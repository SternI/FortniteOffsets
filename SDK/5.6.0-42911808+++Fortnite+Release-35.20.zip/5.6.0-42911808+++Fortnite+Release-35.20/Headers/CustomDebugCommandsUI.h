/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CustomDebugCommandsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "CommonUILegacy.h"
#include "SlateCore.h"
#include "CommonUI.h"

// Size: 0x880 (Inherited: 0x1b70, Single: 0xffffed10)
class UCustomDebugCommandsPanel : public UFortSettingsPanel
{
public:
    uint8_t OnTextFilterCleared[0x10]; // 0x860 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UCustomDebugCommandsPromptWidget* CmdPromptWidget; // 0x870 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_878[0x8]; // 0x878 (Size: 0x8, Type: PaddingProperty)

protected:
    void OnHandleCommandPromptFocusLost(const FFocusEvent InFocusEvent); // 0x11edf008 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void OnHandleFilterChanged(FString& Text); // 0x11edf0d8 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UCustomDebugCommandsPanel) == 0x880, "Size mismatch for UCustomDebugCommandsPanel");
static_assert(offsetof(UCustomDebugCommandsPanel, OnTextFilterCleared) == 0x860, "Offset mismatch for UCustomDebugCommandsPanel::OnTextFilterCleared");
static_assert(offsetof(UCustomDebugCommandsPanel, CmdPromptWidget) == 0x870, "Offset mismatch for UCustomDebugCommandsPanel::CmdPromptWidget");

// Size: 0x2d0 (Inherited: 0x458, Single: 0xfffffe78)
class UCustomDebugCommandsPromptWidget : public UUserWidget
{
public:
    uint8_t OnTextChanged[0x10]; // 0x2b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKeyboardFocusLost[0x10]; // 0x2c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)

protected:
    virtual void HandleCustomDebugCommandResult_BP(EDebugCommandResult& const Result, FString& PlayerName); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    void HandleOnTextChanged(const FText Text); // 0x11ede9c0 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    void HandleOnTextCommited(const FText Text, TEnumAsByte<ETextCommit>& CommitMethod); // 0x11edebcc (Index: 0x2, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UCustomDebugCommandsPromptWidget) == 0x2d0, "Size mismatch for UCustomDebugCommandsPromptWidget");
static_assert(offsetof(UCustomDebugCommandsPromptWidget, OnTextChanged) == 0x2b0, "Offset mismatch for UCustomDebugCommandsPromptWidget::OnTextChanged");
static_assert(offsetof(UCustomDebugCommandsPromptWidget, OnKeyboardFocusLost) == 0x2c0, "Offset mismatch for UCustomDebugCommandsPromptWidget::OnKeyboardFocusLost");

// Size: 0x1b8 (Inherited: 0x1e0, Single: 0xffffffd8)
class UCustomDebugCommandsRegistry : public UFortSettingRegistry
{
public:
};

static_assert(sizeof(UCustomDebugCommandsRegistry) == 0x1b8, "Size mismatch for UCustomDebugCommandsRegistry");

// Size: 0x5f8 (Inherited: 0x1be0, Single: 0xffffea18)
class UCustomDebugCommandsScreen : public USettingsScreen
{
public:
    UCommonButtonBase* Button_CloseTouch; // 0x5f0 (Size: 0x8, Type: ObjectProperty)

private:
    void HandleTabSelected(FName& TabID); // 0x11edeee0 (Index: 0x0, Flags: Final|Native|Private|BlueprintCallable)
};

static_assert(sizeof(UCustomDebugCommandsScreen) == 0x5f8, "Size mismatch for UCustomDebugCommandsScreen");
static_assert(offsetof(UCustomDebugCommandsScreen, Button_CloseTouch) == 0x5f0, "Offset mismatch for UCustomDebugCommandsScreen::Button_CloseTouch");

// Size: 0x60 (Inherited: 0x58, Single: 0x8)
class UFortSettingDataSourceModel_DebugCommand : public UFortSettingDataSourceModel
{
public:
    FString ConsoleCommandName; // 0x30 (Size: 0x10, Type: StrProperty)
    bool bIsServerConsoleCommand; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
    TArray<FString> CommandArgs; // 0x48 (Size: 0x10, Type: ArrayProperty)
    bool bInjectVariableParameter; // 0x58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x3]; // 0x59 (Size: 0x3, Type: PaddingProperty)
    int32_t VariableParameterArgumentPosition; // 0x5c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(UFortSettingDataSourceModel_DebugCommand) == 0x60, "Size mismatch for UFortSettingDataSourceModel_DebugCommand");
static_assert(offsetof(UFortSettingDataSourceModel_DebugCommand, ConsoleCommandName) == 0x30, "Offset mismatch for UFortSettingDataSourceModel_DebugCommand::ConsoleCommandName");
static_assert(offsetof(UFortSettingDataSourceModel_DebugCommand, bIsServerConsoleCommand) == 0x40, "Offset mismatch for UFortSettingDataSourceModel_DebugCommand::bIsServerConsoleCommand");
static_assert(offsetof(UFortSettingDataSourceModel_DebugCommand, CommandArgs) == 0x48, "Offset mismatch for UFortSettingDataSourceModel_DebugCommand::CommandArgs");
static_assert(offsetof(UFortSettingDataSourceModel_DebugCommand, bInjectVariableParameter) == 0x58, "Offset mismatch for UFortSettingDataSourceModel_DebugCommand::bInjectVariableParameter");
static_assert(offsetof(UFortSettingDataSourceModel_DebugCommand, VariableParameterArgumentPosition) == 0x5c, "Offset mismatch for UFortSettingDataSourceModel_DebugCommand::VariableParameterArgumentPosition");

