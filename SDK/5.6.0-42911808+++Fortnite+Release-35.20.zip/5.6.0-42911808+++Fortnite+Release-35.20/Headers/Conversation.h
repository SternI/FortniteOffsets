/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Conversation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"

// Size: 0x72 (Inherited: 0xc8, Single: 0xffffffaa)
class UUFortControllerRequirement_TokenThreshold_C : public UFortControllerRequirement_AccountItemQuantityCheck
{
public:
    bool bSkip; // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bInvertResult; // 0x71 (Size: 0x1, Type: BoolProperty)

protected:
    virtual bool IsRequirementMetInternal(const FControllerRequirementTestContext RequestContext) const; // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UUFortControllerRequirement_TokenThreshold_C) == 0x72, "Size mismatch for UUFortControllerRequirement_TokenThreshold_C");
static_assert(offsetof(UUFortControllerRequirement_TokenThreshold_C, bSkip) == 0x70, "Offset mismatch for UUFortControllerRequirement_TokenThreshold_C::bSkip");
static_assert(offsetof(UUFortControllerRequirement_TokenThreshold_C, bInvertResult) == 0x71, "Offset mismatch for UUFortControllerRequirement_TokenThreshold_C::bInvertResult");

