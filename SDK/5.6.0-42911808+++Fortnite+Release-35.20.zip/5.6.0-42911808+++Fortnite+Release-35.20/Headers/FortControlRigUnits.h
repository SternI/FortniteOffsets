/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortControlRigUnits
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ControlRig.h"
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FFortRigUnit_SphereTrace_WorkData
{
    uint32_t Hash; // 0x0 (Size: 0x4, Type: UInt32Property)
    bool bHit; // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bInitialOverlap; // 0x5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6[0x2]; // 0x6 (Size: 0x2, Type: PaddingProperty)
    FVector HitLocation; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector HitNormal; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FFortRigUnit_SphereTrace_WorkData) == 0x38, "Size mismatch for FFortRigUnit_SphereTrace_WorkData");
static_assert(offsetof(FFortRigUnit_SphereTrace_WorkData, Hash) == 0x0, "Offset mismatch for FFortRigUnit_SphereTrace_WorkData::Hash");
static_assert(offsetof(FFortRigUnit_SphereTrace_WorkData, bHit) == 0x4, "Offset mismatch for FFortRigUnit_SphereTrace_WorkData::bHit");
static_assert(offsetof(FFortRigUnit_SphereTrace_WorkData, bInitialOverlap) == 0x5, "Offset mismatch for FFortRigUnit_SphereTrace_WorkData::bInitialOverlap");
static_assert(offsetof(FFortRigUnit_SphereTrace_WorkData, HitLocation) == 0x8, "Offset mismatch for FFortRigUnit_SphereTrace_WorkData::HitLocation");
static_assert(offsetof(FFortRigUnit_SphereTrace_WorkData, HitNormal) == 0x20, "Offset mismatch for FFortRigUnit_SphereTrace_WorkData::HitNormal");

// Size: 0xe8 (Inherited: 0x10, Single: 0xd8)
struct FFortRigUnit_SphereTraceByChannel : FRigUnit
{
    FVector Start; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector End; // 0x20 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ETraceTypeQuery> TraceChannel; // 0x38 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    float Radius; // 0x3c (Size: 0x4, Type: FloatProperty)
    bool bTraceComplex; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
    TArray<FName> IgnoreActorTags; // 0x48 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer IgnoreGameplayTags; // 0x58 (Size: 0x20, Type: StructProperty)
    uint8_t TraceType; // 0x78 (Size: 0x1, Type: EnumProperty)
    bool bHit; // 0x79 (Size: 0x1, Type: BoolProperty)
    bool bInitialOverlap; // 0x7a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7b[0x5]; // 0x7b (Size: 0x5, Type: PaddingProperty)
    FVector HitLocation; // 0x80 (Size: 0x18, Type: StructProperty)
    FVector HitNormal; // 0x98 (Size: 0x18, Type: StructProperty)
    FFortRigUnit_SphereTrace_WorkData WorkData; // 0xb0 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FFortRigUnit_SphereTraceByChannel) == 0xe8, "Size mismatch for FFortRigUnit_SphereTraceByChannel");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, Start) == 0x8, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::Start");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, End) == 0x20, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::End");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, TraceChannel) == 0x38, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::TraceChannel");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, Radius) == 0x3c, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::Radius");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, bTraceComplex) == 0x40, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::bTraceComplex");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, IgnoreActorTags) == 0x48, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::IgnoreActorTags");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, IgnoreGameplayTags) == 0x58, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::IgnoreGameplayTags");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, TraceType) == 0x78, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::TraceType");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, bHit) == 0x79, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::bHit");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, bInitialOverlap) == 0x7a, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::bInitialOverlap");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, HitLocation) == 0x80, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::HitLocation");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, HitNormal) == 0x98, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::HitNormal");
static_assert(offsetof(FFortRigUnit_SphereTraceByChannel, WorkData) == 0xb0, "Offset mismatch for FFortRigUnit_SphereTraceByChannel::WorkData");

