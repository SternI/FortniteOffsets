/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ContextualTraversalRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "Engine.h"

// Size: 0xf8 (Inherited: 0x310, Single: 0xfffffde8)
class UFortContextualTraversalComponent : public UFortPawnComponent
{
public:
    UCurveFloat* ScoringDistanceCurve; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* ScoringAngleCurve; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d0[0x20]; // 0xd0 (Size: 0x20, Type: PaddingProperty)
    float LockedInteractionTime; // 0xf0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_f4[0x4]; // 0xf4 (Size: 0x4, Type: PaddingProperty)

public:
    void AddInteractionTarget(const FVector TargetLocation, const FRotator TargetRotation, FGameplayTag& TargetTag, float& BaseScoreModifier); // 0xff35e04 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void DrawDebugHUD(AHUD*& HUD, UCanvas*& Canvas); // 0xa93bc70 (Index: 0x1, Flags: Final|Native|Public)
    bool IsBestInteractionOfType(const FGameplayTag InteractionTypeTag) const; // 0xff3606c (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|Const)
    void OnTargetProcessed(FGameplayTag& TargetTag, float& TargetScore); // 0xff3616c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveInteractionTarget(FGameplayTag& TargetTag); // 0xff362a4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortContextualTraversalComponent) == 0xf8, "Size mismatch for UFortContextualTraversalComponent");
static_assert(offsetof(UFortContextualTraversalComponent, ScoringDistanceCurve) == 0xc0, "Offset mismatch for UFortContextualTraversalComponent::ScoringDistanceCurve");
static_assert(offsetof(UFortContextualTraversalComponent, ScoringAngleCurve) == 0xc8, "Offset mismatch for UFortContextualTraversalComponent::ScoringAngleCurve");
static_assert(offsetof(UFortContextualTraversalComponent, LockedInteractionTime) == 0xf0, "Offset mismatch for UFortContextualTraversalComponent::LockedInteractionTime");

// Size: 0x100 (Inherited: 0x68, Single: 0x98)
class UFortMovementMode_TraversalBaseRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
    UAnimMontage* AnimMontage; // 0x40 (Size: 0x8, Type: ObjectProperty)
    FName MontageStartSectionName; // 0x48 (Size: 0x4, Type: NameProperty)
    FName MontageMiddleSectionName; // 0x4c (Size: 0x4, Type: NameProperty)
    FSynchedActionWarpPointInfo_Replicated SynchedActionWarpPointInfo; // 0x50 (Size: 0xa0, Type: StructProperty)
    uint8_t Pad_f0[0x10]; // 0xf0 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFortMovementMode_TraversalBaseRuntimeData) == 0x100, "Size mismatch for UFortMovementMode_TraversalBaseRuntimeData");
static_assert(offsetof(UFortMovementMode_TraversalBaseRuntimeData, AnimMontage) == 0x40, "Offset mismatch for UFortMovementMode_TraversalBaseRuntimeData::AnimMontage");
static_assert(offsetof(UFortMovementMode_TraversalBaseRuntimeData, MontageStartSectionName) == 0x48, "Offset mismatch for UFortMovementMode_TraversalBaseRuntimeData::MontageStartSectionName");
static_assert(offsetof(UFortMovementMode_TraversalBaseRuntimeData, MontageMiddleSectionName) == 0x4c, "Offset mismatch for UFortMovementMode_TraversalBaseRuntimeData::MontageMiddleSectionName");
static_assert(offsetof(UFortMovementMode_TraversalBaseRuntimeData, SynchedActionWarpPointInfo) == 0x50, "Offset mismatch for UFortMovementMode_TraversalBaseRuntimeData::SynchedActionWarpPointInfo");

// Size: 0x240 (Inherited: 0x210, Single: 0x30)
class UFortMovementMode_ExtLogicTraversalBase : public UFortMovementMode_BaseExtLogic
{
public:
    uint8_t Pad_1e8[0x30]; // 0x1e8 (Size: 0x30, Type: PaddingProperty)
    FGameplayTag SynchedActionTag; // 0x218 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_21c[0x4]; // 0x21c (Size: 0x4, Type: PaddingProperty)
    UClass* CameraMode; // 0x220 (Size: 0x8, Type: ClassProperty)
    FGameplayTag CameraModeTag; // 0x228 (Size: 0x4, Type: StructProperty)
    FGameplayTag PreventWeaponHolsterTag; // 0x22c (Size: 0x4, Type: StructProperty)
    FName MontageStartSectionName; // 0x230 (Size: 0x4, Type: NameProperty)
    bool bUseNextSectionAnimName; // 0x234 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_235[0x3]; // 0x235 (Size: 0x3, Type: PaddingProperty)
    float OverrideServerAllowablePositionError; // 0x238 (Size: 0x4, Type: FloatProperty)
    float OverrideAnimBlendOutTimeWhenLanding; // 0x23c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UFortMovementMode_ExtLogicTraversalBase) == 0x240, "Size mismatch for UFortMovementMode_ExtLogicTraversalBase");
static_assert(offsetof(UFortMovementMode_ExtLogicTraversalBase, SynchedActionTag) == 0x218, "Offset mismatch for UFortMovementMode_ExtLogicTraversalBase::SynchedActionTag");
static_assert(offsetof(UFortMovementMode_ExtLogicTraversalBase, CameraMode) == 0x220, "Offset mismatch for UFortMovementMode_ExtLogicTraversalBase::CameraMode");
static_assert(offsetof(UFortMovementMode_ExtLogicTraversalBase, CameraModeTag) == 0x228, "Offset mismatch for UFortMovementMode_ExtLogicTraversalBase::CameraModeTag");
static_assert(offsetof(UFortMovementMode_ExtLogicTraversalBase, PreventWeaponHolsterTag) == 0x22c, "Offset mismatch for UFortMovementMode_ExtLogicTraversalBase::PreventWeaponHolsterTag");
static_assert(offsetof(UFortMovementMode_ExtLogicTraversalBase, MontageStartSectionName) == 0x230, "Offset mismatch for UFortMovementMode_ExtLogicTraversalBase::MontageStartSectionName");
static_assert(offsetof(UFortMovementMode_ExtLogicTraversalBase, bUseNextSectionAnimName) == 0x234, "Offset mismatch for UFortMovementMode_ExtLogicTraversalBase::bUseNextSectionAnimName");
static_assert(offsetof(UFortMovementMode_ExtLogicTraversalBase, OverrideServerAllowablePositionError) == 0x238, "Offset mismatch for UFortMovementMode_ExtLogicTraversalBase::OverrideServerAllowablePositionError");
static_assert(offsetof(UFortMovementMode_ExtLogicTraversalBase, OverrideAnimBlendOutTimeWhenLanding) == 0x23c, "Offset mismatch for UFortMovementMode_ExtLogicTraversalBase::OverrideAnimBlendOutTimeWhenLanding");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FContextualTraversalTargetingData
{
    float ScoringModifier; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FVector Location; // 0x10 (Size: 0x18, Type: StructProperty)
    FRotator Rotation; // 0x28 (Size: 0x18, Type: StructProperty)
    FGameplayTag Tag; // 0x40 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FContextualTraversalTargetingData) == 0x48, "Size mismatch for FContextualTraversalTargetingData");
static_assert(offsetof(FContextualTraversalTargetingData, ScoringModifier) == 0x8, "Offset mismatch for FContextualTraversalTargetingData::ScoringModifier");
static_assert(offsetof(FContextualTraversalTargetingData, Location) == 0x10, "Offset mismatch for FContextualTraversalTargetingData::Location");
static_assert(offsetof(FContextualTraversalTargetingData, Rotation) == 0x28, "Offset mismatch for FContextualTraversalTargetingData::Rotation");
static_assert(offsetof(FContextualTraversalTargetingData, Tag) == 0x40, "Offset mismatch for FContextualTraversalTargetingData::Tag");

// Size: 0x130 (Inherited: 0x10, Single: 0x120)
struct FFortMovementMode_TraversalBaseCreationData : FFortMovementMode_BaseExtCreationData
{
    FSynchedActionInfo SynchedActionInfo; // 0x10 (Size: 0x30, Type: StructProperty)
    FSynchedActionWarpPointInfo_Replicated SynchedActionWarpPointInfo; // 0x40 (Size: 0xa0, Type: StructProperty)
    FVector TargetLocation; // 0xe0 (Size: 0x18, Type: StructProperty)
    FRotator TargetRotation; // 0xf8 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<AActor*> RefActor; // 0x110 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UPrimitiveComponent*> RefActorComponent; // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    FName RefActorBoneName; // 0x120 (Size: 0x4, Type: NameProperty)
    uint8_t EndMovementMode; // 0x124 (Size: 0x1, Type: EnumProperty)
    bool bIsWindow; // 0x125 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_126[0xa]; // 0x126 (Size: 0xa, Type: PaddingProperty)
};

static_assert(sizeof(FFortMovementMode_TraversalBaseCreationData) == 0x130, "Size mismatch for FFortMovementMode_TraversalBaseCreationData");
static_assert(offsetof(FFortMovementMode_TraversalBaseCreationData, SynchedActionInfo) == 0x10, "Offset mismatch for FFortMovementMode_TraversalBaseCreationData::SynchedActionInfo");
static_assert(offsetof(FFortMovementMode_TraversalBaseCreationData, SynchedActionWarpPointInfo) == 0x40, "Offset mismatch for FFortMovementMode_TraversalBaseCreationData::SynchedActionWarpPointInfo");
static_assert(offsetof(FFortMovementMode_TraversalBaseCreationData, TargetLocation) == 0xe0, "Offset mismatch for FFortMovementMode_TraversalBaseCreationData::TargetLocation");
static_assert(offsetof(FFortMovementMode_TraversalBaseCreationData, TargetRotation) == 0xf8, "Offset mismatch for FFortMovementMode_TraversalBaseCreationData::TargetRotation");
static_assert(offsetof(FFortMovementMode_TraversalBaseCreationData, RefActor) == 0x110, "Offset mismatch for FFortMovementMode_TraversalBaseCreationData::RefActor");
static_assert(offsetof(FFortMovementMode_TraversalBaseCreationData, RefActorComponent) == 0x118, "Offset mismatch for FFortMovementMode_TraversalBaseCreationData::RefActorComponent");
static_assert(offsetof(FFortMovementMode_TraversalBaseCreationData, RefActorBoneName) == 0x120, "Offset mismatch for FFortMovementMode_TraversalBaseCreationData::RefActorBoneName");
static_assert(offsetof(FFortMovementMode_TraversalBaseCreationData, EndMovementMode) == 0x124, "Offset mismatch for FFortMovementMode_TraversalBaseCreationData::EndMovementMode");
static_assert(offsetof(FFortMovementMode_TraversalBaseCreationData, bIsWindow) == 0x125, "Offset mismatch for FFortMovementMode_TraversalBaseCreationData::bIsWindow");

