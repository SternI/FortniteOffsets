/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreatorProfile
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "UMG.h"
#include "WBP_Discover_Surface_Base.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "FortniteUI.h"
#include "UIKit.h"
#include "ModelViewViewModel.h"
#include "Systems.h"
#include "Engine.h"
#include "Foundation.h"
#include "FortniteGame.h"
#include "SlateCore.h"

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FUI_SocialIcons_Structure
{
    TMap<UMaterialInstance*, ESocialLinkType> SocialIconsMap_5_40D24916421067524EA597910CB76455; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FUI_SocialIcons_Structure) == 0x50, "Size mismatch for FUI_SocialIcons_Structure");
static_assert(offsetof(FUI_SocialIcons_Structure, SocialIconsMap_5_40D24916421067524EA597910CB76455) == 0x0, "Offset mismatch for FUI_SocialIcons_Structure::SocialIconsMap_5_40D24916421067524EA597910CB76455");

// Size: 0x390 (Inherited: 0x458, Single: 0xffffff38)
class UWBP_CreatorPage_Infos_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2b0 (Size: 0x8, Type: StructProperty)
    UWBP_CreatorPage_Followed_CoachMark_C* WBP_CreatorPage_Followed_CoachMark; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* VB_MiniHeaderCollapsibleArea; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Txt_Bio; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UDynamicEntryBox* EntryBox_MediaButtons; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UWBP_CreatorPage_Button_Main_C* Button_Follow; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_ContextMenuAnchorButton_C* Button_ContextMenu; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UUIKitContextMenuActionContext* ContextMenuActionContext; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t HandleCreatorReported[0x10]; // 0x2f0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t HandleFollowClicked[0x10]; // 0x300 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FUI_SocialIcons_Structure SocialIconsMapReference; // 0x310 (Size: 0x50, Type: StructProperty)
    UUserWidget* LastFocusedWidget; // 0x360 (Size: 0x8, Type: ObjectProperty)
    int32_t LastFocusedSocialButtonIndex; // 0x368 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_36c[0x4]; // 0x36c (Size: 0x4, Type: PaddingProperty)
    uint8_t LastFocusedUpdatedFromCreatorInfos[0x10]; // 0x370 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FText CreatorName; // 0x380 (Size: 0x10, Type: TextProperty)

public:
    void SetSocialInfos(TMap<UFortSocialInfoVM*, ESocialLinkType>& SocialInfoMap); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetCanBeReported(bool& Can_Be_Reported); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x3, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void Open_Social_Info_Dialog(UCommonButtonBase*& Button); // 0x288a61c (Index: 0x4, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnSocialButtonFocused(int32_t& FocusedEntryBoxIndex); // 0x288a61c (Index: 0x5, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    UWidget* NavigateToSocialInfos(EUINavigation& Navigation); // 0x288a61c (Index: 0x6, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    UWidget* NavigateFromSocialInfos(EUINavigation& Navigation); // 0x288a61c (Index: 0x7, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    UWidget* NavigateFromFollowButton(EUINavigation& Navigation); // 0x288a61c (Index: 0x8, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    UWidget* NavigateFromContextMenuButton(EUINavigation& Navigation); // 0x288a61c (Index: 0x9, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void LastFocusedUpdatedFromCreatorInfos__DelegateSignature(UUserWidget*& LastFocusedWidget); // 0x288a61c (Index: 0xa, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void HandleFollowClicked__DelegateSignature(UCommonButtonBase*& Button); // 0x288a61c (Index: 0xb, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void HandleCreatorReported__DelegateSignature(); // 0x288a61c (Index: 0xc, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0xe, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void SetupContextMenu(); // 0x288a61c (Index: 0x10, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_CreatorPage_Infos_C) == 0x390, "Size mismatch for UWBP_CreatorPage_Infos_C");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, UberGraphFrame) == 0x2b0, "Offset mismatch for UWBP_CreatorPage_Infos_C::UberGraphFrame");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, WBP_CreatorPage_Followed_CoachMark) == 0x2b8, "Offset mismatch for UWBP_CreatorPage_Infos_C::WBP_CreatorPage_Followed_CoachMark");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, VB_MiniHeaderCollapsibleArea) == 0x2c0, "Offset mismatch for UWBP_CreatorPage_Infos_C::VB_MiniHeaderCollapsibleArea");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, Txt_Bio) == 0x2c8, "Offset mismatch for UWBP_CreatorPage_Infos_C::Txt_Bio");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, EntryBox_MediaButtons) == 0x2d0, "Offset mismatch for UWBP_CreatorPage_Infos_C::EntryBox_MediaButtons");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, Button_Follow) == 0x2d8, "Offset mismatch for UWBP_CreatorPage_Infos_C::Button_Follow");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, Button_ContextMenu) == 0x2e0, "Offset mismatch for UWBP_CreatorPage_Infos_C::Button_ContextMenu");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, ContextMenuActionContext) == 0x2e8, "Offset mismatch for UWBP_CreatorPage_Infos_C::ContextMenuActionContext");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, HandleCreatorReported) == 0x2f0, "Offset mismatch for UWBP_CreatorPage_Infos_C::HandleCreatorReported");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, HandleFollowClicked) == 0x300, "Offset mismatch for UWBP_CreatorPage_Infos_C::HandleFollowClicked");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, SocialIconsMapReference) == 0x310, "Offset mismatch for UWBP_CreatorPage_Infos_C::SocialIconsMapReference");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, LastFocusedWidget) == 0x360, "Offset mismatch for UWBP_CreatorPage_Infos_C::LastFocusedWidget");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, LastFocusedSocialButtonIndex) == 0x368, "Offset mismatch for UWBP_CreatorPage_Infos_C::LastFocusedSocialButtonIndex");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, LastFocusedUpdatedFromCreatorInfos) == 0x370, "Offset mismatch for UWBP_CreatorPage_Infos_C::LastFocusedUpdatedFromCreatorInfos");
static_assert(offsetof(UWBP_CreatorPage_Infos_C, CreatorName) == 0x380, "Offset mismatch for UWBP_CreatorPage_Infos_C::CreatorName");

// Size: 0x588 (Inherited: 0x1080, Single: 0xfffff508)
class UWBP_FollowCreator_ProfilePage_C : public UWBP_Discover_Surface_Base_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x548 (Size: 0x8, Type: StructProperty)
    UWBP_CreatorPage_Infos_C* WBP_CreatorPage_Infos; // 0x550 (Size: 0x8, Type: ObjectProperty)
    UWBP_CreatorInfo_NonCollapsible_C* WBP_CreatorInfo_NonCollapsible; // 0x558 (Size: 0x8, Type: ObjectProperty)
    UOverlay* HeaderOverlay; // 0x560 (Size: 0x8, Type: ObjectProperty)
    UFortPlayerPageVM* FortPlayerPageVM; // 0x568 (Size: 0x8, Type: ObjectProperty)
    UWidget* LastFocusedCreatorWidget; // 0x570 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Unfavorite_Sound; // 0x578 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Favorite_Sound; // 0x580 (Size: 0x8, Type: ObjectProperty)

public:
    void SetHeaderImageState(EActivityImageLoadingState& LoadingEnum); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetCreatorName(FText& CreatorName); // 0x288a61c (Index: 0x1, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetAvatarImageState(EActivityImageLoadingState& LoadingEnum); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    UWidget* OnNavigateDownFromInfoHeader(EUINavigation& Navigation); // 0x288a61c (Index: 0x6, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void NavigateUpFromMegalist(); // 0x288a61c (Index: 0xd, Flags: Public|BlueprintCallable|BlueprintEvent)
    void LoadHeaderImage(FString& URL); // 0x288a61c (Index: 0xe, Flags: Public|BlueprintCallable|BlueprintEvent)
    void LoadAvatarImage(FString& AvatarURL); // 0x288a61c (Index: 0xf, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual FPrimaryContentSetup GetPrimaryContentSetup() const; // 0x288a61c (Index: 0x11, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const)
    FFlowAnalyticsAdditionalInfo GetCreatorIDForTelemetry(); // 0x288a61c (Index: 0x12, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual void Destruct(); // 0x288a61c (Index: 0x14, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x15, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void BP_OnDeactivated(); // 0x288a61c (Index: 0x16, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnActivated(); // 0x288a61c (Index: 0x17, Flags: Event|Protected|BlueprintEvent)
    virtual UWidget* BP_GetDesiredFocusTarget() const; // 0x288a61c (Index: 0x18, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
    void __194156cd_4db8_4174_96b8_d1a2f05836bb_SourceToDest(UWidget*& SwitcherActiveWidget) const; // 0x288a61c (Index: 0x1a, Flags: Final|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UWBP_FollowCreator_ProfilePage_C) == 0x588, "Size mismatch for UWBP_FollowCreator_ProfilePage_C");
static_assert(offsetof(UWBP_FollowCreator_ProfilePage_C, UberGraphFrame) == 0x548, "Offset mismatch for UWBP_FollowCreator_ProfilePage_C::UberGraphFrame");
static_assert(offsetof(UWBP_FollowCreator_ProfilePage_C, WBP_CreatorPage_Infos) == 0x550, "Offset mismatch for UWBP_FollowCreator_ProfilePage_C::WBP_CreatorPage_Infos");
static_assert(offsetof(UWBP_FollowCreator_ProfilePage_C, WBP_CreatorInfo_NonCollapsible) == 0x558, "Offset mismatch for UWBP_FollowCreator_ProfilePage_C::WBP_CreatorInfo_NonCollapsible");
static_assert(offsetof(UWBP_FollowCreator_ProfilePage_C, HeaderOverlay) == 0x560, "Offset mismatch for UWBP_FollowCreator_ProfilePage_C::HeaderOverlay");
static_assert(offsetof(UWBP_FollowCreator_ProfilePage_C, FortPlayerPageVM) == 0x568, "Offset mismatch for UWBP_FollowCreator_ProfilePage_C::FortPlayerPageVM");
static_assert(offsetof(UWBP_FollowCreator_ProfilePage_C, LastFocusedCreatorWidget) == 0x570, "Offset mismatch for UWBP_FollowCreator_ProfilePage_C::LastFocusedCreatorWidget");
static_assert(offsetof(UWBP_FollowCreator_ProfilePage_C, Unfavorite_Sound) == 0x578, "Offset mismatch for UWBP_FollowCreator_ProfilePage_C::Unfavorite_Sound");
static_assert(offsetof(UWBP_FollowCreator_ProfilePage_C, Favorite_Sound) == 0x580, "Offset mismatch for UWBP_FollowCreator_ProfilePage_C::Favorite_Sound");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UUI_SocialLinkType_Icons_Map_C : public UObject
{
public:
    FUI_SocialIcons_Structure SocialLinkIconsMap; // 0x28 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(UUI_SocialLinkType_Icons_Map_C) == 0x78, "Size mismatch for UUI_SocialLinkType_Icons_Map_C");
static_assert(offsetof(UUI_SocialLinkType_Icons_Map_C, SocialLinkIconsMap) == 0x28, "Offset mismatch for UUI_SocialLinkType_Icons_Map_C::SocialLinkIconsMap");

// Size: 0x480 (Inherited: 0xb38, Single: 0xfffff948)
class UWBP_CreatorPage_QRCode_Modal_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x408 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_Dialog_Base_C* WBP_UIKit_Dialog_Base; // 0x410 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Block_Outline_C* WBP_Outline; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_URL; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ModalTitle; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Desc; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_QRCode; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UButton* Button_URL; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* Button_Close; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UCloseButton_C* Button_BackTouch; // 0x450 (Size: 0x8, Type: ObjectProperty)
    double Mobile_Scale; // 0x458 (Size: 0x8, Type: DoubleProperty)
    FString URL; // 0x460 (Size: 0x10, Type: StrProperty)
    FString SocialPlatform; // 0x470 (Size: 0x10, Type: StrProperty)

public:
    void SetCreatorData(FText& Creator_Name, FString& Social_Platform, FString& URL); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_CreatorPage_QRCode_Modal_C) == 0x480, "Size mismatch for UWBP_CreatorPage_QRCode_Modal_C");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, UberGraphFrame) == 0x408, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::UberGraphFrame");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, WBP_UIKit_Dialog_Base) == 0x410, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::WBP_UIKit_Dialog_Base");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, WBP_Outline) == 0x418, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::WBP_Outline");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, Text_URL) == 0x420, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::Text_URL");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, Text_ModalTitle) == 0x428, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::Text_ModalTitle");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, Text_Desc) == 0x430, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::Text_Desc");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, Image_QRCode) == 0x438, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::Image_QRCode");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, Button_URL) == 0x440, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::Button_URL");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, Button_Close) == 0x448, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::Button_Close");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, Button_BackTouch) == 0x450, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::Button_BackTouch");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, Mobile_Scale) == 0x458, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::Mobile_Scale");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, URL) == 0x460, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::URL");
static_assert(offsetof(UWBP_CreatorPage_QRCode_Modal_C, SocialPlatform) == 0x470, "Offset mismatch for UWBP_CreatorPage_QRCode_Modal_C::SocialPlatform");

// Size: 0x480 (Inherited: 0xfa8, Single: 0xfffff4d8)
class UWBP_CreatorPage_Followed_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x470 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark; // 0x478 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void OnRemovedFromFocusPath(FFocusEvent& InFocusEvent); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void OnShowTooltip(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnEndTooltip(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_CreatorPage_Followed_CoachMark_C) == 0x480, "Size mismatch for UWBP_CreatorPage_Followed_CoachMark_C");
static_assert(offsetof(UWBP_CreatorPage_Followed_CoachMark_C, UberGraphFrame) == 0x470, "Offset mismatch for UWBP_CreatorPage_Followed_CoachMark_C::UberGraphFrame");
static_assert(offsetof(UWBP_CreatorPage_Followed_CoachMark_C, WBP_UIKit_CoachMark) == 0x478, "Offset mismatch for UWBP_CreatorPage_Followed_CoachMark_C::WBP_UIKit_CoachMark");

// Size: 0x18c0 (Inherited: 0x6174, Single: 0xffffb74c)
class UWBP_CreatorPage_Button_Link_C : public UWBP_UIKit_Button_Generic_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x1880 (Size: 0x8, Type: StructProperty)
    FString URL; // 0x1888 (Size: 0x10, Type: StrProperty)
    FString Platform; // 0x1898 (Size: 0x10, Type: StrProperty)
    int32_t EntryBoxIndex; // 0x18a8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_18ac[0x4]; // 0x18ac (Size: 0x4, Type: PaddingProperty)
    uint8_t OnSocialButtonFocused[0x10]; // 0x18b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void SetMobileStyle(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void OnSocialButtonFocused__DelegateSignature(int32_t& EntryBoxIndex); // 0x288a61c (Index: 0x1, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x3, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void BP_OnFocusReceived(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_CreatorPage_Button_Link_C) == 0x18c0, "Size mismatch for UWBP_CreatorPage_Button_Link_C");
static_assert(offsetof(UWBP_CreatorPage_Button_Link_C, UberGraphFrame) == 0x1880, "Offset mismatch for UWBP_CreatorPage_Button_Link_C::UberGraphFrame");
static_assert(offsetof(UWBP_CreatorPage_Button_Link_C, URL) == 0x1888, "Offset mismatch for UWBP_CreatorPage_Button_Link_C::URL");
static_assert(offsetof(UWBP_CreatorPage_Button_Link_C, Platform) == 0x1898, "Offset mismatch for UWBP_CreatorPage_Button_Link_C::Platform");
static_assert(offsetof(UWBP_CreatorPage_Button_Link_C, EntryBoxIndex) == 0x18a8, "Offset mismatch for UWBP_CreatorPage_Button_Link_C::EntryBoxIndex");
static_assert(offsetof(UWBP_CreatorPage_Button_Link_C, OnSocialButtonFocused) == 0x18b0, "Offset mismatch for UWBP_CreatorPage_Button_Link_C::OnSocialButtonFocused");

// Size: 0xd8 (Inherited: 0x168, Single: 0xffffff70)
class UDialogVM_FollowLimitReached_C : public UUIKitDialogViewModel
{
public:
};

static_assert(sizeof(UDialogVM_FollowLimitReached_C) == 0xd8, "Size mismatch for UDialogVM_FollowLimitReached_C");

// Size: 0x2c8 (Inherited: 0x458, Single: 0xfffffe70)
class UWBP_CreatorPage_FavoriteCount_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2b0 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Txt_Favorite; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Txt_Count; // 0x2c0 (Size: 0x8, Type: ObjectProperty)

public:
    void Set_Favorite_Count(int32_t& Favorite_Count); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UWBP_CreatorPage_FavoriteCount_C) == 0x2c8, "Size mismatch for UWBP_CreatorPage_FavoriteCount_C");
static_assert(offsetof(UWBP_CreatorPage_FavoriteCount_C, UberGraphFrame) == 0x2b0, "Offset mismatch for UWBP_CreatorPage_FavoriteCount_C::UberGraphFrame");
static_assert(offsetof(UWBP_CreatorPage_FavoriteCount_C, Txt_Favorite) == 0x2b8, "Offset mismatch for UWBP_CreatorPage_FavoriteCount_C::Txt_Favorite");
static_assert(offsetof(UWBP_CreatorPage_FavoriteCount_C, Txt_Count) == 0x2c0, "Offset mismatch for UWBP_CreatorPage_FavoriteCount_C::Txt_Count");

// Size: 0x18b8 (Inherited: 0x6174, Single: 0xffffb744)
class UWBP_CreatorPage_Button_Main_C : public UWBP_UIKit_Button_Generic_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x1880 (Size: 0x8, Type: StructProperty)
    UWidgetAnimation* Anim_Following; // 0x1888 (Size: 0x8, Type: ObjectProperty)
    double AnimValue_Following_Icon; // 0x1890 (Size: 0x8, Type: DoubleProperty)
    bool Is_Following; // 0x1898 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1899[0x7]; // 0x1899 (Size: 0x7, Type: PaddingProperty)
    double AnimValue_Following_Background; // 0x18a0 (Size: 0x8, Type: DoubleProperty)
    bool IsInitialized; // 0x18a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_18a9[0x7]; // 0x18a9 (Size: 0x7, Type: PaddingProperty)
    double IconRightPadding; // 0x18b0 (Size: 0x8, Type: DoubleProperty)

public:
    void SetFollowState(bool& IsFollowing); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x2, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x4, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

private:
    void SetAnimValue_Following_Background(double& NewParam); // 0x288a61c (Index: 0x1, Flags: Private|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_CreatorPage_Button_Main_C) == 0x18b8, "Size mismatch for UWBP_CreatorPage_Button_Main_C");
static_assert(offsetof(UWBP_CreatorPage_Button_Main_C, UberGraphFrame) == 0x1880, "Offset mismatch for UWBP_CreatorPage_Button_Main_C::UberGraphFrame");
static_assert(offsetof(UWBP_CreatorPage_Button_Main_C, Anim_Following) == 0x1888, "Offset mismatch for UWBP_CreatorPage_Button_Main_C::Anim_Following");
static_assert(offsetof(UWBP_CreatorPage_Button_Main_C, AnimValue_Following_Icon) == 0x1890, "Offset mismatch for UWBP_CreatorPage_Button_Main_C::AnimValue_Following_Icon");
static_assert(offsetof(UWBP_CreatorPage_Button_Main_C, Is_Following) == 0x1898, "Offset mismatch for UWBP_CreatorPage_Button_Main_C::Is_Following");
static_assert(offsetof(UWBP_CreatorPage_Button_Main_C, AnimValue_Following_Background) == 0x18a0, "Offset mismatch for UWBP_CreatorPage_Button_Main_C::AnimValue_Following_Background");
static_assert(offsetof(UWBP_CreatorPage_Button_Main_C, IsInitialized) == 0x18a8, "Offset mismatch for UWBP_CreatorPage_Button_Main_C::IsInitialized");
static_assert(offsetof(UWBP_CreatorPage_Button_Main_C, IconRightPadding) == 0x18b0, "Offset mismatch for UWBP_CreatorPage_Button_Main_C::IconRightPadding");

// Size: 0x2f8 (Inherited: 0x458, Single: 0xfffffea0)
class UWBP_CreatorInfo_NonCollapsible_C : public UUserWidget
{
public:
    UWBP_CreatorPage_FavoriteCount_C* WBP_CreatorPage_FavoriteCount; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UWBP_Creator_AvatarImage_C* WBP_Creator_AvatarImage; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Txt_CreatorName; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t HandleCreatorReported[0x10]; // 0x2c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t HandleFollowClicked[0x10]; // 0x2d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t LastFocusedUpdatedFromCreatorInfos[0x10]; // 0x2e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void LastFocusedUpdatedFromCreatorInfos__DelegateSignature(UUserWidget*& LastFocusedWidget); // 0x288a61c (Index: 0x0, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void HandleFollowClicked__DelegateSignature(UCommonButtonBase*& Button); // 0x288a61c (Index: 0x1, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void HandleCreatorReported__DelegateSignature(); // 0x288a61c (Index: 0x2, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_CreatorInfo_NonCollapsible_C) == 0x2f8, "Size mismatch for UWBP_CreatorInfo_NonCollapsible_C");
static_assert(offsetof(UWBP_CreatorInfo_NonCollapsible_C, WBP_CreatorPage_FavoriteCount) == 0x2b0, "Offset mismatch for UWBP_CreatorInfo_NonCollapsible_C::WBP_CreatorPage_FavoriteCount");
static_assert(offsetof(UWBP_CreatorInfo_NonCollapsible_C, WBP_Creator_AvatarImage) == 0x2b8, "Offset mismatch for UWBP_CreatorInfo_NonCollapsible_C::WBP_Creator_AvatarImage");
static_assert(offsetof(UWBP_CreatorInfo_NonCollapsible_C, Txt_CreatorName) == 0x2c0, "Offset mismatch for UWBP_CreatorInfo_NonCollapsible_C::Txt_CreatorName");
static_assert(offsetof(UWBP_CreatorInfo_NonCollapsible_C, HandleCreatorReported) == 0x2c8, "Offset mismatch for UWBP_CreatorInfo_NonCollapsible_C::HandleCreatorReported");
static_assert(offsetof(UWBP_CreatorInfo_NonCollapsible_C, HandleFollowClicked) == 0x2d8, "Offset mismatch for UWBP_CreatorInfo_NonCollapsible_C::HandleFollowClicked");
static_assert(offsetof(UWBP_CreatorInfo_NonCollapsible_C, LastFocusedUpdatedFromCreatorInfos) == 0x2e8, "Offset mismatch for UWBP_CreatorInfo_NonCollapsible_C::LastFocusedUpdatedFromCreatorInfos");

// Size: 0x30c (Inherited: 0x730, Single: 0xfffffbdc)
class UWBP_Creator_AvatarImage_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2d8 (Size: 0x8, Type: StructProperty)
    UImage* LiveFeedback; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UImage* CreatorThumbnail; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnLoadedImage; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    FVector2D CreatorAvatarSize; // 0x2f8 (Size: 0x10, Type: StructProperty)
    FName TextureParam; // 0x308 (Size: 0x4, Type: NameProperty)

public:
    void SetLoadingState(); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetIsPlayingNow(bool& IsPlayingNow); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetCreatorAvatarImageTexture(UTexture*& CreatorAvatarTexture); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetCreatorAvatarImageSize(FVector2D& CreatorAvatarSize); // 0x288a61c (Index: 0x4, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x5, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UWBP_Creator_AvatarImage_C) == 0x30c, "Size mismatch for UWBP_Creator_AvatarImage_C");
static_assert(offsetof(UWBP_Creator_AvatarImage_C, UberGraphFrame) == 0x2d8, "Offset mismatch for UWBP_Creator_AvatarImage_C::UberGraphFrame");
static_assert(offsetof(UWBP_Creator_AvatarImage_C, LiveFeedback) == 0x2e0, "Offset mismatch for UWBP_Creator_AvatarImage_C::LiveFeedback");
static_assert(offsetof(UWBP_Creator_AvatarImage_C, CreatorThumbnail) == 0x2e8, "Offset mismatch for UWBP_Creator_AvatarImage_C::CreatorThumbnail");
static_assert(offsetof(UWBP_Creator_AvatarImage_C, Anim_OnLoadedImage) == 0x2f0, "Offset mismatch for UWBP_Creator_AvatarImage_C::Anim_OnLoadedImage");
static_assert(offsetof(UWBP_Creator_AvatarImage_C, CreatorAvatarSize) == 0x2f8, "Offset mismatch for UWBP_Creator_AvatarImage_C::CreatorAvatarSize");
static_assert(offsetof(UWBP_Creator_AvatarImage_C, TextureParam) == 0x308, "Offset mismatch for UWBP_Creator_AvatarImage_C::TextureParam");

