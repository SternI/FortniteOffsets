/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DianaGameUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "CoreUObject.h"

// Size: 0x90 (Inherited: 0x100, Single: 0xffffff90)
class UDianaSessionTimerViewModel : public UFortPerUserViewModel
{
public:
    int32_t PlayerCount; // 0x70 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_74[0xc]; // 0x74 (Size: 0xc, Type: PaddingProperty)
    float MaxSessionTimeSeconds; // 0x80 (Size: 0x4, Type: FloatProperty)
    int32_t MaxPlayersInGame; // 0x84 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)

public:
    FTimespan GetCurrentTimeSpan() const; // 0x126b1d64 (Index: 0x0, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    int32_t GetMaxPlayersInGame() const; // 0x99c4174 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void UpdatePlayerCount(int32_t& CurrentPlayersInGame); // 0x126b1d90 (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDianaSessionTimerViewModel) == 0x90, "Size mismatch for UDianaSessionTimerViewModel");
static_assert(offsetof(UDianaSessionTimerViewModel, PlayerCount) == 0x70, "Offset mismatch for UDianaSessionTimerViewModel::PlayerCount");
static_assert(offsetof(UDianaSessionTimerViewModel, MaxSessionTimeSeconds) == 0x80, "Offset mismatch for UDianaSessionTimerViewModel::MaxSessionTimeSeconds");
static_assert(offsetof(UDianaSessionTimerViewModel, MaxPlayersInGame) == 0x84, "Offset mismatch for UDianaSessionTimerViewModel::MaxPlayersInGame");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDianaFinalSurvivorEvent
{
};

static_assert(sizeof(FDianaFinalSurvivorEvent) == 0x1, "Size mismatch for FDianaFinalSurvivorEvent");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDianaFinalSurvivorCompleteEvent
{
};

static_assert(sizeof(FDianaFinalSurvivorCompleteEvent) == 0x1, "Size mismatch for FDianaFinalSurvivorCompleteEvent");

