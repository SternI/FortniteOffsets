/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Dialogs
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "ModelViewViewModel.h"
#include "CoreUObject.h"

// Size: 0xd8 (Inherited: 0x168, Single: 0xffffff70)
class UDialogVM_DiscoTileDisclaimer_RecentlyPlayed_C : public UUIKitDialogViewModel
{
public:
};

static_assert(sizeof(UDialogVM_DiscoTileDisclaimer_RecentlyPlayed_C) == 0xd8, "Size mismatch for UDialogVM_DiscoTileDisclaimer_RecentlyPlayed_C");

// Size: 0xd8 (Inherited: 0x168, Single: 0xffffff70)
class UDialogVM_DiscoTileDisclaimer_Recommended_C : public UUIKitDialogViewModel
{
public:
};

static_assert(sizeof(UDialogVM_DiscoTileDisclaimer_Recommended_C) == 0xd8, "Size mismatch for UDialogVM_DiscoTileDisclaimer_Recommended_C");

// Size: 0xd8 (Inherited: 0x168, Single: 0xffffff70)
class UDialogVM_DiscoTileDisclaimer_C : public UUIKitDialogViewModel
{
public:
};

static_assert(sizeof(UDialogVM_DiscoTileDisclaimer_C) == 0xd8, "Size mismatch for UDialogVM_DiscoTileDisclaimer_C");

