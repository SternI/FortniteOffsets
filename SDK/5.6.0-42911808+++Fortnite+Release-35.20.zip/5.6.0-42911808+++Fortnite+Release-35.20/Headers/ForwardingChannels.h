/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ForwardingChannels
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UForwardingChannelFactory : public UInterface
{
public:
};

static_assert(sizeof(UForwardingChannelFactory) == 0x28, "Size mismatch for UForwardingChannelFactory");

// Size: 0x98 (Inherited: 0x88, Single: 0x10)
class UForwardingChannelsSubsystem : public UGameInstanceSubsystem
{
public:
    TArray<TScriptInterface<Class>> ForwardingChannelFactories; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_40[0x58]; // 0x40 (Size: 0x58, Type: PaddingProperty)
};

static_assert(sizeof(UForwardingChannelsSubsystem) == 0x98, "Size mismatch for UForwardingChannelsSubsystem");
static_assert(offsetof(UForwardingChannelsSubsystem, ForwardingChannelFactories) == 0x30, "Offset mismatch for UForwardingChannelsSubsystem::ForwardingChannelFactories");

