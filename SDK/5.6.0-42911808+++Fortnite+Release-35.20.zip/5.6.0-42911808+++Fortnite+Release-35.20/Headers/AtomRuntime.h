/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AtomRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "DeveloperSettings.h"
#include "Engine.h"
#include "ISMPool.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAtomActorConnectivityResolver : public UObject
{
public:
};

static_assert(sizeof(UAtomActorConnectivityResolver) == 0x28, "Size mismatch for UAtomActorConnectivityResolver");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UAtomActorConnectivityResolverRegistry : public UDeveloperSettings
{
public:
    TArray<UClass*> Resolvers; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UAtomActorConnectivityResolverRegistry) == 0x40, "Size mismatch for UAtomActorConnectivityResolverRegistry");
static_assert(offsetof(UAtomActorConnectivityResolverRegistry, Resolvers) == 0x30, "Offset mismatch for UAtomActorConnectivityResolverRegistry::Resolvers");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAtomTextureImportData : public UAssetImportData
{
public:
};

static_assert(sizeof(UAtomTextureImportData) == 0x28, "Size mismatch for UAtomTextureImportData");

// Size: 0x58 (Inherited: 0x50, Single: 0x8)
class UAtomColorThemeTextureUserData : public UAssetUserData
{
public:
    TArray<FName> ThemeNames; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UAtomColorThemeLibrary*> SourceColorThemeLibrary; // 0x38 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(UAtomColorThemeTextureUserData) == 0x58, "Size mismatch for UAtomColorThemeTextureUserData");
static_assert(offsetof(UAtomColorThemeTextureUserData, ThemeNames) == 0x28, "Offset mismatch for UAtomColorThemeTextureUserData::ThemeNames");
static_assert(offsetof(UAtomColorThemeTextureUserData, SourceColorThemeLibrary) == 0x38, "Offset mismatch for UAtomColorThemeTextureUserData::SourceColorThemeLibrary");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UAtomColorLUTAtlas : public UObject
{
public:
    UTexture2D* AtlasTexture; // 0x28 (Size: 0x8, Type: ObjectProperty)
    TArray<UTexture2D*> Textures; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_40[0x8]; // 0x40 (Size: 0x8, Type: PaddingProperty)

public:
    int32_t FindOrAddLUTIndex(UTexture2D*& InTexture); // 0x10878f04 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    int32_t GetAtlasSize() const; // 0x1087958c (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetLUTIndex(UTexture2D*& InTexture) const; // 0x10879690 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UAtomColorLUTAtlas) == 0x48, "Size mismatch for UAtomColorLUTAtlas");
static_assert(offsetof(UAtomColorLUTAtlas, AtlasTexture) == 0x28, "Offset mismatch for UAtomColorLUTAtlas::AtlasTexture");
static_assert(offsetof(UAtomColorLUTAtlas, Textures) == 0x30, "Offset mismatch for UAtomColorLUTAtlas::Textures");

// Size: 0xe8 (Inherited: 0xe0, Single: 0x8)
class UAtomColorThemeComponent : public UActorComponent
{
public:
    UAtomColorLUTAtlas* ColorLUTAtlas; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* ColorLUTTexture; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    bool bIsThemeCustomTexture; // 0xc8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c9[0x3]; // 0xc9 (Size: 0x3, Type: PaddingProperty)
    FName ColorThemeLibrary; // 0xcc (Size: 0x4, Type: NameProperty)
    FName ColorTheme; // 0xd0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
    UTexture2D* SelectedGeneratedLibraryTexture; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UAtomColorThemeLibrary* SelectedColorThemeLibrary; // 0xe0 (Size: 0x8, Type: ObjectProperty)

public:
    void ApplyColorTheme() const; // 0x108774ac (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|Const)
    TArray<FName> GetAtomColorThemeLibraries(); // 0x108795ac (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    int32_t GetColorThemeIndex() const; // 0x10879644 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetThemeNames() const; // 0x1087a148 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool SetColorThemeByName(FName& Name); // 0x1087a86c (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    bool SetColorThemeByTexture(UTexture2D*& Texture); // 0x1087abe8 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAtomColorThemeComponent) == 0xe8, "Size mismatch for UAtomColorThemeComponent");
static_assert(offsetof(UAtomColorThemeComponent, ColorLUTAtlas) == 0xb8, "Offset mismatch for UAtomColorThemeComponent::ColorLUTAtlas");
static_assert(offsetof(UAtomColorThemeComponent, ColorLUTTexture) == 0xc0, "Offset mismatch for UAtomColorThemeComponent::ColorLUTTexture");
static_assert(offsetof(UAtomColorThemeComponent, bIsThemeCustomTexture) == 0xc8, "Offset mismatch for UAtomColorThemeComponent::bIsThemeCustomTexture");
static_assert(offsetof(UAtomColorThemeComponent, ColorThemeLibrary) == 0xcc, "Offset mismatch for UAtomColorThemeComponent::ColorThemeLibrary");
static_assert(offsetof(UAtomColorThemeComponent, ColorTheme) == 0xd0, "Offset mismatch for UAtomColorThemeComponent::ColorTheme");
static_assert(offsetof(UAtomColorThemeComponent, SelectedGeneratedLibraryTexture) == 0xd8, "Offset mismatch for UAtomColorThemeComponent::SelectedGeneratedLibraryTexture");
static_assert(offsetof(UAtomColorThemeComponent, SelectedColorThemeLibrary) == 0xe0, "Offset mismatch for UAtomColorThemeComponent::SelectedColorThemeLibrary");

// Size: 0x30 (Inherited: 0xb8, Single: 0xffffff78)
class UAtomDatabaseSubsystemBase : public UEngineSubsystem
{
public:
};

static_assert(sizeof(UAtomDatabaseSubsystemBase) == 0x30, "Size mismatch for UAtomDatabaseSubsystemBase");

// Size: 0x98 (Inherited: 0x28, Single: 0x70)
class UAtomLUCTAtlas : public UObject
{
public:
    TMap<FAtomLUCTRemappedColorTable, FName> Themes; // 0x28 (Size: 0x50, Type: MapProperty)
    TSoftObjectPtr<UTexture2D*> GeneratedAtlasTexture; // 0x78 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(UAtomLUCTAtlas) == 0x98, "Size mismatch for UAtomLUCTAtlas");
static_assert(offsetof(UAtomLUCTAtlas, Themes) == 0x28, "Offset mismatch for UAtomLUCTAtlas::Themes");
static_assert(offsetof(UAtomLUCTAtlas, GeneratedAtlasTexture) == 0x78, "Offset mismatch for UAtomLUCTAtlas::GeneratedAtlasTexture");

// Size: 0x2c0 (Inherited: 0x2d0, Single: 0xfffffff0)
class AAtomModelActor : public AActor
{
public:
    UAtomModel* AtomModel; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    FString PrimitiveStyleName; // 0x2b0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(AAtomModelActor) == 0x2c0, "Size mismatch for AAtomModelActor");
static_assert(offsetof(AAtomModelActor, AtomModel) == 0x2a8, "Offset mismatch for AAtomModelActor::AtomModel");
static_assert(offsetof(AAtomModelActor, PrimitiveStyleName) == 0x2b0, "Offset mismatch for AAtomModelActor::PrimitiveStyleName");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAtomModelActorConnectivityResolver : public UAtomActorConnectivityResolver
{
public:
};

static_assert(sizeof(UAtomModelActorConnectivityResolver) == 0x28, "Size mismatch for UAtomModelActorConnectivityResolver");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAtomPartsCollectionBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void AddPartInstance(FAtomModelPartsCollection& PartCollection, const FAtomModelPartInstanceInfo PartInstance); // 0x108772f8 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FString Conv_ModelPartGuidToString(const FAtomModelPartGuid InModelPartGuid); // 0x108777a0 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FAtomModelPartGuid Conv_StringToModelPartGuid(FString& InString); // 0x10877a38 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FAtomModelPartColorInfo CreateColorInfoFromColorId(int32_t& ColorId); // 0x10877d60 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAtomModelPartsCollectionConnectivity* CreatePartsCollectionConnectivity(const FAtomModelPartsCollection PartsCollection, UAtomModel*& const Model, float& Scale); // 0x10877ebc (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FAtomModelPartsCollection FilterCommonPartsToStyle(FAtomModelPartsCollection PartsCollection, FName& GeometryStyle); // 0x10878278 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FAtomModelPartsCollection FilterGroup(UAtomModel*& Model, const FAtomModelPartsCollection PartsCollectionToFilter, FString& GroupName, FString& NewPartsCollectionName); // 0x10878448 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FAtomModelPartsCollection FilterNonTransparent(const FAtomModelPartsCollection PartsCollectionToFilter, FString& NewPartsCollectionName); // 0x108787cc (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FAtomModelPartsCollection FilterSelectionSet(const FAtomModelPartsCollection PartsCollectionToFilter, FString& SelectionSetName, FString& NewPartsCollectionName); // 0x108789e8 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FAtomModelPartsCollection FilterTransparent(const FAtomModelPartsCollection PartsCollectionToFilter, FString& NewPartsCollectionName); // 0x10878ce8 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static int32_t GetModelPartGuidHash(const FAtomModelPartGuid InModelPartGuid); // 0x10879980 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FString GetName(const FAtomModelPartsCollection PartsCollection); // 0x10879a80 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static TArray<FAtomModelPartInstanceInfo> GetParts(const FAtomModelPartsCollection PartsCollection); // 0x10879c00 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static TArray<FAtomCommonPartAndTransform> GetPrimitiveCommonParts(UAtomPrimitive*& Primitive, double& Scale); // 0x10879d0c (Index: 0xd, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void InitializeCommonParts(UAtomModelPartsCollectionConnectivity*& PartsCollectionConnectivity, int32_t& CommonPartOptimizationFlags); // 0x1087a188 (Index: 0xe, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool PrimitiveHasConsistentCommonPartStyles(UAtomPrimitive*& Primitive); // 0x1087a388 (Index: 0xf, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void RemovePartInstance(FAtomModelPartsCollection& PartCollection, const FAtomModelPartGuid PartInstanceId); // 0x1087a4b0 (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ReplacePartInstance(FAtomModelPartsCollection& PartCollection, const FAtomModelPartInstanceInfo SourcePartInstance, const FAtomModelPartGuid TargetPartInstanceId); // 0x1087a63c (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetName(FAtomModelPartsCollection& PartsCollection, FString& Name); // 0x1087b294 (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAtomPartsCollectionBlueprintLibrary) == 0x28, "Size mismatch for UAtomPartsCollectionBlueprintLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAtomPlacementResultHelperLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void Break(const FAtomPlacementResult PlacementResult, FTransform& OutTransformDelta, TArray<TScriptInterface<Class>>& OutRejectionReasons); // 0x108774c0 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UAtomPlacementResultHelperLibrary) == 0x28, "Size mismatch for UAtomPlacementResultHelperLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAtomPrimitiveBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static float GetDefaultPrimitiveScale(); // 0x10879668 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UAtomPrimitiveBlueprintLibrary) == 0x28, "Size mismatch for UAtomPrimitiveBlueprintLibrary");

// Size: 0x2e8 (Inherited: 0x28, Single: 0x2c0)
class UAtomPrimitiveGeometry : public UObject
{
public:

public:
    UAtomPrimitiveGeometry* Append(UAtomPrimitiveGeometry*& const GeometryToAppend, const FTransform3f Transform); // 0x1087c448 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    UAtomPrimitiveGeometry* AppendAndWeld(UAtomPrimitiveGeometry*& const GeometryToAppend, const FTransform3f Transform); // 0x1087c678 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void AttachVerticesToBoneIndex(int32_t& BoneIndex); // 0x1087c8f0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void AttachVerticesToNamedBone(FString& BoneName); // 0x1087ca18 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    UAtomPrimitiveGeometry* BakeScale(float& Scale); // 0x1087cd28 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    UAtomPrimitiveGeometry* BakeTransform(const FTransform3f Transform); // 0x1087ce64 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    UAtomPrimitiveGeometry* BakeTransforms(const TArray<FTransform3f> Transforms); // 0x1087cf74 (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    UAtomPrimitiveGeometry* ConvertVertexColorsLinearToSRGB(); // 0x1087d208 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    UAtomPrimitiveGeometry* CopyNormalMapsToUV0(); // 0x1087d22c (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    static UAtomPrimitiveGeometry* CreateAtomGeometryFromCommonPart(FString& ExportStyleName, EAtomCommonPartType& CommonPartType, int32_t& LODIndex, FString& CommonPartsMeshPath); // 0x1087d250 (Index: 0x9, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAtomPrimitiveGeometry* CreateEmptyAtomGeometry(int32_t& NumberOfUVChannels); // 0x1087d83c (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable)
    UAtomPrimitiveGeometry* DuplicateGeometry() const; // 0x1087d964 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|Const)
    int32_t GetBoneIndexForName(FString& BoneName) const; // 0x1087ded8 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static bool GetCommonPartBestExportStyle(const TArray<FString> GeometryStylePriorityList, EAtomCommonPartType& CommonPartType, FString& OutGeometryStyle, FString& CommonPartsMeshPath); // 0x1087e6c4 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    TArray<FString> GetMaterialNames() const; // 0x1087ffb8 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static int32_t GetNumberOfCommonPartLODs(FString& ExportStyleName, EAtomCommonPartType& CommonPartType, FString& CommonPartsMeshPath); // 0x1087fff4 (Index: 0xf, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    UAtomPrimitiveGeometry* SetMaterialName(FString& Name, int32_t& PolygonGroupIndex); // 0x10881580 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    UAtomPrimitiveGeometry* SetTiledUVs(float& TileSize); // 0x10881964 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
    UAtomPrimitiveGeometry* SetVertexColor(const FColor Color); // 0x10881aa0 (Index: 0x12, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    TArray<UAtomPrimitiveGeometry*> SplitByPolygonGroup(bool& bIgnoreEmptyGroups) const; // 0x10881b7c (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UStaticMesh* ToSimplifiedStaticMesh(float& Scale, UObject*& Outer, FString& Name, bool& bFastBuild) const; // 0x10881d5c (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UAtomPrimitiveGeometry) == 0x2e8, "Size mismatch for UAtomPrimitiveGeometry");

// Size: 0x140 (Inherited: 0x28, Single: 0x118)
class UAtomPrimitiveGeometryContainer : public UObject
{
public:
    TSoftObjectPtr<UStaticMesh*> SourceMesh; // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    FName ExportStyleName; // 0x48 (Size: 0x4, Type: NameProperty)
    int32_t LOD; // 0x4c (Size: 0x4, Type: IntProperty)
    TMap<int32_t, FString> GeometryCount; // 0x50 (Size: 0x50, Type: MapProperty)
    TMap<FAtomPrimitiveGeometrySectionTextureInfos, FString> SectionTextureInfos; // 0xa0 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_f0[0x50]; // 0xf0 (Size: 0x50, Type: PaddingProperty)

public:
    TArray<FAtomPrimitiveGeometryAndTransform> GetCapsGeometry() const; // 0x1087e1e8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FAtomPrimitiveGeometryAndTransform> GetCollisionGeometry() const; // 0x1087e234 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FTransform> GetDefaultBoneTransforms(float& Scale) const; // 0x1087ed60 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FAtomPrimitiveGeometryAndTransform> GetDetailsGeometry() const; // 0x1087f060 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetExportStyleName() const; // 0x1087f0ac (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UAtomPrimitiveGeometry* GetGeometry(EPrimitiveGeometryComplexity& PrimitiveGeometryComplexity); // 0x1087f0f4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    UAtomPrimitiveGeometry* GetGeometrySection(int32_t& PrimitiveGeometrySectionFlag) const; // 0x1087f24c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UAtomPrimitiveGeometry* GetGeometrySectionWithMaterialNames(int32_t& PrimitiveGeometrySectionFlags, FString& ShellMaterial, FString& UndersideMaterial); // 0x1087f3a4 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    UAtomPrimitiveGeometry* GetGeometryWithMaterialNames(EPrimitiveGeometryComplexity& PrimitiveGeometryComplexity, FString& ShellMaterial, FString& UndersideMaterial); // 0x1087f900 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    int32_t GetLOD() const; // 0xa552a44 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FAtomPrimitiveGeometryAndTransform> GetOtherCapsGeometry() const; // 0x10880510 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FAtomPrimitiveGeometryAndTransform> GetPartsGeometry() const; // 0x1088055c (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FAtomPrimitiveGeometryAndTransform> GetScaledCapsGeometry(float& Scale) const; // 0x108805a8 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FAtomPrimitiveGeometryAndTransform> GetScaledCollisionGeometry(float& Scale) const; // 0x108806fc (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FAtomPrimitiveGeometryAndTransform> GetScaledDetailsGeometry(float& Scale) const; // 0x10880850 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UAtomPrimitiveGeometry* GetScaledGeometry(EPrimitiveGeometryComplexity& PrimitiveGeometryComplexity, float& Scale) const; // 0x108809a4 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FAtomPrimitiveGeometryAndTransform GetScaledShellGeometry(float& Scale) const; // 0x10880bc0 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetSectionTextureName(EPrimitiveGeometrySectionFlag& SectionType, EAtomPrimitiveDetailTextureType& TextureType, FString& OutTextureName) const; // 0x10880ed4 (Index: 0x11, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FAtomPrimitiveGeometryAndTransform GetShellGeometry() const; // 0x1088133c (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FAtomPrimitiveGeometryAndTransform> GetTechnicCapsGeometry() const; // 0x108813ac (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasCollisionGeometry() const; // 0x108813f8 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FAtomPrimitiveCollisionGeometry MakePrimitiveCollisionGeometry(float& Scale) const; // 0x1088141c (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UAtomPrimitiveGeometryContainer) == 0x140, "Size mismatch for UAtomPrimitiveGeometryContainer");
static_assert(offsetof(UAtomPrimitiveGeometryContainer, SourceMesh) == 0x28, "Offset mismatch for UAtomPrimitiveGeometryContainer::SourceMesh");
static_assert(offsetof(UAtomPrimitiveGeometryContainer, ExportStyleName) == 0x48, "Offset mismatch for UAtomPrimitiveGeometryContainer::ExportStyleName");
static_assert(offsetof(UAtomPrimitiveGeometryContainer, LOD) == 0x4c, "Offset mismatch for UAtomPrimitiveGeometryContainer::LOD");
static_assert(offsetof(UAtomPrimitiveGeometryContainer, GeometryCount) == 0x50, "Offset mismatch for UAtomPrimitiveGeometryContainer::GeometryCount");
static_assert(offsetof(UAtomPrimitiveGeometryContainer, SectionTextureInfos) == 0xa0, "Offset mismatch for UAtomPrimitiveGeometryContainer::SectionTextureInfos");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAtomRejectionReason : public UInterface
{
public:

public:
    virtual FString GetRejectionMessage() const; // 0x9f6d954 (Index: 0x0, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UAtomRejectionReason) == 0x28, "Size mismatch for UAtomRejectionReason");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UAtomConnectivityRejection : public UObject
{
public:
};

static_assert(sizeof(UAtomConnectivityRejection) == 0x30, "Size mismatch for UAtomConnectivityRejection");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UAtomCollisionRejection : public UObject
{
public:
};

static_assert(sizeof(UAtomCollisionRejection) == 0x30, "Size mismatch for UAtomCollisionRejection");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAtomRuntimeBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static TMap<FAtomColorInfo, int32_t> GetAllColorInfo(); // 0x1087d9a0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static int32_t GetBitPackForColor(const FColor Color); // 0x1087da68 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static int32_t GetBitPackForColorId(int32_t& AtomColorId); // 0x1087db44 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static float GetBitPackForLUTMaterial(int32_t& ColorId, const FGuid PrimitiveUUID, int32_t& VariantId); // 0x1087dc6c (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void GetCommonPartAssetDescriptionFromStaticMesh(UStaticMesh*& StaticMesh, FAtomCommonPartAssetDescription& OutDescription, EGetCommonPartDescriptionResult& OutIsValid); // 0x1087e294 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static EAtomCommonPartCategory GetCommonPartCategoryFromType(EAtomCommonPartType& CommonPartType); // 0x1087ea6c (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void GetCommonPartDescriptionFromType(EAtomCommonPartType& CommonPartType, FAtomCommonPartDescription& OutDescription); // 0x1087eb94 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FAtomColorInfo GetInfoForColorId(int32_t& ColorId); // 0x1087fe64 (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAtomRuntimeBlueprintLibrary) == 0x28, "Size mismatch for UAtomRuntimeBlueprintLibrary");

// Size: 0x60 (Inherited: 0x58, Single: 0x8)
class UAtomRuntimeSettings : public UDeveloperSettings
{
public:
    float PrimitiveGlobalScale; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UDataTable*> ColorDataTableOverride; // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    bool bEnableWorldConnectivity; // 0x58 (Size: 0x1, Type: BoolProperty)
    bool bCookContent; // 0x59 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5a[0x6]; // 0x5a (Size: 0x6, Type: PaddingProperty)

public:
    UDataTable* GetAtomEditorModeColorDataTable() const; // 0x1087da44 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDataTable* GetColorDataTable() const; // 0x1087e270 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UAtomRuntimeSettings) == 0x60, "Size mismatch for UAtomRuntimeSettings");
static_assert(offsetof(UAtomRuntimeSettings, PrimitiveGlobalScale) == 0x30, "Offset mismatch for UAtomRuntimeSettings::PrimitiveGlobalScale");
static_assert(offsetof(UAtomRuntimeSettings, ColorDataTableOverride) == 0x38, "Offset mismatch for UAtomRuntimeSettings::ColorDataTableOverride");
static_assert(offsetof(UAtomRuntimeSettings, bEnableWorldConnectivity) == 0x58, "Offset mismatch for UAtomRuntimeSettings::bEnableWorldConnectivity");
static_assert(offsetof(UAtomRuntimeSettings, bCookContent) == 0x59, "Offset mismatch for UAtomRuntimeSettings::bCookContent");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UConnectivityBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool AreActorsConnected(AActor*& const ActorA, AActor*& const ActorB, UConnectivityRegistration*& const ConnectivityRegistration); // 0x1088518c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UConnectivityBlueprintLibrary) == 0x28, "Size mismatch for UConnectivityBlueprintLibrary");

// Size: 0x178 (Inherited: 0x28, Single: 0x150)
class UConnectivityRegistration : public UObject
{
public:
};

static_assert(sizeof(UConnectivityRegistration) == 0x178, "Size mismatch for UConnectivityRegistration");

// Size: 0x600 (Inherited: 0xbe8, Single: 0xfffffa18)
class UDirectSnapPlacementTool : public UProximitySnapPlacementTool
{
public:

public:
    AActor* PickActorToDrag(const FRay CastRay); // 0x108878b8 (Index: 0x0, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UDirectSnapPlacementTool) == 0x600, "Size mismatch for UDirectSnapPlacementTool");

// Size: 0x5e0 (Inherited: 0x608, Single: 0xffffffd8)
class UProximitySnapPlacementTool : public UAtomPlacementToolBase
{
public:
};

static_assert(sizeof(UProximitySnapPlacementTool) == 0x5e0, "Size mismatch for UProximitySnapPlacementTool");

// Size: 0x5e0 (Inherited: 0x28, Single: 0x5b8)
class UAtomPlacementToolBase : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TWeakObjectPtr<UConnectivityRegistration*> ConnectivityRegistrationWeakPtr; // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    uint8_t PlacementContext[0x590]; // 0x40 (Size: 0x590, Type: OptionalProperty)
    uint8_t Pad_5d0[0x10]; // 0x5d0 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UAtomPlacementToolBase) == 0x5e0, "Size mismatch for UAtomPlacementToolBase");
static_assert(offsetof(UAtomPlacementToolBase, ConnectivityRegistrationWeakPtr) == 0x30, "Offset mismatch for UAtomPlacementToolBase::ConnectivityRegistrationWeakPtr");
static_assert(offsetof(UAtomPlacementToolBase, PlacementContext) == 0x40, "Offset mismatch for UAtomPlacementToolBase::PlacementContext");

// Size: 0x650 (Inherited: 0x608, Single: 0x48)
class UDragSnapPlacementTool : public UAtomPlacementToolBase
{
public:
};

static_assert(sizeof(UDragSnapPlacementTool) == 0x650, "Size mismatch for UDragSnapPlacementTool");

// Size: 0x70 (Inherited: 0x28, Single: 0x48)
class UPlacementSettings : public UObject
{
public:
    uint8_t Pad_28[0x18]; // 0x28 (Size: 0x18, Type: PaddingProperty)
    uint8_t SnapToolMode; // 0x40 (Size: 0x1, Type: EnumProperty)
    bool bClickToEndDrag; // 0x41 (Size: 0x1, Type: BoolProperty)
    bool bEnableEdgeSnapping; // 0x42 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_43[0x1]; // 0x43 (Size: 0x1, Type: PaddingProperty)
    uint32_t MaxSnappingDistanceInStudCount; // 0x44 (Size: 0x4, Type: UInt32Property)
    bool bSingleFieldPlacement; // 0x48 (Size: 0x1, Type: BoolProperty)
    bool bEnableCollisionDetection; // 0x49 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4a[0x6]; // 0x4a (Size: 0x6, Type: PaddingProperty)
    double LineTraceLength; // 0x50 (Size: 0x8, Type: DoubleProperty)
    FCollisionProfileName ConnectivityTraceProfileName; // 0x58 (Size: 0x4, Type: StructProperty)
    FCollisionProfileName RegistrationOverlapProfileName; // 0x5c (Size: 0x4, Type: StructProperty)
    bool bDrawDebugVisualization; // 0x60 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_61[0xf]; // 0x61 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(UPlacementSettings) == 0x70, "Size mismatch for UPlacementSettings");
static_assert(offsetof(UPlacementSettings, SnapToolMode) == 0x40, "Offset mismatch for UPlacementSettings::SnapToolMode");
static_assert(offsetof(UPlacementSettings, bClickToEndDrag) == 0x41, "Offset mismatch for UPlacementSettings::bClickToEndDrag");
static_assert(offsetof(UPlacementSettings, bEnableEdgeSnapping) == 0x42, "Offset mismatch for UPlacementSettings::bEnableEdgeSnapping");
static_assert(offsetof(UPlacementSettings, MaxSnappingDistanceInStudCount) == 0x44, "Offset mismatch for UPlacementSettings::MaxSnappingDistanceInStudCount");
static_assert(offsetof(UPlacementSettings, bSingleFieldPlacement) == 0x48, "Offset mismatch for UPlacementSettings::bSingleFieldPlacement");
static_assert(offsetof(UPlacementSettings, bEnableCollisionDetection) == 0x49, "Offset mismatch for UPlacementSettings::bEnableCollisionDetection");
static_assert(offsetof(UPlacementSettings, LineTraceLength) == 0x50, "Offset mismatch for UPlacementSettings::LineTraceLength");
static_assert(offsetof(UPlacementSettings, ConnectivityTraceProfileName) == 0x58, "Offset mismatch for UPlacementSettings::ConnectivityTraceProfileName");
static_assert(offsetof(UPlacementSettings, RegistrationOverlapProfileName) == 0x5c, "Offset mismatch for UPlacementSettings::RegistrationOverlapProfileName");
static_assert(offsetof(UPlacementSettings, bDrawDebugVisualization) == 0x60, "Offset mismatch for UPlacementSettings::bDrawDebugVisualization");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAtomPlacementTool : public UInterface
{
public:

public:
    bool BeginUpdatingPlacement(const TArray<AActor*> ActorsToUpdate, const FTransform StartPlacementTransform); // 0x10885460 (Index: 0x0, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void EndUpdatingPlacement(bool& bCancelled); // 0xce731cc (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    bool RegisterAndConnectActor(AActor*& const Actor); // 0x108879e8 (Index: 0x2, Flags: Native|Public|BlueprintCallable)
    bool UpdatePlacement(const FPlacementContextData ContextData); // 0x10889b94 (Index: 0x3, Flags: Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAtomPlacementTool) == 0x28, "Size mismatch for UAtomPlacementTool");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDragPlacement : public UInterface
{
public:

public:
    bool NudgeDraggedActors(const FIntPoint NudgeAmount, const FTransform ViewTransform); // 0x108875e8 (Index: 0x0, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    AActor* PickActorToDrag(const FRay CastRay); // 0x108877b0 (Index: 0x1, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void RotateDraggedActors(double& Degrees, const FTransform ViewTransform, TEnumAsByte<EAxis>& ViewAxis); // 0x1088840c (Index: 0x2, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UDragPlacement) == 0x28, "Size mismatch for UDragPlacement");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDirectPlacement : public UInterface
{
public:

public:
    bool TryDirectPlacement(const TArray<AActor*> Actors, const FTransform InStartTransform, const FVector SourceConnectionPointLocation, const FVector TargetConnectionPointLocation, bool& bEndPlacement); // 0x108894f0 (Index: 0x0, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UDirectPlacement) == 0x28, "Size mismatch for UDirectPlacement");

// Size: 0x38 (Inherited: 0x88, Single: 0xffffffb0)
class UWorldConnectivitySubsystem : public UWorldSubsystem
{
public:
    UConnectivityRegistration* ConnectivityRegistration; // 0x30 (Size: 0x8, Type: ObjectProperty)

public:
    void DisconnectAllObjectConnections(FWorldConnectivityHandle& Object); // 0x10885808 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void DisconnectObjects(FWorldConnectivityHandle& ObjectA, FWorldConnectivityHandle& ObjectB); // 0x108858d0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    AActor* GetActor(FWorldConnectivityHandle& Handle) const; // 0x10885c00 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UAtomModel* GetAtomModel(AActor*& const Actor) const; // 0x10885cd4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UAtomModelAssetUserData* GetAtomModelAssetUserData(UObject*& const Object) const; // 0x10885fd4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FPlanarFieldInfo GetClosestFieldToPoint(FWorldConnectivityHandle& Handle, const FVector WorldLocation, EConnectionFieldGender& Type, bool& bSuccess); // 0x10886104 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    TArray<FWorldConnectivityHandle> GetConnectedObjects(FWorldConnectivityHandle& Object); // 0x10886394 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FWorldConnectivityHandle> GetConnectedObjectsRecursively(FWorldConnectivityHandle& Object); // 0x10886480 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    FWorldConnectivityHandle GetConnectivityHandle(AActor*& const Actor) const; // 0x1088656c (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FWorldConnectivityHandle> GetConnectivityHandles(AActor*& const Actor) const; // 0x108866bc (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetOverlapPenetrationDepth(AStaticMeshActor*& Actor1, AStaticMeshActor*& Actor2, FVector& Offset); // 0x10886a3c (Index: 0xa, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    FVector GetPlanarFieldCenter(const FPlanarFieldInfo Field); // 0x10886fc4 (Index: 0xb, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    TArray<FPlanarFieldInfo> GetPlanarFields(FWorldConnectivityHandle& Handle, EConnectionFieldGender& Type); // 0x108870e4 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    FTransform GetTransform(FWorldConnectivityHandle& Handle) const; // 0x108874ec (Index: 0xd, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    double PlanarGridStepSize() const; // 0x108879c4 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool RegisterAtomActor(AActor*& const Actor); // 0x10887b24 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    bool RegisterConnectivityActor(AActor*& const Actor, UAtomModel*& const Model); // 0x10887c60 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    void RegisterCustomConnectivityActor(AActor*& const Actor, const FSerializedConnectivityObjects ConnectivityObject); // 0x10887e78 (Index: 0x11, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void RegisterModelActor(AActor*& const Actor, const FSerializedConnectivityObjects Connections); // 0x10887e78 (Index: 0x12, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    TArray<FConnectivityQueryResult> RunPlanarConnectivityQuery(AActor*& const AtomActorToPlace, AActor*& const AtomActorToConnect, const FVector QueryStartLocation, const FVector QueryEndLocation, TEnumAsByte<ECollisionChannel>& QueryCollisionChannel, int32_t& QueryRadius, bool& bPerformConnectionOnSuccess); // 0x108886d0 (Index: 0x13, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    bool TryConnectObjectAtLocation(FWorldConnectivityHandle& ObjectToConnect, const FTransform DesiredObjectTransform, const TArray<FWorldConnectivityHandle> ConnectionCandidates, bool& PerformConnection); // 0x10889080 (Index: 0x14, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void UnregisterConnectivityActor(AActor*& const Actor); // 0x10889a68 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UWorldConnectivitySubsystem) == 0x38, "Size mismatch for UWorldConnectivitySubsystem");
static_assert(offsetof(UWorldConnectivitySubsystem, ConnectivityRegistration) == 0x30, "Offset mismatch for UWorldConnectivitySubsystem::ConnectivityRegistration");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UWorldConnectivityBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static AActor* GetActor(UObject*& WorldContext, const FWorldConnectivityHandle Handle); // 0x10885a20 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FVector GetFieldCenter(UObject*& WorldContext, const FPlanarFieldInfo Field); // 0x1088680c (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FTransform GetTransform(UObject*& WorldContext, const FWorldConnectivityHandle Handle); // 0x108872c8 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool IsValid(const FWorldConnectivityHandle Handle); // 0xf76d6a4 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UWorldConnectivityBlueprintLibrary) == 0x28, "Size mismatch for UWorldConnectivityBlueprintLibrary");

// Size: 0xc8 (Inherited: 0xe0, Single: 0xffffffe8)
class UAtomColorComponent : public UActorComponent
{
public:
    UAtomColorLUTAtlas* ColorLUTAtlas; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* ColorLUTTexture; // 0xc0 (Size: 0x8, Type: ObjectProperty)

public:
    int32_t GetColorLUTIndex() const; // 0x108b3d7c (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetColorLUTAtlas(UAtomColorLUTAtlas*& InColorLUTAtlas); // 0x108b696c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void SetColorLUTTexture(UTexture2D*& InColorLUTTexture); // 0x108b6c4c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAtomColorComponent) == 0xc8, "Size mismatch for UAtomColorComponent");
static_assert(offsetof(UAtomColorComponent, ColorLUTAtlas) == 0xb8, "Offset mismatch for UAtomColorComponent::ColorLUTAtlas");
static_assert(offsetof(UAtomColorComponent, ColorLUTTexture) == 0xc0, "Offset mismatch for UAtomColorComponent::ColorLUTTexture");

// Size: 0x88 (Inherited: 0x28, Single: 0x60)
class UAtomColorThemeLibrary : public UObject
{
public:
    FString Description; // 0x28 (Size: 0x10, Type: StrProperty)
    char MinimumReservedSlotsForTextureBasedThemes; // 0x38 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
    TArray<FAtomColorTheme> ColorThemes; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UTexture2D*> GeneratedTexture; // 0x50 (Size: 0x20, Type: SoftObjectProperty)
    TArray<UTexture2D*> LUTTextures; // 0x70 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_80[0x8]; // 0x80 (Size: 0x8, Type: PaddingProperty)

public:
    int32_t GetAtlasDynamicTextureSize() const; // 0x108b3774 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetAtlasSize() const; // 0x108b3798 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumberOfStaticThemesRows() const; // 0x108b4e7c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsLUTTextureCompatible(UTexture2D*& LUTTexture) const; // 0x108b5ca4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|Const)
};

static_assert(sizeof(UAtomColorThemeLibrary) == 0x88, "Size mismatch for UAtomColorThemeLibrary");
static_assert(offsetof(UAtomColorThemeLibrary, Description) == 0x28, "Offset mismatch for UAtomColorThemeLibrary::Description");
static_assert(offsetof(UAtomColorThemeLibrary, MinimumReservedSlotsForTextureBasedThemes) == 0x38, "Offset mismatch for UAtomColorThemeLibrary::MinimumReservedSlotsForTextureBasedThemes");
static_assert(offsetof(UAtomColorThemeLibrary, ColorThemes) == 0x40, "Offset mismatch for UAtomColorThemeLibrary::ColorThemes");
static_assert(offsetof(UAtomColorThemeLibrary, GeneratedTexture) == 0x50, "Offset mismatch for UAtomColorThemeLibrary::GeneratedTexture");
static_assert(offsetof(UAtomColorThemeLibrary, LUTTextures) == 0x70, "Offset mismatch for UAtomColorThemeLibrary::LUTTextures");

// Size: 0x100 (Inherited: 0x28, Single: 0xd8)
class UAtomISMPoolRenderer : public UObject
{
public:
    uint8_t Pad_28[0x10]; // 0x28 (Size: 0x10, Type: PaddingProperty)
    UISMPoolComponent* CachedISMPoolComponent; // 0x38 (Size: 0x8, Type: ObjectProperty)
    UISMPoolComponent* LocalISMPoolComponent; // 0x40 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_48[0xb8]; // 0x48 (Size: 0xb8, Type: PaddingProperty)
};

static_assert(sizeof(UAtomISMPoolRenderer) == 0x100, "Size mismatch for UAtomISMPoolRenderer");
static_assert(offsetof(UAtomISMPoolRenderer, CachedISMPoolComponent) == 0x38, "Offset mismatch for UAtomISMPoolRenderer::CachedISMPoolComponent");
static_assert(offsetof(UAtomISMPoolRenderer, LocalISMPoolComponent) == 0x40, "Offset mismatch for UAtomISMPoolRenderer::LocalISMPoolComponent");

// Size: 0x298 (Inherited: 0x28, Single: 0x270)
class UAtomModel : public UObject
{
public:
    FAtomModelAssetSettings Settings; // 0x28 (Size: 0x28, Type: StructProperty)
    TArray<FAtomModelPrimitive> Primitives; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomHingedElement> Elements; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomModelSelectionSet> SelectionSets; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomModelConfigurationGroup> Groups; // 0x80 (Size: 0x10, Type: ArrayProperty)
    FSerializedConnectivityObjects SerializedConnectivityObjects; // 0x90 (Size: 0x40, Type: StructProperty)
    TMap<TSoftObjectPtr<UTexture*>, FString> TextureNameToAsset; // 0xd0 (Size: 0x50, Type: MapProperty)
    TMap<FString, FName> Attributes; // 0x120 (Size: 0x50, Type: MapProperty)
    TSet<FName> Tags; // 0x170 (Size: 0x50, Type: SetProperty)
    uint8_t Pad_1c0[0x50]; // 0x1c0 (Size: 0x50, Type: PaddingProperty)
    FAtomSourceModel SourceModel; // 0x210 (Size: 0x88, Type: StructProperty)

public:
    FString GetChildIdentifier(int32_t& InChildIdx); // 0x108b3a84 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    TArray<TSoftObjectPtr<UStaticMesh*>> GetGeneratedMergedMeshes() const; // 0x108b43c0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetModelName() const; // 0x108b4cd4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetModelPath() const; // 0x108b4d14 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FAtomModelPartsCollection GetPartsCollection() const; // 0x108b4e94 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetPrimitivesForChildArray(int32_t& InChildIdx, TArray<FAtomModelPrimitiveInstance>& OutPrimitives); // 0xeb582a8 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    FVector GetRootGroupPivot() const; // 0x108b4fec (Index: 0x6, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    UTexture* GetTextureForDecorationTextureName(FString& TextureName) const; // 0x108b5558 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UAtomModel) == 0x298, "Size mismatch for UAtomModel");
static_assert(offsetof(UAtomModel, Settings) == 0x28, "Offset mismatch for UAtomModel::Settings");
static_assert(offsetof(UAtomModel, Primitives) == 0x50, "Offset mismatch for UAtomModel::Primitives");
static_assert(offsetof(UAtomModel, Elements) == 0x60, "Offset mismatch for UAtomModel::Elements");
static_assert(offsetof(UAtomModel, SelectionSets) == 0x70, "Offset mismatch for UAtomModel::SelectionSets");
static_assert(offsetof(UAtomModel, Groups) == 0x80, "Offset mismatch for UAtomModel::Groups");
static_assert(offsetof(UAtomModel, SerializedConnectivityObjects) == 0x90, "Offset mismatch for UAtomModel::SerializedConnectivityObjects");
static_assert(offsetof(UAtomModel, TextureNameToAsset) == 0xd0, "Offset mismatch for UAtomModel::TextureNameToAsset");
static_assert(offsetof(UAtomModel, Attributes) == 0x120, "Offset mismatch for UAtomModel::Attributes");
static_assert(offsetof(UAtomModel, Tags) == 0x170, "Offset mismatch for UAtomModel::Tags");
static_assert(offsetof(UAtomModel, SourceModel) == 0x210, "Offset mismatch for UAtomModel::SourceModel");

// Size: 0x78 (Inherited: 0x50, Single: 0x28)
class UAtomConnectivityAssetUserData : public UAssetUserData
{
public:
    FSerializedConnectivityObjects AtomModelConnections; // 0x28 (Size: 0x40, Type: StructProperty)
    TArray<FName> Tags; // 0x68 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UAtomConnectivityAssetUserData) == 0x78, "Size mismatch for UAtomConnectivityAssetUserData");
static_assert(offsetof(UAtomConnectivityAssetUserData, AtomModelConnections) == 0x28, "Offset mismatch for UAtomConnectivityAssetUserData::AtomModelConnections");
static_assert(offsetof(UAtomConnectivityAssetUserData, Tags) == 0x68, "Offset mismatch for UAtomConnectivityAssetUserData::Tags");

// Size: 0x78 (Inherited: 0xc8, Single: 0xffffffb0)
class UAtomModelAssetUserData : public UAtomConnectivityAssetUserData
{
public:
};

static_assert(sizeof(UAtomModelAssetUserData) == 0x78, "Size mismatch for UAtomModelAssetUserData");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAtomEditorModePrimitiveUserData : public UAssetUserData
{
public:
};

static_assert(sizeof(UAtomEditorModePrimitiveUserData) == 0x28, "Size mismatch for UAtomEditorModePrimitiveUserData");

// Size: 0x78 (Inherited: 0xc8, Single: 0xffffffb0)
class UAtomPrimitiveAssetUserData : public UAtomConnectivityAssetUserData
{
public:
};

static_assert(sizeof(UAtomPrimitiveAssetUserData) == 0x78, "Size mismatch for UAtomPrimitiveAssetUserData");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UAtomCommonPartModelAssetUserData : public UAssetUserData
{
public:
    FAtomCommonPartAssetDescription AssetDescription; // 0x28 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UAtomCommonPartModelAssetUserData) == 0x38, "Size mismatch for UAtomCommonPartModelAssetUserData");
static_assert(offsetof(UAtomCommonPartModelAssetUserData, AssetDescription) == 0x28, "Offset mismatch for UAtomCommonPartModelAssetUserData::AssetDescription");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAtomAssetUserDataActorConnectivityResolver : public UAtomActorConnectivityResolver
{
public:
};

static_assert(sizeof(UAtomAssetUserDataActorConnectivityResolver) == 0x28, "Size mismatch for UAtomAssetUserDataActorConnectivityResolver");

// Size: 0x2c0 (Inherited: 0x320, Single: 0xffffffa0)
class UAtomModelComponent : public USceneComponent
{
public:
    UAtomModel* AtomModel; // 0x240 (Size: 0x8, Type: ObjectProperty)
    uint8_t InstanceType; // 0x248 (Size: 0x1, Type: EnumProperty)
    bool bUseCombinedMeshes; // 0x249 (Size: 0x1, Type: BoolProperty)
    uint8_t MaterialColorSource; // 0x24a (Size: 0x1, Type: EnumProperty)
    bool bCreateRigidElements; // 0x24b (Size: 0x1, Type: BoolProperty)
    bool bEnableConnectivity; // 0x24c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_24d[0x3]; // 0x24d (Size: 0x3, Type: PaddingProperty)
    FName SelectionSetFilter; // 0x250 (Size: 0x4, Type: NameProperty)
    char CommonPartOptimization; // 0x254 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_255[0x3]; // 0x255 (Size: 0x3, Type: PaddingProperty)
    TArray<USceneComponent*> RigidElementComponents; // 0x258 (Size: 0x10, Type: ArrayProperty)
    TMap<FModelPrimitiveEntry, FName> ComponentToPrimitive; // 0x268 (Size: 0x50, Type: MapProperty)
    uint8_t PrimitiveGeometryComplexity; // 0x2b8 (Size: 0x1, Type: EnumProperty)
    char PrimitiveGeometrySections; // 0x2b9 (Size: 0x1, Type: ByteProperty)
    bool bShowCommonParts; // 0x2ba (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2bb[0x5]; // 0x2bb (Size: 0x5, Type: PaddingProperty)

public:
    bool ModelSupportsMaterialInstancePayload() const; // 0x108b6900 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UAtomModelComponent) == 0x2c0, "Size mismatch for UAtomModelComponent");
static_assert(offsetof(UAtomModelComponent, AtomModel) == 0x240, "Offset mismatch for UAtomModelComponent::AtomModel");
static_assert(offsetof(UAtomModelComponent, InstanceType) == 0x248, "Offset mismatch for UAtomModelComponent::InstanceType");
static_assert(offsetof(UAtomModelComponent, bUseCombinedMeshes) == 0x249, "Offset mismatch for UAtomModelComponent::bUseCombinedMeshes");
static_assert(offsetof(UAtomModelComponent, MaterialColorSource) == 0x24a, "Offset mismatch for UAtomModelComponent::MaterialColorSource");
static_assert(offsetof(UAtomModelComponent, bCreateRigidElements) == 0x24b, "Offset mismatch for UAtomModelComponent::bCreateRigidElements");
static_assert(offsetof(UAtomModelComponent, bEnableConnectivity) == 0x24c, "Offset mismatch for UAtomModelComponent::bEnableConnectivity");
static_assert(offsetof(UAtomModelComponent, SelectionSetFilter) == 0x250, "Offset mismatch for UAtomModelComponent::SelectionSetFilter");
static_assert(offsetof(UAtomModelComponent, CommonPartOptimization) == 0x254, "Offset mismatch for UAtomModelComponent::CommonPartOptimization");
static_assert(offsetof(UAtomModelComponent, RigidElementComponents) == 0x258, "Offset mismatch for UAtomModelComponent::RigidElementComponents");
static_assert(offsetof(UAtomModelComponent, ComponentToPrimitive) == 0x268, "Offset mismatch for UAtomModelComponent::ComponentToPrimitive");
static_assert(offsetof(UAtomModelComponent, PrimitiveGeometryComplexity) == 0x2b8, "Offset mismatch for UAtomModelComponent::PrimitiveGeometryComplexity");
static_assert(offsetof(UAtomModelComponent, PrimitiveGeometrySections) == 0x2b9, "Offset mismatch for UAtomModelComponent::PrimitiveGeometrySections");
static_assert(offsetof(UAtomModelComponent, bShowCommonParts) == 0x2ba, "Offset mismatch for UAtomModelComponent::bShowCommonParts");

// Size: 0x640 (Inherited: 0x13b0, Single: 0xfffff290)
class UAtomPrimitiveComponent : public UStaticMeshComponent
{
public:
    UAtomPrimitive* AtomPrimitive; // 0x608 (Size: 0x8, Type: ObjectProperty)
    FString RenderStyle; // 0x610 (Size: 0x10, Type: StrProperty)
    FString FallbackRenderStyle; // 0x620 (Size: 0x10, Type: StrProperty)
    bool bUseCombinedMeshes; // 0x630 (Size: 0x1, Type: BoolProperty)
    bool bUseRenderStyle; // 0x631 (Size: 0x1, Type: BoolProperty)
    bool bUseFallbackRenderStyle; // 0x632 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_633[0xd]; // 0x633 (Size: 0xd, Type: PaddingProperty)
};

static_assert(sizeof(UAtomPrimitiveComponent) == 0x640, "Size mismatch for UAtomPrimitiveComponent");
static_assert(offsetof(UAtomPrimitiveComponent, AtomPrimitive) == 0x608, "Offset mismatch for UAtomPrimitiveComponent::AtomPrimitive");
static_assert(offsetof(UAtomPrimitiveComponent, RenderStyle) == 0x610, "Offset mismatch for UAtomPrimitiveComponent::RenderStyle");
static_assert(offsetof(UAtomPrimitiveComponent, FallbackRenderStyle) == 0x620, "Offset mismatch for UAtomPrimitiveComponent::FallbackRenderStyle");
static_assert(offsetof(UAtomPrimitiveComponent, bUseCombinedMeshes) == 0x630, "Offset mismatch for UAtomPrimitiveComponent::bUseCombinedMeshes");
static_assert(offsetof(UAtomPrimitiveComponent, bUseRenderStyle) == 0x631, "Offset mismatch for UAtomPrimitiveComponent::bUseRenderStyle");
static_assert(offsetof(UAtomPrimitiveComponent, bUseFallbackRenderStyle) == 0x632, "Offset mismatch for UAtomPrimitiveComponent::bUseFallbackRenderStyle");

// Size: 0xc0 (Inherited: 0x28, Single: 0x98)
class UAtomModelPartsCollectionConnectivity : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FAtomModelPartsCollection PartsCollection; // 0x30 (Size: 0x80, Type: StructProperty)
    uint8_t Pad_b0[0x10]; // 0xb0 (Size: 0x10, Type: PaddingProperty)

public:
    EFieldConnectResult GetTechnicHoleConnectivityState(const FAtomPartConnectivityFieldReference TechnicHolePartConnectivityRef, FAtomPartConnectivityFieldReference& ConnectedPartConnectivityRef); // 0x108b5168 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    TArray<EFieldConnectResult> GetTechnicPinConnectivityStates(const FAtomPartConnectivityFieldReference TechnicPinPartConnectivityRef, TArray<FAtomPartConnectivityFieldReference>& ConnectedPartsConnectivityRef); // 0x108b530c (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAtomModelPartsCollectionConnectivity) == 0xc0, "Size mismatch for UAtomModelPartsCollectionConnectivity");
static_assert(offsetof(UAtomModelPartsCollectionConnectivity, PartsCollection) == 0x30, "Offset mismatch for UAtomModelPartsCollectionConnectivity::PartsCollection");

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
class UAtomModelProcessor : public UObject
{
public:
    bool bEnableRebuildProgress; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    float DialogDelay; // 0x2c (Size: 0x4, Type: FloatProperty)
    int32_t NumProgressSteps; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    FString ProgressMessage; // 0x38 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_48[0x10]; // 0x48 (Size: 0x10, Type: PaddingProperty)

public:
    void IncrementProgress(int32_t& NumSteps, FString& Message); // 0x108b5854 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    virtual FString OnGetProcessModelTargetAssetPath(UAtomModel*& Model, const FAtomModelPartsCollection AtomModelPartsCollection); // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual FString OnGetProcessPrimitiveTargetAssetPath(UAtomModel*& Model, UAtomPrimitive*& Primitive, const FAtomModelPartsCollection AtomModelPartsCollection, const FAtomOnProcessPrimitiveSettings Settings); // 0x288a61c (Index: 0x2, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual FString OnGetTargetAssetPath(UAtomModel*& Model, UAtomPrimitive*& Primitive, const FAtomModelPartsCollection AtomModelPartsCollection); // 0x288a61c (Index: 0x3, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual FAtomProcessorResult OnProcessModel(UAtomModel*& Model, const FAtomModelPartsCollection AtomModelPartsCollection, const TArray<TSoftObjectPtr<UObject*>> ExistingObjects); // 0x288a61c (Index: 0x4, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual FAtomProcessorResult OnProcessPrimitive(UAtomModel*& DummyModel, UAtomPrimitive*& Primitive, const FAtomModelPartsCollection AtomModelPartsCollection, const FAtomOnProcessPrimitiveSettings Settings); // 0x288a61c (Index: 0x5, Flags: Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UAtomModelProcessor) == 0x58, "Size mismatch for UAtomModelProcessor");
static_assert(offsetof(UAtomModelProcessor, bEnableRebuildProgress) == 0x28, "Offset mismatch for UAtomModelProcessor::bEnableRebuildProgress");
static_assert(offsetof(UAtomModelProcessor, DialogDelay) == 0x2c, "Offset mismatch for UAtomModelProcessor::DialogDelay");
static_assert(offsetof(UAtomModelProcessor, NumProgressSteps) == 0x30, "Offset mismatch for UAtomModelProcessor::NumProgressSteps");
static_assert(offsetof(UAtomModelProcessor, ProgressMessage) == 0x38, "Offset mismatch for UAtomModelProcessor::ProgressMessage");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAtomProcessorBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FAtomProcessorResult AppendAtomProcessorResult(const FAtomProcessorResult Result, const FAtomProcessorResult ResultToAppend); // 0x108b32dc (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UAtomModelProcessor* GetModelProcessor(const FAtomModelProcessorInstance ProcessorInstance); // 0x108b4d54 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UClass* GetProcessorClass(const FAtomModelProcessorInstance ProcessorInstance); // 0x108b4ef8 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool IsValid(const FAtomModelProcessorInstance ProcessorInstance); // 0x108b5ddc (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetModelProcessor(FAtomModelProcessorInstance ProcessorInstance, UAtomModelProcessor*& ModelProcessor, bool& bUseCustomSettings); // 0x108b6f2c (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAtomProcessorBlueprintLibrary) == 0x28, "Size mismatch for UAtomProcessorBlueprintLibrary");

// Size: 0x270 (Inherited: 0x28, Single: 0x248)
class UAtomPrimitive : public UObject
{
public:
    int32_t PartId; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    FString PartRevision; // 0x30 (Size: 0x10, Type: StrProperty)
    FName DesignName; // 0x40 (Size: 0x4, Type: NameProperty)
    bool bIsFlex; // 0x44 (Size: 0x1, Type: BoolProperty)
    bool bIsVariant; // 0x45 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_46[0x2]; // 0x46 (Size: 0x2, Type: PaddingProperty)
    TArray<FString> DecorationSurfaceNames; // 0x48 (Size: 0x10, Type: ArrayProperty)
    int32_t NumberOfColorSurfaces; // 0x58 (Size: 0x4, Type: IntProperty)
    uint8_t AtomPlatform; // 0x5c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5d[0x3]; // 0x5d (Size: 0x3, Type: PaddingProperty)
    int32_t AtomMainGroupId; // 0x60 (Size: 0x4, Type: IntProperty)
    int32_t AtomSubMainGroupId; // 0x64 (Size: 0x4, Type: IntProperty)
    TMap<FAtomPrimitiveCommonPart, EAtomCommonPartType> PrimitiveCommonParts; // 0x68 (Size: 0x50, Type: MapProperty)
    bool bOverrideConnectionFields; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
    FBoxSphereBounds UnscaledBounds; // 0xc0 (Size: 0x38, Type: StructProperty)
    uint8_t Pad_f8[0x8]; // 0xf8 (Size: 0x8, Type: PaddingProperty)
    FAtomPrimitivePhysicsAttributes PhysicsAttributes; // 0x100 (Size: 0xa0, Type: StructProperty)
    TArray<UAtomPrimitiveGeometryContainer*> GeometryContainers; // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveDetailTextureData> DetailTextures; // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    FConnectionFieldContainer ConnectionFields; // 0x1c0 (Size: 0x30, Type: StructProperty)
    FConnectionFieldContainer ConnectionFieldsOverride; // 0x1f0 (Size: 0x30, Type: StructProperty)
    TMap<FTypedConnectivityFieldReference, FAtomPrimitiveTechnicCapReference> TechnicCapConnectivityRefs; // 0x220 (Size: 0x50, Type: MapProperty)

public:
    FBoxSphereBounds GetBounds(float& Scale) const; // 0x108b37bc (Index: 0x0, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector GetCenterOfMass(float& Scale) const; // 0x108b391c (Index: 0x1, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    int32_t GetDecorationSurfaceIndex(FString& SurfaceName) const; // 0x108b3da0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetExportStyleMaxLOD(FString& ExportStyle) const; // 0x108b409c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UAtomPrimitiveGeometryContainer* GetGeometryContainerForBestExportStyle(const TArray<FString> GeometryStylePriorityList, int32_t& LODIndex) const; // 0x108b4428 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UAtomPrimitiveGeometryContainer* GetGeometryContainerForExportStyle(FString& ExportStyleName, FString& FallbackExportStyleName, int32_t& LODIndex, bool& bUseFallbacks) const; // 0x108b4598 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static FName GetMainGroupName(int32_t& MainGroupId); // 0x108b4ba8 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FName GetSubMainGroupName(int32_t& SubMainGroupId); // 0x108b503c (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
    bool IsFlexElement() const; // 0xe5350e4 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UTexture* LoadDetailTextureForExportStyle(FString& ExportStyle, int32_t& LOD, EAtomPrimitiveDetailTextureType& TextureType) const; // 0x108b5ec0 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UTexture* LoadDetailTextureForExportStyleAndSection(FString& ExportStyle, int32_t& LOD, EAtomPrimitiveDetailTextureType& TextureType, EPrimitiveGeometrySectionFlag& Section) const; // 0x108b6370 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UAtomPrimitive) == 0x270, "Size mismatch for UAtomPrimitive");
static_assert(offsetof(UAtomPrimitive, PartId) == 0x28, "Offset mismatch for UAtomPrimitive::PartId");
static_assert(offsetof(UAtomPrimitive, PartRevision) == 0x30, "Offset mismatch for UAtomPrimitive::PartRevision");
static_assert(offsetof(UAtomPrimitive, DesignName) == 0x40, "Offset mismatch for UAtomPrimitive::DesignName");
static_assert(offsetof(UAtomPrimitive, bIsFlex) == 0x44, "Offset mismatch for UAtomPrimitive::bIsFlex");
static_assert(offsetof(UAtomPrimitive, bIsVariant) == 0x45, "Offset mismatch for UAtomPrimitive::bIsVariant");
static_assert(offsetof(UAtomPrimitive, DecorationSurfaceNames) == 0x48, "Offset mismatch for UAtomPrimitive::DecorationSurfaceNames");
static_assert(offsetof(UAtomPrimitive, NumberOfColorSurfaces) == 0x58, "Offset mismatch for UAtomPrimitive::NumberOfColorSurfaces");
static_assert(offsetof(UAtomPrimitive, AtomPlatform) == 0x5c, "Offset mismatch for UAtomPrimitive::AtomPlatform");
static_assert(offsetof(UAtomPrimitive, AtomMainGroupId) == 0x60, "Offset mismatch for UAtomPrimitive::AtomMainGroupId");
static_assert(offsetof(UAtomPrimitive, AtomSubMainGroupId) == 0x64, "Offset mismatch for UAtomPrimitive::AtomSubMainGroupId");
static_assert(offsetof(UAtomPrimitive, PrimitiveCommonParts) == 0x68, "Offset mismatch for UAtomPrimitive::PrimitiveCommonParts");
static_assert(offsetof(UAtomPrimitive, bOverrideConnectionFields) == 0xb8, "Offset mismatch for UAtomPrimitive::bOverrideConnectionFields");
static_assert(offsetof(UAtomPrimitive, UnscaledBounds) == 0xc0, "Offset mismatch for UAtomPrimitive::UnscaledBounds");
static_assert(offsetof(UAtomPrimitive, PhysicsAttributes) == 0x100, "Offset mismatch for UAtomPrimitive::PhysicsAttributes");
static_assert(offsetof(UAtomPrimitive, GeometryContainers) == 0x1a0, "Offset mismatch for UAtomPrimitive::GeometryContainers");
static_assert(offsetof(UAtomPrimitive, DetailTextures) == 0x1b0, "Offset mismatch for UAtomPrimitive::DetailTextures");
static_assert(offsetof(UAtomPrimitive, ConnectionFields) == 0x1c0, "Offset mismatch for UAtomPrimitive::ConnectionFields");
static_assert(offsetof(UAtomPrimitive, ConnectionFieldsOverride) == 0x1f0, "Offset mismatch for UAtomPrimitive::ConnectionFieldsOverride");
static_assert(offsetof(UAtomPrimitive, TechnicCapConnectivityRefs) == 0x220, "Offset mismatch for UAtomPrimitive::TechnicCapConnectivityRefs");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FAtomColorInfo : FTableRowBase
{
    FColor Color; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t MaterialType; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FString Name; // 0x10 (Size: 0x10, Type: StrProperty)
    bool bIsActive; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAtomColorInfo) == 0x28, "Size mismatch for FAtomColorInfo");
static_assert(offsetof(FAtomColorInfo, Color) == 0x8, "Offset mismatch for FAtomColorInfo::Color");
static_assert(offsetof(FAtomColorInfo, MaterialType) == 0xc, "Offset mismatch for FAtomColorInfo::MaterialType");
static_assert(offsetof(FAtomColorInfo, Name) == 0x10, "Offset mismatch for FAtomColorInfo::Name");
static_assert(offsetof(FAtomColorInfo, bIsActive) == 0x20, "Offset mismatch for FAtomColorInfo::bIsActive");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FAtomColorProperty
{
    int32_t AtomColorValue; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FAtomColorProperty) == 0x4, "Size mismatch for FAtomColorProperty");
static_assert(offsetof(FAtomColorProperty, AtomColorValue) == 0x0, "Offset mismatch for FAtomColorProperty::AtomColorValue");

// Size: 0x390 (Inherited: 0x0, Single: 0x390)
struct FAtomConnectionProxy
{
    TArray<TScriptInterface<Class>> RejectionReasons; // 0x380 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomConnectionProxy) == 0x390, "Size mismatch for FAtomConnectionProxy");
static_assert(offsetof(FAtomConnectionProxy, RejectionReasons) == 0x380, "Offset mismatch for FAtomConnectionProxy::RejectionReasons");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FAtomLUCTRemappedColorEntry
{
    FAtomColorProperty SourceColor; // 0x0 (Size: 0x4, Type: StructProperty)
    FAtomColorProperty RemappedColor; // 0x4 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FAtomLUCTRemappedColorEntry) == 0x8, "Size mismatch for FAtomLUCTRemappedColorEntry");
static_assert(offsetof(FAtomLUCTRemappedColorEntry, SourceColor) == 0x0, "Offset mismatch for FAtomLUCTRemappedColorEntry::SourceColor");
static_assert(offsetof(FAtomLUCTRemappedColorEntry, RemappedColor) == 0x4, "Offset mismatch for FAtomLUCTRemappedColorEntry::RemappedColor");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAtomLUCTRemappedColorTable
{
    TArray<FAtomLUCTRemappedColorEntry> Entries; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomLUCTRemappedColorTable) == 0x10, "Size mismatch for FAtomLUCTRemappedColorTable");
static_assert(offsetof(FAtomLUCTRemappedColorTable, Entries) == 0x0, "Offset mismatch for FAtomLUCTRemappedColorTable::Entries");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAtomMaterialOverride
{
    UMaterialInterface* Material; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bManualColorSource; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAtomMaterialOverride) == 0x10, "Size mismatch for FAtomMaterialOverride");
static_assert(offsetof(FAtomMaterialOverride, Material) == 0x0, "Offset mismatch for FAtomMaterialOverride::Material");
static_assert(offsetof(FAtomMaterialOverride, bManualColorSource) == 0x8, "Offset mismatch for FAtomMaterialOverride::bManualColorSource");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FAtomMaterialFeatures
{
    uint8_t MaterialType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TMap<UTexture*, int32_t> UDIMDecorationMap; // 0x8 (Size: 0x50, Type: MapProperty)
    UTexture* NormalMap; // 0x58 (Size: 0x8, Type: ObjectProperty)
    UTexture* AlphaMask; // 0x60 (Size: 0x8, Type: ObjectProperty)
    UTexture* TechnicNormalMap; // 0x68 (Size: 0x8, Type: ObjectProperty)
    UTexture* TechnicMasks; // 0x70 (Size: 0x8, Type: ObjectProperty)
    UTexture* LookUpTableAtlasTexture; // 0x78 (Size: 0x8, Type: ObjectProperty)
    uint8_t ColorSource; // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_81[0x3]; // 0x81 (Size: 0x3, Type: PaddingProperty)
    int32_t ColorId; // 0x84 (Size: 0x4, Type: IntProperty)
    uint8_t UVFeature; // 0x88 (Size: 0x1, Type: EnumProperty)
    uint8_t TranslucencyType; // 0x89 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_8a[0x6]; // 0x8a (Size: 0x6, Type: PaddingProperty)
    FAtomMaterialOverride MaterialOverride; // 0x90 (Size: 0x10, Type: StructProperty)
    TArray<FInstancedStruct> AdditionalFeatures; // 0xa0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomMaterialFeatures) == 0xb0, "Size mismatch for FAtomMaterialFeatures");
static_assert(offsetof(FAtomMaterialFeatures, MaterialType) == 0x0, "Offset mismatch for FAtomMaterialFeatures::MaterialType");
static_assert(offsetof(FAtomMaterialFeatures, UDIMDecorationMap) == 0x8, "Offset mismatch for FAtomMaterialFeatures::UDIMDecorationMap");
static_assert(offsetof(FAtomMaterialFeatures, NormalMap) == 0x58, "Offset mismatch for FAtomMaterialFeatures::NormalMap");
static_assert(offsetof(FAtomMaterialFeatures, AlphaMask) == 0x60, "Offset mismatch for FAtomMaterialFeatures::AlphaMask");
static_assert(offsetof(FAtomMaterialFeatures, TechnicNormalMap) == 0x68, "Offset mismatch for FAtomMaterialFeatures::TechnicNormalMap");
static_assert(offsetof(FAtomMaterialFeatures, TechnicMasks) == 0x70, "Offset mismatch for FAtomMaterialFeatures::TechnicMasks");
static_assert(offsetof(FAtomMaterialFeatures, LookUpTableAtlasTexture) == 0x78, "Offset mismatch for FAtomMaterialFeatures::LookUpTableAtlasTexture");
static_assert(offsetof(FAtomMaterialFeatures, ColorSource) == 0x80, "Offset mismatch for FAtomMaterialFeatures::ColorSource");
static_assert(offsetof(FAtomMaterialFeatures, ColorId) == 0x84, "Offset mismatch for FAtomMaterialFeatures::ColorId");
static_assert(offsetof(FAtomMaterialFeatures, UVFeature) == 0x88, "Offset mismatch for FAtomMaterialFeatures::UVFeature");
static_assert(offsetof(FAtomMaterialFeatures, TranslucencyType) == 0x89, "Offset mismatch for FAtomMaterialFeatures::TranslucencyType");
static_assert(offsetof(FAtomMaterialFeatures, MaterialOverride) == 0x90, "Offset mismatch for FAtomMaterialFeatures::MaterialOverride");
static_assert(offsetof(FAtomMaterialFeatures, AdditionalFeatures) == 0xa0, "Offset mismatch for FAtomMaterialFeatures::AdditionalFeatures");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FAtomMergedMeshLODDistanceSettings
{
    bool bOverrideLODScreenSizes; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float BaseLODScreenSize; // 0x4 (Size: 0x4, Type: FloatProperty)
    float BaseLODScreenSizeScaling; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    TArray<float> LODDistances; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomMergedMeshLODDistanceSettings) == 0x20, "Size mismatch for FAtomMergedMeshLODDistanceSettings");
static_assert(offsetof(FAtomMergedMeshLODDistanceSettings, bOverrideLODScreenSizes) == 0x0, "Offset mismatch for FAtomMergedMeshLODDistanceSettings::bOverrideLODScreenSizes");
static_assert(offsetof(FAtomMergedMeshLODDistanceSettings, BaseLODScreenSize) == 0x4, "Offset mismatch for FAtomMergedMeshLODDistanceSettings::BaseLODScreenSize");
static_assert(offsetof(FAtomMergedMeshLODDistanceSettings, BaseLODScreenSizeScaling) == 0x8, "Offset mismatch for FAtomMergedMeshLODDistanceSettings::BaseLODScreenSizeScaling");
static_assert(offsetof(FAtomMergedMeshLODDistanceSettings, LODDistances) == 0x10, "Offset mismatch for FAtomMergedMeshLODDistanceSettings::LODDistances");

// Size: 0x3f0 (Inherited: 0x0, Single: 0x3f0)
struct FAtomPlacementResult
{
    FAtomConnectionProxy ConnectionProxy; // 0x60 (Size: 0x390, Type: StructProperty)
};

static_assert(sizeof(FAtomPlacementResult) == 0x3f0, "Size mismatch for FAtomPlacementResult");
static_assert(offsetof(FAtomPlacementResult, ConnectionProxy) == 0x60, "Offset mismatch for FAtomPlacementResult::ConnectionProxy");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FAtomPrimitiveCollisionVolumeBase
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    uint16_t BoneIndex; // 0x18 (Size: 0x2, Type: UInt16Property)
    uint8_t Pad_1a[0x6]; // 0x1a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FAtomPrimitiveCollisionVolumeBase) == 0x20, "Size mismatch for FAtomPrimitiveCollisionVolumeBase");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeBase, Location) == 0x0, "Offset mismatch for FAtomPrimitiveCollisionVolumeBase::Location");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeBase, BoneIndex) == 0x18, "Offset mismatch for FAtomPrimitiveCollisionVolumeBase::BoneIndex");

// Size: 0x50 (Inherited: 0x20, Single: 0x30)
struct FAtomPrimitiveCollisionVolumeBox : FAtomPrimitiveCollisionVolumeBase
{
    FRotator Rotation; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector HalfExtent; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FAtomPrimitiveCollisionVolumeBox) == 0x50, "Size mismatch for FAtomPrimitiveCollisionVolumeBox");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeBox, Rotation) == 0x20, "Offset mismatch for FAtomPrimitiveCollisionVolumeBox::Rotation");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeBox, HalfExtent) == 0x38, "Offset mismatch for FAtomPrimitiveCollisionVolumeBox::HalfExtent");

// Size: 0x40 (Inherited: 0x20, Single: 0x20)
struct FAtomPrimitiveCollisionVolumeCapsule : FAtomPrimitiveCollisionVolumeBase
{
    FRotator Rotation; // 0x20 (Size: 0x18, Type: StructProperty)
    float Radius; // 0x38 (Size: 0x4, Type: FloatProperty)
    float HalfLength; // 0x3c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FAtomPrimitiveCollisionVolumeCapsule) == 0x40, "Size mismatch for FAtomPrimitiveCollisionVolumeCapsule");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeCapsule, Rotation) == 0x20, "Offset mismatch for FAtomPrimitiveCollisionVolumeCapsule::Rotation");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeCapsule, Radius) == 0x38, "Offset mismatch for FAtomPrimitiveCollisionVolumeCapsule::Radius");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeCapsule, HalfLength) == 0x3c, "Offset mismatch for FAtomPrimitiveCollisionVolumeCapsule::HalfLength");

// Size: 0x40 (Inherited: 0x20, Single: 0x20)
struct FAtomPrimitiveCollisionVolumeCylinder : FAtomPrimitiveCollisionVolumeBase
{
    FRotator Rotation; // 0x20 (Size: 0x18, Type: StructProperty)
    float Radius; // 0x38 (Size: 0x4, Type: FloatProperty)
    float HalfLength; // 0x3c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FAtomPrimitiveCollisionVolumeCylinder) == 0x40, "Size mismatch for FAtomPrimitiveCollisionVolumeCylinder");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeCylinder, Rotation) == 0x20, "Offset mismatch for FAtomPrimitiveCollisionVolumeCylinder::Rotation");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeCylinder, Radius) == 0x38, "Offset mismatch for FAtomPrimitiveCollisionVolumeCylinder::Radius");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeCylinder, HalfLength) == 0x3c, "Offset mismatch for FAtomPrimitiveCollisionVolumeCylinder::HalfLength");

// Size: 0x48 (Inherited: 0x20, Single: 0x28)
struct FAtomPrimitiveCollisionVolumeTube : FAtomPrimitiveCollisionVolumeBase
{
    FRotator Rotation; // 0x20 (Size: 0x18, Type: StructProperty)
    float InnerRadius; // 0x38 (Size: 0x4, Type: FloatProperty)
    float OuterRadius; // 0x3c (Size: 0x4, Type: FloatProperty)
    float HalfLength; // 0x40 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAtomPrimitiveCollisionVolumeTube) == 0x48, "Size mismatch for FAtomPrimitiveCollisionVolumeTube");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeTube, Rotation) == 0x20, "Offset mismatch for FAtomPrimitiveCollisionVolumeTube::Rotation");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeTube, InnerRadius) == 0x38, "Offset mismatch for FAtomPrimitiveCollisionVolumeTube::InnerRadius");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeTube, OuterRadius) == 0x3c, "Offset mismatch for FAtomPrimitiveCollisionVolumeTube::OuterRadius");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeTube, HalfLength) == 0x40, "Offset mismatch for FAtomPrimitiveCollisionVolumeTube::HalfLength");

// Size: 0x28 (Inherited: 0x20, Single: 0x8)
struct FAtomPrimitiveCollisionVolumeSphere : FAtomPrimitiveCollisionVolumeBase
{
    float Radius; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAtomPrimitiveCollisionVolumeSphere) == 0x28, "Size mismatch for FAtomPrimitiveCollisionVolumeSphere");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeSphere, Radius) == 0x20, "Offset mismatch for FAtomPrimitiveCollisionVolumeSphere::Radius");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FAtomPrimitiveCollisionVolumeContainer
{
    TArray<FAtomPrimitiveCollisionVolumeBox> Boxes; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveCollisionVolumeSphere> Spheres; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveCollisionVolumeCapsule> Capsules; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveCollisionVolumeCylinder> Cylinders; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveCollisionVolumeTube> Tubes; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomPrimitiveCollisionVolumeContainer) == 0x50, "Size mismatch for FAtomPrimitiveCollisionVolumeContainer");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeContainer, Boxes) == 0x0, "Offset mismatch for FAtomPrimitiveCollisionVolumeContainer::Boxes");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeContainer, Spheres) == 0x10, "Offset mismatch for FAtomPrimitiveCollisionVolumeContainer::Spheres");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeContainer, Capsules) == 0x20, "Offset mismatch for FAtomPrimitiveCollisionVolumeContainer::Capsules");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeContainer, Cylinders) == 0x30, "Offset mismatch for FAtomPrimitiveCollisionVolumeContainer::Cylinders");
static_assert(offsetof(FAtomPrimitiveCollisionVolumeContainer, Tubes) == 0x40, "Offset mismatch for FAtomPrimitiveCollisionVolumeContainer::Tubes");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FAtomPrimitiveCollisionGeometry
{
    FKAggregateGeom AggGeom; // 0x0 (Size: 0xa0, Type: StructProperty)
};

static_assert(sizeof(FAtomPrimitiveCollisionGeometry) == 0xa0, "Size mismatch for FAtomPrimitiveCollisionGeometry");
static_assert(offsetof(FAtomPrimitiveCollisionGeometry, AggGeom) == 0x0, "Offset mismatch for FAtomPrimitiveCollisionGeometry::AggGeom");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FAtomPrimitiveGeometryMaterialAssignments
{
    TArray<FString> MaterialSlotName; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomMaterialFeatures> MaterialFeatures; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomPrimitiveGeometryMaterialAssignments) == 0x20, "Size mismatch for FAtomPrimitiveGeometryMaterialAssignments");
static_assert(offsetof(FAtomPrimitiveGeometryMaterialAssignments, MaterialSlotName) == 0x0, "Offset mismatch for FAtomPrimitiveGeometryMaterialAssignments::MaterialSlotName");
static_assert(offsetof(FAtomPrimitiveGeometryMaterialAssignments, MaterialFeatures) == 0x10, "Offset mismatch for FAtomPrimitiveGeometryMaterialAssignments::MaterialFeatures");

// Size: 0xe8 (Inherited: 0x0, Single: 0xe8)
struct FAtomPrimitiveGeometryLODs
{
    TArray<UAtomPrimitiveGeometry*> GeometryLODs; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveGeometryMaterialAssignments> GeometryLODsMaterials; // 0x10 (Size: 0x10, Type: ArrayProperty)
    UAtomPrimitiveGeometry* HiResNaniteGeomery; // 0x20 (Size: 0x8, Type: ObjectProperty)
    FAtomPrimitiveGeometryMaterialAssignments HiResNaniteGeomeryMaterials; // 0x28 (Size: 0x20, Type: StructProperty)
    FAtomPrimitiveCollisionGeometry Collision; // 0x48 (Size: 0xa0, Type: StructProperty)
};

static_assert(sizeof(FAtomPrimitiveGeometryLODs) == 0xe8, "Size mismatch for FAtomPrimitiveGeometryLODs");
static_assert(offsetof(FAtomPrimitiveGeometryLODs, GeometryLODs) == 0x0, "Offset mismatch for FAtomPrimitiveGeometryLODs::GeometryLODs");
static_assert(offsetof(FAtomPrimitiveGeometryLODs, GeometryLODsMaterials) == 0x10, "Offset mismatch for FAtomPrimitiveGeometryLODs::GeometryLODsMaterials");
static_assert(offsetof(FAtomPrimitiveGeometryLODs, HiResNaniteGeomery) == 0x20, "Offset mismatch for FAtomPrimitiveGeometryLODs::HiResNaniteGeomery");
static_assert(offsetof(FAtomPrimitiveGeometryLODs, HiResNaniteGeomeryMaterials) == 0x28, "Offset mismatch for FAtomPrimitiveGeometryLODs::HiResNaniteGeomeryMaterials");
static_assert(offsetof(FAtomPrimitiveGeometryLODs, Collision) == 0x48, "Offset mismatch for FAtomPrimitiveGeometryLODs::Collision");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FAtomPrimitiveGeometryAndTransform
{
    UAtomPrimitiveGeometry* AtomPrimitiveGeometry; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform3f Transform; // 0x10 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FAtomPrimitiveGeometryAndTransform) == 0x40, "Size mismatch for FAtomPrimitiveGeometryAndTransform");
static_assert(offsetof(FAtomPrimitiveGeometryAndTransform, AtomPrimitiveGeometry) == 0x0, "Offset mismatch for FAtomPrimitiveGeometryAndTransform::AtomPrimitiveGeometry");
static_assert(offsetof(FAtomPrimitiveGeometryAndTransform, Transform) == 0x10, "Offset mismatch for FAtomPrimitiveGeometryAndTransform::Transform");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FAtomPrimitiveGeometrySectionTextureInfos
{
    TMap<FString, EAtomPrimitiveDetailTextureType> TextureInfos; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FAtomPrimitiveGeometrySectionTextureInfos) == 0x50, "Size mismatch for FAtomPrimitiveGeometrySectionTextureInfos");
static_assert(offsetof(FAtomPrimitiveGeometrySectionTextureInfos, TextureInfos) == 0x0, "Offset mismatch for FAtomPrimitiveGeometrySectionTextureInfos::TextureInfos");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FConnectionField
{
    FQuat Rotation; // 0x0 (Size: 0x20, Type: StructProperty)
    FVector Location; // 0x20 (Size: 0x18, Type: StructProperty)
    uint32_t Subtype; // 0x38 (Size: 0x4, Type: UInt32Property)
    uint16_t BoneIndex; // 0x3c (Size: 0x2, Type: UInt16Property)
    uint8_t Type; // 0x3e (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3f[0x1]; // 0x3f (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(FConnectionField) == 0x40, "Size mismatch for FConnectionField");
static_assert(offsetof(FConnectionField, Rotation) == 0x0, "Offset mismatch for FConnectionField::Rotation");
static_assert(offsetof(FConnectionField, Location) == 0x20, "Offset mismatch for FConnectionField::Location");
static_assert(offsetof(FConnectionField, Subtype) == 0x38, "Offset mismatch for FConnectionField::Subtype");
static_assert(offsetof(FConnectionField, BoneIndex) == 0x3c, "Offset mismatch for FConnectionField::BoneIndex");
static_assert(offsetof(FConnectionField, Type) == 0x3e, "Offset mismatch for FConnectionField::Type");

// Size: 0x50 (Inherited: 0x40, Single: 0x10)
struct FConnectionFieldLine : FConnectionField
{
    double Length; // 0x40 (Size: 0x8, Type: DoubleProperty)
    bool StartCapped; // 0x48 (Size: 0x1, Type: BoolProperty)
    bool EndCapped; // 0x49 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4a[0x6]; // 0x4a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FConnectionFieldLine) == 0x50, "Size mismatch for FConnectionFieldLine");
static_assert(offsetof(FConnectionFieldLine, Length) == 0x40, "Offset mismatch for FConnectionFieldLine::Length");
static_assert(offsetof(FConnectionFieldLine, StartCapped) == 0x48, "Offset mismatch for FConnectionFieldLine::StartCapped");
static_assert(offsetof(FConnectionFieldLine, EndCapped) == 0x49, "Offset mismatch for FConnectionFieldLine::EndCapped");

// Size: 0x60 (Inherited: 0x90, Single: 0xffffffd0)
struct FConnectionFieldAxle : FConnectionFieldLine
{
    bool Grabbing; // 0x50 (Size: 0x1, Type: BoolProperty)
    bool RequireGrabbing; // 0x51 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_52[0x2]; // 0x52 (Size: 0x2, Type: PaddingProperty)
    float DiscreteSnapInterval; // 0x54 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FConnectionFieldAxle) == 0x60, "Size mismatch for FConnectionFieldAxle");
static_assert(offsetof(FConnectionFieldAxle, Grabbing) == 0x50, "Offset mismatch for FConnectionFieldAxle::Grabbing");
static_assert(offsetof(FConnectionFieldAxle, RequireGrabbing) == 0x51, "Offset mismatch for FConnectionFieldAxle::RequireGrabbing");
static_assert(offsetof(FConnectionFieldAxle, DiscreteSnapInterval) == 0x54, "Offset mismatch for FConnectionFieldAxle::DiscreteSnapInterval");

// Size: 0x40 (Inherited: 0x40, Single: 0x0)
struct FConnectionFieldPoint : FConnectionField
{
};

static_assert(sizeof(FConnectionFieldPoint) == 0x40, "Size mismatch for FConnectionFieldPoint");

// Size: 0x40 (Inherited: 0x80, Single: 0xffffffc0)
struct FConnectionFieldBall : FConnectionFieldPoint
{
};

static_assert(sizeof(FConnectionFieldBall) == 0x40, "Size mismatch for FConnectionFieldBall");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FConnectionFieldContainer
{
    TArray<FConnectionFieldPlanar> PlanarFields; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> LineFields; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> PointFields; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FConnectionFieldContainer) == 0x30, "Size mismatch for FConnectionFieldContainer");
static_assert(offsetof(FConnectionFieldContainer, PlanarFields) == 0x0, "Offset mismatch for FConnectionFieldContainer::PlanarFields");
static_assert(offsetof(FConnectionFieldContainer, LineFields) == 0x10, "Offset mismatch for FConnectionFieldContainer::LineFields");
static_assert(offsetof(FConnectionFieldContainer, PointFields) == 0x20, "Offset mismatch for FConnectionFieldContainer::PointFields");

// Size: 0x60 (Inherited: 0x40, Single: 0x20)
struct FConnectionFieldPlanar : FConnectionField
{
    char Width; // 0x40 (Size: 0x1, Type: ByteProperty)
    char Height; // 0x41 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_42[0x6]; // 0x42 (Size: 0x6, Type: PaddingProperty)
    TArray<FConnectionPoint> Points; // 0x48 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FConnectionFieldPlanar) == 0x60, "Size mismatch for FConnectionFieldPlanar");
static_assert(offsetof(FConnectionFieldPlanar, Width) == 0x40, "Offset mismatch for FConnectionFieldPlanar::Width");
static_assert(offsetof(FConnectionFieldPlanar, Height) == 0x41, "Offset mismatch for FConnectionFieldPlanar::Height");
static_assert(offsetof(FConnectionFieldPlanar, Points) == 0x48, "Offset mismatch for FConnectionFieldPlanar::Points");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FConnectionPoint
{
    uint8_t Flags[0x4]; // 0x0 (Size: 0x4, Type: EnumProperty)
    uint8_t Type; // 0x4 (Size: 0x1, Type: EnumProperty)
    char Size; // 0x5 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_6[0x2]; // 0x6 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FConnectionPoint) == 0x8, "Size mismatch for FConnectionPoint");
static_assert(offsetof(FConnectionPoint, Flags) == 0x0, "Offset mismatch for FConnectionPoint::Flags");
static_assert(offsetof(FConnectionPoint, Type) == 0x4, "Offset mismatch for FConnectionPoint::Type");
static_assert(offsetof(FConnectionPoint, Size) == 0x5, "Offset mismatch for FConnectionPoint::Size");

// Size: 0x50 (Inherited: 0x80, Single: 0xffffffd0)
struct FConnectionFieldFixed : FConnectionFieldPoint
{
    uint32_t Axes; // 0x40 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_44[0xc]; // 0x44 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FConnectionFieldFixed) == 0x50, "Size mismatch for FConnectionFieldFixed");
static_assert(offsetof(FConnectionFieldFixed, Axes) == 0x40, "Offset mismatch for FConnectionFieldFixed::Axes");

// Size: 0x60 (Inherited: 0x90, Single: 0xffffffd0)
struct FConnectionFieldGear : FConnectionFieldLine
{
    double Radius; // 0x50 (Size: 0x8, Type: DoubleProperty)
    uint32_t ToothCount; // 0x58 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FConnectionFieldGear) == 0x60, "Size mismatch for FConnectionFieldGear");
static_assert(offsetof(FConnectionFieldGear, Radius) == 0x50, "Offset mismatch for FConnectionFieldGear::Radius");
static_assert(offsetof(FConnectionFieldGear, ToothCount) == 0x58, "Offset mismatch for FConnectionFieldGear::ToothCount");

// Size: 0x70 (Inherited: 0x80, Single: 0xfffffff0)
struct FConnectionFieldHinge : FConnectionFieldPoint
{
    bool Oriented; // 0x40 (Size: 0x1, Type: BoolProperty)
    bool Flip; // 0x41 (Size: 0x1, Type: BoolProperty)
    bool HasLimits; // 0x42 (Size: 0x1, Type: BoolProperty)
    bool RequireGrabbing; // 0x43 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
    double OrientedMin; // 0x48 (Size: 0x8, Type: DoubleProperty)
    double OrientedMax; // 0x50 (Size: 0x8, Type: DoubleProperty)
    double FlippedMin; // 0x58 (Size: 0x8, Type: DoubleProperty)
    double FlippedMax; // 0x60 (Size: 0x8, Type: DoubleProperty)
    uint8_t Pad_68[0x8]; // 0x68 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FConnectionFieldHinge) == 0x70, "Size mismatch for FConnectionFieldHinge");
static_assert(offsetof(FConnectionFieldHinge, Oriented) == 0x40, "Offset mismatch for FConnectionFieldHinge::Oriented");
static_assert(offsetof(FConnectionFieldHinge, Flip) == 0x41, "Offset mismatch for FConnectionFieldHinge::Flip");
static_assert(offsetof(FConnectionFieldHinge, HasLimits) == 0x42, "Offset mismatch for FConnectionFieldHinge::HasLimits");
static_assert(offsetof(FConnectionFieldHinge, RequireGrabbing) == 0x43, "Offset mismatch for FConnectionFieldHinge::RequireGrabbing");
static_assert(offsetof(FConnectionFieldHinge, OrientedMin) == 0x48, "Offset mismatch for FConnectionFieldHinge::OrientedMin");
static_assert(offsetof(FConnectionFieldHinge, OrientedMax) == 0x50, "Offset mismatch for FConnectionFieldHinge::OrientedMax");
static_assert(offsetof(FConnectionFieldHinge, FlippedMin) == 0x58, "Offset mismatch for FConnectionFieldHinge::FlippedMin");
static_assert(offsetof(FConnectionFieldHinge, FlippedMax) == 0x60, "Offset mismatch for FConnectionFieldHinge::FlippedMax");

// Size: 0x70 (Inherited: 0x90, Single: 0xffffffe0)
struct FConnectionFieldSlider : FConnectionFieldLine
{
    bool Cylindrical; // 0x50 (Size: 0x1, Type: BoolProperty)
    bool HasSpring; // 0x51 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_52[0x6]; // 0x52 (Size: 0x6, Type: PaddingProperty)
    double SpringRest; // 0x58 (Size: 0x8, Type: DoubleProperty)
    double SpringStrength; // 0x60 (Size: 0x8, Type: DoubleProperty)
    double SpringDamping; // 0x68 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FConnectionFieldSlider) == 0x70, "Size mismatch for FConnectionFieldSlider");
static_assert(offsetof(FConnectionFieldSlider, Cylindrical) == 0x50, "Offset mismatch for FConnectionFieldSlider::Cylindrical");
static_assert(offsetof(FConnectionFieldSlider, HasSpring) == 0x51, "Offset mismatch for FConnectionFieldSlider::HasSpring");
static_assert(offsetof(FConnectionFieldSlider, SpringRest) == 0x58, "Offset mismatch for FConnectionFieldSlider::SpringRest");
static_assert(offsetof(FConnectionFieldSlider, SpringStrength) == 0x60, "Offset mismatch for FConnectionFieldSlider::SpringStrength");
static_assert(offsetof(FConnectionFieldSlider, SpringDamping) == 0x68, "Offset mismatch for FConnectionFieldSlider::SpringDamping");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FPlacementContextData
{
    FTransform PlacementTransform; // 0x0 (Size: 0x60, Type: StructProperty)
    FRay CastRay; // 0x60 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FPlacementContextData) == 0x90, "Size mismatch for FPlacementContextData");
static_assert(offsetof(FPlacementContextData, PlacementTransform) == 0x0, "Offset mismatch for FPlacementContextData::PlacementTransform");
static_assert(offsetof(FPlacementContextData, CastRay) == 0x60, "Offset mismatch for FPlacementContextData::CastRay");

// Size: 0x580 (Inherited: 0x0, Single: 0x580)
struct FPlacementToolContext
{
    TArray<AActor*> ActorsToMove; // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t PlacementResult[0x400]; // 0x40 (Size: 0x400, Type: OptionalProperty)
    uint8_t Pad_440[0x140]; // 0x440 (Size: 0x140, Type: PaddingProperty)
};

static_assert(sizeof(FPlacementToolContext) == 0x580, "Size mismatch for FPlacementToolContext");
static_assert(offsetof(FPlacementToolContext, ActorsToMove) == 0x18, "Offset mismatch for FPlacementToolContext::ActorsToMove");
static_assert(offsetof(FPlacementToolContext, PlacementResult) == 0x40, "Offset mismatch for FPlacementToolContext::PlacementResult");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FSerializedPlanarConnection
{
    FPlanarFieldConnectionInfo Connection; // 0x0 (Size: 0x20, Type: StructProperty)
    FConnectivityFieldReference FieldA; // 0x20 (Size: 0x8, Type: StructProperty)
    FConnectivityFieldReference FieldB; // 0x28 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FSerializedPlanarConnection) == 0x30, "Size mismatch for FSerializedPlanarConnection");
static_assert(offsetof(FSerializedPlanarConnection, Connection) == 0x0, "Offset mismatch for FSerializedPlanarConnection::Connection");
static_assert(offsetof(FSerializedPlanarConnection, FieldA) == 0x20, "Offset mismatch for FSerializedPlanarConnection::FieldA");
static_assert(offsetof(FSerializedPlanarConnection, FieldB) == 0x28, "Offset mismatch for FSerializedPlanarConnection::FieldB");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FConnectivityFieldReference
{
    int32_t ObjectId; // 0x0 (Size: 0x4, Type: IntProperty)
    uint16_t FieldIndex; // 0x4 (Size: 0x2, Type: UInt16Property)
    uint8_t Pad_6[0x2]; // 0x6 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FConnectivityFieldReference) == 0x8, "Size mismatch for FConnectivityFieldReference");
static_assert(offsetof(FConnectivityFieldReference, ObjectId) == 0x0, "Offset mismatch for FConnectivityFieldReference::ObjectId");
static_assert(offsetof(FConnectivityFieldReference, FieldIndex) == 0x4, "Offset mismatch for FConnectivityFieldReference::FieldIndex");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FFieldConnectionInfo
{
    uint8_t ConnectResult; // 0x0 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FFieldConnectionInfo) == 0x1, "Size mismatch for FFieldConnectionInfo");
static_assert(offsetof(FFieldConnectionInfo, ConnectResult) == 0x0, "Offset mismatch for FFieldConnectionInfo::ConnectResult");

// Size: 0x20 (Inherited: 0x1, Single: 0x1f)
struct FPlanarFieldConnectionInfo : FFieldConnectionInfo
{
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TArray<FPlanarFieldPointConnectionInfo> PointConnections; // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint32_t OverlapA; // 0x18 (Size: 0x4, Type: UInt32Property)
    uint32_t OverlapB; // 0x1c (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FPlanarFieldConnectionInfo) == 0x20, "Size mismatch for FPlanarFieldConnectionInfo");
static_assert(offsetof(FPlanarFieldConnectionInfo, PointConnections) == 0x8, "Offset mismatch for FPlanarFieldConnectionInfo::PointConnections");
static_assert(offsetof(FPlanarFieldConnectionInfo, OverlapA) == 0x18, "Offset mismatch for FPlanarFieldConnectionInfo::OverlapA");
static_assert(offsetof(FPlanarFieldConnectionInfo, OverlapB) == 0x1c, "Offset mismatch for FPlanarFieldConnectionInfo::OverlapB");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FPlanarFieldPointConnectionInfo
{
    uint16_t IndexA; // 0x0 (Size: 0x2, Type: UInt16Property)
    uint16_t IndexB; // 0x2 (Size: 0x2, Type: UInt16Property)
};

static_assert(sizeof(FPlanarFieldPointConnectionInfo) == 0x4, "Size mismatch for FPlanarFieldPointConnectionInfo");
static_assert(offsetof(FPlanarFieldPointConnectionInfo, IndexA) == 0x0, "Offset mismatch for FPlanarFieldPointConnectionInfo::IndexA");
static_assert(offsetof(FPlanarFieldPointConnectionInfo, IndexB) == 0x2, "Offset mismatch for FPlanarFieldPointConnectionInfo::IndexB");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FSerializedLineConnection
{
    FLineFieldConnectionInfo Connection; // 0x0 (Size: 0x8, Type: StructProperty)
    FConnectivityFieldReference FieldA; // 0x8 (Size: 0x8, Type: StructProperty)
    FConnectivityFieldReference FieldB; // 0x10 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FSerializedLineConnection) == 0x18, "Size mismatch for FSerializedLineConnection");
static_assert(offsetof(FSerializedLineConnection, Connection) == 0x0, "Offset mismatch for FSerializedLineConnection::Connection");
static_assert(offsetof(FSerializedLineConnection, FieldA) == 0x8, "Offset mismatch for FSerializedLineConnection::FieldA");
static_assert(offsetof(FSerializedLineConnection, FieldB) == 0x10, "Offset mismatch for FSerializedLineConnection::FieldB");

// Size: 0x8 (Inherited: 0x1, Single: 0x7)
struct FLineFieldConnectionInfo : FFieldConnectionInfo
{
    bool Flip; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x6]; // 0x2 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FLineFieldConnectionInfo) == 0x8, "Size mismatch for FLineFieldConnectionInfo");
static_assert(offsetof(FLineFieldConnectionInfo, Flip) == 0x1, "Offset mismatch for FLineFieldConnectionInfo::Flip");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FSerializedPointConnection
{
    FPointFieldConnectionInfo Connection; // 0x0 (Size: 0x10, Type: StructProperty)
    FConnectivityFieldReference FieldA; // 0x10 (Size: 0x8, Type: StructProperty)
    FConnectivityFieldReference FieldB; // 0x18 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FSerializedPointConnection) == 0x20, "Size mismatch for FSerializedPointConnection");
static_assert(offsetof(FSerializedPointConnection, Connection) == 0x0, "Offset mismatch for FSerializedPointConnection::Connection");
static_assert(offsetof(FSerializedPointConnection, FieldA) == 0x10, "Offset mismatch for FSerializedPointConnection::FieldA");
static_assert(offsetof(FSerializedPointConnection, FieldB) == 0x18, "Offset mismatch for FSerializedPointConnection::FieldB");

// Size: 0x10 (Inherited: 0x1, Single: 0xf)
struct FPointFieldConnectionInfo : FFieldConnectionInfo
{
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    double OneAxisRotation; // 0x8 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FPointFieldConnectionInfo) == 0x10, "Size mismatch for FPointFieldConnectionInfo");
static_assert(offsetof(FPointFieldConnectionInfo, OneAxisRotation) == 0x8, "Offset mismatch for FPointFieldConnectionInfo::OneAxisRotation");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FSerializedConnectivityObjects
{
    TArray<FConnectionFieldContainer> Fields; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FSerializedPlanarConnection> PlanarConnections; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FSerializedLineConnection> LineConnections; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FSerializedPointConnection> PointConnections; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FSerializedConnectivityObjects) == 0x40, "Size mismatch for FSerializedConnectivityObjects");
static_assert(offsetof(FSerializedConnectivityObjects, Fields) == 0x0, "Offset mismatch for FSerializedConnectivityObjects::Fields");
static_assert(offsetof(FSerializedConnectivityObjects, PlanarConnections) == 0x10, "Offset mismatch for FSerializedConnectivityObjects::PlanarConnections");
static_assert(offsetof(FSerializedConnectivityObjects, LineConnections) == 0x20, "Offset mismatch for FSerializedConnectivityObjects::LineConnections");
static_assert(offsetof(FSerializedConnectivityObjects, PointConnections) == 0x30, "Offset mismatch for FSerializedConnectivityObjects::PointConnections");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FPlanarFieldPointInfo
{
    FVector PointLocation; // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t PointType; // 0x18 (Size: 0x1, Type: EnumProperty)
    bool IsAvailable; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x6]; // 0x1a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FPlanarFieldPointInfo) == 0x20, "Size mismatch for FPlanarFieldPointInfo");
static_assert(offsetof(FPlanarFieldPointInfo, PointLocation) == 0x0, "Offset mismatch for FPlanarFieldPointInfo::PointLocation");
static_assert(offsetof(FPlanarFieldPointInfo, PointType) == 0x18, "Offset mismatch for FPlanarFieldPointInfo::PointType");
static_assert(offsetof(FPlanarFieldPointInfo, IsAvailable) == 0x19, "Offset mismatch for FPlanarFieldPointInfo::IsAvailable");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FPlanarFieldInfo
{
    FTransform Transform; // 0x0 (Size: 0x60, Type: StructProperty)
    FVector2D Size; // 0x60 (Size: 0x10, Type: StructProperty)
    uint8_t PlanarFieldType; // 0x70 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
    TArray<FPlanarFieldPointInfo> PointInfo; // 0x78 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FPlanarFieldInfo) == 0x90, "Size mismatch for FPlanarFieldInfo");
static_assert(offsetof(FPlanarFieldInfo, Transform) == 0x0, "Offset mismatch for FPlanarFieldInfo::Transform");
static_assert(offsetof(FPlanarFieldInfo, Size) == 0x60, "Offset mismatch for FPlanarFieldInfo::Size");
static_assert(offsetof(FPlanarFieldInfo, PlanarFieldType) == 0x70, "Offset mismatch for FPlanarFieldInfo::PlanarFieldType");
static_assert(offsetof(FPlanarFieldInfo, PointInfo) == 0x78, "Offset mismatch for FPlanarFieldInfo::PointInfo");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FWorldConnectivityHandle
{
    int32_t ObjectId; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FWorldConnectivityHandle) == 0x4, "Size mismatch for FWorldConnectivityHandle");
static_assert(offsetof(FWorldConnectivityHandle, ObjectId) == 0x0, "Offset mismatch for FWorldConnectivityHandle::ObjectId");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FConnectivityQueryResult
{
    bool bHasValidConnection; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0xf]; // 0x1 (Size: 0xf, Type: PaddingProperty)
    FTransform TargetTransformToConnect; // 0x10 (Size: 0x60, Type: StructProperty)
    FVector HitLocation; // 0x70 (Size: 0x18, Type: StructProperty)
    FVector OffsetToBestFit; // 0x88 (Size: 0x18, Type: StructProperty)
    int32_t SourceFieldIndex; // 0xa0 (Size: 0x4, Type: IntProperty)
    int32_t SourceFieldObjectId; // 0xa4 (Size: 0x4, Type: IntProperty)
    int32_t SourceFieldConnectionPointIndex; // 0xa8 (Size: 0x4, Type: IntProperty)
    int32_t TargetFieldIndex; // 0xac (Size: 0x4, Type: IntProperty)
    int32_t TargetFieldObjectId; // 0xb0 (Size: 0x4, Type: IntProperty)
    int32_t TargetFieldConnectionPointIndex; // 0xb4 (Size: 0x4, Type: IntProperty)
    FName ErrorMessage; // 0xb8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FConnectivityQueryResult) == 0xc0, "Size mismatch for FConnectivityQueryResult");
static_assert(offsetof(FConnectivityQueryResult, bHasValidConnection) == 0x0, "Offset mismatch for FConnectivityQueryResult::bHasValidConnection");
static_assert(offsetof(FConnectivityQueryResult, TargetTransformToConnect) == 0x10, "Offset mismatch for FConnectivityQueryResult::TargetTransformToConnect");
static_assert(offsetof(FConnectivityQueryResult, HitLocation) == 0x70, "Offset mismatch for FConnectivityQueryResult::HitLocation");
static_assert(offsetof(FConnectivityQueryResult, OffsetToBestFit) == 0x88, "Offset mismatch for FConnectivityQueryResult::OffsetToBestFit");
static_assert(offsetof(FConnectivityQueryResult, SourceFieldIndex) == 0xa0, "Offset mismatch for FConnectivityQueryResult::SourceFieldIndex");
static_assert(offsetof(FConnectivityQueryResult, SourceFieldObjectId) == 0xa4, "Offset mismatch for FConnectivityQueryResult::SourceFieldObjectId");
static_assert(offsetof(FConnectivityQueryResult, SourceFieldConnectionPointIndex) == 0xa8, "Offset mismatch for FConnectivityQueryResult::SourceFieldConnectionPointIndex");
static_assert(offsetof(FConnectivityQueryResult, TargetFieldIndex) == 0xac, "Offset mismatch for FConnectivityQueryResult::TargetFieldIndex");
static_assert(offsetof(FConnectivityQueryResult, TargetFieldObjectId) == 0xb0, "Offset mismatch for FConnectivityQueryResult::TargetFieldObjectId");
static_assert(offsetof(FConnectivityQueryResult, TargetFieldConnectionPointIndex) == 0xb4, "Offset mismatch for FConnectivityQueryResult::TargetFieldConnectionPointIndex");
static_assert(offsetof(FConnectivityQueryResult, ErrorMessage) == 0xb8, "Offset mismatch for FConnectivityQueryResult::ErrorMessage");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FAtomThemeColorEntry
{
    FAtomColorProperty OriginalColor; // 0x0 (Size: 0x4, Type: StructProperty)
    FAtomColorProperty ReplacementColor; // 0x4 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FAtomThemeColorEntry) == 0x8, "Size mismatch for FAtomThemeColorEntry");
static_assert(offsetof(FAtomThemeColorEntry, OriginalColor) == 0x0, "Offset mismatch for FAtomThemeColorEntry::OriginalColor");
static_assert(offsetof(FAtomThemeColorEntry, ReplacementColor) == 0x4, "Offset mismatch for FAtomThemeColorEntry::ReplacementColor");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAtomColorTheme
{
    FName ThemeName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FAtomThemeColorEntry> Entries; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomColorTheme) == 0x18, "Size mismatch for FAtomColorTheme");
static_assert(offsetof(FAtomColorTheme, ThemeName) == 0x0, "Offset mismatch for FAtomColorTheme::ThemeName");
static_assert(offsetof(FAtomColorTheme, Entries) == 0x8, "Offset mismatch for FAtomColorTheme::Entries");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAtomCommonPartDescription
{
    float Radius; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Height; // 0x4 (Size: 0x4, Type: FloatProperty)
    float InnerRadius; // 0x8 (Size: 0x4, Type: FloatProperty)
    char PlaneQuadrant; // 0xc (Size: 0x1, Type: ByteProperty)
    bool bShowLogo; // 0xd (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e[0x2]; // 0xe (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FAtomCommonPartDescription) == 0x10, "Size mismatch for FAtomCommonPartDescription");
static_assert(offsetof(FAtomCommonPartDescription, Radius) == 0x0, "Offset mismatch for FAtomCommonPartDescription::Radius");
static_assert(offsetof(FAtomCommonPartDescription, Height) == 0x4, "Offset mismatch for FAtomCommonPartDescription::Height");
static_assert(offsetof(FAtomCommonPartDescription, InnerRadius) == 0x8, "Offset mismatch for FAtomCommonPartDescription::InnerRadius");
static_assert(offsetof(FAtomCommonPartDescription, PlaneQuadrant) == 0xc, "Offset mismatch for FAtomCommonPartDescription::PlaneQuadrant");
static_assert(offsetof(FAtomCommonPartDescription, bShowLogo) == 0xd, "Offset mismatch for FAtomCommonPartDescription::bShowLogo");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAtomColor
{
    int32_t ID; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Effects; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FLinearColor Color; // 0x8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FAtomColor) == 0x18, "Size mismatch for FAtomColor");
static_assert(offsetof(FAtomColor, ID) == 0x0, "Offset mismatch for FAtomColor::ID");
static_assert(offsetof(FAtomColor, Effects) == 0x4, "Offset mismatch for FAtomColor::Effects");
static_assert(offsetof(FAtomColor, Color) == 0x8, "Offset mismatch for FAtomColor::Color");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FAtomColorSurface
{
    int32_t ColorId; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t ShaderType[0x4]; // 0x4 (Size: 0x4, Type: EnumProperty)
};

static_assert(sizeof(FAtomColorSurface) == 0x8, "Size mismatch for FAtomColorSurface");
static_assert(offsetof(FAtomColorSurface, ColorId) == 0x0, "Offset mismatch for FAtomColorSurface::ColorId");
static_assert(offsetof(FAtomColorSurface, ShaderType) == 0x4, "Offset mismatch for FAtomColorSurface::ShaderType");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FAtomDecorationAssignment
{
    FString SurfaceName; // 0x0 (Size: 0x10, Type: StrProperty)
    FString TextureName; // 0x10 (Size: 0x10, Type: StrProperty)
    FString Version; // 0x20 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FAtomDecorationAssignment) == 0x30, "Size mismatch for FAtomDecorationAssignment");
static_assert(offsetof(FAtomDecorationAssignment, SurfaceName) == 0x0, "Offset mismatch for FAtomDecorationAssignment::SurfaceName");
static_assert(offsetof(FAtomDecorationAssignment, TextureName) == 0x10, "Offset mismatch for FAtomDecorationAssignment::TextureName");
static_assert(offsetof(FAtomDecorationAssignment, Version) == 0x20, "Offset mismatch for FAtomDecorationAssignment::Version");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FAtomModelPrimitiveInstance
{
    UAtomPrimitive* Primitive; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform PrimitiveTransform; // 0x10 (Size: 0x60, Type: StructProperty)
    FVector PivotOrigin; // 0x70 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAtomModelPrimitiveInstance) == 0x90, "Size mismatch for FAtomModelPrimitiveInstance");
static_assert(offsetof(FAtomModelPrimitiveInstance, Primitive) == 0x0, "Offset mismatch for FAtomModelPrimitiveInstance::Primitive");
static_assert(offsetof(FAtomModelPrimitiveInstance, PrimitiveTransform) == 0x10, "Offset mismatch for FAtomModelPrimitiveInstance::PrimitiveTransform");
static_assert(offsetof(FAtomModelPrimitiveInstance, PivotOrigin) == 0x70, "Offset mismatch for FAtomModelPrimitiveInstance::PivotOrigin");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FAtomModelPart
{
    TSoftObjectPtr<UAtomPrimitive*> AtomPrimitive; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInterface*> MaterialInstance; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInterface*> MaterialWithPayload; // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FTransform> Transforms; // 0x60 (Size: 0x10, Type: ArrayProperty)
    uint32_t PartId; // 0x70 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FString PartRevision; // 0x78 (Size: 0x10, Type: StrProperty)
    TArray<FAtomColorSurface> ColorSurfaces; // 0x88 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomDecorationAssignment> Decorations; // 0x98 (Size: 0x10, Type: ArrayProperty)
    bool bIgnoreCommonPartCulling; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAtomModelPart) == 0xb0, "Size mismatch for FAtomModelPart");
static_assert(offsetof(FAtomModelPart, AtomPrimitive) == 0x0, "Offset mismatch for FAtomModelPart::AtomPrimitive");
static_assert(offsetof(FAtomModelPart, MaterialInstance) == 0x20, "Offset mismatch for FAtomModelPart::MaterialInstance");
static_assert(offsetof(FAtomModelPart, MaterialWithPayload) == 0x40, "Offset mismatch for FAtomModelPart::MaterialWithPayload");
static_assert(offsetof(FAtomModelPart, Transforms) == 0x60, "Offset mismatch for FAtomModelPart::Transforms");
static_assert(offsetof(FAtomModelPart, PartId) == 0x70, "Offset mismatch for FAtomModelPart::PartId");
static_assert(offsetof(FAtomModelPart, PartRevision) == 0x78, "Offset mismatch for FAtomModelPart::PartRevision");
static_assert(offsetof(FAtomModelPart, ColorSurfaces) == 0x88, "Offset mismatch for FAtomModelPart::ColorSurfaces");
static_assert(offsetof(FAtomModelPart, Decorations) == 0x98, "Offset mismatch for FAtomModelPart::Decorations");
static_assert(offsetof(FAtomModelPart, bIgnoreCommonPartCulling) == 0xa8, "Offset mismatch for FAtomModelPart::bIgnoreCommonPartCulling");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FAtomModelSocket
{
    FGuid ID; // 0x0 (Size: 0x10, Type: StructProperty)
    FName Name; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FAtomModelSocket) == 0x80, "Size mismatch for FAtomModelSocket");
static_assert(offsetof(FAtomModelSocket, ID) == 0x0, "Offset mismatch for FAtomModelSocket::ID");
static_assert(offsetof(FAtomModelSocket, Name) == 0x10, "Offset mismatch for FAtomModelSocket::Name");
static_assert(offsetof(FAtomModelSocket, Transform) == 0x20, "Offset mismatch for FAtomModelSocket::Transform");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FAtomModelPrimitive
{
    TArray<FAtomModelPart> Parts; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t DesignId; // 0x10 (Size: 0x4, Type: IntProperty)
    FGuid UUID; // 0x14 (Size: 0x10, Type: StructProperty)
    FName DesignName; // 0x24 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FAtomModelPrimitive) == 0x28, "Size mismatch for FAtomModelPrimitive");
static_assert(offsetof(FAtomModelPrimitive, Parts) == 0x0, "Offset mismatch for FAtomModelPrimitive::Parts");
static_assert(offsetof(FAtomModelPrimitive, DesignId) == 0x10, "Offset mismatch for FAtomModelPrimitive::DesignId");
static_assert(offsetof(FAtomModelPrimitive, UUID) == 0x14, "Offset mismatch for FAtomModelPrimitive::UUID");
static_assert(offsetof(FAtomModelPrimitive, DesignName) == 0x24, "Offset mismatch for FAtomModelPrimitive::DesignName");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FAtomBoneReference
{
    int32_t PrimitiveIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t PartIndex; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t BoneIndex; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FAtomBoneReference) == 0xc, "Size mismatch for FAtomBoneReference");
static_assert(offsetof(FAtomBoneReference, PrimitiveIndex) == 0x0, "Offset mismatch for FAtomBoneReference::PrimitiveIndex");
static_assert(offsetof(FAtomBoneReference, PartIndex) == 0x4, "Offset mismatch for FAtomBoneReference::PartIndex");
static_assert(offsetof(FAtomBoneReference, BoneIndex) == 0x8, "Offset mismatch for FAtomBoneReference::BoneIndex");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAtomPrimitiveConnection
{
    FAtomBoneReference From; // 0x0 (Size: 0xc, Type: StructProperty)
    FAtomBoneReference To; // 0xc (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(FAtomPrimitiveConnection) == 0x18, "Size mismatch for FAtomPrimitiveConnection");
static_assert(offsetof(FAtomPrimitiveConnection, From) == 0x0, "Offset mismatch for FAtomPrimitiveConnection::From");
static_assert(offsetof(FAtomPrimitiveConnection, To) == 0xc, "Offset mismatch for FAtomPrimitiveConnection::To");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FAtomRigidElementConnection
{
    FTransform Transform; // 0x0 (Size: 0x60, Type: StructProperty)
    int32_t OtherElementIndex; // 0x60 (Size: 0x4, Type: IntProperty)
    int32_t ConnectionUniqueId; // 0x64 (Size: 0x4, Type: IntProperty)
    TArray<FAtomPrimitiveConnection> PrimitiveConnections; // 0x68 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_78[0x8]; // 0x78 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAtomRigidElementConnection) == 0x80, "Size mismatch for FAtomRigidElementConnection");
static_assert(offsetof(FAtomRigidElementConnection, Transform) == 0x0, "Offset mismatch for FAtomRigidElementConnection::Transform");
static_assert(offsetof(FAtomRigidElementConnection, OtherElementIndex) == 0x60, "Offset mismatch for FAtomRigidElementConnection::OtherElementIndex");
static_assert(offsetof(FAtomRigidElementConnection, ConnectionUniqueId) == 0x64, "Offset mismatch for FAtomRigidElementConnection::ConnectionUniqueId");
static_assert(offsetof(FAtomRigidElementConnection, PrimitiveConnections) == 0x68, "Offset mismatch for FAtomRigidElementConnection::PrimitiveConnections");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FAtomRigidElement
{
    TArray<FAtomBoneReference> BoneReferences; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomRigidElementConnection> Connections; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FName Name; // 0x20 (Size: 0x4, Type: NameProperty)
    int32_t IndexOfMetaBone; // 0x24 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FAtomRigidElement) == 0x28, "Size mismatch for FAtomRigidElement");
static_assert(offsetof(FAtomRigidElement, BoneReferences) == 0x0, "Offset mismatch for FAtomRigidElement::BoneReferences");
static_assert(offsetof(FAtomRigidElement, Connections) == 0x10, "Offset mismatch for FAtomRigidElement::Connections");
static_assert(offsetof(FAtomRigidElement, Name) == 0x20, "Offset mismatch for FAtomRigidElement::Name");
static_assert(offsetof(FAtomRigidElement, IndexOfMetaBone) == 0x24, "Offset mismatch for FAtomRigidElement::IndexOfMetaBone");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAtomHingedElement
{
    TArray<FAtomRigidElement> RigidElements; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t HierarchyRootIndex; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAtomHingedElement) == 0x18, "Size mismatch for FAtomHingedElement");
static_assert(offsetof(FAtomHingedElement, RigidElements) == 0x0, "Offset mismatch for FAtomHingedElement::RigidElements");
static_assert(offsetof(FAtomHingedElement, HierarchyRootIndex) == 0x10, "Offset mismatch for FAtomHingedElement::HierarchyRootIndex");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FAtomModelPartReference
{
    FGuid PrimitiveUUID; // 0x0 (Size: 0x10, Type: StructProperty)
    int32_t PartIndex; // 0x10 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FAtomModelPartReference) == 0x14, "Size mismatch for FAtomModelPartReference");
static_assert(offsetof(FAtomModelPartReference, PrimitiveUUID) == 0x0, "Offset mismatch for FAtomModelPartReference::PrimitiveUUID");
static_assert(offsetof(FAtomModelPartReference, PartIndex) == 0x10, "Offset mismatch for FAtomModelPartReference::PartIndex");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FAtomGlueSet
{
    TSet<FAtomModelPartReference> Entries; // 0x0 (Size: 0x50, Type: SetProperty)
};

static_assert(sizeof(FAtomGlueSet) == 0x50, "Size mismatch for FAtomGlueSet");
static_assert(offsetof(FAtomGlueSet, Entries) == 0x0, "Offset mismatch for FAtomGlueSet::Entries");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAtomPrimitiveGroup
{
    FVector PivotOrigin; // 0x0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FAtomPrimitiveGroup) == 0x18, "Size mismatch for FAtomPrimitiveGroup");
static_assert(offsetof(FAtomPrimitiveGroup, PivotOrigin) == 0x0, "Offset mismatch for FAtomPrimitiveGroup::PivotOrigin");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAtomModelGeometryOptimizationSettings
{
    bool bEnforceLODBudgets; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bUseTagBudget; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    int32_t TriangleBudget; // 0x4 (Size: 0x4, Type: IntProperty)
    double SimplifyBaseTolerance; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double OptimizeBaseTriCost; // 0x10 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FAtomModelGeometryOptimizationSettings) == 0x18, "Size mismatch for FAtomModelGeometryOptimizationSettings");
static_assert(offsetof(FAtomModelGeometryOptimizationSettings, bEnforceLODBudgets) == 0x0, "Offset mismatch for FAtomModelGeometryOptimizationSettings::bEnforceLODBudgets");
static_assert(offsetof(FAtomModelGeometryOptimizationSettings, bUseTagBudget) == 0x1, "Offset mismatch for FAtomModelGeometryOptimizationSettings::bUseTagBudget");
static_assert(offsetof(FAtomModelGeometryOptimizationSettings, TriangleBudget) == 0x4, "Offset mismatch for FAtomModelGeometryOptimizationSettings::TriangleBudget");
static_assert(offsetof(FAtomModelGeometryOptimizationSettings, SimplifyBaseTolerance) == 0x8, "Offset mismatch for FAtomModelGeometryOptimizationSettings::SimplifyBaseTolerance");
static_assert(offsetof(FAtomModelGeometryOptimizationSettings, OptimizeBaseTriCost) == 0x10, "Offset mismatch for FAtomModelGeometryOptimizationSettings::OptimizeBaseTriCost");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FAtomSelectionSetPrimitiveGroup : FAtomPrimitiveGroup
{
    FName SelectionSetName; // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAtomSelectionSetPrimitiveGroup) == 0x20, "Size mismatch for FAtomSelectionSetPrimitiveGroup");
static_assert(offsetof(FAtomSelectionSetPrimitiveGroup, SelectionSetName) == 0x18, "Offset mismatch for FAtomSelectionSetPrimitiveGroup::SelectionSetName");

// Size: 0x18 (Inherited: 0x18, Single: 0x0)
struct FAtomModelPrimitiveGroup : FAtomPrimitiveGroup
{
};

static_assert(sizeof(FAtomModelPrimitiveGroup) == 0x18, "Size mismatch for FAtomModelPrimitiveGroup");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FAtomRigidElementIndices
{
    int32_t HingedElementIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t RigidElementIndex; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t BoneIndex; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FAtomRigidElementIndices) == 0xc, "Size mismatch for FAtomRigidElementIndices");
static_assert(offsetof(FAtomRigidElementIndices, HingedElementIndex) == 0x0, "Offset mismatch for FAtomRigidElementIndices::HingedElementIndex");
static_assert(offsetof(FAtomRigidElementIndices, RigidElementIndex) == 0x4, "Offset mismatch for FAtomRigidElementIndices::RigidElementIndex");
static_assert(offsetof(FAtomRigidElementIndices, BoneIndex) == 0x8, "Offset mismatch for FAtomRigidElementIndices::BoneIndex");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAtomResolvedModelPartReference
{
    FAtomBoneReference Indices; // 0x0 (Size: 0xc, Type: StructProperty)
    FAtomRigidElementIndices ElementIndices; // 0xc (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(FAtomResolvedModelPartReference) == 0x18, "Size mismatch for FAtomResolvedModelPartReference");
static_assert(offsetof(FAtomResolvedModelPartReference, Indices) == 0x0, "Offset mismatch for FAtomResolvedModelPartReference::Indices");
static_assert(offsetof(FAtomResolvedModelPartReference, ElementIndices) == 0xc, "Offset mismatch for FAtomResolvedModelPartReference::ElementIndices");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FAtomRigidElementSettings
{
    FAtomModelPartReference ElementIdentifyingPart; // 0x0 (Size: 0x14, Type: StructProperty)
    FName RigidElementName; // 0x14 (Size: 0x4, Type: NameProperty)
    bool MergeWithParentElement; // 0x18 (Size: 0x1, Type: BoolProperty)
    bool ShouldBeRootElement; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x2]; // 0x1a (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FAtomRigidElementSettings) == 0x1c, "Size mismatch for FAtomRigidElementSettings");
static_assert(offsetof(FAtomRigidElementSettings, ElementIdentifyingPart) == 0x0, "Offset mismatch for FAtomRigidElementSettings::ElementIdentifyingPart");
static_assert(offsetof(FAtomRigidElementSettings, RigidElementName) == 0x14, "Offset mismatch for FAtomRigidElementSettings::RigidElementName");
static_assert(offsetof(FAtomRigidElementSettings, MergeWithParentElement) == 0x18, "Offset mismatch for FAtomRigidElementSettings::MergeWithParentElement");
static_assert(offsetof(FAtomRigidElementSettings, ShouldBeRootElement) == 0x19, "Offset mismatch for FAtomRigidElementSettings::ShouldBeRootElement");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAtomModelTags
{
    TArray<FName> Tags; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomModelTags) == 0x10, "Size mismatch for FAtomModelTags");
static_assert(offsetof(FAtomModelTags, Tags) == 0x0, "Offset mismatch for FAtomModelTags::Tags");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FAtomModelAssetSettings
{
    float Scale; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool CreateRigidElementComponents; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FAtomModelGeometryOptimizationSettings OptimizationSettings; // 0x8 (Size: 0x18, Type: StructProperty)
    bool bEnableConnectivity; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAtomModelAssetSettings) == 0x28, "Size mismatch for FAtomModelAssetSettings");
static_assert(offsetof(FAtomModelAssetSettings, Scale) == 0x0, "Offset mismatch for FAtomModelAssetSettings::Scale");
static_assert(offsetof(FAtomModelAssetSettings, CreateRigidElementComponents) == 0x4, "Offset mismatch for FAtomModelAssetSettings::CreateRigidElementComponents");
static_assert(offsetof(FAtomModelAssetSettings, OptimizationSettings) == 0x8, "Offset mismatch for FAtomModelAssetSettings::OptimizationSettings");
static_assert(offsetof(FAtomModelAssetSettings, bEnableConnectivity) == 0x20, "Offset mismatch for FAtomModelAssetSettings::bEnableConnectivity");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FAtomModelSelectionSet
{
    TSet<FGuid> PrimitiveIds; // 0x0 (Size: 0x50, Type: SetProperty)
    FName SelectionSetName; // 0x50 (Size: 0x4, Type: NameProperty)
    FName ImportedName; // 0x54 (Size: 0x4, Type: NameProperty)
    FGuid ID; // 0x58 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FAtomModelSelectionSet) == 0x68, "Size mismatch for FAtomModelSelectionSet");
static_assert(offsetof(FAtomModelSelectionSet, PrimitiveIds) == 0x0, "Offset mismatch for FAtomModelSelectionSet::PrimitiveIds");
static_assert(offsetof(FAtomModelSelectionSet, SelectionSetName) == 0x50, "Offset mismatch for FAtomModelSelectionSet::SelectionSetName");
static_assert(offsetof(FAtomModelSelectionSet, ImportedName) == 0x54, "Offset mismatch for FAtomModelSelectionSet::ImportedName");
static_assert(offsetof(FAtomModelSelectionSet, ID) == 0x58, "Offset mismatch for FAtomModelSelectionSet::ID");

// Size: 0x190 (Inherited: 0x0, Single: 0x190)
struct FAtomModelConfigurationGroup
{
    FGuid ID; // 0x0 (Size: 0x10, Type: StructProperty)
    FName Name; // 0x10 (Size: 0x4, Type: NameProperty)
    FGuid ParentGroupId; // 0x14 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TSet<FGuid> PrimitiveIds; // 0x28 (Size: 0x50, Type: SetProperty)
    TArray<FAtomModelSocket> Sockets; // 0x78 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
    FTransform GroupPivot; // 0x90 (Size: 0x60, Type: StructProperty)
    TMap<FString, FName> Attributes; // 0xf0 (Size: 0x50, Type: MapProperty)
    TSet<FName> Tags; // 0x140 (Size: 0x50, Type: SetProperty)
};

static_assert(sizeof(FAtomModelConfigurationGroup) == 0x190, "Size mismatch for FAtomModelConfigurationGroup");
static_assert(offsetof(FAtomModelConfigurationGroup, ID) == 0x0, "Offset mismatch for FAtomModelConfigurationGroup::ID");
static_assert(offsetof(FAtomModelConfigurationGroup, Name) == 0x10, "Offset mismatch for FAtomModelConfigurationGroup::Name");
static_assert(offsetof(FAtomModelConfigurationGroup, ParentGroupId) == 0x14, "Offset mismatch for FAtomModelConfigurationGroup::ParentGroupId");
static_assert(offsetof(FAtomModelConfigurationGroup, PrimitiveIds) == 0x28, "Offset mismatch for FAtomModelConfigurationGroup::PrimitiveIds");
static_assert(offsetof(FAtomModelConfigurationGroup, Sockets) == 0x78, "Offset mismatch for FAtomModelConfigurationGroup::Sockets");
static_assert(offsetof(FAtomModelConfigurationGroup, GroupPivot) == 0x90, "Offset mismatch for FAtomModelConfigurationGroup::GroupPivot");
static_assert(offsetof(FAtomModelConfigurationGroup, Attributes) == 0xf0, "Offset mismatch for FAtomModelConfigurationGroup::Attributes");
static_assert(offsetof(FAtomModelConfigurationGroup, Tags) == 0x140, "Offset mismatch for FAtomModelConfigurationGroup::Tags");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FAtomModelHierarchicalSceneNode
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FTransform WorldTransform; // 0x10 (Size: 0x60, Type: StructProperty)
    int32_t ParentIndex; // 0x70 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    TArray<FString> ItemNames; // 0x78 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAtomModelHierarchicalSceneNode) == 0x90, "Size mismatch for FAtomModelHierarchicalSceneNode");
static_assert(offsetof(FAtomModelHierarchicalSceneNode, Name) == 0x0, "Offset mismatch for FAtomModelHierarchicalSceneNode::Name");
static_assert(offsetof(FAtomModelHierarchicalSceneNode, WorldTransform) == 0x10, "Offset mismatch for FAtomModelHierarchicalSceneNode::WorldTransform");
static_assert(offsetof(FAtomModelHierarchicalSceneNode, ParentIndex) == 0x70, "Offset mismatch for FAtomModelHierarchicalSceneNode::ParentIndex");
static_assert(offsetof(FAtomModelHierarchicalSceneNode, ItemNames) == 0x78, "Offset mismatch for FAtomModelHierarchicalSceneNode::ItemNames");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAtomModelHierarchicalScene
{
    TArray<FAtomModelHierarchicalSceneNode> SceneNodes; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomModelHierarchicalScene) == 0x10, "Size mismatch for FAtomModelHierarchicalScene");
static_assert(offsetof(FAtomModelHierarchicalScene, SceneNodes) == 0x0, "Offset mismatch for FAtomModelHierarchicalScene::SceneNodes");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FAtomSourceModel
{
    TArray<FAtomModelPrimitive> Primitives; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomHingedElement> Elements; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomModelSelectionSet> SelectionSets; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomGlueSet> GlueSets; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomModelConfigurationGroup> Groups; // 0x40 (Size: 0x10, Type: ArrayProperty)
    FBox Bounds; // 0x50 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FAtomSourceModel) == 0x88, "Size mismatch for FAtomSourceModel");
static_assert(offsetof(FAtomSourceModel, Primitives) == 0x0, "Offset mismatch for FAtomSourceModel::Primitives");
static_assert(offsetof(FAtomSourceModel, Elements) == 0x10, "Offset mismatch for FAtomSourceModel::Elements");
static_assert(offsetof(FAtomSourceModel, SelectionSets) == 0x20, "Offset mismatch for FAtomSourceModel::SelectionSets");
static_assert(offsetof(FAtomSourceModel, GlueSets) == 0x30, "Offset mismatch for FAtomSourceModel::GlueSets");
static_assert(offsetof(FAtomSourceModel, Groups) == 0x40, "Offset mismatch for FAtomSourceModel::Groups");
static_assert(offsetof(FAtomSourceModel, Bounds) == 0x50, "Offset mismatch for FAtomSourceModel::Bounds");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAtomModelIssue
{
    uint8_t Issue[0x4]; // 0x0 (Size: 0x4, Type: EnumProperty)
    int32_t ID; // 0x4 (Size: 0x4, Type: IntProperty)
    FString StringData; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FAtomModelIssue) == 0x18, "Size mismatch for FAtomModelIssue");
static_assert(offsetof(FAtomModelIssue, Issue) == 0x0, "Offset mismatch for FAtomModelIssue::Issue");
static_assert(offsetof(FAtomModelIssue, ID) == 0x4, "Offset mismatch for FAtomModelIssue::ID");
static_assert(offsetof(FAtomModelIssue, StringData) == 0x8, "Offset mismatch for FAtomModelIssue::StringData");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FCommonPartInstanceDescription
{
    int16_t MeshIdx; // 0x0 (Size: 0x2, Type: Int16Property)
    int16_t MaterialIdx; // 0x2 (Size: 0x2, Type: Int16Property)
    int16_t UUIDIdx; // 0x4 (Size: 0x2, Type: Int16Property)
    uint16_t ColorId; // 0x6 (Size: 0x2, Type: UInt16Property)
};

static_assert(sizeof(FCommonPartInstanceDescription) == 0x8, "Size mismatch for FCommonPartInstanceDescription");
static_assert(offsetof(FCommonPartInstanceDescription, MeshIdx) == 0x0, "Offset mismatch for FCommonPartInstanceDescription::MeshIdx");
static_assert(offsetof(FCommonPartInstanceDescription, MaterialIdx) == 0x2, "Offset mismatch for FCommonPartInstanceDescription::MaterialIdx");
static_assert(offsetof(FCommonPartInstanceDescription, UUIDIdx) == 0x4, "Offset mismatch for FCommonPartInstanceDescription::UUIDIdx");
static_assert(offsetof(FCommonPartInstanceDescription, ColorId) == 0x6, "Offset mismatch for FCommonPartInstanceDescription::ColorId");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FAtomCommonPartInstancesCache
{
    TArray<UStaticMesh*> Meshes; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInterface*> Materials; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FGuid> UUIDs; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FCommonPartInstanceDescription> Instances; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform3f> InstanceTransforms; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomCommonPartInstancesCache) == 0x50, "Size mismatch for FAtomCommonPartInstancesCache");
static_assert(offsetof(FAtomCommonPartInstancesCache, Meshes) == 0x0, "Offset mismatch for FAtomCommonPartInstancesCache::Meshes");
static_assert(offsetof(FAtomCommonPartInstancesCache, Materials) == 0x10, "Offset mismatch for FAtomCommonPartInstancesCache::Materials");
static_assert(offsetof(FAtomCommonPartInstancesCache, UUIDs) == 0x20, "Offset mismatch for FAtomCommonPartInstancesCache::UUIDs");
static_assert(offsetof(FAtomCommonPartInstancesCache, Instances) == 0x30, "Offset mismatch for FAtomCommonPartInstancesCache::Instances");
static_assert(offsetof(FAtomCommonPartInstancesCache, InstanceTransforms) == 0x40, "Offset mismatch for FAtomCommonPartInstancesCache::InstanceTransforms");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FAtomPrimitiveMaterialAssignment
{
    FName SlotName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UMaterialInterface*> Material; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    bool bIsCustomMaterialOverride; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bHasManualColorSource; // 0x29 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a[0x6]; // 0x2a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FAtomPrimitiveMaterialAssignment) == 0x30, "Size mismatch for FAtomPrimitiveMaterialAssignment");
static_assert(offsetof(FAtomPrimitiveMaterialAssignment, SlotName) == 0x0, "Offset mismatch for FAtomPrimitiveMaterialAssignment::SlotName");
static_assert(offsetof(FAtomPrimitiveMaterialAssignment, Material) == 0x8, "Offset mismatch for FAtomPrimitiveMaterialAssignment::Material");
static_assert(offsetof(FAtomPrimitiveMaterialAssignment, bIsCustomMaterialOverride) == 0x28, "Offset mismatch for FAtomPrimitiveMaterialAssignment::bIsCustomMaterialOverride");
static_assert(offsetof(FAtomPrimitiveMaterialAssignment, bHasManualColorSource) == 0x29, "Offset mismatch for FAtomPrimitiveMaterialAssignment::bHasManualColorSource");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FAtomPrimitiveInstanceData
{
    TArray<FAtomPrimitiveMaterialAssignment> MaterialAssignments; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UStaticMesh*> MeshOverride; // 0x10 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FAtomPrimitiveInstanceData) == 0x30, "Size mismatch for FAtomPrimitiveInstanceData");
static_assert(offsetof(FAtomPrimitiveInstanceData, MaterialAssignments) == 0x0, "Offset mismatch for FAtomPrimitiveInstanceData::MaterialAssignments");
static_assert(offsetof(FAtomPrimitiveInstanceData, MeshOverride) == 0x10, "Offset mismatch for FAtomPrimitiveInstanceData::MeshOverride");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FAtomCommonPartAssetDescription
{
    uint8_t CommonPartType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FName CommonPartStyle; // 0x4 (Size: 0x4, Type: NameProperty)
    float Scale; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FAtomCommonPartAssetDescription) == 0xc, "Size mismatch for FAtomCommonPartAssetDescription");
static_assert(offsetof(FAtomCommonPartAssetDescription, CommonPartType) == 0x0, "Offset mismatch for FAtomCommonPartAssetDescription::CommonPartType");
static_assert(offsetof(FAtomCommonPartAssetDescription, CommonPartStyle) == 0x4, "Offset mismatch for FAtomCommonPartAssetDescription::CommonPartStyle");
static_assert(offsetof(FAtomCommonPartAssetDescription, Scale) == 0x8, "Offset mismatch for FAtomCommonPartAssetDescription::Scale");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FModelPrimitiveEntry
{
    TSoftObjectPtr<UPrimitiveComponent*> Component; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FAtomModelPartReference PartReference; // 0x20 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FModelPrimitiveEntry) == 0x38, "Size mismatch for FModelPrimitiveEntry");
static_assert(offsetof(FModelPrimitiveEntry, Component) == 0x0, "Offset mismatch for FModelPrimitiveEntry::Component");
static_assert(offsetof(FModelPrimitiveEntry, PartReference) == 0x20, "Offset mismatch for FModelPrimitiveEntry::PartReference");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FAtomModelPartGuid
{
    FGuid Guid; // 0x0 (Size: 0x10, Type: StructProperty)
    int32_t PartIndex; // 0x10 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FAtomModelPartGuid) == 0x14, "Size mismatch for FAtomModelPartGuid");
static_assert(offsetof(FAtomModelPartGuid, Guid) == 0x0, "Offset mismatch for FAtomModelPartGuid::Guid");
static_assert(offsetof(FAtomModelPartGuid, PartIndex) == 0x10, "Offset mismatch for FAtomModelPartGuid::PartIndex");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FAtomModelPartColorInfo
{
    FColor Color; // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t ColorId; // 0x4 (Size: 0x4, Type: IntProperty)
    uint8_t MaterialType; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FAtomModelPartColorInfo) == 0xc, "Size mismatch for FAtomModelPartColorInfo");
static_assert(offsetof(FAtomModelPartColorInfo, Color) == 0x0, "Offset mismatch for FAtomModelPartColorInfo::Color");
static_assert(offsetof(FAtomModelPartColorInfo, ColorId) == 0x4, "Offset mismatch for FAtomModelPartColorInfo::ColorId");
static_assert(offsetof(FAtomModelPartColorInfo, MaterialType) == 0x8, "Offset mismatch for FAtomModelPartColorInfo::MaterialType");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FAtomModelPartDecorationInfo
{
    UMaterialInterface* Material; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UTexture* Texture; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FString PrimitiveSurfaceName; // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t PrimitiveSurfaceIndex; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAtomModelPartDecorationInfo) == 0x28, "Size mismatch for FAtomModelPartDecorationInfo");
static_assert(offsetof(FAtomModelPartDecorationInfo, Material) == 0x0, "Offset mismatch for FAtomModelPartDecorationInfo::Material");
static_assert(offsetof(FAtomModelPartDecorationInfo, Texture) == 0x8, "Offset mismatch for FAtomModelPartDecorationInfo::Texture");
static_assert(offsetof(FAtomModelPartDecorationInfo, PrimitiveSurfaceName) == 0x10, "Offset mismatch for FAtomModelPartDecorationInfo::PrimitiveSurfaceName");
static_assert(offsetof(FAtomModelPartDecorationInfo, PrimitiveSurfaceIndex) == 0x20, "Offset mismatch for FAtomModelPartDecorationInfo::PrimitiveSurfaceIndex");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FAtomCommonPartAndTransform
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0xf]; // 0x1 (Size: 0xf, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
    TArray<FName> GeometryStyles; // 0x70 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomCommonPartAndTransform) == 0x80, "Size mismatch for FAtomCommonPartAndTransform");
static_assert(offsetof(FAtomCommonPartAndTransform, Type) == 0x0, "Offset mismatch for FAtomCommonPartAndTransform::Type");
static_assert(offsetof(FAtomCommonPartAndTransform, Transform) == 0x10, "Offset mismatch for FAtomCommonPartAndTransform::Transform");
static_assert(offsetof(FAtomCommonPartAndTransform, GeometryStyles) == 0x70, "Offset mismatch for FAtomCommonPartAndTransform::GeometryStyles");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FAtomModelPartInstanceInfo
{
    FAtomModelPartGuid PartGuid; // 0x0 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    int32_t PartId; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    UAtomPrimitive* Primitive; // 0x20 (Size: 0x8, Type: ObjectProperty)
    TArray<FTransform> Transforms; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomModelPartDecorationInfo> Decorations; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomModelPartColorInfo> Colors; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> SelectionSets; // 0x58 (Size: 0x10, Type: ArrayProperty)
    FString Group; // 0x68 (Size: 0x10, Type: StrProperty)
    FString ParentGroup; // 0x78 (Size: 0x10, Type: StrProperty)
    TArray<FAtomCommonPartAndTransform> CommonParts; // 0x88 (Size: 0x10, Type: ArrayProperty)
    bool bIsUndersideVisible; // 0x98 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x17]; // 0x99 (Size: 0x17, Type: PaddingProperty)
};

static_assert(sizeof(FAtomModelPartInstanceInfo) == 0xb0, "Size mismatch for FAtomModelPartInstanceInfo");
static_assert(offsetof(FAtomModelPartInstanceInfo, PartGuid) == 0x0, "Offset mismatch for FAtomModelPartInstanceInfo::PartGuid");
static_assert(offsetof(FAtomModelPartInstanceInfo, PartId) == 0x18, "Offset mismatch for FAtomModelPartInstanceInfo::PartId");
static_assert(offsetof(FAtomModelPartInstanceInfo, Primitive) == 0x20, "Offset mismatch for FAtomModelPartInstanceInfo::Primitive");
static_assert(offsetof(FAtomModelPartInstanceInfo, Transforms) == 0x28, "Offset mismatch for FAtomModelPartInstanceInfo::Transforms");
static_assert(offsetof(FAtomModelPartInstanceInfo, Decorations) == 0x38, "Offset mismatch for FAtomModelPartInstanceInfo::Decorations");
static_assert(offsetof(FAtomModelPartInstanceInfo, Colors) == 0x48, "Offset mismatch for FAtomModelPartInstanceInfo::Colors");
static_assert(offsetof(FAtomModelPartInstanceInfo, SelectionSets) == 0x58, "Offset mismatch for FAtomModelPartInstanceInfo::SelectionSets");
static_assert(offsetof(FAtomModelPartInstanceInfo, Group) == 0x68, "Offset mismatch for FAtomModelPartInstanceInfo::Group");
static_assert(offsetof(FAtomModelPartInstanceInfo, ParentGroup) == 0x78, "Offset mismatch for FAtomModelPartInstanceInfo::ParentGroup");
static_assert(offsetof(FAtomModelPartInstanceInfo, CommonParts) == 0x88, "Offset mismatch for FAtomModelPartInstanceInfo::CommonParts");
static_assert(offsetof(FAtomModelPartInstanceInfo, bIsUndersideVisible) == 0x98, "Offset mismatch for FAtomModelPartInstanceInfo::bIsUndersideVisible");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FAtomModelPartsCollection
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FTransform Pivot; // 0x10 (Size: 0x60, Type: StructProperty)
    TArray<FAtomModelPartInstanceInfo> Parts; // 0x70 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomModelPartsCollection) == 0x80, "Size mismatch for FAtomModelPartsCollection");
static_assert(offsetof(FAtomModelPartsCollection, Name) == 0x0, "Offset mismatch for FAtomModelPartsCollection::Name");
static_assert(offsetof(FAtomModelPartsCollection, Pivot) == 0x10, "Offset mismatch for FAtomModelPartsCollection::Pivot");
static_assert(offsetof(FAtomModelPartsCollection, Parts) == 0x70, "Offset mismatch for FAtomModelPartsCollection::Parts");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FAtomPartConnectivityFieldReference
{
    FAtomModelPartInstanceInfo PartInfo; // 0x0 (Size: 0xb0, Type: StructProperty)
    FTypedConnectivityFieldReference ConnectivityField; // 0xb0 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAtomPartConnectivityFieldReference) == 0xc0, "Size mismatch for FAtomPartConnectivityFieldReference");
static_assert(offsetof(FAtomPartConnectivityFieldReference, PartInfo) == 0x0, "Offset mismatch for FAtomPartConnectivityFieldReference::PartInfo");
static_assert(offsetof(FAtomPartConnectivityFieldReference, ConnectivityField) == 0xb0, "Offset mismatch for FAtomPartConnectivityFieldReference::ConnectivityField");

// Size: 0xc (Inherited: 0x8, Single: 0x4)
struct FTypedConnectivityFieldReference : FConnectivityFieldReference
{
    uint8_t FieldType; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FTypedConnectivityFieldReference) == 0xc, "Size mismatch for FTypedConnectivityFieldReference");
static_assert(offsetof(FTypedConnectivityFieldReference, FieldType) == 0x8, "Offset mismatch for FTypedConnectivityFieldReference::FieldType");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FAtomProcessorResult
{
    bool bSuccess; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TArray<UObject*> ProcessedObjects; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<UObject*> SharedAssets; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomProcessorResult) == 0x28, "Size mismatch for FAtomProcessorResult");
static_assert(offsetof(FAtomProcessorResult, bSuccess) == 0x0, "Offset mismatch for FAtomProcessorResult::bSuccess");
static_assert(offsetof(FAtomProcessorResult, ProcessedObjects) == 0x8, "Offset mismatch for FAtomProcessorResult::ProcessedObjects");
static_assert(offsetof(FAtomProcessorResult, SharedAssets) == 0x18, "Offset mismatch for FAtomProcessorResult::SharedAssets");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAtomOnProcessPrimitiveSettings
{
    FString CustomLocation; // 0x0 (Size: 0x10, Type: StrProperty)
    bool bSupportDecorations; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAtomOnProcessPrimitiveSettings) == 0x18, "Size mismatch for FAtomOnProcessPrimitiveSettings");
static_assert(offsetof(FAtomOnProcessPrimitiveSettings, CustomLocation) == 0x0, "Offset mismatch for FAtomOnProcessPrimitiveSettings::CustomLocation");
static_assert(offsetof(FAtomOnProcessPrimitiveSettings, bSupportDecorations) == 0x10, "Offset mismatch for FAtomOnProcessPrimitiveSettings::bSupportDecorations");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FAtomModelProcessorInstance
{
    bool bUseCustomSettings; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UAtomModelProcessor* Processor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UAtomModelProcessor* InternalTransientPropStorage; // 0x10 (Size: 0x8, Type: ObjectProperty)
    TArray<TSoftObjectPtr<UObject*>> ProcessedObjects; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomModelProcessorInstance) == 0x28, "Size mismatch for FAtomModelProcessorInstance");
static_assert(offsetof(FAtomModelProcessorInstance, bUseCustomSettings) == 0x0, "Offset mismatch for FAtomModelProcessorInstance::bUseCustomSettings");
static_assert(offsetof(FAtomModelProcessorInstance, Processor) == 0x8, "Offset mismatch for FAtomModelProcessorInstance::Processor");
static_assert(offsetof(FAtomModelProcessorInstance, InternalTransientPropStorage) == 0x10, "Offset mismatch for FAtomModelProcessorInstance::InternalTransientPropStorage");
static_assert(offsetof(FAtomModelProcessorInstance, ProcessedObjects) == 0x18, "Offset mismatch for FAtomModelProcessorInstance::ProcessedObjects");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FAtomPrimitiveConnectionPointReference
{
    int16_t PlanarFieldIndex; // 0x0 (Size: 0x2, Type: Int16Property)
    int16_t ConnectionPointIndex; // 0x2 (Size: 0x2, Type: Int16Property)
};

static_assert(sizeof(FAtomPrimitiveConnectionPointReference) == 0x4, "Size mismatch for FAtomPrimitiveConnectionPointReference");
static_assert(offsetof(FAtomPrimitiveConnectionPointReference, PlanarFieldIndex) == 0x0, "Offset mismatch for FAtomPrimitiveConnectionPointReference::PlanarFieldIndex");
static_assert(offsetof(FAtomPrimitiveConnectionPointReference, ConnectionPointIndex) == 0x2, "Offset mismatch for FAtomPrimitiveConnectionPointReference::ConnectionPointIndex");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FAtomPrimitiveTechnicCapReference
{
    FName StyleName; // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t LOD; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t CapIndex; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FAtomPrimitiveTechnicCapReference) == 0xc, "Size mismatch for FAtomPrimitiveTechnicCapReference");
static_assert(offsetof(FAtomPrimitiveTechnicCapReference, StyleName) == 0x0, "Offset mismatch for FAtomPrimitiveTechnicCapReference::StyleName");
static_assert(offsetof(FAtomPrimitiveTechnicCapReference, LOD) == 0x4, "Offset mismatch for FAtomPrimitiveTechnicCapReference::LOD");
static_assert(offsetof(FAtomPrimitiveTechnicCapReference, CapIndex) == 0x8, "Offset mismatch for FAtomPrimitiveTechnicCapReference::CapIndex");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FAtomCommonPartInstance
{
    FTransform3f Transform; // 0x0 (Size: 0x30, Type: StructProperty)
    FAtomPrimitiveConnectionPointReference ConnectionPointReference; // 0x30 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    TArray<FName> GeometryStyles; // 0x38 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAtomCommonPartInstance) == 0x50, "Size mismatch for FAtomCommonPartInstance");
static_assert(offsetof(FAtomCommonPartInstance, Transform) == 0x0, "Offset mismatch for FAtomCommonPartInstance::Transform");
static_assert(offsetof(FAtomCommonPartInstance, ConnectionPointReference) == 0x30, "Offset mismatch for FAtomCommonPartInstance::ConnectionPointReference");
static_assert(offsetof(FAtomCommonPartInstance, GeometryStyles) == 0x38, "Offset mismatch for FAtomCommonPartInstance::GeometryStyles");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAtomPrimitiveCommonPart
{
    TArray<FAtomCommonPartInstance> UnscaledInstances; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAtomPrimitiveCommonPart) == 0x10, "Size mismatch for FAtomPrimitiveCommonPart");
static_assert(offsetof(FAtomPrimitiveCommonPart, UnscaledInstances) == 0x0, "Offset mismatch for FAtomPrimitiveCommonPart::UnscaledInstances");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FAtomPrimitivePhysicsAttributes
{
    FMatrix InertiaTensor; // 0x0 (Size: 0x80, Type: StructProperty)
    FVector CenterOfMass; // 0x80 (Size: 0x18, Type: StructProperty)
    float Mass; // 0x98 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAtomPrimitivePhysicsAttributes) == 0xa0, "Size mismatch for FAtomPrimitivePhysicsAttributes");
static_assert(offsetof(FAtomPrimitivePhysicsAttributes, InertiaTensor) == 0x0, "Offset mismatch for FAtomPrimitivePhysicsAttributes::InertiaTensor");
static_assert(offsetof(FAtomPrimitivePhysicsAttributes, CenterOfMass) == 0x80, "Offset mismatch for FAtomPrimitivePhysicsAttributes::CenterOfMass");
static_assert(offsetof(FAtomPrimitivePhysicsAttributes, Mass) == 0x98, "Offset mismatch for FAtomPrimitivePhysicsAttributes::Mass");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FAtomPrimitiveUserNote
{
    FString Text; // 0x0 (Size: 0x10, Type: StrProperty)
    FString PartRevision; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FAtomPrimitiveUserNote) == 0x20, "Size mismatch for FAtomPrimitiveUserNote");
static_assert(offsetof(FAtomPrimitiveUserNote, Text) == 0x0, "Offset mismatch for FAtomPrimitiveUserNote::Text");
static_assert(offsetof(FAtomPrimitiveUserNote, PartRevision) == 0x10, "Offset mismatch for FAtomPrimitiveUserNote::PartRevision");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FAtomPrimitiveOptimizationSettings
{
    uint8_t OptimizationType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    uint8_t GeometryOptions[0x4]; // 0x4 (Size: 0x4, Type: EnumProperty)
    uint8_t ApproximationShapeType; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    uint8_t ApproximationStrategy[0x4]; // 0xc (Size: 0x4, Type: EnumProperty)
    bool bUseOptimizationAxisOverride; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FVector ApproximationAxisOverride; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FAtomPrimitiveOptimizationSettings) == 0x30, "Size mismatch for FAtomPrimitiveOptimizationSettings");
static_assert(offsetof(FAtomPrimitiveOptimizationSettings, OptimizationType) == 0x0, "Offset mismatch for FAtomPrimitiveOptimizationSettings::OptimizationType");
static_assert(offsetof(FAtomPrimitiveOptimizationSettings, GeometryOptions) == 0x4, "Offset mismatch for FAtomPrimitiveOptimizationSettings::GeometryOptions");
static_assert(offsetof(FAtomPrimitiveOptimizationSettings, ApproximationShapeType) == 0x8, "Offset mismatch for FAtomPrimitiveOptimizationSettings::ApproximationShapeType");
static_assert(offsetof(FAtomPrimitiveOptimizationSettings, ApproximationStrategy) == 0xc, "Offset mismatch for FAtomPrimitiveOptimizationSettings::ApproximationStrategy");
static_assert(offsetof(FAtomPrimitiveOptimizationSettings, bUseOptimizationAxisOverride) == 0x10, "Offset mismatch for FAtomPrimitiveOptimizationSettings::bUseOptimizationAxisOverride");
static_assert(offsetof(FAtomPrimitiveOptimizationSettings, ApproximationAxisOverride) == 0x18, "Offset mismatch for FAtomPrimitiveOptimizationSettings::ApproximationAxisOverride");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FAtomPrimitiveStyleImportData
{
    FString Revision; // 0x0 (Size: 0x10, Type: StrProperty)
    uint8_t DatabaseSourceType; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FString SourceDatabase; // 0x18 (Size: 0x10, Type: StrProperty)
    int32_t ImportWarnings; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAtomPrimitiveStyleImportData) == 0x30, "Size mismatch for FAtomPrimitiveStyleImportData");
static_assert(offsetof(FAtomPrimitiveStyleImportData, Revision) == 0x0, "Offset mismatch for FAtomPrimitiveStyleImportData::Revision");
static_assert(offsetof(FAtomPrimitiveStyleImportData, DatabaseSourceType) == 0x10, "Offset mismatch for FAtomPrimitiveStyleImportData::DatabaseSourceType");
static_assert(offsetof(FAtomPrimitiveStyleImportData, SourceDatabase) == 0x18, "Offset mismatch for FAtomPrimitiveStyleImportData::SourceDatabase");
static_assert(offsetof(FAtomPrimitiveStyleImportData, ImportWarnings) == 0x28, "Offset mismatch for FAtomPrimitiveStyleImportData::ImportWarnings");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FAtomPrimitiveDetailTextureData
{
    TSoftObjectPtr<UTexture*> Texture; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FName Style; // 0x20 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TArray<int32_t> Lods; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t GeometrySection; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t TextureType; // 0x39 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3a[0x6]; // 0x3a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FAtomPrimitiveDetailTextureData) == 0x40, "Size mismatch for FAtomPrimitiveDetailTextureData");
static_assert(offsetof(FAtomPrimitiveDetailTextureData, Texture) == 0x0, "Offset mismatch for FAtomPrimitiveDetailTextureData::Texture");
static_assert(offsetof(FAtomPrimitiveDetailTextureData, Style) == 0x20, "Offset mismatch for FAtomPrimitiveDetailTextureData::Style");
static_assert(offsetof(FAtomPrimitiveDetailTextureData, Lods) == 0x28, "Offset mismatch for FAtomPrimitiveDetailTextureData::Lods");
static_assert(offsetof(FAtomPrimitiveDetailTextureData, GeometrySection) == 0x38, "Offset mismatch for FAtomPrimitiveDetailTextureData::GeometrySection");
static_assert(offsetof(FAtomPrimitiveDetailTextureData, TextureType) == 0x39, "Offset mismatch for FAtomPrimitiveDetailTextureData::TextureType");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FAtomPrimitiveBevelOptions
{
};

static_assert(sizeof(FAtomPrimitiveBevelOptions) == 0x1, "Size mismatch for FAtomPrimitiveBevelOptions");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FAtomPrimitiveBuildOptions
{
};

static_assert(sizeof(FAtomPrimitiveBuildOptions) == 0x1, "Size mismatch for FAtomPrimitiveBuildOptions");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FAtomPrimitiveBuildSettings
{
};

static_assert(sizeof(FAtomPrimitiveBuildSettings) == 0x1, "Size mismatch for FAtomPrimitiveBuildSettings");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FConnectivityFieldConnection
{
    FConnectivityFieldReference Reference; // 0x0 (Size: 0x8, Type: StructProperty)
    uint8_t ConnectResult; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FConnectivityFieldConnection) == 0xc, "Size mismatch for FConnectivityFieldConnection");
static_assert(offsetof(FConnectivityFieldConnection, Reference) == 0x0, "Offset mismatch for FConnectivityFieldConnection::Reference");
static_assert(offsetof(FConnectivityFieldConnection, ConnectResult) == 0x8, "Offset mismatch for FConnectivityFieldConnection::ConnectResult");

// Size: 0x18 (Inherited: 0x11, Single: 0x7)
struct FHingeFieldConnectionInfo : FPointFieldConnectionInfo
{
    bool Flip; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FHingeFieldConnectionInfo) == 0x18, "Size mismatch for FHingeFieldConnectionInfo");
static_assert(offsetof(FHingeFieldConnectionInfo, Flip) == 0x10, "Offset mismatch for FHingeFieldConnectionInfo::Flip");

