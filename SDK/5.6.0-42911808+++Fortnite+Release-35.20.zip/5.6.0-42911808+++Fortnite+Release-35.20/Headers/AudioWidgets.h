/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioWidgets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "SlateCore.h"
#include "Engine.h"

// Size: 0x208 (Inherited: 0x1a8, Single: 0x60)
class UAudioMaterialButton : public UWidget
{
public:
    FAudioMaterialButtonStyle WidgetStyle; // 0x158 (Size: 0x88, Type: StructProperty)
    uint8_t OnButtonPressedChangedEvent[0x10]; // 0x1e0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bIsPressed; // 0x1f0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f1[0x17]; // 0x1f1 (Size: 0x17, Type: PaddingProperty)

public:
    bool GetIsPressed() const; // 0xd278f14 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetIsPressed(bool& InPressed); // 0xfd6aa54 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioMaterialButton) == 0x208, "Size mismatch for UAudioMaterialButton");
static_assert(offsetof(UAudioMaterialButton, WidgetStyle) == 0x158, "Offset mismatch for UAudioMaterialButton::WidgetStyle");
static_assert(offsetof(UAudioMaterialButton, OnButtonPressedChangedEvent) == 0x1e0, "Offset mismatch for UAudioMaterialButton::OnButtonPressedChangedEvent");
static_assert(offsetof(UAudioMaterialButton, bIsPressed) == 0x1f0, "Offset mismatch for UAudioMaterialButton::bIsPressed");

// Size: 0x1d8 (Inherited: 0x1a8, Single: 0x30)
class UAudioMaterialEnvelope : public UWidget
{
public:
    FAudioMaterialEnvelopeStyle WidgetStyle; // 0x158 (Size: 0x48, Type: StructProperty)
    FAudioMaterialEnvelopeSettings EnvelopeSettings; // 0x1a0 (Size: 0x24, Type: StructProperty)
    uint8_t Pad_1c4[0x14]; // 0x1c4 (Size: 0x14, Type: PaddingProperty)
};

static_assert(sizeof(UAudioMaterialEnvelope) == 0x1d8, "Size mismatch for UAudioMaterialEnvelope");
static_assert(offsetof(UAudioMaterialEnvelope, WidgetStyle) == 0x158, "Offset mismatch for UAudioMaterialEnvelope::WidgetStyle");
static_assert(offsetof(UAudioMaterialEnvelope, EnvelopeSettings) == 0x1a0, "Offset mismatch for UAudioMaterialEnvelope::EnvelopeSettings");

// Size: 0x360 (Inherited: 0x1a8, Single: 0x1b8)
class UAudioMaterialKnob : public UWidget
{
public:
    uint8_t Pad_158[0x8]; // 0x158 (Size: 0x8, Type: PaddingProperty)
    FAudioMaterialKnobStyle WidgetStyle; // 0x160 (Size: 0x1c0, Type: StructProperty)
    uint8_t OnKnobValueChanged[0x10]; // 0x320 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float Value; // 0x330 (Size: 0x4, Type: FloatProperty)
    float TuneSpeed; // 0x334 (Size: 0x4, Type: FloatProperty)
    float FineTuneSpeed; // 0x338 (Size: 0x4, Type: FloatProperty)
    bool bLocked; // 0x33c (Size: 0x1, Type: BoolProperty)
    bool bMouseUsesStep; // 0x33d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_33e[0x2]; // 0x33e (Size: 0x2, Type: PaddingProperty)
    float StepSize; // 0x340 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_344[0x1c]; // 0x344 (Size: 0x1c, Type: PaddingProperty)

public:
    float GetFineTuneSpeed() const; // 0xec26094 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsLocked() const; // 0xfd6a738 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetMouseUsesStep() const; // 0xfd6a7b4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStepSize() const; // 0xa51c7a0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTuneSpeed() const; // 0xfd6a7e4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetValue(); // 0xf36ab8c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    void SetFineTuneSpeed(float& InValue); // 0xfd6a7fc (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void SetLocked(bool& InLocked); // 0xfd6ab98 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void SetMouseUsesStep(bool& InUsesStep); // 0xfd6b130 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void SetStepSize(float& InValue); // 0xfd6b418 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void SetTuneSpeed(float& InValue); // 0xfd6b670 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void SetValue(float& InValue); // 0xfd6b8c8 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioMaterialKnob) == 0x360, "Size mismatch for UAudioMaterialKnob");
static_assert(offsetof(UAudioMaterialKnob, WidgetStyle) == 0x160, "Offset mismatch for UAudioMaterialKnob::WidgetStyle");
static_assert(offsetof(UAudioMaterialKnob, OnKnobValueChanged) == 0x320, "Offset mismatch for UAudioMaterialKnob::OnKnobValueChanged");
static_assert(offsetof(UAudioMaterialKnob, Value) == 0x330, "Offset mismatch for UAudioMaterialKnob::Value");
static_assert(offsetof(UAudioMaterialKnob, TuneSpeed) == 0x334, "Offset mismatch for UAudioMaterialKnob::TuneSpeed");
static_assert(offsetof(UAudioMaterialKnob, FineTuneSpeed) == 0x338, "Offset mismatch for UAudioMaterialKnob::FineTuneSpeed");
static_assert(offsetof(UAudioMaterialKnob, bLocked) == 0x33c, "Offset mismatch for UAudioMaterialKnob::bLocked");
static_assert(offsetof(UAudioMaterialKnob, bMouseUsesStep) == 0x33d, "Offset mismatch for UAudioMaterialKnob::bMouseUsesStep");
static_assert(offsetof(UAudioMaterialKnob, StepSize) == 0x340, "Offset mismatch for UAudioMaterialKnob::StepSize");

// Size: 0x270 (Inherited: 0x1a8, Single: 0xc8)
class UAudioMaterialMeter : public UWidget
{
public:
    FAudioMaterialMeterStyle WidgetStyle; // 0x158 (Size: 0xe8, Type: StructProperty)
    TEnumAsByte<EOrientation> orientation; // 0x240 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_241[0x3]; // 0x241 (Size: 0x3, Type: PaddingProperty)
    uint8_t MeterChannelInfoDelegate[0xc]; // 0x244 (Size: 0xc, Type: DelegateProperty)
    uint8_t Pad_250[0x10]; // 0x250 (Size: 0x10, Type: PaddingProperty)
    TArray<FMeterChannelInfo> MeterChannelInfo; // 0x260 (Size: 0x10, Type: ArrayProperty)

public:
    TArray<FMeterChannelInfo> GetMeterChannelInfo() const; // 0xfd6a750 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FMeterChannelInfo> GetMeterChannelInfo__DelegateSignature(); // 0x288a61c (Index: 0x1, Flags: Public|Delegate)
    void SetMeterChannelInfo(const TArray<FMeterChannelInfo> InMeterChannelInfo); // 0xfd6ae80 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAudioMaterialMeter) == 0x270, "Size mismatch for UAudioMaterialMeter");
static_assert(offsetof(UAudioMaterialMeter, WidgetStyle) == 0x158, "Offset mismatch for UAudioMaterialMeter::WidgetStyle");
static_assert(offsetof(UAudioMaterialMeter, orientation) == 0x240, "Offset mismatch for UAudioMaterialMeter::orientation");
static_assert(offsetof(UAudioMaterialMeter, MeterChannelInfoDelegate) == 0x244, "Offset mismatch for UAudioMaterialMeter::MeterChannelInfoDelegate");
static_assert(offsetof(UAudioMaterialMeter, MeterChannelInfo) == 0x260, "Offset mismatch for UAudioMaterialMeter::MeterChannelInfo");

// Size: 0x2f0 (Inherited: 0x1a8, Single: 0x148)
class UAudioMaterialSlider : public UWidget
{
public:
    uint8_t Pad_158[0x8]; // 0x158 (Size: 0x8, Type: PaddingProperty)
    FAudioMaterialSliderStyle WidgetStyle; // 0x160 (Size: 0x150, Type: StructProperty)
    uint8_t OnValueChanged[0x10]; // 0x2b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float Value; // 0x2c0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EOrientation> orientation; // 0x2c4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_2c5[0x3]; // 0x2c5 (Size: 0x3, Type: PaddingProperty)
    float TuneSpeed; // 0x2c8 (Size: 0x4, Type: FloatProperty)
    float FineTuneSpeed; // 0x2cc (Size: 0x4, Type: FloatProperty)
    bool bLocked; // 0x2d0 (Size: 0x1, Type: BoolProperty)
    bool bMouseUsesStep; // 0x2d1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d2[0x2]; // 0x2d2 (Size: 0x2, Type: PaddingProperty)
    float StepSize; // 0x2d4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2d8[0x18]; // 0x2d8 (Size: 0x18, Type: PaddingProperty)

public:
    float GetFineTuneSpeed() const; // 0xdb22e60 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsLocked() const; // 0xd27aa48 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetMouseUsesStep() const; // 0xd9edde4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStepSize() const; // 0xfd6a7cc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTuneSpeed() const; // 0x9eea950 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetValue() const; // 0xa409490 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetFineTuneSpeed(float& const InValue); // 0xfd6a928 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void SetLocked(bool& bInLocked); // 0xfd6ad0c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void SetMouseUsesStep(bool& bInUsesStep); // 0xfd6b2a4 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void SetStepSize(float& InValue); // 0xfd6b544 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void SetTuneSpeed(float& const InValue); // 0xfd6b79c (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void SetValue(float& InValue); // 0xfd6b9f4 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioMaterialSlider) == 0x2f0, "Size mismatch for UAudioMaterialSlider");
static_assert(offsetof(UAudioMaterialSlider, WidgetStyle) == 0x160, "Offset mismatch for UAudioMaterialSlider::WidgetStyle");
static_assert(offsetof(UAudioMaterialSlider, OnValueChanged) == 0x2b0, "Offset mismatch for UAudioMaterialSlider::OnValueChanged");
static_assert(offsetof(UAudioMaterialSlider, Value) == 0x2c0, "Offset mismatch for UAudioMaterialSlider::Value");
static_assert(offsetof(UAudioMaterialSlider, orientation) == 0x2c4, "Offset mismatch for UAudioMaterialSlider::orientation");
static_assert(offsetof(UAudioMaterialSlider, TuneSpeed) == 0x2c8, "Offset mismatch for UAudioMaterialSlider::TuneSpeed");
static_assert(offsetof(UAudioMaterialSlider, FineTuneSpeed) == 0x2cc, "Offset mismatch for UAudioMaterialSlider::FineTuneSpeed");
static_assert(offsetof(UAudioMaterialSlider, bLocked) == 0x2d0, "Offset mismatch for UAudioMaterialSlider::bLocked");
static_assert(offsetof(UAudioMaterialSlider, bMouseUsesStep) == 0x2d1, "Offset mismatch for UAudioMaterialSlider::bMouseUsesStep");
static_assert(offsetof(UAudioMaterialSlider, StepSize) == 0x2d4, "Offset mismatch for UAudioMaterialSlider::StepSize");

// Size: 0x1f0 (Inherited: 0x58, Single: 0x198)
class UAudioMaterialKnobWidgetStyle : public USlateWidgetStyleContainerBase
{
public:
    FAudioMaterialKnobStyle KnobStyle; // 0x30 (Size: 0x1c0, Type: StructProperty)
};

static_assert(sizeof(UAudioMaterialKnobWidgetStyle) == 0x1f0, "Size mismatch for UAudioMaterialKnobWidgetStyle");
static_assert(offsetof(UAudioMaterialKnobWidgetStyle, KnobStyle) == 0x30, "Offset mismatch for UAudioMaterialKnobWidgetStyle::KnobStyle");

// Size: 0x118 (Inherited: 0x58, Single: 0xc0)
class UAudioMaterialMeterWidgetStyle : public USlateWidgetStyleContainerBase
{
public:
    FAudioMaterialMeterStyle MeterStyle; // 0x30 (Size: 0xe8, Type: StructProperty)
};

static_assert(sizeof(UAudioMaterialMeterWidgetStyle) == 0x118, "Size mismatch for UAudioMaterialMeterWidgetStyle");
static_assert(offsetof(UAudioMaterialMeterWidgetStyle, MeterStyle) == 0x30, "Offset mismatch for UAudioMaterialMeterWidgetStyle::MeterStyle");

// Size: 0xb8 (Inherited: 0x58, Single: 0x60)
class UAudioMaterialButtonWidgetStyle : public USlateWidgetStyleContainerBase
{
public:
    FAudioMaterialButtonStyle ButtonStyle; // 0x30 (Size: 0x88, Type: StructProperty)
};

static_assert(sizeof(UAudioMaterialButtonWidgetStyle) == 0xb8, "Size mismatch for UAudioMaterialButtonWidgetStyle");
static_assert(offsetof(UAudioMaterialButtonWidgetStyle, ButtonStyle) == 0x30, "Offset mismatch for UAudioMaterialButtonWidgetStyle::ButtonStyle");

// Size: 0x180 (Inherited: 0x58, Single: 0x128)
class UAudioMaterialSliderWidgetStyle : public USlateWidgetStyleContainerBase
{
public:
    FAudioMaterialSliderStyle SliderStyle; // 0x30 (Size: 0x150, Type: StructProperty)
};

static_assert(sizeof(UAudioMaterialSliderWidgetStyle) == 0x180, "Size mismatch for UAudioMaterialSliderWidgetStyle");
static_assert(offsetof(UAudioMaterialSliderWidgetStyle, SliderStyle) == 0x30, "Offset mismatch for UAudioMaterialSliderWidgetStyle::SliderStyle");

// Size: 0x640 (Inherited: 0x1a8, Single: 0x498)
class UAudioMeter : public UWidget
{
public:
    TArray<FMeterChannelInfo> MeterChannelInfo; // 0x158 (Size: 0x10, Type: ArrayProperty)
    uint8_t MeterChannelInfoDelegate[0xc]; // 0x168 (Size: 0xc, Type: DelegateProperty)
    uint8_t Pad_174[0xc]; // 0x174 (Size: 0xc, Type: PaddingProperty)
    FAudioMeterStyle WidgetStyle; // 0x180 (Size: 0x430, Type: StructProperty)
    TEnumAsByte<EOrientation> orientation; // 0x5b0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_5b1[0x3]; // 0x5b1 (Size: 0x3, Type: PaddingProperty)
    FLinearColor BackgroundColor; // 0x5b4 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterBackgroundColor; // 0x5c4 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterValueColor; // 0x5d4 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterPeakColor; // 0x5e4 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterClippingColor; // 0x5f4 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterScaleColor; // 0x604 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterScaleLabelColor; // 0x614 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_624[0x1c]; // 0x624 (Size: 0x1c, Type: PaddingProperty)

public:
    TArray<FMeterChannelInfo> GetMeterChannelInfo() const; // 0xfda6a70 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FMeterChannelInfo> GetMeterChannelInfo__DelegateSignature(); // 0x288a61c (Index: 0x1, Flags: Public|Delegate)
    void SetBackgroundColor(FLinearColor& InValue); // 0xfda6ea0 (Index: 0x2, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetMeterBackgroundColor(FLinearColor& InValue); // 0xfda7124 (Index: 0x3, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetMeterChannelInfo(const TArray<FMeterChannelInfo> InMeterChannelInfo); // 0xfda7200 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetMeterClippingColor(FLinearColor& InValue); // 0xfda74b0 (Index: 0x5, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetMeterPeakColor(FLinearColor& InValue); // 0xfda758c (Index: 0x6, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetMeterScaleColor(FLinearColor& InValue); // 0xfda7668 (Index: 0x7, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetMeterScaleLabelColor(FLinearColor& InValue); // 0xfda7744 (Index: 0x8, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetMeterValueColor(FLinearColor& InValue); // 0xfda7820 (Index: 0x9, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAudioMeter) == 0x640, "Size mismatch for UAudioMeter");
static_assert(offsetof(UAudioMeter, MeterChannelInfo) == 0x158, "Offset mismatch for UAudioMeter::MeterChannelInfo");
static_assert(offsetof(UAudioMeter, MeterChannelInfoDelegate) == 0x168, "Offset mismatch for UAudioMeter::MeterChannelInfoDelegate");
static_assert(offsetof(UAudioMeter, WidgetStyle) == 0x180, "Offset mismatch for UAudioMeter::WidgetStyle");
static_assert(offsetof(UAudioMeter, orientation) == 0x5b0, "Offset mismatch for UAudioMeter::orientation");
static_assert(offsetof(UAudioMeter, BackgroundColor) == 0x5b4, "Offset mismatch for UAudioMeter::BackgroundColor");
static_assert(offsetof(UAudioMeter, MeterBackgroundColor) == 0x5c4, "Offset mismatch for UAudioMeter::MeterBackgroundColor");
static_assert(offsetof(UAudioMeter, MeterValueColor) == 0x5d4, "Offset mismatch for UAudioMeter::MeterValueColor");
static_assert(offsetof(UAudioMeter, MeterPeakColor) == 0x5e4, "Offset mismatch for UAudioMeter::MeterPeakColor");
static_assert(offsetof(UAudioMeter, MeterClippingColor) == 0x5f4, "Offset mismatch for UAudioMeter::MeterClippingColor");
static_assert(offsetof(UAudioMeter, MeterScaleColor) == 0x604, "Offset mismatch for UAudioMeter::MeterScaleColor");
static_assert(offsetof(UAudioMeter, MeterScaleLabelColor) == 0x614, "Offset mismatch for UAudioMeter::MeterScaleLabelColor");

// Size: 0x620 (Inherited: 0x1a8, Single: 0x478)
class UAudioOscilloscope : public UWidget
{
public:
    uint8_t Pad_158[0x8]; // 0x158 (Size: 0x8, Type: PaddingProperty)
    FAudioOscilloscopePanelStyle OscilloscopeStyle; // 0x160 (Size: 0x440, Type: StructProperty)
    UAudioBus* AudioBus; // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    float MaxTimeWindowMs; // 0x5a8 (Size: 0x4, Type: FloatProperty)
    float TimeWindowMs; // 0x5ac (Size: 0x4, Type: FloatProperty)
    float AnalysisPeriodMs; // 0x5b0 (Size: 0x4, Type: FloatProperty)
    bool bShowTimeGrid; // 0x5b4 (Size: 0x1, Type: BoolProperty)
    uint8_t TimeGridLabelsUnit; // 0x5b5 (Size: 0x1, Type: EnumProperty)
    bool bShowAmplitudeGrid; // 0x5b6 (Size: 0x1, Type: BoolProperty)
    bool bShowAmplitudeLabels; // 0x5b7 (Size: 0x1, Type: BoolProperty)
    uint8_t AmplitudeGridLabelsUnit; // 0x5b8 (Size: 0x1, Type: EnumProperty)
    uint8_t TriggerMode; // 0x5b9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5ba[0x2]; // 0x5ba (Size: 0x2, Type: PaddingProperty)
    float TriggerThreshold; // 0x5bc (Size: 0x4, Type: FloatProperty)
    uint8_t PanelLayoutType; // 0x5c0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5c1[0x3]; // 0x5c1 (Size: 0x3, Type: PaddingProperty)
    int32_t ChannelToAnalyze; // 0x5c4 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_5c8[0x58]; // 0x5c8 (Size: 0x58, Type: PaddingProperty)

public:
    TArray<float> GetOscilloscopeAudioSamples__DelegateSignature(); // 0x288a61c (Index: 0x1, Flags: Public|Delegate)
    void StartProcessing(); // 0xfda8f40 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void StopProcessing(); // 0xfda8f90 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)

private:
    bool CanTriggeringBeSet(); // 0xfda6914 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UAudioOscilloscope) == 0x620, "Size mismatch for UAudioOscilloscope");
static_assert(offsetof(UAudioOscilloscope, OscilloscopeStyle) == 0x160, "Offset mismatch for UAudioOscilloscope::OscilloscopeStyle");
static_assert(offsetof(UAudioOscilloscope, AudioBus) == 0x5a0, "Offset mismatch for UAudioOscilloscope::AudioBus");
static_assert(offsetof(UAudioOscilloscope, MaxTimeWindowMs) == 0x5a8, "Offset mismatch for UAudioOscilloscope::MaxTimeWindowMs");
static_assert(offsetof(UAudioOscilloscope, TimeWindowMs) == 0x5ac, "Offset mismatch for UAudioOscilloscope::TimeWindowMs");
static_assert(offsetof(UAudioOscilloscope, AnalysisPeriodMs) == 0x5b0, "Offset mismatch for UAudioOscilloscope::AnalysisPeriodMs");
static_assert(offsetof(UAudioOscilloscope, bShowTimeGrid) == 0x5b4, "Offset mismatch for UAudioOscilloscope::bShowTimeGrid");
static_assert(offsetof(UAudioOscilloscope, TimeGridLabelsUnit) == 0x5b5, "Offset mismatch for UAudioOscilloscope::TimeGridLabelsUnit");
static_assert(offsetof(UAudioOscilloscope, bShowAmplitudeGrid) == 0x5b6, "Offset mismatch for UAudioOscilloscope::bShowAmplitudeGrid");
static_assert(offsetof(UAudioOscilloscope, bShowAmplitudeLabels) == 0x5b7, "Offset mismatch for UAudioOscilloscope::bShowAmplitudeLabels");
static_assert(offsetof(UAudioOscilloscope, AmplitudeGridLabelsUnit) == 0x5b8, "Offset mismatch for UAudioOscilloscope::AmplitudeGridLabelsUnit");
static_assert(offsetof(UAudioOscilloscope, TriggerMode) == 0x5b9, "Offset mismatch for UAudioOscilloscope::TriggerMode");
static_assert(offsetof(UAudioOscilloscope, TriggerThreshold) == 0x5bc, "Offset mismatch for UAudioOscilloscope::TriggerThreshold");
static_assert(offsetof(UAudioOscilloscope, PanelLayoutType) == 0x5c0, "Offset mismatch for UAudioOscilloscope::PanelLayoutType");
static_assert(offsetof(UAudioOscilloscope, ChannelToAnalyze) == 0x5c4, "Offset mismatch for UAudioOscilloscope::ChannelToAnalyze");

// Size: 0x350 (Inherited: 0x1a8, Single: 0x1a8)
class UAudioRadialSlider : public UWidget
{
public:
    float Value; // 0x158 (Size: 0x4, Type: FloatProperty)
    uint8_t ValueDelegate[0xc]; // 0x15c (Size: 0xc, Type: DelegateProperty)
    TEnumAsByte<EAudioRadialSliderLayout> WidgetLayout; // 0x168 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_169[0x3]; // 0x169 (Size: 0x3, Type: PaddingProperty)
    FLinearColor CenterBackgroundColor; // 0x16c (Size: 0x10, Type: StructProperty)
    FLinearColor SliderProgressColor; // 0x17c (Size: 0x10, Type: StructProperty)
    FLinearColor SliderBarColor; // 0x18c (Size: 0x10, Type: StructProperty)
    uint8_t Pad_19c[0x4]; // 0x19c (Size: 0x4, Type: PaddingProperty)
    FVector2D HandStartEndRatio; // 0x1a0 (Size: 0x10, Type: StructProperty)
    FText UnitsText; // 0x1b0 (Size: 0x10, Type: TextProperty)
    FLinearColor TextLabelBackgroundColor; // 0x1c0 (Size: 0x10, Type: StructProperty)
    bool ShowLabelOnlyOnHover; // 0x1d0 (Size: 0x1, Type: BoolProperty)
    bool ShowUnitsText; // 0x1d1 (Size: 0x1, Type: BoolProperty)
    bool IsUnitsTextReadOnly; // 0x1d2 (Size: 0x1, Type: BoolProperty)
    bool IsValueTextReadOnly; // 0x1d3 (Size: 0x1, Type: BoolProperty)
    float SliderThickness; // 0x1d4 (Size: 0x4, Type: FloatProperty)
    FVector2D OutputRange; // 0x1d8 (Size: 0x10, Type: StructProperty)
    uint8_t OnValueChanged[0x10]; // 0x1e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    float GetOutputValue(float& const InSliderValue); // 0xfda6ad4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    float GetSliderValue(float& const OutputValue); // 0xfda6d5c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void SetCenterBackgroundColor(FLinearColor& InValue); // 0xfda6f7c (Index: 0x2, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetHandStartEndRatio(FVector2D& const InHandStartEndRatio); // 0xfda7058 (Index: 0x3, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetOutputRange(FVector2D& const InOutputRange); // 0xfda78fc (Index: 0x4, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetShowLabelOnlyOnHover(bool& const bShowLabelOnlyOnHover); // 0xfda79cc (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetShowUnitsText(bool& const bShowUnitsText); // 0xfda7c34 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void SetSliderBarColor(FLinearColor& InValue); // 0xfda7f78 (Index: 0x7, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetSliderProgressColor(FLinearColor& InValue); // 0xfda8130 (Index: 0x8, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetSliderThickness(float& const InThickness); // 0xfda820c (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void SetTextLabelBackgroundColor(FSlateColor& InColor); // 0xfda8418 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void SetUnitsText(FText& const Units); // 0xfda85d8 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void SetUnitsTextReadOnly(bool& const bIsReadOnly); // 0xfda8868 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    void SetValueTextReadOnly(bool& const bIsReadOnly); // 0xfda8ad0 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    void SetWidgetLayout(TEnumAsByte<EAudioRadialSliderLayout>& InLayout); // 0xfda8e14 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioRadialSlider) == 0x350, "Size mismatch for UAudioRadialSlider");
static_assert(offsetof(UAudioRadialSlider, Value) == 0x158, "Offset mismatch for UAudioRadialSlider::Value");
static_assert(offsetof(UAudioRadialSlider, ValueDelegate) == 0x15c, "Offset mismatch for UAudioRadialSlider::ValueDelegate");
static_assert(offsetof(UAudioRadialSlider, WidgetLayout) == 0x168, "Offset mismatch for UAudioRadialSlider::WidgetLayout");
static_assert(offsetof(UAudioRadialSlider, CenterBackgroundColor) == 0x16c, "Offset mismatch for UAudioRadialSlider::CenterBackgroundColor");
static_assert(offsetof(UAudioRadialSlider, SliderProgressColor) == 0x17c, "Offset mismatch for UAudioRadialSlider::SliderProgressColor");
static_assert(offsetof(UAudioRadialSlider, SliderBarColor) == 0x18c, "Offset mismatch for UAudioRadialSlider::SliderBarColor");
static_assert(offsetof(UAudioRadialSlider, HandStartEndRatio) == 0x1a0, "Offset mismatch for UAudioRadialSlider::HandStartEndRatio");
static_assert(offsetof(UAudioRadialSlider, UnitsText) == 0x1b0, "Offset mismatch for UAudioRadialSlider::UnitsText");
static_assert(offsetof(UAudioRadialSlider, TextLabelBackgroundColor) == 0x1c0, "Offset mismatch for UAudioRadialSlider::TextLabelBackgroundColor");
static_assert(offsetof(UAudioRadialSlider, ShowLabelOnlyOnHover) == 0x1d0, "Offset mismatch for UAudioRadialSlider::ShowLabelOnlyOnHover");
static_assert(offsetof(UAudioRadialSlider, ShowUnitsText) == 0x1d1, "Offset mismatch for UAudioRadialSlider::ShowUnitsText");
static_assert(offsetof(UAudioRadialSlider, IsUnitsTextReadOnly) == 0x1d2, "Offset mismatch for UAudioRadialSlider::IsUnitsTextReadOnly");
static_assert(offsetof(UAudioRadialSlider, IsValueTextReadOnly) == 0x1d3, "Offset mismatch for UAudioRadialSlider::IsValueTextReadOnly");
static_assert(offsetof(UAudioRadialSlider, SliderThickness) == 0x1d4, "Offset mismatch for UAudioRadialSlider::SliderThickness");
static_assert(offsetof(UAudioRadialSlider, OutputRange) == 0x1d8, "Offset mismatch for UAudioRadialSlider::OutputRange");
static_assert(offsetof(UAudioRadialSlider, OnValueChanged) == 0x1e8, "Offset mismatch for UAudioRadialSlider::OnValueChanged");

// Size: 0x350 (Inherited: 0x4f8, Single: 0xfffffe58)
class UAudioVolumeRadialSlider : public UAudioRadialSlider
{
public:
};

static_assert(sizeof(UAudioVolumeRadialSlider) == 0x350, "Size mismatch for UAudioVolumeRadialSlider");

// Size: 0x350 (Inherited: 0x4f8, Single: 0xfffffe58)
class UAudioFrequencyRadialSlider : public UAudioRadialSlider
{
public:
};

static_assert(sizeof(UAudioFrequencyRadialSlider) == 0x350, "Size mismatch for UAudioFrequencyRadialSlider");

// Size: 0x880 (Inherited: 0x1a8, Single: 0x6d8)
class UAudioSliderBase : public UWidget
{
public:
    float Value; // 0x158 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_15c[0x4]; // 0x15c (Size: 0x4, Type: PaddingProperty)
    FText UnitsText; // 0x160 (Size: 0x10, Type: TextProperty)
    FLinearColor TextLabelBackgroundColor; // 0x170 (Size: 0x10, Type: StructProperty)
    uint8_t TextLabelBackgroundColorDelegate[0xc]; // 0x180 (Size: 0xc, Type: DelegateProperty)
    bool ShowLabelOnlyOnHover; // 0x18c (Size: 0x1, Type: BoolProperty)
    bool ShowUnitsText; // 0x18d (Size: 0x1, Type: BoolProperty)
    bool IsUnitsTextReadOnly; // 0x18e (Size: 0x1, Type: BoolProperty)
    bool IsValueTextReadOnly; // 0x18f (Size: 0x1, Type: BoolProperty)
    uint8_t ValueDelegate[0xc]; // 0x190 (Size: 0xc, Type: DelegateProperty)
    FLinearColor SliderBackgroundColor; // 0x19c (Size: 0x10, Type: StructProperty)
    uint8_t SliderBackgroundColorDelegate[0xc]; // 0x1ac (Size: 0xc, Type: DelegateProperty)
    FLinearColor SliderBarColor; // 0x1b8 (Size: 0x10, Type: StructProperty)
    uint8_t SliderBarColorDelegate[0xc]; // 0x1c8 (Size: 0xc, Type: DelegateProperty)
    FLinearColor SliderThumbColor; // 0x1d4 (Size: 0x10, Type: StructProperty)
    uint8_t SliderThumbColorDelegate[0xc]; // 0x1e4 (Size: 0xc, Type: DelegateProperty)
    FLinearColor WidgetBackgroundColor; // 0x1f0 (Size: 0x10, Type: StructProperty)
    uint8_t WidgetBackgroundColorDelegate[0xc]; // 0x200 (Size: 0xc, Type: DelegateProperty)
    TEnumAsByte<EOrientation> orientation; // 0x20c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_20d[0x3]; // 0x20d (Size: 0x3, Type: PaddingProperty)
    uint8_t OnValueChanged[0x10]; // 0x210 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_220[0x660]; // 0x220 (Size: 0x660, Type: PaddingProperty)

public:
    float GetLinValue(float& const OutputValue); // 0xfda6934 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    float GetOutputValue(float& const InSliderValue); // 0xfda6c18 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    float GetSliderValue(float& const OutputValue); // 0xfda6934 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void SetShowLabelOnlyOnHover(bool& const bShowLabelOnlyOnHover); // 0xfda7b00 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void SetShowUnitsText(bool& const bShowUnitsText); // 0xfda7d68 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SetSliderBackgroundColor(FLinearColor& InValue); // 0xfda7e9c (Index: 0x5, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetSliderBarColor(FLinearColor& InValue); // 0xfda8054 (Index: 0x6, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetSliderThumbColor(FLinearColor& InValue); // 0xfda833c (Index: 0x7, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetTextLabelBackgroundColor(FSlateColor& InColor); // 0xfda84f8 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void SetUnitsText(FText& const Units); // 0xfda8720 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void SetUnitsTextReadOnly(bool& const bIsReadOnly); // 0xfda899c (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void SetValueTextReadOnly(bool& const bIsReadOnly); // 0xfda8c04 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void SetWidgetBackgroundColor(FLinearColor& InValue); // 0xfda8d38 (Index: 0xc, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAudioSliderBase) == 0x880, "Size mismatch for UAudioSliderBase");
static_assert(offsetof(UAudioSliderBase, Value) == 0x158, "Offset mismatch for UAudioSliderBase::Value");
static_assert(offsetof(UAudioSliderBase, UnitsText) == 0x160, "Offset mismatch for UAudioSliderBase::UnitsText");
static_assert(offsetof(UAudioSliderBase, TextLabelBackgroundColor) == 0x170, "Offset mismatch for UAudioSliderBase::TextLabelBackgroundColor");
static_assert(offsetof(UAudioSliderBase, TextLabelBackgroundColorDelegate) == 0x180, "Offset mismatch for UAudioSliderBase::TextLabelBackgroundColorDelegate");
static_assert(offsetof(UAudioSliderBase, ShowLabelOnlyOnHover) == 0x18c, "Offset mismatch for UAudioSliderBase::ShowLabelOnlyOnHover");
static_assert(offsetof(UAudioSliderBase, ShowUnitsText) == 0x18d, "Offset mismatch for UAudioSliderBase::ShowUnitsText");
static_assert(offsetof(UAudioSliderBase, IsUnitsTextReadOnly) == 0x18e, "Offset mismatch for UAudioSliderBase::IsUnitsTextReadOnly");
static_assert(offsetof(UAudioSliderBase, IsValueTextReadOnly) == 0x18f, "Offset mismatch for UAudioSliderBase::IsValueTextReadOnly");
static_assert(offsetof(UAudioSliderBase, ValueDelegate) == 0x190, "Offset mismatch for UAudioSliderBase::ValueDelegate");
static_assert(offsetof(UAudioSliderBase, SliderBackgroundColor) == 0x19c, "Offset mismatch for UAudioSliderBase::SliderBackgroundColor");
static_assert(offsetof(UAudioSliderBase, SliderBackgroundColorDelegate) == 0x1ac, "Offset mismatch for UAudioSliderBase::SliderBackgroundColorDelegate");
static_assert(offsetof(UAudioSliderBase, SliderBarColor) == 0x1b8, "Offset mismatch for UAudioSliderBase::SliderBarColor");
static_assert(offsetof(UAudioSliderBase, SliderBarColorDelegate) == 0x1c8, "Offset mismatch for UAudioSliderBase::SliderBarColorDelegate");
static_assert(offsetof(UAudioSliderBase, SliderThumbColor) == 0x1d4, "Offset mismatch for UAudioSliderBase::SliderThumbColor");
static_assert(offsetof(UAudioSliderBase, SliderThumbColorDelegate) == 0x1e4, "Offset mismatch for UAudioSliderBase::SliderThumbColorDelegate");
static_assert(offsetof(UAudioSliderBase, WidgetBackgroundColor) == 0x1f0, "Offset mismatch for UAudioSliderBase::WidgetBackgroundColor");
static_assert(offsetof(UAudioSliderBase, WidgetBackgroundColorDelegate) == 0x200, "Offset mismatch for UAudioSliderBase::WidgetBackgroundColorDelegate");
static_assert(offsetof(UAudioSliderBase, orientation) == 0x20c, "Offset mismatch for UAudioSliderBase::orientation");
static_assert(offsetof(UAudioSliderBase, OnValueChanged) == 0x210, "Offset mismatch for UAudioSliderBase::OnValueChanged");

// Size: 0x890 (Inherited: 0xa28, Single: 0xfffffe68)
class UAudioSlider : public UAudioSliderBase
{
public:
    TWeakObjectPtr<UCurveFloat*> LinToOutputCurve; // 0x880 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UCurveFloat*> OutputToLinCurve; // 0x888 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UAudioSlider) == 0x890, "Size mismatch for UAudioSlider");
static_assert(offsetof(UAudioSlider, LinToOutputCurve) == 0x880, "Offset mismatch for UAudioSlider::LinToOutputCurve");
static_assert(offsetof(UAudioSlider, OutputToLinCurve) == 0x888, "Offset mismatch for UAudioSlider::OutputToLinCurve");

// Size: 0x890 (Inherited: 0x12b8, Single: 0xfffff5d8)
class UAudioVolumeSlider : public UAudioSlider
{
public:
};

static_assert(sizeof(UAudioVolumeSlider) == 0x890, "Size mismatch for UAudioVolumeSlider");

// Size: 0x890 (Inherited: 0xa28, Single: 0xfffffe68)
class UAudioFrequencySlider : public UAudioSliderBase
{
public:
    FVector2D OutputRange; // 0x880 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UAudioFrequencySlider) == 0x890, "Size mismatch for UAudioFrequencySlider");
static_assert(offsetof(UAudioFrequencySlider, OutputRange) == 0x880, "Offset mismatch for UAudioFrequencySlider::OutputRange");

// Size: 0x360 (Inherited: 0x1a8, Single: 0x1b8)
class UAudioVectorscope : public UWidget
{
public:
    uint8_t Pad_158[0x8]; // 0x158 (Size: 0x8, Type: PaddingProperty)
    FAudioVectorscopePanelStyle VectorscopeStyle; // 0x160 (Size: 0x190, Type: StructProperty)
    UAudioBus* AudioBus; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    bool bShowGrid; // 0x2f8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2f9[0x3]; // 0x2f9 (Size: 0x3, Type: PaddingProperty)
    int32_t GridDivisions; // 0x2fc (Size: 0x4, Type: IntProperty)
    float MaxDisplayPersistenceMs; // 0x300 (Size: 0x4, Type: FloatProperty)
    float DisplayPersistenceMs; // 0x304 (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x308 (Size: 0x4, Type: FloatProperty)
    uint8_t PanelLayoutType; // 0x30c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_30d[0x53]; // 0x30d (Size: 0x53, Type: PaddingProperty)

public:
    TArray<float> GetVectorscopeAudioSamples__DelegateSignature(); // 0x288a61c (Index: 0x0, Flags: Public|Delegate)
    void StartProcessing(); // 0xfda8f68 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void StopProcessing(); // 0xfda8fb8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioVectorscope) == 0x360, "Size mismatch for UAudioVectorscope");
static_assert(offsetof(UAudioVectorscope, VectorscopeStyle) == 0x160, "Offset mismatch for UAudioVectorscope::VectorscopeStyle");
static_assert(offsetof(UAudioVectorscope, AudioBus) == 0x2f0, "Offset mismatch for UAudioVectorscope::AudioBus");
static_assert(offsetof(UAudioVectorscope, bShowGrid) == 0x2f8, "Offset mismatch for UAudioVectorscope::bShowGrid");
static_assert(offsetof(UAudioVectorscope, GridDivisions) == 0x2fc, "Offset mismatch for UAudioVectorscope::GridDivisions");
static_assert(offsetof(UAudioVectorscope, MaxDisplayPersistenceMs) == 0x300, "Offset mismatch for UAudioVectorscope::MaxDisplayPersistenceMs");
static_assert(offsetof(UAudioVectorscope, DisplayPersistenceMs) == 0x304, "Offset mismatch for UAudioVectorscope::DisplayPersistenceMs");
static_assert(offsetof(UAudioVectorscope, Scale) == 0x308, "Offset mismatch for UAudioVectorscope::Scale");
static_assert(offsetof(UAudioVectorscope, PanelLayoutType) == 0x30c, "Offset mismatch for UAudioVectorscope::PanelLayoutType");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FMeterChannelInfo
{
    float MeterValue; // 0x0 (Size: 0x4, Type: FloatProperty)
    float PeakValue; // 0x4 (Size: 0x4, Type: FloatProperty)
    float ClippingValue; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FMeterChannelInfo) == 0xc, "Size mismatch for FMeterChannelInfo");
static_assert(offsetof(FMeterChannelInfo, MeterValue) == 0x0, "Offset mismatch for FMeterChannelInfo::MeterValue");
static_assert(offsetof(FMeterChannelInfo, PeakValue) == 0x4, "Offset mismatch for FMeterChannelInfo::PeakValue");
static_assert(offsetof(FMeterChannelInfo, ClippingValue) == 0x8, "Offset mismatch for FMeterChannelInfo::ClippingValue");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FAudioMaterialWidgetStyle : FSlateWidgetStyle
{
    UMaterialInterface* Material; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector2f DesiredSize; // 0x10 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FAudioMaterialWidgetStyle) == 0x18, "Size mismatch for FAudioMaterialWidgetStyle");
static_assert(offsetof(FAudioMaterialWidgetStyle, Material) == 0x8, "Offset mismatch for FAudioMaterialWidgetStyle::Material");
static_assert(offsetof(FAudioMaterialWidgetStyle, DesiredSize) == 0x10, "Offset mismatch for FAudioMaterialWidgetStyle::DesiredSize");

// Size: 0xe8 (Inherited: 0x20, Single: 0xc8)
struct FAudioMaterialMeterStyle : FAudioMaterialWidgetStyle
{
    FLinearColor MeterFillMinColor; // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterFillMidColor; // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterFillMaxColor; // 0x38 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterFillBackgroundColor; // 0x48 (Size: 0x10, Type: StructProperty)
    FVector2D MeterPadding; // 0x58 (Size: 0x10, Type: StructProperty)
    FVector2D ValueRangeDb; // 0x68 (Size: 0x10, Type: StructProperty)
    bool bShowScale; // 0x78 (Size: 0x1, Type: BoolProperty)
    bool bScaleSide; // 0x79 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7a[0x2]; // 0x7a (Size: 0x2, Type: PaddingProperty)
    float ScaleHashOffset; // 0x7c (Size: 0x4, Type: FloatProperty)
    float ScaleHashWidth; // 0x80 (Size: 0x4, Type: FloatProperty)
    float ScaleHashHeight; // 0x84 (Size: 0x4, Type: FloatProperty)
    int32_t DecibelsPerHash; // 0x88 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
    FSlateFontInfo Font; // 0x90 (Size: 0x58, Type: StructProperty)
};

static_assert(sizeof(FAudioMaterialMeterStyle) == 0xe8, "Size mismatch for FAudioMaterialMeterStyle");
static_assert(offsetof(FAudioMaterialMeterStyle, MeterFillMinColor) == 0x18, "Offset mismatch for FAudioMaterialMeterStyle::MeterFillMinColor");
static_assert(offsetof(FAudioMaterialMeterStyle, MeterFillMidColor) == 0x28, "Offset mismatch for FAudioMaterialMeterStyle::MeterFillMidColor");
static_assert(offsetof(FAudioMaterialMeterStyle, MeterFillMaxColor) == 0x38, "Offset mismatch for FAudioMaterialMeterStyle::MeterFillMaxColor");
static_assert(offsetof(FAudioMaterialMeterStyle, MeterFillBackgroundColor) == 0x48, "Offset mismatch for FAudioMaterialMeterStyle::MeterFillBackgroundColor");
static_assert(offsetof(FAudioMaterialMeterStyle, MeterPadding) == 0x58, "Offset mismatch for FAudioMaterialMeterStyle::MeterPadding");
static_assert(offsetof(FAudioMaterialMeterStyle, ValueRangeDb) == 0x68, "Offset mismatch for FAudioMaterialMeterStyle::ValueRangeDb");
static_assert(offsetof(FAudioMaterialMeterStyle, bShowScale) == 0x78, "Offset mismatch for FAudioMaterialMeterStyle::bShowScale");
static_assert(offsetof(FAudioMaterialMeterStyle, bScaleSide) == 0x79, "Offset mismatch for FAudioMaterialMeterStyle::bScaleSide");
static_assert(offsetof(FAudioMaterialMeterStyle, ScaleHashOffset) == 0x7c, "Offset mismatch for FAudioMaterialMeterStyle::ScaleHashOffset");
static_assert(offsetof(FAudioMaterialMeterStyle, ScaleHashWidth) == 0x80, "Offset mismatch for FAudioMaterialMeterStyle::ScaleHashWidth");
static_assert(offsetof(FAudioMaterialMeterStyle, ScaleHashHeight) == 0x84, "Offset mismatch for FAudioMaterialMeterStyle::ScaleHashHeight");
static_assert(offsetof(FAudioMaterialMeterStyle, DecibelsPerHash) == 0x88, "Offset mismatch for FAudioMaterialMeterStyle::DecibelsPerHash");
static_assert(offsetof(FAudioMaterialMeterStyle, Font) == 0x90, "Offset mismatch for FAudioMaterialMeterStyle::Font");

// Size: 0x430 (Inherited: 0x8, Single: 0x428)
struct FAudioMeterStyle : FSlateWidgetStyle
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush MeterValueImage; // 0x10 (Size: 0xb0, Type: StructProperty)
    FSlateBrush BackgroundImage; // 0xc0 (Size: 0xb0, Type: StructProperty)
    FSlateBrush MeterBackgroundImage; // 0x170 (Size: 0xb0, Type: StructProperty)
    FSlateBrush MeterValueBackgroundImage; // 0x220 (Size: 0xb0, Type: StructProperty)
    FSlateBrush MeterPeakImage; // 0x2d0 (Size: 0xb0, Type: StructProperty)
    FVector2D MeterSize; // 0x380 (Size: 0x10, Type: StructProperty)
    FVector2D MeterPadding; // 0x390 (Size: 0x10, Type: StructProperty)
    float MeterValuePadding; // 0x3a0 (Size: 0x4, Type: FloatProperty)
    float PeakValueWidth; // 0x3a4 (Size: 0x4, Type: FloatProperty)
    FVector2D ValueRangeDb; // 0x3a8 (Size: 0x10, Type: StructProperty)
    bool bShowScale; // 0x3b8 (Size: 0x1, Type: BoolProperty)
    bool bScaleSide; // 0x3b9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3ba[0x2]; // 0x3ba (Size: 0x2, Type: PaddingProperty)
    float ScaleHashOffset; // 0x3bc (Size: 0x4, Type: FloatProperty)
    float ScaleHashWidth; // 0x3c0 (Size: 0x4, Type: FloatProperty)
    float ScaleHashHeight; // 0x3c4 (Size: 0x4, Type: FloatProperty)
    int32_t DecibelsPerHash; // 0x3c8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_3cc[0x4]; // 0x3cc (Size: 0x4, Type: PaddingProperty)
    FSlateFontInfo Font; // 0x3d0 (Size: 0x58, Type: StructProperty)
    uint8_t Pad_428[0x8]; // 0x428 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAudioMeterStyle) == 0x430, "Size mismatch for FAudioMeterStyle");
static_assert(offsetof(FAudioMeterStyle, MeterValueImage) == 0x10, "Offset mismatch for FAudioMeterStyle::MeterValueImage");
static_assert(offsetof(FAudioMeterStyle, BackgroundImage) == 0xc0, "Offset mismatch for FAudioMeterStyle::BackgroundImage");
static_assert(offsetof(FAudioMeterStyle, MeterBackgroundImage) == 0x170, "Offset mismatch for FAudioMeterStyle::MeterBackgroundImage");
static_assert(offsetof(FAudioMeterStyle, MeterValueBackgroundImage) == 0x220, "Offset mismatch for FAudioMeterStyle::MeterValueBackgroundImage");
static_assert(offsetof(FAudioMeterStyle, MeterPeakImage) == 0x2d0, "Offset mismatch for FAudioMeterStyle::MeterPeakImage");
static_assert(offsetof(FAudioMeterStyle, MeterSize) == 0x380, "Offset mismatch for FAudioMeterStyle::MeterSize");
static_assert(offsetof(FAudioMeterStyle, MeterPadding) == 0x390, "Offset mismatch for FAudioMeterStyle::MeterPadding");
static_assert(offsetof(FAudioMeterStyle, MeterValuePadding) == 0x3a0, "Offset mismatch for FAudioMeterStyle::MeterValuePadding");
static_assert(offsetof(FAudioMeterStyle, PeakValueWidth) == 0x3a4, "Offset mismatch for FAudioMeterStyle::PeakValueWidth");
static_assert(offsetof(FAudioMeterStyle, ValueRangeDb) == 0x3a8, "Offset mismatch for FAudioMeterStyle::ValueRangeDb");
static_assert(offsetof(FAudioMeterStyle, bShowScale) == 0x3b8, "Offset mismatch for FAudioMeterStyle::bShowScale");
static_assert(offsetof(FAudioMeterStyle, bScaleSide) == 0x3b9, "Offset mismatch for FAudioMeterStyle::bScaleSide");
static_assert(offsetof(FAudioMeterStyle, ScaleHashOffset) == 0x3bc, "Offset mismatch for FAudioMeterStyle::ScaleHashOffset");
static_assert(offsetof(FAudioMeterStyle, ScaleHashWidth) == 0x3c0, "Offset mismatch for FAudioMeterStyle::ScaleHashWidth");
static_assert(offsetof(FAudioMeterStyle, ScaleHashHeight) == 0x3c4, "Offset mismatch for FAudioMeterStyle::ScaleHashHeight");
static_assert(offsetof(FAudioMeterStyle, DecibelsPerHash) == 0x3c8, "Offset mismatch for FAudioMeterStyle::DecibelsPerHash");
static_assert(offsetof(FAudioMeterStyle, Font) == 0x3d0, "Offset mismatch for FAudioMeterStyle::Font");

// Size: 0x440 (Inherited: 0x8, Single: 0x438)
struct FAudioOscilloscopePanelStyle : FSlateWidgetStyle
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FFixedSampleSequenceRulerStyle TimeRulerStyle; // 0x10 (Size: 0x230, Type: StructProperty)
    FSampledSequenceValueGridOverlayStyle ValueGridStyle; // 0x240 (Size: 0x98, Type: StructProperty)
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)
    FSampledSequenceViewerStyle WaveViewerStyle; // 0x2e0 (Size: 0x140, Type: StructProperty)
    FTriggerThresholdLineStyle TriggerThresholdLineStyle; // 0x420 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_438[0x8]; // 0x438 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAudioOscilloscopePanelStyle) == 0x440, "Size mismatch for FAudioOscilloscopePanelStyle");
static_assert(offsetof(FAudioOscilloscopePanelStyle, TimeRulerStyle) == 0x10, "Offset mismatch for FAudioOscilloscopePanelStyle::TimeRulerStyle");
static_assert(offsetof(FAudioOscilloscopePanelStyle, ValueGridStyle) == 0x240, "Offset mismatch for FAudioOscilloscopePanelStyle::ValueGridStyle");
static_assert(offsetof(FAudioOscilloscopePanelStyle, WaveViewerStyle) == 0x2e0, "Offset mismatch for FAudioOscilloscopePanelStyle::WaveViewerStyle");
static_assert(offsetof(FAudioOscilloscopePanelStyle, TriggerThresholdLineStyle) == 0x420, "Offset mismatch for FAudioOscilloscopePanelStyle::TriggerThresholdLineStyle");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FTriggerThresholdLineStyle : FSlateWidgetStyle
{
    FLinearColor LineColor; // 0x8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FTriggerThresholdLineStyle) == 0x18, "Size mismatch for FTriggerThresholdLineStyle");
static_assert(offsetof(FTriggerThresholdLineStyle, LineColor) == 0x8, "Offset mismatch for FTriggerThresholdLineStyle::LineColor");

// Size: 0x140 (Inherited: 0x8, Single: 0x138)
struct FSampledSequenceViewerStyle : FSlateWidgetStyle
{
    FSlateColor SequenceColor; // 0x8 (Size: 0x14, Type: StructProperty)
    float SequenceLineThickness; // 0x1c (Size: 0x4, Type: FloatProperty)
    FSlateColor MajorGridLineColor; // 0x20 (Size: 0x14, Type: StructProperty)
    FSlateColor MinorGridLineColor; // 0x34 (Size: 0x14, Type: StructProperty)
    FSlateColor ZeroCrossingLineColor; // 0x48 (Size: 0x14, Type: StructProperty)
    float ZeroCrossingLineThickness; // 0x5c (Size: 0x4, Type: FloatProperty)
    float SampleMarkersSize; // 0x60 (Size: 0x4, Type: FloatProperty)
    FSlateColor SequenceBackgroundColor; // 0x64 (Size: 0x14, Type: StructProperty)
    FSlateBrush BackgroundBrush; // 0x80 (Size: 0xb0, Type: StructProperty)
    float DesiredWidth; // 0x130 (Size: 0x4, Type: FloatProperty)
    float DesiredHeight; // 0x134 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FSampledSequenceViewerStyle) == 0x140, "Size mismatch for FSampledSequenceViewerStyle");
static_assert(offsetof(FSampledSequenceViewerStyle, SequenceColor) == 0x8, "Offset mismatch for FSampledSequenceViewerStyle::SequenceColor");
static_assert(offsetof(FSampledSequenceViewerStyle, SequenceLineThickness) == 0x1c, "Offset mismatch for FSampledSequenceViewerStyle::SequenceLineThickness");
static_assert(offsetof(FSampledSequenceViewerStyle, MajorGridLineColor) == 0x20, "Offset mismatch for FSampledSequenceViewerStyle::MajorGridLineColor");
static_assert(offsetof(FSampledSequenceViewerStyle, MinorGridLineColor) == 0x34, "Offset mismatch for FSampledSequenceViewerStyle::MinorGridLineColor");
static_assert(offsetof(FSampledSequenceViewerStyle, ZeroCrossingLineColor) == 0x48, "Offset mismatch for FSampledSequenceViewerStyle::ZeroCrossingLineColor");
static_assert(offsetof(FSampledSequenceViewerStyle, ZeroCrossingLineThickness) == 0x5c, "Offset mismatch for FSampledSequenceViewerStyle::ZeroCrossingLineThickness");
static_assert(offsetof(FSampledSequenceViewerStyle, SampleMarkersSize) == 0x60, "Offset mismatch for FSampledSequenceViewerStyle::SampleMarkersSize");
static_assert(offsetof(FSampledSequenceViewerStyle, SequenceBackgroundColor) == 0x64, "Offset mismatch for FSampledSequenceViewerStyle::SequenceBackgroundColor");
static_assert(offsetof(FSampledSequenceViewerStyle, BackgroundBrush) == 0x80, "Offset mismatch for FSampledSequenceViewerStyle::BackgroundBrush");
static_assert(offsetof(FSampledSequenceViewerStyle, DesiredWidth) == 0x130, "Offset mismatch for FSampledSequenceViewerStyle::DesiredWidth");
static_assert(offsetof(FSampledSequenceViewerStyle, DesiredHeight) == 0x134, "Offset mismatch for FSampledSequenceViewerStyle::DesiredHeight");

// Size: 0x98 (Inherited: 0x8, Single: 0x90)
struct FSampledSequenceValueGridOverlayStyle : FSlateWidgetStyle
{
    FSlateColor GridColor; // 0x8 (Size: 0x14, Type: StructProperty)
    float GridThickness; // 0x1c (Size: 0x4, Type: FloatProperty)
    FSlateColor LabelTextColor; // 0x20 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    FSlateFontInfo LabelTextFont; // 0x38 (Size: 0x58, Type: StructProperty)
    float DesiredWidth; // 0x90 (Size: 0x4, Type: FloatProperty)
    float DesiredHeight; // 0x94 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FSampledSequenceValueGridOverlayStyle) == 0x98, "Size mismatch for FSampledSequenceValueGridOverlayStyle");
static_assert(offsetof(FSampledSequenceValueGridOverlayStyle, GridColor) == 0x8, "Offset mismatch for FSampledSequenceValueGridOverlayStyle::GridColor");
static_assert(offsetof(FSampledSequenceValueGridOverlayStyle, GridThickness) == 0x1c, "Offset mismatch for FSampledSequenceValueGridOverlayStyle::GridThickness");
static_assert(offsetof(FSampledSequenceValueGridOverlayStyle, LabelTextColor) == 0x20, "Offset mismatch for FSampledSequenceValueGridOverlayStyle::LabelTextColor");
static_assert(offsetof(FSampledSequenceValueGridOverlayStyle, LabelTextFont) == 0x38, "Offset mismatch for FSampledSequenceValueGridOverlayStyle::LabelTextFont");
static_assert(offsetof(FSampledSequenceValueGridOverlayStyle, DesiredWidth) == 0x90, "Offset mismatch for FSampledSequenceValueGridOverlayStyle::DesiredWidth");
static_assert(offsetof(FSampledSequenceValueGridOverlayStyle, DesiredHeight) == 0x94, "Offset mismatch for FSampledSequenceValueGridOverlayStyle::DesiredHeight");

// Size: 0x230 (Inherited: 0x8, Single: 0x228)
struct FFixedSampleSequenceRulerStyle : FSlateWidgetStyle
{
    float HandleWidth; // 0x8 (Size: 0x4, Type: FloatProperty)
    FSlateColor HandleColor; // 0xc (Size: 0x14, Type: StructProperty)
    FSlateBrush HandleBrush; // 0x20 (Size: 0xb0, Type: StructProperty)
    FSlateColor TicksColor; // 0xd0 (Size: 0x14, Type: StructProperty)
    FSlateColor TicksTextColor; // 0xe4 (Size: 0x14, Type: StructProperty)
    FSlateFontInfo TicksTextFont; // 0xf8 (Size: 0x58, Type: StructProperty)
    float TicksTextOffset; // 0x150 (Size: 0x4, Type: FloatProperty)
    FSlateColor BackgroundColor; // 0x154 (Size: 0x14, Type: StructProperty)
    FSlateBrush BackgroundBrush; // 0x170 (Size: 0xb0, Type: StructProperty)
    float DesiredWidth; // 0x220 (Size: 0x4, Type: FloatProperty)
    float DesiredHeight; // 0x224 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFixedSampleSequenceRulerStyle) == 0x230, "Size mismatch for FFixedSampleSequenceRulerStyle");
static_assert(offsetof(FFixedSampleSequenceRulerStyle, HandleWidth) == 0x8, "Offset mismatch for FFixedSampleSequenceRulerStyle::HandleWidth");
static_assert(offsetof(FFixedSampleSequenceRulerStyle, HandleColor) == 0xc, "Offset mismatch for FFixedSampleSequenceRulerStyle::HandleColor");
static_assert(offsetof(FFixedSampleSequenceRulerStyle, HandleBrush) == 0x20, "Offset mismatch for FFixedSampleSequenceRulerStyle::HandleBrush");
static_assert(offsetof(FFixedSampleSequenceRulerStyle, TicksColor) == 0xd0, "Offset mismatch for FFixedSampleSequenceRulerStyle::TicksColor");
static_assert(offsetof(FFixedSampleSequenceRulerStyle, TicksTextColor) == 0xe4, "Offset mismatch for FFixedSampleSequenceRulerStyle::TicksTextColor");
static_assert(offsetof(FFixedSampleSequenceRulerStyle, TicksTextFont) == 0xf8, "Offset mismatch for FFixedSampleSequenceRulerStyle::TicksTextFont");
static_assert(offsetof(FFixedSampleSequenceRulerStyle, TicksTextOffset) == 0x150, "Offset mismatch for FFixedSampleSequenceRulerStyle::TicksTextOffset");
static_assert(offsetof(FFixedSampleSequenceRulerStyle, BackgroundColor) == 0x154, "Offset mismatch for FFixedSampleSequenceRulerStyle::BackgroundColor");
static_assert(offsetof(FFixedSampleSequenceRulerStyle, BackgroundBrush) == 0x170, "Offset mismatch for FFixedSampleSequenceRulerStyle::BackgroundBrush");
static_assert(offsetof(FFixedSampleSequenceRulerStyle, DesiredWidth) == 0x220, "Offset mismatch for FFixedSampleSequenceRulerStyle::DesiredWidth");
static_assert(offsetof(FFixedSampleSequenceRulerStyle, DesiredHeight) == 0x224, "Offset mismatch for FFixedSampleSequenceRulerStyle::DesiredHeight");

// Size: 0x190 (Inherited: 0x8, Single: 0x188)
struct FAudioVectorscopePanelStyle : FSlateWidgetStyle
{
    FSampledSequenceValueGridOverlayStyle ValueGridStyle; // 0x8 (Size: 0x98, Type: StructProperty)
    FSampledSequenceVectorViewerStyle VectorViewerStyle; // 0xa0 (Size: 0xf0, Type: StructProperty)
};

static_assert(sizeof(FAudioVectorscopePanelStyle) == 0x190, "Size mismatch for FAudioVectorscopePanelStyle");
static_assert(offsetof(FAudioVectorscopePanelStyle, ValueGridStyle) == 0x8, "Offset mismatch for FAudioVectorscopePanelStyle::ValueGridStyle");
static_assert(offsetof(FAudioVectorscopePanelStyle, VectorViewerStyle) == 0xa0, "Offset mismatch for FAudioVectorscopePanelStyle::VectorViewerStyle");

// Size: 0xf0 (Inherited: 0x8, Single: 0xe8)
struct FSampledSequenceVectorViewerStyle : FSlateWidgetStyle
{
    FSlateColor BackgroundColor; // 0x8 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FSlateBrush BackgroundBrush; // 0x20 (Size: 0xb0, Type: StructProperty)
    FLinearColor LineColor; // 0xd0 (Size: 0x10, Type: StructProperty)
    float LineThickness; // 0xe0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_e4[0xc]; // 0xe4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FSampledSequenceVectorViewerStyle) == 0xf0, "Size mismatch for FSampledSequenceVectorViewerStyle");
static_assert(offsetof(FSampledSequenceVectorViewerStyle, BackgroundColor) == 0x8, "Offset mismatch for FSampledSequenceVectorViewerStyle::BackgroundColor");
static_assert(offsetof(FSampledSequenceVectorViewerStyle, BackgroundBrush) == 0x20, "Offset mismatch for FSampledSequenceVectorViewerStyle::BackgroundBrush");
static_assert(offsetof(FSampledSequenceVectorViewerStyle, LineColor) == 0xd0, "Offset mismatch for FSampledSequenceVectorViewerStyle::LineColor");
static_assert(offsetof(FSampledSequenceVectorViewerStyle, LineThickness) == 0xe0, "Offset mismatch for FSampledSequenceVectorViewerStyle::LineThickness");

// Size: 0x24 (Inherited: 0x0, Single: 0x24)
struct FAudioMaterialEnvelopeSettings
{
    uint8_t EnvelopeType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float AttackCurve; // 0x4 (Size: 0x4, Type: FloatProperty)
    float AttackValue; // 0x8 (Size: 0x4, Type: FloatProperty)
    float AttackTime; // 0xc (Size: 0x4, Type: FloatProperty)
    float DecayCurve; // 0x10 (Size: 0x4, Type: FloatProperty)
    float DecayTime; // 0x14 (Size: 0x4, Type: FloatProperty)
    float SustainValue; // 0x18 (Size: 0x4, Type: FloatProperty)
    float ReleaseCurve; // 0x1c (Size: 0x4, Type: FloatProperty)
    float ReleaseTime; // 0x20 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FAudioMaterialEnvelopeSettings) == 0x24, "Size mismatch for FAudioMaterialEnvelopeSettings");
static_assert(offsetof(FAudioMaterialEnvelopeSettings, EnvelopeType) == 0x0, "Offset mismatch for FAudioMaterialEnvelopeSettings::EnvelopeType");
static_assert(offsetof(FAudioMaterialEnvelopeSettings, AttackCurve) == 0x4, "Offset mismatch for FAudioMaterialEnvelopeSettings::AttackCurve");
static_assert(offsetof(FAudioMaterialEnvelopeSettings, AttackValue) == 0x8, "Offset mismatch for FAudioMaterialEnvelopeSettings::AttackValue");
static_assert(offsetof(FAudioMaterialEnvelopeSettings, AttackTime) == 0xc, "Offset mismatch for FAudioMaterialEnvelopeSettings::AttackTime");
static_assert(offsetof(FAudioMaterialEnvelopeSettings, DecayCurve) == 0x10, "Offset mismatch for FAudioMaterialEnvelopeSettings::DecayCurve");
static_assert(offsetof(FAudioMaterialEnvelopeSettings, DecayTime) == 0x14, "Offset mismatch for FAudioMaterialEnvelopeSettings::DecayTime");
static_assert(offsetof(FAudioMaterialEnvelopeSettings, SustainValue) == 0x18, "Offset mismatch for FAudioMaterialEnvelopeSettings::SustainValue");
static_assert(offsetof(FAudioMaterialEnvelopeSettings, ReleaseCurve) == 0x1c, "Offset mismatch for FAudioMaterialEnvelopeSettings::ReleaseCurve");
static_assert(offsetof(FAudioMaterialEnvelopeSettings, ReleaseTime) == 0x20, "Offset mismatch for FAudioMaterialEnvelopeSettings::ReleaseTime");

// Size: 0x88 (Inherited: 0x20, Single: 0x68)
struct FAudioMaterialButtonStyle : FAudioMaterialWidgetStyle
{
    FLinearColor ButtonMainColor; // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor ButtonMainColorTint_1; // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor ButtonMainColorTint_2; // 0x38 (Size: 0x10, Type: StructProperty)
    FLinearColor ButtonAccentColor; // 0x48 (Size: 0x10, Type: StructProperty)
    FLinearColor ButtonShadowColor; // 0x58 (Size: 0x10, Type: StructProperty)
    FLinearColor ButtonUnpressedOutlineColor; // 0x68 (Size: 0x10, Type: StructProperty)
    FLinearColor ButtonPressedOutlineColor; // 0x78 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FAudioMaterialButtonStyle) == 0x88, "Size mismatch for FAudioMaterialButtonStyle");
static_assert(offsetof(FAudioMaterialButtonStyle, ButtonMainColor) == 0x18, "Offset mismatch for FAudioMaterialButtonStyle::ButtonMainColor");
static_assert(offsetof(FAudioMaterialButtonStyle, ButtonMainColorTint_1) == 0x28, "Offset mismatch for FAudioMaterialButtonStyle::ButtonMainColorTint_1");
static_assert(offsetof(FAudioMaterialButtonStyle, ButtonMainColorTint_2) == 0x38, "Offset mismatch for FAudioMaterialButtonStyle::ButtonMainColorTint_2");
static_assert(offsetof(FAudioMaterialButtonStyle, ButtonAccentColor) == 0x48, "Offset mismatch for FAudioMaterialButtonStyle::ButtonAccentColor");
static_assert(offsetof(FAudioMaterialButtonStyle, ButtonShadowColor) == 0x58, "Offset mismatch for FAudioMaterialButtonStyle::ButtonShadowColor");
static_assert(offsetof(FAudioMaterialButtonStyle, ButtonUnpressedOutlineColor) == 0x68, "Offset mismatch for FAudioMaterialButtonStyle::ButtonUnpressedOutlineColor");
static_assert(offsetof(FAudioMaterialButtonStyle, ButtonPressedOutlineColor) == 0x78, "Offset mismatch for FAudioMaterialButtonStyle::ButtonPressedOutlineColor");

// Size: 0x150 (Inherited: 0x20, Single: 0x130)
struct FAudioMaterialSliderStyle : FAudioMaterialWidgetStyle
{
    FLinearColor SliderBackgroundColor; // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderBackgroundAccentColor; // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderValueMainColor; // 0x38 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderHandleMainColor; // 0x48 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderHandleOutlineColor; // 0x58 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_68[0x8]; // 0x68 (Size: 0x8, Type: PaddingProperty)
    FAudioTextBoxStyle TextBoxStyle; // 0x70 (Size: 0xe0, Type: StructProperty)
};

static_assert(sizeof(FAudioMaterialSliderStyle) == 0x150, "Size mismatch for FAudioMaterialSliderStyle");
static_assert(offsetof(FAudioMaterialSliderStyle, SliderBackgroundColor) == 0x18, "Offset mismatch for FAudioMaterialSliderStyle::SliderBackgroundColor");
static_assert(offsetof(FAudioMaterialSliderStyle, SliderBackgroundAccentColor) == 0x28, "Offset mismatch for FAudioMaterialSliderStyle::SliderBackgroundAccentColor");
static_assert(offsetof(FAudioMaterialSliderStyle, SliderValueMainColor) == 0x38, "Offset mismatch for FAudioMaterialSliderStyle::SliderValueMainColor");
static_assert(offsetof(FAudioMaterialSliderStyle, SliderHandleMainColor) == 0x48, "Offset mismatch for FAudioMaterialSliderStyle::SliderHandleMainColor");
static_assert(offsetof(FAudioMaterialSliderStyle, SliderHandleOutlineColor) == 0x58, "Offset mismatch for FAudioMaterialSliderStyle::SliderHandleOutlineColor");
static_assert(offsetof(FAudioMaterialSliderStyle, TextBoxStyle) == 0x70, "Offset mismatch for FAudioMaterialSliderStyle::TextBoxStyle");

// Size: 0xe0 (Inherited: 0x8, Single: 0xd8)
struct FAudioTextBoxStyle : FSlateWidgetStyle
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush BackgroundImage; // 0x10 (Size: 0xb0, Type: StructProperty)
    FSlateColor BackgroundColor; // 0xc0 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_d4[0xc]; // 0xd4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FAudioTextBoxStyle) == 0xe0, "Size mismatch for FAudioTextBoxStyle");
static_assert(offsetof(FAudioTextBoxStyle, BackgroundImage) == 0x10, "Offset mismatch for FAudioTextBoxStyle::BackgroundImage");
static_assert(offsetof(FAudioTextBoxStyle, BackgroundColor) == 0xc0, "Offset mismatch for FAudioTextBoxStyle::BackgroundColor");

// Size: 0x1c0 (Inherited: 0x20, Single: 0x1a0)
struct FAudioMaterialKnobStyle : FAudioMaterialWidgetStyle
{
    FLinearColor KnobMainColor; // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobAccentColor; // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobShadowColor; // 0x38 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobSmoothBevelColor; // 0x48 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobIndicatorDotColor; // 0x58 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobEdgeFillColor; // 0x68 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobBarColor; // 0x78 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobBarShadowColor; // 0x88 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobBarFillMinColor; // 0x98 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobBarFillMidColor; // 0xa8 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobBarFillMaxColor; // 0xb8 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobBarFillTintColor; // 0xc8 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_d8[0x8]; // 0xd8 (Size: 0x8, Type: PaddingProperty)
    FAudioTextBoxStyle TextBoxStyle; // 0xe0 (Size: 0xe0, Type: StructProperty)
};

static_assert(sizeof(FAudioMaterialKnobStyle) == 0x1c0, "Size mismatch for FAudioMaterialKnobStyle");
static_assert(offsetof(FAudioMaterialKnobStyle, KnobMainColor) == 0x18, "Offset mismatch for FAudioMaterialKnobStyle::KnobMainColor");
static_assert(offsetof(FAudioMaterialKnobStyle, KnobAccentColor) == 0x28, "Offset mismatch for FAudioMaterialKnobStyle::KnobAccentColor");
static_assert(offsetof(FAudioMaterialKnobStyle, KnobShadowColor) == 0x38, "Offset mismatch for FAudioMaterialKnobStyle::KnobShadowColor");
static_assert(offsetof(FAudioMaterialKnobStyle, KnobSmoothBevelColor) == 0x48, "Offset mismatch for FAudioMaterialKnobStyle::KnobSmoothBevelColor");
static_assert(offsetof(FAudioMaterialKnobStyle, KnobIndicatorDotColor) == 0x58, "Offset mismatch for FAudioMaterialKnobStyle::KnobIndicatorDotColor");
static_assert(offsetof(FAudioMaterialKnobStyle, KnobEdgeFillColor) == 0x68, "Offset mismatch for FAudioMaterialKnobStyle::KnobEdgeFillColor");
static_assert(offsetof(FAudioMaterialKnobStyle, KnobBarColor) == 0x78, "Offset mismatch for FAudioMaterialKnobStyle::KnobBarColor");
static_assert(offsetof(FAudioMaterialKnobStyle, KnobBarShadowColor) == 0x88, "Offset mismatch for FAudioMaterialKnobStyle::KnobBarShadowColor");
static_assert(offsetof(FAudioMaterialKnobStyle, KnobBarFillMinColor) == 0x98, "Offset mismatch for FAudioMaterialKnobStyle::KnobBarFillMinColor");
static_assert(offsetof(FAudioMaterialKnobStyle, KnobBarFillMidColor) == 0xa8, "Offset mismatch for FAudioMaterialKnobStyle::KnobBarFillMidColor");
static_assert(offsetof(FAudioMaterialKnobStyle, KnobBarFillMaxColor) == 0xb8, "Offset mismatch for FAudioMaterialKnobStyle::KnobBarFillMaxColor");
static_assert(offsetof(FAudioMaterialKnobStyle, KnobBarFillTintColor) == 0xc8, "Offset mismatch for FAudioMaterialKnobStyle::KnobBarFillTintColor");
static_assert(offsetof(FAudioMaterialKnobStyle, TextBoxStyle) == 0xe0, "Offset mismatch for FAudioMaterialKnobStyle::TextBoxStyle");

// Size: 0x48 (Inherited: 0x20, Single: 0x28)
struct FAudioMaterialEnvelopeStyle : FAudioMaterialWidgetStyle
{
    FLinearColor CurveColor; // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundColor; // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor OutlineColor; // 0x38 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FAudioMaterialEnvelopeStyle) == 0x48, "Size mismatch for FAudioMaterialEnvelopeStyle");
static_assert(offsetof(FAudioMaterialEnvelopeStyle, CurveColor) == 0x18, "Offset mismatch for FAudioMaterialEnvelopeStyle::CurveColor");
static_assert(offsetof(FAudioMaterialEnvelopeStyle, BackgroundColor) == 0x28, "Offset mismatch for FAudioMaterialEnvelopeStyle::BackgroundColor");
static_assert(offsetof(FAudioMaterialEnvelopeStyle, OutlineColor) == 0x38, "Offset mismatch for FAudioMaterialEnvelopeStyle::OutlineColor");

// Size: 0x7 (Inherited: 0x0, Single: 0x7)
struct FSpectrogramRackUnitSettings
{
    uint8_t AnalyzerType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t FFTAnalyzerFFTSize; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t CQTAnalyzerFFTSize; // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t PixelPlotMode; // 0x3 (Size: 0x1, Type: EnumProperty)
    uint8_t FrequencyScale; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t ColorMap; // 0x5 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EOrientation> orientation; // 0x6 (Size: 0x1, Type: ByteProperty)
};

static_assert(sizeof(FSpectrogramRackUnitSettings) == 0x7, "Size mismatch for FSpectrogramRackUnitSettings");
static_assert(offsetof(FSpectrogramRackUnitSettings, AnalyzerType) == 0x0, "Offset mismatch for FSpectrogramRackUnitSettings::AnalyzerType");
static_assert(offsetof(FSpectrogramRackUnitSettings, FFTAnalyzerFFTSize) == 0x1, "Offset mismatch for FSpectrogramRackUnitSettings::FFTAnalyzerFFTSize");
static_assert(offsetof(FSpectrogramRackUnitSettings, CQTAnalyzerFFTSize) == 0x2, "Offset mismatch for FSpectrogramRackUnitSettings::CQTAnalyzerFFTSize");
static_assert(offsetof(FSpectrogramRackUnitSettings, PixelPlotMode) == 0x3, "Offset mismatch for FSpectrogramRackUnitSettings::PixelPlotMode");
static_assert(offsetof(FSpectrogramRackUnitSettings, FrequencyScale) == 0x4, "Offset mismatch for FSpectrogramRackUnitSettings::FrequencyScale");
static_assert(offsetof(FSpectrogramRackUnitSettings, ColorMap) == 0x5, "Offset mismatch for FSpectrogramRackUnitSettings::ColorMap");
static_assert(offsetof(FSpectrogramRackUnitSettings, orientation) == 0x6, "Offset mismatch for FSpectrogramRackUnitSettings::orientation");

// Size: 0x9 (Inherited: 0x0, Single: 0x9)
struct FSpectrumAnalyzerRackUnitSettings
{
    uint8_t Ballistics; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t AnalyzerType; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t FFTAnalyzerFFTSize; // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t CQTAnalyzerFFTSize; // 0x3 (Size: 0x1, Type: EnumProperty)
    uint8_t TiltSpectrum; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t PixelPlotMode; // 0x5 (Size: 0x1, Type: EnumProperty)
    uint8_t FrequencyScale; // 0x6 (Size: 0x1, Type: EnumProperty)
    bool bDisplayFrequencyAxisLabels; // 0x7 (Size: 0x1, Type: BoolProperty)
    bool bDisplaySoundLevelAxisLabels; // 0x8 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FSpectrumAnalyzerRackUnitSettings) == 0x9, "Size mismatch for FSpectrumAnalyzerRackUnitSettings");
static_assert(offsetof(FSpectrumAnalyzerRackUnitSettings, Ballistics) == 0x0, "Offset mismatch for FSpectrumAnalyzerRackUnitSettings::Ballistics");
static_assert(offsetof(FSpectrumAnalyzerRackUnitSettings, AnalyzerType) == 0x1, "Offset mismatch for FSpectrumAnalyzerRackUnitSettings::AnalyzerType");
static_assert(offsetof(FSpectrumAnalyzerRackUnitSettings, FFTAnalyzerFFTSize) == 0x2, "Offset mismatch for FSpectrumAnalyzerRackUnitSettings::FFTAnalyzerFFTSize");
static_assert(offsetof(FSpectrumAnalyzerRackUnitSettings, CQTAnalyzerFFTSize) == 0x3, "Offset mismatch for FSpectrumAnalyzerRackUnitSettings::CQTAnalyzerFFTSize");
static_assert(offsetof(FSpectrumAnalyzerRackUnitSettings, TiltSpectrum) == 0x4, "Offset mismatch for FSpectrumAnalyzerRackUnitSettings::TiltSpectrum");
static_assert(offsetof(FSpectrumAnalyzerRackUnitSettings, PixelPlotMode) == 0x5, "Offset mismatch for FSpectrumAnalyzerRackUnitSettings::PixelPlotMode");
static_assert(offsetof(FSpectrumAnalyzerRackUnitSettings, FrequencyScale) == 0x6, "Offset mismatch for FSpectrumAnalyzerRackUnitSettings::FrequencyScale");
static_assert(offsetof(FSpectrumAnalyzerRackUnitSettings, bDisplayFrequencyAxisLabels) == 0x7, "Offset mismatch for FSpectrumAnalyzerRackUnitSettings::bDisplayFrequencyAxisLabels");
static_assert(offsetof(FSpectrumAnalyzerRackUnitSettings, bDisplaySoundLevelAxisLabels) == 0x8, "Offset mismatch for FSpectrumAnalyzerRackUnitSettings::bDisplaySoundLevelAxisLabels");

// Size: 0x68 (Inherited: 0x8, Single: 0x60)
struct FAudioMeterDefaultColorStyle : FSlateWidgetStyle
{
    FLinearColor MeterBackgroundColor; // 0x8 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterValueColor; // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterPeakColor; // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterClippingColor; // 0x38 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterScaleColor; // 0x48 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterScaleLabelColor; // 0x58 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FAudioMeterDefaultColorStyle) == 0x68, "Size mismatch for FAudioMeterDefaultColorStyle");
static_assert(offsetof(FAudioMeterDefaultColorStyle, MeterBackgroundColor) == 0x8, "Offset mismatch for FAudioMeterDefaultColorStyle::MeterBackgroundColor");
static_assert(offsetof(FAudioMeterDefaultColorStyle, MeterValueColor) == 0x18, "Offset mismatch for FAudioMeterDefaultColorStyle::MeterValueColor");
static_assert(offsetof(FAudioMeterDefaultColorStyle, MeterPeakColor) == 0x28, "Offset mismatch for FAudioMeterDefaultColorStyle::MeterPeakColor");
static_assert(offsetof(FAudioMeterDefaultColorStyle, MeterClippingColor) == 0x38, "Offset mismatch for FAudioMeterDefaultColorStyle::MeterClippingColor");
static_assert(offsetof(FAudioMeterDefaultColorStyle, MeterScaleColor) == 0x48, "Offset mismatch for FAudioMeterDefaultColorStyle::MeterScaleColor");
static_assert(offsetof(FAudioMeterDefaultColorStyle, MeterScaleLabelColor) == 0x58, "Offset mismatch for FAudioMeterDefaultColorStyle::MeterScaleLabelColor");

// Size: 0x120 (Inherited: 0x8, Single: 0x118)
struct FAudioSpectrumPlotStyle : FSlateWidgetStyle
{
    FSlateColor BackgroundColor; // 0x8 (Size: 0x14, Type: StructProperty)
    FSlateColor GridColor; // 0x1c (Size: 0x14, Type: StructProperty)
    FSlateColor AxisLabelColor; // 0x30 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
    FSlateFontInfo AxisLabelFont; // 0x48 (Size: 0x58, Type: StructProperty)
    FSlateColor SpectrumColor; // 0xa0 (Size: 0x14, Type: StructProperty)
    FSlateColor CrosshairColor; // 0xb4 (Size: 0x14, Type: StructProperty)
    FSlateFontInfo CrosshairLabelFont; // 0xc8 (Size: 0x58, Type: StructProperty)
};

static_assert(sizeof(FAudioSpectrumPlotStyle) == 0x120, "Size mismatch for FAudioSpectrumPlotStyle");
static_assert(offsetof(FAudioSpectrumPlotStyle, BackgroundColor) == 0x8, "Offset mismatch for FAudioSpectrumPlotStyle::BackgroundColor");
static_assert(offsetof(FAudioSpectrumPlotStyle, GridColor) == 0x1c, "Offset mismatch for FAudioSpectrumPlotStyle::GridColor");
static_assert(offsetof(FAudioSpectrumPlotStyle, AxisLabelColor) == 0x30, "Offset mismatch for FAudioSpectrumPlotStyle::AxisLabelColor");
static_assert(offsetof(FAudioSpectrumPlotStyle, AxisLabelFont) == 0x48, "Offset mismatch for FAudioSpectrumPlotStyle::AxisLabelFont");
static_assert(offsetof(FAudioSpectrumPlotStyle, SpectrumColor) == 0xa0, "Offset mismatch for FAudioSpectrumPlotStyle::SpectrumColor");
static_assert(offsetof(FAudioSpectrumPlotStyle, CrosshairColor) == 0xb4, "Offset mismatch for FAudioSpectrumPlotStyle::CrosshairColor");
static_assert(offsetof(FAudioSpectrumPlotStyle, CrosshairLabelFont) == 0xc8, "Offset mismatch for FAudioSpectrumPlotStyle::CrosshairLabelFont");

// Size: 0x650 (Inherited: 0x8, Single: 0x648)
struct FAudioSliderStyle : FSlateWidgetStyle
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FSliderStyle SliderStyle; // 0x10 (Size: 0x440, Type: StructProperty)
    FAudioTextBoxStyle TextBoxStyle; // 0x450 (Size: 0xe0, Type: StructProperty)
    FSlateBrush WidgetBackgroundImage; // 0x530 (Size: 0xb0, Type: StructProperty)
    FSlateColor SliderBackgroundColor; // 0x5e0 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_5f4[0x4]; // 0x5f4 (Size: 0x4, Type: PaddingProperty)
    FVector2D SliderBackgroundSize; // 0x5f8 (Size: 0x10, Type: StructProperty)
    float LabelPadding; // 0x608 (Size: 0x4, Type: FloatProperty)
    FSlateColor SliderBarColor; // 0x60c (Size: 0x14, Type: StructProperty)
    FSlateColor SliderThumbColor; // 0x620 (Size: 0x14, Type: StructProperty)
    FSlateColor WidgetBackgroundColor; // 0x634 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_648[0x8]; // 0x648 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAudioSliderStyle) == 0x650, "Size mismatch for FAudioSliderStyle");
static_assert(offsetof(FAudioSliderStyle, SliderStyle) == 0x10, "Offset mismatch for FAudioSliderStyle::SliderStyle");
static_assert(offsetof(FAudioSliderStyle, TextBoxStyle) == 0x450, "Offset mismatch for FAudioSliderStyle::TextBoxStyle");
static_assert(offsetof(FAudioSliderStyle, WidgetBackgroundImage) == 0x530, "Offset mismatch for FAudioSliderStyle::WidgetBackgroundImage");
static_assert(offsetof(FAudioSliderStyle, SliderBackgroundColor) == 0x5e0, "Offset mismatch for FAudioSliderStyle::SliderBackgroundColor");
static_assert(offsetof(FAudioSliderStyle, SliderBackgroundSize) == 0x5f8, "Offset mismatch for FAudioSliderStyle::SliderBackgroundSize");
static_assert(offsetof(FAudioSliderStyle, LabelPadding) == 0x608, "Offset mismatch for FAudioSliderStyle::LabelPadding");
static_assert(offsetof(FAudioSliderStyle, SliderBarColor) == 0x60c, "Offset mismatch for FAudioSliderStyle::SliderBarColor");
static_assert(offsetof(FAudioSliderStyle, SliderThumbColor) == 0x620, "Offset mismatch for FAudioSliderStyle::SliderThumbColor");
static_assert(offsetof(FAudioSliderStyle, WidgetBackgroundColor) == 0x634, "Offset mismatch for FAudioSliderStyle::WidgetBackgroundColor");

// Size: 0x140 (Inherited: 0x8, Single: 0x138)
struct FAudioRadialSliderStyle : FSlateWidgetStyle
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FAudioTextBoxStyle TextBoxStyle; // 0x10 (Size: 0xe0, Type: StructProperty)
    FSlateColor CenterBackgroundColor; // 0xf0 (Size: 0x14, Type: StructProperty)
    FSlateColor SliderBarColor; // 0x104 (Size: 0x14, Type: StructProperty)
    FSlateColor SliderProgressColor; // 0x118 (Size: 0x14, Type: StructProperty)
    float LabelPadding; // 0x12c (Size: 0x4, Type: FloatProperty)
    float DefaultSliderRadius; // 0x130 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_134[0xc]; // 0x134 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FAudioRadialSliderStyle) == 0x140, "Size mismatch for FAudioRadialSliderStyle");
static_assert(offsetof(FAudioRadialSliderStyle, TextBoxStyle) == 0x10, "Offset mismatch for FAudioRadialSliderStyle::TextBoxStyle");
static_assert(offsetof(FAudioRadialSliderStyle, CenterBackgroundColor) == 0xf0, "Offset mismatch for FAudioRadialSliderStyle::CenterBackgroundColor");
static_assert(offsetof(FAudioRadialSliderStyle, SliderBarColor) == 0x104, "Offset mismatch for FAudioRadialSliderStyle::SliderBarColor");
static_assert(offsetof(FAudioRadialSliderStyle, SliderProgressColor) == 0x118, "Offset mismatch for FAudioRadialSliderStyle::SliderProgressColor");
static_assert(offsetof(FAudioRadialSliderStyle, LabelPadding) == 0x12c, "Offset mismatch for FAudioRadialSliderStyle::LabelPadding");
static_assert(offsetof(FAudioRadialSliderStyle, DefaultSliderRadius) == 0x130, "Offset mismatch for FAudioRadialSliderStyle::DefaultSliderRadius");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FPlayheadOverlayStyle : FSlateWidgetStyle
{
    FSlateColor PlayheadColor; // 0x8 (Size: 0x14, Type: StructProperty)
    float PlayheadWidth; // 0x1c (Size: 0x4, Type: FloatProperty)
    float DesiredWidth; // 0x20 (Size: 0x4, Type: FloatProperty)
    float DesiredHeight; // 0x24 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FPlayheadOverlayStyle) == 0x28, "Size mismatch for FPlayheadOverlayStyle");
static_assert(offsetof(FPlayheadOverlayStyle, PlayheadColor) == 0x8, "Offset mismatch for FPlayheadOverlayStyle::PlayheadColor");
static_assert(offsetof(FPlayheadOverlayStyle, PlayheadWidth) == 0x1c, "Offset mismatch for FPlayheadOverlayStyle::PlayheadWidth");
static_assert(offsetof(FPlayheadOverlayStyle, DesiredWidth) == 0x20, "Offset mismatch for FPlayheadOverlayStyle::DesiredWidth");
static_assert(offsetof(FPlayheadOverlayStyle, DesiredHeight) == 0x24, "Offset mismatch for FPlayheadOverlayStyle::DesiredHeight");

