/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_FabricJamTrackPlayerUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FabricUI.h"
#include "ModelViewViewModel.h"
#include "CoreUObject.h"
#include "MediaAssets.h"

// Size: 0xc0 (Inherited: 0x108, Single: 0xffffffb8)
class UFabricJamTrackPlayerPlaybackTimeVM : public UFabricPlaybackTimeViewModel
{
public:
    uint8_t Pad_78[0x40]; // 0x78 (Size: 0x40, Type: PaddingProperty)
    TWeakObjectPtr<UMediaPlayer*> CachedMediaPlayer; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UFabricJamTrackPlayerPlaybackTimeVM) == 0xc0, "Size mismatch for UFabricJamTrackPlayerPlaybackTimeVM");
static_assert(offsetof(UFabricJamTrackPlayerPlaybackTimeVM, CachedMediaPlayer) == 0xb8, "Offset mismatch for UFabricJamTrackPlayerPlaybackTimeVM::CachedMediaPlayer");

// Size: 0x78 (Inherited: 0x90, Single: 0xffffffe8)
class UFabricJamTrackPlayerSongSelectVM : public UMVVMViewModelBase
{
public:
    bool bAllowOwnedSongs; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0xf]; // 0x69 (Size: 0xf, Type: PaddingProperty)

private:
    void OnOwnedSongsAllowedChanged(); // 0x11e552ac (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFabricJamTrackPlayerSongSelectVM) == 0x78, "Size mismatch for UFabricJamTrackPlayerSongSelectVM");
static_assert(offsetof(UFabricJamTrackPlayerSongSelectVM, bAllowOwnedSongs) == 0x68, "Offset mismatch for UFabricJamTrackPlayerSongSelectVM::bAllowOwnedSongs");

// Size: 0xf0 (Inherited: 0x128, Single: 0xffffffc8)
class UFabricJamTrackPlayerTrackInfoVM : public UFabricTrackInfoViewModel
{
public:
};

static_assert(sizeof(UFabricJamTrackPlayerTrackInfoVM) == 0xf0, "Size mismatch for UFabricJamTrackPlayerTrackInfoVM");

// Size: 0x98 (Inherited: 0x108, Single: 0xffffff90)
class UFabricJamTrackPlayerTrackNumberVM : public UFabricTrackNumberViewModel
{
public:
};

static_assert(sizeof(UFabricJamTrackPlayerTrackNumberVM) == 0x98, "Size mismatch for UFabricJamTrackPlayerTrackNumberVM");

