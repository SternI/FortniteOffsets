/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Blade
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "CoreUObject.h"
#include "SlateCore.h"
#include "Engine.h"
#include "UMG.h"

// Size: 0xc70 (Inherited: 0xa40, Single: 0x230)
class UWBP_Blade_C : public UFortBladeWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x310 (Size: 0x8, Type: StructProperty)
    USafeZone* SafeZone; // 0x318 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_BladeContent; // 0x320 (Size: 0x8, Type: ObjectProperty)
    UNamedSlot* NamedSlot_BladeContent_Foreground; // 0x328 (Size: 0x8, Type: ObjectProperty)
    UNamedSlot* NamedSlot_BladeContent; // 0x330 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* Grid_BladeBase; // 0x338 (Size: 0x8, Type: ObjectProperty)
    UImage* FullBackplate_Image; // 0x340 (Size: 0x8, Type: ObjectProperty)
    UButton* EmptyButton_ForPeekMode; // 0x348 (Size: 0x8, Type: ObjectProperty)
    UButton* EmptyButton_ClickCatcherCloseBlade; // 0x350 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_ExpandContract; // 0x358 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_BackplateOpacity; // 0x360 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_BetweenPeekStates; // 0x368 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<E_BladeUIAnchor> EBladeAlignment; // 0x370 (Size: 0x1, Type: ByteProperty)
    bool bStartExpanded; // 0x371 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_372[0x2]; // 0x372 (Size: 0x2, Type: PaddingProperty)
    int32_t RowSpan_Content; // 0x374 (Size: 0x4, Type: IntProperty)
    int32_t Row_Content; // 0x378 (Size: 0x4, Type: IntProperty)
    int32_t ColumnSpan_Content; // 0x37c (Size: 0x4, Type: IntProperty)
    int32_t Column_Content; // 0x380 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_384[0x4]; // 0x384 (Size: 0x4, Type: PaddingProperty)
    double ContentWidth; // 0x388 (Size: 0x8, Type: DoubleProperty)
    double ContentHeight; // 0x390 (Size: 0x8, Type: DoubleProperty)
    double LerpAnimatorExpandContractBlade; // 0x398 (Size: 0x8, Type: DoubleProperty)
    double NudgeForOffscreen; // 0x3a0 (Size: 0x8, Type: DoubleProperty)
    bool UseFullscreenBlade; // 0x3a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3a9[0x7]; // 0x3a9 (Size: 0x7, Type: PaddingProperty)
    double PeekPushPercent; // 0x3b0 (Size: 0x8, Type: DoubleProperty)
    double PeekPushPercent_Mobile; // 0x3b8 (Size: 0x8, Type: DoubleProperty)
    bool EnableSecondaryPeekState; // 0x3c0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3c1[0x7]; // 0x3c1 (Size: 0x7, Type: PaddingProperty)
    double PeekPushPercentSecondary; // 0x3c8 (Size: 0x8, Type: DoubleProperty)
    double PeekPushPercentSecondary_Mobile; // 0x3d0 (Size: 0x8, Type: DoubleProperty)
    uint8_t Pad_3d8[0x8]; // 0x3d8 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush BackplateImageBrush; // 0x3e0 (Size: 0xb0, Type: StructProperty)
    bool bHasClickCatcherButton; // 0x490 (Size: 0x1, Type: BoolProperty)
    bool bIsClickCatcherButtonTransparent; // 0x491 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_492[0xe]; // 0x492 (Size: 0xe, Type: PaddingProperty)
    FButtonStyle ClickCatcherButtonStyle; // 0x4a0 (Size: 0x390, Type: StructProperty)
    FButtonStyle TransparentButtonStyle; // 0x830 (Size: 0x390, Type: StructProperty)
    TEnumAsByte<E_BladeAnimationState> EBladeAnimState; // 0xbc0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_bc1[0x3]; // 0xbc1 (Size: 0x3, Type: PaddingProperty)
    FMargin ContentPadding; // 0xbc4 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_bd4[0x4]; // 0xbd4 (Size: 0x4, Type: PaddingProperty)
    uint8_t OnNotifyParentBladeCatcherClicked[0x10]; // 0xbd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool AnimateBackplateWhenExpanding; // 0xbe8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_be9[0x7]; // 0xbe9 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnNotifyParentBladeContractStart[0x10]; // 0xbf0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnNotifyParentBladeExpandStart[0x10]; // 0xc00 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool HidePeekButton; // 0xc10 (Size: 0x1, Type: BoolProperty)
    bool FinishedTransitionToSecondPeekState; // 0xc11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c12[0x6]; // 0xc12 (Size: 0x6, Type: PaddingProperty)
    double LerpAnimatorBetweenPeekStates; // 0xc18 (Size: 0x8, Type: DoubleProperty)
    uint8_t OnNotifyParentPeekButtonClicked[0x10]; // 0xc20 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnNotifyParentBladeTransitionFinished[0x10]; // 0xc30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool StartedTransitionToSecondPeekState; // 0xc40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c41[0x7]; // 0xc41 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnNotifyParentBladePeekStateTransitionFinished[0x10]; // 0xc48 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    double PreviousLerpAnimValue; // 0xc58 (Size: 0x8, Type: DoubleProperty)
    uint8_t OnNotifyBladeResized[0x10]; // 0xc60 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void SetLerpAnimatorBetweenPeekStates(double& CurrentAnimatorValue); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x2, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnNotifyParentPeekButtonClicked__DelegateSignature(); // 0x288a61c (Index: 0x5, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnNotifyParentBladeTransitionFinished__DelegateSignature(); // 0x288a61c (Index: 0x6, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnNotifyParentBladePeekStateTransitionFinished__DelegateSignature(); // 0x288a61c (Index: 0x7, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnNotifyParentBladeExpandStart__DelegateSignature(); // 0x288a61c (Index: 0x8, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnNotifyParentBladeContractStart__DelegateSignature(); // 0x288a61c (Index: 0x9, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnNotifyParentBladeCatcherClicked__DelegateSignature(); // 0x288a61c (Index: 0xa, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnNotifyBladeResized__DelegateSignature(); // 0x288a61c (Index: 0xb, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    FVector2D GetContentSize(); // 0x288a61c (Index: 0xf, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void GetContentOrViewport_SizeAndSetNudgeValue(bool& IsSizeZero); // 0x288a61c (Index: 0x10, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void Destruct(); // 0x288a61c (Index: 0x12, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x13, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void CalculateNudgeValue(double& PeekValue); // 0x288a61c (Index: 0x14, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetShouldStartInSecondPeekState(bool& ShouldStartInSecondPeekState); // 0x288a61c (Index: 0x19, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetPeekPushPercentFromWidgetSize(double& WidgetSize, double& PercentageOfTheWidgetShow, double& AditionnalOffset); // 0x288a61c (Index: 0x1a, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetPeekButtonVisibility(bool& HidePeekButton); // 0x288a61c (Index: 0x1b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetMobileStyle(); // 0x288a61c (Index: 0x1c, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetLerpAnimatorExpandContractBlade(double& CurrentAnimatorValue); // 0x288a61c (Index: 0x1d, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnViewportResized() const; // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent|Const)
};

static_assert(sizeof(UWBP_Blade_C) == 0xc70, "Size mismatch for UWBP_Blade_C");
static_assert(offsetof(UWBP_Blade_C, UberGraphFrame) == 0x310, "Offset mismatch for UWBP_Blade_C::UberGraphFrame");
static_assert(offsetof(UWBP_Blade_C, SafeZone) == 0x318, "Offset mismatch for UWBP_Blade_C::SafeZone");
static_assert(offsetof(UWBP_Blade_C, Overlay_BladeContent) == 0x320, "Offset mismatch for UWBP_Blade_C::Overlay_BladeContent");
static_assert(offsetof(UWBP_Blade_C, NamedSlot_BladeContent_Foreground) == 0x328, "Offset mismatch for UWBP_Blade_C::NamedSlot_BladeContent_Foreground");
static_assert(offsetof(UWBP_Blade_C, NamedSlot_BladeContent) == 0x330, "Offset mismatch for UWBP_Blade_C::NamedSlot_BladeContent");
static_assert(offsetof(UWBP_Blade_C, Grid_BladeBase) == 0x338, "Offset mismatch for UWBP_Blade_C::Grid_BladeBase");
static_assert(offsetof(UWBP_Blade_C, FullBackplate_Image) == 0x340, "Offset mismatch for UWBP_Blade_C::FullBackplate_Image");
static_assert(offsetof(UWBP_Blade_C, EmptyButton_ForPeekMode) == 0x348, "Offset mismatch for UWBP_Blade_C::EmptyButton_ForPeekMode");
static_assert(offsetof(UWBP_Blade_C, EmptyButton_ClickCatcherCloseBlade) == 0x350, "Offset mismatch for UWBP_Blade_C::EmptyButton_ClickCatcherCloseBlade");
static_assert(offsetof(UWBP_Blade_C, Anim_ExpandContract) == 0x358, "Offset mismatch for UWBP_Blade_C::Anim_ExpandContract");
static_assert(offsetof(UWBP_Blade_C, Anim_BackplateOpacity) == 0x360, "Offset mismatch for UWBP_Blade_C::Anim_BackplateOpacity");
static_assert(offsetof(UWBP_Blade_C, Anim_BetweenPeekStates) == 0x368, "Offset mismatch for UWBP_Blade_C::Anim_BetweenPeekStates");
static_assert(offsetof(UWBP_Blade_C, EBladeAlignment) == 0x370, "Offset mismatch for UWBP_Blade_C::EBladeAlignment");
static_assert(offsetof(UWBP_Blade_C, bStartExpanded) == 0x371, "Offset mismatch for UWBP_Blade_C::bStartExpanded");
static_assert(offsetof(UWBP_Blade_C, RowSpan_Content) == 0x374, "Offset mismatch for UWBP_Blade_C::RowSpan_Content");
static_assert(offsetof(UWBP_Blade_C, Row_Content) == 0x378, "Offset mismatch for UWBP_Blade_C::Row_Content");
static_assert(offsetof(UWBP_Blade_C, ColumnSpan_Content) == 0x37c, "Offset mismatch for UWBP_Blade_C::ColumnSpan_Content");
static_assert(offsetof(UWBP_Blade_C, Column_Content) == 0x380, "Offset mismatch for UWBP_Blade_C::Column_Content");
static_assert(offsetof(UWBP_Blade_C, ContentWidth) == 0x388, "Offset mismatch for UWBP_Blade_C::ContentWidth");
static_assert(offsetof(UWBP_Blade_C, ContentHeight) == 0x390, "Offset mismatch for UWBP_Blade_C::ContentHeight");
static_assert(offsetof(UWBP_Blade_C, LerpAnimatorExpandContractBlade) == 0x398, "Offset mismatch for UWBP_Blade_C::LerpAnimatorExpandContractBlade");
static_assert(offsetof(UWBP_Blade_C, NudgeForOffscreen) == 0x3a0, "Offset mismatch for UWBP_Blade_C::NudgeForOffscreen");
static_assert(offsetof(UWBP_Blade_C, UseFullscreenBlade) == 0x3a8, "Offset mismatch for UWBP_Blade_C::UseFullscreenBlade");
static_assert(offsetof(UWBP_Blade_C, PeekPushPercent) == 0x3b0, "Offset mismatch for UWBP_Blade_C::PeekPushPercent");
static_assert(offsetof(UWBP_Blade_C, PeekPushPercent_Mobile) == 0x3b8, "Offset mismatch for UWBP_Blade_C::PeekPushPercent_Mobile");
static_assert(offsetof(UWBP_Blade_C, EnableSecondaryPeekState) == 0x3c0, "Offset mismatch for UWBP_Blade_C::EnableSecondaryPeekState");
static_assert(offsetof(UWBP_Blade_C, PeekPushPercentSecondary) == 0x3c8, "Offset mismatch for UWBP_Blade_C::PeekPushPercentSecondary");
static_assert(offsetof(UWBP_Blade_C, PeekPushPercentSecondary_Mobile) == 0x3d0, "Offset mismatch for UWBP_Blade_C::PeekPushPercentSecondary_Mobile");
static_assert(offsetof(UWBP_Blade_C, BackplateImageBrush) == 0x3e0, "Offset mismatch for UWBP_Blade_C::BackplateImageBrush");
static_assert(offsetof(UWBP_Blade_C, bHasClickCatcherButton) == 0x490, "Offset mismatch for UWBP_Blade_C::bHasClickCatcherButton");
static_assert(offsetof(UWBP_Blade_C, bIsClickCatcherButtonTransparent) == 0x491, "Offset mismatch for UWBP_Blade_C::bIsClickCatcherButtonTransparent");
static_assert(offsetof(UWBP_Blade_C, ClickCatcherButtonStyle) == 0x4a0, "Offset mismatch for UWBP_Blade_C::ClickCatcherButtonStyle");
static_assert(offsetof(UWBP_Blade_C, TransparentButtonStyle) == 0x830, "Offset mismatch for UWBP_Blade_C::TransparentButtonStyle");
static_assert(offsetof(UWBP_Blade_C, EBladeAnimState) == 0xbc0, "Offset mismatch for UWBP_Blade_C::EBladeAnimState");
static_assert(offsetof(UWBP_Blade_C, ContentPadding) == 0xbc4, "Offset mismatch for UWBP_Blade_C::ContentPadding");
static_assert(offsetof(UWBP_Blade_C, OnNotifyParentBladeCatcherClicked) == 0xbd8, "Offset mismatch for UWBP_Blade_C::OnNotifyParentBladeCatcherClicked");
static_assert(offsetof(UWBP_Blade_C, AnimateBackplateWhenExpanding) == 0xbe8, "Offset mismatch for UWBP_Blade_C::AnimateBackplateWhenExpanding");
static_assert(offsetof(UWBP_Blade_C, OnNotifyParentBladeContractStart) == 0xbf0, "Offset mismatch for UWBP_Blade_C::OnNotifyParentBladeContractStart");
static_assert(offsetof(UWBP_Blade_C, OnNotifyParentBladeExpandStart) == 0xc00, "Offset mismatch for UWBP_Blade_C::OnNotifyParentBladeExpandStart");
static_assert(offsetof(UWBP_Blade_C, HidePeekButton) == 0xc10, "Offset mismatch for UWBP_Blade_C::HidePeekButton");
static_assert(offsetof(UWBP_Blade_C, FinishedTransitionToSecondPeekState) == 0xc11, "Offset mismatch for UWBP_Blade_C::FinishedTransitionToSecondPeekState");
static_assert(offsetof(UWBP_Blade_C, LerpAnimatorBetweenPeekStates) == 0xc18, "Offset mismatch for UWBP_Blade_C::LerpAnimatorBetweenPeekStates");
static_assert(offsetof(UWBP_Blade_C, OnNotifyParentPeekButtonClicked) == 0xc20, "Offset mismatch for UWBP_Blade_C::OnNotifyParentPeekButtonClicked");
static_assert(offsetof(UWBP_Blade_C, OnNotifyParentBladeTransitionFinished) == 0xc30, "Offset mismatch for UWBP_Blade_C::OnNotifyParentBladeTransitionFinished");
static_assert(offsetof(UWBP_Blade_C, StartedTransitionToSecondPeekState) == 0xc40, "Offset mismatch for UWBP_Blade_C::StartedTransitionToSecondPeekState");
static_assert(offsetof(UWBP_Blade_C, OnNotifyParentBladePeekStateTransitionFinished) == 0xc48, "Offset mismatch for UWBP_Blade_C::OnNotifyParentBladePeekStateTransitionFinished");
static_assert(offsetof(UWBP_Blade_C, PreviousLerpAnimValue) == 0xc58, "Offset mismatch for UWBP_Blade_C::PreviousLerpAnimValue");
static_assert(offsetof(UWBP_Blade_C, OnNotifyBladeResized) == 0xc60, "Offset mismatch for UWBP_Blade_C::OnNotifyBladeResized");

