/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FlexLegendWeaponGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"

// Size: 0x1300 (Inherited: 0x20a8, Single: 0xfffff258)
class UFlexLegendLeverShotgunLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    bool bPlayUpperBodyTargetingCustomOrIsTargetingCustom; // 0x12f0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12f1[0xf]; // 0x12f1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(UFlexLegendLeverShotgunLayerAnimInstance) == 0x1300, "Size mismatch for UFlexLegendLeverShotgunLayerAnimInstance");
static_assert(offsetof(UFlexLegendLeverShotgunLayerAnimInstance, bPlayUpperBodyTargetingCustomOrIsTargetingCustom) == 0x12f0, "Offset mismatch for UFlexLegendLeverShotgunLayerAnimInstance::bPlayUpperBodyTargetingCustomOrIsTargetingCustom");

