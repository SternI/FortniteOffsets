/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioShapes
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "AudioGameplay.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x280 (Inherited: 0x518, Single: 0xfffffd68)
class UAudioShapeBoxComponent : public UAudioShapePrimitiveComponent
{
public:
    FTransform BoxTransform; // 0x220 (Size: 0x60, Type: StructProperty)

public:
    void SetBoxTransform(const FTransform InTransform); // 0xc3d664c (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAudioShapeBoxComponent) == 0x280, "Size mismatch for UAudioShapeBoxComponent");
static_assert(offsetof(UAudioShapeBoxComponent, BoxTransform) == 0x220, "Offset mismatch for UAudioShapeBoxComponent::BoxTransform");

// Size: 0x220 (Inherited: 0x2f8, Single: 0xffffff28)
class UAudioShapePrimitiveComponent : public UAudioShapeComponent
{
public:
    USoundBase* SoundOnEdge; // 0x158 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SoundOnInside; // 0x160 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnInsideStateChanged[0x10]; // 0x168 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bUseOwningActorTransform; // 0x178 (Size: 0x1, Type: BoolProperty)
    bool bAutoRefreshShape; // 0x179 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_17a[0x6]; // 0x17a (Size: 0x6, Type: PaddingProperty)
    FVector ActorTransformScale; // 0x180 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_198[0x88]; // 0x198 (Size: 0x88, Type: PaddingProperty)

public:
    UAudioComponent* GetEdgeAudioComponent(); // 0xc3d61c0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    UAudioComponent* GetInsideAudioComponent(); // 0xc3d61e4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool GetIsPlayerInside() const; // 0xc3d6208 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UAudioShapePrimitiveComponent) == 0x220, "Size mismatch for UAudioShapePrimitiveComponent");
static_assert(offsetof(UAudioShapePrimitiveComponent, SoundOnEdge) == 0x158, "Offset mismatch for UAudioShapePrimitiveComponent::SoundOnEdge");
static_assert(offsetof(UAudioShapePrimitiveComponent, SoundOnInside) == 0x160, "Offset mismatch for UAudioShapePrimitiveComponent::SoundOnInside");
static_assert(offsetof(UAudioShapePrimitiveComponent, OnInsideStateChanged) == 0x168, "Offset mismatch for UAudioShapePrimitiveComponent::OnInsideStateChanged");
static_assert(offsetof(UAudioShapePrimitiveComponent, bUseOwningActorTransform) == 0x178, "Offset mismatch for UAudioShapePrimitiveComponent::bUseOwningActorTransform");
static_assert(offsetof(UAudioShapePrimitiveComponent, bAutoRefreshShape) == 0x179, "Offset mismatch for UAudioShapePrimitiveComponent::bAutoRefreshShape");
static_assert(offsetof(UAudioShapePrimitiveComponent, ActorTransformScale) == 0x180, "Offset mismatch for UAudioShapePrimitiveComponent::ActorTransformScale");

// Size: 0x158 (Inherited: 0x1a0, Single: 0xffffffb8)
class UAudioShapeComponent : public UAudioGameplayComponent
{
public:
    uint8_t Pad_c0[0x8]; // 0xc0 (Size: 0x8, Type: PaddingProperty)
    float MaxDistanceOffset; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float SmoothingDistance; // 0xcc (Size: 0x4, Type: FloatProperty)
    float FadeInTime; // 0xd0 (Size: 0x4, Type: FloatProperty)
    float FadeOutTime; // 0xd4 (Size: 0x4, Type: FloatProperty)
    uint8_t OnAudibleStateChanged[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TMap<UAudioComponent*, FName> AudioComponents; // 0xe8 (Size: 0x50, Type: MapProperty)
    TArray<APlayerController*> LocalControllers; // 0x138 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_148[0x10]; // 0x148 (Size: 0x10, Type: PaddingProperty)

public:
    bool IsAudioShapeReady(); // 0xc3d64b4 (Index: 0x2, Flags: Native|Public)
    bool IsShapeActive() const; // 0xc3d64dc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void UpdateAudioShape(const TArray<APlayerController*> InLocalControllers); // 0xc3d6b70 (Index: 0x4, Flags: Final|Native|Public|HasOutParms)

protected:
    void Disable(); // 0x270d644 (Index: 0x0, Flags: Native|Protected|BlueprintCallable)
    void Enable(); // 0x43388fc (Index: 0x1, Flags: Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UAudioShapeComponent) == 0x158, "Size mismatch for UAudioShapeComponent");
static_assert(offsetof(UAudioShapeComponent, MaxDistanceOffset) == 0xc8, "Offset mismatch for UAudioShapeComponent::MaxDistanceOffset");
static_assert(offsetof(UAudioShapeComponent, SmoothingDistance) == 0xcc, "Offset mismatch for UAudioShapeComponent::SmoothingDistance");
static_assert(offsetof(UAudioShapeComponent, FadeInTime) == 0xd0, "Offset mismatch for UAudioShapeComponent::FadeInTime");
static_assert(offsetof(UAudioShapeComponent, FadeOutTime) == 0xd4, "Offset mismatch for UAudioShapeComponent::FadeOutTime");
static_assert(offsetof(UAudioShapeComponent, OnAudibleStateChanged) == 0xd8, "Offset mismatch for UAudioShapeComponent::OnAudibleStateChanged");
static_assert(offsetof(UAudioShapeComponent, AudioComponents) == 0xe8, "Offset mismatch for UAudioShapeComponent::AudioComponents");
static_assert(offsetof(UAudioShapeComponent, LocalControllers) == 0x138, "Offset mismatch for UAudioShapeComponent::LocalControllers");

// Size: 0x220 (Inherited: 0x518, Single: 0xfffffd08)
class UAudioShapeCylinderComponent : public UAudioShapePrimitiveComponent
{
public:
    float HalfHeight; // 0x218 (Size: 0x4, Type: FloatProperty)
    float Radius; // 0x21c (Size: 0x4, Type: FloatProperty)

public:
    void SetHalfHeight(float& InHalfHeight); // 0xc3d67dc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetRadius(float& InRadius); // 0xc3d6910 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioShapeCylinderComponent) == 0x220, "Size mismatch for UAudioShapeCylinderComponent");
static_assert(offsetof(UAudioShapeCylinderComponent, HalfHeight) == 0x218, "Offset mismatch for UAudioShapeCylinderComponent::HalfHeight");
static_assert(offsetof(UAudioShapeCylinderComponent, Radius) == 0x21c, "Offset mismatch for UAudioShapeCylinderComponent::Radius");

// Size: 0x250 (Inherited: 0x518, Single: 0xfffffd38)
class UAudioShapeLineComponent : public UAudioShapePrimitiveComponent
{
public:
    FVector StartPoint; // 0x218 (Size: 0x18, Type: StructProperty)
    FVector Endpoint; // 0x230 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_248[0x8]; // 0x248 (Size: 0x8, Type: PaddingProperty)

public:
    void SetEndPoint(const FVector InEndPoint); // 0x5987a74 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetStartPoint(const FVector InStartPoint); // 0x5987984 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAudioShapeLineComponent) == 0x250, "Size mismatch for UAudioShapeLineComponent");
static_assert(offsetof(UAudioShapeLineComponent, StartPoint) == 0x218, "Offset mismatch for UAudioShapeLineComponent::StartPoint");
static_assert(offsetof(UAudioShapeLineComponent, Endpoint) == 0x230, "Offset mismatch for UAudioShapeLineComponent::Endpoint");

// Size: 0x230 (Inherited: 0x518, Single: 0xfffffd18)
class UAudioShapeLineListComponent : public UAudioShapePrimitiveComponent
{
public:
    TArray<FVector> PointList; // 0x218 (Size: 0x10, Type: ArrayProperty)
    bool bClosedLoop; // 0x228 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_229[0x7]; // 0x229 (Size: 0x7, Type: PaddingProperty)

public:
    int32_t AddPoint(const FVector InPoint); // 0xc3d6050 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void GetPoints(TArray<FVector>& OutPoints) const; // 0xc3d6224 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool RemovePoint(int32_t& InIndex); // 0xc3d64f8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    bool UpdatePoint(int32_t& InIndex, const FVector InPoint); // 0xc3d6dfc (Index: 0x3, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAudioShapeLineListComponent) == 0x230, "Size mismatch for UAudioShapeLineListComponent");
static_assert(offsetof(UAudioShapeLineListComponent, PointList) == 0x218, "Offset mismatch for UAudioShapeLineListComponent::PointList");
static_assert(offsetof(UAudioShapeLineListComponent, bClosedLoop) == 0x228, "Offset mismatch for UAudioShapeLineListComponent::bClosedLoop");

// Size: 0x220 (Inherited: 0x518, Single: 0xfffffd08)
class UAudioShapeSphereComponent : public UAudioShapePrimitiveComponent
{
public:
    float Radius; // 0x218 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_21c[0x4]; // 0x21c (Size: 0x4, Type: PaddingProperty)

public:
    void SetRadius(float& InRadius); // 0xc3d67dc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioShapeSphereComponent) == 0x220, "Size mismatch for UAudioShapeSphereComponent");
static_assert(offsetof(UAudioShapeSphereComponent, Radius) == 0x218, "Offset mismatch for UAudioShapeSphereComponent::Radius");

// Size: 0x2e0 (Inherited: 0x2f8, Single: 0xffffffe8)
class UAudioShapeSplineComponent : public UAudioShapeComponent
{
public:
    float TravelDistanceCrossfadeThreshold; // 0x158 (Size: 0x4, Type: FloatProperty)
    float TravelDistanceCrossfadeTime; // 0x15c (Size: 0x4, Type: FloatProperty)
    USoundBase* ClosestPointSound; // 0x160 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnAudioUpdateInAudibleRange[0x10]; // 0x168 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_178[0x58]; // 0x178 (Size: 0x58, Type: PaddingProperty)
    FBox SplineAABB; // 0x1d0 (Size: 0x38, Type: StructProperty)
    TArray<UAudioComponent*> FadingComponents; // 0x208 (Size: 0x10, Type: ArrayProperty)
    USplineComponent* Spline; // 0x218 (Size: 0x8, Type: ObjectProperty)
    TArray<FSplineSegmentData> SplineSegments; // 0x220 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_230[0xb0]; // 0x230 (Size: 0xb0, Type: PaddingProperty)

public:
    UAudioComponent* GetAudioComponent(); // 0xc3d6190 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetSpline(USplineComponent*& NewSpline); // 0xc3d6a44 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioShapeSplineComponent) == 0x2e0, "Size mismatch for UAudioShapeSplineComponent");
static_assert(offsetof(UAudioShapeSplineComponent, TravelDistanceCrossfadeThreshold) == 0x158, "Offset mismatch for UAudioShapeSplineComponent::TravelDistanceCrossfadeThreshold");
static_assert(offsetof(UAudioShapeSplineComponent, TravelDistanceCrossfadeTime) == 0x15c, "Offset mismatch for UAudioShapeSplineComponent::TravelDistanceCrossfadeTime");
static_assert(offsetof(UAudioShapeSplineComponent, ClosestPointSound) == 0x160, "Offset mismatch for UAudioShapeSplineComponent::ClosestPointSound");
static_assert(offsetof(UAudioShapeSplineComponent, OnAudioUpdateInAudibleRange) == 0x168, "Offset mismatch for UAudioShapeSplineComponent::OnAudioUpdateInAudibleRange");
static_assert(offsetof(UAudioShapeSplineComponent, SplineAABB) == 0x1d0, "Offset mismatch for UAudioShapeSplineComponent::SplineAABB");
static_assert(offsetof(UAudioShapeSplineComponent, FadingComponents) == 0x208, "Offset mismatch for UAudioShapeSplineComponent::FadingComponents");
static_assert(offsetof(UAudioShapeSplineComponent, Spline) == 0x218, "Offset mismatch for UAudioShapeSplineComponent::Spline");
static_assert(offsetof(UAudioShapeSplineComponent, SplineSegments) == 0x220, "Offset mismatch for UAudioShapeSplineComponent::SplineSegments");

// Size: 0x98 (Inherited: 0x88, Single: 0x10)
class UAudioShapeSubsystem : public UWorldSubsystem
{
public:
    uint8_t Pad_30[0x28]; // 0x30 (Size: 0x28, Type: PaddingProperty)
    TArray<UAudioShapeComponent*> PendingAudioShapes; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<UAudioShapeComponent*> AudioShapes; // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<APlayerController*> LocalControllers; // 0x78 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_88[0x10]; // 0x88 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UAudioShapeSubsystem) == 0x98, "Size mismatch for UAudioShapeSubsystem");
static_assert(offsetof(UAudioShapeSubsystem, PendingAudioShapes) == 0x58, "Offset mismatch for UAudioShapeSubsystem::PendingAudioShapes");
static_assert(offsetof(UAudioShapeSubsystem, AudioShapes) == 0x68, "Offset mismatch for UAudioShapeSubsystem::AudioShapes");
static_assert(offsetof(UAudioShapeSubsystem, LocalControllers) == 0x78, "Offset mismatch for UAudioShapeSubsystem::LocalControllers");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FSplineSegmentData
{
    FBoxSphereBounds Bounds; // 0x0 (Size: 0x38, Type: StructProperty)
    int32_t PointIndex; // 0x38 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FSplineSegmentData) == 0x40, "Size mismatch for FSplineSegmentData");
static_assert(offsetof(FSplineSegmentData, Bounds) == 0x0, "Offset mismatch for FSplineSegmentData::Bounds");
static_assert(offsetof(FSplineSegmentData, PointIndex) == 0x38, "Offset mismatch for FSplineSegmentData::PointIndex");

