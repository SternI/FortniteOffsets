/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BikeKidRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "_Verse.h"
#include "ModularGameplay.h"
#include "InputCore.h"
#include "GameplayTags.h"
#include "AudioGameplay.h"
#include "TargetingSystem.h"
#include "Niagara.h"
#include "EnhancedInput.h"

// Size: 0x148 (Inherited: 0x310, Single: 0xfffffe38)
class UFortBikeKidAnalyticsComponent : public UFortControllerComponent
{
public:
    float SessionStartTime; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float SessionLength; // 0xc4 (Size: 0x4, Type: FloatProperty)
    FScalableFloat MinSessionLength; // 0xc8 (Size: 0x28, Type: StructProperty)
    float DistanceTraveled; // 0xf0 (Size: 0x4, Type: FloatProperty)
    FGameplayTag DismissalReason; // 0xf4 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_f8[0x8]; // 0xf8 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat DistanceTraveledUpdateInterval; // 0x100 (Size: 0x28, Type: StructProperty)
    FTimerHandle DistanceTraveledUpdateTimerHandle; // 0x128 (Size: 0x8, Type: StructProperty)
    FVector LastRecorderBikeKidLocation; // 0x130 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UFortBikeKidAnalyticsComponent) == 0x148, "Size mismatch for UFortBikeKidAnalyticsComponent");
static_assert(offsetof(UFortBikeKidAnalyticsComponent, SessionStartTime) == 0xc0, "Offset mismatch for UFortBikeKidAnalyticsComponent::SessionStartTime");
static_assert(offsetof(UFortBikeKidAnalyticsComponent, SessionLength) == 0xc4, "Offset mismatch for UFortBikeKidAnalyticsComponent::SessionLength");
static_assert(offsetof(UFortBikeKidAnalyticsComponent, MinSessionLength) == 0xc8, "Offset mismatch for UFortBikeKidAnalyticsComponent::MinSessionLength");
static_assert(offsetof(UFortBikeKidAnalyticsComponent, DistanceTraveled) == 0xf0, "Offset mismatch for UFortBikeKidAnalyticsComponent::DistanceTraveled");
static_assert(offsetof(UFortBikeKidAnalyticsComponent, DismissalReason) == 0xf4, "Offset mismatch for UFortBikeKidAnalyticsComponent::DismissalReason");
static_assert(offsetof(UFortBikeKidAnalyticsComponent, DistanceTraveledUpdateInterval) == 0x100, "Offset mismatch for UFortBikeKidAnalyticsComponent::DistanceTraveledUpdateInterval");
static_assert(offsetof(UFortBikeKidAnalyticsComponent, DistanceTraveledUpdateTimerHandle) == 0x128, "Offset mismatch for UFortBikeKidAnalyticsComponent::DistanceTraveledUpdateTimerHandle");
static_assert(offsetof(UFortBikeKidAnalyticsComponent, LastRecorderBikeKidLocation) == 0x130, "Offset mismatch for UFortBikeKidAnalyticsComponent::LastRecorderBikeKidLocation");

// Size: 0xc70 (Inherited: 0x1a88, Single: 0xfffff1e8)
class UFortGameplayAbility_BikeKid_SpeedBoost : public UFortGameplayAbility_BikeKid_TargetingBase
{
public:
    FGameplayTag DoorBashCueTag; // 0xb80 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_b84[0x4]; // 0xb84 (Size: 0x4, Type: PaddingProperty)
    UClass* DamageGameplayEffectClass; // 0xb88 (Size: 0x8, Type: ClassProperty)
    FGameplayTag DoorBashPawnLaunchGameplayCueTag; // 0xb90 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_b94[0x4]; // 0xb94 (Size: 0x4, Type: PaddingProperty)
    FScalableFloat DoorBashEnabledHotfix; // 0xb98 (Size: 0x28, Type: StructProperty)
    FScalableFloat DoorBashSphereRadiusForPawnLaunch; // 0xbc0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DoorBashScalarForPawnLaunch; // 0xbe8 (Size: 0x28, Type: StructProperty)
    TArray<TEnumAsByte<EObjectTypeQuery>> DoorBashCollisionTypesForPawn; // 0xc10 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat DoorBashEnabled; // 0xc20 (Size: 0x28, Type: StructProperty)
    FScalableFloat DamageOnBoostEnabled; // 0xc48 (Size: 0x28, Type: StructProperty)

protected:
    virtual void OnBoostedIntoActor(const FHitResult HitResult); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnDoorBashed(const FHitResult HitResult, UFortBuildingWallDoorComponent*& BashedDoor); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortGameplayAbility_BikeKid_SpeedBoost) == 0xc70, "Size mismatch for UFortGameplayAbility_BikeKid_SpeedBoost");
static_assert(offsetof(UFortGameplayAbility_BikeKid_SpeedBoost, DoorBashCueTag) == 0xb80, "Offset mismatch for UFortGameplayAbility_BikeKid_SpeedBoost::DoorBashCueTag");
static_assert(offsetof(UFortGameplayAbility_BikeKid_SpeedBoost, DamageGameplayEffectClass) == 0xb88, "Offset mismatch for UFortGameplayAbility_BikeKid_SpeedBoost::DamageGameplayEffectClass");
static_assert(offsetof(UFortGameplayAbility_BikeKid_SpeedBoost, DoorBashPawnLaunchGameplayCueTag) == 0xb90, "Offset mismatch for UFortGameplayAbility_BikeKid_SpeedBoost::DoorBashPawnLaunchGameplayCueTag");
static_assert(offsetof(UFortGameplayAbility_BikeKid_SpeedBoost, DoorBashEnabledHotfix) == 0xb98, "Offset mismatch for UFortGameplayAbility_BikeKid_SpeedBoost::DoorBashEnabledHotfix");
static_assert(offsetof(UFortGameplayAbility_BikeKid_SpeedBoost, DoorBashSphereRadiusForPawnLaunch) == 0xbc0, "Offset mismatch for UFortGameplayAbility_BikeKid_SpeedBoost::DoorBashSphereRadiusForPawnLaunch");
static_assert(offsetof(UFortGameplayAbility_BikeKid_SpeedBoost, DoorBashScalarForPawnLaunch) == 0xbe8, "Offset mismatch for UFortGameplayAbility_BikeKid_SpeedBoost::DoorBashScalarForPawnLaunch");
static_assert(offsetof(UFortGameplayAbility_BikeKid_SpeedBoost, DoorBashCollisionTypesForPawn) == 0xc10, "Offset mismatch for UFortGameplayAbility_BikeKid_SpeedBoost::DoorBashCollisionTypesForPawn");
static_assert(offsetof(UFortGameplayAbility_BikeKid_SpeedBoost, DoorBashEnabled) == 0xc20, "Offset mismatch for UFortGameplayAbility_BikeKid_SpeedBoost::DoorBashEnabled");
static_assert(offsetof(UFortGameplayAbility_BikeKid_SpeedBoost, DamageOnBoostEnabled) == 0xc48, "Offset mismatch for UFortGameplayAbility_BikeKid_SpeedBoost::DamageOnBoostEnabled");

// Size: 0xb80 (Inherited: 0xf08, Single: 0xfffffc78)
class UFortGameplayAbility_BikeKid_TargetingBase : public UFortGameplayAbility
{
public:
    UTargetingPreset* TargetingPreset; // 0xb38 (Size: 0x8, Type: ObjectProperty)
    FTargetingRequestHandle AsyncTargetingHandle; // 0xb40 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_b44[0x4]; // 0xb44 (Size: 0x4, Type: PaddingProperty)
    FTimerHandle TargetingTimerHandle; // 0xb48 (Size: 0x8, Type: StructProperty)
    FScalableFloat TargetingInterval; // 0xb50 (Size: 0x28, Type: StructProperty)
    bool bUseControllerAsInstigator; // 0xb78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b79[0x7]; // 0xb79 (Size: 0x7, Type: PaddingProperty)

protected:
    virtual void BP_OnTargetsFound(const FTargetingRequestHandle TargetingHandle); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    void StartTargeting(); // 0x11268864 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    void StopTargeting(); // 0x1126888c (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortGameplayAbility_BikeKid_TargetingBase) == 0xb80, "Size mismatch for UFortGameplayAbility_BikeKid_TargetingBase");
static_assert(offsetof(UFortGameplayAbility_BikeKid_TargetingBase, TargetingPreset) == 0xb38, "Offset mismatch for UFortGameplayAbility_BikeKid_TargetingBase::TargetingPreset");
static_assert(offsetof(UFortGameplayAbility_BikeKid_TargetingBase, AsyncTargetingHandle) == 0xb40, "Offset mismatch for UFortGameplayAbility_BikeKid_TargetingBase::AsyncTargetingHandle");
static_assert(offsetof(UFortGameplayAbility_BikeKid_TargetingBase, TargetingTimerHandle) == 0xb48, "Offset mismatch for UFortGameplayAbility_BikeKid_TargetingBase::TargetingTimerHandle");
static_assert(offsetof(UFortGameplayAbility_BikeKid_TargetingBase, TargetingInterval) == 0xb50, "Offset mismatch for UFortGameplayAbility_BikeKid_TargetingBase::TargetingInterval");
static_assert(offsetof(UFortGameplayAbility_BikeKid_TargetingBase, bUseControllerAsInstigator) == 0xb78, "Offset mismatch for UFortGameplayAbility_BikeKid_TargetingBase::bUseControllerAsInstigator");

// Size: 0xb60 (Inherited: 0xf08, Single: 0xfffffc58)
class UFortGameplayAbility_BikeKid_Activate : public UFortGameplayAbility
{
public:
    UClass* RCActorClass; // 0xb38 (Size: 0x8, Type: ClassProperty)
    FVector SpawnOffset; // 0xb40 (Size: 0x18, Type: StructProperty)
    float ForwardObstructionCheckDistance; // 0xb58 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_b5c[0x4]; // 0xb5c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortGameplayAbility_BikeKid_Activate) == 0xb60, "Size mismatch for UFortGameplayAbility_BikeKid_Activate");
static_assert(offsetof(UFortGameplayAbility_BikeKid_Activate, RCActorClass) == 0xb38, "Offset mismatch for UFortGameplayAbility_BikeKid_Activate::RCActorClass");
static_assert(offsetof(UFortGameplayAbility_BikeKid_Activate, SpawnOffset) == 0xb40, "Offset mismatch for UFortGameplayAbility_BikeKid_Activate::SpawnOffset");
static_assert(offsetof(UFortGameplayAbility_BikeKid_Activate, ForwardObstructionCheckDistance) == 0xb58, "Offset mismatch for UFortGameplayAbility_BikeKid_Activate::ForwardObstructionCheckDistance");

// Size: 0xb48 (Inherited: 0xf08, Single: 0xfffffc40)
class UFortGameplayAbility_BikeKid_Dismiss : public UFortGameplayAbility
{
public:
    FBikeKidDismissalData DismissDelayData; // 0xb38 (Size: 0x10, Type: StructProperty)

protected:
    AFortBikeKid* GetControlledBikeKid() const; // 0x112669e4 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortGameplayAbility_BikeKid_Dismiss) == 0xb48, "Size mismatch for UFortGameplayAbility_BikeKid_Dismiss");
static_assert(offsetof(UFortGameplayAbility_BikeKid_Dismiss, DismissDelayData) == 0xb38, "Offset mismatch for UFortGameplayAbility_BikeKid_Dismiss::DismissDelayData");

// Size: 0xcb8 (Inherited: 0x1a88, Single: 0xfffff230)
class UFortGameplayAbility_BikeKid_MarkPotentialTargets : public UFortGameplayAbility_BikeKid_TargetingBase
{
public:
    FIndicatedActorData IndicatedActorData; // 0xb80 (Size: 0x100, Type: StructProperty)
    uint8_t Pad_c80[0x10]; // 0xc80 (Size: 0x10, Type: PaddingProperty)
    FScalableFloat MaxNumberOfPotentialTargets; // 0xc90 (Size: 0x28, Type: StructProperty)

protected:
    virtual void OnStartHighlightingTarget(AActor*& Target); // 0x288a61c (Index: 0x0, Flags: BlueprintCosmetic|Event|Protected|BlueprintEvent)
    virtual void OnStoppedHighlightingTarget(AActor*& Target); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortGameplayAbility_BikeKid_MarkPotentialTargets) == 0xcb8, "Size mismatch for UFortGameplayAbility_BikeKid_MarkPotentialTargets");
static_assert(offsetof(UFortGameplayAbility_BikeKid_MarkPotentialTargets, IndicatedActorData) == 0xb80, "Offset mismatch for UFortGameplayAbility_BikeKid_MarkPotentialTargets::IndicatedActorData");
static_assert(offsetof(UFortGameplayAbility_BikeKid_MarkPotentialTargets, MaxNumberOfPotentialTargets) == 0xc90, "Offset mismatch for UFortGameplayAbility_BikeKid_MarkPotentialTargets::MaxNumberOfPotentialTargets");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UBikeKidPassiveMarkPayload : public UObject
{
public:
    FBikeKidStatusData TargetStatus; // 0x28 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(UBikeKidPassiveMarkPayload) == 0x30, "Size mismatch for UBikeKidPassiveMarkPayload");
static_assert(offsetof(UBikeKidPassiveMarkPayload, TargetStatus) == 0x28, "Offset mismatch for UBikeKidPassiveMarkPayload::TargetStatus");

// Size: 0xd80 (Inherited: 0x1a88, Single: 0xfffff2f8)
class UFortGameplayAbility_BikeKid_PassiveMark : public UFortGameplayAbility_BikeKid_TargetingBase
{
public:
    FBikeKidStatusData CurrentTargetStatus; // 0xb80 (Size: 0x8, Type: StructProperty)
    FStenciledActorData StenciledActorData; // 0xb88 (Size: 0x80, Type: StructProperty)
    FIndicatedActorData IndicatedActorData; // 0xc08 (Size: 0x100, Type: StructProperty)
    FScalableFloat ActorTargetingRange; // 0xd08 (Size: 0x28, Type: StructProperty)
    FScalableFloat TimeToConfirmTarget; // 0xd30 (Size: 0x28, Type: StructProperty)
    AActor* CurrentTarget; // 0xd58 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle TargetConfirmationTimerHandle; // 0xd60 (Size: 0x8, Type: StructProperty)
    UBikeKidPassiveMarkPayload* PayloadCache; // 0xd68 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d70[0x10]; // 0xd70 (Size: 0x10, Type: PaddingProperty)

private:
    void OnActorIndicatorExpired(AActor*& IndicatedActor); // 0x11266d2c (Index: 0x1, Flags: Final|Native|Private)

protected:
    virtual void BP_OnTargetStatusChanged(AActor*& ActiveTarget); // 0x288a61c (Index: 0x0, Flags: BlueprintAuthorityOnly|Event|Protected|BlueprintEvent)
    void OnRep_CurrentTargetStatus(); // 0x11267144 (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortGameplayAbility_BikeKid_PassiveMark) == 0xd80, "Size mismatch for UFortGameplayAbility_BikeKid_PassiveMark");
static_assert(offsetof(UFortGameplayAbility_BikeKid_PassiveMark, CurrentTargetStatus) == 0xb80, "Offset mismatch for UFortGameplayAbility_BikeKid_PassiveMark::CurrentTargetStatus");
static_assert(offsetof(UFortGameplayAbility_BikeKid_PassiveMark, StenciledActorData) == 0xb88, "Offset mismatch for UFortGameplayAbility_BikeKid_PassiveMark::StenciledActorData");
static_assert(offsetof(UFortGameplayAbility_BikeKid_PassiveMark, IndicatedActorData) == 0xc08, "Offset mismatch for UFortGameplayAbility_BikeKid_PassiveMark::IndicatedActorData");
static_assert(offsetof(UFortGameplayAbility_BikeKid_PassiveMark, ActorTargetingRange) == 0xd08, "Offset mismatch for UFortGameplayAbility_BikeKid_PassiveMark::ActorTargetingRange");
static_assert(offsetof(UFortGameplayAbility_BikeKid_PassiveMark, TimeToConfirmTarget) == 0xd30, "Offset mismatch for UFortGameplayAbility_BikeKid_PassiveMark::TimeToConfirmTarget");
static_assert(offsetof(UFortGameplayAbility_BikeKid_PassiveMark, CurrentTarget) == 0xd58, "Offset mismatch for UFortGameplayAbility_BikeKid_PassiveMark::CurrentTarget");
static_assert(offsetof(UFortGameplayAbility_BikeKid_PassiveMark, TargetConfirmationTimerHandle) == 0xd60, "Offset mismatch for UFortGameplayAbility_BikeKid_PassiveMark::TargetConfirmationTimerHandle");
static_assert(offsetof(UFortGameplayAbility_BikeKid_PassiveMark, PayloadCache) == 0xd68, "Offset mismatch for UFortGameplayAbility_BikeKid_PassiveMark::PayloadCache");

// Size: 0xbb0 (Inherited: 0xf08, Single: 0xfffffca8)
class UFortGameplayAbility_BikeKid_Tether : public UFortGameplayAbility
{
public:
    FScalableFloat WarningRange; // 0xb38 (Size: 0x28, Type: StructProperty)
    FScalableFloat SignalLossRange; // 0xb60 (Size: 0x28, Type: StructProperty)
    bool bIsInWarningRange; // 0xb88 (Size: 0x1, Type: BoolProperty)
    bool bIsInSignalLossRange; // 0xb89 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b8a[0x6]; // 0xb8a (Size: 0x6, Type: PaddingProperty)
    FTimerHandle TetheringTimerHandle; // 0xb90 (Size: 0x8, Type: StructProperty)
    FTimerHandle TetheringReportTimerHandle; // 0xb98 (Size: 0x8, Type: StructProperty)
    FBikeKidDismissalData DismissDelayData; // 0xba0 (Size: 0x10, Type: StructProperty)

protected:
    void StartCheckingDistances(); // 0x11268850 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void StopCheckingDistances(); // 0x11268878 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortGameplayAbility_BikeKid_Tether) == 0xbb0, "Size mismatch for UFortGameplayAbility_BikeKid_Tether");
static_assert(offsetof(UFortGameplayAbility_BikeKid_Tether, WarningRange) == 0xb38, "Offset mismatch for UFortGameplayAbility_BikeKid_Tether::WarningRange");
static_assert(offsetof(UFortGameplayAbility_BikeKid_Tether, SignalLossRange) == 0xb60, "Offset mismatch for UFortGameplayAbility_BikeKid_Tether::SignalLossRange");
static_assert(offsetof(UFortGameplayAbility_BikeKid_Tether, bIsInWarningRange) == 0xb88, "Offset mismatch for UFortGameplayAbility_BikeKid_Tether::bIsInWarningRange");
static_assert(offsetof(UFortGameplayAbility_BikeKid_Tether, bIsInSignalLossRange) == 0xb89, "Offset mismatch for UFortGameplayAbility_BikeKid_Tether::bIsInSignalLossRange");
static_assert(offsetof(UFortGameplayAbility_BikeKid_Tether, TetheringTimerHandle) == 0xb90, "Offset mismatch for UFortGameplayAbility_BikeKid_Tether::TetheringTimerHandle");
static_assert(offsetof(UFortGameplayAbility_BikeKid_Tether, TetheringReportTimerHandle) == 0xb98, "Offset mismatch for UFortGameplayAbility_BikeKid_Tether::TetheringReportTimerHandle");
static_assert(offsetof(UFortGameplayAbility_BikeKid_Tether, DismissDelayData) == 0xba0, "Offset mismatch for UFortGameplayAbility_BikeKid_Tether::DismissDelayData");

// Size: 0x368 (Inherited: 0xbc0, Single: 0xfffff7a8)
class AFortAthenaMutator_BikeKid : public AFortAthenaMutator
{
public:
    bool bIsControllingBikeKid; // 0x360 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_361[0x7]; // 0x361 (Size: 0x7, Type: PaddingProperty)

private:
    void OnViewTargetChanged(AFortPlayerController*& PlayerController, AActor*& OldViewTarget, AActor*& NewViewTarget); // 0x11267290 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(AFortAthenaMutator_BikeKid) == 0x368, "Size mismatch for AFortAthenaMutator_BikeKid");
static_assert(offsetof(AFortAthenaMutator_BikeKid, bIsControllingBikeKid) == 0x360, "Offset mismatch for AFortAthenaMutator_BikeKid::bIsControllingBikeKid");

// Size: 0x7b0 (Inherited: 0x660, Single: 0x150)
class AFortBikeKid : public UCharacter
{
public:
    uint8_t Pad_328[0x358]; // 0x328 (Size: 0x358, Type: PaddingProperty)
    UNiagaraComponent* NSBikeKidIdle_Native; // 0x680 (Size: 0x8, Type: ObjectProperty)
    UClass* TeamMateIndicatorMarkerWidgetClass; // 0x688 (Size: 0x8, Type: ClassProperty)
    UAudioComponent* BikeKidMotorLoopComponent; // 0x690 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* BikeKidThrustSoundComponent; // 0x698 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer DefaultTags; // 0x6a0 (Size: 0x20, Type: StructProperty)
    FGameplayTag ExplosionCueTag; // 0x6c0 (Size: 0x4, Type: StructProperty)
    bool bExploded; // 0x6c4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6c5[0xb]; // 0x6c5 (Size: 0xb, Type: PaddingProperty)
    UFortAbilitySystemComponent* AbilitySystemComponent; // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    UFortActorComponent_Affiliation* AffiliationComponent; // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    UFortAbilitySet* StartupAbilitySet; // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    AFortPawn* ControllingPlayerPawn; // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    UFortHealthSet* HealthSet; // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    UFortChargingSet_BikeKidEnergy* EnergySet; // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    FFortAttributeInitializationKey AttributeInitKey; // 0x700 (Size: 0x8, Type: StructProperty)
    TEnumAsByte<EPhysicalSurface> PrimarySurfaceType; // 0x708 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EFortBaseWeaponDamage> WeaponResponseType; // 0x709 (Size: 0x1, Type: ByteProperty)
    bool bPlayedDeath; // 0x70a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_70b[0x1]; // 0x70b (Size: 0x1, Type: PaddingProperty)
    FBikeKidDismissalData OutOfHealthDismissDelayData; // 0x70c (Size: 0x10, Type: StructProperty)
    uint8_t Pad_71c[0x4]; // 0x71c (Size: 0x4, Type: PaddingProperty)
    TArray<FFortGameplayEffectContainerSpec> ExplodeEffectContainerSpecs; // 0x720 (Size: 0x10, Type: ArrayProperty)
    uint8_t OnTeamIndexChanged[0x10]; // 0x730 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UClass* PawnOverrideComponentClass; // 0x740 (Size: 0x8, Type: ClassProperty)
    USoundBase* BikeKidMotorLoopSound; // 0x748 (Size: 0x8, Type: ObjectProperty)
    USoundBase* BikeKidThrusterSound; // 0x750 (Size: 0x8, Type: ObjectProperty)
    UAudioParameterComponent* AudioParameter; // 0x758 (Size: 0x8, Type: ObjectProperty)
    FName LocallyViewedPawnAudioParamName; // 0x760 (Size: 0x4, Type: NameProperty)
    FName IsEnemyAudioParamName; // 0x764 (Size: 0x4, Type: NameProperty)
    FName ThrustAmountAudioParamName; // 0x768 (Size: 0x4, Type: NameProperty)
    float ThrustSoundThreshold; // 0x76c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_770[0x8]; // 0x770 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat LaunchDelay; // 0x778 (Size: 0x28, Type: StructProperty)
    float ServerWorldCreationTime; // 0x7a0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_7a4[0xc]; // 0x7a4 (Size: 0xc, Type: PaddingProperty)

public:
    virtual void BP_OnBikeKidDismissed(const FGameplayTag DismissalReason); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void BP_OnBikeKidLaunched(); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnDestructionStarted(); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    UFortBikeKidMovementComponent* GetBikeKidMovementComponent() const; // 0x112669a0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AFortPawn* GetControllingPlayerPawn() const; // 0x11266a18 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FRotator GetDeltaRotator() const; // 0x11266a30 (Index: 0x6, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    void GetForwardAndRightDotProducts_Native(float& OutForwardDot, float& OutRightDot); // 0x11266a80 (Index: 0x7, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    float GetHealthPercentage() const; // 0x11266bfc (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetLaunchDelayRemaining() const; // 0x11266c1c (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsInLaunchDelay() const; // 0x11266c44 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void OnRotationInputReceived(const FRotator RotationInput); // 0x288a61c (Index: 0x10, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintEvent)

private:
    void OnRep_bExploded(); // 0x11267260 (Index: 0xe, Flags: Final|Native|Private)
    void OnRep_ControllingPlayerPawn(AFortPawn*& OldPawn); // 0x11267018 (Index: 0xf, Flags: Final|Native|Private)

protected:
    void GameplayCue_Damage(TEnumAsByte<EGameplayCueEvent>& EventType, FGameplayCueParameters& Parameters); // 0x112667c0 (Index: 0x3, Flags: Native|Protected)
    void OnCapsuleComponentHit(UPrimitiveComponent*& HitComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, FVector& NormalImpulse, const FHitResult Hit); // 0xe7e08a0 (Index: 0xb, Flags: Final|Native|Protected|HasOutParms|HasDefaults)
    virtual void OnDamagePlayEffects(float& Damage, const FGameplayTagContainer DamageTags, FVector& Momentum, const FHitResult HitInfo, AFortPawn*& InstigatedBy, AActor*& DamageCauser, FGameplayEffectContextHandle& EffectContext); // 0x288a61c (Index: 0xc, Flags: BlueprintCosmetic|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent)
    virtual void OnDeathPlayEffects(float& Damage, const FGameplayTagContainer DamageTags, FVector& Momentum, const FHitResult HitInfo, AFortPawn*& InstigatedBy, AActor*& DamageCauser, FGameplayEffectContextHandle& EffectContext); // 0x288a61c (Index: 0xd, Flags: BlueprintCosmetic|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent)
    void SetAffiliationAudio(); // 0x11268410 (Index: 0x11, Flags: Final|Native|Protected|BlueprintCallable)
    void SetTeamMatesIndicator(bool& bState); // 0x11268710 (Index: 0x12, Flags: Final|Native|Protected|BlueprintCallable)
    void SetupGameplayAudioParameters(); // 0x1126883c (Index: 0x13, Flags: Final|BlueprintCosmetic|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(AFortBikeKid) == 0x7b0, "Size mismatch for AFortBikeKid");
static_assert(offsetof(AFortBikeKid, NSBikeKidIdle_Native) == 0x680, "Offset mismatch for AFortBikeKid::NSBikeKidIdle_Native");
static_assert(offsetof(AFortBikeKid, TeamMateIndicatorMarkerWidgetClass) == 0x688, "Offset mismatch for AFortBikeKid::TeamMateIndicatorMarkerWidgetClass");
static_assert(offsetof(AFortBikeKid, BikeKidMotorLoopComponent) == 0x690, "Offset mismatch for AFortBikeKid::BikeKidMotorLoopComponent");
static_assert(offsetof(AFortBikeKid, BikeKidThrustSoundComponent) == 0x698, "Offset mismatch for AFortBikeKid::BikeKidThrustSoundComponent");
static_assert(offsetof(AFortBikeKid, DefaultTags) == 0x6a0, "Offset mismatch for AFortBikeKid::DefaultTags");
static_assert(offsetof(AFortBikeKid, ExplosionCueTag) == 0x6c0, "Offset mismatch for AFortBikeKid::ExplosionCueTag");
static_assert(offsetof(AFortBikeKid, bExploded) == 0x6c4, "Offset mismatch for AFortBikeKid::bExploded");
static_assert(offsetof(AFortBikeKid, AbilitySystemComponent) == 0x6d0, "Offset mismatch for AFortBikeKid::AbilitySystemComponent");
static_assert(offsetof(AFortBikeKid, AffiliationComponent) == 0x6d8, "Offset mismatch for AFortBikeKid::AffiliationComponent");
static_assert(offsetof(AFortBikeKid, StartupAbilitySet) == 0x6e0, "Offset mismatch for AFortBikeKid::StartupAbilitySet");
static_assert(offsetof(AFortBikeKid, ControllingPlayerPawn) == 0x6e8, "Offset mismatch for AFortBikeKid::ControllingPlayerPawn");
static_assert(offsetof(AFortBikeKid, HealthSet) == 0x6f0, "Offset mismatch for AFortBikeKid::HealthSet");
static_assert(offsetof(AFortBikeKid, EnergySet) == 0x6f8, "Offset mismatch for AFortBikeKid::EnergySet");
static_assert(offsetof(AFortBikeKid, AttributeInitKey) == 0x700, "Offset mismatch for AFortBikeKid::AttributeInitKey");
static_assert(offsetof(AFortBikeKid, PrimarySurfaceType) == 0x708, "Offset mismatch for AFortBikeKid::PrimarySurfaceType");
static_assert(offsetof(AFortBikeKid, WeaponResponseType) == 0x709, "Offset mismatch for AFortBikeKid::WeaponResponseType");
static_assert(offsetof(AFortBikeKid, bPlayedDeath) == 0x70a, "Offset mismatch for AFortBikeKid::bPlayedDeath");
static_assert(offsetof(AFortBikeKid, OutOfHealthDismissDelayData) == 0x70c, "Offset mismatch for AFortBikeKid::OutOfHealthDismissDelayData");
static_assert(offsetof(AFortBikeKid, ExplodeEffectContainerSpecs) == 0x720, "Offset mismatch for AFortBikeKid::ExplodeEffectContainerSpecs");
static_assert(offsetof(AFortBikeKid, OnTeamIndexChanged) == 0x730, "Offset mismatch for AFortBikeKid::OnTeamIndexChanged");
static_assert(offsetof(AFortBikeKid, PawnOverrideComponentClass) == 0x740, "Offset mismatch for AFortBikeKid::PawnOverrideComponentClass");
static_assert(offsetof(AFortBikeKid, BikeKidMotorLoopSound) == 0x748, "Offset mismatch for AFortBikeKid::BikeKidMotorLoopSound");
static_assert(offsetof(AFortBikeKid, BikeKidThrusterSound) == 0x750, "Offset mismatch for AFortBikeKid::BikeKidThrusterSound");
static_assert(offsetof(AFortBikeKid, AudioParameter) == 0x758, "Offset mismatch for AFortBikeKid::AudioParameter");
static_assert(offsetof(AFortBikeKid, LocallyViewedPawnAudioParamName) == 0x760, "Offset mismatch for AFortBikeKid::LocallyViewedPawnAudioParamName");
static_assert(offsetof(AFortBikeKid, IsEnemyAudioParamName) == 0x764, "Offset mismatch for AFortBikeKid::IsEnemyAudioParamName");
static_assert(offsetof(AFortBikeKid, ThrustAmountAudioParamName) == 0x768, "Offset mismatch for AFortBikeKid::ThrustAmountAudioParamName");
static_assert(offsetof(AFortBikeKid, ThrustSoundThreshold) == 0x76c, "Offset mismatch for AFortBikeKid::ThrustSoundThreshold");
static_assert(offsetof(AFortBikeKid, LaunchDelay) == 0x778, "Offset mismatch for AFortBikeKid::LaunchDelay");
static_assert(offsetof(AFortBikeKid, ServerWorldCreationTime) == 0x7a0, "Offset mismatch for AFortBikeKid::ServerWorldCreationTime");

// Size: 0x1f8 (Inherited: 0x278, Single: 0xffffff80)
class UFortBikeKidCameraMode : public UFort3PCameraMode
{
public:
    bool bShouldInterpolateLocation; // 0x1f0 (Size: 0x1, Type: BoolProperty)
    bool bShouldInterpolateRotation; // 0x1f1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f2[0x6]; // 0x1f2 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFortBikeKidCameraMode) == 0x1f8, "Size mismatch for UFortBikeKidCameraMode");
static_assert(offsetof(UFortBikeKidCameraMode, bShouldInterpolateLocation) == 0x1f0, "Offset mismatch for UFortBikeKidCameraMode::bShouldInterpolateLocation");
static_assert(offsetof(UFortBikeKidCameraMode, bShouldInterpolateRotation) == 0x1f1, "Offset mismatch for UFortBikeKidCameraMode::bShouldInterpolateRotation");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UBikeKidDeferredDestructionPayload : public UObject
{
public:
    FBikeKidDismissalData DeferredDestructionData; // 0x28 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UBikeKidDeferredDestructionPayload) == 0x38, "Size mismatch for UBikeKidDeferredDestructionPayload");
static_assert(offsetof(UBikeKidDeferredDestructionPayload, DeferredDestructionData) == 0x28, "Offset mismatch for UBikeKidDeferredDestructionPayload::DeferredDestructionData");

// Size: 0x458 (Inherited: 0x310, Single: 0x148)
class UFortBikeKidControllingComponent : public UFortControllerComponent
{
public:
    FRotator CachedControllerRotator; // 0xc0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_d8[0x30]; // 0xd8 (Size: 0x30, Type: PaddingProperty)
    UInputComponent* BikeKidInputComponent; // 0x108 (Size: 0x8, Type: ObjectProperty)
    AFortBikeKid* ControlledBikeKid; // 0x110 (Size: 0x8, Type: ObjectProperty)
    AFortBikeKid* LastControlledBikeKid; // 0x118 (Size: 0x8, Type: ObjectProperty)
    AActor* OriginalBikeKidOwner; // 0x120 (Size: 0x8, Type: ObjectProperty)
    UFortInputMappingContext* BikeKidInputContext; // 0x128 (Size: 0x8, Type: ObjectProperty)
    TArray<FBikeKidInputTriggerableEvent> InputTriggerableEvents; // 0x130 (Size: 0x10, Type: ArrayProperty)
    UInputAction* DismissAction; // 0x140 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_148[0x8]; // 0x148 (Size: 0x8, Type: PaddingProperty)
    FStenciledActorData OwningActorStencilData; // 0x150 (Size: 0x80, Type: StructProperty)
    FBikeKidDismissalData CurrentDismissalData; // 0x1d0 (Size: 0x10, Type: StructProperty)
    UClass* FirstPersonCameraModeOverride; // 0x1e0 (Size: 0x8, Type: ClassProperty)
    UClass* ThirdPersonCameraModeOverride; // 0x1e8 (Size: 0x8, Type: ClassProperty)
    FGameplayAbilitySpec FakeCameraAbilitySpec; // 0x1f0 (Size: 0xf0, Type: StructProperty)
    TArray<FName> LegacyInputActionsToBlock; // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    UClass* BlockActionsGameplayEffect; // 0x2f0 (Size: 0x8, Type: ClassProperty)
    UBikeKidDeferredDestructionPayload* DismissPayloadCache; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat DismissButtonPressCooldown; // 0x300 (Size: 0x28, Type: StructProperty)
    float InitialDismissInputCooldown; // 0x328 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_32c[0xc]; // 0x32c (Size: 0xc, Type: PaddingProperty)
    FViewTargetTransitionParams PlayerToBikeKidTransitionParams; // 0x338 (Size: 0x10, Type: StructProperty)
    FViewTargetTransitionParams BikeKidToPlayerTransitionParams; // 0x348 (Size: 0x10, Type: StructProperty)
    FGameplayTagContainer InterruptingPlayerTags; // 0x358 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_378[0x10]; // 0x378 (Size: 0x10, Type: PaddingProperty)
    FScalableFloat MaxTurnRate; // 0x388 (Size: 0x28, Type: StructProperty)
    FScalableFloat MouseTurnRate; // 0x3b0 (Size: 0x28, Type: StructProperty)
    FScalableFloat GamepadTurnRate; // 0x3d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TouchLookAccelerationMultiplier; // 0x400 (Size: 0x28, Type: StructProperty)
    FScalableFloat GyroTurnRate; // 0x428 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_450[0x8]; // 0x450 (Size: 0x8, Type: PaddingProperty)

public:
    AFortBikeKid* GetControlledBikeKid() const; // 0x112669c4 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    void ClampRotationInput(FRotator& InOutRotationInput); // 0x112666e0 (Index: 0x4, Flags: Final|Native|Private|HasOutParms|HasDefaults)
    virtual void NotifyClientBikeKidDestruction(FGameplayTag& const DestructionReason); // 0x11266c68 (Index: 0x6, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    virtual void NotifyClientStopControlling(); // 0xceafb60 (Index: 0x7, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    void OnControlledBikeClientDismiss(); // 0x11266e58 (Index: 0x8, Flags: Final|Native|Private)
    void OnLaunched(); // 0x11266e6c (Index: 0x9, Flags: Final|Native|Private)
    void OnOwningPlayerStartedDBNO(); // 0x11266e80 (Index: 0xa, Flags: Final|Native|Private)
    void OnPlayerInterruptionTagsChanged(FGameplayTag& const Tag, int32_t& NewCount); // 0x11266e94 (Index: 0xb, Flags: Final|Native|Private)
    void OnRep_ControlledBikeKid(); // 0x11266fdc (Index: 0xc, Flags: Final|Native|Private)
    void OnWeaponEquipped(AFortWeapon*& NewWeapon, AFortWeapon*& PrevWeapon); // 0x11267574 (Index: 0xd, Flags: Final|Native|Private)
    void PlayerInputMassageAxis(float& InOutNewVal, UFortPlayerInput*& const PlayerInput, const FKey Key, float& const DeltaTime); // 0x1126777c (Index: 0xe, Flags: Final|Native|Private|HasOutParms)
    void PlayerInputMassageVectorAxis(FVector& InOutNewVal, UFortPlayerInput*& const PlayerInput, const FKey Key, float& const DeltaTime); // 0x11267a24 (Index: 0xf, Flags: Final|Native|Private|HasOutParms|HasDefaults)
    void PlayerInputOverrideGamepadLookRates(FRotator& InOutLookRatesBase, FRotator& InOutLookRatesFinal, UFortPlayerInput*& const PlayerInput, float& const DeltaTime); // 0x11267cc8 (Index: 0x10, Flags: Final|Native|Private|HasOutParms|HasDefaults)
    void PlayerInputOverrideTouchLookAccelerationMultiplier(float& InOutMultiplier, UFortPlayerInput*& const PlayerInput); // 0x11267f64 (Index: 0x11, Flags: Final|Native|Private|HasOutParms)
    void PlayerInputProcessTouch(float& InOutLookYawDelta, float& InOutLookPitchDelta, UFortPlayerInput*& const PlayerInput, const FVector2D TouchLookInput, float& const DeltaTime); // 0x112680d4 (Index: 0x12, Flags: Final|Native|Private|HasOutParms|HasDefaults)
    virtual void ServerRequestBikeKidDismissal(); // 0xcc5a53c (Index: 0x13, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)

protected:
    virtual void BP_OnBikeKidDestroyed(const FGameplayTag DismissalReason); // 0x288a61c (Index: 0x0, Flags: BlueprintCosmetic|Event|Protected|HasOutParms|BlueprintEvent)
    virtual void BP_OnDestructionStarted(bool& bInstantDestruction, FGameplayTag& const DismissalReason); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Protected|BlueprintEvent)
    virtual void BP_OnDismissal(FGameplayTag& const DismissalReason); // 0x288a61c (Index: 0x2, Flags: BlueprintCosmetic|Event|Protected|BlueprintEvent)
    virtual void BP_StartedControlling(AFortBikeKid*& InBikeKid); // 0x288a61c (Index: 0x3, Flags: BlueprintCosmetic|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortBikeKidControllingComponent) == 0x458, "Size mismatch for UFortBikeKidControllingComponent");
static_assert(offsetof(UFortBikeKidControllingComponent, CachedControllerRotator) == 0xc0, "Offset mismatch for UFortBikeKidControllingComponent::CachedControllerRotator");
static_assert(offsetof(UFortBikeKidControllingComponent, BikeKidInputComponent) == 0x108, "Offset mismatch for UFortBikeKidControllingComponent::BikeKidInputComponent");
static_assert(offsetof(UFortBikeKidControllingComponent, ControlledBikeKid) == 0x110, "Offset mismatch for UFortBikeKidControllingComponent::ControlledBikeKid");
static_assert(offsetof(UFortBikeKidControllingComponent, LastControlledBikeKid) == 0x118, "Offset mismatch for UFortBikeKidControllingComponent::LastControlledBikeKid");
static_assert(offsetof(UFortBikeKidControllingComponent, OriginalBikeKidOwner) == 0x120, "Offset mismatch for UFortBikeKidControllingComponent::OriginalBikeKidOwner");
static_assert(offsetof(UFortBikeKidControllingComponent, BikeKidInputContext) == 0x128, "Offset mismatch for UFortBikeKidControllingComponent::BikeKidInputContext");
static_assert(offsetof(UFortBikeKidControllingComponent, InputTriggerableEvents) == 0x130, "Offset mismatch for UFortBikeKidControllingComponent::InputTriggerableEvents");
static_assert(offsetof(UFortBikeKidControllingComponent, DismissAction) == 0x140, "Offset mismatch for UFortBikeKidControllingComponent::DismissAction");
static_assert(offsetof(UFortBikeKidControllingComponent, OwningActorStencilData) == 0x150, "Offset mismatch for UFortBikeKidControllingComponent::OwningActorStencilData");
static_assert(offsetof(UFortBikeKidControllingComponent, CurrentDismissalData) == 0x1d0, "Offset mismatch for UFortBikeKidControllingComponent::CurrentDismissalData");
static_assert(offsetof(UFortBikeKidControllingComponent, FirstPersonCameraModeOverride) == 0x1e0, "Offset mismatch for UFortBikeKidControllingComponent::FirstPersonCameraModeOverride");
static_assert(offsetof(UFortBikeKidControllingComponent, ThirdPersonCameraModeOverride) == 0x1e8, "Offset mismatch for UFortBikeKidControllingComponent::ThirdPersonCameraModeOverride");
static_assert(offsetof(UFortBikeKidControllingComponent, FakeCameraAbilitySpec) == 0x1f0, "Offset mismatch for UFortBikeKidControllingComponent::FakeCameraAbilitySpec");
static_assert(offsetof(UFortBikeKidControllingComponent, LegacyInputActionsToBlock) == 0x2e0, "Offset mismatch for UFortBikeKidControllingComponent::LegacyInputActionsToBlock");
static_assert(offsetof(UFortBikeKidControllingComponent, BlockActionsGameplayEffect) == 0x2f0, "Offset mismatch for UFortBikeKidControllingComponent::BlockActionsGameplayEffect");
static_assert(offsetof(UFortBikeKidControllingComponent, DismissPayloadCache) == 0x2f8, "Offset mismatch for UFortBikeKidControllingComponent::DismissPayloadCache");
static_assert(offsetof(UFortBikeKidControllingComponent, DismissButtonPressCooldown) == 0x300, "Offset mismatch for UFortBikeKidControllingComponent::DismissButtonPressCooldown");
static_assert(offsetof(UFortBikeKidControllingComponent, InitialDismissInputCooldown) == 0x328, "Offset mismatch for UFortBikeKidControllingComponent::InitialDismissInputCooldown");
static_assert(offsetof(UFortBikeKidControllingComponent, PlayerToBikeKidTransitionParams) == 0x338, "Offset mismatch for UFortBikeKidControllingComponent::PlayerToBikeKidTransitionParams");
static_assert(offsetof(UFortBikeKidControllingComponent, BikeKidToPlayerTransitionParams) == 0x348, "Offset mismatch for UFortBikeKidControllingComponent::BikeKidToPlayerTransitionParams");
static_assert(offsetof(UFortBikeKidControllingComponent, InterruptingPlayerTags) == 0x358, "Offset mismatch for UFortBikeKidControllingComponent::InterruptingPlayerTags");
static_assert(offsetof(UFortBikeKidControllingComponent, MaxTurnRate) == 0x388, "Offset mismatch for UFortBikeKidControllingComponent::MaxTurnRate");
static_assert(offsetof(UFortBikeKidControllingComponent, MouseTurnRate) == 0x3b0, "Offset mismatch for UFortBikeKidControllingComponent::MouseTurnRate");
static_assert(offsetof(UFortBikeKidControllingComponent, GamepadTurnRate) == 0x3d8, "Offset mismatch for UFortBikeKidControllingComponent::GamepadTurnRate");
static_assert(offsetof(UFortBikeKidControllingComponent, TouchLookAccelerationMultiplier) == 0x400, "Offset mismatch for UFortBikeKidControllingComponent::TouchLookAccelerationMultiplier");
static_assert(offsetof(UFortBikeKidControllingComponent, GyroTurnRate) == 0x428, "Offset mismatch for UFortBikeKidControllingComponent::GyroTurnRate");

// Size: 0x1020 (Inherited: 0x14a8, Single: 0xfffffb78)
class UFortBikeKidMovementComponent : public UCharacterMovementComponent
{
public:
    FScalableFloat PreLaunchSpeed; // 0xfa8 (Size: 0x28, Type: StructProperty)
    FScalableFloat PostLaunchSpeed; // 0xfd0 (Size: 0x28, Type: StructProperty)
    UBoxComponent* HitBoxComponent; // 0xff8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1000[0x20]; // 0x1000 (Size: 0x20, Type: PaddingProperty)

public:
    void SetHitBoxComponent(UBoxComponent*& HitBox); // 0x11268424 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortBikeKidMovementComponent) == 0x1020, "Size mismatch for UFortBikeKidMovementComponent");
static_assert(offsetof(UFortBikeKidMovementComponent, PreLaunchSpeed) == 0xfa8, "Offset mismatch for UFortBikeKidMovementComponent::PreLaunchSpeed");
static_assert(offsetof(UFortBikeKidMovementComponent, PostLaunchSpeed) == 0xfd0, "Offset mismatch for UFortBikeKidMovementComponent::PostLaunchSpeed");
static_assert(offsetof(UFortBikeKidMovementComponent, HitBoxComponent) == 0xff8, "Offset mismatch for UFortBikeKidMovementComponent::HitBoxComponent");

// Size: 0xc8 (Inherited: 0x3d0, Single: 0xfffffcf8)
class UFortBikeKidPawnOverrideComponent : public UFortPawnOverrideComponent
{
public:
    UClass* BikeKidSpectateCameraMode; // 0xc0 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortBikeKidPawnOverrideComponent) == 0xc8, "Size mismatch for UFortBikeKidPawnOverrideComponent");
static_assert(offsetof(UFortBikeKidPawnOverrideComponent, BikeKidSpectateCameraMode) == 0xc0, "Offset mismatch for UFortBikeKidPawnOverrideComponent::BikeKidSpectateCameraMode");

// Size: 0xc8 (Inherited: 0x3d0, Single: 0xfffffcf8)
class UFortBikeKidPawnOwnerOverrideComponent : public UFortPawnOverrideComponent
{
public:
    TWeakObjectPtr<AFortBikeKid*> ControlledBikeKid; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UFortBikeKidPawnOwnerOverrideComponent) == 0xc8, "Size mismatch for UFortBikeKidPawnOwnerOverrideComponent");
static_assert(offsetof(UFortBikeKidPawnOwnerOverrideComponent, ControlledBikeKid) == 0xc0, "Offset mismatch for UFortBikeKidPawnOwnerOverrideComponent::ControlledBikeKid");

// Size: 0x108 (Inherited: 0xd0, Single: 0x38)
class UFortChargingSet_BikeKidEnergy : public UFortChargingSet_Base
{
public:
    FFortGameplayAttributeData Energy; // 0x48 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData MaxEnergy; // 0x70 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData EnergyChargeRate; // 0x98 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData ServerTimeEnergyIncrements; // 0xc0 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_e8[0x20]; // 0xe8 (Size: 0x20, Type: PaddingProperty)

protected:
    void OnRep_Energy(const FFortGameplayAttributeData OldValue); // 0x11267158 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UFortChargingSet_BikeKidEnergy) == 0x108, "Size mismatch for UFortChargingSet_BikeKidEnergy");
static_assert(offsetof(UFortChargingSet_BikeKidEnergy, Energy) == 0x48, "Offset mismatch for UFortChargingSet_BikeKidEnergy::Energy");
static_assert(offsetof(UFortChargingSet_BikeKidEnergy, MaxEnergy) == 0x70, "Offset mismatch for UFortChargingSet_BikeKidEnergy::MaxEnergy");
static_assert(offsetof(UFortChargingSet_BikeKidEnergy, EnergyChargeRate) == 0x98, "Offset mismatch for UFortChargingSet_BikeKidEnergy::EnergyChargeRate");
static_assert(offsetof(UFortChargingSet_BikeKidEnergy, ServerTimeEnergyIncrements) == 0xc0, "Offset mismatch for UFortChargingSet_BikeKidEnergy::ServerTimeEnergyIncrements");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBikeKidDismissalData
{
    float DeposessDelay; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bInstantDestruction; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FGameplayTag DismissalReason; // 0x8 (Size: 0x4, Type: StructProperty)
    float ServerDismissStartTime; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBikeKidDismissalData) == 0x10, "Size mismatch for FBikeKidDismissalData");
static_assert(offsetof(FBikeKidDismissalData, DeposessDelay) == 0x0, "Offset mismatch for FBikeKidDismissalData::DeposessDelay");
static_assert(offsetof(FBikeKidDismissalData, bInstantDestruction) == 0x4, "Offset mismatch for FBikeKidDismissalData::bInstantDestruction");
static_assert(offsetof(FBikeKidDismissalData, DismissalReason) == 0x8, "Offset mismatch for FBikeKidDismissalData::DismissalReason");
static_assert(offsetof(FBikeKidDismissalData, ServerDismissStartTime) == 0xc, "Offset mismatch for FBikeKidDismissalData::ServerDismissStartTime");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FOnFortBikeKidDeployed
{
    TWeakObjectPtr<AFortBikeKid*> DeployedBikeKid; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FOnFortBikeKidDeployed) == 0x8, "Size mismatch for FOnFortBikeKidDeployed");
static_assert(offsetof(FOnFortBikeKidDeployed, DeployedBikeKid) == 0x0, "Offset mismatch for FOnFortBikeKidDeployed::DeployedBikeKid");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FOnFortBikeKidDismissed
{
    FGameplayTag DismissalReason; // 0x0 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FOnFortBikeKidDismissed) == 0x4, "Size mismatch for FOnFortBikeKidDismissed");
static_assert(offsetof(FOnFortBikeKidDismissed, DismissalReason) == 0x0, "Offset mismatch for FOnFortBikeKidDismissed::DismissalReason");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FOnFortBikeKidMarkedEnemies
{
    FGameplayTag Source; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<AActor*> MarkedActors; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FOnFortBikeKidMarkedEnemies) == 0x18, "Size mismatch for FOnFortBikeKidMarkedEnemies");
static_assert(offsetof(FOnFortBikeKidMarkedEnemies, Source) == 0x0, "Offset mismatch for FOnFortBikeKidMarkedEnemies::Source");
static_assert(offsetof(FOnFortBikeKidMarkedEnemies, MarkedActors) == 0x8, "Offset mismatch for FOnFortBikeKidMarkedEnemies::MarkedActors");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FBikeKidStatusData
{
    uint8_t Status; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float ServerTimeStatusChanged; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBikeKidStatusData) == 0x8, "Size mismatch for FBikeKidStatusData");
static_assert(offsetof(FBikeKidStatusData, Status) == 0x0, "Offset mismatch for FBikeKidStatusData::Status");
static_assert(offsetof(FBikeKidStatusData, ServerTimeStatusChanged) == 0x4, "Offset mismatch for FBikeKidStatusData::ServerTimeStatusChanged");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FBikeKidInputTriggerableEvent
{
    FName InputActionName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UInputAction* InputAction; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GameplayEventToTrigger; // 0x10 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FBikeKidInputTriggerableEvent) == 0x18, "Size mismatch for FBikeKidInputTriggerableEvent");
static_assert(offsetof(FBikeKidInputTriggerableEvent, InputActionName) == 0x0, "Offset mismatch for FBikeKidInputTriggerableEvent::InputActionName");
static_assert(offsetof(FBikeKidInputTriggerableEvent, InputAction) == 0x8, "Offset mismatch for FBikeKidInputTriggerableEvent::InputAction");
static_assert(offsetof(FBikeKidInputTriggerableEvent, GameplayEventToTrigger) == 0x10, "Offset mismatch for FBikeKidInputTriggerableEvent::GameplayEventToTrigger");

