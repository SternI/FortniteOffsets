/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Components
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "VehicleCosmeticsRuntime.h"
#include "FortniteGame.h"
#include "EventModeRuntime.h"
#include "CoreUObject.h"
#include "RidingCodeRuntime.h"
#include "ModularGameplay.h"
#include "Player.h"
#include "FMJamSystemRuntime.h"
#include "FMJamInLobbyRuntime.h"
#include "FMJamPlayspaceRuntime.h"
#include "PlayspaceSystem.h"
#include "DynamicUI.h"
#include "GameplayTags.h"
#include "SparksCharacterCommonRuntime.h"
#include "Data.h"
#include "GameplayEventRouter.h"
#include "SlateCore.h"
#include "SparksMusicPlayspaceRuntime.h"
#include "Athena.h"
#include "GameplayAbilities.h"
#include "SoundLibrary.h"
#include "Playspace.h"
#include "FortniteUI.h"
#include "EnhancedInput.h"
#include "SparksCoreUI.h"
#include "InputPromptManagerRuntime.h"
#include "Niagara.h"

// Size: 0x248 (Inherited: 0xe0, Single: 0x168)
class UIntercomManager_C : public UActorComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb8 (Size: 0x8, Type: StructProperty)
    UGameplayEventRouterComponent* Event_Router; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TMap<FGameplayEvent_IntercomBroadcastRequest, FGameplayTag> Active_Channel_Broadcasts; // 0xc8 (Size: 0x50, Type: MapProperty)
    TMap<UAudioComponent*, FGameplayTag> Channel_Audio_Components; // 0x118 (Size: 0x50, Type: MapProperty)
    TMap<FIntercomChannelQueue, FGameplayTag> Channel_Broadcast_Queues; // 0x168 (Size: 0x50, Type: MapProperty)
    TMap<FIntercomChannelListeners, FGameplayTag> Channel_Listeners; // 0x1b8 (Size: 0x50, Type: MapProperty)
    uint8_t On_Broadcast_Started[0x10]; // 0x208 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t On_Broadcast_Ended[0x10]; // 0x218 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t On_Listener_Added[0x10]; // 0x228 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t On_Listener_Removed[0x10]; // 0x238 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void On_Broadcast_Ended__DelegateSignature(FGameplayTag& Channel_Tag); // 0x288a61c (Index: 0x1, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void On_Broadcast_Started__DelegateSignature(FGameplayTag& Channel_Tag, UAudioComponent*& Audio_Component); // 0x288a61c (Index: 0x2, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void Unregister_Source_Bus(FGameplayTag& Channel_Tag, USoundSourceBus*& Source_Bus); // 0x288a61c (Index: 0x4, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Remove_Listener_from_Channel(FGameplayTag& Channel_Tag, USoundSourceBus*& Source_Bus); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Request_Broadcast(FGameplayEvent_IntercomBroadcastRequest& Broadcast_Request_Data); // 0x288a61c (Index: 0x7, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Add_Listener_to_Channel(FGameplayTag& Channel_Tag, USoundSourceBus*& Source_Bus); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Register_Source_Bus(FGameplayTag& Channel_Tag, USoundSourceBus*& Source_Bus); // 0x288a61c (Index: 0xd, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0xe, Flags: Event|Public|BlueprintEvent)
    void On_Listener_Removed__DelegateSignature(FGameplayTag& Channel_Tag, USoundSourceBus*& Source_Bus); // 0x288a61c (Index: 0xf, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void On_Listener_Added__DelegateSignature(FGameplayTag& Channel_Tag, USoundSourceBus*& Source_Bus); // 0x288a61c (Index: 0x10, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)

private:
    void Check_for_Listeners(FGameplayTag& Channel_Tag, USoundSourceBus*& Source_Bus); // 0x288a61c (Index: 0x9, Flags: Private|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    void Stop_Broadcast(FGameplayEvent_IntercomStopBroadcast& Stop_Broadcast_Event_Data); // 0x288a61c (Index: 0x3, Flags: Protected|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Start_Broadcast(FGameplayTag& Channel_Tag); // 0x288a61c (Index: 0x5, Flags: Protected|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Interrupt_Broadcast(FGameplayTag& Channel_Tag, FGameplayEvent_IntercomBroadcastRequest& New_Broadcast_Request); // 0x288a61c (Index: 0x8, Flags: Protected|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Queue_Broadcast(FGameplayTag& Channel_Tag, FGameplayEvent_IntercomBroadcastRequest& Broadcast_Request); // 0x288a61c (Index: 0xb, Flags: Protected|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UIntercomManager_C) == 0x248, "Size mismatch for UIntercomManager_C");
static_assert(offsetof(UIntercomManager_C, UberGraphFrame) == 0xb8, "Offset mismatch for UIntercomManager_C::UberGraphFrame");
static_assert(offsetof(UIntercomManager_C, Event_Router) == 0xc0, "Offset mismatch for UIntercomManager_C::Event_Router");
static_assert(offsetof(UIntercomManager_C, Active_Channel_Broadcasts) == 0xc8, "Offset mismatch for UIntercomManager_C::Active_Channel_Broadcasts");
static_assert(offsetof(UIntercomManager_C, Channel_Audio_Components) == 0x118, "Offset mismatch for UIntercomManager_C::Channel_Audio_Components");
static_assert(offsetof(UIntercomManager_C, Channel_Broadcast_Queues) == 0x168, "Offset mismatch for UIntercomManager_C::Channel_Broadcast_Queues");
static_assert(offsetof(UIntercomManager_C, Channel_Listeners) == 0x1b8, "Offset mismatch for UIntercomManager_C::Channel_Listeners");
static_assert(offsetof(UIntercomManager_C, On_Broadcast_Started) == 0x208, "Offset mismatch for UIntercomManager_C::On_Broadcast_Started");
static_assert(offsetof(UIntercomManager_C, On_Broadcast_Ended) == 0x218, "Offset mismatch for UIntercomManager_C::On_Broadcast_Ended");
static_assert(offsetof(UIntercomManager_C, On_Listener_Added) == 0x228, "Offset mismatch for UIntercomManager_C::On_Listener_Added");
static_assert(offsetof(UIntercomManager_C, On_Listener_Removed) == 0x238, "Offset mismatch for UIntercomManager_C::On_Listener_Removed");

// Size: 0x9b0 (Inherited: 0xb60, Single: 0xfffffe50)
class UBP_VehicleCosmeticsAMUC_C : public UVehicleCosmeticsAssembledMeshUserComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x970 (Size: 0x8, Type: StructProperty)
    AFortAthenaVehicle* VehiclePawn; // 0x978 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GC_LoopingApplication; // 0x980 (Size: 0x4, Type: StructProperty)
    FName BoostTestSocketName; // 0x984 (Size: 0x4, Type: NameProperty)
    AActor* BoostTestSpawnedActor; // 0x988 (Size: 0x8, Type: ObjectProperty)
    UClass* BoostTestActorClass; // 0x990 (Size: 0x8, Type: ClassProperty)
    AActor* TrailTestSpawnedActor; // 0x998 (Size: 0x8, Type: ObjectProperty)
    FName TrailTestSocketName; // 0x9a0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_9a4[0x4]; // 0x9a4 (Size: 0x4, Type: PaddingProperty)
    UClass* TrailTestActorClass; // 0x9a8 (Size: 0x8, Type: ClassProperty)

public:
    void SpawnActorForValidationTest(FName& SocketName, UClass*& ActorClass, AActor*& SpawnedActor); // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UBP_VehicleCosmeticsAMUC_C) == 0x9b0, "Size mismatch for UBP_VehicleCosmeticsAMUC_C");
static_assert(offsetof(UBP_VehicleCosmeticsAMUC_C, UberGraphFrame) == 0x970, "Offset mismatch for UBP_VehicleCosmeticsAMUC_C::UberGraphFrame");
static_assert(offsetof(UBP_VehicleCosmeticsAMUC_C, VehiclePawn) == 0x978, "Offset mismatch for UBP_VehicleCosmeticsAMUC_C::VehiclePawn");
static_assert(offsetof(UBP_VehicleCosmeticsAMUC_C, GC_LoopingApplication) == 0x980, "Offset mismatch for UBP_VehicleCosmeticsAMUC_C::GC_LoopingApplication");
static_assert(offsetof(UBP_VehicleCosmeticsAMUC_C, BoostTestSocketName) == 0x984, "Offset mismatch for UBP_VehicleCosmeticsAMUC_C::BoostTestSocketName");
static_assert(offsetof(UBP_VehicleCosmeticsAMUC_C, BoostTestSpawnedActor) == 0x988, "Offset mismatch for UBP_VehicleCosmeticsAMUC_C::BoostTestSpawnedActor");
static_assert(offsetof(UBP_VehicleCosmeticsAMUC_C, BoostTestActorClass) == 0x990, "Offset mismatch for UBP_VehicleCosmeticsAMUC_C::BoostTestActorClass");
static_assert(offsetof(UBP_VehicleCosmeticsAMUC_C, TrailTestSpawnedActor) == 0x998, "Offset mismatch for UBP_VehicleCosmeticsAMUC_C::TrailTestSpawnedActor");
static_assert(offsetof(UBP_VehicleCosmeticsAMUC_C, TrailTestSocketName) == 0x9a0, "Offset mismatch for UBP_VehicleCosmeticsAMUC_C::TrailTestSocketName");
static_assert(offsetof(UBP_VehicleCosmeticsAMUC_C, TrailTestActorClass) == 0x9a8, "Offset mismatch for UBP_VehicleCosmeticsAMUC_C::TrailTestActorClass");

// Size: 0xc8 (Inherited: 0x308, Single: 0xfffffdc0)
class UBP_JamVolumeComponent_C : public UFortPlayerStateComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb8 (Size: 0x8, Type: StructProperty)
    UGameplayEventRouterComponent* Event_Router; // 0xc0 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    void SetMuteJam(bool& Mute); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UBP_JamVolumeComponent_C) == 0xc8, "Size mismatch for UBP_JamVolumeComponent_C");
static_assert(offsetof(UBP_JamVolumeComponent_C, UberGraphFrame) == 0xb8, "Offset mismatch for UBP_JamVolumeComponent_C::UberGraphFrame");
static_assert(offsetof(UBP_JamVolumeComponent_C, Event_Router) == 0xc0, "Offset mismatch for UBP_JamVolumeComponent_C::Event_Router");

// Size: 0x228 (Inherited: 0x3c0, Single: 0xfffffe68)
class UEventMode_Activator_Component_C : public UFortGameFrameworkComponent_EventMode
{
public:
};

static_assert(sizeof(UEventMode_Activator_Component_C) == 0x228, "Size mismatch for UEventMode_Activator_Component_C");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FJamUISceneByTags
{
    FGameplayTagQuery PlaylistTags_2_12BFD2B24C209C9EE6A73EA9EFAADCEF; // 0x0 (Size: 0x48, Type: StructProperty)
    FString EnableCVar_12_9379D68148A8F57DF6F463B28F8D491A; // 0x48 (Size: 0x10, Type: StrProperty)
    TArray<UDynamicUIScene*> UIScenesToAdd_6_6A717A3F46A28CA9EA3C9E8C1909000C; // 0x58 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FJamUISceneByTags) == 0x68, "Size mismatch for FJamUISceneByTags");
static_assert(offsetof(FJamUISceneByTags, PlaylistTags_2_12BFD2B24C209C9EE6A73EA9EFAADCEF) == 0x0, "Offset mismatch for FJamUISceneByTags::PlaylistTags_2_12BFD2B24C209C9EE6A73EA9EFAADCEF");
static_assert(offsetof(FJamUISceneByTags, EnableCVar_12_9379D68148A8F57DF6F463B28F8D491A) == 0x48, "Offset mismatch for FJamUISceneByTags::EnableCVar_12_9379D68148A8F57DF6F463B28F8D491A");
static_assert(offsetof(FJamUISceneByTags, UIScenesToAdd_6_6A717A3F46A28CA9EA3C9E8C1909000C) == 0x58, "Offset mismatch for FJamUISceneByTags::UIScenesToAdd_6_6A717A3F46A28CA9EA3C9E8C1909000C");

// Size: 0xd2 (Inherited: 0xe0, Single: 0xfffffff2)
class UCreatureBaseNonRidableComponent_C : public UActorComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb8 (Size: 0x8, Type: StructProperty)
    double Jump_Attach_Ground_Height_Min; // 0xc0 (Size: 0x8, Type: DoubleProperty)
    double Jump_Attach_Ground_Height_Buffer; // 0xc8 (Size: 0x8, Type: DoubleProperty)
    bool Uses_Alt_Riding_Message; // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool KillOnRideAttempt; // 0xd1 (Size: 0x1, Type: BoolProperty)

public:
    void ToggleRidingAlternative(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetRidingInfoFromTarget(double& JumpAttachGroundHeightMin, double& JumpAttachGroundHeightBuffer, bool& UsesAltRidingMessage); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UCreatureBaseNonRidableComponent_C) == 0xd2, "Size mismatch for UCreatureBaseNonRidableComponent_C");
static_assert(offsetof(UCreatureBaseNonRidableComponent_C, UberGraphFrame) == 0xb8, "Offset mismatch for UCreatureBaseNonRidableComponent_C::UberGraphFrame");
static_assert(offsetof(UCreatureBaseNonRidableComponent_C, Jump_Attach_Ground_Height_Min) == 0xc0, "Offset mismatch for UCreatureBaseNonRidableComponent_C::Jump_Attach_Ground_Height_Min");
static_assert(offsetof(UCreatureBaseNonRidableComponent_C, Jump_Attach_Ground_Height_Buffer) == 0xc8, "Offset mismatch for UCreatureBaseNonRidableComponent_C::Jump_Attach_Ground_Height_Buffer");
static_assert(offsetof(UCreatureBaseNonRidableComponent_C, Uses_Alt_Riding_Message) == 0xd0, "Offset mismatch for UCreatureBaseNonRidableComponent_C::Uses_Alt_Riding_Message");
static_assert(offsetof(UCreatureBaseNonRidableComponent_C, KillOnRideAttempt) == 0xd1, "Offset mismatch for UCreatureBaseNonRidableComponent_C::KillOnRideAttempt");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class URidingGeneric_Interafce_C : public UInterface
{
public:

public:
    void ToggleRidingAlternative(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetRidingInfoFromTarget(double& JumpAttachGroundHeightMin, double& JumpAttachGroundHeightBuffer, bool& UsesAltRidingMessage); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(URidingGeneric_Interafce_C) == 0x28, "Size mismatch for URidingGeneric_Interafce_C");

// Size: 0xec1 (Inherited: 0xdd8, Single: 0xe9)
class UCreatureBaseRidableComponent_C : public UControllableRidableComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x808 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer T_CreatureIsBeingRidden; // 0x810 (Size: 0x20, Type: StructProperty)
    UClass* GE_CreatureIsBeingRidden; // 0x830 (Size: 0x8, Type: ClassProperty)
    UClass* GE_CreatureIsBeingRidden_Passive; // 0x838 (Size: 0x8, Type: ClassProperty)
    bool bDebugDisplay; // 0x840 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_841[0x7]; // 0x841 (Size: 0x7, Type: PaddingProperty)
    double DebugTickRate; // 0x848 (Size: 0x8, Type: DoubleProperty)
    FVector DebugServerRiderLocation; // 0x850 (Size: 0x18, Type: StructProperty)
    double CapsuleRadiusOffset; // 0x868 (Size: 0x8, Type: DoubleProperty)
    double CapsuleHalfHeightOffset; // 0x870 (Size: 0x8, Type: DoubleProperty)
    FGameplayTagContainer T_RidingSpecialAbility; // 0x878 (Size: 0x20, Type: StructProperty)
    UAnimSequence* IdleAnim_Add; // 0x898 (Size: 0x8, Type: ObjectProperty)
    UAnimSequence* RunAnim_Add; // 0x8a0 (Size: 0x8, Type: ObjectProperty)
    UBlendSpace* TurnBS; // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    double MinSpeedToRun; // 0x8b0 (Size: 0x8, Type: DoubleProperty)
    double Run_RampIntoSpeed; // 0x8b8 (Size: 0x8, Type: DoubleProperty)
    double Run_RampIntoSpeed_ADS; // 0x8c0 (Size: 0x8, Type: DoubleProperty)
    double Run_PlayRate; // 0x8c8 (Size: 0x8, Type: DoubleProperty)
    double Run_PlayRate_ADS; // 0x8d0 (Size: 0x8, Type: DoubleProperty)
    double SpringAlpha; // 0x8d8 (Size: 0x8, Type: DoubleProperty)
    double SpringAlpha_ADS; // 0x8e0 (Size: 0x8, Type: DoubleProperty)
    double Idle_Alpha; // 0x8e8 (Size: 0x8, Type: DoubleProperty)
    double Idle_Alpha_ADS; // 0x8f0 (Size: 0x8, Type: DoubleProperty)
    double Run_Alpha; // 0x8f8 (Size: 0x8, Type: DoubleProperty)
    double Run_Alpha_ADS; // 0x900 (Size: 0x8, Type: DoubleProperty)
    double Turn_Alpha; // 0x908 (Size: 0x8, Type: DoubleProperty)
    double Turn_Alpha_ADS; // 0x910 (Size: 0x8, Type: DoubleProperty)
    UAnimSequence* Clamp_AnimPose_LastResort; // 0x918 (Size: 0x8, Type: ObjectProperty)
    FRotator Clamp_Foot_R_Adjust; // 0x920 (Size: 0x18, Type: StructProperty)
    FRotator Clamp_Foot_L_Adjust; // 0x938 (Size: 0x18, Type: StructProperty)
    double CapsuleRadiusOffset_Emote; // 0x950 (Size: 0x8, Type: DoubleProperty)
    double CapsuleHalfHeightOffset_Emote; // 0x958 (Size: 0x8, Type: DoubleProperty)
    FVector Clamp_Location_Offset; // 0x960 (Size: 0x18, Type: StructProperty)
    FRotator Clamp_Rotation_Offset; // 0x978 (Size: 0x18, Type: StructProperty)
    FVector Clamp_ScaleAdjust; // 0x990 (Size: 0x18, Type: StructProperty)
    FName RidableSocketName; // 0x9a8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_9ac[0x4]; // 0x9ac (Size: 0x4, Type: PaddingProperty)
    double RidableSocket_Alpha; // 0x9b0 (Size: 0x8, Type: DoubleProperty)
    UClass* GE_CooldownOverride; // 0x9b8 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer T_CreatureOverrideCooldown; // 0x9c0 (Size: 0x20, Type: StructProperty)
    TMap<TEnumAsByte<ECollisionResponse>, TEnumAsByte<ECollisionChannel>> OriginalCollisionResponseMap; // 0x9e0 (Size: 0x50, Type: MapProperty)
    FSoundIndicatorIconPicker RidingSoundIndicatorIconOverride; // 0xa30 (Size: 0x28, Type: StructProperty)
    uint8_t AudioOnJump[0x10]; // 0xa58 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t AudioOnJumpApex[0x10]; // 0xa68 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    char MovementMode; // 0xa78 (Size: 0x1, Type: ByteProperty)
    bool bFalling; // 0xa79 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a7a[0x6]; // 0xa7a (Size: 0x6, Type: PaddingProperty)
    FScalableFloat RidingAbilityEnable_HF; // 0xa80 (Size: 0x28, Type: StructProperty)
    double JumpAttach_GroundHeightMin; // 0xaa8 (Size: 0x8, Type: DoubleProperty)
    double JumpAttach_GroundHeightBuffer; // 0xab0 (Size: 0x8, Type: DoubleProperty)
    bool UseAltRidingMessage; // 0xab8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ab9[0x7]; // 0xab9 (Size: 0x7, Type: PaddingProperty)
    FText Riding_Interaction_Text; // 0xac0 (Size: 0x10, Type: TextProperty)
    double currentEnergyValue; // 0xad0 (Size: 0x8, Type: DoubleProperty)
    UPlayerRiderComponent_C* PlayerRiderComponentRef; // 0xad8 (Size: 0x8, Type: ObjectProperty)
    ANPC_Pawn_Wildlife_Parent_C* NPCPawnWildlifeRef; // 0xae0 (Size: 0x8, Type: ObjectProperty)
    double previousTimeTracked; // 0xae8 (Size: 0x8, Type: DoubleProperty)
    double energyTrackingDeltaTime; // 0xaf0 (Size: 0x8, Type: DoubleProperty)
    bool OldEnergyFlowEnabled; // 0xaf8 (Size: 0x1, Type: BoolProperty)
    bool ShouldHaveEnergy; // 0xaf9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_afa[0x6]; // 0xafa (Size: 0x6, Type: PaddingProperty)
    double EnergyRateOfDecayStopped; // 0xb00 (Size: 0x8, Type: DoubleProperty)
    bool allowUpdateEnergyTrackingTick; // 0xb08 (Size: 0x1, Type: BoolProperty)
    bool lastBeingRiddenState; // 0xb09 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b0a[0x6]; // 0xb0a (Size: 0x6, Type: PaddingProperty)
    FCurveTableRowHandle EnergyRateOfDecayMoving; // 0xb10 (Size: 0x10, Type: StructProperty)
    FCurveTableRowHandle EnergyRateOfDecaySprinting; // 0xb20 (Size: 0x10, Type: StructProperty)
    double CurrentEnergyRateOfRecharge; // 0xb30 (Size: 0x8, Type: DoubleProperty)
    FCurveTableRowHandle ExhaustedEnergyRateOfRecharge; // 0xb38 (Size: 0x10, Type: StructProperty)
    double EnergyWarningThreshold; // 0xb48 (Size: 0x8, Type: DoubleProperty)
    double EnergyCriticalThreshold; // 0xb50 (Size: 0x8, Type: DoubleProperty)
    bool energyWarningActive; // 0xb58 (Size: 0x1, Type: BoolProperty)
    bool energyCriticalActive; // 0xb59 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b5a[0x6]; // 0xb5a (Size: 0x6, Type: PaddingProperty)
    double minMovementSpeedTreshold; // 0xb60 (Size: 0x8, Type: DoubleProperty)
    bool IsJumping; // 0xb68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b69[0x7]; // 0xb69 (Size: 0x7, Type: PaddingProperty)
    double EnergyRegenThreshold; // 0xb70 (Size: 0x8, Type: DoubleProperty)
    bool AlwaysRegenWhenNotRidden; // 0xb78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b79[0x7]; // 0xb79 (Size: 0x7, Type: PaddingProperty)
    UClass* GE_EnergyWarning; // 0xb80 (Size: 0x8, Type: ClassProperty)
    UClass* GE_EnergyCritical; // 0xb88 (Size: 0x8, Type: ClassProperty)
    UClass* GE_EnergyDepleted; // 0xb90 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer T_EnergyWarning; // 0xb98 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer T_EnergyCritical; // 0xbb8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer T_EnergyDepleted; // 0xbd8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer T_CannotRideBucket; // 0xbf8 (Size: 0x20, Type: StructProperty)
    UClass* Gameplay_Effect; // 0xc18 (Size: 0x8, Type: ClassProperty)
    FGameplayTag SprintingAbilityTag; // 0xc20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c24[0x4]; // 0xc24 (Size: 0x4, Type: PaddingProperty)
    UClass* GE_EatToRefuel; // 0xc28 (Size: 0x8, Type: ClassProperty)
    FSlateBrush IconBrush; // 0xc30 (Size: 0xb0, Type: StructProperty)
    UClass* GE_Creature_Sprint; // 0xce0 (Size: 0x8, Type: ClassProperty)
    USoundLibrary* RidingFoleySoundLibrary; // 0xce8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer TagsPreventSprinting; // 0xcf0 (Size: 0x20, Type: StructProperty)
    uint8_t RidableUIStart[0x10]; // 0xd10 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t RidableUIUpdateEnergy[0x10]; // 0xd20 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FGameplayTag OutOfEnergySoundLibTag; // 0xd30 (Size: 0x4, Type: StructProperty)
    FGameplayTag SprintStartSoundLibTag; // 0xd34 (Size: 0x4, Type: StructProperty)
    TEnumAsByte<TInteractionType> Riding_Interaction_Type; // 0xd38 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_d39[0x7]; // 0xd39 (Size: 0x7, Type: PaddingProperty)
    double StartInAirTimestamp; // 0xd40 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle RetryJumpExitTimerHandle; // 0xd48 (Size: 0x8, Type: StructProperty)
    double JumpExitBufferStartTimeStamp; // 0xd50 (Size: 0x8, Type: DoubleProperty)
    FScalableFloat JumpExitBufferTime; // 0xd58 (Size: 0x28, Type: StructProperty)
    FTimerHandle JumpExitBufferTimerHandle; // 0xd80 (Size: 0x8, Type: StructProperty)
    FGameplayTag MountLandedCueTag; // 0xd88 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_d8c[0x4]; // 0xd8c (Size: 0x4, Type: PaddingProperty)
    UClass* GE_BlockCreatureAttackOnDismount; // 0xd90 (Size: 0x8, Type: ClassProperty)
    bool EnergyRegenActive; // 0xd98 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d99[0x7]; // 0xd99 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagContainer BlockPetting_TagContainer; // 0xda0 (Size: 0x20, Type: StructProperty)
    bool infiniteStaminaBuffEnabled; // 0xdc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_dc1[0x3]; // 0xdc1 (Size: 0x3, Type: PaddingProperty)
    FGameplayTag InfiniteStaminaEffect_GameplayCueTag; // 0xdc4 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer Cannot_Ride_Rider_Bucket; // 0xdc8 (Size: 0x20, Type: StructProperty)
    FScalableFloat JumpFatigue_Enabled; // 0xde8 (Size: 0x28, Type: StructProperty)
    FScalableFloat JumpFatigue_ApplyFatigueMinJumpCount; // 0xe10 (Size: 0x28, Type: StructProperty)
    UClass* JumpFatigueGameplayEffect; // 0xe38 (Size: 0x8, Type: ClassProperty)
    bool JumpFatigueDebugEnabled; // 0xe40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e41[0x3]; // 0xe41 (Size: 0x3, Type: PaddingProperty)
    int32_t JumpFatigueJumpCount; // 0xe44 (Size: 0x4, Type: IntProperty)
    double JumpFatigue_LastLandingTimeStamp; // 0xe48 (Size: 0x8, Type: DoubleProperty)
    FScalableFloat JumpFatigue_ResetCounterDelay; // 0xe50 (Size: 0x28, Type: StructProperty)
    bool JumpFatigue_ShouldTimeStampNextLanding; // 0xe78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e79[0x3]; // 0xe79 (Size: 0x3, Type: PaddingProperty)
    FActiveGameplayEffectHandle JumpFatigue_GEHandle; // 0xe7c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_e84[0x4]; // 0xe84 (Size: 0x4, Type: PaddingProperty)
    FTimerHandle JumpFatigue_RemovalTimerHandle; // 0xe88 (Size: 0x8, Type: StructProperty)
    FScalableFloat JumpFatigue_GeDurationPostLanding; // 0xe90 (Size: 0x28, Type: StructProperty)
    UClass* GE_NotPetable_IsBeingRidden; // 0xeb8 (Size: 0x8, Type: ClassProperty)
    bool bAllowRidingInteraction; // 0xec0 (Size: 0x1, Type: BoolProperty)

public:
    virtual void CheatSetStaminaPercent(float& const StaminaPercent); // 0x288a61c (Index: 0x2, Flags: BlueprintAuthorityOnly|Event|Public|BlueprintEvent)
    virtual bool CanRiderPlayEmote(URiderComponent*& const Rider) const; // 0x288a61c (Index: 0x3, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void CanJumpExit(bool& CanJumpExit); // 0x288a61c (Index: 0x4, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual bool CanBePet(URiderComponent*& Rider) const; // 0x288a61c (Index: 0x6, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void AudioOnJumpApex__DelegateSignature(); // 0x288a61c (Index: 0x7, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void AudioOnJump__DelegateSignature(double& JumpPitchInterpSpeed); // 0x288a61c (Index: 0x8, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void ApplyGEToSelf(UClass*& GameplayEffectClass, bool& IsValidClass); // 0x288a61c (Index: 0x9, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void ApplyCollisionResponse(TArray<TEnumAsByte<ECollisionChannel>> Channels, TEnumAsByte<ECollisionResponse>& Response); // 0x288a61c (Index: 0xa, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void KickRiderOffSelf(); // 0x288a61c (Index: 0xe, Flags: Public|BlueprintCallable|BlueprintEvent)
    void JumpFatigue_RemoveFatigue(); // 0x288a61c (Index: 0xf, Flags: Public|BlueprintCallable|BlueprintEvent)
    void JumpFatigue_LandTimeStamp(); // 0x288a61c (Index: 0x10, Flags: Public|BlueprintCallable|BlueprintEvent)
    void JumpFatigue_Landed(); // 0x288a61c (Index: 0x11, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void JumpFatigue_CountJumps(); // 0x288a61c (Index: 0x12, Flags: Public|BlueprintCallable|BlueprintEvent)
    void JumpFatigue_CheckApplyFatigue(); // 0x288a61c (Index: 0x13, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void IsSwimming(bool& IsSwimming) const; // 0x288a61c (Index: 0x14, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual void HandleJumpStopped(); // 0x288a61c (Index: 0x17, Flags: Event|Public|BlueprintEvent)
    void HandleEnemyFoleySoundLibrary(UActorComponent*& Rider, bool& bIsRiding); // 0x288a61c (Index: 0x18, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void HandleCancelSprint(bool& const bAbilityInputHeld, bool& const bForceCancel); // 0x288a61c (Index: 0x19, Flags: Event|Public|BlueprintEvent)
    virtual void HandleAbilityStopped(); // 0x288a61c (Index: 0x1a, Flags: Event|Public|BlueprintEvent)
    virtual void HandleAbilityStarted(); // 0x288a61c (Index: 0x1b, Flags: Event|Public|BlueprintEvent)
    virtual void HandleAbilityHeld(); // 0x288a61c (Index: 0x1c, Flags: Event|Public|BlueprintEvent)
    void GetRidingInfoFromTarget(double& JumpAttachGroundHeightMin, double& JumpAttachGroundHeightBuffer, bool& UsesAltRidingMessage); // 0x288a61c (Index: 0x1d, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void GetRidingEmoteCapsuleSize(URiderComponent*& const Rider, float& OriginalRadius, float& OriginalHalfHeight, float& OutRadius, float& OutHalfHeight) const; // 0x288a61c (Index: 0x1e, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual void GetRidingCapsuleSize(URiderComponent*& const Rider, float& OriginalRadius, float& OriginalHalfHeight, float& OutRadius, float& OutHalfHeight) const; // 0x288a61c (Index: 0x1f, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void GetRiderLocation(FVector& Location); // 0x288a61c (Index: 0x20, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void GetRiderCapsuleSize(URiderComponent*& Rider, double& RiderCapsuleRadius, double& RiderCapsuleHH) const; // 0x288a61c (Index: 0x21, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual void HandleJumpStarted(); // 0x288a61c (Index: 0x22, Flags: Event|Public|BlueprintEvent)
    void ForceTaming(AActor*& PlayerPawn, AActor*& CreaturePawn, bool& IsTamingEnabled); // 0x288a61c (Index: 0x23, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void DetermineRateOfChange(double& RateOfChange); // 0x288a61c (Index: 0x29, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void CommitEnergyCosts(bool& RequireAllEnergy, double& EnergyCost, bool& Success); // 0x288a61c (Index: 0x2c, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void ToggleRidingAlternative(); // 0x288a61c (Index: 0x2d, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ToggleRiding(AActor*& PlayerPawn, AActor*& Target, bool& ShouldRide, bool& bChangedRiding); // 0x288a61c (Index: 0x2e, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void TestThreshold(bool& isDecaying, double& CurrentValue, double& testTreshold, bool& PreviousState, bool& crossedThreshold); // 0x288a61c (Index: 0x2f, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void StopSprinting(); // 0x288a61c (Index: 0x30, Flags: Public|BlueprintCallable|BlueprintEvent)
    bool ShouldSetAsViewTarget(URiderComponent*& const Rider) const; // 0x288a61c (Index: 0x31, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual bool ShouldCameraFocusOnRidable(URiderComponent*& const Rider) const; // 0x288a61c (Index: 0x32, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void ShouldBufferJumpExitToRetryJump(bool& Output); // 0x288a61c (Index: 0x33, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void Should_Convert_Jump_Exit_to_Jump(bool& Out); // 0x288a61c (Index: 0x34, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void SetWildlifeHealth(); // 0x288a61c (Index: 0x35, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetInfiniteStaminaBuff(bool& Enabled); // 0x288a61c (Index: 0x36, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void RidableUIUpdateEnergy__DelegateSignature(double& Energy, bool& bIsResting); // 0x288a61c (Index: 0x37, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void RidableUIStart__DelegateSignature(FText& Name, FSlateBrush& Icon); // 0x288a61c (Index: 0x38, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void RestoreCollisionResponses(); // 0x288a61c (Index: 0x3a, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void RemoveGEByTag(FGameplayTagContainer& Tags); // 0x288a61c (Index: 0x3b, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x3e, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x3f, Flags: Event|Public|BlueprintEvent)
    void Propagate_Immunity_Fall_Damage(); // 0x288a61c (Index: 0x40, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnMovementModeChanged(ACharacter*& Character, TEnumAsByte<EMovementMode>& PrevMovementMode, char& PreviousCustomMode); // 0x288a61c (Index: 0x46, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateValue(double& TargetValue, double& RateOfChange, double& DeltaTime, double& updatedValue, bool& EnergyDepleted); // 0x288a61c (Index: 0x4f, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void UpdateLootAnimalGlow(double& Scale); // 0x288a61c (Index: 0x50, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void UpdateAnimInputBool(AFortPawn*& FortPawn, bool& IsBeingRidden); // 0x288a61c (Index: 0x53, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void HandleRiderStoppedRiding(URiderComponent*& Rider); // 0x288a61c (Index: 0x15, Flags: Event|Protected|BlueprintEvent)
    virtual void HandleRiderStartedRiding(URiderComponent*& Rider); // 0x288a61c (Index: 0x16, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCreatureBaseRidableComponent_C) == 0xec1, "Size mismatch for UCreatureBaseRidableComponent_C");
static_assert(offsetof(UCreatureBaseRidableComponent_C, UberGraphFrame) == 0x808, "Offset mismatch for UCreatureBaseRidableComponent_C::UberGraphFrame");
static_assert(offsetof(UCreatureBaseRidableComponent_C, T_CreatureIsBeingRidden) == 0x810, "Offset mismatch for UCreatureBaseRidableComponent_C::T_CreatureIsBeingRidden");
static_assert(offsetof(UCreatureBaseRidableComponent_C, GE_CreatureIsBeingRidden) == 0x830, "Offset mismatch for UCreatureBaseRidableComponent_C::GE_CreatureIsBeingRidden");
static_assert(offsetof(UCreatureBaseRidableComponent_C, GE_CreatureIsBeingRidden_Passive) == 0x838, "Offset mismatch for UCreatureBaseRidableComponent_C::GE_CreatureIsBeingRidden_Passive");
static_assert(offsetof(UCreatureBaseRidableComponent_C, bDebugDisplay) == 0x840, "Offset mismatch for UCreatureBaseRidableComponent_C::bDebugDisplay");
static_assert(offsetof(UCreatureBaseRidableComponent_C, DebugTickRate) == 0x848, "Offset mismatch for UCreatureBaseRidableComponent_C::DebugTickRate");
static_assert(offsetof(UCreatureBaseRidableComponent_C, DebugServerRiderLocation) == 0x850, "Offset mismatch for UCreatureBaseRidableComponent_C::DebugServerRiderLocation");
static_assert(offsetof(UCreatureBaseRidableComponent_C, CapsuleRadiusOffset) == 0x868, "Offset mismatch for UCreatureBaseRidableComponent_C::CapsuleRadiusOffset");
static_assert(offsetof(UCreatureBaseRidableComponent_C, CapsuleHalfHeightOffset) == 0x870, "Offset mismatch for UCreatureBaseRidableComponent_C::CapsuleHalfHeightOffset");
static_assert(offsetof(UCreatureBaseRidableComponent_C, T_RidingSpecialAbility) == 0x878, "Offset mismatch for UCreatureBaseRidableComponent_C::T_RidingSpecialAbility");
static_assert(offsetof(UCreatureBaseRidableComponent_C, IdleAnim_Add) == 0x898, "Offset mismatch for UCreatureBaseRidableComponent_C::IdleAnim_Add");
static_assert(offsetof(UCreatureBaseRidableComponent_C, RunAnim_Add) == 0x8a0, "Offset mismatch for UCreatureBaseRidableComponent_C::RunAnim_Add");
static_assert(offsetof(UCreatureBaseRidableComponent_C, TurnBS) == 0x8a8, "Offset mismatch for UCreatureBaseRidableComponent_C::TurnBS");
static_assert(offsetof(UCreatureBaseRidableComponent_C, MinSpeedToRun) == 0x8b0, "Offset mismatch for UCreatureBaseRidableComponent_C::MinSpeedToRun");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Run_RampIntoSpeed) == 0x8b8, "Offset mismatch for UCreatureBaseRidableComponent_C::Run_RampIntoSpeed");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Run_RampIntoSpeed_ADS) == 0x8c0, "Offset mismatch for UCreatureBaseRidableComponent_C::Run_RampIntoSpeed_ADS");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Run_PlayRate) == 0x8c8, "Offset mismatch for UCreatureBaseRidableComponent_C::Run_PlayRate");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Run_PlayRate_ADS) == 0x8d0, "Offset mismatch for UCreatureBaseRidableComponent_C::Run_PlayRate_ADS");
static_assert(offsetof(UCreatureBaseRidableComponent_C, SpringAlpha) == 0x8d8, "Offset mismatch for UCreatureBaseRidableComponent_C::SpringAlpha");
static_assert(offsetof(UCreatureBaseRidableComponent_C, SpringAlpha_ADS) == 0x8e0, "Offset mismatch for UCreatureBaseRidableComponent_C::SpringAlpha_ADS");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Idle_Alpha) == 0x8e8, "Offset mismatch for UCreatureBaseRidableComponent_C::Idle_Alpha");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Idle_Alpha_ADS) == 0x8f0, "Offset mismatch for UCreatureBaseRidableComponent_C::Idle_Alpha_ADS");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Run_Alpha) == 0x8f8, "Offset mismatch for UCreatureBaseRidableComponent_C::Run_Alpha");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Run_Alpha_ADS) == 0x900, "Offset mismatch for UCreatureBaseRidableComponent_C::Run_Alpha_ADS");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Turn_Alpha) == 0x908, "Offset mismatch for UCreatureBaseRidableComponent_C::Turn_Alpha");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Turn_Alpha_ADS) == 0x910, "Offset mismatch for UCreatureBaseRidableComponent_C::Turn_Alpha_ADS");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Clamp_AnimPose_LastResort) == 0x918, "Offset mismatch for UCreatureBaseRidableComponent_C::Clamp_AnimPose_LastResort");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Clamp_Foot_R_Adjust) == 0x920, "Offset mismatch for UCreatureBaseRidableComponent_C::Clamp_Foot_R_Adjust");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Clamp_Foot_L_Adjust) == 0x938, "Offset mismatch for UCreatureBaseRidableComponent_C::Clamp_Foot_L_Adjust");
static_assert(offsetof(UCreatureBaseRidableComponent_C, CapsuleRadiusOffset_Emote) == 0x950, "Offset mismatch for UCreatureBaseRidableComponent_C::CapsuleRadiusOffset_Emote");
static_assert(offsetof(UCreatureBaseRidableComponent_C, CapsuleHalfHeightOffset_Emote) == 0x958, "Offset mismatch for UCreatureBaseRidableComponent_C::CapsuleHalfHeightOffset_Emote");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Clamp_Location_Offset) == 0x960, "Offset mismatch for UCreatureBaseRidableComponent_C::Clamp_Location_Offset");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Clamp_Rotation_Offset) == 0x978, "Offset mismatch for UCreatureBaseRidableComponent_C::Clamp_Rotation_Offset");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Clamp_ScaleAdjust) == 0x990, "Offset mismatch for UCreatureBaseRidableComponent_C::Clamp_ScaleAdjust");
static_assert(offsetof(UCreatureBaseRidableComponent_C, RidableSocketName) == 0x9a8, "Offset mismatch for UCreatureBaseRidableComponent_C::RidableSocketName");
static_assert(offsetof(UCreatureBaseRidableComponent_C, RidableSocket_Alpha) == 0x9b0, "Offset mismatch for UCreatureBaseRidableComponent_C::RidableSocket_Alpha");
static_assert(offsetof(UCreatureBaseRidableComponent_C, GE_CooldownOverride) == 0x9b8, "Offset mismatch for UCreatureBaseRidableComponent_C::GE_CooldownOverride");
static_assert(offsetof(UCreatureBaseRidableComponent_C, T_CreatureOverrideCooldown) == 0x9c0, "Offset mismatch for UCreatureBaseRidableComponent_C::T_CreatureOverrideCooldown");
static_assert(offsetof(UCreatureBaseRidableComponent_C, OriginalCollisionResponseMap) == 0x9e0, "Offset mismatch for UCreatureBaseRidableComponent_C::OriginalCollisionResponseMap");
static_assert(offsetof(UCreatureBaseRidableComponent_C, RidingSoundIndicatorIconOverride) == 0xa30, "Offset mismatch for UCreatureBaseRidableComponent_C::RidingSoundIndicatorIconOverride");
static_assert(offsetof(UCreatureBaseRidableComponent_C, AudioOnJump) == 0xa58, "Offset mismatch for UCreatureBaseRidableComponent_C::AudioOnJump");
static_assert(offsetof(UCreatureBaseRidableComponent_C, AudioOnJumpApex) == 0xa68, "Offset mismatch for UCreatureBaseRidableComponent_C::AudioOnJumpApex");
static_assert(offsetof(UCreatureBaseRidableComponent_C, MovementMode) == 0xa78, "Offset mismatch for UCreatureBaseRidableComponent_C::MovementMode");
static_assert(offsetof(UCreatureBaseRidableComponent_C, bFalling) == 0xa79, "Offset mismatch for UCreatureBaseRidableComponent_C::bFalling");
static_assert(offsetof(UCreatureBaseRidableComponent_C, RidingAbilityEnable_HF) == 0xa80, "Offset mismatch for UCreatureBaseRidableComponent_C::RidingAbilityEnable_HF");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpAttach_GroundHeightMin) == 0xaa8, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpAttach_GroundHeightMin");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpAttach_GroundHeightBuffer) == 0xab0, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpAttach_GroundHeightBuffer");
static_assert(offsetof(UCreatureBaseRidableComponent_C, UseAltRidingMessage) == 0xab8, "Offset mismatch for UCreatureBaseRidableComponent_C::UseAltRidingMessage");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Riding_Interaction_Text) == 0xac0, "Offset mismatch for UCreatureBaseRidableComponent_C::Riding_Interaction_Text");
static_assert(offsetof(UCreatureBaseRidableComponent_C, currentEnergyValue) == 0xad0, "Offset mismatch for UCreatureBaseRidableComponent_C::currentEnergyValue");
static_assert(offsetof(UCreatureBaseRidableComponent_C, PlayerRiderComponentRef) == 0xad8, "Offset mismatch for UCreatureBaseRidableComponent_C::PlayerRiderComponentRef");
static_assert(offsetof(UCreatureBaseRidableComponent_C, NPCPawnWildlifeRef) == 0xae0, "Offset mismatch for UCreatureBaseRidableComponent_C::NPCPawnWildlifeRef");
static_assert(offsetof(UCreatureBaseRidableComponent_C, previousTimeTracked) == 0xae8, "Offset mismatch for UCreatureBaseRidableComponent_C::previousTimeTracked");
static_assert(offsetof(UCreatureBaseRidableComponent_C, energyTrackingDeltaTime) == 0xaf0, "Offset mismatch for UCreatureBaseRidableComponent_C::energyTrackingDeltaTime");
static_assert(offsetof(UCreatureBaseRidableComponent_C, OldEnergyFlowEnabled) == 0xaf8, "Offset mismatch for UCreatureBaseRidableComponent_C::OldEnergyFlowEnabled");
static_assert(offsetof(UCreatureBaseRidableComponent_C, ShouldHaveEnergy) == 0xaf9, "Offset mismatch for UCreatureBaseRidableComponent_C::ShouldHaveEnergy");
static_assert(offsetof(UCreatureBaseRidableComponent_C, EnergyRateOfDecayStopped) == 0xb00, "Offset mismatch for UCreatureBaseRidableComponent_C::EnergyRateOfDecayStopped");
static_assert(offsetof(UCreatureBaseRidableComponent_C, allowUpdateEnergyTrackingTick) == 0xb08, "Offset mismatch for UCreatureBaseRidableComponent_C::allowUpdateEnergyTrackingTick");
static_assert(offsetof(UCreatureBaseRidableComponent_C, lastBeingRiddenState) == 0xb09, "Offset mismatch for UCreatureBaseRidableComponent_C::lastBeingRiddenState");
static_assert(offsetof(UCreatureBaseRidableComponent_C, EnergyRateOfDecayMoving) == 0xb10, "Offset mismatch for UCreatureBaseRidableComponent_C::EnergyRateOfDecayMoving");
static_assert(offsetof(UCreatureBaseRidableComponent_C, EnergyRateOfDecaySprinting) == 0xb20, "Offset mismatch for UCreatureBaseRidableComponent_C::EnergyRateOfDecaySprinting");
static_assert(offsetof(UCreatureBaseRidableComponent_C, CurrentEnergyRateOfRecharge) == 0xb30, "Offset mismatch for UCreatureBaseRidableComponent_C::CurrentEnergyRateOfRecharge");
static_assert(offsetof(UCreatureBaseRidableComponent_C, ExhaustedEnergyRateOfRecharge) == 0xb38, "Offset mismatch for UCreatureBaseRidableComponent_C::ExhaustedEnergyRateOfRecharge");
static_assert(offsetof(UCreatureBaseRidableComponent_C, EnergyWarningThreshold) == 0xb48, "Offset mismatch for UCreatureBaseRidableComponent_C::EnergyWarningThreshold");
static_assert(offsetof(UCreatureBaseRidableComponent_C, EnergyCriticalThreshold) == 0xb50, "Offset mismatch for UCreatureBaseRidableComponent_C::EnergyCriticalThreshold");
static_assert(offsetof(UCreatureBaseRidableComponent_C, energyWarningActive) == 0xb58, "Offset mismatch for UCreatureBaseRidableComponent_C::energyWarningActive");
static_assert(offsetof(UCreatureBaseRidableComponent_C, energyCriticalActive) == 0xb59, "Offset mismatch for UCreatureBaseRidableComponent_C::energyCriticalActive");
static_assert(offsetof(UCreatureBaseRidableComponent_C, minMovementSpeedTreshold) == 0xb60, "Offset mismatch for UCreatureBaseRidableComponent_C::minMovementSpeedTreshold");
static_assert(offsetof(UCreatureBaseRidableComponent_C, IsJumping) == 0xb68, "Offset mismatch for UCreatureBaseRidableComponent_C::IsJumping");
static_assert(offsetof(UCreatureBaseRidableComponent_C, EnergyRegenThreshold) == 0xb70, "Offset mismatch for UCreatureBaseRidableComponent_C::EnergyRegenThreshold");
static_assert(offsetof(UCreatureBaseRidableComponent_C, AlwaysRegenWhenNotRidden) == 0xb78, "Offset mismatch for UCreatureBaseRidableComponent_C::AlwaysRegenWhenNotRidden");
static_assert(offsetof(UCreatureBaseRidableComponent_C, GE_EnergyWarning) == 0xb80, "Offset mismatch for UCreatureBaseRidableComponent_C::GE_EnergyWarning");
static_assert(offsetof(UCreatureBaseRidableComponent_C, GE_EnergyCritical) == 0xb88, "Offset mismatch for UCreatureBaseRidableComponent_C::GE_EnergyCritical");
static_assert(offsetof(UCreatureBaseRidableComponent_C, GE_EnergyDepleted) == 0xb90, "Offset mismatch for UCreatureBaseRidableComponent_C::GE_EnergyDepleted");
static_assert(offsetof(UCreatureBaseRidableComponent_C, T_EnergyWarning) == 0xb98, "Offset mismatch for UCreatureBaseRidableComponent_C::T_EnergyWarning");
static_assert(offsetof(UCreatureBaseRidableComponent_C, T_EnergyCritical) == 0xbb8, "Offset mismatch for UCreatureBaseRidableComponent_C::T_EnergyCritical");
static_assert(offsetof(UCreatureBaseRidableComponent_C, T_EnergyDepleted) == 0xbd8, "Offset mismatch for UCreatureBaseRidableComponent_C::T_EnergyDepleted");
static_assert(offsetof(UCreatureBaseRidableComponent_C, T_CannotRideBucket) == 0xbf8, "Offset mismatch for UCreatureBaseRidableComponent_C::T_CannotRideBucket");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Gameplay_Effect) == 0xc18, "Offset mismatch for UCreatureBaseRidableComponent_C::Gameplay_Effect");
static_assert(offsetof(UCreatureBaseRidableComponent_C, SprintingAbilityTag) == 0xc20, "Offset mismatch for UCreatureBaseRidableComponent_C::SprintingAbilityTag");
static_assert(offsetof(UCreatureBaseRidableComponent_C, GE_EatToRefuel) == 0xc28, "Offset mismatch for UCreatureBaseRidableComponent_C::GE_EatToRefuel");
static_assert(offsetof(UCreatureBaseRidableComponent_C, IconBrush) == 0xc30, "Offset mismatch for UCreatureBaseRidableComponent_C::IconBrush");
static_assert(offsetof(UCreatureBaseRidableComponent_C, GE_Creature_Sprint) == 0xce0, "Offset mismatch for UCreatureBaseRidableComponent_C::GE_Creature_Sprint");
static_assert(offsetof(UCreatureBaseRidableComponent_C, RidingFoleySoundLibrary) == 0xce8, "Offset mismatch for UCreatureBaseRidableComponent_C::RidingFoleySoundLibrary");
static_assert(offsetof(UCreatureBaseRidableComponent_C, TagsPreventSprinting) == 0xcf0, "Offset mismatch for UCreatureBaseRidableComponent_C::TagsPreventSprinting");
static_assert(offsetof(UCreatureBaseRidableComponent_C, RidableUIStart) == 0xd10, "Offset mismatch for UCreatureBaseRidableComponent_C::RidableUIStart");
static_assert(offsetof(UCreatureBaseRidableComponent_C, RidableUIUpdateEnergy) == 0xd20, "Offset mismatch for UCreatureBaseRidableComponent_C::RidableUIUpdateEnergy");
static_assert(offsetof(UCreatureBaseRidableComponent_C, OutOfEnergySoundLibTag) == 0xd30, "Offset mismatch for UCreatureBaseRidableComponent_C::OutOfEnergySoundLibTag");
static_assert(offsetof(UCreatureBaseRidableComponent_C, SprintStartSoundLibTag) == 0xd34, "Offset mismatch for UCreatureBaseRidableComponent_C::SprintStartSoundLibTag");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Riding_Interaction_Type) == 0xd38, "Offset mismatch for UCreatureBaseRidableComponent_C::Riding_Interaction_Type");
static_assert(offsetof(UCreatureBaseRidableComponent_C, StartInAirTimestamp) == 0xd40, "Offset mismatch for UCreatureBaseRidableComponent_C::StartInAirTimestamp");
static_assert(offsetof(UCreatureBaseRidableComponent_C, RetryJumpExitTimerHandle) == 0xd48, "Offset mismatch for UCreatureBaseRidableComponent_C::RetryJumpExitTimerHandle");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpExitBufferStartTimeStamp) == 0xd50, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpExitBufferStartTimeStamp");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpExitBufferTime) == 0xd58, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpExitBufferTime");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpExitBufferTimerHandle) == 0xd80, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpExitBufferTimerHandle");
static_assert(offsetof(UCreatureBaseRidableComponent_C, MountLandedCueTag) == 0xd88, "Offset mismatch for UCreatureBaseRidableComponent_C::MountLandedCueTag");
static_assert(offsetof(UCreatureBaseRidableComponent_C, GE_BlockCreatureAttackOnDismount) == 0xd90, "Offset mismatch for UCreatureBaseRidableComponent_C::GE_BlockCreatureAttackOnDismount");
static_assert(offsetof(UCreatureBaseRidableComponent_C, EnergyRegenActive) == 0xd98, "Offset mismatch for UCreatureBaseRidableComponent_C::EnergyRegenActive");
static_assert(offsetof(UCreatureBaseRidableComponent_C, BlockPetting_TagContainer) == 0xda0, "Offset mismatch for UCreatureBaseRidableComponent_C::BlockPetting_TagContainer");
static_assert(offsetof(UCreatureBaseRidableComponent_C, infiniteStaminaBuffEnabled) == 0xdc0, "Offset mismatch for UCreatureBaseRidableComponent_C::infiniteStaminaBuffEnabled");
static_assert(offsetof(UCreatureBaseRidableComponent_C, InfiniteStaminaEffect_GameplayCueTag) == 0xdc4, "Offset mismatch for UCreatureBaseRidableComponent_C::InfiniteStaminaEffect_GameplayCueTag");
static_assert(offsetof(UCreatureBaseRidableComponent_C, Cannot_Ride_Rider_Bucket) == 0xdc8, "Offset mismatch for UCreatureBaseRidableComponent_C::Cannot_Ride_Rider_Bucket");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpFatigue_Enabled) == 0xde8, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpFatigue_Enabled");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpFatigue_ApplyFatigueMinJumpCount) == 0xe10, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpFatigue_ApplyFatigueMinJumpCount");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpFatigueGameplayEffect) == 0xe38, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpFatigueGameplayEffect");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpFatigueDebugEnabled) == 0xe40, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpFatigueDebugEnabled");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpFatigueJumpCount) == 0xe44, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpFatigueJumpCount");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpFatigue_LastLandingTimeStamp) == 0xe48, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpFatigue_LastLandingTimeStamp");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpFatigue_ResetCounterDelay) == 0xe50, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpFatigue_ResetCounterDelay");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpFatigue_ShouldTimeStampNextLanding) == 0xe78, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpFatigue_ShouldTimeStampNextLanding");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpFatigue_GEHandle) == 0xe7c, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpFatigue_GEHandle");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpFatigue_RemovalTimerHandle) == 0xe88, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpFatigue_RemovalTimerHandle");
static_assert(offsetof(UCreatureBaseRidableComponent_C, JumpFatigue_GeDurationPostLanding) == 0xe90, "Offset mismatch for UCreatureBaseRidableComponent_C::JumpFatigue_GeDurationPostLanding");
static_assert(offsetof(UCreatureBaseRidableComponent_C, GE_NotPetable_IsBeingRidden) == 0xeb8, "Offset mismatch for UCreatureBaseRidableComponent_C::GE_NotPetable_IsBeingRidden");
static_assert(offsetof(UCreatureBaseRidableComponent_C, bAllowRidingInteraction) == 0xec0, "Offset mismatch for UCreatureBaseRidableComponent_C::bAllowRidingInteraction");

// Size: 0x888 (Inherited: 0x1208, Single: 0xfffff680)
class UPlayerRiderComponent_C : public UControllingRiderComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x758 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer T_PlayerIsRiding; // 0x760 (Size: 0x20, Type: StructProperty)
    UClass* GE_PlayerIsRiding; // 0x780 (Size: 0x8, Type: ClassProperty)
    AFortPlayerPawn* FortPlayerRef; // 0x788 (Size: 0x8, Type: ObjectProperty)
    double JumpOnMountDistanceCheck; // 0x790 (Size: 0x8, Type: DoubleProperty)
    uint8_t RiderUINewStats[0x10]; // 0x798 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t RiderUIEnd[0x10]; // 0x7a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    double targetEnergy; // 0x7b8 (Size: 0x8, Type: DoubleProperty)
    double targetHealth; // 0x7c0 (Size: 0x8, Type: DoubleProperty)
    FGameplayTagContainer T_CannotRideBucket; // 0x7c8 (Size: 0x20, Type: StructProperty)
    uint8_t RiderUIUpdateEnergy[0x10]; // 0x7e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t RiderUIUpdateHealth[0x10]; // 0x7f8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    AActor* CachedRidableActor; // 0x808 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer Cannot_Ride_Rider_Bucket; // 0x810 (Size: 0x20, Type: StructProperty)
    FGameplayTag JumpOnCreature_Cue_Tag; // 0x830 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_834[0x4]; // 0x834 (Size: 0x4, Type: PaddingProperty)
    UClass* GE_PlayerPetting; // 0x838 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer Tag_Quests_Wildlife_Pet; // 0x840 (Size: 0x20, Type: StructProperty)
    UAbilityAsync_WaitGameplayTagAdded* ActiveRidableBlockRidingGameplayTagAsyncAction; // 0x860 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AllowRidingMovementModeChangeTags; // 0x868 (Size: 0x20, Type: StructProperty)

public:
    void GetRidingInfoFromTarget(double& JumpAttachGroundHeightMin, double& JumpAttachGroundHeightBuffer, bool& UsesAltRidingMessage); // 0x288a61c (Index: 0xa, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void GetJumpInfo(AActor*& TargetActor, UActorComponent*& TargetActorComponent, double& JumpAttach_GroundHeightMin, double& JumpAttach_GroundHeightBuffer, bool& UseAltRidingMessage); // 0x288a61c (Index: 0xb, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void ToggleRidingAlternative(); // 0x288a61c (Index: 0x13, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ToggleRiding(AActor*& PlayerPawn, AActor*& Target, bool& ShouldRide, bool& bChangedRiding); // 0x288a61c (Index: 0x14, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void TestIfValidForRidingAttempt(UObject*& Object, bool& Success, UObject*& TargetObject, bool& UseAltRidingMessage); // 0x288a61c (Index: 0x15, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void RiderUIUpdateHealth__DelegateSignature(double& Health); // 0x288a61c (Index: 0x17, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void RiderUIUpdateEnergy__DelegateSignature(double& Energy); // 0x288a61c (Index: 0x18, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void RiderUINewStats__DelegateSignature(FText& Name, FSlateBrush& Icon, AActor*& RidableActor); // 0x288a61c (Index: 0x1a, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void RiderUIEnd__DelegateSignature(AActor*& RidableActor); // 0x288a61c (Index: 0x1c, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x1d, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void HandleStoppedRiding(URidableComponent*& Ridable); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void HandleStartedRiding(URidableComponent*& Ridable); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void HandleRidableFound(const FHitResult HitResult); // 0x288a61c (Index: 0x7, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void HandleRequestPettingStop(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void HandleRequestPettingStart(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UPlayerRiderComponent_C) == 0x888, "Size mismatch for UPlayerRiderComponent_C");
static_assert(offsetof(UPlayerRiderComponent_C, UberGraphFrame) == 0x758, "Offset mismatch for UPlayerRiderComponent_C::UberGraphFrame");
static_assert(offsetof(UPlayerRiderComponent_C, T_PlayerIsRiding) == 0x760, "Offset mismatch for UPlayerRiderComponent_C::T_PlayerIsRiding");
static_assert(offsetof(UPlayerRiderComponent_C, GE_PlayerIsRiding) == 0x780, "Offset mismatch for UPlayerRiderComponent_C::GE_PlayerIsRiding");
static_assert(offsetof(UPlayerRiderComponent_C, FortPlayerRef) == 0x788, "Offset mismatch for UPlayerRiderComponent_C::FortPlayerRef");
static_assert(offsetof(UPlayerRiderComponent_C, JumpOnMountDistanceCheck) == 0x790, "Offset mismatch for UPlayerRiderComponent_C::JumpOnMountDistanceCheck");
static_assert(offsetof(UPlayerRiderComponent_C, RiderUINewStats) == 0x798, "Offset mismatch for UPlayerRiderComponent_C::RiderUINewStats");
static_assert(offsetof(UPlayerRiderComponent_C, RiderUIEnd) == 0x7a8, "Offset mismatch for UPlayerRiderComponent_C::RiderUIEnd");
static_assert(offsetof(UPlayerRiderComponent_C, targetEnergy) == 0x7b8, "Offset mismatch for UPlayerRiderComponent_C::targetEnergy");
static_assert(offsetof(UPlayerRiderComponent_C, targetHealth) == 0x7c0, "Offset mismatch for UPlayerRiderComponent_C::targetHealth");
static_assert(offsetof(UPlayerRiderComponent_C, T_CannotRideBucket) == 0x7c8, "Offset mismatch for UPlayerRiderComponent_C::T_CannotRideBucket");
static_assert(offsetof(UPlayerRiderComponent_C, RiderUIUpdateEnergy) == 0x7e8, "Offset mismatch for UPlayerRiderComponent_C::RiderUIUpdateEnergy");
static_assert(offsetof(UPlayerRiderComponent_C, RiderUIUpdateHealth) == 0x7f8, "Offset mismatch for UPlayerRiderComponent_C::RiderUIUpdateHealth");
static_assert(offsetof(UPlayerRiderComponent_C, CachedRidableActor) == 0x808, "Offset mismatch for UPlayerRiderComponent_C::CachedRidableActor");
static_assert(offsetof(UPlayerRiderComponent_C, Cannot_Ride_Rider_Bucket) == 0x810, "Offset mismatch for UPlayerRiderComponent_C::Cannot_Ride_Rider_Bucket");
static_assert(offsetof(UPlayerRiderComponent_C, JumpOnCreature_Cue_Tag) == 0x830, "Offset mismatch for UPlayerRiderComponent_C::JumpOnCreature_Cue_Tag");
static_assert(offsetof(UPlayerRiderComponent_C, GE_PlayerPetting) == 0x838, "Offset mismatch for UPlayerRiderComponent_C::GE_PlayerPetting");
static_assert(offsetof(UPlayerRiderComponent_C, Tag_Quests_Wildlife_Pet) == 0x840, "Offset mismatch for UPlayerRiderComponent_C::Tag_Quests_Wildlife_Pet");
static_assert(offsetof(UPlayerRiderComponent_C, ActiveRidableBlockRidingGameplayTagAsyncAction) == 0x860, "Offset mismatch for UPlayerRiderComponent_C::ActiveRidableBlockRidingGameplayTagAsyncAction");
static_assert(offsetof(UPlayerRiderComponent_C, AllowRidingMovementModeChangeTags) == 0x868, "Offset mismatch for UPlayerRiderComponent_C::AllowRidingMovementModeChangeTags");

// Size: 0xec1 (Inherited: 0x1c99, Single: 0xfffff228)
class UWolfRidableComponent_C : public UCreatureBaseRidableComponent_C
{
public:
};

static_assert(sizeof(UWolfRidableComponent_C) == 0xec1, "Size mismatch for UWolfRidableComponent_C");

// Size: 0xf0c (Inherited: 0x1c99, Single: 0xfffff273)
class UBoarRidableComponent_C : public UCreatureBaseRidableComponent_C
{
public:
    uint8_t Pad_ec1[0x7]; // 0xec1 (Size: 0x7, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0xec8 (Size: 0x8, Type: StructProperty)
    USoundBase* BurtChargeStartSound; // 0xed0 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* ChargeSoundComp; // 0xed8 (Size: 0x8, Type: ObjectProperty)
    double SprintCooldDownTime; // 0xee0 (Size: 0x8, Type: DoubleProperty)
    UClass* GESprintImpactPawn; // 0xee8 (Size: 0x8, Type: ClassProperty)
    FGameplayTag SprintImpactGameplayCueTag; // 0xef0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_ef4[0x4]; // 0xef4 (Size: 0x4, Type: PaddingProperty)
    UClass* GESprintImpactVehicle; // 0xef8 (Size: 0x8, Type: ClassProperty)
    FGameplayTag SprintChargeImpact_Default_CueTag; // 0xf00 (Size: 0x4, Type: StructProperty)
    FGameplayTag SprintChargeImpact_Pawn_CueTag; // 0xf04 (Size: 0x4, Type: StructProperty)
    FGameplayTag SprintChargeImpact_DestroyBuild_CueTag; // 0xf08 (Size: 0x4, Type: StructProperty)

public:
    void OnReaction(UObject*& Object, FHitResult& HitResult); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void HandleAbilityStarted(); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void HandleRiderStoppedRiding(URiderComponent*& Rider); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void HandleRiderStartedRiding(URiderComponent*& Rider); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UBoarRidableComponent_C) == 0xf0c, "Size mismatch for UBoarRidableComponent_C");
static_assert(offsetof(UBoarRidableComponent_C, UberGraphFrame) == 0xec8, "Offset mismatch for UBoarRidableComponent_C::UberGraphFrame");
static_assert(offsetof(UBoarRidableComponent_C, BurtChargeStartSound) == 0xed0, "Offset mismatch for UBoarRidableComponent_C::BurtChargeStartSound");
static_assert(offsetof(UBoarRidableComponent_C, ChargeSoundComp) == 0xed8, "Offset mismatch for UBoarRidableComponent_C::ChargeSoundComp");
static_assert(offsetof(UBoarRidableComponent_C, SprintCooldDownTime) == 0xee0, "Offset mismatch for UBoarRidableComponent_C::SprintCooldDownTime");
static_assert(offsetof(UBoarRidableComponent_C, GESprintImpactPawn) == 0xee8, "Offset mismatch for UBoarRidableComponent_C::GESprintImpactPawn");
static_assert(offsetof(UBoarRidableComponent_C, SprintImpactGameplayCueTag) == 0xef0, "Offset mismatch for UBoarRidableComponent_C::SprintImpactGameplayCueTag");
static_assert(offsetof(UBoarRidableComponent_C, GESprintImpactVehicle) == 0xef8, "Offset mismatch for UBoarRidableComponent_C::GESprintImpactVehicle");
static_assert(offsetof(UBoarRidableComponent_C, SprintChargeImpact_Default_CueTag) == 0xf00, "Offset mismatch for UBoarRidableComponent_C::SprintChargeImpact_Default_CueTag");
static_assert(offsetof(UBoarRidableComponent_C, SprintChargeImpact_Pawn_CueTag) == 0xf04, "Offset mismatch for UBoarRidableComponent_C::SprintChargeImpact_Pawn_CueTag");
static_assert(offsetof(UBoarRidableComponent_C, SprintChargeImpact_DestroyBuild_CueTag) == 0xf08, "Offset mismatch for UBoarRidableComponent_C::SprintChargeImpact_DestroyBuild_CueTag");

// Size: 0x2d8 (Inherited: 0x728, Single: 0xfffffbb0)
class UBP_JamInstrumentAnimation_PlayerStateComponent_C : public UBP_SparksInstrumentAnimation_PlayerStateComponent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x290 (Size: 0x8, Type: StructProperty)
    AJamPlayspace* JamPlayspace; // 0x298 (Size: 0x8, Type: ObjectProperty)
    UGameplayEventRouterComponent* EventRouter; // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    UAsyncAction_StartListeningToEvent* JamLoopStartedAsyncTask; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UAsyncAction_StartListeningToEvent* JamLoopStoppedAsyncTask; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    FString CanSwapInstrumentsCVarName; // 0x2b8 (Size: 0x10, Type: StrProperty)
    uint8_t CurrentLoopType; // 0x2c8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2c9[0x3]; // 0x2c9 (Size: 0x3, Type: PaddingProperty)
    int32_t LastLoadedAnimsId; // 0x2cc (Size: 0x4, Type: IntProperty)
    USparksInstrumentAnimations* LoadedAnims; // 0x2d0 (Size: 0x8, Type: ObjectProperty)

public:
    void UpdateMusicClock(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateCanPlayMidiAnimations(const FUniqueNetIdRepl PlayerNetIdToIgnore); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void UpdateAnimatableState(); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UnloadAnimations(); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void SwapCosmeticInstrument(ESparksInstrumentType& NewInstrumentType); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    void ServerHolsterWeaponForOwner(bool& const bHolster); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintEvent)
    void ReactToExistingSlot(); // 0x288a61c (Index: 0x7, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void LoadAnimations(); // 0x288a61c (Index: 0x10, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual bool IsUsable() const; // 0x288a61c (Index: 0x12, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void IsPlayerJammer(bool& IsJammer) const; // 0x288a61c (Index: 0x13, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual ESparksInstrumentType GetTrackInstrumentType() const; // 0x288a61c (Index: 0x15, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void GetThisPlayersMusicSlot(UJamMusicSlot*& MusicSlot) const; // 0x288a61c (Index: 0x16, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void GetLoadedAnimations(USparksInstrumentAnimations*& LoadedAnims); // 0x288a61c (Index: 0x17, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void ExitedSparksMusicPlayspace(ASparksMusicPlayspace*& Playspace); // 0x288a61c (Index: 0x18, Flags: Event|Public|BlueprintEvent)
    virtual void EnteredSparksMusicPlayspace(ASparksMusicPlayspace*& Playspace); // 0x288a61c (Index: 0x1a, Flags: Event|Public|BlueprintEvent)
    virtual bool CanSwapToInstrument(ESparksInstrumentType& NewInstrumentType); // 0x288a61c (Index: 0x1b, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual bool CanApplyHolster(const FName HolsterId) const; // 0x288a61c (Index: 0x1c, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const)

protected:
    void IsCorrectPlayer(FUniqueNetIdRepl& PlayerNetId, bool& IsAutoJammer, bool& Correct); // 0x288a61c (Index: 0x14, Flags: Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
};

static_assert(sizeof(UBP_JamInstrumentAnimation_PlayerStateComponent_C) == 0x2d8, "Size mismatch for UBP_JamInstrumentAnimation_PlayerStateComponent_C");
static_assert(offsetof(UBP_JamInstrumentAnimation_PlayerStateComponent_C, UberGraphFrame) == 0x290, "Offset mismatch for UBP_JamInstrumentAnimation_PlayerStateComponent_C::UberGraphFrame");
static_assert(offsetof(UBP_JamInstrumentAnimation_PlayerStateComponent_C, JamPlayspace) == 0x298, "Offset mismatch for UBP_JamInstrumentAnimation_PlayerStateComponent_C::JamPlayspace");
static_assert(offsetof(UBP_JamInstrumentAnimation_PlayerStateComponent_C, EventRouter) == 0x2a0, "Offset mismatch for UBP_JamInstrumentAnimation_PlayerStateComponent_C::EventRouter");
static_assert(offsetof(UBP_JamInstrumentAnimation_PlayerStateComponent_C, JamLoopStartedAsyncTask) == 0x2a8, "Offset mismatch for UBP_JamInstrumentAnimation_PlayerStateComponent_C::JamLoopStartedAsyncTask");
static_assert(offsetof(UBP_JamInstrumentAnimation_PlayerStateComponent_C, JamLoopStoppedAsyncTask) == 0x2b0, "Offset mismatch for UBP_JamInstrumentAnimation_PlayerStateComponent_C::JamLoopStoppedAsyncTask");
static_assert(offsetof(UBP_JamInstrumentAnimation_PlayerStateComponent_C, CanSwapInstrumentsCVarName) == 0x2b8, "Offset mismatch for UBP_JamInstrumentAnimation_PlayerStateComponent_C::CanSwapInstrumentsCVarName");
static_assert(offsetof(UBP_JamInstrumentAnimation_PlayerStateComponent_C, CurrentLoopType) == 0x2c8, "Offset mismatch for UBP_JamInstrumentAnimation_PlayerStateComponent_C::CurrentLoopType");
static_assert(offsetof(UBP_JamInstrumentAnimation_PlayerStateComponent_C, LastLoadedAnimsId) == 0x2cc, "Offset mismatch for UBP_JamInstrumentAnimation_PlayerStateComponent_C::LastLoadedAnimsId");
static_assert(offsetof(UBP_JamInstrumentAnimation_PlayerStateComponent_C, LoadedAnims) == 0x2d0, "Offset mismatch for UBP_JamInstrumentAnimation_PlayerStateComponent_C::LoadedAnims");

// Size: 0x1c8 (Inherited: 0x418, Single: 0xfffffdb0)
class UBP_JamOnOffSwitchComponent_C : public UJamOnOffSwitchComponent
{
public:
};

static_assert(sizeof(UBP_JamOnOffSwitchComponent_C) == 0x1c8, "Size mismatch for UBP_JamOnOffSwitchComponent_C");

// Size: 0x158 (Inherited: 0x4e0, Single: 0xfffffc78)
class UBP_JamInLobbyControllerComponent_LoopOptions_C : public UJamInLobbyControllerComponent_LoopOptions
{
public:
};

static_assert(sizeof(UBP_JamInLobbyControllerComponent_LoopOptions_C) == 0x158, "Size mismatch for UBP_JamInLobbyControllerComponent_LoopOptions_C");

// Size: 0xf8 (Inherited: 0x330, Single: 0xfffffdc8)
class UBP_JamPlayerPawnComponent_C : public UJamPlayerPawnComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xe0 (Size: 0x8, Type: StructProperty)
    ABP_JamPlayspace_C* JamPlayspace; // 0xe8 (Size: 0x8, Type: ObjectProperty)
    USparksMusicPlayspaceAudioState* JamAudioState; // 0xf0 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void ExitedSparksMusicPlayspace(ASparksMusicPlayspace*& Playspace); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)
    virtual bool AllowedToEnterMusicPlayspace(ASparksMusicPlayspace*& Playspace) const; // 0x288a61c (Index: 0xa, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UBP_JamPlayerPawnComponent_C) == 0xf8, "Size mismatch for UBP_JamPlayerPawnComponent_C");
static_assert(offsetof(UBP_JamPlayerPawnComponent_C, UberGraphFrame) == 0xe0, "Offset mismatch for UBP_JamPlayerPawnComponent_C::UberGraphFrame");
static_assert(offsetof(UBP_JamPlayerPawnComponent_C, JamPlayspace) == 0xe8, "Offset mismatch for UBP_JamPlayerPawnComponent_C::JamPlayspace");
static_assert(offsetof(UBP_JamPlayerPawnComponent_C, JamAudioState) == 0xf0, "Offset mismatch for UBP_JamPlayerPawnComponent_C::JamAudioState");

// Size: 0x1a0 (Inherited: 0x330, Single: 0xfffffe70)
class UBP_JamControllerComponent_C : public UJamControllerComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xe0 (Size: 0x8, Type: StructProperty)
    ABP_JamPlayspace_C* Leaf_Jam_Playspace; // 0xe8 (Size: 0x8, Type: ObjectProperty)
    UAbilityAsync_WaitGameplayTagAdded* JammingTagAddedHandle; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UAbilityAsync_WaitGameplayTagRemoved* JammingTagRemovedHandle; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    FString EnableJamEmotesCVarName; // 0x100 (Size: 0x10, Type: StrProperty)
    FString EnableAutoJammersCVarName; // 0x110 (Size: 0x10, Type: StrProperty)
    TArray<FJamUISceneByTags> UIScenes; // 0x120 (Size: 0x10, Type: ArrayProperty)
    TArray<UDynamicUIScene*> AddedUIScenes; // 0x130 (Size: 0x10, Type: ArrayProperty)
    bool CanAutoJam; // 0x140 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_141[0x7]; // 0x141 (Size: 0x7, Type: PaddingProperty)
    UInputMappingContext* JamControlsMap; // 0x148 (Size: 0x8, Type: ObjectProperty)
    UInputMappingContext* AutoJamControlsMap; // 0x150 (Size: 0x8, Type: ObjectProperty)
    UClass* JammingGE; // 0x158 (Size: 0x8, Type: ClassProperty)
    TArray<ABP_JamPlayspace_C*> KnownPlayspaces; // 0x160 (Size: 0x10, Type: ArrayProperty)
    TArray<FDynamicUISceneRequestHandle> DynamicUI_Scene_Requests; // 0x170 (Size: 0x10, Type: ArrayProperty)
    UDynamicUISceneRequestCoordinatorComponent* DynamicUICoordinator; // 0x180 (Size: 0x8, Type: ObjectProperty)
    bool bWantsJamControls; // 0x188 (Size: 0x1, Type: BoolProperty)
    bool bCanHaveJamControls; // 0x189 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_18a[0x6]; // 0x18a (Size: 0x6, Type: PaddingProperty)
    TArray<UInputAlias*> Active_Input_Aliases; // 0x190 (Size: 0x10, Type: ArrayProperty)

public:
    void Remove_Events_From_Picker_Context(UFortPickerContext*& The_Context); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void RemoveUIScenes(); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetUIScenes(TArray<UDynamicUIScene*>& NewParam); // 0x288a61c (Index: 0xd, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    bool GetIsPlayerBlocked(); // 0x288a61c (Index: 0xe, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void Fetch_Scene_Coordinator(); // 0x288a61c (Index: 0xf, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void ExitedSparksMusicPlayspace(ASparksMusicPlayspace*& Playspace); // 0x288a61c (Index: 0x10, Flags: Event|Public|BlueprintEvent)
    virtual void EnteredSparksMusicPlayspace(ASparksMusicPlayspace*& Playspace); // 0x288a61c (Index: 0x12, Flags: Event|Public|BlueprintEvent)
    void Cache_Autojammer_Cvar(); // 0x288a61c (Index: 0x15, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Bind_Events_To_Picker_Context(UFortPickerContext*& The_Context); // 0x288a61c (Index: 0x16, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual bool AllowedToEnterMusicPlayspace(ASparksMusicPlayspace*& Playspace) const; // 0x288a61c (Index: 0x18, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
    void AddUIScenes(); // 0x288a61c (Index: 0x19, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void UpdateUIScenes(); // 0x288a61c (Index: 0x1c, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetWantsJamControls(bool& bNewWantsJamControls); // 0x288a61c (Index: 0x22, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetCanHaveJamControls(bool& bNewCanHaveJamControls); // 0x288a61c (Index: 0x23, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x27, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x28, Flags: Event|Public|BlueprintEvent)
    void ProcessChangeToWantsOrCanHaveJamControls(); // 0x288a61c (Index: 0x29, Flags: Public|BlueprintCallable|BlueprintEvent)

private:
    void Add_Emote_Controls(); // 0x288a61c (Index: 0x1b, Flags: Private|HasDefaults|BlueprintCallable|BlueprintEvent)
    void RemoveEmoteControls(); // 0x288a61c (Index: 0x25, Flags: Private|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    void LeavePlayspace(ABP_JamPlayspace_C*& Playspace_To_Leave); // 0x288a61c (Index: 0x8, Flags: Protected|BlueprintCallable|BlueprintEvent)
    void Join_Playspace(ABP_JamPlayspace_C*& JamPlayspaceToJoin); // 0x288a61c (Index: 0x9, Flags: Protected|BlueprintCallable|BlueprintEvent)
    void ApplyJammingGE(); // 0x288a61c (Index: 0x17, Flags: Protected|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void UpdateJamUI(); // 0x288a61c (Index: 0x1d, Flags: Event|Protected|BlueprintEvent)
    void RemoveJammingGE(); // 0x288a61c (Index: 0x24, Flags: Protected|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UBP_JamControllerComponent_C) == 0x1a0, "Size mismatch for UBP_JamControllerComponent_C");
static_assert(offsetof(UBP_JamControllerComponent_C, UberGraphFrame) == 0xe0, "Offset mismatch for UBP_JamControllerComponent_C::UberGraphFrame");
static_assert(offsetof(UBP_JamControllerComponent_C, Leaf_Jam_Playspace) == 0xe8, "Offset mismatch for UBP_JamControllerComponent_C::Leaf_Jam_Playspace");
static_assert(offsetof(UBP_JamControllerComponent_C, JammingTagAddedHandle) == 0xf0, "Offset mismatch for UBP_JamControllerComponent_C::JammingTagAddedHandle");
static_assert(offsetof(UBP_JamControllerComponent_C, JammingTagRemovedHandle) == 0xf8, "Offset mismatch for UBP_JamControllerComponent_C::JammingTagRemovedHandle");
static_assert(offsetof(UBP_JamControllerComponent_C, EnableJamEmotesCVarName) == 0x100, "Offset mismatch for UBP_JamControllerComponent_C::EnableJamEmotesCVarName");
static_assert(offsetof(UBP_JamControllerComponent_C, EnableAutoJammersCVarName) == 0x110, "Offset mismatch for UBP_JamControllerComponent_C::EnableAutoJammersCVarName");
static_assert(offsetof(UBP_JamControllerComponent_C, UIScenes) == 0x120, "Offset mismatch for UBP_JamControllerComponent_C::UIScenes");
static_assert(offsetof(UBP_JamControllerComponent_C, AddedUIScenes) == 0x130, "Offset mismatch for UBP_JamControllerComponent_C::AddedUIScenes");
static_assert(offsetof(UBP_JamControllerComponent_C, CanAutoJam) == 0x140, "Offset mismatch for UBP_JamControllerComponent_C::CanAutoJam");
static_assert(offsetof(UBP_JamControllerComponent_C, JamControlsMap) == 0x148, "Offset mismatch for UBP_JamControllerComponent_C::JamControlsMap");
static_assert(offsetof(UBP_JamControllerComponent_C, AutoJamControlsMap) == 0x150, "Offset mismatch for UBP_JamControllerComponent_C::AutoJamControlsMap");
static_assert(offsetof(UBP_JamControllerComponent_C, JammingGE) == 0x158, "Offset mismatch for UBP_JamControllerComponent_C::JammingGE");
static_assert(offsetof(UBP_JamControllerComponent_C, KnownPlayspaces) == 0x160, "Offset mismatch for UBP_JamControllerComponent_C::KnownPlayspaces");
static_assert(offsetof(UBP_JamControllerComponent_C, DynamicUI_Scene_Requests) == 0x170, "Offset mismatch for UBP_JamControllerComponent_C::DynamicUI_Scene_Requests");
static_assert(offsetof(UBP_JamControllerComponent_C, DynamicUICoordinator) == 0x180, "Offset mismatch for UBP_JamControllerComponent_C::DynamicUICoordinator");
static_assert(offsetof(UBP_JamControllerComponent_C, bWantsJamControls) == 0x188, "Offset mismatch for UBP_JamControllerComponent_C::bWantsJamControls");
static_assert(offsetof(UBP_JamControllerComponent_C, bCanHaveJamControls) == 0x189, "Offset mismatch for UBP_JamControllerComponent_C::bCanHaveJamControls");
static_assert(offsetof(UBP_JamControllerComponent_C, Active_Input_Aliases) == 0x190, "Offset mismatch for UBP_JamControllerComponent_C::Active_Input_Aliases");

// Size: 0x288 (Inherited: 0x760, Single: 0xfffffb28)
class UBP_JamInLobbyPlayspaceComponent_ReactiveFX_C : public UBP_JamPlayspaceComponent_ReactiveFX_C
{
public:

protected:
    void FindPawnForLoopId(int32_t& const LoopInstanceId, AFortPlayerPawn*& Pawn) const; // 0x288a61c (Index: 0x0, Flags: Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void GetJamPlayspace(AJamInLobbyPlayspace*& JamInLobbyPlayspace) const; // 0x288a61c (Index: 0x1, Flags: Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual bool GetPlayerVFXSpawnProps(const FJamEvent_JamLoopStarted Event, USceneComponent*& OutComponentToFollow, FVector& OutSpawnLocation, FRotator& OutSpawnRotation, FVector& OutSpawnScale, UNiagaraSystem*& OutNiagaraSystemToSpawn) const; // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UBP_JamInLobbyPlayspaceComponent_ReactiveFX_C) == 0x288, "Size mismatch for UBP_JamInLobbyPlayspaceComponent_ReactiveFX_C");

// Size: 0x181 (Inherited: 0x388, Single: 0xfffffdf9)
class UBP_Jam_Controller_LoopOptions_C : public UJamControllerComponent_LoopOptions
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x138 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer Playlist_Context_Tags; // 0x140 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer Jam_Emote_First_Playlist_Tags; // 0x160 (Size: 0x20, Type: StructProperty)
    bool bJamEmotesPostLockerInJamPlaylists; // 0x180 (Size: 0x1, Type: BoolProperty)

public:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    bool IsJamPlaylist() const; // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)

protected:
    virtual bool ShouldAddJamCategoriesBeforeLocker() const; // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UBP_Jam_Controller_LoopOptions_C) == 0x181, "Size mismatch for UBP_Jam_Controller_LoopOptions_C");
static_assert(offsetof(UBP_Jam_Controller_LoopOptions_C, UberGraphFrame) == 0x138, "Offset mismatch for UBP_Jam_Controller_LoopOptions_C::UberGraphFrame");
static_assert(offsetof(UBP_Jam_Controller_LoopOptions_C, Playlist_Context_Tags) == 0x140, "Offset mismatch for UBP_Jam_Controller_LoopOptions_C::Playlist_Context_Tags");
static_assert(offsetof(UBP_Jam_Controller_LoopOptions_C, Jam_Emote_First_Playlist_Tags) == 0x160, "Offset mismatch for UBP_Jam_Controller_LoopOptions_C::Jam_Emote_First_Playlist_Tags");
static_assert(offsetof(UBP_Jam_Controller_LoopOptions_C, bJamEmotesPostLockerInJamPlaylists) == 0x180, "Offset mismatch for UBP_Jam_Controller_LoopOptions_C::bJamEmotesPostLockerInJamPlaylists");

// Size: 0x180 (Inherited: 0x490, Single: 0xfffffcf0)
class UBP_JamAnalytics_C : public UJamAnalytics
{
public:
};

static_assert(sizeof(UBP_JamAnalytics_C) == 0x180, "Size mismatch for UBP_JamAnalytics_C");

// Size: 0x120 (Inherited: 0x428, Single: 0xfffffcf8)
class UBP_PlayerStateCustomFeedMessages_C : public UFortPlayerStateComponent_CustomFeedMessage
{
public:
};

static_assert(sizeof(UBP_PlayerStateCustomFeedMessages_C) == 0x120, "Size mismatch for UBP_PlayerStateCustomFeedMessages_C");

// Size: 0x288 (Inherited: 0x4d8, Single: 0xfffffdb0)
class UBP_JamPlayspaceComponent_ReactiveFX_C : public UJamPlayspaceComponent_ReactiveFX
{
public:
};

static_assert(sizeof(UBP_JamPlayspaceComponent_ReactiveFX_C) == 0x288, "Size mismatch for UBP_JamPlayspaceComponent_ReactiveFX_C");

// Size: 0x108 (Inherited: 0x410, Single: 0xfffffcf8)
class UBP_FortGameStateComponent_JamInLobbyPlayspaceManager_C : public UFortGameStateComponent_JamInLobbyPlayspaceManager
{
public:
};

static_assert(sizeof(UBP_FortGameStateComponent_JamInLobbyPlayspaceManager_C) == 0x108, "Size mismatch for UBP_FortGameStateComponent_JamInLobbyPlayspaceManager_C");

