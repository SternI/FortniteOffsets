/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Creative
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"
#include "Building.h"
#include "Abilities.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "AIModule.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCreative_CommonDeviceFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:

public:
    static void Update_Team_Color(UFortMinigameLogicComponent*& Minigame_Logic, UPrimitiveComponent*& Mesh, int32_t& Team, UObject*& __WorldContext); // 0x288a61c (Index: 0x0, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void Wrapping_Modulo(int32_t& A, int32_t& B, UObject*& __WorldContext, int32_t& Out); // 0x288a61c (Index: 0x1, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void Refresh_Team_Change_Binding(UFortMinigameLogicComponent*& Minigame_Logic, bool& Unbind, const FDelegate Event, UObject*& __WorldContext); // 0x288a61c (Index: 0x2, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    static void Simple_Apply_Gameplay_Effect_to_Actor(UClass*& GameplayEffect, AActor*& Actor, UObject*& __WorldContext); // 0x288a61c (Index: 0x3, Flags: Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    static void TeamToIndex(char& Team, UObject*& __WorldContext, int32_t& Index); // 0x288a61c (Index: 0x4, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void ActorCanTrigger(AActor*& Actor_To_Check, UPrimitiveComponent*& Overlap_Component, UObject*& __WorldContext, bool& CanTrigger, AController*& Controller); // 0x288a61c (Index: 0x5, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void Animate_Float_Curve(double& Delta_Time, double Current_Time, UCurveFloat*& FCurve, double& Animation_Time, bool& Invert_Time, UObject*& __WorldContext, double& Value, bool& bIsComplete); // 0x288a61c (Index: 0x6, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    static void Apply_Vent_Recently_Launched_Tag_or_Abort_Launch(AActor*& Actor_To_Launch, AActor*& Vent_Actor, UObject*& __WorldContext, bool& ShouldLaunch); // 0x288a61c (Index: 0x7, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    static void AwardScore(AActor*& Actor, int32_t& Score, TEnumAsByte<EAwardScoreType>& Type, AController*& Controller, UFortMinigameLogicComponent*& Minigame_Logic, FGameplayTagContainer& const TargetTags, UObject*& __WorldContext); // 0x288a61c (Index: 0x8, Flags: Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    static void Bool_to_Bool_with_Unset(bool& Input, UObject*& __WorldContext, TEnumAsByte<EBoolWithUnset>& Output); // 0x288a61c (Index: 0x9, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void Current_Material_Matches_Base(UStaticMeshComponent*& Static_Mesh_Component, int32_t& MatID, UObject*& __WorldContext, bool& Material_Matches, UMaterialInterface*& Base_Material); // 0x288a61c (Index: 0xa, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    static void GenerateUniqueMaterialName(UPrimitiveComponent*& PrimitiveComponent, FString& Name, UObject*& __WorldContext, FName& UniqueName); // 0x288a61c (Index: 0xb, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    static void Get_Driver_or_Pawn_Controller(AActor*& Actor_To_Check, UObject*& __WorldContext, bool& Valid_Controller, AController*& Controller); // 0x288a61c (Index: 0xc, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void Get_Dynamic_Team_Color(AActor*& Actor, AFortMinigame*& Minigame, TEnumAsByte<ECreativeColorSetType>& Color_Type, UObject*& __WorldContext, int32_t& Array_Index); // 0x288a61c (Index: 0xd, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void Get_PlayerState_from_NetID(const FUniqueNetIdRepl Unique_Net_Id, UObject*& __WorldContext, AFortPlayerState*& Fort_Player_State); // 0x288a61c (Index: 0xe, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void Get_Team_Color_For_Team_Option(AActor*& ContextActor, FCreativeTeamOption& TeamOption, UObject*& __WorldContext, FLinearColor& Base_Color, FLinearColor& Light_Color, FLinearColor& Bold_Color); // 0x288a61c (Index: 0xf, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void Get_Team_Color_Index_from_Tag(AActor*& Actor_with_Tag, AFortMinigame*& Minigame, UObject*& __WorldContext, int32_t& Array_Index, TEnumAsByte<ECreativeColorSetType>& Color_Type_Out); // 0x288a61c (Index: 0x10, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static int32_t Get_Team_Color_Index_or_Team_Index(UFortMinigameLogicComponent*& Minigame_Logic, int32_t& Team_Index, UObject*& __WorldContext); // 0x288a61c (Index: 0x11, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void GetMID(UPrimitiveComponent*& Target, UObject*& __WorldContext, UMaterialInstanceDynamic*& Mid); // 0x288a61c (Index: 0x12, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void GetMID_FromMaterial(UPrimitiveComponent*& Target, int32_t& Index, UMaterialInterface*& SourceMaterial, UObject*& __WorldContext, UMaterialInstanceDynamic*& Mid); // 0x288a61c (Index: 0x13, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void Give_Ammo_To_Inventory_Owner(TScriptInterface<Class>& Inventory_Owner, UFortWorldItemDefinition*& World_Item_Definition, int32_t& Pickup_Instigator_Handle, const TMap<int32_t, TSoftObjectPtr<UFortWorldItemDefinition*>> AmmoToGiveItemDefinitionMap, int32_t& DefaultAmmoToGive, bool& SpareWeaponAmmo_Override, int32_t& SpareWeaponAmmo, UObject*& __WorldContext); // 0x288a61c (Index: 0x14, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    static void IndexToTeam(int32_t& Index, UObject*& __WorldContext, char& Team); // 0x288a61c (Index: 0x15, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void Is_Matching_Channel_ID(UFortGameplayMessageComponentBase*& A, UFortGameplayMessageComponentBase*& B, UObject*& __WorldContext, bool& Matches); // 0x288a61c (Index: 0x16, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void IsActivatedOnPhase(EFortMinigameState& State, int32_t& PhaseIndex, AActor*& const Actor, UObject*& __WorldContext, bool& Enabled); // 0x288a61c (Index: 0x17, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void IsEnabledPhaseMatch(EFortMinigameState& State, int32_t& PhaseIndex, AActor*& const Actor, UObject*& __WorldContext, bool& Enabled); // 0x288a61c (Index: 0x18, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void IsInEditor(UObject*& __WorldContext, bool& TRUE); // 0x288a61c (Index: 0x19, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void IsInPlayMode(const AActor* Actor, UObject*& __WorldContext, bool& Play_Mode); // 0x288a61c (Index: 0x1a, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void IsLocalPawn(AActor*& Actor, UObject*& __WorldContext, bool& IsLocalPawn); // 0x288a61c (Index: 0x1b, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void IsLogicInPlayMode(const UFortMinigameLogicComponent* Logic, UObject*& __WorldContext, bool& Play_Mode); // 0x288a61c (Index: 0x1c, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void IsOnUnpublishedIsland(AActor*& const Actor, UObject*& __WorldContext, bool& Edit_Mode); // 0x288a61c (Index: 0x1d, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void IsValidTeam(int32_t& Team_to_Check, AActor*& const Actor_To_Check, UObject*& __WorldContext, bool& Valid); // 0x288a61c (Index: 0x1e, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void MatchesTagReturnMatch(FGameplayTagContainer& TagContainer, FGameplayTag& Tag, bool& ExactMatch, UObject*& __WorldContext, bool& TagFound, FGameplayTag& FirstMatchingTag); // 0x288a61c (Index: 0x1f, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void Reattach_or_Create_MID(UPrimitiveComponent*& Mesh, UMaterialInstanceDynamic* Target_MID, int32_t& MatID, UObject*& __WorldContext); // 0x288a61c (Index: 0x20, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UCreative_CommonDeviceFunctionLibrary_C) == 0x28, "Size mismatch for UCreative_CommonDeviceFunctionLibrary_C");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCreative_CommonAIFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:

public:
    static void CheckAITeamValidity(AActor*& Actor, FCreativeTeamOption& SelectedTeam, bool& InvertTeamSelection, UObject*& __WorldContext, bool& IsValidController, AFortAIPawn*& FortAIPawn, AAIController*& AIController); // 0x288a61c (Index: 0x0, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    static void GetParticipantControllerFromActor(AActor*& Actor, bool& Include_Guard_NPC, UObject*& __WorldContext, AController*& Controller); // 0x288a61c (Index: 0x1, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void GetPatrolPathGroupFromUserOption(int32_t& UserOption, UObject*& __WorldContext, EFortCreativePatrolPathGroup& PatrolPathGroup); // 0x288a61c (Index: 0x2, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void IsGuardActor(AActor*& Actor, UObject*& __WorldContext, bool& IsGuard); // 0x288a61c (Index: 0x3, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    static void IsPlaylistSupportNavMeshOnDemand(UObject*& WorldObjRef, UObject*& __WorldContext, bool& NavMeshOnDemandEnabled); // 0x288a61c (Index: 0x4, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UCreative_CommonAIFunctionLibrary_C) == 0x28, "Size mismatch for UCreative_CommonAIFunctionLibrary_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_LaunchedByVent_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_LaunchedByVent_C) == 0xa68, "Size mismatch for UGE_LaunchedByVent_C");

// Size: 0x270 (Inherited: 0x320, Single: 0xffffff50)
class UCreativeTeamColors_C : public USceneComponent
{
public:
    TArray<FLinearColor> TeamLightColors; // 0x240 (Size: 0x10, Type: ArrayProperty)
    TArray<FLinearColor> TeamSelectorColors; // 0x250 (Size: 0x10, Type: ArrayProperty)
    TArray<FLinearColor> TeamBoldColors; // 0x260 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCreativeTeamColors_C) == 0x270, "Size mismatch for UCreativeTeamColors_C");
static_assert(offsetof(UCreativeTeamColors_C, TeamLightColors) == 0x240, "Offset mismatch for UCreativeTeamColors_C::TeamLightColors");
static_assert(offsetof(UCreativeTeamColors_C, TeamSelectorColors) == 0x250, "Offset mismatch for UCreativeTeamColors_C::TeamSelectorColors");
static_assert(offsetof(UCreativeTeamColors_C, TeamBoldColors) == 0x260, "Offset mismatch for UCreativeTeamColors_C::TeamBoldColors");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FPawnHighlight
{
    float Priority_28_E2E1B5344846E187B9C11B863A7F0698; // 0x0 (Size: 0x4, Type: FloatProperty)
    FLinearColor Inner_21_4CC2801147EA190DE16F59B34F36853E; // 0x4 (Size: 0x10, Type: StructProperty)
    FLinearColor Outer_22_5A1D7D0543D303E8B54B66A7F7BD2E2E; // 0x14 (Size: 0x10, Type: StructProperty)
    float FresnelBrightness_23_52B0F96447FF640F47DF2895B0602E92; // 0x24 (Size: 0x4, Type: FloatProperty)
    float FresnelExponent_24_B427CF0C441AA37ED49833BF7579DE6D; // 0x28 (Size: 0x4, Type: FloatProperty)
    float UsesPulse_25_E29229F64E540F0617E4C4987AD77605; // 0x2c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FPawnHighlight) == 0x30, "Size mismatch for FPawnHighlight");
static_assert(offsetof(FPawnHighlight, Priority_28_E2E1B5344846E187B9C11B863A7F0698) == 0x0, "Offset mismatch for FPawnHighlight::Priority_28_E2E1B5344846E187B9C11B863A7F0698");
static_assert(offsetof(FPawnHighlight, Inner_21_4CC2801147EA190DE16F59B34F36853E) == 0x4, "Offset mismatch for FPawnHighlight::Inner_21_4CC2801147EA190DE16F59B34F36853E");
static_assert(offsetof(FPawnHighlight, Outer_22_5A1D7D0543D303E8B54B66A7F7BD2E2E) == 0x14, "Offset mismatch for FPawnHighlight::Outer_22_5A1D7D0543D303E8B54B66A7F7BD2E2E");
static_assert(offsetof(FPawnHighlight, FresnelBrightness_23_52B0F96447FF640F47DF2895B0602E92) == 0x24, "Offset mismatch for FPawnHighlight::FresnelBrightness_23_52B0F96447FF640F47DF2895B0602E92");
static_assert(offsetof(FPawnHighlight, FresnelExponent_24_B427CF0C441AA37ED49833BF7579DE6D) == 0x28, "Offset mismatch for FPawnHighlight::FresnelExponent_24_B427CF0C441AA37ED49833BF7579DE6D");
static_assert(offsetof(FPawnHighlight, UsesPulse_25_E29229F64E540F0617E4C4987AD77605) == 0x2c, "Offset mismatch for FPawnHighlight::UsesPulse_25_E29229F64E540F0617E4C4987AD77605");

// Size: 0xe10 (Inherited: 0x30e0, Single: 0xffffdd30)
class AMilitaryBase_Door_01_C : public AParent_BuildingWall_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xd80 (Size: 0x8, Type: StructProperty)
    UBoxComponent* DoorSlideOverlapVolume; // 0xd88 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* DoorStaticMesh1; // 0xd90 (Size: 0x8, Type: ObjectProperty)
    float Timeline_0_EmissiveColorLerp_75727DFA4F9CA24A009D23ADC967876F; // 0xd98 (Size: 0x4, Type: FloatProperty)
    float Timeline_0_SlideAnimation_75727DFA4F9CA24A009D23ADC967876F; // 0xd9c (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_75727DFA4F9CA24A009D23ADC967876F; // 0xda0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_da1[0x7]; // 0xda1 (Size: 0x7, Type: PaddingProperty)
    UTimelineComponent* Timeline_0; // 0xda8 (Size: 0x8, Type: ObjectProperty)
    int32_t NumberOfPawnsWithinVolume; // 0xdb0 (Size: 0x4, Type: IntProperty)
    bool DoorOpen; // 0xdb4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_db5[0x3]; // 0xdb5 (Size: 0x3, Type: PaddingProperty)
    UMaterialInstanceDynamic* DoorMID; // 0xdb8 (Size: 0x8, Type: ObjectProperty)
    FLinearColor DefaultDoorEmissiveValue; // 0xdc0 (Size: 0x10, Type: StructProperty)
    FLinearColor ActiveDoorEmissiveValue; // 0xdd0 (Size: 0x10, Type: StructProperty)
    UMaterialInterface* DoorBaseMaterial; // 0xde0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* Door_Source_Materials; // 0xde8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SlidingDoorClose_Sound; // 0xdf0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SlidingDoorOpen_Sound; // 0xdf8 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnDoorOpened[0x10]; // 0xe00 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void Open(AController*& ControllerInstigator, bool& bRequestFastOpen); // 0x288a61c (Index: 0x4, Flags: BlueprintAuthorityOnly|Event|Public|BlueprintEvent)
    virtual void OnUnLocked(); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
    virtual void OnLocked(); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintEvent)
    void OnDoorOpened__DelegateSignature(); // 0x288a61c (Index: 0x8, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual bool IsOpen() const; // 0x288a61c (Index: 0x9, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
    void GetDoorMID(); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual TArray<UPrimitiveComponent*> GetComponentToLock(); // 0x288a61c (Index: 0xb, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void Close(AController*& ControllerInstigator); // 0x288a61c (Index: 0xe, Flags: BlueprintAuthorityOnly|Event|Public|BlueprintEvent)
};

static_assert(sizeof(AMilitaryBase_Door_01_C) == 0xe10, "Size mismatch for AMilitaryBase_Door_01_C");
static_assert(offsetof(AMilitaryBase_Door_01_C, UberGraphFrame) == 0xd80, "Offset mismatch for AMilitaryBase_Door_01_C::UberGraphFrame");
static_assert(offsetof(AMilitaryBase_Door_01_C, DoorSlideOverlapVolume) == 0xd88, "Offset mismatch for AMilitaryBase_Door_01_C::DoorSlideOverlapVolume");
static_assert(offsetof(AMilitaryBase_Door_01_C, DoorStaticMesh1) == 0xd90, "Offset mismatch for AMilitaryBase_Door_01_C::DoorStaticMesh1");
static_assert(offsetof(AMilitaryBase_Door_01_C, Timeline_0_EmissiveColorLerp_75727DFA4F9CA24A009D23ADC967876F) == 0xd98, "Offset mismatch for AMilitaryBase_Door_01_C::Timeline_0_EmissiveColorLerp_75727DFA4F9CA24A009D23ADC967876F");
static_assert(offsetof(AMilitaryBase_Door_01_C, Timeline_0_SlideAnimation_75727DFA4F9CA24A009D23ADC967876F) == 0xd9c, "Offset mismatch for AMilitaryBase_Door_01_C::Timeline_0_SlideAnimation_75727DFA4F9CA24A009D23ADC967876F");
static_assert(offsetof(AMilitaryBase_Door_01_C, Timeline_0__Direction_75727DFA4F9CA24A009D23ADC967876F) == 0xda0, "Offset mismatch for AMilitaryBase_Door_01_C::Timeline_0__Direction_75727DFA4F9CA24A009D23ADC967876F");
static_assert(offsetof(AMilitaryBase_Door_01_C, Timeline_0) == 0xda8, "Offset mismatch for AMilitaryBase_Door_01_C::Timeline_0");
static_assert(offsetof(AMilitaryBase_Door_01_C, NumberOfPawnsWithinVolume) == 0xdb0, "Offset mismatch for AMilitaryBase_Door_01_C::NumberOfPawnsWithinVolume");
static_assert(offsetof(AMilitaryBase_Door_01_C, DoorOpen) == 0xdb4, "Offset mismatch for AMilitaryBase_Door_01_C::DoorOpen");
static_assert(offsetof(AMilitaryBase_Door_01_C, DoorMID) == 0xdb8, "Offset mismatch for AMilitaryBase_Door_01_C::DoorMID");
static_assert(offsetof(AMilitaryBase_Door_01_C, DefaultDoorEmissiveValue) == 0xdc0, "Offset mismatch for AMilitaryBase_Door_01_C::DefaultDoorEmissiveValue");
static_assert(offsetof(AMilitaryBase_Door_01_C, ActiveDoorEmissiveValue) == 0xdd0, "Offset mismatch for AMilitaryBase_Door_01_C::ActiveDoorEmissiveValue");
static_assert(offsetof(AMilitaryBase_Door_01_C, DoorBaseMaterial) == 0xde0, "Offset mismatch for AMilitaryBase_Door_01_C::DoorBaseMaterial");
static_assert(offsetof(AMilitaryBase_Door_01_C, Door_Source_Materials) == 0xde8, "Offset mismatch for AMilitaryBase_Door_01_C::Door_Source_Materials");
static_assert(offsetof(AMilitaryBase_Door_01_C, SlidingDoorClose_Sound) == 0xdf0, "Offset mismatch for AMilitaryBase_Door_01_C::SlidingDoorClose_Sound");
static_assert(offsetof(AMilitaryBase_Door_01_C, SlidingDoorOpen_Sound) == 0xdf8, "Offset mismatch for AMilitaryBase_Door_01_C::SlidingDoorOpen_Sound");
static_assert(offsetof(AMilitaryBase_Door_01_C, OnDoorOpened) == 0xe00, "Offset mismatch for AMilitaryBase_Door_01_C::OnDoorOpened");

// Size: 0xb60 (Inherited: 0x1a4d, Single: 0xfffff113)
class UGAT_Creative_TriggeredAbility_C : public UGAT_TriggeredAbility_C
{
public:
    uint8_t Pad_b45[0x3]; // 0xb45 (Size: 0x3, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0xb48 (Size: 0x8, Type: StructProperty)
    TArray<FName> OverriddenPropertyNames; // 0xb50 (Size: 0x10, Type: ArrayProperty)

protected:
    void IsPropertyOverridden(FName& PropertyName, bool& bResult) const; // 0x288a61c (Index: 0x0, Flags: Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0x4, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGAT_Creative_TriggeredAbility_C) == 0xb60, "Size mismatch for UGAT_Creative_TriggeredAbility_C");
static_assert(offsetof(UGAT_Creative_TriggeredAbility_C, UberGraphFrame) == 0xb48, "Offset mismatch for UGAT_Creative_TriggeredAbility_C::UberGraphFrame");
static_assert(offsetof(UGAT_Creative_TriggeredAbility_C, OverriddenPropertyNames) == 0xb50, "Offset mismatch for UGAT_Creative_TriggeredAbility_C::OverriddenPropertyNames");

// Size: 0xbb4 (Inherited: 0x311d, Single: 0xffffda97)
class UGA_Creative_OnKillSiphon_C : public UGAT_Creative_TriggeredAbility_Pawn_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb70 (Size: 0x8, Type: StructProperty)
    AFortGameStateAthena* GameState; // 0xb78 (Size: 0x8, Type: ObjectProperty)
    bool IsCreativeOrPlayground; // 0xb80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b81[0x7]; // 0xb81 (Size: 0x7, Type: PaddingProperty)
    UClass* GE_HealPlayer; // 0xb88 (Size: 0x8, Type: ClassProperty)
    bool bShouldConvertExcessHealthToShields; // 0xb90 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b91[0x7]; // 0xb91 (Size: 0x7, Type: PaddingProperty)
    UClass* ShieldGE; // 0xb98 (Size: 0x8, Type: ClassProperty)
    FGameplayTag ConsumedCue; // 0xba0 (Size: 0x4, Type: StructProperty)
    bool bDebugBypasLocalMapEnable; // 0xba4 (Size: 0x1, Type: BoolProperty)
    bool bAttemptHealthRestore; // 0xba5 (Size: 0x1, Type: BoolProperty)
    bool bAttemptMatsRestore; // 0xba6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ba7[0x1]; // 0xba7 (Size: 0x1, Type: PaddingProperty)
    FName NameGrantWood; // 0xba8 (Size: 0x4, Type: NameProperty)
    FName NameGrantStone; // 0xbac (Size: 0x4, Type: NameProperty)
    FName NameGrantMetal; // 0xbb0 (Size: 0x4, Type: NameProperty)

public:
    void SetupRestoreModes(bool& ShouldContinue); // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void RestoreHealth(bool& Success, double& InitialHealAmount, double& ActualAppliedHeal, double& ExcessHealing); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void GiveResourcesToPlayer(bool& bShouldGrant, int32_t& GiveAmount, TEnumAsByte<EFortResourceType>& GiveType, bool& Success); // 0x288a61c (Index: 0x4, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void DetermineHealthDelta(double& HealingAmount, double& MaxHealth, double& CurrentHealth, double& HealthDelta, double& ExcessHealh); // 0x288a61c (Index: 0x6, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void CalculateResources(TEnumAsByte<EFortResourceType>& ResourceGrantType, bool& bSuccess, int32_t& ResourceToGive, TEnumAsByte<EFortResourceType>& ResourceType); // 0x288a61c (Index: 0x7, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void AttemptMats(); // 0x288a61c (Index: 0x8, Flags: Public|BlueprintCallable|BlueprintEvent)
    void AttemptHeal(); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)
    void AddShields(bool& bShouldConvertExcessHealthToShields, double& ShieldToAdd, bool& bAddedShields, double& ShieldAdded); // 0x288a61c (Index: 0xa, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    virtual bool K2_ShouldAbilityRespondToEvent(FGameplayAbilityActorInfo& ActorInfo, FGameplayEventData& Payload) const; // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0x3, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGA_Creative_OnKillSiphon_C) == 0xbb4, "Size mismatch for UGA_Creative_OnKillSiphon_C");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, UberGraphFrame) == 0xb70, "Offset mismatch for UGA_Creative_OnKillSiphon_C::UberGraphFrame");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, GameState) == 0xb78, "Offset mismatch for UGA_Creative_OnKillSiphon_C::GameState");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, IsCreativeOrPlayground) == 0xb80, "Offset mismatch for UGA_Creative_OnKillSiphon_C::IsCreativeOrPlayground");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, GE_HealPlayer) == 0xb88, "Offset mismatch for UGA_Creative_OnKillSiphon_C::GE_HealPlayer");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, bShouldConvertExcessHealthToShields) == 0xb90, "Offset mismatch for UGA_Creative_OnKillSiphon_C::bShouldConvertExcessHealthToShields");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, ShieldGE) == 0xb98, "Offset mismatch for UGA_Creative_OnKillSiphon_C::ShieldGE");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, ConsumedCue) == 0xba0, "Offset mismatch for UGA_Creative_OnKillSiphon_C::ConsumedCue");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, bDebugBypasLocalMapEnable) == 0xba4, "Offset mismatch for UGA_Creative_OnKillSiphon_C::bDebugBypasLocalMapEnable");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, bAttemptHealthRestore) == 0xba5, "Offset mismatch for UGA_Creative_OnKillSiphon_C::bAttemptHealthRestore");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, bAttemptMatsRestore) == 0xba6, "Offset mismatch for UGA_Creative_OnKillSiphon_C::bAttemptMatsRestore");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, NameGrantWood) == 0xba8, "Offset mismatch for UGA_Creative_OnKillSiphon_C::NameGrantWood");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, NameGrantStone) == 0xbac, "Offset mismatch for UGA_Creative_OnKillSiphon_C::NameGrantStone");
static_assert(offsetof(UGA_Creative_OnKillSiphon_C, NameGrantMetal) == 0xbb0, "Offset mismatch for UGA_Creative_OnKillSiphon_C::NameGrantMetal");

// Size: 0xb70 (Inherited: 0x25ad, Single: 0xffffe5c3)
class UGAT_Creative_TriggeredAbility_Pawn_C : public UGAT_Creative_TriggeredAbility_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb60 (Size: 0x8, Type: StructProperty)
    AFortPawn* AbilityOwner; // 0xb68 (Size: 0x8, Type: ObjectProperty)

public:
    void SetupPawnActorAbility(AFortPawn*& FortPawn); // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGAT_Creative_TriggeredAbility_Pawn_C) == 0xb70, "Size mismatch for UGAT_Creative_TriggeredAbility_Pawn_C");
static_assert(offsetof(UGAT_Creative_TriggeredAbility_Pawn_C, UberGraphFrame) == 0xb60, "Offset mismatch for UGAT_Creative_TriggeredAbility_Pawn_C::UberGraphFrame");
static_assert(offsetof(UGAT_Creative_TriggeredAbility_Pawn_C, AbilityOwner) == 0xb68, "Offset mismatch for UGAT_Creative_TriggeredAbility_Pawn_C::AbilityOwner");

