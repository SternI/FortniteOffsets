/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Blueprint
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "SparksCoreCosmeticsRuntime.h"

// Size: 0x108 (Inherited: 0x358, Single: 0xfffffdb0)
class UBP_CosmeticsOverride_Figure_Frontend_C : public USparksCosmeticOverrides
{
public:
};

static_assert(sizeof(UBP_CosmeticsOverride_Figure_Frontend_C) == 0x108, "Size mismatch for UBP_CosmeticsOverride_Figure_Frontend_C");

