/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CaretakerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteAI.h"
#include "AIModule.h"
#include "NavigationSystem.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x640 (Inherited: 0x15b8, Single: 0xfffff088)
class AFortAthenaCaretakerAIController : public AAthenaAIController
{
public:

public:
    void DebugUpdate(float& UpdateInterval); // 0xa35c334 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void OnMovementModeChanged(ACharacter*& CharacterOwner, TEnumAsByte<EMovementMode>& PreviousMovementMode, char& PreviousCustomMode); // 0x1133a9ec (Index: 0x1, Flags: Final|Native|Public)
};

static_assert(sizeof(AFortAthenaCaretakerAIController) == 0x640, "Size mismatch for AFortAthenaCaretakerAIController");

// Size: 0x160 (Inherited: 0x2b8, Single: 0xfffffea8)
class UFortBTTask_CaretakerMoveTo : public UBTTask_MoveTo
{
public:
    FBlackboardKeySelector FocalPointWhileMoving; // 0x130 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<EPathObstacleAction> PathObstacleAction; // 0x158 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_159[0x3]; // 0x159 (Size: 0x3, Type: PaddingProperty)
    uint8_t bEnableSlowdownAtGoal : 1; // 0x15c:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bMoveDirectlyTowards : 1; // 0x15c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bStopAtGoal : 1; // 0x15c:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bFinishMoveOnOverlap : 1; // 0x15c:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15d[0x3]; // 0x15d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTTask_CaretakerMoveTo) == 0x160, "Size mismatch for UFortBTTask_CaretakerMoveTo");
static_assert(offsetof(UFortBTTask_CaretakerMoveTo, FocalPointWhileMoving) == 0x130, "Offset mismatch for UFortBTTask_CaretakerMoveTo::FocalPointWhileMoving");
static_assert(offsetof(UFortBTTask_CaretakerMoveTo, PathObstacleAction) == 0x158, "Offset mismatch for UFortBTTask_CaretakerMoveTo::PathObstacleAction");
static_assert(offsetof(UFortBTTask_CaretakerMoveTo, bEnableSlowdownAtGoal) == 0x15c, "Offset mismatch for UFortBTTask_CaretakerMoveTo::bEnableSlowdownAtGoal");
static_assert(offsetof(UFortBTTask_CaretakerMoveTo, bMoveDirectlyTowards) == 0x15c, "Offset mismatch for UFortBTTask_CaretakerMoveTo::bMoveDirectlyTowards");
static_assert(offsetof(UFortBTTask_CaretakerMoveTo, bStopAtGoal) == 0x15c, "Offset mismatch for UFortBTTask_CaretakerMoveTo::bStopAtGoal");
static_assert(offsetof(UFortBTTask_CaretakerMoveTo, bFinishMoveOnOverlap) == 0x15c, "Offset mismatch for UFortBTTask_CaretakerMoveTo::bFinishMoveOnOverlap");

// Size: 0x60 (Inherited: 0xb8, Single: 0xffffffa8)
class UFortNavigationFilter_Caretaker : public UFortNavigationFilter
{
public:
    float EndPointAcceptableRadius; // 0x48 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    UClass* EndPointFilterClass; // 0x50 (Size: 0x8, Type: ClassProperty)
    uint8_t bEndPointReachTestIncludesAgentRadius : 1; // 0x58:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bEndPointReachTestIncludesGoalRadius : 1; // 0x58:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortNavigationFilter_Caretaker) == 0x60, "Size mismatch for UFortNavigationFilter_Caretaker");
static_assert(offsetof(UFortNavigationFilter_Caretaker, EndPointAcceptableRadius) == 0x48, "Offset mismatch for UFortNavigationFilter_Caretaker::EndPointAcceptableRadius");
static_assert(offsetof(UFortNavigationFilter_Caretaker, EndPointFilterClass) == 0x50, "Offset mismatch for UFortNavigationFilter_Caretaker::EndPointFilterClass");
static_assert(offsetof(UFortNavigationFilter_Caretaker, bEndPointReachTestIncludesAgentRadius) == 0x58, "Offset mismatch for UFortNavigationFilter_Caretaker::bEndPointReachTestIncludesAgentRadius");
static_assert(offsetof(UFortNavigationFilter_Caretaker, bEndPointReachTestIncludesGoalRadius) == 0x58, "Offset mismatch for UFortNavigationFilter_Caretaker::bEndPointReachTestIncludesGoalRadius");

// Size: 0x198 (Inherited: 0x500, Single: 0xfffffc98)
class UFortAITask_CaretakerMove : public UFortAbilityTask_MoveAI
{
public:
};

static_assert(sizeof(UFortAITask_CaretakerMove) == 0x198, "Size mismatch for UFortAITask_CaretakerMove");

// Size: 0x660 (Inherited: 0x14b8, Single: 0xfffff1a8)
class UFortAIAnimInstance_Caretaker : public UFortAIAnimInstance
{
public:
    bool bIsMoving; // 0x608 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_609[0x3]; // 0x609 (Size: 0x3, Type: PaddingProperty)
    float WalkPlayRate; // 0x60c (Size: 0x4, Type: FloatProperty)
    float AimOffsetCurve; // 0x610 (Size: 0x4, Type: FloatProperty)
    bool bFootPhase_StopLeftPlant; // 0x614 (Size: 0x1, Type: BoolProperty)
    bool bFootPhase_StopLeftPass; // 0x615 (Size: 0x1, Type: BoolProperty)
    bool bFootPhase_StopRightPlant; // 0x616 (Size: 0x1, Type: BoolProperty)
    bool bFootPhase_StopRightPass; // 0x617 (Size: 0x1, Type: BoolProperty)
    float BreathingCurve; // 0x618 (Size: 0x4, Type: FloatProperty)
    float MovingTreshold; // 0x61c (Size: 0x4, Type: FloatProperty)
    FName CurveName_AimOffsetCurve; // 0x620 (Size: 0x4, Type: NameProperty)
    FName CurveName_FootPhase; // 0x624 (Size: 0x4, Type: NameProperty)
    FName CurveName_BreathingCurve; // 0x628 (Size: 0x4, Type: NameProperty)
    FName SocketName_FX_Chest; // 0x62c (Size: 0x4, Type: NameProperty)
    FName ParamName_ChestSocketLocation; // 0x630 (Size: 0x4, Type: NameProperty)
    FName ParamName_ChestSocketVector; // 0x634 (Size: 0x4, Type: NameProperty)
    float FirstFootPhaseMin; // 0x638 (Size: 0x4, Type: FloatProperty)
    float SecondFootPhaseMin; // 0x63c (Size: 0x4, Type: FloatProperty)
    float ThirdFootPhaseMin; // 0x640 (Size: 0x4, Type: FloatProperty)
    float FourthFootPhaseMin; // 0x644 (Size: 0x4, Type: FloatProperty)
    float FootPhaseMax; // 0x648 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_64c[0x4]; // 0x64c (Size: 0x4, Type: PaddingProperty)
    UFortAnimWorldStriderComponent* WorldStriderComponent; // 0x650 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_658[0x8]; // 0x658 (Size: 0x8, Type: PaddingProperty)

public:
    float GetStartAnimPosition() const; // 0x1133a94c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetWalkPlayRateValue() const; // 0x1133a978 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetWalkSpeedWarpingValue() const; // 0x1133a998 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFortAnimWorldStriderComponent* GetWorldStriderComponent() const; // 0x1133a9c4 (Index: 0x3, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void SetDelayedMaterialParameters(); // 0x1133b17c (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortAIAnimInstance_Caretaker) == 0x660, "Size mismatch for UFortAIAnimInstance_Caretaker");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, bIsMoving) == 0x608, "Offset mismatch for UFortAIAnimInstance_Caretaker::bIsMoving");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, WalkPlayRate) == 0x60c, "Offset mismatch for UFortAIAnimInstance_Caretaker::WalkPlayRate");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, AimOffsetCurve) == 0x610, "Offset mismatch for UFortAIAnimInstance_Caretaker::AimOffsetCurve");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, bFootPhase_StopLeftPlant) == 0x614, "Offset mismatch for UFortAIAnimInstance_Caretaker::bFootPhase_StopLeftPlant");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, bFootPhase_StopLeftPass) == 0x615, "Offset mismatch for UFortAIAnimInstance_Caretaker::bFootPhase_StopLeftPass");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, bFootPhase_StopRightPlant) == 0x616, "Offset mismatch for UFortAIAnimInstance_Caretaker::bFootPhase_StopRightPlant");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, bFootPhase_StopRightPass) == 0x617, "Offset mismatch for UFortAIAnimInstance_Caretaker::bFootPhase_StopRightPass");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, BreathingCurve) == 0x618, "Offset mismatch for UFortAIAnimInstance_Caretaker::BreathingCurve");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, MovingTreshold) == 0x61c, "Offset mismatch for UFortAIAnimInstance_Caretaker::MovingTreshold");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, CurveName_AimOffsetCurve) == 0x620, "Offset mismatch for UFortAIAnimInstance_Caretaker::CurveName_AimOffsetCurve");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, CurveName_FootPhase) == 0x624, "Offset mismatch for UFortAIAnimInstance_Caretaker::CurveName_FootPhase");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, CurveName_BreathingCurve) == 0x628, "Offset mismatch for UFortAIAnimInstance_Caretaker::CurveName_BreathingCurve");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, SocketName_FX_Chest) == 0x62c, "Offset mismatch for UFortAIAnimInstance_Caretaker::SocketName_FX_Chest");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, ParamName_ChestSocketLocation) == 0x630, "Offset mismatch for UFortAIAnimInstance_Caretaker::ParamName_ChestSocketLocation");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, ParamName_ChestSocketVector) == 0x634, "Offset mismatch for UFortAIAnimInstance_Caretaker::ParamName_ChestSocketVector");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, FirstFootPhaseMin) == 0x638, "Offset mismatch for UFortAIAnimInstance_Caretaker::FirstFootPhaseMin");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, SecondFootPhaseMin) == 0x63c, "Offset mismatch for UFortAIAnimInstance_Caretaker::SecondFootPhaseMin");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, ThirdFootPhaseMin) == 0x640, "Offset mismatch for UFortAIAnimInstance_Caretaker::ThirdFootPhaseMin");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, FourthFootPhaseMin) == 0x644, "Offset mismatch for UFortAIAnimInstance_Caretaker::FourthFootPhaseMin");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, FootPhaseMax) == 0x648, "Offset mismatch for UFortAIAnimInstance_Caretaker::FootPhaseMax");
static_assert(offsetof(UFortAIAnimInstance_Caretaker, WorldStriderComponent) == 0x650, "Offset mismatch for UFortAIAnimInstance_Caretaker::WorldStriderComponent");

