/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AssetTags
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x30 (Inherited: 0xb8, Single: 0xffffff78)
class UAssetTagsSubsystem : public UEngineSubsystem
{
public:

public:
    bool CollectionExists(FName& const Name); // 0x12e211f8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FAssetData> GetAssetsInCollection(FName& const Name); // 0x12e21320 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FName> GetCollections(); // 0x12e21460 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FName> GetCollectionsContainingAsset(FName& const AssetPathName); // 0x12e214a0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FName> GetCollectionsContainingAssetData(const FAssetData AssetData); // 0x12e21894 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    TArray<FName> GetCollectionsContainingAssetPtr(UObject*& const AssetPtr); // 0x12e21aa0 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FName> K2_GetCollectionsContainingAsset(const FSoftObjectPath AssetPath); // 0x12e21e20 (Index: 0x6, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAssetTagsSubsystem) == 0x30, "Size mismatch for UAssetTagsSubsystem");

