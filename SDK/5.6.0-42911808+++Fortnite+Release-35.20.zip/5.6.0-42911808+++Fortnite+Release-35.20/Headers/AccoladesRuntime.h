/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AccoladesRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "GameFeatures.h"
#include "Engine.h"
#include "ModularGameplay.h"
#include "NetCore.h"
#include "GameplayTags.h"

// Size: 0x168 (Inherited: 0x170, Single: 0xfffffff8)
class UPFWAccoladeCollection_Container : public UPersistenceFrameworkContainer
{
public:
};

static_assert(sizeof(UPFWAccoladeCollection_Container) == 0x168, "Size mismatch for UPFWAccoladeCollection_Container");

// Size: 0xe0 (Inherited: 0x108, Single: 0xffffffd8)
class UPFWAccoladeCollection_Module : public UPersistenceFrameworkModule
{
public:
};

static_assert(sizeof(UPFWAccoladeCollection_Module) == 0xe0, "Size mismatch for UPFWAccoladeCollection_Module");

// Size: 0xa0 (Inherited: 0x168, Single: 0xffffff38)
class UPFWAccoladeCollection_Trigger : public UPersistenceFrameworkSaveTrigger_Manual
{
public:
};

static_assert(sizeof(UPFWAccoladeCollection_Trigger) == 0xa0, "Size mismatch for UPFWAccoladeCollection_Trigger");

// Size: 0x120 (Inherited: 0x138, Single: 0xffffffe8)
class UPFWAccoladeCollection_FilteredListContainer : public UPersistenceFrameworkFilteredListContainer
{
public:
};

static_assert(sizeof(UPFWAccoladeCollection_FilteredListContainer) == 0x120, "Size mismatch for UPFWAccoladeCollection_FilteredListContainer");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UFortAccoladeCollectionFeatureCollector : public UObject
{
public:
};

static_assert(sizeof(UFortAccoladeCollectionFeatureCollector) == 0x38, "Size mismatch for UFortAccoladeCollectionFeatureCollector");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UGameFeatureAction_AddAccoladeTables : public UGameFeatureAction
{
public:
    TArray<TSoftObjectPtr<UDataTable*>> AccoladeTables; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGameFeatureAction_AddAccoladeTables) == 0x38, "Size mismatch for UGameFeatureAction_AddAccoladeTables");
static_assert(offsetof(UGameFeatureAction_AddAccoladeTables, AccoladeTables) == 0x28, "Offset mismatch for UGameFeatureAction_AddAccoladeTables::AccoladeTables");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UFortCheatManager_Accolades : public UChildCheatManager
{
public:

private:
    void ResetAccoladeData(); // 0x554e3c4 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Private)
    void TriggerAccolade(FString& AccoladeName); // 0xa63baa0 (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Private)
};

static_assert(sizeof(UFortCheatManager_Accolades) == 0x28, "Size mismatch for UFortCheatManager_Accolades");

// Size: 0x338 (Inherited: 0x310, Single: 0x28)
class UFortControllerComponent_AccoladeCollection : public UFortControllerComponent
{
public:
    uint8_t Pad_c0[0xd0]; // 0xc0 (Size: 0xd0, Type: PaddingProperty)
    FName PinnedAccoladeName; // 0x190 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_194[0x74]; // 0x194 (Size: 0x74, Type: PaddingProperty)
    FPersistenceFrameworkSaveControl SaveControl; // 0x208 (Size: 0x10, Type: StructProperty)
    FFortAccoladeCollectionDataArray AccoladeCollectionDataArray; // 0x218 (Size: 0x120, Type: StructProperty)

private:
    virtual void ClientNotifyRestored(EPersistenceFrameworkResult& const Result); // 0xceb03c8 (Index: 0x0, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    virtual void ClientResetAccoladeData(); // 0xcc5a53c (Index: 0x1, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    void HandleOnCurrentPlaylistLoaded(FName& PlaylistName, const FGameplayTagContainer PlaylistContextTags); // 0xfe63378 (Index: 0x2, Flags: Final|Native|Private|HasOutParms)
    void HandlePlayerProfileInitialized(); // 0xfe63768 (Index: 0x3, Flags: Final|Native|Private)
    void OnEndMatchForPlayer(UFortControllerComponent_EndMatchPersistence*& EndMatchPersistence); // 0x6023a08 (Index: 0x4, Flags: Final|Native|Private)
    void OnRep_PinnedAccoladeName(FName& OldPinnedAccoladeName); // 0xfe637b4 (Index: 0x5, Flags: Final|Native|Private)
    virtual void ServerMarkAccoladesAsSeen(TArray<FName>& const AccoladeNames); // 0xd6f3548 (Index: 0x6, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
    virtual void ServerPinAccolade(FName& const AccoladeName); // 0xfe638dc (Index: 0x7, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
};

static_assert(sizeof(UFortControllerComponent_AccoladeCollection) == 0x338, "Size mismatch for UFortControllerComponent_AccoladeCollection");
static_assert(offsetof(UFortControllerComponent_AccoladeCollection, PinnedAccoladeName) == 0x190, "Offset mismatch for UFortControllerComponent_AccoladeCollection::PinnedAccoladeName");
static_assert(offsetof(UFortControllerComponent_AccoladeCollection, SaveControl) == 0x208, "Offset mismatch for UFortControllerComponent_AccoladeCollection::SaveControl");
static_assert(offsetof(UFortControllerComponent_AccoladeCollection, AccoladeCollectionDataArray) == 0x218, "Offset mismatch for UFortControllerComponent_AccoladeCollection::AccoladeCollectionDataArray");

// Size: 0x538 (Inherited: 0x310, Single: 0x228)
class UFortControllerComponent_Accolades : public UFortControllerComponent
{
public:
    uint8_t Pad_c0[0x1e8]; // 0xc0 (Size: 0x1e8, Type: PaddingProperty)
    FFortUpdatedTrackedAccoladeDataArray UpdatedTrackedAccoladeDataArray; // 0x2a8 (Size: 0x120, Type: StructProperty)
    FFortCompletedAccoladeDataArray CompletedAccoladeDataArray; // 0x3c8 (Size: 0x120, Type: StructProperty)
    uint8_t Pad_4e8[0x50]; // 0x4e8 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UFortControllerComponent_Accolades) == 0x538, "Size mismatch for UFortControllerComponent_Accolades");
static_assert(offsetof(UFortControllerComponent_Accolades, UpdatedTrackedAccoladeDataArray) == 0x2a8, "Offset mismatch for UFortControllerComponent_Accolades::UpdatedTrackedAccoladeDataArray");
static_assert(offsetof(UFortControllerComponent_Accolades, CompletedAccoladeDataArray) == 0x3c8, "Offset mismatch for UFortControllerComponent_Accolades::CompletedAccoladeDataArray");

// Size: 0xc8 (Inherited: 0x308, Single: 0xfffffdc0)
class UFortGameStateComponent_AccoladeCollection : public UFortGameStateComponent
{
public:
};

static_assert(sizeof(UFortGameStateComponent_AccoladeCollection) == 0xc8, "Size mismatch for UFortGameStateComponent_AccoladeCollection");

// Size: 0x1c0 (Inherited: 0x308, Single: 0xfffffeb8)
class UFortGameStateComponent_Accolades : public UFortGameStateComponent
{
public:
};

static_assert(sizeof(UFortGameStateComponent_Accolades) == 0x1c0, "Size mismatch for UFortGameStateComponent_Accolades");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData
{
    FString AccoladeName; // 0x0 (Size: 0x10, Type: StrProperty)
    uint32_t AccoladeCount; // 0x10 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData) == 0x18, "Size mismatch for FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData");
static_assert(offsetof(FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData, AccoladeName) == 0x0, "Offset mismatch for FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData::AccoladeName");
static_assert(offsetof(FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData, AccoladeCount) == 0x10, "Offset mismatch for FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData::AccoladeCount");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData
{
    FString AccoladeName; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData) == 0x10, "Size mismatch for FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData");
static_assert(offsetof(FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData, AccoladeName) == 0x0, "Offset mismatch for FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData::AccoladeName");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData
{
    TArray<FString> AccoladeNames; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData) == 0x10, "Size mismatch for FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData");
static_assert(offsetof(FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData, AccoladeNames) == 0x0, "Offset mismatch for FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData::AccoladeNames");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FPFWAccoladeCollection_PersistentInfo
{
    TArray<FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData> AccoladeCollection_AchievedAccolades; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData AccoladeCollection_PinnedAccolade; // 0x10 (Size: 0x10, Type: StructProperty)
    FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData AccoladeCollection_UnacknowledgedAccolades; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FPFWAccoladeCollection_PersistentInfo) == 0x30, "Size mismatch for FPFWAccoladeCollection_PersistentInfo");
static_assert(offsetof(FPFWAccoladeCollection_PersistentInfo, AccoladeCollection_AchievedAccolades) == 0x0, "Offset mismatch for FPFWAccoladeCollection_PersistentInfo::AccoladeCollection_AchievedAccolades");
static_assert(offsetof(FPFWAccoladeCollection_PersistentInfo, AccoladeCollection_PinnedAccolade) == 0x10, "Offset mismatch for FPFWAccoladeCollection_PersistentInfo::AccoladeCollection_PinnedAccolade");
static_assert(offsetof(FPFWAccoladeCollection_PersistentInfo, AccoladeCollection_UnacknowledgedAccolades) == 0x20, "Offset mismatch for FPFWAccoladeCollection_PersistentInfo::AccoladeCollection_UnacknowledgedAccolades");

// Size: 0x18 (Inherited: 0xc, Single: 0xc)
struct FFortAccoladeCollectionDataItem : FFastArraySerializerItem
{
    FName AccoladeName; // 0xc (Size: 0x4, Type: NameProperty)
    FFortAccoladeCollectionData CollectionData; // 0x10 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FFortAccoladeCollectionDataItem) == 0x18, "Size mismatch for FFortAccoladeCollectionDataItem");
static_assert(offsetof(FFortAccoladeCollectionDataItem, AccoladeName) == 0xc, "Offset mismatch for FFortAccoladeCollectionDataItem::AccoladeName");
static_assert(offsetof(FFortAccoladeCollectionDataItem, CollectionData) == 0x10, "Offset mismatch for FFortAccoladeCollectionDataItem::CollectionData");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFortAccoladeCollectionData
{
    uint32_t AchievedCount; // 0x0 (Size: 0x4, Type: UInt32Property)
    bool bAcknowledged; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FFortAccoladeCollectionData) == 0x8, "Size mismatch for FFortAccoladeCollectionData");
static_assert(offsetof(FFortAccoladeCollectionData, AchievedCount) == 0x0, "Offset mismatch for FFortAccoladeCollectionData::AchievedCount");
static_assert(offsetof(FFortAccoladeCollectionData, bAcknowledged) == 0x4, "Offset mismatch for FFortAccoladeCollectionData::bAcknowledged");

// Size: 0x120 (Inherited: 0x108, Single: 0x18)
struct FFortAccoladeCollectionDataArray : FFastArraySerializer
{
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
    TArray<FFortAccoladeCollectionDataItem> AccoladeCollectionData; // 0x110 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortAccoladeCollectionDataArray) == 0x120, "Size mismatch for FFortAccoladeCollectionDataArray");
static_assert(offsetof(FFortAccoladeCollectionDataArray, AccoladeCollectionData) == 0x110, "Offset mismatch for FFortAccoladeCollectionDataArray::AccoladeCollectionData");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FFortAccoladeSessionData
{
};

static_assert(sizeof(FFortAccoladeSessionData) == 0xc, "Size mismatch for FFortAccoladeSessionData");

// Size: 0x14 (Inherited: 0xc, Single: 0x8)
struct FFortUpdatedTrackedAccoladeData : FFastArraySerializerItem
{
    FName AccoladeRowName; // 0xc (Size: 0x4, Type: NameProperty)
    uint32_t Count; // 0x10 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FFortUpdatedTrackedAccoladeData) == 0x14, "Size mismatch for FFortUpdatedTrackedAccoladeData");
static_assert(offsetof(FFortUpdatedTrackedAccoladeData, AccoladeRowName) == 0xc, "Offset mismatch for FFortUpdatedTrackedAccoladeData::AccoladeRowName");
static_assert(offsetof(FFortUpdatedTrackedAccoladeData, Count) == 0x10, "Offset mismatch for FFortUpdatedTrackedAccoladeData::Count");

// Size: 0x120 (Inherited: 0x108, Single: 0x18)
struct FFortUpdatedTrackedAccoladeDataArray : FFastArraySerializer
{
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
    TArray<FFortUpdatedTrackedAccoladeData> UpdatedTrackedAccolades; // 0x110 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortUpdatedTrackedAccoladeDataArray) == 0x120, "Size mismatch for FFortUpdatedTrackedAccoladeDataArray");
static_assert(offsetof(FFortUpdatedTrackedAccoladeDataArray, UpdatedTrackedAccolades) == 0x110, "Offset mismatch for FFortUpdatedTrackedAccoladeDataArray::UpdatedTrackedAccolades");

// Size: 0x18 (Inherited: 0xc, Single: 0xc)
struct FFortCompletedAccoladeData : FFastArraySerializerItem
{
    FName AccoladeRowName; // 0xc (Size: 0x4, Type: NameProperty)
    uint32_t XPAwarded; // 0x10 (Size: 0x4, Type: UInt32Property)
    uint8_t AccoladeType; // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FFortCompletedAccoladeData) == 0x18, "Size mismatch for FFortCompletedAccoladeData");
static_assert(offsetof(FFortCompletedAccoladeData, AccoladeRowName) == 0xc, "Offset mismatch for FFortCompletedAccoladeData::AccoladeRowName");
static_assert(offsetof(FFortCompletedAccoladeData, XPAwarded) == 0x10, "Offset mismatch for FFortCompletedAccoladeData::XPAwarded");
static_assert(offsetof(FFortCompletedAccoladeData, AccoladeType) == 0x14, "Offset mismatch for FFortCompletedAccoladeData::AccoladeType");

// Size: 0x120 (Inherited: 0x108, Single: 0x18)
struct FFortCompletedAccoladeDataArray : FFastArraySerializer
{
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
    TArray<FFortCompletedAccoladeData> CompletedAccolades; // 0x110 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortCompletedAccoladeDataArray) == 0x120, "Size mismatch for FFortCompletedAccoladeDataArray");
static_assert(offsetof(FFortCompletedAccoladeDataArray, CompletedAccolades) == 0x110, "Offset mismatch for FFortCompletedAccoladeDataArray::CompletedAccolades");

// Size: 0x110 (Inherited: 0x8, Single: 0x108)
struct FFortAccoladesTableRow : FTableRowBase
{
    FInstancedStruct EventConditional; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FInstancedStruct> EventRewards; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> OneTimeEventRewards; // 0x28 (Size: 0x10, Type: ArrayProperty)
    FText DisplayName; // 0x38 (Size: 0x10, Type: TextProperty)
    FText DisplayDescription; // 0x48 (Size: 0x10, Type: TextProperty)
    int32_t DisplayOrder; // 0x58 (Size: 0x4, Type: IntProperty)
    uint8_t AccoladeType; // 0x5c (Size: 0x1, Type: EnumProperty)
    uint8_t Priority; // 0x5d (Size: 0x1, Type: EnumProperty)
    uint8_t AccoladeTier; // 0x5e (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5f[0x1]; // 0x5f (Size: 0x1, Type: PaddingProperty)
    TSoftObjectPtr<USoundCue*> AwardedSoundCue; // 0x60 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D*> PreviewImage; // 0x80 (Size: 0x20, Type: SoftObjectProperty)
    int32_t MaxMatchCount; // 0xa0 (Size: 0x4, Type: IntProperty)
    int32_t MaxPlayerCount; // 0xa4 (Size: 0x4, Type: IntProperty)
    FGameplayTagContainer Tags; // 0xa8 (Size: 0x20, Type: StructProperty)
    FGameplayTagQuery ProductCompatibilityQuery; // 0xc8 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FFortAccoladesTableRow) == 0x110, "Size mismatch for FFortAccoladesTableRow");
static_assert(offsetof(FFortAccoladesTableRow, EventConditional) == 0x8, "Offset mismatch for FFortAccoladesTableRow::EventConditional");
static_assert(offsetof(FFortAccoladesTableRow, EventRewards) == 0x18, "Offset mismatch for FFortAccoladesTableRow::EventRewards");
static_assert(offsetof(FFortAccoladesTableRow, OneTimeEventRewards) == 0x28, "Offset mismatch for FFortAccoladesTableRow::OneTimeEventRewards");
static_assert(offsetof(FFortAccoladesTableRow, DisplayName) == 0x38, "Offset mismatch for FFortAccoladesTableRow::DisplayName");
static_assert(offsetof(FFortAccoladesTableRow, DisplayDescription) == 0x48, "Offset mismatch for FFortAccoladesTableRow::DisplayDescription");
static_assert(offsetof(FFortAccoladesTableRow, DisplayOrder) == 0x58, "Offset mismatch for FFortAccoladesTableRow::DisplayOrder");
static_assert(offsetof(FFortAccoladesTableRow, AccoladeType) == 0x5c, "Offset mismatch for FFortAccoladesTableRow::AccoladeType");
static_assert(offsetof(FFortAccoladesTableRow, Priority) == 0x5d, "Offset mismatch for FFortAccoladesTableRow::Priority");
static_assert(offsetof(FFortAccoladesTableRow, AccoladeTier) == 0x5e, "Offset mismatch for FFortAccoladesTableRow::AccoladeTier");
static_assert(offsetof(FFortAccoladesTableRow, AwardedSoundCue) == 0x60, "Offset mismatch for FFortAccoladesTableRow::AwardedSoundCue");
static_assert(offsetof(FFortAccoladesTableRow, PreviewImage) == 0x80, "Offset mismatch for FFortAccoladesTableRow::PreviewImage");
static_assert(offsetof(FFortAccoladesTableRow, MaxMatchCount) == 0xa0, "Offset mismatch for FFortAccoladesTableRow::MaxMatchCount");
static_assert(offsetof(FFortAccoladesTableRow, MaxPlayerCount) == 0xa4, "Offset mismatch for FFortAccoladesTableRow::MaxPlayerCount");
static_assert(offsetof(FFortAccoladesTableRow, Tags) == 0xa8, "Offset mismatch for FFortAccoladesTableRow::Tags");
static_assert(offsetof(FFortAccoladesTableRow, ProductCompatibilityQuery) == 0xc8, "Offset mismatch for FFortAccoladesTableRow::ProductCompatibilityQuery");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FFortTriggeredAccoladeData
{
};

static_assert(sizeof(FFortTriggeredAccoladeData) == 0x70, "Size mismatch for FFortTriggeredAccoladeData");

