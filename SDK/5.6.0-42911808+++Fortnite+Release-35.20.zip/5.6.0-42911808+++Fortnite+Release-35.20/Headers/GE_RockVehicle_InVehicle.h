/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GE_RockVehicle_InVehicle
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayAbilities.h"

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_RockVehicle_InVehicle_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_RockVehicle_InVehicle_C) == 0xa68, "Size mismatch for UGE_RockVehicle_InVehicle_C");

