/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioMotorSim
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x118 (Inherited: 0xe0, Single: 0x38)
class UAudioMotorModelComponent : public UActorComponent
{
public:
    TArray<FMotorSimEntry> SimComponents; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<TScriptInterface<Class>> AudioComponents; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_d8[0x40]; // 0xd8 (Size: 0x40, Type: PaddingProperty)

public:
    void AddMotorAudioComponent(TScriptInterface<Class>& InComponent); // 0xfea88b8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void AddMotorSimComponent(TScriptInterface<Class>& InComponent, int32_t& const SortOrder); // 0x34eddbc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void ConfigureMotorSimComponents(const TArray<FInstancedStruct> InConfigData); // 0xfea8e54 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    FAudioMotorSimInputContext GetCachedInputData() const; // 0xfea8f30 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetGear() const; // 0xfea8f70 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetRpm() const; // 0x56ae47c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FAudioMotorSimRuntimeContext GetRuntimeInfo() const; // 0xfea8f88 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RemoveMotorAudioComponent(TScriptInterface<Class>& InComponent); // 0xfea8fac (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveMotorSimComponent(TScriptInterface<Class>& InComponent); // 0xfea92a4 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void Reset(); // 0x43388fc (Index: 0x9, Flags: Native|Public|BlueprintCallable)
    void StartOutput(); // 0x270d644 (Index: 0xa, Flags: Native|Public|BlueprintCallable)
    void StopOutput(); // 0x3abd220 (Index: 0xb, Flags: Native|Public|BlueprintCallable)
    void Update(const FAudioMotorSimInputContext Input); // 0xfea96c0 (Index: 0xc, Flags: Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAudioMotorModelComponent) == 0x118, "Size mismatch for UAudioMotorModelComponent");
static_assert(offsetof(UAudioMotorModelComponent, SimComponents) == 0xb8, "Offset mismatch for UAudioMotorModelComponent::SimComponents");
static_assert(offsetof(UAudioMotorModelComponent, AudioComponents) == 0xc8, "Offset mismatch for UAudioMotorModelComponent::AudioComponents");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioMotorSim : public UInterface
{
public:

public:
    void ConfigMotorSim(const FInstancedStruct InConfigData); // 0xfea8d74 (Index: 0x0, Flags: Native|Public|HasOutParms|BlueprintCallable)
    bool GetEnabled(); // 0x427a380 (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    void Reset(); // 0x538b694 (Index: 0x2, Flags: Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioMotorSim) == 0x28, "Size mismatch for UAudioMotorSim");

// Size: 0xc8 (Inherited: 0xe0, Single: 0xffffffe8)
class UAudioMotorSimComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    bool bEnabled; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0x7]; // 0xc1 (Size: 0x7, Type: PaddingProperty)

public:
    virtual void BP_Reset(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    virtual bool BP_Update(FAudioMotorSimInputContext Input, FAudioMotorSimRuntimeContext RuntimeInfo); // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintEvent)
    void SetEnabled(bool& bNewEnabled); // 0xfea9594 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioMotorSimComponent) == 0xc8, "Size mismatch for UAudioMotorSimComponent");
static_assert(offsetof(UAudioMotorSimComponent, bEnabled) == 0xc0, "Offset mismatch for UAudioMotorSimComponent::bEnabled");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioMotorSimOutput : public UInterface
{
public:
};

static_assert(sizeof(UAudioMotorSimOutput) == 0x28, "Size mismatch for UAudioMotorSimOutput");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FAudioMotorSimConfigData
{
};

static_assert(sizeof(FAudioMotorSimConfigData) == 0x1, "Size mismatch for FAudioMotorSimConfigData");

// Size: 0x2c (Inherited: 0x0, Single: 0x2c)
struct FAudioMotorSimInputContext
{
    float DeltaTime; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Speed; // 0x4 (Size: 0x4, Type: FloatProperty)
    float ForwardSpeed; // 0x8 (Size: 0x4, Type: FloatProperty)
    float SideSpeed; // 0xc (Size: 0x4, Type: FloatProperty)
    float UpSpeed; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Throttle; // 0x14 (Size: 0x4, Type: FloatProperty)
    float Brake; // 0x18 (Size: 0x4, Type: FloatProperty)
    float SurfaceFrictionModifier; // 0x1c (Size: 0x4, Type: FloatProperty)
    float MotorFrictionModifier; // 0x20 (Size: 0x4, Type: FloatProperty)
    float Boost; // 0x24 (Size: 0x4, Type: FloatProperty)
    bool bDriving; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bGrounded; // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bCanShift; // 0x2a (Size: 0x1, Type: BoolProperty)
    bool bClutchEngaged; // 0x2b (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FAudioMotorSimInputContext) == 0x2c, "Size mismatch for FAudioMotorSimInputContext");
static_assert(offsetof(FAudioMotorSimInputContext, DeltaTime) == 0x0, "Offset mismatch for FAudioMotorSimInputContext::DeltaTime");
static_assert(offsetof(FAudioMotorSimInputContext, Speed) == 0x4, "Offset mismatch for FAudioMotorSimInputContext::Speed");
static_assert(offsetof(FAudioMotorSimInputContext, ForwardSpeed) == 0x8, "Offset mismatch for FAudioMotorSimInputContext::ForwardSpeed");
static_assert(offsetof(FAudioMotorSimInputContext, SideSpeed) == 0xc, "Offset mismatch for FAudioMotorSimInputContext::SideSpeed");
static_assert(offsetof(FAudioMotorSimInputContext, UpSpeed) == 0x10, "Offset mismatch for FAudioMotorSimInputContext::UpSpeed");
static_assert(offsetof(FAudioMotorSimInputContext, Throttle) == 0x14, "Offset mismatch for FAudioMotorSimInputContext::Throttle");
static_assert(offsetof(FAudioMotorSimInputContext, Brake) == 0x18, "Offset mismatch for FAudioMotorSimInputContext::Brake");
static_assert(offsetof(FAudioMotorSimInputContext, SurfaceFrictionModifier) == 0x1c, "Offset mismatch for FAudioMotorSimInputContext::SurfaceFrictionModifier");
static_assert(offsetof(FAudioMotorSimInputContext, MotorFrictionModifier) == 0x20, "Offset mismatch for FAudioMotorSimInputContext::MotorFrictionModifier");
static_assert(offsetof(FAudioMotorSimInputContext, Boost) == 0x24, "Offset mismatch for FAudioMotorSimInputContext::Boost");
static_assert(offsetof(FAudioMotorSimInputContext, bDriving) == 0x28, "Offset mismatch for FAudioMotorSimInputContext::bDriving");
static_assert(offsetof(FAudioMotorSimInputContext, bGrounded) == 0x29, "Offset mismatch for FAudioMotorSimInputContext::bGrounded");
static_assert(offsetof(FAudioMotorSimInputContext, bCanShift) == 0x2a, "Offset mismatch for FAudioMotorSimInputContext::bCanShift");
static_assert(offsetof(FAudioMotorSimInputContext, bClutchEngaged) == 0x2b, "Offset mismatch for FAudioMotorSimInputContext::bClutchEngaged");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FAudioMotorSimRuntimeContext
{
    bool bShifting; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t Gear; // 0x4 (Size: 0x4, Type: IntProperty)
    float RPM; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Volume; // 0xc (Size: 0x4, Type: FloatProperty)
    float pitch; // 0x10 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FAudioMotorSimRuntimeContext) == 0x14, "Size mismatch for FAudioMotorSimRuntimeContext");
static_assert(offsetof(FAudioMotorSimRuntimeContext, bShifting) == 0x0, "Offset mismatch for FAudioMotorSimRuntimeContext::bShifting");
static_assert(offsetof(FAudioMotorSimRuntimeContext, Gear) == 0x4, "Offset mismatch for FAudioMotorSimRuntimeContext::Gear");
static_assert(offsetof(FAudioMotorSimRuntimeContext, RPM) == 0x8, "Offset mismatch for FAudioMotorSimRuntimeContext::RPM");
static_assert(offsetof(FAudioMotorSimRuntimeContext, Volume) == 0xc, "Offset mismatch for FAudioMotorSimRuntimeContext::Volume");
static_assert(offsetof(FAudioMotorSimRuntimeContext, pitch) == 0x10, "Offset mismatch for FAudioMotorSimRuntimeContext::pitch");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FMotorSimEntry
{
    TScriptInterface<Class> Sim; // 0x0 (Size: 0x10, Type: InterfaceProperty)
    int32_t SortOrder; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FMotorSimEntry) == 0x18, "Size mismatch for FMotorSimEntry");
static_assert(offsetof(FMotorSimEntry, Sim) == 0x0, "Offset mismatch for FMotorSimEntry::Sim");
static_assert(offsetof(FMotorSimEntry, SortOrder) == 0x10, "Offset mismatch for FMotorSimEntry::SortOrder");

