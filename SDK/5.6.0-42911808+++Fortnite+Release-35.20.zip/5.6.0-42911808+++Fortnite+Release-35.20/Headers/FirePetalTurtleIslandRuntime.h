/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FirePetalTurtleIslandRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"

// Size: 0x2e0 (Inherited: 0x2d0, Single: 0x10)
class AFirePetalTurtleHeadActor : public AActor
{
public:
    FScalableFloat DistanceToAlwaysTickPose; // 0x2a8 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_2d0[0x10]; // 0x2d0 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(AFirePetalTurtleHeadActor) == 0x2e0, "Size mismatch for AFirePetalTurtleHeadActor");
static_assert(offsetof(AFirePetalTurtleHeadActor, DistanceToAlwaysTickPose) == 0x2a8, "Offset mismatch for AFirePetalTurtleHeadActor::DistanceToAlwaysTickPose");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UTurtleHeadActorInterface : public UInterface
{
public:

public:
    virtual void GetDataForTurtleHeadAnimBP(bool& LookAtPawnValid, FVector& LookAtPawnLocation, FVector& MeshLocation); // 0x114188f0 (Index: 0x0, Flags: Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent)
};

static_assert(sizeof(UTurtleHeadActorInterface) == 0x28, "Size mismatch for UTurtleHeadActorInterface");

// Size: 0x490 (Inherited: 0x408, Single: 0x88)
class UTurtleIslandHeadCreatureAnimInstance : public UAnimInstance
{
public:
    bool bShould_Blink; // 0x3d8 (Size: 0x1, Type: BoolProperty)
    bool bIsChewing; // 0x3d9 (Size: 0x1, Type: BoolProperty)
    bool bIsChewingAlt; // 0x3da (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3db[0x5]; // 0x3db (Size: 0x5, Type: PaddingProperty)
    double ChewingAlphaInterp; // 0x3e0 (Size: 0x8, Type: DoubleProperty)
    double RandomChewingAlpha; // 0x3e8 (Size: 0x8, Type: DoubleProperty)
    int32_t BlinkPicker; // 0x3f0 (Size: 0x4, Type: IntProperty)
    bool bIsForceBlink; // 0x3f4 (Size: 0x1, Type: BoolProperty)
    bool bIsStillChewingCheck; // 0x3f5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3f6[0x2]; // 0x3f6 (Size: 0x2, Type: PaddingProperty)
    double LookVertical; // 0x3f8 (Size: 0x8, Type: DoubleProperty)
    double LookHorizontal; // 0x400 (Size: 0x8, Type: DoubleProperty)
    float LookHorizontalHead; // 0x408 (Size: 0x4, Type: FloatProperty)
    float LookVerticalHead; // 0x40c (Size: 0x4, Type: FloatProperty)
    FVector PawnLookAtWorldPosition; // 0x410 (Size: 0x18, Type: StructProperty)
    bool bIsValidLookAtTarget; // 0x428 (Size: 0x1, Type: BoolProperty)
    bool bIsLookAway; // 0x429 (Size: 0x1, Type: BoolProperty)
    bool bEyeGateOpen; // 0x42a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_42b[0x65]; // 0x42b (Size: 0x65, Type: PaddingProperty)

public:
    void SetRandomLookNumbers(); // 0x11418b0c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UTurtleIslandHeadCreatureAnimInstance) == 0x490, "Size mismatch for UTurtleIslandHeadCreatureAnimInstance");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, bShould_Blink) == 0x3d8, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::bShould_Blink");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, bIsChewing) == 0x3d9, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::bIsChewing");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, bIsChewingAlt) == 0x3da, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::bIsChewingAlt");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, ChewingAlphaInterp) == 0x3e0, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::ChewingAlphaInterp");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, RandomChewingAlpha) == 0x3e8, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::RandomChewingAlpha");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, BlinkPicker) == 0x3f0, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::BlinkPicker");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, bIsForceBlink) == 0x3f4, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::bIsForceBlink");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, bIsStillChewingCheck) == 0x3f5, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::bIsStillChewingCheck");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, LookVertical) == 0x3f8, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::LookVertical");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, LookHorizontal) == 0x400, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::LookHorizontal");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, LookHorizontalHead) == 0x408, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::LookHorizontalHead");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, LookVerticalHead) == 0x40c, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::LookVerticalHead");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, PawnLookAtWorldPosition) == 0x410, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::PawnLookAtWorldPosition");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, bIsValidLookAtTarget) == 0x428, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::bIsValidLookAtTarget");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, bIsLookAway) == 0x429, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::bIsLookAway");
static_assert(offsetof(UTurtleIslandHeadCreatureAnimInstance, bEyeGateOpen) == 0x42a, "Offset mismatch for UTurtleIslandHeadCreatureAnimInstance::bEyeGateOpen");

