/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricMetasoundDataTypes
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "HarmonixDsp.h"

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UFabricMetasoundDrumPlayerSampleBankAsset : public UDataAsset
{
public:
    FText SampleKitName; // 0x30 (Size: 0x10, Type: TextProperty)
    TArray<FFabricMetasoundDrumPlayerSampleData> Samples; // 0x40 (Size: 0x10, Type: ArrayProperty)

public:
    FText GetSampleKitName() const; // 0x1118afb8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FText> GetSampleLabels() const; // 0x1118affc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFabricMetasoundDrumPlayerSampleBankAsset) == 0x50, "Size mismatch for UFabricMetasoundDrumPlayerSampleBankAsset");
static_assert(offsetof(UFabricMetasoundDrumPlayerSampleBankAsset, SampleKitName) == 0x30, "Offset mismatch for UFabricMetasoundDrumPlayerSampleBankAsset::SampleKitName");
static_assert(offsetof(UFabricMetasoundDrumPlayerSampleBankAsset, Samples) == 0x40, "Offset mismatch for UFabricMetasoundDrumPlayerSampleBankAsset::Samples");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UFabricMetasoundDrumPlayerDataAsset : public UDataAsset
{
public:
    TArray<TSoftObjectPtr<UFabricMetasoundDrumPlayerSampleBankAsset*>> SampleBanks; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFabricMetasoundDrumPlayerDataAsset) == 0x40, "Size mismatch for UFabricMetasoundDrumPlayerDataAsset");
static_assert(offsetof(UFabricMetasoundDrumPlayerDataAsset, SampleBanks) == 0x30, "Offset mismatch for UFabricMetasoundDrumPlayerDataAsset::SampleBanks");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
class UFabricMetasoundInstrumentPlayerDataAsset : public UDataAsset
{
public:
    UFusionPatch* Patch; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFabricMetasoundInstrumentPlayerDataAsset) == 0x38, "Size mismatch for UFabricMetasoundInstrumentPlayerDataAsset");
static_assert(offsetof(UFabricMetasoundInstrumentPlayerDataAsset, Patch) == 0x30, "Offset mismatch for UFabricMetasoundInstrumentPlayerDataAsset::Patch");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UFabricMetasoundInstrumentPlayerDataAssetList : public UDataAsset
{
public:
    TArray<TSoftObjectPtr<UFabricMetasoundInstrumentPlayerDataAsset*>> InstrumentPlayerData; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFabricMetasoundInstrumentPlayerDataAssetList) == 0x40, "Size mismatch for UFabricMetasoundInstrumentPlayerDataAssetList");
static_assert(offsetof(UFabricMetasoundInstrumentPlayerDataAssetList, InstrumentPlayerData) == 0x30, "Offset mismatch for UFabricMetasoundInstrumentPlayerDataAssetList::InstrumentPlayerData");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UFabricMetaSoundUserOption : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FFabricUserOption FabricUserOption; // 0x30 (Size: 0x38, Type: StructProperty)
    uint8_t Pad_68[0x10]; // 0x68 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFabricMetaSoundUserOption) == 0x78, "Size mismatch for UFabricMetaSoundUserOption");
static_assert(offsetof(UFabricMetaSoundUserOption, FabricUserOption) == 0x30, "Offset mismatch for UFabricMetaSoundUserOption::FabricUserOption");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFabricMetasoundDrumPlayerSampleData
{
    FText SampleLabel; // 0x0 (Size: 0x10, Type: TextProperty)
    USoundWave* WaveAsset; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFabricMetasoundDrumPlayerSampleData) == 0x18, "Size mismatch for FFabricMetasoundDrumPlayerSampleData");
static_assert(offsetof(FFabricMetasoundDrumPlayerSampleData, SampleLabel) == 0x0, "Offset mismatch for FFabricMetasoundDrumPlayerSampleData::SampleLabel");
static_assert(offsetof(FFabricMetasoundDrumPlayerSampleData, WaveAsset) == 0x10, "Offset mismatch for FFabricMetasoundDrumPlayerSampleData::WaveAsset");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FFabricUserOption
{
    uint8_t UserOptionType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t ConversionType; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    float Min; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Max; // 0x8 (Size: 0x4, Type: FloatProperty)
    float ValueCurve; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bInverted; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    TArray<float> NumericLookupTable; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> StringLookupTable; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFabricUserOption) == 0x38, "Size mismatch for FFabricUserOption");
static_assert(offsetof(FFabricUserOption, UserOptionType) == 0x0, "Offset mismatch for FFabricUserOption::UserOptionType");
static_assert(offsetof(FFabricUserOption, ConversionType) == 0x1, "Offset mismatch for FFabricUserOption::ConversionType");
static_assert(offsetof(FFabricUserOption, Min) == 0x4, "Offset mismatch for FFabricUserOption::Min");
static_assert(offsetof(FFabricUserOption, Max) == 0x8, "Offset mismatch for FFabricUserOption::Max");
static_assert(offsetof(FFabricUserOption, ValueCurve) == 0xc, "Offset mismatch for FFabricUserOption::ValueCurve");
static_assert(offsetof(FFabricUserOption, bInverted) == 0x10, "Offset mismatch for FFabricUserOption::bInverted");
static_assert(offsetof(FFabricUserOption, NumericLookupTable) == 0x18, "Offset mismatch for FFabricUserOption::NumericLookupTable");
static_assert(offsetof(FFabricUserOption, StringLookupTable) == 0x28, "Offset mismatch for FFabricUserOption::StringLookupTable");

