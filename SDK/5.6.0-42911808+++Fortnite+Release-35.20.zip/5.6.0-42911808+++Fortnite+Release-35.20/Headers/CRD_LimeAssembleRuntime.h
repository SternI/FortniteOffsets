/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_LimeAssembleRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"

// Size: 0x1d0 (Inherited: 0xe0, Single: 0xf0)
class UAtomGeometryAssemblyComponent : public UActorComponent
{
public:
    uint8_t OnBeginAssembleDelegate[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBeginDisassembleDelegate[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFullyAssembledDelegate[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFullyDisassembledDelegate[0x10]; // 0xe8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnResumeAssembleDelegate[0x10]; // 0xf8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnResumeDisassembleDelegate[0x10]; // 0x108 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStopDelegate[0x10]; // 0x118 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t AssemblyEventFlags; // 0x128 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_129[0x3]; // 0x129 (Size: 0x3, Type: PaddingProperty)
    FAtomAssemblyState AssemblyState; // 0x12c (Size: 0xc, Type: StructProperty)
    FAtomAssemblyCollision AssemblyCollision; // 0x138 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_13a[0x6]; // 0x13a (Size: 0x6, Type: PaddingProperty)
    FAtomAssemblyRange MarshalledRange; // 0x140 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_158[0x78]; // 0x158 (Size: 0x78, Type: PaddingProperty)

public:
    float GetAssemblyProgress() const; // 0x1234309c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsFullyAssembled() const; // 0x123436ac (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsFullyDisassembled() const; // 0x123436c4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSleeping() const; // 0x123436dc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetAssemblyDuration(float& Seconds); // 0x12343fb0 (Index: 0x10, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetDisassembledCollision(EAtomAssemblyCollisionMode& CollisionMode); // 0x123440dc (Index: 0x11, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void StartAssemble(EAtomAssemblyMode& AssemblyMode); // 0x12344a88 (Index: 0x12, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void StartDisassemble(EAtomAssemblyMode& AssemblyMode); // 0x12344bdc (Index: 0x13, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void Stop(); // 0x12344d30 (Index: 0x14, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)

private:
    void OnRep_AssemblyCollision(); // 0x12343700 (Index: 0xc, Flags: Final|Native|Private)
    void OnRep_AssemblyEventFlags(); // 0x12343714 (Index: 0xd, Flags: Final|Native|Private)
    void OnRep_AssemblyState(); // 0x12343728 (Index: 0xe, Flags: Final|Native|Private)
    void OnRep_MarshalledRange(); // 0xb4a87ec (Index: 0xf, Flags: Final|Native|Private)

protected:
    virtual void K2_OnBeginAssemble(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_OnBeginDisassemble(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_OnFullyAssembled(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_OnFullyDisassembled(); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_OnResumeAssemble(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_OnResumeDisassemble(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_OnStop(); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_UpdateVisuals(float& CurrentRate, float& CurrentProgress); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UAtomGeometryAssemblyComponent) == 0x1d0, "Size mismatch for UAtomGeometryAssemblyComponent");
static_assert(offsetof(UAtomGeometryAssemblyComponent, OnBeginAssembleDelegate) == 0xb8, "Offset mismatch for UAtomGeometryAssemblyComponent::OnBeginAssembleDelegate");
static_assert(offsetof(UAtomGeometryAssemblyComponent, OnBeginDisassembleDelegate) == 0xc8, "Offset mismatch for UAtomGeometryAssemblyComponent::OnBeginDisassembleDelegate");
static_assert(offsetof(UAtomGeometryAssemblyComponent, OnFullyAssembledDelegate) == 0xd8, "Offset mismatch for UAtomGeometryAssemblyComponent::OnFullyAssembledDelegate");
static_assert(offsetof(UAtomGeometryAssemblyComponent, OnFullyDisassembledDelegate) == 0xe8, "Offset mismatch for UAtomGeometryAssemblyComponent::OnFullyDisassembledDelegate");
static_assert(offsetof(UAtomGeometryAssemblyComponent, OnResumeAssembleDelegate) == 0xf8, "Offset mismatch for UAtomGeometryAssemblyComponent::OnResumeAssembleDelegate");
static_assert(offsetof(UAtomGeometryAssemblyComponent, OnResumeDisassembleDelegate) == 0x108, "Offset mismatch for UAtomGeometryAssemblyComponent::OnResumeDisassembleDelegate");
static_assert(offsetof(UAtomGeometryAssemblyComponent, OnStopDelegate) == 0x118, "Offset mismatch for UAtomGeometryAssemblyComponent::OnStopDelegate");
static_assert(offsetof(UAtomGeometryAssemblyComponent, AssemblyEventFlags) == 0x128, "Offset mismatch for UAtomGeometryAssemblyComponent::AssemblyEventFlags");
static_assert(offsetof(UAtomGeometryAssemblyComponent, AssemblyState) == 0x12c, "Offset mismatch for UAtomGeometryAssemblyComponent::AssemblyState");
static_assert(offsetof(UAtomGeometryAssemblyComponent, AssemblyCollision) == 0x138, "Offset mismatch for UAtomGeometryAssemblyComponent::AssemblyCollision");
static_assert(offsetof(UAtomGeometryAssemblyComponent, MarshalledRange) == 0x140, "Offset mismatch for UAtomGeometryAssemblyComponent::MarshalledRange");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class ULimeAssembleBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static UAtomGeometryAssemblyComponent* FindOrAddAssemblyComponent(AActor*& Actor, UClass*& ComponentClass); // 0x123428fc (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable)
    static bool HasGeometryCollection(ABuildingActor*& const BuildingActor); // 0x1234356c (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(ULimeAssembleBlueprintLibrary) == 0x28, "Size mismatch for ULimeAssembleBlueprintLibrary");

// Size: 0x160 (Inherited: 0xe0, Single: 0x80)
class ULimeAssembleComponent : public UActorComponent
{
public:
    uint8_t TargetActorAddedDelegate[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t TargetActorRemovedDelegate[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<TSoftObjectPtr<AActor*>> TargetActors; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    AActor* ContextActor; // 0xe8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer IgnoredActorTags; // 0xf0 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_110[0x50]; // 0x110 (Size: 0x50, Type: PaddingProperty)

public:
    bool AddTargetActors(const TArray<AActor*> Actors); // 0x123425f0 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)
    void DestroyContextActor(); // 0x123428c0 (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void GetTargetComponents(TArray<UAtomGeometryAssemblyComponent*>& OutComponents); // 0x123432e0 (Index: 0x2, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)
    void ScanForTargetActors(UPrimitiveComponent*& Collider, TArray<AActor*>& OutActors); // 0x123439c4 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool SetTargetActors(const TArray<AActor*> Actors); // 0x1234421c (Index: 0x4, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)
    AActor* SpawnContextActor(UClass*& ActorClass); // 0x123444c4 (Index: 0x5, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ULimeAssembleComponent) == 0x160, "Size mismatch for ULimeAssembleComponent");
static_assert(offsetof(ULimeAssembleComponent, TargetActorAddedDelegate) == 0xb8, "Offset mismatch for ULimeAssembleComponent::TargetActorAddedDelegate");
static_assert(offsetof(ULimeAssembleComponent, TargetActorRemovedDelegate) == 0xc8, "Offset mismatch for ULimeAssembleComponent::TargetActorRemovedDelegate");
static_assert(offsetof(ULimeAssembleComponent, TargetActors) == 0xd8, "Offset mismatch for ULimeAssembleComponent::TargetActors");
static_assert(offsetof(ULimeAssembleComponent, ContextActor) == 0xe8, "Offset mismatch for ULimeAssembleComponent::ContextActor");
static_assert(offsetof(ULimeAssembleComponent, IgnoredActorTags) == 0xf0, "Offset mismatch for ULimeAssembleComponent::IgnoredActorTags");

// Size: 0x1c0 (Inherited: 0xe0, Single: 0xe0)
class ULimeAssembleContextActorComponent : public UActorComponent
{
public:
    uint8_t TargetActorsChangedDelegate[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t BeginAssembleDelegate[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t BeginDisassembleDelegate[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t FullyAssembledDelegate[0x10]; // 0xe8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t FullyDisassembledDelegate[0x10]; // 0xf8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t BoundsChangedDelegate[0x10]; // 0x108 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bNormalizeAssembly; // 0x118 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_119[0x7]; // 0x119 (Size: 0x7, Type: PaddingProperty)
    TArray<AActor*> TargetActors; // 0x120 (Size: 0x10, Type: ArrayProperty)
    FBox Bounds; // 0x130 (Size: 0x38, Type: StructProperty)
    uint8_t LastEvent; // 0x168 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_169[0x57]; // 0x169 (Size: 0x57, Type: PaddingProperty)

public:
    void GetBoundsCenterAndExtents(FVector& Center, FVector& Extents) const; // 0x123430d8 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)

private:
    void OnRep_Bounds(); // 0xc019b98 (Index: 0x7, Flags: Final|Native|Private)
    void OnRep_LastEvent(); // 0x1234373c (Index: 0x8, Flags: Final|Native|Private)
    void OnRep_TargetActors(); // 0x270d644 (Index: 0x9, Flags: Final|Native|Private)

protected:
    virtual void K2_OnBeginAssemble(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_OnBeginDisassemble(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_OnBoundsChanged(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_OnFullyAssembled(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_OnFullyDisassembled(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_OnTargetActorsChanged(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    void OnTargetActorBeginAssemble(UAtomGeometryAssemblyComponent*& Component); // 0x12343764 (Index: 0xa, Flags: Native|Protected)
    void OnTargetActorBeginDisassemble(UAtomGeometryAssemblyComponent*& Component); // 0x12343894 (Index: 0xb, Flags: Native|Protected)
    void OnTargetActorFullyAssembled(UAtomGeometryAssemblyComponent*& Component); // 0xf3f6f5c (Index: 0xc, Flags: Native|Protected)
    void OnTargetActorFullyDisassembled(UAtomGeometryAssemblyComponent*& Component); // 0xe3eb398 (Index: 0xd, Flags: Native|Protected)
};

static_assert(sizeof(ULimeAssembleContextActorComponent) == 0x1c0, "Size mismatch for ULimeAssembleContextActorComponent");
static_assert(offsetof(ULimeAssembleContextActorComponent, TargetActorsChangedDelegate) == 0xb8, "Offset mismatch for ULimeAssembleContextActorComponent::TargetActorsChangedDelegate");
static_assert(offsetof(ULimeAssembleContextActorComponent, BeginAssembleDelegate) == 0xc8, "Offset mismatch for ULimeAssembleContextActorComponent::BeginAssembleDelegate");
static_assert(offsetof(ULimeAssembleContextActorComponent, BeginDisassembleDelegate) == 0xd8, "Offset mismatch for ULimeAssembleContextActorComponent::BeginDisassembleDelegate");
static_assert(offsetof(ULimeAssembleContextActorComponent, FullyAssembledDelegate) == 0xe8, "Offset mismatch for ULimeAssembleContextActorComponent::FullyAssembledDelegate");
static_assert(offsetof(ULimeAssembleContextActorComponent, FullyDisassembledDelegate) == 0xf8, "Offset mismatch for ULimeAssembleContextActorComponent::FullyDisassembledDelegate");
static_assert(offsetof(ULimeAssembleContextActorComponent, BoundsChangedDelegate) == 0x108, "Offset mismatch for ULimeAssembleContextActorComponent::BoundsChangedDelegate");
static_assert(offsetof(ULimeAssembleContextActorComponent, bNormalizeAssembly) == 0x118, "Offset mismatch for ULimeAssembleContextActorComponent::bNormalizeAssembly");
static_assert(offsetof(ULimeAssembleContextActorComponent, TargetActors) == 0x120, "Offset mismatch for ULimeAssembleContextActorComponent::TargetActors");
static_assert(offsetof(ULimeAssembleContextActorComponent, Bounds) == 0x130, "Offset mismatch for ULimeAssembleContextActorComponent::Bounds");
static_assert(offsetof(ULimeAssembleContextActorComponent, LastEvent) == 0x168, "Offset mismatch for ULimeAssembleContextActorComponent::LastEvent");

// Size: 0x1f0 (Inherited: 0x2b0, Single: 0xffffff40)
class ULimeGeometryAssemblyComponent : public UAtomGeometryAssemblyComponent
{
public:
    UClass* DamageImmunityEffectClass; // 0x1d0 (Size: 0x8, Type: ClassProperty)
    AActor* PreviewActor; // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    bool bWantsPreviewActorVisible; // 0x1e0 (Size: 0x1, Type: BoolProperty)
    bool bIsPreviewActorVisible; // 0x1e1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1e2[0x2]; // 0x1e2 (Size: 0x2, Type: PaddingProperty)
    FActiveGameplayEffectHandle DamageImmunityHandle; // 0x1e4 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_1ec[0x4]; // 0x1ec (Size: 0x4, Type: PaddingProperty)

public:
    void SetPreviewActorVisible(bool& bVisible); // 0x9e6e1b8 (Index: 0x4, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)

private:
    void OnRep_WantsPreviewActorVisible(); // 0x12343750 (Index: 0x3, Flags: Final|Native|Private)

protected:
    virtual AActor* CreatePreviewActor(); // 0x12342898 (Index: 0x0, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void OnPreviewActorHidden(); // 0xd4b56f4 (Index: 0x1, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void OnPreviewActorVisible(); // 0xeb6b8b4 (Index: 0x2, Flags: Native|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ULimeGeometryAssemblyComponent) == 0x1f0, "Size mismatch for ULimeGeometryAssemblyComponent");
static_assert(offsetof(ULimeGeometryAssemblyComponent, DamageImmunityEffectClass) == 0x1d0, "Offset mismatch for ULimeGeometryAssemblyComponent::DamageImmunityEffectClass");
static_assert(offsetof(ULimeGeometryAssemblyComponent, PreviewActor) == 0x1d8, "Offset mismatch for ULimeGeometryAssemblyComponent::PreviewActor");
static_assert(offsetof(ULimeGeometryAssemblyComponent, bWantsPreviewActorVisible) == 0x1e0, "Offset mismatch for ULimeGeometryAssemblyComponent::bWantsPreviewActorVisible");
static_assert(offsetof(ULimeGeometryAssemblyComponent, bIsPreviewActorVisible) == 0x1e1, "Offset mismatch for ULimeGeometryAssemblyComponent::bIsPreviewActorVisible");
static_assert(offsetof(ULimeGeometryAssemblyComponent, DamageImmunityHandle) == 0x1e4, "Offset mismatch for ULimeGeometryAssemblyComponent::DamageImmunityHandle");

// Size: 0x268 (Inherited: 0x4a0, Single: 0xfffffdc8)
class ULimeGeometryAssemblyComponent_BrickRain : public ULimeGeometryAssemblyComponent
{
public:
    int32_t TotalGeometryCount; // 0x1f0 (Size: 0x4, Type: IntProperty)
    float GeometryAssemblyRate; // 0x1f4 (Size: 0x4, Type: FloatProperty)
    float SingleGeometryDuration; // 0x1f8 (Size: 0x4, Type: FloatProperty)
    float DisassembledZDistance; // 0x1fc (Size: 0x4, Type: FloatProperty)
    float DisassembledZDistanceRandomRatio; // 0x200 (Size: 0x4, Type: FloatProperty)
    float DisassembledRotationAmount; // 0x204 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_208[0x60]; // 0x208 (Size: 0x60, Type: PaddingProperty)

protected:
    virtual void K2_SetComponentVisible(UPrimitiveComponent*& Component, bool& bVisible); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ULimeGeometryAssemblyComponent_BrickRain) == 0x268, "Size mismatch for ULimeGeometryAssemblyComponent_BrickRain");
static_assert(offsetof(ULimeGeometryAssemblyComponent_BrickRain, TotalGeometryCount) == 0x1f0, "Offset mismatch for ULimeGeometryAssemblyComponent_BrickRain::TotalGeometryCount");
static_assert(offsetof(ULimeGeometryAssemblyComponent_BrickRain, GeometryAssemblyRate) == 0x1f4, "Offset mismatch for ULimeGeometryAssemblyComponent_BrickRain::GeometryAssemblyRate");
static_assert(offsetof(ULimeGeometryAssemblyComponent_BrickRain, SingleGeometryDuration) == 0x1f8, "Offset mismatch for ULimeGeometryAssemblyComponent_BrickRain::SingleGeometryDuration");
static_assert(offsetof(ULimeGeometryAssemblyComponent_BrickRain, DisassembledZDistance) == 0x1fc, "Offset mismatch for ULimeGeometryAssemblyComponent_BrickRain::DisassembledZDistance");
static_assert(offsetof(ULimeGeometryAssemblyComponent_BrickRain, DisassembledZDistanceRandomRatio) == 0x200, "Offset mismatch for ULimeGeometryAssemblyComponent_BrickRain::DisassembledZDistanceRandomRatio");
static_assert(offsetof(ULimeGeometryAssemblyComponent_BrickRain, DisassembledRotationAmount) == 0x204, "Offset mismatch for ULimeGeometryAssemblyComponent_BrickRain::DisassembledRotationAmount");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FAtomAssemblyState
{
    FName CurrentState; // 0x0 (Size: 0x4, Type: NameProperty)
    float CurrentRatio; // 0x4 (Size: 0x4, Type: FloatProperty)
    float TargetRatio; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FAtomAssemblyState) == 0xc, "Size mismatch for FAtomAssemblyState");
static_assert(offsetof(FAtomAssemblyState, CurrentState) == 0x0, "Offset mismatch for FAtomAssemblyState::CurrentState");
static_assert(offsetof(FAtomAssemblyState, CurrentRatio) == 0x4, "Offset mismatch for FAtomAssemblyState::CurrentRatio");
static_assert(offsetof(FAtomAssemblyState, TargetRatio) == 0x8, "Offset mismatch for FAtomAssemblyState::TargetRatio");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FAtomAssemblyCollision
{
    uint8_t bOverrideCollisionEnabled : 1; // 0x0:0 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ECollisionEnabled> CollisionEnabled; // 0x1 (Size: 0x1, Type: ByteProperty)
};

static_assert(sizeof(FAtomAssemblyCollision) == 0x2, "Size mismatch for FAtomAssemblyCollision");
static_assert(offsetof(FAtomAssemblyCollision, bOverrideCollisionEnabled) == 0x0, "Offset mismatch for FAtomAssemblyCollision::bOverrideCollisionEnabled");
static_assert(offsetof(FAtomAssemblyCollision, CollisionEnabled) == 0x1, "Offset mismatch for FAtomAssemblyCollision::CollisionEnabled");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAtomAssemblyRange
{
    uint8_t bHasValue : 1; // 0x0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    double RangeMin; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double RangeMax; // 0x10 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FAtomAssemblyRange) == 0x18, "Size mismatch for FAtomAssemblyRange");
static_assert(offsetof(FAtomAssemblyRange, bHasValue) == 0x0, "Offset mismatch for FAtomAssemblyRange::bHasValue");
static_assert(offsetof(FAtomAssemblyRange, RangeMin) == 0x8, "Offset mismatch for FAtomAssemblyRange::RangeMin");
static_assert(offsetof(FAtomAssemblyRange, RangeMax) == 0x10, "Offset mismatch for FAtomAssemblyRange::RangeMax");

