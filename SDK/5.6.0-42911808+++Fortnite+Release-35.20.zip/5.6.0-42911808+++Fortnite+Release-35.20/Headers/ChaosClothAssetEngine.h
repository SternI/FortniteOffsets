/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosClothAssetEngine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "ClothingSystemRuntimeInterface.h"
#include "DataflowEngine.h"
#include "DataflowSimulation.h"
#include "ClothingSystemRuntimeCommon.h"

// Size: 0xa30 (Inherited: 0x1680, Single: 0xfffff3b0)
class UChaosClothComponent : public USkinnedMeshComponent
{
public:
    FDataflowSimulationAsset SimulationAsset; // 0x8e0 (Size: 0x58, Type: StructProperty)
    float BlendWeight; // 0x938 (Size: 0x4, Type: FloatProperty)
    float ClothGeometryScale; // 0x93c (Size: 0x4, Type: FloatProperty)
    uint8_t bUseAttachedParentAsPoseComponent : 1; // 0x940:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bWaitForParallelTask : 1; // 0x940:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableSimulation : 1; // 0x940:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bSuspendSimulation : 1; // 0x940:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bBindToLeaderComponent : 1; // 0x940:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bTeleport : 1; // 0x940:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bReset : 1; // 0x940:6 (Size: 0x1, Type: BoolProperty)
    uint8_t bCollideWithEnvironment : 1; // 0x940:7 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_941[0x3]; // 0x941 (Size: 0x3, Type: PaddingProperty)
    float TeleportDistanceThreshold; // 0x944 (Size: 0x4, Type: FloatProperty)
    float TeleportRotationThreshold; // 0x948 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_94c[0x9c]; // 0x94c (Size: 0x9c, Type: PaddingProperty)
    TArray<FChaosClothSimulationProperties> ClothSimulationProperties; // 0x9e8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_9f8[0x38]; // 0x9f8 (Size: 0x38, Type: PaddingProperty)

public:
    void AddCollisionSource(USkinnedMeshComponent*& SourceComponent, UPhysicsAsset*& const SourcePhysicsAsset, bool& bUseSphylsOnly); // 0xcb74c98 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void ForceNextUpdateTeleport(); // 0xcb75248 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void ForceNextUpdateTeleportAndReset(); // 0xcb75268 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    UChaosClothAssetBase* GetAsset() const; // 0xcb753d0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UChaosClothAsset* GetClothAsset() const; // 0xcb753f4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UChaosClothAssetInteractor* GetClothOutfitInteractor(int32_t& ModelIndex, FName& const ClothSimulationModelName); // 0xcb75438 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    bool GetCollideWithEnvironment() const; // 0xcb75650 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTeleportDistanceThreshold() const; // 0xcb769e4 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTeleportRotationThreshold() const; // 0xcb769fc (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSimulationEnabled() const; // 0xcb77314 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSimulationSuspended() const; // 0xcb77338 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RecreateClothSimulationProxy(); // 0xcb7735c (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveCollisionSource(USkinnedMeshComponent*& const SourceComponent, UPhysicsAsset*& const SourcePhysicsAsset); // 0xcb77370 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveCollisionSources(USkinnedMeshComponent*& const SourceComponent); // 0xcb7759c (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    void ResetCollisionSources(); // 0xcb776d8 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    void ResetConfigProperties(); // 0xcb776ec (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    void ResetTeleportMode(); // 0xcb77700 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    void ResumeSimulation(); // 0xcb77718 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
    void SetAsset(UChaosClothAssetBase*& InAsset); // 0xcb77730 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)
    void SetClothAsset(UChaosClothAsset*& InClothAsset); // 0xcb77730 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)
    void SetCollideWithEnvironment(bool& bCollide); // 0xcb77864 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)
    void SetEnableSimulation(bool& bEnable); // 0xcb779ac (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    void SetSimulateInEditor(bool& const bNewSimulateState); // 0x9e6e1b8 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void SetTeleportDistanceThreshold(float& Threshold); // 0xcb79860 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void SetTeleportRotationThreshold(float& Threshold); // 0xcb799a8 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void SuspendSimulation(); // 0xcb7a558 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UChaosClothComponent) == 0xa30, "Size mismatch for UChaosClothComponent");
static_assert(offsetof(UChaosClothComponent, SimulationAsset) == 0x8e0, "Offset mismatch for UChaosClothComponent::SimulationAsset");
static_assert(offsetof(UChaosClothComponent, BlendWeight) == 0x938, "Offset mismatch for UChaosClothComponent::BlendWeight");
static_assert(offsetof(UChaosClothComponent, ClothGeometryScale) == 0x93c, "Offset mismatch for UChaosClothComponent::ClothGeometryScale");
static_assert(offsetof(UChaosClothComponent, bUseAttachedParentAsPoseComponent) == 0x940, "Offset mismatch for UChaosClothComponent::bUseAttachedParentAsPoseComponent");
static_assert(offsetof(UChaosClothComponent, bWaitForParallelTask) == 0x940, "Offset mismatch for UChaosClothComponent::bWaitForParallelTask");
static_assert(offsetof(UChaosClothComponent, bEnableSimulation) == 0x940, "Offset mismatch for UChaosClothComponent::bEnableSimulation");
static_assert(offsetof(UChaosClothComponent, bSuspendSimulation) == 0x940, "Offset mismatch for UChaosClothComponent::bSuspendSimulation");
static_assert(offsetof(UChaosClothComponent, bBindToLeaderComponent) == 0x940, "Offset mismatch for UChaosClothComponent::bBindToLeaderComponent");
static_assert(offsetof(UChaosClothComponent, bTeleport) == 0x940, "Offset mismatch for UChaosClothComponent::bTeleport");
static_assert(offsetof(UChaosClothComponent, bReset) == 0x940, "Offset mismatch for UChaosClothComponent::bReset");
static_assert(offsetof(UChaosClothComponent, bCollideWithEnvironment) == 0x940, "Offset mismatch for UChaosClothComponent::bCollideWithEnvironment");
static_assert(offsetof(UChaosClothComponent, TeleportDistanceThreshold) == 0x944, "Offset mismatch for UChaosClothComponent::TeleportDistanceThreshold");
static_assert(offsetof(UChaosClothComponent, TeleportRotationThreshold) == 0x948, "Offset mismatch for UChaosClothComponent::TeleportRotationThreshold");
static_assert(offsetof(UChaosClothComponent, ClothSimulationProperties) == 0x9e8, "Offset mismatch for UChaosClothComponent::ClothSimulationProperties");

// Size: 0x3b0 (Inherited: 0x528, Single: 0xfffffe88)
class UChaosClothAsset : public UChaosClothAssetBase
{
public:
    USkeleton* Skeleton; // 0x368 (Size: 0x8, Type: ObjectProperty)
    UPhysicsAsset* PhysicsAsset; // 0x370 (Size: 0x8, Type: ObjectProperty)
    bool bSmoothTransition; // 0x378 (Size: 0x1, Type: BoolProperty)
    bool bUseMultipleInfluences; // 0x379 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_37a[0x2]; // 0x37a (Size: 0x2, Type: PaddingProperty)
    float SkinningKernelRadius; // 0x37c (Size: 0x4, Type: FloatProperty)
    FGuid AssetGuid; // 0x380 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_390[0x20]; // 0x390 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UChaosClothAsset) == 0x3b0, "Size mismatch for UChaosClothAsset");
static_assert(offsetof(UChaosClothAsset, Skeleton) == 0x368, "Offset mismatch for UChaosClothAsset::Skeleton");
static_assert(offsetof(UChaosClothAsset, PhysicsAsset) == 0x370, "Offset mismatch for UChaosClothAsset::PhysicsAsset");
static_assert(offsetof(UChaosClothAsset, bSmoothTransition) == 0x378, "Offset mismatch for UChaosClothAsset::bSmoothTransition");
static_assert(offsetof(UChaosClothAsset, bUseMultipleInfluences) == 0x379, "Offset mismatch for UChaosClothAsset::bUseMultipleInfluences");
static_assert(offsetof(UChaosClothAsset, SkinningKernelRadius) == 0x37c, "Offset mismatch for UChaosClothAsset::SkinningKernelRadius");
static_assert(offsetof(UChaosClothAsset, AssetGuid) == 0x380, "Offset mismatch for UChaosClothAsset::AssetGuid");

// Size: 0x368 (Inherited: 0x1c0, Single: 0x1a8)
class UChaosClothAssetBase : public USkinnedAsset
{
public:
    uint8_t Pad_d0[0x28]; // 0xd0 (Size: 0x28, Type: PaddingProperty)
    FDataflowInstance DataflowInstance; // 0xf8 (Size: 0x40, Type: StructProperty)
    TArray<FSkeletalMaterial> Materials; // 0x138 (Size: 0x10, Type: ArrayProperty)
    TArray<FSkeletalMeshLODInfo> LODInfo; // 0x148 (Size: 0x10, Type: ArrayProperty)
    FPerQualityLevelInt MinQualityLevelLOD; // 0x158 (Size: 0x68, Type: StructProperty)
    FPerPlatformBool DisableBelowMinLodStripping; // 0x1c0 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_1c1[0x3]; // 0x1c1 (Size: 0x3, Type: PaddingProperty)
    FPerPlatformInt MinLOD; // 0x1c4 (Size: 0x4, Type: StructProperty)
    uint8_t bSupportRayTracing : 1; // 0x1c8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1c9[0x3]; // 0x1c9 (Size: 0x3, Type: PaddingProperty)
    int32_t RayTracingMinLOD; // 0x1cc (Size: 0x4, Type: IntProperty)
    UPhysicsAsset* ShadowPhysicsAsset; // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* OverlayMaterial; // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    float OverlayMaterialMaxDrawDistance; // 0x1e0 (Size: 0x4, Type: FloatProperty)
    uint8_t bHasVertexColors : 1; // 0x1e4:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1e5[0x11b]; // 0x1e5 (Size: 0x11b, Type: PaddingProperty)
    FBoxSphereBounds Bounds; // 0x300 (Size: 0x38, Type: StructProperty)
    uint8_t Pad_338[0x30]; // 0x338 (Size: 0x30, Type: PaddingProperty)

public:
    UMaterialInterface* GetOverlayMaterial() const; // 0xa85f5a4 (Index: 0x0, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetOverlayMaterialMaxDrawDistance() const; // 0xa85f5cc (Index: 0x1, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    UPhysicsAsset* GetShadowPhysicsAsset() const; // 0xa85f620 (Index: 0x2, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetOverlayMaterial(UMaterialInterface*& NewOverlayMaterial); // 0xcb78e58 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void SetOverlayMaterialMaxDrawDistance(float& InMaxDrawDistance); // 0xcb79130 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UChaosClothAssetBase) == 0x368, "Size mismatch for UChaosClothAssetBase");
static_assert(offsetof(UChaosClothAssetBase, DataflowInstance) == 0xf8, "Offset mismatch for UChaosClothAssetBase::DataflowInstance");
static_assert(offsetof(UChaosClothAssetBase, Materials) == 0x138, "Offset mismatch for UChaosClothAssetBase::Materials");
static_assert(offsetof(UChaosClothAssetBase, LODInfo) == 0x148, "Offset mismatch for UChaosClothAssetBase::LODInfo");
static_assert(offsetof(UChaosClothAssetBase, MinQualityLevelLOD) == 0x158, "Offset mismatch for UChaosClothAssetBase::MinQualityLevelLOD");
static_assert(offsetof(UChaosClothAssetBase, DisableBelowMinLodStripping) == 0x1c0, "Offset mismatch for UChaosClothAssetBase::DisableBelowMinLodStripping");
static_assert(offsetof(UChaosClothAssetBase, MinLOD) == 0x1c4, "Offset mismatch for UChaosClothAssetBase::MinLOD");
static_assert(offsetof(UChaosClothAssetBase, bSupportRayTracing) == 0x1c8, "Offset mismatch for UChaosClothAssetBase::bSupportRayTracing");
static_assert(offsetof(UChaosClothAssetBase, RayTracingMinLOD) == 0x1cc, "Offset mismatch for UChaosClothAssetBase::RayTracingMinLOD");
static_assert(offsetof(UChaosClothAssetBase, ShadowPhysicsAsset) == 0x1d0, "Offset mismatch for UChaosClothAssetBase::ShadowPhysicsAsset");
static_assert(offsetof(UChaosClothAssetBase, OverlayMaterial) == 0x1d8, "Offset mismatch for UChaosClothAssetBase::OverlayMaterial");
static_assert(offsetof(UChaosClothAssetBase, OverlayMaterialMaxDrawDistance) == 0x1e0, "Offset mismatch for UChaosClothAssetBase::OverlayMaterialMaxDrawDistance");
static_assert(offsetof(UChaosClothAssetBase, bHasVertexColors) == 0x1e4, "Offset mismatch for UChaosClothAssetBase::bHasVertexColors");
static_assert(offsetof(UChaosClothAssetBase, Bounds) == 0x300, "Offset mismatch for UChaosClothAssetBase::Bounds");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UChaosClothAssetInteractor : public UObject
{
public:

public:
    TArray<FString> GetAllProperties(int32_t& LODIndex) const; // 0xcb75280 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetFloatValue(FString& PropertyName, int32_t& LODIndex, float& DefaultValue) const; // 0xcb7566c (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetHighFloatValue(FString& PropertyName, int32_t& LODIndex, float& DefaultValue) const; // 0xcb75b20 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetIntValue(FString& PropertyName, int32_t& LODIndex, int32_t& DefaultValue) const; // 0xcb75fd4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetLowFloatValue(FString& PropertyName, int32_t& LODIndex, float& DefaultValue) const; // 0xcb7566c (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetStringValue(FString& PropertyName, int32_t& LODIndex, FString& DefaultValue) const; // 0xcb76484 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetVectorValue(FString& PropertyName, int32_t& LODIndex, FVector& DefaultValue) const; // 0xcb76a14 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector2D GetWeightedFloatValue(FString& PropertyName, int32_t& LODIndex, FVector2D& DefaultValue) const; // 0xcb76ea0 (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    void SetFloatValue(FString& PropertyName, int32_t& LODIndex, float& Value); // 0xcb77ae4 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetHighFloatValue(FString& PropertyName, int32_t& LODIndex, float& Value); // 0xcb77f8c (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetIntValue(FString& PropertyName, int32_t& LODIndex, int32_t& Value); // 0xcb78434 (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetLowFloatValue(FString& PropertyName, int32_t& LODIndex, float& Value); // 0xcb789b0 (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetStringValue(FString& PropertyName, int32_t& LODIndex, FString& Value); // 0xcb7925c (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetVectorValue(FString& PropertyName, int32_t& LODIndex, FVector& Value); // 0xcb79ae0 (Index: 0xd, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetWeightedFloatValue(FString& PropertyName, int32_t& LODIndex, FVector2D& Value); // 0xcb7a020 (Index: 0xe, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UChaosClothAssetInteractor) == 0x38, "Size mismatch for UChaosClothAssetInteractor");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FChaosClothSimulationProperties
{
    UChaosClothAssetInteractor* ClothOutfitInteractor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x20]; // 0x8 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(FChaosClothSimulationProperties) == 0x28, "Size mismatch for FChaosClothSimulationProperties");
static_assert(offsetof(FChaosClothSimulationProperties, ClothOutfitInteractor) == 0x0, "Offset mismatch for FChaosClothSimulationProperties::ClothOutfitInteractor");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FChaosClothAssetLodTransitionDataCache
{
};

static_assert(sizeof(FChaosClothAssetLodTransitionDataCache) == 0x38, "Size mismatch for FChaosClothAssetLodTransitionDataCache");

// Size: 0x1f0 (Inherited: 0x0, Single: 0x1f0)
struct FChaosClothSimulationLodModel
{
    TArray<FVector3f> Positions; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector3f> Normals; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> Indices; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothVertBoneData> BoneData; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<uint16_t> RequiredExtraBoneIndices; // 0x40 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_50[0x20]; // 0x50 (Size: 0x20, Type: PaddingProperty)
    TArray<FVector2f> PatternPositions; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> PatternIndices; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> PatternToWeldedIndices; // 0x90 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_a0[0x50]; // 0xa0 (Size: 0x50, Type: PaddingProperty)
    FClothTetherData TetherData; // 0xf0 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_100[0xf0]; // 0x100 (Size: 0xf0, Type: PaddingProperty)
};

static_assert(sizeof(FChaosClothSimulationLodModel) == 0x1f0, "Size mismatch for FChaosClothSimulationLodModel");
static_assert(offsetof(FChaosClothSimulationLodModel, Positions) == 0x0, "Offset mismatch for FChaosClothSimulationLodModel::Positions");
static_assert(offsetof(FChaosClothSimulationLodModel, Normals) == 0x10, "Offset mismatch for FChaosClothSimulationLodModel::Normals");
static_assert(offsetof(FChaosClothSimulationLodModel, Indices) == 0x20, "Offset mismatch for FChaosClothSimulationLodModel::Indices");
static_assert(offsetof(FChaosClothSimulationLodModel, BoneData) == 0x30, "Offset mismatch for FChaosClothSimulationLodModel::BoneData");
static_assert(offsetof(FChaosClothSimulationLodModel, RequiredExtraBoneIndices) == 0x40, "Offset mismatch for FChaosClothSimulationLodModel::RequiredExtraBoneIndices");
static_assert(offsetof(FChaosClothSimulationLodModel, PatternPositions) == 0x70, "Offset mismatch for FChaosClothSimulationLodModel::PatternPositions");
static_assert(offsetof(FChaosClothSimulationLodModel, PatternIndices) == 0x80, "Offset mismatch for FChaosClothSimulationLodModel::PatternIndices");
static_assert(offsetof(FChaosClothSimulationLodModel, PatternToWeldedIndices) == 0x90, "Offset mismatch for FChaosClothSimulationLodModel::PatternToWeldedIndices");
static_assert(offsetof(FChaosClothSimulationLodModel, TetherData) == 0xf0, "Offset mismatch for FChaosClothSimulationLodModel::TetherData");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FChaosClothSimulationModel
{
    TArray<FChaosClothSimulationLodModel> ClothSimulationLodModels; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> UsedBoneNames; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> UsedBoneIndices; // 0x20 (Size: 0x10, Type: ArrayProperty)
    int32_t ReferenceBoneIndex; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FChaosClothSimulationModel) == 0x38, "Size mismatch for FChaosClothSimulationModel");
static_assert(offsetof(FChaosClothSimulationModel, ClothSimulationLodModels) == 0x0, "Offset mismatch for FChaosClothSimulationModel::ClothSimulationLodModels");
static_assert(offsetof(FChaosClothSimulationModel, UsedBoneNames) == 0x10, "Offset mismatch for FChaosClothSimulationModel::UsedBoneNames");
static_assert(offsetof(FChaosClothSimulationModel, UsedBoneIndices) == 0x20, "Offset mismatch for FChaosClothSimulationModel::UsedBoneIndices");
static_assert(offsetof(FChaosClothSimulationModel, ReferenceBoneIndex) == 0x30, "Offset mismatch for FChaosClothSimulationModel::ReferenceBoneIndex");

