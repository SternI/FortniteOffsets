/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_BattleRoyaleFrontendExperienceFlow
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "BattleRoyaleFrontend.h"

// Size: 0x160 (Inherited: 0x188, Single: 0xffffffd8)
class UBP_BattleRoyaleFrontendExperienceFlow_C : public UBattleRoyaleFrontendExperienceFlow
{
public:
};

static_assert(sizeof(UBP_BattleRoyaleFrontendExperienceFlow_C) == 0x160, "Size mismatch for UBP_BattleRoyaleFrontendExperienceFlow_C");

