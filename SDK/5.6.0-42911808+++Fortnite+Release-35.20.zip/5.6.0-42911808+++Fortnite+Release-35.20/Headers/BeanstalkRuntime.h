/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeanstalkRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "FortniteGameFramework.h"
#include "ModularGameplay.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "EnhancedInput.h"
#include "MotionWarping.h"
#include "Niagara.h"

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class UBeanAudioDataAsset : public UDataAsset
{
public:
    TMap<FBeanAudioSet, FBeanAudioKey> SoundListsByCategory; // 0x30 (Size: 0x50, Type: MapProperty)

public:
    TMap<FBeanAudioSet, FBeanAudioKey> GetSoundListsByCategory() const; // 0x112b0200 (Index: 0x0, Flags: Final|Native|Public|Const)
};

static_assert(sizeof(UBeanAudioDataAsset) == 0x80, "Size mismatch for UBeanAudioDataAsset");
static_assert(offsetof(UBeanAudioDataAsset, SoundListsByCategory) == 0x30, "Offset mismatch for UBeanAudioDataAsset::SoundListsByCategory");

// Size: 0xd0 (Inherited: 0x1a0, Single: 0xffffff30)
class UBeanCameraModeOverrideComponent : public UFortCameraModeOverrideComponent
{
public:
    UClass* BeanCurrentCameraMode; // 0xc0 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> CharacterConfig; // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UBeanCameraModeOverrideComponent) == 0xd0, "Size mismatch for UBeanCameraModeOverrideComponent");
static_assert(offsetof(UBeanCameraModeOverrideComponent, BeanCurrentCameraMode) == 0xc0, "Offset mismatch for UBeanCameraModeOverrideComponent::BeanCurrentCameraMode");
static_assert(offsetof(UBeanCameraModeOverrideComponent, CharacterConfig) == 0xc8, "Offset mismatch for UBeanCameraModeOverrideComponent::CharacterConfig");

// Size: 0x2080 (Inherited: 0x20a8, Single: 0xffffffd8)
class UBeanCameraMode_ThirdPerson : public UFortCameraMode_ThirdPerson
{
public:
    bool bEnableDraggedBehaviour; // 0x2018 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2019[0x7]; // 0x2019 (Size: 0x7, Type: PaddingProperty)
    double ControllerYawToleranceForDragEnable; // 0x2020 (Size: 0x8, Type: DoubleProperty)
    FGameplayTagContainer DisableDraggedCameraTags; // 0x2028 (Size: 0x20, Type: StructProperty)
    double ResetCameraPitch; // 0x2048 (Size: 0x8, Type: DoubleProperty)
    uint8_t Pad_2050[0x30]; // 0x2050 (Size: 0x30, Type: PaddingProperty)
};

static_assert(sizeof(UBeanCameraMode_ThirdPerson) == 0x2080, "Size mismatch for UBeanCameraMode_ThirdPerson");
static_assert(offsetof(UBeanCameraMode_ThirdPerson, bEnableDraggedBehaviour) == 0x2018, "Offset mismatch for UBeanCameraMode_ThirdPerson::bEnableDraggedBehaviour");
static_assert(offsetof(UBeanCameraMode_ThirdPerson, ControllerYawToleranceForDragEnable) == 0x2020, "Offset mismatch for UBeanCameraMode_ThirdPerson::ControllerYawToleranceForDragEnable");
static_assert(offsetof(UBeanCameraMode_ThirdPerson, DisableDraggedCameraTags) == 0x2028, "Offset mismatch for UBeanCameraMode_ThirdPerson::DisableDraggedCameraTags");
static_assert(offsetof(UBeanCameraMode_ThirdPerson, ResetCameraPitch) == 0x2048, "Offset mismatch for UBeanCameraMode_ThirdPerson::ResetCameraPitch");

// Size: 0x6370 (Inherited: 0x13920, Single: 0xffff2a50)
class ABeanCharacter : public AFortStandInPlayerPawn
{
public:
    uint8_t Pad_6000[0x8]; // 0x6000 (Size: 0x8, Type: PaddingProperty)
    UFortAbilitySet* AbilitySet; // 0x6008 (Size: 0x8, Type: ObjectProperty)
    UBeanCharAnimInstance* AnimInstance; // 0x6010 (Size: 0x8, Type: ObjectProperty)
    UMotionWarpingComponent* MotionWarpingComponent; // 0x6018 (Size: 0x8, Type: ObjectProperty)
    UClass* ConfigurationClass; // 0x6020 (Size: 0x8, Type: ClassProperty)
    UInputMappingContext* DefaultMappingContext; // 0x6028 (Size: 0x8, Type: ObjectProperty)
    UInputAction* DiveAction; // 0x6030 (Size: 0x8, Type: ObjectProperty)
    UInputAction* GrabAction; // 0x6038 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag JumpButtonDiveIconOverrideTag; // 0x6040 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_6044[0x2c]; // 0x6044 (Size: 0x2c, Type: PaddingProperty)
    UBeanCharMovementComponent* MovementComponent; // 0x6070 (Size: 0x8, Type: ObjectProperty)
    UBeanJiggleMotionComponent* JiggleComponent; // 0x6078 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_6080[0x18]; // 0x6080 (Size: 0x18, Type: PaddingProperty)
    UBeanCharStateMachine* StateMachine; // 0x6098 (Size: 0x8, Type: ObjectProperty)
    UBeanStreamingManager* BeanStreamManager; // 0x60a0 (Size: 0x8, Type: ObjectProperty)
    uint8_t bPressedDive : 1; // 0x60a8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_60a9[0x2f]; // 0x60a9 (Size: 0x2f, Type: PaddingProperty)
    UBeanCameraModeOverrideComponent* BeanCameraModeOverrideComponent; // 0x60d8 (Size: 0x8, Type: ObjectProperty)
    UBeanParticleSystemsComponent* ParticleSystemsComponent; // 0x60e0 (Size: 0x8, Type: ObjectProperty)
    UBeanCharGrabComponent* GrabComponent; // 0x60e8 (Size: 0x8, Type: ObjectProperty)
    UBeanCharBeingGrabbedComponent* BeingGrabbedComponent; // 0x60f0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GrabFeatureEnabledTag; // 0x60f8 (Size: 0x4, Type: StructProperty)
    uint8_t bPressingGrab : 1; // 0x60fc:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_60fd[0x3]; // 0x60fd (Size: 0x3, Type: PaddingProperty)
    UBeanCharMantleComponent* MantleComponent; // 0x6100 (Size: 0x8, Type: ObjectProperty)
    uint8_t bWantsToMantle : 1; // 0x6108:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6109[0xf]; // 0x6109 (Size: 0xf, Type: PaddingProperty)
    UBeanCharRagdollComponent* RagdollComponent; // 0x6118 (Size: 0x8, Type: ObjectProperty)
    UPhysicsConstraintComponent* RagdollPhysicsConstraint; // 0x6120 (Size: 0x8, Type: ObjectProperty)
    UCapsuleComponent* RagdollRootCapsule; // 0x6128 (Size: 0x8, Type: ObjectProperty)
    float CapsuleUnscaledHalfHeight; // 0x6130 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_6134[0x4]; // 0x6134 (Size: 0x4, Type: PaddingProperty)
    UNetworkPhysicsSettingsComponent* NetworkPhysicsSettingsComponent; // 0x6138 (Size: 0x8, Type: ObjectProperty)
    UBeanCharCollisionManagerComponent* CollisionManagerComponent; // 0x6140 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_6148[0x10]; // 0x6148 (Size: 0x10, Type: PaddingProperty)
    UInteractSelection_Base* PushedInteractionSelection; // 0x6158 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_6160[0x30]; // 0x6160 (Size: 0x30, Type: PaddingProperty)
    TSoftObjectPtr<UAnimMontage*> MantleAnimationMontage; // 0x6190 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage*> GetupAnimationMontage_Front; // 0x61b0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage*> GetupAnimationMontage_Left; // 0x61d0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage*> GetupAnimationMontage_Right; // 0x61f0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage*> GetupAnimationMontage_Back; // 0x6210 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage*> LandStaggerAnimationMontage; // 0x6230 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage*> LandStaggerAnimationMontageAlt; // 0x6250 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UBeanCosmeticBackpackAllowList*> BackpackAllowList; // 0x6270 (Size: 0x20, Type: SoftObjectProperty)
    bool bCharacterCosmeticsVisibility; // 0x6290 (Size: 0x1, Type: BoolProperty)
    bool bBackpackCosmeticsVisibility; // 0x6291 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6292[0x6]; // 0x6292 (Size: 0x6, Type: PaddingProperty)
    FGameplayTagContainer IdleBreakBlockingTags; // 0x6298 (Size: 0x20, Type: StructProperty)
    bool bEnableInventoryMode; // 0x62b8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_62b9[0x7]; // 0x62b9 (Size: 0x7, Type: PaddingProperty)
    USkeletalMeshComponent* RetargetSourceMesh; // 0x62c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_62c8[0xa8]; // 0x62c8 (Size: 0xa8, Type: PaddingProperty)

public:
    virtual void BP_OnBeanLocalInteractFailed(AActor*& Interactable); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    TArray<UMaterialInstanceDynamic*> GetAllCosmeticMaterials() const; // 0x112afc94 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UBeanCharAnimInstance* GetBeanAnimInstance() const; // 0x112afd08 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UBeanCharMovementComponent* GetBeanCharacterMovement() const; // 0x112afd78 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UBeanCharBeingGrabbedComponent* GetBeingGrabbedComponent() const; // 0x112afd9c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UBeanCharCollisionManagerComponent* GetCollisionManager() const; // 0x112afdb4 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UBeanCharConfigObject* GetConfiguration() const; // 0x112afdf8 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UBeanCharGrabComponent* GetGrabComponent() const; // 0x112afe1c (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UBeanJiggleMotionComponent* GetJiggleMotionComponent() const; // 0x112b0170 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UBeanCharMantleComponent* GetMantleComponent() const; // 0x112b0188 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetMeshScale() const; // 0x112b01a0 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UNetworkPhysicsSettingsComponent* GetNetworkedPhysicsSettingsComponent(); // 0x112b01b8 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    UBeanCharRagdollComponent* GetRagdollComponent() const; // 0x112b01d0 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    USkeletalMeshComponent* GetRetargetSourceMesh() const; // 0x112b01e8 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsBeingGrabbed() const; // 0x112b02bc (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void PredictLaunch(TScriptInterface<Class>& SourceImpactPredictor, UObject*& SourceOptionalSubobject, const FVector LaunchVector); // 0x112b0358 (Index: 0x13, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void TriggerRagdoll(const FVector Force, bool& bIsViaLaunch); // 0x112b0f20 (Index: 0x15, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable)

private:
    void OnRep_EnableInventoryMode(); // 0x112b02e0 (Index: 0x12, Flags: Final|Native|Private)

protected:
    virtual void Client_OnTeleport(FVector& const Location, FRotator& const Rotation); // 0x112afa08 (Index: 0x1, Flags: Net|NetReliableNative|Event|Protected|HasDefaults|NetClient)
    virtual void Client_TeleportSucceeded(); // 0x112afb94 (Index: 0x2, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void Debug_ServerActivateRagdoll(FVector& Force); // 0x112afbbc (Index: 0x3, Flags: Net|NetReliableNative|Event|Protected|NetServer|HasDefaults)
    virtual void ServerPlayEmote(UAthenaDanceItemDefinition*& const EmoteToPlay, EFortEmotePlayMode& PlayMode); // 0x112b07bc (Index: 0x14, Flags: Net|Native|Event|Protected|NetServer)
};

static_assert(sizeof(ABeanCharacter) == 0x6370, "Size mismatch for ABeanCharacter");
static_assert(offsetof(ABeanCharacter, AbilitySet) == 0x6008, "Offset mismatch for ABeanCharacter::AbilitySet");
static_assert(offsetof(ABeanCharacter, AnimInstance) == 0x6010, "Offset mismatch for ABeanCharacter::AnimInstance");
static_assert(offsetof(ABeanCharacter, MotionWarpingComponent) == 0x6018, "Offset mismatch for ABeanCharacter::MotionWarpingComponent");
static_assert(offsetof(ABeanCharacter, ConfigurationClass) == 0x6020, "Offset mismatch for ABeanCharacter::ConfigurationClass");
static_assert(offsetof(ABeanCharacter, DefaultMappingContext) == 0x6028, "Offset mismatch for ABeanCharacter::DefaultMappingContext");
static_assert(offsetof(ABeanCharacter, DiveAction) == 0x6030, "Offset mismatch for ABeanCharacter::DiveAction");
static_assert(offsetof(ABeanCharacter, GrabAction) == 0x6038, "Offset mismatch for ABeanCharacter::GrabAction");
static_assert(offsetof(ABeanCharacter, JumpButtonDiveIconOverrideTag) == 0x6040, "Offset mismatch for ABeanCharacter::JumpButtonDiveIconOverrideTag");
static_assert(offsetof(ABeanCharacter, MovementComponent) == 0x6070, "Offset mismatch for ABeanCharacter::MovementComponent");
static_assert(offsetof(ABeanCharacter, JiggleComponent) == 0x6078, "Offset mismatch for ABeanCharacter::JiggleComponent");
static_assert(offsetof(ABeanCharacter, StateMachine) == 0x6098, "Offset mismatch for ABeanCharacter::StateMachine");
static_assert(offsetof(ABeanCharacter, BeanStreamManager) == 0x60a0, "Offset mismatch for ABeanCharacter::BeanStreamManager");
static_assert(offsetof(ABeanCharacter, bPressedDive) == 0x60a8, "Offset mismatch for ABeanCharacter::bPressedDive");
static_assert(offsetof(ABeanCharacter, BeanCameraModeOverrideComponent) == 0x60d8, "Offset mismatch for ABeanCharacter::BeanCameraModeOverrideComponent");
static_assert(offsetof(ABeanCharacter, ParticleSystemsComponent) == 0x60e0, "Offset mismatch for ABeanCharacter::ParticleSystemsComponent");
static_assert(offsetof(ABeanCharacter, GrabComponent) == 0x60e8, "Offset mismatch for ABeanCharacter::GrabComponent");
static_assert(offsetof(ABeanCharacter, BeingGrabbedComponent) == 0x60f0, "Offset mismatch for ABeanCharacter::BeingGrabbedComponent");
static_assert(offsetof(ABeanCharacter, GrabFeatureEnabledTag) == 0x60f8, "Offset mismatch for ABeanCharacter::GrabFeatureEnabledTag");
static_assert(offsetof(ABeanCharacter, bPressingGrab) == 0x60fc, "Offset mismatch for ABeanCharacter::bPressingGrab");
static_assert(offsetof(ABeanCharacter, MantleComponent) == 0x6100, "Offset mismatch for ABeanCharacter::MantleComponent");
static_assert(offsetof(ABeanCharacter, bWantsToMantle) == 0x6108, "Offset mismatch for ABeanCharacter::bWantsToMantle");
static_assert(offsetof(ABeanCharacter, RagdollComponent) == 0x6118, "Offset mismatch for ABeanCharacter::RagdollComponent");
static_assert(offsetof(ABeanCharacter, RagdollPhysicsConstraint) == 0x6120, "Offset mismatch for ABeanCharacter::RagdollPhysicsConstraint");
static_assert(offsetof(ABeanCharacter, RagdollRootCapsule) == 0x6128, "Offset mismatch for ABeanCharacter::RagdollRootCapsule");
static_assert(offsetof(ABeanCharacter, CapsuleUnscaledHalfHeight) == 0x6130, "Offset mismatch for ABeanCharacter::CapsuleUnscaledHalfHeight");
static_assert(offsetof(ABeanCharacter, NetworkPhysicsSettingsComponent) == 0x6138, "Offset mismatch for ABeanCharacter::NetworkPhysicsSettingsComponent");
static_assert(offsetof(ABeanCharacter, CollisionManagerComponent) == 0x6140, "Offset mismatch for ABeanCharacter::CollisionManagerComponent");
static_assert(offsetof(ABeanCharacter, PushedInteractionSelection) == 0x6158, "Offset mismatch for ABeanCharacter::PushedInteractionSelection");
static_assert(offsetof(ABeanCharacter, MantleAnimationMontage) == 0x6190, "Offset mismatch for ABeanCharacter::MantleAnimationMontage");
static_assert(offsetof(ABeanCharacter, GetupAnimationMontage_Front) == 0x61b0, "Offset mismatch for ABeanCharacter::GetupAnimationMontage_Front");
static_assert(offsetof(ABeanCharacter, GetupAnimationMontage_Left) == 0x61d0, "Offset mismatch for ABeanCharacter::GetupAnimationMontage_Left");
static_assert(offsetof(ABeanCharacter, GetupAnimationMontage_Right) == 0x61f0, "Offset mismatch for ABeanCharacter::GetupAnimationMontage_Right");
static_assert(offsetof(ABeanCharacter, GetupAnimationMontage_Back) == 0x6210, "Offset mismatch for ABeanCharacter::GetupAnimationMontage_Back");
static_assert(offsetof(ABeanCharacter, LandStaggerAnimationMontage) == 0x6230, "Offset mismatch for ABeanCharacter::LandStaggerAnimationMontage");
static_assert(offsetof(ABeanCharacter, LandStaggerAnimationMontageAlt) == 0x6250, "Offset mismatch for ABeanCharacter::LandStaggerAnimationMontageAlt");
static_assert(offsetof(ABeanCharacter, BackpackAllowList) == 0x6270, "Offset mismatch for ABeanCharacter::BackpackAllowList");
static_assert(offsetof(ABeanCharacter, bCharacterCosmeticsVisibility) == 0x6290, "Offset mismatch for ABeanCharacter::bCharacterCosmeticsVisibility");
static_assert(offsetof(ABeanCharacter, bBackpackCosmeticsVisibility) == 0x6291, "Offset mismatch for ABeanCharacter::bBackpackCosmeticsVisibility");
static_assert(offsetof(ABeanCharacter, IdleBreakBlockingTags) == 0x6298, "Offset mismatch for ABeanCharacter::IdleBreakBlockingTags");
static_assert(offsetof(ABeanCharacter, bEnableInventoryMode) == 0x62b8, "Offset mismatch for ABeanCharacter::bEnableInventoryMode");
static_assert(offsetof(ABeanCharacter, RetargetSourceMesh) == 0x62c0, "Offset mismatch for ABeanCharacter::RetargetSourceMesh");

// Size: 0x750 (Inherited: 0xea8, Single: 0xfffff8a8)
class UBeanCharAnimInstance : public UFortAnimInstance
{
public:
    bool bIsSimulatedProxy; // 0x5c8 (Size: 0x1, Type: BoolProperty)
    uint8_t UpperStateID; // 0x5c9 (Size: 0x1, Type: EnumProperty)
    uint8_t LowerStateID; // 0x5ca (Size: 0x1, Type: EnumProperty)
    uint8_t PrevLowerStateID; // 0x5cb (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EMovementMode> MovementMode; // 0x5cc (Size: 0x1, Type: ByteProperty)
    bool bIsMoving; // 0x5cd (Size: 0x1, Type: BoolProperty)
    bool bIsGrounded; // 0x5ce (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5cf[0x1]; // 0x5cf (Size: 0x1, Type: PaddingProperty)
    float TurningPercentage; // 0x5d0 (Size: 0x4, Type: FloatProperty)
    float SpeedPercentage; // 0x5d4 (Size: 0x4, Type: FloatProperty)
    FVector CurrentVelocity; // 0x5d8 (Size: 0x18, Type: StructProperty)
    bool bIsAnticipatingJumpLanding; // 0x5f0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5f1[0x7]; // 0x5f1 (Size: 0x7, Type: PaddingProperty)
    FVector LastRagdollImpactForce; // 0x5f8 (Size: 0x18, Type: StructProperty)
    FVector LastImpactForce; // 0x610 (Size: 0x18, Type: StructProperty)
    FVector LastImpactRelativeDirection; // 0x628 (Size: 0x18, Type: StructProperty)
    uint8_t TurnState; // 0x640 (Size: 0x1, Type: EnumProperty)
    bool bIsGrabbing; // 0x641 (Size: 0x1, Type: BoolProperty)
    bool bHasGrabTarget; // 0x642 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_643[0x1]; // 0x643 (Size: 0x1, Type: PaddingProperty)
    float GrabStumbleDuration; // 0x644 (Size: 0x4, Type: FloatProperty)
    FVector LeftHandIKPosition; // 0x648 (Size: 0x18, Type: StructProperty)
    FVector RightHandIKPosition; // 0x660 (Size: 0x18, Type: StructProperty)
    FRotator LeftHandIKRotation; // 0x678 (Size: 0x18, Type: StructProperty)
    FRotator RightHandIKRotation; // 0x690 (Size: 0x18, Type: StructProperty)
    float IKAlpha; // 0x6a8 (Size: 0x4, Type: FloatProperty)
    bool bUseImpactAnims; // 0x6ac (Size: 0x1, Type: BoolProperty)
    bool bImpactTriggered; // 0x6ad (Size: 0x1, Type: BoolProperty)
    uint8_t ImpactAnimType; // 0x6ae (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_6af[0x1]; // 0x6af (Size: 0x1, Type: PaddingProperty)
    float LowImpactUpperThresholdReciprocal; // 0x6b0 (Size: 0x4, Type: FloatProperty)
    float MediumImpactUpperThresholdReciprocal; // 0x6b4 (Size: 0x4, Type: FloatProperty)
    float HighImpactUpperThresholdReciprocal; // 0x6b8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_6bc[0x4]; // 0x6bc (Size: 0x4, Type: PaddingProperty)
    FRotator JiggleRotator0; // 0x6c0 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator1; // 0x6d8 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator2; // 0x6f0 (Size: 0x18, Type: StructProperty)
    bool bLowerStateUsesLocomotionAnim; // 0x708 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EFortWeaponCoreAnimation> WeaponCoreAnim; // 0x709 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_70a[0x2]; // 0x70a (Size: 0x2, Type: PaddingProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig; // 0x70c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_714[0x3c]; // 0x714 (Size: 0x3c, Type: PaddingProperty)

protected:
    UBeanCharConfigObject* GetConfig() const; // 0x112afdcc (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    ABeanCharacter* TryGetBeanCharacter() const; // 0x112b10a0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanCharAnimInstance) == 0x750, "Size mismatch for UBeanCharAnimInstance");
static_assert(offsetof(UBeanCharAnimInstance, bIsSimulatedProxy) == 0x5c8, "Offset mismatch for UBeanCharAnimInstance::bIsSimulatedProxy");
static_assert(offsetof(UBeanCharAnimInstance, UpperStateID) == 0x5c9, "Offset mismatch for UBeanCharAnimInstance::UpperStateID");
static_assert(offsetof(UBeanCharAnimInstance, LowerStateID) == 0x5ca, "Offset mismatch for UBeanCharAnimInstance::LowerStateID");
static_assert(offsetof(UBeanCharAnimInstance, PrevLowerStateID) == 0x5cb, "Offset mismatch for UBeanCharAnimInstance::PrevLowerStateID");
static_assert(offsetof(UBeanCharAnimInstance, MovementMode) == 0x5cc, "Offset mismatch for UBeanCharAnimInstance::MovementMode");
static_assert(offsetof(UBeanCharAnimInstance, bIsMoving) == 0x5cd, "Offset mismatch for UBeanCharAnimInstance::bIsMoving");
static_assert(offsetof(UBeanCharAnimInstance, bIsGrounded) == 0x5ce, "Offset mismatch for UBeanCharAnimInstance::bIsGrounded");
static_assert(offsetof(UBeanCharAnimInstance, TurningPercentage) == 0x5d0, "Offset mismatch for UBeanCharAnimInstance::TurningPercentage");
static_assert(offsetof(UBeanCharAnimInstance, SpeedPercentage) == 0x5d4, "Offset mismatch for UBeanCharAnimInstance::SpeedPercentage");
static_assert(offsetof(UBeanCharAnimInstance, CurrentVelocity) == 0x5d8, "Offset mismatch for UBeanCharAnimInstance::CurrentVelocity");
static_assert(offsetof(UBeanCharAnimInstance, bIsAnticipatingJumpLanding) == 0x5f0, "Offset mismatch for UBeanCharAnimInstance::bIsAnticipatingJumpLanding");
static_assert(offsetof(UBeanCharAnimInstance, LastRagdollImpactForce) == 0x5f8, "Offset mismatch for UBeanCharAnimInstance::LastRagdollImpactForce");
static_assert(offsetof(UBeanCharAnimInstance, LastImpactForce) == 0x610, "Offset mismatch for UBeanCharAnimInstance::LastImpactForce");
static_assert(offsetof(UBeanCharAnimInstance, LastImpactRelativeDirection) == 0x628, "Offset mismatch for UBeanCharAnimInstance::LastImpactRelativeDirection");
static_assert(offsetof(UBeanCharAnimInstance, TurnState) == 0x640, "Offset mismatch for UBeanCharAnimInstance::TurnState");
static_assert(offsetof(UBeanCharAnimInstance, bIsGrabbing) == 0x641, "Offset mismatch for UBeanCharAnimInstance::bIsGrabbing");
static_assert(offsetof(UBeanCharAnimInstance, bHasGrabTarget) == 0x642, "Offset mismatch for UBeanCharAnimInstance::bHasGrabTarget");
static_assert(offsetof(UBeanCharAnimInstance, GrabStumbleDuration) == 0x644, "Offset mismatch for UBeanCharAnimInstance::GrabStumbleDuration");
static_assert(offsetof(UBeanCharAnimInstance, LeftHandIKPosition) == 0x648, "Offset mismatch for UBeanCharAnimInstance::LeftHandIKPosition");
static_assert(offsetof(UBeanCharAnimInstance, RightHandIKPosition) == 0x660, "Offset mismatch for UBeanCharAnimInstance::RightHandIKPosition");
static_assert(offsetof(UBeanCharAnimInstance, LeftHandIKRotation) == 0x678, "Offset mismatch for UBeanCharAnimInstance::LeftHandIKRotation");
static_assert(offsetof(UBeanCharAnimInstance, RightHandIKRotation) == 0x690, "Offset mismatch for UBeanCharAnimInstance::RightHandIKRotation");
static_assert(offsetof(UBeanCharAnimInstance, IKAlpha) == 0x6a8, "Offset mismatch for UBeanCharAnimInstance::IKAlpha");
static_assert(offsetof(UBeanCharAnimInstance, bUseImpactAnims) == 0x6ac, "Offset mismatch for UBeanCharAnimInstance::bUseImpactAnims");
static_assert(offsetof(UBeanCharAnimInstance, bImpactTriggered) == 0x6ad, "Offset mismatch for UBeanCharAnimInstance::bImpactTriggered");
static_assert(offsetof(UBeanCharAnimInstance, ImpactAnimType) == 0x6ae, "Offset mismatch for UBeanCharAnimInstance::ImpactAnimType");
static_assert(offsetof(UBeanCharAnimInstance, LowImpactUpperThresholdReciprocal) == 0x6b0, "Offset mismatch for UBeanCharAnimInstance::LowImpactUpperThresholdReciprocal");
static_assert(offsetof(UBeanCharAnimInstance, MediumImpactUpperThresholdReciprocal) == 0x6b4, "Offset mismatch for UBeanCharAnimInstance::MediumImpactUpperThresholdReciprocal");
static_assert(offsetof(UBeanCharAnimInstance, HighImpactUpperThresholdReciprocal) == 0x6b8, "Offset mismatch for UBeanCharAnimInstance::HighImpactUpperThresholdReciprocal");
static_assert(offsetof(UBeanCharAnimInstance, JiggleRotator0) == 0x6c0, "Offset mismatch for UBeanCharAnimInstance::JiggleRotator0");
static_assert(offsetof(UBeanCharAnimInstance, JiggleRotator1) == 0x6d8, "Offset mismatch for UBeanCharAnimInstance::JiggleRotator1");
static_assert(offsetof(UBeanCharAnimInstance, JiggleRotator2) == 0x6f0, "Offset mismatch for UBeanCharAnimInstance::JiggleRotator2");
static_assert(offsetof(UBeanCharAnimInstance, bLowerStateUsesLocomotionAnim) == 0x708, "Offset mismatch for UBeanCharAnimInstance::bLowerStateUsesLocomotionAnim");
static_assert(offsetof(UBeanCharAnimInstance, WeaponCoreAnim) == 0x709, "Offset mismatch for UBeanCharAnimInstance::WeaponCoreAnim");
static_assert(offsetof(UBeanCharAnimInstance, BeanCharacterConfig) == 0x70c, "Offset mismatch for UBeanCharAnimInstance::BeanCharacterConfig");

// Size: 0x110 (Inherited: 0xe0, Single: 0x30)
class UBeanCharBeingGrabbedComponent : public UActorComponent
{
public:

public:
    FVector GetGrabbeeDragForce(float& DragDuration, const FVector LocationOffset) const; // 0x112afe34 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanCharBeingGrabbedComponent) == 0x110, "Size mismatch for UBeanCharBeingGrabbedComponent");

// Size: 0x128 (Inherited: 0xe0, Single: 0x48)
class UBeanCharCollisionManagerComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x58]; // 0xb8 (Size: 0x58, Type: PaddingProperty)
    double MaxConfigImpactThreshold; // 0x110 (Size: 0x8, Type: DoubleProperty)
    double NextImpactCueExecution; // 0x118 (Size: 0x8, Type: DoubleProperty)
    float RagdollThresholdMultiplier; // 0x120 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_124[0x4]; // 0x124 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBeanCharCollisionManagerComponent) == 0x128, "Size mismatch for UBeanCharCollisionManagerComponent");
static_assert(offsetof(UBeanCharCollisionManagerComponent, MaxConfigImpactThreshold) == 0x110, "Offset mismatch for UBeanCharCollisionManagerComponent::MaxConfigImpactThreshold");
static_assert(offsetof(UBeanCharCollisionManagerComponent, NextImpactCueExecution) == 0x118, "Offset mismatch for UBeanCharCollisionManagerComponent::NextImpactCueExecution");
static_assert(offsetof(UBeanCharCollisionManagerComponent, RagdollThresholdMultiplier) == 0x120, "Offset mismatch for UBeanCharCollisionManagerComponent::RagdollThresholdMultiplier");

// Size: 0x1d0 (Inherited: 0xe0, Single: 0xf0)
class UBeanCharGrabComponent : public UActorComponent
{
public:
    UAnimMontage* ArmsOutMontage; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    FVector LeftHandIKPosition; // 0xc0 (Size: 0x18, Type: StructProperty)
    FVector RightHandIKPosition; // 0xd8 (Size: 0x18, Type: StructProperty)
    FRotator LeftHandIKRotation; // 0xf0 (Size: 0x18, Type: StructProperty)
    FRotator RightHandIKRotation; // 0x108 (Size: 0x18, Type: StructProperty)
    float IKAlpha; // 0x120 (Size: 0x4, Type: FloatProperty)
    bool bHasIKTarget; // 0x124 (Size: 0x1, Type: BoolProperty)
    bool bIsGrabStumbling; // 0x125 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_126[0x22]; // 0x126 (Size: 0x22, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> GrabTarget; // 0x148 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_150[0x10]; // 0x150 (Size: 0x10, Type: PaddingProperty)
    float ServerLatestHoldStartTime; // 0x160 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_164[0x6c]; // 0x164 (Size: 0x6c, Type: PaddingProperty)

protected:
    FVector GetGrabberDragForce(float& DragDuration); // 0x112b0024 (Index: 0x0, Flags: Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure)
    void HandleOnPawnJumped(); // 0x112b02a8 (Index: 0x1, Flags: Final|Native|Protected)
    void OnRep_GrabTarget(); // 0x112b02f4 (Index: 0x2, Flags: Final|Native|Protected)
    void OnRep_ServerLatestHoldStartTime(); // 0x112b0308 (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(UBeanCharGrabComponent) == 0x1d0, "Size mismatch for UBeanCharGrabComponent");
static_assert(offsetof(UBeanCharGrabComponent, ArmsOutMontage) == 0xb8, "Offset mismatch for UBeanCharGrabComponent::ArmsOutMontage");
static_assert(offsetof(UBeanCharGrabComponent, LeftHandIKPosition) == 0xc0, "Offset mismatch for UBeanCharGrabComponent::LeftHandIKPosition");
static_assert(offsetof(UBeanCharGrabComponent, RightHandIKPosition) == 0xd8, "Offset mismatch for UBeanCharGrabComponent::RightHandIKPosition");
static_assert(offsetof(UBeanCharGrabComponent, LeftHandIKRotation) == 0xf0, "Offset mismatch for UBeanCharGrabComponent::LeftHandIKRotation");
static_assert(offsetof(UBeanCharGrabComponent, RightHandIKRotation) == 0x108, "Offset mismatch for UBeanCharGrabComponent::RightHandIKRotation");
static_assert(offsetof(UBeanCharGrabComponent, IKAlpha) == 0x120, "Offset mismatch for UBeanCharGrabComponent::IKAlpha");
static_assert(offsetof(UBeanCharGrabComponent, bHasIKTarget) == 0x124, "Offset mismatch for UBeanCharGrabComponent::bHasIKTarget");
static_assert(offsetof(UBeanCharGrabComponent, bIsGrabStumbling) == 0x125, "Offset mismatch for UBeanCharGrabComponent::bIsGrabStumbling");
static_assert(offsetof(UBeanCharGrabComponent, GrabTarget) == 0x148, "Offset mismatch for UBeanCharGrabComponent::GrabTarget");
static_assert(offsetof(UBeanCharGrabComponent, ServerLatestHoldStartTime) == 0x160, "Offset mismatch for UBeanCharGrabComponent::ServerLatestHoldStartTime");

// Size: 0x100 (Inherited: 0xe0, Single: 0x20)
class UBeanCharMantleComponent : public UActorComponent
{
public:
    FScalableFloat ClamberingEnabled; // 0xb8 (Size: 0x28, Type: StructProperty)
    TWeakObjectPtr<ABeanCharacter*> BeanCharacter; // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    float CachedClamberingEnabledValue; // 0xe8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_ec[0x4]; // 0xec (Size: 0x4, Type: PaddingProperty)
    double LastClamberingEnabledCacheTime; // 0xf0 (Size: 0x8, Type: DoubleProperty)
    double ClamberingEnableCacheInterval; // 0xf8 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(UBeanCharMantleComponent) == 0x100, "Size mismatch for UBeanCharMantleComponent");
static_assert(offsetof(UBeanCharMantleComponent, ClamberingEnabled) == 0xb8, "Offset mismatch for UBeanCharMantleComponent::ClamberingEnabled");
static_assert(offsetof(UBeanCharMantleComponent, BeanCharacter) == 0xe0, "Offset mismatch for UBeanCharMantleComponent::BeanCharacter");
static_assert(offsetof(UBeanCharMantleComponent, CachedClamberingEnabledValue) == 0xe8, "Offset mismatch for UBeanCharMantleComponent::CachedClamberingEnabledValue");
static_assert(offsetof(UBeanCharMantleComponent, LastClamberingEnabledCacheTime) == 0xf0, "Offset mismatch for UBeanCharMantleComponent::LastClamberingEnabledCacheTime");
static_assert(offsetof(UBeanCharMantleComponent, ClamberingEnableCacheInterval) == 0xf8, "Offset mismatch for UBeanCharMantleComponent::ClamberingEnableCacheInterval");

// Size: 0x6870 (Inherited: 0xc928, Single: 0xffff9f48)
class UBeanCharMovementComponent : public UFortMovementComp_CharacterAthena
{
public:
    uint8_t Pad_5d30[0xa14]; // 0x5d30 (Size: 0xa14, Type: PaddingProperty)
    float MovementBaseVelocitySamplingPeriod; // 0x6744 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UPrimitiveComponent*> CurrentSampledMovementBase; // 0x6748 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_6750[0x101]; // 0x6750 (Size: 0x101, Type: PaddingProperty)
    bool bAllowFloorHeightAdjustments; // 0x6851 (Size: 0x1, Type: BoolProperty)
    uint8_t TurnState; // 0x6852 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_6853[0xd]; // 0x6853 (Size: 0xd, Type: PaddingProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> CharConfig; // 0x6860 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_6868[0x8]; // 0x6868 (Size: 0x8, Type: PaddingProperty)

public:
    void ApplyKnockbackImpulse(const FVector Force); // 0x112af928 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    ABeanCharacter* GetBeanCharacter() const; // 0x112afd20 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EBeanCharTurn180State GetTurn180State() const; // 0x112b0290 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void ServerRequestPredictLaunch(UObject*& SourceObject, UObject*& SourceOptionalSubobject, FVector& const LaunchVector, float& MovementTimestamp); // 0x112b09c8 (Index: 0x4, Flags: Net|Native|Event|Public|NetServer|HasDefaults)
    void SetTurn180State(EBeanCharTurn180State& NewTurnState); // 0x112b0df8 (Index: 0x6, Flags: Final|Native|Public)

private:
    virtual void ServerSuggestImpartedMovementBaseVelocity(FVector& const ImpartedVelocity, float& Timestamp); // 0x112b0cb0 (Index: 0x5, Flags: Final|Net|Native|Event|Private|NetServer|HasDefaults)

protected:
    virtual void Server_SetDebugForceCorrection(EBeanDebugForceCorrectionMode& Mode); // 0xcf8da58 (Index: 0x3, Flags: Net|Native|Event|Protected|NetServer)
};

static_assert(sizeof(UBeanCharMovementComponent) == 0x6870, "Size mismatch for UBeanCharMovementComponent");
static_assert(offsetof(UBeanCharMovementComponent, MovementBaseVelocitySamplingPeriod) == 0x6744, "Offset mismatch for UBeanCharMovementComponent::MovementBaseVelocitySamplingPeriod");
static_assert(offsetof(UBeanCharMovementComponent, CurrentSampledMovementBase) == 0x6748, "Offset mismatch for UBeanCharMovementComponent::CurrentSampledMovementBase");
static_assert(offsetof(UBeanCharMovementComponent, bAllowFloorHeightAdjustments) == 0x6851, "Offset mismatch for UBeanCharMovementComponent::bAllowFloorHeightAdjustments");
static_assert(offsetof(UBeanCharMovementComponent, TurnState) == 0x6852, "Offset mismatch for UBeanCharMovementComponent::TurnState");
static_assert(offsetof(UBeanCharMovementComponent, CharConfig) == 0x6860, "Offset mismatch for UBeanCharMovementComponent::CharConfig");

// Size: 0x470 (Inherited: 0xe0, Single: 0x390)
class UBeanCharRagdollComponent : public UActorComponent
{
public:
    FComponentReference PhysicsConstraintComponentReference; // 0xb8 (Size: 0x28, Type: StructProperty)
    FComponentReference RootPrimitiveReference; // 0xe0 (Size: 0x28, Type: StructProperty)
    FComponentReference SkeletalMeshReference; // 0x108 (Size: 0x28, Type: StructProperty)
    bool bEnableInputControlCurve; // 0x130 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_131[0x7]; // 0x131 (Size: 0x7, Type: PaddingProperty)
    FRuntimeFloatCurve RagdollInputControlWithTimeCurve; // 0x138 (Size: 0x88, Type: StructProperty)
    uint8_t Pad_1c0[0x1]; // 0x1c0 (Size: 0x1, Type: PaddingProperty)
    bool bIsConfiguredCorrectly; // 0x1c1 (Size: 0x1, Type: BoolProperty)
    bool bHasRequestedRagdollExit; // 0x1c2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1c3[0xd]; // 0x1c3 (Size: 0xd, Type: PaddingProperty)
    FTransform StartingMeshTransform; // 0x1d0 (Size: 0x60, Type: StructProperty)
    FCollisionResponseContainer OriginalActorRootCollisionResponse; // 0x230 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_250[0x48]; // 0x250 (Size: 0x48, Type: PaddingProperty)
    FVector RagdollControlInputVector; // 0x298 (Size: 0x18, Type: StructProperty)
    bool bIsRagdollGrounded; // 0x2b0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b1[0x3]; // 0x2b1 (Size: 0x3, Type: PaddingProperty)
    float TimeOnGround; // 0x2b4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2b8[0x10]; // 0x2b8 (Size: 0x10, Type: PaddingProperty)
    FVector LatestRagdollFloorOffset; // 0x2c8 (Size: 0x18, Type: StructProperty)
    FVector LatestRagdollFloorNormal; // 0x2e0 (Size: 0x18, Type: StructProperty)
    FBeanCharRagdollImpactData CurrentImpactData; // 0x2f8 (Size: 0x40, Type: StructProperty)
    float CurrentGravityZOverride; // 0x338 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_33c[0x4]; // 0x33c (Size: 0x4, Type: PaddingProperty)
    FVector CurrentAdditionalGravity; // 0x340 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_358[0x10]; // 0x358 (Size: 0x10, Type: PaddingProperty)
    TArray<int32_t> CachedMeshBodyIndexesForCCD; // 0x368 (Size: 0x10, Type: ArrayProperty)
    double LowerLinearDistanceTarget; // 0x378 (Size: 0x8, Type: DoubleProperty)
    double UpperLinearDistanceTarget; // 0x380 (Size: 0x8, Type: DoubleProperty)
    float DefaultHardSnapLinearDistance; // 0x388 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_38c[0x4]; // 0x38c (Size: 0x4, Type: PaddingProperty)
    double MaxHardsnapLinearDistance; // 0x390 (Size: 0x8, Type: DoubleProperty)
    bool bHasAddedIgnoredObjects; // 0x398 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_399[0xaf]; // 0x399 (Size: 0xaf, Type: PaddingProperty)
    FBeanRagdollDebugComponentHistory RagdollComponentHistory; // 0x448 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_468[0x8]; // 0x468 (Size: 0x8, Type: PaddingProperty)

public:
    void ApplyImpulse(const FVector Force, bool& bIsLaunch); // 0x112b1cb4 (Index: 0x0, Flags: Native|Public|HasOutParms|HasDefaults)
    void CleanupRagdollForAbruptExit(); // 0xc019b98 (Index: 0x1, Flags: Native|Public)
    void RequestRagdollExit(); // 0xb4a85b4 (Index: 0x5, Flags: Native|Public)
    virtual void ServerRPCRagdollControlInput(FVector& InputVector); // 0x112b34e8 (Index: 0x7, Flags: Net|Native|Event|Public|NetServer|HasDefaults)
    void SetRagdollEnabled(bool& bShouldEnable); // 0xafcc250 (Index: 0x8, Flags: Native|Public)

protected:
    virtual void Client_CleanupRagdollForAbruptExit(); // 0x112b2070 (Index: 0x2, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void Client_SignalRagdollExit(FVector& const EndLocation, FQuat& const EndRotation, FVector& const EndVelocity); // 0x112b2468 (Index: 0x3, Flags: Net|NetReliableNative|Event|Protected|HasDefaults|NetClient)
    void OnRagdollRootPrimitiveHit(UPrimitiveComponent*& HitComp, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, FVector& NormalImpulse, const FHitResult Hit); // 0x112b3098 (Index: 0x4, Flags: Final|Native|Protected|HasOutParms|HasDefaults)
    virtual void Server_SignalClientExitedRagdoll(); // 0xb4a8804 (Index: 0x6, Flags: Net|NetReliableNative|Event|Protected|NetServer)
};

static_assert(sizeof(UBeanCharRagdollComponent) == 0x470, "Size mismatch for UBeanCharRagdollComponent");
static_assert(offsetof(UBeanCharRagdollComponent, PhysicsConstraintComponentReference) == 0xb8, "Offset mismatch for UBeanCharRagdollComponent::PhysicsConstraintComponentReference");
static_assert(offsetof(UBeanCharRagdollComponent, RootPrimitiveReference) == 0xe0, "Offset mismatch for UBeanCharRagdollComponent::RootPrimitiveReference");
static_assert(offsetof(UBeanCharRagdollComponent, SkeletalMeshReference) == 0x108, "Offset mismatch for UBeanCharRagdollComponent::SkeletalMeshReference");
static_assert(offsetof(UBeanCharRagdollComponent, bEnableInputControlCurve) == 0x130, "Offset mismatch for UBeanCharRagdollComponent::bEnableInputControlCurve");
static_assert(offsetof(UBeanCharRagdollComponent, RagdollInputControlWithTimeCurve) == 0x138, "Offset mismatch for UBeanCharRagdollComponent::RagdollInputControlWithTimeCurve");
static_assert(offsetof(UBeanCharRagdollComponent, bIsConfiguredCorrectly) == 0x1c1, "Offset mismatch for UBeanCharRagdollComponent::bIsConfiguredCorrectly");
static_assert(offsetof(UBeanCharRagdollComponent, bHasRequestedRagdollExit) == 0x1c2, "Offset mismatch for UBeanCharRagdollComponent::bHasRequestedRagdollExit");
static_assert(offsetof(UBeanCharRagdollComponent, StartingMeshTransform) == 0x1d0, "Offset mismatch for UBeanCharRagdollComponent::StartingMeshTransform");
static_assert(offsetof(UBeanCharRagdollComponent, OriginalActorRootCollisionResponse) == 0x230, "Offset mismatch for UBeanCharRagdollComponent::OriginalActorRootCollisionResponse");
static_assert(offsetof(UBeanCharRagdollComponent, RagdollControlInputVector) == 0x298, "Offset mismatch for UBeanCharRagdollComponent::RagdollControlInputVector");
static_assert(offsetof(UBeanCharRagdollComponent, bIsRagdollGrounded) == 0x2b0, "Offset mismatch for UBeanCharRagdollComponent::bIsRagdollGrounded");
static_assert(offsetof(UBeanCharRagdollComponent, TimeOnGround) == 0x2b4, "Offset mismatch for UBeanCharRagdollComponent::TimeOnGround");
static_assert(offsetof(UBeanCharRagdollComponent, LatestRagdollFloorOffset) == 0x2c8, "Offset mismatch for UBeanCharRagdollComponent::LatestRagdollFloorOffset");
static_assert(offsetof(UBeanCharRagdollComponent, LatestRagdollFloorNormal) == 0x2e0, "Offset mismatch for UBeanCharRagdollComponent::LatestRagdollFloorNormal");
static_assert(offsetof(UBeanCharRagdollComponent, CurrentImpactData) == 0x2f8, "Offset mismatch for UBeanCharRagdollComponent::CurrentImpactData");
static_assert(offsetof(UBeanCharRagdollComponent, CurrentGravityZOverride) == 0x338, "Offset mismatch for UBeanCharRagdollComponent::CurrentGravityZOverride");
static_assert(offsetof(UBeanCharRagdollComponent, CurrentAdditionalGravity) == 0x340, "Offset mismatch for UBeanCharRagdollComponent::CurrentAdditionalGravity");
static_assert(offsetof(UBeanCharRagdollComponent, CachedMeshBodyIndexesForCCD) == 0x368, "Offset mismatch for UBeanCharRagdollComponent::CachedMeshBodyIndexesForCCD");
static_assert(offsetof(UBeanCharRagdollComponent, LowerLinearDistanceTarget) == 0x378, "Offset mismatch for UBeanCharRagdollComponent::LowerLinearDistanceTarget");
static_assert(offsetof(UBeanCharRagdollComponent, UpperLinearDistanceTarget) == 0x380, "Offset mismatch for UBeanCharRagdollComponent::UpperLinearDistanceTarget");
static_assert(offsetof(UBeanCharRagdollComponent, DefaultHardSnapLinearDistance) == 0x388, "Offset mismatch for UBeanCharRagdollComponent::DefaultHardSnapLinearDistance");
static_assert(offsetof(UBeanCharRagdollComponent, MaxHardsnapLinearDistance) == 0x390, "Offset mismatch for UBeanCharRagdollComponent::MaxHardsnapLinearDistance");
static_assert(offsetof(UBeanCharRagdollComponent, bHasAddedIgnoredObjects) == 0x398, "Offset mismatch for UBeanCharRagdollComponent::bHasAddedIgnoredObjects");
static_assert(offsetof(UBeanCharRagdollComponent, RagdollComponentHistory) == 0x448, "Offset mismatch for UBeanCharRagdollComponent::RagdollComponentHistory");

// Size: 0x198 (Inherited: 0x28, Single: 0x170)
class UBeanCharStateBase : public UObject
{
public:
    uint8_t StateId; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t LayerMask; // 0x29 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EMovementMode> MovementMode; // 0x2a (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EFortCustomMovement> FortCustomMovementMode; // 0x2b (Size: 0x1, Type: ByteProperty)
    FGameplayTag GameplayTag; // 0x2c (Size: 0x4, Type: StructProperty)
    FGameplayCueTag GameplayCue; // 0x30 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    FGameplayCueParameters GameplayCueParameters; // 0x38 (Size: 0xd0, Type: StructProperty)
    bool bShouldSetMovementMode; // 0x108 (Size: 0x1, Type: BoolProperty)
    bool bReplicateToSimulatedProxies; // 0x109 (Size: 0x1, Type: BoolProperty)
    bool bExecuteCodeOnSimulatedProxies; // 0x10a (Size: 0x1, Type: BoolProperty)
    bool bTryActivateFailsIfAlreadyActive; // 0x10b (Size: 0x1, Type: BoolProperty)
    bool bServerMustFlushStateManually; // 0x10c (Size: 0x1, Type: BoolProperty)
    bool bFlushPendingStateChangesOnStateExit; // 0x10d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_10e[0x2]; // 0x10e (Size: 0x2, Type: PaddingProperty)
    float Priority; // 0x110 (Size: 0x4, Type: FloatProperty)
    bool bShouldRemainVertical; // 0x114 (Size: 0x1, Type: BoolProperty)
    bool bCanPerformMantle; // 0x115 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_116[0x2]; // 0x116 (Size: 0x2, Type: PaddingProperty)
    float DecelerationOverride; // 0x118 (Size: 0x4, Type: FloatProperty)
    bool bPauseJiggleCalculations; // 0x11c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11d[0x3]; // 0x11d (Size: 0x3, Type: PaddingProperty)
    UBeanCharStateMachine* OwnerStateMachine; // 0x120 (Size: 0x8, Type: ObjectProperty)
    TArray<uint16_t> RootMotionSourceIDs; // 0x128 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer GrantedTags; // 0x138 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockedTags; // 0x158 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockedAbilityTags; // 0x178 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UBeanCharStateBase) == 0x198, "Size mismatch for UBeanCharStateBase");
static_assert(offsetof(UBeanCharStateBase, StateId) == 0x28, "Offset mismatch for UBeanCharStateBase::StateId");
static_assert(offsetof(UBeanCharStateBase, LayerMask) == 0x29, "Offset mismatch for UBeanCharStateBase::LayerMask");
static_assert(offsetof(UBeanCharStateBase, MovementMode) == 0x2a, "Offset mismatch for UBeanCharStateBase::MovementMode");
static_assert(offsetof(UBeanCharStateBase, FortCustomMovementMode) == 0x2b, "Offset mismatch for UBeanCharStateBase::FortCustomMovementMode");
static_assert(offsetof(UBeanCharStateBase, GameplayTag) == 0x2c, "Offset mismatch for UBeanCharStateBase::GameplayTag");
static_assert(offsetof(UBeanCharStateBase, GameplayCue) == 0x30, "Offset mismatch for UBeanCharStateBase::GameplayCue");
static_assert(offsetof(UBeanCharStateBase, GameplayCueParameters) == 0x38, "Offset mismatch for UBeanCharStateBase::GameplayCueParameters");
static_assert(offsetof(UBeanCharStateBase, bShouldSetMovementMode) == 0x108, "Offset mismatch for UBeanCharStateBase::bShouldSetMovementMode");
static_assert(offsetof(UBeanCharStateBase, bReplicateToSimulatedProxies) == 0x109, "Offset mismatch for UBeanCharStateBase::bReplicateToSimulatedProxies");
static_assert(offsetof(UBeanCharStateBase, bExecuteCodeOnSimulatedProxies) == 0x10a, "Offset mismatch for UBeanCharStateBase::bExecuteCodeOnSimulatedProxies");
static_assert(offsetof(UBeanCharStateBase, bTryActivateFailsIfAlreadyActive) == 0x10b, "Offset mismatch for UBeanCharStateBase::bTryActivateFailsIfAlreadyActive");
static_assert(offsetof(UBeanCharStateBase, bServerMustFlushStateManually) == 0x10c, "Offset mismatch for UBeanCharStateBase::bServerMustFlushStateManually");
static_assert(offsetof(UBeanCharStateBase, bFlushPendingStateChangesOnStateExit) == 0x10d, "Offset mismatch for UBeanCharStateBase::bFlushPendingStateChangesOnStateExit");
static_assert(offsetof(UBeanCharStateBase, Priority) == 0x110, "Offset mismatch for UBeanCharStateBase::Priority");
static_assert(offsetof(UBeanCharStateBase, bShouldRemainVertical) == 0x114, "Offset mismatch for UBeanCharStateBase::bShouldRemainVertical");
static_assert(offsetof(UBeanCharStateBase, bCanPerformMantle) == 0x115, "Offset mismatch for UBeanCharStateBase::bCanPerformMantle");
static_assert(offsetof(UBeanCharStateBase, DecelerationOverride) == 0x118, "Offset mismatch for UBeanCharStateBase::DecelerationOverride");
static_assert(offsetof(UBeanCharStateBase, bPauseJiggleCalculations) == 0x11c, "Offset mismatch for UBeanCharStateBase::bPauseJiggleCalculations");
static_assert(offsetof(UBeanCharStateBase, OwnerStateMachine) == 0x120, "Offset mismatch for UBeanCharStateBase::OwnerStateMachine");
static_assert(offsetof(UBeanCharStateBase, RootMotionSourceIDs) == 0x128, "Offset mismatch for UBeanCharStateBase::RootMotionSourceIDs");
static_assert(offsetof(UBeanCharStateBase, GrantedTags) == 0x138, "Offset mismatch for UBeanCharStateBase::GrantedTags");
static_assert(offsetof(UBeanCharStateBase, BlockedTags) == 0x158, "Offset mismatch for UBeanCharStateBase::BlockedTags");
static_assert(offsetof(UBeanCharStateBase, BlockedAbilityTags) == 0x178, "Offset mismatch for UBeanCharStateBase::BlockedAbilityTags");

// Size: 0x218 (Inherited: 0xe0, Single: 0x138)
class UBeanCharStateMachine : public UActorComponent
{
public:
    bool bIsInitialized; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
    FBeanCharStateMachineContext Layers[0x2]; // 0xc0 (Size: 0x80, Type: StructProperty)
    uint8_t Pad_140[0x28]; // 0x140 (Size: 0x28, Type: PaddingProperty)
    TArray<UBeanCharStateBase*> TempTickStateList; // 0x168 (Size: 0x10, Type: ArrayProperty)
    TArray<UBeanCharStateBase*> States; // 0x178 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_188[0x10]; // 0x188 (Size: 0x10, Type: PaddingProperty)
    bool bFlushMoveToServerAtEndOfFrame; // 0x198 (Size: 0x1, Type: BoolProperty)
    bool bFlushPendingStateChangesAtEndOfFrame; // 0x199 (Size: 0x1, Type: BoolProperty)
    bool bIsReplaying; // 0x19a (Size: 0x1, Type: BoolProperty)
    uint8_t ServerForceSetUpperState; // 0x19b (Size: 0x1, Type: EnumProperty)
    uint8_t ServerForceSetLowerState; // 0x19c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_19d[0x1]; // 0x19d (Size: 0x1, Type: PaddingProperty)
    uint16_t SimulatedProxyStateData; // 0x19e (Size: 0x2, Type: UInt16Property)
    uint32_t AutonomousProxyServerStateData; // 0x1a0 (Size: 0x4, Type: UInt32Property)
    char StateSyncID; // 0x1a4 (Size: 0x1, Type: ByteProperty)
    char ServerStateSyncID; // 0x1a5 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1a6[0x2]; // 0x1a6 (Size: 0x2, Type: PaddingProperty)
    TArray<FBeanStateHistoryItem> AutonomousProxyStateHistory; // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    float AutonomousProxyServerStateCheckTimer; // 0x1b8 (Size: 0x4, Type: FloatProperty)
    float RequestClientStateChangeTimeout; // 0x1bc (Size: 0x4, Type: FloatProperty)
    uint8_t RequestClientStateChangePendingStateID; // 0x1c0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1c1[0x7]; // 0x1c1 (Size: 0x7, Type: PaddingProperty)
    TArray<FBeanStateGameplayTagsDefinition> StateTagsDefinitions; // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    UClass* AnimLayer_Swimming; // 0x1d8 (Size: 0x8, Type: ClassProperty)
    UClass* AnimLayer_Ragdoll; // 0x1e0 (Size: 0x8, Type: ClassProperty)
    UClass* AnimLayer_Zipline; // 0x1e8 (Size: 0x8, Type: ClassProperty)
    UClass* AnimLayer_Flying; // 0x1f0 (Size: 0x8, Type: ClassProperty)
    UClass* AnimLayer_Grab; // 0x1f8 (Size: 0x8, Type: ClassProperty)
    UClass* AnimLayer_EditMode; // 0x200 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_208[0x10]; // 0x208 (Size: 0x10, Type: PaddingProperty)

public:
    void Debug_RequestClientChangesState(EBeanCharStateID& StateId); // 0x112b2654 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    UClass* GetState(EBeanCharStateLayerID& LayerId) const; // 0x112b27ac (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStateActiveDuration(EBeanCharStateID& StateId) const; // 0x112b2c08 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EBeanCharStateID GetStateId(EBeanCharStateLayerID& LayerId) const; // 0x112b2d4c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    virtual void ClientRPC_RequestClientChangesState(EBeanCharStateID& StateId, FVector& Location, FRotator& Rotation); // 0x112b1e34 (Index: 0x1, Flags: Final|Net|Native|Event|Private|HasDefaults|NetClient)
    void OnRep_AutonomousProxyStateData(); // 0x112b34c0 (Index: 0x6, Flags: Final|Native|Private)
    void OnRep_SimulatedProxyStateData(); // 0x112b34d4 (Index: 0x7, Flags: Final|Native|Private)
    virtual void ServerRPC_RequestClientChangeStateResponse(EBeanCharStateID& StateId); // 0x2a47b80 (Index: 0x8, Flags: Final|Net|Native|Event|Private|NetServer)

protected:
    virtual void Client_ForceSetState(EBeanCharStateID& StateUP, EBeanCharStateID& StateLW, char& SyncId, bool& bResetPredictionData); // 0x112b20b0 (Index: 0x0, Flags: Net|NetReliableNative|Event|Protected|NetClient)
};

static_assert(sizeof(UBeanCharStateMachine) == 0x218, "Size mismatch for UBeanCharStateMachine");
static_assert(offsetof(UBeanCharStateMachine, bIsInitialized) == 0xb8, "Offset mismatch for UBeanCharStateMachine::bIsInitialized");
static_assert(offsetof(UBeanCharStateMachine, Layers) == 0xc0, "Offset mismatch for UBeanCharStateMachine::Layers");
static_assert(offsetof(UBeanCharStateMachine, TempTickStateList) == 0x168, "Offset mismatch for UBeanCharStateMachine::TempTickStateList");
static_assert(offsetof(UBeanCharStateMachine, States) == 0x178, "Offset mismatch for UBeanCharStateMachine::States");
static_assert(offsetof(UBeanCharStateMachine, bFlushMoveToServerAtEndOfFrame) == 0x198, "Offset mismatch for UBeanCharStateMachine::bFlushMoveToServerAtEndOfFrame");
static_assert(offsetof(UBeanCharStateMachine, bFlushPendingStateChangesAtEndOfFrame) == 0x199, "Offset mismatch for UBeanCharStateMachine::bFlushPendingStateChangesAtEndOfFrame");
static_assert(offsetof(UBeanCharStateMachine, bIsReplaying) == 0x19a, "Offset mismatch for UBeanCharStateMachine::bIsReplaying");
static_assert(offsetof(UBeanCharStateMachine, ServerForceSetUpperState) == 0x19b, "Offset mismatch for UBeanCharStateMachine::ServerForceSetUpperState");
static_assert(offsetof(UBeanCharStateMachine, ServerForceSetLowerState) == 0x19c, "Offset mismatch for UBeanCharStateMachine::ServerForceSetLowerState");
static_assert(offsetof(UBeanCharStateMachine, SimulatedProxyStateData) == 0x19e, "Offset mismatch for UBeanCharStateMachine::SimulatedProxyStateData");
static_assert(offsetof(UBeanCharStateMachine, AutonomousProxyServerStateData) == 0x1a0, "Offset mismatch for UBeanCharStateMachine::AutonomousProxyServerStateData");
static_assert(offsetof(UBeanCharStateMachine, StateSyncID) == 0x1a4, "Offset mismatch for UBeanCharStateMachine::StateSyncID");
static_assert(offsetof(UBeanCharStateMachine, ServerStateSyncID) == 0x1a5, "Offset mismatch for UBeanCharStateMachine::ServerStateSyncID");
static_assert(offsetof(UBeanCharStateMachine, AutonomousProxyStateHistory) == 0x1a8, "Offset mismatch for UBeanCharStateMachine::AutonomousProxyStateHistory");
static_assert(offsetof(UBeanCharStateMachine, AutonomousProxyServerStateCheckTimer) == 0x1b8, "Offset mismatch for UBeanCharStateMachine::AutonomousProxyServerStateCheckTimer");
static_assert(offsetof(UBeanCharStateMachine, RequestClientStateChangeTimeout) == 0x1bc, "Offset mismatch for UBeanCharStateMachine::RequestClientStateChangeTimeout");
static_assert(offsetof(UBeanCharStateMachine, RequestClientStateChangePendingStateID) == 0x1c0, "Offset mismatch for UBeanCharStateMachine::RequestClientStateChangePendingStateID");
static_assert(offsetof(UBeanCharStateMachine, StateTagsDefinitions) == 0x1c8, "Offset mismatch for UBeanCharStateMachine::StateTagsDefinitions");
static_assert(offsetof(UBeanCharStateMachine, AnimLayer_Swimming) == 0x1d8, "Offset mismatch for UBeanCharStateMachine::AnimLayer_Swimming");
static_assert(offsetof(UBeanCharStateMachine, AnimLayer_Ragdoll) == 0x1e0, "Offset mismatch for UBeanCharStateMachine::AnimLayer_Ragdoll");
static_assert(offsetof(UBeanCharStateMachine, AnimLayer_Zipline) == 0x1e8, "Offset mismatch for UBeanCharStateMachine::AnimLayer_Zipline");
static_assert(offsetof(UBeanCharStateMachine, AnimLayer_Flying) == 0x1f0, "Offset mismatch for UBeanCharStateMachine::AnimLayer_Flying");
static_assert(offsetof(UBeanCharStateMachine, AnimLayer_Grab) == 0x1f8, "Offset mismatch for UBeanCharStateMachine::AnimLayer_Grab");
static_assert(offsetof(UBeanCharStateMachine, AnimLayer_EditMode) == 0x200, "Offset mismatch for UBeanCharStateMachine::AnimLayer_EditMode");

// Size: 0x1a0 (Inherited: 0x1c0, Single: 0xffffffe0)
class UBeanCharState_Dive : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_Dive) == 0x1a0, "Size mismatch for UBeanCharState_Dive");

// Size: 0x1a0 (Inherited: 0x1c0, Single: 0xffffffe0)
class UBeanCharState_Emote : public UBeanCharStateBase
{
public:

private:
    void OnEmoteFinishedCallback(int32_t& EmoteIndex, bool& bWasInterruption); // 0x112b2e84 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UBeanCharState_Emote) == 0x1a0, "Size mismatch for UBeanCharState_Emote");

// Size: 0x1a0 (Inherited: 0x1c0, Single: 0xffffffe0)
class UBeanCharState_Falling : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_Falling) == 0x1a0, "Size mismatch for UBeanCharState_Falling");

// Size: 0x198 (Inherited: 0x1c0, Single: 0xffffffd8)
class UBeanCharState_Flying : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_Flying) == 0x198, "Size mismatch for UBeanCharState_Flying");

// Size: 0x230 (Inherited: 0x1c0, Single: 0x70)
class UBeanCharState_Getup : public UBeanCharStateBase
{
public:
    uint8_t Pad_198[0x50]; // 0x198 (Size: 0x50, Type: PaddingProperty)
    UAnimMontage* ActiveAnim; // 0x1e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1f0[0x40]; // 0x1f0 (Size: 0x40, Type: PaddingProperty)
};

static_assert(sizeof(UBeanCharState_Getup) == 0x230, "Size mismatch for UBeanCharState_Getup");
static_assert(offsetof(UBeanCharState_Getup, ActiveAnim) == 0x1e8, "Offset mismatch for UBeanCharState_Getup::ActiveAnim");

// Size: 0x1e0 (Inherited: 0x1c0, Single: 0x20)
class UBeanCharState_GetupRoll : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_GetupRoll) == 0x1e0, "Size mismatch for UBeanCharState_GetupRoll");

// Size: 0x198 (Inherited: 0x1c0, Single: 0xffffffd8)
class UBeanCharState_Grab : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_Grab) == 0x198, "Size mismatch for UBeanCharState_Grab");

// Size: 0x198 (Inherited: 0x1c0, Single: 0xffffffd8)
class UBeanCharState_GrabStumble : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_GrabStumble) == 0x198, "Size mismatch for UBeanCharState_GrabStumble");

// Size: 0x1b8 (Inherited: 0x1c0, Single: 0xfffffff8)
class UBeanCharState_Grounded : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_Grounded) == 0x1b8, "Size mismatch for UBeanCharState_Grounded");

// Size: 0x1f8 (Inherited: 0x1c0, Single: 0x38)
class UBeanCharState_Jostle : public UBeanCharStateBase
{
public:
    FVector SeparationForce; // 0x198 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_1b0[0x48]; // 0x1b0 (Size: 0x48, Type: PaddingProperty)
};

static_assert(sizeof(UBeanCharState_Jostle) == 0x1f8, "Size mismatch for UBeanCharState_Jostle");
static_assert(offsetof(UBeanCharState_Jostle, SeparationForce) == 0x198, "Offset mismatch for UBeanCharState_Jostle::SeparationForce");

// Size: 0x1b0 (Inherited: 0x1c0, Single: 0xfffffff0)
class UBeanCharState_Jump : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_Jump) == 0x1b0, "Size mismatch for UBeanCharState_Jump");

// Size: 0x1e8 (Inherited: 0x1c0, Single: 0x28)
class UBeanCharState_Mantle : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_Mantle) == 0x1e8, "Size mismatch for UBeanCharState_Mantle");

// Size: 0x1c0 (Inherited: 0x1c0, Single: 0x0)
class UBeanCharState_Ragdoll : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_Ragdoll) == 0x1c0, "Size mismatch for UBeanCharState_Ragdoll");

// Size: 0x1a0 (Inherited: 0x1c0, Single: 0xffffffe0)
class UBeanCharState_Roll : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_Roll) == 0x1a0, "Size mismatch for UBeanCharState_Roll");

// Size: 0x1a8 (Inherited: 0x1c0, Single: 0xffffffe8)
class UBeanCharState_Staggered : public UBeanCharStateBase
{
public:
    uint8_t Pad_198[0x8]; // 0x198 (Size: 0x8, Type: PaddingProperty)
    UAnimMontage* CurrentMontage; // 0x1a0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UBeanCharState_Staggered) == 0x1a8, "Size mismatch for UBeanCharState_Staggered");
static_assert(offsetof(UBeanCharState_Staggered, CurrentMontage) == 0x1a0, "Offset mismatch for UBeanCharState_Staggered::CurrentMontage");

// Size: 0x198 (Inherited: 0x1c0, Single: 0xffffffd8)
class UBeanCharState_SurfaceSwimming : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_SurfaceSwimming) == 0x198, "Size mismatch for UBeanCharState_SurfaceSwimming");

// Size: 0x1b0 (Inherited: 0x370, Single: 0xfffffe40)
class UBeanCharState_WaterJump : public UBeanCharState_Jump
{
public:
};

static_assert(sizeof(UBeanCharState_WaterJump) == 0x1b0, "Size mismatch for UBeanCharState_WaterJump");

// Size: 0x198 (Inherited: 0x1c0, Single: 0xffffffd8)
class UBeanCharState_Zipline : public UBeanCharStateBase
{
public:
};

static_assert(sizeof(UBeanCharState_Zipline) == 0x198, "Size mismatch for UBeanCharState_Zipline");

// Size: 0x3f0 (Inherited: 0x408, Single: 0xffffffe8)
class UBeanChar_EditMode_AnimLayer : public UAnimInstance
{
public:
    TEnumAsByte<EFortWeaponCoreAnimation> WeaponCoreAnim; // 0x3d8 (Size: 0x1, Type: ByteProperty)
    bool bIsMoving; // 0x3d9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3da[0x2]; // 0x3da (Size: 0x2, Type: PaddingProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig; // 0x3dc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_3e4[0xc]; // 0x3e4 (Size: 0xc, Type: PaddingProperty)

protected:
    UBeanCharConfigObject* GetConfig() const; // 0x112b2780 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    ABeanCharacter* TryGetBeanCharacter() const; // 0x112b10a0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanChar_EditMode_AnimLayer) == 0x3f0, "Size mismatch for UBeanChar_EditMode_AnimLayer");
static_assert(offsetof(UBeanChar_EditMode_AnimLayer, WeaponCoreAnim) == 0x3d8, "Offset mismatch for UBeanChar_EditMode_AnimLayer::WeaponCoreAnim");
static_assert(offsetof(UBeanChar_EditMode_AnimLayer, bIsMoving) == 0x3d9, "Offset mismatch for UBeanChar_EditMode_AnimLayer::bIsMoving");
static_assert(offsetof(UBeanChar_EditMode_AnimLayer, BeanCharacterConfig) == 0x3dc, "Offset mismatch for UBeanChar_EditMode_AnimLayer::BeanCharacterConfig");

// Size: 0x3e0 (Inherited: 0x408, Single: 0xffffffd8)
class UBeanChar_Flying_AnimLayer : public UAnimInstance
{
public:
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig; // 0x3d8 (Size: 0x8, Type: WeakObjectProperty)

protected:
    UBeanCharConfigObject* GetConfig() const; // 0x112b443c (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    ABeanCharacter* TryGetBeanCharacter() const; // 0x112b10a0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanChar_Flying_AnimLayer) == 0x3e0, "Size mismatch for UBeanChar_Flying_AnimLayer");
static_assert(offsetof(UBeanChar_Flying_AnimLayer, BeanCharacterConfig) == 0x3d8, "Offset mismatch for UBeanChar_Flying_AnimLayer::BeanCharacterConfig");

// Size: 0x450 (Inherited: 0x408, Single: 0x48)
class UBeanChar_Grab_AnimLayer : public UAnimInstance
{
public:
    bool bHasGrabTarget; // 0x3d8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3d9[0x3]; // 0x3d9 (Size: 0x3, Type: PaddingProperty)
    float GrabStumbleDuration; // 0x3dc (Size: 0x4, Type: FloatProperty)
    FVector LeftHandIKPosition; // 0x3e0 (Size: 0x18, Type: StructProperty)
    FVector RightHandIKPosition; // 0x3f8 (Size: 0x18, Type: StructProperty)
    FRotator LeftHandIKRotation; // 0x410 (Size: 0x18, Type: StructProperty)
    FRotator RightHandIKRotation; // 0x428 (Size: 0x18, Type: StructProperty)
    float IKAlpha; // 0x440 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig; // 0x444 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_44c[0x4]; // 0x44c (Size: 0x4, Type: PaddingProperty)

protected:
    UBeanCharConfigObject* GetConfig() const; // 0x112b4468 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    ABeanCharacter* TryGetBeanCharacter() const; // 0x112b10a0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanChar_Grab_AnimLayer) == 0x450, "Size mismatch for UBeanChar_Grab_AnimLayer");
static_assert(offsetof(UBeanChar_Grab_AnimLayer, bHasGrabTarget) == 0x3d8, "Offset mismatch for UBeanChar_Grab_AnimLayer::bHasGrabTarget");
static_assert(offsetof(UBeanChar_Grab_AnimLayer, GrabStumbleDuration) == 0x3dc, "Offset mismatch for UBeanChar_Grab_AnimLayer::GrabStumbleDuration");
static_assert(offsetof(UBeanChar_Grab_AnimLayer, LeftHandIKPosition) == 0x3e0, "Offset mismatch for UBeanChar_Grab_AnimLayer::LeftHandIKPosition");
static_assert(offsetof(UBeanChar_Grab_AnimLayer, RightHandIKPosition) == 0x3f8, "Offset mismatch for UBeanChar_Grab_AnimLayer::RightHandIKPosition");
static_assert(offsetof(UBeanChar_Grab_AnimLayer, LeftHandIKRotation) == 0x410, "Offset mismatch for UBeanChar_Grab_AnimLayer::LeftHandIKRotation");
static_assert(offsetof(UBeanChar_Grab_AnimLayer, RightHandIKRotation) == 0x428, "Offset mismatch for UBeanChar_Grab_AnimLayer::RightHandIKRotation");
static_assert(offsetof(UBeanChar_Grab_AnimLayer, IKAlpha) == 0x440, "Offset mismatch for UBeanChar_Grab_AnimLayer::IKAlpha");
static_assert(offsetof(UBeanChar_Grab_AnimLayer, BeanCharacterConfig) == 0x444, "Offset mismatch for UBeanChar_Grab_AnimLayer::BeanCharacterConfig");

// Size: 0x430 (Inherited: 0x408, Single: 0x28)
class UBeanChar_GroundLoc_AnimInstance : public UAnimInstance
{
public:
    float TurningPercentage; // 0x3d8 (Size: 0x4, Type: FloatProperty)
    float SpeedPercentage; // 0x3dc (Size: 0x4, Type: FloatProperty)
    uint8_t TurnState; // 0x3e0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3e1[0x3]; // 0x3e1 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig; // 0x3e4 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_3ec[0x44]; // 0x3ec (Size: 0x44, Type: PaddingProperty)

protected:
    UBeanCharConfigObject* GetConfig() const; // 0x112b4494 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    ABeanCharacter* TryGetBeanCharacter() const; // 0x112b10a0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanChar_GroundLoc_AnimInstance) == 0x430, "Size mismatch for UBeanChar_GroundLoc_AnimInstance");
static_assert(offsetof(UBeanChar_GroundLoc_AnimInstance, TurningPercentage) == 0x3d8, "Offset mismatch for UBeanChar_GroundLoc_AnimInstance::TurningPercentage");
static_assert(offsetof(UBeanChar_GroundLoc_AnimInstance, SpeedPercentage) == 0x3dc, "Offset mismatch for UBeanChar_GroundLoc_AnimInstance::SpeedPercentage");
static_assert(offsetof(UBeanChar_GroundLoc_AnimInstance, TurnState) == 0x3e0, "Offset mismatch for UBeanChar_GroundLoc_AnimInstance::TurnState");
static_assert(offsetof(UBeanChar_GroundLoc_AnimInstance, BeanCharacterConfig) == 0x3e4, "Offset mismatch for UBeanChar_GroundLoc_AnimInstance::BeanCharacterConfig");

// Size: 0x420 (Inherited: 0x408, Single: 0x18)
class UBeanChar_Idle_AnimInstance : public UAnimInstance
{
public:
    UAnimSequence* CurrentIdleBreakAnimation; // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    bool bIsPlayingIdleBreak; // 0x3e0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3e1[0x3]; // 0x3e1 (Size: 0x3, Type: PaddingProperty)
    float CurrentIdleBreakTime; // 0x3e4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3e8[0x8]; // 0x3e8 (Size: 0x8, Type: PaddingProperty)
    TArray<TSoftObjectPtr<UAnimSequence*>> IdleBreaks; // 0x3f0 (Size: 0x10, Type: ArrayProperty)
    float IdleBreakMinTime; // 0x400 (Size: 0x4, Type: FloatProperty)
    float IdleBreakMaxTime; // 0x404 (Size: 0x4, Type: FloatProperty)
    float StopIdleBreakTrimTime; // 0x408 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig; // 0x40c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_414[0xc]; // 0x414 (Size: 0xc, Type: PaddingProperty)

protected:
    UBeanCharConfigObject* GetConfig() const; // 0x1116bb88 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    ABeanCharacter* TryGetBeanCharacter() const; // 0x112b10a0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanChar_Idle_AnimInstance) == 0x420, "Size mismatch for UBeanChar_Idle_AnimInstance");
static_assert(offsetof(UBeanChar_Idle_AnimInstance, CurrentIdleBreakAnimation) == 0x3d8, "Offset mismatch for UBeanChar_Idle_AnimInstance::CurrentIdleBreakAnimation");
static_assert(offsetof(UBeanChar_Idle_AnimInstance, bIsPlayingIdleBreak) == 0x3e0, "Offset mismatch for UBeanChar_Idle_AnimInstance::bIsPlayingIdleBreak");
static_assert(offsetof(UBeanChar_Idle_AnimInstance, CurrentIdleBreakTime) == 0x3e4, "Offset mismatch for UBeanChar_Idle_AnimInstance::CurrentIdleBreakTime");
static_assert(offsetof(UBeanChar_Idle_AnimInstance, IdleBreaks) == 0x3f0, "Offset mismatch for UBeanChar_Idle_AnimInstance::IdleBreaks");
static_assert(offsetof(UBeanChar_Idle_AnimInstance, IdleBreakMinTime) == 0x400, "Offset mismatch for UBeanChar_Idle_AnimInstance::IdleBreakMinTime");
static_assert(offsetof(UBeanChar_Idle_AnimInstance, IdleBreakMaxTime) == 0x404, "Offset mismatch for UBeanChar_Idle_AnimInstance::IdleBreakMaxTime");
static_assert(offsetof(UBeanChar_Idle_AnimInstance, StopIdleBreakTrimTime) == 0x408, "Offset mismatch for UBeanChar_Idle_AnimInstance::StopIdleBreakTrimTime");
static_assert(offsetof(UBeanChar_Idle_AnimInstance, BeanCharacterConfig) == 0x40c, "Offset mismatch for UBeanChar_Idle_AnimInstance::BeanCharacterConfig");

// Size: 0x3f0 (Inherited: 0x408, Single: 0xffffffe8)
class UBeanChar_InAirLoc_AnimInstance : public UAnimInstance
{
public:
    bool bIsJumping; // 0x3d8 (Size: 0x1, Type: BoolProperty)
    bool bIsFalling; // 0x3d9 (Size: 0x1, Type: BoolProperty)
    bool bIsAnticipatingJumpLanding; // 0x3da (Size: 0x1, Type: BoolProperty)
    bool bIsDiving; // 0x3db (Size: 0x1, Type: BoolProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig; // 0x3dc (Size: 0x8, Type: WeakObjectProperty)
    bool bWasJumping; // 0x3e4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3e5[0x3]; // 0x3e5 (Size: 0x3, Type: PaddingProperty)
    float JumpStartZ; // 0x3e8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3ec[0x4]; // 0x3ec (Size: 0x4, Type: PaddingProperty)

protected:
    UBeanCharConfigObject* GetConfig() const; // 0x112b2780 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    ABeanCharacter* TryGetBeanCharacter() const; // 0x112b10a0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanChar_InAirLoc_AnimInstance) == 0x3f0, "Size mismatch for UBeanChar_InAirLoc_AnimInstance");
static_assert(offsetof(UBeanChar_InAirLoc_AnimInstance, bIsJumping) == 0x3d8, "Offset mismatch for UBeanChar_InAirLoc_AnimInstance::bIsJumping");
static_assert(offsetof(UBeanChar_InAirLoc_AnimInstance, bIsFalling) == 0x3d9, "Offset mismatch for UBeanChar_InAirLoc_AnimInstance::bIsFalling");
static_assert(offsetof(UBeanChar_InAirLoc_AnimInstance, bIsAnticipatingJumpLanding) == 0x3da, "Offset mismatch for UBeanChar_InAirLoc_AnimInstance::bIsAnticipatingJumpLanding");
static_assert(offsetof(UBeanChar_InAirLoc_AnimInstance, bIsDiving) == 0x3db, "Offset mismatch for UBeanChar_InAirLoc_AnimInstance::bIsDiving");
static_assert(offsetof(UBeanChar_InAirLoc_AnimInstance, BeanCharacterConfig) == 0x3dc, "Offset mismatch for UBeanChar_InAirLoc_AnimInstance::BeanCharacterConfig");
static_assert(offsetof(UBeanChar_InAirLoc_AnimInstance, bWasJumping) == 0x3e4, "Offset mismatch for UBeanChar_InAirLoc_AnimInstance::bWasJumping");
static_assert(offsetof(UBeanChar_InAirLoc_AnimInstance, JumpStartZ) == 0x3e8, "Offset mismatch for UBeanChar_InAirLoc_AnimInstance::JumpStartZ");

// Size: 0x480 (Inherited: 0x408, Single: 0x78)
class UBeanChar_Jiggle_AnimInstance : public UAnimInstance
{
public:
    FVector LastImpactForce; // 0x3d8 (Size: 0x18, Type: StructProperty)
    FVector LastImpactRelativeDirection; // 0x3f0 (Size: 0x18, Type: StructProperty)
    bool bJustLandedFromJump; // 0x408 (Size: 0x1, Type: BoolProperty)
    bool bIsMoving; // 0x409 (Size: 0x1, Type: BoolProperty)
    bool bUseImpactAnims; // 0x40a (Size: 0x1, Type: BoolProperty)
    bool bImpactTriggered; // 0x40b (Size: 0x1, Type: BoolProperty)
    uint8_t ImpactAnimType; // 0x40c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_40d[0x3]; // 0x40d (Size: 0x3, Type: PaddingProperty)
    float LowImpactUpperThresholdReciprocal; // 0x410 (Size: 0x4, Type: FloatProperty)
    float MediumImpactUpperThresholdReciprocal; // 0x414 (Size: 0x4, Type: FloatProperty)
    float HighImpactUpperThresholdReciprocal; // 0x418 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_41c[0x4]; // 0x41c (Size: 0x4, Type: PaddingProperty)
    FRotator JiggleRotator0; // 0x420 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator1; // 0x438 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator2; // 0x450 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig; // 0x468 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_470[0x10]; // 0x470 (Size: 0x10, Type: PaddingProperty)

protected:
    UBeanCharConfigObject* GetConfig() const; // 0x1116bc0c (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    ABeanCharacter* TryGetBeanCharacter() const; // 0x112b10a0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanChar_Jiggle_AnimInstance) == 0x480, "Size mismatch for UBeanChar_Jiggle_AnimInstance");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, LastImpactForce) == 0x3d8, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::LastImpactForce");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, LastImpactRelativeDirection) == 0x3f0, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::LastImpactRelativeDirection");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, bJustLandedFromJump) == 0x408, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::bJustLandedFromJump");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, bIsMoving) == 0x409, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::bIsMoving");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, bUseImpactAnims) == 0x40a, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::bUseImpactAnims");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, bImpactTriggered) == 0x40b, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::bImpactTriggered");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, ImpactAnimType) == 0x40c, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::ImpactAnimType");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, LowImpactUpperThresholdReciprocal) == 0x410, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::LowImpactUpperThresholdReciprocal");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, MediumImpactUpperThresholdReciprocal) == 0x414, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::MediumImpactUpperThresholdReciprocal");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, HighImpactUpperThresholdReciprocal) == 0x418, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::HighImpactUpperThresholdReciprocal");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, JiggleRotator0) == 0x420, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::JiggleRotator0");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, JiggleRotator1) == 0x438, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::JiggleRotator1");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, JiggleRotator2) == 0x450, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::JiggleRotator2");
static_assert(offsetof(UBeanChar_Jiggle_AnimInstance, BeanCharacterConfig) == 0x468, "Offset mismatch for UBeanChar_Jiggle_AnimInstance::BeanCharacterConfig");

// Size: 0x640 (Inherited: 0xea8, Single: 0xfffff798)
class UBeanChar_Main_AnimInstance : public UFortAnimInstance
{
public:
    bool bIsSimulatedProxy; // 0x5c8 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EMovementMode> MovementMode; // 0x5c9 (Size: 0x1, Type: ByteProperty)
    bool bIsMoving; // 0x5ca (Size: 0x1, Type: BoolProperty)
    bool bIsGrounded; // 0x5cb (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5cc[0x4]; // 0x5cc (Size: 0x4, Type: PaddingProperty)
    FVector CurrentVelocity; // 0x5d0 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator0; // 0x5e8 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator1; // 0x600 (Size: 0x18, Type: StructProperty)
    FRotator JiggleRotator2; // 0x618 (Size: 0x18, Type: StructProperty)
    bool bLowerStateUsesLocomotionAnim; // 0x630 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_631[0x3]; // 0x631 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig; // 0x634 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_63c[0x4]; // 0x63c (Size: 0x4, Type: PaddingProperty)

protected:
    UBeanCharConfigObject* GetConfig() const; // 0x112b44c0 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    ABeanCharacter* TryGetBeanCharacter() const; // 0x112b10a0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanChar_Main_AnimInstance) == 0x640, "Size mismatch for UBeanChar_Main_AnimInstance");
static_assert(offsetof(UBeanChar_Main_AnimInstance, bIsSimulatedProxy) == 0x5c8, "Offset mismatch for UBeanChar_Main_AnimInstance::bIsSimulatedProxy");
static_assert(offsetof(UBeanChar_Main_AnimInstance, MovementMode) == 0x5c9, "Offset mismatch for UBeanChar_Main_AnimInstance::MovementMode");
static_assert(offsetof(UBeanChar_Main_AnimInstance, bIsMoving) == 0x5ca, "Offset mismatch for UBeanChar_Main_AnimInstance::bIsMoving");
static_assert(offsetof(UBeanChar_Main_AnimInstance, bIsGrounded) == 0x5cb, "Offset mismatch for UBeanChar_Main_AnimInstance::bIsGrounded");
static_assert(offsetof(UBeanChar_Main_AnimInstance, CurrentVelocity) == 0x5d0, "Offset mismatch for UBeanChar_Main_AnimInstance::CurrentVelocity");
static_assert(offsetof(UBeanChar_Main_AnimInstance, JiggleRotator0) == 0x5e8, "Offset mismatch for UBeanChar_Main_AnimInstance::JiggleRotator0");
static_assert(offsetof(UBeanChar_Main_AnimInstance, JiggleRotator1) == 0x600, "Offset mismatch for UBeanChar_Main_AnimInstance::JiggleRotator1");
static_assert(offsetof(UBeanChar_Main_AnimInstance, JiggleRotator2) == 0x618, "Offset mismatch for UBeanChar_Main_AnimInstance::JiggleRotator2");
static_assert(offsetof(UBeanChar_Main_AnimInstance, bLowerStateUsesLocomotionAnim) == 0x630, "Offset mismatch for UBeanChar_Main_AnimInstance::bLowerStateUsesLocomotionAnim");
static_assert(offsetof(UBeanChar_Main_AnimInstance, BeanCharacterConfig) == 0x634, "Offset mismatch for UBeanChar_Main_AnimInstance::BeanCharacterConfig");

// Size: 0x420 (Inherited: 0x408, Single: 0x18)
class UBeanChar_Ragdoll_AnimLayer : public UAnimInstance
{
public:
    float HighImpactUpperThresholdReciprocal; // 0x3d8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3dc[0x4]; // 0x3dc (Size: 0x4, Type: PaddingProperty)
    FVector LastRagdollImpactForce; // 0x3e0 (Size: 0x18, Type: StructProperty)
    FVector LastImpactRelativeDirection; // 0x3f8 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig; // 0x410 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_418[0x8]; // 0x418 (Size: 0x8, Type: PaddingProperty)

protected:
    UBeanCharConfigObject* GetConfig() const; // 0x112b44ec (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    ABeanCharacter* TryGetBeanCharacter() const; // 0x112b10a0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanChar_Ragdoll_AnimLayer) == 0x420, "Size mismatch for UBeanChar_Ragdoll_AnimLayer");
static_assert(offsetof(UBeanChar_Ragdoll_AnimLayer, HighImpactUpperThresholdReciprocal) == 0x3d8, "Offset mismatch for UBeanChar_Ragdoll_AnimLayer::HighImpactUpperThresholdReciprocal");
static_assert(offsetof(UBeanChar_Ragdoll_AnimLayer, LastRagdollImpactForce) == 0x3e0, "Offset mismatch for UBeanChar_Ragdoll_AnimLayer::LastRagdollImpactForce");
static_assert(offsetof(UBeanChar_Ragdoll_AnimLayer, LastImpactRelativeDirection) == 0x3f8, "Offset mismatch for UBeanChar_Ragdoll_AnimLayer::LastImpactRelativeDirection");
static_assert(offsetof(UBeanChar_Ragdoll_AnimLayer, BeanCharacterConfig) == 0x410, "Offset mismatch for UBeanChar_Ragdoll_AnimLayer::BeanCharacterConfig");

// Size: 0x3f0 (Inherited: 0x408, Single: 0xffffffe8)
class UBeanChar_Swimming_AnimLayer : public UAnimInstance
{
public:
    float SpeedPercentage; // 0x3d8 (Size: 0x4, Type: FloatProperty)
    bool bIsJumping; // 0x3dc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3dd[0x3]; // 0x3dd (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig; // 0x3e0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_3e8[0x8]; // 0x3e8 (Size: 0x8, Type: PaddingProperty)

protected:
    UBeanCharConfigObject* GetConfig() const; // 0x112b4518 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    ABeanCharacter* TryGetBeanCharacter() const; // 0x112b10a0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanChar_Swimming_AnimLayer) == 0x3f0, "Size mismatch for UBeanChar_Swimming_AnimLayer");
static_assert(offsetof(UBeanChar_Swimming_AnimLayer, SpeedPercentage) == 0x3d8, "Offset mismatch for UBeanChar_Swimming_AnimLayer::SpeedPercentage");
static_assert(offsetof(UBeanChar_Swimming_AnimLayer, bIsJumping) == 0x3dc, "Offset mismatch for UBeanChar_Swimming_AnimLayer::bIsJumping");
static_assert(offsetof(UBeanChar_Swimming_AnimLayer, BeanCharacterConfig) == 0x3e0, "Offset mismatch for UBeanChar_Swimming_AnimLayer::BeanCharacterConfig");

// Size: 0x3e0 (Inherited: 0x408, Single: 0xffffffd8)
class UBeanChar_Zipline_AnimLayer : public UAnimInstance
{
public:
    TWeakObjectPtr<UBeanCharConfigObject*> BeanCharacterConfig; // 0x3d8 (Size: 0x8, Type: WeakObjectProperty)

protected:
    UBeanCharConfigObject* GetConfig() const; // 0x112b443c (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    ABeanCharacter* TryGetBeanCharacter() const; // 0x112b10a0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanChar_Zipline_AnimLayer) == 0x3e0, "Size mismatch for UBeanChar_Zipline_AnimLayer");
static_assert(offsetof(UBeanChar_Zipline_AnimLayer, BeanCharacterConfig) == 0x3d8, "Offset mismatch for UBeanChar_Zipline_AnimLayer::BeanCharacterConfig");

// Size: 0x48 (Inherited: 0x78, Single: 0xffffffd0)
class UBeanCheatManager : public UChildCheatManager
{
public:

public:
    void BeanAllowItemInteractionByTag(FString& TagString); // 0xa63baa0 (Index: 0x0, Flags: Final|Exec|Native|Public)
    void BeanDisallowItemInteractionByTag(FString& TagString) const; // 0xa63baa0 (Index: 0x1, Flags: Final|Exec|Native|Public|Const)
    void BeanEnableBeanInEditMode(bool& bEnabled) const; // 0x112b40b8 (Index: 0x2, Flags: Final|Exec|Native|Public|Const)
    void BeanEnableGetupSpeedModifier(bool& bEnabled) const; // 0x112b41e4 (Index: 0x3, Flags: Final|Exec|Native|Public|Const)
    void BeanEnableInventoryMode(bool& bEnable); // 0x9e6e1b8 (Index: 0x4, Flags: Final|Exec|Native|Public)
    void BeanRelockPlayerActionByTag(FString& TagString) const; // 0xa63baa0 (Index: 0x5, Flags: Final|Exec|Native|Public|Const)
    void BeanSetGlobalRagdollThreshold(float& Threshold) const; // 0x112b4310 (Index: 0x6, Flags: Final|Exec|Native|Public|Const)
    void BeanToggleAbilityRestrictions(bool& bApplyRestrictions); // 0x9e6e1b8 (Index: 0x7, Flags: Final|Exec|Native|Public)
    void BeanTogglePickupRestrictions(bool& bApplyRestrictions); // 0x9e6e1b8 (Index: 0x8, Flags: Final|Exec|Native|Public)
    void BeanUnlockBuildMode(bool& bUnlock); // 0x9e6e1b8 (Index: 0x9, Flags: Final|Exec|Native|Public)
    void BeanUnlockPlayerActionByTag(FString& TagString); // 0xa63baa0 (Index: 0xa, Flags: Final|Exec|Native|Public)
    void RespawnAsDefaultPawn(); // 0x554e3c4 (Index: 0xb, Flags: Final|Exec|Native|Public)
    void SwitchBackFromBeanPawn(); // 0x554e3c4 (Index: 0xc, Flags: Final|Exec|Native|Public)
    void SwitchToBeanPawn(); // 0x554e3c4 (Index: 0xd, Flags: Final|Exec|Native|Public)
};

static_assert(sizeof(UBeanCheatManager) == 0x48, "Size mismatch for UBeanCheatManager");

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class UBeanCosmeticBackpackAllowList : public UDataAsset
{
public:
    TSet<TSoftObjectPtr<UAthenaBackpackItemDefinition*>> AllowedBackpacks; // 0x30 (Size: 0x50, Type: SetProperty)
};

static_assert(sizeof(UBeanCosmeticBackpackAllowList) == 0x80, "Size mismatch for UBeanCosmeticBackpackAllowList");
static_assert(offsetof(UBeanCosmeticBackpackAllowList, AllowedBackpacks) == 0x30, "Offset mismatch for UBeanCosmeticBackpackAllowList::AllowedBackpacks");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBeanGrabbable : public UInterface
{
public:
};

static_assert(sizeof(UBeanGrabbable) == 0x28, "Size mismatch for UBeanGrabbable");

// Size: 0x2c0 (Inherited: 0xe0, Single: 0x1e0)
class UBeanJiggleMotionComponent : public UActorComponent
{
public:
    FRuntimeFloatCurve VelocityCurve; // 0xb8 (Size: 0x88, Type: StructProperty)
    uint8_t Pad_140[0x30]; // 0x140 (Size: 0x30, Type: PaddingProperty)
    TArray<FQuat> CurrentBoneRotations; // 0x170 (Size: 0x10, Type: ArrayProperty)
    TArray<FQuat> TargetBoneRotations; // 0x180 (Size: 0x10, Type: ArrayProperty)
    TArray<FRotator> CurrentInterpolatedBoneRotations; // 0x190 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_1a0[0x120]; // 0x1a0 (Size: 0x120, Type: PaddingProperty)
};

static_assert(sizeof(UBeanJiggleMotionComponent) == 0x2c0, "Size mismatch for UBeanJiggleMotionComponent");
static_assert(offsetof(UBeanJiggleMotionComponent, VelocityCurve) == 0xb8, "Offset mismatch for UBeanJiggleMotionComponent::VelocityCurve");
static_assert(offsetof(UBeanJiggleMotionComponent, CurrentBoneRotations) == 0x170, "Offset mismatch for UBeanJiggleMotionComponent::CurrentBoneRotations");
static_assert(offsetof(UBeanJiggleMotionComponent, TargetBoneRotations) == 0x180, "Offset mismatch for UBeanJiggleMotionComponent::TargetBoneRotations");
static_assert(offsetof(UBeanJiggleMotionComponent, CurrentInterpolatedBoneRotations) == 0x190, "Offset mismatch for UBeanJiggleMotionComponent::CurrentInterpolatedBoneRotations");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBeanLaunchPredictorInterface : public UInterface
{
public:

public:
    virtual bool ValidateLaunch(const FBeanPredictedLaunch PredictedLaunch) const; // 0x112b4544 (Index: 0x0, Flags: Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UBeanLaunchPredictorInterface) == 0x28, "Size mismatch for UBeanLaunchPredictorInterface");

// Size: 0x108 (Inherited: 0xe0, Single: 0x28)
class UBeanParticleSystemsComponent : public UActorComponent
{
public:
    TMap<TSoftObjectPtr<UNiagaraSystem*>, EBeanParticleVfxTypes> VfxParticleSystemsMap; // 0xb8 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UBeanParticleSystemsComponent) == 0x108, "Size mismatch for UBeanParticleSystemsComponent");
static_assert(offsetof(UBeanParticleSystemsComponent, VfxParticleSystemsMap) == 0xb8, "Offset mismatch for UBeanParticleSystemsComponent::VfxParticleSystemsMap");

// Size: 0x80 (Inherited: 0x88, Single: 0xfffffff8)
class UBeanPhysicsDOFConstraintSubsystem : public UGameInstanceSubsystem
{
public:
    TMap<FBeanPhysicsDOFConstraint, ABeanCharacter*> PreviousConstraints; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UBeanPhysicsDOFConstraintSubsystem) == 0x80, "Size mismatch for UBeanPhysicsDOFConstraintSubsystem");
static_assert(offsetof(UBeanPhysicsDOFConstraintSubsystem, PreviousConstraints) == 0x30, "Offset mismatch for UBeanPhysicsDOFConstraintSubsystem::PreviousConstraints");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UBeanStreamingManager : public UObject
{
public:
    TSet<UObject*> LoadedAssets; // 0x28 (Size: 0x50, Type: SetProperty)
};

static_assert(sizeof(UBeanStreamingManager) == 0x78, "Size mismatch for UBeanStreamingManager");
static_assert(offsetof(UBeanStreamingManager, LoadedAssets) == 0x28, "Offset mismatch for UBeanStreamingManager::LoadedAssets");

// Size: 0x360 (Inherited: 0xbc0, Single: 0xfffff7a0)
class AFortAthenaMutator_BeanGameStateCore : public AFortAthenaMutator
{
public:
};

static_assert(sizeof(AFortAthenaMutator_BeanGameStateCore) == 0x360, "Size mismatch for AFortAthenaMutator_BeanGameStateCore");

// Size: 0x380 (Inherited: 0xbc0, Single: 0xfffff7c0)
class AFortAthenaMutator_BeanPlayerPawn : public AFortAthenaMutator
{
public:
    TSoftClassPtr OverridePawnClass; // 0x360 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(AFortAthenaMutator_BeanPlayerPawn) == 0x380, "Size mismatch for AFortAthenaMutator_BeanPlayerPawn");
static_assert(offsetof(AFortAthenaMutator_BeanPlayerPawn, OverridePawnClass) == 0x360, "Offset mismatch for AFortAthenaMutator_BeanPlayerPawn::OverridePawnClass");

// Size: 0x90 (Inherited: 0x90, Single: 0x0)
class UFortAutomationRpcManager_Beanstalk : public UFortAutomationRpcManager
{
public:

public:
    void OnBeanStateChanged_AddToHistory(EBeanCharStateID& StateId, EBeanCharStateLayerID& LayerId, bool& bIsReplaying); // 0x112b4788 (Index: 0x0, Flags: Final|Native|Public)
    void OnBeanStateChanged_BroadcastMessage(EBeanCharStateID& StateId, EBeanCharStateLayerID& LayerId, bool& bIsReplaying); // 0x112b4788 (Index: 0x1, Flags: Final|Native|Public)
    void OnBeanStateChanged_Grounded_ResetDive(EBeanCharStateID& StateId, EBeanCharStateLayerID& LayerId, bool& bIsReplaying); // 0x112b4788 (Index: 0x2, Flags: Final|Native|Public)
    void OnCharacterOverlap_BroadcastMessage(AActor*& OverlappedActor, AActor*& OtherActor); // 0xa93bc70 (Index: 0x3, Flags: Final|Native|Public)
    void OnCharacterOverlap_Dive(AActor*& OverlappedActor, AActor*& OtherActor); // 0xa93bc70 (Index: 0x4, Flags: Final|Native|Public)
    void OnCharacterOverlap_Jump(AActor*& OverlappedActor, AActor*& OtherActor); // 0xa93bc70 (Index: 0x5, Flags: Final|Native|Public)
};

static_assert(sizeof(UFortAutomationRpcManager_Beanstalk) == 0x90, "Size mismatch for UFortAutomationRpcManager_Beanstalk");

// Size: 0xd8 (Inherited: 0x270, Single: 0xfffffe68)
class UFortPickupInteractOverrideComponent_Beanstalk : public UFortPickupInteractOverrideComponent
{
public:
};

static_assert(sizeof(UFortPickupInteractOverrideComponent_Beanstalk) == 0xd8, "Size mismatch for UFortPickupInteractOverrideComponent_Beanstalk");

// Size: 0x48 (Inherited: 0x70, Single: 0xffffffd8)
class UInteractSelection_BeanPawn : public UInteractSelection_Base
{
public:
};

static_assert(sizeof(UInteractSelection_BeanPawn) == 0x48, "Size mismatch for UInteractSelection_BeanPawn");

// Size: 0xb18 (Inherited: 0x28, Single: 0xaf0)
class UBeanCharConfigObject : public UObject
{
public:
    FBeanCharInteractionsConfig Interaction; // 0x28 (Size: 0xf0, Type: StructProperty)
    FBeanCharInventoryModeConfig InventoryMode; // 0x118 (Size: 0x80, Type: StructProperty)
    FBeanCharMovementConfig Movement; // 0x198 (Size: 0x278, Type: StructProperty)
    FBeanCharJumpConfig Jump; // 0x410 (Size: 0x48, Type: StructProperty)
    FBeanCharDiveConfig Dive; // 0x458 (Size: 0x58, Type: StructProperty)
    FBeanCharImpactConfig Impact; // 0x4b0 (Size: 0x190, Type: StructProperty)
    FBeanCharStaggerConfig Stagger; // 0x640 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_64c[0x4]; // 0x64c (Size: 0x4, Type: PaddingProperty)
    FBeanCharRagdollConfig Ragdoll; // 0x650 (Size: 0x198, Type: StructProperty)
    FBeanCharRollConfig Roll; // 0x7e8 (Size: 0x28, Type: StructProperty)
    FBeanCharGrabConfig Grab; // 0x810 (Size: 0xd0, Type: StructProperty)
    FBeanCharGetupConfig Getup; // 0x8e0 (Size: 0x28, Type: StructProperty)
    FBeanCharGetupRollConfig GetupRoll; // 0x908 (Size: 0x10, Type: StructProperty)
    FBeanCharMantleConfig Mantle; // 0x918 (Size: 0xc0, Type: StructProperty)
    FBeanCharJostleConfig Jostle; // 0x9d8 (Size: 0x30, Type: StructProperty)
    FBeanCharCameraConfig Camera; // 0xa08 (Size: 0x18, Type: StructProperty)
    FBeanCharCosmeticConfig Cosmetics; // 0xa20 (Size: 0x10, Type: StructProperty)
    FBeanCharSwimmingConfig Swimming; // 0xa30 (Size: 0x20, Type: StructProperty)
    FBeanCharZiplineConfig Zipline; // 0xa50 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_a54[0x4]; // 0xa54 (Size: 0x4, Type: PaddingProperty)
    FBeanCharJiggleConfig Jiggle; // 0xa58 (Size: 0x90, Type: StructProperty)
    FBeanCharHUDConfig HUD; // 0xae8 (Size: 0x20, Type: StructProperty)
    FBeanCharTouchControlsConfig TouchControls; // 0xb08 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_b14[0x4]; // 0xb14 (Size: 0x4, Type: PaddingProperty)

public:
    FBeanCharCameraConfig GetCamera() const; // 0x112b5c80 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharCosmeticConfig GetCosmetics() const; // 0x112b5c9c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharDiveConfig GetDive() const; // 0x112b5cb8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharGetupConfig GetGetup() const; // 0x112b5cd4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharGetupRollConfig GetGetupRoll() const; // 0x112b5cf0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharGrabConfig GetGrab() const; // 0x112b5d0c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharHUDConfig GetHUD() const; // 0x112b5da0 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharImpactConfig GetImpact() const; // 0x112b5dbc (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharInteractionsConfig GetInteraction() const; // 0x112b5dd8 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharInventoryModeConfig GetInventoryMode() const; // 0x112b5df4 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharJiggleConfig GetJiggle() const; // 0x112b5e10 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharJostleConfig GetJostle() const; // 0x112b5e2c (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharJumpConfig GetJump() const; // 0x112b5e60 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharMantleConfig GetMantle() const; // 0x112b5eac (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharMovementConfig GetMovement() const; // 0x112b5ec8 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharRagdollConfig GetRagdoll() const; // 0x112b5ee4 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharRollConfig GetRoll() const; // 0x112b5f00 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharStaggerConfig GetStagger() const; // 0x112b5f34 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharSwimmingConfig GetSwimming() const; // 0x112b5f5c (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharTouchControlsConfig GetTouchControls() const; // 0x112b5f84 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBeanCharZiplineConfig GetZipline() const; // 0x112b5fac (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBeanCharConfigObject) == 0xb18, "Size mismatch for UBeanCharConfigObject");
static_assert(offsetof(UBeanCharConfigObject, Interaction) == 0x28, "Offset mismatch for UBeanCharConfigObject::Interaction");
static_assert(offsetof(UBeanCharConfigObject, InventoryMode) == 0x118, "Offset mismatch for UBeanCharConfigObject::InventoryMode");
static_assert(offsetof(UBeanCharConfigObject, Movement) == 0x198, "Offset mismatch for UBeanCharConfigObject::Movement");
static_assert(offsetof(UBeanCharConfigObject, Jump) == 0x410, "Offset mismatch for UBeanCharConfigObject::Jump");
static_assert(offsetof(UBeanCharConfigObject, Dive) == 0x458, "Offset mismatch for UBeanCharConfigObject::Dive");
static_assert(offsetof(UBeanCharConfigObject, Impact) == 0x4b0, "Offset mismatch for UBeanCharConfigObject::Impact");
static_assert(offsetof(UBeanCharConfigObject, Stagger) == 0x640, "Offset mismatch for UBeanCharConfigObject::Stagger");
static_assert(offsetof(UBeanCharConfigObject, Ragdoll) == 0x650, "Offset mismatch for UBeanCharConfigObject::Ragdoll");
static_assert(offsetof(UBeanCharConfigObject, Roll) == 0x7e8, "Offset mismatch for UBeanCharConfigObject::Roll");
static_assert(offsetof(UBeanCharConfigObject, Grab) == 0x810, "Offset mismatch for UBeanCharConfigObject::Grab");
static_assert(offsetof(UBeanCharConfigObject, Getup) == 0x8e0, "Offset mismatch for UBeanCharConfigObject::Getup");
static_assert(offsetof(UBeanCharConfigObject, GetupRoll) == 0x908, "Offset mismatch for UBeanCharConfigObject::GetupRoll");
static_assert(offsetof(UBeanCharConfigObject, Mantle) == 0x918, "Offset mismatch for UBeanCharConfigObject::Mantle");
static_assert(offsetof(UBeanCharConfigObject, Jostle) == 0x9d8, "Offset mismatch for UBeanCharConfigObject::Jostle");
static_assert(offsetof(UBeanCharConfigObject, Camera) == 0xa08, "Offset mismatch for UBeanCharConfigObject::Camera");
static_assert(offsetof(UBeanCharConfigObject, Cosmetics) == 0xa20, "Offset mismatch for UBeanCharConfigObject::Cosmetics");
static_assert(offsetof(UBeanCharConfigObject, Swimming) == 0xa30, "Offset mismatch for UBeanCharConfigObject::Swimming");
static_assert(offsetof(UBeanCharConfigObject, Zipline) == 0xa50, "Offset mismatch for UBeanCharConfigObject::Zipline");
static_assert(offsetof(UBeanCharConfigObject, Jiggle) == 0xa58, "Offset mismatch for UBeanCharConfigObject::Jiggle");
static_assert(offsetof(UBeanCharConfigObject, HUD) == 0xae8, "Offset mismatch for UBeanCharConfigObject::HUD");
static_assert(offsetof(UBeanCharConfigObject, TouchControls) == 0xb08, "Offset mismatch for UBeanCharConfigObject::TouchControls");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBeanstalkFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool CanPawnSwitchToBeanNow(AFortPlayerPawn*& const PlayerPawn); // 0x11304eac (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool CanPlayerSwitchToBeanNow(AFortPlayerController*& const PlayerController); // 0x113050f8 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void SwitchBackFromBeanPawn(AFortPlayerController*& PlayerController); // 0x1130525c (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool SwitchToBeanPawn(AFortPlayerController*& PlayerController); // 0x11305370 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UBeanstalkFunctionLibrary) == 0x28, "Size mismatch for UBeanstalkFunctionLibrary");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FBeanAudioKey
{
    uint8_t AudioEventType[0x4]; // 0x0 (Size: 0x4, Type: EnumProperty)
    uint8_t AudioCategory[0x4]; // 0x4 (Size: 0x4, Type: EnumProperty)
};

static_assert(sizeof(FBeanAudioKey) == 0x8, "Size mismatch for FBeanAudioKey");
static_assert(offsetof(FBeanAudioKey, AudioEventType) == 0x0, "Offset mismatch for FBeanAudioKey::AudioEventType");
static_assert(offsetof(FBeanAudioKey, AudioCategory) == 0x4, "Offset mismatch for FBeanAudioKey::AudioCategory");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FBeanAudioSet
{
    TArray<USoundBase*> SoundClips2D; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<USoundBase*> SoundClips3D; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FBeanAudioSet) == 0x20, "Size mismatch for FBeanAudioSet");
static_assert(offsetof(FBeanAudioSet, SoundClips2D) == 0x0, "Offset mismatch for FBeanAudioSet::SoundClips2D");
static_assert(offsetof(FBeanAudioSet, SoundClips3D) == 0x10, "Offset mismatch for FBeanAudioSet::SoundClips3D");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FBeanCharIdleBreakDef
{
    TSoftObjectPtr<UAnimMontage*> IdleAnim; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    float Weighting; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FBeanCharIdleBreakDef) == 0x28, "Size mismatch for FBeanCharIdleBreakDef");
static_assert(offsetof(FBeanCharIdleBreakDef, IdleAnim) == 0x0, "Offset mismatch for FBeanCharIdleBreakDef::IdleAnim");
static_assert(offsetof(FBeanCharIdleBreakDef, Weighting) == 0x20, "Offset mismatch for FBeanCharIdleBreakDef::Weighting");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FBeanCharGrabPrediction
{
};

static_assert(sizeof(FBeanCharGrabPrediction) == 0x38, "Size mismatch for FBeanCharGrabPrediction");

// Size: 0xd0 (Inherited: 0x0, Single: 0xd0)
struct FBeanCharMantleCheckDebug
{
};

static_assert(sizeof(FBeanCharMantleCheckDebug) == 0xd0, "Size mismatch for FBeanCharMantleCheckDebug");

// Size: 0x110 (Inherited: 0xd0, Single: 0x40)
struct FBeanCharMantleCheckDebug_StepOne : FBeanCharMantleCheckDebug
{
};

static_assert(sizeof(FBeanCharMantleCheckDebug_StepOne) == 0x110, "Size mismatch for FBeanCharMantleCheckDebug_StepOne");

// Size: 0xe0 (Inherited: 0xd0, Single: 0x10)
struct FBeanCharMantleCheckDebug_StepTwo : FBeanCharMantleCheckDebug
{
};

static_assert(sizeof(FBeanCharMantleCheckDebug_StepTwo) == 0xe0, "Size mismatch for FBeanCharMantleCheckDebug_StepTwo");

// Size: 0xe0 (Inherited: 0xd0, Single: 0x10)
struct FBeanCharMantleCheckDebug_StepThree : FBeanCharMantleCheckDebug
{
};

static_assert(sizeof(FBeanCharMantleCheckDebug_StepThree) == 0xe0, "Size mismatch for FBeanCharMantleCheckDebug_StepThree");

// Size: 0x110 (Inherited: 0xd0, Single: 0x40)
struct FBeanCharMantleCheckDebug_StepFour : FBeanCharMantleCheckDebug
{
};

static_assert(sizeof(FBeanCharMantleCheckDebug_StepFour) == 0x110, "Size mismatch for FBeanCharMantleCheckDebug_StepFour");

// Size: 0x430 (Inherited: 0x0, Single: 0x430)
struct FBeanCharMantleTargetDebug
{
};

static_assert(sizeof(FBeanCharMantleTargetDebug) == 0x430, "Size mismatch for FBeanCharMantleTargetDebug");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FBeanCharMantleTargetData
{
};

static_assert(sizeof(FBeanCharMantleTargetData) == 0x38, "Size mismatch for FBeanCharMantleTargetData");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FBeanCharRagdollImpactData
{
    double Strength; // 0x0 (Size: 0x8, Type: DoubleProperty)
    FVector Location; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Normal; // 0x20 (Size: 0x18, Type: StructProperty)
    bool bFromLaunch; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FBeanCharRagdollImpactData) == 0x40, "Size mismatch for FBeanCharRagdollImpactData");
static_assert(offsetof(FBeanCharRagdollImpactData, Strength) == 0x0, "Offset mismatch for FBeanCharRagdollImpactData::Strength");
static_assert(offsetof(FBeanCharRagdollImpactData, Location) == 0x8, "Offset mismatch for FBeanCharRagdollImpactData::Location");
static_assert(offsetof(FBeanCharRagdollImpactData, Normal) == 0x20, "Offset mismatch for FBeanCharRagdollImpactData::Normal");
static_assert(offsetof(FBeanCharRagdollImpactData, bFromLaunch) == 0x38, "Offset mismatch for FBeanCharRagdollImpactData::bFromLaunch");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FBeanRagdollDebugComponentSnapshot
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Velocity; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FBeanRagdollDebugComponentSnapshot) == 0x30, "Size mismatch for FBeanRagdollDebugComponentSnapshot");
static_assert(offsetof(FBeanRagdollDebugComponentSnapshot, Location) == 0x0, "Offset mismatch for FBeanRagdollDebugComponentSnapshot::Location");
static_assert(offsetof(FBeanRagdollDebugComponentSnapshot, Velocity) == 0x18, "Offset mismatch for FBeanRagdollDebugComponentSnapshot::Velocity");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FBeanRagdollDebugComponentHistory
{
    TArray<FBeanRagdollDebugComponentSnapshot> CapsuleHistory; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FBeanRagdollDebugComponentSnapshot> MeshHistory; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FBeanRagdollDebugComponentHistory) == 0x20, "Size mismatch for FBeanRagdollDebugComponentHistory");
static_assert(offsetof(FBeanRagdollDebugComponentHistory, CapsuleHistory) == 0x0, "Offset mismatch for FBeanRagdollDebugComponentHistory::CapsuleHistory");
static_assert(offsetof(FBeanRagdollDebugComponentHistory, MeshHistory) == 0x10, "Offset mismatch for FBeanRagdollDebugComponentHistory::MeshHistory");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FBeanCharStateMachineContext
{
    UBeanCharStateBase* CurrentState; // 0x8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_10[0x10]; // 0x10 (Size: 0x10, Type: PaddingProperty)
    UBeanCharStateBase* NewState; // 0x20 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_28[0x18]; // 0x28 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FBeanCharStateMachineContext) == 0x40, "Size mismatch for FBeanCharStateMachineContext");
static_assert(offsetof(FBeanCharStateMachineContext, CurrentState) == 0x8, "Offset mismatch for FBeanCharStateMachineContext::CurrentState");
static_assert(offsetof(FBeanCharStateMachineContext, NewState) == 0x20, "Offset mismatch for FBeanCharStateMachineContext::NewState");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FBeanStateHistoryItem
{
};

static_assert(sizeof(FBeanStateHistoryItem) == 0x4, "Size mismatch for FBeanStateHistoryItem");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FBeanStateGameplayTagsDefinition
{
    uint8_t StateId; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagContainer GrantedTags; // 0x8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockedTags; // 0x28 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockedAbilityTags; // 0x48 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FBeanStateGameplayTagsDefinition) == 0x68, "Size mismatch for FBeanStateGameplayTagsDefinition");
static_assert(offsetof(FBeanStateGameplayTagsDefinition, StateId) == 0x0, "Offset mismatch for FBeanStateGameplayTagsDefinition::StateId");
static_assert(offsetof(FBeanStateGameplayTagsDefinition, GrantedTags) == 0x8, "Offset mismatch for FBeanStateGameplayTagsDefinition::GrantedTags");
static_assert(offsetof(FBeanStateGameplayTagsDefinition, BlockedTags) == 0x28, "Offset mismatch for FBeanStateGameplayTagsDefinition::BlockedTags");
static_assert(offsetof(FBeanStateGameplayTagsDefinition, BlockedAbilityTags) == 0x48, "Offset mismatch for FBeanStateGameplayTagsDefinition::BlockedAbilityTags");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FBeanPredictedLaunch
{
    TWeakObjectPtr<ABeanCharacter*> Character; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FVector LaunchVector; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector CharacterLocationBeforeLaunch; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector CharacterVelocityBeforeLaunch; // 0x38 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<UObject*> OptionalSourceSubobject; // 0x50 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FBeanPredictedLaunch) == 0x58, "Size mismatch for FBeanPredictedLaunch");
static_assert(offsetof(FBeanPredictedLaunch, Character) == 0x0, "Offset mismatch for FBeanPredictedLaunch::Character");
static_assert(offsetof(FBeanPredictedLaunch, LaunchVector) == 0x8, "Offset mismatch for FBeanPredictedLaunch::LaunchVector");
static_assert(offsetof(FBeanPredictedLaunch, CharacterLocationBeforeLaunch) == 0x20, "Offset mismatch for FBeanPredictedLaunch::CharacterLocationBeforeLaunch");
static_assert(offsetof(FBeanPredictedLaunch, CharacterVelocityBeforeLaunch) == 0x38, "Offset mismatch for FBeanPredictedLaunch::CharacterVelocityBeforeLaunch");
static_assert(offsetof(FBeanPredictedLaunch, OptionalSourceSubobject) == 0x50, "Offset mismatch for FBeanPredictedLaunch::OptionalSourceSubobject");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FBeanPhysicsDOFConstraint
{
};

static_assert(sizeof(FBeanPhysicsDOFConstraint) == 0x20, "Size mismatch for FBeanPhysicsDOFConstraint");

// Size: 0x100 (Inherited: 0xc0, Single: 0x40)
struct FBeanRootMotionSource_MoveToWithTimeMappingForce : FRootMotionSource
{
    FVector StartLocation; // 0xc0 (Size: 0x18, Type: StructProperty)
    FVector TargetLocation; // 0xd8 (Size: 0x18, Type: StructProperty)
    UCurveFloat* TimeMappingCurve; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    float PreviousPreCurvedTargetRotationTimeFraction; // 0xf8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_fc[0x4]; // 0xfc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FBeanRootMotionSource_MoveToWithTimeMappingForce) == 0x100, "Size mismatch for FBeanRootMotionSource_MoveToWithTimeMappingForce");
static_assert(offsetof(FBeanRootMotionSource_MoveToWithTimeMappingForce, StartLocation) == 0xc0, "Offset mismatch for FBeanRootMotionSource_MoveToWithTimeMappingForce::StartLocation");
static_assert(offsetof(FBeanRootMotionSource_MoveToWithTimeMappingForce, TargetLocation) == 0xd8, "Offset mismatch for FBeanRootMotionSource_MoveToWithTimeMappingForce::TargetLocation");
static_assert(offsetof(FBeanRootMotionSource_MoveToWithTimeMappingForce, TimeMappingCurve) == 0xf0, "Offset mismatch for FBeanRootMotionSource_MoveToWithTimeMappingForce::TimeMappingCurve");
static_assert(offsetof(FBeanRootMotionSource_MoveToWithTimeMappingForce, PreviousPreCurvedTargetRotationTimeFraction) == 0xf8, "Offset mismatch for FBeanRootMotionSource_MoveToWithTimeMappingForce::PreviousPreCurvedTargetRotationTimeFraction");

// Size: 0xf0 (Inherited: 0xc0, Single: 0x30)
struct FBeanRootMotionSource_RotationDeltaForce : FRootMotionSource
{
    FQuat DeltaRotation; // 0xc0 (Size: 0x20, Type: StructProperty)
    UCurveFloat* TimeMappingCurve; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    float PreviousPreCurvedTargetRotationTimeFraction; // 0xe8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_ec[0x4]; // 0xec (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FBeanRootMotionSource_RotationDeltaForce) == 0xf0, "Size mismatch for FBeanRootMotionSource_RotationDeltaForce");
static_assert(offsetof(FBeanRootMotionSource_RotationDeltaForce, DeltaRotation) == 0xc0, "Offset mismatch for FBeanRootMotionSource_RotationDeltaForce::DeltaRotation");
static_assert(offsetof(FBeanRootMotionSource_RotationDeltaForce, TimeMappingCurve) == 0xe0, "Offset mismatch for FBeanRootMotionSource_RotationDeltaForce::TimeMappingCurve");
static_assert(offsetof(FBeanRootMotionSource_RotationDeltaForce, PreviousPreCurvedTargetRotationTimeFraction) == 0xe8, "Offset mismatch for FBeanRootMotionSource_RotationDeltaForce::PreviousPreCurvedTargetRotationTimeFraction");

// Size: 0xe0 (Inherited: 0xc0, Single: 0x20)
struct FBeanRootMotionSource_RotationCurveForce : FRootMotionSource
{
    bool bUseNormalizedTime; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0x7]; // 0xc1 (Size: 0x7, Type: PaddingProperty)
    UCurveVector* RotationCurve; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    float SimulatedTargetTimeFraction; // 0xd0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_d4[0xc]; // 0xd4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FBeanRootMotionSource_RotationCurveForce) == 0xe0, "Size mismatch for FBeanRootMotionSource_RotationCurveForce");
static_assert(offsetof(FBeanRootMotionSource_RotationCurveForce, bUseNormalizedTime) == 0xc0, "Offset mismatch for FBeanRootMotionSource_RotationCurveForce::bUseNormalizedTime");
static_assert(offsetof(FBeanRootMotionSource_RotationCurveForce, RotationCurve) == 0xc8, "Offset mismatch for FBeanRootMotionSource_RotationCurveForce::RotationCurve");
static_assert(offsetof(FBeanRootMotionSource_RotationCurveForce, SimulatedTargetTimeFraction) == 0xd0, "Offset mismatch for FBeanRootMotionSource_RotationCurveForce::SimulatedTargetTimeFraction");

// Size: 0x3 (Inherited: 0x0, Single: 0x3)
struct FBeanStateHistoryRecord
{
    uint8_t StateId; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t LayerId; // 0x1 (Size: 0x1, Type: EnumProperty)
    bool bIsReplaying; // 0x2 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FBeanStateHistoryRecord) == 0x3, "Size mismatch for FBeanStateHistoryRecord");
static_assert(offsetof(FBeanStateHistoryRecord, StateId) == 0x0, "Offset mismatch for FBeanStateHistoryRecord::StateId");
static_assert(offsetof(FBeanStateHistoryRecord, LayerId) == 0x1, "Offset mismatch for FBeanStateHistoryRecord::LayerId");
static_assert(offsetof(FBeanStateHistoryRecord, bIsReplaying) == 0x2, "Offset mismatch for FBeanStateHistoryRecord::bIsReplaying");

// Size: 0x8 (Inherited: 0x1, Single: 0x7)
struct FInteractSelectionData_BeanPawn : FInteractSelectionData_Base
{
    float InteractRadius; // 0x0 (Size: 0x4, Type: FloatProperty)
    float InteractHalfAngle; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FInteractSelectionData_BeanPawn) == 0x8, "Size mismatch for FInteractSelectionData_BeanPawn");
static_assert(offsetof(FInteractSelectionData_BeanPawn, InteractRadius) == 0x0, "Offset mismatch for FInteractSelectionData_BeanPawn::InteractRadius");
static_assert(offsetof(FInteractSelectionData_BeanPawn, InteractHalfAngle) == 0x4, "Offset mismatch for FInteractSelectionData_BeanPawn::InteractHalfAngle");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FBeanJiggleStateWeightOverride
{
    uint8_t StateId; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float Weighting; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBeanJiggleStateWeightOverride) == 0x8, "Size mismatch for FBeanJiggleStateWeightOverride");
static_assert(offsetof(FBeanJiggleStateWeightOverride, StateId) == 0x0, "Offset mismatch for FBeanJiggleStateWeightOverride::StateId");
static_assert(offsetof(FBeanJiggleStateWeightOverride, Weighting) == 0x4, "Offset mismatch for FBeanJiggleStateWeightOverride::Weighting");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FBeanCharCollisionResponseData
{
    float ImpactThreshold; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bActivateKnockback; // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bActivateRagdoll; // 0x5 (Size: 0x1, Type: BoolProperty)
    uint8_t ImpactAnimType; // 0x6 (Size: 0x1, Type: EnumProperty)
    bool bPlayImpactVFX; // 0x7 (Size: 0x1, Type: BoolProperty)
    UForceFeedbackEffect* ForceFeedbackEffect; // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bPlayFeedbackOnLand; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bPlayFeedbackOnLaunch; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FBeanCharCollisionResponseData) == 0x18, "Size mismatch for FBeanCharCollisionResponseData");
static_assert(offsetof(FBeanCharCollisionResponseData, ImpactThreshold) == 0x0, "Offset mismatch for FBeanCharCollisionResponseData::ImpactThreshold");
static_assert(offsetof(FBeanCharCollisionResponseData, bActivateKnockback) == 0x4, "Offset mismatch for FBeanCharCollisionResponseData::bActivateKnockback");
static_assert(offsetof(FBeanCharCollisionResponseData, bActivateRagdoll) == 0x5, "Offset mismatch for FBeanCharCollisionResponseData::bActivateRagdoll");
static_assert(offsetof(FBeanCharCollisionResponseData, ImpactAnimType) == 0x6, "Offset mismatch for FBeanCharCollisionResponseData::ImpactAnimType");
static_assert(offsetof(FBeanCharCollisionResponseData, bPlayImpactVFX) == 0x7, "Offset mismatch for FBeanCharCollisionResponseData::bPlayImpactVFX");
static_assert(offsetof(FBeanCharCollisionResponseData, ForceFeedbackEffect) == 0x8, "Offset mismatch for FBeanCharCollisionResponseData::ForceFeedbackEffect");
static_assert(offsetof(FBeanCharCollisionResponseData, bPlayFeedbackOnLand) == 0x10, "Offset mismatch for FBeanCharCollisionResponseData::bPlayFeedbackOnLand");
static_assert(offsetof(FBeanCharCollisionResponseData, bPlayFeedbackOnLaunch) == 0x11, "Offset mismatch for FBeanCharCollisionResponseData::bPlayFeedbackOnLaunch");

// Size: 0xf0 (Inherited: 0x0, Single: 0xf0)
struct FBeanCharInteractionsConfig
{
    FGameplayTagContainer PersistentTags; // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer DisallowedPlayerActions; // 0x20 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockedGameplayAbilityTags; // 0x40 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AllowedItems; // 0x60 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer BlockedInteractableTags; // 0x80 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer InteractablesRequiringReticle; // 0xa0 (Size: 0x20, Type: StructProperty)
    FText BlockedInteractableContextText; // 0xc0 (Size: 0x10, Type: TextProperty)
    FLinearColor BlockedInteractableContextTextColour; // 0xd0 (Size: 0x10, Type: StructProperty)
    bool bBlockedInteractableContextTextOnly; // 0xe0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e1[0x3]; // 0xe1 (Size: 0x3, Type: PaddingProperty)
    FInteractSelectionData_BeanPawn InteractSelectionData; // 0xe4 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_ec[0x4]; // 0xec (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FBeanCharInteractionsConfig) == 0xf0, "Size mismatch for FBeanCharInteractionsConfig");
static_assert(offsetof(FBeanCharInteractionsConfig, PersistentTags) == 0x0, "Offset mismatch for FBeanCharInteractionsConfig::PersistentTags");
static_assert(offsetof(FBeanCharInteractionsConfig, DisallowedPlayerActions) == 0x20, "Offset mismatch for FBeanCharInteractionsConfig::DisallowedPlayerActions");
static_assert(offsetof(FBeanCharInteractionsConfig, BlockedGameplayAbilityTags) == 0x40, "Offset mismatch for FBeanCharInteractionsConfig::BlockedGameplayAbilityTags");
static_assert(offsetof(FBeanCharInteractionsConfig, AllowedItems) == 0x60, "Offset mismatch for FBeanCharInteractionsConfig::AllowedItems");
static_assert(offsetof(FBeanCharInteractionsConfig, BlockedInteractableTags) == 0x80, "Offset mismatch for FBeanCharInteractionsConfig::BlockedInteractableTags");
static_assert(offsetof(FBeanCharInteractionsConfig, InteractablesRequiringReticle) == 0xa0, "Offset mismatch for FBeanCharInteractionsConfig::InteractablesRequiringReticle");
static_assert(offsetof(FBeanCharInteractionsConfig, BlockedInteractableContextText) == 0xc0, "Offset mismatch for FBeanCharInteractionsConfig::BlockedInteractableContextText");
static_assert(offsetof(FBeanCharInteractionsConfig, BlockedInteractableContextTextColour) == 0xd0, "Offset mismatch for FBeanCharInteractionsConfig::BlockedInteractableContextTextColour");
static_assert(offsetof(FBeanCharInteractionsConfig, bBlockedInteractableContextTextOnly) == 0xe0, "Offset mismatch for FBeanCharInteractionsConfig::bBlockedInteractableContextTextOnly");
static_assert(offsetof(FBeanCharInteractionsConfig, InteractSelectionData) == 0xe4, "Offset mismatch for FBeanCharInteractionsConfig::InteractSelectionData");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FBeanCharInventoryModeConfig
{
    FGameplayTagContainer ActionsToAllow; // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer GameplayAbilityTagsToUnblock; // 0x20 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer HUDElementsToUnhide; // 0x40 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ItemsToAllow; // 0x60 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FBeanCharInventoryModeConfig) == 0x80, "Size mismatch for FBeanCharInventoryModeConfig");
static_assert(offsetof(FBeanCharInventoryModeConfig, ActionsToAllow) == 0x0, "Offset mismatch for FBeanCharInventoryModeConfig::ActionsToAllow");
static_assert(offsetof(FBeanCharInventoryModeConfig, GameplayAbilityTagsToUnblock) == 0x20, "Offset mismatch for FBeanCharInventoryModeConfig::GameplayAbilityTagsToUnblock");
static_assert(offsetof(FBeanCharInventoryModeConfig, HUDElementsToUnhide) == 0x40, "Offset mismatch for FBeanCharInventoryModeConfig::HUDElementsToUnhide");
static_assert(offsetof(FBeanCharInventoryModeConfig, ItemsToAllow) == 0x60, "Offset mismatch for FBeanCharInventoryModeConfig::ItemsToAllow");

// Size: 0x278 (Inherited: 0x0, Single: 0x278)
struct FBeanCharMovementConfig
{
    float Mass; // 0x0 (Size: 0x4, Type: FloatProperty)
    float GravityScale; // 0x4 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve NormalMaxAccelerationCurve; // 0x8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve NormalMaxDecelerationCurve; // 0x90 (Size: 0x88, Type: StructProperty)
    float LeanAnimTurnThreshold; // 0x118 (Size: 0x4, Type: FloatProperty)
    float LeanAnimTurnMaxAngleRadians; // 0x11c (Size: 0x4, Type: FloatProperty)
    float LeanAnimBlendSpeed; // 0x120 (Size: 0x4, Type: FloatProperty)
    float TurnSpeedGrounded; // 0x124 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve TurnYawMultiplierGrounded; // 0x128 (Size: 0x88, Type: StructProperty)
    float TurnSpeedAerial; // 0x1b0 (Size: 0x4, Type: FloatProperty)
    float TurnSpeedFlying; // 0x1b4 (Size: 0x4, Type: FloatProperty)
    bool bIsTurn180Enabled; // 0x1b8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1b9[0x3]; // 0x1b9 (Size: 0x3, Type: PaddingProperty)
    float Turn180MinSpeedPercentage; // 0x1bc (Size: 0x4, Type: FloatProperty)
    float Turn180DotProductTolerance; // 0x1c0 (Size: 0x4, Type: FloatProperty)
    float Turn180Duration; // 0x1c4 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve Turn180YawMultiplier; // 0x1c8 (Size: 0x88, Type: StructProperty)
    float Turn180CancelDotProductTolerance; // 0x250 (Size: 0x4, Type: FloatProperty)
    bool UseMeshPositionLerp; // 0x254 (Size: 0x1, Type: BoolProperty)
    bool UseCameraPositionLerp; // 0x255 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_256[0x2]; // 0x256 (Size: 0x2, Type: PaddingProperty)
    float PositionLerpSpeed; // 0x258 (Size: 0x4, Type: FloatProperty)
    float PositionLerpAccelerationFactor; // 0x25c (Size: 0x4, Type: FloatProperty)
    float MaxCorrectionDistanceToTriggerMeshLerp; // 0x260 (Size: 0x4, Type: FloatProperty)
    float MaxCorrectionDistanceToTriggerCameraLerp; // 0x264 (Size: 0x4, Type: FloatProperty)
    float MaxFallDuration; // 0x268 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_26c[0x4]; // 0x26c (Size: 0x4, Type: PaddingProperty)
    double FallToRagdollZVelocityThreshold; // 0x270 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FBeanCharMovementConfig) == 0x278, "Size mismatch for FBeanCharMovementConfig");
static_assert(offsetof(FBeanCharMovementConfig, Mass) == 0x0, "Offset mismatch for FBeanCharMovementConfig::Mass");
static_assert(offsetof(FBeanCharMovementConfig, GravityScale) == 0x4, "Offset mismatch for FBeanCharMovementConfig::GravityScale");
static_assert(offsetof(FBeanCharMovementConfig, NormalMaxAccelerationCurve) == 0x8, "Offset mismatch for FBeanCharMovementConfig::NormalMaxAccelerationCurve");
static_assert(offsetof(FBeanCharMovementConfig, NormalMaxDecelerationCurve) == 0x90, "Offset mismatch for FBeanCharMovementConfig::NormalMaxDecelerationCurve");
static_assert(offsetof(FBeanCharMovementConfig, LeanAnimTurnThreshold) == 0x118, "Offset mismatch for FBeanCharMovementConfig::LeanAnimTurnThreshold");
static_assert(offsetof(FBeanCharMovementConfig, LeanAnimTurnMaxAngleRadians) == 0x11c, "Offset mismatch for FBeanCharMovementConfig::LeanAnimTurnMaxAngleRadians");
static_assert(offsetof(FBeanCharMovementConfig, LeanAnimBlendSpeed) == 0x120, "Offset mismatch for FBeanCharMovementConfig::LeanAnimBlendSpeed");
static_assert(offsetof(FBeanCharMovementConfig, TurnSpeedGrounded) == 0x124, "Offset mismatch for FBeanCharMovementConfig::TurnSpeedGrounded");
static_assert(offsetof(FBeanCharMovementConfig, TurnYawMultiplierGrounded) == 0x128, "Offset mismatch for FBeanCharMovementConfig::TurnYawMultiplierGrounded");
static_assert(offsetof(FBeanCharMovementConfig, TurnSpeedAerial) == 0x1b0, "Offset mismatch for FBeanCharMovementConfig::TurnSpeedAerial");
static_assert(offsetof(FBeanCharMovementConfig, TurnSpeedFlying) == 0x1b4, "Offset mismatch for FBeanCharMovementConfig::TurnSpeedFlying");
static_assert(offsetof(FBeanCharMovementConfig, bIsTurn180Enabled) == 0x1b8, "Offset mismatch for FBeanCharMovementConfig::bIsTurn180Enabled");
static_assert(offsetof(FBeanCharMovementConfig, Turn180MinSpeedPercentage) == 0x1bc, "Offset mismatch for FBeanCharMovementConfig::Turn180MinSpeedPercentage");
static_assert(offsetof(FBeanCharMovementConfig, Turn180DotProductTolerance) == 0x1c0, "Offset mismatch for FBeanCharMovementConfig::Turn180DotProductTolerance");
static_assert(offsetof(FBeanCharMovementConfig, Turn180Duration) == 0x1c4, "Offset mismatch for FBeanCharMovementConfig::Turn180Duration");
static_assert(offsetof(FBeanCharMovementConfig, Turn180YawMultiplier) == 0x1c8, "Offset mismatch for FBeanCharMovementConfig::Turn180YawMultiplier");
static_assert(offsetof(FBeanCharMovementConfig, Turn180CancelDotProductTolerance) == 0x250, "Offset mismatch for FBeanCharMovementConfig::Turn180CancelDotProductTolerance");
static_assert(offsetof(FBeanCharMovementConfig, UseMeshPositionLerp) == 0x254, "Offset mismatch for FBeanCharMovementConfig::UseMeshPositionLerp");
static_assert(offsetof(FBeanCharMovementConfig, UseCameraPositionLerp) == 0x255, "Offset mismatch for FBeanCharMovementConfig::UseCameraPositionLerp");
static_assert(offsetof(FBeanCharMovementConfig, PositionLerpSpeed) == 0x258, "Offset mismatch for FBeanCharMovementConfig::PositionLerpSpeed");
static_assert(offsetof(FBeanCharMovementConfig, PositionLerpAccelerationFactor) == 0x25c, "Offset mismatch for FBeanCharMovementConfig::PositionLerpAccelerationFactor");
static_assert(offsetof(FBeanCharMovementConfig, MaxCorrectionDistanceToTriggerMeshLerp) == 0x260, "Offset mismatch for FBeanCharMovementConfig::MaxCorrectionDistanceToTriggerMeshLerp");
static_assert(offsetof(FBeanCharMovementConfig, MaxCorrectionDistanceToTriggerCameraLerp) == 0x264, "Offset mismatch for FBeanCharMovementConfig::MaxCorrectionDistanceToTriggerCameraLerp");
static_assert(offsetof(FBeanCharMovementConfig, MaxFallDuration) == 0x268, "Offset mismatch for FBeanCharMovementConfig::MaxFallDuration");
static_assert(offsetof(FBeanCharMovementConfig, FallToRagdollZVelocityThreshold) == 0x270, "Offset mismatch for FBeanCharMovementConfig::FallToRagdollZVelocityThreshold");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FBeanCharJumpConfig
{
    float JumpZVelocity; // 0x0 (Size: 0x4, Type: FloatProperty)
    float LandingVelocityConserve; // 0x4 (Size: 0x4, Type: FloatProperty)
    double TransitionToFallingZThreshold; // 0x8 (Size: 0x8, Type: DoubleProperty)
    float JumpCoyoteTime; // 0x10 (Size: 0x4, Type: FloatProperty)
    float JumpReverseCoyoteTime; // 0x14 (Size: 0x4, Type: FloatProperty)
    FVector ParticleEmitterScale; // 0x18 (Size: 0x18, Type: StructProperty)
    double ParticleSpawnZOffset; // 0x30 (Size: 0x8, Type: DoubleProperty)
    double AnticipateLandingInitialTraceLength; // 0x38 (Size: 0x8, Type: DoubleProperty)
    double AnticipateLandingZVelocityMultiplier; // 0x40 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FBeanCharJumpConfig) == 0x48, "Size mismatch for FBeanCharJumpConfig");
static_assert(offsetof(FBeanCharJumpConfig, JumpZVelocity) == 0x0, "Offset mismatch for FBeanCharJumpConfig::JumpZVelocity");
static_assert(offsetof(FBeanCharJumpConfig, LandingVelocityConserve) == 0x4, "Offset mismatch for FBeanCharJumpConfig::LandingVelocityConserve");
static_assert(offsetof(FBeanCharJumpConfig, TransitionToFallingZThreshold) == 0x8, "Offset mismatch for FBeanCharJumpConfig::TransitionToFallingZThreshold");
static_assert(offsetof(FBeanCharJumpConfig, JumpCoyoteTime) == 0x10, "Offset mismatch for FBeanCharJumpConfig::JumpCoyoteTime");
static_assert(offsetof(FBeanCharJumpConfig, JumpReverseCoyoteTime) == 0x14, "Offset mismatch for FBeanCharJumpConfig::JumpReverseCoyoteTime");
static_assert(offsetof(FBeanCharJumpConfig, ParticleEmitterScale) == 0x18, "Offset mismatch for FBeanCharJumpConfig::ParticleEmitterScale");
static_assert(offsetof(FBeanCharJumpConfig, ParticleSpawnZOffset) == 0x30, "Offset mismatch for FBeanCharJumpConfig::ParticleSpawnZOffset");
static_assert(offsetof(FBeanCharJumpConfig, AnticipateLandingInitialTraceLength) == 0x38, "Offset mismatch for FBeanCharJumpConfig::AnticipateLandingInitialTraceLength");
static_assert(offsetof(FBeanCharJumpConfig, AnticipateLandingZVelocityMultiplier) == 0x40, "Offset mismatch for FBeanCharJumpConfig::AnticipateLandingZVelocityMultiplier");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FBeanCharDiveConfig
{
    float GroundDiveVelocity; // 0x0 (Size: 0x4, Type: FloatProperty)
    float GroundDiveAngle; // 0x4 (Size: 0x4, Type: FloatProperty)
    float AirDiveVelocity; // 0x8 (Size: 0x4, Type: FloatProperty)
    float AirDiveAngle; // 0xc (Size: 0x4, Type: FloatProperty)
    double HorizontalVelocityConservePercentageNormalized; // 0x10 (Size: 0x8, Type: DoubleProperty)
    float TurnSpeedDiving; // 0x18 (Size: 0x4, Type: FloatProperty)
    float GroundTimeBeforeGetup; // 0x1c (Size: 0x4, Type: FloatProperty)
    float LandingVelocityReductionPercentageNormalized; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    UCurveVector* DiveRotationCurve; // 0x28 (Size: 0x8, Type: ObjectProperty)
    FVector ParticleEmitterScale; // 0x30 (Size: 0x18, Type: StructProperty)
    double ParticleSpawnZOffset; // 0x48 (Size: 0x8, Type: DoubleProperty)
    bool bLaunchZOverrideResetsDive; // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bLaunchXYOverrideResetsDive; // 0x51 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_52[0x6]; // 0x52 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FBeanCharDiveConfig) == 0x58, "Size mismatch for FBeanCharDiveConfig");
static_assert(offsetof(FBeanCharDiveConfig, GroundDiveVelocity) == 0x0, "Offset mismatch for FBeanCharDiveConfig::GroundDiveVelocity");
static_assert(offsetof(FBeanCharDiveConfig, GroundDiveAngle) == 0x4, "Offset mismatch for FBeanCharDiveConfig::GroundDiveAngle");
static_assert(offsetof(FBeanCharDiveConfig, AirDiveVelocity) == 0x8, "Offset mismatch for FBeanCharDiveConfig::AirDiveVelocity");
static_assert(offsetof(FBeanCharDiveConfig, AirDiveAngle) == 0xc, "Offset mismatch for FBeanCharDiveConfig::AirDiveAngle");
static_assert(offsetof(FBeanCharDiveConfig, HorizontalVelocityConservePercentageNormalized) == 0x10, "Offset mismatch for FBeanCharDiveConfig::HorizontalVelocityConservePercentageNormalized");
static_assert(offsetof(FBeanCharDiveConfig, TurnSpeedDiving) == 0x18, "Offset mismatch for FBeanCharDiveConfig::TurnSpeedDiving");
static_assert(offsetof(FBeanCharDiveConfig, GroundTimeBeforeGetup) == 0x1c, "Offset mismatch for FBeanCharDiveConfig::GroundTimeBeforeGetup");
static_assert(offsetof(FBeanCharDiveConfig, LandingVelocityReductionPercentageNormalized) == 0x20, "Offset mismatch for FBeanCharDiveConfig::LandingVelocityReductionPercentageNormalized");
static_assert(offsetof(FBeanCharDiveConfig, DiveRotationCurve) == 0x28, "Offset mismatch for FBeanCharDiveConfig::DiveRotationCurve");
static_assert(offsetof(FBeanCharDiveConfig, ParticleEmitterScale) == 0x30, "Offset mismatch for FBeanCharDiveConfig::ParticleEmitterScale");
static_assert(offsetof(FBeanCharDiveConfig, ParticleSpawnZOffset) == 0x48, "Offset mismatch for FBeanCharDiveConfig::ParticleSpawnZOffset");
static_assert(offsetof(FBeanCharDiveConfig, bLaunchZOverrideResetsDive) == 0x50, "Offset mismatch for FBeanCharDiveConfig::bLaunchZOverrideResetsDive");
static_assert(offsetof(FBeanCharDiveConfig, bLaunchXYOverrideResetsDive) == 0x51, "Offset mismatch for FBeanCharDiveConfig::bLaunchXYOverrideResetsDive");

// Size: 0x190 (Inherited: 0x0, Single: 0x190)
struct FBeanCharImpactConfig
{
    TArray<FBeanCharCollisionResponseData> CollisionResponseData; // 0x0 (Size: 0x10, Type: ArrayProperty)
    double DiveHeadOnCollisionReactionMultiplier; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double GroundLandingCollisionReactionMultiplier; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double LedgeUpwardDotTolerance; // 0x20 (Size: 0x8, Type: DoubleProperty)
    FVector LedgeKnockbackMultiplier; // 0x28 (Size: 0x18, Type: StructProperty)
    double InAirKnockbackDampening; // 0x40 (Size: 0x8, Type: DoubleProperty)
    double MinKnockbackForce; // 0x48 (Size: 0x8, Type: DoubleProperty)
    double MaxKnockbackForce; // 0x50 (Size: 0x8, Type: DoubleProperty)
    float ImpactVFXCooldown; // 0x58 (Size: 0x4, Type: FloatProperty)
    float ImpactOffsetAmount; // 0x5c (Size: 0x4, Type: FloatProperty)
    float ImpactThresholdLarge; // 0x60 (Size: 0x4, Type: FloatProperty)
    float ImpactThresholdMedium; // 0x64 (Size: 0x4, Type: FloatProperty)
    float ImpactThresholdSmall; // 0x68 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
    double MinimumImpactGameplayCueStrength; // 0x70 (Size: 0x8, Type: DoubleProperty)
    double ImpactGameplayCueCooldown; // 0x78 (Size: 0x8, Type: DoubleProperty)
    TSet<EBeanCharStateID> IgnoreImpactStates; // 0x80 (Size: 0x50, Type: SetProperty)
    FName RootUnpinnedBone; // 0xd0 (Size: 0x4, Type: NameProperty)
    float BasePinStrength; // 0xd4 (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve PinningResetCurve; // 0xd8 (Size: 0x88, Type: StructProperty)
    TArray<TEnumAsByte<ECollisionChannel>> PinningCollisionChannels; // 0x160 (Size: 0x10, Type: ArrayProperty)
    FPhysicalAnimationData PinningPhysicalAnimationData; // 0x170 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FBeanCharImpactConfig) == 0x190, "Size mismatch for FBeanCharImpactConfig");
static_assert(offsetof(FBeanCharImpactConfig, CollisionResponseData) == 0x0, "Offset mismatch for FBeanCharImpactConfig::CollisionResponseData");
static_assert(offsetof(FBeanCharImpactConfig, DiveHeadOnCollisionReactionMultiplier) == 0x10, "Offset mismatch for FBeanCharImpactConfig::DiveHeadOnCollisionReactionMultiplier");
static_assert(offsetof(FBeanCharImpactConfig, GroundLandingCollisionReactionMultiplier) == 0x18, "Offset mismatch for FBeanCharImpactConfig::GroundLandingCollisionReactionMultiplier");
static_assert(offsetof(FBeanCharImpactConfig, LedgeUpwardDotTolerance) == 0x20, "Offset mismatch for FBeanCharImpactConfig::LedgeUpwardDotTolerance");
static_assert(offsetof(FBeanCharImpactConfig, LedgeKnockbackMultiplier) == 0x28, "Offset mismatch for FBeanCharImpactConfig::LedgeKnockbackMultiplier");
static_assert(offsetof(FBeanCharImpactConfig, InAirKnockbackDampening) == 0x40, "Offset mismatch for FBeanCharImpactConfig::InAirKnockbackDampening");
static_assert(offsetof(FBeanCharImpactConfig, MinKnockbackForce) == 0x48, "Offset mismatch for FBeanCharImpactConfig::MinKnockbackForce");
static_assert(offsetof(FBeanCharImpactConfig, MaxKnockbackForce) == 0x50, "Offset mismatch for FBeanCharImpactConfig::MaxKnockbackForce");
static_assert(offsetof(FBeanCharImpactConfig, ImpactVFXCooldown) == 0x58, "Offset mismatch for FBeanCharImpactConfig::ImpactVFXCooldown");
static_assert(offsetof(FBeanCharImpactConfig, ImpactOffsetAmount) == 0x5c, "Offset mismatch for FBeanCharImpactConfig::ImpactOffsetAmount");
static_assert(offsetof(FBeanCharImpactConfig, ImpactThresholdLarge) == 0x60, "Offset mismatch for FBeanCharImpactConfig::ImpactThresholdLarge");
static_assert(offsetof(FBeanCharImpactConfig, ImpactThresholdMedium) == 0x64, "Offset mismatch for FBeanCharImpactConfig::ImpactThresholdMedium");
static_assert(offsetof(FBeanCharImpactConfig, ImpactThresholdSmall) == 0x68, "Offset mismatch for FBeanCharImpactConfig::ImpactThresholdSmall");
static_assert(offsetof(FBeanCharImpactConfig, MinimumImpactGameplayCueStrength) == 0x70, "Offset mismatch for FBeanCharImpactConfig::MinimumImpactGameplayCueStrength");
static_assert(offsetof(FBeanCharImpactConfig, ImpactGameplayCueCooldown) == 0x78, "Offset mismatch for FBeanCharImpactConfig::ImpactGameplayCueCooldown");
static_assert(offsetof(FBeanCharImpactConfig, IgnoreImpactStates) == 0x80, "Offset mismatch for FBeanCharImpactConfig::IgnoreImpactStates");
static_assert(offsetof(FBeanCharImpactConfig, RootUnpinnedBone) == 0xd0, "Offset mismatch for FBeanCharImpactConfig::RootUnpinnedBone");
static_assert(offsetof(FBeanCharImpactConfig, BasePinStrength) == 0xd4, "Offset mismatch for FBeanCharImpactConfig::BasePinStrength");
static_assert(offsetof(FBeanCharImpactConfig, PinningResetCurve) == 0xd8, "Offset mismatch for FBeanCharImpactConfig::PinningResetCurve");
static_assert(offsetof(FBeanCharImpactConfig, PinningCollisionChannels) == 0x160, "Offset mismatch for FBeanCharImpactConfig::PinningCollisionChannels");
static_assert(offsetof(FBeanCharImpactConfig, PinningPhysicalAnimationData) == 0x170, "Offset mismatch for FBeanCharImpactConfig::PinningPhysicalAnimationData");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FBeanCharStaggerConfig
{
    float LandStaggerZVelocityThreshold; // 0x0 (Size: 0x4, Type: FloatProperty)
    float LandStaggerStunDurationSeconds; // 0x4 (Size: 0x4, Type: FloatProperty)
    float VelocityMultiplierOnStagger; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBeanCharStaggerConfig) == 0xc, "Size mismatch for FBeanCharStaggerConfig");
static_assert(offsetof(FBeanCharStaggerConfig, LandStaggerZVelocityThreshold) == 0x0, "Offset mismatch for FBeanCharStaggerConfig::LandStaggerZVelocityThreshold");
static_assert(offsetof(FBeanCharStaggerConfig, LandStaggerStunDurationSeconds) == 0x4, "Offset mismatch for FBeanCharStaggerConfig::LandStaggerStunDurationSeconds");
static_assert(offsetof(FBeanCharStaggerConfig, VelocityMultiplierOnStagger) == 0x8, "Offset mismatch for FBeanCharStaggerConfig::VelocityMultiplierOnStagger");

// Size: 0xd0 (Inherited: 0x0, Single: 0xd0)
struct FBeanCharGrabConfig
{
    float GrabbedJumpForceMultiplier; // 0x0 (Size: 0x4, Type: FloatProperty)
    float GrabRadius; // 0x4 (Size: 0x4, Type: FloatProperty)
    float GrabTargetCheckHeight; // 0x8 (Size: 0x4, Type: FloatProperty)
    float UngrabDistanceAny; // 0xc (Size: 0x4, Type: FloatProperty)
    float UngrabDistanceVertical; // 0x10 (Size: 0x4, Type: FloatProperty)
    float GrabbingRunSpeedMultiplier; // 0x14 (Size: 0x4, Type: FloatProperty)
    float HoldingRunSpeedMultiplier; // 0x18 (Size: 0x4, Type: FloatProperty)
    float HoldingMaxTurnSpeed; // 0x1c (Size: 0x4, Type: FloatProperty)
    float BeingGrabbedRunSpeedMultiplier; // 0x20 (Size: 0x4, Type: FloatProperty)
    float BeingGrabbedMaxTurnSpeed; // 0x24 (Size: 0x4, Type: FloatProperty)
    float HoldPositionForwardOffset; // 0x28 (Size: 0x4, Type: FloatProperty)
    float RotateToFaceTargetSpeed; // 0x2c (Size: 0x4, Type: FloatProperty)
    float DragPositionTolerance; // 0x30 (Size: 0x4, Type: FloatProperty)
    float DragSpeed; // 0x34 (Size: 0x4, Type: FloatProperty)
    float GrabberVelocityFactor; // 0x38 (Size: 0x4, Type: FloatProperty)
    float MaxForceOnGrabber; // 0x3c (Size: 0x4, Type: FloatProperty)
    float GrabbeeVelocityFactor; // 0x40 (Size: 0x4, Type: FloatProperty)
    float MaxForceOnGrabbee; // 0x44 (Size: 0x4, Type: FloatProperty)
    float GrabBreakTime; // 0x48 (Size: 0x4, Type: FloatProperty)
    float GrabbeeCooldownAfterGrabBreak; // 0x4c (Size: 0x4, Type: FloatProperty)
    float GrabbeeJumpBreakTimeReduction; // 0x50 (Size: 0x4, Type: FloatProperty)
    float GrabBreakApartForce; // 0x54 (Size: 0x4, Type: FloatProperty)
    float GrabStumbleDuration; // 0x58 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    FVector PlayerGrabOffsetIK; // 0x60 (Size: 0x18, Type: StructProperty)
    FVector LeftHandRotationAdjustment; // 0x78 (Size: 0x18, Type: StructProperty)
    FVector RightHandRotationAdjustment; // 0x90 (Size: 0x18, Type: StructProperty)
    float ServerNetLocationToleranceGrabber; // 0xa8 (Size: 0x4, Type: FloatProperty)
    float ServerNetLocationToleranceGrabbee; // 0xac (Size: 0x4, Type: FloatProperty)
    FVector ParticleEmitterScale; // 0xb0 (Size: 0x18, Type: StructProperty)
    float HoldingRunSpeedAnimationMultiplier; // 0xc8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FBeanCharGrabConfig) == 0xd0, "Size mismatch for FBeanCharGrabConfig");
static_assert(offsetof(FBeanCharGrabConfig, GrabbedJumpForceMultiplier) == 0x0, "Offset mismatch for FBeanCharGrabConfig::GrabbedJumpForceMultiplier");
static_assert(offsetof(FBeanCharGrabConfig, GrabRadius) == 0x4, "Offset mismatch for FBeanCharGrabConfig::GrabRadius");
static_assert(offsetof(FBeanCharGrabConfig, GrabTargetCheckHeight) == 0x8, "Offset mismatch for FBeanCharGrabConfig::GrabTargetCheckHeight");
static_assert(offsetof(FBeanCharGrabConfig, UngrabDistanceAny) == 0xc, "Offset mismatch for FBeanCharGrabConfig::UngrabDistanceAny");
static_assert(offsetof(FBeanCharGrabConfig, UngrabDistanceVertical) == 0x10, "Offset mismatch for FBeanCharGrabConfig::UngrabDistanceVertical");
static_assert(offsetof(FBeanCharGrabConfig, GrabbingRunSpeedMultiplier) == 0x14, "Offset mismatch for FBeanCharGrabConfig::GrabbingRunSpeedMultiplier");
static_assert(offsetof(FBeanCharGrabConfig, HoldingRunSpeedMultiplier) == 0x18, "Offset mismatch for FBeanCharGrabConfig::HoldingRunSpeedMultiplier");
static_assert(offsetof(FBeanCharGrabConfig, HoldingMaxTurnSpeed) == 0x1c, "Offset mismatch for FBeanCharGrabConfig::HoldingMaxTurnSpeed");
static_assert(offsetof(FBeanCharGrabConfig, BeingGrabbedRunSpeedMultiplier) == 0x20, "Offset mismatch for FBeanCharGrabConfig::BeingGrabbedRunSpeedMultiplier");
static_assert(offsetof(FBeanCharGrabConfig, BeingGrabbedMaxTurnSpeed) == 0x24, "Offset mismatch for FBeanCharGrabConfig::BeingGrabbedMaxTurnSpeed");
static_assert(offsetof(FBeanCharGrabConfig, HoldPositionForwardOffset) == 0x28, "Offset mismatch for FBeanCharGrabConfig::HoldPositionForwardOffset");
static_assert(offsetof(FBeanCharGrabConfig, RotateToFaceTargetSpeed) == 0x2c, "Offset mismatch for FBeanCharGrabConfig::RotateToFaceTargetSpeed");
static_assert(offsetof(FBeanCharGrabConfig, DragPositionTolerance) == 0x30, "Offset mismatch for FBeanCharGrabConfig::DragPositionTolerance");
static_assert(offsetof(FBeanCharGrabConfig, DragSpeed) == 0x34, "Offset mismatch for FBeanCharGrabConfig::DragSpeed");
static_assert(offsetof(FBeanCharGrabConfig, GrabberVelocityFactor) == 0x38, "Offset mismatch for FBeanCharGrabConfig::GrabberVelocityFactor");
static_assert(offsetof(FBeanCharGrabConfig, MaxForceOnGrabber) == 0x3c, "Offset mismatch for FBeanCharGrabConfig::MaxForceOnGrabber");
static_assert(offsetof(FBeanCharGrabConfig, GrabbeeVelocityFactor) == 0x40, "Offset mismatch for FBeanCharGrabConfig::GrabbeeVelocityFactor");
static_assert(offsetof(FBeanCharGrabConfig, MaxForceOnGrabbee) == 0x44, "Offset mismatch for FBeanCharGrabConfig::MaxForceOnGrabbee");
static_assert(offsetof(FBeanCharGrabConfig, GrabBreakTime) == 0x48, "Offset mismatch for FBeanCharGrabConfig::GrabBreakTime");
static_assert(offsetof(FBeanCharGrabConfig, GrabbeeCooldownAfterGrabBreak) == 0x4c, "Offset mismatch for FBeanCharGrabConfig::GrabbeeCooldownAfterGrabBreak");
static_assert(offsetof(FBeanCharGrabConfig, GrabbeeJumpBreakTimeReduction) == 0x50, "Offset mismatch for FBeanCharGrabConfig::GrabbeeJumpBreakTimeReduction");
static_assert(offsetof(FBeanCharGrabConfig, GrabBreakApartForce) == 0x54, "Offset mismatch for FBeanCharGrabConfig::GrabBreakApartForce");
static_assert(offsetof(FBeanCharGrabConfig, GrabStumbleDuration) == 0x58, "Offset mismatch for FBeanCharGrabConfig::GrabStumbleDuration");
static_assert(offsetof(FBeanCharGrabConfig, PlayerGrabOffsetIK) == 0x60, "Offset mismatch for FBeanCharGrabConfig::PlayerGrabOffsetIK");
static_assert(offsetof(FBeanCharGrabConfig, LeftHandRotationAdjustment) == 0x78, "Offset mismatch for FBeanCharGrabConfig::LeftHandRotationAdjustment");
static_assert(offsetof(FBeanCharGrabConfig, RightHandRotationAdjustment) == 0x90, "Offset mismatch for FBeanCharGrabConfig::RightHandRotationAdjustment");
static_assert(offsetof(FBeanCharGrabConfig, ServerNetLocationToleranceGrabber) == 0xa8, "Offset mismatch for FBeanCharGrabConfig::ServerNetLocationToleranceGrabber");
static_assert(offsetof(FBeanCharGrabConfig, ServerNetLocationToleranceGrabbee) == 0xac, "Offset mismatch for FBeanCharGrabConfig::ServerNetLocationToleranceGrabbee");
static_assert(offsetof(FBeanCharGrabConfig, ParticleEmitterScale) == 0xb0, "Offset mismatch for FBeanCharGrabConfig::ParticleEmitterScale");
static_assert(offsetof(FBeanCharGrabConfig, HoldingRunSpeedAnimationMultiplier) == 0xc8, "Offset mismatch for FBeanCharGrabConfig::HoldingRunSpeedAnimationMultiplier");

// Size: 0x198 (Inherited: 0x0, Single: 0x198)
struct FBeanCharRagdollConfig
{
    double ImpactForceMultiplier; // 0x0 (Size: 0x8, Type: DoubleProperty)
    bool bUseLaunchForceMultiplier; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    FRuntimeFloatCurve LaunchForceMultiplier; // 0x10 (Size: 0x88, Type: StructProperty)
    double GroundedRagdollControlForce; // 0x98 (Size: 0x8, Type: DoubleProperty)
    double InAirRagdollControlForce; // 0xa0 (Size: 0x8, Type: DoubleProperty)
    float RagdollControlVelocityThreshold; // 0xa8 (Size: 0x4, Type: FloatProperty)
    float ExitLinearVelocity; // 0xac (Size: 0x4, Type: FloatProperty)
    float ExitAngularVelocity; // 0xb0 (Size: 0x4, Type: FloatProperty)
    float GetupVerticalityDotProductTolerance; // 0xb4 (Size: 0x4, Type: FloatProperty)
    float GetupVerticalityDotProductDeadZoneMin; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float GetupVerticalityDotProductDeadZoneMax; // 0xbc (Size: 0x4, Type: FloatProperty)
    float MinimumActiveSeconds; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float MaxActiveSeconds; // 0xc4 (Size: 0x4, Type: FloatProperty)
    double AngularVelocityMagnitude; // 0xc8 (Size: 0x8, Type: DoubleProperty)
    float HighImpactMaxAnimThreshold; // 0xd0 (Size: 0x4, Type: FloatProperty)
    FName SkeletalMeshAnchorBone; // 0xd4 (Size: 0x4, Type: NameProperty)
    float PhysicsBlendWeight; // 0xd8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_dc[0x4]; // 0xdc (Size: 0x4, Type: PaddingProperty)
    FRotator MeshCapsuleRotationalOffset; // 0xe0 (Size: 0x18, Type: StructProperty)
    FVector MeshCapsulePositionalOffset; // 0xf8 (Size: 0x18, Type: StructProperty)
    double DebugTriggerRagdollForce; // 0x110 (Size: 0x8, Type: DoubleProperty)
    bool bEnableRollExit; // 0x118 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_119[0x7]; // 0x119 (Size: 0x7, Type: PaddingProperty)
    double SpeedForRollGetup; // 0x120 (Size: 0x8, Type: DoubleProperty)
    float GroundedCheckHalfHeightScale; // 0x128 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_12c[0x4]; // 0x12c (Size: 0x4, Type: PaddingProperty)
    double GroundedCheckRadius; // 0x130 (Size: 0x8, Type: DoubleProperty)
    float MinimumTimeOnGround; // 0x138 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
    TArray<TEnumAsByte<ECollisionChannel>> MeshCollisionChannels; // 0x140 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> MeshBonesWithCCD; // 0x150 (Size: 0x10, Type: ArrayProperty)
    int32_t MaxRemoteRagdollCharacters; // 0x160 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_164[0x4]; // 0x164 (Size: 0x4, Type: PaddingProperty)
    double MaxRemoteRagdollDistance; // 0x168 (Size: 0x8, Type: DoubleProperty)
    double RemoteRagdollMinimumDeactiveTime; // 0x170 (Size: 0x8, Type: DoubleProperty)
    bool bCullRemoteRagdollsBehindCamera; // 0x178 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_179[0x7]; // 0x179 (Size: 0x7, Type: PaddingProperty)
    double ReplicationHardsnapDistanceOverride; // 0x180 (Size: 0x8, Type: DoubleProperty)
    double MaxSecondsStuck; // 0x188 (Size: 0x8, Type: DoubleProperty)
    double SameLocationDistanceTolerance; // 0x190 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FBeanCharRagdollConfig) == 0x198, "Size mismatch for FBeanCharRagdollConfig");
static_assert(offsetof(FBeanCharRagdollConfig, ImpactForceMultiplier) == 0x0, "Offset mismatch for FBeanCharRagdollConfig::ImpactForceMultiplier");
static_assert(offsetof(FBeanCharRagdollConfig, bUseLaunchForceMultiplier) == 0x8, "Offset mismatch for FBeanCharRagdollConfig::bUseLaunchForceMultiplier");
static_assert(offsetof(FBeanCharRagdollConfig, LaunchForceMultiplier) == 0x10, "Offset mismatch for FBeanCharRagdollConfig::LaunchForceMultiplier");
static_assert(offsetof(FBeanCharRagdollConfig, GroundedRagdollControlForce) == 0x98, "Offset mismatch for FBeanCharRagdollConfig::GroundedRagdollControlForce");
static_assert(offsetof(FBeanCharRagdollConfig, InAirRagdollControlForce) == 0xa0, "Offset mismatch for FBeanCharRagdollConfig::InAirRagdollControlForce");
static_assert(offsetof(FBeanCharRagdollConfig, RagdollControlVelocityThreshold) == 0xa8, "Offset mismatch for FBeanCharRagdollConfig::RagdollControlVelocityThreshold");
static_assert(offsetof(FBeanCharRagdollConfig, ExitLinearVelocity) == 0xac, "Offset mismatch for FBeanCharRagdollConfig::ExitLinearVelocity");
static_assert(offsetof(FBeanCharRagdollConfig, ExitAngularVelocity) == 0xb0, "Offset mismatch for FBeanCharRagdollConfig::ExitAngularVelocity");
static_assert(offsetof(FBeanCharRagdollConfig, GetupVerticalityDotProductTolerance) == 0xb4, "Offset mismatch for FBeanCharRagdollConfig::GetupVerticalityDotProductTolerance");
static_assert(offsetof(FBeanCharRagdollConfig, GetupVerticalityDotProductDeadZoneMin) == 0xb8, "Offset mismatch for FBeanCharRagdollConfig::GetupVerticalityDotProductDeadZoneMin");
static_assert(offsetof(FBeanCharRagdollConfig, GetupVerticalityDotProductDeadZoneMax) == 0xbc, "Offset mismatch for FBeanCharRagdollConfig::GetupVerticalityDotProductDeadZoneMax");
static_assert(offsetof(FBeanCharRagdollConfig, MinimumActiveSeconds) == 0xc0, "Offset mismatch for FBeanCharRagdollConfig::MinimumActiveSeconds");
static_assert(offsetof(FBeanCharRagdollConfig, MaxActiveSeconds) == 0xc4, "Offset mismatch for FBeanCharRagdollConfig::MaxActiveSeconds");
static_assert(offsetof(FBeanCharRagdollConfig, AngularVelocityMagnitude) == 0xc8, "Offset mismatch for FBeanCharRagdollConfig::AngularVelocityMagnitude");
static_assert(offsetof(FBeanCharRagdollConfig, HighImpactMaxAnimThreshold) == 0xd0, "Offset mismatch for FBeanCharRagdollConfig::HighImpactMaxAnimThreshold");
static_assert(offsetof(FBeanCharRagdollConfig, SkeletalMeshAnchorBone) == 0xd4, "Offset mismatch for FBeanCharRagdollConfig::SkeletalMeshAnchorBone");
static_assert(offsetof(FBeanCharRagdollConfig, PhysicsBlendWeight) == 0xd8, "Offset mismatch for FBeanCharRagdollConfig::PhysicsBlendWeight");
static_assert(offsetof(FBeanCharRagdollConfig, MeshCapsuleRotationalOffset) == 0xe0, "Offset mismatch for FBeanCharRagdollConfig::MeshCapsuleRotationalOffset");
static_assert(offsetof(FBeanCharRagdollConfig, MeshCapsulePositionalOffset) == 0xf8, "Offset mismatch for FBeanCharRagdollConfig::MeshCapsulePositionalOffset");
static_assert(offsetof(FBeanCharRagdollConfig, DebugTriggerRagdollForce) == 0x110, "Offset mismatch for FBeanCharRagdollConfig::DebugTriggerRagdollForce");
static_assert(offsetof(FBeanCharRagdollConfig, bEnableRollExit) == 0x118, "Offset mismatch for FBeanCharRagdollConfig::bEnableRollExit");
static_assert(offsetof(FBeanCharRagdollConfig, SpeedForRollGetup) == 0x120, "Offset mismatch for FBeanCharRagdollConfig::SpeedForRollGetup");
static_assert(offsetof(FBeanCharRagdollConfig, GroundedCheckHalfHeightScale) == 0x128, "Offset mismatch for FBeanCharRagdollConfig::GroundedCheckHalfHeightScale");
static_assert(offsetof(FBeanCharRagdollConfig, GroundedCheckRadius) == 0x130, "Offset mismatch for FBeanCharRagdollConfig::GroundedCheckRadius");
static_assert(offsetof(FBeanCharRagdollConfig, MinimumTimeOnGround) == 0x138, "Offset mismatch for FBeanCharRagdollConfig::MinimumTimeOnGround");
static_assert(offsetof(FBeanCharRagdollConfig, MeshCollisionChannels) == 0x140, "Offset mismatch for FBeanCharRagdollConfig::MeshCollisionChannels");
static_assert(offsetof(FBeanCharRagdollConfig, MeshBonesWithCCD) == 0x150, "Offset mismatch for FBeanCharRagdollConfig::MeshBonesWithCCD");
static_assert(offsetof(FBeanCharRagdollConfig, MaxRemoteRagdollCharacters) == 0x160, "Offset mismatch for FBeanCharRagdollConfig::MaxRemoteRagdollCharacters");
static_assert(offsetof(FBeanCharRagdollConfig, MaxRemoteRagdollDistance) == 0x168, "Offset mismatch for FBeanCharRagdollConfig::MaxRemoteRagdollDistance");
static_assert(offsetof(FBeanCharRagdollConfig, RemoteRagdollMinimumDeactiveTime) == 0x170, "Offset mismatch for FBeanCharRagdollConfig::RemoteRagdollMinimumDeactiveTime");
static_assert(offsetof(FBeanCharRagdollConfig, bCullRemoteRagdollsBehindCamera) == 0x178, "Offset mismatch for FBeanCharRagdollConfig::bCullRemoteRagdollsBehindCamera");
static_assert(offsetof(FBeanCharRagdollConfig, ReplicationHardsnapDistanceOverride) == 0x180, "Offset mismatch for FBeanCharRagdollConfig::ReplicationHardsnapDistanceOverride");
static_assert(offsetof(FBeanCharRagdollConfig, MaxSecondsStuck) == 0x188, "Offset mismatch for FBeanCharRagdollConfig::MaxSecondsStuck");
static_assert(offsetof(FBeanCharRagdollConfig, SameLocationDistanceTolerance) == 0x190, "Offset mismatch for FBeanCharRagdollConfig::SameLocationDistanceTolerance");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FBeanCharGetupConfig
{
    float AnimationRate; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UCurveFloat* MotionTimeCurve; // 0x8 (Size: 0x8, Type: ObjectProperty)
    float RunSpeedMultiplier; // 0x10 (Size: 0x4, Type: FloatProperty)
    float TurnSpeedOverride; // 0x14 (Size: 0x4, Type: FloatProperty)
    float RestoreMovementAfterDurationNormalized; // 0x18 (Size: 0x4, Type: FloatProperty)
    float EarlyExitStateDurationNormalized; // 0x1c (Size: 0x4, Type: FloatProperty)
    float GetupAnimationThresholdPitch; // 0x20 (Size: 0x4, Type: FloatProperty)
    float SkipAnimationRotationDuration; // 0x24 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBeanCharGetupConfig) == 0x28, "Size mismatch for FBeanCharGetupConfig");
static_assert(offsetof(FBeanCharGetupConfig, AnimationRate) == 0x0, "Offset mismatch for FBeanCharGetupConfig::AnimationRate");
static_assert(offsetof(FBeanCharGetupConfig, MotionTimeCurve) == 0x8, "Offset mismatch for FBeanCharGetupConfig::MotionTimeCurve");
static_assert(offsetof(FBeanCharGetupConfig, RunSpeedMultiplier) == 0x10, "Offset mismatch for FBeanCharGetupConfig::RunSpeedMultiplier");
static_assert(offsetof(FBeanCharGetupConfig, TurnSpeedOverride) == 0x14, "Offset mismatch for FBeanCharGetupConfig::TurnSpeedOverride");
static_assert(offsetof(FBeanCharGetupConfig, RestoreMovementAfterDurationNormalized) == 0x18, "Offset mismatch for FBeanCharGetupConfig::RestoreMovementAfterDurationNormalized");
static_assert(offsetof(FBeanCharGetupConfig, EarlyExitStateDurationNormalized) == 0x1c, "Offset mismatch for FBeanCharGetupConfig::EarlyExitStateDurationNormalized");
static_assert(offsetof(FBeanCharGetupConfig, GetupAnimationThresholdPitch) == 0x20, "Offset mismatch for FBeanCharGetupConfig::GetupAnimationThresholdPitch");
static_assert(offsetof(FBeanCharGetupConfig, SkipAnimationRotationDuration) == 0x24, "Offset mismatch for FBeanCharGetupConfig::SkipAnimationRotationDuration");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBeanCharGetupRollConfig
{
    float duration; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UCurveFloat* MotionTimeCurve; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FBeanCharGetupRollConfig) == 0x10, "Size mismatch for FBeanCharGetupRollConfig");
static_assert(offsetof(FBeanCharGetupRollConfig, duration) == 0x0, "Offset mismatch for FBeanCharGetupRollConfig::duration");
static_assert(offsetof(FBeanCharGetupRollConfig, MotionTimeCurve) == 0x8, "Offset mismatch for FBeanCharGetupRollConfig::MotionTimeCurve");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FBeanCharRollConfig
{
    double ScaleSpeed; // 0x0 (Size: 0x8, Type: DoubleProperty)
    float MinimumDuration; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaximumDurationBeforeForcedExit; // 0xc (Size: 0x4, Type: FloatProperty)
    double ExitSpeed; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double GetupDirectionTolerance; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double ForwardRollBlendSpeed; // 0x20 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FBeanCharRollConfig) == 0x28, "Size mismatch for FBeanCharRollConfig");
static_assert(offsetof(FBeanCharRollConfig, ScaleSpeed) == 0x0, "Offset mismatch for FBeanCharRollConfig::ScaleSpeed");
static_assert(offsetof(FBeanCharRollConfig, MinimumDuration) == 0x8, "Offset mismatch for FBeanCharRollConfig::MinimumDuration");
static_assert(offsetof(FBeanCharRollConfig, MaximumDurationBeforeForcedExit) == 0xc, "Offset mismatch for FBeanCharRollConfig::MaximumDurationBeforeForcedExit");
static_assert(offsetof(FBeanCharRollConfig, ExitSpeed) == 0x10, "Offset mismatch for FBeanCharRollConfig::ExitSpeed");
static_assert(offsetof(FBeanCharRollConfig, GetupDirectionTolerance) == 0x18, "Offset mismatch for FBeanCharRollConfig::GetupDirectionTolerance");
static_assert(offsetof(FBeanCharRollConfig, ForwardRollBlendSpeed) == 0x20, "Offset mismatch for FBeanCharRollConfig::ForwardRollBlendSpeed");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FBeanCharMantleConfig
{
    TArray<TEnumAsByte<ECollisionChannel>> AcceptedCollisionChannels; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TEnumAsByte<EComponentMobility> HighestAcceptedComponentMobility; // 0x10 (Size: 0x1, Type: ByteProperty)
    bool bAllowMantleOnAllSceneGraphEntities; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
    double WallCheckDownOffset; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double WallCheckDownOffsetDiving; // 0x20 (Size: 0x8, Type: DoubleProperty)
    double WallCheckRadius; // 0x28 (Size: 0x8, Type: DoubleProperty)
    double WallCheckHeight; // 0x30 (Size: 0x8, Type: DoubleProperty)
    double WallCheckLength; // 0x38 (Size: 0x8, Type: DoubleProperty)
    double WallCheckMaxAngle; // 0x40 (Size: 0x8, Type: DoubleProperty)
    double WallCheckMinFacingAlignment; // 0x48 (Size: 0x8, Type: DoubleProperty)
    double WallTopCheckMinimumLength; // 0x50 (Size: 0x8, Type: DoubleProperty)
    double WallTopCheckRadius; // 0x58 (Size: 0x8, Type: DoubleProperty)
    double WallTopMinUpwardAlignment; // 0x60 (Size: 0x8, Type: DoubleProperty)
    double LedgeCheckLength; // 0x68 (Size: 0x8, Type: DoubleProperty)
    double LedgeCheckRadius; // 0x70 (Size: 0x8, Type: DoubleProperty)
    double HangingSpotHorizontalOffset; // 0x78 (Size: 0x8, Type: DoubleProperty)
    double HangingSpotVerticalOffset; // 0x80 (Size: 0x8, Type: DoubleProperty)
    double HangingSpotMinimumHeight; // 0x88 (Size: 0x8, Type: DoubleProperty)
    double HangingSpotMaxInclineDot; // 0x90 (Size: 0x8, Type: DoubleProperty)
    float AnimationRate; // 0x98 (Size: 0x4, Type: FloatProperty)
    float RestoreMovementAfterDurationNormalized; // 0x9c (Size: 0x4, Type: FloatProperty)
    float RestoreMovementVelocityMultiplier; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float CancelBuffer; // 0xa4 (Size: 0x4, Type: FloatProperty)
    float CancelInputDuration; // 0xa8 (Size: 0x4, Type: FloatProperty)
    float CooldownTime; // 0xac (Size: 0x4, Type: FloatProperty)
    float TimeToValidate; // 0xb0 (Size: 0x4, Type: FloatProperty)
    FName HangingSpotMotionWarp; // 0xb4 (Size: 0x4, Type: NameProperty)
    float ClamberEnabledCacheTime; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float VelocityProjectionSeconds; // 0xbc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBeanCharMantleConfig) == 0xc0, "Size mismatch for FBeanCharMantleConfig");
static_assert(offsetof(FBeanCharMantleConfig, AcceptedCollisionChannels) == 0x0, "Offset mismatch for FBeanCharMantleConfig::AcceptedCollisionChannels");
static_assert(offsetof(FBeanCharMantleConfig, HighestAcceptedComponentMobility) == 0x10, "Offset mismatch for FBeanCharMantleConfig::HighestAcceptedComponentMobility");
static_assert(offsetof(FBeanCharMantleConfig, bAllowMantleOnAllSceneGraphEntities) == 0x11, "Offset mismatch for FBeanCharMantleConfig::bAllowMantleOnAllSceneGraphEntities");
static_assert(offsetof(FBeanCharMantleConfig, WallCheckDownOffset) == 0x18, "Offset mismatch for FBeanCharMantleConfig::WallCheckDownOffset");
static_assert(offsetof(FBeanCharMantleConfig, WallCheckDownOffsetDiving) == 0x20, "Offset mismatch for FBeanCharMantleConfig::WallCheckDownOffsetDiving");
static_assert(offsetof(FBeanCharMantleConfig, WallCheckRadius) == 0x28, "Offset mismatch for FBeanCharMantleConfig::WallCheckRadius");
static_assert(offsetof(FBeanCharMantleConfig, WallCheckHeight) == 0x30, "Offset mismatch for FBeanCharMantleConfig::WallCheckHeight");
static_assert(offsetof(FBeanCharMantleConfig, WallCheckLength) == 0x38, "Offset mismatch for FBeanCharMantleConfig::WallCheckLength");
static_assert(offsetof(FBeanCharMantleConfig, WallCheckMaxAngle) == 0x40, "Offset mismatch for FBeanCharMantleConfig::WallCheckMaxAngle");
static_assert(offsetof(FBeanCharMantleConfig, WallCheckMinFacingAlignment) == 0x48, "Offset mismatch for FBeanCharMantleConfig::WallCheckMinFacingAlignment");
static_assert(offsetof(FBeanCharMantleConfig, WallTopCheckMinimumLength) == 0x50, "Offset mismatch for FBeanCharMantleConfig::WallTopCheckMinimumLength");
static_assert(offsetof(FBeanCharMantleConfig, WallTopCheckRadius) == 0x58, "Offset mismatch for FBeanCharMantleConfig::WallTopCheckRadius");
static_assert(offsetof(FBeanCharMantleConfig, WallTopMinUpwardAlignment) == 0x60, "Offset mismatch for FBeanCharMantleConfig::WallTopMinUpwardAlignment");
static_assert(offsetof(FBeanCharMantleConfig, LedgeCheckLength) == 0x68, "Offset mismatch for FBeanCharMantleConfig::LedgeCheckLength");
static_assert(offsetof(FBeanCharMantleConfig, LedgeCheckRadius) == 0x70, "Offset mismatch for FBeanCharMantleConfig::LedgeCheckRadius");
static_assert(offsetof(FBeanCharMantleConfig, HangingSpotHorizontalOffset) == 0x78, "Offset mismatch for FBeanCharMantleConfig::HangingSpotHorizontalOffset");
static_assert(offsetof(FBeanCharMantleConfig, HangingSpotVerticalOffset) == 0x80, "Offset mismatch for FBeanCharMantleConfig::HangingSpotVerticalOffset");
static_assert(offsetof(FBeanCharMantleConfig, HangingSpotMinimumHeight) == 0x88, "Offset mismatch for FBeanCharMantleConfig::HangingSpotMinimumHeight");
static_assert(offsetof(FBeanCharMantleConfig, HangingSpotMaxInclineDot) == 0x90, "Offset mismatch for FBeanCharMantleConfig::HangingSpotMaxInclineDot");
static_assert(offsetof(FBeanCharMantleConfig, AnimationRate) == 0x98, "Offset mismatch for FBeanCharMantleConfig::AnimationRate");
static_assert(offsetof(FBeanCharMantleConfig, RestoreMovementAfterDurationNormalized) == 0x9c, "Offset mismatch for FBeanCharMantleConfig::RestoreMovementAfterDurationNormalized");
static_assert(offsetof(FBeanCharMantleConfig, RestoreMovementVelocityMultiplier) == 0xa0, "Offset mismatch for FBeanCharMantleConfig::RestoreMovementVelocityMultiplier");
static_assert(offsetof(FBeanCharMantleConfig, CancelBuffer) == 0xa4, "Offset mismatch for FBeanCharMantleConfig::CancelBuffer");
static_assert(offsetof(FBeanCharMantleConfig, CancelInputDuration) == 0xa8, "Offset mismatch for FBeanCharMantleConfig::CancelInputDuration");
static_assert(offsetof(FBeanCharMantleConfig, CooldownTime) == 0xac, "Offset mismatch for FBeanCharMantleConfig::CooldownTime");
static_assert(offsetof(FBeanCharMantleConfig, TimeToValidate) == 0xb0, "Offset mismatch for FBeanCharMantleConfig::TimeToValidate");
static_assert(offsetof(FBeanCharMantleConfig, HangingSpotMotionWarp) == 0xb4, "Offset mismatch for FBeanCharMantleConfig::HangingSpotMotionWarp");
static_assert(offsetof(FBeanCharMantleConfig, ClamberEnabledCacheTime) == 0xb8, "Offset mismatch for FBeanCharMantleConfig::ClamberEnabledCacheTime");
static_assert(offsetof(FBeanCharMantleConfig, VelocityProjectionSeconds) == 0xbc, "Offset mismatch for FBeanCharMantleConfig::VelocityProjectionSeconds");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FBeanCharJostleConfig
{
    float JostleTriggerRadius; // 0x0 (Size: 0x4, Type: FloatProperty)
    float JostleOuterRadius; // 0x4 (Size: 0x4, Type: FloatProperty)
    float JostleInnerRadius; // 0x8 (Size: 0x4, Type: FloatProperty)
    float JostleMandatoryRadius; // 0xc (Size: 0x4, Type: FloatProperty)
    double JostleForceMultiplier; // 0x10 (Size: 0x8, Type: DoubleProperty)
    float JostlerMinSpeedToApplyForce; // 0x18 (Size: 0x4, Type: FloatProperty)
    float JostleeMaxSpeedToTrigger; // 0x1c (Size: 0x4, Type: FloatProperty)
    float JostleeMaxSpeedToApplyForce; // 0x20 (Size: 0x4, Type: FloatProperty)
    float JostleRefreshInterval; // 0x24 (Size: 0x4, Type: FloatProperty)
    float PositionToleranceDuringJostle; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FBeanCharJostleConfig) == 0x30, "Size mismatch for FBeanCharJostleConfig");
static_assert(offsetof(FBeanCharJostleConfig, JostleTriggerRadius) == 0x0, "Offset mismatch for FBeanCharJostleConfig::JostleTriggerRadius");
static_assert(offsetof(FBeanCharJostleConfig, JostleOuterRadius) == 0x4, "Offset mismatch for FBeanCharJostleConfig::JostleOuterRadius");
static_assert(offsetof(FBeanCharJostleConfig, JostleInnerRadius) == 0x8, "Offset mismatch for FBeanCharJostleConfig::JostleInnerRadius");
static_assert(offsetof(FBeanCharJostleConfig, JostleMandatoryRadius) == 0xc, "Offset mismatch for FBeanCharJostleConfig::JostleMandatoryRadius");
static_assert(offsetof(FBeanCharJostleConfig, JostleForceMultiplier) == 0x10, "Offset mismatch for FBeanCharJostleConfig::JostleForceMultiplier");
static_assert(offsetof(FBeanCharJostleConfig, JostlerMinSpeedToApplyForce) == 0x18, "Offset mismatch for FBeanCharJostleConfig::JostlerMinSpeedToApplyForce");
static_assert(offsetof(FBeanCharJostleConfig, JostleeMaxSpeedToTrigger) == 0x1c, "Offset mismatch for FBeanCharJostleConfig::JostleeMaxSpeedToTrigger");
static_assert(offsetof(FBeanCharJostleConfig, JostleeMaxSpeedToApplyForce) == 0x20, "Offset mismatch for FBeanCharJostleConfig::JostleeMaxSpeedToApplyForce");
static_assert(offsetof(FBeanCharJostleConfig, JostleRefreshInterval) == 0x24, "Offset mismatch for FBeanCharJostleConfig::JostleRefreshInterval");
static_assert(offsetof(FBeanCharJostleConfig, PositionToleranceDuringJostle) == 0x28, "Offset mismatch for FBeanCharJostleConfig::PositionToleranceDuringJostle");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FBeanCharCameraConfig
{
    UClass* CameraMode; // 0x0 (Size: 0x8, Type: ClassProperty)
    UClass* OverrideVehicleCameraMode; // 0x8 (Size: 0x8, Type: ClassProperty)
    float EnableDragAfterTeleportTimeout; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FBeanCharCameraConfig) == 0x18, "Size mismatch for FBeanCharCameraConfig");
static_assert(offsetof(FBeanCharCameraConfig, CameraMode) == 0x0, "Offset mismatch for FBeanCharCameraConfig::CameraMode");
static_assert(offsetof(FBeanCharCameraConfig, OverrideVehicleCameraMode) == 0x8, "Offset mismatch for FBeanCharCameraConfig::OverrideVehicleCameraMode");
static_assert(offsetof(FBeanCharCameraConfig, EnableDragAfterTeleportTimeout) == 0x10, "Offset mismatch for FBeanCharCameraConfig::EnableDragAfterTeleportTimeout");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBeanCharCosmeticConfig
{
    TArray<UAthenaDanceItemDefinition*> DefaultEmotes; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FBeanCharCosmeticConfig) == 0x10, "Size mismatch for FBeanCharCosmeticConfig");
static_assert(offsetof(FBeanCharCosmeticConfig, DefaultEmotes) == 0x0, "Offset mismatch for FBeanCharCosmeticConfig::DefaultEmotes");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FBeanCharSwimmingConfig
{
    float HeadingAdjustmentStrength; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinImmersionDepth; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaxImmersionDepth; // 0x8 (Size: 0x4, Type: FloatProperty)
    float TargetImmersionDepth; // 0xc (Size: 0x4, Type: FloatProperty)
    float JumpMinVelocityZ; // 0x10 (Size: 0x4, Type: FloatProperty)
    float JumpMaxVelocityZ; // 0x14 (Size: 0x4, Type: FloatProperty)
    float JumpForceZ; // 0x18 (Size: 0x4, Type: FloatProperty)
    float JumpForceDuration; // 0x1c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBeanCharSwimmingConfig) == 0x20, "Size mismatch for FBeanCharSwimmingConfig");
static_assert(offsetof(FBeanCharSwimmingConfig, HeadingAdjustmentStrength) == 0x0, "Offset mismatch for FBeanCharSwimmingConfig::HeadingAdjustmentStrength");
static_assert(offsetof(FBeanCharSwimmingConfig, MinImmersionDepth) == 0x4, "Offset mismatch for FBeanCharSwimmingConfig::MinImmersionDepth");
static_assert(offsetof(FBeanCharSwimmingConfig, MaxImmersionDepth) == 0x8, "Offset mismatch for FBeanCharSwimmingConfig::MaxImmersionDepth");
static_assert(offsetof(FBeanCharSwimmingConfig, TargetImmersionDepth) == 0xc, "Offset mismatch for FBeanCharSwimmingConfig::TargetImmersionDepth");
static_assert(offsetof(FBeanCharSwimmingConfig, JumpMinVelocityZ) == 0x10, "Offset mismatch for FBeanCharSwimmingConfig::JumpMinVelocityZ");
static_assert(offsetof(FBeanCharSwimmingConfig, JumpMaxVelocityZ) == 0x14, "Offset mismatch for FBeanCharSwimmingConfig::JumpMaxVelocityZ");
static_assert(offsetof(FBeanCharSwimmingConfig, JumpForceZ) == 0x18, "Offset mismatch for FBeanCharSwimmingConfig::JumpForceZ");
static_assert(offsetof(FBeanCharSwimmingConfig, JumpForceDuration) == 0x1c, "Offset mismatch for FBeanCharSwimmingConfig::JumpForceDuration");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FBeanCharZiplineConfig
{
    float ZiplineTurnSpeed; // 0x0 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBeanCharZiplineConfig) == 0x4, "Size mismatch for FBeanCharZiplineConfig");
static_assert(offsetof(FBeanCharZiplineConfig, ZiplineTurnSpeed) == 0x0, "Offset mismatch for FBeanCharZiplineConfig::ZiplineTurnSpeed");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FBeanCharJiggleConfig
{
    TArray<float> BoneWeights; // 0x0 (Size: 0x10, Type: ArrayProperty)
    double BeingGrabbedWeightMultiplier; // 0x10 (Size: 0x8, Type: DoubleProperty)
    TArray<FBeanJiggleStateWeightOverride> StateWeightOverrides; // 0x18 (Size: 0x10, Type: ArrayProperty)
    float StateWeightBlendDuration; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    double PlatformVelocityMultiplier; // 0x30 (Size: 0x8, Type: DoubleProperty)
    double AccelerationNoiseCutoff; // 0x38 (Size: 0x8, Type: DoubleProperty)
    double Mass; // 0x40 (Size: 0x8, Type: DoubleProperty)
    double SpringConst; // 0x48 (Size: 0x8, Type: DoubleProperty)
    double SpringPivotOffset; // 0x50 (Size: 0x8, Type: DoubleProperty)
    double SpringDamping; // 0x58 (Size: 0x8, Type: DoubleProperty)
    double SpringInterpSpeed; // 0x60 (Size: 0x8, Type: DoubleProperty)
    double ClampOffsetFactor; // 0x68 (Size: 0x8, Type: DoubleProperty)
    double MaxInputForce; // 0x70 (Size: 0x8, Type: DoubleProperty)
    FVector AccelerationAxisWeights; // 0x78 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FBeanCharJiggleConfig) == 0x90, "Size mismatch for FBeanCharJiggleConfig");
static_assert(offsetof(FBeanCharJiggleConfig, BoneWeights) == 0x0, "Offset mismatch for FBeanCharJiggleConfig::BoneWeights");
static_assert(offsetof(FBeanCharJiggleConfig, BeingGrabbedWeightMultiplier) == 0x10, "Offset mismatch for FBeanCharJiggleConfig::BeingGrabbedWeightMultiplier");
static_assert(offsetof(FBeanCharJiggleConfig, StateWeightOverrides) == 0x18, "Offset mismatch for FBeanCharJiggleConfig::StateWeightOverrides");
static_assert(offsetof(FBeanCharJiggleConfig, StateWeightBlendDuration) == 0x28, "Offset mismatch for FBeanCharJiggleConfig::StateWeightBlendDuration");
static_assert(offsetof(FBeanCharJiggleConfig, PlatformVelocityMultiplier) == 0x30, "Offset mismatch for FBeanCharJiggleConfig::PlatformVelocityMultiplier");
static_assert(offsetof(FBeanCharJiggleConfig, AccelerationNoiseCutoff) == 0x38, "Offset mismatch for FBeanCharJiggleConfig::AccelerationNoiseCutoff");
static_assert(offsetof(FBeanCharJiggleConfig, Mass) == 0x40, "Offset mismatch for FBeanCharJiggleConfig::Mass");
static_assert(offsetof(FBeanCharJiggleConfig, SpringConst) == 0x48, "Offset mismatch for FBeanCharJiggleConfig::SpringConst");
static_assert(offsetof(FBeanCharJiggleConfig, SpringPivotOffset) == 0x50, "Offset mismatch for FBeanCharJiggleConfig::SpringPivotOffset");
static_assert(offsetof(FBeanCharJiggleConfig, SpringDamping) == 0x58, "Offset mismatch for FBeanCharJiggleConfig::SpringDamping");
static_assert(offsetof(FBeanCharJiggleConfig, SpringInterpSpeed) == 0x60, "Offset mismatch for FBeanCharJiggleConfig::SpringInterpSpeed");
static_assert(offsetof(FBeanCharJiggleConfig, ClampOffsetFactor) == 0x68, "Offset mismatch for FBeanCharJiggleConfig::ClampOffsetFactor");
static_assert(offsetof(FBeanCharJiggleConfig, MaxInputForce) == 0x70, "Offset mismatch for FBeanCharJiggleConfig::MaxInputForce");
static_assert(offsetof(FBeanCharJiggleConfig, AccelerationAxisWeights) == 0x78, "Offset mismatch for FBeanCharJiggleConfig::AccelerationAxisWeights");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FBeanCharHUDConfig
{
    FGameplayTagContainer HiddenHUDElements; // 0x0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FBeanCharHUDConfig) == 0x20, "Size mismatch for FBeanCharHUDConfig");
static_assert(offsetof(FBeanCharHUDConfig, HiddenHUDElements) == 0x0, "Offset mismatch for FBeanCharHUDConfig::HiddenHUDElements");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FBeanCharTouchControlsConfig
{
    int32_t NumLandingPredictionTraceSubdivisions; // 0x0 (Size: 0x4, Type: IntProperty)
    float JumpDiveButtonAdditionalCoyoteTime; // 0x4 (Size: 0x4, Type: FloatProperty)
    float JumpDiveButtonAdditionalReverseCoyoteTime; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBeanCharTouchControlsConfig) == 0xc, "Size mismatch for FBeanCharTouchControlsConfig");
static_assert(offsetof(FBeanCharTouchControlsConfig, NumLandingPredictionTraceSubdivisions) == 0x0, "Offset mismatch for FBeanCharTouchControlsConfig::NumLandingPredictionTraceSubdivisions");
static_assert(offsetof(FBeanCharTouchControlsConfig, JumpDiveButtonAdditionalCoyoteTime) == 0x4, "Offset mismatch for FBeanCharTouchControlsConfig::JumpDiveButtonAdditionalCoyoteTime");
static_assert(offsetof(FBeanCharTouchControlsConfig, JumpDiveButtonAdditionalReverseCoyoteTime) == 0x8, "Offset mismatch for FBeanCharTouchControlsConfig::JumpDiveButtonAdditionalReverseCoyoteTime");

