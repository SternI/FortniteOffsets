/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Effects
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "NiagaraAnimNotifies.h"
#include "EngineCameras.h"
#include "FortniteGame.h"
#include "FieldSystemEngine.h"
#include "Niagara.h"

// Size: 0x3a8 (Inherited: 0x958, Single: 0xfffffa50)
class AB_CameraLens_Geyser_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x390 (Size: 0x8, Type: StructProperty)
    float Timeline_0_Alpha_3D5AA2144E9B8D6D3B409B845315B143; // 0x398 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_3D5AA2144E9B8D6D3B409B845315B143; // 0x39c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39d[0x3]; // 0x39d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Timeline_0; // 0x3a0 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void ReceiveDestroyed(); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AB_CameraLens_Geyser_C) == 0x3a8, "Size mismatch for AB_CameraLens_Geyser_C");
static_assert(offsetof(AB_CameraLens_Geyser_C, UberGraphFrame) == 0x390, "Offset mismatch for AB_CameraLens_Geyser_C::UberGraphFrame");
static_assert(offsetof(AB_CameraLens_Geyser_C, Timeline_0_Alpha_3D5AA2144E9B8D6D3B409B845315B143) == 0x398, "Offset mismatch for AB_CameraLens_Geyser_C::Timeline_0_Alpha_3D5AA2144E9B8D6D3B409B845315B143");
static_assert(offsetof(AB_CameraLens_Geyser_C, Timeline_0__Direction_3D5AA2144E9B8D6D3B409B845315B143) == 0x39c, "Offset mismatch for AB_CameraLens_Geyser_C::Timeline_0__Direction_3D5AA2144E9B8D6D3B409B845315B143");
static_assert(offsetof(AB_CameraLens_Geyser_C, Timeline_0) == 0x3a0, "Offset mismatch for AB_CameraLens_Geyser_C::Timeline_0");

// Size: 0x44 (Inherited: 0x0, Single: 0x44)
struct FStruc_NiagaraParameters
{
    TEnumAsByte<ENUM_NiagaraParameterSetup> ParameterSelection_14_A6D4854946F722970AD7D0AEC96E4705; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FName FloatParameterName_17_6AFBA48F43B44BD1ED9841983BEFA202; // 0x4 (Size: 0x4, Type: NameProperty)
    float FloatParameterValue_28_AC98B6464E1CD803B50B47AEC91741EC; // 0x8 (Size: 0x4, Type: FloatProperty)
    FName VectorParameterName_20_71917CFB490B3D5D3E0864A3EE90C666; // 0xc (Size: 0x4, Type: NameProperty)
    FVector VectorParameterValue_27_248856604659F589FF5D4FA5FF52E013; // 0x10 (Size: 0x18, Type: StructProperty)
    FName LinearColorparameterName_22_69C61F8D45C74F98203920856CAD5ADE; // 0x28 (Size: 0x4, Type: NameProperty)
    FLinearColor LinearColorParameterValue_29_861B08ED408F0F612BF509A2A94F377F; // 0x2c (Size: 0x10, Type: StructProperty)
    FName IntegerParameterName_24_98306BA7452D90289F6EE9954C4F2B1D; // 0x3c (Size: 0x4, Type: NameProperty)
    int32_t IntegerParameterValue_25_BB84ADEA4515AABD3B9AC6A04453D826; // 0x40 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FStruc_NiagaraParameters) == 0x44, "Size mismatch for FStruc_NiagaraParameters");
static_assert(offsetof(FStruc_NiagaraParameters, ParameterSelection_14_A6D4854946F722970AD7D0AEC96E4705) == 0x0, "Offset mismatch for FStruc_NiagaraParameters::ParameterSelection_14_A6D4854946F722970AD7D0AEC96E4705");
static_assert(offsetof(FStruc_NiagaraParameters, FloatParameterName_17_6AFBA48F43B44BD1ED9841983BEFA202) == 0x4, "Offset mismatch for FStruc_NiagaraParameters::FloatParameterName_17_6AFBA48F43B44BD1ED9841983BEFA202");
static_assert(offsetof(FStruc_NiagaraParameters, FloatParameterValue_28_AC98B6464E1CD803B50B47AEC91741EC) == 0x8, "Offset mismatch for FStruc_NiagaraParameters::FloatParameterValue_28_AC98B6464E1CD803B50B47AEC91741EC");
static_assert(offsetof(FStruc_NiagaraParameters, VectorParameterName_20_71917CFB490B3D5D3E0864A3EE90C666) == 0xc, "Offset mismatch for FStruc_NiagaraParameters::VectorParameterName_20_71917CFB490B3D5D3E0864A3EE90C666");
static_assert(offsetof(FStruc_NiagaraParameters, VectorParameterValue_27_248856604659F589FF5D4FA5FF52E013) == 0x10, "Offset mismatch for FStruc_NiagaraParameters::VectorParameterValue_27_248856604659F589FF5D4FA5FF52E013");
static_assert(offsetof(FStruc_NiagaraParameters, LinearColorparameterName_22_69C61F8D45C74F98203920856CAD5ADE) == 0x28, "Offset mismatch for FStruc_NiagaraParameters::LinearColorparameterName_22_69C61F8D45C74F98203920856CAD5ADE");
static_assert(offsetof(FStruc_NiagaraParameters, LinearColorParameterValue_29_861B08ED408F0F612BF509A2A94F377F) == 0x2c, "Offset mismatch for FStruc_NiagaraParameters::LinearColorParameterValue_29_861B08ED408F0F612BF509A2A94F377F");
static_assert(offsetof(FStruc_NiagaraParameters, IntegerParameterName_24_98306BA7452D90289F6EE9954C4F2B1D) == 0x3c, "Offset mismatch for FStruc_NiagaraParameters::IntegerParameterName_24_98306BA7452D90289F6EE9954C4F2B1D");
static_assert(offsetof(FStruc_NiagaraParameters, IntegerParameterValue_25_BB84ADEA4515AABD3B9AC6A04453D826) == 0x40, "Offset mismatch for FStruc_NiagaraParameters::IntegerParameterValue_25_BB84ADEA4515AABD3B9AC6A04453D826");

// Size: 0x3a0 (Inherited: 0xcf0, Single: 0xfffff6b0)
class AB_PlayerShieldDamage_CameraLensEffect_C : public AB_PlayerHealthDamage_CameraLensEffect_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x398 (Size: 0x8, Type: StructProperty)

};

static_assert(sizeof(AB_PlayerShieldDamage_CameraLensEffect_C) == 0x3a0, "Size mismatch for AB_PlayerShieldDamage_CameraLensEffect_C");
static_assert(offsetof(AB_PlayerShieldDamage_CameraLensEffect_C, UberGraphFrame) == 0x398, "Offset mismatch for AB_PlayerShieldDamage_CameraLensEffect_C::UberGraphFrame");

// Size: 0x398 (Inherited: 0x958, Single: 0xfffffa40)
class AB_PlayerHealthDamage_CameraLensEffect_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x390 (Size: 0x8, Type: StructProperty)

};

static_assert(sizeof(AB_PlayerHealthDamage_CameraLensEffect_C) == 0x398, "Size mismatch for AB_PlayerHealthDamage_CameraLensEffect_C");
static_assert(offsetof(AB_PlayerHealthDamage_CameraLensEffect_C, UberGraphFrame) == 0x390, "Offset mismatch for AB_PlayerHealthDamage_CameraLensEffect_C::UberGraphFrame");

// Size: 0xa0 (Inherited: 0xe8, Single: 0xffffffb8)
class UAnimNotifyState_NiagaraNotify_SetParameters_C : public UAnimNotifyState_TimedNiagaraEffect
{
public:
    TArray<FStruc_NiagaraParameters> Parameter_Setup; // 0x90 (Size: 0x10, Type: ArrayProperty)

public:
    virtual bool Received_NotifyTick(USkeletalMeshComponent*& MeshComp, UAnimSequenceBase*& Animation, float& FrameDeltaTime, const FAnimNotifyEventReference EventReference) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UAnimNotifyState_NiagaraNotify_SetParameters_C) == 0xa0, "Size mismatch for UAnimNotifyState_NiagaraNotify_SetParameters_C");
static_assert(offsetof(UAnimNotifyState_NiagaraNotify_SetParameters_C, Parameter_Setup) == 0x90, "Offset mismatch for UAnimNotifyState_NiagaraNotify_SetParameters_C::Parameter_Setup");

// Size: 0x1f0 (Inherited: 0x2f8, Single: 0xfffffef8)
class UBP_Camera_Shake_Pulse_Zoom_C : public ULegacyCameraShake
{
public:
};

static_assert(sizeof(UBP_Camera_Shake_Pulse_Zoom_C) == 0x1f0, "Size mismatch for UBP_Camera_Shake_Pulse_Zoom_C");

// Size: 0x1f0 (Inherited: 0x2f8, Single: 0xfffffef8)
class UB_Large_Explosion_CameraShake_C : public ULegacyCameraShake
{
public:
};

static_assert(sizeof(UB_Large_Explosion_CameraShake_C) == 0x1f0, "Size mismatch for UB_Large_Explosion_CameraShake_C");

// Size: 0x390 (Inherited: 0x958, Single: 0xfffffa38)
class AB_CameraLens_Victory_Direct_C : public AEmitterCameraLensEffectBase
{
public:
};

static_assert(sizeof(AB_CameraLens_Victory_Direct_C) == 0x390, "Size mismatch for AB_CameraLens_Victory_Direct_C");

// Size: 0x390 (Inherited: 0x958, Single: 0xfffffa38)
class AB_CameraLens_Victory_Ally_C : public AEmitterCameraLensEffectBase
{
public:
};

static_assert(sizeof(AB_CameraLens_Victory_Ally_C) == 0x390, "Size mismatch for AB_CameraLens_Victory_Ally_C");

// Size: 0x1f0 (Inherited: 0x2f8, Single: 0xfffffef8)
class UBP_Camera_Shake_Pulse_Only_C : public ULegacyCameraShake
{
public:
};

static_assert(sizeof(UBP_Camera_Shake_Pulse_Only_C) == 0x1f0, "Size mismatch for UBP_Camera_Shake_Pulse_Only_C");

// Size: 0x3a8 (Inherited: 0x958, Single: 0xfffffa50)
class AB_CameraLens_Boat_Droplets_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x390 (Size: 0x8, Type: StructProperty)
    float Timeline_0_Alpha_0C9ACFAF463718824428D0A86CC5D789; // 0x398 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_0C9ACFAF463718824428D0A86CC5D789; // 0x39c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39d[0x3]; // 0x39d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Timeline_0; // 0x3a0 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void ReceiveDestroyed(); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AB_CameraLens_Boat_Droplets_C) == 0x3a8, "Size mismatch for AB_CameraLens_Boat_Droplets_C");
static_assert(offsetof(AB_CameraLens_Boat_Droplets_C, UberGraphFrame) == 0x390, "Offset mismatch for AB_CameraLens_Boat_Droplets_C::UberGraphFrame");
static_assert(offsetof(AB_CameraLens_Boat_Droplets_C, Timeline_0_Alpha_0C9ACFAF463718824428D0A86CC5D789) == 0x398, "Offset mismatch for AB_CameraLens_Boat_Droplets_C::Timeline_0_Alpha_0C9ACFAF463718824428D0A86CC5D789");
static_assert(offsetof(AB_CameraLens_Boat_Droplets_C, Timeline_0__Direction_0C9ACFAF463718824428D0A86CC5D789) == 0x39c, "Offset mismatch for AB_CameraLens_Boat_Droplets_C::Timeline_0__Direction_0C9ACFAF463718824428D0A86CC5D789");
static_assert(offsetof(AB_CameraLens_Boat_Droplets_C, Timeline_0) == 0x3a0, "Offset mismatch for AB_CameraLens_Boat_Droplets_C::Timeline_0");

// Size: 0x398 (Inherited: 0x958, Single: 0xfffffa40)
class AB_CameraLens_Splash_Water_Droplets_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x390 (Size: 0x8, Type: StructProperty)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AB_CameraLens_Splash_Water_Droplets_C) == 0x398, "Size mismatch for AB_CameraLens_Splash_Water_Droplets_C");
static_assert(offsetof(AB_CameraLens_Splash_Water_Droplets_C, UberGraphFrame) == 0x390, "Offset mismatch for AB_CameraLens_Splash_Water_Droplets_C::UberGraphFrame");

// Size: 0x1f0 (Inherited: 0x2f8, Single: 0xfffffef8)
class UB_Small_Explosion_CameraShake_C : public ULegacyCameraShake
{
public:
};

static_assert(sizeof(UB_Small_Explosion_CameraShake_C) == 0x1f0, "Size mismatch for UB_Small_Explosion_CameraShake_C");

// Size: 0x1f0 (Inherited: 0x2f8, Single: 0xfffffef8)
class UB_Small_Vertical_Jolt_CameraShake_C : public ULegacyCameraShake
{
public:
};

static_assert(sizeof(UB_Small_Vertical_Jolt_CameraShake_C) == 0x1f0, "Size mismatch for UB_Small_Vertical_Jolt_CameraShake_C");

// Size: 0x3a0 (Inherited: 0x958, Single: 0xfffffa48)
class AB_CameraLens_Lava_Bouncing_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x390 (Size: 0x8, Type: StructProperty)
    UParticleSystemComponent* P_Camera_Lava_Bouncing; // 0x398 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AB_CameraLens_Lava_Bouncing_C) == 0x3a0, "Size mismatch for AB_CameraLens_Lava_Bouncing_C");
static_assert(offsetof(AB_CameraLens_Lava_Bouncing_C, UberGraphFrame) == 0x390, "Offset mismatch for AB_CameraLens_Lava_Bouncing_C::UberGraphFrame");
static_assert(offsetof(AB_CameraLens_Lava_Bouncing_C, P_Camera_Lava_Bouncing) == 0x398, "Offset mismatch for AB_CameraLens_Lava_Bouncing_C::P_Camera_Lava_Bouncing");

// Size: 0x398 (Inherited: 0x958, Single: 0xfffffa40)
class AB_CameraLens_SpookyMist_End_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x390 (Size: 0x8, Type: StructProperty)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AB_CameraLens_SpookyMist_End_C) == 0x398, "Size mismatch for AB_CameraLens_SpookyMist_End_C");
static_assert(offsetof(AB_CameraLens_SpookyMist_End_C, UberGraphFrame) == 0x390, "Offset mismatch for AB_CameraLens_SpookyMist_End_C::UberGraphFrame");

// Size: 0x398 (Inherited: 0x958, Single: 0xfffffa40)
class AB_CameraLens_SpookyMist_Loop_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x390 (Size: 0x8, Type: StructProperty)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AB_CameraLens_SpookyMist_Loop_C) == 0x398, "Size mismatch for AB_CameraLens_SpookyMist_Loop_C");
static_assert(offsetof(AB_CameraLens_SpookyMist_Loop_C, UberGraphFrame) == 0x390, "Offset mismatch for AB_CameraLens_SpookyMist_Loop_C::UberGraphFrame");

// Size: 0x390 (Inherited: 0x958, Single: 0xfffffa38)
class ABP_SpeedLines_Looping_Camera_Lens_Vehicle_C : public AEmitterCameraLensEffectBase
{
public:
};

static_assert(sizeof(ABP_SpeedLines_Looping_Camera_Lens_Vehicle_C) == 0x390, "Size mismatch for ABP_SpeedLines_Looping_Camera_Lens_Vehicle_C");

// Size: 0x1f0 (Inherited: 0x2f8, Single: 0xfffffef8)
class UBP_CameraShake_PortalWarp_C : public ULegacyCameraShake
{
public:
};

static_assert(sizeof(UBP_CameraShake_PortalWarp_C) == 0x1f0, "Size mismatch for UBP_CameraShake_PortalWarp_C");

// Size: 0x398 (Inherited: 0x958, Single: 0xfffffa40)
class AB_CameraLens_Shadow_Bomb_Loop_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x390 (Size: 0x8, Type: StructProperty)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AB_CameraLens_Shadow_Bomb_Loop_C) == 0x398, "Size mismatch for AB_CameraLens_Shadow_Bomb_Loop_C");
static_assert(offsetof(AB_CameraLens_Shadow_Bomb_Loop_C, UberGraphFrame) == 0x390, "Offset mismatch for AB_CameraLens_Shadow_Bomb_Loop_C::UberGraphFrame");

// Size: 0x1f0 (Inherited: 0x2f8, Single: 0xfffffef8)
class UBP_CamShake_BlurPulse_C : public ULegacyCameraShake
{
public:
};

static_assert(sizeof(UBP_CamShake_BlurPulse_C) == 0x1f0, "Size mismatch for UBP_CamShake_BlurPulse_C");

// Size: 0x398 (Inherited: 0x958, Single: 0xfffffa40)
class AB_CameraLens_Drown_Damage_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x390 (Size: 0x8, Type: StructProperty)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AB_CameraLens_Drown_Damage_C) == 0x398, "Size mismatch for AB_CameraLens_Drown_Damage_C");
static_assert(offsetof(AB_CameraLens_Drown_Damage_C, UberGraphFrame) == 0x390, "Offset mismatch for AB_CameraLens_Drown_Damage_C::UberGraphFrame");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class USSI_BpLib_BpTools_C : public UBlueprintFunctionLibrary
{
public:

public:
    static void OnLocalPlayersTeam(AActor*& TargetActor, UObject*& __WorldContext, bool& Return_Value); // 0x288a61c (Index: 0x0, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
};

static_assert(sizeof(USSI_BpLib_BpTools_C) == 0x28, "Size mismatch for USSI_BpLib_BpTools_C");

// Size: 0x398 (Inherited: 0x958, Single: 0xfffffa40)
class AB_CameraLens_Shadow_Bomb_End_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x390 (Size: 0x8, Type: StructProperty)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AB_CameraLens_Shadow_Bomb_End_C) == 0x398, "Size mismatch for AB_CameraLens_Shadow_Bomb_End_C");
static_assert(offsetof(AB_CameraLens_Shadow_Bomb_End_C, UberGraphFrame) == 0x390, "Offset mismatch for AB_CameraLens_Shadow_Bomb_End_C::UberGraphFrame");

// Size: 0x398 (Inherited: 0x958, Single: 0xfffffa40)
class AB_CameraLens_SwimBoost_C : public AEmitterCameraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x390 (Size: 0x8, Type: StructProperty)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AB_CameraLens_SwimBoost_C) == 0x398, "Size mismatch for AB_CameraLens_SwimBoost_C");
static_assert(offsetof(AB_CameraLens_SwimBoost_C, UberGraphFrame) == 0x390, "Offset mismatch for AB_CameraLens_SwimBoost_C::UberGraphFrame");

// Size: 0x1f0 (Inherited: 0x2f8, Single: 0xfffffef8)
class UB_Medium_Explosion_CameraShake_C : public ULegacyCameraShake
{
public:
};

static_assert(sizeof(UB_Medium_Explosion_CameraShake_C) == 0x1f0, "Size mismatch for UB_Medium_Explosion_CameraShake_C");

// Size: 0x1f0 (Inherited: 0x2f8, Single: 0xfffffef8)
class UBP_CameraShake_Lava_Bounce_C : public ULegacyCameraShake
{
public:
};

static_assert(sizeof(UBP_CameraShake_Lava_Bounce_C) == 0x1f0, "Size mismatch for UBP_CameraShake_Lava_Bounce_C");

// Size: 0x1f0 (Inherited: 0x2f8, Single: 0xfffffef8)
class UBP_Camera_Shake_Pulse_Flash_C : public ULegacyCameraShake
{
public:
};

static_assert(sizeof(UBP_Camera_Shake_Pulse_Flash_C) == 0x1f0, "Size mismatch for UBP_Camera_Shake_Pulse_Flash_C");

// Size: 0x5fc (Inherited: 0x1024, Single: 0xfffff5d8)
class AB_Pickups_Default_C : public AB_Pickups_Parent_C
{
public:
    uint8_t Pad_5bc[0x4]; // 0x5bc (Size: 0x4, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0x5c0 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* BG_Dark; // 0x5c8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* BG; // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* rarePickupFXMesh; // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* SpotLightComp; // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* rareAmbientEmitter; // 0x5e8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Pickup_Sound; // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    float Spotlight_Inverse_Exposure_Blend; // 0x5f8 (Size: 0x4, Type: FloatProperty)

public:
    void Setup_View_Distances(int32_t& viewDistanceQuality); // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void Set_Initial_BKGD_Param(UMaterialInstanceDynamic*& Mid); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnTossed(); // 0x288a61c (Index: 0x9, Flags: Event|Public|BlueprintEvent)
    virtual void OnPickedUp(AFortPawn*& PickupTarget); // 0x288a61c (Index: 0xa, Flags: Event|Public|BlueprintEvent)
    void initializeSpotlightComponent(); // 0x288a61c (Index: 0xb, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void AddRareFX(); // 0x288a61c (Index: 0xf, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AB_Pickups_Default_C) == 0x5fc, "Size mismatch for AB_Pickups_Default_C");
static_assert(offsetof(AB_Pickups_Default_C, UberGraphFrame) == 0x5c0, "Offset mismatch for AB_Pickups_Default_C::UberGraphFrame");
static_assert(offsetof(AB_Pickups_Default_C, BG_Dark) == 0x5c8, "Offset mismatch for AB_Pickups_Default_C::BG_Dark");
static_assert(offsetof(AB_Pickups_Default_C, BG) == 0x5d0, "Offset mismatch for AB_Pickups_Default_C::BG");
static_assert(offsetof(AB_Pickups_Default_C, rarePickupFXMesh) == 0x5d8, "Offset mismatch for AB_Pickups_Default_C::rarePickupFXMesh");
static_assert(offsetof(AB_Pickups_Default_C, SpotLightComp) == 0x5e0, "Offset mismatch for AB_Pickups_Default_C::SpotLightComp");
static_assert(offsetof(AB_Pickups_Default_C, rareAmbientEmitter) == 0x5e8, "Offset mismatch for AB_Pickups_Default_C::rareAmbientEmitter");
static_assert(offsetof(AB_Pickups_Default_C, Pickup_Sound) == 0x5f0, "Offset mismatch for AB_Pickups_Default_C::Pickup_Sound");
static_assert(offsetof(AB_Pickups_Default_C, Spotlight_Inverse_Exposure_Blend) == 0x5f8, "Offset mismatch for AB_Pickups_Default_C::Spotlight_Inverse_Exposure_Blend");

// Size: 0x5bc (Inherited: 0xa68, Single: 0xfffffb54)
class AB_Pickups_Parent_C : public AFortPickupsParent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x478 (Size: 0x8, Type: StructProperty)
    USceneComponent* Root; // 0x480 (Size: 0x8, Type: ObjectProperty)
    float MobileSelectedTL_LerpInteactoIcon_FF208F9641BE589B76EF698B94309EA7; // 0x488 (Size: 0x4, Type: FloatProperty)
    float MobileSelectedTL_LerpObject_FF208F9641BE589B76EF698B94309EA7; // 0x48c (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> MobileSelectedTL__Direction_FF208F9641BE589B76EF698B94309EA7; // 0x490 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_491[0x7]; // 0x491 (Size: 0x7, Type: PaddingProperty)
    UTimelineComponent* MobileSelectedTL; // 0x498 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Static_Mesh_Pickup; // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* Skeletal_Mesh_Pickup; // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* SkeletalOrStaticMeshAssetPrimitive; // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    int32_t CurrentElementIndex; // 0x4b8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4bc[0x4]; // 0x4bc (Size: 0x4, Type: PaddingProperty)
    double Component_Radius__Scaled_; // 0x4c0 (Size: 0x8, Type: DoubleProperty)
    double Component_Radius_Multiplier; // 0x4c8 (Size: 0x8, Type: DoubleProperty)
    TArray<FLinearColor> Outline_Rarity_Colors; // 0x4d0 (Size: 0x10, Type: ArrayProperty)
    double Component_Radius; // 0x4e0 (Size: 0x8, Type: DoubleProperty)
    UParticleSystem* Picked_Up_Trail_PS_Old; // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    TArray<double> Sparkle_Spawn_Rate__Picked_Up_; // 0x4f0 (Size: 0x10, Type: ArrayProperty)
    TArray<double> Lifetime__Picked_Up_; // 0x500 (Size: 0x10, Type: ArrayProperty)
    UForceFeedbackEffect* PickupForceFeedback_Old; // 0x510 (Size: 0x8, Type: ObjectProperty)
    bool HasUniqueMaterialIds; // 0x518 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_519[0x7]; // 0x519 (Size: 0x7, Type: PaddingProperty)
    TArray<FLinearColor> BackgroundRarityColors; // 0x520 (Size: 0x10, Type: ArrayProperty)
    double Random_Rotation; // 0x530 (Size: 0x8, Type: DoubleProperty)
    FVector MobileSelectedOffset; // 0x538 (Size: 0x18, Type: StructProperty)
    FVector MobileSelectedScale; // 0x550 (Size: 0x18, Type: StructProperty)
    UStaticMeshComponent* MobileInteractIcon; // 0x568 (Size: 0x8, Type: ObjectProperty)
    FVector MobileInteractIconLocation; // 0x570 (Size: 0x18, Type: StructProperty)
    FVector MobileInteractIconScale; // 0x588 (Size: 0x18, Type: StructProperty)
    UMaterialInterface* MobileInteractionMaterial; // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    bool PickedUp; // 0x5a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5a9[0x3]; // 0x5a9 (Size: 0x3, Type: PaddingProperty)
    FLinearColor MissionItemOutlineColor; // 0x5ac (Size: 0x10, Type: StructProperty)

public:
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    void SetVisibleMobileInteractIcon(bool& Visible); // 0x288a61c (Index: 0x1, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void OnPickedUp(AFortPawn*& PickupTarget); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void OnTossed(); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    void ScaleHologramTimingsForPvP(); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetActiveBackgroundParticleSystem(bool& Active, bool& Reset); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetHiddenBackgroundVisualComponents(bool& Hidden); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetHologramPickedUpParams(bool& Tier_0); // 0x288a61c (Index: 0x8, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Setup_View_Distances(int32_t& viewDistanceQuality); // 0x288a61c (Index: 0x9, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SpawnPickedUpTrailPS(); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    void DestroyBackgroundVisualComponents(); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnAttached(); // 0x288a61c (Index: 0xc, Flags: Event|Public|BlueprintEvent)
    void Mobile_Interation_Icon_Setup(); // 0x288a61c (Index: 0xf, Flags: Public|BlueprintCallable|BlueprintEvent)
    int32_t GetViewDistanceQuality(); // 0x288a61c (Index: 0x11, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void EnableBacchusHighlight(); // 0x288a61c (Index: 0x13, Flags: Event|Public|BlueprintEvent)
    virtual void DisableBacchusHighlight(); // 0x288a61c (Index: 0x14, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AB_Pickups_Parent_C) == 0x5bc, "Size mismatch for AB_Pickups_Parent_C");
static_assert(offsetof(AB_Pickups_Parent_C, UberGraphFrame) == 0x478, "Offset mismatch for AB_Pickups_Parent_C::UberGraphFrame");
static_assert(offsetof(AB_Pickups_Parent_C, Root) == 0x480, "Offset mismatch for AB_Pickups_Parent_C::Root");
static_assert(offsetof(AB_Pickups_Parent_C, MobileSelectedTL_LerpInteactoIcon_FF208F9641BE589B76EF698B94309EA7) == 0x488, "Offset mismatch for AB_Pickups_Parent_C::MobileSelectedTL_LerpInteactoIcon_FF208F9641BE589B76EF698B94309EA7");
static_assert(offsetof(AB_Pickups_Parent_C, MobileSelectedTL_LerpObject_FF208F9641BE589B76EF698B94309EA7) == 0x48c, "Offset mismatch for AB_Pickups_Parent_C::MobileSelectedTL_LerpObject_FF208F9641BE589B76EF698B94309EA7");
static_assert(offsetof(AB_Pickups_Parent_C, MobileSelectedTL__Direction_FF208F9641BE589B76EF698B94309EA7) == 0x490, "Offset mismatch for AB_Pickups_Parent_C::MobileSelectedTL__Direction_FF208F9641BE589B76EF698B94309EA7");
static_assert(offsetof(AB_Pickups_Parent_C, MobileSelectedTL) == 0x498, "Offset mismatch for AB_Pickups_Parent_C::MobileSelectedTL");
static_assert(offsetof(AB_Pickups_Parent_C, Static_Mesh_Pickup) == 0x4a0, "Offset mismatch for AB_Pickups_Parent_C::Static_Mesh_Pickup");
static_assert(offsetof(AB_Pickups_Parent_C, Skeletal_Mesh_Pickup) == 0x4a8, "Offset mismatch for AB_Pickups_Parent_C::Skeletal_Mesh_Pickup");
static_assert(offsetof(AB_Pickups_Parent_C, SkeletalOrStaticMeshAssetPrimitive) == 0x4b0, "Offset mismatch for AB_Pickups_Parent_C::SkeletalOrStaticMeshAssetPrimitive");
static_assert(offsetof(AB_Pickups_Parent_C, CurrentElementIndex) == 0x4b8, "Offset mismatch for AB_Pickups_Parent_C::CurrentElementIndex");
static_assert(offsetof(AB_Pickups_Parent_C, Component_Radius__Scaled_) == 0x4c0, "Offset mismatch for AB_Pickups_Parent_C::Component_Radius__Scaled_");
static_assert(offsetof(AB_Pickups_Parent_C, Component_Radius_Multiplier) == 0x4c8, "Offset mismatch for AB_Pickups_Parent_C::Component_Radius_Multiplier");
static_assert(offsetof(AB_Pickups_Parent_C, Outline_Rarity_Colors) == 0x4d0, "Offset mismatch for AB_Pickups_Parent_C::Outline_Rarity_Colors");
static_assert(offsetof(AB_Pickups_Parent_C, Component_Radius) == 0x4e0, "Offset mismatch for AB_Pickups_Parent_C::Component_Radius");
static_assert(offsetof(AB_Pickups_Parent_C, Picked_Up_Trail_PS_Old) == 0x4e8, "Offset mismatch for AB_Pickups_Parent_C::Picked_Up_Trail_PS_Old");
static_assert(offsetof(AB_Pickups_Parent_C, Sparkle_Spawn_Rate__Picked_Up_) == 0x4f0, "Offset mismatch for AB_Pickups_Parent_C::Sparkle_Spawn_Rate__Picked_Up_");
static_assert(offsetof(AB_Pickups_Parent_C, Lifetime__Picked_Up_) == 0x500, "Offset mismatch for AB_Pickups_Parent_C::Lifetime__Picked_Up_");
static_assert(offsetof(AB_Pickups_Parent_C, PickupForceFeedback_Old) == 0x510, "Offset mismatch for AB_Pickups_Parent_C::PickupForceFeedback_Old");
static_assert(offsetof(AB_Pickups_Parent_C, HasUniqueMaterialIds) == 0x518, "Offset mismatch for AB_Pickups_Parent_C::HasUniqueMaterialIds");
static_assert(offsetof(AB_Pickups_Parent_C, BackgroundRarityColors) == 0x520, "Offset mismatch for AB_Pickups_Parent_C::BackgroundRarityColors");
static_assert(offsetof(AB_Pickups_Parent_C, Random_Rotation) == 0x530, "Offset mismatch for AB_Pickups_Parent_C::Random_Rotation");
static_assert(offsetof(AB_Pickups_Parent_C, MobileSelectedOffset) == 0x538, "Offset mismatch for AB_Pickups_Parent_C::MobileSelectedOffset");
static_assert(offsetof(AB_Pickups_Parent_C, MobileSelectedScale) == 0x550, "Offset mismatch for AB_Pickups_Parent_C::MobileSelectedScale");
static_assert(offsetof(AB_Pickups_Parent_C, MobileInteractIcon) == 0x568, "Offset mismatch for AB_Pickups_Parent_C::MobileInteractIcon");
static_assert(offsetof(AB_Pickups_Parent_C, MobileInteractIconLocation) == 0x570, "Offset mismatch for AB_Pickups_Parent_C::MobileInteractIconLocation");
static_assert(offsetof(AB_Pickups_Parent_C, MobileInteractIconScale) == 0x588, "Offset mismatch for AB_Pickups_Parent_C::MobileInteractIconScale");
static_assert(offsetof(AB_Pickups_Parent_C, MobileInteractionMaterial) == 0x5a0, "Offset mismatch for AB_Pickups_Parent_C::MobileInteractionMaterial");
static_assert(offsetof(AB_Pickups_Parent_C, PickedUp) == 0x5a8, "Offset mismatch for AB_Pickups_Parent_C::PickedUp");
static_assert(offsetof(AB_Pickups_Parent_C, MissionItemOutlineColor) == 0x5ac, "Offset mismatch for AB_Pickups_Parent_C::MissionItemOutlineColor");

// Size: 0x390 (Inherited: 0x958, Single: 0xfffffa38)
class ABP_CameraLens_HidingProp_Teleporting_Looping_WilliePete_C : public AEmitterCameraLensEffectBase
{
public:
};

static_assert(sizeof(ABP_CameraLens_HidingProp_Teleporting_Looping_WilliePete_C) == 0x390, "Size mismatch for ABP_CameraLens_HidingProp_Teleporting_Looping_WilliePete_C");

// Size: 0x390 (Inherited: 0x958, Single: 0xfffffa38)
class ABP_CameraLens_HidingProp_Teleporting_Looping_C : public AEmitterCameraLensEffectBase
{
public:
};

static_assert(sizeof(ABP_CameraLens_HidingProp_Teleporting_Looping_C) == 0x390, "Size mismatch for ABP_CameraLens_HidingProp_Teleporting_Looping_C");

// Size: 0x434 (Inherited: 0x2d0, Single: 0x164)
class ADuplicateResOutMesh_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    float CharacterSpawnInTimeline_FirstPassComplete_2AB89084476E64255664E9B2D45E14C1; // 0x2b8 (Size: 0x4, Type: FloatProperty)
    float CharacterSpawnInTimeline_LightIntensity_2AB89084476E64255664E9B2D45E14C1; // 0x2bc (Size: 0x4, Type: FloatProperty)
    float CharacterSpawnInTimeline_zHieght_2AB89084476E64255664E9B2D45E14C1; // 0x2c0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> CharacterSpawnInTimeline__Direction_2AB89084476E64255664E9B2D45E14C1; // 0x2c4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_2c5[0x3]; // 0x2c5 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* CharacterSpawnInTimeline; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* Skeletal_Mesh_Duplicate; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    bool Gun_True; // 0x2d8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d9[0x7]; // 0x2d9 (Size: 0x7, Type: PaddingProperty)
    double BoundsRadius; // 0x2e0 (Size: 0x8, Type: DoubleProperty)
    TArray<UMaterialInstanceDynamic*> MIDArray; // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    FVector World_location_for_the_dissolve_location; // 0x2f8 (Size: 0x18, Type: StructProperty)
    UMaterialInstanceDynamic* Current_MID; // 0x310 (Size: 0x8, Type: ObjectProperty)
    double Head_Space; // 0x318 (Size: 0x8, Type: DoubleProperty)
    double Leg_Space; // 0x320 (Size: 0x8, Type: DoubleProperty)
    UPointLightComponent* Spawn_Light; // 0x328 (Size: 0x8, Type: ObjectProperty)
    double light_intensity; // 0x330 (Size: 0x8, Type: DoubleProperty)
    int32_t Number_of_Base_skeletal_mesh_materials; // 0x338 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_33c[0x4]; // 0x33c (Size: 0x4, Type: PaddingProperty)
    double FirstPassComplete; // 0x340 (Size: 0x8, Type: DoubleProperty)
    TArray<USkeletalMeshComponent*> ExternalSkeletalMeshComponent; // 0x348 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_358[0x8]; // 0x358 (Size: 0x8, Type: PaddingProperty)
    FTransform Box_Local_Transform; // 0x360 (Size: 0x60, Type: StructProperty)
    double Timeline_Play_Length; // 0x3c0 (Size: 0x8, Type: DoubleProperty)
    bool TeleportOut_; // 0x3c8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3c9[0x7]; // 0x3c9 (Size: 0x7, Type: PaddingProperty)
    AActor* ExternalActor; // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    TArray<USkeletalMeshComponent*> InternalSkeletalMeshComponents; // 0x3d8 (Size: 0x10, Type: ArrayProperty)
    int32_t CurrentMeshMidIndex; // 0x3e8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_3ec[0x4]; // 0x3ec (Size: 0x4, Type: PaddingProperty)
    USkeletalMeshComponent* External_Base_Mesh_Component; // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInstanceDynamic*> ExternalMidArray; // 0x3f8 (Size: 0x10, Type: ArrayProperty)
    USkeletalMeshComponent* ExternalRootMeshComponent; // 0x408 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInterface*> ListOfMaterialsExemptFromReparenting; // 0x410 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> Original_MIDs; // 0x420 (Size: 0x10, Type: ArrayProperty)
    int32_t Increment_End; // 0x430 (Size: 0x4, Type: IntProperty)

public:
    void Spawn__Light(); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void External_Mesh_Masked_Setup(TArray<USkeletalMeshComponent*> External_MEsh_Component_Array, TArray<UMaterialInstanceDynamic*>& Corrected_Mid_Array); // 0x288a61c (Index: 0x5, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Find_Bounds(); // 0x288a61c (Index: 0x6, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void initializeExternalSkeletalMeshArray(); // 0x288a61c (Index: 0x7, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Make_and_slave_internal_meshes(); // 0x288a61c (Index: 0x8, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void ProcessSpawnInTimeline(double& ZHeight, double& LightIntensity); // 0x288a61c (Index: 0x9, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Store_Original_Material_for_Teleport_In(); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0xb, Flags: Event|Public|BlueprintEvent)
    void RestoreInProgressRes(); // 0x288a61c (Index: 0xd, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Make_internal_mids_and_append_external_and_intermal_mids_to_mid_array(); // 0x288a61c (Index: 0xe, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ADuplicateResOutMesh_C) == 0x434, "Size mismatch for ADuplicateResOutMesh_C");
static_assert(offsetof(ADuplicateResOutMesh_C, UberGraphFrame) == 0x2a8, "Offset mismatch for ADuplicateResOutMesh_C::UberGraphFrame");
static_assert(offsetof(ADuplicateResOutMesh_C, DefaultSceneRoot) == 0x2b0, "Offset mismatch for ADuplicateResOutMesh_C::DefaultSceneRoot");
static_assert(offsetof(ADuplicateResOutMesh_C, CharacterSpawnInTimeline_FirstPassComplete_2AB89084476E64255664E9B2D45E14C1) == 0x2b8, "Offset mismatch for ADuplicateResOutMesh_C::CharacterSpawnInTimeline_FirstPassComplete_2AB89084476E64255664E9B2D45E14C1");
static_assert(offsetof(ADuplicateResOutMesh_C, CharacterSpawnInTimeline_LightIntensity_2AB89084476E64255664E9B2D45E14C1) == 0x2bc, "Offset mismatch for ADuplicateResOutMesh_C::CharacterSpawnInTimeline_LightIntensity_2AB89084476E64255664E9B2D45E14C1");
static_assert(offsetof(ADuplicateResOutMesh_C, CharacterSpawnInTimeline_zHieght_2AB89084476E64255664E9B2D45E14C1) == 0x2c0, "Offset mismatch for ADuplicateResOutMesh_C::CharacterSpawnInTimeline_zHieght_2AB89084476E64255664E9B2D45E14C1");
static_assert(offsetof(ADuplicateResOutMesh_C, CharacterSpawnInTimeline__Direction_2AB89084476E64255664E9B2D45E14C1) == 0x2c4, "Offset mismatch for ADuplicateResOutMesh_C::CharacterSpawnInTimeline__Direction_2AB89084476E64255664E9B2D45E14C1");
static_assert(offsetof(ADuplicateResOutMesh_C, CharacterSpawnInTimeline) == 0x2c8, "Offset mismatch for ADuplicateResOutMesh_C::CharacterSpawnInTimeline");
static_assert(offsetof(ADuplicateResOutMesh_C, Skeletal_Mesh_Duplicate) == 0x2d0, "Offset mismatch for ADuplicateResOutMesh_C::Skeletal_Mesh_Duplicate");
static_assert(offsetof(ADuplicateResOutMesh_C, Gun_True) == 0x2d8, "Offset mismatch for ADuplicateResOutMesh_C::Gun_True");
static_assert(offsetof(ADuplicateResOutMesh_C, BoundsRadius) == 0x2e0, "Offset mismatch for ADuplicateResOutMesh_C::BoundsRadius");
static_assert(offsetof(ADuplicateResOutMesh_C, MIDArray) == 0x2e8, "Offset mismatch for ADuplicateResOutMesh_C::MIDArray");
static_assert(offsetof(ADuplicateResOutMesh_C, World_location_for_the_dissolve_location) == 0x2f8, "Offset mismatch for ADuplicateResOutMesh_C::World_location_for_the_dissolve_location");
static_assert(offsetof(ADuplicateResOutMesh_C, Current_MID) == 0x310, "Offset mismatch for ADuplicateResOutMesh_C::Current_MID");
static_assert(offsetof(ADuplicateResOutMesh_C, Head_Space) == 0x318, "Offset mismatch for ADuplicateResOutMesh_C::Head_Space");
static_assert(offsetof(ADuplicateResOutMesh_C, Leg_Space) == 0x320, "Offset mismatch for ADuplicateResOutMesh_C::Leg_Space");
static_assert(offsetof(ADuplicateResOutMesh_C, Spawn_Light) == 0x328, "Offset mismatch for ADuplicateResOutMesh_C::Spawn_Light");
static_assert(offsetof(ADuplicateResOutMesh_C, light_intensity) == 0x330, "Offset mismatch for ADuplicateResOutMesh_C::light_intensity");
static_assert(offsetof(ADuplicateResOutMesh_C, Number_of_Base_skeletal_mesh_materials) == 0x338, "Offset mismatch for ADuplicateResOutMesh_C::Number_of_Base_skeletal_mesh_materials");
static_assert(offsetof(ADuplicateResOutMesh_C, FirstPassComplete) == 0x340, "Offset mismatch for ADuplicateResOutMesh_C::FirstPassComplete");
static_assert(offsetof(ADuplicateResOutMesh_C, ExternalSkeletalMeshComponent) == 0x348, "Offset mismatch for ADuplicateResOutMesh_C::ExternalSkeletalMeshComponent");
static_assert(offsetof(ADuplicateResOutMesh_C, Box_Local_Transform) == 0x360, "Offset mismatch for ADuplicateResOutMesh_C::Box_Local_Transform");
static_assert(offsetof(ADuplicateResOutMesh_C, Timeline_Play_Length) == 0x3c0, "Offset mismatch for ADuplicateResOutMesh_C::Timeline_Play_Length");
static_assert(offsetof(ADuplicateResOutMesh_C, TeleportOut_) == 0x3c8, "Offset mismatch for ADuplicateResOutMesh_C::TeleportOut_");
static_assert(offsetof(ADuplicateResOutMesh_C, ExternalActor) == 0x3d0, "Offset mismatch for ADuplicateResOutMesh_C::ExternalActor");
static_assert(offsetof(ADuplicateResOutMesh_C, InternalSkeletalMeshComponents) == 0x3d8, "Offset mismatch for ADuplicateResOutMesh_C::InternalSkeletalMeshComponents");
static_assert(offsetof(ADuplicateResOutMesh_C, CurrentMeshMidIndex) == 0x3e8, "Offset mismatch for ADuplicateResOutMesh_C::CurrentMeshMidIndex");
static_assert(offsetof(ADuplicateResOutMesh_C, External_Base_Mesh_Component) == 0x3f0, "Offset mismatch for ADuplicateResOutMesh_C::External_Base_Mesh_Component");
static_assert(offsetof(ADuplicateResOutMesh_C, ExternalMidArray) == 0x3f8, "Offset mismatch for ADuplicateResOutMesh_C::ExternalMidArray");
static_assert(offsetof(ADuplicateResOutMesh_C, ExternalRootMeshComponent) == 0x408, "Offset mismatch for ADuplicateResOutMesh_C::ExternalRootMeshComponent");
static_assert(offsetof(ADuplicateResOutMesh_C, ListOfMaterialsExemptFromReparenting) == 0x410, "Offset mismatch for ADuplicateResOutMesh_C::ListOfMaterialsExemptFromReparenting");
static_assert(offsetof(ADuplicateResOutMesh_C, Original_MIDs) == 0x420, "Offset mismatch for ADuplicateResOutMesh_C::Original_MIDs");
static_assert(offsetof(ADuplicateResOutMesh_C, Increment_End) == 0x430, "Offset mismatch for ADuplicateResOutMesh_C::Increment_End");

// Size: 0x3f8 (Inherited: 0x8a0, Single: 0xfffffb58)
class AWeakSpot_C : public ABuildingWeakSpot
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x320 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* ConnectTheDotsComponent; // 0x328 (Size: 0x8, Type: ObjectProperty)
    UCapsuleComponent* CollisionComponent; // 0x330 (Size: 0x8, Type: ObjectProperty)
    float ScaleDownParticleTL_ScaleDown_544AE05F40294D09C3C361AB7BCF6C4E; // 0x338 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> ScaleDownParticleTL__Direction_544AE05F40294D09C3C361AB7BCF6C4E; // 0x33c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_33d[0x3]; // 0x33d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* ScaleDownParticleTL; // 0x340 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SpawnSound; // 0x348 (Size: 0x8, Type: ObjectProperty)
    FVector Particle_Location; // 0x350 (Size: 0x18, Type: StructProperty)
    TArray<USoundBase*> Crack_sounds; // 0x368 (Size: 0x10, Type: ArrayProperty)
    double ConnectTheDotsWidth; // 0x378 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsDuration; // 0x380 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsTimeoutFromPreviousHit; // 0x388 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsDurationScale; // 0x390 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsMaxDuration; // 0x398 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsTileScale; // 0x3a0 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsMinLength; // 0x3a8 (Size: 0x8, Type: DoubleProperty)
    double ConnectTheDotsMaxLength; // 0x3b0 (Size: 0x8, Type: DoubleProperty)
    UParticleSystem* DamageTemplateCascade; // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* IdleTemplateCascade; // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* ConnectMID; // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle HideMeshTimer; // 0x3d0 (Size: 0x8, Type: StructProperty)
    UFXSystemComponent* FXComponent; // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* IdleTemplateNiagara; // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* DamageTemplateNiagara; // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    double FXSpriteScale; // 0x3f0 (Size: 0x8, Type: DoubleProperty)

public:
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    void SetSpriteScale(double& SpriteScale); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFXTemplate(UNiagaraSystem*& Niagara, UParticleSystem*& Cascade); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnStartDirectionEffect(); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
    virtual void OnHit(); // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintEvent)
    virtual void OnFadeOut(); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(AWeakSpot_C) == 0x3f8, "Size mismatch for AWeakSpot_C");
static_assert(offsetof(AWeakSpot_C, UberGraphFrame) == 0x320, "Offset mismatch for AWeakSpot_C::UberGraphFrame");
static_assert(offsetof(AWeakSpot_C, ConnectTheDotsComponent) == 0x328, "Offset mismatch for AWeakSpot_C::ConnectTheDotsComponent");
static_assert(offsetof(AWeakSpot_C, CollisionComponent) == 0x330, "Offset mismatch for AWeakSpot_C::CollisionComponent");
static_assert(offsetof(AWeakSpot_C, ScaleDownParticleTL_ScaleDown_544AE05F40294D09C3C361AB7BCF6C4E) == 0x338, "Offset mismatch for AWeakSpot_C::ScaleDownParticleTL_ScaleDown_544AE05F40294D09C3C361AB7BCF6C4E");
static_assert(offsetof(AWeakSpot_C, ScaleDownParticleTL__Direction_544AE05F40294D09C3C361AB7BCF6C4E) == 0x33c, "Offset mismatch for AWeakSpot_C::ScaleDownParticleTL__Direction_544AE05F40294D09C3C361AB7BCF6C4E");
static_assert(offsetof(AWeakSpot_C, ScaleDownParticleTL) == 0x340, "Offset mismatch for AWeakSpot_C::ScaleDownParticleTL");
static_assert(offsetof(AWeakSpot_C, SpawnSound) == 0x348, "Offset mismatch for AWeakSpot_C::SpawnSound");
static_assert(offsetof(AWeakSpot_C, Particle_Location) == 0x350, "Offset mismatch for AWeakSpot_C::Particle_Location");
static_assert(offsetof(AWeakSpot_C, Crack_sounds) == 0x368, "Offset mismatch for AWeakSpot_C::Crack_sounds");
static_assert(offsetof(AWeakSpot_C, ConnectTheDotsWidth) == 0x378, "Offset mismatch for AWeakSpot_C::ConnectTheDotsWidth");
static_assert(offsetof(AWeakSpot_C, ConnectTheDotsDuration) == 0x380, "Offset mismatch for AWeakSpot_C::ConnectTheDotsDuration");
static_assert(offsetof(AWeakSpot_C, ConnectTheDotsTimeoutFromPreviousHit) == 0x388, "Offset mismatch for AWeakSpot_C::ConnectTheDotsTimeoutFromPreviousHit");
static_assert(offsetof(AWeakSpot_C, ConnectTheDotsDurationScale) == 0x390, "Offset mismatch for AWeakSpot_C::ConnectTheDotsDurationScale");
static_assert(offsetof(AWeakSpot_C, ConnectTheDotsMaxDuration) == 0x398, "Offset mismatch for AWeakSpot_C::ConnectTheDotsMaxDuration");
static_assert(offsetof(AWeakSpot_C, ConnectTheDotsTileScale) == 0x3a0, "Offset mismatch for AWeakSpot_C::ConnectTheDotsTileScale");
static_assert(offsetof(AWeakSpot_C, ConnectTheDotsMinLength) == 0x3a8, "Offset mismatch for AWeakSpot_C::ConnectTheDotsMinLength");
static_assert(offsetof(AWeakSpot_C, ConnectTheDotsMaxLength) == 0x3b0, "Offset mismatch for AWeakSpot_C::ConnectTheDotsMaxLength");
static_assert(offsetof(AWeakSpot_C, DamageTemplateCascade) == 0x3b8, "Offset mismatch for AWeakSpot_C::DamageTemplateCascade");
static_assert(offsetof(AWeakSpot_C, IdleTemplateCascade) == 0x3c0, "Offset mismatch for AWeakSpot_C::IdleTemplateCascade");
static_assert(offsetof(AWeakSpot_C, ConnectMID) == 0x3c8, "Offset mismatch for AWeakSpot_C::ConnectMID");
static_assert(offsetof(AWeakSpot_C, HideMeshTimer) == 0x3d0, "Offset mismatch for AWeakSpot_C::HideMeshTimer");
static_assert(offsetof(AWeakSpot_C, FXComponent) == 0x3d8, "Offset mismatch for AWeakSpot_C::FXComponent");
static_assert(offsetof(AWeakSpot_C, IdleTemplateNiagara) == 0x3e0, "Offset mismatch for AWeakSpot_C::IdleTemplateNiagara");
static_assert(offsetof(AWeakSpot_C, DamageTemplateNiagara) == 0x3e8, "Offset mismatch for AWeakSpot_C::DamageTemplateNiagara");
static_assert(offsetof(AWeakSpot_C, FXSpriteScale) == 0x3f0, "Offset mismatch for AWeakSpot_C::FXSpriteScale");

// Size: 0x3d0 (Inherited: 0xd28, Single: 0xfffff6a8)
class AB_PlayerShieldDamage_LensEffect_Direction_C : public AFortEmitterCameraLensEffectDirectional
{
public:
};

static_assert(sizeof(AB_PlayerShieldDamage_LensEffect_Direction_C) == 0x3d0, "Size mismatch for AB_PlayerShieldDamage_LensEffect_Direction_C");

// Size: 0x3d0 (Inherited: 0xd28, Single: 0xfffff6a8)
class AB_PlayerHealthDamage_LensEffect_Direction_C : public AFortEmitterCameraLensEffectDirectional
{
public:
};

static_assert(sizeof(AB_PlayerHealthDamage_LensEffect_Direction_C) == 0x3d0, "Size mismatch for AB_PlayerHealthDamage_LensEffect_Direction_C");

// Size: 0x848 (Inherited: 0x11b8, Single: 0xfffff690)
class AB_SoundIndicator_01_C : public AFortSoundCameraLensEffect
{
public:
    FRuntimeFloatCurve Gunshot_Falloff_Long_Range; // 0x490 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve Chest_Falloff; // 0x518 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve Footsteps_Falloff; // 0x5a0 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve Gunshot_Falloff_Mid_Range; // 0x628 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve Gunshot_Falloff_Melee; // 0x6b0 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve Glider_Falloff; // 0x738 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve Plane_Falloff; // 0x7c0 (Size: 0x88, Type: StructProperty)

public:
    FRuntimeFloatCurve GetWeaponCurve() const; // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual FRuntimeFloatCurve GetStrengthCurveForActiveType() const; // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual FLinearColor GetDefaultTint(); // 0x288a61c (Index: 0x2, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual UTexture* GetDefaultIcon(); // 0x288a61c (Index: 0x3, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(AB_SoundIndicator_01_C) == 0x848, "Size mismatch for AB_SoundIndicator_01_C");
static_assert(offsetof(AB_SoundIndicator_01_C, Gunshot_Falloff_Long_Range) == 0x490, "Offset mismatch for AB_SoundIndicator_01_C::Gunshot_Falloff_Long_Range");
static_assert(offsetof(AB_SoundIndicator_01_C, Chest_Falloff) == 0x518, "Offset mismatch for AB_SoundIndicator_01_C::Chest_Falloff");
static_assert(offsetof(AB_SoundIndicator_01_C, Footsteps_Falloff) == 0x5a0, "Offset mismatch for AB_SoundIndicator_01_C::Footsteps_Falloff");
static_assert(offsetof(AB_SoundIndicator_01_C, Gunshot_Falloff_Mid_Range) == 0x628, "Offset mismatch for AB_SoundIndicator_01_C::Gunshot_Falloff_Mid_Range");
static_assert(offsetof(AB_SoundIndicator_01_C, Gunshot_Falloff_Melee) == 0x6b0, "Offset mismatch for AB_SoundIndicator_01_C::Gunshot_Falloff_Melee");
static_assert(offsetof(AB_SoundIndicator_01_C, Glider_Falloff) == 0x738, "Offset mismatch for AB_SoundIndicator_01_C::Glider_Falloff");
static_assert(offsetof(AB_SoundIndicator_01_C, Plane_Falloff) == 0x7c0, "Offset mismatch for AB_SoundIndicator_01_C::Plane_Falloff");

// Size: 0x364 (Inherited: 0x580, Single: 0xfffffde4)
class AFN_RadialForce_C : public AFieldSystemActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2b0 (Size: 0x8, Type: StructProperty)
    UOperatorField* DistanceFadMult; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    URadialFalloff* DistanceFalloff; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UWaveScalar* DecayScalar; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UOperatorField* DecayMult; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UWaveScalar* RadialFalloffWave; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UOperatorField* RadialVecMultiplyRadialFallOff; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    URadialVector* RadialVector; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    double Wave_Period; // 0x2f0 (Size: 0x8, Type: DoubleProperty)
    double Force_Duration; // 0x2f8 (Size: 0x8, Type: DoubleProperty)
    double Radius; // 0x300 (Size: 0x8, Type: DoubleProperty)
    double Magnitude; // 0x308 (Size: 0x8, Type: DoubleProperty)
    double PlayRate; // 0x310 (Size: 0x8, Type: DoubleProperty)
    double Scale; // 0x318 (Size: 0x8, Type: DoubleProperty)
    double Impact_Time; // 0x320 (Size: 0x8, Type: DoubleProperty)
    double Period; // 0x328 (Size: 0x8, Type: DoubleProperty)
    double WaveLength; // 0x330 (Size: 0x8, Type: DoubleProperty)
    double Time_Decay; // 0x338 (Size: 0x8, Type: DoubleProperty)
    TEnumAsByte<EFieldFalloffType> Falloff_Type; // 0x340 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_341[0x7]; // 0x341 (Size: 0x7, Type: PaddingProperty)
    double Expansion; // 0x348 (Size: 0x8, Type: DoubleProperty)
    double Impact_Radius; // 0x350 (Size: 0x8, Type: DoubleProperty)
    double Strength; // 0x358 (Size: 0x8, Type: DoubleProperty)
    float DelayTime; // 0x360 (Size: 0x4, Type: FloatProperty)

public:
    FTransform NewFunction_0(double& Roll, double& Scale); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AFN_RadialForce_C) == 0x364, "Size mismatch for AFN_RadialForce_C");
static_assert(offsetof(AFN_RadialForce_C, UberGraphFrame) == 0x2b0, "Offset mismatch for AFN_RadialForce_C::UberGraphFrame");
static_assert(offsetof(AFN_RadialForce_C, DistanceFadMult) == 0x2b8, "Offset mismatch for AFN_RadialForce_C::DistanceFadMult");
static_assert(offsetof(AFN_RadialForce_C, DistanceFalloff) == 0x2c0, "Offset mismatch for AFN_RadialForce_C::DistanceFalloff");
static_assert(offsetof(AFN_RadialForce_C, DecayScalar) == 0x2c8, "Offset mismatch for AFN_RadialForce_C::DecayScalar");
static_assert(offsetof(AFN_RadialForce_C, DecayMult) == 0x2d0, "Offset mismatch for AFN_RadialForce_C::DecayMult");
static_assert(offsetof(AFN_RadialForce_C, RadialFalloffWave) == 0x2d8, "Offset mismatch for AFN_RadialForce_C::RadialFalloffWave");
static_assert(offsetof(AFN_RadialForce_C, RadialVecMultiplyRadialFallOff) == 0x2e0, "Offset mismatch for AFN_RadialForce_C::RadialVecMultiplyRadialFallOff");
static_assert(offsetof(AFN_RadialForce_C, RadialVector) == 0x2e8, "Offset mismatch for AFN_RadialForce_C::RadialVector");
static_assert(offsetof(AFN_RadialForce_C, Wave_Period) == 0x2f0, "Offset mismatch for AFN_RadialForce_C::Wave_Period");
static_assert(offsetof(AFN_RadialForce_C, Force_Duration) == 0x2f8, "Offset mismatch for AFN_RadialForce_C::Force_Duration");
static_assert(offsetof(AFN_RadialForce_C, Radius) == 0x300, "Offset mismatch for AFN_RadialForce_C::Radius");
static_assert(offsetof(AFN_RadialForce_C, Magnitude) == 0x308, "Offset mismatch for AFN_RadialForce_C::Magnitude");
static_assert(offsetof(AFN_RadialForce_C, PlayRate) == 0x310, "Offset mismatch for AFN_RadialForce_C::PlayRate");
static_assert(offsetof(AFN_RadialForce_C, Scale) == 0x318, "Offset mismatch for AFN_RadialForce_C::Scale");
static_assert(offsetof(AFN_RadialForce_C, Impact_Time) == 0x320, "Offset mismatch for AFN_RadialForce_C::Impact_Time");
static_assert(offsetof(AFN_RadialForce_C, Period) == 0x328, "Offset mismatch for AFN_RadialForce_C::Period");
static_assert(offsetof(AFN_RadialForce_C, WaveLength) == 0x330, "Offset mismatch for AFN_RadialForce_C::WaveLength");
static_assert(offsetof(AFN_RadialForce_C, Time_Decay) == 0x338, "Offset mismatch for AFN_RadialForce_C::Time_Decay");
static_assert(offsetof(AFN_RadialForce_C, Falloff_Type) == 0x340, "Offset mismatch for AFN_RadialForce_C::Falloff_Type");
static_assert(offsetof(AFN_RadialForce_C, Expansion) == 0x348, "Offset mismatch for AFN_RadialForce_C::Expansion");
static_assert(offsetof(AFN_RadialForce_C, Impact_Radius) == 0x350, "Offset mismatch for AFN_RadialForce_C::Impact_Radius");
static_assert(offsetof(AFN_RadialForce_C, Strength) == 0x358, "Offset mismatch for AFN_RadialForce_C::Strength");
static_assert(offsetof(AFN_RadialForce_C, DelayTime) == 0x360, "Offset mismatch for AFN_RadialForce_C::DelayTime");

// Size: 0x2e8 (Inherited: 0x580, Single: 0xfffffd68)
class AFN_WashForce_C : public AFieldSystemActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2b0 (Size: 0x8, Type: StructProperty)
    URadialFalloff* RadialFalloff; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UOperatorField* Multiply; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    URadialVector* RadialVector; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    double Radius; // 0x2d0 (Size: 0x8, Type: DoubleProperty)
    double Strength; // 0x2d8 (Size: 0x8, Type: DoubleProperty)
    double Stop_TIme; // 0x2e0 (Size: 0x8, Type: DoubleProperty)

public:
    bool Compute_Strength(double& ReturnValue2); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SertRadius(double& Radius); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveDestroyed(); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AFN_WashForce_C) == 0x2e8, "Size mismatch for AFN_WashForce_C");
static_assert(offsetof(AFN_WashForce_C, UberGraphFrame) == 0x2b0, "Offset mismatch for AFN_WashForce_C::UberGraphFrame");
static_assert(offsetof(AFN_WashForce_C, RadialFalloff) == 0x2b8, "Offset mismatch for AFN_WashForce_C::RadialFalloff");
static_assert(offsetof(AFN_WashForce_C, Multiply) == 0x2c0, "Offset mismatch for AFN_WashForce_C::Multiply");
static_assert(offsetof(AFN_WashForce_C, RadialVector) == 0x2c8, "Offset mismatch for AFN_WashForce_C::RadialVector");
static_assert(offsetof(AFN_WashForce_C, Radius) == 0x2d0, "Offset mismatch for AFN_WashForce_C::Radius");
static_assert(offsetof(AFN_WashForce_C, Strength) == 0x2d8, "Offset mismatch for AFN_WashForce_C::Strength");
static_assert(offsetof(AFN_WashForce_C, Stop_TIme) == 0x2e0, "Offset mismatch for AFN_WashForce_C::Stop_TIme");

