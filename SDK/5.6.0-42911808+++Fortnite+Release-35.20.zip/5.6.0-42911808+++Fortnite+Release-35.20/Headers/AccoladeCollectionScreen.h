/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AccoladeCollectionScreen
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUI.h"
#include "FortniteUI.h"
#include "FortniteGame.h"
#include "CommonUILegacy.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"

// Size: 0x2e0 (Inherited: 0x730, Single: 0xfffffbb0)
class UFortAccoladeStageListEntry : public UCommonUserWidget
{
public:
    UAthenaChallengeRewards* UserWidget_Rewards; // 0x2d8 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void BP_PopulateAchievedCount(int32_t& AchievedCount); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortAccoladeStageListEntry) == 0x2e0, "Size mismatch for UFortAccoladeStageListEntry");
static_assert(offsetof(UFortAccoladeStageListEntry, UserWidget_Rewards) == 0x2d8, "Offset mismatch for UFortAccoladeStageListEntry::UserWidget_Rewards");

// Size: 0x328 (Inherited: 0xa48, Single: 0xfffff8e0)
class UPinnedAccoladeWidget : public UFortHUDElementWidget
{
public:
    UFortLazyImage* LazyImage_PinColor; // 0x318 (Size: 0x8, Type: ObjectProperty)
    int32_t NumAllowedDescCharacters; // 0x320 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_324[0x4]; // 0x324 (Size: 0x4, Type: PaddingProperty)

protected:
    virtual void BP_PopulateAccoladeInfo(const FText Description, int32_t& Achieved, int32_t& Total); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UPinnedAccoladeWidget) == 0x328, "Size mismatch for UPinnedAccoladeWidget");
static_assert(offsetof(UPinnedAccoladeWidget, LazyImage_PinColor) == 0x318, "Offset mismatch for UPinnedAccoladeWidget::LazyImage_PinColor");
static_assert(offsetof(UPinnedAccoladeWidget, NumAllowedDescCharacters) == 0x320, "Offset mismatch for UPinnedAccoladeWidget::NumAllowedDescCharacters");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UFortCollectionDataEntryAccolade : public UFortCollectionDataEntry
{
public:
};

static_assert(sizeof(UFortCollectionDataEntryAccolade) == 0x40, "Size mismatch for UFortCollectionDataEntryAccolade");

// Size: 0x1590 (Inherited: 0x4640, Single: 0xffffcf50)
class UFortPlayerAccoladeCollectionListEntry : public UAthenaCollectionListEntry
{
public:
    UImage* Image_Background; // 0x1580 (Size: 0x8, Type: ObjectProperty)
    FName ParamName_ItemIcon; // 0x1588 (Size: 0x4, Type: NameProperty)
    FName ParamName_IsDiscovered; // 0x158c (Size: 0x4, Type: NameProperty)

protected:
    virtual void BP_OnPinnedChanged(bool& const bPinned); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnSelectionSuppressionChanged(bool& const bShouldBeSuppressed); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_UpdateAccoladeTier(EFortAccoladeTierType& Tier); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_UpdateCompletedCount(int32_t& CompletedCount); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortPlayerAccoladeCollectionListEntry) == 0x1590, "Size mismatch for UFortPlayerAccoladeCollectionListEntry");
static_assert(offsetof(UFortPlayerAccoladeCollectionListEntry, Image_Background) == 0x1580, "Offset mismatch for UFortPlayerAccoladeCollectionListEntry::Image_Background");
static_assert(offsetof(UFortPlayerAccoladeCollectionListEntry, ParamName_ItemIcon) == 0x1588, "Offset mismatch for UFortPlayerAccoladeCollectionListEntry::ParamName_ItemIcon");
static_assert(offsetof(UFortPlayerAccoladeCollectionListEntry, ParamName_IsDiscovered) == 0x158c, "Offset mismatch for UFortPlayerAccoladeCollectionListEntry::ParamName_IsDiscovered");

// Size: 0x6d8 (Inherited: 0x1188, Single: 0xfffff550)
class UFortPlayerAccoladeCollectionScreen : public UAthenaCollectionScreenBase
{
public:
    uint8_t Pad_650[0x30]; // 0x650 (Size: 0x30, Type: PaddingProperty)
    FScalableFloat AccoladesEnabledViaHotfix; // 0x680 (Size: 0x28, Type: StructProperty)
    UCommonTextBlock* Text_CategoryTitle; // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_ClearBangs; // 0x6b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_6b8[0x18]; // 0x6b8 (Size: 0x18, Type: PaddingProperty)
    bool bUserProgressSuccessfullyRetrieved; // 0x6d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6d1[0x7]; // 0x6d1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortPlayerAccoladeCollectionScreen) == 0x6d8, "Size mismatch for UFortPlayerAccoladeCollectionScreen");
static_assert(offsetof(UFortPlayerAccoladeCollectionScreen, AccoladesEnabledViaHotfix) == 0x680, "Offset mismatch for UFortPlayerAccoladeCollectionScreen::AccoladesEnabledViaHotfix");
static_assert(offsetof(UFortPlayerAccoladeCollectionScreen, Text_CategoryTitle) == 0x6a8, "Offset mismatch for UFortPlayerAccoladeCollectionScreen::Text_CategoryTitle");
static_assert(offsetof(UFortPlayerAccoladeCollectionScreen, Button_ClearBangs) == 0x6b0, "Offset mismatch for UFortPlayerAccoladeCollectionScreen::Button_ClearBangs");
static_assert(offsetof(UFortPlayerAccoladeCollectionScreen, bUserProgressSuccessfullyRetrieved) == 0x6d0, "Offset mismatch for UFortPlayerAccoladeCollectionScreen::bUserProgressSuccessfullyRetrieved");

// Size: 0x558 (Inherited: 0x1078, Single: 0xfffff4e0)
class UFortPlayerAccoladeCollectionScreenContainer : public UAthenaCollectionScreenContainer
{
public:
    UAccoladeProductData* BRProductData; // 0x540 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_548[0x10]; // 0x548 (Size: 0x10, Type: PaddingProperty)

protected:
    virtual void BP_OnLoadingStatusChanged(bool& bLoadingInProgress); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_PopulateProgress(int32_t& Current, int32_t& Total); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortPlayerAccoladeCollectionScreenContainer) == 0x558, "Size mismatch for UFortPlayerAccoladeCollectionScreenContainer");
static_assert(offsetof(UFortPlayerAccoladeCollectionScreenContainer, BRProductData) == 0x540, "Offset mismatch for UFortPlayerAccoladeCollectionScreenContainer::BRProductData");

// Size: 0x4d0 (Inherited: 0xff8, Single: 0xfffff4d8)
class UFortPlayerAccoladeCollectionScreenInfoOverlay : public UAthenaCollectionScreenInfoOverlay
{
public:
    UFortCTAButton* Button_TrackAccolade; // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UFortAccoladeStageListEntry* Widget_AccoladeGoal; // 0x4c8 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void BP_PopulateAccoladeInfo(int32_t& CompletionCount); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_PopulateCurrentProgress(bool& const bShouldShow, int32_t& const Current, int32_t& const Max); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_UpdateAccoladeTier(EFortAccoladeTierType& Tier); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_UpdateTrackButtonText(bool& const bTracked); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortPlayerAccoladeCollectionScreenInfoOverlay) == 0x4d0, "Size mismatch for UFortPlayerAccoladeCollectionScreenInfoOverlay");
static_assert(offsetof(UFortPlayerAccoladeCollectionScreenInfoOverlay, Button_TrackAccolade) == 0x4c0, "Offset mismatch for UFortPlayerAccoladeCollectionScreenInfoOverlay::Button_TrackAccolade");
static_assert(offsetof(UFortPlayerAccoladeCollectionScreenInfoOverlay, Widget_AccoladeGoal) == 0x4c8, "Offset mismatch for UFortPlayerAccoladeCollectionScreenInfoOverlay::Widget_AccoladeGoal");

