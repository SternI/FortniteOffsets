/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EliminationManager
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FEliminationManager_TargetTag
{
    FText DisplayName_10_865C0E1345A52591AA0CF093C2460CCE; // 0x0 (Size: 0x10, Type: TextProperty)
    FGameplayTagQuery Value_9_1F09D3BE48D352C4EFD0549E8936A8F5; // 0x10 (Size: 0x48, Type: StructProperty)
    FGameplayTagContainer GrantedContextTags_8_B87A88594B96B7892F330C87CB23719B; // 0x58 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FEliminationManager_TargetTag) == 0x78, "Size mismatch for FEliminationManager_TargetTag");
static_assert(offsetof(FEliminationManager_TargetTag, DisplayName_10_865C0E1345A52591AA0CF093C2460CCE) == 0x0, "Offset mismatch for FEliminationManager_TargetTag::DisplayName_10_865C0E1345A52591AA0CF093C2460CCE");
static_assert(offsetof(FEliminationManager_TargetTag, Value_9_1F09D3BE48D352C4EFD0549E8936A8F5) == 0x10, "Offset mismatch for FEliminationManager_TargetTag::Value_9_1F09D3BE48D352C4EFD0549E8936A8F5");
static_assert(offsetof(FEliminationManager_TargetTag, GrantedContextTags_8_B87A88594B96B7892F330C87CB23719B) == 0x58, "Offset mismatch for FEliminationManager_TargetTag::GrantedContextTags_8_B87A88594B96B7892F330C87CB23719B");

