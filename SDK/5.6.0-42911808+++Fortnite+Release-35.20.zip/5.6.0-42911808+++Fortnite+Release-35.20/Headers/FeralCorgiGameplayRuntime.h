/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FeralCorgiGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "PlayspaceSystem.h"
#include "Engine.h"
#include "FortniteGameFramework.h"
#include "ModularGameplay.h"
#include "FortGameplayStateMachine.h"
#include "GameplayStateMachine.h"
#include "GameplayTags.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UApparatusBridge : public UObject
{
public:
};

static_assert(sizeof(UApparatusBridge) == 0x28, "Size mismatch for UApparatusBridge");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UCheatBridge : public UObject
{
public:
};

static_assert(sizeof(UCheatBridge) == 0x28, "Size mismatch for UCheatBridge");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UFeralCorgiGameStateComponentBridge : public UObject
{
public:
};

static_assert(sizeof(UFeralCorgiGameStateComponentBridge) == 0x28, "Size mismatch for UFeralCorgiGameStateComponentBridge");

// Size: 0xc8 (Inherited: 0x310, Single: 0xfffffdb8)
class UFortControllerComponent_FeralCorgi : public UFortControllerComponent
{
public:
    UClass* DamageCameraShakeClassOverride; // 0xc0 (Size: 0x8, Type: ClassProperty)

private:
    void HandlePosessedPawnChanged(APawn*& OldPawn, APawn*& NewPawn); // 0x11a7b1a0 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortControllerComponent_FeralCorgi) == 0xc8, "Size mismatch for UFortControllerComponent_FeralCorgi");
static_assert(offsetof(UFortControllerComponent_FeralCorgi, DamageCameraShakeClassOverride) == 0xc0, "Offset mismatch for UFortControllerComponent_FeralCorgi::DamageCameraShakeClassOverride");

// Size: 0x148 (Inherited: 0x360, Single: 0xfffffde8)
class UFortPlayspaceComponent_Apparatus : public UFortPlayspaceComponent
{
public:
    uint8_t Pad_110[0x10]; // 0x110 (Size: 0x10, Type: PaddingProperty)
    uint8_t OnApparatusTimerRemainingUpdated[0x10]; // 0x120 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnApparatusReset[0x10]; // 0x130 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_140[0x8]; // 0x140 (Size: 0x8, Type: PaddingProperty)

public:
    virtual void DisableDisabling(AController*& const Controller); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void DisablePlanting(AController*& const Controller); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void EnableDisabling(AController*& const Controller); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void EnablePlanting(AController*& const Controller); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    static UFortPlayspaceComponent_Apparatus* GetOrCreate(AActor*& const ContextActor, UClass*& ComponentClass); // 0x11a7a3d4 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    float GetResidualDisablingProgressAtLastDisable() const; // 0xd67b540 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void NotifyApparatusStateChanged(AController*& Instigator, EApparatusState& ApparatusState); // 0x11a7bc70 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    virtual void ResetApparatus(); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintEvent)
    virtual void SetApparatusTimerRemaining(int32_t& time); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)
    void SetResidualDisablingProgressAtLastDisable(float& DisablingProgressSeconds); // 0x11a7c358 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortPlayspaceComponent_Apparatus) == 0x148, "Size mismatch for UFortPlayspaceComponent_Apparatus");
static_assert(offsetof(UFortPlayspaceComponent_Apparatus, OnApparatusTimerRemainingUpdated) == 0x120, "Offset mismatch for UFortPlayspaceComponent_Apparatus::OnApparatusTimerRemainingUpdated");
static_assert(offsetof(UFortPlayspaceComponent_Apparatus, OnApparatusReset) == 0x130, "Offset mismatch for UFortPlayspaceComponent_Apparatus::OnApparatusReset");

// Size: 0x1a0 (Inherited: 0x228, Single: 0xffffff78)
class UFortUserOptionComponent_TickRate : public UFortUserOptionContainerComponent
{
public:
    uint8_t DesiredTickRate; // 0x148 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_149[0x57]; // 0x149 (Size: 0x57, Type: PaddingProperty)
};

static_assert(sizeof(UFortUserOptionComponent_TickRate) == 0x1a0, "Size mismatch for UFortUserOptionComponent_TickRate");
static_assert(offsetof(UFortUserOptionComponent_TickRate, DesiredTickRate) == 0x148, "Offset mismatch for UFortUserOptionComponent_TickRate::DesiredTickRate");

// Size: 0x1ab8 (Inherited: 0x4378, Single: 0xffffd740)
class AFeralCorgiPlayerState : public AFortPlayerStateAthena
{
public:
    TArray<FLinearColor> PinColorForPlayer; // 0x1aa8 (Size: 0x10, Type: ArrayProperty)

public:
    FGameplayTag GetTeamStartTag(); // 0x11a7a9cc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(AFeralCorgiPlayerState) == 0x1ab8, "Size mismatch for AFeralCorgiPlayerState");
static_assert(offsetof(AFeralCorgiPlayerState, PinColorForPlayer) == 0x1aa8, "Offset mismatch for AFeralCorgiPlayerState::PinColorForPlayer");

// Size: 0x6e8 (Inherited: 0x1240, Single: 0xfffff4a8)
class AFeralCorgiRootPlayspace : public AFortPlayspace
{
public:
    UClass* FeralCorgiStateMachineClass; // 0x6e0 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(AFeralCorgiRootPlayspace) == 0x6e8, "Size mismatch for AFeralCorgiRootPlayspace");
static_assert(offsetof(AFeralCorgiRootPlayspace, FeralCorgiStateMachineClass) == 0x6e0, "Offset mismatch for AFeralCorgiRootPlayspace::FeralCorgiStateMachineClass");

// Size: 0xd0 (Inherited: 0x308, Single: 0xfffffdc8)
class UFortGameStateComponent_FeralCorgiManager : public UFortGameStateComponent
{
public:
    uint8_t Pad_b8[0x10]; // 0xb8 (Size: 0x10, Type: PaddingProperty)
    char TeamOneTeamId; // 0xc8 (Size: 0x1, Type: ByteProperty)
    char TeamTwoTeamId; // 0xc9 (Size: 0x1, Type: ByteProperty)
    uint8_t CurrentAttackingTeam; // 0xca (Size: 0x1, Type: EnumProperty)
    uint8_t RoundWinningTeam; // 0xcb (Size: 0x1, Type: EnumProperty)
    uint8_t RoundWinningTeamRole; // 0xcc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_cd[0x3]; // 0xcd (Size: 0x3, Type: PaddingProperty)

public:
    static UFortGameStateComponent_FeralCorgiManager* Get(UObject*& WorldContextObject); // 0x11a79bd4 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    EFeralCorgiTeam GetFeralCorgiTeam(char& TeamID) const; // 0x11a7a01c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFeralCorgiTeam GetFeralCorgiTeamFromTeamRole(EFeralCorgiTeamRole& TeamRole) const; // 0x11a7a154 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFeralCorgiTeamRole GetFeralCorgiTeamRoleFromTeam(EFeralCorgiTeam& Team) const; // 0x11a7a294 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFeralCorgiTeam GetRoundWinningTeam() const; // 0x11a7a99c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFeralCorgiTeamRole GetRoundWinningTeamRole() const; // 0x11a7a9b4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetRoundWinner(EFeralCorgiTeam& WinningTeam, EFeralCorgiTeamRole& WinningTeamRole); // 0x11a7c484 (Index: 0x6, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SwapTeamRoles(); // 0x11a7c690 (Index: 0x7, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortGameStateComponent_FeralCorgiManager) == 0xd0, "Size mismatch for UFortGameStateComponent_FeralCorgiManager");
static_assert(offsetof(UFortGameStateComponent_FeralCorgiManager, TeamOneTeamId) == 0xc8, "Offset mismatch for UFortGameStateComponent_FeralCorgiManager::TeamOneTeamId");
static_assert(offsetof(UFortGameStateComponent_FeralCorgiManager, TeamTwoTeamId) == 0xc9, "Offset mismatch for UFortGameStateComponent_FeralCorgiManager::TeamTwoTeamId");
static_assert(offsetof(UFortGameStateComponent_FeralCorgiManager, CurrentAttackingTeam) == 0xca, "Offset mismatch for UFortGameStateComponent_FeralCorgiManager::CurrentAttackingTeam");
static_assert(offsetof(UFortGameStateComponent_FeralCorgiManager, RoundWinningTeam) == 0xcb, "Offset mismatch for UFortGameStateComponent_FeralCorgiManager::RoundWinningTeam");
static_assert(offsetof(UFortGameStateComponent_FeralCorgiManager, RoundWinningTeamRole) == 0xcc, "Offset mismatch for UFortGameStateComponent_FeralCorgiManager::RoundWinningTeamRole");

// Size: 0x88 (Inherited: 0x128, Single: 0xffffff60)
class UFeralCorgiState : public UFortGameplayState
{
public:
};

static_assert(sizeof(UFeralCorgiState) == 0x88, "Size mismatch for UFeralCorgiState");

// Size: 0xf0 (Inherited: 0x258, Single: 0xfffffe98)
class UFeralCorgiStateMachine : public UFortGameplayStateMachine
{
public:
};

static_assert(sizeof(UFeralCorgiStateMachine) == 0xf0, "Size mismatch for UFeralCorgiStateMachine");

// Size: 0x88 (Inherited: 0x1b0, Single: 0xfffffed8)
class UFeralCorgiState_ClassSelection : public UFeralCorgiState
{
public:
};

static_assert(sizeof(UFeralCorgiState_ClassSelection) == 0x88, "Size mismatch for UFeralCorgiState_ClassSelection");

// Size: 0xf0 (Inherited: 0x348, Single: 0xfffffda8)
class UFeralCorgiState_MainLoopSM : public UFeralCorgiStateMachine
{
public:
};

static_assert(sizeof(UFeralCorgiState_MainLoopSM) == 0xf0, "Size mismatch for UFeralCorgiState_MainLoopSM");

// Size: 0x88 (Inherited: 0x1b0, Single: 0xfffffed8)
class UFeralCorgiState_MainLoop_BuyPhase : public UFeralCorgiState
{
public:
};

static_assert(sizeof(UFeralCorgiState_MainLoop_BuyPhase) == 0x88, "Size mismatch for UFeralCorgiState_MainLoop_BuyPhase");

// Size: 0x88 (Inherited: 0x1b0, Single: 0xfffffed8)
class UFeralCorgiState_MainLoop_End : public UFeralCorgiState
{
public:
};

static_assert(sizeof(UFeralCorgiState_MainLoop_End) == 0x88, "Size mismatch for UFeralCorgiState_MainLoop_End");

// Size: 0x88 (Inherited: 0x1b0, Single: 0xfffffed8)
class UFeralCorgiState_MainLoop_Gameplay : public UFeralCorgiState
{
public:
};

static_assert(sizeof(UFeralCorgiState_MainLoop_Gameplay) == 0x88, "Size mismatch for UFeralCorgiState_MainLoop_Gameplay");

// Size: 0x88 (Inherited: 0x1b0, Single: 0xfffffed8)
class UFeralCorgiState_MainLoop_Reset : public UFeralCorgiState
{
public:
};

static_assert(sizeof(UFeralCorgiState_MainLoop_Reset) == 0x88, "Size mismatch for UFeralCorgiState_MainLoop_Reset");

// Size: 0xf0 (Inherited: 0x258, Single: 0xfffffe98)
class UFeralCorgiState_MasterSM : public UFortGameplayStateMachine
{
public:

public:
    bool AreAllPlayersReady(); // 0x11a7952c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    static UFeralCorgiState_MasterSM* Get(UObject*& WorldContextObject); // 0x11a79aac (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UFeralCorgiState_MasterSM) == 0xf0, "Size mismatch for UFeralCorgiState_MasterSM");

// Size: 0x88 (Inherited: 0x1b0, Single: 0xfffffed8)
class UFeralCorgiState_MatchFinished : public UFeralCorgiState
{
public:
};

static_assert(sizeof(UFeralCorgiState_MatchFinished) == 0x88, "Size mismatch for UFeralCorgiState_MatchFinished");

// Size: 0x88 (Inherited: 0x1b0, Single: 0xfffffed8)
class UFeralCorgiState_Setup : public UFeralCorgiState
{
public:
};

static_assert(sizeof(UFeralCorgiState_Setup) == 0x88, "Size mismatch for UFeralCorgiState_Setup");

// Size: 0x2e0 (Inherited: 0x5a8, Single: 0xfffffd38)
class AFeralCorgiTeamStart : public AFortSquadStart
{
public:
    uint8_t StartType; // 0x2d8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2d9[0x7]; // 0x2d9 (Size: 0x7, Type: PaddingProperty)

public:
    EFeralCorgiStartType GetStartType() const; // 0xd5c0a70 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(AFeralCorgiTeamStart) == 0x2e0, "Size mismatch for AFeralCorgiTeamStart");
static_assert(offsetof(AFeralCorgiTeamStart, StartType) == 0x2d8, "Offset mismatch for AFeralCorgiTeamStart::StartType");

// Size: 0x4f8 (Inherited: 0x1070, Single: 0xfffff488)
class AFortAthenaMutator_FeralCorgi : public AFortAthenaMutator_GameModeBase
{
public:
    TArray<UFortWorldItemDefinition*> DoNotDropItemDefs; // 0x4b0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFortWorldItemDefinition*> DoNotDestroyItemDefs; // 0x4c0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFortWorldItemDefinition*> AutoPickupItemDefs; // 0x4d0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFortWorldItemDefinition*> BuyPhaseRestrictedItemDefs; // 0x4e0 (Size: 0x10, Type: ArrayProperty)
    TEnumAsByte<EVerticalAlignment> HUDMenuBottomBarVerticalAligment; // 0x4f0 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EHorizontalAlignment> HUDMenuBottomBarHorizontalAligment; // 0x4f1 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EVerticalAlignment> HUDEliminatorSpectatingPlayernameVerticalAligment; // 0x4f2 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EHorizontalAlignment> HUDEliminatorSpectatingPlayernameHorinzontalAligment; // 0x4f3 (Size: 0x1, Type: ByteProperty)
    bool bUseTeamForSpectating; // 0x4f4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4f5[0x3]; // 0x4f5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(AFortAthenaMutator_FeralCorgi) == 0x4f8, "Size mismatch for AFortAthenaMutator_FeralCorgi");
static_assert(offsetof(AFortAthenaMutator_FeralCorgi, DoNotDropItemDefs) == 0x4b0, "Offset mismatch for AFortAthenaMutator_FeralCorgi::DoNotDropItemDefs");
static_assert(offsetof(AFortAthenaMutator_FeralCorgi, DoNotDestroyItemDefs) == 0x4c0, "Offset mismatch for AFortAthenaMutator_FeralCorgi::DoNotDestroyItemDefs");
static_assert(offsetof(AFortAthenaMutator_FeralCorgi, AutoPickupItemDefs) == 0x4d0, "Offset mismatch for AFortAthenaMutator_FeralCorgi::AutoPickupItemDefs");
static_assert(offsetof(AFortAthenaMutator_FeralCorgi, BuyPhaseRestrictedItemDefs) == 0x4e0, "Offset mismatch for AFortAthenaMutator_FeralCorgi::BuyPhaseRestrictedItemDefs");
static_assert(offsetof(AFortAthenaMutator_FeralCorgi, HUDMenuBottomBarVerticalAligment) == 0x4f0, "Offset mismatch for AFortAthenaMutator_FeralCorgi::HUDMenuBottomBarVerticalAligment");
static_assert(offsetof(AFortAthenaMutator_FeralCorgi, HUDMenuBottomBarHorizontalAligment) == 0x4f1, "Offset mismatch for AFortAthenaMutator_FeralCorgi::HUDMenuBottomBarHorizontalAligment");
static_assert(offsetof(AFortAthenaMutator_FeralCorgi, HUDEliminatorSpectatingPlayernameVerticalAligment) == 0x4f2, "Offset mismatch for AFortAthenaMutator_FeralCorgi::HUDEliminatorSpectatingPlayernameVerticalAligment");
static_assert(offsetof(AFortAthenaMutator_FeralCorgi, HUDEliminatorSpectatingPlayernameHorinzontalAligment) == 0x4f3, "Offset mismatch for AFortAthenaMutator_FeralCorgi::HUDEliminatorSpectatingPlayernameHorinzontalAligment");
static_assert(offsetof(AFortAthenaMutator_FeralCorgi, bUseTeamForSpectating) == 0x4f4, "Offset mismatch for AFortAthenaMutator_FeralCorgi::bUseTeamForSpectating");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UFortCheatManager_FeralCorgi : public UChildCheatManager
{
public:

public:
    void FCVC(FString& Cheat, double& Value); // 0x11a79550 (Index: 0x0, Flags: Final|Exec|Native|Public)
    void FCVC_AlwaysSwapSidesOnRoundEnd(); // 0x554e3c4 (Index: 0x1, Flags: Final|Exec|Native|Public)
    void FCVC_DisableAutoGameWin(); // 0x554e3c4 (Index: 0x2, Flags: Final|Exec|Native|Public)
    void FCVC_EnableAutoGameWin(); // 0x554e3c4 (Index: 0x3, Flags: Final|Exec|Native|Public)
    void FCVC_EnableFakeRankedMode(); // 0x554e3c4 (Index: 0x4, Flags: Final|Exec|Native|Public)
    void FCVC_ForceEndPhase(); // 0x554e3c4 (Index: 0x5, Flags: Final|Exec|Native|Public)
    void FCVC_ForceShowLastPlayerStanding(); // 0x554e3c4 (Index: 0x6, Flags: Final|Exec|Native|Public)
    void FCVC_ForceTwoPlayersLeftAnnouncement(); // 0x554e3c4 (Index: 0x7, Flags: Final|Exec|Native|Public)
    void FCVC_GiveGold(double& Value); // 0x11a79998 (Index: 0x8, Flags: Final|Exec|Native|Public)
    void FCVC_LoseGame(); // 0x554e3c4 (Index: 0x9, Flags: Final|Exec|Native|Public)
    void FCVC_LoseRound(); // 0x554e3c4 (Index: 0xa, Flags: Final|Exec|Native|Public)
    void FCVC_ResetPlayerFTUEData(); // 0x554e3c4 (Index: 0xb, Flags: Final|Exec|Native|Public)
    void FCVC_SetInfiniteRounds(double& Value); // 0x11a79998 (Index: 0xc, Flags: Final|Exec|Native|Public)
    void FCVC_SetTeam(double& Value); // 0x11a79998 (Index: 0xd, Flags: Final|Exec|Native|Public)
    void FCVC_SetTimer(double& Value); // 0x11a79998 (Index: 0xe, Flags: Final|Exec|Native|Public)
    void FCVC_SetTimerPaused(double& Paused); // 0x11a79998 (Index: 0xf, Flags: Final|Exec|Native|Public)
    void FCVC_SkipIntro(); // 0x554e3c4 (Index: 0x10, Flags: Final|Exec|Native|Public)
    void FCVC_SwapTeamSides(); // 0x554e3c4 (Index: 0x11, Flags: Final|Exec|Native|Public)
    void FCVC_TeleportToAttackers(); // 0x554e3c4 (Index: 0x12, Flags: Final|Exec|Native|Public)
    void FCVC_TeleportToDefenders(); // 0x554e3c4 (Index: 0x13, Flags: Final|Exec|Native|Public)
    void FCVC_ToggleCombatReportHUD(); // 0x554e3c4 (Index: 0x14, Flags: Final|Exec|Native|Public)
    void FCVC_ToggleEliminationFeedHUD(); // 0x554e3c4 (Index: 0x15, Flags: Final|Exec|Native|Public)
    void FCVC_ToggleHUD(); // 0x554e3c4 (Index: 0x16, Flags: Final|Exec|Native|Public)
    void FCVC_WinGame(); // 0x554e3c4 (Index: 0x17, Flags: Final|Exec|Native|Public)
    void FCVC_WinRound(); // 0x554e3c4 (Index: 0x18, Flags: Final|Exec|Native|Public)
    void FeralCorgiVerseCheat(FString& Cheat, double& Value); // 0x11a79550 (Index: 0x19, Flags: Final|Exec|Native|Public)
};

static_assert(sizeof(UFortCheatManager_FeralCorgi) == 0x28, "Size mismatch for UFortCheatManager_FeralCorgi");

// Size: 0xc8 (Inherited: 0x308, Single: 0xfffffdc0)
class UFortGameStateComponent_FeralCorgiVerseCommonBridge : public UFortGameStateComponent
{
public:
    FString CurrentPhaseName; // 0xb8 (Size: 0x10, Type: StrProperty)

public:
    static UFortGameStateComponent_FeralCorgiVerseCommonBridge* Get(UObject*& WorldContextObject); // 0x11a79cfc (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    virtual void HandleVerseToNativeEvent(FString& EventName, const TArray<AController*> TargetControllers, const TMap<double, FString> Params, bool& bWasHandled); // 0x11a7b734 (Index: 0x3, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
    void SendNativeToVerseEvent(FString& EventName, const TArray<AController*> TargetControllers, const TMap<double, FString> Params); // 0x11a7be84 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

protected:
    virtual void HandleGamePhaseBeginEvent(FString& PhaseName, int32_t& const PhaseActiveCounter); // 0x11a7a9f8 (Index: 0x1, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void HandleGamePhaseEndEvent(FString& PhaseName, int32_t& const PhaseActiveCounter); // 0x11a7adcc (Index: 0x2, Flags: Native|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortGameStateComponent_FeralCorgiVerseCommonBridge) == 0xc8, "Size mismatch for UFortGameStateComponent_FeralCorgiVerseCommonBridge");
static_assert(offsetof(UFortGameStateComponent_FeralCorgiVerseCommonBridge, CurrentPhaseName) == 0xb8, "Offset mismatch for UFortGameStateComponent_FeralCorgiVerseCommonBridge::CurrentPhaseName");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FFeralCorgiCheatEvent
{
    FGameplayTag Tag; // 0x0 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FFeralCorgiCheatEvent) == 0x4, "Size mismatch for FFeralCorgiCheatEvent");
static_assert(offsetof(FFeralCorgiCheatEvent, Tag) == 0x0, "Offset mismatch for FFeralCorgiCheatEvent::Tag");

