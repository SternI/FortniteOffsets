/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BattleRoyaleFrontend
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x160 (Inherited: 0x28, Single: 0x138)
class UBattleRoyaleFrontendExperienceFlow : public UObject
{
public:
    uint8_t Pad_28[0x28]; // 0x28 (Size: 0x28, Type: PaddingProperty)
    TArray<FString> DefaultFlowStepArray; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> FirstTimeSeasonFlowStepArray; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FString> BRVideoRating; // 0x70 (Size: 0x50, Type: MapProperty)
    TArray<FBattleRoyaleFrontendProductVideoOverride> ProductVideoOverrides; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_d0[0x18]; // 0xd0 (Size: 0x18, Type: PaddingProperty)
    TSoftClassPtr VideoPlayerClass; // 0xe8 (Size: 0x20, Type: SoftClassProperty)
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
    UClass* HabaneroIntroModalClass; // 0x110 (Size: 0x8, Type: ClassProperty)
    TSoftClassPtr FireModeSelectionReminderModalClass; // 0x118 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr FireModeSelectionScreenClass; // 0x138 (Size: 0x20, Type: SoftClassProperty)
    UClass* SimpleBuildAndEditModalHelper; // 0x158 (Size: 0x8, Type: ClassProperty)

private:
    void FinishTrailerStep(); // 0x11005b30 (Index: 0x0, Flags: Final|Native|Private)
    void HandleBattlePassTrailerEnded(); // 0x11005b44 (Index: 0x1, Flags: Final|Native|Private)
    void HandleSeasonTrailerEnded(); // 0x11005b58 (Index: 0x2, Flags: Final|Native|Private)
    void HandleVideoTerminalError(EBaseMediaTerminalErrorReason& Reason); // 0x11005b6c (Index: 0x3, Flags: Final|Native|Private)
};

static_assert(sizeof(UBattleRoyaleFrontendExperienceFlow) == 0x160, "Size mismatch for UBattleRoyaleFrontendExperienceFlow");
static_assert(offsetof(UBattleRoyaleFrontendExperienceFlow, DefaultFlowStepArray) == 0x50, "Offset mismatch for UBattleRoyaleFrontendExperienceFlow::DefaultFlowStepArray");
static_assert(offsetof(UBattleRoyaleFrontendExperienceFlow, FirstTimeSeasonFlowStepArray) == 0x60, "Offset mismatch for UBattleRoyaleFrontendExperienceFlow::FirstTimeSeasonFlowStepArray");
static_assert(offsetof(UBattleRoyaleFrontendExperienceFlow, BRVideoRating) == 0x70, "Offset mismatch for UBattleRoyaleFrontendExperienceFlow::BRVideoRating");
static_assert(offsetof(UBattleRoyaleFrontendExperienceFlow, ProductVideoOverrides) == 0xc0, "Offset mismatch for UBattleRoyaleFrontendExperienceFlow::ProductVideoOverrides");
static_assert(offsetof(UBattleRoyaleFrontendExperienceFlow, VideoPlayerClass) == 0xe8, "Offset mismatch for UBattleRoyaleFrontendExperienceFlow::VideoPlayerClass");
static_assert(offsetof(UBattleRoyaleFrontendExperienceFlow, HabaneroIntroModalClass) == 0x110, "Offset mismatch for UBattleRoyaleFrontendExperienceFlow::HabaneroIntroModalClass");
static_assert(offsetof(UBattleRoyaleFrontendExperienceFlow, FireModeSelectionReminderModalClass) == 0x118, "Offset mismatch for UBattleRoyaleFrontendExperienceFlow::FireModeSelectionReminderModalClass");
static_assert(offsetof(UBattleRoyaleFrontendExperienceFlow, FireModeSelectionScreenClass) == 0x138, "Offset mismatch for UBattleRoyaleFrontendExperienceFlow::FireModeSelectionScreenClass");
static_assert(offsetof(UBattleRoyaleFrontendExperienceFlow, SimpleBuildAndEditModalHelper) == 0x158, "Offset mismatch for UBattleRoyaleFrontendExperienceFlow::SimpleBuildAndEditModalHelper");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FBattleRoyaleFrontendProductVideoOverride
{
    FGameplayTag ProductTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FString MediaID; // 0x8 (Size: 0x10, Type: StrProperty)
    FName MediaName; // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FBattleRoyaleFrontendProductVideoOverride) == 0x20, "Size mismatch for FBattleRoyaleFrontendProductVideoOverride");
static_assert(offsetof(FBattleRoyaleFrontendProductVideoOverride, ProductTag) == 0x0, "Offset mismatch for FBattleRoyaleFrontendProductVideoOverride::ProductTag");
static_assert(offsetof(FBattleRoyaleFrontendProductVideoOverride, MediaID) == 0x8, "Offset mismatch for FBattleRoyaleFrontendProductVideoOverride::MediaID");
static_assert(offsetof(FBattleRoyaleFrontendProductVideoOverride, MediaName) == 0x18, "Offset mismatch for FBattleRoyaleFrontendProductVideoOverride::MediaName");

