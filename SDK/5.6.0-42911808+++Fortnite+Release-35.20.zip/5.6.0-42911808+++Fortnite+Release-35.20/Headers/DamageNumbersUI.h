/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DamageNumbersUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUI.h"
#include "Engine.h"
#include "FortniteUI.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "UMG.h"
#include "GameplayTags.h"

// Size: 0x490 (Inherited: 0x730, Single: 0xfffffd60)
class UCommonUserWidget_DamageNumbers : public UCommonUserWidget
{
public:
    uint8_t Pad_2d8[0x10]; // 0x2d8 (Size: 0x10, Type: PaddingProperty)
    FVector WorldSpacePos; // 0x2e8 (Size: 0x18, Type: StructProperty)
    FGameplayTag CheckAnimalTag; // 0x300 (Size: 0x4, Type: StructProperty)
    float Damage; // 0x304 (Size: 0x4, Type: FloatProperty)
    float AdditionalVerticalScreenOffset; // 0x308 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_30c[0x4]; // 0x30c (Size: 0x4, Type: PaddingProperty)
    double SpawnTime; // 0x310 (Size: 0x8, Type: DoubleProperty)
    FVector2D DamageNumberScaleVector; // 0x318 (Size: 0x10, Type: StructProperty)
    FVector2D ScreenSpaceOffsetFromHitActor; // 0x328 (Size: 0x10, Type: StructProperty)
    FVector2D InverseHUDScaleVector; // 0x338 (Size: 0x10, Type: StructProperty)
    AActor* HitActor; // 0x348 (Size: 0x8, Type: ObjectProperty)
    bool bHitAnimal; // 0x350 (Size: 0x1, Type: BoolProperty)
    bool bHitVehicle; // 0x351 (Size: 0x1, Type: BoolProperty)
    bool bIsPlayingCritAnimation; // 0x352 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_353[0x1]; // 0x353 (Size: 0x1, Type: PaddingProperty)
    FLinearColor HitColor; // 0x354 (Size: 0x10, Type: StructProperty)
    FLinearColor VehicleColor; // 0x364 (Size: 0x10, Type: StructProperty)
    FLinearColor CritColor; // 0x374 (Size: 0x10, Type: StructProperty)
    FLinearColor HealthColor; // 0x384 (Size: 0x10, Type: StructProperty)
    FLinearColor ShieldColor; // 0x394 (Size: 0x10, Type: StructProperty)
    FLinearColor CritColor_Text; // 0x3a4 (Size: 0x10, Type: StructProperty)
    FLinearColor ShieldColor_Text; // 0x3b4 (Size: 0x10, Type: StructProperty)
    FLinearColor HealthColor_InnerStroke; // 0x3c4 (Size: 0x10, Type: StructProperty)
    FLinearColor ShieldColor_InnerStroke; // 0x3d4 (Size: 0x10, Type: StructProperty)
    FLinearColor CritColor_InnerStroke; // 0x3e4 (Size: 0x10, Type: StructProperty)
    FLinearColor DamageIconVehicleColor; // 0x3f4 (Size: 0x10, Type: StructProperty)
    FLinearColor DamageIconShieldColor; // 0x404 (Size: 0x10, Type: StructProperty)
    FLinearColor DamageIconShieldOutline1Color; // 0x414 (Size: 0x10, Type: StructProperty)
    FLinearColor DamageIconShieldOutline2Color; // 0x424 (Size: 0x10, Type: StructProperty)
    FLinearColor DamageIconVehicleOutline1Color; // 0x434 (Size: 0x10, Type: StructProperty)
    FLinearColor DamageIconVehicleOutline2Color; // 0x444 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_454[0x4]; // 0x454 (Size: 0x4, Type: PaddingProperty)
    UWidgetAnimation* OnDamage; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnDamage_Crit; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Number; // 0x468 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Number_Stroke; // 0x470 (Size: 0x8, Type: ObjectProperty)
    UImage* DamageTypeCrit; // 0x478 (Size: 0x8, Type: ObjectProperty)
    UImage* DamageTypeIcon; // 0x480 (Size: 0x8, Type: ObjectProperty)
    UImage* DamageTypeIcon_EMP; // 0x488 (Size: 0x8, Type: ObjectProperty)

public:
    virtual FText DamageNumbersToText(const double DamageAmount) const; // 0x101e6f88 (Index: 0x0, Flags: Native|Event|Public|HasOutParms|BlueprintEvent|Const)
    void OnDamageDealt(double& InDamage, AActor*& InActor, bool& bInShield, bool& bInCrit, FVector& InWorldSpacePos, bool& bInEMP); // 0x101e70cc (Index: 0x1, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    virtual void ReceiveOnDamageDealt(double& InDamage, AActor*& InActor, bool& bInShield, bool& bInCrit, FVector& InWorldSpacePos, bool& bInEMP); // 0x288a61c (Index: 0x3, Flags: Event|Public|HasDefaults|BlueprintEvent)

protected:
    virtual void OnShieldBreak(bool& bIsOvershield); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    void Reset(); // 0x101e82f4 (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable)
    void UpdateScreenSpacePosition(); // 0x101e85e4 (Index: 0x5, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UCommonUserWidget_DamageNumbers) == 0x490, "Size mismatch for UCommonUserWidget_DamageNumbers");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, WorldSpacePos) == 0x2e8, "Offset mismatch for UCommonUserWidget_DamageNumbers::WorldSpacePos");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, CheckAnimalTag) == 0x300, "Offset mismatch for UCommonUserWidget_DamageNumbers::CheckAnimalTag");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, Damage) == 0x304, "Offset mismatch for UCommonUserWidget_DamageNumbers::Damage");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, AdditionalVerticalScreenOffset) == 0x308, "Offset mismatch for UCommonUserWidget_DamageNumbers::AdditionalVerticalScreenOffset");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, SpawnTime) == 0x310, "Offset mismatch for UCommonUserWidget_DamageNumbers::SpawnTime");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, DamageNumberScaleVector) == 0x318, "Offset mismatch for UCommonUserWidget_DamageNumbers::DamageNumberScaleVector");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, ScreenSpaceOffsetFromHitActor) == 0x328, "Offset mismatch for UCommonUserWidget_DamageNumbers::ScreenSpaceOffsetFromHitActor");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, InverseHUDScaleVector) == 0x338, "Offset mismatch for UCommonUserWidget_DamageNumbers::InverseHUDScaleVector");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, HitActor) == 0x348, "Offset mismatch for UCommonUserWidget_DamageNumbers::HitActor");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, bHitAnimal) == 0x350, "Offset mismatch for UCommonUserWidget_DamageNumbers::bHitAnimal");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, bHitVehicle) == 0x351, "Offset mismatch for UCommonUserWidget_DamageNumbers::bHitVehicle");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, bIsPlayingCritAnimation) == 0x352, "Offset mismatch for UCommonUserWidget_DamageNumbers::bIsPlayingCritAnimation");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, HitColor) == 0x354, "Offset mismatch for UCommonUserWidget_DamageNumbers::HitColor");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, VehicleColor) == 0x364, "Offset mismatch for UCommonUserWidget_DamageNumbers::VehicleColor");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, CritColor) == 0x374, "Offset mismatch for UCommonUserWidget_DamageNumbers::CritColor");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, HealthColor) == 0x384, "Offset mismatch for UCommonUserWidget_DamageNumbers::HealthColor");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, ShieldColor) == 0x394, "Offset mismatch for UCommonUserWidget_DamageNumbers::ShieldColor");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, CritColor_Text) == 0x3a4, "Offset mismatch for UCommonUserWidget_DamageNumbers::CritColor_Text");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, ShieldColor_Text) == 0x3b4, "Offset mismatch for UCommonUserWidget_DamageNumbers::ShieldColor_Text");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, HealthColor_InnerStroke) == 0x3c4, "Offset mismatch for UCommonUserWidget_DamageNumbers::HealthColor_InnerStroke");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, ShieldColor_InnerStroke) == 0x3d4, "Offset mismatch for UCommonUserWidget_DamageNumbers::ShieldColor_InnerStroke");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, CritColor_InnerStroke) == 0x3e4, "Offset mismatch for UCommonUserWidget_DamageNumbers::CritColor_InnerStroke");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, DamageIconVehicleColor) == 0x3f4, "Offset mismatch for UCommonUserWidget_DamageNumbers::DamageIconVehicleColor");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, DamageIconShieldColor) == 0x404, "Offset mismatch for UCommonUserWidget_DamageNumbers::DamageIconShieldColor");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, DamageIconShieldOutline1Color) == 0x414, "Offset mismatch for UCommonUserWidget_DamageNumbers::DamageIconShieldOutline1Color");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, DamageIconShieldOutline2Color) == 0x424, "Offset mismatch for UCommonUserWidget_DamageNumbers::DamageIconShieldOutline2Color");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, DamageIconVehicleOutline1Color) == 0x434, "Offset mismatch for UCommonUserWidget_DamageNumbers::DamageIconVehicleOutline1Color");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, DamageIconVehicleOutline2Color) == 0x444, "Offset mismatch for UCommonUserWidget_DamageNumbers::DamageIconVehicleOutline2Color");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, OnDamage) == 0x458, "Offset mismatch for UCommonUserWidget_DamageNumbers::OnDamage");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, OnDamage_Crit) == 0x460, "Offset mismatch for UCommonUserWidget_DamageNumbers::OnDamage_Crit");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, Text_Number) == 0x468, "Offset mismatch for UCommonUserWidget_DamageNumbers::Text_Number");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, Text_Number_Stroke) == 0x470, "Offset mismatch for UCommonUserWidget_DamageNumbers::Text_Number_Stroke");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, DamageTypeCrit) == 0x478, "Offset mismatch for UCommonUserWidget_DamageNumbers::DamageTypeCrit");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, DamageTypeIcon) == 0x480, "Offset mismatch for UCommonUserWidget_DamageNumbers::DamageTypeIcon");
static_assert(offsetof(UCommonUserWidget_DamageNumbers, DamageTypeIcon_EMP) == 0x488, "Offset mismatch for UCommonUserWidget_DamageNumbers::DamageTypeIcon_EMP");

// Size: 0xd8 (Inherited: 0xe0, Single: 0xfffffff8)
class UCustomDamageNumbersDataComponent : public UActorComponent
{
public:
    uint8_t OnDamageDealt[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t Priority; // 0xc8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)
    UClass* DamageNumbersClass; // 0xd0 (Size: 0x8, Type: ClassProperty)

public:
    UClass* GetDamageNumbersClass(); // 0x101e7098 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    void SetDamageNumbersClass(const UClass* NewDamageNumbersClass); // 0x101e8344 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UCustomDamageNumbersDataComponent) == 0xd8, "Size mismatch for UCustomDamageNumbersDataComponent");
static_assert(offsetof(UCustomDamageNumbersDataComponent, OnDamageDealt) == 0xb8, "Offset mismatch for UCustomDamageNumbersDataComponent::OnDamageDealt");
static_assert(offsetof(UCustomDamageNumbersDataComponent, Priority) == 0xc8, "Offset mismatch for UCustomDamageNumbersDataComponent::Priority");
static_assert(offsetof(UCustomDamageNumbersDataComponent, DamageNumbersClass) == 0xd0, "Offset mismatch for UCustomDamageNumbersDataComponent::DamageNumbersClass");

// Size: 0x3a0 (Inherited: 0x718, Single: 0xfffffc88)
class UFortUserWidget_DamageNumbers : public UFortUserWidget
{
public:
    UClass* DefaultDamageNumberClass; // 0x2c0 (Size: 0x8, Type: ClassProperty)
    double VerticalShiftForNewDamage; // 0x2c8 (Size: 0x8, Type: DoubleProperty)
    double AccumulationTime; // 0x2d0 (Size: 0x8, Type: DoubleProperty)
    int32_t MaxNumberCount; // 0x2d8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2dc[0x4]; // 0x2dc (Size: 0x4, Type: PaddingProperty)
    FVector OffsetFromPawnLocationDBNO; // 0x2e0 (Size: 0x18, Type: StructProperty)
    FVector OffsetFromPawnLocation; // 0x2f8 (Size: 0x18, Type: StructProperty)
    AFortPlayerPawn* BoundPawn; // 0x310 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag HideDamageNumbersTag; // 0x318 (Size: 0x4, Type: StructProperty)
    FGameplayTag DamageAtLocTag; // 0x31c (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer TagsToNotDisplayDmgNumbersOnSpecificActors; // 0x320 (Size: 0x20, Type: StructProperty)
    UDynamicEntryBox* DynamicEntryBox_Numbers; // 0x340 (Size: 0x8, Type: ObjectProperty)
    TMap<int32_t, UClass*> PoolByClassController; // 0x348 (Size: 0x50, Type: MapProperty)
    FGameplayTag DamageCueEMPTag; // 0x398 (Size: 0x4, Type: StructProperty)
    bool bPrecreateDamageNumberEntries; // 0x39c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39d[0x3]; // 0x39d (Size: 0x3, Type: PaddingProperty)

protected:
    void ClearBinding(); // 0x101e6f74 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void OnDamageDealt(double& InDamage, bool& bInCritical, bool& bInFatal, bool& bInShield, AActor*& HitActor, FVector& HitLocation, FGameplayTagContainer& Tags); // 0x101e79cc (Index: 0x1, Flags: Final|Native|Protected|HasDefaults|BlueprintCallable)
    void OnPawnSet(); // 0x101e8160 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
    void OnShieldBreak(bool& bInOverShield); // 0x101e81c8 (Index: 0x3, Flags: Final|Native|Protected)
    void UpdateBinding(); // 0x101e85d0 (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortUserWidget_DamageNumbers) == 0x3a0, "Size mismatch for UFortUserWidget_DamageNumbers");
static_assert(offsetof(UFortUserWidget_DamageNumbers, DefaultDamageNumberClass) == 0x2c0, "Offset mismatch for UFortUserWidget_DamageNumbers::DefaultDamageNumberClass");
static_assert(offsetof(UFortUserWidget_DamageNumbers, VerticalShiftForNewDamage) == 0x2c8, "Offset mismatch for UFortUserWidget_DamageNumbers::VerticalShiftForNewDamage");
static_assert(offsetof(UFortUserWidget_DamageNumbers, AccumulationTime) == 0x2d0, "Offset mismatch for UFortUserWidget_DamageNumbers::AccumulationTime");
static_assert(offsetof(UFortUserWidget_DamageNumbers, MaxNumberCount) == 0x2d8, "Offset mismatch for UFortUserWidget_DamageNumbers::MaxNumberCount");
static_assert(offsetof(UFortUserWidget_DamageNumbers, OffsetFromPawnLocationDBNO) == 0x2e0, "Offset mismatch for UFortUserWidget_DamageNumbers::OffsetFromPawnLocationDBNO");
static_assert(offsetof(UFortUserWidget_DamageNumbers, OffsetFromPawnLocation) == 0x2f8, "Offset mismatch for UFortUserWidget_DamageNumbers::OffsetFromPawnLocation");
static_assert(offsetof(UFortUserWidget_DamageNumbers, BoundPawn) == 0x310, "Offset mismatch for UFortUserWidget_DamageNumbers::BoundPawn");
static_assert(offsetof(UFortUserWidget_DamageNumbers, HideDamageNumbersTag) == 0x318, "Offset mismatch for UFortUserWidget_DamageNumbers::HideDamageNumbersTag");
static_assert(offsetof(UFortUserWidget_DamageNumbers, DamageAtLocTag) == 0x31c, "Offset mismatch for UFortUserWidget_DamageNumbers::DamageAtLocTag");
static_assert(offsetof(UFortUserWidget_DamageNumbers, TagsToNotDisplayDmgNumbersOnSpecificActors) == 0x320, "Offset mismatch for UFortUserWidget_DamageNumbers::TagsToNotDisplayDmgNumbersOnSpecificActors");
static_assert(offsetof(UFortUserWidget_DamageNumbers, DynamicEntryBox_Numbers) == 0x340, "Offset mismatch for UFortUserWidget_DamageNumbers::DynamicEntryBox_Numbers");
static_assert(offsetof(UFortUserWidget_DamageNumbers, PoolByClassController) == 0x348, "Offset mismatch for UFortUserWidget_DamageNumbers::PoolByClassController");
static_assert(offsetof(UFortUserWidget_DamageNumbers, DamageCueEMPTag) == 0x398, "Offset mismatch for UFortUserWidget_DamageNumbers::DamageCueEMPTag");
static_assert(offsetof(UFortUserWidget_DamageNumbers, bPrecreateDamageNumberEntries) == 0x39c, "Offset mismatch for UFortUserWidget_DamageNumbers::bPrecreateDamageNumberEntries");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UFortGameSettingRegistryExtension_DamageNumbers : public UFortGameSettingRegistryExtension
{
public:
};

static_assert(sizeof(UFortGameSettingRegistryExtension_DamageNumbers) == 0x30, "Size mismatch for UFortGameSettingRegistryExtension_DamageNumbers");

