/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamDecksUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "ModularGameplay.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "ModelViewViewModel.h"
#include "FMJamDecksRuntime.h"
#include "GameplayTags.h"
#include "UMG.h"
#include "DynamicUI.h"
#include "FMJamUI.h"

// Size: 0x3c8 (Inherited: 0xe08, Single: 0xfffff5c0)
class UJamDeckEmitterIndicatorBase : public UFortActorIndicatorWidget
{
public:

public:
    ESlateVisibility SelectVisibilityByPlayerPresenceInArray(const TArray<APlayerController*> Controllers, ESlateVisibility& VisibilityWhenPresent, ESlateVisibility& VisibilityWhenAbsent) const; // 0x11459950 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)

protected:
    virtual void OnNewJamDeckEmitter(AJamDeckEmitter*& PreviousEmitter, AJamDeckEmitter*& NewEmitter); // 0x11459744 (Index: 0x0, Flags: Native|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UJamDeckEmitterIndicatorBase) == 0x3c8, "Size mismatch for UJamDeckEmitterIndicatorBase");

// Size: 0xc8 (Inherited: 0x250, Single: 0xfffffe78)
class UJamDecksControllerComponent_IndicatorsManager : public UControllerComponent
{
public:
    UDynamicUIScene* DynamicUISceneToAdd; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c0[0x8]; // 0xc0 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UJamDecksControllerComponent_IndicatorsManager) == 0xc8, "Size mismatch for UJamDecksControllerComponent_IndicatorsManager");
static_assert(offsetof(UJamDecksControllerComponent_IndicatorsManager, DynamicUISceneToAdd) == 0xb8, "Offset mismatch for UJamDecksControllerComponent_IndicatorsManager::DynamicUISceneToAdd");

// Size: 0x108 (Inherited: 0xe0, Single: 0x28)
class UJamDecksEmitterComponent_IndicatorsProvider : public UActorComponent
{
public:
    TArray<UClass*> WithinPlayspaceIndicators; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> WhileFocusedIndicators; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_d8[0x18]; // 0xd8 (Size: 0x18, Type: PaddingProperty)
    TArray<FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails> PerPlayerData; // 0xf0 (Size: 0x10, Type: ArrayProperty)
    UJamDeckViewModel* JamDeckViewModel; // 0x100 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UJamDecksEmitterComponent_IndicatorsProvider) == 0x108, "Size mismatch for UJamDecksEmitterComponent_IndicatorsProvider");
static_assert(offsetof(UJamDecksEmitterComponent_IndicatorsProvider, WithinPlayspaceIndicators) == 0xb8, "Offset mismatch for UJamDecksEmitterComponent_IndicatorsProvider::WithinPlayspaceIndicators");
static_assert(offsetof(UJamDecksEmitterComponent_IndicatorsProvider, WhileFocusedIndicators) == 0xc8, "Offset mismatch for UJamDecksEmitterComponent_IndicatorsProvider::WhileFocusedIndicators");
static_assert(offsetof(UJamDecksEmitterComponent_IndicatorsProvider, PerPlayerData) == 0xf0, "Offset mismatch for UJamDecksEmitterComponent_IndicatorsProvider::PerPlayerData");
static_assert(offsetof(UJamDecksEmitterComponent_IndicatorsProvider, JamDeckViewModel) == 0x100, "Offset mismatch for UJamDecksEmitterComponent_IndicatorsProvider::JamDeckViewModel");

// Size: 0x140 (Inherited: 0xe0, Single: 0x60)
class UJamDecksGameStateComponent_IndicatorCache : public UActorComponent
{
public:
    FUserWidgetPool WidgetPool; // 0xb8 (Size: 0x88, Type: StructProperty)
};

static_assert(sizeof(UJamDecksGameStateComponent_IndicatorCache) == 0x140, "Size mismatch for UJamDecksGameStateComponent_IndicatorCache");
static_assert(offsetof(UJamDecksGameStateComponent_IndicatorCache, WidgetPool) == 0xb8, "Offset mismatch for UJamDecksGameStateComponent_IndicatorCache::WidgetPool");

// Size: 0x320 (Inherited: 0xa48, Single: 0xfffff8d8)
class UJamDecksIndicatorLayerBase : public UFortHUDElementWidget
{
public:
    UFortActorCanvas* EmitterIndicators; // 0x318 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UJamDecksIndicatorLayerBase) == 0x320, "Size mismatch for UJamDecksIndicatorLayerBase");
static_assert(offsetof(UJamDecksIndicatorLayerBase, EmitterIndicators) == 0x318, "Offset mismatch for UJamDecksIndicatorLayerBase::EmitterIndicators");

// Size: 0xf8 (Inherited: 0xe0, Single: 0x18)
class UJamDecksMusicSlotSelectorComponent : public UActorComponent
{
public:
};

static_assert(sizeof(UJamDecksMusicSlotSelectorComponent) == 0xf8, "Size mismatch for UJamDecksMusicSlotSelectorComponent");

// Size: 0x118 (Inherited: 0x250, Single: 0xfffffec8)
class UJamDecksPickerOverriderComponent : public UControllerComponent
{
public:
};

static_assert(sizeof(UJamDecksPickerOverriderComponent) == 0x118, "Size mismatch for UJamDecksPickerOverriderComponent");

// Size: 0xc0 (Inherited: 0x90, Single: 0x30)
class UJamDeckViewModel : public UMVVMViewModelBase
{
public:
    UJamMusicSlotVM* MusicSlotVM; // 0x68 (Size: 0x8, Type: ObjectProperty)
    FText OwnerName; // 0x70 (Size: 0x10, Type: TextProperty)
    TArray<APlayerController*> FocusingPlayers; // 0x80 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_90[0x30]; // 0x90 (Size: 0x30, Type: PaddingProperty)

public:
    bool HasValidMusicSlotAndOwner() const; // 0x11459720 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UJamDeckViewModel) == 0xc0, "Size mismatch for UJamDeckViewModel");
static_assert(offsetof(UJamDeckViewModel, MusicSlotVM) == 0x68, "Offset mismatch for UJamDeckViewModel::MusicSlotVM");
static_assert(offsetof(UJamDeckViewModel, OwnerName) == 0x70, "Offset mismatch for UJamDeckViewModel::OwnerName");
static_assert(offsetof(UJamDeckViewModel, FocusingPlayers) == 0x80, "Offset mismatch for UJamDeckViewModel::FocusingPlayers");

// Size: 0xc8 (Inherited: 0xf8, Single: 0xffffffd0)
class UQuickJoinButtonBehaviorExtension : public UFortMobileActionButtonBehaviorExtension
{
public:
    FGameplayTagQuery QuickJoinTagQuery; // 0x80 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UQuickJoinButtonBehaviorExtension) == 0xc8, "Size mismatch for UQuickJoinButtonBehaviorExtension");
static_assert(offsetof(UQuickJoinButtonBehaviorExtension, QuickJoinTagQuery) == 0x80, "Offset mismatch for UQuickJoinButtonBehaviorExtension::QuickJoinTagQuery");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails
{
    APlayerController* Player; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<UJamDeckEmitterIndicatorBase*> IndicatorsInUse; // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails) == 0x20, "Size mismatch for FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails");
static_assert(offsetof(FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails, Player) == 0x0, "Offset mismatch for FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails::Player");
static_assert(offsetof(FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails, IndicatorsInUse) == 0x8, "Offset mismatch for FJamDecksEmitterComponent_IndicatorsProviderPlayerDetails::IndicatorsInUse");

