/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DeltaFileSystem
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UDeltaFileSaveHandlerTestContext : public UObject
{
public:
    UDeltaFileSaveHandler* SaveHandler; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDeltaFileSaveHandlerTestContext) == 0x30, "Size mismatch for UDeltaFileSaveHandlerTestContext");
static_assert(offsetof(UDeltaFileSaveHandlerTestContext, SaveHandler) == 0x28, "Offset mismatch for UDeltaFileSaveHandlerTestContext::SaveHandler");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDeltaFile : public UInterface
{
public:
};

static_assert(sizeof(UDeltaFile) == 0x28, "Size mismatch for UDeltaFile");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDeltaFileApplier : public UInterface
{
public:
};

static_assert(sizeof(UDeltaFileApplier) == 0x28, "Size mismatch for UDeltaFileApplier");

// Size: 0xc8 (Inherited: 0xe0, Single: 0xffffffe8)
class UDeltaComponent : public UActorComponent
{
public:
};

static_assert(sizeof(UDeltaComponent) == 0xc8, "Size mismatch for UDeltaComponent");

// Size: 0x120 (Inherited: 0x28, Single: 0xf8)
class UDeltaFileSaveHandler : public UObject
{
public:
};

static_assert(sizeof(UDeltaFileSaveHandler) == 0x120, "Size mismatch for UDeltaFileSaveHandler");

// Size: 0xe8 (Inherited: 0xb8, Single: 0x30)
class UDeltaFileSubsystem : public UEngineSubsystem
{
public:
    TMap<FDeltaTrackingHandles, UWorld*> WorldToTrackingHandles; // 0x30 (Size: 0x50, Type: MapProperty)
    TMap<UObject*, FName> DeltaFiles; // 0x80 (Size: 0x50, Type: MapProperty)
    FSoftClassPath DefaultDeltaFileClass; // 0xd0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UDeltaFileSubsystem) == 0xe8, "Size mismatch for UDeltaFileSubsystem");
static_assert(offsetof(UDeltaFileSubsystem, WorldToTrackingHandles) == 0x30, "Offset mismatch for UDeltaFileSubsystem::WorldToTrackingHandles");
static_assert(offsetof(UDeltaFileSubsystem, DeltaFiles) == 0x80, "Offset mismatch for UDeltaFileSubsystem::DeltaFiles");
static_assert(offsetof(UDeltaFileSubsystem, DefaultDeltaFileClass) == 0xd0, "Offset mismatch for UDeltaFileSubsystem::DefaultDeltaFileClass");

// Size: 0xf0 (Inherited: 0x28, Single: 0xc8)
class UMapDelta : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FString PackageToApplyTo; // 0x30 (Size: 0x10, Type: StrProperty)
    TMap<FAddAction, FGuid> AddActions; // 0x40 (Size: 0x50, Type: MapProperty)
    TArray<FUpdateAction> UpdateActions; // 0x90 (Size: 0x10, Type: ArrayProperty)
    TMap<FDeleteAction, FGuid> DeleteActions; // 0xa0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UMapDelta) == 0xf0, "Size mismatch for UMapDelta");
static_assert(offsetof(UMapDelta, PackageToApplyTo) == 0x30, "Offset mismatch for UMapDelta::PackageToApplyTo");
static_assert(offsetof(UMapDelta, AddActions) == 0x40, "Offset mismatch for UMapDelta::AddActions");
static_assert(offsetof(UMapDelta, UpdateActions) == 0x90, "Offset mismatch for UMapDelta::UpdateActions");
static_assert(offsetof(UMapDelta, DeleteActions) == 0xa0, "Offset mismatch for UMapDelta::DeleteActions");

// Size: 0xf0 (Inherited: 0x28, Single: 0xc8)
class UMapDeltaApplier : public UObject
{
public:
};

static_assert(sizeof(UMapDeltaApplier) == 0xf0, "Size mismatch for UMapDeltaApplier");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDeltaAction
{
    FGuid ActorGuid; // 0x0 (Size: 0x10, Type: StructProperty)
    FDateTime CommitTime; // 0x10 (Size: 0x8, Type: StructProperty)
    uint32_t DataHash; // 0x18 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDeltaAction) == 0x20, "Size mismatch for FDeltaAction");
static_assert(offsetof(FDeltaAction, ActorGuid) == 0x0, "Offset mismatch for FDeltaAction::ActorGuid");
static_assert(offsetof(FDeltaAction, CommitTime) == 0x10, "Offset mismatch for FDeltaAction::CommitTime");
static_assert(offsetof(FDeltaAction, DataHash) == 0x18, "Offset mismatch for FDeltaAction::DataHash");

// Size: 0xb0 (Inherited: 0x20, Single: 0x90)
struct FAddAction : FDeltaAction
{
    TSoftClassPtr ActorClass; // 0x20 (Size: 0x20, Type: SoftClassProperty)
    FString JsonStringObjectForPropertyData; // 0x40 (Size: 0x10, Type: StrProperty)
    FTransform Transform; // 0x50 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FAddAction) == 0xb0, "Size mismatch for FAddAction");
static_assert(offsetof(FAddAction, ActorClass) == 0x20, "Offset mismatch for FAddAction::ActorClass");
static_assert(offsetof(FAddAction, JsonStringObjectForPropertyData) == 0x40, "Offset mismatch for FAddAction::JsonStringObjectForPropertyData");
static_assert(offsetof(FAddAction, Transform) == 0x50, "Offset mismatch for FAddAction::Transform");

// Size: 0x30 (Inherited: 0x20, Single: 0x10)
struct FUpdateAction : FDeltaAction
{
    FString JsonStringObjectForPropertyData; // 0x20 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FUpdateAction) == 0x30, "Size mismatch for FUpdateAction");
static_assert(offsetof(FUpdateAction, JsonStringObjectForPropertyData) == 0x20, "Offset mismatch for FUpdateAction::JsonStringObjectForPropertyData");

// Size: 0x90 (Inherited: 0x20, Single: 0x70)
struct FDeleteAction : FDeltaAction
{
    FString ActorName; // 0x20 (Size: 0x10, Type: StrProperty)
    FTransform Transform; // 0x30 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FDeleteAction) == 0x90, "Size mismatch for FDeleteAction");
static_assert(offsetof(FDeleteAction, ActorName) == 0x20, "Offset mismatch for FDeleteAction::ActorName");
static_assert(offsetof(FDeleteAction, Transform) == 0x30, "Offset mismatch for FDeleteAction::Transform");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FDeltaTrackingHandles
{
};

static_assert(sizeof(FDeltaTrackingHandles) == 0x40, "Size mismatch for FDeltaTrackingHandles");

