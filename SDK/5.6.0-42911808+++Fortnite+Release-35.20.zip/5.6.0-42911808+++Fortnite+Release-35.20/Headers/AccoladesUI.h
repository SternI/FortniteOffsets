/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AccoladesUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "CommonUI.h"
#include "UMG.h"
#include "AccoladesRuntime.h"
#include "FortniteGame.h"
#include "Engine.h"

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UAthenaAccoladeWrapper : public UObject
{
public:
    FName AccoladeRowName; // 0x28 (Size: 0x4, Type: NameProperty)
    FFortAccoladeSessionData AccoladeData; // 0x2c (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(UAthenaAccoladeWrapper) == 0x38, "Size mismatch for UAthenaAccoladeWrapper");
static_assert(offsetof(UAthenaAccoladeWrapper, AccoladeRowName) == 0x28, "Offset mismatch for UAthenaAccoladeWrapper::AccoladeRowName");
static_assert(offsetof(UAthenaAccoladeWrapper, AccoladeData) == 0x2c, "Offset mismatch for UAthenaAccoladeWrapper::AccoladeData");

// Size: 0x2e0 (Inherited: 0x730, Single: 0xfffffbb0)
class UAthenaAccoladeListEntryWidget : public UCommonUserWidget
{
public:

protected:
    virtual void SetCount(int32_t& Count); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintCallable|BlueprintEvent)
    virtual void SetIcon(UFortAccoladeItemDefinition*& const ItemDef); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintCallable|BlueprintEvent)
    virtual void SetIconImage(const TSoftObjectPtr<UTexture2D*> IconImage, EFortAccoladeType& const AccoladeType, EFortAccoladeTierType& const AccoladeTier); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void SetJustCompleted(bool& const bJustCompleted); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintCallable|BlueprintEvent)
    virtual void SetSource(const FText SourceText); // 0x288a61c (Index: 0x4, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void SetTitle(const FText TitleText); // 0x288a61c (Index: 0x5, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UAthenaAccoladeListEntryWidget) == 0x2e0, "Size mismatch for UAthenaAccoladeListEntryWidget");

// Size: 0xb60 (Inherited: 0x1af8, Single: 0xfffff068)
class UAthenaAccoladeListWidget : public UCommonListView
{
public:

public:
    void PopulateWidget(); // 0xfe6b9fc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAthenaAccoladeListWidget) == 0xb60, "Size mismatch for UAthenaAccoladeListWidget");

