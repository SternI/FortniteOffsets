/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommonUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "UMG.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "EnhancedInput.h"
#include "SlateCore.h"
#include "InputCore.h"
#include "CommonInput.h"
#include "Slate.h"
#include "MediaAssets.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCommonBoundActionButtonInterface : public UInterface
{
public:
};

static_assert(sizeof(UCommonBoundActionButtonInterface) == 0x28, "Size mismatch for UCommonBoundActionButtonInterface");

// Size: 0x660 (Inherited: 0x7e8, Single: 0xfffffe78)
class UAnalogSlider : public USlider
{
public:
    uint8_t OnAnalogCapture[0x10]; // 0x640 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_650[0x10]; // 0x650 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UAnalogSlider) == 0x660, "Size mismatch for UAnalogSlider");
static_assert(offsetof(UAnalogSlider, OnAnalogCapture) == 0x640, "Offset mismatch for UAnalogSlider::OnAnalogCapture");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCommonActionHandlerInterface : public UInterface
{
public:
};

static_assert(sizeof(UCommonActionHandlerInterface) == 0x28, "Size mismatch for UCommonActionHandlerInterface");

// Size: 0x420 (Inherited: 0x1a8, Single: 0x278)
class UCommonActionWidget : public UWidget
{
public:
    uint8_t OnInputMethodChanged[0x10]; // 0x158 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInputIconUpdated[0x10]; // 0x168 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_178[0x8]; // 0x178 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush ProgressMaterialBrush; // 0x180 (Size: 0xb0, Type: StructProperty)
    FName ProgressMaterialParam; // 0x230 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_234[0xc]; // 0x234 (Size: 0xc, Type: PaddingProperty)
    FSlateBrush IconRimBrush; // 0x240 (Size: 0xb0, Type: StructProperty)
    TArray<FDataTableRowHandle> InputActions; // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    UInputAction* EnhancedInputAction; // 0x300 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_308[0x8]; // 0x308 (Size: 0x8, Type: PaddingProperty)
    UMaterialInstanceDynamic* ProgressDynamicMaterial; // 0x310 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_318[0x48]; // 0x318 (Size: 0x48, Type: PaddingProperty)
    FSlateBrush Icon; // 0x360 (Size: 0xb0, Type: StructProperty)
    uint8_t Pad_410[0x10]; // 0x410 (Size: 0x10, Type: PaddingProperty)

public:
    FText GetDisplayText() const; // 0x4c4f7b4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UInputAction* GetEnhancedInputAction() const; // 0x55e1948 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FSlateBrush GetIcon() const; // 0x4d728f0 (Index: 0x2, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMaterialInstanceDynamic* GetIconDynamicMaterial(); // 0x4d1a190 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    bool IsHeldAction() const; // 0x4a7d4dc (Index: 0x4, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnInputIconUpdated__DelegateSignature(); // 0x288a61c (Index: 0x6, Flags: MulticastDelegate|Public|Delegate)
    void OnInputMethodChanged__DelegateSignature(bool& bUsingGamepad); // 0x288a61c (Index: 0x7, Flags: MulticastDelegate|Public|Delegate)
    void SetEnhancedInputAction(UInputAction*& InInputAction); // 0xb4ac798 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void SetIconRimBrush(FSlateBrush& InIconRimBrush); // 0x55cfe98 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void SetInputAction(FDataTableRowHandle& InputActionRow); // 0x52e45ec (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void SetInputActionBinding(FUIActionBindingHandle& BindingHandle); // 0xb4acd84 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void SetInputActions(TArray<FDataTableRowHandle>& NewInputActions); // 0xb4acff8 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnEnhancedInputMappingsRebuilt(); // 0x4d10500 (Index: 0x5, Flags: Final|Native|Protected)
};

static_assert(sizeof(UCommonActionWidget) == 0x420, "Size mismatch for UCommonActionWidget");
static_assert(offsetof(UCommonActionWidget, OnInputMethodChanged) == 0x158, "Offset mismatch for UCommonActionWidget::OnInputMethodChanged");
static_assert(offsetof(UCommonActionWidget, OnInputIconUpdated) == 0x168, "Offset mismatch for UCommonActionWidget::OnInputIconUpdated");
static_assert(offsetof(UCommonActionWidget, ProgressMaterialBrush) == 0x180, "Offset mismatch for UCommonActionWidget::ProgressMaterialBrush");
static_assert(offsetof(UCommonActionWidget, ProgressMaterialParam) == 0x230, "Offset mismatch for UCommonActionWidget::ProgressMaterialParam");
static_assert(offsetof(UCommonActionWidget, IconRimBrush) == 0x240, "Offset mismatch for UCommonActionWidget::IconRimBrush");
static_assert(offsetof(UCommonActionWidget, InputActions) == 0x2f0, "Offset mismatch for UCommonActionWidget::InputActions");
static_assert(offsetof(UCommonActionWidget, EnhancedInputAction) == 0x300, "Offset mismatch for UCommonActionWidget::EnhancedInputAction");
static_assert(offsetof(UCommonActionWidget, ProgressDynamicMaterial) == 0x310, "Offset mismatch for UCommonActionWidget::ProgressDynamicMaterial");
static_assert(offsetof(UCommonActionWidget, Icon) == 0x360, "Offset mismatch for UCommonActionWidget::Icon");

// Size: 0x408 (Inherited: 0x730, Single: 0xfffffcd8)
class UCommonActivatableWidget : public UCommonUserWidget
{
public:
    bool bIsBackHandler; // 0x2d8 (Size: 0x1, Type: BoolProperty)
    bool bIsBackActionDisplayedInActionBar; // 0x2d9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2da[0x6]; // 0x2da (Size: 0x6, Type: PaddingProperty)
    FText OverrideBackActionDisplayName; // 0x2e0 (Size: 0x10, Type: TextProperty)
    bool bAutoActivate; // 0x2f0 (Size: 0x1, Type: BoolProperty)
    bool bSupportsActivationFocus; // 0x2f1 (Size: 0x1, Type: BoolProperty)
    bool bIsModal; // 0x2f2 (Size: 0x1, Type: BoolProperty)
    bool bAutoRestoreFocus; // 0x2f3 (Size: 0x1, Type: BoolProperty)
    bool bOverrideActionDomain; // 0x2f4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2f5[0x3]; // 0x2f5 (Size: 0x3, Type: PaddingProperty)
    UInputMappingContext* InputMapping; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    int32_t InputMappingPriority; // 0x300 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_304[0x4]; // 0x304 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UCommonInputActionDomain*> ActionDomainOverride; // 0x308 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t BP_OnWidgetActivated[0x10]; // 0x328 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t BP_OnWidgetDeactivated[0x10]; // 0x338 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bIsActive; // 0x348 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_349[0x7]; // 0x349 (Size: 0x7, Type: PaddingProperty)
    TArray<TWeakObjectPtr<UCommonActivatableWidget*>> VisibilityBoundWidgets; // 0x350 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_360[0xa0]; // 0x360 (Size: 0xa0, Type: PaddingProperty)
    bool bSetVisibilityOnActivated; // 0x400 (Size: 0x1, Type: BoolProperty)
    uint8_t ActivatedVisibility; // 0x401 (Size: 0x1, Type: EnumProperty)
    bool bSetVisibilityOnDeactivated; // 0x402 (Size: 0x1, Type: BoolProperty)
    uint8_t DeactivatedVisibility; // 0x403 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_404[0x4]; // 0x404 (Size: 0x4, Type: PaddingProperty)

public:
    void ActivateWidget(); // 0x4297460 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void BindVisibilityToActivation(UCommonActivatableWidget*& ActivatableWidget); // 0xb4a5e04 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void ClearFocusRestorationTarget(); // 0xb4a6300 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void DeactivateWidget(); // 0x58f6d9c (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    UWidget* GetDesiredFocusTarget() const; // 0x302ce28 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsActivated() const; // 0x57984a4 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetBindVisibilities(ESlateVisibility& OnActivatedVisibility, ESlateVisibility& OnDeactivatedVisibility, bool& bInAllActive); // 0xb4ab464 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual UWidget* BP_GetDesiredFocusTarget() const; // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent|Const)
    virtual FUIInputConfig BP_GetDesiredInputConfig() const; // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent|Const)
    virtual void BP_OnActivated(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDeactivated(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual bool BP_OnHandleBackAction(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    void RequestRefreshFocus(); // 0x5e6c3f4 (Index: 0xb, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UCommonActivatableWidget) == 0x408, "Size mismatch for UCommonActivatableWidget");
static_assert(offsetof(UCommonActivatableWidget, bIsBackHandler) == 0x2d8, "Offset mismatch for UCommonActivatableWidget::bIsBackHandler");
static_assert(offsetof(UCommonActivatableWidget, bIsBackActionDisplayedInActionBar) == 0x2d9, "Offset mismatch for UCommonActivatableWidget::bIsBackActionDisplayedInActionBar");
static_assert(offsetof(UCommonActivatableWidget, OverrideBackActionDisplayName) == 0x2e0, "Offset mismatch for UCommonActivatableWidget::OverrideBackActionDisplayName");
static_assert(offsetof(UCommonActivatableWidget, bAutoActivate) == 0x2f0, "Offset mismatch for UCommonActivatableWidget::bAutoActivate");
static_assert(offsetof(UCommonActivatableWidget, bSupportsActivationFocus) == 0x2f1, "Offset mismatch for UCommonActivatableWidget::bSupportsActivationFocus");
static_assert(offsetof(UCommonActivatableWidget, bIsModal) == 0x2f2, "Offset mismatch for UCommonActivatableWidget::bIsModal");
static_assert(offsetof(UCommonActivatableWidget, bAutoRestoreFocus) == 0x2f3, "Offset mismatch for UCommonActivatableWidget::bAutoRestoreFocus");
static_assert(offsetof(UCommonActivatableWidget, bOverrideActionDomain) == 0x2f4, "Offset mismatch for UCommonActivatableWidget::bOverrideActionDomain");
static_assert(offsetof(UCommonActivatableWidget, InputMapping) == 0x2f8, "Offset mismatch for UCommonActivatableWidget::InputMapping");
static_assert(offsetof(UCommonActivatableWidget, InputMappingPriority) == 0x300, "Offset mismatch for UCommonActivatableWidget::InputMappingPriority");
static_assert(offsetof(UCommonActivatableWidget, ActionDomainOverride) == 0x308, "Offset mismatch for UCommonActivatableWidget::ActionDomainOverride");
static_assert(offsetof(UCommonActivatableWidget, BP_OnWidgetActivated) == 0x328, "Offset mismatch for UCommonActivatableWidget::BP_OnWidgetActivated");
static_assert(offsetof(UCommonActivatableWidget, BP_OnWidgetDeactivated) == 0x338, "Offset mismatch for UCommonActivatableWidget::BP_OnWidgetDeactivated");
static_assert(offsetof(UCommonActivatableWidget, bIsActive) == 0x348, "Offset mismatch for UCommonActivatableWidget::bIsActive");
static_assert(offsetof(UCommonActivatableWidget, VisibilityBoundWidgets) == 0x350, "Offset mismatch for UCommonActivatableWidget::VisibilityBoundWidgets");
static_assert(offsetof(UCommonActivatableWidget, bSetVisibilityOnActivated) == 0x400, "Offset mismatch for UCommonActivatableWidget::bSetVisibilityOnActivated");
static_assert(offsetof(UCommonActivatableWidget, ActivatedVisibility) == 0x401, "Offset mismatch for UCommonActivatableWidget::ActivatedVisibility");
static_assert(offsetof(UCommonActivatableWidget, bSetVisibilityOnDeactivated) == 0x402, "Offset mismatch for UCommonActivatableWidget::bSetVisibilityOnDeactivated");
static_assert(offsetof(UCommonActivatableWidget, DeactivatedVisibility) == 0x403, "Offset mismatch for UCommonActivatableWidget::DeactivatedVisibility");

// Size: 0x2d8 (Inherited: 0x458, Single: 0xfffffe80)
class UCommonUserWidget : public UUserWidget
{
public:
    bool bDisplayInActionBar; // 0x2b0 (Size: 0x1, Type: BoolProperty)
    bool bConsumePointerInput; // 0x2b1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b2[0x26]; // 0x2b2 (Size: 0x26, Type: PaddingProperty)

public:
    void RegisterScrollRecipientExternal(UWidget*& const AnalogScrollRecipient); // 0xb4aa304 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetConsumePointerInput(bool& bInConsumePointerInput); // 0xb4ac248 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void UnregisterScrollRecipientExternal(UWidget*& const AnalogScrollRecipient); // 0xb4b1478 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonUserWidget) == 0x2d8, "Size mismatch for UCommonUserWidget");
static_assert(offsetof(UCommonUserWidget, bDisplayInActionBar) == 0x2b0, "Offset mismatch for UCommonUserWidget::bDisplayInActionBar");
static_assert(offsetof(UCommonUserWidget, bConsumePointerInput) == 0x2b1, "Offset mismatch for UCommonUserWidget::bConsumePointerInput");

// Size: 0x220 (Inherited: 0x6b0, Single: 0xfffffb70)
class UCommonActivatableWidgetSwitcher : public UCommonAnimatedSwitcher
{
public:
    bool bClearFocusRestorationTargetOfDeactivatedWidgets; // 0x210 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_211[0xf]; // 0x211 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(UCommonActivatableWidgetSwitcher) == 0x220, "Size mismatch for UCommonActivatableWidgetSwitcher");
static_assert(offsetof(UCommonActivatableWidgetSwitcher, bClearFocusRestorationTargetOfDeactivatedWidgets) == 0x210, "Offset mismatch for UCommonActivatableWidgetSwitcher::bClearFocusRestorationTargetOfDeactivatedWidgets");

// Size: 0x210 (Inherited: 0x4a0, Single: 0xfffffd70)
class UCommonAnimatedSwitcher : public UWidgetSwitcher
{
public:
    uint8_t Pad_188[0x30]; // 0x188 (Size: 0x30, Type: PaddingProperty)
    uint8_t OnActiveWidgetIndexChangedBP[0x10]; // 0x1b8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t TransitionType; // 0x1c8 (Size: 0x1, Type: EnumProperty)
    uint8_t TransitionCurveType; // 0x1c9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1ca[0x2]; // 0x1ca (Size: 0x2, Type: PaddingProperty)
    float TransitionDuration; // 0x1cc (Size: 0x4, Type: FloatProperty)
    uint8_t TransitionFallbackStrategy; // 0x1d0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1d1[0x3f]; // 0x1d1 (Size: 0x3f, Type: PaddingProperty)

public:
    void ActivateNextWidget(bool& bCanWrap); // 0xb4a5014 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void ActivatePreviousWidget(bool& bCanWrap); // 0xb4a5140 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    bool HasWidgets() const; // 0x519a274 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsCurrentlySwitching() const; // 0xb4a9514 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsTransitionPlaying() const; // 0xb4a972c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetDisableTransitionAnimation(bool& bDisableAnimation); // 0xb4ac66c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonAnimatedSwitcher) == 0x210, "Size mismatch for UCommonAnimatedSwitcher");
static_assert(offsetof(UCommonAnimatedSwitcher, OnActiveWidgetIndexChangedBP) == 0x1b8, "Offset mismatch for UCommonAnimatedSwitcher::OnActiveWidgetIndexChangedBP");
static_assert(offsetof(UCommonAnimatedSwitcher, TransitionType) == 0x1c8, "Offset mismatch for UCommonAnimatedSwitcher::TransitionType");
static_assert(offsetof(UCommonAnimatedSwitcher, TransitionCurveType) == 0x1c9, "Offset mismatch for UCommonAnimatedSwitcher::TransitionCurveType");
static_assert(offsetof(UCommonAnimatedSwitcher, TransitionDuration) == 0x1cc, "Offset mismatch for UCommonAnimatedSwitcher::TransitionDuration");
static_assert(offsetof(UCommonAnimatedSwitcher, TransitionFallbackStrategy) == 0x1d0, "Offset mismatch for UCommonAnimatedSwitcher::TransitionFallbackStrategy");

// Size: 0xe0 (Inherited: 0x28, Single: 0xb8)
class UCommonBorderStyle : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush Background; // 0x30 (Size: 0xb0, Type: StructProperty)

public:
    void GetBackgroundBrush(FSlateBrush& Brush) const; // 0xb4a692c (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UCommonBorderStyle) == 0xe0, "Size mismatch for UCommonBorderStyle");
static_assert(offsetof(UCommonBorderStyle, Background) == 0x30, "Offset mismatch for UCommonBorderStyle::Background");

// Size: 0x2f0 (Inherited: 0x758, Single: 0xfffffb98)
class UCommonBorder : public UBorder
{
public:
    UClass* Style; // 0x2d0 (Size: 0x8, Type: ClassProperty)
    bool bReducePaddingBySafezone; // 0x2d8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d9[0x3]; // 0x2d9 (Size: 0x3, Type: PaddingProperty)
    FMargin MinimumPadding; // 0x2dc (Size: 0x10, Type: StructProperty)
    uint8_t Pad_2ec[0x4]; // 0x2ec (Size: 0x4, Type: PaddingProperty)

public:
    void SetStyle(UClass*& InStyle); // 0xb4b0704 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonBorder) == 0x2f0, "Size mismatch for UCommonBorder");
static_assert(offsetof(UCommonBorder, Style) == 0x2d0, "Offset mismatch for UCommonBorder::Style");
static_assert(offsetof(UCommonBorder, bReducePaddingBySafezone) == 0x2d8, "Offset mismatch for UCommonBorder::bReducePaddingBySafezone");
static_assert(offsetof(UCommonBorder, MinimumPadding) == 0x2dc, "Offset mismatch for UCommonBorder::MinimumPadding");

// Size: 0x710 (Inherited: 0x28, Single: 0x6e8)
class UCommonButtonStyle : public UObject
{
public:
    bool bSingleMaterial; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    FSlateBrush SingleMaterialBrush; // 0x30 (Size: 0xb0, Type: StructProperty)
    FSlateBrush NormalBase; // 0xe0 (Size: 0xb0, Type: StructProperty)
    FSlateBrush NormalHovered; // 0x190 (Size: 0xb0, Type: StructProperty)
    FSlateBrush NormalPressed; // 0x240 (Size: 0xb0, Type: StructProperty)
    FSlateBrush SelectedBase; // 0x2f0 (Size: 0xb0, Type: StructProperty)
    FSlateBrush SelectedHovered; // 0x3a0 (Size: 0xb0, Type: StructProperty)
    FSlateBrush SelectedPressed; // 0x450 (Size: 0xb0, Type: StructProperty)
    FSlateBrush Disabled; // 0x500 (Size: 0xb0, Type: StructProperty)
    FMargin ButtonPadding; // 0x5b0 (Size: 0x10, Type: StructProperty)
    FMargin CustomPadding; // 0x5c0 (Size: 0x10, Type: StructProperty)
    int32_t MinWidth; // 0x5d0 (Size: 0x4, Type: IntProperty)
    int32_t MinHeight; // 0x5d4 (Size: 0x4, Type: IntProperty)
    int32_t MaxWidth; // 0x5d8 (Size: 0x4, Type: IntProperty)
    int32_t MaxHeight; // 0x5dc (Size: 0x4, Type: IntProperty)
    UClass* NormalTextStyle; // 0x5e0 (Size: 0x8, Type: ClassProperty)
    UClass* NormalHoveredTextStyle; // 0x5e8 (Size: 0x8, Type: ClassProperty)
    UClass* SelectedTextStyle; // 0x5f0 (Size: 0x8, Type: ClassProperty)
    UClass* SelectedHoveredTextStyle; // 0x5f8 (Size: 0x8, Type: ClassProperty)
    UClass* DisabledTextStyle; // 0x600 (Size: 0x8, Type: ClassProperty)
    FSlateSound PressedSlateSound; // 0x608 (Size: 0x18, Type: StructProperty)
    FSlateSound ClickedSlateSound; // 0x620 (Size: 0x18, Type: StructProperty)
    FCommonButtonStyleOptionalSlateSound SelectedPressedSlateSound; // 0x638 (Size: 0x20, Type: StructProperty)
    FCommonButtonStyleOptionalSlateSound SelectedClickedSlateSound; // 0x658 (Size: 0x20, Type: StructProperty)
    FCommonButtonStyleOptionalSlateSound LockedPressedSlateSound; // 0x678 (Size: 0x20, Type: StructProperty)
    FCommonButtonStyleOptionalSlateSound LockedClickedSlateSound; // 0x698 (Size: 0x20, Type: StructProperty)
    FSlateSound HoveredSlateSound; // 0x6b8 (Size: 0x18, Type: StructProperty)
    FCommonButtonStyleOptionalSlateSound SelectedHoveredSlateSound; // 0x6d0 (Size: 0x20, Type: StructProperty)
    FCommonButtonStyleOptionalSlateSound LockedHoveredSlateSound; // 0x6f0 (Size: 0x20, Type: StructProperty)

public:
    void GetButtonPadding(FMargin& OutButtonPadding) const; // 0xb4a6b78 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetCustomPadding(FMargin& OutCustomPadding) const; // 0xb4a6f54 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetDisabledBrush(FSlateBrush& Brush) const; // 0xb4a7028 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UCommonTextStyle* GetDisabledTextStyle() const; // 0xb4a7128 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetMaterialBrush(FSlateBrush& Brush) const; // 0xb4a692c (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetNormalBaseBrush(FSlateBrush& Brush) const; // 0xb4a7804 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetNormalHoveredBrush(FSlateBrush& Brush) const; // 0xb4a7904 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UCommonTextStyle* GetNormalHoveredTextStyle() const; // 0xb4a7a04 (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetNormalPressedBrush(FSlateBrush& Brush) const; // 0xb4a7a28 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UCommonTextStyle* GetNormalTextStyle() const; // 0xb4a7b28 (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetSelectedBaseBrush(FSlateBrush& Brush) const; // 0xb4a7c08 (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetSelectedHoveredBrush(FSlateBrush& Brush) const; // 0xb4a7d2c (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UCommonTextStyle* GetSelectedHoveredTextStyle() const; // 0xb4a7e2c (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetSelectedPressedBrush(FSlateBrush& Brush) const; // 0xb4a7e68 (Index: 0xd, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UCommonTextStyle* GetSelectedTextStyle() const; // 0xb4a7fa4 (Index: 0xe, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UCommonButtonStyle) == 0x710, "Size mismatch for UCommonButtonStyle");
static_assert(offsetof(UCommonButtonStyle, bSingleMaterial) == 0x28, "Offset mismatch for UCommonButtonStyle::bSingleMaterial");
static_assert(offsetof(UCommonButtonStyle, SingleMaterialBrush) == 0x30, "Offset mismatch for UCommonButtonStyle::SingleMaterialBrush");
static_assert(offsetof(UCommonButtonStyle, NormalBase) == 0xe0, "Offset mismatch for UCommonButtonStyle::NormalBase");
static_assert(offsetof(UCommonButtonStyle, NormalHovered) == 0x190, "Offset mismatch for UCommonButtonStyle::NormalHovered");
static_assert(offsetof(UCommonButtonStyle, NormalPressed) == 0x240, "Offset mismatch for UCommonButtonStyle::NormalPressed");
static_assert(offsetof(UCommonButtonStyle, SelectedBase) == 0x2f0, "Offset mismatch for UCommonButtonStyle::SelectedBase");
static_assert(offsetof(UCommonButtonStyle, SelectedHovered) == 0x3a0, "Offset mismatch for UCommonButtonStyle::SelectedHovered");
static_assert(offsetof(UCommonButtonStyle, SelectedPressed) == 0x450, "Offset mismatch for UCommonButtonStyle::SelectedPressed");
static_assert(offsetof(UCommonButtonStyle, Disabled) == 0x500, "Offset mismatch for UCommonButtonStyle::Disabled");
static_assert(offsetof(UCommonButtonStyle, ButtonPadding) == 0x5b0, "Offset mismatch for UCommonButtonStyle::ButtonPadding");
static_assert(offsetof(UCommonButtonStyle, CustomPadding) == 0x5c0, "Offset mismatch for UCommonButtonStyle::CustomPadding");
static_assert(offsetof(UCommonButtonStyle, MinWidth) == 0x5d0, "Offset mismatch for UCommonButtonStyle::MinWidth");
static_assert(offsetof(UCommonButtonStyle, MinHeight) == 0x5d4, "Offset mismatch for UCommonButtonStyle::MinHeight");
static_assert(offsetof(UCommonButtonStyle, MaxWidth) == 0x5d8, "Offset mismatch for UCommonButtonStyle::MaxWidth");
static_assert(offsetof(UCommonButtonStyle, MaxHeight) == 0x5dc, "Offset mismatch for UCommonButtonStyle::MaxHeight");
static_assert(offsetof(UCommonButtonStyle, NormalTextStyle) == 0x5e0, "Offset mismatch for UCommonButtonStyle::NormalTextStyle");
static_assert(offsetof(UCommonButtonStyle, NormalHoveredTextStyle) == 0x5e8, "Offset mismatch for UCommonButtonStyle::NormalHoveredTextStyle");
static_assert(offsetof(UCommonButtonStyle, SelectedTextStyle) == 0x5f0, "Offset mismatch for UCommonButtonStyle::SelectedTextStyle");
static_assert(offsetof(UCommonButtonStyle, SelectedHoveredTextStyle) == 0x5f8, "Offset mismatch for UCommonButtonStyle::SelectedHoveredTextStyle");
static_assert(offsetof(UCommonButtonStyle, DisabledTextStyle) == 0x600, "Offset mismatch for UCommonButtonStyle::DisabledTextStyle");
static_assert(offsetof(UCommonButtonStyle, PressedSlateSound) == 0x608, "Offset mismatch for UCommonButtonStyle::PressedSlateSound");
static_assert(offsetof(UCommonButtonStyle, ClickedSlateSound) == 0x620, "Offset mismatch for UCommonButtonStyle::ClickedSlateSound");
static_assert(offsetof(UCommonButtonStyle, SelectedPressedSlateSound) == 0x638, "Offset mismatch for UCommonButtonStyle::SelectedPressedSlateSound");
static_assert(offsetof(UCommonButtonStyle, SelectedClickedSlateSound) == 0x658, "Offset mismatch for UCommonButtonStyle::SelectedClickedSlateSound");
static_assert(offsetof(UCommonButtonStyle, LockedPressedSlateSound) == 0x678, "Offset mismatch for UCommonButtonStyle::LockedPressedSlateSound");
static_assert(offsetof(UCommonButtonStyle, LockedClickedSlateSound) == 0x698, "Offset mismatch for UCommonButtonStyle::LockedClickedSlateSound");
static_assert(offsetof(UCommonButtonStyle, HoveredSlateSound) == 0x6b8, "Offset mismatch for UCommonButtonStyle::HoveredSlateSound");
static_assert(offsetof(UCommonButtonStyle, SelectedHoveredSlateSound) == 0x6d0, "Offset mismatch for UCommonButtonStyle::SelectedHoveredSlateSound");
static_assert(offsetof(UCommonButtonStyle, LockedHoveredSlateSound) == 0x6f0, "Offset mismatch for UCommonButtonStyle::LockedHoveredSlateSound");

// Size: 0x600 (Inherited: 0xa18, Single: 0xfffffbe8)
class UCommonButtonInternalBase : public UButton
{
public:
    uint8_t Pad_590[0x8]; // 0x590 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnDoubleClicked[0x10]; // 0x598 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_5a8[0x20]; // 0x5a8 (Size: 0x20, Type: PaddingProperty)
    int32_t MinWidth; // 0x5c8 (Size: 0x4, Type: IntProperty)
    int32_t MinHeight; // 0x5cc (Size: 0x4, Type: IntProperty)
    int32_t MaxWidth; // 0x5d0 (Size: 0x4, Type: IntProperty)
    int32_t MaxHeight; // 0x5d4 (Size: 0x4, Type: IntProperty)
    bool bButtonEnabled; // 0x5d8 (Size: 0x1, Type: BoolProperty)
    bool bInteractionEnabled; // 0x5d9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5da[0x26]; // 0x5da (Size: 0x26, Type: PaddingProperty)
};

static_assert(sizeof(UCommonButtonInternalBase) == 0x600, "Size mismatch for UCommonButtonInternalBase");
static_assert(offsetof(UCommonButtonInternalBase, OnDoubleClicked) == 0x598, "Offset mismatch for UCommonButtonInternalBase::OnDoubleClicked");
static_assert(offsetof(UCommonButtonInternalBase, MinWidth) == 0x5c8, "Offset mismatch for UCommonButtonInternalBase::MinWidth");
static_assert(offsetof(UCommonButtonInternalBase, MinHeight) == 0x5cc, "Offset mismatch for UCommonButtonInternalBase::MinHeight");
static_assert(offsetof(UCommonButtonInternalBase, MaxWidth) == 0x5d0, "Offset mismatch for UCommonButtonInternalBase::MaxWidth");
static_assert(offsetof(UCommonButtonInternalBase, MaxHeight) == 0x5d4, "Offset mismatch for UCommonButtonInternalBase::MaxHeight");
static_assert(offsetof(UCommonButtonInternalBase, bButtonEnabled) == 0x5d8, "Offset mismatch for UCommonButtonInternalBase::bButtonEnabled");
static_assert(offsetof(UCommonButtonInternalBase, bInteractionEnabled) == 0x5d9, "Offset mismatch for UCommonButtonInternalBase::bInteractionEnabled");

// Size: 0x14a0 (Inherited: 0x730, Single: 0xd70)
class UCommonButtonBase : public UCommonUserWidget
{
public:
    FWidgetEventField ClickEvent; // 0x2d8 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_2d9[0x3]; // 0x2d9 (Size: 0x3, Type: PaddingProperty)
    int32_t MinWidth; // 0x2dc (Size: 0x4, Type: IntProperty)
    int32_t MinHeight; // 0x2e0 (Size: 0x4, Type: IntProperty)
    int32_t MaxWidth; // 0x2e4 (Size: 0x4, Type: IntProperty)
    int32_t MaxHeight; // 0x2e8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2ec[0x4]; // 0x2ec (Size: 0x4, Type: PaddingProperty)
    UClass* Style; // 0x2f0 (Size: 0x8, Type: ClassProperty)
    bool bHideInputAction; // 0x2f8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2f9[0x7]; // 0x2f9 (Size: 0x7, Type: PaddingProperty)
    FSlateSound PressedSlateSoundOverride; // 0x300 (Size: 0x18, Type: StructProperty)
    FSlateSound ClickedSlateSoundOverride; // 0x318 (Size: 0x18, Type: StructProperty)
    FSlateSound HoveredSlateSoundOverride; // 0x330 (Size: 0x18, Type: StructProperty)
    FSlateSound SelectedPressedSlateSoundOverride; // 0x348 (Size: 0x18, Type: StructProperty)
    FSlateSound SelectedClickedSlateSoundOverride; // 0x360 (Size: 0x18, Type: StructProperty)
    FSlateSound SelectedHoveredSlateSoundOverride; // 0x378 (Size: 0x18, Type: StructProperty)
    FSlateSound LockedPressedSlateSoundOverride; // 0x390 (Size: 0x18, Type: StructProperty)
    FSlateSound LockedClickedSlateSoundOverride; // 0x3a8 (Size: 0x18, Type: StructProperty)
    FSlateSound LockedHoveredSlateSoundOverride; // 0x3c0 (Size: 0x18, Type: StructProperty)
    uint8_t bApplyAlphaOnDisable : 1; // 0x3d8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bLocked : 1; // 0x3d8:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bSelectable : 1; // 0x3d8:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bShouldSelectUponReceivingFocus : 1; // 0x3d8:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bInteractableWhenSelected : 1; // 0x3d8:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bToggleable : 1; // 0x3d8:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bTriggerClickedAfterSelection : 1; // 0x3d8:6 (Size: 0x1, Type: BoolProperty)
    uint8_t bDisplayInputActionWhenNotInteractable : 1; // 0x3d8:7 (Size: 0x1, Type: BoolProperty)
    uint8_t bHideInputActionWithKeyboard : 1; // 0x3d9:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bShouldUseFallbackDefaultInputAction : 1; // 0x3d9:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bRequiresHold : 1; // 0x3d9:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3da[0x6]; // 0x3da (Size: 0x6, Type: PaddingProperty)
    UClass* HoldData; // 0x3e0 (Size: 0x8, Type: ClassProperty)
    bool bSimulateHoverOnTouchInput; // 0x3e8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3e9[0x1]; // 0x3e9 (Size: 0x1, Type: PaddingProperty)
    TEnumAsByte<EButtonClickMethod> ClickMethod; // 0x3ea (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EButtonTouchMethod> TouchMethod; // 0x3eb (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EButtonPressMethod> PressMethod; // 0x3ec (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3ed[0x3]; // 0x3ed (Size: 0x3, Type: PaddingProperty)
    int32_t InputPriority; // 0x3f0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_3f4[0x4]; // 0x3f4 (Size: 0x4, Type: PaddingProperty)
    FDataTableRowHandle TriggeringInputAction; // 0x3f8 (Size: 0x10, Type: StructProperty)
    UInputAction* TriggeringEnhancedInputAction; // 0x408 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_410[0x10]; // 0x410 (Size: 0x10, Type: PaddingProperty)
    uint8_t bNavigateToNextWidgetOnDisable : 1; // 0x420:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_421[0x7]; // 0x421 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnSelectedChangedBase[0x10]; // 0x428 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonBaseClicked[0x10]; // 0x438 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonBaseDoubleClicked[0x10]; // 0x448 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonBaseHovered[0x10]; // 0x458 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonBaseUnhovered[0x10]; // 0x468 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonBaseFocused[0x10]; // 0x478 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonBaseUnfocused[0x10]; // 0x488 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonBaseLockClicked[0x10]; // 0x498 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonBaseLockDoubleClicked[0x10]; // 0x4a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonBaseSelected[0x10]; // 0x4b8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonBaseUnselected[0x10]; // 0x4c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_4d8[0x38]; // 0x4d8 (Size: 0x38, Type: PaddingProperty)
    bool bIsPersistentBinding; // 0x510 (Size: 0x1, Type: BoolProperty)
    uint8_t InputModeOverride; // 0x511 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_512[0x26]; // 0x512 (Size: 0x26, Type: PaddingProperty)
    UMaterialInstanceDynamic* SingleMaterialStyleMID; // 0x538 (Size: 0x8, Type: ObjectProperty)
    FButtonStyle NormalStyle; // 0x540 (Size: 0x390, Type: StructProperty)
    FButtonStyle SelectedStyle; // 0x8d0 (Size: 0x390, Type: StructProperty)
    FButtonStyle DisabledStyle; // 0xc60 (Size: 0x390, Type: StructProperty)
    FButtonStyle LockedStyle; // 0xff0 (Size: 0x390, Type: StructProperty)
    uint8_t bStopDoubleClickPropagation : 1; // 0x1380:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1381[0x117]; // 0x1381 (Size: 0x117, Type: PaddingProperty)
    UCommonActionWidget* InputActionWidget; // 0x1498 (Size: 0x8, Type: ObjectProperty)

public:
    void ClearSelection(); // 0xb4a6314 (Index: 0x12, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void DisableButtonWithReason(const FText DisabledReason); // 0xb4a6490 (Index: 0x13, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void GetCurrentButtonPadding(FMargin& OutButtonPadding) const; // 0xb4a6d70 (Index: 0x15, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetCurrentCustomPadding(FMargin& OutCustomPadding) const; // 0xb4a6e50 (Index: 0x16, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UCommonTextStyle* GetCurrentTextStyle() const; // 0xb4a6f30 (Index: 0x17, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UClass* GetCurrentTextStyleClass() const; // 0x4c8a080 (Index: 0x18, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UInputAction* GetEnhancedInputAction() const; // 0xb4a714c (Index: 0x19, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetInputAction(FDataTableRowHandle& InputActionRow) const; // 0x4f203dc (Index: 0x1a, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool GetIsFocusable() const; // 0xb4a769c (Index: 0x1b, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetLocked() const; // 0x4efcce8 (Index: 0x1c, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetRequiredHoldTime() const; // 0xb4a7bd4 (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetRequiresHold() const; // 0xb4a7bec (Index: 0x1e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetSelected() const; // 0x4f33b80 (Index: 0x1f, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetShouldSelectUponReceivingFocus() const; // 0xb4a8190 (Index: 0x20, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMaterialInstanceDynamic* GetSingleMaterialStyleMID() const; // 0x6059de0 (Index: 0x21, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCommonButtonStyle* GetStyle() const; // 0xb4a82ac (Index: 0x22, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsInteractionEnabled() const; // 0xb4a9560 (Index: 0x2b, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPressed() const; // 0xb4a96c4 (Index: 0x2c, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetClickedSoundOverride(USoundBase*& Sound); // 0xb4abf58 (Index: 0x38, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetClickMethod(TEnumAsByte<EButtonClickMethod>& InClickMethod); // 0xb4abcf8 (Index: 0x39, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetHideInputAction(bool& bInHideInputAction); // 0xb4ac9f8 (Index: 0x3a, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetHoveredSoundOverride(USoundBase*& Sound); // 0xb4acc58 (Index: 0x3b, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetInputActionProgressMaterial(const FSlateBrush InProgressMaterialBrush, const FName InProgressMaterialParam); // 0xb4ace48 (Index: 0x3c, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetIsFocusable(bool& bInIsFocusable); // 0x5247fd8 (Index: 0x3d, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetIsInteractableWhenSelected(bool& bInInteractableWhenSelected); // 0xb4ad39c (Index: 0x3e, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetIsInteractionEnabled(bool& bInIsInteractionEnabled); // 0x473cde4 (Index: 0x3f, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetIsLocked(bool& bInIsLocked); // 0x56a6898 (Index: 0x40, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetIsSelectable(bool& bInIsSelectable); // 0x473cb58 (Index: 0x41, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetIsSelected(bool& InSelected, bool& bGiveClickFeedback); // 0xb4ad73c (Index: 0x42, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetIsToggleable(bool& bInIsToggleable); // 0x473c0fc (Index: 0x43, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetLockedClickedSoundOverride(USoundBase*& Sound); // 0xb4ae014 (Index: 0x44, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetLockedHoveredSoundOverride(USoundBase*& Sound); // 0xb4ae304 (Index: 0x45, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetLockedPressedSoundOverride(USoundBase*& Sound); // 0xb4ae5f4 (Index: 0x46, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetMaxDimensions(int32_t& InMaxWidth, int32_t& InMaxHeight); // 0xb4aeae8 (Index: 0x47, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetMinDimensions(int32_t& InMinWidth, int32_t& InMinHeight); // 0x4cd6714 (Index: 0x48, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetPressedSoundOverride(USoundBase*& Sound); // 0xb4af3b8 (Index: 0x49, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetPressMethod(TEnumAsByte<EButtonPressMethod>& InPressMethod); // 0xb4af158 (Index: 0x4a, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetRequiresHold(bool& bInRequiresHold); // 0xb4af4e4 (Index: 0x4b, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSelectedClickedSoundOverride(USoundBase*& Sound); // 0xb4af748 (Index: 0x4c, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSelectedHoveredSoundOverride(USoundBase*& Sound); // 0xb4afa38 (Index: 0x4d, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSelectedPressedSoundOverride(USoundBase*& Sound); // 0xb4b0020 (Index: 0x4f, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetShouldSelectUponReceivingFocus(bool& bInShouldSelectUponReceivingFocus); // 0x53b3814 (Index: 0x50, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetShouldUseFallbackDefaultInputAction(bool& bInShouldUseFallbackDefaultInputAction); // 0xb4b05c0 (Index: 0x51, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetStyle(UClass*& InStyle); // 0x4bfb348 (Index: 0x52, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetTouchMethod(TEnumAsByte<EButtonTouchMethod>& InTouchMethod); // 0xb4b0eac (Index: 0x53, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetTriggeredInputAction(const FDataTableRowHandle InputActionRow); // 0xb4b110c (Index: 0x54, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetTriggeringEnhancedInputAction(UInputAction*& InInputAction); // 0x534aba0 (Index: 0x55, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetTriggeringInputAction(const FDataTableRowHandle InputActionRow); // 0x4f204d0 (Index: 0x56, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)

private:
    bool IsHoverSimulationOnTouchAvailable() const; // 0xb4a9544 (Index: 0x2a, Flags: Final|Native|Private|Const)

protected:
    virtual void BP_OnClicked(); // 0x288a61c (Index: 0x0, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnDeselected(); // 0x288a61c (Index: 0x1, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnDisabled(); // 0x288a61c (Index: 0x2, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnDoubleClicked(); // 0x288a61c (Index: 0x3, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnEnabled(); // 0x288a61c (Index: 0x4, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnFocusLost(); // 0x288a61c (Index: 0x5, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnFocusReceived(); // 0x288a61c (Index: 0x6, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnHovered(); // 0x288a61c (Index: 0x7, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnInputActionTriggered(); // 0x288a61c (Index: 0x8, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnInputMethodChanged(ECommonInputType& CurrentInputType); // 0x288a61c (Index: 0x9, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnLockClicked(); // 0x288a61c (Index: 0xa, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnLockDoubleClicked(); // 0x288a61c (Index: 0xb, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnLockedChanged(bool& bIsLocked); // 0x288a61c (Index: 0xc, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnPressed(); // 0x288a61c (Index: 0xd, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnReleased(); // 0x288a61c (Index: 0xe, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnRequiresHoldChanged(); // 0x288a61c (Index: 0xf, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnSelected(); // 0x288a61c (Index: 0x10, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void BP_OnUnhovered(); // 0x288a61c (Index: 0x11, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    bool GetConvertInputActionToHold(); // 0xb4a6d48 (Index: 0x14, Flags: RequiredAPI|Native|Protected)
    void HandleButtonClicked(); // 0xb4a85b4 (Index: 0x23, Flags: RequiredAPI|Native|Protected)
    void HandleButtonPressed(); // 0xb4a87d4 (Index: 0x24, Flags: RequiredAPI|Native|Protected)
    void HandleButtonReleased(); // 0xb4a87ec (Index: 0x25, Flags: RequiredAPI|Native|Protected)
    void HandleFocusLost(); // 0xb4a8804 (Index: 0x26, Flags: RequiredAPI|Native|Protected)
    void HandleFocusReceived(); // 0x5fca794 (Index: 0x27, Flags: RequiredAPI|Native|Protected)
    void HandleTriggeringActionCommited(bool& bPassThrough); // 0xb4a8dd8 (Index: 0x28, Flags: RequiredAPI|Native|Protected|HasOutParms)
    void HoldReset(); // 0xb4a9014 (Index: 0x29, Flags: RequiredAPI|Native|Protected)
    void NativeOnActionComplete(); // 0xb4a9750 (Index: 0x2d, Flags: RequiredAPI|Native|Protected)
    void NativeOnActionProgress(float& HeldPercent); // 0xb4a9768 (Index: 0x2e, Flags: RequiredAPI|Native|Protected)
    bool NativeOnHoldProgress(float& DeltaTime); // 0xb4a9898 (Index: 0x2f, Flags: RequiredAPI|Native|Protected)
    bool NativeOnHoldProgressRollback(float& DeltaTime); // 0xb4a99d8 (Index: 0x30, Flags: RequiredAPI|Native|Protected)
    virtual void OnActionComplete(); // 0x288a61c (Index: 0x31, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void OnActionProgress(float& HeldPercent); // 0x288a61c (Index: 0x32, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void OnCurrentTextStyleChanged(); // 0x288a61c (Index: 0x33, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    void OnInputMethodChanged(ECommonInputType& CurrentInputType); // 0xb4aa130 (Index: 0x34, Flags: RequiredAPI|Native|Protected)
    virtual void OnTriggeredInputActionChanged(const FDataTableRowHandle NewTriggeredAction); // 0x288a61c (Index: 0x35, Flags: RequiredAPI|Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnTriggeringEnhancedInputActionChanged(UInputAction*& const InInputAction); // 0x288a61c (Index: 0x36, Flags: RequiredAPI|Event|Protected|BlueprintEvent)
    virtual void OnTriggeringInputActionChanged(const FDataTableRowHandle NewTriggeredAction); // 0x288a61c (Index: 0x37, Flags: RequiredAPI|Event|Protected|HasOutParms|BlueprintEvent)
    void SetSelectedInternal(bool& bInSelected, bool& bAllowSound, bool& bBroadcast); // 0xb4afd28 (Index: 0x4e, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
    void StopDoubleClickPropagation(); // 0xb4b1460 (Index: 0x57, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
    void UpdateHoldData(ECommonInputType& CurrentInputType); // 0xb4b159c (Index: 0x58, Flags: RequiredAPI|Native|Protected)
};

static_assert(sizeof(UCommonButtonBase) == 0x14a0, "Size mismatch for UCommonButtonBase");
static_assert(offsetof(UCommonButtonBase, ClickEvent) == 0x2d8, "Offset mismatch for UCommonButtonBase::ClickEvent");
static_assert(offsetof(UCommonButtonBase, MinWidth) == 0x2dc, "Offset mismatch for UCommonButtonBase::MinWidth");
static_assert(offsetof(UCommonButtonBase, MinHeight) == 0x2e0, "Offset mismatch for UCommonButtonBase::MinHeight");
static_assert(offsetof(UCommonButtonBase, MaxWidth) == 0x2e4, "Offset mismatch for UCommonButtonBase::MaxWidth");
static_assert(offsetof(UCommonButtonBase, MaxHeight) == 0x2e8, "Offset mismatch for UCommonButtonBase::MaxHeight");
static_assert(offsetof(UCommonButtonBase, Style) == 0x2f0, "Offset mismatch for UCommonButtonBase::Style");
static_assert(offsetof(UCommonButtonBase, bHideInputAction) == 0x2f8, "Offset mismatch for UCommonButtonBase::bHideInputAction");
static_assert(offsetof(UCommonButtonBase, PressedSlateSoundOverride) == 0x300, "Offset mismatch for UCommonButtonBase::PressedSlateSoundOverride");
static_assert(offsetof(UCommonButtonBase, ClickedSlateSoundOverride) == 0x318, "Offset mismatch for UCommonButtonBase::ClickedSlateSoundOverride");
static_assert(offsetof(UCommonButtonBase, HoveredSlateSoundOverride) == 0x330, "Offset mismatch for UCommonButtonBase::HoveredSlateSoundOverride");
static_assert(offsetof(UCommonButtonBase, SelectedPressedSlateSoundOverride) == 0x348, "Offset mismatch for UCommonButtonBase::SelectedPressedSlateSoundOverride");
static_assert(offsetof(UCommonButtonBase, SelectedClickedSlateSoundOverride) == 0x360, "Offset mismatch for UCommonButtonBase::SelectedClickedSlateSoundOverride");
static_assert(offsetof(UCommonButtonBase, SelectedHoveredSlateSoundOverride) == 0x378, "Offset mismatch for UCommonButtonBase::SelectedHoveredSlateSoundOverride");
static_assert(offsetof(UCommonButtonBase, LockedPressedSlateSoundOverride) == 0x390, "Offset mismatch for UCommonButtonBase::LockedPressedSlateSoundOverride");
static_assert(offsetof(UCommonButtonBase, LockedClickedSlateSoundOverride) == 0x3a8, "Offset mismatch for UCommonButtonBase::LockedClickedSlateSoundOverride");
static_assert(offsetof(UCommonButtonBase, LockedHoveredSlateSoundOverride) == 0x3c0, "Offset mismatch for UCommonButtonBase::LockedHoveredSlateSoundOverride");
static_assert(offsetof(UCommonButtonBase, bApplyAlphaOnDisable) == 0x3d8, "Offset mismatch for UCommonButtonBase::bApplyAlphaOnDisable");
static_assert(offsetof(UCommonButtonBase, bLocked) == 0x3d8, "Offset mismatch for UCommonButtonBase::bLocked");
static_assert(offsetof(UCommonButtonBase, bSelectable) == 0x3d8, "Offset mismatch for UCommonButtonBase::bSelectable");
static_assert(offsetof(UCommonButtonBase, bShouldSelectUponReceivingFocus) == 0x3d8, "Offset mismatch for UCommonButtonBase::bShouldSelectUponReceivingFocus");
static_assert(offsetof(UCommonButtonBase, bInteractableWhenSelected) == 0x3d8, "Offset mismatch for UCommonButtonBase::bInteractableWhenSelected");
static_assert(offsetof(UCommonButtonBase, bToggleable) == 0x3d8, "Offset mismatch for UCommonButtonBase::bToggleable");
static_assert(offsetof(UCommonButtonBase, bTriggerClickedAfterSelection) == 0x3d8, "Offset mismatch for UCommonButtonBase::bTriggerClickedAfterSelection");
static_assert(offsetof(UCommonButtonBase, bDisplayInputActionWhenNotInteractable) == 0x3d8, "Offset mismatch for UCommonButtonBase::bDisplayInputActionWhenNotInteractable");
static_assert(offsetof(UCommonButtonBase, bHideInputActionWithKeyboard) == 0x3d9, "Offset mismatch for UCommonButtonBase::bHideInputActionWithKeyboard");
static_assert(offsetof(UCommonButtonBase, bShouldUseFallbackDefaultInputAction) == 0x3d9, "Offset mismatch for UCommonButtonBase::bShouldUseFallbackDefaultInputAction");
static_assert(offsetof(UCommonButtonBase, bRequiresHold) == 0x3d9, "Offset mismatch for UCommonButtonBase::bRequiresHold");
static_assert(offsetof(UCommonButtonBase, HoldData) == 0x3e0, "Offset mismatch for UCommonButtonBase::HoldData");
static_assert(offsetof(UCommonButtonBase, bSimulateHoverOnTouchInput) == 0x3e8, "Offset mismatch for UCommonButtonBase::bSimulateHoverOnTouchInput");
static_assert(offsetof(UCommonButtonBase, ClickMethod) == 0x3ea, "Offset mismatch for UCommonButtonBase::ClickMethod");
static_assert(offsetof(UCommonButtonBase, TouchMethod) == 0x3eb, "Offset mismatch for UCommonButtonBase::TouchMethod");
static_assert(offsetof(UCommonButtonBase, PressMethod) == 0x3ec, "Offset mismatch for UCommonButtonBase::PressMethod");
static_assert(offsetof(UCommonButtonBase, InputPriority) == 0x3f0, "Offset mismatch for UCommonButtonBase::InputPriority");
static_assert(offsetof(UCommonButtonBase, TriggeringInputAction) == 0x3f8, "Offset mismatch for UCommonButtonBase::TriggeringInputAction");
static_assert(offsetof(UCommonButtonBase, TriggeringEnhancedInputAction) == 0x408, "Offset mismatch for UCommonButtonBase::TriggeringEnhancedInputAction");
static_assert(offsetof(UCommonButtonBase, bNavigateToNextWidgetOnDisable) == 0x420, "Offset mismatch for UCommonButtonBase::bNavigateToNextWidgetOnDisable");
static_assert(offsetof(UCommonButtonBase, OnSelectedChangedBase) == 0x428, "Offset mismatch for UCommonButtonBase::OnSelectedChangedBase");
static_assert(offsetof(UCommonButtonBase, OnButtonBaseClicked) == 0x438, "Offset mismatch for UCommonButtonBase::OnButtonBaseClicked");
static_assert(offsetof(UCommonButtonBase, OnButtonBaseDoubleClicked) == 0x448, "Offset mismatch for UCommonButtonBase::OnButtonBaseDoubleClicked");
static_assert(offsetof(UCommonButtonBase, OnButtonBaseHovered) == 0x458, "Offset mismatch for UCommonButtonBase::OnButtonBaseHovered");
static_assert(offsetof(UCommonButtonBase, OnButtonBaseUnhovered) == 0x468, "Offset mismatch for UCommonButtonBase::OnButtonBaseUnhovered");
static_assert(offsetof(UCommonButtonBase, OnButtonBaseFocused) == 0x478, "Offset mismatch for UCommonButtonBase::OnButtonBaseFocused");
static_assert(offsetof(UCommonButtonBase, OnButtonBaseUnfocused) == 0x488, "Offset mismatch for UCommonButtonBase::OnButtonBaseUnfocused");
static_assert(offsetof(UCommonButtonBase, OnButtonBaseLockClicked) == 0x498, "Offset mismatch for UCommonButtonBase::OnButtonBaseLockClicked");
static_assert(offsetof(UCommonButtonBase, OnButtonBaseLockDoubleClicked) == 0x4a8, "Offset mismatch for UCommonButtonBase::OnButtonBaseLockDoubleClicked");
static_assert(offsetof(UCommonButtonBase, OnButtonBaseSelected) == 0x4b8, "Offset mismatch for UCommonButtonBase::OnButtonBaseSelected");
static_assert(offsetof(UCommonButtonBase, OnButtonBaseUnselected) == 0x4c8, "Offset mismatch for UCommonButtonBase::OnButtonBaseUnselected");
static_assert(offsetof(UCommonButtonBase, bIsPersistentBinding) == 0x510, "Offset mismatch for UCommonButtonBase::bIsPersistentBinding");
static_assert(offsetof(UCommonButtonBase, InputModeOverride) == 0x511, "Offset mismatch for UCommonButtonBase::InputModeOverride");
static_assert(offsetof(UCommonButtonBase, SingleMaterialStyleMID) == 0x538, "Offset mismatch for UCommonButtonBase::SingleMaterialStyleMID");
static_assert(offsetof(UCommonButtonBase, NormalStyle) == 0x540, "Offset mismatch for UCommonButtonBase::NormalStyle");
static_assert(offsetof(UCommonButtonBase, SelectedStyle) == 0x8d0, "Offset mismatch for UCommonButtonBase::SelectedStyle");
static_assert(offsetof(UCommonButtonBase, DisabledStyle) == 0xc60, "Offset mismatch for UCommonButtonBase::DisabledStyle");
static_assert(offsetof(UCommonButtonBase, LockedStyle) == 0xff0, "Offset mismatch for UCommonButtonBase::LockedStyle");
static_assert(offsetof(UCommonButtonBase, bStopDoubleClickPropagation) == 0x1380, "Offset mismatch for UCommonButtonBase::bStopDoubleClickPropagation");
static_assert(offsetof(UCommonButtonBase, InputActionWidget) == 0x1498, "Offset mismatch for UCommonButtonBase::InputActionWidget");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UWidgetLockedStateRegistration : public UWidgetBinaryStateRegistration
{
public:
};

static_assert(sizeof(UWidgetLockedStateRegistration) == 0x28, "Size mismatch for UWidgetLockedStateRegistration");

// Size: 0x2e0 (Inherited: 0x758, Single: 0xfffffb88)
class UCommonCustomNavigation : public UBorder
{
public:
    uint8_t OnNavigationEvent[0xc]; // 0x2d0 (Size: 0xc, Type: DelegateProperty)
    uint8_t Pad_2dc[0x4]; // 0x2dc (Size: 0x4, Type: PaddingProperty)

public:
    bool OnCustomNavigationEvent__DelegateSignature(EUINavigation& NavigationType); // 0x288a61c (Index: 0x0, Flags: Public|Delegate)
};

static_assert(sizeof(UCommonCustomNavigation) == 0x2e0, "Size mismatch for UCommonCustomNavigation");
static_assert(offsetof(UCommonCustomNavigation, OnNavigationEvent) == 0x2d0, "Offset mismatch for UCommonCustomNavigation::OnNavigationEvent");

// Size: 0x3a0 (Inherited: 0x950, Single: 0xfffffa50)
class UCommonDateTimeTextBlock : public UCommonTextBlock
{
public:
    FText CustomTimespanFormat; // 0x330 (Size: 0x10, Type: TextProperty)
    bool bCustomTimespanLeadingZeros; // 0x340 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_341[0x5f]; // 0x341 (Size: 0x5f, Type: PaddingProperty)

public:
    FDateTime GetDateTime() const; // 0x5a4edfc (Index: 0x0, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    void SetCountDownCompletionText(FText& const InCompletionText); // 0xb4ac374 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void SetDateTimeValue(FDateTime& const InDateTime, bool& bShowAsCountdown, float& InRefreshDelay); // 0xb4ac4bc (Index: 0x2, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetTimespanValue(FTimespan& const InTimespan); // 0xb4b0de8 (Index: 0x3, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UCommonDateTimeTextBlock) == 0x3a0, "Size mismatch for UCommonDateTimeTextBlock");
static_assert(offsetof(UCommonDateTimeTextBlock, CustomTimespanFormat) == 0x330, "Offset mismatch for UCommonDateTimeTextBlock::CustomTimespanFormat");
static_assert(offsetof(UCommonDateTimeTextBlock, bCustomTimespanLeadingZeros) == 0x340, "Offset mismatch for UCommonDateTimeTextBlock::bCustomTimespanLeadingZeros");

// Size: 0x330 (Inherited: 0x620, Single: 0xfffffd10)
class UCommonTextBlock : public UTextBlock
{
public:
    float MobileFontSizeMultiplier; // 0x300 (Size: 0x4, Type: FloatProperty)
    bool bIsScrollingEnabled; // 0x304 (Size: 0x1, Type: BoolProperty)
    bool bDisplayAllCaps; // 0x305 (Size: 0x1, Type: BoolProperty)
    bool bAutoCollapseWithEmptyText; // 0x306 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_307[0x1]; // 0x307 (Size: 0x1, Type: PaddingProperty)
    UClass* Style; // 0x308 (Size: 0x8, Type: ClassProperty)
    UClass* ScrollStyle; // 0x310 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EOrientation> ScrollOrientation; // 0x318 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_319[0x17]; // 0x319 (Size: 0x17, Type: PaddingProperty)

public:
    FMargin GetMargin(); // 0xb4a76dc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    float GetMobileFontSizeMultiplier() const; // 0xb4a77cc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ResetScrollState(); // 0xb4aad60 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void SetApplyLineHeightToBottomLine(bool& InApplyLineHeightToBottomLine); // 0xb4ab338 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void SetLineHeightPercentage(float& InLineHeightPercentage); // 0x5895b4c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SetMargin(const FMargin InMargin); // 0xb4aea14 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetMobileFontSizeMultiplier(float& InMobileFontSizeMultiplier); // 0x3f58410 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void SetScrollingEnabled(bool& bInIsScrollingEnabled); // 0x5284788 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void SetScrollOrientation(TEnumAsByte<EOrientation>& InScrollOrientation); // 0x5944a64 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void SetStyle(UClass*& InStyle); // 0x3f8c778 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void SetTextCase(bool& bUseAllCaps); // 0x4e8d594 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void SetWrapTextWidth(int32_t& InWrapTextAt); // 0x5873e60 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonTextBlock) == 0x330, "Size mismatch for UCommonTextBlock");
static_assert(offsetof(UCommonTextBlock, MobileFontSizeMultiplier) == 0x300, "Offset mismatch for UCommonTextBlock::MobileFontSizeMultiplier");
static_assert(offsetof(UCommonTextBlock, bIsScrollingEnabled) == 0x304, "Offset mismatch for UCommonTextBlock::bIsScrollingEnabled");
static_assert(offsetof(UCommonTextBlock, bDisplayAllCaps) == 0x305, "Offset mismatch for UCommonTextBlock::bDisplayAllCaps");
static_assert(offsetof(UCommonTextBlock, bAutoCollapseWithEmptyText) == 0x306, "Offset mismatch for UCommonTextBlock::bAutoCollapseWithEmptyText");
static_assert(offsetof(UCommonTextBlock, Style) == 0x308, "Offset mismatch for UCommonTextBlock::Style");
static_assert(offsetof(UCommonTextBlock, ScrollStyle) == 0x310, "Offset mismatch for UCommonTextBlock::ScrollStyle");
static_assert(offsetof(UCommonTextBlock, ScrollOrientation) == 0x318, "Offset mismatch for UCommonTextBlock::ScrollOrientation");

// Size: 0x3f8 (Inherited: 0x408, Single: 0xfffffff0)
class UCommonGameViewportClient : public UGameViewportClient
{
public:
};

static_assert(sizeof(UCommonGameViewportClient) == 0x3f8, "Size mismatch for UCommonGameViewportClient");

// Size: 0x340 (Inherited: 0xa48, Single: 0xfffff8f8)
class UCommonHardwareVisibilityBorder : public UCommonBorder
{
public:
    FGameplayTagQuery VisibilityQuery; // 0x2f0 (Size: 0x48, Type: StructProperty)
    uint8_t VisibleType; // 0x338 (Size: 0x1, Type: EnumProperty)
    uint8_t HiddenType; // 0x339 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_33a[0x6]; // 0x33a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UCommonHardwareVisibilityBorder) == 0x340, "Size mismatch for UCommonHardwareVisibilityBorder");
static_assert(offsetof(UCommonHardwareVisibilityBorder, VisibilityQuery) == 0x2f0, "Offset mismatch for UCommonHardwareVisibilityBorder::VisibilityQuery");
static_assert(offsetof(UCommonHardwareVisibilityBorder, VisibleType) == 0x338, "Offset mismatch for UCommonHardwareVisibilityBorder::VisibleType");
static_assert(offsetof(UCommonHardwareVisibilityBorder, HiddenType) == 0x339, "Offset mismatch for UCommonHardwareVisibilityBorder::HiddenType");

// Size: 0xb40 (Inherited: 0xe58, Single: 0xfffffce8)
class UCommonHierarchicalScrollBox : public UScrollBox
{
public:
};

static_assert(sizeof(UCommonHierarchicalScrollBox) == 0xb40, "Size mismatch for UCommonHierarchicalScrollBox");

// Size: 0x370 (Inherited: 0x428, Single: 0xffffff48)
class UCommonLazyImage : public UImage
{
public:
    FSlateBrush LoadingBackgroundBrush; // 0x280 (Size: 0xb0, Type: StructProperty)
    FName MaterialTextureParamName; // 0x330 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_334[0x4]; // 0x334 (Size: 0x4, Type: PaddingProperty)
    uint8_t BP_OnLoadingStateChanged[0x10]; // 0x338 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_348[0x28]; // 0x348 (Size: 0x28, Type: PaddingProperty)

public:
    bool IsLoading() const; // 0xb4a95a0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetBrushFromLazyDisplayAsset(const TSoftObjectPtr<UObject*> LazyObject, bool& bMatchTextureSize); // 0x4a3b388 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetBrushFromLazyMaterial(const TSoftObjectPtr<UMaterialInterface*> LazyMaterial); // 0xb4ab744 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetBrushFromLazyTexture(const TSoftObjectPtr<UTexture2D*> LazyTexture, bool& bMatchSize); // 0xb4ab9e0 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetMaterialTextureParamName(FName& TextureParamName); // 0x55697e4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonLazyImage) == 0x370, "Size mismatch for UCommonLazyImage");
static_assert(offsetof(UCommonLazyImage, LoadingBackgroundBrush) == 0x280, "Offset mismatch for UCommonLazyImage::LoadingBackgroundBrush");
static_assert(offsetof(UCommonLazyImage, MaterialTextureParamName) == 0x330, "Offset mismatch for UCommonLazyImage::MaterialTextureParamName");
static_assert(offsetof(UCommonLazyImage, BP_OnLoadingStateChanged) == 0x338, "Offset mismatch for UCommonLazyImage::BP_OnLoadingStateChanged");

// Size: 0x290 (Inherited: 0x1a8, Single: 0xe8)
class UCommonLazyWidget : public UWidget
{
public:
    uint8_t Pad_158[0x8]; // 0x158 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush LoadingBackgroundBrush; // 0x160 (Size: 0xb0, Type: StructProperty)
    UUserWidget* Content; // 0x210 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_218[0x28]; // 0x218 (Size: 0x28, Type: PaddingProperty)
    uint8_t BP_OnLoadingStateChanged[0x10]; // 0x240 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_250[0x40]; // 0x250 (Size: 0x40, Type: PaddingProperty)

public:
    UUserWidget* GetContent() const; // 0xb4a6d30 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsLoading() const; // 0xb4a95d0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetLazyContent(TSoftClassPtr& const SoftWidget); // 0xb4ad958 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonLazyWidget) == 0x290, "Size mismatch for UCommonLazyWidget");
static_assert(offsetof(UCommonLazyWidget, LoadingBackgroundBrush) == 0x160, "Offset mismatch for UCommonLazyWidget::LoadingBackgroundBrush");
static_assert(offsetof(UCommonLazyWidget, Content) == 0x210, "Offset mismatch for UCommonLazyWidget::Content");
static_assert(offsetof(UCommonLazyWidget, BP_OnLoadingStateChanged) == 0x240, "Offset mismatch for UCommonLazyWidget::BP_OnLoadingStateChanged");

// Size: 0xb60 (Inherited: 0xf98, Single: 0xfffffbc8)
class UCommonListView : public UListView
{
public:

public:
    void SetEntrySpacing(float& InEntrySpacing); // 0xb4ac8c4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonListView) == 0xb60, "Size mismatch for UCommonListView");

// Size: 0x60 (Inherited: 0x88, Single: 0xffffffd8)
class ULoadGuardSlot : public UPanelSlot
{
public:
    FMargin Padding; // 0x38 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<EHorizontalAlignment> HorizontalAlignment; // 0x48 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EVerticalAlignment> VerticalAlignment; // 0x49 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_4a[0x16]; // 0x4a (Size: 0x16, Type: PaddingProperty)

public:
    void SetHorizontalAlignment(TEnumAsByte<EHorizontalAlignment>& InHorizontalAlignment); // 0xb4acb2c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetPadding(FMargin& InPadding); // 0xb4aef58 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void SetVerticalAlignment(TEnumAsByte<EVerticalAlignment>& InVerticalAlignment); // 0xb4b11e0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ULoadGuardSlot) == 0x60, "Size mismatch for ULoadGuardSlot");
static_assert(offsetof(ULoadGuardSlot, Padding) == 0x38, "Offset mismatch for ULoadGuardSlot::Padding");
static_assert(offsetof(ULoadGuardSlot, HorizontalAlignment) == 0x48, "Offset mismatch for ULoadGuardSlot::HorizontalAlignment");
static_assert(offsetof(ULoadGuardSlot, VerticalAlignment) == 0x49, "Offset mismatch for ULoadGuardSlot::VerticalAlignment");

// Size: 0x2a0 (Inherited: 0x488, Single: 0xfffffe18)
class UCommonLoadGuard : public UContentWidget
{
public:
    FSlateBrush LoadingBackgroundBrush; // 0x170 (Size: 0xb0, Type: StructProperty)
    TEnumAsByte<EHorizontalAlignment> ThrobberAlignment; // 0x220 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_221[0x3]; // 0x221 (Size: 0x3, Type: PaddingProperty)
    FMargin ThrobberPadding; // 0x224 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_234[0x4]; // 0x234 (Size: 0x4, Type: PaddingProperty)
    FText LoadingText; // 0x238 (Size: 0x10, Type: TextProperty)
    UClass* TextStyle; // 0x248 (Size: 0x8, Type: ClassProperty)
    uint8_t BP_OnLoadingStateChanged[0x10]; // 0x250 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FSoftObjectPath SpinnerMaterialPath; // 0x260 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_278[0x28]; // 0x278 (Size: 0x28, Type: PaddingProperty)

public:
    void OnAssetLoaded__DelegateSignature(UObject*& Object); // 0x288a61c (Index: 0x1, Flags: Public|Delegate)
    bool IsLoading() const; // 0xb4a9600 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetIsLoading(bool& bInIsLoading); // 0xb4ad4c8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void SetLoadingText(const FText InLoadingText); // 0xb4aded4 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

private:
    void BP_GuardAndLoadAsset(const TSoftObjectPtr<UObject*> InLazyAsset, const FDelegate OnAssetLoaded); // 0xb4a59ac (Index: 0x0, Flags: Final|Native|Private|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UCommonLoadGuard) == 0x2a0, "Size mismatch for UCommonLoadGuard");
static_assert(offsetof(UCommonLoadGuard, LoadingBackgroundBrush) == 0x170, "Offset mismatch for UCommonLoadGuard::LoadingBackgroundBrush");
static_assert(offsetof(UCommonLoadGuard, ThrobberAlignment) == 0x220, "Offset mismatch for UCommonLoadGuard::ThrobberAlignment");
static_assert(offsetof(UCommonLoadGuard, ThrobberPadding) == 0x224, "Offset mismatch for UCommonLoadGuard::ThrobberPadding");
static_assert(offsetof(UCommonLoadGuard, LoadingText) == 0x238, "Offset mismatch for UCommonLoadGuard::LoadingText");
static_assert(offsetof(UCommonLoadGuard, TextStyle) == 0x248, "Offset mismatch for UCommonLoadGuard::TextStyle");
static_assert(offsetof(UCommonLoadGuard, BP_OnLoadingStateChanged) == 0x250, "Offset mismatch for UCommonLoadGuard::BP_OnLoadingStateChanged");
static_assert(offsetof(UCommonLoadGuard, SpinnerMaterialPath) == 0x260, "Offset mismatch for UCommonLoadGuard::SpinnerMaterialPath");

// Size: 0x3d0 (Inherited: 0x950, Single: 0xfffffa80)
class UCommonNumericTextBlock : public UCommonTextBlock
{
public:
    uint8_t OnInterpolationStartedEvent[0x10]; // 0x330 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInterpolationUpdatedEvent[0x10]; // 0x340 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnOutroEvent[0x10]; // 0x350 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInterpolationEndedEvent[0x10]; // 0x360 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float CurrentNumericValue; // 0x370 (Size: 0x4, Type: FloatProperty)
    uint8_t NumericType; // 0x374 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_375[0x3]; // 0x375 (Size: 0x3, Type: PaddingProperty)
    FCommonNumberFormattingOptions FormattingSpecification; // 0x378 (Size: 0x14, Type: StructProperty)
    float EaseOutInterpolationExponent; // 0x38c (Size: 0x4, Type: FloatProperty)
    float InterpolationUpdateInterval; // 0x390 (Size: 0x4, Type: FloatProperty)
    float PostInterpolationShrinkDuration; // 0x394 (Size: 0x4, Type: FloatProperty)
    bool PerformSizeInterpolation; // 0x398 (Size: 0x1, Type: BoolProperty)
    bool IsPercentage; // 0x399 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39a[0x36]; // 0x39a (Size: 0x36, Type: PaddingProperty)

public:
    float GetTargetValue() const; // 0xb4a8400 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void InterpolateToValue(float& const TargetValue, float& MaximumInterpolationDuration, float& MinimumChangeRate, float& OutroOffset); // 0xb4a9158 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    bool IsInterpolatingNumericValue() const; // 0xb4a9584 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnInterpolationEnded__DelegateSignature(UCommonNumericTextBlock*& NumericTextBlock, bool& const HadCompleted); // 0x288a61c (Index: 0x3, Flags: MulticastDelegate|Public|Delegate)
    void OnInterpolationStarted__DelegateSignature(UCommonNumericTextBlock*& NumericTextBlock); // 0x288a61c (Index: 0x4, Flags: MulticastDelegate|Public|Delegate)
    void OnInterpolationUpdated__DelegateSignature(UCommonNumericTextBlock*& NumericTextBlock, float& LastValue, float& NewValue); // 0x288a61c (Index: 0x5, Flags: MulticastDelegate|Public|Delegate)
    void OnOutro__DelegateSignature(UCommonNumericTextBlock*& NumericTextBlock); // 0x288a61c (Index: 0x6, Flags: MulticastDelegate|Public|Delegate)
    void SetCurrentValue(float& const NewValue); // 0x4b755d8 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void SetNumericType(ECommonNumericType& InNumericType); // 0xb4aee28 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonNumericTextBlock) == 0x3d0, "Size mismatch for UCommonNumericTextBlock");
static_assert(offsetof(UCommonNumericTextBlock, OnInterpolationStartedEvent) == 0x330, "Offset mismatch for UCommonNumericTextBlock::OnInterpolationStartedEvent");
static_assert(offsetof(UCommonNumericTextBlock, OnInterpolationUpdatedEvent) == 0x340, "Offset mismatch for UCommonNumericTextBlock::OnInterpolationUpdatedEvent");
static_assert(offsetof(UCommonNumericTextBlock, OnOutroEvent) == 0x350, "Offset mismatch for UCommonNumericTextBlock::OnOutroEvent");
static_assert(offsetof(UCommonNumericTextBlock, OnInterpolationEndedEvent) == 0x360, "Offset mismatch for UCommonNumericTextBlock::OnInterpolationEndedEvent");
static_assert(offsetof(UCommonNumericTextBlock, CurrentNumericValue) == 0x370, "Offset mismatch for UCommonNumericTextBlock::CurrentNumericValue");
static_assert(offsetof(UCommonNumericTextBlock, NumericType) == 0x374, "Offset mismatch for UCommonNumericTextBlock::NumericType");
static_assert(offsetof(UCommonNumericTextBlock, FormattingSpecification) == 0x378, "Offset mismatch for UCommonNumericTextBlock::FormattingSpecification");
static_assert(offsetof(UCommonNumericTextBlock, EaseOutInterpolationExponent) == 0x38c, "Offset mismatch for UCommonNumericTextBlock::EaseOutInterpolationExponent");
static_assert(offsetof(UCommonNumericTextBlock, InterpolationUpdateInterval) == 0x390, "Offset mismatch for UCommonNumericTextBlock::InterpolationUpdateInterval");
static_assert(offsetof(UCommonNumericTextBlock, PostInterpolationShrinkDuration) == 0x394, "Offset mismatch for UCommonNumericTextBlock::PostInterpolationShrinkDuration");
static_assert(offsetof(UCommonNumericTextBlock, PerformSizeInterpolation) == 0x398, "Offset mismatch for UCommonNumericTextBlock::PerformSizeInterpolation");
static_assert(offsetof(UCommonNumericTextBlock, IsPercentage) == 0x399, "Offset mismatch for UCommonNumericTextBlock::IsPercentage");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCommonPoolableWidgetInterface : public UInterface
{
public:

protected:
    virtual void OnAcquireFromPool(); // 0xb4a9b2c (Index: 0x0, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void OnReleaseToPool(); // 0xb4aa260 (Index: 0x1, Flags: Native|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCommonPoolableWidgetInterface) == 0x28, "Size mismatch for UCommonPoolableWidgetInterface");

// Size: 0x7d0 (Inherited: 0xac0, Single: 0xfffffd10)
class UCommonRichTextBlock : public URichTextBlock
{
public:
    uint8_t InlineIconDisplayMode; // 0x7a0 (Size: 0x1, Type: EnumProperty)
    bool bTintInlineIcon; // 0x7a1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7a2[0x2]; // 0x7a2 (Size: 0x2, Type: PaddingProperty)
    float MobileTextBlockScale; // 0x7a4 (Size: 0x4, Type: FloatProperty)
    UClass* DefaultTextStyleOverrideClass; // 0x7a8 (Size: 0x8, Type: ClassProperty)
    UClass* ScrollStyle; // 0x7b0 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EOrientation> ScrollOrientation; // 0x7b8 (Size: 0x1, Type: ByteProperty)
    bool bIsScrollingEnabled; // 0x7b9 (Size: 0x1, Type: BoolProperty)
    bool bDisplayAllCaps; // 0x7ba (Size: 0x1, Type: BoolProperty)
    bool bAutoCollapseWithEmptyText; // 0x7bb (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7bc[0x14]; // 0x7bc (Size: 0x14, Type: PaddingProperty)

public:
    void SetScrollingEnabled(bool& bInIsScrollingEnabled); // 0xb4af610 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonRichTextBlock) == 0x7d0, "Size mismatch for UCommonRichTextBlock");
static_assert(offsetof(UCommonRichTextBlock, InlineIconDisplayMode) == 0x7a0, "Offset mismatch for UCommonRichTextBlock::InlineIconDisplayMode");
static_assert(offsetof(UCommonRichTextBlock, bTintInlineIcon) == 0x7a1, "Offset mismatch for UCommonRichTextBlock::bTintInlineIcon");
static_assert(offsetof(UCommonRichTextBlock, MobileTextBlockScale) == 0x7a4, "Offset mismatch for UCommonRichTextBlock::MobileTextBlockScale");
static_assert(offsetof(UCommonRichTextBlock, DefaultTextStyleOverrideClass) == 0x7a8, "Offset mismatch for UCommonRichTextBlock::DefaultTextStyleOverrideClass");
static_assert(offsetof(UCommonRichTextBlock, ScrollStyle) == 0x7b0, "Offset mismatch for UCommonRichTextBlock::ScrollStyle");
static_assert(offsetof(UCommonRichTextBlock, ScrollOrientation) == 0x7b8, "Offset mismatch for UCommonRichTextBlock::ScrollOrientation");
static_assert(offsetof(UCommonRichTextBlock, bIsScrollingEnabled) == 0x7b9, "Offset mismatch for UCommonRichTextBlock::bIsScrollingEnabled");
static_assert(offsetof(UCommonRichTextBlock, bDisplayAllCaps) == 0x7ba, "Offset mismatch for UCommonRichTextBlock::bDisplayAllCaps");
static_assert(offsetof(UCommonRichTextBlock, bAutoCollapseWithEmptyText) == 0x7bb, "Offset mismatch for UCommonRichTextBlock::bAutoCollapseWithEmptyText");

// Size: 0x1510 (Inherited: 0x1bd0, Single: 0xfffff940)
class UCommonRotator : public UCommonButtonBase
{
public:
    uint8_t Pad_14a0[0x10]; // 0x14a0 (Size: 0x10, Type: PaddingProperty)
    uint8_t OnRotatedWithDirection[0x10]; // 0x14b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRotated[0x10]; // 0x14c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_14d0[0x18]; // 0x14d0 (Size: 0x18, Type: PaddingProperty)
    UCommonTextBlock* MyText; // 0x14e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_14f0[0x20]; // 0x14f0 (Size: 0x20, Type: PaddingProperty)

public:
    int32_t GetSelectedIndex() const; // 0xb4a7e50 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetSelectedText() const; // 0xb4a7f68 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void PopulateTextLabels(TArray<FText>& Labels); // 0x4cde790 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SetSelectedItem(int32_t& InValue); // 0x4fc5cd4 (Index: 0x5, Flags: Native|Public|BlueprintCallable)
    void ShiftTextLeft(); // 0xb4b1438 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void ShiftTextRight(); // 0xb4b144c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void BP_OnOptionSelected(int32_t& Index); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnOptionsPopulated(int32_t& Count); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCommonRotator) == 0x1510, "Size mismatch for UCommonRotator");
static_assert(offsetof(UCommonRotator, OnRotatedWithDirection) == 0x14b0, "Offset mismatch for UCommonRotator::OnRotatedWithDirection");
static_assert(offsetof(UCommonRotator, OnRotated) == 0x14c0, "Offset mismatch for UCommonRotator::OnRotated");
static_assert(offsetof(UCommonRotator, MyText) == 0x14e8, "Offset mismatch for UCommonRotator::MyText");

// Size: 0x450 (Inherited: 0x730, Single: 0xfffffd20)
class UCommonTabListWidgetBase : public UCommonUserWidget
{
public:
    uint8_t OnTabSelected[0x10]; // 0x2d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTabButtonCreation[0x10]; // 0x2e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTabButtonRemoval[0x10]; // 0x2f8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTabListRebuilt[0x10]; // 0x308 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FDataTableRowHandle NextTabInputActionData; // 0x318 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle PreviousTabInputActionData; // 0x328 (Size: 0x10, Type: StructProperty)
    UInputAction* NextTabEnhancedInputAction; // 0x338 (Size: 0x8, Type: ObjectProperty)
    UInputAction* PreviousTabEnhancedInputAction; // 0x340 (Size: 0x8, Type: ObjectProperty)
    bool bAutoListenForInput; // 0x348 (Size: 0x1, Type: BoolProperty)
    bool bDeferRebuildingTabList; // 0x349 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_34a[0x2]; // 0x34a (Size: 0x2, Type: PaddingProperty)
    TWeakObjectPtr<UCommonAnimatedSwitcher*> LinkedSwitcher; // 0x34c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_354[0x4]; // 0x354 (Size: 0x4, Type: PaddingProperty)
    UCommonButtonGroupBase* TabButtonGroup; // 0x358 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_360[0x8]; // 0x360 (Size: 0x8, Type: PaddingProperty)
    TMap<FCommonRegisteredTabInfo, FName> RegisteredTabsByID; // 0x368 (Size: 0x50, Type: MapProperty)
    FUserWidgetPool TabButtonWidgetPool; // 0x3b8 (Size: 0x88, Type: StructProperty)
    uint8_t Pad_440[0x10]; // 0x440 (Size: 0x10, Type: PaddingProperty)

public:
    void DisableTabWithReason(FName& TabNameID, const FText Reason); // 0xb4a6584 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    FName GetActiveTab() const; // 0x57c31a4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCommonAnimatedSwitcher* GetLinkedSwitcher() const; // 0xb4a76b8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetSelectedTabId() const; // 0x473e408 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCommonButtonBase* GetTabButtonBaseByID(FName& TabNameID) const; // 0x4490d54 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetTabCount() const; // 0x54766d8 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetTabIdAtIndex(int32_t& Index) const; // 0xb4a82d0 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasTabContentWidget(FName& const TabNameID) const; // 0xb4a8edc (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnTabButtonCreation__DelegateSignature(FName& TabID, UCommonButtonBase*& TabButton); // 0x288a61c (Index: 0xf, Flags: MulticastDelegate|Public|Delegate)
    void OnTabButtonRemoval__DelegateSignature(FName& TabID, UCommonButtonBase*& TabButton); // 0x288a61c (Index: 0x10, Flags: MulticastDelegate|Public|Delegate)
    void OnTabListRebuilt__DelegateSignature(); // 0x288a61c (Index: 0x11, Flags: MulticastDelegate|Public|Delegate)
    void OnTabSelected__DelegateSignature(FName& TabID); // 0x288a61c (Index: 0x12, Flags: MulticastDelegate|Public|Delegate)
    bool RegisterTab(FName& TabNameID, UClass*& ButtonWidgetType, UWidget*& ContentWidget, int32_t& const TabIndex); // 0x4fc451c (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)
    bool RegisterTabContentWidget(FName& const TabNameID, UWidget*& ContentWidget); // 0xb4aa428 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveAllTabs(); // 0x473d2c4 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    bool RemoveTab(FName& TabNameID); // 0xb4aa988 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    bool SelectTabByID(FName& TabNameID, bool& bSuppressClickFeedback); // 0x567674c (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void SetLinkedSwitcher(UCommonAnimatedSwitcher*& CommonSwitcher); // 0x6040320 (Index: 0x18, Flags: Native|Public|BlueprintCallable)
    void SetListeningForInput(bool& bShouldListen); // 0xb4adda4 (Index: 0x19, Flags: Native|Public|BlueprintCallable)
    void SetTabEnabled(FName& TabNameID, bool& bEnable); // 0x473c3e4 (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)
    void SetTabInteractionEnabled(FName& TabNameID, bool& bEnable); // 0xb4b09d8 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable)
    void SetTabVisibility(FName& TabNameID, ESlateVisibility& NewVisibility); // 0xb4b0be0 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void HandleNextTabInputAction(bool& bPassThrough); // 0xb4a881c (Index: 0x7, Flags: Final|Native|Protected|HasOutParms)
    virtual void HandlePostLinkedSwitcherChanged_BP(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void HandlePreLinkedSwitcherChanged_BP(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    void HandlePreviousTabInputAction(bool& bPassThrough); // 0xb4a8af8 (Index: 0xa, Flags: Final|Native|Protected|HasOutParms)
    void HandleTabButtonSelected(UCommonButtonBase*& SelectedTabButton, int32_t& ButtonIndex); // 0x562c4ac (Index: 0xb, Flags: Final|Native|Protected)
    virtual void HandleTabCreation(FName& TabNameID, UCommonButtonBase*& TabButton); // 0x4986048 (Index: 0xc, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void HandleTabRemoval(FName& TabNameID, UCommonButtonBase*& TabButton); // 0xb4a8bcc (Index: 0xd, Flags: Native|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCommonTabListWidgetBase) == 0x450, "Size mismatch for UCommonTabListWidgetBase");
static_assert(offsetof(UCommonTabListWidgetBase, OnTabSelected) == 0x2d8, "Offset mismatch for UCommonTabListWidgetBase::OnTabSelected");
static_assert(offsetof(UCommonTabListWidgetBase, OnTabButtonCreation) == 0x2e8, "Offset mismatch for UCommonTabListWidgetBase::OnTabButtonCreation");
static_assert(offsetof(UCommonTabListWidgetBase, OnTabButtonRemoval) == 0x2f8, "Offset mismatch for UCommonTabListWidgetBase::OnTabButtonRemoval");
static_assert(offsetof(UCommonTabListWidgetBase, OnTabListRebuilt) == 0x308, "Offset mismatch for UCommonTabListWidgetBase::OnTabListRebuilt");
static_assert(offsetof(UCommonTabListWidgetBase, NextTabInputActionData) == 0x318, "Offset mismatch for UCommonTabListWidgetBase::NextTabInputActionData");
static_assert(offsetof(UCommonTabListWidgetBase, PreviousTabInputActionData) == 0x328, "Offset mismatch for UCommonTabListWidgetBase::PreviousTabInputActionData");
static_assert(offsetof(UCommonTabListWidgetBase, NextTabEnhancedInputAction) == 0x338, "Offset mismatch for UCommonTabListWidgetBase::NextTabEnhancedInputAction");
static_assert(offsetof(UCommonTabListWidgetBase, PreviousTabEnhancedInputAction) == 0x340, "Offset mismatch for UCommonTabListWidgetBase::PreviousTabEnhancedInputAction");
static_assert(offsetof(UCommonTabListWidgetBase, bAutoListenForInput) == 0x348, "Offset mismatch for UCommonTabListWidgetBase::bAutoListenForInput");
static_assert(offsetof(UCommonTabListWidgetBase, bDeferRebuildingTabList) == 0x349, "Offset mismatch for UCommonTabListWidgetBase::bDeferRebuildingTabList");
static_assert(offsetof(UCommonTabListWidgetBase, LinkedSwitcher) == 0x34c, "Offset mismatch for UCommonTabListWidgetBase::LinkedSwitcher");
static_assert(offsetof(UCommonTabListWidgetBase, TabButtonGroup) == 0x358, "Offset mismatch for UCommonTabListWidgetBase::TabButtonGroup");
static_assert(offsetof(UCommonTabListWidgetBase, RegisteredTabsByID) == 0x368, "Offset mismatch for UCommonTabListWidgetBase::RegisteredTabsByID");
static_assert(offsetof(UCommonTabListWidgetBase, TabButtonWidgetPool) == 0x3b8, "Offset mismatch for UCommonTabListWidgetBase::TabButtonWidgetPool");

// Size: 0x190 (Inherited: 0x28, Single: 0x168)
class UCommonTextStyle : public UObject
{
public:
    FSlateFontInfo Font; // 0x28 (Size: 0x58, Type: StructProperty)
    FLinearColor Color; // 0x80 (Size: 0x10, Type: StructProperty)
    bool bUsesDropShadow; // 0x90 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
    FVector2D ShadowOffset; // 0x98 (Size: 0x10, Type: StructProperty)
    FLinearColor ShadowColor; // 0xa8 (Size: 0x10, Type: StructProperty)
    FMargin Margin; // 0xb8 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush StrikeBrush; // 0xd0 (Size: 0xb0, Type: StructProperty)
    float LineHeightPercentage; // 0x180 (Size: 0x4, Type: FloatProperty)
    bool ApplyLineHeightToBottomLine; // 0x184 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_185[0xb]; // 0x185 (Size: 0xb, Type: PaddingProperty)

public:
    bool GetApplyLineHeightToBottomLine() const; // 0xb4a6914 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetColor(FLinearColor& OutColor) const; // 0xb4a6c4c (Index: 0x1, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    void GetFont(FSlateFontInfo& OutFont) const; // 0xb4a73a8 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    float GetLineHeightPercentage() const; // 0xa2b9a20 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetMargin(FMargin& OutMargin) const; // 0xb4a76f8 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetShadowColor(FLinearColor& OutColor) const; // 0xb4a7fc8 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    void GetShadowOffset(FVector2D& OutShadowOffset) const; // 0xb4a80ac (Index: 0x6, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    void GetStrikeBrush(FSlateBrush& OutStrikeBrush) const; // 0xb4a81ac (Index: 0x7, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UCommonTextStyle) == 0x190, "Size mismatch for UCommonTextStyle");
static_assert(offsetof(UCommonTextStyle, Font) == 0x28, "Offset mismatch for UCommonTextStyle::Font");
static_assert(offsetof(UCommonTextStyle, Color) == 0x80, "Offset mismatch for UCommonTextStyle::Color");
static_assert(offsetof(UCommonTextStyle, bUsesDropShadow) == 0x90, "Offset mismatch for UCommonTextStyle::bUsesDropShadow");
static_assert(offsetof(UCommonTextStyle, ShadowOffset) == 0x98, "Offset mismatch for UCommonTextStyle::ShadowOffset");
static_assert(offsetof(UCommonTextStyle, ShadowColor) == 0xa8, "Offset mismatch for UCommonTextStyle::ShadowColor");
static_assert(offsetof(UCommonTextStyle, Margin) == 0xb8, "Offset mismatch for UCommonTextStyle::Margin");
static_assert(offsetof(UCommonTextStyle, StrikeBrush) == 0xd0, "Offset mismatch for UCommonTextStyle::StrikeBrush");
static_assert(offsetof(UCommonTextStyle, LineHeightPercentage) == 0x180, "Offset mismatch for UCommonTextStyle::LineHeightPercentage");
static_assert(offsetof(UCommonTextStyle, ApplyLineHeightToBottomLine) == 0x184, "Offset mismatch for UCommonTextStyle::ApplyLineHeightToBottomLine");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UCommonTextScrollStyle : public UObject
{
public:
    float Speed; // 0x28 (Size: 0x4, Type: FloatProperty)
    float StartDelay; // 0x2c (Size: 0x4, Type: FloatProperty)
    float EndDelay; // 0x30 (Size: 0x4, Type: FloatProperty)
    float FadeInDelay; // 0x34 (Size: 0x4, Type: FloatProperty)
    float FadeOutDelay; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Clipping; // 0x3c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3d[0x3]; // 0x3d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UCommonTextScrollStyle) == 0x40, "Size mismatch for UCommonTextScrollStyle");
static_assert(offsetof(UCommonTextScrollStyle, Speed) == 0x28, "Offset mismatch for UCommonTextScrollStyle::Speed");
static_assert(offsetof(UCommonTextScrollStyle, StartDelay) == 0x2c, "Offset mismatch for UCommonTextScrollStyle::StartDelay");
static_assert(offsetof(UCommonTextScrollStyle, EndDelay) == 0x30, "Offset mismatch for UCommonTextScrollStyle::EndDelay");
static_assert(offsetof(UCommonTextScrollStyle, FadeInDelay) == 0x34, "Offset mismatch for UCommonTextScrollStyle::FadeInDelay");
static_assert(offsetof(UCommonTextScrollStyle, FadeOutDelay) == 0x38, "Offset mismatch for UCommonTextScrollStyle::FadeOutDelay");
static_assert(offsetof(UCommonTextScrollStyle, Clipping) == 0x3c, "Offset mismatch for UCommonTextScrollStyle::Clipping");

// Size: 0xb90 (Inherited: 0x1b28, Single: 0xfffff068)
class UCommonTileView : public UTileView
{
public:
};

static_assert(sizeof(UCommonTileView) == 0xb90, "Size mismatch for UCommonTileView");

// Size: 0xbc0 (Inherited: 0x1b58, Single: 0xfffff068)
class UCommonTreeView : public UTreeView
{
public:
};

static_assert(sizeof(UCommonTreeView) == 0xbc0, "Size mismatch for UCommonTreeView");

// Size: 0x90 (Inherited: 0x28, Single: 0x68)
class UCommonUIEditorSettings : public UObject
{
public:
    TSoftClassPtr TemplateTextStyle; // 0x28 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr TemplateButtonStyle; // 0x48 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr TemplateBorderStyle; // 0x68 (Size: 0x20, Type: SoftClassProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UCommonUIEditorSettings) == 0x90, "Size mismatch for UCommonUIEditorSettings");
static_assert(offsetof(UCommonUIEditorSettings, TemplateTextStyle) == 0x28, "Offset mismatch for UCommonUIEditorSettings::TemplateTextStyle");
static_assert(offsetof(UCommonUIEditorSettings, TemplateButtonStyle) == 0x48, "Offset mismatch for UCommonUIEditorSettings::TemplateButtonStyle");
static_assert(offsetof(UCommonUIEditorSettings, TemplateBorderStyle) == 0x68, "Offset mismatch for UCommonUIEditorSettings::TemplateBorderStyle");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCommonUILibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static UWidget* FindParentWidgetOfType(UWidget*& StartingWidget, UClass*& Type); // 0x560dffc (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonUILibrary) == 0x28, "Size mismatch for UCommonUILibrary");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UCommonUIRichTextData : public UObject
{
public:
    UDataTable* InlineIconSet; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UCommonUIRichTextData) == 0x30, "Size mismatch for UCommonUIRichTextData");
static_assert(offsetof(UCommonUIRichTextData, InlineIconSet) == 0x28, "Offset mismatch for UCommonUIRichTextData::InlineIconSet");

// Size: 0x1a0 (Inherited: 0x28, Single: 0x178)
class UCommonUISettings : public UObject
{
public:
    bool bAutoLoadData; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    TSoftObjectPtr<UObject*> DefaultImageResourceObject; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInterface*> DefaultThrobberMaterial; // 0x50 (Size: 0x20, Type: SoftObjectProperty)
    TSoftClassPtr DefaultRichTextDataClass; // 0x70 (Size: 0x20, Type: SoftClassProperty)
    TArray<FGameplayTag> PlatformTraits; // 0x90 (Size: 0x10, Type: ArrayProperty)
    uint8_t CommonButtonAcceptKeyHandling[0x4]; // 0xa0 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_a4[0x24]; // 0xa4 (Size: 0x24, Type: PaddingProperty)
    UObject* DefaultImageResourceObjectInstance; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* DefaultThrobberMaterialInstance; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d8[0x8]; // 0xd8 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush DefaultThrobberBrush; // 0xe0 (Size: 0xb0, Type: StructProperty)
    UCommonUIRichTextData* RichTextDataInstance; // 0x190 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_198[0x8]; // 0x198 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UCommonUISettings) == 0x1a0, "Size mismatch for UCommonUISettings");
static_assert(offsetof(UCommonUISettings, bAutoLoadData) == 0x28, "Offset mismatch for UCommonUISettings::bAutoLoadData");
static_assert(offsetof(UCommonUISettings, DefaultImageResourceObject) == 0x30, "Offset mismatch for UCommonUISettings::DefaultImageResourceObject");
static_assert(offsetof(UCommonUISettings, DefaultThrobberMaterial) == 0x50, "Offset mismatch for UCommonUISettings::DefaultThrobberMaterial");
static_assert(offsetof(UCommonUISettings, DefaultRichTextDataClass) == 0x70, "Offset mismatch for UCommonUISettings::DefaultRichTextDataClass");
static_assert(offsetof(UCommonUISettings, PlatformTraits) == 0x90, "Offset mismatch for UCommonUISettings::PlatformTraits");
static_assert(offsetof(UCommonUISettings, CommonButtonAcceptKeyHandling) == 0xa0, "Offset mismatch for UCommonUISettings::CommonButtonAcceptKeyHandling");
static_assert(offsetof(UCommonUISettings, DefaultImageResourceObjectInstance) == 0xc8, "Offset mismatch for UCommonUISettings::DefaultImageResourceObjectInstance");
static_assert(offsetof(UCommonUISettings, DefaultThrobberMaterialInstance) == 0xd0, "Offset mismatch for UCommonUISettings::DefaultThrobberMaterialInstance");
static_assert(offsetof(UCommonUISettings, DefaultThrobberBrush) == 0xe0, "Offset mismatch for UCommonUISettings::DefaultThrobberBrush");
static_assert(offsetof(UCommonUISettings, RichTextDataInstance) == 0x190, "Offset mismatch for UCommonUISettings::RichTextDataInstance");

// Size: 0x40 (Inherited: 0x88, Single: 0xffffffb8)
class UCommonUISubsystemBase : public UGameInstanceSubsystem
{
public:

public:
    FSlateBrush GetEnhancedInputActionButtonIcon(UInputAction*& const InputAction, ULocalPlayer*& const LocalPlayer) const; // 0xb4a7164 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FSlateBrush GetInputActionButtonIcon(const FDataTableRowHandle InputActionRowHandle, ECommonInputType& InputType, const FName GamepadName) const; // 0xb4a74a8 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UCommonUISubsystemBase) == 0x40, "Size mismatch for UCommonUISubsystemBase");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UCommonInputMetadata : public UObject
{
public:
    int32_t NavBarPriority; // 0x28 (Size: 0x4, Type: IntProperty)
    bool bIsGenericInputAction; // 0x2c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UCommonInputMetadata) == 0x30, "Size mismatch for UCommonInputMetadata");
static_assert(offsetof(UCommonInputMetadata, NavBarPriority) == 0x28, "Offset mismatch for UCommonInputMetadata::NavBarPriority");
static_assert(offsetof(UCommonInputMetadata, bIsGenericInputAction) == 0x2c, "Offset mismatch for UCommonInputMetadata::bIsGenericInputAction");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCommonMappingContextMetadataInterface : public UInterface
{
public:
};

static_assert(sizeof(UCommonMappingContextMetadataInterface) == 0x28, "Size mismatch for UCommonMappingContextMetadataInterface");

// Size: 0x90 (Inherited: 0x58, Single: 0x38)
class UCommonMappingContextMetadata : public UDataAsset
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    UCommonInputMetadata* EnhancedInputMetadata; // 0x38 (Size: 0x8, Type: ObjectProperty)
    TMap<UCommonInputMetadata*, UInputAction*> PerActionEnhancedInputMetadata; // 0x40 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UCommonMappingContextMetadata) == 0x90, "Size mismatch for UCommonMappingContextMetadata");
static_assert(offsetof(UCommonMappingContextMetadata, EnhancedInputMetadata) == 0x38, "Offset mismatch for UCommonMappingContextMetadata::EnhancedInputMetadata");
static_assert(offsetof(UCommonMappingContextMetadata, PerActionEnhancedInputMetadata) == 0x40, "Offset mismatch for UCommonMappingContextMetadata::PerActionEnhancedInputMetadata");

// Size: 0x88 (Inherited: 0x88, Single: 0x0)
class UCommonUIVisibilitySubsystem : public ULocalPlayerSubsystem
{
public:
};

static_assert(sizeof(UCommonUIVisibilitySubsystem) == 0x88, "Size mismatch for UCommonUIVisibilitySubsystem");

// Size: 0x2a0 (Inherited: 0x1a8, Single: 0xf8)
class UCommonVideoPlayer : public UWidget
{
public:
    UMediaSource* Video; // 0x158 (Size: 0x8, Type: ObjectProperty)
    bool bMatchSize; // 0x160 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_161[0x7]; // 0x161 (Size: 0x7, Type: PaddingProperty)
    UMediaPlayer* MediaPlayer; // 0x168 (Size: 0x8, Type: ObjectProperty)
    UMediaTexture* MediaTexture; // 0x170 (Size: 0x8, Type: ObjectProperty)
    UMaterial* VideoMaterial; // 0x178 (Size: 0x8, Type: ObjectProperty)
    UMediaSoundComponent* SoundComponent; // 0x180 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_188[0x8]; // 0x188 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush VideoBrush; // 0x190 (Size: 0xb0, Type: StructProperty)
    uint8_t Pad_240[0x60]; // 0x240 (Size: 0x60, Type: PaddingProperty)

public:
    void Close(); // 0xb4a633c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    float GetPlaybackRate() const; // 0xb4a7b4c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPlaybackTime() const; // 0xb4a7b80 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetVideoDuration() const; // 0xb4a8438 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsLooping() const; // 0xb4a9630 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsMuted() const; // 0xb4a965c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPaused() const; // 0xb4a9674 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPlaying() const; // 0xb4a96a0 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void Pause(); // 0xb4aa274 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void Play(); // 0xb4aa290 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void PlayFromStart(); // 0xb4aa2b4 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void Reverse(); // 0xb4aad88 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void Seek(float& PlaybackTime); // 0xb4aadac (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    void SetIsMuted(bool& bInIsMuted); // 0xb4ad5f4 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    void SetLooping(bool& bShouldLoopPlayback); // 0xb4ae8e4 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    void SetPlaybackRate(float& PlaybackRate); // 0xb4af028 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    void SetShouldMatchSize(bool& bInMatchSize); // 0xb4b043c (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    void SetVideo(UMediaSource*& NewVideo); // 0xb4b130c (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonVideoPlayer) == 0x2a0, "Size mismatch for UCommonVideoPlayer");
static_assert(offsetof(UCommonVideoPlayer, Video) == 0x158, "Offset mismatch for UCommonVideoPlayer::Video");
static_assert(offsetof(UCommonVideoPlayer, bMatchSize) == 0x160, "Offset mismatch for UCommonVideoPlayer::bMatchSize");
static_assert(offsetof(UCommonVideoPlayer, MediaPlayer) == 0x168, "Offset mismatch for UCommonVideoPlayer::MediaPlayer");
static_assert(offsetof(UCommonVideoPlayer, MediaTexture) == 0x170, "Offset mismatch for UCommonVideoPlayer::MediaTexture");
static_assert(offsetof(UCommonVideoPlayer, VideoMaterial) == 0x178, "Offset mismatch for UCommonVideoPlayer::VideoMaterial");
static_assert(offsetof(UCommonVideoPlayer, SoundComponent) == 0x180, "Offset mismatch for UCommonVideoPlayer::SoundComponent");
static_assert(offsetof(UCommonVideoPlayer, VideoBrush) == 0x190, "Offset mismatch for UCommonVideoPlayer::VideoBrush");

// Size: 0x1a8 (Inherited: 0x498, Single: 0xfffffd10)
class UCommonVisibilitySwitcher : public UOverlay
{
public:
    uint8_t ShownVisibility; // 0x180 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_181[0x3]; // 0x181 (Size: 0x3, Type: PaddingProperty)
    int32_t ActiveWidgetIndex; // 0x184 (Size: 0x4, Type: IntProperty)
    bool bAutoActivateSlot; // 0x188 (Size: 0x1, Type: BoolProperty)
    bool bActivateFirstSlotOnAdding; // 0x189 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_18a[0x1e]; // 0x18a (Size: 0x1e, Type: PaddingProperty)

public:
    void ActivateVisibleSlot(); // 0xb4a5284 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void DeactivateVisibleSlot(); // 0xb4a6350 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void DecrementActiveWidgetIndex(bool& bAllowWrapping); // 0xb4a6364 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    UWidget* GetActiveWidget() const; // 0xb4a68d0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetActiveWidgetIndex() const; // 0x561a778 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void IncrementActiveWidgetIndex(bool& bAllowWrapping); // 0xb4a902c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    bool IsCurrentlySwitching() const; // 0xb4a952c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetActiveWidget(UWidget*& const Widget); // 0x485e674 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void SetActiveWidgetIndex(int32_t& Index); // 0x5386498 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonVisibilitySwitcher) == 0x1a8, "Size mismatch for UCommonVisibilitySwitcher");
static_assert(offsetof(UCommonVisibilitySwitcher, ShownVisibility) == 0x180, "Offset mismatch for UCommonVisibilitySwitcher::ShownVisibility");
static_assert(offsetof(UCommonVisibilitySwitcher, ActiveWidgetIndex) == 0x184, "Offset mismatch for UCommonVisibilitySwitcher::ActiveWidgetIndex");
static_assert(offsetof(UCommonVisibilitySwitcher, bAutoActivateSlot) == 0x188, "Offset mismatch for UCommonVisibilitySwitcher::bAutoActivateSlot");
static_assert(offsetof(UCommonVisibilitySwitcher, bActivateFirstSlotOnAdding) == 0x189, "Offset mismatch for UCommonVisibilitySwitcher::bActivateFirstSlotOnAdding");

// Size: 0x68 (Inherited: 0xe0, Single: 0xffffff88)
class UCommonVisibilitySwitcherSlot : public UOverlaySlot
{
public:
};

static_assert(sizeof(UCommonVisibilitySwitcherSlot) == 0x68, "Size mismatch for UCommonVisibilitySwitcherSlot");

// Size: 0x350 (Inherited: 0xa48, Single: 0xfffff908)
class UUCommonVisibilityWidgetBase : public UCommonBorder
{
public:
    TMap<bool, FName> VisibilityControls; // 0x2f0 (Size: 0x50, Type: MapProperty)
    bool bShowForGamepad; // 0x340 (Size: 0x1, Type: BoolProperty)
    bool bShowForMouseAndKeyboard; // 0x341 (Size: 0x1, Type: BoolProperty)
    bool bShowForTouch; // 0x342 (Size: 0x1, Type: BoolProperty)
    uint8_t VisibleType; // 0x343 (Size: 0x1, Type: EnumProperty)
    uint8_t HiddenType; // 0x344 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_345[0xb]; // 0x345 (Size: 0xb, Type: PaddingProperty)

protected:
    static TArray<FName> GetRegisteredPlatforms(); // 0xb4a7ba8 (Index: 0x0, Flags: Final|Native|Static|Protected)
};

static_assert(sizeof(UUCommonVisibilityWidgetBase) == 0x350, "Size mismatch for UUCommonVisibilityWidgetBase");
static_assert(offsetof(UUCommonVisibilityWidgetBase, VisibilityControls) == 0x2f0, "Offset mismatch for UUCommonVisibilityWidgetBase::VisibilityControls");
static_assert(offsetof(UUCommonVisibilityWidgetBase, bShowForGamepad) == 0x340, "Offset mismatch for UUCommonVisibilityWidgetBase::bShowForGamepad");
static_assert(offsetof(UUCommonVisibilityWidgetBase, bShowForMouseAndKeyboard) == 0x341, "Offset mismatch for UUCommonVisibilityWidgetBase::bShowForMouseAndKeyboard");
static_assert(offsetof(UUCommonVisibilityWidgetBase, bShowForTouch) == 0x342, "Offset mismatch for UUCommonVisibilityWidgetBase::bShowForTouch");
static_assert(offsetof(UUCommonVisibilityWidgetBase, VisibleType) == 0x343, "Offset mismatch for UUCommonVisibilityWidgetBase::VisibleType");
static_assert(offsetof(UUCommonVisibilityWidgetBase, HiddenType) == 0x344, "Offset mismatch for UUCommonVisibilityWidgetBase::HiddenType");

// Size: 0x1c8 (Inherited: 0x630, Single: 0xfffffb98)
class UCommonVisualAttachment : public USizeBox
{
public:
    FVector2D ContentAnchor; // 0x1a8 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_1b8[0x10]; // 0x1b8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UCommonVisualAttachment) == 0x1c8, "Size mismatch for UCommonVisualAttachment");
static_assert(offsetof(UCommonVisualAttachment, ContentAnchor) == 0x1a8, "Offset mismatch for UCommonVisualAttachment::ContentAnchor");

// Size: 0x1b8 (Inherited: 0x318, Single: 0xfffffea0)
class UCommonWidgetCarousel : public UPanelWidget
{
public:
    int32_t ActiveWidgetIndex; // 0x170 (Size: 0x4, Type: IntProperty)
    float MoveSpeed; // 0x174 (Size: 0x4, Type: FloatProperty)
    uint8_t OnCurrentPageIndexChanged[0x10]; // 0x178 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_188[0x30]; // 0x188 (Size: 0x30, Type: PaddingProperty)

public:
    void BeginAutoScrolling(float& ScrollInterval); // 0xb4a5cd8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void EndAutoScrolling(); // 0xb4a6760 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    int32_t GetActiveWidgetIndex() const; // 0xb4a68f4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetMoveSpeed() const; // 0xb4a77e4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UWidget* GetWidgetAtIndex(int32_t& Index) const; // 0xb4a8460 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void NextPage(); // 0xb4a9b18 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void PreviousPage(); // 0xb4aa2f0 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void SetActiveWidget(UWidget*& Widget); // 0x3964b28 (Index: 0x7, Flags: Native|Public|BlueprintCallable)
    void SetActiveWidgetIndex(int32_t& Index); // 0x3de481c (Index: 0x8, Flags: Native|Public|BlueprintCallable)
    void SetMoveSpeed(float& InMoveSpeed); // 0xb4aecfc (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonWidgetCarousel) == 0x1b8, "Size mismatch for UCommonWidgetCarousel");
static_assert(offsetof(UCommonWidgetCarousel, ActiveWidgetIndex) == 0x170, "Offset mismatch for UCommonWidgetCarousel::ActiveWidgetIndex");
static_assert(offsetof(UCommonWidgetCarousel, MoveSpeed) == 0x174, "Offset mismatch for UCommonWidgetCarousel::MoveSpeed");
static_assert(offsetof(UCommonWidgetCarousel, OnCurrentPageIndexChanged) == 0x178, "Offset mismatch for UCommonWidgetCarousel::OnCurrentPageIndexChanged");

// Size: 0x1a0 (Inherited: 0x1a8, Single: 0xfffffff8)
class UCommonWidgetCarouselNavBar : public UWidget
{
public:
    UClass* ButtonWidgetType; // 0x158 (Size: 0x8, Type: ClassProperty)
    FMargin ButtonPadding; // 0x160 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_170[0x10]; // 0x170 (Size: 0x10, Type: PaddingProperty)
    UCommonWidgetCarousel* LinkedCarousel; // 0x180 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonGroupBase* ButtonGroup; // 0x188 (Size: 0x8, Type: ObjectProperty)
    TArray<UCommonButtonBase*> Buttons; // 0x190 (Size: 0x10, Type: ArrayProperty)

public:
    void SetLinkedCarousel(UCommonWidgetCarousel*& CommonCarousel); // 0xb4adc78 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void HandleButtonClicked(UCommonButtonBase*& AssociatedButton, int32_t& ButtonIndex); // 0xb4a85cc (Index: 0x0, Flags: Final|Native|Protected)
    void HandlePageChanged(UCommonWidgetCarousel*& CommonCarousel, int32_t& PageIndex); // 0xb4a88f0 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UCommonWidgetCarouselNavBar) == 0x1a0, "Size mismatch for UCommonWidgetCarouselNavBar");
static_assert(offsetof(UCommonWidgetCarouselNavBar, ButtonWidgetType) == 0x158, "Offset mismatch for UCommonWidgetCarouselNavBar::ButtonWidgetType");
static_assert(offsetof(UCommonWidgetCarouselNavBar, ButtonPadding) == 0x160, "Offset mismatch for UCommonWidgetCarouselNavBar::ButtonPadding");
static_assert(offsetof(UCommonWidgetCarouselNavBar, LinkedCarousel) == 0x180, "Offset mismatch for UCommonWidgetCarouselNavBar::LinkedCarousel");
static_assert(offsetof(UCommonWidgetCarouselNavBar, ButtonGroup) == 0x188, "Offset mismatch for UCommonWidgetCarouselNavBar::ButtonGroup");
static_assert(offsetof(UCommonWidgetCarouselNavBar, Buttons) == 0x190, "Offset mismatch for UCommonWidgetCarouselNavBar::Buttons");

// Size: 0x160 (Inherited: 0x50, Single: 0x110)
class UCommonButtonGroupBase : public UCommonWidgetGroupBase
{
public:
    uint8_t OnSelectedButtonBaseChanged[0x10]; // 0x28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_38[0x18]; // 0x38 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnHoveredButtonBaseChanged[0x10]; // 0x50 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_60[0x18]; // 0x60 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnButtonBaseClicked[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_88[0x18]; // 0x88 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnButtonBaseDoubleClicked[0x10]; // 0xa0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_b0[0x18]; // 0xb0 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnSelectionCleared[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_d8[0x18]; // 0xd8 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnButtonBaseLockClicked[0x10]; // 0xf0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_100[0x18]; // 0x100 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnButtonBaseLockDoubleClicked[0x10]; // 0x118 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_128[0x18]; // 0x128 (Size: 0x18, Type: PaddingProperty)
    bool bSelectionRequired; // 0x140 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_141[0x1f]; // 0x141 (Size: 0x1f, Type: PaddingProperty)

public:
    void DeselectAll(); // 0x605fc30 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    int32_t FindButtonIndex(UCommonButtonBase*& const ButtonToFind) const; // 0xb4a6774 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCommonButtonBase* GetButtonBaseAtIndex(int32_t& Index) const; // 0xb4a6a28 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetButtonCount() const; // 0xb4a6b60 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetHoveredButtonIndex() const; // 0xb4a7490 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCommonButtonBase* GetSelectedButtonBase() const; // 0xb4a7d08 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetSelectedButtonIndex() const; // 0xa12db20 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasAnyButtons() const; // 0xb4a8ec0 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SelectButtonAtIndex(int32_t& ButtonIndex, bool& const bAllowSound); // 0xb4aaed8 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    void SelectNextButton(bool& bAllowWrap); // 0xb4ab0e0 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    void SelectPreviousButton(bool& bAllowWrap); // 0xb4ab20c (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
    void SetSelectionRequired(bool& bRequireSelection); // 0xb4b0310 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnButtonBaseHovered(UCommonButtonBase*& BaseButton); // 0xb4a9b40 (Index: 0x8, Flags: Native|Protected)
    void OnButtonBaseUnhovered(UCommonButtonBase*& BaseButton); // 0xb4a9c70 (Index: 0x9, Flags: Native|Protected)
    void OnHandleButtonBaseClicked(UCommonButtonBase*& BaseButton); // 0xa20aad8 (Index: 0xa, Flags: Native|Protected)
    void OnHandleButtonBaseDoubleClicked(UCommonButtonBase*& BaseButton); // 0xb4a9da0 (Index: 0xb, Flags: Native|Protected)
    void OnHandleButtonBaseLockClicked(UCommonButtonBase*& BaseButton); // 0xb4a9ed0 (Index: 0xc, Flags: Native|Protected)
    void OnHandleButtonBaseLockDoubleClicked(UCommonButtonBase*& BaseButton); // 0xb4aa000 (Index: 0xd, Flags: Native|Protected)
    void OnSelectionStateChangedBase(UCommonButtonBase*& BaseButton, bool& bIsSelected); // 0x5086974 (Index: 0xe, Flags: Native|Protected)
};

static_assert(sizeof(UCommonButtonGroupBase) == 0x160, "Size mismatch for UCommonButtonGroupBase");
static_assert(offsetof(UCommonButtonGroupBase, OnSelectedButtonBaseChanged) == 0x28, "Offset mismatch for UCommonButtonGroupBase::OnSelectedButtonBaseChanged");
static_assert(offsetof(UCommonButtonGroupBase, OnHoveredButtonBaseChanged) == 0x50, "Offset mismatch for UCommonButtonGroupBase::OnHoveredButtonBaseChanged");
static_assert(offsetof(UCommonButtonGroupBase, OnButtonBaseClicked) == 0x78, "Offset mismatch for UCommonButtonGroupBase::OnButtonBaseClicked");
static_assert(offsetof(UCommonButtonGroupBase, OnButtonBaseDoubleClicked) == 0xa0, "Offset mismatch for UCommonButtonGroupBase::OnButtonBaseDoubleClicked");
static_assert(offsetof(UCommonButtonGroupBase, OnSelectionCleared) == 0xc8, "Offset mismatch for UCommonButtonGroupBase::OnSelectionCleared");
static_assert(offsetof(UCommonButtonGroupBase, OnButtonBaseLockClicked) == 0xf0, "Offset mismatch for UCommonButtonGroupBase::OnButtonBaseLockClicked");
static_assert(offsetof(UCommonButtonGroupBase, OnButtonBaseLockDoubleClicked) == 0x118, "Offset mismatch for UCommonButtonGroupBase::OnButtonBaseLockDoubleClicked");
static_assert(offsetof(UCommonButtonGroupBase, bSelectionRequired) == 0x140, "Offset mismatch for UCommonButtonGroupBase::bSelectionRequired");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UCommonWidgetGroupBase : public UObject
{
public:

public:
    void AddWidget(UWidget*& InWidget); // 0x58f4640 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void AddWidgets(const TArray<UWidget*> Widgets); // 0xb4a5298 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void RemoveAll(); // 0x472ef98 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveWidget(UWidget*& InWidget); // 0xb4aabe4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonWidgetGroupBase) == 0x28, "Size mismatch for UCommonWidgetGroupBase");

// Size: 0x260 (Inherited: 0x3e0, Single: 0xfffffe80)
class UCommonBoundActionBar : public UDynamicEntryBoxBase
{
public:
    UClass* ActionButtonClass; // 0x238 (Size: 0x8, Type: ClassProperty)
    bool bDisplayOwningPlayerActionsOnly; // 0x240 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreDuplicateActions; // 0x241 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_242[0x6]; // 0x242 (Size: 0x6, Type: PaddingProperty)
    uint8_t OnActionBarUpdated[0x10]; // 0x248 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_258[0x8]; // 0x258 (Size: 0x8, Type: PaddingProperty)

public:
    void SetDisplayOwningPlayerActionsOnly(bool& bShouldOnlyDisplayOwningPlayerActions); // 0x438527c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)

private:
    void HandleInputMappingsRebuiltUpdated(); // 0x5ac812c (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UCommonBoundActionBar) == 0x260, "Size mismatch for UCommonBoundActionBar");
static_assert(offsetof(UCommonBoundActionBar, ActionButtonClass) == 0x238, "Offset mismatch for UCommonBoundActionBar::ActionButtonClass");
static_assert(offsetof(UCommonBoundActionBar, bDisplayOwningPlayerActionsOnly) == 0x240, "Offset mismatch for UCommonBoundActionBar::bDisplayOwningPlayerActionsOnly");
static_assert(offsetof(UCommonBoundActionBar, bIgnoreDuplicateActions) == 0x241, "Offset mismatch for UCommonBoundActionBar::bIgnoreDuplicateActions");
static_assert(offsetof(UCommonBoundActionBar, OnActionBarUpdated) == 0x248, "Offset mismatch for UCommonBoundActionBar::OnActionBarUpdated");

// Size: 0x14c0 (Inherited: 0x1bd0, Single: 0xfffff8f0)
class UCommonBoundActionButton : public UCommonButtonBase
{
public:
    uint8_t Pad_14a0[0x8]; // 0x14a0 (Size: 0x8, Type: PaddingProperty)
    UCommonTextBlock* Text_ActionName; // 0x14a8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_14b0[0x10]; // 0x14b0 (Size: 0x10, Type: PaddingProperty)

protected:
    virtual void OnUpdateInputAction(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCommonBoundActionButton) == 0x14c0, "Size mismatch for UCommonBoundActionButton");
static_assert(offsetof(UCommonBoundActionButton, Text_ActionName) == 0x14a8, "Offset mismatch for UCommonBoundActionButton::Text_ActionName");

// Size: 0xb0 (Inherited: 0xd8, Single: 0xffffffd8)
class UCommonGenericInputActionDataTable : public UDataTable
{
public:
};

static_assert(sizeof(UCommonGenericInputActionDataTable) == 0xb0, "Size mismatch for UCommonGenericInputActionDataTable");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UCommonInputActionDataProcessor : public UObject
{
public:
};

static_assert(sizeof(UCommonInputActionDataProcessor) == 0x28, "Size mismatch for UCommonInputActionDataProcessor");

// Size: 0x1d8 (Inherited: 0x88, Single: 0x150)
class UCommonUIActionRouterBase : public ULocalPlayerSubsystem
{
public:
};

static_assert(sizeof(UCommonUIActionRouterBase) == 0x1d8, "Size mismatch for UCommonUIActionRouterBase");

// Size: 0x80 (Inherited: 0x28, Single: 0x58)
class UCommonUIInputSettings : public UObject
{
public:
    bool bLinkCursorToGamepadFocus; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    int32_t UIActionProcessingPriority; // 0x2c (Size: 0x4, Type: IntProperty)
    TArray<FUIInputAction> InputActions; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FUIInputAction> ActionOverrides; // 0x40 (Size: 0x10, Type: ArrayProperty)
    FCommonAnalogCursorSettings AnalogCursorSettings; // 0x50 (Size: 0x2c, Type: StructProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UCommonUIInputSettings) == 0x80, "Size mismatch for UCommonUIInputSettings");
static_assert(offsetof(UCommonUIInputSettings, bLinkCursorToGamepadFocus) == 0x28, "Offset mismatch for UCommonUIInputSettings::bLinkCursorToGamepadFocus");
static_assert(offsetof(UCommonUIInputSettings, UIActionProcessingPriority) == 0x2c, "Offset mismatch for UCommonUIInputSettings::UIActionProcessingPriority");
static_assert(offsetof(UCommonUIInputSettings, InputActions) == 0x30, "Offset mismatch for UCommonUIInputSettings::InputActions");
static_assert(offsetof(UCommonUIInputSettings, ActionOverrides) == 0x40, "Offset mismatch for UCommonUIInputSettings::ActionOverrides");
static_assert(offsetof(UCommonUIInputSettings, AnalogCursorSettings) == 0x50, "Offset mismatch for UCommonUIInputSettings::AnalogCursorSettings");

// Size: 0x280 (Inherited: 0x1a8, Single: 0xd8)
class UCommonActivatableWidgetContainerBase : public UWidget
{
public:
    uint8_t Pad_158[0x18]; // 0x158 (Size: 0x18, Type: PaddingProperty)
    uint8_t TransitionType; // 0x170 (Size: 0x1, Type: EnumProperty)
    uint8_t TransitionCurveType; // 0x171 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_172[0x2]; // 0x172 (Size: 0x2, Type: PaddingProperty)
    float TransitionDuration; // 0x174 (Size: 0x4, Type: FloatProperty)
    uint8_t TransitionFallbackStrategy; // 0x178 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_179[0x7]; // 0x179 (Size: 0x7, Type: PaddingProperty)
    TArray<UCommonActivatableWidget*> WidgetList; // 0x180 (Size: 0x10, Type: ArrayProperty)
    UCommonActivatableWidget* DisplayedWidget; // 0x190 (Size: 0x8, Type: ObjectProperty)
    FUserWidgetPool GeneratedWidgetsPool; // 0x198 (Size: 0x88, Type: StructProperty)
    uint8_t Pad_220[0x60]; // 0x220 (Size: 0x60, Type: PaddingProperty)

public:
    void ClearWidgets(); // 0xb4a6328 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    UCommonActivatableWidget* GetActiveWidget() const; // 0xb4a68ac (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTransitionDuration() const; // 0xb4a8420 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetTransitionDuration(float& duration); // 0xb4b0fd8 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

private:
    UCommonActivatableWidget* BP_AddWidget(UClass*& ActivatableWidgetClass); // 0xb4a5524 (Index: 0x0, Flags: Final|Native|Private|BlueprintCallable)
    void RemoveWidget(UCommonActivatableWidget*& WidgetToRemove); // 0xb4aaac0 (Index: 0x4, Flags: Final|Native|Private|BlueprintCallable)
};

static_assert(sizeof(UCommonActivatableWidgetContainerBase) == 0x280, "Size mismatch for UCommonActivatableWidgetContainerBase");
static_assert(offsetof(UCommonActivatableWidgetContainerBase, TransitionType) == 0x170, "Offset mismatch for UCommonActivatableWidgetContainerBase::TransitionType");
static_assert(offsetof(UCommonActivatableWidgetContainerBase, TransitionCurveType) == 0x171, "Offset mismatch for UCommonActivatableWidgetContainerBase::TransitionCurveType");
static_assert(offsetof(UCommonActivatableWidgetContainerBase, TransitionDuration) == 0x174, "Offset mismatch for UCommonActivatableWidgetContainerBase::TransitionDuration");
static_assert(offsetof(UCommonActivatableWidgetContainerBase, TransitionFallbackStrategy) == 0x178, "Offset mismatch for UCommonActivatableWidgetContainerBase::TransitionFallbackStrategy");
static_assert(offsetof(UCommonActivatableWidgetContainerBase, WidgetList) == 0x180, "Offset mismatch for UCommonActivatableWidgetContainerBase::WidgetList");
static_assert(offsetof(UCommonActivatableWidgetContainerBase, DisplayedWidget) == 0x190, "Offset mismatch for UCommonActivatableWidgetContainerBase::DisplayedWidget");
static_assert(offsetof(UCommonActivatableWidgetContainerBase, GeneratedWidgetsPool) == 0x198, "Offset mismatch for UCommonActivatableWidgetContainerBase::GeneratedWidgetsPool");

// Size: 0x290 (Inherited: 0x428, Single: 0xfffffe68)
class UCommonActivatableWidgetStack : public UCommonActivatableWidgetContainerBase
{
public:
    UClass* RootContentWidgetClass; // 0x280 (Size: 0x8, Type: ClassProperty)
    UCommonActivatableWidget* RootContentWidget; // 0x288 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UCommonActivatableWidgetStack) == 0x290, "Size mismatch for UCommonActivatableWidgetStack");
static_assert(offsetof(UCommonActivatableWidgetStack, RootContentWidgetClass) == 0x280, "Offset mismatch for UCommonActivatableWidgetStack::RootContentWidgetClass");
static_assert(offsetof(UCommonActivatableWidgetStack, RootContentWidget) == 0x288, "Offset mismatch for UCommonActivatableWidgetStack::RootContentWidget");

// Size: 0x280 (Inherited: 0x428, Single: 0xfffffe58)
class UCommonActivatableWidgetQueue : public UCommonActivatableWidgetContainerBase
{
public:
};

static_assert(sizeof(UCommonActivatableWidgetQueue) == 0x280, "Size mismatch for UCommonActivatableWidgetQueue");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FUIActionBindingHandle
{
};

static_assert(sizeof(FUIActionBindingHandle) == 0x4, "Size mismatch for FUIActionBindingHandle");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FCommonNumberFormattingOptions
{
    TEnumAsByte<ERoundingMode> RoundingMode; // 0x0 (Size: 0x1, Type: ByteProperty)
    bool AlwaysSign; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool UseGrouping; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    int32_t MinimumIntegralDigits; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t MaximumIntegralDigits; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t MinimumFractionalDigits; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t MaximumFractionalDigits; // 0x10 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FCommonNumberFormattingOptions) == 0x14, "Size mismatch for FCommonNumberFormattingOptions");
static_assert(offsetof(FCommonNumberFormattingOptions, RoundingMode) == 0x0, "Offset mismatch for FCommonNumberFormattingOptions::RoundingMode");
static_assert(offsetof(FCommonNumberFormattingOptions, AlwaysSign) == 0x1, "Offset mismatch for FCommonNumberFormattingOptions::AlwaysSign");
static_assert(offsetof(FCommonNumberFormattingOptions, UseGrouping) == 0x2, "Offset mismatch for FCommonNumberFormattingOptions::UseGrouping");
static_assert(offsetof(FCommonNumberFormattingOptions, MinimumIntegralDigits) == 0x4, "Offset mismatch for FCommonNumberFormattingOptions::MinimumIntegralDigits");
static_assert(offsetof(FCommonNumberFormattingOptions, MaximumIntegralDigits) == 0x8, "Offset mismatch for FCommonNumberFormattingOptions::MaximumIntegralDigits");
static_assert(offsetof(FCommonNumberFormattingOptions, MinimumFractionalDigits) == 0xc, "Offset mismatch for FCommonNumberFormattingOptions::MinimumFractionalDigits");
static_assert(offsetof(FCommonNumberFormattingOptions, MaximumFractionalDigits) == 0x10, "Offset mismatch for FCommonNumberFormattingOptions::MaximumFractionalDigits");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCommonRegisteredTabInfo
{
    int32_t TabIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UClass* TabButtonClass; // 0x8 (Size: 0x8, Type: ClassProperty)
    UCommonButtonBase* TabButton; // 0x10 (Size: 0x8, Type: ObjectProperty)
    UWidget* ContentInstance; // 0x18 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCommonRegisteredTabInfo) == 0x20, "Size mismatch for FCommonRegisteredTabInfo");
static_assert(offsetof(FCommonRegisteredTabInfo, TabIndex) == 0x0, "Offset mismatch for FCommonRegisteredTabInfo::TabIndex");
static_assert(offsetof(FCommonRegisteredTabInfo, TabButtonClass) == 0x8, "Offset mismatch for FCommonRegisteredTabInfo::TabButtonClass");
static_assert(offsetof(FCommonRegisteredTabInfo, TabButton) == 0x10, "Offset mismatch for FCommonRegisteredTabInfo::TabButton");
static_assert(offsetof(FCommonRegisteredTabInfo, ContentInstance) == 0x18, "Offset mismatch for FCommonRegisteredTabInfo::ContentInstance");

// Size: 0x6 (Inherited: 0x0, Single: 0x6)
struct FUIInputConfig
{
    bool bIgnoreMoveInput; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreLookInput; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t InputMode; // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t MouseCaptureMode; // 0x3 (Size: 0x1, Type: EnumProperty)
    uint8_t MouseLockMode; // 0x4 (Size: 0x1, Type: EnumProperty)
    bool bHideCursorDuringViewportCapture; // 0x5 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FUIInputConfig) == 0x6, "Size mismatch for FUIInputConfig");
static_assert(offsetof(FUIInputConfig, bIgnoreMoveInput) == 0x0, "Offset mismatch for FUIInputConfig::bIgnoreMoveInput");
static_assert(offsetof(FUIInputConfig, bIgnoreLookInput) == 0x1, "Offset mismatch for FUIInputConfig::bIgnoreLookInput");
static_assert(offsetof(FUIInputConfig, InputMode) == 0x2, "Offset mismatch for FUIInputConfig::InputMode");
static_assert(offsetof(FUIInputConfig, MouseCaptureMode) == 0x3, "Offset mismatch for FUIInputConfig::MouseCaptureMode");
static_assert(offsetof(FUIInputConfig, MouseLockMode) == 0x4, "Offset mismatch for FUIInputConfig::MouseLockMode");
static_assert(offsetof(FUIInputConfig, bHideCursorDuringViewportCapture) == 0x5, "Offset mismatch for FUIInputConfig::bHideCursorDuringViewportCapture");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCommonInputActionHandlerData
{
    FDataTableRowHandle InputActionRow; // 0x0 (Size: 0x10, Type: StructProperty)
    uint8_t State; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0xf]; // 0x11 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FCommonInputActionHandlerData) == 0x20, "Size mismatch for FCommonInputActionHandlerData");
static_assert(offsetof(FCommonInputActionHandlerData, InputActionRow) == 0x0, "Offset mismatch for FCommonInputActionHandlerData::InputActionRow");
static_assert(offsetof(FCommonInputActionHandlerData, State) == 0x10, "Offset mismatch for FCommonInputActionHandlerData::State");

// Size: 0x4 (Inherited: 0x4, Single: 0x0)
struct FUITag : FGameplayTag
{
};

static_assert(sizeof(FUITag) == 0x4, "Size mismatch for FUITag");

// Size: 0x4 (Inherited: 0x8, Single: 0xfffffffc)
struct FUIActionTag : FUITag
{
};

static_assert(sizeof(FUIActionTag) == 0x4, "Size mismatch for FUIActionTag");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCommonButtonStyleOptionalSlateSound
{
    bool bHasSound; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FSlateSound Sound; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FCommonButtonStyleOptionalSlateSound) == 0x20, "Size mismatch for FCommonButtonStyleOptionalSlateSound");
static_assert(offsetof(FCommonButtonStyleOptionalSlateSound, bHasSound) == 0x0, "Offset mismatch for FCommonButtonStyleOptionalSlateSound::bHasSound");
static_assert(offsetof(FCommonButtonStyleOptionalSlateSound, Sound) == 0x8, "Offset mismatch for FCommonButtonStyleOptionalSlateSound::Sound");

// Size: 0x48 (Inherited: 0x8, Single: 0x40)
struct FRichTextIconData : FTableRowBase
{
    FText DisplayName; // 0x8 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UObject*> ResourceObject; // 0x18 (Size: 0x20, Type: SoftObjectProperty)
    FVector2D ImageSize; // 0x38 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRichTextIconData) == 0x48, "Size mismatch for FRichTextIconData");
static_assert(offsetof(FRichTextIconData, DisplayName) == 0x8, "Offset mismatch for FRichTextIconData::DisplayName");
static_assert(offsetof(FRichTextIconData, ResourceObject) == 0x18, "Offset mismatch for FRichTextIconData::ResourceObject");
static_assert(offsetof(FRichTextIconData, ImageSize) == 0x38, "Offset mismatch for FRichTextIconData::ImageSize");

// Size: 0xe0 (Inherited: 0x0, Single: 0xe0)
struct FCommonInputTypeInfo
{
    FKey Key; // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t OverrrideState; // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bActionRequiresHold; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x2]; // 0x1a (Size: 0x2, Type: PaddingProperty)
    float HoldTime; // 0x1c (Size: 0x4, Type: FloatProperty)
    float HoldRollbackTime; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0xc]; // 0x24 (Size: 0xc, Type: PaddingProperty)
    FSlateBrush OverrideBrush; // 0x30 (Size: 0xb0, Type: StructProperty)
};

static_assert(sizeof(FCommonInputTypeInfo) == 0xe0, "Size mismatch for FCommonInputTypeInfo");
static_assert(offsetof(FCommonInputTypeInfo, Key) == 0x0, "Offset mismatch for FCommonInputTypeInfo::Key");
static_assert(offsetof(FCommonInputTypeInfo, OverrrideState) == 0x18, "Offset mismatch for FCommonInputTypeInfo::OverrrideState");
static_assert(offsetof(FCommonInputTypeInfo, bActionRequiresHold) == 0x19, "Offset mismatch for FCommonInputTypeInfo::bActionRequiresHold");
static_assert(offsetof(FCommonInputTypeInfo, HoldTime) == 0x1c, "Offset mismatch for FCommonInputTypeInfo::HoldTime");
static_assert(offsetof(FCommonInputTypeInfo, HoldRollbackTime) == 0x20, "Offset mismatch for FCommonInputTypeInfo::HoldRollbackTime");
static_assert(offsetof(FCommonInputTypeInfo, OverrideBrush) == 0x30, "Offset mismatch for FCommonInputTypeInfo::OverrideBrush");

// Size: 0x320 (Inherited: 0x8, Single: 0x318)
struct FCommonInputActionDataBase : FTableRowBase
{
    FText DisplayName; // 0x8 (Size: 0x10, Type: TextProperty)
    FText HoldDisplayName; // 0x18 (Size: 0x10, Type: TextProperty)
    int32_t NavBarPriority; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    FCommonInputTypeInfo KeyboardInputTypeInfo; // 0x30 (Size: 0xe0, Type: StructProperty)
    FCommonInputTypeInfo DefaultGamepadInputTypeInfo; // 0x110 (Size: 0xe0, Type: StructProperty)
    TMap<FCommonInputTypeInfo, FName> GamepadInputOverrides; // 0x1f0 (Size: 0x50, Type: MapProperty)
    FCommonInputTypeInfo TouchInputTypeInfo; // 0x240 (Size: 0xe0, Type: StructProperty)
};

static_assert(sizeof(FCommonInputActionDataBase) == 0x320, "Size mismatch for FCommonInputActionDataBase");
static_assert(offsetof(FCommonInputActionDataBase, DisplayName) == 0x8, "Offset mismatch for FCommonInputActionDataBase::DisplayName");
static_assert(offsetof(FCommonInputActionDataBase, HoldDisplayName) == 0x18, "Offset mismatch for FCommonInputActionDataBase::HoldDisplayName");
static_assert(offsetof(FCommonInputActionDataBase, NavBarPriority) == 0x28, "Offset mismatch for FCommonInputActionDataBase::NavBarPriority");
static_assert(offsetof(FCommonInputActionDataBase, KeyboardInputTypeInfo) == 0x30, "Offset mismatch for FCommonInputActionDataBase::KeyboardInputTypeInfo");
static_assert(offsetof(FCommonInputActionDataBase, DefaultGamepadInputTypeInfo) == 0x110, "Offset mismatch for FCommonInputActionDataBase::DefaultGamepadInputTypeInfo");
static_assert(offsetof(FCommonInputActionDataBase, GamepadInputOverrides) == 0x1f0, "Offset mismatch for FCommonInputActionDataBase::GamepadInputOverrides");
static_assert(offsetof(FCommonInputActionDataBase, TouchInputTypeInfo) == 0x240, "Offset mismatch for FCommonInputActionDataBase::TouchInputTypeInfo");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FUIActionKeyMapping
{
    FKey Key; // 0x0 (Size: 0x18, Type: StructProperty)
    float HoldTime; // 0x18 (Size: 0x4, Type: FloatProperty)
    float HoldRollbackTime; // 0x1c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FUIActionKeyMapping) == 0x20, "Size mismatch for FUIActionKeyMapping");
static_assert(offsetof(FUIActionKeyMapping, Key) == 0x0, "Offset mismatch for FUIActionKeyMapping::Key");
static_assert(offsetof(FUIActionKeyMapping, HoldTime) == 0x18, "Offset mismatch for FUIActionKeyMapping::HoldTime");
static_assert(offsetof(FUIActionKeyMapping, HoldRollbackTime) == 0x1c, "Offset mismatch for FUIActionKeyMapping::HoldRollbackTime");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FUIInputAction
{
    FUIActionTag ActionTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FText DefaultDisplayName; // 0x8 (Size: 0x10, Type: TextProperty)
    TArray<FUIActionKeyMapping> KeyMappings; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FUIInputAction) == 0x28, "Size mismatch for FUIInputAction");
static_assert(offsetof(FUIInputAction, ActionTag) == 0x0, "Offset mismatch for FUIInputAction::ActionTag");
static_assert(offsetof(FUIInputAction, DefaultDisplayName) == 0x8, "Offset mismatch for FUIInputAction::DefaultDisplayName");
static_assert(offsetof(FUIInputAction, KeyMappings) == 0x18, "Offset mismatch for FUIInputAction::KeyMappings");

// Size: 0x2c (Inherited: 0x0, Single: 0x2c)
struct FCommonAnalogCursorSettings
{
    int32_t PreprocessorPriority; // 0x0 (Size: 0x4, Type: IntProperty)
    FInputPreprocessorRegistrationKey PreprocessorRegistrationInfo; // 0x4 (Size: 0x8, Type: StructProperty)
    bool bEnableCursorAcceleration; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    float CursorAcceleration; // 0x10 (Size: 0x4, Type: FloatProperty)
    float CursorMaxSpeed; // 0x14 (Size: 0x4, Type: FloatProperty)
    float CursorDeadZone; // 0x18 (Size: 0x4, Type: FloatProperty)
    float HoverSlowdownFactor; // 0x1c (Size: 0x4, Type: FloatProperty)
    float ScrollDeadZone; // 0x20 (Size: 0x4, Type: FloatProperty)
    float ScrollUpdatePeriod; // 0x24 (Size: 0x4, Type: FloatProperty)
    float ScrollMultiplier; // 0x28 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FCommonAnalogCursorSettings) == 0x2c, "Size mismatch for FCommonAnalogCursorSettings");
static_assert(offsetof(FCommonAnalogCursorSettings, PreprocessorPriority) == 0x0, "Offset mismatch for FCommonAnalogCursorSettings::PreprocessorPriority");
static_assert(offsetof(FCommonAnalogCursorSettings, PreprocessorRegistrationInfo) == 0x4, "Offset mismatch for FCommonAnalogCursorSettings::PreprocessorRegistrationInfo");
static_assert(offsetof(FCommonAnalogCursorSettings, bEnableCursorAcceleration) == 0xc, "Offset mismatch for FCommonAnalogCursorSettings::bEnableCursorAcceleration");
static_assert(offsetof(FCommonAnalogCursorSettings, CursorAcceleration) == 0x10, "Offset mismatch for FCommonAnalogCursorSettings::CursorAcceleration");
static_assert(offsetof(FCommonAnalogCursorSettings, CursorMaxSpeed) == 0x14, "Offset mismatch for FCommonAnalogCursorSettings::CursorMaxSpeed");
static_assert(offsetof(FCommonAnalogCursorSettings, CursorDeadZone) == 0x18, "Offset mismatch for FCommonAnalogCursorSettings::CursorDeadZone");
static_assert(offsetof(FCommonAnalogCursorSettings, HoverSlowdownFactor) == 0x1c, "Offset mismatch for FCommonAnalogCursorSettings::HoverSlowdownFactor");
static_assert(offsetof(FCommonAnalogCursorSettings, ScrollDeadZone) == 0x20, "Offset mismatch for FCommonAnalogCursorSettings::ScrollDeadZone");
static_assert(offsetof(FCommonAnalogCursorSettings, ScrollUpdatePeriod) == 0x24, "Offset mismatch for FCommonAnalogCursorSettings::ScrollUpdatePeriod");
static_assert(offsetof(FCommonAnalogCursorSettings, ScrollMultiplier) == 0x28, "Offset mismatch for FCommonAnalogCursorSettings::ScrollMultiplier");

