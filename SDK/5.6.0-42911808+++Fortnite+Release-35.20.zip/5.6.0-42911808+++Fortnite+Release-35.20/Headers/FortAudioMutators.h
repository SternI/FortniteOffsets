/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortAudioMutators
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Enums.h"
#include "Engine.h"
#include "AudioMutators.h"

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class USoundClassGraphMapping : public UDataAsset
{
public:
    TMap<USoundClass*, USoundClass*> SoundClassMap; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(USoundClassGraphMapping) == 0x80, "Size mismatch for USoundClassGraphMapping");
static_assert(offsetof(USoundClassGraphMapping, SoundClassMap) == 0x30, "Offset mismatch for USoundClassGraphMapping::SoundClassMap");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FSoundActionSwapSoundClassGraph : FAudioMutatorAction
{
    USoundClassGraphMapping* SoundClassMapping; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FSoundActionSwapSoundClassGraph) == 0x10, "Size mismatch for FSoundActionSwapSoundClassGraph");
static_assert(offsetof(FSoundActionSwapSoundClassGraph, SoundClassMapping) == 0x8, "Offset mismatch for FSoundActionSwapSoundClassGraph::SoundClassMapping");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FSoundSelectorAffiliation : FAudioMutatorSelector
{
    uint8_t Affiliation; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FSoundSelectorAffiliation) == 0x10, "Size mismatch for FSoundSelectorAffiliation");
static_assert(offsetof(FSoundSelectorAffiliation, Affiliation) == 0x8, "Offset mismatch for FSoundSelectorAffiliation::Affiliation");

