/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayEffects
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0xa68 (Inherited: 0x14f8, Single: 0xfffff570)
class UGE_Riding_Creature_Sprint_Burt_C : public UGE_Riding_Creature_Sprint_C
{
public:
};

static_assert(sizeof(UGE_Riding_Creature_Sprint_Burt_C) == 0xa68, "Size mismatch for UGE_Riding_Creature_Sprint_Burt_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_NotPetableCreature_IsBeingRidden_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_NotPetableCreature_IsBeingRidden_C) == 0xa68, "Size mismatch for UGE_Riding_NotPetableCreature_IsBeingRidden_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_Creature_Sprint_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_Creature_Sprint_C) == 0xa68, "Size mismatch for UGE_Riding_Creature_Sprint_C");

