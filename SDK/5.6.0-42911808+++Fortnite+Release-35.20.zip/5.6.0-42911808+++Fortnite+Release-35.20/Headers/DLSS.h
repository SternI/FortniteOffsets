/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DLSS
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UDLSSOverrideSettings : public UObject
{
public:
    uint8_t EnableDLSSInEditorViewportsOverride; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t EnableDLSSInPlayInEditorViewportsOverride; // 0x29 (Size: 0x1, Type: EnumProperty)
    bool bShowDLSSIncompatiblePluginsToolsWarnings; // 0x2a (Size: 0x1, Type: BoolProperty)
    uint8_t ShowDLSSSDebugOnScreenMessages; // 0x2b (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDLSSOverrideSettings) == 0x30, "Size mismatch for UDLSSOverrideSettings");
static_assert(offsetof(UDLSSOverrideSettings, EnableDLSSInEditorViewportsOverride) == 0x28, "Offset mismatch for UDLSSOverrideSettings::EnableDLSSInEditorViewportsOverride");
static_assert(offsetof(UDLSSOverrideSettings, EnableDLSSInPlayInEditorViewportsOverride) == 0x29, "Offset mismatch for UDLSSOverrideSettings::EnableDLSSInPlayInEditorViewportsOverride");
static_assert(offsetof(UDLSSOverrideSettings, bShowDLSSIncompatiblePluginsToolsWarnings) == 0x2a, "Offset mismatch for UDLSSOverrideSettings::bShowDLSSIncompatiblePluginsToolsWarnings");
static_assert(offsetof(UDLSSOverrideSettings, ShowDLSSSDebugOnScreenMessages) == 0x2b, "Offset mismatch for UDLSSOverrideSettings::ShowDLSSSDebugOnScreenMessages");

// Size: 0x60 (Inherited: 0x28, Single: 0x38)
class UDLSSSettings : public UObject
{
public:
    bool bEnableDLSSD3D12; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bEnableDLSSD3D11; // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bEnableDLSSVulkan; // 0x2a (Size: 0x1, Type: BoolProperty)
    bool bEnableDLSSInEditorViewports; // 0x2b (Size: 0x1, Type: BoolProperty)
    bool bEnableDLSSInPlayInEditorViewports; // 0x2c (Size: 0x1, Type: BoolProperty)
    bool bShowDLSSSDebugOnScreenMessages; // 0x2d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2e[0x2]; // 0x2e (Size: 0x2, Type: PaddingProperty)
    FString GenericDLSSBinaryPath; // 0x30 (Size: 0x10, Type: StrProperty)
    bool bGenericDLSSBinaryExists; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x3]; // 0x41 (Size: 0x3, Type: PaddingProperty)
    uint32_t NVIDIANGXApplicationId; // 0x44 (Size: 0x4, Type: UInt32Property)
    FString CustomDLSSBinaryPath; // 0x48 (Size: 0x10, Type: StrProperty)
    bool bCustomDLSSBinaryExists; // 0x58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDLSSSettings) == 0x60, "Size mismatch for UDLSSSettings");
static_assert(offsetof(UDLSSSettings, bEnableDLSSD3D12) == 0x28, "Offset mismatch for UDLSSSettings::bEnableDLSSD3D12");
static_assert(offsetof(UDLSSSettings, bEnableDLSSD3D11) == 0x29, "Offset mismatch for UDLSSSettings::bEnableDLSSD3D11");
static_assert(offsetof(UDLSSSettings, bEnableDLSSVulkan) == 0x2a, "Offset mismatch for UDLSSSettings::bEnableDLSSVulkan");
static_assert(offsetof(UDLSSSettings, bEnableDLSSInEditorViewports) == 0x2b, "Offset mismatch for UDLSSSettings::bEnableDLSSInEditorViewports");
static_assert(offsetof(UDLSSSettings, bEnableDLSSInPlayInEditorViewports) == 0x2c, "Offset mismatch for UDLSSSettings::bEnableDLSSInPlayInEditorViewports");
static_assert(offsetof(UDLSSSettings, bShowDLSSSDebugOnScreenMessages) == 0x2d, "Offset mismatch for UDLSSSettings::bShowDLSSSDebugOnScreenMessages");
static_assert(offsetof(UDLSSSettings, GenericDLSSBinaryPath) == 0x30, "Offset mismatch for UDLSSSettings::GenericDLSSBinaryPath");
static_assert(offsetof(UDLSSSettings, bGenericDLSSBinaryExists) == 0x40, "Offset mismatch for UDLSSSettings::bGenericDLSSBinaryExists");
static_assert(offsetof(UDLSSSettings, NVIDIANGXApplicationId) == 0x44, "Offset mismatch for UDLSSSettings::NVIDIANGXApplicationId");
static_assert(offsetof(UDLSSSettings, CustomDLSSBinaryPath) == 0x48, "Offset mismatch for UDLSSSettings::CustomDLSSBinaryPath");
static_assert(offsetof(UDLSSSettings, bCustomDLSSBinaryExists) == 0x58, "Offset mismatch for UDLSSSettings::bCustomDLSSBinaryExists");

