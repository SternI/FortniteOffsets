/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosNiagara
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Niagara.h"
#include "NiagaraCore.h"
#include "CoreUObject.h"
#include "ChaosSolverEngine.h"
#include "PhysicsCore.h"
#include "GeometryCollectionEngine.h"

// Size: 0x348 (Inherited: 0xb0, Single: 0x298)
class UNiagaraDataInterfaceChaosDestruction : public UNiagaraDataInterface
{
public:
    TSet<AChaosSolverActor*> ChaosSolverActorSet; // 0x38 (Size: 0x50, Type: SetProperty)
    uint8_t DataSourceType; // 0x88 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_89[0x3]; // 0x89 (Size: 0x3, Type: PaddingProperty)
    int32_t DataProcessFrequency; // 0x8c (Size: 0x4, Type: IntProperty)
    int32_t MaxNumberOfDataEntriesToSpawn; // 0x90 (Size: 0x4, Type: IntProperty)
    bool DoSpawn; // 0x94 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_95[0x3]; // 0x95 (Size: 0x3, Type: PaddingProperty)
    FVector2D SpawnMultiplierMinMax; // 0x98 (Size: 0x10, Type: StructProperty)
    float SpawnChance; // 0xa8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
    FVector2D ImpulseToSpawnMinMax; // 0xb0 (Size: 0x10, Type: StructProperty)
    FVector2D SpeedToSpawnMinMax; // 0xc0 (Size: 0x10, Type: StructProperty)
    FVector2D MassToSpawnMinMax; // 0xd0 (Size: 0x10, Type: StructProperty)
    FVector2D ExtentMinToSpawnMinMax; // 0xe0 (Size: 0x10, Type: StructProperty)
    FVector2D ExtentMaxToSpawnMinMax; // 0xf0 (Size: 0x10, Type: StructProperty)
    FVector2D VolumeToSpawnMinMax; // 0x100 (Size: 0x10, Type: StructProperty)
    FVector2D SolverTimeToSpawnMinMax; // 0x110 (Size: 0x10, Type: StructProperty)
    int32_t SurfaceTypeToSpawn; // 0x120 (Size: 0x4, Type: IntProperty)
    uint8_t LocationFilteringMode; // 0x124 (Size: 0x1, Type: EnumProperty)
    uint8_t LocationXToSpawn; // 0x125 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_126[0x2]; // 0x126 (Size: 0x2, Type: PaddingProperty)
    FVector2D LocationXToSpawnMinMax; // 0x128 (Size: 0x10, Type: StructProperty)
    uint8_t LocationYToSpawn; // 0x138 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_139[0x7]; // 0x139 (Size: 0x7, Type: PaddingProperty)
    FVector2D LocationYToSpawnMinMax; // 0x140 (Size: 0x10, Type: StructProperty)
    uint8_t LocationZToSpawn; // 0x150 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_151[0x7]; // 0x151 (Size: 0x7, Type: PaddingProperty)
    FVector2D LocationZToSpawnMinMax; // 0x158 (Size: 0x10, Type: StructProperty)
    float TrailMinSpeedToSpawn; // 0x168 (Size: 0x4, Type: FloatProperty)
    uint8_t DataSortingType; // 0x16c (Size: 0x1, Type: EnumProperty)
    bool bGetExternalCollisionData; // 0x16d (Size: 0x1, Type: BoolProperty)
    bool DoSpatialHash; // 0x16e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_16f[0x1]; // 0x16f (Size: 0x1, Type: PaddingProperty)
    FVector SpatialHashVolumeMin; // 0x170 (Size: 0x18, Type: StructProperty)
    FVector SpatialHashVolumeMax; // 0x188 (Size: 0x18, Type: StructProperty)
    FVector SpatialHashVolumeCellSize; // 0x1a0 (Size: 0x18, Type: StructProperty)
    int32_t MaxDataPerCell; // 0x1b8 (Size: 0x4, Type: IntProperty)
    bool bApplyMaterialsFilter; // 0x1bc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1bd[0x3]; // 0x1bd (Size: 0x3, Type: PaddingProperty)
    TSet<UPhysicalMaterial*> ChaosBreakingMaterialSet; // 0x1c0 (Size: 0x50, Type: SetProperty)
    bool bGetExternalBreakingData; // 0x210 (Size: 0x1, Type: BoolProperty)
    bool bGetExternalTrailingData; // 0x211 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_212[0x6]; // 0x212 (Size: 0x6, Type: PaddingProperty)
    FVector2D RandomPositionMagnitudeMinMax; // 0x218 (Size: 0x10, Type: StructProperty)
    float InheritedVelocityMultiplier; // 0x228 (Size: 0x4, Type: FloatProperty)
    uint8_t RandomVelocityGenerationType; // 0x22c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_22d[0x3]; // 0x22d (Size: 0x3, Type: PaddingProperty)
    FVector2D RandomVelocityMagnitudeMinMax; // 0x230 (Size: 0x10, Type: StructProperty)
    float SpreadAngleMax; // 0x240 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_244[0x4]; // 0x244 (Size: 0x4, Type: PaddingProperty)
    FVector VelocityOffsetMin; // 0x248 (Size: 0x18, Type: StructProperty)
    FVector VelocityOffsetMax; // 0x260 (Size: 0x18, Type: StructProperty)
    FVector2D FinalVelocityMagnitudeMinMax; // 0x278 (Size: 0x10, Type: StructProperty)
    float MaxLatency; // 0x288 (Size: 0x4, Type: FloatProperty)
    uint8_t DebugType; // 0x28c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_28d[0x3]; // 0x28d (Size: 0x3, Type: PaddingProperty)
    int32_t LastSpawnedPointID; // 0x290 (Size: 0x4, Type: IntProperty)
    float LastSpawnTime; // 0x294 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_298[0x10]; // 0x298 (Size: 0x10, Type: PaddingProperty)
    float SolverTime; // 0x2a8 (Size: 0x4, Type: FloatProperty)
    float TimeStampOfLastProcessedData; // 0x2ac (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2b0[0x98]; // 0x2b0 (Size: 0x98, Type: PaddingProperty)
};

static_assert(sizeof(UNiagaraDataInterfaceChaosDestruction) == 0x348, "Size mismatch for UNiagaraDataInterfaceChaosDestruction");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, ChaosSolverActorSet) == 0x38, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::ChaosSolverActorSet");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, DataSourceType) == 0x88, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::DataSourceType");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, DataProcessFrequency) == 0x8c, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::DataProcessFrequency");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, MaxNumberOfDataEntriesToSpawn) == 0x90, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::MaxNumberOfDataEntriesToSpawn");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, DoSpawn) == 0x94, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::DoSpawn");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, SpawnMultiplierMinMax) == 0x98, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::SpawnMultiplierMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, SpawnChance) == 0xa8, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::SpawnChance");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, ImpulseToSpawnMinMax) == 0xb0, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::ImpulseToSpawnMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, SpeedToSpawnMinMax) == 0xc0, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::SpeedToSpawnMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, MassToSpawnMinMax) == 0xd0, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::MassToSpawnMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, ExtentMinToSpawnMinMax) == 0xe0, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::ExtentMinToSpawnMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, ExtentMaxToSpawnMinMax) == 0xf0, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::ExtentMaxToSpawnMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, VolumeToSpawnMinMax) == 0x100, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::VolumeToSpawnMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, SolverTimeToSpawnMinMax) == 0x110, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::SolverTimeToSpawnMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, SurfaceTypeToSpawn) == 0x120, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::SurfaceTypeToSpawn");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, LocationFilteringMode) == 0x124, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::LocationFilteringMode");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, LocationXToSpawn) == 0x125, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::LocationXToSpawn");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, LocationXToSpawnMinMax) == 0x128, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::LocationXToSpawnMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, LocationYToSpawn) == 0x138, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::LocationYToSpawn");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, LocationYToSpawnMinMax) == 0x140, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::LocationYToSpawnMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, LocationZToSpawn) == 0x150, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::LocationZToSpawn");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, LocationZToSpawnMinMax) == 0x158, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::LocationZToSpawnMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, TrailMinSpeedToSpawn) == 0x168, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::TrailMinSpeedToSpawn");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, DataSortingType) == 0x16c, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::DataSortingType");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, bGetExternalCollisionData) == 0x16d, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::bGetExternalCollisionData");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, DoSpatialHash) == 0x16e, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::DoSpatialHash");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, SpatialHashVolumeMin) == 0x170, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::SpatialHashVolumeMin");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, SpatialHashVolumeMax) == 0x188, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::SpatialHashVolumeMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, SpatialHashVolumeCellSize) == 0x1a0, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::SpatialHashVolumeCellSize");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, MaxDataPerCell) == 0x1b8, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::MaxDataPerCell");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, bApplyMaterialsFilter) == 0x1bc, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::bApplyMaterialsFilter");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, ChaosBreakingMaterialSet) == 0x1c0, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::ChaosBreakingMaterialSet");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, bGetExternalBreakingData) == 0x210, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::bGetExternalBreakingData");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, bGetExternalTrailingData) == 0x211, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::bGetExternalTrailingData");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, RandomPositionMagnitudeMinMax) == 0x218, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::RandomPositionMagnitudeMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, InheritedVelocityMultiplier) == 0x228, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::InheritedVelocityMultiplier");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, RandomVelocityGenerationType) == 0x22c, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::RandomVelocityGenerationType");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, RandomVelocityMagnitudeMinMax) == 0x230, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::RandomVelocityMagnitudeMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, SpreadAngleMax) == 0x240, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::SpreadAngleMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, VelocityOffsetMin) == 0x248, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::VelocityOffsetMin");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, VelocityOffsetMax) == 0x260, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::VelocityOffsetMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, FinalVelocityMagnitudeMinMax) == 0x278, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::FinalVelocityMagnitudeMinMax");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, MaxLatency) == 0x288, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::MaxLatency");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, DebugType) == 0x28c, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::DebugType");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, LastSpawnedPointID) == 0x290, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::LastSpawnedPointID");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, LastSpawnTime) == 0x294, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::LastSpawnTime");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, SolverTime) == 0x2a8, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::SolverTime");
static_assert(offsetof(UNiagaraDataInterfaceChaosDestruction, TimeStampOfLastProcessedData) == 0x2ac, "Offset mismatch for UNiagaraDataInterfaceChaosDestruction::TimeStampOfLastProcessedData");

// Size: 0x90 (Inherited: 0xb0, Single: 0xffffffe0)
class UNiagaraDataInterfaceGeometryCollection : public UNiagaraDataInterface
{
public:
    uint8_t SourceMode; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
    UGeometryCollection* DefaultGeometryCollection; // 0x40 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<AGeometryCollectionActor*> GeometryCollectionActor; // 0x48 (Size: 0x20, Type: SoftObjectProperty)
    UGeometryCollectionComponent* SourceComponent; // 0x68 (Size: 0x8, Type: ObjectProperty)
    FNiagaraUserParameterBinding GeometryCollectionUserParameter; // 0x70 (Size: 0x18, Type: StructProperty)
    bool bIncludeIntermediateBones; // 0x88 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0x7]; // 0x89 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UNiagaraDataInterfaceGeometryCollection) == 0x90, "Size mismatch for UNiagaraDataInterfaceGeometryCollection");
static_assert(offsetof(UNiagaraDataInterfaceGeometryCollection, SourceMode) == 0x38, "Offset mismatch for UNiagaraDataInterfaceGeometryCollection::SourceMode");
static_assert(offsetof(UNiagaraDataInterfaceGeometryCollection, DefaultGeometryCollection) == 0x40, "Offset mismatch for UNiagaraDataInterfaceGeometryCollection::DefaultGeometryCollection");
static_assert(offsetof(UNiagaraDataInterfaceGeometryCollection, GeometryCollectionActor) == 0x48, "Offset mismatch for UNiagaraDataInterfaceGeometryCollection::GeometryCollectionActor");
static_assert(offsetof(UNiagaraDataInterfaceGeometryCollection, SourceComponent) == 0x68, "Offset mismatch for UNiagaraDataInterfaceGeometryCollection::SourceComponent");
static_assert(offsetof(UNiagaraDataInterfaceGeometryCollection, GeometryCollectionUserParameter) == 0x70, "Offset mismatch for UNiagaraDataInterfaceGeometryCollection::GeometryCollectionUserParameter");
static_assert(offsetof(UNiagaraDataInterfaceGeometryCollection, bIncludeIntermediateBones) == 0x88, "Offset mismatch for UNiagaraDataInterfaceGeometryCollection::bIncludeIntermediateBones");

// Size: 0x38 (Inherited: 0xb0, Single: 0xffffff88)
class UNiagaraDataInterfacePhysicsField : public UNiagaraDataInterface
{
public:
};

static_assert(sizeof(UNiagaraDataInterfacePhysicsField) == 0x38, "Size mismatch for UNiagaraDataInterfacePhysicsField");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FChaosDestructionEvent
{
    FVector Position; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Normal; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector Velocity; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity; // 0x48 (Size: 0x18, Type: StructProperty)
    float ExtentMin; // 0x60 (Size: 0x4, Type: FloatProperty)
    float ExtentMax; // 0x64 (Size: 0x4, Type: FloatProperty)
    int32_t ParticleID; // 0x68 (Size: 0x4, Type: IntProperty)
    float time; // 0x6c (Size: 0x4, Type: FloatProperty)
    int32_t Type; // 0x70 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FChaosDestructionEvent) == 0x78, "Size mismatch for FChaosDestructionEvent");
static_assert(offsetof(FChaosDestructionEvent, Position) == 0x0, "Offset mismatch for FChaosDestructionEvent::Position");
static_assert(offsetof(FChaosDestructionEvent, Normal) == 0x18, "Offset mismatch for FChaosDestructionEvent::Normal");
static_assert(offsetof(FChaosDestructionEvent, Velocity) == 0x30, "Offset mismatch for FChaosDestructionEvent::Velocity");
static_assert(offsetof(FChaosDestructionEvent, AngularVelocity) == 0x48, "Offset mismatch for FChaosDestructionEvent::AngularVelocity");
static_assert(offsetof(FChaosDestructionEvent, ExtentMin) == 0x60, "Offset mismatch for FChaosDestructionEvent::ExtentMin");
static_assert(offsetof(FChaosDestructionEvent, ExtentMax) == 0x64, "Offset mismatch for FChaosDestructionEvent::ExtentMax");
static_assert(offsetof(FChaosDestructionEvent, ParticleID) == 0x68, "Offset mismatch for FChaosDestructionEvent::ParticleID");
static_assert(offsetof(FChaosDestructionEvent, time) == 0x6c, "Offset mismatch for FChaosDestructionEvent::time");
static_assert(offsetof(FChaosDestructionEvent, Type) == 0x70, "Offset mismatch for FChaosDestructionEvent::Type");

