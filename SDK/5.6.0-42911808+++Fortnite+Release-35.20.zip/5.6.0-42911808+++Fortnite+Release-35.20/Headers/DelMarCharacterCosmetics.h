/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarCharacterCosmetics
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "ModularGameplay.h"
#include "Engine.h"
#include "DelMarCore.h"
#include "FortniteGame.h"
#include "CosmeticsFrameworkLoadouts.h"
#include "CoreUObject.h"

// Size: 0xf8 (Inherited: 0x250, Single: 0xfffffea8)
class UDelMarDriverCosmeticPlayerComponent : public UPlayerStateComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    TArray<FName> SequenceBindingTags; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    FDelMarDriverCosmeticData CosmeticData; // 0xe0 (Size: 0x18, Type: StructProperty)

protected:
    void HandleBotControllerLoadoutChanged(ADelMarAIController*& AIController, const FFortAthenaLoadout Loadout); // 0x11d2b7dc (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void HandlePlayerControllerLoadoutChanged(const FCosmeticLoadout Loadout); // 0x11d2ba48 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
    void On_RepCosmeticData(); // 0x10dd5298 (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarDriverCosmeticPlayerComponent) == 0xf8, "Size mismatch for UDelMarDriverCosmeticPlayerComponent");
static_assert(offsetof(UDelMarDriverCosmeticPlayerComponent, SequenceBindingTags) == 0xd0, "Offset mismatch for UDelMarDriverCosmeticPlayerComponent::SequenceBindingTags");
static_assert(offsetof(UDelMarDriverCosmeticPlayerComponent, CosmeticData) == 0xe0, "Offset mismatch for UDelMarDriverCosmeticPlayerComponent::CosmeticData");

// Size: 0x48 (Inherited: 0x88, Single: 0xffffffc0)
class UDelMarCharacterCosmeticsSettings : public UPrimaryDataAsset
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    TArray<FPrimaryAssetId> RandomCharacters; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarCharacterCosmeticsSettings) == 0x48, "Size mismatch for UDelMarCharacterCosmeticsSettings");
static_assert(offsetof(UDelMarCharacterCosmeticsSettings, RandomCharacters) == 0x38, "Offset mismatch for UDelMarCharacterCosmeticsSettings::RandomCharacters");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarDriverCosmeticData
{
    UAthenaCharacterItemDefinition* CharacterDefinition; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FMcpVariantChannelInfo> CharacterVariantChannels; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarDriverCosmeticData) == 0x18, "Size mismatch for FDelMarDriverCosmeticData");
static_assert(offsetof(FDelMarDriverCosmeticData, CharacterDefinition) == 0x0, "Offset mismatch for FDelMarDriverCosmeticData::CharacterDefinition");
static_assert(offsetof(FDelMarDriverCosmeticData, CharacterVariantChannels) == 0x8, "Offset mismatch for FDelMarDriverCosmeticData::CharacterVariantChannels");

