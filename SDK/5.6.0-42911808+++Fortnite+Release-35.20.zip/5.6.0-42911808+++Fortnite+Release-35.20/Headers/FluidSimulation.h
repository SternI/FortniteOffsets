/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FluidSimulation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "Water.h"
#include "Blueprints.h"

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FFluidForceSocketInfo
{
    TMap<FName, FName> SocketsandEndpoints_6_B3EDD8FC43A7C681151F46BE0AA158C5; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FFluidForceSocketInfo) == 0x50, "Size mismatch for FFluidForceSocketInfo");
static_assert(offsetof(FFluidForceSocketInfo, SocketsandEndpoints_6_B3EDD8FC43A7C681151F46BE0AA158C5) == 0x0, "Offset mismatch for FFluidForceSocketInfo::SocketsandEndpoints_6_B3EDD8FC43A7C681151F46BE0AA158C5");

// Size: 0x148 (Inherited: 0x0, Single: 0x148)
struct FFluidForceDynamicPerInstanceData
{
    FFluidForceDynamic ForceInfo_2_A6A35E3243FAF59D161A5FBAA2F6F2B1; // 0x0 (Size: 0x70, Type: StructProperty)
    FVector ComponentLocation_13_959307184C8E5CCACA55FC8378D92CFD; // 0x70 (Size: 0x18, Type: StructProperty)
    FVector ComponentVelocity_5_4F6589474918826DF8A6468CF0F2C361; // 0x88 (Size: 0x18, Type: StructProperty)
    float BoundsRadius_30_ADFF818743BE39AC4A481D995CB50D03; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float WaterLevel_34_A4E505D148073B883CA7B1B09A3E34A8; // 0xa4 (Size: 0x4, Type: FloatProperty)
    TMap<FVector, FName> SocketLocationMap_21_ABF6AA244A5F84728A5E83BE2328C7FA; // 0xa8 (Size: 0x50, Type: MapProperty)
    TMap<FVector, FName> SocketVelocityMap_26_82B0E24B45935A12E1949F918A59A537; // 0xf8 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FFluidForceDynamicPerInstanceData) == 0x148, "Size mismatch for FFluidForceDynamicPerInstanceData");
static_assert(offsetof(FFluidForceDynamicPerInstanceData, ForceInfo_2_A6A35E3243FAF59D161A5FBAA2F6F2B1) == 0x0, "Offset mismatch for FFluidForceDynamicPerInstanceData::ForceInfo_2_A6A35E3243FAF59D161A5FBAA2F6F2B1");
static_assert(offsetof(FFluidForceDynamicPerInstanceData, ComponentLocation_13_959307184C8E5CCACA55FC8378D92CFD) == 0x70, "Offset mismatch for FFluidForceDynamicPerInstanceData::ComponentLocation_13_959307184C8E5CCACA55FC8378D92CFD");
static_assert(offsetof(FFluidForceDynamicPerInstanceData, ComponentVelocity_5_4F6589474918826DF8A6468CF0F2C361) == 0x88, "Offset mismatch for FFluidForceDynamicPerInstanceData::ComponentVelocity_5_4F6589474918826DF8A6468CF0F2C361");
static_assert(offsetof(FFluidForceDynamicPerInstanceData, BoundsRadius_30_ADFF818743BE39AC4A481D995CB50D03) == 0xa0, "Offset mismatch for FFluidForceDynamicPerInstanceData::BoundsRadius_30_ADFF818743BE39AC4A481D995CB50D03");
static_assert(offsetof(FFluidForceDynamicPerInstanceData, WaterLevel_34_A4E505D148073B883CA7B1B09A3E34A8) == 0xa4, "Offset mismatch for FFluidForceDynamicPerInstanceData::WaterLevel_34_A4E505D148073B883CA7B1B09A3E34A8");
static_assert(offsetof(FFluidForceDynamicPerInstanceData, SocketLocationMap_21_ABF6AA244A5F84728A5E83BE2328C7FA) == 0xa8, "Offset mismatch for FFluidForceDynamicPerInstanceData::SocketLocationMap_21_ABF6AA244A5F84728A5E83BE2328C7FA");
static_assert(offsetof(FFluidForceDynamicPerInstanceData, SocketVelocityMap_26_82B0E24B45935A12E1949F918A59A537) == 0xf8, "Offset mismatch for FFluidForceDynamicPerInstanceData::SocketVelocityMap_26_82B0E24B45935A12E1949F918A59A537");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FFluidForceDynamic
{
    TEnumAsByte<FluidDynamicForceMeshType> ForceType_28_DDC16EE543D2DFD3BA29C49D32198C9C; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float ForceRadius_32_C31B527C4C367A5CA5E1DF8E49E76234; // 0x4 (Size: 0x4, Type: FloatProperty)
    float ForceStrength_33_2CAA30794D1EFF60AE1C3491D011CECF; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    USceneComponent* ForceComponent_34_ABF6640F40D37677EF6F809E09046055; // 0x10 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* MaterialOverride_25_5A792CE8489A59E5D9B24F9E4DCFE94A; // 0x18 (Size: 0x8, Type: ObjectProperty)
    FFluidForceSocketInfo SkeletalMeshSetup_31_51A4130440BAFFBA1DA0FE83E942A30A; // 0x20 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FFluidForceDynamic) == 0x70, "Size mismatch for FFluidForceDynamic");
static_assert(offsetof(FFluidForceDynamic, ForceType_28_DDC16EE543D2DFD3BA29C49D32198C9C) == 0x0, "Offset mismatch for FFluidForceDynamic::ForceType_28_DDC16EE543D2DFD3BA29C49D32198C9C");
static_assert(offsetof(FFluidForceDynamic, ForceRadius_32_C31B527C4C367A5CA5E1DF8E49E76234) == 0x4, "Offset mismatch for FFluidForceDynamic::ForceRadius_32_C31B527C4C367A5CA5E1DF8E49E76234");
static_assert(offsetof(FFluidForceDynamic, ForceStrength_33_2CAA30794D1EFF60AE1C3491D011CECF) == 0x8, "Offset mismatch for FFluidForceDynamic::ForceStrength_33_2CAA30794D1EFF60AE1C3491D011CECF");
static_assert(offsetof(FFluidForceDynamic, ForceComponent_34_ABF6640F40D37677EF6F809E09046055) == 0x10, "Offset mismatch for FFluidForceDynamic::ForceComponent_34_ABF6640F40D37677EF6F809E09046055");
static_assert(offsetof(FFluidForceDynamic, MaterialOverride_25_5A792CE8489A59E5D9B24F9E4DCFE94A) == 0x18, "Offset mismatch for FFluidForceDynamic::MaterialOverride_25_5A792CE8489A59E5D9B24F9E4DCFE94A");
static_assert(offsetof(FFluidForceDynamic, SkeletalMeshSetup_31_51A4130440BAFFBA1DA0FE83E942A30A) == 0x20, "Offset mismatch for FFluidForceDynamic::SkeletalMeshSetup_31_51A4130440BAFFBA1DA0FE83E942A30A");

// Size: 0x61 (Inherited: 0x0, Single: 0x61)
struct FFluidForceImpulsePerInstanceData
{
    FFluidForceImpulse ImpulseSettings_41_C9A94C02422D8BF40DF6B1BB2A0D8CBC; // 0x0 (Size: 0x58, Type: StructProperty)
    float ElapsedTime_44_12C387C1450456E47FC74BBD11EEAE4F; // 0x58 (Size: 0x4, Type: FloatProperty)
    float StartOffset_48_78EF0E3F4B05F70C5679F9B9F41D590F; // 0x5c (Size: 0x4, Type: FloatProperty)
    bool IsSplashEffect_54_4A5B178940D26E71D6FCDF84584A5284; // 0x60 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FFluidForceImpulsePerInstanceData) == 0x61, "Size mismatch for FFluidForceImpulsePerInstanceData");
static_assert(offsetof(FFluidForceImpulsePerInstanceData, ImpulseSettings_41_C9A94C02422D8BF40DF6B1BB2A0D8CBC) == 0x0, "Offset mismatch for FFluidForceImpulsePerInstanceData::ImpulseSettings_41_C9A94C02422D8BF40DF6B1BB2A0D8CBC");
static_assert(offsetof(FFluidForceImpulsePerInstanceData, ElapsedTime_44_12C387C1450456E47FC74BBD11EEAE4F) == 0x58, "Offset mismatch for FFluidForceImpulsePerInstanceData::ElapsedTime_44_12C387C1450456E47FC74BBD11EEAE4F");
static_assert(offsetof(FFluidForceImpulsePerInstanceData, StartOffset_48_78EF0E3F4B05F70C5679F9B9F41D590F) == 0x5c, "Offset mismatch for FFluidForceImpulsePerInstanceData::StartOffset_48_78EF0E3F4B05F70C5679F9B9F41D590F");
static_assert(offsetof(FFluidForceImpulsePerInstanceData, IsSplashEffect_54_4A5B178940D26E71D6FCDF84584A5284) == 0x60, "Offset mismatch for FFluidForceImpulsePerInstanceData::IsSplashEffect_54_4A5B178940D26E71D6FCDF84584A5284");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FFluidForceImpulse
{
    FVector WorldPosition_32_C9A94C02422D8BF40DF6B1BB2A0D8CBC; // 0x0 (Size: 0x18, Type: StructProperty)
    float ForceRadius_31_C31B527C4C367A5CA5E1DF8E49E76234; // 0x18 (Size: 0x4, Type: FloatProperty)
    float ForceStrength_30_2CAA30794D1EFF60AE1C3491D011CECF; // 0x1c (Size: 0x4, Type: FloatProperty)
    UMaterialInterface* MaterialOverride_24_5A792CE8489A59E5D9B24F9E4DCFE94A; // 0x20 (Size: 0x8, Type: ObjectProperty)
    float Lifetime_34_C2749C1449C41D4F236BCBAF6ED34113; // 0x28 (Size: 0x4, Type: FloatProperty)
    float StrengthoverLifePower_41_85B52C994A7ED323A34BF4BBCB0DFA0F; // 0x2c (Size: 0x4, Type: FloatProperty)
    FFluidForceImpulseTimedEffects TimedWaterDropSplashes_38_2CB1456B483AEF3A52677AAF4152E31E; // 0x30 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FFluidForceImpulse) == 0x58, "Size mismatch for FFluidForceImpulse");
static_assert(offsetof(FFluidForceImpulse, WorldPosition_32_C9A94C02422D8BF40DF6B1BB2A0D8CBC) == 0x0, "Offset mismatch for FFluidForceImpulse::WorldPosition_32_C9A94C02422D8BF40DF6B1BB2A0D8CBC");
static_assert(offsetof(FFluidForceImpulse, ForceRadius_31_C31B527C4C367A5CA5E1DF8E49E76234) == 0x18, "Offset mismatch for FFluidForceImpulse::ForceRadius_31_C31B527C4C367A5CA5E1DF8E49E76234");
static_assert(offsetof(FFluidForceImpulse, ForceStrength_30_2CAA30794D1EFF60AE1C3491D011CECF) == 0x1c, "Offset mismatch for FFluidForceImpulse::ForceStrength_30_2CAA30794D1EFF60AE1C3491D011CECF");
static_assert(offsetof(FFluidForceImpulse, MaterialOverride_24_5A792CE8489A59E5D9B24F9E4DCFE94A) == 0x20, "Offset mismatch for FFluidForceImpulse::MaterialOverride_24_5A792CE8489A59E5D9B24F9E4DCFE94A");
static_assert(offsetof(FFluidForceImpulse, Lifetime_34_C2749C1449C41D4F236BCBAF6ED34113) == 0x28, "Offset mismatch for FFluidForceImpulse::Lifetime_34_C2749C1449C41D4F236BCBAF6ED34113");
static_assert(offsetof(FFluidForceImpulse, StrengthoverLifePower_41_85B52C994A7ED323A34BF4BBCB0DFA0F) == 0x2c, "Offset mismatch for FFluidForceImpulse::StrengthoverLifePower_41_85B52C994A7ED323A34BF4BBCB0DFA0F");
static_assert(offsetof(FFluidForceImpulse, TimedWaterDropSplashes_38_2CB1456B483AEF3A52677AAF4152E31E) == 0x30, "Offset mismatch for FFluidForceImpulse::TimedWaterDropSplashes_38_2CB1456B483AEF3A52677AAF4152E31E");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFluidForceImpulseTimedEffects
{
    bool EnableWaterDropsEffect_39_0A7932284406807D62695D8E0927BD70; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float EffectRadius_30_C9A94C02422D8BF40DF6B1BB2A0D8CBC; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Strength_29_2CAA30794D1EFF60AE1C3491D011CECF; // 0x8 (Size: 0x4, Type: FloatProperty)
    float WaterDropsperSquareMeter_27_C31B527C4C367A5CA5E1DF8E49E76234; // 0xc (Size: 0x4, Type: FloatProperty)
    float StartTimeOffset_33_5A792CE8489A59E5D9B24F9E4DCFE94A; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Lifetime_35_C2749C1449C41D4F236BCBAF6ED34113; // 0x14 (Size: 0x4, Type: FloatProperty)
    float StrengthoverLifePower_37_4FA6941A4AD024828AFEB782783DD01C; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    UMaterialInterface* MaterialOverride_42_FB856A244A1713590BB76EAA7CC7A0DF; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFluidForceImpulseTimedEffects) == 0x28, "Size mismatch for FFluidForceImpulseTimedEffects");
static_assert(offsetof(FFluidForceImpulseTimedEffects, EnableWaterDropsEffect_39_0A7932284406807D62695D8E0927BD70) == 0x0, "Offset mismatch for FFluidForceImpulseTimedEffects::EnableWaterDropsEffect_39_0A7932284406807D62695D8E0927BD70");
static_assert(offsetof(FFluidForceImpulseTimedEffects, EffectRadius_30_C9A94C02422D8BF40DF6B1BB2A0D8CBC) == 0x4, "Offset mismatch for FFluidForceImpulseTimedEffects::EffectRadius_30_C9A94C02422D8BF40DF6B1BB2A0D8CBC");
static_assert(offsetof(FFluidForceImpulseTimedEffects, Strength_29_2CAA30794D1EFF60AE1C3491D011CECF) == 0x8, "Offset mismatch for FFluidForceImpulseTimedEffects::Strength_29_2CAA30794D1EFF60AE1C3491D011CECF");
static_assert(offsetof(FFluidForceImpulseTimedEffects, WaterDropsperSquareMeter_27_C31B527C4C367A5CA5E1DF8E49E76234) == 0xc, "Offset mismatch for FFluidForceImpulseTimedEffects::WaterDropsperSquareMeter_27_C31B527C4C367A5CA5E1DF8E49E76234");
static_assert(offsetof(FFluidForceImpulseTimedEffects, StartTimeOffset_33_5A792CE8489A59E5D9B24F9E4DCFE94A) == 0x10, "Offset mismatch for FFluidForceImpulseTimedEffects::StartTimeOffset_33_5A792CE8489A59E5D9B24F9E4DCFE94A");
static_assert(offsetof(FFluidForceImpulseTimedEffects, Lifetime_35_C2749C1449C41D4F236BCBAF6ED34113) == 0x14, "Offset mismatch for FFluidForceImpulseTimedEffects::Lifetime_35_C2749C1449C41D4F236BCBAF6ED34113");
static_assert(offsetof(FFluidForceImpulseTimedEffects, StrengthoverLifePower_37_4FA6941A4AD024828AFEB782783DD01C) == 0x18, "Offset mismatch for FFluidForceImpulseTimedEffects::StrengthoverLifePower_37_4FA6941A4AD024828AFEB782783DD01C");
static_assert(offsetof(FFluidForceImpulseTimedEffects, MaterialOverride_42_FB856A244A1713590BB76EAA7CC7A0DF) == 0x20, "Offset mismatch for FFluidForceImpulseTimedEffects::MaterialOverride_42_FB856A244A1713590BB76EAA7CC7A0DF");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class ABP_FluidSimParent_C : public AActor
{
public:
    USceneComponent* DefaultSceneRoot; // 0x2a8 (Size: 0x8, Type: ObjectProperty)

public:
    void GetNormalRT(UTextureRenderTarget2D*& RT); // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(ABP_FluidSimParent_C) == 0x2b0, "Size mismatch for ABP_FluidSimParent_C");
static_assert(offsetof(ABP_FluidSimParent_C, DefaultSceneRoot) == 0x2a8, "Offset mismatch for ABP_FluidSimParent_C::DefaultSceneRoot");

// Size: 0x5e8 (Inherited: 0x580, Single: 0x68)
class ABP_FluidSim_01_C : public ABP_FluidSimParent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2b0 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* DebugPlane; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* RippleSimMID; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* RenderNormalsMID; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* DisplayMID; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* DisplayBottomMID; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* CrossSectionMID; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    TArray<UTextureRenderTarget2D*> RippleRTs; // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    UMaterialInterface* Display_Material; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    double Virtual_FPS; // 0x300 (Size: 0x8, Type: DoubleProperty)
    int32_t Passes; // 0x308 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_30c[0x4]; // 0x30c (Size: 0x4, Type: PaddingProperty)
    double TimeAccumulator; // 0x310 (Size: 0x8, Type: DoubleProperty)
    double FixedStep; // 0x318 (Size: 0x8, Type: DoubleProperty)
    bool Enabled; // 0x320 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_321[0x7]; // 0x321 (Size: 0x7, Type: PaddingProperty)
    double Fluid_Size; // 0x328 (Size: 0x8, Type: DoubleProperty)
    int32_t Resolution; // 0x330 (Size: 0x4, Type: IntProperty)
    TEnumAsByte<FluidBoundary> Boundary_Condition; // 0x334 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_335[0x3]; // 0x335 (Size: 0x3, Type: PaddingProperty)
    double Travel_Speed; // 0x338 (Size: 0x8, Type: DoubleProperty)
    double Damping; // 0x340 (Size: 0x8, Type: DoubleProperty)
    UTextureRenderTarget2D* NormalRT; // 0x348 (Size: 0x8, Type: ObjectProperty)
    FVector CutPos; // 0x350 (Size: 0x18, Type: StructProperty)
    FVector PrevLoc; // 0x368 (Size: 0x18, Type: StructProperty)
    FVector PrecLoc2; // 0x380 (Size: 0x18, Type: StructProperty)
    FVector PrevOffset; // 0x398 (Size: 0x18, Type: StructProperty)
    FVector PrevOffset2; // 0x3b0 (Size: 0x18, Type: StructProperty)
    FVector GridCenter; // 0x3c8 (Size: 0x18, Type: StructProperty)
    UTextureRenderTarget2D* TempRT; // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* ForcesRT; // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    double ApplyForces; // 0x3f0 (Size: 0x8, Type: DoubleProperty)
    ALandscapeWaterInfo_C* LandscapeWaterInfo; // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    int32_t Renders_Per_Frame; // 0x400 (Size: 0x4, Type: IntProperty)
    bool Show_Cross_Section; // 0x404 (Size: 0x1, Type: BoolProperty)
    bool Perf_Test_Mode; // 0x405 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_406[0x2]; // 0x406 (Size: 0x2, Type: PaddingProperty)
    UTextureRenderTarget2D* PerfRT; // 0x408 (Size: 0x8, Type: ObjectProperty)
    TArray<FFluidForceImpulsePerInstanceData> ImpulseForces; // 0x410 (Size: 0x10, Type: ArrayProperty)
    TMap<FFluidForceDynamicPerInstanceData, UActorComponent*> DynamicForces; // 0x420 (Size: 0x50, Type: MapProperty)
    TMap<UMaterialInstanceDynamic*, UMaterialInterface*> ForceParentAndMIDMap; // 0x470 (Size: 0x50, Type: MapProperty)
    bool Show_Simulation_Mesh; // 0x4c0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4c1[0x7]; // 0x4c1 (Size: 0x7, Type: PaddingProperty)
    UStaticMeshComponent* Fluid_Display_Mesh; // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Cross_Section_Mesh; // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    double FluidSizeSquared; // 0x4d8 (Size: 0x8, Type: DoubleProperty)
    bool LocalPawnRef; // 0x4e0 (Size: 0x1, Type: BoolProperty)
    bool Debug_Text; // 0x4e1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4e2[0x2]; // 0x4e2 (Size: 0x2, Type: PaddingProperty)
    int32_t Pawn_Check_Every_N_Frames; // 0x4e4 (Size: 0x4, Type: IntProperty)
    TMap<FFluidForceDynamicPerInstanceData, UActorComponent*> ProjectileForces; // 0x4e8 (Size: 0x50, Type: MapProperty)
    bool Follow_Player_; // 0x538 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_539[0x3]; // 0x539 (Size: 0x3, Type: PaddingProperty)
    int32_t Frames_Since_Last_Active_Force; // 0x53c (Size: 0x4, Type: IntProperty)
    bool Use_Terrain_Water_System; // 0x540 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_541[0x7]; // 0x541 (Size: 0x7, Type: PaddingProperty)
    UMaterialInstanceDynamic* PhysicsForceMID; // 0x548 (Size: 0x8, Type: ObjectProperty)
    bool Add_Physics_Forces; // 0x550 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_551[0x7]; // 0x551 (Size: 0x7, Type: PaddingProperty)
    UTexture* WaterVelocityTexture; // 0x558 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<AWaterZone*> WaterZone; // 0x560 (Size: 0x20, Type: SoftObjectProperty)
    bool UpdateForcesInFixedTimeStep; // 0x580 (Size: 0x1, Type: BoolProperty)
    bool UpdateSimInFixedTimeStep; // 0x581 (Size: 0x1, Type: BoolProperty)
    bool UpdateNormalInFixedTimeStep; // 0x582 (Size: 0x1, Type: BoolProperty)
    bool ShowDebugWaterPlane; // 0x583 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_584[0x4]; // 0x584 (Size: 0x4, Type: PaddingProperty)
    UMaterialInstanceDynamic* DebugWaterPlaneMID; // 0x588 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* DebugRippleRT1; // 0x590 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* DebugRippleRT2; // 0x598 (Size: 0x8, Type: ObjectProperty)
    UTextureRenderTarget2D* DebugRippleRTCurrent; // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    int32_t WaterZoneIndex; // 0x5a8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_5ac[0x4]; // 0x5ac (Size: 0x4, Type: PaddingProperty)
    double MaxFlowVelocity; // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    FVector2D WaterZoneExtent; // 0x5b8 (Size: 0x10, Type: StructProperty)
    FVector WaterZoneLocation; // 0x5c8 (Size: 0x18, Type: StructProperty)
    UMaterialInterface* DefaultSplashMaterial; // 0x5e0 (Size: 0x8, Type: ObjectProperty)

public:
    void GridMovement(); // 0x288a61c (Index: 0x1, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void GetPlayerPawnForces(); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetNormalRT(UTextureRenderTarget2D*& RT); // 0x288a61c (Index: 0x3, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void GetLocalPawn(APawn*& Pawn); // 0x288a61c (Index: 0x4, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void Get_LandscapeWaterInfo(AWaterZone*& WaterZone); // 0x288a61c (Index: 0x5, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Get_Frames_Since_Last_Active_Forces(); // 0x288a61c (Index: 0x6, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Get_Force_MID(UMaterialInterface* Parent, UMaterialInstanceDynamic*& Mid); // 0x288a61c (Index: 0x7, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void Draw_Impulse_Force(UCanvas*& Canvas, FVector2D& Canvas_Size, FFluidForceImpulsePerInstanceData& Impulse_Settings); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Draw_Dynamic_Force(UCanvas* Canvas, FVector2D Canvas_Size, FFluidForceDynamicPerInstanceData Dynamic_Force_Settings); // 0x288a61c (Index: 0xb, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void CycleDebugRenderTargets(); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Cycle_Render_Targets(UTextureRenderTarget2D*& Current_Target); // 0x288a61c (Index: 0xd, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void Convert_Force_Position(FVector& Force_Location, double& Sine_Bob, FVector& UV_Location); // 0x288a61c (Index: 0xe, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void Clear_Sim_from_Waterbody_MIDs(); // 0x288a61c (Index: 0xf, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Apply_Fluid_Force_Impulse(FFluidForceImpulse& Impulse_Settings); // 0x288a61c (Index: 0x11, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Validate_RTs(bool& RTs_All_Valid); // 0x288a61c (Index: 0x13, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x14, Flags: Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Update_Impulse_Lifetimes(); // 0x288a61c (Index: 0x15, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Update_Dynamic_Forces(); // 0x288a61c (Index: 0x16, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetupSimMIDs(); // 0x288a61c (Index: 0x17, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetupDisplayMIDs(); // 0x288a61c (Index: 0x18, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetSingleWaterBodyMIDTexture(AWaterBody*& WaterBody); // 0x288a61c (Index: 0x1a, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Waterbody_MID_Params(); // 0x288a61c (Index: 0x23, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Remove_Projectile_Force(UActorComponent*& Component); // 0x288a61c (Index: 0x24, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Remove_Dynamic_Force(UActorComponent*& Component); // 0x288a61c (Index: 0x25, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Register_Projectile_Force(FFluidForceDynamic& Dynamic_Fluid_Force, USceneComponent*& Tracked_Component); // 0x288a61c (Index: 0x28, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Register_Dynamic_Force(FFluidForceDynamic& Dynamic_Fluid_Force, USceneComponent*& Tracked_Component, double& WaterLevel); // 0x288a61c (Index: 0x29, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x2b, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x2c, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABP_FluidSim_01_C) == 0x5e8, "Size mismatch for ABP_FluidSim_01_C");
static_assert(offsetof(ABP_FluidSim_01_C, UberGraphFrame) == 0x2b0, "Offset mismatch for ABP_FluidSim_01_C::UberGraphFrame");
static_assert(offsetof(ABP_FluidSim_01_C, DebugPlane) == 0x2b8, "Offset mismatch for ABP_FluidSim_01_C::DebugPlane");
static_assert(offsetof(ABP_FluidSim_01_C, RippleSimMID) == 0x2c0, "Offset mismatch for ABP_FluidSim_01_C::RippleSimMID");
static_assert(offsetof(ABP_FluidSim_01_C, RenderNormalsMID) == 0x2c8, "Offset mismatch for ABP_FluidSim_01_C::RenderNormalsMID");
static_assert(offsetof(ABP_FluidSim_01_C, DisplayMID) == 0x2d0, "Offset mismatch for ABP_FluidSim_01_C::DisplayMID");
static_assert(offsetof(ABP_FluidSim_01_C, DisplayBottomMID) == 0x2d8, "Offset mismatch for ABP_FluidSim_01_C::DisplayBottomMID");
static_assert(offsetof(ABP_FluidSim_01_C, CrossSectionMID) == 0x2e0, "Offset mismatch for ABP_FluidSim_01_C::CrossSectionMID");
static_assert(offsetof(ABP_FluidSim_01_C, RippleRTs) == 0x2e8, "Offset mismatch for ABP_FluidSim_01_C::RippleRTs");
static_assert(offsetof(ABP_FluidSim_01_C, Display_Material) == 0x2f8, "Offset mismatch for ABP_FluidSim_01_C::Display_Material");
static_assert(offsetof(ABP_FluidSim_01_C, Virtual_FPS) == 0x300, "Offset mismatch for ABP_FluidSim_01_C::Virtual_FPS");
static_assert(offsetof(ABP_FluidSim_01_C, Passes) == 0x308, "Offset mismatch for ABP_FluidSim_01_C::Passes");
static_assert(offsetof(ABP_FluidSim_01_C, TimeAccumulator) == 0x310, "Offset mismatch for ABP_FluidSim_01_C::TimeAccumulator");
static_assert(offsetof(ABP_FluidSim_01_C, FixedStep) == 0x318, "Offset mismatch for ABP_FluidSim_01_C::FixedStep");
static_assert(offsetof(ABP_FluidSim_01_C, Enabled) == 0x320, "Offset mismatch for ABP_FluidSim_01_C::Enabled");
static_assert(offsetof(ABP_FluidSim_01_C, Fluid_Size) == 0x328, "Offset mismatch for ABP_FluidSim_01_C::Fluid_Size");
static_assert(offsetof(ABP_FluidSim_01_C, Resolution) == 0x330, "Offset mismatch for ABP_FluidSim_01_C::Resolution");
static_assert(offsetof(ABP_FluidSim_01_C, Boundary_Condition) == 0x334, "Offset mismatch for ABP_FluidSim_01_C::Boundary_Condition");
static_assert(offsetof(ABP_FluidSim_01_C, Travel_Speed) == 0x338, "Offset mismatch for ABP_FluidSim_01_C::Travel_Speed");
static_assert(offsetof(ABP_FluidSim_01_C, Damping) == 0x340, "Offset mismatch for ABP_FluidSim_01_C::Damping");
static_assert(offsetof(ABP_FluidSim_01_C, NormalRT) == 0x348, "Offset mismatch for ABP_FluidSim_01_C::NormalRT");
static_assert(offsetof(ABP_FluidSim_01_C, CutPos) == 0x350, "Offset mismatch for ABP_FluidSim_01_C::CutPos");
static_assert(offsetof(ABP_FluidSim_01_C, PrevLoc) == 0x368, "Offset mismatch for ABP_FluidSim_01_C::PrevLoc");
static_assert(offsetof(ABP_FluidSim_01_C, PrecLoc2) == 0x380, "Offset mismatch for ABP_FluidSim_01_C::PrecLoc2");
static_assert(offsetof(ABP_FluidSim_01_C, PrevOffset) == 0x398, "Offset mismatch for ABP_FluidSim_01_C::PrevOffset");
static_assert(offsetof(ABP_FluidSim_01_C, PrevOffset2) == 0x3b0, "Offset mismatch for ABP_FluidSim_01_C::PrevOffset2");
static_assert(offsetof(ABP_FluidSim_01_C, GridCenter) == 0x3c8, "Offset mismatch for ABP_FluidSim_01_C::GridCenter");
static_assert(offsetof(ABP_FluidSim_01_C, TempRT) == 0x3e0, "Offset mismatch for ABP_FluidSim_01_C::TempRT");
static_assert(offsetof(ABP_FluidSim_01_C, ForcesRT) == 0x3e8, "Offset mismatch for ABP_FluidSim_01_C::ForcesRT");
static_assert(offsetof(ABP_FluidSim_01_C, ApplyForces) == 0x3f0, "Offset mismatch for ABP_FluidSim_01_C::ApplyForces");
static_assert(offsetof(ABP_FluidSim_01_C, LandscapeWaterInfo) == 0x3f8, "Offset mismatch for ABP_FluidSim_01_C::LandscapeWaterInfo");
static_assert(offsetof(ABP_FluidSim_01_C, Renders_Per_Frame) == 0x400, "Offset mismatch for ABP_FluidSim_01_C::Renders_Per_Frame");
static_assert(offsetof(ABP_FluidSim_01_C, Show_Cross_Section) == 0x404, "Offset mismatch for ABP_FluidSim_01_C::Show_Cross_Section");
static_assert(offsetof(ABP_FluidSim_01_C, Perf_Test_Mode) == 0x405, "Offset mismatch for ABP_FluidSim_01_C::Perf_Test_Mode");
static_assert(offsetof(ABP_FluidSim_01_C, PerfRT) == 0x408, "Offset mismatch for ABP_FluidSim_01_C::PerfRT");
static_assert(offsetof(ABP_FluidSim_01_C, ImpulseForces) == 0x410, "Offset mismatch for ABP_FluidSim_01_C::ImpulseForces");
static_assert(offsetof(ABP_FluidSim_01_C, DynamicForces) == 0x420, "Offset mismatch for ABP_FluidSim_01_C::DynamicForces");
static_assert(offsetof(ABP_FluidSim_01_C, ForceParentAndMIDMap) == 0x470, "Offset mismatch for ABP_FluidSim_01_C::ForceParentAndMIDMap");
static_assert(offsetof(ABP_FluidSim_01_C, Show_Simulation_Mesh) == 0x4c0, "Offset mismatch for ABP_FluidSim_01_C::Show_Simulation_Mesh");
static_assert(offsetof(ABP_FluidSim_01_C, Fluid_Display_Mesh) == 0x4c8, "Offset mismatch for ABP_FluidSim_01_C::Fluid_Display_Mesh");
static_assert(offsetof(ABP_FluidSim_01_C, Cross_Section_Mesh) == 0x4d0, "Offset mismatch for ABP_FluidSim_01_C::Cross_Section_Mesh");
static_assert(offsetof(ABP_FluidSim_01_C, FluidSizeSquared) == 0x4d8, "Offset mismatch for ABP_FluidSim_01_C::FluidSizeSquared");
static_assert(offsetof(ABP_FluidSim_01_C, LocalPawnRef) == 0x4e0, "Offset mismatch for ABP_FluidSim_01_C::LocalPawnRef");
static_assert(offsetof(ABP_FluidSim_01_C, Debug_Text) == 0x4e1, "Offset mismatch for ABP_FluidSim_01_C::Debug_Text");
static_assert(offsetof(ABP_FluidSim_01_C, Pawn_Check_Every_N_Frames) == 0x4e4, "Offset mismatch for ABP_FluidSim_01_C::Pawn_Check_Every_N_Frames");
static_assert(offsetof(ABP_FluidSim_01_C, ProjectileForces) == 0x4e8, "Offset mismatch for ABP_FluidSim_01_C::ProjectileForces");
static_assert(offsetof(ABP_FluidSim_01_C, Follow_Player_) == 0x538, "Offset mismatch for ABP_FluidSim_01_C::Follow_Player_");
static_assert(offsetof(ABP_FluidSim_01_C, Frames_Since_Last_Active_Force) == 0x53c, "Offset mismatch for ABP_FluidSim_01_C::Frames_Since_Last_Active_Force");
static_assert(offsetof(ABP_FluidSim_01_C, Use_Terrain_Water_System) == 0x540, "Offset mismatch for ABP_FluidSim_01_C::Use_Terrain_Water_System");
static_assert(offsetof(ABP_FluidSim_01_C, PhysicsForceMID) == 0x548, "Offset mismatch for ABP_FluidSim_01_C::PhysicsForceMID");
static_assert(offsetof(ABP_FluidSim_01_C, Add_Physics_Forces) == 0x550, "Offset mismatch for ABP_FluidSim_01_C::Add_Physics_Forces");
static_assert(offsetof(ABP_FluidSim_01_C, WaterVelocityTexture) == 0x558, "Offset mismatch for ABP_FluidSim_01_C::WaterVelocityTexture");
static_assert(offsetof(ABP_FluidSim_01_C, WaterZone) == 0x560, "Offset mismatch for ABP_FluidSim_01_C::WaterZone");
static_assert(offsetof(ABP_FluidSim_01_C, UpdateForcesInFixedTimeStep) == 0x580, "Offset mismatch for ABP_FluidSim_01_C::UpdateForcesInFixedTimeStep");
static_assert(offsetof(ABP_FluidSim_01_C, UpdateSimInFixedTimeStep) == 0x581, "Offset mismatch for ABP_FluidSim_01_C::UpdateSimInFixedTimeStep");
static_assert(offsetof(ABP_FluidSim_01_C, UpdateNormalInFixedTimeStep) == 0x582, "Offset mismatch for ABP_FluidSim_01_C::UpdateNormalInFixedTimeStep");
static_assert(offsetof(ABP_FluidSim_01_C, ShowDebugWaterPlane) == 0x583, "Offset mismatch for ABP_FluidSim_01_C::ShowDebugWaterPlane");
static_assert(offsetof(ABP_FluidSim_01_C, DebugWaterPlaneMID) == 0x588, "Offset mismatch for ABP_FluidSim_01_C::DebugWaterPlaneMID");
static_assert(offsetof(ABP_FluidSim_01_C, DebugRippleRT1) == 0x590, "Offset mismatch for ABP_FluidSim_01_C::DebugRippleRT1");
static_assert(offsetof(ABP_FluidSim_01_C, DebugRippleRT2) == 0x598, "Offset mismatch for ABP_FluidSim_01_C::DebugRippleRT2");
static_assert(offsetof(ABP_FluidSim_01_C, DebugRippleRTCurrent) == 0x5a0, "Offset mismatch for ABP_FluidSim_01_C::DebugRippleRTCurrent");
static_assert(offsetof(ABP_FluidSim_01_C, WaterZoneIndex) == 0x5a8, "Offset mismatch for ABP_FluidSim_01_C::WaterZoneIndex");
static_assert(offsetof(ABP_FluidSim_01_C, MaxFlowVelocity) == 0x5b0, "Offset mismatch for ABP_FluidSim_01_C::MaxFlowVelocity");
static_assert(offsetof(ABP_FluidSim_01_C, WaterZoneExtent) == 0x5b8, "Offset mismatch for ABP_FluidSim_01_C::WaterZoneExtent");
static_assert(offsetof(ABP_FluidSim_01_C, WaterZoneLocation) == 0x5c8, "Offset mismatch for ABP_FluidSim_01_C::WaterZoneLocation");
static_assert(offsetof(ABP_FluidSim_01_C, DefaultSplashMaterial) == 0x5e0, "Offset mismatch for ABP_FluidSim_01_C::DefaultSplashMaterial");

