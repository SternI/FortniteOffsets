/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BladeHazardRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x9c8 (Inherited: 0x13c8, Single: 0xfffff600)
class AFortBladeHazard : public ABuildingGameplayActor
{
public:
    uint8_t SpinningDirection; // 0x9b0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9b1[0x7]; // 0x9b1 (Size: 0x7, Type: PaddingProperty)
    TArray<FTransform> CustomForceDirections; // 0x9b8 (Size: 0x10, Type: ArrayProperty)

protected:
    FVector GetForceDirectionForHit(const FHitResult Hit) const; // 0x1126fbd0 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(AFortBladeHazard) == 0x9c8, "Size mismatch for AFortBladeHazard");
static_assert(offsetof(AFortBladeHazard, SpinningDirection) == 0x9b0, "Offset mismatch for AFortBladeHazard::SpinningDirection");
static_assert(offsetof(AFortBladeHazard, CustomForceDirections) == 0x9b8, "Offset mismatch for AFortBladeHazard::CustomForceDirections");

