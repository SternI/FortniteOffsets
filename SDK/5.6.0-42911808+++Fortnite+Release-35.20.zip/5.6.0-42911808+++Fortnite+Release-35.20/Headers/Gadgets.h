/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Gadgets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "Niagara.h"
#include "Athena.h"
#include "GameplayAbilities.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UVariantScript_Glider_BistroAstronaut_Style_C : public UFortLoadoutTagDrivenVariantScript
{
public:

public:
    virtual FGameplayTag DetermineVariantSelection(const FFortAthenaLoadout Loadout) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UVariantScript_Glider_BistroAstronaut_Style_C) == 0x28, "Size mismatch for UVariantScript_Glider_BistroAstronaut_Style_C");

// Size: 0x3f8 (Inherited: 0x680, Single: 0xfffffd78)
class ABP_ZipLine_Athena_Harness_Yellow_C : public ABP_ZipLine_Athena_Harness_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x3b0 (Size: 0x8, Type: StructProperty)
    UNiagaraComponent* NS_Zipline_Pulley_SpeedLines_Converted; // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* NS_Zipline_Speedline; // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    float Alpha_NewTrack_0_AF34CA1D47D28FE19CCA3C98688125DE; // 0x3c8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Alpha__Direction_AF34CA1D47D28FE19CCA3C98688125DE; // 0x3cc (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3cd[0x3]; // 0x3cd (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* Alpha; // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    float Spark_NewTrack_0_A812B2F04CB78DDF352B84A578861501; // 0x3d8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Spark__Direction_A812B2F04CB78DDF352B84A578861501; // 0x3dc (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3dd[0x3]; // 0x3dd (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* spark; // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    double BeginLocation_z; // 0x3e8 (Size: 0x8, Type: DoubleProperty)
    double Location; // 0x3f0 (Size: 0x8, Type: DoubleProperty)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABP_ZipLine_Athena_Harness_Yellow_C) == 0x3f8, "Size mismatch for ABP_ZipLine_Athena_Harness_Yellow_C");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_Yellow_C, UberGraphFrame) == 0x3b0, "Offset mismatch for ABP_ZipLine_Athena_Harness_Yellow_C::UberGraphFrame");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_Yellow_C, NS_Zipline_Pulley_SpeedLines_Converted) == 0x3b8, "Offset mismatch for ABP_ZipLine_Athena_Harness_Yellow_C::NS_Zipline_Pulley_SpeedLines_Converted");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_Yellow_C, NS_Zipline_Speedline) == 0x3c0, "Offset mismatch for ABP_ZipLine_Athena_Harness_Yellow_C::NS_Zipline_Speedline");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_Yellow_C, Alpha_NewTrack_0_AF34CA1D47D28FE19CCA3C98688125DE) == 0x3c8, "Offset mismatch for ABP_ZipLine_Athena_Harness_Yellow_C::Alpha_NewTrack_0_AF34CA1D47D28FE19CCA3C98688125DE");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_Yellow_C, Alpha__Direction_AF34CA1D47D28FE19CCA3C98688125DE) == 0x3cc, "Offset mismatch for ABP_ZipLine_Athena_Harness_Yellow_C::Alpha__Direction_AF34CA1D47D28FE19CCA3C98688125DE");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_Yellow_C, Alpha) == 0x3d0, "Offset mismatch for ABP_ZipLine_Athena_Harness_Yellow_C::Alpha");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_Yellow_C, Spark_NewTrack_0_A812B2F04CB78DDF352B84A578861501) == 0x3d8, "Offset mismatch for ABP_ZipLine_Athena_Harness_Yellow_C::Spark_NewTrack_0_A812B2F04CB78DDF352B84A578861501");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_Yellow_C, Spark__Direction_A812B2F04CB78DDF352B84A578861501) == 0x3dc, "Offset mismatch for ABP_ZipLine_Athena_Harness_Yellow_C::Spark__Direction_A812B2F04CB78DDF352B84A578861501");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_Yellow_C, spark) == 0x3e0, "Offset mismatch for ABP_ZipLine_Athena_Harness_Yellow_C::spark");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_Yellow_C, BeginLocation_z) == 0x3e8, "Offset mismatch for ABP_ZipLine_Athena_Harness_Yellow_C::BeginLocation_z");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_Yellow_C, Location) == 0x3f0, "Offset mismatch for ABP_ZipLine_Athena_Harness_Yellow_C::Location");

// Size: 0x3b0 (Inherited: 0x2d0, Single: 0xe0)
class ABP_ZipLine_Athena_Harness_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    UParticleSystemComponent* P_Zipline_AttachedToPlayer; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_Zipline_Magnet; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UArrowComponent* Arrow; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* P_Zipline_Pulley_SpeedLines; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_Zipline_Motor; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* Scene; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* SpawnFX; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* DestroyFX; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* CollideDestroyVFX; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* AttachSound; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* DetachSound; // 0x300 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* AttachedPlayer; // 0x308 (Size: 0x8, Type: ObjectProperty)
    bool HasHitAnotherPlayer; // 0x310 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_311[0x7]; // 0x311 (Size: 0x7, Type: PaddingProperty)
    double ZiplineChimeVisualUpdate; // 0x318 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle ChimeTimer; // 0x320 (Size: 0x8, Type: StructProperty)
    FVector ZiplineDirection; // 0x328 (Size: 0x18, Type: StructProperty)
    ABP_Athena_Environmental_ZipLine_Spline_C* EnvZiplineSpline; // 0x340 (Size: 0x8, Type: ObjectProperty)
    double SplineRotationUpdateSeconds; // 0x348 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle MotorUpdateTimer; // 0x350 (Size: 0x8, Type: StructProperty)
    AFortAthenaZipline* AttachedZipline; // 0x358 (Size: 0x8, Type: ObjectProperty)
    bool debugOutput; // 0x360 (Size: 0x1, Type: BoolProperty)
    bool IsReversingMomentum; // 0x361 (Size: 0x1, Type: BoolProperty)
    bool bIsTravelingUphill; // 0x362 (Size: 0x1, Type: BoolProperty)
    bool bIsTravelingDownhill; // 0x363 (Size: 0x1, Type: BoolProperty)
    FGameplayTag GCNTag_Travel; // 0x364 (Size: 0x4, Type: StructProperty)
    USoundBase* TravelSound; // 0x368 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GCNTag_HighSpeed; // 0x370 (Size: 0x4, Type: StructProperty)
    FGameplayTag GCNTag_ZiplineBraking; // 0x374 (Size: 0x4, Type: StructProperty)
    bool bLoopingDownhillGCN; // 0x378 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_379[0x3]; // 0x379 (Size: 0x3, Type: PaddingProperty)
    FActiveGameplayEffectHandle DownhillTravelGE; // 0x37c (Size: 0x8, Type: StructProperty)
    bool UseMeshAttachment; // 0x384 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_385[0x3]; // 0x385 (Size: 0x3, Type: PaddingProperty)
    FVector CurrentDesired_Zipline_Offset; // 0x388 (Size: 0x18, Type: StructProperty)
    APROTOTYPE_BP_Athena_Dynamic_ZipLine_Spline_C* DynamicZiplineSpline; // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    USplineComponent* NewVar_0; // 0x3a8 (Size: 0x8, Type: ObjectProperty)

public:
    void Update_Audio_and_VFXParams(); // 0x288a61c (Index: 0x4, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveDestroyed(); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABP_ZipLine_Athena_Harness_C) == 0x3b0, "Size mismatch for ABP_ZipLine_Athena_Harness_C");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, UberGraphFrame) == 0x2a8, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::UberGraphFrame");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, P_Zipline_AttachedToPlayer) == 0x2b0, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::P_Zipline_AttachedToPlayer");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, SM_Zipline_Magnet) == 0x2b8, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::SM_Zipline_Magnet");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, Arrow) == 0x2c0, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::Arrow");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, P_Zipline_Pulley_SpeedLines) == 0x2c8, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::P_Zipline_Pulley_SpeedLines");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, SM_Zipline_Motor) == 0x2d0, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::SM_Zipline_Motor");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, Scene) == 0x2d8, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::Scene");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, SpawnFX) == 0x2e0, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::SpawnFX");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, DestroyFX) == 0x2e8, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::DestroyFX");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, CollideDestroyVFX) == 0x2f0, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::CollideDestroyVFX");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, AttachSound) == 0x2f8, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::AttachSound");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, DetachSound) == 0x300, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::DetachSound");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, AttachedPlayer) == 0x308, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::AttachedPlayer");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, HasHitAnotherPlayer) == 0x310, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::HasHitAnotherPlayer");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, ZiplineChimeVisualUpdate) == 0x318, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::ZiplineChimeVisualUpdate");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, ChimeTimer) == 0x320, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::ChimeTimer");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, ZiplineDirection) == 0x328, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::ZiplineDirection");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, EnvZiplineSpline) == 0x340, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::EnvZiplineSpline");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, SplineRotationUpdateSeconds) == 0x348, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::SplineRotationUpdateSeconds");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, MotorUpdateTimer) == 0x350, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::MotorUpdateTimer");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, AttachedZipline) == 0x358, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::AttachedZipline");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, debugOutput) == 0x360, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::debugOutput");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, IsReversingMomentum) == 0x361, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::IsReversingMomentum");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, bIsTravelingUphill) == 0x362, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::bIsTravelingUphill");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, bIsTravelingDownhill) == 0x363, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::bIsTravelingDownhill");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, GCNTag_Travel) == 0x364, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::GCNTag_Travel");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, TravelSound) == 0x368, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::TravelSound");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, GCNTag_HighSpeed) == 0x370, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::GCNTag_HighSpeed");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, GCNTag_ZiplineBraking) == 0x374, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::GCNTag_ZiplineBraking");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, bLoopingDownhillGCN) == 0x378, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::bLoopingDownhillGCN");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, DownhillTravelGE) == 0x37c, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::DownhillTravelGE");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, UseMeshAttachment) == 0x384, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::UseMeshAttachment");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, CurrentDesired_Zipline_Offset) == 0x388, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::CurrentDesired_Zipline_Offset");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, DynamicZiplineSpline) == 0x3a0, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::DynamicZiplineSpline");
static_assert(offsetof(ABP_ZipLine_Athena_Harness_C, NewVar_0) == 0x3a8, "Offset mismatch for ABP_ZipLine_Athena_Harness_C::NewVar_0");

