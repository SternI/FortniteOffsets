/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Buoyancy
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "DeveloperSettings.h"
#include "Engine.h"
#include "Water.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBuoyancyEventInterface : public UInterface
{
public:

public:
    virtual void OnSurfaceTouchBegin(AWaterBody*& WaterBodyActor, UPrimitiveComponent*& WaterComponent, UPrimitiveComponent*& SubmergedComponent, float& SubmergedVolume, const FVector SubmergedCenterOfMass, const FVector SubmergedVelocity); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintEvent)
    virtual void OnSurfaceTouchEnd(AWaterBody*& WaterBodyActor, UPrimitiveComponent*& WaterComponent, UPrimitiveComponent*& SubmergedComponent, float& SubmergedVolume, const FVector SubmergedCenterOfMass, const FVector SubmergedVelocity); // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintEvent)
    virtual void OnSurfaceTouching(AWaterBody*& WaterBodyActor, UPrimitiveComponent*& WaterComponent, UPrimitiveComponent*& SubmergedComponent, float& SubmergedVolume, const FVector SubmergedCenterOfMass, const FVector SubmergedVelocity); // 0x288a61c (Index: 0x2, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintEvent)
};

static_assert(sizeof(UBuoyancyEventInterface) == 0x28, "Size mismatch for UBuoyancyEventInterface");

// Size: 0x60 (Inherited: 0x58, Single: 0x8)
class UBuoyancyRuntimeSettings : public UDeveloperSettings
{
public:
    bool bBuoyancyEnabled; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bKeepFloatingObjectsAwake; // 0x31 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x2]; // 0x32 (Size: 0x2, Type: PaddingProperty)
    float WaterDensity; // 0x34 (Size: 0x4, Type: FloatProperty)
    float WaterDrag; // 0x38 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ECollisionChannel> CollisionChannelForWaterObjects; // 0x3c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_3d[0x3]; // 0x3d (Size: 0x3, Type: PaddingProperty)
    int32_t MaxNumBoundsSubdivisions; // 0x40 (Size: 0x4, Type: IntProperty)
    float MinBoundsSubdivisionVol; // 0x44 (Size: 0x4, Type: FloatProperty)
    char SurfaceTouchCallbackFlags; // 0x48 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_49[0x3]; // 0x49 (Size: 0x3, Type: PaddingProperty)
    float MinVelocityForSurfaceTouchCallback; // 0x4c (Size: 0x4, Type: FloatProperty)
    bool bEnableSplineKeyCacheGrid; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x3]; // 0x51 (Size: 0x3, Type: PaddingProperty)
    float SplineKeyCacheGridSize; // 0x54 (Size: 0x4, Type: FloatProperty)
    uint32_t SplineKeyCacheLimit; // 0x58 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UBuoyancyRuntimeSettings) == 0x60, "Size mismatch for UBuoyancyRuntimeSettings");
static_assert(offsetof(UBuoyancyRuntimeSettings, bBuoyancyEnabled) == 0x30, "Offset mismatch for UBuoyancyRuntimeSettings::bBuoyancyEnabled");
static_assert(offsetof(UBuoyancyRuntimeSettings, bKeepFloatingObjectsAwake) == 0x31, "Offset mismatch for UBuoyancyRuntimeSettings::bKeepFloatingObjectsAwake");
static_assert(offsetof(UBuoyancyRuntimeSettings, WaterDensity) == 0x34, "Offset mismatch for UBuoyancyRuntimeSettings::WaterDensity");
static_assert(offsetof(UBuoyancyRuntimeSettings, WaterDrag) == 0x38, "Offset mismatch for UBuoyancyRuntimeSettings::WaterDrag");
static_assert(offsetof(UBuoyancyRuntimeSettings, CollisionChannelForWaterObjects) == 0x3c, "Offset mismatch for UBuoyancyRuntimeSettings::CollisionChannelForWaterObjects");
static_assert(offsetof(UBuoyancyRuntimeSettings, MaxNumBoundsSubdivisions) == 0x40, "Offset mismatch for UBuoyancyRuntimeSettings::MaxNumBoundsSubdivisions");
static_assert(offsetof(UBuoyancyRuntimeSettings, MinBoundsSubdivisionVol) == 0x44, "Offset mismatch for UBuoyancyRuntimeSettings::MinBoundsSubdivisionVol");
static_assert(offsetof(UBuoyancyRuntimeSettings, SurfaceTouchCallbackFlags) == 0x48, "Offset mismatch for UBuoyancyRuntimeSettings::SurfaceTouchCallbackFlags");
static_assert(offsetof(UBuoyancyRuntimeSettings, MinVelocityForSurfaceTouchCallback) == 0x4c, "Offset mismatch for UBuoyancyRuntimeSettings::MinVelocityForSurfaceTouchCallback");
static_assert(offsetof(UBuoyancyRuntimeSettings, bEnableSplineKeyCacheGrid) == 0x50, "Offset mismatch for UBuoyancyRuntimeSettings::bEnableSplineKeyCacheGrid");
static_assert(offsetof(UBuoyancyRuntimeSettings, SplineKeyCacheGridSize) == 0x54, "Offset mismatch for UBuoyancyRuntimeSettings::SplineKeyCacheGridSize");
static_assert(offsetof(UBuoyancyRuntimeSettings, SplineKeyCacheLimit) == 0x58, "Offset mismatch for UBuoyancyRuntimeSettings::SplineKeyCacheLimit");

// Size: 0x90 (Inherited: 0xc8, Single: 0xffffffc8)
class UBuoyancySubsystem : public UTickableWorldSubsystem
{
public:

public:
    bool IsEnabled() const; // 0xc98449c (Index: 0x0, Flags: Final|Native|Public|Const)
};

static_assert(sizeof(UBuoyancySubsystem) == 0x90, "Size mismatch for UBuoyancySubsystem");

