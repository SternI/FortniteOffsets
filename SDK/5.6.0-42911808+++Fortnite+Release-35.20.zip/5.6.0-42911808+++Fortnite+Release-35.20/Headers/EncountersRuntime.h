/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EncountersRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "ModularGameplay.h"
#include "WorldConditions.h"
#include "FortniteGame.h"
#include "FortniteQuest.h"
#include "ItemizationCoreRuntime.h"
#include "LagerRuntime.h"
#include "GameplayStateTreeModule.h"
#include "StateTreeModule.h"
#include "VariableSelectionsRuntime.h"
#include "FortniteAI.h"
#include "GameplayTags.h"
#include "DataRegistry.h"
#include "PlayspaceSystem.h"
#include "GameplayAbilities.h"
#include "AIModule.h"

// Size: 0x2a8 (Inherited: 0x2d0, Single: 0xffffffd8)
class AEncounterGameplayCueActor : public AActor
{
public:
};

static_assert(sizeof(AEncounterGameplayCueActor) == 0x2a8, "Size mismatch for AEncounterGameplayCueActor");

// Size: 0x2c8 (Inherited: 0x2d0, Single: 0xfffffff8)
class AEncounterMobAnchor : public AActor
{
public:
    FGameplayTagContainer FilterTags; // 0x2a8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(AEncounterMobAnchor) == 0x2c8, "Size mismatch for AEncounterMobAnchor");
static_assert(offsetof(AEncounterMobAnchor, FilterTags) == 0x2a8, "Offset mismatch for AEncounterMobAnchor::FilterTags");

// Size: 0x230 (Inherited: 0x198, Single: 0x98)
class UEncounterMobManagerComponent : public UGameFrameworkComponent
{
public:
    TArray<FEncounterMobInstance> SpawnedMobs; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<FEncounterMobSpawnData> MobEncounterSpawnData; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    FEncounterMobSpawnInfo DefaultMobSpawnInfo; // 0xd8 (Size: 0xa0, Type: StructProperty)
    FScalableFloat LWMDensityWeight; // 0x178 (Size: 0x28, Type: StructProperty)
    FScalableFloat LWMDensityRange; // 0x1a0 (Size: 0x28, Type: StructProperty)
    uint8_t OnEncounterStarted[0x10]; // 0x1c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEncounterPaused[0x10]; // 0x1d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEncounterResumed[0x10]; // 0x1e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEncounterActorSpawned[0x10]; // 0x1f8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEncounterActorDead[0x10]; // 0x208 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEncounterEnded[0x10]; // 0x218 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TWeakObjectPtr<ALivingWorldEncounterPrefab*> EncounterPrefab; // 0x228 (Size: 0x8, Type: WeakObjectProperty)

public:
    void EndAndCleanupAllMobEncounters(); // 0x10037730 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void EndMobEncounter(const FGameplayTag MobIdentifier); // 0x10037744 (Index: 0x1, Flags: Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)
    void OnEncounterActorDead__DelegateSignature(FGameplayTag& MobIdentifier, AActor*& DamagedActor, AActor*& DamageCauser); // 0x288a61c (Index: 0x2, Flags: MulticastDelegate|Public|Delegate)
    void OnEncounterActorSpawned__DelegateSignature(FGameplayTag& MobIdentifier, AActor*& SpawnedActor); // 0x288a61c (Index: 0x3, Flags: MulticastDelegate|Public|Delegate)
    void OnEncounterEnded__DelegateSignature(FGameplayTag& MobIdentifier); // 0x288a61c (Index: 0x4, Flags: MulticastDelegate|Public|Delegate)
    void OnEncounterPaused__DelegateSignature(FGameplayTag& MobIdentifier); // 0x288a61c (Index: 0x5, Flags: MulticastDelegate|Public|Delegate)
    void OnEncounterResumed__DelegateSignature(FGameplayTag& MobIdentifier); // 0x288a61c (Index: 0x6, Flags: MulticastDelegate|Public|Delegate)
    void OnEncounterStarted__DelegateSignature(FGameplayTag& MobIdentifier); // 0x288a61c (Index: 0x7, Flags: MulticastDelegate|Public|Delegate)
    void PauseMobEncounter(const FGameplayTag MobIdentifier); // 0x10038178 (Index: 0xb, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)
    void ResumeMobEncounter(const FGameplayTag MobIdentifier); // 0x1003825c (Index: 0xc, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)
    bool StartMobEncounter(const FGameplayTag MobIdentifier); // 0x10038340 (Index: 0xd, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)

private:
    void OnMobActorDied(AActor*& DamagedActor, float& Damage, AController*& InstigatedBy, AActor*& DamageCauser, FVector& HitLocation, UPrimitiveComponent*& HitComponent, FName& BoneName, FVector& Momentum); // 0x10037828 (Index: 0x8, Flags: Final|Native|Private|HasDefaults)
    void OnMobActorSpawn(AActor*& SpawnedActor, UFortAthenaLivingWorldEventData*& const EventData); // 0x10037d64 (Index: 0x9, Flags: Final|Native|Private)
    void OnMobPawnEndPlay(AActor*& Mob, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x10037f6c (Index: 0xa, Flags: Final|Native|Private)
};

static_assert(sizeof(UEncounterMobManagerComponent) == 0x230, "Size mismatch for UEncounterMobManagerComponent");
static_assert(offsetof(UEncounterMobManagerComponent, SpawnedMobs) == 0xb8, "Offset mismatch for UEncounterMobManagerComponent::SpawnedMobs");
static_assert(offsetof(UEncounterMobManagerComponent, MobEncounterSpawnData) == 0xc8, "Offset mismatch for UEncounterMobManagerComponent::MobEncounterSpawnData");
static_assert(offsetof(UEncounterMobManagerComponent, DefaultMobSpawnInfo) == 0xd8, "Offset mismatch for UEncounterMobManagerComponent::DefaultMobSpawnInfo");
static_assert(offsetof(UEncounterMobManagerComponent, LWMDensityWeight) == 0x178, "Offset mismatch for UEncounterMobManagerComponent::LWMDensityWeight");
static_assert(offsetof(UEncounterMobManagerComponent, LWMDensityRange) == 0x1a0, "Offset mismatch for UEncounterMobManagerComponent::LWMDensityRange");
static_assert(offsetof(UEncounterMobManagerComponent, OnEncounterStarted) == 0x1c8, "Offset mismatch for UEncounterMobManagerComponent::OnEncounterStarted");
static_assert(offsetof(UEncounterMobManagerComponent, OnEncounterPaused) == 0x1d8, "Offset mismatch for UEncounterMobManagerComponent::OnEncounterPaused");
static_assert(offsetof(UEncounterMobManagerComponent, OnEncounterResumed) == 0x1e8, "Offset mismatch for UEncounterMobManagerComponent::OnEncounterResumed");
static_assert(offsetof(UEncounterMobManagerComponent, OnEncounterActorSpawned) == 0x1f8, "Offset mismatch for UEncounterMobManagerComponent::OnEncounterActorSpawned");
static_assert(offsetof(UEncounterMobManagerComponent, OnEncounterActorDead) == 0x208, "Offset mismatch for UEncounterMobManagerComponent::OnEncounterActorDead");
static_assert(offsetof(UEncounterMobManagerComponent, OnEncounterEnded) == 0x218, "Offset mismatch for UEncounterMobManagerComponent::OnEncounterEnded");
static_assert(offsetof(UEncounterMobManagerComponent, EncounterPrefab) == 0x228, "Offset mismatch for UEncounterMobManagerComponent::EncounterPrefab");

// Size: 0x40 (Inherited: 0x60, Single: 0xffffffe0)
class UEncounterWorldConditionSchema : public UWorldConditionSchema
{
public:
};

static_assert(sizeof(UEncounterWorldConditionSchema) == 0x40, "Size mismatch for UEncounterWorldConditionSchema");

// Size: 0x168 (Inherited: 0x28, Single: 0x140)
class ULWMEncounterInstance : public UObject
{
public:
    TWeakObjectPtr<UFortAthenaLivingWorldEncounterInstance*> LWMInstance; // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<AFortPawn*>> SpawnedMobPawns; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FLWMEncounterInstanceSavedTargetInfo> SavedTargetActors; // 0x40 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_50[0x58]; // 0x50 (Size: 0x58, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> EncounterAnchorPoint; // 0xa8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> UserActor; // 0xb0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TScriptInterface<Class>> ActivePointProviderInterfaces; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_c8[0xa0]; // 0xc8 (Size: 0xa0, Type: PaddingProperty)

public:
    void OnMobActorDied(AActor*& DamagedActor, float& Damage, AController*& InstigatedBy, AActor*& DamageCauser, FVector& HitLocation, UPrimitiveComponent*& HitComponent, FName& BoneName, FVector& Momentum); // 0x10039f08 (Index: 0x0, Flags: Final|Native|Public|HasDefaults)
    void OnMobActorSpawn(AActor*& SpawnedActor, UFortAthenaLivingWorldEventData*& const EventData); // 0x1003a444 (Index: 0x1, Flags: Final|Native|Public)
    void OnMobPawnEndPlay(AActor*& Mob, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x1003a7c8 (Index: 0x2, Flags: Final|Native|Public)

protected:
    void OnPointProviderEndPlayed(AActor*& InActor, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x1003a9f8 (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(ULWMEncounterInstance) == 0x168, "Size mismatch for ULWMEncounterInstance");
static_assert(offsetof(ULWMEncounterInstance, LWMInstance) == 0x28, "Offset mismatch for ULWMEncounterInstance::LWMInstance");
static_assert(offsetof(ULWMEncounterInstance, SpawnedMobPawns) == 0x30, "Offset mismatch for ULWMEncounterInstance::SpawnedMobPawns");
static_assert(offsetof(ULWMEncounterInstance, SavedTargetActors) == 0x40, "Offset mismatch for ULWMEncounterInstance::SavedTargetActors");
static_assert(offsetof(ULWMEncounterInstance, EncounterAnchorPoint) == 0xa8, "Offset mismatch for ULWMEncounterInstance::EncounterAnchorPoint");
static_assert(offsetof(ULWMEncounterInstance, UserActor) == 0xb0, "Offset mismatch for ULWMEncounterInstance::UserActor");
static_assert(offsetof(ULWMEncounterInstance, ActivePointProviderInterfaces) == 0xb8, "Offset mismatch for ULWMEncounterInstance::ActivePointProviderInterfaces");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class USpawnActorTaskHelper : public UObject
{
public:
};

static_assert(sizeof(USpawnActorTaskHelper) == 0x38, "Size mismatch for USpawnActorTaskHelper");

// Size: 0xa0 (Inherited: 0xc0, Single: 0xffffffe0)
class UEncounterActorSpawnerData : public UFortAthenaActorSpawnerData
{
public:
    FEncounterPrefabEntry EncounterEntry; // 0x50 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(UEncounterActorSpawnerData) == 0xa0, "Size mismatch for UEncounterActorSpawnerData");
static_assert(offsetof(UEncounterActorSpawnerData, EncounterEntry) == 0x50, "Offset mismatch for UEncounterActorSpawnerData::EncounterEntry");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEncounterBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static UEncounterMobManagerComponent* GetRelevantMobManagerComponentForActor(AActor*& const Actor); // 0x1005b1a8 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UEncounterBlueprintLibrary) == 0x28, "Size mismatch for UEncounterBlueprintLibrary");

// Size: 0x100 (Inherited: 0x88, Single: 0x78)
class UEncounterFactionData : public UPrimaryDataAsset
{
public:
    FGameplayTagContainer FactionCapabilities; // 0x30 (Size: 0x20, Type: StructProperty)
    FWorldConditionQueryDefinition WorldConditionDefinition; // 0x50 (Size: 0x18, Type: StructProperty)
    UDataTable* LWMEncounterTable; // 0x68 (Size: 0x8, Type: ObjectProperty)
    FVariableSelections_Faction EnemiesSelection; // 0x70 (Size: 0x90, Type: StructProperty)
};

static_assert(sizeof(UEncounterFactionData) == 0x100, "Size mismatch for UEncounterFactionData");
static_assert(offsetof(UEncounterFactionData, FactionCapabilities) == 0x30, "Offset mismatch for UEncounterFactionData::FactionCapabilities");
static_assert(offsetof(UEncounterFactionData, WorldConditionDefinition) == 0x50, "Offset mismatch for UEncounterFactionData::WorldConditionDefinition");
static_assert(offsetof(UEncounterFactionData, LWMEncounterTable) == 0x68, "Offset mismatch for UEncounterFactionData::LWMEncounterTable");
static_assert(offsetof(UEncounterFactionData, EnemiesSelection) == 0x70, "Offset mismatch for UEncounterFactionData::EnemiesSelection");

// Size: 0x950 (Inherited: 0x11a0, Single: 0xfffff7b0)
class AEncounterGameplayVolume : public AFortQuestManagerVolume
{
public:
    UEncounterStateTreeComponent* EncounterStateTreeComponent; // 0x878 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_880[0x8]; // 0x880 (Size: 0x8, Type: PaddingProperty)
    TArray<TScriptInterface<Class>> TrackedEncounterPointProviders; // 0x888 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AEncounterMobAnchor*>> TrackedEncounterAnchors; // 0x898 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AActor*>> TrackedActors; // 0x8a8 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FString> AllVisitedPlayersMap; // 0x8b8 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_908[0x48]; // 0x908 (Size: 0x48, Type: PaddingProperty)

public:
    virtual bool IsDoneCleaningUp() const; // 0x1005c82c (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual void OnCleanup(); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(AEncounterGameplayVolume) == 0x950, "Size mismatch for AEncounterGameplayVolume");
static_assert(offsetof(AEncounterGameplayVolume, EncounterStateTreeComponent) == 0x878, "Offset mismatch for AEncounterGameplayVolume::EncounterStateTreeComponent");
static_assert(offsetof(AEncounterGameplayVolume, TrackedEncounterPointProviders) == 0x888, "Offset mismatch for AEncounterGameplayVolume::TrackedEncounterPointProviders");
static_assert(offsetof(AEncounterGameplayVolume, TrackedEncounterAnchors) == 0x898, "Offset mismatch for AEncounterGameplayVolume::TrackedEncounterAnchors");
static_assert(offsetof(AEncounterGameplayVolume, TrackedActors) == 0x8a8, "Offset mismatch for AEncounterGameplayVolume::TrackedActors");
static_assert(offsetof(AEncounterGameplayVolume, AllVisitedPlayersMap) == 0x8b8, "Offset mismatch for AEncounterGameplayVolume::AllVisitedPlayersMap");

// Size: 0x300 (Inherited: 0x1e0, Single: 0x120)
class UEncounterItemDefinition : public UFortItemDefinition
{
public:
    bool bAutoHandleSuccessFailure; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)
    TSoftObjectPtr<UWorld*> Level; // 0xb0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStateTree*> StateTreeOverride; // 0xd0 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayCueTag ProximityGameplayCueTag; // 0xf0 (Size: 0x4, Type: StructProperty)
    FGameplayCueTag ActorCleanupGameplayCueTag; // 0xf4 (Size: 0x4, Type: StructProperty)
    bool bUseOverlapTestForActorCollection; // 0xf8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f9[0x7]; // 0xf9 (Size: 0x7, Type: PaddingProperty)
    TArray<FEncounterLootEntry> SuccessRewards; // 0x100 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> ReactionsToGrantOnSuccess; // 0x110 (Size: 0x10, Type: ArrayProperty)
    FEncounterRewardBehavior SuccessRewardBehavior; // 0x120 (Size: 0x80, Type: StructProperty)
    FGameplayCueTag ActorSuccessGameplayCueTag; // 0x1a0 (Size: 0x4, Type: StructProperty)
    FGameplayCueTag PlayerSuccessGameplayCueTag; // 0x1a4 (Size: 0x4, Type: StructProperty)
    TArray<FEncounterLootEntry> FailureRewards; // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> ReactionsToGrantOnFailure; // 0x1b8 (Size: 0x10, Type: ArrayProperty)
    FEncounterRewardBehavior FailureRewardBehavior; // 0x1c8 (Size: 0x80, Type: StructProperty)
    FGameplayCueTag ActorFailureGameplayCueTag; // 0x248 (Size: 0x4, Type: StructProperty)
    FGameplayCueTag PlayerFailureGameplayCueTag; // 0x24c (Size: 0x4, Type: StructProperty)
    FScalableFloat LWMDensityWeight; // 0x250 (Size: 0x28, Type: StructProperty)
    FScalableFloat LWMDensityRange; // 0x278 (Size: 0x28, Type: StructProperty)
    bool bUseGlobalLWMBudget; // 0x2a0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a1[0x7]; // 0x2a1 (Size: 0x7, Type: PaddingProperty)
    TArray<FInstancedStruct> Vars; // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> VariableSelections; // 0x2b8 (Size: 0x10, Type: ArrayProperty)
    TArray<FVariableCollectionSelection> VariableCollectionSelections; // 0x2c8 (Size: 0x10, Type: ArrayProperty)
    FWorldConditionQueryDefinition CanSpawnWorldConditionDefinition; // 0x2d8 (Size: 0x18, Type: StructProperty)
    TArray<FFortAthenaLivingWorldPrefabActorSpawnerData> ActorSpawnerDatas; // 0x2f0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UEncounterItemDefinition) == 0x300, "Size mismatch for UEncounterItemDefinition");
static_assert(offsetof(UEncounterItemDefinition, bAutoHandleSuccessFailure) == 0xa8, "Offset mismatch for UEncounterItemDefinition::bAutoHandleSuccessFailure");
static_assert(offsetof(UEncounterItemDefinition, Level) == 0xb0, "Offset mismatch for UEncounterItemDefinition::Level");
static_assert(offsetof(UEncounterItemDefinition, StateTreeOverride) == 0xd0, "Offset mismatch for UEncounterItemDefinition::StateTreeOverride");
static_assert(offsetof(UEncounterItemDefinition, ProximityGameplayCueTag) == 0xf0, "Offset mismatch for UEncounterItemDefinition::ProximityGameplayCueTag");
static_assert(offsetof(UEncounterItemDefinition, ActorCleanupGameplayCueTag) == 0xf4, "Offset mismatch for UEncounterItemDefinition::ActorCleanupGameplayCueTag");
static_assert(offsetof(UEncounterItemDefinition, bUseOverlapTestForActorCollection) == 0xf8, "Offset mismatch for UEncounterItemDefinition::bUseOverlapTestForActorCollection");
static_assert(offsetof(UEncounterItemDefinition, SuccessRewards) == 0x100, "Offset mismatch for UEncounterItemDefinition::SuccessRewards");
static_assert(offsetof(UEncounterItemDefinition, ReactionsToGrantOnSuccess) == 0x110, "Offset mismatch for UEncounterItemDefinition::ReactionsToGrantOnSuccess");
static_assert(offsetof(UEncounterItemDefinition, SuccessRewardBehavior) == 0x120, "Offset mismatch for UEncounterItemDefinition::SuccessRewardBehavior");
static_assert(offsetof(UEncounterItemDefinition, ActorSuccessGameplayCueTag) == 0x1a0, "Offset mismatch for UEncounterItemDefinition::ActorSuccessGameplayCueTag");
static_assert(offsetof(UEncounterItemDefinition, PlayerSuccessGameplayCueTag) == 0x1a4, "Offset mismatch for UEncounterItemDefinition::PlayerSuccessGameplayCueTag");
static_assert(offsetof(UEncounterItemDefinition, FailureRewards) == 0x1a8, "Offset mismatch for UEncounterItemDefinition::FailureRewards");
static_assert(offsetof(UEncounterItemDefinition, ReactionsToGrantOnFailure) == 0x1b8, "Offset mismatch for UEncounterItemDefinition::ReactionsToGrantOnFailure");
static_assert(offsetof(UEncounterItemDefinition, FailureRewardBehavior) == 0x1c8, "Offset mismatch for UEncounterItemDefinition::FailureRewardBehavior");
static_assert(offsetof(UEncounterItemDefinition, ActorFailureGameplayCueTag) == 0x248, "Offset mismatch for UEncounterItemDefinition::ActorFailureGameplayCueTag");
static_assert(offsetof(UEncounterItemDefinition, PlayerFailureGameplayCueTag) == 0x24c, "Offset mismatch for UEncounterItemDefinition::PlayerFailureGameplayCueTag");
static_assert(offsetof(UEncounterItemDefinition, LWMDensityWeight) == 0x250, "Offset mismatch for UEncounterItemDefinition::LWMDensityWeight");
static_assert(offsetof(UEncounterItemDefinition, LWMDensityRange) == 0x278, "Offset mismatch for UEncounterItemDefinition::LWMDensityRange");
static_assert(offsetof(UEncounterItemDefinition, bUseGlobalLWMBudget) == 0x2a0, "Offset mismatch for UEncounterItemDefinition::bUseGlobalLWMBudget");
static_assert(offsetof(UEncounterItemDefinition, Vars) == 0x2a8, "Offset mismatch for UEncounterItemDefinition::Vars");
static_assert(offsetof(UEncounterItemDefinition, VariableSelections) == 0x2b8, "Offset mismatch for UEncounterItemDefinition::VariableSelections");
static_assert(offsetof(UEncounterItemDefinition, VariableCollectionSelections) == 0x2c8, "Offset mismatch for UEncounterItemDefinition::VariableCollectionSelections");
static_assert(offsetof(UEncounterItemDefinition, CanSpawnWorldConditionDefinition) == 0x2d8, "Offset mismatch for UEncounterItemDefinition::CanSpawnWorldConditionDefinition");
static_assert(offsetof(UEncounterItemDefinition, ActorSpawnerDatas) == 0x2f0, "Offset mismatch for UEncounterItemDefinition::ActorSpawnerDatas");

// Size: 0x338 (Inherited: 0x198, Single: 0x1a0)
class UEncounterManagerComponent : public UGameFrameworkComponent
{
public:
    TWeakObjectPtr<AEncounterGameplayVolume*> EncounterVolume; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    UEncounterItemDefinition* EncounterDefinition; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AActor*> CenterActorOverride; // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    FDataTableRowHandle PostEncounterLWMEvent; // 0xd0 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle PostEncounterLWMCategory; // 0xe0 (Size: 0x10, Type: StructProperty)
    FGameplayTagQuery PostEncounterTagQuery; // 0xf0 (Size: 0x48, Type: StructProperty)
    TSet<AFortPlayerController*> ExplicitContributors; // 0x138 (Size: 0x50, Type: SetProperty)
    TArray<FActorIdentifierEntry> ActorIdentifiers; // 0x188 (Size: 0x10, Type: ArrayProperty)
    bool bHasHandledSuccessFailure; // 0x198 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_199[0x7]; // 0x199 (Size: 0x7, Type: PaddingProperty)
    TArray<FLWMEncounterInfo> EncounterInfos; // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayEffectIdentifierInfo> GameplayEffectInfos; // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<ALivingWorldEncounterPrefab*> EncounterPrefab; // 0x1c0 (Size: 0x8, Type: WeakObjectProperty)
    UEncounterFactionData* SelectedFaction; // 0x1c8 (Size: 0x8, Type: ObjectProperty)
    UDataTable* LWMEncounterTable; // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1d8[0x100]; // 0x1d8 (Size: 0x100, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> LastThreat; // 0x2d8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> ReservoirActor; // 0x2e0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<FTrackedActorInfo> TrackedActorInfos; // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_2f8[0x30]; // 0x2f8 (Size: 0x30, Type: PaddingProperty)
    TArray<UObject*> LoadedObjects; // 0x328 (Size: 0x10, Type: ArrayProperty)

public:
    void AddExplicitContributor(AFortPlayerController*& Contributor); // 0x1005ada0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    TArray<UOverlapComponent*> GetOverlapComponents() const; // 0x1005b07c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetPersistentValue(const FGameplayTag Identifier) const; // 0x1005b0e8 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TSoftClassPtr GetVariable_ActorClass(const FGameplayTag VarName) const; // 0x1005b2fc (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription> GetVariable_ActorDescription(const FGameplayTag VarName) const; // 0x1005b648 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool GetVariable_Bool(const FGameplayTag VarName) const; // 0x1005b744 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UEncounterFactionData* GetVariable_Faction(const FGameplayTag VarName) const; // 0x1005b838 (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    float GetVariable_Float(const FGameplayTag VarName) const; // 0x1005b92c (Index: 0x7, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetVariable_GameplayTag(const FGameplayTag VarName) const; // 0x1005ba20 (Index: 0x8, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FGameplayTagContainer GetVariable_GameplayTagContainer(const FGameplayTag VarName) const; // 0x1005bb0c (Index: 0x9, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    int32_t GetVariable_Int(const FGameplayTag VarName) const; // 0x1005bc18 (Index: 0xa, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UFortWorldItemDefinition* GetVariable_ItemDefinition(const FGameplayTag VarName) const; // 0x1005bd0c (Index: 0xb, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UFortAthenaLivingWorldEncounter* GetVariable_LWMEncounter(const FGameplayTag VarName) const; // 0x1005be00 (Index: 0xc, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UFortQuestItemDefinition* GetVariable_QuestDefinition(const FGameplayTag VarName) const; // 0x1005bef4 (Index: 0xd, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FName GetVariable_String(const FGameplayTag VarName) const; // 0x1005bfe8 (Index: 0xe, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FGameplayTagQuery GetVariable_TagQuery(const FGameplayTag VarName) const; // 0x1005c0d4 (Index: 0xf, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void HandleEncounterFailure(int32_t& RewardIndex); // 0x1005c1e4 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    void HandleEncounterSuccess(int32_t& RewardIndex); // 0x1005c508 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveExplicitContributor(AFortPlayerController*& Contributor); // 0x1005c980 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)
    void SetPersistentValue(const FGameplayTag Identifier, int32_t& Value, EPersistentValueScope& PersistenceScope); // 0x1005cc58 (Index: 0x14, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)

private:
    void OnStateTreeStatusChanged(EStateTreeRunStatus& Status); // 0x1005c854 (Index: 0x12, Flags: Final|Native|Private)
    virtual void TriggerClientReactions(TArray<FInstancedStruct>& const Reactions, AActor*& TargetActor) const; // 0x1005ce18 (Index: 0x15, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private|Const)
};

static_assert(sizeof(UEncounterManagerComponent) == 0x338, "Size mismatch for UEncounterManagerComponent");
static_assert(offsetof(UEncounterManagerComponent, EncounterVolume) == 0xb8, "Offset mismatch for UEncounterManagerComponent::EncounterVolume");
static_assert(offsetof(UEncounterManagerComponent, EncounterDefinition) == 0xc0, "Offset mismatch for UEncounterManagerComponent::EncounterDefinition");
static_assert(offsetof(UEncounterManagerComponent, CenterActorOverride) == 0xc8, "Offset mismatch for UEncounterManagerComponent::CenterActorOverride");
static_assert(offsetof(UEncounterManagerComponent, PostEncounterLWMEvent) == 0xd0, "Offset mismatch for UEncounterManagerComponent::PostEncounterLWMEvent");
static_assert(offsetof(UEncounterManagerComponent, PostEncounterLWMCategory) == 0xe0, "Offset mismatch for UEncounterManagerComponent::PostEncounterLWMCategory");
static_assert(offsetof(UEncounterManagerComponent, PostEncounterTagQuery) == 0xf0, "Offset mismatch for UEncounterManagerComponent::PostEncounterTagQuery");
static_assert(offsetof(UEncounterManagerComponent, ExplicitContributors) == 0x138, "Offset mismatch for UEncounterManagerComponent::ExplicitContributors");
static_assert(offsetof(UEncounterManagerComponent, ActorIdentifiers) == 0x188, "Offset mismatch for UEncounterManagerComponent::ActorIdentifiers");
static_assert(offsetof(UEncounterManagerComponent, bHasHandledSuccessFailure) == 0x198, "Offset mismatch for UEncounterManagerComponent::bHasHandledSuccessFailure");
static_assert(offsetof(UEncounterManagerComponent, EncounterInfos) == 0x1a0, "Offset mismatch for UEncounterManagerComponent::EncounterInfos");
static_assert(offsetof(UEncounterManagerComponent, GameplayEffectInfos) == 0x1b0, "Offset mismatch for UEncounterManagerComponent::GameplayEffectInfos");
static_assert(offsetof(UEncounterManagerComponent, EncounterPrefab) == 0x1c0, "Offset mismatch for UEncounterManagerComponent::EncounterPrefab");
static_assert(offsetof(UEncounterManagerComponent, SelectedFaction) == 0x1c8, "Offset mismatch for UEncounterManagerComponent::SelectedFaction");
static_assert(offsetof(UEncounterManagerComponent, LWMEncounterTable) == 0x1d0, "Offset mismatch for UEncounterManagerComponent::LWMEncounterTable");
static_assert(offsetof(UEncounterManagerComponent, LastThreat) == 0x2d8, "Offset mismatch for UEncounterManagerComponent::LastThreat");
static_assert(offsetof(UEncounterManagerComponent, ReservoirActor) == 0x2e0, "Offset mismatch for UEncounterManagerComponent::ReservoirActor");
static_assert(offsetof(UEncounterManagerComponent, TrackedActorInfos) == 0x2e8, "Offset mismatch for UEncounterManagerComponent::TrackedActorInfos");
static_assert(offsetof(UEncounterManagerComponent, LoadedObjects) == 0x328, "Offset mismatch for UEncounterManagerComponent::LoadedObjects");

// Size: 0x3b8 (Inherited: 0x680, Single: 0xfffffd38)
class AEncounterPatrolPathPointProvider : public AFortAthenaPatrolPathPointProvider
{
public:
};

static_assert(sizeof(AEncounterPatrolPathPointProvider) == 0x3b8, "Size mismatch for AEncounterPatrolPathPointProvider");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEncounterPointProviderInterface : public UInterface
{
public:
};

static_assert(sizeof(UEncounterPointProviderInterface) == 0x28, "Size mismatch for UEncounterPointProviderInterface");

// Size: 0x188 (Inherited: 0x370, Single: 0xfffffe18)
class UEncounterStateTreeComponent : public UStateTreeComponent
{
public:
};

static_assert(sizeof(UEncounterStateTreeComponent) == 0x188, "Size mismatch for UEncounterStateTreeComponent");

// Size: 0x3b0 (Inherited: 0x678, Single: 0xfffffd38)
class AEncounterStaticPointProvider : public AFortAthenaLivingWorldStaticPointProvider
{
public:
};

static_assert(sizeof(AEncounterStaticPointProvider) == 0x3b0, "Size mismatch for AEncounterStaticPointProvider");

// Size: 0x600 (Inherited: 0xe88, Single: 0xfffff778)
class AEncounterVolumePointProvider : public AFortAthenaLivingWorldVolume
{
public:
};

static_assert(sizeof(AEncounterVolumePointProvider) == 0x600, "Size mismatch for AEncounterVolumePointProvider");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UFortCheatManager_Encounters : public UChildCheatManager
{
public:

public:
    void EncountersDump(); // 0x554e3c4 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Public)
};

static_assert(sizeof(UFortCheatManager_Encounters) == 0x28, "Size mismatch for UFortCheatManager_Encounters");

// Size: 0xa88 (Inherited: 0x23f0, Single: 0xffffe698)
class ALivingWorldEncounterPrefab : public AFortAthenaLivingWorldPrefab
{
public:
    uint8_t Pad_a00[0x58]; // 0xa00 (Size: 0x58, Type: PaddingProperty)
    TArray<FEncounterPrefabInfo> EncounterEntries; // 0xa58 (Size: 0x10, Type: ArrayProperty)
    UEncounterItemDefinition* EncounterDefinition; // 0xa68 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AActor*> ReservoirActorOverride; // 0xa70 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UEncounterManagerComponent*> EncounterManager; // 0xa78 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_a80[0x8]; // 0xa80 (Size: 0x8, Type: PaddingProperty)

private:
    void OnRep_EncounterDefinition(); // 0xd31f56c (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(ALivingWorldEncounterPrefab) == 0xa88, "Size mismatch for ALivingWorldEncounterPrefab");
static_assert(offsetof(ALivingWorldEncounterPrefab, EncounterEntries) == 0xa58, "Offset mismatch for ALivingWorldEncounterPrefab::EncounterEntries");
static_assert(offsetof(ALivingWorldEncounterPrefab, EncounterDefinition) == 0xa68, "Offset mismatch for ALivingWorldEncounterPrefab::EncounterDefinition");
static_assert(offsetof(ALivingWorldEncounterPrefab, ReservoirActorOverride) == 0xa70, "Offset mismatch for ALivingWorldEncounterPrefab::ReservoirActorOverride");
static_assert(offsetof(ALivingWorldEncounterPrefab, EncounterManager) == 0xa78, "Offset mismatch for ALivingWorldEncounterPrefab::EncounterManager");

// Size: 0x98 (Inherited: 0x190, Single: 0xffffff08)
class UFortVerbProcessor_EncounterCompleted : public UFortObjectiveProcessor
{
public:
};

static_assert(sizeof(UFortVerbProcessor_EncounterCompleted) == 0x98, "Size mismatch for UFortVerbProcessor_EncounterCompleted");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FEncounterMobSpawnInfo
{
    FScalableFloat LeashRadiusInner; // 0x0 (Size: 0x28, Type: StructProperty)
    FScalableFloat LeashRadiusOuter; // 0x28 (Size: 0x28, Type: StructProperty)
    TWeakObjectPtr<AEncounterMobAnchor*> EncounterAnchorPoint; // 0x50 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t MobSpawnType[0x4]; // 0x58 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer PointProviderFilterTags; // 0x60 (Size: 0x20, Type: StructProperty)
    TArray<TWeakObjectPtr<AFortAthenaLivingWorldStaticPointProvider*>> StaticPointProviders; // 0x80 (Size: 0x10, Type: ArrayProperty)
    UEnvQuery* PointProviderEQS; // 0x90 (Size: 0x8, Type: ObjectProperty)
    UClass* PointProviderVolumeClass; // 0x98 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FEncounterMobSpawnInfo) == 0xa0, "Size mismatch for FEncounterMobSpawnInfo");
static_assert(offsetof(FEncounterMobSpawnInfo, LeashRadiusInner) == 0x0, "Offset mismatch for FEncounterMobSpawnInfo::LeashRadiusInner");
static_assert(offsetof(FEncounterMobSpawnInfo, LeashRadiusOuter) == 0x28, "Offset mismatch for FEncounterMobSpawnInfo::LeashRadiusOuter");
static_assert(offsetof(FEncounterMobSpawnInfo, EncounterAnchorPoint) == 0x50, "Offset mismatch for FEncounterMobSpawnInfo::EncounterAnchorPoint");
static_assert(offsetof(FEncounterMobSpawnInfo, MobSpawnType) == 0x58, "Offset mismatch for FEncounterMobSpawnInfo::MobSpawnType");
static_assert(offsetof(FEncounterMobSpawnInfo, PointProviderFilterTags) == 0x60, "Offset mismatch for FEncounterMobSpawnInfo::PointProviderFilterTags");
static_assert(offsetof(FEncounterMobSpawnInfo, StaticPointProviders) == 0x80, "Offset mismatch for FEncounterMobSpawnInfo::StaticPointProviders");
static_assert(offsetof(FEncounterMobSpawnInfo, PointProviderEQS) == 0x90, "Offset mismatch for FEncounterMobSpawnInfo::PointProviderEQS");
static_assert(offsetof(FEncounterMobSpawnInfo, PointProviderVolumeClass) == 0x98, "Offset mismatch for FEncounterMobSpawnInfo::PointProviderVolumeClass");

// Size: 0xe0 (Inherited: 0x0, Single: 0xe0)
struct FEncounterMobSpawnData
{
    FString DevNotes; // 0x0 (Size: 0x10, Type: StrProperty)
    FGameplayTag MobIdentifier; // 0x10 (Size: 0x4, Type: StructProperty)
    bool bActiveOnStart; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    TSoftObjectPtr<UFortAthenaLivingWorldEncounter*> MobEncounterData; // 0x18 (Size: 0x20, Type: SoftObjectProperty)
    bool bOverrideDefaultSpawnInfo; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
    FEncounterMobSpawnInfo MobSpawnInfo; // 0x40 (Size: 0xa0, Type: StructProperty)
};

static_assert(sizeof(FEncounterMobSpawnData) == 0xe0, "Size mismatch for FEncounterMobSpawnData");
static_assert(offsetof(FEncounterMobSpawnData, DevNotes) == 0x0, "Offset mismatch for FEncounterMobSpawnData::DevNotes");
static_assert(offsetof(FEncounterMobSpawnData, MobIdentifier) == 0x10, "Offset mismatch for FEncounterMobSpawnData::MobIdentifier");
static_assert(offsetof(FEncounterMobSpawnData, bActiveOnStart) == 0x14, "Offset mismatch for FEncounterMobSpawnData::bActiveOnStart");
static_assert(offsetof(FEncounterMobSpawnData, MobEncounterData) == 0x18, "Offset mismatch for FEncounterMobSpawnData::MobEncounterData");
static_assert(offsetof(FEncounterMobSpawnData, bOverrideDefaultSpawnInfo) == 0x38, "Offset mismatch for FEncounterMobSpawnData::bOverrideDefaultSpawnInfo");
static_assert(offsetof(FEncounterMobSpawnData, MobSpawnInfo) == 0x40, "Offset mismatch for FEncounterMobSpawnData::MobSpawnInfo");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FEncounterMobInstance
{
    AFortAthenaLivingWorldVolume* VolumePointProvider; // 0x18 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_20[0x10]; // 0x20 (Size: 0x10, Type: PaddingProperty)
    TArray<TScriptInterface<Class>> CurrentPointProviders; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FEncounterMobInstance) == 0x58, "Size mismatch for FEncounterMobInstance");
static_assert(offsetof(FEncounterMobInstance, VolumePointProvider) == 0x18, "Offset mismatch for FEncounterMobInstance::VolumePointProvider");
static_assert(offsetof(FEncounterMobInstance, CurrentPointProviders) == 0x30, "Offset mismatch for FEncounterMobInstance::CurrentPointProviders");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FActorAddLooseTagsStateTreeTaskInstanceData
{
    TWeakObjectPtr<AActor*> InActor; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTagContainer ActorTags; // 0x8 (Size: 0x20, Type: StructProperty)
    bool bAddTags; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FActorAddLooseTagsStateTreeTaskInstanceData) == 0x38, "Size mismatch for FActorAddLooseTagsStateTreeTaskInstanceData");
static_assert(offsetof(FActorAddLooseTagsStateTreeTaskInstanceData, InActor) == 0x0, "Offset mismatch for FActorAddLooseTagsStateTreeTaskInstanceData::InActor");
static_assert(offsetof(FActorAddLooseTagsStateTreeTaskInstanceData, ActorTags) == 0x8, "Offset mismatch for FActorAddLooseTagsStateTreeTaskInstanceData::ActorTags");
static_assert(offsetof(FActorAddLooseTagsStateTreeTaskInstanceData, bAddTags) == 0x28, "Offset mismatch for FActorAddLooseTagsStateTreeTaskInstanceData::bAddTags");
static_assert(offsetof(FActorAddLooseTagsStateTreeTaskInstanceData, UserActor) == 0x30, "Offset mismatch for FActorAddLooseTagsStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FActorAddLooseTagsStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FActorAddLooseTagsStateTreeTask) == 0x20, "Size mismatch for FActorAddLooseTagsStateTreeTask");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FActorPhysicsStateTreeTaskInstanceData
{
    FGameplayTagQuery ActorQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    bool bShouldWakeup; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FActorPhysicsStateTreeTaskInstanceData) == 0x58, "Size mismatch for FActorPhysicsStateTreeTaskInstanceData");
static_assert(offsetof(FActorPhysicsStateTreeTaskInstanceData, ActorQuery) == 0x0, "Offset mismatch for FActorPhysicsStateTreeTaskInstanceData::ActorQuery");
static_assert(offsetof(FActorPhysicsStateTreeTaskInstanceData, bShouldWakeup) == 0x48, "Offset mismatch for FActorPhysicsStateTreeTaskInstanceData::bShouldWakeup");
static_assert(offsetof(FActorPhysicsStateTreeTaskInstanceData, UserActor) == 0x50, "Offset mismatch for FActorPhysicsStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FActorPhysicsStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FActorPhysicsStateTreeTask) == 0x20, "Size mismatch for FActorPhysicsStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAddEncounterPrefabTagStateTreeTaskInstanceData
{
    FGameplayTag PrefabTag; // 0x0 (Size: 0x4, Type: StructProperty)
    bool bRemoveOnExit; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAddEncounterPrefabTagStateTreeTaskInstanceData) == 0x10, "Size mismatch for FAddEncounterPrefabTagStateTreeTaskInstanceData");
static_assert(offsetof(FAddEncounterPrefabTagStateTreeTaskInstanceData, PrefabTag) == 0x0, "Offset mismatch for FAddEncounterPrefabTagStateTreeTaskInstanceData::PrefabTag");
static_assert(offsetof(FAddEncounterPrefabTagStateTreeTaskInstanceData, bRemoveOnExit) == 0x4, "Offset mismatch for FAddEncounterPrefabTagStateTreeTaskInstanceData::bRemoveOnExit");
static_assert(offsetof(FAddEncounterPrefabTagStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FAddEncounterPrefabTagStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FAddEncounterPrefabTagStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FAddEncounterPrefabTagStateTreeTask) == 0x20, "Size mismatch for FAddEncounterPrefabTagStateTreeTask");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FAddGameplayCueStateTreeTaskInstanceData
{
    FGameplayCueTag GameplayCue; // 0x0 (Size: 0x4, Type: StructProperty)
    bool bApplyToActor; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> TargetActor; // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    bool bApplyToLWMEncounters; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagQuery EncounterQuery; // 0x18 (Size: 0x48, Type: StructProperty)
    bool bApplyToParticipatingPlayers; // 0x60 (Size: 0x1, Type: BoolProperty)
    bool bIsLooping; // 0x61 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_62[0x6]; // 0x62 (Size: 0x6, Type: PaddingProperty)
    AActor* UserActor; // 0x68 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAddGameplayCueStateTreeTaskInstanceData) == 0x70, "Size mismatch for FAddGameplayCueStateTreeTaskInstanceData");
static_assert(offsetof(FAddGameplayCueStateTreeTaskInstanceData, GameplayCue) == 0x0, "Offset mismatch for FAddGameplayCueStateTreeTaskInstanceData::GameplayCue");
static_assert(offsetof(FAddGameplayCueStateTreeTaskInstanceData, bApplyToActor) == 0x4, "Offset mismatch for FAddGameplayCueStateTreeTaskInstanceData::bApplyToActor");
static_assert(offsetof(FAddGameplayCueStateTreeTaskInstanceData, TargetActor) == 0x8, "Offset mismatch for FAddGameplayCueStateTreeTaskInstanceData::TargetActor");
static_assert(offsetof(FAddGameplayCueStateTreeTaskInstanceData, bApplyToLWMEncounters) == 0x10, "Offset mismatch for FAddGameplayCueStateTreeTaskInstanceData::bApplyToLWMEncounters");
static_assert(offsetof(FAddGameplayCueStateTreeTaskInstanceData, EncounterQuery) == 0x18, "Offset mismatch for FAddGameplayCueStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FAddGameplayCueStateTreeTaskInstanceData, bApplyToParticipatingPlayers) == 0x60, "Offset mismatch for FAddGameplayCueStateTreeTaskInstanceData::bApplyToParticipatingPlayers");
static_assert(offsetof(FAddGameplayCueStateTreeTaskInstanceData, bIsLooping) == 0x61, "Offset mismatch for FAddGameplayCueStateTreeTaskInstanceData::bIsLooping");
static_assert(offsetof(FAddGameplayCueStateTreeTaskInstanceData, UserActor) == 0x68, "Offset mismatch for FAddGameplayCueStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FAddGameplayCueStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FAddGameplayCueStateTreeTask) == 0x20, "Size mismatch for FAddGameplayCueStateTreeTask");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FDestroyActorsStateTreeTaskInstanceData
{
    FGameplayTagQuery ActorQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor; // 0x48 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDestroyActorsStateTreeTaskInstanceData) == 0x50, "Size mismatch for FDestroyActorsStateTreeTaskInstanceData");
static_assert(offsetof(FDestroyActorsStateTreeTaskInstanceData, ActorQuery) == 0x0, "Offset mismatch for FDestroyActorsStateTreeTaskInstanceData::ActorQuery");
static_assert(offsetof(FDestroyActorsStateTreeTaskInstanceData, UserActor) == 0x48, "Offset mismatch for FDestroyActorsStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FDestroyActorsStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FDestroyActorsStateTreeTask) == 0x20, "Size mismatch for FDestroyActorsStateTreeTask");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FEnableEncounterPointProvidersStateTreeTaskInstanceData
{
    FGameplayTagQuery ProviderTagQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    bool bEnableProvider; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEnableEncounterPointProvidersStateTreeTaskInstanceData) == 0x58, "Size mismatch for FEnableEncounterPointProvidersStateTreeTaskInstanceData");
static_assert(offsetof(FEnableEncounterPointProvidersStateTreeTaskInstanceData, ProviderTagQuery) == 0x0, "Offset mismatch for FEnableEncounterPointProvidersStateTreeTaskInstanceData::ProviderTagQuery");
static_assert(offsetof(FEnableEncounterPointProvidersStateTreeTaskInstanceData, bEnableProvider) == 0x48, "Offset mismatch for FEnableEncounterPointProvidersStateTreeTaskInstanceData::bEnableProvider");
static_assert(offsetof(FEnableEncounterPointProvidersStateTreeTaskInstanceData, UserActor) == 0x50, "Offset mismatch for FEnableEncounterPointProvidersStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEnableEncounterPointProvidersStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEnableEncounterPointProvidersStateTreeTask) == 0x20, "Size mismatch for FEnableEncounterPointProvidersStateTreeTask");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FEnableSmartObjectsStateTreeTaskInstanceData
{
    bool bUseTagQuery; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagQuery ActorQuery; // 0x8 (Size: 0x48, Type: StructProperty)
    AActor* TargetActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
    bool bEnable; // 0x58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0x60 (Size: 0x8, Type: ObjectProperty)
    TArray<AActor*> AIActors; // 0x68 (Size: 0x10, Type: ArrayProperty)
    FFortAICommandSOUsageDataBase AICommandSOUsageData; // 0x78 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FEnableSmartObjectsStateTreeTaskInstanceData) == 0x80, "Size mismatch for FEnableSmartObjectsStateTreeTaskInstanceData");
static_assert(offsetof(FEnableSmartObjectsStateTreeTaskInstanceData, bUseTagQuery) == 0x0, "Offset mismatch for FEnableSmartObjectsStateTreeTaskInstanceData::bUseTagQuery");
static_assert(offsetof(FEnableSmartObjectsStateTreeTaskInstanceData, ActorQuery) == 0x8, "Offset mismatch for FEnableSmartObjectsStateTreeTaskInstanceData::ActorQuery");
static_assert(offsetof(FEnableSmartObjectsStateTreeTaskInstanceData, TargetActor) == 0x50, "Offset mismatch for FEnableSmartObjectsStateTreeTaskInstanceData::TargetActor");
static_assert(offsetof(FEnableSmartObjectsStateTreeTaskInstanceData, bEnable) == 0x58, "Offset mismatch for FEnableSmartObjectsStateTreeTaskInstanceData::bEnable");
static_assert(offsetof(FEnableSmartObjectsStateTreeTaskInstanceData, UserActor) == 0x60, "Offset mismatch for FEnableSmartObjectsStateTreeTaskInstanceData::UserActor");
static_assert(offsetof(FEnableSmartObjectsStateTreeTaskInstanceData, AIActors) == 0x68, "Offset mismatch for FEnableSmartObjectsStateTreeTaskInstanceData::AIActors");
static_assert(offsetof(FEnableSmartObjectsStateTreeTaskInstanceData, AICommandSOUsageData) == 0x78, "Offset mismatch for FEnableSmartObjectsStateTreeTaskInstanceData::AICommandSOUsageData");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEnableSmartObjectsStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEnableSmartObjectsStateTreeTask) == 0x20, "Size mismatch for FEnableSmartObjectsStateTreeTask");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FEncounterVariableDebugInfo
{
    FGameplayTag VariableTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FDataRegistryOrTableRow VariableValue; // 0x8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FEncounterVariableDebugInfo) == 0x28, "Size mismatch for FEncounterVariableDebugInfo");
static_assert(offsetof(FEncounterVariableDebugInfo, VariableTag) == 0x0, "Offset mismatch for FEncounterVariableDebugInfo::VariableTag");
static_assert(offsetof(FEncounterVariableDebugInfo, VariableValue) == 0x8, "Offset mismatch for FEncounterVariableDebugInfo::VariableValue");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEncounterDebugVolumeInfo
{
    FVector VolumeOrigin; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector VolumeExtents; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FEncounterDebugVolumeInfo) == 0x30, "Size mismatch for FEncounterDebugVolumeInfo");
static_assert(offsetof(FEncounterDebugVolumeInfo, VolumeOrigin) == 0x0, "Offset mismatch for FEncounterDebugVolumeInfo::VolumeOrigin");
static_assert(offsetof(FEncounterDebugVolumeInfo, VolumeExtents) == 0x18, "Offset mismatch for FEncounterDebugVolumeInfo::VolumeExtents");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FEncounterDebugInfo
{
    FGuid EncounterGuid; // 0x0 (Size: 0x10, Type: StructProperty)
    UEncounterItemDefinition* EncounterDefinition; // 0x10 (Size: 0x8, Type: ObjectProperty)
    UDataTable* EncounterTable; // 0x18 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery EncounterVariantQuery; // 0x20 (Size: 0x48, Type: StructProperty)
    TArray<FEncounterVariableDebugInfo> DynamicVariables; // 0x68 (Size: 0x10, Type: ArrayProperty)
    FVector EncounterOrigin; // 0x78 (Size: 0x18, Type: StructProperty)
    TArray<FEncounterDebugVolumeInfo> VolumeEntries; // 0x90 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FEncounterDebugInfo) == 0xa0, "Size mismatch for FEncounterDebugInfo");
static_assert(offsetof(FEncounterDebugInfo, EncounterGuid) == 0x0, "Offset mismatch for FEncounterDebugInfo::EncounterGuid");
static_assert(offsetof(FEncounterDebugInfo, EncounterDefinition) == 0x10, "Offset mismatch for FEncounterDebugInfo::EncounterDefinition");
static_assert(offsetof(FEncounterDebugInfo, EncounterTable) == 0x18, "Offset mismatch for FEncounterDebugInfo::EncounterTable");
static_assert(offsetof(FEncounterDebugInfo, EncounterVariantQuery) == 0x20, "Offset mismatch for FEncounterDebugInfo::EncounterVariantQuery");
static_assert(offsetof(FEncounterDebugInfo, DynamicVariables) == 0x68, "Offset mismatch for FEncounterDebugInfo::DynamicVariables");
static_assert(offsetof(FEncounterDebugInfo, EncounterOrigin) == 0x78, "Offset mismatch for FEncounterDebugInfo::EncounterOrigin");
static_assert(offsetof(FEncounterDebugInfo, VolumeEntries) == 0x90, "Offset mismatch for FEncounterDebugInfo::VolumeEntries");

// Size: 0x38 (Inherited: 0x8, Single: 0x30)
struct FEncounterFactionRow : FTableRowBase
{
    UEncounterFactionData* FactionData; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat Weight; // 0x10 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FEncounterFactionRow) == 0x38, "Size mismatch for FEncounterFactionRow");
static_assert(offsetof(FEncounterFactionRow, FactionData) == 0x8, "Offset mismatch for FEncounterFactionRow::FactionData");
static_assert(offsetof(FEncounterFactionRow, Weight) == 0x10, "Offset mismatch for FEncounterFactionRow::Weight");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FEncounterFreeLWMReservoirStateTreeTaskInstanceData
{
    AActor* UserActor; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterFreeLWMReservoirStateTreeTaskInstanceData) == 0x8, "Size mismatch for FEncounterFreeLWMReservoirStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterFreeLWMReservoirStateTreeTaskInstanceData, UserActor) == 0x0, "Offset mismatch for FEncounterFreeLWMReservoirStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterFreeLWMReservoirStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterFreeLWMReservoirStateTreeTask) == 0x20, "Size mismatch for FEncounterFreeLWMReservoirStateTreeTask");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FEncounterGetEnemyFactionStateTreeTaskInstanceData
{
    bool bSpecifyFaction; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UEncounterFactionData* Faction; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery EnemyTagQuery; // 0x10 (Size: 0x48, Type: StructProperty)
    AActor* UserActor; // 0x58 (Size: 0x8, Type: ObjectProperty)
    UEncounterFactionData* EnemyFaction; // 0x60 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetEnemyFactionStateTreeTaskInstanceData) == 0x68, "Size mismatch for FEncounterGetEnemyFactionStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetEnemyFactionStateTreeTaskInstanceData, bSpecifyFaction) == 0x0, "Offset mismatch for FEncounterGetEnemyFactionStateTreeTaskInstanceData::bSpecifyFaction");
static_assert(offsetof(FEncounterGetEnemyFactionStateTreeTaskInstanceData, Faction) == 0x8, "Offset mismatch for FEncounterGetEnemyFactionStateTreeTaskInstanceData::Faction");
static_assert(offsetof(FEncounterGetEnemyFactionStateTreeTaskInstanceData, EnemyTagQuery) == 0x10, "Offset mismatch for FEncounterGetEnemyFactionStateTreeTaskInstanceData::EnemyTagQuery");
static_assert(offsetof(FEncounterGetEnemyFactionStateTreeTaskInstanceData, UserActor) == 0x58, "Offset mismatch for FEncounterGetEnemyFactionStateTreeTaskInstanceData::UserActor");
static_assert(offsetof(FEncounterGetEnemyFactionStateTreeTaskInstanceData, EnemyFaction) == 0x60, "Offset mismatch for FEncounterGetEnemyFactionStateTreeTaskInstanceData::EnemyFaction");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetEnemyFactionStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetEnemyFactionStateTreeTask) == 0x20, "Size mismatch for FEncounterGetEnemyFactionStateTreeTask");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FEncounterGetKillCountStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    int32_t Value; // 0x48 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetKillCountStateTreeTaskInstanceData) == 0x58, "Size mismatch for FEncounterGetKillCountStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetKillCountStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FEncounterGetKillCountStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FEncounterGetKillCountStateTreeTaskInstanceData, Value) == 0x48, "Offset mismatch for FEncounterGetKillCountStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetKillCountStateTreeTaskInstanceData, UserActor) == 0x50, "Offset mismatch for FEncounterGetKillCountStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetKillCountStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetKillCountStateTreeTask) == 0x20, "Size mismatch for FEncounterGetKillCountStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEncounterGetPersistentValueStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t Value; // 0x4 (Size: 0x4, Type: IntProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetPersistentValueStateTreeTaskInstanceData) == 0x10, "Size mismatch for FEncounterGetPersistentValueStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetPersistentValueStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetPersistentValueStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetPersistentValueStateTreeTaskInstanceData, Value) == 0x4, "Offset mismatch for FEncounterGetPersistentValueStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetPersistentValueStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FEncounterGetPersistentValueStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetPersistentValueStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetPersistentValueStateTreeTask) == 0x20, "Size mismatch for FEncounterGetPersistentValueStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEncounterGetPlayerCountStateTreeTaskInstanceData
{
    int32_t Value; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetPlayerCountStateTreeTaskInstanceData) == 0x10, "Size mismatch for FEncounterGetPlayerCountStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetPlayerCountStateTreeTaskInstanceData, Value) == 0x0, "Offset mismatch for FEncounterGetPlayerCountStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetPlayerCountStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FEncounterGetPlayerCountStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetPlayerCountStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetPlayerCountStateTreeTask) == 0x20, "Size mismatch for FEncounterGetPlayerCountStateTreeTask");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FEncounterGetRemainingCountStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    int32_t Value; // 0x48 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetRemainingCountStateTreeTaskInstanceData) == 0x58, "Size mismatch for FEncounterGetRemainingCountStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetRemainingCountStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FEncounterGetRemainingCountStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FEncounterGetRemainingCountStateTreeTaskInstanceData, Value) == 0x48, "Offset mismatch for FEncounterGetRemainingCountStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetRemainingCountStateTreeTaskInstanceData, UserActor) == 0x50, "Offset mismatch for FEncounterGetRemainingCountStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetRemainingCountStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetRemainingCountStateTreeTask) == 0x20, "Size mismatch for FEncounterGetRemainingCountStateTreeTask");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEncounterGetVariableActorClassStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftClassPtr Value; // 0x8 (Size: 0x20, Type: SoftClassProperty)
    AActor* UserActor; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableActorClassStateTreeTaskInstanceData) == 0x30, "Size mismatch for FEncounterGetVariableActorClassStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableActorClassStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableActorClassStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableActorClassStateTreeTaskInstanceData, Value) == 0x8, "Offset mismatch for FEncounterGetVariableActorClassStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariableActorClassStateTreeTaskInstanceData, UserActor) == 0x28, "Offset mismatch for FEncounterGetVariableActorClassStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableActorClassStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableActorClassStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableActorClassStateTreeTask");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FEncounterGetVariableActorDescriptionStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription> Value; // 0x8 (Size: 0x10, Type: ArrayProperty)
    AActor* UserActor; // 0x18 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableActorDescriptionStateTreeTaskInstanceData) == 0x20, "Size mismatch for FEncounterGetVariableActorDescriptionStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableActorDescriptionStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableActorDescriptionStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableActorDescriptionStateTreeTaskInstanceData, Value) == 0x8, "Offset mismatch for FEncounterGetVariableActorDescriptionStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariableActorDescriptionStateTreeTaskInstanceData, UserActor) == 0x18, "Offset mismatch for FEncounterGetVariableActorDescriptionStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableActorDescriptionStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableActorDescriptionStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableActorDescriptionStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEncounterGetVariableBoolStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    bool bValue; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableBoolStateTreeTaskInstanceData) == 0x10, "Size mismatch for FEncounterGetVariableBoolStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableBoolStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableBoolStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableBoolStateTreeTaskInstanceData, bValue) == 0x4, "Offset mismatch for FEncounterGetVariableBoolStateTreeTaskInstanceData::bValue");
static_assert(offsetof(FEncounterGetVariableBoolStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FEncounterGetVariableBoolStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableBoolStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableBoolStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableBoolStateTreeTask");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEncounterGetVariableFactionStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UEncounterFactionData*> Value; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    AActor* UserActor; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableFactionStateTreeTaskInstanceData) == 0x30, "Size mismatch for FEncounterGetVariableFactionStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableFactionStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableFactionStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableFactionStateTreeTaskInstanceData, Value) == 0x8, "Offset mismatch for FEncounterGetVariableFactionStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariableFactionStateTreeTaskInstanceData, UserActor) == 0x28, "Offset mismatch for FEncounterGetVariableFactionStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableFactionStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableFactionStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableFactionStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEncounterGetVariableFloatStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    float Value; // 0x4 (Size: 0x4, Type: FloatProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableFloatStateTreeTaskInstanceData) == 0x10, "Size mismatch for FEncounterGetVariableFloatStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableFloatStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableFloatStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableFloatStateTreeTaskInstanceData, Value) == 0x4, "Offset mismatch for FEncounterGetVariableFloatStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariableFloatStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FEncounterGetVariableFloatStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableFloatStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableFloatStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableFloatStateTreeTask");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEncounterGetVariableGameplayTagContainerStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer Value; // 0x8 (Size: 0x20, Type: StructProperty)
    AActor* UserActor; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableGameplayTagContainerStateTreeTaskInstanceData) == 0x30, "Size mismatch for FEncounterGetVariableGameplayTagContainerStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableGameplayTagContainerStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableGameplayTagContainerStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableGameplayTagContainerStateTreeTaskInstanceData, Value) == 0x8, "Offset mismatch for FEncounterGetVariableGameplayTagContainerStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariableGameplayTagContainerStateTreeTaskInstanceData, UserActor) == 0x28, "Offset mismatch for FEncounterGetVariableGameplayTagContainerStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableGameplayTagContainerStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableGameplayTagContainerStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableGameplayTagContainerStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEncounterGetVariableGameplayTagStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag Value; // 0x4 (Size: 0x4, Type: StructProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableGameplayTagStateTreeTaskInstanceData) == 0x10, "Size mismatch for FEncounterGetVariableGameplayTagStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableGameplayTagStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableGameplayTagStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableGameplayTagStateTreeTaskInstanceData, Value) == 0x4, "Offset mismatch for FEncounterGetVariableGameplayTagStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariableGameplayTagStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FEncounterGetVariableGameplayTagStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableGameplayTagStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableGameplayTagStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableGameplayTagStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEncounterGetVariableIntStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t Value; // 0x4 (Size: 0x4, Type: IntProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableIntStateTreeTaskInstanceData) == 0x10, "Size mismatch for FEncounterGetVariableIntStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableIntStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableIntStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableIntStateTreeTaskInstanceData, Value) == 0x4, "Offset mismatch for FEncounterGetVariableIntStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariableIntStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FEncounterGetVariableIntStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableIntStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableIntStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableIntStateTreeTask");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEncounterGetVariableItemDefinitionStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UFortWorldItemDefinition*> Value; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    AActor* UserActor; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableItemDefinitionStateTreeTaskInstanceData) == 0x30, "Size mismatch for FEncounterGetVariableItemDefinitionStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableItemDefinitionStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableItemDefinitionStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableItemDefinitionStateTreeTaskInstanceData, Value) == 0x8, "Offset mismatch for FEncounterGetVariableItemDefinitionStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariableItemDefinitionStateTreeTaskInstanceData, UserActor) == 0x28, "Offset mismatch for FEncounterGetVariableItemDefinitionStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableItemDefinitionStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableItemDefinitionStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableItemDefinitionStateTreeTask");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEncounterGetVariableLWMEncounterStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UFortAthenaLivingWorldEncounter*> Value; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    AActor* UserActor; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableLWMEncounterStateTreeTaskInstanceData) == 0x30, "Size mismatch for FEncounterGetVariableLWMEncounterStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableLWMEncounterStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableLWMEncounterStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableLWMEncounterStateTreeTaskInstanceData, Value) == 0x8, "Offset mismatch for FEncounterGetVariableLWMEncounterStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariableLWMEncounterStateTreeTaskInstanceData, UserActor) == 0x28, "Offset mismatch for FEncounterGetVariableLWMEncounterStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableLWMEncounterStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableLWMEncounterStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableLWMEncounterStateTreeTask");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEncounterGetVariableQuestDefinitionStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UFortQuestItemDefinition*> Value; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    AActor* UserActor; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableQuestDefinitionStateTreeTaskInstanceData) == 0x30, "Size mismatch for FEncounterGetVariableQuestDefinitionStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableQuestDefinitionStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableQuestDefinitionStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableQuestDefinitionStateTreeTaskInstanceData, Value) == 0x8, "Offset mismatch for FEncounterGetVariableQuestDefinitionStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariableQuestDefinitionStateTreeTaskInstanceData, UserActor) == 0x28, "Offset mismatch for FEncounterGetVariableQuestDefinitionStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableQuestDefinitionStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableQuestDefinitionStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableQuestDefinitionStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEncounterGetVariableStringStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    FName Value; // 0x4 (Size: 0x4, Type: NameProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableStringStateTreeTaskInstanceData) == 0x10, "Size mismatch for FEncounterGetVariableStringStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableStringStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableStringStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableStringStateTreeTaskInstanceData, Value) == 0x4, "Offset mismatch for FEncounterGetVariableStringStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariableStringStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FEncounterGetVariableStringStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableStringStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableStringStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableStringStateTreeTask");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FEncounterGetVariableTagQueryStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagQuery Value; // 0x8 (Size: 0x48, Type: StructProperty)
    AActor* UserActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariableTagQueryStateTreeTaskInstanceData) == 0x58, "Size mismatch for FEncounterGetVariableTagQueryStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariableTagQueryStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterGetVariableTagQueryStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterGetVariableTagQueryStateTreeTaskInstanceData, Value) == 0x8, "Offset mismatch for FEncounterGetVariableTagQueryStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariableTagQueryStateTreeTaskInstanceData, UserActor) == 0x50, "Offset mismatch for FEncounterGetVariableTagQueryStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariableTagQueryStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariableTagQueryStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariableTagQueryStateTreeTask");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FEncounterGetVariantTagQueryStateTreeTaskInstanceData
{
    FGameplayTagQuery BaseTagQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery Value; // 0x48 (Size: 0x48, Type: StructProperty)
    AActor* UserActor; // 0x90 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterGetVariantTagQueryStateTreeTaskInstanceData) == 0x98, "Size mismatch for FEncounterGetVariantTagQueryStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterGetVariantTagQueryStateTreeTaskInstanceData, BaseTagQuery) == 0x0, "Offset mismatch for FEncounterGetVariantTagQueryStateTreeTaskInstanceData::BaseTagQuery");
static_assert(offsetof(FEncounterGetVariantTagQueryStateTreeTaskInstanceData, Value) == 0x48, "Offset mismatch for FEncounterGetVariantTagQueryStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterGetVariantTagQueryStateTreeTaskInstanceData, UserActor) == 0x90, "Offset mismatch for FEncounterGetVariantTagQueryStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterGetVariantTagQueryStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterGetVariantTagQueryStateTreeTask) == 0x20, "Size mismatch for FEncounterGetVariantTagQueryStateTreeTask");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FEncounterPrefabEntry
{
    UEncounterItemDefinition* EncounterDefinition; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag EncounterIdentifierTag; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FScalableFloat Weight; // 0x10 (Size: 0x28, Type: StructProperty)
    FWorldConditionQueryDefinition CanSpawnCondition; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FEncounterPrefabEntry) == 0x50, "Size mismatch for FEncounterPrefabEntry");
static_assert(offsetof(FEncounterPrefabEntry, EncounterDefinition) == 0x0, "Offset mismatch for FEncounterPrefabEntry::EncounterDefinition");
static_assert(offsetof(FEncounterPrefabEntry, EncounterIdentifierTag) == 0x8, "Offset mismatch for FEncounterPrefabEntry::EncounterIdentifierTag");
static_assert(offsetof(FEncounterPrefabEntry, Weight) == 0x10, "Offset mismatch for FEncounterPrefabEntry::Weight");
static_assert(offsetof(FEncounterPrefabEntry, CanSpawnCondition) == 0x38, "Offset mismatch for FEncounterPrefabEntry::CanSpawnCondition");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FEncounterSelectFactionStateTreeTaskInstanceData
{
    UDataRegistry* FactionRegistry; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery FactionRequirements; // 0x8 (Size: 0x48, Type: StructProperty)
    bool bSaveToEncounterManager; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0x58 (Size: 0x8, Type: ObjectProperty)
    UEncounterFactionData* Faction; // 0x60 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_68[0x8]; // 0x68 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FEncounterSelectFactionStateTreeTaskInstanceData) == 0x70, "Size mismatch for FEncounterSelectFactionStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterSelectFactionStateTreeTaskInstanceData, FactionRegistry) == 0x0, "Offset mismatch for FEncounterSelectFactionStateTreeTaskInstanceData::FactionRegistry");
static_assert(offsetof(FEncounterSelectFactionStateTreeTaskInstanceData, FactionRequirements) == 0x8, "Offset mismatch for FEncounterSelectFactionStateTreeTaskInstanceData::FactionRequirements");
static_assert(offsetof(FEncounterSelectFactionStateTreeTaskInstanceData, bSaveToEncounterManager) == 0x50, "Offset mismatch for FEncounterSelectFactionStateTreeTaskInstanceData::bSaveToEncounterManager");
static_assert(offsetof(FEncounterSelectFactionStateTreeTaskInstanceData, UserActor) == 0x58, "Offset mismatch for FEncounterSelectFactionStateTreeTaskInstanceData::UserActor");
static_assert(offsetof(FEncounterSelectFactionStateTreeTaskInstanceData, Faction) == 0x60, "Offset mismatch for FEncounterSelectFactionStateTreeTaskInstanceData::Faction");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterSelectFactionStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterSelectFactionStateTreeTask) == 0x20, "Size mismatch for FEncounterSelectFactionStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEncounterSetCenterActorStateTreeTaskInstanceData
{
    TWeakObjectPtr<AActor*> CenterActor; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterSetCenterActorStateTreeTaskInstanceData) == 0x10, "Size mismatch for FEncounterSetCenterActorStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterSetCenterActorStateTreeTaskInstanceData, CenterActor) == 0x0, "Offset mismatch for FEncounterSetCenterActorStateTreeTaskInstanceData::CenterActor");
static_assert(offsetof(FEncounterSetCenterActorStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FEncounterSetCenterActorStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterSetCenterActorStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterSetCenterActorStateTreeTask) == 0x20, "Size mismatch for FEncounterSetCenterActorStateTreeTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FEncounterSetPersistentValueStateTreeTaskInstanceData
{
    FGameplayTag VariableIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t Value; // 0x4 (Size: 0x4, Type: IntProperty)
    uint8_t Scope; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterSetPersistentValueStateTreeTaskInstanceData) == 0x18, "Size mismatch for FEncounterSetPersistentValueStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterSetPersistentValueStateTreeTaskInstanceData, VariableIdentifier) == 0x0, "Offset mismatch for FEncounterSetPersistentValueStateTreeTaskInstanceData::VariableIdentifier");
static_assert(offsetof(FEncounterSetPersistentValueStateTreeTaskInstanceData, Value) == 0x4, "Offset mismatch for FEncounterSetPersistentValueStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterSetPersistentValueStateTreeTaskInstanceData, Scope) == 0x8, "Offset mismatch for FEncounterSetPersistentValueStateTreeTaskInstanceData::Scope");
static_assert(offsetof(FEncounterSetPersistentValueStateTreeTaskInstanceData, UserActor) == 0x10, "Offset mismatch for FEncounterSetPersistentValueStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterSetPersistentValueStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterSetPersistentValueStateTreeTask) == 0x20, "Size mismatch for FEncounterSetPersistentValueStateTreeTask");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FEndAllMobEncountersStateTreeTaskInstanceData
{
    AActor* UserActor; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEndAllMobEncountersStateTreeTaskInstanceData) == 0x8, "Size mismatch for FEndAllMobEncountersStateTreeTaskInstanceData");
static_assert(offsetof(FEndAllMobEncountersStateTreeTaskInstanceData, UserActor) == 0x0, "Offset mismatch for FEndAllMobEncountersStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEndAllMobEncountersStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEndAllMobEncountersStateTreeTask) == 0x20, "Size mismatch for FEndAllMobEncountersStateTreeTask");

// Size: 0x138 (Inherited: 0x78, Single: 0xc0)
struct FFortVerbMessage_EncounterCompleted : FVerbMessage
{
    FSubjectTagsPair EncounterItemDef; // 0x78 (Size: 0x38, Type: StructProperty)
    bool bSuccess; // 0xb0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b1[0x7]; // 0xb1 (Size: 0x7, Type: PaddingProperty)
    TArray<FSubjectTagsPair> EncounterPlayers; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    FSubjectTagsPair Faction; // 0xc8 (Size: 0x38, Type: StructProperty)
    FSubjectTagsPair EncounterVolumeTags; // 0x100 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FFortVerbMessage_EncounterCompleted) == 0x138, "Size mismatch for FFortVerbMessage_EncounterCompleted");
static_assert(offsetof(FFortVerbMessage_EncounterCompleted, EncounterItemDef) == 0x78, "Offset mismatch for FFortVerbMessage_EncounterCompleted::EncounterItemDef");
static_assert(offsetof(FFortVerbMessage_EncounterCompleted, bSuccess) == 0xb0, "Offset mismatch for FFortVerbMessage_EncounterCompleted::bSuccess");
static_assert(offsetof(FFortVerbMessage_EncounterCompleted, EncounterPlayers) == 0xb8, "Offset mismatch for FFortVerbMessage_EncounterCompleted::EncounterPlayers");
static_assert(offsetof(FFortVerbMessage_EncounterCompleted, Faction) == 0xc8, "Offset mismatch for FFortVerbMessage_EncounterCompleted::Faction");
static_assert(offsetof(FFortVerbMessage_EncounterCompleted, EncounterVolumeTags) == 0x100, "Offset mismatch for FFortVerbMessage_EncounterCompleted::EncounterVolumeTags");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FGetAnchorStateTreeTaskInstanceData
{
    FGameplayTagQuery AnchorQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    TWeakObjectPtr<AActor*> AnchorActor; // 0x48 (Size: 0x8, Type: WeakObjectProperty)
    AActor* UserActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGetAnchorStateTreeTaskInstanceData) == 0x58, "Size mismatch for FGetAnchorStateTreeTaskInstanceData");
static_assert(offsetof(FGetAnchorStateTreeTaskInstanceData, AnchorQuery) == 0x0, "Offset mismatch for FGetAnchorStateTreeTaskInstanceData::AnchorQuery");
static_assert(offsetof(FGetAnchorStateTreeTaskInstanceData, AnchorActor) == 0x48, "Offset mismatch for FGetAnchorStateTreeTaskInstanceData::AnchorActor");
static_assert(offsetof(FGetAnchorStateTreeTaskInstanceData, UserActor) == 0x50, "Offset mismatch for FGetAnchorStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FGetAnchorStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FGetAnchorStateTreeTask) == 0x20, "Size mismatch for FGetAnchorStateTreeTask");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FGetEncounterActorStateTreeTaskInstanceData
{
    FGameplayTagQuery ActorQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    bool bQueryAgainstTrackedActorIdentifiers; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x3]; // 0x49 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> ChosenActor; // 0x4c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x58 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGetEncounterActorStateTreeTaskInstanceData) == 0x60, "Size mismatch for FGetEncounterActorStateTreeTaskInstanceData");
static_assert(offsetof(FGetEncounterActorStateTreeTaskInstanceData, ActorQuery) == 0x0, "Offset mismatch for FGetEncounterActorStateTreeTaskInstanceData::ActorQuery");
static_assert(offsetof(FGetEncounterActorStateTreeTaskInstanceData, bQueryAgainstTrackedActorIdentifiers) == 0x48, "Offset mismatch for FGetEncounterActorStateTreeTaskInstanceData::bQueryAgainstTrackedActorIdentifiers");
static_assert(offsetof(FGetEncounterActorStateTreeTaskInstanceData, ChosenActor) == 0x4c, "Offset mismatch for FGetEncounterActorStateTreeTaskInstanceData::ChosenActor");
static_assert(offsetof(FGetEncounterActorStateTreeTaskInstanceData, UserActor) == 0x58, "Offset mismatch for FGetEncounterActorStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FGetEncounterActorStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FGetEncounterActorStateTreeTask) == 0x20, "Size mismatch for FGetEncounterActorStateTreeTask");

// Size: 0xd0 (Inherited: 0x0, Single: 0xd0)
struct FGetFactionEntryStateTreeTaskInstanceData
{
    bool bSpecifyFaction; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UEncounterFactionData* Faction; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UDataRegistry* FactionRegistry; // 0x10 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery FactionRequirements; // 0x18 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery LWMEncounterTagQuery; // 0x60 (Size: 0x48, Type: StructProperty)
    AActor* UserActor; // 0xa8 (Size: 0x8, Type: ObjectProperty)
    TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription> ActorDescriptions; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortAthenaLivingWorldTaggedSpawnActionClass> SpawnActions; // 0xc0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGetFactionEntryStateTreeTaskInstanceData) == 0xd0, "Size mismatch for FGetFactionEntryStateTreeTaskInstanceData");
static_assert(offsetof(FGetFactionEntryStateTreeTaskInstanceData, bSpecifyFaction) == 0x0, "Offset mismatch for FGetFactionEntryStateTreeTaskInstanceData::bSpecifyFaction");
static_assert(offsetof(FGetFactionEntryStateTreeTaskInstanceData, Faction) == 0x8, "Offset mismatch for FGetFactionEntryStateTreeTaskInstanceData::Faction");
static_assert(offsetof(FGetFactionEntryStateTreeTaskInstanceData, FactionRegistry) == 0x10, "Offset mismatch for FGetFactionEntryStateTreeTaskInstanceData::FactionRegistry");
static_assert(offsetof(FGetFactionEntryStateTreeTaskInstanceData, FactionRequirements) == 0x18, "Offset mismatch for FGetFactionEntryStateTreeTaskInstanceData::FactionRequirements");
static_assert(offsetof(FGetFactionEntryStateTreeTaskInstanceData, LWMEncounterTagQuery) == 0x60, "Offset mismatch for FGetFactionEntryStateTreeTaskInstanceData::LWMEncounterTagQuery");
static_assert(offsetof(FGetFactionEntryStateTreeTaskInstanceData, UserActor) == 0xa8, "Offset mismatch for FGetFactionEntryStateTreeTaskInstanceData::UserActor");
static_assert(offsetof(FGetFactionEntryStateTreeTaskInstanceData, ActorDescriptions) == 0xb0, "Offset mismatch for FGetFactionEntryStateTreeTaskInstanceData::ActorDescriptions");
static_assert(offsetof(FGetFactionEntryStateTreeTaskInstanceData, SpawnActions) == 0xc0, "Offset mismatch for FGetFactionEntryStateTreeTaskInstanceData::SpawnActions");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FGetFactionEntryStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FGetFactionEntryStateTreeTask) == 0x20, "Size mismatch for FGetFactionEntryStateTreeTask");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FGetLWMEncounterPawnStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    TWeakObjectPtr<AFortPawn*> ChosenPawn; // 0x48 (Size: 0x8, Type: WeakObjectProperty)
    AActor* UserActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGetLWMEncounterPawnStateTreeTaskInstanceData) == 0x58, "Size mismatch for FGetLWMEncounterPawnStateTreeTaskInstanceData");
static_assert(offsetof(FGetLWMEncounterPawnStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FGetLWMEncounterPawnStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FGetLWMEncounterPawnStateTreeTaskInstanceData, ChosenPawn) == 0x48, "Offset mismatch for FGetLWMEncounterPawnStateTreeTaskInstanceData::ChosenPawn");
static_assert(offsetof(FGetLWMEncounterPawnStateTreeTaskInstanceData, UserActor) == 0x50, "Offset mismatch for FGetLWMEncounterPawnStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FGetLWMEncounterPawnStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FGetLWMEncounterPawnStateTreeTask) == 0x20, "Size mismatch for FGetLWMEncounterPawnStateTreeTask");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FGrantQuestStateTreeTaskInstanceData
{
    TSoftObjectPtr<UFortQuestItemDefinition*> QuestToGrant; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t GrantType; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
    AActor* TargetActor; // 0x28 (Size: 0x8, Type: ObjectProperty)
    AActor* UserActor; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGrantQuestStateTreeTaskInstanceData) == 0x38, "Size mismatch for FGrantQuestStateTreeTaskInstanceData");
static_assert(offsetof(FGrantQuestStateTreeTaskInstanceData, QuestToGrant) == 0x0, "Offset mismatch for FGrantQuestStateTreeTaskInstanceData::QuestToGrant");
static_assert(offsetof(FGrantQuestStateTreeTaskInstanceData, GrantType) == 0x20, "Offset mismatch for FGrantQuestStateTreeTaskInstanceData::GrantType");
static_assert(offsetof(FGrantQuestStateTreeTaskInstanceData, TargetActor) == 0x28, "Offset mismatch for FGrantQuestStateTreeTaskInstanceData::TargetActor");
static_assert(offsetof(FGrantQuestStateTreeTaskInstanceData, UserActor) == 0x30, "Offset mismatch for FGrantQuestStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FGrantQuestStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FGrantQuestStateTreeTask) == 0x20, "Size mismatch for FGrantQuestStateTreeTask");

// Size: 0x40 (Inherited: 0x8, Single: 0x38)
struct FGrantReactionStateTreeTaskInstanceData : FFortStateTreeEncounterInstanceDataBase
{
    TArray<FScenarioReactionEntry> ReactionEntries; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> Reactions; // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t GrantType; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> TargetActor; // 0x2c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGrantReactionStateTreeTaskInstanceData) == 0x40, "Size mismatch for FGrantReactionStateTreeTaskInstanceData");
static_assert(offsetof(FGrantReactionStateTreeTaskInstanceData, ReactionEntries) == 0x8, "Offset mismatch for FGrantReactionStateTreeTaskInstanceData::ReactionEntries");
static_assert(offsetof(FGrantReactionStateTreeTaskInstanceData, Reactions) == 0x18, "Offset mismatch for FGrantReactionStateTreeTaskInstanceData::Reactions");
static_assert(offsetof(FGrantReactionStateTreeTaskInstanceData, GrantType) == 0x28, "Offset mismatch for FGrantReactionStateTreeTaskInstanceData::GrantType");
static_assert(offsetof(FGrantReactionStateTreeTaskInstanceData, TargetActor) == 0x2c, "Offset mismatch for FGrantReactionStateTreeTaskInstanceData::TargetActor");
static_assert(offsetof(FGrantReactionStateTreeTaskInstanceData, UserActor) == 0x38, "Offset mismatch for FGrantReactionStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FScenarioReactionEntry
{
    FDataRegistryOrTableRow RowValue; // 0x0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FScenarioReactionEntry) == 0x20, "Size mismatch for FScenarioReactionEntry");
static_assert(offsetof(FScenarioReactionEntry, RowValue) == 0x0, "Offset mismatch for FScenarioReactionEntry::RowValue");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FGrantReactionStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FGrantReactionStateTreeTask) == 0x20, "Size mismatch for FGrantReactionStateTreeTask");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    UClass* GameplayEffect; // 0x48 (Size: 0x8, Type: ClassProperty)
    bool bRemoveEffectOnExit; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagContainer IdentifierTags; // 0x58 (Size: 0x20, Type: StructProperty)
    AActor* UserActor; // 0x78 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_80[0x8]; // 0x80 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData) == 0x88, "Size mismatch for FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData, GameplayEffect) == 0x48, "Offset mismatch for FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData::GameplayEffect");
static_assert(offsetof(FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData, bRemoveEffectOnExit) == 0x50, "Offset mismatch for FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData::bRemoveEffectOnExit");
static_assert(offsetof(FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData, IdentifierTags) == 0x58, "Offset mismatch for FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData::IdentifierTags");
static_assert(offsetof(FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData, UserActor) == 0x78, "Offset mismatch for FLWMEncounterAddGameplayEffectStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FLWMEncounterAddGameplayEffectStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FLWMEncounterAddGameplayEffectStateTreeTask) == 0x20, "Size mismatch for FLWMEncounterAddGameplayEffectStateTreeTask");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FLWMEncounterAdvanceStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor; // 0x48 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FLWMEncounterAdvanceStateTreeTaskInstanceData) == 0x50, "Size mismatch for FLWMEncounterAdvanceStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterAdvanceStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterAdvanceStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterAdvanceStateTreeTaskInstanceData, UserActor) == 0x48, "Offset mismatch for FLWMEncounterAdvanceStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FLWMEncounterAdvanceStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FLWMEncounterAdvanceStateTreeTask) == 0x20, "Size mismatch for FLWMEncounterAdvanceStateTreeTask");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FLWMEncounterAssignPointProvidersStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery PatrolPathTagQuery; // 0x48 (Size: 0x48, Type: StructProperty)
    bool bUseClosestProvider; // 0x90 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0x98 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FLWMEncounterAssignPointProvidersStateTreeTaskInstanceData) == 0xa0, "Size mismatch for FLWMEncounterAssignPointProvidersStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterAssignPointProvidersStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterAssignPointProvidersStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterAssignPointProvidersStateTreeTaskInstanceData, PatrolPathTagQuery) == 0x48, "Offset mismatch for FLWMEncounterAssignPointProvidersStateTreeTaskInstanceData::PatrolPathTagQuery");
static_assert(offsetof(FLWMEncounterAssignPointProvidersStateTreeTaskInstanceData, bUseClosestProvider) == 0x90, "Offset mismatch for FLWMEncounterAssignPointProvidersStateTreeTaskInstanceData::bUseClosestProvider");
static_assert(offsetof(FLWMEncounterAssignPointProvidersStateTreeTaskInstanceData, UserActor) == 0x98, "Offset mismatch for FLWMEncounterAssignPointProvidersStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FLWMEncounterAssignPointProvidersStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FLWMEncounterAssignPointProvidersStateTreeTask) == 0x20, "Size mismatch for FLWMEncounterAssignPointProvidersStateTreeTask");

// Size: 0x248 (Inherited: 0x0, Single: 0x248)
struct FDynamicEncounterEntry
{
    FString DebugName; // 0x0 (Size: 0x10, Type: StrProperty)
    bool bUseEventTemplate; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    int32_t SpawnCount; // 0x14 (Size: 0x4, Type: IntProperty)
    int32_t MaxConcurrentSpawns; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FFortAthenaLivingWorldEvent EventTemplate; // 0x20 (Size: 0x1b8, Type: StructProperty)
    bool bOverrideActorCount; // 0x1d8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d9[0x3]; // 0x1d9 (Size: 0x3, Type: PaddingProperty)
    int32_t ActorCountOverrideMax; // 0x1dc (Size: 0x4, Type: IntProperty)
    int32_t ActorCountOverrideMin; // 0x1e0 (Size: 0x4, Type: IntProperty)
    bool bUseEncounterTagQuery; // 0x1e4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1e5[0x3]; // 0x1e5 (Size: 0x3, Type: PaddingProperty)
    FGameplayTagQuery EncounterTagQuery; // 0x1e8 (Size: 0x48, Type: StructProperty)
    bool bCreateRandomSingleActorEvents; // 0x230 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_231[0x3]; // 0x231 (Size: 0x3, Type: PaddingProperty)
    int32_t NoActorLimitEventCount; // 0x234 (Size: 0x4, Type: IntProperty)
    TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription> ActorDescriptions; // 0x238 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDynamicEncounterEntry) == 0x248, "Size mismatch for FDynamicEncounterEntry");
static_assert(offsetof(FDynamicEncounterEntry, DebugName) == 0x0, "Offset mismatch for FDynamicEncounterEntry::DebugName");
static_assert(offsetof(FDynamicEncounterEntry, bUseEventTemplate) == 0x10, "Offset mismatch for FDynamicEncounterEntry::bUseEventTemplate");
static_assert(offsetof(FDynamicEncounterEntry, SpawnCount) == 0x14, "Offset mismatch for FDynamicEncounterEntry::SpawnCount");
static_assert(offsetof(FDynamicEncounterEntry, MaxConcurrentSpawns) == 0x18, "Offset mismatch for FDynamicEncounterEntry::MaxConcurrentSpawns");
static_assert(offsetof(FDynamicEncounterEntry, EventTemplate) == 0x20, "Offset mismatch for FDynamicEncounterEntry::EventTemplate");
static_assert(offsetof(FDynamicEncounterEntry, bOverrideActorCount) == 0x1d8, "Offset mismatch for FDynamicEncounterEntry::bOverrideActorCount");
static_assert(offsetof(FDynamicEncounterEntry, ActorCountOverrideMax) == 0x1dc, "Offset mismatch for FDynamicEncounterEntry::ActorCountOverrideMax");
static_assert(offsetof(FDynamicEncounterEntry, ActorCountOverrideMin) == 0x1e0, "Offset mismatch for FDynamicEncounterEntry::ActorCountOverrideMin");
static_assert(offsetof(FDynamicEncounterEntry, bUseEncounterTagQuery) == 0x1e4, "Offset mismatch for FDynamicEncounterEntry::bUseEncounterTagQuery");
static_assert(offsetof(FDynamicEncounterEntry, EncounterTagQuery) == 0x1e8, "Offset mismatch for FDynamicEncounterEntry::EncounterTagQuery");
static_assert(offsetof(FDynamicEncounterEntry, bCreateRandomSingleActorEvents) == 0x230, "Offset mismatch for FDynamicEncounterEntry::bCreateRandomSingleActorEvents");
static_assert(offsetof(FDynamicEncounterEntry, NoActorLimitEventCount) == 0x234, "Offset mismatch for FDynamicEncounterEntry::NoActorLimitEventCount");
static_assert(offsetof(FDynamicEncounterEntry, ActorDescriptions) == 0x238, "Offset mismatch for FDynamicEncounterEntry::ActorDescriptions");

// Size: 0x160 (Inherited: 0x0, Single: 0x160)
struct FLWMEncounterStartSharedStateTreeTaskInstanceData
{
    FGameplayTagQuery PointProviderTagQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    bool bAttachVolumeToSpawn; // 0x48 (Size: 0x1, Type: BoolProperty)
    bool bOverrideAnchorPosition; // 0x49 (Size: 0x1, Type: BoolProperty)
    bool bUseVolumeAsAnchor; // 0x4a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4b[0x5]; // 0x4b (Size: 0x5, Type: PaddingProperty)
    FGameplayTagQuery AnchorPointTagQuery; // 0x50 (Size: 0x48, Type: StructProperty)
    FScalableFloat LeashRadiusInner; // 0x98 (Size: 0x28, Type: StructProperty)
    FScalableFloat LeashRadiusOuter; // 0xc0 (Size: 0x28, Type: StructProperty)
    FGameplayTagContainer EncounterIdentifierTags; // 0xe8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ActorTags; // 0x108 (Size: 0x20, Type: StructProperty)
    FScalableFloat SpawnTimeout; // 0x128 (Size: 0x28, Type: StructProperty)
    bool bPauseOnExit; // 0x150 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_151[0x7]; // 0x151 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0x158 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FLWMEncounterStartSharedStateTreeTaskInstanceData) == 0x160, "Size mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterStartSharedStateTreeTaskInstanceData, PointProviderTagQuery) == 0x0, "Offset mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData::PointProviderTagQuery");
static_assert(offsetof(FLWMEncounterStartSharedStateTreeTaskInstanceData, bAttachVolumeToSpawn) == 0x48, "Offset mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData::bAttachVolumeToSpawn");
static_assert(offsetof(FLWMEncounterStartSharedStateTreeTaskInstanceData, bOverrideAnchorPosition) == 0x49, "Offset mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData::bOverrideAnchorPosition");
static_assert(offsetof(FLWMEncounterStartSharedStateTreeTaskInstanceData, bUseVolumeAsAnchor) == 0x4a, "Offset mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData::bUseVolumeAsAnchor");
static_assert(offsetof(FLWMEncounterStartSharedStateTreeTaskInstanceData, AnchorPointTagQuery) == 0x50, "Offset mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData::AnchorPointTagQuery");
static_assert(offsetof(FLWMEncounterStartSharedStateTreeTaskInstanceData, LeashRadiusInner) == 0x98, "Offset mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData::LeashRadiusInner");
static_assert(offsetof(FLWMEncounterStartSharedStateTreeTaskInstanceData, LeashRadiusOuter) == 0xc0, "Offset mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData::LeashRadiusOuter");
static_assert(offsetof(FLWMEncounterStartSharedStateTreeTaskInstanceData, EncounterIdentifierTags) == 0xe8, "Offset mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData::EncounterIdentifierTags");
static_assert(offsetof(FLWMEncounterStartSharedStateTreeTaskInstanceData, ActorTags) == 0x108, "Offset mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData::ActorTags");
static_assert(offsetof(FLWMEncounterStartSharedStateTreeTaskInstanceData, SpawnTimeout) == 0x128, "Offset mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData::SpawnTimeout");
static_assert(offsetof(FLWMEncounterStartSharedStateTreeTaskInstanceData, bPauseOnExit) == 0x150, "Offset mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData::bPauseOnExit");
static_assert(offsetof(FLWMEncounterStartSharedStateTreeTaskInstanceData, UserActor) == 0x158, "Offset mismatch for FLWMEncounterStartSharedStateTreeTaskInstanceData::UserActor");

// Size: 0x208 (Inherited: 0x160, Single: 0xa8)
struct FLWMEncounterDynamicStartStateTreeTaskInstanceData : FLWMEncounterStartSharedStateTreeTaskInstanceData
{
    bool bSpecifyFaction; // 0x160 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_161[0x7]; // 0x161 (Size: 0x7, Type: PaddingProperty)
    UEncounterFactionData* Faction; // 0x168 (Size: 0x8, Type: ObjectProperty)
    TArray<FDynamicEncounterEntry> DynamicEncounterEntries; // 0x170 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UFortAthenaLivingWorldEncounter*> DynamicEmptyEncounter; // 0x180 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FFortAthenaLivingWorldTaggedSpawnActionClass> SpawnActions; // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    bool bOverrideEnvQuery; // 0x1b0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1b1[0x7]; // 0x1b1 (Size: 0x7, Type: PaddingProperty)
    UEnvQuery* SpawnAroundEnvironmentQuery; // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EEnvQueryRunMode> SpawnAroundEnvironmentQueryRunMode; // 0x1c0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1c1[0x7]; // 0x1c1 (Size: 0x7, Type: PaddingProperty)
    FSoftClassPath SpawnAroundNavigationSourceOverride; // 0x1c8 (Size: 0x18, Type: StructProperty)
    bool bWaitForEncounterDoneSpawning; // 0x1e0 (Size: 0x1, Type: BoolProperty)
    bool bOverrideDelayBetweenEvents; // 0x1e1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1e2[0x2]; // 0x1e2 (Size: 0x2, Type: PaddingProperty)
    float DelayBetweenEventsMin; // 0x1e4 (Size: 0x4, Type: FloatProperty)
    float DelayBetweenEventsMax; // 0x1e8 (Size: 0x4, Type: FloatProperty)
    bool bOverrideStageActorMaxCount; // 0x1ec (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1ed[0x3]; // 0x1ed (Size: 0x3, Type: PaddingProperty)
    int32_t StageActorMaxCount; // 0x1f0 (Size: 0x4, Type: IntProperty)
    bool bOverrideStageActorMaxSpawnedCount; // 0x1f4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f5[0x3]; // 0x1f5 (Size: 0x3, Type: PaddingProperty)
    int32_t StageActorMaxSpawnedCount; // 0x1f8 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<ULWMEncounterInstance*> EncounterInstance; // 0x1fc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_204[0x4]; // 0x204 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterDynamicStartStateTreeTaskInstanceData) == 0x208, "Size mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, bSpecifyFaction) == 0x160, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::bSpecifyFaction");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, Faction) == 0x168, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::Faction");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, DynamicEncounterEntries) == 0x170, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::DynamicEncounterEntries");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, DynamicEmptyEncounter) == 0x180, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::DynamicEmptyEncounter");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, SpawnActions) == 0x1a0, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::SpawnActions");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, bOverrideEnvQuery) == 0x1b0, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::bOverrideEnvQuery");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, SpawnAroundEnvironmentQuery) == 0x1b8, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::SpawnAroundEnvironmentQuery");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, SpawnAroundEnvironmentQueryRunMode) == 0x1c0, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::SpawnAroundEnvironmentQueryRunMode");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, SpawnAroundNavigationSourceOverride) == 0x1c8, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::SpawnAroundNavigationSourceOverride");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, bWaitForEncounterDoneSpawning) == 0x1e0, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::bWaitForEncounterDoneSpawning");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, bOverrideDelayBetweenEvents) == 0x1e1, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::bOverrideDelayBetweenEvents");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, DelayBetweenEventsMin) == 0x1e4, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::DelayBetweenEventsMin");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, DelayBetweenEventsMax) == 0x1e8, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::DelayBetweenEventsMax");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, bOverrideStageActorMaxCount) == 0x1ec, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::bOverrideStageActorMaxCount");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, StageActorMaxCount) == 0x1f0, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::StageActorMaxCount");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, bOverrideStageActorMaxSpawnedCount) == 0x1f4, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::bOverrideStageActorMaxSpawnedCount");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, StageActorMaxSpawnedCount) == 0x1f8, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::StageActorMaxSpawnedCount");
static_assert(offsetof(FLWMEncounterDynamicStartStateTreeTaskInstanceData, EncounterInstance) == 0x1fc, "Offset mismatch for FLWMEncounterDynamicStartStateTreeTaskInstanceData::EncounterInstance");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FLWMEncounterDynamicStartStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FLWMEncounterDynamicStartStateTreeTask) == 0x20, "Size mismatch for FLWMEncounterDynamicStartStateTreeTask");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FLWMEncounterAlertLevelTargetInfo
{
    float AwareForgetTime; // 0x0 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FLWMEncounterAlertLevelTargetInfo) == 0x4, "Size mismatch for FLWMEncounterAlertLevelTargetInfo");
static_assert(offsetof(FLWMEncounterAlertLevelTargetInfo, AwareForgetTime) == 0x0, "Offset mismatch for FLWMEncounterAlertLevelTargetInfo::AwareForgetTime");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FLWMEncounterInstanceSavedTargetInfo
{
    TWeakObjectPtr<AActor*> Target; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_8[0x4]; // 0x8 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterInstanceSavedTargetInfo) == 0xc, "Size mismatch for FLWMEncounterInstanceSavedTargetInfo");
static_assert(offsetof(FLWMEncounterInstanceSavedTargetInfo, Target) == 0x0, "Offset mismatch for FLWMEncounterInstanceSavedTargetInfo::Target");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FLWMEncounterInstanceEffectInfo
{
    UClass* GameplayEffect; // 0x0 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_8[0x50]; // 0x8 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterInstanceEffectInfo) == 0x58, "Size mismatch for FLWMEncounterInstanceEffectInfo");
static_assert(offsetof(FLWMEncounterInstanceEffectInfo, GameplayEffect) == 0x0, "Offset mismatch for FLWMEncounterInstanceEffectInfo::GameplayEffect");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FLWMEncounterPauseStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor; // 0x48 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FLWMEncounterPauseStateTreeTaskInstanceData) == 0x50, "Size mismatch for FLWMEncounterPauseStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterPauseStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterPauseStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterPauseStateTreeTaskInstanceData, UserActor) == 0x48, "Offset mismatch for FLWMEncounterPauseStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FLWMEncounterPauseStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FLWMEncounterPauseStateTreeTask) == 0x20, "Size mismatch for FLWMEncounterPauseStateTreeTask");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FLWMEncounterRemoveGameplayEffectStateTreeTaskInstanceData
{
    FGameplayTagQuery GameplayEffectQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor; // 0x48 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FLWMEncounterRemoveGameplayEffectStateTreeTaskInstanceData) == 0x50, "Size mismatch for FLWMEncounterRemoveGameplayEffectStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterRemoveGameplayEffectStateTreeTaskInstanceData, GameplayEffectQuery) == 0x0, "Offset mismatch for FLWMEncounterRemoveGameplayEffectStateTreeTaskInstanceData::GameplayEffectQuery");
static_assert(offsetof(FLWMEncounterRemoveGameplayEffectStateTreeTaskInstanceData, UserActor) == 0x48, "Offset mismatch for FLWMEncounterRemoveGameplayEffectStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FLWMEncounterRemoveGameplayEffectStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FLWMEncounterRemoveGameplayEffectStateTreeTask) == 0x20, "Size mismatch for FLWMEncounterRemoveGameplayEffectStateTreeTask");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FLWMEncounterResumeStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor; // 0x48 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FLWMEncounterResumeStateTreeTaskInstanceData) == 0x50, "Size mismatch for FLWMEncounterResumeStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterResumeStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterResumeStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterResumeStateTreeTaskInstanceData, UserActor) == 0x48, "Offset mismatch for FLWMEncounterResumeStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FLWMEncounterResumeStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FLWMEncounterResumeStateTreeTask) == 0x20, "Size mismatch for FLWMEncounterResumeStateTreeTask");

// Size: 0x50 (Inherited: 0x8, Single: 0x48)
struct FLWMEncounterRow : FTableRowBase
{
    TArray<FFortAthenaLivingWorldEventDataActorSpawnDescription> DynamicActorDescriptions; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortAthenaLivingWorldTaggedSpawnActionClass> DynamicSpawnActions; // 0x18 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer Tags; // 0x28 (Size: 0x20, Type: StructProperty)
    float Weight; // 0x48 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterRow) == 0x50, "Size mismatch for FLWMEncounterRow");
static_assert(offsetof(FLWMEncounterRow, DynamicActorDescriptions) == 0x8, "Offset mismatch for FLWMEncounterRow::DynamicActorDescriptions");
static_assert(offsetof(FLWMEncounterRow, DynamicSpawnActions) == 0x18, "Offset mismatch for FLWMEncounterRow::DynamicSpawnActions");
static_assert(offsetof(FLWMEncounterRow, Tags) == 0x28, "Offset mismatch for FLWMEncounterRow::Tags");
static_assert(offsetof(FLWMEncounterRow, Weight) == 0x48, "Offset mismatch for FLWMEncounterRow::Weight");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FLWMEncounterSetAlertLevelStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    FLWMEncounterAlertLevelTargetInfo TargetInfo; // 0x48 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<AActor*> TargetActor; // 0x4c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagQuery TargetEncounterQuery; // 0x58 (Size: 0x48, Type: StructProperty)
    uint8_t TargetBehavior; // 0xa0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a1[0x7]; // 0xa1 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0xa8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FLWMEncounterSetAlertLevelStateTreeTaskInstanceData) == 0xb0, "Size mismatch for FLWMEncounterSetAlertLevelStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterSetAlertLevelStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterSetAlertLevelStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterSetAlertLevelStateTreeTaskInstanceData, TargetInfo) == 0x48, "Offset mismatch for FLWMEncounterSetAlertLevelStateTreeTaskInstanceData::TargetInfo");
static_assert(offsetof(FLWMEncounterSetAlertLevelStateTreeTaskInstanceData, TargetActor) == 0x4c, "Offset mismatch for FLWMEncounterSetAlertLevelStateTreeTaskInstanceData::TargetActor");
static_assert(offsetof(FLWMEncounterSetAlertLevelStateTreeTaskInstanceData, TargetEncounterQuery) == 0x58, "Offset mismatch for FLWMEncounterSetAlertLevelStateTreeTaskInstanceData::TargetEncounterQuery");
static_assert(offsetof(FLWMEncounterSetAlertLevelStateTreeTaskInstanceData, TargetBehavior) == 0xa0, "Offset mismatch for FLWMEncounterSetAlertLevelStateTreeTaskInstanceData::TargetBehavior");
static_assert(offsetof(FLWMEncounterSetAlertLevelStateTreeTaskInstanceData, UserActor) == 0xa8, "Offset mismatch for FLWMEncounterSetAlertLevelStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FLWMEncounterSetAlertLevelStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FLWMEncounterSetAlertLevelStateTreeTask) == 0x20, "Size mismatch for FLWMEncounterSetAlertLevelStateTreeTask");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FLWMEncounterSetStageStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    int32_t StageIndex; // 0x48 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FLWMEncounterSetStageStateTreeTaskInstanceData) == 0x58, "Size mismatch for FLWMEncounterSetStageStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterSetStageStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterSetStageStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterSetStageStateTreeTaskInstanceData, StageIndex) == 0x48, "Offset mismatch for FLWMEncounterSetStageStateTreeTaskInstanceData::StageIndex");
static_assert(offsetof(FLWMEncounterSetStageStateTreeTaskInstanceData, UserActor) == 0x50, "Offset mismatch for FLWMEncounterSetStageStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FLWMEncounterSetStageStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FLWMEncounterSetStageStateTreeTask) == 0x20, "Size mismatch for FLWMEncounterSetStageStateTreeTask");

// Size: 0x188 (Inherited: 0x160, Single: 0x28)
struct FLWMEncounterStartStateTreeTaskInstanceData : FLWMEncounterStartSharedStateTreeTaskInstanceData
{
    TSoftObjectPtr<UFortAthenaLivingWorldEncounter*> LWMEncounter; // 0x160 (Size: 0x20, Type: SoftObjectProperty)
    TWeakObjectPtr<ULWMEncounterInstance*> EncounterInstance; // 0x180 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FLWMEncounterStartStateTreeTaskInstanceData) == 0x188, "Size mismatch for FLWMEncounterStartStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterStartStateTreeTaskInstanceData, LWMEncounter) == 0x160, "Offset mismatch for FLWMEncounterStartStateTreeTaskInstanceData::LWMEncounter");
static_assert(offsetof(FLWMEncounterStartStateTreeTaskInstanceData, EncounterInstance) == 0x180, "Offset mismatch for FLWMEncounterStartStateTreeTaskInstanceData::EncounterInstance");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FLWMEncounterStartStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FLWMEncounterStartStateTreeTask) == 0x20, "Size mismatch for FLWMEncounterStartStateTreeTask");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FLWMEncounterStopStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor; // 0x48 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FLWMEncounterStopStateTreeTaskInstanceData) == 0x50, "Size mismatch for FLWMEncounterStopStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterStopStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterStopStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterStopStateTreeTaskInstanceData, UserActor) == 0x48, "Offset mismatch for FLWMEncounterStopStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FLWMEncounterStopStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FLWMEncounterStopStateTreeTask) == 0x20, "Size mismatch for FLWMEncounterStopStateTreeTask");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FUpdateLeashAlertLevelOverrideEntry
{
    uint8_t AlertLevel; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FScalableFloat LeashRadiusInner; // 0x8 (Size: 0x28, Type: StructProperty)
    FScalableFloat LeashRadiusOuter; // 0x30 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FUpdateLeashAlertLevelOverrideEntry) == 0x58, "Size mismatch for FUpdateLeashAlertLevelOverrideEntry");
static_assert(offsetof(FUpdateLeashAlertLevelOverrideEntry, AlertLevel) == 0x0, "Offset mismatch for FUpdateLeashAlertLevelOverrideEntry::AlertLevel");
static_assert(offsetof(FUpdateLeashAlertLevelOverrideEntry, LeashRadiusInner) == 0x8, "Offset mismatch for FUpdateLeashAlertLevelOverrideEntry::LeashRadiusInner");
static_assert(offsetof(FUpdateLeashAlertLevelOverrideEntry, LeashRadiusOuter) == 0x30, "Offset mismatch for FUpdateLeashAlertLevelOverrideEntry::LeashRadiusOuter");

// Size: 0x108 (Inherited: 0x0, Single: 0x108)
struct FLWMEncounterUpdateLeashStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* TargetActor; // 0x48 (Size: 0x8, Type: ObjectProperty)
    bool bOverrideAnchorPosition; // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bUseVolumeAsAnchor; // 0x51 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_52[0x6]; // 0x52 (Size: 0x6, Type: PaddingProperty)
    FGameplayTagQuery AnchorPointTagQuery; // 0x58 (Size: 0x48, Type: StructProperty)
    FScalableFloat LeashRadiusInner; // 0xa0 (Size: 0x28, Type: StructProperty)
    FScalableFloat LeashRadiusOuter; // 0xc8 (Size: 0x28, Type: StructProperty)
    TArray<FUpdateLeashAlertLevelOverrideEntry> AlertLevelOverrides; // 0xf0 (Size: 0x10, Type: ArrayProperty)
    AActor* UserActor; // 0x100 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FLWMEncounterUpdateLeashStateTreeTaskInstanceData) == 0x108, "Size mismatch for FLWMEncounterUpdateLeashStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterUpdateLeashStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterUpdateLeashStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterUpdateLeashStateTreeTaskInstanceData, TargetActor) == 0x48, "Offset mismatch for FLWMEncounterUpdateLeashStateTreeTaskInstanceData::TargetActor");
static_assert(offsetof(FLWMEncounterUpdateLeashStateTreeTaskInstanceData, bOverrideAnchorPosition) == 0x50, "Offset mismatch for FLWMEncounterUpdateLeashStateTreeTaskInstanceData::bOverrideAnchorPosition");
static_assert(offsetof(FLWMEncounterUpdateLeashStateTreeTaskInstanceData, bUseVolumeAsAnchor) == 0x51, "Offset mismatch for FLWMEncounterUpdateLeashStateTreeTaskInstanceData::bUseVolumeAsAnchor");
static_assert(offsetof(FLWMEncounterUpdateLeashStateTreeTaskInstanceData, AnchorPointTagQuery) == 0x58, "Offset mismatch for FLWMEncounterUpdateLeashStateTreeTaskInstanceData::AnchorPointTagQuery");
static_assert(offsetof(FLWMEncounterUpdateLeashStateTreeTaskInstanceData, LeashRadiusInner) == 0xa0, "Offset mismatch for FLWMEncounterUpdateLeashStateTreeTaskInstanceData::LeashRadiusInner");
static_assert(offsetof(FLWMEncounterUpdateLeashStateTreeTaskInstanceData, LeashRadiusOuter) == 0xc8, "Offset mismatch for FLWMEncounterUpdateLeashStateTreeTaskInstanceData::LeashRadiusOuter");
static_assert(offsetof(FLWMEncounterUpdateLeashStateTreeTaskInstanceData, AlertLevelOverrides) == 0xf0, "Offset mismatch for FLWMEncounterUpdateLeashStateTreeTaskInstanceData::AlertLevelOverrides");
static_assert(offsetof(FLWMEncounterUpdateLeashStateTreeTaskInstanceData, UserActor) == 0x100, "Offset mismatch for FLWMEncounterUpdateLeashStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FLWMEncounterUpdateLeashStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FLWMEncounterUpdateLeashStateTreeTask) == 0x20, "Size mismatch for FLWMEncounterUpdateLeashStateTreeTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FOverrideAIBehaviorStateTreeTaskInstanceData
{
    TWeakObjectPtr<AActor*> TargetActor; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    int32_t BehaviorControl; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FOverrideAIBehaviorStateTreeTaskInstanceData) == 0x18, "Size mismatch for FOverrideAIBehaviorStateTreeTaskInstanceData");
static_assert(offsetof(FOverrideAIBehaviorStateTreeTaskInstanceData, TargetActor) == 0x0, "Offset mismatch for FOverrideAIBehaviorStateTreeTaskInstanceData::TargetActor");
static_assert(offsetof(FOverrideAIBehaviorStateTreeTaskInstanceData, BehaviorControl) == 0x8, "Offset mismatch for FOverrideAIBehaviorStateTreeTaskInstanceData::BehaviorControl");
static_assert(offsetof(FOverrideAIBehaviorStateTreeTaskInstanceData, UserActor) == 0x10, "Offset mismatch for FOverrideAIBehaviorStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FOverrideAIBehaviorStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FOverrideAIBehaviorStateTreeTask) == 0x20, "Size mismatch for FOverrideAIBehaviorStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPauseMobEncounterStateTreeTaskInstanceData
{
    FGameplayTag MobIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FPauseMobEncounterStateTreeTaskInstanceData) == 0x10, "Size mismatch for FPauseMobEncounterStateTreeTaskInstanceData");
static_assert(offsetof(FPauseMobEncounterStateTreeTaskInstanceData, MobIdentifier) == 0x0, "Offset mismatch for FPauseMobEncounterStateTreeTaskInstanceData::MobIdentifier");
static_assert(offsetof(FPauseMobEncounterStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FPauseMobEncounterStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FPauseMobEncounterStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FPauseMobEncounterStateTreeTask) == 0x20, "Size mismatch for FPauseMobEncounterStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRemoveEncounterPrefabTagStateTreeTaskInstanceData
{
    FGameplayTag PrefabTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FRemoveEncounterPrefabTagStateTreeTaskInstanceData) == 0x10, "Size mismatch for FRemoveEncounterPrefabTagStateTreeTaskInstanceData");
static_assert(offsetof(FRemoveEncounterPrefabTagStateTreeTaskInstanceData, PrefabTag) == 0x0, "Offset mismatch for FRemoveEncounterPrefabTagStateTreeTaskInstanceData::PrefabTag");
static_assert(offsetof(FRemoveEncounterPrefabTagStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FRemoveEncounterPrefabTagStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FRemoveEncounterPrefabTagStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FRemoveEncounterPrefabTagStateTreeTask) == 0x20, "Size mismatch for FRemoveEncounterPrefabTagStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FResumeMobEncounterStateTreeTaskInstanceData
{
    FGameplayTag MobIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FResumeMobEncounterStateTreeTaskInstanceData) == 0x10, "Size mismatch for FResumeMobEncounterStateTreeTaskInstanceData");
static_assert(offsetof(FResumeMobEncounterStateTreeTaskInstanceData, MobIdentifier) == 0x0, "Offset mismatch for FResumeMobEncounterStateTreeTaskInstanceData::MobIdentifier");
static_assert(offsetof(FResumeMobEncounterStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FResumeMobEncounterStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FResumeMobEncounterStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FResumeMobEncounterStateTreeTask) == 0x20, "Size mismatch for FResumeMobEncounterStateTreeTask");

// Size: 0x150 (Inherited: 0x0, Single: 0x150)
struct FSpawnActorStateTreeTaskInstanceData
{
    TSoftClassPtr ActorClass; // 0x0 (Size: 0x20, Type: SoftClassProperty)
    bool bUseActorLocation; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x3]; // 0x21 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> TargetActor; // 0x24 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    FGameplayTagQuery AnchorQuery; // 0x30 (Size: 0x48, Type: StructProperty)
    FVector AnchorOffset; // 0x78 (Size: 0x18, Type: StructProperty)
    bool bEnablePhysics; // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bAttachEncounterVolume; // 0x91 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_92[0x6]; // 0x92 (Size: 0x6, Type: PaddingProperty)
    FGameplayTagContainer ActorTags; // 0x98 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ActorIdentifierTags; // 0xb8 (Size: 0x20, Type: StructProperty)
    uint8_t PersistenceBehavior; // 0xd8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d9[0x7]; // 0xd9 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagQuery ExistingActorQuery; // 0xe0 (Size: 0x48, Type: StructProperty)
    bool bWaitForSpawnedActor; // 0x128 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_129[0x3]; // 0x129 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> SpawnedActor; // 0x12c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_134[0x4]; // 0x134 (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x138 (Size: 0x8, Type: ObjectProperty)
    USpawnActorTaskHelper* SpawnActorHelper; // 0x140 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_148[0x8]; // 0x148 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FSpawnActorStateTreeTaskInstanceData) == 0x150, "Size mismatch for FSpawnActorStateTreeTaskInstanceData");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, ActorClass) == 0x0, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::ActorClass");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, bUseActorLocation) == 0x20, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::bUseActorLocation");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, TargetActor) == 0x24, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::TargetActor");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, AnchorQuery) == 0x30, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::AnchorQuery");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, AnchorOffset) == 0x78, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::AnchorOffset");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, bEnablePhysics) == 0x90, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::bEnablePhysics");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, bAttachEncounterVolume) == 0x91, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::bAttachEncounterVolume");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, ActorTags) == 0x98, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::ActorTags");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, ActorIdentifierTags) == 0xb8, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::ActorIdentifierTags");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, PersistenceBehavior) == 0xd8, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::PersistenceBehavior");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, ExistingActorQuery) == 0xe0, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::ExistingActorQuery");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, bWaitForSpawnedActor) == 0x128, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::bWaitForSpawnedActor");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, SpawnedActor) == 0x12c, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::SpawnedActor");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, UserActor) == 0x138, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::UserActor");
static_assert(offsetof(FSpawnActorStateTreeTaskInstanceData, SpawnActorHelper) == 0x140, "Offset mismatch for FSpawnActorStateTreeTaskInstanceData::SpawnActorHelper");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FSpawnActorStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FSpawnActorStateTreeTask) == 0x20, "Size mismatch for FSpawnActorStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FStartMobEncounterStateTreeTaskInstanceData
{
    FGameplayTag MobIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FStartMobEncounterStateTreeTaskInstanceData) == 0x10, "Size mismatch for FStartMobEncounterStateTreeTaskInstanceData");
static_assert(offsetof(FStartMobEncounterStateTreeTaskInstanceData, MobIdentifier) == 0x0, "Offset mismatch for FStartMobEncounterStateTreeTaskInstanceData::MobIdentifier");
static_assert(offsetof(FStartMobEncounterStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FStartMobEncounterStateTreeTaskInstanceData::UserActor");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
struct FStartMobEncounterStateTreeTask : FFortStateTreeEncounterTaskBase
{
    bool bStopEncounterOnExit; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FStartMobEncounterStateTreeTask) == 0x28, "Size mismatch for FStartMobEncounterStateTreeTask");
static_assert(offsetof(FStartMobEncounterStateTreeTask, bStopEncounterOnExit) == 0x20, "Offset mismatch for FStartMobEncounterStateTreeTask::bStopEncounterOnExit");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FStopMobEncounterStateTreeTaskInstanceData
{
    FGameplayTag MobIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FStopMobEncounterStateTreeTaskInstanceData) == 0x10, "Size mismatch for FStopMobEncounterStateTreeTaskInstanceData");
static_assert(offsetof(FStopMobEncounterStateTreeTaskInstanceData, MobIdentifier) == 0x0, "Offset mismatch for FStopMobEncounterStateTreeTaskInstanceData::MobIdentifier");
static_assert(offsetof(FStopMobEncounterStateTreeTaskInstanceData, UserActor) == 0x8, "Offset mismatch for FStopMobEncounterStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FStopMobEncounterStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FStopMobEncounterStateTreeTask) == 0x20, "Size mismatch for FStopMobEncounterStateTreeTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FToggleStateActorStateTreeTaskInstanceData
{
    AActor* TargetActor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bToggleOn; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FToggleStateActorStateTreeTaskInstanceData) == 0x18, "Size mismatch for FToggleStateActorStateTreeTaskInstanceData");
static_assert(offsetof(FToggleStateActorStateTreeTaskInstanceData, TargetActor) == 0x0, "Offset mismatch for FToggleStateActorStateTreeTaskInstanceData::TargetActor");
static_assert(offsetof(FToggleStateActorStateTreeTaskInstanceData, bToggleOn) == 0x8, "Offset mismatch for FToggleStateActorStateTreeTaskInstanceData::bToggleOn");
static_assert(offsetof(FToggleStateActorStateTreeTaskInstanceData, UserActor) == 0x10, "Offset mismatch for FToggleStateActorStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FToggleStateActorStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FToggleStateActorStateTreeTask) == 0x20, "Size mismatch for FToggleStateActorStateTreeTask");

// Size: 0x68 (Inherited: 0x50, Single: 0x18)
struct FVariableSelectionsRow_Faction : FVariableSelectionsRow
{
    FDataRegistryOrTableRow RowValue; // 0x48 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FVariableSelectionsRow_Faction) == 0x68, "Size mismatch for FVariableSelectionsRow_Faction");
static_assert(offsetof(FVariableSelectionsRow_Faction, RowValue) == 0x48, "Offset mismatch for FVariableSelectionsRow_Faction::RowValue");

// Size: 0x68 (Inherited: 0x50, Single: 0x18)
struct FVariableSelectionsRow_QuestDefinition : FVariableSelectionsRow
{
    FDataRegistryOrTableRow RowValue; // 0x48 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FVariableSelectionsRow_QuestDefinition) == 0x68, "Size mismatch for FVariableSelectionsRow_QuestDefinition");
static_assert(offsetof(FVariableSelectionsRow_QuestDefinition, RowValue) == 0x48, "Offset mismatch for FVariableSelectionsRow_QuestDefinition::RowValue");

// Size: 0x90 (Inherited: 0x60, Single: 0x30)
struct FVariableSelections_Faction : FVariableSelections
{
    FSoftDataRegistryOrTable ValueChoiceTable; // 0x60 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FVariableSelections_Faction) == 0x90, "Size mismatch for FVariableSelections_Faction");
static_assert(offsetof(FVariableSelections_Faction, ValueChoiceTable) == 0x60, "Offset mismatch for FVariableSelections_Faction::ValueChoiceTable");

// Size: 0x90 (Inherited: 0x60, Single: 0x30)
struct FVariableSelections_QuestDefinition : FVariableSelections
{
    FSoftDataRegistryOrTable ValueChoiceTable; // 0x60 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FVariableSelections_QuestDefinition) == 0x90, "Size mismatch for FVariableSelections_QuestDefinition");
static_assert(offsetof(FVariableSelections_QuestDefinition, ValueChoiceTable) == 0x60, "Offset mismatch for FVariableSelections_QuestDefinition::ValueChoiceTable");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FVariable_Faction : FVariable
{
    FDataTableRowHandle RowValue; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FVariable_Faction) == 0x20, "Size mismatch for FVariable_Faction");
static_assert(offsetof(FVariable_Faction, RowValue) == 0x10, "Offset mismatch for FVariable_Faction::RowValue");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FVariable_QuestDefinition : FVariable
{
    FDataTableRowHandle RowValue; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FVariable_QuestDefinition) == 0x20, "Size mismatch for FVariable_QuestDefinition");
static_assert(offsetof(FVariable_QuestDefinition, RowValue) == 0x10, "Offset mismatch for FVariable_QuestDefinition::RowValue");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FVarRow_Faction : FVarRow
{
    UEncounterFactionData* Value; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVarRow_Faction) == 0x10, "Size mismatch for FVarRow_Faction");
static_assert(offsetof(FVarRow_Faction, Value) == 0x8, "Offset mismatch for FVarRow_Faction::Value");

// Size: 0x28 (Inherited: 0x10, Single: 0x18)
struct FVarRow_QuestDefinition : FVarRow
{
    TSoftObjectPtr<UFortQuestItemDefinition*> Value; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FVarRow_QuestDefinition) == 0x28, "Size mismatch for FVarRow_QuestDefinition");
static_assert(offsetof(FVarRow_QuestDefinition, Value) == 0x8, "Offset mismatch for FVarRow_QuestDefinition::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEncounterFactionEnemy
{
    UEncounterFactionData* FactionData; // 0x0 (Size: 0x8, Type: ObjectProperty)
    float Weight; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FEncounterFactionEnemy) == 0x10, "Size mismatch for FEncounterFactionEnemy");
static_assert(offsetof(FEncounterFactionEnemy, FactionData) == 0x0, "Offset mismatch for FEncounterFactionEnemy::FactionData");
static_assert(offsetof(FEncounterFactionEnemy, Weight) == 0x8, "Offset mismatch for FEncounterFactionEnemy::Weight");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FEncounterLootEntry
{
    bool bUseLootSelectionTable; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FName LootTierName; // 0x4 (Size: 0x4, Type: NameProperty)
    FVariableSelections_String LootTierSelection; // 0x8 (Size: 0x90, Type: StructProperty)
};

static_assert(sizeof(FEncounterLootEntry) == 0x98, "Size mismatch for FEncounterLootEntry");
static_assert(offsetof(FEncounterLootEntry, bUseLootSelectionTable) == 0x0, "Offset mismatch for FEncounterLootEntry::bUseLootSelectionTable");
static_assert(offsetof(FEncounterLootEntry, LootTierName) == 0x4, "Offset mismatch for FEncounterLootEntry::LootTierName");
static_assert(offsetof(FEncounterLootEntry, LootTierSelection) == 0x8, "Offset mismatch for FEncounterLootEntry::LootTierSelection");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FEncounterRewardBehavior
{
    FVector RewardOffset; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector RewardDirection; // 0x18 (Size: 0x18, Type: StructProperty)
    FScalableFloat RewardConeAngle; // 0x30 (Size: 0x28, Type: StructProperty)
    FScalableFloat RewardFlingMagnitude; // 0x58 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FEncounterRewardBehavior) == 0x80, "Size mismatch for FEncounterRewardBehavior");
static_assert(offsetof(FEncounterRewardBehavior, RewardOffset) == 0x0, "Offset mismatch for FEncounterRewardBehavior::RewardOffset");
static_assert(offsetof(FEncounterRewardBehavior, RewardDirection) == 0x18, "Offset mismatch for FEncounterRewardBehavior::RewardDirection");
static_assert(offsetof(FEncounterRewardBehavior, RewardConeAngle) == 0x30, "Offset mismatch for FEncounterRewardBehavior::RewardConeAngle");
static_assert(offsetof(FEncounterRewardBehavior, RewardFlingMagnitude) == 0x58, "Offset mismatch for FEncounterRewardBehavior::RewardFlingMagnitude");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FActorIdentifierEntry
{
    FGameplayTagContainer IdentifierTags; // 0x0 (Size: 0x20, Type: StructProperty)
    TWeakObjectPtr<AActor*> TargetActor; // 0x20 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FActorIdentifierEntry) == 0x28, "Size mismatch for FActorIdentifierEntry");
static_assert(offsetof(FActorIdentifierEntry, IdentifierTags) == 0x0, "Offset mismatch for FActorIdentifierEntry::IdentifierTags");
static_assert(offsetof(FActorIdentifierEntry, TargetActor) == 0x20, "Offset mismatch for FActorIdentifierEntry::TargetActor");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FLWMEncounterInfo
{
    ULWMEncounterInstance* LWMEncounter; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x20]; // 0x8 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterInfo) == 0x28, "Size mismatch for FLWMEncounterInfo");
static_assert(offsetof(FLWMEncounterInfo, LWMEncounter) == 0x0, "Offset mismatch for FLWMEncounterInfo::LWMEncounter");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameplayEffectIdentifierInfo
{
};

static_assert(sizeof(FGameplayEffectIdentifierInfo) == 0x28, "Size mismatch for FGameplayEffectIdentifierInfo");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FEncounterGroupEffectInfo
{
};

static_assert(sizeof(FEncounterGroupEffectInfo) == 0x50, "Size mismatch for FEncounterGroupEffectInfo");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FTrackedActorInfo
{
    TWeakObjectPtr<AActor*> TrackedActor; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_8[0x30]; // 0x8 (Size: 0x30, Type: PaddingProperty)
};

static_assert(sizeof(FTrackedActorInfo) == 0x38, "Size mismatch for FTrackedActorInfo");
static_assert(offsetof(FTrackedActorInfo, TrackedActor) == 0x0, "Offset mismatch for FTrackedActorInfo::TrackedActor");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FEncounterPrefabInfo
{
    UEncounterItemDefinition* EncounterDefinition; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag EncounterIdentifierTag; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FScalableFloat Weight; // 0x10 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FEncounterPrefabInfo) == 0x38, "Size mismatch for FEncounterPrefabInfo");
static_assert(offsetof(FEncounterPrefabInfo, EncounterDefinition) == 0x0, "Offset mismatch for FEncounterPrefabInfo::EncounterDefinition");
static_assert(offsetof(FEncounterPrefabInfo, EncounterIdentifierTag) == 0x8, "Offset mismatch for FEncounterPrefabInfo::EncounterIdentifierTag");
static_assert(offsetof(FEncounterPrefabInfo, Weight) == 0x10, "Offset mismatch for FEncounterPrefabInfo::Weight");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FActorRemainingCountTransitionStateTreeTaskInstanceData
{
    FGameplayTagQuery ActorIdentifierQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    uint32_t Value; // 0x48 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
    bool bOnlyTriggerOnce; // 0x58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
    FEncounterCustomVerbData CustomVerb; // 0x60 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition; // 0x88 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0x3]; // 0x89 (Size: 0x3, Type: PaddingProperty)
    int32_t RemainingCount; // 0x8c (Size: 0x4, Type: IntProperty)
    uint8_t Pad_90[0x10]; // 0x90 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FActorRemainingCountTransitionStateTreeTaskInstanceData) == 0xa0, "Size mismatch for FActorRemainingCountTransitionStateTreeTaskInstanceData");
static_assert(offsetof(FActorRemainingCountTransitionStateTreeTaskInstanceData, ActorIdentifierQuery) == 0x0, "Offset mismatch for FActorRemainingCountTransitionStateTreeTaskInstanceData::ActorIdentifierQuery");
static_assert(offsetof(FActorRemainingCountTransitionStateTreeTaskInstanceData, Value) == 0x48, "Offset mismatch for FActorRemainingCountTransitionStateTreeTaskInstanceData::Value");
static_assert(offsetof(FActorRemainingCountTransitionStateTreeTaskInstanceData, UserActor) == 0x50, "Offset mismatch for FActorRemainingCountTransitionStateTreeTaskInstanceData::UserActor");
static_assert(offsetof(FActorRemainingCountTransitionStateTreeTaskInstanceData, bOnlyTriggerOnce) == 0x58, "Offset mismatch for FActorRemainingCountTransitionStateTreeTaskInstanceData::bOnlyTriggerOnce");
static_assert(offsetof(FActorRemainingCountTransitionStateTreeTaskInstanceData, CustomVerb) == 0x60, "Offset mismatch for FActorRemainingCountTransitionStateTreeTaskInstanceData::CustomVerb");
static_assert(offsetof(FActorRemainingCountTransitionStateTreeTaskInstanceData, bShouldTransition) == 0x88, "Offset mismatch for FActorRemainingCountTransitionStateTreeTaskInstanceData::bShouldTransition");
static_assert(offsetof(FActorRemainingCountTransitionStateTreeTaskInstanceData, RemainingCount) == 0x8c, "Offset mismatch for FActorRemainingCountTransitionStateTreeTaskInstanceData::RemainingCount");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FEncounterCustomVerbData
{
    FGameplayTag CustomVerbTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint32_t Amount; // 0x4 (Size: 0x4, Type: UInt32Property)
    TArray<FFEncounterCustomVerbSubject> Subjects; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FFEncounterCustomVerbValue> Values; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FEncounterCustomVerbData) == 0x28, "Size mismatch for FEncounterCustomVerbData");
static_assert(offsetof(FEncounterCustomVerbData, CustomVerbTag) == 0x0, "Offset mismatch for FEncounterCustomVerbData::CustomVerbTag");
static_assert(offsetof(FEncounterCustomVerbData, Amount) == 0x4, "Offset mismatch for FEncounterCustomVerbData::Amount");
static_assert(offsetof(FEncounterCustomVerbData, Subjects) == 0x8, "Offset mismatch for FEncounterCustomVerbData::Subjects");
static_assert(offsetof(FEncounterCustomVerbData, Values) == 0x18, "Offset mismatch for FEncounterCustomVerbData::Values");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFEncounterCustomVerbValue
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    double Value; // 0x8 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FFEncounterCustomVerbValue) == 0x10, "Size mismatch for FFEncounterCustomVerbValue");
static_assert(offsetof(FFEncounterCustomVerbValue, Name) == 0x0, "Offset mismatch for FFEncounterCustomVerbValue::Name");
static_assert(offsetof(FFEncounterCustomVerbValue, Value) == 0x8, "Offset mismatch for FFEncounterCustomVerbValue::Value");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FFEncounterCustomVerbSubject
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    AActor* Actor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AdditionalTags; // 0x10 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FFEncounterCustomVerbSubject) == 0x30, "Size mismatch for FFEncounterCustomVerbSubject");
static_assert(offsetof(FFEncounterCustomVerbSubject, Name) == 0x0, "Offset mismatch for FFEncounterCustomVerbSubject::Name");
static_assert(offsetof(FFEncounterCustomVerbSubject, Actor) == 0x8, "Offset mismatch for FFEncounterCustomVerbSubject::Actor");
static_assert(offsetof(FFEncounterCustomVerbSubject, AdditionalTags) == 0x10, "Offset mismatch for FFEncounterCustomVerbSubject::AdditionalTags");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
struct FActorRemainingCountTransitionStateTreeTask : FFortStateTreeEncounterTaskBase
{
    FStateTreeStateLink TransitionTo; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FActorRemainingCountTransitionStateTreeTask) == 0x28, "Size mismatch for FActorRemainingCountTransitionStateTreeTask");
static_assert(offsetof(FActorRemainingCountTransitionStateTreeTask, TransitionTo) == 0x20, "Offset mismatch for FActorRemainingCountTransitionStateTreeTask::TransitionTo");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FEncounterPlayerCountTransitionStateTreeTaskInstanceData
{
    uint8_t ComparisonOperator; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t Value; // 0x4 (Size: 0x4, Type: IntProperty)
    FEncounterCustomVerbData CustomVerb; // 0x8 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bOnlyTriggerOnce; // 0x31 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x6]; // 0x32 (Size: 0x6, Type: PaddingProperty)
    AActor* UserActor; // 0x38 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_40[0x10]; // 0x40 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FEncounterPlayerCountTransitionStateTreeTaskInstanceData) == 0x50, "Size mismatch for FEncounterPlayerCountTransitionStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterPlayerCountTransitionStateTreeTaskInstanceData, ComparisonOperator) == 0x0, "Offset mismatch for FEncounterPlayerCountTransitionStateTreeTaskInstanceData::ComparisonOperator");
static_assert(offsetof(FEncounterPlayerCountTransitionStateTreeTaskInstanceData, Value) == 0x4, "Offset mismatch for FEncounterPlayerCountTransitionStateTreeTaskInstanceData::Value");
static_assert(offsetof(FEncounterPlayerCountTransitionStateTreeTaskInstanceData, CustomVerb) == 0x8, "Offset mismatch for FEncounterPlayerCountTransitionStateTreeTaskInstanceData::CustomVerb");
static_assert(offsetof(FEncounterPlayerCountTransitionStateTreeTaskInstanceData, bShouldTransition) == 0x30, "Offset mismatch for FEncounterPlayerCountTransitionStateTreeTaskInstanceData::bShouldTransition");
static_assert(offsetof(FEncounterPlayerCountTransitionStateTreeTaskInstanceData, bOnlyTriggerOnce) == 0x31, "Offset mismatch for FEncounterPlayerCountTransitionStateTreeTaskInstanceData::bOnlyTriggerOnce");
static_assert(offsetof(FEncounterPlayerCountTransitionStateTreeTaskInstanceData, UserActor) == 0x38, "Offset mismatch for FEncounterPlayerCountTransitionStateTreeTaskInstanceData::UserActor");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
struct FEncounterPlayerCountTransitionStateTreeTask : FFortStateTreeEncounterTaskBase
{
    FStateTreeStateLink TransitionTo; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FEncounterPlayerCountTransitionStateTreeTask) == 0x28, "Size mismatch for FEncounterPlayerCountTransitionStateTreeTask");
static_assert(offsetof(FEncounterPlayerCountTransitionStateTreeTask, TransitionTo) == 0x20, "Offset mismatch for FEncounterPlayerCountTransitionStateTreeTask::TransitionTo");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FEncounterSendCustomVerbStateTreeTaskInstanceData
{
    FEncounterCustomVerbData CustomVerb; // 0x0 (Size: 0x28, Type: StructProperty)
    bool bSendVerbForEachPlayerAuthor; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEncounterSendCustomVerbStateTreeTaskInstanceData) == 0x38, "Size mismatch for FEncounterSendCustomVerbStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterSendCustomVerbStateTreeTaskInstanceData, CustomVerb) == 0x0, "Offset mismatch for FEncounterSendCustomVerbStateTreeTaskInstanceData::CustomVerb");
static_assert(offsetof(FEncounterSendCustomVerbStateTreeTaskInstanceData, bSendVerbForEachPlayerAuthor) == 0x28, "Offset mismatch for FEncounterSendCustomVerbStateTreeTaskInstanceData::bSendVerbForEachPlayerAuthor");
static_assert(offsetof(FEncounterSendCustomVerbStateTreeTaskInstanceData, UserActor) == 0x30, "Offset mismatch for FEncounterSendCustomVerbStateTreeTaskInstanceData::UserActor");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FEncounterSendCustomVerbStateTreeTask : FFortStateTreeEncounterTaskBase
{
};

static_assert(sizeof(FEncounterSendCustomVerbStateTreeTask) == 0x20, "Size mismatch for FEncounterSendCustomVerbStateTreeTask");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FEncounterValueConditionEntry
{
    int32_t LeftValue; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t RightValue; // 0x4 (Size: 0x4, Type: IntProperty)
    uint8_t ComparisonOperator; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FEncounterValueConditionEntry) == 0xc, "Size mismatch for FEncounterValueConditionEntry");
static_assert(offsetof(FEncounterValueConditionEntry, LeftValue) == 0x0, "Offset mismatch for FEncounterValueConditionEntry::LeftValue");
static_assert(offsetof(FEncounterValueConditionEntry, RightValue) == 0x4, "Offset mismatch for FEncounterValueConditionEntry::RightValue");
static_assert(offsetof(FEncounterValueConditionEntry, ComparisonOperator) == 0x8, "Offset mismatch for FEncounterValueConditionEntry::ComparisonOperator");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FEncounterValueConditionTransitionStateTreeTaskInstanceData
{
    TArray<FEncounterValueConditionEntry> ValueConditions; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FEncounterCustomVerbData CustomVerb; // 0x10 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition; // 0x38 (Size: 0x1, Type: BoolProperty)
    bool bOnlyTriggerOnce; // 0x39 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3a[0x6]; // 0x3a (Size: 0x6, Type: PaddingProperty)
    AActor* UserActor; // 0x40 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FEncounterValueConditionTransitionStateTreeTaskInstanceData) == 0x50, "Size mismatch for FEncounterValueConditionTransitionStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterValueConditionTransitionStateTreeTaskInstanceData, ValueConditions) == 0x0, "Offset mismatch for FEncounterValueConditionTransitionStateTreeTaskInstanceData::ValueConditions");
static_assert(offsetof(FEncounterValueConditionTransitionStateTreeTaskInstanceData, CustomVerb) == 0x10, "Offset mismatch for FEncounterValueConditionTransitionStateTreeTaskInstanceData::CustomVerb");
static_assert(offsetof(FEncounterValueConditionTransitionStateTreeTaskInstanceData, bShouldTransition) == 0x38, "Offset mismatch for FEncounterValueConditionTransitionStateTreeTaskInstanceData::bShouldTransition");
static_assert(offsetof(FEncounterValueConditionTransitionStateTreeTaskInstanceData, bOnlyTriggerOnce) == 0x39, "Offset mismatch for FEncounterValueConditionTransitionStateTreeTaskInstanceData::bOnlyTriggerOnce");
static_assert(offsetof(FEncounterValueConditionTransitionStateTreeTaskInstanceData, UserActor) == 0x40, "Offset mismatch for FEncounterValueConditionTransitionStateTreeTaskInstanceData::UserActor");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
struct FEncounterValueConditionTransitionStateTreeTask : FFortStateTreeEncounterTaskBase
{
    FStateTreeStateLink TransitionTo; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FEncounterValueConditionTransitionStateTreeTask) == 0x28, "Size mismatch for FEncounterValueConditionTransitionStateTreeTask");
static_assert(offsetof(FEncounterValueConditionTransitionStateTreeTask, TransitionTo) == 0x20, "Offset mismatch for FEncounterValueConditionTransitionStateTreeTask::TransitionTo");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FEncounterVerbTransitionConditionEntry
{
    TArray<FInstancedStruct> ObjectiveVerbs; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t ObjectiveValueThreshold; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x24]; // 0x14 (Size: 0x24, Type: PaddingProperty)
};

static_assert(sizeof(FEncounterVerbTransitionConditionEntry) == 0x38, "Size mismatch for FEncounterVerbTransitionConditionEntry");
static_assert(offsetof(FEncounterVerbTransitionConditionEntry, ObjectiveVerbs) == 0x0, "Offset mismatch for FEncounterVerbTransitionConditionEntry::ObjectiveVerbs");
static_assert(offsetof(FEncounterVerbTransitionConditionEntry, ObjectiveValueThreshold) == 0x10, "Offset mismatch for FEncounterVerbTransitionConditionEntry::ObjectiveValueThreshold");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FEncounterVerbTransitionStateTreeTaskInstanceData
{
    bool bUseAdvancedObjectives; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TArray<FInstancedStruct> ObjectiveVerbs; // 0x8 (Size: 0x10, Type: ArrayProperty)
    int32_t ObjectiveValueThreshold; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    TArray<FEncounterVerbTransitionConditionEntry> Objectives; // 0x20 (Size: 0x10, Type: ArrayProperty)
    AActor* UserActor; // 0x30 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_38[0x28]; // 0x38 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(FEncounterVerbTransitionStateTreeTaskInstanceData) == 0x60, "Size mismatch for FEncounterVerbTransitionStateTreeTaskInstanceData");
static_assert(offsetof(FEncounterVerbTransitionStateTreeTaskInstanceData, bUseAdvancedObjectives) == 0x0, "Offset mismatch for FEncounterVerbTransitionStateTreeTaskInstanceData::bUseAdvancedObjectives");
static_assert(offsetof(FEncounterVerbTransitionStateTreeTaskInstanceData, ObjectiveVerbs) == 0x8, "Offset mismatch for FEncounterVerbTransitionStateTreeTaskInstanceData::ObjectiveVerbs");
static_assert(offsetof(FEncounterVerbTransitionStateTreeTaskInstanceData, ObjectiveValueThreshold) == 0x18, "Offset mismatch for FEncounterVerbTransitionStateTreeTaskInstanceData::ObjectiveValueThreshold");
static_assert(offsetof(FEncounterVerbTransitionStateTreeTaskInstanceData, Objectives) == 0x20, "Offset mismatch for FEncounterVerbTransitionStateTreeTaskInstanceData::Objectives");
static_assert(offsetof(FEncounterVerbTransitionStateTreeTaskInstanceData, UserActor) == 0x30, "Offset mismatch for FEncounterVerbTransitionStateTreeTaskInstanceData::UserActor");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
struct FEncounterVerbTransitionStateTreeTask : FFortStateTreeEncounterTaskBase
{
    FStateTreeStateLink TransitionTo; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FEncounterVerbTransitionStateTreeTask) == 0x28, "Size mismatch for FEncounterVerbTransitionStateTreeTask");
static_assert(offsetof(FEncounterVerbTransitionStateTreeTask, TransitionTo) == 0x20, "Offset mismatch for FEncounterVerbTransitionStateTreeTask::TransitionTo");

// Size: 0xa8 (Inherited: 0x0, Single: 0xa8)
struct FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    TArray<EAlertLevel> AlertLevels; // 0x48 (Size: 0x10, Type: ArrayProperty)
    uint8_t ComparisonOperator; // 0x58 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_59[0x3]; // 0x59 (Size: 0x3, Type: PaddingProperty)
    int32_t Value; // 0x5c (Size: 0x4, Type: IntProperty)
    FEncounterCustomVerbData CustomVerb; // 0x60 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition; // 0x88 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0x7]; // 0x89 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0x90 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_98[0x10]; // 0x98 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData) == 0xa8, "Size mismatch for FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData, AlertLevels) == 0x48, "Offset mismatch for FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData::AlertLevels");
static_assert(offsetof(FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData, ComparisonOperator) == 0x58, "Offset mismatch for FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData::ComparisonOperator");
static_assert(offsetof(FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData, Value) == 0x5c, "Offset mismatch for FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData::Value");
static_assert(offsetof(FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData, CustomVerb) == 0x60, "Offset mismatch for FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData::CustomVerb");
static_assert(offsetof(FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData, bShouldTransition) == 0x88, "Offset mismatch for FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData::bShouldTransition");
static_assert(offsetof(FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData, UserActor) == 0x90, "Offset mismatch for FLWMEncounterAlertLevelTransitionStateTreeTaskInstanceData::UserActor");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
struct FLWMEncounterAlertLevelTransitionStateTreeTask : FFortStateTreeEncounterTaskBase
{
    FStateTreeStateLink TransitionTo; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterAlertLevelTransitionStateTreeTask) == 0x28, "Size mismatch for FLWMEncounterAlertLevelTransitionStateTreeTask");
static_assert(offsetof(FLWMEncounterAlertLevelTransitionStateTreeTask, TransitionTo) == 0x20, "Offset mismatch for FLWMEncounterAlertLevelTransitionStateTreeTask::TransitionTo");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FLWMEncounterKillCountTransitionStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    uint32_t Value; // 0x48 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    FEncounterCustomVerbData CustomVerb; // 0x50 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
    AActor* UserActor; // 0x80 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_88[0x10]; // 0x88 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterKillCountTransitionStateTreeTaskInstanceData) == 0x98, "Size mismatch for FLWMEncounterKillCountTransitionStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterKillCountTransitionStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterKillCountTransitionStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterKillCountTransitionStateTreeTaskInstanceData, Value) == 0x48, "Offset mismatch for FLWMEncounterKillCountTransitionStateTreeTaskInstanceData::Value");
static_assert(offsetof(FLWMEncounterKillCountTransitionStateTreeTaskInstanceData, CustomVerb) == 0x50, "Offset mismatch for FLWMEncounterKillCountTransitionStateTreeTaskInstanceData::CustomVerb");
static_assert(offsetof(FLWMEncounterKillCountTransitionStateTreeTaskInstanceData, bShouldTransition) == 0x78, "Offset mismatch for FLWMEncounterKillCountTransitionStateTreeTaskInstanceData::bShouldTransition");
static_assert(offsetof(FLWMEncounterKillCountTransitionStateTreeTaskInstanceData, UserActor) == 0x80, "Offset mismatch for FLWMEncounterKillCountTransitionStateTreeTaskInstanceData::UserActor");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
struct FLWMEncounterKillCountTransitionStateTreeTask : FFortStateTreeEncounterTaskBase
{
    FStateTreeStateLink TransitionTo; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterKillCountTransitionStateTreeTask) == 0x28, "Size mismatch for FLWMEncounterKillCountTransitionStateTreeTask");
static_assert(offsetof(FLWMEncounterKillCountTransitionStateTreeTask, TransitionTo) == 0x20, "Offset mismatch for FLWMEncounterKillCountTransitionStateTreeTask::TransitionTo");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    int32_t Value; // 0x48 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    AActor* UserActor; // 0x50 (Size: 0x8, Type: ObjectProperty)
    bool bOnlyTriggerOnce; // 0x58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
    FEncounterCustomVerbData CustomVerb; // 0x60 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition; // 0x88 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0xf]; // 0x89 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData) == 0x98, "Size mismatch for FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData, Value) == 0x48, "Offset mismatch for FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData::Value");
static_assert(offsetof(FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData, UserActor) == 0x50, "Offset mismatch for FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData::UserActor");
static_assert(offsetof(FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData, bOnlyTriggerOnce) == 0x58, "Offset mismatch for FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData::bOnlyTriggerOnce");
static_assert(offsetof(FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData, CustomVerb) == 0x60, "Offset mismatch for FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData::CustomVerb");
static_assert(offsetof(FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData, bShouldTransition) == 0x88, "Offset mismatch for FLWMEncounterRemainingCountTransitionStateTreeTaskInstanceData::bShouldTransition");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
struct FLWMEncounterRemainingCountTransitionStateTreeTask : FFortStateTreeEncounterTaskBase
{
    FStateTreeStateLink TransitionTo; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterRemainingCountTransitionStateTreeTask) == 0x28, "Size mismatch for FLWMEncounterRemainingCountTransitionStateTreeTask");
static_assert(offsetof(FLWMEncounterRemainingCountTransitionStateTreeTask, TransitionTo) == 0x20, "Offset mismatch for FLWMEncounterRemainingCountTransitionStateTreeTask::TransitionTo");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData
{
    FGameplayTagQuery EncounterQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    AActor* UserActor; // 0x48 (Size: 0x8, Type: ObjectProperty)
    bool bOnlyTriggerOnce; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
    FEncounterCustomVerbData CustomVerb; // 0x58 (Size: 0x28, Type: StructProperty)
    bool bShouldTransition; // 0x80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_81[0xf]; // 0x81 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData) == 0x90, "Size mismatch for FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData");
static_assert(offsetof(FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData, EncounterQuery) == 0x0, "Offset mismatch for FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData::EncounterQuery");
static_assert(offsetof(FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData, UserActor) == 0x48, "Offset mismatch for FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData::UserActor");
static_assert(offsetof(FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData, bOnlyTriggerOnce) == 0x50, "Offset mismatch for FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData::bOnlyTriggerOnce");
static_assert(offsetof(FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData, CustomVerb) == 0x58, "Offset mismatch for FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData::CustomVerb");
static_assert(offsetof(FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData, bShouldTransition) == 0x80, "Offset mismatch for FLWMEncounterSpawnCompleteTransitionStateTreeTaskInstanceData::bShouldTransition");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
struct FLWMEncounterSpawnCompleteTransitionStateTreeTask : FFortStateTreeEncounterTaskBase
{
    FStateTreeStateLink TransitionTo; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FLWMEncounterSpawnCompleteTransitionStateTreeTask) == 0x28, "Size mismatch for FLWMEncounterSpawnCompleteTransitionStateTreeTask");
static_assert(offsetof(FLWMEncounterSpawnCompleteTransitionStateTreeTask, TransitionTo) == 0x20, "Offset mismatch for FLWMEncounterSpawnCompleteTransitionStateTreeTask::TransitionTo");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData
{
    AActor* UserActor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AActor*> TargetActor; // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    FScalableFloat Radius; // 0x10 (Size: 0x28, Type: StructProperty)
    FNavAgentProperties NavAgentProperties; // 0x38 (Size: 0x30, Type: StructProperty)
    bool bOnlyTriggerOnce; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData) == 0x70, "Size mismatch for FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData");
static_assert(offsetof(FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData, UserActor) == 0x0, "Offset mismatch for FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData::UserActor");
static_assert(offsetof(FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData, TargetActor) == 0x8, "Offset mismatch for FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData::TargetActor");
static_assert(offsetof(FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData, Radius) == 0x10, "Offset mismatch for FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData::Radius");
static_assert(offsetof(FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData, NavAgentProperties) == 0x38, "Offset mismatch for FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData::NavAgentProperties");
static_assert(offsetof(FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData, bOnlyTriggerOnce) == 0x68, "Offset mismatch for FLWMWaitForNavMeshTransitionStateTreeTaskInstanceData::bOnlyTriggerOnce");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
struct FLWMWaitForNavMeshTransitionStateTreeTask : FFortStateTreeEncounterTaskBase
{
    FStateTreeStateLink TransitionTo; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FLWMWaitForNavMeshTransitionStateTreeTask) == 0x28, "Size mismatch for FLWMWaitForNavMeshTransitionStateTreeTask");
static_assert(offsetof(FLWMWaitForNavMeshTransitionStateTreeTask, TransitionTo) == 0x20, "Offset mismatch for FLWMWaitForNavMeshTransitionStateTreeTask::TransitionTo");

// Size: 0x1d0 (Inherited: 0xa0, Single: 0x130)
struct FFortVerbFilter_EncounterCompleted : FObjectiveFilter
{
    FObjectiveSubjectTags EncounterItemDef; // 0xa0 (Size: 0x48, Type: StructProperty)
    uint8_t SuccessState; // 0xe8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_e9[0x7]; // 0xe9 (Size: 0x7, Type: PaddingProperty)
    FObjectiveSubjectTags_Progressible Participants; // 0xf0 (Size: 0x50, Type: StructProperty)
    FObjectiveSubjectTags Faction; // 0x140 (Size: 0x48, Type: StructProperty)
    FObjectiveSubjectTags EncounterVolumeTags; // 0x188 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FFortVerbFilter_EncounterCompleted) == 0x1d0, "Size mismatch for FFortVerbFilter_EncounterCompleted");
static_assert(offsetof(FFortVerbFilter_EncounterCompleted, EncounterItemDef) == 0xa0, "Offset mismatch for FFortVerbFilter_EncounterCompleted::EncounterItemDef");
static_assert(offsetof(FFortVerbFilter_EncounterCompleted, SuccessState) == 0xe8, "Offset mismatch for FFortVerbFilter_EncounterCompleted::SuccessState");
static_assert(offsetof(FFortVerbFilter_EncounterCompleted, Participants) == 0xf0, "Offset mismatch for FFortVerbFilter_EncounterCompleted::Participants");
static_assert(offsetof(FFortVerbFilter_EncounterCompleted, Faction) == 0x140, "Offset mismatch for FFortVerbFilter_EncounterCompleted::Faction");
static_assert(offsetof(FFortVerbFilter_EncounterCompleted, EncounterVolumeTags) == 0x188, "Offset mismatch for FFortVerbFilter_EncounterCompleted::EncounterVolumeTags");

