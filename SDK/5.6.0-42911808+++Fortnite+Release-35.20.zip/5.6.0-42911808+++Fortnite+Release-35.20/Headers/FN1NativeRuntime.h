/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FN1NativeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "FortniteGame.h"

// Size: 0xc0 (Inherited: 0xe0, Single: 0xffffffe0)
class UVerseFortniteBusVolumeComponent : public UActorComponent
{
public:
    AVolume* DropZone; // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UVerseFortniteBusVolumeComponent) == 0xc0, "Size mismatch for UVerseFortniteBusVolumeComponent");
static_assert(offsetof(UVerseFortniteBusVolumeComponent, DropZone) == 0xb8, "Offset mismatch for UVerseFortniteBusVolumeComponent::DropZone");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UVerseFortniteBattlebus : public UObject
{
public:

public:
    void OnAircraftEnteredDropZone(AFortAthenaAircraft*& FortAthenaAircraft); // 0xf1c1348 (Index: 0x0, Flags: Native|Public)
    void OnAircraftExitedDropZone(AFortAthenaAircraft*& FortAthenaAircraft); // 0x11463f50 (Index: 0x1, Flags: Native|Public)
    void OnAircraftFlightEnded(AFortAthenaAircraft*& FortAthenaAircraft); // 0xbff5700 (Index: 0x2, Flags: Native|Public)
};

static_assert(sizeof(UVerseFortniteBattlebus) == 0x28, "Size mismatch for UVerseFortniteBattlebus");

// Size: 0x368 (Inherited: 0xbc0, Single: 0xfffff7a8)
class AFortVerseBusMutator : public AFortAthenaMutator
{
public:
};

static_assert(sizeof(AFortVerseBusMutator) == 0x368, "Size mismatch for AFortVerseBusMutator");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UVerseFortGameMode : public UObject
{
public:

public:
    void HandleAthenaGamePhaseChanged(const FFortGamePhaseUpdatedEvent GamePhaseUpdatedEvent); // 0x11463c74 (Index: 0x0, Flags: Native|Public|HasOutParms)
    void HandleConsumedRemainingTeamLives(AFortPlayerStateAthena*& PlayerState, int32_t& LivesConsumed); // 0x11463d44 (Index: 0x1, Flags: Native|Public)
    void HandlePlayerPawnEliminated(AFortPlayerPawn*& PlayerPawn); // 0xbff5700 (Index: 0x2, Flags: Native|Public)
    void HandlePlayerPawnRespawned(AFortPlayerPawn*& PlayerPawn); // 0x11463f50 (Index: 0x3, Flags: Native|Public)
    void HandleRespawnsDisabled(); // 0x5ba16d4 (Index: 0x4, Flags: Native|Public)
    void HandleRespawnsEnabled(); // 0x31f3198 (Index: 0x5, Flags: Native|Public)
    void HandleTeamLivesChanged(APlayerController*& PlayerController, char& TeamID, int32_t& RemainingLives, int32_t& Change); // 0x11464080 (Index: 0x6, Flags: Native|Public)
    void HandleTeamWon(int32_t& WinningTeamId); // 0x1146443c (Index: 0x7, Flags: Native|Public)
    void HandleTimeUntilRespawnsDisabledUpdated(); // 0xa39d578 (Index: 0x8, Flags: Native|Public)
    void HandleTimeUntilTeamLivesRechargeChanged(APlayerController*& PlayerController, char& TeamID, float& TimeUntilRecharge, float& Change); // 0x11464568 (Index: 0x9, Flags: Native|Public)
};

static_assert(sizeof(UVerseFortGameMode) == 0x28, "Size mismatch for UVerseFortGameMode");

// Size: 0xc8 (Inherited: 0xe0, Single: 0xffffffe8)
class UVerseFortniteStormVolumeComponent : public UActorComponent
{
public:
    TArray<FVFortStormVolume> SafeZoneVolumes; // 0xb8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UVerseFortniteStormVolumeComponent) == 0xc8, "Size mismatch for UVerseFortniteStormVolumeComponent");
static_assert(offsetof(UVerseFortniteStormVolumeComponent, SafeZoneVolumes) == 0xb8, "Offset mismatch for UVerseFortniteStormVolumeComponent::SafeZoneVolumes");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UVerseFortniteStorm : public UObject
{
public:
};

static_assert(sizeof(UVerseFortniteStorm) == 0x28, "Size mismatch for UVerseFortniteStorm");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FVFortStormVolume
{
    AVolume* VolumeActor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    float RejectionChance; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FVFortStormVolume) == 0x10, "Size mismatch for FVFortStormVolume");
static_assert(offsetof(FVFortStormVolume, VolumeActor) == 0x0, "Offset mismatch for FVFortStormVolume::VolumeActor");
static_assert(offsetof(FVFortStormVolume, RejectionChance) == 0x8, "Offset mismatch for FVFortStormVolume::RejectionChance");

