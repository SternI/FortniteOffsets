/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Discovery_BackgroundMaterialsSelectorFunctions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDiscovery_BackgroundMaterialsSelectorFunctions_C : public UBlueprintFunctionLibrary
{
public:

public:
    static void GetTopEdgeMaterial(EFortActivityLinkCategory& LinkCategory, UObject*& __WorldContext, UMaterialInterface*& TopEdgeMaterial); // 0x288a61c (Index: 0x0, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void GetHeaderImageMaterial(EFortActivityLinkCategory& LinkCategory, UObject*& __WorldContext, UMaterialInterface*& HeaderMaterial); // 0x288a61c (Index: 0x1, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void GetFooterMaterial(EFortActivityLinkCategory& LinkCategory, UObject*& __WorldContext, UMaterialInterface*& FooterMaterial); // 0x288a61c (Index: 0x2, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void GetBackgroundMaterial(EFortActivityLinkCategory& LinkCategory, UObject*& __WorldContext, UMaterialInterface*& BackgroundMaterial); // 0x288a61c (Index: 0x3, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
};

static_assert(sizeof(UDiscovery_BackgroundMaterialsSelectorFunctions_C) == 0x28, "Size mismatch for UDiscovery_BackgroundMaterialsSelectorFunctions_C");

