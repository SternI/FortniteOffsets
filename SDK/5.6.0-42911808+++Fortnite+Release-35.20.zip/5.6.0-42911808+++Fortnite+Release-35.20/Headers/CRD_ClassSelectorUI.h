/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_ClassSelectorUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CommonUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "FortniteUI.h"
#include "Engine.h"
#include "SlateCore.h"

// Size: 0x320 (Inherited: 0x730, Single: 0xfffffbf0)
class UClassSelectorLoadoutContainer : public UCommonUserWidget
{
public:
    UWrapBox* WrapBox; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UClass* EntryWidgetClass; // 0x2e0 (Size: 0x8, Type: ClassProperty)
    TArray<UAthenaItemElementWidgetBase*> EntryWidgets; // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    UFortItemDefinition* PreviewItemDef; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    int32_t NumPreviewEntries; // 0x300 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_304[0x1c]; // 0x304 (Size: 0x1c, Type: PaddingProperty)
};

static_assert(sizeof(UClassSelectorLoadoutContainer) == 0x320, "Size mismatch for UClassSelectorLoadoutContainer");
static_assert(offsetof(UClassSelectorLoadoutContainer, WrapBox) == 0x2d8, "Offset mismatch for UClassSelectorLoadoutContainer::WrapBox");
static_assert(offsetof(UClassSelectorLoadoutContainer, EntryWidgetClass) == 0x2e0, "Offset mismatch for UClassSelectorLoadoutContainer::EntryWidgetClass");
static_assert(offsetof(UClassSelectorLoadoutContainer, EntryWidgets) == 0x2e8, "Offset mismatch for UClassSelectorLoadoutContainer::EntryWidgets");
static_assert(offsetof(UClassSelectorLoadoutContainer, PreviewItemDef) == 0x2f8, "Offset mismatch for UClassSelectorLoadoutContainer::PreviewItemDef");
static_assert(offsetof(UClassSelectorLoadoutContainer, NumPreviewEntries) == 0x300, "Offset mismatch for UClassSelectorLoadoutContainer::NumPreviewEntries");

// Size: 0x390 (Inherited: 0x730, Single: 0xfffffc60)
class UClassSelectorTabButtons : public UCommonUserWidget
{
public:
    UCommonActionWidget* LeftActionWidget; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UCommonActionWidget* RightActionWidget; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UScrollBox* TabButtonsScrollBox; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* LeftButton; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* RightButton; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle LeftInputAction; // 0x300 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_310[0x8]; // 0x310 (Size: 0x8, Type: PaddingProperty)
    FDataTableRowHandle RightInputAction; // 0x318 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_328[0x8]; // 0x328 (Size: 0x8, Type: PaddingProperty)
    TArray<UClassSelectorTeamTile*> TabButtons; // 0x330 (Size: 0x10, Type: ArrayProperty)
    UClass* TabButtonClass; // 0x340 (Size: 0x8, Type: ClassProperty)
    FMargin TabButtonPadding; // 0x348 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_358[0x8]; // 0x358 (Size: 0x8, Type: PaddingProperty)
    TArray<FText> DesignerPreviewTabNames; // 0x360 (Size: 0x10, Type: ArrayProperty)
    float ButtonScrollAmount; // 0x370 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_374[0x1c]; // 0x374 (Size: 0x1c, Type: PaddingProperty)
};

static_assert(sizeof(UClassSelectorTabButtons) == 0x390, "Size mismatch for UClassSelectorTabButtons");
static_assert(offsetof(UClassSelectorTabButtons, LeftActionWidget) == 0x2d8, "Offset mismatch for UClassSelectorTabButtons::LeftActionWidget");
static_assert(offsetof(UClassSelectorTabButtons, RightActionWidget) == 0x2e0, "Offset mismatch for UClassSelectorTabButtons::RightActionWidget");
static_assert(offsetof(UClassSelectorTabButtons, TabButtonsScrollBox) == 0x2e8, "Offset mismatch for UClassSelectorTabButtons::TabButtonsScrollBox");
static_assert(offsetof(UClassSelectorTabButtons, LeftButton) == 0x2f0, "Offset mismatch for UClassSelectorTabButtons::LeftButton");
static_assert(offsetof(UClassSelectorTabButtons, RightButton) == 0x2f8, "Offset mismatch for UClassSelectorTabButtons::RightButton");
static_assert(offsetof(UClassSelectorTabButtons, LeftInputAction) == 0x300, "Offset mismatch for UClassSelectorTabButtons::LeftInputAction");
static_assert(offsetof(UClassSelectorTabButtons, RightInputAction) == 0x318, "Offset mismatch for UClassSelectorTabButtons::RightInputAction");
static_assert(offsetof(UClassSelectorTabButtons, TabButtons) == 0x330, "Offset mismatch for UClassSelectorTabButtons::TabButtons");
static_assert(offsetof(UClassSelectorTabButtons, TabButtonClass) == 0x340, "Offset mismatch for UClassSelectorTabButtons::TabButtonClass");
static_assert(offsetof(UClassSelectorTabButtons, TabButtonPadding) == 0x348, "Offset mismatch for UClassSelectorTabButtons::TabButtonPadding");
static_assert(offsetof(UClassSelectorTabButtons, DesignerPreviewTabNames) == 0x360, "Offset mismatch for UClassSelectorTabButtons::DesignerPreviewTabNames");
static_assert(offsetof(UClassSelectorTabButtons, ButtonScrollAmount) == 0x370, "Offset mismatch for UClassSelectorTabButtons::ButtonScrollAmount");

// Size: 0x2c8 (Inherited: 0x458, Single: 0xfffffe70)
class UClassSelectorTeamInfoWidget : public UUserWidget
{
public:
    UCommonTextBlock* TeamName; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* TeamCountText; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* TeamDescription; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UClassSelectorTeamInfoWidget) == 0x2c8, "Size mismatch for UClassSelectorTeamInfoWidget");
static_assert(offsetof(UClassSelectorTeamInfoWidget, TeamName) == 0x2b0, "Offset mismatch for UClassSelectorTeamInfoWidget::TeamName");
static_assert(offsetof(UClassSelectorTeamInfoWidget, TeamCountText) == 0x2b8, "Offset mismatch for UClassSelectorTeamInfoWidget::TeamCountText");
static_assert(offsetof(UClassSelectorTeamInfoWidget, TeamDescription) == 0x2c0, "Offset mismatch for UClassSelectorTeamInfoWidget::TeamDescription");

// Size: 0x1570 (Inherited: 0x30b0, Single: 0xffffe4c0)
class UClassSelectorTeamTile : public UCreativeClassSelectorButton
{
public:
    uint8_t Pad_14e0[0x78]; // 0x14e0 (Size: 0x78, Type: PaddingProperty)
    UTextBlock* PlayerCount; // 0x1558 (Size: 0x8, Type: ObjectProperty)
    UCommonLazyImage* TeamIconImage; // 0x1560 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1568[0x8]; // 0x1568 (Size: 0x8, Type: PaddingProperty)

public:
    virtual void OnPlayerCountSet(int32_t& NewPlayerCount); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void OnTeamColorIndexSet(int32_t& TeamColorIndex); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void OnTeamIconSet(const FCreativeIconOption NewTeamIcon); // 0x288a61c (Index: 0x2, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnTeamSet(const FMinigameTeam NewTeamData); // 0x288a61c (Index: 0x3, Flags: Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UClassSelectorTeamTile) == 0x1570, "Size mismatch for UClassSelectorTeamTile");
static_assert(offsetof(UClassSelectorTeamTile, PlayerCount) == 0x1558, "Offset mismatch for UClassSelectorTeamTile::PlayerCount");
static_assert(offsetof(UClassSelectorTeamTile, TeamIconImage) == 0x1560, "Offset mismatch for UClassSelectorTeamTile::TeamIconImage");

// Size: 0x14e0 (Inherited: 0x1bd0, Single: 0xfffff910)
class UCreativeClassSelectorButton : public UCommonButtonBase
{
public:
    UCommonTextBlock* ButtonTextBlock; // 0x14a0 (Size: 0x8, Type: ObjectProperty)
    UCommonActionWidget* ActionWidget; // 0x14a8 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText; // 0x14b0 (Size: 0x10, Type: TextProperty)
    FDataTableRowHandle buttonInputAction; // 0x14c0 (Size: 0x10, Type: StructProperty)
    bool bAutoCapitalize; // 0x14d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_14d1[0xf]; // 0x14d1 (Size: 0xf, Type: PaddingProperty)

public:
    void SetButtonText(const FText InText); // 0x11a992c0 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UCreativeClassSelectorButton) == 0x14e0, "Size mismatch for UCreativeClassSelectorButton");
static_assert(offsetof(UCreativeClassSelectorButton, ButtonTextBlock) == 0x14a0, "Offset mismatch for UCreativeClassSelectorButton::ButtonTextBlock");
static_assert(offsetof(UCreativeClassSelectorButton, ActionWidget) == 0x14a8, "Offset mismatch for UCreativeClassSelectorButton::ActionWidget");
static_assert(offsetof(UCreativeClassSelectorButton, ButtonText) == 0x14b0, "Offset mismatch for UCreativeClassSelectorButton::ButtonText");
static_assert(offsetof(UCreativeClassSelectorButton, buttonInputAction) == 0x14c0, "Offset mismatch for UCreativeClassSelectorButton::buttonInputAction");
static_assert(offsetof(UCreativeClassSelectorButton, bAutoCapitalize) == 0x14d0, "Offset mismatch for UCreativeClassSelectorButton::bAutoCapitalize");

// Size: 0x320 (Inherited: 0x730, Single: 0xfffffbf0)
class UClassSelectorTeamTiles : public UCommonUserWidget
{
public:
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)
    TArray<UClassSelectorTeamTile*> TeamTiles; // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    UUniformGridPanel* RootPanel; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UClass* EntryClass; // 0x2f8 (Size: 0x8, Type: ClassProperty)
    int32_t DesignerPreviewEntries; // 0x300 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_304[0x1c]; // 0x304 (Size: 0x1c, Type: PaddingProperty)
};

static_assert(sizeof(UClassSelectorTeamTiles) == 0x320, "Size mismatch for UClassSelectorTeamTiles");
static_assert(offsetof(UClassSelectorTeamTiles, TeamTiles) == 0x2e0, "Offset mismatch for UClassSelectorTeamTiles::TeamTiles");
static_assert(offsetof(UClassSelectorTeamTiles, RootPanel) == 0x2f0, "Offset mismatch for UClassSelectorTeamTiles::RootPanel");
static_assert(offsetof(UClassSelectorTeamTiles, EntryClass) == 0x2f8, "Offset mismatch for UClassSelectorTeamTiles::EntryClass");
static_assert(offsetof(UClassSelectorTeamTiles, DesignerPreviewEntries) == 0x300, "Offset mismatch for UClassSelectorTeamTiles::DesignerPreviewEntries");

// Size: 0x70 (Inherited: 0x28, Single: 0x48)
class UCreativeClassItemInfo : public UObject
{
public:
    FMinigameClassSlot ClassSlot; // 0x28 (Size: 0x40, Type: StructProperty)
    uint8_t Pad_68[0x8]; // 0x68 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UCreativeClassItemInfo) == 0x70, "Size mismatch for UCreativeClassItemInfo");
static_assert(offsetof(UCreativeClassItemInfo, ClassSlot) == 0x28, "Offset mismatch for UCreativeClassItemInfo::ClassSlot");

// Size: 0x14f0 (Inherited: 0x30b0, Single: 0xffffe440)
class UCreativeClassEntry : public UCreativeClassSelectorButton
{
public:
    UCreativeClassItemInfo* ItemInfo; // 0x14e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_14e8[0x8]; // 0x14e8 (Size: 0x8, Type: PaddingProperty)

public:
    virtual void OnBrowsingLoadout(bool& const bBrowsingLoadout); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void OnClassEntryDataSet(bool& const bIsCurrentClass, bool& const bIsPendingClass); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UCreativeClassEntry) == 0x14f0, "Size mismatch for UCreativeClassEntry");
static_assert(offsetof(UCreativeClassEntry, ItemInfo) == 0x14e0, "Offset mismatch for UCreativeClassEntry::ItemInfo");

// Size: 0x540 (Inherited: 0xb38, Single: 0xfffffa08)
class UCreativeClassSelector : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x10]; // 0x408 (Size: 0x10, Type: PaddingProperty)
    UClassSelectorTabButtons* TabButtons_TeamSelection; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UCommonListView* ListView_Classes; // 0x420 (Size: 0x8, Type: ObjectProperty)
    TArray<UCreativeClassItemInfo*> ClassItemInfos; // 0x428 (Size: 0x10, Type: ArrayProperty)
    UScrollBox* LoadoutScrollBox; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UClassSelectorLoadoutContainer* LoadoutContainer_Inventory; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UClassSelectorLoadoutContainer* LoadoutContainer_Resources; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_SelectLoadout; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_RandomClass; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UWidgetSwitcher* Switcher_Descriptions; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* ClassAndTeamDescriptionContainer; // 0x468 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* ItemDescriptionContainer; // 0x470 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* InventoryPanel; // 0x478 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* ResourcesPanel; // 0x480 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* ItemRarity; // 0x488 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* ItemName; // 0x490 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* ItemDescription; // 0x498 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* TeamDescriptionContainer; // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UClassSelectorTeamInfoWidget* TeamInfoWidget_FullView; // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UClassSelectorTeamInfoWidget* TeamInfoWidget_TeamsOnly; // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UWidgetSwitcher* DisplaySwitcher; // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* ClassAndTeamSelectionContainer; // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* OnlyTeamSelectionContainer; // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* InvalidDataContainer; // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    UClassSelectorTeamTiles* TeamTiles; // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    UClass* TeamSelectionTabClass; // 0x4e0 (Size: 0x8, Type: ClassProperty)
    bool bIsModalVersion; // 0x4e8 (Size: 0x1, Type: BoolProperty)
    bool bEnableModalTimeLimit; // 0x4e9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4ea[0x2]; // 0x4ea (Size: 0x2, Type: PaddingProperty)
    int32_t ModalTimeLimitInSeconds; // 0x4ec (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4f0[0x10]; // 0x4f0 (Size: 0x10, Type: PaddingProperty)
    uint8_t DisplayMode; // 0x500 (Size: 0x1, Type: EnumProperty)
    bool bDeferRespawn; // 0x501 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_502[0x6]; // 0x502 (Size: 0x6, Type: PaddingProperty)
    FDataTableRowHandle ReturnToClassSelectionInputAction; // 0x508 (Size: 0x10, Type: StructProperty)
    float LoadoutScrollPadding; // 0x518 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_51c[0x1c]; // 0x51c (Size: 0x1c, Type: PaddingProperty)
    UCreativeClassItemInfo* SelectedClassItemInfo; // 0x538 (Size: 0x8, Type: ObjectProperty)

public:
    UWidget* GetFirstLoadoutItem() const; // 0x11a9907c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void OnClassSelectionChanged(const FText NewClassName, const FText NewClassDescription); // 0x288a61c (Index: 0x2, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnLoadoutCommitted(const FText NewClassName, const FText NewTeamName, bool& const bNewLoadout, bool& const bDefer, char& SelectedClassIndex); // 0x288a61c (Index: 0x4, Flags: Event|Public|HasOutParms|BlueprintEvent)

protected:
    void HandleMinigameStateChanged(AFortMinigame*& Minigame, EFortMinigameState& MinigameState); // 0x11a990b8 (Index: 0x1, Flags: Final|Native|Protected)
    virtual void OnClassSelectorUIPopulated(bool& const bHasValidData); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTimerCountdown(int32_t& const RemainingTime); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCreativeClassSelector) == 0x540, "Size mismatch for UCreativeClassSelector");
static_assert(offsetof(UCreativeClassSelector, TabButtons_TeamSelection) == 0x418, "Offset mismatch for UCreativeClassSelector::TabButtons_TeamSelection");
static_assert(offsetof(UCreativeClassSelector, ListView_Classes) == 0x420, "Offset mismatch for UCreativeClassSelector::ListView_Classes");
static_assert(offsetof(UCreativeClassSelector, ClassItemInfos) == 0x428, "Offset mismatch for UCreativeClassSelector::ClassItemInfos");
static_assert(offsetof(UCreativeClassSelector, LoadoutScrollBox) == 0x438, "Offset mismatch for UCreativeClassSelector::LoadoutScrollBox");
static_assert(offsetof(UCreativeClassSelector, LoadoutContainer_Inventory) == 0x440, "Offset mismatch for UCreativeClassSelector::LoadoutContainer_Inventory");
static_assert(offsetof(UCreativeClassSelector, LoadoutContainer_Resources) == 0x448, "Offset mismatch for UCreativeClassSelector::LoadoutContainer_Resources");
static_assert(offsetof(UCreativeClassSelector, Button_SelectLoadout) == 0x450, "Offset mismatch for UCreativeClassSelector::Button_SelectLoadout");
static_assert(offsetof(UCreativeClassSelector, Button_RandomClass) == 0x458, "Offset mismatch for UCreativeClassSelector::Button_RandomClass");
static_assert(offsetof(UCreativeClassSelector, Switcher_Descriptions) == 0x460, "Offset mismatch for UCreativeClassSelector::Switcher_Descriptions");
static_assert(offsetof(UCreativeClassSelector, ClassAndTeamDescriptionContainer) == 0x468, "Offset mismatch for UCreativeClassSelector::ClassAndTeamDescriptionContainer");
static_assert(offsetof(UCreativeClassSelector, ItemDescriptionContainer) == 0x470, "Offset mismatch for UCreativeClassSelector::ItemDescriptionContainer");
static_assert(offsetof(UCreativeClassSelector, InventoryPanel) == 0x478, "Offset mismatch for UCreativeClassSelector::InventoryPanel");
static_assert(offsetof(UCreativeClassSelector, ResourcesPanel) == 0x480, "Offset mismatch for UCreativeClassSelector::ResourcesPanel");
static_assert(offsetof(UCreativeClassSelector, ItemRarity) == 0x488, "Offset mismatch for UCreativeClassSelector::ItemRarity");
static_assert(offsetof(UCreativeClassSelector, ItemName) == 0x490, "Offset mismatch for UCreativeClassSelector::ItemName");
static_assert(offsetof(UCreativeClassSelector, ItemDescription) == 0x498, "Offset mismatch for UCreativeClassSelector::ItemDescription");
static_assert(offsetof(UCreativeClassSelector, TeamDescriptionContainer) == 0x4a0, "Offset mismatch for UCreativeClassSelector::TeamDescriptionContainer");
static_assert(offsetof(UCreativeClassSelector, TeamInfoWidget_FullView) == 0x4a8, "Offset mismatch for UCreativeClassSelector::TeamInfoWidget_FullView");
static_assert(offsetof(UCreativeClassSelector, TeamInfoWidget_TeamsOnly) == 0x4b0, "Offset mismatch for UCreativeClassSelector::TeamInfoWidget_TeamsOnly");
static_assert(offsetof(UCreativeClassSelector, DisplaySwitcher) == 0x4b8, "Offset mismatch for UCreativeClassSelector::DisplaySwitcher");
static_assert(offsetof(UCreativeClassSelector, ClassAndTeamSelectionContainer) == 0x4c0, "Offset mismatch for UCreativeClassSelector::ClassAndTeamSelectionContainer");
static_assert(offsetof(UCreativeClassSelector, OnlyTeamSelectionContainer) == 0x4c8, "Offset mismatch for UCreativeClassSelector::OnlyTeamSelectionContainer");
static_assert(offsetof(UCreativeClassSelector, InvalidDataContainer) == 0x4d0, "Offset mismatch for UCreativeClassSelector::InvalidDataContainer");
static_assert(offsetof(UCreativeClassSelector, TeamTiles) == 0x4d8, "Offset mismatch for UCreativeClassSelector::TeamTiles");
static_assert(offsetof(UCreativeClassSelector, TeamSelectionTabClass) == 0x4e0, "Offset mismatch for UCreativeClassSelector::TeamSelectionTabClass");
static_assert(offsetof(UCreativeClassSelector, bIsModalVersion) == 0x4e8, "Offset mismatch for UCreativeClassSelector::bIsModalVersion");
static_assert(offsetof(UCreativeClassSelector, bEnableModalTimeLimit) == 0x4e9, "Offset mismatch for UCreativeClassSelector::bEnableModalTimeLimit");
static_assert(offsetof(UCreativeClassSelector, ModalTimeLimitInSeconds) == 0x4ec, "Offset mismatch for UCreativeClassSelector::ModalTimeLimitInSeconds");
static_assert(offsetof(UCreativeClassSelector, DisplayMode) == 0x500, "Offset mismatch for UCreativeClassSelector::DisplayMode");
static_assert(offsetof(UCreativeClassSelector, bDeferRespawn) == 0x501, "Offset mismatch for UCreativeClassSelector::bDeferRespawn");
static_assert(offsetof(UCreativeClassSelector, ReturnToClassSelectionInputAction) == 0x508, "Offset mismatch for UCreativeClassSelector::ReturnToClassSelectionInputAction");
static_assert(offsetof(UCreativeClassSelector, LoadoutScrollPadding) == 0x518, "Offset mismatch for UCreativeClassSelector::LoadoutScrollPadding");
static_assert(offsetof(UCreativeClassSelector, SelectedClassItemInfo) == 0x538, "Offset mismatch for UCreativeClassSelector::SelectedClassItemInfo");

// Size: 0x478 (Inherited: 0xb38, Single: 0xfffff940)
class UCreativeClassSelectorMapTab : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x28]; // 0x408 (Size: 0x28, Type: PaddingProperty)
    FAthenaMapScreenContainerTabInfo MapTabInfo; // 0x430 (Size: 0x40, Type: StructProperty)
    UCreativeClassSelector* CreativeClassSelector; // 0x470 (Size: 0x8, Type: ObjectProperty)

public:
    void SetTabName(const FText TabName); // 0x11a993b4 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UCreativeClassSelectorMapTab) == 0x478, "Size mismatch for UCreativeClassSelectorMapTab");
static_assert(offsetof(UCreativeClassSelectorMapTab, MapTabInfo) == 0x430, "Offset mismatch for UCreativeClassSelectorMapTab::MapTabInfo");
static_assert(offsetof(UCreativeClassSelectorMapTab, CreativeClassSelector) == 0x470, "Offset mismatch for UCreativeClassSelectorMapTab::CreativeClassSelector");

// Size: 0x360 (Inherited: 0xbc0, Single: 0xfffff7a0)
class AMutator_ClassSelectorUI : public AFortAthenaMutator
{
public:
};

static_assert(sizeof(AMutator_ClassSelectorUI) == 0x360, "Size mismatch for AMutator_ClassSelectorUI");

