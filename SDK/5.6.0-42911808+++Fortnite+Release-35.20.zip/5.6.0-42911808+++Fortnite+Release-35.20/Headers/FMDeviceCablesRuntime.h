/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMDeviceCablesRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "FabricRuntime.h"
#include "FabricFramework.h"
#include "GameplayEventRouter.h"

// Size: 0x940 (Inherited: 0xa18, Single: 0xffffff28)
class AFMDeviceCable : public ABuildingActor
{
public:
    uint8_t Pad_748[0x18]; // 0x748 (Size: 0x18, Type: PaddingProperty)
    USplineComponent* SplineComponent; // 0x760 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* DeviceCableHead; // 0x768 (Size: 0x8, Type: ObjectProperty)
    UClass* SplineMeshComponentClass; // 0x770 (Size: 0x8, Type: ClassProperty)
    TSoftObjectPtr<UStaticMesh*> ScalarStaticMesh; // 0x778 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh*> AudioStaticMesh; // 0x798 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh*> NoteStaticMesh; // 0x7b8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh*> TextureStaticMesh; // 0x7d8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh*> MeshStaticMesh; // 0x7f8 (Size: 0x20, Type: SoftObjectProperty)
    FName SplineLengthParam; // 0x818 (Size: 0x4, Type: NameProperty)
    FName SplineStartParam; // 0x81c (Size: 0x4, Type: NameProperty)
    FName SplineEndParam; // 0x820 (Size: 0x4, Type: NameProperty)
    FName PortTypeParam; // 0x824 (Size: 0x4, Type: NameProperty)
    float CableStubLength; // 0x828 (Size: 0x4, Type: FloatProperty)
    float CableDistanceFromPortB; // 0x82c (Size: 0x4, Type: FloatProperty)
    float CableMinTangent; // 0x830 (Size: 0x4, Type: FloatProperty)
    float CableMaxTangent; // 0x834 (Size: 0x4, Type: FloatProperty)
    float CableSectionLengthAtCableCenter; // 0x838 (Size: 0x4, Type: FloatProperty)
    float CableSectionLengthAtCableHeads; // 0x83c (Size: 0x4, Type: FloatProperty)
    int32_t CableSectionCountAtCableHeads; // 0x840 (Size: 0x4, Type: IntProperty)
    int32_t CableCenterSectionsMaxCount; // 0x844 (Size: 0x4, Type: IntProperty)
    float ExtremeMinDotProduct; // 0x848 (Size: 0x4, Type: FloatProperty)
    float MaxExtremeCableBendSize; // 0x84c (Size: 0x4, Type: FloatProperty)
    float ExtremeAngleTangentScale; // 0x850 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_854[0x4]; // 0x854 (Size: 0x4, Type: PaddingProperty)
    TArray<USplineMeshComponent*> CableSplineMeshArray; // 0x858 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UFMDeviceCableAnimatorBase*> DeviceCableAnimator; // 0x868 (Size: 0x8, Type: WeakObjectProperty)
    UMaterialInstanceDynamic* DeviceCableMaterial; // 0x870 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* DeviceCableHeadMaterial; // 0x878 (Size: 0x8, Type: ObjectProperty)
    FVector DeviceCableHeadScale; // 0x880 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_898[0x10]; // 0x898 (Size: 0x10, Type: PaddingProperty)
    UFMDeviceCablePortComponent* ConstantPort; // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* PortA; // 0x8b0 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* ServerPortA; // 0x8b8 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* PortB; // 0x8c0 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* ServerPortB; // 0x8c8 (Size: 0x8, Type: ObjectProperty)
    bool bPermittedToShowVisuals; // 0x8d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8d1[0x6f]; // 0x8d1 (Size: 0x6f, Type: PaddingProperty)

public:
    void ConnectConstantPort(UFMDeviceCablePortComponent*& Port); // 0x11dc5858 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void ConnectPort(UFMDeviceCablePortComponent*& Port); // 0x11dc5984 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void Disconnect(); // 0x11dc5c30 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    EDeviceCablePortDataType GetCableDataType() const; // 0x11dc5c58 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    USplineComponent* GetCableSpline() const; // 0xda1c788 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFMDeviceCablePortComponent* GetConstantPort() const; // 0xe931644 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UStaticMeshComponent* GetDeviceCableHead() const; // 0x11dc5c78 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFMDeviceCablePortComponent* GetPortA() const; // 0x11dc5c90 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFMDeviceCablePortComponent* GetPortB() const; // 0x11dc5ca8 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetDeviceCableHeadScale(FVector& Scale); // 0x11dc7784 (Index: 0x14, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetFocusedVisuals(bool& bIsFocused); // 0x11dc7dc4 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateDeviceCableAnimator(); // 0x11dc82f4 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateVisualParameters(); // 0x11dc8308 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnRep_bPermittedToShowVisuals(); // 0x11dc6ef0 (Index: 0xf, Flags: Final|Native|Private)
    void OnRep_ServerPortA(); // 0x11dc6eb4 (Index: 0x10, Flags: Final|Native|Private)
    void OnRep_ServerPortB(); // 0x11dc6ec8 (Index: 0x11, Flags: Final|Native|Private)

protected:
    void BuildMeshOnSpline(bool& bCollisionEnabled); // 0x11dc572c (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnCableConnected(bool& bThroughReplication); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCableDisconnected(bool& bThroughReplication); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCableGrabbed(bool& bThroughReplication); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCablePortsUpdated(EDeviceCablePortDataType& CurrentPortDataType); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCableReturned(); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void OnScalesUpdated(FVector& StartScale, FVector& EndScale); // 0x288a61c (Index: 0x12, Flags: Event|Protected|HasDefaults|BlueprintEvent)
    virtual void OnSplineUpdated(bool& bCollisionEnabled); // 0x288a61c (Index: 0x13, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AFMDeviceCable) == 0x940, "Size mismatch for AFMDeviceCable");
static_assert(offsetof(AFMDeviceCable, SplineComponent) == 0x760, "Offset mismatch for AFMDeviceCable::SplineComponent");
static_assert(offsetof(AFMDeviceCable, DeviceCableHead) == 0x768, "Offset mismatch for AFMDeviceCable::DeviceCableHead");
static_assert(offsetof(AFMDeviceCable, SplineMeshComponentClass) == 0x770, "Offset mismatch for AFMDeviceCable::SplineMeshComponentClass");
static_assert(offsetof(AFMDeviceCable, ScalarStaticMesh) == 0x778, "Offset mismatch for AFMDeviceCable::ScalarStaticMesh");
static_assert(offsetof(AFMDeviceCable, AudioStaticMesh) == 0x798, "Offset mismatch for AFMDeviceCable::AudioStaticMesh");
static_assert(offsetof(AFMDeviceCable, NoteStaticMesh) == 0x7b8, "Offset mismatch for AFMDeviceCable::NoteStaticMesh");
static_assert(offsetof(AFMDeviceCable, TextureStaticMesh) == 0x7d8, "Offset mismatch for AFMDeviceCable::TextureStaticMesh");
static_assert(offsetof(AFMDeviceCable, MeshStaticMesh) == 0x7f8, "Offset mismatch for AFMDeviceCable::MeshStaticMesh");
static_assert(offsetof(AFMDeviceCable, SplineLengthParam) == 0x818, "Offset mismatch for AFMDeviceCable::SplineLengthParam");
static_assert(offsetof(AFMDeviceCable, SplineStartParam) == 0x81c, "Offset mismatch for AFMDeviceCable::SplineStartParam");
static_assert(offsetof(AFMDeviceCable, SplineEndParam) == 0x820, "Offset mismatch for AFMDeviceCable::SplineEndParam");
static_assert(offsetof(AFMDeviceCable, PortTypeParam) == 0x824, "Offset mismatch for AFMDeviceCable::PortTypeParam");
static_assert(offsetof(AFMDeviceCable, CableStubLength) == 0x828, "Offset mismatch for AFMDeviceCable::CableStubLength");
static_assert(offsetof(AFMDeviceCable, CableDistanceFromPortB) == 0x82c, "Offset mismatch for AFMDeviceCable::CableDistanceFromPortB");
static_assert(offsetof(AFMDeviceCable, CableMinTangent) == 0x830, "Offset mismatch for AFMDeviceCable::CableMinTangent");
static_assert(offsetof(AFMDeviceCable, CableMaxTangent) == 0x834, "Offset mismatch for AFMDeviceCable::CableMaxTangent");
static_assert(offsetof(AFMDeviceCable, CableSectionLengthAtCableCenter) == 0x838, "Offset mismatch for AFMDeviceCable::CableSectionLengthAtCableCenter");
static_assert(offsetof(AFMDeviceCable, CableSectionLengthAtCableHeads) == 0x83c, "Offset mismatch for AFMDeviceCable::CableSectionLengthAtCableHeads");
static_assert(offsetof(AFMDeviceCable, CableSectionCountAtCableHeads) == 0x840, "Offset mismatch for AFMDeviceCable::CableSectionCountAtCableHeads");
static_assert(offsetof(AFMDeviceCable, CableCenterSectionsMaxCount) == 0x844, "Offset mismatch for AFMDeviceCable::CableCenterSectionsMaxCount");
static_assert(offsetof(AFMDeviceCable, ExtremeMinDotProduct) == 0x848, "Offset mismatch for AFMDeviceCable::ExtremeMinDotProduct");
static_assert(offsetof(AFMDeviceCable, MaxExtremeCableBendSize) == 0x84c, "Offset mismatch for AFMDeviceCable::MaxExtremeCableBendSize");
static_assert(offsetof(AFMDeviceCable, ExtremeAngleTangentScale) == 0x850, "Offset mismatch for AFMDeviceCable::ExtremeAngleTangentScale");
static_assert(offsetof(AFMDeviceCable, CableSplineMeshArray) == 0x858, "Offset mismatch for AFMDeviceCable::CableSplineMeshArray");
static_assert(offsetof(AFMDeviceCable, DeviceCableAnimator) == 0x868, "Offset mismatch for AFMDeviceCable::DeviceCableAnimator");
static_assert(offsetof(AFMDeviceCable, DeviceCableMaterial) == 0x870, "Offset mismatch for AFMDeviceCable::DeviceCableMaterial");
static_assert(offsetof(AFMDeviceCable, DeviceCableHeadMaterial) == 0x878, "Offset mismatch for AFMDeviceCable::DeviceCableHeadMaterial");
static_assert(offsetof(AFMDeviceCable, DeviceCableHeadScale) == 0x880, "Offset mismatch for AFMDeviceCable::DeviceCableHeadScale");
static_assert(offsetof(AFMDeviceCable, ConstantPort) == 0x8a8, "Offset mismatch for AFMDeviceCable::ConstantPort");
static_assert(offsetof(AFMDeviceCable, PortA) == 0x8b0, "Offset mismatch for AFMDeviceCable::PortA");
static_assert(offsetof(AFMDeviceCable, ServerPortA) == 0x8b8, "Offset mismatch for AFMDeviceCable::ServerPortA");
static_assert(offsetof(AFMDeviceCable, PortB) == 0x8c0, "Offset mismatch for AFMDeviceCable::PortB");
static_assert(offsetof(AFMDeviceCable, ServerPortB) == 0x8c8, "Offset mismatch for AFMDeviceCable::ServerPortB");
static_assert(offsetof(AFMDeviceCable, bPermittedToShowVisuals) == 0x8d0, "Offset mismatch for AFMDeviceCable::bPermittedToShowVisuals");

// Size: 0x120 (Inherited: 0x158, Single: 0xffffffc8)
class UFMDeviceCableAnimatorTickSubsystem : public UFortManagedTickSubsystem
{
public:
};

static_assert(sizeof(UFMDeviceCableAnimatorTickSubsystem) == 0x120, "Size mismatch for UFMDeviceCableAnimatorTickSubsystem");

// Size: 0xe8 (Inherited: 0x28, Single: 0xc0)
class UFMDeviceCableAnimatorBase : public UObject
{
public:
    uint8_t Pad_28[0x50]; // 0x28 (Size: 0x50, Type: PaddingProperty)
    TWeakObjectPtr<UFMDeviceCablePortComponent*> OwnerPort; // 0x78 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_80[0x68]; // 0x80 (Size: 0x68, Type: PaddingProperty)

public:
    void AddMaterialInstance(UMaterialInstanceDynamic*& InMaterialInstance); // 0x11dc5600 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveMaterialInstance(UMaterialInstanceDynamic*& InMaterialInstance); // 0x11dc710c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetOwnerPort(UFMDeviceCablePortComponent*& OwnerPort); // 0x11dc81c8 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnConnectionEnded(UFMDeviceCableConnectionBase*& EndedConnection); // 0xb084dc0 (Index: 0x1, Flags: Final|Native|Private)
    void OnConnectionStarted(UFMDeviceCableConnectionBase*& NewConnection); // 0xb084c90 (Index: 0x2, Flags: Final|Native|Private)
    void OnPortArtifactUpdated(); // 0xa39cba8 (Index: 0x3, Flags: Final|Native|Private)

protected:
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFMDeviceCableAnimatorBase) == 0xe8, "Size mismatch for UFMDeviceCableAnimatorBase");
static_assert(offsetof(UFMDeviceCableAnimatorBase, OwnerPort) == 0x78, "Offset mismatch for UFMDeviceCableAnimatorBase::OwnerPort");

// Size: 0x190 (Inherited: 0x110, Single: 0x80)
class UFMDeviceCableAnimatorMidiEvent : public UFMDeviceCableAnimatorBase
{
public:
    FName NoteTextureParam; // 0xe8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_ec[0x4]; // 0xec (Size: 0x4, Type: PaddingProperty)
    UCurveFloat* NoteShapeCurve; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    float NotePercentOfTexture; // 0xf8 (Size: 0x4, Type: FloatProperty)
    float NoteTravelBeats; // 0xfc (Size: 0x4, Type: FloatProperty)
    float NoteStartDelayBeats; // 0x100 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_104[0x14]; // 0x104 (Size: 0x14, Type: PaddingProperty)
    UTexture2D* NoteTexture; // 0x118 (Size: 0x8, Type: ObjectProperty)
    UFabricMetaSoundPatchWrapper* PatchWrapper; // 0x120 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_128[0x68]; // 0x128 (Size: 0x68, Type: PaddingProperty)

private:
    void OnMetaSoundOutputIntChangedBatch(const FName OutputName, const TArray<int32_t> Output); // 0x11dc6b5c (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UFMDeviceCableAnimatorMidiEvent) == 0x190, "Size mismatch for UFMDeviceCableAnimatorMidiEvent");
static_assert(offsetof(UFMDeviceCableAnimatorMidiEvent, NoteTextureParam) == 0xe8, "Offset mismatch for UFMDeviceCableAnimatorMidiEvent::NoteTextureParam");
static_assert(offsetof(UFMDeviceCableAnimatorMidiEvent, NoteShapeCurve) == 0xf0, "Offset mismatch for UFMDeviceCableAnimatorMidiEvent::NoteShapeCurve");
static_assert(offsetof(UFMDeviceCableAnimatorMidiEvent, NotePercentOfTexture) == 0xf8, "Offset mismatch for UFMDeviceCableAnimatorMidiEvent::NotePercentOfTexture");
static_assert(offsetof(UFMDeviceCableAnimatorMidiEvent, NoteTravelBeats) == 0xfc, "Offset mismatch for UFMDeviceCableAnimatorMidiEvent::NoteTravelBeats");
static_assert(offsetof(UFMDeviceCableAnimatorMidiEvent, NoteStartDelayBeats) == 0x100, "Offset mismatch for UFMDeviceCableAnimatorMidiEvent::NoteStartDelayBeats");
static_assert(offsetof(UFMDeviceCableAnimatorMidiEvent, NoteTexture) == 0x118, "Offset mismatch for UFMDeviceCableAnimatorMidiEvent::NoteTexture");
static_assert(offsetof(UFMDeviceCableAnimatorMidiEvent, PatchWrapper) == 0x120, "Offset mismatch for UFMDeviceCableAnimatorMidiEvent::PatchWrapper");

// Size: 0x100 (Inherited: 0x110, Single: 0xfffffff0)
class UFMDeviceCableAnimatorFloatProvider : public UFMDeviceCableAnimatorBase
{
public:
    FName CableDataParam; // 0xe8 (Size: 0x4, Type: NameProperty)
    FName FloatProviderTypeParam; // 0xec (Size: 0x4, Type: NameProperty)
    TArray<UFabricFloatProviderBase*> FloatProviders; // 0xf0 (Size: 0x10, Type: ArrayProperty)

public:
    void SetFloatProvider(UFabricFloatProviderBase*& InFloatProvider); // 0x11dc785c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void SetFloatProviders(const TArray<UFabricFloatProviderBase*> InFloatProviders); // 0x11dc7b38 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

protected:
    void OnFloatChanged(float& CurrentFloat, UFabricFloatProviderBase*& FloatProvider); // 0x11dc63e8 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFMDeviceCableAnimatorFloatProvider) == 0x100, "Size mismatch for UFMDeviceCableAnimatorFloatProvider");
static_assert(offsetof(UFMDeviceCableAnimatorFloatProvider, CableDataParam) == 0xe8, "Offset mismatch for UFMDeviceCableAnimatorFloatProvider::CableDataParam");
static_assert(offsetof(UFMDeviceCableAnimatorFloatProvider, FloatProviderTypeParam) == 0xec, "Offset mismatch for UFMDeviceCableAnimatorFloatProvider::FloatProviderTypeParam");
static_assert(offsetof(UFMDeviceCableAnimatorFloatProvider, FloatProviders) == 0xf0, "Offset mismatch for UFMDeviceCableAnimatorFloatProvider::FloatProviders");

// Size: 0xf8 (Inherited: 0x110, Single: 0xffffffe8)
class UFMDeviceCableAnimatorTextureProvider : public UFMDeviceCableAnimatorBase
{
public:
    FName CableDataParam; // 0xe8 (Size: 0x4, Type: NameProperty)
    float DecayRate; // 0xec (Size: 0x4, Type: FloatProperty)
    UFabricTextureProviderBase* TextureProvider; // 0xf0 (Size: 0x8, Type: ObjectProperty)

public:
    void SetTextureProvider(UFabricTextureProviderBase*& InTextureProvider); // 0x11dc7ef0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFMDeviceCableAnimatorTextureProvider) == 0xf8, "Size mismatch for UFMDeviceCableAnimatorTextureProvider");
static_assert(offsetof(UFMDeviceCableAnimatorTextureProvider, CableDataParam) == 0xe8, "Offset mismatch for UFMDeviceCableAnimatorTextureProvider::CableDataParam");
static_assert(offsetof(UFMDeviceCableAnimatorTextureProvider, DecayRate) == 0xec, "Offset mismatch for UFMDeviceCableAnimatorTextureProvider::DecayRate");
static_assert(offsetof(UFMDeviceCableAnimatorTextureProvider, TextureProvider) == 0xf0, "Offset mismatch for UFMDeviceCableAnimatorTextureProvider::TextureProvider");

// Size: 0xf8 (Inherited: 0x110, Single: 0xffffffe8)
class UFMDeviceCableAnimatorMeshProvider : public UFMDeviceCableAnimatorBase
{
public:
    FName CableDataParam; // 0xe8 (Size: 0x4, Type: NameProperty)
    float DecayRate; // 0xec (Size: 0x4, Type: FloatProperty)
    UFabricMeshProviderBase* MeshProvider; // 0xf0 (Size: 0x8, Type: ObjectProperty)

public:
    void SetMeshProvider(UFabricMeshProviderBase*& InMeshProvider); // 0x11dc7ef0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFMDeviceCableAnimatorMeshProvider) == 0xf8, "Size mismatch for UFMDeviceCableAnimatorMeshProvider");
static_assert(offsetof(UFMDeviceCableAnimatorMeshProvider, CableDataParam) == 0xe8, "Offset mismatch for UFMDeviceCableAnimatorMeshProvider::CableDataParam");
static_assert(offsetof(UFMDeviceCableAnimatorMeshProvider, DecayRate) == 0xec, "Offset mismatch for UFMDeviceCableAnimatorMeshProvider::DecayRate");
static_assert(offsetof(UFMDeviceCableAnimatorMeshProvider, MeshProvider) == 0xf0, "Offset mismatch for UFMDeviceCableAnimatorMeshProvider::MeshProvider");

// Size: 0x168 (Inherited: 0x110, Single: 0x58)
class UFMDeviceCableAnimatorAudioAnalyzer : public UFMDeviceCableAnimatorBase
{
public:
    FName FftTextureParam; // 0xe8 (Size: 0x4, Type: NameProperty)
    FName WaveformTextureParam; // 0xec (Size: 0x4, Type: NameProperty)
    FName AmplitudeTextureParam; // 0xf0 (Size: 0x4, Type: NameProperty)
    FName AmplitudeDataParam; // 0xf4 (Size: 0x4, Type: NameProperty)
    FName CableQualityParam; // 0xf8 (Size: 0x4, Type: NameProperty)
    FName CableReactivityParam; // 0xfc (Size: 0x4, Type: NameProperty)
    int32_t WaveformNumSamplesHeld; // 0x100 (Size: 0x4, Type: IntProperty)
    int32_t WaveformSmoothingDistance; // 0x104 (Size: 0x4, Type: IntProperty)
    float WaveformSmoothingFactor; // 0x108 (Size: 0x4, Type: FloatProperty)
    float WaveformDecayPerSecond; // 0x10c (Size: 0x4, Type: FloatProperty)
    UTexture2D* WaveformTexture; // 0x110 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* AmplitudeTexture; // 0x118 (Size: 0x8, Type: ObjectProperty)
    UFabricMetaSoundPatchWrapper* PatchWrapper; // 0x120 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_128[0x40]; // 0x128 (Size: 0x40, Type: PaddingProperty)

public:
    float GetLastAnalyzerValue() const; // 0x5952680 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetAnalyzerName(FName& AnalyzerName); // 0x11dc765c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnMetaSoundOutputFloatChangedBatch(const FName OutputName, TArray<float>& Output, FFabricMetaSoundPatchWrapperPeakTamer& PeakTamer, float& DeltaSeconds); // 0x11dc6714 (Index: 0x1, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UFMDeviceCableAnimatorAudioAnalyzer) == 0x168, "Size mismatch for UFMDeviceCableAnimatorAudioAnalyzer");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, FftTextureParam) == 0xe8, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::FftTextureParam");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, WaveformTextureParam) == 0xec, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::WaveformTextureParam");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, AmplitudeTextureParam) == 0xf0, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::AmplitudeTextureParam");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, AmplitudeDataParam) == 0xf4, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::AmplitudeDataParam");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, CableQualityParam) == 0xf8, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::CableQualityParam");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, CableReactivityParam) == 0xfc, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::CableReactivityParam");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, WaveformNumSamplesHeld) == 0x100, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::WaveformNumSamplesHeld");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, WaveformSmoothingDistance) == 0x104, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::WaveformSmoothingDistance");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, WaveformSmoothingFactor) == 0x108, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::WaveformSmoothingFactor");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, WaveformDecayPerSecond) == 0x10c, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::WaveformDecayPerSecond");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, WaveformTexture) == 0x110, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::WaveformTexture");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, AmplitudeTexture) == 0x118, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::AmplitudeTexture");
static_assert(offsetof(UFMDeviceCableAnimatorAudioAnalyzer, PatchWrapper) == 0x120, "Offset mismatch for UFMDeviceCableAnimatorAudioAnalyzer::PatchWrapper");

// Size: 0x98 (Inherited: 0x28, Single: 0x70)
class UFMDeviceCableConnectionBase : public UObject
{
public:
    uint8_t Pad_28[0x58]; // 0x28 (Size: 0x58, Type: PaddingProperty)
    bool bConnectionActive; // 0x80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_81[0x7]; // 0x81 (Size: 0x7, Type: PaddingProperty)
    TArray<TWeakObjectPtr<UFMDeviceCablePortComponent*>> BuildingCompositeArtifactFromPorts; // 0x88 (Size: 0x10, Type: ArrayProperty)

protected:
    virtual void EndConnectionBP(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void RebuildDirtyConnectionBP(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void StartConnectionBP(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFMDeviceCableConnectionBase) == 0x98, "Size mismatch for UFMDeviceCableConnectionBase");
static_assert(offsetof(UFMDeviceCableConnectionBase, bConnectionActive) == 0x80, "Offset mismatch for UFMDeviceCableConnectionBase::bConnectionActive");
static_assert(offsetof(UFMDeviceCableConnectionBase, BuildingCompositeArtifactFromPorts) == 0x88, "Offset mismatch for UFMDeviceCableConnectionBase::BuildingCompositeArtifactFromPorts");

// Size: 0x98 (Inherited: 0xc0, Single: 0xffffffd8)
class UFMDeviceCableMetaSoundConnection : public UFMDeviceCableConnectionBase
{
public:
};

static_assert(sizeof(UFMDeviceCableMetaSoundConnection) == 0x98, "Size mismatch for UFMDeviceCableMetaSoundConnection");

// Size: 0x98 (Inherited: 0x158, Single: 0xffffff40)
class UFMDeviceCableNoteConnection : public UFMDeviceCableMetaSoundConnection
{
public:
};

static_assert(sizeof(UFMDeviceCableNoteConnection) == 0x98, "Size mismatch for UFMDeviceCableNoteConnection");

// Size: 0x98 (Inherited: 0x158, Single: 0xffffff40)
class UFMDeviceCableAudioConnection : public UFMDeviceCableMetaSoundConnection
{
public:
};

static_assert(sizeof(UFMDeviceCableAudioConnection) == 0x98, "Size mismatch for UFMDeviceCableAudioConnection");

// Size: 0x98 (Inherited: 0xc0, Single: 0xffffffd8)
class UFMDeviceCableFloatConnection : public UFMDeviceCableConnectionBase
{
public:
};

static_assert(sizeof(UFMDeviceCableFloatConnection) == 0x98, "Size mismatch for UFMDeviceCableFloatConnection");

// Size: 0x98 (Inherited: 0xc0, Single: 0xffffffd8)
class UFMDeviceCableTextureConnection : public UFMDeviceCableConnectionBase
{
public:
};

static_assert(sizeof(UFMDeviceCableTextureConnection) == 0x98, "Size mismatch for UFMDeviceCableTextureConnection");

// Size: 0xa0 (Inherited: 0xc0, Single: 0xffffffe0)
class UFMDeviceCableMeshConnection : public UFMDeviceCableConnectionBase
{
public:
    uint32_t PreviousMeshInstanceHash; // 0x98 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFMDeviceCableMeshConnection) == 0xa0, "Size mismatch for UFMDeviceCableMeshConnection");
static_assert(offsetof(UFMDeviceCableMeshConnection, PreviousMeshInstanceHash) == 0x98, "Offset mismatch for UFMDeviceCableMeshConnection::PreviousMeshInstanceHash");

// Size: 0x128 (Inherited: 0xe0, Single: 0x48)
class UFMDeviceCableControllerComponent : public UActorComponent
{
public:
    uint8_t OnControllerCableConnected[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnControllerCableDisconnected[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UClass* ControllerCablePort; // 0xd8 (Size: 0x8, Type: ClassProperty)
    UClass* DeviceCableManagerClass; // 0xe0 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<AFortPawn*> CurrentPlayerPawn; // 0xe8 (Size: 0x8, Type: WeakObjectProperty)
    AFortPlayerControllerAthena* PlayerController; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* LocalControllerPort; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* ServerControllerPort; // 0x100 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AActor*> LocalControllerPortActor; // 0x108 (Size: 0x8, Type: WeakObjectProperty)
    UFMDeviceCableManagerComponent* LocalDeviceCableManager; // 0x110 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCableManagerComponent* ServerDeviceCableManager; // 0x118 (Size: 0x8, Type: ObjectProperty)
    bool bFitIsEquipped; // 0x120 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_121[0x7]; // 0x121 (Size: 0x7, Type: PaddingProperty)

public:
    void DropCable(); // 0x11dc5c44 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    bool IsCableConnectionValid(UFMDeviceCablePortComponent*& OtherPort) const; // 0x11dc5cc0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsHoldingCable() const; // 0x11dc609c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnControllerCableConnected__DelegateSignature(const TArray<UFMDeviceCablePortComponent*> ConnectedPorts); // 0x288a61c (Index: 0x4, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void OnControllerCableDisconnected__DelegateSignature(); // 0x288a61c (Index: 0x5, Flags: MulticastDelegate|Public|Delegate)
    void SelectPort(UFMDeviceCablePortComponent*& SelectedPort); // 0x11dc7238 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    virtual void ServerPortActivatedStateChanged(UFMDeviceCablePortComponent*& Port, EDeviceCableActivatedState& ActivatedState); // 0xde3827c (Index: 0x10, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)

private:
    virtual void ClientPortUpdatesRejected(TArray<FPortUpdateInfo>& const PortChangeInfos); // 0xd53ff40 (Index: 0x0, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    void OnCreativePlotLinkedVolumeChanged(AFortVolume*& FortVolume); // 0x11dc60bc (Index: 0x6, Flags: Final|Native|Private)
    void OnEmoteStarted(UFortItemDefinition*& const MontageItemDef, AFortPawn*& PawnEmoting); // 0x11dc61e8 (Index: 0x7, Flags: Final|Native|Private)
    void OnFortPawnChanged(AFortPawn*& NewPawn); // 0x11dc65e8 (Index: 0x8, Flags: Final|Native|Private)
    void OnNoFabricInteractablesHit(); // 0x11dc5c44 (Index: 0x9, Flags: Final|Native|Private)
    void OnRep_ServerControllerPort(); // 0x11dc6e80 (Index: 0xa, Flags: Final|Native|Private)
    void OnRep_ServerDeviceCableManager(); // 0x11dc6e94 (Index: 0xb, Flags: Final|Native|Private)
    void OnWeaponEquipped(AFortWeapon*& NewWeapon, AFortWeapon*& PrevWeapon); // 0x11dc6f04 (Index: 0xc, Flags: Final|Native|Private)
    void OnWeaponHolstered(); // 0x11dc5c44 (Index: 0xd, Flags: Final|Native|Private)
    virtual void ServerDisconnectController(); // 0x43388fc (Index: 0xf, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
    virtual void ServerPortsUpdated(TArray<FPortUpdateInfo>& const PortChangeInfos); // 0x11dc7364 (Index: 0x11, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
    virtual void ServerSelectPort(UFMDeviceCablePortComponent*& SelectedPort); // 0xa2be2d0 (Index: 0x12, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
    virtual void ServerVolumeChanged(); // 0x3473f70 (Index: 0x13, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)

protected:
    virtual void SetControllerTargetForControllerPortBP(AActor*& ControllerPortActor, APlayerController*& Controller); // 0x288a61c (Index: 0x14, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFMDeviceCableControllerComponent) == 0x128, "Size mismatch for UFMDeviceCableControllerComponent");
static_assert(offsetof(UFMDeviceCableControllerComponent, OnControllerCableConnected) == 0xb8, "Offset mismatch for UFMDeviceCableControllerComponent::OnControllerCableConnected");
static_assert(offsetof(UFMDeviceCableControllerComponent, OnControllerCableDisconnected) == 0xc8, "Offset mismatch for UFMDeviceCableControllerComponent::OnControllerCableDisconnected");
static_assert(offsetof(UFMDeviceCableControllerComponent, ControllerCablePort) == 0xd8, "Offset mismatch for UFMDeviceCableControllerComponent::ControllerCablePort");
static_assert(offsetof(UFMDeviceCableControllerComponent, DeviceCableManagerClass) == 0xe0, "Offset mismatch for UFMDeviceCableControllerComponent::DeviceCableManagerClass");
static_assert(offsetof(UFMDeviceCableControllerComponent, CurrentPlayerPawn) == 0xe8, "Offset mismatch for UFMDeviceCableControllerComponent::CurrentPlayerPawn");
static_assert(offsetof(UFMDeviceCableControllerComponent, PlayerController) == 0xf0, "Offset mismatch for UFMDeviceCableControllerComponent::PlayerController");
static_assert(offsetof(UFMDeviceCableControllerComponent, LocalControllerPort) == 0xf8, "Offset mismatch for UFMDeviceCableControllerComponent::LocalControllerPort");
static_assert(offsetof(UFMDeviceCableControllerComponent, ServerControllerPort) == 0x100, "Offset mismatch for UFMDeviceCableControllerComponent::ServerControllerPort");
static_assert(offsetof(UFMDeviceCableControllerComponent, LocalControllerPortActor) == 0x108, "Offset mismatch for UFMDeviceCableControllerComponent::LocalControllerPortActor");
static_assert(offsetof(UFMDeviceCableControllerComponent, LocalDeviceCableManager) == 0x110, "Offset mismatch for UFMDeviceCableControllerComponent::LocalDeviceCableManager");
static_assert(offsetof(UFMDeviceCableControllerComponent, ServerDeviceCableManager) == 0x118, "Offset mismatch for UFMDeviceCableControllerComponent::ServerDeviceCableManager");
static_assert(offsetof(UFMDeviceCableControllerComponent, bFitIsEquipped) == 0x120, "Offset mismatch for UFMDeviceCableControllerComponent::bFitIsEquipped");

// Size: 0x940 (Inherited: 0x1cd0, Single: 0xffffec70)
class UFMDeviceCableModulatorPortComponent : public UFMDeviceCablePortComponent
{
public:
    FString AssociatedProperty; // 0x920 (Size: 0x10, Type: StrProperty)
    TWeakObjectPtr<UObject*> AssociatedObject; // 0x930 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_938[0x8]; // 0x938 (Size: 0x8, Type: PaddingProperty)

public:
    void SetDeviceCableManager(UFMDeviceCableManagerComponent*& InDeviceCableManager); // 0x11dcbc60 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFMDeviceCableModulatorPortComponent) == 0x940, "Size mismatch for UFMDeviceCableModulatorPortComponent");
static_assert(offsetof(UFMDeviceCableModulatorPortComponent, AssociatedProperty) == 0x920, "Offset mismatch for UFMDeviceCableModulatorPortComponent::AssociatedProperty");
static_assert(offsetof(UFMDeviceCableModulatorPortComponent, AssociatedObject) == 0x930, "Offset mismatch for UFMDeviceCableModulatorPortComponent::AssociatedObject");

// Size: 0x920 (Inherited: 0x13b0, Single: 0xfffff570)
class UFMDeviceCablePortComponent : public UStaticMeshComponent
{
public:
    uint8_t Pad_610[0x30]; // 0x610 (Size: 0x30, Type: PaddingProperty)
    uint8_t OnCablePortSizeUpdated[0x10]; // 0x640 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnAnimatorCreated[0x10]; // 0x650 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnConnected[0x10]; // 0x660 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_670[0x20]; // 0x670 (Size: 0x20, Type: PaddingProperty)
    uint8_t OnConnectedDuringGameplay[0x10]; // 0x690 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDisconnected[0x10]; // 0x6a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnConnectionStarted[0x10]; // 0x6b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnConnectionEnded[0x10]; // 0x6c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPortArtifactUpdated[0x10]; // 0x6d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnReceiveFloatProviders[0x10]; // 0x6e0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDisconnectFloatProvider[0x10]; // 0x6f0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UClass* DeviceCableManagerClass; // 0x700 (Size: 0x8, Type: ClassProperty)
    TSoftObjectPtr<UStaticMesh*> OutputStaticMesh; // 0x708 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh*> AudioInStaticMesh; // 0x728 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh*> NoteInStaticMesh; // 0x748 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh*> TextureInStaticMesh; // 0x768 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh*> MeshInStaticMesh; // 0x788 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh*> ScalarInStaticMesh; // 0x7a8 (Size: 0x20, Type: SoftObjectProperty)
    TMap<UClass*, EDeviceCablePortDataType> CableAnimatorClasses; // 0x7c8 (Size: 0x50, Type: MapProperty)
    uint8_t PortFlowType; // 0x818 (Size: 0x1, Type: EnumProperty)
    uint8_t PortDataType; // 0x819 (Size: 0x1, Type: EnumProperty)
    uint8_t PortLoadableState; // 0x81a (Size: 0x1, Type: EnumProperty)
    uint8_t AnimationSyncType; // 0x81b (Size: 0x1, Type: EnumProperty)
    bool bAllowMultipleConnections; // 0x81c (Size: 0x1, Type: BoolProperty)
    bool bAllowSiblingConnections; // 0x81d (Size: 0x1, Type: BoolProperty)
    uint8_t OverrideAllowMultipleConnections; // 0x81e (Size: 0x1, Type: EnumProperty)
    uint8_t OverrideAllowSiblingConnections; // 0x81f (Size: 0x1, Type: EnumProperty)
    bool bHideWhenNotRelevant; // 0x820 (Size: 0x1, Type: BoolProperty)
    bool bIsPlayerPort; // 0x821 (Size: 0x1, Type: BoolProperty)
    bool bIsOnPreviewBuildingActor; // 0x822 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_823[0x1]; // 0x823 (Size: 0x1, Type: PaddingProperty)
    FName EnterVolumeTag; // 0x824 (Size: 0x4, Type: NameProperty)
    FName ExitVolumeTag; // 0x828 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_82c[0x4]; // 0x82c (Size: 0x4, Type: PaddingProperty)
    TArray<UFMDeviceCablePortComponent*> ConnectedPorts; // 0x830 (Size: 0x10, Type: ArrayProperty)
    TArray<UFMDeviceCablePortComponent*> ServerConnectedPorts; // 0x840 (Size: 0x10, Type: ArrayProperty)
    TArray<UFMDeviceCableConnectionBase*> CurrentConnections; // 0x850 (Size: 0x10, Type: ArrayProperty)
    AFMDeviceCable* ConstantCable; // 0x860 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCableManagerComponent* DeviceCableManager; // 0x868 (Size: 0x8, Type: ObjectProperty)
    TArray<UFMDeviceCablePortComponent*> OtherPortsOnActor; // 0x870 (Size: 0x10, Type: ArrayProperty)
    uint8_t PortActivatedState; // 0x880 (Size: 0x1, Type: EnumProperty)
    uint8_t ServerPortActivatedState; // 0x881 (Size: 0x1, Type: EnumProperty)
    uint8_t PortSelectableState; // 0x882 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_883[0x5]; // 0x883 (Size: 0x5, Type: PaddingProperty)
    UFMDeviceCableAnimatorBase* DeviceCableAnimator; // 0x888 (Size: 0x8, Type: ObjectProperty)
    FGuid ConnectionGuid; // 0x890 (Size: 0x10, Type: StructProperty)
    TArray<FGuid> ConnectedGuids; // 0x8a0 (Size: 0x10, Type: ArrayProperty)
    FFMDeviceCableArtifact CachedArtifact; // 0x8b0 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_8d0[0x10]; // 0x8d0 (Size: 0x10, Type: PaddingProperty)
    TArray<UFMDeviceCablePortComponent*> PendingConnectionBroadcasts; // 0x8e0 (Size: 0x10, Type: ArrayProperty)
    FGuid SaveGuid; // 0x8f0 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_900[0x20]; // 0x900 (Size: 0x20, Type: PaddingProperty)

public:
    void FabricCablePortSizeUpdated__DelegateSignature(float& Size); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
    EDeviceCablePortAnimationSyncType GetAnimationSyncType() const; // 0x11dc934c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FFMDeviceCableArtifact GetCachedArtifact() const; // 0x11dc9364 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UFMDeviceCablePortComponent*> GetConnectedPorts() const; // 0x11dc938c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UFMDeviceCableConnectionBase*> GetConnections() const; // 0x11dc93a8 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AFMDeviceCable* GetConstantCable(); // 0x11dc9434 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    UFMDeviceCableAnimatorBase* GetDeviceCableAnimator(); // 0x11dc944c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    FGuid GetGuid(); // 0x11dc9464 (Index: 0x8, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    bool GetIsModulationPort() const; // 0x11dc9494 (Index: 0x9, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsPlayerPort() const; // 0x11dc94bc (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsTerminalPort(EDeviceCablePortFlowType& FlowType) const; // 0x11dc94d4 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UFMDeviceCablePortComponent*> GetNextPortsInConnections() const; // 0x11dc960c (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UFMDeviceCablePortComponent*> GetOtherPortsOnActor() const; // 0x11dc9648 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EDeviceCableActivatedState GetPortActivatedState() const; // 0x11dc9664 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EDeviceCablePortDataType GetPortDataType() const; // 0x11dc967c (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EDeviceCablePortFlowType GetPortFlowType() const; // 0x11dc9694 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EDeviceCablePortSelectableState GetPortSelectableState() const; // 0x11dc96ac (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UFMDeviceCablePortComponent*> GetPreviousPortsInConnections() const; // 0x11dc96c4 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasSavedConnections() const; // 0x11dc9700 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsConnected() const; // 0x11dc9730 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsConnectedToPort(UFMDeviceCablePortComponent*& Port) const; // 0x11dc974c (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool MatchesPortConnectionType(UFMDeviceCablePortComponent*& OtherPort) const; // 0x11dc9bac (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnAnimatorCreated__DelegateSignature(UFMDeviceCableAnimatorBase*& Animator); // 0x288a61c (Index: 0x17, Flags: MulticastDelegate|Public|Delegate)
    void OnConnected__DelegateSignature(UFMDeviceCablePortComponent*& ConnectedPort); // 0x288a61c (Index: 0x18, Flags: MulticastDelegate|Public|Delegate)
    void OnConnectedWithSourcePort__DelegateSignature(UFMDeviceCablePortComponent*& SourcePort, UFMDeviceCablePortComponent*& OtherPort); // 0x288a61c (Index: 0x19, Flags: MulticastDelegate|Public|Delegate)
    void OnConnectionEnded__DelegateSignature(UFMDeviceCableConnectionBase*& EndedConnection); // 0x288a61c (Index: 0x1a, Flags: MulticastDelegate|Public|Delegate)
    void OnConnectionStarted__DelegateSignature(UFMDeviceCableConnectionBase*& NewConnection); // 0x288a61c (Index: 0x1b, Flags: MulticastDelegate|Public|Delegate)
    void OnDisconnected__DelegateSignature(UFMDeviceCablePortComponent*& DisconnectedPort); // 0x288a61c (Index: 0x1c, Flags: MulticastDelegate|Public|Delegate)
    void OnDisconnectFloatProvider__DelegateSignature(UFabricFloatProviderBase*& FloatProvider); // 0x288a61c (Index: 0x1d, Flags: MulticastDelegate|Public|Delegate)
    void OnPortArtifactUpdated__DelegateSignature(); // 0x288a61c (Index: 0x21, Flags: MulticastDelegate|Public|Delegate)
    void OnReceiveFloatProviders__DelegateSignature(const TArray<UFabricFloatProviderBase*> FloatProviders); // 0x288a61c (Index: 0x22, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    EPortSelectStatus Select(UFMDeviceCablePortComponent*& PlayerSelectionPort, TArray<FPortUpdateInfo>& OutPortUpdates); // 0x11dcad4c (Index: 0x27, Flags: Native|Public|HasOutParms|BlueprintCallable)
    EPortSelectStatus SelectWithStaticOutputInteraction(UFMDeviceCablePortComponent*& PlayerSelectionPort, TArray<FPortUpdateInfo>& OutPortUpdates); // 0x11dcb0cc (Index: 0x28, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetCablesHidden(bool& bNewHidden); // 0x11dcb910 (Index: 0x29, Flags: Final|Native|Public|BlueprintCallable)
    void SetCachedArtifact(const FFMDeviceCableArtifact InCachedArtifact); // 0x11dcba3c (Index: 0x2a, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetConnectedCablesHidden(bool& bNewHidden); // 0x11dcbb34 (Index: 0x2b, Flags: Final|Native|Public|BlueprintCallable)
    void SetDeviceCableAnimator(UFMDeviceCableAnimatorBase*& InAnimator); // 0x6023a08 (Index: 0x2c, Flags: Final|Native|Public|BlueprintCallable)
    void SetPortActivatedState(EDeviceCableActivatedState& NewActivatedState); // 0x11dcc050 (Index: 0x2d, Flags: Final|Native|Public|BlueprintCallable)
    void SetPortConnectionsDirty(); // 0x11dcc17c (Index: 0x2e, Flags: Final|Native|Public|BlueprintCallable)
    void SetPortSelectableState(EDeviceCablePortSelectableState& NewSelectableState); // 0x11dcc190 (Index: 0x2f, Flags: Final|Native|Public|BlueprintCallable)
    void SetPortVisibility(bool& bPortVisible); // 0x11dcc2c0 (Index: 0x30, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateCableHiddenState(UFMDeviceCablePortComponent*& OtherPort); // 0x11dcc3ec (Index: 0x31, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateCableHiddenStateForConnectedPort(UFMDeviceCablePortComponent*& OtherPort, bool& bNewHidden); // 0x11dcc534 (Index: 0x32, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnFabricGlobalSystemChanged(AFabricGlobalSystem*& OldGlobalSystem, AFabricGlobalSystem*& GlobalSystem); // 0x11dc9d1c (Index: 0x1e, Flags: Final|Native|Private)
    void OnPlayerControllerPortConnected(const TArray<UFMDeviceCablePortComponent*> ControllerPorts); // 0x11dca9a4 (Index: 0x1f, Flags: Final|Native|Private|HasOutParms)
    void OnPlayerControllerPortDisconnected(); // 0x11dcac30 (Index: 0x20, Flags: Final|Native|Private)
    void OnRep_ConstantCable(); // 0x11dcac44 (Index: 0x23, Flags: Final|Native|Private)
    void OnRep_DeviceCableManager(); // 0x11dcac9c (Index: 0x24, Flags: Final|Native|Private)
    void OnRep_ServerConnectedPorts(); // 0x11dcacf4 (Index: 0x25, Flags: Final|Native|Private)
    void OnRep_ServerPortActivatedState(); // 0x11dcad08 (Index: 0x26, Flags: Final|Native|Private)

protected:
    virtual bool ActorHasValidControllerBP(AActor*& Actor, AFortPlayerPawn*& OutFortPlayerPawn, APlayerController*& OutPlayerController); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    void UpdateStaticMesh(); // 0x11dcc75c (Index: 0x33, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFMDeviceCablePortComponent) == 0x920, "Size mismatch for UFMDeviceCablePortComponent");
static_assert(offsetof(UFMDeviceCablePortComponent, OnCablePortSizeUpdated) == 0x640, "Offset mismatch for UFMDeviceCablePortComponent::OnCablePortSizeUpdated");
static_assert(offsetof(UFMDeviceCablePortComponent, OnAnimatorCreated) == 0x650, "Offset mismatch for UFMDeviceCablePortComponent::OnAnimatorCreated");
static_assert(offsetof(UFMDeviceCablePortComponent, OnConnected) == 0x660, "Offset mismatch for UFMDeviceCablePortComponent::OnConnected");
static_assert(offsetof(UFMDeviceCablePortComponent, OnConnectedDuringGameplay) == 0x690, "Offset mismatch for UFMDeviceCablePortComponent::OnConnectedDuringGameplay");
static_assert(offsetof(UFMDeviceCablePortComponent, OnDisconnected) == 0x6a0, "Offset mismatch for UFMDeviceCablePortComponent::OnDisconnected");
static_assert(offsetof(UFMDeviceCablePortComponent, OnConnectionStarted) == 0x6b0, "Offset mismatch for UFMDeviceCablePortComponent::OnConnectionStarted");
static_assert(offsetof(UFMDeviceCablePortComponent, OnConnectionEnded) == 0x6c0, "Offset mismatch for UFMDeviceCablePortComponent::OnConnectionEnded");
static_assert(offsetof(UFMDeviceCablePortComponent, OnPortArtifactUpdated) == 0x6d0, "Offset mismatch for UFMDeviceCablePortComponent::OnPortArtifactUpdated");
static_assert(offsetof(UFMDeviceCablePortComponent, OnReceiveFloatProviders) == 0x6e0, "Offset mismatch for UFMDeviceCablePortComponent::OnReceiveFloatProviders");
static_assert(offsetof(UFMDeviceCablePortComponent, OnDisconnectFloatProvider) == 0x6f0, "Offset mismatch for UFMDeviceCablePortComponent::OnDisconnectFloatProvider");
static_assert(offsetof(UFMDeviceCablePortComponent, DeviceCableManagerClass) == 0x700, "Offset mismatch for UFMDeviceCablePortComponent::DeviceCableManagerClass");
static_assert(offsetof(UFMDeviceCablePortComponent, OutputStaticMesh) == 0x708, "Offset mismatch for UFMDeviceCablePortComponent::OutputStaticMesh");
static_assert(offsetof(UFMDeviceCablePortComponent, AudioInStaticMesh) == 0x728, "Offset mismatch for UFMDeviceCablePortComponent::AudioInStaticMesh");
static_assert(offsetof(UFMDeviceCablePortComponent, NoteInStaticMesh) == 0x748, "Offset mismatch for UFMDeviceCablePortComponent::NoteInStaticMesh");
static_assert(offsetof(UFMDeviceCablePortComponent, TextureInStaticMesh) == 0x768, "Offset mismatch for UFMDeviceCablePortComponent::TextureInStaticMesh");
static_assert(offsetof(UFMDeviceCablePortComponent, MeshInStaticMesh) == 0x788, "Offset mismatch for UFMDeviceCablePortComponent::MeshInStaticMesh");
static_assert(offsetof(UFMDeviceCablePortComponent, ScalarInStaticMesh) == 0x7a8, "Offset mismatch for UFMDeviceCablePortComponent::ScalarInStaticMesh");
static_assert(offsetof(UFMDeviceCablePortComponent, CableAnimatorClasses) == 0x7c8, "Offset mismatch for UFMDeviceCablePortComponent::CableAnimatorClasses");
static_assert(offsetof(UFMDeviceCablePortComponent, PortFlowType) == 0x818, "Offset mismatch for UFMDeviceCablePortComponent::PortFlowType");
static_assert(offsetof(UFMDeviceCablePortComponent, PortDataType) == 0x819, "Offset mismatch for UFMDeviceCablePortComponent::PortDataType");
static_assert(offsetof(UFMDeviceCablePortComponent, PortLoadableState) == 0x81a, "Offset mismatch for UFMDeviceCablePortComponent::PortLoadableState");
static_assert(offsetof(UFMDeviceCablePortComponent, AnimationSyncType) == 0x81b, "Offset mismatch for UFMDeviceCablePortComponent::AnimationSyncType");
static_assert(offsetof(UFMDeviceCablePortComponent, bAllowMultipleConnections) == 0x81c, "Offset mismatch for UFMDeviceCablePortComponent::bAllowMultipleConnections");
static_assert(offsetof(UFMDeviceCablePortComponent, bAllowSiblingConnections) == 0x81d, "Offset mismatch for UFMDeviceCablePortComponent::bAllowSiblingConnections");
static_assert(offsetof(UFMDeviceCablePortComponent, OverrideAllowMultipleConnections) == 0x81e, "Offset mismatch for UFMDeviceCablePortComponent::OverrideAllowMultipleConnections");
static_assert(offsetof(UFMDeviceCablePortComponent, OverrideAllowSiblingConnections) == 0x81f, "Offset mismatch for UFMDeviceCablePortComponent::OverrideAllowSiblingConnections");
static_assert(offsetof(UFMDeviceCablePortComponent, bHideWhenNotRelevant) == 0x820, "Offset mismatch for UFMDeviceCablePortComponent::bHideWhenNotRelevant");
static_assert(offsetof(UFMDeviceCablePortComponent, bIsPlayerPort) == 0x821, "Offset mismatch for UFMDeviceCablePortComponent::bIsPlayerPort");
static_assert(offsetof(UFMDeviceCablePortComponent, bIsOnPreviewBuildingActor) == 0x822, "Offset mismatch for UFMDeviceCablePortComponent::bIsOnPreviewBuildingActor");
static_assert(offsetof(UFMDeviceCablePortComponent, EnterVolumeTag) == 0x824, "Offset mismatch for UFMDeviceCablePortComponent::EnterVolumeTag");
static_assert(offsetof(UFMDeviceCablePortComponent, ExitVolumeTag) == 0x828, "Offset mismatch for UFMDeviceCablePortComponent::ExitVolumeTag");
static_assert(offsetof(UFMDeviceCablePortComponent, ConnectedPorts) == 0x830, "Offset mismatch for UFMDeviceCablePortComponent::ConnectedPorts");
static_assert(offsetof(UFMDeviceCablePortComponent, ServerConnectedPorts) == 0x840, "Offset mismatch for UFMDeviceCablePortComponent::ServerConnectedPorts");
static_assert(offsetof(UFMDeviceCablePortComponent, CurrentConnections) == 0x850, "Offset mismatch for UFMDeviceCablePortComponent::CurrentConnections");
static_assert(offsetof(UFMDeviceCablePortComponent, ConstantCable) == 0x860, "Offset mismatch for UFMDeviceCablePortComponent::ConstantCable");
static_assert(offsetof(UFMDeviceCablePortComponent, DeviceCableManager) == 0x868, "Offset mismatch for UFMDeviceCablePortComponent::DeviceCableManager");
static_assert(offsetof(UFMDeviceCablePortComponent, OtherPortsOnActor) == 0x870, "Offset mismatch for UFMDeviceCablePortComponent::OtherPortsOnActor");
static_assert(offsetof(UFMDeviceCablePortComponent, PortActivatedState) == 0x880, "Offset mismatch for UFMDeviceCablePortComponent::PortActivatedState");
static_assert(offsetof(UFMDeviceCablePortComponent, ServerPortActivatedState) == 0x881, "Offset mismatch for UFMDeviceCablePortComponent::ServerPortActivatedState");
static_assert(offsetof(UFMDeviceCablePortComponent, PortSelectableState) == 0x882, "Offset mismatch for UFMDeviceCablePortComponent::PortSelectableState");
static_assert(offsetof(UFMDeviceCablePortComponent, DeviceCableAnimator) == 0x888, "Offset mismatch for UFMDeviceCablePortComponent::DeviceCableAnimator");
static_assert(offsetof(UFMDeviceCablePortComponent, ConnectionGuid) == 0x890, "Offset mismatch for UFMDeviceCablePortComponent::ConnectionGuid");
static_assert(offsetof(UFMDeviceCablePortComponent, ConnectedGuids) == 0x8a0, "Offset mismatch for UFMDeviceCablePortComponent::ConnectedGuids");
static_assert(offsetof(UFMDeviceCablePortComponent, CachedArtifact) == 0x8b0, "Offset mismatch for UFMDeviceCablePortComponent::CachedArtifact");
static_assert(offsetof(UFMDeviceCablePortComponent, PendingConnectionBroadcasts) == 0x8e0, "Offset mismatch for UFMDeviceCablePortComponent::PendingConnectionBroadcasts");
static_assert(offsetof(UFMDeviceCablePortComponent, SaveGuid) == 0x8f0, "Offset mismatch for UFMDeviceCablePortComponent::SaveGuid");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFMDeviceCablesFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static USoundSourceBus* DeepCopySoundSourceBus(UObject*& const Context, UObject*& Outer, USoundSourceBus*& Source); // 0x11dc8e30 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FSoundSourceBusSendInfo MakeSoundSourceBusSendInfo(USoundSourceBus*& SoundSourceBus); // 0x11dc9890 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UFMDeviceCablesFunctionLibrary) == 0x28, "Size mismatch for UFMDeviceCablesFunctionLibrary");

// Size: 0x2a8 (Inherited: 0x2d0, Single: 0xffffffd8)
class AFMDeviceCableSystem : public AActor
{
public:
};

static_assert(sizeof(AFMDeviceCableSystem) == 0x2a8, "Size mismatch for AFMDeviceCableSystem");

// Size: 0x578 (Inherited: 0xe0, Single: 0x498)
class UFMDeviceCableWildcardOrderingComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    FFMDeviceCableOrderingMovementInfo InputsShowHideMovementInfo; // 0xc0 (Size: 0x30, Type: StructProperty)
    uint8_t Pad_f0[0xb8]; // 0xf0 (Size: 0xb8, Type: PaddingProperty)
    FFMDeviceCableOrderingMovementInfo InOutMovementInfo; // 0x1a8 (Size: 0x30, Type: StructProperty)
    FFMDeviceCableOrderingMovementInfo TransitionMovementInfo; // 0x1d8 (Size: 0x30, Type: StructProperty)
    uint8_t Pad_208[0xb8]; // 0x208 (Size: 0xb8, Type: PaddingProperty)
    FFMDeviceCableOrderingMovementInfo CollapseExpandMovementInfo; // 0x2c0 (Size: 0x30, Type: StructProperty)
    uint8_t Pad_2f0[0xb8]; // 0x2f0 (Size: 0xb8, Type: PaddingProperty)
    FVector CollapsedOutputPosition; // 0x3a8 (Size: 0x18, Type: StructProperty)
    float VisualChangeTimeoutTime; // 0x3c0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c4[0x4]; // 0x3c4 (Size: 0x4, Type: PaddingProperty)
    FName ClosedMeshTag; // 0x3c8 (Size: 0x4, Type: NameProperty)
    FName TopMeshTag; // 0x3cc (Size: 0x4, Type: NameProperty)
    FName MiddleMeshTag; // 0x3d0 (Size: 0x4, Type: NameProperty)
    FName BottomMeshTag; // 0x3d4 (Size: 0x4, Type: NameProperty)
    FName InputPortParentTag; // 0x3d8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3dc[0x4]; // 0x3dc (Size: 0x4, Type: PaddingProperty)
    UStaticMeshComponent* ClosedMesh; // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* TopMesh; // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    TArray<UStaticMeshComponent*> MiddleMeshes; // 0x3f0 (Size: 0x10, Type: ArrayProperty)
    UStaticMeshComponent* BottomMesh; // 0x400 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_408[0x8]; // 0x408 (Size: 0x8, Type: PaddingProperty)
    TArray<UFMDeviceCableWildcardPortComponent*> InputWildcardPorts; // 0x410 (Size: 0x10, Type: ArrayProperty)
    USceneComponent* InputWildcardPortParent; // 0x420 (Size: 0x8, Type: ObjectProperty)
    TArray<UFMDeviceCableWildcardPortComponent*> OutputWildcardPorts; // 0x428 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_438[0x120]; // 0x438 (Size: 0x120, Type: PaddingProperty)
    TArray<FFMDeviceCableOrderingPortState> ServerPortStates; // 0x558 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_568[0x10]; // 0x568 (Size: 0x10, Type: PaddingProperty)

public:
    void SetInputRoot(FVector& RootLocation); // 0x11dcbd8c (Index: 0x9, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetOutputPortsExpanded(bool& bExpanded); // 0x11dcbe58 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void SetOutputRoot(FVector& RootLocation); // 0x11dcbf84 (Index: 0xb, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)

private:
    void InitializeOutputSlots(); // 0x11dc971c (Index: 0x1, Flags: Final|Native|Private)
    void OnInputPortConnected(UFMDeviceCablePortComponent*& ConnectedPort); // 0x11dc9f24 (Index: 0x2, Flags: Final|Native|Private)
    void OnInputPortDataTypeChanged(UFMDeviceCableWildcardPortComponent*& WildcardPort, EDeviceCablePortDataType& DataType); // 0x11dca04c (Index: 0x3, Flags: Final|Native|Private)
    void OnInputPortDisconnected(UFMDeviceCablePortComponent*& DisconnectedPort); // 0x11dca25c (Index: 0x4, Flags: Final|Native|Private)
    void OnOutputPortConnected(UFMDeviceCablePortComponent*& SourcePort, UFMDeviceCablePortComponent*& ConnectedPort); // 0x11dca388 (Index: 0x5, Flags: Final|Native|Private)
    void OnOutputPortDisconnected(UFMDeviceCablePortComponent*& SourcePort, UFMDeviceCablePortComponent*& DisconnectedPort); // 0x11dca590 (Index: 0x6, Flags: Final|Native|Private)
    void OnOutputPortSlotSetFromSave(UFMDeviceCableWildcardPortComponent*& WildcardPort, bool& bHasConnections); // 0x11dca798 (Index: 0x7, Flags: Final|Native|Private)
    void OnRep_ServerPortStates(); // 0x11dcad38 (Index: 0x8, Flags: Final|Native|Private)

protected:
    void FinishVisualChange(); // 0x11dc9334 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFMDeviceCableWildcardOrderingComponent) == 0x578, "Size mismatch for UFMDeviceCableWildcardOrderingComponent");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, InputsShowHideMovementInfo) == 0xc0, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::InputsShowHideMovementInfo");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, InOutMovementInfo) == 0x1a8, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::InOutMovementInfo");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, TransitionMovementInfo) == 0x1d8, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::TransitionMovementInfo");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, CollapseExpandMovementInfo) == 0x2c0, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::CollapseExpandMovementInfo");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, CollapsedOutputPosition) == 0x3a8, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::CollapsedOutputPosition");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, VisualChangeTimeoutTime) == 0x3c0, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::VisualChangeTimeoutTime");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, ClosedMeshTag) == 0x3c8, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::ClosedMeshTag");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, TopMeshTag) == 0x3cc, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::TopMeshTag");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, MiddleMeshTag) == 0x3d0, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::MiddleMeshTag");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, BottomMeshTag) == 0x3d4, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::BottomMeshTag");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, InputPortParentTag) == 0x3d8, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::InputPortParentTag");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, ClosedMesh) == 0x3e0, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::ClosedMesh");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, TopMesh) == 0x3e8, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::TopMesh");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, MiddleMeshes) == 0x3f0, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::MiddleMeshes");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, BottomMesh) == 0x400, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::BottomMesh");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, InputWildcardPorts) == 0x410, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::InputWildcardPorts");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, InputWildcardPortParent) == 0x420, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::InputWildcardPortParent");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, OutputWildcardPorts) == 0x428, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::OutputWildcardPorts");
static_assert(offsetof(UFMDeviceCableWildcardOrderingComponent, ServerPortStates) == 0x558, "Offset mismatch for UFMDeviceCableWildcardOrderingComponent::ServerPortStates");

// Size: 0x960 (Inherited: 0x1cd0, Single: 0xffffec90)
class UFMDeviceCableWildcardPortComponent : public UFMDeviceCablePortComponent
{
public:
    uint8_t OnWildcardDataTypeChanged[0x10]; // 0x920 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnWildcardPortSlotSetFromSave[0x10]; // 0x930 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t SlotIndex; // 0x940 (Size: 0x4, Type: IntProperty)
    int32_t SavedSlotIndex; // 0x944 (Size: 0x4, Type: IntProperty)
    uint8_t SavedPortDataType; // 0x948 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_949[0x17]; // 0x949 (Size: 0x17, Type: PaddingProperty)

public:
    void OnWildcardDataTypeChanged__DelegateSignature(UFMDeviceCableWildcardPortComponent*& WildcardPort, EDeviceCablePortDataType& DataType); // 0x288a61c (Index: 0x4, Flags: MulticastDelegate|Public|Delegate)
    void OnWildcardPortSlotSetFromSave__DelegateSignature(UFMDeviceCableWildcardPortComponent*& WildcardPort, bool& bHasConnections); // 0x288a61c (Index: 0x5, Flags: MulticastDelegate|Public|Delegate)

private:
    void OnPlayerControllerPortConnectedWildcard(const TArray<UFMDeviceCablePortComponent*> ControllerPorts); // 0x11df9910 (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
    void OnPlayerControllerPortDisconnectedWildcard(); // 0x11df9b9c (Index: 0x1, Flags: Final|Native|Private)
    void OnRep_SavedPortDataType(); // 0x11df9bb0 (Index: 0x2, Flags: Final|Native|Private)
    void OnRep_SavedSlotIndex(); // 0x11df9be4 (Index: 0x3, Flags: Final|Native|Private)
};

static_assert(sizeof(UFMDeviceCableWildcardPortComponent) == 0x960, "Size mismatch for UFMDeviceCableWildcardPortComponent");
static_assert(offsetof(UFMDeviceCableWildcardPortComponent, OnWildcardDataTypeChanged) == 0x920, "Offset mismatch for UFMDeviceCableWildcardPortComponent::OnWildcardDataTypeChanged");
static_assert(offsetof(UFMDeviceCableWildcardPortComponent, OnWildcardPortSlotSetFromSave) == 0x930, "Offset mismatch for UFMDeviceCableWildcardPortComponent::OnWildcardPortSlotSetFromSave");
static_assert(offsetof(UFMDeviceCableWildcardPortComponent, SlotIndex) == 0x940, "Offset mismatch for UFMDeviceCableWildcardPortComponent::SlotIndex");
static_assert(offsetof(UFMDeviceCableWildcardPortComponent, SavedSlotIndex) == 0x944, "Offset mismatch for UFMDeviceCableWildcardPortComponent::SavedSlotIndex");
static_assert(offsetof(UFMDeviceCableWildcardPortComponent, SavedPortDataType) == 0x948, "Offset mismatch for UFMDeviceCableWildcardPortComponent::SavedPortDataType");

// Size: 0x320 (Inherited: 0xe0, Single: 0x240)
class UFMDeviceCableManagerComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    UClass* DeviceCableClass; // 0xc0 (Size: 0x8, Type: ClassProperty)
    int32_t StartingCablePoolSize; // 0xc8 (Size: 0x4, Type: IntProperty)
    uint8_t CableInteractionType; // 0xcc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_cd[0x3]; // 0xcd (Size: 0x3, Type: PaddingProperty)
    TMap<UClass*, EDeviceCablePortDataType> ConnectionClasses; // 0xd0 (Size: 0x50, Type: MapProperty)
    FGameplayEventListenerBackwardCompatibleHandle PlayerEnteredHandle; // 0x120 (Size: 0x48, Type: StructProperty)
    TArray<AFMDeviceCable*> FreeDeviceCables; // 0x168 (Size: 0x10, Type: ArrayProperty)
    TMap<UFMDeviceCableConnectionBase*, EDeviceCablePortDataType> CableConnectionsByType; // 0x178 (Size: 0x50, Type: MapProperty)
    TMap<TWeakObjectPtr<UFMDeviceCablePortComponent*>, FGuid> PortsInVolume; // 0x1c8 (Size: 0x50, Type: MapProperty)
    TMap<FGuid, FGuid> OriginalGuidToDuplicatedGuidThisFrame; // 0x218 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_268[0xa0]; // 0x268 (Size: 0xa0, Type: PaddingProperty)
    TArray<TWeakObjectPtr<AFMDeviceCable*>> CablesToBeNotifiedOfVisualPermissions; // 0x308 (Size: 0x10, Type: ArrayProperty)
    bool bVisualPermissionsAlreadyEstablished; // 0x318 (Size: 0x1, Type: BoolProperty)
    bool bUnregisterWithSignificanceSystem; // 0x319 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31a[0x6]; // 0x31a (Size: 0x6, Type: PaddingProperty)

public:
    EDeviceCableInteractionType GetCableInteractionType(); // 0x11a7a9b4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnRep_bUnregisterWithSignificanceSystem(); // 0x11df9c08 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UFMDeviceCableManagerComponent) == 0x320, "Size mismatch for UFMDeviceCableManagerComponent");
static_assert(offsetof(UFMDeviceCableManagerComponent, DeviceCableClass) == 0xc0, "Offset mismatch for UFMDeviceCableManagerComponent::DeviceCableClass");
static_assert(offsetof(UFMDeviceCableManagerComponent, StartingCablePoolSize) == 0xc8, "Offset mismatch for UFMDeviceCableManagerComponent::StartingCablePoolSize");
static_assert(offsetof(UFMDeviceCableManagerComponent, CableInteractionType) == 0xcc, "Offset mismatch for UFMDeviceCableManagerComponent::CableInteractionType");
static_assert(offsetof(UFMDeviceCableManagerComponent, ConnectionClasses) == 0xd0, "Offset mismatch for UFMDeviceCableManagerComponent::ConnectionClasses");
static_assert(offsetof(UFMDeviceCableManagerComponent, PlayerEnteredHandle) == 0x120, "Offset mismatch for UFMDeviceCableManagerComponent::PlayerEnteredHandle");
static_assert(offsetof(UFMDeviceCableManagerComponent, FreeDeviceCables) == 0x168, "Offset mismatch for UFMDeviceCableManagerComponent::FreeDeviceCables");
static_assert(offsetof(UFMDeviceCableManagerComponent, CableConnectionsByType) == 0x178, "Offset mismatch for UFMDeviceCableManagerComponent::CableConnectionsByType");
static_assert(offsetof(UFMDeviceCableManagerComponent, PortsInVolume) == 0x1c8, "Offset mismatch for UFMDeviceCableManagerComponent::PortsInVolume");
static_assert(offsetof(UFMDeviceCableManagerComponent, OriginalGuidToDuplicatedGuidThisFrame) == 0x218, "Offset mismatch for UFMDeviceCableManagerComponent::OriginalGuidToDuplicatedGuidThisFrame");
static_assert(offsetof(UFMDeviceCableManagerComponent, CablesToBeNotifiedOfVisualPermissions) == 0x308, "Offset mismatch for UFMDeviceCableManagerComponent::CablesToBeNotifiedOfVisualPermissions");
static_assert(offsetof(UFMDeviceCableManagerComponent, bVisualPermissionsAlreadyEstablished) == 0x318, "Offset mismatch for UFMDeviceCableManagerComponent::bVisualPermissionsAlreadyEstablished");
static_assert(offsetof(UFMDeviceCableManagerComponent, bUnregisterWithSignificanceSystem) == 0x319, "Offset mismatch for UFMDeviceCableManagerComponent::bUnregisterWithSignificanceSystem");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FPortUpdateInfo
{
    uint8_t PortSelectStatus; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UFMDeviceCablePortComponent* ConstantPort; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* ConnectedPort; // 0x10 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCablePortComponent* DisconnectedPort; // 0x18 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FPortUpdateInfo) == 0x20, "Size mismatch for FPortUpdateInfo");
static_assert(offsetof(FPortUpdateInfo, PortSelectStatus) == 0x0, "Offset mismatch for FPortUpdateInfo::PortSelectStatus");
static_assert(offsetof(FPortUpdateInfo, ConstantPort) == 0x8, "Offset mismatch for FPortUpdateInfo::ConstantPort");
static_assert(offsetof(FPortUpdateInfo, ConnectedPort) == 0x10, "Offset mismatch for FPortUpdateInfo::ConnectedPort");
static_assert(offsetof(FPortUpdateInfo, DisconnectedPort) == 0x18, "Offset mismatch for FPortUpdateInfo::DisconnectedPort");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFMDeviceCableArtifact
{
    UFabricMeshTreeNode* MeshTreeNode; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UFabricMetaSoundTreeNode* MetaSoundTreeNode; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UFabricTextureTreeNode* TextureTreeNode; // 0x10 (Size: 0x8, Type: ObjectProperty)
    UFabricModulationNode* ModulationNode; // 0x18 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFMDeviceCableArtifact) == 0x20, "Size mismatch for FFMDeviceCableArtifact");
static_assert(offsetof(FFMDeviceCableArtifact, MeshTreeNode) == 0x0, "Offset mismatch for FFMDeviceCableArtifact::MeshTreeNode");
static_assert(offsetof(FFMDeviceCableArtifact, MetaSoundTreeNode) == 0x8, "Offset mismatch for FFMDeviceCableArtifact::MetaSoundTreeNode");
static_assert(offsetof(FFMDeviceCableArtifact, TextureTreeNode) == 0x10, "Offset mismatch for FFMDeviceCableArtifact::TextureTreeNode");
static_assert(offsetof(FFMDeviceCableArtifact, ModulationNode) == 0x18, "Offset mismatch for FFMDeviceCableArtifact::ModulationNode");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FModulatorPortSaveData
{
    FGuid ConnectionGuid; // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<FGuid> ConnectedGuids; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FModulatorPortSaveData) == 0x20, "Size mismatch for FModulatorPortSaveData");
static_assert(offsetof(FModulatorPortSaveData, ConnectionGuid) == 0x0, "Offset mismatch for FModulatorPortSaveData::ConnectionGuid");
static_assert(offsetof(FModulatorPortSaveData, ConnectedGuids) == 0x10, "Offset mismatch for FModulatorPortSaveData::ConnectedGuids");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FFMDeviceCableOrderingMovementInfo
{
    UCurveFloat* Curve; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UCurveVector* ScaleCurve; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector Vector; // 0x10 (Size: 0x18, Type: StructProperty)
    float MovementTimeSeconds; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFMDeviceCableOrderingMovementInfo) == 0x30, "Size mismatch for FFMDeviceCableOrderingMovementInfo");
static_assert(offsetof(FFMDeviceCableOrderingMovementInfo, Curve) == 0x0, "Offset mismatch for FFMDeviceCableOrderingMovementInfo::Curve");
static_assert(offsetof(FFMDeviceCableOrderingMovementInfo, ScaleCurve) == 0x8, "Offset mismatch for FFMDeviceCableOrderingMovementInfo::ScaleCurve");
static_assert(offsetof(FFMDeviceCableOrderingMovementInfo, Vector) == 0x10, "Offset mismatch for FFMDeviceCableOrderingMovementInfo::Vector");
static_assert(offsetof(FFMDeviceCableOrderingMovementInfo, MovementTimeSeconds) == 0x28, "Offset mismatch for FFMDeviceCableOrderingMovementInfo::MovementTimeSeconds");

// Size: 0xb8 (Inherited: 0x0, Single: 0xb8)
struct FFMDeviceCableOrderingMovementState
{
};

static_assert(sizeof(FFMDeviceCableOrderingMovementState) == 0xb8, "Size mismatch for FFMDeviceCableOrderingMovementState");

// Size: 0x270 (Inherited: 0x0, Single: 0x270)
struct FFMDeviceCableOrderingPortState
{
    UFMDeviceCableWildcardPortComponent* WildcardPort; // 0x0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* VerticalPositionParent; // 0x8 (Size: 0x8, Type: ObjectProperty)
    uint8_t VisualState[0x4]; // 0x10 (Size: 0x4, Type: EnumProperty)
    uint8_t State[0x4]; // 0x14 (Size: 0x4, Type: EnumProperty)
    int32_t Slot; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t TargetSlot; // 0x1c (Size: 0x4, Type: IntProperty)
    uint8_t Pad_20[0x240]; // 0x20 (Size: 0x240, Type: PaddingProperty)
    TWeakObjectPtr<UFMDeviceCableWildcardOrderingComponent*> Owner; // 0x260 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_268[0x8]; // 0x268 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FFMDeviceCableOrderingPortState) == 0x270, "Size mismatch for FFMDeviceCableOrderingPortState");
static_assert(offsetof(FFMDeviceCableOrderingPortState, WildcardPort) == 0x0, "Offset mismatch for FFMDeviceCableOrderingPortState::WildcardPort");
static_assert(offsetof(FFMDeviceCableOrderingPortState, VerticalPositionParent) == 0x8, "Offset mismatch for FFMDeviceCableOrderingPortState::VerticalPositionParent");
static_assert(offsetof(FFMDeviceCableOrderingPortState, VisualState) == 0x10, "Offset mismatch for FFMDeviceCableOrderingPortState::VisualState");
static_assert(offsetof(FFMDeviceCableOrderingPortState, State) == 0x14, "Offset mismatch for FFMDeviceCableOrderingPortState::State");
static_assert(offsetof(FFMDeviceCableOrderingPortState, Slot) == 0x18, "Offset mismatch for FFMDeviceCableOrderingPortState::Slot");
static_assert(offsetof(FFMDeviceCableOrderingPortState, TargetSlot) == 0x1c, "Offset mismatch for FFMDeviceCableOrderingPortState::TargetSlot");
static_assert(offsetof(FFMDeviceCableOrderingPortState, Owner) == 0x260, "Offset mismatch for FFMDeviceCableOrderingPortState::Owner");

