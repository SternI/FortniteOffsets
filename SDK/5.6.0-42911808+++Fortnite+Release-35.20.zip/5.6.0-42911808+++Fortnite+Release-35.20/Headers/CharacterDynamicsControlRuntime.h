/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CharacterDynamicsControlRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "FortniteGame.h"
#include "CharacterDynamicsControlCore.h"
#include "PhysicsControl.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCharacterDynamicsControlBPLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void AddCharacterDynamicsControlLogicLayer(UFortAnimInstance*& const InAnimInstance, FName& const LayerName, UFortCharacterDynamicsStateLogic*& const LayerStateLogic); // 0x1011b8a4 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FRigidBodyWithControlReference UpdateRigidBodyWithControlNodeParameters(const FAnimUpdateContext UpdateContext, const FRigidBodyWithControlReference RigidBodyWithControl); // 0x1011bf70 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FRigidBodyWithControlReference UpdateRigidBodyWithControlNodeParametersForLayer(const FAnimUpdateContext UpdateContext, const FRigidBodyWithControlReference RigidBodyWithControl, FName& const StateLogicLayerName, UFortCharacterDynamicsParameters*& const Parameters); // 0x1011c134 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    FRigidBodyWithControlReference UpdateRigidBodyWithControlNodeParametersFromAsset(const FAnimUpdateContext UpdateContext, const FRigidBodyWithControlReference RigidBodyWithControl, UFortCharacterDynamicsParameters*& const Parameters); // 0x1011c3f4 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UCharacterDynamicsControlBPLibrary) == 0x28, "Size mismatch for UCharacterDynamicsControlBPLibrary");

// Size: 0x500 (Inherited: 0x5c8, Single: 0xffffff38)
class UCharacterDynamicsControlGameFeatureData : public UFortGameFeatureData
{
public:
    UFortCharacterDynamicsStateLogic* DefaultStateLogic; // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    UFortCharacterDynamicsParameters* DefaultParameters; // 0x4f8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UCharacterDynamicsControlGameFeatureData) == 0x500, "Size mismatch for UCharacterDynamicsControlGameFeatureData");
static_assert(offsetof(UCharacterDynamicsControlGameFeatureData, DefaultStateLogic) == 0x4f0, "Offset mismatch for UCharacterDynamicsControlGameFeatureData::DefaultStateLogic");
static_assert(offsetof(UCharacterDynamicsControlGameFeatureData, DefaultParameters) == 0x4f8, "Offset mismatch for UCharacterDynamicsControlGameFeatureData::DefaultParameters");

// Size: 0x168 (Inherited: 0x198, Single: 0xffffffd0)
class UFortCharacterDynamicsComponent : public UFortCharacterDynamicsComponentInterface
{
public:
    UFortCharacterDynamicsStateLogic* DefaultStateLogic; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UFortCharacterDynamicsParameters* DefaultParameters; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c8[0xa0]; // 0xc8 (Size: 0xa0, Type: PaddingProperty)

public:
    void AddLayer(FName& const LayerName, UFortCharacterDynamicsStateLogic*& const LayerStateLogic); // 0x1011bd64 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortCharacterDynamicsComponent) == 0x168, "Size mismatch for UFortCharacterDynamicsComponent");
static_assert(offsetof(UFortCharacterDynamicsComponent, DefaultStateLogic) == 0xb8, "Offset mismatch for UFortCharacterDynamicsComponent::DefaultStateLogic");
static_assert(offsetof(UFortCharacterDynamicsComponent, DefaultParameters) == 0xc0, "Offset mismatch for UFortCharacterDynamicsComponent::DefaultParameters");

