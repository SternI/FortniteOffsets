/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNE_ConversationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "LocalizableMessage.h"

// Size: 0x300 (Inherited: 0x2d0, Single: 0x30)
class AConversationEntityProxyActor : public AActor
{
public:
    TArray<AController*> ControllersInConversation; // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    USceneComponent* RootSceneComponent; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UFortNonPlayerConversationParticipantComponent* NonPlayerConversationComponent; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    FLocalizableMessage SpeakerName; // 0x2c8 (Size: 0x30, Type: StructProperty)
    UObject* CachedConversationEntityComponent; // 0x2f8 (Size: 0x8, Type: ObjectProperty)

protected:
    void OnRep_ControllersInConversation(); // 0x11465594 (Index: 0x0, Flags: Final|Native|Protected)
    void OnRep_SpeakerName(); // 0x114655a8 (Index: 0x1, Flags: Final|Native|Protected)
    void OnServerConversationEnded(AActor*& ParticipantActorPlayer); // 0x6023a08 (Index: 0x2, Flags: Final|Native|Protected)
    void OnServerConversationStarted(AActor*& ParticipantActorPlayer, const FGameplayTag ParticipantID); // 0x114655bc (Index: 0x3, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(AConversationEntityProxyActor) == 0x300, "Size mismatch for AConversationEntityProxyActor");
static_assert(offsetof(AConversationEntityProxyActor, ControllersInConversation) == 0x2a8, "Offset mismatch for AConversationEntityProxyActor::ControllersInConversation");
static_assert(offsetof(AConversationEntityProxyActor, RootSceneComponent) == 0x2b8, "Offset mismatch for AConversationEntityProxyActor::RootSceneComponent");
static_assert(offsetof(AConversationEntityProxyActor, NonPlayerConversationComponent) == 0x2c0, "Offset mismatch for AConversationEntityProxyActor::NonPlayerConversationComponent");
static_assert(offsetof(AConversationEntityProxyActor, SpeakerName) == 0x2c8, "Offset mismatch for AConversationEntityProxyActor::SpeakerName");
static_assert(offsetof(AConversationEntityProxyActor, CachedConversationEntityComponent) == 0x2f8, "Offset mismatch for AConversationEntityProxyActor::CachedConversationEntityComponent");

// Size: 0x638 (Inherited: 0x8c0, Single: 0xfffffd78)
class UFNE_NonPlayerConversationParticipantComponent : public UFortNonPlayerConversationParticipantComponent
{
public:
};

static_assert(sizeof(UFNE_NonPlayerConversationParticipantComponent) == 0x638, "Size mismatch for UFNE_NonPlayerConversationParticipantComponent");

