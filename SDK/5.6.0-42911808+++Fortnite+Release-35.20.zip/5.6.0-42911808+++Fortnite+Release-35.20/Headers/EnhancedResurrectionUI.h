/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EnhancedResurrectionUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "FortniteGame.h"

// Size: 0x318 (Inherited: 0xa48, Single: 0xfffff8d0)
class UEnhancedResurrectionSelectWidget : public UFortHUDElementWidget
{
public:

protected:
    int32_t GetItemEntryCount(const FFortItemEntry ItemEntry) const; // 0x113d43b0 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UEnhancedResurrectionSelectWidget) == 0x318, "Size mismatch for UEnhancedResurrectionSelectWidget");

