/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarFrontendMinimal
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "VehicleCosmeticsPreviewRuntime.h"
#include "FortniteUI.h"
#include "CosmeticsFrameworkLoadouts.h"

// Size: 0x100 (Inherited: 0xb8, Single: 0x48)
class UDelMarFrontendSubsystem : public UFortLocalPlayerSubsystem
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    TWeakObjectPtr<AVehicleCosmeticsPreviewVehicle*> PreviewVehicle; // 0x38 (Size: 0x8, Type: WeakObjectProperty)
    FFrontendLobbyActor LobbyVehicleActorData; // 0x40 (Size: 0x70, Type: StructProperty)
    FCosmeticLoadoutSlot LobbyVehicleDefaultBody; // 0xb0 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_d0[0x30]; // 0xd0 (Size: 0x30, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarFrontendSubsystem) == 0x100, "Size mismatch for UDelMarFrontendSubsystem");
static_assert(offsetof(UDelMarFrontendSubsystem, PreviewVehicle) == 0x38, "Offset mismatch for UDelMarFrontendSubsystem::PreviewVehicle");
static_assert(offsetof(UDelMarFrontendSubsystem, LobbyVehicleActorData) == 0x40, "Offset mismatch for UDelMarFrontendSubsystem::LobbyVehicleActorData");
static_assert(offsetof(UDelMarFrontendSubsystem, LobbyVehicleDefaultBody) == 0xb0, "Offset mismatch for UDelMarFrontendSubsystem::LobbyVehicleDefaultBody");

