/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataflowCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "DeveloperSettings.h"
#include "Chaos.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDataflowGraphInterface : public UInterface
{
public:
};

static_assert(sizeof(UDataflowGraphInterface) == 0x28, "Size mismatch for UDataflowGraphInterface");

// Size: 0x120 (Inherited: 0x58, Single: 0xc8)
class UDataflowSettings : public UDeveloperSettings
{
public:
    TMap<FNodeColors, FName> NodeColorsMap; // 0x30 (Size: 0x50, Type: MapProperty)
    TMap<FPinSettings, FName> PinSettingsMap; // 0x80 (Size: 0x50, Type: MapProperty)
    FTransformLevelColors TransformLevelColors; // 0xd0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UDataflowSettings) == 0x120, "Size mismatch for UDataflowSettings");
static_assert(offsetof(UDataflowSettings, NodeColorsMap) == 0x30, "Offset mismatch for UDataflowSettings::NodeColorsMap");
static_assert(offsetof(UDataflowSettings, PinSettingsMap) == 0x80, "Offset mismatch for UDataflowSettings::PinSettingsMap");
static_assert(offsetof(UDataflowSettings, TransformLevelColors) == 0xd0, "Offset mismatch for UDataflowSettings::TransformLevelColors");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDataflowAnyType
{
};

static_assert(sizeof(FDataflowAnyType) == 0x1, "Size mismatch for FDataflowAnyType");

// Size: 0x1 (Inherited: 0x1, Single: 0x0)
struct FDataflowAllTypes : FDataflowAnyType
{
};

static_assert(sizeof(FDataflowAllTypes) == 0x1, "Size mismatch for FDataflowAllTypes");

// Size: 0x8 (Inherited: 0x1, Single: 0x7)
struct FDataflowNumericTypes : FDataflowAnyType
{
    double Value; // 0x0 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FDataflowNumericTypes) == 0x8, "Size mismatch for FDataflowNumericTypes");
static_assert(offsetof(FDataflowNumericTypes, Value) == 0x0, "Offset mismatch for FDataflowNumericTypes::Value");

// Size: 0x20 (Inherited: 0x1, Single: 0x1f)
struct FDataflowVectorTypes : FDataflowAnyType
{
    FVector4 Value; // 0x0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDataflowVectorTypes) == 0x20, "Size mismatch for FDataflowVectorTypes");
static_assert(offsetof(FDataflowVectorTypes, Value) == 0x0, "Offset mismatch for FDataflowVectorTypes::Value");

// Size: 0x10 (Inherited: 0x1, Single: 0xf)
struct FDataflowStringTypes : FDataflowAnyType
{
    FString Value; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FDataflowStringTypes) == 0x10, "Size mismatch for FDataflowStringTypes");
static_assert(offsetof(FDataflowStringTypes, Value) == 0x0, "Offset mismatch for FDataflowStringTypes::Value");

// Size: 0x1 (Inherited: 0x1, Single: 0x0)
struct FDataflowBoolTypes : FDataflowAnyType
{
    bool Value; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FDataflowBoolTypes) == 0x1, "Size mismatch for FDataflowBoolTypes");
static_assert(offsetof(FDataflowBoolTypes, Value) == 0x0, "Offset mismatch for FDataflowBoolTypes::Value");

// Size: 0x60 (Inherited: 0x1, Single: 0x5f)
struct FDataflowTransformTypes : FDataflowAnyType
{
    FTransform Value; // 0x0 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FDataflowTransformTypes) == 0x60, "Size mismatch for FDataflowTransformTypes");
static_assert(offsetof(FDataflowTransformTypes, Value) == 0x0, "Offset mismatch for FDataflowTransformTypes::Value");

// Size: 0x10 (Inherited: 0x1, Single: 0xf)
struct FDataflowStringConvertibleTypes : FDataflowAnyType
{
    FString Value; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FDataflowStringConvertibleTypes) == 0x10, "Size mismatch for FDataflowStringConvertibleTypes");
static_assert(offsetof(FDataflowStringConvertibleTypes, Value) == 0x0, "Offset mismatch for FDataflowStringConvertibleTypes::Value");

// Size: 0x8 (Inherited: 0x1, Single: 0x7)
struct FDataflowUObjectConvertibleTypes : FDataflowAnyType
{
    UObject* Value; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDataflowUObjectConvertibleTypes) == 0x8, "Size mismatch for FDataflowUObjectConvertibleTypes");
static_assert(offsetof(FDataflowUObjectConvertibleTypes, Value) == 0x0, "Offset mismatch for FDataflowUObjectConvertibleTypes::Value");

// Size: 0x28 (Inherited: 0x1, Single: 0x27)
struct FDataflowSelectionTypes : FDataflowAnyType
{
    FDataflowSelection Value; // 0x0 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FDataflowSelectionTypes) == 0x28, "Size mismatch for FDataflowSelectionTypes");
static_assert(offsetof(FDataflowSelectionTypes, Value) == 0x0, "Offset mismatch for FDataflowSelectionTypes::Value");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDataflowSelection
{
};

static_assert(sizeof(FDataflowSelection) == 0x28, "Size mismatch for FDataflowSelection");

// Size: 0x10 (Inherited: 0x1, Single: 0xf)
struct FDataflowVectorArrayTypes : FDataflowAnyType
{
    TArray<FVector4> Value; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDataflowVectorArrayTypes) == 0x10, "Size mismatch for FDataflowVectorArrayTypes");
static_assert(offsetof(FDataflowVectorArrayTypes, Value) == 0x0, "Offset mismatch for FDataflowVectorArrayTypes::Value");

// Size: 0x10 (Inherited: 0x1, Single: 0xf)
struct FDataflowNumericArrayTypes : FDataflowAnyType
{
    TArray<double> Value; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDataflowNumericArrayTypes) == 0x10, "Size mismatch for FDataflowNumericArrayTypes");
static_assert(offsetof(FDataflowNumericArrayTypes, Value) == 0x0, "Offset mismatch for FDataflowNumericArrayTypes::Value");

// Size: 0x10 (Inherited: 0x1, Single: 0xf)
struct FDataflowStringArrayTypes : FDataflowAnyType
{
    TArray<FString> Value; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDataflowStringArrayTypes) == 0x10, "Size mismatch for FDataflowStringArrayTypes");
static_assert(offsetof(FDataflowStringArrayTypes, Value) == 0x0, "Offset mismatch for FDataflowStringArrayTypes::Value");

// Size: 0x10 (Inherited: 0x1, Single: 0xf)
struct FDataflowBoolArrayTypes : FDataflowAnyType
{
    TArray<bool> Value; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDataflowBoolArrayTypes) == 0x10, "Size mismatch for FDataflowBoolArrayTypes");
static_assert(offsetof(FDataflowBoolArrayTypes, Value) == 0x0, "Offset mismatch for FDataflowBoolArrayTypes::Value");

// Size: 0x10 (Inherited: 0x1, Single: 0xf)
struct FDataflowTransformArrayTypes : FDataflowAnyType
{
    TArray<FTransform> Value; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDataflowTransformArrayTypes) == 0x10, "Size mismatch for FDataflowTransformArrayTypes");
static_assert(offsetof(FDataflowTransformArrayTypes, Value) == 0x0, "Offset mismatch for FDataflowTransformArrayTypes::Value");

// Size: 0x18 (Inherited: 0x1, Single: 0x17)
struct FDataflowRotationTypes : FDataflowAnyType
{
    FRotator Value; // 0x0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDataflowRotationTypes) == 0x18, "Size mismatch for FDataflowRotationTypes");
static_assert(offsetof(FDataflowRotationTypes, Value) == 0x0, "Offset mismatch for FDataflowRotationTypes::Value");

// Size: 0x270 (Inherited: 0x0, Single: 0x270)
struct FDataflowNode
{
    bool bActive; // 0xc8 (Size: 0x1, Type: BoolProperty)
    bool bOverrideColor; // 0xc9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ca[0x2]; // 0xca (Size: 0x2, Type: PaddingProperty)
    FLinearColor OverrideColor; // 0xcc (Size: 0x10, Type: StructProperty)
    uint8_t Pad_dc[0x144]; // 0xdc (Size: 0x144, Type: PaddingProperty)
    FInstancedPropertyBag FrozenProperties; // 0x220 (Size: 0x10, Type: StructProperty)
    bool bIsFrozen; // 0x230 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_231[0x3f]; // 0x231 (Size: 0x3f, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowNode) == 0x270, "Size mismatch for FDataflowNode");
static_assert(offsetof(FDataflowNode, bActive) == 0xc8, "Offset mismatch for FDataflowNode::bActive");
static_assert(offsetof(FDataflowNode, bOverrideColor) == 0xc9, "Offset mismatch for FDataflowNode::bOverrideColor");
static_assert(offsetof(FDataflowNode, OverrideColor) == 0xcc, "Offset mismatch for FDataflowNode::OverrideColor");
static_assert(offsetof(FDataflowNode, FrozenProperties) == 0x220, "Offset mismatch for FDataflowNode::FrozenProperties");
static_assert(offsetof(FDataflowNode, bIsFrozen) == 0x230, "Offset mismatch for FDataflowNode::bIsFrozen");

// Size: 0x280 (Inherited: 0x270, Single: 0x10)
struct FConvertNumericTypesDataflowNode : FDataflowNode
{
    FDataflowNumericTypes In; // 0x270 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Out; // 0x278 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FConvertNumericTypesDataflowNode) == 0x280, "Size mismatch for FConvertNumericTypesDataflowNode");
static_assert(offsetof(FConvertNumericTypesDataflowNode, In) == 0x270, "Offset mismatch for FConvertNumericTypesDataflowNode::In");
static_assert(offsetof(FConvertNumericTypesDataflowNode, Out) == 0x278, "Offset mismatch for FConvertNumericTypesDataflowNode::Out");

// Size: 0x2b0 (Inherited: 0x270, Single: 0x40)
struct FConvertVectorTypesDataflowNode : FDataflowNode
{
    FDataflowVectorTypes In; // 0x270 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes Out; // 0x290 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FConvertVectorTypesDataflowNode) == 0x2b0, "Size mismatch for FConvertVectorTypesDataflowNode");
static_assert(offsetof(FConvertVectorTypesDataflowNode, In) == 0x270, "Offset mismatch for FConvertVectorTypesDataflowNode::In");
static_assert(offsetof(FConvertVectorTypesDataflowNode, Out) == 0x290, "Offset mismatch for FConvertVectorTypesDataflowNode::Out");

// Size: 0x290 (Inherited: 0x270, Single: 0x20)
struct FConvertStringTypesDataflowNode : FDataflowNode
{
    FDataflowStringTypes In; // 0x270 (Size: 0x10, Type: StructProperty)
    FDataflowStringTypes Out; // 0x280 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FConvertStringTypesDataflowNode) == 0x290, "Size mismatch for FConvertStringTypesDataflowNode");
static_assert(offsetof(FConvertStringTypesDataflowNode, In) == 0x270, "Offset mismatch for FConvertStringTypesDataflowNode::In");
static_assert(offsetof(FConvertStringTypesDataflowNode, Out) == 0x280, "Offset mismatch for FConvertStringTypesDataflowNode::Out");

// Size: 0x278 (Inherited: 0x270, Single: 0x8)
struct FConvertBoolTypesDataflowNode : FDataflowNode
{
    FDataflowBoolTypes In; // 0x270 (Size: 0x1, Type: StructProperty)
    FDataflowBoolTypes Out; // 0x271 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_272[0x6]; // 0x272 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FConvertBoolTypesDataflowNode) == 0x278, "Size mismatch for FConvertBoolTypesDataflowNode");
static_assert(offsetof(FConvertBoolTypesDataflowNode, In) == 0x270, "Offset mismatch for FConvertBoolTypesDataflowNode::In");
static_assert(offsetof(FConvertBoolTypesDataflowNode, Out) == 0x271, "Offset mismatch for FConvertBoolTypesDataflowNode::Out");

// Size: 0x330 (Inherited: 0x270, Single: 0xc0)
struct FConvertTransformTypesDataflowNode : FDataflowNode
{
    FDataflowTransformTypes In; // 0x270 (Size: 0x60, Type: StructProperty)
    FDataflowTransformTypes Out; // 0x2d0 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FConvertTransformTypesDataflowNode) == 0x330, "Size mismatch for FConvertTransformTypesDataflowNode");
static_assert(offsetof(FConvertTransformTypesDataflowNode, In) == 0x270, "Offset mismatch for FConvertTransformTypesDataflowNode::In");
static_assert(offsetof(FConvertTransformTypesDataflowNode, Out) == 0x2d0, "Offset mismatch for FConvertTransformTypesDataflowNode::Out");

// Size: 0x290 (Inherited: 0x270, Single: 0x20)
struct FConvertStringConvertibleTypesDataflowNode : FDataflowNode
{
    FDataflowStringConvertibleTypes In; // 0x270 (Size: 0x10, Type: StructProperty)
    FDataflowStringConvertibleTypes Out; // 0x280 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FConvertStringConvertibleTypesDataflowNode) == 0x290, "Size mismatch for FConvertStringConvertibleTypesDataflowNode");
static_assert(offsetof(FConvertStringConvertibleTypesDataflowNode, In) == 0x270, "Offset mismatch for FConvertStringConvertibleTypesDataflowNode::In");
static_assert(offsetof(FConvertStringConvertibleTypesDataflowNode, Out) == 0x280, "Offset mismatch for FConvertStringConvertibleTypesDataflowNode::Out");

// Size: 0x280 (Inherited: 0x270, Single: 0x10)
struct FConvertUObjectConvertibleTypesDataflowNode : FDataflowNode
{
    FDataflowUObjectConvertibleTypes In; // 0x270 (Size: 0x8, Type: StructProperty)
    FDataflowUObjectConvertibleTypes Out; // 0x278 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FConvertUObjectConvertibleTypesDataflowNode) == 0x280, "Size mismatch for FConvertUObjectConvertibleTypesDataflowNode");
static_assert(offsetof(FConvertUObjectConvertibleTypesDataflowNode, In) == 0x270, "Offset mismatch for FConvertUObjectConvertibleTypesDataflowNode::In");
static_assert(offsetof(FConvertUObjectConvertibleTypesDataflowNode, Out) == 0x278, "Offset mismatch for FConvertUObjectConvertibleTypesDataflowNode::Out");

// Size: 0x378 (Inherited: 0x270, Single: 0x108)
struct FConvertSelectionTypesDataflowNode : FDataflowNode
{
    FManagedArrayCollection Collection; // 0x270 (Size: 0xb0, Type: StructProperty)
    FDataflowSelectionTypes In; // 0x320 (Size: 0x28, Type: StructProperty)
    bool bAllElementsMustBeSelected; // 0x348 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_349[0x7]; // 0x349 (Size: 0x7, Type: PaddingProperty)
    FDataflowSelectionTypes Out; // 0x350 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FConvertSelectionTypesDataflowNode) == 0x378, "Size mismatch for FConvertSelectionTypesDataflowNode");
static_assert(offsetof(FConvertSelectionTypesDataflowNode, Collection) == 0x270, "Offset mismatch for FConvertSelectionTypesDataflowNode::Collection");
static_assert(offsetof(FConvertSelectionTypesDataflowNode, In) == 0x320, "Offset mismatch for FConvertSelectionTypesDataflowNode::In");
static_assert(offsetof(FConvertSelectionTypesDataflowNode, bAllElementsMustBeSelected) == 0x348, "Offset mismatch for FConvertSelectionTypesDataflowNode::bAllElementsMustBeSelected");
static_assert(offsetof(FConvertSelectionTypesDataflowNode, Out) == 0x350, "Offset mismatch for FConvertSelectionTypesDataflowNode::Out");

// Size: 0x290 (Inherited: 0x270, Single: 0x20)
struct FConvertVectorArrayTypesDataflowNode : FDataflowNode
{
    FDataflowVectorArrayTypes In; // 0x270 (Size: 0x10, Type: StructProperty)
    FDataflowVectorArrayTypes Out; // 0x280 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FConvertVectorArrayTypesDataflowNode) == 0x290, "Size mismatch for FConvertVectorArrayTypesDataflowNode");
static_assert(offsetof(FConvertVectorArrayTypesDataflowNode, In) == 0x270, "Offset mismatch for FConvertVectorArrayTypesDataflowNode::In");
static_assert(offsetof(FConvertVectorArrayTypesDataflowNode, Out) == 0x280, "Offset mismatch for FConvertVectorArrayTypesDataflowNode::Out");

// Size: 0x290 (Inherited: 0x270, Single: 0x20)
struct FConvertNumericArrayTypesDataflowNode : FDataflowNode
{
    FDataflowNumericArrayTypes In; // 0x270 (Size: 0x10, Type: StructProperty)
    FDataflowNumericArrayTypes Out; // 0x280 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FConvertNumericArrayTypesDataflowNode) == 0x290, "Size mismatch for FConvertNumericArrayTypesDataflowNode");
static_assert(offsetof(FConvertNumericArrayTypesDataflowNode, In) == 0x270, "Offset mismatch for FConvertNumericArrayTypesDataflowNode::In");
static_assert(offsetof(FConvertNumericArrayTypesDataflowNode, Out) == 0x280, "Offset mismatch for FConvertNumericArrayTypesDataflowNode::Out");

// Size: 0x290 (Inherited: 0x270, Single: 0x20)
struct FConvertStringArrayTypesDataflowNode : FDataflowNode
{
    FDataflowStringArrayTypes In; // 0x270 (Size: 0x10, Type: StructProperty)
    FDataflowStringArrayTypes Out; // 0x280 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FConvertStringArrayTypesDataflowNode) == 0x290, "Size mismatch for FConvertStringArrayTypesDataflowNode");
static_assert(offsetof(FConvertStringArrayTypesDataflowNode, In) == 0x270, "Offset mismatch for FConvertStringArrayTypesDataflowNode::In");
static_assert(offsetof(FConvertStringArrayTypesDataflowNode, Out) == 0x280, "Offset mismatch for FConvertStringArrayTypesDataflowNode::Out");

// Size: 0x290 (Inherited: 0x270, Single: 0x20)
struct FConvertBoolArrayTypesDataflowNode : FDataflowNode
{
    FDataflowBoolArrayTypes In; // 0x270 (Size: 0x10, Type: StructProperty)
    FDataflowBoolArrayTypes Out; // 0x280 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FConvertBoolArrayTypesDataflowNode) == 0x290, "Size mismatch for FConvertBoolArrayTypesDataflowNode");
static_assert(offsetof(FConvertBoolArrayTypesDataflowNode, In) == 0x270, "Offset mismatch for FConvertBoolArrayTypesDataflowNode::In");
static_assert(offsetof(FConvertBoolArrayTypesDataflowNode, Out) == 0x280, "Offset mismatch for FConvertBoolArrayTypesDataflowNode::Out");

// Size: 0x290 (Inherited: 0x270, Single: 0x20)
struct FConvertTransformArrayTypesDataflowNode : FDataflowNode
{
    FDataflowTransformArrayTypes In; // 0x270 (Size: 0x10, Type: StructProperty)
    FDataflowTransformArrayTypes Out; // 0x280 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FConvertTransformArrayTypesDataflowNode) == 0x290, "Size mismatch for FConvertTransformArrayTypesDataflowNode");
static_assert(offsetof(FConvertTransformArrayTypesDataflowNode, In) == 0x270, "Offset mismatch for FConvertTransformArrayTypesDataflowNode::In");
static_assert(offsetof(FConvertTransformArrayTypesDataflowNode, Out) == 0x280, "Offset mismatch for FConvertTransformArrayTypesDataflowNode::Out");

// Size: 0x2a0 (Inherited: 0x270, Single: 0x30)
struct FConvertRotationDataflowNode : FDataflowNode
{
    FDataflowRotationTypes In; // 0x270 (Size: 0x18, Type: StructProperty)
    FDataflowRotationTypes Out; // 0x288 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FConvertRotationDataflowNode) == 0x2a0, "Size mismatch for FConvertRotationDataflowNode");
static_assert(offsetof(FConvertRotationDataflowNode, In) == 0x270, "Offset mismatch for FConvertRotationDataflowNode::In");
static_assert(offsetof(FConvertRotationDataflowNode, Out) == 0x288, "Offset mismatch for FConvertRotationDataflowNode::Out");

// Size: 0x278 (Inherited: 0x270, Single: 0x8)
struct FDataflowReRouteNode : FDataflowNode
{
    FDataflowAnyType Value; // 0x270 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_271[0x7]; // 0x271 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowReRouteNode) == 0x278, "Size mismatch for FDataflowReRouteNode");
static_assert(offsetof(FDataflowReRouteNode, Value) == 0x270, "Offset mismatch for FDataflowReRouteNode::Value");

// Size: 0x278 (Inherited: 0x270, Single: 0x8)
struct FDataflowBranchNode : FDataflowNode
{
    FDataflowAnyType TrueValue; // 0x270 (Size: 0x1, Type: StructProperty)
    FDataflowAnyType FalseValue; // 0x271 (Size: 0x1, Type: StructProperty)
    bool bCondition; // 0x272 (Size: 0x1, Type: BoolProperty)
    FDataflowAnyType Result; // 0x273 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_274[0x4]; // 0x274 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowBranchNode) == 0x278, "Size mismatch for FDataflowBranchNode");
static_assert(offsetof(FDataflowBranchNode, TrueValue) == 0x270, "Offset mismatch for FDataflowBranchNode::TrueValue");
static_assert(offsetof(FDataflowBranchNode, FalseValue) == 0x271, "Offset mismatch for FDataflowBranchNode::FalseValue");
static_assert(offsetof(FDataflowBranchNode, bCondition) == 0x272, "Offset mismatch for FDataflowBranchNode::bCondition");
static_assert(offsetof(FDataflowBranchNode, Result) == 0x273, "Offset mismatch for FDataflowBranchNode::Result");

// Size: 0x288 (Inherited: 0x270, Single: 0x18)
struct FDataflowSelectNode : FDataflowNode
{
    TArray<FDataflowAnyType> Inputs; // 0x270 (Size: 0x10, Type: ArrayProperty)
    int32_t SelectedIndex; // 0x280 (Size: 0x4, Type: IntProperty)
    FDataflowAnyType Result; // 0x284 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_285[0x3]; // 0x285 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowSelectNode) == 0x288, "Size mismatch for FDataflowSelectNode");
static_assert(offsetof(FDataflowSelectNode, Inputs) == 0x270, "Offset mismatch for FDataflowSelectNode::Inputs");
static_assert(offsetof(FDataflowSelectNode, SelectedIndex) == 0x280, "Offset mismatch for FDataflowSelectNode::SelectedIndex");
static_assert(offsetof(FDataflowSelectNode, Result) == 0x284, "Offset mismatch for FDataflowSelectNode::Result");

// Size: 0x280 (Inherited: 0x270, Single: 0x10)
struct FDataflowPrintNode : FDataflowNode
{
    FDataflowStringConvertibleTypes Value; // 0x270 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FDataflowPrintNode) == 0x280, "Size mismatch for FDataflowPrintNode");
static_assert(offsetof(FDataflowPrintNode, Value) == 0x270, "Offset mismatch for FDataflowPrintNode::Value");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDataflowImage
{
};

static_assert(sizeof(FDataflowImage) == 0x28, "Size mismatch for FDataflowImage");

// Size: 0x2b0 (Inherited: 0x270, Single: 0x40)
struct FDataflowImageFromColorNode : FDataflowNode
{
    FLinearColor FillColor; // 0x270 (Size: 0x10, Type: StructProperty)
    uint8_t Resolution[0x4]; // 0x280 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_284[0x4]; // 0x284 (Size: 0x4, Type: PaddingProperty)
    FDataflowImage Image; // 0x288 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FDataflowImageFromColorNode) == 0x2b0, "Size mismatch for FDataflowImageFromColorNode");
static_assert(offsetof(FDataflowImageFromColorNode, FillColor) == 0x270, "Offset mismatch for FDataflowImageFromColorNode::FillColor");
static_assert(offsetof(FDataflowImageFromColorNode, Resolution) == 0x280, "Offset mismatch for FDataflowImageFromColorNode::Resolution");
static_assert(offsetof(FDataflowImageFromColorNode, Image) == 0x288, "Offset mismatch for FDataflowImageFromColorNode::Image");

// Size: 0x338 (Inherited: 0x270, Single: 0xc8)
struct FDataflowImageSplitChannelsNode : FDataflowNode
{
    FDataflowImage Image; // 0x270 (Size: 0x28, Type: StructProperty)
    FDataflowImage Red; // 0x298 (Size: 0x28, Type: StructProperty)
    FDataflowImage Green; // 0x2c0 (Size: 0x28, Type: StructProperty)
    FDataflowImage Blue; // 0x2e8 (Size: 0x28, Type: StructProperty)
    FDataflowImage Alpha; // 0x310 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FDataflowImageSplitChannelsNode) == 0x338, "Size mismatch for FDataflowImageSplitChannelsNode");
static_assert(offsetof(FDataflowImageSplitChannelsNode, Image) == 0x270, "Offset mismatch for FDataflowImageSplitChannelsNode::Image");
static_assert(offsetof(FDataflowImageSplitChannelsNode, Red) == 0x298, "Offset mismatch for FDataflowImageSplitChannelsNode::Red");
static_assert(offsetof(FDataflowImageSplitChannelsNode, Green) == 0x2c0, "Offset mismatch for FDataflowImageSplitChannelsNode::Green");
static_assert(offsetof(FDataflowImageSplitChannelsNode, Blue) == 0x2e8, "Offset mismatch for FDataflowImageSplitChannelsNode::Blue");
static_assert(offsetof(FDataflowImageSplitChannelsNode, Alpha) == 0x310, "Offset mismatch for FDataflowImageSplitChannelsNode::Alpha");

// Size: 0x340 (Inherited: 0x270, Single: 0xd0)
struct FDataflowImageCombineChannelsNode : FDataflowNode
{
    FDataflowImage Red; // 0x270 (Size: 0x28, Type: StructProperty)
    FDataflowImage Green; // 0x298 (Size: 0x28, Type: StructProperty)
    FDataflowImage Blue; // 0x2c0 (Size: 0x28, Type: StructProperty)
    FDataflowImage Alpha; // 0x2e8 (Size: 0x28, Type: StructProperty)
    FDataflowImage Image; // 0x310 (Size: 0x28, Type: StructProperty)
    uint8_t ResolutionOptions[0x4]; // 0x338 (Size: 0x4, Type: EnumProperty)
    uint8_t Resolution[0x4]; // 0x33c (Size: 0x4, Type: EnumProperty)
};

static_assert(sizeof(FDataflowImageCombineChannelsNode) == 0x340, "Size mismatch for FDataflowImageCombineChannelsNode");
static_assert(offsetof(FDataflowImageCombineChannelsNode, Red) == 0x270, "Offset mismatch for FDataflowImageCombineChannelsNode::Red");
static_assert(offsetof(FDataflowImageCombineChannelsNode, Green) == 0x298, "Offset mismatch for FDataflowImageCombineChannelsNode::Green");
static_assert(offsetof(FDataflowImageCombineChannelsNode, Blue) == 0x2c0, "Offset mismatch for FDataflowImageCombineChannelsNode::Blue");
static_assert(offsetof(FDataflowImageCombineChannelsNode, Alpha) == 0x2e8, "Offset mismatch for FDataflowImageCombineChannelsNode::Alpha");
static_assert(offsetof(FDataflowImageCombineChannelsNode, Image) == 0x310, "Offset mismatch for FDataflowImageCombineChannelsNode::Image");
static_assert(offsetof(FDataflowImageCombineChannelsNode, ResolutionOptions) == 0x338, "Offset mismatch for FDataflowImageCombineChannelsNode::ResolutionOptions");
static_assert(offsetof(FDataflowImageCombineChannelsNode, Resolution) == 0x33c, "Offset mismatch for FDataflowImageCombineChannelsNode::Resolution");

// Size: 0x280 (Inherited: 0x270, Single: 0x10)
struct FDataflowMathOneInputOperatorNode : FDataflowNode
{
    FDataflowNumericTypes A; // 0x270 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Result; // 0x278 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FDataflowMathOneInputOperatorNode) == 0x280, "Size mismatch for FDataflowMathOneInputOperatorNode");
static_assert(offsetof(FDataflowMathOneInputOperatorNode, A) == 0x270, "Offset mismatch for FDataflowMathOneInputOperatorNode::A");
static_assert(offsetof(FDataflowMathOneInputOperatorNode, Result) == 0x278, "Offset mismatch for FDataflowMathOneInputOperatorNode::Result");

// Size: 0x288 (Inherited: 0x270, Single: 0x18)
struct FDataflowMathTwoInputsOperatorNode : FDataflowNode
{
    FDataflowNumericTypes A; // 0x270 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes B; // 0x278 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Result; // 0x280 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FDataflowMathTwoInputsOperatorNode) == 0x288, "Size mismatch for FDataflowMathTwoInputsOperatorNode");
static_assert(offsetof(FDataflowMathTwoInputsOperatorNode, A) == 0x270, "Offset mismatch for FDataflowMathTwoInputsOperatorNode::A");
static_assert(offsetof(FDataflowMathTwoInputsOperatorNode, B) == 0x278, "Offset mismatch for FDataflowMathTwoInputsOperatorNode::B");
static_assert(offsetof(FDataflowMathTwoInputsOperatorNode, Result) == 0x280, "Offset mismatch for FDataflowMathTwoInputsOperatorNode::Result");

// Size: 0x288 (Inherited: 0x4f8, Single: 0xfffffd90)
struct FDataflowMathAddNode : FDataflowMathTwoInputsOperatorNode
{
};

static_assert(sizeof(FDataflowMathAddNode) == 0x288, "Size mismatch for FDataflowMathAddNode");

// Size: 0x288 (Inherited: 0x4f8, Single: 0xfffffd90)
struct FDataflowMathSubtractNode : FDataflowMathTwoInputsOperatorNode
{
};

static_assert(sizeof(FDataflowMathSubtractNode) == 0x288, "Size mismatch for FDataflowMathSubtractNode");

// Size: 0x288 (Inherited: 0x4f8, Single: 0xfffffd90)
struct FDataflowMathMultiplyNode : FDataflowMathTwoInputsOperatorNode
{
};

static_assert(sizeof(FDataflowMathMultiplyNode) == 0x288, "Size mismatch for FDataflowMathMultiplyNode");

// Size: 0x290 (Inherited: 0x4f8, Single: 0xfffffd98)
struct FDataflowMathDivideNode : FDataflowMathTwoInputsOperatorNode
{
    FDataflowNumericTypes Fallback; // 0x288 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FDataflowMathDivideNode) == 0x290, "Size mismatch for FDataflowMathDivideNode");
static_assert(offsetof(FDataflowMathDivideNode, Fallback) == 0x288, "Offset mismatch for FDataflowMathDivideNode::Fallback");

// Size: 0x288 (Inherited: 0x4f8, Single: 0xfffffd90)
struct FDataflowMathMinimumNode : FDataflowMathTwoInputsOperatorNode
{
};

static_assert(sizeof(FDataflowMathMinimumNode) == 0x288, "Size mismatch for FDataflowMathMinimumNode");

// Size: 0x288 (Inherited: 0x270, Single: 0x18)
struct FDataflowMathMinimumNode_v2 : FDataflowNode
{
    TArray<FDataflowNumericTypes> Inputs; // 0x270 (Size: 0x10, Type: ArrayProperty)
    FDataflowNumericTypes Result; // 0x280 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FDataflowMathMinimumNode_v2) == 0x288, "Size mismatch for FDataflowMathMinimumNode_v2");
static_assert(offsetof(FDataflowMathMinimumNode_v2, Inputs) == 0x270, "Offset mismatch for FDataflowMathMinimumNode_v2::Inputs");
static_assert(offsetof(FDataflowMathMinimumNode_v2, Result) == 0x280, "Offset mismatch for FDataflowMathMinimumNode_v2::Result");

// Size: 0x288 (Inherited: 0x4f8, Single: 0xfffffd90)
struct FDataflowMathMaximumNode : FDataflowMathTwoInputsOperatorNode
{
};

static_assert(sizeof(FDataflowMathMaximumNode) == 0x288, "Size mismatch for FDataflowMathMaximumNode");

// Size: 0x288 (Inherited: 0x270, Single: 0x18)
struct FDataflowMathMaximumNode_v2 : FDataflowNode
{
    TArray<FDataflowNumericTypes> Inputs; // 0x270 (Size: 0x10, Type: ArrayProperty)
    FDataflowNumericTypes Result; // 0x280 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FDataflowMathMaximumNode_v2) == 0x288, "Size mismatch for FDataflowMathMaximumNode_v2");
static_assert(offsetof(FDataflowMathMaximumNode_v2, Inputs) == 0x270, "Offset mismatch for FDataflowMathMaximumNode_v2::Inputs");
static_assert(offsetof(FDataflowMathMaximumNode_v2, Result) == 0x280, "Offset mismatch for FDataflowMathMaximumNode_v2::Result");

// Size: 0x288 (Inherited: 0x4f0, Single: 0xfffffd98)
struct FDataflowMathReciprocalNode : FDataflowMathOneInputOperatorNode
{
    FDataflowNumericTypes Fallback; // 0x280 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FDataflowMathReciprocalNode) == 0x288, "Size mismatch for FDataflowMathReciprocalNode");
static_assert(offsetof(FDataflowMathReciprocalNode, Fallback) == 0x280, "Offset mismatch for FDataflowMathReciprocalNode::Fallback");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathSquareNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathSquareNode) == 0x280, "Size mismatch for FDataflowMathSquareNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathCubeNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathCubeNode) == 0x280, "Size mismatch for FDataflowMathCubeNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathSquareRootNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathSquareRootNode) == 0x280, "Size mismatch for FDataflowMathSquareRootNode");

// Size: 0x288 (Inherited: 0x4f0, Single: 0xfffffd98)
struct FDataflowMathInverseSquareRootNode : FDataflowMathOneInputOperatorNode
{
    FDataflowNumericTypes Fallback; // 0x280 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FDataflowMathInverseSquareRootNode) == 0x288, "Size mismatch for FDataflowMathInverseSquareRootNode");
static_assert(offsetof(FDataflowMathInverseSquareRootNode, Fallback) == 0x280, "Offset mismatch for FDataflowMathInverseSquareRootNode::Fallback");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathNegateNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathNegateNode) == 0x280, "Size mismatch for FDataflowMathNegateNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathAbsNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathAbsNode) == 0x280, "Size mismatch for FDataflowMathAbsNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathFloorNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathFloorNode) == 0x280, "Size mismatch for FDataflowMathFloorNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathCeilNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathCeilNode) == 0x280, "Size mismatch for FDataflowMathCeilNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathRoundNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathRoundNode) == 0x280, "Size mismatch for FDataflowMathRoundNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathTruncNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathTruncNode) == 0x280, "Size mismatch for FDataflowMathTruncNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathFracNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathFracNode) == 0x280, "Size mismatch for FDataflowMathFracNode");

// Size: 0x288 (Inherited: 0x4f8, Single: 0xfffffd90)
struct FDataflowMathPowNode : FDataflowMathTwoInputsOperatorNode
{
};

static_assert(sizeof(FDataflowMathPowNode) == 0x288, "Size mismatch for FDataflowMathPowNode");

// Size: 0x288 (Inherited: 0x4f0, Single: 0xfffffd98)
struct FDataflowMathLogXNode : FDataflowMathOneInputOperatorNode
{
    FDataflowNumericTypes base; // 0x280 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FDataflowMathLogXNode) == 0x288, "Size mismatch for FDataflowMathLogXNode");
static_assert(offsetof(FDataflowMathLogXNode, base) == 0x280, "Offset mismatch for FDataflowMathLogXNode::base");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathLogNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathLogNode) == 0x280, "Size mismatch for FDataflowMathLogNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathExpNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathExpNode) == 0x280, "Size mismatch for FDataflowMathExpNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathSignNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathSignNode) == 0x280, "Size mismatch for FDataflowMathSignNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathOneMinusNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathOneMinusNode) == 0x280, "Size mismatch for FDataflowMathOneMinusNode");

// Size: 0x280 (Inherited: 0x270, Single: 0x10)
struct FDataflowMathConstantNode : FDataflowNode
{
    uint8_t Constant; // 0x270 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_271[0x7]; // 0x271 (Size: 0x7, Type: PaddingProperty)
    FDataflowNumericTypes Result; // 0x278 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FDataflowMathConstantNode) == 0x280, "Size mismatch for FDataflowMathConstantNode");
static_assert(offsetof(FDataflowMathConstantNode, Constant) == 0x270, "Offset mismatch for FDataflowMathConstantNode::Constant");
static_assert(offsetof(FDataflowMathConstantNode, Result) == 0x278, "Offset mismatch for FDataflowMathConstantNode::Result");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathSinNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathSinNode) == 0x280, "Size mismatch for FDataflowMathSinNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathCosNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathCosNode) == 0x280, "Size mismatch for FDataflowMathCosNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathTanNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathTanNode) == 0x280, "Size mismatch for FDataflowMathTanNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathArcSinNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathArcSinNode) == 0x280, "Size mismatch for FDataflowMathArcSinNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathArcCosNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathArcCosNode) == 0x280, "Size mismatch for FDataflowMathArcCosNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathArcTanNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathArcTanNode) == 0x280, "Size mismatch for FDataflowMathArcTanNode");

// Size: 0x288 (Inherited: 0x4f8, Single: 0xfffffd90)
struct FDataflowMathArcTan2Node : FDataflowMathTwoInputsOperatorNode
{
};

static_assert(sizeof(FDataflowMathArcTan2Node) == 0x288, "Size mismatch for FDataflowMathArcTan2Node");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathDegToRadNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathDegToRadNode) == 0x280, "Size mismatch for FDataflowMathDegToRadNode");

// Size: 0x280 (Inherited: 0x4f0, Single: 0xfffffd90)
struct FDataflowMathRadToDegNode : FDataflowMathOneInputOperatorNode
{
};

static_assert(sizeof(FDataflowMathRadToDegNode) == 0x280, "Size mismatch for FDataflowMathRadToDegNode");

// Size: 0x2a0 (Inherited: 0x270, Single: 0x30)
struct FDataflowVectorMakeVec2Node : FDataflowNode
{
    FDataflowNumericTypes X; // 0x270 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Y; // 0x278 (Size: 0x8, Type: StructProperty)
    FDataflowVectorTypes Vector2D; // 0x280 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDataflowVectorMakeVec2Node) == 0x2a0, "Size mismatch for FDataflowVectorMakeVec2Node");
static_assert(offsetof(FDataflowVectorMakeVec2Node, X) == 0x270, "Offset mismatch for FDataflowVectorMakeVec2Node::X");
static_assert(offsetof(FDataflowVectorMakeVec2Node, Y) == 0x278, "Offset mismatch for FDataflowVectorMakeVec2Node::Y");
static_assert(offsetof(FDataflowVectorMakeVec2Node, Vector2D) == 0x280, "Offset mismatch for FDataflowVectorMakeVec2Node::Vector2D");

// Size: 0x2b0 (Inherited: 0x270, Single: 0x40)
struct FDataflowVectorMakeVec3Node : FDataflowNode
{
    FDataflowNumericTypes X; // 0x270 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Y; // 0x278 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Z; // 0x280 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_288[0x8]; // 0x288 (Size: 0x8, Type: PaddingProperty)
    FDataflowVectorTypes Vector3d; // 0x290 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDataflowVectorMakeVec3Node) == 0x2b0, "Size mismatch for FDataflowVectorMakeVec3Node");
static_assert(offsetof(FDataflowVectorMakeVec3Node, X) == 0x270, "Offset mismatch for FDataflowVectorMakeVec3Node::X");
static_assert(offsetof(FDataflowVectorMakeVec3Node, Y) == 0x278, "Offset mismatch for FDataflowVectorMakeVec3Node::Y");
static_assert(offsetof(FDataflowVectorMakeVec3Node, Z) == 0x280, "Offset mismatch for FDataflowVectorMakeVec3Node::Z");
static_assert(offsetof(FDataflowVectorMakeVec3Node, Vector3d) == 0x290, "Offset mismatch for FDataflowVectorMakeVec3Node::Vector3d");

// Size: 0x2b0 (Inherited: 0x270, Single: 0x40)
struct FDataflowVectorMakeVec4Node : FDataflowNode
{
    FDataflowNumericTypes X; // 0x270 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Y; // 0x278 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Z; // 0x280 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes W; // 0x288 (Size: 0x8, Type: StructProperty)
    FDataflowVectorTypes Vector4d; // 0x290 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDataflowVectorMakeVec4Node) == 0x2b0, "Size mismatch for FDataflowVectorMakeVec4Node");
static_assert(offsetof(FDataflowVectorMakeVec4Node, X) == 0x270, "Offset mismatch for FDataflowVectorMakeVec4Node::X");
static_assert(offsetof(FDataflowVectorMakeVec4Node, Y) == 0x278, "Offset mismatch for FDataflowVectorMakeVec4Node::Y");
static_assert(offsetof(FDataflowVectorMakeVec4Node, Z) == 0x280, "Offset mismatch for FDataflowVectorMakeVec4Node::Z");
static_assert(offsetof(FDataflowVectorMakeVec4Node, W) == 0x288, "Offset mismatch for FDataflowVectorMakeVec4Node::W");
static_assert(offsetof(FDataflowVectorMakeVec4Node, Vector4d) == 0x290, "Offset mismatch for FDataflowVectorMakeVec4Node::Vector4d");

// Size: 0x2b0 (Inherited: 0x270, Single: 0x40)
struct FDataflowVectorBreakNode : FDataflowNode
{
    FDataflowVectorTypes V; // 0x270 (Size: 0x20, Type: StructProperty)
    FDataflowNumericTypes X; // 0x290 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Y; // 0x298 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes Z; // 0x2a0 (Size: 0x8, Type: StructProperty)
    FDataflowNumericTypes W; // 0x2a8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FDataflowVectorBreakNode) == 0x2b0, "Size mismatch for FDataflowVectorBreakNode");
static_assert(offsetof(FDataflowVectorBreakNode, V) == 0x270, "Offset mismatch for FDataflowVectorBreakNode::V");
static_assert(offsetof(FDataflowVectorBreakNode, X) == 0x290, "Offset mismatch for FDataflowVectorBreakNode::X");
static_assert(offsetof(FDataflowVectorBreakNode, Y) == 0x298, "Offset mismatch for FDataflowVectorBreakNode::Y");
static_assert(offsetof(FDataflowVectorBreakNode, Z) == 0x2a0, "Offset mismatch for FDataflowVectorBreakNode::Z");
static_assert(offsetof(FDataflowVectorBreakNode, W) == 0x2a8, "Offset mismatch for FDataflowVectorBreakNode::W");

// Size: 0x2d0 (Inherited: 0x270, Single: 0x60)
struct FDataflowVectorAddNode : FDataflowNode
{
    FDataflowVectorTypes A; // 0x270 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes B; // 0x290 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes V; // 0x2b0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDataflowVectorAddNode) == 0x2d0, "Size mismatch for FDataflowVectorAddNode");
static_assert(offsetof(FDataflowVectorAddNode, A) == 0x270, "Offset mismatch for FDataflowVectorAddNode::A");
static_assert(offsetof(FDataflowVectorAddNode, B) == 0x290, "Offset mismatch for FDataflowVectorAddNode::B");
static_assert(offsetof(FDataflowVectorAddNode, V) == 0x2b0, "Offset mismatch for FDataflowVectorAddNode::V");

// Size: 0x2d0 (Inherited: 0x270, Single: 0x60)
struct FDataflowVectorSubtractNode : FDataflowNode
{
    FDataflowVectorTypes A; // 0x270 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes B; // 0x290 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes V; // 0x2b0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDataflowVectorSubtractNode) == 0x2d0, "Size mismatch for FDataflowVectorSubtractNode");
static_assert(offsetof(FDataflowVectorSubtractNode, A) == 0x270, "Offset mismatch for FDataflowVectorSubtractNode::A");
static_assert(offsetof(FDataflowVectorSubtractNode, B) == 0x290, "Offset mismatch for FDataflowVectorSubtractNode::B");
static_assert(offsetof(FDataflowVectorSubtractNode, V) == 0x2b0, "Offset mismatch for FDataflowVectorSubtractNode::V");

// Size: 0x2c0 (Inherited: 0x270, Single: 0x50)
struct FDataflowVectorDotProductNode : FDataflowNode
{
    FDataflowVectorTypes A; // 0x270 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes B; // 0x290 (Size: 0x20, Type: StructProperty)
    FDataflowNumericTypes DotProduct; // 0x2b0 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_2b8[0x8]; // 0x2b8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowVectorDotProductNode) == 0x2c0, "Size mismatch for FDataflowVectorDotProductNode");
static_assert(offsetof(FDataflowVectorDotProductNode, A) == 0x270, "Offset mismatch for FDataflowVectorDotProductNode::A");
static_assert(offsetof(FDataflowVectorDotProductNode, B) == 0x290, "Offset mismatch for FDataflowVectorDotProductNode::B");
static_assert(offsetof(FDataflowVectorDotProductNode, DotProduct) == 0x2b0, "Offset mismatch for FDataflowVectorDotProductNode::DotProduct");

// Size: 0x2a0 (Inherited: 0x270, Single: 0x30)
struct FDataflowVectorLengthNode : FDataflowNode
{
    FDataflowVectorTypes V; // 0x270 (Size: 0x20, Type: StructProperty)
    FDataflowNumericTypes Length; // 0x290 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_298[0x8]; // 0x298 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowVectorLengthNode) == 0x2a0, "Size mismatch for FDataflowVectorLengthNode");
static_assert(offsetof(FDataflowVectorLengthNode, V) == 0x270, "Offset mismatch for FDataflowVectorLengthNode::V");
static_assert(offsetof(FDataflowVectorLengthNode, Length) == 0x290, "Offset mismatch for FDataflowVectorLengthNode::Length");

// Size: 0x2a0 (Inherited: 0x270, Single: 0x30)
struct FDataflowVectorSquaredLengthNode : FDataflowNode
{
    FDataflowVectorTypes V; // 0x270 (Size: 0x20, Type: StructProperty)
    FDataflowNumericTypes SquaredLength; // 0x290 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_298[0x8]; // 0x298 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowVectorSquaredLengthNode) == 0x2a0, "Size mismatch for FDataflowVectorSquaredLengthNode");
static_assert(offsetof(FDataflowVectorSquaredLengthNode, V) == 0x270, "Offset mismatch for FDataflowVectorSquaredLengthNode::V");
static_assert(offsetof(FDataflowVectorSquaredLengthNode, SquaredLength) == 0x290, "Offset mismatch for FDataflowVectorSquaredLengthNode::SquaredLength");

// Size: 0x2c0 (Inherited: 0x270, Single: 0x50)
struct FDataflowVectorDistanceNode : FDataflowNode
{
    FDataflowVectorTypes A; // 0x270 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes B; // 0x290 (Size: 0x20, Type: StructProperty)
    FDataflowNumericTypes Distance; // 0x2b0 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_2b8[0x8]; // 0x2b8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowVectorDistanceNode) == 0x2c0, "Size mismatch for FDataflowVectorDistanceNode");
static_assert(offsetof(FDataflowVectorDistanceNode, A) == 0x270, "Offset mismatch for FDataflowVectorDistanceNode::A");
static_assert(offsetof(FDataflowVectorDistanceNode, B) == 0x290, "Offset mismatch for FDataflowVectorDistanceNode::B");
static_assert(offsetof(FDataflowVectorDistanceNode, Distance) == 0x2b0, "Offset mismatch for FDataflowVectorDistanceNode::Distance");

// Size: 0x2d0 (Inherited: 0x270, Single: 0x60)
struct FDataflowVectorCrossProductNode : FDataflowNode
{
    FDataflowVectorTypes A; // 0x270 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes B; // 0x290 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes CrossProduct; // 0x2b0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDataflowVectorCrossProductNode) == 0x2d0, "Size mismatch for FDataflowVectorCrossProductNode");
static_assert(offsetof(FDataflowVectorCrossProductNode, A) == 0x270, "Offset mismatch for FDataflowVectorCrossProductNode::A");
static_assert(offsetof(FDataflowVectorCrossProductNode, B) == 0x290, "Offset mismatch for FDataflowVectorCrossProductNode::B");
static_assert(offsetof(FDataflowVectorCrossProductNode, CrossProduct) == 0x2b0, "Offset mismatch for FDataflowVectorCrossProductNode::CrossProduct");

// Size: 0x2c0 (Inherited: 0x270, Single: 0x50)
struct FDataflowVectorScaleNode : FDataflowNode
{
    FDataflowVectorTypes V; // 0x270 (Size: 0x20, Type: StructProperty)
    FDataflowNumericTypes Scale; // 0x290 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_298[0x8]; // 0x298 (Size: 0x8, Type: PaddingProperty)
    FDataflowVectorTypes Scaled; // 0x2a0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDataflowVectorScaleNode) == 0x2c0, "Size mismatch for FDataflowVectorScaleNode");
static_assert(offsetof(FDataflowVectorScaleNode, V) == 0x270, "Offset mismatch for FDataflowVectorScaleNode::V");
static_assert(offsetof(FDataflowVectorScaleNode, Scale) == 0x290, "Offset mismatch for FDataflowVectorScaleNode::Scale");
static_assert(offsetof(FDataflowVectorScaleNode, Scaled) == 0x2a0, "Offset mismatch for FDataflowVectorScaleNode::Scaled");

// Size: 0x2b0 (Inherited: 0x270, Single: 0x40)
struct FDataflowVectorNormalize : FDataflowNode
{
    FDataflowVectorTypes V; // 0x270 (Size: 0x20, Type: StructProperty)
    FDataflowVectorTypes Normalized; // 0x290 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FDataflowVectorNormalize) == 0x2b0, "Size mismatch for FDataflowVectorNormalize");
static_assert(offsetof(FDataflowVectorNormalize, V) == 0x270, "Offset mismatch for FDataflowVectorNormalize::V");
static_assert(offsetof(FDataflowVectorNormalize, Normalized) == 0x290, "Offset mismatch for FDataflowVectorNormalize::Normalized");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FDataflowConnection
{
};

static_assert(sizeof(FDataflowConnection) == 0x50, "Size mismatch for FDataflowConnection");

// Size: 0x60 (Inherited: 0x50, Single: 0x10)
struct FDataflowInput : FDataflowConnection
{
};

static_assert(sizeof(FDataflowInput) == 0x60, "Size mismatch for FDataflowInput");

// Size: 0x70 (Inherited: 0xb0, Single: 0xffffffc0)
struct FDataflowArrayInput : FDataflowInput
{
};

static_assert(sizeof(FDataflowArrayInput) == 0x70, "Size mismatch for FDataflowArrayInput");

// Size: 0x80 (Inherited: 0x50, Single: 0x30)
struct FDataflowOutput : FDataflowConnection
{
};

static_assert(sizeof(FDataflowOutput) == 0x80, "Size mismatch for FDataflowOutput");

// Size: 0x90 (Inherited: 0xd0, Single: 0xffffffc0)
struct FDataflowArrayOutput : FDataflowOutput
{
};

static_assert(sizeof(FDataflowArrayOutput) == 0x90, "Size mismatch for FDataflowArrayOutput");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDataflowFreezeActions
{
};

static_assert(sizeof(FDataflowFreezeActions) == 0x1, "Size mismatch for FDataflowFreezeActions");

// Size: 0x290 (Inherited: 0x270, Single: 0x20)
struct FDataflowOverrideNode : FDataflowNode
{
    FName Key; // 0x270 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_274[0x4]; // 0x274 (Size: 0x4, Type: PaddingProperty)
    FString Default; // 0x278 (Size: 0x10, Type: StrProperty)
    bool IsOverriden; // 0x288 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_289[0x7]; // 0x289 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowOverrideNode) == 0x290, "Size mismatch for FDataflowOverrideNode");
static_assert(offsetof(FDataflowOverrideNode, Key) == 0x270, "Offset mismatch for FDataflowOverrideNode::Key");
static_assert(offsetof(FDataflowOverrideNode, Default) == 0x278, "Offset mismatch for FDataflowOverrideNode::Default");
static_assert(offsetof(FDataflowOverrideNode, IsOverriden) == 0x288, "Offset mismatch for FDataflowOverrideNode::IsOverriden");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FDataflowPath
{
};

static_assert(sizeof(FDataflowPath) == 0x40, "Size mismatch for FDataflowPath");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
struct FDataflowTransformSelection : FDataflowSelection
{
};

static_assert(sizeof(FDataflowTransformSelection) == 0x28, "Size mismatch for FDataflowTransformSelection");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
struct FDataflowVertexSelection : FDataflowSelection
{
};

static_assert(sizeof(FDataflowVertexSelection) == 0x28, "Size mismatch for FDataflowVertexSelection");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
struct FDataflowFaceSelection : FDataflowSelection
{
};

static_assert(sizeof(FDataflowFaceSelection) == 0x28, "Size mismatch for FDataflowFaceSelection");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
struct FDataflowGeometrySelection : FDataflowSelection
{
};

static_assert(sizeof(FDataflowGeometrySelection) == 0x28, "Size mismatch for FDataflowGeometrySelection");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
struct FDataflowMaterialSelection : FDataflowSelection
{
};

static_assert(sizeof(FDataflowMaterialSelection) == 0x28, "Size mismatch for FDataflowMaterialSelection");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FNodeColors
{
    FLinearColor NodeTitleColor; // 0x0 (Size: 0x10, Type: StructProperty)
    FLinearColor NodeBodyTintColor; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FNodeColors) == 0x20, "Size mismatch for FNodeColors");
static_assert(offsetof(FNodeColors, NodeTitleColor) == 0x0, "Offset mismatch for FNodeColors::NodeTitleColor");
static_assert(offsetof(FNodeColors, NodeBodyTintColor) == 0x10, "Offset mismatch for FNodeColors::NodeBodyTintColor");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FPinSettings
{
    FLinearColor PinColor; // 0x0 (Size: 0x10, Type: StructProperty)
    float WireThickness; // 0x10 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FPinSettings) == 0x14, "Size mismatch for FPinSettings");
static_assert(offsetof(FPinSettings, PinColor) == 0x0, "Offset mismatch for FPinSettings::PinColor");
static_assert(offsetof(FPinSettings, WireThickness) == 0x10, "Offset mismatch for FPinSettings::WireThickness");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FTransformLevelColors
{
    TArray<FLinearColor> LevelColors; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FLinearColor BlankColor; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FTransformLevelColors) == 0x20, "Size mismatch for FTransformLevelColors");
static_assert(offsetof(FTransformLevelColors, LevelColors) == 0x0, "Offset mismatch for FTransformLevelColors::LevelColors");
static_assert(offsetof(FTransformLevelColors, BlankColor) == 0x10, "Offset mismatch for FTransformLevelColors::BlankColor");

// Size: 0x270 (Inherited: 0x270, Single: 0x0)
struct FDataflowTerminalNode : FDataflowNode
{
};

static_assert(sizeof(FDataflowTerminalNode) == 0x270, "Size mismatch for FDataflowTerminalNode");

