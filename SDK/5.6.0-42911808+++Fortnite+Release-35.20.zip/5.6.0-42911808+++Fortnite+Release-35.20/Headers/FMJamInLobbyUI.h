/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamInLobbyUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "FMJamPlayspaceRuntime.h"
#include "PlayspaceSystem.h"
#include "FMJamInLobbyRuntime.h"
#include "Engine.h"

// Size: 0xa8 (Inherited: 0xb8, Single: 0xfffffff0)
class UJamInLobbyOpenGlobalControlsSubsystem : public UFortLocalPlayerSubsystem
{
public:
    FDataTableRowHandle InputAction; // 0x30 (Size: 0x10, Type: StructProperty)
    TWeakObjectPtr<AJamInLobbyPlayspace*> LocalPlayerPlayspace; // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_48[0x60]; // 0x48 (Size: 0x60, Type: PaddingProperty)

protected:
    AFortPlayerController* GetFortPlayerController() const; // 0x111109fc (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void HandleOnJamLoopStarted(const FJamEvent_JamLoopStarted Payload); // 0x11110a20 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
    void HandleOnJamLoopStopped(const FJamEvent_JamLoopStopped Payload); // 0x11110b28 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
    void HandleOnNewPlayspaceForPlayer(APlayspace*& Playspace, const FPlayspaceJurisdictionFilter Filter); // 0x11110c30 (Index: 0x3, Flags: Final|Native|Protected|HasOutParms)
    virtual void OpenGlobalControls(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UJamInLobbyOpenGlobalControlsSubsystem) == 0xa8, "Size mismatch for UJamInLobbyOpenGlobalControlsSubsystem");
static_assert(offsetof(UJamInLobbyOpenGlobalControlsSubsystem, InputAction) == 0x30, "Offset mismatch for UJamInLobbyOpenGlobalControlsSubsystem::InputAction");
static_assert(offsetof(UJamInLobbyOpenGlobalControlsSubsystem, LocalPlayerPlayspace) == 0x40, "Offset mismatch for UJamInLobbyOpenGlobalControlsSubsystem::LocalPlayerPlayspace");

