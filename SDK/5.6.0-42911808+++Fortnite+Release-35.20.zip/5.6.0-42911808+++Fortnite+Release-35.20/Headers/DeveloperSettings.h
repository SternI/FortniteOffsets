/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DeveloperSettings
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UDeveloperSettings : public UObject
{
public:
};

static_assert(sizeof(UDeveloperSettings) == 0x30, "Size mismatch for UDeveloperSettings");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UDeveloperSettingsBackedByCVars : public UDeveloperSettings
{
public:
};

static_assert(sizeof(UDeveloperSettingsBackedByCVars) == 0x30, "Size mismatch for UDeveloperSettingsBackedByCVars");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UPlatformSettings : public UObject
{
public:
};

static_assert(sizeof(UPlatformSettings) == 0x40, "Size mismatch for UPlatformSettings");

// Size: 0x80 (Inherited: 0x28, Single: 0x58)
class UPlatformSettingsManager : public UObject
{
public:
    TMap<FPlatformSettingsInstances, UClass*> SettingsMap; // 0x28 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_78[0x8]; // 0x78 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UPlatformSettingsManager) == 0x80, "Size mismatch for UPlatformSettingsManager");
static_assert(offsetof(UPlatformSettingsManager, SettingsMap) == 0x28, "Offset mismatch for UPlatformSettingsManager::SettingsMap");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPerPlatformSettings
{
    TArray<UPlatformSettings*> Settings; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FPerPlatformSettings) == 0x10, "Size mismatch for FPerPlatformSettings");
static_assert(offsetof(FPerPlatformSettings, Settings) == 0x0, "Offset mismatch for FPerPlatformSettings::Settings");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FPlatformSettingsInstances
{
    UPlatformSettings* PlatformInstance; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TMap<UPlatformSettings*, FName> OtherPlatforms; // 0x8 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FPlatformSettingsInstances) == 0x58, "Size mismatch for FPlatformSettingsInstances");
static_assert(offsetof(FPlatformSettingsInstances, PlatformInstance) == 0x0, "Offset mismatch for FPlatformSettingsInstances::PlatformInstance");
static_assert(offsetof(FPlatformSettingsInstances, OtherPlatforms) == 0x8, "Offset mismatch for FPlatformSettingsInstances::OtherPlatforms");

