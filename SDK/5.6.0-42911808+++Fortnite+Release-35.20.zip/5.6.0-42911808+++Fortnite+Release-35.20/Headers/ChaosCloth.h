/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosCloth
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ClothingSystemRuntimeCommon.h"
#include "ClothingSystemRuntimeInterface.h"
#include "CoreUObject.h"

// Size: 0x180 (Inherited: 0x78, Single: 0x108)
class UChaosClothConfig : public UClothConfigCommon
{
public:
    uint8_t MassMode; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    float UniformMass; // 0x2c (Size: 0x4, Type: FloatProperty)
    float TotalMass; // 0x30 (Size: 0x4, Type: FloatProperty)
    float Density; // 0x34 (Size: 0x4, Type: FloatProperty)
    float MinPerParticleMass; // 0x38 (Size: 0x4, Type: FloatProperty)
    FChaosClothWeightedValue EdgeStiffnessWeighted; // 0x3c (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue BendingStiffnessWeighted; // 0x44 (Size: 0x8, Type: StructProperty)
    bool bUseBendingElements; // 0x4c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4d[0x3]; // 0x4d (Size: 0x3, Type: PaddingProperty)
    float BucklingRatio; // 0x50 (Size: 0x4, Type: FloatProperty)
    FChaosClothWeightedValue BucklingStiffnessWeighted; // 0x54 (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue FlatnessRatio; // 0x5c (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue AreaStiffnessWeighted; // 0x64 (Size: 0x8, Type: StructProperty)
    float VolumeStiffness; // 0x6c (Size: 0x4, Type: FloatProperty)
    FChaosClothWeightedValue TetherStiffness; // 0x70 (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue TetherScale; // 0x78 (Size: 0x8, Type: StructProperty)
    bool bUseGeodesicDistance; // 0x80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_81[0x3]; // 0x81 (Size: 0x3, Type: PaddingProperty)
    float ShapeTargetStiffness; // 0x84 (Size: 0x4, Type: FloatProperty)
    float CollisionThickness; // 0x88 (Size: 0x4, Type: FloatProperty)
    float FrictionCoefficient; // 0x8c (Size: 0x4, Type: FloatProperty)
    bool bUseCCD; // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bUseSelfCollisions; // 0x91 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_92[0x2]; // 0x92 (Size: 0x2, Type: PaddingProperty)
    float SelfCollisionThickness; // 0x94 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionFriction; // 0x98 (Size: 0x4, Type: FloatProperty)
    bool bUseSelfIntersections; // 0x9c (Size: 0x1, Type: BoolProperty)
    bool bUseSelfCollisionSpheres; // 0x9d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9e[0x2]; // 0x9e (Size: 0x2, Type: PaddingProperty)
    float SelfCollisionSphereRadius; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionSphereStiffness; // 0xa4 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionSphereRadiusCullMultiplier; // 0xa8 (Size: 0x4, Type: FloatProperty)
    bool bUseLegacyBackstop; // 0xac (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ad[0x3]; // 0xad (Size: 0x3, Type: PaddingProperty)
    float DampingCoefficient; // 0xb0 (Size: 0x4, Type: FloatProperty)
    float LocalDampingCoefficient; // 0xb4 (Size: 0x4, Type: FloatProperty)
    bool bUsePointBasedWindModel; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x3]; // 0xb9 (Size: 0x3, Type: PaddingProperty)
    FChaosClothWeightedValue Drag; // 0xbc (Size: 0x8, Type: StructProperty)
    bool bEnableOuterDrag; // 0xc4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c5[0x3]; // 0xc5 (Size: 0x3, Type: PaddingProperty)
    FChaosClothWeightedValue OuterDrag; // 0xc8 (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue Lift; // 0xd0 (Size: 0x8, Type: StructProperty)
    bool bEnableOuterLift; // 0xd8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d9[0x3]; // 0xd9 (Size: 0x3, Type: PaddingProperty)
    FChaosClothWeightedValue OuterLift; // 0xdc (Size: 0x8, Type: StructProperty)
    bool bUseGravityOverride; // 0xe4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e5[0x3]; // 0xe5 (Size: 0x3, Type: PaddingProperty)
    float GravityScale; // 0xe8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_ec[0x4]; // 0xec (Size: 0x4, Type: PaddingProperty)
    FVector Gravity; // 0xf0 (Size: 0x18, Type: StructProperty)
    FChaosClothWeightedValue Pressure; // 0x108 (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue AnimDriveStiffness; // 0x110 (Size: 0x8, Type: StructProperty)
    FChaosClothWeightedValue AnimDriveDamping; // 0x118 (Size: 0x8, Type: StructProperty)
    uint8_t VelocityScaleSpace; // 0x120 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_121[0x7]; // 0x121 (Size: 0x7, Type: PaddingProperty)
    FVector LinearVelocityScale; // 0x128 (Size: 0x18, Type: StructProperty)
    bool bEnableLinearVelocityClamping; // 0x140 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_141[0x3]; // 0x141 (Size: 0x3, Type: PaddingProperty)
    FVector3f MaxLinearVelocity; // 0x144 (Size: 0xc, Type: StructProperty)
    bool bEnableLinearAccelerationClamping; // 0x150 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_151[0x3]; // 0x151 (Size: 0x3, Type: PaddingProperty)
    FVector3f MaxLinearAcceleration; // 0x154 (Size: 0xc, Type: StructProperty)
    float AngularVelocityScale; // 0x160 (Size: 0x4, Type: FloatProperty)
    bool bEnableAngularVelocityClamping; // 0x164 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_165[0x3]; // 0x165 (Size: 0x3, Type: PaddingProperty)
    float MaxAngularVelocity; // 0x168 (Size: 0x4, Type: FloatProperty)
    bool bEnableAngularAccelerationClamping; // 0x16c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_16d[0x3]; // 0x16d (Size: 0x3, Type: PaddingProperty)
    float MaxAngularAcceleration; // 0x170 (Size: 0x4, Type: FloatProperty)
    float FictitiousAngularScale; // 0x174 (Size: 0x4, Type: FloatProperty)
    bool bUseTetrahedralConstraints; // 0x178 (Size: 0x1, Type: BoolProperty)
    bool bUseThinShellVolumeConstraints; // 0x179 (Size: 0x1, Type: BoolProperty)
    bool bUseContinuousCollisionDetection; // 0x17a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_17b[0x5]; // 0x17b (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(UChaosClothConfig) == 0x180, "Size mismatch for UChaosClothConfig");
static_assert(offsetof(UChaosClothConfig, MassMode) == 0x28, "Offset mismatch for UChaosClothConfig::MassMode");
static_assert(offsetof(UChaosClothConfig, UniformMass) == 0x2c, "Offset mismatch for UChaosClothConfig::UniformMass");
static_assert(offsetof(UChaosClothConfig, TotalMass) == 0x30, "Offset mismatch for UChaosClothConfig::TotalMass");
static_assert(offsetof(UChaosClothConfig, Density) == 0x34, "Offset mismatch for UChaosClothConfig::Density");
static_assert(offsetof(UChaosClothConfig, MinPerParticleMass) == 0x38, "Offset mismatch for UChaosClothConfig::MinPerParticleMass");
static_assert(offsetof(UChaosClothConfig, EdgeStiffnessWeighted) == 0x3c, "Offset mismatch for UChaosClothConfig::EdgeStiffnessWeighted");
static_assert(offsetof(UChaosClothConfig, BendingStiffnessWeighted) == 0x44, "Offset mismatch for UChaosClothConfig::BendingStiffnessWeighted");
static_assert(offsetof(UChaosClothConfig, bUseBendingElements) == 0x4c, "Offset mismatch for UChaosClothConfig::bUseBendingElements");
static_assert(offsetof(UChaosClothConfig, BucklingRatio) == 0x50, "Offset mismatch for UChaosClothConfig::BucklingRatio");
static_assert(offsetof(UChaosClothConfig, BucklingStiffnessWeighted) == 0x54, "Offset mismatch for UChaosClothConfig::BucklingStiffnessWeighted");
static_assert(offsetof(UChaosClothConfig, FlatnessRatio) == 0x5c, "Offset mismatch for UChaosClothConfig::FlatnessRatio");
static_assert(offsetof(UChaosClothConfig, AreaStiffnessWeighted) == 0x64, "Offset mismatch for UChaosClothConfig::AreaStiffnessWeighted");
static_assert(offsetof(UChaosClothConfig, VolumeStiffness) == 0x6c, "Offset mismatch for UChaosClothConfig::VolumeStiffness");
static_assert(offsetof(UChaosClothConfig, TetherStiffness) == 0x70, "Offset mismatch for UChaosClothConfig::TetherStiffness");
static_assert(offsetof(UChaosClothConfig, TetherScale) == 0x78, "Offset mismatch for UChaosClothConfig::TetherScale");
static_assert(offsetof(UChaosClothConfig, bUseGeodesicDistance) == 0x80, "Offset mismatch for UChaosClothConfig::bUseGeodesicDistance");
static_assert(offsetof(UChaosClothConfig, ShapeTargetStiffness) == 0x84, "Offset mismatch for UChaosClothConfig::ShapeTargetStiffness");
static_assert(offsetof(UChaosClothConfig, CollisionThickness) == 0x88, "Offset mismatch for UChaosClothConfig::CollisionThickness");
static_assert(offsetof(UChaosClothConfig, FrictionCoefficient) == 0x8c, "Offset mismatch for UChaosClothConfig::FrictionCoefficient");
static_assert(offsetof(UChaosClothConfig, bUseCCD) == 0x90, "Offset mismatch for UChaosClothConfig::bUseCCD");
static_assert(offsetof(UChaosClothConfig, bUseSelfCollisions) == 0x91, "Offset mismatch for UChaosClothConfig::bUseSelfCollisions");
static_assert(offsetof(UChaosClothConfig, SelfCollisionThickness) == 0x94, "Offset mismatch for UChaosClothConfig::SelfCollisionThickness");
static_assert(offsetof(UChaosClothConfig, SelfCollisionFriction) == 0x98, "Offset mismatch for UChaosClothConfig::SelfCollisionFriction");
static_assert(offsetof(UChaosClothConfig, bUseSelfIntersections) == 0x9c, "Offset mismatch for UChaosClothConfig::bUseSelfIntersections");
static_assert(offsetof(UChaosClothConfig, bUseSelfCollisionSpheres) == 0x9d, "Offset mismatch for UChaosClothConfig::bUseSelfCollisionSpheres");
static_assert(offsetof(UChaosClothConfig, SelfCollisionSphereRadius) == 0xa0, "Offset mismatch for UChaosClothConfig::SelfCollisionSphereRadius");
static_assert(offsetof(UChaosClothConfig, SelfCollisionSphereStiffness) == 0xa4, "Offset mismatch for UChaosClothConfig::SelfCollisionSphereStiffness");
static_assert(offsetof(UChaosClothConfig, SelfCollisionSphereRadiusCullMultiplier) == 0xa8, "Offset mismatch for UChaosClothConfig::SelfCollisionSphereRadiusCullMultiplier");
static_assert(offsetof(UChaosClothConfig, bUseLegacyBackstop) == 0xac, "Offset mismatch for UChaosClothConfig::bUseLegacyBackstop");
static_assert(offsetof(UChaosClothConfig, DampingCoefficient) == 0xb0, "Offset mismatch for UChaosClothConfig::DampingCoefficient");
static_assert(offsetof(UChaosClothConfig, LocalDampingCoefficient) == 0xb4, "Offset mismatch for UChaosClothConfig::LocalDampingCoefficient");
static_assert(offsetof(UChaosClothConfig, bUsePointBasedWindModel) == 0xb8, "Offset mismatch for UChaosClothConfig::bUsePointBasedWindModel");
static_assert(offsetof(UChaosClothConfig, Drag) == 0xbc, "Offset mismatch for UChaosClothConfig::Drag");
static_assert(offsetof(UChaosClothConfig, bEnableOuterDrag) == 0xc4, "Offset mismatch for UChaosClothConfig::bEnableOuterDrag");
static_assert(offsetof(UChaosClothConfig, OuterDrag) == 0xc8, "Offset mismatch for UChaosClothConfig::OuterDrag");
static_assert(offsetof(UChaosClothConfig, Lift) == 0xd0, "Offset mismatch for UChaosClothConfig::Lift");
static_assert(offsetof(UChaosClothConfig, bEnableOuterLift) == 0xd8, "Offset mismatch for UChaosClothConfig::bEnableOuterLift");
static_assert(offsetof(UChaosClothConfig, OuterLift) == 0xdc, "Offset mismatch for UChaosClothConfig::OuterLift");
static_assert(offsetof(UChaosClothConfig, bUseGravityOverride) == 0xe4, "Offset mismatch for UChaosClothConfig::bUseGravityOverride");
static_assert(offsetof(UChaosClothConfig, GravityScale) == 0xe8, "Offset mismatch for UChaosClothConfig::GravityScale");
static_assert(offsetof(UChaosClothConfig, Gravity) == 0xf0, "Offset mismatch for UChaosClothConfig::Gravity");
static_assert(offsetof(UChaosClothConfig, Pressure) == 0x108, "Offset mismatch for UChaosClothConfig::Pressure");
static_assert(offsetof(UChaosClothConfig, AnimDriveStiffness) == 0x110, "Offset mismatch for UChaosClothConfig::AnimDriveStiffness");
static_assert(offsetof(UChaosClothConfig, AnimDriveDamping) == 0x118, "Offset mismatch for UChaosClothConfig::AnimDriveDamping");
static_assert(offsetof(UChaosClothConfig, VelocityScaleSpace) == 0x120, "Offset mismatch for UChaosClothConfig::VelocityScaleSpace");
static_assert(offsetof(UChaosClothConfig, LinearVelocityScale) == 0x128, "Offset mismatch for UChaosClothConfig::LinearVelocityScale");
static_assert(offsetof(UChaosClothConfig, bEnableLinearVelocityClamping) == 0x140, "Offset mismatch for UChaosClothConfig::bEnableLinearVelocityClamping");
static_assert(offsetof(UChaosClothConfig, MaxLinearVelocity) == 0x144, "Offset mismatch for UChaosClothConfig::MaxLinearVelocity");
static_assert(offsetof(UChaosClothConfig, bEnableLinearAccelerationClamping) == 0x150, "Offset mismatch for UChaosClothConfig::bEnableLinearAccelerationClamping");
static_assert(offsetof(UChaosClothConfig, MaxLinearAcceleration) == 0x154, "Offset mismatch for UChaosClothConfig::MaxLinearAcceleration");
static_assert(offsetof(UChaosClothConfig, AngularVelocityScale) == 0x160, "Offset mismatch for UChaosClothConfig::AngularVelocityScale");
static_assert(offsetof(UChaosClothConfig, bEnableAngularVelocityClamping) == 0x164, "Offset mismatch for UChaosClothConfig::bEnableAngularVelocityClamping");
static_assert(offsetof(UChaosClothConfig, MaxAngularVelocity) == 0x168, "Offset mismatch for UChaosClothConfig::MaxAngularVelocity");
static_assert(offsetof(UChaosClothConfig, bEnableAngularAccelerationClamping) == 0x16c, "Offset mismatch for UChaosClothConfig::bEnableAngularAccelerationClamping");
static_assert(offsetof(UChaosClothConfig, MaxAngularAcceleration) == 0x170, "Offset mismatch for UChaosClothConfig::MaxAngularAcceleration");
static_assert(offsetof(UChaosClothConfig, FictitiousAngularScale) == 0x174, "Offset mismatch for UChaosClothConfig::FictitiousAngularScale");
static_assert(offsetof(UChaosClothConfig, bUseTetrahedralConstraints) == 0x178, "Offset mismatch for UChaosClothConfig::bUseTetrahedralConstraints");
static_assert(offsetof(UChaosClothConfig, bUseThinShellVolumeConstraints) == 0x179, "Offset mismatch for UChaosClothConfig::bUseThinShellVolumeConstraints");
static_assert(offsetof(UChaosClothConfig, bUseContinuousCollisionDetection) == 0x17a, "Offset mismatch for UChaosClothConfig::bUseContinuousCollisionDetection");

// Size: 0x38 (Inherited: 0xa0, Single: 0xffffff98)
class UChaosClothSharedSimConfig : public UClothSharedConfigCommon
{
public:
    int32_t IterationCount; // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t MaxIterationCount; // 0x2c (Size: 0x4, Type: IntProperty)
    int32_t SubdivisionCount; // 0x30 (Size: 0x4, Type: IntProperty)
    bool bUseLocalSpaceSimulation; // 0x34 (Size: 0x1, Type: BoolProperty)
    bool bUseXPBDConstraints; // 0x35 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_36[0x2]; // 0x36 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(UChaosClothSharedSimConfig) == 0x38, "Size mismatch for UChaosClothSharedSimConfig");
static_assert(offsetof(UChaosClothSharedSimConfig, IterationCount) == 0x28, "Offset mismatch for UChaosClothSharedSimConfig::IterationCount");
static_assert(offsetof(UChaosClothSharedSimConfig, MaxIterationCount) == 0x2c, "Offset mismatch for UChaosClothSharedSimConfig::MaxIterationCount");
static_assert(offsetof(UChaosClothSharedSimConfig, SubdivisionCount) == 0x30, "Offset mismatch for UChaosClothSharedSimConfig::SubdivisionCount");
static_assert(offsetof(UChaosClothSharedSimConfig, bUseLocalSpaceSimulation) == 0x34, "Offset mismatch for UChaosClothSharedSimConfig::bUseLocalSpaceSimulation");
static_assert(offsetof(UChaosClothSharedSimConfig, bUseXPBDConstraints) == 0x35, "Offset mismatch for UChaosClothSharedSimConfig::bUseXPBDConstraints");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChaosClothingSimulationFactory : public UClothingSimulationFactory
{
public:
};

static_assert(sizeof(UChaosClothingSimulationFactory) == 0x28, "Size mismatch for UChaosClothingSimulationFactory");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UChaosClothingInteractor : public UClothingInteractor
{
public:

public:
    void ResetAndTeleport(bool& bReset, bool& bTeleport); // 0xc60cdd8 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetAerodynamics(float& DragCoefficient, float& LiftCoefficient, FVector& WindVelocity); // 0xc60cff4 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetAnimDrive(FVector2D& AnimDriveStiffness, FVector2D& AnimDriveDamping); // 0xc60d28c (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetAnimDriveLinear(float& AnimDriveStiffness); // 0xc60d3e4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetBackstop(bool& bEnabled); // 0xc60d510 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetCollision(float& CollisionThickness, float& FrictionCoefficient, bool& bUseCCD, float& SelfCollisionThickness); // 0xc60d63c (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetDamping(float& DampingCoefficient, float& LocalDampingCoefficient); // 0xc60da00 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetGravity(float& GravityScale, bool& bIsGravityOverridden, FVector& GravityOverride); // 0xc60dc0c (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetLongRangeAttachment(FVector2D& TetherStiffness, FVector2D& TetherScale); // 0xc60dea8 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetLongRangeAttachmentLinear(float& TetherStiffness, float& TetherScale); // 0xc60e000 (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetMaterial(FVector2D& EdgeStiffness, FVector2D& BendingStiffness, FVector2D& AreaStiffness); // 0xc60e20c (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetMaterialBuckling(FVector2D& BucklingRatio, FVector2D& BucklingStiffness); // 0xc60e3dc (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetMaterialLinear(float& EdgeStiffness, float& BendingStiffness, float& AreaStiffness); // 0xc60e534 (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetPressure(FVector2D& Pressure); // 0xc60e818 (Index: 0xd, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetVelocityClamps(bool& bEnableLinearVelocityClamping, FVector& MaxLinearVelocity, bool& bEnableLinearAccelerationClamping, FVector& MaxLinearAcceleration, bool& bEnableAngularVelocityClamping, float& MaxAngularVelocity, bool& bEnableAngularAccelerationClamping, float& MaxAngularAcceleration); // 0xc60e8e4 (Index: 0xe, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetVelocityScale(FVector& LinearVelocityScale, float& AngularVelocityScale, float& FictitiousAngularScale); // 0xc60ed34 (Index: 0xf, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetWind(FVector2D& Drag, FVector2D& Lift, float& AirDensity, FVector& WindVelocity, FVector2D& OuterDrag, FVector2D& OuterLift); // 0xc60eef4 (Index: 0x10, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UChaosClothingInteractor) == 0x50, "Size mismatch for UChaosClothingInteractor");

// Size: 0xb0 (Inherited: 0xb8, Single: 0xfffffff8)
class UChaosClothingSimulationInteractor : public UClothingSimulationInteractor
{
public:
};

static_assert(sizeof(UChaosClothingSimulationInteractor) == 0xb0, "Size mismatch for UChaosClothingSimulationInteractor");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FChaosClothWeightedValue
{
    float Low; // 0x0 (Size: 0x4, Type: FloatProperty)
    float High; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FChaosClothWeightedValue) == 0x8, "Size mismatch for FChaosClothWeightedValue");
static_assert(offsetof(FChaosClothWeightedValue, Low) == 0x0, "Offset mismatch for FChaosClothWeightedValue::Low");
static_assert(offsetof(FChaosClothWeightedValue, High) == 0x4, "Offset mismatch for FChaosClothWeightedValue::High");

