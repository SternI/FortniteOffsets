/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AutoAimWeaponUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "UMG.h"
#include "GameplayAbilities.h"

// Size: 0x2b0 (Inherited: 0x428, Single: 0xfffffe88)
class UFortAutoAimTargetImage : public UImage
{
public:
    FScalableFloat AutoAimReticleSize; // 0x280 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_2a8[0x8]; // 0x2a8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAutoAimTargetImage) == 0x2b0, "Size mismatch for UFortAutoAimTargetImage");
static_assert(offsetof(UFortAutoAimTargetImage, AutoAimReticleSize) == 0x280, "Offset mismatch for UFortAutoAimTargetImage::AutoAimReticleSize");

