/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_DelMarProductModeUserFacingData
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"

// Size: 0x78 (Inherited: 0xa0, Single: 0xffffffd8)
class UBP_DelMarProductModeUserFacingData_C : public UProductModeUserFacingData
{
public:
};

static_assert(sizeof(UBP_DelMarProductModeUserFacingData_C) == 0x78, "Size mismatch for UBP_DelMarProductModeUserFacingData_C");

