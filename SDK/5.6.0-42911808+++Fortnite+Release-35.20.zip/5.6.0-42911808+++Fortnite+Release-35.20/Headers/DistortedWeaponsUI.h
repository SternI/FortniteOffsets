/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DistortedWeaponsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "FortniteGame.h"

// Size: 0x338 (Inherited: 0xa48, Single: 0xfffff8f0)
class UChromeWeaponInfoWidget : public UFortHUDElementWidget
{
public:
    UFortHUDContext* HUDContext; // 0x318 (Size: 0x8, Type: ObjectProperty)
    UFortWorldMultiItemXPComponent* CurrentXpComponent; // 0x320 (Size: 0x8, Type: ObjectProperty)
    UAthenaItemTierWidget* ItemTierWidget; // 0x328 (Size: 0x8, Type: ObjectProperty)
    UFortKeybindWidget* KeybindWidget; // 0x330 (Size: 0x8, Type: ObjectProperty)

protected:
    EFortRarity GetCurrentWeaponRarity() const; // 0x11ee05d4 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void HandlePowerUpPending(); // 0x11ee05f8 (Index: 0x1, Flags: Final|Native|Protected)
    void HandleUpgradeTriggered(float& ReloadTime, EFortWeaponReloadType& ReloadType); // 0x11ee060c (Index: 0x2, Flags: Final|Native|Protected)
    void HandleWeaponEquipped(AFortWeapon*& NewWeapon, AFortWeapon*& PrevWeapon); // 0x11ee0818 (Index: 0x3, Flags: Final|Native|Protected)
    void HandleWeaponUnEquipped(); // 0x11ee0a20 (Index: 0x4, Flags: Final|Native|Protected)
    void HandleWeaponUpgraded(); // 0x11ee0a34 (Index: 0x5, Flags: Final|Native|Protected)
    void HandleXpChanged(float& const XPDelta, float& const CurrentXPPercentage); // 0x11ee0a48 (Index: 0x6, Flags: Final|Native|Protected)
    virtual void OnGainedXp(float& CurrentXPPercentage); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void OnReadyToUpgradeWeapon(EFortRarity& NextRarity); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void OnWeaponEquipped(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void OnWeaponRemoved(); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void OnWeaponStartUpgrading(); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
    virtual void OnWeaponUpgraded(); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UChromeWeaponInfoWidget) == 0x338, "Size mismatch for UChromeWeaponInfoWidget");
static_assert(offsetof(UChromeWeaponInfoWidget, HUDContext) == 0x318, "Offset mismatch for UChromeWeaponInfoWidget::HUDContext");
static_assert(offsetof(UChromeWeaponInfoWidget, CurrentXpComponent) == 0x320, "Offset mismatch for UChromeWeaponInfoWidget::CurrentXpComponent");
static_assert(offsetof(UChromeWeaponInfoWidget, ItemTierWidget) == 0x328, "Offset mismatch for UChromeWeaponInfoWidget::ItemTierWidget");
static_assert(offsetof(UChromeWeaponInfoWidget, KeybindWidget) == 0x330, "Offset mismatch for UChromeWeaponInfoWidget::KeybindWidget");

