/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaBasePlayer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "MediaAssets.h"
#include "MediaUtils.h"
#include "EpicStreamMediaSource.h"

// Size: 0x58 (Inherited: 0xb8, Single: 0xffffffa0)
class UEpicMediaPrioritySystem : public UEngineSubsystem
{
public:
};

static_assert(sizeof(UEpicMediaPrioritySystem) == 0x58, "Size mismatch for UEpicMediaPrioritySystem");

// Size: 0x158 (Inherited: 0x28, Single: 0x130)
class UEpicBaseStreamingVideo : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    uint8_t VideoOnTerminalError[0x10]; // 0x30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t VideoOnSuccess[0x10]; // 0x40 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t VideoOnClosed[0x10]; // 0x50 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t VideoOnEndReached[0x10]; // 0x60 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t VideoOnOpened[0x10]; // 0x70 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t VideoOnOpenTimeout[0x10]; // 0x80 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t VideoOnResumed[0x10]; // 0x90 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UEpicStreamMediaSource* MediaSource; // 0xa0 (Size: 0x8, Type: ObjectProperty)
    UMediaPlayer* MediaPlayer; // 0xa8 (Size: 0x8, Type: ObjectProperty)
    FIntPoint VideoSize; // 0xb0 (Size: 0x8, Type: StructProperty)
    FEpicMediaPriorityInfo PriorityInfo; // 0xb8 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_bb[0x15]; // 0xbb (Size: 0x15, Type: PaddingProperty)
    USoundSubmixBase* DefaultSubmix; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    USoundSubmixBase* LicensedSubmix; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UMediaSoundComponent* MediaSoundComponent; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_e8[0x58]; // 0xe8 (Size: 0x58, Type: PaddingProperty)
    UMediaTexture* PendingMediaTexture; // 0x140 (Size: 0x8, Type: ObjectProperty)
    bool bAwaitingRetry; // 0x148 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_149[0x3]; // 0x149 (Size: 0x3, Type: PaddingProperty)
    float RetryDelayElapsed; // 0x14c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_150[0x8]; // 0x150 (Size: 0x8, Type: PaddingProperty)

public:
    void ClearSyncTimes(); // 0xc5aebc0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool GetLicensedAudio(); // 0xc5aebd4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    UMediaPlayer* GetMediaPlayer(); // 0xc5aebec (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    FMediaPlayerOptions GetMediaPlayerOptions(); // 0xc5aec04 (Index: 0x3, Flags: Native|Public)
    UEpicStreamMediaSource* GetMediaSource(); // 0x48a9e20 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    FEpicMediaPriorityInfo GetPriorityInfo() const; // 0xc5aec6c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMediaSoundComponent* GetSoundComponent(); // 0xbd722dc (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    bool Init(UMediaTexture*& InVideoTexture, UMediaPlayer*& InMediaPlayer, UEpicStreamMediaSource*& InMediaSource, bool& InCDNFailover); // 0xc5af3ec (Index: 0xd, Flags: Native|Public|BlueprintCallable)
    bool IsSyncStartTimeSet() const; // 0xc5af7ac (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void MethodDebounce(bool& bDebounce); // 0xc5af7c4 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    bool Open(FMediaPlayerOptions& InMediaOptions); // 0xc5b0280 (Index: 0x12, Flags: Native|Public|BlueprintCallable)
    void Release(); // 0x3c6d244 (Index: 0x13, Flags: Native|Public|BlueprintCallable)
    void SetCreateAudioComponent(bool& bInCreateAudioComponent); // 0xc5b068c (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    void SetEnableExternalCloseCallback(bool& bInEnable); // 0xc5b07b8 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void SetOpenTimeout(double& InTimeoutTime); // 0xc5b08e4 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void SetPriorityInfo(FEpicMediaPriorityInfo& InPriorityInfo); // 0xc5b0a14 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void SetSoundSubmixes(UMediaSoundComponent*& InSoundComponent, USoundSubmixBase*& InDefault, USoundSubmixBase*& InLicensed); // 0xc5b0ae4 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    void SetSyncTimes(FDateTime& InNowTime, FDateTime& InStartTime, bool& DynamicStart, float& InOffset_s, float& InDelay_s); // 0xc5b0f60 (Index: 0x1a, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetVideoSize(int32_t& const Width, int32_t& const Height); // 0xc5b11fc (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable)
    void Start(FString& InVUID, UMediaTexture*& InVideoTexture); // 0xc5b140c (Index: 0x1c, Flags: Native|Public|BlueprintCallable)
    void Stop(bool& bRelease, bool& bStopPlayer); // 0xc5b17e0 (Index: 0x1d, Flags: Native|Public|BlueprintCallable)

private:
    void HandleLicensedAudioTreatmentChanged(UCPTypes& UCPType); // 0xc5aec90 (Index: 0x7, Flags: Final|Native|Private)

protected:
    void HandleMediaClosed(); // 0xc5aedbc (Index: 0x8, Flags: Final|Native|Protected)
    void HandleMediaEndReached(); // 0xc5aedd0 (Index: 0x9, Flags: Final|Native|Protected)
    void HandleMediaOpened(FString& OpenedUrl); // 0xc5aede4 (Index: 0xa, Flags: Final|Native|Protected)
    void HandleMediaOpenedFailed(FString& FailedUrl); // 0xc5af0e8 (Index: 0xb, Flags: Final|Native|Protected)
    void HandleMediaResumed(); // 0x31f3198 (Index: 0xc, Flags: Native|Protected)
    void OnFailedURL(FString& URL, int32_t& Code, EEpicMediaRequestType& RequestType); // 0xc5af8f0 (Index: 0x10, Flags: Native|Protected)
    void OnSuccessfulURL(FString& URL, int32_t& Code, EEpicMediaRequestType& RequestType); // 0xc5afdb8 (Index: 0x11, Flags: Native|Protected)
    bool RetryOnError(EBaseMediaTerminalErrorReason& Reason, int32_t& ErrorCode, EEpicMediaRequestType& RequestType); // 0xc5b03a4 (Index: 0x14, Flags: Final|Native|Protected)
};

static_assert(sizeof(UEpicBaseStreamingVideo) == 0x158, "Size mismatch for UEpicBaseStreamingVideo");
static_assert(offsetof(UEpicBaseStreamingVideo, VideoOnTerminalError) == 0x30, "Offset mismatch for UEpicBaseStreamingVideo::VideoOnTerminalError");
static_assert(offsetof(UEpicBaseStreamingVideo, VideoOnSuccess) == 0x40, "Offset mismatch for UEpicBaseStreamingVideo::VideoOnSuccess");
static_assert(offsetof(UEpicBaseStreamingVideo, VideoOnClosed) == 0x50, "Offset mismatch for UEpicBaseStreamingVideo::VideoOnClosed");
static_assert(offsetof(UEpicBaseStreamingVideo, VideoOnEndReached) == 0x60, "Offset mismatch for UEpicBaseStreamingVideo::VideoOnEndReached");
static_assert(offsetof(UEpicBaseStreamingVideo, VideoOnOpened) == 0x70, "Offset mismatch for UEpicBaseStreamingVideo::VideoOnOpened");
static_assert(offsetof(UEpicBaseStreamingVideo, VideoOnOpenTimeout) == 0x80, "Offset mismatch for UEpicBaseStreamingVideo::VideoOnOpenTimeout");
static_assert(offsetof(UEpicBaseStreamingVideo, VideoOnResumed) == 0x90, "Offset mismatch for UEpicBaseStreamingVideo::VideoOnResumed");
static_assert(offsetof(UEpicBaseStreamingVideo, MediaSource) == 0xa0, "Offset mismatch for UEpicBaseStreamingVideo::MediaSource");
static_assert(offsetof(UEpicBaseStreamingVideo, MediaPlayer) == 0xa8, "Offset mismatch for UEpicBaseStreamingVideo::MediaPlayer");
static_assert(offsetof(UEpicBaseStreamingVideo, VideoSize) == 0xb0, "Offset mismatch for UEpicBaseStreamingVideo::VideoSize");
static_assert(offsetof(UEpicBaseStreamingVideo, PriorityInfo) == 0xb8, "Offset mismatch for UEpicBaseStreamingVideo::PriorityInfo");
static_assert(offsetof(UEpicBaseStreamingVideo, DefaultSubmix) == 0xd0, "Offset mismatch for UEpicBaseStreamingVideo::DefaultSubmix");
static_assert(offsetof(UEpicBaseStreamingVideo, LicensedSubmix) == 0xd8, "Offset mismatch for UEpicBaseStreamingVideo::LicensedSubmix");
static_assert(offsetof(UEpicBaseStreamingVideo, MediaSoundComponent) == 0xe0, "Offset mismatch for UEpicBaseStreamingVideo::MediaSoundComponent");
static_assert(offsetof(UEpicBaseStreamingVideo, PendingMediaTexture) == 0x140, "Offset mismatch for UEpicBaseStreamingVideo::PendingMediaTexture");
static_assert(offsetof(UEpicBaseStreamingVideo, bAwaitingRetry) == 0x148, "Offset mismatch for UEpicBaseStreamingVideo::bAwaitingRetry");
static_assert(offsetof(UEpicBaseStreamingVideo, RetryDelayElapsed) == 0x14c, "Offset mismatch for UEpicBaseStreamingVideo::RetryDelayElapsed");

// Size: 0x3 (Inherited: 0x0, Single: 0x3)
struct FEpicMediaPriorityInfo
{
    bool bCanBeInterrupted; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bCanInterruptOtherAndHold; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Type; // 0x2 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FEpicMediaPriorityInfo) == 0x3, "Size mismatch for FEpicMediaPriorityInfo");
static_assert(offsetof(FEpicMediaPriorityInfo, bCanBeInterrupted) == 0x0, "Offset mismatch for FEpicMediaPriorityInfo::bCanBeInterrupted");
static_assert(offsetof(FEpicMediaPriorityInfo, bCanInterruptOtherAndHold) == 0x1, "Offset mismatch for FEpicMediaPriorityInfo::bCanInterruptOtherAndHold");
static_assert(offsetof(FEpicMediaPriorityInfo, Type) == 0x2, "Offset mismatch for FEpicMediaPriorityInfo::Type");

// Size: 0xf8 (Inherited: 0x0, Single: 0xf8)
struct FEpicMediaPriorityPendingInfo
{
    UMediaTexture* MediaTexture; // 0x10 (Size: 0x8, Type: ObjectProperty)
    FMediaPlayerOptions MediaOptions; // 0x28 (Size: 0xc8, Type: StructProperty)
    FEpicMediaPriorityInfo PriorityInfo; // 0xf0 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_f3[0x5]; // 0xf3 (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(FEpicMediaPriorityPendingInfo) == 0xf8, "Size mismatch for FEpicMediaPriorityPendingInfo");
static_assert(offsetof(FEpicMediaPriorityPendingInfo, MediaTexture) == 0x10, "Offset mismatch for FEpicMediaPriorityPendingInfo::MediaTexture");
static_assert(offsetof(FEpicMediaPriorityPendingInfo, MediaOptions) == 0x28, "Offset mismatch for FEpicMediaPriorityPendingInfo::MediaOptions");
static_assert(offsetof(FEpicMediaPriorityPendingInfo, PriorityInfo) == 0xf0, "Offset mismatch for FEpicMediaPriorityPendingInfo::PriorityInfo");

