/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CrewUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "ModularGameplay.h"
#include "ModelViewViewModel.h"
#include "UMG.h"
#include "CommonUI.h"
#include "FortniteUI.h"
#include "FortniteGame.h"
#include "GameFeatures.h"

// Size: 0x58 (Inherited: 0x58, Single: 0x0)
class UFortAsyncAction_CrewCancelSubscription : public UBlueprintAsyncActionBase
{
public:
    uint8_t OnOperationCompleted[0x10]; // 0x30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_40[0x18]; // 0x40 (Size: 0x18, Type: PaddingProperty)

public:
    static UFortAsyncAction_CrewCancelSubscription* CancelSubscription(UUserWidget*& const ContextWidget); // 0x110caf38 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    void OnOperationCompleted__DelegateSignature(bool& Success); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
};

static_assert(sizeof(UFortAsyncAction_CrewCancelSubscription) == 0x58, "Size mismatch for UFortAsyncAction_CrewCancelSubscription");
static_assert(offsetof(UFortAsyncAction_CrewCancelSubscription, OnOperationCompleted) == 0x30, "Offset mismatch for UFortAsyncAction_CrewCancelSubscription::OnOperationCompleted");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortProgressiveContentInterface : public UInterface
{
public:
};

static_assert(sizeof(UFortProgressiveContentInterface) == 0x28, "Size mismatch for UFortProgressiveContentInterface");

// Size: 0xc8 (Inherited: 0x250, Single: 0xfffffe78)
class UFortTemporaryItemsComponent : public UControllerComponent
{
public:
    UFortTemporaryItemsManager* TemporaryItemsManager; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFortMcpProfileAthena*> AthenaProfile; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)

private:
    void OnAthenaProfileInitialized(); // 0x5fd4734 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortTemporaryItemsComponent) == 0xc8, "Size mismatch for UFortTemporaryItemsComponent");
static_assert(offsetof(UFortTemporaryItemsComponent, TemporaryItemsManager) == 0xb8, "Offset mismatch for UFortTemporaryItemsComponent::TemporaryItemsManager");
static_assert(offsetof(UFortTemporaryItemsComponent, AthenaProfile) == 0xc0, "Offset mismatch for UFortTemporaryItemsComponent::AthenaProfile");

// Size: 0x60 (Inherited: 0x88, Single: 0xffffffd8)
class UFortTemporaryItemsManager : public UWorldSubsystem
{
public:

private:
    void OnTemporaryItemsStateChanged(); // 0x110cbec4 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortTemporaryItemsManager) == 0x60, "Size mismatch for UFortTemporaryItemsManager");

// Size: 0x88 (Inherited: 0x90, Single: 0xfffffff8)
class UFortTemporaryItemsRewardGroupVM : public UMVVMViewModelBase
{
public:
    uint8_t Pad_68[0x8]; // 0x68 (Size: 0x8, Type: PaddingProperty)
    uint8_t Category; // 0x70 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
    TArray<UFortTemporaryItemsRewardVM*> Rewards; // 0x78 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortTemporaryItemsRewardGroupVM) == 0x88, "Size mismatch for UFortTemporaryItemsRewardGroupVM");
static_assert(offsetof(UFortTemporaryItemsRewardGroupVM, Category) == 0x70, "Offset mismatch for UFortTemporaryItemsRewardGroupVM::Category");
static_assert(offsetof(UFortTemporaryItemsRewardGroupVM, Rewards) == 0x78, "Offset mismatch for UFortTemporaryItemsRewardGroupVM::Rewards");

// Size: 0x80 (Inherited: 0x90, Single: 0xfffffff0)
class UFortTemporaryItemsRewardVM : public UMVVMViewModelBase
{
public:
    uint8_t Pad_68[0x8]; // 0x68 (Size: 0x8, Type: PaddingProperty)
    UFortAccountItemDefinition* ItemDefinition; // 0x70 (Size: 0x8, Type: ObjectProperty)
    bool bIsOwned; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortTemporaryItemsRewardVM) == 0x80, "Size mismatch for UFortTemporaryItemsRewardVM");
static_assert(offsetof(UFortTemporaryItemsRewardVM, ItemDefinition) == 0x70, "Offset mismatch for UFortTemporaryItemsRewardVM::ItemDefinition");
static_assert(offsetof(UFortTemporaryItemsRewardVM, bIsOwned) == 0x78, "Offset mismatch for UFortTemporaryItemsRewardVM::bIsOwned");

// Size: 0x2d0 (Inherited: 0x458, Single: 0xfffffe78)
class UFortTemporaryItemsRow : public UUserWidget
{
public:

public:
    FText GetCategoryText(EAthenaCustomizationCategory& const InCategory) const; // 0x110cb46c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void SetTileView(UTileView*& InTileView); // 0xf1bccdc (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortTemporaryItemsRow) == 0x2d0, "Size mismatch for UFortTemporaryItemsRow");

// Size: 0x14b0 (Inherited: 0x1bd0, Single: 0xfffff8e0)
class UFortTemporaryItemsTileButton : public UCommonButtonBase
{
public:
    uint8_t Pad_14a0[0x8]; // 0x14a0 (Size: 0x8, Type: PaddingProperty)
    UFortCosmeticItemCard* ItemCard; // 0x14a8 (Size: 0x8, Type: ObjectProperty)

public:
    void SetupRewardItem(UFortAccountItemDefinition*& const ItemDef); // 0x110ccdb8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortTemporaryItemsTileButton) == 0x14b0, "Size mismatch for UFortTemporaryItemsTileButton");
static_assert(offsetof(UFortTemporaryItemsTileButton, ItemCard) == 0x14a8, "Offset mismatch for UFortTemporaryItemsTileButton::ItemCard");

// Size: 0x90 (Inherited: 0x100, Single: 0xffffff90)
class UFortTemporaryItemsVM : public UFortPerUserViewModel
{
public:
    TArray<UFortTemporaryItemsRewardGroupVM*> RewardGroups; // 0x70 (Size: 0x10, Type: ArrayProperty)
    FDateTime ExpirationDate; // 0x80 (Size: 0x8, Type: StructProperty)
    UFortTemporaryItemsManager* TemporaryItemsManager; // 0x88 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortTemporaryItemsVM) == 0x90, "Size mismatch for UFortTemporaryItemsVM");
static_assert(offsetof(UFortTemporaryItemsVM, RewardGroups) == 0x70, "Offset mismatch for UFortTemporaryItemsVM::RewardGroups");
static_assert(offsetof(UFortTemporaryItemsVM, ExpirationDate) == 0x80, "Offset mismatch for UFortTemporaryItemsVM::ExpirationDate");
static_assert(offsetof(UFortTemporaryItemsVM, TemporaryItemsManager) == 0x88, "Offset mismatch for UFortTemporaryItemsVM::TemporaryItemsManager");

// Size: 0x58 (Inherited: 0xb0, Single: 0xffffffa8)
class UCrewAsyncActions : public UFortAsyncAction_FromFunctionBase
{
public:

public:
    static UFortAsyncAction_FromFunctionBase* ContinueSubscription(UUserWidget*& const ContextWidget); // 0x110cb2f8 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UFortAsyncAction_FromFunctionBase* PurchaseSubscription(UUserWidget*& const ContextWidget); // 0x110cc004 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UFortAsyncAction_FromFunctionBase* RedeemPurchasesAndClaimRewards(UUserWidget*& const ContextWidget); // 0x110cc12c (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UFortAsyncAction_FromFunctionBase* RejoinSubscription(UUserWidget*& const ContextWidget); // 0x110cc254 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UCrewAsyncActions) == 0x58, "Size mismatch for UCrewAsyncActions");

// Size: 0x50 (Inherited: 0x118, Single: 0xffffff38)
class UCrewShopOfferOverride : public UFortItemShopOfferInspectionScreenOverrideBase
{
public:
    TSoftClassPtr WidgetToShow; // 0x30 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UCrewShopOfferOverride) == 0x50, "Size mismatch for UCrewShopOfferOverride");
static_assert(offsetof(UCrewShopOfferOverride, WidgetToShow) == 0x30, "Offset mismatch for UCrewShopOfferOverride::WidgetToShow");

// Size: 0x4e8 (Inherited: 0x1018, Single: 0xfffff4d0)
class UCrewStandaloneSubscriptionContentContainer : public UFortStandaloneFrontend
{
public:
    UCrewSubscriptionContentContainer* Widget_CrewContentContainer; // 0x4e0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UCrewStandaloneSubscriptionContentContainer) == 0x4e8, "Size mismatch for UCrewStandaloneSubscriptionContentContainer");
static_assert(offsetof(UCrewStandaloneSubscriptionContentContainer, Widget_CrewContentContainer) == 0x4e0, "Offset mismatch for UCrewStandaloneSubscriptionContentContainer::Widget_CrewContentContainer");

// Size: 0x4a8 (Inherited: 0xb38, Single: 0xfffff970)
class UCrewSubscriptionContentContainer : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x30]; // 0x408 (Size: 0x30, Type: PaddingProperty)
    TArray<FCrewSubscriptionContentTabData> TabsData; // 0x438 (Size: 0x10, Type: ArrayProperty)
    FDataTableRowHandle NextTabInputAction; // 0x448 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle PreviousTabInputAction; // 0x458 (Size: 0x10, Type: StructProperty)
    UDynamicEntryBox* EntryBox_Tabs; // 0x468 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonGroupBase* ButtonGroup_Tabs; // 0x470 (Size: 0x8, Type: ObjectProperty)
    UCommonActivatableWidgetSwitcher* Switcher_Tabs; // 0x478 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_TabsContainer; // 0x480 (Size: 0x8, Type: ObjectProperty)
    float SpacingAdjustmentForTabs; // 0x488 (Size: 0x4, Type: FloatProperty)
    FPrimaryContentSetup ContentSetup; // 0x48c (Size: 0x4, Type: StructProperty)
    uint8_t Pad_490[0x18]; // 0x490 (Size: 0x18, Type: PaddingProperty)

protected:
    virtual void OnTabSelected(int32_t& TabIndex); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCrewSubscriptionContentContainer) == 0x4a8, "Size mismatch for UCrewSubscriptionContentContainer");
static_assert(offsetof(UCrewSubscriptionContentContainer, TabsData) == 0x438, "Offset mismatch for UCrewSubscriptionContentContainer::TabsData");
static_assert(offsetof(UCrewSubscriptionContentContainer, NextTabInputAction) == 0x448, "Offset mismatch for UCrewSubscriptionContentContainer::NextTabInputAction");
static_assert(offsetof(UCrewSubscriptionContentContainer, PreviousTabInputAction) == 0x458, "Offset mismatch for UCrewSubscriptionContentContainer::PreviousTabInputAction");
static_assert(offsetof(UCrewSubscriptionContentContainer, EntryBox_Tabs) == 0x468, "Offset mismatch for UCrewSubscriptionContentContainer::EntryBox_Tabs");
static_assert(offsetof(UCrewSubscriptionContentContainer, ButtonGroup_Tabs) == 0x470, "Offset mismatch for UCrewSubscriptionContentContainer::ButtonGroup_Tabs");
static_assert(offsetof(UCrewSubscriptionContentContainer, Switcher_Tabs) == 0x478, "Offset mismatch for UCrewSubscriptionContentContainer::Switcher_Tabs");
static_assert(offsetof(UCrewSubscriptionContentContainer, Widget_TabsContainer) == 0x480, "Offset mismatch for UCrewSubscriptionContentContainer::Widget_TabsContainer");
static_assert(offsetof(UCrewSubscriptionContentContainer, SpacingAdjustmentForTabs) == 0x488, "Offset mismatch for UCrewSubscriptionContentContainer::SpacingAdjustmentForTabs");
static_assert(offsetof(UCrewSubscriptionContentContainer, ContentSetup) == 0x48c, "Offset mismatch for UCrewSubscriptionContentContainer::ContentSetup");

// Size: 0x48 (Inherited: 0x78, Single: 0xffffffd0)
class UCrewUIGameFeatureDataAction : public UFortUIGameFeatureAction
{
public:
    TSoftClassPtr StandaloneCrewUpsellScreen; // 0x28 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UCrewUIGameFeatureDataAction) == 0x48, "Size mismatch for UCrewUIGameFeatureDataAction");
static_assert(offsetof(UCrewUIGameFeatureDataAction, StandaloneCrewUpsellScreen) == 0x28, "Offset mismatch for UCrewUIGameFeatureDataAction::StandaloneCrewUpsellScreen");

// Size: 0xe8 (Inherited: 0x78, Single: 0x70)
class UCrewUIGameFeatureAction : public UFortUIGameFeatureAction
{
public:
    TSoftClassPtr CrewContentContainerClass; // 0x28 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr CrewStandaloneContentContainerClass; // 0x48 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr ProgressionScreenClass; // 0x68 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr CrewPriceChangeAcknowledgeModalClass; // 0x88 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr MultiSubAlertModalClass; // 0xa8 (Size: 0x20, Type: SoftClassProperty)
    TArray<FFortProgressiveSet> ProgressiveCosmeticSets; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortCosmeticPreviewData> CustomCrewPreviewData; // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCrewUIGameFeatureAction) == 0xe8, "Size mismatch for UCrewUIGameFeatureAction");
static_assert(offsetof(UCrewUIGameFeatureAction, CrewContentContainerClass) == 0x28, "Offset mismatch for UCrewUIGameFeatureAction::CrewContentContainerClass");
static_assert(offsetof(UCrewUIGameFeatureAction, CrewStandaloneContentContainerClass) == 0x48, "Offset mismatch for UCrewUIGameFeatureAction::CrewStandaloneContentContainerClass");
static_assert(offsetof(UCrewUIGameFeatureAction, ProgressionScreenClass) == 0x68, "Offset mismatch for UCrewUIGameFeatureAction::ProgressionScreenClass");
static_assert(offsetof(UCrewUIGameFeatureAction, CrewPriceChangeAcknowledgeModalClass) == 0x88, "Offset mismatch for UCrewUIGameFeatureAction::CrewPriceChangeAcknowledgeModalClass");
static_assert(offsetof(UCrewUIGameFeatureAction, MultiSubAlertModalClass) == 0xa8, "Offset mismatch for UCrewUIGameFeatureAction::MultiSubAlertModalClass");
static_assert(offsetof(UCrewUIGameFeatureAction, ProgressiveCosmeticSets) == 0xc8, "Offset mismatch for UCrewUIGameFeatureAction::ProgressiveCosmeticSets");
static_assert(offsetof(UCrewUIGameFeatureAction, CustomCrewPreviewData) == 0xd8, "Offset mismatch for UCrewUIGameFeatureAction::CustomCrewPreviewData");

// Size: 0x450 (Inherited: 0xf68, Single: 0xfffff4e8)
class UFortProgressiveContentContainer : public UFortSubscriptionContentBase
{
public:
    uint8_t Pad_430[0x8]; // 0x430 (Size: 0x8, Type: PaddingProperty)
    UCommonActivatableWidgetSwitcher* Switcher_PrimaryContent; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UFortProgressiveTableOfContentsScreen* Widget_ProgressiveTableOfContentsScreen; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UFortProgressiveItemScreen* Widget_ProgressiveItemScreen; // 0x448 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortProgressiveContentContainer) == 0x450, "Size mismatch for UFortProgressiveContentContainer");
static_assert(offsetof(UFortProgressiveContentContainer, Switcher_PrimaryContent) == 0x438, "Offset mismatch for UFortProgressiveContentContainer::Switcher_PrimaryContent");
static_assert(offsetof(UFortProgressiveContentContainer, Widget_ProgressiveTableOfContentsScreen) == 0x440, "Offset mismatch for UFortProgressiveContentContainer::Widget_ProgressiveTableOfContentsScreen");
static_assert(offsetof(UFortProgressiveContentContainer, Widget_ProgressiveItemScreen) == 0x448, "Offset mismatch for UFortProgressiveContentContainer::Widget_ProgressiveItemScreen");

// Size: 0x480 (Inherited: 0xf98, Single: 0xfffff4e8)
class UFortProgressiveItemScreen : public UFortProgressiveScreenBase
{
public:
    TSoftClassPtr MoreInfoModalClass; // 0x460 (Size: 0x20, Type: SoftClassProperty)

protected:
    void HandleBackClicked(); // 0x110cbde8 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleMoreInfoClicked(); // 0x110cbe34 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleSubscribeEngaged(); // 0x110cbe5c (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnSubscriptionPurchaseComplete(bool& bSuccess); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    void SendAnalyticsEvent(FString& Event, FString& FullfillmentId, int32_t& StageIndex); // 0x110cc3a8 (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortProgressiveItemScreen) == 0x480, "Size mismatch for UFortProgressiveItemScreen");
static_assert(offsetof(UFortProgressiveItemScreen, MoreInfoModalClass) == 0x460, "Offset mismatch for UFortProgressiveItemScreen::MoreInfoModalClass");

// Size: 0x460 (Inherited: 0xb38, Single: 0xfffff928)
class UFortProgressiveScreenBase : public UCommonActivatableWidget
{
public:

protected:
    virtual void BP_OnContainerTabVisibilityUpdated(bool& const bTabsVisible, float& const SpacingAdjustmentForTabs); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortProgressiveScreenBase) == 0x460, "Size mismatch for UFortProgressiveScreenBase");

// Size: 0x480 (Inherited: 0xf98, Single: 0xfffff4e8)
class UFortProgressiveTableOfContentsScreen : public UFortProgressiveScreenBase
{
public:
    TSoftClassPtr MoreInfoModalClass; // 0x460 (Size: 0x20, Type: SoftClassProperty)

protected:
    void HandleBackClicked(); // 0x110cbe04 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleInspectSetTile(); // 0x110cbe18 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleMoreInfoClicked(); // 0x110cbe48 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleSubscribeEngaged(); // 0x110cbe70 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnSubscriptionPurchaseComplete(bool& bSuccess); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortProgressiveTableOfContentsScreen) == 0x480, "Size mismatch for UFortProgressiveTableOfContentsScreen");
static_assert(offsetof(UFortProgressiveTableOfContentsScreen, MoreInfoModalClass) == 0x460, "Offset mismatch for UFortProgressiveTableOfContentsScreen::MoreInfoModalClass");

// Size: 0x100 (Inherited: 0x100, Single: 0x0)
class UCrewBenefitVM : public UFortPerUserViewModel
{
public:
    uint8_t Pad_70[0x78]; // 0x70 (Size: 0x78, Type: PaddingProperty)
    TArray<UFortItemVM*> CrewPackItems; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_f8[0x8]; // 0xf8 (Size: 0x8, Type: PaddingProperty)

public:
    FString GetBackgroundImageURL() const; // 0x110cb420 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FColor GetColor1() const; // 0xf1a99e8 (Index: 0x1, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FColor GetColor2() const; // 0xfea8f70 (Index: 0x2, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FColor GetColor3() const; // 0x56ae47c (Index: 0x3, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FColor GetColor4() const; // 0x110cb5bc (Index: 0x4, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FDateTime GetComingSoonDate() const; // 0x110cb5d4 (Index: 0x5, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FText GetComingSoonText() const; // 0x110cb5f8 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetDescription() const; // 0x110cb634 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetHasMoreInfo() const; // 0x110cb6b4 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsMonthlySubscription() const; // 0x110cb70c (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsOwned() const; // 0x110cb728 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetSecondaryTileImageURL() const; // 0x110cbadc (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ECrewDetailsTag GetTag() const; // 0xca9e578 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetTagText() const; // 0x110cbbc4 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetTemplateId() const; // 0x110cbc58 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetTileImageURL() const; // 0x110cbc98 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetTileLabel() const; // 0x110cbce4 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetTitle() const; // 0x110cbd84 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ECrewTileType GetType() const; // 0x110cbdc8 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UCrewBenefitVM) == 0x100, "Size mismatch for UCrewBenefitVM");
static_assert(offsetof(UCrewBenefitVM, CrewPackItems) == 0xe8, "Offset mismatch for UCrewBenefitVM::CrewPackItems");

// Size: 0x90 (Inherited: 0x90, Single: 0x0)
class UCrewItemShopDataVM : public UMVVMViewModelBase
{
public:
    FText HighlightText; // 0x68 (Size: 0x10, Type: TextProperty)
    uint8_t HighlightIntensity; // 0x78 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
    FString TileImageURL; // 0x80 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(UCrewItemShopDataVM) == 0x90, "Size mismatch for UCrewItemShopDataVM");
static_assert(offsetof(UCrewItemShopDataVM, HighlightText) == 0x68, "Offset mismatch for UCrewItemShopDataVM::HighlightText");
static_assert(offsetof(UCrewItemShopDataVM, HighlightIntensity) == 0x78, "Offset mismatch for UCrewItemShopDataVM::HighlightIntensity");
static_assert(offsetof(UCrewItemShopDataVM, TileImageURL) == 0x80, "Offset mismatch for UCrewItemShopDataVM::TileImageURL");

// Size: 0x78 (Inherited: 0x90, Single: 0xffffffe8)
class UCrewCancellationInfoVM : public UMVVMViewModelBase
{
public:
    TArray<FText> BulletPoints; // 0x68 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCrewCancellationInfoVM) == 0x78, "Size mismatch for UCrewCancellationInfoVM");
static_assert(offsetof(UCrewCancellationInfoVM, BulletPoints) == 0x68, "Offset mismatch for UCrewCancellationInfoVM::BulletPoints");

// Size: 0x100 (Inherited: 0x100, Single: 0x0)
class UCrewPlatformAndCountriesNotificationVM : public UFortPerUserViewModel
{
public:
    uint8_t Pad_70[0x10]; // 0x70 (Size: 0x10, Type: PaddingProperty)
    FText Title; // 0x80 (Size: 0x10, Type: TextProperty)
    FText BodyText; // 0x90 (Size: 0x10, Type: TextProperty)
    FText CheckboxText; // 0xa0 (Size: 0x10, Type: TextProperty)
    FText ConfirmButtonText; // 0xb0 (Size: 0x10, Type: TextProperty)
    FText CancelSubscriptionButtonText; // 0xc0 (Size: 0x10, Type: TextProperty)
    FText MoreInfoText; // 0xd0 (Size: 0x10, Type: TextProperty)
    FText MoreInfoUrl; // 0xe0 (Size: 0x10, Type: TextProperty)
    TArray<FCrewTableRow> TableRows; // 0xf0 (Size: 0x10, Type: ArrayProperty)

protected:
    void ProcessAcknowledgment(bool& const Accepted); // 0x110cbed8 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UCrewPlatformAndCountriesNotificationVM) == 0x100, "Size mismatch for UCrewPlatformAndCountriesNotificationVM");
static_assert(offsetof(UCrewPlatformAndCountriesNotificationVM, Title) == 0x80, "Offset mismatch for UCrewPlatformAndCountriesNotificationVM::Title");
static_assert(offsetof(UCrewPlatformAndCountriesNotificationVM, BodyText) == 0x90, "Offset mismatch for UCrewPlatformAndCountriesNotificationVM::BodyText");
static_assert(offsetof(UCrewPlatformAndCountriesNotificationVM, CheckboxText) == 0xa0, "Offset mismatch for UCrewPlatformAndCountriesNotificationVM::CheckboxText");
static_assert(offsetof(UCrewPlatformAndCountriesNotificationVM, ConfirmButtonText) == 0xb0, "Offset mismatch for UCrewPlatformAndCountriesNotificationVM::ConfirmButtonText");
static_assert(offsetof(UCrewPlatformAndCountriesNotificationVM, CancelSubscriptionButtonText) == 0xc0, "Offset mismatch for UCrewPlatformAndCountriesNotificationVM::CancelSubscriptionButtonText");
static_assert(offsetof(UCrewPlatformAndCountriesNotificationVM, MoreInfoText) == 0xd0, "Offset mismatch for UCrewPlatformAndCountriesNotificationVM::MoreInfoText");
static_assert(offsetof(UCrewPlatformAndCountriesNotificationVM, MoreInfoUrl) == 0xe0, "Offset mismatch for UCrewPlatformAndCountriesNotificationVM::MoreInfoUrl");
static_assert(offsetof(UCrewPlatformAndCountriesNotificationVM, TableRows) == 0xf0, "Offset mismatch for UCrewPlatformAndCountriesNotificationVM::TableRows");

// Size: 0x98 (Inherited: 0x90, Single: 0x8)
class UCrewSubscriptionModalInfoVM : public UMVVMViewModelBase
{
public:
    FString ModalId; // 0x68 (Size: 0x10, Type: StrProperty)
    TArray<FText> Entries; // 0x78 (Size: 0x10, Type: ArrayProperty)
    FString QrCodeImageUrl; // 0x88 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(UCrewSubscriptionModalInfoVM) == 0x98, "Size mismatch for UCrewSubscriptionModalInfoVM");
static_assert(offsetof(UCrewSubscriptionModalInfoVM, ModalId) == 0x68, "Offset mismatch for UCrewSubscriptionModalInfoVM::ModalId");
static_assert(offsetof(UCrewSubscriptionModalInfoVM, Entries) == 0x78, "Offset mismatch for UCrewSubscriptionModalInfoVM::Entries");
static_assert(offsetof(UCrewSubscriptionModalInfoVM, QrCodeImageUrl) == 0x88, "Offset mismatch for UCrewSubscriptionModalInfoVM::QrCodeImageUrl");

// Size: 0xa8 (Inherited: 0x100, Single: 0xffffffa8)
class UCrewProgressiveItemsVM : public UFortPerUserViewModel
{
public:
    TArray<UCrewProgressiveSetVM*> AllSets; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<UCrewProgressiveSetVM*> VisibleSets; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortCosmeticPreviewData> PreviewData; // 0x90 (Size: 0x10, Type: ArrayProperty)
    bool bAllSetsComplete; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0x7]; // 0xa1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UCrewProgressiveItemsVM) == 0xa8, "Size mismatch for UCrewProgressiveItemsVM");
static_assert(offsetof(UCrewProgressiveItemsVM, AllSets) == 0x70, "Offset mismatch for UCrewProgressiveItemsVM::AllSets");
static_assert(offsetof(UCrewProgressiveItemsVM, VisibleSets) == 0x80, "Offset mismatch for UCrewProgressiveItemsVM::VisibleSets");
static_assert(offsetof(UCrewProgressiveItemsVM, PreviewData) == 0x90, "Offset mismatch for UCrewProgressiveItemsVM::PreviewData");
static_assert(offsetof(UCrewProgressiveItemsVM, bAllSetsComplete) == 0xa0, "Offset mismatch for UCrewProgressiveItemsVM::bAllSetsComplete");

// Size: 0xc0 (Inherited: 0x90, Single: 0x30)
class UCrewProgressiveRewardVM : public UMVVMViewModelBase
{
public:
    FText Name; // 0x68 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UMaterialInterface*> TileMaterial; // 0x78 (Size: 0x20, Type: SoftObjectProperty)
    TArray<UFortItemVM*> Items; // 0x98 (Size: 0x10, Type: ArrayProperty)
    TArray<FCosmeticVariantInfo> PreviewVariants; // 0xa8 (Size: 0x10, Type: ArrayProperty)
    bool bAllowPreviewStyles; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UCrewProgressiveRewardVM) == 0xc0, "Size mismatch for UCrewProgressiveRewardVM");
static_assert(offsetof(UCrewProgressiveRewardVM, Name) == 0x68, "Offset mismatch for UCrewProgressiveRewardVM::Name");
static_assert(offsetof(UCrewProgressiveRewardVM, TileMaterial) == 0x78, "Offset mismatch for UCrewProgressiveRewardVM::TileMaterial");
static_assert(offsetof(UCrewProgressiveRewardVM, Items) == 0x98, "Offset mismatch for UCrewProgressiveRewardVM::Items");
static_assert(offsetof(UCrewProgressiveRewardVM, PreviewVariants) == 0xa8, "Offset mismatch for UCrewProgressiveRewardVM::PreviewVariants");
static_assert(offsetof(UCrewProgressiveRewardVM, bAllowPreviewStyles) == 0xb8, "Offset mismatch for UCrewProgressiveRewardVM::bAllowPreviewStyles");

// Size: 0xf0 (Inherited: 0x100, Single: 0xfffffff0)
class UCrewProgressiveSelectionVM : public UFortPerUserViewModel
{
public:
    UCrewProgressiveRewardVM* SelectedReward; // 0x70 (Size: 0x8, Type: ObjectProperty)
    UCrewProgressiveStageVM* SelectedStage; // 0x78 (Size: 0x8, Type: ObjectProperty)
    UCrewProgressiveSetVM* SelectedSet; // 0x80 (Size: 0x8, Type: ObjectProperty)
    UFortItemVM* PreviewItem; // 0x88 (Size: 0x8, Type: ObjectProperty)
    FFortCosmeticPreviewData PreviewData; // 0x90 (Size: 0x50, Type: StructProperty)
    uint8_t Pad_e0[0x10]; // 0xe0 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UCrewProgressiveSelectionVM) == 0xf0, "Size mismatch for UCrewProgressiveSelectionVM");
static_assert(offsetof(UCrewProgressiveSelectionVM, SelectedReward) == 0x70, "Offset mismatch for UCrewProgressiveSelectionVM::SelectedReward");
static_assert(offsetof(UCrewProgressiveSelectionVM, SelectedStage) == 0x78, "Offset mismatch for UCrewProgressiveSelectionVM::SelectedStage");
static_assert(offsetof(UCrewProgressiveSelectionVM, SelectedSet) == 0x80, "Offset mismatch for UCrewProgressiveSelectionVM::SelectedSet");
static_assert(offsetof(UCrewProgressiveSelectionVM, PreviewItem) == 0x88, "Offset mismatch for UCrewProgressiveSelectionVM::PreviewItem");
static_assert(offsetof(UCrewProgressiveSelectionVM, PreviewData) == 0x90, "Offset mismatch for UCrewProgressiveSelectionVM::PreviewData");

// Size: 0xe8 (Inherited: 0x90, Single: 0x58)
class UCrewProgressiveSetVM : public UMVVMViewModelBase
{
public:
    FString FulfillmentId; // 0x68 (Size: 0x10, Type: StrProperty)
    FText Name; // 0x78 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UMaterialInterface*> TileMaterial; // 0x88 (Size: 0x20, Type: SoftObjectProperty)
    TArray<UCrewProgressiveStageVM*> Stages; // 0xa8 (Size: 0x10, Type: ArrayProperty)
    FDateTime CutoffDate; // 0xb8 (Size: 0x8, Type: StructProperty)
    FDateTime AcquisitionCutoffDate; // 0xc0 (Size: 0x8, Type: StructProperty)
    FDateTime AcquireStartDate; // 0xc8 (Size: 0x8, Type: StructProperty)
    FText AcquisitionCutoffDateText; // 0xd0 (Size: 0x10, Type: TextProperty)
    int32_t UnlockedStages; // 0xe0 (Size: 0x4, Type: IntProperty)
    uint8_t Progress; // 0xe4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_e5[0x3]; // 0xe5 (Size: 0x3, Type: PaddingProperty)

public:
    bool GetIsCompleted() const; // 0x110cb6ec (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCrewProgressiveStageVM* GetNextStage() const; // 0x110cbab8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetStageCount() const; // 0xa12d964 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UCrewProgressiveSetVM) == 0xe8, "Size mismatch for UCrewProgressiveSetVM");
static_assert(offsetof(UCrewProgressiveSetVM, FulfillmentId) == 0x68, "Offset mismatch for UCrewProgressiveSetVM::FulfillmentId");
static_assert(offsetof(UCrewProgressiveSetVM, Name) == 0x78, "Offset mismatch for UCrewProgressiveSetVM::Name");
static_assert(offsetof(UCrewProgressiveSetVM, TileMaterial) == 0x88, "Offset mismatch for UCrewProgressiveSetVM::TileMaterial");
static_assert(offsetof(UCrewProgressiveSetVM, Stages) == 0xa8, "Offset mismatch for UCrewProgressiveSetVM::Stages");
static_assert(offsetof(UCrewProgressiveSetVM, CutoffDate) == 0xb8, "Offset mismatch for UCrewProgressiveSetVM::CutoffDate");
static_assert(offsetof(UCrewProgressiveSetVM, AcquisitionCutoffDate) == 0xc0, "Offset mismatch for UCrewProgressiveSetVM::AcquisitionCutoffDate");
static_assert(offsetof(UCrewProgressiveSetVM, AcquireStartDate) == 0xc8, "Offset mismatch for UCrewProgressiveSetVM::AcquireStartDate");
static_assert(offsetof(UCrewProgressiveSetVM, AcquisitionCutoffDateText) == 0xd0, "Offset mismatch for UCrewProgressiveSetVM::AcquisitionCutoffDateText");
static_assert(offsetof(UCrewProgressiveSetVM, UnlockedStages) == 0xe0, "Offset mismatch for UCrewProgressiveSetVM::UnlockedStages");
static_assert(offsetof(UCrewProgressiveSetVM, Progress) == 0xe4, "Offset mismatch for UCrewProgressiveSetVM::Progress");

// Size: 0x98 (Inherited: 0x90, Single: 0x8)
class UCrewProgressiveStageVM : public UMVVMViewModelBase
{
public:
    TArray<UCrewProgressiveRewardVM*> Rewards; // 0x68 (Size: 0x10, Type: ArrayProperty)
    FText UnlockCriteria; // 0x78 (Size: 0x10, Type: TextProperty)
    int32_t StageIndex; // 0x88 (Size: 0x4, Type: IntProperty)
    int32_t RemainingMonths; // 0x8c (Size: 0x4, Type: IntProperty)
    bool bIsOwned; // 0x90 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)

public:
    FText GetName() const; // 0x110cba7c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UCrewProgressiveStageVM) == 0x98, "Size mismatch for UCrewProgressiveStageVM");
static_assert(offsetof(UCrewProgressiveStageVM, Rewards) == 0x68, "Offset mismatch for UCrewProgressiveStageVM::Rewards");
static_assert(offsetof(UCrewProgressiveStageVM, UnlockCriteria) == 0x78, "Offset mismatch for UCrewProgressiveStageVM::UnlockCriteria");
static_assert(offsetof(UCrewProgressiveStageVM, StageIndex) == 0x88, "Offset mismatch for UCrewProgressiveStageVM::StageIndex");
static_assert(offsetof(UCrewProgressiveStageVM, RemainingMonths) == 0x8c, "Offset mismatch for UCrewProgressiveStageVM::RemainingMonths");
static_assert(offsetof(UCrewProgressiveStageVM, bIsOwned) == 0x90, "Offset mismatch for UCrewProgressiveStageVM::bIsOwned");

// Size: 0x80 (Inherited: 0x100, Single: 0xffffff80)
class UCrewSelectionVM : public UFortPerUserViewModel
{
public:
    UCrewBenefitVM* HoveredBenefit; // 0x70 (Size: 0x8, Type: ObjectProperty)
    UCrewBenefitVM* SelectedBenefit; // 0x78 (Size: 0x8, Type: ObjectProperty)

public:
    void ClearHoveredBenefit(UCrewBenefitVM*& const Benefit); // 0x110cb060 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void ClearSelectedBenefit(UCrewBenefitVM*& const Benefit); // 0x110cb1ac (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void Reset(); // 0x110cc37c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCrewSelectionVM) == 0x80, "Size mismatch for UCrewSelectionVM");
static_assert(offsetof(UCrewSelectionVM, HoveredBenefit) == 0x70, "Offset mismatch for UCrewSelectionVM::HoveredBenefit");
static_assert(offsetof(UCrewSelectionVM, SelectedBenefit) == 0x78, "Offset mismatch for UCrewSelectionVM::SelectedBenefit");

// Size: 0x220 (Inherited: 0x100, Single: 0x120)
class UCrewVM : public UFortPerUserViewModel
{
public:
    uint8_t SubscriptionState; // 0x70 (Size: 0x1, Type: EnumProperty)
    bool bIsLegacySubscription; // 0x71 (Size: 0x1, Type: BoolProperty)
    bool bCanPurchaseSubscription; // 0x72 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_73[0x5]; // 0x73 (Size: 0x5, Type: PaddingProperty)
    FDateTime SubscriptionStartDate; // 0x78 (Size: 0x8, Type: StructProperty)
    TArray<EAppStore> SubscriptionPlatforms; // 0x80 (Size: 0x10, Type: ArrayProperty)
    int32_t NumAutoRenewSubscriptions; // 0x90 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
    FText Title; // 0x98 (Size: 0x10, Type: TextProperty)
    FText Description; // 0xa8 (Size: 0x10, Type: TextProperty)
    FText ShortDescription; // 0xb8 (Size: 0x10, Type: TextProperty)
    FString BackgroundURL; // 0xc8 (Size: 0x10, Type: StrProperty)
    FString SubscribedBackgroundURL; // 0xd8 (Size: 0x10, Type: StrProperty)
    FString OverrideUpsellPass; // 0xe8 (Size: 0x10, Type: StrProperty)
    bool bCrewOnRightInUpsell; // 0xf8 (Size: 0x1, Type: BoolProperty)
    bool bCrew50PercentInUpsell; // 0xf9 (Size: 0x1, Type: BoolProperty)
    bool bCrewOnlyInUpsell; // 0xfa (Size: 0x1, Type: BoolProperty)
    bool bPassOnlyInUpsell; // 0xfb (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_fc[0x4]; // 0xfc (Size: 0x4, Type: PaddingProperty)
    FCrewUpsellConfig CMSUpsellConfig; // 0x100 (Size: 0x18, Type: StructProperty)
    FCrewUpsellConfig ExperimentUpsellConfig; // 0x118 (Size: 0x18, Type: StructProperty)
    FText Disclaimer; // 0x130 (Size: 0x10, Type: TextProperty)
    FText SubscriptionButtonText; // 0x140 (Size: 0x10, Type: TextProperty)
    FText PriceText; // 0x150 (Size: 0x10, Type: TextProperty)
    FText UserInformationTextPrimary; // 0x160 (Size: 0x10, Type: TextProperty)
    FText UserInformationTextSecondary; // 0x170 (Size: 0x10, Type: TextProperty)
    FText PaymentLegalText; // 0x180 (Size: 0x10, Type: TextProperty)
    TArray<FText> ProgressiveInfoInfoModalEntries; // 0x190 (Size: 0x10, Type: ArrayProperty)
    FText ProgressiveInfoNewStagesUnlockFinePrint; // 0x1a0 (Size: 0x10, Type: TextProperty)
    TArray<FText> TemporaryItemsInfoModalEntries; // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFortItemVM*> CrewPackItems; // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    UCrewCancellationInfoVM* CancellationInfo; // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    UCrewItemShopDataVM* SubscriptionShopData; // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    UCrewItemShopDataVM* CrewShopData; // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    TArray<UCrewBenefitVM*> RecurringBenefits; // 0x1e8 (Size: 0x10, Type: ArrayProperty)
    TArray<UCrewBenefitVM*> LimitedTimeBenefits; // 0x1f8 (Size: 0x10, Type: ArrayProperty)
    TArray<UCrewSubscriptionModalInfoVM*> SubscriptionModals; // 0x208 (Size: 0x10, Type: ArrayProperty)
    UCrewBenefitVM* PreviewBenefit; // 0x218 (Size: 0x8, Type: ObjectProperty)

public:
    EAppStore ActiveSubscriptionPlatform() const; // 0x110caeb0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool CanCancelSubscriptionDirectly() const; // 0x110caed4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetEarliestAutoRenewEndDate() const; // 0x110cb678 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ESubscriptionCancellability GetSubscriptionCancellabillity() const; // 0x110cbb28 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetSubscriptionEndDate() const; // 0x50ad070 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetSubscriptionError() const; // 0x110cbb4c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetSubscriptionNextBillingDateAsText() const; // 0x110cbb88 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasMultipleSubscriptions() const; // 0x110cbe84 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsOnActiveSubscriptionPlatform() const; // 0x110cbea0 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSubscribed() const; // 0x5fd4ca8 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    UCrewSubscriptionModalInfoVM* GetModalViewModelById(FString& ModalId); // 0x110cb780 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
    void SendSubscriptionAnalyticsEvent(FString& ContextName, FString& Interaction); // 0x110cc958 (Index: 0xb, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UCrewVM) == 0x220, "Size mismatch for UCrewVM");
static_assert(offsetof(UCrewVM, SubscriptionState) == 0x70, "Offset mismatch for UCrewVM::SubscriptionState");
static_assert(offsetof(UCrewVM, bIsLegacySubscription) == 0x71, "Offset mismatch for UCrewVM::bIsLegacySubscription");
static_assert(offsetof(UCrewVM, bCanPurchaseSubscription) == 0x72, "Offset mismatch for UCrewVM::bCanPurchaseSubscription");
static_assert(offsetof(UCrewVM, SubscriptionStartDate) == 0x78, "Offset mismatch for UCrewVM::SubscriptionStartDate");
static_assert(offsetof(UCrewVM, SubscriptionPlatforms) == 0x80, "Offset mismatch for UCrewVM::SubscriptionPlatforms");
static_assert(offsetof(UCrewVM, NumAutoRenewSubscriptions) == 0x90, "Offset mismatch for UCrewVM::NumAutoRenewSubscriptions");
static_assert(offsetof(UCrewVM, Title) == 0x98, "Offset mismatch for UCrewVM::Title");
static_assert(offsetof(UCrewVM, Description) == 0xa8, "Offset mismatch for UCrewVM::Description");
static_assert(offsetof(UCrewVM, ShortDescription) == 0xb8, "Offset mismatch for UCrewVM::ShortDescription");
static_assert(offsetof(UCrewVM, BackgroundURL) == 0xc8, "Offset mismatch for UCrewVM::BackgroundURL");
static_assert(offsetof(UCrewVM, SubscribedBackgroundURL) == 0xd8, "Offset mismatch for UCrewVM::SubscribedBackgroundURL");
static_assert(offsetof(UCrewVM, OverrideUpsellPass) == 0xe8, "Offset mismatch for UCrewVM::OverrideUpsellPass");
static_assert(offsetof(UCrewVM, bCrewOnRightInUpsell) == 0xf8, "Offset mismatch for UCrewVM::bCrewOnRightInUpsell");
static_assert(offsetof(UCrewVM, bCrew50PercentInUpsell) == 0xf9, "Offset mismatch for UCrewVM::bCrew50PercentInUpsell");
static_assert(offsetof(UCrewVM, bCrewOnlyInUpsell) == 0xfa, "Offset mismatch for UCrewVM::bCrewOnlyInUpsell");
static_assert(offsetof(UCrewVM, bPassOnlyInUpsell) == 0xfb, "Offset mismatch for UCrewVM::bPassOnlyInUpsell");
static_assert(offsetof(UCrewVM, CMSUpsellConfig) == 0x100, "Offset mismatch for UCrewVM::CMSUpsellConfig");
static_assert(offsetof(UCrewVM, ExperimentUpsellConfig) == 0x118, "Offset mismatch for UCrewVM::ExperimentUpsellConfig");
static_assert(offsetof(UCrewVM, Disclaimer) == 0x130, "Offset mismatch for UCrewVM::Disclaimer");
static_assert(offsetof(UCrewVM, SubscriptionButtonText) == 0x140, "Offset mismatch for UCrewVM::SubscriptionButtonText");
static_assert(offsetof(UCrewVM, PriceText) == 0x150, "Offset mismatch for UCrewVM::PriceText");
static_assert(offsetof(UCrewVM, UserInformationTextPrimary) == 0x160, "Offset mismatch for UCrewVM::UserInformationTextPrimary");
static_assert(offsetof(UCrewVM, UserInformationTextSecondary) == 0x170, "Offset mismatch for UCrewVM::UserInformationTextSecondary");
static_assert(offsetof(UCrewVM, PaymentLegalText) == 0x180, "Offset mismatch for UCrewVM::PaymentLegalText");
static_assert(offsetof(UCrewVM, ProgressiveInfoInfoModalEntries) == 0x190, "Offset mismatch for UCrewVM::ProgressiveInfoInfoModalEntries");
static_assert(offsetof(UCrewVM, ProgressiveInfoNewStagesUnlockFinePrint) == 0x1a0, "Offset mismatch for UCrewVM::ProgressiveInfoNewStagesUnlockFinePrint");
static_assert(offsetof(UCrewVM, TemporaryItemsInfoModalEntries) == 0x1b0, "Offset mismatch for UCrewVM::TemporaryItemsInfoModalEntries");
static_assert(offsetof(UCrewVM, CrewPackItems) == 0x1c0, "Offset mismatch for UCrewVM::CrewPackItems");
static_assert(offsetof(UCrewVM, CancellationInfo) == 0x1d0, "Offset mismatch for UCrewVM::CancellationInfo");
static_assert(offsetof(UCrewVM, SubscriptionShopData) == 0x1d8, "Offset mismatch for UCrewVM::SubscriptionShopData");
static_assert(offsetof(UCrewVM, CrewShopData) == 0x1e0, "Offset mismatch for UCrewVM::CrewShopData");
static_assert(offsetof(UCrewVM, RecurringBenefits) == 0x1e8, "Offset mismatch for UCrewVM::RecurringBenefits");
static_assert(offsetof(UCrewVM, LimitedTimeBenefits) == 0x1f8, "Offset mismatch for UCrewVM::LimitedTimeBenefits");
static_assert(offsetof(UCrewVM, SubscriptionModals) == 0x208, "Offset mismatch for UCrewVM::SubscriptionModals");
static_assert(offsetof(UCrewVM, PreviewBenefit) == 0x218, "Offset mismatch for UCrewVM::PreviewBenefit");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCrewUpsellConfig
{
    FString OverrideUpsellPass; // 0x0 (Size: 0x10, Type: StrProperty)
    bool bCrewOnRightInUpsell; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bCrew50PercentInUpsell; // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bCrew30PercentInUpsell; // 0x12 (Size: 0x1, Type: BoolProperty)
    bool bCrewAsSliver; // 0x13 (Size: 0x1, Type: BoolProperty)
    bool bCrewOnlyInUpsell; // 0x14 (Size: 0x1, Type: BoolProperty)
    bool bPassOnlyInUpsell; // 0x15 (Size: 0x1, Type: BoolProperty)
    bool bAnimateCrewBG; // 0x16 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_17[0x1]; // 0x17 (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(FCrewUpsellConfig) == 0x18, "Size mismatch for FCrewUpsellConfig");
static_assert(offsetof(FCrewUpsellConfig, OverrideUpsellPass) == 0x0, "Offset mismatch for FCrewUpsellConfig::OverrideUpsellPass");
static_assert(offsetof(FCrewUpsellConfig, bCrewOnRightInUpsell) == 0x10, "Offset mismatch for FCrewUpsellConfig::bCrewOnRightInUpsell");
static_assert(offsetof(FCrewUpsellConfig, bCrew50PercentInUpsell) == 0x11, "Offset mismatch for FCrewUpsellConfig::bCrew50PercentInUpsell");
static_assert(offsetof(FCrewUpsellConfig, bCrew30PercentInUpsell) == 0x12, "Offset mismatch for FCrewUpsellConfig::bCrew30PercentInUpsell");
static_assert(offsetof(FCrewUpsellConfig, bCrewAsSliver) == 0x13, "Offset mismatch for FCrewUpsellConfig::bCrewAsSliver");
static_assert(offsetof(FCrewUpsellConfig, bCrewOnlyInUpsell) == 0x14, "Offset mismatch for FCrewUpsellConfig::bCrewOnlyInUpsell");
static_assert(offsetof(FCrewUpsellConfig, bPassOnlyInUpsell) == 0x15, "Offset mismatch for FCrewUpsellConfig::bPassOnlyInUpsell");
static_assert(offsetof(FCrewUpsellConfig, bAnimateCrewBG) == 0x16, "Offset mismatch for FCrewUpsellConfig::bAnimateCrewBG");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCrewSubscriptionContentTabData
{
    FText TabName; // 0x0 (Size: 0x10, Type: TextProperty)
    uint8_t TabType; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FCrewSubscriptionContentTabData) == 0x18, "Size mismatch for FCrewSubscriptionContentTabData");
static_assert(offsetof(FCrewSubscriptionContentTabData, TabName) == 0x0, "Offset mismatch for FCrewSubscriptionContentTabData::TabName");
static_assert(offsetof(FCrewSubscriptionContentTabData, TabType) == 0x10, "Offset mismatch for FCrewSubscriptionContentTabData::TabType");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FFortProgressiveReward
{
    TSoftObjectPtr<UMaterialInterface*> TileMaterial; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    bool bHidden; // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bAllowPreviewStyles; // 0x21 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_22[0x6]; // 0x22 (Size: 0x6, Type: PaddingProperty)
    TSoftObjectPtr<UFortItemDefinition*> RewardDef; // 0x28 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FFortProgressiveReward) == 0x48, "Size mismatch for FFortProgressiveReward");
static_assert(offsetof(FFortProgressiveReward, TileMaterial) == 0x0, "Offset mismatch for FFortProgressiveReward::TileMaterial");
static_assert(offsetof(FFortProgressiveReward, bHidden) == 0x20, "Offset mismatch for FFortProgressiveReward::bHidden");
static_assert(offsetof(FFortProgressiveReward, bAllowPreviewStyles) == 0x21, "Offset mismatch for FFortProgressiveReward::bAllowPreviewStyles");
static_assert(offsetof(FFortProgressiveReward, RewardDef) == 0x28, "Offset mismatch for FFortProgressiveReward::RewardDef");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FFortProgressiveStageOverrideDisplayData
{
    TArray<FCosmeticVariantInfo> DefaultVariantPreviewOverrides; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FText DisplayName; // 0x10 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UMaterialInterface*> TileMaterial; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    bool bAllowPreviewStyles; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortProgressiveStageOverrideDisplayData) == 0x48, "Size mismatch for FFortProgressiveStageOverrideDisplayData");
static_assert(offsetof(FFortProgressiveStageOverrideDisplayData, DefaultVariantPreviewOverrides) == 0x0, "Offset mismatch for FFortProgressiveStageOverrideDisplayData::DefaultVariantPreviewOverrides");
static_assert(offsetof(FFortProgressiveStageOverrideDisplayData, DisplayName) == 0x10, "Offset mismatch for FFortProgressiveStageOverrideDisplayData::DisplayName");
static_assert(offsetof(FFortProgressiveStageOverrideDisplayData, TileMaterial) == 0x20, "Offset mismatch for FFortProgressiveStageOverrideDisplayData::TileMaterial");
static_assert(offsetof(FFortProgressiveStageOverrideDisplayData, bAllowPreviewStyles) == 0x40, "Offset mismatch for FFortProgressiveStageOverrideDisplayData::bAllowPreviewStyles");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FFortProgressiveUIStage
{
    TArray<FFortProgressiveReward> Rewards; // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bUseOverrideDisplayData; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FFortProgressiveStageOverrideDisplayData OverrideDisplayData; // 0x18 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FFortProgressiveUIStage) == 0x60, "Size mismatch for FFortProgressiveUIStage");
static_assert(offsetof(FFortProgressiveUIStage, Rewards) == 0x0, "Offset mismatch for FFortProgressiveUIStage::Rewards");
static_assert(offsetof(FFortProgressiveUIStage, bUseOverrideDisplayData) == 0x10, "Offset mismatch for FFortProgressiveUIStage::bUseOverrideDisplayData");
static_assert(offsetof(FFortProgressiveUIStage, OverrideDisplayData) == 0x18, "Offset mismatch for FFortProgressiveUIStage::OverrideDisplayData");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FFortProgressiveSet
{
    FString FulfillmentId; // 0x0 (Size: 0x10, Type: StrProperty)
    FText SetName; // 0x10 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UMaterialInterface*> TileMaterial; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FFortProgressiveUIStage> Stages; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortProgressiveSet) == 0x50, "Size mismatch for FFortProgressiveSet");
static_assert(offsetof(FFortProgressiveSet, FulfillmentId) == 0x0, "Offset mismatch for FFortProgressiveSet::FulfillmentId");
static_assert(offsetof(FFortProgressiveSet, SetName) == 0x10, "Offset mismatch for FFortProgressiveSet::SetName");
static_assert(offsetof(FFortProgressiveSet, TileMaterial) == 0x20, "Offset mismatch for FFortProgressiveSet::TileMaterial");
static_assert(offsetof(FFortProgressiveSet, Stages) == 0x40, "Offset mismatch for FFortProgressiveSet::Stages");

