/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticsFrameworkItems
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "GameplayTags.h"
#include "CoreUObject.h"

// Size: 0x108 (Inherited: 0xe0, Single: 0x28)
class UCosmeticDataComponent : public UActorComponent
{
public:
    TMap<FInstancedStructContainer, FGameplayTag> PropertyContainers; // 0xb8 (Size: 0x50, Type: MapProperty)

public:
    bool BP_AddOrOverrideProperty(FGameplayTag& SlotTag, const FCosmeticPropertyBase Property); // 0xb24cd38 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool BP_FindProperty(FGameplayTag& SlotTag, FGameplayTag& PropertyTag, FCosmeticPropertyBase& OutProperty); // 0xb24cee0 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void ResetProperties(); // 0xb24d114 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCosmeticDataComponent) == 0x108, "Size mismatch for UCosmeticDataComponent");
static_assert(offsetof(UCosmeticDataComponent, PropertyContainers) == 0xb8, "Offset mismatch for UCosmeticDataComponent::PropertyContainers");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCosmeticPropertyBase
{
    FGameplayTag PropertyTag; // 0x0 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FCosmeticPropertyBase) == 0x4, "Size mismatch for FCosmeticPropertyBase");
static_assert(offsetof(FCosmeticPropertyBase, PropertyTag) == 0x0, "Offset mismatch for FCosmeticPropertyBase::PropertyTag");

// Size: 0x20 (Inherited: 0x4, Single: 0x1c)
struct FCosmeticProperty_Vector : FCosmeticPropertyBase
{
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector Value; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FCosmeticProperty_Vector) == 0x20, "Size mismatch for FCosmeticProperty_Vector");
static_assert(offsetof(FCosmeticProperty_Vector, Value) == 0x8, "Offset mismatch for FCosmeticProperty_Vector::Value");

// Size: 0x18 (Inherited: 0x4, Single: 0x14)
struct FCosmeticProperty_TableRow : FCosmeticPropertyBase
{
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FDataTableRowHandle TableRow; // 0x8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FCosmeticProperty_TableRow) == 0x18, "Size mismatch for FCosmeticProperty_TableRow");
static_assert(offsetof(FCosmeticProperty_TableRow, TableRow) == 0x8, "Offset mismatch for FCosmeticProperty_TableRow::TableRow");

// Size: 0x8 (Inherited: 0x4, Single: 0x4)
struct FCosmeticProperty_GameplayTag : FCosmeticPropertyBase
{
    FGameplayTag GameplayTag; // 0x4 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FCosmeticProperty_GameplayTag) == 0x8, "Size mismatch for FCosmeticProperty_GameplayTag");
static_assert(offsetof(FCosmeticProperty_GameplayTag, GameplayTag) == 0x4, "Offset mismatch for FCosmeticProperty_GameplayTag::GameplayTag");

