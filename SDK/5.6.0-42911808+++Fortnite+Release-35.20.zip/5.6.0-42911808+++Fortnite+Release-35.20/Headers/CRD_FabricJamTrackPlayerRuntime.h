/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_FabricJamTrackPlayerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "PlayspaceSystem.h"
#include "SparksSongSetlistRuntime.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "SparksSongPlayerRuntime.h"
#include "ModularGameplay.h"
#include "FabricRuntime.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "FabricFramework.h"
#include "FMDeviceCablesRuntime.h"
#include "HarmonixMetasound.h"
#include "SparksMidiParser.h"
#include "MetasoundEngine.h"

// Size: 0x1c0 (Inherited: 0x250, Single: 0xffffff70)
class UFabricJamTrackPlayerAnalyticsComponent : public UPlayspaceComponent
{
public:
    UClass* SongPlayCoordinatorClass; // 0xb8 (Size: 0x8, Type: ClassProperty)
    UClass* PlayspaceComponentClass; // 0xc0 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_c8[0xf8]; // 0xc8 (Size: 0xf8, Type: PaddingProperty)

public:
    void OnRegisteredPlayersChanged(); // 0x11e35b74 (Index: 0x0, Flags: Final|Native|Public)
    void OnSelectionControlChanged(); // 0x11e35d44 (Index: 0x1, Flags: Final|Native|Public)
    void RegisterFabricAnalyticsProvider(TScriptInterface<Class>& InAnalyticsProvider); // 0x11e365c4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void ServerLoginPlayer(AFortPlayerControllerAthena*& PlayerController); // 0x11e36b20 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void ServerLogoutPlayer(AFortPlayerControllerAthena*& PlayerController); // 0x11e36c4c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void ServerPlayerAudible(AFortPlayerControllerAthena*& PlayerController); // 0x11e36d78 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void ServerPlayerInaudible(AFortPlayerControllerAthena*& PlayerController); // 0x11e36ea4 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void ServerPlayerRegistered(AFortPlayerControllerAthena*& PlayerController); // 0x11e36fd0 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void ServerPlayerRegistrationRequirementChanged(bool& bPlayerRegistrationRequired); // 0x11e37344 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void ServerPlayerUnregistered(AFortPlayerControllerAthena*& PlayerController); // 0x11e37470 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void ServerSongEnded(AController*& const Instigator); // 0x11e379ec (Index: 0xa, Flags: Final|Native|Public)
    void ServerSongRestarted(AController*& const Instigator); // 0x11e37b18 (Index: 0xb, Flags: Final|Native|Public)
    void ServerSongStarted(AController*& const Instigator); // 0x11e37c44 (Index: 0xc, Flags: Final|Native|Public)
    void ServerSongStopped(AController*& const Instigator); // 0x11e37d70 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    void UnregisterFabricAnalyticsProvider(); // 0x11e3813c (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricJamTrackPlayerAnalyticsComponent) == 0x1c0, "Size mismatch for UFabricJamTrackPlayerAnalyticsComponent");
static_assert(offsetof(UFabricJamTrackPlayerAnalyticsComponent, SongPlayCoordinatorClass) == 0xb8, "Offset mismatch for UFabricJamTrackPlayerAnalyticsComponent::SongPlayCoordinatorClass");
static_assert(offsetof(UFabricJamTrackPlayerAnalyticsComponent, PlayspaceComponentClass) == 0xc0, "Offset mismatch for UFabricJamTrackPlayerAnalyticsComponent::PlayspaceComponentClass");

// Size: 0x1d8 (Inherited: 0x330, Single: 0xfffffea8)
class UFabricJamTrackPlayerCustomSetlist : public USparksCustomSetlist
{
public:
    uint8_t OnSetlistLengthChanged[0x10]; // 0xe0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSongsPerPlayerChanged[0x10]; // 0xf0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t SetlistDismissed[0x10]; // 0x100 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UClass* JTPPlayspaceComponentClass; // 0x110 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_118[0xb0]; // 0x118 (Size: 0xb0, Type: PaddingProperty)
    uint8_t SongsPerPlayer; // 0x1c8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1c9[0x3]; // 0x1c9 (Size: 0x3, Type: PaddingProperty)
    int32_t SetlistLength; // 0x1cc (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1d0[0x8]; // 0x1d0 (Size: 0x8, Type: PaddingProperty)

public:
    void AddSetlistEditor(APlayerController*& Editor); // 0x11e34f08 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void AddSetlistSelector(APlayerController*& Editor); // 0x11e35034 (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    int32_t GetSetlistLength() const; // 0xed0d214 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFabricJamTrackPlayerSongsPerPlayerRule GetSongsPerPlayerRule() const; // 0xf19b3e4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSongAvailable(FName& SongShortname) const; // 0x11e35844 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RemoveSetlistEditor(APlayerController*& Editor); // 0x11e368b4 (Index: 0xa, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void RemoveSetlistSelector(APlayerController*& Editor); // 0x11e369e0 (Index: 0xb, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void ServerSetSetlistLength(int32_t& const InSetlistLength); // 0x11e377e4 (Index: 0xc, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void ServerSetSongsPerPlayerRule(const EFabricJamTrackPlayerSongsPerPlayerRule SongsPerPlayerRule); // 0x11e3790c (Index: 0xd, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)
    void ServerShuffleSetlist(); // 0x11e379d8 (Index: 0xe, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetlistDismissed__DelegateSignature(AController*& const Instigator); // 0x288a61c (Index: 0xf, Flags: MulticastDelegate|Public|Delegate)
    void SetlistLengthChanged__DelegateSignature(int32_t& const NewSetlistLength); // 0x288a61c (Index: 0x10, Flags: MulticastDelegate|Public|Delegate)
    void SongsPerPlayerChanged__DelegateSignature(EFabricJamTrackPlayerSongsPerPlayerRule& const NewSongsPerPlayer); // 0x288a61c (Index: 0x11, Flags: MulticastDelegate|Public|Delegate)

protected:
    virtual void MulticastSetlistEditorsChanged(bool& bHasEditors); // 0xf777010 (Index: 0x5, Flags: Net|NetReliableNative|Event|NetMulticast|Protected)
    void OnAvailableSongsChanged(); // 0x554e3c4 (Index: 0x6, Flags: Final|Native|Protected)
    void OnRep_SetlistLength(); // 0x11e35d08 (Index: 0x7, Flags: Final|Native|Protected)
    void OnRep_SongsPerPlayer(); // 0x11e35d30 (Index: 0x8, Flags: Final|Native|Protected)
    void OnSelectorsChanged(); // 0x11e35e98 (Index: 0x9, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFabricJamTrackPlayerCustomSetlist) == 0x1d8, "Size mismatch for UFabricJamTrackPlayerCustomSetlist");
static_assert(offsetof(UFabricJamTrackPlayerCustomSetlist, OnSetlistLengthChanged) == 0xe0, "Offset mismatch for UFabricJamTrackPlayerCustomSetlist::OnSetlistLengthChanged");
static_assert(offsetof(UFabricJamTrackPlayerCustomSetlist, OnSongsPerPlayerChanged) == 0xf0, "Offset mismatch for UFabricJamTrackPlayerCustomSetlist::OnSongsPerPlayerChanged");
static_assert(offsetof(UFabricJamTrackPlayerCustomSetlist, SetlistDismissed) == 0x100, "Offset mismatch for UFabricJamTrackPlayerCustomSetlist::SetlistDismissed");
static_assert(offsetof(UFabricJamTrackPlayerCustomSetlist, JTPPlayspaceComponentClass) == 0x110, "Offset mismatch for UFabricJamTrackPlayerCustomSetlist::JTPPlayspaceComponentClass");
static_assert(offsetof(UFabricJamTrackPlayerCustomSetlist, SongsPerPlayer) == 0x1c8, "Offset mismatch for UFabricJamTrackPlayerCustomSetlist::SongsPerPlayer");
static_assert(offsetof(UFabricJamTrackPlayerCustomSetlist, SetlistLength) == 0x1cc, "Offset mismatch for UFabricJamTrackPlayerCustomSetlist::SetlistLength");

// Size: 0x1d8 (Inherited: 0xe0, Single: 0xf8)
class UFabricJamTrackPlayerDeviceComponent : public UActorComponent
{
public:
    FGameplayTag PlayspaceTag; // 0xb8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
    UClass* PlayspaceComponentClass; // 0xc0 (Size: 0x8, Type: ClassProperty)
    UClass* PlayCoordinatorClass; // 0xc8 (Size: 0x8, Type: ClassProperty)
    UClass* SetlistClass; // 0xd0 (Size: 0x8, Type: ClassProperty)
    FName SelectionControlPropertyName; // 0xd8 (Size: 0x4, Type: NameProperty)
    FName SetlistLengthPropertyName; // 0xdc (Size: 0x4, Type: NameProperty)
    FName SelectionLimitPropertyName; // 0xe0 (Size: 0x4, Type: NameProperty)
    FName PlaybackBehaviorPropertyName; // 0xe4 (Size: 0x4, Type: NameProperty)
    FName CountInAudioPropertyName; // 0xe8 (Size: 0x4, Type: NameProperty)
    FName VocalsGainInputName; // 0xec (Size: 0x4, Type: NameProperty)
    FName MuteInputName; // 0xf0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_f4[0x4]; // 0xf4 (Size: 0x4, Type: PaddingProperty)
    FText FirstJTPDialogHeader; // 0xf8 (Size: 0x10, Type: TextProperty)
    FText FirstJTPDialogMessage; // 0x108 (Size: 0x10, Type: TextProperty)
    uint8_t OnJamTrackStartedPlaying[0x10]; // 0x118 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFirstJTPDialogSeen[0x10]; // 0x128 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_138[0x70]; // 0x138 (Size: 0x70, Type: PaddingProperty)
    TWeakObjectPtr<UPlayspaceComponent_FabricJamTrackPlayer*> PlayspaceComponent; // 0x1a8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricJamTrackPlayerSongPlayCoordinator*> PlayCoordinator; // 0x1b0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricJamTrackPlayerCustomSetlist*> Setlist; // 0x1b8 (Size: 0x8, Type: WeakObjectProperty)
    TArray<UFMDeviceCablePortComponent*> OutputPorts; // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    bool bHasShownInitialDialog; // 0x1d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d1[0x7]; // 0x1d1 (Size: 0x7, Type: PaddingProperty)

public:
    void AllPlayersUnregisteredByDevice(); // 0x11e35160 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool AreAllLocalPlayersRegistered() const; // 0x11e3519c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UActorComponent* FindOrAddPlayspaceComponent(UClass*& ComponentClass); // 0x11e351d4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    UActorComponent* FindPlayspaceComponent(UClass*& ComponentClass); // 0x11e354b8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    UFabricJamTrackPlayerSongPlayCoordinator* GetPlayCoordinator(); // 0x11e3579c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    APlayspace* GetPlayspace(); // 0x11e357c0 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    UPlayspaceComponent_FabricJamTrackPlayer* GetPlayspaceComponent(); // 0x11e357e4 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    UFabricJamTrackPlayerCustomSetlist* GetSetlist(); // 0x11e35808 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void PlayerRegisteredByDevice(AController*& Instigator); // 0x11e36114 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    void PlayerUnregisteredByDevice(AController*& Instigator); // 0x11e3636c (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnAnyOptionUpdated(); // 0x11e35a20 (Index: 0x9, Flags: Final|Native|Private)
    void OnGlobalRegisteredPlayersChanged(); // 0x11e35a34 (Index: 0xa, Flags: Final|Native|Private)
    void OnPlaybackBehaviorChanged(EFabricJamTrackPlayerPlaybackBehavior& const NewPlaybackBehavior); // 0x11e35a48 (Index: 0xb, Flags: Final|Native|Private)
    void OnRegisteredPlayersChangedPostReplication(); // 0x11e35b88 (Index: 0xc, Flags: Final|Native|Private)
    void OnSelectionControlChanged(); // 0x11e35d58 (Index: 0x10, Flags: Final|Native|Private)
    void OnSelectionLimitChanged(EFabricJamTrackPlayerSongsPerPlayerRule& const NewSelectionLimit); // 0x11e35d6c (Index: 0x11, Flags: Final|Native|Private)
    void OnSetlistLengthChanged(int32_t& const NewSetlistLength); // 0x11e35eac (Index: 0x12, Flags: Final|Native|Private)
    void OnShouldSkipCountinChanged(bool& const NewSkipCountin); // 0x11e35fd4 (Index: 0x13, Flags: Final|Native|Private)
    void OnSongStartedPlaying(); // 0x11e36100 (Index: 0x14, Flags: Final|Native|Private)

protected:
    bool GetHasShownInitialDialog() const; // 0xa287c60 (Index: 0x4, Flags: Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void OnRep_PlayCoordinator(TWeakObjectPtr<UFabricJamTrackPlayerSongPlayCoordinator*>& OldPlayCoordinator); // 0x11e35b9c (Index: 0xd, Flags: Final|Native|Protected)
    void OnRep_PlayspaceComponent(TWeakObjectPtr<UPlayspaceComponent_FabricJamTrackPlayer*>& OldPlayspaceComponent); // 0x11e35c60 (Index: 0xe, Flags: Final|Native|Protected)
    void OnRep_Setlist(TWeakObjectPtr<UFabricJamTrackPlayerCustomSetlist*>& OldSetlist); // 0x11e35c60 (Index: 0xf, Flags: Final|Native|Protected)
    void SetHasShownInitialDialog(bool& bInHasShownInitialDialog); // 0xd7b02fc (Index: 0x17, Flags: Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFabricJamTrackPlayerDeviceComponent) == 0x1d8, "Size mismatch for UFabricJamTrackPlayerDeviceComponent");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, PlayspaceTag) == 0xb8, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::PlayspaceTag");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, PlayspaceComponentClass) == 0xc0, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::PlayspaceComponentClass");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, PlayCoordinatorClass) == 0xc8, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::PlayCoordinatorClass");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, SetlistClass) == 0xd0, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::SetlistClass");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, SelectionControlPropertyName) == 0xd8, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::SelectionControlPropertyName");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, SetlistLengthPropertyName) == 0xdc, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::SetlistLengthPropertyName");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, SelectionLimitPropertyName) == 0xe0, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::SelectionLimitPropertyName");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, PlaybackBehaviorPropertyName) == 0xe4, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::PlaybackBehaviorPropertyName");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, CountInAudioPropertyName) == 0xe8, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::CountInAudioPropertyName");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, VocalsGainInputName) == 0xec, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::VocalsGainInputName");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, MuteInputName) == 0xf0, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::MuteInputName");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, FirstJTPDialogHeader) == 0xf8, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::FirstJTPDialogHeader");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, FirstJTPDialogMessage) == 0x108, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::FirstJTPDialogMessage");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, OnJamTrackStartedPlaying) == 0x118, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::OnJamTrackStartedPlaying");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, OnFirstJTPDialogSeen) == 0x128, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::OnFirstJTPDialogSeen");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, PlayspaceComponent) == 0x1a8, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::PlayspaceComponent");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, PlayCoordinator) == 0x1b0, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::PlayCoordinator");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, Setlist) == 0x1b8, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::Setlist");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, OutputPorts) == 0x1c0, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::OutputPorts");
static_assert(offsetof(UFabricJamTrackPlayerDeviceComponent, bHasShownInitialDialog) == 0x1d0, "Offset mismatch for UFabricJamTrackPlayerDeviceComponent::bHasShownInitialDialog");

// Size: 0xb8 (Inherited: 0xe0, Single: 0xffffffd8)
class UFabricJamTrackPlayerInteractionComponent : public UActorComponent
{
public:
};

static_assert(sizeof(UFabricJamTrackPlayerInteractionComponent) == 0xb8, "Size mismatch for UFabricJamTrackPlayerInteractionComponent");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UFabricJamTrackPlayerMidiEventDriver : public UObject
{
public:
    uint8_t Pad_28[0x10]; // 0x28 (Size: 0x10, Type: PaddingProperty)
    UParsedMidiEventData* ParsedMidiEventData; // 0x38 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_40[0x8]; // 0x40 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFabricJamTrackPlayerMidiEventDriver) == 0x48, "Size mismatch for UFabricJamTrackPlayerMidiEventDriver");
static_assert(offsetof(UFabricJamTrackPlayerMidiEventDriver, ParsedMidiEventData) == 0x38, "Offset mismatch for UFabricJamTrackPlayerMidiEventDriver::ParsedMidiEventData");

// Size: 0x280 (Inherited: 0x2e8, Single: 0xffffff98)
class UFabricJamTrackPlayerSongPlayCoordinator : public USparksSongPlayerPlayCoordinator
{
public:
    uint8_t Pad_150[0x50]; // 0x150 (Size: 0x50, Type: PaddingProperty)
    FFabricJamTrackPlayerSong SongToPlay; // 0x1a0 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1ac[0x4]; // 0x1ac (Size: 0x4, Type: PaddingProperty)
    UClass* UtilityProviderPatchClass; // 0x1b0 (Size: 0x8, Type: ClassProperty)
    UFabricJamTrackPlayerUtilityProviderPatchWrapper* UtilityProviderPatchInstance; // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    float DelayBeforeForcePreloadInSeconds; // 0x1c0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c4[0x54]; // 0x1c4 (Size: 0x54, Type: PaddingProperty)
    TSet<FUniqueNetIdRepl> PlayersLoadingSong; // 0x218 (Size: 0x50, Type: SetProperty)
    uint8_t Pad_268[0x8]; // 0x268 (Size: 0x8, Type: PaddingProperty)
    bool bShouldSkipCountIn; // 0x270 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_271[0xf]; // 0x271 (Size: 0xf, Type: PaddingProperty)

public:
    bool DidRestartSong() const; // 0x113e064c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetShouldSkipCountIn() const; // 0x11e3582c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void PlayServerAuthoritativeSongFromShortname(const FName ShortName); // 0xeb6e8dc (Index: 0x4, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)
    void ResetServerAuthoritativeSong(); // 0x11e36b0c (Index: 0x5, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetShouldSkipCountIn(bool& const bInSkipCountin); // 0x11e37fc8 (Index: 0x7, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    bool ShouldMuteAllAudioForCurrentSong() const; // 0x11e380f4 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ShouldMuteVocalsForCurrentSong() const; // 0x11e38118 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SkipCountinChanged__DelegateSignature(bool& const NewSkipCountin); // 0x288a61c (Index: 0xa, Flags: MulticastDelegate|Public|Delegate)

protected:
    void ClientPlaySong(); // 0x11e351c0 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable)
    void OnRep_SongToPlay(); // 0x11e35d1c (Index: 0x3, Flags: Final|Native|Protected)
    void SetFabricZoneSystem(AFabricZoneSystem*& System); // 0x11e37e9c (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFabricJamTrackPlayerSongPlayCoordinator) == 0x280, "Size mismatch for UFabricJamTrackPlayerSongPlayCoordinator");
static_assert(offsetof(UFabricJamTrackPlayerSongPlayCoordinator, SongToPlay) == 0x1a0, "Offset mismatch for UFabricJamTrackPlayerSongPlayCoordinator::SongToPlay");
static_assert(offsetof(UFabricJamTrackPlayerSongPlayCoordinator, UtilityProviderPatchClass) == 0x1b0, "Offset mismatch for UFabricJamTrackPlayerSongPlayCoordinator::UtilityProviderPatchClass");
static_assert(offsetof(UFabricJamTrackPlayerSongPlayCoordinator, UtilityProviderPatchInstance) == 0x1b8, "Offset mismatch for UFabricJamTrackPlayerSongPlayCoordinator::UtilityProviderPatchInstance");
static_assert(offsetof(UFabricJamTrackPlayerSongPlayCoordinator, DelayBeforeForcePreloadInSeconds) == 0x1c0, "Offset mismatch for UFabricJamTrackPlayerSongPlayCoordinator::DelayBeforeForcePreloadInSeconds");
static_assert(offsetof(UFabricJamTrackPlayerSongPlayCoordinator, PlayersLoadingSong) == 0x218, "Offset mismatch for UFabricJamTrackPlayerSongPlayCoordinator::PlayersLoadingSong");
static_assert(offsetof(UFabricJamTrackPlayerSongPlayCoordinator, bShouldSkipCountIn) == 0x270, "Offset mismatch for UFabricJamTrackPlayerSongPlayCoordinator::bShouldSkipCountIn");

// Size: 0xc0 (Inherited: 0x308, Single: 0xfffffdb8)
class UFabricJamTrackPlayerSongPreloadController : public USparksSongPlayerPreloadControllerComponent
{
public:
};

static_assert(sizeof(UFabricJamTrackPlayerSongPreloadController) == 0xc0, "Size mismatch for UFabricJamTrackPlayerSongPreloadController");

// Size: 0xc0 (Inherited: 0xe0, Single: 0xffffffe0)
class UFabricJamTrackPlayerTimelineSyncComponent : public UActorComponent
{
public:
};

static_assert(sizeof(UFabricJamTrackPlayerTimelineSyncComponent) == 0xc0, "Size mismatch for UFabricJamTrackPlayerTimelineSyncComponent");

// Size: 0x218 (Inherited: 0x1d0, Single: 0x48)
class UFabricJamTrackPlayerUtilityProviderPatchWrapper : public UFabricMetaSoundUtilityProviderPatchWrapper
{
public:
    uint8_t Pad_1a8[0x50]; // 0x1a8 (Size: 0x50, Type: PaddingProperty)
    FName StemsAssetInputName; // 0x1f8 (Size: 0x4, Type: NameProperty)
    FName OnMidiFinishedTriggerOutputName; // 0x1fc (Size: 0x4, Type: NameProperty)
    uint8_t Pad_200[0x18]; // 0x200 (Size: 0x18, Type: PaddingProperty)

private:
    void OnMidiFinishedTriggered(FName& OutputName, const FMetaSoundOutput Output); // 0x11e5239c (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UFabricJamTrackPlayerUtilityProviderPatchWrapper) == 0x218, "Size mismatch for UFabricJamTrackPlayerUtilityProviderPatchWrapper");
static_assert(offsetof(UFabricJamTrackPlayerUtilityProviderPatchWrapper, StemsAssetInputName) == 0x1f8, "Offset mismatch for UFabricJamTrackPlayerUtilityProviderPatchWrapper::StemsAssetInputName");
static_assert(offsetof(UFabricJamTrackPlayerUtilityProviderPatchWrapper, OnMidiFinishedTriggerOutputName) == 0x1fc, "Offset mismatch for UFabricJamTrackPlayerUtilityProviderPatchWrapper::OnMidiFinishedTriggerOutputName");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UInterface_FabricJamTrackPlayerAnalyticsProvider : public UInterface
{
public:

public:
    virtual bool DoPlayersNeedRegistrationForMusicalGameplayForAnalytics() const; // 0x28898d4 (Index: 0x0, Flags: BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent|Const)
    virtual bool IsPlayerAudibleForAnalytics(APlayerController*& const InPlayerController) const; // 0x11e51ea4 (Index: 0x1, Flags: BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent|Const)
    virtual bool IsPlayerRegisteredForAnalytics(APlayerController*& const InPlayerController) const; // 0x11e51fe0 (Index: 0x2, Flags: BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent|Const)
};

static_assert(sizeof(UInterface_FabricJamTrackPlayerAnalyticsProvider) == 0x28, "Size mismatch for UInterface_FabricJamTrackPlayerAnalyticsProvider");

// Size: 0x288 (Inherited: 0x250, Single: 0x38)
class UPlayspaceComponent_FabricJamTrackPlayer : public UPlayspaceComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    UClass* AnalyticsClass; // 0xc0 (Size: 0x8, Type: ClassProperty)
    UClass* SongPlayCoordinatorClass; // 0xc8 (Size: 0x8, Type: ClassProperty)
    UClass* CustomSetlistClass; // 0xd0 (Size: 0x8, Type: ClassProperty)
    uint8_t OnRegisteredPlayersChanged[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSelectorsChanged[0x10]; // 0xe8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnAllowOwnedSongsChanged[0x10]; // 0xf8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSelectionControlChanged[0x10]; // 0x108 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_118[0x10]; // 0x118 (Size: 0x10, Type: PaddingProperty)
    uint8_t OnSetlistPlaybackInitiated[0x10]; // 0x128 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSetlistPlaybackFailed[0x10]; // 0x138 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSongStartedPlaying[0x10]; // 0x148 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSongStoppedPlaying[0x10]; // 0x158 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSongEnded[0x10]; // 0x168 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSongRestarted[0x10]; // 0x178 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSetlistFinished[0x10]; // 0x188 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTrackChanged[0x10]; // 0x198 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPlayerRegistrationFailed[0x10]; // 0x1a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float RestartOrPreviousTimeSecs; // 0x1b8 (Size: 0x4, Type: FloatProperty)
    int32_t RegistrationLimit; // 0x1bc (Size: 0x4, Type: IntProperty)
    bool bOwnedSongsAvailable; // 0x1c0 (Size: 0x1, Type: BoolProperty)
    bool bPublishedIsland; // 0x1c1 (Size: 0x1, Type: BoolProperty)
    bool bIsPlaying; // 0x1c2 (Size: 0x1, Type: BoolProperty)
    bool bAdvanceOnNextPlay; // 0x1c3 (Size: 0x1, Type: BoolProperty)
    bool bMuteLicensedAudio; // 0x1c4 (Size: 0x1, Type: BoolProperty)
    uint8_t SelectionType; // 0x1c5 (Size: 0x1, Type: EnumProperty)
    uint8_t PlaybackBehavior; // 0x1c6 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1c7[0x1]; // 0x1c7 (Size: 0x1, Type: PaddingProperty)
    UFabricJamTrackPlayerAnalyticsComponent* AnalyticsComponent; // 0x1c8 (Size: 0x8, Type: ObjectProperty)
    UFabricJamTrackPlayerSongPlayCoordinator* SongPlayCoordinator; // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    UFabricJamTrackPlayerCustomSetlist* CustomSetlist; // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    int32_t CurrentSetlistTrackIndex; // 0x1e0 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<AActor*> PlayspaceGameplayVolume; // 0x1e4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortClientSettingsRecord*> Settings; // 0x1ec (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMusicClockComponent*> CachedMusicClock; // 0x1f4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricMetaSoundManagerComponent*> CachedMetaSoundManager; // 0x1fc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_204[0x78]; // 0x204 (Size: 0x78, Type: PaddingProperty)
    TWeakObjectPtr<AController*> LastPlayInstigator; // 0x27c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_284[0x4]; // 0x284 (Size: 0x4, Type: PaddingProperty)

public:
    void AdvanceToNextSetlistTrack(AController*& const Instigator); // 0x11e51a48 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool CanPlayerSelectJamTrack(AController*& Player) const; // 0x11e51b74 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetAllowOwnedSongs() const; // 0x11e51cac (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFabricJamTrackPlayerSelectionType GetJamTrackSelectionControl() const; // 0x11e51cd0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFabricJamTrackPlayerPlaybackBehavior GetPlaybackBehavior() const; // 0x11e51ce8 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<AController*> GetRegisteredPlayers() const; // 0x11e51d00 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetRegistrationLimit() const; // 0xed0cf38 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<AController*> GetSelectorPlayers() const; // 0x11e51d3c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GoToPreviousSetlistTrack(AController*& const Instigator); // 0x11e51d78 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void OnGlobalJTPPropertyChanged__DelegateSignature(); // 0x288a61c (Index: 0xb, Flags: MulticastDelegate|Public|Delegate)
    void OnJamTrackPlayerBroadcastChange__DelegateSignature(AController*& const Instigator); // 0x288a61c (Index: 0xc, Flags: MulticastDelegate|Public|Delegate)
    void PlaybackBehaviorChanged__DelegateSignature(EFabricJamTrackPlayerPlaybackBehavior& const NewPlaybackBehavior); // 0x288a61c (Index: 0x11, Flags: MulticastDelegate|Public|Delegate)
    void PlayCurrentSetlistTrack(AController*& const Instigator); // 0x11e527a4 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)
    bool RegisterPlayer(AController*& Player); // 0x11e528d0 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)
    void RegisterPlayers(const TArray<AController*> Players); // 0x11e52a08 (Index: 0x14, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void RestartOrPreviousSetlistTrack(AController*& const Instigator); // 0x11e52c94 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    void SetJamTrackSelectionControl(EFabricJamTrackPlayerSelectionType& InSelectionType); // 0x11e52dc0 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void SetPlaybackBehavior(const EFabricJamTrackPlayerPlaybackBehavior InPlaybackBehavior); // 0x11e52eec (Index: 0x17, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)
    void SetRegistrationLimit(int32_t& InRegistrationLimit); // 0x11e52fb8 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void StartPlayingSetlist(AController*& const Instigator); // 0x11e530f0 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    void StopPlayingSetlist(bool& const bSetlistFinished, AController*& const Instigator); // 0x11e53264 (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)
    void UnregisterAllPlayers(); // 0x11e53480 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable)
    void UnregisterPlayer(AController*& Player); // 0x11e53494 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable)
    void UnregisterPlayers(const TArray<AController*> Players); // 0x11e535c4 (Index: 0x1d, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

private:
    void OnErrorPlayCoordinator(AController*& ErroredController); // 0x11e5211c (Index: 0x9, Flags: Final|Native|Private)
    void OnFabricPlayStateChanged(EFabricMetasoundPlayState& CurrentState); // 0x11e52254 (Index: 0xa, Flags: Final|Native|Private)
    void OnLicensedAudioTreatmentChanged() const; // 0x11e52388 (Index: 0xd, Flags: Final|Native|Private|Const)
    void OnMinigameStateChanged(AFortMinigame*& Minigame, EFortMinigameState& MinigameState); // 0x11e52574 (Index: 0xe, Flags: Final|Native|Private)
    void OnSongEndedPlayCoordinator(); // 0x11e5277c (Index: 0xf, Flags: Final|Native|Private)
    void OnSongStartedPlayCoordinator(); // 0x11e52790 (Index: 0x10, Flags: Final|Native|Private)
};

static_assert(sizeof(UPlayspaceComponent_FabricJamTrackPlayer) == 0x288, "Size mismatch for UPlayspaceComponent_FabricJamTrackPlayer");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, AnalyticsClass) == 0xc0, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::AnalyticsClass");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, SongPlayCoordinatorClass) == 0xc8, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::SongPlayCoordinatorClass");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, CustomSetlistClass) == 0xd0, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::CustomSetlistClass");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnRegisteredPlayersChanged) == 0xd8, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnRegisteredPlayersChanged");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnSelectorsChanged) == 0xe8, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnSelectorsChanged");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnAllowOwnedSongsChanged) == 0xf8, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnAllowOwnedSongsChanged");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnSelectionControlChanged) == 0x108, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnSelectionControlChanged");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnSetlistPlaybackInitiated) == 0x128, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnSetlistPlaybackInitiated");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnSetlistPlaybackFailed) == 0x138, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnSetlistPlaybackFailed");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnSongStartedPlaying) == 0x148, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnSongStartedPlaying");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnSongStoppedPlaying) == 0x158, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnSongStoppedPlaying");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnSongEnded) == 0x168, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnSongEnded");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnSongRestarted) == 0x178, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnSongRestarted");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnSetlistFinished) == 0x188, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnSetlistFinished");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnTrackChanged) == 0x198, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnTrackChanged");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, OnPlayerRegistrationFailed) == 0x1a8, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::OnPlayerRegistrationFailed");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, RestartOrPreviousTimeSecs) == 0x1b8, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::RestartOrPreviousTimeSecs");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, RegistrationLimit) == 0x1bc, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::RegistrationLimit");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, bOwnedSongsAvailable) == 0x1c0, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::bOwnedSongsAvailable");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, bPublishedIsland) == 0x1c1, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::bPublishedIsland");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, bIsPlaying) == 0x1c2, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::bIsPlaying");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, bAdvanceOnNextPlay) == 0x1c3, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::bAdvanceOnNextPlay");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, bMuteLicensedAudio) == 0x1c4, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::bMuteLicensedAudio");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, SelectionType) == 0x1c5, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::SelectionType");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, PlaybackBehavior) == 0x1c6, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::PlaybackBehavior");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, AnalyticsComponent) == 0x1c8, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::AnalyticsComponent");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, SongPlayCoordinator) == 0x1d0, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::SongPlayCoordinator");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, CustomSetlist) == 0x1d8, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::CustomSetlist");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, CurrentSetlistTrackIndex) == 0x1e0, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::CurrentSetlistTrackIndex");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, PlayspaceGameplayVolume) == 0x1e4, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::PlayspaceGameplayVolume");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, Settings) == 0x1ec, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::Settings");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, CachedMusicClock) == 0x1f4, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::CachedMusicClock");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, CachedMetaSoundManager) == 0x1fc, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::CachedMetaSoundManager");
static_assert(offsetof(UPlayspaceComponent_FabricJamTrackPlayer, LastPlayInstigator) == 0x27c, "Offset mismatch for UPlayspaceComponent_FabricJamTrackPlayer::LastPlayInstigator");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FFabricJamTrackPlayerSong
{
    FName ShortName; // 0x0 (Size: 0x4, Type: NameProperty)
    float ServerWorldTimeSentInSeconds; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bIsRestart; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FFabricJamTrackPlayerSong) == 0xc, "Size mismatch for FFabricJamTrackPlayerSong");
static_assert(offsetof(FFabricJamTrackPlayerSong, ShortName) == 0x0, "Offset mismatch for FFabricJamTrackPlayerSong::ShortName");
static_assert(offsetof(FFabricJamTrackPlayerSong, ServerWorldTimeSentInSeconds) == 0x4, "Offset mismatch for FFabricJamTrackPlayerSong::ServerWorldTimeSentInSeconds");
static_assert(offsetof(FFabricJamTrackPlayerSong, bIsRestart) == 0x8, "Offset mismatch for FFabricJamTrackPlayerSong::bIsRestart");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FSetlistEditorsChanged
{
    bool bHasEditors; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FSetlistEditorsChanged) == 0x1, "Size mismatch for FSetlistEditorsChanged");
static_assert(offsetof(FSetlistEditorsChanged, bHasEditors) == 0x0, "Offset mismatch for FSetlistEditorsChanged::bHasEditors");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FFabricJamTrackPlayerCoordinatorStateChanged
{
    uint8_t State; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<USparksMediaStreamer*> MediaStreamer; // 0x4 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FFabricJamTrackPlayerCoordinatorStateChanged) == 0xc, "Size mismatch for FFabricJamTrackPlayerCoordinatorStateChanged");
static_assert(offsetof(FFabricJamTrackPlayerCoordinatorStateChanged, State) == 0x0, "Offset mismatch for FFabricJamTrackPlayerCoordinatorStateChanged::State");
static_assert(offsetof(FFabricJamTrackPlayerCoordinatorStateChanged, MediaStreamer) == 0x4, "Offset mismatch for FFabricJamTrackPlayerCoordinatorStateChanged::MediaStreamer");

