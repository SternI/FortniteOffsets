/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ExecutionTestSuite
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x60 (Inherited: 0x28, Single: 0x38)
class UExecTestObject : public UObject
{
public:
};

static_assert(sizeof(UExecTestObject) == 0x60, "Size mismatch for UExecTestObject");

