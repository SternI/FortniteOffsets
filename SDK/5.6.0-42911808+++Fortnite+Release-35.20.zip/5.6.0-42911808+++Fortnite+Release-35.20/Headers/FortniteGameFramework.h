/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteGameFramework
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "_Verse.h"
#include "StateTreeModule.h"
#include "NetCore.h"

// Size: 0x398 (Inherited: 0x8d8, Single: 0xfffffac0)
class AFGF_PlayerState : public APlayerState
{
public:
};

static_assert(sizeof(AFGF_PlayerState) == 0x398, "Size mismatch for AFGF_PlayerState");

// Size: 0x770 (Inherited: 0xd48, Single: 0xfffffa28)
class AFGF_PlayerController : public APlayerController
{
public:
};

static_assert(sizeof(AFGF_PlayerController) == 0x770, "Size mismatch for AFGF_PlayerController");

// Size: 0x670 (Inherited: 0x660, Single: 0x10)
class AFGF_Character : public UCharacter
{
public:
};

static_assert(sizeof(AFGF_Character) == 0x670, "Size mismatch for AFGF_Character");

// Size: 0x3c0 (Inherited: 0xc40, Single: 0xfffff780)
class AFGF_GameMode : public AGameMode
{
public:
};

static_assert(sizeof(AFGF_GameMode) == 0x3c0, "Size mismatch for AFGF_GameMode");

// Size: 0x360 (Inherited: 0xb90, Single: 0xfffff7d0)
class AFGF_GameState : public AGameState
{
public:
    uint8_t Pad_318[0x40]; // 0x318 (Size: 0x40, Type: PaddingProperty)
    uint8_t bIsObjectTrackingEnabled : 1; // 0x358:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_359[0x7]; // 0x359 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(AFGF_GameState) == 0x360, "Size mismatch for AFGF_GameState");
static_assert(offsetof(AFGF_GameState, bIsObjectTrackingEnabled) == 0x358, "Offset mismatch for AFGF_GameState::bIsObjectTrackingEnabled");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UObjectBasedStateTreeSchema : public UStateTreeSchema
{
public:
};

static_assert(sizeof(UObjectBasedStateTreeSchema) == 0x28, "Size mismatch for UObjectBasedStateTreeSchema");

// Size: 0x1f8 (Inherited: 0xe0, Single: 0x118)
class UStateTreeManagerComponent : public UActorComponent
{
public:
    TArray<FStateTreeRuntimeData> StateTreeRuntimeDataList; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<FStateTreeClientSimulationData> SimulatedDataList; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    FStateChangeDataArray ReplicatedStateChanges; // 0xd8 (Size: 0x120, Type: StructProperty)
};

static_assert(sizeof(UStateTreeManagerComponent) == 0x1f8, "Size mismatch for UStateTreeManagerComponent");
static_assert(offsetof(UStateTreeManagerComponent, StateTreeRuntimeDataList) == 0xb8, "Offset mismatch for UStateTreeManagerComponent::StateTreeRuntimeDataList");
static_assert(offsetof(UStateTreeManagerComponent, SimulatedDataList) == 0xc8, "Offset mismatch for UStateTreeManagerComponent::SimulatedDataList");
static_assert(offsetof(UStateTreeManagerComponent, ReplicatedStateChanges) == 0xd8, "Offset mismatch for UStateTreeManagerComponent::ReplicatedStateChanges");

// Size: 0x88 (Inherited: 0x118, Single: 0xffffff70)
class UStateTreeTaskObject : public UStateTreeTaskBlueprintBase
{
public:
    bool bReplicates; // 0x80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_81[0x7]; // 0x81 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UStateTreeTaskObject) == 0x88, "Size mismatch for UStateTreeTaskObject");
static_assert(offsetof(UStateTreeTaskObject, bReplicates) == 0x80, "Offset mismatch for UStateTreeTaskObject::bReplicates");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FComponentCacheHelper
{
};

static_assert(sizeof(FComponentCacheHelper) == 0x38, "Size mismatch for FComponentCacheHelper");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FActorOwnedStateTreeConfig
{
    TSoftObjectPtr<UStateTree*> StateTreeAsset; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    bool bShouldReplicate; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FActorOwnedStateTreeConfig) == 0x28, "Size mismatch for FActorOwnedStateTreeConfig");
static_assert(offsetof(FActorOwnedStateTreeConfig, StateTreeAsset) == 0x0, "Offset mismatch for FActorOwnedStateTreeConfig::StateTreeAsset");
static_assert(offsetof(FActorOwnedStateTreeConfig, bShouldReplicate) == 0x20, "Offset mismatch for FActorOwnedStateTreeConfig::bShouldReplicate");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FStateTreeRuntimeData
{
    UObject* Owner; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UStateTree* StateTree; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FStateTreeInstanceData StateTreeInstanceData; // 0x10 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_20[0x10]; // 0x20 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FStateTreeRuntimeData) == 0x30, "Size mismatch for FStateTreeRuntimeData");
static_assert(offsetof(FStateTreeRuntimeData, Owner) == 0x0, "Offset mismatch for FStateTreeRuntimeData::Owner");
static_assert(offsetof(FStateTreeRuntimeData, StateTree) == 0x8, "Offset mismatch for FStateTreeRuntimeData::StateTree");
static_assert(offsetof(FStateTreeRuntimeData, StateTreeInstanceData) == 0x10, "Offset mismatch for FStateTreeRuntimeData::StateTreeInstanceData");

// Size: 0x28 (Inherited: 0xc, Single: 0x1c)
struct FStateChangeData : FFastArraySerializerItem
{
    int32_t StateTreeDataHandle; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t Handle; // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t StateIdentifier; // 0x14 (Size: 0x4, Type: IntProperty)
    UStateTreeTaskObject* StateObject; // 0x18 (Size: 0x8, Type: ObjectProperty)
    uint8_t StateChangeType; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FStateChangeData) == 0x28, "Size mismatch for FStateChangeData");
static_assert(offsetof(FStateChangeData, StateTreeDataHandle) == 0xc, "Offset mismatch for FStateChangeData::StateTreeDataHandle");
static_assert(offsetof(FStateChangeData, Handle) == 0x10, "Offset mismatch for FStateChangeData::Handle");
static_assert(offsetof(FStateChangeData, StateIdentifier) == 0x14, "Offset mismatch for FStateChangeData::StateIdentifier");
static_assert(offsetof(FStateChangeData, StateObject) == 0x18, "Offset mismatch for FStateChangeData::StateObject");
static_assert(offsetof(FStateChangeData, StateChangeType) == 0x20, "Offset mismatch for FStateChangeData::StateChangeType");

// Size: 0x120 (Inherited: 0x108, Single: 0x18)
struct FStateChangeDataArray : FFastArraySerializer
{
    TArray<FStateChangeData> StateChangeDataList; // 0x108 (Size: 0x10, Type: ArrayProperty)
    UStateTreeManagerComponent* StateTreeManagerComponent; // 0x118 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FStateChangeDataArray) == 0x120, "Size mismatch for FStateChangeDataArray");
static_assert(offsetof(FStateChangeDataArray, StateChangeDataList) == 0x108, "Offset mismatch for FStateChangeDataArray::StateChangeDataList");
static_assert(offsetof(FStateChangeDataArray, StateTreeManagerComponent) == 0x118, "Offset mismatch for FStateChangeDataArray::StateTreeManagerComponent");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FStateTreeClientSimulationData
{
};

static_assert(sizeof(FStateTreeClientSimulationData) == 0x28, "Size mismatch for FStateTreeClientSimulationData");

