/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Constraints
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "MovieScene.h"
#include "AnimationCore.h"

// Size: 0x50 (Inherited: 0xb8, Single: 0xffffff98)
class UConstraintSubsystem : public UEngineSubsystem
{
public:
    uint8_t OnConstraintAddedToSystem_BP; // 0x30 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    uint8_t OnConstraintRemovedFromSystem_BP; // 0x31 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    uint8_t Pad_32[0x6]; // 0x32 (Size: 0x6, Type: PaddingProperty)
    TArray<FConstraintsInWorld> ConstraintsInWorld; // 0x38 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)

public:
    void OnConstraintAddedToSystem__DelegateSignature(UConstraintSubsystem*& Mananger, UTickableConstraint*& Constraint); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    void OnConstraintRemovedFromSystem__DelegateSignature(UConstraintSubsystem*& Mananger, UTickableConstraint*& Constraint, bool& bDoNotCompensate); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
};

static_assert(sizeof(UConstraintSubsystem) == 0x50, "Size mismatch for UConstraintSubsystem");
static_assert(offsetof(UConstraintSubsystem, OnConstraintAddedToSystem_BP) == 0x30, "Offset mismatch for UConstraintSubsystem::OnConstraintAddedToSystem_BP");
static_assert(offsetof(UConstraintSubsystem, OnConstraintRemovedFromSystem_BP) == 0x31, "Offset mismatch for UConstraintSubsystem::OnConstraintRemovedFromSystem_BP");
static_assert(offsetof(UConstraintSubsystem, ConstraintsInWorld) == 0x38, "Offset mismatch for UConstraintSubsystem::ConstraintsInWorld");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class AConstraintsActor : public AActor
{
public:
    UConstraintsManager* ConstraintsManager; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(AConstraintsActor) == 0x2b0, "Size mismatch for AConstraintsActor");
static_assert(offsetof(AConstraintsActor, ConstraintsManager) == 0x2a8, "Offset mismatch for AConstraintsActor::ConstraintsManager");

// Size: 0x90 (Inherited: 0x28, Single: 0x68)
class UTickableConstraint : public UObject
{
public:
    bool Active; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bValid; // 0x29 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a[0x66]; // 0x2a (Size: 0x66, Type: PaddingProperty)
};

static_assert(sizeof(UTickableConstraint) == 0x90, "Size mismatch for UTickableConstraint");
static_assert(offsetof(UTickableConstraint, Active) == 0x28, "Offset mismatch for UTickableConstraint::Active");
static_assert(offsetof(UTickableConstraint, bValid) == 0x29, "Offset mismatch for UTickableConstraint::bValid");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UConstraintsManager : public UObject
{
public:
    uint8_t OnConstraintAdded_BP; // 0x28 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    uint8_t OnConstraintRemoved_BP; // 0x29 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    uint8_t Pad_2a[0xe]; // 0x2a (Size: 0xe, Type: PaddingProperty)
    TArray<UTickableConstraint*> Constraints; // 0x38 (Size: 0x10, Type: ArrayProperty)

public:
    void OnConstraintAdded__DelegateSignature(UConstraintsManager*& Mananger, UTickableConstraint*& Constraint); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    void OnConstraintRemoved__DelegateSignature(UConstraintsManager*& Mananger, UTickableConstraint*& Constraint, bool& bDoNotCompensate); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
};

static_assert(sizeof(UConstraintsManager) == 0x48, "Size mismatch for UConstraintsManager");
static_assert(offsetof(UConstraintsManager, OnConstraintAdded_BP) == 0x28, "Offset mismatch for UConstraintsManager::OnConstraintAdded_BP");
static_assert(offsetof(UConstraintsManager, OnConstraintRemoved_BP) == 0x29, "Offset mismatch for UConstraintsManager::OnConstraintRemoved_BP");
static_assert(offsetof(UConstraintsManager, Constraints) == 0x38, "Offset mismatch for UConstraintsManager::Constraints");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UConstraintsScriptingLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool AddConstraint(UWorld*& InWorld, UTransformableHandle*& InParentHandle, UTransformableHandle*& InChildHandle, UTickableTransformConstraint*& InConstraint, bool& const bMaintainOffset); // 0x9fb4be4 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static UTickableTransformConstraint* CreateFromType(UWorld*& InWorld, ETransformConstraintType& const InType); // 0x9fb5070 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static UTransformableComponentHandle* CreateTransformableComponentHandle(UWorld*& InWorld, USceneComponent*& InSceneComponent, const FName InSocketName); // 0x9fb5278 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UTransformableHandle* CreateTransformableHandle(UWorld*& InWorld, UObject*& InObject, const FName InAttachmentName); // 0x9fb5700 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static TArray<UTickableConstraint*> GetConstraintsArray(UWorld*& InWorld); // 0x9fb5998 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static bool RemoveConstraint(UWorld*& InWorld, int32_t& InIndex); // 0x9fb5b6c (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static bool RemoveThisConstraint(UWorld*& InWorld, UTickableConstraint*& InTickableConstraint); // 0x9fb5d80 (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UConstraintsScriptingLibrary) == 0x28, "Size mismatch for UConstraintsScriptingLibrary");

// Size: 0x60 (Inherited: 0x28, Single: 0x38)
class UTransformableHandle : public UObject
{
public:
    uint8_t Pad_28[0x4]; // 0x28 (Size: 0x4, Type: PaddingProperty)
    FMovieSceneObjectBindingID ConstraintBindingID; // 0x2c (Size: 0x18, Type: StructProperty)
    uint8_t Pad_44[0x1c]; // 0x44 (Size: 0x1c, Type: PaddingProperty)
};

static_assert(sizeof(UTransformableHandle) == 0x60, "Size mismatch for UTransformableHandle");
static_assert(offsetof(UTransformableHandle, ConstraintBindingID) == 0x2c, "Offset mismatch for UTransformableHandle::ConstraintBindingID");

// Size: 0x70 (Inherited: 0x88, Single: 0xffffffe8)
class UTransformableComponentHandle : public UTransformableHandle
{
public:
    TWeakObjectPtr<USceneComponent*> Component; // 0x60 (Size: 0x8, Type: WeakObjectProperty)
    FName SocketName; // 0x68 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UTransformableComponentHandle) == 0x70, "Size mismatch for UTransformableComponentHandle");
static_assert(offsetof(UTransformableComponentHandle, Component) == 0x60, "Offset mismatch for UTransformableComponentHandle::Component");
static_assert(offsetof(UTransformableComponentHandle, SocketName) == 0x68, "Offset mismatch for UTransformableComponentHandle::SocketName");

// Size: 0xb0 (Inherited: 0xb8, Single: 0xfffffff8)
class UTickableTransformConstraint : public UTickableConstraint
{
public:
    UTransformableHandle* ParentTRSHandle; // 0x90 (Size: 0x8, Type: ObjectProperty)
    UTransformableHandle* ChildTRSHandle; // 0x98 (Size: 0x8, Type: ObjectProperty)
    bool bMaintainOffset; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0x3]; // 0xa1 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0xa4 (Size: 0x4, Type: FloatProperty)
    bool bDynamicOffset; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Type; // 0xa9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_aa[0x6]; // 0xaa (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UTickableTransformConstraint) == 0xb0, "Size mismatch for UTickableTransformConstraint");
static_assert(offsetof(UTickableTransformConstraint, ParentTRSHandle) == 0x90, "Offset mismatch for UTickableTransformConstraint::ParentTRSHandle");
static_assert(offsetof(UTickableTransformConstraint, ChildTRSHandle) == 0x98, "Offset mismatch for UTickableTransformConstraint::ChildTRSHandle");
static_assert(offsetof(UTickableTransformConstraint, bMaintainOffset) == 0xa0, "Offset mismatch for UTickableTransformConstraint::bMaintainOffset");
static_assert(offsetof(UTickableTransformConstraint, Weight) == 0xa4, "Offset mismatch for UTickableTransformConstraint::Weight");
static_assert(offsetof(UTickableTransformConstraint, bDynamicOffset) == 0xa8, "Offset mismatch for UTickableTransformConstraint::bDynamicOffset");
static_assert(offsetof(UTickableTransformConstraint, Type) == 0xa9, "Offset mismatch for UTickableTransformConstraint::Type");

// Size: 0xd8 (Inherited: 0x168, Single: 0xffffff70)
class UTickableTranslationConstraint : public UTickableTransformConstraint
{
public:
    uint8_t Pad_b0[0x8]; // 0xb0 (Size: 0x8, Type: PaddingProperty)
    FVector OffsetTranslation; // 0xb8 (Size: 0x18, Type: StructProperty)
    FFilterOptionPerAxis AxisFilter; // 0xd0 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_d3[0x5]; // 0xd3 (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(UTickableTranslationConstraint) == 0xd8, "Size mismatch for UTickableTranslationConstraint");
static_assert(offsetof(UTickableTranslationConstraint, OffsetTranslation) == 0xb8, "Offset mismatch for UTickableTranslationConstraint::OffsetTranslation");
static_assert(offsetof(UTickableTranslationConstraint, AxisFilter) == 0xd0, "Offset mismatch for UTickableTranslationConstraint::AxisFilter");

// Size: 0xf0 (Inherited: 0x168, Single: 0xffffff88)
class UTickableRotationConstraint : public UTickableTransformConstraint
{
public:
    uint8_t Pad_b0[0x10]; // 0xb0 (Size: 0x10, Type: PaddingProperty)
    FQuat OffsetRotation; // 0xc0 (Size: 0x20, Type: StructProperty)
    FFilterOptionPerAxis AxisFilter; // 0xe0 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_e3[0xd]; // 0xe3 (Size: 0xd, Type: PaddingProperty)
};

static_assert(sizeof(UTickableRotationConstraint) == 0xf0, "Size mismatch for UTickableRotationConstraint");
static_assert(offsetof(UTickableRotationConstraint, OffsetRotation) == 0xc0, "Offset mismatch for UTickableRotationConstraint::OffsetRotation");
static_assert(offsetof(UTickableRotationConstraint, AxisFilter) == 0xe0, "Offset mismatch for UTickableRotationConstraint::AxisFilter");

// Size: 0xd8 (Inherited: 0x168, Single: 0xffffff70)
class UTickableScaleConstraint : public UTickableTransformConstraint
{
public:
    uint8_t Pad_b0[0x8]; // 0xb0 (Size: 0x8, Type: PaddingProperty)
    FVector OffsetScale; // 0xb8 (Size: 0x18, Type: StructProperty)
    FFilterOptionPerAxis AxisFilter; // 0xd0 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_d3[0x5]; // 0xd3 (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(UTickableScaleConstraint) == 0xd8, "Size mismatch for UTickableScaleConstraint");
static_assert(offsetof(UTickableScaleConstraint, OffsetScale) == 0xb8, "Offset mismatch for UTickableScaleConstraint::OffsetScale");
static_assert(offsetof(UTickableScaleConstraint, AxisFilter) == 0xd0, "Offset mismatch for UTickableScaleConstraint::AxisFilter");

// Size: 0x130 (Inherited: 0x168, Single: 0xffffffc8)
class UTickableParentConstraint : public UTickableTransformConstraint
{
public:
    uint8_t Pad_b0[0x10]; // 0xb0 (Size: 0x10, Type: PaddingProperty)
    FTransform OffsetTransform; // 0xc0 (Size: 0x60, Type: StructProperty)
    bool bScaling; // 0x120 (Size: 0x1, Type: BoolProperty)
    FTransformFilter TransformFilter; // 0x121 (Size: 0x9, Type: StructProperty)
    uint8_t Pad_12a[0x6]; // 0x12a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UTickableParentConstraint) == 0x130, "Size mismatch for UTickableParentConstraint");
static_assert(offsetof(UTickableParentConstraint, OffsetTransform) == 0xc0, "Offset mismatch for UTickableParentConstraint::OffsetTransform");
static_assert(offsetof(UTickableParentConstraint, bScaling) == 0x120, "Offset mismatch for UTickableParentConstraint::bScaling");
static_assert(offsetof(UTickableParentConstraint, TransformFilter) == 0x121, "Offset mismatch for UTickableParentConstraint::TransformFilter");

// Size: 0xc8 (Inherited: 0x168, Single: 0xffffff60)
class UTickableLookAtConstraint : public UTickableTransformConstraint
{
public:
    FVector Axis; // 0xb0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UTickableLookAtConstraint) == 0xc8, "Size mismatch for UTickableLookAtConstraint");
static_assert(offsetof(UTickableLookAtConstraint, Axis) == 0xb0, "Offset mismatch for UTickableLookAtConstraint::Axis");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FConstraintsInWorld
{
    TWeakObjectPtr<UWorld*> World; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<UTickableConstraint*>> Constraints; // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_18[0x10]; // 0x18 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FConstraintsInWorld) == 0x28, "Size mismatch for FConstraintsInWorld");
static_assert(offsetof(FConstraintsInWorld, World) == 0x0, "Offset mismatch for FConstraintsInWorld::World");
static_assert(offsetof(FConstraintsInWorld, Constraints) == 0x8, "Offset mismatch for FConstraintsInWorld::Constraints");

// Size: 0x108 (Inherited: 0x158, Single: 0xffffffb0)
struct FMovieSceneConstraintChannel : FMovieSceneBoolChannel
{
};

static_assert(sizeof(FMovieSceneConstraintChannel) == 0x108, "Size mismatch for FMovieSceneConstraintChannel");

// Size: 0x110 (Inherited: 0x0, Single: 0x110)
struct FConstraintAndActiveChannel
{
    FMovieSceneConstraintChannel ActiveChannel; // 0x0 (Size: 0x108, Type: StructProperty)
    UTickableConstraint* ConstraintCopyToSpawn; // 0x108 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FConstraintAndActiveChannel) == 0x110, "Size mismatch for FConstraintAndActiveChannel");
static_assert(offsetof(FConstraintAndActiveChannel, ActiveChannel) == 0x0, "Offset mismatch for FConstraintAndActiveChannel::ActiveChannel");
static_assert(offsetof(FConstraintAndActiveChannel, ConstraintCopyToSpawn) == 0x108, "Offset mismatch for FConstraintAndActiveChannel::ConstraintCopyToSpawn");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
struct FConstraintTickFunction : FTickFunction
{
};

static_assert(sizeof(FConstraintTickFunction) == 0x40, "Size mismatch for FConstraintTickFunction");

