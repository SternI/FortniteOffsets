/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ElectroBatGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "Engine.h"
#include "ModularGameplay.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0x80 (Inherited: 0x88, Single: 0xfffffff8)
class UElectroBatAttributeSet : public UFortAttributeSet
{
public:
    FFortGameplayAttributeData KnockbackCharge; // 0x30 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData CurrentChargeStage; // 0x58 (Size: 0x28, Type: StructProperty)

private:
    void OnRep_CurrentChargeStage(const FFortGameplayAttributeData OldValue); // 0x113d402c (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
    void OnRep_KnockbackCharge(const FFortGameplayAttributeData OldValue); // 0x113d4134 (Index: 0x1, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UElectroBatAttributeSet) == 0x80, "Size mismatch for UElectroBatAttributeSet");
static_assert(offsetof(UElectroBatAttributeSet, KnockbackCharge) == 0x30, "Offset mismatch for UElectroBatAttributeSet::KnockbackCharge");
static_assert(offsetof(UElectroBatAttributeSet, CurrentChargeStage) == 0x58, "Offset mismatch for UElectroBatAttributeSet::CurrentChargeStage");

// Size: 0x1330 (Inherited: 0x20a8, Single: 0xfffff288)
class UElectroBatLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    FFortPlayerAnimAssets PlayerAnimAssetsOverrideDuringCharging; // 0x12f0 (Size: 0x10, Type: StructProperty)
    float CustomMeleeTwist; // 0x1300 (Size: 0x4, Type: FloatProperty)
    bool bChargedSwingHit; // 0x1304 (Size: 0x1, Type: BoolProperty)
    bool bUserCurve01; // 0x1305 (Size: 0x1, Type: BoolProperty)
    bool bEnterChargedState; // 0x1306 (Size: 0x1, Type: BoolProperty)
    bool bUserCurve03; // 0x1307 (Size: 0x1, Type: BoolProperty)
    bool bExitOutro; // 0x1308 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1309[0x3]; // 0x1309 (Size: 0x3, Type: PaddingProperty)
    FGameplayTag ChargingTagName; // 0x130c (Size: 0x4, Type: StructProperty)
    FGameplayTag HitTagName; // 0x1310 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1314[0x1c]; // 0x1314 (Size: 0x1c, Type: PaddingProperty)
};

static_assert(sizeof(UElectroBatLayerAnimInstance) == 0x1330, "Size mismatch for UElectroBatLayerAnimInstance");
static_assert(offsetof(UElectroBatLayerAnimInstance, PlayerAnimAssetsOverrideDuringCharging) == 0x12f0, "Offset mismatch for UElectroBatLayerAnimInstance::PlayerAnimAssetsOverrideDuringCharging");
static_assert(offsetof(UElectroBatLayerAnimInstance, CustomMeleeTwist) == 0x1300, "Offset mismatch for UElectroBatLayerAnimInstance::CustomMeleeTwist");
static_assert(offsetof(UElectroBatLayerAnimInstance, bChargedSwingHit) == 0x1304, "Offset mismatch for UElectroBatLayerAnimInstance::bChargedSwingHit");
static_assert(offsetof(UElectroBatLayerAnimInstance, bUserCurve01) == 0x1305, "Offset mismatch for UElectroBatLayerAnimInstance::bUserCurve01");
static_assert(offsetof(UElectroBatLayerAnimInstance, bEnterChargedState) == 0x1306, "Offset mismatch for UElectroBatLayerAnimInstance::bEnterChargedState");
static_assert(offsetof(UElectroBatLayerAnimInstance, bUserCurve03) == 0x1307, "Offset mismatch for UElectroBatLayerAnimInstance::bUserCurve03");
static_assert(offsetof(UElectroBatLayerAnimInstance, bExitOutro) == 0x1308, "Offset mismatch for UElectroBatLayerAnimInstance::bExitOutro");
static_assert(offsetof(UElectroBatLayerAnimInstance, ChargingTagName) == 0x130c, "Offset mismatch for UElectroBatLayerAnimInstance::ChargingTagName");
static_assert(offsetof(UElectroBatLayerAnimInstance, HitTagName) == 0x1310, "Offset mismatch for UElectroBatLayerAnimInstance::HitTagName");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UElectroBatWeaponComponent : public UFortWeaponComponent
{
public:
    uint8_t OnChargeStart[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnChargeStop[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnChargeIncreased[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_e8[0x10]; // 0xe8 (Size: 0x10, Type: PaddingProperty)
    FGameplayAttribute ChargeStageAttribute; // 0xf8 (Size: 0x38, Type: StructProperty)
    uint8_t Pad_130[0x8]; // 0x130 (Size: 0x8, Type: PaddingProperty)
    UClass* CustomSprintMMEClass; // 0x138 (Size: 0x8, Type: ClassProperty)
    FGameplayTag ElectroBatSprintingTag; // 0x140 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_144[0x4]; // 0x144 (Size: 0x4, Type: PaddingProperty)
    UClass* FallDamamgeImmunityEffectClass; // 0x148 (Size: 0x8, Type: ClassProperty)
    UClass* StartChargingEffectClass; // 0x150 (Size: 0x8, Type: ClassProperty)
    UClass* StopChargeEffectClass; // 0x158 (Size: 0x8, Type: ClassProperty)
    UClass* IncrementChargeEffectClass; // 0x160 (Size: 0x8, Type: ClassProperty)
    UClass* ChargingEffectClass; // 0x168 (Size: 0x8, Type: ClassProperty)
    FScalableFloat PreChargeDelay; // 0x170 (Size: 0x28, Type: StructProperty)
    FScalableFloat TimePerCharge; // 0x198 (Size: 0x28, Type: StructProperty)
    FScalableFloat TotalChargeStages; // 0x1c0 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_1e8[0x10]; // 0x1e8 (Size: 0x10, Type: PaddingProperty)

public:
    int32_t GetCurrentChargeStage() const; // 0x113d3fb0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsCharging() const; // 0xd574ac0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetElectroBatMovementEnabled(bool& const bMovementEnabled); // 0x113d423c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void StartCharging(); // 0x113d4368 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void StopCharging(); // 0x113d439c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnPawnJumped(); // 0x113d4018 (Index: 0x2, Flags: Final|Native|Private)
    virtual void ServerStopCharging(); // 0x3473f70 (Index: 0x3, Flags: Final|Net|Native|Event|Private|NetServer)
};

static_assert(sizeof(UElectroBatWeaponComponent) == 0x1f8, "Size mismatch for UElectroBatWeaponComponent");
static_assert(offsetof(UElectroBatWeaponComponent, OnChargeStart) == 0xb8, "Offset mismatch for UElectroBatWeaponComponent::OnChargeStart");
static_assert(offsetof(UElectroBatWeaponComponent, OnChargeStop) == 0xc8, "Offset mismatch for UElectroBatWeaponComponent::OnChargeStop");
static_assert(offsetof(UElectroBatWeaponComponent, OnChargeIncreased) == 0xd8, "Offset mismatch for UElectroBatWeaponComponent::OnChargeIncreased");
static_assert(offsetof(UElectroBatWeaponComponent, ChargeStageAttribute) == 0xf8, "Offset mismatch for UElectroBatWeaponComponent::ChargeStageAttribute");
static_assert(offsetof(UElectroBatWeaponComponent, CustomSprintMMEClass) == 0x138, "Offset mismatch for UElectroBatWeaponComponent::CustomSprintMMEClass");
static_assert(offsetof(UElectroBatWeaponComponent, ElectroBatSprintingTag) == 0x140, "Offset mismatch for UElectroBatWeaponComponent::ElectroBatSprintingTag");
static_assert(offsetof(UElectroBatWeaponComponent, FallDamamgeImmunityEffectClass) == 0x148, "Offset mismatch for UElectroBatWeaponComponent::FallDamamgeImmunityEffectClass");
static_assert(offsetof(UElectroBatWeaponComponent, StartChargingEffectClass) == 0x150, "Offset mismatch for UElectroBatWeaponComponent::StartChargingEffectClass");
static_assert(offsetof(UElectroBatWeaponComponent, StopChargeEffectClass) == 0x158, "Offset mismatch for UElectroBatWeaponComponent::StopChargeEffectClass");
static_assert(offsetof(UElectroBatWeaponComponent, IncrementChargeEffectClass) == 0x160, "Offset mismatch for UElectroBatWeaponComponent::IncrementChargeEffectClass");
static_assert(offsetof(UElectroBatWeaponComponent, ChargingEffectClass) == 0x168, "Offset mismatch for UElectroBatWeaponComponent::ChargingEffectClass");
static_assert(offsetof(UElectroBatWeaponComponent, PreChargeDelay) == 0x170, "Offset mismatch for UElectroBatWeaponComponent::PreChargeDelay");
static_assert(offsetof(UElectroBatWeaponComponent, TimePerCharge) == 0x198, "Offset mismatch for UElectroBatWeaponComponent::TimePerCharge");
static_assert(offsetof(UElectroBatWeaponComponent, TotalChargeStages) == 0x1c0, "Offset mismatch for UElectroBatWeaponComponent::TotalChargeStages");

