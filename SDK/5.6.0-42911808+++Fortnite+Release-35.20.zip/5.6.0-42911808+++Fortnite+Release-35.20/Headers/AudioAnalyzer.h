/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioAnalyzer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAudioAnalyzerAssetBase : public UObject
{
public:
};

static_assert(sizeof(UAudioAnalyzerAssetBase) == 0x28, "Size mismatch for UAudioAnalyzerAssetBase");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioAnalyzerSettings : public UAudioAnalyzerAssetBase
{
public:
};

static_assert(sizeof(UAudioAnalyzerSettings) == 0x28, "Size mismatch for UAudioAnalyzerSettings");

// Size: 0xa0 (Inherited: 0x28, Single: 0x78)
class UAudioAnalyzer : public UObject
{
public:
    UAudioBus* AudioBus; // 0x28 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    UAudioAnalyzerSubsystem* AudioAnalyzerSubsystem; // 0x38 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_40[0x60]; // 0x40 (Size: 0x60, Type: PaddingProperty)

public:
    void StartAnalyzing(UObject*& const WorldContextObject, UAudioBus*& AudioBusToAnalyze); // 0xfd57cec (Index: 0x0, Flags: Final|RequiredAPI|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void StopAnalyzing(UObject*& const WorldContextObject); // 0xfd57ef4 (Index: 0x1, Flags: Final|RequiredAPI|BlueprintCosmetic|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioAnalyzer) == 0xa0, "Size mismatch for UAudioAnalyzer");
static_assert(offsetof(UAudioAnalyzer, AudioBus) == 0x28, "Offset mismatch for UAudioAnalyzer::AudioBus");
static_assert(offsetof(UAudioAnalyzer, AudioAnalyzerSubsystem) == 0x38, "Offset mismatch for UAudioAnalyzer::AudioAnalyzerSubsystem");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioAnalyzerNRTSettings : public UAudioAnalyzerAssetBase
{
public:
};

static_assert(sizeof(UAudioAnalyzerNRTSettings) == 0x28, "Size mismatch for UAudioAnalyzerNRTSettings");

// Size: 0x78 (Inherited: 0x50, Single: 0x28)
class UAudioAnalyzerNRT : public UAudioAnalyzerAssetBase
{
public:
    USoundWave* Sound; // 0x28 (Size: 0x8, Type: ObjectProperty)
    float DurationInSeconds; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x44]; // 0x34 (Size: 0x44, Type: PaddingProperty)
};

static_assert(sizeof(UAudioAnalyzerNRT) == 0x78, "Size mismatch for UAudioAnalyzerNRT");
static_assert(offsetof(UAudioAnalyzerNRT, Sound) == 0x28, "Offset mismatch for UAudioAnalyzerNRT::Sound");
static_assert(offsetof(UAudioAnalyzerNRT, DurationInSeconds) == 0x30, "Offset mismatch for UAudioAnalyzerNRT::DurationInSeconds");

// Size: 0x50 (Inherited: 0xb8, Single: 0xffffff98)
class UAudioAnalyzerSubsystem : public UEngineSubsystem
{
public:
    TArray<UAudioAnalyzer*> AudioAnalyzers; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_40[0x10]; // 0x40 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UAudioAnalyzerSubsystem) == 0x50, "Size mismatch for UAudioAnalyzerSubsystem");
static_assert(offsetof(UAudioAnalyzerSubsystem, AudioAnalyzers) == 0x30, "Offset mismatch for UAudioAnalyzerSubsystem::AudioAnalyzers");

