/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Banners
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBannerLibrary_C : public UBlueprintFunctionLibrary
{
public:

public:
    static void UpdateBannerColorOnMaterial(UMaterialInstanceDynamic*& Material, FLinearColor& PrimaryBGColor, FLinearColor& SecondaryBGColor, UObject*& __WorldContext); // 0x288a61c (Index: 0x0, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void GenericUpdateMaterial(UMaterialInstanceDynamic*& Target, UTexture*& BannerIcon, FLinearColor& BG_PrimaryColor, FLinearColor& BG_SecondaryColor, UTexture*& ShapeIcon, UObject*& __WorldContext); // 0x288a61c (Index: 0x1, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void UpdateBannerIconOnMaterial(UMaterialInstanceDynamic*& Material, UTexture*& Icon, UObject*& __WorldContext); // 0x288a61c (Index: 0x2, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UBannerLibrary_C) == 0x28, "Size mismatch for UBannerLibrary_C");

