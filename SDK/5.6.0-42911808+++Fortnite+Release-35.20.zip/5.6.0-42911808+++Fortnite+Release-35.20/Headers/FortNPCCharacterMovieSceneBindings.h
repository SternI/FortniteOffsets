/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortNPCCharacterMovieSceneBindings
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameFeatures.h"
#include "MovieSceneTracks.h"
#include "MovieScene.h"
#include "VerseFortniteAI.h"
#include "CoreUObject.h"

// Size: 0x68 (Inherited: 0x50, Single: 0x18)
class UFortGameFeatureAction_SetSeqNPCClasses : public UGameFeatureAction
{
public:
    TSoftClassPtr MannequinClass; // 0x28 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr MannequinAnimInstanceClass; // 0x48 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UFortGameFeatureAction_SetSeqNPCClasses) == 0x68, "Size mismatch for UFortGameFeatureAction_SetSeqNPCClasses");
static_assert(offsetof(UFortGameFeatureAction_SetSeqNPCClasses, MannequinClass) == 0x28, "Offset mismatch for UFortGameFeatureAction_SetSeqNPCClasses::MannequinClass");
static_assert(offsetof(UFortGameFeatureAction_SetSeqNPCClasses, MannequinAnimInstanceClass) == 0x48, "Offset mismatch for UFortGameFeatureAction_SetSeqNPCClasses::MannequinAnimInstanceClass");

// Size: 0x48 (Inherited: 0xa0, Single: 0xffffffa8)
class UFortNPCCharacterMovieSceneReplaceableBinding : public UMovieSceneReplaceableActorBinding
{
public:
    TSoftObjectPtr<UNPCCharacterDefinition*> CharacterDefinition; // 0x28 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(UFortNPCCharacterMovieSceneReplaceableBinding) == 0x48, "Size mismatch for UFortNPCCharacterMovieSceneReplaceableBinding");
static_assert(offsetof(UFortNPCCharacterMovieSceneReplaceableBinding, CharacterDefinition) == 0x28, "Offset mismatch for UFortNPCCharacterMovieSceneReplaceableBinding::CharacterDefinition");

// Size: 0x90 (Inherited: 0xb8, Single: 0xffffffd8)
class UFortNPCCharacterMovieSceneSpawnableBinding : public UMovieSceneSpawnableActorBindingBase
{
public:
    TSoftObjectPtr<UNPCCharacterDefinition*> CharacterDefinition; // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    UClass* SpawnableActorClass; // 0x58 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_60[0x30]; // 0x60 (Size: 0x30, Type: PaddingProperty)
};

static_assert(sizeof(UFortNPCCharacterMovieSceneSpawnableBinding) == 0x90, "Size mismatch for UFortNPCCharacterMovieSceneSpawnableBinding");
static_assert(offsetof(UFortNPCCharacterMovieSceneSpawnableBinding, CharacterDefinition) == 0x38, "Offset mismatch for UFortNPCCharacterMovieSceneSpawnableBinding::CharacterDefinition");
static_assert(offsetof(UFortNPCCharacterMovieSceneSpawnableBinding, SpawnableActorClass) == 0x58, "Offset mismatch for UFortNPCCharacterMovieSceneSpawnableBinding::SpawnableActorClass");

