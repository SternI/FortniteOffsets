/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_SurfaceTrackingComponent_FortPawn
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0x1b8 (Inherited: 0x4c8, Single: 0xfffffcf0)
class UBP_SurfaceTrackingComponent_FortPawn_C : public UFortSurfaceTrackingComponent
{
public:
};

static_assert(sizeof(UBP_SurfaceTrackingComponent_FortPawn_C) == 0x1b8, "Size mismatch for UBP_SurfaceTrackingComponent_FortPawn_C");

