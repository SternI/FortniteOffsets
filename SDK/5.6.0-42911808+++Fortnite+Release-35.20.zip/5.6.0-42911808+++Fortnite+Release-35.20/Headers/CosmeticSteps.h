/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticSteps
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "BeanstalkCosmeticsRuntime.h"
#include "Engine.h"

// Size: 0xc8 (Inherited: 0x1a0, Single: 0xffffff28)
class UBP_FortCosmeticStep_ApplyBeanCD_C : public UFortCosmeticStep_ApplyBeanCD
{
public:

public:
    virtual void BP_UpdateCosmeticMaterials(UBeanCosmeticItemDefinitionBase*& const BeanCD, UMaterialInstanceDynamic*& MaterialBody, UMaterialInstanceDynamic*& MaterialCostume, UMaterialInstanceDynamic*& MaterialHead) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UBP_FortCosmeticStep_ApplyBeanCD_C) == 0xc8, "Size mismatch for UBP_FortCosmeticStep_ApplyBeanCD_C");

