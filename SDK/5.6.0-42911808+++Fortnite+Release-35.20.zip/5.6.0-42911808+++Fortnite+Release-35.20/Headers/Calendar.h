/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Calendar
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CommonUI.h"
#include "FortniteUI.h"
#include "UIKit.h"
#include "Systems.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "WBP_CompeteTileButton_Base.h"
#include "ModelViewViewModel.h"
#include "CompeteUI.h"
#include "SlateCore.h"
#include "Engine.h"
#include "UI.h"
#include "Blueprints.h"
#include "TournamentTile.h"
#include "Valkyrie.h"

// Size: 0x5b0 (Inherited: 0xb38, Single: 0xfffffa78)
class UWBP_Calendar_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x408 (Size: 0x8, Type: StructProperty)
    UWBP_TournamentsCarousel_C* WBP_TournamentsCarousel; // 0x410 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* VertBox_MobileCalendarContainer; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UUniformGridPanel* UniformGridPanel; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* TournamentsStateVisibilitySwitcher; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UFortSwipePanel* SwipePanel; // 0x430 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_Month; // 0x438 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UScrollBox* ScrollBox_Month; // 0x448 (Size: 0x8, Type: ObjectProperty)
    USafeZone* SafeZone; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Generic_C* PreviousButton; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Generic_C* NextButton; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* NavigationButtons; // 0x468 (Size: 0x8, Type: ObjectProperty)
    UWBP_IconHintsPanel_C* IconHintsPanel; // 0x470 (Size: 0x8, Type: ObjectProperty)
    UWBP_FilterButton_C* FilterButton; // 0x478 (Size: 0x8, Type: ObjectProperty)
    UWBP_BottomBarDecoyButton_C* DecoyButton_Today; // 0x480 (Size: 0x8, Type: ObjectProperty)
    UWBP_BottomBarDecoyButton_C* DecoyButton_FirstUpcoming; // 0x488 (Size: 0x8, Type: ObjectProperty)
    UWBP_BottomBarDecoyButton_C* DecoyButton_Bookmark; // 0x490 (Size: 0x8, Type: ObjectProperty)
    UWBP_BottomBarDecoyButton_C* DecoyButton_Back; // 0x498 (Size: 0x8, Type: ObjectProperty)
    UUniformGridPanel* Days; // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UWBP_CaptureForPostBufferUpdate_C* CaptureForPostBufferUpdate; // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UWBP_CalendarWrapper_C* CalendarWrapper; // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UImage* Background; // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OpenCalendar; // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_BackgroundColor; // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UFortPoblanoTournamentsCalendarVM* FortPoblanoTournamentsCalendarVM; // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    TArray<UWBP_CalendarTile_C*> CalendarDayTilesArray; // 0x4d8 (Size: 0x10, Type: ArrayProperty)
    UCommonButtonBase* Selected_Calendar_Tile; // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    bool IsCalendarOpened; // 0x4f0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4f1[0x3]; // 0x4f1 (Size: 0x3, Type: PaddingProperty)
    int32_t Selected_Tournament_Tile; // 0x4f4 (Size: 0x4, Type: IntProperty)
    UMaterialInstanceDynamic* MID_Background; // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    FLinearColor NextColor1; // 0x500 (Size: 0x10, Type: StructProperty)
    TArray<UWBP_TournamentTile_C*> TournamentTilesArray; // 0x510 (Size: 0x10, Type: ArrayProperty)
    FLinearColor NextColor2; // 0x520 (Size: 0x10, Type: StructProperty)
    bool B_Has_Init_Months; // 0x530 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_531[0x7]; // 0x531 (Size: 0x7, Type: PaddingProperty)
    double Max_Color_Luminance; // 0x538 (Size: 0x8, Type: DoubleProperty)
    UMVVM_CompeteEmptyTile_Entry_C* FirstItem; // 0x540 (Size: 0x8, Type: ObjectProperty)
    UMVVM_CompeteEmptyTile_Entry_C* LastItem; // 0x548 (Size: 0x8, Type: ObjectProperty)
    uint8_t Input_Type; // 0x550 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_551[0x7]; // 0x551 (Size: 0x7, Type: PaddingProperty)
    UFortPoblanoTournamentsCalendarTournamentTileVM* CurrentSelectedTileVM; // 0x558 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle AddBookmarkInputAction; // 0x560 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle RemoveBookmarkInputAction; // 0x570 (Size: 0x10, Type: StructProperty)
    bool IsCalendarScrollableForTouch; // 0x580 (Size: 0x1, Type: BoolProperty)
    bool IsTournamentCarouselSwiped; // 0x581 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_582[0x6]; // 0x582 (Size: 0x6, Type: PaddingProperty)
    FDataTableRowHandle TodayInputAction; // 0x588 (Size: 0x10, Type: StructProperty)
    int32_t PreviouslySelectedCalendarTileIndex; // 0x598 (Size: 0x4, Type: IntProperty)
    bool IsLoadingTournaments; // 0x59c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59d[0x3]; // 0x59d (Size: 0x3, Type: PaddingProperty)
    uint8_t OnMonthJustGenerated[0x10]; // 0x5a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void AdjustColorLuminance(FLinearColor& In_Color, FLinearColor& Out_Color); // 0x288a61c (Index: 0x10, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SequenceEvent__ENTRYPOINTWBP_Calendar(); // 0x288a61c (Index: 0x12, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SelectCurrentDateTournament(); // 0x288a61c (Index: 0x13, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x1a, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void PlayBackgroundTransition(FLinearColor& NextColor1, FLinearColor& NextColor2); // 0x288a61c (Index: 0x1b, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual FEventReply OnMouseWheel(FGeometry& MyGeometry, const FPointerEvent MouseEvent); // 0x288a61c (Index: 0x1f, Flags: BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnMonthJustGenerated__DelegateSignature(); // 0x288a61c (Index: 0x20, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void On_Select_Calendar_Tile(UCommonButtonBase*& Button, bool& B_Is_Selected); // 0x288a61c (Index: 0x21, Flags: Public|BlueprintCallable|BlueprintEvent)
    UWidget* Navigation_FocusToCalendarTile(EUINavigation& Navigation); // 0x288a61c (Index: 0x22, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    UWidget* Navigation_DoCustom(EUINavigation& Navigation); // 0x288a61c (Index: 0x23, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void LerpBackgroundColor(); // 0x288a61c (Index: 0x24, Flags: Public|BlueprintCallable|BlueprintEvent)
    void InputMethodChanged(ECommonInputType& InputType); // 0x288a61c (Index: 0x26, Flags: Public|BlueprintCallable|BlueprintEvent)
    UWidget* HideCalendar(bool& B_Instant_Animations); // 0x288a61c (Index: 0x27, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void GenerateTournaments(FTournamentsTilesData& Tournaments); // 0x288a61c (Index: 0x2a, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnCalendarTileClicked(UCommonButtonBase*& Button); // 0x288a61c (Index: 0x2b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GenerateMonth(FCalendarTilesData& TilesData); // 0x288a61c (Index: 0x2c, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void DayOfWeek(FDateTime& Date, int32_t& 0_6, FText& Day); // 0x288a61c (Index: 0x2e, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x2f, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void UpdateSelectedTileFromScrollOffset(double& ScrollOffset); // 0x288a61c (Index: 0x34, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateIsOpened(bool& IsOpened); // 0x288a61c (Index: 0x35, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateBookmarkButtonEnabled(); // 0x288a61c (Index: 0x36, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    UWidget* ShowCalendar(); // 0x288a61c (Index: 0x37, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetTodayButton(); // 0x288a61c (Index: 0x38, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetTilesState(); // 0x288a61c (Index: 0x39, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetMobileStyle(); // 0x288a61c (Index: 0x3a, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetMobileMonthHeight(bool& IsCalendarShown); // 0x288a61c (Index: 0x3b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFortPoblanoTournamentsCalendarVM(UFortPoblanoTournamentsCalendarVM*& ViewModel); // 0x288a61c (Index: 0x3c, Flags: Final|Public|BlueprintCallable|BlueprintEvent)

private:
    void Set_Month_Text(); // 0x288a61c (Index: 0x11, Flags: Private|HasDefaults|BlueprintCallable|BlueprintEvent)
    void ScrollToCalendarTile(const FDateTime New_Date); // 0x288a61c (Index: 0x14, Flags: Private|HasOutParms|BlueprintCallable|BlueprintEvent)
    void Scroll_to_Tournament_Tile(UFortPoblanoTournamentsCalendarTournamentTileVM*& In_Tournament_Tile); // 0x288a61c (Index: 0x15, Flags: Private|BlueprintCallable|BlueprintEvent)
    void Scroll_to_Selected_Tournament_In_Carousel(); // 0x288a61c (Index: 0x16, Flags: Private|BlueprintCallable|BlueprintEvent)
    void RestoreCalendarFocusAfterProcessingFilter(); // 0x288a61c (Index: 0x18, Flags: Private|BlueprintCallable|BlueprintEvent)
    void RefocusCalendarIfDirtyFilter(); // 0x288a61c (Index: 0x19, Flags: Private|BlueprintCallable|BlueprintEvent)
    void Is_Displaying_Month(const FDateTime In_Date, bool& B_Is_Displaying_Current_Month); // 0x288a61c (Index: 0x25, Flags: Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void Get_Selected_Tournament_Date(FDateTime& Date) const; // 0x288a61c (Index: 0x29, Flags: Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)

protected:
    virtual void BP_OnActivated(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual UWidget* BP_GetDesiredFocusTarget() const; // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
    virtual void BP_OnDeactivated(); // 0x288a61c (Index: 0x31, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_Calendar_C) == 0x5b0, "Size mismatch for UWBP_Calendar_C");
static_assert(offsetof(UWBP_Calendar_C, UberGraphFrame) == 0x408, "Offset mismatch for UWBP_Calendar_C::UberGraphFrame");
static_assert(offsetof(UWBP_Calendar_C, WBP_TournamentsCarousel) == 0x410, "Offset mismatch for UWBP_Calendar_C::WBP_TournamentsCarousel");
static_assert(offsetof(UWBP_Calendar_C, VertBox_MobileCalendarContainer) == 0x418, "Offset mismatch for UWBP_Calendar_C::VertBox_MobileCalendarContainer");
static_assert(offsetof(UWBP_Calendar_C, UniformGridPanel) == 0x420, "Offset mismatch for UWBP_Calendar_C::UniformGridPanel");
static_assert(offsetof(UWBP_Calendar_C, TournamentsStateVisibilitySwitcher) == 0x428, "Offset mismatch for UWBP_Calendar_C::TournamentsStateVisibilitySwitcher");
static_assert(offsetof(UWBP_Calendar_C, SwipePanel) == 0x430, "Offset mismatch for UWBP_Calendar_C::SwipePanel");
static_assert(offsetof(UWBP_Calendar_C, SizeBox_Month) == 0x438, "Offset mismatch for UWBP_Calendar_C::SizeBox_Month");
static_assert(offsetof(UWBP_Calendar_C, SizeBox) == 0x440, "Offset mismatch for UWBP_Calendar_C::SizeBox");
static_assert(offsetof(UWBP_Calendar_C, ScrollBox_Month) == 0x448, "Offset mismatch for UWBP_Calendar_C::ScrollBox_Month");
static_assert(offsetof(UWBP_Calendar_C, SafeZone) == 0x450, "Offset mismatch for UWBP_Calendar_C::SafeZone");
static_assert(offsetof(UWBP_Calendar_C, PreviousButton) == 0x458, "Offset mismatch for UWBP_Calendar_C::PreviousButton");
static_assert(offsetof(UWBP_Calendar_C, NextButton) == 0x460, "Offset mismatch for UWBP_Calendar_C::NextButton");
static_assert(offsetof(UWBP_Calendar_C, NavigationButtons) == 0x468, "Offset mismatch for UWBP_Calendar_C::NavigationButtons");
static_assert(offsetof(UWBP_Calendar_C, IconHintsPanel) == 0x470, "Offset mismatch for UWBP_Calendar_C::IconHintsPanel");
static_assert(offsetof(UWBP_Calendar_C, FilterButton) == 0x478, "Offset mismatch for UWBP_Calendar_C::FilterButton");
static_assert(offsetof(UWBP_Calendar_C, DecoyButton_Today) == 0x480, "Offset mismatch for UWBP_Calendar_C::DecoyButton_Today");
static_assert(offsetof(UWBP_Calendar_C, DecoyButton_FirstUpcoming) == 0x488, "Offset mismatch for UWBP_Calendar_C::DecoyButton_FirstUpcoming");
static_assert(offsetof(UWBP_Calendar_C, DecoyButton_Bookmark) == 0x490, "Offset mismatch for UWBP_Calendar_C::DecoyButton_Bookmark");
static_assert(offsetof(UWBP_Calendar_C, DecoyButton_Back) == 0x498, "Offset mismatch for UWBP_Calendar_C::DecoyButton_Back");
static_assert(offsetof(UWBP_Calendar_C, Days) == 0x4a0, "Offset mismatch for UWBP_Calendar_C::Days");
static_assert(offsetof(UWBP_Calendar_C, CaptureForPostBufferUpdate) == 0x4a8, "Offset mismatch for UWBP_Calendar_C::CaptureForPostBufferUpdate");
static_assert(offsetof(UWBP_Calendar_C, CalendarWrapper) == 0x4b0, "Offset mismatch for UWBP_Calendar_C::CalendarWrapper");
static_assert(offsetof(UWBP_Calendar_C, Background) == 0x4b8, "Offset mismatch for UWBP_Calendar_C::Background");
static_assert(offsetof(UWBP_Calendar_C, Anim_OpenCalendar) == 0x4c0, "Offset mismatch for UWBP_Calendar_C::Anim_OpenCalendar");
static_assert(offsetof(UWBP_Calendar_C, Anim_BackgroundColor) == 0x4c8, "Offset mismatch for UWBP_Calendar_C::Anim_BackgroundColor");
static_assert(offsetof(UWBP_Calendar_C, FortPoblanoTournamentsCalendarVM) == 0x4d0, "Offset mismatch for UWBP_Calendar_C::FortPoblanoTournamentsCalendarVM");
static_assert(offsetof(UWBP_Calendar_C, CalendarDayTilesArray) == 0x4d8, "Offset mismatch for UWBP_Calendar_C::CalendarDayTilesArray");
static_assert(offsetof(UWBP_Calendar_C, Selected_Calendar_Tile) == 0x4e8, "Offset mismatch for UWBP_Calendar_C::Selected_Calendar_Tile");
static_assert(offsetof(UWBP_Calendar_C, IsCalendarOpened) == 0x4f0, "Offset mismatch for UWBP_Calendar_C::IsCalendarOpened");
static_assert(offsetof(UWBP_Calendar_C, Selected_Tournament_Tile) == 0x4f4, "Offset mismatch for UWBP_Calendar_C::Selected_Tournament_Tile");
static_assert(offsetof(UWBP_Calendar_C, MID_Background) == 0x4f8, "Offset mismatch for UWBP_Calendar_C::MID_Background");
static_assert(offsetof(UWBP_Calendar_C, NextColor1) == 0x500, "Offset mismatch for UWBP_Calendar_C::NextColor1");
static_assert(offsetof(UWBP_Calendar_C, TournamentTilesArray) == 0x510, "Offset mismatch for UWBP_Calendar_C::TournamentTilesArray");
static_assert(offsetof(UWBP_Calendar_C, NextColor2) == 0x520, "Offset mismatch for UWBP_Calendar_C::NextColor2");
static_assert(offsetof(UWBP_Calendar_C, B_Has_Init_Months) == 0x530, "Offset mismatch for UWBP_Calendar_C::B_Has_Init_Months");
static_assert(offsetof(UWBP_Calendar_C, Max_Color_Luminance) == 0x538, "Offset mismatch for UWBP_Calendar_C::Max_Color_Luminance");
static_assert(offsetof(UWBP_Calendar_C, FirstItem) == 0x540, "Offset mismatch for UWBP_Calendar_C::FirstItem");
static_assert(offsetof(UWBP_Calendar_C, LastItem) == 0x548, "Offset mismatch for UWBP_Calendar_C::LastItem");
static_assert(offsetof(UWBP_Calendar_C, Input_Type) == 0x550, "Offset mismatch for UWBP_Calendar_C::Input_Type");
static_assert(offsetof(UWBP_Calendar_C, CurrentSelectedTileVM) == 0x558, "Offset mismatch for UWBP_Calendar_C::CurrentSelectedTileVM");
static_assert(offsetof(UWBP_Calendar_C, AddBookmarkInputAction) == 0x560, "Offset mismatch for UWBP_Calendar_C::AddBookmarkInputAction");
static_assert(offsetof(UWBP_Calendar_C, RemoveBookmarkInputAction) == 0x570, "Offset mismatch for UWBP_Calendar_C::RemoveBookmarkInputAction");
static_assert(offsetof(UWBP_Calendar_C, IsCalendarScrollableForTouch) == 0x580, "Offset mismatch for UWBP_Calendar_C::IsCalendarScrollableForTouch");
static_assert(offsetof(UWBP_Calendar_C, IsTournamentCarouselSwiped) == 0x581, "Offset mismatch for UWBP_Calendar_C::IsTournamentCarouselSwiped");
static_assert(offsetof(UWBP_Calendar_C, TodayInputAction) == 0x588, "Offset mismatch for UWBP_Calendar_C::TodayInputAction");
static_assert(offsetof(UWBP_Calendar_C, PreviouslySelectedCalendarTileIndex) == 0x598, "Offset mismatch for UWBP_Calendar_C::PreviouslySelectedCalendarTileIndex");
static_assert(offsetof(UWBP_Calendar_C, IsLoadingTournaments) == 0x59c, "Offset mismatch for UWBP_Calendar_C::IsLoadingTournaments");
static_assert(offsetof(UWBP_Calendar_C, OnMonthJustGenerated) == 0x5a0, "Offset mismatch for UWBP_Calendar_C::OnMonthJustGenerated");

// Size: 0x2f0 (Inherited: 0xa10, Single: 0xfffff8e0)
class UWBP_TournamentsCarousel_C : public UFortPolymorphicListView
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2e0 (Size: 0x8, Type: StructProperty)
    UFortPoblanoTournamentsCarouselVM* FortPoblanoTournamentsCarouselVM; // 0x2e8 (Size: 0x8, Type: ObjectProperty)

public:
    void OnTournamentDetailsScreenParamsChanged(FTournamentDetailsScreenParams& DetailsScreenParams); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual bool GetItemSelectableOrNavigable(UObject*& Item) const; // 0x288a61c (Index: 0x2, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
    virtual UClass* GetDesiredEntryClassForItem(UObject*& Item) const; // 0x288a61c (Index: 0x3, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
    virtual void Destruct(); // 0x288a61c (Index: 0x5, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x6, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UWBP_TournamentsCarousel_C) == 0x2f0, "Size mismatch for UWBP_TournamentsCarousel_C");
static_assert(offsetof(UWBP_TournamentsCarousel_C, UberGraphFrame) == 0x2e0, "Offset mismatch for UWBP_TournamentsCarousel_C::UberGraphFrame");
static_assert(offsetof(UWBP_TournamentsCarousel_C, FortPoblanoTournamentsCarouselVM) == 0x2e8, "Offset mismatch for UWBP_TournamentsCarousel_C::FortPoblanoTournamentsCarouselVM");

// Size: 0x1888 (Inherited: 0x6174, Single: 0xffffb714)
class UWBP_FilterButton_C : public UWBP_UIKit_Button_Generic_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x1880 (Size: 0x8, Type: StructProperty)

public:
    void Update_Filter_Info(); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Set_Button_Design(); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x2, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UWBP_FilterButton_C) == 0x1888, "Size mismatch for UWBP_FilterButton_C");
static_assert(offsetof(UWBP_FilterButton_C, UberGraphFrame) == 0x1880, "Offset mismatch for UWBP_FilterButton_C::UberGraphFrame");

// Size: 0x341 (Inherited: 0xa24, Single: 0xfffff91d)
class UWBP_Compete_Block_Image_C : public UWBP_UIKit_Block_Base_C
{
public:
    uint8_t Pad_2ec[0x4]; // 0x2ec (Size: 0x4, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0x2f0 (Size: 0x8, Type: StructProperty)
    UFortMobileImage* Image; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Focused_Transition; // 0x300 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Disabled_Transition; // 0x308 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Selected_Transition; // 0x310 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_SelectedFocused_Transition; // 0x318 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_SelectedDisabled_Transition; // 0x320 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Outline_Transition; // 0x328 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstance* ImageMaterial; // 0x330 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* ImageMID; // 0x338 (Size: 0x8, Type: ObjectProperty)
    bool Is_Marked; // 0x340 (Size: 0x1, Type: BoolProperty)

public:
    void SetTextureWithParameter(FName& ParameterName, const UTexture2D* InTexture); // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetTexture(const UTexture2D* InTexture); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetSize(FVector2D& Desired_Size); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetMaterial(const UMaterialInstance* InMaterial); // 0x288a61c (Index: 0x3, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetMarked(bool& IsMarked); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetBrush(const FSlateBrush InBrush); // 0x288a61c (Index: 0x5, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)

protected:
    void RefreshImageMID(); // 0x288a61c (Index: 0x6, Flags: Protected|BlueprintCallable|BlueprintEvent)
    virtual void OnTransitionUnfocusedRequested(); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionSelectedRequested(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionFocusedRequested(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionEnabledRequested(); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionDisabledRequested(); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionDeselectedIdleRequested(); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionDeselectedFocusedRequested(); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void OnInstantTransitionToSelected(); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void OnInstantTransitionToEnabled(); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void OnInstantTransitionToDisabled(); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_Compete_Block_Image_C) == 0x341, "Size mismatch for UWBP_Compete_Block_Image_C");
static_assert(offsetof(UWBP_Compete_Block_Image_C, UberGraphFrame) == 0x2f0, "Offset mismatch for UWBP_Compete_Block_Image_C::UberGraphFrame");
static_assert(offsetof(UWBP_Compete_Block_Image_C, Image) == 0x2f8, "Offset mismatch for UWBP_Compete_Block_Image_C::Image");
static_assert(offsetof(UWBP_Compete_Block_Image_C, Anim_Focused_Transition) == 0x300, "Offset mismatch for UWBP_Compete_Block_Image_C::Anim_Focused_Transition");
static_assert(offsetof(UWBP_Compete_Block_Image_C, Anim_Disabled_Transition) == 0x308, "Offset mismatch for UWBP_Compete_Block_Image_C::Anim_Disabled_Transition");
static_assert(offsetof(UWBP_Compete_Block_Image_C, Anim_Selected_Transition) == 0x310, "Offset mismatch for UWBP_Compete_Block_Image_C::Anim_Selected_Transition");
static_assert(offsetof(UWBP_Compete_Block_Image_C, Anim_SelectedFocused_Transition) == 0x318, "Offset mismatch for UWBP_Compete_Block_Image_C::Anim_SelectedFocused_Transition");
static_assert(offsetof(UWBP_Compete_Block_Image_C, Anim_SelectedDisabled_Transition) == 0x320, "Offset mismatch for UWBP_Compete_Block_Image_C::Anim_SelectedDisabled_Transition");
static_assert(offsetof(UWBP_Compete_Block_Image_C, Anim_Outline_Transition) == 0x328, "Offset mismatch for UWBP_Compete_Block_Image_C::Anim_Outline_Transition");
static_assert(offsetof(UWBP_Compete_Block_Image_C, ImageMaterial) == 0x330, "Offset mismatch for UWBP_Compete_Block_Image_C::ImageMaterial");
static_assert(offsetof(UWBP_Compete_Block_Image_C, ImageMID) == 0x338, "Offset mismatch for UWBP_Compete_Block_Image_C::ImageMID");
static_assert(offsetof(UWBP_Compete_Block_Image_C, Is_Marked) == 0x340, "Offset mismatch for UWBP_Compete_Block_Image_C::Is_Marked");

// Size: 0x2e0 (Inherited: 0x730, Single: 0xfffffbb0)
class UWBP_EmptyTile_Entry_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2d8 (Size: 0x8, Type: StructProperty)

protected:
    virtual void BP_OnEntryReleased(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnListItemObjectSet(UObject*& ListItemObject); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnItemSelectionChanged(bool& bIsSelected); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnItemExpansionChanged(bool& bIsExpanded); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_EmptyTile_Entry_C) == 0x2e0, "Size mismatch for UWBP_EmptyTile_Entry_C");
static_assert(offsetof(UWBP_EmptyTile_Entry_C, UberGraphFrame) == 0x2d8, "Offset mismatch for UWBP_EmptyTile_Entry_C::UberGraphFrame");

// Size: 0x320 (Inherited: 0x730, Single: 0xfffffbf0)
class UWBP_IconHintsPanel_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2d8 (Size: 0x8, Type: StructProperty)
    UWBP_IconHint_C* VictoryHint; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UWBP_IconHint_C* RanckedHint; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UWBP_IconHint_C* OtherHint; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UWBP_IconHint_C* ItemShopHint; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Background; // 0x300 (Size: 0x8, Type: ObjectProperty)
    UWBP_IconHint_C* FNCSHint; // 0x308 (Size: 0x8, Type: ObjectProperty)
    UWBP_IconHint_C* CashHint; // 0x310 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Scrim_C* BackgroundBlur; // 0x318 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UWBP_IconHintsPanel_C) == 0x320, "Size mismatch for UWBP_IconHintsPanel_C");
static_assert(offsetof(UWBP_IconHintsPanel_C, UberGraphFrame) == 0x2d8, "Offset mismatch for UWBP_IconHintsPanel_C::UberGraphFrame");
static_assert(offsetof(UWBP_IconHintsPanel_C, VictoryHint) == 0x2e0, "Offset mismatch for UWBP_IconHintsPanel_C::VictoryHint");
static_assert(offsetof(UWBP_IconHintsPanel_C, RanckedHint) == 0x2e8, "Offset mismatch for UWBP_IconHintsPanel_C::RanckedHint");
static_assert(offsetof(UWBP_IconHintsPanel_C, OtherHint) == 0x2f0, "Offset mismatch for UWBP_IconHintsPanel_C::OtherHint");
static_assert(offsetof(UWBP_IconHintsPanel_C, ItemShopHint) == 0x2f8, "Offset mismatch for UWBP_IconHintsPanel_C::ItemShopHint");
static_assert(offsetof(UWBP_IconHintsPanel_C, Image_Background) == 0x300, "Offset mismatch for UWBP_IconHintsPanel_C::Image_Background");
static_assert(offsetof(UWBP_IconHintsPanel_C, FNCSHint) == 0x308, "Offset mismatch for UWBP_IconHintsPanel_C::FNCSHint");
static_assert(offsetof(UWBP_IconHintsPanel_C, CashHint) == 0x310, "Offset mismatch for UWBP_IconHintsPanel_C::CashHint");
static_assert(offsetof(UWBP_IconHintsPanel_C, BackgroundBlur) == 0x318, "Offset mismatch for UWBP_IconHintsPanel_C::BackgroundBlur");

// Size: 0x320 (Inherited: 0x730, Single: 0xfffffbf0)
class UWBP_CalendarWrapper_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2d8 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_Month; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Generic_C* PreviousButton; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Generic_C* NextButton; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_ShowButtons; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnClickedPreviousButton[0x10]; // 0x300 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnClickedNextButton[0x10]; // 0x310 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void UpdateButtonsByInputType(ECommonInputType& InputType); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetText(FText& InText); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetMobileStyle(); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x3, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void PlayButtonAnimation(bool& IsShow); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void OnClickedPreviousButton__DelegateSignature(); // 0x288a61c (Index: 0x5, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnClickedNextButton__DelegateSignature(); // 0x288a61c (Index: 0x6, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)

private:
    void GetNextButtonDefaultColumn(int32_t& Column); // 0x288a61c (Index: 0x7, Flags: Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
};

static_assert(sizeof(UWBP_CalendarWrapper_C) == 0x320, "Size mismatch for UWBP_CalendarWrapper_C");
static_assert(offsetof(UWBP_CalendarWrapper_C, UberGraphFrame) == 0x2d8, "Offset mismatch for UWBP_CalendarWrapper_C::UberGraphFrame");
static_assert(offsetof(UWBP_CalendarWrapper_C, Text_Month) == 0x2e0, "Offset mismatch for UWBP_CalendarWrapper_C::Text_Month");
static_assert(offsetof(UWBP_CalendarWrapper_C, PreviousButton) == 0x2e8, "Offset mismatch for UWBP_CalendarWrapper_C::PreviousButton");
static_assert(offsetof(UWBP_CalendarWrapper_C, NextButton) == 0x2f0, "Offset mismatch for UWBP_CalendarWrapper_C::NextButton");
static_assert(offsetof(UWBP_CalendarWrapper_C, Anim_ShowButtons) == 0x2f8, "Offset mismatch for UWBP_CalendarWrapper_C::Anim_ShowButtons");
static_assert(offsetof(UWBP_CalendarWrapper_C, OnClickedPreviousButton) == 0x300, "Offset mismatch for UWBP_CalendarWrapper_C::OnClickedPreviousButton");
static_assert(offsetof(UWBP_CalendarWrapper_C, OnClickedNextButton) == 0x310, "Offset mismatch for UWBP_CalendarWrapper_C::OnClickedNextButton");

// Size: 0x308 (Inherited: 0x730, Single: 0xfffffbd8)
class UWBP_IconHint_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2d8 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* NameExplanation; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Explanation; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* IconMaterial; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    FText Name; // 0x2f8 (Size: 0x10, Type: TextProperty)

public:
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x0, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UWBP_IconHint_C) == 0x308, "Size mismatch for UWBP_IconHint_C");
static_assert(offsetof(UWBP_IconHint_C, UberGraphFrame) == 0x2d8, "Offset mismatch for UWBP_IconHint_C::UberGraphFrame");
static_assert(offsetof(UWBP_IconHint_C, NameExplanation) == 0x2e0, "Offset mismatch for UWBP_IconHint_C::NameExplanation");
static_assert(offsetof(UWBP_IconHint_C, Image_Explanation) == 0x2e8, "Offset mismatch for UWBP_IconHint_C::Image_Explanation");
static_assert(offsetof(UWBP_IconHint_C, IconMaterial) == 0x2f0, "Offset mismatch for UWBP_IconHint_C::IconMaterial");
static_assert(offsetof(UWBP_IconHint_C, Name) == 0x2f8, "Offset mismatch for UWBP_IconHint_C::Name");

// Size: 0x16da (Inherited: 0x4598, Single: 0xffffd142)
class UWBP_CalendarTile_C : public UWBP_CompeteTileButton_Base_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x1508 (Size: 0x8, Type: StructProperty)
    UGridPanel* TournamentIcons; // 0x1510 (Size: 0x8, Type: ObjectProperty)
    UImage* TotalTournamentsIcon; // 0x1518 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Date; // 0x1520 (Size: 0x8, Type: ObjectProperty)
    UStackBox* Stack_TotalTournaments; // 0x1528 (Size: 0x8, Type: ObjectProperty)
    UCommonBorder* SelectionOutline; // 0x1530 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* Root; // 0x1538 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_Tournaments; // 0x1540 (Size: 0x8, Type: ObjectProperty)
    UImage* Fade; // 0x1548 (Size: 0x8, Type: ObjectProperty)
    UUEFN_TextBlock_C* DebugTxt; // 0x1550 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Date; // 0x1558 (Size: 0x8, Type: ObjectProperty)
    UImage* Bookmarked; // 0x1560 (Size: 0x8, Type: ObjectProperty)
    UWBP_Compete_Block_Image_C* Block_VictoryIcon; // 0x1568 (Size: 0x8, Type: ObjectProperty)
    UWBP_Compete_Block_Image_C* Block_RankedIcon; // 0x1570 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Block_Outline_C* Block_Outline; // 0x1578 (Size: 0x8, Type: ObjectProperty)
    UWBP_Compete_Block_Image_C* Block_OthersIcon; // 0x1580 (Size: 0x8, Type: ObjectProperty)
    UWBP_Compete_Block_Image_C* Block_ItemShopIcon; // 0x1588 (Size: 0x8, Type: ObjectProperty)
    UWBP_Compete_Block_Image_C* Block_FNCSIcon; // 0x1590 (Size: 0x8, Type: ObjectProperty)
    UWBP_Compete_Block_Image_C* Block_CashIcon; // 0x1598 (Size: 0x8, Type: ObjectProperty)
    UImage* Background_Date; // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    UImage* Background; // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    UCommonVisualAttachment* AttachmentBookmarked; // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_ShowTournamentIcons; // 0x15b8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Locked; // 0x15c0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Selected; // 0x15c8 (Size: 0x8, Type: ObjectProperty)
    UFortPoblanoTournamentsCalendarDayTileVM* FortPoblanoTournamentsCalendarDayTileVM; // 0x15d0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstance* Material_Cups; // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstance* Material_TotalTournaments; // 0x15e0 (Size: 0x8, Type: ObjectProperty)
    FSlateFontInfo Font_TotalTournaments; // 0x15e8 (Size: 0x58, Type: StructProperty)
    FSlateFontInfo Font_Date; // 0x1640 (Size: 0x58, Type: StructProperty)
    UMaterialInstance* BackgroundMaterial; // 0x1698 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstance* Material_FontDateToday; // 0x16a0 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* Cash_Texture; // 0x16a8 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* FNCS_Texture; // 0x16b0 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* ItemShop_Texture; // 0x16b8 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* Victory_Texture; // 0x16c0 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* Others_Texture; // 0x16c8 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* Ranked_Texture; // 0x16d0 (Size: 0x8, Type: ObjectProperty)
    bool FakeLockedState; // 0x16d8 (Size: 0x1, Type: BoolProperty)
    bool IsCalendarOpened; // 0x16d9 (Size: 0x1, Type: BoolProperty)

public:
    void SetTileTimeState(ECupTimeZoneStyle& TimeZone); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetRenderOpacityForNonModuarBlockElements(float& InOpacity); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetHasAnyBookmarks(bool& IsBookmarked); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFortPoblanoTournamentsCalendarDayTileVM(UFortPoblanoTournamentsCalendarDayTileVM*& ViewModel); // 0x288a61c (Index: 0x3, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void SetDate(int32_t& Amount); // 0x288a61c (Index: 0x4, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetAsToday(); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void RefreshTotalBookmarked(int32_t& Amount); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void RefreshAmountTournaments(); // 0x288a61c (Index: 0x7, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x8, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void PlayTransitionShowIcons(TEnumAsByte<EUMGSequencePlayMode>& PlayMode, bool& Instant); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateVictoryCupsState(ECupState& State); // 0x288a61c (Index: 0x17, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateShopsCupsState(ECupState& State); // 0x288a61c (Index: 0x18, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateRankedCupsState(ECupState& State); // 0x288a61c (Index: 0x19, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateOtherCupsState(ECupState& State); // 0x288a61c (Index: 0x1a, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateIconFNCSState(ECupState& State); // 0x288a61c (Index: 0x1b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateCupImageColorByState(ECupState& State, UWBP_Compete_Block_Image_C*& BlockImage); // 0x288a61c (Index: 0x1c, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateCashCupsState(ECupState& State); // 0x288a61c (Index: 0x1d, Flags: Public|BlueprintCallable|BlueprintEvent)
    void TotalTournaments(int32_t& Amount); // 0x288a61c (Index: 0x1e, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ShouldFocusOnSelected(bool& ShouldFocus); // 0x288a61c (Index: 0x1f, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)

private:
    void InitTournamentBlockIcon(UWBP_Compete_Block_Image_C*& BlockImage, const UTexture2D* Texture); // 0x288a61c (Index: 0xb, Flags: Private|HasOutParms|BlueprintCallable|BlueprintEvent)
    void InitTile(); // 0x288a61c (Index: 0xc, Flags: Private|HasDefaults|BlueprintCallable|BlueprintEvent)
    void DebugCalendarTileInstance(); // 0x288a61c (Index: 0xe, Flags: Private|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnListItemObjectSet(UObject*& ListItemObject); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnSelected(); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnItemSelectionChanged(bool& bIsSelected); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnItemExpansionChanged(bool& bIsExpanded); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnFocusReceived(); // 0x288a61c (Index: 0x12, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnFocusLost(); // 0x288a61c (Index: 0x13, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnEntryReleased(); // 0x288a61c (Index: 0x14, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDeselected(); // 0x288a61c (Index: 0x15, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnClicked(); // 0x288a61c (Index: 0x16, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_CalendarTile_C) == 0x16da, "Size mismatch for UWBP_CalendarTile_C");
static_assert(offsetof(UWBP_CalendarTile_C, UberGraphFrame) == 0x1508, "Offset mismatch for UWBP_CalendarTile_C::UberGraphFrame");
static_assert(offsetof(UWBP_CalendarTile_C, TournamentIcons) == 0x1510, "Offset mismatch for UWBP_CalendarTile_C::TournamentIcons");
static_assert(offsetof(UWBP_CalendarTile_C, TotalTournamentsIcon) == 0x1518, "Offset mismatch for UWBP_CalendarTile_C::TotalTournamentsIcon");
static_assert(offsetof(UWBP_CalendarTile_C, Text_Date) == 0x1520, "Offset mismatch for UWBP_CalendarTile_C::Text_Date");
static_assert(offsetof(UWBP_CalendarTile_C, Stack_TotalTournaments) == 0x1528, "Offset mismatch for UWBP_CalendarTile_C::Stack_TotalTournaments");
static_assert(offsetof(UWBP_CalendarTile_C, SelectionOutline) == 0x1530, "Offset mismatch for UWBP_CalendarTile_C::SelectionOutline");
static_assert(offsetof(UWBP_CalendarTile_C, Root) == 0x1538, "Offset mismatch for UWBP_CalendarTile_C::Root");
static_assert(offsetof(UWBP_CalendarTile_C, RichText_Tournaments) == 0x1540, "Offset mismatch for UWBP_CalendarTile_C::RichText_Tournaments");
static_assert(offsetof(UWBP_CalendarTile_C, Fade) == 0x1548, "Offset mismatch for UWBP_CalendarTile_C::Fade");
static_assert(offsetof(UWBP_CalendarTile_C, DebugTxt) == 0x1550, "Offset mismatch for UWBP_CalendarTile_C::DebugTxt");
static_assert(offsetof(UWBP_CalendarTile_C, Date) == 0x1558, "Offset mismatch for UWBP_CalendarTile_C::Date");
static_assert(offsetof(UWBP_CalendarTile_C, Bookmarked) == 0x1560, "Offset mismatch for UWBP_CalendarTile_C::Bookmarked");
static_assert(offsetof(UWBP_CalendarTile_C, Block_VictoryIcon) == 0x1568, "Offset mismatch for UWBP_CalendarTile_C::Block_VictoryIcon");
static_assert(offsetof(UWBP_CalendarTile_C, Block_RankedIcon) == 0x1570, "Offset mismatch for UWBP_CalendarTile_C::Block_RankedIcon");
static_assert(offsetof(UWBP_CalendarTile_C, Block_Outline) == 0x1578, "Offset mismatch for UWBP_CalendarTile_C::Block_Outline");
static_assert(offsetof(UWBP_CalendarTile_C, Block_OthersIcon) == 0x1580, "Offset mismatch for UWBP_CalendarTile_C::Block_OthersIcon");
static_assert(offsetof(UWBP_CalendarTile_C, Block_ItemShopIcon) == 0x1588, "Offset mismatch for UWBP_CalendarTile_C::Block_ItemShopIcon");
static_assert(offsetof(UWBP_CalendarTile_C, Block_FNCSIcon) == 0x1590, "Offset mismatch for UWBP_CalendarTile_C::Block_FNCSIcon");
static_assert(offsetof(UWBP_CalendarTile_C, Block_CashIcon) == 0x1598, "Offset mismatch for UWBP_CalendarTile_C::Block_CashIcon");
static_assert(offsetof(UWBP_CalendarTile_C, Background_Date) == 0x15a0, "Offset mismatch for UWBP_CalendarTile_C::Background_Date");
static_assert(offsetof(UWBP_CalendarTile_C, Background) == 0x15a8, "Offset mismatch for UWBP_CalendarTile_C::Background");
static_assert(offsetof(UWBP_CalendarTile_C, AttachmentBookmarked) == 0x15b0, "Offset mismatch for UWBP_CalendarTile_C::AttachmentBookmarked");
static_assert(offsetof(UWBP_CalendarTile_C, Anim_ShowTournamentIcons) == 0x15b8, "Offset mismatch for UWBP_CalendarTile_C::Anim_ShowTournamentIcons");
static_assert(offsetof(UWBP_CalendarTile_C, Anim_Locked) == 0x15c0, "Offset mismatch for UWBP_CalendarTile_C::Anim_Locked");
static_assert(offsetof(UWBP_CalendarTile_C, Anim_Selected) == 0x15c8, "Offset mismatch for UWBP_CalendarTile_C::Anim_Selected");
static_assert(offsetof(UWBP_CalendarTile_C, FortPoblanoTournamentsCalendarDayTileVM) == 0x15d0, "Offset mismatch for UWBP_CalendarTile_C::FortPoblanoTournamentsCalendarDayTileVM");
static_assert(offsetof(UWBP_CalendarTile_C, Material_Cups) == 0x15d8, "Offset mismatch for UWBP_CalendarTile_C::Material_Cups");
static_assert(offsetof(UWBP_CalendarTile_C, Material_TotalTournaments) == 0x15e0, "Offset mismatch for UWBP_CalendarTile_C::Material_TotalTournaments");
static_assert(offsetof(UWBP_CalendarTile_C, Font_TotalTournaments) == 0x15e8, "Offset mismatch for UWBP_CalendarTile_C::Font_TotalTournaments");
static_assert(offsetof(UWBP_CalendarTile_C, Font_Date) == 0x1640, "Offset mismatch for UWBP_CalendarTile_C::Font_Date");
static_assert(offsetof(UWBP_CalendarTile_C, BackgroundMaterial) == 0x1698, "Offset mismatch for UWBP_CalendarTile_C::BackgroundMaterial");
static_assert(offsetof(UWBP_CalendarTile_C, Material_FontDateToday) == 0x16a0, "Offset mismatch for UWBP_CalendarTile_C::Material_FontDateToday");
static_assert(offsetof(UWBP_CalendarTile_C, Cash_Texture) == 0x16a8, "Offset mismatch for UWBP_CalendarTile_C::Cash_Texture");
static_assert(offsetof(UWBP_CalendarTile_C, FNCS_Texture) == 0x16b0, "Offset mismatch for UWBP_CalendarTile_C::FNCS_Texture");
static_assert(offsetof(UWBP_CalendarTile_C, ItemShop_Texture) == 0x16b8, "Offset mismatch for UWBP_CalendarTile_C::ItemShop_Texture");
static_assert(offsetof(UWBP_CalendarTile_C, Victory_Texture) == 0x16c0, "Offset mismatch for UWBP_CalendarTile_C::Victory_Texture");
static_assert(offsetof(UWBP_CalendarTile_C, Others_Texture) == 0x16c8, "Offset mismatch for UWBP_CalendarTile_C::Others_Texture");
static_assert(offsetof(UWBP_CalendarTile_C, Ranked_Texture) == 0x16d0, "Offset mismatch for UWBP_CalendarTile_C::Ranked_Texture");
static_assert(offsetof(UWBP_CalendarTile_C, FakeLockedState) == 0x16d8, "Offset mismatch for UWBP_CalendarTile_C::FakeLockedState");
static_assert(offsetof(UWBP_CalendarTile_C, IsCalendarOpened) == 0x16d9, "Offset mismatch for UWBP_CalendarTile_C::IsCalendarOpened");

// Size: 0x69 (Inherited: 0x90, Single: 0xffffffd9)
class UMVVM_CompeteEmptyTile_Entry_C : public UMVVMViewModelBase
{
public:
    bool IsSelectable; // 0x68 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(UMVVM_CompeteEmptyTile_Entry_C) == 0x69, "Size mismatch for UMVVM_CompeteEmptyTile_Entry_C");
static_assert(offsetof(UMVVM_CompeteEmptyTile_Entry_C, IsSelectable) == 0x68, "Offset mismatch for UMVVM_CompeteEmptyTile_Entry_C::IsSelectable");

