/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Account
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UExternalAccountProvider : public UObject
{
public:
    TArray<FExternalAccountServiceConfig> Services; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UExternalAccountProvider) == 0x38, "Size mismatch for UExternalAccountProvider");
static_assert(offsetof(UExternalAccountProvider, Services) == 0x28, "Offset mismatch for UExternalAccountProvider::Services");

// Size: 0xb50 (Inherited: 0x28, Single: 0xb28)
class UOnlineAccountCommon : public UObject
{
public:
    uint8_t Pad_28[0x10]; // 0x28 (Size: 0x10, Type: PaddingProperty)
    FString AvailabilityServiceGameName; // 0x38 (Size: 0x10, Type: StrProperty)
    bool bRequireLightswitchAtStartup; // 0x48 (Size: 0x1, Type: BoolProperty)
    bool bPartialLoginEnabled; // 0x49 (Size: 0x1, Type: BoolProperty)
    bool bRedeemOfflinePurchasesEnabled; // 0x4a (Size: 0x1, Type: BoolProperty)
    bool bCheckingRejoinEnabled; // 0x4b (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    FString EULAKey; // 0x50 (Size: 0x10, Type: StrProperty)
    TArray<FString> EulaKeys; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FString> EulaKeyMapping; // 0x70 (Size: 0x50, Type: MapProperty)
    bool bEnableWaitingRoom; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0x7]; // 0xc1 (Size: 0x7, Type: PaddingProperty)
    TArray<FWebEnvUrl> WebCreateEpicAccountUrl; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    bool bAllowLocalLogout; // 0xd8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d9[0x37]; // 0xd9 (Size: 0x37, Type: PaddingProperty)
    float DefaultLoginStepTimeout; // 0x110 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_114[0x4]; // 0x114 (Size: 0x4, Type: PaddingProperty)
    TMap<float, FName> CustomLoginStepTimeouts; // 0x118 (Size: 0x50, Type: MapProperty)
    bool bEnableDevLoginStepTimeouts; // 0x168 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_169[0x3]; // 0x169 (Size: 0x3, Type: PaddingProperty)
    float DefaultLogoutStepTimeout; // 0x16c (Size: 0x4, Type: FloatProperty)
    TMap<float, FName> CustomLogoutStepTimeouts; // 0x170 (Size: 0x50, Type: MapProperty)
    bool bEnableDevLogoutStepTimeouts; // 0x1c0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1c1[0x27]; // 0x1c1 (Size: 0x27, Type: PaddingProperty)
    TArray<FServiceLoginConfig> ServiceLoginConfig; // 0x1e8 (Size: 0x10, Type: ArrayProperty)
    FString RedeemAccessUrl; // 0x1f8 (Size: 0x10, Type: StrProperty)
    FString RequestFreeAccessUrl; // 0x208 (Size: 0x10, Type: StrProperty)
    FString RealGameAccessUrl; // 0x218 (Size: 0x10, Type: StrProperty)
    float SkipRedeemOfflinePurchasesChance; // 0x228 (Size: 0x4, Type: FloatProperty)
    bool bUseFreeAccessInsteadOfGameAccess; // 0x22c (Size: 0x1, Type: BoolProperty)
    bool bShouldGrantFreeAccess; // 0x22d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_22e[0x1]; // 0x22e (Size: 0x1, Type: PaddingProperty)
    bool bAllowHomeSharingAccess; // 0x22f (Size: 0x1, Type: BoolProperty)
    bool bRequireUGCPrivilege; // 0x230 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_231[0x28f]; // 0x231 (Size: 0x28f, Type: PaddingProperty)
    float AccessGrantDelaySeconds; // 0x4c0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4c4[0x4]; // 0x4c4 (Size: 0x4, Type: PaddingProperty)
    UWaitingRoomState* WaitingRoomState; // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_4d0[0x680]; // 0x4d0 (Size: 0x680, Type: PaddingProperty)
};

static_assert(sizeof(UOnlineAccountCommon) == 0xb50, "Size mismatch for UOnlineAccountCommon");
static_assert(offsetof(UOnlineAccountCommon, AvailabilityServiceGameName) == 0x38, "Offset mismatch for UOnlineAccountCommon::AvailabilityServiceGameName");
static_assert(offsetof(UOnlineAccountCommon, bRequireLightswitchAtStartup) == 0x48, "Offset mismatch for UOnlineAccountCommon::bRequireLightswitchAtStartup");
static_assert(offsetof(UOnlineAccountCommon, bPartialLoginEnabled) == 0x49, "Offset mismatch for UOnlineAccountCommon::bPartialLoginEnabled");
static_assert(offsetof(UOnlineAccountCommon, bRedeemOfflinePurchasesEnabled) == 0x4a, "Offset mismatch for UOnlineAccountCommon::bRedeemOfflinePurchasesEnabled");
static_assert(offsetof(UOnlineAccountCommon, bCheckingRejoinEnabled) == 0x4b, "Offset mismatch for UOnlineAccountCommon::bCheckingRejoinEnabled");
static_assert(offsetof(UOnlineAccountCommon, EULAKey) == 0x50, "Offset mismatch for UOnlineAccountCommon::EULAKey");
static_assert(offsetof(UOnlineAccountCommon, EulaKeys) == 0x60, "Offset mismatch for UOnlineAccountCommon::EulaKeys");
static_assert(offsetof(UOnlineAccountCommon, EulaKeyMapping) == 0x70, "Offset mismatch for UOnlineAccountCommon::EulaKeyMapping");
static_assert(offsetof(UOnlineAccountCommon, bEnableWaitingRoom) == 0xc0, "Offset mismatch for UOnlineAccountCommon::bEnableWaitingRoom");
static_assert(offsetof(UOnlineAccountCommon, WebCreateEpicAccountUrl) == 0xc8, "Offset mismatch for UOnlineAccountCommon::WebCreateEpicAccountUrl");
static_assert(offsetof(UOnlineAccountCommon, bAllowLocalLogout) == 0xd8, "Offset mismatch for UOnlineAccountCommon::bAllowLocalLogout");
static_assert(offsetof(UOnlineAccountCommon, DefaultLoginStepTimeout) == 0x110, "Offset mismatch for UOnlineAccountCommon::DefaultLoginStepTimeout");
static_assert(offsetof(UOnlineAccountCommon, CustomLoginStepTimeouts) == 0x118, "Offset mismatch for UOnlineAccountCommon::CustomLoginStepTimeouts");
static_assert(offsetof(UOnlineAccountCommon, bEnableDevLoginStepTimeouts) == 0x168, "Offset mismatch for UOnlineAccountCommon::bEnableDevLoginStepTimeouts");
static_assert(offsetof(UOnlineAccountCommon, DefaultLogoutStepTimeout) == 0x16c, "Offset mismatch for UOnlineAccountCommon::DefaultLogoutStepTimeout");
static_assert(offsetof(UOnlineAccountCommon, CustomLogoutStepTimeouts) == 0x170, "Offset mismatch for UOnlineAccountCommon::CustomLogoutStepTimeouts");
static_assert(offsetof(UOnlineAccountCommon, bEnableDevLogoutStepTimeouts) == 0x1c0, "Offset mismatch for UOnlineAccountCommon::bEnableDevLogoutStepTimeouts");
static_assert(offsetof(UOnlineAccountCommon, ServiceLoginConfig) == 0x1e8, "Offset mismatch for UOnlineAccountCommon::ServiceLoginConfig");
static_assert(offsetof(UOnlineAccountCommon, RedeemAccessUrl) == 0x1f8, "Offset mismatch for UOnlineAccountCommon::RedeemAccessUrl");
static_assert(offsetof(UOnlineAccountCommon, RequestFreeAccessUrl) == 0x208, "Offset mismatch for UOnlineAccountCommon::RequestFreeAccessUrl");
static_assert(offsetof(UOnlineAccountCommon, RealGameAccessUrl) == 0x218, "Offset mismatch for UOnlineAccountCommon::RealGameAccessUrl");
static_assert(offsetof(UOnlineAccountCommon, SkipRedeemOfflinePurchasesChance) == 0x228, "Offset mismatch for UOnlineAccountCommon::SkipRedeemOfflinePurchasesChance");
static_assert(offsetof(UOnlineAccountCommon, bUseFreeAccessInsteadOfGameAccess) == 0x22c, "Offset mismatch for UOnlineAccountCommon::bUseFreeAccessInsteadOfGameAccess");
static_assert(offsetof(UOnlineAccountCommon, bShouldGrantFreeAccess) == 0x22d, "Offset mismatch for UOnlineAccountCommon::bShouldGrantFreeAccess");
static_assert(offsetof(UOnlineAccountCommon, bAllowHomeSharingAccess) == 0x22f, "Offset mismatch for UOnlineAccountCommon::bAllowHomeSharingAccess");
static_assert(offsetof(UOnlineAccountCommon, bRequireUGCPrivilege) == 0x230, "Offset mismatch for UOnlineAccountCommon::bRequireUGCPrivilege");
static_assert(offsetof(UOnlineAccountCommon, AccessGrantDelaySeconds) == 0x4c0, "Offset mismatch for UOnlineAccountCommon::AccessGrantDelaySeconds");
static_assert(offsetof(UOnlineAccountCommon, WaitingRoomState) == 0x4c8, "Offset mismatch for UOnlineAccountCommon::WaitingRoomState");

// Size: 0x88 (Inherited: 0x28, Single: 0x60)
class UWaitingRoomState : public UObject
{
public:
    uint8_t Pad_28[0x34]; // 0x28 (Size: 0x34, Type: PaddingProperty)
    int32_t GracePeriodMins; // 0x5c (Size: 0x4, Type: IntProperty)
    uint8_t Pad_60[0x28]; // 0x60 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(UWaitingRoomState) == 0x88, "Size mismatch for UWaitingRoomState");
static_assert(offsetof(UWaitingRoomState, GracePeriodMins) == 0x5c, "Offset mismatch for UWaitingRoomState::GracePeriodMins");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FWebEnvUrl
{
    FString URL; // 0x0 (Size: 0x10, Type: StrProperty)
    FString RedirectUrl; // 0x10 (Size: 0x10, Type: StrProperty)
    FString Environment; // 0x20 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FWebEnvUrl) == 0x30, "Size mismatch for FWebEnvUrl");
static_assert(offsetof(FWebEnvUrl, URL) == 0x0, "Offset mismatch for FWebEnvUrl::URL");
static_assert(offsetof(FWebEnvUrl, RedirectUrl) == 0x10, "Offset mismatch for FWebEnvUrl::RedirectUrl");
static_assert(offsetof(FWebEnvUrl, Environment) == 0x20, "Offset mismatch for FWebEnvUrl::Environment");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FExternalAccountServiceConfig
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FName ExternalServiceName; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FExternalAccountServiceConfig) == 0x8, "Size mismatch for FExternalAccountServiceConfig");
static_assert(offsetof(FExternalAccountServiceConfig, Type) == 0x0, "Offset mismatch for FExternalAccountServiceConfig::Type");
static_assert(offsetof(FExternalAccountServiceConfig, ExternalServiceName) == 0x4, "Offset mismatch for FExternalAccountServiceConfig::ExternalServiceName");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FExchangeAccessParams
{
    FString EntitlementId; // 0x0 (Size: 0x10, Type: StrProperty)
    FString ReceiptId; // 0x10 (Size: 0x10, Type: StrProperty)
    FString VendorReceipt; // 0x20 (Size: 0x10, Type: StrProperty)
    FString AppStore; // 0x30 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FExchangeAccessParams) == 0x40, "Size mismatch for FExchangeAccessParams");
static_assert(offsetof(FExchangeAccessParams, EntitlementId) == 0x0, "Offset mismatch for FExchangeAccessParams::EntitlementId");
static_assert(offsetof(FExchangeAccessParams, ReceiptId) == 0x10, "Offset mismatch for FExchangeAccessParams::ReceiptId");
static_assert(offsetof(FExchangeAccessParams, VendorReceipt) == 0x20, "Offset mismatch for FExchangeAccessParams::VendorReceipt");
static_assert(offsetof(FExchangeAccessParams, AppStore) == 0x30, "Offset mismatch for FExchangeAccessParams::AppStore");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FGiftMessage
{
    FString GiftCode; // 0x0 (Size: 0x10, Type: StrProperty)
    FString SenderName; // 0x10 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_20[0x10]; // 0x20 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FGiftMessage) == 0x30, "Size mismatch for FGiftMessage");
static_assert(offsetof(FGiftMessage, GiftCode) == 0x0, "Offset mismatch for FGiftMessage::GiftCode");
static_assert(offsetof(FGiftMessage, SenderName) == 0x10, "Offset mismatch for FGiftMessage::SenderName");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FServiceLoginConfig
{
    FName LoginType; // 0x0 (Size: 0x4, Type: NameProperty)
    FName ExternalAuthMethod; // 0x4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_8[0x4]; // 0x8 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FServiceLoginConfig) == 0xc, "Size mismatch for FServiceLoginConfig");
static_assert(offsetof(FServiceLoginConfig, LoginType) == 0x0, "Offset mismatch for FServiceLoginConfig::LoginType");
static_assert(offsetof(FServiceLoginConfig, ExternalAuthMethod) == 0x4, "Offset mismatch for FServiceLoginConfig::ExternalAuthMethod");

// Size: 0xf0 (Inherited: 0x0, Single: 0xf0)
struct FOnlineAccountTexts_FailedLoginConsole
{
    FText AgeRestriction; // 0x0 (Size: 0x10, Type: TextProperty)
    FText Generic; // 0x10 (Size: 0x10, Type: TextProperty)
    FText MissingAuthAssociation; // 0x20 (Size: 0x10, Type: TextProperty)
    FText NeedPremiumAccount; // 0x30 (Size: 0x10, Type: TextProperty)
    FText OnlinePlayRestriction; // 0x40 (Size: 0x10, Type: TextProperty)
    FText PatchAvailable; // 0x50 (Size: 0x10, Type: TextProperty)
    FText PatchAvailableInstruction_Default; // 0x60 (Size: 0x10, Type: TextProperty)
    FText PatchAvailableInstruction_Xbox; // 0x70 (Size: 0x10, Type: TextProperty)
    FText PleaseSignIn; // 0x80 (Size: 0x10, Type: TextProperty)
    FText SystemUpdateAvailable; // 0x90 (Size: 0x10, Type: TextProperty)
    FText UI; // 0xa0 (Size: 0x10, Type: TextProperty)
    FText UnableToComplete; // 0xb0 (Size: 0x10, Type: TextProperty)
    FText UnableToSignIn; // 0xc0 (Size: 0x10, Type: TextProperty)
    FText UnableToStartPrivCheck; // 0xd0 (Size: 0x10, Type: TextProperty)
    FText UnexpectedError; // 0xe0 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FOnlineAccountTexts_FailedLoginConsole) == 0xf0, "Size mismatch for FOnlineAccountTexts_FailedLoginConsole");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, AgeRestriction) == 0x0, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::AgeRestriction");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, Generic) == 0x10, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::Generic");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, MissingAuthAssociation) == 0x20, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::MissingAuthAssociation");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, NeedPremiumAccount) == 0x30, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::NeedPremiumAccount");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, OnlinePlayRestriction) == 0x40, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::OnlinePlayRestriction");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, PatchAvailable) == 0x50, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::PatchAvailable");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, PatchAvailableInstruction_Default) == 0x60, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::PatchAvailableInstruction_Default");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, PatchAvailableInstruction_Xbox) == 0x70, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::PatchAvailableInstruction_Xbox");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, PleaseSignIn) == 0x80, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::PleaseSignIn");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, SystemUpdateAvailable) == 0x90, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::SystemUpdateAvailable");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, UI) == 0xa0, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::UI");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, UnableToComplete) == 0xb0, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::UnableToComplete");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, UnableToSignIn) == 0xc0, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::UnableToSignIn");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, UnableToStartPrivCheck) == 0xd0, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::UnableToStartPrivCheck");
static_assert(offsetof(FOnlineAccountTexts_FailedLoginConsole, UnexpectedError) == 0xe0, "Offset mismatch for FOnlineAccountTexts_FailedLoginConsole::UnexpectedError");

// Size: 0x670 (Inherited: 0x0, Single: 0x670)
struct FOnlineAccountTexts
{
    FText AllGiftCodesUsed; // 0x0 (Size: 0x10, Type: TextProperty)
    FText AssociateConsoleAuth; // 0x10 (Size: 0x10, Type: TextProperty)
    FText AutoLoginFailed; // 0x20 (Size: 0x10, Type: TextProperty)
    FText AutoLoginFailedMobile; // 0x30 (Size: 0x10, Type: TextProperty)
    FText BannedFromGame; // 0x40 (Size: 0x10, Type: TextProperty)
    FText CheckEntitledToPlay; // 0x50 (Size: 0x10, Type: TextProperty)
    FText CheckingRejoin; // 0x60 (Size: 0x10, Type: TextProperty)
    FText CheckServiceAvailability; // 0x70 (Size: 0x10, Type: TextProperty)
    FText ConsolePrivileges; // 0x80 (Size: 0x10, Type: TextProperty)
    FText CreateAccountCompleted; // 0x90 (Size: 0x10, Type: TextProperty)
    FText CreateAccountFailure; // 0xa0 (Size: 0x10, Type: TextProperty)
    FText CreateAccountStepTimeout; // 0xb0 (Size: 0x10, Type: TextProperty)
    FText CreateHeadless; // 0xc0 (Size: 0x10, Type: TextProperty)
    FText DoQosPingTests; // 0xd0 (Size: 0x10, Type: TextProperty)
    FText DowntimeMinutesWarningText; // 0xe0 (Size: 0x10, Type: TextProperty)
    FText DowntimeSecondsWarningText; // 0xf0 (Size: 0x10, Type: TextProperty)
    FText DuplicateAuthAssociaton; // 0x100 (Size: 0x10, Type: TextProperty)
    FText EulaCheck; // 0x110 (Size: 0x10, Type: TextProperty)
    FText ExchangeConsoleGiftsForAccess; // 0x120 (Size: 0x10, Type: TextProperty)
    FText FailedAccountCreate; // 0x130 (Size: 0x10, Type: TextProperty)
    FText FailedEulaCheck_EulaAcceptanceFailed; // 0x140 (Size: 0x10, Type: TextProperty)
    FText FailedEulaCheck_MustAcceptEula; // 0x150 (Size: 0x10, Type: TextProperty)
    FText FailedLoginCredentialsMsg; // 0x160 (Size: 0x10, Type: TextProperty)
    FText FailedLoginAgeVerificationIncomplete; // 0x170 (Size: 0x10, Type: TextProperty)
    FText FailedLoginParentalLock; // 0x180 (Size: 0x10, Type: TextProperty)
    FText FailedLoginNoRealId; // 0x190 (Size: 0x10, Type: TextProperty)
    FText FailedLoginLockoutMsg; // 0x1a0 (Size: 0x10, Type: TextProperty)
    FText FailedLoginRequiresMFA; // 0x1b0 (Size: 0x10, Type: TextProperty)
    FText FailedLoginRequiresAuthAppMFA; // 0x1c0 (Size: 0x10, Type: TextProperty)
    FText FailedInvalidMFA; // 0x1d0 (Size: 0x10, Type: TextProperty)
    FText FailedLoginRequiresCorrectiveAction; // 0x1e0 (Size: 0x10, Type: TextProperty)
    FText FailedLoginMsg; // 0x1f0 (Size: 0x10, Type: TextProperty)
    FText FailedLoginMsg_InvalidRefreshToken; // 0x200 (Size: 0x10, Type: TextProperty)
    FText FailedStartLogin; // 0x210 (Size: 0x10, Type: TextProperty)
    FText FounderChatExitedText; // 0x220 (Size: 0x10, Type: TextProperty)
    FText FounderChatJoinedText; // 0x230 (Size: 0x10, Type: TextProperty)
    FText GameDisplayName; // 0x240 (Size: 0x10, Type: TextProperty)
    FText GeneralLoginFailure; // 0x250 (Size: 0x10, Type: TextProperty)
    FText GlobalChatExitedText; // 0x260 (Size: 0x10, Type: TextProperty)
    FText GlobalChatJoinedText; // 0x270 (Size: 0x10, Type: TextProperty)
    FText HeadlessAccountFailed; // 0x280 (Size: 0x10, Type: TextProperty)
    FText InMatchShutdownTimeWarningText; // 0x290 (Size: 0x10, Type: TextProperty)
    FText InvalidUser; // 0x2a0 (Size: 0x10, Type: TextProperty)
    FText LoggedOutofMCP; // 0x2b0 (Size: 0x10, Type: TextProperty)
    FText DisconnectedFromMCP; // 0x2c0 (Size: 0x10, Type: TextProperty)
    FText LoggedOutReturnedToTitle; // 0x2d0 (Size: 0x10, Type: TextProperty)
    FText LoggedOutSwitchedProfile; // 0x2e0 (Size: 0x10, Type: TextProperty)
    FText LoggingIn; // 0x2f0 (Size: 0x10, Type: TextProperty)
    FText LoggingInConsoleAuth; // 0x300 (Size: 0x10, Type: TextProperty)
    FText LoggingOut; // 0x310 (Size: 0x10, Type: TextProperty)
    FText LoginConsole; // 0x320 (Size: 0x10, Type: TextProperty)
    FText LoginFailure; // 0x330 (Size: 0x10, Type: TextProperty)
    FText Logout_Unlink; // 0x340 (Size: 0x10, Type: TextProperty)
    FText LogoutCompleted; // 0x350 (Size: 0x10, Type: TextProperty)
    FText LostConnection; // 0x360 (Size: 0x10, Type: TextProperty)
    FText LoginStepTimeout; // 0x370 (Size: 0x10, Type: TextProperty)
    FText MCPTimeout; // 0x380 (Size: 0x10, Type: TextProperty)
    FText LightswitchCheckNetworkFailureMsg; // 0x390 (Size: 0x10, Type: TextProperty)
    FText NetworkConnectionUnavailable; // 0x3a0 (Size: 0x10, Type: TextProperty)
    FText NoPlayEntitlement; // 0x3b0 (Size: 0x10, Type: TextProperty)
    FText NoServerAccess; // 0x3c0 (Size: 0x10, Type: TextProperty)
    FText PlayAccessRevoked; // 0x3d0 (Size: 0x10, Type: TextProperty)
    FText PremiumAccountName_Default; // 0x3e0 (Size: 0x10, Type: TextProperty)
    FText PremiumAccountName_Sony; // 0x3f0 (Size: 0x10, Type: TextProperty)
    FText PremiumAccountName_Nintendo; // 0x400 (Size: 0x10, Type: TextProperty)
    FText PremiumAccountName_XboxOne; // 0x410 (Size: 0x10, Type: TextProperty)
    FText RedeemOfflinePurchases; // 0x420 (Size: 0x10, Type: TextProperty)
    FText ServiceDowntime; // 0x430 (Size: 0x10, Type: TextProperty)
    FText SignInCompleting; // 0x440 (Size: 0x10, Type: TextProperty)
    FText SignIntoConsoleServices; // 0x450 (Size: 0x10, Type: TextProperty)
    FText TokenExpired; // 0x460 (Size: 0x10, Type: TextProperty)
    FText UnableToConnect; // 0x470 (Size: 0x10, Type: TextProperty)
    FText UnableToJoinWaitingRoomLoginQueue; // 0x480 (Size: 0x10, Type: TextProperty)
    FText UnexpectedConsoleAuthFailure; // 0x490 (Size: 0x10, Type: TextProperty)
    FText UnlinkConsoleFailed; // 0x4a0 (Size: 0x10, Type: TextProperty)
    FText UserLoginFailed; // 0x4b0 (Size: 0x10, Type: TextProperty)
    FText WaitingRoom; // 0x4c0 (Size: 0x10, Type: TextProperty)
    FText WaitingRoomError; // 0x4d0 (Size: 0x10, Type: TextProperty)
    FText WaitingRoomFailure; // 0x4e0 (Size: 0x10, Type: TextProperty)
    FText WaitingRoomWaiting; // 0x4f0 (Size: 0x10, Type: TextProperty)
    FOnlineAccountTexts_FailedLoginConsole FailedLoginConsole; // 0x500 (Size: 0xf0, Type: StructProperty)
    FText LoggingInExternalAuth; // 0x5f0 (Size: 0x10, Type: TextProperty)
    FText CreateDeviceAuth; // 0x600 (Size: 0x10, Type: TextProperty)
    FText ExtAuthCanceled; // 0x610 (Size: 0x10, Type: TextProperty)
    FText ExtAuthFailure; // 0x620 (Size: 0x10, Type: TextProperty)
    FText ExtAuthAssociationFailure; // 0x630 (Size: 0x10, Type: TextProperty)
    FText ExtAuthTimeout; // 0x640 (Size: 0x10, Type: TextProperty)
    FText ExtAuthMissingAuthAssociation; // 0x650 (Size: 0x10, Type: TextProperty)
    FText UnableToQueryReceipts; // 0x660 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FOnlineAccountTexts) == 0x670, "Size mismatch for FOnlineAccountTexts");
static_assert(offsetof(FOnlineAccountTexts, AllGiftCodesUsed) == 0x0, "Offset mismatch for FOnlineAccountTexts::AllGiftCodesUsed");
static_assert(offsetof(FOnlineAccountTexts, AssociateConsoleAuth) == 0x10, "Offset mismatch for FOnlineAccountTexts::AssociateConsoleAuth");
static_assert(offsetof(FOnlineAccountTexts, AutoLoginFailed) == 0x20, "Offset mismatch for FOnlineAccountTexts::AutoLoginFailed");
static_assert(offsetof(FOnlineAccountTexts, AutoLoginFailedMobile) == 0x30, "Offset mismatch for FOnlineAccountTexts::AutoLoginFailedMobile");
static_assert(offsetof(FOnlineAccountTexts, BannedFromGame) == 0x40, "Offset mismatch for FOnlineAccountTexts::BannedFromGame");
static_assert(offsetof(FOnlineAccountTexts, CheckEntitledToPlay) == 0x50, "Offset mismatch for FOnlineAccountTexts::CheckEntitledToPlay");
static_assert(offsetof(FOnlineAccountTexts, CheckingRejoin) == 0x60, "Offset mismatch for FOnlineAccountTexts::CheckingRejoin");
static_assert(offsetof(FOnlineAccountTexts, CheckServiceAvailability) == 0x70, "Offset mismatch for FOnlineAccountTexts::CheckServiceAvailability");
static_assert(offsetof(FOnlineAccountTexts, ConsolePrivileges) == 0x80, "Offset mismatch for FOnlineAccountTexts::ConsolePrivileges");
static_assert(offsetof(FOnlineAccountTexts, CreateAccountCompleted) == 0x90, "Offset mismatch for FOnlineAccountTexts::CreateAccountCompleted");
static_assert(offsetof(FOnlineAccountTexts, CreateAccountFailure) == 0xa0, "Offset mismatch for FOnlineAccountTexts::CreateAccountFailure");
static_assert(offsetof(FOnlineAccountTexts, CreateAccountStepTimeout) == 0xb0, "Offset mismatch for FOnlineAccountTexts::CreateAccountStepTimeout");
static_assert(offsetof(FOnlineAccountTexts, CreateHeadless) == 0xc0, "Offset mismatch for FOnlineAccountTexts::CreateHeadless");
static_assert(offsetof(FOnlineAccountTexts, DoQosPingTests) == 0xd0, "Offset mismatch for FOnlineAccountTexts::DoQosPingTests");
static_assert(offsetof(FOnlineAccountTexts, DowntimeMinutesWarningText) == 0xe0, "Offset mismatch for FOnlineAccountTexts::DowntimeMinutesWarningText");
static_assert(offsetof(FOnlineAccountTexts, DowntimeSecondsWarningText) == 0xf0, "Offset mismatch for FOnlineAccountTexts::DowntimeSecondsWarningText");
static_assert(offsetof(FOnlineAccountTexts, DuplicateAuthAssociaton) == 0x100, "Offset mismatch for FOnlineAccountTexts::DuplicateAuthAssociaton");
static_assert(offsetof(FOnlineAccountTexts, EulaCheck) == 0x110, "Offset mismatch for FOnlineAccountTexts::EulaCheck");
static_assert(offsetof(FOnlineAccountTexts, ExchangeConsoleGiftsForAccess) == 0x120, "Offset mismatch for FOnlineAccountTexts::ExchangeConsoleGiftsForAccess");
static_assert(offsetof(FOnlineAccountTexts, FailedAccountCreate) == 0x130, "Offset mismatch for FOnlineAccountTexts::FailedAccountCreate");
static_assert(offsetof(FOnlineAccountTexts, FailedEulaCheck_EulaAcceptanceFailed) == 0x140, "Offset mismatch for FOnlineAccountTexts::FailedEulaCheck_EulaAcceptanceFailed");
static_assert(offsetof(FOnlineAccountTexts, FailedEulaCheck_MustAcceptEula) == 0x150, "Offset mismatch for FOnlineAccountTexts::FailedEulaCheck_MustAcceptEula");
static_assert(offsetof(FOnlineAccountTexts, FailedLoginCredentialsMsg) == 0x160, "Offset mismatch for FOnlineAccountTexts::FailedLoginCredentialsMsg");
static_assert(offsetof(FOnlineAccountTexts, FailedLoginAgeVerificationIncomplete) == 0x170, "Offset mismatch for FOnlineAccountTexts::FailedLoginAgeVerificationIncomplete");
static_assert(offsetof(FOnlineAccountTexts, FailedLoginParentalLock) == 0x180, "Offset mismatch for FOnlineAccountTexts::FailedLoginParentalLock");
static_assert(offsetof(FOnlineAccountTexts, FailedLoginNoRealId) == 0x190, "Offset mismatch for FOnlineAccountTexts::FailedLoginNoRealId");
static_assert(offsetof(FOnlineAccountTexts, FailedLoginLockoutMsg) == 0x1a0, "Offset mismatch for FOnlineAccountTexts::FailedLoginLockoutMsg");
static_assert(offsetof(FOnlineAccountTexts, FailedLoginRequiresMFA) == 0x1b0, "Offset mismatch for FOnlineAccountTexts::FailedLoginRequiresMFA");
static_assert(offsetof(FOnlineAccountTexts, FailedLoginRequiresAuthAppMFA) == 0x1c0, "Offset mismatch for FOnlineAccountTexts::FailedLoginRequiresAuthAppMFA");
static_assert(offsetof(FOnlineAccountTexts, FailedInvalidMFA) == 0x1d0, "Offset mismatch for FOnlineAccountTexts::FailedInvalidMFA");
static_assert(offsetof(FOnlineAccountTexts, FailedLoginRequiresCorrectiveAction) == 0x1e0, "Offset mismatch for FOnlineAccountTexts::FailedLoginRequiresCorrectiveAction");
static_assert(offsetof(FOnlineAccountTexts, FailedLoginMsg) == 0x1f0, "Offset mismatch for FOnlineAccountTexts::FailedLoginMsg");
static_assert(offsetof(FOnlineAccountTexts, FailedLoginMsg_InvalidRefreshToken) == 0x200, "Offset mismatch for FOnlineAccountTexts::FailedLoginMsg_InvalidRefreshToken");
static_assert(offsetof(FOnlineAccountTexts, FailedStartLogin) == 0x210, "Offset mismatch for FOnlineAccountTexts::FailedStartLogin");
static_assert(offsetof(FOnlineAccountTexts, FounderChatExitedText) == 0x220, "Offset mismatch for FOnlineAccountTexts::FounderChatExitedText");
static_assert(offsetof(FOnlineAccountTexts, FounderChatJoinedText) == 0x230, "Offset mismatch for FOnlineAccountTexts::FounderChatJoinedText");
static_assert(offsetof(FOnlineAccountTexts, GameDisplayName) == 0x240, "Offset mismatch for FOnlineAccountTexts::GameDisplayName");
static_assert(offsetof(FOnlineAccountTexts, GeneralLoginFailure) == 0x250, "Offset mismatch for FOnlineAccountTexts::GeneralLoginFailure");
static_assert(offsetof(FOnlineAccountTexts, GlobalChatExitedText) == 0x260, "Offset mismatch for FOnlineAccountTexts::GlobalChatExitedText");
static_assert(offsetof(FOnlineAccountTexts, GlobalChatJoinedText) == 0x270, "Offset mismatch for FOnlineAccountTexts::GlobalChatJoinedText");
static_assert(offsetof(FOnlineAccountTexts, HeadlessAccountFailed) == 0x280, "Offset mismatch for FOnlineAccountTexts::HeadlessAccountFailed");
static_assert(offsetof(FOnlineAccountTexts, InMatchShutdownTimeWarningText) == 0x290, "Offset mismatch for FOnlineAccountTexts::InMatchShutdownTimeWarningText");
static_assert(offsetof(FOnlineAccountTexts, InvalidUser) == 0x2a0, "Offset mismatch for FOnlineAccountTexts::InvalidUser");
static_assert(offsetof(FOnlineAccountTexts, LoggedOutofMCP) == 0x2b0, "Offset mismatch for FOnlineAccountTexts::LoggedOutofMCP");
static_assert(offsetof(FOnlineAccountTexts, DisconnectedFromMCP) == 0x2c0, "Offset mismatch for FOnlineAccountTexts::DisconnectedFromMCP");
static_assert(offsetof(FOnlineAccountTexts, LoggedOutReturnedToTitle) == 0x2d0, "Offset mismatch for FOnlineAccountTexts::LoggedOutReturnedToTitle");
static_assert(offsetof(FOnlineAccountTexts, LoggedOutSwitchedProfile) == 0x2e0, "Offset mismatch for FOnlineAccountTexts::LoggedOutSwitchedProfile");
static_assert(offsetof(FOnlineAccountTexts, LoggingIn) == 0x2f0, "Offset mismatch for FOnlineAccountTexts::LoggingIn");
static_assert(offsetof(FOnlineAccountTexts, LoggingInConsoleAuth) == 0x300, "Offset mismatch for FOnlineAccountTexts::LoggingInConsoleAuth");
static_assert(offsetof(FOnlineAccountTexts, LoggingOut) == 0x310, "Offset mismatch for FOnlineAccountTexts::LoggingOut");
static_assert(offsetof(FOnlineAccountTexts, LoginConsole) == 0x320, "Offset mismatch for FOnlineAccountTexts::LoginConsole");
static_assert(offsetof(FOnlineAccountTexts, LoginFailure) == 0x330, "Offset mismatch for FOnlineAccountTexts::LoginFailure");
static_assert(offsetof(FOnlineAccountTexts, Logout_Unlink) == 0x340, "Offset mismatch for FOnlineAccountTexts::Logout_Unlink");
static_assert(offsetof(FOnlineAccountTexts, LogoutCompleted) == 0x350, "Offset mismatch for FOnlineAccountTexts::LogoutCompleted");
static_assert(offsetof(FOnlineAccountTexts, LostConnection) == 0x360, "Offset mismatch for FOnlineAccountTexts::LostConnection");
static_assert(offsetof(FOnlineAccountTexts, LoginStepTimeout) == 0x370, "Offset mismatch for FOnlineAccountTexts::LoginStepTimeout");
static_assert(offsetof(FOnlineAccountTexts, MCPTimeout) == 0x380, "Offset mismatch for FOnlineAccountTexts::MCPTimeout");
static_assert(offsetof(FOnlineAccountTexts, LightswitchCheckNetworkFailureMsg) == 0x390, "Offset mismatch for FOnlineAccountTexts::LightswitchCheckNetworkFailureMsg");
static_assert(offsetof(FOnlineAccountTexts, NetworkConnectionUnavailable) == 0x3a0, "Offset mismatch for FOnlineAccountTexts::NetworkConnectionUnavailable");
static_assert(offsetof(FOnlineAccountTexts, NoPlayEntitlement) == 0x3b0, "Offset mismatch for FOnlineAccountTexts::NoPlayEntitlement");
static_assert(offsetof(FOnlineAccountTexts, NoServerAccess) == 0x3c0, "Offset mismatch for FOnlineAccountTexts::NoServerAccess");
static_assert(offsetof(FOnlineAccountTexts, PlayAccessRevoked) == 0x3d0, "Offset mismatch for FOnlineAccountTexts::PlayAccessRevoked");
static_assert(offsetof(FOnlineAccountTexts, PremiumAccountName_Default) == 0x3e0, "Offset mismatch for FOnlineAccountTexts::PremiumAccountName_Default");
static_assert(offsetof(FOnlineAccountTexts, PremiumAccountName_Sony) == 0x3f0, "Offset mismatch for FOnlineAccountTexts::PremiumAccountName_Sony");
static_assert(offsetof(FOnlineAccountTexts, PremiumAccountName_Nintendo) == 0x400, "Offset mismatch for FOnlineAccountTexts::PremiumAccountName_Nintendo");
static_assert(offsetof(FOnlineAccountTexts, PremiumAccountName_XboxOne) == 0x410, "Offset mismatch for FOnlineAccountTexts::PremiumAccountName_XboxOne");
static_assert(offsetof(FOnlineAccountTexts, RedeemOfflinePurchases) == 0x420, "Offset mismatch for FOnlineAccountTexts::RedeemOfflinePurchases");
static_assert(offsetof(FOnlineAccountTexts, ServiceDowntime) == 0x430, "Offset mismatch for FOnlineAccountTexts::ServiceDowntime");
static_assert(offsetof(FOnlineAccountTexts, SignInCompleting) == 0x440, "Offset mismatch for FOnlineAccountTexts::SignInCompleting");
static_assert(offsetof(FOnlineAccountTexts, SignIntoConsoleServices) == 0x450, "Offset mismatch for FOnlineAccountTexts::SignIntoConsoleServices");
static_assert(offsetof(FOnlineAccountTexts, TokenExpired) == 0x460, "Offset mismatch for FOnlineAccountTexts::TokenExpired");
static_assert(offsetof(FOnlineAccountTexts, UnableToConnect) == 0x470, "Offset mismatch for FOnlineAccountTexts::UnableToConnect");
static_assert(offsetof(FOnlineAccountTexts, UnableToJoinWaitingRoomLoginQueue) == 0x480, "Offset mismatch for FOnlineAccountTexts::UnableToJoinWaitingRoomLoginQueue");
static_assert(offsetof(FOnlineAccountTexts, UnexpectedConsoleAuthFailure) == 0x490, "Offset mismatch for FOnlineAccountTexts::UnexpectedConsoleAuthFailure");
static_assert(offsetof(FOnlineAccountTexts, UnlinkConsoleFailed) == 0x4a0, "Offset mismatch for FOnlineAccountTexts::UnlinkConsoleFailed");
static_assert(offsetof(FOnlineAccountTexts, UserLoginFailed) == 0x4b0, "Offset mismatch for FOnlineAccountTexts::UserLoginFailed");
static_assert(offsetof(FOnlineAccountTexts, WaitingRoom) == 0x4c0, "Offset mismatch for FOnlineAccountTexts::WaitingRoom");
static_assert(offsetof(FOnlineAccountTexts, WaitingRoomError) == 0x4d0, "Offset mismatch for FOnlineAccountTexts::WaitingRoomError");
static_assert(offsetof(FOnlineAccountTexts, WaitingRoomFailure) == 0x4e0, "Offset mismatch for FOnlineAccountTexts::WaitingRoomFailure");
static_assert(offsetof(FOnlineAccountTexts, WaitingRoomWaiting) == 0x4f0, "Offset mismatch for FOnlineAccountTexts::WaitingRoomWaiting");
static_assert(offsetof(FOnlineAccountTexts, FailedLoginConsole) == 0x500, "Offset mismatch for FOnlineAccountTexts::FailedLoginConsole");
static_assert(offsetof(FOnlineAccountTexts, LoggingInExternalAuth) == 0x5f0, "Offset mismatch for FOnlineAccountTexts::LoggingInExternalAuth");
static_assert(offsetof(FOnlineAccountTexts, CreateDeviceAuth) == 0x600, "Offset mismatch for FOnlineAccountTexts::CreateDeviceAuth");
static_assert(offsetof(FOnlineAccountTexts, ExtAuthCanceled) == 0x610, "Offset mismatch for FOnlineAccountTexts::ExtAuthCanceled");
static_assert(offsetof(FOnlineAccountTexts, ExtAuthFailure) == 0x620, "Offset mismatch for FOnlineAccountTexts::ExtAuthFailure");
static_assert(offsetof(FOnlineAccountTexts, ExtAuthAssociationFailure) == 0x630, "Offset mismatch for FOnlineAccountTexts::ExtAuthAssociationFailure");
static_assert(offsetof(FOnlineAccountTexts, ExtAuthTimeout) == 0x640, "Offset mismatch for FOnlineAccountTexts::ExtAuthTimeout");
static_assert(offsetof(FOnlineAccountTexts, ExtAuthMissingAuthAssociation) == 0x650, "Offset mismatch for FOnlineAccountTexts::ExtAuthMissingAuthAssociation");
static_assert(offsetof(FOnlineAccountTexts, UnableToQueryReceipts) == 0x660, "Offset mismatch for FOnlineAccountTexts::UnableToQueryReceipts");

