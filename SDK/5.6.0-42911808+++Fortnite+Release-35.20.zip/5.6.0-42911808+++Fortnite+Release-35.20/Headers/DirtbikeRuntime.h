/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DirtbikeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "MotorcycleRuntime.h"
#include "FortniteGame.h"
#include "EnhancedInput.h"

// Size: 0x26d0 (Inherited: 0x96a8, Single: 0xffff9028)
class AFortDirtbikeVehicle : public AFortMotorcycleVehicle
{
public:
    UInputAction* InputActionJump; // 0x26c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_26c8[0x8]; // 0x26c8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(AFortDirtbikeVehicle) == 0x26d0, "Size mismatch for AFortDirtbikeVehicle");
static_assert(offsetof(AFortDirtbikeVehicle, InputActionJump) == 0x26c0, "Offset mismatch for AFortDirtbikeVehicle::InputActionJump");

// Size: 0xee8 (Inherited: 0x1c08, Single: 0xfffff2e0)
class UFortDirtbikeVehicleConfigs : public UFortMotorcycleVehicleConfigs
{
public:
};

static_assert(sizeof(UFortDirtbikeVehicleConfigs) == 0xee8, "Size mismatch for UFortDirtbikeVehicleConfigs");

