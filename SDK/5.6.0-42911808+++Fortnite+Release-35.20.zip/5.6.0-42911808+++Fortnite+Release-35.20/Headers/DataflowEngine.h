/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataflowEngine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "DataflowCore.h"

// Size: 0x580 (Inherited: 0xdc0, Single: 0xfffff7c0)
class UDataflowDebugDrawComponent : public UDebugDrawComponent
{
public:
};

static_assert(sizeof(UDataflowDebugDrawComponent) == 0x580, "Size mismatch for UDataflowDebugDrawComponent");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDataflowInstanceInterface : public UInterface
{
public:
};

static_assert(sizeof(UDataflowInstanceInterface) == 0x28, "Size mismatch for UDataflowInstanceInterface");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UDataflowMesh : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TArray<UMaterialInterface*> Materials; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDataflowMesh) == 0x40, "Size mismatch for UDataflowMesh");
static_assert(offsetof(UDataflowMesh, Materials) == 0x30, "Offset mismatch for UDataflowMesh::Materials");

// Size: 0x78 (Inherited: 0x88, Single: 0xfffffff0)
class UDataflowSubGraph : public UEdGraph
{
public:
    FGuid SubGraphGuid; // 0x60 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_70[0x8]; // 0x70 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDataflowSubGraph) == 0x78, "Size mismatch for UDataflowSubGraph");
static_assert(offsetof(UDataflowSubGraph, SubGraphGuid) == 0x60, "Offset mismatch for UDataflowSubGraph::SubGraphGuid");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDataflowBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void EvaluateTerminalNodeByName(UDataflow*& Dataflow, FName& TerminalNodeName, UObject*& ResultAsset); // 0x9f041e8 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UDataflowBlueprintLibrary) == 0x28, "Size mismatch for UDataflowBlueprintLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDataflowContentOwner : public UInterface
{
public:
};

static_assert(sizeof(UDataflowContentOwner) == 0x28, "Size mismatch for UDataflowContentOwner");

// Size: 0xa8 (Inherited: 0xa0, Single: 0x8)
class UDataflowBaseContent : public UDataflowContextObject
{
public:
    FString DataflowTerminal; // 0x78 (Size: 0x10, Type: StrProperty)
    UObject* TerminalAsset; // 0x88 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_90[0x8]; // 0x90 (Size: 0x8, Type: PaddingProperty)
    bool bIsConstructionDirty; // 0x98 (Size: 0x1, Type: BoolProperty)
    bool bIsSimulationDirty; // 0x99 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9a[0xe]; // 0x9a (Size: 0xe, Type: PaddingProperty)
};

static_assert(sizeof(UDataflowBaseContent) == 0xa8, "Size mismatch for UDataflowBaseContent");
static_assert(offsetof(UDataflowBaseContent, DataflowTerminal) == 0x78, "Offset mismatch for UDataflowBaseContent::DataflowTerminal");
static_assert(offsetof(UDataflowBaseContent, TerminalAsset) == 0x88, "Offset mismatch for UDataflowBaseContent::TerminalAsset");
static_assert(offsetof(UDataflowBaseContent, bIsConstructionDirty) == 0x98, "Offset mismatch for UDataflowBaseContent::bIsConstructionDirty");
static_assert(offsetof(UDataflowBaseContent, bIsSimulationDirty) == 0x99, "Offset mismatch for UDataflowBaseContent::bIsSimulationDirty");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UDataflowContextObject : public UObject
{
public:
    uint8_t Pad_28[0x10]; // 0x28 (Size: 0x10, Type: PaddingProperty)
    UDataflowEdNode* SelectedNode; // 0x38 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_40[0x18]; // 0x40 (Size: 0x18, Type: PaddingProperty)
    UDataflow* DataflowGraph; // 0x58 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_60[0x18]; // 0x60 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UDataflowContextObject) == 0x78, "Size mismatch for UDataflowContextObject");
static_assert(offsetof(UDataflowContextObject, SelectedNode) == 0x38, "Offset mismatch for UDataflowContextObject::SelectedNode");
static_assert(offsetof(UDataflowContextObject, DataflowGraph) == 0x58, "Offset mismatch for UDataflowContextObject::DataflowGraph");

// Size: 0xc0 (Inherited: 0x148, Single: 0xffffff78)
class UDataflowSkeletalContent : public UDataflowBaseContent
{
public:
    USkeletalMesh* SkeletalMesh; // 0xa8 (Size: 0x8, Type: ObjectProperty)
    UAnimationAsset* AnimationAsset; // 0xb0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDataflowSkeletalContent) == 0xc0, "Size mismatch for UDataflowSkeletalContent");
static_assert(offsetof(UDataflowSkeletalContent, SkeletalMesh) == 0xa8, "Offset mismatch for UDataflowSkeletalContent::SkeletalMesh");
static_assert(offsetof(UDataflowSkeletalContent, AnimationAsset) == 0xb0, "Offset mismatch for UDataflowSkeletalContent::AnimationAsset");

// Size: 0xd8 (Inherited: 0xc0, Single: 0x18)
class UDataflowEdNode : public UEdGraphNode
{
public:
    uint8_t Pad_98[0x20]; // 0x98 (Size: 0x20, Type: PaddingProperty)
    bool bRenderInAssetEditor; // 0xb8 (Size: 0x1, Type: BoolProperty)
    bool bRenderWireframeInAssetEditor; // 0xb9 (Size: 0x1, Type: BoolProperty)
    bool bCanEnableRenderWireframe; // 0xba (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_bb[0x1d]; // 0xbb (Size: 0x1d, Type: PaddingProperty)
};

static_assert(sizeof(UDataflowEdNode) == 0xd8, "Size mismatch for UDataflowEdNode");
static_assert(offsetof(UDataflowEdNode, bRenderInAssetEditor) == 0xb8, "Offset mismatch for UDataflowEdNode::bRenderInAssetEditor");
static_assert(offsetof(UDataflowEdNode, bRenderWireframeInAssetEditor) == 0xb9, "Offset mismatch for UDataflowEdNode::bRenderWireframeInAssetEditor");
static_assert(offsetof(UDataflowEdNode, bCanEnableRenderWireframe) == 0xba, "Offset mismatch for UDataflowEdNode::bCanEnableRenderWireframe");

// Size: 0x108 (Inherited: 0x88, Single: 0x80)
class UDataflow : public UEdGraph
{
public:
    uint8_t Pad_60[0x48]; // 0x60 (Size: 0x48, Type: PaddingProperty)
    bool bActive; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)
    TArray<UObject*> Targets; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    UMaterial* Material; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Type; // 0xc8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c9[0x7]; // 0xc9 (Size: 0x7, Type: PaddingProperty)
    FInstancedPropertyBag Variables; // 0xd0 (Size: 0x10, Type: StructProperty)
    TArray<UDataflowSubGraph*> DataflowSubGraphs; // 0xe0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_f0[0x18]; // 0xf0 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UDataflow) == 0x108, "Size mismatch for UDataflow");
static_assert(offsetof(UDataflow, bActive) == 0xa8, "Offset mismatch for UDataflow::bActive");
static_assert(offsetof(UDataflow, Targets) == 0xb0, "Offset mismatch for UDataflow::Targets");
static_assert(offsetof(UDataflow, Material) == 0xc0, "Offset mismatch for UDataflow::Material");
static_assert(offsetof(UDataflow, Type) == 0xc8, "Offset mismatch for UDataflow::Type");
static_assert(offsetof(UDataflow, Variables) == 0xd0, "Offset mismatch for UDataflow::Variables");
static_assert(offsetof(UDataflow, DataflowSubGraphs) == 0xe0, "Offset mismatch for UDataflow::DataflowSubGraphs");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDataflowNodeDebugDrawSettings
{
    uint8_t RenderType; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bTranslucent; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    FLinearColor Color; // 0x4 (Size: 0x10, Type: StructProperty)
    float LineWidthMultiplier; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDataflowNodeDebugDrawSettings) == 0x18, "Size mismatch for FDataflowNodeDebugDrawSettings");
static_assert(offsetof(FDataflowNodeDebugDrawSettings, RenderType) == 0x0, "Offset mismatch for FDataflowNodeDebugDrawSettings::RenderType");
static_assert(offsetof(FDataflowNodeDebugDrawSettings, bTranslucent) == 0x1, "Offset mismatch for FDataflowNodeDebugDrawSettings::bTranslucent");
static_assert(offsetof(FDataflowNodeDebugDrawSettings, Color) == 0x4, "Offset mismatch for FDataflowNodeDebugDrawSettings::Color");
static_assert(offsetof(FDataflowNodeDebugDrawSettings, LineWidthMultiplier) == 0x14, "Offset mismatch for FDataflowNodeDebugDrawSettings::LineWidthMultiplier");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FDataflowDynamicConnections
{
    TArray<FDataflowAllTypes> DynamicProperties; // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_10[0x68]; // 0x10 (Size: 0x68, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowDynamicConnections) == 0x78, "Size mismatch for FDataflowDynamicConnections");
static_assert(offsetof(FDataflowDynamicConnections, DynamicProperties) == 0x0, "Offset mismatch for FDataflowDynamicConnections::DynamicProperties");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FStringValuePair
{
    FString Key; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FStringValuePair) == 0x20, "Size mismatch for FStringValuePair");
static_assert(offsetof(FStringValuePair, Key) == 0x0, "Offset mismatch for FStringValuePair::Key");
static_assert(offsetof(FStringValuePair, Value) == 0x10, "Offset mismatch for FStringValuePair::Value");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDataflowVariableOverrides
{
    FInstancedPropertyBag Variables; // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<FGuid> OverriddenVariableGuids; // 0x10 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_20[0x8]; // 0x20 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowVariableOverrides) == 0x28, "Size mismatch for FDataflowVariableOverrides");
static_assert(offsetof(FDataflowVariableOverrides, Variables) == 0x0, "Offset mismatch for FDataflowVariableOverrides::Variables");
static_assert(offsetof(FDataflowVariableOverrides, OverriddenVariableGuids) == 0x10, "Offset mismatch for FDataflowVariableOverrides::OverriddenVariableGuids");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FDataflowInstance
{
    UDataflow* DataflowAsset; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName DataflowTerminal; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FDataflowVariableOverrides VariableOverrides; // 0x10 (Size: 0x28, Type: StructProperty)
    UObject* Owner; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDataflowInstance) == 0x40, "Size mismatch for FDataflowInstance");
static_assert(offsetof(FDataflowInstance, DataflowAsset) == 0x0, "Offset mismatch for FDataflowInstance::DataflowAsset");
static_assert(offsetof(FDataflowInstance, DataflowTerminal) == 0x8, "Offset mismatch for FDataflowInstance::DataflowTerminal");
static_assert(offsetof(FDataflowInstance, VariableOverrides) == 0x10, "Offset mismatch for FDataflowInstance::VariableOverrides");
static_assert(offsetof(FDataflowInstance, Owner) == 0x38, "Offset mismatch for FDataflowInstance::Owner");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FDataflowPreviewCacheParams
{
    int32_t FrameRate; // 0x0 (Size: 0x4, Type: IntProperty)
    FVector2f TimeRange; // 0x4 (Size: 0x8, Type: StructProperty)
    bool bRestartSimulation; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FVector2f RestartTimeRange; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bAsyncCaching; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowPreviewCacheParams) == 0x1c, "Size mismatch for FDataflowPreviewCacheParams");
static_assert(offsetof(FDataflowPreviewCacheParams, FrameRate) == 0x0, "Offset mismatch for FDataflowPreviewCacheParams::FrameRate");
static_assert(offsetof(FDataflowPreviewCacheParams, TimeRange) == 0x4, "Offset mismatch for FDataflowPreviewCacheParams::TimeRange");
static_assert(offsetof(FDataflowPreviewCacheParams, bRestartSimulation) == 0xc, "Offset mismatch for FDataflowPreviewCacheParams::bRestartSimulation");
static_assert(offsetof(FDataflowPreviewCacheParams, RestartTimeRange) == 0x10, "Offset mismatch for FDataflowPreviewCacheParams::RestartTimeRange");
static_assert(offsetof(FDataflowPreviewCacheParams, bAsyncCaching) == 0x18, "Offset mismatch for FDataflowPreviewCacheParams::bAsyncCaching");

// Size: 0x300 (Inherited: 0x270, Single: 0x90)
struct FDataflowSubGraphInputNode : FDataflowNode
{
    uint8_t Pad_270[0x8]; // 0x270 (Size: 0x8, Type: PaddingProperty)
    FDataflowDynamicConnections DynamicConnections; // 0x278 (Size: 0x78, Type: StructProperty)
    FInstancedPropertyBag PropertyBag; // 0x2f0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FDataflowSubGraphInputNode) == 0x300, "Size mismatch for FDataflowSubGraphInputNode");
static_assert(offsetof(FDataflowSubGraphInputNode, DynamicConnections) == 0x278, "Offset mismatch for FDataflowSubGraphInputNode::DynamicConnections");
static_assert(offsetof(FDataflowSubGraphInputNode, PropertyBag) == 0x2f0, "Offset mismatch for FDataflowSubGraphInputNode::PropertyBag");

// Size: 0x300 (Inherited: 0x270, Single: 0x90)
struct FDataflowSubGraphOutputNode : FDataflowNode
{
    uint8_t Pad_270[0x8]; // 0x270 (Size: 0x8, Type: PaddingProperty)
    FDataflowDynamicConnections DynamicConnections; // 0x278 (Size: 0x78, Type: StructProperty)
    FInstancedPropertyBag PropertyBag; // 0x2f0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FDataflowSubGraphOutputNode) == 0x300, "Size mismatch for FDataflowSubGraphOutputNode");
static_assert(offsetof(FDataflowSubGraphOutputNode, DynamicConnections) == 0x278, "Offset mismatch for FDataflowSubGraphOutputNode::DynamicConnections");
static_assert(offsetof(FDataflowSubGraphOutputNode, PropertyBag) == 0x2f0, "Offset mismatch for FDataflowSubGraphOutputNode::PropertyBag");

// Size: 0x3b0 (Inherited: 0x270, Single: 0x140)
struct FDataflowCallSubGraphNode : FDataflowNode
{
    uint8_t Pad_270[0x10]; // 0x270 (Size: 0x10, Type: PaddingProperty)
    FGuid SubGraphGuid; // 0x280 (Size: 0x10, Type: StructProperty)
    FDataflowDynamicConnections DynamicInputs; // 0x290 (Size: 0x78, Type: StructProperty)
    FInstancedPropertyBag InputsPropertyBag; // 0x308 (Size: 0x10, Type: StructProperty)
    FDataflowDynamicConnections DynamicOutputs; // 0x318 (Size: 0x78, Type: StructProperty)
    FInstancedPropertyBag OutputsPropertyBag; // 0x390 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_3a0[0x10]; // 0x3a0 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FDataflowCallSubGraphNode) == 0x3b0, "Size mismatch for FDataflowCallSubGraphNode");
static_assert(offsetof(FDataflowCallSubGraphNode, SubGraphGuid) == 0x280, "Offset mismatch for FDataflowCallSubGraphNode::SubGraphGuid");
static_assert(offsetof(FDataflowCallSubGraphNode, DynamicInputs) == 0x290, "Offset mismatch for FDataflowCallSubGraphNode::DynamicInputs");
static_assert(offsetof(FDataflowCallSubGraphNode, InputsPropertyBag) == 0x308, "Offset mismatch for FDataflowCallSubGraphNode::InputsPropertyBag");
static_assert(offsetof(FDataflowCallSubGraphNode, DynamicOutputs) == 0x318, "Offset mismatch for FDataflowCallSubGraphNode::DynamicOutputs");
static_assert(offsetof(FDataflowCallSubGraphNode, OutputsPropertyBag) == 0x390, "Offset mismatch for FDataflowCallSubGraphNode::OutputsPropertyBag");

// Size: 0x2a0 (Inherited: 0x4e0, Single: 0xfffffdc0)
struct FDataflowTextureTerminalNode : FDataflowTerminalNode
{
    FDataflowImage Image; // 0x270 (Size: 0x28, Type: StructProperty)
    UTexture2D* TextureAsset; // 0x298 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDataflowTextureTerminalNode) == 0x2a0, "Size mismatch for FDataflowTextureTerminalNode");
static_assert(offsetof(FDataflowTextureTerminalNode, Image) == 0x270, "Offset mismatch for FDataflowTextureTerminalNode::Image");
static_assert(offsetof(FDataflowTextureTerminalNode, TextureAsset) == 0x298, "Offset mismatch for FDataflowTextureTerminalNode::TextureAsset");

// Size: 0x2a8 (Inherited: 0x270, Single: 0x38)
struct FGetDataflowVariableNode : FDataflowNode
{
    FDataflowAnyType Value; // 0x270 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_271[0x7]; // 0x271 (Size: 0x7, Type: PaddingProperty)
    FInstancedPropertyBag VariablePropertyBag; // 0x278 (Size: 0x10, Type: StructProperty)
    FName VariableName; // 0x288 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_28c[0x1c]; // 0x28c (Size: 0x1c, Type: PaddingProperty)
};

static_assert(sizeof(FGetDataflowVariableNode) == 0x2a8, "Size mismatch for FGetDataflowVariableNode");
static_assert(offsetof(FGetDataflowVariableNode, Value) == 0x270, "Offset mismatch for FGetDataflowVariableNode::Value");
static_assert(offsetof(FGetDataflowVariableNode, VariablePropertyBag) == 0x278, "Offset mismatch for FGetDataflowVariableNode::VariablePropertyBag");
static_assert(offsetof(FGetDataflowVariableNode, VariableName) == 0x288, "Offset mismatch for FGetDataflowVariableNode::VariableName");

