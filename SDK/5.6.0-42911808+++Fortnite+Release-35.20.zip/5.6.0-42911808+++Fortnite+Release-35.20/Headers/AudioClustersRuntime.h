/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioClustersRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UAudioClusterConfig : public UObject
{
public:
    UAudioClusterBehavior* Behavior; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UAudioClusterConfig) == 0x30, "Size mismatch for UAudioClusterConfig");
static_assert(offsetof(UAudioClusterConfig, Behavior) == 0x28, "Offset mismatch for UAudioClusterConfig::Behavior");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UAudioClusterConfigMap : public UObject
{
public:
    TMap<UAudioClusterConfig*, FGameplayTag> TagConfigMap; // 0x28 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UAudioClusterConfigMap) == 0x78, "Size mismatch for UAudioClusterConfigMap");
static_assert(offsetof(UAudioClusterConfigMap, TagConfigMap) == 0x28, "Offset mismatch for UAudioClusterConfigMap::TagConfigMap");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UAudioClusterBehavior : public UObject
{
public:

protected:
    virtual void OnActorAdded(AActor*& Actor); // 0xbff5700 (Index: 0x0, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void OnActorRemoved(AActor*& Actor); // 0xb084c90 (Index: 0x1, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void OnPositionUpdated(const FVector Position); // 0x1146619c (Index: 0x2, Flags: Native|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent)
    virtual void OnSizeUpdated(int32_t& Size); // 0x11466280 (Index: 0x3, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void OnStart(); // 0x41f1e2c (Index: 0x4, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void OnStop(); // 0xa20b3a8 (Index: 0x5, Flags: Native|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UAudioClusterBehavior) == 0x30, "Size mismatch for UAudioClusterBehavior");

// Size: 0x38 (Inherited: 0x88, Single: 0xffffffb0)
class UAudioClustersSubsystem : public UWorldSubsystem
{
public:

public:
    bool AddConfigMap(UAudioClusterConfigMap*& Map); // 0x11466064 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool Register(const FAudioClusterActorInfo ActorInfo); // 0x114663ac (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool RegisterOneShot(const FAudioClusterOneShotInfo OneShotInfo); // 0x1146648c (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool RemoveConfigMap(UAudioClusterConfigMap*& Map); // 0x11466588 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void SetListenerPosition(const FVector InListenerPosition); // 0x1146678c (Index: 0x4, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    bool SetParam(const FGameplayTag Tag, double& Value); // 0x1146686c (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool Unregister(const FAudioClusterActorInfo ActorInfo); // 0x114669fc (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UpdateClusters(float& DeltaTimeSeconds); // 0x11466adc (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioClustersSubsystem) == 0x38, "Size mismatch for UAudioClustersSubsystem");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FAudioClusterActorInfo
{
    TWeakObjectPtr<AActor*> Actor; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTag Tag; // 0x8 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FAudioClusterActorInfo) == 0xc, "Size mismatch for FAudioClusterActorInfo");
static_assert(offsetof(FAudioClusterActorInfo, Actor) == 0x0, "Offset mismatch for FAudioClusterActorInfo::Actor");
static_assert(offsetof(FAudioClusterActorInfo, Tag) == 0x8, "Offset mismatch for FAudioClusterActorInfo::Tag");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FAudioClusterOneShotInfo
{
    FGameplayTag Tag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector Position; // 0x8 (Size: 0x18, Type: StructProperty)
    float LifetimeSeconds; // 0x20 (Size: 0x4, Type: FloatProperty)
    float TimeRemainingSeconds; // 0x24 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FAudioClusterOneShotInfo) == 0x28, "Size mismatch for FAudioClusterOneShotInfo");
static_assert(offsetof(FAudioClusterOneShotInfo, Tag) == 0x0, "Offset mismatch for FAudioClusterOneShotInfo::Tag");
static_assert(offsetof(FAudioClusterOneShotInfo, Position) == 0x8, "Offset mismatch for FAudioClusterOneShotInfo::Position");
static_assert(offsetof(FAudioClusterOneShotInfo, LifetimeSeconds) == 0x20, "Offset mismatch for FAudioClusterOneShotInfo::LifetimeSeconds");
static_assert(offsetof(FAudioClusterOneShotInfo, TimeRemainingSeconds) == 0x24, "Offset mismatch for FAudioClusterOneShotInfo::TimeRemainingSeconds");

