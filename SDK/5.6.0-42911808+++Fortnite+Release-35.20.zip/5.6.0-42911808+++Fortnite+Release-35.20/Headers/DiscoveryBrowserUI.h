/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DiscoveryBrowserUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ModelViewViewModel.h"
#include "CommonUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "FortniteUI.h"
#include "Engine.h"
#include "CommonUILegacy.h"
#include "FortniteGame.h"
#include "Party.h"

// Size: 0x98 (Inherited: 0x90, Single: 0x8)
class UDiscoverSelectedActivityViewModel : public UMVVMViewModelBase
{
public:
    bool bLoading; // 0x68 (Size: 0x1, Type: BoolProperty)
    bool bHasPartyData; // 0x69 (Size: 0x1, Type: BoolProperty)
    bool bIsLibrary; // 0x6a (Size: 0x1, Type: BoolProperty)
    bool bIsActiveInvite; // 0x6b (Size: 0x1, Type: BoolProperty)
    bool bIsPartyPrivate; // 0x6c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6d[0x3]; // 0x6d (Size: 0x3, Type: PaddingProperty)
    int32_t CurrentPartySize; // 0x70 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FText RichPresenceText; // 0x78 (Size: 0x10, Type: TextProperty)
    UFortActivityViewModel* ActivityVM; // 0x88 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_90[0x8]; // 0x90 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDiscoverSelectedActivityViewModel) == 0x98, "Size mismatch for UDiscoverSelectedActivityViewModel");
static_assert(offsetof(UDiscoverSelectedActivityViewModel, bLoading) == 0x68, "Offset mismatch for UDiscoverSelectedActivityViewModel::bLoading");
static_assert(offsetof(UDiscoverSelectedActivityViewModel, bHasPartyData) == 0x69, "Offset mismatch for UDiscoverSelectedActivityViewModel::bHasPartyData");
static_assert(offsetof(UDiscoverSelectedActivityViewModel, bIsLibrary) == 0x6a, "Offset mismatch for UDiscoverSelectedActivityViewModel::bIsLibrary");
static_assert(offsetof(UDiscoverSelectedActivityViewModel, bIsActiveInvite) == 0x6b, "Offset mismatch for UDiscoverSelectedActivityViewModel::bIsActiveInvite");
static_assert(offsetof(UDiscoverSelectedActivityViewModel, bIsPartyPrivate) == 0x6c, "Offset mismatch for UDiscoverSelectedActivityViewModel::bIsPartyPrivate");
static_assert(offsetof(UDiscoverSelectedActivityViewModel, CurrentPartySize) == 0x70, "Offset mismatch for UDiscoverSelectedActivityViewModel::CurrentPartySize");
static_assert(offsetof(UDiscoverSelectedActivityViewModel, RichPresenceText) == 0x78, "Offset mismatch for UDiscoverSelectedActivityViewModel::RichPresenceText");
static_assert(offsetof(UDiscoverSelectedActivityViewModel, ActivityVM) == 0x88, "Offset mismatch for UDiscoverSelectedActivityViewModel::ActivityVM");

// Size: 0x1550 (Inherited: 0x30d0, Single: 0xffffe480)
class UFortActivityBrowserLibraryTile : public UFortActivityBrowserTileBase
{
public:
    uint8_t Pad_1500[0x10]; // 0x1500 (Size: 0x10, Type: PaddingProperty)
    UFortSidebarOnboardTooltipWidget* OnboardingTooltip; // 0x1510 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1518[0x38]; // 0x1518 (Size: 0x38, Type: PaddingProperty)
};

static_assert(sizeof(UFortActivityBrowserLibraryTile) == 0x1550, "Size mismatch for UFortActivityBrowserLibraryTile");
static_assert(offsetof(UFortActivityBrowserLibraryTile, OnboardingTooltip) == 0x1510, "Offset mismatch for UFortActivityBrowserLibraryTile::OnboardingTooltip");

// Size: 0x1500 (Inherited: 0x1bd0, Single: 0xfffff930)
class UFortActivityBrowserTileBase : public UCommonButtonBase
{
public:
};

static_assert(sizeof(UFortActivityBrowserTileBase) == 0x1500, "Size mismatch for UFortActivityBrowserTileBase");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UFortActivityListItemWrapper : public UObject
{
public:
};

static_assert(sizeof(UFortActivityListItemWrapper) == 0x38, "Size mismatch for UFortActivityListItemWrapper");

// Size: 0x3f0 (Inherited: 0xb08, Single: 0xfffff8e8)
class UFortDiscoverBrowserGridRow : public UFortActivityBrowserRow
{
public:
    uint8_t Pad_3d8[0x8]; // 0x3d8 (Size: 0x8, Type: PaddingProperty)
    int32_t ItemIndexRepresented; // 0x3e0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_3e4[0x4]; // 0x3e4 (Size: 0x4, Type: PaddingProperty)
    bool bSupportLessThanMaxVisibleSubRows; // 0x3e8 (Size: 0x1, Type: BoolProperty)
    bool bUseSizeShiftedFocusOffset; // 0x3e9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3ea[0x6]; // 0x3ea (Size: 0x6, Type: PaddingProperty)

public:
    int32_t GetFirstVisibleSubRow() const; // 0x11081b5c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumberOfVisibleSubRows() const; // 0x11081de4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetSupportsLessThanMaxVisibleRows(); // 0x11081e54 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void HandleActivitySelected(int32_t& Index, int32_t& IndexInRow); // 0x11081ed0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void NavigateWithinGrid(int32_t& Row); // 0x110831ec (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    virtual void OpenNestedSurface(UFortDiscoverSurfaceTileItemVM*& const SurfaceTileItemVM); // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintEvent)
    virtual void SetFocusOffset(int32_t& FocusOffset, bool& bSelectFromBelow); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintEvent)
    void SetMaxVisibleRows(int32_t& MaxRowsShown); // 0x11084418 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    bool ShouldUseSizeShiftedFocusOffset(); // 0x11084970 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    virtual void UpdateAnalyticsStates(bool& bStopImpressions); // 0x288a61c (Index: 0xb, Flags: Event|Public|BlueprintEvent)

protected:
    virtual UFortDiscoverProviderViewModel* GetPanelViewModel(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void SetPanelViewModel(UFortDiscoverProviderViewModel*& ViewModel); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortDiscoverBrowserGridRow) == 0x3f0, "Size mismatch for UFortDiscoverBrowserGridRow");
static_assert(offsetof(UFortDiscoverBrowserGridRow, ItemIndexRepresented) == 0x3e0, "Offset mismatch for UFortDiscoverBrowserGridRow::ItemIndexRepresented");
static_assert(offsetof(UFortDiscoverBrowserGridRow, bSupportLessThanMaxVisibleSubRows) == 0x3e8, "Offset mismatch for UFortDiscoverBrowserGridRow::bSupportLessThanMaxVisibleSubRows");
static_assert(offsetof(UFortDiscoverBrowserGridRow, bUseSizeShiftedFocusOffset) == 0x3e9, "Offset mismatch for UFortDiscoverBrowserGridRow::bUseSizeShiftedFocusOffset");

// Size: 0x3d8 (Inherited: 0x730, Single: 0xfffffca8)
class UFortActivityBrowserRow : public UCommonUserWidget
{
public:
    uint8_t Pad_2d8[0x18]; // 0x2d8 (Size: 0x18, Type: PaddingProperty)
    int32_t MinimumVisibilityPercentageForRowActivation; // 0x2f0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2f4[0x4]; // 0x2f4 (Size: 0x4, Type: PaddingProperty)
    UFortDiscoverItemSelectorBase* OverrideItemSelector; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UFortDiscoverSurfaceViewModel* SurfaceViewModel; // 0x300 (Size: 0x8, Type: ObjectProperty)
    uint8_t PanelViewModelSource; // 0x308 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_309[0x7]; // 0x309 (Size: 0x7, Type: PaddingProperty)
    UFortNestedButtonGroupSelectionVM* NestedButtonGroupSelectionVM; // 0x310 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_318[0xb0]; // 0x318 (Size: 0xb0, Type: PaddingProperty)
    UCommonTextBlock* Text_CategoryName; // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_3d0[0x8]; // 0x3d0 (Size: 0x8, Type: PaddingProperty)

public:
    bool GetIsActive() const; // 0x11081c40 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsInPeekState() const; // 0x11081c58 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsSelected() const; // 0x11081c80 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual int32_t GetNumDisplayedSubRows() const; // 0x11081d94 (Index: 0x3, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual int32_t GetNumItemsPerRow() const; // 0x11081dbc (Index: 0x4, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)

protected:
    virtual void OnCategoryItemChanged(bool& const bPlayAnimation, const FName CategoryPanelName); // 0x288a61c (Index: 0x5, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnCategoryTextChanged(const FText CategoryText, const FText CategorySubtitle); // 0x288a61c (Index: 0x6, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnOverrideItemSelectorSet(UFortDiscoverItemSelectorBase*& const ItemSelector); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowIsActiveChanged(bool& const bIsActive); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowIsSelectedChanged(bool& const bIsSelected); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowMoveDown(bool& const bMovingOffscreen); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowMoveUp(bool& const bMovingOffscreen); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowPeekStateChanged(bool& const bIsInPeekState); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortActivityBrowserRow) == 0x3d8, "Size mismatch for UFortActivityBrowserRow");
static_assert(offsetof(UFortActivityBrowserRow, MinimumVisibilityPercentageForRowActivation) == 0x2f0, "Offset mismatch for UFortActivityBrowserRow::MinimumVisibilityPercentageForRowActivation");
static_assert(offsetof(UFortActivityBrowserRow, OverrideItemSelector) == 0x2f8, "Offset mismatch for UFortActivityBrowserRow::OverrideItemSelector");
static_assert(offsetof(UFortActivityBrowserRow, SurfaceViewModel) == 0x300, "Offset mismatch for UFortActivityBrowserRow::SurfaceViewModel");
static_assert(offsetof(UFortActivityBrowserRow, PanelViewModelSource) == 0x308, "Offset mismatch for UFortActivityBrowserRow::PanelViewModelSource");
static_assert(offsetof(UFortActivityBrowserRow, NestedButtonGroupSelectionVM) == 0x310, "Offset mismatch for UFortActivityBrowserRow::NestedButtonGroupSelectionVM");
static_assert(offsetof(UFortActivityBrowserRow, Text_CategoryName) == 0x3c8, "Offset mismatch for UFortActivityBrowserRow::Text_CategoryName");

// Size: 0x438 (Inherited: 0xf60, Single: 0xfffff4d8)
class UFortDiscoverHomespace : public UScrollableActivatableWidget
{
public:
    UWidget* HomebarWidget; // 0x428 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_430[0x8]; // 0x430 (Size: 0x8, Type: PaddingProperty)

protected:
    float GetHomebarPeekPercentage() const; // 0x11081b8c (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void RefreshPeekPushPercentage(); // 0x60769a4 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    void SendHomespaceSubviewEvent(UWidget*& const SubWidget, FString& Text) const; // 0x11083ad4 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable|Const)
    bool ShouldUseHomebarPeekPercentageOnMobile() const; // 0x11084954 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void ShowDownloadStartedTooltip(FString& TooltipDescription); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void UpdatePeekPercentageFromHomebarHeight(double& const HomebarHeight) const; // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent|Const)
};

static_assert(sizeof(UFortDiscoverHomespace) == 0x438, "Size mismatch for UFortDiscoverHomespace");
static_assert(offsetof(UFortDiscoverHomespace, HomebarWidget) == 0x428, "Offset mismatch for UFortDiscoverHomespace::HomebarWidget");

// Size: 0x108 (Inherited: 0x28, Single: 0xe0)
class UFortDiscoverPreviewManager : public UObject
{
public:
};

static_assert(sizeof(UFortDiscoverPreviewManager) == 0x108, "Size mismatch for UFortDiscoverPreviewManager");

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class UFortActivityBrowserColorSchemeAsset : public UDataAsset
{
public:
    TMap<FColorSchemeParamaterValues, UMaterialParameterCollection*> MaterialCollectionOverrides; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UFortActivityBrowserColorSchemeAsset) == 0x80, "Size mismatch for UFortActivityBrowserColorSchemeAsset");
static_assert(offsetof(UFortActivityBrowserColorSchemeAsset, MaterialCollectionOverrides) == 0x30, "Offset mismatch for UFortActivityBrowserColorSchemeAsset::MaterialCollectionOverrides");

// Size: 0x500 (Inherited: 0x438, Single: 0xc8)
class UFortActivityBrowserListView : public UListViewBase
{
public:
    uint8_t Pad_290[0xe8]; // 0x290 (Size: 0xe8, Type: PaddingProperty)
    float DirectionalNavigationTimeThreshold; // 0x378 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_37c[0x4]; // 0x37c (Size: 0x4, Type: PaddingProperty)
    UClass* DiscoverItemRowClass; // 0x380 (Size: 0x8, Type: ClassProperty)
    UClass* HomebarItemRowClass; // 0x388 (Size: 0x8, Type: ClassProperty)
    UClass* BannerItemRowClass; // 0x390 (Size: 0x8, Type: ClassProperty)
    UClass* NonScrollingItemRowClass; // 0x398 (Size: 0x8, Type: ClassProperty)
    UClass* ScrollingViewModelItemRowClass; // 0x3a0 (Size: 0x8, Type: ClassProperty)
    TMap<UClass*, FName> RowTypes; // 0x3a8 (Size: 0x50, Type: MapProperty)
    UFortDiscoverItemSelectorBase* OverrideItemSelector; // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    UFortDiscoverSurfaceViewModel* SurfaceViewModel; // 0x400 (Size: 0x8, Type: ObjectProperty)
    bool bAllowNonFullGridRows; // 0x408 (Size: 0x1, Type: BoolProperty)
    bool bUseTinyOffsetWhenScrollingIntoView; // 0x409 (Size: 0x1, Type: BoolProperty)
    bool bAllowInternalRowSelection; // 0x40a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_40b[0xf5]; // 0x40b (Size: 0xf5, Type: PaddingProperty)

public:
    void NavigateToActivityInFirstRow(int32_t& ActivityItemIndex, bool& bRequestNavigationToItem); // 0x581fda8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    bool NavigateToCategory(FName& const ActivityCategoryName, bool& bAnimateScroll); // 0x11082fa4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    bool ScrollListViewToNextRow(); // 0x11083a64 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void ScrollToTopOfSelectedCategory(); // 0x11083a88 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SetAllowInternalRowSelection(bool& const bInAllowInternalRowSelection); // 0x110842ec (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void HandleVisibleEntriesChanged(); // 0x11082b84 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortActivityBrowserListView) == 0x500, "Size mismatch for UFortActivityBrowserListView");
static_assert(offsetof(UFortActivityBrowserListView, DirectionalNavigationTimeThreshold) == 0x378, "Offset mismatch for UFortActivityBrowserListView::DirectionalNavigationTimeThreshold");
static_assert(offsetof(UFortActivityBrowserListView, DiscoverItemRowClass) == 0x380, "Offset mismatch for UFortActivityBrowserListView::DiscoverItemRowClass");
static_assert(offsetof(UFortActivityBrowserListView, HomebarItemRowClass) == 0x388, "Offset mismatch for UFortActivityBrowserListView::HomebarItemRowClass");
static_assert(offsetof(UFortActivityBrowserListView, BannerItemRowClass) == 0x390, "Offset mismatch for UFortActivityBrowserListView::BannerItemRowClass");
static_assert(offsetof(UFortActivityBrowserListView, NonScrollingItemRowClass) == 0x398, "Offset mismatch for UFortActivityBrowserListView::NonScrollingItemRowClass");
static_assert(offsetof(UFortActivityBrowserListView, ScrollingViewModelItemRowClass) == 0x3a0, "Offset mismatch for UFortActivityBrowserListView::ScrollingViewModelItemRowClass");
static_assert(offsetof(UFortActivityBrowserListView, RowTypes) == 0x3a8, "Offset mismatch for UFortActivityBrowserListView::RowTypes");
static_assert(offsetof(UFortActivityBrowserListView, OverrideItemSelector) == 0x3f8, "Offset mismatch for UFortActivityBrowserListView::OverrideItemSelector");
static_assert(offsetof(UFortActivityBrowserListView, SurfaceViewModel) == 0x400, "Offset mismatch for UFortActivityBrowserListView::SurfaceViewModel");
static_assert(offsetof(UFortActivityBrowserListView, bAllowNonFullGridRows) == 0x408, "Offset mismatch for UFortActivityBrowserListView::bAllowNonFullGridRows");
static_assert(offsetof(UFortActivityBrowserListView, bUseTinyOffsetWhenScrollingIntoView) == 0x409, "Offset mismatch for UFortActivityBrowserListView::bUseTinyOffsetWhenScrollingIntoView");
static_assert(offsetof(UFortActivityBrowserListView, bAllowInternalRowSelection) == 0x40a, "Offset mismatch for UFortActivityBrowserListView::bAllowInternalRowSelection");

// Size: 0x15d0 (Inherited: 0x30d0, Single: 0xffffe500)
class UFortActivityBrowserPlayWithFriendsTile : public UFortActivityBrowserTileBase
{
public:
    uint8_t Pad_1500[0x8]; // 0x1500 (Size: 0x8, Type: PaddingProperty)
    int32_t MaxNamesToDisplay; // 0x1508 (Size: 0x4, Type: IntProperty)
    int32_t MaxPortraitsToDisplay; // 0x150c (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1510[0x10]; // 0x1510 (Size: 0x10, Type: PaddingProperty)
    UFortJoinablePartyPortraitsDisplay* PartyMembersAvatarsDisplay; // 0x1520 (Size: 0x8, Type: ObjectProperty)
    bool bIsActiveInvite; // 0x1528 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1529[0x3]; // 0x1529 (Size: 0x3, Type: PaddingProperty)
    int32_t CurrentPartySize; // 0x152c (Size: 0x4, Type: IntProperty)
    bool bIsPartyPrivate; // 0x1530 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1531[0x7]; // 0x1531 (Size: 0x7, Type: PaddingProperty)
    UFortGameActivity* CachedGameActivity; // 0x1538 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1540[0x10]; // 0x1540 (Size: 0x10, Type: PaddingProperty)
    TWeakObjectPtr<USocialUser*> CachedTargetSocialUser; // 0x1550 (Size: 0x8, Type: WeakObjectProperty)
    FText CurrentCTAButtonText; // 0x1558 (Size: 0x10, Type: TextProperty)
    FText JoinPartyText; // 0x1568 (Size: 0x10, Type: TextProperty)
    FText RequestToJoinText; // 0x1578 (Size: 0x10, Type: TextProperty)
    FDataTableRowHandle JoinFriendInputAction_Touch; // 0x1588 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_1598[0x38]; // 0x1598 (Size: 0x38, Type: PaddingProperty)

public:
    FText GetCTAButtonText(); // 0x11081a9c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void BP_PartyInformationUpdated(bool& bInIsTileSelected); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    int32_t GetMaxPartySize() const; // 0x11081d0c (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void HandleCTAButtonClicked(); // 0x110820f8 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnGameActivityChanged(UFortGameActivity*& GameActivity); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTextureBeginLoading(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTextureLoadingComplete(UTexture*& const ThumbnailTexture); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTileActiveChanged(bool& const bIsTileActive); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUpdateColumnSize(int32_t& NewColumnSize); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    void OpenSidebar(); // 0x110838bc (Index: 0x9, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void UpdateCTAButtonInfo(const FText InteractionText, bool& const bInteractionFound); // 0x288a61c (Index: 0xa, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void UpdateCTAButtonInteraction(bool& const bIsInteractionEnabled); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
    virtual void UpdateIslandThumbnail(UTexture*& const ThumbnailTexture); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void UpdateLastInteraction(const FText LastInteraction); // 0x288a61c (Index: 0xd, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void UpdateOtherPlayersSubText(const FText OtherPlayersSubText); // 0x288a61c (Index: 0xe, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void UpdatePartyMemberNames(const FText Names); // 0x288a61c (Index: 0xf, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void UpdateRichPresence(const FText RichPresence); // 0x288a61c (Index: 0x10, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void UpdateSingleFriendName(const FText SingleFriendName); // 0x288a61c (Index: 0x11, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortActivityBrowserPlayWithFriendsTile) == 0x15d0, "Size mismatch for UFortActivityBrowserPlayWithFriendsTile");
static_assert(offsetof(UFortActivityBrowserPlayWithFriendsTile, MaxNamesToDisplay) == 0x1508, "Offset mismatch for UFortActivityBrowserPlayWithFriendsTile::MaxNamesToDisplay");
static_assert(offsetof(UFortActivityBrowserPlayWithFriendsTile, MaxPortraitsToDisplay) == 0x150c, "Offset mismatch for UFortActivityBrowserPlayWithFriendsTile::MaxPortraitsToDisplay");
static_assert(offsetof(UFortActivityBrowserPlayWithFriendsTile, PartyMembersAvatarsDisplay) == 0x1520, "Offset mismatch for UFortActivityBrowserPlayWithFriendsTile::PartyMembersAvatarsDisplay");
static_assert(offsetof(UFortActivityBrowserPlayWithFriendsTile, bIsActiveInvite) == 0x1528, "Offset mismatch for UFortActivityBrowserPlayWithFriendsTile::bIsActiveInvite");
static_assert(offsetof(UFortActivityBrowserPlayWithFriendsTile, CurrentPartySize) == 0x152c, "Offset mismatch for UFortActivityBrowserPlayWithFriendsTile::CurrentPartySize");
static_assert(offsetof(UFortActivityBrowserPlayWithFriendsTile, bIsPartyPrivate) == 0x1530, "Offset mismatch for UFortActivityBrowserPlayWithFriendsTile::bIsPartyPrivate");
static_assert(offsetof(UFortActivityBrowserPlayWithFriendsTile, CachedGameActivity) == 0x1538, "Offset mismatch for UFortActivityBrowserPlayWithFriendsTile::CachedGameActivity");
static_assert(offsetof(UFortActivityBrowserPlayWithFriendsTile, CachedTargetSocialUser) == 0x1550, "Offset mismatch for UFortActivityBrowserPlayWithFriendsTile::CachedTargetSocialUser");
static_assert(offsetof(UFortActivityBrowserPlayWithFriendsTile, CurrentCTAButtonText) == 0x1558, "Offset mismatch for UFortActivityBrowserPlayWithFriendsTile::CurrentCTAButtonText");
static_assert(offsetof(UFortActivityBrowserPlayWithFriendsTile, JoinPartyText) == 0x1568, "Offset mismatch for UFortActivityBrowserPlayWithFriendsTile::JoinPartyText");
static_assert(offsetof(UFortActivityBrowserPlayWithFriendsTile, RequestToJoinText) == 0x1578, "Offset mismatch for UFortActivityBrowserPlayWithFriendsTile::RequestToJoinText");
static_assert(offsetof(UFortActivityBrowserPlayWithFriendsTile, JoinFriendInputAction_Touch) == 0x1588, "Offset mismatch for UFortActivityBrowserPlayWithFriendsTile::JoinFriendInputAction_Touch");

// Size: 0x3f8 (Inherited: 0xb08, Single: 0xfffff8f0)
class UFortActivityBrowserRowList : public UFortActivityBrowserRow
{
public:
    UFortActivityListView* ListView_Activities; // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PageLeft; // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PageRight; // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_3f0[0x8]; // 0x3f0 (Size: 0x8, Type: PaddingProperty)

public:
    virtual void OnQueryStatusChanged(bool& bIsActive); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFortActivityBrowserRowList) == 0x3f8, "Size mismatch for UFortActivityBrowserRowList");
static_assert(offsetof(UFortActivityBrowserRowList, ListView_Activities) == 0x3d8, "Offset mismatch for UFortActivityBrowserRowList::ListView_Activities");
static_assert(offsetof(UFortActivityBrowserRowList, Button_PageLeft) == 0x3e0, "Offset mismatch for UFortActivityBrowserRowList::Button_PageLeft");
static_assert(offsetof(UFortActivityBrowserRowList, Button_PageRight) == 0x3e8, "Offset mismatch for UFortActivityBrowserRowList::Button_PageRight");

// Size: 0x6d0 (Inherited: 0x14b8, Single: 0xfffff218)
class UFortActivityBrowserRowView : public UFortActivityBrowserView
{
public:
    uint8_t Pad_528[0x8]; // 0x528 (Size: 0x8, Type: PaddingProperty)
    float MouseWheelScrollTimeThreshold; // 0x530 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_534[0x4]; // 0x534 (Size: 0x4, Type: PaddingProperty)
    UFortActivityBrowserListView* BrowserList_Activities; // 0x538 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_540[0x68]; // 0x540 (Size: 0x68, Type: PaddingProperty)
    FName TabNameID; // 0x5a8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_5ac[0x4]; // 0x5ac (Size: 0x4, Type: PaddingProperty)
    FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x5b0 (Size: 0xf0, Type: StructProperty)
    UFortSwipePanel* SwipePanel_Navigation; // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    TArray<FName> ActivityProviderFilter; // 0x6a8 (Size: 0x10, Type: ArrayProperty)
    uint8_t ActivityProviderFilterType; // 0x6b8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_6b9[0x17]; // 0x6b9 (Size: 0x17, Type: PaddingProperty)

public:
    virtual void OnActivityUpdated(); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void OnListViewScrolled(float& ItemOffset, float& DistanceRemaining); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    virtual void OnQueryActivitiesFinished(); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
    virtual void OnRowChanged(int32_t& const NewCategoryIndex); // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintEvent)
    void SetActivityProviderFilter(TArray<FName>& PanelNames, EActivityBrowserFilterType& FilterType); // 0x11083f00 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void SetSurfaceViewModel(UFortDiscoverSurfaceViewModel*& SurfaceViewModel); // 0x11084674 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)

private:
    void HandleVerticalSwipe(int32_t& const Direction); // 0x11082a5c (Index: 0x2, Flags: Final|Native|Private|BlueprintCallable)

protected:
    virtual void BP_OnSwipeDownAtEnd(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnSwipeUpAtStart(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortActivityBrowserRowView) == 0x6d0, "Size mismatch for UFortActivityBrowserRowView");
static_assert(offsetof(UFortActivityBrowserRowView, MouseWheelScrollTimeThreshold) == 0x530, "Offset mismatch for UFortActivityBrowserRowView::MouseWheelScrollTimeThreshold");
static_assert(offsetof(UFortActivityBrowserRowView, BrowserList_Activities) == 0x538, "Offset mismatch for UFortActivityBrowserRowView::BrowserList_Activities");
static_assert(offsetof(UFortActivityBrowserRowView, TabNameID) == 0x5a8, "Offset mismatch for UFortActivityBrowserRowView::TabNameID");
static_assert(offsetof(UFortActivityBrowserRowView, TabButtonLabelInfo) == 0x5b0, "Offset mismatch for UFortActivityBrowserRowView::TabButtonLabelInfo");
static_assert(offsetof(UFortActivityBrowserRowView, SwipePanel_Navigation) == 0x6a0, "Offset mismatch for UFortActivityBrowserRowView::SwipePanel_Navigation");
static_assert(offsetof(UFortActivityBrowserRowView, ActivityProviderFilter) == 0x6a8, "Offset mismatch for UFortActivityBrowserRowView::ActivityProviderFilter");
static_assert(offsetof(UFortActivityBrowserRowView, ActivityProviderFilterType) == 0x6b8, "Offset mismatch for UFortActivityBrowserRowView::ActivityProviderFilterType");

// Size: 0x528 (Inherited: 0xf90, Single: 0xfffff598)
class UFortActivityBrowserView : public UFortActivityView
{
public:
    bool bShowCustomMatchmakingModalButton; // 0x458 (Size: 0x1, Type: BoolProperty)
    bool bShowSpectateMatchModalButton; // 0x459 (Size: 0x1, Type: BoolProperty)
    bool bShowMobileGameDetailsButton; // 0x45a (Size: 0x1, Type: BoolProperty)
    bool bShowMobileAcceptButton; // 0x45b (Size: 0x1, Type: BoolProperty)
    bool bShowBackToTopButton; // 0x45c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_45d[0x3]; // 0x45d (Size: 0x3, Type: PaddingProperty)
    FName DiscoverySurfaceName; // 0x460 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_464[0xc4]; // 0x464 (Size: 0xc4, Type: PaddingProperty)

public:
    EFortInvalidActivityReason GetInvalidActivityReason() const; // 0x11081c08 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    virtual void OnSurfaceDataDirty(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortActivityBrowserView) == 0x528, "Size mismatch for UFortActivityBrowserView");
static_assert(offsetof(UFortActivityBrowserView, bShowCustomMatchmakingModalButton) == 0x458, "Offset mismatch for UFortActivityBrowserView::bShowCustomMatchmakingModalButton");
static_assert(offsetof(UFortActivityBrowserView, bShowSpectateMatchModalButton) == 0x459, "Offset mismatch for UFortActivityBrowserView::bShowSpectateMatchModalButton");
static_assert(offsetof(UFortActivityBrowserView, bShowMobileGameDetailsButton) == 0x45a, "Offset mismatch for UFortActivityBrowserView::bShowMobileGameDetailsButton");
static_assert(offsetof(UFortActivityBrowserView, bShowMobileAcceptButton) == 0x45b, "Offset mismatch for UFortActivityBrowserView::bShowMobileAcceptButton");
static_assert(offsetof(UFortActivityBrowserView, bShowBackToTopButton) == 0x45c, "Offset mismatch for UFortActivityBrowserView::bShowBackToTopButton");
static_assert(offsetof(UFortActivityBrowserView, DiscoverySurfaceName) == 0x460, "Offset mismatch for UFortActivityBrowserView::DiscoverySurfaceName");

// Size: 0x1560 (Inherited: 0x30d0, Single: 0xffffe490)
class UFortActivityBrowserTile : public UFortActivityBrowserTileBase
{
public:
    uint8_t Pad_1500[0x8]; // 0x1500 (Size: 0x8, Type: PaddingProperty)
    UFortActivityTileDetailsDisplay* Display_TileDetails; // 0x1508 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1510[0x50]; // 0x1510 (Size: 0x50, Type: PaddingProperty)

private:
    void HandleActivitySelected(); // 0x11081e94 (Index: 0x0, Flags: Final|Native|Private)
    void HandleDisplayTileDetailsHoldTriggered(UCommonButtonBase*& Button); // 0x110827a0 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortActivityBrowserTile) == 0x1560, "Size mismatch for UFortActivityBrowserTile");
static_assert(offsetof(UFortActivityBrowserTile, Display_TileDetails) == 0x1508, "Offset mismatch for UFortActivityBrowserTile::Display_TileDetails");

// Size: 0x6a0 (Inherited: 0x1b18, Single: 0xffffeb88)
class UFortActivityCategoryPageView : public UFortActivityPlayerBrowserView
{
public:
    uint8_t Pad_660[0x8]; // 0x660 (Size: 0x8, Type: PaddingProperty)
    UCommonRichTextBlock* Text_CategoryTitle; // 0x668 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_BackToTop; // 0x670 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch; // 0x678 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back; // 0x680 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_MobileAccept; // 0x688 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_MobileShowGameDetails; // 0x690 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_698[0x8]; // 0x698 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortActivityCategoryPageView) == 0x6a0, "Size mismatch for UFortActivityCategoryPageView");
static_assert(offsetof(UFortActivityCategoryPageView, Text_CategoryTitle) == 0x668, "Offset mismatch for UFortActivityCategoryPageView::Text_CategoryTitle");
static_assert(offsetof(UFortActivityCategoryPageView, Button_BackToTop) == 0x670, "Offset mismatch for UFortActivityCategoryPageView::Button_BackToTop");
static_assert(offsetof(UFortActivityCategoryPageView, Button_CloseTouch) == 0x678, "Offset mismatch for UFortActivityCategoryPageView::Button_CloseTouch");
static_assert(offsetof(UFortActivityCategoryPageView, Button_Back) == 0x680, "Offset mismatch for UFortActivityCategoryPageView::Button_Back");
static_assert(offsetof(UFortActivityCategoryPageView, Button_MobileAccept) == 0x688, "Offset mismatch for UFortActivityCategoryPageView::Button_MobileAccept");
static_assert(offsetof(UFortActivityCategoryPageView, Button_MobileShowGameDetails) == 0x690, "Offset mismatch for UFortActivityCategoryPageView::Button_MobileShowGameDetails");

// Size: 0x660 (Inherited: 0x14b8, Single: 0xfffff1a8)
class UFortActivityPlayerBrowserView : public UFortActivityBrowserView
{
public:
    uint8_t Pad_528[0x8]; // 0x528 (Size: 0x8, Type: PaddingProperty)
    UFortGameActivityProvider* ActivityProvider; // 0x530 (Size: 0x8, Type: ObjectProperty)
    UFortActivityTileView* TileView_PlayerActivities; // 0x538 (Size: 0x8, Type: ObjectProperty)
    FName TabNameID; // 0x540 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_544[0xc]; // 0x544 (Size: 0xc, Type: PaddingProperty)
    FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x550 (Size: 0xf0, Type: StructProperty)
    uint8_t PlayHistoryProviderType; // 0x640 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_641[0x1f]; // 0x641 (Size: 0x1f, Type: PaddingProperty)

public:
    void PlayViewIntro(); // 0x110838ec (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void BP_OnTileViewUpdated(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPlayViewIntro(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnQueryActivitiesComplete(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnQueryActivitiesStarted(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortActivityPlayerBrowserView) == 0x660, "Size mismatch for UFortActivityPlayerBrowserView");
static_assert(offsetof(UFortActivityPlayerBrowserView, ActivityProvider) == 0x530, "Offset mismatch for UFortActivityPlayerBrowserView::ActivityProvider");
static_assert(offsetof(UFortActivityPlayerBrowserView, TileView_PlayerActivities) == 0x538, "Offset mismatch for UFortActivityPlayerBrowserView::TileView_PlayerActivities");
static_assert(offsetof(UFortActivityPlayerBrowserView, TabNameID) == 0x540, "Offset mismatch for UFortActivityPlayerBrowserView::TabNameID");
static_assert(offsetof(UFortActivityPlayerBrowserView, TabButtonLabelInfo) == 0x550, "Offset mismatch for UFortActivityPlayerBrowserView::TabButtonLabelInfo");
static_assert(offsetof(UFortActivityPlayerBrowserView, PlayHistoryProviderType) == 0x640, "Offset mismatch for UFortActivityPlayerBrowserView::PlayHistoryProviderType");

// Size: 0x1540 (Inherited: 0x3100, Single: 0xffffe440)
class UFortActivityCategoryTile : public UFortActivityTileViewTileBase
{
public:
    UCommonTextBlock* Text_CategoryTitle; // 0x1530 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1538[0x8]; // 0x1538 (Size: 0x8, Type: PaddingProperty)

protected:
    virtual void OnTileActiveSet(bool& const bIsTileActive); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortActivityCategoryTile) == 0x1540, "Size mismatch for UFortActivityCategoryTile");
static_assert(offsetof(UFortActivityCategoryTile, Text_CategoryTitle) == 0x1530, "Offset mismatch for UFortActivityCategoryTile::Text_CategoryTitle");

// Size: 0x1530 (Inherited: 0x1bd0, Single: 0xfffff960)
class UFortActivityTileViewTileBase : public UCommonButtonBase
{
public:
};

static_assert(sizeof(UFortActivityTileViewTileBase) == 0x1530, "Size mismatch for UFortActivityTileViewTileBase");

// Size: 0x348 (Inherited: 0x730, Single: 0xfffffc18)
class UFortActivityCategoryTilePanel : public UCommonUserWidget
{
public:
    UFortActivityTileView* TileView_Categories; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Title; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    int32_t TileViewQueryThreshold; // 0x2e8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2ec[0x4]; // 0x2ec (Size: 0x4, Type: PaddingProperty)
    UFortCreativeDiscoveryActivityProvider* CachedActivityProvider; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2f8[0x50]; // 0x2f8 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UFortActivityCategoryTilePanel) == 0x348, "Size mismatch for UFortActivityCategoryTilePanel");
static_assert(offsetof(UFortActivityCategoryTilePanel, TileView_Categories) == 0x2d8, "Offset mismatch for UFortActivityCategoryTilePanel::TileView_Categories");
static_assert(offsetof(UFortActivityCategoryTilePanel, Text_Title) == 0x2e0, "Offset mismatch for UFortActivityCategoryTilePanel::Text_Title");
static_assert(offsetof(UFortActivityCategoryTilePanel, TileViewQueryThreshold) == 0x2e8, "Offset mismatch for UFortActivityCategoryTilePanel::TileViewQueryThreshold");
static_assert(offsetof(UFortActivityCategoryTilePanel, CachedActivityProvider) == 0x2f0, "Offset mismatch for UFortActivityCategoryTilePanel::CachedActivityProvider");

// Size: 0x650 (Inherited: 0x14b8, Single: 0xfffff198)
class UFortActivityCategoryView : public UFortActivityBrowserView
{
public:
    uint8_t Pad_528[0x8]; // 0x528 (Size: 0x8, Type: PaddingProperty)
    FName TabNameID; // 0x530 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_534[0xc]; // 0x534 (Size: 0xc, Type: PaddingProperty)
    FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x540 (Size: 0xf0, Type: StructProperty)
    UFortActivityCategoryTilePanel* TilePanel_Featured; // 0x630 (Size: 0x8, Type: ObjectProperty)
    UFortActivityCategoryTilePanel* TilePanel_All; // 0x638 (Size: 0x8, Type: ObjectProperty)
    UFortActivityCategoryTilePanel* CurrentSelectedPanel; // 0x640 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_648[0x8]; // 0x648 (Size: 0x8, Type: PaddingProperty)

protected:
    UFortActivityCategoryTilePanel* GetCurrentSelectedPanel() const; // 0x11081b1c (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual UFortActivityCategoryTilePanel* GetTopMostVisiblePanel() const; // 0x11081e6c (Index: 0x1, Flags: Native|Event|Protected|BlueprintEvent|Const)
    UFortActivityCategoryTilePanel* NavigateFromPanel(EUINavigation& Direction, UFortActivityCategoryTilePanel*& NavigatingPanel); // 0x11082d88 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnCategoryTilePanelSelected(UFortActivityCategoryTilePanel*& const SelectedPanel); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSurfaceDataReady(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortActivityCategoryView) == 0x650, "Size mismatch for UFortActivityCategoryView");
static_assert(offsetof(UFortActivityCategoryView, TabNameID) == 0x530, "Offset mismatch for UFortActivityCategoryView::TabNameID");
static_assert(offsetof(UFortActivityCategoryView, TabButtonLabelInfo) == 0x540, "Offset mismatch for UFortActivityCategoryView::TabButtonLabelInfo");
static_assert(offsetof(UFortActivityCategoryView, TilePanel_Featured) == 0x630, "Offset mismatch for UFortActivityCategoryView::TilePanel_Featured");
static_assert(offsetof(UFortActivityCategoryView, TilePanel_All) == 0x638, "Offset mismatch for UFortActivityCategoryView::TilePanel_All");
static_assert(offsetof(UFortActivityCategoryView, CurrentSelectedPanel) == 0x640, "Offset mismatch for UFortActivityCategoryView::CurrentSelectedPanel");

// Size: 0x7f0 (Inherited: 0x21b8, Single: 0xffffe638)
class UFortActivityCreatorPageView : public UFortActivityCategoryPageView
{
public:
    uint8_t Pad_6a0[0xf8]; // 0x6a0 (Size: 0xf8, Type: PaddingProperty)
    int32_t AmountOfCreatorLinkEntriesQueried; // 0x798 (Size: 0x4, Type: IntProperty)
    int32_t ProcessedCreatorLinkEntries; // 0x79c (Size: 0x4, Type: IntProperty)
    int32_t AmountOfEntriesQueried; // 0x7a0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_7a4[0x4c]; // 0x7a4 (Size: 0x4c, Type: PaddingProperty)

protected:
    virtual void OnCreatorActivitiesQueryFinished(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnNoContentFoundForCreator(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortActivityCreatorPageView) == 0x7f0, "Size mismatch for UFortActivityCreatorPageView");
static_assert(offsetof(UFortActivityCreatorPageView, AmountOfCreatorLinkEntriesQueried) == 0x798, "Offset mismatch for UFortActivityCreatorPageView::AmountOfCreatorLinkEntriesQueried");
static_assert(offsetof(UFortActivityCreatorPageView, ProcessedCreatorLinkEntries) == 0x79c, "Offset mismatch for UFortActivityCreatorPageView::ProcessedCreatorLinkEntries");
static_assert(offsetof(UFortActivityCreatorPageView, AmountOfEntriesQueried) == 0x7a0, "Offset mismatch for UFortActivityCreatorPageView::AmountOfEntriesQueried");

// Size: 0x770 (Inherited: 0x1b88, Single: 0xffffebe8)
class UFortActivityDiscoverView : public UFortActivityBrowserRowView
{
public:
    bool bPlayDetailsAnimationOnScreenOpen; // 0x6d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6d1[0x3]; // 0x6d1 (Size: 0x3, Type: PaddingProperty)
    float DetailsDisplayUpdateDelay; // 0x6d4 (Size: 0x4, Type: FloatProperty)
    UClass* MovieWidgetClass; // 0x6d8 (Size: 0x8, Type: ClassProperty)
    UFortActivityDetailsDisplay* DetailsDisplay_SelectedActivity; // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    UFortActivityDetailsDisplay* DetailsDisplay_PromotedActivity; // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* Panel_VideoSlot; // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* Panel_PromotedVideoSlot; // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    UFortActivatableMovieWidget* ActivityMovieWidget; // 0x700 (Size: 0x8, Type: ObjectProperty)
    UFortActivatableMovieWidget* PromotedActivityMovieWidget; // 0x708 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_710[0x48]; // 0x710 (Size: 0x48, Type: PaddingProperty)
    UWidgetAnimation* BoundKeyArtOutroAnimation; // 0x758 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_760[0x10]; // 0x760 (Size: 0x10, Type: PaddingProperty)

public:
    virtual UTexture* GetCurrentTexture() const; // 0x11081b34 (Index: 0x1, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual UWidgetAnimation* GetKeyArtOutroAnimation() const; // 0x11081ca8 (Index: 0x2, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    UFortActivatableMovieWidget* GetMovieWidget() const; // 0x11081d7c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFortActivatableMovieWidget* GetPromotedMovieWidget() const; // 0x11081e3c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsImageLoading() const; // 0x11082ca4 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsInOutroState() const; // 0x11082cbc (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsShowingPromotedContent() const; // 0x11082d1c (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsShowingSeasonalContent() const; // 0x11082d48 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void OnMoviePlayingChanged(bool& const bIsPlaying); // 0x288a61c (Index: 0xb, Flags: Event|Public|BlueprintEvent)
    virtual void OnMoviePreEndEvent(); // 0x288a61c (Index: 0xc, Flags: Event|Public|BlueprintEvent)
    virtual void OnPlayKeyArtIntro(); // 0x288a61c (Index: 0xd, Flags: Event|Public|BlueprintEvent)
    virtual void OnPlayKeyArtOutro(); // 0x288a61c (Index: 0xe, Flags: Event|Public|BlueprintEvent)
    virtual void OnPreviewImageChanged(bool& const bIsLoading, UTexture*& const Texture); // 0x288a61c (Index: 0xf, Flags: Event|Public|BlueprintEvent)
    virtual void OnUpdateDetailsDisplay(); // 0x288a61c (Index: 0x10, Flags: Event|Public|BlueprintEvent)

private:
    void CheckUpdateDetailsDelay(); // 0x110818c0 (Index: 0x0, Flags: Final|Native|Private)
    void HandleMovieWidgetMediaPreEndEvent(); // 0x110828cc (Index: 0x5, Flags: Final|Native|Private)
    void HandleMovieWidgetMediaStarted(); // 0x110828e0 (Index: 0x6, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortActivityDiscoverView) == 0x770, "Size mismatch for UFortActivityDiscoverView");
static_assert(offsetof(UFortActivityDiscoverView, bPlayDetailsAnimationOnScreenOpen) == 0x6d0, "Offset mismatch for UFortActivityDiscoverView::bPlayDetailsAnimationOnScreenOpen");
static_assert(offsetof(UFortActivityDiscoverView, DetailsDisplayUpdateDelay) == 0x6d4, "Offset mismatch for UFortActivityDiscoverView::DetailsDisplayUpdateDelay");
static_assert(offsetof(UFortActivityDiscoverView, MovieWidgetClass) == 0x6d8, "Offset mismatch for UFortActivityDiscoverView::MovieWidgetClass");
static_assert(offsetof(UFortActivityDiscoverView, DetailsDisplay_SelectedActivity) == 0x6e0, "Offset mismatch for UFortActivityDiscoverView::DetailsDisplay_SelectedActivity");
static_assert(offsetof(UFortActivityDiscoverView, DetailsDisplay_PromotedActivity) == 0x6e8, "Offset mismatch for UFortActivityDiscoverView::DetailsDisplay_PromotedActivity");
static_assert(offsetof(UFortActivityDiscoverView, Panel_VideoSlot) == 0x6f0, "Offset mismatch for UFortActivityDiscoverView::Panel_VideoSlot");
static_assert(offsetof(UFortActivityDiscoverView, Panel_PromotedVideoSlot) == 0x6f8, "Offset mismatch for UFortActivityDiscoverView::Panel_PromotedVideoSlot");
static_assert(offsetof(UFortActivityDiscoverView, ActivityMovieWidget) == 0x700, "Offset mismatch for UFortActivityDiscoverView::ActivityMovieWidget");
static_assert(offsetof(UFortActivityDiscoverView, PromotedActivityMovieWidget) == 0x708, "Offset mismatch for UFortActivityDiscoverView::PromotedActivityMovieWidget");
static_assert(offsetof(UFortActivityDiscoverView, BoundKeyArtOutroAnimation) == 0x758, "Offset mismatch for UFortActivityDiscoverView::BoundKeyArtOutroAnimation");

// Size: 0x830 (Inherited: 0x1b88, Single: 0xffffeca8)
class UFortActivityDiscoverViewV2 : public UFortActivityBrowserRowView
{
public:
    uint8_t OnActivityRequested[0x10]; // 0x6d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UFortDiscoverPreviewManager* DiscoverPreviewManager; // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_6e8[0x28]; // 0x6e8 (Size: 0x28, Type: PaddingProperty)
    UDiscoverSelectedActivityViewModel* SelectedActivityVM; // 0x710 (Size: 0x8, Type: ObjectProperty)
    TSoftClassPtr SoftCustomMatchmakingModalClass; // 0x718 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr SoftSpectateMatchModalClass; // 0x738 (Size: 0x20, Type: SoftClassProperty)
    uint8_t Pad_758[0x8]; // 0x758 (Size: 0x8, Type: PaddingProperty)
    FDataTableRowHandle BackToTopInputAction; // 0x760 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_770[0x8]; // 0x770 (Size: 0x8, Type: PaddingProperty)
    FDataTableRowHandle CustomKeyInputAction; // 0x778 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_788[0x8]; // 0x788 (Size: 0x8, Type: PaddingProperty)
    FDataTableRowHandle ShowSpectateMatchModalInputAction; // 0x790 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_7a0[0x8]; // 0x7a0 (Size: 0x8, Type: PaddingProperty)
    FDataTableRowHandle JoinAsSpectatorInputAction; // 0x7a8 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_7b8[0x8]; // 0x7b8 (Size: 0x8, Type: PaddingProperty)
    FDataTableRowHandle JoinAsPlayerInputAction; // 0x7c0 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_7d0[0x8]; // 0x7d0 (Size: 0x8, Type: PaddingProperty)
    FDataTableRowHandle SelectActivityInputAction_Touch; // 0x7d8 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_7e8[0x40]; // 0x7e8 (Size: 0x40, Type: PaddingProperty)
    UFortNestedButtonGroupSelectionVM* NestedButtonGroupSelectionVM; // 0x828 (Size: 0x8, Type: ObjectProperty)

public:
    void DeactivationTransitionCompleted(); // 0x110818e8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void FireDiscoverExitedAnalyticEvent(); // 0x655170c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    bool IsShowingPromotedContent() const; // 0x11082d1c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsShowingSeasonalContent() const; // 0x11082d48 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void StartDiscoverAnalyticSession(); // 0x563167c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

private:
    void HandlePlaytimeStateChanged(EPlaytimeState& NewState); // 0x11082908 (Index: 0x2, Flags: Final|Native|Private)
    void UpdateMiscActionBindingVisibility(bool& bVisible); // 0x3eb60c8 (Index: 0x6, Flags: Final|Native|Private|BlueprintCallable)
};

static_assert(sizeof(UFortActivityDiscoverViewV2) == 0x830, "Size mismatch for UFortActivityDiscoverViewV2");
static_assert(offsetof(UFortActivityDiscoverViewV2, OnActivityRequested) == 0x6d0, "Offset mismatch for UFortActivityDiscoverViewV2::OnActivityRequested");
static_assert(offsetof(UFortActivityDiscoverViewV2, DiscoverPreviewManager) == 0x6e0, "Offset mismatch for UFortActivityDiscoverViewV2::DiscoverPreviewManager");
static_assert(offsetof(UFortActivityDiscoverViewV2, SelectedActivityVM) == 0x710, "Offset mismatch for UFortActivityDiscoverViewV2::SelectedActivityVM");
static_assert(offsetof(UFortActivityDiscoverViewV2, SoftCustomMatchmakingModalClass) == 0x718, "Offset mismatch for UFortActivityDiscoverViewV2::SoftCustomMatchmakingModalClass");
static_assert(offsetof(UFortActivityDiscoverViewV2, SoftSpectateMatchModalClass) == 0x738, "Offset mismatch for UFortActivityDiscoverViewV2::SoftSpectateMatchModalClass");
static_assert(offsetof(UFortActivityDiscoverViewV2, BackToTopInputAction) == 0x760, "Offset mismatch for UFortActivityDiscoverViewV2::BackToTopInputAction");
static_assert(offsetof(UFortActivityDiscoverViewV2, CustomKeyInputAction) == 0x778, "Offset mismatch for UFortActivityDiscoverViewV2::CustomKeyInputAction");
static_assert(offsetof(UFortActivityDiscoverViewV2, ShowSpectateMatchModalInputAction) == 0x790, "Offset mismatch for UFortActivityDiscoverViewV2::ShowSpectateMatchModalInputAction");
static_assert(offsetof(UFortActivityDiscoverViewV2, JoinAsSpectatorInputAction) == 0x7a8, "Offset mismatch for UFortActivityDiscoverViewV2::JoinAsSpectatorInputAction");
static_assert(offsetof(UFortActivityDiscoverViewV2, JoinAsPlayerInputAction) == 0x7c0, "Offset mismatch for UFortActivityDiscoverViewV2::JoinAsPlayerInputAction");
static_assert(offsetof(UFortActivityDiscoverViewV2, SelectActivityInputAction_Touch) == 0x7d8, "Offset mismatch for UFortActivityDiscoverViewV2::SelectActivityInputAction_Touch");
static_assert(offsetof(UFortActivityDiscoverViewV2, NestedButtonGroupSelectionVM) == 0x828, "Offset mismatch for UFortActivityDiscoverViewV2::NestedButtonGroupSelectionVM");

// Size: 0x438 (Inherited: 0x438, Single: 0x0)
class UFortActivityListView : public UListViewBase
{
public:
    uint8_t Pad_290[0xe8]; // 0x290 (Size: 0xe8, Type: PaddingProperty)
    float DirectionalNavigationTimeThreshold; // 0x378 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EOrientation> orientation; // 0x37c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_37d[0x3]; // 0x37d (Size: 0x3, Type: PaddingProperty)
    float EntrySpacing; // 0x380 (Size: 0x4, Type: FloatProperty)
    bool bCircularNavigationEnabled; // 0x384 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_385[0x3]; // 0x385 (Size: 0x3, Type: PaddingProperty)
    TMap<UClass*, EActivityBrowserTileStyle> TileTypes; // 0x388 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_3d8[0x60]; // 0x3d8 (Size: 0x60, Type: PaddingProperty)

public:
    void AddTileType(EActivityBrowserTileStyle& Style, UClass*& WidgetClass); // 0x110814e4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool GetHasViewAllButton(); // 0x11081b74 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool GetHorizontalScrollingEnabled(); // 0x11081ba8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    int32_t GetInViewCount() const; // 0x11081bc0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetMaxRows(); // 0x11081d64 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UFortActivityListView) == 0x438, "Size mismatch for UFortActivityListView");
static_assert(offsetof(UFortActivityListView, DirectionalNavigationTimeThreshold) == 0x378, "Offset mismatch for UFortActivityListView::DirectionalNavigationTimeThreshold");
static_assert(offsetof(UFortActivityListView, orientation) == 0x37c, "Offset mismatch for UFortActivityListView::orientation");
static_assert(offsetof(UFortActivityListView, EntrySpacing) == 0x380, "Offset mismatch for UFortActivityListView::EntrySpacing");
static_assert(offsetof(UFortActivityListView, bCircularNavigationEnabled) == 0x384, "Offset mismatch for UFortActivityListView::bCircularNavigationEnabled");
static_assert(offsetof(UFortActivityListView, TileTypes) == 0x388, "Offset mismatch for UFortActivityListView::TileTypes");

// Size: 0x1580 (Inherited: 0x30c0, Single: 0xffffe4c0)
class UFortActivityLobbyTile : public UCommonButtonLegacy
{
public:
    UCommonTextBlock* Text_ActivityName; // 0x14f0 (Size: 0x8, Type: ObjectProperty)
    UFortActivityBrowserTag* ActivityBrowserTag_EpicOriginal; // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    UFortGameActivityProvider* ActivityProvider; // 0x1500 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1508[0x78]; // 0x1508 (Size: 0x78, Type: PaddingProperty)

public:
    FText GetChildActivityDisplayName() const; // 0x11081ae0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsActivityEpicCreated() const; // 0x11082b98 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ShowMatchmakingSettingsModal(); // 0x11084988 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

protected:
    UTexture* GetLastMapRotationTexture() const; // 0x11081cd0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnDetailsUpdated(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnMapRotationChanged(bool& const bIsVisible, const FText MapName, UTexture*& const MapTexture); // 0x288a61c (Index: 0x4, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortActivityLobbyTile) == 0x1580, "Size mismatch for UFortActivityLobbyTile");
static_assert(offsetof(UFortActivityLobbyTile, Text_ActivityName) == 0x14f0, "Offset mismatch for UFortActivityLobbyTile::Text_ActivityName");
static_assert(offsetof(UFortActivityLobbyTile, ActivityBrowserTag_EpicOriginal) == 0x14f8, "Offset mismatch for UFortActivityLobbyTile::ActivityBrowserTag_EpicOriginal");
static_assert(offsetof(UFortActivityLobbyTile, ActivityProvider) == 0x1500, "Offset mismatch for UFortActivityLobbyTile::ActivityProvider");

// Size: 0x488 (Inherited: 0xf58, Single: 0xfffff530)
class UFortActivityModeSetSelectionModal : public UFortActivityModeSetSelectionModalBase
{
public:
    UCommonTextBlock* Text_ActivityName; // 0x420 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_428[0x28]; // 0x428 (Size: 0x28, Type: PaddingProperty)
    UCommonButtonBase* Button_Back; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_BackBoard; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UFortActivityModeSetSelection* List_SubModeList; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UFortActivitySquadFillButton* Button_ActivitySquadFill; // 0x468 (Size: 0x8, Type: ObjectProperty)
    UFortActivityPrivacyButton* Button_ActivityPrivacy; // 0x470 (Size: 0x8, Type: ObjectProperty)
    UFortActivityHabaneroButton* Button_Activity_Habanero; // 0x478 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_480[0x8]; // 0x480 (Size: 0x8, Type: PaddingProperty)

protected:
    bool IsCreativeModeSetActivity() const; // 0x11082c64 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnActivityChanged(UFortGameActivity*& const GameActivity, FString& StartingSelectedMnemonic); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPreviewImageChanged(bool& const bIsLoading, UTexture*& const Texture); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSubModeSelected(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSubModeSelectionChanged(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    void SaveSelectionAndClose(); // 0x11083a50 (Index: 0x5, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void SetHabaneroValues(bool& bHabaneroEnabled, bool& bHabaneroExists); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void SetIsRankedSwitchAvailable(bool& const bIsRankedSwitchAvailable); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortActivityModeSetSelectionModal) == 0x488, "Size mismatch for UFortActivityModeSetSelectionModal");
static_assert(offsetof(UFortActivityModeSetSelectionModal, Text_ActivityName) == 0x420, "Offset mismatch for UFortActivityModeSetSelectionModal::Text_ActivityName");
static_assert(offsetof(UFortActivityModeSetSelectionModal, Button_Back) == 0x450, "Offset mismatch for UFortActivityModeSetSelectionModal::Button_Back");
static_assert(offsetof(UFortActivityModeSetSelectionModal, Button_BackBoard) == 0x458, "Offset mismatch for UFortActivityModeSetSelectionModal::Button_BackBoard");
static_assert(offsetof(UFortActivityModeSetSelectionModal, List_SubModeList) == 0x460, "Offset mismatch for UFortActivityModeSetSelectionModal::List_SubModeList");
static_assert(offsetof(UFortActivityModeSetSelectionModal, Button_ActivitySquadFill) == 0x468, "Offset mismatch for UFortActivityModeSetSelectionModal::Button_ActivitySquadFill");
static_assert(offsetof(UFortActivityModeSetSelectionModal, Button_ActivityPrivacy) == 0x470, "Offset mismatch for UFortActivityModeSetSelectionModal::Button_ActivityPrivacy");
static_assert(offsetof(UFortActivityModeSetSelectionModal, Button_Activity_Habanero) == 0x478, "Offset mismatch for UFortActivityModeSetSelectionModal::Button_Activity_Habanero");

// Size: 0x1590 (Inherited: 0x3100, Single: 0xffffe490)
class UFortActivityPlayerBrowserTile : public UFortActivityTileViewTileBase
{
public:
    UFortActivityTileDetailsDisplay* Display_TileDetails; // 0x1530 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_LastPlayedDate; // 0x1538 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1540[0x50]; // 0x1540 (Size: 0x50, Type: PaddingProperty)

private:
    void HandleActivitySelected(); // 0x11081ea8 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortActivityPlayerBrowserTile) == 0x1590, "Size mismatch for UFortActivityPlayerBrowserTile");
static_assert(offsetof(UFortActivityPlayerBrowserTile, Display_TileDetails) == 0x1530, "Offset mismatch for UFortActivityPlayerBrowserTile::Display_TileDetails");
static_assert(offsetof(UFortActivityPlayerBrowserTile, Text_LastPlayedDate) == 0x1538, "Offset mismatch for UFortActivityPlayerBrowserTile::Text_LastPlayedDate");

// Size: 0x340 (Inherited: 0xb8, Single: 0x288)
class UFortActivitySelector : public UFortLocalPlayerSubsystem
{
public:
    uint8_t Pad_30[0x238]; // 0x30 (Size: 0x238, Type: PaddingProperty)
    uint8_t OnShowActivityDetailsOnCreatorPageDelegate[0x10]; // 0x268 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_278[0x10]; // 0x278 (Size: 0x10, Type: PaddingProperty)
    TMap<UFortActivityBrowserColorSchemeAsset*, FName> ColorSchemes; // 0x288 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_2d8[0x68]; // 0x2d8 (Size: 0x68, Type: PaddingProperty)

public:
    void ConfirmSelectedActivity(); // 0x110818d4 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    FString GetPlayerPageCreatorAccountId() const; // 0x11081dfc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void HandleCategoryTileClicked(AFortPlayerController*& const FortPC, UFortDiscoverSurfaceTileItemVM*& const InTileItemVM) const; // 0x1108210c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|Const)
    void HandleShowActivityDetails(); // 0x11082a34 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    bool IsShowingPlayerPage() const; // 0x11082d04 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void MarkAsNotInterested(); // 0x11082d74 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void OnShowActivityDetailsOnCreatorPage__DelegateSignature(); // 0x288a61c (Index: 0x8, Flags: MulticastDelegate|Public|Delegate)
    void SetPlayerPageBackButtonClicked(bool& const bInIsButtonClicked); // 0xa3a25a8 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    void SetPlayerPageViewAllButtonClicked(bool& const bInIsButtonClicked); // 0xa3a26d4 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    void ToggleFavorite(); // 0x110849c4 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)

private:
    void HandlePlayerPageBackButtonClicked(); // 0x110828f4 (Index: 0x3, Flags: Final|Native|Private|BlueprintCallable)
    void OpenCreatorPage(bool& const bIsOpenedFromDetailsModal); // 0x110833c0 (Index: 0xa, Flags: Final|Native|Private|BlueprintCallable)
    void OpenCreatorPageFromCreatorId(FString& InNewCreatorId, UUserWidget*& InSelectedContextWidget); // 0x110834ec (Index: 0xb, Flags: Final|Native|Private|BlueprintCallable)

protected:
    virtual void OnEnableColorScheme(bool& const bIsColorSchemeActive); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSwapColorScheme(bool& const bInIsUsingAlternateColorScheme); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortActivitySelector) == 0x340, "Size mismatch for UFortActivitySelector");
static_assert(offsetof(UFortActivitySelector, OnShowActivityDetailsOnCreatorPageDelegate) == 0x268, "Offset mismatch for UFortActivitySelector::OnShowActivityDetailsOnCreatorPageDelegate");
static_assert(offsetof(UFortActivitySelector, ColorSchemes) == 0x288, "Offset mismatch for UFortActivitySelector::ColorSchemes");

// Size: 0x1760 (Inherited: 0x4640, Single: 0xffffd120)
class UFortActivityTileDetailsDisplay : public UUIKitHoldableModularButton
{
public:
    uint8_t OnActivitySelectedDelegate[0x10]; // 0x15b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnActivityUnSelectedDelegate[0x10]; // 0x15c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bShowDetailsButton; // 0x15d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15d1[0x3]; // 0x15d1 (Size: 0x3, Type: PaddingProperty)
    int32_t DefaultColumnSize; // 0x15d4 (Size: 0x4, Type: IntProperty)
    UCommonTextBlock* Text_ActivityName; // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_PlayerCount; // 0x15e0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Favorite; // 0x15e8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Details; // 0x15f0 (Size: 0x8, Type: ObjectProperty)
    UFortActivityBrowserTag* ActivityBrowserTag_EpicOriginal; // 0x15f8 (Size: 0x8, Type: ObjectProperty)
    UTextBlock* Text_DebugId; // 0x1600 (Size: 0x8, Type: ObjectProperty)
    UFortActivityVideoCycle* ActivityVideoCycleWidget; // 0x1608 (Size: 0x8, Type: ObjectProperty)
    TMap<ECreativeLinkPreviewSize, uint32_t> MinColumnSizeToImageSize; // 0x1610 (Size: 0x50, Type: MapProperty)
    UClass* ActivityDetailsModalClass; // 0x1660 (Size: 0x8, Type: ClassProperty)
    UClass* PlayerPageViewClass; // 0x1668 (Size: 0x8, Type: ClassProperty)
    UClass* ActivityCampaignPurchaseScreenClass; // 0x1670 (Size: 0x8, Type: ClassProperty)
    UClass* ActivityAttributionsClass; // 0x1678 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_1680[0xe0]; // 0x1680 (Size: 0xe0, Type: PaddingProperty)

public:
    void BroadcastOnActivityConfirmed() const; // 0x110818a4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|Const)
    void OnActivitySelected__DelegateSignature(); // 0x288a61c (Index: 0xc, Flags: MulticastDelegate|Public|Delegate)
    void OnActivityUnSelected__DelegateSignature(); // 0x288a61c (Index: 0xd, Flags: MulticastDelegate|Public|Delegate)
    virtual void OnRespondToTileViewVisibilityChange(bool& bIsVisible); // 0x288a61c (Index: 0x17, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    void UpdateActivitySelector(); // 0x11081ebc (Index: 0x1e, Flags: Final|Native|Public|BlueprintCallable)

private:
    void HandleActivitySelected(); // 0x11081ebc (Index: 0x6, Flags: Final|Native|Private)
    void HandleShowActivityDetails(); // 0x11082a48 (Index: 0x7, Flags: Final|Native|Private)

protected:
    bool DoesActivityRequirePurchase() const; // 0x11081940 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    FString GetActivityCreatorDisplayText() const; // 0x110819b8 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    UFortActivitySelector* GetActivitySelector() const; // 0x110819f8 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    EFortActivityIsLockedReason GetBestActivityLockedReason() const; // 0x11081a1c (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    EFortInvalidActivityReason GetInvalidActivityReason() const; // 0x11081c1c (Index: 0x5, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool IsActivityFavorited() const; // 0x11082bec (Index: 0x8, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool IsActivityLocked() const; // 0x11082c10 (Index: 0x9, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool IsModeSetActivity() const; // 0x11082cd4 (Index: 0xa, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void NotifyAnalyticsTileWasClicked(); // 0x11083314 (Index: 0xb, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnDetailsUpdated(); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void OnFriendsPlayingChanged(int32_t& NumPlaying); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void OnIsFavoriteChanged(bool& const bIsFavorite); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void OnLocalPlayerDemoted(); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
    virtual void OnLocalPlayerPromotedToLeader(); // 0x288a61c (Index: 0x12, Flags: Event|Protected|BlueprintEvent)
    virtual void OnLogoImageChanged(bool& const bIsLoading, UTexture*& const Texture); // 0x288a61c (Index: 0x13, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPartySizeChanged(int32_t& const PartySize); // 0x288a61c (Index: 0x14, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPreviewImageChanged(bool& const bIsLoading, UTexture*& const Texture); // 0x288a61c (Index: 0x15, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRequiresPurchaseChanged(bool& const bRequiresPurchase); // 0x288a61c (Index: 0x16, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTileActiveSet(bool& const bIsTileActive); // 0x288a61c (Index: 0x18, Flags: Event|Protected|BlueprintEvent)
    void OnTileClicked(); // 0x1108333c (Index: 0x19, Flags: Final|Native|Protected|BlueprintCallable)
    void SetShowTileTrailers(bool& const bInShowTileTrailers); // 0x11084548 (Index: 0x1a, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void ShouldPlayTileVideo(bool& bOutResult); // 0x288a61c (Index: 0x1b, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void StartTileVideo(); // 0x1108499c (Index: 0x1c, Flags: Final|Native|Protected|BlueprintCallable)
    void StopTileVideo(); // 0x110849b0 (Index: 0x1d, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void UpdateCCU(int32_t& const CCUCount); // 0x288a61c (Index: 0x1f, Flags: Event|Protected|BlueprintEvent)
    void UpdateFromFortActivityViewModel(); // 0x11084a34 (Index: 0x20, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void UpdateSqueegeeWidgets(UFortGameActivity*& GameActivity); // 0x288a61c (Index: 0x21, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortActivityTileDetailsDisplay) == 0x1760, "Size mismatch for UFortActivityTileDetailsDisplay");
static_assert(offsetof(UFortActivityTileDetailsDisplay, OnActivitySelectedDelegate) == 0x15b0, "Offset mismatch for UFortActivityTileDetailsDisplay::OnActivitySelectedDelegate");
static_assert(offsetof(UFortActivityTileDetailsDisplay, OnActivityUnSelectedDelegate) == 0x15c0, "Offset mismatch for UFortActivityTileDetailsDisplay::OnActivityUnSelectedDelegate");
static_assert(offsetof(UFortActivityTileDetailsDisplay, bShowDetailsButton) == 0x15d0, "Offset mismatch for UFortActivityTileDetailsDisplay::bShowDetailsButton");
static_assert(offsetof(UFortActivityTileDetailsDisplay, DefaultColumnSize) == 0x15d4, "Offset mismatch for UFortActivityTileDetailsDisplay::DefaultColumnSize");
static_assert(offsetof(UFortActivityTileDetailsDisplay, Text_ActivityName) == 0x15d8, "Offset mismatch for UFortActivityTileDetailsDisplay::Text_ActivityName");
static_assert(offsetof(UFortActivityTileDetailsDisplay, Text_PlayerCount) == 0x15e0, "Offset mismatch for UFortActivityTileDetailsDisplay::Text_PlayerCount");
static_assert(offsetof(UFortActivityTileDetailsDisplay, Button_Favorite) == 0x15e8, "Offset mismatch for UFortActivityTileDetailsDisplay::Button_Favorite");
static_assert(offsetof(UFortActivityTileDetailsDisplay, Button_Details) == 0x15f0, "Offset mismatch for UFortActivityTileDetailsDisplay::Button_Details");
static_assert(offsetof(UFortActivityTileDetailsDisplay, ActivityBrowserTag_EpicOriginal) == 0x15f8, "Offset mismatch for UFortActivityTileDetailsDisplay::ActivityBrowserTag_EpicOriginal");
static_assert(offsetof(UFortActivityTileDetailsDisplay, Text_DebugId) == 0x1600, "Offset mismatch for UFortActivityTileDetailsDisplay::Text_DebugId");
static_assert(offsetof(UFortActivityTileDetailsDisplay, ActivityVideoCycleWidget) == 0x1608, "Offset mismatch for UFortActivityTileDetailsDisplay::ActivityVideoCycleWidget");
static_assert(offsetof(UFortActivityTileDetailsDisplay, MinColumnSizeToImageSize) == 0x1610, "Offset mismatch for UFortActivityTileDetailsDisplay::MinColumnSizeToImageSize");
static_assert(offsetof(UFortActivityTileDetailsDisplay, ActivityDetailsModalClass) == 0x1660, "Offset mismatch for UFortActivityTileDetailsDisplay::ActivityDetailsModalClass");
static_assert(offsetof(UFortActivityTileDetailsDisplay, PlayerPageViewClass) == 0x1668, "Offset mismatch for UFortActivityTileDetailsDisplay::PlayerPageViewClass");
static_assert(offsetof(UFortActivityTileDetailsDisplay, ActivityCampaignPurchaseScreenClass) == 0x1670, "Offset mismatch for UFortActivityTileDetailsDisplay::ActivityCampaignPurchaseScreenClass");
static_assert(offsetof(UFortActivityTileDetailsDisplay, ActivityAttributionsClass) == 0x1678, "Offset mismatch for UFortActivityTileDetailsDisplay::ActivityAttributionsClass");

// Size: 0xb90 (Inherited: 0x3248, Single: 0xffffd948)
class UFortActivityTileView : public UFortTileView
{
public:

public:
    void NavigateToTop(); // 0x110831c0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void RespondToVisibilityChange(bool& bIsVisible); // 0x11083924 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void SetListenForMouseWheelInput(bool& bListenForInput); // 0x4cd8160 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortActivityTileView) == 0xb90, "Size mismatch for UFortActivityTileView");

// Size: 0x440 (Inherited: 0xb08, Single: 0xfffff938)
class UFortDiscoverItemBrowserRow : public UFortActivityBrowserRow
{
public:
    UFortDiscoverItemListView* ListView_Tiles; // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PageLeft; // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PageRight; // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_3f0[0x50]; // 0x3f0 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UFortDiscoverItemBrowserRow) == 0x440, "Size mismatch for UFortDiscoverItemBrowserRow");
static_assert(offsetof(UFortDiscoverItemBrowserRow, ListView_Tiles) == 0x3d8, "Offset mismatch for UFortDiscoverItemBrowserRow::ListView_Tiles");
static_assert(offsetof(UFortDiscoverItemBrowserRow, Button_PageLeft) == 0x3e0, "Offset mismatch for UFortDiscoverItemBrowserRow::Button_PageLeft");
static_assert(offsetof(UFortDiscoverItemBrowserRow, Button_PageRight) == 0x3e8, "Offset mismatch for UFortDiscoverItemBrowserRow::Button_PageRight");

// Size: 0x3e8 (Inherited: 0x438, Single: 0xffffffb0)
class UFortDiscoverItemListView : public UListViewBase
{
public:
    uint8_t Pad_290[0xe8]; // 0x290 (Size: 0xe8, Type: PaddingProperty)
    float DirectionalNavigationTimeThreshold; // 0x378 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_37c[0x4]; // 0x37c (Size: 0x4, Type: PaddingProperty)
    UClass* PlayWithFriendsEntryWidgetClass; // 0x380 (Size: 0x8, Type: ClassProperty)
    UClass* ActivityEntryWidgetClass; // 0x388 (Size: 0x8, Type: ClassProperty)
    UClass* LibraryEntryWidgetClass; // 0x390 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EOrientation> orientation; // 0x398 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_399[0x3]; // 0x399 (Size: 0x3, Type: PaddingProperty)
    float EntrySpacing; // 0x39c (Size: 0x4, Type: FloatProperty)
    bool bCircularNavigationEnabled; // 0x3a0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3a1[0x47]; // 0x3a1 (Size: 0x47, Type: PaddingProperty)

public:
    int32_t GetInViewCount() const; // 0x11081be4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortDiscoverItemListView) == 0x3e8, "Size mismatch for UFortDiscoverItemListView");
static_assert(offsetof(UFortDiscoverItemListView, DirectionalNavigationTimeThreshold) == 0x378, "Offset mismatch for UFortDiscoverItemListView::DirectionalNavigationTimeThreshold");
static_assert(offsetof(UFortDiscoverItemListView, PlayWithFriendsEntryWidgetClass) == 0x380, "Offset mismatch for UFortDiscoverItemListView::PlayWithFriendsEntryWidgetClass");
static_assert(offsetof(UFortDiscoverItemListView, ActivityEntryWidgetClass) == 0x388, "Offset mismatch for UFortDiscoverItemListView::ActivityEntryWidgetClass");
static_assert(offsetof(UFortDiscoverItemListView, LibraryEntryWidgetClass) == 0x390, "Offset mismatch for UFortDiscoverItemListView::LibraryEntryWidgetClass");
static_assert(offsetof(UFortDiscoverItemListView, orientation) == 0x398, "Offset mismatch for UFortDiscoverItemListView::orientation");
static_assert(offsetof(UFortDiscoverItemListView, EntrySpacing) == 0x39c, "Offset mismatch for UFortDiscoverItemListView::EntrySpacing");
static_assert(offsetof(UFortDiscoverItemListView, bCircularNavigationEnabled) == 0x3a0, "Offset mismatch for UFortDiscoverItemListView::bCircularNavigationEnabled");

// Size: 0xe8 (Inherited: 0xe0, Single: 0x8)
class UActivityLibraryComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x10]; // 0xb8 (Size: 0x10, Type: PaddingProperty)
    TSoftClassPtr CreatorPageOverrideClass; // 0xc8 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UActivityLibraryComponent) == 0xe8, "Size mismatch for UActivityLibraryComponent");
static_assert(offsetof(UActivityLibraryComponent, CreatorPageOverrideClass) == 0xc8, "Offset mismatch for UActivityLibraryComponent::CreatorPageOverrideClass");

// Size: 0x48 (Inherited: 0x88, Single: 0xffffffc0)
class UFortActivityBrowserContext : public UGameInstanceSubsystem
{
public:
};

static_assert(sizeof(UFortActivityBrowserContext) == 0x48, "Size mismatch for UFortActivityBrowserContext");

// Size: 0x100 (Inherited: 0xe0, Single: 0x20)
class UOverrideMatchmakingUIComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    FMatchmakingUIOverride MatchmakingUIOverride; // 0xc0 (Size: 0x40, Type: StructProperty)
};

static_assert(sizeof(UOverrideMatchmakingUIComponent) == 0x100, "Size mismatch for UOverrideMatchmakingUIComponent");
static_assert(offsetof(UOverrideMatchmakingUIComponent, MatchmakingUIOverride) == 0xc0, "Offset mismatch for UOverrideMatchmakingUIComponent::MatchmakingUIOverride");

// Size: 0xa8 (Inherited: 0x0, Single: 0xa8)
struct FColorSchemeParamaterValues
{
    UMaterialParameterCollection* AlternateMaterialCollection; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TMap<float, FName> ScalarParameterValues; // 0x8 (Size: 0x50, Type: MapProperty)
    TMap<FLinearColor, FName> VectorParameterValues; // 0x58 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FColorSchemeParamaterValues) == 0xa8, "Size mismatch for FColorSchemeParamaterValues");
static_assert(offsetof(FColorSchemeParamaterValues, AlternateMaterialCollection) == 0x0, "Offset mismatch for FColorSchemeParamaterValues::AlternateMaterialCollection");
static_assert(offsetof(FColorSchemeParamaterValues, ScalarParameterValues) == 0x8, "Offset mismatch for FColorSchemeParamaterValues::ScalarParameterValues");
static_assert(offsetof(FColorSchemeParamaterValues, VectorParameterValues) == 0x58, "Offset mismatch for FColorSchemeParamaterValues::VectorParameterValues");

