/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AIDebuggerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "Engine.h"
#include "ModularGameplay.h"
#include "GameplayMessages.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UAIDebuggerCheatManager : public UChildCheatManager
{
public:

public:
    void EnableNavMeshVisualizer(bool& const bEnable); // 0x9e6e1b8 (Index: 0x0, Flags: Final|Exec|Native|Public)
    void NextNavMesh(); // 0x554e3c4 (Index: 0x1, Flags: Final|Exec|Native|Public)
    void StartAIDebugger(FString& const AIDebuggerSoftClassPath); // 0xd7d6cf4 (Index: 0x2, Flags: Final|Exec|Native|Public)
};

static_assert(sizeof(UAIDebuggerCheatManager) == 0x28, "Size mismatch for UAIDebuggerCheatManager");

// Size: 0x5c0 (Inherited: 0x840, Single: 0xfffffd80)
class UAIDebuggerRendererComponent : public UPrimitiveComponent
{
public:
    uint8_t Pad_520[0x90]; // 0x520 (Size: 0x90, Type: PaddingProperty)
    UMaterial* NavMeshMaterial; // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    float NavLinkLineThickness; // 0x5b8 (Size: 0x4, Type: FloatProperty)
    float NavLinkMaxDrawDistance; // 0x5bc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UAIDebuggerRendererComponent) == 0x5c0, "Size mismatch for UAIDebuggerRendererComponent");
static_assert(offsetof(UAIDebuggerRendererComponent, NavMeshMaterial) == 0x5b0, "Offset mismatch for UAIDebuggerRendererComponent::NavMeshMaterial");
static_assert(offsetof(UAIDebuggerRendererComponent, NavLinkLineThickness) == 0x5b8, "Offset mismatch for UAIDebuggerRendererComponent::NavLinkLineThickness");
static_assert(offsetof(UAIDebuggerRendererComponent, NavLinkMaxDrawDistance) == 0x5bc, "Offset mismatch for UAIDebuggerRendererComponent::NavLinkMaxDrawDistance");

// Size: 0x128 (Inherited: 0x310, Single: 0xfffffe18)
class UFortControllerComponent_AIDebugger : public UFortControllerComponent
{
public:
    APlayerController* OwnerPC; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UClass* NavMeshRendererComponentClass; // 0xc8 (Size: 0x8, Type: ClassProperty)
    char DefaultEnabledVisualizers; // 0xd0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_d1[0x3]; // 0xd1 (Size: 0x3, Type: PaddingProperty)
    int32_t DefaultNavDataIndexToDisplay; // 0xd4 (Size: 0x4, Type: IntProperty)
    char EnabledVisualizers; // 0xd8 (Size: 0x1, Type: ByteProperty)
    char NumNavMeshes; // 0xd9 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_da[0x4e]; // 0xda (Size: 0x4e, Type: PaddingProperty)

public:
    UAIDebuggerRendererComponent* GetOrCreateRenderer() const; // 0xfe8512c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsVisualizationEnabled(EAIDebuggerVisualization& const VisualizationType) const; // 0xfe85150 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnPlayerExitedIsland(FEventMessageTag& Channel, const FPlayerExitSpatialActorContextWithPawn PlayerExitSpatialActorContext); // 0xfe85288 (Index: 0x2, Flags: Final|Native|Public|HasOutParms)
    void OnPossessedPawnChanged(APawn*& OldPawn, APawn*& NewPawn); // 0xfe85410 (Index: 0x3, Flags: Final|Native|Public)
    void OnRep_EnabledVisualizers(); // 0xfe85610 (Index: 0x4, Flags: Final|Native|Public)
    virtual void SetVisualizationEnable(EAIDebuggerVisualization& const VisualizationType, bool& const bEnable); // 0xfe85624 (Index: 0x5, Flags: RequiredAPI|Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void VisualizeNavMeshID(int32_t& const NavMeshID); // 0xcff5074 (Index: 0x6, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void VisualizeNextNavMesh(); // 0xceafd84 (Index: 0x7, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
};

static_assert(sizeof(UFortControllerComponent_AIDebugger) == 0x128, "Size mismatch for UFortControllerComponent_AIDebugger");
static_assert(offsetof(UFortControllerComponent_AIDebugger, OwnerPC) == 0xc0, "Offset mismatch for UFortControllerComponent_AIDebugger::OwnerPC");
static_assert(offsetof(UFortControllerComponent_AIDebugger, NavMeshRendererComponentClass) == 0xc8, "Offset mismatch for UFortControllerComponent_AIDebugger::NavMeshRendererComponentClass");
static_assert(offsetof(UFortControllerComponent_AIDebugger, DefaultEnabledVisualizers) == 0xd0, "Offset mismatch for UFortControllerComponent_AIDebugger::DefaultEnabledVisualizers");
static_assert(offsetof(UFortControllerComponent_AIDebugger, DefaultNavDataIndexToDisplay) == 0xd4, "Offset mismatch for UFortControllerComponent_AIDebugger::DefaultNavDataIndexToDisplay");
static_assert(offsetof(UFortControllerComponent_AIDebugger, EnabledVisualizers) == 0xd8, "Offset mismatch for UFortControllerComponent_AIDebugger::EnabledVisualizers");
static_assert(offsetof(UFortControllerComponent_AIDebugger, NumNavMeshes) == 0xd9, "Offset mismatch for UFortControllerComponent_AIDebugger::NumNavMeshes");

