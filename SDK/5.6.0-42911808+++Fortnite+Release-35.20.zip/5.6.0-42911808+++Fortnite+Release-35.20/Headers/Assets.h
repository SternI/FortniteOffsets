/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Assets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "UMG.h"
#include "CommonUI.h"
#include "Systems.h"
#include "CoreUObject.h"
#include "FortniteUI.h"
#include "ModelViewViewModel.h"
#include "UIKit.h"
#include "CommonUILegacy.h"
#include "UI.h"
#include "Engine.h"
#include "MPL.h"
#include "SlateCore.h"
#include "Frontend.h"
#include "GameplayTags.h"
#include "Customization.h"
#include "FortniteGame.h"
#include "GameplayEventRouter.h"
#include "WBP_AthenaBannerSelectModal.h"
#include "CoachMarks.h"

// Size: 0x2d0 (Inherited: 0x458, Single: 0xfffffe78)
class UWBP_MPLocker_Heading_MyLoadout_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2b0 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_SubHeader; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Header; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    bool Show_Sub_Heading_; // 0x2c8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2c9[0x3]; // 0x2c9 (Size: 0x3, Type: PaddingProperty)
    float HeaderMinWidth; // 0x2cc (Size: 0x4, Type: FloatProperty)

public:
    void SetSubHeadingVisibility(bool& ShowSubHeading_); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetSubHeader(FText& Text); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetHeader(FText& Text); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void PresetForDesignTime(); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x4, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UWBP_MPLocker_Heading_MyLoadout_C) == 0x2d0, "Size mismatch for UWBP_MPLocker_Heading_MyLoadout_C");
static_assert(offsetof(UWBP_MPLocker_Heading_MyLoadout_C, UberGraphFrame) == 0x2b0, "Offset mismatch for UWBP_MPLocker_Heading_MyLoadout_C::UberGraphFrame");
static_assert(offsetof(UWBP_MPLocker_Heading_MyLoadout_C, Text_SubHeader) == 0x2b8, "Offset mismatch for UWBP_MPLocker_Heading_MyLoadout_C::Text_SubHeader");
static_assert(offsetof(UWBP_MPLocker_Heading_MyLoadout_C, Text_Header) == 0x2c0, "Offset mismatch for UWBP_MPLocker_Heading_MyLoadout_C::Text_Header");
static_assert(offsetof(UWBP_MPLocker_Heading_MyLoadout_C, Show_Sub_Heading_) == 0x2c8, "Offset mismatch for UWBP_MPLocker_Heading_MyLoadout_C::Show_Sub_Heading_");
static_assert(offsetof(UWBP_MPLocker_Heading_MyLoadout_C, HeaderMinWidth) == 0x2cc, "Offset mismatch for UWBP_MPLocker_Heading_MyLoadout_C::HeaderMinWidth");

// Size: 0x494 (Inherited: 0xb38, Single: 0xfffff95c)
class UWBP_MyLoadouts_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x408 (Size: 0x8, Type: StructProperty)
    UWBP_MPLocker_BackToTopButton_C* WBP_MPLocker_BackToTopButton; // 0x410 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_NumPresets; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Header; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UFortTileView* MyLoadoutList; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UFortCommonLoadoutsVM* FortCommonLoadoutsVM; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UFortLockerVM* FortLockerVM; // 0x438 (Size: 0x8, Type: ObjectProperty)
    bool IsSaveMode; // 0x440 (Size: 0x1, Type: BoolProperty)
    bool IsShuffleMode; // 0x441 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_442[0x6]; // 0x442 (Size: 0x6, Type: PaddingProperty)
    TArray<UFortCommonLoadoutPresetVM*> Loadouts; // 0x448 (Size: 0x10, Type: ArrayProperty)
    TArray<UFortCommonLoadoutPresetVM*> Common_Loadout_Presets; // 0x458 (Size: 0x10, Type: ArrayProperty)
    uint8_t CloseMyloadoutMenu[0x10]; // 0x468 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UWBP_Itemcard_Myloadout_C* TouchSelectedItemcard; // 0x478 (Size: 0x8, Type: ObjectProperty)
    uint8_t CommonLoadoutDisplayItem[0x10]; // 0x480 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t LastChangedIndex; // 0x490 (Size: 0x4, Type: IntProperty)

public:
    void SetSaveMode(bool& IsSaveMode); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x5, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void FireFlowriderInteract(FString& ElementName, bool& UsePresetId, UFortCommonLoadoutPresetVM*& FortCommonLoadoutPresetVM); // 0x288a61c (Index: 0x12, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void EquipLoadout_Touch(); // 0x288a61c (Index: 0x14, Flags: Public|BlueprintCallable|BlueprintEvent)
    void CreateLoadoutModal(EFortLoadoutActionType& LoadoutAction, UFortCommonLoadoutPresetVM*& InTargetLoadout, UWBP_MPLocker_Modal_CommonLoadout_C*& Out_ModalWidget); // 0x288a61c (Index: 0x16, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void CommonLoadoutDisplayItem__DelegateSignature(UWBP_Itemcard_Myloadout_C*& LoadoutCard); // 0x288a61c (Index: 0x17, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void CloseMyloadoutMenu__DelegateSignature(); // 0x288a61c (Index: 0x18, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void UpdateSubheader(TArray<UFortCommonLoadoutPresetVM*> Presets); // 0x288a61c (Index: 0x1e, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void ToggleContextMenu_Touch(); // 0x288a61c (Index: 0x1f, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetupList(TArray<UFortCommonLoadoutPresetVM*> Presets); // 0x288a61c (Index: 0x20, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    virtual void BP_OnDeactivated(); // 0x288a61c (Index: 0x19, Flags: Event|Protected|BlueprintEvent)
    virtual UWidget* BP_GetDesiredFocusTarget() const; // 0x288a61c (Index: 0x1a, Flags: Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UWBP_MyLoadouts_C) == 0x494, "Size mismatch for UWBP_MyLoadouts_C");
static_assert(offsetof(UWBP_MyLoadouts_C, UberGraphFrame) == 0x408, "Offset mismatch for UWBP_MyLoadouts_C::UberGraphFrame");
static_assert(offsetof(UWBP_MyLoadouts_C, WBP_MPLocker_BackToTopButton) == 0x410, "Offset mismatch for UWBP_MyLoadouts_C::WBP_MPLocker_BackToTopButton");
static_assert(offsetof(UWBP_MyLoadouts_C, Text_NumPresets) == 0x418, "Offset mismatch for UWBP_MyLoadouts_C::Text_NumPresets");
static_assert(offsetof(UWBP_MyLoadouts_C, Text_Header) == 0x420, "Offset mismatch for UWBP_MyLoadouts_C::Text_Header");
static_assert(offsetof(UWBP_MyLoadouts_C, MyLoadoutList) == 0x428, "Offset mismatch for UWBP_MyLoadouts_C::MyLoadoutList");
static_assert(offsetof(UWBP_MyLoadouts_C, FortCommonLoadoutsVM) == 0x430, "Offset mismatch for UWBP_MyLoadouts_C::FortCommonLoadoutsVM");
static_assert(offsetof(UWBP_MyLoadouts_C, FortLockerVM) == 0x438, "Offset mismatch for UWBP_MyLoadouts_C::FortLockerVM");
static_assert(offsetof(UWBP_MyLoadouts_C, IsSaveMode) == 0x440, "Offset mismatch for UWBP_MyLoadouts_C::IsSaveMode");
static_assert(offsetof(UWBP_MyLoadouts_C, IsShuffleMode) == 0x441, "Offset mismatch for UWBP_MyLoadouts_C::IsShuffleMode");
static_assert(offsetof(UWBP_MyLoadouts_C, Loadouts) == 0x448, "Offset mismatch for UWBP_MyLoadouts_C::Loadouts");
static_assert(offsetof(UWBP_MyLoadouts_C, Common_Loadout_Presets) == 0x458, "Offset mismatch for UWBP_MyLoadouts_C::Common_Loadout_Presets");
static_assert(offsetof(UWBP_MyLoadouts_C, CloseMyloadoutMenu) == 0x468, "Offset mismatch for UWBP_MyLoadouts_C::CloseMyloadoutMenu");
static_assert(offsetof(UWBP_MyLoadouts_C, TouchSelectedItemcard) == 0x478, "Offset mismatch for UWBP_MyLoadouts_C::TouchSelectedItemcard");
static_assert(offsetof(UWBP_MyLoadouts_C, CommonLoadoutDisplayItem) == 0x480, "Offset mismatch for UWBP_MyLoadouts_C::CommonLoadoutDisplayItem");
static_assert(offsetof(UWBP_MyLoadouts_C, LastChangedIndex) == 0x490, "Offset mismatch for UWBP_MyLoadouts_C::LastChangedIndex");

// Size: 0x1988 (Inherited: 0x5f1a, Single: 0xffffba6e)
class UWBP_Itemcard_Myloadout_C : public UWBP_UIKit_ItemCard_Base_C
{
public:
    uint8_t Pad_18da[0x6]; // 0x18da (Size: 0x6, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0x18e0 (Size: 0x8, Type: StructProperty)
    UWBP_MPLocker_CommonLoadout_Preview_C* WBP_CommonLoadout_Preview; // 0x18e8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Loadoutname; // 0x18f0 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_ContextMenuAnchorButton_C* ContextMenu; // 0x18f8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Hover; // 0x1900 (Size: 0x8, Type: ObjectProperty)
    UFortCommonLoadoutPresetVM* FortCommonLoadoutPresetVM; // 0x1908 (Size: 0x8, Type: ObjectProperty)
    UFortCommonLoadoutsVM* FortCommonLoadoutsVM; // 0x1910 (Size: 0x8, Type: ObjectProperty)
    float TextOffsetForTile; // 0x1918 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_191c[0x4]; // 0x191c (Size: 0x4, Type: PaddingProperty)
    FText Rename_In_Action_Info_Display_Name; // 0x1920 (Size: 0x10, Type: TextProperty)
    FText Delete_In_Action_Info_Display_Name; // 0x1930 (Size: 0x10, Type: TextProperty)
    uint8_t RenameMegeapresetEventFired[0x10]; // 0x1940 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t DeleteMegapresetEventFired[0x10]; // 0x1950 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool Is_Save_as_New_Tile; // 0x1960 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1961[0x7]; // 0x1961 (Size: 0x7, Type: PaddingProperty)
    FString ContextMenuParentID; // 0x1968 (Size: 0x10, Type: StrProperty)
    FText ShuffleText; // 0x1978 (Size: 0x10, Type: TextProperty)

public:
    void UpdateShuffleText(bool& bShuffle); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void UpdateHoverAnimations(bool& IsHovered); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ShowSingleItem(bool& EnableSingleImageMode, TSoftObjectPtr<UObject*>& Item_Image, FDeprecateSlateVector2D& In_Brush_Image_Size); // 0x288a61c (Index: 0x2, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetupTile(TArray<UFortCommonLoadoutCategoryGroupPresetVM*> PresetItems); // 0x288a61c (Index: 0x3, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetupAsShuffleTile(); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetupAsSaveTile(); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetTileName(UFortCommonLoadoutPresetVM*& VM); // 0x288a61c (Index: 0x6, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetFortCommonLoadoutPresetVM(UFortCommonLoadoutPresetVM*& ViewModel); // 0x288a61c (Index: 0x7, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void SetContextMenuActionContext(const FDelegate RenameInInteractionDelegate, const FDelegate DeleteInInteractionDelegate); // 0x288a61c (Index: 0x8, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void RenameMegeapresetEventFired__DelegateSignature(UWBP_Itemcard_Myloadout_C*& MyloadoutCard); // 0x288a61c (Index: 0x9, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0xa, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void InitializeTile(bool& IsDesignTime); // 0x288a61c (Index: 0xc, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void DeleteMegapresetEventFired__DelegateSignature(UWBP_Itemcard_Myloadout_C*& MyloadoutCard); // 0x288a61c (Index: 0x10, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void ContextMenuVisibility(bool& ShowButton); // 0x288a61c (Index: 0x11, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnListItemObjectSet(UObject*& ListItemObject); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnUnhovered(); // 0x288a61c (Index: 0x12, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnSelected(); // 0x288a61c (Index: 0x13, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnItemSelectionChanged(bool& bIsSelected); // 0x288a61c (Index: 0x14, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnItemExpansionChanged(bool& bIsExpanded); // 0x288a61c (Index: 0x15, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnHovered(); // 0x288a61c (Index: 0x16, Flags: Event|Protected|BlueprintEvent)
    virtual FEventReply BP_OnHoldTriggered(ECommonInputType& CurrentInputType); // 0x288a61c (Index: 0x17, Flags: BlueprintCosmetic|Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void BP_OnEntryReleased(); // 0x288a61c (Index: 0x18, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDeselected(); // 0x288a61c (Index: 0x19, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnClicked(); // 0x288a61c (Index: 0x1a, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_Itemcard_Myloadout_C) == 0x1988, "Size mismatch for UWBP_Itemcard_Myloadout_C");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, UberGraphFrame) == 0x18e0, "Offset mismatch for UWBP_Itemcard_Myloadout_C::UberGraphFrame");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, WBP_CommonLoadout_Preview) == 0x18e8, "Offset mismatch for UWBP_Itemcard_Myloadout_C::WBP_CommonLoadout_Preview");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, Text_Loadoutname) == 0x18f0, "Offset mismatch for UWBP_Itemcard_Myloadout_C::Text_Loadoutname");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, ContextMenu) == 0x18f8, "Offset mismatch for UWBP_Itemcard_Myloadout_C::ContextMenu");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, Anim_Hover) == 0x1900, "Offset mismatch for UWBP_Itemcard_Myloadout_C::Anim_Hover");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, FortCommonLoadoutPresetVM) == 0x1908, "Offset mismatch for UWBP_Itemcard_Myloadout_C::FortCommonLoadoutPresetVM");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, FortCommonLoadoutsVM) == 0x1910, "Offset mismatch for UWBP_Itemcard_Myloadout_C::FortCommonLoadoutsVM");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, TextOffsetForTile) == 0x1918, "Offset mismatch for UWBP_Itemcard_Myloadout_C::TextOffsetForTile");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, Rename_In_Action_Info_Display_Name) == 0x1920, "Offset mismatch for UWBP_Itemcard_Myloadout_C::Rename_In_Action_Info_Display_Name");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, Delete_In_Action_Info_Display_Name) == 0x1930, "Offset mismatch for UWBP_Itemcard_Myloadout_C::Delete_In_Action_Info_Display_Name");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, RenameMegeapresetEventFired) == 0x1940, "Offset mismatch for UWBP_Itemcard_Myloadout_C::RenameMegeapresetEventFired");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, DeleteMegapresetEventFired) == 0x1950, "Offset mismatch for UWBP_Itemcard_Myloadout_C::DeleteMegapresetEventFired");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, Is_Save_as_New_Tile) == 0x1960, "Offset mismatch for UWBP_Itemcard_Myloadout_C::Is_Save_as_New_Tile");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, ContextMenuParentID) == 0x1968, "Offset mismatch for UWBP_Itemcard_Myloadout_C::ContextMenuParentID");
static_assert(offsetof(UWBP_Itemcard_Myloadout_C, ShuffleText) == 0x1978, "Offset mismatch for UWBP_Itemcard_Myloadout_C::ShuffleText");

// Size: 0x5ba (Inherited: 0xb38, Single: 0xfffffa82)
class UWBP_LoadoutScrollingList_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x408 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_ItemDescription_MPL_C* WPB_ItemDescription; // 0x410 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_InfoBox_C* WBP_CompatibilityInfo; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_InfoBox_C* WBP_CommonLoadout_Shuffle; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_InfoBox_C* WBP_CategoryPreset_Shuffle; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_SubHeader; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UOverlay* MainOverlay; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* LoadoutHeader_HBox; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Tag_C* LinkedLoadout_Tag; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* ItemDetails_VBox; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UFortItemListView* FullCategorySlotListView; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_FadeItemDetails; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_HideItemDetails; // 0x468 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_ShowItemDetails; // 0x470 (Size: 0x8, Type: ObjectProperty)
    UFortLockerVM* FortLockerVM; // 0x478 (Size: 0x8, Type: ObjectProperty)
    UFortItemSelectionVM* FortItemSelectionVM; // 0x480 (Size: 0x8, Type: ObjectProperty)
    UFortTypedModularLoadoutsVM* FortTypedModularLoadoutsVM; // 0x488 (Size: 0x8, Type: ObjectProperty)
    UFortCommonLoadoutsVM* FortCommonLoadoutsVM; // 0x490 (Size: 0x8, Type: ObjectProperty)
    int32_t CurrentEntryIndex; // 0x498 (Size: 0x4, Type: IntProperty)
    bool CurrentIsDirectionUp; // 0x49c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49d[0x3]; // 0x49d (Size: 0x3, Type: PaddingProperty)
    int32_t Current_Desired_Column; // 0x4a0 (Size: 0x4, Type: IntProperty)
    bool CurrentShouldApplyFocus; // 0x4a4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4a5[0x3]; // 0x4a5 (Size: 0x3, Type: PaddingProperty)
    TArray<UObject*> ListCategoryGroupItems; // 0x4a8 (Size: 0x10, Type: ArrayProperty)
    FText Category_Name; // 0x4b8 (Size: 0x10, Type: TextProperty)
    uint8_t OnOptionContextMenuOpened[0x10]; // 0x4c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnOptionContextMenuClosed[0x10]; // 0x4d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCategoryEditStyles[0x10]; // 0x4e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCategoryButtonClicked[0x10]; // 0x4f8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCategoryCardHovered[0x10]; // 0x508 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPresetSave[0x10]; // 0x518 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPresetLoad[0x10]; // 0x528 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t IsHoveredOverTile[0x10]; // 0x538 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t IsModalActive[0x10]; // 0x548 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMouseWheelNavRequested[0x10]; // 0x558 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool HasFocusPending; // 0x568 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_569[0x7]; // 0x569 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnKitsButtonPressed[0x10]; // 0x570 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FGameplayTag ContextButtonSeenID; // 0x580 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_584[0x4]; // 0x584 (Size: 0x4, Type: PaddingProperty)
    UCommonActivatableWidget* CurrentCoachMark; // 0x588 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle ItemDescriptionHideTimer; // 0x590 (Size: 0x8, Type: StructProperty)
    float ItemDetailsHideTime; // 0x598 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_59c[0x4]; // 0x59c (Size: 0x4, Type: PaddingProperty)
    uint8_t OnCategoryCardSelected[0x10]; // 0x5a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UObject* BottomEntryObject; // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    bool ShouldNavigate; // 0x5b8 (Size: 0x1, Type: BoolProperty)
    bool IgnoreClick; // 0x5b9 (Size: 0x1, Type: BoolProperty)

public:
    void UpdateShuffleLoadoutTextVisibility(bool& Index); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateListViewClipping(bool& ShouldClip); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateItemUsageDescription(FText& ItemUsageDescription); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateActiveLoadoutGroup(FString& ActiveLoadoutGroupName); // 0x288a61c (Index: 0x4, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Update_Shuffle_Message_Text(FText& Category); // 0x288a61c (Index: 0x5, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Update_Selected_Category_Index(UFortLockerCategoryGroupVM*& SelectedCategoryGroup); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Update_Selected_Category(UObject*& ViewListObject); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    void TriggerContextMenuCoachMark(); // 0x288a61c (Index: 0xe, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetMobileStyle(); // 0x288a61c (Index: 0x17, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ScrollToCategory(bool& FocusItem); // 0x288a61c (Index: 0x1b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ResetFocus(UWBP_CategorySlotListEntry_C*& EntryWidget); // 0x288a61c (Index: 0x1c, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void GetShuffleMessageText(FText& CategoryName); // 0x288a61c (Index: 0x1d, Flags: Public|BlueprintCallable|BlueprintEvent)
    UWidget* GetFocusTarget(); // 0x288a61c (Index: 0x1e, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void GetEntryToNav(UWBP_CategorySlotListEntry_C*& DesiredWidget) const; // 0x288a61c (Index: 0x1f, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual void Destruct(); // 0x288a61c (Index: 0x25, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void CheckIfEntryIsDisplayed(bool& IsDirectionUp, UWBP_CategorySlotListEntry_C*& DesiredWidget, bool& EntryDisplayed, bool& shouldIgnoreNav) const; // 0x288a61c (Index: 0x26, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void Preset_Random_ShuffleActive(bool& IsShuffle); // 0x288a61c (Index: 0x2b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void PopulateCategories(TArray<UFortLockerCategoryGroupCollectionVM*> Category_Group_Collections); // 0x288a61c (Index: 0x2c, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void OnPresetSave__DelegateSignature(); // 0x288a61c (Index: 0x2d, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnPresetLoad__DelegateSignature(); // 0x288a61c (Index: 0x2e, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnOptionContextMenuOpened__DelegateSignature(); // 0x288a61c (Index: 0x2f, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnOptionContextMenuClosed__DelegateSignature(); // 0x288a61c (Index: 0x30, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnMouseWheelNavRequested__DelegateSignature(bool& IsDirectionUp); // 0x288a61c (Index: 0x31, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual FEventReply OnMouseWheel(FGeometry& MyGeometry, const FPointerEvent MouseEvent); // 0x288a61c (Index: 0x32, Flags: BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnKitsButtonPressed__DelegateSignature(); // 0x288a61c (Index: 0x33, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void OnInitialized(); // 0x288a61c (Index: 0x34, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnCategoryEditStyles__DelegateSignature(); // 0x288a61c (Index: 0x35, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x36, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnCategoryCardSelected__DelegateSignature(UWBP_UIKit_ItemCard_Category_C*& ItemCardCategory); // 0x288a61c (Index: 0x37, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnCategoryCardHovered__DelegateSignature(UUserWidget*& CategoryItemEntryObject); // 0x288a61c (Index: 0x38, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnCategoryButtonClicked__DelegateSignature(); // 0x288a61c (Index: 0x39, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void NavToNextCategory(int32_t& DesiredColumn, bool& IsDirectionUp); // 0x288a61c (Index: 0x3a, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ItemScrolledIntoViewComplete(UObject*& Item, UUserWidget*& Widget); // 0x288a61c (Index: 0x3b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void IsModalActive__DelegateSignature(bool& IsModalActive); // 0x288a61c (Index: 0x3c, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void IsHoveredOverTile__DelegateSignature(bool& IsTileHovered); // 0x288a61c (Index: 0x3d, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_LoadoutScrollingList_C) == 0x5ba, "Size mismatch for UWBP_LoadoutScrollingList_C");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, UberGraphFrame) == 0x408, "Offset mismatch for UWBP_LoadoutScrollingList_C::UberGraphFrame");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, WPB_ItemDescription) == 0x410, "Offset mismatch for UWBP_LoadoutScrollingList_C::WPB_ItemDescription");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, WBP_CompatibilityInfo) == 0x418, "Offset mismatch for UWBP_LoadoutScrollingList_C::WBP_CompatibilityInfo");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, WBP_CommonLoadout_Shuffle) == 0x420, "Offset mismatch for UWBP_LoadoutScrollingList_C::WBP_CommonLoadout_Shuffle");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, WBP_CategoryPreset_Shuffle) == 0x428, "Offset mismatch for UWBP_LoadoutScrollingList_C::WBP_CategoryPreset_Shuffle");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, Text_SubHeader) == 0x430, "Offset mismatch for UWBP_LoadoutScrollingList_C::Text_SubHeader");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, MainOverlay) == 0x438, "Offset mismatch for UWBP_LoadoutScrollingList_C::MainOverlay");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, LoadoutHeader_HBox) == 0x440, "Offset mismatch for UWBP_LoadoutScrollingList_C::LoadoutHeader_HBox");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, LinkedLoadout_Tag) == 0x448, "Offset mismatch for UWBP_LoadoutScrollingList_C::LinkedLoadout_Tag");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, ItemDetails_VBox) == 0x450, "Offset mismatch for UWBP_LoadoutScrollingList_C::ItemDetails_VBox");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, FullCategorySlotListView) == 0x458, "Offset mismatch for UWBP_LoadoutScrollingList_C::FullCategorySlotListView");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, Anim_FadeItemDetails) == 0x460, "Offset mismatch for UWBP_LoadoutScrollingList_C::Anim_FadeItemDetails");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, Anim_HideItemDetails) == 0x468, "Offset mismatch for UWBP_LoadoutScrollingList_C::Anim_HideItemDetails");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, Anim_ShowItemDetails) == 0x470, "Offset mismatch for UWBP_LoadoutScrollingList_C::Anim_ShowItemDetails");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, FortLockerVM) == 0x478, "Offset mismatch for UWBP_LoadoutScrollingList_C::FortLockerVM");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, FortItemSelectionVM) == 0x480, "Offset mismatch for UWBP_LoadoutScrollingList_C::FortItemSelectionVM");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, FortTypedModularLoadoutsVM) == 0x488, "Offset mismatch for UWBP_LoadoutScrollingList_C::FortTypedModularLoadoutsVM");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, FortCommonLoadoutsVM) == 0x490, "Offset mismatch for UWBP_LoadoutScrollingList_C::FortCommonLoadoutsVM");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, CurrentEntryIndex) == 0x498, "Offset mismatch for UWBP_LoadoutScrollingList_C::CurrentEntryIndex");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, CurrentIsDirectionUp) == 0x49c, "Offset mismatch for UWBP_LoadoutScrollingList_C::CurrentIsDirectionUp");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, Current_Desired_Column) == 0x4a0, "Offset mismatch for UWBP_LoadoutScrollingList_C::Current_Desired_Column");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, CurrentShouldApplyFocus) == 0x4a4, "Offset mismatch for UWBP_LoadoutScrollingList_C::CurrentShouldApplyFocus");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, ListCategoryGroupItems) == 0x4a8, "Offset mismatch for UWBP_LoadoutScrollingList_C::ListCategoryGroupItems");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, Category_Name) == 0x4b8, "Offset mismatch for UWBP_LoadoutScrollingList_C::Category_Name");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, OnOptionContextMenuOpened) == 0x4c8, "Offset mismatch for UWBP_LoadoutScrollingList_C::OnOptionContextMenuOpened");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, OnOptionContextMenuClosed) == 0x4d8, "Offset mismatch for UWBP_LoadoutScrollingList_C::OnOptionContextMenuClosed");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, OnCategoryEditStyles) == 0x4e8, "Offset mismatch for UWBP_LoadoutScrollingList_C::OnCategoryEditStyles");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, OnCategoryButtonClicked) == 0x4f8, "Offset mismatch for UWBP_LoadoutScrollingList_C::OnCategoryButtonClicked");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, OnCategoryCardHovered) == 0x508, "Offset mismatch for UWBP_LoadoutScrollingList_C::OnCategoryCardHovered");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, OnPresetSave) == 0x518, "Offset mismatch for UWBP_LoadoutScrollingList_C::OnPresetSave");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, OnPresetLoad) == 0x528, "Offset mismatch for UWBP_LoadoutScrollingList_C::OnPresetLoad");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, IsHoveredOverTile) == 0x538, "Offset mismatch for UWBP_LoadoutScrollingList_C::IsHoveredOverTile");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, IsModalActive) == 0x548, "Offset mismatch for UWBP_LoadoutScrollingList_C::IsModalActive");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, OnMouseWheelNavRequested) == 0x558, "Offset mismatch for UWBP_LoadoutScrollingList_C::OnMouseWheelNavRequested");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, HasFocusPending) == 0x568, "Offset mismatch for UWBP_LoadoutScrollingList_C::HasFocusPending");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, OnKitsButtonPressed) == 0x570, "Offset mismatch for UWBP_LoadoutScrollingList_C::OnKitsButtonPressed");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, ContextButtonSeenID) == 0x580, "Offset mismatch for UWBP_LoadoutScrollingList_C::ContextButtonSeenID");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, CurrentCoachMark) == 0x588, "Offset mismatch for UWBP_LoadoutScrollingList_C::CurrentCoachMark");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, ItemDescriptionHideTimer) == 0x590, "Offset mismatch for UWBP_LoadoutScrollingList_C::ItemDescriptionHideTimer");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, ItemDetailsHideTime) == 0x598, "Offset mismatch for UWBP_LoadoutScrollingList_C::ItemDetailsHideTime");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, OnCategoryCardSelected) == 0x5a0, "Offset mismatch for UWBP_LoadoutScrollingList_C::OnCategoryCardSelected");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, BottomEntryObject) == 0x5b0, "Offset mismatch for UWBP_LoadoutScrollingList_C::BottomEntryObject");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, ShouldNavigate) == 0x5b8, "Offset mismatch for UWBP_LoadoutScrollingList_C::ShouldNavigate");
static_assert(offsetof(UWBP_LoadoutScrollingList_C, IgnoreClick) == 0x5b9, "Offset mismatch for UWBP_LoadoutScrollingList_C::IgnoreClick");

// Size: 0x598 (Inherited: 0x730, Single: 0xfffffe68)
class UWBP_CategorySlotListEntry_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2d8 (Size: 0x8, Type: StructProperty)
    UWBP_MyLoadout_CategorySet_C* WBP_MyLoadout_CategorySet; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UWBP_MPLocker_Heading_MyLoadout_C* WBP_MPLocker_Heading_Loadout; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    USpacer* ScrollEntrySpacer; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UFortLazyImage* PrimaryVehicleIndicator; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Tag_C* PresetName_Tag; // 0x300 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* JunoMessage_Text; // 0x308 (Size: 0x8, Type: ObjectProperty)
    UImage* Divider; // 0x310 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* ContextSwitcher; // 0x318 (Size: 0x8, Type: ObjectProperty)
    UFortVisualAttachment* CoachMark_Attachment_Preset; // 0x320 (Size: 0x8, Type: ObjectProperty)
    UFortVisualAttachment* CoachMark_Attachment_MM; // 0x328 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* CategoryVBox; // 0x330 (Size: 0x8, Type: ObjectProperty)
    UWBP_Locker_Button_C* Button_ViewJunoKits; // 0x338 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_ContextMenuAnchorButton_C* Button_Options; // 0x340 (Size: 0x8, Type: ObjectProperty)
    UButton* Button_Hitbox; // 0x348 (Size: 0x8, Type: ObjectProperty)
    UFortLockerCategoryGroupVM* FortLockerCategoryGroupVM; // 0x350 (Size: 0x8, Type: ObjectProperty)
    UFortItemSelectionVM* FortItemSelectionVM; // 0x358 (Size: 0x8, Type: ObjectProperty)
    UFortTypedModularLoadoutsVM* FortTypedModularLoadoutsVM; // 0x360 (Size: 0x8, Type: ObjectProperty)
    UFortLockerCategoryGroupCollectionVM* FortLockerCategoryGroupCollectionVM; // 0x368 (Size: 0x8, Type: ObjectProperty)
    float UnselectedOpacity; // 0x370 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_374[0x4]; // 0x374 (Size: 0x4, Type: PaddingProperty)
    uint8_t OnOptionContextMenuOpened[0x10]; // 0x378 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnOptionContextMenuClosed[0x10]; // 0x388 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCategoryEditStyles[0x10]; // 0x398 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCategoryButtonClicked[0x10]; // 0x3a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnNavToNextCategory[0x10]; // 0x3b8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t CurrentDesiredFocusColumn; // 0x3c8 (Size: 0x4, Type: IntProperty)
    bool CurrentIsDirectionUp; // 0x3cc (Size: 0x1, Type: BoolProperty)
    bool CurrentShouldApplyFocus; // 0x3cd (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3ce[0x2]; // 0x3ce (Size: 0x2, Type: PaddingProperty)
    UUIKitContextMenuActionContext* MenuActionContext; // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    FText Clear_All_Bangs_Action_Info_Display_Name; // 0x3d8 (Size: 0x10, Type: TextProperty)
    FText Randomize_Loadout_In_Action_Info_Display_Name; // 0x3e8 (Size: 0x10, Type: TextProperty)
    FText Clear_Loadout_In_Action_Info_Display_Name; // 0x3f8 (Size: 0x10, Type: TextProperty)
    FText Load_Preset_In_Action_Info_Display_Name; // 0x408 (Size: 0x10, Type: TextProperty)
    FText Set_Primary_Vehice_In_Action_Info_DisplayName; // 0x418 (Size: 0x10, Type: TextProperty)
    FText CategoryNameText; // 0x428 (Size: 0x10, Type: TextProperty)
    FText SavePresetText; // 0x438 (Size: 0x10, Type: TextProperty)
    FDataTableRowHandle ClearAllBangsInput; // 0x448 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle RandomizeLoadoutInput; // 0x458 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ClearLoadoutInput; // 0x468 (Size: 0x10, Type: StructProperty)
    uint8_t OnNavToSelf[0x10]; // 0x478 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnClearAllBangs[0x10]; // 0x488 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRandomizeAllSlots[0x10]; // 0x498 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCategoryCardHovered[0x10]; // 0x4a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FDataTableRowHandle SetPrimaryVehicleInput; // 0x4b8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle SavePresetsInput; // 0x4c8 (Size: 0x10, Type: StructProperty)
    uint8_t OnPresetSave[0x10]; // 0x4d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnIsModalActive[0x10]; // 0x4e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool CategorySelected; // 0x4f8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4f9[0x7]; // 0x4f9 (Size: 0x7, Type: PaddingProperty)
    FDataTableRowHandle Load_Presets_Input; // 0x500 (Size: 0x10, Type: StructProperty)
    uint8_t OnPresetLoad[0x10]; // 0x510 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t IsHoveredOverTile[0x10]; // 0x520 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FDataTableRowHandle Triggering_Input_Action; // 0x530 (Size: 0x10, Type: StructProperty)
    uint8_t OnKitsButtonPressed[0x10]; // 0x540 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UCommonActivatableWidget* CurrentCoachMark; // 0x550 (Size: 0x8, Type: ObjectProperty)
    uint8_t CoachMarkChanged[0x10]; // 0x558 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool ShowContextFTUE; // 0x568 (Size: 0x1, Type: BoolProperty)
    bool Is_Linked_Preset; // 0x569 (Size: 0x1, Type: BoolProperty)
    bool ContextMenuOpen; // 0x56a (Size: 0x1, Type: BoolProperty)
    bool CheckForMMCoachmark; // 0x56b (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_56c[0x4]; // 0x56c (Size: 0x4, Type: PaddingProperty)
    uint8_t OnCategoryCardSelected[0x10]; // 0x570 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool IsModalActive; // 0x580 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_581[0x7]; // 0x581 (Size: 0x7, Type: PaddingProperty)
    UWBP_MPLocker_SetPrimary_Dialog_C* VehicleModal; // 0x588 (Size: 0x8, Type: ObjectProperty)
    UWBP_NameLoadout_MP_C* NameModal; // 0x590 (Size: 0x8, Type: ObjectProperty)

public:
    void IsPrimaryArchetype(bool& IsActive); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void IsHoveredOverTile__DelegateSignature(bool& IsTileHovered); // 0x288a61c (Index: 0x1, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void GetNewCategoryNavigation(int32_t& DesiredColumn, bool& IsDirectionUp, UUserWidget*& Widget); // 0x288a61c (Index: 0x3, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    UWidget* Get_Desired_Focus_Widget(); // 0x288a61c (Index: 0x4, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void CoachMarkChanged__DelegateSignature(bool& IsShown); // 0x288a61c (Index: 0x7, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void IsShuffleMode(bool& IsShuffleLoadoutMode); // 0x288a61c (Index: 0x8, Flags: Public|BlueprintCallable|BlueprintEvent)
    void CloseContextMenu(); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFortLockerCategoryGroupCollectionVM(UFortLockerCategoryGroupCollectionVM*& ViewModel); // 0x288a61c (Index: 0x20, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void SetContextMenuActionContext(); // 0x288a61c (Index: 0x21, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetCategorySelection(bool& SelectionBool, bool& NewSelection); // 0x288a61c (Index: 0x22, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void ResetFocus(); // 0x288a61c (Index: 0x24, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x27, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnRandomizeAllSlots__DelegateSignature(); // 0x288a61c (Index: 0x28, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnPresetSave__DelegateSignature(); // 0x288a61c (Index: 0x29, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnPresetLoad__DelegateSignature(); // 0x288a61c (Index: 0x2a, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnOptionContextMenuOpened__DelegateSignature(); // 0x288a61c (Index: 0x2b, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnOptionContextMenuClosed__DelegateSignature(); // 0x288a61c (Index: 0x2c, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnNavToSelf__DelegateSignature(UFortLockerCategoryGroupVM*& NewParam); // 0x288a61c (Index: 0x2d, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnNavToNextCategory__DelegateSignature(int32_t& DesiredColumn, bool& IsDirectionUp); // 0x288a61c (Index: 0x2e, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnKitsButtonPressed__DelegateSignature(); // 0x288a61c (Index: 0x30, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnIsModalActive__DelegateSignature(bool& IsModalActive); // 0x288a61c (Index: 0x31, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void OnInitialized(); // 0x288a61c (Index: 0x32, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnClearAllBangs__DelegateSignature(); // 0x288a61c (Index: 0x33, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnCategoryEditStyles__DelegateSignature(); // 0x288a61c (Index: 0x34, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnCategoryCardSelected__DelegateSignature(UWBP_UIKit_ItemCard_Category_C*& ItemCardCategory); // 0x288a61c (Index: 0x35, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnCategoryCardHovered__DelegateSignature(UUserWidget*& HoveredWidget); // 0x288a61c (Index: 0x36, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnCategoryButtonClicked__DelegateSignature(); // 0x288a61c (Index: 0x37, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void ModalUnbinds(); // 0x288a61c (Index: 0x3a, Flags: Public|BlueprintCallable|BlueprintEvent)
    void JunoNextNavigation(EUINavigation& Navigation); // 0x288a61c (Index: 0x3e, Flags: Public|BlueprintCallable|BlueprintEvent)
    void IsShuffleArchetype(bool& IsActive); // 0x288a61c (Index: 0x3f, Flags: Public|BlueprintCallable|BlueprintEvent)
    void IsSelectedCategory(UFortLockerCategoryGroupVM*& SelectedCategoryVM); // 0x288a61c (Index: 0x40, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateLinkedPresetVisibility(bool& IsLinked); // 0x288a61c (Index: 0x42, Flags: Public|BlueprintCallable|BlueprintEvent)
    void TriggerMusicMomentsCoachmark(); // 0x288a61c (Index: 0x45, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void TriggerContextCoachMark(); // 0x288a61c (Index: 0x46, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetMobileLayout(); // 0x288a61c (Index: 0x49, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetJunoItemCount(TArray<UFortLockerCategoryItemVM*> CategoryItems); // 0x288a61c (Index: 0x4a, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetFortLockerCategoryGroupVM(UFortLockerCategoryGroupVM*& ViewModel); // 0x288a61c (Index: 0x4b, Flags: Final|Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void BP_OnItemSelectionChanged(bool& bIsSelected); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnItemExpansionChanged(bool& bIsExpanded); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnEntryReleased(); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void OnListItemObjectSet(UObject*& ListItemObject); // 0x288a61c (Index: 0x2f, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_CategorySlotListEntry_C) == 0x598, "Size mismatch for UWBP_CategorySlotListEntry_C");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, UberGraphFrame) == 0x2d8, "Offset mismatch for UWBP_CategorySlotListEntry_C::UberGraphFrame");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, WBP_MyLoadout_CategorySet) == 0x2e0, "Offset mismatch for UWBP_CategorySlotListEntry_C::WBP_MyLoadout_CategorySet");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, WBP_MPLocker_Heading_Loadout) == 0x2e8, "Offset mismatch for UWBP_CategorySlotListEntry_C::WBP_MPLocker_Heading_Loadout");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, ScrollEntrySpacer) == 0x2f0, "Offset mismatch for UWBP_CategorySlotListEntry_C::ScrollEntrySpacer");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, PrimaryVehicleIndicator) == 0x2f8, "Offset mismatch for UWBP_CategorySlotListEntry_C::PrimaryVehicleIndicator");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, PresetName_Tag) == 0x300, "Offset mismatch for UWBP_CategorySlotListEntry_C::PresetName_Tag");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, JunoMessage_Text) == 0x308, "Offset mismatch for UWBP_CategorySlotListEntry_C::JunoMessage_Text");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, Divider) == 0x310, "Offset mismatch for UWBP_CategorySlotListEntry_C::Divider");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, ContextSwitcher) == 0x318, "Offset mismatch for UWBP_CategorySlotListEntry_C::ContextSwitcher");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, CoachMark_Attachment_Preset) == 0x320, "Offset mismatch for UWBP_CategorySlotListEntry_C::CoachMark_Attachment_Preset");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, CoachMark_Attachment_MM) == 0x328, "Offset mismatch for UWBP_CategorySlotListEntry_C::CoachMark_Attachment_MM");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, CategoryVBox) == 0x330, "Offset mismatch for UWBP_CategorySlotListEntry_C::CategoryVBox");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, Button_ViewJunoKits) == 0x338, "Offset mismatch for UWBP_CategorySlotListEntry_C::Button_ViewJunoKits");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, Button_Options) == 0x340, "Offset mismatch for UWBP_CategorySlotListEntry_C::Button_Options");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, Button_Hitbox) == 0x348, "Offset mismatch for UWBP_CategorySlotListEntry_C::Button_Hitbox");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, FortLockerCategoryGroupVM) == 0x350, "Offset mismatch for UWBP_CategorySlotListEntry_C::FortLockerCategoryGroupVM");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, FortItemSelectionVM) == 0x358, "Offset mismatch for UWBP_CategorySlotListEntry_C::FortItemSelectionVM");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, FortTypedModularLoadoutsVM) == 0x360, "Offset mismatch for UWBP_CategorySlotListEntry_C::FortTypedModularLoadoutsVM");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, FortLockerCategoryGroupCollectionVM) == 0x368, "Offset mismatch for UWBP_CategorySlotListEntry_C::FortLockerCategoryGroupCollectionVM");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, UnselectedOpacity) == 0x370, "Offset mismatch for UWBP_CategorySlotListEntry_C::UnselectedOpacity");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnOptionContextMenuOpened) == 0x378, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnOptionContextMenuOpened");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnOptionContextMenuClosed) == 0x388, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnOptionContextMenuClosed");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnCategoryEditStyles) == 0x398, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnCategoryEditStyles");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnCategoryButtonClicked) == 0x3a8, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnCategoryButtonClicked");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnNavToNextCategory) == 0x3b8, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnNavToNextCategory");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, CurrentDesiredFocusColumn) == 0x3c8, "Offset mismatch for UWBP_CategorySlotListEntry_C::CurrentDesiredFocusColumn");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, CurrentIsDirectionUp) == 0x3cc, "Offset mismatch for UWBP_CategorySlotListEntry_C::CurrentIsDirectionUp");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, CurrentShouldApplyFocus) == 0x3cd, "Offset mismatch for UWBP_CategorySlotListEntry_C::CurrentShouldApplyFocus");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, MenuActionContext) == 0x3d0, "Offset mismatch for UWBP_CategorySlotListEntry_C::MenuActionContext");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, Clear_All_Bangs_Action_Info_Display_Name) == 0x3d8, "Offset mismatch for UWBP_CategorySlotListEntry_C::Clear_All_Bangs_Action_Info_Display_Name");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, Randomize_Loadout_In_Action_Info_Display_Name) == 0x3e8, "Offset mismatch for UWBP_CategorySlotListEntry_C::Randomize_Loadout_In_Action_Info_Display_Name");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, Clear_Loadout_In_Action_Info_Display_Name) == 0x3f8, "Offset mismatch for UWBP_CategorySlotListEntry_C::Clear_Loadout_In_Action_Info_Display_Name");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, Load_Preset_In_Action_Info_Display_Name) == 0x408, "Offset mismatch for UWBP_CategorySlotListEntry_C::Load_Preset_In_Action_Info_Display_Name");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, Set_Primary_Vehice_In_Action_Info_DisplayName) == 0x418, "Offset mismatch for UWBP_CategorySlotListEntry_C::Set_Primary_Vehice_In_Action_Info_DisplayName");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, CategoryNameText) == 0x428, "Offset mismatch for UWBP_CategorySlotListEntry_C::CategoryNameText");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, SavePresetText) == 0x438, "Offset mismatch for UWBP_CategorySlotListEntry_C::SavePresetText");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, ClearAllBangsInput) == 0x448, "Offset mismatch for UWBP_CategorySlotListEntry_C::ClearAllBangsInput");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, RandomizeLoadoutInput) == 0x458, "Offset mismatch for UWBP_CategorySlotListEntry_C::RandomizeLoadoutInput");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, ClearLoadoutInput) == 0x468, "Offset mismatch for UWBP_CategorySlotListEntry_C::ClearLoadoutInput");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnNavToSelf) == 0x478, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnNavToSelf");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnClearAllBangs) == 0x488, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnClearAllBangs");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnRandomizeAllSlots) == 0x498, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnRandomizeAllSlots");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnCategoryCardHovered) == 0x4a8, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnCategoryCardHovered");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, SetPrimaryVehicleInput) == 0x4b8, "Offset mismatch for UWBP_CategorySlotListEntry_C::SetPrimaryVehicleInput");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, SavePresetsInput) == 0x4c8, "Offset mismatch for UWBP_CategorySlotListEntry_C::SavePresetsInput");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnPresetSave) == 0x4d8, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnPresetSave");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnIsModalActive) == 0x4e8, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnIsModalActive");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, CategorySelected) == 0x4f8, "Offset mismatch for UWBP_CategorySlotListEntry_C::CategorySelected");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, Load_Presets_Input) == 0x500, "Offset mismatch for UWBP_CategorySlotListEntry_C::Load_Presets_Input");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnPresetLoad) == 0x510, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnPresetLoad");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, IsHoveredOverTile) == 0x520, "Offset mismatch for UWBP_CategorySlotListEntry_C::IsHoveredOverTile");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, Triggering_Input_Action) == 0x530, "Offset mismatch for UWBP_CategorySlotListEntry_C::Triggering_Input_Action");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnKitsButtonPressed) == 0x540, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnKitsButtonPressed");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, CurrentCoachMark) == 0x550, "Offset mismatch for UWBP_CategorySlotListEntry_C::CurrentCoachMark");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, CoachMarkChanged) == 0x558, "Offset mismatch for UWBP_CategorySlotListEntry_C::CoachMarkChanged");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, ShowContextFTUE) == 0x568, "Offset mismatch for UWBP_CategorySlotListEntry_C::ShowContextFTUE");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, Is_Linked_Preset) == 0x569, "Offset mismatch for UWBP_CategorySlotListEntry_C::Is_Linked_Preset");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, ContextMenuOpen) == 0x56a, "Offset mismatch for UWBP_CategorySlotListEntry_C::ContextMenuOpen");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, CheckForMMCoachmark) == 0x56b, "Offset mismatch for UWBP_CategorySlotListEntry_C::CheckForMMCoachmark");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, OnCategoryCardSelected) == 0x570, "Offset mismatch for UWBP_CategorySlotListEntry_C::OnCategoryCardSelected");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, IsModalActive) == 0x580, "Offset mismatch for UWBP_CategorySlotListEntry_C::IsModalActive");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, VehicleModal) == 0x588, "Offset mismatch for UWBP_CategorySlotListEntry_C::VehicleModal");
static_assert(offsetof(UWBP_CategorySlotListEntry_C, NameModal) == 0x590, "Offset mismatch for UWBP_CategorySlotListEntry_C::NameModal");

// Size: 0x7f1 (Inherited: 0x1b88, Single: 0xffffec69)
class UFortMPLocker_MyLoadout_Full_C : public UAthenaCustomizationScreenBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x598 (Size: 0x8, Type: StructProperty)
    USizeBox* Widget_CameraFrame; // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    UWBP_MPLocker_ServiceNotice_C* WBP_MPLocker_ServiceNotice; // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    UWBP_AthenaBottomBar_WithNotifications_C* WBP_AthenaBottomBar_WithNotifications; // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    UWBP_ActionBarContainer_C* WBP_ActionBarContainer_Right; // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    UWBP_ActionBarContainer_C* WBP_ActionBarContainer_Left; // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    UWBP_MPLocker_SideNavigation_C* UIKit_SideNavigation; // 0x5c8 (Size: 0x8, Type: ObjectProperty)
    UFortSwipePanel* TouchNavigationSwipePanel; // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    UWBP_MyLoadouts_C* TEMP_MyLoadouts_MegaPresets; // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_PreviewWindow; // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_0; // 0x5e8 (Size: 0x8, Type: ObjectProperty)
    USafeZone* SafeZone; // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    UWBP_MPLocker_Presets_C* PresetsWidget; // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_SaveLoadout; // 0x600 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_RandomToggle; // 0x608 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_OptionVisibility; // 0x610 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_EquipVisibility; // 0x618 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_BackToTopVisibility; // 0x620 (Size: 0x8, Type: ObjectProperty)
    UWBP_LoadoutScrollingList_C* MyLoadouts_Categories; // 0x628 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* MyLoadout_NavWrapper; // 0x630 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* Grid_Main; // 0x638 (Size: 0x8, Type: ObjectProperty)
    UFortItemPreviewWidget_C* FortItemPreviewWidget; // 0x640 (Size: 0x8, Type: ObjectProperty)
    UFortVisualAttachment* CoachMark_Attachment; // 0x648 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* CategoryTabs_NavWrapper; // 0x650 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* CategoriesNavWrapper; // 0x658 (Size: 0x8, Type: ObjectProperty)
    USpacer* Camera_Spacer_Right; // 0x660 (Size: 0x8, Type: ObjectProperty)
    USpacer* Camera_Spacer_Left; // 0x668 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Quiet_C* Button_ViewAllLoadouts; // 0x670 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Quiet_C* Button_SaveLoadouts; // 0x678 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Quiet_C* Button_RandomToggle; // 0x680 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Quiet_C* Button_Options; // 0x688 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Quiet_C* Button_Equip; // 0x690 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Quiet_C* Button_ClearBadges_Gamepad; // 0x698 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* Button_Bar_Right; // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    UWBP_MPLocker_BackToTopButton_C* Button_BackToTop; // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Quiet_C* Button_Back; // 0x6b0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* BackToGame_Visibility; // 0x6b8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* TogglePresetsFullscreen; // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* CameraSlideOut; // 0x6c8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* CameraSlideIn; // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Intro; // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* PresetsPeek; // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* TogglePresetsFullscreenMobile; // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ToggleMyLoadouts; // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Default; // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    UFortItemSelectionVM* FortItemSelectionVM; // 0x700 (Size: 0x8, Type: ObjectProperty)
    UFortLockerVM* FortLockerVM; // 0x708 (Size: 0x8, Type: ObjectProperty)
    UFortLockerCategoryItemVM* PrimaryCategoryItemVM; // 0x710 (Size: 0x8, Type: ObjectProperty)
    UFortTypedModularLoadoutsVM* FortTypedModularLoadoutsVM; // 0x718 (Size: 0x8, Type: ObjectProperty)
    UFortCommonLoadoutsVM* FortCommonLoadoutsVM; // 0x720 (Size: 0x8, Type: ObjectProperty)
    UFortLocalPlayerVM* FortLocalPlayerVM; // 0x728 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<ELockerScreenList> ActiveScreen; // 0x730 (Size: 0x1, Type: ByteProperty)
    bool CameraIsLeft; // 0x731 (Size: 0x1, Type: BoolProperty)
    bool Is_Presets_Active; // 0x732 (Size: 0x1, Type: BoolProperty)
    bool IsTabsExpanded; // 0x733 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_734[0x4]; // 0x734 (Size: 0x4, Type: PaddingProperty)
    uint8_t AnimStarted[0x10]; // 0x738 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool Is_Save_Mode; // 0x748 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_749[0x7]; // 0x749 (Size: 0x7, Type: PaddingProperty)
    USoundBase* LockerCategoryWhooshSound; // 0x750 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_ItemCard_Category_C* Hovered_Category; // 0x758 (Size: 0x8, Type: ObjectProperty)
    double LastPreviewScale; // 0x760 (Size: 0x8, Type: DoubleProperty)
    UWBP_UIKit_PresetCard_C* Hovered_Preset_Button; // 0x768 (Size: 0x8, Type: ObjectProperty)
    bool Is_Modal_Active; // 0x770 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_771[0x7]; // 0x771 (Size: 0x7, Type: PaddingProperty)
    UFortTypedModularLoadoutVM* LastSelectedLoadout; // 0x778 (Size: 0x8, Type: ObjectProperty)
    bool isScrollEnabled; // 0x780 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_781[0x7]; // 0x781 (Size: 0x7, Type: PaddingProperty)
    double PresetsMenuSize; // 0x788 (Size: 0x8, Type: DoubleProperty)
    double CameraPosition; // 0x790 (Size: 0x8, Type: DoubleProperty)
    bool IsTileHovered; // 0x798 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_799[0x3]; // 0x799 (Size: 0x3, Type: PaddingProperty)
    float PreviewNotEquippableFixedWidth; // 0x79c (Size: 0x4, Type: FloatProperty)
    FMargin PreviewNotEquipabblePadding; // 0x7a0 (Size: 0x10, Type: StructProperty)
    bool Is_MyLoadoutActive; // 0x7b0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7b1[0x7]; // 0x7b1 (Size: 0x7, Type: PaddingProperty)
    UWBP_Locker_SaveLoadout_CoachMark_C* SaveLoadoutCoachMark; // 0x7b8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag ContextButtonSeenID; // 0x7c0 (Size: 0x4, Type: StructProperty)
    FGameplayTag Save_Loadout_Seen_ID; // 0x7c4 (Size: 0x4, Type: StructProperty)
    UFortCommonLoadoutPresetVM* FirstCommonLoadoutPreset; // 0x7c8 (Size: 0x8, Type: ObjectProperty)
    UAsyncAction_StartListeningToEvent* ChatEventWatch; // 0x7d0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag PCB_Seen_ID; // 0x7d8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_7dc[0x4]; // 0x7dc (Size: 0x4, Type: PaddingProperty)
    UWBP_Locker_PCB_CoachMark_C* PCBCoachMark; // 0x7e0 (Size: 0x8, Type: ObjectProperty)
    UWBP_AthenaBannerSelectModal_C* BannerSelectModal; // 0x7e8 (Size: 0x8, Type: ObjectProperty)
    bool IsAnyContextMenuOpened; // 0x7f0 (Size: 0x1, Type: BoolProperty)

public:
    void Bind_Preview_Actions(); // 0x288a61c (Index: 0x1d, Flags: Public|BlueprintCallable|BlueprintEvent)
    void AnimStarted__DelegateSignature(double& AnimLength); // 0x288a61c (Index: 0x1f, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void AdjustPresetsCamera(double& FloatProgress); // 0x288a61c (Index: 0x20, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    UWidget* Navigation_GoToTiles(EUINavigation& Navigation); // 0x288a61c (Index: 0x26, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    UWidget* Navigation_GoToTabs(EUINavigation& Navigation); // 0x288a61c (Index: 0x27, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void Loadout_Loaded(); // 0x288a61c (Index: 0x28, Flags: Public|BlueprintCallable|BlueprintEvent)
    void IsSelectedItemInvalidOnTouchInput(UObject*& SelectedItem, bool& IsSelectedItemInvalidOnTouchInput); // 0x288a61c (Index: 0x29, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    bool Is_In_Legacy_Stw_Locker(); // 0x288a61c (Index: 0x2a, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void Handle3DCameraTransition(); // 0x288a61c (Index: 0x2e, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Handle_Collectable_Tabs_Clicked(); // 0x288a61c (Index: 0x2f, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Handle_Category_Selected(FName& InputPin); // 0x288a61c (Index: 0x30, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetItemSelectionVMConfig(UFortLockerCategoryConfig*& const VMConfig); // 0x288a61c (Index: 0x31, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void GetItemsAreEquippable(bool& bItemsAreEquippable) const; // 0x288a61c (Index: 0x32, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void GetFirstCommonLoadoutPreset(TArray<UFortCommonLoadoutPresetVM*> Loadout_Presets); // 0x288a61c (Index: 0x33, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void Destruct(); // 0x288a61c (Index: 0x38, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x39, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void CanChangeCategory(bool& Result); // 0x288a61c (Index: 0x3b, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void Update_MLO_Buttons_Visibililty(UFortCommonLoadoutPresetVM*& Common_Loadout_Preset); // 0x288a61c (Index: 0x42, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Update_Flow_Rider_Sub_View(); // 0x288a61c (Index: 0x43, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Update_Buttons_Visibility(UFortTypedModularLoadoutVM*& Typed_Modular_Loadout); // 0x288a61c (Index: 0x44, Flags: Public|BlueprintCallable|BlueprintEvent)
    void TriggerShowMyloadoutFTUE(); // 0x288a61c (Index: 0x46, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SwitchScreen_Presets(bool& IsPresetsActive, bool& NoAnimations, bool& IsSaveMode); // 0x288a61c (Index: 0x47, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SwitchScreen_MyLoadout(bool& IsMyLoadoutsActive, bool& NoAnimations, bool& IsSaveMode); // 0x288a61c (Index: 0x48, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void StW_Reset_Category_Focus(); // 0x288a61c (Index: 0x49, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SkipMyLoadoutFTUE(); // 0x288a61c (Index: 0x4a, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ShufflePresetsActive(bool& ShuffleEnabled); // 0x288a61c (Index: 0x4b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ShowNextCoachMark(); // 0x288a61c (Index: 0x4c, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SharedScreenButtonOverlayVisibility(); // 0x288a61c (Index: 0x4d, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetPrimaryCategoryItemVM(UFortLockerCategoryItemVM*& ViewModel); // 0x288a61c (Index: 0x4e, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void SetPresetsMenuSize(double& IsFullscreen); // 0x288a61c (Index: 0x4f, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetMobileLayout(); // 0x288a61c (Index: 0x50, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetCustomPaddingForStw(); // 0x288a61c (Index: 0x51, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetCameraPosition(double& CameraPosition); // 0x288a61c (Index: 0x52, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetAllInteractionsEnabled(bool& IsInteractionEnabled); // 0x288a61c (Index: 0x55, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Collectable_Preview_Widget_Position(); // 0x288a61c (Index: 0x56, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SelectFirstSlot(); // 0x288a61c (Index: 0x57, Flags: Public|BlueprintCallable|BlueprintEvent)
    void RemovePCBCoachMark(); // 0x288a61c (Index: 0x58, Flags: Public|BlueprintCallable|BlueprintEvent)
    void RemoveLoadoutCoachMark(); // 0x288a61c (Index: 0x59, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x5c, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual FEventReply OnPreviewKeyDown(FGeometry& MyGeometry, FKeyEvent& InKeyEvent); // 0x288a61c (Index: 0x62, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void UpdateViewLoadoutsButtonText(); // 0x288a61c (Index: 0x63, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void UpdateLeftButtonBarVisibility(ESlateVisibility& InVisibility); // 0x288a61c (Index: 0x66, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateInputVisibilityButtons(ECommonInputType& InputType); // 0x288a61c (Index: 0x67, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateCategoryPreviewScale(UFortLockerCategoryItemVM*& CategoryToPreview); // 0x288a61c (Index: 0x68, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    virtual void BP_OnDeactivated(); // 0x288a61c (Index: 0x3c, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnActivated(); // 0x288a61c (Index: 0x3d, Flags: Event|Protected|BlueprintEvent)
    virtual FUIInputConfig BP_GetDesiredInputConfig() const; // 0x288a61c (Index: 0x3e, Flags: Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const)
    virtual UWidget* BP_GetDesiredFocusTarget() const; // 0x288a61c (Index: 0x3f, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
    void SetButtonsVisibilityForPresetsLayout(bool& HasPrompts); // 0x288a61c (Index: 0x53, Flags: Protected|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetButtonsVisibilityForMainLayout(bool& HasPrompts); // 0x288a61c (Index: 0x54, Flags: Protected|HasOutParms|BlueprintCallable|BlueprintEvent)
    void UpdateRandomButton(); // 0x288a61c (Index: 0x64, Flags: Protected|HasDefaults|BlueprintCallable|BlueprintEvent)
    void UpdateOptionsButtonOverlayVisibility(bool& HasPrompts); // 0x288a61c (Index: 0x65, Flags: Protected|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UFortMPLocker_MyLoadout_Full_C) == 0x7f1, "Size mismatch for UFortMPLocker_MyLoadout_Full_C");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, UberGraphFrame) == 0x598, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::UberGraphFrame");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Widget_CameraFrame) == 0x5a0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Widget_CameraFrame");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, WBP_MPLocker_ServiceNotice) == 0x5a8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::WBP_MPLocker_ServiceNotice");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, WBP_AthenaBottomBar_WithNotifications) == 0x5b0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::WBP_AthenaBottomBar_WithNotifications");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, WBP_ActionBarContainer_Right) == 0x5b8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::WBP_ActionBarContainer_Right");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, WBP_ActionBarContainer_Left) == 0x5c0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::WBP_ActionBarContainer_Left");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, UIKit_SideNavigation) == 0x5c8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::UIKit_SideNavigation");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, TouchNavigationSwipePanel) == 0x5d0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::TouchNavigationSwipePanel");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, TEMP_MyLoadouts_MegaPresets) == 0x5d8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::TEMP_MyLoadouts_MegaPresets");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, SizeBox_PreviewWindow) == 0x5e0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::SizeBox_PreviewWindow");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, SizeBox_0) == 0x5e8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::SizeBox_0");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, SafeZone) == 0x5f0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::SafeZone");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, PresetsWidget) == 0x5f8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::PresetsWidget");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Overlay_SaveLoadout) == 0x600, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Overlay_SaveLoadout");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Overlay_RandomToggle) == 0x608, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Overlay_RandomToggle");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Overlay_OptionVisibility) == 0x610, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Overlay_OptionVisibility");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Overlay_EquipVisibility) == 0x618, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Overlay_EquipVisibility");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Overlay_BackToTopVisibility) == 0x620, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Overlay_BackToTopVisibility");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, MyLoadouts_Categories) == 0x628, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::MyLoadouts_Categories");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, MyLoadout_NavWrapper) == 0x630, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::MyLoadout_NavWrapper");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Grid_Main) == 0x638, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Grid_Main");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, FortItemPreviewWidget) == 0x640, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::FortItemPreviewWidget");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, CoachMark_Attachment) == 0x648, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::CoachMark_Attachment");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, CategoryTabs_NavWrapper) == 0x650, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::CategoryTabs_NavWrapper");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, CategoriesNavWrapper) == 0x658, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::CategoriesNavWrapper");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Camera_Spacer_Right) == 0x660, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Camera_Spacer_Right");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Camera_Spacer_Left) == 0x668, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Camera_Spacer_Left");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Button_ViewAllLoadouts) == 0x670, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Button_ViewAllLoadouts");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Button_SaveLoadouts) == 0x678, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Button_SaveLoadouts");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Button_RandomToggle) == 0x680, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Button_RandomToggle");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Button_Options) == 0x688, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Button_Options");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Button_Equip) == 0x690, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Button_Equip");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Button_ClearBadges_Gamepad) == 0x698, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Button_ClearBadges_Gamepad");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Button_Bar_Right) == 0x6a0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Button_Bar_Right");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Button_BackToTop) == 0x6a8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Button_BackToTop");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Button_Back) == 0x6b0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Button_Back");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, BackToGame_Visibility) == 0x6b8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::BackToGame_Visibility");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, TogglePresetsFullscreen) == 0x6c0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::TogglePresetsFullscreen");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, CameraSlideOut) == 0x6c8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::CameraSlideOut");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, CameraSlideIn) == 0x6d0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::CameraSlideIn");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Intro) == 0x6d8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Intro");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, PresetsPeek) == 0x6e0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::PresetsPeek");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, TogglePresetsFullscreenMobile) == 0x6e8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::TogglePresetsFullscreenMobile");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, ToggleMyLoadouts) == 0x6f0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::ToggleMyLoadouts");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Default) == 0x6f8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Default");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, FortItemSelectionVM) == 0x700, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::FortItemSelectionVM");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, FortLockerVM) == 0x708, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::FortLockerVM");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, PrimaryCategoryItemVM) == 0x710, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::PrimaryCategoryItemVM");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, FortTypedModularLoadoutsVM) == 0x718, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::FortTypedModularLoadoutsVM");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, FortCommonLoadoutsVM) == 0x720, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::FortCommonLoadoutsVM");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, FortLocalPlayerVM) == 0x728, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::FortLocalPlayerVM");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, ActiveScreen) == 0x730, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::ActiveScreen");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, CameraIsLeft) == 0x731, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::CameraIsLeft");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Is_Presets_Active) == 0x732, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Is_Presets_Active");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, IsTabsExpanded) == 0x733, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::IsTabsExpanded");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, AnimStarted) == 0x738, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::AnimStarted");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Is_Save_Mode) == 0x748, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Is_Save_Mode");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, LockerCategoryWhooshSound) == 0x750, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::LockerCategoryWhooshSound");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Hovered_Category) == 0x758, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Hovered_Category");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, LastPreviewScale) == 0x760, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::LastPreviewScale");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Hovered_Preset_Button) == 0x768, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Hovered_Preset_Button");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Is_Modal_Active) == 0x770, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Is_Modal_Active");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, LastSelectedLoadout) == 0x778, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::LastSelectedLoadout");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, isScrollEnabled) == 0x780, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::isScrollEnabled");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, PresetsMenuSize) == 0x788, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::PresetsMenuSize");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, CameraPosition) == 0x790, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::CameraPosition");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, IsTileHovered) == 0x798, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::IsTileHovered");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, PreviewNotEquippableFixedWidth) == 0x79c, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::PreviewNotEquippableFixedWidth");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, PreviewNotEquipabblePadding) == 0x7a0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::PreviewNotEquipabblePadding");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Is_MyLoadoutActive) == 0x7b0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Is_MyLoadoutActive");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, SaveLoadoutCoachMark) == 0x7b8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::SaveLoadoutCoachMark");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, ContextButtonSeenID) == 0x7c0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::ContextButtonSeenID");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, Save_Loadout_Seen_ID) == 0x7c4, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::Save_Loadout_Seen_ID");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, FirstCommonLoadoutPreset) == 0x7c8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::FirstCommonLoadoutPreset");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, ChatEventWatch) == 0x7d0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::ChatEventWatch");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, PCB_Seen_ID) == 0x7d8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::PCB_Seen_ID");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, PCBCoachMark) == 0x7e0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::PCBCoachMark");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, BannerSelectModal) == 0x7e8, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::BannerSelectModal");
static_assert(offsetof(UFortMPLocker_MyLoadout_Full_C, IsAnyContextMenuOpened) == 0x7f0, "Offset mismatch for UFortMPLocker_MyLoadout_Full_C::IsAnyContextMenuOpened");

// Size: 0x378 (Inherited: 0x458, Single: 0xffffff20)
class UWBP_MPLocker_SideNavigation_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2b0 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_SideNavigation_C* UIKit_SideNavigation; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_Mobile; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UScaleBox* ScaleBox_ClearBadges_Mobile; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UButton* Button_Hitbox; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Collapsible_C* Button_ClearBadges; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Generic_C* Button_BackToSideNavigation; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UFortItemSelectionVM* FortItemSelectionVM; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnSideNavigationSelectionChanged[0x10]; // 0x2f0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnClearBadgesClicked[0x10]; // 0x300 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSideNavigationFocused[0x10]; // 0x310 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSideNavigationUnfocused[0x10]; // 0x320 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool ShouldConsumeNextSelectionEvent; // 0x330 (Size: 0x1, Type: BoolProperty)
    bool IsCollapsed; // 0x331 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_332[0x6]; // 0x332 (Size: 0x6, Type: PaddingProperty)
    double ElementsDesiredTextWidth; // 0x338 (Size: 0x8, Type: DoubleProperty)
    FVector2D ContainerArrowSize; // 0x340 (Size: 0x10, Type: StructProperty)
    bool IsTopCategorySelected; // 0x350 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_351[0x7]; // 0x351 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnSideNavigationCollapsedChanged[0x10]; // 0x358 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FName CurrentMainTabID; // 0x368 (Size: 0x4, Type: NameProperty)
    bool WaitForExpand; // 0x36c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_36d[0x3]; // 0x36d (Size: 0x3, Type: PaddingProperty)
    UWidget* SubTabToFocus; // 0x370 (Size: 0x8, Type: ObjectProperty)

public:
    void OnExpandFinished(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void OnClearBadgesClicked__DelegateSignature(); // 0x288a61c (Index: 0x1, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x2, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void OnAddedToFocusPath(FFocusEvent& InFocusEvent); // 0x288a61c (Index: 0x3, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void IsClearBadgesActive(bool& IsActive); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleCategoryGroupChanged(UFortLockerCategoryGroupVM*& Selected_Category_Group); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetFocusTarget(UWidget*& Widget) const; // 0x288a61c (Index: 0x7, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void ForceFocusTab(UWidget*& WidgetTarget, bool& WaitForExpand); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void Destruct(); // 0x288a61c (Index: 0xc, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0xd, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void UpdateSideNavigation(FName& TabID, FName& InnerTabID, UMVVMViewModelBase*& TabViewModel); // 0x288a61c (Index: 0x1a, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Update_Flow_Rider_Sub_View(); // 0x288a61c (Index: 0x1c, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UnbindCategoryExpand(); // 0x288a61c (Index: 0x1d, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetSideNavAllEnabled(bool& Enabled); // 0x288a61c (Index: 0x1e, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetMobileLayout(); // 0x288a61c (Index: 0x1f, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetIsCollapsed(bool& IsCollapsed, bool& SkipAnimation); // 0x288a61c (Index: 0x20, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SelectTopCategory(); // 0x288a61c (Index: 0x21, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SelectCorrespondentSideNavButton(); // 0x288a61c (Index: 0x22, Flags: Public|BlueprintCallable|BlueprintEvent)
    void PopulateCategories(const TArray<UFortLockerCategoryGroupCollectionVM*> CategoryGroupCollections); // 0x288a61c (Index: 0x23, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnSideNavigationUnfocused__DelegateSignature(); // 0x288a61c (Index: 0x24, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnSideNavigationSelectionChanged__DelegateSignature(UMVVMViewModelBase*& Tab_VM, bool& ShouldFocus); // 0x288a61c (Index: 0x25, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnSideNavigationFocused__DelegateSignature(); // 0x288a61c (Index: 0x26, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnSideNavigationCollapsedChanged__DelegateSignature(bool& IsCollapsed); // 0x288a61c (Index: 0x27, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void OnRemovedFromFocusPath(FFocusEvent& InFocusEvent); // 0x288a61c (Index: 0x28, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void OnMouseLeave(const FPointerEvent MouseEvent); // 0x288a61c (Index: 0x29, Flags: BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnMouseEnter(FGeometry& MyGeometry, const FPointerEvent MouseEvent); // 0x288a61c (Index: 0x2a, Flags: BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent)

protected:
    void HandleCollapseRequest(bool& ShouldCollapse, bool& IsImmediate); // 0x288a61c (Index: 0x5, Flags: Protected|BlueprintCallable|BlueprintEvent)
    void CheckTopCategorySelected(UMVVMViewModelBase*& VM); // 0x288a61c (Index: 0xe, Flags: Protected|BlueprintCallable|BlueprintEvent)
    void UpdateSelectedCategoryViewModel(UMVVMViewModelBase*& Tab_VM, FName& TabNameID); // 0x288a61c (Index: 0x1b, Flags: Protected|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_MPLocker_SideNavigation_C) == 0x378, "Size mismatch for UWBP_MPLocker_SideNavigation_C");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, UberGraphFrame) == 0x2b0, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::UberGraphFrame");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, UIKit_SideNavigation) == 0x2b8, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::UIKit_SideNavigation");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, SizeBox_Mobile) == 0x2c0, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::SizeBox_Mobile");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, ScaleBox_ClearBadges_Mobile) == 0x2c8, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::ScaleBox_ClearBadges_Mobile");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, Button_Hitbox) == 0x2d0, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::Button_Hitbox");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, Button_ClearBadges) == 0x2d8, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::Button_ClearBadges");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, Button_BackToSideNavigation) == 0x2e0, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::Button_BackToSideNavigation");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, FortItemSelectionVM) == 0x2e8, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::FortItemSelectionVM");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, OnSideNavigationSelectionChanged) == 0x2f0, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::OnSideNavigationSelectionChanged");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, OnClearBadgesClicked) == 0x300, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::OnClearBadgesClicked");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, OnSideNavigationFocused) == 0x310, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::OnSideNavigationFocused");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, OnSideNavigationUnfocused) == 0x320, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::OnSideNavigationUnfocused");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, ShouldConsumeNextSelectionEvent) == 0x330, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::ShouldConsumeNextSelectionEvent");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, IsCollapsed) == 0x331, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::IsCollapsed");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, ElementsDesiredTextWidth) == 0x338, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::ElementsDesiredTextWidth");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, ContainerArrowSize) == 0x340, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::ContainerArrowSize");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, IsTopCategorySelected) == 0x350, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::IsTopCategorySelected");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, OnSideNavigationCollapsedChanged) == 0x358, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::OnSideNavigationCollapsedChanged");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, CurrentMainTabID) == 0x368, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::CurrentMainTabID");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, WaitForExpand) == 0x36c, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::WaitForExpand");
static_assert(offsetof(UWBP_MPLocker_SideNavigation_C, SubTabToFocus) == 0x370, "Offset mismatch for UWBP_MPLocker_SideNavigation_C::SubTabToFocus");

// Size: 0x18f8 (Inherited: 0x48f4, Single: 0xffffd004)
class UWBP_MPLocker_Button_SubCategory_C : public UWBP_UIKit_ButtonGeneric_Base_C
{
public:
    uint8_t Pad_1864[0x4]; // 0x1864 (Size: 0x4, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0x1868 (Size: 0x8, Type: StructProperty)
    UWidgetAnimation* ShowText; // 0x1870 (Size: 0x8, Type: ObjectProperty)
    UFortLockerCategoryGroupVM* FortLockerCategoryGroupVM; // 0x1878 (Size: 0x8, Type: ObjectProperty)
    UFortLockerCategoryGroupCollectionVM* FortLockerCategoryGroupCollectionVM; // 0x1880 (Size: 0x8, Type: ObjectProperty)
    UFortLockerCategoryGroupVM* LockerVM; // 0x1888 (Size: 0x8, Type: ObjectProperty)
    FText CurrentCatName; // 0x1890 (Size: 0x10, Type: TextProperty)
    FText CurrentSubCatName; // 0x18a0 (Size: 0x10, Type: TextProperty)
    bool ShowArchetypeIcon; // 0x18b0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_18b1[0x3]; // 0x18b1 (Size: 0x3, Type: PaddingProperty)
    float BackgroundCornerRadius; // 0x18b4 (Size: 0x4, Type: FloatProperty)
    FMargin FocusOutlinePadding; // 0x18b8 (Size: 0x10, Type: StructProperty)
    FMargin BackgroundPadding; // 0x18c8 (Size: 0x10, Type: StructProperty)
    FMargin TextPaddingIconHidden; // 0x18d8 (Size: 0x10, Type: StructProperty)
    FMargin TextPaddingIconVisible; // 0x18e8 (Size: 0x10, Type: StructProperty)

public:
    void UpdateSubCategoryText(FText& TestInputText); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateSubCategoryNotification(bool& Bang); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateSubCategoryIcon(UTexture2D*& Texture); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateCategoryText(FText& TestInputText); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateCategoryNotification(bool& Bang); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateCategoryIcon(UTexture2D*& Texture); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFortLockerCategoryGroupVM(UFortLockerCategoryGroupVM*& ViewModel); // 0x288a61c (Index: 0x6, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void SetFortLockerCategoryGroupCollectionVM(UFortLockerCategoryGroupCollectionVM*& ViewModel); // 0x288a61c (Index: 0x7, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x9, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void IsShuffleArchetype(bool& IsActive); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    void IsPrimaryArchetype(bool& IsActive); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0xd, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void BP_OnEnabled(); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDisabled(); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_MPLocker_Button_SubCategory_C) == 0x18f8, "Size mismatch for UWBP_MPLocker_Button_SubCategory_C");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, UberGraphFrame) == 0x1868, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::UberGraphFrame");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, ShowText) == 0x1870, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::ShowText");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, FortLockerCategoryGroupVM) == 0x1878, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::FortLockerCategoryGroupVM");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, FortLockerCategoryGroupCollectionVM) == 0x1880, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::FortLockerCategoryGroupCollectionVM");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, LockerVM) == 0x1888, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::LockerVM");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, CurrentCatName) == 0x1890, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::CurrentCatName");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, CurrentSubCatName) == 0x18a0, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::CurrentSubCatName");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, ShowArchetypeIcon) == 0x18b0, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::ShowArchetypeIcon");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, BackgroundCornerRadius) == 0x18b4, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::BackgroundCornerRadius");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, FocusOutlinePadding) == 0x18b8, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::FocusOutlinePadding");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, BackgroundPadding) == 0x18c8, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::BackgroundPadding");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, TextPaddingIconHidden) == 0x18d8, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::TextPaddingIconHidden");
static_assert(offsetof(UWBP_MPLocker_Button_SubCategory_C, TextPaddingIconVisible) == 0x18e8, "Offset mismatch for UWBP_MPLocker_Button_SubCategory_C::TextPaddingIconVisible");

// Size: 0x18f8 (Inherited: 0x48f4, Single: 0xffffd004)
class UWBP_MPLocker_Button_Category_C : public UWBP_UIKit_ButtonGeneric_Base_C
{
public:
    uint8_t Pad_1864[0x4]; // 0x1864 (Size: 0x4, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0x1868 (Size: 0x8, Type: StructProperty)
    UWidgetAnimation* ShowText; // 0x1870 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnCollapse; // 0x1878 (Size: 0x8, Type: ObjectProperty)
    UFortLockerCategoryGroupVM* FortLockerCategoryGroupVM; // 0x1880 (Size: 0x8, Type: ObjectProperty)
    UFortLockerCategoryGroupCollectionVM* FortLockerCategoryGroupCollectionVM; // 0x1888 (Size: 0x8, Type: ObjectProperty)
    UFortLockerCategoryGroupVM* LockerVM; // 0x1890 (Size: 0x8, Type: ObjectProperty)
    FText CurrentCatName; // 0x1898 (Size: 0x10, Type: TextProperty)
    FText CurrentSubCatName; // 0x18a8 (Size: 0x10, Type: TextProperty)
    bool IsCollapsing; // 0x18b8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_18b9[0x7]; // 0x18b9 (Size: 0x7, Type: PaddingProperty)
    double OnCollapseAnimValue; // 0x18c0 (Size: 0x8, Type: DoubleProperty)
    double MaxTextWidth; // 0x18c8 (Size: 0x8, Type: DoubleProperty)
    float BackgroundCornerRadius; // 0x18d0 (Size: 0x4, Type: FloatProperty)
    FMargin BackgroundPadding; // 0x18d4 (Size: 0x10, Type: StructProperty)
    FMargin FocusOutlinePadding; // 0x18e4 (Size: 0x10, Type: StructProperty)
    int32_t StatusIndicatorLayer; // 0x18f4 (Size: 0x4, Type: IntProperty)

public:
    void SetMaxTextWidth(double& NewWidth); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetIsCollapsed(bool& IsCollapsed, bool& SkipAnimation); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFortLockerCategoryGroupVM(UFortLockerCategoryGroupVM*& ViewModel); // 0x288a61c (Index: 0x2, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void SetFortLockerCategoryGroupCollectionVM(UFortLockerCategoryGroupCollectionVM*& ViewModel); // 0x288a61c (Index: 0x3, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x5, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void IsShuffleArchetype(bool& IsActive); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void IsPrimaryArchetype(bool& IsActive); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void Destruct(); // 0x288a61c (Index: 0xa, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0xb, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void UpdateSubCategoryText(FText& TestInputText); // 0x288a61c (Index: 0xf, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateSubCategoryNotification(bool& Bang); // 0x288a61c (Index: 0x10, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateSubCategoryIcon(UTexture2D*& Texture); // 0x288a61c (Index: 0x11, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateCategoryText(FText& TestInputText); // 0x288a61c (Index: 0x12, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateCategoryNotification(bool& Bang); // 0x288a61c (Index: 0x13, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateCategoryIcon(UTexture2D*& Texture); // 0x288a61c (Index: 0x14, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetOnCollapseAnimValue(double& Value); // 0x288a61c (Index: 0x15, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    void HandleOnCollapseAnimFinished(); // 0x288a61c (Index: 0x8, Flags: Protected|BlueprintCallable|BlueprintEvent)
    virtual void BP_OnEnabled(); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDisabled(); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_MPLocker_Button_Category_C) == 0x18f8, "Size mismatch for UWBP_MPLocker_Button_Category_C");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, UberGraphFrame) == 0x1868, "Offset mismatch for UWBP_MPLocker_Button_Category_C::UberGraphFrame");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, ShowText) == 0x1870, "Offset mismatch for UWBP_MPLocker_Button_Category_C::ShowText");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, OnCollapse) == 0x1878, "Offset mismatch for UWBP_MPLocker_Button_Category_C::OnCollapse");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, FortLockerCategoryGroupVM) == 0x1880, "Offset mismatch for UWBP_MPLocker_Button_Category_C::FortLockerCategoryGroupVM");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, FortLockerCategoryGroupCollectionVM) == 0x1888, "Offset mismatch for UWBP_MPLocker_Button_Category_C::FortLockerCategoryGroupCollectionVM");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, LockerVM) == 0x1890, "Offset mismatch for UWBP_MPLocker_Button_Category_C::LockerVM");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, CurrentCatName) == 0x1898, "Offset mismatch for UWBP_MPLocker_Button_Category_C::CurrentCatName");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, CurrentSubCatName) == 0x18a8, "Offset mismatch for UWBP_MPLocker_Button_Category_C::CurrentSubCatName");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, IsCollapsing) == 0x18b8, "Offset mismatch for UWBP_MPLocker_Button_Category_C::IsCollapsing");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, OnCollapseAnimValue) == 0x18c0, "Offset mismatch for UWBP_MPLocker_Button_Category_C::OnCollapseAnimValue");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, MaxTextWidth) == 0x18c8, "Offset mismatch for UWBP_MPLocker_Button_Category_C::MaxTextWidth");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, BackgroundCornerRadius) == 0x18d0, "Offset mismatch for UWBP_MPLocker_Button_Category_C::BackgroundCornerRadius");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, BackgroundPadding) == 0x18d4, "Offset mismatch for UWBP_MPLocker_Button_Category_C::BackgroundPadding");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, FocusOutlinePadding) == 0x18e4, "Offset mismatch for UWBP_MPLocker_Button_Category_C::FocusOutlinePadding");
static_assert(offsetof(UWBP_MPLocker_Button_Category_C, StatusIndicatorLayer) == 0x18f4, "Offset mismatch for UWBP_MPLocker_Button_Category_C::StatusIndicatorLayer");

// Size: 0xd8 (Inherited: 0x168, Single: 0xffffff70)
class UDialogVM_LockerRename_CommonLoadout_C : public UUIKitDialogViewModel
{
public:
};

static_assert(sizeof(UDialogVM_LockerRename_CommonLoadout_C) == 0xd8, "Size mismatch for UDialogVM_LockerRename_CommonLoadout_C");

// Size: 0xd8 (Inherited: 0x168, Single: 0xffffff70)
class UDialogVM_LockerDelete_CommonLoadout_C : public UUIKitDialogViewModel
{
public:
};

static_assert(sizeof(UDialogVM_LockerDelete_CommonLoadout_C) == 0xd8, "Size mismatch for UDialogVM_LockerDelete_CommonLoadout_C");

// Size: 0x1890 (Inherited: 0x6174, Single: 0xffffb71c)
class UWBP_LockerCategory_Button_Context_C : public UWBP_UIKit_Button_Generic_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x1880 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_Block_Outline_C* UIKit_Block_Outline; // 0x1888 (Size: 0x8, Type: ObjectProperty)

public:
    void ToggleTouchStyle(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnInitialized(); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void BP_OnUnhovered(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnInputMethodChanged(ECommonInputType& CurrentInputType); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnHovered(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_LockerCategory_Button_Context_C) == 0x1890, "Size mismatch for UWBP_LockerCategory_Button_Context_C");
static_assert(offsetof(UWBP_LockerCategory_Button_Context_C, UberGraphFrame) == 0x1880, "Offset mismatch for UWBP_LockerCategory_Button_Context_C::UberGraphFrame");
static_assert(offsetof(UWBP_LockerCategory_Button_Context_C, UIKit_Block_Outline) == 0x1888, "Offset mismatch for UWBP_LockerCategory_Button_Context_C::UIKit_Block_Outline");

// Size: 0x628 (Inherited: 0x1b90, Single: 0xffffea98)
class UWBP_MPLocker_Modal_CommonLoadout_C : public UFortSaveLoadoutPopup
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x5a0 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_Loadoutname; // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SBox_LoadoutPreview; // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HB_Buttons; // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Dialog_Base_C* Dialog_Base; // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    UWBP_MPLocker_CommonLoadout_Preview_C* Card_Loadout; // 0x5c8 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* Button_Cancel; // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* Button_Accept; // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    UFortCommonLoadoutsVM* FortCommonLoadoutsVM; // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    UUIKitDialogViewModel* DialogVM; // 0x5e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t ClearLoadout[0x10]; // 0x5f0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Loadout_Action; // 0x600 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_601[0x7]; // 0x601 (Size: 0x7, Type: PaddingProperty)
    UFortCommonLoadoutPresetVM* TargetCommonLoadout; // 0x608 (Size: 0x8, Type: ObjectProperty)
    bool RetainFocus; // 0x610 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_611[0x7]; // 0x611 (Size: 0x7, Type: PaddingProperty)
    FText LoadoutName; // 0x618 (Size: 0x10, Type: TextProperty)

public:
    virtual void Construct(); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void ClearLoadout__DelegateSignature(); // 0x288a61c (Index: 0x2, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void CheckNumberOfLoadouts(TArray<UFortCommonLoadoutPresetVM*> Loadouts); // 0x288a61c (Index: 0x3, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0xf, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void OnSanitizationReady(bool& bSuccess, FString& Sanitizedtext); // 0x288a61c (Index: 0x10, Flags: Event|Public|BlueprintEvent)
    virtual void OnRemovedFromFocusPath(FFocusEvent& InFocusEvent); // 0x288a61c (Index: 0x11, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void OnInitialized(); // 0x288a61c (Index: 0x12, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void Initialize(EFortLoadoutActionType& NewLoadoutAction, UFortCommonLoadoutPresetVM*& InTargetLoadout); // 0x288a61c (Index: 0x13, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void BP_OnDeactivated(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnActivated(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual UWidget* BP_GetDesiredFocusTarget() const; // 0x288a61c (Index: 0x6, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
    void SetupForSave(UFortCommonLoadoutPresetVM*& Target_Loadout, bool& SaveNew); // 0x288a61c (Index: 0xa, Flags: Protected|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetupForDelete(); // 0x288a61c (Index: 0xb, Flags: Protected|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetupForClear(); // 0x288a61c (Index: 0xc, Flags: Protected|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetNavigationRules(); // 0x288a61c (Index: 0xd, Flags: Protected|BlueprintCallable|BlueprintEvent)
    void SetMobileStyle(); // 0x288a61c (Index: 0xe, Flags: Protected|HasDefaults|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_MPLocker_Modal_CommonLoadout_C) == 0x628, "Size mismatch for UWBP_MPLocker_Modal_CommonLoadout_C");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, UberGraphFrame) == 0x5a0, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::UberGraphFrame");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, Text_Loadoutname) == 0x5a8, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::Text_Loadoutname");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, SBox_LoadoutPreview) == 0x5b0, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::SBox_LoadoutPreview");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, HB_Buttons) == 0x5b8, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::HB_Buttons");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, Dialog_Base) == 0x5c0, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::Dialog_Base");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, Card_Loadout) == 0x5c8, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::Card_Loadout");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, Button_Cancel) == 0x5d0, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::Button_Cancel");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, Button_Accept) == 0x5d8, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::Button_Accept");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, FortCommonLoadoutsVM) == 0x5e0, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::FortCommonLoadoutsVM");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, DialogVM) == 0x5e8, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::DialogVM");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, ClearLoadout) == 0x5f0, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::ClearLoadout");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, Loadout_Action) == 0x600, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::Loadout_Action");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, TargetCommonLoadout) == 0x608, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::TargetCommonLoadout");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, RetainFocus) == 0x610, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::RetainFocus");
static_assert(offsetof(UWBP_MPLocker_Modal_CommonLoadout_C, LoadoutName) == 0x618, "Offset mismatch for UWBP_MPLocker_Modal_CommonLoadout_C::LoadoutName");

// Size: 0x310 (Inherited: 0x458, Single: 0xfffffeb8)
class UWBP_MPLocker_CommonLoadout_Preview_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2b0 (Size: 0x8, Type: StructProperty)
    UWBP_Itemcard_Myloadout_Tile_C* Item_Wrap; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UWBP_Itemcard_Myloadout_Tile_C* Item_Truck; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UWBP_Itemcard_Myloadout_Tile_C* Item_SportsCar; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UWBP_Itemcard_Myloadout_Tile_C* Item_MusicMoment; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UWBP_Itemcard_Myloadout_Tile_C* Item_Jam; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UWBP_Itemcard_Myloadout_Tile_C* Item_Instrument; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UWBP_Itemcard_Myloadout_Tile_C* Item_Emote; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UWBP_Itemcard_Myloadout_Tile_C* Item_Character; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UWBP_Itemcard_Myloadout_Tile_C* Item_Banner; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* GridPanel_Cards_Preview; // 0x300 (Size: 0x8, Type: ObjectProperty)
    UImage* GridLines; // 0x308 (Size: 0x8, Type: ObjectProperty)

public:
    void TriggerHover(bool& IsHovered); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void PopulateSubitems(const TArray<UFortCommonLoadoutCategoryGroupPresetVM*> Data); // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_MPLocker_CommonLoadout_Preview_C) == 0x310, "Size mismatch for UWBP_MPLocker_CommonLoadout_Preview_C");
static_assert(offsetof(UWBP_MPLocker_CommonLoadout_Preview_C, UberGraphFrame) == 0x2b0, "Offset mismatch for UWBP_MPLocker_CommonLoadout_Preview_C::UberGraphFrame");
static_assert(offsetof(UWBP_MPLocker_CommonLoadout_Preview_C, Item_Wrap) == 0x2b8, "Offset mismatch for UWBP_MPLocker_CommonLoadout_Preview_C::Item_Wrap");
static_assert(offsetof(UWBP_MPLocker_CommonLoadout_Preview_C, Item_Truck) == 0x2c0, "Offset mismatch for UWBP_MPLocker_CommonLoadout_Preview_C::Item_Truck");
static_assert(offsetof(UWBP_MPLocker_CommonLoadout_Preview_C, Item_SportsCar) == 0x2c8, "Offset mismatch for UWBP_MPLocker_CommonLoadout_Preview_C::Item_SportsCar");
static_assert(offsetof(UWBP_MPLocker_CommonLoadout_Preview_C, Item_MusicMoment) == 0x2d0, "Offset mismatch for UWBP_MPLocker_CommonLoadout_Preview_C::Item_MusicMoment");
static_assert(offsetof(UWBP_MPLocker_CommonLoadout_Preview_C, Item_Jam) == 0x2d8, "Offset mismatch for UWBP_MPLocker_CommonLoadout_Preview_C::Item_Jam");
static_assert(offsetof(UWBP_MPLocker_CommonLoadout_Preview_C, Item_Instrument) == 0x2e0, "Offset mismatch for UWBP_MPLocker_CommonLoadout_Preview_C::Item_Instrument");
static_assert(offsetof(UWBP_MPLocker_CommonLoadout_Preview_C, Item_Emote) == 0x2e8, "Offset mismatch for UWBP_MPLocker_CommonLoadout_Preview_C::Item_Emote");
static_assert(offsetof(UWBP_MPLocker_CommonLoadout_Preview_C, Item_Character) == 0x2f0, "Offset mismatch for UWBP_MPLocker_CommonLoadout_Preview_C::Item_Character");
static_assert(offsetof(UWBP_MPLocker_CommonLoadout_Preview_C, Item_Banner) == 0x2f8, "Offset mismatch for UWBP_MPLocker_CommonLoadout_Preview_C::Item_Banner");
static_assert(offsetof(UWBP_MPLocker_CommonLoadout_Preview_C, GridPanel_Cards_Preview) == 0x300, "Offset mismatch for UWBP_MPLocker_CommonLoadout_Preview_C::GridPanel_Cards_Preview");
static_assert(offsetof(UWBP_MPLocker_CommonLoadout_Preview_C, GridLines) == 0x308, "Offset mismatch for UWBP_MPLocker_CommonLoadout_Preview_C::GridLines");

// Size: 0x18f0 (Inherited: 0x5f1a, Single: 0xffffb9d6)
class UWBP_Itemcard_Myloadout_Tile_C : public UWBP_UIKit_ItemCard_Base_C
{
public:
    uint8_t Pad_18da[0x6]; // 0x18da (Size: 0x6, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0x18e0 (Size: 0x8, Type: StructProperty)
    UFortItemVM* FortItemVM; // 0x18e8 (Size: 0x8, Type: ObjectProperty)

public:
    void SetFortItemVM(UFortItemVM*& ViewModel); // 0x288a61c (Index: 0x0, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnFortItemVMChanged(UFortItemVM*& InFortVM); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_Itemcard_Myloadout_Tile_C) == 0x18f0, "Size mismatch for UWBP_Itemcard_Myloadout_Tile_C");
static_assert(offsetof(UWBP_Itemcard_Myloadout_Tile_C, UberGraphFrame) == 0x18e0, "Offset mismatch for UWBP_Itemcard_Myloadout_Tile_C::UberGraphFrame");
static_assert(offsetof(UWBP_Itemcard_Myloadout_Tile_C, FortItemVM) == 0x18e8, "Offset mismatch for UWBP_Itemcard_Myloadout_Tile_C::FortItemVM");

// Size: 0x2d8 (Inherited: 0x458, Single: 0xfffffe80)
class UWBP_MPLocker_ServiceNotice_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2b0 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_InfoBox_C* WBP_UIKit_InfoBox; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UFortLockerVM* FortLockerVM; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<E_UI_BackplateBrightness> Brightness; // 0x2c8 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<E_UI_BackplateCornerRadius> Corner_Radius; // 0x2c9 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_2ca[0x6]; // 0x2ca (Size: 0x6, Type: PaddingProperty)
    UMaterialInstance* Material_Instance; // 0x2d0 (Size: 0x8, Type: ObjectProperty)

public:
    void UpdateServicesNoticeVisibility(bool& IsServiceResponsive); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UWBP_MPLocker_ServiceNotice_C) == 0x2d8, "Size mismatch for UWBP_MPLocker_ServiceNotice_C");
static_assert(offsetof(UWBP_MPLocker_ServiceNotice_C, UberGraphFrame) == 0x2b0, "Offset mismatch for UWBP_MPLocker_ServiceNotice_C::UberGraphFrame");
static_assert(offsetof(UWBP_MPLocker_ServiceNotice_C, WBP_UIKit_InfoBox) == 0x2b8, "Offset mismatch for UWBP_MPLocker_ServiceNotice_C::WBP_UIKit_InfoBox");
static_assert(offsetof(UWBP_MPLocker_ServiceNotice_C, FortLockerVM) == 0x2c0, "Offset mismatch for UWBP_MPLocker_ServiceNotice_C::FortLockerVM");
static_assert(offsetof(UWBP_MPLocker_ServiceNotice_C, Brightness) == 0x2c8, "Offset mismatch for UWBP_MPLocker_ServiceNotice_C::Brightness");
static_assert(offsetof(UWBP_MPLocker_ServiceNotice_C, Corner_Radius) == 0x2c9, "Offset mismatch for UWBP_MPLocker_ServiceNotice_C::Corner_Radius");
static_assert(offsetof(UWBP_MPLocker_ServiceNotice_C, Material_Instance) == 0x2d0, "Offset mismatch for UWBP_MPLocker_ServiceNotice_C::Material_Instance");

// Size: 0x388 (Inherited: 0x458, Single: 0xffffff30)
class UWBP_MyLoadout_CategorySet_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2b0 (Size: 0x8, Type: StructProperty)
    USpacer* Spacer_1; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UFortDynamicEntryBox* CategoryTopRow; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UFortDynamicEntryBox* CategoryBottom; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UFortLockerCategoryGroupVM* FortLockerCategoryGroupVM; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnCategoryClicked[0x10]; // 0x2d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<UFortLockerCategoryItemVM*> VisibleItems; // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    uint8_t OnCategoryItemSetup[0x10]; // 0x2f8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UCommonButtonGroupBase* ButtonGroup; // 0x308 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnCategoryContextMenuOpened[0x10]; // 0x310 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCategoryContextMenuClosed[0x10]; // 0x320 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCategoryEditStyles[0x10]; // 0x330 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCardHovered[0x10]; // 0x340 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnNavToNextCategory[0x10]; // 0x350 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t ItemsPopulated[0x10]; // 0x360 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UWidget* CurrentDesiredFocusTarget; // 0x370 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnCardSelected[0x10]; // 0x378 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void OnCategoryEditStyles__DelegateSignature(); // 0x288a61c (Index: 0x0, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void SetupCategoryItem(UFortLockerCategoryItemVM*& Category, bool& IsSecondRow); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void OnCategoryContextMenuOpened__DelegateSignature(UWidget*& ContextMenuParent); // 0x288a61c (Index: 0x2, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnCategoryContextMenuClosed__DelegateSignature(); // 0x288a61c (Index: 0x3, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnCategoryClicked__DelegateSignature(); // 0x288a61c (Index: 0x4, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnCardSelected__DelegateSignature(UWBP_UIKit_ItemCard_Category_C*& ItemCardCategory); // 0x288a61c (Index: 0x5, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnCardHovered__DelegateSignature(bool& IsHovered); // 0x288a61c (Index: 0x6, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    UWidget* NavTopRow(EUINavigation& Navigation); // 0x288a61c (Index: 0x7, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    UWidget* NavBottomRow(EUINavigation& Navigation); // 0x288a61c (Index: 0x8, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void ItemsPopulated__DelegateSignature(); // 0x288a61c (Index: 0x9, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void HandleContextMenuClosed(); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleCategoryEditStyles(); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleCategoryClicked(); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleCategoryCardSelected(UWBP_UIKit_ItemCard_Category_C*& ItemCardCategory); // 0x288a61c (Index: 0xd, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleCategoryCardHovered(bool& IsCategoryCardHovered); // 0x288a61c (Index: 0xe, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Handle_Context_Menu_Opened(UWidget*& ContextMenuParent); // 0x288a61c (Index: 0xf, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetNavigationFocus(int32_t& DesiredColumn, bool& IsDirectionUp, UUserWidget*& Output); // 0x288a61c (Index: 0x10, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void GetDesiredNavInfo(UDynamicEntryBoxBase*& CurrentRow, int32_t& DesiredColumn); // 0x288a61c (Index: 0x12, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    UWidget* GetDesiredFocusTarget(); // 0x288a61c (Index: 0x13, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    UWidget* Get_Widget_to_Nav(UDynamicEntryBoxBase*& CurrentRow, UDynamicEntryBoxBase*& TargetRow, bool& TargetEmpty); // 0x288a61c (Index: 0x14, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void TryUpdateFocusTarget(int32_t& DesiredColumn, bool& IsDirectionUp, bool& ShouldApplyFocus); // 0x288a61c (Index: 0x19, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetupCategoryRows(TArray<UFortLockerCategoryItemVM*> CategoryItem); // 0x288a61c (Index: 0x1a, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetRowDistance(bool& EnableSpacer); // 0x288a61c (Index: 0x1b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFortLockerCategoryGroupVM(UFortLockerCategoryGroupVM*& ViewModel); // 0x288a61c (Index: 0x1c, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void SetCategorySelected(bool& IsSelected); // 0x288a61c (Index: 0x1d, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ResetItems(); // 0x288a61c (Index: 0x1e, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void ResetFocus(); // 0x288a61c (Index: 0x1f, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x20, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnNavToNextCategory__DelegateSignature(int32_t& DesiredColumn, bool& IsDirectionUp); // 0x288a61c (Index: 0x21, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnCategoryItemSetup__DelegateSignature(UUserWidget*& CategoryItemEntryObject); // 0x288a61c (Index: 0x23, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)

private:
    void GetItemRowData(int32_t& CurrentItemIndex, int32_t& ArrayLastIndex, int32_t& ItemsPerRow, bool& SplitItems, bool& IsSecondRow, bool& EnableSpacer); // 0x288a61c (Index: 0x11, Flags: Private|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)

protected:
    virtual void BP_OnItemSelectionChanged(bool& bIsSelected); // 0x288a61c (Index: 0x16, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnItemExpansionChanged(bool& bIsExpanded); // 0x288a61c (Index: 0x17, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnEntryReleased(); // 0x288a61c (Index: 0x18, Flags: Event|Protected|BlueprintEvent)
    virtual void OnListItemObjectSet(UObject*& ListItemObject); // 0x288a61c (Index: 0x22, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_MyLoadout_CategorySet_C) == 0x388, "Size mismatch for UWBP_MyLoadout_CategorySet_C");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, UberGraphFrame) == 0x2b0, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::UberGraphFrame");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, Spacer_1) == 0x2b8, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::Spacer_1");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, CategoryTopRow) == 0x2c0, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::CategoryTopRow");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, CategoryBottom) == 0x2c8, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::CategoryBottom");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, FortLockerCategoryGroupVM) == 0x2d0, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::FortLockerCategoryGroupVM");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, OnCategoryClicked) == 0x2d8, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::OnCategoryClicked");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, VisibleItems) == 0x2e8, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::VisibleItems");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, OnCategoryItemSetup) == 0x2f8, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::OnCategoryItemSetup");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, ButtonGroup) == 0x308, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::ButtonGroup");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, OnCategoryContextMenuOpened) == 0x310, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::OnCategoryContextMenuOpened");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, OnCategoryContextMenuClosed) == 0x320, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::OnCategoryContextMenuClosed");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, OnCategoryEditStyles) == 0x330, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::OnCategoryEditStyles");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, OnCardHovered) == 0x340, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::OnCardHovered");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, OnNavToNextCategory) == 0x350, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::OnNavToNextCategory");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, ItemsPopulated) == 0x360, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::ItemsPopulated");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, CurrentDesiredFocusTarget) == 0x370, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::CurrentDesiredFocusTarget");
static_assert(offsetof(UWBP_MyLoadout_CategorySet_C, OnCardSelected) == 0x378, "Offset mismatch for UWBP_MyLoadout_CategorySet_C::OnCardSelected");

