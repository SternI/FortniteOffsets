/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityCategoryTilePanelBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DiscoveryBrowserUI.h"
#include "Engine.h"
#include "UMG.h"

// Size: 0x378 (Inherited: 0xa78, Single: 0xfffff900)
class UActivityCategoryTilePanelBase_C : public UFortActivityCategoryTilePanel
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x348 (Size: 0x8, Type: StructProperty)
    UVerticalBox* VerticalBox_Content; // 0x350 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ActiveInactivate; // 0x358 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnMoveUpOutOfView; // 0x360 (Size: 0x8, Type: ObjectProperty)
    double EntryHeight; // 0x368 (Size: 0x8, Type: DoubleProperty)
    double EntryWidth; // 0x370 (Size: 0x8, Type: DoubleProperty)

public:
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void OnInitialized(); // 0x288a61c (Index: 0x2, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x7, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UActivityCategoryTilePanelBase_C) == 0x378, "Size mismatch for UActivityCategoryTilePanelBase_C");
static_assert(offsetof(UActivityCategoryTilePanelBase_C, UberGraphFrame) == 0x348, "Offset mismatch for UActivityCategoryTilePanelBase_C::UberGraphFrame");
static_assert(offsetof(UActivityCategoryTilePanelBase_C, VerticalBox_Content) == 0x350, "Offset mismatch for UActivityCategoryTilePanelBase_C::VerticalBox_Content");
static_assert(offsetof(UActivityCategoryTilePanelBase_C, ActiveInactivate) == 0x358, "Offset mismatch for UActivityCategoryTilePanelBase_C::ActiveInactivate");
static_assert(offsetof(UActivityCategoryTilePanelBase_C, OnMoveUpOutOfView) == 0x360, "Offset mismatch for UActivityCategoryTilePanelBase_C::OnMoveUpOutOfView");
static_assert(offsetof(UActivityCategoryTilePanelBase_C, EntryHeight) == 0x368, "Offset mismatch for UActivityCategoryTilePanelBase_C::EntryHeight");
static_assert(offsetof(UActivityCategoryTilePanelBase_C, EntryWidth) == 0x370, "Offset mismatch for UActivityCategoryTilePanelBase_C::EntryWidth");

