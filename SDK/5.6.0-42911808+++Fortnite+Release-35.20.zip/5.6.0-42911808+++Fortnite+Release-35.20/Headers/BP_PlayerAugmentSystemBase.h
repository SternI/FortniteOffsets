/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_PlayerAugmentSystemBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "PlayerAugmentsCodeRuntime.h"

// Size: 0x1d8 (Inherited: 0x4e0, Single: 0xfffffcf8)
class UBP_PlayerAugmentSystemBase_C : public UFortPlayerStateComponent_PlayerAugmentSystem
{
public:
};

static_assert(sizeof(UBP_PlayerAugmentSystemBase_C) == 0x1d8, "Size mismatch for UBP_PlayerAugmentSystemBase_C");

