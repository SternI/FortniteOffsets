/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserDiscoverRow_HorizontalScrolling
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DiscoveryBrowserUI.h"
#include "FortniteUI.h"
#include "Rows.h"
#include "UMG.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "TabScreens.h"

// Size: 0x481 (Inherited: 0xef8, Single: 0xfffff589)
class UActivityBrowserDiscoverRow_HorizontalScrolling_C : public UFortDiscoverBrowserGridRow
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x3f0 (Size: 0x8, Type: StructProperty)
    UWBP_Row_HorizontalScrollingList_C* WBP_Row_HorizontalScrollingList; // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    UWBP_LoadingMorePages_C* WBP_LoadingMorePages; // 0x400 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* GridRoot; // 0x408 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnLoadingMore; // 0x410 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowMoveUpOutOfViewAnim; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowMoveDownIntoView; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UFortDiscoverProviderViewModel* FortDiscoverProviderViewModel; // 0x428 (Size: 0x8, Type: ObjectProperty)
    FName FontHoverAnimateParam; // 0x430 (Size: 0x4, Type: NameProperty)
    FName FontPressedAnimateParam; // 0x434 (Size: 0x4, Type: NameProperty)
    bool IsWaitingForInactiveAnim; // 0x438 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_439[0x7]; // 0x439 (Size: 0x7, Type: PaddingProperty)
    double LoadingMoreDisplayDelay; // 0x440 (Size: 0x8, Type: DoubleProperty)
    bool IsLoadingMoreVisible; // 0x448 (Size: 0x1, Type: BoolProperty)
    bool IsLoadingMoreQueryActive; // 0x449 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_44a[0x6]; // 0x44a (Size: 0x6, Type: PaddingProperty)
    FTimerHandle LoadingMoreDelayTimer; // 0x450 (Size: 0x8, Type: StructProperty)
    uint8_t OnRowBroadcastClickToDiscover[0x10]; // 0x458 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    double EntriesSpacing; // 0x468 (Size: 0x8, Type: DoubleProperty)
    uint8_t OnUpperBoundaryHit[0x10]; // 0x470 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bAllowNonFullRows; // 0x480 (Size: 0x1, Type: BoolProperty)

public:
    void UpdateVisibility(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateItemSelectorInHoziontalScrollingList(); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void UpdateAnalyticsStates(bool& bStopImpressions); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    void SetFortDiscoverProviderViewModel(UFortDiscoverProviderViewModel*& ViewModel); // 0x288a61c (Index: 0x4, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    virtual void SetFocusOffset(int32_t& FocusOffset, bool& bSelectFromBelow); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
    void SelectItem(int32_t& ItemIndex); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OpenNestedSurface(UFortDiscoverSurfaceTileItemVM*& const SurfaceTileItemVM); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintEvent)
    void OnUpperBoundaryHit__DelegateSignature(); // 0x288a61c (Index: 0x8, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnRowBroadcastClickToDiscover__DelegateSignature(); // 0x288a61c (Index: 0x11, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void Destruct(); // 0x288a61c (Index: 0x1b, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x1c, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void SetPanelViewModel(UFortDiscoverProviderViewModel*& ViewModel); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowPeekStateChanged(bool& const bIsInPeekState); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowMoveUp(bool& const bMovingOffscreen); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowMoveDown(bool& const bMovingOffscreen); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowIsSelectedChanged(bool& const bIsSelected); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowIsActiveChanged(bool& const bIsActive); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void OnOverrideItemSelectorSet(UFortDiscoverItemSelectorBase*& const ItemSelector); // 0x288a61c (Index: 0x14, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCategoryItemChanged(bool& const bPlayAnimation, const FName CategoryPanelName); // 0x288a61c (Index: 0x15, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual UFortDiscoverProviderViewModel* GetPanelViewModel(); // 0x288a61c (Index: 0x17, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void BP_OnEntryReleased(); // 0x288a61c (Index: 0x1d, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UActivityBrowserDiscoverRow_HorizontalScrolling_C) == 0x481, "Size mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, UberGraphFrame) == 0x3f0, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::UberGraphFrame");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, WBP_Row_HorizontalScrollingList) == 0x3f8, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::WBP_Row_HorizontalScrollingList");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, WBP_LoadingMorePages) == 0x400, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::WBP_LoadingMorePages");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, GridRoot) == 0x408, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::GridRoot");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, OnLoadingMore) == 0x410, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::OnLoadingMore");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, OnRowMoveUpOutOfViewAnim) == 0x418, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::OnRowMoveUpOutOfViewAnim");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, OnRowMoveDownIntoView) == 0x420, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::OnRowMoveDownIntoView");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, FortDiscoverProviderViewModel) == 0x428, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::FortDiscoverProviderViewModel");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, FontHoverAnimateParam) == 0x430, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::FontHoverAnimateParam");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, FontPressedAnimateParam) == 0x434, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::FontPressedAnimateParam");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, IsWaitingForInactiveAnim) == 0x438, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::IsWaitingForInactiveAnim");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, LoadingMoreDisplayDelay) == 0x440, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::LoadingMoreDisplayDelay");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, IsLoadingMoreVisible) == 0x448, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::IsLoadingMoreVisible");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, IsLoadingMoreQueryActive) == 0x449, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::IsLoadingMoreQueryActive");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, LoadingMoreDelayTimer) == 0x450, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::LoadingMoreDelayTimer");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, OnRowBroadcastClickToDiscover) == 0x458, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::OnRowBroadcastClickToDiscover");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, EntriesSpacing) == 0x468, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::EntriesSpacing");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, OnUpperBoundaryHit) == 0x470, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::OnUpperBoundaryHit");
static_assert(offsetof(UActivityBrowserDiscoverRow_HorizontalScrolling_C, bAllowNonFullRows) == 0x480, "Offset mismatch for UActivityBrowserDiscoverRow_HorizontalScrolling_C::bAllowNonFullRows");

