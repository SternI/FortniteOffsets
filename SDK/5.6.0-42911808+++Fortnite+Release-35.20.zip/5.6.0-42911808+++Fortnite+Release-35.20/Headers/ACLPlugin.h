/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ACLPlugin
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x128 (Inherited: 0x28, Single: 0x100)
class UAnimationCompressionLibraryDatabase : public UObject
{
public:
    TArray<char> CookedCompressedBytes; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<uint64_t> CookedAnimSequenceMappings; // 0x38 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_48[0xd8]; // 0x48 (Size: 0xd8, Type: PaddingProperty)
    uint32_t MaxStreamRequestSizeKB; // 0x120 (Size: 0x4, Type: UInt32Property)
    uint8_t DefaultVisualFidelity; // 0x124 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_125[0x3]; // 0x125 (Size: 0x3, Type: PaddingProperty)

public:
    static ACLVisualFidelity GetVisualFidelity(UAnimationCompressionLibraryDatabase*& DatabaseAsset); // 0x103b17c0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SetVisualFidelity(UObject*& WorldContextObject, FLatentActionInfo& LatentInfo, UAnimationCompressionLibraryDatabase*& DatabaseAsset, ACLVisualFidelityChangeResult& Result, ACLVisualFidelity& VisualFidelity); // 0x103b18e4 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAnimationCompressionLibraryDatabase) == 0x128, "Size mismatch for UAnimationCompressionLibraryDatabase");
static_assert(offsetof(UAnimationCompressionLibraryDatabase, CookedCompressedBytes) == 0x28, "Offset mismatch for UAnimationCompressionLibraryDatabase::CookedCompressedBytes");
static_assert(offsetof(UAnimationCompressionLibraryDatabase, CookedAnimSequenceMappings) == 0x38, "Offset mismatch for UAnimationCompressionLibraryDatabase::CookedAnimSequenceMappings");
static_assert(offsetof(UAnimationCompressionLibraryDatabase, MaxStreamRequestSizeKB) == 0x120, "Offset mismatch for UAnimationCompressionLibraryDatabase::MaxStreamRequestSizeKB");
static_assert(offsetof(UAnimationCompressionLibraryDatabase, DefaultVisualFidelity) == 0x124, "Offset mismatch for UAnimationCompressionLibraryDatabase::DefaultVisualFidelity");

// Size: 0x38 (Inherited: 0x98, Single: 0xffffffa0)
class UAnimBoneCompressionCodec_ACL : public UAnimBoneCompressionCodec_ACLBase
{
public:
};

static_assert(sizeof(UAnimBoneCompressionCodec_ACL) == 0x38, "Size mismatch for UAnimBoneCompressionCodec_ACL");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class UAnimBoneCompressionCodec_ACLBase : public UAnimBoneCompressionCodec
{
public:
};

static_assert(sizeof(UAnimBoneCompressionCodec_ACLBase) == 0x38, "Size mismatch for UAnimBoneCompressionCodec_ACLBase");

// Size: 0x38 (Inherited: 0x98, Single: 0xffffffa0)
class UAnimBoneCompressionCodec_ACLCustom : public UAnimBoneCompressionCodec_ACLBase
{
public:
};

static_assert(sizeof(UAnimBoneCompressionCodec_ACLCustom) == 0x38, "Size mismatch for UAnimBoneCompressionCodec_ACLCustom");

// Size: 0x40 (Inherited: 0x98, Single: 0xffffffa8)
class UAnimBoneCompressionCodec_ACLDatabase : public UAnimBoneCompressionCodec_ACLBase
{
public:
    UAnimationCompressionLibraryDatabase* DatabaseAsset; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UAnimBoneCompressionCodec_ACLDatabase) == 0x40, "Size mismatch for UAnimBoneCompressionCodec_ACLDatabase");
static_assert(offsetof(UAnimBoneCompressionCodec_ACLDatabase, DatabaseAsset) == 0x38, "Offset mismatch for UAnimBoneCompressionCodec_ACLDatabase::DatabaseAsset");

// Size: 0x38 (Inherited: 0x98, Single: 0xffffffa0)
class UAnimBoneCompressionCodec_ACLSafe : public UAnimBoneCompressionCodec_ACLBase
{
public:
};

static_assert(sizeof(UAnimBoneCompressionCodec_ACLSafe) == 0x38, "Size mismatch for UAnimBoneCompressionCodec_ACLSafe");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAnimCurveCompressionCodec_ACL : public UAnimCurveCompressionCodec
{
public:
};

static_assert(sizeof(UAnimCurveCompressionCodec_ACL) == 0x28, "Size mismatch for UAnimCurveCompressionCodec_ACL");

