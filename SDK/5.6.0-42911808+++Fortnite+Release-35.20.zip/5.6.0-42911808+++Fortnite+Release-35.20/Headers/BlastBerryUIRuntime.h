/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BlastBerryUIRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "CommonUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "Engine.h"

// Size: 0x88 (Inherited: 0xf8, Single: 0xffffff90)
class UFortMobileActionButtonBehaviorExtension_Reboot : public UFortMobileActionButtonBehaviorExtension
{
public:

private:
    void DisableVisibility(); // 0x112a75f0 (Index: 0x0, Flags: Final|Native|Private)
    void EnableVisibility(); // 0x112a7604 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortMobileActionButtonBehaviorExtension_Reboot) == 0x88, "Size mismatch for UFortMobileActionButtonBehaviorExtension_Reboot");

// Size: 0x5c0 (Inherited: 0x1980, Single: 0xffffec40)
class UBlastBerryDeathLocationIndicator : public UAthenaEliminationIndicator
{
public:
};

static_assert(sizeof(UBlastBerryDeathLocationIndicator) == 0x5c0, "Size mismatch for UBlastBerryDeathLocationIndicator");

// Size: 0x370 (Inherited: 0xa48, Single: 0xfffff928)
class UBlastBerryInstantRebootWidget : public UFortHUDElementWidget
{
public:
    float HoldDuration; // 0x318 (Size: 0x4, Type: FloatProperty)
    float InvulnerabilityRespawnDisplayDelay; // 0x31c (Size: 0x4, Type: FloatProperty)
    FGameplayTag InvulnerabilityGameplayTag; // 0x320 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_324[0x4]; // 0x324 (Size: 0x4, Type: PaddingProperty)
    UFortKeybindWidget* KeybindWidget; // 0x328 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_330[0x20]; // 0x330 (Size: 0x20, Type: PaddingProperty)
    UInputComponent* BlastBerryInstantRebootInputComponent; // 0x350 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_358[0x4]; // 0x358 (Size: 0x4, Type: PaddingProperty)
    TWeakObjectPtr<UAbilitySystemComponent*> OwnerASC; // 0x35c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_364[0xc]; // 0x364 (Size: 0xc, Type: PaddingProperty)

private:
    void HandleRespawnEventsStopped(); // 0x112a7640 (Index: 0x0, Flags: Final|Native|Private)

protected:
    virtual void OnRespawnEventsStopped(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnWidgetActiveChanged(bool& bIsActive); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintCallable|BlueprintEvent)
    void UpdateKeybindings(); // 0x112a7854 (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(UBlastBerryInstantRebootWidget) == 0x370, "Size mismatch for UBlastBerryInstantRebootWidget");
static_assert(offsetof(UBlastBerryInstantRebootWidget, HoldDuration) == 0x318, "Offset mismatch for UBlastBerryInstantRebootWidget::HoldDuration");
static_assert(offsetof(UBlastBerryInstantRebootWidget, InvulnerabilityRespawnDisplayDelay) == 0x31c, "Offset mismatch for UBlastBerryInstantRebootWidget::InvulnerabilityRespawnDisplayDelay");
static_assert(offsetof(UBlastBerryInstantRebootWidget, InvulnerabilityGameplayTag) == 0x320, "Offset mismatch for UBlastBerryInstantRebootWidget::InvulnerabilityGameplayTag");
static_assert(offsetof(UBlastBerryInstantRebootWidget, KeybindWidget) == 0x328, "Offset mismatch for UBlastBerryInstantRebootWidget::KeybindWidget");
static_assert(offsetof(UBlastBerryInstantRebootWidget, BlastBerryInstantRebootInputComponent) == 0x350, "Offset mismatch for UBlastBerryInstantRebootWidget::BlastBerryInstantRebootInputComponent");
static_assert(offsetof(UBlastBerryInstantRebootWidget, OwnerASC) == 0x35c, "Offset mismatch for UBlastBerryInstantRebootWidget::OwnerASC");

// Size: 0x340 (Inherited: 0xa48, Single: 0xfffff8f8)
class UBlastBerryPlayerInfoRespawn : public UFortHUDElementWidget
{
public:
    uint8_t Pad_318[0x8]; // 0x318 (Size: 0x8, Type: PaddingProperty)
    TWeakObjectPtr<AFortPlayerStateAthena*> WeakPlayerStateAthena_RepresentedPlayer; // 0x320 (Size: 0x8, Type: WeakObjectProperty)
    UCommonTextBlock* Text_Time; // 0x328 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_330[0x10]; // 0x330 (Size: 0x10, Type: PaddingProperty)

private:
    void HandleRespawnTimeReplicated(AFortPlayerStateAthena*& PlayerState, float& TimeRemaining); // 0x112a7654 (Index: 0x1, Flags: Final|Native|Private)

protected:
    float GetTimeOfDeath() const; // 0x112a7618 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnTickDown(float& TimeRemaining); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTimeEnded(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTimerCancelled(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UBlastBerryPlayerInfoRespawn) == 0x340, "Size mismatch for UBlastBerryPlayerInfoRespawn");
static_assert(offsetof(UBlastBerryPlayerInfoRespawn, WeakPlayerStateAthena_RepresentedPlayer) == 0x320, "Offset mismatch for UBlastBerryPlayerInfoRespawn::WeakPlayerStateAthena_RepresentedPlayer");
static_assert(offsetof(UBlastBerryPlayerInfoRespawn, Text_Time) == 0x328, "Offset mismatch for UBlastBerryPlayerInfoRespawn::Text_Time");

