/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EcosystemReadyUpErrorsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "CoreUObject.h"

// Size: 0x120 (Inherited: 0x138, Single: 0xffffffe8)
class UBaseDownloadErrorUI : public UReadyUpErrorUI
{
public:

public:
    void BindToDownloadUpdated(const FDelegate OnDownloadInfo) const; // 0x110b9f08 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|Const)
};

static_assert(sizeof(UBaseDownloadErrorUI) == 0x120, "Size mismatch for UBaseDownloadErrorUI");

// Size: 0x120 (Inherited: 0x138, Single: 0xffffffe8)
class UBaseMatchmakingGroupErrorUI : public UReadyUpErrorUI
{
public:
};

static_assert(sizeof(UBaseMatchmakingGroupErrorUI) == 0x120, "Size mismatch for UBaseMatchmakingGroupErrorUI");

// Size: 0x120 (Inherited: 0x138, Single: 0xffffffe8)
class UBaseRegionErrorUI : public UReadyUpErrorUI
{
public:
};

static_assert(sizeof(UBaseRegionErrorUI) == 0x120, "Size mismatch for UBaseRegionErrorUI");

// Size: 0x110 (Inherited: 0x138, Single: 0xffffffd8)
class UBaseTournamentLockErrorUI : public UReadyUpErrorUI
{
public:
};

static_assert(sizeof(UBaseTournamentLockErrorUI) == 0x110, "Size mismatch for UBaseTournamentLockErrorUI");

// Size: 0x120 (Inherited: 0x258, Single: 0xfffffec8)
class UCannotUseWhileLookingForPartyUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

static_assert(sizeof(UCannotUseWhileLookingForPartyUI) == 0x120, "Size mismatch for UCannotUseWhileLookingForPartyUI");

// Size: 0x120 (Inherited: 0x258, Single: 0xfffffec8)
class UCannotUseWhileUsingPartySignalUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

static_assert(sizeof(UCannotUseWhileUsingPartySignalUI) == 0x120, "Size mismatch for UCannotUseWhileUsingPartySignalUI");

// Size: 0x120 (Inherited: 0x258, Single: 0xfffffec8)
class UContentGatedUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

static_assert(sizeof(UContentGatedUI) == 0x120, "Size mismatch for UContentGatedUI");

// Size: 0x110 (Inherited: 0x138, Single: 0xffffffd8)
class UCrossplayReadyUpErrorUI : public UReadyUpErrorUI
{
public:
};

static_assert(sizeof(UCrossplayReadyUpErrorUI) == 0x110, "Size mismatch for UCrossplayReadyUpErrorUI");

// Size: 0x140 (Inherited: 0x138, Single: 0x8)
class UEULAErrorUI : public UReadyUpErrorUI
{
public:
    FText TitleOverride; // 0x110 (Size: 0x10, Type: TextProperty)
    TSoftClassPtr EulaModal; // 0x120 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UEULAErrorUI) == 0x140, "Size mismatch for UEULAErrorUI");
static_assert(offsetof(UEULAErrorUI, TitleOverride) == 0x110, "Offset mismatch for UEULAErrorUI::TitleOverride");
static_assert(offsetof(UEULAErrorUI, EulaModal) == 0x120, "Offset mismatch for UEULAErrorUI::EulaModal");

// Size: 0x118 (Inherited: 0x250, Single: 0xfffffec8)
class UGeneralBanUI : public UTimedErrorUI
{
public:
};

static_assert(sizeof(UGeneralBanUI) == 0x118, "Size mismatch for UGeneralBanUI");

// Size: 0x118 (Inherited: 0x138, Single: 0xffffffe0)
class UTimedErrorUI : public UReadyUpErrorUI
{
public:
};

static_assert(sizeof(UTimedErrorUI) == 0x118, "Size mismatch for UTimedErrorUI");

// Size: 0x110 (Inherited: 0x138, Single: 0xffffffd8)
class UIneligibleEventErrorUI : public UReadyUpErrorUI
{
public:
};

static_assert(sizeof(UIneligibleEventErrorUI) == 0x110, "Size mismatch for UIneligibleEventErrorUI");

// Size: 0x110 (Inherited: 0x138, Single: 0xffffffd8)
class UIsPreDownloadingUI : public UReadyUpErrorUI
{
public:
};

static_assert(sizeof(UIsPreDownloadingUI) == 0x110, "Size mismatch for UIsPreDownloadingUI");

// Size: 0x120 (Inherited: 0x258, Single: 0xfffffec8)
class UNotAvailableInSplitScreenErrorUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

static_assert(sizeof(UNotAvailableInSplitScreenErrorUI) == 0x120, "Size mismatch for UNotAvailableInSplitScreenErrorUI");

// Size: 0x120 (Inherited: 0x258, Single: 0xfffffec8)
class UNotEnoughPartyMembersUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

static_assert(sizeof(UNotEnoughPartyMembersUI) == 0x120, "Size mismatch for UNotEnoughPartyMembersUI");

// Size: 0x110 (Inherited: 0x138, Single: 0xffffffd8)
class UNotEnoughPlayersForPrivateUI : public UReadyUpErrorUI
{
public:
};

static_assert(sizeof(UNotEnoughPlayersForPrivateUI) == 0x110, "Size mismatch for UNotEnoughPlayersForPrivateUI");

// Size: 0x120 (Inherited: 0x258, Single: 0xfffffec8)
class UPlayersNotQualifiedErrorUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

static_assert(sizeof(UPlayersNotQualifiedErrorUI) == 0x120, "Size mismatch for UPlayersNotQualifiedErrorUI");

// Size: 0x110 (Inherited: 0x138, Single: 0xffffffd8)
class UQuestErrorUI : public UReadyUpErrorUI
{
public:
};

static_assert(sizeof(UQuestErrorUI) == 0x110, "Size mismatch for UQuestErrorUI");

// Size: 0x118 (Inherited: 0x138, Single: 0xffffffe0)
class URequiresPreDownloadUI : public UReadyUpErrorUI
{
public:
};

static_assert(sizeof(URequiresPreDownloadUI) == 0x118, "Size mismatch for URequiresPreDownloadUI");

// Size: 0x130 (Inherited: 0x138, Single: 0xfffffff8)
class USTWGeneralErrorUI : public UReadyUpErrorUI
{
public:
    TSoftClassPtr CampaignModal; // 0x110 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(USTWGeneralErrorUI) == 0x130, "Size mismatch for USTWGeneralErrorUI");
static_assert(offsetof(USTWGeneralErrorUI, CampaignModal) == 0x110, "Offset mismatch for USTWGeneralErrorUI::CampaignModal");

// Size: 0x110 (Inherited: 0x138, Single: 0xffffffd8)
class USTWRequiresFrontendErrorUI : public UReadyUpErrorUI
{
public:
};

static_assert(sizeof(USTWRequiresFrontendErrorUI) == 0x110, "Size mismatch for USTWRequiresFrontendErrorUI");

// Size: 0x120 (Inherited: 0x258, Single: 0xfffffec8)
class UTooManyPartyMembersUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

static_assert(sizeof(UTooManyPartyMembersUI) == 0x120, "Size mismatch for UTooManyPartyMembersUI");

// Size: 0x120 (Inherited: 0x258, Single: 0xfffffec8)
class UTooManySplitscreenMembersUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

static_assert(sizeof(UTooManySplitscreenMembersUI) == 0x120, "Size mismatch for UTooManySplitscreenMembersUI");

// Size: 0x110 (Inherited: 0x248, Single: 0xfffffec8)
class UTournamentLockedByAccountErrorUI : public UBaseTournamentLockErrorUI
{
public:
};

static_assert(sizeof(UTournamentLockedByAccountErrorUI) == 0x110, "Size mismatch for UTournamentLockedByAccountErrorUI");

// Size: 0x110 (Inherited: 0x248, Single: 0xfffffec8)
class UTournamentLockedByRegionUI : public UBaseTournamentLockErrorUI
{
public:
};

static_assert(sizeof(UTournamentLockedByRegionUI) == 0x110, "Size mismatch for UTournamentLockedByRegionUI");

// Size: 0x110 (Inherited: 0x248, Single: 0xfffffec8)
class UTournamentLockedByTeamErrorUI : public UBaseTournamentLockErrorUI
{
public:
};

static_assert(sizeof(UTournamentLockedByTeamErrorUI) == 0x110, "Size mismatch for UTournamentLockedByTeamErrorUI");

// Size: 0x140 (Inherited: 0x138, Single: 0x8)
class UTournamentRequiresMFAErrorUI : public UReadyUpErrorUI
{
public:
    TSoftClassPtr MFAModalClass; // 0x110 (Size: 0x20, Type: SoftClassProperty)
    uint8_t Pad_130[0x10]; // 0x130 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UTournamentRequiresMFAErrorUI) == 0x140, "Size mismatch for UTournamentRequiresMFAErrorUI");
static_assert(offsetof(UTournamentRequiresMFAErrorUI, MFAModalClass) == 0x110, "Offset mismatch for UTournamentRequiresMFAErrorUI::MFAModalClass");

// Size: 0x120 (Inherited: 0x258, Single: 0xfffffec8)
class UUnusableRegionUI : public UBaseRegionErrorUI
{
public:
};

static_assert(sizeof(UUnusableRegionUI) == 0x120, "Size mismatch for UUnusableRegionUI");

// Size: 0x178 (Inherited: 0x258, Single: 0xffffff20)
class UWorldOwnerMustBePartyLeaderErrorUI : public UBaseMatchmakingGroupErrorUI
{
public:
};

static_assert(sizeof(UWorldOwnerMustBePartyLeaderErrorUI) == 0x178, "Size mismatch for UWorldOwnerMustBePartyLeaderErrorUI");

