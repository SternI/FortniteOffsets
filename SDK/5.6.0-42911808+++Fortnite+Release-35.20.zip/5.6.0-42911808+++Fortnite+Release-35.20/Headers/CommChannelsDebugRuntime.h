/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommChannelsDebugRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x40 (Inherited: 0xc8, Single: 0xffffff78)
class UCommChannelsDebugDrawSubsystem : public UTickableWorldSubsystem
{
public:
};

static_assert(sizeof(UCommChannelsDebugDrawSubsystem) == 0x40, "Size mismatch for UCommChannelsDebugDrawSubsystem");

