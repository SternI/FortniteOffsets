/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosVDBlueprint
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChaosVDRuntimeBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

private:
    static void RecordDebugDrawBox(UObject*& const WorldContext, const FBox InBox, FName& Tag, FLinearColor& Color); // 0x12af78f8 (Index: 0x0, Flags: Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable)
    static void RecordDebugDrawLine(UObject*& const WorldContext, const FVector InStartLocation, const FVector InEndLocation, FName& Tag, FLinearColor& Color); // 0x12af7b58 (Index: 0x1, Flags: Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable)
    static void RecordDebugDrawSphere(UObject*& const WorldContext, const FVector InCenter, float& Radius, FName& Tag, FLinearColor& Color); // 0x12af7e30 (Index: 0x2, Flags: Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable)
    static void RecordDebugDrawVector(UObject*& const WorldContext, const FVector InStartLocation, const FVector InVector, FName& Tag, FLinearColor& Color); // 0x12af7b58 (Index: 0x3, Flags: Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UChaosVDRuntimeBlueprintLibrary) == 0x28, "Size mismatch for UChaosVDRuntimeBlueprintLibrary");

