/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortnitePlaytimeRewardsTypes
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteDynamicXpTypes.h"

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FPlaytimeXpProfileStat
{
    int32_t CurrentWeekXp; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t CurrentWeek; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FPlaytimeXpProfileStat) == 0x8, "Size mismatch for FPlaytimeXpProfileStat");
static_assert(offsetof(FPlaytimeXpProfileStat, CurrentWeekXp) == 0x0, "Offset mismatch for FPlaytimeXpProfileStat::CurrentWeekXp");
static_assert(offsetof(FPlaytimeXpProfileStat, CurrentWeek) == 0x4, "Offset mismatch for FPlaytimeXpProfileStat::CurrentWeek");

// Size: 0x30 (Inherited: 0x8, Single: 0x28)
struct FPlaytimeRewardsTableRow : FTableRowBase
{
    FGameplayTag ProductTag; // 0x8 (Size: 0x4, Type: StructProperty)
    int32_t XpPayout; // 0xc (Size: 0x4, Type: IntProperty)
    FRestedXpUsage RestedXpUsage; // 0x10 (Size: 0x8, Type: StructProperty)
    float CompletionTimeMinutes; // 0x18 (Size: 0x4, Type: FloatProperty)
    float DisplayTimeIntervalMinutes; // 0x1c (Size: 0x4, Type: FloatProperty)
    bool bDisableIfDynamicDistributorsAreActive; // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bUseDynamicXpCircuitBreaker; // 0x21 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_22[0x2]; // 0x22 (Size: 0x2, Type: PaddingProperty)
    int32_t WeeklyXpThreshold; // 0x24 (Size: 0x4, Type: IntProperty)
    int32_t DiminishedXpPayout; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FPlaytimeRewardsTableRow) == 0x30, "Size mismatch for FPlaytimeRewardsTableRow");
static_assert(offsetof(FPlaytimeRewardsTableRow, ProductTag) == 0x8, "Offset mismatch for FPlaytimeRewardsTableRow::ProductTag");
static_assert(offsetof(FPlaytimeRewardsTableRow, XpPayout) == 0xc, "Offset mismatch for FPlaytimeRewardsTableRow::XpPayout");
static_assert(offsetof(FPlaytimeRewardsTableRow, RestedXpUsage) == 0x10, "Offset mismatch for FPlaytimeRewardsTableRow::RestedXpUsage");
static_assert(offsetof(FPlaytimeRewardsTableRow, CompletionTimeMinutes) == 0x18, "Offset mismatch for FPlaytimeRewardsTableRow::CompletionTimeMinutes");
static_assert(offsetof(FPlaytimeRewardsTableRow, DisplayTimeIntervalMinutes) == 0x1c, "Offset mismatch for FPlaytimeRewardsTableRow::DisplayTimeIntervalMinutes");
static_assert(offsetof(FPlaytimeRewardsTableRow, bDisableIfDynamicDistributorsAreActive) == 0x20, "Offset mismatch for FPlaytimeRewardsTableRow::bDisableIfDynamicDistributorsAreActive");
static_assert(offsetof(FPlaytimeRewardsTableRow, bUseDynamicXpCircuitBreaker) == 0x21, "Offset mismatch for FPlaytimeRewardsTableRow::bUseDynamicXpCircuitBreaker");
static_assert(offsetof(FPlaytimeRewardsTableRow, WeeklyXpThreshold) == 0x24, "Offset mismatch for FPlaytimeRewardsTableRow::WeeklyXpThreshold");
static_assert(offsetof(FPlaytimeRewardsTableRow, DiminishedXpPayout) == 0x28, "Offset mismatch for FPlaytimeRewardsTableRow::DiminishedXpPayout");

