/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ElectraDataChannelRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"
#include "MediaAssets.h"

// Size: 0x2d8 (Inherited: 0x2d0, Single: 0x8)
class AElectraDataChannelPlayer : public AActor
{
public:
    uint8_t OnTerminalError[0x10]; // 0x2a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_2b8[0x20]; // 0x2b8 (Size: 0x20, Type: PaddingProperty)

public:
    void EndPlayback(); // 0x11ab8ec8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void PlayFromFile(FString& InFilename); // 0x11ab8f0c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void PlayFromMediaPlayer(UMediaPlayer*& InMediaPlayer); // 0x11ab9200 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void PlayFromStateStreamServer(FString& InStatePlaylistURL); // 0x11ab932c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void UseTimeFromMediaPlayer(UMediaPlayer*& InMediaPlayer); // 0x11ab9c28 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(AElectraDataChannelPlayer) == 0x2d8, "Size mismatch for AElectraDataChannelPlayer");
static_assert(offsetof(AElectraDataChannelPlayer, OnTerminalError) == 0x2a8, "Offset mismatch for AElectraDataChannelPlayer::OnTerminalError");

// Size: 0x2e0 (Inherited: 0x2d0, Single: 0x10)
class AElectraDataChannelRecorder : public AActor
{
public:

public:
    void EndRecording(); // 0x11ab8edc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void RecordToFile(FString& InFilename); // 0x11ab9620 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void StartRecording(); // 0x11ab9c14 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void UseTimeFromMediaPlayer(UMediaPlayer*& InMediaPlayer); // 0x11ab9d54 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(AElectraDataChannelRecorder) == 0x2e0, "Size mismatch for AElectraDataChannelRecorder");

// Size: 0x320 (Inherited: 0x2d0, Single: 0x50)
class AElectraDataChannelTarget : public AActor
{
public:

public:
    FString GetTargetAlias() const; // 0x11ab8ef0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetTargetAlias(FString& InAlias); // 0x11ab9914 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(AElectraDataChannelTarget) == 0x320, "Size mismatch for AElectraDataChannelTarget");

