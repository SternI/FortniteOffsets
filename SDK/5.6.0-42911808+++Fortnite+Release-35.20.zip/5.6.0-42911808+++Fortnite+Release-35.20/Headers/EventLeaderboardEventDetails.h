/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EventLeaderboardEventDetails
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "Engine.h"
#include "CommonUI.h"

// Size: 0x748 (Inherited: 0xe58, Single: 0xfffff8f0)
class UEventLeaderboardEventDetails_C : public UFortShowdownDetailView
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x728 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_SessionName; // 0x730 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_RoundAndRegionName; // 0x738 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_EventName; // 0x740 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void RefreshDataBP(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UEventLeaderboardEventDetails_C) == 0x748, "Size mismatch for UEventLeaderboardEventDetails_C");
static_assert(offsetof(UEventLeaderboardEventDetails_C, UberGraphFrame) == 0x728, "Offset mismatch for UEventLeaderboardEventDetails_C::UberGraphFrame");
static_assert(offsetof(UEventLeaderboardEventDetails_C, Text_SessionName) == 0x730, "Offset mismatch for UEventLeaderboardEventDetails_C::Text_SessionName");
static_assert(offsetof(UEventLeaderboardEventDetails_C, Text_RoundAndRegionName) == 0x738, "Offset mismatch for UEventLeaderboardEventDetails_C::Text_RoundAndRegionName");
static_assert(offsetof(UEventLeaderboardEventDetails_C, Text_EventName) == 0x740, "Offset mismatch for UEventLeaderboardEventDetails_C::Text_EventName");

