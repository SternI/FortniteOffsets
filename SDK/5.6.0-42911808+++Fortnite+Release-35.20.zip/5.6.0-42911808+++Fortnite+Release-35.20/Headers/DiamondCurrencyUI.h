/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DiamondCurrencyUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "GameplayTags.h"

// Size: 0x370 (Inherited: 0xa48, Single: 0xfffff928)
class UFortDiamondHUDWidget : public UFortHUDElementWidget
{
public:
    UPanelWidget* Panel_BoundVisibility; // 0x318 (Size: 0x8, Type: ObjectProperty)
    UFortResourceItemDefinition* ResourceItemDefinition; // 0x320 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer DiamondSpendablesActorTags; // 0x328 (Size: 0x20, Type: StructProperty)
    float OverlapDiamondSpendableSphereRadius; // 0x348 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34c[0x24]; // 0x34c (Size: 0x24, Type: PaddingProperty)

private:
    void HandleWorldItemsChanged(); // 0x113a9eb4 (Index: 0x0, Flags: Final|Native|Private)

protected:
    virtual void OnResourceCountChanged(int32_t& const OldCount, int32_t& const NewCount); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortDiamondHUDWidget) == 0x370, "Size mismatch for UFortDiamondHUDWidget");
static_assert(offsetof(UFortDiamondHUDWidget, Panel_BoundVisibility) == 0x318, "Offset mismatch for UFortDiamondHUDWidget::Panel_BoundVisibility");
static_assert(offsetof(UFortDiamondHUDWidget, ResourceItemDefinition) == 0x320, "Offset mismatch for UFortDiamondHUDWidget::ResourceItemDefinition");
static_assert(offsetof(UFortDiamondHUDWidget, DiamondSpendablesActorTags) == 0x328, "Offset mismatch for UFortDiamondHUDWidget::DiamondSpendablesActorTags");
static_assert(offsetof(UFortDiamondHUDWidget, OverlapDiamondSpendableSphereRadius) == 0x348, "Offset mismatch for UFortDiamondHUDWidget::OverlapDiamondSpendableSphereRadius");

