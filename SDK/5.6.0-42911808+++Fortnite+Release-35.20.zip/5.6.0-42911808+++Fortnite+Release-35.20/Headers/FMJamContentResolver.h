/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamContentResolver
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "ModularGameplay.h"
#include "Engine.h"

// Size: 0x368 (Inherited: 0x250, Single: 0x118)
class UJamContentResolver : public UGameStateComponent
{
public:
};

static_assert(sizeof(UJamContentResolver) == 0x368, "Size mismatch for UJamContentResolver");

// Size: 0x110 (Inherited: 0x250, Single: 0xfffffec0)
class UJamControllerComponent_ContentResolver : public UControllerComponent
{
public:

private:
    virtual void Client_ResolveLinkCodeFinished(bool& const bSuccess, FString& LinkCode, TArray<FString>& const PluginUrls); // 0x10790f50 (Index: 0x0, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    virtual void Server_ResolveLinkCode(FString& PlatformName, FString& LinkCode); // 0x10791420 (Index: 0x1, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
};

static_assert(sizeof(UJamControllerComponent_ContentResolver) == 0x110, "Size mismatch for UJamControllerComponent_ContentResolver");

