/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserTileDetailsDisplay
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DiscoveryBrowserUI.h"
#include "WBP_Discovery_WarningIcon.h"
#include "WBP_ActivityBrowserSocialProof.h"
#include "Engine.h"
#include "UI.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "WBP_LockedStatus.h"

// Size: 0x1928 (Inherited: 0x5da0, Single: 0xffffbb88)
class UActivityBrowserTileDetailsDisplay_C : public UFortActivityTileDetailsDisplay
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x1760 (Size: 0x8, Type: StructProperty)
    UWBP_LockedStatus_C* WBP_LockedStatus; // 0x1768 (Size: 0x8, Type: ObjectProperty)
    UWBP_Discovery_WarningIcon_C* WBP_Discovery_WarningIcon; // 0x1770 (Size: 0x8, Type: ObjectProperty)
    UWBP_Discovery_Favorite_C* WBP_Discovery_Favorite; // 0x1778 (Size: 0x8, Type: ObjectProperty)
    UImage* TileThumbnail; // 0x1780 (Size: 0x8, Type: ObjectProperty)
    UImage* TileStroke; // 0x1788 (Size: 0x8, Type: ObjectProperty)
    USqueegeeInjectionSlot_C* SqueegeeSlot_Lock; // 0x1790 (Size: 0x8, Type: ObjectProperty)
    USpacer* Spacer_Mobile; // 0x1798 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_Primary; // 0x17a0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* OvrDisabledWarningMessage; // 0x17a8 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Ovr_Primary; // 0x17b0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_PurchaseRequired; // 0x17b8 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_InteractButtons; // 0x17c0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Favorite; // 0x17c8 (Size: 0x8, Type: ObjectProperty)
    UOverlay* OriginalContentEpicBanner; // 0x17d0 (Size: 0x8, Type: ObjectProperty)
    UImage* Logo_NotReady_Fort554488; // 0x17d8 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_MultiMode; // 0x17e0 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_PlayerCount; // 0x17e8 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_LocksAndHearts; // 0x17f0 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_ActivityInfo; // 0x17f8 (Size: 0x8, Type: ObjectProperty)
    UImage* EpicBannerBg; // 0x1800 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* DisabledWarningMessage; // 0x1808 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* BannerText; // 0x1810 (Size: 0x8, Type: ObjectProperty)
    UWBP_ActivityBrowserSocialProof_C* ActivityBrowserSocialProof; // 0x1818 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnHoverSelect; // 0x1820 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnHoverSelect_GrowNonHeroRowTiles; // 0x1828 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnIntro; // 0x1830 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_HoverPulse; // 0x1838 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnImageLoaded; // 0x1840 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnHoverUnhoverRehover; // 0x1848 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_OnDisabledClick; // 0x1850 (Size: 0x8, Type: ObjectProperty)
    bool IsKeyArtValid; // 0x1858 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1859[0x7]; // 0x1859 (Size: 0x7, Type: PaddingProperty)
    UTexture* DefaultImage; // 0x1860 (Size: 0x8, Type: ObjectProperty)
    bool IsTileActive; // 0x1868 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1869[0x7]; // 0x1869 (Size: 0x7, Type: PaddingProperty)
    FTimerHandle DisabledClickTimer; // 0x1870 (Size: 0x8, Type: StructProperty)
    double DisabledClickDuration; // 0x1878 (Size: 0x8, Type: DoubleProperty)
    bool IsActivityValid; // 0x1880 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1881[0x7]; // 0x1881 (Size: 0x7, Type: PaddingProperty)
    FVector2D TileSize; // 0x1888 (Size: 0x10, Type: StructProperty)
    FName TextureParam; // 0x1898 (Size: 0x4, Type: NameProperty)
    FName ThumbnailAlpha; // 0x189c (Size: 0x4, Type: NameProperty)
    FName ThumbnailScale; // 0x18a0 (Size: 0x4, Type: NameProperty)
    FName ThumbnailDisabledOverlay; // 0x18a4 (Size: 0x4, Type: NameProperty)
    FName FrameColor; // 0x18a8 (Size: 0x4, Type: NameProperty)
    FLinearColor BaseColor; // 0x18ac (Size: 0x10, Type: StructProperty)
    FLinearColor EpicColor; // 0x18bc (Size: 0x10, Type: StructProperty)
    FLinearColor StrokeColor; // 0x18cc (Size: 0x10, Type: StructProperty)
    FLinearColor DisabledColor; // 0x18dc (Size: 0x10, Type: StructProperty)
    uint8_t Pad_18ec[0x4]; // 0x18ec (Size: 0x4, Type: PaddingProperty)
    double BannerColorAnimator; // 0x18f0 (Size: 0x8, Type: DoubleProperty)
    double VerticalTilePaddingOffset; // 0x18f8 (Size: 0x8, Type: DoubleProperty)
    bool HideDetails; // 0x1900 (Size: 0x1, Type: BoolProperty)
    bool IsPurchaseRequired; // 0x1901 (Size: 0x1, Type: BoolProperty)
    bool bAllowThumbnailHoverRehoverAnim; // 0x1902 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1903[0x5]; // 0x1903 (Size: 0x5, Type: PaddingProperty)
    double GridSingleColumnWidth; // 0x1908 (Size: 0x8, Type: DoubleProperty)
    double GridSingleGutterWidth; // 0x1910 (Size: 0x8, Type: DoubleProperty)
    double Ratio16x9ConvertWidthToHeight; // 0x1918 (Size: 0x8, Type: DoubleProperty)
    bool IsPromotedHeroRow; // 0x1920 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1921[0x3]; // 0x1921 (Size: 0x3, Type: PaddingProperty)
    int32_t DefaultGameModeTextSize; // 0x1924 (Size: 0x4, Type: IntProperty)

public:
    void UpdateRequiresPurchase(bool& IsPurchaseRequired); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ResetOnHoverSelectAnimation(); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ResetOnImageLoadedAnimation(bool& IsLoaded); // 0x288a61c (Index: 0x8, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Grow_Tile_on_Select_for_Non_Hero_Rows(); // 0x288a61c (Index: 0xf, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x12, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void ColumnSizeToTileSize(int32_t& NewColumnSize, FVector2D& NewTileSize); // 0x288a61c (Index: 0x13, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void SetFavoriteVisibility(bool& IsFavorited); // 0x288a61c (Index: 0x1a, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Game_Mode_Text_Size_Override(); // 0x288a61c (Index: 0x1b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetBannerColorAnimator(double& NewParam); // 0x288a61c (Index: 0x1c, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetDetailsButtonAvailable(); // 0x288a61c (Index: 0x1d, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetFirstTimeModalStyle(); // 0x288a61c (Index: 0x1e, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateEpicActivityStyling(FString& CreatorDisplayName); // 0x288a61c (Index: 0x1f, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetDisabledText(); // 0x288a61c (Index: 0x20, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetDisabledThumbnailOverlay(); // 0x288a61c (Index: 0x21, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetIsPromotedHero(bool& IsPromotedHeroCarousel); // 0x288a61c (Index: 0x22, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetHideDetails(bool& Hide_Details); // 0x288a61c (Index: 0x23, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetExtraVerticalPaddingOffset(double& InVerticalTilePadding); // 0x288a61c (Index: 0x24, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetTileSize(FVector2D& Size); // 0x288a61c (Index: 0x25, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Game_Mode_Text_Size(int32_t& FontSize); // 0x288a61c (Index: 0x26, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x2b, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void OnTileActiveSet(bool& const bIsTileActive); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRequiresPurchaseChanged(bool& const bRequiresPurchase); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPreviewImageChanged(bool& const bIsLoading, UTexture*& const Texture); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPartySizeChanged(int32_t& const PartySize); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void OnLogoImageChanged(bool& const bIsLoading, UTexture*& const Texture); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void OnLocalPlayerPromotedToLeader(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void OnLocalPlayerDemoted(); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void OnListItemObjectSet(UObject*& ListItemObject); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
    virtual void OnIsFavoriteChanged(bool& const bIsFavorite); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void OnFriendsPlayingChanged(int32_t& NumPlaying); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void OnDetailsUpdated(); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnUnhovered(); // 0x288a61c (Index: 0x14, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnItemSelectionChanged(bool& bIsSelected); // 0x288a61c (Index: 0x15, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnItemExpansionChanged(bool& bIsExpanded); // 0x288a61c (Index: 0x16, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnHovered(); // 0x288a61c (Index: 0x17, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnEntryReleased(); // 0x288a61c (Index: 0x18, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnClicked(); // 0x288a61c (Index: 0x19, Flags: Event|Protected|BlueprintEvent)
    virtual void UpdateCCU(int32_t& const CCUCount); // 0x288a61c (Index: 0x27, Flags: Event|Protected|BlueprintEvent)
    virtual void ShouldPlayTileVideo(bool& bOutResult); // 0x288a61c (Index: 0x28, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual void UpdateSqueegeeWidgets(UFortGameActivity*& GameActivity); // 0x288a61c (Index: 0x2c, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UActivityBrowserTileDetailsDisplay_C) == 0x1928, "Size mismatch for UActivityBrowserTileDetailsDisplay_C");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, UberGraphFrame) == 0x1760, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::UberGraphFrame");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, WBP_LockedStatus) == 0x1768, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::WBP_LockedStatus");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, WBP_Discovery_WarningIcon) == 0x1770, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::WBP_Discovery_WarningIcon");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, WBP_Discovery_Favorite) == 0x1778, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::WBP_Discovery_Favorite");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, TileThumbnail) == 0x1780, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::TileThumbnail");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, TileStroke) == 0x1788, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::TileStroke");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, SqueegeeSlot_Lock) == 0x1790, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::SqueegeeSlot_Lock");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Spacer_Mobile) == 0x1798, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Spacer_Mobile");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, SizeBox_Primary) == 0x17a0, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::SizeBox_Primary");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, OvrDisabledWarningMessage) == 0x17a8, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::OvrDisabledWarningMessage");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Ovr_Primary) == 0x17b0, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Ovr_Primary");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Overlay_PurchaseRequired) == 0x17b8, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Overlay_PurchaseRequired");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Overlay_InteractButtons) == 0x17c0, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Overlay_InteractButtons");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Overlay_Favorite) == 0x17c8, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Overlay_Favorite");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, OriginalContentEpicBanner) == 0x17d0, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::OriginalContentEpicBanner");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Logo_NotReady_Fort554488) == 0x17d8, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Logo_NotReady_Fort554488");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Image_MultiMode) == 0x17e0, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Image_MultiMode");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, HorizontalBox_PlayerCount) == 0x17e8, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::HorizontalBox_PlayerCount");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, HorizontalBox_LocksAndHearts) == 0x17f0, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::HorizontalBox_LocksAndHearts");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, HorizontalBox_ActivityInfo) == 0x17f8, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::HorizontalBox_ActivityInfo");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, EpicBannerBg) == 0x1800, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::EpicBannerBg");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, DisabledWarningMessage) == 0x1808, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::DisabledWarningMessage");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, BannerText) == 0x1810, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::BannerText");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, ActivityBrowserSocialProof) == 0x1818, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::ActivityBrowserSocialProof");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Anim_OnHoverSelect) == 0x1820, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Anim_OnHoverSelect");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Anim_OnHoverSelect_GrowNonHeroRowTiles) == 0x1828, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Anim_OnHoverSelect_GrowNonHeroRowTiles");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Anim_OnIntro) == 0x1830, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Anim_OnIntro");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Anim_HoverPulse) == 0x1838, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Anim_HoverPulse");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Anim_OnImageLoaded) == 0x1840, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Anim_OnImageLoaded");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Anim_OnHoverUnhoverRehover) == 0x1848, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Anim_OnHoverUnhoverRehover");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Anim_OnDisabledClick) == 0x1850, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Anim_OnDisabledClick");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, IsKeyArtValid) == 0x1858, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::IsKeyArtValid");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, DefaultImage) == 0x1860, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::DefaultImage");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, IsTileActive) == 0x1868, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::IsTileActive");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, DisabledClickTimer) == 0x1870, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::DisabledClickTimer");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, DisabledClickDuration) == 0x1878, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::DisabledClickDuration");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, IsActivityValid) == 0x1880, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::IsActivityValid");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, TileSize) == 0x1888, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::TileSize");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, TextureParam) == 0x1898, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::TextureParam");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, ThumbnailAlpha) == 0x189c, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::ThumbnailAlpha");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, ThumbnailScale) == 0x18a0, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::ThumbnailScale");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, ThumbnailDisabledOverlay) == 0x18a4, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::ThumbnailDisabledOverlay");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, FrameColor) == 0x18a8, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::FrameColor");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, BaseColor) == 0x18ac, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::BaseColor");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, EpicColor) == 0x18bc, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::EpicColor");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, StrokeColor) == 0x18cc, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::StrokeColor");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, DisabledColor) == 0x18dc, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::DisabledColor");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, BannerColorAnimator) == 0x18f0, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::BannerColorAnimator");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, VerticalTilePaddingOffset) == 0x18f8, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::VerticalTilePaddingOffset");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, HideDetails) == 0x1900, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::HideDetails");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, IsPurchaseRequired) == 0x1901, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::IsPurchaseRequired");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, bAllowThumbnailHoverRehoverAnim) == 0x1902, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::bAllowThumbnailHoverRehoverAnim");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, GridSingleColumnWidth) == 0x1908, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::GridSingleColumnWidth");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, GridSingleGutterWidth) == 0x1910, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::GridSingleGutterWidth");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, Ratio16x9ConvertWidthToHeight) == 0x1918, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::Ratio16x9ConvertWidthToHeight");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, IsPromotedHeroRow) == 0x1920, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::IsPromotedHeroRow");
static_assert(offsetof(UActivityBrowserTileDetailsDisplay_C, DefaultGameModeTextSize) == 0x1924, "Offset mismatch for UActivityBrowserTileDetailsDisplay_C::DefaultGameModeTextSize");

