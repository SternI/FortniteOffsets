/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EntityLevel
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x530 (Inherited: 0x840, Single: 0xfffffcf0)
class UEntitySceneComponent : public UPrimitiveComponent
{
public:
    ALevelEntity* LevelEntity; // 0x518 (Size: 0x8, Type: ObjectProperty)
    bool bIgnoreAttachmentUponPaste; // 0x520 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_521[0xf]; // 0x521 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(UEntitySceneComponent) == 0x530, "Size mismatch for UEntitySceneComponent");
static_assert(offsetof(UEntitySceneComponent, LevelEntity) == 0x518, "Offset mismatch for UEntitySceneComponent::LevelEntity");
static_assert(offsetof(UEntitySceneComponent, bIgnoreAttachmentUponPaste) == 0x520, "Offset mismatch for UEntitySceneComponent::bIgnoreAttachmentUponPaste");

// Size: 0x2e8 (Inherited: 0x2d0, Single: 0x18)
class AEntityProxyActor : public AActor
{
public:
    uint8_t Pad_2a8[0x8]; // 0x2a8 (Size: 0x8, Type: PaddingProperty)
    UObject* Entity; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2b8[0x8]; // 0x2b8 (Size: 0x8, Type: PaddingProperty)
    ALevelEntity* LevelEntity; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UObject* TransformComponent; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2d0[0x10]; // 0x2d0 (Size: 0x10, Type: PaddingProperty)
    UObject* DuplicatedEntity; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(AEntityProxyActor) == 0x2e8, "Size mismatch for AEntityProxyActor");
static_assert(offsetof(AEntityProxyActor, Entity) == 0x2b0, "Offset mismatch for AEntityProxyActor::Entity");
static_assert(offsetof(AEntityProxyActor, LevelEntity) == 0x2c0, "Offset mismatch for AEntityProxyActor::LevelEntity");
static_assert(offsetof(AEntityProxyActor, TransformComponent) == 0x2c8, "Offset mismatch for AEntityProxyActor::TransformComponent");
static_assert(offsetof(AEntityProxyActor, DuplicatedEntity) == 0x2e0, "Offset mismatch for AEntityProxyActor::DuplicatedEntity");

// Size: 0xc8 (Inherited: 0xe0, Single: 0xffffffe8)
class UEntityProxyActorComponent : public UActorComponent
{
public:
    UObject* Entity; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UObject* EntityComponent; // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UEntityProxyActorComponent) == 0xc8, "Size mismatch for UEntityProxyActorComponent");
static_assert(offsetof(UEntityProxyActorComponent, Entity) == 0xb8, "Offset mismatch for UEntityProxyActorComponent::Entity");
static_assert(offsetof(UEntityProxyActorComponent, EntityComponent) == 0xc0, "Offset mismatch for UEntityProxyActorComponent::EntityComponent");

// Size: 0x2d0 (Inherited: 0x2d0, Single: 0x0)
class ALevelEntity : public AActor
{
public:
    uint8_t Pad_2a8[0x8]; // 0x2a8 (Size: 0x8, Type: PaddingProperty)
    UObject* LevelEntity; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2b8[0x8]; // 0x2b8 (Size: 0x8, Type: PaddingProperty)
    UClass* SavedEntityClass; // 0x2c0 (Size: 0x8, Type: ClassProperty)
    UClass* SavedEntityComponentClass; // 0x2c8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(ALevelEntity) == 0x2d0, "Size mismatch for ALevelEntity");
static_assert(offsetof(ALevelEntity, LevelEntity) == 0x2b0, "Offset mismatch for ALevelEntity::LevelEntity");
static_assert(offsetof(ALevelEntity, SavedEntityClass) == 0x2c0, "Offset mismatch for ALevelEntity::SavedEntityClass");
static_assert(offsetof(ALevelEntity, SavedEntityComponentClass) == 0x2c8, "Offset mismatch for ALevelEntity::SavedEntityComponentClass");

