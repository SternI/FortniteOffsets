/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ComputeFramework
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UComputeDataInterface : public UObject
{
public:
};

static_assert(sizeof(UComputeDataInterface) == 0x28, "Size mismatch for UComputeDataInterface");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UComputeDataProvider : public UObject
{
public:
};

static_assert(sizeof(UComputeDataProvider) == 0x28, "Size mismatch for UComputeDataProvider");

// Size: 0x98 (Inherited: 0x28, Single: 0x70)
class UComputeKernelSource : public UObject
{
public:
    FString EntryPoint; // 0x28 (Size: 0x10, Type: StrProperty)
    FIntVector GroupSize; // 0x38 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
    FComputeKernelPermutationSet PermutationSet; // 0x48 (Size: 0x10, Type: StructProperty)
    FComputeKernelDefinitionSet DefinitionsSet; // 0x58 (Size: 0x10, Type: StructProperty)
    TArray<UComputeSource*> AdditionalSources; // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<FShaderFunctionDefinition> ExternalInputs; // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<FShaderFunctionDefinition> ExternalOutputs; // 0x88 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UComputeKernelSource) == 0x98, "Size mismatch for UComputeKernelSource");
static_assert(offsetof(UComputeKernelSource, EntryPoint) == 0x28, "Offset mismatch for UComputeKernelSource::EntryPoint");
static_assert(offsetof(UComputeKernelSource, GroupSize) == 0x38, "Offset mismatch for UComputeKernelSource::GroupSize");
static_assert(offsetof(UComputeKernelSource, PermutationSet) == 0x48, "Offset mismatch for UComputeKernelSource::PermutationSet");
static_assert(offsetof(UComputeKernelSource, DefinitionsSet) == 0x58, "Offset mismatch for UComputeKernelSource::DefinitionsSet");
static_assert(offsetof(UComputeKernelSource, AdditionalSources) == 0x68, "Offset mismatch for UComputeKernelSource::AdditionalSources");
static_assert(offsetof(UComputeKernelSource, ExternalInputs) == 0x78, "Offset mismatch for UComputeKernelSource::ExternalInputs");
static_assert(offsetof(UComputeKernelSource, ExternalOutputs) == 0x88, "Offset mismatch for UComputeKernelSource::ExternalOutputs");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UComputeSource : public UObject
{
public:
    TArray<UComputeSource*> AdditionalSources; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UComputeSource) == 0x38, "Size mismatch for UComputeSource");
static_assert(offsetof(UComputeSource, AdditionalSources) == 0x28, "Offset mismatch for UComputeSource::AdditionalSources");

// Size: 0xe0 (Inherited: 0x28, Single: 0xb8)
class UComputeGraph : public UObject
{
public:
    TArray<UComputeKernel*> KernelInvocations; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<UComputeDataInterface*> DataInterfaces; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FComputeGraphEdge> GraphEdges; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> Bindings; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> DataInterfaceToBinding; // 0x68 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_78[0x68]; // 0x78 (Size: 0x68, Type: PaddingProperty)
};

static_assert(sizeof(UComputeGraph) == 0xe0, "Size mismatch for UComputeGraph");
static_assert(offsetof(UComputeGraph, KernelInvocations) == 0x28, "Offset mismatch for UComputeGraph::KernelInvocations");
static_assert(offsetof(UComputeGraph, DataInterfaces) == 0x38, "Offset mismatch for UComputeGraph::DataInterfaces");
static_assert(offsetof(UComputeGraph, GraphEdges) == 0x48, "Offset mismatch for UComputeGraph::GraphEdges");
static_assert(offsetof(UComputeGraph, Bindings) == 0x58, "Offset mismatch for UComputeGraph::Bindings");
static_assert(offsetof(UComputeGraph, DataInterfaceToBinding) == 0x68, "Offset mismatch for UComputeGraph::DataInterfaceToBinding");

// Size: 0xd8 (Inherited: 0xe0, Single: 0xfffffff8)
class UComputeGraphComponent : public UActorComponent
{
public:
    UComputeGraph* ComputeGraph; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    FComputeGraphInstance ComputeGraphInstance; // 0xc0 (Size: 0x18, Type: StructProperty)

public:
    void CreateDataProviders(int32_t& InBindingIndex, UObject*& InBindingObject); // 0x103f8e34 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void DestroyDataProviders(); // 0x103f91f0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void QueueExecute(); // 0x103f9230 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UComputeGraphComponent) == 0xd8, "Size mismatch for UComputeGraphComponent");
static_assert(offsetof(UComputeGraphComponent, ComputeGraph) == 0xb8, "Offset mismatch for UComputeGraphComponent::ComputeGraph");
static_assert(offsetof(UComputeGraphComponent, ComputeGraphInstance) == 0xc0, "Offset mismatch for UComputeGraphComponent::ComputeGraphInstance");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UComputeKernel : public UObject
{
public:
    UComputeKernelSource* KernelSource; // 0x28 (Size: 0x8, Type: ObjectProperty)
    int32_t KernelFlags; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UComputeKernel) == 0x38, "Size mismatch for UComputeKernel");
static_assert(offsetof(UComputeKernel, KernelSource) == 0x28, "Offset mismatch for UComputeKernel::KernelSource");
static_assert(offsetof(UComputeKernel, KernelFlags) == 0x30, "Offset mismatch for UComputeKernel::KernelFlags");

// Size: 0xa8 (Inherited: 0xc0, Single: 0xffffffe8)
class UComputeKernelFromText : public UComputeKernelSource
{
public:
    FFilePath SourceFile; // 0x98 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UComputeKernelFromText) == 0xa8, "Size mismatch for UComputeKernelFromText");
static_assert(offsetof(UComputeKernelFromText, SourceFile) == 0x98, "Offset mismatch for UComputeKernelFromText::SourceFile");

// Size: 0x48 (Inherited: 0x60, Single: 0xffffffe8)
class UComputeSourceFromText : public UComputeSource
{
public:
    FFilePath SourceFile; // 0x38 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UComputeSourceFromText) == 0x48, "Size mismatch for UComputeSourceFromText");
static_assert(offsetof(UComputeSourceFromText, SourceFile) == 0x38, "Offset mismatch for UComputeSourceFromText::SourceFile");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FComputeGraphEdge
{
    int32_t KernelIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t KernelBindingIndex; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t DataInterfaceIndex; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t DataInterfaceBindingIndex; // 0xc (Size: 0x4, Type: IntProperty)
    bool bKernelInput; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FString BindingFunctionNameOverride; // 0x18 (Size: 0x10, Type: StrProperty)
    FString BindingFunctionNamespace; // 0x28 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FComputeGraphEdge) == 0x38, "Size mismatch for FComputeGraphEdge");
static_assert(offsetof(FComputeGraphEdge, KernelIndex) == 0x0, "Offset mismatch for FComputeGraphEdge::KernelIndex");
static_assert(offsetof(FComputeGraphEdge, KernelBindingIndex) == 0x4, "Offset mismatch for FComputeGraphEdge::KernelBindingIndex");
static_assert(offsetof(FComputeGraphEdge, DataInterfaceIndex) == 0x8, "Offset mismatch for FComputeGraphEdge::DataInterfaceIndex");
static_assert(offsetof(FComputeGraphEdge, DataInterfaceBindingIndex) == 0xc, "Offset mismatch for FComputeGraphEdge::DataInterfaceBindingIndex");
static_assert(offsetof(FComputeGraphEdge, bKernelInput) == 0x10, "Offset mismatch for FComputeGraphEdge::bKernelInput");
static_assert(offsetof(FComputeGraphEdge, BindingFunctionNameOverride) == 0x18, "Offset mismatch for FComputeGraphEdge::BindingFunctionNameOverride");
static_assert(offsetof(FComputeGraphEdge, BindingFunctionNamespace) == 0x28, "Offset mismatch for FComputeGraphEdge::BindingFunctionNamespace");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FComputeGraphInstance
{
    TArray<UComputeDataProvider*> DataProviders; // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_10[0x8]; // 0x10 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FComputeGraphInstance) == 0x18, "Size mismatch for FComputeGraphInstance");
static_assert(offsetof(FComputeGraphInstance, DataProviders) == 0x0, "Offset mismatch for FComputeGraphInstance::DataProviders");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FComputeKernelPermutationBool
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    bool Value; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FComputeKernelPermutationBool) == 0x18, "Size mismatch for FComputeKernelPermutationBool");
static_assert(offsetof(FComputeKernelPermutationBool, Name) == 0x0, "Offset mismatch for FComputeKernelPermutationBool::Name");
static_assert(offsetof(FComputeKernelPermutationBool, Value) == 0x10, "Offset mismatch for FComputeKernelPermutationBool::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FComputeKernelPermutationSet
{
    TArray<FComputeKernelPermutationBool> BooleanOptions; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FComputeKernelPermutationSet) == 0x10, "Size mismatch for FComputeKernelPermutationSet");
static_assert(offsetof(FComputeKernelPermutationSet, BooleanOptions) == 0x0, "Offset mismatch for FComputeKernelPermutationSet::BooleanOptions");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FComputeKernelDefinition
{
    FString Symbol; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Define; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FComputeKernelDefinition) == 0x20, "Size mismatch for FComputeKernelDefinition");
static_assert(offsetof(FComputeKernelDefinition, Symbol) == 0x0, "Offset mismatch for FComputeKernelDefinition::Symbol");
static_assert(offsetof(FComputeKernelDefinition, Define) == 0x10, "Offset mismatch for FComputeKernelDefinition::Define");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FComputeKernelDefinitionSet
{
    TArray<FComputeKernelDefinition> Defines; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FComputeKernelDefinitionSet) == 0x10, "Size mismatch for FComputeKernelDefinitionSet");
static_assert(offsetof(FComputeKernelDefinitionSet, Defines) == 0x0, "Offset mismatch for FComputeKernelDefinitionSet::Defines");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FComputeKernelPermutationVector
{
    TMap<uint32_t, FString> Permutations; // 0x0 (Size: 0x50, Type: MapProperty)
    uint32_t BitCount; // 0x50 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FComputeKernelPermutationVector) == 0x58, "Size mismatch for FComputeKernelPermutationVector");
static_assert(offsetof(FComputeKernelPermutationVector, Permutations) == 0x0, "Offset mismatch for FComputeKernelPermutationVector::Permutations");
static_assert(offsetof(FComputeKernelPermutationVector, BitCount) == 0x50, "Offset mismatch for FComputeKernelPermutationVector::BitCount");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FShaderValueTypeHandle
{
};

static_assert(sizeof(FShaderValueTypeHandle) == 0x8, "Size mismatch for FShaderValueTypeHandle");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FArrayShaderValue
{
    TArray<char> ArrayOfValues; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FArrayShaderValue) == 0x10, "Size mismatch for FArrayShaderValue");
static_assert(offsetof(FArrayShaderValue, ArrayOfValues) == 0x0, "Offset mismatch for FArrayShaderValue::ArrayOfValues");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FShaderValueContainer
{
    TArray<char> ShaderValue; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FArrayShaderValue> ArrayList; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FShaderValueContainer) == 0x20, "Size mismatch for FShaderValueContainer");
static_assert(offsetof(FShaderValueContainer, ShaderValue) == 0x0, "Offset mismatch for FShaderValueContainer::ShaderValue");
static_assert(offsetof(FShaderValueContainer, ArrayList) == 0x10, "Offset mismatch for FShaderValueContainer::ArrayList");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FShaderValueType
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t DimensionType; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    FName Name; // 0x4 (Size: 0x4, Type: NameProperty)
    bool bIsDynamicArray; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x17]; // 0x9 (Size: 0x17, Type: PaddingProperty)
};

static_assert(sizeof(FShaderValueType) == 0x20, "Size mismatch for FShaderValueType");
static_assert(offsetof(FShaderValueType, Type) == 0x0, "Offset mismatch for FShaderValueType::Type");
static_assert(offsetof(FShaderValueType, DimensionType) == 0x1, "Offset mismatch for FShaderValueType::DimensionType");
static_assert(offsetof(FShaderValueType, Name) == 0x4, "Offset mismatch for FShaderValueType::Name");
static_assert(offsetof(FShaderValueType, bIsDynamicArray) == 0x8, "Offset mismatch for FShaderValueType::bIsDynamicArray");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FShaderParamTypeDefinition
{
    FString TypeDeclaration; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Name; // 0x10 (Size: 0x10, Type: StrProperty)
    FShaderValueTypeHandle ValueType; // 0x20 (Size: 0x8, Type: StructProperty)
    uint16_t ArrayElementCount; // 0x28 (Size: 0x2, Type: UInt16Property)
    uint8_t BindingType; // 0x2a (Size: 0x1, Type: EnumProperty)
    uint8_t ResourceType; // 0x2b (Size: 0x1, Type: EnumProperty)
    uint8_t Modifier; // 0x2c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FShaderParamTypeDefinition) == 0x30, "Size mismatch for FShaderParamTypeDefinition");
static_assert(offsetof(FShaderParamTypeDefinition, TypeDeclaration) == 0x0, "Offset mismatch for FShaderParamTypeDefinition::TypeDeclaration");
static_assert(offsetof(FShaderParamTypeDefinition, Name) == 0x10, "Offset mismatch for FShaderParamTypeDefinition::Name");
static_assert(offsetof(FShaderParamTypeDefinition, ValueType) == 0x20, "Offset mismatch for FShaderParamTypeDefinition::ValueType");
static_assert(offsetof(FShaderParamTypeDefinition, ArrayElementCount) == 0x28, "Offset mismatch for FShaderParamTypeDefinition::ArrayElementCount");
static_assert(offsetof(FShaderParamTypeDefinition, BindingType) == 0x2a, "Offset mismatch for FShaderParamTypeDefinition::BindingType");
static_assert(offsetof(FShaderParamTypeDefinition, ResourceType) == 0x2b, "Offset mismatch for FShaderParamTypeDefinition::ResourceType");
static_assert(offsetof(FShaderParamTypeDefinition, Modifier) == 0x2c, "Offset mismatch for FShaderParamTypeDefinition::Modifier");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FShaderFunctionDefinition
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    TArray<FShaderParamTypeDefinition> ParamTypes; // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bHasReturnType; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FShaderFunctionDefinition) == 0x28, "Size mismatch for FShaderFunctionDefinition");
static_assert(offsetof(FShaderFunctionDefinition, Name) == 0x0, "Offset mismatch for FShaderFunctionDefinition::Name");
static_assert(offsetof(FShaderFunctionDefinition, ParamTypes) == 0x10, "Offset mismatch for FShaderFunctionDefinition::ParamTypes");
static_assert(offsetof(FShaderFunctionDefinition, bHasReturnType) == 0x20, "Offset mismatch for FShaderFunctionDefinition::bHasReturnType");

