/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DiscoverBrowserAnalyticsFunctions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"
#include "UMG.h"
#include "FortniteUI.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDiscoverBrowserAnalyticsFunctions_C : public UBlueprintFunctionLibrary
{
public:

public:
    static void GetWidgetAbsoluteRect(UWidget*& Widget, UObject*& __WorldContext, FVector2D& TopLeft, FVector2D& BottomRight, FVector2D& Size, FString& DebugStringOutput); // 0x288a61c (Index: 0x0, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    static void ComputeRowVisibility(UListView*& ListView, UFortDiscoverProviderViewModel*& Provider_VM, FVector2D& TopLeft, FVector2D& BottomRight, UObject*& __WorldContext); // 0x288a61c (Index: 0x1, Flags: Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    static void ComputeItemVisibility(UWidget*& Widget, FVector2D& TopLeft, FVector2D& BottomRight, UObject*& __WorldContext, bool& Visible); // 0x288a61c (Index: 0x2, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UDiscoverBrowserAnalyticsFunctions_C) == 0x28, "Size mismatch for UDiscoverBrowserAnalyticsFunctions_C");

