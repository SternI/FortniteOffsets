/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortLevelInjectingRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "ModularGameplay.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "AIModule.h"
#include "GameplayAbilities.h"
#include "TargetingSystem.h"

// Size: 0x200 (Inherited: 0x338, Single: 0xfffffec8)
class UFortDynamicPOIInjectionManager : public UFortLevelInjectionManager
{
public:
    FScalableFloat LevelRevealDuration; // 0xe8 (Size: 0x28, Type: StructProperty)
    FScalableFloat LevelPreInjectionDuration; // 0x110 (Size: 0x28, Type: StructProperty)
    FScalableFloat TeleportLocationUpOffset; // 0x138 (Size: 0x28, Type: StructProperty)
    UDataTable* LocationMetadataTable; // 0x160 (Size: 0x8, Type: ObjectProperty)
    FVector GeoOffsetFromSpawnPoint; // 0x168 (Size: 0x18, Type: StructProperty)
    UTargetingPreset* ObstaclePreset; // 0x180 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_188[0x18]; // 0x188 (Size: 0x18, Type: PaddingProperty)
    FTransform ChosenInjectTransform; // 0x1a0 (Size: 0x60, Type: StructProperty)

private:
    void OnRep_ChosenInjectTransform(); // 0x100e2a1c (Index: 0xa, Flags: Final|Native|Private)

protected:
    virtual void BP_OnLevelBecameVisibleOnClient(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnLevelPreInjectionFinished(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnLevelPreInjectionStarted(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnLevelRevealStarted(const FTransform InjectionTransform); // 0x288a61c (Index: 0x3, Flags: Event|Protected|HasOutParms|HasDefaults|BlueprintEvent)
    virtual void BP_OnPawnFinishedTeleportingFromInjectionLocation(AFortPawn*& FortPawn); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnPawnStartedTeleportingAwayFromInjectionLocation(AFortPawn*& FortPawn); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    FTransform GetChosenInjectTransform() const; // 0x100e16f0 (Index: 0x6, Flags: Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTransform GetTrueLevelTransform() const; // 0x100e1748 (Index: 0x7, Flags: Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    virtual void HandleInjectionObstacles(TArray<FHitResult>& Hits, const FVector SpawnLocation, float& RadiusOfInfluence); // 0x100e17c4 (Index: 0x8, Flags: Native|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent)
    void OnPawnFinishedTeleportingFromInjectionLocation(AFortPawn*& FortPawn); // 0x100e241c (Index: 0x9, Flags: Final|Native|Protected)
    void RemoveInjectionObstacles(const FVector SpawnLocation, float& RadiusOfInfluence); // 0x100e2c18 (Index: 0xb, Flags: Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UFortDynamicPOIInjectionManager) == 0x200, "Size mismatch for UFortDynamicPOIInjectionManager");
static_assert(offsetof(UFortDynamicPOIInjectionManager, LevelRevealDuration) == 0xe8, "Offset mismatch for UFortDynamicPOIInjectionManager::LevelRevealDuration");
static_assert(offsetof(UFortDynamicPOIInjectionManager, LevelPreInjectionDuration) == 0x110, "Offset mismatch for UFortDynamicPOIInjectionManager::LevelPreInjectionDuration");
static_assert(offsetof(UFortDynamicPOIInjectionManager, TeleportLocationUpOffset) == 0x138, "Offset mismatch for UFortDynamicPOIInjectionManager::TeleportLocationUpOffset");
static_assert(offsetof(UFortDynamicPOIInjectionManager, LocationMetadataTable) == 0x160, "Offset mismatch for UFortDynamicPOIInjectionManager::LocationMetadataTable");
static_assert(offsetof(UFortDynamicPOIInjectionManager, GeoOffsetFromSpawnPoint) == 0x168, "Offset mismatch for UFortDynamicPOIInjectionManager::GeoOffsetFromSpawnPoint");
static_assert(offsetof(UFortDynamicPOIInjectionManager, ObstaclePreset) == 0x180, "Offset mismatch for UFortDynamicPOIInjectionManager::ObstaclePreset");
static_assert(offsetof(UFortDynamicPOIInjectionManager, ChosenInjectTransform) == 0x1a0, "Offset mismatch for UFortDynamicPOIInjectionManager::ChosenInjectTransform");

// Size: 0xe8 (Inherited: 0x250, Single: 0xfffffe98)
class UFortLevelInjectionManager : public UGameStateComponent
{
public:
    UFortLevelInjectionData* InjectionData; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    TArray<FFortLevelInjectionRuntimeData> InjectedLevels; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    int32_t EQSHandle; // 0xd0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_d4[0xc]; // 0xd4 (Size: 0xc, Type: PaddingProperty)
    bool bPendingRequest; // 0xe0 (Size: 0x1, Type: BoolProperty)
    bool bReadyToInject; // 0xe1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e2[0x6]; // 0xe2 (Size: 0x6, Type: PaddingProperty)

private:
    void OnPlaylistDataReady(AFortGameStateAthena*& GameState, UFortPlaylist*& const Playlist, const FGameplayTagContainer PlaylistContextTags); // 0x100e2548 (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
    void OnRep_InjectedLevels(TArray<FFortLevelInjectionRuntimeData>& PreviousInjectedLevels); // 0x40d9244 (Index: 0x1, Flags: Final|Native|Private)

protected:
    void RemoveLevelInjection(); // 0x100e2d94 (Index: 0x2, Flags: Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable)
    void RequestLevelInjection(); // 0x100e2da8 (Index: 0x3, Flags: Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortLevelInjectionManager) == 0xe8, "Size mismatch for UFortLevelInjectionManager");
static_assert(offsetof(UFortLevelInjectionManager, InjectionData) == 0xb8, "Offset mismatch for UFortLevelInjectionManager::InjectionData");
static_assert(offsetof(UFortLevelInjectionManager, InjectedLevels) == 0xc0, "Offset mismatch for UFortLevelInjectionManager::InjectedLevels");
static_assert(offsetof(UFortLevelInjectionManager, EQSHandle) == 0xd0, "Offset mismatch for UFortLevelInjectionManager::EQSHandle");
static_assert(offsetof(UFortLevelInjectionManager, bPendingRequest) == 0xe0, "Offset mismatch for UFortLevelInjectionManager::bPendingRequest");
static_assert(offsetof(UFortLevelInjectionManager, bReadyToInject) == 0xe1, "Offset mismatch for UFortLevelInjectionManager::bReadyToInject");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UFortLevelInjectionCheatManager : public UChildCheatManager
{
public:

private:
    void InjectLevel(FString& FeatureName, float& LocalXOffset, float& LocalYOffset, float& GlobalZOffset); // 0x100e1b94 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Private)
    void InjectLevelInClosestLocation(FString& FeatureName); // 0x100e2128 (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Private)
    void TriggerLevelInjectionRequest(FString& FeatureName); // 0x100e320c (Index: 0x2, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Private)
};

static_assert(sizeof(UFortLevelInjectionCheatManager) == 0x28, "Size mismatch for UFortLevelInjectionCheatManager");

// Size: 0x828 (Inherited: 0x11f0, Single: 0xfffff638)
class AFortLevelInjectionLocation : public ABuildingLevelInstance
{
public:
    FGameplayTagContainer InstanceTags; // 0x7d8 (Size: 0x20, Type: StructProperty)
    FDataTableRowHandle LocationMetadata; // 0x7f8 (Size: 0x10, Type: StructProperty)
    TSoftObjectPtr<UWorld*> NoWorldAsset; // 0x808 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(AFortLevelInjectionLocation) == 0x828, "Size mismatch for AFortLevelInjectionLocation");
static_assert(offsetof(AFortLevelInjectionLocation, InstanceTags) == 0x7d8, "Offset mismatch for AFortLevelInjectionLocation::InstanceTags");
static_assert(offsetof(AFortLevelInjectionLocation, LocationMetadata) == 0x7f8, "Offset mismatch for AFortLevelInjectionLocation::LocationMetadata");
static_assert(offsetof(AFortLevelInjectionLocation, NoWorldAsset) == 0x808, "Offset mismatch for AFortLevelInjectionLocation::NoWorldAsset");

// Size: 0x100 (Inherited: 0x128, Single: 0xffffffd8)
class UFortLevelInjectionData : public UFortLevelInjectionDataBase
{
public:
    UEnvQuery* LimitedInjectableLocationsEQS; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat InjectableLocationsLimit; // 0xd8 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UFortLevelInjectionData) == 0x100, "Size mismatch for UFortLevelInjectionData");
static_assert(offsetof(UFortLevelInjectionData, LimitedInjectableLocationsEQS) == 0xd0, "Offset mismatch for UFortLevelInjectionData::LimitedInjectableLocationsEQS");
static_assert(offsetof(UFortLevelInjectionData, InjectableLocationsLimit) == 0xd8, "Offset mismatch for UFortLevelInjectionData::InjectableLocationsLimit");

// Size: 0xd0 (Inherited: 0x58, Single: 0x78)
class UFortLevelInjectionDataBase : public UDataAsset
{
public:
    FFortLevelInjectionWorldAssetData BaseLevelAssetData; // 0x30 (Size: 0x28, Type: StructProperty)
    TArray<FFortLevelInjectionWorldAssetData> HLODData; // 0x58 (Size: 0x10, Type: ArrayProperty)
    FVector BoundsExtent; // 0x68 (Size: 0x18, Type: StructProperty)
    FString InjectedLevelCellSuffix; // 0x80 (Size: 0x10, Type: StrProperty)
    int32_t InjectionRequestPriority; // 0x90 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
    FScalableFloat Enabled; // 0x98 (Size: 0x28, Type: StructProperty)
    FString DebugName; // 0xc0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(UFortLevelInjectionDataBase) == 0xd0, "Size mismatch for UFortLevelInjectionDataBase");
static_assert(offsetof(UFortLevelInjectionDataBase, BaseLevelAssetData) == 0x30, "Offset mismatch for UFortLevelInjectionDataBase::BaseLevelAssetData");
static_assert(offsetof(UFortLevelInjectionDataBase, HLODData) == 0x58, "Offset mismatch for UFortLevelInjectionDataBase::HLODData");
static_assert(offsetof(UFortLevelInjectionDataBase, BoundsExtent) == 0x68, "Offset mismatch for UFortLevelInjectionDataBase::BoundsExtent");
static_assert(offsetof(UFortLevelInjectionDataBase, InjectedLevelCellSuffix) == 0x80, "Offset mismatch for UFortLevelInjectionDataBase::InjectedLevelCellSuffix");
static_assert(offsetof(UFortLevelInjectionDataBase, InjectionRequestPriority) == 0x90, "Offset mismatch for UFortLevelInjectionDataBase::InjectionRequestPriority");
static_assert(offsetof(UFortLevelInjectionDataBase, Enabled) == 0x98, "Offset mismatch for UFortLevelInjectionDataBase::Enabled");
static_assert(offsetof(UFortLevelInjectionDataBase, DebugName) == 0xc0, "Offset mismatch for UFortLevelInjectionDataBase::DebugName");

// Size: 0xc8 (Inherited: 0x250, Single: 0xfffffe78)
class UFortLevelInjectionManagerBase : public UGameStateComponent
{
public:
    TArray<FFortLevelInjectionRuntimeDataBase> InjectedLevels; // 0xb8 (Size: 0x10, Type: ArrayProperty)

public:
    void RequestToInjectLevel(TSoftObjectPtr<UFortLevelInjectionDataBase*>& LevelInjectionData, FTransform& const LevelTransform); // 0x100e2dbc (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasDefaults|BlueprintCallable)

protected:
    void OnRep_InjectedLevels(TArray<FFortLevelInjectionRuntimeDataBase>& PreviousInjectedLevels); // 0x100e2a7c (Index: 0x0, Flags: Native|Protected)
};

static_assert(sizeof(UFortLevelInjectionManagerBase) == 0xc8, "Size mismatch for UFortLevelInjectionManagerBase");
static_assert(offsetof(UFortLevelInjectionManagerBase, InjectedLevels) == 0xb8, "Offset mismatch for UFortLevelInjectionManagerBase::InjectedLevels");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FFortLevelInjectionLocationMetadata : FTableRowBase
{
    bool bEnabled; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortLevelInjectionLocationMetadata) == 0x10, "Size mismatch for FFortLevelInjectionLocationMetadata");
static_assert(offsetof(FFortLevelInjectionLocationMetadata, bEnabled) == 0x8, "Offset mismatch for FFortLevelInjectionLocationMetadata::bEnabled");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FFortLevelInjectionRuntimeData
{
    FGuid LevelGUID; // 0x0 (Size: 0x10, Type: StructProperty)
    FTransform LevelTransform; // 0x10 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FFortLevelInjectionRuntimeData) == 0x70, "Size mismatch for FFortLevelInjectionRuntimeData");
static_assert(offsetof(FFortLevelInjectionRuntimeData, LevelGUID) == 0x0, "Offset mismatch for FFortLevelInjectionRuntimeData::LevelGUID");
static_assert(offsetof(FFortLevelInjectionRuntimeData, LevelTransform) == 0x10, "Offset mismatch for FFortLevelInjectionRuntimeData::LevelTransform");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFortLevelInjectionWorldAssetData
{
    TSoftObjectPtr<UWorld*> WorldAsset; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FName TargetGridName; // 0x20 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortLevelInjectionWorldAssetData) == 0x28, "Size mismatch for FFortLevelInjectionWorldAssetData");
static_assert(offsetof(FFortLevelInjectionWorldAssetData, WorldAsset) == 0x0, "Offset mismatch for FFortLevelInjectionWorldAssetData::WorldAsset");
static_assert(offsetof(FFortLevelInjectionWorldAssetData, TargetGridName) == 0x20, "Offset mismatch for FFortLevelInjectionWorldAssetData::TargetGridName");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FFortLevelInjectionRuntimeDataBase
{
    TSoftObjectPtr<UFortLevelInjectionDataBase*> InjectionData; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FGuid LevelGUID; // 0x20 (Size: 0x10, Type: StructProperty)
    FTransform LevelTransform; // 0x30 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FFortLevelInjectionRuntimeDataBase) == 0x90, "Size mismatch for FFortLevelInjectionRuntimeDataBase");
static_assert(offsetof(FFortLevelInjectionRuntimeDataBase, InjectionData) == 0x0, "Offset mismatch for FFortLevelInjectionRuntimeDataBase::InjectionData");
static_assert(offsetof(FFortLevelInjectionRuntimeDataBase, LevelGUID) == 0x20, "Offset mismatch for FFortLevelInjectionRuntimeDataBase::LevelGUID");
static_assert(offsetof(FFortLevelInjectionRuntimeDataBase, LevelTransform) == 0x30, "Offset mismatch for FFortLevelInjectionRuntimeDataBase::LevelTransform");

