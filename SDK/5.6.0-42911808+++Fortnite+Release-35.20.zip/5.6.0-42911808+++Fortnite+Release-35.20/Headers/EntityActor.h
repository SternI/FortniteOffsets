/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EntityActor
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "EntityCore.h"
#include "Engine.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEntityAbilityInterface : public UInterface
{
public:
};

static_assert(sizeof(UEntityAbilityInterface) == 0x28, "Size mismatch for UEntityAbilityInterface");

// Size: 0x60 (Inherited: 0x80, Single: 0xffffffe0)
class UEntityActorCustomReplicationComponent : public UEntityComponent
{
public:
    TEnumAsByte<EEntityActorReplicationOverrideType> ReplicationOverride; // 0x58 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEntityActorReplicationRelevancyBucketType> ReplicationRelevancyBucketType; // 0x59 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_5a[0x2]; // 0x5a (Size: 0x2, Type: PaddingProperty)
    float CustomReplicationRelevancyRange; // 0x5c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UEntityActorCustomReplicationComponent) == 0x60, "Size mismatch for UEntityActorCustomReplicationComponent");
static_assert(offsetof(UEntityActorCustomReplicationComponent, ReplicationOverride) == 0x58, "Offset mismatch for UEntityActorCustomReplicationComponent::ReplicationOverride");
static_assert(offsetof(UEntityActorCustomReplicationComponent, ReplicationRelevancyBucketType) == 0x59, "Offset mismatch for UEntityActorCustomReplicationComponent::ReplicationRelevancyBucketType");
static_assert(offsetof(UEntityActorCustomReplicationComponent, CustomReplicationRelevancyRange) == 0x5c, "Offset mismatch for UEntityActorCustomReplicationComponent::CustomReplicationRelevancyRange");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class ASimObject : public AActor
{
public:
};

static_assert(sizeof(ASimObject) == 0x2b0, "Size mismatch for ASimObject");

// Size: 0xd8 (Inherited: 0xe0, Single: 0xfffffff8)
class UActorToEntityAdapterComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    TArray<UEntityComponent*> SerializedComponents; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    uint8_t bForceOwnerReplication : 1; // 0xd0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d1[0x7]; // 0xd1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UActorToEntityAdapterComponent) == 0xd8, "Size mismatch for UActorToEntityAdapterComponent");
static_assert(offsetof(UActorToEntityAdapterComponent, SerializedComponents) == 0xc0, "Offset mismatch for UActorToEntityAdapterComponent::SerializedComponents");
static_assert(offsetof(UActorToEntityAdapterComponent, bForceOwnerReplication) == 0xd0, "Offset mismatch for UActorToEntityAdapterComponent::bForceOwnerReplication");

// Size: 0x88 (Inherited: 0x80, Single: 0x8)
class UEntityActorComponent : public UEntityComponent
{
public:
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
    UActorComponent* ActorComponent; // 0x60 (Size: 0x8, Type: ObjectProperty)
    bool bCreatedActorComponent; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x1f]; // 0x69 (Size: 0x1f, Type: PaddingProperty)

private:
    void OnRep_ActorComponent(); // 0x4b4be24 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UEntityActorComponent) == 0x88, "Size mismatch for UEntityActorComponent");
static_assert(offsetof(UEntityActorComponent, ActorComponent) == 0x60, "Offset mismatch for UEntityActorComponent::ActorComponent");
static_assert(offsetof(UEntityActorComponent, bCreatedActorComponent) == 0x68, "Offset mismatch for UEntityActorComponent::bCreatedActorComponent");

// Size: 0x68 (Inherited: 0x88, Single: 0xffffffe0)
class UEntityActorSubsystem : public UWorldSubsystem
{
public:
};

static_assert(sizeof(UEntityActorSubsystem) == 0x68, "Size mismatch for UEntityActorSubsystem");

// Size: 0xb0 (Inherited: 0xf8, Single: 0xffffffb8)
class UEntityDynamicActivationComponent : public UEntityEnableableComponent
{
public:
    uint8_t Pad_78[0x8]; // 0x78 (Size: 0x8, Type: PaddingProperty)
    float TransitionTargetTime; // 0x80 (Size: 0x4, Type: FloatProperty)
    bool bTargetState; // 0x84 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_85[0x3]; // 0x85 (Size: 0x3, Type: PaddingProperty)
    TArray<UEntityComponent*> LinkedComponents; // 0x88 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_98[0x18]; // 0x98 (Size: 0x18, Type: PaddingProperty)

public:
    void OnEnabledChanged(bool& bIsEnabled); // 0xb862530 (Index: 0x0, Flags: Final|Native|Public)

private:
    void OnRep_TransitionTarget(); // 0xb86343c (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UEntityDynamicActivationComponent) == 0xb0, "Size mismatch for UEntityDynamicActivationComponent");
static_assert(offsetof(UEntityDynamicActivationComponent, TransitionTargetTime) == 0x80, "Offset mismatch for UEntityDynamicActivationComponent::TransitionTargetTime");
static_assert(offsetof(UEntityDynamicActivationComponent, bTargetState) == 0x84, "Offset mismatch for UEntityDynamicActivationComponent::bTargetState");
static_assert(offsetof(UEntityDynamicActivationComponent, LinkedComponents) == 0x88, "Offset mismatch for UEntityDynamicActivationComponent::LinkedComponents");

// Size: 0x60 (Inherited: 0x80, Single: 0xffffffe0)
class UEntityToActorAdapterComponent : public UEntityComponent
{
public:
};

static_assert(sizeof(UEntityToActorAdapterComponent) == 0x60, "Size mismatch for UEntityToActorAdapterComponent");

// Size: 0x60 (Inherited: 0x80, Single: 0xffffffe0)
class UEntityActorLocalInputComponent : public UEntityComponent
{
public:
    TEnumAsByte<EAutoReceiveInput> AutoReceiveControllerInput; // 0x58 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UEntityActorLocalInputComponent) == 0x60, "Size mismatch for UEntityActorLocalInputComponent");
static_assert(offsetof(UEntityActorLocalInputComponent, AutoReceiveControllerInput) == 0x58, "Offset mismatch for UEntityActorLocalInputComponent::AutoReceiveControllerInput");

// Size: 0xf0 (Inherited: 0xf8, Single: 0xfffffff8)
class UEntityActorCollisionComponent : public UEntityEnableableComponent
{
public:
    uint8_t Pad_78[0x48]; // 0x78 (Size: 0x48, Type: PaddingProperty)
    FName ShadowVar_CollisionProfileName; // 0xc0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c4[0x4]; // 0xc4 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UPrimitiveComponent*> PrimitiveComponentCache; // 0xc8 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t Pad_e8[0x2]; // 0xe8 (Size: 0x2, Type: PaddingProperty)
    TEnumAsByte<ECollisionShapeMode> CollisionShapeMode; // 0xea (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_eb[0x5]; // 0xeb (Size: 0x5, Type: PaddingProperty)

private:
    void OnEnabledChanged(bool& bIsEnabled); // 0xb862404 (Index: 0x0, Flags: Final|Native|Private)
    void OnNativeComponentBeginOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult SweepResult); // 0xb86265c (Index: 0x1, Flags: Final|Native|Private|HasOutParms)
    void OnNativeComponentEndOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex); // 0xb862bbc (Index: 0x2, Flags: Final|Native|Private)
    void OnNativeComponentHit(UPrimitiveComponent*& HitComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, FVector& NormalImpulse, const FHitResult Hit); // 0xb862f74 (Index: 0x3, Flags: Final|Native|Private|HasOutParms|HasDefaults)
    void OnRep_CollisionProfileName(); // 0xb86339c (Index: 0x4, Flags: Final|Native|Private)
    void OnRep_PrimitiveComponent(); // 0xb86339c (Index: 0x5, Flags: Final|Native|Private)
};

static_assert(sizeof(UEntityActorCollisionComponent) == 0xf0, "Size mismatch for UEntityActorCollisionComponent");
static_assert(offsetof(UEntityActorCollisionComponent, ShadowVar_CollisionProfileName) == 0xc0, "Offset mismatch for UEntityActorCollisionComponent::ShadowVar_CollisionProfileName");
static_assert(offsetof(UEntityActorCollisionComponent, PrimitiveComponentCache) == 0xc8, "Offset mismatch for UEntityActorCollisionComponent::PrimitiveComponentCache");
static_assert(offsetof(UEntityActorCollisionComponent, CollisionShapeMode) == 0xea, "Offset mismatch for UEntityActorCollisionComponent::CollisionShapeMode");

// Size: 0xd0 (Inherited: 0xe0, Single: 0xfffffff0)
class UEntityActorPlayerComponent : public UEntityDataBackedComponent
{
public:
    FUniqueNetIdRepl PlayerId; // 0x60 (Size: 0x30, Type: StructProperty)
    TSoftObjectPtr<APlayerController*> PlayerControllerCache; // 0x90 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<APlayerState*> PlayerStateCache; // 0xb0 (Size: 0x20, Type: SoftObjectProperty)

protected:
    void OnRep_PlayerId(); // 0x4b4be24 (Index: 0x0, Flags: Native|Protected)
};

static_assert(sizeof(UEntityActorPlayerComponent) == 0xd0, "Size mismatch for UEntityActorPlayerComponent");
static_assert(offsetof(UEntityActorPlayerComponent, PlayerId) == 0x60, "Offset mismatch for UEntityActorPlayerComponent::PlayerId");
static_assert(offsetof(UEntityActorPlayerComponent, PlayerControllerCache) == 0x90, "Offset mismatch for UEntityActorPlayerComponent::PlayerControllerCache");
static_assert(offsetof(UEntityActorPlayerComponent, PlayerStateCache) == 0xb0, "Offset mismatch for UEntityActorPlayerComponent::PlayerStateCache");

// Size: 0x78 (Inherited: 0x80, Single: 0xfffffff8)
class UEntityActorSkeletalMeshRenderComponent : public UEntityComponent
{
public:
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
    bool bAddedMeshRenderComponent; // 0x60 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_61[0x7]; // 0x61 (Size: 0x7, Type: PaddingProperty)
    USkeletalMesh* ShadowVar_SkeletalMesh; // 0x68 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<ECollisionEnabled> ShadowVar_EnableCollision; // 0x70 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UEntityActorSkeletalMeshRenderComponent) == 0x78, "Size mismatch for UEntityActorSkeletalMeshRenderComponent");
static_assert(offsetof(UEntityActorSkeletalMeshRenderComponent, bAddedMeshRenderComponent) == 0x60, "Offset mismatch for UEntityActorSkeletalMeshRenderComponent::bAddedMeshRenderComponent");
static_assert(offsetof(UEntityActorSkeletalMeshRenderComponent, ShadowVar_SkeletalMesh) == 0x68, "Offset mismatch for UEntityActorSkeletalMeshRenderComponent::ShadowVar_SkeletalMesh");
static_assert(offsetof(UEntityActorSkeletalMeshRenderComponent, ShadowVar_EnableCollision) == 0x70, "Offset mismatch for UEntityActorSkeletalMeshRenderComponent::ShadowVar_EnableCollision");

// Size: 0xa0 (Inherited: 0x108, Single: 0xffffff98)
class UEntityActorStaticMeshRenderComponent : public UEntityActorComponent
{
public:
    TArray<UMaterialInterface*> ShadowVar_MeshMaterials; // 0x88 (Size: 0x10, Type: ArrayProperty)
    TEnumAsByte<ECollisionEnabled> ShadowVar_EnableCollision; // 0x98 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_99[0x3]; // 0x99 (Size: 0x3, Type: PaddingProperty)
    float ShadowVar_MaxDrawDistance; // 0x9c (Size: 0x4, Type: FloatProperty)

private:
    void OnRep_EnableCollision(); // 0xb8633e0 (Index: 0x0, Flags: Final|Native|Private)
    void OnRep_MaxDrawDistance(); // 0xb8633f4 (Index: 0x1, Flags: Final|Native|Private)
    void OnRep_MeshMaterials(); // 0xb863410 (Index: 0x2, Flags: Final|Native|Private)
};

static_assert(sizeof(UEntityActorStaticMeshRenderComponent) == 0xa0, "Size mismatch for UEntityActorStaticMeshRenderComponent");
static_assert(offsetof(UEntityActorStaticMeshRenderComponent, ShadowVar_MeshMaterials) == 0x88, "Offset mismatch for UEntityActorStaticMeshRenderComponent::ShadowVar_MeshMaterials");
static_assert(offsetof(UEntityActorStaticMeshRenderComponent, ShadowVar_EnableCollision) == 0x98, "Offset mismatch for UEntityActorStaticMeshRenderComponent::ShadowVar_EnableCollision");
static_assert(offsetof(UEntityActorStaticMeshRenderComponent, ShadowVar_MaxDrawDistance) == 0x9c, "Offset mismatch for UEntityActorStaticMeshRenderComponent::ShadowVar_MaxDrawDistance");

// Size: 0xa8 (Inherited: 0x108, Single: 0xffffffa0)
class UEntityActorTextDisplayComponent : public UEntityActorComponent
{
public:
    FText DisplayText; // 0x88 (Size: 0x10, Type: TextProperty)
    float ShadowVar_WorldSize; // 0x98 (Size: 0x4, Type: FloatProperty)
    FColor ShadowVar_TextRenderColor; // 0x9c (Size: 0x4, Type: StructProperty)
    bool bAddedTextRenderComponent; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0x7]; // 0xa1 (Size: 0x7, Type: PaddingProperty)

public:
    TEnumAsByte<EHorizTextAligment> GetHorizontalAlignment(); // 0xb862248 (Index: 0x0, Flags: Final|Native|Public)
    FVector GetRelativeLocation(); // 0xb862284 (Index: 0x1, Flags: Final|Native|Public|HasDefaults)
    FText GetText() const; // 0xb8622d4 (Index: 0x2, Flags: Final|Native|Public|Const)
    FColor GetTextRenderColor() const; // 0xb86233c (Index: 0x3, Flags: Final|Native|Public|HasDefaults|Const)
    TEnumAsByte<EVerticalTextAligment> GetVerticalAlignment(); // 0xb862380 (Index: 0x4, Flags: Final|Native|Public)
    float GetWorldSize() const; // 0xb8623bc (Index: 0x5, Flags: Final|Native|Public|Const)
    void SetHorizontalAlignment(TEnumAsByte<EHorizTextAligment>& Value); // 0xb863a90 (Index: 0x9, Flags: Final|Native|Public)
    void SetRelativeLocation(FVector& RelativeLocation); // 0xb863be0 (Index: 0xa, Flags: Final|Native|Public|HasDefaults)
    void SetRelativeRotation(FRotator& RelativeRotation); // 0xb863cb4 (Index: 0xb, Flags: Final|Native|Public|HasDefaults)
    void SetRelativeScale(FVector& RelativeScale); // 0xb863dcc (Index: 0xc, Flags: Final|Native|Public|HasDefaults)
    void SetText(FText& Text); // 0xb863ed0 (Index: 0xd, Flags: Final|Native|Public)
    void SetTextRenderColor(FColor& Value); // 0xb864018 (Index: 0xe, Flags: Final|Native|Public|HasDefaults)
    void SetVerticalAlignment(TEnumAsByte<EVerticalTextAligment>& Value); // 0xb8640d4 (Index: 0xf, Flags: Final|Native|Public)
    void SetWorldSize(float& Value); // 0xb864224 (Index: 0x10, Flags: Final|Native|Public)

private:
    void OnRep_DisplayText(); // 0xb8633cc (Index: 0x6, Flags: Final|Native|Private)
    void OnRep_TextRenderColor(); // 0xb863424 (Index: 0x7, Flags: Final|Native|Private)
    void OnRep_WorldSize(); // 0xb863450 (Index: 0x8, Flags: Final|Native|Private)
};

static_assert(sizeof(UEntityActorTextDisplayComponent) == 0xa8, "Size mismatch for UEntityActorTextDisplayComponent");
static_assert(offsetof(UEntityActorTextDisplayComponent, DisplayText) == 0x88, "Offset mismatch for UEntityActorTextDisplayComponent::DisplayText");
static_assert(offsetof(UEntityActorTextDisplayComponent, ShadowVar_WorldSize) == 0x98, "Offset mismatch for UEntityActorTextDisplayComponent::ShadowVar_WorldSize");
static_assert(offsetof(UEntityActorTextDisplayComponent, ShadowVar_TextRenderColor) == 0x9c, "Offset mismatch for UEntityActorTextDisplayComponent::ShadowVar_TextRenderColor");
static_assert(offsetof(UEntityActorTextDisplayComponent, bAddedTextRenderComponent) == 0xa0, "Offset mismatch for UEntityActorTextDisplayComponent::bAddedTextRenderComponent");

// Size: 0x80 (Inherited: 0x140, Single: 0xffffff40)
class UEntityActorPositionComponent : public UEntityPositionComponent
{
public:
    FVector ShadowVar_Location; // 0x60 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_78[0x8]; // 0x78 (Size: 0x8, Type: PaddingProperty)

private:
    void OnRootComponentChanged(USceneComponent*& InRootComponent, bool& bIsRootComponent); // 0xb86346c (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UEntityActorPositionComponent) == 0x80, "Size mismatch for UEntityActorPositionComponent");
static_assert(offsetof(UEntityActorPositionComponent, ShadowVar_Location) == 0x60, "Offset mismatch for UEntityActorPositionComponent::ShadowVar_Location");

// Size: 0x88 (Inherited: 0x140, Single: 0xffffff48)
class UEntityActorRotationComponent : public UEntityRotationComponent
{
public:
    FRotator ShadowVar_Rotation; // 0x60 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_78[0x10]; // 0x78 (Size: 0x10, Type: PaddingProperty)

private:
    void OnRootComponentChanged(USceneComponent*& InRootComponent, bool& bIsRootComponent); // 0xb863678 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UEntityActorRotationComponent) == 0x88, "Size mismatch for UEntityActorRotationComponent");
static_assert(offsetof(UEntityActorRotationComponent, ShadowVar_Rotation) == 0x60, "Offset mismatch for UEntityActorRotationComponent::ShadowVar_Rotation");

// Size: 0x80 (Inherited: 0x140, Single: 0xffffff40)
class UEntityActorScaleComponent : public UEntityScaleComponent
{
public:
    FVector ShadowVar_Scale; // 0x60 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_78[0x8]; // 0x78 (Size: 0x8, Type: PaddingProperty)

private:
    void OnRootComponentChanged(USceneComponent*& InRootComponent, bool& bIsRootComponent); // 0xb863884 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UEntityActorScaleComponent) == 0x80, "Size mismatch for UEntityActorScaleComponent");
static_assert(offsetof(UEntityActorScaleComponent, ShadowVar_Scale) == 0x60, "Offset mismatch for UEntityActorScaleComponent::ShadowVar_Scale");

