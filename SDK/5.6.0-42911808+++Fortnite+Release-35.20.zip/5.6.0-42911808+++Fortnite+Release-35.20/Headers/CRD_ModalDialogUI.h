/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_ModalDialogUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "ModelViewViewModel.h"
#include "CommonUI.h"
#include "UMG.h"
#include "SlateCore.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCreativeModalDialogAllowedConversionFunction : public UBlueprintFunctionLibrary
{
public:

public:
    static ECreativeModalDialogViewmodelResponse GetResponseButton1(FWidgetEventField& Field); // 0x11a9beb8 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static ECreativeModalDialogViewmodelResponse GetResponseButton2(FWidgetEventField& Field); // 0x11a9bf6c (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static ECreativeModalDialogViewmodelResponse GetResponseButton3(FWidgetEventField& Field); // 0x11a9c020 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static ECreativeModalDialogViewmodelResponse GetResponseButton4(FWidgetEventField& Field); // 0x11a9c0d4 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static ECreativeModalDialogViewmodelResponse GetResponseButton5(FWidgetEventField& Field); // 0x11a9c188 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static ECreativeModalDialogViewmodelResponse GetResponseButton6(FWidgetEventField& Field); // 0x11a9c23c (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static ECreativeModalDialogViewmodelResponse GetResponseNone(FWidgetEventField& Field); // 0x11a9c2f0 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UCreativeModalDialogAllowedConversionFunction) == 0x28, "Size mismatch for UCreativeModalDialogAllowedConversionFunction");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UCreativeModalDialogConversionFunction : public UCreativeModalDialogAllowedConversionFunction
{
public:

public:
    static ECreativeModalDialogViewmodelResponse AssignCreativeModalDialogViewmodelResponse(FMVVMEventField& Field, ECreativeModalDialogViewmodelResponse& Response); // 0x11a9adc4 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetColumnIndexForButtonFromContentAlignment(ECreativeModalDialogAlignmentOption& const AlignmentOption, int32_t& const ButtonIndex, int32_t& const WideMaxColumns, int32_t& const TallMaxColumns, int32_t& const DefaultMaxColumns); // 0x11a9b120 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static float GetFloatingValueFromContentAlignment(ECreativeModalDialogAlignmentOption& const AlignmentOption, float& const TallValue, float& const WideValue, float& const CenteredFullValue, float& const DefaultValue); // 0x11a9b570 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FMargin GetMarginFromContentAlignment(ECreativeModalDialogAlignmentOption& const AlignmentOption, float& const TallMarginAmount, float& const WideMarginAmount, float& const CenteredFullMarginAmount, float& const DefaultMarginAmount); // 0x11a9ba58 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetRowIndexForButtonFromContentAlignment(ECreativeModalDialogAlignmentOption& const AlignmentOption, int32_t& const ButtonIndex, int32_t& const WideMaxColumns, int32_t& const TallMaxColumns, int32_t& const DefaultMaxColumns); // 0x11a9c398 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static ECreativeModalDialogViewmodelResponse TranslateResponse(FWidgetEventField& Field, ECreativeModalDialogViewmodelResponse& Response); // 0x11a9adc4 (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UCreativeModalDialogConversionFunction) == 0x28, "Size mismatch for UCreativeModalDialogConversionFunction");

// Size: 0x1a8 (Inherited: 0x90, Single: 0x118)
class UCreativeModalDialogViewmodel : public UMVVMViewModelBase
{
public:
    FText Title; // 0x68 (Size: 0x10, Type: TextProperty)
    FText Body; // 0x78 (Size: 0x10, Type: TextProperty)
    UDataTable* TextStyleSet; // 0x88 (Size: 0x8, Type: ObjectProperty)
    FText Button01_MainText; // 0x90 (Size: 0x10, Type: TextProperty)
    FText Button02_MainText; // 0xa0 (Size: 0x10, Type: TextProperty)
    FText Button03_MainText; // 0xb0 (Size: 0x10, Type: TextProperty)
    FText Button04_MainText; // 0xc0 (Size: 0x10, Type: TextProperty)
    FText Button05_MainText; // 0xd0 (Size: 0x10, Type: TextProperty)
    FText Button06_MainText; // 0xe0 (Size: 0x10, Type: TextProperty)
    FText Button01_SubText; // 0xf0 (Size: 0x10, Type: TextProperty)
    FText Button02_SubText; // 0x100 (Size: 0x10, Type: TextProperty)
    FText Button03_SubText; // 0x110 (Size: 0x10, Type: TextProperty)
    FText Button04_SubText; // 0x120 (Size: 0x10, Type: TextProperty)
    FText Button05_SubText; // 0x130 (Size: 0x10, Type: TextProperty)
    FText Button06_SubText; // 0x140 (Size: 0x10, Type: TextProperty)
    UTexture2D* Art01_Image; // 0x150 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* Art02_Image; // 0x158 (Size: 0x8, Type: ObjectProperty)
    UMaterial* Art01_Material; // 0x160 (Size: 0x8, Type: ObjectProperty)
    UMaterial* Art02_Material; // 0x168 (Size: 0x8, Type: ObjectProperty)
    uint8_t ContentAlignment; // 0x170 (Size: 0x1, Type: EnumProperty)
    bool bShowBackground; // 0x171 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_172[0x2]; // 0x172 (Size: 0x2, Type: PaddingProperty)
    float DialogBackgroundAlpha; // 0x174 (Size: 0x4, Type: FloatProperty)
    uint8_t TimerOption; // 0x178 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_179[0x3]; // 0x179 (Size: 0x3, Type: PaddingProperty)
    float Timeout; // 0x17c (Size: 0x4, Type: FloatProperty)
    float RemainingTimeForTimeout; // 0x180 (Size: 0x4, Type: FloatProperty)
    float Progress; // 0x184 (Size: 0x4, Type: FloatProperty)
    int64_t NumberOfButtons; // 0x188 (Size: 0x8, Type: Int64Property)
    uint8_t BackActionBoundButton; // 0x190 (Size: 0x1, Type: EnumProperty)
    uint8_t Response; // 0x191 (Size: 0x1, Type: EnumProperty)
    uint8_t Button01_Visibility; // 0x192 (Size: 0x1, Type: EnumProperty)
    uint8_t Button02_Visibility; // 0x193 (Size: 0x1, Type: EnumProperty)
    uint8_t Button03_Visibility; // 0x194 (Size: 0x1, Type: EnumProperty)
    uint8_t Button04_Visibility; // 0x195 (Size: 0x1, Type: EnumProperty)
    uint8_t Button05_Visibility; // 0x196 (Size: 0x1, Type: EnumProperty)
    uint8_t Button06_Visibility; // 0x197 (Size: 0x1, Type: EnumProperty)
    USoundBase* HoveredSound; // 0x198 (Size: 0x8, Type: ObjectProperty)
    USoundBase* PressedSound; // 0x1a0 (Size: 0x8, Type: ObjectProperty)

public:
    ESlateVisibility GetBackgroundVisibility() const; // 0x11a9aeec (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FDataTableRowHandle GetButton1TriggeringInputAction() const; // 0x11a9af10 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ESlateVisibility GetButton1Visibility() const; // 0x11a9af4c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FDataTableRowHandle GetButton2TriggeringInputAction() const; // 0x11a9af68 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ESlateVisibility GetButton2Visibility() const; // 0x11a9afa4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FDataTableRowHandle GetButton3TriggeringInputAction() const; // 0x11a9afc0 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ESlateVisibility GetButton3Visibility() const; // 0x11a9affc (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FDataTableRowHandle GetButton4TriggeringInputAction() const; // 0x11a9b018 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ESlateVisibility GetButton4Visibility() const; // 0x11a9b054 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FDataTableRowHandle GetButton5TriggeringInputAction() const; // 0x11a9b070 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ESlateVisibility GetButton5Visibility() const; // 0x11a9b0ac (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FDataTableRowHandle GetButton6TriggeringInputAction() const; // 0x11a9b0c8 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ESlateVisibility GetButton6Visibility() const; // 0x11a9b104 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TEnumAsByte<EHorizontalAlignment> GetHorizontalAlignment() const; // 0x11a9b9e0 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTimeoutProgress() const; // 0x11a9c7e8 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ESlateVisibility GetTimerVisibility() const; // 0x11a9c80c (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TEnumAsByte<EVerticalAlignment> GetVerticalAlignment() const; // 0x11a9c844 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsButton1Visible() const; // 0x11a9c8bc (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsButton2Visible() const; // 0x11a9c8d8 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsButton3Visible() const; // 0x11a9c8f4 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsButton4Visible() const; // 0x11a9c910 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsButton5Visible() const; // 0x11a9c92c (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsButton6Visible() const; // 0x11a9c948 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsTimerVisible() const; // 0x11a9c964 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ShouldButton1UseFallbackDefaultInputAction() const; // 0x11a9c994 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ShouldButton2UseFallbackDefaultInputAction() const; // 0x11a9c9c0 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ShouldButton3UseFallbackDefaultInputAction() const; // 0x11a9c9ec (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ShouldButton4UseFallbackDefaultInputAction() const; // 0x11a9ca18 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ShouldButton5UseFallbackDefaultInputAction() const; // 0x11a9ca44 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ShouldButton6UseFallbackDefaultInputAction() const; // 0x11a9ca70 (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UCreativeModalDialogViewmodel) == 0x1a8, "Size mismatch for UCreativeModalDialogViewmodel");
static_assert(offsetof(UCreativeModalDialogViewmodel, Title) == 0x68, "Offset mismatch for UCreativeModalDialogViewmodel::Title");
static_assert(offsetof(UCreativeModalDialogViewmodel, Body) == 0x78, "Offset mismatch for UCreativeModalDialogViewmodel::Body");
static_assert(offsetof(UCreativeModalDialogViewmodel, TextStyleSet) == 0x88, "Offset mismatch for UCreativeModalDialogViewmodel::TextStyleSet");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button01_MainText) == 0x90, "Offset mismatch for UCreativeModalDialogViewmodel::Button01_MainText");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button02_MainText) == 0xa0, "Offset mismatch for UCreativeModalDialogViewmodel::Button02_MainText");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button03_MainText) == 0xb0, "Offset mismatch for UCreativeModalDialogViewmodel::Button03_MainText");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button04_MainText) == 0xc0, "Offset mismatch for UCreativeModalDialogViewmodel::Button04_MainText");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button05_MainText) == 0xd0, "Offset mismatch for UCreativeModalDialogViewmodel::Button05_MainText");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button06_MainText) == 0xe0, "Offset mismatch for UCreativeModalDialogViewmodel::Button06_MainText");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button01_SubText) == 0xf0, "Offset mismatch for UCreativeModalDialogViewmodel::Button01_SubText");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button02_SubText) == 0x100, "Offset mismatch for UCreativeModalDialogViewmodel::Button02_SubText");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button03_SubText) == 0x110, "Offset mismatch for UCreativeModalDialogViewmodel::Button03_SubText");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button04_SubText) == 0x120, "Offset mismatch for UCreativeModalDialogViewmodel::Button04_SubText");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button05_SubText) == 0x130, "Offset mismatch for UCreativeModalDialogViewmodel::Button05_SubText");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button06_SubText) == 0x140, "Offset mismatch for UCreativeModalDialogViewmodel::Button06_SubText");
static_assert(offsetof(UCreativeModalDialogViewmodel, Art01_Image) == 0x150, "Offset mismatch for UCreativeModalDialogViewmodel::Art01_Image");
static_assert(offsetof(UCreativeModalDialogViewmodel, Art02_Image) == 0x158, "Offset mismatch for UCreativeModalDialogViewmodel::Art02_Image");
static_assert(offsetof(UCreativeModalDialogViewmodel, Art01_Material) == 0x160, "Offset mismatch for UCreativeModalDialogViewmodel::Art01_Material");
static_assert(offsetof(UCreativeModalDialogViewmodel, Art02_Material) == 0x168, "Offset mismatch for UCreativeModalDialogViewmodel::Art02_Material");
static_assert(offsetof(UCreativeModalDialogViewmodel, ContentAlignment) == 0x170, "Offset mismatch for UCreativeModalDialogViewmodel::ContentAlignment");
static_assert(offsetof(UCreativeModalDialogViewmodel, bShowBackground) == 0x171, "Offset mismatch for UCreativeModalDialogViewmodel::bShowBackground");
static_assert(offsetof(UCreativeModalDialogViewmodel, DialogBackgroundAlpha) == 0x174, "Offset mismatch for UCreativeModalDialogViewmodel::DialogBackgroundAlpha");
static_assert(offsetof(UCreativeModalDialogViewmodel, TimerOption) == 0x178, "Offset mismatch for UCreativeModalDialogViewmodel::TimerOption");
static_assert(offsetof(UCreativeModalDialogViewmodel, Timeout) == 0x17c, "Offset mismatch for UCreativeModalDialogViewmodel::Timeout");
static_assert(offsetof(UCreativeModalDialogViewmodel, RemainingTimeForTimeout) == 0x180, "Offset mismatch for UCreativeModalDialogViewmodel::RemainingTimeForTimeout");
static_assert(offsetof(UCreativeModalDialogViewmodel, Progress) == 0x184, "Offset mismatch for UCreativeModalDialogViewmodel::Progress");
static_assert(offsetof(UCreativeModalDialogViewmodel, NumberOfButtons) == 0x188, "Offset mismatch for UCreativeModalDialogViewmodel::NumberOfButtons");
static_assert(offsetof(UCreativeModalDialogViewmodel, BackActionBoundButton) == 0x190, "Offset mismatch for UCreativeModalDialogViewmodel::BackActionBoundButton");
static_assert(offsetof(UCreativeModalDialogViewmodel, Response) == 0x191, "Offset mismatch for UCreativeModalDialogViewmodel::Response");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button01_Visibility) == 0x192, "Offset mismatch for UCreativeModalDialogViewmodel::Button01_Visibility");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button02_Visibility) == 0x193, "Offset mismatch for UCreativeModalDialogViewmodel::Button02_Visibility");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button03_Visibility) == 0x194, "Offset mismatch for UCreativeModalDialogViewmodel::Button03_Visibility");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button04_Visibility) == 0x195, "Offset mismatch for UCreativeModalDialogViewmodel::Button04_Visibility");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button05_Visibility) == 0x196, "Offset mismatch for UCreativeModalDialogViewmodel::Button05_Visibility");
static_assert(offsetof(UCreativeModalDialogViewmodel, Button06_Visibility) == 0x197, "Offset mismatch for UCreativeModalDialogViewmodel::Button06_Visibility");
static_assert(offsetof(UCreativeModalDialogViewmodel, HoveredSound) == 0x198, "Offset mismatch for UCreativeModalDialogViewmodel::HoveredSound");
static_assert(offsetof(UCreativeModalDialogViewmodel, PressedSound) == 0x1a0, "Offset mismatch for UCreativeModalDialogViewmodel::PressedSound");

// Size: 0x418 (Inherited: 0xb38, Single: 0xfffff8e0)
class UCreativeModalDialogWidget : public UCommonActivatableWidget
{
public:
    FDataTableRowHandle MainMenuInputRowHandle; // 0x408 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UCreativeModalDialogWidget) == 0x418, "Size mismatch for UCreativeModalDialogWidget");
static_assert(offsetof(UCreativeModalDialogWidget, MainMenuInputRowHandle) == 0x408, "Offset mismatch for UCreativeModalDialogWidget::MainMenuInputRowHandle");

