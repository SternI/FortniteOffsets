/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DryBoxRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "Engine.h"

// Size: 0x1298 (Inherited: 0x8f0, Single: 0x9a8)
class UNyxGlassWeaponComponent_Swinging : public UFortWeaponComponent_Swinging
{
public:
    FScalableFloat SwingTargetRaycastDist; // 0x6a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat AttackTargetRaycastDist; // 0x6c8 (Size: 0x28, Type: StructProperty)
    FScalableFloat CameraDistScale; // 0x6f0 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetingSphereRadius; // 0x718 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxAttachPointActorBoundsSize; // 0x740 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxAttachPointActorExtent; // 0x768 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinAttachPointDistFromCamera; // 0x790 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinAttachPointAngleInRad; // 0x7b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxSecondAttachPointDotProd; // 0x7e0 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> RayTraceTargetingCollisionChannel; // 0x808 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ECollisionChannel> SphereOverlapTargetingCollisionChannel; // 0x809 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_80a[0x6]; // 0x80a (Size: 0x6, Type: PaddingProperty)
    TArray<UClass*> DisallowedActorClasses; // 0x810 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> DirectRaycastDisallowedActorClasses; // 0x820 (Size: 0x10, Type: ArrayProperty)
    TArray<TEnumAsByte<EFortBuildingType>> AllowedBuildingTypes; // 0x830 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat SwingingAutoDetachDist; // 0x840 (Size: 0x28, Type: StructProperty)
    FScalableFloat AttackStartSlashDist; // 0x868 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxAcceleration; // 0x890 (Size: 0x28, Type: StructProperty)
    FScalableFloat GasOrthogonalPowerWhileAttacking; // 0x8b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat GasOrthogonalPowerWhileSwinging; // 0x8e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat GasReelInPowerSwinging; // 0x908 (Size: 0x28, Type: StructProperty)
    FScalableFloat GasReelInPowerAttacking; // 0x930 (Size: 0x28, Type: StructProperty)
    FScalableFloat bShouldInterpolateCurGasToGoal; // 0x958 (Size: 0x28, Type: StructProperty)
    FScalableFloat GasForceInterpSpeed; // 0x980 (Size: 0x28, Type: StructProperty)
    FScalableFloat bShouldAccelerateWhileAttached; // 0x9a8 (Size: 0x28, Type: StructProperty)
    FScalableFloat UnattachedDeaccelerationMultiplier; // 0x9d0 (Size: 0x28, Type: StructProperty)
    FScalableFloat AttachedDeaccelerationMultiplier; // 0x9f8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TimeAttachedBeforeSpeedStartsIncreasing; // 0xa20 (Size: 0x28, Type: StructProperty)
    FScalableFloat TimeAttachedForMaxSpeed; // 0xa48 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinAttachedSpeedMultiplier; // 0xa70 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxAttachedSpeedMultiplier; // 0xa98 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinUnattachedSpeedMultiplier; // 0xac0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxSpeedMultiplier; // 0xae8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxSpeedDecreaseFromUpwardAngle; // 0xb10 (Size: 0x28, Type: StructProperty)
    UCurveFloat* SpeedBasedOnHeightCurve; // 0xb38 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat BaseSwingSpeed; // 0xb40 (Size: 0x28, Type: StructProperty)
    FScalableFloat InitialAccelerationStartSpeed; // 0xb68 (Size: 0x28, Type: StructProperty)
    FScalableFloat InitialAccelerationTime; // 0xb90 (Size: 0x28, Type: StructProperty)
    UCurveFloat* InitialAccelerationCurve; // 0xbb8 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat SpeedSoftCapDrag; // 0xbc0 (Size: 0x28, Type: StructProperty)
    FScalableFloat SpeedHardCapFailsafe; // 0xbe8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxHoverTime; // 0xc10 (Size: 0x28, Type: StructProperty)
    FScalableFloat FullHoverRechargeTime; // 0xc38 (Size: 0x28, Type: StructProperty)
    FScalableFloat DesiredHoverZSpeed; // 0xc60 (Size: 0x28, Type: StructProperty)
    FScalableFloat HoverZMultiplier; // 0xc88 (Size: 0x28, Type: StructProperty)
    FScalableFloat HoverTimeWhileUnequipped; // 0xcb0 (Size: 0x28, Type: StructProperty)
    FScalableFloat HoverZMultiplierWhileUnequipped; // 0xcd8 (Size: 0x28, Type: StructProperty)
    FScalableFloat SpeedSoftCapDragWhenHovering; // 0xd00 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxHoverSpeed; // 0xd28 (Size: 0x28, Type: StructProperty)
    FScalableFloat OldAttackDistanceXRange; // 0xd50 (Size: 0x28, Type: StructProperty)
    FScalableFloat OldAttackDistanceYRange; // 0xd78 (Size: 0x28, Type: StructProperty)
    FScalableFloat NewAttackDistanceXRange; // 0xda0 (Size: 0x28, Type: StructProperty)
    FScalableFloat NewAttackDistanceYRange; // 0xdc8 (Size: 0x28, Type: StructProperty)
    UCurveFloat* AttackAccelerationCurve; // 0xdf0 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat ReelInForceAttackMinDist; // 0xdf8 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReelInForceAttackMaxDist; // 0xe20 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReelInForceAttackMinMult; // 0xe48 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReelInForceAttackMaxMult; // 0xe70 (Size: 0x28, Type: StructProperty)
    FScalableFloat AttackStartSpeed; // 0xe98 (Size: 0x28, Type: StructProperty)
    FScalableFloat AttackMaxSpeed; // 0xec0 (Size: 0x28, Type: StructProperty)
    FScalableFloat SpeedSoftCapDragWhenAttacking; // 0xee8 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlashLockDistance; // 0xf10 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinSlashDistToTarget; // 0xf38 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlashSpeed; // 0xf60 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlashLockTime; // 0xf88 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlashLeapBackTime; // 0xfb0 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlashLeapBackHeightModifier; // 0xfd8 (Size: 0x28, Type: StructProperty)
    FScalableFloat SlashLeapBackSpeed; // 0x1000 (Size: 0x28, Type: StructProperty)
    FGameplayTag OverrideSwingingControlParamsTag_Swinging; // 0x1028 (Size: 0x4, Type: StructProperty)
    FGameplayTag OverrideSwingingControlParamsTag_Hovering; // 0x102c (Size: 0x4, Type: StructProperty)
    FGameplayTag OverrideSwingingControlParamsTag_Attacking; // 0x1030 (Size: 0x4, Type: StructProperty)
    FGameplayTag OverrideSwingingControlParamsTag_LeapingBack; // 0x1034 (Size: 0x4, Type: StructProperty)
    FScalableFloat LeapingBack_OverrideTimer; // 0x1038 (Size: 0x28, Type: StructProperty)
    FName ActorHasPreferredSwingMeshTag; // 0x1060 (Size: 0x4, Type: NameProperty)
    FName ComponentIsPreferredSwingMeshTag; // 0x1064 (Size: 0x4, Type: NameProperty)
    bool bUsingDirectRaycast; // 0x1068 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1069[0x7]; // 0x1069 (Size: 0x7, Type: PaddingProperty)
    FNyxGlassTargetingData CurTargetingData; // 0x1070 (Size: 0x48, Type: StructProperty)
    uint8_t Pad_10b8[0x1e0]; // 0x10b8 (Size: 0x1e0, Type: PaddingProperty)

public:
    float CalcInitialAccelerationAlpha() const; // 0x113c4e70 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void EndSwingingSession(); // 0x113c4e98 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    virtual ENyxGlassSlashSubstate GetNyxGlassSlashSubstate() const; // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent|Const)
    virtual ENyxGlassState GetNyxGlassState() const; // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent|Const)
    virtual bool IsAttacking(); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    void OnAttached(); // 0x554e3c4 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void OnAttackStart(); // 0x113c4f80 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void OnBPWeaponFired(); // 0x113c4f94 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void OnDetached(); // 0x554e3c4 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void OnNyxGlassStateChanged(ENyxGlassState& const OldState, ENyxGlassState& const NewState); // 0x113c4fb8 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    virtual void OnServerTargetingDataReceived(); // 0x288a61c (Index: 0xb, Flags: Event|Public|BlueprintEvent)
    virtual void OnTargetingComplete(const FNyxGlassTargetingData TargetingData); // 0x288a61c (Index: 0xc, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnVelocityCalculated(const FNyxGlassVelocityMetadata VelocityMetadata) const; // 0x288a61c (Index: 0xd, Flags: Event|Public|HasOutParms|BlueprintEvent|Const)
    virtual bool ShouldUpdateTargeting(); // 0x288a61c (Index: 0x11, Flags: Event|Public|BlueprintEvent)
    virtual void UpdateRopeVFX(); // 0x288a61c (Index: 0x12, Flags: Event|Public|BlueprintEvent)

private:
    virtual void Multicast_SetTargetingDataOnRemoteClients(FNyxGlassTargetingData& const NewData); // 0x113c4eb0 (Index: 0x5, Flags: Final|Net|Native|Event|NetMulticast|Private)
    void OnWeaponFired(); // 0x113c53cc (Index: 0xe, Flags: Final|Native|Private)
    void OnWeaponUnequip(AFortWeapon*& Weapon); // 0x113c53e0 (Index: 0xf, Flags: Final|Native|Private)
    virtual void Server_SetTargetingData(FNyxGlassTargetingData& const NewData); // 0x113c550c (Index: 0x10, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
};

static_assert(sizeof(UNyxGlassWeaponComponent_Swinging) == 0x1298, "Size mismatch for UNyxGlassWeaponComponent_Swinging");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SwingTargetRaycastDist) == 0x6a0, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SwingTargetRaycastDist");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, AttackTargetRaycastDist) == 0x6c8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::AttackTargetRaycastDist");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, CameraDistScale) == 0x6f0, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::CameraDistScale");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, TargetingSphereRadius) == 0x718, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::TargetingSphereRadius");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MaxAttachPointActorBoundsSize) == 0x740, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MaxAttachPointActorBoundsSize");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MaxAttachPointActorExtent) == 0x768, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MaxAttachPointActorExtent");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MinAttachPointDistFromCamera) == 0x790, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MinAttachPointDistFromCamera");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MinAttachPointAngleInRad) == 0x7b8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MinAttachPointAngleInRad");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MaxSecondAttachPointDotProd) == 0x7e0, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MaxSecondAttachPointDotProd");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, RayTraceTargetingCollisionChannel) == 0x808, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::RayTraceTargetingCollisionChannel");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SphereOverlapTargetingCollisionChannel) == 0x809, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SphereOverlapTargetingCollisionChannel");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, DisallowedActorClasses) == 0x810, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::DisallowedActorClasses");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, DirectRaycastDisallowedActorClasses) == 0x820, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::DirectRaycastDisallowedActorClasses");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, AllowedBuildingTypes) == 0x830, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::AllowedBuildingTypes");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SwingingAutoDetachDist) == 0x840, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SwingingAutoDetachDist");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, AttackStartSlashDist) == 0x868, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::AttackStartSlashDist");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MaxAcceleration) == 0x890, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MaxAcceleration");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, GasOrthogonalPowerWhileAttacking) == 0x8b8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::GasOrthogonalPowerWhileAttacking");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, GasOrthogonalPowerWhileSwinging) == 0x8e0, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::GasOrthogonalPowerWhileSwinging");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, GasReelInPowerSwinging) == 0x908, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::GasReelInPowerSwinging");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, GasReelInPowerAttacking) == 0x930, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::GasReelInPowerAttacking");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, bShouldInterpolateCurGasToGoal) == 0x958, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::bShouldInterpolateCurGasToGoal");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, GasForceInterpSpeed) == 0x980, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::GasForceInterpSpeed");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, bShouldAccelerateWhileAttached) == 0x9a8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::bShouldAccelerateWhileAttached");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, UnattachedDeaccelerationMultiplier) == 0x9d0, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::UnattachedDeaccelerationMultiplier");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, AttachedDeaccelerationMultiplier) == 0x9f8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::AttachedDeaccelerationMultiplier");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, TimeAttachedBeforeSpeedStartsIncreasing) == 0xa20, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::TimeAttachedBeforeSpeedStartsIncreasing");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, TimeAttachedForMaxSpeed) == 0xa48, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::TimeAttachedForMaxSpeed");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MinAttachedSpeedMultiplier) == 0xa70, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MinAttachedSpeedMultiplier");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MaxAttachedSpeedMultiplier) == 0xa98, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MaxAttachedSpeedMultiplier");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MinUnattachedSpeedMultiplier) == 0xac0, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MinUnattachedSpeedMultiplier");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MaxSpeedMultiplier) == 0xae8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MaxSpeedMultiplier");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MaxSpeedDecreaseFromUpwardAngle) == 0xb10, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MaxSpeedDecreaseFromUpwardAngle");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SpeedBasedOnHeightCurve) == 0xb38, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SpeedBasedOnHeightCurve");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, BaseSwingSpeed) == 0xb40, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::BaseSwingSpeed");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, InitialAccelerationStartSpeed) == 0xb68, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::InitialAccelerationStartSpeed");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, InitialAccelerationTime) == 0xb90, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::InitialAccelerationTime");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, InitialAccelerationCurve) == 0xbb8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::InitialAccelerationCurve");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SpeedSoftCapDrag) == 0xbc0, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SpeedSoftCapDrag");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SpeedHardCapFailsafe) == 0xbe8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SpeedHardCapFailsafe");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MaxHoverTime) == 0xc10, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MaxHoverTime");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, FullHoverRechargeTime) == 0xc38, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::FullHoverRechargeTime");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, DesiredHoverZSpeed) == 0xc60, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::DesiredHoverZSpeed");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, HoverZMultiplier) == 0xc88, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::HoverZMultiplier");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, HoverTimeWhileUnequipped) == 0xcb0, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::HoverTimeWhileUnequipped");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, HoverZMultiplierWhileUnequipped) == 0xcd8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::HoverZMultiplierWhileUnequipped");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SpeedSoftCapDragWhenHovering) == 0xd00, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SpeedSoftCapDragWhenHovering");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MaxHoverSpeed) == 0xd28, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MaxHoverSpeed");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, OldAttackDistanceXRange) == 0xd50, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::OldAttackDistanceXRange");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, OldAttackDistanceYRange) == 0xd78, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::OldAttackDistanceYRange");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, NewAttackDistanceXRange) == 0xda0, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::NewAttackDistanceXRange");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, NewAttackDistanceYRange) == 0xdc8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::NewAttackDistanceYRange");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, AttackAccelerationCurve) == 0xdf0, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::AttackAccelerationCurve");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, ReelInForceAttackMinDist) == 0xdf8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::ReelInForceAttackMinDist");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, ReelInForceAttackMaxDist) == 0xe20, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::ReelInForceAttackMaxDist");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, ReelInForceAttackMinMult) == 0xe48, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::ReelInForceAttackMinMult");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, ReelInForceAttackMaxMult) == 0xe70, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::ReelInForceAttackMaxMult");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, AttackStartSpeed) == 0xe98, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::AttackStartSpeed");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, AttackMaxSpeed) == 0xec0, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::AttackMaxSpeed");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SpeedSoftCapDragWhenAttacking) == 0xee8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SpeedSoftCapDragWhenAttacking");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SlashLockDistance) == 0xf10, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SlashLockDistance");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, MinSlashDistToTarget) == 0xf38, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::MinSlashDistToTarget");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SlashSpeed) == 0xf60, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SlashSpeed");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SlashLockTime) == 0xf88, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SlashLockTime");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SlashLeapBackTime) == 0xfb0, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SlashLeapBackTime");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SlashLeapBackHeightModifier) == 0xfd8, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SlashLeapBackHeightModifier");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, SlashLeapBackSpeed) == 0x1000, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::SlashLeapBackSpeed");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, OverrideSwingingControlParamsTag_Swinging) == 0x1028, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::OverrideSwingingControlParamsTag_Swinging");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, OverrideSwingingControlParamsTag_Hovering) == 0x102c, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::OverrideSwingingControlParamsTag_Hovering");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, OverrideSwingingControlParamsTag_Attacking) == 0x1030, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::OverrideSwingingControlParamsTag_Attacking");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, OverrideSwingingControlParamsTag_LeapingBack) == 0x1034, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::OverrideSwingingControlParamsTag_LeapingBack");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, LeapingBack_OverrideTimer) == 0x1038, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::LeapingBack_OverrideTimer");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, ActorHasPreferredSwingMeshTag) == 0x1060, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::ActorHasPreferredSwingMeshTag");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, ComponentIsPreferredSwingMeshTag) == 0x1064, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::ComponentIsPreferredSwingMeshTag");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, bUsingDirectRaycast) == 0x1068, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::bUsingDirectRaycast");
static_assert(offsetof(UNyxGlassWeaponComponent_Swinging, CurTargetingData) == 0x1070, "Offset mismatch for UNyxGlassWeaponComponent_Swinging::CurTargetingData");

// Size: 0xb0 (Inherited: 0x88, Single: 0x28)
class UNyxGlassFuelAttributeSet : public UFortAttributeSet
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    FFortGameplayAttributeData MaxFuel; // 0x38 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData Fuel; // 0x60 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData LocalFuel; // 0x88 (Size: 0x28, Type: StructProperty)

private:
    void OnRep_Fuel(const FFortGameplayAttributeData OldValue); // 0x113c51bc (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
    void OnRep_LocalFuel(const FFortGameplayAttributeData OldValue); // 0x113c52c4 (Index: 0x1, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UNyxGlassFuelAttributeSet) == 0xb0, "Size mismatch for UNyxGlassFuelAttributeSet");
static_assert(offsetof(UNyxGlassFuelAttributeSet, MaxFuel) == 0x38, "Offset mismatch for UNyxGlassFuelAttributeSet::MaxFuel");
static_assert(offsetof(UNyxGlassFuelAttributeSet, Fuel) == 0x60, "Offset mismatch for UNyxGlassFuelAttributeSet::Fuel");
static_assert(offsetof(UNyxGlassFuelAttributeSet, LocalFuel) == 0x88, "Offset mismatch for UNyxGlassFuelAttributeSet::LocalFuel");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UNyxGlassSwingingMovementControls : public UFortMovementControls
{
public:
};

static_assert(sizeof(UNyxGlassSwingingMovementControls) == 0x30, "Size mismatch for UNyxGlassSwingingMovementControls");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FNyxGlassTargetingData
{
    AActor* LeftActor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* RightActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector LeftAttachPoint; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector RightAttachPoint; // 0x28 (Size: 0x18, Type: StructProperty)
    bool bFoundLeftAttachPoint; // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bFoundRightAttachPoint; // 0x41 (Size: 0x1, Type: BoolProperty)
    bool bUsingDirectRaycast; // 0x42 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_43[0x5]; // 0x43 (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(FNyxGlassTargetingData) == 0x48, "Size mismatch for FNyxGlassTargetingData");
static_assert(offsetof(FNyxGlassTargetingData, LeftActor) == 0x0, "Offset mismatch for FNyxGlassTargetingData::LeftActor");
static_assert(offsetof(FNyxGlassTargetingData, RightActor) == 0x8, "Offset mismatch for FNyxGlassTargetingData::RightActor");
static_assert(offsetof(FNyxGlassTargetingData, LeftAttachPoint) == 0x10, "Offset mismatch for FNyxGlassTargetingData::LeftAttachPoint");
static_assert(offsetof(FNyxGlassTargetingData, RightAttachPoint) == 0x28, "Offset mismatch for FNyxGlassTargetingData::RightAttachPoint");
static_assert(offsetof(FNyxGlassTargetingData, bFoundLeftAttachPoint) == 0x40, "Offset mismatch for FNyxGlassTargetingData::bFoundLeftAttachPoint");
static_assert(offsetof(FNyxGlassTargetingData, bFoundRightAttachPoint) == 0x41, "Offset mismatch for FNyxGlassTargetingData::bFoundRightAttachPoint");
static_assert(offsetof(FNyxGlassTargetingData, bUsingDirectRaycast) == 0x42, "Offset mismatch for FNyxGlassTargetingData::bUsingDirectRaycast");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FNyxGlassVelocityMetadata
{
    FVector OrigVelocity; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector FinalVelocity; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector FinalGasForce; // 0x30 (Size: 0x18, Type: StructProperty)
    float CalcMaxSpeedMultiplier; // 0x48 (Size: 0x4, Type: FloatProperty)
    bool bCloseToAttachPoint; // 0x4c (Size: 0x1, Type: BoolProperty)
    bool bPerformedHoverCalculation; // 0x4d (Size: 0x1, Type: BoolProperty)
    bool bReachedSlashTarget; // 0x4e (Size: 0x1, Type: BoolProperty)
    bool bShouldApplySlashDamage; // 0x4f (Size: 0x1, Type: BoolProperty)
    bool bShouldLeapBack; // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bFinishedLeapingBack; // 0x51 (Size: 0x1, Type: BoolProperty)
    bool bCancelAttackSequence; // 0x52 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_53[0x5]; // 0x53 (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(FNyxGlassVelocityMetadata) == 0x58, "Size mismatch for FNyxGlassVelocityMetadata");
static_assert(offsetof(FNyxGlassVelocityMetadata, OrigVelocity) == 0x0, "Offset mismatch for FNyxGlassVelocityMetadata::OrigVelocity");
static_assert(offsetof(FNyxGlassVelocityMetadata, FinalVelocity) == 0x18, "Offset mismatch for FNyxGlassVelocityMetadata::FinalVelocity");
static_assert(offsetof(FNyxGlassVelocityMetadata, FinalGasForce) == 0x30, "Offset mismatch for FNyxGlassVelocityMetadata::FinalGasForce");
static_assert(offsetof(FNyxGlassVelocityMetadata, CalcMaxSpeedMultiplier) == 0x48, "Offset mismatch for FNyxGlassVelocityMetadata::CalcMaxSpeedMultiplier");
static_assert(offsetof(FNyxGlassVelocityMetadata, bCloseToAttachPoint) == 0x4c, "Offset mismatch for FNyxGlassVelocityMetadata::bCloseToAttachPoint");
static_assert(offsetof(FNyxGlassVelocityMetadata, bPerformedHoverCalculation) == 0x4d, "Offset mismatch for FNyxGlassVelocityMetadata::bPerformedHoverCalculation");
static_assert(offsetof(FNyxGlassVelocityMetadata, bReachedSlashTarget) == 0x4e, "Offset mismatch for FNyxGlassVelocityMetadata::bReachedSlashTarget");
static_assert(offsetof(FNyxGlassVelocityMetadata, bShouldApplySlashDamage) == 0x4f, "Offset mismatch for FNyxGlassVelocityMetadata::bShouldApplySlashDamage");
static_assert(offsetof(FNyxGlassVelocityMetadata, bShouldLeapBack) == 0x50, "Offset mismatch for FNyxGlassVelocityMetadata::bShouldLeapBack");
static_assert(offsetof(FNyxGlassVelocityMetadata, bFinishedLeapingBack) == 0x51, "Offset mismatch for FNyxGlassVelocityMetadata::bFinishedLeapingBack");
static_assert(offsetof(FNyxGlassVelocityMetadata, bCancelAttackSequence) == 0x52, "Offset mismatch for FNyxGlassVelocityMetadata::bCancelAttackSequence");

