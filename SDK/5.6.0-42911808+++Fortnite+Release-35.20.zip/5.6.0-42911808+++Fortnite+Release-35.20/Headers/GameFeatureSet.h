/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameFeatureSet
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "GameFeatures.h"
#include "Engine.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UGameFeatureSetAssetReplacementMappingBase : public UObject
{
public:
};

static_assert(sizeof(UGameFeatureSetAssetReplacementMappingBase) == 0x28, "Size mismatch for UGameFeatureSetAssetReplacementMappingBase");

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UGameFeatureSetPlayerSpawnerReplacement : public UGameFeatureSetAssetReplacementMappingBase
{
public:
    TSoftObjectPtr<UObject*> PlayerSpawnerClass; // 0x28 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(UGameFeatureSetPlayerSpawnerReplacement) == 0x48, "Size mismatch for UGameFeatureSetPlayerSpawnerReplacement");
static_assert(offsetof(UGameFeatureSetPlayerSpawnerReplacement, PlayerSpawnerClass) == 0x28, "Offset mismatch for UGameFeatureSetPlayerSpawnerReplacement::PlayerSpawnerClass");

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UGameFeatureSetIslandSettingsReplacement : public UGameFeatureSetAssetReplacementMappingBase
{
public:
    TSoftClassPtr IslandSettingsClass; // 0x28 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UGameFeatureSetIslandSettingsReplacement) == 0x48, "Size mismatch for UGameFeatureSetIslandSettingsReplacement");
static_assert(offsetof(UGameFeatureSetIslandSettingsReplacement, IslandSettingsClass) == 0x28, "Offset mismatch for UGameFeatureSetIslandSettingsReplacement::IslandSettingsClass");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UGameFeatureAction_SetGFSClassReplacements : public UGameFeatureAction
{
public:
    TArray<UGameFeatureSetAssetReplacementMappingBase*> ReplacementMappings; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGameFeatureAction_SetGFSClassReplacements) == 0x38, "Size mismatch for UGameFeatureAction_SetGFSClassReplacements");
static_assert(offsetof(UGameFeatureAction_SetGFSClassReplacements, ReplacementMappings) == 0x28, "Offset mismatch for UGameFeatureAction_SetGFSClassReplacements::ReplacementMappings");

// Size: 0x228 (Inherited: 0xb8, Single: 0x170)
class UGameFeatureSetSubsystem : public UEngineSubsystem
{
public:
};

static_assert(sizeof(UGameFeatureSetSubsystem) == 0x228, "Size mismatch for UGameFeatureSetSubsystem");

