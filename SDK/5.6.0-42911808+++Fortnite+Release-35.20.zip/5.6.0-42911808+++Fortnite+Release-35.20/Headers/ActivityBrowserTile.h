/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserTile
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DiscoveryBrowserUI.h"

// Size: 0x1560 (Inherited: 0x4630, Single: 0xffffcf30)
class UActivityBrowserTile_C : public UFortActivityBrowserTile
{
public:
};

static_assert(sizeof(UActivityBrowserTile_C) == 0x1560, "Size mismatch for UActivityBrowserTile_C");

