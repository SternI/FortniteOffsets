/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "SlateCore.h"
#include "CommonInput.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDynamicUITransitionableWidgetInterface : public UInterface
{
public:

protected:
    void BroadcastTransitionCompleted(); // 0x35e15d0 (Index: 0x0, Flags: Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDynamicUITransitionableWidgetInterface) == 0x28, "Size mismatch for UDynamicUITransitionableWidgetInterface");

// Size: 0x2c8 (Inherited: 0x2d0, Single: 0xfffffff8)
class ADynamicUIDirectorBase : public AActor
{
public:
    TArray<UDynamicUIScene*> DefaultScenes; // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<ULocalPlayer*> OwningLocalPlayer; // 0x2b8 (Size: 0x8, Type: WeakObjectProperty)
    bool bEnabledDuringReplay; // 0x2c0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2c1[0x7]; // 0x2c1 (Size: 0x7, Type: PaddingProperty)

public:
    void AddScene(UDynamicUIScene*& const Scene); // 0xc053a04 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void AddScenes(const TArray<UDynamicUIScene*> Scenes); // 0xc054018 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    ULocalPlayer* GetOwningLocalPlayer() const; // 0xc054814 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    APlayerController* GetOwningLocalPlayerController() const; // 0xc054838 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSceneActive(UDynamicUIScene*& const Scene) const; // 0xc05485c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RemoveScene(UDynamicUIScene*& const Scene); // 0xc054f5c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveScenes(const TArray<UDynamicUIScene*> Scenes); // 0xc0551d8 (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(ADynamicUIDirectorBase) == 0x2c8, "Size mismatch for ADynamicUIDirectorBase");
static_assert(offsetof(ADynamicUIDirectorBase, DefaultScenes) == 0x2a8, "Offset mismatch for ADynamicUIDirectorBase::DefaultScenes");
static_assert(offsetof(ADynamicUIDirectorBase, OwningLocalPlayer) == 0x2b8, "Offset mismatch for ADynamicUIDirectorBase::OwningLocalPlayer");
static_assert(offsetof(ADynamicUIDirectorBase, bEnabledDuringReplay) == 0x2c0, "Offset mismatch for ADynamicUIDirectorBase::bEnabledDuringReplay");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDynamicUIExcludeBase : public UObject
{
public:
};

static_assert(sizeof(UDynamicUIExcludeBase) == 0x28, "Size mismatch for UDynamicUIExcludeBase");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UDynamicUIExcludeInputType : public UDynamicUIExcludeBase
{
public:
    TArray<ECommonInputType> InputTypes; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDynamicUIExcludeInputType) == 0x38, "Size mismatch for UDynamicUIExcludeInputType");
static_assert(offsetof(UDynamicUIExcludeInputType, InputTypes) == 0x28, "Offset mismatch for UDynamicUIExcludeInputType::InputTypes");

// Size: 0x70 (Inherited: 0x28, Single: 0x48)
class UDynamicUIConstraintBase : public UObject
{
public:
    uint8_t Pad_28[0x28]; // 0x28 (Size: 0x28, Type: PaddingProperty)
    FVector2D Offset; // 0x50 (Size: 0x10, Type: StructProperty)
    UDynamicUIConstraintOverrideBase* ConstraintOverride; // 0x60 (Size: 0x8, Type: ObjectProperty)
    uint8_t bUseOffset : 1; // 0x68:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseOverride : 1; // 0x68:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUIConstraintBase) == 0x70, "Size mismatch for UDynamicUIConstraintBase");
static_assert(offsetof(UDynamicUIConstraintBase, Offset) == 0x50, "Offset mismatch for UDynamicUIConstraintBase::Offset");
static_assert(offsetof(UDynamicUIConstraintBase, ConstraintOverride) == 0x60, "Offset mismatch for UDynamicUIConstraintBase::ConstraintOverride");
static_assert(offsetof(UDynamicUIConstraintBase, bUseOffset) == 0x68, "Offset mismatch for UDynamicUIConstraintBase::bUseOffset");
static_assert(offsetof(UDynamicUIConstraintBase, bUseOverride) == 0x68, "Offset mismatch for UDynamicUIConstraintBase::bUseOverride");

// Size: 0x88 (Inherited: 0x98, Single: 0xfffffff0)
class UDynamicUIConstraintPosition : public UDynamicUIConstraintBase
{
public:
    FVector2D Position; // 0x70 (Size: 0x10, Type: StructProperty)
    uint8_t Anchor[0x4]; // 0x80 (Size: 0x4, Type: EnumProperty)
    uint8_t bUseSafeZone : 1; // 0x84:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_85[0x3]; // 0x85 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUIConstraintPosition) == 0x88, "Size mismatch for UDynamicUIConstraintPosition");
static_assert(offsetof(UDynamicUIConstraintPosition, Position) == 0x70, "Offset mismatch for UDynamicUIConstraintPosition::Position");
static_assert(offsetof(UDynamicUIConstraintPosition, Anchor) == 0x80, "Offset mismatch for UDynamicUIConstraintPosition::Anchor");
static_assert(offsetof(UDynamicUIConstraintPosition, bUseSafeZone) == 0x84, "Offset mismatch for UDynamicUIConstraintPosition::bUseSafeZone");

// Size: 0x98 (Inherited: 0x98, Single: 0x0)
class UDynamicUIConstraintAlignment : public UDynamicUIConstraintBase
{
public:
    TEnumAsByte<EHorizontalAlignment> HorizontalAlignment; // 0x70 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EVerticalAlignment> VerticalAlignment; // 0x71 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_72[0x2]; // 0x72 (Size: 0x2, Type: PaddingProperty)
    uint8_t Anchor[0x4]; // 0x74 (Size: 0x4, Type: EnumProperty)
    FDynamicUIVerticalMargin VerticalMargin; // 0x78 (Size: 0x8, Type: StructProperty)
    FDynamicUIHorizontalMargin HorizontalMargin; // 0x80 (Size: 0x8, Type: StructProperty)
    FDynamicUIAspectRatio MaxAspectRatio; // 0x88 (Size: 0x8, Type: StructProperty)
    uint8_t bUseSafeZone : 1; // 0x90:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseMaxAspectRatio : 1; // 0x90:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUIConstraintAlignment) == 0x98, "Size mismatch for UDynamicUIConstraintAlignment");
static_assert(offsetof(UDynamicUIConstraintAlignment, HorizontalAlignment) == 0x70, "Offset mismatch for UDynamicUIConstraintAlignment::HorizontalAlignment");
static_assert(offsetof(UDynamicUIConstraintAlignment, VerticalAlignment) == 0x71, "Offset mismatch for UDynamicUIConstraintAlignment::VerticalAlignment");
static_assert(offsetof(UDynamicUIConstraintAlignment, Anchor) == 0x74, "Offset mismatch for UDynamicUIConstraintAlignment::Anchor");
static_assert(offsetof(UDynamicUIConstraintAlignment, VerticalMargin) == 0x78, "Offset mismatch for UDynamicUIConstraintAlignment::VerticalMargin");
static_assert(offsetof(UDynamicUIConstraintAlignment, HorizontalMargin) == 0x80, "Offset mismatch for UDynamicUIConstraintAlignment::HorizontalMargin");
static_assert(offsetof(UDynamicUIConstraintAlignment, MaxAspectRatio) == 0x88, "Offset mismatch for UDynamicUIConstraintAlignment::MaxAspectRatio");
static_assert(offsetof(UDynamicUIConstraintAlignment, bUseSafeZone) == 0x90, "Offset mismatch for UDynamicUIConstraintAlignment::bUseSafeZone");
static_assert(offsetof(UDynamicUIConstraintAlignment, bUseMaxAspectRatio) == 0x90, "Offset mismatch for UDynamicUIConstraintAlignment::bUseMaxAspectRatio");

// Size: 0x110 (Inherited: 0x98, Single: 0x78)
class UDynamicUIConstraintWidget : public UDynamicUIConstraintBase
{
public:
    uint8_t Anchor[0x4]; // 0x70 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FDynamicUIWidgetTarget TargetWidget; // 0x78 (Size: 0x78, Type: StructProperty)
    uint8_t TargetAnchor[0x4]; // 0xf0 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_f4[0x4]; // 0xf4 (Size: 0x4, Type: PaddingProperty)
    TArray<UDynamicUIConstraintBase*> Fallbacks; // 0xf8 (Size: 0x10, Type: ArrayProperty)
    uint8_t bConstrainToUnallowedWidgets : 1; // 0x108:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseFallbacks : 1; // 0x108:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_109[0x7]; // 0x109 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUIConstraintWidget) == 0x110, "Size mismatch for UDynamicUIConstraintWidget");
static_assert(offsetof(UDynamicUIConstraintWidget, Anchor) == 0x70, "Offset mismatch for UDynamicUIConstraintWidget::Anchor");
static_assert(offsetof(UDynamicUIConstraintWidget, TargetWidget) == 0x78, "Offset mismatch for UDynamicUIConstraintWidget::TargetWidget");
static_assert(offsetof(UDynamicUIConstraintWidget, TargetAnchor) == 0xf0, "Offset mismatch for UDynamicUIConstraintWidget::TargetAnchor");
static_assert(offsetof(UDynamicUIConstraintWidget, Fallbacks) == 0xf8, "Offset mismatch for UDynamicUIConstraintWidget::Fallbacks");
static_assert(offsetof(UDynamicUIConstraintWidget, bConstrainToUnallowedWidgets) == 0x108, "Offset mismatch for UDynamicUIConstraintWidget::bConstrainToUnallowedWidgets");
static_assert(offsetof(UDynamicUIConstraintWidget, bUseFallbacks) == 0x108, "Offset mismatch for UDynamicUIConstraintWidget::bUseFallbacks");

// Size: 0x98 (Inherited: 0x98, Single: 0x0)
class UDynamicUIConstraintContainer : public UDynamicUIConstraintBase
{
public:
    TArray<FDynamicUIWidgetTarget> WidgetsToContain; // 0x70 (Size: 0x10, Type: ArrayProperty)
    FMargin Padding; // 0x80 (Size: 0x10, Type: StructProperty)
    uint8_t bMustMatchAllWidgets : 1; // 0x90:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUIConstraintContainer) == 0x98, "Size mismatch for UDynamicUIConstraintContainer");
static_assert(offsetof(UDynamicUIConstraintContainer, WidgetsToContain) == 0x70, "Offset mismatch for UDynamicUIConstraintContainer::WidgetsToContain");
static_assert(offsetof(UDynamicUIConstraintContainer, Padding) == 0x80, "Offset mismatch for UDynamicUIConstraintContainer::Padding");
static_assert(offsetof(UDynamicUIConstraintContainer, bMustMatchAllWidgets) == 0x90, "Offset mismatch for UDynamicUIConstraintContainer::bMustMatchAllWidgets");

// Size: 0x100 (Inherited: 0x98, Single: 0x68)
class UDynamicUIConstraintReplace : public UDynamicUIConstraintBase
{
public:
    FDynamicUIWidgetTarget TargetWidget; // 0x70 (Size: 0x78, Type: StructProperty)
    TArray<UDynamicUIConstraintBase*> Fallbacks; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    uint8_t bUseFallbacks : 1; // 0xf8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f9[0x7]; // 0xf9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUIConstraintReplace) == 0x100, "Size mismatch for UDynamicUIConstraintReplace");
static_assert(offsetof(UDynamicUIConstraintReplace, TargetWidget) == 0x70, "Offset mismatch for UDynamicUIConstraintReplace::TargetWidget");
static_assert(offsetof(UDynamicUIConstraintReplace, Fallbacks) == 0xe8, "Offset mismatch for UDynamicUIConstraintReplace::Fallbacks");
static_assert(offsetof(UDynamicUIConstraintReplace, bUseFallbacks) == 0xf8, "Offset mismatch for UDynamicUIConstraintReplace::bUseFallbacks");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDynamicUIConstraintOverrideBase : public UObject
{
public:
};

static_assert(sizeof(UDynamicUIConstraintOverrideBase) == 0x28, "Size mismatch for UDynamicUIConstraintOverrideBase");

// Size: 0xd0 (Inherited: 0x50, Single: 0x80)
class UDynamicUIConstraintPlatformOverride : public UDynamicUIConstraintOverrideBase
{
public:
    TMap<UDynamicUIConstraintBase*, FName> PlatformVisibilityControls; // 0x28 (Size: 0x50, Type: MapProperty)
    TMap<UDynamicUIConstraintBase*, ECommonInputType> InputTypeVisibilityControls; // 0x78 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUIConstraintPlatformOverride) == 0xd0, "Size mismatch for UDynamicUIConstraintPlatformOverride");
static_assert(offsetof(UDynamicUIConstraintPlatformOverride, PlatformVisibilityControls) == 0x28, "Offset mismatch for UDynamicUIConstraintPlatformOverride::PlatformVisibilityControls");
static_assert(offsetof(UDynamicUIConstraintPlatformOverride, InputTypeVisibilityControls) == 0x78, "Offset mismatch for UDynamicUIConstraintPlatformOverride::InputTypeVisibilityControls");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UDynamicUIConstraintSplitscreenOverride : public UDynamicUIConstraintOverrideBase
{
public:
    UDynamicUIConstraintBase* SplitscreenConstraintOverride; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDynamicUIConstraintSplitscreenOverride) == 0x30, "Size mismatch for UDynamicUIConstraintSplitscreenOverride");
static_assert(offsetof(UDynamicUIConstraintSplitscreenOverride, SplitscreenConstraintOverride) == 0x28, "Offset mismatch for UDynamicUIConstraintSplitscreenOverride::SplitscreenConstraintOverride");

// Size: 0x98 (Inherited: 0x88, Single: 0x10)
class UDynamicUIManager : public UWorldSubsystem
{
public:
    uint8_t Pad_30[0x18]; // 0x30 (Size: 0x18, Type: PaddingProperty)
    TMap<FDynamicUIPlayerData, TWeakObjectPtr<ULocalPlayer*>> PlayerDataMap; // 0x48 (Size: 0x50, Type: MapProperty)

protected:
    void AddScene(UDynamicUIScene*& const Scene, APlayerController* Player); // 0xc053b30 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    void AddScenes(TArray<UDynamicUIScene*>& const Scenes, APlayerController* Player); // 0xc0542a4 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    void AddSceneToFirstLocalPlayer(UDynamicUIScene*& const Scene); // 0xc053ec8 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
    bool IsSceneActive(UDynamicUIScene*& const Scene, APlayerController* Player) const; // 0xc054a5c (Index: 0x3, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool IsSceneActiveOnFirstLocalPlayer(UDynamicUIScene*& const Scene) const; // 0xc054e00 (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void RemoveScene(UDynamicUIScene*& const Scene, APlayerController* Player); // 0x525a6d0 (Index: 0x5, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    void RemoveSceneFromFirstLocalPlayer(UDynamicUIScene*& const Scene); // 0xc055088 (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable)
    void RemoveScenes(TArray<UDynamicUIScene*>& const Scenes, APlayerController* Player); // 0xc055464 (Index: 0x7, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UDynamicUIManager) == 0x98, "Size mismatch for UDynamicUIManager");
static_assert(offsetof(UDynamicUIManager, PlayerDataMap) == 0x48, "Offset mismatch for UDynamicUIManager::PlayerDataMap");

// Size: 0x78 (Inherited: 0x58, Single: 0x20)
class UDynamicUIScene : public UDataAsset
{
public:
    char LayerId; // 0x30 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    TArray<FDynamicUIAllowed> Allowed; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<UDynamicUIUnallowBase*> Unallow; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FDynamicUIAdjust> Adjust; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FDynamicUIPreload> Preload; // 0x68 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDynamicUIScene) == 0x78, "Size mismatch for UDynamicUIScene");
static_assert(offsetof(UDynamicUIScene, LayerId) == 0x30, "Offset mismatch for UDynamicUIScene::LayerId");
static_assert(offsetof(UDynamicUIScene, Allowed) == 0x38, "Offset mismatch for UDynamicUIScene::Allowed");
static_assert(offsetof(UDynamicUIScene, Unallow) == 0x48, "Offset mismatch for UDynamicUIScene::Unallow");
static_assert(offsetof(UDynamicUIScene, Adjust) == 0x58, "Offset mismatch for UDynamicUIScene::Adjust");
static_assert(offsetof(UDynamicUIScene, Preload) == 0x68, "Offset mismatch for UDynamicUIScene::Preload");

// Size: 0x60 (Inherited: 0x28, Single: 0x38)
class UDynamicUISizeBase : public UObject
{
public:
    uint8_t Pad_28[0x28]; // 0x28 (Size: 0x28, Type: PaddingProperty)
    UDynamicUISizeOverrideBase* SizeOverride; // 0x50 (Size: 0x8, Type: ObjectProperty)
    uint8_t bUseOverride : 1; // 0x58:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseRenderTransform : 1; // 0x58:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUISizeBase) == 0x60, "Size mismatch for UDynamicUISizeBase");
static_assert(offsetof(UDynamicUISizeBase, SizeOverride) == 0x50, "Offset mismatch for UDynamicUISizeBase::SizeOverride");
static_assert(offsetof(UDynamicUISizeBase, bUseOverride) == 0x58, "Offset mismatch for UDynamicUISizeBase::bUseOverride");
static_assert(offsetof(UDynamicUISizeBase, bUseRenderTransform) == 0x58, "Offset mismatch for UDynamicUISizeBase::bUseRenderTransform");

// Size: 0x68 (Inherited: 0x88, Single: 0xffffffe0)
class UDynamicUISizeFixed : public UDynamicUISizeBase
{
public:
    FVector2f Size; // 0x60 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(UDynamicUISizeFixed) == 0x68, "Size mismatch for UDynamicUISizeFixed");
static_assert(offsetof(UDynamicUISizeFixed, Size) == 0x60, "Offset mismatch for UDynamicUISizeFixed::Size");

// Size: 0x68 (Inherited: 0x88, Single: 0xffffffe0)
class UDynamicUISizeScale : public UDynamicUISizeBase
{
public:
    FVector2f Scale; // 0x60 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(UDynamicUISizeScale) == 0x68, "Size mismatch for UDynamicUISizeScale");
static_assert(offsetof(UDynamicUISizeScale, Scale) == 0x60, "Offset mismatch for UDynamicUISizeScale::Scale");

// Size: 0xf8 (Inherited: 0x88, Single: 0x70)
class UDynamicUISizeMatchWidget : public UDynamicUISizeBase
{
public:
    FDynamicUIWidgetTarget TargetWidget; // 0x60 (Size: 0x78, Type: StructProperty)
    uint8_t MatchType[0x4]; // 0xd8 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_dc[0x4]; // 0xdc (Size: 0x4, Type: PaddingProperty)
    TArray<UDynamicUISizeBase*> Fallbacks; // 0xe0 (Size: 0x10, Type: ArrayProperty)
    uint8_t bUseFallbacks : 1; // 0xf0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f1[0x7]; // 0xf1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUISizeMatchWidget) == 0xf8, "Size mismatch for UDynamicUISizeMatchWidget");
static_assert(offsetof(UDynamicUISizeMatchWidget, TargetWidget) == 0x60, "Offset mismatch for UDynamicUISizeMatchWidget::TargetWidget");
static_assert(offsetof(UDynamicUISizeMatchWidget, MatchType) == 0xd8, "Offset mismatch for UDynamicUISizeMatchWidget::MatchType");
static_assert(offsetof(UDynamicUISizeMatchWidget, Fallbacks) == 0xe0, "Offset mismatch for UDynamicUISizeMatchWidget::Fallbacks");
static_assert(offsetof(UDynamicUISizeMatchWidget, bUseFallbacks) == 0xf0, "Offset mismatch for UDynamicUISizeMatchWidget::bUseFallbacks");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDynamicUISizeOverrideBase : public UObject
{
public:
};

static_assert(sizeof(UDynamicUISizeOverrideBase) == 0x28, "Size mismatch for UDynamicUISizeOverrideBase");

// Size: 0xd0 (Inherited: 0x50, Single: 0x80)
class UDynamicUISizeOverridePlatform : public UDynamicUISizeOverrideBase
{
public:
    TMap<UDynamicUISizeBase*, FName> PlatformOverrides; // 0x28 (Size: 0x50, Type: MapProperty)
    TMap<UDynamicUISizeBase*, ECommonInputType> InputTypeOverrides; // 0x78 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUISizeOverridePlatform) == 0xd0, "Size mismatch for UDynamicUISizeOverridePlatform");
static_assert(offsetof(UDynamicUISizeOverridePlatform, PlatformOverrides) == 0x28, "Offset mismatch for UDynamicUISizeOverridePlatform::PlatformOverrides");
static_assert(offsetof(UDynamicUISizeOverridePlatform, InputTypeOverrides) == 0x78, "Offset mismatch for UDynamicUISizeOverridePlatform::InputTypeOverrides");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UDynamicUISizeSplitscreenOverride : public UDynamicUISizeOverrideBase
{
public:
    UDynamicUISizeBase* SplitscreenSizeModifier; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDynamicUISizeSplitscreenOverride) == 0x30, "Size mismatch for UDynamicUISizeSplitscreenOverride");
static_assert(offsetof(UDynamicUISizeSplitscreenOverride, SplitscreenSizeModifier) == 0x28, "Offset mismatch for UDynamicUISizeSplitscreenOverride::SplitscreenSizeModifier");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UDynamicUIUnallowBase : public UObject
{
public:
    uint8_t Behavior[0x4]; // 0x28 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    TArray<UDynamicUIExcludeBase*> ExcludeConditions; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t bUseExclude : 1; // 0x40:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUIUnallowBase) == 0x48, "Size mismatch for UDynamicUIUnallowBase");
static_assert(offsetof(UDynamicUIUnallowBase, Behavior) == 0x28, "Offset mismatch for UDynamicUIUnallowBase::Behavior");
static_assert(offsetof(UDynamicUIUnallowBase, ExcludeConditions) == 0x30, "Offset mismatch for UDynamicUIUnallowBase::ExcludeConditions");
static_assert(offsetof(UDynamicUIUnallowBase, bUseExclude) == 0x40, "Offset mismatch for UDynamicUIUnallowBase::bUseExclude");

// Size: 0xc8 (Inherited: 0x70, Single: 0x58)
class UDynamicUIUnallowWidget : public UDynamicUIUnallowBase
{
public:
    FDynamicUIWidgetTarget Widget; // 0x48 (Size: 0x78, Type: StructProperty)
    uint8_t bTargetAll : 1; // 0xc0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0x7]; // 0xc1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUIUnallowWidget) == 0xc8, "Size mismatch for UDynamicUIUnallowWidget");
static_assert(offsetof(UDynamicUIUnallowWidget, Widget) == 0x48, "Offset mismatch for UDynamicUIUnallowWidget::Widget");
static_assert(offsetof(UDynamicUIUnallowWidget, bTargetAll) == 0xc0, "Offset mismatch for UDynamicUIUnallowWidget::bTargetAll");

// Size: 0x50 (Inherited: 0x70, Single: 0xffffffe0)
class UDynamicUIUnallowLayer : public UDynamicUIUnallowBase
{
public:
    char LayerId; // 0x48 (Size: 0x1, Type: ByteProperty)
    uint8_t Comparison; // 0x49 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_4a[0x6]; // 0x4a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUIUnallowLayer) == 0x50, "Size mismatch for UDynamicUIUnallowLayer");
static_assert(offsetof(UDynamicUIUnallowLayer, LayerId) == 0x48, "Offset mismatch for UDynamicUIUnallowLayer::LayerId");
static_assert(offsetof(UDynamicUIUnallowLayer, Comparison) == 0x49, "Offset mismatch for UDynamicUIUnallowLayer::Comparison");

// Size: 0x110 (Inherited: 0x70, Single: 0xa0)
class UDynamicUIUnallowScene : public UDynamicUIUnallowBase
{
public:
    FDynamicUISceneTarget Scene; // 0x48 (Size: 0x18, Type: StructProperty)
    TArray<FDynamicUIWidgetTarget> Exclusions; // 0x60 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_70[0xa0]; // 0x70 (Size: 0xa0, Type: PaddingProperty)
};

static_assert(sizeof(UDynamicUIUnallowScene) == 0x110, "Size mismatch for UDynamicUIUnallowScene");
static_assert(offsetof(UDynamicUIUnallowScene, Scene) == 0x48, "Offset mismatch for UDynamicUIUnallowScene::Scene");
static_assert(offsetof(UDynamicUIUnallowScene, Exclusions) == 0x60, "Offset mismatch for UDynamicUIUnallowScene::Exclusions");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDynamicUIManagerDebug
{
};

static_assert(sizeof(FDynamicUIManagerDebug) == 0x1, "Size mismatch for FDynamicUIManagerDebug");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDynamicUIPanelDebug
{
};

static_assert(sizeof(FDynamicUIPanelDebug) == 0x1, "Size mismatch for FDynamicUIPanelDebug");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FDynamicUIAdjust
{
    FDynamicUIWidgetTarget TargetWidget; // 0x0 (Size: 0x78, Type: StructProperty)
    UDynamicUIConstraintBase* LayoutConstraint; // 0x78 (Size: 0x8, Type: ObjectProperty)
    UDynamicUISizeBase* SizeModifier; // 0x80 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDynamicUIAdjust) == 0x88, "Size mismatch for FDynamicUIAdjust");
static_assert(offsetof(FDynamicUIAdjust, TargetWidget) == 0x0, "Offset mismatch for FDynamicUIAdjust::TargetWidget");
static_assert(offsetof(FDynamicUIAdjust, LayoutConstraint) == 0x78, "Offset mismatch for FDynamicUIAdjust::LayoutConstraint");
static_assert(offsetof(FDynamicUIAdjust, SizeModifier) == 0x80, "Offset mismatch for FDynamicUIAdjust::SizeModifier");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FDynamicUIWidgetTarget
{
    FName WidgetPath; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FSoftObjectPath WidgetAssetPath; // 0x8 (Size: 0x18, Type: StructProperty)
    TSoftClassPtr WidgetClass; // 0x20 (Size: 0x20, Type: SoftClassProperty)
    FName UniqueID; // 0x40 (Size: 0x4, Type: NameProperty)
    uint8_t bUseWidgetClass : 1; // 0x44:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseUniqueID : 1; // 0x44:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_45[0x33]; // 0x45 (Size: 0x33, Type: PaddingProperty)
};

static_assert(sizeof(FDynamicUIWidgetTarget) == 0x78, "Size mismatch for FDynamicUIWidgetTarget");
static_assert(offsetof(FDynamicUIWidgetTarget, WidgetPath) == 0x0, "Offset mismatch for FDynamicUIWidgetTarget::WidgetPath");
static_assert(offsetof(FDynamicUIWidgetTarget, WidgetAssetPath) == 0x8, "Offset mismatch for FDynamicUIWidgetTarget::WidgetAssetPath");
static_assert(offsetof(FDynamicUIWidgetTarget, WidgetClass) == 0x20, "Offset mismatch for FDynamicUIWidgetTarget::WidgetClass");
static_assert(offsetof(FDynamicUIWidgetTarget, UniqueID) == 0x40, "Offset mismatch for FDynamicUIWidgetTarget::UniqueID");
static_assert(offsetof(FDynamicUIWidgetTarget, bUseWidgetClass) == 0x44, "Offset mismatch for FDynamicUIWidgetTarget::bUseWidgetClass");
static_assert(offsetof(FDynamicUIWidgetTarget, bUseUniqueID) == 0x44, "Offset mismatch for FDynamicUIWidgetTarget::bUseUniqueID");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FDynamicUIAllowed
{
    TSoftClassPtr Widget; // 0x0 (Size: 0x20, Type: SoftClassProperty)
    uint8_t ZOrder[0x4]; // 0x20 (Size: 0x4, Type: EnumProperty)
    int32_t CustomZOrder; // 0x24 (Size: 0x4, Type: IntProperty)
    FName UniqueID; // 0x28 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UCommonInputActionDomain*> ActionDomain; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    UDynamicUIConstraintBase* LayoutConstraint; // 0x50 (Size: 0x8, Type: ObjectProperty)
    UDynamicUISizeBase* SizeModifier; // 0x58 (Size: 0x8, Type: ObjectProperty)
    TArray<UDynamicUIExcludeBase*> ExcludeConditions; // 0x60 (Size: 0x10, Type: ArrayProperty)
    char LayerIDOverride; // 0x70 (Size: 0x1, Type: ByteProperty)
    uint8_t bIsUnique : 1; // 0x71:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseActionDomain : 1; // 0x71:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseLayerOverride : 1; // 0x71:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseExclude : 1; // 0x71:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_72[0x6]; // 0x72 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FDynamicUIAllowed) == 0x78, "Size mismatch for FDynamicUIAllowed");
static_assert(offsetof(FDynamicUIAllowed, Widget) == 0x0, "Offset mismatch for FDynamicUIAllowed::Widget");
static_assert(offsetof(FDynamicUIAllowed, ZOrder) == 0x20, "Offset mismatch for FDynamicUIAllowed::ZOrder");
static_assert(offsetof(FDynamicUIAllowed, CustomZOrder) == 0x24, "Offset mismatch for FDynamicUIAllowed::CustomZOrder");
static_assert(offsetof(FDynamicUIAllowed, UniqueID) == 0x28, "Offset mismatch for FDynamicUIAllowed::UniqueID");
static_assert(offsetof(FDynamicUIAllowed, ActionDomain) == 0x30, "Offset mismatch for FDynamicUIAllowed::ActionDomain");
static_assert(offsetof(FDynamicUIAllowed, LayoutConstraint) == 0x50, "Offset mismatch for FDynamicUIAllowed::LayoutConstraint");
static_assert(offsetof(FDynamicUIAllowed, SizeModifier) == 0x58, "Offset mismatch for FDynamicUIAllowed::SizeModifier");
static_assert(offsetof(FDynamicUIAllowed, ExcludeConditions) == 0x60, "Offset mismatch for FDynamicUIAllowed::ExcludeConditions");
static_assert(offsetof(FDynamicUIAllowed, LayerIDOverride) == 0x70, "Offset mismatch for FDynamicUIAllowed::LayerIDOverride");
static_assert(offsetof(FDynamicUIAllowed, bIsUnique) == 0x71, "Offset mismatch for FDynamicUIAllowed::bIsUnique");
static_assert(offsetof(FDynamicUIAllowed, bUseActionDomain) == 0x71, "Offset mismatch for FDynamicUIAllowed::bUseActionDomain");
static_assert(offsetof(FDynamicUIAllowed, bUseLayerOverride) == 0x71, "Offset mismatch for FDynamicUIAllowed::bUseLayerOverride");
static_assert(offsetof(FDynamicUIAllowed, bUseExclude) == 0x71, "Offset mismatch for FDynamicUIAllowed::bUseExclude");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDynamicUIAspectRatio
{
    uint8_t AspectRatio[0x4]; // 0x0 (Size: 0x4, Type: EnumProperty)
    float CustomAspectRatio; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDynamicUIAspectRatio) == 0x8, "Size mismatch for FDynamicUIAspectRatio");
static_assert(offsetof(FDynamicUIAspectRatio, AspectRatio) == 0x0, "Offset mismatch for FDynamicUIAspectRatio::AspectRatio");
static_assert(offsetof(FDynamicUIAspectRatio, CustomAspectRatio) == 0x4, "Offset mismatch for FDynamicUIAspectRatio::CustomAspectRatio");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDynamicUIVerticalMargin
{
    float Top; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Bottom; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDynamicUIVerticalMargin) == 0x8, "Size mismatch for FDynamicUIVerticalMargin");
static_assert(offsetof(FDynamicUIVerticalMargin, Top) == 0x0, "Offset mismatch for FDynamicUIVerticalMargin::Top");
static_assert(offsetof(FDynamicUIVerticalMargin, Bottom) == 0x4, "Offset mismatch for FDynamicUIVerticalMargin::Bottom");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDynamicUIHorizontalMargin
{
    float Left; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Right; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDynamicUIHorizontalMargin) == 0x8, "Size mismatch for FDynamicUIHorizontalMargin");
static_assert(offsetof(FDynamicUIHorizontalMargin, Left) == 0x0, "Offset mismatch for FDynamicUIHorizontalMargin::Left");
static_assert(offsetof(FDynamicUIHorizontalMargin, Right) == 0x4, "Offset mismatch for FDynamicUIHorizontalMargin::Right");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDynamicUIPreload
{
    TSoftClassPtr Widget; // 0x0 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FDynamicUIPreload) == 0x20, "Size mismatch for FDynamicUIPreload");
static_assert(offsetof(FDynamicUIPreload, Widget) == 0x0, "Offset mismatch for FDynamicUIPreload::Widget");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDynamicUISceneTarget
{
    FSoftObjectPath SceneAssetPath; // 0x0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDynamicUISceneTarget) == 0x18, "Size mismatch for FDynamicUISceneTarget");
static_assert(offsetof(FDynamicUISceneTarget, SceneAssetPath) == 0x0, "Offset mismatch for FDynamicUISceneTarget::SceneAssetPath");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FDynamicUISceneData
{
};

static_assert(sizeof(FDynamicUISceneData) == 0x1, "Size mismatch for FDynamicUISceneData");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDynamicUIDirectorData
{
    TSoftClassPtr DirectorClass; // 0x0 (Size: 0x20, Type: SoftClassProperty)
    TWeakObjectPtr<AActor*> Instance; // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FDynamicUIDirectorData) == 0x30, "Size mismatch for FDynamicUIDirectorData");
static_assert(offsetof(FDynamicUIDirectorData, DirectorClass) == 0x0, "Offset mismatch for FDynamicUIDirectorData::DirectorClass");
static_assert(offsetof(FDynamicUIDirectorData, Instance) == 0x20, "Offset mismatch for FDynamicUIDirectorData::Instance");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FDynamicUIPlayerData
{
    TMap<FDynamicUIDirectorData, FString> ActiveDirectors; // 0x40 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FDynamicUIPlayerData) == 0x90, "Size mismatch for FDynamicUIPlayerData");
static_assert(offsetof(FDynamicUIPlayerData, ActiveDirectors) == 0x40, "Offset mismatch for FDynamicUIPlayerData::ActiveDirectors");

