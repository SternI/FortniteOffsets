/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AINavigation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "MassEntity.h"
#include "MassSignals.h"
#include "CoreUObject.h"
#include "NavigationSystem.h"

// Size: 0x400 (Inherited: 0xd8, Single: 0x328)
class UNavigationElementProcessor : public UMassProcessor
{
public:
};

static_assert(sizeof(UNavigationElementProcessor) == 0x400, "Size mismatch for UNavigationElementProcessor");

// Size: 0x4c0 (Inherited: 0x598, Single: 0xffffff28)
class UDirtyNavigationRelevantUpdateProcessor : public UMassSignalProcessorBase
{
public:
};

static_assert(sizeof(UDirtyNavigationRelevantUpdateProcessor) == 0x4c0, "Size mismatch for UDirtyNavigationRelevantUpdateProcessor");

// Size: 0x420 (Inherited: 0x1a0, Single: 0x280)
class UNavigationRelevantMassDeinitializer : public UMassObserverProcessor
{
public:
};

static_assert(sizeof(UNavigationRelevantMassDeinitializer) == 0x420, "Size mismatch for UNavigationRelevantMassDeinitializer");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UNavigationFilter : public UObject
{
public:
};

static_assert(sizeof(UNavigationFilter) == 0x28, "Size mismatch for UNavigationFilter");

// Size: 0x58 (Inherited: 0x70, Single: 0xffffffe8)
class UCompositeNavigationQuery : public UNavigationQueryFilter
{
public:
    TArray<UNavigationFilter*> NavigationFilters; // 0x48 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCompositeNavigationQuery) == 0x58, "Size mismatch for UCompositeNavigationQuery");
static_assert(offsetof(UCompositeNavigationQuery, NavigationFilters) == 0x48, "Offset mismatch for UCompositeNavigationQuery::NavigationFilters");

