/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BikeKidUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "DynamicUI.h"
#include "BikeKidRuntime.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "Engine.h"

// Size: 0xa0 (Inherited: 0xf8, Single: 0xffffffa8)
class UFortMobileActionButtonBehaviorExtension_BikeKidUse : public UFortMobileActionButtonBehaviorExtension
{
public:
    FGameplayTagContainer ContextTagToCheck; // 0x80 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UFortMobileActionButtonBehaviorExtension_BikeKidUse) == 0xa0, "Size mismatch for UFortMobileActionButtonBehaviorExtension_BikeKidUse");
static_assert(offsetof(UFortMobileActionButtonBehaviorExtension_BikeKidUse, ContextTagToCheck) == 0x80, "Offset mismatch for UFortMobileActionButtonBehaviorExtension_BikeKidUse::ContextTagToCheck");

// Size: 0x3a8 (Inherited: 0x458, Single: 0xffffff50)
class UBikeKidHUD : public UUserWidget
{
public:
    float TimeToConfirmTargetCache; // 0x2b0 (Size: 0x4, Type: FloatProperty)
    float InitialHealth; // 0x2b4 (Size: 0x4, Type: FloatProperty)
    FScalableFloat WarningRange; // 0x2b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat SignalLossRange; // 0x2e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat UpdateSignalInterval; // 0x308 (Size: 0x28, Type: StructProperty)
    FGameplayTag MarkAbilityTag; // 0x330 (Size: 0x4, Type: StructProperty)
    FGameplayTag DismissAbilityTag; // 0x334 (Size: 0x4, Type: StructProperty)
    FGameplayTag SpeedBoostAbilityTag; // 0x338 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_33c[0x4]; // 0x33c (Size: 0x4, Type: PaddingProperty)
    UOverlay* Overlay_Health; // 0x340 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_EnergyLevel; // 0x348 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Reticle; // 0x350 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_TetheringIndicator; // 0x358 (Size: 0x8, Type: ObjectProperty)
    float MaxHealthCache; // 0x360 (Size: 0x4, Type: FloatProperty)
    float MaxEnergyCache; // 0x364 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_368[0x28]; // 0x368 (Size: 0x28, Type: PaddingProperty)
    FTimerHandle SignalDataTimerHandle; // 0x390 (Size: 0x8, Type: StructProperty)
    TArray<FBikeKidWidgetIdentifier> HUDIdentifiers; // 0x398 (Size: 0x10, Type: ArrayProperty)

private:
    float GetTargetConfirmationTime(); // 0x1126b5c4 (Index: 0x1, Flags: Final|Native|Private|BlueprintCallable)

protected:
    AFortBikeKid* GetControlledBikeKid() const; // 0x1126b5a0 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnBikeKidDismissAbilityUsed(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnBikeKidEnergyChanged(float& EnergyPercentage); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnBikeKidHealthUpdated(float& HealthPercentage, float& CurrentHealth); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void OnBikeKidMarkAbilityEnd(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void OnBikeKidMarkAbilityUsed(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void OnBikeKidSignalDataUpdated(float& DistanceFromPlayer, float& SignalPercentage); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void OnBikeKidSpeedBoostAbilityEnd(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void OnBikeKidSpeedBoostAbilityUsed(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void OnOwningPlayerDamaged(); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void OnReticleChangeAbilityActivated(FGameplayTag& const UpdatedTag); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTargetingStatusChanged(const FBikeKidStatusData StatusData); // 0x288a61c (Index: 0xc, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UBikeKidHUD) == 0x3a8, "Size mismatch for UBikeKidHUD");
static_assert(offsetof(UBikeKidHUD, TimeToConfirmTargetCache) == 0x2b0, "Offset mismatch for UBikeKidHUD::TimeToConfirmTargetCache");
static_assert(offsetof(UBikeKidHUD, InitialHealth) == 0x2b4, "Offset mismatch for UBikeKidHUD::InitialHealth");
static_assert(offsetof(UBikeKidHUD, WarningRange) == 0x2b8, "Offset mismatch for UBikeKidHUD::WarningRange");
static_assert(offsetof(UBikeKidHUD, SignalLossRange) == 0x2e0, "Offset mismatch for UBikeKidHUD::SignalLossRange");
static_assert(offsetof(UBikeKidHUD, UpdateSignalInterval) == 0x308, "Offset mismatch for UBikeKidHUD::UpdateSignalInterval");
static_assert(offsetof(UBikeKidHUD, MarkAbilityTag) == 0x330, "Offset mismatch for UBikeKidHUD::MarkAbilityTag");
static_assert(offsetof(UBikeKidHUD, DismissAbilityTag) == 0x334, "Offset mismatch for UBikeKidHUD::DismissAbilityTag");
static_assert(offsetof(UBikeKidHUD, SpeedBoostAbilityTag) == 0x338, "Offset mismatch for UBikeKidHUD::SpeedBoostAbilityTag");
static_assert(offsetof(UBikeKidHUD, Overlay_Health) == 0x340, "Offset mismatch for UBikeKidHUD::Overlay_Health");
static_assert(offsetof(UBikeKidHUD, Overlay_EnergyLevel) == 0x348, "Offset mismatch for UBikeKidHUD::Overlay_EnergyLevel");
static_assert(offsetof(UBikeKidHUD, Overlay_Reticle) == 0x350, "Offset mismatch for UBikeKidHUD::Overlay_Reticle");
static_assert(offsetof(UBikeKidHUD, Overlay_TetheringIndicator) == 0x358, "Offset mismatch for UBikeKidHUD::Overlay_TetheringIndicator");
static_assert(offsetof(UBikeKidHUD, MaxHealthCache) == 0x360, "Offset mismatch for UBikeKidHUD::MaxHealthCache");
static_assert(offsetof(UBikeKidHUD, MaxEnergyCache) == 0x364, "Offset mismatch for UBikeKidHUD::MaxEnergyCache");
static_assert(offsetof(UBikeKidHUD, SignalDataTimerHandle) == 0x390, "Offset mismatch for UBikeKidHUD::SignalDataTimerHandle");
static_assert(offsetof(UBikeKidHUD, HUDIdentifiers) == 0x398, "Offset mismatch for UBikeKidHUD::HUDIdentifiers");

// Size: 0x2d0 (Inherited: 0x458, Single: 0xfffffe78)
class UBikeKidTetherIndicator : public UUserWidget
{
public:

protected:
    virtual void BP_OnEnterSignalLossRange(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnEnterWarningRange(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnExitWarningRange(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_WhileInWarningRange(float& SignalIntensityPercentage); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    AFortBikeKid* GetControlledBikeKid() const; // 0x1126b5a0 (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UBikeKidTetherIndicator) == 0x2d0, "Size mismatch for UBikeKidTetherIndicator");

// Size: 0x2e8 (Inherited: 0x598, Single: 0xfffffd50)
class ABikeKidUIDirector : public ADynamicUIDirectorBase
{
public:
    FGameplayTagContainer HUDTagsToHide; // 0x2c8 (Size: 0x20, Type: StructProperty)

protected:
    virtual void BP_OnBikeKidDeployed(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnBikeKidDismissed(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABikeKidUIDirector) == 0x2e8, "Size mismatch for ABikeKidUIDirector");
static_assert(offsetof(ABikeKidUIDirector, HUDTagsToHide) == 0x2c8, "Offset mismatch for ABikeKidUIDirector::HUDTagsToHide");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FBikeKidWidgetIdentifier
{
    FGameplayTagContainer Tags; // 0x0 (Size: 0x20, Type: StructProperty)
    TWeakObjectPtr<UWidget*> WeakWdiget; // 0x20 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FBikeKidWidgetIdentifier) == 0x28, "Size mismatch for FBikeKidWidgetIdentifier");
static_assert(offsetof(FBikeKidWidgetIdentifier, Tags) == 0x0, "Offset mismatch for FBikeKidWidgetIdentifier::Tags");
static_assert(offsetof(FBikeKidWidgetIdentifier, WeakWdiget) == 0x20, "Offset mismatch for FBikeKidWidgetIdentifier::WeakWdiget");

