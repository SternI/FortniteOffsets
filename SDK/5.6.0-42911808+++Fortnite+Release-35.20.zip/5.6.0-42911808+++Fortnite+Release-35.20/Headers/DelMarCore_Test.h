/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarCore_Test
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "DelMarCore.h"

// Size: 0xc0 (Inherited: 0xb0, Single: 0x10)
class UDelMarTestControllerTrackScrubber : public UFortTestControllerBase
{
public:

protected:
    void ReceiveRaceBeginEvent(const FDelMarEvent_RaceActive Event); // 0x11cf96a8 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void ReceiveTrackScrubberCompletedProfiling(); // 0x11cf976c (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarTestControllerTrackScrubber) == 0xc0, "Size mismatch for UDelMarTestControllerTrackScrubber");

