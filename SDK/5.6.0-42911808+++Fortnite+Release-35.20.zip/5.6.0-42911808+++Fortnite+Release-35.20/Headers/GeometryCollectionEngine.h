/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GeometryCollectionEngine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "DataflowEngine.h"
#include "ChaosSolverEngine.h"
#include "ISMPool.h"
#include "Chaos.h"
#include "FieldSystemEngine.h"
#include "PhysicsCore.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryCollectionBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void SetCustomInstanceDataByIndex(UGeometryCollectionComponent*& GeometryCollectionComponent, int32_t& CustomDataIndex, float& CustomDataValue); // 0x9f430f4 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SetCustomInstanceDataByName(UGeometryCollectionComponent*& GeometryCollectionComponent, FName& CustomDataName, float& CustomDataValue); // 0x9f43404 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SetISMPoolCustomInstanceData(UGeometryCollectionComponent*& GeometryCollectionComponent, int32_t& CustomDataIndex, float& CustomDataValue); // 0x9f430f4 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryCollectionBlueprintLibrary) == 0x28, "Size mismatch for UGeometryCollectionBlueprintLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryCollectionExternalRenderInterface : public UInterface
{
public:
};

static_assert(sizeof(UGeometryCollectionExternalRenderInterface) == 0x28, "Size mismatch for UGeometryCollectionExternalRenderInterface");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryCollectionCustomDataInterface : public UInterface
{
public:
};

static_assert(sizeof(UGeometryCollectionCustomDataInterface) == 0x28, "Size mismatch for UGeometryCollectionCustomDataInterface");

// Size: 0x80 (Inherited: 0x88, Single: 0xfffffff8)
class UGeometryCollectionISMPoolSubSystem : public UWorldSubsystem
{
public:

protected:
    void OnActorEndPlay(AActor*& InSource, TEnumAsByte<EEndPlayReason>& Reason); // 0x9f41cd0 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UGeometryCollectionISMPoolSubSystem) == 0x80, "Size mismatch for UGeometryCollectionISMPoolSubSystem");

// Size: 0x4f0 (Inherited: 0x320, Single: 0x1d0)
class UChaosDestructionListener : public USceneComponent
{
public:
    uint8_t bIsCollisionEventListeningEnabled : 1; // 0x240:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsBreakingEventListeningEnabled : 1; // 0x240:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsTrailingEventListeningEnabled : 1; // 0x240:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsRemovalEventListeningEnabled : 1; // 0x240:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_241[0x3]; // 0x241 (Size: 0x3, Type: PaddingProperty)
    FChaosCollisionEventRequestSettings CollisionEventRequestSettings; // 0x244 (Size: 0x18, Type: StructProperty)
    FChaosBreakingEventRequestSettings BreakingEventRequestSettings; // 0x25c (Size: 0x18, Type: StructProperty)
    FChaosTrailingEventRequestSettings TrailingEventRequestSettings; // 0x274 (Size: 0x18, Type: StructProperty)
    FChaosRemovalEventRequestSettings RemovalEventRequestSettings; // 0x28c (Size: 0x10, Type: StructProperty)
    uint8_t Pad_29c[0x4]; // 0x29c (Size: 0x4, Type: PaddingProperty)
    TSet<AChaosSolverActor*> ChaosSolverActors; // 0x2a0 (Size: 0x50, Type: SetProperty)
    TSet<AGeometryCollectionActor*> GeometryCollectionActors; // 0x2f0 (Size: 0x50, Type: SetProperty)
    uint8_t OnCollisionEvents[0x10]; // 0x340 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBreakingEvents[0x10]; // 0x350 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTrailingEvents[0x10]; // 0x360 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRemovalEvents[0x10]; // 0x370 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_380[0x170]; // 0x380 (Size: 0x170, Type: PaddingProperty)

public:
    void AddChaosSolverActor(AChaosSolverActor*& ChaosSolverActor); // 0x6023a08 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void AddGeometryCollectionActor(AGeometryCollectionActor*& GeometryCollectionActor); // 0x9f3f230 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    bool IsEventListening() const; // 0x9f41c9c (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RemoveChaosSolverActor(AChaosSolverActor*& ChaosSolverActor); // 0x6023a08 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void RemoveGeometryCollectionActor(AGeometryCollectionActor*& GeometryCollectionActor); // 0x9f42130 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetBreakingEventEnabled(bool& bIsEnabled); // 0x9f42c98 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetBreakingEventRequestSettings(const FChaosBreakingEventRequestSettings InSettings); // 0x9f42dd8 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetCollisionEventEnabled(bool& bIsEnabled); // 0x9f42ec8 (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetCollisionEventRequestSettings(const FChaosCollisionEventRequestSettings InSettings); // 0x9f43004 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetRemovalEventEnabled(bool& bIsEnabled); // 0x9f45408 (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetRemovalEventRequestSettings(const FChaosRemovalEventRequestSettings InSettings); // 0x9f45548 (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetTrailingEventEnabled(bool& bIsEnabled); // 0x9f461c4 (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetTrailingEventRequestSettings(const FChaosTrailingEventRequestSettings InSettings); // 0x9f46304 (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SortBreakingEvents(TArray<FChaosBreakingEventData> BreakingEvents, EChaosBreakingSortMethod& SortMethod); // 0x9f46668 (Index: 0xd, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SortCollisionEvents(TArray<FChaosCollisionEventData> CollisionEvents, EChaosCollisionSortMethod& SortMethod); // 0x9f46968 (Index: 0xe, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SortRemovalEvents(TArray<FChaosRemovalEventData> RemovalEvents, EChaosRemovalSortMethod& SortMethod); // 0x9f46c68 (Index: 0xf, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SortTrailingEvents(TArray<FChaosTrailingEventData> TrailingEvents, EChaosTrailingSortMethod& SortMethod); // 0x9f46f68 (Index: 0x10, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UChaosDestructionListener) == 0x4f0, "Size mismatch for UChaosDestructionListener");
static_assert(offsetof(UChaosDestructionListener, bIsCollisionEventListeningEnabled) == 0x240, "Offset mismatch for UChaosDestructionListener::bIsCollisionEventListeningEnabled");
static_assert(offsetof(UChaosDestructionListener, bIsBreakingEventListeningEnabled) == 0x240, "Offset mismatch for UChaosDestructionListener::bIsBreakingEventListeningEnabled");
static_assert(offsetof(UChaosDestructionListener, bIsTrailingEventListeningEnabled) == 0x240, "Offset mismatch for UChaosDestructionListener::bIsTrailingEventListeningEnabled");
static_assert(offsetof(UChaosDestructionListener, bIsRemovalEventListeningEnabled) == 0x240, "Offset mismatch for UChaosDestructionListener::bIsRemovalEventListeningEnabled");
static_assert(offsetof(UChaosDestructionListener, CollisionEventRequestSettings) == 0x244, "Offset mismatch for UChaosDestructionListener::CollisionEventRequestSettings");
static_assert(offsetof(UChaosDestructionListener, BreakingEventRequestSettings) == 0x25c, "Offset mismatch for UChaosDestructionListener::BreakingEventRequestSettings");
static_assert(offsetof(UChaosDestructionListener, TrailingEventRequestSettings) == 0x274, "Offset mismatch for UChaosDestructionListener::TrailingEventRequestSettings");
static_assert(offsetof(UChaosDestructionListener, RemovalEventRequestSettings) == 0x28c, "Offset mismatch for UChaosDestructionListener::RemovalEventRequestSettings");
static_assert(offsetof(UChaosDestructionListener, ChaosSolverActors) == 0x2a0, "Offset mismatch for UChaosDestructionListener::ChaosSolverActors");
static_assert(offsetof(UChaosDestructionListener, GeometryCollectionActors) == 0x2f0, "Offset mismatch for UChaosDestructionListener::GeometryCollectionActors");
static_assert(offsetof(UChaosDestructionListener, OnCollisionEvents) == 0x340, "Offset mismatch for UChaosDestructionListener::OnCollisionEvents");
static_assert(offsetof(UChaosDestructionListener, OnBreakingEvents) == 0x350, "Offset mismatch for UChaosDestructionListener::OnBreakingEvents");
static_assert(offsetof(UChaosDestructionListener, OnTrailingEvents) == 0x360, "Offset mismatch for UChaosDestructionListener::OnTrailingEvents");
static_assert(offsetof(UChaosDestructionListener, OnRemovalEvents) == 0x370, "Offset mismatch for UChaosDestructionListener::OnRemovalEvents");

// Size: 0x2b8 (Inherited: 0x2d0, Single: 0xffffffe8)
class AGeometryCollectionActor : public AActor
{
public:
    UGeometryCollectionComponent* GeometryCollectionComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UGeometryCollectionDebugDrawComponent* GeometryCollectionDebugDrawComponent; // 0x2b0 (Size: 0x8, Type: ObjectProperty)

public:
    bool RaycastSingle(FVector& Start, FVector& End, FHitResult& OutHit) const; // 0x9f41f18 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(AGeometryCollectionActor) == 0x2b8, "Size mismatch for AGeometryCollectionActor");
static_assert(offsetof(AGeometryCollectionActor, GeometryCollectionComponent) == 0x2a8, "Offset mismatch for AGeometryCollectionActor::GeometryCollectionComponent");
static_assert(offsetof(AGeometryCollectionActor, GeometryCollectionDebugDrawComponent) == 0x2b0, "Offset mismatch for AGeometryCollectionActor::GeometryCollectionDebugDrawComponent");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UGeometryCollectionCache : public UObject
{
public:
    FRecordedTransformTrack RecordedData; // 0x28 (Size: 0x10, Type: StructProperty)
    UGeometryCollection* SupportedCollection; // 0x38 (Size: 0x8, Type: ObjectProperty)
    FGuid CompatibleCollectionState; // 0x40 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UGeometryCollectionCache) == 0x50, "Size mismatch for UGeometryCollectionCache");
static_assert(offsetof(UGeometryCollectionCache, RecordedData) == 0x28, "Offset mismatch for UGeometryCollectionCache::RecordedData");
static_assert(offsetof(UGeometryCollectionCache, SupportedCollection) == 0x38, "Offset mismatch for UGeometryCollectionCache::SupportedCollection");
static_assert(offsetof(UGeometryCollectionCache, CompatibleCollectionState) == 0x40, "Offset mismatch for UGeometryCollectionCache::CompatibleCollectionState");

// Size: 0xa00 (Inherited: 0xda0, Single: 0xfffffc60)
class UGeometryCollectionComponent : public UMeshComponent
{
public:
    uint8_t Pad_560[0x8]; // 0x560 (Size: 0x8, Type: PaddingProperty)
    AChaosSolverActor* ChaosSolverActor; // 0x568 (Size: 0x8, Type: ObjectProperty)
    UGeometryCollection* RestCollection; // 0x570 (Size: 0x8, Type: ObjectProperty)
    TArray<AFieldSystemActor*> InitializationFields; // 0x578 (Size: 0x10, Type: ArrayProperty)
    bool Simulating; // 0x588 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_589[0x1]; // 0x589 (Size: 0x1, Type: PaddingProperty)
    uint8_t ObjectType; // 0x58a (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_58b[0x1]; // 0x58b (Size: 0x1, Type: PaddingProperty)
    int32_t GravityGroupIndex; // 0x58c (Size: 0x4, Type: IntProperty)
    int32_t OneWayInteractionLevel; // 0x590 (Size: 0x4, Type: IntProperty)
    bool bDensityFromPhysicsMaterial; // 0x594 (Size: 0x1, Type: BoolProperty)
    bool bForceMotionBlur; // 0x595 (Size: 0x1, Type: BoolProperty)
    bool EnableClustering; // 0x596 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_597[0x1]; // 0x597 (Size: 0x1, Type: PaddingProperty)
    int32_t ClusterGroupIndex; // 0x598 (Size: 0x4, Type: IntProperty)
    int32_t MaxClusterLevel; // 0x59c (Size: 0x4, Type: IntProperty)
    int32_t MaxSimulatedLevel; // 0x5a0 (Size: 0x4, Type: IntProperty)
    uint8_t DamageModel; // 0x5a4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5a5[0x3]; // 0x5a5 (Size: 0x3, Type: PaddingProperty)
    TArray<float> DamageThreshold; // 0x5a8 (Size: 0x10, Type: ArrayProperty)
    bool bUseSizeSpecificDamageThreshold; // 0x5b8 (Size: 0x1, Type: BoolProperty)
    bool bUseMaterialDamageModifiers; // 0x5b9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5ba[0x2]; // 0x5ba (Size: 0x2, Type: PaddingProperty)
    FGeometryCollectionDamagePropagationData DamagePropagationData; // 0x5bc (Size: 0xc, Type: StructProperty)
    bool bEnableDamageFromCollision; // 0x5c8 (Size: 0x1, Type: BoolProperty)
    bool bAllowRemovalOnSleep; // 0x5c9 (Size: 0x1, Type: BoolProperty)
    bool bAllowRemovalOnBreak; // 0x5ca (Size: 0x1, Type: BoolProperty)
    bool bForceUpdateActiveTransforms; // 0x5cb (Size: 0x1, Type: BoolProperty)
    uint8_t ClusterConnectionType; // 0x5cc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5cd[0x3]; // 0x5cd (Size: 0x3, Type: PaddingProperty)
    int32_t CollisionGroup; // 0x5d0 (Size: 0x4, Type: IntProperty)
    float CollisionSampleFraction; // 0x5d4 (Size: 0x4, Type: FloatProperty)
    float LinearEtherDrag; // 0x5d8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5dc[0x4]; // 0x5dc (Size: 0x4, Type: PaddingProperty)
    UChaosPhysicalMaterial* PhysicalMaterial; // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t InitialVelocityType; // 0x5e8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5e9[0x7]; // 0x5e9 (Size: 0x7, Type: PaddingProperty)
    FVector InitialLinearVelocity; // 0x5f0 (Size: 0x18, Type: StructProperty)
    FVector InitialAngularVelocity; // 0x608 (Size: 0x18, Type: StructProperty)
    UPhysicalMaterial* PhysicalMaterialOverride; // 0x620 (Size: 0x8, Type: ObjectProperty)
    FGeomComponentCacheParameters CacheParameters; // 0x628 (Size: 0x50, Type: StructProperty)
    TArray<FTransform> RestTransforms; // 0x678 (Size: 0x10, Type: ArrayProperty)
    uint8_t NotifyGeometryCollectionPhysicsStateChange[0x10]; // 0x688 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t NotifyGeometryCollectionPhysicsLoadingStateChange[0x10]; // 0x698 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_6a8[0x18]; // 0x6a8 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnChaosBreakEvent[0x10]; // 0x6c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnChaosRemovalEvent[0x10]; // 0x6d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnChaosCrumblingEvent[0x10]; // 0x6e0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_6f0[0x48]; // 0x6f0 (Size: 0x48, Type: PaddingProperty)
    float DesiredCacheTime; // 0x738 (Size: 0x4, Type: FloatProperty)
    bool CachePlayback; // 0x73c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_73d[0x3]; // 0x73d (Size: 0x3, Type: PaddingProperty)
    uint8_t OnChaosPhysicsCollision[0x10]; // 0x740 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bNotifyBreaks; // 0x750 (Size: 0x1, Type: BoolProperty)
    bool bNotifyCollisions; // 0x751 (Size: 0x1, Type: BoolProperty)
    bool bNotifyTrailing; // 0x752 (Size: 0x1, Type: BoolProperty)
    bool bNotifyRemovals; // 0x753 (Size: 0x1, Type: BoolProperty)
    bool bNotifyCrumblings; // 0x754 (Size: 0x1, Type: BoolProperty)
    bool bCrumblingEventIncludesChildren; // 0x755 (Size: 0x1, Type: BoolProperty)
    bool bNotifyGlobalBreaks; // 0x756 (Size: 0x1, Type: BoolProperty)
    bool bNotifyGlobalCollisions; // 0x757 (Size: 0x1, Type: BoolProperty)
    bool bNotifyGlobalRemovals; // 0x758 (Size: 0x1, Type: BoolProperty)
    bool bNotifyGlobalCrumblings; // 0x759 (Size: 0x1, Type: BoolProperty)
    bool bGlobalCrumblingEventIncludesChildren; // 0x75a (Size: 0x1, Type: BoolProperty)
    bool bStoreVelocities; // 0x75b (Size: 0x1, Type: BoolProperty)
    bool bIsCurrentlyNavigationRelevant; // 0x75c (Size: 0x1, Type: BoolProperty)
    bool bShowBoneColors; // 0x75d (Size: 0x1, Type: BoolProperty)
    bool bUpdateComponentTransformToRootBone; // 0x75e (Size: 0x1, Type: BoolProperty)
    bool bUseRootProxyForNavigation; // 0x75f (Size: 0x1, Type: BoolProperty)
    bool bUpdateNavigationInTick; // 0x760 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_761[0x1]; // 0x761 (Size: 0x1, Type: PaddingProperty)
    bool bEnableReplication; // 0x762 (Size: 0x1, Type: BoolProperty)
    bool bEnableAbandonAfterLevel; // 0x763 (Size: 0x1, Type: BoolProperty)
    FName AbandonedCollisionProfileName; // 0x764 (Size: 0x4, Type: NameProperty)
    AISMPoolActor* ISMPool; // 0x768 (Size: 0x8, Type: ObjectProperty)
    UClass* CustomRendererType; // 0x770 (Size: 0x8, Type: ClassProperty)
    bool bOverrideCustomRenderer; // 0x778 (Size: 0x1, Type: BoolProperty)
    bool bAutoAssignISMPool; // 0x779 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_77a[0x1]; // 0x77a (Size: 0x1, Type: PaddingProperty)
    bool bUseStaticMeshCollisionForTraces; // 0x77b (Size: 0x1, Type: BoolProperty)
    int32_t ReplicationAbandonClusterLevel; // 0x77c (Size: 0x4, Type: IntProperty)
    TScriptInterface<Class> CustomRenderer; // 0x780 (Size: 0x10, Type: InterfaceProperty)
    TArray<FName> CollisionProfilePerLevel; // 0x790 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_7a0[0x10]; // 0x7a0 (Size: 0x10, Type: PaddingProperty)
    int32_t ReplicationAbandonAfterLevel; // 0x7b0 (Size: 0x4, Type: IntProperty)
    int32_t ReplicationMaxPositionAndVelocityCorrectionLevel; // 0x7b4 (Size: 0x4, Type: IntProperty)
    FGeometryCollectionRepData RepData; // 0x7b8 (Size: 0x38, Type: StructProperty)
    FGeometryCollectionRepStateData RepStateData; // 0x7f0 (Size: 0x40, Type: StructProperty)
    FGeometryCollectionRepDynamicData RepDynamicData; // 0x830 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_848[0x110]; // 0x848 (Size: 0x110, Type: PaddingProperty)
    UBodySetup* DummyBodySetup; // 0x958 (Size: 0x8, Type: ObjectProperty)
    UChaosGameplayEventDispatcher* EventDispatcher; // 0x960 (Size: 0x8, Type: ObjectProperty)
    TArray<UInstancedStaticMeshComponent*> EmbeddedGeometryComponents; // 0x968 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_978[0x14]; // 0x978 (Size: 0x14, Type: PaddingProperty)
    float AngularEtherDrag; // 0x98c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_990[0x70]; // 0x990 (Size: 0x70, Type: PaddingProperty)

public:
    void ApplyAngularVelocity(int32_t& ItemIndex, const FVector AngularVelocity); // 0x9f3f858 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void ApplyAssetDefaults(); // 0x9f3fa40 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void ApplyBreakingAngularVelocity(int32_t& ItemIndex, const FVector AngularVelocity); // 0x9f3fa54 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void ApplyBreakingLinearVelocity(int32_t& ItemIndex, const FVector LinearVelocity); // 0x9f3fc40 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void ApplyExternalStrain(int32_t& ItemIndex, const FVector Location, float& Radius, int32_t& PropagationDepth, float& PropagationFactor, float& Strain); // 0x9f3fe08 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void ApplyInternalStrain(int32_t& ItemIndex, const FVector Location, float& Radius, int32_t& PropagationDepth, float& PropagationFactor, float& Strain); // 0x9f40184 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void ApplyKinematicField(float& Radius, FVector& Position); // 0x9f404f0 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void ApplyLinearVelocity(int32_t& ItemIndex, const FVector LinearVelocity); // 0x9f406b4 (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void ApplyPhysicsField(bool& Enabled, EGeometryCollectionPhysicsTypeEnum& Target, UFieldSystemMetaData*& MetaData, UFieldNodeBase*& Field); // 0x9f4089c (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void CrumbleActiveClusters(); // 0x9f40e9c (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void CrumbleCluster(int32_t& ItemIndex); // 0x9f40eb0 (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void EnableRootProxyForCustomRenderer(bool& bEnable); // 0x9f411a8 (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void ForceBrokenForCustomRenderer(bool& bForceBroken); // 0x9f412e4 (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    TArray<float> GetDamageThreshold() const; // 0x9f41420 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetDebugInfo(); // 0x9f41460 (Index: 0xe, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    int32_t GetInitialLevel(int32_t& ItemIndex); // 0x9f414a0 (Index: 0xf, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    TArray<FTransform> GetInitialLocalRestTransforms() const; // 0x9f415d8 (Index: 0x10, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBox GetLocalBounds() const; // 0x9f41618 (Index: 0x11, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    TArray<FTransform> GetLocalRestTransforms(bool& bInitialTransforms) const; // 0x9f41658 (Index: 0x12, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetMassAndExtents(int32_t& ItemIndex, float& OutMass, FBox& OutExtents); // 0x9f4195c (Index: 0x13, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    FTransform GetRootCurrentTransform() const; // 0x9f41b94 (Index: 0x14, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    int32_t GetRootIndex() const; // 0x9f41bf0 (Index: 0x15, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FTransform GetRootInitialTransform() const; // 0x9f41c10 (Index: 0x16, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool GetUseStaticMeshCollisionForTraces() const; // 0x9f41c84 (Index: 0x18, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsRootBroken() const; // 0x9f41cb8 (Index: 0x19, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature(UGeometryCollectionComponent*& FracturedComponent); // 0x288a61c (Index: 0x1a, Flags: MulticastDelegate|Public|Delegate)
    void NotifyGeometryCollectionPhysicsStateChange__DelegateSignature(UGeometryCollectionComponent*& FracturedComponent); // 0x288a61c (Index: 0x1b, Flags: MulticastDelegate|Public|Delegate)
    virtual void ReceivePhysicsCollision(const FChaosPhysicsCollisionInfo CollisionInfo); // 0x288a61c (Index: 0x1f, Flags: RequiredAPI|Event|Public|HasOutParms|BlueprintEvent)
    void RemoveAllAnchors(); // 0x9f4211c (Index: 0x20, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetAbandonedParticleCollisionProfileName(FName& CollisionProfile); // 0x9f42424 (Index: 0x21, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetAnchoredByBox(FBox& WorldSpaceBox, bool& bAnchored, int32_t& MaxLevel); // 0x9f42558 (Index: 0x22, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetAnchoredByIndex(int32_t& Index, bool& bAnchored); // 0x9f42784 (Index: 0x23, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetAnchoredByTransformedBox(FBox& Box, FTransform& Transform, bool& bAnchored, int32_t& MaxLevel); // 0x9f429ac (Index: 0x24, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetDamageModel(EDamageModelTypeEnum& InDamageModel); // 0x9f43714 (Index: 0x25, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetDamagePropagationData(const FGeometryCollectionDamagePropagationData InDamagePropagationData); // 0x9f43840 (Index: 0x26, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetDamageThreshold(const TArray<float> InDamageThreshold); // 0x9f4391c (Index: 0x27, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetDensityFromPhysicsMaterial(bool& bInDensityFromPhysicsMaterial); // 0x9f43ba8 (Index: 0x28, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetEnableDamageFromCollision(bool& bValue); // 0x9f43cd4 (Index: 0x29, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetGravityGroupIndex(int32_t& InGravityGroupIndex); // 0x9f43e00 (Index: 0x2a, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetLocalRestTransforms(const TArray<FTransform> Transforms, bool& bOnlyLeaves); // 0x9f43f28 (Index: 0x2b, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetNotifyBreaks(bool& bNewNotifyBreaks); // 0x9f4422c (Index: 0x2c, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetNotifyCrumblings(bool& bNewNotifyCrumblings, bool& bNewCrumblingEventIncludesChildren); // 0x9f44390 (Index: 0x2d, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetNotifyGlobalBreaks(bool& bNewNotifyGlobalBreaks); // 0x9f445ac (Index: 0x2e, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetNotifyGlobalCollision(bool& bNewNotifyGlobalCollisions); // 0x9f446d8 (Index: 0x2f, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetNotifyGlobalCrumblings(bool& bNewNotifyGlobalCrumblings, bool& bGlobalNewCrumblingEventIncludesChildren); // 0x9f44838 (Index: 0x30, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetNotifyGlobalRemovals(bool& bNewNotifyGlobalRemovals); // 0x9f44a88 (Index: 0x31, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetNotifyRemovals(bool& bNewNotifyRemovals); // 0x9f44be8 (Index: 0x32, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetOneWayInteractionLevel(int32_t& InOneWayInteractionLevel); // 0x9f44d24 (Index: 0x33, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetPerLevelCollisionProfileNames(const TArray<FName> ProfileNames); // 0x9f44e4c (Index: 0x34, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetPerParticleCollisionProfileName(const TArray<int32_t> BoneIds, FName& ProfileName); // 0x9f450f0 (Index: 0x35, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetRestCollection(UGeometryCollection*& const RestCollectionIn, bool& bApplyAssetDefaults); // 0x9f4562c (Index: 0x36, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetRootProxyComponentSpaceTransform(int32_t& Index, const FTransform RootProxyTransform); // 0x9f45c74 (Index: 0x37, Flags: Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetUseMaterialDamageModifiers(bool& bInUseMaterialDamageModifiers); // 0x9f463f4 (Index: 0x39, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetUseStaticMeshCollisionForTraces(bool& bInUseStaticMeshCollisionForTraces); // 0x9f46520 (Index: 0x3a, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)

private:
    AChaosSolverActor* GetSolverActor() const; // 0x9f41c6c (Index: 0x17, Flags: Final|RequiredAPI|Native|Private|BlueprintCallable|BlueprintPure|Const)
    void SetSolverActor(AChaosSolverActor*& InSolverActor); // 0x9f45edc (Index: 0x38, Flags: Final|RequiredAPI|Native|Private|BlueprintCallable)

protected:
    void OnRep_RepData(); // 0x9f41edc (Index: 0x1c, Flags: Final|RequiredAPI|Native|Protected)
    void OnRep_RepDynamicData(); // 0x9f41ef0 (Index: 0x1d, Flags: Final|RequiredAPI|Native|Protected)
    void OnRep_RepStateData(); // 0x9f41f04 (Index: 0x1e, Flags: Final|RequiredAPI|Native|Protected)
};

static_assert(sizeof(UGeometryCollectionComponent) == 0xa00, "Size mismatch for UGeometryCollectionComponent");
static_assert(offsetof(UGeometryCollectionComponent, ChaosSolverActor) == 0x568, "Offset mismatch for UGeometryCollectionComponent::ChaosSolverActor");
static_assert(offsetof(UGeometryCollectionComponent, RestCollection) == 0x570, "Offset mismatch for UGeometryCollectionComponent::RestCollection");
static_assert(offsetof(UGeometryCollectionComponent, InitializationFields) == 0x578, "Offset mismatch for UGeometryCollectionComponent::InitializationFields");
static_assert(offsetof(UGeometryCollectionComponent, Simulating) == 0x588, "Offset mismatch for UGeometryCollectionComponent::Simulating");
static_assert(offsetof(UGeometryCollectionComponent, ObjectType) == 0x58a, "Offset mismatch for UGeometryCollectionComponent::ObjectType");
static_assert(offsetof(UGeometryCollectionComponent, GravityGroupIndex) == 0x58c, "Offset mismatch for UGeometryCollectionComponent::GravityGroupIndex");
static_assert(offsetof(UGeometryCollectionComponent, OneWayInteractionLevel) == 0x590, "Offset mismatch for UGeometryCollectionComponent::OneWayInteractionLevel");
static_assert(offsetof(UGeometryCollectionComponent, bDensityFromPhysicsMaterial) == 0x594, "Offset mismatch for UGeometryCollectionComponent::bDensityFromPhysicsMaterial");
static_assert(offsetof(UGeometryCollectionComponent, bForceMotionBlur) == 0x595, "Offset mismatch for UGeometryCollectionComponent::bForceMotionBlur");
static_assert(offsetof(UGeometryCollectionComponent, EnableClustering) == 0x596, "Offset mismatch for UGeometryCollectionComponent::EnableClustering");
static_assert(offsetof(UGeometryCollectionComponent, ClusterGroupIndex) == 0x598, "Offset mismatch for UGeometryCollectionComponent::ClusterGroupIndex");
static_assert(offsetof(UGeometryCollectionComponent, MaxClusterLevel) == 0x59c, "Offset mismatch for UGeometryCollectionComponent::MaxClusterLevel");
static_assert(offsetof(UGeometryCollectionComponent, MaxSimulatedLevel) == 0x5a0, "Offset mismatch for UGeometryCollectionComponent::MaxSimulatedLevel");
static_assert(offsetof(UGeometryCollectionComponent, DamageModel) == 0x5a4, "Offset mismatch for UGeometryCollectionComponent::DamageModel");
static_assert(offsetof(UGeometryCollectionComponent, DamageThreshold) == 0x5a8, "Offset mismatch for UGeometryCollectionComponent::DamageThreshold");
static_assert(offsetof(UGeometryCollectionComponent, bUseSizeSpecificDamageThreshold) == 0x5b8, "Offset mismatch for UGeometryCollectionComponent::bUseSizeSpecificDamageThreshold");
static_assert(offsetof(UGeometryCollectionComponent, bUseMaterialDamageModifiers) == 0x5b9, "Offset mismatch for UGeometryCollectionComponent::bUseMaterialDamageModifiers");
static_assert(offsetof(UGeometryCollectionComponent, DamagePropagationData) == 0x5bc, "Offset mismatch for UGeometryCollectionComponent::DamagePropagationData");
static_assert(offsetof(UGeometryCollectionComponent, bEnableDamageFromCollision) == 0x5c8, "Offset mismatch for UGeometryCollectionComponent::bEnableDamageFromCollision");
static_assert(offsetof(UGeometryCollectionComponent, bAllowRemovalOnSleep) == 0x5c9, "Offset mismatch for UGeometryCollectionComponent::bAllowRemovalOnSleep");
static_assert(offsetof(UGeometryCollectionComponent, bAllowRemovalOnBreak) == 0x5ca, "Offset mismatch for UGeometryCollectionComponent::bAllowRemovalOnBreak");
static_assert(offsetof(UGeometryCollectionComponent, bForceUpdateActiveTransforms) == 0x5cb, "Offset mismatch for UGeometryCollectionComponent::bForceUpdateActiveTransforms");
static_assert(offsetof(UGeometryCollectionComponent, ClusterConnectionType) == 0x5cc, "Offset mismatch for UGeometryCollectionComponent::ClusterConnectionType");
static_assert(offsetof(UGeometryCollectionComponent, CollisionGroup) == 0x5d0, "Offset mismatch for UGeometryCollectionComponent::CollisionGroup");
static_assert(offsetof(UGeometryCollectionComponent, CollisionSampleFraction) == 0x5d4, "Offset mismatch for UGeometryCollectionComponent::CollisionSampleFraction");
static_assert(offsetof(UGeometryCollectionComponent, LinearEtherDrag) == 0x5d8, "Offset mismatch for UGeometryCollectionComponent::LinearEtherDrag");
static_assert(offsetof(UGeometryCollectionComponent, PhysicalMaterial) == 0x5e0, "Offset mismatch for UGeometryCollectionComponent::PhysicalMaterial");
static_assert(offsetof(UGeometryCollectionComponent, InitialVelocityType) == 0x5e8, "Offset mismatch for UGeometryCollectionComponent::InitialVelocityType");
static_assert(offsetof(UGeometryCollectionComponent, InitialLinearVelocity) == 0x5f0, "Offset mismatch for UGeometryCollectionComponent::InitialLinearVelocity");
static_assert(offsetof(UGeometryCollectionComponent, InitialAngularVelocity) == 0x608, "Offset mismatch for UGeometryCollectionComponent::InitialAngularVelocity");
static_assert(offsetof(UGeometryCollectionComponent, PhysicalMaterialOverride) == 0x620, "Offset mismatch for UGeometryCollectionComponent::PhysicalMaterialOverride");
static_assert(offsetof(UGeometryCollectionComponent, CacheParameters) == 0x628, "Offset mismatch for UGeometryCollectionComponent::CacheParameters");
static_assert(offsetof(UGeometryCollectionComponent, RestTransforms) == 0x678, "Offset mismatch for UGeometryCollectionComponent::RestTransforms");
static_assert(offsetof(UGeometryCollectionComponent, NotifyGeometryCollectionPhysicsStateChange) == 0x688, "Offset mismatch for UGeometryCollectionComponent::NotifyGeometryCollectionPhysicsStateChange");
static_assert(offsetof(UGeometryCollectionComponent, NotifyGeometryCollectionPhysicsLoadingStateChange) == 0x698, "Offset mismatch for UGeometryCollectionComponent::NotifyGeometryCollectionPhysicsLoadingStateChange");
static_assert(offsetof(UGeometryCollectionComponent, OnChaosBreakEvent) == 0x6c0, "Offset mismatch for UGeometryCollectionComponent::OnChaosBreakEvent");
static_assert(offsetof(UGeometryCollectionComponent, OnChaosRemovalEvent) == 0x6d0, "Offset mismatch for UGeometryCollectionComponent::OnChaosRemovalEvent");
static_assert(offsetof(UGeometryCollectionComponent, OnChaosCrumblingEvent) == 0x6e0, "Offset mismatch for UGeometryCollectionComponent::OnChaosCrumblingEvent");
static_assert(offsetof(UGeometryCollectionComponent, DesiredCacheTime) == 0x738, "Offset mismatch for UGeometryCollectionComponent::DesiredCacheTime");
static_assert(offsetof(UGeometryCollectionComponent, CachePlayback) == 0x73c, "Offset mismatch for UGeometryCollectionComponent::CachePlayback");
static_assert(offsetof(UGeometryCollectionComponent, OnChaosPhysicsCollision) == 0x740, "Offset mismatch for UGeometryCollectionComponent::OnChaosPhysicsCollision");
static_assert(offsetof(UGeometryCollectionComponent, bNotifyBreaks) == 0x750, "Offset mismatch for UGeometryCollectionComponent::bNotifyBreaks");
static_assert(offsetof(UGeometryCollectionComponent, bNotifyCollisions) == 0x751, "Offset mismatch for UGeometryCollectionComponent::bNotifyCollisions");
static_assert(offsetof(UGeometryCollectionComponent, bNotifyTrailing) == 0x752, "Offset mismatch for UGeometryCollectionComponent::bNotifyTrailing");
static_assert(offsetof(UGeometryCollectionComponent, bNotifyRemovals) == 0x753, "Offset mismatch for UGeometryCollectionComponent::bNotifyRemovals");
static_assert(offsetof(UGeometryCollectionComponent, bNotifyCrumblings) == 0x754, "Offset mismatch for UGeometryCollectionComponent::bNotifyCrumblings");
static_assert(offsetof(UGeometryCollectionComponent, bCrumblingEventIncludesChildren) == 0x755, "Offset mismatch for UGeometryCollectionComponent::bCrumblingEventIncludesChildren");
static_assert(offsetof(UGeometryCollectionComponent, bNotifyGlobalBreaks) == 0x756, "Offset mismatch for UGeometryCollectionComponent::bNotifyGlobalBreaks");
static_assert(offsetof(UGeometryCollectionComponent, bNotifyGlobalCollisions) == 0x757, "Offset mismatch for UGeometryCollectionComponent::bNotifyGlobalCollisions");
static_assert(offsetof(UGeometryCollectionComponent, bNotifyGlobalRemovals) == 0x758, "Offset mismatch for UGeometryCollectionComponent::bNotifyGlobalRemovals");
static_assert(offsetof(UGeometryCollectionComponent, bNotifyGlobalCrumblings) == 0x759, "Offset mismatch for UGeometryCollectionComponent::bNotifyGlobalCrumblings");
static_assert(offsetof(UGeometryCollectionComponent, bGlobalCrumblingEventIncludesChildren) == 0x75a, "Offset mismatch for UGeometryCollectionComponent::bGlobalCrumblingEventIncludesChildren");
static_assert(offsetof(UGeometryCollectionComponent, bStoreVelocities) == 0x75b, "Offset mismatch for UGeometryCollectionComponent::bStoreVelocities");
static_assert(offsetof(UGeometryCollectionComponent, bIsCurrentlyNavigationRelevant) == 0x75c, "Offset mismatch for UGeometryCollectionComponent::bIsCurrentlyNavigationRelevant");
static_assert(offsetof(UGeometryCollectionComponent, bShowBoneColors) == 0x75d, "Offset mismatch for UGeometryCollectionComponent::bShowBoneColors");
static_assert(offsetof(UGeometryCollectionComponent, bUpdateComponentTransformToRootBone) == 0x75e, "Offset mismatch for UGeometryCollectionComponent::bUpdateComponentTransformToRootBone");
static_assert(offsetof(UGeometryCollectionComponent, bUseRootProxyForNavigation) == 0x75f, "Offset mismatch for UGeometryCollectionComponent::bUseRootProxyForNavigation");
static_assert(offsetof(UGeometryCollectionComponent, bUpdateNavigationInTick) == 0x760, "Offset mismatch for UGeometryCollectionComponent::bUpdateNavigationInTick");
static_assert(offsetof(UGeometryCollectionComponent, bEnableReplication) == 0x762, "Offset mismatch for UGeometryCollectionComponent::bEnableReplication");
static_assert(offsetof(UGeometryCollectionComponent, bEnableAbandonAfterLevel) == 0x763, "Offset mismatch for UGeometryCollectionComponent::bEnableAbandonAfterLevel");
static_assert(offsetof(UGeometryCollectionComponent, AbandonedCollisionProfileName) == 0x764, "Offset mismatch for UGeometryCollectionComponent::AbandonedCollisionProfileName");
static_assert(offsetof(UGeometryCollectionComponent, ISMPool) == 0x768, "Offset mismatch for UGeometryCollectionComponent::ISMPool");
static_assert(offsetof(UGeometryCollectionComponent, CustomRendererType) == 0x770, "Offset mismatch for UGeometryCollectionComponent::CustomRendererType");
static_assert(offsetof(UGeometryCollectionComponent, bOverrideCustomRenderer) == 0x778, "Offset mismatch for UGeometryCollectionComponent::bOverrideCustomRenderer");
static_assert(offsetof(UGeometryCollectionComponent, bAutoAssignISMPool) == 0x779, "Offset mismatch for UGeometryCollectionComponent::bAutoAssignISMPool");
static_assert(offsetof(UGeometryCollectionComponent, bUseStaticMeshCollisionForTraces) == 0x77b, "Offset mismatch for UGeometryCollectionComponent::bUseStaticMeshCollisionForTraces");
static_assert(offsetof(UGeometryCollectionComponent, ReplicationAbandonClusterLevel) == 0x77c, "Offset mismatch for UGeometryCollectionComponent::ReplicationAbandonClusterLevel");
static_assert(offsetof(UGeometryCollectionComponent, CustomRenderer) == 0x780, "Offset mismatch for UGeometryCollectionComponent::CustomRenderer");
static_assert(offsetof(UGeometryCollectionComponent, CollisionProfilePerLevel) == 0x790, "Offset mismatch for UGeometryCollectionComponent::CollisionProfilePerLevel");
static_assert(offsetof(UGeometryCollectionComponent, ReplicationAbandonAfterLevel) == 0x7b0, "Offset mismatch for UGeometryCollectionComponent::ReplicationAbandonAfterLevel");
static_assert(offsetof(UGeometryCollectionComponent, ReplicationMaxPositionAndVelocityCorrectionLevel) == 0x7b4, "Offset mismatch for UGeometryCollectionComponent::ReplicationMaxPositionAndVelocityCorrectionLevel");
static_assert(offsetof(UGeometryCollectionComponent, RepData) == 0x7b8, "Offset mismatch for UGeometryCollectionComponent::RepData");
static_assert(offsetof(UGeometryCollectionComponent, RepStateData) == 0x7f0, "Offset mismatch for UGeometryCollectionComponent::RepStateData");
static_assert(offsetof(UGeometryCollectionComponent, RepDynamicData) == 0x830, "Offset mismatch for UGeometryCollectionComponent::RepDynamicData");
static_assert(offsetof(UGeometryCollectionComponent, DummyBodySetup) == 0x958, "Offset mismatch for UGeometryCollectionComponent::DummyBodySetup");
static_assert(offsetof(UGeometryCollectionComponent, EventDispatcher) == 0x960, "Offset mismatch for UGeometryCollectionComponent::EventDispatcher");
static_assert(offsetof(UGeometryCollectionComponent, EmbeddedGeometryComponents) == 0x968, "Offset mismatch for UGeometryCollectionComponent::EmbeddedGeometryComponents");
static_assert(offsetof(UGeometryCollectionComponent, AngularEtherDrag) == 0x98c, "Offset mismatch for UGeometryCollectionComponent::AngularEtherDrag");

// Size: 0x368 (Inherited: 0x2d0, Single: 0x98)
class AGeometryCollectionDebugDrawActor : public AActor
{
public:
    FGeometryCollectionDebugDrawWarningMessage WarningMessage; // 0x2a8 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_2a9[0x7]; // 0x2a9 (Size: 0x7, Type: PaddingProperty)
    FGeometryCollectionDebugDrawActorSelectedRigidBody SelectedRigidBody; // 0x2b0 (Size: 0x18, Type: StructProperty)
    bool bDebugDrawWholeCollection; // 0x2c8 (Size: 0x1, Type: BoolProperty)
    bool bDebugDrawHierarchy; // 0x2c9 (Size: 0x1, Type: BoolProperty)
    bool bDebugDrawClustering; // 0x2ca (Size: 0x1, Type: BoolProperty)
    uint8_t HideGeometry; // 0x2cb (Size: 0x1, Type: EnumProperty)
    bool bShowRigidBodyId; // 0x2cc (Size: 0x1, Type: BoolProperty)
    bool bShowRigidBodyCollision; // 0x2cd (Size: 0x1, Type: BoolProperty)
    bool bCollisionAtOrigin; // 0x2ce (Size: 0x1, Type: BoolProperty)
    bool bShowRigidBodyTransform; // 0x2cf (Size: 0x1, Type: BoolProperty)
    bool bShowRigidBodyInertia; // 0x2d0 (Size: 0x1, Type: BoolProperty)
    bool bShowRigidBodyVelocity; // 0x2d1 (Size: 0x1, Type: BoolProperty)
    bool bShowRigidBodyForce; // 0x2d2 (Size: 0x1, Type: BoolProperty)
    bool bShowRigidBodyInfos; // 0x2d3 (Size: 0x1, Type: BoolProperty)
    bool bShowTransformIndex; // 0x2d4 (Size: 0x1, Type: BoolProperty)
    bool bShowTransform; // 0x2d5 (Size: 0x1, Type: BoolProperty)
    bool bShowParent; // 0x2d6 (Size: 0x1, Type: BoolProperty)
    bool bShowLevel; // 0x2d7 (Size: 0x1, Type: BoolProperty)
    bool bShowConnectivityEdges; // 0x2d8 (Size: 0x1, Type: BoolProperty)
    bool bShowGeometryIndex; // 0x2d9 (Size: 0x1, Type: BoolProperty)
    bool bShowGeometryTransform; // 0x2da (Size: 0x1, Type: BoolProperty)
    bool bShowBoundingBox; // 0x2db (Size: 0x1, Type: BoolProperty)
    bool bShowFaces; // 0x2dc (Size: 0x1, Type: BoolProperty)
    bool bShowFaceIndices; // 0x2dd (Size: 0x1, Type: BoolProperty)
    bool bShowFaceNormals; // 0x2de (Size: 0x1, Type: BoolProperty)
    bool bShowSingleFace; // 0x2df (Size: 0x1, Type: BoolProperty)
    int32_t SingleFaceIndex; // 0x2e0 (Size: 0x4, Type: IntProperty)
    bool bShowVertices; // 0x2e4 (Size: 0x1, Type: BoolProperty)
    bool bShowVertexIndices; // 0x2e5 (Size: 0x1, Type: BoolProperty)
    bool bShowVertexNormals; // 0x2e6 (Size: 0x1, Type: BoolProperty)
    bool bUseActiveVisualization; // 0x2e7 (Size: 0x1, Type: BoolProperty)
    float PointThickness; // 0x2e8 (Size: 0x4, Type: FloatProperty)
    float LineThickness; // 0x2ec (Size: 0x4, Type: FloatProperty)
    bool bTextShadow; // 0x2f0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2f1[0x3]; // 0x2f1 (Size: 0x3, Type: PaddingProperty)
    float TextScale; // 0x2f4 (Size: 0x4, Type: FloatProperty)
    float NormalScale; // 0x2f8 (Size: 0x4, Type: FloatProperty)
    float AxisScale; // 0x2fc (Size: 0x4, Type: FloatProperty)
    float ArrowScale; // 0x300 (Size: 0x4, Type: FloatProperty)
    FColor RigidBodyIdColor; // 0x304 (Size: 0x4, Type: StructProperty)
    float RigidBodyTransformScale; // 0x308 (Size: 0x4, Type: FloatProperty)
    FColor RigidBodyCollisionColor; // 0x30c (Size: 0x4, Type: StructProperty)
    FColor RigidBodyInertiaColor; // 0x310 (Size: 0x4, Type: StructProperty)
    FColor RigidBodyVelocityColor; // 0x314 (Size: 0x4, Type: StructProperty)
    FColor RigidBodyForceColor; // 0x318 (Size: 0x4, Type: StructProperty)
    FColor RigidBodyInfoColor; // 0x31c (Size: 0x4, Type: StructProperty)
    FColor TransformIndexColor; // 0x320 (Size: 0x4, Type: StructProperty)
    float TransformScale; // 0x324 (Size: 0x4, Type: FloatProperty)
    FColor LevelColor; // 0x328 (Size: 0x4, Type: StructProperty)
    FColor ParentColor; // 0x32c (Size: 0x4, Type: StructProperty)
    float ConnectivityEdgeThickness; // 0x330 (Size: 0x4, Type: FloatProperty)
    FColor GeometryIndexColor; // 0x334 (Size: 0x4, Type: StructProperty)
    float GeometryTransformScale; // 0x338 (Size: 0x4, Type: FloatProperty)
    FColor BoundingBoxColor; // 0x33c (Size: 0x4, Type: StructProperty)
    FColor FaceColor; // 0x340 (Size: 0x4, Type: StructProperty)
    FColor FaceIndexColor; // 0x344 (Size: 0x4, Type: StructProperty)
    FColor FaceNormalColor; // 0x348 (Size: 0x4, Type: StructProperty)
    FColor SingleFaceColor; // 0x34c (Size: 0x4, Type: StructProperty)
    FColor VertexColor; // 0x350 (Size: 0x4, Type: StructProperty)
    FColor VertexIndexColor; // 0x354 (Size: 0x4, Type: StructProperty)
    FColor VertexNormalColor; // 0x358 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_35c[0x4]; // 0x35c (Size: 0x4, Type: PaddingProperty)
    UBillboardComponent* SpriteComponent; // 0x360 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(AGeometryCollectionDebugDrawActor) == 0x368, "Size mismatch for AGeometryCollectionDebugDrawActor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, WarningMessage) == 0x2a8, "Offset mismatch for AGeometryCollectionDebugDrawActor::WarningMessage");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, SelectedRigidBody) == 0x2b0, "Offset mismatch for AGeometryCollectionDebugDrawActor::SelectedRigidBody");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bDebugDrawWholeCollection) == 0x2c8, "Offset mismatch for AGeometryCollectionDebugDrawActor::bDebugDrawWholeCollection");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bDebugDrawHierarchy) == 0x2c9, "Offset mismatch for AGeometryCollectionDebugDrawActor::bDebugDrawHierarchy");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bDebugDrawClustering) == 0x2ca, "Offset mismatch for AGeometryCollectionDebugDrawActor::bDebugDrawClustering");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, HideGeometry) == 0x2cb, "Offset mismatch for AGeometryCollectionDebugDrawActor::HideGeometry");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowRigidBodyId) == 0x2cc, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowRigidBodyId");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowRigidBodyCollision) == 0x2cd, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowRigidBodyCollision");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bCollisionAtOrigin) == 0x2ce, "Offset mismatch for AGeometryCollectionDebugDrawActor::bCollisionAtOrigin");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowRigidBodyTransform) == 0x2cf, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowRigidBodyTransform");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowRigidBodyInertia) == 0x2d0, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowRigidBodyInertia");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowRigidBodyVelocity) == 0x2d1, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowRigidBodyVelocity");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowRigidBodyForce) == 0x2d2, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowRigidBodyForce");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowRigidBodyInfos) == 0x2d3, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowRigidBodyInfos");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowTransformIndex) == 0x2d4, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowTransformIndex");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowTransform) == 0x2d5, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowTransform");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowParent) == 0x2d6, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowParent");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowLevel) == 0x2d7, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowLevel");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowConnectivityEdges) == 0x2d8, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowConnectivityEdges");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowGeometryIndex) == 0x2d9, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowGeometryIndex");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowGeometryTransform) == 0x2da, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowGeometryTransform");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowBoundingBox) == 0x2db, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowBoundingBox");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowFaces) == 0x2dc, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowFaces");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowFaceIndices) == 0x2dd, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowFaceIndices");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowFaceNormals) == 0x2de, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowFaceNormals");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowSingleFace) == 0x2df, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowSingleFace");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, SingleFaceIndex) == 0x2e0, "Offset mismatch for AGeometryCollectionDebugDrawActor::SingleFaceIndex");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowVertices) == 0x2e4, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowVertices");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowVertexIndices) == 0x2e5, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowVertexIndices");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bShowVertexNormals) == 0x2e6, "Offset mismatch for AGeometryCollectionDebugDrawActor::bShowVertexNormals");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bUseActiveVisualization) == 0x2e7, "Offset mismatch for AGeometryCollectionDebugDrawActor::bUseActiveVisualization");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, PointThickness) == 0x2e8, "Offset mismatch for AGeometryCollectionDebugDrawActor::PointThickness");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, LineThickness) == 0x2ec, "Offset mismatch for AGeometryCollectionDebugDrawActor::LineThickness");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, bTextShadow) == 0x2f0, "Offset mismatch for AGeometryCollectionDebugDrawActor::bTextShadow");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, TextScale) == 0x2f4, "Offset mismatch for AGeometryCollectionDebugDrawActor::TextScale");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, NormalScale) == 0x2f8, "Offset mismatch for AGeometryCollectionDebugDrawActor::NormalScale");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, AxisScale) == 0x2fc, "Offset mismatch for AGeometryCollectionDebugDrawActor::AxisScale");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, ArrowScale) == 0x300, "Offset mismatch for AGeometryCollectionDebugDrawActor::ArrowScale");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, RigidBodyIdColor) == 0x304, "Offset mismatch for AGeometryCollectionDebugDrawActor::RigidBodyIdColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, RigidBodyTransformScale) == 0x308, "Offset mismatch for AGeometryCollectionDebugDrawActor::RigidBodyTransformScale");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, RigidBodyCollisionColor) == 0x30c, "Offset mismatch for AGeometryCollectionDebugDrawActor::RigidBodyCollisionColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, RigidBodyInertiaColor) == 0x310, "Offset mismatch for AGeometryCollectionDebugDrawActor::RigidBodyInertiaColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, RigidBodyVelocityColor) == 0x314, "Offset mismatch for AGeometryCollectionDebugDrawActor::RigidBodyVelocityColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, RigidBodyForceColor) == 0x318, "Offset mismatch for AGeometryCollectionDebugDrawActor::RigidBodyForceColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, RigidBodyInfoColor) == 0x31c, "Offset mismatch for AGeometryCollectionDebugDrawActor::RigidBodyInfoColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, TransformIndexColor) == 0x320, "Offset mismatch for AGeometryCollectionDebugDrawActor::TransformIndexColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, TransformScale) == 0x324, "Offset mismatch for AGeometryCollectionDebugDrawActor::TransformScale");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, LevelColor) == 0x328, "Offset mismatch for AGeometryCollectionDebugDrawActor::LevelColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, ParentColor) == 0x32c, "Offset mismatch for AGeometryCollectionDebugDrawActor::ParentColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, ConnectivityEdgeThickness) == 0x330, "Offset mismatch for AGeometryCollectionDebugDrawActor::ConnectivityEdgeThickness");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, GeometryIndexColor) == 0x334, "Offset mismatch for AGeometryCollectionDebugDrawActor::GeometryIndexColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, GeometryTransformScale) == 0x338, "Offset mismatch for AGeometryCollectionDebugDrawActor::GeometryTransformScale");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, BoundingBoxColor) == 0x33c, "Offset mismatch for AGeometryCollectionDebugDrawActor::BoundingBoxColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, FaceColor) == 0x340, "Offset mismatch for AGeometryCollectionDebugDrawActor::FaceColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, FaceIndexColor) == 0x344, "Offset mismatch for AGeometryCollectionDebugDrawActor::FaceIndexColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, FaceNormalColor) == 0x348, "Offset mismatch for AGeometryCollectionDebugDrawActor::FaceNormalColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, SingleFaceColor) == 0x34c, "Offset mismatch for AGeometryCollectionDebugDrawActor::SingleFaceColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, VertexColor) == 0x350, "Offset mismatch for AGeometryCollectionDebugDrawActor::VertexColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, VertexIndexColor) == 0x354, "Offset mismatch for AGeometryCollectionDebugDrawActor::VertexIndexColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, VertexNormalColor) == 0x358, "Offset mismatch for AGeometryCollectionDebugDrawActor::VertexNormalColor");
static_assert(offsetof(AGeometryCollectionDebugDrawActor, SpriteComponent) == 0x360, "Offset mismatch for AGeometryCollectionDebugDrawActor::SpriteComponent");

// Size: 0xd0 (Inherited: 0xe0, Single: 0xfffffff0)
class UGeometryCollectionDebugDrawComponent : public UActorComponent
{
public:
    AGeometryCollectionDebugDrawActor* GeometryCollectionDebugDrawActor; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    AGeometryCollectionRenderLevelSetActor* GeometryCollectionRenderLevelSetActor; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UGeometryCollectionDebugDrawComponent) == 0xd0, "Size mismatch for UGeometryCollectionDebugDrawComponent");
static_assert(offsetof(UGeometryCollectionDebugDrawComponent, GeometryCollectionDebugDrawActor) == 0xb8, "Offset mismatch for UGeometryCollectionDebugDrawComponent::GeometryCollectionDebugDrawActor");
static_assert(offsetof(UGeometryCollectionDebugDrawComponent, GeometryCollectionRenderLevelSetActor) == 0xc0, "Offset mismatch for UGeometryCollectionDebugDrawComponent::GeometryCollectionRenderLevelSetActor");

// Size: 0x2b8 (Inherited: 0x2d0, Single: 0xffffffe8)
class AGeometryCollectionISMPoolActor : public AActor
{
public:
    UGeometryCollectionISMPoolComponent* ISMPoolComp; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UGeometryCollectionISMPoolDebugDrawComponent* ISMPoolDebugDrawComp; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(AGeometryCollectionISMPoolActor) == 0x2b8, "Size mismatch for AGeometryCollectionISMPoolActor");
static_assert(offsetof(AGeometryCollectionISMPoolActor, ISMPoolComp) == 0x2a8, "Offset mismatch for AGeometryCollectionISMPoolActor::ISMPoolComp");
static_assert(offsetof(AGeometryCollectionISMPoolActor, ISMPoolDebugDrawComp) == 0x2b0, "Offset mismatch for AGeometryCollectionISMPoolActor::ISMPoolDebugDrawComp");

// Size: 0x370 (Inherited: 0x320, Single: 0x50)
class UGeometryCollectionISMPoolComponent : public USceneComponent
{
public:
};

static_assert(sizeof(UGeometryCollectionISMPoolComponent) == 0x370, "Size mismatch for UGeometryCollectionISMPoolComponent");

// Size: 0xe0 (Inherited: 0x28, Single: 0xb8)
class UGeometryCollectionISMPoolRenderer : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    UISMPoolComponent* CachedISMPoolComponent; // 0x30 (Size: 0x8, Type: ObjectProperty)
    UISMPoolComponent* LocalISMPoolComponent; // 0x38 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_40[0xa0]; // 0x40 (Size: 0xa0, Type: PaddingProperty)
};

static_assert(sizeof(UGeometryCollectionISMPoolRenderer) == 0xe0, "Size mismatch for UGeometryCollectionISMPoolRenderer");
static_assert(offsetof(UGeometryCollectionISMPoolRenderer, CachedISMPoolComponent) == 0x30, "Offset mismatch for UGeometryCollectionISMPoolRenderer::CachedISMPoolComponent");
static_assert(offsetof(UGeometryCollectionISMPoolRenderer, LocalISMPoolComponent) == 0x38, "Offset mismatch for UGeometryCollectionISMPoolRenderer::LocalISMPoolComponent");

// Size: 0x280 (Inherited: 0x28, Single: 0x258)
class UGeometryCollection : public UObject
{
public:
    uint8_t Pad_28[0x38]; // 0x28 (Size: 0x38, Type: PaddingProperty)
    bool EnableClustering; // 0x60 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_61[0x3]; // 0x61 (Size: 0x3, Type: PaddingProperty)
    int32_t ClusterGroupIndex; // 0x64 (Size: 0x4, Type: IntProperty)
    int32_t MaxClusterLevel; // 0x68 (Size: 0x4, Type: IntProperty)
    uint8_t DamageModel; // 0x6c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_6d[0x3]; // 0x6d (Size: 0x3, Type: PaddingProperty)
    TArray<float> DamageThreshold; // 0x70 (Size: 0x10, Type: ArrayProperty)
    bool bUseSizeSpecificDamageThreshold; // 0x80 (Size: 0x1, Type: BoolProperty)
    bool bUseMaterialDamageModifiers; // 0x81 (Size: 0x1, Type: BoolProperty)
    bool PerClusterOnlyDamageThreshold; // 0x82 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_83[0x1]; // 0x83 (Size: 0x1, Type: PaddingProperty)
    FGeometryCollectionDamagePropagationData DamagePropagationData; // 0x84 (Size: 0xc, Type: StructProperty)
    uint8_t ClusterConnectionType; // 0x90 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_91[0x3]; // 0x91 (Size: 0x3, Type: PaddingProperty)
    float ConnectionGraphBoundsFilteringMargin; // 0x94 (Size: 0x4, Type: FloatProperty)
    TArray<UMaterialInterface*> Materials; // 0x98 (Size: 0x10, Type: ArrayProperty)
    TArray<FGeometryCollectionEmbeddedExemplar> EmbeddedGeometryExemplar; // 0xa8 (Size: 0x10, Type: ArrayProperty)
    bool bUseFullPrecisionUVs; // 0xb8 (Size: 0x1, Type: BoolProperty)
    bool bStripOnCook; // 0xb9 (Size: 0x1, Type: BoolProperty)
    bool bStripRenderDataOnCook; // 0xba (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_bb[0x5]; // 0xbb (Size: 0x5, Type: PaddingProperty)
    UClass* CustomRendererType; // 0xc0 (Size: 0x8, Type: ClassProperty)
    FGeometryCollectionProxyMeshData RootProxyData; // 0xc8 (Size: 0x20, Type: StructProperty)
    TArray<FGeometryCollectionAutoInstanceMesh> AutoInstanceMeshes; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    bool EnableNanite; // 0xf8 (Size: 0x1, Type: BoolProperty)
    bool bEnableNaniteFallback; // 0xf9 (Size: 0x1, Type: BoolProperty)
    bool bConvertVertexColorsToSRGB; // 0xfa (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_fb[0x5]; // 0xfb (Size: 0x5, Type: PaddingProperty)
    UPhysicalMaterial* PhysicsMaterial; // 0x100 (Size: 0x8, Type: ObjectProperty)
    bool bDensityFromPhysicsMaterial; // 0x108 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_109[0x3]; // 0x109 (Size: 0x3, Type: PaddingProperty)
    float CachedDensityFromPhysicsMaterialInGCm3; // 0x10c (Size: 0x4, Type: FloatProperty)
    bool bMassAsDensity; // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_111[0x3]; // 0x111 (Size: 0x3, Type: PaddingProperty)
    float Mass; // 0x114 (Size: 0x4, Type: FloatProperty)
    float MinimumMassClamp; // 0x118 (Size: 0x4, Type: FloatProperty)
    bool bImportCollisionFromSource; // 0x11c (Size: 0x1, Type: BoolProperty)
    bool bOptimizeConvexes; // 0x11d (Size: 0x1, Type: BoolProperty)
    bool bScaleOnRemoval; // 0x11e (Size: 0x1, Type: BoolProperty)
    bool bRemoveOnMaxSleep; // 0x11f (Size: 0x1, Type: BoolProperty)
    bool bAutomaticCrumblePartialClusters; // 0x120 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_121[0x7]; // 0x121 (Size: 0x7, Type: PaddingProperty)
    FVector2D MaximumSleepTime; // 0x128 (Size: 0x10, Type: StructProperty)
    FVector2D RemovalDuration; // 0x138 (Size: 0x10, Type: StructProperty)
    bool bSlowMovingAsSleeping; // 0x148 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_149[0x3]; // 0x149 (Size: 0x3, Type: PaddingProperty)
    float SlowMovingVelocityThreshold; // 0x14c (Size: 0x4, Type: FloatProperty)
    TArray<FGeometryCollectionSizeSpecificData> SizeSpecificData; // 0x150 (Size: 0x10, Type: ArrayProperty)
    bool EnableRemovePiecesOnFracture; // 0x160 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_161[0x7]; // 0x161 (Size: 0x7, Type: PaddingProperty)
    TArray<UMaterialInterface*> RemoveOnFractureMaterials; // 0x168 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FString> Overrides; // 0x178 (Size: 0x50, Type: MapProperty)
    FDataflowInstance DataflowInstance; // 0x1c8 (Size: 0x40, Type: StructProperty)
    FGuid PersistentGuid; // 0x208 (Size: 0x10, Type: StructProperty)
    FGuid StateGuid; // 0x218 (Size: 0x10, Type: StructProperty)
    int32_t RootIndex; // 0x228 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_22c[0x4]; // 0x22c (Size: 0x4, Type: PaddingProperty)
    TArray<int32_t> BreadthFirstTransformIndices; // 0x230 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> AutoInstanceTransformRemapIndices; // 0x240 (Size: 0x10, Type: ArrayProperty)
    int32_t BoneSelectedMaterialIndex; // 0x250 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_254[0x14]; // 0x254 (Size: 0x14, Type: PaddingProperty)
    TArray<UAssetUserData*> AssetUserData; // 0x268 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_278[0x8]; // 0x278 (Size: 0x8, Type: PaddingProperty)

public:
    UDataflow* GetDataflowAsset() const; // 0x9f5615c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetConvertVertexColorsToSRGB(bool& bValue); // 0x9f56174 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetDataflowAsset(UDataflow*& InDataflowAsset); // 0x9f562a8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void SetEnableNanite(bool& bValue); // 0x9f565b4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryCollection) == 0x280, "Size mismatch for UGeometryCollection");
static_assert(offsetof(UGeometryCollection, EnableClustering) == 0x60, "Offset mismatch for UGeometryCollection::EnableClustering");
static_assert(offsetof(UGeometryCollection, ClusterGroupIndex) == 0x64, "Offset mismatch for UGeometryCollection::ClusterGroupIndex");
static_assert(offsetof(UGeometryCollection, MaxClusterLevel) == 0x68, "Offset mismatch for UGeometryCollection::MaxClusterLevel");
static_assert(offsetof(UGeometryCollection, DamageModel) == 0x6c, "Offset mismatch for UGeometryCollection::DamageModel");
static_assert(offsetof(UGeometryCollection, DamageThreshold) == 0x70, "Offset mismatch for UGeometryCollection::DamageThreshold");
static_assert(offsetof(UGeometryCollection, bUseSizeSpecificDamageThreshold) == 0x80, "Offset mismatch for UGeometryCollection::bUseSizeSpecificDamageThreshold");
static_assert(offsetof(UGeometryCollection, bUseMaterialDamageModifiers) == 0x81, "Offset mismatch for UGeometryCollection::bUseMaterialDamageModifiers");
static_assert(offsetof(UGeometryCollection, PerClusterOnlyDamageThreshold) == 0x82, "Offset mismatch for UGeometryCollection::PerClusterOnlyDamageThreshold");
static_assert(offsetof(UGeometryCollection, DamagePropagationData) == 0x84, "Offset mismatch for UGeometryCollection::DamagePropagationData");
static_assert(offsetof(UGeometryCollection, ClusterConnectionType) == 0x90, "Offset mismatch for UGeometryCollection::ClusterConnectionType");
static_assert(offsetof(UGeometryCollection, ConnectionGraphBoundsFilteringMargin) == 0x94, "Offset mismatch for UGeometryCollection::ConnectionGraphBoundsFilteringMargin");
static_assert(offsetof(UGeometryCollection, Materials) == 0x98, "Offset mismatch for UGeometryCollection::Materials");
static_assert(offsetof(UGeometryCollection, EmbeddedGeometryExemplar) == 0xa8, "Offset mismatch for UGeometryCollection::EmbeddedGeometryExemplar");
static_assert(offsetof(UGeometryCollection, bUseFullPrecisionUVs) == 0xb8, "Offset mismatch for UGeometryCollection::bUseFullPrecisionUVs");
static_assert(offsetof(UGeometryCollection, bStripOnCook) == 0xb9, "Offset mismatch for UGeometryCollection::bStripOnCook");
static_assert(offsetof(UGeometryCollection, bStripRenderDataOnCook) == 0xba, "Offset mismatch for UGeometryCollection::bStripRenderDataOnCook");
static_assert(offsetof(UGeometryCollection, CustomRendererType) == 0xc0, "Offset mismatch for UGeometryCollection::CustomRendererType");
static_assert(offsetof(UGeometryCollection, RootProxyData) == 0xc8, "Offset mismatch for UGeometryCollection::RootProxyData");
static_assert(offsetof(UGeometryCollection, AutoInstanceMeshes) == 0xe8, "Offset mismatch for UGeometryCollection::AutoInstanceMeshes");
static_assert(offsetof(UGeometryCollection, EnableNanite) == 0xf8, "Offset mismatch for UGeometryCollection::EnableNanite");
static_assert(offsetof(UGeometryCollection, bEnableNaniteFallback) == 0xf9, "Offset mismatch for UGeometryCollection::bEnableNaniteFallback");
static_assert(offsetof(UGeometryCollection, bConvertVertexColorsToSRGB) == 0xfa, "Offset mismatch for UGeometryCollection::bConvertVertexColorsToSRGB");
static_assert(offsetof(UGeometryCollection, PhysicsMaterial) == 0x100, "Offset mismatch for UGeometryCollection::PhysicsMaterial");
static_assert(offsetof(UGeometryCollection, bDensityFromPhysicsMaterial) == 0x108, "Offset mismatch for UGeometryCollection::bDensityFromPhysicsMaterial");
static_assert(offsetof(UGeometryCollection, CachedDensityFromPhysicsMaterialInGCm3) == 0x10c, "Offset mismatch for UGeometryCollection::CachedDensityFromPhysicsMaterialInGCm3");
static_assert(offsetof(UGeometryCollection, bMassAsDensity) == 0x110, "Offset mismatch for UGeometryCollection::bMassAsDensity");
static_assert(offsetof(UGeometryCollection, Mass) == 0x114, "Offset mismatch for UGeometryCollection::Mass");
static_assert(offsetof(UGeometryCollection, MinimumMassClamp) == 0x118, "Offset mismatch for UGeometryCollection::MinimumMassClamp");
static_assert(offsetof(UGeometryCollection, bImportCollisionFromSource) == 0x11c, "Offset mismatch for UGeometryCollection::bImportCollisionFromSource");
static_assert(offsetof(UGeometryCollection, bOptimizeConvexes) == 0x11d, "Offset mismatch for UGeometryCollection::bOptimizeConvexes");
static_assert(offsetof(UGeometryCollection, bScaleOnRemoval) == 0x11e, "Offset mismatch for UGeometryCollection::bScaleOnRemoval");
static_assert(offsetof(UGeometryCollection, bRemoveOnMaxSleep) == 0x11f, "Offset mismatch for UGeometryCollection::bRemoveOnMaxSleep");
static_assert(offsetof(UGeometryCollection, bAutomaticCrumblePartialClusters) == 0x120, "Offset mismatch for UGeometryCollection::bAutomaticCrumblePartialClusters");
static_assert(offsetof(UGeometryCollection, MaximumSleepTime) == 0x128, "Offset mismatch for UGeometryCollection::MaximumSleepTime");
static_assert(offsetof(UGeometryCollection, RemovalDuration) == 0x138, "Offset mismatch for UGeometryCollection::RemovalDuration");
static_assert(offsetof(UGeometryCollection, bSlowMovingAsSleeping) == 0x148, "Offset mismatch for UGeometryCollection::bSlowMovingAsSleeping");
static_assert(offsetof(UGeometryCollection, SlowMovingVelocityThreshold) == 0x14c, "Offset mismatch for UGeometryCollection::SlowMovingVelocityThreshold");
static_assert(offsetof(UGeometryCollection, SizeSpecificData) == 0x150, "Offset mismatch for UGeometryCollection::SizeSpecificData");
static_assert(offsetof(UGeometryCollection, EnableRemovePiecesOnFracture) == 0x160, "Offset mismatch for UGeometryCollection::EnableRemovePiecesOnFracture");
static_assert(offsetof(UGeometryCollection, RemoveOnFractureMaterials) == 0x168, "Offset mismatch for UGeometryCollection::RemoveOnFractureMaterials");
static_assert(offsetof(UGeometryCollection, Overrides) == 0x178, "Offset mismatch for UGeometryCollection::Overrides");
static_assert(offsetof(UGeometryCollection, DataflowInstance) == 0x1c8, "Offset mismatch for UGeometryCollection::DataflowInstance");
static_assert(offsetof(UGeometryCollection, PersistentGuid) == 0x208, "Offset mismatch for UGeometryCollection::PersistentGuid");
static_assert(offsetof(UGeometryCollection, StateGuid) == 0x218, "Offset mismatch for UGeometryCollection::StateGuid");
static_assert(offsetof(UGeometryCollection, RootIndex) == 0x228, "Offset mismatch for UGeometryCollection::RootIndex");
static_assert(offsetof(UGeometryCollection, BreadthFirstTransformIndices) == 0x230, "Offset mismatch for UGeometryCollection::BreadthFirstTransformIndices");
static_assert(offsetof(UGeometryCollection, AutoInstanceTransformRemapIndices) == 0x240, "Offset mismatch for UGeometryCollection::AutoInstanceTransformRemapIndices");
static_assert(offsetof(UGeometryCollection, BoneSelectedMaterialIndex) == 0x250, "Offset mismatch for UGeometryCollection::BoneSelectedMaterialIndex");
static_assert(offsetof(UGeometryCollection, AssetUserData) == 0x268, "Offset mismatch for UGeometryCollection::AssetUserData");

// Size: 0x3a0 (Inherited: 0x2d0, Single: 0xd0)
class AGeometryCollectionRenderLevelSetActor : public AActor
{
public:
    UVolumeTexture* TargetVolumeTexture; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UMaterial* RayMarchMaterial; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    float SurfaceTolerance; // 0x2b8 (Size: 0x4, Type: FloatProperty)
    float Isovalue; // 0x2bc (Size: 0x4, Type: FloatProperty)
    bool Enabled; // 0x2c0 (Size: 0x1, Type: BoolProperty)
    bool RenderVolumeBoundingBox; // 0x2c1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2c2[0xde]; // 0x2c2 (Size: 0xde, Type: PaddingProperty)
};

static_assert(sizeof(AGeometryCollectionRenderLevelSetActor) == 0x3a0, "Size mismatch for AGeometryCollectionRenderLevelSetActor");
static_assert(offsetof(AGeometryCollectionRenderLevelSetActor, TargetVolumeTexture) == 0x2a8, "Offset mismatch for AGeometryCollectionRenderLevelSetActor::TargetVolumeTexture");
static_assert(offsetof(AGeometryCollectionRenderLevelSetActor, RayMarchMaterial) == 0x2b0, "Offset mismatch for AGeometryCollectionRenderLevelSetActor::RayMarchMaterial");
static_assert(offsetof(AGeometryCollectionRenderLevelSetActor, SurfaceTolerance) == 0x2b8, "Offset mismatch for AGeometryCollectionRenderLevelSetActor::SurfaceTolerance");
static_assert(offsetof(AGeometryCollectionRenderLevelSetActor, Isovalue) == 0x2bc, "Offset mismatch for AGeometryCollectionRenderLevelSetActor::Isovalue");
static_assert(offsetof(AGeometryCollectionRenderLevelSetActor, Enabled) == 0x2c0, "Offset mismatch for AGeometryCollectionRenderLevelSetActor::Enabled");
static_assert(offsetof(AGeometryCollectionRenderLevelSetActor, RenderVolumeBoundingBox) == 0x2c1, "Offset mismatch for AGeometryCollectionRenderLevelSetActor::RenderVolumeBoundingBox");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UGeometryCollectionRootProxyRenderer : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TArray<UStaticMeshComponent*> StaticMeshComponents; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_40[0x8]; // 0x40 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UGeometryCollectionRootProxyRenderer) == 0x48, "Size mismatch for UGeometryCollectionRootProxyRenderer");
static_assert(offsetof(UGeometryCollectionRootProxyRenderer, StaticMeshComponents) == 0x30, "Offset mismatch for UGeometryCollectionRootProxyRenderer::StaticMeshComponents");

// Size: 0x590 (Inherited: 0xdc0, Single: 0xfffff7d0)
class UGeometryCollectionISMPoolDebugDrawComponent : public UDebugDrawComponent
{
public:
    bool bShowGlobalStats; // 0x578 (Size: 0x1, Type: BoolProperty)
    bool bShowStats; // 0x579 (Size: 0x1, Type: BoolProperty)
    bool bShowBounds; // 0x57a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_57b[0x5]; // 0x57b (Size: 0x5, Type: PaddingProperty)
    UInstancedStaticMeshComponent* SelectedComponent; // 0x580 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_588[0x8]; // 0x588 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UGeometryCollectionISMPoolDebugDrawComponent) == 0x590, "Size mismatch for UGeometryCollectionISMPoolDebugDrawComponent");
static_assert(offsetof(UGeometryCollectionISMPoolDebugDrawComponent, bShowGlobalStats) == 0x578, "Offset mismatch for UGeometryCollectionISMPoolDebugDrawComponent::bShowGlobalStats");
static_assert(offsetof(UGeometryCollectionISMPoolDebugDrawComponent, bShowStats) == 0x579, "Offset mismatch for UGeometryCollectionISMPoolDebugDrawComponent::bShowStats");
static_assert(offsetof(UGeometryCollectionISMPoolDebugDrawComponent, bShowBounds) == 0x57a, "Offset mismatch for UGeometryCollectionISMPoolDebugDrawComponent::bShowBounds");
static_assert(offsetof(UGeometryCollectionISMPoolDebugDrawComponent, SelectedComponent) == 0x580, "Offset mismatch for UGeometryCollectionISMPoolDebugDrawComponent::SelectedComponent");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FChaosBreakingEventData
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Velocity; // 0x18 (Size: 0x18, Type: StructProperty)
    float Mass; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FChaosBreakingEventData) == 0x38, "Size mismatch for FChaosBreakingEventData");
static_assert(offsetof(FChaosBreakingEventData, Location) == 0x0, "Offset mismatch for FChaosBreakingEventData::Location");
static_assert(offsetof(FChaosBreakingEventData, Velocity) == 0x18, "Offset mismatch for FChaosBreakingEventData::Velocity");
static_assert(offsetof(FChaosBreakingEventData, Mass) == 0x30, "Offset mismatch for FChaosBreakingEventData::Mass");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FChaosCollisionEventData
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Normal; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector Velocity1; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector Velocity2; // 0x48 (Size: 0x18, Type: StructProperty)
    float Mass1; // 0x60 (Size: 0x4, Type: FloatProperty)
    float Mass2; // 0x64 (Size: 0x4, Type: FloatProperty)
    FVector Impulse; // 0x68 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FChaosCollisionEventData) == 0x80, "Size mismatch for FChaosCollisionEventData");
static_assert(offsetof(FChaosCollisionEventData, Location) == 0x0, "Offset mismatch for FChaosCollisionEventData::Location");
static_assert(offsetof(FChaosCollisionEventData, Normal) == 0x18, "Offset mismatch for FChaosCollisionEventData::Normal");
static_assert(offsetof(FChaosCollisionEventData, Velocity1) == 0x30, "Offset mismatch for FChaosCollisionEventData::Velocity1");
static_assert(offsetof(FChaosCollisionEventData, Velocity2) == 0x48, "Offset mismatch for FChaosCollisionEventData::Velocity2");
static_assert(offsetof(FChaosCollisionEventData, Mass1) == 0x60, "Offset mismatch for FChaosCollisionEventData::Mass1");
static_assert(offsetof(FChaosCollisionEventData, Mass2) == 0x64, "Offset mismatch for FChaosCollisionEventData::Mass2");
static_assert(offsetof(FChaosCollisionEventData, Impulse) == 0x68, "Offset mismatch for FChaosCollisionEventData::Impulse");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FChaosRemovalEventData
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    float Mass; // 0x18 (Size: 0x4, Type: FloatProperty)
    int32_t ParticleIndex; // 0x1c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FChaosRemovalEventData) == 0x20, "Size mismatch for FChaosRemovalEventData");
static_assert(offsetof(FChaosRemovalEventData, Location) == 0x0, "Offset mismatch for FChaosRemovalEventData::Location");
static_assert(offsetof(FChaosRemovalEventData, Mass) == 0x18, "Offset mismatch for FChaosRemovalEventData::Mass");
static_assert(offsetof(FChaosRemovalEventData, ParticleIndex) == 0x1c, "Offset mismatch for FChaosRemovalEventData::ParticleIndex");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FChaosTrailingEventData
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Velocity; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity; // 0x30 (Size: 0x18, Type: StructProperty)
    float Mass; // 0x48 (Size: 0x4, Type: FloatProperty)
    int32_t ParticleIndex; // 0x4c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FChaosTrailingEventData) == 0x50, "Size mismatch for FChaosTrailingEventData");
static_assert(offsetof(FChaosTrailingEventData, Location) == 0x0, "Offset mismatch for FChaosTrailingEventData::Location");
static_assert(offsetof(FChaosTrailingEventData, Velocity) == 0x18, "Offset mismatch for FChaosTrailingEventData::Velocity");
static_assert(offsetof(FChaosTrailingEventData, AngularVelocity) == 0x30, "Offset mismatch for FChaosTrailingEventData::AngularVelocity");
static_assert(offsetof(FChaosTrailingEventData, Mass) == 0x48, "Offset mismatch for FChaosTrailingEventData::Mass");
static_assert(offsetof(FChaosTrailingEventData, ParticleIndex) == 0x4c, "Offset mismatch for FChaosTrailingEventData::ParticleIndex");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryCollectionDamagePropagationData
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float BreakDamagePropagationFactor; // 0x4 (Size: 0x4, Type: FloatProperty)
    float ShockDamagePropagationFactor; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryCollectionDamagePropagationData) == 0xc, "Size mismatch for FGeometryCollectionDamagePropagationData");
static_assert(offsetof(FGeometryCollectionDamagePropagationData, bEnabled) == 0x0, "Offset mismatch for FGeometryCollectionDamagePropagationData::bEnabled");
static_assert(offsetof(FGeometryCollectionDamagePropagationData, BreakDamagePropagationFactor) == 0x4, "Offset mismatch for FGeometryCollectionDamagePropagationData::BreakDamagePropagationFactor");
static_assert(offsetof(FGeometryCollectionDamagePropagationData, ShockDamagePropagationFactor) == 0x8, "Offset mismatch for FGeometryCollectionDamagePropagationData::ShockDamagePropagationFactor");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGeometryCollectionRepDynamicData
{
};

static_assert(sizeof(FGeometryCollectionRepDynamicData) == 0x18, "Size mismatch for FGeometryCollectionRepDynamicData");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FGeometryCollectionRepStateData
{
};

static_assert(sizeof(FGeometryCollectionRepStateData) == 0x40, "Size mismatch for FGeometryCollectionRepStateData");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FGeometryCollectionRepData
{
};

static_assert(sizeof(FGeometryCollectionRepData) == 0x38, "Size mismatch for FGeometryCollectionRepData");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FGeomComponentCacheParameters
{
    uint8_t CacheMode; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UGeometryCollectionCache* TargetCache; // 0x8 (Size: 0x8, Type: ObjectProperty)
    float ReverseCacheBeginTime; // 0x10 (Size: 0x4, Type: FloatProperty)
    bool SaveCollisionData; // 0x14 (Size: 0x1, Type: BoolProperty)
    bool DoGenerateCollisionData; // 0x15 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_16[0x2]; // 0x16 (Size: 0x2, Type: PaddingProperty)
    int32_t CollisionDataSizeMax; // 0x18 (Size: 0x4, Type: IntProperty)
    bool DoCollisionDataSpatialHash; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
    float CollisionDataSpatialHashRadius; // 0x20 (Size: 0x4, Type: FloatProperty)
    int32_t MaxCollisionPerCell; // 0x24 (Size: 0x4, Type: IntProperty)
    bool SaveBreakingData; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool DoGenerateBreakingData; // 0x29 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    int32_t BreakingDataSizeMax; // 0x2c (Size: 0x4, Type: IntProperty)
    bool DoBreakingDataSpatialHash; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x3]; // 0x31 (Size: 0x3, Type: PaddingProperty)
    float BreakingDataSpatialHashRadius; // 0x34 (Size: 0x4, Type: FloatProperty)
    int32_t MaxBreakingPerCell; // 0x38 (Size: 0x4, Type: IntProperty)
    bool SaveTrailingData; // 0x3c (Size: 0x1, Type: BoolProperty)
    bool DoGenerateTrailingData; // 0x3d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3e[0x2]; // 0x3e (Size: 0x2, Type: PaddingProperty)
    int32_t TrailingDataSizeMax; // 0x40 (Size: 0x4, Type: IntProperty)
    float TrailingMinSpeedThreshold; // 0x44 (Size: 0x4, Type: FloatProperty)
    float TrailingMinVolumeThreshold; // 0x48 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGeomComponentCacheParameters) == 0x50, "Size mismatch for FGeomComponentCacheParameters");
static_assert(offsetof(FGeomComponentCacheParameters, CacheMode) == 0x0, "Offset mismatch for FGeomComponentCacheParameters::CacheMode");
static_assert(offsetof(FGeomComponentCacheParameters, TargetCache) == 0x8, "Offset mismatch for FGeomComponentCacheParameters::TargetCache");
static_assert(offsetof(FGeomComponentCacheParameters, ReverseCacheBeginTime) == 0x10, "Offset mismatch for FGeomComponentCacheParameters::ReverseCacheBeginTime");
static_assert(offsetof(FGeomComponentCacheParameters, SaveCollisionData) == 0x14, "Offset mismatch for FGeomComponentCacheParameters::SaveCollisionData");
static_assert(offsetof(FGeomComponentCacheParameters, DoGenerateCollisionData) == 0x15, "Offset mismatch for FGeomComponentCacheParameters::DoGenerateCollisionData");
static_assert(offsetof(FGeomComponentCacheParameters, CollisionDataSizeMax) == 0x18, "Offset mismatch for FGeomComponentCacheParameters::CollisionDataSizeMax");
static_assert(offsetof(FGeomComponentCacheParameters, DoCollisionDataSpatialHash) == 0x1c, "Offset mismatch for FGeomComponentCacheParameters::DoCollisionDataSpatialHash");
static_assert(offsetof(FGeomComponentCacheParameters, CollisionDataSpatialHashRadius) == 0x20, "Offset mismatch for FGeomComponentCacheParameters::CollisionDataSpatialHashRadius");
static_assert(offsetof(FGeomComponentCacheParameters, MaxCollisionPerCell) == 0x24, "Offset mismatch for FGeomComponentCacheParameters::MaxCollisionPerCell");
static_assert(offsetof(FGeomComponentCacheParameters, SaveBreakingData) == 0x28, "Offset mismatch for FGeomComponentCacheParameters::SaveBreakingData");
static_assert(offsetof(FGeomComponentCacheParameters, DoGenerateBreakingData) == 0x29, "Offset mismatch for FGeomComponentCacheParameters::DoGenerateBreakingData");
static_assert(offsetof(FGeomComponentCacheParameters, BreakingDataSizeMax) == 0x2c, "Offset mismatch for FGeomComponentCacheParameters::BreakingDataSizeMax");
static_assert(offsetof(FGeomComponentCacheParameters, DoBreakingDataSpatialHash) == 0x30, "Offset mismatch for FGeomComponentCacheParameters::DoBreakingDataSpatialHash");
static_assert(offsetof(FGeomComponentCacheParameters, BreakingDataSpatialHashRadius) == 0x34, "Offset mismatch for FGeomComponentCacheParameters::BreakingDataSpatialHashRadius");
static_assert(offsetof(FGeomComponentCacheParameters, MaxBreakingPerCell) == 0x38, "Offset mismatch for FGeomComponentCacheParameters::MaxBreakingPerCell");
static_assert(offsetof(FGeomComponentCacheParameters, SaveTrailingData) == 0x3c, "Offset mismatch for FGeomComponentCacheParameters::SaveTrailingData");
static_assert(offsetof(FGeomComponentCacheParameters, DoGenerateTrailingData) == 0x3d, "Offset mismatch for FGeomComponentCacheParameters::DoGenerateTrailingData");
static_assert(offsetof(FGeomComponentCacheParameters, TrailingDataSizeMax) == 0x40, "Offset mismatch for FGeomComponentCacheParameters::TrailingDataSizeMax");
static_assert(offsetof(FGeomComponentCacheParameters, TrailingMinSpeedThreshold) == 0x44, "Offset mismatch for FGeomComponentCacheParameters::TrailingMinSpeedThreshold");
static_assert(offsetof(FGeomComponentCacheParameters, TrailingMinVolumeThreshold) == 0x48, "Offset mismatch for FGeomComponentCacheParameters::TrailingMinVolumeThreshold");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FChaosBreakingEventRequestSettings
{
    int32_t MaxNumberOfResults; // 0x0 (Size: 0x4, Type: IntProperty)
    float MinRadius; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinSpeed; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinMass; // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxDistance; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t SortMethod; // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FChaosBreakingEventRequestSettings) == 0x18, "Size mismatch for FChaosBreakingEventRequestSettings");
static_assert(offsetof(FChaosBreakingEventRequestSettings, MaxNumberOfResults) == 0x0, "Offset mismatch for FChaosBreakingEventRequestSettings::MaxNumberOfResults");
static_assert(offsetof(FChaosBreakingEventRequestSettings, MinRadius) == 0x4, "Offset mismatch for FChaosBreakingEventRequestSettings::MinRadius");
static_assert(offsetof(FChaosBreakingEventRequestSettings, MinSpeed) == 0x8, "Offset mismatch for FChaosBreakingEventRequestSettings::MinSpeed");
static_assert(offsetof(FChaosBreakingEventRequestSettings, MinMass) == 0xc, "Offset mismatch for FChaosBreakingEventRequestSettings::MinMass");
static_assert(offsetof(FChaosBreakingEventRequestSettings, MaxDistance) == 0x10, "Offset mismatch for FChaosBreakingEventRequestSettings::MaxDistance");
static_assert(offsetof(FChaosBreakingEventRequestSettings, SortMethod) == 0x14, "Offset mismatch for FChaosBreakingEventRequestSettings::SortMethod");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FChaosCollisionEventRequestSettings
{
    int32_t MaxNumberResults; // 0x0 (Size: 0x4, Type: IntProperty)
    float MinMass; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinSpeed; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinImpulse; // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxDistance; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t SortMethod; // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FChaosCollisionEventRequestSettings) == 0x18, "Size mismatch for FChaosCollisionEventRequestSettings");
static_assert(offsetof(FChaosCollisionEventRequestSettings, MaxNumberResults) == 0x0, "Offset mismatch for FChaosCollisionEventRequestSettings::MaxNumberResults");
static_assert(offsetof(FChaosCollisionEventRequestSettings, MinMass) == 0x4, "Offset mismatch for FChaosCollisionEventRequestSettings::MinMass");
static_assert(offsetof(FChaosCollisionEventRequestSettings, MinSpeed) == 0x8, "Offset mismatch for FChaosCollisionEventRequestSettings::MinSpeed");
static_assert(offsetof(FChaosCollisionEventRequestSettings, MinImpulse) == 0xc, "Offset mismatch for FChaosCollisionEventRequestSettings::MinImpulse");
static_assert(offsetof(FChaosCollisionEventRequestSettings, MaxDistance) == 0x10, "Offset mismatch for FChaosCollisionEventRequestSettings::MaxDistance");
static_assert(offsetof(FChaosCollisionEventRequestSettings, SortMethod) == 0x14, "Offset mismatch for FChaosCollisionEventRequestSettings::SortMethod");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FChaosRemovalEventRequestSettings
{
    int32_t MaxNumberOfResults; // 0x0 (Size: 0x4, Type: IntProperty)
    float MinMass; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaxDistance; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t SortMethod; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FChaosRemovalEventRequestSettings) == 0x10, "Size mismatch for FChaosRemovalEventRequestSettings");
static_assert(offsetof(FChaosRemovalEventRequestSettings, MaxNumberOfResults) == 0x0, "Offset mismatch for FChaosRemovalEventRequestSettings::MaxNumberOfResults");
static_assert(offsetof(FChaosRemovalEventRequestSettings, MinMass) == 0x4, "Offset mismatch for FChaosRemovalEventRequestSettings::MinMass");
static_assert(offsetof(FChaosRemovalEventRequestSettings, MaxDistance) == 0x8, "Offset mismatch for FChaosRemovalEventRequestSettings::MaxDistance");
static_assert(offsetof(FChaosRemovalEventRequestSettings, SortMethod) == 0xc, "Offset mismatch for FChaosRemovalEventRequestSettings::SortMethod");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FChaosTrailingEventRequestSettings
{
    int32_t MaxNumberOfResults; // 0x0 (Size: 0x4, Type: IntProperty)
    float MinMass; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinSpeed; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinAngularSpeed; // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxDistance; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t SortMethod; // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FChaosTrailingEventRequestSettings) == 0x18, "Size mismatch for FChaosTrailingEventRequestSettings");
static_assert(offsetof(FChaosTrailingEventRequestSettings, MaxNumberOfResults) == 0x0, "Offset mismatch for FChaosTrailingEventRequestSettings::MaxNumberOfResults");
static_assert(offsetof(FChaosTrailingEventRequestSettings, MinMass) == 0x4, "Offset mismatch for FChaosTrailingEventRequestSettings::MinMass");
static_assert(offsetof(FChaosTrailingEventRequestSettings, MinSpeed) == 0x8, "Offset mismatch for FChaosTrailingEventRequestSettings::MinSpeed");
static_assert(offsetof(FChaosTrailingEventRequestSettings, MinAngularSpeed) == 0xc, "Offset mismatch for FChaosTrailingEventRequestSettings::MinAngularSpeed");
static_assert(offsetof(FChaosTrailingEventRequestSettings, MaxDistance) == 0x10, "Offset mismatch for FChaosTrailingEventRequestSettings::MaxDistance");
static_assert(offsetof(FChaosTrailingEventRequestSettings, SortMethod) == 0x14, "Offset mismatch for FChaosTrailingEventRequestSettings::SortMethod");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGeometryCollectionDebugDrawWarningMessage
{
};

static_assert(sizeof(FGeometryCollectionDebugDrawWarningMessage) == 0x1, "Size mismatch for FGeometryCollectionDebugDrawWarningMessage");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGeometryCollectionDebugDrawActorSelectedRigidBody
{
    int32_t ID; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    AChaosSolverActor* Solver; // 0x8 (Size: 0x8, Type: ObjectProperty)
    AGeometryCollectionActor* GeometryCollection; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGeometryCollectionDebugDrawActorSelectedRigidBody) == 0x18, "Size mismatch for FGeometryCollectionDebugDrawActorSelectedRigidBody");
static_assert(offsetof(FGeometryCollectionDebugDrawActorSelectedRigidBody, ID) == 0x0, "Offset mismatch for FGeometryCollectionDebugDrawActorSelectedRigidBody::ID");
static_assert(offsetof(FGeometryCollectionDebugDrawActorSelectedRigidBody, Solver) == 0x8, "Offset mismatch for FGeometryCollectionDebugDrawActorSelectedRigidBody::Solver");
static_assert(offsetof(FGeometryCollectionDebugDrawActorSelectedRigidBody, GeometryCollection) == 0x10, "Offset mismatch for FGeometryCollectionDebugDrawActorSelectedRigidBody::GeometryCollection");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FGeometryCollectionSource
{
    FSoftObjectPath SourceGeometryObject; // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform LocalTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    TArray<UMaterialInterface*> SourceMaterial; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<float> InstanceCustomData; // 0x90 (Size: 0x10, Type: ArrayProperty)
    bool bAddInternalMaterials; // 0xa0 (Size: 0x1, Type: BoolProperty)
    bool bSplitComponents; // 0xa1 (Size: 0x1, Type: BoolProperty)
    bool bSetInternalFromMaterialIndex; // 0xa2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a3[0xd]; // 0xa3 (Size: 0xd, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryCollectionSource) == 0xb0, "Size mismatch for FGeometryCollectionSource");
static_assert(offsetof(FGeometryCollectionSource, SourceGeometryObject) == 0x0, "Offset mismatch for FGeometryCollectionSource::SourceGeometryObject");
static_assert(offsetof(FGeometryCollectionSource, LocalTransform) == 0x20, "Offset mismatch for FGeometryCollectionSource::LocalTransform");
static_assert(offsetof(FGeometryCollectionSource, SourceMaterial) == 0x80, "Offset mismatch for FGeometryCollectionSource::SourceMaterial");
static_assert(offsetof(FGeometryCollectionSource, InstanceCustomData) == 0x90, "Offset mismatch for FGeometryCollectionSource::InstanceCustomData");
static_assert(offsetof(FGeometryCollectionSource, bAddInternalMaterials) == 0xa0, "Offset mismatch for FGeometryCollectionSource::bAddInternalMaterials");
static_assert(offsetof(FGeometryCollectionSource, bSplitComponents) == 0xa1, "Offset mismatch for FGeometryCollectionSource::bSplitComponents");
static_assert(offsetof(FGeometryCollectionSource, bSetInternalFromMaterialIndex) == 0xa2, "Offset mismatch for FGeometryCollectionSource::bSetInternalFromMaterialIndex");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FGeometryCollectionAutoInstanceMesh
{
    UStaticMesh* Mesh; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInterface*> Materials; // 0x8 (Size: 0x10, Type: ArrayProperty)
    int32_t NumInstances; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    TArray<float> CustomData; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGeometryCollectionAutoInstanceMesh) == 0x30, "Size mismatch for FGeometryCollectionAutoInstanceMesh");
static_assert(offsetof(FGeometryCollectionAutoInstanceMesh, Mesh) == 0x0, "Offset mismatch for FGeometryCollectionAutoInstanceMesh::Mesh");
static_assert(offsetof(FGeometryCollectionAutoInstanceMesh, Materials) == 0x8, "Offset mismatch for FGeometryCollectionAutoInstanceMesh::Materials");
static_assert(offsetof(FGeometryCollectionAutoInstanceMesh, NumInstances) == 0x18, "Offset mismatch for FGeometryCollectionAutoInstanceMesh::NumInstances");
static_assert(offsetof(FGeometryCollectionAutoInstanceMesh, CustomData) == 0x20, "Offset mismatch for FGeometryCollectionAutoInstanceMesh::CustomData");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGeometryCollectionEmbeddedExemplar
{
    FSoftObjectPath StaticMeshExemplar; // 0x0 (Size: 0x18, Type: StructProperty)
    float StartCullDistance; // 0x18 (Size: 0x4, Type: FloatProperty)
    float EndCullDistance; // 0x1c (Size: 0x4, Type: FloatProperty)
    int32_t InstanceCount; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryCollectionEmbeddedExemplar) == 0x28, "Size mismatch for FGeometryCollectionEmbeddedExemplar");
static_assert(offsetof(FGeometryCollectionEmbeddedExemplar, StaticMeshExemplar) == 0x0, "Offset mismatch for FGeometryCollectionEmbeddedExemplar::StaticMeshExemplar");
static_assert(offsetof(FGeometryCollectionEmbeddedExemplar, StartCullDistance) == 0x18, "Offset mismatch for FGeometryCollectionEmbeddedExemplar::StartCullDistance");
static_assert(offsetof(FGeometryCollectionEmbeddedExemplar, EndCullDistance) == 0x1c, "Offset mismatch for FGeometryCollectionEmbeddedExemplar::EndCullDistance");
static_assert(offsetof(FGeometryCollectionEmbeddedExemplar, InstanceCount) == 0x20, "Offset mismatch for FGeometryCollectionEmbeddedExemplar::InstanceCount");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryCollectionLevelSetData
{
    int32_t MinLevelSetResolution; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t MaxLevelSetResolution; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t MinClusterLevelSetResolution; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t MaxClusterLevelSetResolution; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryCollectionLevelSetData) == 0x10, "Size mismatch for FGeometryCollectionLevelSetData");
static_assert(offsetof(FGeometryCollectionLevelSetData, MinLevelSetResolution) == 0x0, "Offset mismatch for FGeometryCollectionLevelSetData::MinLevelSetResolution");
static_assert(offsetof(FGeometryCollectionLevelSetData, MaxLevelSetResolution) == 0x4, "Offset mismatch for FGeometryCollectionLevelSetData::MaxLevelSetResolution");
static_assert(offsetof(FGeometryCollectionLevelSetData, MinClusterLevelSetResolution) == 0x8, "Offset mismatch for FGeometryCollectionLevelSetData::MinClusterLevelSetResolution");
static_assert(offsetof(FGeometryCollectionLevelSetData, MaxClusterLevelSetResolution) == 0xc, "Offset mismatch for FGeometryCollectionLevelSetData::MaxClusterLevelSetResolution");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryCollectionCollisionParticleData
{
    float CollisionParticlesFraction; // 0x0 (Size: 0x4, Type: FloatProperty)
    int32_t MaximumCollisionParticles; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryCollectionCollisionParticleData) == 0x8, "Size mismatch for FGeometryCollectionCollisionParticleData");
static_assert(offsetof(FGeometryCollectionCollisionParticleData, CollisionParticlesFraction) == 0x0, "Offset mismatch for FGeometryCollectionCollisionParticleData::CollisionParticlesFraction");
static_assert(offsetof(FGeometryCollectionCollisionParticleData, MaximumCollisionParticles) == 0x4, "Offset mismatch for FGeometryCollectionCollisionParticleData::MaximumCollisionParticles");

// Size: 0x24 (Inherited: 0x0, Single: 0x24)
struct FGeometryCollectionCollisionTypeData
{
    uint8_t CollisionType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t ImplicitType; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    FGeometryCollectionLevelSetData LevelSet; // 0x4 (Size: 0x10, Type: StructProperty)
    FGeometryCollectionCollisionParticleData CollisionParticles; // 0x14 (Size: 0x8, Type: StructProperty)
    float CollisionObjectReductionPercentage; // 0x1c (Size: 0x4, Type: FloatProperty)
    float CollisionMarginFraction; // 0x20 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryCollectionCollisionTypeData) == 0x24, "Size mismatch for FGeometryCollectionCollisionTypeData");
static_assert(offsetof(FGeometryCollectionCollisionTypeData, CollisionType) == 0x0, "Offset mismatch for FGeometryCollectionCollisionTypeData::CollisionType");
static_assert(offsetof(FGeometryCollectionCollisionTypeData, ImplicitType) == 0x1, "Offset mismatch for FGeometryCollectionCollisionTypeData::ImplicitType");
static_assert(offsetof(FGeometryCollectionCollisionTypeData, LevelSet) == 0x4, "Offset mismatch for FGeometryCollectionCollisionTypeData::LevelSet");
static_assert(offsetof(FGeometryCollectionCollisionTypeData, CollisionParticles) == 0x14, "Offset mismatch for FGeometryCollectionCollisionTypeData::CollisionParticles");
static_assert(offsetof(FGeometryCollectionCollisionTypeData, CollisionObjectReductionPercentage) == 0x1c, "Offset mismatch for FGeometryCollectionCollisionTypeData::CollisionObjectReductionPercentage");
static_assert(offsetof(FGeometryCollectionCollisionTypeData, CollisionMarginFraction) == 0x20, "Offset mismatch for FGeometryCollectionCollisionTypeData::CollisionMarginFraction");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGeometryCollectionSizeSpecificData
{
    float MaxSize; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FGeometryCollectionCollisionTypeData> CollisionShapes; // 0x8 (Size: 0x10, Type: ArrayProperty)
    int32_t DamageThreshold; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryCollectionSizeSpecificData) == 0x20, "Size mismatch for FGeometryCollectionSizeSpecificData");
static_assert(offsetof(FGeometryCollectionSizeSpecificData, MaxSize) == 0x0, "Offset mismatch for FGeometryCollectionSizeSpecificData::MaxSize");
static_assert(offsetof(FGeometryCollectionSizeSpecificData, CollisionShapes) == 0x8, "Offset mismatch for FGeometryCollectionSizeSpecificData::CollisionShapes");
static_assert(offsetof(FGeometryCollectionSizeSpecificData, DamageThreshold) == 0x18, "Offset mismatch for FGeometryCollectionSizeSpecificData::DamageThreshold");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGeometryCollectionProxyMeshData
{
    TArray<UStaticMesh*> ProxyMeshes; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform3f> MeshTransforms; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGeometryCollectionProxyMeshData) == 0x20, "Size mismatch for FGeometryCollectionProxyMeshData");
static_assert(offsetof(FGeometryCollectionProxyMeshData, ProxyMeshes) == 0x0, "Offset mismatch for FGeometryCollectionProxyMeshData::ProxyMeshes");
static_assert(offsetof(FGeometryCollectionProxyMeshData, MeshTransforms) == 0x10, "Offset mismatch for FGeometryCollectionProxyMeshData::MeshTransforms");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryCollectionRenderResourceSizeInfo
{
    uint64_t MeshResourcesSize; // 0x0 (Size: 0x8, Type: UInt64Property)
    uint64_t NaniteResourcesSize; // 0x8 (Size: 0x8, Type: UInt64Property)
};

static_assert(sizeof(FGeometryCollectionRenderResourceSizeInfo) == 0x10, "Size mismatch for FGeometryCollectionRenderResourceSizeInfo");
static_assert(offsetof(FGeometryCollectionRenderResourceSizeInfo, MeshResourcesSize) == 0x0, "Offset mismatch for FGeometryCollectionRenderResourceSizeInfo::MeshResourcesSize");
static_assert(offsetof(FGeometryCollectionRenderResourceSizeInfo, NaniteResourcesSize) == 0x8, "Offset mismatch for FGeometryCollectionRenderResourceSizeInfo::NaniteResourcesSize");

