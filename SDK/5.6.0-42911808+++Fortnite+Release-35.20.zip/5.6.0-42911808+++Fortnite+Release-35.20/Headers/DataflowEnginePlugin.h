/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataflowEnginePlugin
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"
#include "DataflowCore.h"
#include "GeometryFramework.h"

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class ADataflowActor : public AActor
{
public:
    UDataflowComponent* DataflowComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ADataflowActor) == 0x2b0, "Size mismatch for ADataflowActor");
static_assert(offsetof(ADataflowActor, DataflowComponent) == 0x2a8, "Offset mismatch for ADataflowActor::DataflowComponent");

// Size: 0x660 (Inherited: 0x840, Single: 0xfffffe20)
class UDataflowComponent : public UPrimitiveComponent
{
public:
};

static_assert(sizeof(UDataflowComponent) == 0x660, "Size mismatch for UDataflowComponent");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCollectionAttributeKey
{
    FString Attribute; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Group; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FCollectionAttributeKey) == 0x20, "Size mismatch for FCollectionAttributeKey");
static_assert(offsetof(FCollectionAttributeKey, Attribute) == 0x0, "Offset mismatch for FCollectionAttributeKey::Attribute");
static_assert(offsetof(FCollectionAttributeKey, Group) == 0x10, "Offset mismatch for FCollectionAttributeKey::Group");

// Size: 0x10 (Inherited: 0x1, Single: 0xf)
struct FDataflowDynamicMeshArray : FDataflowAnyType
{
    TArray<UDynamicMesh*> Value; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDataflowDynamicMeshArray) == 0x10, "Size mismatch for FDataflowDynamicMeshArray");
static_assert(offsetof(FDataflowDynamicMeshArray, Value) == 0x0, "Offset mismatch for FDataflowDynamicMeshArray::Value");

