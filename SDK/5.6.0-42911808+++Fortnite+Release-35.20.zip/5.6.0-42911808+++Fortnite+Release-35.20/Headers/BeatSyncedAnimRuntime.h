/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeatSyncedAnimRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "AnimGraphRuntime.h"
#include "FortniteGame.h"
#include "MusicEventSystem.h"
#include "HarmonixMetasound.h"
#include "BeatSyncedAnimMetaData.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBeatSyncedAnimLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static UFortItemDefinition* GetLastEmoteExecuted(AController*& const Controller); // 0x103b769c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UBeatSyncedAnimLibrary) == 0x28, "Size mismatch for UBeatSyncedAnimLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFMBeatTimingUtils : public UBlueprintFunctionLibrary
{
public:

public:
    static FBeatAndTime GetCurrentBeatAndTime(UMusicClockComponent*& const MusicClock, UObject*& const WorldContext, bool& bAlwaysAllowPreviewBPM, float& PreviewBPM); // 0x103b728c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UFMBeatTimingUtils) == 0x28, "Size mismatch for UFMBeatTimingUtils");

// Size: 0x118 (Inherited: 0xe0, Single: 0x38)
class UMontageBeatSyncComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x4]; // 0xb8 (Size: 0x4, Type: PaddingProperty)
    float UsingMaxPlayRateBeforeHalf; // 0xbc (Size: 0x4, Type: FloatProperty)
    float UsingMinPlayRateBeforeDoubling; // 0xc0 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<UMusicClockComponent*> WeakMusicClockPtr; // 0xc4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMusicEventInstance*> WeakMusicEventPtr; // 0xcc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t UserEmoteBeatSyncingPermission; // 0xd4 (Size: 0x1, Type: EnumProperty)
    uint8_t UsingUserEmoteBeatSyncingPermission; // 0xd5 (Size: 0x1, Type: EnumProperty)
    bool bIsMusicPlaying; // 0xd6 (Size: 0x1, Type: BoolProperty)
    bool bHaveTimingInfo; // 0xd7 (Size: 0x1, Type: BoolProperty)
    int32_t LastKnownMontageInstanceId; // 0xd8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_dc[0x4]; // 0xdc (Size: 0x4, Type: PaddingProperty)
    AFortPlayerPawn* OwnerFortPlayerPawn; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    ASkeletalMeshActor* OwnerSkeletalMeshActor; // 0xe8 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* OwnerMeshComponent; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UPreciseBeatSyncedAnimMetaData* ActiveTimingInfo; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_100[0x18]; // 0x100 (Size: 0x18, Type: PaddingProperty)

public:
    virtual void BeganPlayingMusic(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void EndedPlayingMusic(); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    AFortPlayerPawn* GetOwnerFortPlayerPawn() const; // 0x103b77fc (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ASkeletalMeshActor* GetOwnerSkeletalMeshActor() const; // 0x103b7820 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    USkeletalMeshComponent* GetOwnerSkeletalMeshComponent(); // 0xdcaedc4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool IsMusicPlaying() const; // 0x103b7844 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void ServerRPC_SetMusicClock(UMusicClockComponent*& NewMusicClock); // 0x103b7b94 (Index: 0xc, Flags: Net|NetReliableNative|Event|Public|NetServer)
    void SetMusicClock(UMusicClockComponent*& NewMusicClock); // 0x103b7df0 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnClockPlayStateChanged(EMusicClockState& NewState); // 0x103b785c (Index: 0x6, Flags: Final|Native|Private)
    void OnMeshAnimInstanceInitalized(); // 0x103b7990 (Index: 0x7, Flags: Final|Native|Private)
    void OnMontageStarted(UAnimMontage*& NewMontage); // 0x372fb34 (Index: 0x8, Flags: Final|Native|Private)
    void OnMusicEventClockChanged(UMusicEventInstance*& MusicEvent); // 0x103b79a4 (Index: 0x9, Flags: Final|Native|Private)
    void OnMusicEventPriorityChanged(UMusicEventInstance*& MusicEvent); // 0x103b79a4 (Index: 0xa, Flags: Final|Native|Private)
    void OnRep_MusicClock(TWeakObjectPtr<UMusicClockComponent*>& OldWeakMusicClockPtr); // 0x103b7ad0 (Index: 0xb, Flags: Final|Native|Private)

protected:
    virtual void ServerRPC_SetUserEmoteBeatSyncingPermission(EUserEmoteBeatSyncingPermission& NewPermission); // 0x103b7cc0 (Index: 0xd, Flags: Net|NetReliableNative|Event|Protected|NetServer)
};

static_assert(sizeof(UMontageBeatSyncComponent) == 0x118, "Size mismatch for UMontageBeatSyncComponent");
static_assert(offsetof(UMontageBeatSyncComponent, UsingMaxPlayRateBeforeHalf) == 0xbc, "Offset mismatch for UMontageBeatSyncComponent::UsingMaxPlayRateBeforeHalf");
static_assert(offsetof(UMontageBeatSyncComponent, UsingMinPlayRateBeforeDoubling) == 0xc0, "Offset mismatch for UMontageBeatSyncComponent::UsingMinPlayRateBeforeDoubling");
static_assert(offsetof(UMontageBeatSyncComponent, WeakMusicClockPtr) == 0xc4, "Offset mismatch for UMontageBeatSyncComponent::WeakMusicClockPtr");
static_assert(offsetof(UMontageBeatSyncComponent, WeakMusicEventPtr) == 0xcc, "Offset mismatch for UMontageBeatSyncComponent::WeakMusicEventPtr");
static_assert(offsetof(UMontageBeatSyncComponent, UserEmoteBeatSyncingPermission) == 0xd4, "Offset mismatch for UMontageBeatSyncComponent::UserEmoteBeatSyncingPermission");
static_assert(offsetof(UMontageBeatSyncComponent, UsingUserEmoteBeatSyncingPermission) == 0xd5, "Offset mismatch for UMontageBeatSyncComponent::UsingUserEmoteBeatSyncingPermission");
static_assert(offsetof(UMontageBeatSyncComponent, bIsMusicPlaying) == 0xd6, "Offset mismatch for UMontageBeatSyncComponent::bIsMusicPlaying");
static_assert(offsetof(UMontageBeatSyncComponent, bHaveTimingInfo) == 0xd7, "Offset mismatch for UMontageBeatSyncComponent::bHaveTimingInfo");
static_assert(offsetof(UMontageBeatSyncComponent, LastKnownMontageInstanceId) == 0xd8, "Offset mismatch for UMontageBeatSyncComponent::LastKnownMontageInstanceId");
static_assert(offsetof(UMontageBeatSyncComponent, OwnerFortPlayerPawn) == 0xe0, "Offset mismatch for UMontageBeatSyncComponent::OwnerFortPlayerPawn");
static_assert(offsetof(UMontageBeatSyncComponent, OwnerSkeletalMeshActor) == 0xe8, "Offset mismatch for UMontageBeatSyncComponent::OwnerSkeletalMeshActor");
static_assert(offsetof(UMontageBeatSyncComponent, OwnerMeshComponent) == 0xf0, "Offset mismatch for UMontageBeatSyncComponent::OwnerMeshComponent");
static_assert(offsetof(UMontageBeatSyncComponent, ActiveTimingInfo) == 0xf8, "Offset mismatch for UMontageBeatSyncComponent::ActiveTimingInfo");

// Size: 0xd0 (Inherited: 0xe0, Single: 0xfffffff0)
class USparksAnimLoggingComponent : public UActorComponent
{
public:

public:
    FString GetCurrentFullBodyAnimName() const; // 0x103b765c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(USparksAnimLoggingComponent) == 0xd0, "Size mismatch for USparksAnimLoggingComponent");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class UAnimNotify_BeatMarker : public UAnimNotify
{
public:
};

static_assert(sizeof(UAnimNotify_BeatMarker) == 0x38, "Size mismatch for UAnimNotify_BeatMarker");

// Size: 0xb0 (Inherited: 0xd8, Single: 0xffffffd8)
struct FAnimNode_PlayBeatSyncedAnim : FAnimNode_SequenceEvaluator
{
    UAnimSequenceBase* InSequence; // 0x40 (Size: 0x8, Type: ObjectProperty)
    FBeatAndTime BeatAndTime; // 0x48 (Size: 0x10, Type: StructProperty)
    float TempoMultiplier; // 0x58 (Size: 0x4, Type: FloatProperty)
    float PreviewBPM; // 0x5c (Size: 0x4, Type: FloatProperty)
    bool bAlwaysAllowPreviewBPM; // 0x60 (Size: 0x1, Type: BoolProperty)
    uint8_t SyncAnimBeatTo; // 0x61 (Size: 0x1, Type: EnumProperty)
    uint8_t Logging; // 0x62 (Size: 0x1, Type: EnumProperty)
    bool bSideloadedLipSync; // 0x63 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_64[0x4c]; // 0x64 (Size: 0x4c, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_PlayBeatSyncedAnim) == 0xb0, "Size mismatch for FAnimNode_PlayBeatSyncedAnim");
static_assert(offsetof(FAnimNode_PlayBeatSyncedAnim, InSequence) == 0x40, "Offset mismatch for FAnimNode_PlayBeatSyncedAnim::InSequence");
static_assert(offsetof(FAnimNode_PlayBeatSyncedAnim, BeatAndTime) == 0x48, "Offset mismatch for FAnimNode_PlayBeatSyncedAnim::BeatAndTime");
static_assert(offsetof(FAnimNode_PlayBeatSyncedAnim, TempoMultiplier) == 0x58, "Offset mismatch for FAnimNode_PlayBeatSyncedAnim::TempoMultiplier");
static_assert(offsetof(FAnimNode_PlayBeatSyncedAnim, PreviewBPM) == 0x5c, "Offset mismatch for FAnimNode_PlayBeatSyncedAnim::PreviewBPM");
static_assert(offsetof(FAnimNode_PlayBeatSyncedAnim, bAlwaysAllowPreviewBPM) == 0x60, "Offset mismatch for FAnimNode_PlayBeatSyncedAnim::bAlwaysAllowPreviewBPM");
static_assert(offsetof(FAnimNode_PlayBeatSyncedAnim, SyncAnimBeatTo) == 0x61, "Offset mismatch for FAnimNode_PlayBeatSyncedAnim::SyncAnimBeatTo");
static_assert(offsetof(FAnimNode_PlayBeatSyncedAnim, Logging) == 0x62, "Offset mismatch for FAnimNode_PlayBeatSyncedAnim::Logging");
static_assert(offsetof(FAnimNode_PlayBeatSyncedAnim, bSideloadedLipSync) == 0x63, "Offset mismatch for FAnimNode_PlayBeatSyncedAnim::bSideloadedLipSync");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBeatAndTime
{
    uint8_t GotBeatTimeFrom; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float Beat; // 0x4 (Size: 0x4, Type: FloatProperty)
    float time; // 0x8 (Size: 0x4, Type: FloatProperty)
    float BeatsPerSecond; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBeatAndTime) == 0x10, "Size mismatch for FBeatAndTime");
static_assert(offsetof(FBeatAndTime, GotBeatTimeFrom) == 0x0, "Offset mismatch for FBeatAndTime::GotBeatTimeFrom");
static_assert(offsetof(FBeatAndTime, Beat) == 0x4, "Offset mismatch for FBeatAndTime::Beat");
static_assert(offsetof(FBeatAndTime, time) == 0x8, "Offset mismatch for FBeatAndTime::time");
static_assert(offsetof(FBeatAndTime, BeatsPerSecond) == 0xc, "Offset mismatch for FBeatAndTime::BeatsPerSecond");

