/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EyeTracker
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEyeTrackerFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool GetGazeData(FEyeTrackerGazeData& OutGazeData); // 0x99d4ccc (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool GetStereoGazeData(FEyeTrackerStereoGazeData& OutGazeData); // 0x99d4e10 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool IsEyeTrackerConnected(); // 0x99d4eec (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsStereoGazeDataAvailable(); // 0x99d4f38 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void SetEyeTrackedPlayer(APlayerController*& PlayerController); // 0x99d4f7c (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UEyeTrackerFunctionLibrary) == 0x28, "Size mismatch for UEyeTrackerFunctionLibrary");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FEyeTrackerGazeData
{
    FVector GazeOrigin; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector GazeDirection; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector FixationPoint; // 0x30 (Size: 0x18, Type: StructProperty)
    float ConfidenceValue; // 0x48 (Size: 0x4, Type: FloatProperty)
    bool bIsLeftEyeBlink; // 0x4c (Size: 0x1, Type: BoolProperty)
    bool bIsRightEyeBlink; // 0x4d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4e[0x2]; // 0x4e (Size: 0x2, Type: PaddingProperty)
    float LeftPupilDiameter; // 0x50 (Size: 0x4, Type: FloatProperty)
    float RightPupilDiameter; // 0x54 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FEyeTrackerGazeData) == 0x58, "Size mismatch for FEyeTrackerGazeData");
static_assert(offsetof(FEyeTrackerGazeData, GazeOrigin) == 0x0, "Offset mismatch for FEyeTrackerGazeData::GazeOrigin");
static_assert(offsetof(FEyeTrackerGazeData, GazeDirection) == 0x18, "Offset mismatch for FEyeTrackerGazeData::GazeDirection");
static_assert(offsetof(FEyeTrackerGazeData, FixationPoint) == 0x30, "Offset mismatch for FEyeTrackerGazeData::FixationPoint");
static_assert(offsetof(FEyeTrackerGazeData, ConfidenceValue) == 0x48, "Offset mismatch for FEyeTrackerGazeData::ConfidenceValue");
static_assert(offsetof(FEyeTrackerGazeData, bIsLeftEyeBlink) == 0x4c, "Offset mismatch for FEyeTrackerGazeData::bIsLeftEyeBlink");
static_assert(offsetof(FEyeTrackerGazeData, bIsRightEyeBlink) == 0x4d, "Offset mismatch for FEyeTrackerGazeData::bIsRightEyeBlink");
static_assert(offsetof(FEyeTrackerGazeData, LeftPupilDiameter) == 0x50, "Offset mismatch for FEyeTrackerGazeData::LeftPupilDiameter");
static_assert(offsetof(FEyeTrackerGazeData, RightPupilDiameter) == 0x54, "Offset mismatch for FEyeTrackerGazeData::RightPupilDiameter");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FEyeTrackerStereoGazeData
{
    FVector LeftEyeOrigin; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector LeftEyeDirection; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector RightEyeOrigin; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector RightEyeDirection; // 0x48 (Size: 0x18, Type: StructProperty)
    FVector FixationPoint; // 0x60 (Size: 0x18, Type: StructProperty)
    float ConfidenceValue; // 0x78 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FEyeTrackerStereoGazeData) == 0x80, "Size mismatch for FEyeTrackerStereoGazeData");
static_assert(offsetof(FEyeTrackerStereoGazeData, LeftEyeOrigin) == 0x0, "Offset mismatch for FEyeTrackerStereoGazeData::LeftEyeOrigin");
static_assert(offsetof(FEyeTrackerStereoGazeData, LeftEyeDirection) == 0x18, "Offset mismatch for FEyeTrackerStereoGazeData::LeftEyeDirection");
static_assert(offsetof(FEyeTrackerStereoGazeData, RightEyeOrigin) == 0x30, "Offset mismatch for FEyeTrackerStereoGazeData::RightEyeOrigin");
static_assert(offsetof(FEyeTrackerStereoGazeData, RightEyeDirection) == 0x48, "Offset mismatch for FEyeTrackerStereoGazeData::RightEyeDirection");
static_assert(offsetof(FEyeTrackerStereoGazeData, FixationPoint) == 0x60, "Offset mismatch for FEyeTrackerStereoGazeData::FixationPoint");
static_assert(offsetof(FEyeTrackerStereoGazeData, ConfidenceValue) == 0x78, "Offset mismatch for FEyeTrackerStereoGazeData::ConfidenceValue");

