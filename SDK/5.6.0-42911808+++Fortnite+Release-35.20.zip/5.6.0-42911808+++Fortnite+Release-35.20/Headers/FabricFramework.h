/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricFramework
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "PlayspaceSystem.h"
#include "ModularGameplay.h"
#include "GameplayTags.h"

// Size: 0xf8 (Inherited: 0xe0, Single: 0x18)
class UFabricDeviceComponentBase : public UActorComponent
{
public:
    uint8_t OnFabricGlobalSystemChanged[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFabricZoneSystemChanged[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    AFabricGlobalSystem* ServerFabricGlobalSystem; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AFabricGlobalSystem*> LocalFabricGlobalSystem; // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    AFabricZoneSystem* ServerFabricZoneSystem; // 0xe8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AFabricZoneSystem*> LocalFabricZoneSystem; // 0xf0 (Size: 0x8, Type: WeakObjectProperty)

public:
    AFabricGlobalSystem* GetFabricGlobalSystem() const; // 0x11192b20 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AFabricZoneSystem* GetFabricZoneSystem() const; // 0x11192b44 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    void OnRep_FabricGlobalSystem(); // 0x11192b88 (Index: 0x2, Flags: Final|Native|Private)
    void OnRep_FabricZoneSystem(); // 0x11192b9c (Index: 0x3, Flags: Final|Native|Private)
};

static_assert(sizeof(UFabricDeviceComponentBase) == 0xf8, "Size mismatch for UFabricDeviceComponentBase");
static_assert(offsetof(UFabricDeviceComponentBase, OnFabricGlobalSystemChanged) == 0xb8, "Offset mismatch for UFabricDeviceComponentBase::OnFabricGlobalSystemChanged");
static_assert(offsetof(UFabricDeviceComponentBase, OnFabricZoneSystemChanged) == 0xc8, "Offset mismatch for UFabricDeviceComponentBase::OnFabricZoneSystemChanged");
static_assert(offsetof(UFabricDeviceComponentBase, ServerFabricGlobalSystem) == 0xd8, "Offset mismatch for UFabricDeviceComponentBase::ServerFabricGlobalSystem");
static_assert(offsetof(UFabricDeviceComponentBase, LocalFabricGlobalSystem) == 0xe0, "Offset mismatch for UFabricDeviceComponentBase::LocalFabricGlobalSystem");
static_assert(offsetof(UFabricDeviceComponentBase, ServerFabricZoneSystem) == 0xe8, "Offset mismatch for UFabricDeviceComponentBase::ServerFabricZoneSystem");
static_assert(offsetof(UFabricDeviceComponentBase, LocalFabricZoneSystem) == 0xf0, "Offset mismatch for UFabricDeviceComponentBase::LocalFabricZoneSystem");

// Size: 0x2a8 (Inherited: 0x2d0, Single: 0xffffffd8)
class AFabricGlobalSystem : public AActor
{
public:
};

static_assert(sizeof(AFabricGlobalSystem) == 0x2a8, "Size mismatch for AFabricGlobalSystem");

// Size: 0x758 (Inherited: 0xa18, Single: 0xfffffd40)
class AFabricMusicRandomizer : public ABuildingActor
{
public:
    int32_t RandomSeed; // 0x748 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_74c[0x4]; // 0x74c (Size: 0x4, Type: PaddingProperty)
    AFabricZoneSystem* OwnerZoneSystem; // 0x750 (Size: 0x8, Type: ObjectProperty)

protected:
    AFabricZoneSystem* GetOwnerZoneSystem(); // 0x11192b70 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(AFabricMusicRandomizer) == 0x758, "Size mismatch for AFabricMusicRandomizer");
static_assert(offsetof(AFabricMusicRandomizer, RandomSeed) == 0x748, "Offset mismatch for AFabricMusicRandomizer::RandomSeed");
static_assert(offsetof(AFabricMusicRandomizer, OwnerZoneSystem) == 0x750, "Offset mismatch for AFabricMusicRandomizer::OwnerZoneSystem");

// Size: 0xe0 (Inherited: 0x250, Single: 0xfffffe90)
class UFabricZoneComponent : public UPlayspaceComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    TWeakObjectPtr<AFabricZoneSystem*> ZoneSystem; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UPlayspaceComponent_Fabric*> FabricPlayspaceComponent; // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>> DevicesInZone; // 0xd0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFabricZoneComponent) == 0xe0, "Size mismatch for UFabricZoneComponent");
static_assert(offsetof(UFabricZoneComponent, ZoneSystem) == 0xc0, "Offset mismatch for UFabricZoneComponent::ZoneSystem");
static_assert(offsetof(UFabricZoneComponent, FabricPlayspaceComponent) == 0xc8, "Offset mismatch for UFabricZoneComponent::FabricPlayspaceComponent");
static_assert(offsetof(UFabricZoneComponent, DevicesInZone) == 0xd0, "Offset mismatch for UFabricZoneComponent::DevicesInZone");

// Size: 0x2c0 (Inherited: 0x2d0, Single: 0xfffffff0)
class AFabricZoneSystem : public AActor
{
public:
    bool bAllowRandomization; // 0x2a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a9[0x7]; // 0x2a9 (Size: 0x7, Type: PaddingProperty)
    UFabricZoneComponent* OwnerZoneComponent; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    AFabricMusicRandomizer* MusicRandomizer; // 0x2b8 (Size: 0x8, Type: ObjectProperty)

public:
    bool GetAllowRandomization() const; // 0xd8c9068 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AFabricMusicRandomizer* GetMusicRandomizer() const; // 0xa164804 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetAllowRandomization(bool& bInAllowRandomization); // 0xf7f4218 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(AFabricZoneSystem) == 0x2c0, "Size mismatch for AFabricZoneSystem");
static_assert(offsetof(AFabricZoneSystem, bAllowRandomization) == 0x2a8, "Offset mismatch for AFabricZoneSystem::bAllowRandomization");
static_assert(offsetof(AFabricZoneSystem, OwnerZoneComponent) == 0x2b0, "Offset mismatch for AFabricZoneSystem::OwnerZoneComponent");
static_assert(offsetof(AFabricZoneSystem, MusicRandomizer) == 0x2b8, "Offset mismatch for AFabricZoneSystem::MusicRandomizer");

// Size: 0x58 (Inherited: 0x88, Single: 0xffffffd0)
class UFabricGlobalVariablesSubsystem : public UWorldSubsystem
{
public:
    FGameplayTag FabricPlayspaceGameplayTag; // 0x30 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    UClass* FabricPlayspaceComponentClass; // 0x38 (Size: 0x8, Type: ClassProperty)
    UClass* FabricGlobalSystemClass; // 0x40 (Size: 0x8, Type: ClassProperty)
    UClass* FabricZoneSystemClass; // 0x48 (Size: 0x8, Type: ClassProperty)
    UClass* FabricMusicRandomizerClass; // 0x50 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFabricGlobalVariablesSubsystem) == 0x58, "Size mismatch for UFabricGlobalVariablesSubsystem");
static_assert(offsetof(UFabricGlobalVariablesSubsystem, FabricPlayspaceGameplayTag) == 0x30, "Offset mismatch for UFabricGlobalVariablesSubsystem::FabricPlayspaceGameplayTag");
static_assert(offsetof(UFabricGlobalVariablesSubsystem, FabricPlayspaceComponentClass) == 0x38, "Offset mismatch for UFabricGlobalVariablesSubsystem::FabricPlayspaceComponentClass");
static_assert(offsetof(UFabricGlobalVariablesSubsystem, FabricGlobalSystemClass) == 0x40, "Offset mismatch for UFabricGlobalVariablesSubsystem::FabricGlobalSystemClass");
static_assert(offsetof(UFabricGlobalVariablesSubsystem, FabricZoneSystemClass) == 0x48, "Offset mismatch for UFabricGlobalVariablesSubsystem::FabricZoneSystemClass");
static_assert(offsetof(UFabricGlobalVariablesSubsystem, FabricMusicRandomizerClass) == 0x50, "Offset mismatch for UFabricGlobalVariablesSubsystem::FabricMusicRandomizerClass");

// Size: 0xf8 (Inherited: 0x250, Single: 0xfffffea8)
class UPlayspaceComponent_Fabric : public UPlayspaceComponent
{
public:
    TWeakObjectPtr<AFabricGlobalSystem*> GlobalSystem; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFabricZoneSystem*> GlobalZoneSystem; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>> RegisteredDevices; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<UFabricDeviceComponentBase*>> GlobalDevices; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<UFabricZoneComponent*>> RegisteredZoneSystems; // 0xe8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UPlayspaceComponent_Fabric) == 0xf8, "Size mismatch for UPlayspaceComponent_Fabric");
static_assert(offsetof(UPlayspaceComponent_Fabric, GlobalSystem) == 0xb8, "Offset mismatch for UPlayspaceComponent_Fabric::GlobalSystem");
static_assert(offsetof(UPlayspaceComponent_Fabric, GlobalZoneSystem) == 0xc0, "Offset mismatch for UPlayspaceComponent_Fabric::GlobalZoneSystem");
static_assert(offsetof(UPlayspaceComponent_Fabric, RegisteredDevices) == 0xc8, "Offset mismatch for UPlayspaceComponent_Fabric::RegisteredDevices");
static_assert(offsetof(UPlayspaceComponent_Fabric, GlobalDevices) == 0xd8, "Offset mismatch for UPlayspaceComponent_Fabric::GlobalDevices");
static_assert(offsetof(UPlayspaceComponent_Fabric, RegisteredZoneSystems) == 0xe8, "Offset mismatch for UPlayspaceComponent_Fabric::RegisteredZoneSystems");

