/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_AudioMixerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "AudioModulation.h"

// Size: 0xca0 (Inherited: 0x45b0, Single: 0xffffc6f0)
class ACreativeAudioMixerDevice : public AFortCreativeDeviceProp
{
public:
    uint8_t Pad_c10[0x8]; // 0xc10 (Size: 0x8, Type: PaddingProperty)
    USoundControlBusMix* Mix; // 0xc18 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* Bus; // 0xc20 (Size: 0x8, Type: ObjectProperty)
    float FaderValue; // 0xc28 (Size: 0x4, Type: FloatProperty)
    uint8_t CanBeHeardBy; // 0xc2c (Size: 0x1, Type: EnumProperty)
    bool bActivateInEditMode; // 0xc2d (Size: 0x1, Type: BoolProperty)
    bool bActivateOnGameStart; // 0xc2e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c2f[0x1]; // 0xc2f (Size: 0x1, Type: PaddingProperty)
    UCreativeProxyManagerComponent* CreativeProxyManagerComponent; // 0xc30 (Size: 0x8, Type: ObjectProperty)
    UFortMinigameProgressComponent* FortMinigameProgressComponent; // 0xc38 (Size: 0x8, Type: ObjectProperty)
    UCreativeRegisteredPlayersManagerComponent* CreativeRegisteredPlayersManagerComponent; // 0xc40 (Size: 0x8, Type: ObjectProperty)
    UFortActorOptionsComponent* FortActorOptionsComponent; // 0xc48 (Size: 0x8, Type: ObjectProperty)
    bool bCachedIsActive; // 0xc50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c51[0x7]; // 0xc51 (Size: 0x7, Type: PaddingProperty)
    AController* CachedInstigator; // 0xc58 (Size: 0x8, Type: ObjectProperty)
    ACreativeAudioMixerReplicationProxy* ClientCachedProxy; // 0xc60 (Size: 0x8, Type: ObjectProperty)
    USoundControlBusMix* CachedBusMix; // 0xc68 (Size: 0x8, Type: ObjectProperty)
    FName CachedBusMixName; // 0xc70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c74[0x4]; // 0xc74 (Size: 0x4, Type: PaddingProperty)
    TArray<FUniqueNetIdRepl> RegisteredPlayerIds; // 0xc78 (Size: 0x10, Type: ArrayProperty)
    TArray<FUniqueNetIdRepl> NonRegisteredPlayerIds; // 0xc88 (Size: 0x10, Type: ArrayProperty)
    bool bHasUpdatedStateInEditMode; // 0xc98 (Size: 0x1, Type: BoolProperty)
    bool bHasUpdatedStateInGameplay; // 0xc99 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c9a[0x6]; // 0xc9a (Size: 0x6, Type: PaddingProperty)

public:
    void ActivateMix(); // 0x554e3c4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void DeactivateMix(); // 0x554e3c4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnAllPlayersUnregistered(); // 0x11a7e45c (Index: 0x2, Flags: Final|Native|Private)
    void OnMinigameEnded(); // 0x11a7e478 (Index: 0x3, Flags: Final|Native|Private)
    void OnMinigameStarted(); // 0x11a7e494 (Index: 0x4, Flags: Final|Native|Private)
    void OnPlayerAdded(FUniqueNetIdRepl& NetId, bool& bIsLocalPlayer); // 0x11a7e4b0 (Index: 0x5, Flags: Final|Native|Private)
    void OnPlayerRegistered(AFortPlayerState*& const PlayerState); // 0x11a7e654 (Index: 0x6, Flags: Final|Native|Private)
    void OnPlayerUnregistered(AFortPlayerState*& const PlayerState); // 0x11a7e784 (Index: 0x7, Flags: Final|Native|Private)
    void OnPreAnyPropertyChanged(); // 0x11a7e8b4 (Index: 0x8, Flags: Final|Native|Private)
    void OnProxyDataChanged(ACreativePlayerReplicationProxy*& ProxyData); // 0x11a7e8c8 (Index: 0x9, Flags: Final|Native|Private)
};

static_assert(sizeof(ACreativeAudioMixerDevice) == 0xca0, "Size mismatch for ACreativeAudioMixerDevice");
static_assert(offsetof(ACreativeAudioMixerDevice, Mix) == 0xc18, "Offset mismatch for ACreativeAudioMixerDevice::Mix");
static_assert(offsetof(ACreativeAudioMixerDevice, Bus) == 0xc20, "Offset mismatch for ACreativeAudioMixerDevice::Bus");
static_assert(offsetof(ACreativeAudioMixerDevice, FaderValue) == 0xc28, "Offset mismatch for ACreativeAudioMixerDevice::FaderValue");
static_assert(offsetof(ACreativeAudioMixerDevice, CanBeHeardBy) == 0xc2c, "Offset mismatch for ACreativeAudioMixerDevice::CanBeHeardBy");
static_assert(offsetof(ACreativeAudioMixerDevice, bActivateInEditMode) == 0xc2d, "Offset mismatch for ACreativeAudioMixerDevice::bActivateInEditMode");
static_assert(offsetof(ACreativeAudioMixerDevice, bActivateOnGameStart) == 0xc2e, "Offset mismatch for ACreativeAudioMixerDevice::bActivateOnGameStart");
static_assert(offsetof(ACreativeAudioMixerDevice, CreativeProxyManagerComponent) == 0xc30, "Offset mismatch for ACreativeAudioMixerDevice::CreativeProxyManagerComponent");
static_assert(offsetof(ACreativeAudioMixerDevice, FortMinigameProgressComponent) == 0xc38, "Offset mismatch for ACreativeAudioMixerDevice::FortMinigameProgressComponent");
static_assert(offsetof(ACreativeAudioMixerDevice, CreativeRegisteredPlayersManagerComponent) == 0xc40, "Offset mismatch for ACreativeAudioMixerDevice::CreativeRegisteredPlayersManagerComponent");
static_assert(offsetof(ACreativeAudioMixerDevice, FortActorOptionsComponent) == 0xc48, "Offset mismatch for ACreativeAudioMixerDevice::FortActorOptionsComponent");
static_assert(offsetof(ACreativeAudioMixerDevice, bCachedIsActive) == 0xc50, "Offset mismatch for ACreativeAudioMixerDevice::bCachedIsActive");
static_assert(offsetof(ACreativeAudioMixerDevice, CachedInstigator) == 0xc58, "Offset mismatch for ACreativeAudioMixerDevice::CachedInstigator");
static_assert(offsetof(ACreativeAudioMixerDevice, ClientCachedProxy) == 0xc60, "Offset mismatch for ACreativeAudioMixerDevice::ClientCachedProxy");
static_assert(offsetof(ACreativeAudioMixerDevice, CachedBusMix) == 0xc68, "Offset mismatch for ACreativeAudioMixerDevice::CachedBusMix");
static_assert(offsetof(ACreativeAudioMixerDevice, CachedBusMixName) == 0xc70, "Offset mismatch for ACreativeAudioMixerDevice::CachedBusMixName");
static_assert(offsetof(ACreativeAudioMixerDevice, RegisteredPlayerIds) == 0xc78, "Offset mismatch for ACreativeAudioMixerDevice::RegisteredPlayerIds");
static_assert(offsetof(ACreativeAudioMixerDevice, NonRegisteredPlayerIds) == 0xc88, "Offset mismatch for ACreativeAudioMixerDevice::NonRegisteredPlayerIds");
static_assert(offsetof(ACreativeAudioMixerDevice, bHasUpdatedStateInEditMode) == 0xc98, "Offset mismatch for ACreativeAudioMixerDevice::bHasUpdatedStateInEditMode");
static_assert(offsetof(ACreativeAudioMixerDevice, bHasUpdatedStateInGameplay) == 0xc99, "Offset mismatch for ACreativeAudioMixerDevice::bHasUpdatedStateInGameplay");

// Size: 0x2c0 (Inherited: 0x830, Single: 0xfffffa90)
class ACreativeAudioMixerReplicationProxy : public ACreativePlayerReplicationProxy
{
public:
    bool bIsActive; // 0x2b8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b9[0x7]; // 0x2b9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(ACreativeAudioMixerReplicationProxy) == 0x2c0, "Size mismatch for ACreativeAudioMixerReplicationProxy");
static_assert(offsetof(ACreativeAudioMixerReplicationProxy, bIsActive) == 0x2b8, "Offset mismatch for ACreativeAudioMixerReplicationProxy::bIsActive");

