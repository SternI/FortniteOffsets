/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Foundation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Styles.h"
#include "FortniteUI.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "CommonUILegacy.h"
#include "UMG.h"
#include "Engine.h"
#include "Input.h"
#include "UI.h"
#include "SlateCore.h"
#include "InputCore.h"

// Size: 0x190 (Inherited: 0x4d8, Single: 0xfffffcb8)
class UTextStyle_BurbSmBk_15_White_C : public UTextStyle_BaseParent_C
{
public:
};

static_assert(sizeof(UTextStyle_BurbSmBk_15_White_C) == 0x190, "Size mismatch for UTextStyle_BurbSmBk_15_White_C");

// Size: 0x510 (Inherited: 0x1080, Single: 0xfffff490)
class URootLayout_Athena_C : public UFortRootViewportLayout_Athena
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x4c8 (Size: 0x8, Type: StructProperty)
    UConfirmationWindow_C* ConfirmationWindow; // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    UProgressModalWidget_C* ControllerDisconnectedModal; // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    bool bClosingErrorDialog; // 0x4e0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4e1[0x7]; // 0x4e1 (Size: 0x7, Type: PaddingProperty)
    FText QuitTitle; // 0x4e8 (Size: 0x10, Type: TextProperty)
    FText QuitMessage; // 0x4f8 (Size: 0x10, Type: TextProperty)
    USoundBase* TakeControlAudio; // 0x508 (Size: 0x8, Type: ObjectProperty)

public:
    bool IsConsole(); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual void Construct(); // 0x288a61c (Index: 0x4, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(URootLayout_Athena_C) == 0x510, "Size mismatch for URootLayout_Athena_C");
static_assert(offsetof(URootLayout_Athena_C, UberGraphFrame) == 0x4c8, "Offset mismatch for URootLayout_Athena_C::UberGraphFrame");
static_assert(offsetof(URootLayout_Athena_C, ConfirmationWindow) == 0x4d0, "Offset mismatch for URootLayout_Athena_C::ConfirmationWindow");
static_assert(offsetof(URootLayout_Athena_C, ControllerDisconnectedModal) == 0x4d8, "Offset mismatch for URootLayout_Athena_C::ControllerDisconnectedModal");
static_assert(offsetof(URootLayout_Athena_C, bClosingErrorDialog) == 0x4e0, "Offset mismatch for URootLayout_Athena_C::bClosingErrorDialog");
static_assert(offsetof(URootLayout_Athena_C, QuitTitle) == 0x4e8, "Offset mismatch for URootLayout_Athena_C::QuitTitle");
static_assert(offsetof(URootLayout_Athena_C, QuitMessage) == 0x4f8, "Offset mismatch for URootLayout_Athena_C::QuitMessage");
static_assert(offsetof(URootLayout_Athena_C, TakeControlAudio) == 0x508, "Offset mismatch for URootLayout_Athena_C::TakeControlAudio");

// Size: 0x190 (Inherited: 0x4d8, Single: 0xfffffcb8)
class UTextStyle_BurbSmBk_15_White50pc_C : public UTextStyle_BaseParent_C
{
public:
};

static_assert(sizeof(UTextStyle_BurbSmBk_15_White50pc_C) == 0x190, "Size mismatch for UTextStyle_BurbSmBk_15_White50pc_C");

// Size: 0x190 (Inherited: 0x4d8, Single: 0xfffffcb8)
class UTextStyle_BurbSmBk_15_Red_C : public UTextStyle_BaseParent_C
{
public:
};

static_assert(sizeof(UTextStyle_BurbSmBk_15_Red_C) == 0x190, "Size mismatch for UTextStyle_BurbSmBk_15_Red_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_BottomBar_S_Selected_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_BottomBar_S_Selected_C) == 0x190, "Size mismatch for UTextStyle_Button_BottomBar_S_Selected_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UAthena_ButtonStyle_AngledBlackMenuButton_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UAthena_ButtonStyle_AngledBlackMenuButton_C) == 0x710, "Size mismatch for UAthena_ButtonStyle_AngledBlackMenuButton_C");

// Size: 0x190 (Inherited: 0x4d8, Single: 0xfffffcb8)
class UTextStyle_BurbSmBk_15_Green_C : public UTextStyle_BaseParent_C
{
public:
};

static_assert(sizeof(UTextStyle_BurbSmBk_15_Green_C) == 0x190, "Size mismatch for UTextStyle_BurbSmBk_15_Green_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Feature_L_Yellow_s11_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Feature_L_Yellow_s11_C) == 0x710, "Size mismatch for UButtonStyle_Feature_L_Yellow_s11_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Feature_M_Disabled_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Feature_M_Disabled_C) == 0x190, "Size mismatch for UTextStyle_Button_Feature_M_Disabled_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_NewFeature_M_Yellow_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_NewFeature_M_Yellow_C) == 0x710, "Size mismatch for UButtonStyle_NewFeature_M_Yellow_C");

// Size: 0x710 (Inherited: 0x1558, Single: 0xfffff1b8)
class UButtonStyle_BottomBar_Console_C : public UButtonStyle_MediumBase_C
{
public:
};

static_assert(sizeof(UButtonStyle_BottomBar_Console_C) == 0x710, "Size mismatch for UButtonStyle_BottomBar_Console_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_SoloButton_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_SoloButton_C) == 0x710, "Size mismatch for UButtonStyle_SoloButton_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Skew_LBlue_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Skew_LBlue_C) == 0x710, "Size mismatch for UButtonStyle_Skew_LBlue_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Feature_L_Disabled_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Feature_L_Disabled_C) == 0x190, "Size mismatch for UTextStyle_Button_Feature_L_Disabled_C");

// Size: 0x710 (Inherited: 0xe48, Single: 0xfffff8c8)
class UButtonStyle_TextOnlyBase_EmptyFocus_C : public UButtonStyle_Base_C
{
public:
};

static_assert(sizeof(UButtonStyle_TextOnlyBase_EmptyFocus_C) == 0x710, "Size mismatch for UButtonStyle_TextOnlyBase_EmptyFocus_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Skew_LessTransparent_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Skew_LessTransparent_C) == 0x710, "Size mismatch for UButtonStyle_Skew_LessTransparent_C");

// Size: 0x1539 (Inherited: 0x30c0, Single: 0xffffe479)
class UCloseButton_C : public UCommonButtonLegacy
{
public:
    UCommonTextBlock* Text_ButtonAction; // 0x14f0 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_Control; // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    UImage* CloseIcon; // 0x1500 (Size: 0x8, Type: ObjectProperty)
    UBorder* Border_Container; // 0x1508 (Size: 0x8, Type: ObjectProperty)
    FText Button_Description; // 0x1510 (Size: 0x10, Type: TextProperty)
    bool FontSizeOveride; // 0x1520 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1521[0x3]; // 0x1521 (Size: 0x3, Type: PaddingProperty)
    int32_t FontSize; // 0x1524 (Size: 0x4, Type: IntProperty)
    FMargin Padding_Overide; // 0x1528 (Size: 0x10, Type: StructProperty)
    bool PaddingOveride; // 0x1538 (Size: 0x1, Type: BoolProperty)

public:
    void SetText(FText& Text); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleSize(); // 0x288a61c (Index: 0x1, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UCloseButton_C) == 0x1539, "Size mismatch for UCloseButton_C");
static_assert(offsetof(UCloseButton_C, Text_ButtonAction) == 0x14f0, "Offset mismatch for UCloseButton_C::Text_ButtonAction");
static_assert(offsetof(UCloseButton_C, SizeBox_Control) == 0x14f8, "Offset mismatch for UCloseButton_C::SizeBox_Control");
static_assert(offsetof(UCloseButton_C, CloseIcon) == 0x1500, "Offset mismatch for UCloseButton_C::CloseIcon");
static_assert(offsetof(UCloseButton_C, Border_Container) == 0x1508, "Offset mismatch for UCloseButton_C::Border_Container");
static_assert(offsetof(UCloseButton_C, Button_Description) == 0x1510, "Offset mismatch for UCloseButton_C::Button_Description");
static_assert(offsetof(UCloseButton_C, FontSizeOveride) == 0x1520, "Offset mismatch for UCloseButton_C::FontSizeOveride");
static_assert(offsetof(UCloseButton_C, FontSize) == 0x1524, "Offset mismatch for UCloseButton_C::FontSize");
static_assert(offsetof(UCloseButton_C, Padding_Overide) == 0x1528, "Offset mismatch for UCloseButton_C::Padding_Overide");
static_assert(offsetof(UCloseButton_C, PaddingOveride) == 0x1538, "Offset mismatch for UCloseButton_C::PaddingOveride");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Feature_M_Feature_s11_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Feature_M_Feature_s11_C) == 0x190, "Size mismatch for UTextStyle_Button_Feature_M_Feature_s11_C");

// Size: 0x1520 (Inherited: 0x30e0, Single: 0xffffe440)
class UTextRotatorWhite_C : public UCommonRotator
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x1510 (Size: 0x8, Type: StructProperty)
    UCommonBorder* MainBorder; // 0x1518 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void Construct(); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UTextRotatorWhite_C) == 0x1520, "Size mismatch for UTextRotatorWhite_C");
static_assert(offsetof(UTextRotatorWhite_C, UberGraphFrame) == 0x1510, "Offset mismatch for UTextRotatorWhite_C::UberGraphFrame");
static_assert(offsetof(UTextRotatorWhite_C, MainBorder) == 0x1518, "Offset mismatch for UTextRotatorWhite_C::MainBorder");

// Size: 0x1640 (Inherited: 0x30c0, Single: 0xffffe580)
class UIconTabButton_Legacy_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x14f0 (Size: 0x8, Type: StructProperty)
    USizeBox* SizeBoxShell; // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    UImage* LeftSideImage; // 0x1500 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* ContentHB; // 0x1508 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* CenterButtonTextWidget; // 0x1510 (Size: 0x8, Type: ObjectProperty)
    UNormalBangWrapper_C* BangWrapper; // 0x1518 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText; // 0x1520 (Size: 0x10, Type: TextProperty)
    FSlateBrush IconBrush; // 0x1530 (Size: 0xb0, Type: StructProperty)
    bool UseText; // 0x15e0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15e1[0x3]; // 0x15e1 (Size: 0x3, Type: PaddingProperty)
    FLinearColor SelectedIconTint; // 0x15e4 (Size: 0x10, Type: StructProperty)
    FLinearColor DeselectedIconTint; // 0x15f4 (Size: 0x10, Type: StructProperty)
    FLinearColor HoveredIconTint; // 0x1604 (Size: 0x10, Type: StructProperty)
    bool bBangEnabled; // 0x1614 (Size: 0x1, Type: BoolProperty)
    bool ChangeIconColorWhenSelected; // 0x1615 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1616[0x2]; // 0x1616 (Size: 0x2, Type: PaddingProperty)
    FSlateColor SelectedIconColor; // 0x1618 (Size: 0x14, Type: StructProperty)
    FSlateColor UnSelectedIconColor; // 0x162c (Size: 0x14, Type: StructProperty)

public:
    void Update_Bang_State(bool& bBangEnabled, int32_t& Count); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ShowText(); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetTutorialBorderStyle(UClass*& BorderStyle); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void SetTabLabelInfo(const FFortTabButtonLabelInfo TabLabelInfo); // 0x288a61c (Index: 0x3, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetChangeIconColorWhenSelected(bool& ChangeColorWhenSelected, FSlateColor& SelectedColor, FSlateColor& UnselectedColor); // 0x288a61c (Index: 0x4, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Set_Text(FText& ButtonText); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Icon(FSlateBrush& IconBrush); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x7, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void Play_Hover_Sound(); // 0x288a61c (Index: 0x8, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0xb, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void OnCurrentTextStyleChanged(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnUnhovered(); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnSelected(); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnHovered(); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnEnabled(); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDisabled(); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDeselected(); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UIconTabButton_Legacy_C) == 0x1640, "Size mismatch for UIconTabButton_Legacy_C");
static_assert(offsetof(UIconTabButton_Legacy_C, UberGraphFrame) == 0x14f0, "Offset mismatch for UIconTabButton_Legacy_C::UberGraphFrame");
static_assert(offsetof(UIconTabButton_Legacy_C, SizeBoxShell) == 0x14f8, "Offset mismatch for UIconTabButton_Legacy_C::SizeBoxShell");
static_assert(offsetof(UIconTabButton_Legacy_C, LeftSideImage) == 0x1500, "Offset mismatch for UIconTabButton_Legacy_C::LeftSideImage");
static_assert(offsetof(UIconTabButton_Legacy_C, ContentHB) == 0x1508, "Offset mismatch for UIconTabButton_Legacy_C::ContentHB");
static_assert(offsetof(UIconTabButton_Legacy_C, CenterButtonTextWidget) == 0x1510, "Offset mismatch for UIconTabButton_Legacy_C::CenterButtonTextWidget");
static_assert(offsetof(UIconTabButton_Legacy_C, BangWrapper) == 0x1518, "Offset mismatch for UIconTabButton_Legacy_C::BangWrapper");
static_assert(offsetof(UIconTabButton_Legacy_C, ButtonText) == 0x1520, "Offset mismatch for UIconTabButton_Legacy_C::ButtonText");
static_assert(offsetof(UIconTabButton_Legacy_C, IconBrush) == 0x1530, "Offset mismatch for UIconTabButton_Legacy_C::IconBrush");
static_assert(offsetof(UIconTabButton_Legacy_C, UseText) == 0x15e0, "Offset mismatch for UIconTabButton_Legacy_C::UseText");
static_assert(offsetof(UIconTabButton_Legacy_C, SelectedIconTint) == 0x15e4, "Offset mismatch for UIconTabButton_Legacy_C::SelectedIconTint");
static_assert(offsetof(UIconTabButton_Legacy_C, DeselectedIconTint) == 0x15f4, "Offset mismatch for UIconTabButton_Legacy_C::DeselectedIconTint");
static_assert(offsetof(UIconTabButton_Legacy_C, HoveredIconTint) == 0x1604, "Offset mismatch for UIconTabButton_Legacy_C::HoveredIconTint");
static_assert(offsetof(UIconTabButton_Legacy_C, bBangEnabled) == 0x1614, "Offset mismatch for UIconTabButton_Legacy_C::bBangEnabled");
static_assert(offsetof(UIconTabButton_Legacy_C, ChangeIconColorWhenSelected) == 0x1615, "Offset mismatch for UIconTabButton_Legacy_C::ChangeIconColorWhenSelected");
static_assert(offsetof(UIconTabButton_Legacy_C, SelectedIconColor) == 0x1618, "Offset mismatch for UIconTabButton_Legacy_C::SelectedIconColor");
static_assert(offsetof(UIconTabButton_Legacy_C, UnSelectedIconColor) == 0x162c, "Offset mismatch for UIconTabButton_Legacy_C::UnSelectedIconColor");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Outline_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Outline_C) == 0x710, "Size mismatch for UButtonStyle_Outline_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Outline_XS_Disabled_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Outline_XS_Disabled_C) == 0x190, "Size mismatch for UTextStyle_Button_Outline_XS_Disabled_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Clear_NoSound_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Clear_NoSound_C) == 0x710, "Size mismatch for UButtonStyle_Clear_NoSound_C");

// Size: 0x1658 (Inherited: 0x30c0, Single: 0xffffe598)
class UIconTextButtonHold_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x14f0 (Size: 0x8, Type: StructProperty)
    UNamedSlot* RightExtraContentSlot; // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    UImage* LeftSideImage; // 0x1500 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_ButtonContent; // 0x1508 (Size: 0x8, Type: ObjectProperty)
    UBorder* ContentBorder; // 0x1510 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* CenterButtonTextWidget; // 0x1518 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText; // 0x1520 (Size: 0x10, Type: TextProperty)
    FSlateBrush IconBrush; // 0x1530 (Size: 0xb0, Type: StructProperty)
    UClass* ControllerInputStyle; // 0x15e0 (Size: 0x8, Type: ClassProperty)
    UClass* MouseKeyboardStyle; // 0x15e8 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EHorizontalAlignment> ContentAlignment; // 0x15f0 (Size: 0x1, Type: ByteProperty)
    bool bMouseKeyboardStyleSet; // 0x15f1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15f2[0x6]; // 0x15f2 (Size: 0x6, Type: PaddingProperty)
    FText OverrideButtonText; // 0x15f8 (Size: 0x10, Type: TextProperty)
    TEnumAsByte<ETextJustify> ButtonTextJustification; // 0x1608 (Size: 0x1, Type: ByteProperty)
    bool bDisplayAllCaps; // 0x1609 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_160a[0x6]; // 0x160a (Size: 0x6, Type: PaddingProperty)
    double PressProgress; // 0x1610 (Size: 0x8, Type: DoubleProperty)
    bool bIgnoreInputActionWidgetText; // 0x1618 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1619[0x7]; // 0x1619 (Size: 0x7, Type: PaddingProperty)
    uint8_t HoldActionStarted[0x10]; // 0x1620 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bHolding; // 0x1630 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1631[0x7]; // 0x1631 (Size: 0x7, Type: PaddingProperty)
    uint8_t HoldActionEnded[0x10]; // 0x1638 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t HoldActionCompleted[0x10]; // 0x1648 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void ShowIcon(bool& bShouldShow); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateText(); // 0x288a61c (Index: 0x2, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void UpdateTextAndStyle(ECommonInputType& InputType); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateTextStyle(); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateStyle(bool& UsingGamepad); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x7, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Destruct(); // 0x288a61c (Index: 0x8, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void Get_Dynamic_Material(UMaterialInstanceDynamic*& Ret_Material); // 0x288a61c (Index: 0xa, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void GetPressProgress(double& Progress); // 0x288a61c (Index: 0xb, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void HoldActionCompleted__DelegateSignature(); // 0x288a61c (Index: 0xc, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void HoldActionEnded__DelegateSignature(); // 0x288a61c (Index: 0xd, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void HoldActionStarted__DelegateSignature(); // 0x288a61c (Index: 0xe, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void InitializeButton(); // 0x288a61c (Index: 0xf, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x14, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void Set_Icon(FSlateBrush& IconBrush); // 0x288a61c (Index: 0x15, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Text(FText& ButtonText); // 0x288a61c (Index: 0x16, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetContentAlignment(TEnumAsByte<EHorizontalAlignment>& ContentAlignment); // 0x288a61c (Index: 0x17, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetControllerStyle(UClass*& ControllerInputStyle); // 0x288a61c (Index: 0x18, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetInitialMouseKeyboardStyle(); // 0x288a61c (Index: 0x19, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetMouseKeyboardStyle(UClass*& ControllerInputStyle); // 0x288a61c (Index: 0x1a, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void SetTabLabelInfo(const FFortTabButtonLabelInfo TabLabelInfo); // 0x288a61c (Index: 0x1b, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)

private:
    void SetTextInternal(FText& InButtonText); // 0x288a61c (Index: 0x0, Flags: Private|BlueprintCallable|BlueprintEvent)
    void UpdateContentAlignment(); // 0x288a61c (Index: 0x5, Flags: Private|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnActionComplete(); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void OnActionProgress(float& HeldPercent); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCurrentTextStyleChanged(); // 0x288a61c (Index: 0x12, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTriggeredInputActionChanged(const FDataTableRowHandle NewTriggeredAction); // 0x288a61c (Index: 0x13, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UIconTextButtonHold_C) == 0x1658, "Size mismatch for UIconTextButtonHold_C");
static_assert(offsetof(UIconTextButtonHold_C, UberGraphFrame) == 0x14f0, "Offset mismatch for UIconTextButtonHold_C::UberGraphFrame");
static_assert(offsetof(UIconTextButtonHold_C, RightExtraContentSlot) == 0x14f8, "Offset mismatch for UIconTextButtonHold_C::RightExtraContentSlot");
static_assert(offsetof(UIconTextButtonHold_C, LeftSideImage) == 0x1500, "Offset mismatch for UIconTextButtonHold_C::LeftSideImage");
static_assert(offsetof(UIconTextButtonHold_C, HorizontalBox_ButtonContent) == 0x1508, "Offset mismatch for UIconTextButtonHold_C::HorizontalBox_ButtonContent");
static_assert(offsetof(UIconTextButtonHold_C, ContentBorder) == 0x1510, "Offset mismatch for UIconTextButtonHold_C::ContentBorder");
static_assert(offsetof(UIconTextButtonHold_C, CenterButtonTextWidget) == 0x1518, "Offset mismatch for UIconTextButtonHold_C::CenterButtonTextWidget");
static_assert(offsetof(UIconTextButtonHold_C, ButtonText) == 0x1520, "Offset mismatch for UIconTextButtonHold_C::ButtonText");
static_assert(offsetof(UIconTextButtonHold_C, IconBrush) == 0x1530, "Offset mismatch for UIconTextButtonHold_C::IconBrush");
static_assert(offsetof(UIconTextButtonHold_C, ControllerInputStyle) == 0x15e0, "Offset mismatch for UIconTextButtonHold_C::ControllerInputStyle");
static_assert(offsetof(UIconTextButtonHold_C, MouseKeyboardStyle) == 0x15e8, "Offset mismatch for UIconTextButtonHold_C::MouseKeyboardStyle");
static_assert(offsetof(UIconTextButtonHold_C, ContentAlignment) == 0x15f0, "Offset mismatch for UIconTextButtonHold_C::ContentAlignment");
static_assert(offsetof(UIconTextButtonHold_C, bMouseKeyboardStyleSet) == 0x15f1, "Offset mismatch for UIconTextButtonHold_C::bMouseKeyboardStyleSet");
static_assert(offsetof(UIconTextButtonHold_C, OverrideButtonText) == 0x15f8, "Offset mismatch for UIconTextButtonHold_C::OverrideButtonText");
static_assert(offsetof(UIconTextButtonHold_C, ButtonTextJustification) == 0x1608, "Offset mismatch for UIconTextButtonHold_C::ButtonTextJustification");
static_assert(offsetof(UIconTextButtonHold_C, bDisplayAllCaps) == 0x1609, "Offset mismatch for UIconTextButtonHold_C::bDisplayAllCaps");
static_assert(offsetof(UIconTextButtonHold_C, PressProgress) == 0x1610, "Offset mismatch for UIconTextButtonHold_C::PressProgress");
static_assert(offsetof(UIconTextButtonHold_C, bIgnoreInputActionWidgetText) == 0x1618, "Offset mismatch for UIconTextButtonHold_C::bIgnoreInputActionWidgetText");
static_assert(offsetof(UIconTextButtonHold_C, HoldActionStarted) == 0x1620, "Offset mismatch for UIconTextButtonHold_C::HoldActionStarted");
static_assert(offsetof(UIconTextButtonHold_C, bHolding) == 0x1630, "Offset mismatch for UIconTextButtonHold_C::bHolding");
static_assert(offsetof(UIconTextButtonHold_C, HoldActionEnded) == 0x1638, "Offset mismatch for UIconTextButtonHold_C::HoldActionEnded");
static_assert(offsetof(UIconTextButtonHold_C, HoldActionCompleted) == 0x1648, "Offset mismatch for UIconTextButtonHold_C::HoldActionCompleted");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Feature_L_Skew_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Feature_L_Skew_C) == 0x710, "Size mismatch for UButtonStyle_Feature_L_Skew_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Tab_Main_S11_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Tab_Main_S11_C) == 0x710, "Size mismatch for UButtonStyle_Tab_Main_S11_C");

// Size: 0x15a8 (Inherited: 0x45c0, Single: 0xffffcfe8)
class UGamepadKeyTextButton_C : public UFortGamepadCustomListItem
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x1500 (Size: 0x8, Type: StructProperty)
    USizeBox* SizeBox_Nokey; // 0x1508 (Size: 0x8, Type: ObjectProperty)
    UFortRichTextBlockLegacy* FortRichTextBlock_NoKey; // 0x1510 (Size: 0x8, Type: ObjectProperty)
    UFortRichTextBlockLegacy* FortRichTextBlock_Desc; // 0x1518 (Size: 0x8, Type: ObjectProperty)
    UBorder* ContentBorder; // 0x1520 (Size: 0x8, Type: ObjectProperty)
    UKeybindWidget_C* BoundKey; // 0x1528 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText; // 0x1530 (Size: 0x10, Type: TextProperty)
    UClass* ControllerInputStyle; // 0x1540 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EHorizontalAlignment> ContentAlignment; // 0x1548 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1549[0x7]; // 0x1549 (Size: 0x7, Type: PaddingProperty)
    uint8_t ChangeTheBinding_Button[0x10]; // 0x1550 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FName ActionNameData; // 0x1560 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1564[0x4]; // 0x1564 (Size: 0x4, Type: PaddingProperty)
    FKey KeyData; // 0x1568 (Size: 0x18, Type: StructProperty)
    FText TextData; // 0x1580 (Size: 0x10, Type: TextProperty)
    FKey KeyNone; // 0x1590 (Size: 0x18, Type: StructProperty)

public:
    void SetContentAlignment(TEnumAsByte<EHorizontalAlignment>& ContentAlignment); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x2, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void ChangeTheBinding_Button__DelegateSignature(FName& ActionName, FKey& Key); // 0x288a61c (Index: 0x5, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void SetTabLabelInfo(const FFortTabButtonLabelInfo TabLabelInfo); // 0x288a61c (Index: 0x8, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetNonInteractableStyle(); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)

private:
    void UpdateContentAlignment(); // 0x288a61c (Index: 0x6, Flags: Private|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnListItemObjectSet(UObject*& ListItemObject); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGamepadKeyTextButton_C) == 0x15a8, "Size mismatch for UGamepadKeyTextButton_C");
static_assert(offsetof(UGamepadKeyTextButton_C, UberGraphFrame) == 0x1500, "Offset mismatch for UGamepadKeyTextButton_C::UberGraphFrame");
static_assert(offsetof(UGamepadKeyTextButton_C, SizeBox_Nokey) == 0x1508, "Offset mismatch for UGamepadKeyTextButton_C::SizeBox_Nokey");
static_assert(offsetof(UGamepadKeyTextButton_C, FortRichTextBlock_NoKey) == 0x1510, "Offset mismatch for UGamepadKeyTextButton_C::FortRichTextBlock_NoKey");
static_assert(offsetof(UGamepadKeyTextButton_C, FortRichTextBlock_Desc) == 0x1518, "Offset mismatch for UGamepadKeyTextButton_C::FortRichTextBlock_Desc");
static_assert(offsetof(UGamepadKeyTextButton_C, ContentBorder) == 0x1520, "Offset mismatch for UGamepadKeyTextButton_C::ContentBorder");
static_assert(offsetof(UGamepadKeyTextButton_C, BoundKey) == 0x1528, "Offset mismatch for UGamepadKeyTextButton_C::BoundKey");
static_assert(offsetof(UGamepadKeyTextButton_C, ButtonText) == 0x1530, "Offset mismatch for UGamepadKeyTextButton_C::ButtonText");
static_assert(offsetof(UGamepadKeyTextButton_C, ControllerInputStyle) == 0x1540, "Offset mismatch for UGamepadKeyTextButton_C::ControllerInputStyle");
static_assert(offsetof(UGamepadKeyTextButton_C, ContentAlignment) == 0x1548, "Offset mismatch for UGamepadKeyTextButton_C::ContentAlignment");
static_assert(offsetof(UGamepadKeyTextButton_C, ChangeTheBinding_Button) == 0x1550, "Offset mismatch for UGamepadKeyTextButton_C::ChangeTheBinding_Button");
static_assert(offsetof(UGamepadKeyTextButton_C, ActionNameData) == 0x1560, "Offset mismatch for UGamepadKeyTextButton_C::ActionNameData");
static_assert(offsetof(UGamepadKeyTextButton_C, KeyData) == 0x1568, "Offset mismatch for UGamepadKeyTextButton_C::KeyData");
static_assert(offsetof(UGamepadKeyTextButton_C, TextData) == 0x1580, "Offset mismatch for UGamepadKeyTextButton_C::TextData");
static_assert(offsetof(UGamepadKeyTextButton_C, KeyNone) == 0x1590, "Offset mismatch for UGamepadKeyTextButton_C::KeyNone");

// Size: 0x15e3 (Inherited: 0x30c0, Single: 0xffffe523)
class UScrollingTextButton_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x14f0 (Size: 0x8, Type: StructProperty)
    UImage* LeftSideImage; // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    UBorder* ContentBorder; // 0x1500 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* CenterButtonTextWidget; // 0x1508 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText; // 0x1510 (Size: 0x10, Type: TextProperty)
    FSlateBrush IconBrush; // 0x1520 (Size: 0xb0, Type: StructProperty)
    UClass* ControllerInputStyle; // 0x15d0 (Size: 0x8, Type: ClassProperty)
    UClass* MouseKeyboardStyle; // 0x15d8 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EHorizontalAlignment> ContentAlignment; // 0x15e0 (Size: 0x1, Type: ByteProperty)
    bool bMouseKeyboardStyleSet; // 0x15e1 (Size: 0x1, Type: BoolProperty)
    bool UseLightInput; // 0x15e2 (Size: 0x1, Type: BoolProperty)

public:
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x0, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void InitializeButton(); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x7, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void UpdateTextStyle(); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateTextAndStyle(bool& bUsingGamepad); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateText(); // 0x288a61c (Index: 0xc, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void UpdateStyle(bool& UsingGamepad); // 0x288a61c (Index: 0xd, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void SetTabLabelInfo(const FFortTabButtonLabelInfo TabLabelInfo); // 0x288a61c (Index: 0xf, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetMouseKeyboardStyle(UClass*& ControllerInputStyle); // 0x288a61c (Index: 0x10, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetInitialMouseKeyboardStyle(); // 0x288a61c (Index: 0x11, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetControllerStyle(UClass*& ControllerInputStyle); // 0x288a61c (Index: 0x12, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetContentAlignment(TEnumAsByte<EHorizontalAlignment>& ContentAlignment); // 0x288a61c (Index: 0x13, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Text(FText& ButtonText); // 0x288a61c (Index: 0x14, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Icon(FSlateBrush& IconBrush); // 0x288a61c (Index: 0x15, Flags: Public|BlueprintCallable|BlueprintEvent)

private:
    void UpdateContentAlignment(); // 0x288a61c (Index: 0xe, Flags: Private|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnTriggeredInputActionChanged(const FDataTableRowHandle NewTriggeredAction); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnCurrentTextStyleChanged(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnActionProgress(float& HeldPercent); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnActionComplete(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UScrollingTextButton_C) == 0x15e3, "Size mismatch for UScrollingTextButton_C");
static_assert(offsetof(UScrollingTextButton_C, UberGraphFrame) == 0x14f0, "Offset mismatch for UScrollingTextButton_C::UberGraphFrame");
static_assert(offsetof(UScrollingTextButton_C, LeftSideImage) == 0x14f8, "Offset mismatch for UScrollingTextButton_C::LeftSideImage");
static_assert(offsetof(UScrollingTextButton_C, ContentBorder) == 0x1500, "Offset mismatch for UScrollingTextButton_C::ContentBorder");
static_assert(offsetof(UScrollingTextButton_C, CenterButtonTextWidget) == 0x1508, "Offset mismatch for UScrollingTextButton_C::CenterButtonTextWidget");
static_assert(offsetof(UScrollingTextButton_C, ButtonText) == 0x1510, "Offset mismatch for UScrollingTextButton_C::ButtonText");
static_assert(offsetof(UScrollingTextButton_C, IconBrush) == 0x1520, "Offset mismatch for UScrollingTextButton_C::IconBrush");
static_assert(offsetof(UScrollingTextButton_C, ControllerInputStyle) == 0x15d0, "Offset mismatch for UScrollingTextButton_C::ControllerInputStyle");
static_assert(offsetof(UScrollingTextButton_C, MouseKeyboardStyle) == 0x15d8, "Offset mismatch for UScrollingTextButton_C::MouseKeyboardStyle");
static_assert(offsetof(UScrollingTextButton_C, ContentAlignment) == 0x15e0, "Offset mismatch for UScrollingTextButton_C::ContentAlignment");
static_assert(offsetof(UScrollingTextButton_C, bMouseKeyboardStyleSet) == 0x15e1, "Offset mismatch for UScrollingTextButton_C::bMouseKeyboardStyleSet");
static_assert(offsetof(UScrollingTextButton_C, UseLightInput) == 0x15e2, "Offset mismatch for UScrollingTextButton_C::UseLightInput");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Clear_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Clear_C) == 0x710, "Size mismatch for UButtonStyle_Clear_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyleClearDismissTooltip_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyleClearDismissTooltip_C) == 0x710, "Size mismatch for UButtonStyleClearDismissTooltip_C");

// Size: 0x710 (Inherited: 0x1c68, Single: 0xffffeaa8)
class UButtonStyle_MediumTransparentWithCues_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

static_assert(sizeof(UButtonStyle_MediumTransparentWithCues_C) == 0x710, "Size mismatch for UButtonStyle_MediumTransparentWithCues_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Primary_MSkew_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Primary_MSkew_C) == 0x190, "Size mismatch for UTextStyle_Button_Primary_MSkew_C");

// Size: 0x42d0 (Inherited: 0x4358, Single: 0xffffff78)
class UDefaultUIDataConfiguration_C : public UFortUIDataConfiguration
{
public:
};

static_assert(sizeof(UDefaultUIDataConfiguration_C) == 0x42d0, "Size mismatch for UDefaultUIDataConfiguration_C");

// Size: 0x180 (Inherited: 0x308, Single: 0xfffffe78)
class UUIManager_Athena_C : public UFortUIManager_Athena
{
public:
};

static_assert(sizeof(UUIManager_Athena_C) == 0x180, "Size mismatch for UUIManager_Athena_C");

// Size: 0x160 (Inherited: 0x2e8, Single: 0xfffffe78)
class UUIManager_Startup_C : public UFortUIManager_Startup
{
public:
};

static_assert(sizeof(UUIManager_Startup_C) == 0x160, "Size mismatch for UUIManager_Startup_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Primary_M_Disabled_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Primary_M_Disabled_C) == 0x190, "Size mismatch for UTextStyle_Button_Primary_M_Disabled_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Rotator_Small_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Rotator_Small_C) == 0x710, "Size mismatch for UButtonStyle_Rotator_Small_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UAthena_ButtonStyle_CollectionTab_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UAthena_ButtonStyle_CollectionTab_C) == 0x710, "Size mismatch for UAthena_ButtonStyle_CollectionTab_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Skew_SocialInteraction_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Skew_SocialInteraction_C) == 0x710, "Size mismatch for UButtonStyle_Skew_SocialInteraction_C");

// Size: 0x190 (Inherited: 0x4d8, Single: 0xfffffcb8)
class UTextStyle_BurbSmBk_15_LightBlue_C : public UTextStyle_BaseParent_C
{
public:
};

static_assert(sizeof(UTextStyle_BurbSmBk_15_LightBlue_C) == 0x190, "Size mismatch for UTextStyle_BurbSmBk_15_LightBlue_C");

// Size: 0x190 (Inherited: 0x4d8, Single: 0xfffffcb8)
class UTextStyle_BurbSmBk_15_DarkBlue_C : public UTextStyle_BaseParent_C
{
public:
};

static_assert(sizeof(UTextStyle_BurbSmBk_15_DarkBlue_C) == 0x190, "Size mismatch for UTextStyle_BurbSmBk_15_DarkBlue_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Tab_Manage_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Tab_Manage_C) == 0x710, "Size mismatch for UButtonStyle_Tab_Manage_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UAthena_ButtonStyle_BlueMenuButton_Settings_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UAthena_ButtonStyle_BlueMenuButton_Settings_C) == 0x710, "Size mismatch for UAthena_ButtonStyle_BlueMenuButton_Settings_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Skew_Error_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Skew_Error_C) == 0x710, "Size mismatch for UButtonStyle_Skew_Error_C");

// Size: 0x1689 (Inherited: 0x30c0, Single: 0xffffe5c9)
class UIconTextButton_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x14f0 (Size: 0x8, Type: StructProperty)
    UNamedSlot* RightExtraContentSlot; // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    UImage* LeftSideImage; // 0x1500 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_ButtonContent; // 0x1508 (Size: 0x8, Type: ObjectProperty)
    UBorder* ContentBorder; // 0x1510 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* CenterButtonTextWidget; // 0x1518 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText; // 0x1520 (Size: 0x10, Type: TextProperty)
    FSlateBrush IconBrush; // 0x1530 (Size: 0xb0, Type: StructProperty)
    UClass* ControllerInputStyle; // 0x15e0 (Size: 0x8, Type: ClassProperty)
    UClass* MouseKeyboardStyle; // 0x15e8 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EHorizontalAlignment> ContentAlignment; // 0x15f0 (Size: 0x1, Type: ByteProperty)
    bool bMouseKeyboardStyleSet; // 0x15f1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15f2[0x6]; // 0x15f2 (Size: 0x6, Type: PaddingProperty)
    FText OverrideButtonText; // 0x15f8 (Size: 0x10, Type: TextProperty)
    TEnumAsByte<ETextJustify> ButtonTextJustification; // 0x1608 (Size: 0x1, Type: ByteProperty)
    bool bDisplayAllCaps; // 0x1609 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_160a[0x6]; // 0x160a (Size: 0x6, Type: PaddingProperty)
    double PressProgress; // 0x1610 (Size: 0x8, Type: DoubleProperty)
    bool bIgnoreInputActionWidgetText; // 0x1618 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1619[0x7]; // 0x1619 (Size: 0x7, Type: PaddingProperty)
    uint8_t FocusChangedEvent[0x10]; // 0x1620 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FSlateFontInfo Font; // 0x1630 (Size: 0x58, Type: StructProperty)
    bool UseLightInput; // 0x1688 (Size: 0x1, Type: BoolProperty)

public:
    void ShowIcon(bool& bShouldShow); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void SetTabLabelInfo(const FFortTabButtonLabelInfo TabLabelInfo); // 0x288a61c (Index: 0x3, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetMouseKeyboardStyle(UClass*& ControllerInputStyle); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetInitialMouseKeyboardStyle(); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetControllerStyle(UClass*& ControllerInputStyle); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetContentAlignment(TEnumAsByte<EHorizontalAlignment>& ContentAlignment); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Text(FText& ButtonText); // 0x288a61c (Index: 0x8, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Icon(FSlateBrush& IconBrush); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0xa, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual FEventReply OnFocusReceived(FGeometry& MyGeometry, FFocusEvent& InFocusEvent); // 0x288a61c (Index: 0xd, Flags: BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void OnFocusLost(FFocusEvent& InFocusEvent); // 0x288a61c (Index: 0xe, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void InitializeButton(); // 0x288a61c (Index: 0x12, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetPressProgress(double& Progress); // 0x288a61c (Index: 0x13, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void Get_Dynamic_Material(UMaterialInstanceDynamic*& Ret_Material); // 0x288a61c (Index: 0x14, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void FocusChangedEvent__DelegateSignature(bool& HasFocus); // 0x288a61c (Index: 0x15, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void Destruct(); // 0x288a61c (Index: 0x17, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x18, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void UpdateTextStyle(); // 0x288a61c (Index: 0x1b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateTextAndStyle(ECommonInputType& InputType); // 0x288a61c (Index: 0x1c, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateText(); // 0x288a61c (Index: 0x1d, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void UpdateStyle(bool& UsingGamepad); // 0x288a61c (Index: 0x1e, Flags: Public|BlueprintCallable|BlueprintEvent)

private:
    void UpdateContentAlignment(); // 0x288a61c (Index: 0x0, Flags: Private|BlueprintCallable|BlueprintEvent)
    void SetTextInternal(FText& InButtonText); // 0x288a61c (Index: 0x2, Flags: Private|BlueprintCallable|BlueprintEvent)
    void BindCommonInputSubsystem(bool& bBind); // 0x288a61c (Index: 0x1a, Flags: Private|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnTriggeringInputActionChanged(const FDataTableRowHandle NewTriggeredAction); // 0x288a61c (Index: 0xb, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnTriggeredInputActionChanged(const FDataTableRowHandle NewTriggeredAction); // 0x288a61c (Index: 0xc, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnCurrentTextStyleChanged(); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void OnActionProgress(float& HeldPercent); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void OnActionComplete(); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UIconTextButton_C) == 0x1689, "Size mismatch for UIconTextButton_C");
static_assert(offsetof(UIconTextButton_C, UberGraphFrame) == 0x14f0, "Offset mismatch for UIconTextButton_C::UberGraphFrame");
static_assert(offsetof(UIconTextButton_C, RightExtraContentSlot) == 0x14f8, "Offset mismatch for UIconTextButton_C::RightExtraContentSlot");
static_assert(offsetof(UIconTextButton_C, LeftSideImage) == 0x1500, "Offset mismatch for UIconTextButton_C::LeftSideImage");
static_assert(offsetof(UIconTextButton_C, HorizontalBox_ButtonContent) == 0x1508, "Offset mismatch for UIconTextButton_C::HorizontalBox_ButtonContent");
static_assert(offsetof(UIconTextButton_C, ContentBorder) == 0x1510, "Offset mismatch for UIconTextButton_C::ContentBorder");
static_assert(offsetof(UIconTextButton_C, CenterButtonTextWidget) == 0x1518, "Offset mismatch for UIconTextButton_C::CenterButtonTextWidget");
static_assert(offsetof(UIconTextButton_C, ButtonText) == 0x1520, "Offset mismatch for UIconTextButton_C::ButtonText");
static_assert(offsetof(UIconTextButton_C, IconBrush) == 0x1530, "Offset mismatch for UIconTextButton_C::IconBrush");
static_assert(offsetof(UIconTextButton_C, ControllerInputStyle) == 0x15e0, "Offset mismatch for UIconTextButton_C::ControllerInputStyle");
static_assert(offsetof(UIconTextButton_C, MouseKeyboardStyle) == 0x15e8, "Offset mismatch for UIconTextButton_C::MouseKeyboardStyle");
static_assert(offsetof(UIconTextButton_C, ContentAlignment) == 0x15f0, "Offset mismatch for UIconTextButton_C::ContentAlignment");
static_assert(offsetof(UIconTextButton_C, bMouseKeyboardStyleSet) == 0x15f1, "Offset mismatch for UIconTextButton_C::bMouseKeyboardStyleSet");
static_assert(offsetof(UIconTextButton_C, OverrideButtonText) == 0x15f8, "Offset mismatch for UIconTextButton_C::OverrideButtonText");
static_assert(offsetof(UIconTextButton_C, ButtonTextJustification) == 0x1608, "Offset mismatch for UIconTextButton_C::ButtonTextJustification");
static_assert(offsetof(UIconTextButton_C, bDisplayAllCaps) == 0x1609, "Offset mismatch for UIconTextButton_C::bDisplayAllCaps");
static_assert(offsetof(UIconTextButton_C, PressProgress) == 0x1610, "Offset mismatch for UIconTextButton_C::PressProgress");
static_assert(offsetof(UIconTextButton_C, bIgnoreInputActionWidgetText) == 0x1618, "Offset mismatch for UIconTextButton_C::bIgnoreInputActionWidgetText");
static_assert(offsetof(UIconTextButton_C, FocusChangedEvent) == 0x1620, "Offset mismatch for UIconTextButton_C::FocusChangedEvent");
static_assert(offsetof(UIconTextButton_C, Font) == 0x1630, "Offset mismatch for UIconTextButton_C::Font");
static_assert(offsetof(UIconTextButton_C, UseLightInput) == 0x1688, "Offset mismatch for UIconTextButton_C::UseLightInput");

// Size: 0x1540 (Inherited: 0x30c0, Single: 0xffffe480)
class UPanelButton_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x14f0 (Size: 0x8, Type: StructProperty)
    UNamedSlot* ContentSlot; // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    UClass* ControllerInputStyle; // 0x1500 (Size: 0x8, Type: ClassProperty)
    UClass* MouseKeyboardStyle; // 0x1508 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EHorizontalAlignment> InputActionHorizontalAlignment; // 0x1510 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EVerticalAlignment> InputActionVerticalAlignment; // 0x1511 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1512[0x6]; // 0x1512 (Size: 0x6, Type: PaddingProperty)
    FVector2D InputActionRenderTranslation; // 0x1518 (Size: 0x10, Type: StructProperty)
    bool InputActionUseRimBrush; // 0x1528 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1529[0x7]; // 0x1529 (Size: 0x7, Type: PaddingProperty)
    FVector2D InputActionRimBrushSize; // 0x1530 (Size: 0x10, Type: StructProperty)

public:
    void InitializeButton(); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x6, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void UpdateTextAndStyle(); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateStyle(bool& bUsingGamepad); // 0x288a61c (Index: 0xa, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void UpdateInputActionLayout(); // 0x288a61c (Index: 0xb, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0xc, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void OnTriggeredInputActionChanged(const FDataTableRowHandle NewTriggeredAction); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnActionProgress(float& HeldPercent); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnActionComplete(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnUnhovered(); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnHovered(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UPanelButton_C) == 0x1540, "Size mismatch for UPanelButton_C");
static_assert(offsetof(UPanelButton_C, UberGraphFrame) == 0x14f0, "Offset mismatch for UPanelButton_C::UberGraphFrame");
static_assert(offsetof(UPanelButton_C, ContentSlot) == 0x14f8, "Offset mismatch for UPanelButton_C::ContentSlot");
static_assert(offsetof(UPanelButton_C, ControllerInputStyle) == 0x1500, "Offset mismatch for UPanelButton_C::ControllerInputStyle");
static_assert(offsetof(UPanelButton_C, MouseKeyboardStyle) == 0x1508, "Offset mismatch for UPanelButton_C::MouseKeyboardStyle");
static_assert(offsetof(UPanelButton_C, InputActionHorizontalAlignment) == 0x1510, "Offset mismatch for UPanelButton_C::InputActionHorizontalAlignment");
static_assert(offsetof(UPanelButton_C, InputActionVerticalAlignment) == 0x1511, "Offset mismatch for UPanelButton_C::InputActionVerticalAlignment");
static_assert(offsetof(UPanelButton_C, InputActionRenderTranslation) == 0x1518, "Offset mismatch for UPanelButton_C::InputActionRenderTranslation");
static_assert(offsetof(UPanelButton_C, InputActionUseRimBrush) == 0x1528, "Offset mismatch for UPanelButton_C::InputActionUseRimBrush");
static_assert(offsetof(UPanelButton_C, InputActionRimBrushSize) == 0x1530, "Offset mismatch for UPanelButton_C::InputActionRimBrushSize");

// Size: 0x1552 (Inherited: 0x30c0, Single: 0xffffe492)
class USoloButton_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x14f0 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_ButtonAction; // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_Control; // 0x1500 (Size: 0x8, Type: ObjectProperty)
    UImage* ButtonBacking; // 0x1508 (Size: 0x8, Type: ObjectProperty)
    UBorder* Border_Container; // 0x1510 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Hover; // 0x1518 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Pressed; // 0x1520 (Size: 0x8, Type: ObjectProperty)
    FText Button_Description; // 0x1528 (Size: 0x10, Type: TextProperty)
    bool FontSizeOveride; // 0x1538 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1539[0x3]; // 0x1539 (Size: 0x3, Type: PaddingProperty)
    int32_t FontSize; // 0x153c (Size: 0x4, Type: IntProperty)
    FMargin Padding_Overide; // 0x1540 (Size: 0x10, Type: StructProperty)
    bool PaddingOveride; // 0x1550 (Size: 0x1, Type: BoolProperty)
    bool IsDisabled; // 0x1551 (Size: 0x1, Type: BoolProperty)

public:
    void SetText(FText& Text); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x3, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void HandleSize(); // 0x288a61c (Index: 0x4, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x6, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void BP_OnDisabled(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnClicked(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnUnhovered(); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnHovered(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnEnabled(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(USoloButton_C) == 0x1552, "Size mismatch for USoloButton_C");
static_assert(offsetof(USoloButton_C, UberGraphFrame) == 0x14f0, "Offset mismatch for USoloButton_C::UberGraphFrame");
static_assert(offsetof(USoloButton_C, Text_ButtonAction) == 0x14f8, "Offset mismatch for USoloButton_C::Text_ButtonAction");
static_assert(offsetof(USoloButton_C, SizeBox_Control) == 0x1500, "Offset mismatch for USoloButton_C::SizeBox_Control");
static_assert(offsetof(USoloButton_C, ButtonBacking) == 0x1508, "Offset mismatch for USoloButton_C::ButtonBacking");
static_assert(offsetof(USoloButton_C, Border_Container) == 0x1510, "Offset mismatch for USoloButton_C::Border_Container");
static_assert(offsetof(USoloButton_C, Hover) == 0x1518, "Offset mismatch for USoloButton_C::Hover");
static_assert(offsetof(USoloButton_C, Pressed) == 0x1520, "Offset mismatch for USoloButton_C::Pressed");
static_assert(offsetof(USoloButton_C, Button_Description) == 0x1528, "Offset mismatch for USoloButton_C::Button_Description");
static_assert(offsetof(USoloButton_C, FontSizeOveride) == 0x1538, "Offset mismatch for USoloButton_C::FontSizeOveride");
static_assert(offsetof(USoloButton_C, FontSize) == 0x153c, "Offset mismatch for USoloButton_C::FontSize");
static_assert(offsetof(USoloButton_C, Padding_Overide) == 0x1540, "Offset mismatch for USoloButton_C::Padding_Overide");
static_assert(offsetof(USoloButton_C, PaddingOveride) == 0x1550, "Offset mismatch for USoloButton_C::PaddingOveride");
static_assert(offsetof(USoloButton_C, IsDisabled) == 0x1551, "Offset mismatch for USoloButton_C::IsDisabled");

// Size: 0x510 (Inherited: 0x1018, Single: 0xfffff4f8)
class UWBP_Modal_ReviewYourSettings_C : public UFortReviewYourSettingsModal
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x4e0 (Size: 0x8, Type: StructProperty)
    USafeZone* MobileClose; // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    UImage* Lightbox_HitTestBlocker; // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_BackgroundBottomBar; // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    USafeZone* ContentSZ; // 0x500 (Size: 0x8, Type: ObjectProperty)
    UImage* Containment; // 0x508 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void OnModalBackout(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_Modal_ReviewYourSettings_C) == 0x510, "Size mismatch for UWBP_Modal_ReviewYourSettings_C");
static_assert(offsetof(UWBP_Modal_ReviewYourSettings_C, UberGraphFrame) == 0x4e0, "Offset mismatch for UWBP_Modal_ReviewYourSettings_C::UberGraphFrame");
static_assert(offsetof(UWBP_Modal_ReviewYourSettings_C, MobileClose) == 0x4e8, "Offset mismatch for UWBP_Modal_ReviewYourSettings_C::MobileClose");
static_assert(offsetof(UWBP_Modal_ReviewYourSettings_C, Lightbox_HitTestBlocker) == 0x4f0, "Offset mismatch for UWBP_Modal_ReviewYourSettings_C::Lightbox_HitTestBlocker");
static_assert(offsetof(UWBP_Modal_ReviewYourSettings_C, Image_BackgroundBottomBar) == 0x4f8, "Offset mismatch for UWBP_Modal_ReviewYourSettings_C::Image_BackgroundBottomBar");
static_assert(offsetof(UWBP_Modal_ReviewYourSettings_C, ContentSZ) == 0x500, "Offset mismatch for UWBP_Modal_ReviewYourSettings_C::ContentSZ");
static_assert(offsetof(UWBP_Modal_ReviewYourSettings_C, Containment) == 0x508, "Offset mismatch for UWBP_Modal_ReviewYourSettings_C::Containment");

// Size: 0x190 (Inherited: 0x4d8, Single: 0xfffffcb8)
class UTextStyle_BurbSmBk_20_LightGrey_C : public UTextStyle_BaseParent_C
{
public:
};

static_assert(sizeof(UTextStyle_BurbSmBk_20_LightGrey_C) == 0x190, "Size mismatch for UTextStyle_BurbSmBk_20_LightGrey_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Skew_LessDesirable_AddFriend_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Skew_LessDesirable_AddFriend_C) == 0x710, "Size mismatch for UButtonStyle_Skew_LessDesirable_AddFriend_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Primary_L_Yellow_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Primary_L_Yellow_C) == 0x710, "Size mismatch for UButtonStyle_Primary_L_Yellow_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_TransparentList_Social_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_TransparentList_Social_C) == 0x710, "Size mismatch for UButtonStyle_TransparentList_Social_C");

// Size: 0x710 (Inherited: 0x1558, Single: 0xfffff1b8)
class UButtonStyle_MediumTransparentNoCues_C : public UButtonStyle_MediumBase_C
{
public:
};

static_assert(sizeof(UButtonStyle_MediumTransparentNoCues_C) == 0x710, "Size mismatch for UButtonStyle_MediumTransparentNoCues_C");

// Size: 0x710 (Inherited: 0xe48, Single: 0xfffff8c8)
class UButtonStyle_MediumBase_C : public UButtonStyle_Base_C
{
public:
};

static_assert(sizeof(UButtonStyle_MediumBase_C) == 0x710, "Size mismatch for UButtonStyle_MediumBase_C");

// Size: 0x190 (Inherited: 0x348, Single: 0xfffffe48)
class UTextStyle_MediumButton_Disabled_C : public UTextStyle_MediumButton_C
{
public:
};

static_assert(sizeof(UTextStyle_MediumButton_Disabled_C) == 0x190, "Size mismatch for UTextStyle_MediumButton_Disabled_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_MediumButton_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_MediumButton_C) == 0x190, "Size mismatch for UTextStyle_MediumButton_C");

// Size: 0x710 (Inherited: 0xe48, Single: 0xfffff8c8)
class UButtonStyle_Empty_C : public UButtonStyle_Base_C
{
public:
};

static_assert(sizeof(UButtonStyle_Empty_C) == 0x710, "Size mismatch for UButtonStyle_Empty_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Tab_Main_Recolor_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Tab_Main_Recolor_C) == 0x710, "Size mismatch for UButtonStyle_Tab_Main_Recolor_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_RotatorBorder_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_RotatorBorder_C) == 0x710, "Size mismatch for UButtonStyle_RotatorBorder_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Icon_Transparent_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Icon_Transparent_C) == 0x710, "Size mismatch for UButtonStyle_Icon_Transparent_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Primary_M_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Primary_M_C) == 0x710, "Size mismatch for UButtonStyle_Primary_M_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Primary_Radio_M_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Primary_Radio_M_C) == 0x710, "Size mismatch for UButtonStyle_Primary_Radio_M_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Primary_M_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Primary_M_C) == 0x190, "Size mismatch for UTextStyle_Button_Primary_M_C");

// Size: 0x710 (Inherited: 0x1c68, Single: 0xffffeaa8)
class UButtonStyle_ClearSocialSearch_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

static_assert(sizeof(UButtonStyle_ClearSocialSearch_C) == 0x710, "Size mismatch for UButtonStyle_ClearSocialSearch_C");

// Size: 0x710 (Inherited: 0x1c68, Single: 0xffffeaa8)
class UButtonStyle_PageChevron_Left_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

static_assert(sizeof(UButtonStyle_PageChevron_Left_C) == 0x710, "Size mismatch for UButtonStyle_PageChevron_Left_C");

// Size: 0x710 (Inherited: 0x1c68, Single: 0xffffeaa8)
class UButtonStyle_PageChevron_Right_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

static_assert(sizeof(UButtonStyle_PageChevron_Right_C) == 0x710, "Size mismatch for UButtonStyle_PageChevron_Right_C");

// Size: 0x710 (Inherited: 0x1c68, Single: 0xffffeaa8)
class UButtonStyle_GamepadBindings_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

static_assert(sizeof(UButtonStyle_GamepadBindings_C) == 0x710, "Size mismatch for UButtonStyle_GamepadBindings_C");

// Size: 0x710 (Inherited: 0x1c68, Single: 0xffffeaa8)
class UButtonStyle_GamepadBindings_NonInteractable_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

static_assert(sizeof(UButtonStyle_GamepadBindings_NonInteractable_C) == 0x710, "Size mismatch for UButtonStyle_GamepadBindings_NonInteractable_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_TransparentList_Nothing_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_TransparentList_Nothing_C) == 0x710, "Size mismatch for UButtonStyle_TransparentList_Nothing_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Primary_LSkew_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Primary_LSkew_C) == 0x190, "Size mismatch for UTextStyle_Button_Primary_LSkew_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UAthena_ButtonStyle_AngledBlueMenuButton_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UAthena_ButtonStyle_AngledBlueMenuButton_C) == 0x710, "Size mismatch for UAthena_ButtonStyle_AngledBlueMenuButton_C");

// Size: 0x190 (Inherited: 0x4d8, Single: 0xfffffcb8)
class UTextStyle_BurbSmBk_20_White_C : public UTextStyle_BaseParent_C
{
public:
};

static_assert(sizeof(UTextStyle_BurbSmBk_20_White_C) == 0x190, "Size mismatch for UTextStyle_BurbSmBk_20_White_C");

// Size: 0x190 (Inherited: 0x4d8, Single: 0xfffffcb8)
class UTextStyle_BurbSmBk_20_White50pc_C : public UTextStyle_BaseParent_C
{
public:
};

static_assert(sizeof(UTextStyle_BurbSmBk_20_White50pc_C) == 0x190, "Size mismatch for UTextStyle_BurbSmBk_20_White50pc_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Skew_Desirable_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Skew_Desirable_C) == 0x710, "Size mismatch for UButtonStyle_Skew_Desirable_C");

// Size: 0x190 (Inherited: 0x4d8, Single: 0xfffffcb8)
class UTextStyle_BurbSmBk_20_LightBlue_C : public UTextStyle_BaseParent_C
{
public:
};

static_assert(sizeof(UTextStyle_BurbSmBk_20_LightBlue_C) == 0x190, "Size mismatch for UTextStyle_BurbSmBk_20_LightBlue_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_OutlineEmptyFill_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_OutlineEmptyFill_C) == 0x710, "Size mismatch for UButtonStyle_OutlineEmptyFill_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_TransparentList_Social_NoHovered_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_TransparentList_Social_NoHovered_C) == 0x710, "Size mismatch for UButtonStyle_TransparentList_Social_NoHovered_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_FullyInvisible_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_FullyInvisible_C) == 0x710, "Size mismatch for UButtonStyle_FullyInvisible_C");

// Size: 0x30 (Inherited: 0x80, Single: 0xffffffb0)
class UCommonRichTextDecorators_C : public URichTextBlockImageDecorator
{
public:
};

static_assert(sizeof(UCommonRichTextDecorators_C) == 0x30, "Size mismatch for UCommonRichTextDecorators_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Feature_M_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Feature_M_C) == 0x710, "Size mismatch for UButtonStyle_Feature_M_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Feature_M_Base_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Feature_M_Base_C) == 0x190, "Size mismatch for UTextStyle_Button_Feature_M_Base_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Feature_M_Yellow_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Feature_M_Yellow_C) == 0x710, "Size mismatch for UButtonStyle_Feature_M_Yellow_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Primary_M_Skew_BurbankDark_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Primary_M_Skew_BurbankDark_C) == 0x190, "Size mismatch for UTextStyle_Button_Primary_M_Skew_BurbankDark_C");

// Size: 0x710 (Inherited: 0xe48, Single: 0xfffff8c8)
class UButtonStyle_TextOnlyBase_Empty_NoSound_C : public UButtonStyle_Base_C
{
public:
};

static_assert(sizeof(UButtonStyle_TextOnlyBase_Empty_NoSound_C) == 0x710, "Size mismatch for UButtonStyle_TextOnlyBase_Empty_NoSound_C");

// Size: 0x14c8 (Inherited: 0x1bd0, Single: 0xfffff8f8)
class UBackButtonSmall_C : public UCommonButtonBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x14a0 (Size: 0x8, Type: StructProperty)
    UFortMobileImage* Image_Arrow; // 0x14a8 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_3; // 0x14b0 (Size: 0x8, Type: ObjectProperty)
    UCommonActionWidget* CommonActionWidget_65; // 0x14b8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnHover; // 0x14c0 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void OnInitialized(); // 0x288a61c (Index: 0x0, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void BP_OnUnhovered(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnHovered(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnClicked(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UBackButtonSmall_C) == 0x14c8, "Size mismatch for UBackButtonSmall_C");
static_assert(offsetof(UBackButtonSmall_C, UberGraphFrame) == 0x14a0, "Offset mismatch for UBackButtonSmall_C::UberGraphFrame");
static_assert(offsetof(UBackButtonSmall_C, Image_Arrow) == 0x14a8, "Offset mismatch for UBackButtonSmall_C::Image_Arrow");
static_assert(offsetof(UBackButtonSmall_C, HorizontalBox_3) == 0x14b0, "Offset mismatch for UBackButtonSmall_C::HorizontalBox_3");
static_assert(offsetof(UBackButtonSmall_C, CommonActionWidget_65) == 0x14b8, "Offset mismatch for UBackButtonSmall_C::CommonActionWidget_65");
static_assert(offsetof(UBackButtonSmall_C, OnHover) == 0x14c0, "Offset mismatch for UBackButtonSmall_C::OnHover");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Feature_L_Yellow_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Feature_L_Yellow_C) == 0x710, "Size mismatch for UButtonStyle_Feature_L_Yellow_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Feature_L_Base_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Feature_L_Base_C) == 0x190, "Size mismatch for UTextStyle_Button_Feature_L_Base_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Skew_Red_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Skew_Red_C) == 0x710, "Size mismatch for UButtonStyle_Skew_Red_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Skew_LDarkBlue_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Skew_LDarkBlue_C) == 0x710, "Size mismatch for UButtonStyle_Skew_LDarkBlue_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Outline_Skew_Blue_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Outline_Skew_Blue_C) == 0x710, "Size mismatch for UButtonStyle_Outline_Skew_Blue_C");

// Size: 0x710 (Inherited: 0xe48, Single: 0xfffff8c8)
class UButtonStyle_ItemShopTile_C : public UButtonStyle_Base_C
{
public:
};

static_assert(sizeof(UButtonStyle_ItemShopTile_C) == 0x710, "Size mismatch for UButtonStyle_ItemShopTile_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Skew_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Skew_C) == 0x710, "Size mismatch for UButtonStyle_Skew_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Tab_Main_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Tab_Main_C) == 0x710, "Size mismatch for UButtonStyle_Tab_Main_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_BottomBar_S_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_BottomBar_S_C) == 0x190, "Size mismatch for UTextStyle_Button_BottomBar_S_C");

// Size: 0x710 (Inherited: 0xe48, Single: 0xfffff8c8)
class UButtonStyle_Empty_NoSound_C : public UButtonStyle_Base_C
{
public:
};

static_assert(sizeof(UButtonStyle_Empty_NoSound_C) == 0x710, "Size mismatch for UButtonStyle_Empty_NoSound_C");

// Size: 0x710 (Inherited: 0xe48, Single: 0xfffff8c8)
class UButtonStyle_Tab_Main_Bacchus_NoPadding_C : public UButtonStyle_Tab_Main_C
{
public:
};

static_assert(sizeof(UButtonStyle_Tab_Main_Bacchus_NoPadding_C) == 0x710, "Size mismatch for UButtonStyle_Tab_Main_Bacchus_NoPadding_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_PlayerSurvey_ChoiceResponse_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_PlayerSurvey_ChoiceResponse_C) == 0x710, "Size mismatch for UButtonStyle_PlayerSurvey_ChoiceResponse_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Primary_L_Disabled_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Primary_L_Disabled_C) == 0x190, "Size mismatch for UTextStyle_Button_Primary_L_Disabled_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Skew2_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Skew2_C) == 0x710, "Size mismatch for UButtonStyle_Skew2_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Primary_M_Skew_BurbankLightBlue_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Primary_M_Skew_BurbankLightBlue_C) == 0x190, "Size mismatch for UTextStyle_Button_Primary_M_Skew_BurbankLightBlue_C");

// Size: 0x190 (Inherited: 0x1b8, Single: 0xffffffd8)
class UTextStyle_Button_Primary_L_C : public UCommonTextStyle
{
public:
};

static_assert(sizeof(UTextStyle_Button_Primary_L_C) == 0x190, "Size mismatch for UTextStyle_Button_Primary_L_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Primary_L_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Primary_L_C) == 0x710, "Size mismatch for UButtonStyle_Primary_L_C");

// Size: 0x710 (Inherited: 0xe48, Single: 0xfffff8c8)
class UButtonStyle_Lightbox_C : public UButtonStyle_Base_C
{
public:
};

static_assert(sizeof(UButtonStyle_Lightbox_C) == 0x710, "Size mismatch for UButtonStyle_Lightbox_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Primary_M_Skew_Yellow_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Primary_M_Skew_Yellow_C) == 0x710, "Size mismatch for UButtonStyle_Primary_M_Skew_Yellow_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Skew_LessDesirable_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Skew_LessDesirable_C) == 0x710, "Size mismatch for UButtonStyle_Skew_LessDesirable_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Slot_Gadget_S_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Slot_Gadget_S_C) == 0x710, "Size mismatch for UButtonStyle_Slot_Gadget_S_C");

// Size: 0x710 (Inherited: 0x1c68, Single: 0xffffeaa8)
class UButtonStyle_Radial_C : public UButtonStyle_MediumTransparentNoCues_C
{
public:
};

static_assert(sizeof(UButtonStyle_Radial_C) == 0x710, "Size mismatch for UButtonStyle_Radial_C");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UCommonUIRichTextData_C : public UCommonUIRichTextData
{
public:
};

static_assert(sizeof(UCommonUIRichTextData_C) == 0x30, "Size mismatch for UCommonUIRichTextData_C");

// Size: 0x710 (Inherited: 0x738, Single: 0xffffffd8)
class UButtonStyle_Base_C : public UCommonButtonStyle
{
public:
};

static_assert(sizeof(UButtonStyle_Base_C) == 0x710, "Size mismatch for UButtonStyle_Base_C");

// Size: 0x710 (Inherited: 0xe48, Single: 0xfffff8c8)
class UButtonStyle_TextOnlyBase_Empty_C : public UButtonStyle_Base_C
{
public:
};

static_assert(sizeof(UButtonStyle_TextOnlyBase_Empty_C) == 0x710, "Size mismatch for UButtonStyle_TextOnlyBase_Empty_C");

