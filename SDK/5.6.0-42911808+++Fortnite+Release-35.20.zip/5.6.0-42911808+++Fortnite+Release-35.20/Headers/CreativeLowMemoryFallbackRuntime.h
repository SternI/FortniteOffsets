/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeLowMemoryFallbackRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DeveloperSettings.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0x120 (Inherited: 0x58, Single: 0xc8)
class UCreativeLowMemoryFallbackSettings : public UDeveloperSettings
{
public:
    TSoftObjectPtr<UObject*> WarningToastIcon; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    FCreativeLowMemoryFallbackUserFacingText DefaultText; // 0x50 (Size: 0x30, Type: StructProperty)
    TMap<FCreativeLowMemoryFallbackFreeMemoryThresholds, TSoftObjectPtr<UFortPlaylist*>> PlaylistOverrideThresholds; // 0x80 (Size: 0x50, Type: MapProperty)
    TMap<FCreativeLowMemoryFallbackUserFacingText, TSoftObjectPtr<UFortPlaylist*>> PlaylistOverrideText; // 0xd0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UCreativeLowMemoryFallbackSettings) == 0x120, "Size mismatch for UCreativeLowMemoryFallbackSettings");
static_assert(offsetof(UCreativeLowMemoryFallbackSettings, WarningToastIcon) == 0x30, "Offset mismatch for UCreativeLowMemoryFallbackSettings::WarningToastIcon");
static_assert(offsetof(UCreativeLowMemoryFallbackSettings, DefaultText) == 0x50, "Offset mismatch for UCreativeLowMemoryFallbackSettings::DefaultText");
static_assert(offsetof(UCreativeLowMemoryFallbackSettings, PlaylistOverrideThresholds) == 0x80, "Offset mismatch for UCreativeLowMemoryFallbackSettings::PlaylistOverrideThresholds");
static_assert(offsetof(UCreativeLowMemoryFallbackSettings, PlaylistOverrideText) == 0xd0, "Offset mismatch for UCreativeLowMemoryFallbackSettings::PlaylistOverrideText");

// Size: 0x68 (Inherited: 0x88, Single: 0xffffffe0)
class UCreativeLowMemoryFallbackWorldSubsystem : public UWorldSubsystem
{
public:
    FCreativeLowMemoryFallbackFreeMemoryThresholds CurrentThresholds; // 0x30 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_3c[0x2c]; // 0x3c (Size: 0x2c, Type: PaddingProperty)

private:
    void OnPlaylistDataChanged(AFortGameStateAthena*& GameState, UFortPlaylist*& const Playlist, const FGameplayTagContainer PlaylistContextTags); // 0x11ed7924 (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UCreativeLowMemoryFallbackWorldSubsystem) == 0x68, "Size mismatch for UCreativeLowMemoryFallbackWorldSubsystem");
static_assert(offsetof(UCreativeLowMemoryFallbackWorldSubsystem, CurrentThresholds) == 0x30, "Offset mismatch for UCreativeLowMemoryFallbackWorldSubsystem::CurrentThresholds");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FCreativeLowMemoryFallbackUserFacingText
{
    FText ExitToMainMenuReasonText; // 0x0 (Size: 0x10, Type: TextProperty)
    FText WarningToastTitle; // 0x10 (Size: 0x10, Type: TextProperty)
    FText WarningToastDescription; // 0x20 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FCreativeLowMemoryFallbackUserFacingText) == 0x30, "Size mismatch for FCreativeLowMemoryFallbackUserFacingText");
static_assert(offsetof(FCreativeLowMemoryFallbackUserFacingText, ExitToMainMenuReasonText) == 0x0, "Offset mismatch for FCreativeLowMemoryFallbackUserFacingText::ExitToMainMenuReasonText");
static_assert(offsetof(FCreativeLowMemoryFallbackUserFacingText, WarningToastTitle) == 0x10, "Offset mismatch for FCreativeLowMemoryFallbackUserFacingText::WarningToastTitle");
static_assert(offsetof(FCreativeLowMemoryFallbackUserFacingText, WarningToastDescription) == 0x20, "Offset mismatch for FCreativeLowMemoryFallbackUserFacingText::WarningToastDescription");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FCreativeLowMemoryFallbackFreeMemoryThresholds
{
    float FallbackMB; // 0x0 (Size: 0x4, Type: FloatProperty)
    float WarningMB; // 0x4 (Size: 0x4, Type: FloatProperty)
    float RecoveryMB; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FCreativeLowMemoryFallbackFreeMemoryThresholds) == 0xc, "Size mismatch for FCreativeLowMemoryFallbackFreeMemoryThresholds");
static_assert(offsetof(FCreativeLowMemoryFallbackFreeMemoryThresholds, FallbackMB) == 0x0, "Offset mismatch for FCreativeLowMemoryFallbackFreeMemoryThresholds::FallbackMB");
static_assert(offsetof(FCreativeLowMemoryFallbackFreeMemoryThresholds, WarningMB) == 0x4, "Offset mismatch for FCreativeLowMemoryFallbackFreeMemoryThresholds::WarningMB");
static_assert(offsetof(FCreativeLowMemoryFallbackFreeMemoryThresholds, RecoveryMB) == 0x8, "Offset mismatch for FCreativeLowMemoryFallbackFreeMemoryThresholds::RecoveryMB");

