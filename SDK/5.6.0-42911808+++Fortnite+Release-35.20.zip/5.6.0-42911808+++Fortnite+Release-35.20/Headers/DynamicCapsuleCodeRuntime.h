/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicCapsuleCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "Engine.h"
#include "GameplayTags.h"

// Size: 0x110 (Inherited: 0x310, Single: 0xfffffe00)
class UDynamicCapsuleComponent : public UFortPawnComponent
{
public:
    TArray<FDynamicCapsuleEntry> DynamicCapsuleEntryStack; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    FDynamicCapsuleState ReplicatedCapsuleState; // 0xd0 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_e0[0x30]; // 0xe0 (Size: 0x30, Type: PaddingProperty)

public:
    bool ApplyDynamicCapsule(const FGameplayTag Tag, float& CapsuleRadius, float& CapsuleHalfHeight); // 0x113432e8 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    bool ApplyDynamicCapsuleWithLocationAdjust(const FGameplayTag Tag, float& CapsuleRadius, float& CapsuleHalfHeight, double& NewRelativeMeshHeight); // 0x113434f8 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    bool RemoveDynamicCapsule(const FGameplayTag Tag); // 0x113437b8 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)

private:
    void OnRep_DynamicCapsuleEntryStack(); // 0x113437a4 (Index: 0x2, Flags: Final|Native|Private)
    void OnRep_ReplicatedCapsuleState(); // 0x4a3f814 (Index: 0x3, Flags: Final|Native|Private)
    virtual void ServerApplyDynamicCapsule(FGameplayTag& const Tag, float& CapsuleRadius, float& CapsuleHalfHeight, double& NewRelativeMeshHeight); // 0x113438ac (Index: 0x5, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
    virtual void ServerRemoveDynamicCapsule(FGameplayTag& const Tag); // 0x11343ac8 (Index: 0x6, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
};

static_assert(sizeof(UDynamicCapsuleComponent) == 0x110, "Size mismatch for UDynamicCapsuleComponent");
static_assert(offsetof(UDynamicCapsuleComponent, DynamicCapsuleEntryStack) == 0xc0, "Offset mismatch for UDynamicCapsuleComponent::DynamicCapsuleEntryStack");
static_assert(offsetof(UDynamicCapsuleComponent, ReplicatedCapsuleState) == 0xd0, "Offset mismatch for UDynamicCapsuleComponent::ReplicatedCapsuleState");

// Size: 0x48 (Inherited: 0x58, Single: 0xfffffff0)
class UAnimNotifyState_SetCapsuleSize : public UAnimNotifyState
{
public:
    float TargetCapsuleRadius; // 0x30 (Size: 0x4, Type: FloatProperty)
    float TargetCapsuleHalfHeight; // 0x34 (Size: 0x4, Type: FloatProperty)
    bool bAdjustRelativeMeshHeight; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    float TargetRelativeMeshHeight; // 0x3c (Size: 0x4, Type: FloatProperty)
    FGameplayTag CapsuleSizeTag; // 0x40 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UAnimNotifyState_SetCapsuleSize) == 0x48, "Size mismatch for UAnimNotifyState_SetCapsuleSize");
static_assert(offsetof(UAnimNotifyState_SetCapsuleSize, TargetCapsuleRadius) == 0x30, "Offset mismatch for UAnimNotifyState_SetCapsuleSize::TargetCapsuleRadius");
static_assert(offsetof(UAnimNotifyState_SetCapsuleSize, TargetCapsuleHalfHeight) == 0x34, "Offset mismatch for UAnimNotifyState_SetCapsuleSize::TargetCapsuleHalfHeight");
static_assert(offsetof(UAnimNotifyState_SetCapsuleSize, bAdjustRelativeMeshHeight) == 0x38, "Offset mismatch for UAnimNotifyState_SetCapsuleSize::bAdjustRelativeMeshHeight");
static_assert(offsetof(UAnimNotifyState_SetCapsuleSize, TargetRelativeMeshHeight) == 0x3c, "Offset mismatch for UAnimNotifyState_SetCapsuleSize::TargetRelativeMeshHeight");
static_assert(offsetof(UAnimNotifyState_SetCapsuleSize, CapsuleSizeTag) == 0x40, "Offset mismatch for UAnimNotifyState_SetCapsuleSize::CapsuleSizeTag");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDynamicCapsuleState
{
    float CapsuleRadius; // 0x0 (Size: 0x4, Type: FloatProperty)
    float CapsuleHalfHeight; // 0x4 (Size: 0x4, Type: FloatProperty)
    double RelativeMeshHeight; // 0x8 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FDynamicCapsuleState) == 0x10, "Size mismatch for FDynamicCapsuleState");
static_assert(offsetof(FDynamicCapsuleState, CapsuleRadius) == 0x0, "Offset mismatch for FDynamicCapsuleState::CapsuleRadius");
static_assert(offsetof(FDynamicCapsuleState, CapsuleHalfHeight) == 0x4, "Offset mismatch for FDynamicCapsuleState::CapsuleHalfHeight");
static_assert(offsetof(FDynamicCapsuleState, RelativeMeshHeight) == 0x8, "Offset mismatch for FDynamicCapsuleState::RelativeMeshHeight");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDynamicCapsuleEntry
{
    FGameplayTag Tag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FDynamicCapsuleState State; // 0x8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FDynamicCapsuleEntry) == 0x18, "Size mismatch for FDynamicCapsuleEntry");
static_assert(offsetof(FDynamicCapsuleEntry, Tag) == 0x0, "Offset mismatch for FDynamicCapsuleEntry::Tag");
static_assert(offsetof(FDynamicCapsuleEntry, State) == 0x8, "Offset mismatch for FDynamicCapsuleEntry::State");

