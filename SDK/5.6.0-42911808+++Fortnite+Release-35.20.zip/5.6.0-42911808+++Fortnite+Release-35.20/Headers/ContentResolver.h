/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ContentResolver
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0xa8 (Inherited: 0x28, Single: 0x80)
class UPluginBatchLoaderHelper : public UObject
{
public:
};

static_assert(sizeof(UPluginBatchLoaderHelper) == 0xa8, "Size mismatch for UPluginBatchLoaderHelper");

// Size: 0x48 (Inherited: 0xb8, Single: 0xffffff90)
class UExternalContentLoader : public UEngineSubsystem
{
public:
};

static_assert(sizeof(UExternalContentLoader) == 0x48, "Size mismatch for UExternalContentLoader");

