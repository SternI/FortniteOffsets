/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CoreUObject
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Basic.h"

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
class UObject
{
public:
    void** VTable; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName NamePrivate; // 0x8 (Size: 0x4, Type: NameProperty)
    int32_t InternalIndex; // 0xc (Size: 0x4, Type: IntProperty)
    UObject* OuterPrivate; // 0x10 (Size: 0x8, Type: ObjectProperty)
    EObjectFlags ObjectFlags; // 0x18 (Size: 0x4, Type: EnumProperty)
    int32_t ObjectListInternalIndex; // 0x1c (Size: 0x4, Type: IntProperty)
    UClass* ClassPrivate; // 0x20 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void ExecuteUbergraph(int32_t& EntryPoint); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UObject) == 0x28, "Size mismatch for UObject");
static_assert(offsetof(UObject, VTable) == 0x0, "Offset mismatch for UObject::VTable");
static_assert(offsetof(UObject, NamePrivate) == 0x8, "Offset mismatch for UObject::NamePrivate");
static_assert(offsetof(UObject, InternalIndex) == 0xc, "Offset mismatch for UObject::InternalIndex");
static_assert(offsetof(UObject, OuterPrivate) == 0x10, "Offset mismatch for UObject::OuterPrivate");
static_assert(offsetof(UObject, ObjectFlags) == 0x18, "Offset mismatch for UObject::ObjectFlags");
static_assert(offsetof(UObject, ObjectListInternalIndex) == 0x1c, "Offset mismatch for UObject::ObjectListInternalIndex");
static_assert(offsetof(UObject, ClassPrivate) == 0x20, "Offset mismatch for UObject::ClassPrivate");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UInterface : public UObject
{
public:
};

static_assert(sizeof(UInterface) == 0x28, "Size mismatch for UInterface");

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
class UOptionalPropertyTestObject : public UObject
{
public:
    uint8_t OptionalString[0x10]; // 0x28 (Size: 0x10, Type: OptionalProperty)
    uint8_t OptionalText[0x10]; // 0x38 (Size: 0x10, Type: OptionalProperty)
    uint8_t OptionalName[0x4]; // 0x48 (Size: 0x4, Type: OptionalProperty)
    uint8_t OptionalInt[0x8]; // 0x4c (Size: 0x8, Type: OptionalProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UOptionalPropertyTestObject) == 0x58, "Size mismatch for UOptionalPropertyTestObject");
static_assert(offsetof(UOptionalPropertyTestObject, OptionalString) == 0x28, "Offset mismatch for UOptionalPropertyTestObject::OptionalString");
static_assert(offsetof(UOptionalPropertyTestObject, OptionalText) == 0x38, "Offset mismatch for UOptionalPropertyTestObject::OptionalText");
static_assert(offsetof(UOptionalPropertyTestObject, OptionalName) == 0x48, "Offset mismatch for UOptionalPropertyTestObject::OptionalName");
static_assert(offsetof(UOptionalPropertyTestObject, OptionalInt) == 0x4c, "Offset mismatch for UOptionalPropertyTestObject::OptionalInt");

// Size: 0x8c0 (Inherited: 0x28, Single: 0x898)
class UTestPropertyPathFunctionsClass : public UObject
{
public:
    FTestPropertyPathFunctionsStruct StructStaticArray[0x8]; // 0x28 (Size: 0x700, Type: StructProperty)
    TArray<FTestPropertyPathFunctionsStruct> StructArray; // 0x728 (Size: 0x10, Type: ArrayProperty)
    TSet<FTestPropertyPathFunctionsStructKey> StructSet; // 0x738 (Size: 0x50, Type: SetProperty)
    TMap<FTestPropertyPathFunctionsStruct, FTestPropertyPathFunctionsStructKey> StructMap; // 0x788 (Size: 0x50, Type: MapProperty)
    uint8_t StructOptional[0xe8]; // 0x7d8 (Size: 0xe8, Type: OptionalProperty)
};

static_assert(sizeof(UTestPropertyPathFunctionsClass) == 0x8c0, "Size mismatch for UTestPropertyPathFunctionsClass");
static_assert(offsetof(UTestPropertyPathFunctionsClass, StructStaticArray) == 0x28, "Offset mismatch for UTestPropertyPathFunctionsClass::StructStaticArray");
static_assert(offsetof(UTestPropertyPathFunctionsClass, StructArray) == 0x728, "Offset mismatch for UTestPropertyPathFunctionsClass::StructArray");
static_assert(offsetof(UTestPropertyPathFunctionsClass, StructSet) == 0x738, "Offset mismatch for UTestPropertyPathFunctionsClass::StructSet");
static_assert(offsetof(UTestPropertyPathFunctionsClass, StructMap) == 0x788, "Offset mismatch for UTestPropertyPathFunctionsClass::StructMap");
static_assert(offsetof(UTestPropertyPathFunctionsClass, StructOptional) == 0x7d8, "Offset mismatch for UTestPropertyPathFunctionsClass::StructOptional");

// Size: 0x80 (Inherited: 0x28, Single: 0x58)
class UTestInstanceDataObjectClass : public UObject
{
public:
    int32_t A[0x4]; // 0x28 (Size: 0x10, Type: IntProperty)
    float B; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    int64_t C; // 0x40 (Size: 0x8, Type: Int64Property)
    int32_t D; // 0x48 (Size: 0x4, Type: IntProperty)
    int32_t E; // 0x4c (Size: 0x4, Type: IntProperty)
    FTestInstanceDataObjectStruct Struct; // 0x50 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(UTestInstanceDataObjectClass) == 0x80, "Size mismatch for UTestInstanceDataObjectClass");
static_assert(offsetof(UTestInstanceDataObjectClass, A) == 0x28, "Offset mismatch for UTestInstanceDataObjectClass::A");
static_assert(offsetof(UTestInstanceDataObjectClass, B) == 0x38, "Offset mismatch for UTestInstanceDataObjectClass::B");
static_assert(offsetof(UTestInstanceDataObjectClass, C) == 0x40, "Offset mismatch for UTestInstanceDataObjectClass::C");
static_assert(offsetof(UTestInstanceDataObjectClass, D) == 0x48, "Offset mismatch for UTestInstanceDataObjectClass::D");
static_assert(offsetof(UTestInstanceDataObjectClass, E) == 0x4c, "Offset mismatch for UTestInstanceDataObjectClass::E");
static_assert(offsetof(UTestInstanceDataObjectClass, Struct) == 0x50, "Offset mismatch for UTestInstanceDataObjectClass::Struct");

// Size: 0x108 (Inherited: 0x1d0, Single: 0xffffff38)
class UUserDefinedStruct : public UScriptStruct
{
public:
    TEnumAsByte<EUserDefinedStructureStatus> Status; // 0xc0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_c1[0x3]; // 0xc1 (Size: 0x3, Type: PaddingProperty)
    FGuid Guid; // 0xc4 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_d4[0x34]; // 0xd4 (Size: 0x34, Type: PaddingProperty)
};

static_assert(sizeof(UUserDefinedStruct) == 0x108, "Size mismatch for UUserDefinedStruct");
static_assert(offsetof(UUserDefinedStruct, Status) == 0xc0, "Offset mismatch for UUserDefinedStruct::Status");
static_assert(offsetof(UUserDefinedStruct, Guid) == 0xc4, "Offset mismatch for UUserDefinedStruct::Guid");

// Size: 0xc0 (Inherited: 0x110, Single: 0xffffffb0)
class UScriptStruct : public UStruct
{
public:
};

static_assert(sizeof(UScriptStruct) == 0xc0, "Size mismatch for UScriptStruct");

// Size: 0xb0 (Inherited: 0x58, Single: 0x58)
class UStruct : public UField
{
public:
    uint8_t Pad_30[0x10]; // 0x30 (Size: 0x10, Type: PaddingProperty)
    UStruct* SuperStruct; // 0x40 (Size: 0x8, Type: ObjectProperty)
    FField* ChildProperties; // 0x48 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_50[0x60]; // 0x50 (Size: 0x60, Type: PaddingProperty)
};

static_assert(sizeof(UStruct) == 0xb0, "Size mismatch for UStruct");
static_assert(offsetof(UStruct, SuperStruct) == 0x40, "Offset mismatch for UStruct::SuperStruct");
static_assert(offsetof(UStruct, ChildProperties) == 0x48, "Offset mismatch for UStruct::ChildProperties");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UField : public UObject
{
public:
    UField* Next; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UField) == 0x30, "Size mismatch for UField");
static_assert(offsetof(UField, Next) == 0x28, "Offset mismatch for UField::Next");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UUserDefinedStructEditorDataBase : public UObject
{
public:
};

static_assert(sizeof(UUserDefinedStructEditorDataBase) == 0x28, "Size mismatch for UUserDefinedStructEditorDataBase");

// Size: 0x78 (Inherited: 0xb8, Single: 0xffffffc0)
class UVerseEnum : public UEnum
{
public:
    uint8_t VerseEnumFlags[0x4]; // 0x60 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_64[0x4]; // 0x64 (Size: 0x4, Type: PaddingProperty)
    uint8_t QualifiedName[0x10]; // 0x68 (Size: 0x10, Type: Utf8StrProperty)
};

static_assert(sizeof(UVerseEnum) == 0x78, "Size mismatch for UVerseEnum");
static_assert(offsetof(UVerseEnum, VerseEnumFlags) == 0x60, "Offset mismatch for UVerseEnum::VerseEnumFlags");
static_assert(offsetof(UVerseEnum, QualifiedName) == 0x68, "Offset mismatch for UVerseEnum::QualifiedName");

// Size: 0x60 (Inherited: 0x58, Single: 0x8)
class UEnum : public UField
{
public:
};

static_assert(sizeof(UEnum) == 0x60, "Size mismatch for UEnum");

// Size: 0xe0 (Inherited: 0x1e8, Single: 0xfffffef8)
class UVerseFunction : public UFunction
{
public:
};

static_assert(sizeof(UVerseFunction) == 0xe0, "Size mismatch for UVerseFunction");

// Size: 0x208 (Inherited: 0x110, Single: 0xf8)
class UClass : public UStruct
{
public:
};

static_assert(sizeof(UClass) == 0x208, "Size mismatch for UClass");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UPackage : public UObject
{
public:
};

static_assert(sizeof(UPackage) == 0x48, "Size mismatch for UPackage");

// Size: 0xe0 (Inherited: 0x110, Single: 0xffffffd0)
class UFunction : public UStruct
{
public:
    uint8_t Pad_b8[0xc]; // 0xb8 (Size: 0xc, Type: PaddingProperty)
    EFunctionFlags FunctionFlags; // 0xc4 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_c8[0x10]; // 0xc8 (Size: 0x10, Type: PaddingProperty)
    void* Func; // 0xd8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFunction) == 0xe0, "Size mismatch for UFunction");
static_assert(offsetof(UFunction, FunctionFlags) == 0xc4, "Offset mismatch for UFunction::FunctionFlags");
static_assert(offsetof(UFunction, Func) == 0xd8, "Offset mismatch for UFunction::Func");

// Size: 0x110 (Inherited: 0x1d0, Single: 0xffffff40)
class UVerseStruct : public UScriptStruct
{
public:
    uint32_t VerseClassFlags; // 0xc0 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_c4[0x4]; // 0xc4 (Size: 0x4, Type: PaddingProperty)
    uint8_t QualifiedName[0x10]; // 0xc8 (Size: 0x10, Type: Utf8StrProperty)
    UFunction* InitFunction; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UVerseClass* ModuleClass; // 0xe0 (Size: 0x8, Type: ClassProperty)
    FGuid Guid; // 0xe8 (Size: 0x10, Type: StructProperty)
    UFunction* FactoryFunction; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    UFunction* OverrideFactoryFunction; // 0x100 (Size: 0x8, Type: ObjectProperty)
    uint8_t ConstructorEffects; // 0x108 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_109[0x7]; // 0x109 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UVerseStruct) == 0x110, "Size mismatch for UVerseStruct");
static_assert(offsetof(UVerseStruct, VerseClassFlags) == 0xc0, "Offset mismatch for UVerseStruct::VerseClassFlags");
static_assert(offsetof(UVerseStruct, QualifiedName) == 0xc8, "Offset mismatch for UVerseStruct::QualifiedName");
static_assert(offsetof(UVerseStruct, InitFunction) == 0xd8, "Offset mismatch for UVerseStruct::InitFunction");
static_assert(offsetof(UVerseStruct, ModuleClass) == 0xe0, "Offset mismatch for UVerseStruct::ModuleClass");
static_assert(offsetof(UVerseStruct, Guid) == 0xe8, "Offset mismatch for UVerseStruct::Guid");
static_assert(offsetof(UVerseStruct, FactoryFunction) == 0xf8, "Offset mismatch for UVerseStruct::FactoryFunction");
static_assert(offsetof(UVerseStruct, OverrideFactoryFunction) == 0x100, "Offset mismatch for UVerseStruct::OverrideFactoryFunction");
static_assert(offsetof(UVerseStruct, ConstructorEffects) == 0x108, "Offset mismatch for UVerseStruct::ConstructorEffects");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEditorPathObjectInterface : public UInterface
{
public:
};

static_assert(sizeof(UEditorPathObjectInterface) == 0x28, "Size mismatch for UEditorPathObjectInterface");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UGCObjectReferencer : public UObject
{
public:
};

static_assert(sizeof(UGCObjectReferencer) == 0x38, "Size mismatch for UGCObjectReferencer");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UTextBuffer : public UObject
{
public:
};

static_assert(sizeof(UTextBuffer) == 0x50, "Size mismatch for UTextBuffer");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UPropertyBagMissingObject : public UObject
{
public:
};

static_assert(sizeof(UPropertyBagMissingObject) == 0x28, "Size mismatch for UPropertyBagMissingObject");

// Size: 0xd8 (Inherited: 0x1d0, Single: 0xffffff08)
class UPropertyBag : public UScriptStruct
{
public:
    TArray<FPropertyBagPropertyDesc> PropertyDescs; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_d0[0x8]; // 0xd0 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UPropertyBag) == 0xd8, "Size mismatch for UPropertyBag");
static_assert(offsetof(UPropertyBag, PropertyDescs) == 0xc0, "Offset mismatch for UPropertyBag::PropertyDescs");

// Size: 0xe0 (Inherited: 0x1e8, Single: 0xfffffef8)
class UDelegateFunction : public UFunction
{
public:
};

static_assert(sizeof(UDelegateFunction) == 0xe0, "Size mismatch for UDelegateFunction");

// Size: 0xe8 (Inherited: 0x2c8, Single: 0xfffffe20)
class USparseDelegateFunction : public UDelegateFunction
{
public:
};

static_assert(sizeof(USparseDelegateFunction) == 0xe8, "Size mismatch for USparseDelegateFunction");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UEnumCookedMetaData : public UObject
{
public:
    FObjectCookedMetaDataStore EnumMetaData; // 0x28 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(UEnumCookedMetaData) == 0x78, "Size mismatch for UEnumCookedMetaData");
static_assert(offsetof(UEnumCookedMetaData, EnumMetaData) == 0x28, "Offset mismatch for UEnumCookedMetaData::EnumMetaData");

// Size: 0xc8 (Inherited: 0x28, Single: 0xa0)
class UStructCookedMetaData : public UObject
{
public:
    FStructCookedMetaDataStore StructMetaData; // 0x28 (Size: 0xa0, Type: StructProperty)
};

static_assert(sizeof(UStructCookedMetaData) == 0xc8, "Size mismatch for UStructCookedMetaData");
static_assert(offsetof(UStructCookedMetaData, StructMetaData) == 0x28, "Offset mismatch for UStructCookedMetaData::StructMetaData");

// Size: 0x118 (Inherited: 0x28, Single: 0xf0)
class UClassCookedMetaData : public UObject
{
public:
    FStructCookedMetaDataStore ClassMetaData; // 0x28 (Size: 0xa0, Type: StructProperty)
    TMap<FStructCookedMetaDataStore, FName> FunctionsMetaData; // 0xc8 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UClassCookedMetaData) == 0x118, "Size mismatch for UClassCookedMetaData");
static_assert(offsetof(UClassCookedMetaData, ClassMetaData) == 0x28, "Offset mismatch for UClassCookedMetaData::ClassMetaData");
static_assert(offsetof(UClassCookedMetaData, FunctionsMetaData) == 0xc8, "Offset mismatch for UClassCookedMetaData::FunctionsMetaData");

// Size: 0xe0 (Inherited: 0x28, Single: 0xb8)
class UPackageMap : public UObject
{
public:
};

static_assert(sizeof(UPackageMap) == 0xe0, "Size mismatch for UPackageMap");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UObjectReachabilityStressData : public UObject
{
public:
};

static_assert(sizeof(UObjectReachabilityStressData) == 0x38, "Size mismatch for UObjectReachabilityStressData");

// Size: 0x3c8 (Inherited: 0x318, Single: 0xb0)
class ULinkerPlaceholderClass : public UClass
{
public:
};

static_assert(sizeof(ULinkerPlaceholderClass) == 0x3c8, "Size mismatch for ULinkerPlaceholderClass");

// Size: 0xf8 (Inherited: 0x28, Single: 0xd0)
class ULinkerPlaceholderExportObject : public UObject
{
public:
};

static_assert(sizeof(ULinkerPlaceholderExportObject) == 0xf8, "Size mismatch for ULinkerPlaceholderExportObject");

// Size: 0x2a0 (Inherited: 0x1e8, Single: 0xb8)
class ULinkerPlaceholderFunction : public UFunction
{
public:
};

static_assert(sizeof(ULinkerPlaceholderFunction) == 0x2a0, "Size mismatch for ULinkerPlaceholderFunction");

// Size: 0xc8 (Inherited: 0x28, Single: 0xa0)
class UMetaData : public UObject
{
public:
};

static_assert(sizeof(UMetaData) == 0xc8, "Size mismatch for UMetaData");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UObjectRedirector : public UObject
{
public:
};

static_assert(sizeof(UObjectRedirector) == 0x30, "Size mismatch for UObjectRedirector");

// Size: 0x70 (Inherited: 0x58, Single: 0x18)
class UProperty : public UField
{
public:
};

static_assert(sizeof(UProperty) == 0x70, "Size mismatch for UProperty");

// Size: 0x80 (Inherited: 0xc8, Single: 0xffffffb8)
class UEnumProperty : public UProperty
{
public:
};

static_assert(sizeof(UEnumProperty) == 0x80, "Size mismatch for UEnumProperty");

// Size: 0x78 (Inherited: 0xc8, Single: 0xffffffb0)
class UArrayProperty : public UProperty
{
public:
};

static_assert(sizeof(UArrayProperty) == 0x78, "Size mismatch for UArrayProperty");

// Size: 0x78 (Inherited: 0xc8, Single: 0xffffffb0)
class UObjectPropertyBase : public UProperty
{
public:
};

static_assert(sizeof(UObjectPropertyBase) == 0x78, "Size mismatch for UObjectPropertyBase");

// Size: 0x78 (Inherited: 0xc8, Single: 0xffffffb0)
class UBoolProperty : public UProperty
{
public:
};

static_assert(sizeof(UBoolProperty) == 0x78, "Size mismatch for UBoolProperty");

// Size: 0x78 (Inherited: 0x138, Single: 0xffffff40)
class UByteProperty : public UNumericProperty
{
public:
};

static_assert(sizeof(UByteProperty) == 0x78, "Size mismatch for UByteProperty");

// Size: 0x70 (Inherited: 0xc8, Single: 0xffffffa8)
class UNumericProperty : public UProperty
{
public:
};

static_assert(sizeof(UNumericProperty) == 0x70, "Size mismatch for UNumericProperty");

// Size: 0x80 (Inherited: 0x1b8, Single: 0xfffffec8)
class UClassProperty : public UObjectProperty
{
public:
};

static_assert(sizeof(UClassProperty) == 0x80, "Size mismatch for UClassProperty");

// Size: 0x78 (Inherited: 0x140, Single: 0xffffff38)
class UObjectProperty : public UObjectPropertyBase
{
public:
};

static_assert(sizeof(UObjectProperty) == 0x78, "Size mismatch for UObjectProperty");

// Size: 0x78 (Inherited: 0xc8, Single: 0xffffffb0)
class UDelegateProperty : public UProperty
{
public:
};

static_assert(sizeof(UDelegateProperty) == 0x78, "Size mismatch for UDelegateProperty");

// Size: 0x70 (Inherited: 0x138, Single: 0xffffff38)
class UDoubleProperty : public UNumericProperty
{
public:
};

static_assert(sizeof(UDoubleProperty) == 0x70, "Size mismatch for UDoubleProperty");

// Size: 0x70 (Inherited: 0x138, Single: 0xffffff38)
class UFloatProperty : public UNumericProperty
{
public:
};

static_assert(sizeof(UFloatProperty) == 0x70, "Size mismatch for UFloatProperty");

// Size: 0x70 (Inherited: 0x138, Single: 0xffffff38)
class UIntProperty : public UNumericProperty
{
public:
};

static_assert(sizeof(UIntProperty) == 0x70, "Size mismatch for UIntProperty");

// Size: 0x70 (Inherited: 0x138, Single: 0xffffff38)
class UInt8Property : public UNumericProperty
{
public:
};

static_assert(sizeof(UInt8Property) == 0x70, "Size mismatch for UInt8Property");

// Size: 0x70 (Inherited: 0x138, Single: 0xffffff38)
class UInt16Property : public UNumericProperty
{
public:
};

static_assert(sizeof(UInt16Property) == 0x70, "Size mismatch for UInt16Property");

// Size: 0x70 (Inherited: 0x138, Single: 0xffffff38)
class UInt64Property : public UNumericProperty
{
public:
};

static_assert(sizeof(UInt64Property) == 0x70, "Size mismatch for UInt64Property");

// Size: 0x78 (Inherited: 0xc8, Single: 0xffffffb0)
class UInterfaceProperty : public UProperty
{
public:
};

static_assert(sizeof(UInterfaceProperty) == 0x78, "Size mismatch for UInterfaceProperty");

// Size: 0x78 (Inherited: 0x140, Single: 0xffffff38)
class ULazyObjectProperty : public UObjectPropertyBase
{
public:
};

static_assert(sizeof(ULazyObjectProperty) == 0x78, "Size mismatch for ULazyObjectProperty");

// Size: 0x98 (Inherited: 0xc8, Single: 0xffffffd0)
class UMapProperty : public UProperty
{
public:
};

static_assert(sizeof(UMapProperty) == 0x98, "Size mismatch for UMapProperty");

// Size: 0x78 (Inherited: 0xc8, Single: 0xffffffb0)
class UMulticastDelegateProperty : public UProperty
{
public:
};

static_assert(sizeof(UMulticastDelegateProperty) == 0x78, "Size mismatch for UMulticastDelegateProperty");

// Size: 0x78 (Inherited: 0x140, Single: 0xffffff38)
class UMulticastInlineDelegateProperty : public UMulticastDelegateProperty
{
public:
};

static_assert(sizeof(UMulticastInlineDelegateProperty) == 0x78, "Size mismatch for UMulticastInlineDelegateProperty");

// Size: 0x78 (Inherited: 0x140, Single: 0xffffff38)
class UMulticastSparseDelegateProperty : public UMulticastDelegateProperty
{
public:
};

static_assert(sizeof(UMulticastSparseDelegateProperty) == 0x78, "Size mismatch for UMulticastSparseDelegateProperty");

// Size: 0x70 (Inherited: 0xc8, Single: 0xffffffa8)
class UNameProperty : public UProperty
{
public:
};

static_assert(sizeof(UNameProperty) == 0x70, "Size mismatch for UNameProperty");

// Size: 0x90 (Inherited: 0xc8, Single: 0xffffffc8)
class USetProperty : public UProperty
{
public:
};

static_assert(sizeof(USetProperty) == 0x90, "Size mismatch for USetProperty");

// Size: 0x80 (Inherited: 0x1b8, Single: 0xfffffec8)
class USoftClassProperty : public USoftObjectProperty
{
public:
};

static_assert(sizeof(USoftClassProperty) == 0x80, "Size mismatch for USoftClassProperty");

// Size: 0x78 (Inherited: 0x140, Single: 0xffffff38)
class USoftObjectProperty : public UObjectPropertyBase
{
public:
};

static_assert(sizeof(USoftObjectProperty) == 0x78, "Size mismatch for USoftObjectProperty");

// Size: 0x70 (Inherited: 0xc8, Single: 0xffffffa8)
class UStrProperty : public UProperty
{
public:
};

static_assert(sizeof(UStrProperty) == 0x70, "Size mismatch for UStrProperty");

// Size: 0x78 (Inherited: 0xc8, Single: 0xffffffb0)
class UStructProperty : public UProperty
{
public:
};

static_assert(sizeof(UStructProperty) == 0x78, "Size mismatch for UStructProperty");

// Size: 0x70 (Inherited: 0x138, Single: 0xffffff38)
class UUInt16Property : public UNumericProperty
{
public:
};

static_assert(sizeof(UUInt16Property) == 0x70, "Size mismatch for UUInt16Property");

// Size: 0x70 (Inherited: 0x138, Single: 0xffffff38)
class UUInt32Property : public UNumericProperty
{
public:
};

static_assert(sizeof(UUInt32Property) == 0x70, "Size mismatch for UUInt32Property");

// Size: 0x70 (Inherited: 0x138, Single: 0xffffff38)
class UUInt64Property : public UNumericProperty
{
public:
};

static_assert(sizeof(UUInt64Property) == 0x70, "Size mismatch for UUInt64Property");

// Size: 0x78 (Inherited: 0x140, Single: 0xffffff38)
class UWeakObjectProperty : public UObjectPropertyBase
{
public:
};

static_assert(sizeof(UWeakObjectProperty) == 0x78, "Size mismatch for UWeakObjectProperty");

// Size: 0x70 (Inherited: 0xc8, Single: 0xffffffa8)
class UTextProperty : public UProperty
{
public:
};

static_assert(sizeof(UTextProperty) == 0x70, "Size mismatch for UTextProperty");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UPropertyWrapper : public UObject
{
public:
};

static_assert(sizeof(UPropertyWrapper) == 0x30, "Size mismatch for UPropertyWrapper");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UMulticastDelegatePropertyWrapper : public UPropertyWrapper
{
public:
};

static_assert(sizeof(UMulticastDelegatePropertyWrapper) == 0x30, "Size mismatch for UMulticastDelegatePropertyWrapper");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UMulticastInlineDelegatePropertyWrapper : public UMulticastDelegatePropertyWrapper
{
public:
};

static_assert(sizeof(UMulticastInlineDelegatePropertyWrapper) == 0x30, "Size mismatch for UMulticastInlineDelegatePropertyWrapper");

// Size: 0x378 (Inherited: 0x318, Single: 0x60)
class UVerseClass : public UClass
{
public:
    uint32_t SolClassFlags; // 0x208 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_20c[0x4]; // 0x20c (Size: 0x4, Type: PaddingProperty)
    TArray<UVerseClass*> TaskClasses; // 0x210 (Size: 0x10, Type: ArrayProperty)
    UFunction* InitInstanceFunction; // 0x220 (Size: 0x8, Type: ObjectProperty)
    TArray<FVersePersistentVar> PersistentVars; // 0x228 (Size: 0x10, Type: ArrayProperty)
    TArray<FVerseSessionVar> SessionVars; // 0x238 (Size: 0x10, Type: ArrayProperty)
    TMap<FVerseClassVarAccessors, FName> VarAccessors; // 0x248 (Size: 0x50, Type: MapProperty)
    uint8_t ConstructorEffects; // 0x298 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_299[0x3]; // 0x299 (Size: 0x3, Type: PaddingProperty)
    FName MangledPackageVersePath; // 0x29c (Size: 0x4, Type: NameProperty)
    FString PackageRelativeVersePath; // 0x2a0 (Size: 0x10, Type: StrProperty)
    TMap<FName, FName> DisplayNameToUENameFunctionMap; // 0x2b0 (Size: 0x50, Type: MapProperty)
    TArray<UVerseClass*> DirectInterfaces; // 0x300 (Size: 0x10, Type: ArrayProperty)
    TArray<TFieldPath> PropertiesWrittenByInitCDO; // 0x310 (Size: 0x10, Type: ArrayProperty)
    TMap<FName, FName> FunctionMangledNames; // 0x320 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_370[0x8]; // 0x370 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UVerseClass) == 0x378, "Size mismatch for UVerseClass");
static_assert(offsetof(UVerseClass, SolClassFlags) == 0x208, "Offset mismatch for UVerseClass::SolClassFlags");
static_assert(offsetof(UVerseClass, TaskClasses) == 0x210, "Offset mismatch for UVerseClass::TaskClasses");
static_assert(offsetof(UVerseClass, InitInstanceFunction) == 0x220, "Offset mismatch for UVerseClass::InitInstanceFunction");
static_assert(offsetof(UVerseClass, PersistentVars) == 0x228, "Offset mismatch for UVerseClass::PersistentVars");
static_assert(offsetof(UVerseClass, SessionVars) == 0x238, "Offset mismatch for UVerseClass::SessionVars");
static_assert(offsetof(UVerseClass, VarAccessors) == 0x248, "Offset mismatch for UVerseClass::VarAccessors");
static_assert(offsetof(UVerseClass, ConstructorEffects) == 0x298, "Offset mismatch for UVerseClass::ConstructorEffects");
static_assert(offsetof(UVerseClass, MangledPackageVersePath) == 0x29c, "Offset mismatch for UVerseClass::MangledPackageVersePath");
static_assert(offsetof(UVerseClass, PackageRelativeVersePath) == 0x2a0, "Offset mismatch for UVerseClass::PackageRelativeVersePath");
static_assert(offsetof(UVerseClass, DisplayNameToUENameFunctionMap) == 0x2b0, "Offset mismatch for UVerseClass::DisplayNameToUENameFunctionMap");
static_assert(offsetof(UVerseClass, DirectInterfaces) == 0x300, "Offset mismatch for UVerseClass::DirectInterfaces");
static_assert(offsetof(UVerseClass, PropertiesWrittenByInitCDO) == 0x310, "Offset mismatch for UVerseClass::PropertiesWrittenByInitCDO");
static_assert(offsetof(UVerseClass, FunctionMangledNames) == 0x320, "Offset mismatch for UVerseClass::FunctionMangledNames");

// Size: 0x150 (Inherited: 0x0, Single: 0x150)
struct FARFilter
{
    TArray<FName> PackageNames; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> PackagePaths; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FSoftObjectPath> SoftObjectPaths; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> ClassNames; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FTopLevelAssetPath> ClassPaths; // 0x40 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_50[0x50]; // 0x50 (Size: 0x50, Type: PaddingProperty)
    TSet<FName> RecursiveClassesExclusionSet; // 0xa0 (Size: 0x50, Type: SetProperty)
    TSet<FTopLevelAssetPath> RecursiveClassPathsExclusionSet; // 0xf0 (Size: 0x50, Type: SetProperty)
    bool bRecursivePaths; // 0x140 (Size: 0x1, Type: BoolProperty)
    bool bRecursiveClasses; // 0x141 (Size: 0x1, Type: BoolProperty)
    bool bIncludeOnlyOnDiskAssets; // 0x142 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_143[0xd]; // 0x143 (Size: 0xd, Type: PaddingProperty)
};

static_assert(sizeof(FARFilter) == 0x150, "Size mismatch for FARFilter");
static_assert(offsetof(FARFilter, PackageNames) == 0x0, "Offset mismatch for FARFilter::PackageNames");
static_assert(offsetof(FARFilter, PackagePaths) == 0x10, "Offset mismatch for FARFilter::PackagePaths");
static_assert(offsetof(FARFilter, SoftObjectPaths) == 0x20, "Offset mismatch for FARFilter::SoftObjectPaths");
static_assert(offsetof(FARFilter, ClassNames) == 0x30, "Offset mismatch for FARFilter::ClassNames");
static_assert(offsetof(FARFilter, ClassPaths) == 0x40, "Offset mismatch for FARFilter::ClassPaths");
static_assert(offsetof(FARFilter, RecursiveClassesExclusionSet) == 0xa0, "Offset mismatch for FARFilter::RecursiveClassesExclusionSet");
static_assert(offsetof(FARFilter, RecursiveClassPathsExclusionSet) == 0xf0, "Offset mismatch for FARFilter::RecursiveClassPathsExclusionSet");
static_assert(offsetof(FARFilter, bRecursivePaths) == 0x140, "Offset mismatch for FARFilter::bRecursivePaths");
static_assert(offsetof(FARFilter, bRecursiveClasses) == 0x141, "Offset mismatch for FARFilter::bRecursiveClasses");
static_assert(offsetof(FARFilter, bIncludeOnlyOnDiskAssets) == 0x142, "Offset mismatch for FARFilter::bIncludeOnlyOnDiskAssets");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FTopLevelAssetPath
{
    FName PackageName; // 0x0 (Size: 0x4, Type: NameProperty)
    FName AssetName; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FTopLevelAssetPath) == 0x8, "Size mismatch for FTopLevelAssetPath");
static_assert(offsetof(FTopLevelAssetPath, PackageName) == 0x0, "Offset mismatch for FTopLevelAssetPath::PackageName");
static_assert(offsetof(FTopLevelAssetPath, AssetName) == 0x4, "Offset mismatch for FTopLevelAssetPath::AssetName");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FSoftObjectPath
{
    FTopLevelAssetPath AssetPath; // 0x0 (Size: 0x8, Type: StructProperty)
    uint8_t SubPathString[0x10]; // 0x8 (Size: 0x10, Type: Utf8StrProperty)
};

static_assert(sizeof(FSoftObjectPath) == 0x18, "Size mismatch for FSoftObjectPath");
static_assert(offsetof(FSoftObjectPath, AssetPath) == 0x0, "Offset mismatch for FSoftObjectPath::AssetPath");
static_assert(offsetof(FSoftObjectPath, SubPathString) == 0x8, "Offset mismatch for FSoftObjectPath::SubPathString");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAssetBundleData
{
    TArray<FAssetBundleEntry> Bundles; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAssetBundleData) == 0x10, "Size mismatch for FAssetBundleData");
static_assert(offsetof(FAssetBundleData, Bundles) == 0x0, "Offset mismatch for FAssetBundleData::Bundles");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAssetBundleEntry
{
    FName BundleName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FTopLevelAssetPath> AssetPaths; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAssetBundleEntry) == 0x18, "Size mismatch for FAssetBundleEntry");
static_assert(offsetof(FAssetBundleEntry, BundleName) == 0x0, "Offset mismatch for FAssetBundleEntry::BundleName");
static_assert(offsetof(FAssetBundleEntry, AssetPaths) == 0x8, "Offset mismatch for FAssetBundleEntry::AssetPaths");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FAssetData
{
    FName PackageName; // 0x0 (Size: 0x4, Type: NameProperty)
    FName PackagePath; // 0x4 (Size: 0x4, Type: NameProperty)
    FName AssetName; // 0x8 (Size: 0x4, Type: NameProperty)
    FName AssetClass; // 0xc (Size: 0x4, Type: NameProperty)
    FTopLevelAssetPath AssetClassPath; // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_18[0x20]; // 0x18 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(FAssetData) == 0x38, "Size mismatch for FAssetData");
static_assert(offsetof(FAssetData, PackageName) == 0x0, "Offset mismatch for FAssetData::PackageName");
static_assert(offsetof(FAssetData, PackagePath) == 0x4, "Offset mismatch for FAssetData::PackagePath");
static_assert(offsetof(FAssetData, AssetName) == 0x8, "Offset mismatch for FAssetData::AssetName");
static_assert(offsetof(FAssetData, AssetClass) == 0xc, "Offset mismatch for FAssetData::AssetClass");
static_assert(offsetof(FAssetData, AssetClassPath) == 0x10, "Offset mismatch for FAssetData::AssetClassPath");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FAutomationEvent
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FString Message; // 0x8 (Size: 0x10, Type: StrProperty)
    FString Context; // 0x18 (Size: 0x10, Type: StrProperty)
    FGuid Artifact; // 0x28 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FAutomationEvent) == 0x38, "Size mismatch for FAutomationEvent");
static_assert(offsetof(FAutomationEvent, Type) == 0x0, "Offset mismatch for FAutomationEvent::Type");
static_assert(offsetof(FAutomationEvent, Message) == 0x8, "Offset mismatch for FAutomationEvent::Message");
static_assert(offsetof(FAutomationEvent, Context) == 0x18, "Offset mismatch for FAutomationEvent::Context");
static_assert(offsetof(FAutomationEvent, Artifact) == 0x28, "Offset mismatch for FAutomationEvent::Artifact");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGuid
{
    int32_t A; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t B; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t C; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t D; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGuid) == 0x10, "Size mismatch for FGuid");
static_assert(offsetof(FGuid, A) == 0x0, "Offset mismatch for FGuid::A");
static_assert(offsetof(FGuid, B) == 0x4, "Offset mismatch for FGuid::B");
static_assert(offsetof(FGuid, C) == 0x8, "Offset mismatch for FGuid::C");
static_assert(offsetof(FGuid, D) == 0xc, "Offset mismatch for FGuid::D");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FAutomationExecutionEntry
{
    FAutomationEvent Event; // 0x0 (Size: 0x38, Type: StructProperty)
    FString Filename; // 0x38 (Size: 0x10, Type: StrProperty)
    int32_t LineNumber; // 0x48 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    FDateTime Timestamp; // 0x50 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FAutomationExecutionEntry) == 0x58, "Size mismatch for FAutomationExecutionEntry");
static_assert(offsetof(FAutomationExecutionEntry, Event) == 0x0, "Offset mismatch for FAutomationExecutionEntry::Event");
static_assert(offsetof(FAutomationExecutionEntry, Filename) == 0x38, "Offset mismatch for FAutomationExecutionEntry::Filename");
static_assert(offsetof(FAutomationExecutionEntry, LineNumber) == 0x48, "Offset mismatch for FAutomationExecutionEntry::LineNumber");
static_assert(offsetof(FAutomationExecutionEntry, Timestamp) == 0x50, "Offset mismatch for FAutomationExecutionEntry::Timestamp");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDateTime
{
    int64_t Ticks; // 0x0 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FDateTime) == 0x8, "Size mismatch for FDateTime");
static_assert(offsetof(FDateTime, Ticks) == 0x0, "Offset mismatch for FDateTime::Ticks");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FBox
{
    FVector Min; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Max; // 0x18 (Size: 0x18, Type: StructProperty)
    bool IsValid; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FBox) == 0x38, "Size mismatch for FBox");
static_assert(offsetof(FBox, Min) == 0x0, "Offset mismatch for FBox::Min");
static_assert(offsetof(FBox, Max) == 0x18, "Offset mismatch for FBox::Max");
static_assert(offsetof(FBox, IsValid) == 0x30, "Offset mismatch for FBox::IsValid");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FVector
{
    double X; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Z; // 0x10 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FVector) == 0x18, "Size mismatch for FVector");
static_assert(offsetof(FVector, X) == 0x0, "Offset mismatch for FVector::X");
static_assert(offsetof(FVector, Y) == 0x8, "Offset mismatch for FVector::Y");
static_assert(offsetof(FVector, Z) == 0x10, "Offset mismatch for FVector::Z");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FBox2D
{
    FVector2D Min; // 0x0 (Size: 0x10, Type: StructProperty)
    FVector2D Max; // 0x10 (Size: 0x10, Type: StructProperty)
    bool bIsValid; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FBox2D) == 0x28, "Size mismatch for FBox2D");
static_assert(offsetof(FBox2D, Min) == 0x0, "Offset mismatch for FBox2D::Min");
static_assert(offsetof(FBox2D, Max) == 0x10, "Offset mismatch for FBox2D::Max");
static_assert(offsetof(FBox2D, bIsValid) == 0x20, "Offset mismatch for FBox2D::bIsValid");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FVector2D
{
    double X; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y; // 0x8 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FVector2D) == 0x10, "Size mismatch for FVector2D");
static_assert(offsetof(FVector2D, X) == 0x0, "Offset mismatch for FVector2D::X");
static_assert(offsetof(FVector2D, Y) == 0x8, "Offset mismatch for FVector2D::Y");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FBox2f
{
    FVector2f Min; // 0x0 (Size: 0x8, Type: StructProperty)
    FVector2f Max; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIsValid; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FBox2f) == 0x14, "Size mismatch for FBox2f");
static_assert(offsetof(FBox2f, Min) == 0x0, "Offset mismatch for FBox2f::Min");
static_assert(offsetof(FBox2f, Max) == 0x8, "Offset mismatch for FBox2f::Max");
static_assert(offsetof(FBox2f, bIsValid) == 0x10, "Offset mismatch for FBox2f::bIsValid");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FVector2f
{
    float X; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Y; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FVector2f) == 0x8, "Size mismatch for FVector2f");
static_assert(offsetof(FVector2f, X) == 0x0, "Offset mismatch for FVector2f::X");
static_assert(offsetof(FVector2f, Y) == 0x4, "Offset mismatch for FVector2f::Y");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FBox3d
{
    FVector3d Min; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector3d Max; // 0x18 (Size: 0x18, Type: StructProperty)
    bool IsValid; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FBox3d) == 0x38, "Size mismatch for FBox3d");
static_assert(offsetof(FBox3d, Min) == 0x0, "Offset mismatch for FBox3d::Min");
static_assert(offsetof(FBox3d, Max) == 0x18, "Offset mismatch for FBox3d::Max");
static_assert(offsetof(FBox3d, IsValid) == 0x30, "Offset mismatch for FBox3d::IsValid");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FVector3d
{
    double X; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Z; // 0x10 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FVector3d) == 0x18, "Size mismatch for FVector3d");
static_assert(offsetof(FVector3d, X) == 0x0, "Offset mismatch for FVector3d::X");
static_assert(offsetof(FVector3d, Y) == 0x8, "Offset mismatch for FVector3d::Y");
static_assert(offsetof(FVector3d, Z) == 0x10, "Offset mismatch for FVector3d::Z");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FBox3f
{
    FVector3f Min; // 0x0 (Size: 0xc, Type: StructProperty)
    FVector3f Max; // 0xc (Size: 0xc, Type: StructProperty)
    bool IsValid; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FBox3f) == 0x1c, "Size mismatch for FBox3f");
static_assert(offsetof(FBox3f, Min) == 0x0, "Offset mismatch for FBox3f::Min");
static_assert(offsetof(FBox3f, Max) == 0xc, "Offset mismatch for FBox3f::Max");
static_assert(offsetof(FBox3f, IsValid) == 0x18, "Offset mismatch for FBox3f::IsValid");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FVector3f
{
    float X; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Y; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Z; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FVector3f) == 0xc, "Size mismatch for FVector3f");
static_assert(offsetof(FVector3f, X) == 0x0, "Offset mismatch for FVector3f::X");
static_assert(offsetof(FVector3f, Y) == 0x4, "Offset mismatch for FVector3f::Y");
static_assert(offsetof(FVector3f, Z) == 0x8, "Offset mismatch for FVector3f::Z");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FBoxSphereBounds
{
    FVector origin; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector BoxExtent; // 0x18 (Size: 0x18, Type: StructProperty)
    double SphereRadius; // 0x30 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FBoxSphereBounds) == 0x38, "Size mismatch for FBoxSphereBounds");
static_assert(offsetof(FBoxSphereBounds, origin) == 0x0, "Offset mismatch for FBoxSphereBounds::origin");
static_assert(offsetof(FBoxSphereBounds, BoxExtent) == 0x18, "Offset mismatch for FBoxSphereBounds::BoxExtent");
static_assert(offsetof(FBoxSphereBounds, SphereRadius) == 0x30, "Offset mismatch for FBoxSphereBounds::SphereRadius");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FBoxSphereBounds3d
{
    FVector3d origin; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector3d BoxExtent; // 0x18 (Size: 0x18, Type: StructProperty)
    double SphereRadius; // 0x30 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FBoxSphereBounds3d) == 0x38, "Size mismatch for FBoxSphereBounds3d");
static_assert(offsetof(FBoxSphereBounds3d, origin) == 0x0, "Offset mismatch for FBoxSphereBounds3d::origin");
static_assert(offsetof(FBoxSphereBounds3d, BoxExtent) == 0x18, "Offset mismatch for FBoxSphereBounds3d::BoxExtent");
static_assert(offsetof(FBoxSphereBounds3d, SphereRadius) == 0x30, "Offset mismatch for FBoxSphereBounds3d::SphereRadius");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FBoxSphereBounds3f
{
    FVector3f origin; // 0x0 (Size: 0xc, Type: StructProperty)
    FVector3f BoxExtent; // 0xc (Size: 0xc, Type: StructProperty)
    float SphereRadius; // 0x18 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBoxSphereBounds3f) == 0x1c, "Size mismatch for FBoxSphereBounds3f");
static_assert(offsetof(FBoxSphereBounds3f, origin) == 0x0, "Offset mismatch for FBoxSphereBounds3f::origin");
static_assert(offsetof(FBoxSphereBounds3f, BoxExtent) == 0xc, "Offset mismatch for FBoxSphereBounds3f::BoxExtent");
static_assert(offsetof(FBoxSphereBounds3f, SphereRadius) == 0x18, "Offset mismatch for FBoxSphereBounds3f::SphereRadius");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FColor
{
    char B; // 0x0 (Size: 0x1, Type: ByteProperty)
    char G; // 0x1 (Size: 0x1, Type: ByteProperty)
    char R; // 0x2 (Size: 0x1, Type: ByteProperty)
    char A; // 0x3 (Size: 0x1, Type: ByteProperty)
};

static_assert(sizeof(FColor) == 0x4, "Size mismatch for FColor");
static_assert(offsetof(FColor, B) == 0x0, "Offset mismatch for FColor::B");
static_assert(offsetof(FColor, G) == 0x1, "Offset mismatch for FColor::G");
static_assert(offsetof(FColor, R) == 0x2, "Offset mismatch for FColor::R");
static_assert(offsetof(FColor, A) == 0x3, "Offset mismatch for FColor::A");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDirectoryPath
{
    FString Path; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FDirectoryPath) == 0x10, "Size mismatch for FDirectoryPath");
static_assert(offsetof(FDirectoryPath, Path) == 0x0, "Offset mismatch for FDirectoryPath::Path");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDoubleRange
{
    FDoubleRangeBound LowerBound; // 0x0 (Size: 0x10, Type: StructProperty)
    FDoubleRangeBound UpperBound; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FDoubleRange) == 0x20, "Size mismatch for FDoubleRange");
static_assert(offsetof(FDoubleRange, LowerBound) == 0x0, "Offset mismatch for FDoubleRange::LowerBound");
static_assert(offsetof(FDoubleRange, UpperBound) == 0x10, "Offset mismatch for FDoubleRange::UpperBound");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDoubleRangeBound
{
    TEnumAsByte<ERangeBoundTypes> Type; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    double Value; // 0x8 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FDoubleRangeBound) == 0x10, "Size mismatch for FDoubleRangeBound");
static_assert(offsetof(FDoubleRangeBound, Type) == 0x0, "Offset mismatch for FDoubleRangeBound::Type");
static_assert(offsetof(FDoubleRangeBound, Value) == 0x8, "Offset mismatch for FDoubleRangeBound::Value");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FFallbackStruct
{
};

static_assert(sizeof(FFallbackStruct) == 0x1, "Size mismatch for FFallbackStruct");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFilePath
{
    FString FilePath; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FFilePath) == 0x10, "Size mismatch for FFilePath");
static_assert(offsetof(FFilePath, FilePath) == 0x0, "Offset mismatch for FFilePath::FilePath");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFloatInterval
{
    float Min; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Max; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFloatInterval) == 0x8, "Size mismatch for FFloatInterval");
static_assert(offsetof(FFloatInterval, Min) == 0x0, "Offset mismatch for FFloatInterval::Min");
static_assert(offsetof(FFloatInterval, Max) == 0x4, "Offset mismatch for FFloatInterval::Max");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFloatRange
{
    FFloatRangeBound LowerBound; // 0x0 (Size: 0x8, Type: StructProperty)
    FFloatRangeBound UpperBound; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FFloatRange) == 0x10, "Size mismatch for FFloatRange");
static_assert(offsetof(FFloatRange, LowerBound) == 0x0, "Offset mismatch for FFloatRange::LowerBound");
static_assert(offsetof(FFloatRange, UpperBound) == 0x8, "Offset mismatch for FFloatRange::UpperBound");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFloatRangeBound
{
    TEnumAsByte<ERangeBoundTypes> Type; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float Value; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFloatRangeBound) == 0x8, "Size mismatch for FFloatRangeBound");
static_assert(offsetof(FFloatRangeBound, Type) == 0x0, "Offset mismatch for FFloatRangeBound::Type");
static_assert(offsetof(FFloatRangeBound, Value) == 0x4, "Offset mismatch for FFloatRangeBound::Value");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FFrameNumber
{
    int32_t Value; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FFrameNumber) == 0x4, "Size mismatch for FFrameNumber");
static_assert(offsetof(FFrameNumber, Value) == 0x0, "Offset mismatch for FFrameNumber::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFrameNumberRange
{
    FFrameNumberRangeBound LowerBound; // 0x0 (Size: 0x8, Type: StructProperty)
    FFrameNumberRangeBound UpperBound; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FFrameNumberRange) == 0x10, "Size mismatch for FFrameNumberRange");
static_assert(offsetof(FFrameNumberRange, LowerBound) == 0x0, "Offset mismatch for FFrameNumberRange::LowerBound");
static_assert(offsetof(FFrameNumberRange, UpperBound) == 0x8, "Offset mismatch for FFrameNumberRange::UpperBound");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFrameNumberRangeBound
{
    TEnumAsByte<ERangeBoundTypes> Type; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FFrameNumber Value; // 0x4 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FFrameNumberRangeBound) == 0x8, "Size mismatch for FFrameNumberRangeBound");
static_assert(offsetof(FFrameNumberRangeBound, Type) == 0x0, "Offset mismatch for FFrameNumberRangeBound::Type");
static_assert(offsetof(FFrameNumberRangeBound, Value) == 0x4, "Offset mismatch for FFrameNumberRangeBound::Value");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFrameRate
{
    int32_t Numerator; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Denominator; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FFrameRate) == 0x8, "Size mismatch for FFrameRate");
static_assert(offsetof(FFrameRate, Numerator) == 0x0, "Offset mismatch for FFrameRate::Numerator");
static_assert(offsetof(FFrameRate, Denominator) == 0x4, "Offset mismatch for FFrameRate::Denominator");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFrameTime
{
    FFrameNumber FrameNumber; // 0x0 (Size: 0x4, Type: StructProperty)
    float SubFrame; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFrameTime) == 0x8, "Size mismatch for FFrameTime");
static_assert(offsetof(FFrameTime, FrameNumber) == 0x0, "Offset mismatch for FFrameTime::FrameNumber");
static_assert(offsetof(FFrameTime, SubFrame) == 0x4, "Offset mismatch for FFrameTime::SubFrame");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FInputDeviceId
{
    int32_t InternalId; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FInputDeviceId) == 0x4, "Size mismatch for FInputDeviceId");
static_assert(offsetof(FInputDeviceId, InternalId) == 0x0, "Offset mismatch for FInputDeviceId::InternalId");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FInt32Interval
{
    int32_t Min; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Max; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FInt32Interval) == 0x8, "Size mismatch for FInt32Interval");
static_assert(offsetof(FInt32Interval, Min) == 0x0, "Offset mismatch for FInt32Interval::Min");
static_assert(offsetof(FInt32Interval, Max) == 0x4, "Offset mismatch for FInt32Interval::Max");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FInt32Point
{
    int32_t X; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FInt32Point) == 0x8, "Size mismatch for FInt32Point");
static_assert(offsetof(FInt32Point, X) == 0x0, "Offset mismatch for FInt32Point::X");
static_assert(offsetof(FInt32Point, Y) == 0x4, "Offset mismatch for FInt32Point::Y");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInt32Range
{
    FInt32RangeBound LowerBound; // 0x0 (Size: 0x8, Type: StructProperty)
    FInt32RangeBound UpperBound; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FInt32Range) == 0x10, "Size mismatch for FInt32Range");
static_assert(offsetof(FInt32Range, LowerBound) == 0x0, "Offset mismatch for FInt32Range::LowerBound");
static_assert(offsetof(FInt32Range, UpperBound) == 0x8, "Offset mismatch for FInt32Range::UpperBound");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FInt32RangeBound
{
    TEnumAsByte<ERangeBoundTypes> Type; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t Value; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FInt32RangeBound) == 0x8, "Size mismatch for FInt32RangeBound");
static_assert(offsetof(FInt32RangeBound, Type) == 0x0, "Offset mismatch for FInt32RangeBound::Type");
static_assert(offsetof(FInt32RangeBound, Value) == 0x4, "Offset mismatch for FInt32RangeBound::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInt32Rect
{
    FInt32Point Min; // 0x0 (Size: 0x8, Type: StructProperty)
    FInt32Point Max; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FInt32Rect) == 0x10, "Size mismatch for FInt32Rect");
static_assert(offsetof(FInt32Rect, Min) == 0x0, "Offset mismatch for FInt32Rect::Min");
static_assert(offsetof(FInt32Rect, Max) == 0x8, "Offset mismatch for FInt32Rect::Max");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FInt32Vector
{
    int32_t X; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Z; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FInt32Vector) == 0xc, "Size mismatch for FInt32Vector");
static_assert(offsetof(FInt32Vector, X) == 0x0, "Offset mismatch for FInt32Vector::X");
static_assert(offsetof(FInt32Vector, Y) == 0x4, "Offset mismatch for FInt32Vector::Y");
static_assert(offsetof(FInt32Vector, Z) == 0x8, "Offset mismatch for FInt32Vector::Z");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FInt32Vector2
{
    int32_t X; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FInt32Vector2) == 0x8, "Size mismatch for FInt32Vector2");
static_assert(offsetof(FInt32Vector2, X) == 0x0, "Offset mismatch for FInt32Vector2::X");
static_assert(offsetof(FInt32Vector2, Y) == 0x4, "Offset mismatch for FInt32Vector2::Y");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInt32Vector4
{
    int32_t X; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Z; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t W; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FInt32Vector4) == 0x10, "Size mismatch for FInt32Vector4");
static_assert(offsetof(FInt32Vector4, X) == 0x0, "Offset mismatch for FInt32Vector4::X");
static_assert(offsetof(FInt32Vector4, Y) == 0x4, "Offset mismatch for FInt32Vector4::Y");
static_assert(offsetof(FInt32Vector4, Z) == 0x8, "Offset mismatch for FInt32Vector4::Z");
static_assert(offsetof(FInt32Vector4, W) == 0xc, "Offset mismatch for FInt32Vector4::W");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInt64Point
{
    int64_t X; // 0x0 (Size: 0x8, Type: Int64Property)
    int64_t Y; // 0x8 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FInt64Point) == 0x10, "Size mismatch for FInt64Point");
static_assert(offsetof(FInt64Point, X) == 0x0, "Offset mismatch for FInt64Point::X");
static_assert(offsetof(FInt64Point, Y) == 0x8, "Offset mismatch for FInt64Point::Y");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FInt64Rect
{
    FInt64Point Min; // 0x0 (Size: 0x10, Type: StructProperty)
    FInt64Point Max; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FInt64Rect) == 0x20, "Size mismatch for FInt64Rect");
static_assert(offsetof(FInt64Rect, Min) == 0x0, "Offset mismatch for FInt64Rect::Min");
static_assert(offsetof(FInt64Rect, Max) == 0x10, "Offset mismatch for FInt64Rect::Max");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FInt64Vector
{
    int64_t X; // 0x0 (Size: 0x8, Type: Int64Property)
    int64_t Y; // 0x8 (Size: 0x8, Type: Int64Property)
    int64_t Z; // 0x10 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FInt64Vector) == 0x18, "Size mismatch for FInt64Vector");
static_assert(offsetof(FInt64Vector, X) == 0x0, "Offset mismatch for FInt64Vector::X");
static_assert(offsetof(FInt64Vector, Y) == 0x8, "Offset mismatch for FInt64Vector::Y");
static_assert(offsetof(FInt64Vector, Z) == 0x10, "Offset mismatch for FInt64Vector::Z");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInt64Vector2
{
    int64_t X; // 0x0 (Size: 0x8, Type: Int64Property)
    int64_t Y; // 0x8 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FInt64Vector2) == 0x10, "Size mismatch for FInt64Vector2");
static_assert(offsetof(FInt64Vector2, X) == 0x0, "Offset mismatch for FInt64Vector2::X");
static_assert(offsetof(FInt64Vector2, Y) == 0x8, "Offset mismatch for FInt64Vector2::Y");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FInt64Vector4
{
    int64_t X; // 0x0 (Size: 0x8, Type: Int64Property)
    int64_t Y; // 0x8 (Size: 0x8, Type: Int64Property)
    int64_t Z; // 0x10 (Size: 0x8, Type: Int64Property)
    int64_t W; // 0x18 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FInt64Vector4) == 0x20, "Size mismatch for FInt64Vector4");
static_assert(offsetof(FInt64Vector4, X) == 0x0, "Offset mismatch for FInt64Vector4::X");
static_assert(offsetof(FInt64Vector4, Y) == 0x8, "Offset mismatch for FInt64Vector4::Y");
static_assert(offsetof(FInt64Vector4, Z) == 0x10, "Offset mismatch for FInt64Vector4::Z");
static_assert(offsetof(FInt64Vector4, W) == 0x18, "Offset mismatch for FInt64Vector4::W");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FInterpCurveFloat
{
    TArray<FInterpCurvePointFloat> Points; // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bIsLooped; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float LoopKeyOffset; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FInterpCurveFloat) == 0x18, "Size mismatch for FInterpCurveFloat");
static_assert(offsetof(FInterpCurveFloat, Points) == 0x0, "Offset mismatch for FInterpCurveFloat::Points");
static_assert(offsetof(FInterpCurveFloat, bIsLooped) == 0x10, "Offset mismatch for FInterpCurveFloat::bIsLooped");
static_assert(offsetof(FInterpCurveFloat, LoopKeyOffset) == 0x14, "Offset mismatch for FInterpCurveFloat::LoopKeyOffset");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FInterpCurvePointFloat
{
    float InVal; // 0x0 (Size: 0x4, Type: FloatProperty)
    float OutVal; // 0x4 (Size: 0x4, Type: FloatProperty)
    float ArriveTangent; // 0x8 (Size: 0x4, Type: FloatProperty)
    float LeaveTangent; // 0xc (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EInterpCurveMode> InterpMode; // 0x10 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FInterpCurvePointFloat) == 0x14, "Size mismatch for FInterpCurvePointFloat");
static_assert(offsetof(FInterpCurvePointFloat, InVal) == 0x0, "Offset mismatch for FInterpCurvePointFloat::InVal");
static_assert(offsetof(FInterpCurvePointFloat, OutVal) == 0x4, "Offset mismatch for FInterpCurvePointFloat::OutVal");
static_assert(offsetof(FInterpCurvePointFloat, ArriveTangent) == 0x8, "Offset mismatch for FInterpCurvePointFloat::ArriveTangent");
static_assert(offsetof(FInterpCurvePointFloat, LeaveTangent) == 0xc, "Offset mismatch for FInterpCurvePointFloat::LeaveTangent");
static_assert(offsetof(FInterpCurvePointFloat, InterpMode) == 0x10, "Offset mismatch for FInterpCurvePointFloat::InterpMode");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FInterpCurveLinearColor
{
    TArray<FInterpCurvePointLinearColor> Points; // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bIsLooped; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float LoopKeyOffset; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FInterpCurveLinearColor) == 0x18, "Size mismatch for FInterpCurveLinearColor");
static_assert(offsetof(FInterpCurveLinearColor, Points) == 0x0, "Offset mismatch for FInterpCurveLinearColor::Points");
static_assert(offsetof(FInterpCurveLinearColor, bIsLooped) == 0x10, "Offset mismatch for FInterpCurveLinearColor::bIsLooped");
static_assert(offsetof(FInterpCurveLinearColor, LoopKeyOffset) == 0x14, "Offset mismatch for FInterpCurveLinearColor::LoopKeyOffset");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FInterpCurvePointLinearColor
{
    float InVal; // 0x0 (Size: 0x4, Type: FloatProperty)
    FLinearColor OutVal; // 0x4 (Size: 0x10, Type: StructProperty)
    FLinearColor ArriveTangent; // 0x14 (Size: 0x10, Type: StructProperty)
    FLinearColor LeaveTangent; // 0x24 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<EInterpCurveMode> InterpMode; // 0x34 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_35[0x3]; // 0x35 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FInterpCurvePointLinearColor) == 0x38, "Size mismatch for FInterpCurvePointLinearColor");
static_assert(offsetof(FInterpCurvePointLinearColor, InVal) == 0x0, "Offset mismatch for FInterpCurvePointLinearColor::InVal");
static_assert(offsetof(FInterpCurvePointLinearColor, OutVal) == 0x4, "Offset mismatch for FInterpCurvePointLinearColor::OutVal");
static_assert(offsetof(FInterpCurvePointLinearColor, ArriveTangent) == 0x14, "Offset mismatch for FInterpCurvePointLinearColor::ArriveTangent");
static_assert(offsetof(FInterpCurvePointLinearColor, LeaveTangent) == 0x24, "Offset mismatch for FInterpCurvePointLinearColor::LeaveTangent");
static_assert(offsetof(FInterpCurvePointLinearColor, InterpMode) == 0x34, "Offset mismatch for FInterpCurvePointLinearColor::InterpMode");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FLinearColor
{
    float R; // 0x0 (Size: 0x4, Type: FloatProperty)
    float G; // 0x4 (Size: 0x4, Type: FloatProperty)
    float B; // 0x8 (Size: 0x4, Type: FloatProperty)
    float A; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FLinearColor) == 0x10, "Size mismatch for FLinearColor");
static_assert(offsetof(FLinearColor, R) == 0x0, "Offset mismatch for FLinearColor::R");
static_assert(offsetof(FLinearColor, G) == 0x4, "Offset mismatch for FLinearColor::G");
static_assert(offsetof(FLinearColor, B) == 0x8, "Offset mismatch for FLinearColor::B");
static_assert(offsetof(FLinearColor, A) == 0xc, "Offset mismatch for FLinearColor::A");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FInterpCurvePointQuat
{
    float InVal; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0xc]; // 0x4 (Size: 0xc, Type: PaddingProperty)
    FQuat OutVal; // 0x10 (Size: 0x20, Type: StructProperty)
    FQuat ArriveTangent; // 0x30 (Size: 0x20, Type: StructProperty)
    FQuat LeaveTangent; // 0x50 (Size: 0x20, Type: StructProperty)
    TEnumAsByte<EInterpCurveMode> InterpMode; // 0x70 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_71[0xf]; // 0x71 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FInterpCurvePointQuat) == 0x80, "Size mismatch for FInterpCurvePointQuat");
static_assert(offsetof(FInterpCurvePointQuat, InVal) == 0x0, "Offset mismatch for FInterpCurvePointQuat::InVal");
static_assert(offsetof(FInterpCurvePointQuat, OutVal) == 0x10, "Offset mismatch for FInterpCurvePointQuat::OutVal");
static_assert(offsetof(FInterpCurvePointQuat, ArriveTangent) == 0x30, "Offset mismatch for FInterpCurvePointQuat::ArriveTangent");
static_assert(offsetof(FInterpCurvePointQuat, LeaveTangent) == 0x50, "Offset mismatch for FInterpCurvePointQuat::LeaveTangent");
static_assert(offsetof(FInterpCurvePointQuat, InterpMode) == 0x70, "Offset mismatch for FInterpCurvePointQuat::InterpMode");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FQuat
{
    double X; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Z; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double W; // 0x18 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FQuat) == 0x20, "Size mismatch for FQuat");
static_assert(offsetof(FQuat, X) == 0x0, "Offset mismatch for FQuat::X");
static_assert(offsetof(FQuat, Y) == 0x8, "Offset mismatch for FQuat::Y");
static_assert(offsetof(FQuat, Z) == 0x10, "Offset mismatch for FQuat::Z");
static_assert(offsetof(FQuat, W) == 0x18, "Offset mismatch for FQuat::W");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FInterpCurvePointTwoVectors
{
    float InVal; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FTwoVectors OutVal; // 0x8 (Size: 0x30, Type: StructProperty)
    FTwoVectors ArriveTangent; // 0x38 (Size: 0x30, Type: StructProperty)
    FTwoVectors LeaveTangent; // 0x68 (Size: 0x30, Type: StructProperty)
    TEnumAsByte<EInterpCurveMode> InterpMode; // 0x98 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FInterpCurvePointTwoVectors) == 0xa0, "Size mismatch for FInterpCurvePointTwoVectors");
static_assert(offsetof(FInterpCurvePointTwoVectors, InVal) == 0x0, "Offset mismatch for FInterpCurvePointTwoVectors::InVal");
static_assert(offsetof(FInterpCurvePointTwoVectors, OutVal) == 0x8, "Offset mismatch for FInterpCurvePointTwoVectors::OutVal");
static_assert(offsetof(FInterpCurvePointTwoVectors, ArriveTangent) == 0x38, "Offset mismatch for FInterpCurvePointTwoVectors::ArriveTangent");
static_assert(offsetof(FInterpCurvePointTwoVectors, LeaveTangent) == 0x68, "Offset mismatch for FInterpCurvePointTwoVectors::LeaveTangent");
static_assert(offsetof(FInterpCurvePointTwoVectors, InterpMode) == 0x98, "Offset mismatch for FInterpCurvePointTwoVectors::InterpMode");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FTwoVectors
{
    FVector v1; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector v2; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FTwoVectors) == 0x30, "Size mismatch for FTwoVectors");
static_assert(offsetof(FTwoVectors, v1) == 0x0, "Offset mismatch for FTwoVectors::v1");
static_assert(offsetof(FTwoVectors, v2) == 0x18, "Offset mismatch for FTwoVectors::v2");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FInterpCurvePointVector
{
    float InVal; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector OutVal; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector ArriveTangent; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector LeaveTangent; // 0x38 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<EInterpCurveMode> InterpMode; // 0x50 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FInterpCurvePointVector) == 0x58, "Size mismatch for FInterpCurvePointVector");
static_assert(offsetof(FInterpCurvePointVector, InVal) == 0x0, "Offset mismatch for FInterpCurvePointVector::InVal");
static_assert(offsetof(FInterpCurvePointVector, OutVal) == 0x8, "Offset mismatch for FInterpCurvePointVector::OutVal");
static_assert(offsetof(FInterpCurvePointVector, ArriveTangent) == 0x20, "Offset mismatch for FInterpCurvePointVector::ArriveTangent");
static_assert(offsetof(FInterpCurvePointVector, LeaveTangent) == 0x38, "Offset mismatch for FInterpCurvePointVector::LeaveTangent");
static_assert(offsetof(FInterpCurvePointVector, InterpMode) == 0x50, "Offset mismatch for FInterpCurvePointVector::InterpMode");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FInterpCurvePointVector2D
{
    float InVal; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector2D OutVal; // 0x8 (Size: 0x10, Type: StructProperty)
    FVector2D ArriveTangent; // 0x18 (Size: 0x10, Type: StructProperty)
    FVector2D LeaveTangent; // 0x28 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<EInterpCurveMode> InterpMode; // 0x38 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FInterpCurvePointVector2D) == 0x40, "Size mismatch for FInterpCurvePointVector2D");
static_assert(offsetof(FInterpCurvePointVector2D, InVal) == 0x0, "Offset mismatch for FInterpCurvePointVector2D::InVal");
static_assert(offsetof(FInterpCurvePointVector2D, OutVal) == 0x8, "Offset mismatch for FInterpCurvePointVector2D::OutVal");
static_assert(offsetof(FInterpCurvePointVector2D, ArriveTangent) == 0x18, "Offset mismatch for FInterpCurvePointVector2D::ArriveTangent");
static_assert(offsetof(FInterpCurvePointVector2D, LeaveTangent) == 0x28, "Offset mismatch for FInterpCurvePointVector2D::LeaveTangent");
static_assert(offsetof(FInterpCurvePointVector2D, InterpMode) == 0x38, "Offset mismatch for FInterpCurvePointVector2D::InterpMode");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FInterpCurveQuat
{
    TArray<FInterpCurvePointQuat> Points; // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bIsLooped; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float LoopKeyOffset; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FInterpCurveQuat) == 0x18, "Size mismatch for FInterpCurveQuat");
static_assert(offsetof(FInterpCurveQuat, Points) == 0x0, "Offset mismatch for FInterpCurveQuat::Points");
static_assert(offsetof(FInterpCurveQuat, bIsLooped) == 0x10, "Offset mismatch for FInterpCurveQuat::bIsLooped");
static_assert(offsetof(FInterpCurveQuat, LoopKeyOffset) == 0x14, "Offset mismatch for FInterpCurveQuat::LoopKeyOffset");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FInterpCurveTwoVectors
{
    TArray<FInterpCurvePointTwoVectors> Points; // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bIsLooped; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float LoopKeyOffset; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FInterpCurveTwoVectors) == 0x18, "Size mismatch for FInterpCurveTwoVectors");
static_assert(offsetof(FInterpCurveTwoVectors, Points) == 0x0, "Offset mismatch for FInterpCurveTwoVectors::Points");
static_assert(offsetof(FInterpCurveTwoVectors, bIsLooped) == 0x10, "Offset mismatch for FInterpCurveTwoVectors::bIsLooped");
static_assert(offsetof(FInterpCurveTwoVectors, LoopKeyOffset) == 0x14, "Offset mismatch for FInterpCurveTwoVectors::LoopKeyOffset");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FInterpCurveVector
{
    TArray<FInterpCurvePointVector> Points; // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bIsLooped; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float LoopKeyOffset; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FInterpCurveVector) == 0x18, "Size mismatch for FInterpCurveVector");
static_assert(offsetof(FInterpCurveVector, Points) == 0x0, "Offset mismatch for FInterpCurveVector::Points");
static_assert(offsetof(FInterpCurveVector, bIsLooped) == 0x10, "Offset mismatch for FInterpCurveVector::bIsLooped");
static_assert(offsetof(FInterpCurveVector, LoopKeyOffset) == 0x14, "Offset mismatch for FInterpCurveVector::LoopKeyOffset");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FInterpCurveVector2D
{
    TArray<FInterpCurvePointVector2D> Points; // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bIsLooped; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float LoopKeyOffset; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FInterpCurveVector2D) == 0x18, "Size mismatch for FInterpCurveVector2D");
static_assert(offsetof(FInterpCurveVector2D, Points) == 0x0, "Offset mismatch for FInterpCurveVector2D::Points");
static_assert(offsetof(FInterpCurveVector2D, bIsLooped) == 0x10, "Offset mismatch for FInterpCurveVector2D::bIsLooped");
static_assert(offsetof(FInterpCurveVector2D, LoopKeyOffset) == 0x14, "Offset mismatch for FInterpCurveVector2D::LoopKeyOffset");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FIntPoint
{
    int32_t X; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FIntPoint) == 0x8, "Size mismatch for FIntPoint");
static_assert(offsetof(FIntPoint, X) == 0x0, "Offset mismatch for FIntPoint::X");
static_assert(offsetof(FIntPoint, Y) == 0x4, "Offset mismatch for FIntPoint::Y");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FIntRect
{
    FIntPoint Min; // 0x0 (Size: 0x8, Type: StructProperty)
    FIntPoint Max; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FIntRect) == 0x10, "Size mismatch for FIntRect");
static_assert(offsetof(FIntRect, Min) == 0x0, "Offset mismatch for FIntRect::Min");
static_assert(offsetof(FIntRect, Max) == 0x8, "Offset mismatch for FIntRect::Max");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FIntVector
{
    int32_t X; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Z; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FIntVector) == 0xc, "Size mismatch for FIntVector");
static_assert(offsetof(FIntVector, X) == 0x0, "Offset mismatch for FIntVector::X");
static_assert(offsetof(FIntVector, Y) == 0x4, "Offset mismatch for FIntVector::Y");
static_assert(offsetof(FIntVector, Z) == 0x8, "Offset mismatch for FIntVector::Z");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FIntVector2
{
    int32_t X; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FIntVector2) == 0x8, "Size mismatch for FIntVector2");
static_assert(offsetof(FIntVector2, X) == 0x0, "Offset mismatch for FIntVector2::X");
static_assert(offsetof(FIntVector2, Y) == 0x4, "Offset mismatch for FIntVector2::Y");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FIntVector4
{
    int32_t X; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Z; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t W; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FIntVector4) == 0x10, "Size mismatch for FIntVector4");
static_assert(offsetof(FIntVector4, X) == 0x0, "Offset mismatch for FIntVector4::X");
static_assert(offsetof(FIntVector4, Y) == 0x4, "Offset mismatch for FIntVector4::Y");
static_assert(offsetof(FIntVector4, Z) == 0x8, "Offset mismatch for FIntVector4::Z");
static_assert(offsetof(FIntVector4, W) == 0xc, "Offset mismatch for FIntVector4::W");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FMatrix
{
    FPlane XPlane; // 0x0 (Size: 0x20, Type: StructProperty)
    FPlane YPlane; // 0x20 (Size: 0x20, Type: StructProperty)
    FPlane ZPlane; // 0x40 (Size: 0x20, Type: StructProperty)
    FPlane WPlane; // 0x60 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FMatrix) == 0x80, "Size mismatch for FMatrix");
static_assert(offsetof(FMatrix, XPlane) == 0x0, "Offset mismatch for FMatrix::XPlane");
static_assert(offsetof(FMatrix, YPlane) == 0x20, "Offset mismatch for FMatrix::YPlane");
static_assert(offsetof(FMatrix, ZPlane) == 0x40, "Offset mismatch for FMatrix::ZPlane");
static_assert(offsetof(FMatrix, WPlane) == 0x60, "Offset mismatch for FMatrix::WPlane");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FPlane : FVector
{
    double W; // 0x18 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FPlane) == 0x20, "Size mismatch for FPlane");
static_assert(offsetof(FPlane, W) == 0x18, "Offset mismatch for FPlane::W");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FMatrix44d
{
    FPlane4d XPlane; // 0x0 (Size: 0x20, Type: StructProperty)
    FPlane4d YPlane; // 0x20 (Size: 0x20, Type: StructProperty)
    FPlane4d ZPlane; // 0x40 (Size: 0x20, Type: StructProperty)
    FPlane4d WPlane; // 0x60 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FMatrix44d) == 0x80, "Size mismatch for FMatrix44d");
static_assert(offsetof(FMatrix44d, XPlane) == 0x0, "Offset mismatch for FMatrix44d::XPlane");
static_assert(offsetof(FMatrix44d, YPlane) == 0x20, "Offset mismatch for FMatrix44d::YPlane");
static_assert(offsetof(FMatrix44d, ZPlane) == 0x40, "Offset mismatch for FMatrix44d::ZPlane");
static_assert(offsetof(FMatrix44d, WPlane) == 0x60, "Offset mismatch for FMatrix44d::WPlane");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FPlane4d : FVector3d
{
    double W; // 0x18 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FPlane4d) == 0x20, "Size mismatch for FPlane4d");
static_assert(offsetof(FPlane4d, W) == 0x18, "Offset mismatch for FPlane4d::W");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FMatrix44f
{
    FPlane4f XPlane; // 0x0 (Size: 0x10, Type: StructProperty)
    FPlane4f YPlane; // 0x10 (Size: 0x10, Type: StructProperty)
    FPlane4f ZPlane; // 0x20 (Size: 0x10, Type: StructProperty)
    FPlane4f WPlane; // 0x30 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FMatrix44f) == 0x40, "Size mismatch for FMatrix44f");
static_assert(offsetof(FMatrix44f, XPlane) == 0x0, "Offset mismatch for FMatrix44f::XPlane");
static_assert(offsetof(FMatrix44f, YPlane) == 0x10, "Offset mismatch for FMatrix44f::YPlane");
static_assert(offsetof(FMatrix44f, ZPlane) == 0x20, "Offset mismatch for FMatrix44f::ZPlane");
static_assert(offsetof(FMatrix44f, WPlane) == 0x30, "Offset mismatch for FMatrix44f::WPlane");

// Size: 0x10 (Inherited: 0xc, Single: 0x4)
struct FPlane4f : FVector3f
{
    float W; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FPlane4f) == 0x10, "Size mismatch for FPlane4f");
static_assert(offsetof(FPlane4f, W) == 0xc, "Offset mismatch for FPlane4f::W");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FMusicalTime
{
    int32_t Bar; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t TickInBar; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t TicksPerBar; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t TicksPerBeat; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FMusicalTime) == 0x10, "Size mismatch for FMusicalTime");
static_assert(offsetof(FMusicalTime, Bar) == 0x0, "Offset mismatch for FMusicalTime::Bar");
static_assert(offsetof(FMusicalTime, TickInBar) == 0x4, "Offset mismatch for FMusicalTime::TickInBar");
static_assert(offsetof(FMusicalTime, TicksPerBar) == 0x8, "Offset mismatch for FMusicalTime::TicksPerBar");
static_assert(offsetof(FMusicalTime, TicksPerBeat) == 0xc, "Offset mismatch for FMusicalTime::TicksPerBeat");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FOrientedBox
{
    FVector Center; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector AxisX; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector AxisY; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector AxisZ; // 0x48 (Size: 0x18, Type: StructProperty)
    double ExtentX; // 0x60 (Size: 0x8, Type: DoubleProperty)
    double ExtentY; // 0x68 (Size: 0x8, Type: DoubleProperty)
    double ExtentZ; // 0x70 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FOrientedBox) == 0x78, "Size mismatch for FOrientedBox");
static_assert(offsetof(FOrientedBox, Center) == 0x0, "Offset mismatch for FOrientedBox::Center");
static_assert(offsetof(FOrientedBox, AxisX) == 0x18, "Offset mismatch for FOrientedBox::AxisX");
static_assert(offsetof(FOrientedBox, AxisY) == 0x30, "Offset mismatch for FOrientedBox::AxisY");
static_assert(offsetof(FOrientedBox, AxisZ) == 0x48, "Offset mismatch for FOrientedBox::AxisZ");
static_assert(offsetof(FOrientedBox, ExtentX) == 0x60, "Offset mismatch for FOrientedBox::ExtentX");
static_assert(offsetof(FOrientedBox, ExtentY) == 0x68, "Offset mismatch for FOrientedBox::ExtentY");
static_assert(offsetof(FOrientedBox, ExtentZ) == 0x70, "Offset mismatch for FOrientedBox::ExtentZ");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FPackedNormal
{
    char X; // 0x0 (Size: 0x1, Type: ByteProperty)
    char Y; // 0x1 (Size: 0x1, Type: ByteProperty)
    char Z; // 0x2 (Size: 0x1, Type: ByteProperty)
    char W; // 0x3 (Size: 0x1, Type: ByteProperty)
};

static_assert(sizeof(FPackedNormal) == 0x4, "Size mismatch for FPackedNormal");
static_assert(offsetof(FPackedNormal, X) == 0x0, "Offset mismatch for FPackedNormal::X");
static_assert(offsetof(FPackedNormal, Y) == 0x1, "Offset mismatch for FPackedNormal::Y");
static_assert(offsetof(FPackedNormal, Z) == 0x2, "Offset mismatch for FPackedNormal::Z");
static_assert(offsetof(FPackedNormal, W) == 0x3, "Offset mismatch for FPackedNormal::W");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FPackedRGB10A2N
{
    int32_t Packed; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FPackedRGB10A2N) == 0x4, "Size mismatch for FPackedRGB10A2N");
static_assert(offsetof(FPackedRGB10A2N, Packed) == 0x0, "Offset mismatch for FPackedRGB10A2N::Packed");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FPackedRGBA16N
{
    int32_t XY; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t ZW; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FPackedRGBA16N) == 0x8, "Size mismatch for FPackedRGBA16N");
static_assert(offsetof(FPackedRGBA16N, XY) == 0x0, "Offset mismatch for FPackedRGBA16N::XY");
static_assert(offsetof(FPackedRGBA16N, ZW) == 0x4, "Offset mismatch for FPackedRGBA16N::ZW");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FPlatformInputDeviceState
{
    FPlatformUserId OwningPlatformUser; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t ConnectionState; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FPlatformInputDeviceState) == 0x8, "Size mismatch for FPlatformInputDeviceState");
static_assert(offsetof(FPlatformInputDeviceState, OwningPlatformUser) == 0x0, "Offset mismatch for FPlatformInputDeviceState::OwningPlatformUser");
static_assert(offsetof(FPlatformInputDeviceState, ConnectionState) == 0x4, "Offset mismatch for FPlatformInputDeviceState::ConnectionState");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FPlatformUserId
{
    int32_t InternalId; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FPlatformUserId) == 0x4, "Size mismatch for FPlatformUserId");
static_assert(offsetof(FPlatformUserId, InternalId) == 0x0, "Offset mismatch for FPlatformUserId::InternalId");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FPolyglotTextData
{
    uint8_t Category; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FString NativeCulture; // 0x8 (Size: 0x10, Type: StrProperty)
    FString Namespace; // 0x18 (Size: 0x10, Type: StrProperty)
    FString Key; // 0x28 (Size: 0x10, Type: StrProperty)
    FString NativeString; // 0x38 (Size: 0x10, Type: StrProperty)
    TMap<FString, FString> LocalizedStrings; // 0x48 (Size: 0x50, Type: MapProperty)
    bool bIsMinimalPatch; // 0x98 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
    FText CachedText; // 0xa0 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FPolyglotTextData) == 0xb0, "Size mismatch for FPolyglotTextData");
static_assert(offsetof(FPolyglotTextData, Category) == 0x0, "Offset mismatch for FPolyglotTextData::Category");
static_assert(offsetof(FPolyglotTextData, NativeCulture) == 0x8, "Offset mismatch for FPolyglotTextData::NativeCulture");
static_assert(offsetof(FPolyglotTextData, Namespace) == 0x18, "Offset mismatch for FPolyglotTextData::Namespace");
static_assert(offsetof(FPolyglotTextData, Key) == 0x28, "Offset mismatch for FPolyglotTextData::Key");
static_assert(offsetof(FPolyglotTextData, NativeString) == 0x38, "Offset mismatch for FPolyglotTextData::NativeString");
static_assert(offsetof(FPolyglotTextData, LocalizedStrings) == 0x48, "Offset mismatch for FPolyglotTextData::LocalizedStrings");
static_assert(offsetof(FPolyglotTextData, bIsMinimalPatch) == 0x98, "Offset mismatch for FPolyglotTextData::bIsMinimalPatch");
static_assert(offsetof(FPolyglotTextData, CachedText) == 0xa0, "Offset mismatch for FPolyglotTextData::CachedText");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FPrimaryAssetId
{
    FPrimaryAssetType PrimaryAssetType; // 0x0 (Size: 0x4, Type: StructProperty)
    FName PrimaryAssetName; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FPrimaryAssetId) == 0x8, "Size mismatch for FPrimaryAssetId");
static_assert(offsetof(FPrimaryAssetId, PrimaryAssetType) == 0x0, "Offset mismatch for FPrimaryAssetId::PrimaryAssetType");
static_assert(offsetof(FPrimaryAssetId, PrimaryAssetName) == 0x4, "Offset mismatch for FPrimaryAssetId::PrimaryAssetName");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FPrimaryAssetType
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FPrimaryAssetType) == 0x4, "Size mismatch for FPrimaryAssetType");
static_assert(offsetof(FPrimaryAssetType, Name) == 0x0, "Offset mismatch for FPrimaryAssetType::Name");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FQualifiedFrameTime
{
    FFrameTime time; // 0x0 (Size: 0x8, Type: StructProperty)
    FFrameRate Rate; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FQualifiedFrameTime) == 0x10, "Size mismatch for FQualifiedFrameTime");
static_assert(offsetof(FQualifiedFrameTime, time) == 0x0, "Offset mismatch for FQualifiedFrameTime::time");
static_assert(offsetof(FQualifiedFrameTime, Rate) == 0x8, "Offset mismatch for FQualifiedFrameTime::Rate");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FQuat4d
{
    double X; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Z; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double W; // 0x18 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FQuat4d) == 0x20, "Size mismatch for FQuat4d");
static_assert(offsetof(FQuat4d, X) == 0x0, "Offset mismatch for FQuat4d::X");
static_assert(offsetof(FQuat4d, Y) == 0x8, "Offset mismatch for FQuat4d::Y");
static_assert(offsetof(FQuat4d, Z) == 0x10, "Offset mismatch for FQuat4d::Z");
static_assert(offsetof(FQuat4d, W) == 0x18, "Offset mismatch for FQuat4d::W");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FQuat4f
{
    float X; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Y; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Z; // 0x8 (Size: 0x4, Type: FloatProperty)
    float W; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FQuat4f) == 0x10, "Size mismatch for FQuat4f");
static_assert(offsetof(FQuat4f, X) == 0x0, "Offset mismatch for FQuat4f::X");
static_assert(offsetof(FQuat4f, Y) == 0x4, "Offset mismatch for FQuat4f::Y");
static_assert(offsetof(FQuat4f, Z) == 0x8, "Offset mismatch for FQuat4f::Z");
static_assert(offsetof(FQuat4f, W) == 0xc, "Offset mismatch for FQuat4f::W");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FRandomStream
{
    int32_t InitialSeed; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Seed; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FRandomStream) == 0x8, "Size mismatch for FRandomStream");
static_assert(offsetof(FRandomStream, InitialSeed) == 0x0, "Offset mismatch for FRandomStream::InitialSeed");
static_assert(offsetof(FRandomStream, Seed) == 0x4, "Offset mismatch for FRandomStream::Seed");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FRay
{
    FVector origin; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Direction; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRay) == 0x30, "Size mismatch for FRay");
static_assert(offsetof(FRay, origin) == 0x0, "Offset mismatch for FRay::origin");
static_assert(offsetof(FRay, Direction) == 0x18, "Offset mismatch for FRay::Direction");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FRay3d
{
    FVector3d origin; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector3d Direction; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRay3d) == 0x30, "Size mismatch for FRay3d");
static_assert(offsetof(FRay3d, origin) == 0x0, "Offset mismatch for FRay3d::origin");
static_assert(offsetof(FRay3d, Direction) == 0x18, "Offset mismatch for FRay3d::Direction");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FRay3f
{
    FVector3f origin; // 0x0 (Size: 0xc, Type: StructProperty)
    FVector3f Direction; // 0xc (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(FRay3f) == 0x18, "Size mismatch for FRay3f");
static_assert(offsetof(FRay3f, origin) == 0x0, "Offset mismatch for FRay3f::origin");
static_assert(offsetof(FRay3f, Direction) == 0xc, "Offset mismatch for FRay3f::Direction");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRemoteObjectBytes
{
    TArray<char> Bytes; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRemoteObjectBytes) == 0x10, "Size mismatch for FRemoteObjectBytes");
static_assert(offsetof(FRemoteObjectBytes, Bytes) == 0x0, "Offset mismatch for FRemoteObjectBytes::Bytes");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FRemoteObjectData
{
    TArray<FName> Names; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FRemoteObjectPathName> PathNames; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FRemoteObjectBytes> Bytes; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRemoteObjectData) == 0x30, "Size mismatch for FRemoteObjectData");
static_assert(offsetof(FRemoteObjectData, Names) == 0x0, "Offset mismatch for FRemoteObjectData::Names");
static_assert(offsetof(FRemoteObjectData, PathNames) == 0x10, "Offset mismatch for FRemoteObjectData::PathNames");
static_assert(offsetof(FRemoteObjectData, Bytes) == 0x20, "Offset mismatch for FRemoteObjectData::Bytes");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRemoteObjectPathName
{
    TArray<uint16_t> Names; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRemoteObjectPathName) == 0x10, "Size mismatch for FRemoteObjectPathName");
static_assert(offsetof(FRemoteObjectPathName, Names) == 0x0, "Offset mismatch for FRemoteObjectPathName::Names");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FRemoteObjectId
{
    uint64_t ID; // 0x0 (Size: 0x8, Type: UInt64Property)
};

static_assert(sizeof(FRemoteObjectId) == 0x8, "Size mismatch for FRemoteObjectId");
static_assert(offsetof(FRemoteObjectId, ID) == 0x0, "Offset mismatch for FRemoteObjectId::ID");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRemoteObjectReference
{
    FRemoteObjectId ObjectId; // 0x0 (Size: 0x8, Type: StructProperty)
    FRemoteServerId ServerId; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRemoteObjectReference) == 0x10, "Size mismatch for FRemoteObjectReference");
static_assert(offsetof(FRemoteObjectReference, ObjectId) == 0x0, "Offset mismatch for FRemoteObjectReference::ObjectId");
static_assert(offsetof(FRemoteObjectReference, ServerId) == 0x8, "Offset mismatch for FRemoteObjectReference::ServerId");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FRemoteServerId
{
    uint32_t ID; // 0x0 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FRemoteServerId) == 0x4, "Size mismatch for FRemoteServerId");
static_assert(offsetof(FRemoteServerId, ID) == 0x0, "Offset mismatch for FRemoteServerId::ID");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FRemoteTransactionId
{
    uint32_t ID; // 0x0 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FRemoteTransactionId) == 0x4, "Size mismatch for FRemoteTransactionId");
static_assert(offsetof(FRemoteTransactionId, ID) == 0x0, "Offset mismatch for FRemoteTransactionId::ID");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FRemoteWorkPriority
{
    uint64_t PackedData; // 0x0 (Size: 0x8, Type: UInt64Property)
};

static_assert(sizeof(FRemoteWorkPriority) == 0x8, "Size mismatch for FRemoteWorkPriority");
static_assert(offsetof(FRemoteWorkPriority, PackedData) == 0x0, "Offset mismatch for FRemoteWorkPriority::PackedData");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FRotator
{
    double pitch; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Yaw; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Roll; // 0x10 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FRotator) == 0x18, "Size mismatch for FRotator");
static_assert(offsetof(FRotator, pitch) == 0x0, "Offset mismatch for FRotator::pitch");
static_assert(offsetof(FRotator, Yaw) == 0x8, "Offset mismatch for FRotator::Yaw");
static_assert(offsetof(FRotator, Roll) == 0x10, "Offset mismatch for FRotator::Roll");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FRotator3d
{
    double pitch; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Yaw; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Roll; // 0x10 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FRotator3d) == 0x18, "Size mismatch for FRotator3d");
static_assert(offsetof(FRotator3d, pitch) == 0x0, "Offset mismatch for FRotator3d::pitch");
static_assert(offsetof(FRotator3d, Yaw) == 0x8, "Offset mismatch for FRotator3d::Yaw");
static_assert(offsetof(FRotator3d, Roll) == 0x10, "Offset mismatch for FRotator3d::Roll");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FRotator3f
{
    float pitch; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Yaw; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Roll; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRotator3f) == 0xc, "Size mismatch for FRotator3f");
static_assert(offsetof(FRotator3f, pitch) == 0x0, "Offset mismatch for FRotator3f::pitch");
static_assert(offsetof(FRotator3f, Yaw) == 0x4, "Offset mismatch for FRotator3f::Yaw");
static_assert(offsetof(FRotator3f, Roll) == 0x8, "Offset mismatch for FRotator3f::Roll");

// Size: 0x18 (Inherited: 0x18, Single: 0x0)
struct FSoftClassPath : FSoftObjectPath
{
};

static_assert(sizeof(FSoftClassPath) == 0x18, "Size mismatch for FSoftClassPath");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FSphere
{
    FVector Center; // 0x0 (Size: 0x18, Type: StructProperty)
    double W; // 0x18 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FSphere) == 0x20, "Size mismatch for FSphere");
static_assert(offsetof(FSphere, Center) == 0x0, "Offset mismatch for FSphere::Center");
static_assert(offsetof(FSphere, W) == 0x18, "Offset mismatch for FSphere::W");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FSphere3d
{
    FVector3d Center; // 0x0 (Size: 0x18, Type: StructProperty)
    double W; // 0x18 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FSphere3d) == 0x20, "Size mismatch for FSphere3d");
static_assert(offsetof(FSphere3d, Center) == 0x0, "Offset mismatch for FSphere3d::Center");
static_assert(offsetof(FSphere3d, W) == 0x18, "Offset mismatch for FSphere3d::W");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSphere3f
{
    FVector3f Center; // 0x0 (Size: 0xc, Type: StructProperty)
    float W; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FSphere3f) == 0x10, "Size mismatch for FSphere3f");
static_assert(offsetof(FSphere3f, Center) == 0x0, "Offset mismatch for FSphere3f::Center");
static_assert(offsetof(FSphere3f, W) == 0xc, "Offset mismatch for FSphere3f::W");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FTemplateString
{
    FString Template; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FTemplateString) == 0x10, "Size mismatch for FTemplateString");
static_assert(offsetof(FTemplateString, Template) == 0x0, "Offset mismatch for FTemplateString::Template");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FTestUndeclaredScriptStructObjectReferencesTest
{
    UObject* StrongObjectPointer; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UObject*> SoftObjectPointer; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    FSoftObjectPath SoftObjectPath; // 0x28 (Size: 0x18, Type: StructProperty)
    TWeakObjectPtr<UObject*> WeakObjectPointer; // 0x40 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FTestUndeclaredScriptStructObjectReferencesTest) == 0x48, "Size mismatch for FTestUndeclaredScriptStructObjectReferencesTest");
static_assert(offsetof(FTestUndeclaredScriptStructObjectReferencesTest, StrongObjectPointer) == 0x0, "Offset mismatch for FTestUndeclaredScriptStructObjectReferencesTest::StrongObjectPointer");
static_assert(offsetof(FTestUndeclaredScriptStructObjectReferencesTest, SoftObjectPointer) == 0x8, "Offset mismatch for FTestUndeclaredScriptStructObjectReferencesTest::SoftObjectPointer");
static_assert(offsetof(FTestUndeclaredScriptStructObjectReferencesTest, SoftObjectPath) == 0x28, "Offset mismatch for FTestUndeclaredScriptStructObjectReferencesTest::SoftObjectPath");
static_assert(offsetof(FTestUndeclaredScriptStructObjectReferencesTest, WeakObjectPointer) == 0x40, "Offset mismatch for FTestUndeclaredScriptStructObjectReferencesTest::WeakObjectPointer");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FTestUninitializedScriptStructMembersTest
{
    UObject* UninitializedObjectReference; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UObject* InitializedObjectReference; // 0x8 (Size: 0x8, Type: ObjectProperty)
    float UnusedValue; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FTestUninitializedScriptStructMembersTest) == 0x18, "Size mismatch for FTestUninitializedScriptStructMembersTest");
static_assert(offsetof(FTestUninitializedScriptStructMembersTest, UninitializedObjectReference) == 0x0, "Offset mismatch for FTestUninitializedScriptStructMembersTest::UninitializedObjectReference");
static_assert(offsetof(FTestUninitializedScriptStructMembersTest, InitializedObjectReference) == 0x8, "Offset mismatch for FTestUninitializedScriptStructMembersTest::InitializedObjectReference");
static_assert(offsetof(FTestUninitializedScriptStructMembersTest, UnusedValue) == 0x10, "Offset mismatch for FTestUninitializedScriptStructMembersTest::UnusedValue");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FTimecode
{
    int32_t Hours; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Minutes; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Seconds; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t Frames; // 0xc (Size: 0x4, Type: IntProperty)
    float SubFrame; // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bDropFrameFormat; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FTimecode) == 0x18, "Size mismatch for FTimecode");
static_assert(offsetof(FTimecode, Hours) == 0x0, "Offset mismatch for FTimecode::Hours");
static_assert(offsetof(FTimecode, Minutes) == 0x4, "Offset mismatch for FTimecode::Minutes");
static_assert(offsetof(FTimecode, Seconds) == 0x8, "Offset mismatch for FTimecode::Seconds");
static_assert(offsetof(FTimecode, Frames) == 0xc, "Offset mismatch for FTimecode::Frames");
static_assert(offsetof(FTimecode, SubFrame) == 0x10, "Offset mismatch for FTimecode::SubFrame");
static_assert(offsetof(FTimecode, bDropFrameFormat) == 0x14, "Offset mismatch for FTimecode::bDropFrameFormat");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FTimespan
{
    int64_t Ticks; // 0x0 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FTimespan) == 0x8, "Size mismatch for FTimespan");
static_assert(offsetof(FTimespan, Ticks) == 0x0, "Offset mismatch for FTimespan::Ticks");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FTransform
{
    FQuat Rotation; // 0x0 (Size: 0x20, Type: StructProperty)
    FVector Translation; // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    FVector Scale3D; // 0x40 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FTransform) == 0x60, "Size mismatch for FTransform");
static_assert(offsetof(FTransform, Rotation) == 0x0, "Offset mismatch for FTransform::Rotation");
static_assert(offsetof(FTransform, Translation) == 0x20, "Offset mismatch for FTransform::Translation");
static_assert(offsetof(FTransform, Scale3D) == 0x40, "Offset mismatch for FTransform::Scale3D");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FTransform3d
{
    FQuat4d Rotation; // 0x0 (Size: 0x20, Type: StructProperty)
    FVector3d Translation; // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    FVector3d Scale3D; // 0x40 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FTransform3d) == 0x60, "Size mismatch for FTransform3d");
static_assert(offsetof(FTransform3d, Rotation) == 0x0, "Offset mismatch for FTransform3d::Rotation");
static_assert(offsetof(FTransform3d, Translation) == 0x20, "Offset mismatch for FTransform3d::Translation");
static_assert(offsetof(FTransform3d, Scale3D) == 0x40, "Offset mismatch for FTransform3d::Scale3D");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FTransform3f
{
    FQuat4f Rotation; // 0x0 (Size: 0x10, Type: StructProperty)
    FVector3f Translation; // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FVector3f Scale3D; // 0x20 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FTransform3f) == 0x30, "Size mismatch for FTransform3f");
static_assert(offsetof(FTransform3f, Rotation) == 0x0, "Offset mismatch for FTransform3f::Rotation");
static_assert(offsetof(FTransform3f, Translation) == 0x10, "Offset mismatch for FTransform3f::Translation");
static_assert(offsetof(FTransform3f, Scale3D) == 0x20, "Offset mismatch for FTransform3f::Scale3D");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FUint32Point
{
    int32_t X; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FUint32Point) == 0x8, "Size mismatch for FUint32Point");
static_assert(offsetof(FUint32Point, X) == 0x0, "Offset mismatch for FUint32Point::X");
static_assert(offsetof(FUint32Point, Y) == 0x4, "Offset mismatch for FUint32Point::Y");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FUint32Rect
{
    FUint32Point Min; // 0x0 (Size: 0x8, Type: StructProperty)
    FUint32Point Max; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FUint32Rect) == 0x10, "Size mismatch for FUint32Rect");
static_assert(offsetof(FUint32Rect, Min) == 0x0, "Offset mismatch for FUint32Rect::Min");
static_assert(offsetof(FUint32Rect, Max) == 0x8, "Offset mismatch for FUint32Rect::Max");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FUint32Vector
{
    uint32_t X; // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Y; // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t Z; // 0x8 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FUint32Vector) == 0xc, "Size mismatch for FUint32Vector");
static_assert(offsetof(FUint32Vector, X) == 0x0, "Offset mismatch for FUint32Vector::X");
static_assert(offsetof(FUint32Vector, Y) == 0x4, "Offset mismatch for FUint32Vector::Y");
static_assert(offsetof(FUint32Vector, Z) == 0x8, "Offset mismatch for FUint32Vector::Z");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FUint32Vector2
{
    uint32_t X; // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Y; // 0x4 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FUint32Vector2) == 0x8, "Size mismatch for FUint32Vector2");
static_assert(offsetof(FUint32Vector2, X) == 0x0, "Offset mismatch for FUint32Vector2::X");
static_assert(offsetof(FUint32Vector2, Y) == 0x4, "Offset mismatch for FUint32Vector2::Y");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FUint32Vector4
{
    uint32_t X; // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Y; // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t Z; // 0x8 (Size: 0x4, Type: UInt32Property)
    uint32_t W; // 0xc (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FUint32Vector4) == 0x10, "Size mismatch for FUint32Vector4");
static_assert(offsetof(FUint32Vector4, X) == 0x0, "Offset mismatch for FUint32Vector4::X");
static_assert(offsetof(FUint32Vector4, Y) == 0x4, "Offset mismatch for FUint32Vector4::Y");
static_assert(offsetof(FUint32Vector4, Z) == 0x8, "Offset mismatch for FUint32Vector4::Z");
static_assert(offsetof(FUint32Vector4, W) == 0xc, "Offset mismatch for FUint32Vector4::W");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FUint64Point
{
    int64_t X; // 0x0 (Size: 0x8, Type: Int64Property)
    int64_t Y; // 0x8 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FUint64Point) == 0x10, "Size mismatch for FUint64Point");
static_assert(offsetof(FUint64Point, X) == 0x0, "Offset mismatch for FUint64Point::X");
static_assert(offsetof(FUint64Point, Y) == 0x8, "Offset mismatch for FUint64Point::Y");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FUint64Rect
{
    FUint64Point Min; // 0x0 (Size: 0x10, Type: StructProperty)
    FUint64Point Max; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FUint64Rect) == 0x20, "Size mismatch for FUint64Rect");
static_assert(offsetof(FUint64Rect, Min) == 0x0, "Offset mismatch for FUint64Rect::Min");
static_assert(offsetof(FUint64Rect, Max) == 0x10, "Offset mismatch for FUint64Rect::Max");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FUint64Vector
{
    uint64_t X; // 0x0 (Size: 0x8, Type: UInt64Property)
    uint64_t Y; // 0x8 (Size: 0x8, Type: UInt64Property)
    uint64_t Z; // 0x10 (Size: 0x8, Type: UInt64Property)
};

static_assert(sizeof(FUint64Vector) == 0x18, "Size mismatch for FUint64Vector");
static_assert(offsetof(FUint64Vector, X) == 0x0, "Offset mismatch for FUint64Vector::X");
static_assert(offsetof(FUint64Vector, Y) == 0x8, "Offset mismatch for FUint64Vector::Y");
static_assert(offsetof(FUint64Vector, Z) == 0x10, "Offset mismatch for FUint64Vector::Z");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FUint64Vector2
{
    uint64_t X; // 0x0 (Size: 0x8, Type: UInt64Property)
    uint64_t Y; // 0x8 (Size: 0x8, Type: UInt64Property)
};

static_assert(sizeof(FUint64Vector2) == 0x10, "Size mismatch for FUint64Vector2");
static_assert(offsetof(FUint64Vector2, X) == 0x0, "Offset mismatch for FUint64Vector2::X");
static_assert(offsetof(FUint64Vector2, Y) == 0x8, "Offset mismatch for FUint64Vector2::Y");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FUint64Vector4
{
    uint64_t X; // 0x0 (Size: 0x8, Type: UInt64Property)
    uint64_t Y; // 0x8 (Size: 0x8, Type: UInt64Property)
    uint64_t Z; // 0x10 (Size: 0x8, Type: UInt64Property)
    uint64_t W; // 0x18 (Size: 0x8, Type: UInt64Property)
};

static_assert(sizeof(FUint64Vector4) == 0x20, "Size mismatch for FUint64Vector4");
static_assert(offsetof(FUint64Vector4, X) == 0x0, "Offset mismatch for FUint64Vector4::X");
static_assert(offsetof(FUint64Vector4, Y) == 0x8, "Offset mismatch for FUint64Vector4::Y");
static_assert(offsetof(FUint64Vector4, Z) == 0x10, "Offset mismatch for FUint64Vector4::Z");
static_assert(offsetof(FUint64Vector4, W) == 0x18, "Offset mismatch for FUint64Vector4::W");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FUintPoint
{
    int32_t X; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FUintPoint) == 0x8, "Size mismatch for FUintPoint");
static_assert(offsetof(FUintPoint, X) == 0x0, "Offset mismatch for FUintPoint::X");
static_assert(offsetof(FUintPoint, Y) == 0x4, "Offset mismatch for FUintPoint::Y");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FUintRect
{
    FUintPoint Min; // 0x0 (Size: 0x8, Type: StructProperty)
    FUintPoint Max; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FUintRect) == 0x10, "Size mismatch for FUintRect");
static_assert(offsetof(FUintRect, Min) == 0x0, "Offset mismatch for FUintRect::Min");
static_assert(offsetof(FUintRect, Max) == 0x8, "Offset mismatch for FUintRect::Max");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FUintVector
{
    uint32_t X; // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Y; // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t Z; // 0x8 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FUintVector) == 0xc, "Size mismatch for FUintVector");
static_assert(offsetof(FUintVector, X) == 0x0, "Offset mismatch for FUintVector::X");
static_assert(offsetof(FUintVector, Y) == 0x4, "Offset mismatch for FUintVector::Y");
static_assert(offsetof(FUintVector, Z) == 0x8, "Offset mismatch for FUintVector::Z");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FUintVector2
{
    uint32_t X; // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Y; // 0x4 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FUintVector2) == 0x8, "Size mismatch for FUintVector2");
static_assert(offsetof(FUintVector2, X) == 0x0, "Offset mismatch for FUintVector2::X");
static_assert(offsetof(FUintVector2, Y) == 0x4, "Offset mismatch for FUintVector2::Y");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FUintVector4
{
    uint32_t X; // 0x0 (Size: 0x4, Type: UInt32Property)
    uint32_t Y; // 0x4 (Size: 0x4, Type: UInt32Property)
    uint32_t Z; // 0x8 (Size: 0x4, Type: UInt32Property)
    uint32_t W; // 0xc (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FUintVector4) == 0x10, "Size mismatch for FUintVector4");
static_assert(offsetof(FUintVector4, X) == 0x0, "Offset mismatch for FUintVector4::X");
static_assert(offsetof(FUintVector4, Y) == 0x4, "Offset mismatch for FUintVector4::Y");
static_assert(offsetof(FUintVector4, Z) == 0x8, "Offset mismatch for FUintVector4::Z");
static_assert(offsetof(FUintVector4, W) == 0xc, "Offset mismatch for FUintVector4::W");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FVector4
{
    double X; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Z; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double W; // 0x18 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FVector4) == 0x20, "Size mismatch for FVector4");
static_assert(offsetof(FVector4, X) == 0x0, "Offset mismatch for FVector4::X");
static_assert(offsetof(FVector4, Y) == 0x8, "Offset mismatch for FVector4::Y");
static_assert(offsetof(FVector4, Z) == 0x10, "Offset mismatch for FVector4::Z");
static_assert(offsetof(FVector4, W) == 0x18, "Offset mismatch for FVector4::W");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FVector4d
{
    double X; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Y; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Z; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double W; // 0x18 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FVector4d) == 0x20, "Size mismatch for FVector4d");
static_assert(offsetof(FVector4d, X) == 0x0, "Offset mismatch for FVector4d::X");
static_assert(offsetof(FVector4d, Y) == 0x8, "Offset mismatch for FVector4d::Y");
static_assert(offsetof(FVector4d, Z) == 0x10, "Offset mismatch for FVector4d::Z");
static_assert(offsetof(FVector4d, W) == 0x18, "Offset mismatch for FVector4d::W");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FVector4f
{
    float X; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Y; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Z; // 0x8 (Size: 0x4, Type: FloatProperty)
    float W; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FVector4f) == 0x10, "Size mismatch for FVector4f");
static_assert(offsetof(FVector4f, X) == 0x0, "Offset mismatch for FVector4f::X");
static_assert(offsetof(FVector4f, Y) == 0x4, "Offset mismatch for FVector4f::Y");
static_assert(offsetof(FVector4f, Z) == 0x8, "Offset mismatch for FVector4f::Z");
static_assert(offsetof(FVector4f, W) == 0xc, "Offset mismatch for FVector4f::W");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInstancedStruct
{
};

static_assert(sizeof(FInstancedStruct) == 0x10, "Size mismatch for FInstancedStruct");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSharedStruct
{
};

static_assert(sizeof(FSharedStruct) == 0x10, "Size mismatch for FSharedStruct");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInstancedPropertyBag
{
    FInstancedStruct Value; // 0x0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FInstancedPropertyBag) == 0x10, "Size mismatch for FInstancedPropertyBag");
static_assert(offsetof(FInstancedPropertyBag, Value) == 0x0, "Offset mismatch for FInstancedPropertyBag::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FConstSharedStruct
{
};

static_assert(sizeof(FConstSharedStruct) == 0x10, "Size mismatch for FConstSharedStruct");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FOverriddenPropertyNodeID
{
    FName Path; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UObject* Object; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FOverriddenPropertyNodeID) == 0x10, "Size mismatch for FOverriddenPropertyNodeID");
static_assert(offsetof(FOverriddenPropertyNodeID, Path) == 0x0, "Offset mismatch for FOverriddenPropertyNodeID::Path");
static_assert(offsetof(FOverriddenPropertyNodeID, Object) == 0x8, "Offset mismatch for FOverriddenPropertyNodeID::Object");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FOverriddenPropertyNode
{
    FOverriddenPropertyNodeID NodeId; // 0x0 (Size: 0x10, Type: StructProperty)
    uint8_t Operation; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    TMap<FOverriddenPropertyNodeID, FOverriddenPropertyNodeID> SubPropertyNodeKeys; // 0x18 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FOverriddenPropertyNode) == 0x68, "Size mismatch for FOverriddenPropertyNode");
static_assert(offsetof(FOverriddenPropertyNode, NodeId) == 0x0, "Offset mismatch for FOverriddenPropertyNode::NodeId");
static_assert(offsetof(FOverriddenPropertyNode, Operation) == 0x10, "Offset mismatch for FOverriddenPropertyNode::Operation");
static_assert(offsetof(FOverriddenPropertyNode, SubPropertyNodeKeys) == 0x18, "Offset mismatch for FOverriddenPropertyNode::SubPropertyNodeKeys");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FOverriddenPropertySet
{
    UObject* Owner; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bWasAdded; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    TSet<FOverriddenPropertyNode> OverriddenPropertyNodes; // 0x10 (Size: 0x50, Type: SetProperty)
    uint8_t Pad_60[0x8]; // 0x60 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FOverriddenPropertySet) == 0x68, "Size mismatch for FOverriddenPropertySet");
static_assert(offsetof(FOverriddenPropertySet, Owner) == 0x0, "Offset mismatch for FOverriddenPropertySet::Owner");
static_assert(offsetof(FOverriddenPropertySet, bWasAdded) == 0x8, "Offset mismatch for FOverriddenPropertySet::bWasAdded");
static_assert(offsetof(FOverriddenPropertySet, OverriddenPropertyNodes) == 0x10, "Offset mismatch for FOverriddenPropertySet::OverriddenPropertyNodes");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FTestPropertyPathFunctionsStructKey
{
    int32_t UNUSED; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Key; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FTestPropertyPathFunctionsStructKey) == 0x8, "Size mismatch for FTestPropertyPathFunctionsStructKey");
static_assert(offsetof(FTestPropertyPathFunctionsStructKey, UNUSED) == 0x0, "Offset mismatch for FTestPropertyPathFunctionsStructKey::UNUSED");
static_assert(offsetof(FTestPropertyPathFunctionsStructKey, Key) == 0x4, "Offset mismatch for FTestPropertyPathFunctionsStructKey::Key");

// Size: 0xe0 (Inherited: 0x0, Single: 0xe0)
struct FTestPropertyPathFunctionsStruct
{
    int32_t UNUSED; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t int32; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Int32StaticArray[0x8]; // 0x8 (Size: 0x20, Type: IntProperty)
    TArray<int32_t> Int32Array; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TSet<int32_t> Int32Set; // 0x38 (Size: 0x50, Type: SetProperty)
    TMap<int32_t, int32_t> Int32Map; // 0x88 (Size: 0x50, Type: MapProperty)
    uint8_t Int32Optional[0x8]; // 0xd8 (Size: 0x8, Type: OptionalProperty)
};

static_assert(sizeof(FTestPropertyPathFunctionsStruct) == 0xe0, "Size mismatch for FTestPropertyPathFunctionsStruct");
static_assert(offsetof(FTestPropertyPathFunctionsStruct, UNUSED) == 0x0, "Offset mismatch for FTestPropertyPathFunctionsStruct::UNUSED");
static_assert(offsetof(FTestPropertyPathFunctionsStruct, int32) == 0x4, "Offset mismatch for FTestPropertyPathFunctionsStruct::int32");
static_assert(offsetof(FTestPropertyPathFunctionsStruct, Int32StaticArray) == 0x8, "Offset mismatch for FTestPropertyPathFunctionsStruct::Int32StaticArray");
static_assert(offsetof(FTestPropertyPathFunctionsStruct, Int32Array) == 0x28, "Offset mismatch for FTestPropertyPathFunctionsStruct::Int32Array");
static_assert(offsetof(FTestPropertyPathFunctionsStruct, Int32Set) == 0x38, "Offset mismatch for FTestPropertyPathFunctionsStruct::Int32Set");
static_assert(offsetof(FTestPropertyPathFunctionsStruct, Int32Map) == 0x88, "Offset mismatch for FTestPropertyPathFunctionsStruct::Int32Map");
static_assert(offsetof(FTestPropertyPathFunctionsStruct, Int32Optional) == 0xd8, "Offset mismatch for FTestPropertyPathFunctionsStruct::Int32Optional");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FTestInstanceDataObjectPoint
{
    int32_t X; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Y; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t Z; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t W; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FTestInstanceDataObjectPoint) == 0x10, "Size mismatch for FTestInstanceDataObjectPoint");
static_assert(offsetof(FTestInstanceDataObjectPoint, X) == 0x0, "Offset mismatch for FTestInstanceDataObjectPoint::X");
static_assert(offsetof(FTestInstanceDataObjectPoint, Y) == 0x4, "Offset mismatch for FTestInstanceDataObjectPoint::Y");
static_assert(offsetof(FTestInstanceDataObjectPoint, Z) == 0x8, "Offset mismatch for FTestInstanceDataObjectPoint::Z");
static_assert(offsetof(FTestInstanceDataObjectPoint, W) == 0xc, "Offset mismatch for FTestInstanceDataObjectPoint::W");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FTestInstanceDataObjectPointAlternate
{
    int32_t U; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t V; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t W; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FTestInstanceDataObjectPointAlternate) == 0xc, "Size mismatch for FTestInstanceDataObjectPointAlternate");
static_assert(offsetof(FTestInstanceDataObjectPointAlternate, U) == 0x0, "Offset mismatch for FTestInstanceDataObjectPointAlternate::U");
static_assert(offsetof(FTestInstanceDataObjectPointAlternate, V) == 0x4, "Offset mismatch for FTestInstanceDataObjectPointAlternate::V");
static_assert(offsetof(FTestInstanceDataObjectPointAlternate, W) == 0x8, "Offset mismatch for FTestInstanceDataObjectPointAlternate::W");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FTestInstanceDataObjectStruct
{
    int32_t A; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t B; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t C; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t D; // 0xc (Size: 0x4, Type: IntProperty)
    TEnumAsByte<ETestInstanceDataObjectBird> Bird; // 0x10 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ETestInstanceDataObjectGrain> Grain; // 0x11 (Size: 0x1, Type: ByteProperty)
    uint8_t Fruit; // 0x12 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_13[0x1]; // 0x13 (Size: 0x1, Type: PaddingProperty)
    uint8_t Direction[0x2]; // 0x14 (Size: 0x2, Type: EnumProperty)
    uint8_t FullFlags; // 0x16 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<ETestInstanceDataObjectGrain> GrainFromEnumClass; // 0x17 (Size: 0x1, Type: ByteProperty)
    uint8_t FruitFromNamespace; // 0x18 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<ETestInstanceDataObjectGrain> GrainTypeChange; // 0x19 (Size: 0x1, Type: ByteProperty)
    uint8_t FruitTypeChange; // 0x1a (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<ETestInstanceDataObjectGrain> GrainTypeAndPropertyChange; // 0x1b (Size: 0x1, Type: ByteProperty)
    uint8_t FruitTypeAndPropertyChange; // 0x1c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
    FTestInstanceDataObjectPoint Point; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FTestInstanceDataObjectStruct) == 0x30, "Size mismatch for FTestInstanceDataObjectStruct");
static_assert(offsetof(FTestInstanceDataObjectStruct, A) == 0x0, "Offset mismatch for FTestInstanceDataObjectStruct::A");
static_assert(offsetof(FTestInstanceDataObjectStruct, B) == 0x4, "Offset mismatch for FTestInstanceDataObjectStruct::B");
static_assert(offsetof(FTestInstanceDataObjectStruct, C) == 0x8, "Offset mismatch for FTestInstanceDataObjectStruct::C");
static_assert(offsetof(FTestInstanceDataObjectStruct, D) == 0xc, "Offset mismatch for FTestInstanceDataObjectStruct::D");
static_assert(offsetof(FTestInstanceDataObjectStruct, Bird) == 0x10, "Offset mismatch for FTestInstanceDataObjectStruct::Bird");
static_assert(offsetof(FTestInstanceDataObjectStruct, Grain) == 0x11, "Offset mismatch for FTestInstanceDataObjectStruct::Grain");
static_assert(offsetof(FTestInstanceDataObjectStruct, Fruit) == 0x12, "Offset mismatch for FTestInstanceDataObjectStruct::Fruit");
static_assert(offsetof(FTestInstanceDataObjectStruct, Direction) == 0x14, "Offset mismatch for FTestInstanceDataObjectStruct::Direction");
static_assert(offsetof(FTestInstanceDataObjectStruct, FullFlags) == 0x16, "Offset mismatch for FTestInstanceDataObjectStruct::FullFlags");
static_assert(offsetof(FTestInstanceDataObjectStruct, GrainFromEnumClass) == 0x17, "Offset mismatch for FTestInstanceDataObjectStruct::GrainFromEnumClass");
static_assert(offsetof(FTestInstanceDataObjectStruct, FruitFromNamespace) == 0x18, "Offset mismatch for FTestInstanceDataObjectStruct::FruitFromNamespace");
static_assert(offsetof(FTestInstanceDataObjectStruct, GrainTypeChange) == 0x19, "Offset mismatch for FTestInstanceDataObjectStruct::GrainTypeChange");
static_assert(offsetof(FTestInstanceDataObjectStruct, FruitTypeChange) == 0x1a, "Offset mismatch for FTestInstanceDataObjectStruct::FruitTypeChange");
static_assert(offsetof(FTestInstanceDataObjectStruct, GrainTypeAndPropertyChange) == 0x1b, "Offset mismatch for FTestInstanceDataObjectStruct::GrainTypeAndPropertyChange");
static_assert(offsetof(FTestInstanceDataObjectStruct, FruitTypeAndPropertyChange) == 0x1c, "Offset mismatch for FTestInstanceDataObjectStruct::FruitTypeAndPropertyChange");
static_assert(offsetof(FTestInstanceDataObjectStruct, Point) == 0x20, "Offset mismatch for FTestInstanceDataObjectStruct::Point");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FTestInstanceDataObjectStructAlternate
{
    float B; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    int64_t C; // 0x8 (Size: 0x8, Type: Int64Property)
    int32_t D; // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t E; // 0x14 (Size: 0x4, Type: IntProperty)
    TEnumAsByte<ETestInstanceDataObjectBird> Bird; // 0x18 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ETestInstanceDataObjectGrainAlternate> Grain; // 0x19 (Size: 0x1, Type: ByteProperty)
    uint8_t Fruit; // 0x1a (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1b[0x1]; // 0x1b (Size: 0x1, Type: PaddingProperty)
    uint8_t Direction[0x2]; // 0x1c (Size: 0x2, Type: EnumProperty)
    uint8_t GrainFromEnumClass; // 0x1e (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<ETestInstanceDataObjectFruitAlternateNamespace> FruitFromNamespace; // 0x1f (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ETestInstanceDataObjectGrainAlternate> GrainTypeChange; // 0x20 (Size: 0x1, Type: ByteProperty)
    uint8_t FruitTypeChange; // 0x21 (Size: 0x1, Type: EnumProperty)
    uint8_t GrainTypeAndPropertyChange; // 0x22 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<ETestInstanceDataObjectFruitAlternateNamespace> FruitTypeAndPropertyChange; // 0x23 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ETestInstanceDataObjectGrainAlternate> DeletedGrain; // 0x24 (Size: 0x1, Type: ByteProperty)
    uint8_t DeletedFruit; // 0x25 (Size: 0x1, Type: EnumProperty)
    uint8_t DeletedDirection[0x2]; // 0x26 (Size: 0x2, Type: EnumProperty)
    FTestInstanceDataObjectPointAlternate Point; // 0x28 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FTestInstanceDataObjectStructAlternate) == 0x38, "Size mismatch for FTestInstanceDataObjectStructAlternate");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, B) == 0x0, "Offset mismatch for FTestInstanceDataObjectStructAlternate::B");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, C) == 0x8, "Offset mismatch for FTestInstanceDataObjectStructAlternate::C");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, D) == 0x10, "Offset mismatch for FTestInstanceDataObjectStructAlternate::D");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, E) == 0x14, "Offset mismatch for FTestInstanceDataObjectStructAlternate::E");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, Bird) == 0x18, "Offset mismatch for FTestInstanceDataObjectStructAlternate::Bird");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, Grain) == 0x19, "Offset mismatch for FTestInstanceDataObjectStructAlternate::Grain");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, Fruit) == 0x1a, "Offset mismatch for FTestInstanceDataObjectStructAlternate::Fruit");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, Direction) == 0x1c, "Offset mismatch for FTestInstanceDataObjectStructAlternate::Direction");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, GrainFromEnumClass) == 0x1e, "Offset mismatch for FTestInstanceDataObjectStructAlternate::GrainFromEnumClass");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, FruitFromNamespace) == 0x1f, "Offset mismatch for FTestInstanceDataObjectStructAlternate::FruitFromNamespace");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, GrainTypeChange) == 0x20, "Offset mismatch for FTestInstanceDataObjectStructAlternate::GrainTypeChange");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, FruitTypeChange) == 0x21, "Offset mismatch for FTestInstanceDataObjectStructAlternate::FruitTypeChange");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, GrainTypeAndPropertyChange) == 0x22, "Offset mismatch for FTestInstanceDataObjectStructAlternate::GrainTypeAndPropertyChange");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, FruitTypeAndPropertyChange) == 0x23, "Offset mismatch for FTestInstanceDataObjectStructAlternate::FruitTypeAndPropertyChange");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, DeletedGrain) == 0x24, "Offset mismatch for FTestInstanceDataObjectStructAlternate::DeletedGrain");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, DeletedFruit) == 0x25, "Offset mismatch for FTestInstanceDataObjectStructAlternate::DeletedFruit");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, DeletedDirection) == 0x26, "Offset mismatch for FTestInstanceDataObjectStructAlternate::DeletedDirection");
static_assert(offsetof(FTestInstanceDataObjectStructAlternate, Point) == 0x28, "Offset mismatch for FTestInstanceDataObjectStructAlternate::Point");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FPropertyTextFName
{
};

static_assert(sizeof(FPropertyTextFName) == 0x18, "Size mismatch for FPropertyTextFName");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FPropertyTextString
{
};

static_assert(sizeof(FPropertyTextString) == 0x20, "Size mismatch for FPropertyTextString");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FProfileLocus
{
};

static_assert(sizeof(FProfileLocus) == 0x30, "Size mismatch for FProfileLocus");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FSolarisProfilingData
{
};

static_assert(sizeof(FSolarisProfilingData) == 0x38, "Size mismatch for FSolarisProfilingData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInstancedStructContainer
{
};

static_assert(sizeof(FInstancedStructContainer) == 0x10, "Size mismatch for FInstancedStructContainer");

// Size: 0x3 (Inherited: 0x0, Single: 0x3)
struct FPropertyBagContainerTypes
{
};

static_assert(sizeof(FPropertyBagContainerTypes) == 0x3, "Size mismatch for FPropertyBagContainerTypes");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FPropertyBagPropertyDescMetaData
{
    FName Key; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FString Value; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FPropertyBagPropertyDescMetaData) == 0x18, "Size mismatch for FPropertyBagPropertyDescMetaData");
static_assert(offsetof(FPropertyBagPropertyDescMetaData, Key) == 0x0, "Offset mismatch for FPropertyBagPropertyDescMetaData::Key");
static_assert(offsetof(FPropertyBagPropertyDescMetaData, Value) == 0x8, "Offset mismatch for FPropertyBagPropertyDescMetaData::Value");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FPropertyBagPropertyDesc
{
    UObject* ValueTypeObject; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGuid ID; // 0x8 (Size: 0x10, Type: StructProperty)
    FName Name; // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t ValueType; // 0x1c (Size: 0x1, Type: EnumProperty)
    FPropertyBagContainerTypes ContainerTypes; // 0x1d (Size: 0x3, Type: StructProperty)
    uint64_t PropertyFlags; // 0x20 (Size: 0x8, Type: UInt64Property)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FPropertyBagPropertyDesc) == 0x30, "Size mismatch for FPropertyBagPropertyDesc");
static_assert(offsetof(FPropertyBagPropertyDesc, ValueTypeObject) == 0x0, "Offset mismatch for FPropertyBagPropertyDesc::ValueTypeObject");
static_assert(offsetof(FPropertyBagPropertyDesc, ID) == 0x8, "Offset mismatch for FPropertyBagPropertyDesc::ID");
static_assert(offsetof(FPropertyBagPropertyDesc, Name) == 0x18, "Offset mismatch for FPropertyBagPropertyDesc::Name");
static_assert(offsetof(FPropertyBagPropertyDesc, ValueType) == 0x1c, "Offset mismatch for FPropertyBagPropertyDesc::ValueType");
static_assert(offsetof(FPropertyBagPropertyDesc, ContainerTypes) == 0x1d, "Offset mismatch for FPropertyBagPropertyDesc::ContainerTypes");
static_assert(offsetof(FPropertyBagPropertyDesc, PropertyFlags) == 0x20, "Offset mismatch for FPropertyBagPropertyDesc::PropertyFlags");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FPropertyBagMissingStruct
{
};

static_assert(sizeof(FPropertyBagMissingStruct) == 0x1, "Size mismatch for FPropertyBagMissingStruct");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FObjectCookedMetaDataStore
{
    TMap<FString, FName> ObjectMetaData; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FObjectCookedMetaDataStore) == 0x50, "Size mismatch for FObjectCookedMetaDataStore");
static_assert(offsetof(FObjectCookedMetaDataStore, ObjectMetaData) == 0x0, "Offset mismatch for FObjectCookedMetaDataStore::ObjectMetaData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFieldCookedMetaDataKey
{
    TArray<FName> FieldPath; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFieldCookedMetaDataKey) == 0x10, "Size mismatch for FFieldCookedMetaDataKey");
static_assert(offsetof(FFieldCookedMetaDataKey, FieldPath) == 0x0, "Offset mismatch for FFieldCookedMetaDataKey::FieldPath");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FFieldCookedMetaDataValue
{
    TMap<FString, FName> MetaData; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FFieldCookedMetaDataValue) == 0x50, "Size mismatch for FFieldCookedMetaDataValue");
static_assert(offsetof(FFieldCookedMetaDataValue, MetaData) == 0x0, "Offset mismatch for FFieldCookedMetaDataValue::MetaData");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FFieldCookedMetaDataStore
{
    TMap<FString, FName> FieldMetaData; // 0x0 (Size: 0x50, Type: MapProperty)
    TMap<FFieldCookedMetaDataValue, FFieldCookedMetaDataKey> SubFieldMetaData; // 0x50 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FFieldCookedMetaDataStore) == 0xa0, "Size mismatch for FFieldCookedMetaDataStore");
static_assert(offsetof(FFieldCookedMetaDataStore, FieldMetaData) == 0x0, "Offset mismatch for FFieldCookedMetaDataStore::FieldMetaData");
static_assert(offsetof(FFieldCookedMetaDataStore, SubFieldMetaData) == 0x50, "Offset mismatch for FFieldCookedMetaDataStore::SubFieldMetaData");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FStructCookedMetaDataStore
{
    FObjectCookedMetaDataStore ObjectMetaData; // 0x0 (Size: 0x50, Type: StructProperty)
    TMap<FFieldCookedMetaDataStore, FName> PropertiesMetaData; // 0x50 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FStructCookedMetaDataStore) == 0xa0, "Size mismatch for FStructCookedMetaDataStore");
static_assert(offsetof(FStructCookedMetaDataStore, ObjectMetaData) == 0x0, "Offset mismatch for FStructCookedMetaDataStore::ObjectMetaData");
static_assert(offsetof(FStructCookedMetaDataStore, PropertiesMetaData) == 0x50, "Offset mismatch for FStructCookedMetaDataStore::PropertiesMetaData");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FPerPlatformInt
{
    int32_t Default; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FPerPlatformInt) == 0x4, "Size mismatch for FPerPlatformInt");
static_assert(offsetof(FPerPlatformInt, Default) == 0x0, "Offset mismatch for FPerPlatformInt::Default");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FFreezablePerPlatformInt
{
};

static_assert(sizeof(FFreezablePerPlatformInt) == 0x4, "Size mismatch for FFreezablePerPlatformInt");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FPerPlatformFloat
{
    float Default; // 0x0 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FPerPlatformFloat) == 0x4, "Size mismatch for FPerPlatformFloat");
static_assert(offsetof(FPerPlatformFloat, Default) == 0x0, "Offset mismatch for FPerPlatformFloat::Default");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FPerPlatformBool
{
    bool Default; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FPerPlatformBool) == 0x1, "Size mismatch for FPerPlatformBool");
static_assert(offsetof(FPerPlatformBool, Default) == 0x0, "Offset mismatch for FPerPlatformBool::Default");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FPerPlatformFrameRate
{
    FFrameRate Default; // 0x0 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FPerPlatformFrameRate) == 0x8, "Size mismatch for FPerPlatformFrameRate");
static_assert(offsetof(FPerPlatformFrameRate, Default) == 0x0, "Offset mismatch for FPerPlatformFrameRate::Default");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FVersePersistentVar
{
    FString Path; // 0x0 (Size: 0x10, Type: StrProperty)
    uint8_t Property[0x20]; // 0x10 (Size: 0x20, Type: FieldPathProperty)
};

static_assert(sizeof(FVersePersistentVar) == 0x30, "Size mismatch for FVersePersistentVar");
static_assert(offsetof(FVersePersistentVar, Path) == 0x0, "Offset mismatch for FVersePersistentVar::Path");
static_assert(offsetof(FVersePersistentVar, Property) == 0x10, "Offset mismatch for FVersePersistentVar::Property");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FVerseSessionVar
{
    uint8_t Property[0x20]; // 0x0 (Size: 0x20, Type: FieldPathProperty)
};

static_assert(sizeof(FVerseSessionVar) == 0x20, "Size mismatch for FVerseSessionVar");
static_assert(offsetof(FVerseSessionVar, Property) == 0x0, "Offset mismatch for FVerseSessionVar::Property");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FVerseClassVarAccessor
{
    UFunction* Func; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bIsInstanceMember; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bIsFallible; // 0x9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a[0x6]; // 0xa (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FVerseClassVarAccessor) == 0x10, "Size mismatch for FVerseClassVarAccessor");
static_assert(offsetof(FVerseClassVarAccessor, Func) == 0x0, "Offset mismatch for FVerseClassVarAccessor::Func");
static_assert(offsetof(FVerseClassVarAccessor, bIsInstanceMember) == 0x8, "Offset mismatch for FVerseClassVarAccessor::bIsInstanceMember");
static_assert(offsetof(FVerseClassVarAccessor, bIsFallible) == 0x9, "Offset mismatch for FVerseClassVarAccessor::bIsFallible");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FVerseClassVarAccessors
{
    TMap<FVerseClassVarAccessor, int32_t> Getters; // 0x0 (Size: 0x50, Type: MapProperty)
    TMap<FVerseClassVarAccessor, int32_t> Setters; // 0x50 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FVerseClassVarAccessors) == 0xa0, "Size mismatch for FVerseClassVarAccessors");
static_assert(offsetof(FVerseClassVarAccessors, Getters) == 0x0, "Offset mismatch for FVerseClassVarAccessors::Getters");
static_assert(offsetof(FVerseClassVarAccessors, Setters) == 0x50, "Offset mismatch for FVerseClassVarAccessors::Setters");

