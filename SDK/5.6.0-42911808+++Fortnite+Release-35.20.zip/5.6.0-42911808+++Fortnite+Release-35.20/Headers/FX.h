/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FX
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"

// Size: 0x3e (Inherited: 0x60, Single: 0xffffffde)
class UAnimNotify_Irwin_Footfalls_C : public UAnimNotify
{
public:
    int32_t FootfallsIndex; // 0x38 (Size: 0x4, Type: IntProperty)
    bool is_Running__; // 0x3c (Size: 0x1, Type: BoolProperty)
    bool is_Sprinting__; // 0x3d (Size: 0x1, Type: BoolProperty)

public:
    virtual bool Received_Notify(USkeletalMeshComponent*& MeshComp, UAnimSequenceBase*& Animation, const FAnimNotifyEventReference EventReference) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UAnimNotify_Irwin_Footfalls_C) == 0x3e, "Size mismatch for UAnimNotify_Irwin_Footfalls_C");
static_assert(offsetof(UAnimNotify_Irwin_Footfalls_C, FootfallsIndex) == 0x38, "Offset mismatch for UAnimNotify_Irwin_Footfalls_C::FootfallsIndex");
static_assert(offsetof(UAnimNotify_Irwin_Footfalls_C, is_Running__) == 0x3c, "Offset mismatch for UAnimNotify_Irwin_Footfalls_C::is_Running__");
static_assert(offsetof(UAnimNotify_Irwin_Footfalls_C, is_Sprinting__) == 0x3d, "Offset mismatch for UAnimNotify_Irwin_Footfalls_C::is_Sprinting__");

