/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRDPlayerTracker
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"
#include "UMG.h"
#include "FortniteGame.h"

// Size: 0xb8 (Inherited: 0xe0, Single: 0xffffffd8)
class UCRDPlayerTrackerComponent : public UActorComponent
{
public:
};

static_assert(sizeof(UCRDPlayerTrackerComponent) == 0xb8, "Size mismatch for UCRDPlayerTrackerComponent");

// Size: 0x2b8 (Inherited: 0x2d0, Single: 0xffffffe8)
class ACRDPlayerTrackerMarker : public AActor
{
public:
    UClass* WidgetClass; // 0x2a8 (Size: 0x8, Type: ClassProperty)
    UActorComponent* PlayerTrackerUIActorComponent; // 0x2b0 (Size: 0x8, Type: ObjectProperty)

public:
    UUserWidget* CreatePlayerTrackerWidget(AFortPlayerControllerGameplay*& InFortPlayerControllerGameplay, AFortPlayerStateAthena*& AssociatedPSA); // 0x11e6d198 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool DestroyPlayerTrackerWidget(AFortPlayerControllerGameplay*& InFortPlayerControllerGameplay); // 0x11e6d56c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ACRDPlayerTrackerMarker) == 0x2b8, "Size mismatch for ACRDPlayerTrackerMarker");
static_assert(offsetof(ACRDPlayerTrackerMarker, WidgetClass) == 0x2a8, "Offset mismatch for ACRDPlayerTrackerMarker::WidgetClass");
static_assert(offsetof(ACRDPlayerTrackerMarker, PlayerTrackerUIActorComponent) == 0x2b0, "Offset mismatch for ACRDPlayerTrackerMarker::PlayerTrackerUIActorComponent");

