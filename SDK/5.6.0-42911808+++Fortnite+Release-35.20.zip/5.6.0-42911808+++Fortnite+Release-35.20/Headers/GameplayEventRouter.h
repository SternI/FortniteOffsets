/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayEventRouter
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayMessages.h"

// Size: 0xb8 (Inherited: 0x58, Single: 0x60)
class UAsyncAction_StartListeningToEvent : public UBlueprintAsyncActionBase
{
public:
    uint8_t OnEventReceived[0x10]; // 0x30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_40[0x78]; // 0x40 (Size: 0x78, Type: PaddingProperty)

public:
    bool GetPayload(int32_t OutPayload); // 0x53d4e80 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    static UAsyncAction_StartListeningToEvent* StartListeningToEvent(UObject*& WorldContextObject, UGameplayEventRouterComponent*& Target, UScriptStruct*& EventType, UObject*& Context, EEventBubblingRule& EventBubblingRule); // 0x5034688 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAsyncAction_StartListeningToEvent* StartListeningToEventBackwardCompatible(UObject*& WorldContextObject, FEventMessageTag& Channel, UGameplayEventRouterComponent*& Target, UScriptStruct*& EventType, UObject*& Context, EEventBubblingRule& EventBubblingRule); // 0x5032db4 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    void StopListeningToEvent(); // 0x472ef98 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAsyncAction_StartListeningToEvent) == 0xb8, "Size mismatch for UAsyncAction_StartListeningToEvent");
static_assert(offsetof(UAsyncAction_StartListeningToEvent, OnEventReceived) == 0x30, "Offset mismatch for UAsyncAction_StartListeningToEvent::OnEventReceived");

// Size: 0xd8 (Inherited: 0x58, Single: 0x80)
class UAsyncAction_StartListeningToStatefulEvent : public UBlueprintAsyncActionBase
{
public:
    uint8_t OnEventReceived[0x10]; // 0x30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSavedEventStateExists[0x10]; // 0x40 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEventStateCleared[0x10]; // 0x50 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_60[0x78]; // 0x60 (Size: 0x78, Type: PaddingProperty)

public:
    bool GetPayload(int32_t OutPayload); // 0x5134144 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    static UAsyncAction_StartListeningToStatefulEvent* StartListeningToStatefulEvent(UObject*& WorldContextObject, UGameplayEventRouterComponent*& Target, UScriptStruct*& EventType, UObject*& Context, EEventBubblingRule& EventBubblingRule); // 0x5033abc (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAsyncAction_StartListeningToStatefulEvent* StartListeningToStatefulEventBackwardsCompatible(UObject*& WorldContextObject, FEventMessageTag& Channel, UGameplayEventRouterComponent*& Target, UScriptStruct*& EventType, UObject*& Context, EEventBubblingRule& EventBubblingRule); // 0xafff128 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    void StopListeningToStatefulEvent(); // 0x472ef98 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAsyncAction_StartListeningToStatefulEvent) == 0xd8, "Size mismatch for UAsyncAction_StartListeningToStatefulEvent");
static_assert(offsetof(UAsyncAction_StartListeningToStatefulEvent, OnEventReceived) == 0x30, "Offset mismatch for UAsyncAction_StartListeningToStatefulEvent::OnEventReceived");
static_assert(offsetof(UAsyncAction_StartListeningToStatefulEvent, OnSavedEventStateExists) == 0x40, "Offset mismatch for UAsyncAction_StartListeningToStatefulEvent::OnSavedEventStateExists");
static_assert(offsetof(UAsyncAction_StartListeningToStatefulEvent, OnEventStateCleared) == 0x50, "Offset mismatch for UAsyncAction_StartListeningToStatefulEvent::OnEventStateCleared");

// Size: 0x2f0 (Inherited: 0xe0, Single: 0x210)
class UGameplayEventRouterComponent : public UActorComponent
{
public:

public:
    void ClearEventState(UScriptStruct*& const EventType); // 0xaffdca0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void ClearEventStateByContext(UScriptStruct*& const EventType, UObject*& const Context); // 0xaffe07c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    bool HasValidEventState(UScriptStruct*& const EventType, UObject*& const Context) const; // 0xaffe5a0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void StopListeningToEvent(FGameplayEventListenerHandle HandleToRemove); // 0xafff468 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

protected:
    bool K2_BroadcastEvent(const int32_t EventData, UObject*& EventContext); // 0x555506c (Index: 0x3, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    bool K2_BroadcastStatefulEvent(const int32_t EventData, UObject*& EventContext); // 0xaffeba0 (Index: 0x4, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGameplayEventRouterComponent) == 0x2f0, "Size mismatch for UGameplayEventRouterComponent");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameplayEventRouterOwnerInterface : public UInterface
{
public:

protected:
    virtual UClass* GetEventRouterClass() const; // 0x528401c (Index: 0x0, Flags: Native|Event|Protected|BlueprintEvent|Const)
};

static_assert(sizeof(UGameplayEventRouterOwnerInterface) == 0x28, "Size mismatch for UGameplayEventRouterOwnerInterface");

// Size: 0x198 (Inherited: 0x88, Single: 0x110)
class UGameplayEventRouterSubsystem : public UGameInstanceSubsystem
{
public:
    uint8_t Pad_30[0x158]; // 0x30 (Size: 0x158, Type: PaddingProperty)
    TArray<FGameplayEventGlobalRouterPendingListenerData> PendingGlobalRouterListenerDatas; // 0x188 (Size: 0x10, Type: ArrayProperty)

public:
    static void ClearEventStateBackwardCompatible(UObject*& WorldContextObject, FEventMessageTag& Channel, UGameplayEventRouterComponent*& Target, UScriptStruct*& const EventType); // 0xaffddcc (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ClearEventStateByContextBackwardCompatible(UObject*& WorldContextObject, FEventMessageTag& Channel, UGameplayEventRouterComponent*& Target, UScriptStruct*& const EventType, UObject*& const Context); // 0xaffe284 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UGameplayEventRouterComponent* GetEventRouter(UClass*& Scope, AActor*& ContextActor); // 0x5800540 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UGameplayEventRouterComponent* GetGlobalEventRouter(UObject*& const WorldContextObject); // 0x54c4558 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool K2_BroadcastEventBackwardCompatible(UObject*& WorldContextObject, UGameplayEventRouterComponent*& Target, FEventMessageTag& Channel, const int32_t EventData, UObject*& EventContext); // 0xaffe7bc (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool K2_BroadcastStatefulEventBackwardCompatible(UObject*& WorldContextObject, UGameplayEventRouterComponent*& Target, FEventMessageTag& Channel, const int32_t EventData, UObject*& EventContext); // 0xaffed44 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGameplayEventRouterSubsystem) == 0x198, "Size mismatch for UGameplayEventRouterSubsystem");
static_assert(offsetof(UGameplayEventRouterSubsystem, PendingGlobalRouterListenerDatas) == 0x188, "Offset mismatch for UGameplayEventRouterSubsystem::PendingGlobalRouterListenerDatas");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FGameplayEventListenerHandle
{
    int32_t Handle; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x8]; // 0x14 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayEventListenerHandle) == 0x1c, "Size mismatch for FGameplayEventListenerHandle");
static_assert(offsetof(FGameplayEventListenerHandle, Handle) == 0x10, "Offset mismatch for FGameplayEventListenerHandle::Handle");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayEventId
{
};

static_assert(sizeof(FGameplayEventId) == 0x10, "Size mismatch for FGameplayEventId");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FGameplayEventListenerBackwardCompatibleHandle
{
};

static_assert(sizeof(FGameplayEventListenerBackwardCompatibleHandle) == 0x48, "Size mismatch for FGameplayEventListenerBackwardCompatibleHandle");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FGameplayEventListenerData
{
    UScriptStruct* EventType; // 0x90 (Size: 0x8, Type: ObjectProperty)
    UObject* EventContext; // 0x98 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_a0[0x20]; // 0xa0 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayEventListenerData) == 0xc0, "Size mismatch for FGameplayEventListenerData");
static_assert(offsetof(FGameplayEventListenerData, EventType) == 0x90, "Offset mismatch for FGameplayEventListenerData::EventType");
static_assert(offsetof(FGameplayEventListenerData, EventContext) == 0x98, "Offset mismatch for FGameplayEventListenerData::EventContext");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FGameplayEventListenerList
{
};

static_assert(sizeof(FGameplayEventListenerList) == 0x38, "Size mismatch for FGameplayEventListenerList");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FGameplayEventGlobalRouterPendingListenerData
{
    UScriptStruct* EventType; // 0xb0 (Size: 0x8, Type: ObjectProperty)
    UObject* EventContext; // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGameplayEventGlobalRouterPendingListenerData) == 0xc0, "Size mismatch for FGameplayEventGlobalRouterPendingListenerData");
static_assert(offsetof(FGameplayEventGlobalRouterPendingListenerData, EventType) == 0xb0, "Offset mismatch for FGameplayEventGlobalRouterPendingListenerData::EventType");
static_assert(offsetof(FGameplayEventGlobalRouterPendingListenerData, EventContext) == 0xb8, "Offset mismatch for FGameplayEventGlobalRouterPendingListenerData::EventContext");

