/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ControlRigPhysics
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ControlRig.h"
#include "RigVM.h"
#include "PhysicsControl.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x180 (Inherited: 0x40, Single: 0x140)
struct FRigPhysicsBodyComponent : FRigBaseComponent
{
    FRigPhysicsBodySolverSettings BodySolverSettings; // 0x40 (Size: 0x20, Type: StructProperty)
    FRigPhysicsDynamics Dynamics; // 0x60 (Size: 0x50, Type: StructProperty)
    FRigPhysicsCollision Collision; // 0xb0 (Size: 0x40, Type: StructProperty)
    FPhysicsControlModifierData BodyData; // 0xf0 (Size: 0x10, Type: StructProperty)
    FTransform KinematicTarget; // 0x100 (Size: 0x60, Type: StructProperty)
    uint8_t KinematicTargetSpace; // 0x160 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_161[0x7]; // 0x161 (Size: 0x7, Type: PaddingProperty)
    TArray<FRigComponentKey> NoCollisionBodies; // 0x168 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_178[0x8]; // 0x178 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigPhysicsBodyComponent) == 0x180, "Size mismatch for FRigPhysicsBodyComponent");
static_assert(offsetof(FRigPhysicsBodyComponent, BodySolverSettings) == 0x40, "Offset mismatch for FRigPhysicsBodyComponent::BodySolverSettings");
static_assert(offsetof(FRigPhysicsBodyComponent, Dynamics) == 0x60, "Offset mismatch for FRigPhysicsBodyComponent::Dynamics");
static_assert(offsetof(FRigPhysicsBodyComponent, Collision) == 0xb0, "Offset mismatch for FRigPhysicsBodyComponent::Collision");
static_assert(offsetof(FRigPhysicsBodyComponent, BodyData) == 0xf0, "Offset mismatch for FRigPhysicsBodyComponent::BodyData");
static_assert(offsetof(FRigPhysicsBodyComponent, KinematicTarget) == 0x100, "Offset mismatch for FRigPhysicsBodyComponent::KinematicTarget");
static_assert(offsetof(FRigPhysicsBodyComponent, KinematicTargetSpace) == 0x160, "Offset mismatch for FRigPhysicsBodyComponent::KinematicTargetSpace");
static_assert(offsetof(FRigPhysicsBodyComponent, NoCollisionBodies) == 0x168, "Offset mismatch for FRigPhysicsBodyComponent::NoCollisionBodies");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FRigPhysicsCollision
{
    TArray<FRigPhysicsCollisionBox> Boxes; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigPhysicsCollisionSphere> Spheres; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigPhysicsCollisionCapsule> Capsules; // 0x20 (Size: 0x10, Type: ArrayProperty)
    FRigPhysicsMaterial Material; // 0x30 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigPhysicsCollision) == 0x40, "Size mismatch for FRigPhysicsCollision");
static_assert(offsetof(FRigPhysicsCollision, Boxes) == 0x0, "Offset mismatch for FRigPhysicsCollision::Boxes");
static_assert(offsetof(FRigPhysicsCollision, Spheres) == 0x10, "Offset mismatch for FRigPhysicsCollision::Spheres");
static_assert(offsetof(FRigPhysicsCollision, Capsules) == 0x20, "Offset mismatch for FRigPhysicsCollision::Capsules");
static_assert(offsetof(FRigPhysicsCollision, Material) == 0x30, "Offset mismatch for FRigPhysicsCollision::Material");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FRigPhysicsMaterial
{
    float Friction; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Restitution; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t FrictionCombineMode; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t RestitutionCombineMode; // 0x9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a[0x2]; // 0xa (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FRigPhysicsMaterial) == 0xc, "Size mismatch for FRigPhysicsMaterial");
static_assert(offsetof(FRigPhysicsMaterial, Friction) == 0x0, "Offset mismatch for FRigPhysicsMaterial::Friction");
static_assert(offsetof(FRigPhysicsMaterial, Restitution) == 0x4, "Offset mismatch for FRigPhysicsMaterial::Restitution");
static_assert(offsetof(FRigPhysicsMaterial, FrictionCombineMode) == 0x8, "Offset mismatch for FRigPhysicsMaterial::FrictionCombineMode");
static_assert(offsetof(FRigPhysicsMaterial, RestitutionCombineMode) == 0x9, "Offset mismatch for FRigPhysicsMaterial::RestitutionCombineMode");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FRigPhysicsCollisionShape
{
    float RestOffset; // 0x0 (Size: 0x4, Type: FloatProperty)
    FName Name; // 0x4 (Size: 0x4, Type: NameProperty)
    bool bContributeToMass; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigPhysicsCollisionShape) == 0xc, "Size mismatch for FRigPhysicsCollisionShape");
static_assert(offsetof(FRigPhysicsCollisionShape, RestOffset) == 0x0, "Offset mismatch for FRigPhysicsCollisionShape::RestOffset");
static_assert(offsetof(FRigPhysicsCollisionShape, Name) == 0x4, "Offset mismatch for FRigPhysicsCollisionShape::Name");
static_assert(offsetof(FRigPhysicsCollisionShape, bContributeToMass) == 0x8, "Offset mismatch for FRigPhysicsCollisionShape::bContributeToMass");

// Size: 0x80 (Inherited: 0xc, Single: 0x74)
struct FRigPhysicsCollisionCapsule : FRigPhysicsCollisionShape
{
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FTransform TM; // 0x10 (Size: 0x60, Type: StructProperty)
    float Radius; // 0x70 (Size: 0x4, Type: FloatProperty)
    float Length; // 0x74 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_78[0x8]; // 0x78 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigPhysicsCollisionCapsule) == 0x80, "Size mismatch for FRigPhysicsCollisionCapsule");
static_assert(offsetof(FRigPhysicsCollisionCapsule, TM) == 0x10, "Offset mismatch for FRigPhysicsCollisionCapsule::TM");
static_assert(offsetof(FRigPhysicsCollisionCapsule, Radius) == 0x70, "Offset mismatch for FRigPhysicsCollisionCapsule::Radius");
static_assert(offsetof(FRigPhysicsCollisionCapsule, Length) == 0x74, "Offset mismatch for FRigPhysicsCollisionCapsule::Length");

// Size: 0x80 (Inherited: 0xc, Single: 0x74)
struct FRigPhysicsCollisionSphere : FRigPhysicsCollisionShape
{
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FTransform TM; // 0x10 (Size: 0x60, Type: StructProperty)
    float Radius; // 0x70 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_74[0xc]; // 0x74 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FRigPhysicsCollisionSphere) == 0x80, "Size mismatch for FRigPhysicsCollisionSphere");
static_assert(offsetof(FRigPhysicsCollisionSphere, TM) == 0x10, "Offset mismatch for FRigPhysicsCollisionSphere::TM");
static_assert(offsetof(FRigPhysicsCollisionSphere, Radius) == 0x70, "Offset mismatch for FRigPhysicsCollisionSphere::Radius");

// Size: 0x90 (Inherited: 0xc, Single: 0x84)
struct FRigPhysicsCollisionBox : FRigPhysicsCollisionShape
{
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FTransform TM; // 0x10 (Size: 0x60, Type: StructProperty)
    FVector Extents; // 0x70 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigPhysicsCollisionBox) == 0x90, "Size mismatch for FRigPhysicsCollisionBox");
static_assert(offsetof(FRigPhysicsCollisionBox, TM) == 0x10, "Offset mismatch for FRigPhysicsCollisionBox::TM");
static_assert(offsetof(FRigPhysicsCollisionBox, Extents) == 0x70, "Offset mismatch for FRigPhysicsCollisionBox::Extents");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FRigPhysicsDynamics
{
    float Density; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MassOverride; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bOverrideCentreOfMass; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    FVector CentreOfMassOverride; // 0x10 (Size: 0x18, Type: StructProperty)
    bool bOverrideMomentsOfInertia; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    FVector MomentsOfInertiaOverride; // 0x30 (Size: 0x18, Type: StructProperty)
    float LinearDamping; // 0x48 (Size: 0x4, Type: FloatProperty)
    float AngularDamping; // 0x4c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigPhysicsDynamics) == 0x50, "Size mismatch for FRigPhysicsDynamics");
static_assert(offsetof(FRigPhysicsDynamics, Density) == 0x0, "Offset mismatch for FRigPhysicsDynamics::Density");
static_assert(offsetof(FRigPhysicsDynamics, MassOverride) == 0x4, "Offset mismatch for FRigPhysicsDynamics::MassOverride");
static_assert(offsetof(FRigPhysicsDynamics, bOverrideCentreOfMass) == 0x8, "Offset mismatch for FRigPhysicsDynamics::bOverrideCentreOfMass");
static_assert(offsetof(FRigPhysicsDynamics, CentreOfMassOverride) == 0x10, "Offset mismatch for FRigPhysicsDynamics::CentreOfMassOverride");
static_assert(offsetof(FRigPhysicsDynamics, bOverrideMomentsOfInertia) == 0x28, "Offset mismatch for FRigPhysicsDynamics::bOverrideMomentsOfInertia");
static_assert(offsetof(FRigPhysicsDynamics, MomentsOfInertiaOverride) == 0x30, "Offset mismatch for FRigPhysicsDynamics::MomentsOfInertiaOverride");
static_assert(offsetof(FRigPhysicsDynamics, LinearDamping) == 0x48, "Offset mismatch for FRigPhysicsDynamics::LinearDamping");
static_assert(offsetof(FRigPhysicsDynamics, AngularDamping) == 0x4c, "Offset mismatch for FRigPhysicsDynamics::AngularDamping");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FRigPhysicsBodySolverSettings
{
    FRigComponentKey PhysicsSolverComponentKey; // 0x0 (Size: 0xc, Type: StructProperty)
    bool bUseAutomaticSolver; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FRigElementKey SourceBone; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey TargetBone; // 0x18 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigPhysicsBodySolverSettings) == 0x20, "Size mismatch for FRigPhysicsBodySolverSettings");
static_assert(offsetof(FRigPhysicsBodySolverSettings, PhysicsSolverComponentKey) == 0x0, "Offset mismatch for FRigPhysicsBodySolverSettings::PhysicsSolverComponentKey");
static_assert(offsetof(FRigPhysicsBodySolverSettings, bUseAutomaticSolver) == 0xc, "Offset mismatch for FRigPhysicsBodySolverSettings::bUseAutomaticSolver");
static_assert(offsetof(FRigPhysicsBodySolverSettings, SourceBone) == 0x10, "Offset mismatch for FRigPhysicsBodySolverSettings::SourceBone");
static_assert(offsetof(FRigPhysicsBodySolverSettings, TargetBone) == 0x18, "Offset mismatch for FRigPhysicsBodySolverSettings::TargetBone");

// Size: 0x188 (Inherited: 0x40, Single: 0x148)
struct FRigPhysicsControlComponent : FRigBaseComponent
{
    FRigComponentKey ParentBodyComponentKey; // 0x40 (Size: 0xc, Type: StructProperty)
    bool bUseParentBodyAsDefault; // 0x4c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4d[0x3]; // 0x4d (Size: 0x3, Type: PaddingProperty)
    FRigComponentKey ChildBodyComponentKey; // 0x50 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    FPhysicsControlData ControlData; // 0x60 (Size: 0x50, Type: StructProperty)
    FPhysicsControlMultiplier ControlMultiplier; // 0xb0 (Size: 0x70, Type: StructProperty)
    FPhysicsControlTarget ControlTarget; // 0x120 (Size: 0x68, Type: StructProperty)
};

static_assert(sizeof(FRigPhysicsControlComponent) == 0x188, "Size mismatch for FRigPhysicsControlComponent");
static_assert(offsetof(FRigPhysicsControlComponent, ParentBodyComponentKey) == 0x40, "Offset mismatch for FRigPhysicsControlComponent::ParentBodyComponentKey");
static_assert(offsetof(FRigPhysicsControlComponent, bUseParentBodyAsDefault) == 0x4c, "Offset mismatch for FRigPhysicsControlComponent::bUseParentBodyAsDefault");
static_assert(offsetof(FRigPhysicsControlComponent, ChildBodyComponentKey) == 0x50, "Offset mismatch for FRigPhysicsControlComponent::ChildBodyComponentKey");
static_assert(offsetof(FRigPhysicsControlComponent, ControlData) == 0x60, "Offset mismatch for FRigPhysicsControlComponent::ControlData");
static_assert(offsetof(FRigPhysicsControlComponent, ControlMultiplier) == 0xb0, "Offset mismatch for FRigPhysicsControlComponent::ControlMultiplier");
static_assert(offsetof(FRigPhysicsControlComponent, ControlTarget) == 0x120, "Offset mismatch for FRigPhysicsControlComponent::ControlTarget");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigPhysicsVisualizationSettings
{
    bool bEnableVisualization; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float LineThickness; // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t ShapeSize; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t ShapeDetail; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FRigPhysicsVisualizationSettings) == 0x10, "Size mismatch for FRigPhysicsVisualizationSettings");
static_assert(offsetof(FRigPhysicsVisualizationSettings, bEnableVisualization) == 0x0, "Offset mismatch for FRigPhysicsVisualizationSettings::bEnableVisualization");
static_assert(offsetof(FRigPhysicsVisualizationSettings, LineThickness) == 0x4, "Offset mismatch for FRigPhysicsVisualizationSettings::LineThickness");
static_assert(offsetof(FRigPhysicsVisualizationSettings, ShapeSize) == 0x8, "Offset mismatch for FRigPhysicsVisualizationSettings::ShapeSize");
static_assert(offsetof(FRigPhysicsVisualizationSettings, ShapeDetail) == 0xc, "Offset mismatch for FRigPhysicsVisualizationSettings::ShapeDetail");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FRigPhysicsSimulationSpaceSettings
{
    float SpaceMovementAmount; // 0x0 (Size: 0x4, Type: FloatProperty)
    float VelocityScaleZ; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bClampLinearVelocity; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    float MaxLinearVelocity; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bClampAngularVelocity; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float MaxAngularVelocity; // 0x14 (Size: 0x4, Type: FloatProperty)
    bool bClampLinearAcceleration; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
    float MaxLinearAcceleration; // 0x1c (Size: 0x4, Type: FloatProperty)
    bool bClampAngularAcceleration; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x3]; // 0x21 (Size: 0x3, Type: PaddingProperty)
    float MaxAngularAcceleration; // 0x24 (Size: 0x4, Type: FloatProperty)
    float LinearAccelerationThresholdForTeleport; // 0x28 (Size: 0x4, Type: FloatProperty)
    float AngularAccelerationThresholdForTeleport; // 0x2c (Size: 0x4, Type: FloatProperty)
    FVector ExternalLinearDragV; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector ExternalLinearVelocity; // 0x48 (Size: 0x18, Type: StructProperty)
    FVector ExternalAngularVelocity; // 0x60 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigPhysicsSimulationSpaceSettings) == 0x78, "Size mismatch for FRigPhysicsSimulationSpaceSettings");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, SpaceMovementAmount) == 0x0, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::SpaceMovementAmount");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, VelocityScaleZ) == 0x4, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::VelocityScaleZ");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, bClampLinearVelocity) == 0x8, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::bClampLinearVelocity");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, MaxLinearVelocity) == 0xc, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::MaxLinearVelocity");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, bClampAngularVelocity) == 0x10, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::bClampAngularVelocity");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, MaxAngularVelocity) == 0x14, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::MaxAngularVelocity");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, bClampLinearAcceleration) == 0x18, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::bClampLinearAcceleration");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, MaxLinearAcceleration) == 0x1c, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::MaxLinearAcceleration");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, bClampAngularAcceleration) == 0x20, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::bClampAngularAcceleration");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, MaxAngularAcceleration) == 0x24, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::MaxAngularAcceleration");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, LinearAccelerationThresholdForTeleport) == 0x28, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::LinearAccelerationThresholdForTeleport");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, AngularAccelerationThresholdForTeleport) == 0x2c, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::AngularAccelerationThresholdForTeleport");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, ExternalLinearDragV) == 0x30, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::ExternalLinearDragV");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, ExternalLinearVelocity) == 0x48, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::ExternalLinearVelocity");
static_assert(offsetof(FRigPhysicsSimulationSpaceSettings, ExternalAngularVelocity) == 0x60, "Offset mismatch for FRigPhysicsSimulationSpaceSettings::ExternalAngularVelocity");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FRigPhysicsSolverSettings
{
    bool bAutomaticallyAddPhysicsComponents; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t SimulationSpace; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t CollisionSpace; // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    FRigElementKey SpaceBone; // 0x4 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FRigPhysicsCollision Collision; // 0x10 (Size: 0x40, Type: StructProperty)
    FVector Gravity; // 0x50 (Size: 0x18, Type: StructProperty)
    int32_t PositionIterations; // 0x68 (Size: 0x4, Type: IntProperty)
    int32_t VelocityIterations; // 0x6c (Size: 0x4, Type: IntProperty)
    int32_t ProjectionIterations; // 0x70 (Size: 0x4, Type: IntProperty)
    int32_t MaxNumRollingAverageStepTimes; // 0x74 (Size: 0x4, Type: IntProperty)
    float MaxDepenetrationVelocity; // 0x78 (Size: 0x4, Type: FloatProperty)
    float FixedTimeStep; // 0x7c (Size: 0x4, Type: FloatProperty)
    int32_t MaxTimeSteps; // 0x80 (Size: 0x4, Type: IntProperty)
    float MaxDeltaTime; // 0x84 (Size: 0x4, Type: FloatProperty)
    bool bUseLinearJointSolver; // 0x88 (Size: 0x1, Type: BoolProperty)
    bool bSolveJointPositionsLast; // 0x89 (Size: 0x1, Type: BoolProperty)
    bool bUseManifolds; // 0x8a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8b[0x1]; // 0x8b (Size: 0x1, Type: PaddingProperty)
    float DistanceThresholdForReset; // 0x8c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigPhysicsSolverSettings) == 0x90, "Size mismatch for FRigPhysicsSolverSettings");
static_assert(offsetof(FRigPhysicsSolverSettings, bAutomaticallyAddPhysicsComponents) == 0x0, "Offset mismatch for FRigPhysicsSolverSettings::bAutomaticallyAddPhysicsComponents");
static_assert(offsetof(FRigPhysicsSolverSettings, SimulationSpace) == 0x1, "Offset mismatch for FRigPhysicsSolverSettings::SimulationSpace");
static_assert(offsetof(FRigPhysicsSolverSettings, CollisionSpace) == 0x2, "Offset mismatch for FRigPhysicsSolverSettings::CollisionSpace");
static_assert(offsetof(FRigPhysicsSolverSettings, SpaceBone) == 0x4, "Offset mismatch for FRigPhysicsSolverSettings::SpaceBone");
static_assert(offsetof(FRigPhysicsSolverSettings, Collision) == 0x10, "Offset mismatch for FRigPhysicsSolverSettings::Collision");
static_assert(offsetof(FRigPhysicsSolverSettings, Gravity) == 0x50, "Offset mismatch for FRigPhysicsSolverSettings::Gravity");
static_assert(offsetof(FRigPhysicsSolverSettings, PositionIterations) == 0x68, "Offset mismatch for FRigPhysicsSolverSettings::PositionIterations");
static_assert(offsetof(FRigPhysicsSolverSettings, VelocityIterations) == 0x6c, "Offset mismatch for FRigPhysicsSolverSettings::VelocityIterations");
static_assert(offsetof(FRigPhysicsSolverSettings, ProjectionIterations) == 0x70, "Offset mismatch for FRigPhysicsSolverSettings::ProjectionIterations");
static_assert(offsetof(FRigPhysicsSolverSettings, MaxNumRollingAverageStepTimes) == 0x74, "Offset mismatch for FRigPhysicsSolverSettings::MaxNumRollingAverageStepTimes");
static_assert(offsetof(FRigPhysicsSolverSettings, MaxDepenetrationVelocity) == 0x78, "Offset mismatch for FRigPhysicsSolverSettings::MaxDepenetrationVelocity");
static_assert(offsetof(FRigPhysicsSolverSettings, FixedTimeStep) == 0x7c, "Offset mismatch for FRigPhysicsSolverSettings::FixedTimeStep");
static_assert(offsetof(FRigPhysicsSolverSettings, MaxTimeSteps) == 0x80, "Offset mismatch for FRigPhysicsSolverSettings::MaxTimeSteps");
static_assert(offsetof(FRigPhysicsSolverSettings, MaxDeltaTime) == 0x84, "Offset mismatch for FRigPhysicsSolverSettings::MaxDeltaTime");
static_assert(offsetof(FRigPhysicsSolverSettings, bUseLinearJointSolver) == 0x88, "Offset mismatch for FRigPhysicsSolverSettings::bUseLinearJointSolver");
static_assert(offsetof(FRigPhysicsSolverSettings, bSolveJointPositionsLast) == 0x89, "Offset mismatch for FRigPhysicsSolverSettings::bSolveJointPositionsLast");
static_assert(offsetof(FRigPhysicsSolverSettings, bUseManifolds) == 0x8a, "Offset mismatch for FRigPhysicsSolverSettings::bUseManifolds");
static_assert(offsetof(FRigPhysicsSolverSettings, DistanceThresholdForReset) == 0x8c, "Offset mismatch for FRigPhysicsSolverSettings::DistanceThresholdForReset");

// Size: 0xd8 (Inherited: 0x0, Single: 0xd8)
struct FRigPhysicsDriveData
{
    FLinearDriveConstraint LinearDriveConstraint; // 0x0 (Size: 0x68, Type: StructProperty)
    FAngularDriveConstraint AngularDriveConstraint; // 0x68 (Size: 0x68, Type: StructProperty)
    float SkeletalAnimationVelocityMultiplier; // 0xd0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigPhysicsDriveData) == 0xd8, "Size mismatch for FRigPhysicsDriveData");
static_assert(offsetof(FRigPhysicsDriveData, LinearDriveConstraint) == 0x0, "Offset mismatch for FRigPhysicsDriveData::LinearDriveConstraint");
static_assert(offsetof(FRigPhysicsDriveData, AngularDriveConstraint) == 0x68, "Offset mismatch for FRigPhysicsDriveData::AngularDriveConstraint");
static_assert(offsetof(FRigPhysicsDriveData, SkeletalAnimationVelocityMultiplier) == 0xd0, "Offset mismatch for FRigPhysicsDriveData::SkeletalAnimationVelocityMultiplier");

// Size: 0x150 (Inherited: 0x0, Single: 0x150)
struct FRigPhysicsJointData
{
    bool bAutoCalculateParentOffset; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0xf]; // 0x1 (Size: 0xf, Type: PaddingProperty)
    FTransform ExtraParentOffset; // 0x10 (Size: 0x60, Type: StructProperty)
    bool bAutoCalculateChildOffset; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0xf]; // 0x71 (Size: 0xf, Type: PaddingProperty)
    FTransform ExtraChildOffset; // 0x80 (Size: 0x60, Type: StructProperty)
    FLinearConstraint LinearConstraint; // 0xe0 (Size: 0x1c, Type: StructProperty)
    FConeConstraint ConeConstraint; // 0xfc (Size: 0x20, Type: StructProperty)
    FTwistConstraint TwistConstraint; // 0x11c (Size: 0x1c, Type: StructProperty)
    bool bDisableCollision; // 0x138 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_139[0x3]; // 0x139 (Size: 0x3, Type: PaddingProperty)
    float LinearProjectionAmount; // 0x13c (Size: 0x4, Type: FloatProperty)
    float AngularProjectionAmount; // 0x140 (Size: 0x4, Type: FloatProperty)
    float ParentInverseMassScale; // 0x144 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_148[0x8]; // 0x148 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigPhysicsJointData) == 0x150, "Size mismatch for FRigPhysicsJointData");
static_assert(offsetof(FRigPhysicsJointData, bAutoCalculateParentOffset) == 0x0, "Offset mismatch for FRigPhysicsJointData::bAutoCalculateParentOffset");
static_assert(offsetof(FRigPhysicsJointData, ExtraParentOffset) == 0x10, "Offset mismatch for FRigPhysicsJointData::ExtraParentOffset");
static_assert(offsetof(FRigPhysicsJointData, bAutoCalculateChildOffset) == 0x70, "Offset mismatch for FRigPhysicsJointData::bAutoCalculateChildOffset");
static_assert(offsetof(FRigPhysicsJointData, ExtraChildOffset) == 0x80, "Offset mismatch for FRigPhysicsJointData::ExtraChildOffset");
static_assert(offsetof(FRigPhysicsJointData, LinearConstraint) == 0xe0, "Offset mismatch for FRigPhysicsJointData::LinearConstraint");
static_assert(offsetof(FRigPhysicsJointData, ConeConstraint) == 0xfc, "Offset mismatch for FRigPhysicsJointData::ConeConstraint");
static_assert(offsetof(FRigPhysicsJointData, TwistConstraint) == 0x11c, "Offset mismatch for FRigPhysicsJointData::TwistConstraint");
static_assert(offsetof(FRigPhysicsJointData, bDisableCollision) == 0x138, "Offset mismatch for FRigPhysicsJointData::bDisableCollision");
static_assert(offsetof(FRigPhysicsJointData, LinearProjectionAmount) == 0x13c, "Offset mismatch for FRigPhysicsJointData::LinearProjectionAmount");
static_assert(offsetof(FRigPhysicsJointData, AngularProjectionAmount) == 0x140, "Offset mismatch for FRigPhysicsJointData::AngularProjectionAmount");
static_assert(offsetof(FRigPhysicsJointData, ParentInverseMassScale) == 0x144, "Offset mismatch for FRigPhysicsJointData::ParentInverseMassScale");

// Size: 0x290 (Inherited: 0x40, Single: 0x250)
struct FRigPhysicsJointComponent : FRigBaseComponent
{
    FRigComponentKey ParentBodyComponentKey; // 0x40 (Size: 0xc, Type: StructProperty)
    FRigComponentKey ChildBodyComponentKey; // 0x4c (Size: 0xc, Type: StructProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
    FRigPhysicsJointData JointData; // 0x60 (Size: 0x150, Type: StructProperty)
    FRigPhysicsDriveData DriveData; // 0x1b0 (Size: 0xd8, Type: StructProperty)
    uint8_t Pad_288[0x8]; // 0x288 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigPhysicsJointComponent) == 0x290, "Size mismatch for FRigPhysicsJointComponent");
static_assert(offsetof(FRigPhysicsJointComponent, ParentBodyComponentKey) == 0x40, "Offset mismatch for FRigPhysicsJointComponent::ParentBodyComponentKey");
static_assert(offsetof(FRigPhysicsJointComponent, ChildBodyComponentKey) == 0x4c, "Offset mismatch for FRigPhysicsJointComponent::ChildBodyComponentKey");
static_assert(offsetof(FRigPhysicsJointComponent, JointData) == 0x60, "Offset mismatch for FRigPhysicsJointComponent::JointData");
static_assert(offsetof(FRigPhysicsJointComponent, DriveData) == 0x1b0, "Offset mismatch for FRigPhysicsJointComponent::DriveData");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FRigBodyRecord
{
};

static_assert(sizeof(FRigBodyRecord) == 0x8, "Size mismatch for FRigBodyRecord");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FRigJointRecord
{
};

static_assert(sizeof(FRigJointRecord) == 0x70, "Size mismatch for FRigJointRecord");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FRigControlRecord
{
};

static_assert(sizeof(FRigControlRecord) == 0x70, "Size mismatch for FRigControlRecord");

// Size: 0x500 (Inherited: 0x20, Single: 0x4e0)
struct FRigPhysicsSimulation : FRigPhysicsSimulationBase
{
};

static_assert(sizeof(FRigPhysicsSimulation) == 0x500, "Size mismatch for FRigPhysicsSimulation");

// Size: 0x148 (Inherited: 0x40, Single: 0x108)
struct FRigPhysicsSolverComponent : FRigBaseComponent
{
    FRigPhysicsSolverSettings SolverSettings; // 0x40 (Size: 0x90, Type: StructProperty)
    FRigPhysicsSimulationSpaceSettings SimulationSpaceSettings; // 0xd0 (Size: 0x78, Type: StructProperty)
};

static_assert(sizeof(FRigPhysicsSolverComponent) == 0x148, "Size mismatch for FRigPhysicsSolverComponent");
static_assert(offsetof(FRigPhysicsSolverComponent, SolverSettings) == 0x40, "Offset mismatch for FRigPhysicsSolverComponent::SolverSettings");
static_assert(offsetof(FRigPhysicsSolverComponent, SimulationSpaceSettings) == 0xd0, "Offset mismatch for FRigPhysicsSolverComponent::SimulationSpaceSettings");

// Size: 0x10 (Inherited: 0x20, Single: 0xfffffff0)
struct FRigUnit_PhysicsBaseMutable : FRigUnitMutable
{
};

static_assert(sizeof(FRigUnit_PhysicsBaseMutable) == 0x10, "Size mismatch for FRigUnit_PhysicsBaseMutable");

// Size: 0xe8 (Inherited: 0x30, Single: 0xb8)
struct FRigUnit_AddPhysicsBody : FRigUnit_PhysicsBaseMutable
{
    FRigElementKey Owner; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigComponentKey PhysicsBodyComponentKey; // 0x18 (Size: 0xc, Type: StructProperty)
    FRigPhysicsBodySolverSettings Solver; // 0x24 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
    FRigPhysicsDynamics Dynamics; // 0x48 (Size: 0x50, Type: StructProperty)
    FRigPhysicsCollision Collision; // 0x98 (Size: 0x40, Type: StructProperty)
    FPhysicsControlModifierData BodyData; // 0xd8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_AddPhysicsBody) == 0xe8, "Size mismatch for FRigUnit_AddPhysicsBody");
static_assert(offsetof(FRigUnit_AddPhysicsBody, Owner) == 0x10, "Offset mismatch for FRigUnit_AddPhysicsBody::Owner");
static_assert(offsetof(FRigUnit_AddPhysicsBody, PhysicsBodyComponentKey) == 0x18, "Offset mismatch for FRigUnit_AddPhysicsBody::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_AddPhysicsBody, Solver) == 0x24, "Offset mismatch for FRigUnit_AddPhysicsBody::Solver");
static_assert(offsetof(FRigUnit_AddPhysicsBody, Dynamics) == 0x48, "Offset mismatch for FRigUnit_AddPhysicsBody::Dynamics");
static_assert(offsetof(FRigUnit_AddPhysicsBody, Collision) == 0x98, "Offset mismatch for FRigUnit_AddPhysicsBody::Collision");
static_assert(offsetof(FRigUnit_AddPhysicsBody, BodyData) == 0xd8, "Offset mismatch for FRigUnit_AddPhysicsBody::BodyData");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_HierarchyAutoCalculateCollision : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    float MinAspectRatio; // 0x1c (Size: 0x4, Type: FloatProperty)
    float MinSize; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAutoCalculateCollision) == 0x28, "Size mismatch for FRigUnit_HierarchyAutoCalculateCollision");
static_assert(offsetof(FRigUnit_HierarchyAutoCalculateCollision, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchyAutoCalculateCollision::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchyAutoCalculateCollision, MinAspectRatio) == 0x1c, "Offset mismatch for FRigUnit_HierarchyAutoCalculateCollision::MinAspectRatio");
static_assert(offsetof(FRigUnit_HierarchyAutoCalculateCollision, MinSize) == 0x20, "Offset mismatch for FRigUnit_HierarchyAutoCalculateCollision::MinSize");

// Size: 0x70 (Inherited: 0x30, Single: 0x40)
struct FRigUnit_HierarchySetDynamics : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FRigPhysicsDynamics Dynamics; // 0x20 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetDynamics) == 0x70, "Size mismatch for FRigUnit_HierarchySetDynamics");
static_assert(offsetof(FRigUnit_HierarchySetDynamics, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetDynamics::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetDynamics, Dynamics) == 0x20, "Offset mismatch for FRigUnit_HierarchySetDynamics::Dynamics");

// Size: 0x60 (Inherited: 0x30, Single: 0x30)
struct FRigUnit_HierarchySetCollision : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FRigPhysicsCollision Collision; // 0x20 (Size: 0x40, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetCollision) == 0x60, "Size mismatch for FRigUnit_HierarchySetCollision");
static_assert(offsetof(FRigUnit_HierarchySetCollision, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetCollision::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetCollision, Collision) == 0x20, "Offset mismatch for FRigUnit_HierarchySetCollision::Collision");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_HierarchyDisableCollisionBetween : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey1; // 0x10 (Size: 0xc, Type: StructProperty)
    FRigComponentKey PhysicsBodyComponentKey2; // 0x1c (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyDisableCollisionBetween) == 0x28, "Size mismatch for FRigUnit_HierarchyDisableCollisionBetween");
static_assert(offsetof(FRigUnit_HierarchyDisableCollisionBetween, PhysicsBodyComponentKey1) == 0x10, "Offset mismatch for FRigUnit_HierarchyDisableCollisionBetween::PhysicsBodyComponentKey1");
static_assert(offsetof(FRigUnit_HierarchyDisableCollisionBetween, PhysicsBodyComponentKey2) == 0x1c, "Offset mismatch for FRigUnit_HierarchyDisableCollisionBetween::PhysicsBodyComponentKey2");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_HierarchySetPhysicsBodySourceBone : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    FRigElementKey SourceBone; // 0x1c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPhysicsBodySourceBone) == 0x28, "Size mismatch for FRigUnit_HierarchySetPhysicsBodySourceBone");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodySourceBone, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodySourceBone::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodySourceBone, SourceBone) == 0x1c, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodySourceBone::SourceBone");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_HierarchySetPhysicsBodyTargetBone : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    FRigElementKey TargetBone; // 0x1c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPhysicsBodyTargetBone) == 0x28, "Size mismatch for FRigUnit_HierarchySetPhysicsBodyTargetBone");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyTargetBone, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyTargetBone::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyTargetBone, TargetBone) == 0x1c, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyTargetBone::TargetBone");

// Size: 0x30 (Inherited: 0x30, Single: 0x0)
struct FRigUnit_HierarchySetPhysicsBodySparseData : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    FPhysicsControlModifierSparseData Data; // 0x1c (Size: 0x10, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPhysicsBodySparseData) == 0x30, "Size mismatch for FRigUnit_HierarchySetPhysicsBodySparseData");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodySparseData, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodySparseData::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodySparseData, Data) == 0x1c, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodySparseData::Data");

// Size: 0x80 (Inherited: 0x30, Single: 0x50)
struct FRigUnit_HierarchySetPhysicsBodyKinematicTarget : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t KinematicTargetSpace; // 0x1c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
    FTransform KinematicTarget; // 0x20 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPhysicsBodyKinematicTarget) == 0x80, "Size mismatch for FRigUnit_HierarchySetPhysicsBodyKinematicTarget");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyKinematicTarget, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyKinematicTarget::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyKinematicTarget, KinematicTargetSpace) == 0x1c, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyKinematicTarget::KinematicTargetSpace");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyKinematicTarget, KinematicTarget) == 0x20, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyKinematicTarget::KinematicTarget");

// Size: 0x20 (Inherited: 0x30, Single: 0xfffffff0)
struct FRigUnit_HierarchySetPhysicsBodyMovementType : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t MovementType; // 0x1c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPhysicsBodyMovementType) == 0x20, "Size mismatch for FRigUnit_HierarchySetPhysicsBodyMovementType");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyMovementType, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyMovementType::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyMovementType, MovementType) == 0x1c, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyMovementType::MovementType");

// Size: 0x20 (Inherited: 0x30, Single: 0xfffffff0)
struct FRigUnit_HierarchySetPhysicsBodyCollisionType : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    TEnumAsByte<ECollisionEnabled> CollisionType; // 0x1c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPhysicsBodyCollisionType) == 0x20, "Size mismatch for FRigUnit_HierarchySetPhysicsBodyCollisionType");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyCollisionType, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyCollisionType::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyCollisionType, CollisionType) == 0x1c, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyCollisionType::CollisionType");

// Size: 0x20 (Inherited: 0x30, Single: 0xfffffff0)
struct FRigUnit_HierarchySetPhysicsBodyGravityMultiplier : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    float GravityMultiplier; // 0x1c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPhysicsBodyGravityMultiplier) == 0x20, "Size mismatch for FRigUnit_HierarchySetPhysicsBodyGravityMultiplier");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyGravityMultiplier, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyGravityMultiplier::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyGravityMultiplier, GravityMultiplier) == 0x1c, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyGravityMultiplier::GravityMultiplier");

// Size: 0x20 (Inherited: 0x30, Single: 0xfffffff0)
struct FRigUnit_HierarchySetPhysicsBodyPhysicsBlendWeight : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    float PhysicsBlendWeight; // 0x1c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPhysicsBodyPhysicsBlendWeight) == 0x20, "Size mismatch for FRigUnit_HierarchySetPhysicsBodyPhysicsBlendWeight");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyPhysicsBlendWeight, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyPhysicsBlendWeight::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyPhysicsBlendWeight, PhysicsBlendWeight) == 0x1c, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyPhysicsBlendWeight::PhysicsBlendWeight");

// Size: 0x20 (Inherited: 0x30, Single: 0xfffffff0)
struct FRigUnit_HierarchySetPhysicsBodyUseSkeletalAnimation : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    bool bUseSkeletalAnimation; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPhysicsBodyUseSkeletalAnimation) == 0x20, "Size mismatch for FRigUnit_HierarchySetPhysicsBodyUseSkeletalAnimation");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyUseSkeletalAnimation, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyUseSkeletalAnimation::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyUseSkeletalAnimation, bUseSkeletalAnimation) == 0x1c, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyUseSkeletalAnimation::bUseSkeletalAnimation");

// Size: 0x20 (Inherited: 0x30, Single: 0xfffffff0)
struct FRigUnit_HierarchySetPhysicsBodyUpdateKinematicFromSimulation : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    bool bUpdateKinematicFromSimulation; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPhysicsBodyUpdateKinematicFromSimulation) == 0x20, "Size mismatch for FRigUnit_HierarchySetPhysicsBodyUpdateKinematicFromSimulation");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyUpdateKinematicFromSimulation, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyUpdateKinematicFromSimulation::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyUpdateKinematicFromSimulation, bUpdateKinematicFromSimulation) == 0x1c, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyUpdateKinematicFromSimulation::bUpdateKinematicFromSimulation");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_HierarchySetPhysicsBodyDamping : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsBodyComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    float LinearDamping; // 0x1c (Size: 0x4, Type: FloatProperty)
    float AngularDamping; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPhysicsBodyDamping) == 0x28, "Size mismatch for FRigUnit_HierarchySetPhysicsBodyDamping");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyDamping, PhysicsBodyComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyDamping::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyDamping, LinearDamping) == 0x1c, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyDamping::LinearDamping");
static_assert(offsetof(FRigUnit_HierarchySetPhysicsBodyDamping, AngularDamping) == 0x20, "Offset mismatch for FRigUnit_HierarchySetPhysicsBodyDamping::AngularDamping");

// Size: 0x168 (Inherited: 0x30, Single: 0x138)
struct FRigUnit_AddPhysicsControl : FRigUnit_PhysicsBaseMutable
{
    FRigElementKey Owner; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigComponentKey ControlComponentKey; // 0x18 (Size: 0xc, Type: StructProperty)
    FRigComponentKey ParentBodyComponentKey; // 0x24 (Size: 0xc, Type: StructProperty)
    FRigComponentKey ChildBodyComponentKey; // 0x30 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    FPhysicsControlData ControlData; // 0x40 (Size: 0x50, Type: StructProperty)
    FPhysicsControlMultiplier ControlMultiplier; // 0x90 (Size: 0x70, Type: StructProperty)
    FPhysicsControlTarget ControlTarget; // 0x100 (Size: 0x68, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_AddPhysicsControl) == 0x168, "Size mismatch for FRigUnit_AddPhysicsControl");
static_assert(offsetof(FRigUnit_AddPhysicsControl, Owner) == 0x10, "Offset mismatch for FRigUnit_AddPhysicsControl::Owner");
static_assert(offsetof(FRigUnit_AddPhysicsControl, ControlComponentKey) == 0x18, "Offset mismatch for FRigUnit_AddPhysicsControl::ControlComponentKey");
static_assert(offsetof(FRigUnit_AddPhysicsControl, ParentBodyComponentKey) == 0x24, "Offset mismatch for FRigUnit_AddPhysicsControl::ParentBodyComponentKey");
static_assert(offsetof(FRigUnit_AddPhysicsControl, ChildBodyComponentKey) == 0x30, "Offset mismatch for FRigUnit_AddPhysicsControl::ChildBodyComponentKey");
static_assert(offsetof(FRigUnit_AddPhysicsControl, ControlData) == 0x40, "Offset mismatch for FRigUnit_AddPhysicsControl::ControlData");
static_assert(offsetof(FRigUnit_AddPhysicsControl, ControlMultiplier) == 0x90, "Offset mismatch for FRigUnit_AddPhysicsControl::ControlMultiplier");
static_assert(offsetof(FRigUnit_AddPhysicsControl, ControlTarget) == 0x100, "Offset mismatch for FRigUnit_AddPhysicsControl::ControlTarget");

// Size: 0x70 (Inherited: 0x30, Single: 0x40)
struct FRigUnit_HierarchySetControlData : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsControlComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FPhysicsControlData ControlData; // 0x20 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetControlData) == 0x70, "Size mismatch for FRigUnit_HierarchySetControlData");
static_assert(offsetof(FRigUnit_HierarchySetControlData, PhysicsControlComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetControlData::PhysicsControlComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetControlData, ControlData) == 0x20, "Offset mismatch for FRigUnit_HierarchySetControlData::ControlData");

// Size: 0x88 (Inherited: 0x30, Single: 0x58)
struct FRigUnit_HierarchySetControlTarget : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsControlComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FPhysicsControlTarget ControlTarget; // 0x20 (Size: 0x68, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetControlTarget) == 0x88, "Size mismatch for FRigUnit_HierarchySetControlTarget");
static_assert(offsetof(FRigUnit_HierarchySetControlTarget, PhysicsControlComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetControlTarget::PhysicsControlComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetControlTarget, ControlTarget) == 0x20, "Offset mismatch for FRigUnit_HierarchySetControlTarget::ControlTarget");

// Size: 0x90 (Inherited: 0x30, Single: 0x60)
struct FRigUnit_HierarchySetControlMultiplier : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsControlComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FPhysicsControlMultiplier ControlMultiplier; // 0x20 (Size: 0x70, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetControlMultiplier) == 0x90, "Size mismatch for FRigUnit_HierarchySetControlMultiplier");
static_assert(offsetof(FRigUnit_HierarchySetControlMultiplier, PhysicsControlComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetControlMultiplier::PhysicsControlComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetControlMultiplier, ControlMultiplier) == 0x20, "Offset mismatch for FRigUnit_HierarchySetControlMultiplier::ControlMultiplier");

// Size: 0x8 (Inherited: 0x10, Single: 0xfffffff8)
struct FRigUnit_PhysicsBase : FRigUnit
{
};

static_assert(sizeof(FRigUnit_PhysicsBase) == 0x8, "Size mismatch for FRigUnit_PhysicsBase");

// Size: 0x130 (Inherited: 0x30, Single: 0x100)
struct FRigUnit_AddPhysicsSolver : FRigUnit_PhysicsBaseMutable
{
    FRigElementKey Owner; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigComponentKey PhysicsSolverComponentKey; // 0x18 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FRigPhysicsSolverSettings SolverSettings; // 0x28 (Size: 0x90, Type: StructProperty)
    FRigPhysicsSimulationSpaceSettings SimulationSpaceSettings; // 0xb8 (Size: 0x78, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_AddPhysicsSolver) == 0x130, "Size mismatch for FRigUnit_AddPhysicsSolver");
static_assert(offsetof(FRigUnit_AddPhysicsSolver, Owner) == 0x10, "Offset mismatch for FRigUnit_AddPhysicsSolver::Owner");
static_assert(offsetof(FRigUnit_AddPhysicsSolver, PhysicsSolverComponentKey) == 0x18, "Offset mismatch for FRigUnit_AddPhysicsSolver::PhysicsSolverComponentKey");
static_assert(offsetof(FRigUnit_AddPhysicsSolver, SolverSettings) == 0x28, "Offset mismatch for FRigUnit_AddPhysicsSolver::SolverSettings");
static_assert(offsetof(FRigUnit_AddPhysicsSolver, SimulationSpaceSettings) == 0xb8, "Offset mismatch for FRigUnit_AddPhysicsSolver::SimulationSpaceSettings");

// Size: 0x20 (Inherited: 0x30, Single: 0xfffffff0)
struct FRigUnit_InstantiatePhysics : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsSolverComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_InstantiatePhysics) == 0x20, "Size mismatch for FRigUnit_InstantiatePhysics");
static_assert(offsetof(FRigUnit_InstantiatePhysics, PhysicsSolverComponentKey) == 0x10, "Offset mismatch for FRigUnit_InstantiatePhysics::PhysicsSolverComponentKey");

// Size: 0x38 (Inherited: 0x30, Single: 0x8)
struct FRigUnit_StepPhysicsSolver : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsSolverComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    float DeltaTimeOverride; // 0x1c (Size: 0x4, Type: FloatProperty)
    float SimulationSpaceDeltaTimeOverride; // 0x20 (Size: 0x4, Type: FloatProperty)
    float Alpha; // 0x24 (Size: 0x4, Type: FloatProperty)
    FRigPhysicsVisualizationSettings VisualizationSettings; // 0x28 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_StepPhysicsSolver) == 0x38, "Size mismatch for FRigUnit_StepPhysicsSolver");
static_assert(offsetof(FRigUnit_StepPhysicsSolver, PhysicsSolverComponentKey) == 0x10, "Offset mismatch for FRigUnit_StepPhysicsSolver::PhysicsSolverComponentKey");
static_assert(offsetof(FRigUnit_StepPhysicsSolver, DeltaTimeOverride) == 0x1c, "Offset mismatch for FRigUnit_StepPhysicsSolver::DeltaTimeOverride");
static_assert(offsetof(FRigUnit_StepPhysicsSolver, SimulationSpaceDeltaTimeOverride) == 0x20, "Offset mismatch for FRigUnit_StepPhysicsSolver::SimulationSpaceDeltaTimeOverride");
static_assert(offsetof(FRigUnit_StepPhysicsSolver, Alpha) == 0x24, "Offset mismatch for FRigUnit_StepPhysicsSolver::Alpha");
static_assert(offsetof(FRigUnit_StepPhysicsSolver, VisualizationSettings) == 0x28, "Offset mismatch for FRigUnit_StepPhysicsSolver::VisualizationSettings");

// Size: 0x3e0 (Inherited: 0x30, Single: 0x3b0)
struct FRigUnit_AddPhysicsComponents : FRigUnit_PhysicsBaseMutable
{
    FRigElementKey Owner; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bAddJoint; // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bAddSimSpaceControl; // 0x19 (Size: 0x1, Type: BoolProperty)
    bool bAddParentSpaceControl; // 0x1a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1b[0x1]; // 0x1b (Size: 0x1, Type: PaddingProperty)
    FRigComponentKey PhysicsBodyComponentKey; // 0x1c (Size: 0xc, Type: StructProperty)
    FRigComponentKey PhysicsJointComponentKey; // 0x28 (Size: 0xc, Type: StructProperty)
    FRigComponentKey SimSpaceControlComponentKey; // 0x34 (Size: 0xc, Type: StructProperty)
    FRigComponentKey ParentSpaceControlComponentKey; // 0x40 (Size: 0xc, Type: StructProperty)
    FRigPhysicsBodySolverSettings Solver; // 0x4c (Size: 0x20, Type: StructProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
    FRigPhysicsDynamics Dynamics; // 0x70 (Size: 0x50, Type: StructProperty)
    FRigPhysicsCollision Collision; // 0xc0 (Size: 0x40, Type: StructProperty)
    FPhysicsControlModifierData BodyData; // 0x100 (Size: 0x10, Type: StructProperty)
    FRigPhysicsJointData JointData; // 0x110 (Size: 0x150, Type: StructProperty)
    FRigPhysicsDriveData DriveData; // 0x260 (Size: 0xd8, Type: StructProperty)
    FPhysicsControlData SimSpaceControlData; // 0x338 (Size: 0x50, Type: StructProperty)
    FPhysicsControlData ParentSpaceControlData; // 0x388 (Size: 0x50, Type: StructProperty)
    uint8_t Pad_3d8[0x8]; // 0x3d8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_AddPhysicsComponents) == 0x3e0, "Size mismatch for FRigUnit_AddPhysicsComponents");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, Owner) == 0x10, "Offset mismatch for FRigUnit_AddPhysicsComponents::Owner");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, bAddJoint) == 0x18, "Offset mismatch for FRigUnit_AddPhysicsComponents::bAddJoint");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, bAddSimSpaceControl) == 0x19, "Offset mismatch for FRigUnit_AddPhysicsComponents::bAddSimSpaceControl");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, bAddParentSpaceControl) == 0x1a, "Offset mismatch for FRigUnit_AddPhysicsComponents::bAddParentSpaceControl");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, PhysicsBodyComponentKey) == 0x1c, "Offset mismatch for FRigUnit_AddPhysicsComponents::PhysicsBodyComponentKey");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, PhysicsJointComponentKey) == 0x28, "Offset mismatch for FRigUnit_AddPhysicsComponents::PhysicsJointComponentKey");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, SimSpaceControlComponentKey) == 0x34, "Offset mismatch for FRigUnit_AddPhysicsComponents::SimSpaceControlComponentKey");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, ParentSpaceControlComponentKey) == 0x40, "Offset mismatch for FRigUnit_AddPhysicsComponents::ParentSpaceControlComponentKey");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, Solver) == 0x4c, "Offset mismatch for FRigUnit_AddPhysicsComponents::Solver");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, Dynamics) == 0x70, "Offset mismatch for FRigUnit_AddPhysicsComponents::Dynamics");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, Collision) == 0xc0, "Offset mismatch for FRigUnit_AddPhysicsComponents::Collision");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, BodyData) == 0x100, "Offset mismatch for FRigUnit_AddPhysicsComponents::BodyData");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, JointData) == 0x110, "Offset mismatch for FRigUnit_AddPhysicsComponents::JointData");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, DriveData) == 0x260, "Offset mismatch for FRigUnit_AddPhysicsComponents::DriveData");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, SimSpaceControlData) == 0x338, "Offset mismatch for FRigUnit_AddPhysicsComponents::SimSpaceControlData");
static_assert(offsetof(FRigUnit_AddPhysicsComponents, ParentSpaceControlData) == 0x388, "Offset mismatch for FRigUnit_AddPhysicsComponents::ParentSpaceControlData");

// Size: 0x138 (Inherited: 0x30, Single: 0x108)
struct FRigUnit_HierarchyInstantiateFromPhysicsAsset : FRigUnit_PhysicsBaseMutable
{
    FRigPhysicsBodySolverSettings Solver; // 0x10 (Size: 0x20, Type: StructProperty)
    UPhysicsAsset* PhysicsAsset; // 0x30 (Size: 0x8, Type: ObjectProperty)
    FName ConstraintProfileName; // 0x38 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    TArray<FRigElementKey> BonesToUse; // 0x40 (Size: 0x10, Type: ArrayProperty)
    bool bEnableJoints; // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bEnableDrives; // 0x51 (Size: 0x1, Type: BoolProperty)
    bool bAddSimSpaceControl; // 0x52 (Size: 0x1, Type: BoolProperty)
    bool bAddParentSpaceControl; // 0x53 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
    FPhysicsControlData SimSpaceControlData; // 0x58 (Size: 0x50, Type: StructProperty)
    FPhysicsControlData ParentSpaceControlData; // 0xa8 (Size: 0x50, Type: StructProperty)
    TArray<FRigComponentKey> PhysicsBodyComponentKeys; // 0xf8 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigComponentKey> PhysicsJointComponentKeys; // 0x108 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigComponentKey> SimSpaceControlComponentKeys; // 0x118 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigComponentKey> ParentSpaceControlComponentKeys; // 0x128 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_HierarchyInstantiateFromPhysicsAsset) == 0x138, "Size mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, Solver) == 0x10, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::Solver");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, PhysicsAsset) == 0x30, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::PhysicsAsset");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, ConstraintProfileName) == 0x38, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::ConstraintProfileName");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, BonesToUse) == 0x40, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::BonesToUse");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, bEnableJoints) == 0x50, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::bEnableJoints");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, bEnableDrives) == 0x51, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::bEnableDrives");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, bAddSimSpaceControl) == 0x52, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::bAddSimSpaceControl");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, bAddParentSpaceControl) == 0x53, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::bAddParentSpaceControl");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, SimSpaceControlData) == 0x58, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::SimSpaceControlData");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, ParentSpaceControlData) == 0xa8, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::ParentSpaceControlData");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, PhysicsBodyComponentKeys) == 0xf8, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::PhysicsBodyComponentKeys");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, PhysicsJointComponentKeys) == 0x108, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::PhysicsJointComponentKeys");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, SimSpaceControlComponentKeys) == 0x118, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::SimSpaceControlComponentKeys");
static_assert(offsetof(FRigUnit_HierarchyInstantiateFromPhysicsAsset, ParentSpaceControlComponentKeys) == 0x128, "Offset mismatch for FRigUnit_HierarchyInstantiateFromPhysicsAsset::ParentSpaceControlComponentKeys");

// Size: 0x90 (Inherited: 0x18, Single: 0x78)
struct FRigUnit_GetPhysicsSolverSpaceData : FRigUnit_PhysicsBase
{
    FRigComponentKey PhysicsSolverComponentKey; // 0x8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FVector LinearVelocity; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector LinearAcceleration; // 0x48 (Size: 0x18, Type: StructProperty)
    FVector AngularAcceleration; // 0x60 (Size: 0x18, Type: StructProperty)
    FVector Gravity; // 0x78 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetPhysicsSolverSpaceData) == 0x90, "Size mismatch for FRigUnit_GetPhysicsSolverSpaceData");
static_assert(offsetof(FRigUnit_GetPhysicsSolverSpaceData, PhysicsSolverComponentKey) == 0x8, "Offset mismatch for FRigUnit_GetPhysicsSolverSpaceData::PhysicsSolverComponentKey");
static_assert(offsetof(FRigUnit_GetPhysicsSolverSpaceData, LinearVelocity) == 0x18, "Offset mismatch for FRigUnit_GetPhysicsSolverSpaceData::LinearVelocity");
static_assert(offsetof(FRigUnit_GetPhysicsSolverSpaceData, AngularVelocity) == 0x30, "Offset mismatch for FRigUnit_GetPhysicsSolverSpaceData::AngularVelocity");
static_assert(offsetof(FRigUnit_GetPhysicsSolverSpaceData, LinearAcceleration) == 0x48, "Offset mismatch for FRigUnit_GetPhysicsSolverSpaceData::LinearAcceleration");
static_assert(offsetof(FRigUnit_GetPhysicsSolverSpaceData, AngularAcceleration) == 0x60, "Offset mismatch for FRigUnit_GetPhysicsSolverSpaceData::AngularAcceleration");
static_assert(offsetof(FRigUnit_GetPhysicsSolverSpaceData, Gravity) == 0x78, "Offset mismatch for FRigUnit_GetPhysicsSolverSpaceData::Gravity");

// Size: 0x270 (Inherited: 0x30, Single: 0x240)
struct FRigUnit_AddPhysicsJoint : FRigUnit_PhysicsBaseMutable
{
    FRigElementKey Owner; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigComponentKey PhysicsJointComponentKey; // 0x18 (Size: 0xc, Type: StructProperty)
    FRigComponentKey ParentBodyComponentKey; // 0x24 (Size: 0xc, Type: StructProperty)
    FRigComponentKey ChildBodyComponentKey; // 0x30 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    FRigPhysicsJointData JointData; // 0x40 (Size: 0x150, Type: StructProperty)
    FRigPhysicsDriveData DriveData; // 0x190 (Size: 0xd8, Type: StructProperty)
    uint8_t Pad_268[0x8]; // 0x268 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_AddPhysicsJoint) == 0x270, "Size mismatch for FRigUnit_AddPhysicsJoint");
static_assert(offsetof(FRigUnit_AddPhysicsJoint, Owner) == 0x10, "Offset mismatch for FRigUnit_AddPhysicsJoint::Owner");
static_assert(offsetof(FRigUnit_AddPhysicsJoint, PhysicsJointComponentKey) == 0x18, "Offset mismatch for FRigUnit_AddPhysicsJoint::PhysicsJointComponentKey");
static_assert(offsetof(FRigUnit_AddPhysicsJoint, ParentBodyComponentKey) == 0x24, "Offset mismatch for FRigUnit_AddPhysicsJoint::ParentBodyComponentKey");
static_assert(offsetof(FRigUnit_AddPhysicsJoint, ChildBodyComponentKey) == 0x30, "Offset mismatch for FRigUnit_AddPhysicsJoint::ChildBodyComponentKey");
static_assert(offsetof(FRigUnit_AddPhysicsJoint, JointData) == 0x40, "Offset mismatch for FRigUnit_AddPhysicsJoint::JointData");
static_assert(offsetof(FRigUnit_AddPhysicsJoint, DriveData) == 0x190, "Offset mismatch for FRigUnit_AddPhysicsJoint::DriveData");

// Size: 0x170 (Inherited: 0x30, Single: 0x140)
struct FRigUnit_HierarchySetJointData : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsJointComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FRigPhysicsJointData JointData; // 0x20 (Size: 0x150, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetJointData) == 0x170, "Size mismatch for FRigUnit_HierarchySetJointData");
static_assert(offsetof(FRigUnit_HierarchySetJointData, PhysicsJointComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetJointData::PhysicsJointComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetJointData, JointData) == 0x20, "Offset mismatch for FRigUnit_HierarchySetJointData::JointData");

// Size: 0xf8 (Inherited: 0x30, Single: 0xc8)
struct FRigUnit_HierarchySetJointDriveData : FRigUnit_PhysicsBaseMutable
{
    FRigComponentKey PhysicsJointComponentKey; // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FRigPhysicsDriveData DriveData; // 0x20 (Size: 0xd8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetJointDriveData) == 0xf8, "Size mismatch for FRigUnit_HierarchySetJointDriveData");
static_assert(offsetof(FRigUnit_HierarchySetJointDriveData, PhysicsJointComponentKey) == 0x10, "Offset mismatch for FRigUnit_HierarchySetJointDriveData::PhysicsJointComponentKey");
static_assert(offsetof(FRigUnit_HierarchySetJointDriveData, DriveData) == 0x20, "Offset mismatch for FRigUnit_HierarchySetJointDriveData::DriveData");

// Size: 0x1a0 (Inherited: 0x18, Single: 0x188)
struct FRigUnit_MakeArticulationJointData : FRigUnit_PhysicsBase
{
    FVector AngularLimit; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector SoftStrength; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector SoftDampingRatio; // 0x38 (Size: 0x18, Type: StructProperty)
    FRigPhysicsJointData JointData; // 0x50 (Size: 0x150, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_MakeArticulationJointData) == 0x1a0, "Size mismatch for FRigUnit_MakeArticulationJointData");
static_assert(offsetof(FRigUnit_MakeArticulationJointData, AngularLimit) == 0x8, "Offset mismatch for FRigUnit_MakeArticulationJointData::AngularLimit");
static_assert(offsetof(FRigUnit_MakeArticulationJointData, SoftStrength) == 0x20, "Offset mismatch for FRigUnit_MakeArticulationJointData::SoftStrength");
static_assert(offsetof(FRigUnit_MakeArticulationJointData, SoftDampingRatio) == 0x38, "Offset mismatch for FRigUnit_MakeArticulationJointData::SoftDampingRatio");
static_assert(offsetof(FRigUnit_MakeArticulationJointData, JointData) == 0x50, "Offset mismatch for FRigUnit_MakeArticulationJointData::JointData");

// Size: 0xf8 (Inherited: 0x18, Single: 0xe0)
struct FRigUnit_MakeArticulationDriveData : FRigUnit_PhysicsBase
{
    bool bEnableAngularDrive; // 0x8 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EAngularDriveMode> AngularDriveMode; // 0x9 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_a[0x2]; // 0xa (Size: 0x2, Type: PaddingProperty)
    float AngularStrength; // 0xc (Size: 0x4, Type: FloatProperty)
    float AngularDampingRatio; // 0x10 (Size: 0x4, Type: FloatProperty)
    float AngularExtraDamping; // 0x14 (Size: 0x4, Type: FloatProperty)
    float SkeletalAnimationVelocityMultiplier; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FRigPhysicsDriveData DriveData; // 0x20 (Size: 0xd8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_MakeArticulationDriveData) == 0xf8, "Size mismatch for FRigUnit_MakeArticulationDriveData");
static_assert(offsetof(FRigUnit_MakeArticulationDriveData, bEnableAngularDrive) == 0x8, "Offset mismatch for FRigUnit_MakeArticulationDriveData::bEnableAngularDrive");
static_assert(offsetof(FRigUnit_MakeArticulationDriveData, AngularDriveMode) == 0x9, "Offset mismatch for FRigUnit_MakeArticulationDriveData::AngularDriveMode");
static_assert(offsetof(FRigUnit_MakeArticulationDriveData, AngularStrength) == 0xc, "Offset mismatch for FRigUnit_MakeArticulationDriveData::AngularStrength");
static_assert(offsetof(FRigUnit_MakeArticulationDriveData, AngularDampingRatio) == 0x10, "Offset mismatch for FRigUnit_MakeArticulationDriveData::AngularDampingRatio");
static_assert(offsetof(FRigUnit_MakeArticulationDriveData, AngularExtraDamping) == 0x14, "Offset mismatch for FRigUnit_MakeArticulationDriveData::AngularExtraDamping");
static_assert(offsetof(FRigUnit_MakeArticulationDriveData, SkeletalAnimationVelocityMultiplier) == 0x18, "Offset mismatch for FRigUnit_MakeArticulationDriveData::SkeletalAnimationVelocityMultiplier");
static_assert(offsetof(FRigUnit_MakeArticulationDriveData, DriveData) == 0x20, "Offset mismatch for FRigUnit_MakeArticulationDriveData::DriveData");

// Size: 0x108 (Inherited: 0x18, Single: 0xf0)
struct FRigUnit_MakeDriveData : FRigUnit_PhysicsBase
{
    bool bEnableLinearDrive; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    float LinearStrength; // 0xc (Size: 0x4, Type: FloatProperty)
    float LinearDampingRatio; // 0x10 (Size: 0x4, Type: FloatProperty)
    float LinearExtraDamping; // 0x14 (Size: 0x4, Type: FloatProperty)
    bool bEnableAngularDrive; // 0x18 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EAngularDriveMode> AngularDriveMode; // 0x19 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1a[0x2]; // 0x1a (Size: 0x2, Type: PaddingProperty)
    float AngularStrength; // 0x1c (Size: 0x4, Type: FloatProperty)
    float AngularDampingRatio; // 0x20 (Size: 0x4, Type: FloatProperty)
    float AngularExtraDamping; // 0x24 (Size: 0x4, Type: FloatProperty)
    float SkeletalAnimationVelocityMultiplier; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    FRigPhysicsDriveData DriveData; // 0x30 (Size: 0xd8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_MakeDriveData) == 0x108, "Size mismatch for FRigUnit_MakeDriveData");
static_assert(offsetof(FRigUnit_MakeDriveData, bEnableLinearDrive) == 0x8, "Offset mismatch for FRigUnit_MakeDriveData::bEnableLinearDrive");
static_assert(offsetof(FRigUnit_MakeDriveData, LinearStrength) == 0xc, "Offset mismatch for FRigUnit_MakeDriveData::LinearStrength");
static_assert(offsetof(FRigUnit_MakeDriveData, LinearDampingRatio) == 0x10, "Offset mismatch for FRigUnit_MakeDriveData::LinearDampingRatio");
static_assert(offsetof(FRigUnit_MakeDriveData, LinearExtraDamping) == 0x14, "Offset mismatch for FRigUnit_MakeDriveData::LinearExtraDamping");
static_assert(offsetof(FRigUnit_MakeDriveData, bEnableAngularDrive) == 0x18, "Offset mismatch for FRigUnit_MakeDriveData::bEnableAngularDrive");
static_assert(offsetof(FRigUnit_MakeDriveData, AngularDriveMode) == 0x19, "Offset mismatch for FRigUnit_MakeDriveData::AngularDriveMode");
static_assert(offsetof(FRigUnit_MakeDriveData, AngularStrength) == 0x1c, "Offset mismatch for FRigUnit_MakeDriveData::AngularStrength");
static_assert(offsetof(FRigUnit_MakeDriveData, AngularDampingRatio) == 0x20, "Offset mismatch for FRigUnit_MakeDriveData::AngularDampingRatio");
static_assert(offsetof(FRigUnit_MakeDriveData, AngularExtraDamping) == 0x24, "Offset mismatch for FRigUnit_MakeDriveData::AngularExtraDamping");
static_assert(offsetof(FRigUnit_MakeDriveData, SkeletalAnimationVelocityMultiplier) == 0x28, "Offset mismatch for FRigUnit_MakeDriveData::SkeletalAnimationVelocityMultiplier");
static_assert(offsetof(FRigUnit_MakeDriveData, DriveData) == 0x30, "Offset mismatch for FRigUnit_MakeDriveData::DriveData");

