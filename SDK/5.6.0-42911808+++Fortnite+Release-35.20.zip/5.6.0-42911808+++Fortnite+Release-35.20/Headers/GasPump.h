/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GasPump
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "ModularGameplay.h"
#include "CoreUObject.h"
#include "Athena.h"
#include "Engine.h"

// Size: 0xe8 (Inherited: 0x308, Single: 0xfffffde0)
class UValet_GasPumpIndicatorManagerV2_C : public UFortGameStateComponent
{
public:
    UClass* FuelIndicatorClass; // 0xb8 (Size: 0x8, Type: ClassProperty)
    TArray<UB_GasPump_Valet_Component_C*> GasPumpList; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TArray<AFuelIndicator_C*> FuelIndicatorList; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    double FuelIndicatorRangeSquared; // 0xe0 (Size: 0x8, Type: DoubleProperty)

public:
    void AddGasPump(UB_GasPump_Valet_Component_C*& Gas_Pump); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void RemoveGasPump(UB_GasPump_Valet_Component_C*& Gas_Pump); // 0x288a61c (Index: 0x1, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UValet_GasPumpIndicatorManagerV2_C) == 0xe8, "Size mismatch for UValet_GasPumpIndicatorManagerV2_C");
static_assert(offsetof(UValet_GasPumpIndicatorManagerV2_C, FuelIndicatorClass) == 0xb8, "Offset mismatch for UValet_GasPumpIndicatorManagerV2_C::FuelIndicatorClass");
static_assert(offsetof(UValet_GasPumpIndicatorManagerV2_C, GasPumpList) == 0xc0, "Offset mismatch for UValet_GasPumpIndicatorManagerV2_C::GasPumpList");
static_assert(offsetof(UValet_GasPumpIndicatorManagerV2_C, FuelIndicatorList) == 0xd0, "Offset mismatch for UValet_GasPumpIndicatorManagerV2_C::FuelIndicatorList");
static_assert(offsetof(UValet_GasPumpIndicatorManagerV2_C, FuelIndicatorRangeSquared) == 0xe0, "Offset mismatch for UValet_GasPumpIndicatorManagerV2_C::FuelIndicatorRangeSquared");

// Size: 0xd8 (Inherited: 0x198, Single: 0xffffff40)
class UB_GasPump_Valet_Component_C : public UGameFrameworkComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb8 (Size: 0x8, Type: StructProperty)
    FName Gas_Pump_Icon_Enabled; // 0xc0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c4[0x4]; // 0xc4 (Size: 0x4, Type: PaddingProperty)
    UClass* Gas_Pump_IndicatorManager_Class; // 0xc8 (Size: 0x8, Type: ClassProperty)
    UValet_GasPumpIndicatorManagerV2_C* Gas_Pump_IndicatorManager; // 0xd0 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UB_GasPump_Valet_Component_C) == 0xd8, "Size mismatch for UB_GasPump_Valet_Component_C");
static_assert(offsetof(UB_GasPump_Valet_Component_C, UberGraphFrame) == 0xb8, "Offset mismatch for UB_GasPump_Valet_Component_C::UberGraphFrame");
static_assert(offsetof(UB_GasPump_Valet_Component_C, Gas_Pump_Icon_Enabled) == 0xc0, "Offset mismatch for UB_GasPump_Valet_Component_C::Gas_Pump_Icon_Enabled");
static_assert(offsetof(UB_GasPump_Valet_Component_C, Gas_Pump_IndicatorManager_Class) == 0xc8, "Offset mismatch for UB_GasPump_Valet_Component_C::Gas_Pump_IndicatorManager_Class");
static_assert(offsetof(UB_GasPump_Valet_Component_C, Gas_Pump_IndicatorManager) == 0xd0, "Offset mismatch for UB_GasPump_Valet_Component_C::Gas_Pump_IndicatorManager");

