/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChronoWeaponGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"

// Size: 0x3f0 (Inherited: 0x408, Single: 0xffffffe8)
class UAnimInstance_ChronoPanRifle : public UAnimInstance
{
public:
    bool bIsFiring; // 0x3d8 (Size: 0x1, Type: BoolProperty)
    bool bIsReloading; // 0x3d9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3da[0x2]; // 0x3da (Size: 0x2, Type: PaddingProperty)
    float MagRotationValue; // 0x3dc (Size: 0x4, Type: FloatProperty)
    FName ResetMagRotationCurveName; // 0x3e0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3e4[0xc]; // 0x3e4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UAnimInstance_ChronoPanRifle) == 0x3f0, "Size mismatch for UAnimInstance_ChronoPanRifle");
static_assert(offsetof(UAnimInstance_ChronoPanRifle, bIsFiring) == 0x3d8, "Offset mismatch for UAnimInstance_ChronoPanRifle::bIsFiring");
static_assert(offsetof(UAnimInstance_ChronoPanRifle, bIsReloading) == 0x3d9, "Offset mismatch for UAnimInstance_ChronoPanRifle::bIsReloading");
static_assert(offsetof(UAnimInstance_ChronoPanRifle, MagRotationValue) == 0x3dc, "Offset mismatch for UAnimInstance_ChronoPanRifle::MagRotationValue");
static_assert(offsetof(UAnimInstance_ChronoPanRifle, ResetMagRotationCurveName) == 0x3e0, "Offset mismatch for UAnimInstance_ChronoPanRifle::ResetMagRotationCurveName");

