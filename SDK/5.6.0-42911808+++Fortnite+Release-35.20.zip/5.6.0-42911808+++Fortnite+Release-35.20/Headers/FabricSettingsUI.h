/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricSettingsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "CoreUObject.h"

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UFortGameSettingRegistryExtension_Fabric : public UFortGameSettingRegistryExtension
{
public:
};

static_assert(sizeof(UFortGameSettingRegistryExtension_Fabric) == 0x30, "Size mismatch for UFortGameSettingRegistryExtension_Fabric");

// Size: 0x40 (Inherited: 0x68, Single: 0xffffffd8)
class UFortSettingEditCondition_FabricEnabledForLinkEntry : public UFortSettingEditCondition
{
public:
};

static_assert(sizeof(UFortSettingEditCondition_FabricEnabledForLinkEntry) == 0x40, "Size mismatch for UFortSettingEditCondition_FabricEnabledForLinkEntry");

