/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChatCompletion
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "JsonUtilities.h"

// Size: 0xc8 (Inherited: 0x28, Single: 0xa0)
class UChatCompleter : public UObject
{
public:
    uint8_t OnGenerateResponse[0x10]; // 0x28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnGenerateStructuredResponse[0x10]; // 0x38 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnGenerateStreamingResponse[0x10]; // 0x48 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnResponse[0x10]; // 0x58 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStructuredResponse[0x10]; // 0x68 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFailure[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnStreamingResponse[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnBeginStreamingFunctionCall[0x10]; // 0x98 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnUpdateStreamingFunctionCallArg[0x10]; // 0xa8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TWeakObjectPtr<UChatCompletionSubsystem*> Subsystem; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    bool bStripFromClientBuilds; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0x7]; // 0xc1 (Size: 0x7, Type: PaddingProperty)

public:
    void CancelRequest(FChatCompletionRequestHandle& ChatCompletionRequestHandle); // 0x114a1b90 (Index: 0x0, Flags: Native|Public|HasOutParms|BlueprintCallable)
    bool CanModerateHarmCategory(EChatCompletionHarmCategory& HarmCategory) const; // 0x114a1954 (Index: 0x1, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ChatCompleterOnBeginStreamingFunctionCallDelegate__DelegateSignature(const FChatCompletionRequestHandle RequestHandle, const FChatCompletionFunctionCall FunctionCall); // 0x288a61c (Index: 0x2, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void ChatCompleterOnFailureDelegate__DelegateSignature(const FChatCompletionRequestHandle RequestHandle, const EChatCompletionErrorFlags ErrorFlags); // 0x288a61c (Index: 0x3, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void ChatCompleterOnGenerateResponseDelegate__DelegateSignature(const FChatCompletionChat chat, const FChatCompletionSettings ChatCompletionSettings, FChatCompletionRequestHandle& RequestHandle); // 0x288a61c (Index: 0x4, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void ChatCompleterOnGenerateStreamingResponseDelegate__DelegateSignature(const FChatCompletionChat chat, const FChatCompletionSettings ChatCompletionSettings, FChatCompletionRequestHandle& RequestHandle); // 0x288a61c (Index: 0x5, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void ChatCompleterOnGenerateStructuredResponseDelegate__DelegateSignature(const FChatCompletionChat chat, const FChatCompletionSettings ChatCompletionSettings, const FChatCompletionStructuredResponseDataSchema StructuredResponseSchema, FChatCompletionRequestHandle& RequestHandle); // 0x288a61c (Index: 0x6, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void ChatCompleterOnResponseDelegate__DelegateSignature(const FChatCompletionRequestHandle RequestHandle, const FChatCompletionResponseMessage ResponseMessage); // 0x288a61c (Index: 0x7, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void ChatCompleterOnStreamingResponseDelegate__DelegateSignature(const FChatCompletionRequestHandle RequestHandle, FString& ResponseMessage, int32_t& PreviousLength); // 0x288a61c (Index: 0x8, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void ChatCompleterOnStructuredResponseDelegate__DelegateSignature(const FChatCompletionRequestHandle RequestHandle, const FChatCompletionStructuredResponseMessage StructuredResponseMessage); // 0x288a61c (Index: 0x9, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void ChatCompleterOnUpdateStreamingFunctionCallArgDelegate__DelegateSignature(const FChatCompletionRequestHandle RequestHandle, const FChatCompletionFunctionCall FunctionCall, FString& UpdatedArg, EChatCompletionFunctionCallArgUpdateReason& ArgUpdateReason, int32_t& PreviousLength); // 0x288a61c (Index: 0xa, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    FChatCompletionRequestHandle GenerateResponse(const FChatCompletionChat chat, const FChatCompletionSettings ChatCompletionSettings, const FDelegate ResponseDelegate, const FDelegate FailureDelegate, AController*& Instigator, const FGuid AnalyticsEventGroupID); // 0x114a2bb8 (Index: 0xb, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    FChatCompletionRequestHandle GenerateStreamingResponse(const FChatCompletionChat chat, const FChatCompletionSettings ChatCompletionSettings, const FDelegate StreamingResponseDelegate, const FDelegate BeginStreamingFunctionCallDelegate, const FDelegate UpdateStreamingFunctionCallDelegate, const FDelegate ResponseDelegate, const FDelegate FailureDelegate, AController*& Instigator, const FGuid AnalyticsEventGroupID); // 0x114a2ff0 (Index: 0xc, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    FChatCompletionRequestHandle GenerateStructuredResponse(const FChatCompletionChat chat, const FChatCompletionSettings ChatCompletionSettings, const FChatCompletionStructuredResponseDataSchema StructuredResponseSchema, const FDelegate StructuredResponseDelegate, const FDelegate FailureDelegate, AController*& Instigator, const FGuid AnalyticsEventGroupID); // 0x114a3b08 (Index: 0xd, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    TArray<FString> GetSupportedAttachmentMIMETypes() const; // 0x114a4b34 (Index: 0xe, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool LoadChatCompletionRequestFromFile(FString& ChatCompletionRequestFilename, FChatCompletionChat& OutChat, FChatCompletionSettings& OutChatCompletionSettings); // 0x114a4fb8 (Index: 0xf, Flags: Native|Public|HasOutParms|BlueprintCallable)
    bool LoadStructuredChatCompletionRequestFromFile(FString& ChatCompletionRequestFilename, FChatCompletionChat& OutChat, FChatCompletionSettings& OutChatCompletionSettings, FChatCompletionStructuredResponseDataSchema& OutStructuredResponseSchema); // 0x114a6154 (Index: 0x10, Flags: Native|Public|HasOutParms|BlueprintCallable)
    bool ParseChatCompletionRequestFromString(FString& ChatCompletionRequestString, FChatCompletionChat& OutChat, FChatCompletionSettings& OutChatCompletionSettings); // 0x114a782c (Index: 0x11, Flags: Native|Public|HasOutParms|BlueprintCallable)
    bool ParseStructuredChatCompletionRequestFromString(FString& ChatCompletionRequestString, FChatCompletionChat& OutChat, FChatCompletionSettings& OutChatCompletionSettings, FChatCompletionStructuredResponseDataSchema& OutStructuredResponseSchema); // 0x114a8acc (Index: 0x12, Flags: Native|Public|HasOutParms|BlueprintCallable)
    bool SupportsAttachmentMIMEType(FString& mimetype); // 0x114a8f38 (Index: 0x13, Flags: Native|Public|BlueprintCallable)
    bool SupportsFunctionCallingMode(const EChatCompletionFunctionCallingMode FunctionCallingMode) const; // 0x114a9238 (Index: 0x14, Flags: Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool SupportsFunctionCallStreaming() const; // 0x1146c8ac (Index: 0x15, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool SupportsResponseMessageStreaming() const; // 0x114a931c (Index: 0x16, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool SupportsStructuredResponses() const; // 0xdd06dc4 (Index: 0x17, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UChatCompleter) == 0xc8, "Size mismatch for UChatCompleter");
static_assert(offsetof(UChatCompleter, OnGenerateResponse) == 0x28, "Offset mismatch for UChatCompleter::OnGenerateResponse");
static_assert(offsetof(UChatCompleter, OnGenerateStructuredResponse) == 0x38, "Offset mismatch for UChatCompleter::OnGenerateStructuredResponse");
static_assert(offsetof(UChatCompleter, OnGenerateStreamingResponse) == 0x48, "Offset mismatch for UChatCompleter::OnGenerateStreamingResponse");
static_assert(offsetof(UChatCompleter, OnResponse) == 0x58, "Offset mismatch for UChatCompleter::OnResponse");
static_assert(offsetof(UChatCompleter, OnStructuredResponse) == 0x68, "Offset mismatch for UChatCompleter::OnStructuredResponse");
static_assert(offsetof(UChatCompleter, OnFailure) == 0x78, "Offset mismatch for UChatCompleter::OnFailure");
static_assert(offsetof(UChatCompleter, OnStreamingResponse) == 0x88, "Offset mismatch for UChatCompleter::OnStreamingResponse");
static_assert(offsetof(UChatCompleter, OnBeginStreamingFunctionCall) == 0x98, "Offset mismatch for UChatCompleter::OnBeginStreamingFunctionCall");
static_assert(offsetof(UChatCompleter, OnUpdateStreamingFunctionCallArg) == 0xa8, "Offset mismatch for UChatCompleter::OnUpdateStreamingFunctionCallArg");
static_assert(offsetof(UChatCompleter, Subsystem) == 0xb8, "Offset mismatch for UChatCompleter::Subsystem");
static_assert(offsetof(UChatCompleter, bStripFromClientBuilds) == 0xc0, "Offset mismatch for UChatCompleter::bStripFromClientBuilds");

// Size: 0x68 (Inherited: 0x88, Single: 0xffffffe0)
class UAsyncAction_ChatCompletionRequest : public UCancellableAsyncAction
{
public:
    uint8_t OnSuccess[0x10]; // 0x30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFailure[0x10]; // 0x40 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UChatCompleter* ChatCompleter; // 0x50 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_58[0x10]; // 0x58 (Size: 0x10, Type: PaddingProperty)

public:
    void ChatCompletionRequestDelegate__DelegateSignature(const FChatCompletionResponseMessage ResponseMessage, const EChatCompletionErrorFlags ErrorFlags); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    static UAsyncAction_ChatCompletionRequest* GenerateChatCompletionResponse(UChatCompleter*& ChatCompleter, const FChatCompletionChat chat, const FChatCompletionSettings ChatCompletionSettings, AController*& Instigator, const FGuid AnalyticsEventGroupID); // 0x114a26f8 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)

protected:
    void OnChatCompletionFailure(const FChatCompletionRequestHandle RequestHandle, const EChatCompletionErrorFlags ErrorFlags); // 0x114a70cc (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
    void OnChatCompletionResponse(const FChatCompletionRequestHandle RequestHandle, const FChatCompletionResponseMessage ResponseMessage); // 0x114a7404 (Index: 0x3, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UAsyncAction_ChatCompletionRequest) == 0x68, "Size mismatch for UAsyncAction_ChatCompletionRequest");
static_assert(offsetof(UAsyncAction_ChatCompletionRequest, OnSuccess) == 0x30, "Offset mismatch for UAsyncAction_ChatCompletionRequest::OnSuccess");
static_assert(offsetof(UAsyncAction_ChatCompletionRequest, OnFailure) == 0x40, "Offset mismatch for UAsyncAction_ChatCompletionRequest::OnFailure");
static_assert(offsetof(UAsyncAction_ChatCompletionRequest, ChatCompleter) == 0x50, "Offset mismatch for UAsyncAction_ChatCompletionRequest::ChatCompleter");

// Size: 0x68 (Inherited: 0x88, Single: 0xffffffe0)
class UAsyncAction_StructuredChatCompletionRequest : public UCancellableAsyncAction
{
public:
    uint8_t OnSuccess[0x10]; // 0x30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFailure[0x10]; // 0x40 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UChatCompleter* ChatCompleter; // 0x50 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_58[0x10]; // 0x58 (Size: 0x10, Type: PaddingProperty)

public:
    static UAsyncAction_StructuredChatCompletionRequest* GenerateStructuredChatCompletionResponse(UChatCompleter*& ChatCompleter, const FChatCompletionChat chat, const FChatCompletionSettings ChatCompletionSettings, const FChatCompletionStructuredResponseDataSchema StructuredResponseSchema, AController*& Instigator, const FGuid AnalyticsEventGroupID); // 0x114a35dc (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void StructuredChatCompletionRequestDelegate__DelegateSignature(const FChatCompletionStructuredResponseMessage StructuredResponseMessage, const EChatCompletionErrorFlags ErrorFlags); // 0x288a61c (Index: 0x3, Flags: MulticastDelegate|Public|Delegate|HasOutParms)

protected:
    void OnChatCompletionFailure(const FChatCompletionRequestHandle RequestHandle, const EChatCompletionErrorFlags ErrorFlags); // 0x114a7268 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
    void OnChatCompletionStructuredResponse(const FChatCompletionRequestHandle RequestHandle, const FChatCompletionStructuredResponseMessage StructuredResponseMessage); // 0x114a7668 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UAsyncAction_StructuredChatCompletionRequest) == 0x68, "Size mismatch for UAsyncAction_StructuredChatCompletionRequest");
static_assert(offsetof(UAsyncAction_StructuredChatCompletionRequest, OnSuccess) == 0x30, "Offset mismatch for UAsyncAction_StructuredChatCompletionRequest::OnSuccess");
static_assert(offsetof(UAsyncAction_StructuredChatCompletionRequest, OnFailure) == 0x40, "Offset mismatch for UAsyncAction_StructuredChatCompletionRequest::OnFailure");
static_assert(offsetof(UAsyncAction_StructuredChatCompletionRequest, ChatCompleter) == 0x50, "Offset mismatch for UAsyncAction_StructuredChatCompletionRequest::ChatCompleter");

// Size: 0xc8 (Inherited: 0xf0, Single: 0xffffffd8)
class UChatCompleterBase : public UChatCompleter
{
public:

public:
    EChatCompletionErrorFlags ChatCompletionRequestToJson(const FChatCompletionChat chat, const FChatCompletionSettings ChatCompletionSettings, bool& bStreamResponse, bool& bStructuredResponse, const FChatCompletionStructuredResponseDataSchema StructuredResponseSchema, FJsonObjectWrapper& OutChatRequestJson); // 0x114a1c94 (Index: 0x0, Flags: Native|Public|HasOutParms|BlueprintCallable)
    EChatCompletionErrorFlags ChatCompletionRequestToString(const FChatCompletionChat chat, const FChatCompletionSettings ChatCompletionSettings, bool& bStreamResponse, bool& bStructuredResponse, const FChatCompletionStructuredResponseDataSchema StructuredResponseSchema, FString& OutChatCompletionRequestString); // 0x114a209c (Index: 0x1, Flags: Native|Public|HasOutParms|BlueprintCallable)
    FString GetEndpointURL(bool& bStreamResponse); // 0x114a4624 (Index: 0x2, Flags: Native|Public|BlueprintCallable)
    void GetHeaders(bool& bStreamResponse, TMap<FString, FString>& OutHeaders); // 0x114a492c (Index: 0x3, Flags: Native|Public|HasOutParms|BlueprintCallable)
    EChatCompletionErrorFlags ParseChatCompletionResponseFromJson(const FJsonObjectWrapper ChatCompletionResponseJson, const FChatCompletionRequestHandle RequestHandle, FChatCompletionResponseMessage& OutResponseMessage); // 0x114a7c60 (Index: 0x4, Flags: Native|Public|HasOutParms|BlueprintCallable)
    EChatCompletionErrorFlags ParseChatCompletionResponseFromString(FString& ChatCompletionResponseString, const FChatCompletionRequestHandle RequestHandle, FChatCompletionResponseMessage& OutResponseMessage); // 0x114a7f44 (Index: 0x5, Flags: Native|Public|HasOutParms|BlueprintCallable)
    EChatCompletionErrorFlags ParseChatCompletionStructuredResponseFromJson(const FJsonObjectWrapper ChatCompletionStructuredResponseJson, const FChatCompletionRequestHandle RequestHandle, FChatCompletionStructuredResponseMessage& OutStructuredResponseMessage); // 0x114a83f8 (Index: 0x6, Flags: Native|Public|HasOutParms|BlueprintCallable)
    EChatCompletionErrorFlags ParseChatCompletionStructuredResponseFromString(FString& ChatCompletionStructuredResponseString, const FChatCompletionRequestHandle RequestHandle, FChatCompletionStructuredResponseMessage& OutStructuredResponseMessage); // 0x114a865c (Index: 0x7, Flags: Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UChatCompleterBase) == 0xc8, "Size mismatch for UChatCompleterBase");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChatCompletionCheatManager : public UCheatManagerExtension
{
public:

private:
    void ChatCompletionBugReport(bool& bExploreOutputDir); // 0x9e6e1b8 (Index: 0x0, Flags: Final|Exec|Native|Private)
};

static_assert(sizeof(UChatCompletionCheatManager) == 0x28, "Size mismatch for UChatCompletionCheatManager");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChatCompletionFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool AddAttachmentToLastUserMessage(FChatCompletionChat chat, const FChatCompletionAttachment ChatCompletionAttachment); // 0x114a15a4 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FJsonObjectWrapper BP_StructToJsonSchema(UStruct*& Struct, const FChatCompletionPropertyMetaData PropertyMetaData); // 0x114a1750 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void CancelChatCompletionRequest(FChatCompletionRequestHandle ChatCompletionRequestHandle); // 0x114a1a94 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool EqualEqual_ChatCompletionRequestHandle(const FChatCompletionRequestHandle A, const FChatCompletionRequestHandle B); // 0x114a251c (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void GetAllChatCompleters(UClass*& ChatCompleterType, TArray<UChatCompleter*>& OutAllChatCompleters); // 0x114a3fd4 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FName GetChatCompletionRequestName(const FChatCompletionRequestHandle ChatCompletionRequestHandle); // 0x114a4510 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FString InstancedStructToString(const FInstancedStruct InstancedStruct); // 0x114a4b64 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool IsChatCompletionRequestHandleValid(const FChatCompletionRequestHandle ChatCompletionRequestHandle); // 0x1035714c (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsChatCompletionStructuredDataSchemaValid(const FChatCompletionStructuredDataSchema ChatCompletionStructuredDataSchema); // 0x114a4cb4 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsChatCompletionStructuredResponseDataSchemaValid(const FChatCompletionStructuredResponseDataSchema ChatCompletionStructuredResponseDataSchema); // 0x114a4db4 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsSharedChatCompletionFunctionHandleValid(const FSharedChatCompletionFunctionHandle SharedChatCompletionFunctionHandle); // 0x1035714c (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsValid_ChatCompletionAttachment(const FChatCompletionAttachment Attachment); // 0x114a4ecc (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsValid_ChatCompletionRequestHandle(const FChatCompletionRequestHandle ChatCompletionRequestHandle); // 0x1035714c (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool LoadFileAsChatCompletionAttachment(FString& Filename, FString& mimetype, FChatCompletionAttachment& OutChatCompletionAttachment); // 0x114a53ec (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool LoadJsonFile(FString& FilePath, FString& JsonString, FJsonObjectWrapper& JsonObjectWrapper); // 0x114a58e0 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool LoadPromptFile(FString& FilePath, FString& PromptString); // 0x114a5d60 (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FChatCompletionStructuredResponseDataSchema MakeChatCompletionStructuredDataResponseSchema(const FName Name, UScriptStruct*& StructType, const FChatCompletionPropertyMetaData CustomPropertyMetaData); // 0x114a65c0 (Index: 0x10, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FChatCompletionStructuredDataSchema MakeChatCompletionStructuredDataSchema(UScriptStruct*& StructType, const FChatCompletionPropertyMetaData CustomPropertyMetaData); // 0x114a6820 (Index: 0x11, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FSharedChatCompletionFunctionHandle MakeSharedChatCompletionFunction(FString& Name, FString& Description, const FChatCompletionStructuredDataSchema ArgumentsSchema); // 0x114a6a28 (Index: 0x12, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool NotEqual_ChatCompletionRequestHandle(const FChatCompletionRequestHandle A, const FChatCompletionRequestHandle B); // 0x114a6ef0 (Index: 0x13, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UChatCompletionFunctionLibrary) == 0x28, "Size mismatch for UChatCompletionFunctionLibrary");

// Size: 0xc8 (Inherited: 0xb8, Single: 0x10)
class UChatCompletionSubsystem : public UEngineSubsystem
{
public:
    uint8_t Pad_30[0x88]; // 0x30 (Size: 0x88, Type: PaddingProperty)
    FString AnalyticsEventNamespace; // 0xb8 (Size: 0x10, Type: StrProperty)

public:
    FString GetAnalyticsEventNamespace() const; // 0xdb59ee8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RecordAnalyticsEvent(const FChatCompletionRequestHandle ChatCompletionRequestHandle, FString& EventName, const TMap<FString, FString> StringAttributes); // 0x114b3dd8 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetAnalyticsEventNamespace(FString& NewDefaultAnalyticsEventNamespace); // 0x114b40a8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UChatCompletionSubsystem) == 0xc8, "Size mismatch for UChatCompletionSubsystem");
static_assert(offsetof(UChatCompletionSubsystem, AnalyticsEventNamespace) == 0xb8, "Offset mismatch for UChatCompletionSubsystem::AnalyticsEventNamespace");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FChatCompletionFunctionCall
{
    FString ID; // 0x0 (Size: 0x10, Type: StrProperty)
    FSharedChatCompletionFunctionHandle Function; // 0x10 (Size: 0x10, Type: StructProperty)
    FChatCompletionStructuredData Arguments; // 0x20 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FChatCompletionFunctionCall) == 0x50, "Size mismatch for FChatCompletionFunctionCall");
static_assert(offsetof(FChatCompletionFunctionCall, ID) == 0x0, "Offset mismatch for FChatCompletionFunctionCall::ID");
static_assert(offsetof(FChatCompletionFunctionCall, Function) == 0x10, "Offset mismatch for FChatCompletionFunctionCall::Function");
static_assert(offsetof(FChatCompletionFunctionCall, Arguments) == 0x20, "Offset mismatch for FChatCompletionFunctionCall::Arguments");

// Size: 0x30 (Inherited: 0x20, Single: 0x10)
struct FChatCompletionStructuredData : FJsonObjectWrapper
{
    FInstancedStruct TypedData; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FChatCompletionStructuredData) == 0x30, "Size mismatch for FChatCompletionStructuredData");
static_assert(offsetof(FChatCompletionStructuredData, TypedData) == 0x20, "Offset mismatch for FChatCompletionStructuredData::TypedData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSharedChatCompletionFunctionHandle
{
};

static_assert(sizeof(FSharedChatCompletionFunctionHandle) == 0x10, "Size mismatch for FSharedChatCompletionFunctionHandle");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FChatCompletionRequestHandle
{
};

static_assert(sizeof(FChatCompletionRequestHandle) == 0x10, "Size mismatch for FChatCompletionRequestHandle");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FChatCompletionMessageBase
{
};

static_assert(sizeof(FChatCompletionMessageBase) == 0x8, "Size mismatch for FChatCompletionMessageBase");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FChatCompletionResponseMessageBase : FChatCompletionMessageBase
{
    TArray<FChatCompletionFunctionCall> FunctionCalls; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FChatCompletionResponseMessageBase) == 0x18, "Size mismatch for FChatCompletionResponseMessageBase");
static_assert(offsetof(FChatCompletionResponseMessageBase, FunctionCalls) == 0x8, "Offset mismatch for FChatCompletionResponseMessageBase::FunctionCalls");

// Size: 0x28 (Inherited: 0x20, Single: 0x8)
struct FChatCompletionResponseMessage : FChatCompletionResponseMessageBase
{
    FString Content; // 0x18 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FChatCompletionResponseMessage) == 0x28, "Size mismatch for FChatCompletionResponseMessage");
static_assert(offsetof(FChatCompletionResponseMessage, Content) == 0x18, "Offset mismatch for FChatCompletionResponseMessage::Content");

// Size: 0x48 (Inherited: 0x20, Single: 0x28)
struct FChatCompletionStructuredResponseMessage : FChatCompletionResponseMessageBase
{
    FChatCompletionStructuredData StructuredContent; // 0x18 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FChatCompletionStructuredResponseMessage) == 0x48, "Size mismatch for FChatCompletionStructuredResponseMessage");
static_assert(offsetof(FChatCompletionStructuredResponseMessage, StructuredContent) == 0x18, "Offset mismatch for FChatCompletionStructuredResponseMessage::StructuredContent");

// Size: 0xd8 (Inherited: 0x0, Single: 0xd8)
struct FChatCompletionSettings
{
    FChatCompletionGenerationSettings GenerationSettings; // 0x0 (Size: 0x24, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FChatCompletionSafetySettings SafetySettings; // 0x28 (Size: 0x50, Type: StructProperty)
    FChatCompletionRetrySettings RetrySettings; // 0x78 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FChatCompletionSettings) == 0xd8, "Size mismatch for FChatCompletionSettings");
static_assert(offsetof(FChatCompletionSettings, GenerationSettings) == 0x0, "Offset mismatch for FChatCompletionSettings::GenerationSettings");
static_assert(offsetof(FChatCompletionSettings, SafetySettings) == 0x28, "Offset mismatch for FChatCompletionSettings::SafetySettings");
static_assert(offsetof(FChatCompletionSettings, RetrySettings) == 0x78, "Offset mismatch for FChatCompletionSettings::RetrySettings");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FChatCompletionRetrySettings
{
    FChatCompletionRetryCounts RetryCounts; // 0x0 (Size: 0x58, Type: StructProperty)
    bool bAutoRespondToMalformedFunctionCalls; // 0x58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FChatCompletionRetrySettings) == 0x60, "Size mismatch for FChatCompletionRetrySettings");
static_assert(offsetof(FChatCompletionRetrySettings, RetryCounts) == 0x0, "Offset mismatch for FChatCompletionRetrySettings::RetryCounts");
static_assert(offsetof(FChatCompletionRetrySettings, bAutoRespondToMalformedFunctionCalls) == 0x58, "Offset mismatch for FChatCompletionRetrySettings::bAutoRespondToMalformedFunctionCalls");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FChatCompletionRetryCounts
{
    int32_t AnyReasonRetryCount; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TMap<int32_t, EChatCompletionErrorFlags> ErrorRetryCounts; // 0x8 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FChatCompletionRetryCounts) == 0x58, "Size mismatch for FChatCompletionRetryCounts");
static_assert(offsetof(FChatCompletionRetryCounts, AnyReasonRetryCount) == 0x0, "Offset mismatch for FChatCompletionRetryCounts::AnyReasonRetryCount");
static_assert(offsetof(FChatCompletionRetryCounts, ErrorRetryCounts) == 0x8, "Offset mismatch for FChatCompletionRetryCounts::ErrorRetryCounts");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FChatCompletionSafetySettings
{
    TMap<FChatCompletionSafetySetting, EChatCompletionHarmCategory> HarmCategorySettings; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FChatCompletionSafetySettings) == 0x50, "Size mismatch for FChatCompletionSafetySettings");
static_assert(offsetof(FChatCompletionSafetySettings, HarmCategorySettings) == 0x0, "Offset mismatch for FChatCompletionSafetySettings::HarmCategorySettings");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FChatCompletionSafetySetting
{
    uint8_t BlockThreshold; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t BlockMethod; // 0x1 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FChatCompletionSafetySetting) == 0x2, "Size mismatch for FChatCompletionSafetySetting");
static_assert(offsetof(FChatCompletionSafetySetting, BlockThreshold) == 0x0, "Offset mismatch for FChatCompletionSafetySetting::BlockThreshold");
static_assert(offsetof(FChatCompletionSafetySetting, BlockMethod) == 0x1, "Offset mismatch for FChatCompletionSafetySetting::BlockMethod");

// Size: 0x24 (Inherited: 0x0, Single: 0x24)
struct FChatCompletionGenerationSettings
{
    uint8_t Temperature[0x8]; // 0x0 (Size: 0x8, Type: OptionalProperty)
    uint8_t FunctionCallingMode; // 0x8 (Size: 0x1, Type: EnumProperty)
    bool bAllowParallelFunctionCalls; // 0x9 (Size: 0x1, Type: BoolProperty)
    bool bAutoSubstituteUndefinedFunctionCallHistory; // 0xa (Size: 0x1, Type: BoolProperty)
    uint8_t ResponseFormat; // 0xb (Size: 0x1, Type: EnumProperty)
    uint8_t MaxOutputTokens[0x8]; // 0xc (Size: 0x8, Type: OptionalProperty)
    uint8_t FrequencyPenalty[0x8]; // 0x14 (Size: 0x8, Type: OptionalProperty)
    uint8_t PresencePenalty[0x8]; // 0x1c (Size: 0x8, Type: OptionalProperty)
};

static_assert(sizeof(FChatCompletionGenerationSettings) == 0x24, "Size mismatch for FChatCompletionGenerationSettings");
static_assert(offsetof(FChatCompletionGenerationSettings, Temperature) == 0x0, "Offset mismatch for FChatCompletionGenerationSettings::Temperature");
static_assert(offsetof(FChatCompletionGenerationSettings, FunctionCallingMode) == 0x8, "Offset mismatch for FChatCompletionGenerationSettings::FunctionCallingMode");
static_assert(offsetof(FChatCompletionGenerationSettings, bAllowParallelFunctionCalls) == 0x9, "Offset mismatch for FChatCompletionGenerationSettings::bAllowParallelFunctionCalls");
static_assert(offsetof(FChatCompletionGenerationSettings, bAutoSubstituteUndefinedFunctionCallHistory) == 0xa, "Offset mismatch for FChatCompletionGenerationSettings::bAutoSubstituteUndefinedFunctionCallHistory");
static_assert(offsetof(FChatCompletionGenerationSettings, ResponseFormat) == 0xb, "Offset mismatch for FChatCompletionGenerationSettings::ResponseFormat");
static_assert(offsetof(FChatCompletionGenerationSettings, MaxOutputTokens) == 0xc, "Offset mismatch for FChatCompletionGenerationSettings::MaxOutputTokens");
static_assert(offsetof(FChatCompletionGenerationSettings, FrequencyPenalty) == 0x14, "Offset mismatch for FChatCompletionGenerationSettings::FrequencyPenalty");
static_assert(offsetof(FChatCompletionGenerationSettings, PresencePenalty) == 0x1c, "Offset mismatch for FChatCompletionGenerationSettings::PresencePenalty");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FChatCompletionChat
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FString SystemMessage; // 0x8 (Size: 0x10, Type: StrProperty)
    TArray<FInstancedStruct> Messages; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FSharedChatCompletionFunctionHandle> Functions; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FChatCompletionChat) == 0x38, "Size mismatch for FChatCompletionChat");
static_assert(offsetof(FChatCompletionChat, Name) == 0x0, "Offset mismatch for FChatCompletionChat::Name");
static_assert(offsetof(FChatCompletionChat, SystemMessage) == 0x8, "Offset mismatch for FChatCompletionChat::SystemMessage");
static_assert(offsetof(FChatCompletionChat, Messages) == 0x18, "Offset mismatch for FChatCompletionChat::Messages");
static_assert(offsetof(FChatCompletionChat, Functions) == 0x28, "Offset mismatch for FChatCompletionChat::Functions");

// Size: 0x100 (Inherited: 0x0, Single: 0x100)
struct FChatCompletionStructuredDataSchema
{
    UScriptStruct* StructType; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bHasCustomPropertyMetaData; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    FChatCompletionPropertyMetaData PropertyMetaData; // 0x10 (Size: 0xf0, Type: StructProperty)
};

static_assert(sizeof(FChatCompletionStructuredDataSchema) == 0x100, "Size mismatch for FChatCompletionStructuredDataSchema");
static_assert(offsetof(FChatCompletionStructuredDataSchema, StructType) == 0x0, "Offset mismatch for FChatCompletionStructuredDataSchema::StructType");
static_assert(offsetof(FChatCompletionStructuredDataSchema, bHasCustomPropertyMetaData) == 0x8, "Offset mismatch for FChatCompletionStructuredDataSchema::bHasCustomPropertyMetaData");
static_assert(offsetof(FChatCompletionStructuredDataSchema, PropertyMetaData) == 0x10, "Offset mismatch for FChatCompletionStructuredDataSchema::PropertyMetaData");

// Size: 0xf0 (Inherited: 0x0, Single: 0xf0)
struct FChatCompletionPropertyMetaData
{
    TMap<FText, FString> PropertyDescriptions; // 0x0 (Size: 0x50, Type: MapProperty)
    TMap<double, FString> PropertyClampMin; // 0x50 (Size: 0x50, Type: MapProperty)
    TMap<double, FString> PropertyClampMax; // 0xa0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FChatCompletionPropertyMetaData) == 0xf0, "Size mismatch for FChatCompletionPropertyMetaData");
static_assert(offsetof(FChatCompletionPropertyMetaData, PropertyDescriptions) == 0x0, "Offset mismatch for FChatCompletionPropertyMetaData::PropertyDescriptions");
static_assert(offsetof(FChatCompletionPropertyMetaData, PropertyClampMin) == 0x50, "Offset mismatch for FChatCompletionPropertyMetaData::PropertyClampMin");
static_assert(offsetof(FChatCompletionPropertyMetaData, PropertyClampMax) == 0xa0, "Offset mismatch for FChatCompletionPropertyMetaData::PropertyClampMax");

// Size: 0x108 (Inherited: 0x100, Single: 0x8)
struct FChatCompletionStructuredResponseDataSchema : FChatCompletionStructuredDataSchema
{
    FName Name; // 0x100 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_104[0x4]; // 0x104 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FChatCompletionStructuredResponseDataSchema) == 0x108, "Size mismatch for FChatCompletionStructuredResponseDataSchema");
static_assert(offsetof(FChatCompletionStructuredResponseDataSchema, Name) == 0x100, "Offset mismatch for FChatCompletionStructuredResponseDataSchema::Name");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FChatCompletionAttachment
{
    FString mimetype; // 0x0 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_10[0x20]; // 0x10 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(FChatCompletionAttachment) == 0x30, "Size mismatch for FChatCompletionAttachment");
static_assert(offsetof(FChatCompletionAttachment, mimetype) == 0x0, "Offset mismatch for FChatCompletionAttachment::mimetype");

// Size: 0x220 (Inherited: 0x0, Single: 0x220)
struct FChatCompletionFunction
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Description; // 0x10 (Size: 0x10, Type: StrProperty)
    FChatCompletionStructuredDataSchema ArgumentsSchema; // 0x20 (Size: 0x100, Type: StructProperty)
    FChatCompletionStructuredDataSchema ResponseSchema; // 0x120 (Size: 0x100, Type: StructProperty)
};

static_assert(sizeof(FChatCompletionFunction) == 0x220, "Size mismatch for FChatCompletionFunction");
static_assert(offsetof(FChatCompletionFunction, Name) == 0x0, "Offset mismatch for FChatCompletionFunction::Name");
static_assert(offsetof(FChatCompletionFunction, Description) == 0x10, "Offset mismatch for FChatCompletionFunction::Description");
static_assert(offsetof(FChatCompletionFunction, ArgumentsSchema) == 0x20, "Offset mismatch for FChatCompletionFunction::ArgumentsSchema");
static_assert(offsetof(FChatCompletionFunction, ResponseSchema) == 0x120, "Offset mismatch for FChatCompletionFunction::ResponseSchema");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FChatCompletionFunctionCallResult
{
    FSharedChatCompletionFunctionHandle Function; // 0x0 (Size: 0x10, Type: StructProperty)
    FString FunctionCallID; // 0x10 (Size: 0x10, Type: StrProperty)
    FChatCompletionStructuredData Result; // 0x20 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FChatCompletionFunctionCallResult) == 0x50, "Size mismatch for FChatCompletionFunctionCallResult");
static_assert(offsetof(FChatCompletionFunctionCallResult, Function) == 0x0, "Offset mismatch for FChatCompletionFunctionCallResult::Function");
static_assert(offsetof(FChatCompletionFunctionCallResult, FunctionCallID) == 0x10, "Offset mismatch for FChatCompletionFunctionCallResult::FunctionCallID");
static_assert(offsetof(FChatCompletionFunctionCallResult, Result) == 0x20, "Offset mismatch for FChatCompletionFunctionCallResult::Result");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FChatCompletionUserMessage : FChatCompletionMessageBase
{
    FString Content; // 0x8 (Size: 0x10, Type: StrProperty)
    TArray<FChatCompletionAttachment> Attachments; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FChatCompletionUserMessage) == 0x28, "Size mismatch for FChatCompletionUserMessage");
static_assert(offsetof(FChatCompletionUserMessage, Content) == 0x8, "Offset mismatch for FChatCompletionUserMessage::Content");
static_assert(offsetof(FChatCompletionUserMessage, Attachments) == 0x18, "Offset mismatch for FChatCompletionUserMessage::Attachments");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FChatCompletionFunctionResultsMessage : FChatCompletionMessageBase
{
    TArray<FChatCompletionFunctionCallResult> FunctionResults; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FChatCompletionFunctionResultsMessage) == 0x18, "Size mismatch for FChatCompletionFunctionResultsMessage");
static_assert(offsetof(FChatCompletionFunctionResultsMessage, FunctionResults) == 0x8, "Offset mismatch for FChatCompletionFunctionResultsMessage::FunctionResults");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FChatCompletionUsage
{
};

static_assert(sizeof(FChatCompletionUsage) == 0x18, "Size mismatch for FChatCompletionUsage");

