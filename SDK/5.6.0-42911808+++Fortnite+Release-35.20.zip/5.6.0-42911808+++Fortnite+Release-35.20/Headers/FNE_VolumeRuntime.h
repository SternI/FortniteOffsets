/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNE_VolumeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "PlayspaceSystem.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "FortniteGame.h"

// Size: 0x348 (Inherited: 0x618, Single: 0xfffffd30)
class AFNE_Volume : public AGameplayVolume
{
public:
};

static_assert(sizeof(AFNE_Volume) == 0x348, "Size mismatch for AFNE_Volume");

// Size: 0x330 (Inherited: 0x5b0, Single: 0xfffffd80)
class UFNE_VolumeComponent : public UChildActorComponent
{
public:
    uint8_t OnPlayerStateBeginOverlap[0x10]; // 0x290 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPlayerStateEndOverlap[0x10]; // 0x2a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnOtherActorBeginOverlap[0x10]; // 0x2b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnOtherActorEndOverlap[0x10]; // 0x2c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bEnableOverlap; // 0x2d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d1[0x7]; // 0x2d1 (Size: 0x7, Type: PaddingProperty)
    TMap<UStaticMesh*, EFNEVolumeShapeTypeEnum> FNEVolumeShapeMap; // 0x2d8 (Size: 0x50, Type: MapProperty)
    USpatialGameplayActorTrackerComponent* SpatialGameplayActorTracker; // 0x328 (Size: 0x8, Type: ObjectProperty)

public:
    bool BindToOnOtherActorBeginOverlap(const FDelegate InEvent); // 0x11174bc8 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool BindToOnOtherActorEndOverlap(const FDelegate InEvent); // 0x11174de0 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    TArray<APawn*> GetAllPlayerPawns() const; // 0x11175984 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<APlayerState*> GetAllPlayerStates() const; // 0x111759fc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<AActor*> GetAllTrackedActors() const; // 0x11175a7c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetEnableOverlap() const; // 0xd27aa48 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AFNE_Volume* GetSpawnedVolume() const; // 0x11175b14 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UOverlapComponent* GetSpawnedVolumeBoundsComponent(); // 0x11175b38 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void SetEnableOverlap(bool& const bEnable); // 0xda18cf0 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    void SetRelativeScale3DForBoundsComponent(const FVector Scale3D); // 0x111772a4 (Index: 0xd, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    bool SetStaticMeshForBoundsComponent(UStaticMesh*& NewMesh); // 0x11177464 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    void UnBindFromOnOtherActorBeginOverlap(const FDelegate InEvent); // 0x11177c18 (Index: 0xf, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UnBindFromOnOtherActorEndOverlap(const FDelegate InEvent); // 0x11177e18 (Index: 0x10, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UpdateOverLapShape(EFNEVolumeShapeTypeEnum& EShape, bool& const bUseCustomShape, UStaticMesh*& CustomShape); // 0x11178018 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)

private:
    void HandleNotifyActorBeginOverlap(AActor*& OverlappedActor, AActor*& OtherActor); // 0x11175b5c (Index: 0x8, Flags: Final|Native|Private)
    void HandleNotifyActorEndOverlap(AActor*& OverlappedActor, AActor*& OtherActor); // 0x11175d64 (Index: 0x9, Flags: Final|Native|Private)

protected:
    void HandleNotifyPlayerStateBeginOverlap(APlayerState*& TouchingPlayerState, AGameplayVolume*& Volume); // 0x11175f6c (Index: 0xa, Flags: Final|Native|Protected)
    void HandleNotifyPlayerStateEndOverlap(APlayerState*& TouchingPlayerState, AGameplayVolume*& Volume); // 0x11176174 (Index: 0xb, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFNE_VolumeComponent) == 0x330, "Size mismatch for UFNE_VolumeComponent");
static_assert(offsetof(UFNE_VolumeComponent, OnPlayerStateBeginOverlap) == 0x290, "Offset mismatch for UFNE_VolumeComponent::OnPlayerStateBeginOverlap");
static_assert(offsetof(UFNE_VolumeComponent, OnPlayerStateEndOverlap) == 0x2a0, "Offset mismatch for UFNE_VolumeComponent::OnPlayerStateEndOverlap");
static_assert(offsetof(UFNE_VolumeComponent, OnOtherActorBeginOverlap) == 0x2b0, "Offset mismatch for UFNE_VolumeComponent::OnOtherActorBeginOverlap");
static_assert(offsetof(UFNE_VolumeComponent, OnOtherActorEndOverlap) == 0x2c0, "Offset mismatch for UFNE_VolumeComponent::OnOtherActorEndOverlap");
static_assert(offsetof(UFNE_VolumeComponent, bEnableOverlap) == 0x2d0, "Offset mismatch for UFNE_VolumeComponent::bEnableOverlap");
static_assert(offsetof(UFNE_VolumeComponent, FNEVolumeShapeMap) == 0x2d8, "Offset mismatch for UFNE_VolumeComponent::FNEVolumeShapeMap");
static_assert(offsetof(UFNE_VolumeComponent, SpatialGameplayActorTracker) == 0x328, "Offset mismatch for UFNE_VolumeComponent::SpatialGameplayActorTracker");

// Size: 0x730 (Inherited: 0x13b0, Single: 0xfffff380)
class UFNE_VolumeOverlapComponent : public UStaticMeshComponent
{
public:
    uint8_t OnPlayerStateBeginOverlap[0x10]; // 0x608 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPlayerStateEndOverlap[0x10]; // 0x618 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnOtherActorBeginOverlap[0x10]; // 0x628 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnOtherActorEndOverlap[0x10]; // 0x638 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t EnableOverlapBehavior; // 0x648 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_649[0x7]; // 0x649 (Size: 0x7, Type: PaddingProperty)
    TMap<UStaticMesh*, EFNEVolumeShapeTypeEnum> FNEVolumeShapeMap; // 0x650 (Size: 0x50, Type: MapProperty)
    uint8_t SceneQueryShape; // 0x6a0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_6a1[0x7]; // 0x6a1 (Size: 0x7, Type: PaddingProperty)
    TArray<TEnumAsByte<EObjectTypeQuery>> SceneQueryObjectTypes; // 0x6a8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_6b8[0x20]; // 0x6b8 (Size: 0x20, Type: PaddingProperty)
    TWeakObjectPtr<AFortMinigame*> CachedMinigame; // 0x6d8 (Size: 0x8, Type: WeakObjectProperty)
    TSet<AActor*> TrackedActors; // 0x6e0 (Size: 0x50, Type: SetProperty)

public:
    bool BindToOnOtherActorBeginOverlap(const FDelegate InEvent); // 0x11174cd4 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool BindToOnOtherActorEndOverlap(const FDelegate InEvent); // 0x11174eec (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void CheckCollidingActorsSceneQuery(); // 0x11174ff8 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    TArray<APawn*> GetAllPlayerPawns() const; // 0x111759c0 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<APlayerState*> GetAllPlayerStates() const; // 0x11175a3c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<AActor*> GetAllTrackedActors() const; // 0x11175abc (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EVolumeEnableOverlapBehavior GetEnableOverlap() const; // 0x11175afc (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetEnableOverlapBehavior(EVolumeEnableOverlapBehavior& const InOverlapBehavior); // 0x11177178 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    void SetRelativeScale3DForBoundsComponent(const FVector Scale3D); // 0x11177384 (Index: 0x11, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    bool SetStaticMeshForBoundsComponent(UStaticMesh*& NewMesh); // 0x1117759c (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)
    void SetVolumeMaterial(TSoftObjectPtr<UMaterialInterface*>& MaterialToLoad, int32_t& ElementIndex); // 0x111776d4 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)
    virtual bool ShouldAllowOverlapEventToFire(AActor*& OverlapActor); // 0x11177ad8 (Index: 0x14, Flags: Native|Event|Public|BlueprintEvent)
    void UnBindFromOnOtherActorBeginOverlap(const FDelegate InEvent); // 0x11177d18 (Index: 0x15, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UnBindFromOnOtherActorEndOverlap(const FDelegate InEvent); // 0x11177f18 (Index: 0x16, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UpdateOverLapShape(EFNEVolumeShapeTypeEnum& EShape, bool& const bUseCustomShape, UStaticMesh*& CustomShape); // 0x11178300 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)

private:
    void ActorEnteredVolume(AActor*& EnteringActor); // 0x11174970 (Index: 0x0, Flags: Final|Native|Private)
    void ActorExitVolume(AActor*& LeavingActor); // 0x11174a9c (Index: 0x1, Flags: Final|Native|Private)
    void ComponentAddedToMinigame(AFortMinigame*& Minigame); // 0x1117500c (Index: 0x5, Flags: Final|Native|Private)
    void HandleTrackedActorEndPlay(AActor*& Actor, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x1117637c (Index: 0xa, Flags: Final|Native|Private)
    void OnBeginActorOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult SweepResult); // 0x11176588 (Index: 0xb, Flags: Final|Native|Private|HasOutParms)
    void OnEndActorOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex); // 0x11176ac8 (Index: 0xc, Flags: Final|Native|Private)

protected:
    void OnMinigameEnded(); // 0x11176e6c (Index: 0xd, Flags: Final|Native|Protected)
    void OnMinigameRoundEnded(AFortPlayerController*& Instigator, EFortMinigameEnd& EndMethod, EFortMinigameState& NextState); // 0x11176e80 (Index: 0xe, Flags: Final|Native|Protected)
    void OnMinigameStarted(); // 0x11177164 (Index: 0xf, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFNE_VolumeOverlapComponent) == 0x730, "Size mismatch for UFNE_VolumeOverlapComponent");
static_assert(offsetof(UFNE_VolumeOverlapComponent, OnPlayerStateBeginOverlap) == 0x608, "Offset mismatch for UFNE_VolumeOverlapComponent::OnPlayerStateBeginOverlap");
static_assert(offsetof(UFNE_VolumeOverlapComponent, OnPlayerStateEndOverlap) == 0x618, "Offset mismatch for UFNE_VolumeOverlapComponent::OnPlayerStateEndOverlap");
static_assert(offsetof(UFNE_VolumeOverlapComponent, OnOtherActorBeginOverlap) == 0x628, "Offset mismatch for UFNE_VolumeOverlapComponent::OnOtherActorBeginOverlap");
static_assert(offsetof(UFNE_VolumeOverlapComponent, OnOtherActorEndOverlap) == 0x638, "Offset mismatch for UFNE_VolumeOverlapComponent::OnOtherActorEndOverlap");
static_assert(offsetof(UFNE_VolumeOverlapComponent, EnableOverlapBehavior) == 0x648, "Offset mismatch for UFNE_VolumeOverlapComponent::EnableOverlapBehavior");
static_assert(offsetof(UFNE_VolumeOverlapComponent, FNEVolumeShapeMap) == 0x650, "Offset mismatch for UFNE_VolumeOverlapComponent::FNEVolumeShapeMap");
static_assert(offsetof(UFNE_VolumeOverlapComponent, SceneQueryShape) == 0x6a0, "Offset mismatch for UFNE_VolumeOverlapComponent::SceneQueryShape");
static_assert(offsetof(UFNE_VolumeOverlapComponent, SceneQueryObjectTypes) == 0x6a8, "Offset mismatch for UFNE_VolumeOverlapComponent::SceneQueryObjectTypes");
static_assert(offsetof(UFNE_VolumeOverlapComponent, CachedMinigame) == 0x6d8, "Offset mismatch for UFNE_VolumeOverlapComponent::CachedMinigame");
static_assert(offsetof(UFNE_VolumeOverlapComponent, TrackedActors) == 0x6e0, "Offset mismatch for UFNE_VolumeOverlapComponent::TrackedActors");

