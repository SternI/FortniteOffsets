/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Gameplay
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayAbilities.h"
#include "Athena.h"
#include "FortniteGame.h"
#include "RidingCodeRuntime.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_Creatue_IsBeingRidden_Passive_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_Creatue_IsBeingRidden_Passive_C) == 0xa68, "Size mismatch for UGE_Riding_Creatue_IsBeingRidden_Passive_C");

// Size: 0xed0 (Inherited: 0x1dd0, Single: 0xfffff100)
class UGA_Riding_Creature_IsBeingRidden_Passive_C : public UGA_NPC_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xec8 (Size: 0x8, Type: StructProperty)

public:
    virtual void FailedToActivatePassiveAbility(FGameplayAbilityActorInfo& ActorInfo); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGA_Riding_Creature_IsBeingRidden_Passive_C) == 0xed0, "Size mismatch for UGA_Riding_Creature_IsBeingRidden_Passive_C");
static_assert(offsetof(UGA_Riding_Creature_IsBeingRidden_Passive_C, UberGraphFrame) == 0xec8, "Offset mismatch for UGA_Riding_Creature_IsBeingRidden_Passive_C::UberGraphFrame");

// Size: 0xb40 (Inherited: 0xf08, Single: 0xfffffc38)
class UGA_Riding_Creature_Burt_SprintCharge_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)

public:
    virtual void FailedToActivatePassiveAbility(FGameplayAbilityActorInfo& ActorInfo); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGA_Riding_Creature_Burt_SprintCharge_C) == 0xb40, "Size mismatch for UGA_Riding_Creature_Burt_SprintCharge_C");
static_assert(offsetof(UGA_Riding_Creature_Burt_SprintCharge_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGA_Riding_Creature_Burt_SprintCharge_C::UberGraphFrame");

// Size: 0x2040 (Inherited: 0x40e8, Single: 0xffffdf58)
class URidingCameraMode_C : public UFortCameraMode_Riding
{
public:
};

static_assert(sizeof(URidingCameraMode_C) == 0x2040, "Size mismatch for URidingCameraMode_C");

// Size: 0xb68 (Inherited: 0xf08, Single: 0xfffffc60)
class UGA_Riding_Player_Petting_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    URidableComponent* Active_Ridable; // 0xb40 (Size: 0x8, Type: ObjectProperty)
    UClass* GE_PlayerPetting; // 0xb48 (Size: 0x8, Type: ClassProperty)
    TArray<FGameplayTag> TagsToCancelPetting; // 0xb50 (Size: 0x10, Type: ArrayProperty)
    AFortPlayerPawn* FortPlayerPawnRider; // 0xb60 (Size: 0x8, Type: ObjectProperty)

public:
    void PettingTelemetry(AActor*& Owner); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetRiderPettingMontage(UAnimMontage*& RiderPettingMontage); // 0x288a61c (Index: 0x7, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual void FailedToActivatePassiveAbility(FGameplayAbilityActorInfo& ActorInfo); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGA_Riding_Player_Petting_C) == 0xb68, "Size mismatch for UGA_Riding_Player_Petting_C");
static_assert(offsetof(UGA_Riding_Player_Petting_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGA_Riding_Player_Petting_C::UberGraphFrame");
static_assert(offsetof(UGA_Riding_Player_Petting_C, Active_Ridable) == 0xb40, "Offset mismatch for UGA_Riding_Player_Petting_C::Active_Ridable");
static_assert(offsetof(UGA_Riding_Player_Petting_C, GE_PlayerPetting) == 0xb48, "Offset mismatch for UGA_Riding_Player_Petting_C::GE_PlayerPetting");
static_assert(offsetof(UGA_Riding_Player_Petting_C, TagsToCancelPetting) == 0xb50, "Offset mismatch for UGA_Riding_Player_Petting_C::TagsToCancelPetting");
static_assert(offsetof(UGA_Riding_Player_Petting_C, FortPlayerPawnRider) == 0xb60, "Offset mismatch for UGA_Riding_Player_Petting_C::FortPlayerPawnRider");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_Player_Petting_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_Player_Petting_C) == 0xa68, "Size mismatch for UGE_Riding_Player_Petting_C");

// Size: 0xb40 (Inherited: 0xf08, Single: 0xfffffc38)
class UGA_Riding_Player_StopRidingOnTriggered_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)

protected:
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGA_Riding_Player_StopRidingOnTriggered_C) == 0xb40, "Size mismatch for UGA_Riding_Player_StopRidingOnTriggered_C");
static_assert(offsetof(UGA_Riding_Player_StopRidingOnTriggered_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGA_Riding_Player_StopRidingOnTriggered_C::UberGraphFrame");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_EatSlapBerry_TriggerInfiniteStamina_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_EatSlapBerry_TriggerInfiniteStamina_C) == 0xa68, "Size mismatch for UGE_Riding_EatSlapBerry_TriggerInfiniteStamina_C");

// Size: 0x2040 (Inherited: 0x40e8, Single: 0xffffdf58)
class URiding_PlayerCameraMode_TacticalSprint_C : public UFortCameraMode_Riding
{
public:
};

static_assert(sizeof(URiding_PlayerCameraMode_TacticalSprint_C) == 0x2040, "Size mismatch for URiding_PlayerCameraMode_TacticalSprint_C");

// Size: 0xa68 (Inherited: 0x14f8, Single: 0xfffff570)
class UGE_Riding_Irwin_Prey_Burt_IsBeingRidden_C : public UGE_Riding_Creatue_IsBeingRidden_C
{
public:
};

static_assert(sizeof(UGE_Riding_Irwin_Prey_Burt_IsBeingRidden_C) == 0xa68, "Size mismatch for UGE_Riding_Irwin_Prey_Burt_IsBeingRidden_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_Creatue_IsBeingRidden_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_Creatue_IsBeingRidden_C) == 0xa68, "Size mismatch for UGE_Riding_Creatue_IsBeingRidden_C");

// Size: 0xed0 (Inherited: 0x1dd0, Single: 0xfffff100)
class UGA_Riding_Creature_IsBeingRidden_C : public UGA_NPC_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xec8 (Size: 0x8, Type: StructProperty)

public:
    virtual void FailedToActivatePassiveAbility(FGameplayAbilityActorInfo& ActorInfo); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGA_Riding_Creature_IsBeingRidden_C) == 0xed0, "Size mismatch for UGA_Riding_Creature_IsBeingRidden_C");
static_assert(offsetof(UGA_Riding_Creature_IsBeingRidden_C, UberGraphFrame) == 0xec8, "Offset mismatch for UGA_Riding_Creature_IsBeingRidden_C::UberGraphFrame");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_Player_IsRiding_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_Player_IsRiding_C) == 0xa68, "Size mismatch for UGE_Riding_Player_IsRiding_C");

// Size: 0xb50 (Inherited: 0xf08, Single: 0xfffffc48)
class UGA_Riding_Player_IsRiding_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    UAnimMontage* SettleMontageRef; // 0xb40 (Size: 0x8, Type: ObjectProperty)
    UFortAbilityTask_PlayMontageWaitTarget* settleMontageTask; // 0xb48 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void FailedToActivatePassiveAbility(FGameplayAbilityActorInfo& ActorInfo); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGA_Riding_Player_IsRiding_C) == 0xb50, "Size mismatch for UGA_Riding_Player_IsRiding_C");
static_assert(offsetof(UGA_Riding_Player_IsRiding_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGA_Riding_Player_IsRiding_C::UberGraphFrame");
static_assert(offsetof(UGA_Riding_Player_IsRiding_C, SettleMontageRef) == 0xb40, "Offset mismatch for UGA_Riding_Player_IsRiding_C::SettleMontageRef");
static_assert(offsetof(UGA_Riding_Player_IsRiding_C, settleMontageTask) == 0xb48, "Offset mismatch for UGA_Riding_Player_IsRiding_C::settleMontageTask");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_Player_Sprint_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_Player_Sprint_C) == 0xa68, "Size mismatch for UGE_Riding_Player_Sprint_C");

// Size: 0xb51 (Inherited: 0xf08, Single: 0xfffffc49)
class UGA_Riding_Player_Sprint_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    TArray<FGameplayTag> Tags_to_cancel_sprinting; // 0xb40 (Size: 0x10, Type: ArrayProperty)
    bool ShouldCancelSprint; // 0xb50 (Size: 0x1, Type: BoolProperty)

public:
    virtual void FailedToActivatePassiveAbility(FGameplayAbilityActorInfo& ActorInfo); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGA_Riding_Player_Sprint_C) == 0xb51, "Size mismatch for UGA_Riding_Player_Sprint_C");
static_assert(offsetof(UGA_Riding_Player_Sprint_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGA_Riding_Player_Sprint_C::UberGraphFrame");
static_assert(offsetof(UGA_Riding_Player_Sprint_C, Tags_to_cancel_sprinting) == 0xb40, "Offset mismatch for UGA_Riding_Player_Sprint_C::Tags_to_cancel_sprinting");
static_assert(offsetof(UGA_Riding_Player_Sprint_C, ShouldCancelSprint) == 0xb50, "Offset mismatch for UGA_Riding_Player_Sprint_C::ShouldCancelSprint");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_Creature_Grant_EatToRefuel_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_Creature_Grant_EatToRefuel_C) == 0xa68, "Size mismatch for UGE_Riding_Creature_Grant_EatToRefuel_C");

// Size: 0xb68 (Inherited: 0xf08, Single: 0xfffffc60)
class UGA_Riding_Creature_EatToRefuel_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer Slap_Berry_Tags; // 0xb40 (Size: 0x20, Type: StructProperty)
    UClass* Slap_Berry_Gameplay_Effect; // 0xb60 (Size: 0x8, Type: ClassProperty)

protected:
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGA_Riding_Creature_EatToRefuel_C) == 0xb68, "Size mismatch for UGA_Riding_Creature_EatToRefuel_C");
static_assert(offsetof(UGA_Riding_Creature_EatToRefuel_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGA_Riding_Creature_EatToRefuel_C::UberGraphFrame");
static_assert(offsetof(UGA_Riding_Creature_EatToRefuel_C, Slap_Berry_Tags) == 0xb40, "Offset mismatch for UGA_Riding_Creature_EatToRefuel_C::Slap_Berry_Tags");
static_assert(offsetof(UGA_Riding_Creature_EatToRefuel_C, Slap_Berry_Gameplay_Effect) == 0xb60, "Offset mismatch for UGA_Riding_Creature_EatToRefuel_C::Slap_Berry_Gameplay_Effect");

