/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayBehaviorsModule
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "AIModule.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "GameplayTasks.h"

// Size: 0xc0 (Inherited: 0x188, Single: 0xffffff38)
class UBTTask_SetKeyValueGameplayTag : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_GameplayTagContainer Value; // 0x98 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UBTTask_SetKeyValueGameplayTag) == 0xc0, "Size mismatch for UBTTask_SetKeyValueGameplayTag");
static_assert(offsetof(UBTTask_SetKeyValueGameplayTag, Value) == 0x98, "Offset mismatch for UBTTask_SetKeyValueGameplayTag::Value");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UValueOrBBKey_GameplayTagBlueprintUtility : public UBlueprintFunctionLibrary
{
public:

public:
    static FGameplayTagContainer GetTagContainer(const FValueOrBBKey_GameplayTagContainer Value, UBehaviorTreeComponent*& const BehaviorTreeComp); // 0xc9a726c (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UValueOrBBKey_GameplayTagBlueprintUtility) == 0x28, "Size mismatch for UValueOrBBKey_GameplayTagBlueprintUtility");

// Size: 0xe8 (Inherited: 0x148, Single: 0xffffffa0)
class UBTDecorator_GameplayTagQuery : public UBTDecorator
{
public:
    FBlackboardKeySelector ActorForGameplayTagQuery; // 0x68 (Size: 0x28, Type: StructProperty)
    FGameplayTagQuery GameplayTagQuery; // 0x90 (Size: 0x48, Type: StructProperty)
    TArray<FGameplayTag> QueryTags; // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UBTDecorator_GameplayTagQuery) == 0xe8, "Size mismatch for UBTDecorator_GameplayTagQuery");
static_assert(offsetof(UBTDecorator_GameplayTagQuery, ActorForGameplayTagQuery) == 0x68, "Offset mismatch for UBTDecorator_GameplayTagQuery::ActorForGameplayTagQuery");
static_assert(offsetof(UBTDecorator_GameplayTagQuery, GameplayTagQuery) == 0x90, "Offset mismatch for UBTDecorator_GameplayTagQuery::GameplayTagQuery");
static_assert(offsetof(UBTDecorator_GameplayTagQuery, QueryTags) == 0xd8, "Offset mismatch for UBTDecorator_GameplayTagQuery::QueryTags");

// Size: 0x78 (Inherited: 0xf0, Single: 0xffffff88)
class UBTTask_StopGameplayBehavior : public UBTTaskNode
{
public:
    UClass* BehaviorToStop; // 0x70 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UBTTask_StopGameplayBehavior) == 0x78, "Size mismatch for UBTTask_StopGameplayBehavior");
static_assert(offsetof(UBTTask_StopGameplayBehavior, BehaviorToStop) == 0x70, "Offset mismatch for UBTTask_StopGameplayBehavior::BehaviorToStop");

// Size: 0x58 (Inherited: 0x58, Single: 0x0)
class UGameplayBehaviorConfig_BehaviorTree : public UGameplayBehaviorConfig
{
public:
    TSoftObjectPtr<UBehaviorTree*> BehaviorTree; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t bRevertToPreviousBTOnFinish : 1; // 0x50:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UGameplayBehaviorConfig_BehaviorTree) == 0x58, "Size mismatch for UGameplayBehaviorConfig_BehaviorTree");
static_assert(offsetof(UGameplayBehaviorConfig_BehaviorTree, BehaviorTree) == 0x30, "Offset mismatch for UGameplayBehaviorConfig_BehaviorTree::BehaviorTree");
static_assert(offsetof(UGameplayBehaviorConfig_BehaviorTree, bRevertToPreviousBTOnFinish) == 0x50, "Offset mismatch for UGameplayBehaviorConfig_BehaviorTree::bRevertToPreviousBTOnFinish");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UGameplayBehaviorConfig : public UObject
{
public:
    UClass* BehaviorClass; // 0x28 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UGameplayBehaviorConfig) == 0x30, "Size mismatch for UGameplayBehaviorConfig");
static_assert(offsetof(UGameplayBehaviorConfig, BehaviorClass) == 0x28, "Offset mismatch for UGameplayBehaviorConfig::BehaviorClass");

// Size: 0xa8 (Inherited: 0xb0, Single: 0xfffffff8)
class UGameplayBehavior_BehaviorTree : public UGameplayBehavior
{
public:
    UBehaviorTree* PreviousBT; // 0x88 (Size: 0x8, Type: ObjectProperty)
    AAIController* AIController; // 0x90 (Size: 0x8, Type: ObjectProperty)
    bool bSingleRun; // 0x98 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0xf]; // 0x99 (Size: 0xf, Type: PaddingProperty)

protected:
    void OnPossessedPawnChanged(APawn*& OldPawn, APawn*& NewPawn); // 0xc9a7dc0 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UGameplayBehavior_BehaviorTree) == 0xa8, "Size mismatch for UGameplayBehavior_BehaviorTree");
static_assert(offsetof(UGameplayBehavior_BehaviorTree, PreviousBT) == 0x88, "Offset mismatch for UGameplayBehavior_BehaviorTree::PreviousBT");
static_assert(offsetof(UGameplayBehavior_BehaviorTree, AIController) == 0x90, "Offset mismatch for UGameplayBehavior_BehaviorTree::AIController");
static_assert(offsetof(UGameplayBehavior_BehaviorTree, bSingleRun) == 0x98, "Offset mismatch for UGameplayBehavior_BehaviorTree::bSingleRun");

// Size: 0x88 (Inherited: 0x28, Single: 0x60)
class UGameplayBehavior : public UObject
{
public:
    uint8_t Pad_28[0x14]; // 0x28 (Size: 0x14, Type: PaddingProperty)
    FGameplayTag ActionTag; // 0x3c (Size: 0x4, Type: StructProperty)
    uint8_t Pad_40[0x18]; // 0x40 (Size: 0x18, Type: PaddingProperty)
    TArray<AActor*> RelevantActors; // 0x58 (Size: 0x10, Type: ArrayProperty)
    AActor* TransientSmartObjectOwner; // 0x68 (Size: 0x8, Type: ObjectProperty)
    AActor* TransientAvatar; // 0x70 (Size: 0x8, Type: ObjectProperty)
    TArray<UGameplayTask*> ActiveTasks; // 0x78 (Size: 0x10, Type: ArrayProperty)

public:
    void K2_AbortBehavior(AActor*& Avatar); // 0xc9a7458 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void K2_EndBehavior(AActor*& Avatar); // 0xc9a7580 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    int32_t K2_GetNextActorIndexInSequence(int32_t& CurrentIndex) const; // 0xc9a76a8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void K2_OnFinished(AActor*& Avatar, bool& bWasInterrupted); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void K2_OnFinishedCharacter(ACharacter*& Avatar, bool& bWasInterrupted); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    virtual void K2_OnFinishedPawn(APawn*& Avatar, bool& bWasInterrupted); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
    virtual void K2_OnTriggered(AActor*& Avatar, UGameplayBehaviorConfig*& const Config, AActor*& SmartObjectOwner); // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintEvent)
    virtual void K2_OnTriggeredCharacter(ACharacter*& Avatar, UGameplayBehaviorConfig*& const Config, AActor*& SmartObjectOwner); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintEvent)
    virtual void K2_OnTriggeredPawn(APawn*& Avatar, UGameplayBehaviorConfig*& const Config, AActor*& SmartObjectOwner); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)
    void K2_TriggerBehavior(AActor*& Avatar, UGameplayBehaviorConfig*& Config, AActor*& SmartObjectOwner); // 0xc9a77fc (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UGameplayBehavior) == 0x88, "Size mismatch for UGameplayBehavior");
static_assert(offsetof(UGameplayBehavior, ActionTag) == 0x3c, "Offset mismatch for UGameplayBehavior::ActionTag");
static_assert(offsetof(UGameplayBehavior, RelevantActors) == 0x58, "Offset mismatch for UGameplayBehavior::RelevantActors");
static_assert(offsetof(UGameplayBehavior, TransientSmartObjectOwner) == 0x68, "Offset mismatch for UGameplayBehavior::TransientSmartObjectOwner");
static_assert(offsetof(UGameplayBehavior, TransientAvatar) == 0x70, "Offset mismatch for UGameplayBehavior::TransientAvatar");
static_assert(offsetof(UGameplayBehavior, ActiveTasks) == 0x78, "Offset mismatch for UGameplayBehavior::ActiveTasks");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UBlackboardKeyType_GameplayTag : public UBlackboardKeyType
{
public:
    FGameplayTagContainer DefaultValue; // 0x30 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UBlackboardKeyType_GameplayTag) == 0x50, "Size mismatch for UBlackboardKeyType_GameplayTag");
static_assert(offsetof(UBlackboardKeyType_GameplayTag, DefaultValue) == 0x30, "Offset mismatch for UBlackboardKeyType_GameplayTag::DefaultValue");

// Size: 0x60 (Inherited: 0x58, Single: 0x8)
class UGameplayBehaviorConfig_Animation : public UGameplayBehaviorConfig
{
public:
    TSoftObjectPtr<UAnimMontage*> AnimMontage; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    float PlayRate; // 0x50 (Size: 0x4, Type: FloatProperty)
    FName StartSectionName; // 0x54 (Size: 0x4, Type: NameProperty)
    uint8_t bLoop : 1; // 0x58:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UGameplayBehaviorConfig_Animation) == 0x60, "Size mismatch for UGameplayBehaviorConfig_Animation");
static_assert(offsetof(UGameplayBehaviorConfig_Animation, AnimMontage) == 0x30, "Offset mismatch for UGameplayBehaviorConfig_Animation::AnimMontage");
static_assert(offsetof(UGameplayBehaviorConfig_Animation, PlayRate) == 0x50, "Offset mismatch for UGameplayBehaviorConfig_Animation::PlayRate");
static_assert(offsetof(UGameplayBehaviorConfig_Animation, StartSectionName) == 0x54, "Offset mismatch for UGameplayBehaviorConfig_Animation::StartSectionName");
static_assert(offsetof(UGameplayBehaviorConfig_Animation, bLoop) == 0x58, "Offset mismatch for UGameplayBehaviorConfig_Animation::bLoop");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameplayBehaviorsBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void AddGameplayTagFilterToBlackboardKeySelector(FBlackboardKeySelector& InSelector, UObject*& Owner, FName& PropertyName); // 0xc9a696c (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGameplayTagContainer GetBlackboardValueAsGameplayTag(UBTNode*& NodeOwner, const FBlackboardKeySelector Key); // 0xc9a6cd8 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayTagContainer GetBlackboardValueAsGameplayTagFromBlackboardComp(UBlackboardComponent*& BlackboardComp, const FName KeyName); // 0xc9a7080 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetBlackboardValueAsGameplayTag(UBTNode*& NodeOwner, const FBlackboardKeySelector Key, FGameplayTagContainer& Value); // 0xc9a7fd4 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetValueAsGameplayTagForBlackboardComp(UBlackboardComponent*& BlackboardComp, const FName KeyName, FGameplayTagContainer& GameplayTagValue); // 0xc9a84a8 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGameplayBehaviorsBlueprintFunctionLibrary) == 0x28, "Size mismatch for UGameplayBehaviorsBlueprintFunctionLibrary");

// Size: 0x80 (Inherited: 0x88, Single: 0xfffffff8)
class UGameplayBehaviorSubsystem : public UWorldSubsystem
{
public:
    TMap<FAgentGameplayBehaviors, AActor*> AgentGameplayBehaviors; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UGameplayBehaviorSubsystem) == 0x80, "Size mismatch for UGameplayBehaviorSubsystem");
static_assert(offsetof(UGameplayBehaviorSubsystem, AgentGameplayBehaviors) == 0x30, "Offset mismatch for UGameplayBehaviorSubsystem::AgentGameplayBehaviors");

// Size: 0x98 (Inherited: 0xb0, Single: 0xffffffe8)
class UGameplayBehavior_AnimationBased : public UGameplayBehavior
{
public:
    TArray<FMontagePlaybackData> ActivePlayback; // 0x88 (Size: 0x10, Type: ArrayProperty)

protected:
    void OnMontageFinished(UAnimMontage*& Montage, bool& bInterrupted, AActor*& InAvatar); // 0xc9a7ad8 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UGameplayBehavior_AnimationBased) == 0x98, "Size mismatch for UGameplayBehavior_AnimationBased");
static_assert(offsetof(UGameplayBehavior_AnimationBased, ActivePlayback) == 0x88, "Offset mismatch for UGameplayBehavior_AnimationBased::ActivePlayback");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FValueOrBBKey_GameplayTagContainer : FValueOrBlackboardKeyBase
{
    FGameplayTagContainer DefaultValue; // 0x8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FValueOrBBKey_GameplayTagContainer) == 0x28, "Size mismatch for FValueOrBBKey_GameplayTagContainer");
static_assert(offsetof(FValueOrBBKey_GameplayTagContainer, DefaultValue) == 0x8, "Offset mismatch for FValueOrBBKey_GameplayTagContainer::DefaultValue");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAgentGameplayBehaviors
{
    TArray<UGameplayBehavior*> Behaviors; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAgentGameplayBehaviors) == 0x10, "Size mismatch for FAgentGameplayBehaviors");
static_assert(offsetof(FAgentGameplayBehaviors, Behaviors) == 0x0, "Offset mismatch for FAgentGameplayBehaviors::Behaviors");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FMontagePlaybackData
{
    AActor* Avatar; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* AnimMontage; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UAbilitySystemComponent* AbilityComponent; // 0x10 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_18[0x28]; // 0x18 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(FMontagePlaybackData) == 0x40, "Size mismatch for FMontagePlaybackData");
static_assert(offsetof(FMontagePlaybackData, Avatar) == 0x0, "Offset mismatch for FMontagePlaybackData::Avatar");
static_assert(offsetof(FMontagePlaybackData, AnimMontage) == 0x8, "Offset mismatch for FMontagePlaybackData::AnimMontage");
static_assert(offsetof(FMontagePlaybackData, AbilityComponent) == 0x10, "Offset mismatch for FMontagePlaybackData::AbilityComponent");

