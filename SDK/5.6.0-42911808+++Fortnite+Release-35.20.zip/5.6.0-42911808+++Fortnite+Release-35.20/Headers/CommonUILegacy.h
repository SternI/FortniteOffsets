/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommonUILegacy
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CommonUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x540 (Inherited: 0xb38, Single: 0xfffffa08)
class UCommonActivatablePanelLegacy : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x8]; // 0x408 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnWidgetActivated[0x10]; // 0x410 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnWidgetDeactivated[0x10]; // 0x420 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bConsumeAllActions; // 0x430 (Size: 0x1, Type: BoolProperty)
    bool bExposeActionsExternally; // 0x431 (Size: 0x1, Type: BoolProperty)
    bool bShouldBypassStack; // 0x432 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_433[0x10d]; // 0x433 (Size: 0x10d, Type: PaddingProperty)

public:
    void AddInputActionHandler(UDataTable*& DataTable, FName& RowName, FDelegate& CommitedEvent); // 0xc015300 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void AddInputActionHandlerWithPopup(UDataTable*& DataTable, FName& RowName, FDelegate& CommitedEvent, UCommonPopupMenuLegacy*& PopupMenu); // 0xc0155f8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void AddInputActionHandlerWithProgress(UDataTable*& DataTable, FName& RowName, FDelegate& CommitedEvent, FDelegate& ProgressEvent); // 0xc015d1c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void AddInputActionHandlerWithProgressPopup(UDataTable*& DataTable, FName& RowName, FDelegate& CommitedEvent, FDelegate& ProgressEvent, UCommonPopupMenuLegacy*& PopupMenu); // 0xc0160bc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void AddInputActionNoHandler(UDataTable*& DataTable, FName& RowName); // 0xc016858 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void BeginIntro(); // 0xc016a90 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void BeginOutro(); // 0xc016aa4 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    bool GetInputActions(TArray<FCommonInputActionHandlerData>& InputActionDataRows) const; // 0xc0170f4 (Index: 0x9, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool HasInputActionHandler(FDataTableRowHandle& InputActionRow) const; // 0xc019054 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsInActivationStack() const; // 0xc0192ec (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsIntroed() const; // 0xc019330 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void PopPanel(); // 0xc019b98 (Index: 0x13, Flags: Native|Public|BlueprintCallable)
    void RemoveAllInputActionHandlers(); // 0xc019ff4 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveInputActionHandler(FDataTableRowHandle& InputActionRow); // 0xc01a008 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    void SetActionHandlerState(UDataTable*& const DataTable, FName& RowName, EInputActionState& State); // 0xc01a2c0 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void SetActionHandlerStateFromHandle(FDataTableRowHandle& InputActionRow, EInputActionState& State); // 0xc01a8d0 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void SetActionHandlerStateFromHandleWithDisabledCommitEvent(FDataTableRowHandle& InputActionRow, EInputActionState& State, FDelegate& DisabledCommitEvent); // 0xc01abcc (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void SetActionHandlerStateWithDisabledCommitEvent(UDataTable*& DataTable, FName& RowName, EInputActionState& State, FDelegate& DisabledCommitEvent); // 0xc01af40 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    void SetInputActionHandler(FDataTableRowHandle& InputActionRow, FDelegate& CommitedEvent); // 0xc01bcd4 (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)
    void SetInputActionHandlerWithPopupMenu(FDataTableRowHandle& InputActionRow, FDelegate& CommitedEvent, UCommonPopupMenuLegacy*& PopupMenu); // 0xc01bfe0 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable)
    void SetInputActionHandlerWithProgress(FDataTableRowHandle& InputActionRow, FDelegate& CommitedEvent, FDelegate& ProgressEvent); // 0xc01c358 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable)
    void SetInputActionHandlerWithProgressPopupMenu(FDataTableRowHandle& InputActionRow, FDelegate& CommitedEvent, FDelegate& ProgressEvent, UCommonPopupMenuLegacy*& PopupMenu); // 0xc01c6e4 (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void EndIntro(); // 0xc016ce4 (Index: 0x7, Flags: Final|Native|Protected|BlueprintCallable)
    void EndOutro(); // 0xc016cf8 (Index: 0x8, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnAddedToActivationStack(); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void OnBeginIntro(); // 0xb4a85b4 (Index: 0xe, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void OnBeginOutro(); // 0xc0194b8 (Index: 0xf, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void OnInputModeChanged(bool& bUsingGamepad); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRemovedFromActivationStack(); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionedBySwitcher(); // 0x288a61c (Index: 0x12, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCommonActivatablePanelLegacy) == 0x540, "Size mismatch for UCommonActivatablePanelLegacy");
static_assert(offsetof(UCommonActivatablePanelLegacy, OnWidgetActivated) == 0x410, "Offset mismatch for UCommonActivatablePanelLegacy::OnWidgetActivated");
static_assert(offsetof(UCommonActivatablePanelLegacy, OnWidgetDeactivated) == 0x420, "Offset mismatch for UCommonActivatablePanelLegacy::OnWidgetDeactivated");
static_assert(offsetof(UCommonActivatablePanelLegacy, bConsumeAllActions) == 0x430, "Offset mismatch for UCommonActivatablePanelLegacy::bConsumeAllActions");
static_assert(offsetof(UCommonActivatablePanelLegacy, bExposeActionsExternally) == 0x431, "Offset mismatch for UCommonActivatablePanelLegacy::bExposeActionsExternally");
static_assert(offsetof(UCommonActivatablePanelLegacy, bShouldBypassStack) == 0x432, "Offset mismatch for UCommonActivatablePanelLegacy::bShouldBypassStack");

// Size: 0x600 (Inherited: 0x1018, Single: 0xfffff5e8)
class UCommonButtonInternalLegacy : public UCommonButtonInternalBase
{
public:
};

static_assert(sizeof(UCommonButtonInternalLegacy) == 0x600, "Size mismatch for UCommonButtonInternalLegacy");

// Size: 0x14f0 (Inherited: 0x1bd0, Single: 0xfffff920)
class UCommonButtonLegacy : public UCommonButtonBase
{
public:
    uint8_t OnSelectedChanged[0x10]; // 0x14a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonClicked[0x10]; // 0x14b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonDoubleClicked[0x10]; // 0x14c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonHovered[0x10]; // 0x14d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnButtonUnhovered[0x10]; // 0x14e0 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void SetTriggeredInputActionLegacy(const FDataTableRowHandle InputActionRow, UCommonActivatablePanelLegacy*& OldPanel); // 0xc01cc08 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

private:
    void HandleOnButtonClicked(UCommonButtonBase*& Button); // 0xc017f3c (Index: 0x0, Flags: Final|Native|Private)
    void HandleOnButtonDoubleClicked(UCommonButtonBase*& Button); // 0xc018270 (Index: 0x1, Flags: Final|Native|Private)
    void HandleOnButtonHovered(UCommonButtonBase*& Button); // 0xc01839c (Index: 0x2, Flags: Final|Native|Private)
    void HandleOnButtonUnhovered(UCommonButtonBase*& Button); // 0xc0184c8 (Index: 0x3, Flags: Final|Native|Private)
    void HandleOnSelectedChanged(UCommonButtonBase*& Button, bool& InSelected); // 0x448f4c0 (Index: 0x4, Flags: Final|Native|Private)
};

static_assert(sizeof(UCommonButtonLegacy) == 0x14f0, "Size mismatch for UCommonButtonLegacy");
static_assert(offsetof(UCommonButtonLegacy, OnSelectedChanged) == 0x14a0, "Offset mismatch for UCommonButtonLegacy::OnSelectedChanged");
static_assert(offsetof(UCommonButtonLegacy, OnButtonClicked) == 0x14b0, "Offset mismatch for UCommonButtonLegacy::OnButtonClicked");
static_assert(offsetof(UCommonButtonLegacy, OnButtonDoubleClicked) == 0x14c0, "Offset mismatch for UCommonButtonLegacy::OnButtonDoubleClicked");
static_assert(offsetof(UCommonButtonLegacy, OnButtonHovered) == 0x14d0, "Offset mismatch for UCommonButtonLegacy::OnButtonHovered");
static_assert(offsetof(UCommonButtonLegacy, OnButtonUnhovered) == 0x14e0, "Offset mismatch for UCommonButtonLegacy::OnButtonUnhovered");

// Size: 0x70 (Inherited: 0x28, Single: 0x48)
class UCommonGlobalInputHandlerLegacy : public UObject
{
public:
};

static_assert(sizeof(UCommonGlobalInputHandlerLegacy) == 0x70, "Size mismatch for UCommonGlobalInputHandlerLegacy");

// Size: 0x108 (Inherited: 0x28, Single: 0xe0)
class UCommonInputManagerLegacy : public UObject
{
public:
    uint8_t Pad_28[0x80]; // 0x28 (Size: 0x80, Type: PaddingProperty)
    TScriptInterface<Class> CurrentlyHeldActionInputHandler; // 0xa8 (Size: 0x10, Type: InterfaceProperty)
    TArray<UCommonActivatablePanelLegacy*> ActivatablePanelStack; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    UCommonGlobalInputHandlerLegacy* GlobalInputHandler; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d0[0x18]; // 0xd0 (Size: 0x18, Type: PaddingProperty)
    TArray<FOperation> Operations; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_f8[0x10]; // 0xf8 (Size: 0x10, Type: PaddingProperty)

public:
    bool GetAvailableInputActions(TArray<FCommonInputActionHandlerData>& AvailableInputActions); // 0xc016d0c (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    int32_t GetGlobalInputHandlerPriorityFilter() const; // 0xc0170d4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCommonActivatablePanelLegacy* GetTopPanel() const; // 0xc0173c0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsInputSuspended() const; // 0xc019304 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPanelOnStack(UCommonActivatablePanelLegacy*& const InPanel) const; // 0xc019348 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void PopActivatablePanel(UCommonActivatablePanelLegacy*& ActivatablePanel); // 0xc019a6c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void PushActivatablePanel(UCommonActivatablePanelLegacy*& ActivatablePanel, bool& bIntroPanel, bool& bOutroPanelBelow); // 0xc019bd4 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void ResumeStartingOperationProcessing(); // 0xc01a2a4 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void SetGlobalInputHandlerPriorityFilter(int32_t& InFilterPriority); // 0xc01bbb0 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    bool StartListeningForExistingHeldAction(const FDataTableRowHandle InputActionDataRow, const FDelegate CompleteEvent, const FDelegate ProgressEvent); // 0xc01cd60 (Index: 0x9, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool StopListeningForExistingHeldAction(const FDataTableRowHandle InputActionDataRow, const FDelegate CompleteEvent, const FDelegate ProgressEvent); // 0xc01cf90 (Index: 0xa, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SuspendStartingOperationProcessing(); // 0xc01d1c0 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCommonInputManagerLegacy) == 0x108, "Size mismatch for UCommonInputManagerLegacy");
static_assert(offsetof(UCommonInputManagerLegacy, CurrentlyHeldActionInputHandler) == 0xa8, "Offset mismatch for UCommonInputManagerLegacy::CurrentlyHeldActionInputHandler");
static_assert(offsetof(UCommonInputManagerLegacy, ActivatablePanelStack) == 0xb8, "Offset mismatch for UCommonInputManagerLegacy::ActivatablePanelStack");
static_assert(offsetof(UCommonInputManagerLegacy, GlobalInputHandler) == 0xc8, "Offset mismatch for UCommonInputManagerLegacy::GlobalInputHandler");
static_assert(offsetof(UCommonInputManagerLegacy, Operations) == 0xe8, "Offset mismatch for UCommonInputManagerLegacy::Operations");

// Size: 0x308 (Inherited: 0x730, Single: 0xfffffbd8)
class UCommonInputReflectorLegacy : public UCommonUserWidget
{
public:
    UClass* ButtonType; // 0x2d8 (Size: 0x8, Type: ClassProperty)
    TArray<UCommonButtonLegacy*> ActiveButtons; // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    TArray<UCommonButtonLegacy*> InactiveButtons; // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_300[0x8]; // 0x300 (Size: 0x8, Type: PaddingProperty)

public:
    virtual void OnButtonAdded(UCommonButtonLegacy*& AddedButton, const FCommonInputActionHandlerData Data); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UCommonInputReflectorLegacy) == 0x308, "Size mismatch for UCommonInputReflectorLegacy");
static_assert(offsetof(UCommonInputReflectorLegacy, ButtonType) == 0x2d8, "Offset mismatch for UCommonInputReflectorLegacy::ButtonType");
static_assert(offsetof(UCommonInputReflectorLegacy, ActiveButtons) == 0x2e0, "Offset mismatch for UCommonInputReflectorLegacy::ActiveButtons");
static_assert(offsetof(UCommonInputReflectorLegacy, InactiveButtons) == 0x2f0, "Offset mismatch for UCommonInputReflectorLegacy::InactiveButtons");

// Size: 0x1500 (Inherited: 0x30c0, Single: 0xffffe440)
class UCommonPopupButtonLegacy : public UCommonButtonLegacy
{
public:
    UMenuAnchor* PopupMenuAnchor; // 0x14f0 (Size: 0x8, Type: ObjectProperty)
    UCommonPopupMenuLegacy* PopupMenu; // 0x14f8 (Size: 0x8, Type: ObjectProperty)

private:
    UUserWidget* GetMenuAnchorWidget(); // 0xc017384 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UCommonPopupButtonLegacy) == 0x1500, "Size mismatch for UCommonPopupButtonLegacy");
static_assert(offsetof(UCommonPopupButtonLegacy, PopupMenuAnchor) == 0x14f0, "Offset mismatch for UCommonPopupButtonLegacy::PopupMenuAnchor");
static_assert(offsetof(UCommonPopupButtonLegacy, PopupMenu) == 0x14f8, "Offset mismatch for UCommonPopupButtonLegacy::PopupMenu");

// Size: 0x558 (Inherited: 0x1078, Single: 0xfffff4e0)
class UCommonPopupMenuLegacy : public UCommonActivatablePanelLegacy
{
public:
    bool bUseInputStack; // 0x540 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_541[0x3]; // 0x541 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<UMenuAnchor*> OwningMenuAnchor; // 0x544 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UObject*> ContextProvidingObject; // 0x54c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_554[0x4]; // 0x554 (Size: 0x4, Type: PaddingProperty)

public:
    void SetContextProvider(UObject*& const ContextProvidingObject); // 0xc01ba84 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SetOwningMenuAnchor(UMenuAnchor*& const MenuAnchor); // 0xc01cadc (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void HandlePostDifferentContextProviderSet(); // 0xc018c0c (Index: 0x0, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void HandlePreDifferentContextProviderSet(); // 0xc018c24 (Index: 0x1, Flags: Native|Event|Protected|BlueprintEvent)
    void OnIsOpenChanged(bool& IsOpen); // 0xc019730 (Index: 0x2, Flags: Final|Native|Protected)
    void RequestClose(); // 0xc01a290 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UCommonPopupMenuLegacy) == 0x558, "Size mismatch for UCommonPopupMenuLegacy");
static_assert(offsetof(UCommonPopupMenuLegacy, bUseInputStack) == 0x540, "Offset mismatch for UCommonPopupMenuLegacy::bUseInputStack");
static_assert(offsetof(UCommonPopupMenuLegacy, OwningMenuAnchor) == 0x544, "Offset mismatch for UCommonPopupMenuLegacy::OwningMenuAnchor");
static_assert(offsetof(UCommonPopupMenuLegacy, ContextProvidingObject) == 0x54c, "Offset mismatch for UCommonPopupMenuLegacy::ContextProvidingObject");

// Size: 0x470 (Inherited: 0xb80, Single: 0xfffff8f0)
class UCommonTabListWidgetLegacy : public UCommonTabListWidgetBase
{
public:
    uint8_t OnTabButtonCreated[0x10]; // 0x450 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTabButtonRemoved[0x10]; // 0x460 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void OnTabButtonCreated__DelegateSignature(FName& TabID, UCommonButtonLegacy*& TabButton); // 0x288a61c (Index: 0x5, Flags: MulticastDelegate|Public|Delegate)
    void OnTabButtonRemoved__DelegateSignature(FName& TabID, UCommonButtonLegacy*& TabButton); // 0x288a61c (Index: 0x6, Flags: MulticastDelegate|Public|Delegate)

private:
    void HandleOnTabButtonCreated(FName& TabID, UCommonButtonBase*& TabButton); // 0x448f728 (Index: 0x1, Flags: Final|Native|Private)
    void HandleOnTabButtonRemoved(FName& TabID, UCommonButtonBase*& TabButton); // 0xc018a04 (Index: 0x2, Flags: Final|Native|Private)

protected:
    UCommonButtonLegacy* GetTabButtonByID(FName& TabNameID); // 0x448fd74 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void HandleTabCreated(FName& TabNameID, UCommonButtonLegacy*& TabButton); // 0xc018c3c (Index: 0x3, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void HandleTabRemoved(FName& TabNameID, UCommonButtonLegacy*& TabButton); // 0xc018e48 (Index: 0x4, Flags: Native|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCommonTabListWidgetLegacy) == 0x470, "Size mismatch for UCommonTabListWidgetLegacy");
static_assert(offsetof(UCommonTabListWidgetLegacy, OnTabButtonCreated) == 0x450, "Offset mismatch for UCommonTabListWidgetLegacy::OnTabButtonCreated");
static_assert(offsetof(UCommonTabListWidgetLegacy, OnTabButtonRemoved) == 0x460, "Offset mismatch for UCommonTabListWidgetLegacy::OnTabButtonRemoved");

// Size: 0x70 (Inherited: 0xc8, Single: 0xffffffa8)
class UCommonUISubsystemLegacy : public UCommonUISubsystemBase
{
public:
    uint8_t OnInputSuspensionChanged[0x10]; // 0x40 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UCommonInputManagerLegacy* CommonInputManager; // 0x50 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_58[0x18]; // 0x58 (Size: 0x18, Type: PaddingProperty)

public:
    UCommonInputManagerLegacy* GetInputManager() const; // 0xb4791e8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void InputSuspensionChanged__DelegateSignature(bool& bInputSuspended); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
};

static_assert(sizeof(UCommonUISubsystemLegacy) == 0x70, "Size mismatch for UCommonUISubsystemLegacy");
static_assert(offsetof(UCommonUISubsystemLegacy, OnInputSuspensionChanged) == 0x40, "Offset mismatch for UCommonUISubsystemLegacy::OnInputSuspensionChanged");
static_assert(offsetof(UCommonUISubsystemLegacy, CommonInputManager) == 0x50, "Offset mismatch for UCommonUISubsystemLegacy::CommonInputManager");

// Size: 0x300 (Inherited: 0xa48, Single: 0xfffff8b8)
class UCommonVisibilityWidgetLegacy : public UCommonBorder
{
public:
    bool bShowForGamepad; // 0x2f0 (Size: 0x1, Type: BoolProperty)
    bool bShowForMouseAndKeyboard; // 0x2f1 (Size: 0x1, Type: BoolProperty)
    bool bShowForTouch; // 0x2f2 (Size: 0x1, Type: BoolProperty)
    bool bShowForPC; // 0x2f3 (Size: 0x1, Type: BoolProperty)
    bool bShowForMac; // 0x2f4 (Size: 0x1, Type: BoolProperty)
    bool bShowForPS4; // 0x2f5 (Size: 0x1, Type: BoolProperty)
    bool bShowForPS5; // 0x2f6 (Size: 0x1, Type: BoolProperty)
    bool bShowForXBox; // 0x2f7 (Size: 0x1, Type: BoolProperty)
    bool bShowForXSX; // 0x2f8 (Size: 0x1, Type: BoolProperty)
    bool bShowForIOS; // 0x2f9 (Size: 0x1, Type: BoolProperty)
    bool bShowForAndroid; // 0x2fa (Size: 0x1, Type: BoolProperty)
    bool bShowForErebus; // 0x2fb (Size: 0x1, Type: BoolProperty)
    bool bShowForSwitch2; // 0x2fc (Size: 0x1, Type: BoolProperty)
    uint8_t VisibleType; // 0x2fd (Size: 0x1, Type: EnumProperty)
    uint8_t HiddenType; // 0x2fe (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2ff[0x1]; // 0x2ff (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(UCommonVisibilityWidgetLegacy) == 0x300, "Size mismatch for UCommonVisibilityWidgetLegacy");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForGamepad) == 0x2f0, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForGamepad");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForMouseAndKeyboard) == 0x2f1, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForMouseAndKeyboard");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForTouch) == 0x2f2, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForTouch");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForPC) == 0x2f3, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForPC");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForMac) == 0x2f4, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForMac");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForPS4) == 0x2f5, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForPS4");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForPS5) == 0x2f6, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForPS5");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForXBox) == 0x2f7, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForXBox");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForXSX) == 0x2f8, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForXSX");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForIOS) == 0x2f9, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForIOS");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForAndroid) == 0x2fa, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForAndroid");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForErebus) == 0x2fb, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForErebus");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, bShowForSwitch2) == 0x2fc, "Offset mismatch for UCommonVisibilityWidgetLegacy::bShowForSwitch2");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, VisibleType) == 0x2fd, "Offset mismatch for UCommonVisibilityWidgetLegacy::VisibleType");
static_assert(offsetof(UCommonVisibilityWidgetLegacy, HiddenType) == 0x2fe, "Offset mismatch for UCommonVisibilityWidgetLegacy::HiddenType");

// Size: 0x1b8 (Inherited: 0x640, Single: 0xfffffb78)
class UCommonWidgetStackLegacy : public UCommonVisibilitySwitcher
{
public:
    uint8_t OnActiveWidgetChangedLegacyEvent[0x10]; // 0x1a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void OnActiveWidgetChangedLegacy__DelegateSignature(UWidget*& InActiveWidget, int32_t& InActiveWidgetIndex); // 0x288a61c (Index: 0x2, Flags: MulticastDelegate|Public|Delegate)
    UWidget* PopWidget(); // 0xc019bb0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void PushWidget(UWidget*& InWidget); // 0xc019ec8 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void ActivateWidget(); // 0xc0152ec (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void DeactivateWidget(); // 0xc016cd0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UCommonWidgetStackLegacy) == 0x1b8, "Size mismatch for UCommonWidgetStackLegacy");
static_assert(offsetof(UCommonWidgetStackLegacy, OnActiveWidgetChangedLegacyEvent) == 0x1a8, "Offset mismatch for UCommonWidgetStackLegacy::OnActiveWidgetChangedLegacyEvent");

// Size: 0x238 (Inherited: 0x6b0, Single: 0xfffffb88)
class UCommonWidgetSwitcherLegacy : public UCommonAnimatedSwitcher
{
public:
    uint8_t OnActiveWidgetDeactivated[0x10]; // 0x210 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnActiveWidgetChanged[0x10]; // 0x220 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bWidgetActivationEnabled; // 0x230 (Size: 0x1, Type: BoolProperty)
    bool bOutroPanelBelow; // 0x231 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_232[0x6]; // 0x232 (Size: 0x6, Type: PaddingProperty)

public:
    void ActivateWidget(); // 0x368f85c (Index: 0x0, Flags: Native|Public|BlueprintCallable)
    void DeactivateWidget(); // 0x368e690 (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    void SetActiveWidget_Advanced(UWidget*& Widget, bool& const AttemptActivationChange); // 0xc01b848 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void SetActiveWidgetIndex_Advanced(int32_t& const Index, bool& const AttemptActivationChange); // 0xc01b640 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)

private:
    void HandleActiveWidgetDeactivated(UCommonActivatablePanelLegacy*& DeactivatedPanel); // 0xc0173e4 (Index: 0x2, Flags: Final|Native|Private)
};

static_assert(sizeof(UCommonWidgetSwitcherLegacy) == 0x238, "Size mismatch for UCommonWidgetSwitcherLegacy");
static_assert(offsetof(UCommonWidgetSwitcherLegacy, OnActiveWidgetDeactivated) == 0x210, "Offset mismatch for UCommonWidgetSwitcherLegacy::OnActiveWidgetDeactivated");
static_assert(offsetof(UCommonWidgetSwitcherLegacy, OnActiveWidgetChanged) == 0x220, "Offset mismatch for UCommonWidgetSwitcherLegacy::OnActiveWidgetChanged");
static_assert(offsetof(UCommonWidgetSwitcherLegacy, bWidgetActivationEnabled) == 0x230, "Offset mismatch for UCommonWidgetSwitcherLegacy::bWidgetActivationEnabled");
static_assert(offsetof(UCommonWidgetSwitcherLegacy, bOutroPanelBelow) == 0x231, "Offset mismatch for UCommonWidgetSwitcherLegacy::bOutroPanelBelow");

// Size: 0x200 (Inherited: 0x1b0, Single: 0x50)
class UCommonButtonGroupLegacy : public UCommonButtonGroupBase
{
public:
    uint8_t OnSelectedButtonChanged[0x10]; // 0x160 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_170[0x18]; // 0x170 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnHoveredButtonChanged[0x10]; // 0x188 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_198[0x18]; // 0x198 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnButtonClicked[0x10]; // 0x1b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_1c0[0x18]; // 0x1c0 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnButtonDoubleClicked[0x10]; // 0x1d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_1e8[0x18]; // 0x1e8 (Size: 0x18, Type: PaddingProperty)

public:
    static UCommonButtonGroupLegacy* CreateButtonGroup(UObject*& ContextObject, bool& bInSelectionRequired); // 0xc016ab8 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    UCommonButtonLegacy* GetButtonAtIndex(int32_t& Index) const; // 0xc016f9c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCommonButtonLegacy* GetSelectedButton() const; // 0xc01739c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    void HandleNativeOnButtonClicked(UCommonButtonBase*& BaseButton, int32_t& InSelectedButtonIndex); // 0xc017514 (Index: 0x3, Flags: Final|Native|Private)
    void HandleNativeOnButtonDoubleClicked(UCommonButtonBase*& BaseButton, int32_t& InSelectedButtonIndex); // 0xc01771c (Index: 0x4, Flags: Final|Native|Private)
    void HandleNativeOnHoveredButtonChanged(UCommonButtonBase*& BaseButton, int32_t& InSelectedButtonIndex); // 0xc017924 (Index: 0x5, Flags: Final|Native|Private)
    void HandleNativeOnSelectedButtonChanged(UCommonButtonBase*& BaseButton, int32_t& InSelectedButtonIndex); // 0xc017b2c (Index: 0x6, Flags: Final|Native|Private)
    void HandleOnButtonClicked(UCommonButtonBase*& BaseButton, int32_t& InSelectedButtonIndex); // 0xc017d34 (Index: 0x7, Flags: Final|Native|Private)
    void HandleOnButtonDoubleClicked(UCommonButtonBase*& BaseButton, int32_t& InSelectedButtonIndex); // 0xc018068 (Index: 0x8, Flags: Final|Native|Private)
    void HandleOnHoveredButtonChanged(UCommonButtonBase*& BaseButton, int32_t& InSelectedButtonIndex); // 0xc0185f4 (Index: 0x9, Flags: Final|Native|Private)
    void HandleOnSelectedButtonChanged(UCommonButtonBase*& BaseButton, int32_t& InSelectedButtonIndex); // 0xc0187fc (Index: 0xa, Flags: Final|Native|Private)

protected:
    void OnButtonHovered(UCommonButtonLegacy*& BaseButton); // 0xc0194d0 (Index: 0xb, Flags: Native|Protected)
    void OnButtonUnhovered(UCommonButtonLegacy*& BaseButton); // 0xa157078 (Index: 0xc, Flags: Native|Protected)
    void OnHandleButtonClicked(UCommonButtonLegacy*& BaseButton); // 0xc019600 (Index: 0xd, Flags: Native|Protected)
    void OnHandleButtonDoubleClicked(UCommonButtonLegacy*& BaseButton); // 0xa130e8c (Index: 0xe, Flags: Native|Protected)
    void OnSelectionStateChanged(UCommonButtonLegacy*& BaseButton, bool& bIsSelected); // 0xc01985c (Index: 0xf, Flags: Native|Protected)
};

static_assert(sizeof(UCommonButtonGroupLegacy) == 0x200, "Size mismatch for UCommonButtonGroupLegacy");
static_assert(offsetof(UCommonButtonGroupLegacy, OnSelectedButtonChanged) == 0x160, "Offset mismatch for UCommonButtonGroupLegacy::OnSelectedButtonChanged");
static_assert(offsetof(UCommonButtonGroupLegacy, OnHoveredButtonChanged) == 0x188, "Offset mismatch for UCommonButtonGroupLegacy::OnHoveredButtonChanged");
static_assert(offsetof(UCommonButtonGroupLegacy, OnButtonClicked) == 0x1b0, "Offset mismatch for UCommonButtonGroupLegacy::OnButtonClicked");
static_assert(offsetof(UCommonButtonGroupLegacy, OnButtonDoubleClicked) == 0x1d8, "Offset mismatch for UCommonButtonGroupLegacy::OnButtonDoubleClicked");

// Size: 0x1e0 (Inherited: 0x260, Single: 0xffffff80)
class UCommonUIActionRouterLegacy : public UCommonUIActionRouterBase
{
public:
};

static_assert(sizeof(UCommonUIActionRouterLegacy) == 0x1e0, "Size mismatch for UCommonUIActionRouterLegacy");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FOperation
{
    uint8_t Operation; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UCommonActivatablePanelLegacy* Panel; // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bIntroPanel; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bActivatePanel; // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bOutroPanelBelow; // 0x12 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_13[0x15]; // 0x13 (Size: 0x15, Type: PaddingProperty)
};

static_assert(sizeof(FOperation) == 0x28, "Size mismatch for FOperation");
static_assert(offsetof(FOperation, Operation) == 0x0, "Offset mismatch for FOperation::Operation");
static_assert(offsetof(FOperation, Panel) == 0x8, "Offset mismatch for FOperation::Panel");
static_assert(offsetof(FOperation, bIntroPanel) == 0x10, "Offset mismatch for FOperation::bIntroPanel");
static_assert(offsetof(FOperation, bActivatePanel) == 0x11, "Offset mismatch for FOperation::bActivatePanel");
static_assert(offsetof(FOperation, bOutroPanelBelow) == 0x12, "Offset mismatch for FOperation::bOutroPanelBelow");

// Size: 0x990 (Inherited: 0x328, Single: 0x668)
struct FCommonInputActionData : FCommonInputActionDataBase
{
    TMap<FCommonInputTypeInfo, ECommonGamepadType> GamepadInputTypeInfoOverrides; // 0x320 (Size: 0x50, Type: MapProperty)
    FCommonInputTypeInfo GamepadInputTypeInfos[0x7]; // 0x370 (Size: 0x620, Type: StructProperty)
};

static_assert(sizeof(FCommonInputActionData) == 0x990, "Size mismatch for FCommonInputActionData");
static_assert(offsetof(FCommonInputActionData, GamepadInputTypeInfoOverrides) == 0x320, "Offset mismatch for FCommonInputActionData::GamepadInputTypeInfoOverrides");
static_assert(offsetof(FCommonInputActionData, GamepadInputTypeInfos) == 0x370, "Offset mismatch for FCommonInputActionData::GamepadInputTypeInfos");

