/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeDataChannelTriggerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "ElectraDataChannelRuntime.h"
#include "Engine.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UCreativeDataChannelAnalytics : public UObject
{
public:
};

static_assert(sizeof(UCreativeDataChannelAnalytics) == 0x28, "Size mismatch for UCreativeDataChannelAnalytics");

// Size: 0x370 (Inherited: 0x5f0, Single: 0xfffffd80)
class ACreativeDataChannelTarget : public AElectraDataChannelTarget
{
public:
    uint8_t Pad_320[0x8]; // 0x320 (Size: 0x8, Type: PaddingProperty)
    int8_t VersionByte; // 0x328 (Size: 0x1, Type: Int8Property)
    uint8_t Pad_329[0x7]; // 0x329 (Size: 0x7, Type: PaddingProperty)
    FCreativeDataChannelEvents EVENTS; // 0x330 (Size: 0x10, Type: StructProperty)
    uint8_t OnEventsRep[0x10]; // 0x340 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FCreativeDataChannelEvents EventsCache; // 0x350 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_360[0x10]; // 0x360 (Size: 0x10, Type: PaddingProperty)

public:
    virtual void FireEvent(FName& EventName); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    void OnRep_Events(); // 0x554e3c4 (Index: 0x1, Flags: Final|Native|Public)
    void TestCreativeDataChannelTarget(FCreativeDataChannelEvents& TestEvents); // 0x11abcbbc (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ACreativeDataChannelTarget) == 0x370, "Size mismatch for ACreativeDataChannelTarget");
static_assert(offsetof(ACreativeDataChannelTarget, VersionByte) == 0x328, "Offset mismatch for ACreativeDataChannelTarget::VersionByte");
static_assert(offsetof(ACreativeDataChannelTarget, EVENTS) == 0x330, "Offset mismatch for ACreativeDataChannelTarget::EVENTS");
static_assert(offsetof(ACreativeDataChannelTarget, OnEventsRep) == 0x340, "Offset mismatch for ACreativeDataChannelTarget::OnEventsRep");
static_assert(offsetof(ACreativeDataChannelTarget, EventsCache) == 0x350, "Offset mismatch for ACreativeDataChannelTarget::EventsCache");

// Size: 0x5d8 (Inherited: 0x5f0, Single: 0xffffffe8)
class ACreativeDataChannelTargetFN : public AElectraDataChannelTarget
{
public:
    uint8_t Pad_320[0x8]; // 0x320 (Size: 0x8, Type: PaddingProperty)
    int32_t VersionByte; // 0x328 (Size: 0x4, Type: IntProperty)
    FCDCInt VersionByteTracker; // 0x32c (Size: 0x4, Type: StructProperty)
    uint8_t VersionByteEvent[0x10]; // 0x330 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString LeaderBoard; // 0x340 (Size: 0x10, Type: StrProperty)
    int64_t StormCircleSize; // 0x350 (Size: 0x8, Type: Int64Property)
    FCDCLargeInt StormCircleSizeTracker; // 0x358 (Size: 0x8, Type: StructProperty)
    uint8_t StormCircleSizeEvent[0x10]; // 0x360 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<float> StormCircleLocation; // 0x370 (Size: 0x10, Type: ArrayProperty)
    FCDCFloatArray StormCircleLocationTracker; // 0x380 (Size: 0x10, Type: StructProperty)
    uint8_t StormCircleLocationEvent[0x10]; // 0x390 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString PlayerLocation; // 0x3a0 (Size: 0x10, Type: StrProperty)
    FCDCStringFloatArrayMap PlayerLocationTracker; // 0x3b0 (Size: 0x50, Type: StructProperty)
    uint8_t PlayerLocationEvent[0x10]; // 0x400 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString ArenaPointLeaderBoard; // 0x410 (Size: 0x10, Type: StrProperty)
    FCDCStringStringMap ArenaPointLeaderBoardTracker; // 0x420 (Size: 0xa0, Type: StructProperty)
    uint8_t ArenaPointLeaderBoardEvent[0x10]; // 0x4c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString CashCupDataAllTimeEarners; // 0x4d0 (Size: 0x10, Type: StrProperty)
    FCDCStringFloatMap CashCupDataAllTimeEanersTracker; // 0x4e0 (Size: 0x50, Type: StructProperty)
    uint8_t CashCupDataAllTimeEarnersEvent[0x10]; // 0x530 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString MythicBossEliminatedPlayer; // 0x540 (Size: 0x10, Type: StrProperty)
    FCDCString MythicBossEliminatedPlayerTracker; // 0x550 (Size: 0x10, Type: StructProperty)
    uint8_t MythicBossEliminatedPlayerEvent[0x10]; // 0x560 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString MythicWeaponPlayer; // 0x570 (Size: 0x10, Type: StrProperty)
    FCDCString MythicWeaponPlayerTracker; // 0x580 (Size: 0x10, Type: StructProperty)
    uint8_t MythicWeaponPlayerEvent[0x10]; // 0x590 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString PlayerInfo; // 0x5a0 (Size: 0x10, Type: StrProperty)
    FCDCStringArray PlayerInfoTracker; // 0x5b0 (Size: 0x18, Type: StructProperty)
    uint8_t PlayerInfoEvent[0x10]; // 0x5c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
};

static_assert(sizeof(ACreativeDataChannelTargetFN) == 0x5d8, "Size mismatch for ACreativeDataChannelTargetFN");
static_assert(offsetof(ACreativeDataChannelTargetFN, VersionByte) == 0x328, "Offset mismatch for ACreativeDataChannelTargetFN::VersionByte");
static_assert(offsetof(ACreativeDataChannelTargetFN, VersionByteTracker) == 0x32c, "Offset mismatch for ACreativeDataChannelTargetFN::VersionByteTracker");
static_assert(offsetof(ACreativeDataChannelTargetFN, VersionByteEvent) == 0x330, "Offset mismatch for ACreativeDataChannelTargetFN::VersionByteEvent");
static_assert(offsetof(ACreativeDataChannelTargetFN, LeaderBoard) == 0x340, "Offset mismatch for ACreativeDataChannelTargetFN::LeaderBoard");
static_assert(offsetof(ACreativeDataChannelTargetFN, StormCircleSize) == 0x350, "Offset mismatch for ACreativeDataChannelTargetFN::StormCircleSize");
static_assert(offsetof(ACreativeDataChannelTargetFN, StormCircleSizeTracker) == 0x358, "Offset mismatch for ACreativeDataChannelTargetFN::StormCircleSizeTracker");
static_assert(offsetof(ACreativeDataChannelTargetFN, StormCircleSizeEvent) == 0x360, "Offset mismatch for ACreativeDataChannelTargetFN::StormCircleSizeEvent");
static_assert(offsetof(ACreativeDataChannelTargetFN, StormCircleLocation) == 0x370, "Offset mismatch for ACreativeDataChannelTargetFN::StormCircleLocation");
static_assert(offsetof(ACreativeDataChannelTargetFN, StormCircleLocationTracker) == 0x380, "Offset mismatch for ACreativeDataChannelTargetFN::StormCircleLocationTracker");
static_assert(offsetof(ACreativeDataChannelTargetFN, StormCircleLocationEvent) == 0x390, "Offset mismatch for ACreativeDataChannelTargetFN::StormCircleLocationEvent");
static_assert(offsetof(ACreativeDataChannelTargetFN, PlayerLocation) == 0x3a0, "Offset mismatch for ACreativeDataChannelTargetFN::PlayerLocation");
static_assert(offsetof(ACreativeDataChannelTargetFN, PlayerLocationTracker) == 0x3b0, "Offset mismatch for ACreativeDataChannelTargetFN::PlayerLocationTracker");
static_assert(offsetof(ACreativeDataChannelTargetFN, PlayerLocationEvent) == 0x400, "Offset mismatch for ACreativeDataChannelTargetFN::PlayerLocationEvent");
static_assert(offsetof(ACreativeDataChannelTargetFN, ArenaPointLeaderBoard) == 0x410, "Offset mismatch for ACreativeDataChannelTargetFN::ArenaPointLeaderBoard");
static_assert(offsetof(ACreativeDataChannelTargetFN, ArenaPointLeaderBoardTracker) == 0x420, "Offset mismatch for ACreativeDataChannelTargetFN::ArenaPointLeaderBoardTracker");
static_assert(offsetof(ACreativeDataChannelTargetFN, ArenaPointLeaderBoardEvent) == 0x4c0, "Offset mismatch for ACreativeDataChannelTargetFN::ArenaPointLeaderBoardEvent");
static_assert(offsetof(ACreativeDataChannelTargetFN, CashCupDataAllTimeEarners) == 0x4d0, "Offset mismatch for ACreativeDataChannelTargetFN::CashCupDataAllTimeEarners");
static_assert(offsetof(ACreativeDataChannelTargetFN, CashCupDataAllTimeEanersTracker) == 0x4e0, "Offset mismatch for ACreativeDataChannelTargetFN::CashCupDataAllTimeEanersTracker");
static_assert(offsetof(ACreativeDataChannelTargetFN, CashCupDataAllTimeEarnersEvent) == 0x530, "Offset mismatch for ACreativeDataChannelTargetFN::CashCupDataAllTimeEarnersEvent");
static_assert(offsetof(ACreativeDataChannelTargetFN, MythicBossEliminatedPlayer) == 0x540, "Offset mismatch for ACreativeDataChannelTargetFN::MythicBossEliminatedPlayer");
static_assert(offsetof(ACreativeDataChannelTargetFN, MythicBossEliminatedPlayerTracker) == 0x550, "Offset mismatch for ACreativeDataChannelTargetFN::MythicBossEliminatedPlayerTracker");
static_assert(offsetof(ACreativeDataChannelTargetFN, MythicBossEliminatedPlayerEvent) == 0x560, "Offset mismatch for ACreativeDataChannelTargetFN::MythicBossEliminatedPlayerEvent");
static_assert(offsetof(ACreativeDataChannelTargetFN, MythicWeaponPlayer) == 0x570, "Offset mismatch for ACreativeDataChannelTargetFN::MythicWeaponPlayer");
static_assert(offsetof(ACreativeDataChannelTargetFN, MythicWeaponPlayerTracker) == 0x580, "Offset mismatch for ACreativeDataChannelTargetFN::MythicWeaponPlayerTracker");
static_assert(offsetof(ACreativeDataChannelTargetFN, MythicWeaponPlayerEvent) == 0x590, "Offset mismatch for ACreativeDataChannelTargetFN::MythicWeaponPlayerEvent");
static_assert(offsetof(ACreativeDataChannelTargetFN, PlayerInfo) == 0x5a0, "Offset mismatch for ACreativeDataChannelTargetFN::PlayerInfo");
static_assert(offsetof(ACreativeDataChannelTargetFN, PlayerInfoTracker) == 0x5b0, "Offset mismatch for ACreativeDataChannelTargetFN::PlayerInfoTracker");
static_assert(offsetof(ACreativeDataChannelTargetFN, PlayerInfoEvent) == 0x5c8, "Offset mismatch for ACreativeDataChannelTargetFN::PlayerInfoEvent");

// Size: 0x7e0 (Inherited: 0x5f0, Single: 0x1f0)
class ACreativeDataChannelTargetRL : public AElectraDataChannelTarget
{
public:
    uint8_t Pad_320[0x8]; // 0x320 (Size: 0x8, Type: PaddingProperty)
    int32_t VersionByte; // 0x328 (Size: 0x4, Type: IntProperty)
    FCDCInt VersionByteTracker; // 0x32c (Size: 0x4, Type: StructProperty)
    uint8_t VersionByteEvent[0x10]; // 0x330 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t ScoreTeam; // 0x340 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_344[0x4]; // 0x344 (Size: 0x4, Type: PaddingProperty)
    FCDCString ScoreTeamTracker; // 0x348 (Size: 0x10, Type: StructProperty)
    uint8_t ScoreTeamEvent[0x10]; // 0x358 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString ScoreTotal; // 0x368 (Size: 0x10, Type: StrProperty)
    FCDCStringIntMap ScoreTotalTracker; // 0x378 (Size: 0x50, Type: StructProperty)
    uint8_t ScoreTotalEvent[0x10]; // 0x3c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int64_t ScoreboardTimeLeft; // 0x3d8 (Size: 0x8, Type: Int64Property)
    FCDCLargeInt ScoreboardTimeLeftTracker; // 0x3e0 (Size: 0x8, Type: StructProperty)
    uint8_t ScoreboardTimeLeftEvent[0x10]; // 0x3e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString ScoreboardBestOf; // 0x3f8 (Size: 0x10, Type: StrProperty)
    FCDCStringIntMap ScoreboardBestOfTracker; // 0x408 (Size: 0x50, Type: StructProperty)
    uint8_t ScoreboardBestOfEvent[0x10]; // 0x458 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t OverTime; // 0x468 (Size: 0x4, Type: IntProperty)
    FCDCInt OvertimeTracker; // 0x46c (Size: 0x4, Type: StructProperty)
    uint8_t OvertimeEvent[0x10]; // 0x470 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString TeamNames; // 0x480 (Size: 0x10, Type: StrProperty)
    FCDCStringArray TeamNamesTracker; // 0x490 (Size: 0x18, Type: StructProperty)
    uint8_t TeamNamesEvent[0x10]; // 0x4a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString PlayerNames; // 0x4b8 (Size: 0x10, Type: StrProperty)
    FCDCStringArray PlayerNamesTracker; // 0x4c8 (Size: 0x18, Type: StructProperty)
    uint8_t PlayerNamesEvent[0x10]; // 0x4e0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString PlayerBoost; // 0x4f0 (Size: 0x10, Type: StrProperty)
    FCDCStringIntMap PlayerBoostTracker; // 0x500 (Size: 0x50, Type: StructProperty)
    uint8_t PlayerBoostEvent[0x10]; // 0x550 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString PlayerBoostCollected; // 0x560 (Size: 0x10, Type: StrProperty)
    FCDCStringStringMap PlayerBoostCollectedTracker; // 0x570 (Size: 0xa0, Type: StructProperty)
    uint8_t PlayerBoostCollectedEvent[0x10]; // 0x610 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString PlayerCoords; // 0x620 (Size: 0x10, Type: StrProperty)
    FCDCStringFloatArrayMap PlayerCoordsTracker; // 0x630 (Size: 0x50, Type: StructProperty)
    uint8_t PlayerCoordsEvent[0x10]; // 0x680 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString BallCoords; // 0x690 (Size: 0x10, Type: StrProperty)
    FCDCFloatArray BallCoordsTracker; // 0x6a0 (Size: 0x10, Type: StructProperty)
    uint8_t BallCoordsEvent[0x10]; // 0x6b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString MediaStart; // 0x6c0 (Size: 0x10, Type: StrProperty)
    FCDCStringStringMap MediaStartTracker; // 0x6d0 (Size: 0xa0, Type: StructProperty)
    uint8_t MediaStartEvent[0x10]; // 0x770 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t MediaStop; // 0x780 (Size: 0x4, Type: IntProperty)
    FCDCInt MediaStopTracker; // 0x784 (Size: 0x4, Type: StructProperty)
    uint8_t MediaStopEvent[0x10]; // 0x788 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t SeriesState; // 0x798 (Size: 0x4, Type: IntProperty)
    FCDCInt SeriesStateTracker; // 0x79c (Size: 0x4, Type: StructProperty)
    uint8_t SeriesStateEvent[0x10]; // 0x7a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t MatchState; // 0x7b0 (Size: 0x4, Type: IntProperty)
    FCDCInt MatchStateTracker; // 0x7b4 (Size: 0x4, Type: StructProperty)
    uint8_t MatchStateEvent[0x10]; // 0x7b8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t FinaleState; // 0x7c8 (Size: 0x4, Type: IntProperty)
    FCDCInt FinaleStateTracker; // 0x7cc (Size: 0x4, Type: StructProperty)
    uint8_t FinaleStateEvent[0x10]; // 0x7d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void OnRep_BallCoords(); // 0x11abc27c (Index: 0x0, Flags: Final|Native|Public)
    void OnRep_FinaleState(); // 0x11abc290 (Index: 0x1, Flags: Final|Native|Public)
    void OnRep_MatchState(); // 0x11abc2c8 (Index: 0x2, Flags: Final|Native|Public)
    void OnRep_MediaStart(); // 0x11abc300 (Index: 0x3, Flags: Final|Native|Public)
    void OnRep_MediaStop(); // 0x11abc314 (Index: 0x4, Flags: Final|Native|Public)
    void OnRep_Overtime(); // 0x11abc34c (Index: 0x5, Flags: Final|Native|Public)
    void OnRep_PlayerBoost(); // 0x11abc384 (Index: 0x6, Flags: Final|Native|Public)
    void OnRep_PlayerBoostCollected(); // 0x11abc398 (Index: 0x7, Flags: Final|Native|Public)
    void OnRep_PlayerCoords(); // 0x11abc3ac (Index: 0x8, Flags: Final|Native|Public)
    void OnRep_PlayerNames(); // 0x11abc3c0 (Index: 0x9, Flags: Final|Native|Public)
    void OnRep_ScoreboardBestOf(); // 0x11abc3fc (Index: 0xa, Flags: Final|Native|Public)
    void OnRep_ScoreboardTimeLeft(); // 0x11abc410 (Index: 0xb, Flags: Final|Native|Public)
    void OnRep_ScoreTeam(); // 0x11abc3d4 (Index: 0xc, Flags: Final|Native|Public)
    void OnRep_ScoreTotal(); // 0x11abc3e8 (Index: 0xd, Flags: Final|Native|Public)
    void OnRep_SeriesState(); // 0x11abc44c (Index: 0xe, Flags: Final|Native|Public)
    void OnRep_TeamNames(); // 0x11abc484 (Index: 0xf, Flags: Final|Native|Public)
    void OnRep_VersionByte(); // 0x11abc4ec (Index: 0x10, Flags: Final|Native|Public)
    void ReportServerStateStreamError(FString& Error, FString& UID, FString& URL); // 0x11abc524 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ACreativeDataChannelTargetRL) == 0x7e0, "Size mismatch for ACreativeDataChannelTargetRL");
static_assert(offsetof(ACreativeDataChannelTargetRL, VersionByte) == 0x328, "Offset mismatch for ACreativeDataChannelTargetRL::VersionByte");
static_assert(offsetof(ACreativeDataChannelTargetRL, VersionByteTracker) == 0x32c, "Offset mismatch for ACreativeDataChannelTargetRL::VersionByteTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, VersionByteEvent) == 0x330, "Offset mismatch for ACreativeDataChannelTargetRL::VersionByteEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, ScoreTeam) == 0x340, "Offset mismatch for ACreativeDataChannelTargetRL::ScoreTeam");
static_assert(offsetof(ACreativeDataChannelTargetRL, ScoreTeamTracker) == 0x348, "Offset mismatch for ACreativeDataChannelTargetRL::ScoreTeamTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, ScoreTeamEvent) == 0x358, "Offset mismatch for ACreativeDataChannelTargetRL::ScoreTeamEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, ScoreTotal) == 0x368, "Offset mismatch for ACreativeDataChannelTargetRL::ScoreTotal");
static_assert(offsetof(ACreativeDataChannelTargetRL, ScoreTotalTracker) == 0x378, "Offset mismatch for ACreativeDataChannelTargetRL::ScoreTotalTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, ScoreTotalEvent) == 0x3c8, "Offset mismatch for ACreativeDataChannelTargetRL::ScoreTotalEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, ScoreboardTimeLeft) == 0x3d8, "Offset mismatch for ACreativeDataChannelTargetRL::ScoreboardTimeLeft");
static_assert(offsetof(ACreativeDataChannelTargetRL, ScoreboardTimeLeftTracker) == 0x3e0, "Offset mismatch for ACreativeDataChannelTargetRL::ScoreboardTimeLeftTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, ScoreboardTimeLeftEvent) == 0x3e8, "Offset mismatch for ACreativeDataChannelTargetRL::ScoreboardTimeLeftEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, ScoreboardBestOf) == 0x3f8, "Offset mismatch for ACreativeDataChannelTargetRL::ScoreboardBestOf");
static_assert(offsetof(ACreativeDataChannelTargetRL, ScoreboardBestOfTracker) == 0x408, "Offset mismatch for ACreativeDataChannelTargetRL::ScoreboardBestOfTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, ScoreboardBestOfEvent) == 0x458, "Offset mismatch for ACreativeDataChannelTargetRL::ScoreboardBestOfEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, OverTime) == 0x468, "Offset mismatch for ACreativeDataChannelTargetRL::OverTime");
static_assert(offsetof(ACreativeDataChannelTargetRL, OvertimeTracker) == 0x46c, "Offset mismatch for ACreativeDataChannelTargetRL::OvertimeTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, OvertimeEvent) == 0x470, "Offset mismatch for ACreativeDataChannelTargetRL::OvertimeEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, TeamNames) == 0x480, "Offset mismatch for ACreativeDataChannelTargetRL::TeamNames");
static_assert(offsetof(ACreativeDataChannelTargetRL, TeamNamesTracker) == 0x490, "Offset mismatch for ACreativeDataChannelTargetRL::TeamNamesTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, TeamNamesEvent) == 0x4a8, "Offset mismatch for ACreativeDataChannelTargetRL::TeamNamesEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, PlayerNames) == 0x4b8, "Offset mismatch for ACreativeDataChannelTargetRL::PlayerNames");
static_assert(offsetof(ACreativeDataChannelTargetRL, PlayerNamesTracker) == 0x4c8, "Offset mismatch for ACreativeDataChannelTargetRL::PlayerNamesTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, PlayerNamesEvent) == 0x4e0, "Offset mismatch for ACreativeDataChannelTargetRL::PlayerNamesEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, PlayerBoost) == 0x4f0, "Offset mismatch for ACreativeDataChannelTargetRL::PlayerBoost");
static_assert(offsetof(ACreativeDataChannelTargetRL, PlayerBoostTracker) == 0x500, "Offset mismatch for ACreativeDataChannelTargetRL::PlayerBoostTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, PlayerBoostEvent) == 0x550, "Offset mismatch for ACreativeDataChannelTargetRL::PlayerBoostEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, PlayerBoostCollected) == 0x560, "Offset mismatch for ACreativeDataChannelTargetRL::PlayerBoostCollected");
static_assert(offsetof(ACreativeDataChannelTargetRL, PlayerBoostCollectedTracker) == 0x570, "Offset mismatch for ACreativeDataChannelTargetRL::PlayerBoostCollectedTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, PlayerBoostCollectedEvent) == 0x610, "Offset mismatch for ACreativeDataChannelTargetRL::PlayerBoostCollectedEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, PlayerCoords) == 0x620, "Offset mismatch for ACreativeDataChannelTargetRL::PlayerCoords");
static_assert(offsetof(ACreativeDataChannelTargetRL, PlayerCoordsTracker) == 0x630, "Offset mismatch for ACreativeDataChannelTargetRL::PlayerCoordsTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, PlayerCoordsEvent) == 0x680, "Offset mismatch for ACreativeDataChannelTargetRL::PlayerCoordsEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, BallCoords) == 0x690, "Offset mismatch for ACreativeDataChannelTargetRL::BallCoords");
static_assert(offsetof(ACreativeDataChannelTargetRL, BallCoordsTracker) == 0x6a0, "Offset mismatch for ACreativeDataChannelTargetRL::BallCoordsTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, BallCoordsEvent) == 0x6b0, "Offset mismatch for ACreativeDataChannelTargetRL::BallCoordsEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, MediaStart) == 0x6c0, "Offset mismatch for ACreativeDataChannelTargetRL::MediaStart");
static_assert(offsetof(ACreativeDataChannelTargetRL, MediaStartTracker) == 0x6d0, "Offset mismatch for ACreativeDataChannelTargetRL::MediaStartTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, MediaStartEvent) == 0x770, "Offset mismatch for ACreativeDataChannelTargetRL::MediaStartEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, MediaStop) == 0x780, "Offset mismatch for ACreativeDataChannelTargetRL::MediaStop");
static_assert(offsetof(ACreativeDataChannelTargetRL, MediaStopTracker) == 0x784, "Offset mismatch for ACreativeDataChannelTargetRL::MediaStopTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, MediaStopEvent) == 0x788, "Offset mismatch for ACreativeDataChannelTargetRL::MediaStopEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, SeriesState) == 0x798, "Offset mismatch for ACreativeDataChannelTargetRL::SeriesState");
static_assert(offsetof(ACreativeDataChannelTargetRL, SeriesStateTracker) == 0x79c, "Offset mismatch for ACreativeDataChannelTargetRL::SeriesStateTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, SeriesStateEvent) == 0x7a0, "Offset mismatch for ACreativeDataChannelTargetRL::SeriesStateEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, MatchState) == 0x7b0, "Offset mismatch for ACreativeDataChannelTargetRL::MatchState");
static_assert(offsetof(ACreativeDataChannelTargetRL, MatchStateTracker) == 0x7b4, "Offset mismatch for ACreativeDataChannelTargetRL::MatchStateTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, MatchStateEvent) == 0x7b8, "Offset mismatch for ACreativeDataChannelTargetRL::MatchStateEvent");
static_assert(offsetof(ACreativeDataChannelTargetRL, FinaleState) == 0x7c8, "Offset mismatch for ACreativeDataChannelTargetRL::FinaleState");
static_assert(offsetof(ACreativeDataChannelTargetRL, FinaleStateTracker) == 0x7cc, "Offset mismatch for ACreativeDataChannelTargetRL::FinaleStateTracker");
static_assert(offsetof(ACreativeDataChannelTargetRL, FinaleStateEvent) == 0x7d0, "Offset mismatch for ACreativeDataChannelTargetRL::FinaleStateEvent");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FCDCStringFloatArrayMap
{
    TMap<FVector, FString> Data; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FCDCStringFloatArrayMap) == 0x50, "Size mismatch for FCDCStringFloatArrayMap");
static_assert(offsetof(FCDCStringFloatArrayMap, Data) == 0x0, "Offset mismatch for FCDCStringFloatArrayMap::Data");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCDCFloatArray
{
    TArray<float> Data; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCDCFloatArray) == 0x10, "Size mismatch for FCDCFloatArray");
static_assert(offsetof(FCDCFloatArray, Data) == 0x0, "Offset mismatch for FCDCFloatArray::Data");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FCDCStringFloatMap
{
    TMap<float, FString> Data; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FCDCStringFloatMap) == 0x50, "Size mismatch for FCDCStringFloatMap");
static_assert(offsetof(FCDCStringFloatMap, Data) == 0x0, "Offset mismatch for FCDCStringFloatMap::Data");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FCDCStringIntMap
{
    TMap<int32_t, FString> Data; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FCDCStringIntMap) == 0x50, "Size mismatch for FCDCStringIntMap");
static_assert(offsetof(FCDCStringIntMap, Data) == 0x0, "Offset mismatch for FCDCStringIntMap::Data");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCDCInt
{
    int32_t Data; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FCDCInt) == 0x4, "Size mismatch for FCDCInt");
static_assert(offsetof(FCDCInt, Data) == 0x0, "Offset mismatch for FCDCInt::Data");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FCDCLargeInt
{
    int64_t Data; // 0x0 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FCDCLargeInt) == 0x8, "Size mismatch for FCDCLargeInt");
static_assert(offsetof(FCDCLargeInt, Data) == 0x0, "Offset mismatch for FCDCLargeInt::Data");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FCDCStringStringMap
{
    TMap<FString, FString> Data; // 0x0 (Size: 0x50, Type: MapProperty)
    TMap<int32_t, FString> ExtraData; // 0x50 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FCDCStringStringMap) == 0xa0, "Size mismatch for FCDCStringStringMap");
static_assert(offsetof(FCDCStringStringMap, Data) == 0x0, "Offset mismatch for FCDCStringStringMap::Data");
static_assert(offsetof(FCDCStringStringMap, ExtraData) == 0x50, "Offset mismatch for FCDCStringStringMap::ExtraData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCDCString
{
    FString Data; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FCDCString) == 0x10, "Size mismatch for FCDCString");
static_assert(offsetof(FCDCString, Data) == 0x0, "Offset mismatch for FCDCString::Data");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCDCStringArray
{
    TArray<FString> Data; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t ExtraData; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCDCStringArray) == 0x18, "Size mismatch for FCDCStringArray");
static_assert(offsetof(FCDCStringArray, Data) == 0x0, "Offset mismatch for FCDCStringArray::Data");
static_assert(offsetof(FCDCStringArray, ExtraData) == 0x10, "Offset mismatch for FCDCStringArray::ExtraData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCreativeDataChannelEvents
{
    TArray<FCreativeDataChannelEvent> EVENTS; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCreativeDataChannelEvents) == 0x10, "Size mismatch for FCreativeDataChannelEvents");
static_assert(offsetof(FCreativeDataChannelEvents, EVENTS) == 0x0, "Offset mismatch for FCreativeDataChannelEvents::EVENTS");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FCreativeDataChannelEvent
{
    FName EventName; // 0x0 (Size: 0x4, Type: NameProperty)
    FName Parameters; // 0x4 (Size: 0x4, Type: NameProperty)
    FName TriggerCondition; // 0x8 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FCreativeDataChannelEvent) == 0xc, "Size mismatch for FCreativeDataChannelEvent");
static_assert(offsetof(FCreativeDataChannelEvent, EventName) == 0x0, "Offset mismatch for FCreativeDataChannelEvent::EventName");
static_assert(offsetof(FCreativeDataChannelEvent, Parameters) == 0x4, "Offset mismatch for FCreativeDataChannelEvent::Parameters");
static_assert(offsetof(FCreativeDataChannelEvent, TriggerCondition) == 0x8, "Offset mismatch for FCreativeDataChannelEvent::TriggerCondition");

