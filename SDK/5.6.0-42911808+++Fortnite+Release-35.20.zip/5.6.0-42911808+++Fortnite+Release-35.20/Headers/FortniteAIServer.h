/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteAIServer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteAI.h"
#include "CoreUObject.h"
#include "StateTreeModule.h"
#include "AIModule.h"
#include "WorldConditions.h"
#include "FortniteGame.h"
#include "GameFeatures.h"
#include "ModularGameplay.h"
#include "GameplayStateTreeModule.h"
#include "Engine.h"
#include "_Verse.h"
#include "GameplayInteractionsModule.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"
#include "DataRegistry.h"
#include "SmartObjectsModule.h"
#include "NavigationSystem.h"
#include "GameplayBehaviorsModule.h"
#include "PhysicsCore.h"
#include "ContextualAnimation.h"

// Size: 0x2c0 (Inherited: 0x3f0, Single: 0xfffffed0)
class UFortAthenaAIBotEvaluator_ApproachNearbyPawns : public UFortAthenaAIBotEvaluator_Movement
{
public:
    uint8_t Pad_1a0[0x20]; // 0x1a0 (Size: 0x20, Type: PaddingProperty)
    FScalableFloat MaxApproaches; // 0x1c0 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_1e8[0x8]; // 0x1e8 (Size: 0x8, Type: PaddingProperty)
    FFortNearbyActorsPerceptionConfiguration PerceptionConfiguration; // 0x1f0 (Size: 0xc0, Type: StructProperty)
    FName EnableKeyName; // 0x2b0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_2b4[0xc]; // 0x2b4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_ApproachNearbyPawns) == 0x2c0, "Size mismatch for UFortAthenaAIBotEvaluator_ApproachNearbyPawns");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ApproachNearbyPawns, MaxApproaches) == 0x1c0, "Offset mismatch for UFortAthenaAIBotEvaluator_ApproachNearbyPawns::MaxApproaches");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ApproachNearbyPawns, PerceptionConfiguration) == 0x1f0, "Offset mismatch for UFortAthenaAIBotEvaluator_ApproachNearbyPawns::PerceptionConfiguration");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ApproachNearbyPawns, EnableKeyName) == 0x2b0, "Offset mismatch for UFortAthenaAIBotEvaluator_ApproachNearbyPawns::EnableKeyName");

// Size: 0x228 (Inherited: 0x170, Single: 0xb8)
class UFortAthenaAIBotEvaluator_Disengagement : public UFortAthenaAIBotEvaluator
{
public:
    FName TargetActorKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    FName DisengagementReasonKeyName; // 0xac (Size: 0x4, Type: NameProperty)
    FScalableFloat TargetInterestEnabled; // 0xb0 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetInterestInitialDuration; // 0xd8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetInterestOnDamageDuration; // 0x100 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetInterestStartingMinDistance; // 0x128 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetInterestOngoingMinDistance; // 0x150 (Size: 0x28, Type: StructProperty)
    FScalableFloat TargetInterestCanBeTriggeredInsideLeash; // 0x178 (Size: 0x28, Type: StructProperty)
    float TargetInterestStartingMinDistanceSqr; // 0x1a0 (Size: 0x4, Type: FloatProperty)
    float TargetInterestOngoingMinDistanceSqr; // 0x1a4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1a8[0x8]; // 0x1a8 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat TargetReachabilityEnabled; // 0x1b0 (Size: 0x28, Type: StructProperty)
    FName TargetIsReachableKeyName; // 0x1d8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1dc[0x4]; // 0x1dc (Size: 0x4, Type: PaddingProperty)
    FScalableFloat TargetReachabilityMaxDistance; // 0x1e0 (Size: 0x28, Type: StructProperty)
    float TargetReachabilityMaxDistanceSqr; // 0x208 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_20c[0x14]; // 0x20c (Size: 0x14, Type: PaddingProperty)
    UFortAthenaLeashComponent* CachedLeashComponent; // 0x220 (Size: 0x8, Type: ObjectProperty)

private:
    void OnDamageReceived(AActor*& DamagedActor, float& Damage, AController*& InstigatedBy, AActor*& DamageCauser, FVector& HitLocation, UPrimitiveComponent*& FHitComponent, FName& BoneName, FVector& Momentum); // 0xeeb9f1c (Index: 0x0, Flags: Final|Native|Private|HasDefaults)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Disengagement) == 0x228, "Size mismatch for UFortAthenaAIBotEvaluator_Disengagement");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetActorKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetActorKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, DisengagementReasonKeyName) == 0xac, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::DisengagementReasonKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetInterestEnabled) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetInterestEnabled");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetInterestInitialDuration) == 0xd8, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetInterestInitialDuration");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetInterestOnDamageDuration) == 0x100, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetInterestOnDamageDuration");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetInterestStartingMinDistance) == 0x128, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetInterestStartingMinDistance");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetInterestOngoingMinDistance) == 0x150, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetInterestOngoingMinDistance");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetInterestCanBeTriggeredInsideLeash) == 0x178, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetInterestCanBeTriggeredInsideLeash");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetInterestStartingMinDistanceSqr) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetInterestStartingMinDistanceSqr");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetInterestOngoingMinDistanceSqr) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetInterestOngoingMinDistanceSqr");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetReachabilityEnabled) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetReachabilityEnabled");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetIsReachableKeyName) == 0x1d8, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetIsReachableKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetReachabilityMaxDistance) == 0x1e0, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetReachabilityMaxDistance");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, TargetReachabilityMaxDistanceSqr) == 0x208, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::TargetReachabilityMaxDistanceSqr");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Disengagement, CachedLeashComponent) == 0x220, "Offset mismatch for UFortAthenaAIBotEvaluator_Disengagement::CachedLeashComponent");

// Size: 0x340 (Inherited: 0x3f0, Single: 0xffffff50)
class UFortAthenaAIBotEvaluator_Harvest : public UFortAthenaAIBotEvaluator_Movement
{
public:
    uint8_t Pad_1a0[0x50]; // 0x1a0 (Size: 0x50, Type: PaddingProperty)
    UClass* ProjectionNavigationQueryFilterClass; // 0x1f0 (Size: 0x8, Type: ClassProperty)
    UClass* ValidNavigationQueryFilterClassOverride; // 0x1f8 (Size: 0x8, Type: ClassProperty)
    FScalableFloat MaximumTimeToHelpFromLastPlayerDamage; // 0x200 (Size: 0x28, Type: StructProperty)
    FScalableFloat KeepTargetTimeOnWeaponTrigger; // 0x228 (Size: 0x28, Type: StructProperty)
    FScalableFloat AmountOfTimesPlayerBuiltStructuresNeedToBeDamaged; // 0x250 (Size: 0x28, Type: StructProperty)
    FScalableFloat TimeToTrackDamagedActors; // 0x278 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxDistanceFromActorForFallbackNoHarvestBehaviour; // 0x2a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ExtraExtentForPlayerHitChecks; // 0x2c8 (Size: 0x28, Type: StructProperty)
    TArray<UClass*> GEsToApplyOnFallbackBehaviorTrigger; // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> GEsToApplyOnCannotDamageBehaviorTrigger; // 0x300 (Size: 0x10, Type: ArrayProperty)
    FName HarvestTargetKeyName; // 0x310 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_314[0x4]; // 0x314 (Size: 0x4, Type: PaddingProperty)
    FName HarvestTargetHitPointKeyName; // 0x318 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_31c[0x4]; // 0x31c (Size: 0x4, Type: PaddingProperty)
    FName HarvestDestinationKeyName; // 0x320 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_324[0x4]; // 0x324 (Size: 0x4, Type: PaddingProperty)
    FName FallbackBehaviorKeyName; // 0x328 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_32c[0x4]; // 0x32c (Size: 0x4, Type: PaddingProperty)
    FName CannotDamageKeyName; // 0x330 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_334[0x4]; // 0x334 (Size: 0x4, Type: PaddingProperty)
    FName WeaponTriggerMeleeKeyName; // 0x338 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_33c[0x4]; // 0x33c (Size: 0x4, Type: PaddingProperty)

protected:
    void HandleConverted(AFortPawn*& const InstigatorPawn, AFortPawn*& const ConvertedPawn); // 0xeeb9b18 (Index: 0x0, Flags: Final|Native|Protected)
    void HandleUnconverted(AFortPawn*& const UnconvertedPawn, EUnconvertReason& UnconvertReason); // 0xeeb9d1c (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Harvest) == 0x340, "Size mismatch for UFortAthenaAIBotEvaluator_Harvest");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, ProjectionNavigationQueryFilterClass) == 0x1f0, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::ProjectionNavigationQueryFilterClass");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, ValidNavigationQueryFilterClassOverride) == 0x1f8, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::ValidNavigationQueryFilterClassOverride");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, MaximumTimeToHelpFromLastPlayerDamage) == 0x200, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::MaximumTimeToHelpFromLastPlayerDamage");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, KeepTargetTimeOnWeaponTrigger) == 0x228, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::KeepTargetTimeOnWeaponTrigger");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, AmountOfTimesPlayerBuiltStructuresNeedToBeDamaged) == 0x250, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::AmountOfTimesPlayerBuiltStructuresNeedToBeDamaged");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, TimeToTrackDamagedActors) == 0x278, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::TimeToTrackDamagedActors");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, MaxDistanceFromActorForFallbackNoHarvestBehaviour) == 0x2a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::MaxDistanceFromActorForFallbackNoHarvestBehaviour");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, ExtraExtentForPlayerHitChecks) == 0x2c8, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::ExtraExtentForPlayerHitChecks");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, GEsToApplyOnFallbackBehaviorTrigger) == 0x2f0, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::GEsToApplyOnFallbackBehaviorTrigger");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, GEsToApplyOnCannotDamageBehaviorTrigger) == 0x300, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::GEsToApplyOnCannotDamageBehaviorTrigger");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, HarvestTargetKeyName) == 0x310, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::HarvestTargetKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, HarvestTargetHitPointKeyName) == 0x318, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::HarvestTargetHitPointKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, HarvestDestinationKeyName) == 0x320, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::HarvestDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, FallbackBehaviorKeyName) == 0x328, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::FallbackBehaviorKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, CannotDamageKeyName) == 0x330, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::CannotDamageKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Harvest, WeaponTriggerMeleeKeyName) == 0x338, "Offset mismatch for UFortAthenaAIBotEvaluator_Harvest::WeaponTriggerMeleeKeyName");

// Size: 0x2a8 (Inherited: 0x3f0, Single: 0xfffffeb8)
class UFortAthenaAIBotEvaluator_MoveAway : public UFortAthenaAIBotEvaluator_Movement
{
public:
    uint8_t Pad_1a0[0x70]; // 0x1a0 (Size: 0x70, Type: PaddingProperty)
    FScalableFloat MaxSecondsToReactToBump; // 0x210 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxSecondsToReactToBox; // 0x238 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinSecondsBetweenInstantReactions; // 0x260 (Size: 0x28, Type: StructProperty)
    UEnvQuery* FindAwayLocationFromPawnQueryTemplate; // 0x288 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EEnvQueryRunMode> FindAwayLocationFromPawnRunMode; // 0x290 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_291[0x7]; // 0x291 (Size: 0x7, Type: PaddingProperty)
    UEnvQuery* FindAwayLocationFromBoxQueryTemplate; // 0x298 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EEnvQueryRunMode> FindAwayLocationFromBoxRunMode; // 0x2a0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_2a1[0x7]; // 0x2a1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_MoveAway) == 0x2a8, "Size mismatch for UFortAthenaAIBotEvaluator_MoveAway");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MoveAway, MaxSecondsToReactToBump) == 0x210, "Offset mismatch for UFortAthenaAIBotEvaluator_MoveAway::MaxSecondsToReactToBump");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MoveAway, MaxSecondsToReactToBox) == 0x238, "Offset mismatch for UFortAthenaAIBotEvaluator_MoveAway::MaxSecondsToReactToBox");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MoveAway, MinSecondsBetweenInstantReactions) == 0x260, "Offset mismatch for UFortAthenaAIBotEvaluator_MoveAway::MinSecondsBetweenInstantReactions");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MoveAway, FindAwayLocationFromPawnQueryTemplate) == 0x288, "Offset mismatch for UFortAthenaAIBotEvaluator_MoveAway::FindAwayLocationFromPawnQueryTemplate");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MoveAway, FindAwayLocationFromPawnRunMode) == 0x290, "Offset mismatch for UFortAthenaAIBotEvaluator_MoveAway::FindAwayLocationFromPawnRunMode");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MoveAway, FindAwayLocationFromBoxQueryTemplate) == 0x298, "Offset mismatch for UFortAthenaAIBotEvaluator_MoveAway::FindAwayLocationFromBoxQueryTemplate");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MoveAway, FindAwayLocationFromBoxRunMode) == 0x2a0, "Offset mismatch for UFortAthenaAIBotEvaluator_MoveAway::FindAwayLocationFromBoxRunMode");

// Size: 0x240 (Inherited: 0x3f0, Single: 0xfffffe50)
class UFortAthenaAIBotEvaluator_SmartObjectCommand : public UFortAthenaAIBotEvaluator_Movement
{
public:
    UFortAthenaAIRuntimeParameters_SmartObjectBase* SmartObjectRuntimeParameters; // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    USmartObjectSubsystem* SmartObjectSubsystem; // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1b0[0x8]; // 0x1b0 (Size: 0x8, Type: PaddingProperty)
    FFortAIActiveCommandSOUsageData RunningCommandData; // 0x1b8 (Size: 0x10, Type: StructProperty)
    FBotEvaluatorCommandCooldown CommandOnCooldown; // 0x1c8 (Size: 0x14, Type: StructProperty)
    FGameplayTag EvaluationTag; // 0x1dc (Size: 0x4, Type: StructProperty)
    bool bEvaluateSOValidityAfterChosen; // 0x1e0 (Size: 0x1, Type: BoolProperty)
    bool bEnableEntryLocationsSupport; // 0x1e1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1e2[0x6]; // 0x1e2 (Size: 0x6, Type: PaddingProperty)
    FScalableFloat SingleCommandCooldown; // 0x1e8 (Size: 0x28, Type: StructProperty)
    UClass* OverridenFilterClassForEntryPoints; // 0x210 (Size: 0x8, Type: ClassProperty)
    FName SmartObjectExecutionStatusKeyName; // 0x218 (Size: 0x4, Type: NameProperty)
    FName SmartObjectMovementStateKeyName; // 0x21c (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationKeyName; // 0x220 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationRotationKeyName; // 0x224 (Size: 0x4, Type: NameProperty)
    FName SmartObjectShouldMoveKeyName; // 0x228 (Size: 0x4, Type: NameProperty)
    FName SmartObjectUrgencyKeyName; // 0x22c (Size: 0x4, Type: NameProperty)
    uint8_t Pad_230[0x10]; // 0x230 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_SmartObjectCommand) == 0x240, "Size mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, SmartObjectRuntimeParameters) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::SmartObjectRuntimeParameters");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, SmartObjectSubsystem) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::SmartObjectSubsystem");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, RunningCommandData) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::RunningCommandData");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, CommandOnCooldown) == 0x1c8, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::CommandOnCooldown");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, EvaluationTag) == 0x1dc, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::EvaluationTag");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, bEvaluateSOValidityAfterChosen) == 0x1e0, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::bEvaluateSOValidityAfterChosen");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, bEnableEntryLocationsSupport) == 0x1e1, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::bEnableEntryLocationsSupport");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, SingleCommandCooldown) == 0x1e8, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::SingleCommandCooldown");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, OverridenFilterClassForEntryPoints) == 0x210, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::OverridenFilterClassForEntryPoints");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, SmartObjectExecutionStatusKeyName) == 0x218, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::SmartObjectExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, SmartObjectMovementStateKeyName) == 0x21c, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::SmartObjectMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, SmartObjectDestinationKeyName) == 0x220, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::SmartObjectDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, SmartObjectDestinationRotationKeyName) == 0x224, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::SmartObjectDestinationRotationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, SmartObjectShouldMoveKeyName) == 0x228, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::SmartObjectShouldMoveKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectCommand, SmartObjectUrgencyKeyName) == 0x22c, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectCommand::SmartObjectUrgencyKeyName");

// Size: 0x1f8 (Inherited: 0x3f0, Single: 0xfffffe08)
class UFortAthenaAIBotEvaluator_SmartObjectConverted : public UFortAthenaAIBotEvaluator_Movement
{
public:
    UFortAthenaAIRuntimeParameters_SmartObjectBase* SmartObjectRuntimeParameters; // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    USmartObjectSubsystem* SmartObjectSubsystem; // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1b0[0x8]; // 0x1b0 (Size: 0x8, Type: PaddingProperty)
    FBotEvaluatorSmartObjectConvertedData RunningData; // 0x1b8 (Size: 0x8, Type: StructProperty)
    FGameplayTag EvaluationTag; // 0x1c0 (Size: 0x4, Type: StructProperty)
    bool bEvaluateSOValidityAfterChosen; // 0x1c4 (Size: 0x1, Type: BoolProperty)
    bool bEnableEntryLocationsSupport; // 0x1c5 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreCooldowns; // 0x1c6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1c7[0x1]; // 0x1c7 (Size: 0x1, Type: PaddingProperty)
    UClass* OverridenFilterClassForEntryPoints; // 0x1c8 (Size: 0x8, Type: ClassProperty)
    FName SmartObjectExecutionStatusKeyName; // 0x1d0 (Size: 0x4, Type: NameProperty)
    FName SmartObjectMovementStateKeyName; // 0x1d4 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationKeyName; // 0x1d8 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationRotationKeyName; // 0x1dc (Size: 0x4, Type: NameProperty)
    FName SmartObjectShouldMoveKeyName; // 0x1e0 (Size: 0x4, Type: NameProperty)
    FName SmartObjectUrgencyKeyName; // 0x1e4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1e8[0x10]; // 0x1e8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_SmartObjectConverted) == 0x1f8, "Size mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, SmartObjectRuntimeParameters) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::SmartObjectRuntimeParameters");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, SmartObjectSubsystem) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::SmartObjectSubsystem");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, RunningData) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::RunningData");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, EvaluationTag) == 0x1c0, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::EvaluationTag");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, bEvaluateSOValidityAfterChosen) == 0x1c4, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::bEvaluateSOValidityAfterChosen");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, bEnableEntryLocationsSupport) == 0x1c5, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::bEnableEntryLocationsSupport");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, bIgnoreCooldowns) == 0x1c6, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::bIgnoreCooldowns");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, OverridenFilterClassForEntryPoints) == 0x1c8, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::OverridenFilterClassForEntryPoints");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, SmartObjectExecutionStatusKeyName) == 0x1d0, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::SmartObjectExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, SmartObjectMovementStateKeyName) == 0x1d4, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::SmartObjectMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, SmartObjectDestinationKeyName) == 0x1d8, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::SmartObjectDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, SmartObjectDestinationRotationKeyName) == 0x1dc, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::SmartObjectDestinationRotationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, SmartObjectShouldMoveKeyName) == 0x1e0, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::SmartObjectShouldMoveKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjectConverted, SmartObjectUrgencyKeyName) == 0x1e4, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjectConverted::SmartObjectUrgencyKeyName");

// Size: 0x150 (Inherited: 0x170, Single: 0xffffffe0)
class UFortAthenaAIBotEvaluator_TargetContext : public UFortAthenaAIBotEvaluator
{
public:
    FGameplayTagQuery TokenPositionTagQuery; // 0xa8 (Size: 0x48, Type: StructProperty)
    FName TargetContextReachableKeyName; // 0xf0 (Size: 0x4, Type: NameProperty)
    FName TargetContextReachableInStraightLineKeyName; // 0xf4 (Size: 0x4, Type: NameProperty)
    FName TargetContextInsideLeashKeyName; // 0xf8 (Size: 0x4, Type: NameProperty)
    FName TargetContextLeashExitTimeKeyName; // 0xfc (Size: 0x4, Type: NameProperty)
    FName TargetActorName; // 0x100 (Size: 0x4, Type: NameProperty)
    FName LastRangedWeaponFireAbilityAgainstTimeKeyName; // 0x104 (Size: 0x4, Type: NameProperty)
    UFortAthenaLeashComponent* CachedLeashComponent; // 0x108 (Size: 0x8, Type: ObjectProperty)
    float HorizontalProjectionForReachability; // 0x110 (Size: 0x4, Type: FloatProperty)
    float VerticalProjectionForReachability; // 0x114 (Size: 0x4, Type: FloatProperty)
    FValueOrBBKey_Float TimeToConsiderUnreachable; // 0x118 (Size: 0xc, Type: StructProperty)
    bool bUseTargetNavAgentLocation; // 0x124 (Size: 0x1, Type: BoolProperty)
    bool bTargetInterpenetrationTestEnabled; // 0x125 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_126[0x2]; // 0x126 (Size: 0x2, Type: PaddingProperty)
    FName TargetContextInterpenetratedKeyName; // 0x128 (Size: 0x4, Type: NameProperty)
    FName TargetContextInAirForAimingKeyName; // 0x12c (Size: 0x4, Type: NameProperty)
    uint8_t Pad_130[0x20]; // 0x130 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_TargetContext) == 0x150, "Size mismatch for UFortAthenaAIBotEvaluator_TargetContext");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, TokenPositionTagQuery) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::TokenPositionTagQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, TargetContextReachableKeyName) == 0xf0, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::TargetContextReachableKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, TargetContextReachableInStraightLineKeyName) == 0xf4, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::TargetContextReachableInStraightLineKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, TargetContextInsideLeashKeyName) == 0xf8, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::TargetContextInsideLeashKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, TargetContextLeashExitTimeKeyName) == 0xfc, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::TargetContextLeashExitTimeKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, TargetActorName) == 0x100, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::TargetActorName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, LastRangedWeaponFireAbilityAgainstTimeKeyName) == 0x104, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::LastRangedWeaponFireAbilityAgainstTimeKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, CachedLeashComponent) == 0x108, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::CachedLeashComponent");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, HorizontalProjectionForReachability) == 0x110, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::HorizontalProjectionForReachability");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, VerticalProjectionForReachability) == 0x114, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::VerticalProjectionForReachability");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, TimeToConsiderUnreachable) == 0x118, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::TimeToConsiderUnreachable");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, bUseTargetNavAgentLocation) == 0x124, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::bUseTargetNavAgentLocation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, bTargetInterpenetrationTestEnabled) == 0x125, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::bTargetInterpenetrationTestEnabled");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, TargetContextInterpenetratedKeyName) == 0x128, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::TargetContextInterpenetratedKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TargetContext, TargetContextInAirForAimingKeyName) == 0x12c, "Offset mismatch for UFortAthenaAIBotEvaluator_TargetContext::TargetContextInAirForAimingKeyName");

// Size: 0x2e0 (Inherited: 0x250, Single: 0x90)
class UFortAthenaAIBotEvaluator_TokenPosition : public UFortAthenaAIEvaluator_Movement
{
public:
    uint8_t Pad_188[0x10]; // 0x188 (Size: 0x10, Type: PaddingProperty)
    FName QueryResultKeyName; // 0x198 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_19c[0x4]; // 0x19c (Size: 0x4, Type: PaddingProperty)
    TArray<FPositioningEQS> EQSs; // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    float TokenPositionCooldown; // 0x1b0 (Size: 0x4, Type: FloatProperty)
    float TokenPositionCooldownVariation; // 0x1b4 (Size: 0x4, Type: FloatProperty)
    FValueOrBBKey_Float NewTokenPositionCooldown; // 0x1b8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float NewTokenPositionCooldownVariation; // 0x1c4 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float DistanceToleranceForReturningToPosition; // 0x1d0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool CanAcquirePositionInEnter; // 0x1dc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float DistanceForDestinationAsTarget; // 0x1e8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool DestinationAsTargetOnceOnly; // 0x1f4 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool CanAddNewPositionToProvider; // 0x200 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ShouldCheckIfPositionIsReachable; // 0x20c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float MarkPositionAsDeniedIfNoVisibilityOnTarget; // 0x218 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float AcceptableDistanceForReservation; // 0x224 (Size: 0xc, Type: StructProperty)
    FGameplayTagQuery GeneratedTokenPositionTagQuery; // 0x230 (Size: 0x48, Type: StructProperty)
    uint8_t Pad_278[0x38]; // 0x278 (Size: 0x38, Type: PaddingProperty)
    UFortAICombatTokenConsumerComponent* CachedTokenConsumerComponent; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFortAICombatTokenProviderComponent*> CachedTokenProviderComponent; // 0x2b8 (Size: 0x8, Type: WeakObjectProperty)
    int32_t RunningEQSRequestID; // 0x2c0 (Size: 0x4, Type: IntProperty)
    bool bPositionRequested; // 0x2c4 (Size: 0x1, Type: BoolProperty)
    bool bPositionAcquiredInEnter; // 0x2c5 (Size: 0x1, Type: BoolProperty)
    bool bMoveToTargetFinished; // 0x2c6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2c7[0x1]; // 0x2c7 (Size: 0x1, Type: PaddingProperty)
    float PositionAcquiredFromQueryTimestamp; // 0x2c8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2cc[0x8]; // 0x2cc (Size: 0x8, Type: PaddingProperty)
    FName WeaponKeyName; // 0x2d4 (Size: 0x4, Type: NameProperty)
    FName TargetActorName; // 0x2d8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_2dc[0x4]; // 0x2dc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_TokenPosition) == 0x2e0, "Size mismatch for UFortAthenaAIBotEvaluator_TokenPosition");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, QueryResultKeyName) == 0x198, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::QueryResultKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, EQSs) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::EQSs");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, TokenPositionCooldown) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::TokenPositionCooldown");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, TokenPositionCooldownVariation) == 0x1b4, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::TokenPositionCooldownVariation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, NewTokenPositionCooldown) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::NewTokenPositionCooldown");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, NewTokenPositionCooldownVariation) == 0x1c4, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::NewTokenPositionCooldownVariation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, DistanceToleranceForReturningToPosition) == 0x1d0, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::DistanceToleranceForReturningToPosition");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, CanAcquirePositionInEnter) == 0x1dc, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::CanAcquirePositionInEnter");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, DistanceForDestinationAsTarget) == 0x1e8, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::DistanceForDestinationAsTarget");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, DestinationAsTargetOnceOnly) == 0x1f4, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::DestinationAsTargetOnceOnly");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, CanAddNewPositionToProvider) == 0x200, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::CanAddNewPositionToProvider");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, ShouldCheckIfPositionIsReachable) == 0x20c, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::ShouldCheckIfPositionIsReachable");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, MarkPositionAsDeniedIfNoVisibilityOnTarget) == 0x218, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::MarkPositionAsDeniedIfNoVisibilityOnTarget");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, AcceptableDistanceForReservation) == 0x224, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::AcceptableDistanceForReservation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, GeneratedTokenPositionTagQuery) == 0x230, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::GeneratedTokenPositionTagQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, CachedTokenConsumerComponent) == 0x2b0, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::CachedTokenConsumerComponent");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, CachedTokenProviderComponent) == 0x2b8, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::CachedTokenProviderComponent");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, RunningEQSRequestID) == 0x2c0, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::RunningEQSRequestID");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, bPositionRequested) == 0x2c4, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::bPositionRequested");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, bPositionAcquiredInEnter) == 0x2c5, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::bPositionAcquiredInEnter");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, bMoveToTargetFinished) == 0x2c6, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::bMoveToTargetFinished");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, PositionAcquiredFromQueryTimestamp) == 0x2c8, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::PositionAcquiredFromQueryTimestamp");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, WeaponKeyName) == 0x2d4, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::WeaponKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TokenPosition, TargetActorName) == 0x2d8, "Offset mismatch for UFortAthenaAIBotEvaluator_TokenPosition::TargetActorName");

// Size: 0xa0 (Inherited: 0xc8, Single: 0xffffffd8)
class UFortAthenaAIEvaluator_AbovePhysicsObject : public UFortAthenaAIEvaluator
{
public:
};

static_assert(sizeof(UFortAthenaAIEvaluator_AbovePhysicsObject) == 0xa0, "Size mismatch for UFortAthenaAIEvaluator_AbovePhysicsObject");

// Size: 0x188 (Inherited: 0xc8, Single: 0xc0)
class UFortAthenaAIEvaluator_LookAt : public UFortAthenaAIEvaluator
{
public:
    TArray<FFortAthenaAIEvaluator_LookAt_PawnConfiguration> PawnConfigurations; // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortAthenaAIEvaluator_LookAt_SOConfiguration> SOConfigurations; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    UCurveFloat* UtilityWeightBaseDistanceCurve; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* UtilityWeightBaseDotCurve; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    TArray<FName> ExecutionStatusesToCheckForNonPendingNames; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_e0[0x10]; // 0xe0 (Size: 0x10, Type: PaddingProperty)
    bool bForceEvaluationOnNearbyPawnChange; // 0xf0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f1[0x97]; // 0xf1 (Size: 0x97, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIEvaluator_LookAt) == 0x188, "Size mismatch for UFortAthenaAIEvaluator_LookAt");
static_assert(offsetof(UFortAthenaAIEvaluator_LookAt, PawnConfigurations) == 0xa0, "Offset mismatch for UFortAthenaAIEvaluator_LookAt::PawnConfigurations");
static_assert(offsetof(UFortAthenaAIEvaluator_LookAt, SOConfigurations) == 0xb0, "Offset mismatch for UFortAthenaAIEvaluator_LookAt::SOConfigurations");
static_assert(offsetof(UFortAthenaAIEvaluator_LookAt, UtilityWeightBaseDistanceCurve) == 0xc0, "Offset mismatch for UFortAthenaAIEvaluator_LookAt::UtilityWeightBaseDistanceCurve");
static_assert(offsetof(UFortAthenaAIEvaluator_LookAt, UtilityWeightBaseDotCurve) == 0xc8, "Offset mismatch for UFortAthenaAIEvaluator_LookAt::UtilityWeightBaseDotCurve");
static_assert(offsetof(UFortAthenaAIEvaluator_LookAt, ExecutionStatusesToCheckForNonPendingNames) == 0xd0, "Offset mismatch for UFortAthenaAIEvaluator_LookAt::ExecutionStatusesToCheckForNonPendingNames");
static_assert(offsetof(UFortAthenaAIEvaluator_LookAt, bForceEvaluationOnNearbyPawnChange) == 0xf0, "Offset mismatch for UFortAthenaAIEvaluator_LookAt::bForceEvaluationOnNearbyPawnChange");

// Size: 0xf0 (Inherited: 0x118, Single: 0xffffffd8)
class UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask : public UStateTreeTaskBlueprintBase
{
public:
    AActor* SmartObjectActor; // 0x80 (Size: 0x8, Type: ObjectProperty)
    AActor* Actor; // 0x88 (Size: 0x8, Type: ObjectProperty)
    FSoftDataRegistryOrTable UIOptionsDataTable; // 0x90 (Size: 0x30, Type: StructProperty)
    FFortUISmartObjectUIPayloadOptions UIOptions; // 0xc0 (Size: 0x18, Type: StructProperty)
    FFortUISmartObjectUIPayloadOptions UIOptionsResult; // 0xd8 (Size: 0x18, Type: StructProperty)

public:
    virtual FFortUISmartObjectUIPayloadOptions GenerateOptions(); // 0xeeb9aa0 (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent)
    FFortUISmartObjectUIPayloadOptions GetInitialUIPayloadOptions() const; // 0xeeb9adc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask) == 0xf0, "Size mismatch for UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask");
static_assert(offsetof(UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask, SmartObjectActor) == 0x80, "Offset mismatch for UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask::SmartObjectActor");
static_assert(offsetof(UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask, Actor) == 0x88, "Offset mismatch for UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask::Actor");
static_assert(offsetof(UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask, UIOptionsDataTable) == 0x90, "Offset mismatch for UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask::UIOptionsDataTable");
static_assert(offsetof(UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask, UIOptions) == 0xc0, "Offset mismatch for UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask::UIOptions");
static_assert(offsetof(UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask, UIOptionsResult) == 0xd8, "Offset mismatch for UFortAthenaBPDynamicOptionsSmartObjectUIStateTreeTask::UIOptionsResult");

// Size: 0x88 (Inherited: 0x150, Single: 0xffffff38)
class UFortAthenaBTService_ApplySkillSet : public UBTService
{
public:
    FValueOrBBKey_Class SkillSetClass; // 0x70 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UFortAthenaBTService_ApplySkillSet) == 0x88, "Size mismatch for UFortAthenaBTService_ApplySkillSet");
static_assert(offsetof(UFortAthenaBTService_ApplySkillSet, SkillSetClass) == 0x70, "Offset mismatch for UFortAthenaBTService_ApplySkillSet::SkillSetClass");

// Size: 0xe0 (Inherited: 0x150, Single: 0xffffff90)
class UFortAthenaBTService_ModifyTokenNumber : public UBTService
{
public:
    FGameplayTagQuery TokenTagQuery; // 0x70 (Size: 0x48, Type: StructProperty)
    FScalableFloat NewTokenAmount; // 0xb8 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UFortAthenaBTService_ModifyTokenNumber) == 0xe0, "Size mismatch for UFortAthenaBTService_ModifyTokenNumber");
static_assert(offsetof(UFortAthenaBTService_ModifyTokenNumber, TokenTagQuery) == 0x70, "Offset mismatch for UFortAthenaBTService_ModifyTokenNumber::TokenTagQuery");
static_assert(offsetof(UFortAthenaBTService_ModifyTokenNumber, NewTokenAmount) == 0xb8, "Offset mismatch for UFortAthenaBTService_ModifyTokenNumber::NewTokenAmount");

// Size: 0x98 (Inherited: 0x150, Single: 0xffffff48)
class UFortAthenaBTService_ModulateSpeedOnDistance : public UBTService
{
public:
    FName TooFarFromLeaderKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName FollowGroupLeaderDestinationKeyName; // 0x74 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_78[0x4]; // 0x78 (Size: 0x4, Type: PaddingProperty)
    FValueOrBBKey_Float TargetSpeed; // 0x7c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float MaxSpeed; // 0x88 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_ModulateSpeedOnDistance) == 0x98, "Size mismatch for UFortAthenaBTService_ModulateSpeedOnDistance");
static_assert(offsetof(UFortAthenaBTService_ModulateSpeedOnDistance, TooFarFromLeaderKeyName) == 0x70, "Offset mismatch for UFortAthenaBTService_ModulateSpeedOnDistance::TooFarFromLeaderKeyName");
static_assert(offsetof(UFortAthenaBTService_ModulateSpeedOnDistance, FollowGroupLeaderDestinationKeyName) == 0x74, "Offset mismatch for UFortAthenaBTService_ModulateSpeedOnDistance::FollowGroupLeaderDestinationKeyName");
static_assert(offsetof(UFortAthenaBTService_ModulateSpeedOnDistance, TargetSpeed) == 0x7c, "Offset mismatch for UFortAthenaBTService_ModulateSpeedOnDistance::TargetSpeed");
static_assert(offsetof(UFortAthenaBTService_ModulateSpeedOnDistance, MaxSpeed) == 0x88, "Offset mismatch for UFortAthenaBTService_ModulateSpeedOnDistance::MaxSpeed");

// Size: 0x140 (Inherited: 0x150, Single: 0xfffffff0)
class UFortAthenaBTService_MovementStyle : public UBTService
{
public:
    TEnumAsByte<EFortMovementStyle> MovementStyle; // 0x70 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
    FValueOrBBKey_Enum NewMovementStyle; // 0x78 (Size: 0x28, Type: StructProperty)
    FGameplayTagQuery TagCondition; // 0xa0 (Size: 0x48, Type: StructProperty)
    FBlackboardKeySelector BlackboardCondition; // 0xe8 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Bool InvertBlackboardCondition; // 0x110 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_11c[0x24]; // 0x11c (Size: 0x24, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_MovementStyle) == 0x140, "Size mismatch for UFortAthenaBTService_MovementStyle");
static_assert(offsetof(UFortAthenaBTService_MovementStyle, MovementStyle) == 0x70, "Offset mismatch for UFortAthenaBTService_MovementStyle::MovementStyle");
static_assert(offsetof(UFortAthenaBTService_MovementStyle, NewMovementStyle) == 0x78, "Offset mismatch for UFortAthenaBTService_MovementStyle::NewMovementStyle");
static_assert(offsetof(UFortAthenaBTService_MovementStyle, TagCondition) == 0xa0, "Offset mismatch for UFortAthenaBTService_MovementStyle::TagCondition");
static_assert(offsetof(UFortAthenaBTService_MovementStyle, BlackboardCondition) == 0xe8, "Offset mismatch for UFortAthenaBTService_MovementStyle::BlackboardCondition");
static_assert(offsetof(UFortAthenaBTService_MovementStyle, InvertBlackboardCondition) == 0x110, "Offset mismatch for UFortAthenaBTService_MovementStyle::InvertBlackboardCondition");

// Size: 0x80 (Inherited: 0x150, Single: 0xffffff30)
class UFortAthenaBTService_SetInTacticalAction : public UBTService
{
public:
    FValueOrBBKey_Bool ShouldSetInTacticalAction; // 0x70 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_SetInTacticalAction) == 0x80, "Size mismatch for UFortAthenaBTService_SetInTacticalAction");
static_assert(offsetof(UFortAthenaBTService_SetInTacticalAction, ShouldSetInTacticalAction) == 0x70, "Offset mismatch for UFortAthenaBTService_SetInTacticalAction::ShouldSetInTacticalAction");

// Size: 0xd8 (Inherited: 0x150, Single: 0xffffff88)
class UFortAthenaBTService_TokenQuery : public UBTService
{
public:
    TArray<FEquippedItemTagAssociationData> EquippedItemTagAssociationDatas; // 0x70 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagQuery DefaultTokenSystemTagQuery; // 0x80 (Size: 0x48, Type: StructProperty)
    uint8_t BecomeRelevantTokenAction; // 0xc8 (Size: 0x1, Type: EnumProperty)
    uint8_t CeaseRelevantTokenAction; // 0xc9 (Size: 0x1, Type: EnumProperty)
    uint8_t WeaponChangeTokenAction; // 0xca (Size: 0x1, Type: EnumProperty)
    uint8_t TargetChangeTokenAction; // 0xcb (Size: 0x1, Type: EnumProperty)
    FName WeaponKeyName; // 0xcc (Size: 0x4, Type: NameProperty)
    FName TargetActorName; // 0xd0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_TokenQuery) == 0xd8, "Size mismatch for UFortAthenaBTService_TokenQuery");
static_assert(offsetof(UFortAthenaBTService_TokenQuery, EquippedItemTagAssociationDatas) == 0x70, "Offset mismatch for UFortAthenaBTService_TokenQuery::EquippedItemTagAssociationDatas");
static_assert(offsetof(UFortAthenaBTService_TokenQuery, DefaultTokenSystemTagQuery) == 0x80, "Offset mismatch for UFortAthenaBTService_TokenQuery::DefaultTokenSystemTagQuery");
static_assert(offsetof(UFortAthenaBTService_TokenQuery, BecomeRelevantTokenAction) == 0xc8, "Offset mismatch for UFortAthenaBTService_TokenQuery::BecomeRelevantTokenAction");
static_assert(offsetof(UFortAthenaBTService_TokenQuery, CeaseRelevantTokenAction) == 0xc9, "Offset mismatch for UFortAthenaBTService_TokenQuery::CeaseRelevantTokenAction");
static_assert(offsetof(UFortAthenaBTService_TokenQuery, WeaponChangeTokenAction) == 0xca, "Offset mismatch for UFortAthenaBTService_TokenQuery::WeaponChangeTokenAction");
static_assert(offsetof(UFortAthenaBTService_TokenQuery, TargetChangeTokenAction) == 0xcb, "Offset mismatch for UFortAthenaBTService_TokenQuery::TargetChangeTokenAction");
static_assert(offsetof(UFortAthenaBTService_TokenQuery, WeaponKeyName) == 0xcc, "Offset mismatch for UFortAthenaBTService_TokenQuery::WeaponKeyName");
static_assert(offsetof(UFortAthenaBTService_TokenQuery, TargetActorName) == 0xd0, "Offset mismatch for UFortAthenaBTService_TokenQuery::TargetActorName");

// Size: 0x50 (Inherited: 0x60, Single: 0xfffffff0)
class UFortBTWorldConditionSchema : public UWorldConditionSchema
{
public:
};

static_assert(sizeof(UFortBTWorldConditionSchema) == 0x50, "Size mismatch for UFortBTWorldConditionSchema");

// Size: 0xe0 (Inherited: 0x150, Single: 0xffffff90)
class UFortAthenaBTService_WorldCondition : public UBTService
{
public:
    FWorldConditionQueryDefinition Conditions; // 0x70 (Size: 0x18, Type: StructProperty)
    FName ConditionsResultName; // 0x88 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
    FWorldConditionQueryState QueryState; // 0x90 (Size: 0x30, Type: StructProperty)
    AAIController* CachedOwnerController; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    AActor* CachedOwnerPawn; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d0[0x10]; // 0xd0 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_WorldCondition) == 0xe0, "Size mismatch for UFortAthenaBTService_WorldCondition");
static_assert(offsetof(UFortAthenaBTService_WorldCondition, Conditions) == 0x70, "Offset mismatch for UFortAthenaBTService_WorldCondition::Conditions");
static_assert(offsetof(UFortAthenaBTService_WorldCondition, ConditionsResultName) == 0x88, "Offset mismatch for UFortAthenaBTService_WorldCondition::ConditionsResultName");
static_assert(offsetof(UFortAthenaBTService_WorldCondition, QueryState) == 0x90, "Offset mismatch for UFortAthenaBTService_WorldCondition::QueryState");
static_assert(offsetof(UFortAthenaBTService_WorldCondition, CachedOwnerController) == 0xc0, "Offset mismatch for UFortAthenaBTService_WorldCondition::CachedOwnerController");
static_assert(offsetof(UFortAthenaBTService_WorldCondition, CachedOwnerPawn) == 0xc8, "Offset mismatch for UFortAthenaBTService_WorldCondition::CachedOwnerPawn");

// Size: 0x98 (Inherited: 0xf0, Single: 0xffffffa8)
class UFortAthenaBTTask_SetDefendSpotPenalized : public UBTTaskNode
{
public:
    FBlackboardKeySelector DefendSpotBlackboardKey; // 0x70 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UFortAthenaBTTask_SetDefendSpotPenalized) == 0x98, "Size mismatch for UFortAthenaBTTask_SetDefendSpotPenalized");
static_assert(offsetof(UFortAthenaBTTask_SetDefendSpotPenalized, DefendSpotBlackboardKey) == 0x70, "Offset mismatch for UFortAthenaBTTask_SetDefendSpotPenalized::DefendSpotBlackboardKey");

// Size: 0x98 (Inherited: 0xf0, Single: 0xffffffa8)
class UFortAthenaBTTask_SetDefendSpotReached : public UBTTaskNode
{
public:
    FBlackboardKeySelector DefendSpotBlackboardKey; // 0x70 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UFortAthenaBTTask_SetDefendSpotReached) == 0x98, "Size mismatch for UFortAthenaBTTask_SetDefendSpotReached");
static_assert(offsetof(UFortAthenaBTTask_SetDefendSpotReached, DefendSpotBlackboardKey) == 0x70, "Offset mismatch for UFortAthenaBTTask_SetDefendSpotReached::DefendSpotBlackboardKey");

// Size: 0xe8 (Inherited: 0xf0, Single: 0xfffffff8)
class UFortAthenaBTTask_GetDefendSpotShootSpot : public UBTTaskNode
{
public:
    FBlackboardKeySelector DefendSpotBlackboardKey; // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector ShootSpotPositionBlackboardKey; // 0x98 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector AllowCrouchBlackboardKey; // 0xc0 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UFortAthenaBTTask_GetDefendSpotShootSpot) == 0xe8, "Size mismatch for UFortAthenaBTTask_GetDefendSpotShootSpot");
static_assert(offsetof(UFortAthenaBTTask_GetDefendSpotShootSpot, DefendSpotBlackboardKey) == 0x70, "Offset mismatch for UFortAthenaBTTask_GetDefendSpotShootSpot::DefendSpotBlackboardKey");
static_assert(offsetof(UFortAthenaBTTask_GetDefendSpotShootSpot, ShootSpotPositionBlackboardKey) == 0x98, "Offset mismatch for UFortAthenaBTTask_GetDefendSpotShootSpot::ShootSpotPositionBlackboardKey");
static_assert(offsetof(UFortAthenaBTTask_GetDefendSpotShootSpot, AllowCrouchBlackboardKey) == 0xc0, "Offset mismatch for UFortAthenaBTTask_GetDefendSpotShootSpot::AllowCrouchBlackboardKey");

// Size: 0xc0 (Inherited: 0xf0, Single: 0xffffffd0)
class UFortAthenaBTTask_Harvest : public UBTTaskNode
{
public:
    FName HarvestExecutionStatusKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FName HarvestTargetKeyName; // 0x78 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
    FName HarvestTargetHitPointKeyName; // 0x80 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
    FName HarvestDestinationKeyName; // 0x88 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
    FName WeaponTriggerMeleeKeyName; // 0x90 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
    FScalableFloat MeleeSwingDelay; // 0x98 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UFortAthenaBTTask_Harvest) == 0xc0, "Size mismatch for UFortAthenaBTTask_Harvest");
static_assert(offsetof(UFortAthenaBTTask_Harvest, HarvestExecutionStatusKeyName) == 0x70, "Offset mismatch for UFortAthenaBTTask_Harvest::HarvestExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaBTTask_Harvest, HarvestTargetKeyName) == 0x78, "Offset mismatch for UFortAthenaBTTask_Harvest::HarvestTargetKeyName");
static_assert(offsetof(UFortAthenaBTTask_Harvest, HarvestTargetHitPointKeyName) == 0x80, "Offset mismatch for UFortAthenaBTTask_Harvest::HarvestTargetHitPointKeyName");
static_assert(offsetof(UFortAthenaBTTask_Harvest, HarvestDestinationKeyName) == 0x88, "Offset mismatch for UFortAthenaBTTask_Harvest::HarvestDestinationKeyName");
static_assert(offsetof(UFortAthenaBTTask_Harvest, WeaponTriggerMeleeKeyName) == 0x90, "Offset mismatch for UFortAthenaBTTask_Harvest::WeaponTriggerMeleeKeyName");
static_assert(offsetof(UFortAthenaBTTask_Harvest, MeleeSwingDelay) == 0x98, "Offset mismatch for UFortAthenaBTTask_Harvest::MeleeSwingDelay");

// Size: 0x88 (Inherited: 0xf0, Single: 0xffffff98)
class UFortAthenaBTTask_ReactToVerb : public UBTTaskNode
{
public:
    FName ReactToVerbTargetActorKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FName ReactToVerbExecutionStatusKeyName; // 0x78 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
    FName ExtraStructDataKeyName; // 0x80 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_ReactToVerb) == 0x88, "Size mismatch for UFortAthenaBTTask_ReactToVerb");
static_assert(offsetof(UFortAthenaBTTask_ReactToVerb, ReactToVerbTargetActorKeyName) == 0x70, "Offset mismatch for UFortAthenaBTTask_ReactToVerb::ReactToVerbTargetActorKeyName");
static_assert(offsetof(UFortAthenaBTTask_ReactToVerb, ReactToVerbExecutionStatusKeyName) == 0x78, "Offset mismatch for UFortAthenaBTTask_ReactToVerb::ReactToVerbExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaBTTask_ReactToVerb, ExtraStructDataKeyName) == 0x80, "Offset mismatch for UFortAthenaBTTask_ReactToVerb::ExtraStructDataKeyName");

// Size: 0x78 (Inherited: 0xf0, Single: 0xffffff88)
class UFortAthenaBTTask_VehicleSwitchSeat : public UBTTaskNode
{
public:
    TEnumAsByte<SwitchSeatType> SwitchSeatType; // 0x70 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_VehicleSwitchSeat) == 0x78, "Size mismatch for UFortAthenaBTTask_VehicleSwitchSeat");
static_assert(offsetof(UFortAthenaBTTask_VehicleSwitchSeat, SwitchSeatType) == 0x70, "Offset mismatch for UFortAthenaBTTask_VehicleSwitchSeat::SwitchSeatType");

// Size: 0x50 (Inherited: 0x60, Single: 0xfffffff0)
class UFortStateTreeConditionSchema : public UWorldConditionSchema
{
public:
};

static_assert(sizeof(UFortStateTreeConditionSchema) == 0x50, "Size mismatch for UFortStateTreeConditionSchema");

// Size: 0x70 (Inherited: 0x148, Single: 0xffffff28)
class UFortBTDecorator_AIBotVehicleSeatStatus : public UBTDecorator
{
public:
    TEnumAsByte<SeatStatusType> SeatType; // 0x68 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTDecorator_AIBotVehicleSeatStatus) == 0x70, "Size mismatch for UFortBTDecorator_AIBotVehicleSeatStatus");
static_assert(offsetof(UFortBTDecorator_AIBotVehicleSeatStatus, SeatType) == 0x68, "Offset mismatch for UFortBTDecorator_AIBotVehicleSeatStatus::SeatType");

// Size: 0xc0 (Inherited: 0x298, Single: 0xfffffe28)
class UFortBTDecorator_CanDoInjectedBehavior : public UBTDecorator_Blackboard
{
public:
};

static_assert(sizeof(UFortBTDecorator_CanDoInjectedBehavior) == 0xc0, "Size mismatch for UFortBTDecorator_CanDoInjectedBehavior");

// Size: 0xd0 (Inherited: 0x298, Single: 0xfffffe38)
class UFortBTDecorator_ExecutionStatus : public UBTDecorator_Blackboard
{
public:
    FValueOrBBKey_Bool ShouldUpdateExecutionStatus; // 0xc0 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTDecorator_ExecutionStatus) == 0xd0, "Size mismatch for UFortBTDecorator_ExecutionStatus");
static_assert(offsetof(UFortBTDecorator_ExecutionStatus, ShouldUpdateExecutionStatus) == 0xc0, "Offset mismatch for UFortBTDecorator_ExecutionStatus::ShouldUpdateExecutionStatus");

// Size: 0xd8 (Inherited: 0x1d8, Single: 0xffffff00)
class UFortBTDecorator_HasToken : public UBTDecorator_BlackboardBase
{
public:
    FGameplayTagQuery TokenQuery; // 0x90 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UFortBTDecorator_HasToken) == 0xd8, "Size mismatch for UFortBTDecorator_HasToken");
static_assert(offsetof(UFortBTDecorator_HasToken, TokenQuery) == 0x90, "Offset mismatch for UFortBTDecorator_HasToken::TokenQuery");

// Size: 0x88 (Inherited: 0x150, Single: 0xffffff38)
class UFortBTService_AIEvaluatorsInjector : public UBTService
{
public:
    TArray<FFortBTService_InjectionTagKey> InjectionTagsKeys; // 0x70 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_80[0x8]; // 0x80 (Size: 0x8, Type: PaddingProperty)

private:
    void OnPawnDied(AActor*& DamagedActor, float& Damage, AController*& InstigatedBy, AActor*& DamageCauser, FVector& HitLocation, UPrimitiveComponent*& FHitComponent, FName& BoneName, FVector& Momentum); // 0xeebc910 (Index: 0x0, Flags: Final|Native|Private|HasDefaults)
};

static_assert(sizeof(UFortBTService_AIEvaluatorsInjector) == 0x88, "Size mismatch for UFortBTService_AIEvaluatorsInjector");
static_assert(offsetof(UFortBTService_AIEvaluatorsInjector, InjectionTagsKeys) == 0x70, "Offset mismatch for UFortBTService_AIEvaluatorsInjector::InjectionTagsKeys");

// Size: 0x98 (Inherited: 0x150, Single: 0xffffff48)
class UFortBTService_ApplyGameplayEffect : public UBTService
{
public:
    FValueOrBBKey_Class GameplayEffectBehaviorValue; // 0x70 (Size: 0x18, Type: StructProperty)
    FValueOrBBKey_Float GameplayEffectLevel; // 0x88 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTService_ApplyGameplayEffect) == 0x98, "Size mismatch for UFortBTService_ApplyGameplayEffect");
static_assert(offsetof(UFortBTService_ApplyGameplayEffect, GameplayEffectBehaviorValue) == 0x70, "Offset mismatch for UFortBTService_ApplyGameplayEffect::GameplayEffectBehaviorValue");
static_assert(offsetof(UFortBTService_ApplyGameplayEffect, GameplayEffectLevel) == 0x88, "Offset mismatch for UFortBTService_ApplyGameplayEffect::GameplayEffectLevel");

// Size: 0x70 (Inherited: 0x150, Single: 0xffffff20)
class UFortBTService_ClearGoalAndAssignment : public UBTService
{
public:
};

static_assert(sizeof(UFortBTService_ClearGoalAndAssignment) == 0x70, "Size mismatch for UFortBTService_ClearGoalAndAssignment");

// Size: 0x70 (Inherited: 0xf0, Single: 0xffffff80)
class UFortBTTask_AlwaysSucceed : public UBTTaskNode
{
public:
};

static_assert(sizeof(UFortBTTask_AlwaysSucceed) == 0x70, "Size mismatch for UFortBTTask_AlwaysSucceed");

// Size: 0x70 (Inherited: 0xf0, Single: 0xffffff80)
class UFortBTTask_AlwaysFail : public UBTTaskNode
{
public:
};

static_assert(sizeof(UFortBTTask_AlwaysFail) == 0x70, "Size mismatch for UFortBTTask_AlwaysFail");

// Size: 0x70 (Inherited: 0xf0, Single: 0xffffff80)
class UFortBTTask_InProgress : public UBTTaskNode
{
public:
};

static_assert(sizeof(UFortBTTask_InProgress) == 0x70, "Size mismatch for UFortBTTask_InProgress");

// Size: 0x90 (Inherited: 0xf0, Single: 0xffffffa0)
class UFortBTTask_InjectionPoint : public UBTTaskNode
{
public:
    FGameplayTag InjectionTag; // 0x70 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FValueOrBBKey_Object InjectedAction; // 0x78 (Size: 0x18, Type: StructProperty)

public:
    void CreateAndBindActionObjectKey(); // 0x554e3c4 (Index: 0x0, Flags: Final|Native|Public)
    void CreateAndBindExecutionStatusKey(); // 0x554e3c4 (Index: 0x1, Flags: Final|Native|Public)
    void RefreshEditorWindow() const; // 0x554e3c4 (Index: 0x2, Flags: Final|Native|Public|Const)
};

static_assert(sizeof(UFortBTTask_InjectionPoint) == 0x90, "Size mismatch for UFortBTTask_InjectionPoint");
static_assert(offsetof(UFortBTTask_InjectionPoint, InjectionTag) == 0x70, "Offset mismatch for UFortBTTask_InjectionPoint::InjectionTag");
static_assert(offsetof(UFortBTTask_InjectionPoint, InjectedAction) == 0x78, "Offset mismatch for UFortBTTask_InjectionPoint::InjectedAction");

// Size: 0xb0 (Inherited: 0x188, Single: 0xffffff28)
class UFortBTTask_RandomInt : public UBTTask_BlackboardBase
{
public:
    FValueOrBBKey_Int32 MinimumValue; // 0x98 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Int32 MaximumValue; // 0xa4 (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(UFortBTTask_RandomInt) == 0xb0, "Size mismatch for UFortBTTask_RandomInt");
static_assert(offsetof(UFortBTTask_RandomInt, MinimumValue) == 0x98, "Offset mismatch for UFortBTTask_RandomInt::MinimumValue");
static_assert(offsetof(UFortBTTask_RandomInt, MaximumValue) == 0xa4, "Offset mismatch for UFortBTTask_RandomInt::MaximumValue");

// Size: 0x108 (Inherited: 0x178, Single: 0xffffff90)
class UFortEnvQueryGenerator_ActorsOfClass : public UEnvQueryGenerator_ActorsOfClass
{
public:
    FAIDataProviderBoolValue bRandomizeResults; // 0xd0 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortEnvQueryGenerator_ActorsOfClass) == 0x108, "Size mismatch for UFortEnvQueryGenerator_ActorsOfClass");
static_assert(offsetof(UFortEnvQueryGenerator_ActorsOfClass, bRandomizeResults) == 0xd0, "Offset mismatch for UFortEnvQueryGenerator_ActorsOfClass::bRandomizeResults");

// Size: 0x48 (Inherited: 0x88, Single: 0xffffffc0)
class UFortGameFeatureAction_AddInjectionSupportingBehavior : public UFortGameInstanceGameFeatureAction
{
public:
    TArray<TSoftObjectPtr<UBehaviorTree*>> InjectionSupportingBehaviors; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortGameFeatureAction_AddInjectionSupportingBehavior) == 0x48, "Size mismatch for UFortGameFeatureAction_AddInjectionSupportingBehavior");
static_assert(offsetof(UFortGameFeatureAction_AddInjectionSupportingBehavior, InjectionSupportingBehaviors) == 0x38, "Offset mismatch for UFortGameFeatureAction_AddInjectionSupportingBehavior::InjectionSupportingBehaviors");

// Size: 0x48 (Inherited: 0x88, Single: 0xffffffc0)
class UFortGameFeatureAction_InjectAIBehavior : public UFortGameInstanceGameFeatureAction
{
public:
    TArray<FFortAISpawnerTagQueryInjectedBehavior> InjectedBehaviors; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortGameFeatureAction_InjectAIBehavior) == 0x48, "Size mismatch for UFortGameFeatureAction_InjectAIBehavior");
static_assert(offsetof(UFortGameFeatureAction_InjectAIBehavior, InjectedBehaviors) == 0x38, "Offset mismatch for UFortGameFeatureAction_InjectAIBehavior::InjectedBehaviors");

// Size: 0x108 (Inherited: 0x308, Single: 0xfffffe00)
class UFortInjectedBehaviorsComponent : public UFortGameStateComponent
{
public:
};

static_assert(sizeof(UFortInjectedBehaviorsComponent) == 0x108, "Size mismatch for UFortInjectedBehaviorsComponent");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UFortQueryContext_ClosestLocationInsideLeash : public UEnvQueryContext
{
public:
    UClass* NavFilterClass; // 0x28 (Size: 0x8, Type: ClassProperty)
    bool bUseInnerRadius; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bForcePositionOnLeash; // 0x31 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x6]; // 0x32 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryContext_ClosestLocationInsideLeash) == 0x38, "Size mismatch for UFortQueryContext_ClosestLocationInsideLeash");
static_assert(offsetof(UFortQueryContext_ClosestLocationInsideLeash, NavFilterClass) == 0x28, "Offset mismatch for UFortQueryContext_ClosestLocationInsideLeash::NavFilterClass");
static_assert(offsetof(UFortQueryContext_ClosestLocationInsideLeash, bUseInnerRadius) == 0x30, "Offset mismatch for UFortQueryContext_ClosestLocationInsideLeash::bUseInnerRadius");
static_assert(offsetof(UFortQueryContext_ClosestLocationInsideLeash, bForcePositionOnLeash) == 0x31, "Offset mismatch for UFortQueryContext_ClosestLocationInsideLeash::bForcePositionOnLeash");

// Size: 0x50 (Inherited: 0x50, Single: 0x0)
class UFortQueryContext_NearbyFactionMembers : public UEnvQueryContext
{
public:
    FScalableFloat NearbyFactionMemberDistance; // 0x28 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UFortQueryContext_NearbyFactionMembers) == 0x50, "Size mismatch for UFortQueryContext_NearbyFactionMembers");
static_assert(offsetof(UFortQueryContext_NearbyFactionMembers, NearbyFactionMemberDistance) == 0x28, "Offset mismatch for UFortQueryContext_NearbyFactionMembers::NearbyFactionMemberDistance");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UFortQueryContext_PlayspaceVolume : public UEnvQueryContext
{
public:
    UClass* QueryActorContext; // 0x28 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryContext_PlayspaceVolume) == 0x30, "Size mismatch for UFortQueryContext_PlayspaceVolume");
static_assert(offsetof(UFortQueryContext_PlayspaceVolume, QueryActorContext) == 0x28, "Offset mismatch for UFortQueryContext_PlayspaceVolume::QueryActorContext");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_QuerierController : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_QuerierController) == 0x28, "Size mismatch for UFortQueryContext_QuerierController");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UFortQueryContext_TokenReservedPosition : public UEnvQueryContext
{
public:
    UClass* TokenProviderContext; // 0x28 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryContext_TokenReservedPosition) == 0x30, "Size mismatch for UFortQueryContext_TokenReservedPosition");
static_assert(offsetof(UFortQueryContext_TokenReservedPosition, TokenProviderContext) == 0x28, "Offset mismatch for UFortQueryContext_TokenReservedPosition::TokenProviderContext");

// Size: 0x58 (Inherited: 0xa8, Single: 0xffffffb0)
class UFortQueryGenerator_CoverPositionProvider : public UEnvQueryGenerator
{
public:
    UClass* CoverPositionProviderContext; // 0x50 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_CoverPositionProvider) == 0x58, "Size mismatch for UFortQueryGenerator_CoverPositionProvider");
static_assert(offsetof(UFortQueryGenerator_CoverPositionProvider, CoverPositionProviderContext) == 0x50, "Offset mismatch for UFortQueryGenerator_CoverPositionProvider::CoverPositionProviderContext");

// Size: 0x50 (Inherited: 0xa8, Single: 0xffffffa8)
class UFortQueryGenerator_DefendSpots : public UEnvQueryGenerator
{
public:
};

static_assert(sizeof(UFortQueryGenerator_DefendSpots) == 0x50, "Size mismatch for UFortQueryGenerator_DefendSpots");

// Size: 0x160 (Inherited: 0xa8, Single: 0xb8)
class UFortQueryGenerator_Floodfill : public UEnvQueryGenerator
{
public:
    UClass* CenterContext; // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderIntValue MaximumNodeSearchProvider; // 0x58 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaximumSearchRadiusProvider; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue PointDensityProvider; // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue MaximumNumberOfPointProvider; // 0x100 (Size: 0x38, Type: StructProperty)
    UClass* FilterOverride; // 0x138 (Size: 0x8, Type: ClassProperty)
    FVector ProjectExtent; // 0x140 (Size: 0x18, Type: StructProperty)
    FNavigationFilterFlags ExtraExcludeFlags; // 0x158 (Size: 0x4, Type: StructProperty)
    uint8_t Behavior[0x4]; // 0x15c (Size: 0x4, Type: EnumProperty)
};

static_assert(sizeof(UFortQueryGenerator_Floodfill) == 0x160, "Size mismatch for UFortQueryGenerator_Floodfill");
static_assert(offsetof(UFortQueryGenerator_Floodfill, CenterContext) == 0x50, "Offset mismatch for UFortQueryGenerator_Floodfill::CenterContext");
static_assert(offsetof(UFortQueryGenerator_Floodfill, MaximumNodeSearchProvider) == 0x58, "Offset mismatch for UFortQueryGenerator_Floodfill::MaximumNodeSearchProvider");
static_assert(offsetof(UFortQueryGenerator_Floodfill, MaximumSearchRadiusProvider) == 0x90, "Offset mismatch for UFortQueryGenerator_Floodfill::MaximumSearchRadiusProvider");
static_assert(offsetof(UFortQueryGenerator_Floodfill, PointDensityProvider) == 0xc8, "Offset mismatch for UFortQueryGenerator_Floodfill::PointDensityProvider");
static_assert(offsetof(UFortQueryGenerator_Floodfill, MaximumNumberOfPointProvider) == 0x100, "Offset mismatch for UFortQueryGenerator_Floodfill::MaximumNumberOfPointProvider");
static_assert(offsetof(UFortQueryGenerator_Floodfill, FilterOverride) == 0x138, "Offset mismatch for UFortQueryGenerator_Floodfill::FilterOverride");
static_assert(offsetof(UFortQueryGenerator_Floodfill, ProjectExtent) == 0x140, "Offset mismatch for UFortQueryGenerator_Floodfill::ProjectExtent");
static_assert(offsetof(UFortQueryGenerator_Floodfill, ExtraExcludeFlags) == 0x158, "Offset mismatch for UFortQueryGenerator_Floodfill::ExtraExcludeFlags");
static_assert(offsetof(UFortQueryGenerator_Floodfill, Behavior) == 0x15c, "Offset mismatch for UFortQueryGenerator_Floodfill::Behavior");

// Size: 0x148 (Inherited: 0x138, Single: 0x10)
class UFortQueryGenerator_GridInBox : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue BoxWidth; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue BoxLength; // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SpaceBetween; // 0x100 (Size: 0x38, Type: StructProperty)
    UClass* GenerateAround; // 0x138 (Size: 0x8, Type: ClassProperty)
    UClass* BoxExtentsContext; // 0x140 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_GridInBox) == 0x148, "Size mismatch for UFortQueryGenerator_GridInBox");
static_assert(offsetof(UFortQueryGenerator_GridInBox, BoxWidth) == 0x90, "Offset mismatch for UFortQueryGenerator_GridInBox::BoxWidth");
static_assert(offsetof(UFortQueryGenerator_GridInBox, BoxLength) == 0xc8, "Offset mismatch for UFortQueryGenerator_GridInBox::BoxLength");
static_assert(offsetof(UFortQueryGenerator_GridInBox, SpaceBetween) == 0x100, "Offset mismatch for UFortQueryGenerator_GridInBox::SpaceBetween");
static_assert(offsetof(UFortQueryGenerator_GridInBox, GenerateAround) == 0x138, "Offset mismatch for UFortQueryGenerator_GridInBox::GenerateAround");
static_assert(offsetof(UFortQueryGenerator_GridInBox, BoxExtentsContext) == 0x140, "Offset mismatch for UFortQueryGenerator_GridInBox::BoxExtentsContext");

// Size: 0xd0 (Inherited: 0x138, Single: 0xffffff98)
class UFortQueryGenerator_GridInVolume : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue SpaceBetween; // 0x90 (Size: 0x38, Type: StructProperty)
    UClass* GenerateInVolume; // 0xc8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_GridInVolume) == 0xd0, "Size mismatch for UFortQueryGenerator_GridInVolume");
static_assert(offsetof(UFortQueryGenerator_GridInVolume, SpaceBetween) == 0x90, "Offset mismatch for UFortQueryGenerator_GridInVolume::SpaceBetween");
static_assert(offsetof(UFortQueryGenerator_GridInVolume, GenerateInVolume) == 0xc8, "Offset mismatch for UFortQueryGenerator_GridInVolume::GenerateInVolume");

// Size: 0x1c0 (Inherited: 0x138, Single: 0x88)
class UFortQueryGenerator_OnRectangle : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue RectangleWidth; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue RectangleLength; // 0xc8 (Size: 0x38, Type: StructProperty)
    uint8_t SpacingMethod; // 0x100 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_101[0x7]; // 0x101 (Size: 0x7, Type: PaddingProperty)
    FAIDataProviderIntValue NumberOfPointsOnWidth; // 0x108 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue NumberOfPointsOnLength; // 0x140 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SpaceBetween; // 0x178 (Size: 0x38, Type: StructProperty)
    UClass* LocationContext; // 0x1b0 (Size: 0x8, Type: ClassProperty)
    UClass* RotationContext; // 0x1b8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_OnRectangle) == 0x1c0, "Size mismatch for UFortQueryGenerator_OnRectangle");
static_assert(offsetof(UFortQueryGenerator_OnRectangle, RectangleWidth) == 0x90, "Offset mismatch for UFortQueryGenerator_OnRectangle::RectangleWidth");
static_assert(offsetof(UFortQueryGenerator_OnRectangle, RectangleLength) == 0xc8, "Offset mismatch for UFortQueryGenerator_OnRectangle::RectangleLength");
static_assert(offsetof(UFortQueryGenerator_OnRectangle, SpacingMethod) == 0x100, "Offset mismatch for UFortQueryGenerator_OnRectangle::SpacingMethod");
static_assert(offsetof(UFortQueryGenerator_OnRectangle, NumberOfPointsOnWidth) == 0x108, "Offset mismatch for UFortQueryGenerator_OnRectangle::NumberOfPointsOnWidth");
static_assert(offsetof(UFortQueryGenerator_OnRectangle, NumberOfPointsOnLength) == 0x140, "Offset mismatch for UFortQueryGenerator_OnRectangle::NumberOfPointsOnLength");
static_assert(offsetof(UFortQueryGenerator_OnRectangle, SpaceBetween) == 0x178, "Offset mismatch for UFortQueryGenerator_OnRectangle::SpaceBetween");
static_assert(offsetof(UFortQueryGenerator_OnRectangle, LocationContext) == 0x1b0, "Offset mismatch for UFortQueryGenerator_OnRectangle::LocationContext");
static_assert(offsetof(UFortQueryGenerator_OnRectangle, RotationContext) == 0x1b8, "Offset mismatch for UFortQueryGenerator_OnRectangle::RotationContext");

// Size: 0x1f0 (Inherited: 0x138, Single: 0xb8)
class UFortQueryGenerator_OnSphere : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue Radius; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue SliceCount; // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue StackCount; // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScaleX; // 0x138 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScaleY; // 0x170 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScaleZ; // 0x1a8 (Size: 0x38, Type: StructProperty)
    UClass* LocationContext; // 0x1e0 (Size: 0x8, Type: ClassProperty)
    UClass* RotationContext; // 0x1e8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_OnSphere) == 0x1f0, "Size mismatch for UFortQueryGenerator_OnSphere");
static_assert(offsetof(UFortQueryGenerator_OnSphere, Radius) == 0x90, "Offset mismatch for UFortQueryGenerator_OnSphere::Radius");
static_assert(offsetof(UFortQueryGenerator_OnSphere, SliceCount) == 0xc8, "Offset mismatch for UFortQueryGenerator_OnSphere::SliceCount");
static_assert(offsetof(UFortQueryGenerator_OnSphere, StackCount) == 0x100, "Offset mismatch for UFortQueryGenerator_OnSphere::StackCount");
static_assert(offsetof(UFortQueryGenerator_OnSphere, ScaleX) == 0x138, "Offset mismatch for UFortQueryGenerator_OnSphere::ScaleX");
static_assert(offsetof(UFortQueryGenerator_OnSphere, ScaleY) == 0x170, "Offset mismatch for UFortQueryGenerator_OnSphere::ScaleY");
static_assert(offsetof(UFortQueryGenerator_OnSphere, ScaleZ) == 0x1a8, "Offset mismatch for UFortQueryGenerator_OnSphere::ScaleZ");
static_assert(offsetof(UFortQueryGenerator_OnSphere, LocationContext) == 0x1e0, "Offset mismatch for UFortQueryGenerator_OnSphere::LocationContext");
static_assert(offsetof(UFortQueryGenerator_OnSphere, RotationContext) == 0x1e8, "Offset mismatch for UFortQueryGenerator_OnSphere::RotationContext");

// Size: 0x178 (Inherited: 0x138, Single: 0x40)
class UFortQueryGenerator_PointsOnLine : public UEnvQueryGenerator_ProjectedPoints
{
public:
    UClass* GenerateFrom; // 0x90 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue DistanceToFirstPoint; // 0x98 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DistanceBetweenPoints; // 0xd0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaxDistance; // 0x108 (Size: 0x38, Type: StructProperty)
    FEnvTraceData TraceData; // 0x140 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_PointsOnLine) == 0x178, "Size mismatch for UFortQueryGenerator_PointsOnLine");
static_assert(offsetof(UFortQueryGenerator_PointsOnLine, GenerateFrom) == 0x90, "Offset mismatch for UFortQueryGenerator_PointsOnLine::GenerateFrom");
static_assert(offsetof(UFortQueryGenerator_PointsOnLine, DistanceToFirstPoint) == 0x98, "Offset mismatch for UFortQueryGenerator_PointsOnLine::DistanceToFirstPoint");
static_assert(offsetof(UFortQueryGenerator_PointsOnLine, DistanceBetweenPoints) == 0xd0, "Offset mismatch for UFortQueryGenerator_PointsOnLine::DistanceBetweenPoints");
static_assert(offsetof(UFortQueryGenerator_PointsOnLine, MaxDistance) == 0x108, "Offset mismatch for UFortQueryGenerator_PointsOnLine::MaxDistance");
static_assert(offsetof(UFortQueryGenerator_PointsOnLine, TraceData) == 0x140, "Offset mismatch for UFortQueryGenerator_PointsOnLine::TraceData");

// Size: 0x1b8 (Inherited: 0x138, Single: 0x80)
class UFortQueryGenerator_PointsOutsideBox : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue SpaceBetween; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue NumberOfRingsAroundVolume; // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ExtraXExtent; // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ExtraYExtent; // 0x138 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ExtraZExtent; // 0x170 (Size: 0x38, Type: StructProperty)
    UClass* GenerateInBoxCenter; // 0x1a8 (Size: 0x8, Type: ClassProperty)
    UClass* GenerateInBoxExtent; // 0x1b0 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_PointsOutsideBox) == 0x1b8, "Size mismatch for UFortQueryGenerator_PointsOutsideBox");
static_assert(offsetof(UFortQueryGenerator_PointsOutsideBox, SpaceBetween) == 0x90, "Offset mismatch for UFortQueryGenerator_PointsOutsideBox::SpaceBetween");
static_assert(offsetof(UFortQueryGenerator_PointsOutsideBox, NumberOfRingsAroundVolume) == 0xc8, "Offset mismatch for UFortQueryGenerator_PointsOutsideBox::NumberOfRingsAroundVolume");
static_assert(offsetof(UFortQueryGenerator_PointsOutsideBox, ExtraXExtent) == 0x100, "Offset mismatch for UFortQueryGenerator_PointsOutsideBox::ExtraXExtent");
static_assert(offsetof(UFortQueryGenerator_PointsOutsideBox, ExtraYExtent) == 0x138, "Offset mismatch for UFortQueryGenerator_PointsOutsideBox::ExtraYExtent");
static_assert(offsetof(UFortQueryGenerator_PointsOutsideBox, ExtraZExtent) == 0x170, "Offset mismatch for UFortQueryGenerator_PointsOutsideBox::ExtraZExtent");
static_assert(offsetof(UFortQueryGenerator_PointsOutsideBox, GenerateInBoxCenter) == 0x1a8, "Offset mismatch for UFortQueryGenerator_PointsOutsideBox::GenerateInBoxCenter");
static_assert(offsetof(UFortQueryGenerator_PointsOutsideBox, GenerateInBoxExtent) == 0x1b0, "Offset mismatch for UFortQueryGenerator_PointsOutsideBox::GenerateInBoxExtent");

// Size: 0x160 (Inherited: 0xa8, Single: 0xb8)
class UFortTokenGenerator_TokenHintPositions : public UEnvQueryGenerator
{
public:
    UClass* Center; // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue MaximumDistanceProvider; // 0x58 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue HintPositionVerticalOffsetProvider; // 0x90 (Size: 0x38, Type: StructProperty)
    FGameplayTagQuery RequiredTagQuery; // 0xc8 (Size: 0x48, Type: StructProperty)
    FScalableFloat MaximumDistance; // 0x110 (Size: 0x28, Type: StructProperty)
    FScalableFloat HintPositionVerticalOffset; // 0x138 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UFortTokenGenerator_TokenHintPositions) == 0x160, "Size mismatch for UFortTokenGenerator_TokenHintPositions");
static_assert(offsetof(UFortTokenGenerator_TokenHintPositions, Center) == 0x50, "Offset mismatch for UFortTokenGenerator_TokenHintPositions::Center");
static_assert(offsetof(UFortTokenGenerator_TokenHintPositions, MaximumDistanceProvider) == 0x58, "Offset mismatch for UFortTokenGenerator_TokenHintPositions::MaximumDistanceProvider");
static_assert(offsetof(UFortTokenGenerator_TokenHintPositions, HintPositionVerticalOffsetProvider) == 0x90, "Offset mismatch for UFortTokenGenerator_TokenHintPositions::HintPositionVerticalOffsetProvider");
static_assert(offsetof(UFortTokenGenerator_TokenHintPositions, RequiredTagQuery) == 0xc8, "Offset mismatch for UFortTokenGenerator_TokenHintPositions::RequiredTagQuery");
static_assert(offsetof(UFortTokenGenerator_TokenHintPositions, MaximumDistance) == 0x110, "Offset mismatch for UFortTokenGenerator_TokenHintPositions::MaximumDistance");
static_assert(offsetof(UFortTokenGenerator_TokenHintPositions, HintPositionVerticalOffset) == 0x138, "Offset mismatch for UFortTokenGenerator_TokenHintPositions::HintPositionVerticalOffset");

// Size: 0xa0 (Inherited: 0xa8, Single: 0xfffffff8)
class UFortQueryGenerator_TokenProviderPositions : public UEnvQueryGenerator
{
public:
    UClass* TokenProviderContext; // 0x50 (Size: 0x8, Type: ClassProperty)
    FGameplayTagQuery GameplayTagQuery; // 0x58 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_TokenProviderPositions) == 0xa0, "Size mismatch for UFortQueryGenerator_TokenProviderPositions");
static_assert(offsetof(UFortQueryGenerator_TokenProviderPositions, TokenProviderContext) == 0x50, "Offset mismatch for UFortQueryGenerator_TokenProviderPositions::TokenProviderContext");
static_assert(offsetof(UFortQueryGenerator_TokenProviderPositions, GameplayTagQuery) == 0x58, "Offset mismatch for UFortQueryGenerator_TokenProviderPositions::GameplayTagQuery");

// Size: 0x100 (Inherited: 0xa8, Single: 0x58)
class UFortQueryGenerator_TokenReservedPositions : public UEnvQueryGenerator
{
public:
    UClass* ActorContext; // 0x50 (Size: 0x8, Type: ClassProperty)
    FGameplayTagQuery GameplayTagQuery; // 0x58 (Size: 0x48, Type: StructProperty)
    FAIDataProviderFloatValue MaximumDistanceFromQueryActorProvider; // 0xa0 (Size: 0x38, Type: StructProperty)
    FScalableFloat MaximumDistanceFromQueryActor; // 0xd8 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_TokenReservedPositions) == 0x100, "Size mismatch for UFortQueryGenerator_TokenReservedPositions");
static_assert(offsetof(UFortQueryGenerator_TokenReservedPositions, ActorContext) == 0x50, "Offset mismatch for UFortQueryGenerator_TokenReservedPositions::ActorContext");
static_assert(offsetof(UFortQueryGenerator_TokenReservedPositions, GameplayTagQuery) == 0x58, "Offset mismatch for UFortQueryGenerator_TokenReservedPositions::GameplayTagQuery");
static_assert(offsetof(UFortQueryGenerator_TokenReservedPositions, MaximumDistanceFromQueryActorProvider) == 0xa0, "Offset mismatch for UFortQueryGenerator_TokenReservedPositions::MaximumDistanceFromQueryActorProvider");
static_assert(offsetof(UFortQueryGenerator_TokenReservedPositions, MaximumDistanceFromQueryActor) == 0xd8, "Offset mismatch for UFortQueryGenerator_TokenReservedPositions::MaximumDistanceFromQueryActor");

// Size: 0x270 (Inherited: 0x250, Single: 0x20)
class UFortQueryTest_ActorWithinMeleeRange : public UEnvQueryTest
{
public:
    UClass* TargetContext; // 0x1f8 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderBoolValue RequireAllTargets; // 0x200 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue TargetBoundsHeightBias; // 0x238 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_ActorWithinMeleeRange) == 0x270, "Size mismatch for UFortQueryTest_ActorWithinMeleeRange");
static_assert(offsetof(UFortQueryTest_ActorWithinMeleeRange, TargetContext) == 0x1f8, "Offset mismatch for UFortQueryTest_ActorWithinMeleeRange::TargetContext");
static_assert(offsetof(UFortQueryTest_ActorWithinMeleeRange, RequireAllTargets) == 0x200, "Offset mismatch for UFortQueryTest_ActorWithinMeleeRange::RequireAllTargets");
static_assert(offsetof(UFortQueryTest_ActorWithinMeleeRange, TargetBoundsHeightBias) == 0x238, "Offset mismatch for UFortQueryTest_ActorWithinMeleeRange::TargetBoundsHeightBias");

// Size: 0x208 (Inherited: 0x250, Single: 0xffffffb8)
class UFortQueryTest_CoverPosition : public UEnvQueryTest
{
public:
    UClass* CoverPositionProviderContext; // 0x1f8 (Size: 0x8, Type: ClassProperty)
    UClass* TargetContext; // 0x200 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryTest_CoverPosition) == 0x208, "Size mismatch for UFortQueryTest_CoverPosition");
static_assert(offsetof(UFortQueryTest_CoverPosition, CoverPositionProviderContext) == 0x1f8, "Offset mismatch for UFortQueryTest_CoverPosition::CoverPositionProviderContext");
static_assert(offsetof(UFortQueryTest_CoverPosition, TargetContext) == 0x200, "Offset mismatch for UFortQueryTest_CoverPosition::TargetContext");

// Size: 0x240 (Inherited: 0x250, Single: 0xfffffff0)
class UFortQueryTest_DefendSpotCanShoot : public UEnvQueryTest
{
public:
    UClass* TargetActorContext; // 0x1f8 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue TraceCloseEnoughDistance; // 0x200 (Size: 0x38, Type: StructProperty)
    TEnumAsByte<ETraceTypeQuery> TraceType; // 0x238 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_239[0x7]; // 0x239 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_DefendSpotCanShoot) == 0x240, "Size mismatch for UFortQueryTest_DefendSpotCanShoot");
static_assert(offsetof(UFortQueryTest_DefendSpotCanShoot, TargetActorContext) == 0x1f8, "Offset mismatch for UFortQueryTest_DefendSpotCanShoot::TargetActorContext");
static_assert(offsetof(UFortQueryTest_DefendSpotCanShoot, TraceCloseEnoughDistance) == 0x200, "Offset mismatch for UFortQueryTest_DefendSpotCanShoot::TraceCloseEnoughDistance");
static_assert(offsetof(UFortQueryTest_DefendSpotCanShoot, TraceType) == 0x238, "Offset mismatch for UFortQueryTest_DefendSpotCanShoot::TraceType");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UFortQueryTest_DefendSpotPenalized : public UEnvQueryTest
{
public:
};

static_assert(sizeof(UFortQueryTest_DefendSpotPenalized) == 0x1f8, "Size mismatch for UFortQueryTest_DefendSpotPenalized");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UFortQueryTest_DefendSpotOccupied : public UEnvQueryTest
{
public:
};

static_assert(sizeof(UFortQueryTest_DefendSpotOccupied) == 0x1f8, "Size mismatch for UFortQueryTest_DefendSpotOccupied");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UFortQueryTest_DefendSpotAlreadyReserved : public UEnvQueryTest
{
public:
};

static_assert(sizeof(UFortQueryTest_DefendSpotAlreadyReserved) == 0x1f8, "Size mismatch for UFortQueryTest_DefendSpotAlreadyReserved");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UFortQueryTest_DefendSpotPreviouslyOccupied : public UEnvQueryTest
{
public:
};

static_assert(sizeof(UFortQueryTest_DefendSpotPreviouslyOccupied) == 0x1f8, "Size mismatch for UFortQueryTest_DefendSpotPreviouslyOccupied");

// Size: 0x238 (Inherited: 0x250, Single: 0xffffffe8)
class UFortQueryTest_DefendSpotPathfindLength : public UEnvQueryTest
{
public:
    FAIDataProviderFloatValue NavmeshNodeSearchDistanceScale; // 0x1f8 (Size: 0x38, Type: StructProperty)
    UClass* PathfindNavigationQueryFilter; // 0x230 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryTest_DefendSpotPathfindLength) == 0x238, "Size mismatch for UFortQueryTest_DefendSpotPathfindLength");
static_assert(offsetof(UFortQueryTest_DefendSpotPathfindLength, NavmeshNodeSearchDistanceScale) == 0x1f8, "Offset mismatch for UFortQueryTest_DefendSpotPathfindLength::NavmeshNodeSearchDistanceScale");
static_assert(offsetof(UFortQueryTest_DefendSpotPathfindLength, PathfindNavigationQueryFilter) == 0x230, "Offset mismatch for UFortQueryTest_DefendSpotPathfindLength::PathfindNavigationQueryFilter");

// Size: 0x200 (Inherited: 0x250, Single: 0xffffffb0)
class UFortQueryTest_DefendSpotProtectionDot : public UEnvQueryTest
{
public:
    UClass* TargetActorContext; // 0x1f8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryTest_DefendSpotProtectionDot) == 0x200, "Size mismatch for UFortQueryTest_DefendSpotProtectionDot");
static_assert(offsetof(UFortQueryTest_DefendSpotProtectionDot, TargetActorContext) == 0x1f8, "Offset mismatch for UFortQueryTest_DefendSpotProtectionDot::TargetActorContext");

// Size: 0x280 (Inherited: 0x250, Single: 0x30)
class UFortQueryTest_DistanceBounded : public UEnvQueryTest
{
public:
    uint8_t MeasurementType; // 0x1f8 (Size: 0x1, Type: EnumProperty)
    bool bEnableUpperBound; // 0x1f9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1fa[0x6]; // 0x1fa (Size: 0x6, Type: PaddingProperty)
    FAIDataProviderFloatValue UpperBound; // 0x200 (Size: 0x38, Type: StructProperty)
    bool bEnableLowerBound; // 0x238 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_239[0x7]; // 0x239 (Size: 0x7, Type: PaddingProperty)
    FAIDataProviderFloatValue LowerBound; // 0x240 (Size: 0x38, Type: StructProperty)
    UClass* ContextLocation; // 0x278 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryTest_DistanceBounded) == 0x280, "Size mismatch for UFortQueryTest_DistanceBounded");
static_assert(offsetof(UFortQueryTest_DistanceBounded, MeasurementType) == 0x1f8, "Offset mismatch for UFortQueryTest_DistanceBounded::MeasurementType");
static_assert(offsetof(UFortQueryTest_DistanceBounded, bEnableUpperBound) == 0x1f9, "Offset mismatch for UFortQueryTest_DistanceBounded::bEnableUpperBound");
static_assert(offsetof(UFortQueryTest_DistanceBounded, UpperBound) == 0x200, "Offset mismatch for UFortQueryTest_DistanceBounded::UpperBound");
static_assert(offsetof(UFortQueryTest_DistanceBounded, bEnableLowerBound) == 0x238, "Offset mismatch for UFortQueryTest_DistanceBounded::bEnableLowerBound");
static_assert(offsetof(UFortQueryTest_DistanceBounded, LowerBound) == 0x240, "Offset mismatch for UFortQueryTest_DistanceBounded::LowerBound");
static_assert(offsetof(UFortQueryTest_DistanceBounded, ContextLocation) == 0x278, "Offset mismatch for UFortQueryTest_DistanceBounded::ContextLocation");

// Size: 0x240 (Inherited: 0x250, Single: 0xfffffff0)
class UFortQueryTest_NavmeshRaycast : public UEnvQueryTest
{
public:
    FAIDataProviderBoolValue ShouldRaycastToContext; // 0x1f8 (Size: 0x38, Type: StructProperty)
    UClass* RaycastContext; // 0x230 (Size: 0x8, Type: ClassProperty)
    UClass* NavigationFilterOverride; // 0x238 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryTest_NavmeshRaycast) == 0x240, "Size mismatch for UFortQueryTest_NavmeshRaycast");
static_assert(offsetof(UFortQueryTest_NavmeshRaycast, ShouldRaycastToContext) == 0x1f8, "Offset mismatch for UFortQueryTest_NavmeshRaycast::ShouldRaycastToContext");
static_assert(offsetof(UFortQueryTest_NavmeshRaycast, RaycastContext) == 0x230, "Offset mismatch for UFortQueryTest_NavmeshRaycast::RaycastContext");
static_assert(offsetof(UFortQueryTest_NavmeshRaycast, NavigationFilterOverride) == 0x238, "Offset mismatch for UFortQueryTest_NavmeshRaycast::NavigationFilterOverride");

// Size: 0x60 (Inherited: 0x28, Single: 0x38)
class UFortWorldConditionTimeOfDayState : public UObject
{
public:

private:
    void HandleTimeOfDayPhaseChange(EFortDayPhase& CurrentDayPhase, EFortDayPhase& PreviousDayPhase, bool& bAtCreation); // 0xeed23e0 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortWorldConditionTimeOfDayState) == 0x60, "Size mismatch for UFortWorldConditionTimeOfDayState");

// Size: 0x168 (Inherited: 0x170, Single: 0xfffffff8)
class UPFWNPCReactions_Container : public UPersistenceFrameworkContainer
{
public:
};

static_assert(sizeof(UPFWNPCReactions_Container) == 0x168, "Size mismatch for UPFWNPCReactions_Container");

// Size: 0xe0 (Inherited: 0x108, Single: 0xffffffd8)
class UPFWNPCReactions_Module : public UPersistenceFrameworkModule
{
public:
};

static_assert(sizeof(UPFWNPCReactions_Module) == 0xe0, "Size mismatch for UPFWNPCReactions_Module");

// Size: 0xa0 (Inherited: 0x168, Single: 0xffffff38)
class UPFWNPCReactions_Trigger : public UPersistenceFrameworkSaveTrigger_Manual
{
public:
};

static_assert(sizeof(UPFWNPCReactions_Trigger) == 0xa0, "Size mismatch for UPFWNPCReactions_Trigger");

// Size: 0x1d0 (Inherited: 0x138, Single: 0x98)
class UPFWNPCReactions_FilteredListContainer : public UPersistenceFrameworkFilteredListContainer
{
public:
};

static_assert(sizeof(UPFWNPCReactions_FilteredListContainer) == 0x1d0, "Size mismatch for UPFWNPCReactions_FilteredListContainer");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UFortGameFeatureAction_InjectAIEvaluators : public UGameFeatureAction
{
public:
    TArray<FGameFeatureFortAIEvaluatorEntry> AIEvaluatorList; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortGameFeatureAction_InjectAIEvaluators) == 0x38, "Size mismatch for UFortGameFeatureAction_InjectAIEvaluators");
static_assert(offsetof(UFortGameFeatureAction_InjectAIEvaluators, AIEvaluatorList) == 0x28, "Offset mismatch for UFortGameFeatureAction_InjectAIEvaluators::AIEvaluatorList");

// Size: 0x98 (Inherited: 0x138, Single: 0xffffff60)
class UFortEnvQueryGenerator_ProjectedPoints : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FName OverridenAgentNameForNavmesh; // 0x90 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortEnvQueryGenerator_ProjectedPoints) == 0x98, "Size mismatch for UFortEnvQueryGenerator_ProjectedPoints");
static_assert(offsetof(UFortEnvQueryGenerator_ProjectedPoints, OverridenAgentNameForNavmesh) == 0x90, "Offset mismatch for UFortEnvQueryGenerator_ProjectedPoints::OverridenAgentNameForNavmesh");

// Size: 0x148 (Inherited: 0x1d0, Single: 0xffffff78)
class UFortEnvQueryGenerator_SimpleGrid : public UFortEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue GridSize; // 0x98 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SpaceBetween; // 0xd0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue RandomDisplacementRatio; // 0x108 (Size: 0x38, Type: StructProperty)
    UClass* GenerateAround; // 0x140 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortEnvQueryGenerator_SimpleGrid) == 0x148, "Size mismatch for UFortEnvQueryGenerator_SimpleGrid");
static_assert(offsetof(UFortEnvQueryGenerator_SimpleGrid, GridSize) == 0x98, "Offset mismatch for UFortEnvQueryGenerator_SimpleGrid::GridSize");
static_assert(offsetof(UFortEnvQueryGenerator_SimpleGrid, SpaceBetween) == 0xd0, "Offset mismatch for UFortEnvQueryGenerator_SimpleGrid::SpaceBetween");
static_assert(offsetof(UFortEnvQueryGenerator_SimpleGrid, RandomDisplacementRatio) == 0x108, "Offset mismatch for UFortEnvQueryGenerator_SimpleGrid::RandomDisplacementRatio");
static_assert(offsetof(UFortEnvQueryGenerator_SimpleGrid, GenerateAround) == 0x140, "Offset mismatch for UFortEnvQueryGenerator_SimpleGrid::GenerateAround");

// Size: 0xb0 (Inherited: 0x1d0, Single: 0xfffffee0)
class UFortBTContext_MoveUrgency : public UFortBTService_ContextOverride
{
public:
    FValueOrBBKey_Enum MoveUrgencyValue; // 0x80 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<EFortMovementUrgency> MoveUrgency; // 0xa8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTContext_MoveUrgency) == 0xb0, "Size mismatch for UFortBTContext_MoveUrgency");
static_assert(offsetof(UFortBTContext_MoveUrgency, MoveUrgencyValue) == 0x80, "Offset mismatch for UFortBTContext_MoveUrgency::MoveUrgencyValue");
static_assert(offsetof(UFortBTContext_MoveUrgency, MoveUrgency) == 0xa8, "Offset mismatch for UFortBTContext_MoveUrgency::MoveUrgency");

// Size: 0x80 (Inherited: 0x150, Single: 0xffffff30)
class UFortBTService_ContextOverride : public UBTService
{
public:
    FValueOrBBKey_Bool Enabled; // 0x70 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTService_ContextOverride) == 0x80, "Size mismatch for UFortBTService_ContextOverride");
static_assert(offsetof(UFortBTService_ContextOverride, Enabled) == 0x70, "Offset mismatch for UFortBTService_ContextOverride::Enabled");

// Size: 0x80 (Inherited: 0x1d0, Single: 0xfffffeb0)
class UFortBTContext_SkipNotPerceivedGoals : public UFortBTService_ContextOverride
{
public:
};

static_assert(sizeof(UFortBTContext_SkipNotPerceivedGoals) == 0x80, "Size mismatch for UFortBTContext_SkipNotPerceivedGoals");

// Size: 0x88 (Inherited: 0x1d0, Single: 0xfffffeb8)
class UFortBTContext_SuppressGoalUpdate : public UFortBTService_ContextOverride
{
public:
    bool bUnregisterFromGoalManager; // 0x80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_81[0x7]; // 0x81 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTContext_SuppressGoalUpdate) == 0x88, "Size mismatch for UFortBTContext_SuppressGoalUpdate");
static_assert(offsetof(UFortBTContext_SuppressGoalUpdate, bUnregisterFromGoalManager) == 0x80, "Offset mismatch for UFortBTContext_SuppressGoalUpdate::bUnregisterFromGoalManager");

// Size: 0xc0 (Inherited: 0x148, Single: 0xffffff78)
class UFortBTDecorator_Affiliation : public UBTDecorator
{
public:
    FBlackboardKeySelector FirstActorKey; // 0x68 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector SecondActorKey; // 0x90 (Size: 0x28, Type: StructProperty)
    uint32_t AcceptedAffiliations; // 0xb8 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTDecorator_Affiliation) == 0xc0, "Size mismatch for UFortBTDecorator_Affiliation");
static_assert(offsetof(UFortBTDecorator_Affiliation, FirstActorKey) == 0x68, "Offset mismatch for UFortBTDecorator_Affiliation::FirstActorKey");
static_assert(offsetof(UFortBTDecorator_Affiliation, SecondActorKey) == 0x90, "Offset mismatch for UFortBTDecorator_Affiliation::SecondActorKey");
static_assert(offsetof(UFortBTDecorator_Affiliation, AcceptedAffiliations) == 0xb8, "Offset mismatch for UFortBTDecorator_Affiliation::AcceptedAffiliations");

// Size: 0x90 (Inherited: 0x1d8, Single: 0xfffffeb8)
class UFortBTDecorator_CanBeConsideredAirborne : public UBTDecorator_BlackboardBase
{
public:
};

static_assert(sizeof(UFortBTDecorator_CanBeConsideredAirborne) == 0x90, "Size mismatch for UFortBTDecorator_CanBeConsideredAirborne");

// Size: 0xe8 (Inherited: 0x148, Single: 0xffffffa0)
class UFortBTDecorator_DistanceBetween : public UBTDecorator
{
public:
    TEnumAsByte<EArithmeticKeyOperation> Operator; // 0x68 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
    FBlackboardKeySelector BlackboardKeyA; // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector BlackboardKeyB; // 0x98 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Float SpecifiedDistance; // 0xc0 (Size: 0xc, Type: StructProperty)
    uint8_t bUseSelf : 1; // 0xcc:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_cd[0x3]; // 0xcd (Size: 0x3, Type: PaddingProperty)
    FValueOrBBKey_Bool bCalculateAs2D; // 0xd0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float DistanceCalculationUpdateRate; // 0xdc (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(UFortBTDecorator_DistanceBetween) == 0xe8, "Size mismatch for UFortBTDecorator_DistanceBetween");
static_assert(offsetof(UFortBTDecorator_DistanceBetween, Operator) == 0x68, "Offset mismatch for UFortBTDecorator_DistanceBetween::Operator");
static_assert(offsetof(UFortBTDecorator_DistanceBetween, BlackboardKeyA) == 0x70, "Offset mismatch for UFortBTDecorator_DistanceBetween::BlackboardKeyA");
static_assert(offsetof(UFortBTDecorator_DistanceBetween, BlackboardKeyB) == 0x98, "Offset mismatch for UFortBTDecorator_DistanceBetween::BlackboardKeyB");
static_assert(offsetof(UFortBTDecorator_DistanceBetween, SpecifiedDistance) == 0xc0, "Offset mismatch for UFortBTDecorator_DistanceBetween::SpecifiedDistance");
static_assert(offsetof(UFortBTDecorator_DistanceBetween, bUseSelf) == 0xcc, "Offset mismatch for UFortBTDecorator_DistanceBetween::bUseSelf");
static_assert(offsetof(UFortBTDecorator_DistanceBetween, bCalculateAs2D) == 0xd0, "Offset mismatch for UFortBTDecorator_DistanceBetween::bCalculateAs2D");
static_assert(offsetof(UFortBTDecorator_DistanceBetween, DistanceCalculationUpdateRate) == 0xdc, "Offset mismatch for UFortBTDecorator_DistanceBetween::DistanceCalculationUpdateRate");

// Size: 0x168 (Inherited: 0x2b0, Single: 0xfffffeb8)
class UFortBTDecorator_GameplayAbility_CanActivate : public UFortBTDecorator_QueryGameplayAbility
{
public:
};

static_assert(sizeof(UFortBTDecorator_GameplayAbility_CanActivate) == 0x168, "Size mismatch for UFortBTDecorator_GameplayAbility_CanActivate");

// Size: 0x178 (Inherited: 0x2b0, Single: 0xfffffec8)
class UFortBTDecorator_GameplayAbility_CanHitTarget : public UFortBTDecorator_QueryGameplayAbility
{
public:
    FValueOrBBKey_Bool UseIdealYawRotationToTargetValue; // 0x168 (Size: 0xc, Type: StructProperty)
    uint8_t UseIdealYawRotationToTarget : 1; // 0x174:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_175[0x3]; // 0x175 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTDecorator_GameplayAbility_CanHitTarget) == 0x178, "Size mismatch for UFortBTDecorator_GameplayAbility_CanHitTarget");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_CanHitTarget, UseIdealYawRotationToTargetValue) == 0x168, "Offset mismatch for UFortBTDecorator_GameplayAbility_CanHitTarget::UseIdealYawRotationToTargetValue");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_CanHitTarget, UseIdealYawRotationToTarget) == 0x174, "Offset mismatch for UFortBTDecorator_GameplayAbility_CanHitTarget::UseIdealYawRotationToTarget");

// Size: 0x178 (Inherited: 0x2b0, Single: 0xfffffec8)
class UFortBTDecorator_GameplayAbility_CompareDistance : public UFortBTDecorator_QueryGameplayAbility
{
public:
    TArray<FDistanceToTargetComparison> DistanceComparisons; // 0x168 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortBTDecorator_GameplayAbility_CompareDistance) == 0x178, "Size mismatch for UFortBTDecorator_GameplayAbility_CompareDistance");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_CompareDistance, DistanceComparisons) == 0x168, "Offset mismatch for UFortBTDecorator_GameplayAbility_CompareDistance::DistanceComparisons");

// Size: 0x168 (Inherited: 0x2b0, Single: 0xfffffeb8)
class UFortBTDecorator_GameplayAbility_DoesTargetHaveProhibitedTags : public UFortBTDecorator_QueryGameplayAbility
{
public:
};

static_assert(sizeof(UFortBTDecorator_GameplayAbility_DoesTargetHaveProhibitedTags) == 0x168, "Size mismatch for UFortBTDecorator_GameplayAbility_DoesTargetHaveProhibitedTags");

// Size: 0x130 (Inherited: 0x148, Single: 0xffffffe8)
class UFortBTDecorator_GameplayAbility_HasGameplayAbility : public UBTDecorator
{
public:
    FValueOrBBKey_Object AbilityOwningActor; // 0x68 (Size: 0x18, Type: StructProperty)
    FValueOrBBKey_GameplayTagContainer GameplayAbilityTagContainer; // 0x80 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Bool OnlyTestActiveAbility; // 0xa8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_b4[0x4]; // 0xb4 (Size: 0x4, Type: PaddingProperty)
    FBlackboardKeySelector AbilityOwningActorKey; // 0xb8 (Size: 0x28, Type: StructProperty)
    FGameplayTagContainer GameplayAbilityTag; // 0xe0 (Size: 0x20, Type: StructProperty)
    FBlackboardKeySelector GameplayAbilityTagBlackboardKey; // 0x100 (Size: 0x28, Type: StructProperty)
    bool bOnlyTestActiveAbility; // 0x128 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_129[0x7]; // 0x129 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTDecorator_GameplayAbility_HasGameplayAbility) == 0x130, "Size mismatch for UFortBTDecorator_GameplayAbility_HasGameplayAbility");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasGameplayAbility, AbilityOwningActor) == 0x68, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasGameplayAbility::AbilityOwningActor");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasGameplayAbility, GameplayAbilityTagContainer) == 0x80, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasGameplayAbility::GameplayAbilityTagContainer");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasGameplayAbility, OnlyTestActiveAbility) == 0xa8, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasGameplayAbility::OnlyTestActiveAbility");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasGameplayAbility, AbilityOwningActorKey) == 0xb8, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasGameplayAbility::AbilityOwningActorKey");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasGameplayAbility, GameplayAbilityTag) == 0xe0, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasGameplayAbility::GameplayAbilityTag");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasGameplayAbility, GameplayAbilityTagBlackboardKey) == 0x100, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasGameplayAbility::GameplayAbilityTagBlackboardKey");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasGameplayAbility, bOnlyTestActiveAbility) == 0x128, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasGameplayAbility::bOnlyTestActiveAbility");

// Size: 0x198 (Inherited: 0x2b0, Single: 0xfffffee8)
class UFortBTDecorator_GameplayAbility_HasNearbyPawns : public UFortBTDecorator_QueryGameplayAbility
{
public:
    FValueOrBBKey_Float NearbyPawnDistanceValue; // 0x168 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool FilterAIPawns; // 0x174 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool FilterPlayerPawns; // 0x180 (Size: 0xc, Type: StructProperty)
    float NearbyPawnDistance; // 0x18c (Size: 0x4, Type: FloatProperty)
    bool bFilterAIPawns; // 0x190 (Size: 0x1, Type: BoolProperty)
    bool bFilterPlayerPawns; // 0x191 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_192[0x6]; // 0x192 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTDecorator_GameplayAbility_HasNearbyPawns) == 0x198, "Size mismatch for UFortBTDecorator_GameplayAbility_HasNearbyPawns");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasNearbyPawns, NearbyPawnDistanceValue) == 0x168, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasNearbyPawns::NearbyPawnDistanceValue");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasNearbyPawns, FilterAIPawns) == 0x174, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasNearbyPawns::FilterAIPawns");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasNearbyPawns, FilterPlayerPawns) == 0x180, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasNearbyPawns::FilterPlayerPawns");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasNearbyPawns, NearbyPawnDistance) == 0x18c, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasNearbyPawns::NearbyPawnDistance");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasNearbyPawns, bFilterAIPawns) == 0x190, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasNearbyPawns::bFilterAIPawns");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_HasNearbyPawns, bFilterPlayerPawns) == 0x191, "Offset mismatch for UFortBTDecorator_GameplayAbility_HasNearbyPawns::bFilterPlayerPawns");

// Size: 0x198 (Inherited: 0x2b0, Single: 0xfffffee8)
class UFortBTDecorator_GameplayAbility_IsClosestPawnInRange : public UFortBTDecorator_QueryGameplayAbility
{
public:
    FValueOrBBKey_Float NearbyPawnDistanceValue; // 0x168 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool FilterAIPawns; // 0x174 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool FilterPlayerPawns; // 0x180 (Size: 0xc, Type: StructProperty)
    float NearbyPawnDistance; // 0x18c (Size: 0x4, Type: FloatProperty)
    bool bFilterAIPawns; // 0x190 (Size: 0x1, Type: BoolProperty)
    bool bFilterPlayerPawns; // 0x191 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_192[0x6]; // 0x192 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTDecorator_GameplayAbility_IsClosestPawnInRange) == 0x198, "Size mismatch for UFortBTDecorator_GameplayAbility_IsClosestPawnInRange");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_IsClosestPawnInRange, NearbyPawnDistanceValue) == 0x168, "Offset mismatch for UFortBTDecorator_GameplayAbility_IsClosestPawnInRange::NearbyPawnDistanceValue");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_IsClosestPawnInRange, FilterAIPawns) == 0x174, "Offset mismatch for UFortBTDecorator_GameplayAbility_IsClosestPawnInRange::FilterAIPawns");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_IsClosestPawnInRange, FilterPlayerPawns) == 0x180, "Offset mismatch for UFortBTDecorator_GameplayAbility_IsClosestPawnInRange::FilterPlayerPawns");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_IsClosestPawnInRange, NearbyPawnDistance) == 0x18c, "Offset mismatch for UFortBTDecorator_GameplayAbility_IsClosestPawnInRange::NearbyPawnDistance");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_IsClosestPawnInRange, bFilterAIPawns) == 0x190, "Offset mismatch for UFortBTDecorator_GameplayAbility_IsClosestPawnInRange::bFilterAIPawns");
static_assert(offsetof(UFortBTDecorator_GameplayAbility_IsClosestPawnInRange, bFilterPlayerPawns) == 0x191, "Offset mismatch for UFortBTDecorator_GameplayAbility_IsClosestPawnInRange::bFilterPlayerPawns");

// Size: 0x168 (Inherited: 0x2b0, Single: 0xfffffeb8)
class UFortBTDecorator_GameplayAbility_IsOnCooldown : public UFortBTDecorator_QueryGameplayAbility
{
public:
};

static_assert(sizeof(UFortBTDecorator_GameplayAbility_IsOnCooldown) == 0x168, "Size mismatch for UFortBTDecorator_GameplayAbility_IsOnCooldown");

// Size: 0x168 (Inherited: 0x2b0, Single: 0xfffffeb8)
class UFortBTDecorator_GameplayAbility_IsRotatedToAttackTarget : public UFortBTDecorator_QueryGameplayAbility
{
public:
};

static_assert(sizeof(UFortBTDecorator_GameplayAbility_IsRotatedToAttackTarget) == 0x168, "Size mismatch for UFortBTDecorator_GameplayAbility_IsRotatedToAttackTarget");

// Size: 0x168 (Inherited: 0x2b0, Single: 0xfffffeb8)
class UFortBTDecorator_GameplayAbility_IsWithinMaxTargetSelectionRange : public UFortBTDecorator_QueryGameplayAbility
{
public:
};

static_assert(sizeof(UFortBTDecorator_GameplayAbility_IsWithinMaxTargetSelectionRange) == 0x168, "Size mismatch for UFortBTDecorator_GameplayAbility_IsWithinMaxTargetSelectionRange");

// Size: 0x90 (Inherited: 0x1d8, Single: 0xfffffeb8)
class UFortBTDecorator_IsGoalPawn : public UBTDecorator_BlackboardBase
{
public:
};

static_assert(sizeof(UFortBTDecorator_IsGoalPawn) == 0x90, "Size mismatch for UFortBTDecorator_IsGoalPawn");

// Size: 0x68 (Inherited: 0x148, Single: 0xffffff20)
class UFortBTDecorator_IsInBotEndGame : public UBTDecorator
{
public:
};

static_assert(sizeof(UFortBTDecorator_IsInBotEndGame) == 0x68, "Size mismatch for UFortBTDecorator_IsInBotEndGame");

// Size: 0x1d8 (Inherited: 0x2b0, Single: 0xffffff28)
class UFortBTDecorator_IsMoving : public UFortBTDecorator_QueryGameplayAbility
{
public:
    FValueOrBBKey_Float UpdateIntervalValue; // 0x168 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float MinTimeValue; // 0x174 (Size: 0xc, Type: StructProperty)
    bool bUseMinDist; // 0x180 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_181[0x3]; // 0x181 (Size: 0x3, Type: PaddingProperty)
    FValueOrBBKey_Float UseMinDistToTargetTime; // 0x184 (Size: 0xc, Type: StructProperty)
    FDistanceToTargetComparison MinDistanceComparison; // 0x190 (Size: 0x38, Type: StructProperty)
    float UpdateInterval; // 0x1c8 (Size: 0x4, Type: FloatProperty)
    float MinTime; // 0x1cc (Size: 0x4, Type: FloatProperty)
    float MinDistMinTime; // 0x1d0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1d4[0x4]; // 0x1d4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTDecorator_IsMoving) == 0x1d8, "Size mismatch for UFortBTDecorator_IsMoving");
static_assert(offsetof(UFortBTDecorator_IsMoving, UpdateIntervalValue) == 0x168, "Offset mismatch for UFortBTDecorator_IsMoving::UpdateIntervalValue");
static_assert(offsetof(UFortBTDecorator_IsMoving, MinTimeValue) == 0x174, "Offset mismatch for UFortBTDecorator_IsMoving::MinTimeValue");
static_assert(offsetof(UFortBTDecorator_IsMoving, bUseMinDist) == 0x180, "Offset mismatch for UFortBTDecorator_IsMoving::bUseMinDist");
static_assert(offsetof(UFortBTDecorator_IsMoving, UseMinDistToTargetTime) == 0x184, "Offset mismatch for UFortBTDecorator_IsMoving::UseMinDistToTargetTime");
static_assert(offsetof(UFortBTDecorator_IsMoving, MinDistanceComparison) == 0x190, "Offset mismatch for UFortBTDecorator_IsMoving::MinDistanceComparison");
static_assert(offsetof(UFortBTDecorator_IsMoving, UpdateInterval) == 0x1c8, "Offset mismatch for UFortBTDecorator_IsMoving::UpdateInterval");
static_assert(offsetof(UFortBTDecorator_IsMoving, MinTime) == 0x1cc, "Offset mismatch for UFortBTDecorator_IsMoving::MinTime");
static_assert(offsetof(UFortBTDecorator_IsMoving, MinDistMinTime) == 0x1d0, "Offset mismatch for UFortBTDecorator_IsMoving::MinDistMinTime");

// Size: 0x68 (Inherited: 0x148, Single: 0xffffff20)
class UFortBTDecorator_IsTakerAirborne : public UBTDecorator
{
public:
};

static_assert(sizeof(UFortBTDecorator_IsTakerAirborne) == 0x68, "Size mismatch for UFortBTDecorator_IsTakerAirborne");

// Size: 0x98 (Inherited: 0x148, Single: 0xffffff50)
class UFortBTDecorator_WeaponStatus : public UBTDecorator
{
public:
    float WeaponStatusUpdateRate; // 0x68 (Size: 0x4, Type: FloatProperty)
    uint8_t bTestIfCurrentWeaponIsValid : 1; // 0x6c:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bCurrentWeaponShouldBeValid : 1; // 0x6c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bTestAllowedCurrentWeaponTags : 1; // 0x6c:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6d[0x3]; // 0x6d (Size: 0x3, Type: PaddingProperty)
    FGameplayTagContainer AllowedCurrentWeaponTags; // 0x70 (Size: 0x20, Type: StructProperty)
    uint8_t bTestIfCurrentWeaponIsReloading : 1; // 0x90:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bCurrentWeaponShouldBeReloading : 1; // 0x90:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bTestIfCurrentWeaponHasAmmoInMagazine : 1; // 0x90:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bCurrentWeaponShouldHaveAmmoInMagazine : 1; // 0x90:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bTestIfCurrentWeaponHasExtraAmmo : 1; // 0x90:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bCurrentWeaponShouldHaveExtraAmmo : 1; // 0x90:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bAllInterestedTestsMustPass : 1; // 0x90:6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTDecorator_WeaponStatus) == 0x98, "Size mismatch for UFortBTDecorator_WeaponStatus");
static_assert(offsetof(UFortBTDecorator_WeaponStatus, WeaponStatusUpdateRate) == 0x68, "Offset mismatch for UFortBTDecorator_WeaponStatus::WeaponStatusUpdateRate");
static_assert(offsetof(UFortBTDecorator_WeaponStatus, bTestIfCurrentWeaponIsValid) == 0x6c, "Offset mismatch for UFortBTDecorator_WeaponStatus::bTestIfCurrentWeaponIsValid");
static_assert(offsetof(UFortBTDecorator_WeaponStatus, bCurrentWeaponShouldBeValid) == 0x6c, "Offset mismatch for UFortBTDecorator_WeaponStatus::bCurrentWeaponShouldBeValid");
static_assert(offsetof(UFortBTDecorator_WeaponStatus, bTestAllowedCurrentWeaponTags) == 0x6c, "Offset mismatch for UFortBTDecorator_WeaponStatus::bTestAllowedCurrentWeaponTags");
static_assert(offsetof(UFortBTDecorator_WeaponStatus, AllowedCurrentWeaponTags) == 0x70, "Offset mismatch for UFortBTDecorator_WeaponStatus::AllowedCurrentWeaponTags");
static_assert(offsetof(UFortBTDecorator_WeaponStatus, bTestIfCurrentWeaponIsReloading) == 0x90, "Offset mismatch for UFortBTDecorator_WeaponStatus::bTestIfCurrentWeaponIsReloading");
static_assert(offsetof(UFortBTDecorator_WeaponStatus, bCurrentWeaponShouldBeReloading) == 0x90, "Offset mismatch for UFortBTDecorator_WeaponStatus::bCurrentWeaponShouldBeReloading");
static_assert(offsetof(UFortBTDecorator_WeaponStatus, bTestIfCurrentWeaponHasAmmoInMagazine) == 0x90, "Offset mismatch for UFortBTDecorator_WeaponStatus::bTestIfCurrentWeaponHasAmmoInMagazine");
static_assert(offsetof(UFortBTDecorator_WeaponStatus, bCurrentWeaponShouldHaveAmmoInMagazine) == 0x90, "Offset mismatch for UFortBTDecorator_WeaponStatus::bCurrentWeaponShouldHaveAmmoInMagazine");
static_assert(offsetof(UFortBTDecorator_WeaponStatus, bTestIfCurrentWeaponHasExtraAmmo) == 0x90, "Offset mismatch for UFortBTDecorator_WeaponStatus::bTestIfCurrentWeaponHasExtraAmmo");
static_assert(offsetof(UFortBTDecorator_WeaponStatus, bCurrentWeaponShouldHaveExtraAmmo) == 0x90, "Offset mismatch for UFortBTDecorator_WeaponStatus::bCurrentWeaponShouldHaveExtraAmmo");
static_assert(offsetof(UFortBTDecorator_WeaponStatus, bAllInterestedTestsMustPass) == 0x90, "Offset mismatch for UFortBTDecorator_WeaponStatus::bAllInterestedTestsMustPass");

// Size: 0x158 (Inherited: 0x1e8, Single: 0xffffff70)
class UFortBTService_ActivateAbility : public UBTService_BlueprintBase
{
public:
    FValueOrBBKey_GameplayTagContainer AbilityTags; // 0x98 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector TargetActorKey; // 0xc0 (Size: 0x28, Type: StructProperty)
    bool bRequireCanHitTargetWithAbility; // 0xe8 (Size: 0x1, Type: BoolProperty)
    bool bPawnTargetsOnly; // 0xe9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ea[0x6]; // 0xea (Size: 0x6, Type: PaddingProperty)
    FGameplayTagContainer ProhibitedTargetTags; // 0xf0 (Size: 0x20, Type: StructProperty)
    FValueOrBBKey_Bool bCanActivateWhenMoving; // 0x110 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_11c[0x4]; // 0x11c (Size: 0x4, Type: PaddingProperty)
    TArray<FDistanceToTargetComparison> DistanceChecks; // 0x120 (Size: 0x10, Type: ArrayProperty)
    FValueOrBBKey_Float InitialDelayTime; // 0x130 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float InitialDelayRandomDeviation; // 0x13c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool WantsReceiveActivatedAbilityEnded; // 0x148 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_154[0x4]; // 0x154 (Size: 0x4, Type: PaddingProperty)

protected:
    virtual void ReceiveActivatedAbilityEnded(AAIController*& OwnerAIController); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortBTService_ActivateAbility) == 0x158, "Size mismatch for UFortBTService_ActivateAbility");
static_assert(offsetof(UFortBTService_ActivateAbility, AbilityTags) == 0x98, "Offset mismatch for UFortBTService_ActivateAbility::AbilityTags");
static_assert(offsetof(UFortBTService_ActivateAbility, TargetActorKey) == 0xc0, "Offset mismatch for UFortBTService_ActivateAbility::TargetActorKey");
static_assert(offsetof(UFortBTService_ActivateAbility, bRequireCanHitTargetWithAbility) == 0xe8, "Offset mismatch for UFortBTService_ActivateAbility::bRequireCanHitTargetWithAbility");
static_assert(offsetof(UFortBTService_ActivateAbility, bPawnTargetsOnly) == 0xe9, "Offset mismatch for UFortBTService_ActivateAbility::bPawnTargetsOnly");
static_assert(offsetof(UFortBTService_ActivateAbility, ProhibitedTargetTags) == 0xf0, "Offset mismatch for UFortBTService_ActivateAbility::ProhibitedTargetTags");
static_assert(offsetof(UFortBTService_ActivateAbility, bCanActivateWhenMoving) == 0x110, "Offset mismatch for UFortBTService_ActivateAbility::bCanActivateWhenMoving");
static_assert(offsetof(UFortBTService_ActivateAbility, DistanceChecks) == 0x120, "Offset mismatch for UFortBTService_ActivateAbility::DistanceChecks");
static_assert(offsetof(UFortBTService_ActivateAbility, InitialDelayTime) == 0x130, "Offset mismatch for UFortBTService_ActivateAbility::InitialDelayTime");
static_assert(offsetof(UFortBTService_ActivateAbility, InitialDelayRandomDeviation) == 0x13c, "Offset mismatch for UFortBTService_ActivateAbility::InitialDelayRandomDeviation");
static_assert(offsetof(UFortBTService_ActivateAbility, WantsReceiveActivatedAbilityEnded) == 0x148, "Offset mismatch for UFortBTService_ActivateAbility::WantsReceiveActivatedAbilityEnded");

// Size: 0xc0 (Inherited: 0x150, Single: 0xffffff70)
class UFortBTService_UpdateBotMissionBuilding : public UBTService
{
public:
    FBlackboardKeySelector InterestLocationKey; // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector BuildOrderKey; // 0x98 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UFortBTService_UpdateBotMissionBuilding) == 0xc0, "Size mismatch for UFortBTService_UpdateBotMissionBuilding");
static_assert(offsetof(UFortBTService_UpdateBotMissionBuilding, InterestLocationKey) == 0x70, "Offset mismatch for UFortBTService_UpdateBotMissionBuilding::InterestLocationKey");
static_assert(offsetof(UFortBTService_UpdateBotMissionBuilding, BuildOrderKey) == 0x98, "Offset mismatch for UFortBTService_UpdateBotMissionBuilding::BuildOrderKey");

// Size: 0xa0 (Inherited: 0x1e8, Single: 0xfffffeb8)
class UFortBTService_UpdateBotMissionGoal : public UBTService_BlackboardBase
{
public:
    uint8_t bRequireInteraction : 1; // 0x98:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bRequireInteractionOrLocator : 1; // 0x98:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bRequireEncounter : 1; // 0x98:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bPickClosest : 1; // 0x98:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTService_UpdateBotMissionGoal) == 0xa0, "Size mismatch for UFortBTService_UpdateBotMissionGoal");
static_assert(offsetof(UFortBTService_UpdateBotMissionGoal, bRequireInteraction) == 0x98, "Offset mismatch for UFortBTService_UpdateBotMissionGoal::bRequireInteraction");
static_assert(offsetof(UFortBTService_UpdateBotMissionGoal, bRequireInteractionOrLocator) == 0x98, "Offset mismatch for UFortBTService_UpdateBotMissionGoal::bRequireInteractionOrLocator");
static_assert(offsetof(UFortBTService_UpdateBotMissionGoal, bRequireEncounter) == 0x98, "Offset mismatch for UFortBTService_UpdateBotMissionGoal::bRequireEncounter");
static_assert(offsetof(UFortBTService_UpdateBotMissionGoal, bPickClosest) == 0x98, "Offset mismatch for UFortBTService_UpdateBotMissionGoal::bPickClosest");

// Size: 0x98 (Inherited: 0x188, Single: 0xffffff10)
class UFortBTTask_BotMissionBuild : public UBTTask_BlackboardBase
{
public:
};

static_assert(sizeof(UFortBTTask_BotMissionBuild) == 0x98, "Size mismatch for UFortBTTask_BotMissionBuild");

// Size: 0x98 (Inherited: 0x188, Single: 0xffffff10)
class UFortBTTask_BotMissionInteract : public UBTTask_BlackboardBase
{
public:
};

static_assert(sizeof(UFortBTTask_BotMissionInteract) == 0x98, "Size mismatch for UFortBTTask_BotMissionInteract");

// Size: 0xf0 (Inherited: 0x170, Single: 0xffffff80)
class UFortBTTask_ExecuteGameplayAbility : public UBTTask_GameplayTaskBase
{
public:
    FValueOrBBKey_GameplayTagContainer GameplayAbilityTagContainer; // 0x80 (Size: 0x28, Type: StructProperty)
    FGameplayTagContainer GameplayAbilityTag; // 0xa8 (Size: 0x20, Type: StructProperty)
    FBlackboardKeySelector GameplayAbilityTagBlackboardKey; // 0xc8 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UFortBTTask_ExecuteGameplayAbility) == 0xf0, "Size mismatch for UFortBTTask_ExecuteGameplayAbility");
static_assert(offsetof(UFortBTTask_ExecuteGameplayAbility, GameplayAbilityTagContainer) == 0x80, "Offset mismatch for UFortBTTask_ExecuteGameplayAbility::GameplayAbilityTagContainer");
static_assert(offsetof(UFortBTTask_ExecuteGameplayAbility, GameplayAbilityTag) == 0xa8, "Offset mismatch for UFortBTTask_ExecuteGameplayAbility::GameplayAbilityTag");
static_assert(offsetof(UFortBTTask_ExecuteGameplayAbility, GameplayAbilityTagBlackboardKey) == 0xc8, "Offset mismatch for UFortBTTask_ExecuteGameplayAbility::GameplayAbilityTagBlackboardKey");

// Size: 0x1a0 (Inherited: 0x458, Single: 0xfffffd48)
class UFortBTTask_GameMoveDirectlyToward : public UFortBTTask_GameMoveTo
{
public:
};

static_assert(sizeof(UFortBTTask_GameMoveDirectlyToward) == 0x1a0, "Size mismatch for UFortBTTask_GameMoveDirectlyToward");

// Size: 0x1a0 (Inherited: 0x2b8, Single: 0xfffffee8)
class UFortBTTask_GameMoveTo : public UBTTask_MoveTo
{
public:
    FBlackboardKeySelector FocalPointWhileMoving; // 0x130 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<EPathObstacleAction> PathObstacleAction; // 0x158 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_159[0x7]; // 0x159 (Size: 0x7, Type: PaddingProperty)
    UClass* PushBumpedPawnClass; // 0x160 (Size: 0x8, Type: ClassProperty)
    FGameplayTag NavFilterTag; // 0x168 (Size: 0x4, Type: StructProperty)
    uint8_t bDetectUnexpectedPathBlockingObstacles : 1; // 0x16c:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableSlowdownAtGoal : 1; // 0x16c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bStopAtGoal : 1; // 0x16c:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bFinishMoveOnOverlap : 1; // 0x16c:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bUpdateMoveOnBlackboardKeyChanges : 1; // 0x16c:4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_16d[0x3]; // 0x16d (Size: 0x3, Type: PaddingProperty)
    FBlackboardKeySelector AcceptableRadiusKey; // 0x170 (Size: 0x28, Type: StructProperty)
    uint8_t bDeimosFlavor : 1; // 0x198:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_199[0x7]; // 0x199 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTTask_GameMoveTo) == 0x1a0, "Size mismatch for UFortBTTask_GameMoveTo");
static_assert(offsetof(UFortBTTask_GameMoveTo, FocalPointWhileMoving) == 0x130, "Offset mismatch for UFortBTTask_GameMoveTo::FocalPointWhileMoving");
static_assert(offsetof(UFortBTTask_GameMoveTo, PathObstacleAction) == 0x158, "Offset mismatch for UFortBTTask_GameMoveTo::PathObstacleAction");
static_assert(offsetof(UFortBTTask_GameMoveTo, PushBumpedPawnClass) == 0x160, "Offset mismatch for UFortBTTask_GameMoveTo::PushBumpedPawnClass");
static_assert(offsetof(UFortBTTask_GameMoveTo, NavFilterTag) == 0x168, "Offset mismatch for UFortBTTask_GameMoveTo::NavFilterTag");
static_assert(offsetof(UFortBTTask_GameMoveTo, bDetectUnexpectedPathBlockingObstacles) == 0x16c, "Offset mismatch for UFortBTTask_GameMoveTo::bDetectUnexpectedPathBlockingObstacles");
static_assert(offsetof(UFortBTTask_GameMoveTo, bEnableSlowdownAtGoal) == 0x16c, "Offset mismatch for UFortBTTask_GameMoveTo::bEnableSlowdownAtGoal");
static_assert(offsetof(UFortBTTask_GameMoveTo, bStopAtGoal) == 0x16c, "Offset mismatch for UFortBTTask_GameMoveTo::bStopAtGoal");
static_assert(offsetof(UFortBTTask_GameMoveTo, bFinishMoveOnOverlap) == 0x16c, "Offset mismatch for UFortBTTask_GameMoveTo::bFinishMoveOnOverlap");
static_assert(offsetof(UFortBTTask_GameMoveTo, bUpdateMoveOnBlackboardKeyChanges) == 0x16c, "Offset mismatch for UFortBTTask_GameMoveTo::bUpdateMoveOnBlackboardKeyChanges");
static_assert(offsetof(UFortBTTask_GameMoveTo, AcceptableRadiusKey) == 0x170, "Offset mismatch for UFortBTTask_GameMoveTo::AcceptableRadiusKey");
static_assert(offsetof(UFortBTTask_GameMoveTo, bDeimosFlavor) == 0x198, "Offset mismatch for UFortBTTask_GameMoveTo::bDeimosFlavor");

// Size: 0x70 (Inherited: 0xf0, Single: 0xffffff80)
class UFortBTTask_RequestUndermining : public UBTTaskNode
{
public:
};

static_assert(sizeof(UFortBTTask_RequestUndermining) == 0x70, "Size mismatch for UFortBTTask_RequestUndermining");

// Size: 0xc8 (Inherited: 0x230, Single: 0xfffffe98)
class UFortBTTask_RotateToFaceBBEntryWithTags : public UBTTask_RotateToFaceBBEntry
{
public:
    FGameplayTagContainer TagsToApply; // 0xa8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UFortBTTask_RotateToFaceBBEntryWithTags) == 0xc8, "Size mismatch for UFortBTTask_RotateToFaceBBEntryWithTags");
static_assert(offsetof(UFortBTTask_RotateToFaceBBEntryWithTags, TagsToApply) == 0xa8, "Offset mismatch for UFortBTTask_RotateToFaceBBEntryWithTags::TagsToApply");

// Size: 0xc8 (Inherited: 0x1b8, Single: 0xffffff10)
class UFortBTTask_RunDynamicStateTree : public UBTTask_RunDynamicStateTree
{
public:
};

static_assert(sizeof(UFortBTTask_RunDynamicStateTree) == 0xc8, "Size mismatch for UFortBTTask_RunDynamicStateTree");

// Size: 0x78 (Inherited: 0xf0, Single: 0xffffff88)
class UFortBTTask_SetFrustrationDiscouragement : public UBTTaskNode
{
public:
    float DiscouragementDuration; // 0x70 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortBTTask_SetFrustrationDiscouragement) == 0x78, "Size mismatch for UFortBTTask_SetFrustrationDiscouragement");
static_assert(offsetof(UFortBTTask_SetFrustrationDiscouragement, DiscouragementDuration) == 0x70, "Offset mismatch for UFortBTTask_SetFrustrationDiscouragement::DiscouragementDuration");

// Size: 0x70 (Inherited: 0xf0, Single: 0xffffff80)
class UFortBTTask_Sleep : public UBTTaskNode
{
public:
};

static_assert(sizeof(UFortBTTask_Sleep) == 0x70, "Size mismatch for UFortBTTask_Sleep");

// Size: 0x130 (Inherited: 0x2b8, Single: 0xfffffe78)
class UFortBTTask_TakerMoveToNavmesh : public UBTTask_MoveTo
{
public:
};

static_assert(sizeof(UFortBTTask_TakerMoveToNavmesh) == 0x130, "Size mismatch for UFortBTTask_TakerMoveToNavmesh");

// Size: 0x2e0 (Inherited: 0x2d0, Single: 0x10)
class AFortEQSPrevisActor : public AActor
{
public:
    uint8_t Pad_2a8[0x10]; // 0x2a8 (Size: 0x10, Type: PaddingProperty)
    USceneComponent* SceneRoot; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer GameplayTags; // 0x2c0 (Size: 0x20, Type: StructProperty)

public:
    virtual void PrepForPrevis(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    void SetQueryTemplate(UEnvQuery*& InPrevisQueryTemplate); // 0x6023a08 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(AFortEQSPrevisActor) == 0x2e0, "Size mismatch for AFortEQSPrevisActor");
static_assert(offsetof(AFortEQSPrevisActor, SceneRoot) == 0x2b8, "Offset mismatch for AFortEQSPrevisActor::SceneRoot");
static_assert(offsetof(AFortEQSPrevisActor, GameplayTags) == 0x2c0, "Offset mismatch for AFortEQSPrevisActor::GameplayTags");

// Size: 0x3d8 (Inherited: 0x9d8, Single: 0xfffffa00)
class AFortEQSTestingController : public AAIController
{
public:
};

static_assert(sizeof(AFortEQSTestingController) == 0x3d8, "Size mismatch for AFortEQSTestingController");

// Size: 0x6e0 (Inherited: 0xd30, Single: 0xfffff9b0)
class AFortEQSTestingPawn : public AEQSTestingPawn
{
public:
    bool bUseDoorNavLinks; // 0x6d0 (Size: 0x1, Type: BoolProperty)
    bool bUseClamberNavLinks; // 0x6d1 (Size: 0x1, Type: BoolProperty)
    bool bUseHurdleNavLinks; // 0x6d2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6d3[0xd]; // 0x6d3 (Size: 0xd, Type: PaddingProperty)
};

static_assert(sizeof(AFortEQSTestingPawn) == 0x6e0, "Size mismatch for AFortEQSTestingPawn");
static_assert(offsetof(AFortEQSTestingPawn, bUseDoorNavLinks) == 0x6d0, "Offset mismatch for AFortEQSTestingPawn::bUseDoorNavLinks");
static_assert(offsetof(AFortEQSTestingPawn, bUseClamberNavLinks) == 0x6d1, "Offset mismatch for AFortEQSTestingPawn::bUseClamberNavLinks");
static_assert(offsetof(AFortEQSTestingPawn, bUseHurdleNavLinks) == 0x6d2, "Offset mismatch for AFortEQSTestingPawn::bUseHurdleNavLinks");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_AIPawnSpawnLocation : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_AIPawnSpawnLocation) == 0x28, "Size mismatch for UFortQueryContext_AIPawnSpawnLocation");

// Size: 0x78 (Inherited: 0x50, Single: 0x28)
class UFortQueryContext_AllBots : public UEnvQueryContext
{
public:
    bool bIncludeOnlyAthenaGameParticipantBots; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagQuery BotTagQuery; // 0x30 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UFortQueryContext_AllBots) == 0x78, "Size mismatch for UFortQueryContext_AllBots");
static_assert(offsetof(UFortQueryContext_AllBots, bIncludeOnlyAthenaGameParticipantBots) == 0x28, "Offset mismatch for UFortQueryContext_AllBots::bIncludeOnlyAthenaGameParticipantBots");
static_assert(offsetof(UFortQueryContext_AllBots, BotTagQuery) == 0x30, "Offset mismatch for UFortQueryContext_AllBots::BotTagQuery");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_AllEnemies : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_AllEnemies) == 0x28, "Size mismatch for UFortQueryContext_AllEnemies");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_AllGoals : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_AllGoals) == 0x28, "Size mismatch for UFortQueryContext_AllGoals");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_AllPlayers : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_AllPlayers) == 0x28, "Size mismatch for UFortQueryContext_AllPlayers");

// Size: 0x70 (Inherited: 0x50, Single: 0x20)
class UFortQueryContext_AllPOIVolumes : public UEnvQueryContext
{
public:
    FGameplayTagQuery VolumeLocationTagQuery; // 0x28 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UFortQueryContext_AllPOIVolumes) == 0x70, "Size mismatch for UFortQueryContext_AllPOIVolumes");
static_assert(offsetof(UFortQueryContext_AllPOIVolumes, VolumeLocationTagQuery) == 0x28, "Offset mismatch for UFortQueryContext_AllPOIVolumes::VolumeLocationTagQuery");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_AthenaCurrentSafeZoneCenter : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_AthenaCurrentSafeZoneCenter) == 0x28, "Size mismatch for UFortQueryContext_AthenaCurrentSafeZoneCenter");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_AthenaCurrentSafeZoneIndicatorCenter : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_AthenaCurrentSafeZoneIndicatorCenter) == 0x28, "Size mismatch for UFortQueryContext_AthenaCurrentSafeZoneIndicatorCenter");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_AthenaSafeZonePredictedLocation : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_AthenaSafeZonePredictedLocation) == 0x28, "Size mismatch for UFortQueryContext_AthenaSafeZonePredictedLocation");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_BlackboardKeyLeader : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_BlackboardKeyLeader) == 0x28, "Size mismatch for UFortQueryContext_BlackboardKeyLeader");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_BuildingRifts : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_BuildingRifts) == 0x28, "Size mismatch for UFortQueryContext_BuildingRifts");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_EncounterFallbackTarget : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_EncounterFallbackTarget) == 0x28, "Size mismatch for UFortQueryContext_EncounterFallbackTarget");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_EncounterGoalsCenterLocation : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_EncounterGoalsCenterLocation) == 0x28, "Size mismatch for UFortQueryContext_EncounterGoalsCenterLocation");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_EncounterGoalsOnGround : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_EncounterGoalsOnGround) == 0x28, "Size mismatch for UFortQueryContext_EncounterGoalsOnGround");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_EncounterPrimaryAssignmentGoals : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_EncounterPrimaryAssignmentGoals) == 0x28, "Size mismatch for UFortQueryContext_EncounterPrimaryAssignmentGoals");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_EncounterProvidedQueryLocations : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_EncounterProvidedQueryLocations) == 0x28, "Size mismatch for UFortQueryContext_EncounterProvidedQueryLocations");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_EncounterQueryActor : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_EncounterQueryActor) == 0x28, "Size mismatch for UFortQueryContext_EncounterQueryActor");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_EncounterRandomDirection : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_EncounterRandomDirection) == 0x28, "Size mismatch for UFortQueryContext_EncounterRandomDirection");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_EncounterTargetObjective : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_EncounterTargetObjective) == 0x28, "Size mismatch for UFortQueryContext_EncounterTargetObjective");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_Goal : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_Goal) == 0x28, "Size mismatch for UFortQueryContext_Goal");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_GoalProviderRootAssignmentGoals : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_GoalProviderRootAssignmentGoals) == 0x28, "Size mismatch for UFortQueryContext_GoalProviderRootAssignmentGoals");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_Goal_SpawnLocation : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_Goal_SpawnLocation) == 0x28, "Size mismatch for UFortQueryContext_Goal_SpawnLocation");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_NearbyAIPawns : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_NearbyAIPawns) == 0x28, "Size mismatch for UFortQueryContext_NearbyAIPawns");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_NearbyAIPawnsMoveDestinations : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_NearbyAIPawnsMoveDestinations) == 0x28, "Size mismatch for UFortQueryContext_NearbyAIPawnsMoveDestinations");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_NearbyFriendlyAIPawns : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_NearbyFriendlyAIPawns) == 0x28, "Size mismatch for UFortQueryContext_NearbyFriendlyAIPawns");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_NearbyFriendlyAIPawnsAndPlayerPawns : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_NearbyFriendlyAIPawnsAndPlayerPawns) == 0x28, "Size mismatch for UFortQueryContext_NearbyFriendlyAIPawnsAndPlayerPawns");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_NearbyFriends : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_NearbyFriends) == 0x28, "Size mismatch for UFortQueryContext_NearbyFriends");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_PlayerSpawnPad : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_PlayerSpawnPad) == 0x28, "Size mismatch for UFortQueryContext_PlayerSpawnPad");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_RandomDirectionXY : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_RandomDirectionXY) == 0x28, "Size mismatch for UFortQueryContext_RandomDirectionXY");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_SpawnSpotActorLocationOrAIPawnSpawnLocation : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_SpawnSpotActorLocationOrAIPawnSpawnLocation) == 0x28, "Size mismatch for UFortQueryContext_SpawnSpotActorLocationOrAIPawnSpawnLocation");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_StWStormShield : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_StWStormShield) == 0x28, "Size mismatch for UFortQueryContext_StWStormShield");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_TwoPointSolverPointA : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_TwoPointSolverPointA) == 0x28, "Size mismatch for UFortQueryContext_TwoPointSolverPointA");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_TwoPointSolverRotationA : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_TwoPointSolverRotationA) == 0x28, "Size mismatch for UFortQueryContext_TwoPointSolverRotationA");

// Size: 0x90 (Inherited: 0x58, Single: 0x38)
class UFortQueryData_CurvesAroundLine : public UDataAsset
{
public:
    FFortPointsOnCurve PointsOnSideA; // 0x30 (Size: 0x30, Type: StructProperty)
    FFortPointsOnCurve PointsOnSideB; // 0x60 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(UFortQueryData_CurvesAroundLine) == 0x90, "Size mismatch for UFortQueryData_CurvesAroundLine");
static_assert(offsetof(UFortQueryData_CurvesAroundLine, PointsOnSideA) == 0x30, "Offset mismatch for UFortQueryData_CurvesAroundLine::PointsOnSideA");
static_assert(offsetof(UFortQueryData_CurvesAroundLine, PointsOnSideB) == 0x60, "Offset mismatch for UFortQueryData_CurvesAroundLine::PointsOnSideB");

// Size: 0xd0 (Inherited: 0x178, Single: 0xffffff58)
class UFortQueryGenerator_ActorsAround : public UEnvQueryGenerator_ActorsOfClass
{
public:
};

static_assert(sizeof(UFortQueryGenerator_ActorsAround) == 0xd0, "Size mismatch for UFortQueryGenerator_ActorsAround");

// Size: 0x50 (Inherited: 0xa8, Single: 0xffffffa8)
class UFortQueryGenerator_Allies : public UEnvQueryGenerator
{
public:
};

static_assert(sizeof(UFortQueryGenerator_Allies) == 0x50, "Size mismatch for UFortQueryGenerator_Allies");

// Size: 0x50 (Inherited: 0xa8, Single: 0xffffffa8)
class UFortQueryGenerator_AssignmentGoal : public UEnvQueryGenerator
{
public:
};

static_assert(sizeof(UFortQueryGenerator_AssignmentGoal) == 0x50, "Size mismatch for UFortQueryGenerator_AssignmentGoal");

// Size: 0x50 (Inherited: 0xa8, Single: 0xffffffa8)
class UFortQueryGenerator_BuildingRifts : public UEnvQueryGenerator
{
public:
};

static_assert(sizeof(UFortQueryGenerator_BuildingRifts) == 0x50, "Size mismatch for UFortQueryGenerator_BuildingRifts");

// Size: 0x228 (Inherited: 0xa8, Single: 0x180)
class UFortQueryGenerator_Buildings : public UEnvQueryGenerator
{
public:
    FFortAIAssignmentIdentifier AssignmentIdentifier; // 0x50 (Size: 0x30, Type: StructProperty)
    UFortAIAssignmentSettings* AssignmentSettings; // 0x80 (Size: 0x8, Type: ObjectProperty)
    UClass* BuildingGridVolumeCenter; // 0x88 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderIntValue HorizontalBuildingCellRadius; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue BuildingCellsAbove; // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue BuildingCellsBelow; // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bIncludeWalls; // 0x138 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bIncludeFloors; // 0x170 (Size: 0x38, Type: StructProperty)
    TArray<EFloorPatternType> FloorPatternsToIgnore; // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    FAIDataProviderBoolValue bIncludeCenterCell; // 0x1b8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue MaxBuildingActorsPerVolumeCenterToCollect; // 0x1f0 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_Buildings) == 0x228, "Size mismatch for UFortQueryGenerator_Buildings");
static_assert(offsetof(UFortQueryGenerator_Buildings, AssignmentIdentifier) == 0x50, "Offset mismatch for UFortQueryGenerator_Buildings::AssignmentIdentifier");
static_assert(offsetof(UFortQueryGenerator_Buildings, AssignmentSettings) == 0x80, "Offset mismatch for UFortQueryGenerator_Buildings::AssignmentSettings");
static_assert(offsetof(UFortQueryGenerator_Buildings, BuildingGridVolumeCenter) == 0x88, "Offset mismatch for UFortQueryGenerator_Buildings::BuildingGridVolumeCenter");
static_assert(offsetof(UFortQueryGenerator_Buildings, HorizontalBuildingCellRadius) == 0x90, "Offset mismatch for UFortQueryGenerator_Buildings::HorizontalBuildingCellRadius");
static_assert(offsetof(UFortQueryGenerator_Buildings, BuildingCellsAbove) == 0xc8, "Offset mismatch for UFortQueryGenerator_Buildings::BuildingCellsAbove");
static_assert(offsetof(UFortQueryGenerator_Buildings, BuildingCellsBelow) == 0x100, "Offset mismatch for UFortQueryGenerator_Buildings::BuildingCellsBelow");
static_assert(offsetof(UFortQueryGenerator_Buildings, bIncludeWalls) == 0x138, "Offset mismatch for UFortQueryGenerator_Buildings::bIncludeWalls");
static_assert(offsetof(UFortQueryGenerator_Buildings, bIncludeFloors) == 0x170, "Offset mismatch for UFortQueryGenerator_Buildings::bIncludeFloors");
static_assert(offsetof(UFortQueryGenerator_Buildings, FloorPatternsToIgnore) == 0x1a8, "Offset mismatch for UFortQueryGenerator_Buildings::FloorPatternsToIgnore");
static_assert(offsetof(UFortQueryGenerator_Buildings, bIncludeCenterCell) == 0x1b8, "Offset mismatch for UFortQueryGenerator_Buildings::bIncludeCenterCell");
static_assert(offsetof(UFortQueryGenerator_Buildings, MaxBuildingActorsPerVolumeCenterToCollect) == 0x1f0, "Offset mismatch for UFortQueryGenerator_Buildings::MaxBuildingActorsPerVolumeCenterToCollect");

// Size: 0x100 (Inherited: 0xa8, Single: 0x58)
class UFortQueryGenerator_BuildingsOnCachedPath : public UEnvQueryGenerator
{
public:
    UClass* CachedPathSource; // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderBoolValue bIncludeWalls; // 0x58 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bIncludeFloors; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bIncludeCenterCell; // 0xc8 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_BuildingsOnCachedPath) == 0x100, "Size mismatch for UFortQueryGenerator_BuildingsOnCachedPath");
static_assert(offsetof(UFortQueryGenerator_BuildingsOnCachedPath, CachedPathSource) == 0x50, "Offset mismatch for UFortQueryGenerator_BuildingsOnCachedPath::CachedPathSource");
static_assert(offsetof(UFortQueryGenerator_BuildingsOnCachedPath, bIncludeWalls) == 0x58, "Offset mismatch for UFortQueryGenerator_BuildingsOnCachedPath::bIncludeWalls");
static_assert(offsetof(UFortQueryGenerator_BuildingsOnCachedPath, bIncludeFloors) == 0x90, "Offset mismatch for UFortQueryGenerator_BuildingsOnCachedPath::bIncludeFloors");
static_assert(offsetof(UFortQueryGenerator_BuildingsOnCachedPath, bIncludeCenterCell) == 0xc8, "Offset mismatch for UFortQueryGenerator_BuildingsOnCachedPath::bIncludeCenterCell");

// Size: 0x50 (Inherited: 0xa8, Single: 0xffffffa8)
class UFortQueryGenerator_EncounterTargets : public UEnvQueryGenerator
{
public:
};

static_assert(sizeof(UFortQueryGenerator_EncounterTargets) == 0x50, "Size mismatch for UFortQueryGenerator_EncounterTargets");

// Size: 0xd0 (Inherited: 0xa8, Single: 0x28)
class UFortQueryGenerator_Enemies : public UEnvQueryGenerator
{
public:
    bool bPerceivedEnemiesOnly; // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bSleepCapableAIUsePerceivedEnemiesOnly; // 0x51 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreDBNOPawns; // 0x52 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreSleepingAIs; // 0x53 (Size: 0x1, Type: BoolProperty)
    bool bAddEnemiesFromAbilityRange; // 0x54 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_55[0x3]; // 0x55 (Size: 0x3, Type: PaddingProperty)
    FGameplayTagContainer AbilityTags; // 0x58 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer DistanceTags; // 0x78 (Size: 0x20, Type: StructProperty)
    FAIDataProviderFloatValue MaxTimeSincePerceived; // 0x98 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_Enemies) == 0xd0, "Size mismatch for UFortQueryGenerator_Enemies");
static_assert(offsetof(UFortQueryGenerator_Enemies, bPerceivedEnemiesOnly) == 0x50, "Offset mismatch for UFortQueryGenerator_Enemies::bPerceivedEnemiesOnly");
static_assert(offsetof(UFortQueryGenerator_Enemies, bSleepCapableAIUsePerceivedEnemiesOnly) == 0x51, "Offset mismatch for UFortQueryGenerator_Enemies::bSleepCapableAIUsePerceivedEnemiesOnly");
static_assert(offsetof(UFortQueryGenerator_Enemies, bIgnoreDBNOPawns) == 0x52, "Offset mismatch for UFortQueryGenerator_Enemies::bIgnoreDBNOPawns");
static_assert(offsetof(UFortQueryGenerator_Enemies, bIgnoreSleepingAIs) == 0x53, "Offset mismatch for UFortQueryGenerator_Enemies::bIgnoreSleepingAIs");
static_assert(offsetof(UFortQueryGenerator_Enemies, bAddEnemiesFromAbilityRange) == 0x54, "Offset mismatch for UFortQueryGenerator_Enemies::bAddEnemiesFromAbilityRange");
static_assert(offsetof(UFortQueryGenerator_Enemies, AbilityTags) == 0x58, "Offset mismatch for UFortQueryGenerator_Enemies::AbilityTags");
static_assert(offsetof(UFortQueryGenerator_Enemies, DistanceTags) == 0x78, "Offset mismatch for UFortQueryGenerator_Enemies::DistanceTags");
static_assert(offsetof(UFortQueryGenerator_Enemies, MaxTimeSincePerceived) == 0x98, "Offset mismatch for UFortQueryGenerator_Enemies::MaxTimeSincePerceived");

// Size: 0x98 (Inherited: 0xa8, Single: 0xfffffff0)
class UFortQueryGenerator_GoalActorsOfClass : public UEnvQueryGenerator
{
public:
    UClass* SearchedActorClass; // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue SearchRadius; // 0x58 (Size: 0x38, Type: StructProperty)
    UClass* SearchCenter; // 0x90 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_GoalActorsOfClass) == 0x98, "Size mismatch for UFortQueryGenerator_GoalActorsOfClass");
static_assert(offsetof(UFortQueryGenerator_GoalActorsOfClass, SearchedActorClass) == 0x50, "Offset mismatch for UFortQueryGenerator_GoalActorsOfClass::SearchedActorClass");
static_assert(offsetof(UFortQueryGenerator_GoalActorsOfClass, SearchRadius) == 0x58, "Offset mismatch for UFortQueryGenerator_GoalActorsOfClass::SearchRadius");
static_assert(offsetof(UFortQueryGenerator_GoalActorsOfClass, SearchCenter) == 0x90, "Offset mismatch for UFortQueryGenerator_GoalActorsOfClass::SearchCenter");

// Size: 0x268 (Inherited: 0x360, Single: 0xffffff08)
class UFortQueryGenerator_GoalOnCircle : public UEnvQueryGenerator_OnCircle
{
public:
    bool bIncludeCenterActorInGeneratedGoals; // 0x228 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_229[0x7]; // 0x229 (Size: 0x7, Type: PaddingProperty)
    UFortAIAssignmentSettings* OptionalAssignmentSettings; // 0x230 (Size: 0x8, Type: ObjectProperty)
    FFortAIAssignmentIdentifier OptionalAssignmentIdentifier; // 0x238 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_GoalOnCircle) == 0x268, "Size mismatch for UFortQueryGenerator_GoalOnCircle");
static_assert(offsetof(UFortQueryGenerator_GoalOnCircle, bIncludeCenterActorInGeneratedGoals) == 0x228, "Offset mismatch for UFortQueryGenerator_GoalOnCircle::bIncludeCenterActorInGeneratedGoals");
static_assert(offsetof(UFortQueryGenerator_GoalOnCircle, OptionalAssignmentSettings) == 0x230, "Offset mismatch for UFortQueryGenerator_GoalOnCircle::OptionalAssignmentSettings");
static_assert(offsetof(UFortQueryGenerator_GoalOnCircle, OptionalAssignmentIdentifier) == 0x238, "Offset mismatch for UFortQueryGenerator_GoalOnCircle::OptionalAssignmentIdentifier");

// Size: 0x58 (Inherited: 0xa8, Single: 0xffffffb0)
class UFortQueryGenerator_GoalPlayerPawns : public UEnvQueryGenerator
{
public:
    bool bOnlyAthenaGameParticipants; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryGenerator_GoalPlayerPawns) == 0x58, "Size mismatch for UFortQueryGenerator_GoalPlayerPawns");
static_assert(offsetof(UFortQueryGenerator_GoalPlayerPawns, bOnlyAthenaGameParticipants) == 0x50, "Offset mismatch for UFortQueryGenerator_GoalPlayerPawns::bOnlyAthenaGameParticipants");

// Size: 0xd0 (Inherited: 0xa8, Single: 0x28)
class UFortQueryGenerator_GoalTrackableAIObjects : public UEnvQueryGenerator
{
public:
    FFortAIAssignmentIdentifier AssignmentIdentifier; // 0x50 (Size: 0x30, Type: StructProperty)
    UClass* SearchedActorClass; // 0x80 (Size: 0x8, Type: ClassProperty)
    FGameplayTag RequiredTag; // 0x88 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
    FAIDataProviderFloatValue SearchRadius; // 0x90 (Size: 0x38, Type: StructProperty)
    UClass* SearchCenter; // 0xc8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_GoalTrackableAIObjects) == 0xd0, "Size mismatch for UFortQueryGenerator_GoalTrackableAIObjects");
static_assert(offsetof(UFortQueryGenerator_GoalTrackableAIObjects, AssignmentIdentifier) == 0x50, "Offset mismatch for UFortQueryGenerator_GoalTrackableAIObjects::AssignmentIdentifier");
static_assert(offsetof(UFortQueryGenerator_GoalTrackableAIObjects, SearchedActorClass) == 0x80, "Offset mismatch for UFortQueryGenerator_GoalTrackableAIObjects::SearchedActorClass");
static_assert(offsetof(UFortQueryGenerator_GoalTrackableAIObjects, RequiredTag) == 0x88, "Offset mismatch for UFortQueryGenerator_GoalTrackableAIObjects::RequiredTag");
static_assert(offsetof(UFortQueryGenerator_GoalTrackableAIObjects, SearchRadius) == 0x90, "Offset mismatch for UFortQueryGenerator_GoalTrackableAIObjects::SearchRadius");
static_assert(offsetof(UFortQueryGenerator_GoalTrackableAIObjects, SearchCenter) == 0xc8, "Offset mismatch for UFortQueryGenerator_GoalTrackableAIObjects::SearchCenter");

// Size: 0xa0 (Inherited: 0xa8, Single: 0xfffffff8)
class UFortQueryGenerator_HotspotSlots : public UEnvQueryGenerator
{
public:
    UClass* GenerateAround; // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue Radius; // 0x58 (Size: 0x38, Type: StructProperty)
    uint8_t bUseTetherZone : 1; // 0x90:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
    UClass* HotspotClass; // 0x98 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_HotspotSlots) == 0xa0, "Size mismatch for UFortQueryGenerator_HotspotSlots");
static_assert(offsetof(UFortQueryGenerator_HotspotSlots, GenerateAround) == 0x50, "Offset mismatch for UFortQueryGenerator_HotspotSlots::GenerateAround");
static_assert(offsetof(UFortQueryGenerator_HotspotSlots, Radius) == 0x58, "Offset mismatch for UFortQueryGenerator_HotspotSlots::Radius");
static_assert(offsetof(UFortQueryGenerator_HotspotSlots, bUseTetherZone) == 0x90, "Offset mismatch for UFortQueryGenerator_HotspotSlots::bUseTetherZone");
static_assert(offsetof(UFortQueryGenerator_HotspotSlots, HotspotClass) == 0x98, "Offset mismatch for UFortQueryGenerator_HotspotSlots::HotspotClass");

// Size: 0xd8 (Inherited: 0x138, Single: 0xffffffa0)
class UFortQueryGenerator_InfluenceMapPoints : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderIntValue Density; // 0x90 (Size: 0x38, Type: StructProperty)
    uint8_t bOnlyFlatSurface : 1; // 0xc8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c9[0x7]; // 0xc9 (Size: 0x7, Type: PaddingProperty)
    UClass* GenerateAround; // 0xd0 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_InfluenceMapPoints) == 0xd8, "Size mismatch for UFortQueryGenerator_InfluenceMapPoints");
static_assert(offsetof(UFortQueryGenerator_InfluenceMapPoints, Density) == 0x90, "Offset mismatch for UFortQueryGenerator_InfluenceMapPoints::Density");
static_assert(offsetof(UFortQueryGenerator_InfluenceMapPoints, bOnlyFlatSurface) == 0xc8, "Offset mismatch for UFortQueryGenerator_InfluenceMapPoints::bOnlyFlatSurface");
static_assert(offsetof(UFortQueryGenerator_InfluenceMapPoints, GenerateAround) == 0xd0, "Offset mismatch for UFortQueryGenerator_InfluenceMapPoints::GenerateAround");

// Size: 0x128 (Inherited: 0xa8, Single: 0x80)
class UFortQueryGenerator_LootGoalsAthena : public UEnvQueryGenerator
{
public:
    FFortAIAssignmentIdentifier AssignmentIdentifier; // 0x50 (Size: 0x30, Type: StructProperty)
    UFortAIAssignmentSettings* AssignmentSettings; // 0x80 (Size: 0x8, Type: ObjectProperty)
    FAIDataProviderFloatValue HorizontalHalfExtents; // 0x88 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue VerticalHalfExtents; // 0xc0 (Size: 0x38, Type: StructProperty)
    UClass* SearchCenter; // 0xf8 (Size: 0x8, Type: ClassProperty)
    uint8_t bAvailableLootOnly : 1; // 0x100:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0x7]; // 0x101 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagContainer ExcludedAILootGameplayTags; // 0x108 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_LootGoalsAthena) == 0x128, "Size mismatch for UFortQueryGenerator_LootGoalsAthena");
static_assert(offsetof(UFortQueryGenerator_LootGoalsAthena, AssignmentIdentifier) == 0x50, "Offset mismatch for UFortQueryGenerator_LootGoalsAthena::AssignmentIdentifier");
static_assert(offsetof(UFortQueryGenerator_LootGoalsAthena, AssignmentSettings) == 0x80, "Offset mismatch for UFortQueryGenerator_LootGoalsAthena::AssignmentSettings");
static_assert(offsetof(UFortQueryGenerator_LootGoalsAthena, HorizontalHalfExtents) == 0x88, "Offset mismatch for UFortQueryGenerator_LootGoalsAthena::HorizontalHalfExtents");
static_assert(offsetof(UFortQueryGenerator_LootGoalsAthena, VerticalHalfExtents) == 0xc0, "Offset mismatch for UFortQueryGenerator_LootGoalsAthena::VerticalHalfExtents");
static_assert(offsetof(UFortQueryGenerator_LootGoalsAthena, SearchCenter) == 0xf8, "Offset mismatch for UFortQueryGenerator_LootGoalsAthena::SearchCenter");
static_assert(offsetof(UFortQueryGenerator_LootGoalsAthena, bAvailableLootOnly) == 0x100, "Offset mismatch for UFortQueryGenerator_LootGoalsAthena::bAvailableLootOnly");
static_assert(offsetof(UFortQueryGenerator_LootGoalsAthena, ExcludedAILootGameplayTags) == 0x108, "Offset mismatch for UFortQueryGenerator_LootGoalsAthena::ExcludedAILootGameplayTags");

// Size: 0x98 (Inherited: 0xa8, Single: 0xfffffff0)
class UFortQueryGenerator_MissionPlacementActors : public UEnvQueryGenerator
{
public:
    FGameplayTagQuery MissionPlacementActorTagQuery; // 0x50 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_MissionPlacementActors) == 0x98, "Size mismatch for UFortQueryGenerator_MissionPlacementActors");
static_assert(offsetof(UFortQueryGenerator_MissionPlacementActors, MissionPlacementActorTagQuery) == 0x50, "Offset mismatch for UFortQueryGenerator_MissionPlacementActors::MissionPlacementActorTagQuery");

// Size: 0x50 (Inherited: 0xa8, Single: 0xffffffa8)
class UFortQueryGenerator_MutatorActorQueryResults : public UEnvQueryGenerator
{
public:
};

static_assert(sizeof(UFortQueryGenerator_MutatorActorQueryResults) == 0x50, "Size mismatch for UFortQueryGenerator_MutatorActorQueryResults");

// Size: 0x50 (Inherited: 0xa8, Single: 0xffffffa8)
class UFortQueryGenerator_MutatorBaseQueryResults : public UEnvQueryGenerator
{
public:
};

static_assert(sizeof(UFortQueryGenerator_MutatorBaseQueryResults) == 0x50, "Size mismatch for UFortQueryGenerator_MutatorBaseQueryResults");

// Size: 0x128 (Inherited: 0xa8, Single: 0x80)
class UFortQueryGenerator_PerceivedActors : public UEnvQueryGenerator
{
public:
    bool bGenerateHostileActorGoal; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
    FFortQueryGenerator_PerceivedActors_Settings HostileActorSettings; // 0x58 (Size: 0x40, Type: StructProperty)
    bool bGenerateNeutralActorGoal; // 0x98 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
    FFortQueryGenerator_PerceivedActors_Settings NeutralActorSettings; // 0xa0 (Size: 0x40, Type: StructProperty)
    bool bGenerateFriendlyActorGoal; // 0xe0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e1[0x7]; // 0xe1 (Size: 0x7, Type: PaddingProperty)
    FFortQueryGenerator_PerceivedActors_Settings FriendlyActorSettings; // 0xe8 (Size: 0x40, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_PerceivedActors) == 0x128, "Size mismatch for UFortQueryGenerator_PerceivedActors");
static_assert(offsetof(UFortQueryGenerator_PerceivedActors, bGenerateHostileActorGoal) == 0x50, "Offset mismatch for UFortQueryGenerator_PerceivedActors::bGenerateHostileActorGoal");
static_assert(offsetof(UFortQueryGenerator_PerceivedActors, HostileActorSettings) == 0x58, "Offset mismatch for UFortQueryGenerator_PerceivedActors::HostileActorSettings");
static_assert(offsetof(UFortQueryGenerator_PerceivedActors, bGenerateNeutralActorGoal) == 0x98, "Offset mismatch for UFortQueryGenerator_PerceivedActors::bGenerateNeutralActorGoal");
static_assert(offsetof(UFortQueryGenerator_PerceivedActors, NeutralActorSettings) == 0xa0, "Offset mismatch for UFortQueryGenerator_PerceivedActors::NeutralActorSettings");
static_assert(offsetof(UFortQueryGenerator_PerceivedActors, bGenerateFriendlyActorGoal) == 0xe0, "Offset mismatch for UFortQueryGenerator_PerceivedActors::bGenerateFriendlyActorGoal");
static_assert(offsetof(UFortQueryGenerator_PerceivedActors, FriendlyActorSettings) == 0xe8, "Offset mismatch for UFortQueryGenerator_PerceivedActors::FriendlyActorSettings");

// Size: 0x128 (Inherited: 0x138, Single: 0xfffffff0)
class UFortQueryGenerator_PointsAroundLine : public UEnvQueryGenerator_ProjectedPoints
{
public:
    UClass* GenerateAround; // 0x90 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderIntValue MaxPointsPerClusterLocation; // 0x98 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ClusterRadius; // 0xd0 (Size: 0x38, Type: StructProperty)
    TSoftObjectPtr<UFortQueryData_CurvesAroundLine*> CurvesAroundLineAsset; // 0x108 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(UFortQueryGenerator_PointsAroundLine) == 0x128, "Size mismatch for UFortQueryGenerator_PointsAroundLine");
static_assert(offsetof(UFortQueryGenerator_PointsAroundLine, GenerateAround) == 0x90, "Offset mismatch for UFortQueryGenerator_PointsAroundLine::GenerateAround");
static_assert(offsetof(UFortQueryGenerator_PointsAroundLine, MaxPointsPerClusterLocation) == 0x98, "Offset mismatch for UFortQueryGenerator_PointsAroundLine::MaxPointsPerClusterLocation");
static_assert(offsetof(UFortQueryGenerator_PointsAroundLine, ClusterRadius) == 0xd0, "Offset mismatch for UFortQueryGenerator_PointsAroundLine::ClusterRadius");
static_assert(offsetof(UFortQueryGenerator_PointsAroundLine, CurvesAroundLineAsset) == 0x108, "Offset mismatch for UFortQueryGenerator_PointsAroundLine::CurvesAroundLineAsset");

// Size: 0x1e0 (Inherited: 0x138, Single: 0xa8)
class UFortQueryGenerator_PointsFromNavGraph : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue MinPathDistance; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaxPathDistance; // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue Density; // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ExploreDirectionYaw; // 0x138 (Size: 0x38, Type: StructProperty)
    FEnvDirection ExploreDirection; // 0x170 (Size: 0x20, Type: StructProperty)
    float ExploreAngleDot; // 0x190 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_194[0x4]; // 0x194 (Size: 0x4, Type: PaddingProperty)
    FAIDataProviderFloatValue ExploreInnerRadius; // 0x198 (Size: 0x38, Type: StructProperty)
    uint8_t bLimitExplorationDirection : 1; // 0x1d0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bOnlyFlatSurface : 1; // 0x1d0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseParameterizedDirection : 1; // 0x1d0:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseHeightCheck : 1; // 0x1d0:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bFilterAllowTerrain : 1; // 0x1d0:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bFilterAllowBuildings : 1; // 0x1d0:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bFilterAllowDropdown : 1; // 0x1d0:6 (Size: 0x1, Type: BoolProperty)
    uint8_t bFilterAllowClimbup : 1; // 0x1d0:7 (Size: 0x1, Type: BoolProperty)
    uint8_t bFilterAllowSmash : 1; // 0x1d1:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d2[0x2]; // 0x1d2 (Size: 0x2, Type: PaddingProperty)
    TEnumAsByte<EFortPointsFromNavGraphGoalPathDistanceFilterOperator> PathDistanceFilterOperator; // 0x1d4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1d5[0x3]; // 0x1d5 (Size: 0x3, Type: PaddingProperty)
    UClass* GenerateAround; // 0x1d8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_PointsFromNavGraph) == 0x1e0, "Size mismatch for UFortQueryGenerator_PointsFromNavGraph");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, MinPathDistance) == 0x90, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::MinPathDistance");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, MaxPathDistance) == 0xc8, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::MaxPathDistance");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, Density) == 0x100, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::Density");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, ExploreDirectionYaw) == 0x138, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::ExploreDirectionYaw");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, ExploreDirection) == 0x170, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::ExploreDirection");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, ExploreAngleDot) == 0x190, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::ExploreAngleDot");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, ExploreInnerRadius) == 0x198, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::ExploreInnerRadius");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, bLimitExplorationDirection) == 0x1d0, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::bLimitExplorationDirection");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, bOnlyFlatSurface) == 0x1d0, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::bOnlyFlatSurface");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, bUseParameterizedDirection) == 0x1d0, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::bUseParameterizedDirection");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, bUseHeightCheck) == 0x1d0, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::bUseHeightCheck");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, bFilterAllowTerrain) == 0x1d0, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::bFilterAllowTerrain");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, bFilterAllowBuildings) == 0x1d0, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::bFilterAllowBuildings");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, bFilterAllowDropdown) == 0x1d0, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::bFilterAllowDropdown");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, bFilterAllowClimbup) == 0x1d0, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::bFilterAllowClimbup");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, bFilterAllowSmash) == 0x1d1, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::bFilterAllowSmash");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, PathDistanceFilterOperator) == 0x1d4, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::PathDistanceFilterOperator");
static_assert(offsetof(UFortQueryGenerator_PointsFromNavGraph, GenerateAround) == 0x1d8, "Offset mismatch for UFortQueryGenerator_PointsFromNavGraph::GenerateAround");

// Size: 0x288 (Inherited: 0x318, Single: 0xffffff70)
class UFortQueryGenerator_PointsInCylinder : public UEnvQueryGenerator_Donut
{
public:
    FAIDataProviderFloatValue CylinderHeightMin; // 0x1e0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue CylinderHeightMax; // 0x218 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SpaceBetweenSlices; // 0x250 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_PointsInCylinder) == 0x288, "Size mismatch for UFortQueryGenerator_PointsInCylinder");
static_assert(offsetof(UFortQueryGenerator_PointsInCylinder, CylinderHeightMin) == 0x1e0, "Offset mismatch for UFortQueryGenerator_PointsInCylinder::CylinderHeightMin");
static_assert(offsetof(UFortQueryGenerator_PointsInCylinder, CylinderHeightMax) == 0x218, "Offset mismatch for UFortQueryGenerator_PointsInCylinder::CylinderHeightMax");
static_assert(offsetof(UFortQueryGenerator_PointsInCylinder, SpaceBetweenSlices) == 0x250, "Offset mismatch for UFortQueryGenerator_PointsInCylinder::SpaceBetweenSlices");

// Size: 0x98 (Inherited: 0xa8, Single: 0xfffffff0)
class UFortQueryGenerator_PointsInVolume : public UEnvQueryGenerator
{
public:
    FAIDataProviderIntValue NumberOfPoints; // 0x50 (Size: 0x38, Type: StructProperty)
    TEnumAsByte<EFortNamedNavmesh> NavMeshToUse; // 0x88 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_89[0x7]; // 0x89 (Size: 0x7, Type: PaddingProperty)
    UClass* GenerateIn; // 0x90 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_PointsInVolume) == 0x98, "Size mismatch for UFortQueryGenerator_PointsInVolume");
static_assert(offsetof(UFortQueryGenerator_PointsInVolume, NumberOfPoints) == 0x50, "Offset mismatch for UFortQueryGenerator_PointsInVolume::NumberOfPoints");
static_assert(offsetof(UFortQueryGenerator_PointsInVolume, NavMeshToUse) == 0x88, "Offset mismatch for UFortQueryGenerator_PointsInVolume::NavMeshToUse");
static_assert(offsetof(UFortQueryGenerator_PointsInVolume, GenerateIn) == 0x90, "Offset mismatch for UFortQueryGenerator_PointsInVolume::GenerateIn");

// Size: 0x258 (Inherited: 0x138, Single: 0x120)
class UFortQueryGenerator_PointsOnBuildingActors : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderFloatValue BoundingBoxExtentXY; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue BoundingBoxExtentZ; // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue PointDensity; // 0x100 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue MaxGeneratedPoints; // 0x138 (Size: 0x38, Type: StructProperty)
    FFortTaggedActorOctreeFilter ActorLookupFilter; // 0x170 (Size: 0xa8, Type: StructProperty)
    FAIDataProviderFloatValue RandomChanceToSkip; // 0x218 (Size: 0x38, Type: StructProperty)
    UClass* GenerateAround; // 0x250 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_PointsOnBuildingActors) == 0x258, "Size mismatch for UFortQueryGenerator_PointsOnBuildingActors");
static_assert(offsetof(UFortQueryGenerator_PointsOnBuildingActors, BoundingBoxExtentXY) == 0x90, "Offset mismatch for UFortQueryGenerator_PointsOnBuildingActors::BoundingBoxExtentXY");
static_assert(offsetof(UFortQueryGenerator_PointsOnBuildingActors, BoundingBoxExtentZ) == 0xc8, "Offset mismatch for UFortQueryGenerator_PointsOnBuildingActors::BoundingBoxExtentZ");
static_assert(offsetof(UFortQueryGenerator_PointsOnBuildingActors, PointDensity) == 0x100, "Offset mismatch for UFortQueryGenerator_PointsOnBuildingActors::PointDensity");
static_assert(offsetof(UFortQueryGenerator_PointsOnBuildingActors, MaxGeneratedPoints) == 0x138, "Offset mismatch for UFortQueryGenerator_PointsOnBuildingActors::MaxGeneratedPoints");
static_assert(offsetof(UFortQueryGenerator_PointsOnBuildingActors, ActorLookupFilter) == 0x170, "Offset mismatch for UFortQueryGenerator_PointsOnBuildingActors::ActorLookupFilter");
static_assert(offsetof(UFortQueryGenerator_PointsOnBuildingActors, RandomChanceToSkip) == 0x218, "Offset mismatch for UFortQueryGenerator_PointsOnBuildingActors::RandomChanceToSkip");
static_assert(offsetof(UFortQueryGenerator_PointsOnBuildingActors, GenerateAround) == 0x250, "Offset mismatch for UFortQueryGenerator_PointsOnBuildingActors::GenerateAround");

// Size: 0x110 (Inherited: 0x138, Single: 0xffffffd8)
class UFortQueryGenerator_PointsOnBuildingGrid : public UEnvQueryGenerator_ProjectedPoints
{
public:
    FAIDataProviderIntValue HorizontalGridSize; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue VerticalGridSize; // 0xc8 (Size: 0x38, Type: StructProperty)
    bool bStartGridFromBottom; // 0x100 (Size: 0x1, Type: BoolProperty)
    bool bUsePointInVerticalCenterOfCell; // 0x101 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_102[0x6]; // 0x102 (Size: 0x6, Type: PaddingProperty)
    UClass* GenerateAround; // 0x108 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_PointsOnBuildingGrid) == 0x110, "Size mismatch for UFortQueryGenerator_PointsOnBuildingGrid");
static_assert(offsetof(UFortQueryGenerator_PointsOnBuildingGrid, HorizontalGridSize) == 0x90, "Offset mismatch for UFortQueryGenerator_PointsOnBuildingGrid::HorizontalGridSize");
static_assert(offsetof(UFortQueryGenerator_PointsOnBuildingGrid, VerticalGridSize) == 0xc8, "Offset mismatch for UFortQueryGenerator_PointsOnBuildingGrid::VerticalGridSize");
static_assert(offsetof(UFortQueryGenerator_PointsOnBuildingGrid, bStartGridFromBottom) == 0x100, "Offset mismatch for UFortQueryGenerator_PointsOnBuildingGrid::bStartGridFromBottom");
static_assert(offsetof(UFortQueryGenerator_PointsOnBuildingGrid, bUsePointInVerticalCenterOfCell) == 0x101, "Offset mismatch for UFortQueryGenerator_PointsOnBuildingGrid::bUsePointInVerticalCenterOfCell");
static_assert(offsetof(UFortQueryGenerator_PointsOnBuildingGrid, GenerateAround) == 0x108, "Offset mismatch for UFortQueryGenerator_PointsOnBuildingGrid::GenerateAround");

// Size: 0xf0 (Inherited: 0x138, Single: 0xffffffb8)
class UFortQueryGenerator_PointsOnWaterShoreLine : public UEnvQueryGenerator_ProjectedPoints
{
public:
    UClass* GenerateAround; // 0x90 (Size: 0x8, Type: ClassProperty)
    TSoftObjectPtr<UFortQueryData_CurvesAroundLine*> CurvesAroundLineAsset; // 0x98 (Size: 0x20, Type: SoftObjectProperty)
    FAIDataProviderFloatValue SegmentMaximumVerticalDegreeAngle; // 0xb8 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_PointsOnWaterShoreLine) == 0xf0, "Size mismatch for UFortQueryGenerator_PointsOnWaterShoreLine");
static_assert(offsetof(UFortQueryGenerator_PointsOnWaterShoreLine, GenerateAround) == 0x90, "Offset mismatch for UFortQueryGenerator_PointsOnWaterShoreLine::GenerateAround");
static_assert(offsetof(UFortQueryGenerator_PointsOnWaterShoreLine, CurvesAroundLineAsset) == 0x98, "Offset mismatch for UFortQueryGenerator_PointsOnWaterShoreLine::CurvesAroundLineAsset");
static_assert(offsetof(UFortQueryGenerator_PointsOnWaterShoreLine, SegmentMaximumVerticalDegreeAngle) == 0xb8, "Offset mismatch for UFortQueryGenerator_PointsOnWaterShoreLine::SegmentMaximumVerticalDegreeAngle");

// Size: 0xd0 (Inherited: 0x138, Single: 0xffffff98)
class UFortQueryGenerator_RandomPointsInBoundingVolume : public UEnvQueryGenerator_ProjectedPoints
{
public:
    UClass* GenerateIn; // 0x90 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue RandomPointsCount; // 0x98 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_RandomPointsInBoundingVolume) == 0xd0, "Size mismatch for UFortQueryGenerator_RandomPointsInBoundingVolume");
static_assert(offsetof(UFortQueryGenerator_RandomPointsInBoundingVolume, GenerateIn) == 0x90, "Offset mismatch for UFortQueryGenerator_RandomPointsInBoundingVolume::GenerateIn");
static_assert(offsetof(UFortQueryGenerator_RandomPointsInBoundingVolume, RandomPointsCount) == 0x98, "Offset mismatch for UFortQueryGenerator_RandomPointsInBoundingVolume::RandomPointsCount");

// Size: 0x90 (Inherited: 0xa8, Single: 0xffffffe8)
class UFortQueryGenerator_SpecificAssignmentGoals : public UEnvQueryGenerator
{
public:
    FFortAIAssignmentIdentifier AssignmentIdentifier; // 0x50 (Size: 0x30, Type: StructProperty)
    UFortAIAssignmentSettings* AssignmentSettings; // 0x80 (Size: 0x8, Type: ObjectProperty)
    UClass* GoalProvider; // 0x88 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryGenerator_SpecificAssignmentGoals) == 0x90, "Size mismatch for UFortQueryGenerator_SpecificAssignmentGoals");
static_assert(offsetof(UFortQueryGenerator_SpecificAssignmentGoals, AssignmentIdentifier) == 0x50, "Offset mismatch for UFortQueryGenerator_SpecificAssignmentGoals::AssignmentIdentifier");
static_assert(offsetof(UFortQueryGenerator_SpecificAssignmentGoals, AssignmentSettings) == 0x80, "Offset mismatch for UFortQueryGenerator_SpecificAssignmentGoals::AssignmentSettings");
static_assert(offsetof(UFortQueryGenerator_SpecificAssignmentGoals, GoalProvider) == 0x88, "Offset mismatch for UFortQueryGenerator_SpecificAssignmentGoals::GoalProvider");

// Size: 0x168 (Inherited: 0xa8, Single: 0xc0)
class UFortQueryGenerator_SquadMembers : public UEnvQueryGenerator
{
public:
    FAIDataProviderBoolValue LookingForHumanPlayers; // 0x50 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue LookingForPlayerBots; // 0x88 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue LookingForNpcs; // 0xc0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue LookingForAiPawns; // 0xf8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue IncludeSelf; // 0x130 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_SquadMembers) == 0x168, "Size mismatch for UFortQueryGenerator_SquadMembers");
static_assert(offsetof(UFortQueryGenerator_SquadMembers, LookingForHumanPlayers) == 0x50, "Offset mismatch for UFortQueryGenerator_SquadMembers::LookingForHumanPlayers");
static_assert(offsetof(UFortQueryGenerator_SquadMembers, LookingForPlayerBots) == 0x88, "Offset mismatch for UFortQueryGenerator_SquadMembers::LookingForPlayerBots");
static_assert(offsetof(UFortQueryGenerator_SquadMembers, LookingForNpcs) == 0xc0, "Offset mismatch for UFortQueryGenerator_SquadMembers::LookingForNpcs");
static_assert(offsetof(UFortQueryGenerator_SquadMembers, LookingForAiPawns) == 0xf8, "Offset mismatch for UFortQueryGenerator_SquadMembers::LookingForAiPawns");
static_assert(offsetof(UFortQueryGenerator_SquadMembers, IncludeSelf) == 0x130, "Offset mismatch for UFortQueryGenerator_SquadMembers::IncludeSelf");

// Size: 0x140 (Inherited: 0xa8, Single: 0x98)
class UFortQueryGenerator_TerrainDonut : public UEnvQueryGenerator
{
public:
    UClass* Center; // 0x50 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue Radius; // 0x58 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue RadiusWidth; // 0x90 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue SpacingArc; // 0xc8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderIntValue NumRings; // 0x100 (Size: 0x38, Type: StructProperty)
    uint8_t bFilterAllowTerrain : 1; // 0x138:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bFilterAllowBuildings : 1; // 0x138:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_139[0x7]; // 0x139 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryGenerator_TerrainDonut) == 0x140, "Size mismatch for UFortQueryGenerator_TerrainDonut");
static_assert(offsetof(UFortQueryGenerator_TerrainDonut, Center) == 0x50, "Offset mismatch for UFortQueryGenerator_TerrainDonut::Center");
static_assert(offsetof(UFortQueryGenerator_TerrainDonut, Radius) == 0x58, "Offset mismatch for UFortQueryGenerator_TerrainDonut::Radius");
static_assert(offsetof(UFortQueryGenerator_TerrainDonut, RadiusWidth) == 0x90, "Offset mismatch for UFortQueryGenerator_TerrainDonut::RadiusWidth");
static_assert(offsetof(UFortQueryGenerator_TerrainDonut, SpacingArc) == 0xc8, "Offset mismatch for UFortQueryGenerator_TerrainDonut::SpacingArc");
static_assert(offsetof(UFortQueryGenerator_TerrainDonut, NumRings) == 0x100, "Offset mismatch for UFortQueryGenerator_TerrainDonut::NumRings");
static_assert(offsetof(UFortQueryGenerator_TerrainDonut, bFilterAllowTerrain) == 0x138, "Offset mismatch for UFortQueryGenerator_TerrainDonut::bFilterAllowTerrain");
static_assert(offsetof(UFortQueryGenerator_TerrainDonut, bFilterAllowBuildings) == 0x138, "Offset mismatch for UFortQueryGenerator_TerrainDonut::bFilterAllowBuildings");

// Size: 0x88 (Inherited: 0xa8, Single: 0xffffffe0)
class UFortQueryGenerator_ValidSpawnRiftActors : public UEnvQueryGenerator
{
public:
    FAIDataProviderIntValue NumAIForGroup; // 0x50 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryGenerator_ValidSpawnRiftActors) == 0x88, "Size mismatch for UFortQueryGenerator_ValidSpawnRiftActors");
static_assert(offsetof(UFortQueryGenerator_ValidSpawnRiftActors, NumAIForGroup) == 0x50, "Offset mismatch for UFortQueryGenerator_ValidSpawnRiftActors::NumAIForGroup");

// Size: 0x30 (Inherited: 0xb8, Single: 0xffffff78)
class UFortQueryItemType_PointOrSlot : public UEnvQueryItemType_Point
{
public:
};

static_assert(sizeof(UFortQueryItemType_PointOrSlot) == 0x30, "Size mismatch for UFortQueryItemType_PointOrSlot");

// Size: 0x428 (Inherited: 0x4b8, Single: 0xffffff70)
class UFortQueryTest_AssignmentTypeInterest : public UFortQueryTest_GoalBase
{
public:
    FAIDataProviderFloatValue InvalidTypeStartInterest; // 0x268 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue InvalidTypeEndInterest; // 0x2a0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue InvalidTypeTimeBeforeLerp; // 0x2d8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue InvalidTypeLerpDuration; // 0x310 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValidTypeStartInterest; // 0x348 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValidTypeEndInterest; // 0x380 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValidTypeTimeBeforeLerp; // 0x3b8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValidTypeLerpDuration; // 0x3f0 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_AssignmentTypeInterest) == 0x428, "Size mismatch for UFortQueryTest_AssignmentTypeInterest");
static_assert(offsetof(UFortQueryTest_AssignmentTypeInterest, InvalidTypeStartInterest) == 0x268, "Offset mismatch for UFortQueryTest_AssignmentTypeInterest::InvalidTypeStartInterest");
static_assert(offsetof(UFortQueryTest_AssignmentTypeInterest, InvalidTypeEndInterest) == 0x2a0, "Offset mismatch for UFortQueryTest_AssignmentTypeInterest::InvalidTypeEndInterest");
static_assert(offsetof(UFortQueryTest_AssignmentTypeInterest, InvalidTypeTimeBeforeLerp) == 0x2d8, "Offset mismatch for UFortQueryTest_AssignmentTypeInterest::InvalidTypeTimeBeforeLerp");
static_assert(offsetof(UFortQueryTest_AssignmentTypeInterest, InvalidTypeLerpDuration) == 0x310, "Offset mismatch for UFortQueryTest_AssignmentTypeInterest::InvalidTypeLerpDuration");
static_assert(offsetof(UFortQueryTest_AssignmentTypeInterest, ValidTypeStartInterest) == 0x348, "Offset mismatch for UFortQueryTest_AssignmentTypeInterest::ValidTypeStartInterest");
static_assert(offsetof(UFortQueryTest_AssignmentTypeInterest, ValidTypeEndInterest) == 0x380, "Offset mismatch for UFortQueryTest_AssignmentTypeInterest::ValidTypeEndInterest");
static_assert(offsetof(UFortQueryTest_AssignmentTypeInterest, ValidTypeTimeBeforeLerp) == 0x3b8, "Offset mismatch for UFortQueryTest_AssignmentTypeInterest::ValidTypeTimeBeforeLerp");
static_assert(offsetof(UFortQueryTest_AssignmentTypeInterest, ValidTypeLerpDuration) == 0x3f0, "Offset mismatch for UFortQueryTest_AssignmentTypeInterest::ValidTypeLerpDuration");

// Size: 0x268 (Inherited: 0x250, Single: 0x18)
class UFortQueryTest_GoalBase : public UEnvQueryTest
{
public:
    uint8_t bScoreEnemies : 1; // 0x1f8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bScoreEncounterGoals : 1; // 0x1f8:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bScoreWorldGoals : 1; // 0x1f8:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bScoreSpecificAssignments : 1; // 0x1f8:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
    TArray<FFortAIAssignmentIdentifier> AssignmentIDs; // 0x200 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortAIAssignmentIdentifier> ProhibitedAssignmentIDs; // 0x210 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagQuery GoalActorTagQuery; // 0x220 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_GoalBase) == 0x268, "Size mismatch for UFortQueryTest_GoalBase");
static_assert(offsetof(UFortQueryTest_GoalBase, bScoreEnemies) == 0x1f8, "Offset mismatch for UFortQueryTest_GoalBase::bScoreEnemies");
static_assert(offsetof(UFortQueryTest_GoalBase, bScoreEncounterGoals) == 0x1f8, "Offset mismatch for UFortQueryTest_GoalBase::bScoreEncounterGoals");
static_assert(offsetof(UFortQueryTest_GoalBase, bScoreWorldGoals) == 0x1f8, "Offset mismatch for UFortQueryTest_GoalBase::bScoreWorldGoals");
static_assert(offsetof(UFortQueryTest_GoalBase, bScoreSpecificAssignments) == 0x1f8, "Offset mismatch for UFortQueryTest_GoalBase::bScoreSpecificAssignments");
static_assert(offsetof(UFortQueryTest_GoalBase, AssignmentIDs) == 0x200, "Offset mismatch for UFortQueryTest_GoalBase::AssignmentIDs");
static_assert(offsetof(UFortQueryTest_GoalBase, ProhibitedAssignmentIDs) == 0x210, "Offset mismatch for UFortQueryTest_GoalBase::ProhibitedAssignmentIDs");
static_assert(offsetof(UFortQueryTest_GoalBase, GoalActorTagQuery) == 0x220, "Offset mismatch for UFortQueryTest_GoalBase::GoalActorTagQuery");

// Size: 0x8b8 (Inherited: 0x4b8, Single: 0x400)
class UFortQueryTest_BuildingCriteria : public UFortQueryTest_GoalBase
{
public:
    FAIDataProviderFloatValue ScoreForGroundSupportedFloor; // 0x268 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoreForBeingGroundSupported; // 0x2a0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoreForTraps; // 0x2d8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoreForWalls; // 0x310 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoreForNavigableOpening; // 0x348 (Size: 0x38, Type: StructProperty)
    FFortAIAssignmentIdentifier RootAssignmentID; // 0x380 (Size: 0x30, Type: StructProperty)
    FAIDataProviderBoolValue bPreferCloserToRootAssignment; // 0x3b0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ScoreForDistanceFromClosestRootAssignmentGoal; // 0x3e8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MinDistanceForDistanceScoring; // 0x420 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaxDistanceForDistanceScoring; // 0x458 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaxHealthScore; // 0x490 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bPreferHigherHealth; // 0x4c8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ClampMaxHealthValue; // 0x500 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ClampMinHealthValue; // 0x538 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bPreferHigherHealthPercentage; // 0x570 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaxHealthPercentageScore; // 0x5a8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bWantsBuildingRepairableByOwner; // 0x5e0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue RepairableBuildingScore; // 0x618 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue NotRepairableBuildingScore; // 0x650 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue NeedsRepairBuildingScore; // 0x688 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DoesntNeedsRepairBuildingScore; // 0x6c0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bWantsDamagedByFriendly; // 0x6f8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DamagedByFriendlyMaxLifespan; // 0x730 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DamagedByFriendlyMinDamage; // 0x768 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DamagedByFriendlyScore; // 0x7a0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue bWantsDamagedByEnemy; // 0x7d8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DamagedByEnemyMaxLifespan; // 0x810 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DamagedByEnemyMinDamage; // 0x848 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DamagedByEnemyScore; // 0x880 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_BuildingCriteria) == 0x8b8, "Size mismatch for UFortQueryTest_BuildingCriteria");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, ScoreForGroundSupportedFloor) == 0x268, "Offset mismatch for UFortQueryTest_BuildingCriteria::ScoreForGroundSupportedFloor");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, ScoreForBeingGroundSupported) == 0x2a0, "Offset mismatch for UFortQueryTest_BuildingCriteria::ScoreForBeingGroundSupported");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, ScoreForTraps) == 0x2d8, "Offset mismatch for UFortQueryTest_BuildingCriteria::ScoreForTraps");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, ScoreForWalls) == 0x310, "Offset mismatch for UFortQueryTest_BuildingCriteria::ScoreForWalls");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, ScoreForNavigableOpening) == 0x348, "Offset mismatch for UFortQueryTest_BuildingCriteria::ScoreForNavigableOpening");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, RootAssignmentID) == 0x380, "Offset mismatch for UFortQueryTest_BuildingCriteria::RootAssignmentID");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, bPreferCloserToRootAssignment) == 0x3b0, "Offset mismatch for UFortQueryTest_BuildingCriteria::bPreferCloserToRootAssignment");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, ScoreForDistanceFromClosestRootAssignmentGoal) == 0x3e8, "Offset mismatch for UFortQueryTest_BuildingCriteria::ScoreForDistanceFromClosestRootAssignmentGoal");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, MinDistanceForDistanceScoring) == 0x420, "Offset mismatch for UFortQueryTest_BuildingCriteria::MinDistanceForDistanceScoring");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, MaxDistanceForDistanceScoring) == 0x458, "Offset mismatch for UFortQueryTest_BuildingCriteria::MaxDistanceForDistanceScoring");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, MaxHealthScore) == 0x490, "Offset mismatch for UFortQueryTest_BuildingCriteria::MaxHealthScore");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, bPreferHigherHealth) == 0x4c8, "Offset mismatch for UFortQueryTest_BuildingCriteria::bPreferHigherHealth");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, ClampMaxHealthValue) == 0x500, "Offset mismatch for UFortQueryTest_BuildingCriteria::ClampMaxHealthValue");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, ClampMinHealthValue) == 0x538, "Offset mismatch for UFortQueryTest_BuildingCriteria::ClampMinHealthValue");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, bPreferHigherHealthPercentage) == 0x570, "Offset mismatch for UFortQueryTest_BuildingCriteria::bPreferHigherHealthPercentage");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, MaxHealthPercentageScore) == 0x5a8, "Offset mismatch for UFortQueryTest_BuildingCriteria::MaxHealthPercentageScore");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, bWantsBuildingRepairableByOwner) == 0x5e0, "Offset mismatch for UFortQueryTest_BuildingCriteria::bWantsBuildingRepairableByOwner");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, RepairableBuildingScore) == 0x618, "Offset mismatch for UFortQueryTest_BuildingCriteria::RepairableBuildingScore");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, NotRepairableBuildingScore) == 0x650, "Offset mismatch for UFortQueryTest_BuildingCriteria::NotRepairableBuildingScore");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, NeedsRepairBuildingScore) == 0x688, "Offset mismatch for UFortQueryTest_BuildingCriteria::NeedsRepairBuildingScore");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, DoesntNeedsRepairBuildingScore) == 0x6c0, "Offset mismatch for UFortQueryTest_BuildingCriteria::DoesntNeedsRepairBuildingScore");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, bWantsDamagedByFriendly) == 0x6f8, "Offset mismatch for UFortQueryTest_BuildingCriteria::bWantsDamagedByFriendly");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, DamagedByFriendlyMaxLifespan) == 0x730, "Offset mismatch for UFortQueryTest_BuildingCriteria::DamagedByFriendlyMaxLifespan");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, DamagedByFriendlyMinDamage) == 0x768, "Offset mismatch for UFortQueryTest_BuildingCriteria::DamagedByFriendlyMinDamage");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, DamagedByFriendlyScore) == 0x7a0, "Offset mismatch for UFortQueryTest_BuildingCriteria::DamagedByFriendlyScore");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, bWantsDamagedByEnemy) == 0x7d8, "Offset mismatch for UFortQueryTest_BuildingCriteria::bWantsDamagedByEnemy");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, DamagedByEnemyMaxLifespan) == 0x810, "Offset mismatch for UFortQueryTest_BuildingCriteria::DamagedByEnemyMaxLifespan");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, DamagedByEnemyMinDamage) == 0x848, "Offset mismatch for UFortQueryTest_BuildingCriteria::DamagedByEnemyMinDamage");
static_assert(offsetof(UFortQueryTest_BuildingCriteria, DamagedByEnemyScore) == 0x880, "Offset mismatch for UFortQueryTest_BuildingCriteria::DamagedByEnemyScore");

// Size: 0x268 (Inherited: 0x4b8, Single: 0xfffffdb0)
class UFortQueryTest_CanAttackTarget : public UFortQueryTest_GoalBase
{
public:
};

static_assert(sizeof(UFortQueryTest_CanAttackTarget) == 0x268, "Size mismatch for UFortQueryTest_CanAttackTarget");

// Size: 0x268 (Inherited: 0x4b8, Single: 0xfffffdb0)
class UFortQueryTest_CanBeDamaged : public UFortQueryTest_GoalBase
{
public:
};

static_assert(sizeof(UFortQueryTest_CanBeDamaged) == 0x268, "Size mismatch for UFortQueryTest_CanBeDamaged");

// Size: 0x228 (Inherited: 0x250, Single: 0xffffffd8)
class UFortQueryTest_CanHitWithGameplayAbility : public UEnvQueryTest
{
public:
    UClass* AIsUsingAbility; // 0x1f8 (Size: 0x8, Type: ClassProperty)
    UClass* AbilityTargets; // 0x200 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer GameplayAbilityTag; // 0x208 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_CanHitWithGameplayAbility) == 0x228, "Size mismatch for UFortQueryTest_CanHitWithGameplayAbility");
static_assert(offsetof(UFortQueryTest_CanHitWithGameplayAbility, AIsUsingAbility) == 0x1f8, "Offset mismatch for UFortQueryTest_CanHitWithGameplayAbility::AIsUsingAbility");
static_assert(offsetof(UFortQueryTest_CanHitWithGameplayAbility, AbilityTargets) == 0x200, "Offset mismatch for UFortQueryTest_CanHitWithGameplayAbility::AbilityTargets");
static_assert(offsetof(UFortQueryTest_CanHitWithGameplayAbility, GameplayAbilityTag) == 0x208, "Offset mismatch for UFortQueryTest_CanHitWithGameplayAbility::GameplayAbilityTag");

// Size: 0x240 (Inherited: 0x250, Single: 0xfffffff0)
class UFortQueryTest_CurieState : public UEnvQueryTest
{
public:
    FGameplayTagQuery CurieStateQuery; // 0x1f8 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_CurieState) == 0x240, "Size mismatch for UFortQueryTest_CurieState");
static_assert(offsetof(UFortQueryTest_CurieState, CurieStateQuery) == 0x1f8, "Offset mismatch for UFortQueryTest_CurieState::CurieStateQuery");

// Size: 0x200 (Inherited: 0x250, Single: 0xffffffb0)
class UFortQueryTest_DecoyDistance : public UEnvQueryTest
{
public:
    UClass* DistanceTo; // 0x1f8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryTest_DecoyDistance) == 0x200, "Size mismatch for UFortQueryTest_DecoyDistance");
static_assert(offsetof(UFortQueryTest_DecoyDistance, DistanceTo) == 0x1f8, "Offset mismatch for UFortQueryTest_DecoyDistance::DistanceTo");

// Size: 0x208 (Inherited: 0x250, Single: 0xffffffb8)
class UFortQueryTest_DeltaDistance : public UEnvQueryTest
{
public:
    UClass* LocationProviderContext; // 0x1f8 (Size: 0x8, Type: ClassProperty)
    bool bUseDistance2D; // 0x200 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_201[0x7]; // 0x201 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_DeltaDistance) == 0x208, "Size mismatch for UFortQueryTest_DeltaDistance");
static_assert(offsetof(UFortQueryTest_DeltaDistance, LocationProviderContext) == 0x1f8, "Offset mismatch for UFortQueryTest_DeltaDistance::LocationProviderContext");
static_assert(offsetof(UFortQueryTest_DeltaDistance, bUseDistance2D) == 0x200, "Offset mismatch for UFortQueryTest_DeltaDistance::bUseDistance2D");

// Size: 0x208 (Inherited: 0x250, Single: 0xffffffb8)
class UFortQueryTest_DistanceToActorBound : public UEnvQueryTest
{
public:
    UClass* DistanceTo; // 0x1f8 (Size: 0x8, Type: ClassProperty)
    bool bUse2DDistance; // 0x200 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_201[0x7]; // 0x201 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_DistanceToActorBound) == 0x208, "Size mismatch for UFortQueryTest_DistanceToActorBound");
static_assert(offsetof(UFortQueryTest_DistanceToActorBound, DistanceTo) == 0x1f8, "Offset mismatch for UFortQueryTest_DistanceToActorBound::DistanceTo");
static_assert(offsetof(UFortQueryTest_DistanceToActorBound, bUse2DDistance) == 0x200, "Offset mismatch for UFortQueryTest_DistanceToActorBound::bUse2DDistance");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UFortQueryTest_DistanceToIndestructibleBuilding : public UEnvQueryTest
{
public:
};

static_assert(sizeof(UFortQueryTest_DistanceToIndestructibleBuilding) == 0x1f8, "Size mismatch for UFortQueryTest_DistanceToIndestructibleBuilding");

// Size: 0x200 (Inherited: 0x250, Single: 0xffffffb0)
class UFortQueryTest_EnvironmentalDanger : public UEnvQueryTest
{
public:
    bool bUse3DBoundsCheck; // 0x1f8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f9[0x3]; // 0x1f9 (Size: 0x3, Type: PaddingProperty)
    FGameplayTag DangerSourceActorRegistryTag; // 0x1fc (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_EnvironmentalDanger) == 0x200, "Size mismatch for UFortQueryTest_EnvironmentalDanger");
static_assert(offsetof(UFortQueryTest_EnvironmentalDanger, bUse3DBoundsCheck) == 0x1f8, "Offset mismatch for UFortQueryTest_EnvironmentalDanger::bUse3DBoundsCheck");
static_assert(offsetof(UFortQueryTest_EnvironmentalDanger, DangerSourceActorRegistryTag) == 0x1fc, "Offset mismatch for UFortQueryTest_EnvironmentalDanger::DangerSourceActorRegistryTag");

// Size: 0x208 (Inherited: 0x250, Single: 0xffffffb8)
class UFortQueryTest_GameplayTagsPerDifficulty : public UEnvQueryTest
{
public:
    TArray<FFortGameplayTagQueryPerDifficulty> TagQueriesPerDifficulty; // 0x1f8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortQueryTest_GameplayTagsPerDifficulty) == 0x208, "Size mismatch for UFortQueryTest_GameplayTagsPerDifficulty");
static_assert(offsetof(UFortQueryTest_GameplayTagsPerDifficulty, TagQueriesPerDifficulty) == 0x1f8, "Offset mismatch for UFortQueryTest_GameplayTagsPerDifficulty::TagQueriesPerDifficulty");

// Size: 0x280 (Inherited: 0x4b8, Single: 0xfffffdc8)
class UFortQueryTest_GoalActorDot : public UFortQueryTest_GoalBase
{
public:
    UClass* LineATo; // 0x268 (Size: 0x8, Type: ClassProperty)
    UClass* LineBTo; // 0x270 (Size: 0x8, Type: ClassProperty)
    uint8_t TestMode; // 0x278 (Size: 0x1, Type: EnumProperty)
    bool bAbsoluteValue; // 0x279 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_27a[0x6]; // 0x27a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_GoalActorDot) == 0x280, "Size mismatch for UFortQueryTest_GoalActorDot");
static_assert(offsetof(UFortQueryTest_GoalActorDot, LineATo) == 0x268, "Offset mismatch for UFortQueryTest_GoalActorDot::LineATo");
static_assert(offsetof(UFortQueryTest_GoalActorDot, LineBTo) == 0x270, "Offset mismatch for UFortQueryTest_GoalActorDot::LineBTo");
static_assert(offsetof(UFortQueryTest_GoalActorDot, TestMode) == 0x278, "Offset mismatch for UFortQueryTest_GoalActorDot::TestMode");
static_assert(offsetof(UFortQueryTest_GoalActorDot, bAbsoluteValue) == 0x279, "Offset mismatch for UFortQueryTest_GoalActorDot::bAbsoluteValue");

// Size: 0x268 (Inherited: 0x4b8, Single: 0xfffffdb0)
class UFortQueryTest_GoalActorTimeSinceSpawn : public UFortQueryTest_GoalBase
{
public:
};

static_assert(sizeof(UFortQueryTest_GoalActorTimeSinceSpawn) == 0x268, "Size mismatch for UFortQueryTest_GoalActorTimeSinceSpawn");

// Size: 0x2a0 (Inherited: 0x4b8, Single: 0xfffffde8)
class UFortQueryTest_GoalDiscouragement : public UFortQueryTest_GoalBase
{
public:
    FAIDataProviderBoolValue DisableDiscouragementWhenUndermining; // 0x268 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_GoalDiscouragement) == 0x2a0, "Size mismatch for UFortQueryTest_GoalDiscouragement");
static_assert(offsetof(UFortQueryTest_GoalDiscouragement, DisableDiscouragementWhenUndermining) == 0x268, "Offset mismatch for UFortQueryTest_GoalDiscouragement::DisableDiscouragementWhenUndermining");

// Size: 0x280 (Inherited: 0x4b8, Single: 0xfffffdc8)
class UFortQueryTest_GoalDistance : public UFortQueryTest_GoalBase
{
public:
    uint8_t DistanceMode; // 0x268 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_269[0x7]; // 0x269 (Size: 0x7, Type: PaddingProperty)
    UClass* DistanceTo; // 0x270 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EEnvTestDistance> TestMode; // 0x278 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_279[0x7]; // 0x279 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_GoalDistance) == 0x280, "Size mismatch for UFortQueryTest_GoalDistance");
static_assert(offsetof(UFortQueryTest_GoalDistance, DistanceMode) == 0x268, "Offset mismatch for UFortQueryTest_GoalDistance::DistanceMode");
static_assert(offsetof(UFortQueryTest_GoalDistance, DistanceTo) == 0x270, "Offset mismatch for UFortQueryTest_GoalDistance::DistanceTo");
static_assert(offsetof(UFortQueryTest_GoalDistance, TestMode) == 0x278, "Offset mismatch for UFortQueryTest_GoalDistance::TestMode");

// Size: 0x290 (Inherited: 0x4b8, Single: 0xfffffdd8)
class UFortQueryTest_GoalDistanceRanges : public UFortQueryTest_GoalBase
{
public:
    uint8_t DistanceMode; // 0x268 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_269[0x7]; // 0x269 (Size: 0x7, Type: PaddingProperty)
    UClass* DistanceTo; // 0x270 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EEnvTestDistance> ScreeningTestMode; // 0x278 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EEnvTestDistance> TestMode; // 0x279 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_27a[0x6]; // 0x27a (Size: 0x6, Type: PaddingProperty)
    TArray<FGoalDistanceData> GoalDistanceDataRanges; // 0x280 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortQueryTest_GoalDistanceRanges) == 0x290, "Size mismatch for UFortQueryTest_GoalDistanceRanges");
static_assert(offsetof(UFortQueryTest_GoalDistanceRanges, DistanceMode) == 0x268, "Offset mismatch for UFortQueryTest_GoalDistanceRanges::DistanceMode");
static_assert(offsetof(UFortQueryTest_GoalDistanceRanges, DistanceTo) == 0x270, "Offset mismatch for UFortQueryTest_GoalDistanceRanges::DistanceTo");
static_assert(offsetof(UFortQueryTest_GoalDistanceRanges, ScreeningTestMode) == 0x278, "Offset mismatch for UFortQueryTest_GoalDistanceRanges::ScreeningTestMode");
static_assert(offsetof(UFortQueryTest_GoalDistanceRanges, TestMode) == 0x279, "Offset mismatch for UFortQueryTest_GoalDistanceRanges::TestMode");
static_assert(offsetof(UFortQueryTest_GoalDistanceRanges, GoalDistanceDataRanges) == 0x280, "Offset mismatch for UFortQueryTest_GoalDistanceRanges::GoalDistanceDataRanges");

// Size: 0x268 (Inherited: 0x4b8, Single: 0xfffffdb0)
class UFortQueryTest_GoalFrustrationDiscouragement : public UFortQueryTest_GoalBase
{
public:
};

static_assert(sizeof(UFortQueryTest_GoalFrustrationDiscouragement) == 0x268, "Size mismatch for UFortQueryTest_GoalFrustrationDiscouragement");

// Size: 0x2c0 (Inherited: 0x4b8, Single: 0xfffffe08)
class UFortQueryTest_GoalGameplayTags : public UFortQueryTest_GoalBase
{
public:
    bool bShouldLookupQueryByTag; // 0x268 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_269[0x7]; // 0x269 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagQuery TagQueryToMatch; // 0x270 (Size: 0x48, Type: StructProperty)
    FGameplayTag QueryLookupTag; // 0x2b8 (Size: 0x4, Type: StructProperty)
    bool bShouldPassWhenQueryNotFound; // 0x2bc (Size: 0x1, Type: BoolProperty)
    bool bRequireAllProvidedTagQueriesPass; // 0x2bd (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2be[0x2]; // 0x2be (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_GoalGameplayTags) == 0x2c0, "Size mismatch for UFortQueryTest_GoalGameplayTags");
static_assert(offsetof(UFortQueryTest_GoalGameplayTags, bShouldLookupQueryByTag) == 0x268, "Offset mismatch for UFortQueryTest_GoalGameplayTags::bShouldLookupQueryByTag");
static_assert(offsetof(UFortQueryTest_GoalGameplayTags, TagQueryToMatch) == 0x270, "Offset mismatch for UFortQueryTest_GoalGameplayTags::TagQueryToMatch");
static_assert(offsetof(UFortQueryTest_GoalGameplayTags, QueryLookupTag) == 0x2b8, "Offset mismatch for UFortQueryTest_GoalGameplayTags::QueryLookupTag");
static_assert(offsetof(UFortQueryTest_GoalGameplayTags, bShouldPassWhenQueryNotFound) == 0x2bc, "Offset mismatch for UFortQueryTest_GoalGameplayTags::bShouldPassWhenQueryNotFound");
static_assert(offsetof(UFortQueryTest_GoalGameplayTags, bRequireAllProvidedTagQueriesPass) == 0x2bd, "Offset mismatch for UFortQueryTest_GoalGameplayTags::bRequireAllProvidedTagQueriesPass");

// Size: 0x2e8 (Inherited: 0x4b8, Single: 0xfffffe30)
class UFortQueryTest_GoalMarkedByPlayer : public UFortQueryTest_GoalBase
{
public:
    FGameplayTagQuery OwnerTagQuery; // 0x268 (Size: 0x48, Type: StructProperty)
    FAIDataProviderBoolValue OnlyConverterMarkedTargets; // 0x2b0 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_GoalMarkedByPlayer) == 0x2e8, "Size mismatch for UFortQueryTest_GoalMarkedByPlayer");
static_assert(offsetof(UFortQueryTest_GoalMarkedByPlayer, OwnerTagQuery) == 0x268, "Offset mismatch for UFortQueryTest_GoalMarkedByPlayer::OwnerTagQuery");
static_assert(offsetof(UFortQueryTest_GoalMarkedByPlayer, OnlyConverterMarkedTargets) == 0x2b0, "Offset mismatch for UFortQueryTest_GoalMarkedByPlayer::OnlyConverterMarkedTargets");

// Size: 0x270 (Inherited: 0x4b8, Single: 0xfffffdb8)
class UFortQueryTest_GoalNumberOfAIAssigned : public UFortQueryTest_GoalBase
{
public:
    uint8_t TypeOfMatchToCount; // 0x268 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_269[0x7]; // 0x269 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_GoalNumberOfAIAssigned) == 0x270, "Size mismatch for UFortQueryTest_GoalNumberOfAIAssigned");
static_assert(offsetof(UFortQueryTest_GoalNumberOfAIAssigned, TypeOfMatchToCount) == 0x268, "Offset mismatch for UFortQueryTest_GoalNumberOfAIAssigned::TypeOfMatchToCount");

// Size: 0x268 (Inherited: 0x4b8, Single: 0xfffffdb0)
class UFortQueryTest_GoalOverallDamageCaused : public UFortQueryTest_GoalBase
{
public:
};

static_assert(sizeof(UFortQueryTest_GoalOverallDamageCaused) == 0x268, "Size mismatch for UFortQueryTest_GoalOverallDamageCaused");

// Size: 0x270 (Inherited: 0x4b8, Single: 0xfffffdb8)
class UFortQueryTest_GoalPickupFilter : public UFortQueryTest_GoalBase
{
public:
    float MaxLifetime; // 0x268 (Size: 0x4, Type: FloatProperty)
    uint8_t RequiredPickupSpawnSource; // 0x26c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_26d[0x3]; // 0x26d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_GoalPickupFilter) == 0x270, "Size mismatch for UFortQueryTest_GoalPickupFilter");
static_assert(offsetof(UFortQueryTest_GoalPickupFilter, MaxLifetime) == 0x268, "Offset mismatch for UFortQueryTest_GoalPickupFilter::MaxLifetime");
static_assert(offsetof(UFortQueryTest_GoalPickupFilter, RequiredPickupSpawnSource) == 0x26c, "Offset mismatch for UFortQueryTest_GoalPickupFilter::RequiredPickupSpawnSource");

// Size: 0x2a0 (Inherited: 0x4b8, Single: 0xfffffde8)
class UFortQueryTest_GoalProject : public UFortQueryTest_GoalBase
{
public:
    FEnvTraceData ProjectionData; // 0x268 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_GoalProject) == 0x2a0, "Size mismatch for UFortQueryTest_GoalProject");
static_assert(offsetof(UFortQueryTest_GoalProject, ProjectionData) == 0x268, "Offset mismatch for UFortQueryTest_GoalProject::ProjectionData");

// Size: 0x380 (Inherited: 0x4b8, Single: 0xfffffec8)
class UFortQueryTest_GoalStickiness : public UFortQueryTest_GoalBase
{
public:
    FAIDataProviderFloatValue StartValueForGoal; // 0x268 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue EndValueForGoal; // 0x2a0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue TimeBeforeValueLerp; // 0x2d8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValueLerpDuration; // 0x310 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue ApplyStickinessToAllGoalsWithSameActor; // 0x348 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_GoalStickiness) == 0x380, "Size mismatch for UFortQueryTest_GoalStickiness");
static_assert(offsetof(UFortQueryTest_GoalStickiness, StartValueForGoal) == 0x268, "Offset mismatch for UFortQueryTest_GoalStickiness::StartValueForGoal");
static_assert(offsetof(UFortQueryTest_GoalStickiness, EndValueForGoal) == 0x2a0, "Offset mismatch for UFortQueryTest_GoalStickiness::EndValueForGoal");
static_assert(offsetof(UFortQueryTest_GoalStickiness, TimeBeforeValueLerp) == 0x2d8, "Offset mismatch for UFortQueryTest_GoalStickiness::TimeBeforeValueLerp");
static_assert(offsetof(UFortQueryTest_GoalStickiness, ValueLerpDuration) == 0x310, "Offset mismatch for UFortQueryTest_GoalStickiness::ValueLerpDuration");
static_assert(offsetof(UFortQueryTest_GoalStickiness, ApplyStickinessToAllGoalsWithSameActor) == 0x348, "Offset mismatch for UFortQueryTest_GoalStickiness::ApplyStickinessToAllGoalsWithSameActor");

// Size: 0x268 (Inherited: 0x4b8, Single: 0xfffffdb0)
class UFortQueryTest_GoalType : public UFortQueryTest_GoalBase
{
public:
};

static_assert(sizeof(UFortQueryTest_GoalType) == 0x268, "Size mismatch for UFortQueryTest_GoalType");

// Size: 0x268 (Inherited: 0x4b8, Single: 0xfffffdb0)
class UFortQueryTest_GoalWithinTetheredBounds : public UFortQueryTest_GoalBase
{
public:
};

static_assert(sizeof(UFortQueryTest_GoalWithinTetheredBounds) == 0x268, "Size mismatch for UFortQueryTest_GoalWithinTetheredBounds");

// Size: 0x208 (Inherited: 0x250, Single: 0xffffffb8)
class UFortQueryTest_HasNearbyBuildings : public UEnvQueryTest
{
public:
    uint8_t bIncludeCenter : 1; // 0x1f8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bIncludeFloors : 1; // 0x1f8:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bIncludeFloorsAbove : 1; // 0x1f8:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bIncludeWalls : 1; // 0x1f8:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f9[0x3]; // 0x1f9 (Size: 0x3, Type: PaddingProperty)
    int32_t ExtentXY; // 0x1fc (Size: 0x4, Type: IntProperty)
    int32_t ExtentZ; // 0x200 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_204[0x4]; // 0x204 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_HasNearbyBuildings) == 0x208, "Size mismatch for UFortQueryTest_HasNearbyBuildings");
static_assert(offsetof(UFortQueryTest_HasNearbyBuildings, bIncludeCenter) == 0x1f8, "Offset mismatch for UFortQueryTest_HasNearbyBuildings::bIncludeCenter");
static_assert(offsetof(UFortQueryTest_HasNearbyBuildings, bIncludeFloors) == 0x1f8, "Offset mismatch for UFortQueryTest_HasNearbyBuildings::bIncludeFloors");
static_assert(offsetof(UFortQueryTest_HasNearbyBuildings, bIncludeFloorsAbove) == 0x1f8, "Offset mismatch for UFortQueryTest_HasNearbyBuildings::bIncludeFloorsAbove");
static_assert(offsetof(UFortQueryTest_HasNearbyBuildings, bIncludeWalls) == 0x1f8, "Offset mismatch for UFortQueryTest_HasNearbyBuildings::bIncludeWalls");
static_assert(offsetof(UFortQueryTest_HasNearbyBuildings, ExtentXY) == 0x1fc, "Offset mismatch for UFortQueryTest_HasNearbyBuildings::ExtentXY");
static_assert(offsetof(UFortQueryTest_HasNearbyBuildings, ExtentZ) == 0x200, "Offset mismatch for UFortQueryTest_HasNearbyBuildings::ExtentZ");

// Size: 0x238 (Inherited: 0x250, Single: 0xffffffe8)
class UFortQueryTest_HasNearbyEncounterGoals : public UEnvQueryTest
{
public:
    uint8_t bOnlyActiveEncounters : 1; // 0x1f8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
    FAIDataProviderFloatValue TestDistance; // 0x200 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_HasNearbyEncounterGoals) == 0x238, "Size mismatch for UFortQueryTest_HasNearbyEncounterGoals");
static_assert(offsetof(UFortQueryTest_HasNearbyEncounterGoals, bOnlyActiveEncounters) == 0x1f8, "Offset mismatch for UFortQueryTest_HasNearbyEncounterGoals::bOnlyActiveEncounters");
static_assert(offsetof(UFortQueryTest_HasNearbyEncounterGoals, TestDistance) == 0x200, "Offset mismatch for UFortQueryTest_HasNearbyEncounterGoals::TestDistance");

// Size: 0x200 (Inherited: 0x250, Single: 0xffffffb0)
class UFortQueryTest_Health : public UEnvQueryTest
{
public:
    bool bUsePercentHealth; // 0x1f8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_Health) == 0x200, "Size mismatch for UFortQueryTest_Health");
static_assert(offsetof(UFortQueryTest_Health, bUsePercentHealth) == 0x1f8, "Offset mismatch for UFortQueryTest_Health::bUsePercentHealth");

// Size: 0x2f0 (Inherited: 0x250, Single: 0xa0)
class UFortQueryTest_HealthAndShield : public UEnvQueryTest
{
public:
    bool bConsiderHealth; // 0x1f8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
    FAIDataProviderFloatValue HealthMin; // 0x200 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue HealthMax; // 0x238 (Size: 0x38, Type: StructProperty)
    bool bHealthAsPercent; // 0x270 (Size: 0x1, Type: BoolProperty)
    bool bConsiderShield; // 0x271 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_272[0x6]; // 0x272 (Size: 0x6, Type: PaddingProperty)
    FAIDataProviderFloatValue ShieldMin; // 0x278 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ShieldMax; // 0x2b0 (Size: 0x38, Type: StructProperty)
    bool bShieldAsPercent; // 0x2e8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2e9[0x7]; // 0x2e9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_HealthAndShield) == 0x2f0, "Size mismatch for UFortQueryTest_HealthAndShield");
static_assert(offsetof(UFortQueryTest_HealthAndShield, bConsiderHealth) == 0x1f8, "Offset mismatch for UFortQueryTest_HealthAndShield::bConsiderHealth");
static_assert(offsetof(UFortQueryTest_HealthAndShield, HealthMin) == 0x200, "Offset mismatch for UFortQueryTest_HealthAndShield::HealthMin");
static_assert(offsetof(UFortQueryTest_HealthAndShield, HealthMax) == 0x238, "Offset mismatch for UFortQueryTest_HealthAndShield::HealthMax");
static_assert(offsetof(UFortQueryTest_HealthAndShield, bHealthAsPercent) == 0x270, "Offset mismatch for UFortQueryTest_HealthAndShield::bHealthAsPercent");
static_assert(offsetof(UFortQueryTest_HealthAndShield, bConsiderShield) == 0x271, "Offset mismatch for UFortQueryTest_HealthAndShield::bConsiderShield");
static_assert(offsetof(UFortQueryTest_HealthAndShield, ShieldMin) == 0x278, "Offset mismatch for UFortQueryTest_HealthAndShield::ShieldMin");
static_assert(offsetof(UFortQueryTest_HealthAndShield, ShieldMax) == 0x2b0, "Offset mismatch for UFortQueryTest_HealthAndShield::ShieldMax");
static_assert(offsetof(UFortQueryTest_HealthAndShield, bShieldAsPercent) == 0x2e8, "Offset mismatch for UFortQueryTest_HealthAndShield::bShieldAsPercent");

// Size: 0x238 (Inherited: 0x250, Single: 0xffffffe8)
class UFortQueryTest_HotspotSlotOrientation : public UEnvQueryTest
{
public:
    UClass* FaceToward; // 0x1f8 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue DotThreshold; // 0x200 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_HotspotSlotOrientation) == 0x238, "Size mismatch for UFortQueryTest_HotspotSlotOrientation");
static_assert(offsetof(UFortQueryTest_HotspotSlotOrientation, FaceToward) == 0x1f8, "Offset mismatch for UFortQueryTest_HotspotSlotOrientation::FaceToward");
static_assert(offsetof(UFortQueryTest_HotspotSlotOrientation, DotThreshold) == 0x200, "Offset mismatch for UFortQueryTest_HotspotSlotOrientation::DotThreshold");

// Size: 0x200 (Inherited: 0x250, Single: 0xffffffb0)
class UFortQueryTest_HotspotSlotState : public UEnvQueryTest
{
public:
    uint8_t SlotState; // 0x1f8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_HotspotSlotState) == 0x200, "Size mismatch for UFortQueryTest_HotspotSlotState");
static_assert(offsetof(UFortQueryTest_HotspotSlotState, SlotState) == 0x1f8, "Offset mismatch for UFortQueryTest_HotspotSlotState::SlotState");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UFortQueryTest_InfluenceScore : public UEnvQueryTest
{
public:
};

static_assert(sizeof(UFortQueryTest_InfluenceScore) == 0x1f8, "Size mismatch for UFortQueryTest_InfluenceScore");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UFortQueryTest_InsideAIBotLeash : public UEnvQueryTest
{
public:
};

static_assert(sizeof(UFortQueryTest_InsideAIBotLeash) == 0x1f8, "Size mismatch for UFortQueryTest_InsideAIBotLeash");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UFortQueryTest_InsideAthenaLeash : public UEnvQueryTest
{
public:
};

static_assert(sizeof(UFortQueryTest_InsideAthenaLeash) == 0x1f8, "Size mismatch for UFortQueryTest_InsideAthenaLeash");

// Size: 0x240 (Inherited: 0x250, Single: 0xfffffff0)
class UFortQueryTest_InsideAthenaSafeZone : public UEnvQueryTest
{
public:
    bool bUseCurrentSafeZoneIndicatorRadius; // 0x1f8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
    FAIDataProviderIntValue SafeZoneIndex; // 0x200 (Size: 0x38, Type: StructProperty)
    bool bNextSafeZone; // 0x238 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_239[0x7]; // 0x239 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_InsideAthenaSafeZone) == 0x240, "Size mismatch for UFortQueryTest_InsideAthenaSafeZone");
static_assert(offsetof(UFortQueryTest_InsideAthenaSafeZone, bUseCurrentSafeZoneIndicatorRadius) == 0x1f8, "Offset mismatch for UFortQueryTest_InsideAthenaSafeZone::bUseCurrentSafeZoneIndicatorRadius");
static_assert(offsetof(UFortQueryTest_InsideAthenaSafeZone, SafeZoneIndex) == 0x200, "Offset mismatch for UFortQueryTest_InsideAthenaSafeZone::SafeZoneIndex");
static_assert(offsetof(UFortQueryTest_InsideAthenaSafeZone, bNextSafeZone) == 0x238, "Offset mismatch for UFortQueryTest_InsideAthenaSafeZone::bNextSafeZone");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UFortQueryTest_InsideBuilding : public UEnvQueryTest
{
public:
};

static_assert(sizeof(UFortQueryTest_InsideBuilding) == 0x1f8, "Size mismatch for UFortQueryTest_InsideBuilding");

// Size: 0x200 (Inherited: 0x250, Single: 0xffffffb0)
class UFortQueryTest_InsideWater : public UEnvQueryTest
{
public:
    float TestRadius; // 0x1f8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1fc[0x4]; // 0x1fc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_InsideWater) == 0x200, "Size mismatch for UFortQueryTest_InsideWater");
static_assert(offsetof(UFortQueryTest_InsideWater, TestRadius) == 0x1f8, "Offset mismatch for UFortQueryTest_InsideWater::TestRadius");

// Size: 0x240 (Inherited: 0x250, Single: 0xfffffff0)
class UFortQueryTest_IsCloseToHotspotSlot : public UEnvQueryTest
{
public:
    UClass* HotspotClass; // 0x1f8 (Size: 0x8, Type: ClassProperty)
    FAIDataProviderFloatValue Radius; // 0x200 (Size: 0x38, Type: StructProperty)
    bool bIgnoreItemsWithSlotData; // 0x238 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_239[0x7]; // 0x239 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_IsCloseToHotspotSlot) == 0x240, "Size mismatch for UFortQueryTest_IsCloseToHotspotSlot");
static_assert(offsetof(UFortQueryTest_IsCloseToHotspotSlot, HotspotClass) == 0x1f8, "Offset mismatch for UFortQueryTest_IsCloseToHotspotSlot::HotspotClass");
static_assert(offsetof(UFortQueryTest_IsCloseToHotspotSlot, Radius) == 0x200, "Offset mismatch for UFortQueryTest_IsCloseToHotspotSlot::Radius");
static_assert(offsetof(UFortQueryTest_IsCloseToHotspotSlot, bIgnoreItemsWithSlotData) == 0x238, "Offset mismatch for UFortQueryTest_IsCloseToHotspotSlot::bIgnoreItemsWithSlotData");

// Size: 0x200 (Inherited: 0x250, Single: 0xffffffb0)
class UFortQueryTest_IsCloseToPatrolWard : public UEnvQueryTest
{
public:
    uint8_t WardEffectTypeFilter; // 0x1f8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_IsCloseToPatrolWard) == 0x200, "Size mismatch for UFortQueryTest_IsCloseToPatrolWard");
static_assert(offsetof(UFortQueryTest_IsCloseToPatrolWard, WardEffectTypeFilter) == 0x1f8, "Offset mismatch for UFortQueryTest_IsCloseToPatrolWard::WardEffectTypeFilter");

// Size: 0x230 (Inherited: 0x250, Single: 0xffffffe0)
class UFortQueryTest_IsGoalForAssignment : public UEnvQueryTest
{
public:
    bool bRetrieveRootAssignmentFromOwner; // 0x1f8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
    FFortAIAssignmentIdentifier RootAssignmentID; // 0x200 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_IsGoalForAssignment) == 0x230, "Size mismatch for UFortQueryTest_IsGoalForAssignment");
static_assert(offsetof(UFortQueryTest_IsGoalForAssignment, bRetrieveRootAssignmentFromOwner) == 0x1f8, "Offset mismatch for UFortQueryTest_IsGoalForAssignment::bRetrieveRootAssignmentFromOwner");
static_assert(offsetof(UFortQueryTest_IsGoalForAssignment, RootAssignmentID) == 0x200, "Offset mismatch for UFortQueryTest_IsGoalForAssignment::RootAssignmentID");

// Size: 0x320 (Inherited: 0x4b8, Single: 0xfffffe68)
class UFortQueryTest_IsGoalHostile : public UFortQueryTest_GoalBase
{
public:
    FGameplayTagQuery OwnerTagQuery; // 0x268 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery EnemyPawnTagsToConsider; // 0x2b0 (Size: 0x48, Type: StructProperty)
    FGameplayTagContainer BuildingTagsToConsider; // 0x2f8 (Size: 0x20, Type: StructProperty)
    bool bConsiderDefenders; // 0x318 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_319[0x7]; // 0x319 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_IsGoalHostile) == 0x320, "Size mismatch for UFortQueryTest_IsGoalHostile");
static_assert(offsetof(UFortQueryTest_IsGoalHostile, OwnerTagQuery) == 0x268, "Offset mismatch for UFortQueryTest_IsGoalHostile::OwnerTagQuery");
static_assert(offsetof(UFortQueryTest_IsGoalHostile, EnemyPawnTagsToConsider) == 0x2b0, "Offset mismatch for UFortQueryTest_IsGoalHostile::EnemyPawnTagsToConsider");
static_assert(offsetof(UFortQueryTest_IsGoalHostile, BuildingTagsToConsider) == 0x2f8, "Offset mismatch for UFortQueryTest_IsGoalHostile::BuildingTagsToConsider");
static_assert(offsetof(UFortQueryTest_IsGoalHostile, bConsiderDefenders) == 0x318, "Offset mismatch for UFortQueryTest_IsGoalHostile::bConsiderDefenders");

// Size: 0x250 (Inherited: 0x250, Single: 0x0)
class UFortQueryTest_IsInLeaderLOS : public UEnvQueryTest
{
public:
    FGameplayTagQuery OwnerTagQuery; // 0x1f8 (Size: 0x48, Type: StructProperty)
    bool bRequireLOSRayCast; // 0x240 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_241[0x3]; // 0x241 (Size: 0x3, Type: PaddingProperty)
    float RayCastLeaderVerticalOffset; // 0x244 (Size: 0x4, Type: FloatProperty)
    float RayCastItemVerticalOffset; // 0x248 (Size: 0x4, Type: FloatProperty)
    float MinDotProduct; // 0x24c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UFortQueryTest_IsInLeaderLOS) == 0x250, "Size mismatch for UFortQueryTest_IsInLeaderLOS");
static_assert(offsetof(UFortQueryTest_IsInLeaderLOS, OwnerTagQuery) == 0x1f8, "Offset mismatch for UFortQueryTest_IsInLeaderLOS::OwnerTagQuery");
static_assert(offsetof(UFortQueryTest_IsInLeaderLOS, bRequireLOSRayCast) == 0x240, "Offset mismatch for UFortQueryTest_IsInLeaderLOS::bRequireLOSRayCast");
static_assert(offsetof(UFortQueryTest_IsInLeaderLOS, RayCastLeaderVerticalOffset) == 0x244, "Offset mismatch for UFortQueryTest_IsInLeaderLOS::RayCastLeaderVerticalOffset");
static_assert(offsetof(UFortQueryTest_IsInLeaderLOS, RayCastItemVerticalOffset) == 0x248, "Offset mismatch for UFortQueryTest_IsInLeaderLOS::RayCastItemVerticalOffset");
static_assert(offsetof(UFortQueryTest_IsInLeaderLOS, MinDotProduct) == 0x24c, "Offset mismatch for UFortQueryTest_IsInLeaderLOS::MinDotProduct");

// Size: 0x3c0 (Inherited: 0x530, Single: 0xfffffe90)
class UFortQueryTest_IsObstructed : public UEnvQueryTest_Trace
{
public:
    FAIDataProviderBoolValue OverrideContextLocationXWithItemLocationX; // 0x2e0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue OverrideContextLocationYWithItemLocationY; // 0x318 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue OverrideContextLocationZWithItemLocationZ; // 0x350 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue OverrideItemLocationZWithContextLocationZ; // 0x388 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_IsObstructed) == 0x3c0, "Size mismatch for UFortQueryTest_IsObstructed");
static_assert(offsetof(UFortQueryTest_IsObstructed, OverrideContextLocationXWithItemLocationX) == 0x2e0, "Offset mismatch for UFortQueryTest_IsObstructed::OverrideContextLocationXWithItemLocationX");
static_assert(offsetof(UFortQueryTest_IsObstructed, OverrideContextLocationYWithItemLocationY) == 0x318, "Offset mismatch for UFortQueryTest_IsObstructed::OverrideContextLocationYWithItemLocationY");
static_assert(offsetof(UFortQueryTest_IsObstructed, OverrideContextLocationZWithItemLocationZ) == 0x350, "Offset mismatch for UFortQueryTest_IsObstructed::OverrideContextLocationZWithItemLocationZ");
static_assert(offsetof(UFortQueryTest_IsObstructed, OverrideItemLocationZWithContextLocationZ) == 0x388, "Offset mismatch for UFortQueryTest_IsObstructed::OverrideItemLocationZWithContextLocationZ");

// Size: 0x388 (Inherited: 0x530, Single: 0xfffffe58)
class UFortQueryTest_IsObstructedOverlap : public UEnvQueryTest_Trace
{
public:
    FAIDataProviderBoolValue OverrideContextLocationXWithItemLocationX; // 0x2e0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue OverrideContextLocationYWithItemLocationY; // 0x318 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue OverrideContextLocationZWithItemLocationZ; // 0x350 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_IsObstructedOverlap) == 0x388, "Size mismatch for UFortQueryTest_IsObstructedOverlap");
static_assert(offsetof(UFortQueryTest_IsObstructedOverlap, OverrideContextLocationXWithItemLocationX) == 0x2e0, "Offset mismatch for UFortQueryTest_IsObstructedOverlap::OverrideContextLocationXWithItemLocationX");
static_assert(offsetof(UFortQueryTest_IsObstructedOverlap, OverrideContextLocationYWithItemLocationY) == 0x318, "Offset mismatch for UFortQueryTest_IsObstructedOverlap::OverrideContextLocationYWithItemLocationY");
static_assert(offsetof(UFortQueryTest_IsObstructedOverlap, OverrideContextLocationZWithItemLocationZ) == 0x350, "Offset mismatch for UFortQueryTest_IsObstructedOverlap::OverrideContextLocationZWithItemLocationZ");

// Size: 0x260 (Inherited: 0x250, Single: 0x10)
class UFortQueryTest_MissionGameplayTagMatch : public UEnvQueryTest
{
public:
    FGameplayTagQuery MissionPlacementActorTagQuery; // 0x1f8 (Size: 0x48, Type: StructProperty)
    FGameplayTagContainer GameplayTagsToMatch; // 0x240 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_MissionGameplayTagMatch) == 0x260, "Size mismatch for UFortQueryTest_MissionGameplayTagMatch");
static_assert(offsetof(UFortQueryTest_MissionGameplayTagMatch, MissionPlacementActorTagQuery) == 0x1f8, "Offset mismatch for UFortQueryTest_MissionGameplayTagMatch::MissionPlacementActorTagQuery");
static_assert(offsetof(UFortQueryTest_MissionGameplayTagMatch, GameplayTagsToMatch) == 0x240, "Offset mismatch for UFortQueryTest_MissionGameplayTagMatch::GameplayTagsToMatch");

// Size: 0x240 (Inherited: 0x250, Single: 0xfffffff0)
class UFortQueryTest_MissionSameMap : public UEnvQueryTest
{
public:
    FGameplayTagQuery MissionPlacementActorTagQuery; // 0x1f8 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_MissionSameMap) == 0x240, "Size mismatch for UFortQueryTest_MissionSameMap");
static_assert(offsetof(UFortQueryTest_MissionSameMap, MissionPlacementActorTagQuery) == 0x1f8, "Offset mismatch for UFortQueryTest_MissionSameMap::MissionPlacementActorTagQuery");

// Size: 0x200 (Inherited: 0x250, Single: 0xffffffb0)
class UFortQueryTest_NavGraphDistance : public UEnvQueryTest
{
public:
    UClass* DistanceTo; // 0x1f8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryTest_NavGraphDistance) == 0x200, "Size mismatch for UFortQueryTest_NavGraphDistance");
static_assert(offsetof(UFortQueryTest_NavGraphDistance, DistanceTo) == 0x1f8, "Offset mismatch for UFortQueryTest_NavGraphDistance::DistanceTo");

// Size: 0x210 (Inherited: 0x250, Single: 0xffffffc0)
class UFortQueryTest_OnFlatSurface : public UEnvQueryTest
{
public:
    float Radius; // 0x1f8 (Size: 0x4, Type: FloatProperty)
    float ToleranceZ; // 0x1fc (Size: 0x4, Type: FloatProperty)
    float TraceOffsetUp; // 0x200 (Size: 0x4, Type: FloatProperty)
    float TraceOffsetDown; // 0x204 (Size: 0x4, Type: FloatProperty)
    uint32_t NumberOfIteration; // 0x208 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_20c[0x4]; // 0x20c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_OnFlatSurface) == 0x210, "Size mismatch for UFortQueryTest_OnFlatSurface");
static_assert(offsetof(UFortQueryTest_OnFlatSurface, Radius) == 0x1f8, "Offset mismatch for UFortQueryTest_OnFlatSurface::Radius");
static_assert(offsetof(UFortQueryTest_OnFlatSurface, ToleranceZ) == 0x1fc, "Offset mismatch for UFortQueryTest_OnFlatSurface::ToleranceZ");
static_assert(offsetof(UFortQueryTest_OnFlatSurface, TraceOffsetUp) == 0x200, "Offset mismatch for UFortQueryTest_OnFlatSurface::TraceOffsetUp");
static_assert(offsetof(UFortQueryTest_OnFlatSurface, TraceOffsetDown) == 0x204, "Offset mismatch for UFortQueryTest_OnFlatSurface::TraceOffsetDown");
static_assert(offsetof(UFortQueryTest_OnFlatSurface, NumberOfIteration) == 0x208, "Offset mismatch for UFortQueryTest_OnFlatSurface::NumberOfIteration");

// Size: 0x218 (Inherited: 0x250, Single: 0xffffffc8)
class UFortQueryTest_OnFlatSurfaceNoNavMesh : public UEnvQueryTest
{
public:
    float Radius; // 0x1f8 (Size: 0x4, Type: FloatProperty)
    float ZTolerance; // 0x1fc (Size: 0x4, Type: FloatProperty)
    float NormalTolerance; // 0x200 (Size: 0x4, Type: FloatProperty)
    float TraceOffset; // 0x204 (Size: 0x4, Type: FloatProperty)
    TArray<UClass*> ActorClassesToIgnoreInTrace; // 0x208 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortQueryTest_OnFlatSurfaceNoNavMesh) == 0x218, "Size mismatch for UFortQueryTest_OnFlatSurfaceNoNavMesh");
static_assert(offsetof(UFortQueryTest_OnFlatSurfaceNoNavMesh, Radius) == 0x1f8, "Offset mismatch for UFortQueryTest_OnFlatSurfaceNoNavMesh::Radius");
static_assert(offsetof(UFortQueryTest_OnFlatSurfaceNoNavMesh, ZTolerance) == 0x1fc, "Offset mismatch for UFortQueryTest_OnFlatSurfaceNoNavMesh::ZTolerance");
static_assert(offsetof(UFortQueryTest_OnFlatSurfaceNoNavMesh, NormalTolerance) == 0x200, "Offset mismatch for UFortQueryTest_OnFlatSurfaceNoNavMesh::NormalTolerance");
static_assert(offsetof(UFortQueryTest_OnFlatSurfaceNoNavMesh, TraceOffset) == 0x204, "Offset mismatch for UFortQueryTest_OnFlatSurfaceNoNavMesh::TraceOffset");
static_assert(offsetof(UFortQueryTest_OnFlatSurfaceNoNavMesh, ActorClassesToIgnoreInTrace) == 0x208, "Offset mismatch for UFortQueryTest_OnFlatSurfaceNoNavMesh::ActorClassesToIgnoreInTrace");

// Size: 0x2c0 (Inherited: 0x788, Single: 0xfffffb38)
class UFortQueryTest_PathfindingBatch : public UEnvQueryTest_PathfindingBatch
{
public:
    FGameplayTag NavFilterTag; // 0x2b8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2bc[0x4]; // 0x2bc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_PathfindingBatch) == 0x2c0, "Size mismatch for UFortQueryTest_PathfindingBatch");
static_assert(offsetof(UFortQueryTest_PathfindingBatch, NavFilterTag) == 0x2b8, "Offset mismatch for UFortQueryTest_PathfindingBatch::NavFilterTag");

// Size: 0x270 (Inherited: 0x4b8, Single: 0xfffffdb8)
class UFortQueryTest_PawnHealth : public UFortQueryTest_GoalBase
{
public:
    bool bUsePercentHealth; // 0x268 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_269[0x7]; // 0x269 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_PawnHealth) == 0x270, "Size mismatch for UFortQueryTest_PawnHealth");
static_assert(offsetof(UFortQueryTest_PawnHealth, bUsePercentHealth) == 0x268, "Offset mismatch for UFortQueryTest_PawnHealth::bUsePercentHealth");

// Size: 0x268 (Inherited: 0x4b8, Single: 0xfffffdb0)
class UFortQueryTest_PawnIsDBNO : public UFortQueryTest_GoalBase
{
public:
};

static_assert(sizeof(UFortQueryTest_PawnIsDBNO) == 0x268, "Size mismatch for UFortQueryTest_PawnIsDBNO");

// Size: 0x208 (Inherited: 0x250, Single: 0xffffffb8)
class UFortQueryTest_PerceptionAge : public UEnvQueryTest
{
public:
    TEnumAsByte<ECorePerceptionTypes> Sense; // 0x1f8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
    UClass* SenseClass; // 0x200 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryTest_PerceptionAge) == 0x208, "Size mismatch for UFortQueryTest_PerceptionAge");
static_assert(offsetof(UFortQueryTest_PerceptionAge, Sense) == 0x1f8, "Offset mismatch for UFortQueryTest_PerceptionAge::Sense");
static_assert(offsetof(UFortQueryTest_PerceptionAge, SenseClass) == 0x200, "Offset mismatch for UFortQueryTest_PerceptionAge::SenseClass");

// Size: 0x478 (Inherited: 0x4b8, Single: 0xffffffc0)
class UFortQueryTest_PerceptionAll : public UFortQueryTest_GoalBase
{
public:
    FAIDataProviderFloatValue SenseScores[0x6]; // 0x268 (Size: 0x150, Type: StructProperty)
    TMap<FAIDataProviderFloatValue, UClass*> AdditionalSenseScores; // 0x3b8 (Size: 0x50, Type: MapProperty)
    FAIDataProviderFloatValue MinSenseAge; // 0x408 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue MaxSenseAge; // 0x440 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_PerceptionAll) == 0x478, "Size mismatch for UFortQueryTest_PerceptionAll");
static_assert(offsetof(UFortQueryTest_PerceptionAll, SenseScores) == 0x268, "Offset mismatch for UFortQueryTest_PerceptionAll::SenseScores");
static_assert(offsetof(UFortQueryTest_PerceptionAll, AdditionalSenseScores) == 0x3b8, "Offset mismatch for UFortQueryTest_PerceptionAll::AdditionalSenseScores");
static_assert(offsetof(UFortQueryTest_PerceptionAll, MinSenseAge) == 0x408, "Offset mismatch for UFortQueryTest_PerceptionAll::MinSenseAge");
static_assert(offsetof(UFortQueryTest_PerceptionAll, MaxSenseAge) == 0x440, "Offset mismatch for UFortQueryTest_PerceptionAll::MaxSenseAge");

// Size: 0x208 (Inherited: 0x250, Single: 0xffffffb8)
class UFortQueryTest_PerceptionExists : public UEnvQueryTest
{
public:
    TEnumAsByte<ECorePerceptionTypes> Sense; // 0x1f8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
    UClass* SenseClass; // 0x200 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFortQueryTest_PerceptionExists) == 0x208, "Size mismatch for UFortQueryTest_PerceptionExists");
static_assert(offsetof(UFortQueryTest_PerceptionExists, Sense) == 0x1f8, "Offset mismatch for UFortQueryTest_PerceptionExists::Sense");
static_assert(offsetof(UFortQueryTest_PerceptionExists, SenseClass) == 0x200, "Offset mismatch for UFortQueryTest_PerceptionExists::SenseClass");

// Size: 0x380 (Inherited: 0x4b8, Single: 0xfffffec8)
class UFortQueryTest_PickupDropper : public UFortQueryTest_GoalBase
{
public:
    FAIDataProviderFloatValue ValueConverterDroppedPickup; // 0x268 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValueOtherDroppedPickupInitial; // 0x2a0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue ValueOtherDroppedPickupFinal; // 0x2d8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue TimeOtherDroppedPickupFinal; // 0x310 (Size: 0x38, Type: StructProperty)
    FAIDataProviderBoolValue LerpFromInitialToFinal; // 0x348 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_PickupDropper) == 0x380, "Size mismatch for UFortQueryTest_PickupDropper");
static_assert(offsetof(UFortQueryTest_PickupDropper, ValueConverterDroppedPickup) == 0x268, "Offset mismatch for UFortQueryTest_PickupDropper::ValueConverterDroppedPickup");
static_assert(offsetof(UFortQueryTest_PickupDropper, ValueOtherDroppedPickupInitial) == 0x2a0, "Offset mismatch for UFortQueryTest_PickupDropper::ValueOtherDroppedPickupInitial");
static_assert(offsetof(UFortQueryTest_PickupDropper, ValueOtherDroppedPickupFinal) == 0x2d8, "Offset mismatch for UFortQueryTest_PickupDropper::ValueOtherDroppedPickupFinal");
static_assert(offsetof(UFortQueryTest_PickupDropper, TimeOtherDroppedPickupFinal) == 0x310, "Offset mismatch for UFortQueryTest_PickupDropper::TimeOtherDroppedPickupFinal");
static_assert(offsetof(UFortQueryTest_PickupDropper, LerpFromInitialToFinal) == 0x348, "Offset mismatch for UFortQueryTest_PickupDropper::LerpFromInitialToFinal");

// Size: 0x220 (Inherited: 0x250, Single: 0xffffffd0)
class UFortQueryTest_PointInBuildingFoundation : public UEnvQueryTest
{
public:
    UClass* BuildingFoundationContext; // 0x1f8 (Size: 0x8, Type: ClassProperty)
    UClass* BuildingFoundationClass; // 0x200 (Size: 0x8, Type: ClassProperty)
    FVector BoundingBoxScale; // 0x208 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_PointInBuildingFoundation) == 0x220, "Size mismatch for UFortQueryTest_PointInBuildingFoundation");
static_assert(offsetof(UFortQueryTest_PointInBuildingFoundation, BuildingFoundationContext) == 0x1f8, "Offset mismatch for UFortQueryTest_PointInBuildingFoundation::BuildingFoundationContext");
static_assert(offsetof(UFortQueryTest_PointInBuildingFoundation, BuildingFoundationClass) == 0x200, "Offset mismatch for UFortQueryTest_PointInBuildingFoundation::BuildingFoundationClass");
static_assert(offsetof(UFortQueryTest_PointInBuildingFoundation, BoundingBoxScale) == 0x208, "Offset mismatch for UFortQueryTest_PointInBuildingFoundation::BoundingBoxScale");

// Size: 0x388 (Inherited: 0x4b8, Single: 0xfffffed0)
class UFortQueryTest_PrimaryAssignment : public UFortQueryTest_GoalBase
{
public:
    bool bUseItemActorLocation; // 0x268 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_269[0x7]; // 0x269 (Size: 0x7, Type: PaddingProperty)
    FAIDataProviderFloatValue DistanceClose; // 0x270 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue DistanceFar; // 0x2a8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue PercentValueClose; // 0x2e0 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue PercentValueRegular; // 0x318 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue PercentValueFar; // 0x350 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UFortQueryTest_PrimaryAssignment) == 0x388, "Size mismatch for UFortQueryTest_PrimaryAssignment");
static_assert(offsetof(UFortQueryTest_PrimaryAssignment, bUseItemActorLocation) == 0x268, "Offset mismatch for UFortQueryTest_PrimaryAssignment::bUseItemActorLocation");
static_assert(offsetof(UFortQueryTest_PrimaryAssignment, DistanceClose) == 0x270, "Offset mismatch for UFortQueryTest_PrimaryAssignment::DistanceClose");
static_assert(offsetof(UFortQueryTest_PrimaryAssignment, DistanceFar) == 0x2a8, "Offset mismatch for UFortQueryTest_PrimaryAssignment::DistanceFar");
static_assert(offsetof(UFortQueryTest_PrimaryAssignment, PercentValueClose) == 0x2e0, "Offset mismatch for UFortQueryTest_PrimaryAssignment::PercentValueClose");
static_assert(offsetof(UFortQueryTest_PrimaryAssignment, PercentValueRegular) == 0x318, "Offset mismatch for UFortQueryTest_PrimaryAssignment::PercentValueRegular");
static_assert(offsetof(UFortQueryTest_PrimaryAssignment, PercentValueFar) == 0x350, "Offset mismatch for UFortQueryTest_PrimaryAssignment::PercentValueFar");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UFortQueryTest_ProjectOnNavMesh : public UEnvQueryTest
{
public:
};

static_assert(sizeof(UFortQueryTest_ProjectOnNavMesh) == 0x1f8, "Size mismatch for UFortQueryTest_ProjectOnNavMesh");

// Size: 0x200 (Inherited: 0x250, Single: 0xffffffb0)
class UFortQueryTest_Random : public UEnvQueryTest
{
public:
    uint8_t bUseRandomSeedForAI : 1; // 0x1f8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseRandomSeedForOthers : 1; // 0x1f8:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f9[0x7]; // 0x1f9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_Random) == 0x200, "Size mismatch for UFortQueryTest_Random");
static_assert(offsetof(UFortQueryTest_Random, bUseRandomSeedForAI) == 0x1f8, "Offset mismatch for UFortQueryTest_Random::bUseRandomSeedForAI");
static_assert(offsetof(UFortQueryTest_Random, bUseRandomSeedForOthers) == 0x1f8, "Offset mismatch for UFortQueryTest_Random::bUseRandomSeedForOthers");

// Size: 0x250 (Inherited: 0x250, Single: 0x0)
class UFortQueryTest_TowardNextAthenaSafeZone : public UEnvQueryTest
{
public:
    FAIDataProviderIntValue SafeZoneIndex; // 0x1f8 (Size: 0x38, Type: StructProperty)
    bool bCheckAcceptanceAngleTowardNextCenter; // 0x230 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_231[0x3]; // 0x231 (Size: 0x3, Type: PaddingProperty)
    float AcceptanceAngleTowardNextCenter; // 0x234 (Size: 0x4, Type: FloatProperty)
    TArray<int32_t> ExclusionSafeZoneIndex; // 0x238 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_248[0x8]; // 0x248 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_TowardNextAthenaSafeZone) == 0x250, "Size mismatch for UFortQueryTest_TowardNextAthenaSafeZone");
static_assert(offsetof(UFortQueryTest_TowardNextAthenaSafeZone, SafeZoneIndex) == 0x1f8, "Offset mismatch for UFortQueryTest_TowardNextAthenaSafeZone::SafeZoneIndex");
static_assert(offsetof(UFortQueryTest_TowardNextAthenaSafeZone, bCheckAcceptanceAngleTowardNextCenter) == 0x230, "Offset mismatch for UFortQueryTest_TowardNextAthenaSafeZone::bCheckAcceptanceAngleTowardNextCenter");
static_assert(offsetof(UFortQueryTest_TowardNextAthenaSafeZone, AcceptanceAngleTowardNextCenter) == 0x234, "Offset mismatch for UFortQueryTest_TowardNextAthenaSafeZone::AcceptanceAngleTowardNextCenter");
static_assert(offsetof(UFortQueryTest_TowardNextAthenaSafeZone, ExclusionSafeZoneIndex) == 0x238, "Offset mismatch for UFortQueryTest_TowardNextAthenaSafeZone::ExclusionSafeZoneIndex");

// Size: 0x318 (Inherited: 0x250, Single: 0xc8)
class UFortQueryTest_ValidSurface : public UEnvQueryTest
{
public:
    FAIDataProviderFloatValue Radius; // 0x1f8 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue TraceOffsetUp; // 0x230 (Size: 0x38, Type: StructProperty)
    FAIDataProviderFloatValue TraceOffsetDown; // 0x268 (Size: 0x38, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> TraceCollisionChannel; // 0x2a0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_2a1[0x7]; // 0x2a1 (Size: 0x7, Type: PaddingProperty)
    FAIDataProviderFloatValue FlatSurfaceToleranceZ; // 0x2a8 (Size: 0x38, Type: StructProperty)
    TArray<TSoftObjectPtr<UPhysicalMaterial*>> SurfaceMaterials; // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    bool bAreSurfaceMaterialsValid; // 0x2f0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2f1[0x7]; // 0x2f1 (Size: 0x7, Type: PaddingProperty)
    TArray<TSoftClassPtr> ValidHitActorClasses; // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftClassPtr> InvalidHitActorClasses; // 0x308 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortQueryTest_ValidSurface) == 0x318, "Size mismatch for UFortQueryTest_ValidSurface");
static_assert(offsetof(UFortQueryTest_ValidSurface, Radius) == 0x1f8, "Offset mismatch for UFortQueryTest_ValidSurface::Radius");
static_assert(offsetof(UFortQueryTest_ValidSurface, TraceOffsetUp) == 0x230, "Offset mismatch for UFortQueryTest_ValidSurface::TraceOffsetUp");
static_assert(offsetof(UFortQueryTest_ValidSurface, TraceOffsetDown) == 0x268, "Offset mismatch for UFortQueryTest_ValidSurface::TraceOffsetDown");
static_assert(offsetof(UFortQueryTest_ValidSurface, TraceCollisionChannel) == 0x2a0, "Offset mismatch for UFortQueryTest_ValidSurface::TraceCollisionChannel");
static_assert(offsetof(UFortQueryTest_ValidSurface, FlatSurfaceToleranceZ) == 0x2a8, "Offset mismatch for UFortQueryTest_ValidSurface::FlatSurfaceToleranceZ");
static_assert(offsetof(UFortQueryTest_ValidSurface, SurfaceMaterials) == 0x2e0, "Offset mismatch for UFortQueryTest_ValidSurface::SurfaceMaterials");
static_assert(offsetof(UFortQueryTest_ValidSurface, bAreSurfaceMaterialsValid) == 0x2f0, "Offset mismatch for UFortQueryTest_ValidSurface::bAreSurfaceMaterialsValid");
static_assert(offsetof(UFortQueryTest_ValidSurface, ValidHitActorClasses) == 0x2f8, "Offset mismatch for UFortQueryTest_ValidSurface::ValidHitActorClasses");
static_assert(offsetof(UFortQueryTest_ValidSurface, InvalidHitActorClasses) == 0x308, "Offset mismatch for UFortQueryTest_ValidSurface::InvalidHitActorClasses");

// Size: 0x220 (Inherited: 0x250, Single: 0xffffffd0)
class UFortQueryTest_WithinHotfixVolumeBounds : public UEnvQueryTest
{
public:
    UDataTable* BoundsTable; // 0x1f8 (Size: 0x8, Type: ObjectProperty)
    FVector BoundsExtentBuffer; // 0x200 (Size: 0x18, Type: StructProperty)
    bool bXYOnly; // 0x218 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_219[0x7]; // 0x219 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_WithinHotfixVolumeBounds) == 0x220, "Size mismatch for UFortQueryTest_WithinHotfixVolumeBounds");
static_assert(offsetof(UFortQueryTest_WithinHotfixVolumeBounds, BoundsTable) == 0x1f8, "Offset mismatch for UFortQueryTest_WithinHotfixVolumeBounds::BoundsTable");
static_assert(offsetof(UFortQueryTest_WithinHotfixVolumeBounds, BoundsExtentBuffer) == 0x200, "Offset mismatch for UFortQueryTest_WithinHotfixVolumeBounds::BoundsExtentBuffer");
static_assert(offsetof(UFortQueryTest_WithinHotfixVolumeBounds, bXYOnly) == 0x218, "Offset mismatch for UFortQueryTest_WithinHotfixVolumeBounds::bXYOnly");

// Size: 0x260 (Inherited: 0x250, Single: 0x10)
class UFortQueryTest_WithinTaggedArea : public UEnvQueryTest
{
public:
    FGameplayTagQuery TagQuery; // 0x1f8 (Size: 0x48, Type: StructProperty)
    FVector AreaExtentBuffer; // 0x240 (Size: 0x18, Type: StructProperty)
    bool bAssumeInfiniteHeightForArea; // 0x258 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_259[0x7]; // 0x259 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortQueryTest_WithinTaggedArea) == 0x260, "Size mismatch for UFortQueryTest_WithinTaggedArea");
static_assert(offsetof(UFortQueryTest_WithinTaggedArea, TagQuery) == 0x1f8, "Offset mismatch for UFortQueryTest_WithinTaggedArea::TagQuery");
static_assert(offsetof(UFortQueryTest_WithinTaggedArea, AreaExtentBuffer) == 0x240, "Offset mismatch for UFortQueryTest_WithinTaggedArea::AreaExtentBuffer");
static_assert(offsetof(UFortQueryTest_WithinTaggedArea, bAssumeInfiniteHeightForArea) == 0x258, "Offset mismatch for UFortQueryTest_WithinTaggedArea::bAssumeInfiniteHeightForArea");

// Size: 0x118 (Inherited: 0x178, Single: 0xffffffa0)
class UFortAthenaBTTask_BotAmbushPlayer : public UBTTask_Wait
{
public:
    float FacingPrecision; // 0x88 (Size: 0x4, Type: FloatProperty)
    float WeaponCooldown; // 0x8c (Size: 0x4, Type: FloatProperty)
    bool bClearBlackboardOnFinished; // 0x90 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
    FBlackboardKeySelector TargetedPlayerKeySelector; // 0x98 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector MaxLocationErrorKeySelector; // 0xc0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector MinLocationErrorKeySelector; // 0xe8 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_110[0x8]; // 0x110 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_BotAmbushPlayer) == 0x118, "Size mismatch for UFortAthenaBTTask_BotAmbushPlayer");
static_assert(offsetof(UFortAthenaBTTask_BotAmbushPlayer, FacingPrecision) == 0x88, "Offset mismatch for UFortAthenaBTTask_BotAmbushPlayer::FacingPrecision");
static_assert(offsetof(UFortAthenaBTTask_BotAmbushPlayer, WeaponCooldown) == 0x8c, "Offset mismatch for UFortAthenaBTTask_BotAmbushPlayer::WeaponCooldown");
static_assert(offsetof(UFortAthenaBTTask_BotAmbushPlayer, bClearBlackboardOnFinished) == 0x90, "Offset mismatch for UFortAthenaBTTask_BotAmbushPlayer::bClearBlackboardOnFinished");
static_assert(offsetof(UFortAthenaBTTask_BotAmbushPlayer, TargetedPlayerKeySelector) == 0x98, "Offset mismatch for UFortAthenaBTTask_BotAmbushPlayer::TargetedPlayerKeySelector");
static_assert(offsetof(UFortAthenaBTTask_BotAmbushPlayer, MaxLocationErrorKeySelector) == 0xc0, "Offset mismatch for UFortAthenaBTTask_BotAmbushPlayer::MaxLocationErrorKeySelector");
static_assert(offsetof(UFortAthenaBTTask_BotAmbushPlayer, MinLocationErrorKeySelector) == 0xe8, "Offset mismatch for UFortAthenaBTTask_BotAmbushPlayer::MinLocationErrorKeySelector");

// Size: 0x70 (Inherited: 0x148, Single: 0xffffff28)
class UFortAthenaBTDecorator_BehaviorControls : public UBTDecorator
{
public:
    uint8_t BehaviorTreeBranch; // 0x68 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTDecorator_BehaviorControls) == 0x70, "Size mismatch for UFortAthenaBTDecorator_BehaviorControls");
static_assert(offsetof(UFortAthenaBTDecorator_BehaviorControls, BehaviorTreeBranch) == 0x68, "Offset mismatch for UFortAthenaBTDecorator_BehaviorControls::BehaviorTreeBranch");

// Size: 0xd8 (Inherited: 0x170, Single: 0xffffff68)
class UFortAthenaAIBotEvaluator_AimDownSight : public UFortAthenaAIBotEvaluator
{
public:
    FName WeaponKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    FName ThrowableAttacksName; // 0xac (Size: 0x4, Type: NameProperty)
    FName TargetActorName; // 0xb0 (Size: 0x4, Type: NameProperty)
    FName UrgentMovementName; // 0xb4 (Size: 0x4, Type: NameProperty)
    bool bSkipTargetChecks; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c8[0x10]; // 0xc8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_AimDownSight) == 0xd8, "Size mismatch for UFortAthenaAIBotEvaluator_AimDownSight");
static_assert(offsetof(UFortAthenaAIBotEvaluator_AimDownSight, WeaponKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_AimDownSight::WeaponKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_AimDownSight, ThrowableAttacksName) == 0xac, "Offset mismatch for UFortAthenaAIBotEvaluator_AimDownSight::ThrowableAttacksName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_AimDownSight, TargetActorName) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_AimDownSight::TargetActorName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_AimDownSight, UrgentMovementName) == 0xb4, "Offset mismatch for UFortAthenaAIBotEvaluator_AimDownSight::UrgentMovementName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_AimDownSight, bSkipTargetChecks) == 0xb8, "Offset mismatch for UFortAthenaAIBotEvaluator_AimDownSight::bSkipTargetChecks");
static_assert(offsetof(UFortAthenaAIBotEvaluator_AimDownSight, CacheAimingDigestedSkillSet) == 0xc0, "Offset mismatch for UFortAthenaAIBotEvaluator_AimDownSight::CacheAimingDigestedSkillSet");

// Size: 0x208 (Inherited: 0x3f0, Single: 0xfffffe18)
class UFortAthenaAIBotEvaluator_Ambush : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName LastKnownPositionName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName DestinationKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName MoveToDestinationKeyName; // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName AggressivenessName; // 0x1ac (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1b0[0x58]; // 0x1b0 (Size: 0x58, Type: PaddingProperty)

private:
    void OnAssignedPerksChangedEvent(); // 0xef2e204 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Ambush) == 0x208, "Size mismatch for UFortAthenaAIBotEvaluator_Ambush");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Ambush, LastKnownPositionName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Ambush::LastKnownPositionName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Ambush, DestinationKeyName) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_Ambush::DestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Ambush, MoveToDestinationKeyName) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_Ambush::MoveToDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Ambush, AggressivenessName) == 0x1ac, "Offset mismatch for UFortAthenaAIBotEvaluator_Ambush::AggressivenessName");

// Size: 0x1b8 (Inherited: 0x3f0, Single: 0xfffffdc8)
class UFortAthenaAIBotEvaluator_Attack : public UFortAthenaAIBotEvaluator_Movement
{
public:
    uint8_t Pad_1a0[0x4]; // 0x1a0 (Size: 0x4, Type: PaddingProperty)
    FName WeaponKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName MoveToDestinationKeyName; // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName TargetActorName; // 0x1ac (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1b0[0x8]; // 0x1b0 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Attack) == 0x1b8, "Size mismatch for UFortAthenaAIBotEvaluator_Attack");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Attack, WeaponKeyName) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_Attack::WeaponKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Attack, MoveToDestinationKeyName) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_Attack::MoveToDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Attack, TargetActorName) == 0x1ac, "Offset mismatch for UFortAthenaAIBotEvaluator_Attack::TargetActorName");

// Size: 0x1c8 (Inherited: 0x3f0, Single: 0xfffffdd8)
class UFortAthenaAIBotEvaluator_AvoidThreat : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName AvoidThreatKeyName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName AvoidThreatMovementStateKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName AvoidThreatDestinationKeyName; // 0x1a8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1ac[0xc]; // 0x1ac (Size: 0xc, Type: PaddingProperty)
    AActor* CurrentThreatActorAvoiding; // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotEvasiveManeuversDigestedSkillSet* CacheEMDigestedSkillSet; // 0x1c0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_AvoidThreat) == 0x1c8, "Size mismatch for UFortAthenaAIBotEvaluator_AvoidThreat");
static_assert(offsetof(UFortAthenaAIBotEvaluator_AvoidThreat, AvoidThreatKeyName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_AvoidThreat::AvoidThreatKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_AvoidThreat, AvoidThreatMovementStateKeyName) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_AvoidThreat::AvoidThreatMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_AvoidThreat, AvoidThreatDestinationKeyName) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_AvoidThreat::AvoidThreatDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_AvoidThreat, CurrentThreatActorAvoiding) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_AvoidThreat::CurrentThreatActorAvoiding");
static_assert(offsetof(UFortAthenaAIBotEvaluator_AvoidThreat, CacheEMDigestedSkillSet) == 0x1c0, "Offset mismatch for UFortAthenaAIBotEvaluator_AvoidThreat::CacheEMDigestedSkillSet");

// Size: 0x258 (Inherited: 0x3f0, Single: 0xfffffe68)
class UFortAthenaAIBotEvaluator_Bunker : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName BuildExecutionStatusKeyName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName HealingStatusKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    FGameplayTagContainer DangerTags; // 0x1a8 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_1c8[0x90]; // 0x1c8 (Size: 0x90, Type: PaddingProperty)

private:
    void OnAssignedPerksChangedEvent(); // 0xef2e218 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Bunker) == 0x258, "Size mismatch for UFortAthenaAIBotEvaluator_Bunker");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Bunker, BuildExecutionStatusKeyName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Bunker::BuildExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Bunker, HealingStatusKeyName) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_Bunker::HealingStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Bunker, DangerTags) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_Bunker::DangerTags");

// Size: 0xb0 (Inherited: 0x170, Single: 0xffffff40)
class UFortAthenaAIBotEvaluator_CanMove : public UFortAthenaAIBotEvaluator
{
public:
    FName CanMoveKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_CanMove) == 0xb0, "Size mismatch for UFortAthenaAIBotEvaluator_CanMove");
static_assert(offsetof(UFortAthenaAIBotEvaluator_CanMove, CanMoveKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_CanMove::CanMoveKeyName");

// Size: 0xf8 (Inherited: 0x170, Single: 0xffffff88)
class UFortAthenaAIBotEvaluator_CharacterLaunched : public UFortAthenaAIBotEvaluator
{
public:
    bool bSteerInSameDirectionAsLaunchVelocity; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x3]; // 0xa9 (Size: 0x3, Type: PaddingProperty)
    FName CharacterLaunchedExecutionStatusKeyName; // 0xac (Size: 0x4, Type: NameProperty)
    FName SteerDirectionKeyName; // 0xb0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b4[0x4]; // 0xb4 (Size: 0x4, Type: PaddingProperty)
    FVector LastLaunchVelocity; // 0xb8 (Size: 0x18, Type: StructProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* CachedMovementSkillSet; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIRuntimeParameters_BehaviorTreeControl* CachedBehaviorControlsRuntimeParameters; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    float LastZiplineTimestamp; // 0xe0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_e4[0x14]; // 0xe4 (Size: 0x14, Type: PaddingProperty)

private:
    void OnCharacterLaunchChanged(UFortMovementComp_Character*& MovementComponent, const FVector LaunchVelocity); // 0xef520cc (Index: 0x0, Flags: Final|Native|Private|HasOutParms|HasDefaults)
    void OnZiplineStateChanged(bool& bIsZiplining, AFortPlayerPawn*& FortPlayerPawn); // 0xef52be0 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_CharacterLaunched) == 0xf8, "Size mismatch for UFortAthenaAIBotEvaluator_CharacterLaunched");
static_assert(offsetof(UFortAthenaAIBotEvaluator_CharacterLaunched, bSteerInSameDirectionAsLaunchVelocity) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_CharacterLaunched::bSteerInSameDirectionAsLaunchVelocity");
static_assert(offsetof(UFortAthenaAIBotEvaluator_CharacterLaunched, CharacterLaunchedExecutionStatusKeyName) == 0xac, "Offset mismatch for UFortAthenaAIBotEvaluator_CharacterLaunched::CharacterLaunchedExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_CharacterLaunched, SteerDirectionKeyName) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_CharacterLaunched::SteerDirectionKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_CharacterLaunched, LastLaunchVelocity) == 0xb8, "Offset mismatch for UFortAthenaAIBotEvaluator_CharacterLaunched::LastLaunchVelocity");
static_assert(offsetof(UFortAthenaAIBotEvaluator_CharacterLaunched, CachedMovementSkillSet) == 0xd0, "Offset mismatch for UFortAthenaAIBotEvaluator_CharacterLaunched::CachedMovementSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_CharacterLaunched, CachedBehaviorControlsRuntimeParameters) == 0xd8, "Offset mismatch for UFortAthenaAIBotEvaluator_CharacterLaunched::CachedBehaviorControlsRuntimeParameters");
static_assert(offsetof(UFortAthenaAIBotEvaluator_CharacterLaunched, LastZiplineTimestamp) == 0xe0, "Offset mismatch for UFortAthenaAIBotEvaluator_CharacterLaunched::LastZiplineTimestamp");

// Size: 0x310 (Inherited: 0x170, Single: 0x1a0)
class UFortAthenaAIBotEvaluator_Conversation : public UFortAthenaAIBotEvaluator
{
public:
    FName IsInConversationStateName; // 0xa8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
    TArray<FName> ExecutionStatusesToCheckedToAvoidStoppingWhenNearActorNames; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_c0[0x10]; // 0xc0 (Size: 0x10, Type: PaddingProperty)
    TArray<FName> ExecutionStatusesToCheckForAllowToAvoidStoppingWhenNearActorNames; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_e0[0x10]; // 0xe0 (Size: 0x10, Type: PaddingProperty)
    TArray<FName> MovementStatusesToCheckedToAvoidStoppingWhenNearActorNames; // 0xf0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_100[0x10]; // 0x100 (Size: 0x10, Type: PaddingProperty)
    bool bForceStopIfNoPlayerNearby; // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_111[0x7]; // 0x111 (Size: 0x7, Type: PaddingProperty)
    FScalableFloat HolsterWeaponOnConversationEnter; // 0x118 (Size: 0x28, Type: StructProperty)
    FGameplayTagQuery RequiredTagQueryToStopNearActor; // 0x140 (Size: 0x48, Type: StructProperty)
    FScalableFloat ConversationTimeout; // 0x188 (Size: 0x28, Type: StructProperty)
    FScalableFloat ConversationTimeoutWithOtherPlayerNearby; // 0x1b0 (Size: 0x28, Type: StructProperty)
    FScalableFloat BanTimeAfterTimeout; // 0x1d8 (Size: 0x28, Type: StructProperty)
    UFortAthenaAIRuntimeParameters_Conversation* ConversationRuntimeParameters; // 0x200 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorToFocus; // 0x208 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_210[0x100]; // 0x210 (Size: 0x100, Type: PaddingProperty)

private:
    void OnPlayerPawnSpawned(AAIController*& Controller, AFortPawn*& Pawn); // 0xef525d0 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Conversation) == 0x310, "Size mismatch for UFortAthenaAIBotEvaluator_Conversation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Conversation, IsInConversationStateName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_Conversation::IsInConversationStateName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Conversation, ExecutionStatusesToCheckedToAvoidStoppingWhenNearActorNames) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_Conversation::ExecutionStatusesToCheckedToAvoidStoppingWhenNearActorNames");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Conversation, ExecutionStatusesToCheckForAllowToAvoidStoppingWhenNearActorNames) == 0xd0, "Offset mismatch for UFortAthenaAIBotEvaluator_Conversation::ExecutionStatusesToCheckForAllowToAvoidStoppingWhenNearActorNames");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Conversation, MovementStatusesToCheckedToAvoidStoppingWhenNearActorNames) == 0xf0, "Offset mismatch for UFortAthenaAIBotEvaluator_Conversation::MovementStatusesToCheckedToAvoidStoppingWhenNearActorNames");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Conversation, bForceStopIfNoPlayerNearby) == 0x110, "Offset mismatch for UFortAthenaAIBotEvaluator_Conversation::bForceStopIfNoPlayerNearby");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Conversation, HolsterWeaponOnConversationEnter) == 0x118, "Offset mismatch for UFortAthenaAIBotEvaluator_Conversation::HolsterWeaponOnConversationEnter");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Conversation, RequiredTagQueryToStopNearActor) == 0x140, "Offset mismatch for UFortAthenaAIBotEvaluator_Conversation::RequiredTagQueryToStopNearActor");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Conversation, ConversationTimeout) == 0x188, "Offset mismatch for UFortAthenaAIBotEvaluator_Conversation::ConversationTimeout");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Conversation, ConversationTimeoutWithOtherPlayerNearby) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_Conversation::ConversationTimeoutWithOtherPlayerNearby");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Conversation, BanTimeAfterTimeout) == 0x1d8, "Offset mismatch for UFortAthenaAIBotEvaluator_Conversation::BanTimeAfterTimeout");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Conversation, ConversationRuntimeParameters) == 0x200, "Offset mismatch for UFortAthenaAIBotEvaluator_Conversation::ConversationRuntimeParameters");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Conversation, ActorToFocus) == 0x208, "Offset mismatch for UFortAthenaAIBotEvaluator_Conversation::ActorToFocus");

// Size: 0x388 (Inherited: 0x3f0, Single: 0xffffff98)
class UFortAthenaAIBotEvaluator_Converted : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName ShouldMoveTowardsConverterName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName ShouldTeleportTowardsConverterName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName ConvertedAllowPatrolAroundName; // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName ConvertedAllowScanAroundWhenWaitingName; // 0x1ac (Size: 0x4, Type: NameProperty)
    FName ConvertedDestinationName; // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName CrouchExecutionStatusName; // 0x1b4 (Size: 0x4, Type: NameProperty)
    FVector TeleportLocationProjectionExtent; // 0x1b8 (Size: 0x18, Type: StructProperty)
    FVector MovingFromLosLocationProjectionExtent; // 0x1d0 (Size: 0x18, Type: StructProperty)
    FScalableFloat AmountOfTimesNonHostilePawnNeedsToBeDamagedForTargeting; // 0x1e8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TimeToTrackDamagedActors; // 0x210 (Size: 0x28, Type: StructProperty)
    FScalableFloat NearbyPlayerDistanceForTeleportTowardsConverter; // 0x238 (Size: 0x28, Type: StructProperty)
    FScalableFloat PlayerFOVForNearbyPlayersVisibility; // 0x260 (Size: 0x28, Type: StructProperty)
    UEnvQuery* TeleportToConverterQueryTemplate; // 0x288 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EEnvQueryRunMode> TeleportToConverterRunMode; // 0x290 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_291[0x7]; // 0x291 (Size: 0x7, Type: PaddingProperty)
    TArray<FMimicConverterAbilityData> AbilitiesToMimic; // 0x298 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagQuery RequiredTagQueryToTargetConverterDamagedPawn; // 0x2a8 (Size: 0x48, Type: StructProperty)
    FValueOrBBKey_Bool UpdateConvertedDestinationWhileUsingNavLinks; // 0x2f0 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_2fc[0x6c]; // 0x2fc (Size: 0x6c, Type: PaddingProperty)
    AFortPawn* ConverterPawn; // 0x368 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIRuntimeParameters_AIBotConvert* CachedAIBotConvertParameters; // 0x370 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_378[0x10]; // 0x378 (Size: 0x10, Type: PaddingProperty)

protected:
    void OnConvertedEvent(AFortPawn*& InstigatorPawn, AFortPawn*& ConvertedPawn); // 0xef52294 (Index: 0x0, Flags: Final|Native|Protected)
    void OnUnconvertedEvent(AFortPawn*& UnconvertedPawn, EUnconvertReason& const UnconvertReason); // 0xef529e0 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Converted) == 0x388, "Size mismatch for UFortAthenaAIBotEvaluator_Converted");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, ShouldMoveTowardsConverterName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::ShouldMoveTowardsConverterName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, ShouldTeleportTowardsConverterName) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::ShouldTeleportTowardsConverterName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, ConvertedAllowPatrolAroundName) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::ConvertedAllowPatrolAroundName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, ConvertedAllowScanAroundWhenWaitingName) == 0x1ac, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::ConvertedAllowScanAroundWhenWaitingName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, ConvertedDestinationName) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::ConvertedDestinationName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, CrouchExecutionStatusName) == 0x1b4, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::CrouchExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, TeleportLocationProjectionExtent) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::TeleportLocationProjectionExtent");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, MovingFromLosLocationProjectionExtent) == 0x1d0, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::MovingFromLosLocationProjectionExtent");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, AmountOfTimesNonHostilePawnNeedsToBeDamagedForTargeting) == 0x1e8, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::AmountOfTimesNonHostilePawnNeedsToBeDamagedForTargeting");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, TimeToTrackDamagedActors) == 0x210, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::TimeToTrackDamagedActors");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, NearbyPlayerDistanceForTeleportTowardsConverter) == 0x238, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::NearbyPlayerDistanceForTeleportTowardsConverter");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, PlayerFOVForNearbyPlayersVisibility) == 0x260, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::PlayerFOVForNearbyPlayersVisibility");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, TeleportToConverterQueryTemplate) == 0x288, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::TeleportToConverterQueryTemplate");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, TeleportToConverterRunMode) == 0x290, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::TeleportToConverterRunMode");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, AbilitiesToMimic) == 0x298, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::AbilitiesToMimic");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, RequiredTagQueryToTargetConverterDamagedPawn) == 0x2a8, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::RequiredTagQueryToTargetConverterDamagedPawn");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, UpdateConvertedDestinationWhileUsingNavLinks) == 0x2f0, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::UpdateConvertedDestinationWhileUsingNavLinks");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, ConverterPawn) == 0x368, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::ConverterPawn");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Converted, CachedAIBotConvertParameters) == 0x370, "Offset mismatch for UFortAthenaAIBotEvaluator_Converted::CachedAIBotConvertParameters");

// Size: 0xd0 (Inherited: 0x170, Single: 0xffffff60)
class UFortAthenaAIBotEvaluator_DanceOnKill : public UFortAthenaAIBotEvaluator
{
public:
    FName LastKillPositionKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    FName LastKillTimeKeyName; // 0xac (Size: 0x4, Type: NameProperty)
    FName LastKillWasABotKeyName; // 0xb0 (Size: 0x4, Type: NameProperty)
    FName PlayEmoteExecutionStatusKeyName; // 0xb4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b8[0x10]; // 0xb8 (Size: 0x10, Type: PaddingProperty)
    UFortAthenaAIBotEmoteDigestedSkillSet* CacheEmoteDigestedSkillSet; // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_DanceOnKill) == 0xd0, "Size mismatch for UFortAthenaAIBotEvaluator_DanceOnKill");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DanceOnKill, LastKillPositionKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_DanceOnKill::LastKillPositionKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DanceOnKill, LastKillTimeKeyName) == 0xac, "Offset mismatch for UFortAthenaAIBotEvaluator_DanceOnKill::LastKillTimeKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DanceOnKill, LastKillWasABotKeyName) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_DanceOnKill::LastKillWasABotKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DanceOnKill, PlayEmoteExecutionStatusKeyName) == 0xb4, "Offset mismatch for UFortAthenaAIBotEvaluator_DanceOnKill::PlayEmoteExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DanceOnKill, CacheEmoteDigestedSkillSet) == 0xc8, "Offset mismatch for UFortAthenaAIBotEvaluator_DanceOnKill::CacheEmoteDigestedSkillSet");

// Size: 0x148 (Inherited: 0x268, Single: 0xfffffee0)
class UFortAthenaAIBotEvaluator_DangerDetection : public UFortAthenaAIBotEvaluator_TagQuery
{
public:
    uint8_t Pad_f8[0x10]; // 0xf8 (Size: 0x10, Type: PaddingProperty)
    UClass* DangerNavAreaClass; // 0x108 (Size: 0x8, Type: ClassProperty)
    float TimeToCheckForDangerAfterValidQuery; // 0x110 (Size: 0x4, Type: FloatProperty)
    float MaxRadiusToSearchForSafePlace; // 0x114 (Size: 0x4, Type: FloatProperty)
    FName DangerZoneDetectedExecutionStatusName; // 0x118 (Size: 0x4, Type: NameProperty)
    FName DangerZoneDetectedSafeLocationKeyName; // 0x11c (Size: 0x4, Type: NameProperty)
    uint8_t Pad_120[0x8]; // 0x120 (Size: 0x8, Type: PaddingProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* CachedMovementSkillSet; // 0x128 (Size: 0x8, Type: ObjectProperty)
    UAthenaAIServiceZoneManager* CacheZoneManager; // 0x130 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_138[0x10]; // 0x138 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_DangerDetection) == 0x148, "Size mismatch for UFortAthenaAIBotEvaluator_DangerDetection");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DangerDetection, DangerNavAreaClass) == 0x108, "Offset mismatch for UFortAthenaAIBotEvaluator_DangerDetection::DangerNavAreaClass");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DangerDetection, TimeToCheckForDangerAfterValidQuery) == 0x110, "Offset mismatch for UFortAthenaAIBotEvaluator_DangerDetection::TimeToCheckForDangerAfterValidQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DangerDetection, MaxRadiusToSearchForSafePlace) == 0x114, "Offset mismatch for UFortAthenaAIBotEvaluator_DangerDetection::MaxRadiusToSearchForSafePlace");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DangerDetection, DangerZoneDetectedExecutionStatusName) == 0x118, "Offset mismatch for UFortAthenaAIBotEvaluator_DangerDetection::DangerZoneDetectedExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DangerDetection, DangerZoneDetectedSafeLocationKeyName) == 0x11c, "Offset mismatch for UFortAthenaAIBotEvaluator_DangerDetection::DangerZoneDetectedSafeLocationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DangerDetection, CachedMovementSkillSet) == 0x128, "Offset mismatch for UFortAthenaAIBotEvaluator_DangerDetection::CachedMovementSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DangerDetection, CacheZoneManager) == 0x130, "Offset mismatch for UFortAthenaAIBotEvaluator_DangerDetection::CacheZoneManager");

// Size: 0xf8 (Inherited: 0x170, Single: 0xffffff88)
class UFortAthenaAIBotEvaluator_TagQuery : public UFortAthenaAIBotEvaluator
{
public:
    FGameplayTagQuery TagQuery; // 0xa8 (Size: 0x48, Type: StructProperty)
    UAbilitySystemComponent* CachedAbilitySystemComponent; // 0xf0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_TagQuery) == 0xf8, "Size mismatch for UFortAthenaAIBotEvaluator_TagQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TagQuery, TagQuery) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_TagQuery::TagQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TagQuery, CachedAbilitySystemComponent) == 0xf0, "Offset mismatch for UFortAthenaAIBotEvaluator_TagQuery::CachedAbilitySystemComponent");

// Size: 0x200 (Inherited: 0x3f0, Single: 0xfffffe10)
class UFortAthenaAIBotEvaluator_DBNO : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName DBNODestinationKeyName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1a4[0x2]; // 0x1a4 (Size: 0x2, Type: PaddingProperty)
    uint8_t bAllowReachSquadmates : 1; // 0x1a6:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAllowReachSameFactionNPCs : 1; // 0x1a6:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a7[0x1]; // 0x1a7 (Size: 0x1, Type: PaddingProperty)
    TArray<AFortPlayerPawnAthena*> AllyPawns; // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    FVector CachedCurrentDestination; // 0x1b8 (Size: 0x18, Type: StructProperty)
    UFortAthenaAIBotDBNODigestedSkillSet* DBNOSkillSet; // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAICoverComponent* CachedCoverComponent; // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIRuntimeParameters_DBNOBehavior* DBNOBehaviorRuntimeParameters; // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1e8[0x18]; // 0x1e8 (Size: 0x18, Type: PaddingProperty)

private:
    void OnAllyPawnDBNOStateChanged(AFortPawn*& InPlayer, bool& bInIsDBNO); // 0xef51eac (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_DBNO) == 0x200, "Size mismatch for UFortAthenaAIBotEvaluator_DBNO");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DBNO, DBNODestinationKeyName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_DBNO::DBNODestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DBNO, bAllowReachSquadmates) == 0x1a6, "Offset mismatch for UFortAthenaAIBotEvaluator_DBNO::bAllowReachSquadmates");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DBNO, bAllowReachSameFactionNPCs) == 0x1a6, "Offset mismatch for UFortAthenaAIBotEvaluator_DBNO::bAllowReachSameFactionNPCs");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DBNO, AllyPawns) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_DBNO::AllyPawns");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DBNO, CachedCurrentDestination) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_DBNO::CachedCurrentDestination");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DBNO, DBNOSkillSet) == 0x1d0, "Offset mismatch for UFortAthenaAIBotEvaluator_DBNO::DBNOSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DBNO, CachedCoverComponent) == 0x1d8, "Offset mismatch for UFortAthenaAIBotEvaluator_DBNO::CachedCoverComponent");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DBNO, DBNOBehaviorRuntimeParameters) == 0x1e0, "Offset mismatch for UFortAthenaAIBotEvaluator_DBNO::DBNOBehaviorRuntimeParameters");

// Size: 0xc0 (Inherited: 0x170, Single: 0xffffff50)
class UFortAthenaAIBotEvaluator_DefensiveBuilding : public UFortAthenaAIBotEvaluator
{
public:
    uint8_t Pad_a8[0x8]; // 0xa8 (Size: 0x8, Type: PaddingProperty)
    UFortAthenaAIBotBuildingDigestedSkillSet* CachedBuildingDigestedSkillSet; // 0xb0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotBuildingComponent* CachedBuildingComponent; // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_DefensiveBuilding) == 0xc0, "Size mismatch for UFortAthenaAIBotEvaluator_DefensiveBuilding");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DefensiveBuilding, CachedBuildingDigestedSkillSet) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_DefensiveBuilding::CachedBuildingDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_DefensiveBuilding, CachedBuildingComponent) == 0xb8, "Offset mismatch for UFortAthenaAIBotEvaluator_DefensiveBuilding::CachedBuildingComponent");

// Size: 0x200 (Inherited: 0x170, Single: 0x90)
class UFortAthenaAIBotEvaluator_Escalate : public UFortAthenaAIBotEvaluator
{
public:
    uint8_t Pad_a8[0xf0]; // 0xa8 (Size: 0xf0, Type: PaddingProperty)
    UFortAthenaAIRuntimeParameters_EscalateBehavior* EscalateRuntimeParameters; // 0x198 (Size: 0x8, Type: ObjectProperty)
    TArray<FEscalateTargetData> EscalateTargetDatas; // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_1b0[0x50]; // 0x1b0 (Size: 0x50, Type: PaddingProperty)

private:
    void OnPlayerPawnSpawned(AAIController*& Controller, AFortPawn*& Pawn); // 0xef527d8 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Escalate) == 0x200, "Size mismatch for UFortAthenaAIBotEvaluator_Escalate");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Escalate, EscalateRuntimeParameters) == 0x198, "Offset mismatch for UFortAthenaAIBotEvaluator_Escalate::EscalateRuntimeParameters");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Escalate, EscalateTargetDatas) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Escalate::EscalateTargetDatas");

// Size: 0x1d0 (Inherited: 0x3f0, Single: 0xfffffde0)
class UFortAthenaAIBotEvaluator_Escape : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FGameplayTagContainer EscapeTags; // 0x1a0 (Size: 0x20, Type: StructProperty)
    float CooldownBetweenAggressivenessChanges; // 0x1c0 (Size: 0x4, Type: FloatProperty)
    FName AggressivenessName; // 0x1c4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c8[0x8]; // 0x1c8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Escape) == 0x1d0, "Size mismatch for UFortAthenaAIBotEvaluator_Escape");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Escape, EscapeTags) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Escape::EscapeTags");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Escape, CooldownBetweenAggressivenessChanges) == 0x1c0, "Offset mismatch for UFortAthenaAIBotEvaluator_Escape::CooldownBetweenAggressivenessChanges");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Escape, AggressivenessName) == 0x1c4, "Offset mismatch for UFortAthenaAIBotEvaluator_Escape::AggressivenessName");

// Size: 0x290 (Inherited: 0x170, Single: 0x120)
class UFortAthenaAIBotEvaluator_EvasiveManeuvers : public UFortAthenaAIBotEvaluator
{
public:
    uint8_t Pad_a8[0xa8]; // 0xa8 (Size: 0xa8, Type: PaddingProperty)
    FName CrouchExecutionStatusName; // 0x150 (Size: 0x4, Type: NameProperty)
    FName JumpExecutionStatusName; // 0x154 (Size: 0x4, Type: NameProperty)
    FName JetpackStrafeExecutionStatusName; // 0x158 (Size: 0x4, Type: NameProperty)
    FName DodgeName; // 0x15c (Size: 0x4, Type: NameProperty)
    FName DestinationKeyName; // 0x160 (Size: 0x4, Type: NameProperty)
    FName UrgentMoveKeyName; // 0x164 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_168[0xc]; // 0x168 (Size: 0xc, Type: PaddingProperty)
    bool bDoCrouching; // 0x174 (Size: 0x1, Type: BoolProperty)
    bool bDoDodging; // 0x175 (Size: 0x1, Type: BoolProperty)
    bool bDoJumping; // 0x176 (Size: 0x1, Type: BoolProperty)
    bool bDoJumpingDistanceCheck; // 0x177 (Size: 0x1, Type: BoolProperty)
    bool bDoJetpackStrafing; // 0x178 (Size: 0x1, Type: BoolProperty)
    bool bDoJetpackStrafingDistanceCheck; // 0x179 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_17a[0x2]; // 0x17a (Size: 0x2, Type: PaddingProperty)
    float JetpackStrafingRequiredFuelPercent; // 0x17c (Size: 0x4, Type: FloatProperty)
    float JetpackStrafeNavPadding; // 0x180 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_184[0x4]; // 0x184 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagQuery RequiredTagQuery; // 0x188 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery JetpackRequiredTagQuery; // 0x1d0 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery JumpRequiredTagQuery; // 0x218 (Size: 0x48, Type: StructProperty)
    UClass* ForcedPerkClass; // 0x260 (Size: 0x8, Type: ClassProperty)
    UFortAthenaAIBotEvasiveManeuversDigestedSkillSet* CacheEMDigestedSkillSet; // 0x268 (Size: 0x8, Type: ObjectProperty)
    UFortAIControllerPerksComponent* CachedPerksComponent; // 0x270 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_278[0x18]; // 0x278 (Size: 0x18, Type: PaddingProperty)

public:
    void OnMoveCompleted(FAIRequestID& RequestID, TEnumAsByte<EPathFollowingResult>& MovementResult); // 0xef52498 (Index: 0x1, Flags: Final|Native|Public)

private:
    void OnAssignedPerksChangedEvent(); // 0xef520b8 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_EvasiveManeuvers) == 0x290, "Size mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, CrouchExecutionStatusName) == 0x150, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::CrouchExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, JumpExecutionStatusName) == 0x154, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::JumpExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, JetpackStrafeExecutionStatusName) == 0x158, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::JetpackStrafeExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, DodgeName) == 0x15c, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::DodgeName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, DestinationKeyName) == 0x160, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::DestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, UrgentMoveKeyName) == 0x164, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::UrgentMoveKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, bDoCrouching) == 0x174, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::bDoCrouching");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, bDoDodging) == 0x175, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::bDoDodging");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, bDoJumping) == 0x176, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::bDoJumping");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, bDoJumpingDistanceCheck) == 0x177, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::bDoJumpingDistanceCheck");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, bDoJetpackStrafing) == 0x178, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::bDoJetpackStrafing");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, bDoJetpackStrafingDistanceCheck) == 0x179, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::bDoJetpackStrafingDistanceCheck");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, JetpackStrafingRequiredFuelPercent) == 0x17c, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::JetpackStrafingRequiredFuelPercent");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, JetpackStrafeNavPadding) == 0x180, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::JetpackStrafeNavPadding");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, RequiredTagQuery) == 0x188, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::RequiredTagQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, JetpackRequiredTagQuery) == 0x1d0, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::JetpackRequiredTagQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, JumpRequiredTagQuery) == 0x218, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::JumpRequiredTagQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, ForcedPerkClass) == 0x260, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::ForcedPerkClass");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, CacheEMDigestedSkillSet) == 0x268, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::CacheEMDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_EvasiveManeuvers, CachedPerksComponent) == 0x270, "Offset mismatch for UFortAthenaAIBotEvaluator_EvasiveManeuvers::CachedPerksComponent");

// Size: 0x218 (Inherited: 0x3f0, Single: 0xfffffe28)
class UFortAthenaAIBotEvaluator_Flanking : public UFortAthenaAIBotEvaluator_Movement
{
public:
    AFortAIDirector* CachedAIDirector; // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotRangeAttackDigestedSkillSet* CachedRangeAttackDigestedSkillSet; // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    FName FlankingExecutionStatusKeyName; // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName FlankingMovementStateKeyName; // 0x1b4 (Size: 0x4, Type: NameProperty)
    FName FlankingDestinationKeyName; // 0x1b8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1bc[0xc]; // 0x1bc (Size: 0xc, Type: PaddingProperty)
    TArray<FFlankingLocationInfo> LocationsToEvaluate; // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    TArray<FFlankingLocationInfo> BestLocations; // 0x1d8 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AActor*>> ActorsInArea; // 0x1e8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_1f8[0x20]; // 0x1f8 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Flanking) == 0x218, "Size mismatch for UFortAthenaAIBotEvaluator_Flanking");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flanking, CachedAIDirector) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Flanking::CachedAIDirector");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flanking, CachedRangeAttackDigestedSkillSet) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_Flanking::CachedRangeAttackDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flanking, FlankingExecutionStatusKeyName) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_Flanking::FlankingExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flanking, FlankingMovementStateKeyName) == 0x1b4, "Offset mismatch for UFortAthenaAIBotEvaluator_Flanking::FlankingMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flanking, FlankingDestinationKeyName) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_Flanking::FlankingDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flanking, LocationsToEvaluate) == 0x1c8, "Offset mismatch for UFortAthenaAIBotEvaluator_Flanking::LocationsToEvaluate");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flanking, BestLocations) == 0x1d8, "Offset mismatch for UFortAthenaAIBotEvaluator_Flanking::BestLocations");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flanking, ActorsInArea) == 0x1e8, "Offset mismatch for UFortAthenaAIBotEvaluator_Flanking::ActorsInArea");

// Size: 0x1d8 (Inherited: 0x3f0, Single: 0xfffffde8)
class UFortAthenaAIBotEvaluator_Flee : public UFortAthenaAIBotEvaluator_Movement
{
public:
    float MinDistanceFromTarget; // 0x1a0 (Size: 0x4, Type: FloatProperty)
    float MinValidDistanceForFleeLocation; // 0x1a4 (Size: 0x4, Type: FloatProperty)
    float FleeDistance; // 0x1a8 (Size: 0x4, Type: FloatProperty)
    float MaxDistanceFromTargetWhenFleeing; // 0x1ac (Size: 0x4, Type: FloatProperty)
    float MinDistanceHysteresisWhenChangingTarget; // 0x1b0 (Size: 0x4, Type: FloatProperty)
    FName FleeKeyName; // 0x1b4 (Size: 0x4, Type: NameProperty)
    FName FleeMovementStateKeyName; // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName FleeDestinationKeyName; // 0x1bc (Size: 0x4, Type: NameProperty)
    FName FleeActorKeyName; // 0x1c0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c4[0xc]; // 0x1c4 (Size: 0xc, Type: PaddingProperty)
    AActor* CurrentActorFleeingFrom; // 0x1d0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Flee) == 0x1d8, "Size mismatch for UFortAthenaAIBotEvaluator_Flee");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flee, MinDistanceFromTarget) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Flee::MinDistanceFromTarget");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flee, MinValidDistanceForFleeLocation) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_Flee::MinValidDistanceForFleeLocation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flee, FleeDistance) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_Flee::FleeDistance");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flee, MaxDistanceFromTargetWhenFleeing) == 0x1ac, "Offset mismatch for UFortAthenaAIBotEvaluator_Flee::MaxDistanceFromTargetWhenFleeing");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flee, MinDistanceHysteresisWhenChangingTarget) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_Flee::MinDistanceHysteresisWhenChangingTarget");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flee, FleeKeyName) == 0x1b4, "Offset mismatch for UFortAthenaAIBotEvaluator_Flee::FleeKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flee, FleeMovementStateKeyName) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_Flee::FleeMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flee, FleeDestinationKeyName) == 0x1bc, "Offset mismatch for UFortAthenaAIBotEvaluator_Flee::FleeDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flee, FleeActorKeyName) == 0x1c0, "Offset mismatch for UFortAthenaAIBotEvaluator_Flee::FleeActorKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Flee, CurrentActorFleeingFrom) == 0x1d0, "Offset mismatch for UFortAthenaAIBotEvaluator_Flee::CurrentActorFleeingFrom");

// Size: 0x1b8 (Inherited: 0x170, Single: 0x48)
class UFortAthenaAIBotEvaluator_FreeFalling : public UFortAthenaAIBotEvaluator
{
public:
    FName DiveExecutionStatusKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    FName DiveDestinationKeyName; // 0xac (Size: 0x4, Type: NameProperty)
    FName GlideExecutionStatusKeyName; // 0xb0 (Size: 0x4, Type: NameProperty)
    FName GlideDestinationKeyName; // 0xb4 (Size: 0x4, Type: NameProperty)
    FName JumpOffBusDestinationName; // 0xb8 (Size: 0x4, Type: NameProperty)
    FName AlertLevelName; // 0xbc (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c0[0xc]; // 0xc0 (Size: 0xc, Type: PaddingProperty)
    bool bRandomlySelectFreeFallingMode; // 0xcc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_cd[0x3]; // 0xcd (Size: 0x3, Type: PaddingProperty)
    FScalableFloat IdleWeight; // 0xd0 (Size: 0x28, Type: StructProperty)
    FScalableFloat RandomWeight; // 0xf8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TowardNearestAllyWeight; // 0x120 (Size: 0x28, Type: StructProperty)
    uint8_t FreeFallingMode; // 0x148 (Size: 0x1, Type: EnumProperty)
    bool bIsAlerted; // 0x149 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_14a[0x2]; // 0x14a (Size: 0x2, Type: PaddingProperty)
    float MaxOffsetRangeFromNearestAlly; // 0x14c (Size: 0x4, Type: FloatProperty)
    uint8_t bShouldRecomputeDestinationWhenTowardNearestAlly : 1; // 0x150:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bShouldSearchAllyInSquad : 1; // 0x150:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bShouldSearchAllyInTeam : 1; // 0x150:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bGlideAllowed : 1; // 0x150:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_151[0x3]; // 0x151 (Size: 0x3, Type: PaddingProperty)
    float SkyTubeDivingStuckTimeThreshold; // 0x154 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_158[0x20]; // 0x158 (Size: 0x20, Type: PaddingProperty)
    AFortPlayerStateAthena* NearestAlly; // 0x178 (Size: 0x8, Type: ObjectProperty)
    FVector CachedLatestDestination; // 0x180 (Size: 0x18, Type: StructProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementDigestedSkillSet; // 0x198 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1a0[0x8]; // 0x1a0 (Size: 0x8, Type: PaddingProperty)
    AFortSkyTube* CachedSkyTube; // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1b0[0x8]; // 0x1b0 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_FreeFalling) == 0x1b8, "Size mismatch for UFortAthenaAIBotEvaluator_FreeFalling");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, DiveExecutionStatusKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::DiveExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, DiveDestinationKeyName) == 0xac, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::DiveDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, GlideExecutionStatusKeyName) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::GlideExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, GlideDestinationKeyName) == 0xb4, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::GlideDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, JumpOffBusDestinationName) == 0xb8, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::JumpOffBusDestinationName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, AlertLevelName) == 0xbc, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::AlertLevelName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, bRandomlySelectFreeFallingMode) == 0xcc, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::bRandomlySelectFreeFallingMode");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, IdleWeight) == 0xd0, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::IdleWeight");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, RandomWeight) == 0xf8, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::RandomWeight");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, TowardNearestAllyWeight) == 0x120, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::TowardNearestAllyWeight");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, FreeFallingMode) == 0x148, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::FreeFallingMode");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, bIsAlerted) == 0x149, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::bIsAlerted");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, MaxOffsetRangeFromNearestAlly) == 0x14c, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::MaxOffsetRangeFromNearestAlly");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, bShouldRecomputeDestinationWhenTowardNearestAlly) == 0x150, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::bShouldRecomputeDestinationWhenTowardNearestAlly");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, bShouldSearchAllyInSquad) == 0x150, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::bShouldSearchAllyInSquad");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, bShouldSearchAllyInTeam) == 0x150, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::bShouldSearchAllyInTeam");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, bGlideAllowed) == 0x150, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::bGlideAllowed");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, SkyTubeDivingStuckTimeThreshold) == 0x154, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::SkyTubeDivingStuckTimeThreshold");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, NearestAlly) == 0x178, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::NearestAlly");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, CachedLatestDestination) == 0x180, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::CachedLatestDestination");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, CacheMovementDigestedSkillSet) == 0x198, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::CacheMovementDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_FreeFalling, CachedSkyTube) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_FreeFalling::CachedSkyTube");

// Size: 0x138 (Inherited: 0x170, Single: 0xffffffc8)
class UFortAthenaAIBotEvaluator_Ground : public UFortAthenaAIBotEvaluator
{
public:
    FVector SurfaceTypeRaycastDir; // 0xa8 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_c0[0x70]; // 0xc0 (Size: 0x70, Type: PaddingProperty)
    UFortAthenaAIRuntimeParameters_Behavior* CachedBehaviorRuntimeParameters; // 0x130 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Ground) == 0x138, "Size mismatch for UFortAthenaAIBotEvaluator_Ground");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Ground, SurfaceTypeRaycastDir) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_Ground::SurfaceTypeRaycastDir");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Ground, CachedBehaviorRuntimeParameters) == 0x130, "Offset mismatch for UFortAthenaAIBotEvaluator_Ground::CachedBehaviorRuntimeParameters");

// Size: 0x1f8 (Inherited: 0x170, Single: 0x88)
class UFortAthenaAIBotEvaluator_HandleFocusing : public UFortAthenaAIBotEvaluator
{
public:
    FName TargetActorName; // 0xa8 (Size: 0x4, Type: NameProperty)
    FName InteractActorName; // 0xac (Size: 0x4, Type: NameProperty)
    FName TargetLocationName; // 0xb0 (Size: 0x4, Type: NameProperty)
    FName FocusActorName; // 0xb4 (Size: 0x4, Type: NameProperty)
    FName FocalPointName; // 0xb8 (Size: 0x4, Type: NameProperty)
    FName WeaponFireName; // 0xbc (Size: 0x4, Type: NameProperty)
    FName RangeAttackIsReadyToFireName; // 0xc0 (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerMeleeName; // 0xc4 (Size: 0x4, Type: NameProperty)
    FName LastKnownPositionName; // 0xc8 (Size: 0x4, Type: NameProperty)
    FName TacticalSprintExecutionStatusName; // 0xcc (Size: 0x4, Type: NameProperty)
    uint8_t Pad_d0[0x18]; // 0xd0 (Size: 0x18, Type: PaddingProperty)
    FValueOrBBKey_Enum FocusingBehavior; // 0xe8 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Enum NoRangedWeaponFocusBehavior; // 0x110 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Bool bPrioritizeThreatOverCurrentTarget; // 0x138 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bUseTargetActorKeyAsFocusTarget; // 0x144 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bFocusOnTargetLocation; // 0x150 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float AmbushMaxLKPLookAtAngleDegree; // 0x15c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bStopFocusingWhenMoving; // 0x168 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float ResumeFocusingWhenMovingDist; // 0x174 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float StopFocusingWhenMovingDist; // 0x180 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bResumeFocusWhileSliding; // 0x18c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ClearFocusOnTacticalSprint; // 0x198 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1a4[0x4]; // 0x1a4 (Size: 0x4, Type: PaddingProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementDigestedSkillSet; // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    AActor* LastTargetedThreat; // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1c0[0x8]; // 0x1c0 (Size: 0x8, Type: PaddingProperty)
    AActor* FocusActor; // 0x1c8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1d0[0x28]; // 0x1d0 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_HandleFocusing) == 0x1f8, "Size mismatch for UFortAthenaAIBotEvaluator_HandleFocusing");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, TargetActorName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::TargetActorName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, InteractActorName) == 0xac, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::InteractActorName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, TargetLocationName) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::TargetLocationName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, FocusActorName) == 0xb4, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::FocusActorName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, FocalPointName) == 0xb8, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::FocalPointName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, WeaponFireName) == 0xbc, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::WeaponFireName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, RangeAttackIsReadyToFireName) == 0xc0, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::RangeAttackIsReadyToFireName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, WeaponTriggerMeleeName) == 0xc4, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::WeaponTriggerMeleeName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, LastKnownPositionName) == 0xc8, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::LastKnownPositionName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, TacticalSprintExecutionStatusName) == 0xcc, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::TacticalSprintExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, FocusingBehavior) == 0xe8, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::FocusingBehavior");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, NoRangedWeaponFocusBehavior) == 0x110, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::NoRangedWeaponFocusBehavior");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, bPrioritizeThreatOverCurrentTarget) == 0x138, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::bPrioritizeThreatOverCurrentTarget");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, bUseTargetActorKeyAsFocusTarget) == 0x144, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::bUseTargetActorKeyAsFocusTarget");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, bFocusOnTargetLocation) == 0x150, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::bFocusOnTargetLocation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, AmbushMaxLKPLookAtAngleDegree) == 0x15c, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::AmbushMaxLKPLookAtAngleDegree");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, bStopFocusingWhenMoving) == 0x168, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::bStopFocusingWhenMoving");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, ResumeFocusingWhenMovingDist) == 0x174, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::ResumeFocusingWhenMovingDist");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, StopFocusingWhenMovingDist) == 0x180, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::StopFocusingWhenMovingDist");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, bResumeFocusWhileSliding) == 0x18c, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::bResumeFocusWhileSliding");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, ClearFocusOnTacticalSprint) == 0x198, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::ClearFocusOnTacticalSprint");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, CacheAimingDigestedSkillSet) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::CacheAimingDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, CacheMovementDigestedSkillSet) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::CacheMovementDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, LastTargetedThreat) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::LastTargetedThreat");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HandleFocusing, FocusActor) == 0x1c8, "Offset mismatch for UFortAthenaAIBotEvaluator_HandleFocusing::FocusActor");

// Size: 0x128 (Inherited: 0x170, Single: 0xffffffb8)
class UFortAthenaAIBotEvaluator_Heal : public UFortAthenaAIBotEvaluator
{
public:
    FName HealingObjectKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
    FName CanHealWhileMovingKeyName; // 0xb0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b4[0x4]; // 0xb4 (Size: 0x4, Type: PaddingProperty)
    FName UnstuckExecutionStatusKeyName; // 0xb8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_bc[0xc]; // 0xbc (Size: 0xc, Type: PaddingProperty)
    FGameplayTagQuery RequiredTagQuery; // 0xc8 (Size: 0x48, Type: StructProperty)
    bool bAllowEvaluationRetry; // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_111[0x7]; // 0x111 (Size: 0x7, Type: PaddingProperty)
    UFortAthenaAIBotHealingDigestedSkillSet* HealingSkillSet; // 0x118 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_120[0x8]; // 0x120 (Size: 0x8, Type: PaddingProperty)

private:
    void HandlePlayerHealthOrShieldChanged(); // 0xef51e98 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Heal) == 0x128, "Size mismatch for UFortAthenaAIBotEvaluator_Heal");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Heal, HealingObjectKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_Heal::HealingObjectKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Heal, CanHealWhileMovingKeyName) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_Heal::CanHealWhileMovingKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Heal, UnstuckExecutionStatusKeyName) == 0xb8, "Offset mismatch for UFortAthenaAIBotEvaluator_Heal::UnstuckExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Heal, RequiredTagQuery) == 0xc8, "Offset mismatch for UFortAthenaAIBotEvaluator_Heal::RequiredTagQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Heal, bAllowEvaluationRetry) == 0x110, "Offset mismatch for UFortAthenaAIBotEvaluator_Heal::bAllowEvaluationRetry");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Heal, HealingSkillSet) == 0x118, "Offset mismatch for UFortAthenaAIBotEvaluator_Heal::HealingSkillSet");

// Size: 0x298 (Inherited: 0x3f0, Single: 0xfffffea8)
class UFortAthenaAIBotEvaluator_HitAndRun : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FScalableFloat AttackDurationBeforeEvade; // 0x1a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MeleeAttackMaxDistToEvade; // 0x1c8 (Size: 0x28, Type: StructProperty)
    FScalableFloat ClampEvadeDistanceEnable; // 0x1f0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinDistanceToEvade; // 0x218 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxDistanceToEvade; // 0x240 (Size: 0x28, Type: StructProperty)
    FName EvadeKeyName; // 0x268 (Size: 0x4, Type: NameProperty)
    FName EvadeMovementStateKeyName; // 0x26c (Size: 0x4, Type: NameProperty)
    FName EvadeDestinationKeyName; // 0x270 (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerMeleeName; // 0x274 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_278[0x10]; // 0x278 (Size: 0x10, Type: PaddingProperty)
    float MeleeAttackMaxDistToEvadeSqr; // 0x288 (Size: 0x4, Type: FloatProperty)
    float MaxDistanceToEvadeSqr; // 0x28c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_290[0x8]; // 0x290 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_HitAndRun) == 0x298, "Size mismatch for UFortAthenaAIBotEvaluator_HitAndRun");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HitAndRun, AttackDurationBeforeEvade) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_HitAndRun::AttackDurationBeforeEvade");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HitAndRun, MeleeAttackMaxDistToEvade) == 0x1c8, "Offset mismatch for UFortAthenaAIBotEvaluator_HitAndRun::MeleeAttackMaxDistToEvade");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HitAndRun, ClampEvadeDistanceEnable) == 0x1f0, "Offset mismatch for UFortAthenaAIBotEvaluator_HitAndRun::ClampEvadeDistanceEnable");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HitAndRun, MinDistanceToEvade) == 0x218, "Offset mismatch for UFortAthenaAIBotEvaluator_HitAndRun::MinDistanceToEvade");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HitAndRun, MaxDistanceToEvade) == 0x240, "Offset mismatch for UFortAthenaAIBotEvaluator_HitAndRun::MaxDistanceToEvade");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HitAndRun, EvadeKeyName) == 0x268, "Offset mismatch for UFortAthenaAIBotEvaluator_HitAndRun::EvadeKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HitAndRun, EvadeMovementStateKeyName) == 0x26c, "Offset mismatch for UFortAthenaAIBotEvaluator_HitAndRun::EvadeMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HitAndRun, EvadeDestinationKeyName) == 0x270, "Offset mismatch for UFortAthenaAIBotEvaluator_HitAndRun::EvadeDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HitAndRun, WeaponTriggerMeleeName) == 0x274, "Offset mismatch for UFortAthenaAIBotEvaluator_HitAndRun::WeaponTriggerMeleeName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HitAndRun, MeleeAttackMaxDistToEvadeSqr) == 0x288, "Offset mismatch for UFortAthenaAIBotEvaluator_HitAndRun::MeleeAttackMaxDistToEvadeSqr");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HitAndRun, MaxDistanceToEvadeSqr) == 0x28c, "Offset mismatch for UFortAthenaAIBotEvaluator_HitAndRun::MaxDistanceToEvadeSqr");

// Size: 0xe8 (Inherited: 0x170, Single: 0xffffff78)
class UFortAthenaAIBotEvaluator_HolsterWeapon : public UFortAthenaAIBotEvaluator
{
public:
    TArray<FName> ExecutionStatusesToCheckedNames; // 0xa8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_b8[0x10]; // 0xb8 (Size: 0x10, Type: PaddingProperty)
    FValueOrBBKey_Bool HolsterEvenWithTarget; // 0xc8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
    UFortAthenaAIRuntimeParameters_NPCBehavior* CachedNPCBehaviorParameters; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIRuntimeParameters_AIBotConvert* CachedConvertParameters; // 0xe0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_HolsterWeapon) == 0xe8, "Size mismatch for UFortAthenaAIBotEvaluator_HolsterWeapon");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HolsterWeapon, ExecutionStatusesToCheckedNames) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_HolsterWeapon::ExecutionStatusesToCheckedNames");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HolsterWeapon, HolsterEvenWithTarget) == 0xc8, "Offset mismatch for UFortAthenaAIBotEvaluator_HolsterWeapon::HolsterEvenWithTarget");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HolsterWeapon, CachedNPCBehaviorParameters) == 0xd8, "Offset mismatch for UFortAthenaAIBotEvaluator_HolsterWeapon::CachedNPCBehaviorParameters");
static_assert(offsetof(UFortAthenaAIBotEvaluator_HolsterWeapon, CachedConvertParameters) == 0xe0, "Offset mismatch for UFortAthenaAIBotEvaluator_HolsterWeapon::CachedConvertParameters");

// Size: 0x260 (Inherited: 0x3f0, Single: 0xfffffe70)
class UFortAthenaAIBotEvaluator_Investigate : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName LastKnownPositionName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName DestinationKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName MoveToDestinationKeyName; // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName AggressivenessName; // 0x1ac (Size: 0x4, Type: NameProperty)
    FName CautiousKeyName; // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName AlertLevelName; // 0x1b4 (Size: 0x4, Type: NameProperty)
    UClass* SearchQueryFilterClass; // 0x1b8 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_1c0[0x10]; // 0x1c0 (Size: 0x10, Type: PaddingProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingDigestedSkillSet; // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotUnstuckDigestedSkillSet* CachedUnstuckSkillSet; // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1e8[0x48]; // 0x1e8 (Size: 0x48, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> InvestigatingSupportingActor; // 0x230 (Size: 0x8, Type: WeakObjectProperty)
    ABuildingSMActor* UnderminingBuildingActor; // 0x238 (Size: 0x8, Type: ObjectProperty)
    AActor* ExcludeReachingTarget; // 0x240 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_248[0x18]; // 0x248 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Investigate) == 0x260, "Size mismatch for UFortAthenaAIBotEvaluator_Investigate");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, LastKnownPositionName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::LastKnownPositionName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, DestinationKeyName) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::DestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, MoveToDestinationKeyName) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::MoveToDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, AggressivenessName) == 0x1ac, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::AggressivenessName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, CautiousKeyName) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::CautiousKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, AlertLevelName) == 0x1b4, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::AlertLevelName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, SearchQueryFilterClass) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::SearchQueryFilterClass");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, CacheAimingDigestedSkillSet) == 0x1d0, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::CacheAimingDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, CacheAttackingDigestedSkillSet) == 0x1d8, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::CacheAttackingDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, CachedUnstuckSkillSet) == 0x1e0, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::CachedUnstuckSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, InvestigatingSupportingActor) == 0x230, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::InvestigatingSupportingActor");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, UnderminingBuildingActor) == 0x238, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::UnderminingBuildingActor");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Investigate, ExcludeReachingTarget) == 0x240, "Offset mismatch for UFortAthenaAIBotEvaluator_Investigate::ExcludeReachingTarget");

// Size: 0xe8 (Inherited: 0x170, Single: 0xffffff78)
class UFortAthenaAIBotEvaluator_JumpOffBus : public UFortAthenaAIBotEvaluator
{
public:
    FName JumpOffBusDestinationName; // 0xa8 (Size: 0x4, Type: NameProperty)
    FName JumpOffBusDestinationVolumeKeyName; // 0xac (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b0[0x20]; // 0xb0 (Size: 0x20, Type: PaddingProperty)
    AFortPoiVolume* BusDroppingVolume; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementDigestedSkillSet; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_e0[0x8]; // 0xe0 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_JumpOffBus) == 0xe8, "Size mismatch for UFortAthenaAIBotEvaluator_JumpOffBus");
static_assert(offsetof(UFortAthenaAIBotEvaluator_JumpOffBus, JumpOffBusDestinationName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_JumpOffBus::JumpOffBusDestinationName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_JumpOffBus, JumpOffBusDestinationVolumeKeyName) == 0xac, "Offset mismatch for UFortAthenaAIBotEvaluator_JumpOffBus::JumpOffBusDestinationVolumeKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_JumpOffBus, BusDroppingVolume) == 0xd0, "Offset mismatch for UFortAthenaAIBotEvaluator_JumpOffBus::BusDroppingVolume");
static_assert(offsetof(UFortAthenaAIBotEvaluator_JumpOffBus, CacheMovementDigestedSkillSet) == 0xd8, "Offset mismatch for UFortAthenaAIBotEvaluator_JumpOffBus::CacheMovementDigestedSkillSet");

// Size: 0x228 (Inherited: 0x5a8, Single: 0xfffffc80)
class UFortAthenaAIBotEvaluator_MeleeAttack : public UFortAthenaAIBotEvaluator_Attack
{
public:
    uint8_t Pad_1b8[0x4]; // 0x1b8 (Size: 0x4, Type: PaddingProperty)
    FName WeaponTriggerMeleeName; // 0x1bc (Size: 0x4, Type: NameProperty)
    FName ThrowableAttacksAllowedName; // 0x1c0 (Size: 0x4, Type: NameProperty)
    FName TraversalBlockMeleeAttackName; // 0x1c4 (Size: 0x4, Type: NameProperty)
    FName TargetContextReachableKeyName; // 0x1c8 (Size: 0x4, Type: NameProperty)
    FName TargetContextInsideLeashKeyName; // 0x1cc (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1d0[0x18]; // 0x1d0 (Size: 0x18, Type: PaddingProperty)
    UFortAthenaAIBotAttackingDigestedSkillSet* AttackingSkillSet; // 0x1e8 (Size: 0x8, Type: ObjectProperty)
    FValueOrBBKey_Bool ShouldValidateWeaponType; // 0x1f0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool CheckMeleeHeightAligned; // 0x1fc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool AddExtentsToMeleeAttackDistance; // 0x208 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool Use3DDistanceCheckForMeleeAttack; // 0x214 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_220[0x8]; // 0x220 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_MeleeAttack) == 0x228, "Size mismatch for UFortAthenaAIBotEvaluator_MeleeAttack");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MeleeAttack, WeaponTriggerMeleeName) == 0x1bc, "Offset mismatch for UFortAthenaAIBotEvaluator_MeleeAttack::WeaponTriggerMeleeName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MeleeAttack, ThrowableAttacksAllowedName) == 0x1c0, "Offset mismatch for UFortAthenaAIBotEvaluator_MeleeAttack::ThrowableAttacksAllowedName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MeleeAttack, TraversalBlockMeleeAttackName) == 0x1c4, "Offset mismatch for UFortAthenaAIBotEvaluator_MeleeAttack::TraversalBlockMeleeAttackName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MeleeAttack, TargetContextReachableKeyName) == 0x1c8, "Offset mismatch for UFortAthenaAIBotEvaluator_MeleeAttack::TargetContextReachableKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MeleeAttack, TargetContextInsideLeashKeyName) == 0x1cc, "Offset mismatch for UFortAthenaAIBotEvaluator_MeleeAttack::TargetContextInsideLeashKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MeleeAttack, AttackingSkillSet) == 0x1e8, "Offset mismatch for UFortAthenaAIBotEvaluator_MeleeAttack::AttackingSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MeleeAttack, ShouldValidateWeaponType) == 0x1f0, "Offset mismatch for UFortAthenaAIBotEvaluator_MeleeAttack::ShouldValidateWeaponType");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MeleeAttack, CheckMeleeHeightAligned) == 0x1fc, "Offset mismatch for UFortAthenaAIBotEvaluator_MeleeAttack::CheckMeleeHeightAligned");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MeleeAttack, AddExtentsToMeleeAttackDistance) == 0x208, "Offset mismatch for UFortAthenaAIBotEvaluator_MeleeAttack::AddExtentsToMeleeAttackDistance");
static_assert(offsetof(UFortAthenaAIBotEvaluator_MeleeAttack, Use3DDistanceCheckForMeleeAttack) == 0x214, "Offset mismatch for UFortAthenaAIBotEvaluator_MeleeAttack::Use3DDistanceCheckForMeleeAttack");

// Size: 0xc8 (Inherited: 0x170, Single: 0xffffff58)
class UFortAthenaAIBotEvaluator_Observe : public UFortAthenaAIBotEvaluator
{
public:
    FName AggressivenessName; // 0xa8 (Size: 0x4, Type: NameProperty)
    FName ObserveDestinationKeyName; // 0xac (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b0[0x4]; // 0xb0 (Size: 0x4, Type: PaddingProperty)
    bool bContinueMovementOnStart; // 0xb4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b5[0x3]; // 0xb5 (Size: 0x3, Type: PaddingProperty)
    float MaxMovementDuration; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0xc]; // 0xbc (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Observe) == 0xc8, "Size mismatch for UFortAthenaAIBotEvaluator_Observe");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Observe, AggressivenessName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_Observe::AggressivenessName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Observe, ObserveDestinationKeyName) == 0xac, "Offset mismatch for UFortAthenaAIBotEvaluator_Observe::ObserveDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Observe, bContinueMovementOnStart) == 0xb4, "Offset mismatch for UFortAthenaAIBotEvaluator_Observe::bContinueMovementOnStart");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Observe, MaxMovementDuration) == 0xb8, "Offset mismatch for UFortAthenaAIBotEvaluator_Observe::MaxMovementDuration");

// Size: 0xc8 (Inherited: 0x170, Single: 0xffffff58)
class UFortAthenaAIBotEvaluator_PathExists : public UFortAthenaAIBotEvaluator
{
public:
    FName PathExistsKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
    FName GoalKeyName; // 0xb0 (Size: 0x4, Type: NameProperty)
    float AcceptableRadius; // 0xb4 (Size: 0x4, Type: FloatProperty)
    UClass* FilterClass; // 0xb8 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<EPathTestQueryType> PathQueryType; // 0xc0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_c1[0x3]; // 0xc1 (Size: 0x3, Type: PaddingProperty)
    uint8_t bProjectGoalLocation : 1; // 0xc4:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bReachTestIncludesAgentRadius : 1; // 0xc4:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bReachTestIncludesGoalRadius : 1; // 0xc4:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c5[0x3]; // 0xc5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_PathExists) == 0xc8, "Size mismatch for UFortAthenaAIBotEvaluator_PathExists");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PathExists, PathExistsKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_PathExists::PathExistsKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PathExists, GoalKeyName) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_PathExists::GoalKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PathExists, AcceptableRadius) == 0xb4, "Offset mismatch for UFortAthenaAIBotEvaluator_PathExists::AcceptableRadius");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PathExists, FilterClass) == 0xb8, "Offset mismatch for UFortAthenaAIBotEvaluator_PathExists::FilterClass");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PathExists, PathQueryType) == 0xc0, "Offset mismatch for UFortAthenaAIBotEvaluator_PathExists::PathQueryType");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PathExists, bProjectGoalLocation) == 0xc4, "Offset mismatch for UFortAthenaAIBotEvaluator_PathExists::bProjectGoalLocation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PathExists, bReachTestIncludesAgentRadius) == 0xc4, "Offset mismatch for UFortAthenaAIBotEvaluator_PathExists::bReachTestIncludesAgentRadius");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PathExists, bReachTestIncludesGoalRadius) == 0xc4, "Offset mismatch for UFortAthenaAIBotEvaluator_PathExists::bReachTestIncludesGoalRadius");

// Size: 0x238 (Inherited: 0x3f0, Single: 0xfffffe48)
class UFortAthenaAIBotEvaluator_PatrolAround : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FEQSParametrizedQueryExecutionRequest EQSRequest; // 0x1a0 (Size: 0x48, Type: StructProperty)
    UClass* NavigationQueryFilterClass; // 0x1e8 (Size: 0x8, Type: ClassProperty)
    bool bFallbackToPointWithNoCustomNavigationQueryFilter; // 0x1f0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1f1[0x3]; // 0x1f1 (Size: 0x3, Type: PaddingProperty)
    FName PatrolDestinationName; // 0x1f4 (Size: 0x4, Type: NameProperty)
    FName PatrolExecutionStatusName; // 0x1f8 (Size: 0x4, Type: NameProperty)
    FName PatrolMovementStateName; // 0x1fc (Size: 0x4, Type: NameProperty)
    FName BestTargetActorName; // 0x200 (Size: 0x4, Type: NameProperty)
    FName EnableKeyName; // 0x204 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_208[0x8]; // 0x208 (Size: 0x8, Type: PaddingProperty)
    AFortGameModeAthena* CacheAthenaGameMode; // 0x210 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_218[0x20]; // 0x218 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_PatrolAround) == 0x238, "Size mismatch for UFortAthenaAIBotEvaluator_PatrolAround");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PatrolAround, EQSRequest) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_PatrolAround::EQSRequest");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PatrolAround, NavigationQueryFilterClass) == 0x1e8, "Offset mismatch for UFortAthenaAIBotEvaluator_PatrolAround::NavigationQueryFilterClass");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PatrolAround, bFallbackToPointWithNoCustomNavigationQueryFilter) == 0x1f0, "Offset mismatch for UFortAthenaAIBotEvaluator_PatrolAround::bFallbackToPointWithNoCustomNavigationQueryFilter");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PatrolAround, PatrolDestinationName) == 0x1f4, "Offset mismatch for UFortAthenaAIBotEvaluator_PatrolAround::PatrolDestinationName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PatrolAround, PatrolExecutionStatusName) == 0x1f8, "Offset mismatch for UFortAthenaAIBotEvaluator_PatrolAround::PatrolExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PatrolAround, PatrolMovementStateName) == 0x1fc, "Offset mismatch for UFortAthenaAIBotEvaluator_PatrolAround::PatrolMovementStateName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PatrolAround, BestTargetActorName) == 0x200, "Offset mismatch for UFortAthenaAIBotEvaluator_PatrolAround::BestTargetActorName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PatrolAround, EnableKeyName) == 0x204, "Offset mismatch for UFortAthenaAIBotEvaluator_PatrolAround::EnableKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PatrolAround, CacheAthenaGameMode) == 0x210, "Offset mismatch for UFortAthenaAIBotEvaluator_PatrolAround::CacheAthenaGameMode");

// Size: 0x1c0 (Inherited: 0x3f0, Single: 0xfffffdd0)
class UFortAthenaAIBotEvaluator_PlayEmote : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName PlayEmoteExecutionStatusKeyName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName PlayEmoteDestinationKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1a8[0x8]; // 0x1a8 (Size: 0x8, Type: PaddingProperty)
    AActor* ExcludeReachingTarget; // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1b8[0x8]; // 0x1b8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_PlayEmote) == 0x1c0, "Size mismatch for UFortAthenaAIBotEvaluator_PlayEmote");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PlayEmote, PlayEmoteExecutionStatusKeyName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_PlayEmote::PlayEmoteExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PlayEmote, PlayEmoteDestinationKeyName) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_PlayEmote::PlayEmoteDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PlayEmote, ExcludeReachingTarget) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_PlayEmote::ExcludeReachingTarget");

// Size: 0x130 (Inherited: 0x170, Single: 0xffffffc0)
class UFortAthenaAIBotEvaluator_PropagateAwareness : public UFortAthenaAIBotEvaluator
{
public:
    FGameplayTagQuery AwarenessTagQuery; // 0xa8 (Size: 0x48, Type: StructProperty)
    UClass* AwarenessGameplayEffectClass; // 0xf0 (Size: 0x8, Type: ClassProperty)
    TArray<AFortPlayerPawnAthena*> AwareAllyPawns; // 0xf8 (Size: 0x10, Type: ArrayProperty)
    TArray<AFortPlayerPawnAthena*> AlreadyTestedPawns; // 0x108 (Size: 0x10, Type: ArrayProperty)
    UFortAthenaAIBotPropagateAwarenessDigestedSkillSet* PropagateAwarenessSkillSet; // 0x118 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIRuntimeParameters_BehaviorTreeControl* BehaviorControlsRuntimeParameters; // 0x120 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIRuntimeParameters_AffiliationBase* AffiliationRuntimeParameters; // 0x128 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_PropagateAwareness) == 0x130, "Size mismatch for UFortAthenaAIBotEvaluator_PropagateAwareness");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PropagateAwareness, AwarenessTagQuery) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_PropagateAwareness::AwarenessTagQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PropagateAwareness, AwarenessGameplayEffectClass) == 0xf0, "Offset mismatch for UFortAthenaAIBotEvaluator_PropagateAwareness::AwarenessGameplayEffectClass");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PropagateAwareness, AwareAllyPawns) == 0xf8, "Offset mismatch for UFortAthenaAIBotEvaluator_PropagateAwareness::AwareAllyPawns");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PropagateAwareness, AlreadyTestedPawns) == 0x108, "Offset mismatch for UFortAthenaAIBotEvaluator_PropagateAwareness::AlreadyTestedPawns");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PropagateAwareness, PropagateAwarenessSkillSet) == 0x118, "Offset mismatch for UFortAthenaAIBotEvaluator_PropagateAwareness::PropagateAwarenessSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PropagateAwareness, BehaviorControlsRuntimeParameters) == 0x120, "Offset mismatch for UFortAthenaAIBotEvaluator_PropagateAwareness::BehaviorControlsRuntimeParameters");
static_assert(offsetof(UFortAthenaAIBotEvaluator_PropagateAwareness, AffiliationRuntimeParameters) == 0x128, "Offset mismatch for UFortAthenaAIBotEvaluator_PropagateAwareness::AffiliationRuntimeParameters");

// Size: 0x398 (Inherited: 0x5a8, Single: 0xfffffdf0)
class UFortAthenaAIBotEvaluator_RangeAttack : public UFortAthenaAIBotEvaluator_Attack
{
public:
    uint8_t Pad_1b8[0x40]; // 0x1b8 (Size: 0x40, Type: PaddingProperty)
    FName WeaponReloadName; // 0x1f8 (Size: 0x4, Type: NameProperty)
    FName WeaponFireName; // 0x1fc (Size: 0x4, Type: NameProperty)
    FName RangeAttackIsReadyToFireName; // 0x200 (Size: 0x4, Type: NameProperty)
    FName WeaponTargetingName; // 0x204 (Size: 0x4, Type: NameProperty)
    FName AggressivenessName; // 0x208 (Size: 0x4, Type: NameProperty)
    FName HasLoSOnThreatName; // 0x20c (Size: 0x4, Type: NameProperty)
    FName UrgentMovementKeyName; // 0x210 (Size: 0x4, Type: NameProperty)
    FName IsManningTurretKeyName; // 0x214 (Size: 0x4, Type: NameProperty)
    FName BlockWeaponActionsKeyName; // 0x218 (Size: 0x4, Type: NameProperty)
    FName CancelWeaponAutoReloadKeyName; // 0x21c (Size: 0x4, Type: NameProperty)
    uint8_t Pad_220[0x14]; // 0x220 (Size: 0x14, Type: PaddingProperty)
    bool bAlwaysAllowTargetingEvaluation; // 0x234 (Size: 0x1, Type: BoolProperty)
    bool bSkipADSEvaluation; // 0x235 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_236[0x2]; // 0x236 (Size: 0x2, Type: PaddingProperty)
    FValueOrBBKey_Bool SkipADSEvaluation; // 0x238 (Size: 0xc, Type: StructProperty)
    bool bConsiderLoF; // 0x244 (Size: 0x1, Type: BoolProperty)
    bool bShouldValidateRangedWeapon; // 0x245 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_246[0x2]; // 0x246 (Size: 0x2, Type: PaddingProperty)
    float RangeReachHysteresisRatio; // 0x248 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24c[0x4]; // 0x24c (Size: 0x4, Type: PaddingProperty)
    FValueOrBBKey_Bool ResetCanFireNextTimeOnEnter; // 0x250 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool CancelWeaponAutoReloadOnExit; // 0x25c (Size: 0xc, Type: StructProperty)
    uint8_t Pad_268[0x28]; // 0x268 (Size: 0x28, Type: PaddingProperty)
    UFortAthenaAIBotRangeAttackDigestedSkillSet* CacheRangeAttackDigestedSkillSet; // 0x290 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0x298 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotPerceptionDigestedSkillSet* CachePerceptionDigestedSkillSet; // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingDigestedSkillSet; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UAthenaAIServiceZoneManager*> CacheZoneManager; // 0x2b0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAthenaAIServiceCover*> CachedAIServiceCover; // 0x2b8 (Size: 0x8, Type: WeakObjectProperty)
    AActor* ExcludeReachingTarget; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2c8[0xd0]; // 0x2c8 (Size: 0xd0, Type: PaddingProperty)

protected:
    void FindShootingPosition_Async(int32_t& const RequestID, float& const DistanceFromTarget, float& const WeaponIdealAttackRange, const FVector TargetPosition); // 0xef73040 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms|HasDefaults)
    void OnCurrentTargetChanged(AActor*& OldTarget, AActor*& NewTarget); // 0xef7398c (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_RangeAttack) == 0x398, "Size mismatch for UFortAthenaAIBotEvaluator_RangeAttack");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, WeaponReloadName) == 0x1f8, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::WeaponReloadName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, WeaponFireName) == 0x1fc, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::WeaponFireName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, RangeAttackIsReadyToFireName) == 0x200, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::RangeAttackIsReadyToFireName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, WeaponTargetingName) == 0x204, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::WeaponTargetingName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, AggressivenessName) == 0x208, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::AggressivenessName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, HasLoSOnThreatName) == 0x20c, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::HasLoSOnThreatName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, UrgentMovementKeyName) == 0x210, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::UrgentMovementKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, IsManningTurretKeyName) == 0x214, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::IsManningTurretKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, BlockWeaponActionsKeyName) == 0x218, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::BlockWeaponActionsKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, CancelWeaponAutoReloadKeyName) == 0x21c, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::CancelWeaponAutoReloadKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, bAlwaysAllowTargetingEvaluation) == 0x234, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::bAlwaysAllowTargetingEvaluation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, bSkipADSEvaluation) == 0x235, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::bSkipADSEvaluation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, SkipADSEvaluation) == 0x238, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::SkipADSEvaluation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, bConsiderLoF) == 0x244, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::bConsiderLoF");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, bShouldValidateRangedWeapon) == 0x245, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::bShouldValidateRangedWeapon");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, RangeReachHysteresisRatio) == 0x248, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::RangeReachHysteresisRatio");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, ResetCanFireNextTimeOnEnter) == 0x250, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::ResetCanFireNextTimeOnEnter");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, CancelWeaponAutoReloadOnExit) == 0x25c, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::CancelWeaponAutoReloadOnExit");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, CacheRangeAttackDigestedSkillSet) == 0x290, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::CacheRangeAttackDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, CacheAimingDigestedSkillSet) == 0x298, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::CacheAimingDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, CachePerceptionDigestedSkillSet) == 0x2a0, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::CachePerceptionDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, CacheAttackingDigestedSkillSet) == 0x2a8, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::CacheAttackingDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, CacheZoneManager) == 0x2b0, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::CacheZoneManager");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, CachedAIServiceCover) == 0x2b8, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::CachedAIServiceCover");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RangeAttack, ExcludeReachingTarget) == 0x2c0, "Offset mismatch for UFortAthenaAIBotEvaluator_RangeAttack::ExcludeReachingTarget");

// Size: 0x1c0 (Inherited: 0x3f0, Single: 0xfffffdd0)
class UFortAthenaAIBotEvaluator_ReachBeacon : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName ReachBeaconStatusKeyName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName ReachBeaconMovementStateKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName ReachBeaconTargetKeyName; // 0x1a8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1ac[0x8]; // 0x1ac (Size: 0x8, Type: PaddingProperty)
    TWeakObjectPtr<UFortAthenaBeaconComponent*> CurrentBeacon; // 0x1b4 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_1bc[0x4]; // 0x1bc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_ReachBeacon) == 0x1c0, "Size mismatch for UFortAthenaAIBotEvaluator_ReachBeacon");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReachBeacon, ReachBeaconStatusKeyName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_ReachBeacon::ReachBeaconStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReachBeacon, ReachBeaconMovementStateKeyName) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_ReachBeacon::ReachBeaconMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReachBeacon, ReachBeaconTargetKeyName) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_ReachBeacon::ReachBeaconTargetKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReachBeacon, CurrentBeacon) == 0x1b4, "Offset mismatch for UFortAthenaAIBotEvaluator_ReachBeacon::CurrentBeacon");

// Size: 0x670 (Inherited: 0x3f0, Single: 0x280)
class UFortAthenaAIBotEvaluator_ReactToVerb : public UFortAthenaAIBotEvaluator_Movement
{
public:
    uint8_t Pad_1a0[0x78]; // 0x1a0 (Size: 0x78, Type: PaddingProperty)
    UFortAthenaAIBotReactToVerbDigestedSkillSet* CacheReactToVerbDigestedSkillSet; // 0x218 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_220[0x98]; // 0x220 (Size: 0x98, Type: PaddingProperty)
    FSoftDataRegistryOrTable VerbReactionsMap; // 0x2b8 (Size: 0x30, Type: StructProperty)
    FScalableFloat MinDistanceFromPlayerToReact; // 0x2e8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinDistanceFromPlayerToReactForGroupEmotes; // 0x310 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxReactionEmoteDuration; // 0x338 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxReactionWaitTime; // 0x360 (Size: 0x28, Type: StructProperty)
    FScalableFloat DelayBeforeRunningQueuedReaction; // 0x388 (Size: 0x28, Type: StructProperty)
    FFortNearbyActorsPerceptionConfiguration PerceptionConfiguration; // 0x3b0 (Size: 0xc0, Type: StructProperty)
    bool bIsHighPriorityEvaluator; // 0x470 (Size: 0x1, Type: BoolProperty)
    bool bEnableNPCReactionsPersistence; // 0x471 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_472[0x6]; // 0x472 (Size: 0x6, Type: PaddingProperty)
    FScalableFloat ReactToEmotes; // 0x478 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxNPCsReactingToEmotes; // 0x4a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat LimitReactToGroupEmote; // 0x4c8 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReactToGroupEmoteIfClosestNPCWithinDistance; // 0x4f0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReactToGroupEmoteDelaySecondsWhenPlayersNearby; // 0x518 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinDistanceOfPlayersFromPlayerToConsiderNearbyPlayer; // 0x540 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReactToGroupEmoteDelayRandomDeviation; // 0x568 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReactToGroupEmoteDelayForNumPlayersNearby; // 0x590 (Size: 0x28, Type: StructProperty)
    FGameplayTag ReactToEmoteGameplayTag; // 0x5b8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_5bc[0x4]; // 0x5bc (Size: 0x4, Type: PaddingProperty)
    FGameplayTagQuery ReactToEmoteRequiredTagQueryOnAI; // 0x5c0 (Size: 0x48, Type: StructProperty)
    FName ReactToVerbTargetActorKeyName; // 0x608 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_60c[0x4]; // 0x60c (Size: 0x4, Type: PaddingProperty)
    FName ReactToVerbShouldMoveKeyName; // 0x610 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_614[0x4]; // 0x614 (Size: 0x4, Type: PaddingProperty)
    FName ReactToVerbShouldMoveReachDistanceKeyName; // 0x618 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_61c[0x4]; // 0x61c (Size: 0x4, Type: PaddingProperty)
    FName ExtraStructDataKeyName; // 0x620 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_624[0x4]; // 0x624 (Size: 0x4, Type: PaddingProperty)
    FName ReactToVerbShouldJoinGroupEmoteKeyName; // 0x628 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_62c[0x4]; // 0x62c (Size: 0x4, Type: PaddingProperty)
    FName ShouldFollowTargetKeyName; // 0x630 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_634[0x2c]; // 0x634 (Size: 0x2c, Type: PaddingProperty)
    FPersistenceFrameworkSaveControl SaveControl; // 0x660 (Size: 0x10, Type: StructProperty)

public:
    void HandleDelayedReactToGroupEmoteTimerElapsed(); // 0x554e3c4 (Index: 0x0, Flags: Final|Native|Public)

protected:
    void HandlePawnStartedEmote(UFortItemDefinition*& const MontageItemDef, AFortPawn*& PawnEmoting); // 0xa93bc70 (Index: 0x1, Flags: Final|Native|Protected)
    void HandlePawnStoppedEmote(UFortItemDefinition*& const MontageItemDef, AFortPawn*& PawnEmoting); // 0xa93bc70 (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_ReactToVerb) == 0x670, "Size mismatch for UFortAthenaAIBotEvaluator_ReactToVerb");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, CacheReactToVerbDigestedSkillSet) == 0x218, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::CacheReactToVerbDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, VerbReactionsMap) == 0x2b8, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::VerbReactionsMap");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, MinDistanceFromPlayerToReact) == 0x2e8, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::MinDistanceFromPlayerToReact");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, MinDistanceFromPlayerToReactForGroupEmotes) == 0x310, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::MinDistanceFromPlayerToReactForGroupEmotes");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, MaxReactionEmoteDuration) == 0x338, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::MaxReactionEmoteDuration");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, MaxReactionWaitTime) == 0x360, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::MaxReactionWaitTime");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, DelayBeforeRunningQueuedReaction) == 0x388, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::DelayBeforeRunningQueuedReaction");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, PerceptionConfiguration) == 0x3b0, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::PerceptionConfiguration");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, bIsHighPriorityEvaluator) == 0x470, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::bIsHighPriorityEvaluator");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, bEnableNPCReactionsPersistence) == 0x471, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::bEnableNPCReactionsPersistence");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ReactToEmotes) == 0x478, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ReactToEmotes");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, MaxNPCsReactingToEmotes) == 0x4a0, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::MaxNPCsReactingToEmotes");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, LimitReactToGroupEmote) == 0x4c8, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::LimitReactToGroupEmote");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ReactToGroupEmoteIfClosestNPCWithinDistance) == 0x4f0, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ReactToGroupEmoteIfClosestNPCWithinDistance");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ReactToGroupEmoteDelaySecondsWhenPlayersNearby) == 0x518, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ReactToGroupEmoteDelaySecondsWhenPlayersNearby");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, MinDistanceOfPlayersFromPlayerToConsiderNearbyPlayer) == 0x540, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::MinDistanceOfPlayersFromPlayerToConsiderNearbyPlayer");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ReactToGroupEmoteDelayRandomDeviation) == 0x568, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ReactToGroupEmoteDelayRandomDeviation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ReactToGroupEmoteDelayForNumPlayersNearby) == 0x590, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ReactToGroupEmoteDelayForNumPlayersNearby");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ReactToEmoteGameplayTag) == 0x5b8, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ReactToEmoteGameplayTag");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ReactToEmoteRequiredTagQueryOnAI) == 0x5c0, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ReactToEmoteRequiredTagQueryOnAI");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ReactToVerbTargetActorKeyName) == 0x608, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ReactToVerbTargetActorKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ReactToVerbShouldMoveKeyName) == 0x610, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ReactToVerbShouldMoveKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ReactToVerbShouldMoveReachDistanceKeyName) == 0x618, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ReactToVerbShouldMoveReachDistanceKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ExtraStructDataKeyName) == 0x620, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ExtraStructDataKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ReactToVerbShouldJoinGroupEmoteKeyName) == 0x628, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ReactToVerbShouldJoinGroupEmoteKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, ShouldFollowTargetKeyName) == 0x630, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::ShouldFollowTargetKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReactToVerb, SaveControl) == 0x660, "Offset mismatch for UFortAthenaAIBotEvaluator_ReactToVerb::SaveControl");

// Size: 0x208 (Inherited: 0x3f0, Single: 0xfffffe18)
class UFortAthenaAIBotEvaluator_RecoverLineOfSight : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FScalableFloat RecoveringLineOfSightMaxDuration; // 0x1a0 (Size: 0x28, Type: StructProperty)
    TArray<FName> ExecutionStatusToListenKeyNames; // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    FName RecoverLineOfSightExecutionStatusKeyName; // 0x1d8 (Size: 0x4, Type: NameProperty)
    FName RecoverLineOfSightMovementStateKeyName; // 0x1dc (Size: 0x4, Type: NameProperty)
    FName RecoverLineOfSightDestinationKeyName; // 0x1e0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1e4[0x24]; // 0x1e4 (Size: 0x24, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_RecoverLineOfSight) == 0x208, "Size mismatch for UFortAthenaAIBotEvaluator_RecoverLineOfSight");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RecoverLineOfSight, RecoveringLineOfSightMaxDuration) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_RecoverLineOfSight::RecoveringLineOfSightMaxDuration");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RecoverLineOfSight, ExecutionStatusToListenKeyNames) == 0x1c8, "Offset mismatch for UFortAthenaAIBotEvaluator_RecoverLineOfSight::ExecutionStatusToListenKeyNames");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RecoverLineOfSight, RecoverLineOfSightExecutionStatusKeyName) == 0x1d8, "Offset mismatch for UFortAthenaAIBotEvaluator_RecoverLineOfSight::RecoverLineOfSightExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RecoverLineOfSight, RecoverLineOfSightMovementStateKeyName) == 0x1dc, "Offset mismatch for UFortAthenaAIBotEvaluator_RecoverLineOfSight::RecoverLineOfSightMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_RecoverLineOfSight, RecoverLineOfSightDestinationKeyName) == 0x1e0, "Offset mismatch for UFortAthenaAIBotEvaluator_RecoverLineOfSight::RecoverLineOfSightDestinationKeyName");

// Size: 0xb0 (Inherited: 0x170, Single: 0xffffff40)
class UFortAthenaAIBotEvaluator_ReloadWeapon : public UFortAthenaAIBotEvaluator
{
public:
    FName WeaponKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_ac[0x2]; // 0xac (Size: 0x2, Type: PaddingProperty)
    bool bCanReloadWeaponsInInventory; // 0xae (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_af[0x1]; // 0xaf (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_ReloadWeapon) == 0xb0, "Size mismatch for UFortAthenaAIBotEvaluator_ReloadWeapon");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReloadWeapon, WeaponKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_ReloadWeapon::WeaponKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ReloadWeapon, bCanReloadWeaponsInInventory) == 0xae, "Offset mismatch for UFortAthenaAIBotEvaluator_ReloadWeapon::bCanReloadWeaponsInInventory");

// Size: 0x1d0 (Inherited: 0x3f0, Single: 0xfffffde0)
class UFortAthenaAIBotEvaluator_Retreat : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName RetreatDestinationName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1a4[0x4]; // 0x1a4 (Size: 0x4, Type: PaddingProperty)
    UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingDigestedSkillSet; // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAICoverComponent* CachedCoverComponent; // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1b8[0x18]; // 0x1b8 (Size: 0x18, Type: PaddingProperty)

protected:
    void HandlePlayerHealthOrShieldChanged(); // 0xef733b4 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Retreat) == 0x1d0, "Size mismatch for UFortAthenaAIBotEvaluator_Retreat");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Retreat, RetreatDestinationName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Retreat::RetreatDestinationName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Retreat, CacheAttackingDigestedSkillSet) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_Retreat::CacheAttackingDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Retreat, CachedCoverComponent) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_Retreat::CachedCoverComponent");

// Size: 0x208 (Inherited: 0x3f0, Single: 0xfffffe18)
class UFortAthenaAIBotEvaluator_Revive : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FScalableFloat LastReviveTargetExpiration; // 0x1a0 (Size: 0x28, Type: StructProperty)
    FName ReviveTargetKeyName; // 0x1c8 (Size: 0x4, Type: NameProperty)
    FName ReviveLastTargetKeyName; // 0x1cc (Size: 0x4, Type: NameProperty)
    UFortAthenaAIRuntimeParameters_ReviveBehavior* ReviveBehaviorRuntimeParameters; // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawnAthena* CurrentReviveTarget; // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    TArray<AFortPlayerPawnAthena*> DBNOAllyPawns; // 0x1e0 (Size: 0x10, Type: ArrayProperty)
    UFortAthenaAIBotReviveDigestedSkillSet* ReviveSkillSet; // 0x1f0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1f8[0x10]; // 0x1f8 (Size: 0x10, Type: PaddingProperty)

private:
    void OnCurrentTargetRevived(AFortPlayerPawn*& RevivedPawn); // 0xef73b94 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Revive) == 0x208, "Size mismatch for UFortAthenaAIBotEvaluator_Revive");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Revive, LastReviveTargetExpiration) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Revive::LastReviveTargetExpiration");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Revive, ReviveTargetKeyName) == 0x1c8, "Offset mismatch for UFortAthenaAIBotEvaluator_Revive::ReviveTargetKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Revive, ReviveLastTargetKeyName) == 0x1cc, "Offset mismatch for UFortAthenaAIBotEvaluator_Revive::ReviveLastTargetKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Revive, ReviveBehaviorRuntimeParameters) == 0x1d0, "Offset mismatch for UFortAthenaAIBotEvaluator_Revive::ReviveBehaviorRuntimeParameters");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Revive, CurrentReviveTarget) == 0x1d8, "Offset mismatch for UFortAthenaAIBotEvaluator_Revive::CurrentReviveTarget");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Revive, DBNOAllyPawns) == 0x1e0, "Offset mismatch for UFortAthenaAIBotEvaluator_Revive::DBNOAllyPawns");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Revive, ReviveSkillSet) == 0x1f0, "Offset mismatch for UFortAthenaAIBotEvaluator_Revive::ReviveSkillSet");

// Size: 0x170 (Inherited: 0x268, Single: 0xffffff08)
class UFortAthenaAIBotEvaluator_SandTunnel : public UFortAthenaAIBotEvaluator_TagQuery
{
public:
    FName JumpExecutionStatusName; // 0xf8 (Size: 0x4, Type: NameProperty)
    FName LootInteractionExecutionStatusName; // 0xfc (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerMeleeName; // 0x100 (Size: 0x4, Type: NameProperty)
    FName WeaponFireName; // 0x104 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
    FGameplayTagQuery BuriedTagQuery; // 0x110 (Size: 0x48, Type: StructProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementDigestedSkillSet; // 0x158 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_160[0x10]; // 0x160 (Size: 0x10, Type: PaddingProperty)

private:
    void OnBotControllerAlertLevelChanged(AFortAthenaAIBotController*& BotController, EAlertLevel& OldAlertLevel, EAlertLevel& NewAlertLevel); // 0xef736b4 (Index: 0x1, Flags: Final|Native|Private)

protected:
    void Jump(); // 0xef733c8 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_SandTunnel) == 0x170, "Size mismatch for UFortAthenaAIBotEvaluator_SandTunnel");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SandTunnel, JumpExecutionStatusName) == 0xf8, "Offset mismatch for UFortAthenaAIBotEvaluator_SandTunnel::JumpExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SandTunnel, LootInteractionExecutionStatusName) == 0xfc, "Offset mismatch for UFortAthenaAIBotEvaluator_SandTunnel::LootInteractionExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SandTunnel, WeaponTriggerMeleeName) == 0x100, "Offset mismatch for UFortAthenaAIBotEvaluator_SandTunnel::WeaponTriggerMeleeName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SandTunnel, WeaponFireName) == 0x104, "Offset mismatch for UFortAthenaAIBotEvaluator_SandTunnel::WeaponFireName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SandTunnel, BuriedTagQuery) == 0x110, "Offset mismatch for UFortAthenaAIBotEvaluator_SandTunnel::BuriedTagQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SandTunnel, CacheMovementDigestedSkillSet) == 0x158, "Offset mismatch for UFortAthenaAIBotEvaluator_SandTunnel::CacheMovementDigestedSkillSet");

// Size: 0x210 (Inherited: 0x3f0, Single: 0xfffffe20)
class UFortAthenaAIBotEvaluator_SelectNextDynamicPOI : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName DynamicPOIExecutionStatusKeyName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName DynamicPOILocationKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1a8[0x8]; // 0x1a8 (Size: 0x8, Type: PaddingProperty)
    UFortGameStateComponent_BattleRoyaleGamePhaseLogic* CachedBRLogic; // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1b8[0x38]; // 0x1b8 (Size: 0x38, Type: PaddingProperty)
    FTimerHandle NextSearchTimerHandle; // 0x1f0 (Size: 0x8, Type: StructProperty)
    TArray<FFailedToReachPOI> FailedBotPOIList; // 0x1f8 (Size: 0x10, Type: ArrayProperty)
    int32_t CachedSelectedBotPOIID; // 0x208 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_20c[0x4]; // 0x20c (Size: 0x4, Type: PaddingProperty)

private:
    void OnBattleRoyalLogicReady(const FFortBattleRoyaleGamePhaseLogicComponentReadyEvent Event); // 0xef735e4 (Index: 0x1, Flags: Final|Native|Private|HasOutParms)
    void OnSafeZonePhaseChanged(const FFortSafeZonePhaseUpdatedEvent Event); // 0xef73cc0 (Index: 0x2, Flags: Final|Native|Private|HasOutParms)
    void ReachingPositionFail_Async(int32_t& const RequestID); // 0xef73d90 (Index: 0x3, Flags: Final|Native|Private)

protected:
    void OnAgentDied(AFortAthenaAIBotController*& BotController, AFortPawn*& FortPawn); // 0xef733dc (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_SelectNextDynamicPOI) == 0x210, "Size mismatch for UFortAthenaAIBotEvaluator_SelectNextDynamicPOI");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextDynamicPOI, DynamicPOIExecutionStatusKeyName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextDynamicPOI::DynamicPOIExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextDynamicPOI, DynamicPOILocationKeyName) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextDynamicPOI::DynamicPOILocationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextDynamicPOI, CachedBRLogic) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextDynamicPOI::CachedBRLogic");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextDynamicPOI, NextSearchTimerHandle) == 0x1f0, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextDynamicPOI::NextSearchTimerHandle");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextDynamicPOI, FailedBotPOIList) == 0x1f8, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextDynamicPOI::FailedBotPOIList");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextDynamicPOI, CachedSelectedBotPOIID) == 0x208, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextDynamicPOI::CachedSelectedBotPOIID");

// Size: 0x1d0 (Inherited: 0x3f0, Single: 0xfffffde0)
class UFortAthenaAIBotEvaluator_SelectNextPOI : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName NextPOIKeyName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName MarkerLocationKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1a8[0x8]; // 0x1a8 (Size: 0x8, Type: PaddingProperty)
    AFortPoiVolume* StartingGroundPOI; // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    bool bCheckForStartingGroundPOI; // 0x1b8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1b9[0x3]; // 0x1b9 (Size: 0x3, Type: PaddingProperty)
    float CurrentPOICompletionTime; // 0x1bc (Size: 0x4, Type: FloatProperty)
    float DurationInsideCurrentPOI; // 0x1c0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c4[0x4]; // 0x1c4 (Size: 0x4, Type: PaddingProperty)
    UFortAthenaAIBotLootingDigestedSkillSet* CachedLootingSkillSet; // 0x1c8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_SelectNextPOI) == 0x1d0, "Size mismatch for UFortAthenaAIBotEvaluator_SelectNextPOI");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextPOI, NextPOIKeyName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextPOI::NextPOIKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextPOI, MarkerLocationKeyName) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextPOI::MarkerLocationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextPOI, StartingGroundPOI) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextPOI::StartingGroundPOI");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextPOI, bCheckForStartingGroundPOI) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextPOI::bCheckForStartingGroundPOI");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextPOI, CurrentPOICompletionTime) == 0x1bc, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextPOI::CurrentPOICompletionTime");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextPOI, DurationInsideCurrentPOI) == 0x1c0, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextPOI::DurationInsideCurrentPOI");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectNextPOI, CachedLootingSkillSet) == 0x1c8, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectNextPOI::CachedLootingSkillSet");

// Size: 0x2c8 (Inherited: 0x3f0, Single: 0xfffffed8)
class UFortAthenaAIBotEvaluator_SelectVehicle : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName VehicleDestinationKeyName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName SelectVehicleMovementStateKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName SelectVehicleStatusKeyName; // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName SelectedVehicleKeyName; // 0x1ac (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1b0[0x8]; // 0x1b0 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat Enabled; // 0x1b8 (Size: 0x28, Type: StructProperty)
    float VehicleSearchRadius; // 0x1e0 (Size: 0x4, Type: FloatProperty)
    bool bCanEnterOnlyWithHisConverter; // 0x1e4 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterAsDriver; // 0x1e5 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterVehiclesInWater; // 0x1e6 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterOutOfFuelVehicles; // 0x1e7 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterWithPlayerDriver; // 0x1e8 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterWithPlayerOnAnySeat; // 0x1e9 (Size: 0x1, Type: BoolProperty)
    bool bCanEnterOnlyMatchingPatrols; // 0x1ea (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1eb[0x5]; // 0x1eb (Size: 0x5, Type: PaddingProperty)
    FGameplayTagQuery VehiclesFilterTagQuery; // 0x1f0 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery SeatsFilterTagQuery; // 0x238 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery OwnerFilterTagQuery; // 0x280 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_SelectVehicle) == 0x2c8, "Size mismatch for UFortAthenaAIBotEvaluator_SelectVehicle");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, VehicleDestinationKeyName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::VehicleDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, SelectVehicleMovementStateKeyName) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::SelectVehicleMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, SelectVehicleStatusKeyName) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::SelectVehicleStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, SelectedVehicleKeyName) == 0x1ac, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::SelectedVehicleKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, Enabled) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::Enabled");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, VehicleSearchRadius) == 0x1e0, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::VehicleSearchRadius");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, bCanEnterOnlyWithHisConverter) == 0x1e4, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::bCanEnterOnlyWithHisConverter");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, bCanEnterAsDriver) == 0x1e5, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::bCanEnterAsDriver");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, bCanEnterVehiclesInWater) == 0x1e6, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::bCanEnterVehiclesInWater");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, bCanEnterOutOfFuelVehicles) == 0x1e7, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::bCanEnterOutOfFuelVehicles");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, bCanEnterWithPlayerDriver) == 0x1e8, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::bCanEnterWithPlayerDriver");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, bCanEnterWithPlayerOnAnySeat) == 0x1e9, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::bCanEnterWithPlayerOnAnySeat");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, bCanEnterOnlyMatchingPatrols) == 0x1ea, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::bCanEnterOnlyMatchingPatrols");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, VehiclesFilterTagQuery) == 0x1f0, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::VehiclesFilterTagQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, SeatsFilterTagQuery) == 0x238, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::SeatsFilterTagQuery");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SelectVehicle, OwnerFilterTagQuery) == 0x280, "Offset mismatch for UFortAthenaAIBotEvaluator_SelectVehicle::OwnerFilterTagQuery");

// Size: 0x2b8 (Inherited: 0x3f0, Single: 0xfffffec8)
class UFortAthenaAIBotEvaluator_SmartObjects : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FGameplayTag EvaluationTag; // 0x1a0 (Size: 0x4, Type: StructProperty)
    bool bEvaluateSOValidityAfterChosen; // 0x1a4 (Size: 0x1, Type: BoolProperty)
    bool bEnableEntryLocationsSupport; // 0x1a5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a6[0x2]; // 0x1a6 (Size: 0x2, Type: PaddingProperty)
    FWorldConditionQueryDefinition CanRunPrecondition; // 0x1a8 (Size: 0x18, Type: StructProperty)
    FScalableFloat MaximumEntryLocationsChecksPerEvaluation; // 0x1c0 (Size: 0x28, Type: StructProperty)
    FScalableFloat EntryLocationFailuresBlacklistedTime; // 0x1e8 (Size: 0x28, Type: StructProperty)
    UCurveFloat* DistanceToWeightCurveForSlotPicking; // 0x210 (Size: 0x8, Type: ObjectProperty)
    UClass* OverridenFilterClassForEntryPoints; // 0x218 (Size: 0x8, Type: ClassProperty)
    TArray<FName> ExecutionStatusesToCheckForAllowToAvoidGoingToSOKeyNames; // 0x220 (Size: 0x10, Type: ArrayProperty)
    FName SmartObjectExecutionStatusKeyName; // 0x230 (Size: 0x4, Type: NameProperty)
    FName SmartObjectMovementStateKeyName; // 0x234 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationKeyName; // 0x238 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationRotationKeyName; // 0x23c (Size: 0x4, Type: NameProperty)
    FName SmartObjectShouldMoveKeyName; // 0x240 (Size: 0x4, Type: NameProperty)
    FName SmartObjectUrgencyKeyName; // 0x244 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_248[0x20]; // 0x248 (Size: 0x20, Type: PaddingProperty)
    UFortAthenaAIRuntimeParameters_SmartObjectBase* SmartObjectRuntimeParameters; // 0x268 (Size: 0x8, Type: ObjectProperty)
    USmartObjectSubsystem* SmartObjectSubsystem; // 0x270 (Size: 0x8, Type: ObjectProperty)
    FWorldConditionQueryState CanRunPreconditionQueryState; // 0x278 (Size: 0x30, Type: StructProperty)
    uint8_t Pad_2a8[0x10]; // 0x2a8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_SmartObjects) == 0x2b8, "Size mismatch for UFortAthenaAIBotEvaluator_SmartObjects");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, EvaluationTag) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::EvaluationTag");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, bEvaluateSOValidityAfterChosen) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::bEvaluateSOValidityAfterChosen");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, bEnableEntryLocationsSupport) == 0x1a5, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::bEnableEntryLocationsSupport");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, CanRunPrecondition) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::CanRunPrecondition");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, MaximumEntryLocationsChecksPerEvaluation) == 0x1c0, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::MaximumEntryLocationsChecksPerEvaluation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, EntryLocationFailuresBlacklistedTime) == 0x1e8, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::EntryLocationFailuresBlacklistedTime");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, DistanceToWeightCurveForSlotPicking) == 0x210, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::DistanceToWeightCurveForSlotPicking");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, OverridenFilterClassForEntryPoints) == 0x218, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::OverridenFilterClassForEntryPoints");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, ExecutionStatusesToCheckForAllowToAvoidGoingToSOKeyNames) == 0x220, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::ExecutionStatusesToCheckForAllowToAvoidGoingToSOKeyNames");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, SmartObjectExecutionStatusKeyName) == 0x230, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::SmartObjectExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, SmartObjectMovementStateKeyName) == 0x234, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::SmartObjectMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, SmartObjectDestinationKeyName) == 0x238, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::SmartObjectDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, SmartObjectDestinationRotationKeyName) == 0x23c, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::SmartObjectDestinationRotationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, SmartObjectShouldMoveKeyName) == 0x240, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::SmartObjectShouldMoveKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, SmartObjectUrgencyKeyName) == 0x244, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::SmartObjectUrgencyKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, SmartObjectRuntimeParameters) == 0x268, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::SmartObjectRuntimeParameters");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, SmartObjectSubsystem) == 0x270, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::SmartObjectSubsystem");
static_assert(offsetof(UFortAthenaAIBotEvaluator_SmartObjects, CanRunPreconditionQueryState) == 0x278, "Offset mismatch for UFortAthenaAIBotEvaluator_SmartObjects::CanRunPreconditionQueryState");

// Size: 0x140 (Inherited: 0x170, Single: 0xffffffd0)
class UFortAthenaAIBotEvaluator_Sprinting : public UFortAthenaAIBotEvaluator
{
public:
    FName AllowSprintKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    FName AllowSlideKeyName; // 0xac (Size: 0x4, Type: NameProperty)
    FName JumpExecutionStatusName; // 0xb0 (Size: 0x4, Type: NameProperty)
    FName TacticalSprintExecutionStatusName; // 0xb4 (Size: 0x4, Type: NameProperty)
    FName SlideExecutionStatusName; // 0xb8 (Size: 0x4, Type: NameProperty)
    FName UrgentMovementKeyName; // 0xbc (Size: 0x4, Type: NameProperty)
    FName RangeAttackExecutionStatusName; // 0xc0 (Size: 0x4, Type: NameProperty)
    FName MeleeAttackExecutionStatusName; // 0xc4 (Size: 0x4, Type: NameProperty)
    FName ThrowableAttackExecutionStatusName; // 0xc8 (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Bool ValidateSprintingBeforeTacticalSprinting; // 0xcc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool CanTacticalSprintJump; // 0xd8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_e4[0x12]; // 0xe4 (Size: 0x12, Type: PaddingProperty)
    bool bSprintOnlyInWater; // 0xf6 (Size: 0x1, Type: BoolProperty)
    bool bSprintOnlyInUrgentMode; // 0xf7 (Size: 0x1, Type: BoolProperty)
    UFortAthenaAIBotMovementDigestedSkillSet* MovementSkillSet; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* AimingSkillSet; // 0x100 (Size: 0x8, Type: ObjectProperty)
    float TacticalSprintTriggerChance; // 0x108 (Size: 0x4, Type: FloatProperty)
    float TacticalSprintTriggerChanceInUrgentMovement; // 0x10c (Size: 0x4, Type: FloatProperty)
    float TacticalSprintJumpTriggerChance; // 0x110 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_114[0x2c]; // 0x114 (Size: 0x2c, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Sprinting) == 0x140, "Size mismatch for UFortAthenaAIBotEvaluator_Sprinting");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, AllowSprintKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::AllowSprintKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, AllowSlideKeyName) == 0xac, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::AllowSlideKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, JumpExecutionStatusName) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::JumpExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, TacticalSprintExecutionStatusName) == 0xb4, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::TacticalSprintExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, SlideExecutionStatusName) == 0xb8, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::SlideExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, UrgentMovementKeyName) == 0xbc, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::UrgentMovementKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, RangeAttackExecutionStatusName) == 0xc0, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::RangeAttackExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, MeleeAttackExecutionStatusName) == 0xc4, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::MeleeAttackExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, ThrowableAttackExecutionStatusName) == 0xc8, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::ThrowableAttackExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, ValidateSprintingBeforeTacticalSprinting) == 0xcc, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::ValidateSprintingBeforeTacticalSprinting");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, CanTacticalSprintJump) == 0xd8, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::CanTacticalSprintJump");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, bSprintOnlyInWater) == 0xf6, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::bSprintOnlyInWater");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, bSprintOnlyInUrgentMode) == 0xf7, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::bSprintOnlyInUrgentMode");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, MovementSkillSet) == 0xf8, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::MovementSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, AimingSkillSet) == 0x100, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::AimingSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, TacticalSprintTriggerChance) == 0x108, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::TacticalSprintTriggerChance");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, TacticalSprintTriggerChanceInUrgentMovement) == 0x10c, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::TacticalSprintTriggerChanceInUrgentMovement");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Sprinting, TacticalSprintJumpTriggerChance) == 0x110, "Offset mismatch for UFortAthenaAIBotEvaluator_Sprinting::TacticalSprintJumpTriggerChance");

// Size: 0x150 (Inherited: 0x170, Single: 0xffffffe0)
class UFortAthenaAIBotEvaluator_StealWall : public UFortAthenaAIBotEvaluator
{
public:
    FName StealWallBuildTypeName; // 0xa8 (Size: 0x4, Type: NameProperty)
    FName StealWallBuildGridCoordName; // 0xac (Size: 0x4, Type: NameProperty)
    FName TargetActorName; // 0xb0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b4[0xc]; // 0xb4 (Size: 0xc, Type: PaddingProperty)
    UFortAthenaAIBotBuildingDigestedSkillSet* CacheBuildingDigestedSkillSet; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    ABuildingActor* CurrentBuildingTarget; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d0[0x80]; // 0xd0 (Size: 0x80, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_StealWall) == 0x150, "Size mismatch for UFortAthenaAIBotEvaluator_StealWall");
static_assert(offsetof(UFortAthenaAIBotEvaluator_StealWall, StealWallBuildTypeName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_StealWall::StealWallBuildTypeName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_StealWall, StealWallBuildGridCoordName) == 0xac, "Offset mismatch for UFortAthenaAIBotEvaluator_StealWall::StealWallBuildGridCoordName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_StealWall, TargetActorName) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_StealWall::TargetActorName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_StealWall, CacheBuildingDigestedSkillSet) == 0xc0, "Offset mismatch for UFortAthenaAIBotEvaluator_StealWall::CacheBuildingDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_StealWall, CurrentBuildingTarget) == 0xc8, "Offset mismatch for UFortAthenaAIBotEvaluator_StealWall::CurrentBuildingTarget");

// Size: 0x1d0 (Inherited: 0x3f0, Single: 0xfffffde0)
class UFortAthenaAIBotEvaluator_StepBack : public UFortAthenaAIBotEvaluator_Movement
{
public:
    UFortAthenaAIBotRangeAttackDigestedSkillSet* CachedRangeAttackDigestedSkillSet; // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    UAthenaAIServiceCover* CachedAIServiceCover; // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1b0[0x8]; // 0x1b0 (Size: 0x8, Type: PaddingProperty)
    FName StepBackExecutionStatusKeyName; // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName StepBackMovementStateKeyName; // 0x1bc (Size: 0x4, Type: NameProperty)
    FName StepBackDestinationKeyName; // 0x1c0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c4[0xc]; // 0x1c4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_StepBack) == 0x1d0, "Size mismatch for UFortAthenaAIBotEvaluator_StepBack");
static_assert(offsetof(UFortAthenaAIBotEvaluator_StepBack, CachedRangeAttackDigestedSkillSet) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_StepBack::CachedRangeAttackDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_StepBack, CachedAIServiceCover) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_StepBack::CachedAIServiceCover");
static_assert(offsetof(UFortAthenaAIBotEvaluator_StepBack, StepBackExecutionStatusKeyName) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_StepBack::StepBackExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_StepBack, StepBackMovementStateKeyName) == 0x1bc, "Offset mismatch for UFortAthenaAIBotEvaluator_StepBack::StepBackMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_StepBack, StepBackDestinationKeyName) == 0x1c0, "Offset mismatch for UFortAthenaAIBotEvaluator_StepBack::StepBackDestinationKeyName");

// Size: 0x200 (Inherited: 0x3f0, Single: 0xfffffe10)
class UFortAthenaAIBotEvaluator_Storm : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName StormDestinationName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1a4[0xc]; // 0x1a4 (Size: 0xc, Type: PaddingProperty)
    AFortGameModeAthena* CacheAthenaGameMode; // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    UBehaviorTreeComponent* CachedBTComp; // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    UFortGameStateComponent_BattleRoyaleGamePhaseLogic* CachedGamePhaseLogic; // 0x1c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1c8[0x38]; // 0x1c8 (Size: 0x38, Type: PaddingProperty)

public:
    void OnSafeZoneStateChanged(EFortSafeZoneState& const NewState); // 0xef97ffc (Index: 0x0, Flags: Final|Native|Public)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Storm) == 0x200, "Size mismatch for UFortAthenaAIBotEvaluator_Storm");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Storm, StormDestinationName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Storm::StormDestinationName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Storm, CacheAthenaGameMode) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_Storm::CacheAthenaGameMode");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Storm, CachedBTComp) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_Storm::CachedBTComp");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Storm, CachedGamePhaseLogic) == 0x1c0, "Offset mismatch for UFortAthenaAIBotEvaluator_Storm::CachedGamePhaseLogic");

// Size: 0x100 (Inherited: 0x268, Single: 0xfffffe98)
class UFortAthenaAIBotEvaluator_TagQueryToBBKey : public UFortAthenaAIBotEvaluator_TagQuery
{
public:
    FName LinkedBBKeyName; // 0xf8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_fc[0x4]; // 0xfc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_TagQueryToBBKey) == 0x100, "Size mismatch for UFortAthenaAIBotEvaluator_TagQueryToBBKey");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TagQueryToBBKey, LinkedBBKeyName) == 0xf8, "Offset mismatch for UFortAthenaAIBotEvaluator_TagQueryToBBKey::LinkedBBKeyName");

// Size: 0x230 (Inherited: 0x3f0, Single: 0xfffffe40)
class UFortAthenaAIBotEvaluator_TakeCover : public UFortAthenaAIBotEvaluator_Movement
{
public:
    UFortAthenaAIBotRangeAttackDigestedSkillSet* CacheRangeAttackDigestedSkillSet; // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    UAthenaAIServiceCover* CachedAIServiceCover; // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    FName DestinationKeyName; // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName MoveToDestinationKeyName; // 0x1bc (Size: 0x4, Type: NameProperty)
    FName HealingStatusKeyName; // 0x1c0 (Size: 0x4, Type: NameProperty)
    FName WeaponFireName; // 0x1c4 (Size: 0x4, Type: NameProperty)
    FName TargetActorName; // 0x1c8 (Size: 0x4, Type: NameProperty)
    FName BunkerStatusKeyName; // 0x1cc (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1d0[0x10]; // 0x1d0 (Size: 0x10, Type: PaddingProperty)
    ABuildingActor* CachedCoverBuildingActor; // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    TArray<ABuildingActor*> ExcludedBuildingActors; // 0x1e8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_1f8[0x38]; // 0x1f8 (Size: 0x38, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_TakeCover) == 0x230, "Size mismatch for UFortAthenaAIBotEvaluator_TakeCover");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TakeCover, CacheRangeAttackDigestedSkillSet) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_TakeCover::CacheRangeAttackDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TakeCover, CacheAimingDigestedSkillSet) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_TakeCover::CacheAimingDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TakeCover, CachedAIServiceCover) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_TakeCover::CachedAIServiceCover");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TakeCover, DestinationKeyName) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_TakeCover::DestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TakeCover, MoveToDestinationKeyName) == 0x1bc, "Offset mismatch for UFortAthenaAIBotEvaluator_TakeCover::MoveToDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TakeCover, HealingStatusKeyName) == 0x1c0, "Offset mismatch for UFortAthenaAIBotEvaluator_TakeCover::HealingStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TakeCover, WeaponFireName) == 0x1c4, "Offset mismatch for UFortAthenaAIBotEvaluator_TakeCover::WeaponFireName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TakeCover, TargetActorName) == 0x1c8, "Offset mismatch for UFortAthenaAIBotEvaluator_TakeCover::TargetActorName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TakeCover, BunkerStatusKeyName) == 0x1cc, "Offset mismatch for UFortAthenaAIBotEvaluator_TakeCover::BunkerStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TakeCover, CachedCoverBuildingActor) == 0x1e0, "Offset mismatch for UFortAthenaAIBotEvaluator_TakeCover::CachedCoverBuildingActor");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TakeCover, ExcludedBuildingActors) == 0x1e8, "Offset mismatch for UFortAthenaAIBotEvaluator_TakeCover::ExcludedBuildingActors");

// Size: 0x208 (Inherited: 0x5a8, Single: 0xfffffc60)
class UFortAthenaAIBotEvaluator_ThrowableAttack : public UFortAthenaAIBotEvaluator_Attack
{
public:
    FName WeaponTriggerThrowableName; // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName ThrowableAttackIsReadyToThrowName; // 0x1bc (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c0[0x8]; // 0x1c0 (Size: 0x8, Type: PaddingProperty)
    UFortAthenaAIBotAttackingDigestedSkillSet* AttackingSkillSet; // 0x1c8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotRangeAttackDigestedSkillSet* RangeAttackSkillSet; // 0x1d0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* AimingSkillSet; // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    UFortWorldItem* ChosenWeapon; // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1e8[0x20]; // 0x1e8 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_ThrowableAttack) == 0x208, "Size mismatch for UFortAthenaAIBotEvaluator_ThrowableAttack");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ThrowableAttack, WeaponTriggerThrowableName) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_ThrowableAttack::WeaponTriggerThrowableName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ThrowableAttack, ThrowableAttackIsReadyToThrowName) == 0x1bc, "Offset mismatch for UFortAthenaAIBotEvaluator_ThrowableAttack::ThrowableAttackIsReadyToThrowName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ThrowableAttack, AttackingSkillSet) == 0x1c8, "Offset mismatch for UFortAthenaAIBotEvaluator_ThrowableAttack::AttackingSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ThrowableAttack, RangeAttackSkillSet) == 0x1d0, "Offset mismatch for UFortAthenaAIBotEvaluator_ThrowableAttack::RangeAttackSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ThrowableAttack, AimingSkillSet) == 0x1d8, "Offset mismatch for UFortAthenaAIBotEvaluator_ThrowableAttack::AimingSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_ThrowableAttack, ChosenWeapon) == 0x1e0, "Offset mismatch for UFortAthenaAIBotEvaluator_ThrowableAttack::ChosenWeapon");

// Size: 0xd8 (Inherited: 0x170, Single: 0xffffff68)
class UFortAthenaAIBotEvaluator_TrapOnPathDetected : public UFortAthenaAIBotEvaluator
{
public:
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0xa8 (Size: 0x8, Type: ObjectProperty)
    FName TrapOnPathKeyName; // 0xb0 (Size: 0x4, Type: NameProperty)
    FName TrapActorOnPathKeyName; // 0xb4 (Size: 0x4, Type: NameProperty)
    FName TargetActorName; // 0xb8 (Size: 0x4, Type: NameProperty)
    FName AlertLevelName; // 0xbc (Size: 0x4, Type: NameProperty)
    FName RangeAttackExecutionStatusName; // 0xc0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c4[0xc]; // 0xc4 (Size: 0xc, Type: PaddingProperty)
    ABuildingTrap* CurrentTrapTarget; // 0xd0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_TrapOnPathDetected) == 0xd8, "Size mismatch for UFortAthenaAIBotEvaluator_TrapOnPathDetected");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TrapOnPathDetected, CacheAimingDigestedSkillSet) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_TrapOnPathDetected::CacheAimingDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TrapOnPathDetected, TrapOnPathKeyName) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_TrapOnPathDetected::TrapOnPathKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TrapOnPathDetected, TrapActorOnPathKeyName) == 0xb4, "Offset mismatch for UFortAthenaAIBotEvaluator_TrapOnPathDetected::TrapActorOnPathKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TrapOnPathDetected, TargetActorName) == 0xb8, "Offset mismatch for UFortAthenaAIBotEvaluator_TrapOnPathDetected::TargetActorName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TrapOnPathDetected, AlertLevelName) == 0xbc, "Offset mismatch for UFortAthenaAIBotEvaluator_TrapOnPathDetected::AlertLevelName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TrapOnPathDetected, RangeAttackExecutionStatusName) == 0xc0, "Offset mismatch for UFortAthenaAIBotEvaluator_TrapOnPathDetected::RangeAttackExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_TrapOnPathDetected, CurrentTrapTarget) == 0xd0, "Offset mismatch for UFortAthenaAIBotEvaluator_TrapOnPathDetected::CurrentTrapTarget");

// Size: 0x250 (Inherited: 0x3f0, Single: 0xfffffe60)
class UFortAthenaAIBotEvaluator_VehicleCombatNavigation : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FValueOrBBKey_Float ExecutionDuration; // 0x1a0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float ExecutionDurationDeviation; // 0x1ac (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float CooldownDuration; // 0x1b8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float CooldownDurationDeviation; // 0x1c4 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float OddsToStart; // 0x1d0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float OddsToStartWhenTargetMatchesOptionalTags; // 0x1dc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float OddsToGoOnCooldown; // 0x1e8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float OddsToGoOnCooldownWhenTargetMatchesOptionalTags; // 0x1f4 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_GameplayTagContainer OptionalTargetTagsToMatch; // 0x200 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_228[0x28]; // 0x228 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_VehicleCombatNavigation) == 0x250, "Size mismatch for UFortAthenaAIBotEvaluator_VehicleCombatNavigation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleCombatNavigation, ExecutionDuration) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleCombatNavigation::ExecutionDuration");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleCombatNavigation, ExecutionDurationDeviation) == 0x1ac, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleCombatNavigation::ExecutionDurationDeviation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleCombatNavigation, CooldownDuration) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleCombatNavigation::CooldownDuration");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleCombatNavigation, CooldownDurationDeviation) == 0x1c4, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleCombatNavigation::CooldownDurationDeviation");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleCombatNavigation, OddsToStart) == 0x1d0, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleCombatNavigation::OddsToStart");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleCombatNavigation, OddsToStartWhenTargetMatchesOptionalTags) == 0x1dc, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleCombatNavigation::OddsToStartWhenTargetMatchesOptionalTags");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleCombatNavigation, OddsToGoOnCooldown) == 0x1e8, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleCombatNavigation::OddsToGoOnCooldown");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleCombatNavigation, OddsToGoOnCooldownWhenTargetMatchesOptionalTags) == 0x1f4, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleCombatNavigation::OddsToGoOnCooldownWhenTargetMatchesOptionalTags");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleCombatNavigation, OptionalTargetTagsToMatch) == 0x200, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleCombatNavigation::OptionalTargetTagsToMatch");

// Size: 0xb0 (Inherited: 0x170, Single: 0xffffff40)
class UFortAthenaAIBotEvaluator_VehicleEscalate : public UFortAthenaAIBotEvaluator
{
public:
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_VehicleEscalate) == 0xb0, "Size mismatch for UFortAthenaAIBotEvaluator_VehicleEscalate");

// Size: 0xb0 (Inherited: 0x170, Single: 0xffffff40)
class UFortAthenaAIBotEvaluator_VehicleLeaveSeat : public UFortAthenaAIBotEvaluator
{
public:
    FName LeaveSeatStatusKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_ac[0x2]; // 0xac (Size: 0x2, Type: PaddingProperty)
    bool bLeaveSeatWhenPlayerInVehicle; // 0xae (Size: 0x1, Type: BoolProperty)
    bool bLeaveSeatWhenConverterLeave; // 0xaf (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_VehicleLeaveSeat) == 0xb0, "Size mismatch for UFortAthenaAIBotEvaluator_VehicleLeaveSeat");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleLeaveSeat, LeaveSeatStatusKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleLeaveSeat::LeaveSeatStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleLeaveSeat, bLeaveSeatWhenPlayerInVehicle) == 0xae, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleLeaveSeat::bLeaveSeatWhenPlayerInVehicle");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleLeaveSeat, bLeaveSeatWhenConverterLeave) == 0xaf, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleLeaveSeat::bLeaveSeatWhenConverterLeave");

// Size: 0xc0 (Inherited: 0x170, Single: 0xffffff50)
class UFortAthenaAIBotEvaluator_VehicleSwitchSeat : public UFortAthenaAIBotEvaluator
{
public:
    FName SwitchSeatStatusKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
    FValueOrBBKey_Bool bSwitchToDriverSeatIfEmpty; // 0xb0 (Size: 0xc, Type: StructProperty)
    bool bSwitchToEmptyDriverSeat; // 0xbc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_bd[0x3]; // 0xbd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_VehicleSwitchSeat) == 0xc0, "Size mismatch for UFortAthenaAIBotEvaluator_VehicleSwitchSeat");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleSwitchSeat, SwitchSeatStatusKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleSwitchSeat::SwitchSeatStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleSwitchSeat, bSwitchToDriverSeatIfEmpty) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleSwitchSeat::bSwitchToDriverSeatIfEmpty");
static_assert(offsetof(UFortAthenaAIBotEvaluator_VehicleSwitchSeat, bSwitchToEmptyDriverSeat) == 0xbc, "Offset mismatch for UFortAthenaAIBotEvaluator_VehicleSwitchSeat::bSwitchToEmptyDriverSeat");

// Size: 0xb0 (Inherited: 0x170, Single: 0xffffff40)
class UFortAthenaAIBotEvaluator_WaitForPassengers : public UFortAthenaAIBotEvaluator
{
public:
    FName WaitForPassengersStatusKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_WaitForPassengers) == 0xb0, "Size mismatch for UFortAthenaAIBotEvaluator_WaitForPassengers");
static_assert(offsetof(UFortAthenaAIBotEvaluator_WaitForPassengers, WaitForPassengersStatusKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_WaitForPassengers::WaitForPassengersStatusKeyName");

// Size: 0xd8 (Inherited: 0x170, Single: 0xffffff68)
class UFortAthenaAIBotEvaluator_Warmup : public UFortAthenaAIBotEvaluator
{
public:
    FName WarmupPlayEmoteExecutionStatusKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    FName WarmupLootAndShootExecutionStatusKeyName; // 0xac (Size: 0x4, Type: NameProperty)
    FName WarmupIdleExecutionStatusKeyName; // 0xb0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b4[0xc]; // 0xb4 (Size: 0xc, Type: PaddingProperty)
    UFortAthenaAIBotWarmupDigestedSkillSet* CacheWarmupDigestedSkillSet; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c8[0x10]; // 0xc8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Warmup) == 0xd8, "Size mismatch for UFortAthenaAIBotEvaluator_Warmup");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Warmup, WarmupPlayEmoteExecutionStatusKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_Warmup::WarmupPlayEmoteExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Warmup, WarmupLootAndShootExecutionStatusKeyName) == 0xac, "Offset mismatch for UFortAthenaAIBotEvaluator_Warmup::WarmupLootAndShootExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Warmup, WarmupIdleExecutionStatusKeyName) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_Warmup::WarmupIdleExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Warmup, CacheWarmupDigestedSkillSet) == 0xc0, "Offset mismatch for UFortAthenaAIBotEvaluator_Warmup::CacheWarmupDigestedSkillSet");

// Size: 0xe8 (Inherited: 0x170, Single: 0xffffff78)
class UFortAthenaAIBotEvaluator_WeaponSelection : public UFortAthenaAIBotEvaluator
{
public:
    FName ThrowableAttackIsReadyToThrowName; // 0xa8 (Size: 0x4, Type: NameProperty)
    FName WeaponKeyName; // 0xac (Size: 0x4, Type: NameProperty)
    FName TargetActorName; // 0xb0 (Size: 0x4, Type: NameProperty)
    FName IsManningTurretKeyName; // 0xb4 (Size: 0x4, Type: NameProperty)
    FName UseItemSelectNewWeaponKeyName; // 0xb8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_bc[0x14]; // 0xbc (Size: 0x14, Type: PaddingProperty)
    UFortAthenaAIBotRangeAttackDigestedSkillSet* CacheRangeAttackDigestedSkillSet; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingDigestedSkillSet; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0xe0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_WeaponSelection) == 0xe8, "Size mismatch for UFortAthenaAIBotEvaluator_WeaponSelection");
static_assert(offsetof(UFortAthenaAIBotEvaluator_WeaponSelection, ThrowableAttackIsReadyToThrowName) == 0xa8, "Offset mismatch for UFortAthenaAIBotEvaluator_WeaponSelection::ThrowableAttackIsReadyToThrowName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_WeaponSelection, WeaponKeyName) == 0xac, "Offset mismatch for UFortAthenaAIBotEvaluator_WeaponSelection::WeaponKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_WeaponSelection, TargetActorName) == 0xb0, "Offset mismatch for UFortAthenaAIBotEvaluator_WeaponSelection::TargetActorName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_WeaponSelection, IsManningTurretKeyName) == 0xb4, "Offset mismatch for UFortAthenaAIBotEvaluator_WeaponSelection::IsManningTurretKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_WeaponSelection, UseItemSelectNewWeaponKeyName) == 0xb8, "Offset mismatch for UFortAthenaAIBotEvaluator_WeaponSelection::UseItemSelectNewWeaponKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_WeaponSelection, CacheRangeAttackDigestedSkillSet) == 0xd0, "Offset mismatch for UFortAthenaAIBotEvaluator_WeaponSelection::CacheRangeAttackDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_WeaponSelection, CacheAttackingDigestedSkillSet) == 0xd8, "Offset mismatch for UFortAthenaAIBotEvaluator_WeaponSelection::CacheAttackingDigestedSkillSet");
static_assert(offsetof(UFortAthenaAIBotEvaluator_WeaponSelection, CacheAimingDigestedSkillSet) == 0xe0, "Offset mismatch for UFortAthenaAIBotEvaluator_WeaponSelection::CacheAimingDigestedSkillSet");

// Size: 0x250 (Inherited: 0x3f0, Single: 0xfffffe60)
class UFortAthenaAIBotEvaluator_Zipline : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName CurrentDestinationKeyName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName ZiplineTargetKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName LastZiplineUsedName; // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName ZiplineMoveExecutionStatusKeyName; // 0x1ac (Size: 0x4, Type: NameProperty)
    FName ZiplineEntryLocationKeyName; // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName ZiplineExitLocationKeyName; // 0x1b4 (Size: 0x4, Type: NameProperty)
    FName ZiplineLastUsageTimeName; // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName ZiplineUsageExecutionStatusName; // 0x1bc (Size: 0x4, Type: NameProperty)
    FScalableFloat WaitTimeBetweenZiplineRandomChoices; // 0x1c0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ProbabilityToUseZipline; // 0x1e8 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_210[0x40]; // 0x210 (Size: 0x40, Type: PaddingProperty)

protected:
    void OnZiplineStateChanged(bool& bIsZiplining, AFortPlayerPawn*& FortPlayerPawn); // 0xef98128 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortAthenaAIBotEvaluator_Zipline) == 0x250, "Size mismatch for UFortAthenaAIBotEvaluator_Zipline");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Zipline, CurrentDestinationKeyName) == 0x1a0, "Offset mismatch for UFortAthenaAIBotEvaluator_Zipline::CurrentDestinationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Zipline, ZiplineTargetKeyName) == 0x1a4, "Offset mismatch for UFortAthenaAIBotEvaluator_Zipline::ZiplineTargetKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Zipline, LastZiplineUsedName) == 0x1a8, "Offset mismatch for UFortAthenaAIBotEvaluator_Zipline::LastZiplineUsedName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Zipline, ZiplineMoveExecutionStatusKeyName) == 0x1ac, "Offset mismatch for UFortAthenaAIBotEvaluator_Zipline::ZiplineMoveExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Zipline, ZiplineEntryLocationKeyName) == 0x1b0, "Offset mismatch for UFortAthenaAIBotEvaluator_Zipline::ZiplineEntryLocationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Zipline, ZiplineExitLocationKeyName) == 0x1b4, "Offset mismatch for UFortAthenaAIBotEvaluator_Zipline::ZiplineExitLocationKeyName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Zipline, ZiplineLastUsageTimeName) == 0x1b8, "Offset mismatch for UFortAthenaAIBotEvaluator_Zipline::ZiplineLastUsageTimeName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Zipline, ZiplineUsageExecutionStatusName) == 0x1bc, "Offset mismatch for UFortAthenaAIBotEvaluator_Zipline::ZiplineUsageExecutionStatusName");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Zipline, WaitTimeBetweenZiplineRandomChoices) == 0x1c0, "Offset mismatch for UFortAthenaAIBotEvaluator_Zipline::WaitTimeBetweenZiplineRandomChoices");
static_assert(offsetof(UFortAthenaAIBotEvaluator_Zipline, ProbabilityToUseZipline) == 0x1e8, "Offset mismatch for UFortAthenaAIBotEvaluator_Zipline::ProbabilityToUseZipline");

// Size: 0x70 (Inherited: 0x60, Single: 0x10)
class UFortEvaluatorBlueprintBaseWorldConditionSchema : public UWorldConditionSchema
{
public:
};

static_assert(sizeof(UFortEvaluatorBlueprintBaseWorldConditionSchema) == 0x70, "Size mismatch for UFortEvaluatorBlueprintBaseWorldConditionSchema");

// Size: 0x318 (Inherited: 0x28, Single: 0x2f0)
class UFortAthenaAIEvaluator_BlueprintBase : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    bool bBlockWeaponActions; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bGameplayAbilityEvaluator; // 0x31 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x6]; // 0x32 (Size: 0x6, Type: PaddingProperty)
    FGameplayAbilityEvaluatorModule GameplayAbilityEvaluatorModule; // 0x38 (Size: 0x28, Type: StructProperty)
    bool bCooldownEvaluator; // 0x60 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_61[0x7]; // 0x61 (Size: 0x7, Type: PaddingProperty)
    TArray<FFortEvaluatorBlueprintBaseCooldown> Cooldowns; // 0x68 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat Cooldown; // 0x78 (Size: 0x28, Type: StructProperty)
    FScalableFloat CooldownVariation; // 0xa0 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<ECooldownType> CooldownType; // 0xc8 (Size: 0x1, Type: ByteProperty)
    bool bDistanceEvaluator; // 0xc9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ca[0x2]; // 0xca (Size: 0x2, Type: PaddingProperty)
    float StartDistance; // 0xcc (Size: 0x4, Type: FloatProperty)
    float OngoingDistance; // 0xd0 (Size: 0x4, Type: FloatProperty)
    FName DistanceTargetKeyName; // 0xd4 (Size: 0x4, Type: NameProperty)
    bool bDurationEvaluator; // 0xd8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d9[0x7]; // 0xd9 (Size: 0x7, Type: PaddingProperty)
    FScalableFloat duration; // 0xe0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DurationVariation; // 0x108 (Size: 0x28, Type: StructProperty)
    bool bTokenEvaluator; // 0x130 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_131[0x7]; // 0x131 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagQuery TokenQuery; // 0x138 (Size: 0x48, Type: StructProperty)
    FName TokenTargetKeyName; // 0x180 (Size: 0x4, Type: NameProperty)
    bool bWorldConditionEvaluator; // 0x184 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_185[0x3]; // 0x185 (Size: 0x3, Type: PaddingProperty)
    FWorldConditionQueryDefinition StartingWorldConditions; // 0x188 (Size: 0x18, Type: StructProperty)
    FWorldConditionQueryDefinition OngoingWorldConditions; // 0x1a0 (Size: 0x18, Type: StructProperty)
    FName StartingWorldConditionTargetKeyName; // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName OngoingWorldConditionTargetKeyName; // 0x1bc (Size: 0x4, Type: NameProperty)
    FScalableFloat Interval; // 0x1c0 (Size: 0x28, Type: StructProperty)
    FScalableFloat RandomVariation; // 0x1e8 (Size: 0x28, Type: StructProperty)
    FWorldConditionQueryState StartingQueryState; // 0x210 (Size: 0x30, Type: StructProperty)
    FWorldConditionQueryState OngoingQueryState; // 0x240 (Size: 0x30, Type: StructProperty)
    UFortAICombatTokenConsumerComponent* CachedTokenConsumerComponent; // 0x270 (Size: 0x8, Type: ObjectProperty)
    UBehaviorTreeComponent* CachedOwnerComponent; // 0x278 (Size: 0x8, Type: ObjectProperty)
    AAIController* CachedController; // 0x280 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_288[0x8]; // 0x288 (Size: 0x8, Type: PaddingProperty)
    bool bEvaluateOnBlackboardKeyChange; // 0x290 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_291[0x7]; // 0x291 (Size: 0x7, Type: PaddingProperty)
    TArray<FName> ListeningBlackboardKeyNames; // 0x298 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_2a8[0x70]; // 0x2a8 (Size: 0x70, Type: PaddingProperty)

public:
    void AllowExecution(); // 0xef97d58 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void DenyExecution(); // 0xef97d74 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    float GetCurrentWeight() const; // 0xef97da8 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetDefaultWeight() const; // 0xef97ddc (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EExecutionStatus GetExecutionStatus() const; // 0xef97e04 (Index: 0x8, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetWeight(float& const NewWeight); // 0xef98358 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void AddTimeout(float& const TimeoutLength, float& const TimeoutLengthVariation); // 0xef97b4c (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    virtual bool EvaluateOngoingConditions(UBehaviorTreeComponent*& OwnerComp); // 0xec61614 (Index: 0x3, Flags: Native|Event|Protected|BlueprintCallable|BlueprintEvent)
    virtual bool EvaluateStartingConditions(UBehaviorTreeComponent*& OwnerComp); // 0xa8be280 (Index: 0x4, Flags: Native|Event|Protected|BlueprintCallable|BlueprintEvent)
    AAIController* GetController() const; // 0xef97d90 (Index: 0x5, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    UBehaviorTreeComponent* GetOwner() const; // 0xef97e2c (Index: 0x9, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    AFortPawn* GetPawn() const; // 0xef97e44 (Index: 0xa, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    float GetTime(UBehaviorTreeComponent*& OwnerComp) const; // 0xef97ec4 (Index: 0xb, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnBlackboardKeyValueChanged(UBehaviorTreeComponent*& OwnerComp, FName& ChangedKeyName); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void OnConcurentBehaviorExecutionStatusChanged(UFortInjectedBehavior*& const InjectedBehavior, EExecutionStatus& const PreviousExecutionStatus, EExecutionStatus& const NewExecutionStatus); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void OnEnter(UBehaviorTreeComponent*& OwnerComp); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void OnExecutionStatusChanged(EExecutionStatus& const PreviousExecutionStatus, EExecutionStatus& const NewExecutionStatus); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void OnExit(UBehaviorTreeComponent*& OwnerComp); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void OnInstantiated(UBehaviorTreeComponent*& OwnerComp); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
    virtual void OnReleased(UBehaviorTreeComponent*& OwnerComp); // 0x288a61c (Index: 0x12, Flags: Event|Protected|BlueprintEvent)
    void RequestEvaluation() const; // 0xef98344 (Index: 0x13, Flags: Final|Native|Protected|BlueprintCallable|Const)
    virtual void TaskEvaluate(UBehaviorTreeComponent*& OwnerComp); // 0x288a61c (Index: 0x15, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortAthenaAIEvaluator_BlueprintBase) == 0x318, "Size mismatch for UFortAthenaAIEvaluator_BlueprintBase");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, bBlockWeaponActions) == 0x30, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::bBlockWeaponActions");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, bGameplayAbilityEvaluator) == 0x31, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::bGameplayAbilityEvaluator");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, GameplayAbilityEvaluatorModule) == 0x38, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::GameplayAbilityEvaluatorModule");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, bCooldownEvaluator) == 0x60, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::bCooldownEvaluator");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, Cooldowns) == 0x68, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::Cooldowns");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, Cooldown) == 0x78, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::Cooldown");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, CooldownVariation) == 0xa0, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::CooldownVariation");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, CooldownType) == 0xc8, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::CooldownType");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, bDistanceEvaluator) == 0xc9, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::bDistanceEvaluator");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, StartDistance) == 0xcc, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::StartDistance");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, OngoingDistance) == 0xd0, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::OngoingDistance");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, DistanceTargetKeyName) == 0xd4, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::DistanceTargetKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, bDurationEvaluator) == 0xd8, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::bDurationEvaluator");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, duration) == 0xe0, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::duration");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, DurationVariation) == 0x108, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::DurationVariation");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, bTokenEvaluator) == 0x130, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::bTokenEvaluator");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, TokenQuery) == 0x138, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::TokenQuery");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, TokenTargetKeyName) == 0x180, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::TokenTargetKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, bWorldConditionEvaluator) == 0x184, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::bWorldConditionEvaluator");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, StartingWorldConditions) == 0x188, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::StartingWorldConditions");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, OngoingWorldConditions) == 0x1a0, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::OngoingWorldConditions");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, StartingWorldConditionTargetKeyName) == 0x1b8, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::StartingWorldConditionTargetKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, OngoingWorldConditionTargetKeyName) == 0x1bc, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::OngoingWorldConditionTargetKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, Interval) == 0x1c0, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::Interval");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, RandomVariation) == 0x1e8, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::RandomVariation");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, StartingQueryState) == 0x210, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::StartingQueryState");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, OngoingQueryState) == 0x240, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::OngoingQueryState");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, CachedTokenConsumerComponent) == 0x270, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::CachedTokenConsumerComponent");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, CachedOwnerComponent) == 0x278, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::CachedOwnerComponent");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, CachedController) == 0x280, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::CachedController");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, bEvaluateOnBlackboardKeyChange) == 0x290, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::bEvaluateOnBlackboardKeyChange");
static_assert(offsetof(UFortAthenaAIEvaluator_BlueprintBase, ListeningBlackboardKeyNames) == 0x298, "Offset mismatch for UFortAthenaAIEvaluator_BlueprintBase::ListeningBlackboardKeyNames");

// Size: 0x148 (Inherited: 0xc8, Single: 0x80)
class UFortAthenaAIEvaluator_DormantUntilPhase : public UFortAthenaAIEvaluator
{
public:
    FScalableFloat bIsEnabled; // 0xa0 (Size: 0x28, Type: StructProperty)
    bool bDisabledInCreative; // 0xc8 (Size: 0x1, Type: BoolProperty)
    uint8_t RequiredGamePhaseStep; // 0xc9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_ca[0x6]; // 0xca (Size: 0x6, Type: PaddingProperty)
    FScalableFloat DelayAfterPhase; // 0xd0 (Size: 0x28, Type: StructProperty)
    FScalableFloat RandomDeviationAfterPhase; // 0xf8 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_120[0x28]; // 0x120 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIEvaluator_DormantUntilPhase) == 0x148, "Size mismatch for UFortAthenaAIEvaluator_DormantUntilPhase");
static_assert(offsetof(UFortAthenaAIEvaluator_DormantUntilPhase, bIsEnabled) == 0xa0, "Offset mismatch for UFortAthenaAIEvaluator_DormantUntilPhase::bIsEnabled");
static_assert(offsetof(UFortAthenaAIEvaluator_DormantUntilPhase, bDisabledInCreative) == 0xc8, "Offset mismatch for UFortAthenaAIEvaluator_DormantUntilPhase::bDisabledInCreative");
static_assert(offsetof(UFortAthenaAIEvaluator_DormantUntilPhase, RequiredGamePhaseStep) == 0xc9, "Offset mismatch for UFortAthenaAIEvaluator_DormantUntilPhase::RequiredGamePhaseStep");
static_assert(offsetof(UFortAthenaAIEvaluator_DormantUntilPhase, DelayAfterPhase) == 0xd0, "Offset mismatch for UFortAthenaAIEvaluator_DormantUntilPhase::DelayAfterPhase");
static_assert(offsetof(UFortAthenaAIEvaluator_DormantUntilPhase, RandomDeviationAfterPhase) == 0xf8, "Offset mismatch for UFortAthenaAIEvaluator_DormantUntilPhase::RandomDeviationAfterPhase");

// Size: 0xc8 (Inherited: 0xc8, Single: 0x0)
class UFortAthenaAIEvaluator_FleeEnvDanger : public UFortAthenaAIEvaluator
{
public:
    float MaximumCheckDistance; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float AdditionalFleeDistance; // 0xa4 (Size: 0x4, Type: FloatProperty)
    FName EnvironmentalDangerExecutionStatusName; // 0xa8 (Size: 0x4, Type: NameProperty)
    FName EnvironmentalDangerFleeDirectionFromKeyName; // 0xac (Size: 0x4, Type: NameProperty)
    FName EnvironmentalDangerFleeDirectionToKeyName; // 0xb0 (Size: 0x4, Type: NameProperty)
    FName EnvironmentalDangerFleeDistanceKeyName; // 0xb4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    AAIController* CachedController; // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIEvaluator_FleeEnvDanger) == 0xc8, "Size mismatch for UFortAthenaAIEvaluator_FleeEnvDanger");
static_assert(offsetof(UFortAthenaAIEvaluator_FleeEnvDanger, MaximumCheckDistance) == 0xa0, "Offset mismatch for UFortAthenaAIEvaluator_FleeEnvDanger::MaximumCheckDistance");
static_assert(offsetof(UFortAthenaAIEvaluator_FleeEnvDanger, AdditionalFleeDistance) == 0xa4, "Offset mismatch for UFortAthenaAIEvaluator_FleeEnvDanger::AdditionalFleeDistance");
static_assert(offsetof(UFortAthenaAIEvaluator_FleeEnvDanger, EnvironmentalDangerExecutionStatusName) == 0xa8, "Offset mismatch for UFortAthenaAIEvaluator_FleeEnvDanger::EnvironmentalDangerExecutionStatusName");
static_assert(offsetof(UFortAthenaAIEvaluator_FleeEnvDanger, EnvironmentalDangerFleeDirectionFromKeyName) == 0xac, "Offset mismatch for UFortAthenaAIEvaluator_FleeEnvDanger::EnvironmentalDangerFleeDirectionFromKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_FleeEnvDanger, EnvironmentalDangerFleeDirectionToKeyName) == 0xb0, "Offset mismatch for UFortAthenaAIEvaluator_FleeEnvDanger::EnvironmentalDangerFleeDirectionToKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_FleeEnvDanger, EnvironmentalDangerFleeDistanceKeyName) == 0xb4, "Offset mismatch for UFortAthenaAIEvaluator_FleeEnvDanger::EnvironmentalDangerFleeDistanceKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_FleeEnvDanger, CachedController) == 0xc0, "Offset mismatch for UFortAthenaAIEvaluator_FleeEnvDanger::CachedController");

// Size: 0x1d8 (Inherited: 0x3f0, Single: 0xfffffde8)
class UFortAthenaAIEvaluator_FollowGroupLeader : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FValueOrBBKey_Bool bBotsSkipSafeToReachLocationCheck; // 0x1a0 (Size: 0xc, Type: StructProperty)
    FName FollowGroupLeaderStatusKeyName; // 0x1ac (Size: 0x4, Type: NameProperty)
    FName FollowGroupLeaderMovementStateKeyName; // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName FollowGroupLeaderDestinationKeyName; // 0x1b4 (Size: 0x4, Type: NameProperty)
    FName TooFarFromLeaderKeyName; // 0x1b8 (Size: 0x4, Type: NameProperty)
    FName HasLeaderToFollowKeyName; // 0x1bc (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c0[0x18]; // 0x1c0 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIEvaluator_FollowGroupLeader) == 0x1d8, "Size mismatch for UFortAthenaAIEvaluator_FollowGroupLeader");
static_assert(offsetof(UFortAthenaAIEvaluator_FollowGroupLeader, bBotsSkipSafeToReachLocationCheck) == 0x1a0, "Offset mismatch for UFortAthenaAIEvaluator_FollowGroupLeader::bBotsSkipSafeToReachLocationCheck");
static_assert(offsetof(UFortAthenaAIEvaluator_FollowGroupLeader, FollowGroupLeaderStatusKeyName) == 0x1ac, "Offset mismatch for UFortAthenaAIEvaluator_FollowGroupLeader::FollowGroupLeaderStatusKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_FollowGroupLeader, FollowGroupLeaderMovementStateKeyName) == 0x1b0, "Offset mismatch for UFortAthenaAIEvaluator_FollowGroupLeader::FollowGroupLeaderMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_FollowGroupLeader, FollowGroupLeaderDestinationKeyName) == 0x1b4, "Offset mismatch for UFortAthenaAIEvaluator_FollowGroupLeader::FollowGroupLeaderDestinationKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_FollowGroupLeader, TooFarFromLeaderKeyName) == 0x1b8, "Offset mismatch for UFortAthenaAIEvaluator_FollowGroupLeader::TooFarFromLeaderKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_FollowGroupLeader, HasLeaderToFollowKeyName) == 0x1bc, "Offset mismatch for UFortAthenaAIEvaluator_FollowGroupLeader::HasLeaderToFollowKeyName");

// Size: 0xc8 (Inherited: 0xc8, Single: 0x0)
class UFortAthenaAIEvaluator_Leash : public UFortAthenaAIEvaluator
{
public:
    FName GoalIsInsideLeashKeyName; // 0xa0 (Size: 0x4, Type: NameProperty)
    FName AIIsInsideLeashKeyName; // 0xa4 (Size: 0x4, Type: NameProperty)
    FName LeashCenterLocationKeyName; // 0xa8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_ac[0xc]; // 0xac (Size: 0xc, Type: PaddingProperty)
    UFortAthenaLeashComponent* CachedLeashComponent; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UFortAIGoalComponent* CachedAIGoalComponent; // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIEvaluator_Leash) == 0xc8, "Size mismatch for UFortAthenaAIEvaluator_Leash");
static_assert(offsetof(UFortAthenaAIEvaluator_Leash, GoalIsInsideLeashKeyName) == 0xa0, "Offset mismatch for UFortAthenaAIEvaluator_Leash::GoalIsInsideLeashKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_Leash, AIIsInsideLeashKeyName) == 0xa4, "Offset mismatch for UFortAthenaAIEvaluator_Leash::AIIsInsideLeashKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_Leash, LeashCenterLocationKeyName) == 0xa8, "Offset mismatch for UFortAthenaAIEvaluator_Leash::LeashCenterLocationKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_Leash, CachedLeashComponent) == 0xb8, "Offset mismatch for UFortAthenaAIEvaluator_Leash::CachedLeashComponent");
static_assert(offsetof(UFortAthenaAIEvaluator_Leash, CachedAIGoalComponent) == 0xc0, "Offset mismatch for UFortAthenaAIEvaluator_Leash::CachedAIGoalComponent");

// Size: 0x240 (Inherited: 0xc8, Single: 0x178)
class UFortAthenaAIEvaluator_NearbyActorsPerception : public UFortAthenaAIEvaluator
{
public:
    FName FoundNearbyActorKeyName; // 0xa0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_a4[0x4]; // 0xa4 (Size: 0x4, Type: PaddingProperty)
    FScalableFloat MinimumUpdateInterval; // 0xa8 (Size: 0x28, Type: StructProperty)
    int32_t RequiredTypes; // 0xd0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
    FScalableFloat MinimumDistanceToActors; // 0xd8 (Size: 0x28, Type: StructProperty)
    TArray<TEnumAsByte<ETeamAttitude>> RequiredAttitudes; // 0x100 (Size: 0x10, Type: ArrayProperty)
    bool bRequireLoS; // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_111[0x7]; // 0x111 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagQuery RequiredTagsQuery; // 0x118 (Size: 0x48, Type: StructProperty)
    uint8_t Pad_160[0xe0]; // 0x160 (Size: 0xe0, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIEvaluator_NearbyActorsPerception) == 0x240, "Size mismatch for UFortAthenaAIEvaluator_NearbyActorsPerception");
static_assert(offsetof(UFortAthenaAIEvaluator_NearbyActorsPerception, FoundNearbyActorKeyName) == 0xa0, "Offset mismatch for UFortAthenaAIEvaluator_NearbyActorsPerception::FoundNearbyActorKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_NearbyActorsPerception, MinimumUpdateInterval) == 0xa8, "Offset mismatch for UFortAthenaAIEvaluator_NearbyActorsPerception::MinimumUpdateInterval");
static_assert(offsetof(UFortAthenaAIEvaluator_NearbyActorsPerception, RequiredTypes) == 0xd0, "Offset mismatch for UFortAthenaAIEvaluator_NearbyActorsPerception::RequiredTypes");
static_assert(offsetof(UFortAthenaAIEvaluator_NearbyActorsPerception, MinimumDistanceToActors) == 0xd8, "Offset mismatch for UFortAthenaAIEvaluator_NearbyActorsPerception::MinimumDistanceToActors");
static_assert(offsetof(UFortAthenaAIEvaluator_NearbyActorsPerception, RequiredAttitudes) == 0x100, "Offset mismatch for UFortAthenaAIEvaluator_NearbyActorsPerception::RequiredAttitudes");
static_assert(offsetof(UFortAthenaAIEvaluator_NearbyActorsPerception, bRequireLoS) == 0x110, "Offset mismatch for UFortAthenaAIEvaluator_NearbyActorsPerception::bRequireLoS");
static_assert(offsetof(UFortAthenaAIEvaluator_NearbyActorsPerception, RequiredTagsQuery) == 0x118, "Offset mismatch for UFortAthenaAIEvaluator_NearbyActorsPerception::RequiredTagsQuery");

// Size: 0x188 (Inherited: 0xc8, Single: 0xc0)
class UFortAthenaAIEvaluator_SmartObjects : public UFortAthenaAIEvaluator
{
public:
    UFortAthenaAIRuntimeParameters_SmartObjectBase* SmartObjectRuntimeParameters; // 0xa0 (Size: 0x8, Type: ObjectProperty)
    USmartObjectSubsystem* SmartObjectSubsystem; // 0xa8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_b0[0x8]; // 0xb0 (Size: 0x8, Type: PaddingProperty)
    FGameplayTag EvaluationTag; // 0xb8 (Size: 0x4, Type: StructProperty)
    bool bEvaluateSOValidityAfterChosen; // 0xbc (Size: 0x1, Type: BoolProperty)
    bool bEnableEntryLocationsSupport; // 0xbd (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_be[0x2]; // 0xbe (Size: 0x2, Type: PaddingProperty)
    FScalableFloat MaximumEntryLocationsChecksPerEvaluation; // 0xc0 (Size: 0x28, Type: StructProperty)
    FScalableFloat EntryLocationFailuresBlacklistedTime; // 0xe8 (Size: 0x28, Type: StructProperty)
    UCurveFloat* DistanceToWeightCurveForSlotPicking; // 0x110 (Size: 0x8, Type: ObjectProperty)
    UClass* OverridenFilterClassForEntryPoints; // 0x118 (Size: 0x8, Type: ClassProperty)
    TArray<FName> ExecutionStatusesToCheckForAllowToAvoidGoingToSOKeyNames; // 0x120 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_130[0x10]; // 0x130 (Size: 0x10, Type: PaddingProperty)
    FName SmartObjectExecutionStatusKeyName; // 0x140 (Size: 0x4, Type: NameProperty)
    FName SmartObjectMovementStateKeyName; // 0x144 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationKeyName; // 0x148 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationRotationKeyName; // 0x14c (Size: 0x4, Type: NameProperty)
    FName SmartObjectShouldMoveKeyName; // 0x150 (Size: 0x4, Type: NameProperty)
    FName SmartObjectUrgencyKeyName; // 0x154 (Size: 0x4, Type: NameProperty)
    FGameplayTagContainer ForceDebugClosestSOTagsToRemoveOnPawn; // 0x158 (Size: 0x20, Type: StructProperty)
    bool bFirstTimeRunForceDebugClosestSO; // 0x178 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_179[0xf]; // 0x179 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAIEvaluator_SmartObjects) == 0x188, "Size mismatch for UFortAthenaAIEvaluator_SmartObjects");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, SmartObjectRuntimeParameters) == 0xa0, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::SmartObjectRuntimeParameters");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, SmartObjectSubsystem) == 0xa8, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::SmartObjectSubsystem");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, EvaluationTag) == 0xb8, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::EvaluationTag");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, bEvaluateSOValidityAfterChosen) == 0xbc, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::bEvaluateSOValidityAfterChosen");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, bEnableEntryLocationsSupport) == 0xbd, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::bEnableEntryLocationsSupport");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, MaximumEntryLocationsChecksPerEvaluation) == 0xc0, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::MaximumEntryLocationsChecksPerEvaluation");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, EntryLocationFailuresBlacklistedTime) == 0xe8, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::EntryLocationFailuresBlacklistedTime");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, DistanceToWeightCurveForSlotPicking) == 0x110, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::DistanceToWeightCurveForSlotPicking");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, OverridenFilterClassForEntryPoints) == 0x118, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::OverridenFilterClassForEntryPoints");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, ExecutionStatusesToCheckForAllowToAvoidGoingToSOKeyNames) == 0x120, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::ExecutionStatusesToCheckForAllowToAvoidGoingToSOKeyNames");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, SmartObjectExecutionStatusKeyName) == 0x140, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::SmartObjectExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, SmartObjectMovementStateKeyName) == 0x144, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::SmartObjectMovementStateKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, SmartObjectDestinationKeyName) == 0x148, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::SmartObjectDestinationKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, SmartObjectDestinationRotationKeyName) == 0x14c, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::SmartObjectDestinationRotationKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, SmartObjectShouldMoveKeyName) == 0x150, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::SmartObjectShouldMoveKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, SmartObjectUrgencyKeyName) == 0x154, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::SmartObjectUrgencyKeyName");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, ForceDebugClosestSOTagsToRemoveOnPawn) == 0x158, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::ForceDebugClosestSOTagsToRemoveOnPawn");
static_assert(offsetof(UFortAthenaAIEvaluator_SmartObjects, bFirstTimeRunForceDebugClosestSO) == 0x178, "Offset mismatch for UFortAthenaAIEvaluator_SmartObjects::bFirstTimeRunForceDebugClosestSO");

// Size: 0x240 (Inherited: 0x308, Single: 0xffffff38)
class UFortAthenaAIEvaluator_SpeechBubble : public UFortAthenaAIEvaluator_NearbyActorsPerception
{
public:
    UFortPawnComponent_SpeechBubble* CachedSpeechBubbleComponent; // 0x238 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaAIEvaluator_SpeechBubble) == 0x240, "Size mismatch for UFortAthenaAIEvaluator_SpeechBubble");
static_assert(offsetof(UFortAthenaAIEvaluator_SpeechBubble, CachedSpeechBubbleComponent) == 0x238, "Offset mismatch for UFortAthenaAIEvaluator_SpeechBubble::CachedSpeechBubbleComponent");

// Size: 0x80 (Inherited: 0x1d0, Single: 0xfffffeb0)
class UFortAthenaBTContext_SuppressAutomaticAttackCheck : public UFortBTService_ContextOverride
{
public:
};

static_assert(sizeof(UFortAthenaBTContext_SuppressAutomaticAttackCheck) == 0x80, "Size mismatch for UFortAthenaBTContext_SuppressAutomaticAttackCheck");

// Size: 0xa8 (Inherited: 0x150, Single: 0xffffff58)
class UFortAthenaBTService_AgentOffNavigationData : public UBTService
{
public:
    FName AgentIsOffNavigationDataKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    bool bEvaluateOnTick; // 0x74 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_75[0x3]; // 0x75 (Size: 0x3, Type: PaddingProperty)
    FScalableFloat TickInterval; // 0x78 (Size: 0x28, Type: StructProperty)
    bool bEvaluateOnMoveRequestFinished; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0x7]; // 0xa1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_AgentOffNavigationData) == 0xa8, "Size mismatch for UFortAthenaBTService_AgentOffNavigationData");
static_assert(offsetof(UFortAthenaBTService_AgentOffNavigationData, AgentIsOffNavigationDataKeyName) == 0x70, "Offset mismatch for UFortAthenaBTService_AgentOffNavigationData::AgentIsOffNavigationDataKeyName");
static_assert(offsetof(UFortAthenaBTService_AgentOffNavigationData, bEvaluateOnTick) == 0x74, "Offset mismatch for UFortAthenaBTService_AgentOffNavigationData::bEvaluateOnTick");
static_assert(offsetof(UFortAthenaBTService_AgentOffNavigationData, TickInterval) == 0x78, "Offset mismatch for UFortAthenaBTService_AgentOffNavigationData::TickInterval");
static_assert(offsetof(UFortAthenaBTService_AgentOffNavigationData, bEvaluateOnMoveRequestFinished) == 0xa0, "Offset mismatch for UFortAthenaBTService_AgentOffNavigationData::bEvaluateOnMoveRequestFinished");

// Size: 0x90 (Inherited: 0x150, Single: 0xffffff40)
class UFortAthenaBTService_AIEvaluator : public UBTService
{
public:
    FGameplayTag InjectionTag; // 0x70 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FValueOrBBKey_Class AIEvaluatorClass; // 0x78 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UFortAthenaBTService_AIEvaluator) == 0x90, "Size mismatch for UFortAthenaBTService_AIEvaluator");
static_assert(offsetof(UFortAthenaBTService_AIEvaluator, InjectionTag) == 0x70, "Offset mismatch for UFortAthenaBTService_AIEvaluator::InjectionTag");
static_assert(offsetof(UFortAthenaBTService_AIEvaluator, AIEvaluatorClass) == 0x78, "Offset mismatch for UFortAthenaBTService_AIEvaluator::AIEvaluatorClass");

// Size: 0x98 (Inherited: 0x150, Single: 0xffffff48)
class UFortAthenaBTService_ApplyGameplayEffect : public UBTService
{
public:
    FValueOrBBKey_Class GameplayEffectClass; // 0x70 (Size: 0x18, Type: StructProperty)
    FValueOrBBKey_Float GameplayEffectLevel; // 0x88 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_ApplyGameplayEffect) == 0x98, "Size mismatch for UFortAthenaBTService_ApplyGameplayEffect");
static_assert(offsetof(UFortAthenaBTService_ApplyGameplayEffect, GameplayEffectClass) == 0x70, "Offset mismatch for UFortAthenaBTService_ApplyGameplayEffect::GameplayEffectClass");
static_assert(offsetof(UFortAthenaBTService_ApplyGameplayEffect, GameplayEffectLevel) == 0x88, "Offset mismatch for UFortAthenaBTService_ApplyGameplayEffect::GameplayEffectLevel");

// Size: 0xb0 (Inherited: 0x150, Single: 0xffffff60)
class UFortAthenaBTService_ApplyGameplayTags : public UBTService
{
public:
    FValueOrBBKey_GameplayTagContainer GameplayTagsToApply; // 0x70 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Bool bReplicateTags; // 0x98 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool RemoveTagsOnCeaseRelevant; // 0xa4 (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(UFortAthenaBTService_ApplyGameplayTags) == 0xb0, "Size mismatch for UFortAthenaBTService_ApplyGameplayTags");
static_assert(offsetof(UFortAthenaBTService_ApplyGameplayTags, GameplayTagsToApply) == 0x70, "Offset mismatch for UFortAthenaBTService_ApplyGameplayTags::GameplayTagsToApply");
static_assert(offsetof(UFortAthenaBTService_ApplyGameplayTags, bReplicateTags) == 0x98, "Offset mismatch for UFortAthenaBTService_ApplyGameplayTags::bReplicateTags");
static_assert(offsetof(UFortAthenaBTService_ApplyGameplayTags, RemoveTagsOnCeaseRelevant) == 0xa4, "Offset mismatch for UFortAthenaBTService_ApplyGameplayTags::RemoveTagsOnCeaseRelevant");

// Size: 0x70 (Inherited: 0x150, Single: 0xffffff20)
class UFortAthenaBTService_ApplyPatrolTags : public UBTService
{
public:
};

static_assert(sizeof(UFortAthenaBTService_ApplyPatrolTags) == 0x70, "Size mismatch for UFortAthenaBTService_ApplyPatrolTags");

// Size: 0x88 (Inherited: 0x150, Single: 0xffffff38)
class UFortAthenaBTService_BuildConstruction : public UBTService
{
public:
    FName StealWallBuildName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName StealWallBuildTypeName; // 0x74 (Size: 0x4, Type: NameProperty)
    FName StealWallBuildGridCoordName; // 0x78 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_7c[0xc]; // 0x7c (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_BuildConstruction) == 0x88, "Size mismatch for UFortAthenaBTService_BuildConstruction");
static_assert(offsetof(UFortAthenaBTService_BuildConstruction, StealWallBuildName) == 0x70, "Offset mismatch for UFortAthenaBTService_BuildConstruction::StealWallBuildName");
static_assert(offsetof(UFortAthenaBTService_BuildConstruction, StealWallBuildTypeName) == 0x74, "Offset mismatch for UFortAthenaBTService_BuildConstruction::StealWallBuildTypeName");
static_assert(offsetof(UFortAthenaBTService_BuildConstruction, StealWallBuildGridCoordName) == 0x78, "Offset mismatch for UFortAthenaBTService_BuildConstruction::StealWallBuildGridCoordName");

// Size: 0xa8 (Inherited: 0x150, Single: 0xffffff58)
class UFortAthenaBTService_Clamber : public UBTService
{
public:
    FName ClamberExecutionStatusName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName ClamberOriginLocationName; // 0x74 (Size: 0x4, Type: NameProperty)
    FName ClamberDestinationLocationName; // 0x78 (Size: 0x4, Type: NameProperty)
    FName ClamberAbilityStatusName; // 0x7c (Size: 0x4, Type: NameProperty)
    FName JumpExecutionStatusName; // 0x80 (Size: 0x4, Type: NameProperty)
    FName CrouchExecutionStatusName; // 0x84 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_88[0xc]; // 0x88 (Size: 0xc, Type: PaddingProperty)
    uint32_t FirstJumpRetryMaxCount; // 0x94 (Size: 0x4, Type: UInt32Property)
    uint32_t ClamberAttemptRetryMaxCount; // 0x98 (Size: 0x4, Type: UInt32Property)
    float FirstJumpRetryDelay; // 0x9c (Size: 0x4, Type: FloatProperty)
    float FirstJumpClamberMaxStartDelay; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float ClamberRetryDelay; // 0xa4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UFortAthenaBTService_Clamber) == 0xa8, "Size mismatch for UFortAthenaBTService_Clamber");
static_assert(offsetof(UFortAthenaBTService_Clamber, ClamberExecutionStatusName) == 0x70, "Offset mismatch for UFortAthenaBTService_Clamber::ClamberExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_Clamber, ClamberOriginLocationName) == 0x74, "Offset mismatch for UFortAthenaBTService_Clamber::ClamberOriginLocationName");
static_assert(offsetof(UFortAthenaBTService_Clamber, ClamberDestinationLocationName) == 0x78, "Offset mismatch for UFortAthenaBTService_Clamber::ClamberDestinationLocationName");
static_assert(offsetof(UFortAthenaBTService_Clamber, ClamberAbilityStatusName) == 0x7c, "Offset mismatch for UFortAthenaBTService_Clamber::ClamberAbilityStatusName");
static_assert(offsetof(UFortAthenaBTService_Clamber, JumpExecutionStatusName) == 0x80, "Offset mismatch for UFortAthenaBTService_Clamber::JumpExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_Clamber, CrouchExecutionStatusName) == 0x84, "Offset mismatch for UFortAthenaBTService_Clamber::CrouchExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_Clamber, FirstJumpRetryMaxCount) == 0x94, "Offset mismatch for UFortAthenaBTService_Clamber::FirstJumpRetryMaxCount");
static_assert(offsetof(UFortAthenaBTService_Clamber, ClamberAttemptRetryMaxCount) == 0x98, "Offset mismatch for UFortAthenaBTService_Clamber::ClamberAttemptRetryMaxCount");
static_assert(offsetof(UFortAthenaBTService_Clamber, FirstJumpRetryDelay) == 0x9c, "Offset mismatch for UFortAthenaBTService_Clamber::FirstJumpRetryDelay");
static_assert(offsetof(UFortAthenaBTService_Clamber, FirstJumpClamberMaxStartDelay) == 0xa0, "Offset mismatch for UFortAthenaBTService_Clamber::FirstJumpClamberMaxStartDelay");
static_assert(offsetof(UFortAthenaBTService_Clamber, ClamberRetryDelay) == 0xa4, "Offset mismatch for UFortAthenaBTService_Clamber::ClamberRetryDelay");

// Size: 0xe8 (Inherited: 0x150, Single: 0xffffff98)
class UFortAthenaBTService_CopyActorLocation : public UBTService
{
public:
    FBlackboardKeySelector SourceBlackboardKey; // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector DestinationBlackboardKey; // 0x98 (Size: 0x28, Type: StructProperty)
    FValueOrBBKey_Bool bCopyOnBecomeRelevant; // 0xc0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bCopyOnCeaseRelevant; // 0xcc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool bCopyWhenSourceValueChange; // 0xd8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_e4[0x4]; // 0xe4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_CopyActorLocation) == 0xe8, "Size mismatch for UFortAthenaBTService_CopyActorLocation");
static_assert(offsetof(UFortAthenaBTService_CopyActorLocation, SourceBlackboardKey) == 0x70, "Offset mismatch for UFortAthenaBTService_CopyActorLocation::SourceBlackboardKey");
static_assert(offsetof(UFortAthenaBTService_CopyActorLocation, DestinationBlackboardKey) == 0x98, "Offset mismatch for UFortAthenaBTService_CopyActorLocation::DestinationBlackboardKey");
static_assert(offsetof(UFortAthenaBTService_CopyActorLocation, bCopyOnBecomeRelevant) == 0xc0, "Offset mismatch for UFortAthenaBTService_CopyActorLocation::bCopyOnBecomeRelevant");
static_assert(offsetof(UFortAthenaBTService_CopyActorLocation, bCopyOnCeaseRelevant) == 0xcc, "Offset mismatch for UFortAthenaBTService_CopyActorLocation::bCopyOnCeaseRelevant");
static_assert(offsetof(UFortAthenaBTService_CopyActorLocation, bCopyWhenSourceValueChange) == 0xd8, "Offset mismatch for UFortAthenaBTService_CopyActorLocation::bCopyWhenSourceValueChange");

// Size: 0xc8 (Inherited: 0x150, Single: 0xffffff78)
class UFortAthenaBTService_CopyBlackboardVariable : public UBTService
{
public:
    FBlackboardKeySelector SourceBlackboardKey; // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector DestinationBlackboardKey; // 0x98 (Size: 0x28, Type: StructProperty)
    uint8_t bCopyOnBecomeRelevant : 1; // 0xc0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bCopyOnCeaseRelevant : 1; // 0xc0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bCopyWhenSourceValueChange : 1; // 0xc0:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0x7]; // 0xc1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_CopyBlackboardVariable) == 0xc8, "Size mismatch for UFortAthenaBTService_CopyBlackboardVariable");
static_assert(offsetof(UFortAthenaBTService_CopyBlackboardVariable, SourceBlackboardKey) == 0x70, "Offset mismatch for UFortAthenaBTService_CopyBlackboardVariable::SourceBlackboardKey");
static_assert(offsetof(UFortAthenaBTService_CopyBlackboardVariable, DestinationBlackboardKey) == 0x98, "Offset mismatch for UFortAthenaBTService_CopyBlackboardVariable::DestinationBlackboardKey");
static_assert(offsetof(UFortAthenaBTService_CopyBlackboardVariable, bCopyOnBecomeRelevant) == 0xc0, "Offset mismatch for UFortAthenaBTService_CopyBlackboardVariable::bCopyOnBecomeRelevant");
static_assert(offsetof(UFortAthenaBTService_CopyBlackboardVariable, bCopyOnCeaseRelevant) == 0xc0, "Offset mismatch for UFortAthenaBTService_CopyBlackboardVariable::bCopyOnCeaseRelevant");
static_assert(offsetof(UFortAthenaBTService_CopyBlackboardVariable, bCopyWhenSourceValueChange) == 0xc0, "Offset mismatch for UFortAthenaBTService_CopyBlackboardVariable::bCopyWhenSourceValueChange");

// Size: 0x78 (Inherited: 0x150, Single: 0xffffff28)
class UFortAthenaBTService_Crouch : public UBTService
{
public:
    FName CrouchExecutionStatusName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_Crouch) == 0x78, "Size mismatch for UFortAthenaBTService_Crouch");
static_assert(offsetof(UFortAthenaBTService_Crouch, CrouchExecutionStatusName) == 0x70, "Offset mismatch for UFortAthenaBTService_Crouch::CrouchExecutionStatusName");

// Size: 0x80 (Inherited: 0x150, Single: 0xffffff30)
class UFortAthenaBTService_Escape : public UBTService
{
public:
    FName EscapeKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FName EscapeFromStormKeyName; // 0x78 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_Escape) == 0x80, "Size mismatch for UFortAthenaBTService_Escape");
static_assert(offsetof(UFortAthenaBTService_Escape, EscapeKeyName) == 0x70, "Offset mismatch for UFortAthenaBTService_Escape::EscapeKeyName");
static_assert(offsetof(UFortAthenaBTService_Escape, EscapeFromStormKeyName) == 0x78, "Offset mismatch for UFortAthenaBTService_Escape::EscapeFromStormKeyName");

// Size: 0xf8 (Inherited: 0x150, Single: 0xffffffa8)
class UFortAthenaBTService_HeightMap : public UBTService
{
public:
    FName HeightMapAverageFloorHeightKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FScalableFloat AverageFloorHeightRadius; // 0x78 (Size: 0x28, Type: StructProperty)
    FScalableFloat AverageFloorHeightHeight; // 0xa0 (Size: 0x28, Type: StructProperty)
    FScalableFloat AverageFloorHeightUseLowResolution; // 0xc8 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_f0[0x8]; // 0xf0 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_HeightMap) == 0xf8, "Size mismatch for UFortAthenaBTService_HeightMap");
static_assert(offsetof(UFortAthenaBTService_HeightMap, HeightMapAverageFloorHeightKeyName) == 0x70, "Offset mismatch for UFortAthenaBTService_HeightMap::HeightMapAverageFloorHeightKeyName");
static_assert(offsetof(UFortAthenaBTService_HeightMap, AverageFloorHeightRadius) == 0x78, "Offset mismatch for UFortAthenaBTService_HeightMap::AverageFloorHeightRadius");
static_assert(offsetof(UFortAthenaBTService_HeightMap, AverageFloorHeightHeight) == 0xa0, "Offset mismatch for UFortAthenaBTService_HeightMap::AverageFloorHeightHeight");
static_assert(offsetof(UFortAthenaBTService_HeightMap, AverageFloorHeightUseLowResolution) == 0xc8, "Offset mismatch for UFortAthenaBTService_HeightMap::AverageFloorHeightUseLowResolution");

// Size: 0x140 (Inherited: 0x150, Single: 0xfffffff0)
class UFortAthenaBTService_Interact : public UBTService
{
public:
    FBlackboardKeySelector InteractExecutionStatusKeySelector; // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector InteractContextInfoKeySelector; // 0x98 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector InteractObjectKeySelector; // 0xc0 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector ExecutionStatusKeySelector; // 0xe8 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector MovementStateKeySelector; // 0x110 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<EInteractionBeingAttempted> InteractionBeingAttempted; // 0x138 (Size: 0x1, Type: ByteProperty)
    bool bRequireDistanceCheck; // 0x139 (Size: 0x1, Type: BoolProperty)
    bool bRequireBlockedCheck; // 0x13a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_13b[0x5]; // 0x13b (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_Interact) == 0x140, "Size mismatch for UFortAthenaBTService_Interact");
static_assert(offsetof(UFortAthenaBTService_Interact, InteractExecutionStatusKeySelector) == 0x70, "Offset mismatch for UFortAthenaBTService_Interact::InteractExecutionStatusKeySelector");
static_assert(offsetof(UFortAthenaBTService_Interact, InteractContextInfoKeySelector) == 0x98, "Offset mismatch for UFortAthenaBTService_Interact::InteractContextInfoKeySelector");
static_assert(offsetof(UFortAthenaBTService_Interact, InteractObjectKeySelector) == 0xc0, "Offset mismatch for UFortAthenaBTService_Interact::InteractObjectKeySelector");
static_assert(offsetof(UFortAthenaBTService_Interact, ExecutionStatusKeySelector) == 0xe8, "Offset mismatch for UFortAthenaBTService_Interact::ExecutionStatusKeySelector");
static_assert(offsetof(UFortAthenaBTService_Interact, MovementStateKeySelector) == 0x110, "Offset mismatch for UFortAthenaBTService_Interact::MovementStateKeySelector");
static_assert(offsetof(UFortAthenaBTService_Interact, InteractionBeingAttempted) == 0x138, "Offset mismatch for UFortAthenaBTService_Interact::InteractionBeingAttempted");
static_assert(offsetof(UFortAthenaBTService_Interact, bRequireDistanceCheck) == 0x139, "Offset mismatch for UFortAthenaBTService_Interact::bRequireDistanceCheck");
static_assert(offsetof(UFortAthenaBTService_Interact, bRequireBlockedCheck) == 0x13a, "Offset mismatch for UFortAthenaBTService_Interact::bRequireBlockedCheck");

// Size: 0x98 (Inherited: 0x1d8, Single: 0xfffffec0)
class UFortAthenaBTService_JetpackStrafe : public UFortAthenaBTService_Jump
{
public:
    FName JetpackStrafeExecutionStatusName; // 0x88 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
    UFortAthenaAIBotEvasiveManeuversDigestedSkillSet* CacheEMDigestedSkillSet; // 0x90 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaBTService_JetpackStrafe) == 0x98, "Size mismatch for UFortAthenaBTService_JetpackStrafe");
static_assert(offsetof(UFortAthenaBTService_JetpackStrafe, JetpackStrafeExecutionStatusName) == 0x88, "Offset mismatch for UFortAthenaBTService_JetpackStrafe::JetpackStrafeExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_JetpackStrafe, CacheEMDigestedSkillSet) == 0x90, "Offset mismatch for UFortAthenaBTService_JetpackStrafe::CacheEMDigestedSkillSet");

// Size: 0x88 (Inherited: 0x150, Single: 0xffffff38)
class UFortAthenaBTService_Jump : public UBTService
{
public:
    FName JumpExecutionStatusName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FName CrouchExecutionStatusName; // 0x78 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
    float JumpInputReleaseDelay; // 0x80 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_Jump) == 0x88, "Size mismatch for UFortAthenaBTService_Jump");
static_assert(offsetof(UFortAthenaBTService_Jump, JumpExecutionStatusName) == 0x70, "Offset mismatch for UFortAthenaBTService_Jump::JumpExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_Jump, CrouchExecutionStatusName) == 0x78, "Offset mismatch for UFortAthenaBTService_Jump::CrouchExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_Jump, JumpInputReleaseDelay) == 0x80, "Offset mismatch for UFortAthenaBTService_Jump::JumpInputReleaseDelay");

// Size: 0x78 (Inherited: 0x150, Single: 0xffffff28)
class UFortAthenaBTService_JumpOffBus : public UBTService
{
public:
    FName JumpOffBusExecutionStatusName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_JumpOffBus) == 0x78, "Size mismatch for UFortAthenaBTService_JumpOffBus");
static_assert(offsetof(UFortAthenaBTService_JumpOffBus, JumpOffBusExecutionStatusName) == 0x70, "Offset mismatch for UFortAthenaBTService_JumpOffBus::JumpOffBusExecutionStatusName");

// Size: 0xc8 (Inherited: 0x218, Single: 0xfffffeb0)
class UFortAthenaBTService_ManageVehicleWeapon : public UFortAthenaBTService_ManageWeapon
{
public:
};

static_assert(sizeof(UFortAthenaBTService_ManageVehicleWeapon) == 0xc8, "Size mismatch for UFortAthenaBTService_ManageVehicleWeapon");

// Size: 0xc8 (Inherited: 0x150, Single: 0xffffff78)
class UFortAthenaBTService_ManageWeapon : public UBTService
{
public:
    FName WeaponFireName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerMeleeName; // 0x74 (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerThrowableName; // 0x78 (Size: 0x4, Type: NameProperty)
    FName WeaponReloadName; // 0x7c (Size: 0x4, Type: NameProperty)
    FName WeaponName; // 0x80 (Size: 0x4, Type: NameProperty)
    FName WeaponTargetingName; // 0x84 (Size: 0x4, Type: NameProperty)
    FName SprintExecutionStatusName; // 0x88 (Size: 0x4, Type: NameProperty)
    FName TacticalSprintExecutionStatusName; // 0x8c (Size: 0x4, Type: NameProperty)
    FName HealingStatusKeyName; // 0x90 (Size: 0x4, Type: NameProperty)
    FName BlockWeaponActionsKeyName; // 0x94 (Size: 0x4, Type: NameProperty)
    FName RangedWeaponCancelAutoReloadKeyName; // 0x98 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_9c[0x18]; // 0x9c (Size: 0x18, Type: PaddingProperty)
    FValueOrBBKey_Bool AllowAttackingWhileSprinting; // 0xb4 (Size: 0xc, Type: StructProperty)
    bool bEndChargeOnFireStop; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0x7]; // 0xc1 (Size: 0x7, Type: PaddingProperty)

protected:
    void ManageWeaponTargeting(UBehaviorTreeComponent*& OwnerComp) const; // 0xefba6bc (Index: 0x0, Flags: Final|Native|Protected|Const)
};

static_assert(sizeof(UFortAthenaBTService_ManageWeapon) == 0xc8, "Size mismatch for UFortAthenaBTService_ManageWeapon");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, WeaponFireName) == 0x70, "Offset mismatch for UFortAthenaBTService_ManageWeapon::WeaponFireName");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, WeaponTriggerMeleeName) == 0x74, "Offset mismatch for UFortAthenaBTService_ManageWeapon::WeaponTriggerMeleeName");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, WeaponTriggerThrowableName) == 0x78, "Offset mismatch for UFortAthenaBTService_ManageWeapon::WeaponTriggerThrowableName");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, WeaponReloadName) == 0x7c, "Offset mismatch for UFortAthenaBTService_ManageWeapon::WeaponReloadName");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, WeaponName) == 0x80, "Offset mismatch for UFortAthenaBTService_ManageWeapon::WeaponName");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, WeaponTargetingName) == 0x84, "Offset mismatch for UFortAthenaBTService_ManageWeapon::WeaponTargetingName");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, SprintExecutionStatusName) == 0x88, "Offset mismatch for UFortAthenaBTService_ManageWeapon::SprintExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, TacticalSprintExecutionStatusName) == 0x8c, "Offset mismatch for UFortAthenaBTService_ManageWeapon::TacticalSprintExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, HealingStatusKeyName) == 0x90, "Offset mismatch for UFortAthenaBTService_ManageWeapon::HealingStatusKeyName");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, BlockWeaponActionsKeyName) == 0x94, "Offset mismatch for UFortAthenaBTService_ManageWeapon::BlockWeaponActionsKeyName");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, RangedWeaponCancelAutoReloadKeyName) == 0x98, "Offset mismatch for UFortAthenaBTService_ManageWeapon::RangedWeaponCancelAutoReloadKeyName");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, AllowAttackingWhileSprinting) == 0xb4, "Offset mismatch for UFortAthenaBTService_ManageWeapon::AllowAttackingWhileSprinting");
static_assert(offsetof(UFortAthenaBTService_ManageWeapon, bEndChargeOnFireStop) == 0xc0, "Offset mismatch for UFortAthenaBTService_ManageWeapon::bEndChargeOnFireStop");

// Size: 0xe0 (Inherited: 0x150, Single: 0xffffff90)
class UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween : public UBTService
{
public:
    FBlackboardKeySelector BlackboardKeyA; // 0x70 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector BlackboardKeyB; // 0x98 (Size: 0x28, Type: StructProperty)
    float MinDistance; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float MaxDistance; // 0xc4 (Size: 0x4, Type: FloatProperty)
    float MinDistanceSpeed; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float MaxDistanceSpeed; // 0xcc (Size: 0x4, Type: FloatProperty)
    bool bCalculateAs2D; // 0xd0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d1[0xf]; // 0xd1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween) == 0xe0, "Size mismatch for UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween");
static_assert(offsetof(UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween, BlackboardKeyA) == 0x70, "Offset mismatch for UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween::BlackboardKeyA");
static_assert(offsetof(UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween, BlackboardKeyB) == 0x98, "Offset mismatch for UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween::BlackboardKeyB");
static_assert(offsetof(UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween, MinDistance) == 0xc0, "Offset mismatch for UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween::MinDistance");
static_assert(offsetof(UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween, MaxDistance) == 0xc4, "Offset mismatch for UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween::MaxDistance");
static_assert(offsetof(UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween, MinDistanceSpeed) == 0xc8, "Offset mismatch for UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween::MinDistanceSpeed");
static_assert(offsetof(UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween, MaxDistanceSpeed) == 0xcc, "Offset mismatch for UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween::MaxDistanceSpeed");
static_assert(offsetof(UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween, bCalculateAs2D) == 0xd0, "Offset mismatch for UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween::bCalculateAs2D");

// Size: 0xd8 (Inherited: 0x150, Single: 0xffffff88)
class UFortAthenaBTService_MovementListener : public UBTService
{
public:
    FName MovementStateKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName IsStuckKeyName; // 0x74 (Size: 0x4, Type: NameProperty)
    bool bSuccessPartialAsFail; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
    FScalableFloat MaxFailCount; // 0x80 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxDurationToFail; // 0xa8 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_d0[0x8]; // 0xd0 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_MovementListener) == 0xd8, "Size mismatch for UFortAthenaBTService_MovementListener");
static_assert(offsetof(UFortAthenaBTService_MovementListener, MovementStateKeyName) == 0x70, "Offset mismatch for UFortAthenaBTService_MovementListener::MovementStateKeyName");
static_assert(offsetof(UFortAthenaBTService_MovementListener, IsStuckKeyName) == 0x74, "Offset mismatch for UFortAthenaBTService_MovementListener::IsStuckKeyName");
static_assert(offsetof(UFortAthenaBTService_MovementListener, bSuccessPartialAsFail) == 0x78, "Offset mismatch for UFortAthenaBTService_MovementListener::bSuccessPartialAsFail");
static_assert(offsetof(UFortAthenaBTService_MovementListener, MaxFailCount) == 0x80, "Offset mismatch for UFortAthenaBTService_MovementListener::MaxFailCount");
static_assert(offsetof(UFortAthenaBTService_MovementListener, MaxDurationToFail) == 0xa8, "Offset mismatch for UFortAthenaBTService_MovementListener::MaxDurationToFail");

// Size: 0x90 (Inherited: 0x150, Single: 0xffffff40)
class UFortAthenaBTService_Patrolling : public UBTService
{
public:
    FName PatrollingAppendDestinationKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    float AcceptableRadius; // 0x78 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
    UClass* FilterClass; // 0x80 (Size: 0x8, Type: ClassProperty)
    uint8_t bAllowPartialPath : 1; // 0x88:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bProjectGoalLocation : 1; // 0x88:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0x7]; // 0x89 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_Patrolling) == 0x90, "Size mismatch for UFortAthenaBTService_Patrolling");
static_assert(offsetof(UFortAthenaBTService_Patrolling, PatrollingAppendDestinationKeyName) == 0x70, "Offset mismatch for UFortAthenaBTService_Patrolling::PatrollingAppendDestinationKeyName");
static_assert(offsetof(UFortAthenaBTService_Patrolling, AcceptableRadius) == 0x78, "Offset mismatch for UFortAthenaBTService_Patrolling::AcceptableRadius");
static_assert(offsetof(UFortAthenaBTService_Patrolling, FilterClass) == 0x80, "Offset mismatch for UFortAthenaBTService_Patrolling::FilterClass");
static_assert(offsetof(UFortAthenaBTService_Patrolling, bAllowPartialPath) == 0x88, "Offset mismatch for UFortAthenaBTService_Patrolling::bAllowPartialPath");
static_assert(offsetof(UFortAthenaBTService_Patrolling, bProjectGoalLocation) == 0x88, "Offset mismatch for UFortAthenaBTService_Patrolling::bProjectGoalLocation");

// Size: 0x70 (Inherited: 0x150, Single: 0xffffff20)
class UFortAthenaBTService_PauseVehicle : public UBTService
{
public:
};

static_assert(sizeof(UFortAthenaBTService_PauseVehicle) == 0x70, "Size mismatch for UFortAthenaBTService_PauseVehicle");

// Size: 0x90 (Inherited: 0x150, Single: 0xffffff40)
class UFortAthenaBTService_PerceptionCheck : public UBTService
{
public:
    FValueOrBBKey_Object PerceptionTargetActorKey; // 0x70 (Size: 0x18, Type: StructProperty)
    FName PerceptionTargetActorIsBeingSeenKeyName; // 0x88 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_PerceptionCheck) == 0x90, "Size mismatch for UFortAthenaBTService_PerceptionCheck");
static_assert(offsetof(UFortAthenaBTService_PerceptionCheck, PerceptionTargetActorKey) == 0x70, "Offset mismatch for UFortAthenaBTService_PerceptionCheck::PerceptionTargetActorKey");
static_assert(offsetof(UFortAthenaBTService_PerceptionCheck, PerceptionTargetActorIsBeingSeenKeyName) == 0x88, "Offset mismatch for UFortAthenaBTService_PerceptionCheck::PerceptionTargetActorIsBeingSeenKeyName");

// Size: 0x90 (Inherited: 0x150, Single: 0xffffff40)
class UFortAthenaBTService_PickUpLoot : public UBTService
{
public:
    FName LootObjectKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName ExecutionStatusName; // 0x74 (Size: 0x4, Type: NameProperty)
    FName InteractionExecutionStatusName; // 0x78 (Size: 0x4, Type: NameProperty)
    FName InteractionContextInfoName; // 0x7c (Size: 0x4, Type: NameProperty)
    FName MovementStateKeyName; // 0x80 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_84[0xc]; // 0x84 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_PickUpLoot) == 0x90, "Size mismatch for UFortAthenaBTService_PickUpLoot");
static_assert(offsetof(UFortAthenaBTService_PickUpLoot, LootObjectKeyName) == 0x70, "Offset mismatch for UFortAthenaBTService_PickUpLoot::LootObjectKeyName");
static_assert(offsetof(UFortAthenaBTService_PickUpLoot, ExecutionStatusName) == 0x74, "Offset mismatch for UFortAthenaBTService_PickUpLoot::ExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_PickUpLoot, InteractionExecutionStatusName) == 0x78, "Offset mismatch for UFortAthenaBTService_PickUpLoot::InteractionExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_PickUpLoot, InteractionContextInfoName) == 0x7c, "Offset mismatch for UFortAthenaBTService_PickUpLoot::InteractionContextInfoName");
static_assert(offsetof(UFortAthenaBTService_PickUpLoot, MovementStateKeyName) == 0x80, "Offset mismatch for UFortAthenaBTService_PickUpLoot::MovementStateKeyName");

// Size: 0x78 (Inherited: 0x150, Single: 0xffffff28)
class UFortAthenaBTService_PropagatePatrolProgressToPassengers : public UBTService
{
public:
    FName PatrollingAppendDestinationKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_PropagatePatrolProgressToPassengers) == 0x78, "Size mismatch for UFortAthenaBTService_PropagatePatrolProgressToPassengers");
static_assert(offsetof(UFortAthenaBTService_PropagatePatrolProgressToPassengers, PatrollingAppendDestinationKeyName) == 0x70, "Offset mismatch for UFortAthenaBTService_PropagatePatrolProgressToPassengers::PatrollingAppendDestinationKeyName");

// Size: 0x90 (Inherited: 0x150, Single: 0xffffff40)
class UFortAthenaBTService_Revive : public UBTService
{
public:
    FName ReviveTargetKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName ExecutionStatusName; // 0x74 (Size: 0x4, Type: NameProperty)
    FName MoveToPathMovementStateName; // 0x78 (Size: 0x4, Type: NameProperty)
    FName InteractionExecutionStatusName; // 0x7c (Size: 0x4, Type: NameProperty)
    FName InteractionContextInfoName; // 0x80 (Size: 0x4, Type: NameProperty)
    bool bDisableLeash; // 0x84 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_85[0xb]; // 0x85 (Size: 0xb, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_Revive) == 0x90, "Size mismatch for UFortAthenaBTService_Revive");
static_assert(offsetof(UFortAthenaBTService_Revive, ReviveTargetKeyName) == 0x70, "Offset mismatch for UFortAthenaBTService_Revive::ReviveTargetKeyName");
static_assert(offsetof(UFortAthenaBTService_Revive, ExecutionStatusName) == 0x74, "Offset mismatch for UFortAthenaBTService_Revive::ExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_Revive, MoveToPathMovementStateName) == 0x78, "Offset mismatch for UFortAthenaBTService_Revive::MoveToPathMovementStateName");
static_assert(offsetof(UFortAthenaBTService_Revive, InteractionExecutionStatusName) == 0x7c, "Offset mismatch for UFortAthenaBTService_Revive::InteractionExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_Revive, InteractionContextInfoName) == 0x80, "Offset mismatch for UFortAthenaBTService_Revive::InteractionContextInfoName");
static_assert(offsetof(UFortAthenaBTService_Revive, bDisableLeash) == 0x84, "Offset mismatch for UFortAthenaBTService_Revive::bDisableLeash");

// Size: 0xa8 (Inherited: 0x288, Single: 0xfffffe20)
class UFortAthenaBTService_SetAIFocus : public UBTService_DefaultFocus
{
public:
    uint8_t FocusPriorityToSet; // 0xa0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a1[0x7]; // 0xa1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_SetAIFocus) == 0xa8, "Size mismatch for UFortAthenaBTService_SetAIFocus");
static_assert(offsetof(UFortAthenaBTService_SetAIFocus, FocusPriorityToSet) == 0xa0, "Offset mismatch for UFortAthenaBTService_SetAIFocus::FocusPriorityToSet");

// Size: 0xa0 (Inherited: 0x150, Single: 0xffffff50)
class UFortAthenaBTService_SetBlackboardBool : public UBTService
{
public:
    FBlackboardKeySelector BlackboardKey; // 0x70 (Size: 0x28, Type: StructProperty)
    bool bBlackboardValue; // 0x98 (Size: 0x1, Type: BoolProperty)
    uint8_t ExitAction; // 0x99 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9a[0x6]; // 0x9a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_SetBlackboardBool) == 0xa0, "Size mismatch for UFortAthenaBTService_SetBlackboardBool");
static_assert(offsetof(UFortAthenaBTService_SetBlackboardBool, BlackboardKey) == 0x70, "Offset mismatch for UFortAthenaBTService_SetBlackboardBool::BlackboardKey");
static_assert(offsetof(UFortAthenaBTService_SetBlackboardBool, bBlackboardValue) == 0x98, "Offset mismatch for UFortAthenaBTService_SetBlackboardBool::bBlackboardValue");
static_assert(offsetof(UFortAthenaBTService_SetBlackboardBool, ExitAction) == 0x99, "Offset mismatch for UFortAthenaBTService_SetBlackboardBool::ExitAction");

// Size: 0xa0 (Inherited: 0x1e8, Single: 0xfffffeb8)
class UFortAthenaBTService_SetExecutionStatus : public UBTService_BlackboardBase
{
public:
    uint8_t ExecutionStatus; // 0x98 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_SetExecutionStatus) == 0xa0, "Size mismatch for UFortAthenaBTService_SetExecutionStatus");
static_assert(offsetof(UFortAthenaBTService_SetExecutionStatus, ExecutionStatus) == 0x98, "Offset mismatch for UFortAthenaBTService_SetExecutionStatus::ExecutionStatus");

// Size: 0x78 (Inherited: 0x150, Single: 0xffffff28)
class UFortAthenaBTService_Slide : public UBTService
{
public:
    FName SlideExecutionStatusName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)

private:
    void OnStopSliding(AFortPlayerPawn*& Pawn); // 0xefba878 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortAthenaBTService_Slide) == 0x78, "Size mismatch for UFortAthenaBTService_Slide");
static_assert(offsetof(UFortAthenaBTService_Slide, SlideExecutionStatusName) == 0x70, "Offset mismatch for UFortAthenaBTService_Slide::SlideExecutionStatusName");

// Size: 0x88 (Inherited: 0x150, Single: 0xffffff38)
class UFortAthenaBTService_SmartObject : public UBTService
{
public:
    FName SmartObjectStatusKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName SmartObjectDestinationKeyName; // 0x74 (Size: 0x4, Type: NameProperty)
    FGameplayTag EvaluationTag; // 0x78 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_7c[0xc]; // 0x7c (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_SmartObject) == 0x88, "Size mismatch for UFortAthenaBTService_SmartObject");
static_assert(offsetof(UFortAthenaBTService_SmartObject, SmartObjectStatusKeyName) == 0x70, "Offset mismatch for UFortAthenaBTService_SmartObject::SmartObjectStatusKeyName");
static_assert(offsetof(UFortAthenaBTService_SmartObject, SmartObjectDestinationKeyName) == 0x74, "Offset mismatch for UFortAthenaBTService_SmartObject::SmartObjectDestinationKeyName");
static_assert(offsetof(UFortAthenaBTService_SmartObject, EvaluationTag) == 0x78, "Offset mismatch for UFortAthenaBTService_SmartObject::EvaluationTag");

// Size: 0xe0 (Inherited: 0x150, Single: 0xffffff90)
class UFortAthenaBTService_Sprinting : public UBTService
{
public:
    uint8_t Pad_70[0x40]; // 0x70 (Size: 0x40, Type: PaddingProperty)
    FName SprintExecutionStatusName; // 0xb0 (Size: 0x4, Type: NameProperty)
    FName TacticalSprintExecutionStatusName; // 0xb4 (Size: 0x4, Type: NameProperty)
    FName TacticalSprintOverridenName; // 0xb8 (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Bool EnableSprinting; // 0xbc (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ValidateSprintingBeforeTacticalSprinting; // 0xc8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_d4[0xc]; // 0xd4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_Sprinting) == 0xe0, "Size mismatch for UFortAthenaBTService_Sprinting");
static_assert(offsetof(UFortAthenaBTService_Sprinting, SprintExecutionStatusName) == 0xb0, "Offset mismatch for UFortAthenaBTService_Sprinting::SprintExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_Sprinting, TacticalSprintExecutionStatusName) == 0xb4, "Offset mismatch for UFortAthenaBTService_Sprinting::TacticalSprintExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_Sprinting, TacticalSprintOverridenName) == 0xb8, "Offset mismatch for UFortAthenaBTService_Sprinting::TacticalSprintOverridenName");
static_assert(offsetof(UFortAthenaBTService_Sprinting, EnableSprinting) == 0xbc, "Offset mismatch for UFortAthenaBTService_Sprinting::EnableSprinting");
static_assert(offsetof(UFortAthenaBTService_Sprinting, ValidateSprintingBeforeTacticalSprinting) == 0xc8, "Offset mismatch for UFortAthenaBTService_Sprinting::ValidateSprintingBeforeTacticalSprinting");

// Size: 0x70 (Inherited: 0x150, Single: 0xffffff20)
class UFortAthenaBTService_UpdateTarget : public UBTService
{
public:
};

static_assert(sizeof(UFortAthenaBTService_UpdateTarget) == 0x70, "Size mismatch for UFortAthenaBTService_UpdateTarget");

// Size: 0xa0 (Inherited: 0x150, Single: 0xffffff50)
class UFortAthenaBTService_UseItem : public UBTService
{
public:
    FName ActionObjectKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName ExecutionStatusKeyName; // 0x74 (Size: 0x4, Type: NameProperty)
    FName CanMoveWhileUsingItemKeyName; // 0x78 (Size: 0x4, Type: NameProperty)
    int32_t MaxEquipAttempts; // 0x7c (Size: 0x4, Type: IntProperty)
    float EquipRetryInterval; // 0x80 (Size: 0x4, Type: FloatProperty)
    float UseItemDelay; // 0x84 (Size: 0x4, Type: FloatProperty)
    float MinWaitTimeBetweenUses; // 0x88 (Size: 0x4, Type: FloatProperty)
    float MaxWaitTimeBetweenUses; // 0x8c (Size: 0x4, Type: FloatProperty)
    float ItemUsageTimeout; // 0x90 (Size: 0x4, Type: FloatProperty)
    bool bCanOnlyUseMobileItems; // 0x94 (Size: 0x1, Type: BoolProperty)
    bool bBlockWeaponActions; // 0x95 (Size: 0x1, Type: BoolProperty)
    bool bValidateAbility; // 0x96 (Size: 0x1, Type: BoolProperty)
    bool bResetActionObjectKey; // 0x97 (Size: 0x1, Type: BoolProperty)
    bool bUseAlternateMode; // 0x98 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_UseItem) == 0xa0, "Size mismatch for UFortAthenaBTService_UseItem");
static_assert(offsetof(UFortAthenaBTService_UseItem, ActionObjectKeyName) == 0x70, "Offset mismatch for UFortAthenaBTService_UseItem::ActionObjectKeyName");
static_assert(offsetof(UFortAthenaBTService_UseItem, ExecutionStatusKeyName) == 0x74, "Offset mismatch for UFortAthenaBTService_UseItem::ExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaBTService_UseItem, CanMoveWhileUsingItemKeyName) == 0x78, "Offset mismatch for UFortAthenaBTService_UseItem::CanMoveWhileUsingItemKeyName");
static_assert(offsetof(UFortAthenaBTService_UseItem, MaxEquipAttempts) == 0x7c, "Offset mismatch for UFortAthenaBTService_UseItem::MaxEquipAttempts");
static_assert(offsetof(UFortAthenaBTService_UseItem, EquipRetryInterval) == 0x80, "Offset mismatch for UFortAthenaBTService_UseItem::EquipRetryInterval");
static_assert(offsetof(UFortAthenaBTService_UseItem, UseItemDelay) == 0x84, "Offset mismatch for UFortAthenaBTService_UseItem::UseItemDelay");
static_assert(offsetof(UFortAthenaBTService_UseItem, MinWaitTimeBetweenUses) == 0x88, "Offset mismatch for UFortAthenaBTService_UseItem::MinWaitTimeBetweenUses");
static_assert(offsetof(UFortAthenaBTService_UseItem, MaxWaitTimeBetweenUses) == 0x8c, "Offset mismatch for UFortAthenaBTService_UseItem::MaxWaitTimeBetweenUses");
static_assert(offsetof(UFortAthenaBTService_UseItem, ItemUsageTimeout) == 0x90, "Offset mismatch for UFortAthenaBTService_UseItem::ItemUsageTimeout");
static_assert(offsetof(UFortAthenaBTService_UseItem, bCanOnlyUseMobileItems) == 0x94, "Offset mismatch for UFortAthenaBTService_UseItem::bCanOnlyUseMobileItems");
static_assert(offsetof(UFortAthenaBTService_UseItem, bBlockWeaponActions) == 0x95, "Offset mismatch for UFortAthenaBTService_UseItem::bBlockWeaponActions");
static_assert(offsetof(UFortAthenaBTService_UseItem, bValidateAbility) == 0x96, "Offset mismatch for UFortAthenaBTService_UseItem::bValidateAbility");
static_assert(offsetof(UFortAthenaBTService_UseItem, bResetActionObjectKey) == 0x97, "Offset mismatch for UFortAthenaBTService_UseItem::bResetActionObjectKey");
static_assert(offsetof(UFortAthenaBTService_UseItem, bUseAlternateMode) == 0x98, "Offset mismatch for UFortAthenaBTService_UseItem::bUseAlternateMode");

// Size: 0x78 (Inherited: 0x150, Single: 0xffffff28)
class UFortAthenaBTService_WaitForPassengers : public UBTService
{
public:
    FName WaitForPassengersStatusKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_WaitForPassengers) == 0x78, "Size mismatch for UFortAthenaBTService_WaitForPassengers");
static_assert(offsetof(UFortAthenaBTService_WaitForPassengers, WaitForPassengersStatusKeyName) == 0x70, "Offset mismatch for UFortAthenaBTService_WaitForPassengers::WaitForPassengersStatusKeyName");

// Size: 0xb8 (Inherited: 0x150, Single: 0xffffff68)
class UFortAthenaBTService_Zipline : public UBTService
{
public:
    FName ZiplineTargetName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName InteractionExecutionStatusName; // 0x74 (Size: 0x4, Type: NameProperty)
    FName InteractionContextInfoName; // 0x78 (Size: 0x4, Type: NameProperty)
    FName UsageExecutionStatusName; // 0x7c (Size: 0x4, Type: NameProperty)
    FName ZiplineEntryLocationName; // 0x80 (Size: 0x4, Type: NameProperty)
    FName ZiplineExitLocationKeyName; // 0x84 (Size: 0x4, Type: NameProperty)
    FName MoveToPathMovementStateName; // 0x88 (Size: 0x4, Type: NameProperty)
    FName MoveExecutionStatusName; // 0x8c (Size: 0x4, Type: NameProperty)
    FName FocalPointName; // 0x90 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_94[0x24]; // 0x94 (Size: 0x24, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTService_Zipline) == 0xb8, "Size mismatch for UFortAthenaBTService_Zipline");
static_assert(offsetof(UFortAthenaBTService_Zipline, ZiplineTargetName) == 0x70, "Offset mismatch for UFortAthenaBTService_Zipline::ZiplineTargetName");
static_assert(offsetof(UFortAthenaBTService_Zipline, InteractionExecutionStatusName) == 0x74, "Offset mismatch for UFortAthenaBTService_Zipline::InteractionExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_Zipline, InteractionContextInfoName) == 0x78, "Offset mismatch for UFortAthenaBTService_Zipline::InteractionContextInfoName");
static_assert(offsetof(UFortAthenaBTService_Zipline, UsageExecutionStatusName) == 0x7c, "Offset mismatch for UFortAthenaBTService_Zipline::UsageExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_Zipline, ZiplineEntryLocationName) == 0x80, "Offset mismatch for UFortAthenaBTService_Zipline::ZiplineEntryLocationName");
static_assert(offsetof(UFortAthenaBTService_Zipline, ZiplineExitLocationKeyName) == 0x84, "Offset mismatch for UFortAthenaBTService_Zipline::ZiplineExitLocationKeyName");
static_assert(offsetof(UFortAthenaBTService_Zipline, MoveToPathMovementStateName) == 0x88, "Offset mismatch for UFortAthenaBTService_Zipline::MoveToPathMovementStateName");
static_assert(offsetof(UFortAthenaBTService_Zipline, MoveExecutionStatusName) == 0x8c, "Offset mismatch for UFortAthenaBTService_Zipline::MoveExecutionStatusName");
static_assert(offsetof(UFortAthenaBTService_Zipline, FocalPointName) == 0x90, "Offset mismatch for UFortAthenaBTService_Zipline::FocalPointName");

// Size: 0x80 (Inherited: 0xf0, Single: 0xffffff90)
class UFortAthenaBTTask_ActivateVehicleBoost : public UBTTaskNode
{
public:
    bool bActivateBoost; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x3]; // 0x71 (Size: 0x3, Type: PaddingProperty)
    float BoostLength; // 0x74 (Size: 0x4, Type: FloatProperty)
    bool bIgnoreMinimumDistanceLeft; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_ActivateVehicleBoost) == 0x80, "Size mismatch for UFortAthenaBTTask_ActivateVehicleBoost");
static_assert(offsetof(UFortAthenaBTTask_ActivateVehicleBoost, bActivateBoost) == 0x70, "Offset mismatch for UFortAthenaBTTask_ActivateVehicleBoost::bActivateBoost");
static_assert(offsetof(UFortAthenaBTTask_ActivateVehicleBoost, BoostLength) == 0x74, "Offset mismatch for UFortAthenaBTTask_ActivateVehicleBoost::BoostLength");
static_assert(offsetof(UFortAthenaBTTask_ActivateVehicleBoost, bIgnoreMinimumDistanceLeft) == 0x78, "Offset mismatch for UFortAthenaBTTask_ActivateVehicleBoost::bIgnoreMinimumDistanceLeft");

// Size: 0x170 (Inherited: 0x3f8, Single: 0xfffffd78)
class UFortAthenaBTTask_BotMoveTo : public UFortAthenaBTTask_MoveTo
{
public:
    FName NoSmashMoveGoalActorKeyName; // 0x140 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_144[0x2]; // 0x144 (Size: 0x2, Type: PaddingProperty)
    uint8_t bAllowRandomWobble : 1; // 0x146:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_147[0x1]; // 0x147 (Size: 0x1, Type: PaddingProperty)
    FValueOrBBKey_Bool AllowRandomWobble; // 0x148 (Size: 0xc, Type: StructProperty)
    uint8_t bIsUrgentMovement : 1; // 0x154:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_155[0x3]; // 0x155 (Size: 0x3, Type: PaddingProperty)
    FValueOrBBKey_Bool IsUrgentMovement; // 0x158 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool IgnoreObstaclesOnPath; // 0x164 (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(UFortAthenaBTTask_BotMoveTo) == 0x170, "Size mismatch for UFortAthenaBTTask_BotMoveTo");
static_assert(offsetof(UFortAthenaBTTask_BotMoveTo, NoSmashMoveGoalActorKeyName) == 0x140, "Offset mismatch for UFortAthenaBTTask_BotMoveTo::NoSmashMoveGoalActorKeyName");
static_assert(offsetof(UFortAthenaBTTask_BotMoveTo, bAllowRandomWobble) == 0x146, "Offset mismatch for UFortAthenaBTTask_BotMoveTo::bAllowRandomWobble");
static_assert(offsetof(UFortAthenaBTTask_BotMoveTo, AllowRandomWobble) == 0x148, "Offset mismatch for UFortAthenaBTTask_BotMoveTo::AllowRandomWobble");
static_assert(offsetof(UFortAthenaBTTask_BotMoveTo, bIsUrgentMovement) == 0x154, "Offset mismatch for UFortAthenaBTTask_BotMoveTo::bIsUrgentMovement");
static_assert(offsetof(UFortAthenaBTTask_BotMoveTo, IsUrgentMovement) == 0x158, "Offset mismatch for UFortAthenaBTTask_BotMoveTo::IsUrgentMovement");
static_assert(offsetof(UFortAthenaBTTask_BotMoveTo, IgnoreObstaclesOnPath) == 0x164, "Offset mismatch for UFortAthenaBTTask_BotMoveTo::IgnoreObstaclesOnPath");

// Size: 0x140 (Inherited: 0x2b8, Single: 0xfffffe88)
class UFortAthenaBTTask_MoveTo : public UBTTask_MoveTo
{
public:
    FName MovementResultKeyName; // 0x130 (Size: 0x4, Type: NameProperty)
    FName ExecutionStatusKeyName; // 0x134 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_138[0x4]; // 0x138 (Size: 0x4, Type: PaddingProperty)
    uint8_t bAllowRestartOnPartialSuccess : 1; // 0x13c:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAllowPartialPathToUncompleteNavigationArea : 1; // 0x13c:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_13d[0x3]; // 0x13d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_MoveTo) == 0x140, "Size mismatch for UFortAthenaBTTask_MoveTo");
static_assert(offsetof(UFortAthenaBTTask_MoveTo, MovementResultKeyName) == 0x130, "Offset mismatch for UFortAthenaBTTask_MoveTo::MovementResultKeyName");
static_assert(offsetof(UFortAthenaBTTask_MoveTo, ExecutionStatusKeyName) == 0x134, "Offset mismatch for UFortAthenaBTTask_MoveTo::ExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaBTTask_MoveTo, bAllowRestartOnPartialSuccess) == 0x13c, "Offset mismatch for UFortAthenaBTTask_MoveTo::bAllowRestartOnPartialSuccess");
static_assert(offsetof(UFortAthenaBTTask_MoveTo, bAllowPartialPathToUncompleteNavigationArea) == 0x13c, "Offset mismatch for UFortAthenaBTTask_MoveTo::bAllowPartialPathToUncompleteNavigationArea");

// Size: 0xe8 (Inherited: 0xf0, Single: 0xfffffff8)
class UFortAthenaBTTask_BotUnstuckTeleport : public UBTTaskNode
{
public:
    FEQSParametrizedQueryExecutionRequest EQSRequest; // 0x70 (Size: 0x48, Type: StructProperty)
    FName CanReachDestinationKeyName; // 0xb8 (Size: 0x4, Type: NameProperty)
    FName TeleportExecutionStatusKeyName; // 0xbc (Size: 0x4, Type: NameProperty)
    FName LastPartialPathTimeKeyName; // 0xc0 (Size: 0x4, Type: NameProperty)
    FName LastPartialPathCountKeyName; // 0xc4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c8[0x20]; // 0xc8 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_BotUnstuckTeleport) == 0xe8, "Size mismatch for UFortAthenaBTTask_BotUnstuckTeleport");
static_assert(offsetof(UFortAthenaBTTask_BotUnstuckTeleport, EQSRequest) == 0x70, "Offset mismatch for UFortAthenaBTTask_BotUnstuckTeleport::EQSRequest");
static_assert(offsetof(UFortAthenaBTTask_BotUnstuckTeleport, CanReachDestinationKeyName) == 0xb8, "Offset mismatch for UFortAthenaBTTask_BotUnstuckTeleport::CanReachDestinationKeyName");
static_assert(offsetof(UFortAthenaBTTask_BotUnstuckTeleport, TeleportExecutionStatusKeyName) == 0xbc, "Offset mismatch for UFortAthenaBTTask_BotUnstuckTeleport::TeleportExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaBTTask_BotUnstuckTeleport, LastPartialPathTimeKeyName) == 0xc0, "Offset mismatch for UFortAthenaBTTask_BotUnstuckTeleport::LastPartialPathTimeKeyName");
static_assert(offsetof(UFortAthenaBTTask_BotUnstuckTeleport, LastPartialPathCountKeyName) == 0xc4, "Offset mismatch for UFortAthenaBTTask_BotUnstuckTeleport::LastPartialPathCountKeyName");

// Size: 0xb0 (Inherited: 0x178, Single: 0xffffff38)
class UFortAthenaBTTask_BotWait : public UBTTask_Wait
{
public:
    FBlackboardKeySelector WaitCompleteKeySelector; // 0x88 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UFortAthenaBTTask_BotWait) == 0xb0, "Size mismatch for UFortAthenaBTTask_BotWait");
static_assert(offsetof(UFortAthenaBTTask_BotWait, WaitCompleteKeySelector) == 0x88, "Offset mismatch for UFortAthenaBTTask_BotWait::WaitCompleteKeySelector");

// Size: 0x80 (Inherited: 0xf0, Single: 0xffffff90)
class UFortAthenaBTTask_Build : public UBTTaskNode
{
public:
    FName ExecutionStatusKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName FocalPointName; // 0x74 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_78[0x8]; // 0x78 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_Build) == 0x80, "Size mismatch for UFortAthenaBTTask_Build");
static_assert(offsetof(UFortAthenaBTTask_Build, ExecutionStatusKeyName) == 0x70, "Offset mismatch for UFortAthenaBTTask_Build::ExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaBTTask_Build, FocalPointName) == 0x74, "Offset mismatch for UFortAthenaBTTask_Build::FocalPointName");

// Size: 0x78 (Inherited: 0xf0, Single: 0xffffff88)
class UFortAthenaBTTask_Conversation : public UBTTaskNode
{
public:
    FName ConversationStatusKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x2]; // 0x74 (Size: 0x2, Type: PaddingProperty)
    bool bResetEvaluatorStatusKeyOnFinish; // 0x76 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_77[0x1]; // 0x77 (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_Conversation) == 0x78, "Size mismatch for UFortAthenaBTTask_Conversation");
static_assert(offsetof(UFortAthenaBTTask_Conversation, ConversationStatusKeyName) == 0x70, "Offset mismatch for UFortAthenaBTTask_Conversation::ConversationStatusKeyName");
static_assert(offsetof(UFortAthenaBTTask_Conversation, bResetEvaluatorStatusKeyOnFinish) == 0x76, "Offset mismatch for UFortAthenaBTTask_Conversation::bResetEvaluatorStatusKeyOnFinish");

// Size: 0x80 (Inherited: 0xf0, Single: 0xffffff90)
class UFortAthenaBTTask_Dive : public UBTTaskNode
{
public:
    FName ExecutionStatusKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName DiveDestinationKeyName; // 0x74 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_78[0x8]; // 0x78 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_Dive) == 0x80, "Size mismatch for UFortAthenaBTTask_Dive");
static_assert(offsetof(UFortAthenaBTTask_Dive, ExecutionStatusKeyName) == 0x70, "Offset mismatch for UFortAthenaBTTask_Dive::ExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaBTTask_Dive, DiveDestinationKeyName) == 0x74, "Offset mismatch for UFortAthenaBTTask_Dive::DiveDestinationKeyName");

// Size: 0x78 (Inherited: 0xf0, Single: 0xffffff88)
class UFortAthenaBTTask_EnterVehicle : public UBTTaskNode
{
public:
    FName SelectedVehicleKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_EnterVehicle) == 0x78, "Size mismatch for UFortAthenaBTTask_EnterVehicle");
static_assert(offsetof(UFortAthenaBTTask_EnterVehicle, SelectedVehicleKeyName) == 0x70, "Offset mismatch for UFortAthenaBTTask_EnterVehicle::SelectedVehicleKeyName");

// Size: 0xc0 (Inherited: 0xf0, Single: 0xffffffd0)
class UFortAthenaBTTask_EquipItem : public UBTTaskNode
{
public:
    FName WeaponKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName EquipItemKeyName; // 0x74 (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Bool DisableEquipAnimation; // 0x78 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool WaitForEquipToFinish; // 0x84 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_GameplayTagContainer ItemTagToEquip; // 0x90 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_EquipItem) == 0xc0, "Size mismatch for UFortAthenaBTTask_EquipItem");
static_assert(offsetof(UFortAthenaBTTask_EquipItem, WeaponKeyName) == 0x70, "Offset mismatch for UFortAthenaBTTask_EquipItem::WeaponKeyName");
static_assert(offsetof(UFortAthenaBTTask_EquipItem, EquipItemKeyName) == 0x74, "Offset mismatch for UFortAthenaBTTask_EquipItem::EquipItemKeyName");
static_assert(offsetof(UFortAthenaBTTask_EquipItem, DisableEquipAnimation) == 0x78, "Offset mismatch for UFortAthenaBTTask_EquipItem::DisableEquipAnimation");
static_assert(offsetof(UFortAthenaBTTask_EquipItem, WaitForEquipToFinish) == 0x84, "Offset mismatch for UFortAthenaBTTask_EquipItem::WaitForEquipToFinish");
static_assert(offsetof(UFortAthenaBTTask_EquipItem, ItemTagToEquip) == 0x90, "Offset mismatch for UFortAthenaBTTask_EquipItem::ItemTagToEquip");

// Size: 0x78 (Inherited: 0xf0, Single: 0xffffff88)
class UFortAthenaBTTask_Escalate : public UBTTaskNode
{
public:

protected:
    virtual void BP_OnEscalate(AFortPlayerPawn*& const OwnerActor, AFortPlayerPawn*& const EscalateTarget) const; // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent|Const)
    virtual void BP_OnHasEscalateTarget(AFortPlayerPawn*& const OwnerActor, AFortPlayerPawn*& const EscalateTarget) const; // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent|Const)
};

static_assert(sizeof(UFortAthenaBTTask_Escalate) == 0x78, "Size mismatch for UFortAthenaBTTask_Escalate");

// Size: 0x80 (Inherited: 0xf0, Single: 0xffffff90)
class UFortAthenaBTTask_Glide : public UBTTaskNode
{
public:
    FName ExecutionStatusKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName GlideDestinationKeyName; // 0x74 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_78[0x8]; // 0x78 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_Glide) == 0x80, "Size mismatch for UFortAthenaBTTask_Glide");
static_assert(offsetof(UFortAthenaBTTask_Glide, ExecutionStatusKeyName) == 0x70, "Offset mismatch for UFortAthenaBTTask_Glide::ExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaBTTask_Glide, GlideDestinationKeyName) == 0x74, "Offset mismatch for UFortAthenaBTTask_Glide::GlideDestinationKeyName");

// Size: 0xe8 (Inherited: 0xf0, Single: 0xfffffff8)
class UFortAthenaBTTask_Interact : public UBTTaskNode
{
public:
    float AttemptInterval; // 0x70 (Size: 0x4, Type: FloatProperty)
    int32_t MaxInteractAttempts; // 0x74 (Size: 0x4, Type: IntProperty)
    bool bShouldFocusOnInteraction; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
    FBlackboardKeySelector InteractExecutionStatusKeySelector; // 0x80 (Size: 0x28, Type: StructProperty)
    FBlackboardKeySelector InteractContextInfoKeySelector; // 0xa8 (Size: 0x28, Type: StructProperty)
    FName FocalPointName; // 0xd0 (Size: 0x4, Type: NameProperty)
    FName InteractActorName; // 0xd4 (Size: 0x4, Type: NameProperty)
    FName JumpExecutionStatusName; // 0xd8 (Size: 0x4, Type: NameProperty)
    FName WeaponTriggerMeleeName; // 0xdc (Size: 0x4, Type: NameProperty)
    uint8_t Pad_e0[0x8]; // 0xe0 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_Interact) == 0xe8, "Size mismatch for UFortAthenaBTTask_Interact");
static_assert(offsetof(UFortAthenaBTTask_Interact, AttemptInterval) == 0x70, "Offset mismatch for UFortAthenaBTTask_Interact::AttemptInterval");
static_assert(offsetof(UFortAthenaBTTask_Interact, MaxInteractAttempts) == 0x74, "Offset mismatch for UFortAthenaBTTask_Interact::MaxInteractAttempts");
static_assert(offsetof(UFortAthenaBTTask_Interact, bShouldFocusOnInteraction) == 0x78, "Offset mismatch for UFortAthenaBTTask_Interact::bShouldFocusOnInteraction");
static_assert(offsetof(UFortAthenaBTTask_Interact, InteractExecutionStatusKeySelector) == 0x80, "Offset mismatch for UFortAthenaBTTask_Interact::InteractExecutionStatusKeySelector");
static_assert(offsetof(UFortAthenaBTTask_Interact, InteractContextInfoKeySelector) == 0xa8, "Offset mismatch for UFortAthenaBTTask_Interact::InteractContextInfoKeySelector");
static_assert(offsetof(UFortAthenaBTTask_Interact, FocalPointName) == 0xd0, "Offset mismatch for UFortAthenaBTTask_Interact::FocalPointName");
static_assert(offsetof(UFortAthenaBTTask_Interact, InteractActorName) == 0xd4, "Offset mismatch for UFortAthenaBTTask_Interact::InteractActorName");
static_assert(offsetof(UFortAthenaBTTask_Interact, JumpExecutionStatusName) == 0xd8, "Offset mismatch for UFortAthenaBTTask_Interact::JumpExecutionStatusName");
static_assert(offsetof(UFortAthenaBTTask_Interact, WeaponTriggerMeleeName) == 0xdc, "Offset mismatch for UFortAthenaBTTask_Interact::WeaponTriggerMeleeName");

// Size: 0x78 (Inherited: 0xf0, Single: 0xffffff88)
class UFortAthenaBTTask_LeaveVehicle : public UBTTaskNode
{
public:
    bool bWaitVehicleStop; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_LeaveVehicle) == 0x78, "Size mismatch for UFortAthenaBTTask_LeaveVehicle");
static_assert(offsetof(UFortAthenaBTTask_LeaveVehicle, bWaitVehicleStop) == 0x70, "Offset mismatch for UFortAthenaBTTask_LeaveVehicle::bWaitVehicleStop");

// Size: 0x88 (Inherited: 0xf0, Single: 0xffffff98)
class UFortAthenaBTTask_ModulateVehicleSpeed : public UBTTaskNode
{
public:
    FValueOrBBKey_Float DrivingSpeed; // 0x70 (Size: 0xc, Type: StructProperty)
    float NewDrivingSpeed; // 0x7c (Size: 0x4, Type: FloatProperty)
    bool bResetControlPIDs; // 0x80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_81[0x7]; // 0x81 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_ModulateVehicleSpeed) == 0x88, "Size mismatch for UFortAthenaBTTask_ModulateVehicleSpeed");
static_assert(offsetof(UFortAthenaBTTask_ModulateVehicleSpeed, DrivingSpeed) == 0x70, "Offset mismatch for UFortAthenaBTTask_ModulateVehicleSpeed::DrivingSpeed");
static_assert(offsetof(UFortAthenaBTTask_ModulateVehicleSpeed, NewDrivingSpeed) == 0x7c, "Offset mismatch for UFortAthenaBTTask_ModulateVehicleSpeed::NewDrivingSpeed");
static_assert(offsetof(UFortAthenaBTTask_ModulateVehicleSpeed, bResetControlPIDs) == 0x80, "Offset mismatch for UFortAthenaBTTask_ModulateVehicleSpeed::bResetControlPIDs");

// Size: 0x78 (Inherited: 0xf0, Single: 0xffffff88)
class UFortAthenaBTTask_PauseVehicle : public UBTTaskNode
{
public:
    bool bPausePathFollow; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_PauseVehicle) == 0x78, "Size mismatch for UFortAthenaBTTask_PauseVehicle");
static_assert(offsetof(UFortAthenaBTTask_PauseVehicle, bPausePathFollow) == 0x70, "Offset mismatch for UFortAthenaBTTask_PauseVehicle::bPausePathFollow");

// Size: 0x88 (Inherited: 0xf0, Single: 0xffffff98)
class UFortAthenaBTTask_PlayEmote : public UBTTaskNode
{
public:
    FName PlayEmoteExecutionStatusKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    TArray<UAthenaDanceItemDefinition*> BespokeEmotes; // 0x78 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortAthenaBTTask_PlayEmote) == 0x88, "Size mismatch for UFortAthenaBTTask_PlayEmote");
static_assert(offsetof(UFortAthenaBTTask_PlayEmote, PlayEmoteExecutionStatusKeyName) == 0x70, "Offset mismatch for UFortAthenaBTTask_PlayEmote::PlayEmoteExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaBTTask_PlayEmote, BespokeEmotes) == 0x78, "Offset mismatch for UFortAthenaBTTask_PlayEmote::BespokeEmotes");

// Size: 0x78 (Inherited: 0xf0, Single: 0xffffff88)
class UFortAthenaBTTask_ReverseVehicle : public UBTTaskNode
{
public:
    bool bReverseVehicle; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_ReverseVehicle) == 0x78, "Size mismatch for UFortAthenaBTTask_ReverseVehicle");
static_assert(offsetof(UFortAthenaBTTask_ReverseVehicle, bReverseVehicle) == 0x70, "Offset mismatch for UFortAthenaBTTask_ReverseVehicle::bReverseVehicle");

// Size: 0x90 (Inherited: 0x178, Single: 0xffffff18)
class UFortAthenaBTTask_RunDynamicSubtree : public UBTTask_RunBehaviorDynamic
{
public:
    uint8_t bCallParentOnInstanceCreated : 1; // 0x88:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0x7]; // 0x89 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_RunDynamicSubtree) == 0x90, "Size mismatch for UFortAthenaBTTask_RunDynamicSubtree");
static_assert(offsetof(UFortAthenaBTTask_RunDynamicSubtree, bCallParentOnInstanceCreated) == 0x88, "Offset mismatch for UFortAthenaBTTask_RunDynamicSubtree::bCallParentOnInstanceCreated");

// Size: 0x78 (Inherited: 0xf0, Single: 0xffffff88)
class UFortAthenaBTTask_SetAggressiveDriving : public UBTTaskNode
{
public:
    bool bAggressiveDriving; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_SetAggressiveDriving) == 0x78, "Size mismatch for UFortAthenaBTTask_SetAggressiveDriving");
static_assert(offsetof(UFortAthenaBTTask_SetAggressiveDriving, bAggressiveDriving) == 0x70, "Offset mismatch for UFortAthenaBTTask_SetAggressiveDriving::bAggressiveDriving");

// Size: 0xb8 (Inherited: 0x178, Single: 0xffffff40)
class UFortAthenaBTTask_ShootTrap : public UBTTask_Wait
{
public:
    FBlackboardKeySelector TargetActorKey; // 0x88 (Size: 0x28, Type: StructProperty)
    FName TrapOnPathKeyName; // 0xb0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b4[0x4]; // 0xb4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_ShootTrap) == 0xb8, "Size mismatch for UFortAthenaBTTask_ShootTrap");
static_assert(offsetof(UFortAthenaBTTask_ShootTrap, TargetActorKey) == 0x88, "Offset mismatch for UFortAthenaBTTask_ShootTrap::TargetActorKey");
static_assert(offsetof(UFortAthenaBTTask_ShootTrap, TrapOnPathKeyName) == 0xb0, "Offset mismatch for UFortAthenaBTTask_ShootTrap::TrapOnPathKeyName");

// Size: 0xa0 (Inherited: 0xf0, Single: 0xffffffb0)
class UFortAthenaBTTask_SteerMovement : public UBTTaskNode
{
public:
    FBlackboardKeySelector SteerDirectionKeySelector; // 0x70 (Size: 0x28, Type: StructProperty)
    uint8_t bSetControlRotation : 1; // 0x98:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_SteerMovement) == 0xa0, "Size mismatch for UFortAthenaBTTask_SteerMovement");
static_assert(offsetof(UFortAthenaBTTask_SteerMovement, SteerDirectionKeySelector) == 0x70, "Offset mismatch for UFortAthenaBTTask_SteerMovement::SteerDirectionKeySelector");
static_assert(offsetof(UFortAthenaBTTask_SteerMovement, bSetControlRotation) == 0x98, "Offset mismatch for UFortAthenaBTTask_SteerMovement::bSetControlRotation");

// Size: 0x88 (Inherited: 0xf0, Single: 0xffffff98)
class UFortAthenaBTTask_Undermine : public UBTTaskNode
{
public:
    FName UndermineTargetKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName UndermineLocationImpactName; // 0x74 (Size: 0x4, Type: NameProperty)
    FName UndermineExecutionStatusKeyName; // 0x78 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_7c[0xc]; // 0x7c (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_Undermine) == 0x88, "Size mismatch for UFortAthenaBTTask_Undermine");
static_assert(offsetof(UFortAthenaBTTask_Undermine, UndermineTargetKeyName) == 0x70, "Offset mismatch for UFortAthenaBTTask_Undermine::UndermineTargetKeyName");
static_assert(offsetof(UFortAthenaBTTask_Undermine, UndermineLocationImpactName) == 0x74, "Offset mismatch for UFortAthenaBTTask_Undermine::UndermineLocationImpactName");
static_assert(offsetof(UFortAthenaBTTask_Undermine, UndermineExecutionStatusKeyName) == 0x78, "Offset mismatch for UFortAthenaBTTask_Undermine::UndermineExecutionStatusKeyName");

// Size: 0xf0 (Inherited: 0xf0, Single: 0x0)
class UFortAthenaBTTask_UseItem : public UBTTaskNode
{
public:
    FName ActionObjectKeyName; // 0x70 (Size: 0x4, Type: NameProperty)
    FName ExecutionStatusKeyName; // 0x74 (Size: 0x4, Type: NameProperty)
    FName UseItemSelectNewWeaponName; // 0x78 (Size: 0x4, Type: NameProperty)
    FValueOrBBKey_Float MinimumWaitTimeBetweenUses; // 0x7c (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float MaximumWaitTimeBetweenUses; // 0x88 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ValidateAbility; // 0x94 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ValidateAbilityBeforeEquipping; // 0xa0 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool ResetActionObjectKey; // 0xac (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool UseAlternateMode; // 0xb8 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool FinishAfterItemUse; // 0xc4 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Bool UnequipAndRemoveAfterItemUse; // 0xd0 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_dc[0x8]; // 0xdc (Size: 0x8, Type: PaddingProperty)
    float MinWaitTimeBetweenUses; // 0xe4 (Size: 0x4, Type: FloatProperty)
    float MaxWaitTimeBetweenUses; // 0xe8 (Size: 0x4, Type: FloatProperty)
    bool bValidateAbility; // 0xec (Size: 0x1, Type: BoolProperty)
    bool bResetActionObjectKey; // 0xed (Size: 0x1, Type: BoolProperty)
    bool bUseAlternateMode; // 0xee (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ef[0x1]; // 0xef (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_UseItem) == 0xf0, "Size mismatch for UFortAthenaBTTask_UseItem");
static_assert(offsetof(UFortAthenaBTTask_UseItem, ActionObjectKeyName) == 0x70, "Offset mismatch for UFortAthenaBTTask_UseItem::ActionObjectKeyName");
static_assert(offsetof(UFortAthenaBTTask_UseItem, ExecutionStatusKeyName) == 0x74, "Offset mismatch for UFortAthenaBTTask_UseItem::ExecutionStatusKeyName");
static_assert(offsetof(UFortAthenaBTTask_UseItem, UseItemSelectNewWeaponName) == 0x78, "Offset mismatch for UFortAthenaBTTask_UseItem::UseItemSelectNewWeaponName");
static_assert(offsetof(UFortAthenaBTTask_UseItem, MinimumWaitTimeBetweenUses) == 0x7c, "Offset mismatch for UFortAthenaBTTask_UseItem::MinimumWaitTimeBetweenUses");
static_assert(offsetof(UFortAthenaBTTask_UseItem, MaximumWaitTimeBetweenUses) == 0x88, "Offset mismatch for UFortAthenaBTTask_UseItem::MaximumWaitTimeBetweenUses");
static_assert(offsetof(UFortAthenaBTTask_UseItem, ValidateAbility) == 0x94, "Offset mismatch for UFortAthenaBTTask_UseItem::ValidateAbility");
static_assert(offsetof(UFortAthenaBTTask_UseItem, ValidateAbilityBeforeEquipping) == 0xa0, "Offset mismatch for UFortAthenaBTTask_UseItem::ValidateAbilityBeforeEquipping");
static_assert(offsetof(UFortAthenaBTTask_UseItem, ResetActionObjectKey) == 0xac, "Offset mismatch for UFortAthenaBTTask_UseItem::ResetActionObjectKey");
static_assert(offsetof(UFortAthenaBTTask_UseItem, UseAlternateMode) == 0xb8, "Offset mismatch for UFortAthenaBTTask_UseItem::UseAlternateMode");
static_assert(offsetof(UFortAthenaBTTask_UseItem, FinishAfterItemUse) == 0xc4, "Offset mismatch for UFortAthenaBTTask_UseItem::FinishAfterItemUse");
static_assert(offsetof(UFortAthenaBTTask_UseItem, UnequipAndRemoveAfterItemUse) == 0xd0, "Offset mismatch for UFortAthenaBTTask_UseItem::UnequipAndRemoveAfterItemUse");
static_assert(offsetof(UFortAthenaBTTask_UseItem, MinWaitTimeBetweenUses) == 0xe4, "Offset mismatch for UFortAthenaBTTask_UseItem::MinWaitTimeBetweenUses");
static_assert(offsetof(UFortAthenaBTTask_UseItem, MaxWaitTimeBetweenUses) == 0xe8, "Offset mismatch for UFortAthenaBTTask_UseItem::MaxWaitTimeBetweenUses");
static_assert(offsetof(UFortAthenaBTTask_UseItem, bValidateAbility) == 0xec, "Offset mismatch for UFortAthenaBTTask_UseItem::bValidateAbility");
static_assert(offsetof(UFortAthenaBTTask_UseItem, bResetActionObjectKey) == 0xed, "Offset mismatch for UFortAthenaBTTask_UseItem::bResetActionObjectKey");
static_assert(offsetof(UFortAthenaBTTask_UseItem, bUseAlternateMode) == 0xee, "Offset mismatch for UFortAthenaBTTask_UseItem::bUseAlternateMode");

// Size: 0xa8 (Inherited: 0xf0, Single: 0xffffffb8)
class UFortAthenaBTTask_UseSmartObject : public UBTTaskNode
{
public:
    FGameplayTag EvaluationTag; // 0x70 (Size: 0x4, Type: StructProperty)
    FValueOrBBKey_Bool AddFocusAndWait; // 0x74 (Size: 0xc, Type: StructProperty)
    FName SmartObjectsStatusKeyName; // 0x80 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
    FName SmartObjectDestinationRotationKeyName; // 0x88 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_8c[0x2]; // 0x8c (Size: 0x2, Type: PaddingProperty)
    bool bHandleAbortWithSoftDisable; // 0x8e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8f[0x19]; // 0x8f (Size: 0x19, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_UseSmartObject) == 0xa8, "Size mismatch for UFortAthenaBTTask_UseSmartObject");
static_assert(offsetof(UFortAthenaBTTask_UseSmartObject, EvaluationTag) == 0x70, "Offset mismatch for UFortAthenaBTTask_UseSmartObject::EvaluationTag");
static_assert(offsetof(UFortAthenaBTTask_UseSmartObject, AddFocusAndWait) == 0x74, "Offset mismatch for UFortAthenaBTTask_UseSmartObject::AddFocusAndWait");
static_assert(offsetof(UFortAthenaBTTask_UseSmartObject, SmartObjectsStatusKeyName) == 0x80, "Offset mismatch for UFortAthenaBTTask_UseSmartObject::SmartObjectsStatusKeyName");
static_assert(offsetof(UFortAthenaBTTask_UseSmartObject, SmartObjectDestinationRotationKeyName) == 0x88, "Offset mismatch for UFortAthenaBTTask_UseSmartObject::SmartObjectDestinationRotationKeyName");
static_assert(offsetof(UFortAthenaBTTask_UseSmartObject, bHandleAbortWithSoftDisable) == 0x8e, "Offset mismatch for UFortAthenaBTTask_UseSmartObject::bHandleAbortWithSoftDisable");

// Size: 0x80 (Inherited: 0xf0, Single: 0xffffff90)
class UFortAthenaBTTask_VehicleHonk : public UBTTaskNode
{
public:
    float MaxHonkTime; // 0x70 (Size: 0x4, Type: FloatProperty)
    float MinHonkTime; // 0x74 (Size: 0x4, Type: FloatProperty)
    float MaxFlickerTime; // 0x78 (Size: 0x4, Type: FloatProperty)
    float MinFlickerTime; // 0x7c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UFortAthenaBTTask_VehicleHonk) == 0x80, "Size mismatch for UFortAthenaBTTask_VehicleHonk");
static_assert(offsetof(UFortAthenaBTTask_VehicleHonk, MaxHonkTime) == 0x70, "Offset mismatch for UFortAthenaBTTask_VehicleHonk::MaxHonkTime");
static_assert(offsetof(UFortAthenaBTTask_VehicleHonk, MinHonkTime) == 0x74, "Offset mismatch for UFortAthenaBTTask_VehicleHonk::MinHonkTime");
static_assert(offsetof(UFortAthenaBTTask_VehicleHonk, MaxFlickerTime) == 0x78, "Offset mismatch for UFortAthenaBTTask_VehicleHonk::MaxFlickerTime");
static_assert(offsetof(UFortAthenaBTTask_VehicleHonk, MinFlickerTime) == 0x7c, "Offset mismatch for UFortAthenaBTTask_VehicleHonk::MinFlickerTime");

// Size: 0xa0 (Inherited: 0x188, Single: 0xffffff18)
class UFortAthenaBTTask_VehicleTurnTo : public UBTTask_BlackboardBase
{
public:
    float Precision; // 0x98 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaBTTask_VehicleTurnTo) == 0xa0, "Size mismatch for UFortAthenaBTTask_VehicleTurnTo");
static_assert(offsetof(UFortAthenaBTTask_VehicleTurnTo, Precision) == 0x98, "Offset mismatch for UFortAthenaBTTask_VehicleTurnTo::Precision");

// Size: 0x80 (Inherited: 0xf0, Single: 0xffffff90)
class UFortAthenaBTTask_Zipline : public UBTTaskNode
{
public:
    FName UsageExecutionStatusName; // 0x70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    FName ZiplineTargetName; // 0x78 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)

public:
    void OnZiplineStateChanged(bool& bIsZiplining, AFortPlayerPawn*& FortPlayerPawn); // 0xefdc220 (Index: 0x0, Flags: Final|Native|Public)
};

static_assert(sizeof(UFortAthenaBTTask_Zipline) == 0x80, "Size mismatch for UFortAthenaBTTask_Zipline");
static_assert(offsetof(UFortAthenaBTTask_Zipline, UsageExecutionStatusName) == 0x70, "Offset mismatch for UFortAthenaBTTask_Zipline::UsageExecutionStatusName");
static_assert(offsetof(UFortAthenaBTTask_Zipline, ZiplineTargetName) == 0x78, "Offset mismatch for UFortAthenaBTTask_Zipline::ZiplineTargetName");

// Size: 0x448 (Inherited: 0x3f0, Single: 0x58)
class UFortAthenaNpcEvaluator_Encampment : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FScalableFloat EncampmentEnable; // 0x1a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat EncampmentTentativeDelayMin; // 0x1c8 (Size: 0x28, Type: StructProperty)
    FScalableFloat EncampmentTentativeDelayMax; // 0x1f0 (Size: 0x28, Type: StructProperty)
    FScalableFloat EncampmentDurationMin; // 0x218 (Size: 0x28, Type: StructProperty)
    FScalableFloat EncampmentDurationMax; // 0x240 (Size: 0x28, Type: StructProperty)
    FScalableFloat BuilderPercentage; // 0x268 (Size: 0x28, Type: StructProperty)
    FScalableFloat BuilderMinDistance; // 0x290 (Size: 0x28, Type: StructProperty)
    FScalableFloat BuilderMaxDistance; // 0x2b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat GuardMinDistance; // 0x2e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat GuardMaxDistance; // 0x308 (Size: 0x28, Type: StructProperty)
    FScalableFloat AllowInSwimming; // 0x330 (Size: 0x28, Type: StructProperty)
    FScalableFloat AllowInFalling; // 0x358 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinSquadMembersCountToBuild; // 0x380 (Size: 0x28, Type: StructProperty)
    FName EncampmentStatusKeyName; // 0x3a8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3ac[0x4]; // 0x3ac (Size: 0x4, Type: PaddingProperty)
    FName EncampmentMovementStateKeyName; // 0x3b0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3b4[0x4]; // 0x3b4 (Size: 0x4, Type: PaddingProperty)
    FName EncampmentCenterLocationKeyName; // 0x3b8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3bc[0x4]; // 0x3bc (Size: 0x4, Type: PaddingProperty)
    FName EncampmentDestinationKeyName; // 0x3c0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3c4[0x4]; // 0x3c4 (Size: 0x4, Type: PaddingProperty)
    FName EncampmentAroundCampFireLocationKeyName; // 0x3c8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3cc[0x4]; // 0x3cc (Size: 0x4, Type: PaddingProperty)
    FName EncampmentRoleKeyName; // 0x3d0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3d4[0x4]; // 0x3d4 (Size: 0x4, Type: PaddingProperty)
    FName DefensiveBuildName; // 0x3d8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3dc[0x6c]; // 0x3dc (Size: 0x6c, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaNpcEvaluator_Encampment) == 0x448, "Size mismatch for UFortAthenaNpcEvaluator_Encampment");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, EncampmentEnable) == 0x1a0, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::EncampmentEnable");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, EncampmentTentativeDelayMin) == 0x1c8, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::EncampmentTentativeDelayMin");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, EncampmentTentativeDelayMax) == 0x1f0, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::EncampmentTentativeDelayMax");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, EncampmentDurationMin) == 0x218, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::EncampmentDurationMin");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, EncampmentDurationMax) == 0x240, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::EncampmentDurationMax");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, BuilderPercentage) == 0x268, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::BuilderPercentage");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, BuilderMinDistance) == 0x290, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::BuilderMinDistance");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, BuilderMaxDistance) == 0x2b8, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::BuilderMaxDistance");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, GuardMinDistance) == 0x2e0, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::GuardMinDistance");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, GuardMaxDistance) == 0x308, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::GuardMaxDistance");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, AllowInSwimming) == 0x330, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::AllowInSwimming");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, AllowInFalling) == 0x358, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::AllowInFalling");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, MinSquadMembersCountToBuild) == 0x380, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::MinSquadMembersCountToBuild");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, EncampmentStatusKeyName) == 0x3a8, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::EncampmentStatusKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, EncampmentMovementStateKeyName) == 0x3b0, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::EncampmentMovementStateKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, EncampmentCenterLocationKeyName) == 0x3b8, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::EncampmentCenterLocationKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, EncampmentDestinationKeyName) == 0x3c0, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::EncampmentDestinationKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, EncampmentAroundCampFireLocationKeyName) == 0x3c8, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::EncampmentAroundCampFireLocationKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, EncampmentRoleKeyName) == 0x3d0, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::EncampmentRoleKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Encampment, DefensiveBuildName) == 0x3d8, "Offset mismatch for UFortAthenaNpcEvaluator_Encampment::DefensiveBuildName");

// Size: 0x1d8 (Inherited: 0x3f0, Single: 0xfffffde8)
class UFortAthenaNpcEvaluator_FollowPatrolPath : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName FollowPatrolPathKeyName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName FollowPatrolPathMovementStateKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName FollowPatrolPathDestinationKeyName; // 0x1a8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1ac[0x8]; // 0x1ac (Size: 0x8, Type: PaddingProperty)
    float ChanceToTakeABreak; // 0x1b4 (Size: 0x4, Type: FloatProperty)
    float BreakDurationMin; // 0x1b8 (Size: 0x4, Type: FloatProperty)
    float BreakDurationMax; // 0x1bc (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c0[0x18]; // 0x1c0 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaNpcEvaluator_FollowPatrolPath) == 0x1d8, "Size mismatch for UFortAthenaNpcEvaluator_FollowPatrolPath");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowPatrolPath, FollowPatrolPathKeyName) == 0x1a0, "Offset mismatch for UFortAthenaNpcEvaluator_FollowPatrolPath::FollowPatrolPathKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowPatrolPath, FollowPatrolPathMovementStateKeyName) == 0x1a4, "Offset mismatch for UFortAthenaNpcEvaluator_FollowPatrolPath::FollowPatrolPathMovementStateKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowPatrolPath, FollowPatrolPathDestinationKeyName) == 0x1a8, "Offset mismatch for UFortAthenaNpcEvaluator_FollowPatrolPath::FollowPatrolPathDestinationKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowPatrolPath, ChanceToTakeABreak) == 0x1b4, "Offset mismatch for UFortAthenaNpcEvaluator_FollowPatrolPath::ChanceToTakeABreak");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowPatrolPath, BreakDurationMin) == 0x1b8, "Offset mismatch for UFortAthenaNpcEvaluator_FollowPatrolPath::BreakDurationMin");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowPatrolPath, BreakDurationMax) == 0x1bc, "Offset mismatch for UFortAthenaNpcEvaluator_FollowPatrolPath::BreakDurationMax");

// Size: 0x2f0 (Inherited: 0x3f0, Single: 0xffffff00)
class UFortAthenaNpcEvaluator_FollowSquadLeader : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FScalableFloat FormationOffsetRadiusMin; // 0x1a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat FormationOffsetRadiusMax; // 0x1c8 (Size: 0x28, Type: StructProperty)
    FScalableFloat TooFarFromSquadLeaderDistance; // 0x1f0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxNoiseRadius; // 0x218 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinDurationNoiseEvaluate; // 0x240 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxDurationNoiseEvaluate; // 0x268 (Size: 0x28, Type: StructProperty)
    FName FollowSquadLeaderStatusKeyName; // 0x290 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_294[0x4]; // 0x294 (Size: 0x4, Type: PaddingProperty)
    FName FollowSquadLeaderMovementStateKeyName; // 0x298 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_29c[0x4]; // 0x29c (Size: 0x4, Type: PaddingProperty)
    FName FollowSquadLeaderDestinationKeyName; // 0x2a0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_2a4[0x4]; // 0x2a4 (Size: 0x4, Type: PaddingProperty)
    FName TooFarFromLeaderKeyName; // 0x2a8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_2ac[0x4]; // 0x2ac (Size: 0x4, Type: PaddingProperty)
    FVector CachedSquadFormationOffset; // 0x2b0 (Size: 0x18, Type: StructProperty)
    FVector CachedNoiseOffset; // 0x2c8 (Size: 0x18, Type: StructProperty)
    float CachedTooFarFromSquadLeaderDistanceSqr; // 0x2e0 (Size: 0x4, Type: FloatProperty)
    float LastNoiseOffsetUpdateTime; // 0x2e4 (Size: 0x4, Type: FloatProperty)
    float DurationNoiseEvaluate; // 0x2e8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2ec[0x4]; // 0x2ec (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaNpcEvaluator_FollowSquadLeader) == 0x2f0, "Size mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, FormationOffsetRadiusMin) == 0x1a0, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::FormationOffsetRadiusMin");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, FormationOffsetRadiusMax) == 0x1c8, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::FormationOffsetRadiusMax");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, TooFarFromSquadLeaderDistance) == 0x1f0, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::TooFarFromSquadLeaderDistance");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, MaxNoiseRadius) == 0x218, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::MaxNoiseRadius");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, MinDurationNoiseEvaluate) == 0x240, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::MinDurationNoiseEvaluate");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, MaxDurationNoiseEvaluate) == 0x268, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::MaxDurationNoiseEvaluate");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, FollowSquadLeaderStatusKeyName) == 0x290, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::FollowSquadLeaderStatusKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, FollowSquadLeaderMovementStateKeyName) == 0x298, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::FollowSquadLeaderMovementStateKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, FollowSquadLeaderDestinationKeyName) == 0x2a0, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::FollowSquadLeaderDestinationKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, TooFarFromLeaderKeyName) == 0x2a8, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::TooFarFromLeaderKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, CachedSquadFormationOffset) == 0x2b0, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::CachedSquadFormationOffset");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, CachedNoiseOffset) == 0x2c8, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::CachedNoiseOffset");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, CachedTooFarFromSquadLeaderDistanceSqr) == 0x2e0, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::CachedTooFarFromSquadLeaderDistanceSqr");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, LastNoiseOffsetUpdateTime) == 0x2e4, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::LastNoiseOffsetUpdateTime");
static_assert(offsetof(UFortAthenaNpcEvaluator_FollowSquadLeader, DurationNoiseEvaluate) == 0x2e8, "Offset mismatch for UFortAthenaNpcEvaluator_FollowSquadLeader::DurationNoiseEvaluate");

// Size: 0x1e0 (Inherited: 0x3f0, Single: 0xfffffdf0)
class UFortAthenaNpcEvaluator_Leash : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName LeashKeyName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName LeashMovementStateKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName LeashDestinationKeyName; // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName LeashLocationKeyName; // 0x1ac (Size: 0x4, Type: NameProperty)
    FName LeashOuterRadiusKeyName; // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName ShouldTeleportInLeashKeyName; // 0x1b4 (Size: 0x4, Type: NameProperty)
    FName TriggerLeashBehaviorKeyName; // 0x1b8 (Size: 0x4, Type: NameProperty)
    bool bAlwaysForceMoveToLeashCenter; // 0x1bc (Size: 0x1, Type: BoolProperty)
    bool bForcePositionOnLeash; // 0x1bd (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1be[0x2]; // 0x1be (Size: 0x2, Type: PaddingProperty)
    UClass* AvoidObstaclesFilterClass; // 0x1c0 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_1c8[0x10]; // 0x1c8 (Size: 0x10, Type: PaddingProperty)
    UFortAthenaAIRuntimeParameters_Leash* LeashRuntimeParameters; // 0x1d8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortAthenaNpcEvaluator_Leash) == 0x1e0, "Size mismatch for UFortAthenaNpcEvaluator_Leash");
static_assert(offsetof(UFortAthenaNpcEvaluator_Leash, LeashKeyName) == 0x1a0, "Offset mismatch for UFortAthenaNpcEvaluator_Leash::LeashKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Leash, LeashMovementStateKeyName) == 0x1a4, "Offset mismatch for UFortAthenaNpcEvaluator_Leash::LeashMovementStateKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Leash, LeashDestinationKeyName) == 0x1a8, "Offset mismatch for UFortAthenaNpcEvaluator_Leash::LeashDestinationKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Leash, LeashLocationKeyName) == 0x1ac, "Offset mismatch for UFortAthenaNpcEvaluator_Leash::LeashLocationKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Leash, LeashOuterRadiusKeyName) == 0x1b0, "Offset mismatch for UFortAthenaNpcEvaluator_Leash::LeashOuterRadiusKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Leash, ShouldTeleportInLeashKeyName) == 0x1b4, "Offset mismatch for UFortAthenaNpcEvaluator_Leash::ShouldTeleportInLeashKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Leash, TriggerLeashBehaviorKeyName) == 0x1b8, "Offset mismatch for UFortAthenaNpcEvaluator_Leash::TriggerLeashBehaviorKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Leash, bAlwaysForceMoveToLeashCenter) == 0x1bc, "Offset mismatch for UFortAthenaNpcEvaluator_Leash::bAlwaysForceMoveToLeashCenter");
static_assert(offsetof(UFortAthenaNpcEvaluator_Leash, bForcePositionOnLeash) == 0x1bd, "Offset mismatch for UFortAthenaNpcEvaluator_Leash::bForcePositionOnLeash");
static_assert(offsetof(UFortAthenaNpcEvaluator_Leash, AvoidObstaclesFilterClass) == 0x1c0, "Offset mismatch for UFortAthenaNpcEvaluator_Leash::AvoidObstaclesFilterClass");
static_assert(offsetof(UFortAthenaNpcEvaluator_Leash, LeashRuntimeParameters) == 0x1d8, "Offset mismatch for UFortAthenaNpcEvaluator_Leash::LeashRuntimeParameters");

// Size: 0x1f0 (Inherited: 0x3f0, Single: 0xfffffe00)
class UFortAthenaNpcEvaluator_Patrolling : public UFortAthenaAIBotEvaluator_Movement
{
public:
    FName PatrollingKeyName; // 0x1a0 (Size: 0x4, Type: NameProperty)
    FName PatrollingMovementStateKeyName; // 0x1a4 (Size: 0x4, Type: NameProperty)
    FName PatrollingDestinationKeyName; // 0x1a8 (Size: 0x4, Type: NameProperty)
    FName DynamicBlueprintStatusKeyName; // 0x1ac (Size: 0x4, Type: NameProperty)
    FName DynamicBlueprintActorKeyName; // 0x1b0 (Size: 0x4, Type: NameProperty)
    FName PatrollingShouldMoveKeyName; // 0x1b4 (Size: 0x4, Type: NameProperty)
    FName PatrollingAppendDestinationKeyName; // 0x1b8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1bc[0x10]; // 0x1bc (Size: 0x10, Type: PaddingProperty)
    float DistanceToTestPoint; // 0x1cc (Size: 0x4, Type: FloatProperty)
    bool bCanDisablePatrolling; // 0x1d0 (Size: 0x1, Type: BoolProperty)
    bool bCanReenablePatrolling; // 0x1d1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d2[0x2]; // 0x1d2 (Size: 0x2, Type: PaddingProperty)
    float ReenableTimer; // 0x1d4 (Size: 0x4, Type: FloatProperty)
    bool bCanSelectNearestPatrolPointAtStart; // 0x1d8 (Size: 0x1, Type: BoolProperty)
    bool bCanRetryOnPartialPathSuccess; // 0x1d9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1da[0x6]; // 0x1da (Size: 0x6, Type: PaddingProperty)
    UFortAthenaNpcPatrollingComponent* CachedNpcPatrollingComponent; // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1e8[0x8]; // 0x1e8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaNpcEvaluator_Patrolling) == 0x1f0, "Size mismatch for UFortAthenaNpcEvaluator_Patrolling");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, PatrollingKeyName) == 0x1a0, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::PatrollingKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, PatrollingMovementStateKeyName) == 0x1a4, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::PatrollingMovementStateKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, PatrollingDestinationKeyName) == 0x1a8, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::PatrollingDestinationKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, DynamicBlueprintStatusKeyName) == 0x1ac, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::DynamicBlueprintStatusKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, DynamicBlueprintActorKeyName) == 0x1b0, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::DynamicBlueprintActorKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, PatrollingShouldMoveKeyName) == 0x1b4, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::PatrollingShouldMoveKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, PatrollingAppendDestinationKeyName) == 0x1b8, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::PatrollingAppendDestinationKeyName");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, DistanceToTestPoint) == 0x1cc, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::DistanceToTestPoint");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, bCanDisablePatrolling) == 0x1d0, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::bCanDisablePatrolling");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, bCanReenablePatrolling) == 0x1d1, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::bCanReenablePatrolling");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, ReenableTimer) == 0x1d4, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::ReenableTimer");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, bCanSelectNearestPatrolPointAtStart) == 0x1d8, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::bCanSelectNearestPatrolPointAtStart");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, bCanRetryOnPartialPathSuccess) == 0x1d9, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::bCanRetryOnPartialPathSuccess");
static_assert(offsetof(UFortAthenaNpcEvaluator_Patrolling, CachedNpcPatrollingComponent) == 0x1e0, "Offset mismatch for UFortAthenaNpcEvaluator_Patrolling::CachedNpcPatrollingComponent");

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UFortQueryContext_BotPOIVolume : public UEnvQueryContext
{
public:
    bool bSetProjectedToNavmeshLocationAsContext; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    FVector ProjectionExtent; // 0x30 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UFortQueryContext_BotPOIVolume) == 0x48, "Size mismatch for UFortQueryContext_BotPOIVolume");
static_assert(offsetof(UFortQueryContext_BotPOIVolume, bSetProjectedToNavmeshLocationAsContext) == 0x28, "Offset mismatch for UFortQueryContext_BotPOIVolume::bSetProjectedToNavmeshLocationAsContext");
static_assert(offsetof(UFortQueryContext_BotPOIVolume, ProjectionExtent) == 0x30, "Offset mismatch for UFortQueryContext_BotPOIVolume::ProjectionExtent");

// Size: 0xc8 (Inherited: 0x118, Single: 0xffffffb0)
class UFortAthenaAttachToActorStateTreeTask : public UStateTreeTaskBlueprintBase
{
public:
    AActor* Actor; // 0x80 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor; // 0x88 (Size: 0x8, Type: ObjectProperty)
    uint8_t AttachExecutionMode[0x4]; // 0x90 (Size: 0x4, Type: EnumProperty)
    bool bHandleAthenaMovComponent; // 0x94 (Size: 0x1, Type: BoolProperty)
    bool bSetPhysicsToQueryOnlyWhileAttached; // 0x95 (Size: 0x1, Type: BoolProperty)
    bool bTryToAttachToSkeletalMeshOnTargetActor; // 0x96 (Size: 0x1, Type: BoolProperty)
    bool bChangeBaseToSkeletalMeshOnTargetActor; // 0x97 (Size: 0x1, Type: BoolProperty)
    uint8_t AttachmentLocationRule; // 0x98 (Size: 0x1, Type: EnumProperty)
    uint8_t AttachmentRotationRule; // 0x99 (Size: 0x1, Type: EnumProperty)
    uint8_t AttachmentScaleRule; // 0x9a (Size: 0x1, Type: EnumProperty)
    bool bWeldSimulatedBodiesOnAttach; // 0x9b (Size: 0x1, Type: BoolProperty)
    FName AttachmentSocketName; // 0x9c (Size: 0x4, Type: NameProperty)
    uint8_t DetachExecutionMode[0x4]; // 0xa0 (Size: 0x4, Type: EnumProperty)
    bool bForceChangeBaseOnDetach; // 0xa4 (Size: 0x1, Type: BoolProperty)
    uint8_t DetachmentLocationRule; // 0xa5 (Size: 0x1, Type: EnumProperty)
    uint8_t DetachmentRotationRule; // 0xa6 (Size: 0x1, Type: EnumProperty)
    uint8_t DetachmentScaleRule; // 0xa7 (Size: 0x1, Type: EnumProperty)
    bool bCallModifyOnDetach; // 0xa8 (Size: 0x1, Type: BoolProperty)
    bool bHandleLaunchCharacter; // 0xa9 (Size: 0x1, Type: BoolProperty)
    bool bHasHandledLaunchCharacter; // 0xaa (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ab[0x5]; // 0xab (Size: 0x5, Type: PaddingProperty)
    AFortPawn* FortPawnActor; // 0xb0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_b8[0x10]; // 0xb8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFortAthenaAttachToActorStateTreeTask) == 0xc8, "Size mismatch for UFortAthenaAttachToActorStateTreeTask");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, Actor) == 0x80, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::Actor");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, TargetActor) == 0x88, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::TargetActor");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, AttachExecutionMode) == 0x90, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::AttachExecutionMode");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, bHandleAthenaMovComponent) == 0x94, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::bHandleAthenaMovComponent");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, bSetPhysicsToQueryOnlyWhileAttached) == 0x95, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::bSetPhysicsToQueryOnlyWhileAttached");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, bTryToAttachToSkeletalMeshOnTargetActor) == 0x96, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::bTryToAttachToSkeletalMeshOnTargetActor");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, bChangeBaseToSkeletalMeshOnTargetActor) == 0x97, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::bChangeBaseToSkeletalMeshOnTargetActor");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, AttachmentLocationRule) == 0x98, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::AttachmentLocationRule");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, AttachmentRotationRule) == 0x99, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::AttachmentRotationRule");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, AttachmentScaleRule) == 0x9a, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::AttachmentScaleRule");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, bWeldSimulatedBodiesOnAttach) == 0x9b, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::bWeldSimulatedBodiesOnAttach");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, AttachmentSocketName) == 0x9c, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::AttachmentSocketName");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, DetachExecutionMode) == 0xa0, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::DetachExecutionMode");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, bForceChangeBaseOnDetach) == 0xa4, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::bForceChangeBaseOnDetach");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, DetachmentLocationRule) == 0xa5, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::DetachmentLocationRule");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, DetachmentRotationRule) == 0xa6, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::DetachmentRotationRule");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, DetachmentScaleRule) == 0xa7, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::DetachmentScaleRule");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, bCallModifyOnDetach) == 0xa8, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::bCallModifyOnDetach");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, bHandleLaunchCharacter) == 0xa9, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::bHandleLaunchCharacter");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, bHasHandledLaunchCharacter) == 0xaa, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::bHasHandledLaunchCharacter");
static_assert(offsetof(UFortAthenaAttachToActorStateTreeTask, FortPawnActor) == 0xb0, "Offset mismatch for UFortAthenaAttachToActorStateTreeTask::FortPawnActor");

// Size: 0x100 (Inherited: 0x28, Single: 0xd8)
class UFortAthenaPlayContextualAnimTaskInstanceData : public UObject
{
public:
    AActor* PrimaryActor; // 0x28 (Size: 0x8, Type: ObjectProperty)
    AActor* SecondaryActor; // 0x30 (Size: 0x8, Type: ObjectProperty)
    FName SecondaryRole; // 0x38 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    AActor* TertiaryActor; // 0x40 (Size: 0x8, Type: ObjectProperty)
    FName TertiaryRole; // 0x48 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    UContextualAnimSceneAsset* SceneAsset; // 0x50 (Size: 0x8, Type: ObjectProperty)
    FName SectionName; // 0x58 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer PrimaryActorExternalTags; // 0x60 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer SecondaryActorExternalTags; // 0x80 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TertiaryActorExternalTags; // 0xa0 (Size: 0x20, Type: StructProperty)
    uint8_t ExecutionMethod; // 0xc0 (Size: 0x1, Type: EnumProperty)
    bool bWaitForNotifyEventToEnd; // 0xc1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c2[0x2]; // 0xc2 (Size: 0x2, Type: PaddingProperty)
    FName NotifyEventNameToEnd; // 0xc4 (Size: 0x4, Type: NameProperty)
    int32_t LoopsToRun; // 0xc8 (Size: 0x4, Type: IntProperty)
    bool bLoopForever; // 0xcc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_cd[0x3]; // 0xcd (Size: 0x3, Type: PaddingProperty)
    float DelayBetweenLoops; // 0xd0 (Size: 0x4, Type: FloatProperty)
    float RandomDeviationBetweenLoops; // 0xd4 (Size: 0x4, Type: FloatProperty)
    TArray<FContextualAnimWarpTarget> WarpTargets; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    bool bFindAnimSetBasedOnWarpTargets; // 0xe8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e9[0x17]; // 0xe9 (Size: 0x17, Type: PaddingProperty)

public:
    void OnMontageEnded(UContextualAnimSceneActorComponent*& SceneComponent, UAnimMontage*& const EndedMontage, bool& const bInterrupted); // 0xefdb9a0 (Index: 0x0, Flags: Final|Native|Public)
    void OnNotifyBeginReceived(FName& NotifyName, const FBranchingPointNotifyPayload BranchingPointNotifyPayload); // 0xefdbe90 (Index: 0x1, Flags: Final|Native|Public|HasOutParms)
};

static_assert(sizeof(UFortAthenaPlayContextualAnimTaskInstanceData) == 0x100, "Size mismatch for UFortAthenaPlayContextualAnimTaskInstanceData");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, PrimaryActor) == 0x28, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::PrimaryActor");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, SecondaryActor) == 0x30, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::SecondaryActor");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, SecondaryRole) == 0x38, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::SecondaryRole");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, TertiaryActor) == 0x40, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::TertiaryActor");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, TertiaryRole) == 0x48, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::TertiaryRole");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, SceneAsset) == 0x50, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::SceneAsset");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, SectionName) == 0x58, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::SectionName");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, PrimaryActorExternalTags) == 0x60, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::PrimaryActorExternalTags");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, SecondaryActorExternalTags) == 0x80, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::SecondaryActorExternalTags");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, TertiaryActorExternalTags) == 0xa0, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::TertiaryActorExternalTags");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, ExecutionMethod) == 0xc0, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::ExecutionMethod");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, bWaitForNotifyEventToEnd) == 0xc1, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::bWaitForNotifyEventToEnd");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, NotifyEventNameToEnd) == 0xc4, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::NotifyEventNameToEnd");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, LoopsToRun) == 0xc8, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::LoopsToRun");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, bLoopForever) == 0xcc, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::bLoopForever");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, DelayBetweenLoops) == 0xd0, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::DelayBetweenLoops");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, RandomDeviationBetweenLoops) == 0xd4, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::RandomDeviationBetweenLoops");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, WarpTargets) == 0xd8, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::WarpTargets");
static_assert(offsetof(UFortAthenaPlayContextualAnimTaskInstanceData, bFindAnimSetBasedOnWarpTargets) == 0xe8, "Offset mismatch for UFortAthenaPlayContextualAnimTaskInstanceData::bFindAnimSetBasedOnWarpTargets");

// Size: 0x100 (Inherited: 0x118, Single: 0xffffffe8)
class UFortAthenaPlayInteractionStateTreeTask : public UStateTreeTaskBlueprintBase
{
public:
    AActor* InteractorActor; // 0x80 (Size: 0x8, Type: ObjectProperty)
    AActor* InteractableActor; // 0x88 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* InteractorMontage; // 0x90 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* InteractableMontage; // 0x98 (Size: 0x8, Type: ObjectProperty)
    bool bWaitForNotifyEventToEnd; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0x3]; // 0xa1 (Size: 0x3, Type: PaddingProperty)
    FName NotifyEventNameToEnd; // 0xa4 (Size: 0x4, Type: NameProperty)
    bool bAddMotionWarpingTargets; // 0xa8 (Size: 0x1, Type: BoolProperty)
    bool bDisableCollisionBetweenActors; // 0xa9 (Size: 0x1, Type: BoolProperty)
    bool bSetMovementModeToFlying; // 0xaa (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ab[0x1]; // 0xab (Size: 0x1, Type: PaddingProperty)
    int32_t LoopsToRun; // 0xac (Size: 0x4, Type: IntProperty)
    bool bLoopForever; // 0xb0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b1[0x3]; // 0xb1 (Size: 0x3, Type: PaddingProperty)
    float DelayBetweenLoops; // 0xb4 (Size: 0x4, Type: FloatProperty)
    float RandomDeviationBetweenLoops; // 0xb8 (Size: 0x4, Type: FloatProperty)
    bool bStopInteractorAnimMontageOnExit; // 0xbc (Size: 0x1, Type: BoolProperty)
    bool bStopInteractableAnimMontageOnExit; // 0xbd (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_be[0x42]; // 0xbe (Size: 0x42, Type: PaddingProperty)

private:
    void OnMontageEnded(UAnimMontage*& const EndedMontage, bool& const bInterrupted); // 0xefdbc84 (Index: 0x0, Flags: Final|Native|Private)
    void OnNotifyBeginReceived(FName& NotifyName, const FBranchingPointNotifyPayload BranchingPointNotifyPayload); // 0xefdc058 (Index: 0x1, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UFortAthenaPlayInteractionStateTreeTask) == 0x100, "Size mismatch for UFortAthenaPlayInteractionStateTreeTask");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, InteractorActor) == 0x80, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::InteractorActor");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, InteractableActor) == 0x88, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::InteractableActor");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, InteractorMontage) == 0x90, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::InteractorMontage");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, InteractableMontage) == 0x98, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::InteractableMontage");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, bWaitForNotifyEventToEnd) == 0xa0, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::bWaitForNotifyEventToEnd");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, NotifyEventNameToEnd) == 0xa4, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::NotifyEventNameToEnd");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, bAddMotionWarpingTargets) == 0xa8, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::bAddMotionWarpingTargets");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, bDisableCollisionBetweenActors) == 0xa9, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::bDisableCollisionBetweenActors");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, bSetMovementModeToFlying) == 0xaa, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::bSetMovementModeToFlying");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, LoopsToRun) == 0xac, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::LoopsToRun");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, bLoopForever) == 0xb0, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::bLoopForever");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, DelayBetweenLoops) == 0xb4, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::DelayBetweenLoops");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, RandomDeviationBetweenLoops) == 0xb8, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::RandomDeviationBetweenLoops");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, bStopInteractorAnimMontageOnExit) == 0xbc, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::bStopInteractorAnimMontageOnExit");
static_assert(offsetof(UFortAthenaPlayInteractionStateTreeTask, bStopInteractableAnimMontageOnExit) == 0xbd, "Offset mismatch for UFortAthenaPlayInteractionStateTreeTask::bStopInteractableAnimMontageOnExit");

// Size: 0xe8 (Inherited: 0x118, Single: 0xffffffd0)
class UFortAthenaPlayMontageStateTreeTask : public UStateTreeTaskBlueprintBase
{
public:
    AActor* Actor; // 0x80 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Montage; // 0x88 (Size: 0x8, Type: ObjectProperty)
    uint8_t ExecMode; // 0x90 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_91[0x3]; // 0x91 (Size: 0x3, Type: PaddingProperty)
    FName SectionName; // 0x94 (Size: 0x4, Type: NameProperty)
    uint8_t LoopMode; // 0x98 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
    TArray<FSTFortAthenaPlayMontageWarpTarget> WarpTargets; // 0xa0 (Size: 0x10, Type: ArrayProperty)
    bool bWaitForNotifyEventToEnd; // 0xb0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b1[0x3]; // 0xb1 (Size: 0x3, Type: PaddingProperty)
    FName NotifyEventNameToEnd; // 0xb4 (Size: 0x4, Type: NameProperty)
    bool bSetMovementModeToFlying; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x3]; // 0xb9 (Size: 0x3, Type: PaddingProperty)
    int32_t LoopsToRun; // 0xbc (Size: 0x4, Type: IntProperty)
    bool bLoopForever; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0x3]; // 0xc1 (Size: 0x3, Type: PaddingProperty)
    float DelayBetweenLoops; // 0xc4 (Size: 0x4, Type: FloatProperty)
    float RandomDeviationBetweenLoops; // 0xc8 (Size: 0x4, Type: FloatProperty)
    bool bStopAnimMontageOnExit; // 0xcc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_cd[0x1b]; // 0xcd (Size: 0x1b, Type: PaddingProperty)

private:
    void HandleMontageEnded(UAnimMontage*& const EndedMontage, bool& const bInterrupted); // 0xefdb470 (Index: 0x0, Flags: Final|Native|Private)
    void HandleNotifyBeginReceived(FName& NotifyName, const FBranchingPointNotifyPayload BranchingPointNotifyPayload); // 0xefdb67c (Index: 0x1, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UFortAthenaPlayMontageStateTreeTask) == 0xe8, "Size mismatch for UFortAthenaPlayMontageStateTreeTask");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, Actor) == 0x80, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::Actor");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, Montage) == 0x88, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::Montage");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, ExecMode) == 0x90, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::ExecMode");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, SectionName) == 0x94, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::SectionName");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, LoopMode) == 0x98, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::LoopMode");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, WarpTargets) == 0xa0, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::WarpTargets");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, bWaitForNotifyEventToEnd) == 0xb0, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::bWaitForNotifyEventToEnd");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, NotifyEventNameToEnd) == 0xb4, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::NotifyEventNameToEnd");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, bSetMovementModeToFlying) == 0xb8, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::bSetMovementModeToFlying");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, LoopsToRun) == 0xbc, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::LoopsToRun");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, bLoopForever) == 0xc0, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::bLoopForever");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, DelayBetweenLoops) == 0xc4, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::DelayBetweenLoops");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, RandomDeviationBetweenLoops) == 0xc8, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::RandomDeviationBetweenLoops");
static_assert(offsetof(UFortAthenaPlayMontageStateTreeTask, bStopAnimMontageOnExit) == 0xcc, "Offset mismatch for UFortAthenaPlayMontageStateTreeTask::bStopAnimMontageOnExit");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UFortWorldConditionPlaylist_State : public UObject
{
public:
};

static_assert(sizeof(UFortWorldConditionPlaylist_State) == 0x40, "Size mismatch for UFortWorldConditionPlaylist_State");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UFortWorldConditionWorldState_State : public UObject
{
public:

private:
    void HandleWorldStateChanged(const FGameplayTag WorldStateTag, bool& bAdded); // 0xefdb844 (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UFortWorldConditionWorldState_State) == 0x48, "Size mismatch for UFortWorldConditionWorldState_State");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FBotEvaluatorCommandCooldown
{
    FFortAIActiveCommandSOUsageData Command; // 0x0 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_10[0x4]; // 0x10 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FBotEvaluatorCommandCooldown) == 0x14, "Size mismatch for FBotEvaluatorCommandCooldown");
static_assert(offsetof(FBotEvaluatorCommandCooldown, Command) == 0x0, "Offset mismatch for FBotEvaluatorCommandCooldown::Command");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FBotEvaluatorSmartObjectConvertedData
{
    USmartObjectComponent* SmartObjectComponent; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FBotEvaluatorSmartObjectConvertedData) == 0x8, "Size mismatch for FBotEvaluatorSmartObjectConvertedData");
static_assert(offsetof(FBotEvaluatorSmartObjectConvertedData, SmartObjectComponent) == 0x0, "Offset mismatch for FBotEvaluatorSmartObjectConvertedData::SmartObjectComponent");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FTokenEQSParameter
{
    FName ParamName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t ParamType; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    float DefaultValue; // 0x8 (Size: 0x4, Type: FloatProperty)
    FName BlackboardKeyName; // 0xc (Size: 0x4, Type: NameProperty)
    uint8_t Pad_10[0x4]; // 0x10 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FTokenEQSParameter) == 0x14, "Size mismatch for FTokenEQSParameter");
static_assert(offsetof(FTokenEQSParameter, ParamName) == 0x0, "Offset mismatch for FTokenEQSParameter::ParamName");
static_assert(offsetof(FTokenEQSParameter, ParamType) == 0x4, "Offset mismatch for FTokenEQSParameter::ParamType");
static_assert(offsetof(FTokenEQSParameter, DefaultValue) == 0x8, "Offset mismatch for FTokenEQSParameter::DefaultValue");
static_assert(offsetof(FTokenEQSParameter, BlackboardKeyName) == 0xc, "Offset mismatch for FTokenEQSParameter::BlackboardKeyName");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FPositioningEQS
{
    FGameplayTagQuery ItemTagQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    UEnvQuery* QueryTemplate; // 0x48 (Size: 0x8, Type: ObjectProperty)
    TArray<FTokenEQSParameter> QueryConfig; // 0x50 (Size: 0x10, Type: ArrayProperty)
    bool bAllowStayingOnSamePosition; // 0x60 (Size: 0x1, Type: BoolProperty)
    bool bRequestNewPosititonOnProviderRecomputed; // 0x61 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_62[0x2]; // 0x62 (Size: 0x2, Type: PaddingProperty)
    FValueOrBBKey_Bool AllowStayingOnSamePosition; // 0x64 (Size: 0xc, Type: StructProperty)
    FValueOrBBKey_Float TimerForNewPositionOnProviderRecomputed; // 0x70 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FPositioningEQS) == 0x80, "Size mismatch for FPositioningEQS");
static_assert(offsetof(FPositioningEQS, ItemTagQuery) == 0x0, "Offset mismatch for FPositioningEQS::ItemTagQuery");
static_assert(offsetof(FPositioningEQS, QueryTemplate) == 0x48, "Offset mismatch for FPositioningEQS::QueryTemplate");
static_assert(offsetof(FPositioningEQS, QueryConfig) == 0x50, "Offset mismatch for FPositioningEQS::QueryConfig");
static_assert(offsetof(FPositioningEQS, bAllowStayingOnSamePosition) == 0x60, "Offset mismatch for FPositioningEQS::bAllowStayingOnSamePosition");
static_assert(offsetof(FPositioningEQS, bRequestNewPosititonOnProviderRecomputed) == 0x61, "Offset mismatch for FPositioningEQS::bRequestNewPosititonOnProviderRecomputed");
static_assert(offsetof(FPositioningEQS, AllowStayingOnSamePosition) == 0x64, "Offset mismatch for FPositioningEQS::AllowStayingOnSamePosition");
static_assert(offsetof(FPositioningEQS, TimerForNewPositionOnProviderRecomputed) == 0x70, "Offset mismatch for FPositioningEQS::TimerForNewPositionOnProviderRecomputed");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FFortAthenaAIEvaluator_LookAt_AbstractConfiguration
{
    int32_t DiceRollingPercentage; // 0x0 (Size: 0x4, Type: IntProperty)
    float DiceRollingFailCooldown; // 0x4 (Size: 0x4, Type: FloatProperty)
    float UtilityWeightMultiplier; // 0x8 (Size: 0x4, Type: FloatProperty)
    float UtilityWeightAddition; // 0xc (Size: 0x4, Type: FloatProperty)
    FVector2D ConfigurationCooldownRange; // 0x10 (Size: 0x10, Type: StructProperty)
    FVector2D ActorCooldownRange; // 0x20 (Size: 0x10, Type: StructProperty)
    FVector2D MaxDurationRange; // 0x30 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FFortAthenaAIEvaluator_LookAt_AbstractConfiguration) == 0x40, "Size mismatch for FFortAthenaAIEvaluator_LookAt_AbstractConfiguration");
static_assert(offsetof(FFortAthenaAIEvaluator_LookAt_AbstractConfiguration, DiceRollingPercentage) == 0x0, "Offset mismatch for FFortAthenaAIEvaluator_LookAt_AbstractConfiguration::DiceRollingPercentage");
static_assert(offsetof(FFortAthenaAIEvaluator_LookAt_AbstractConfiguration, DiceRollingFailCooldown) == 0x4, "Offset mismatch for FFortAthenaAIEvaluator_LookAt_AbstractConfiguration::DiceRollingFailCooldown");
static_assert(offsetof(FFortAthenaAIEvaluator_LookAt_AbstractConfiguration, UtilityWeightMultiplier) == 0x8, "Offset mismatch for FFortAthenaAIEvaluator_LookAt_AbstractConfiguration::UtilityWeightMultiplier");
static_assert(offsetof(FFortAthenaAIEvaluator_LookAt_AbstractConfiguration, UtilityWeightAddition) == 0xc, "Offset mismatch for FFortAthenaAIEvaluator_LookAt_AbstractConfiguration::UtilityWeightAddition");
static_assert(offsetof(FFortAthenaAIEvaluator_LookAt_AbstractConfiguration, ConfigurationCooldownRange) == 0x10, "Offset mismatch for FFortAthenaAIEvaluator_LookAt_AbstractConfiguration::ConfigurationCooldownRange");
static_assert(offsetof(FFortAthenaAIEvaluator_LookAt_AbstractConfiguration, ActorCooldownRange) == 0x20, "Offset mismatch for FFortAthenaAIEvaluator_LookAt_AbstractConfiguration::ActorCooldownRange");
static_assert(offsetof(FFortAthenaAIEvaluator_LookAt_AbstractConfiguration, MaxDurationRange) == 0x30, "Offset mismatch for FFortAthenaAIEvaluator_LookAt_AbstractConfiguration::MaxDurationRange");

// Size: 0x100 (Inherited: 0x40, Single: 0xc0)
struct FFortAthenaAIEvaluator_LookAt_PawnConfiguration : FFortAthenaAIEvaluator_LookAt_AbstractConfiguration
{
    FFortNearbyActorsPerceptionConfiguration PerceptionConfiguration; // 0x40 (Size: 0xc0, Type: StructProperty)
};

static_assert(sizeof(FFortAthenaAIEvaluator_LookAt_PawnConfiguration) == 0x100, "Size mismatch for FFortAthenaAIEvaluator_LookAt_PawnConfiguration");
static_assert(offsetof(FFortAthenaAIEvaluator_LookAt_PawnConfiguration, PerceptionConfiguration) == 0x40, "Offset mismatch for FFortAthenaAIEvaluator_LookAt_PawnConfiguration::PerceptionConfiguration");

// Size: 0x48 (Inherited: 0x40, Single: 0x8)
struct FFortAthenaAIEvaluator_LookAt_SOConfiguration : FFortAthenaAIEvaluator_LookAt_AbstractConfiguration
{
    float Max2DDistance; // 0x40 (Size: 0x4, Type: FloatProperty)
    float MaxZDistance; // 0x44 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFortAthenaAIEvaluator_LookAt_SOConfiguration) == 0x48, "Size mismatch for FFortAthenaAIEvaluator_LookAt_SOConfiguration");
static_assert(offsetof(FFortAthenaAIEvaluator_LookAt_SOConfiguration, Max2DDistance) == 0x40, "Offset mismatch for FFortAthenaAIEvaluator_LookAt_SOConfiguration::Max2DDistance");
static_assert(offsetof(FFortAthenaAIEvaluator_LookAt_SOConfiguration, MaxZDistance) == 0x44, "Offset mismatch for FFortAthenaAIEvaluator_LookAt_SOConfiguration::MaxZDistance");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FEquippedItemTagAssociationData
{
    FGameplayTagQuery ItemTagQuery; // 0x0 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery TokenSystemTagQuery; // 0x48 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FEquippedItemTagAssociationData) == 0x90, "Size mismatch for FEquippedItemTagAssociationData");
static_assert(offsetof(FEquippedItemTagAssociationData, ItemTagQuery) == 0x0, "Offset mismatch for FEquippedItemTagAssociationData::ItemTagQuery");
static_assert(offsetof(FEquippedItemTagAssociationData, TokenSystemTagQuery) == 0x48, "Offset mismatch for FEquippedItemTagAssociationData::TokenSystemTagQuery");

// Size: 0xa0 (Inherited: 0xa0, Single: 0x0)
struct FortAthenaFindSlotEntranceLocationStateTreeTask_InstanceData : FStateTreeTask_FindSlotEntranceLocation_InstanceData
{
};

static_assert(sizeof(FortAthenaFindSlotEntranceLocationStateTreeTask_InstanceData) == 0xa0, "Size mismatch for FortAthenaFindSlotEntranceLocationStateTreeTask_InstanceData");

// Size: 0x48 (Inherited: 0x98, Single: 0xffffffb0)
struct FFortAthenaFindSlotEntranceLocationStateTreeTask : FStateTreeTask_FindSlotEntranceLocation
{
    bool bPreferLocationNearActorMovementInput; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaFindSlotEntranceLocationStateTreeTask) == 0x48, "Size mismatch for FFortAthenaFindSlotEntranceLocationStateTreeTask");
static_assert(offsetof(FFortAthenaFindSlotEntranceLocationStateTreeTask, bPreferLocationNearActorMovementInput) == 0x40, "Offset mismatch for FFortAthenaFindSlotEntranceLocationStateTreeTask::bPreferLocationNearActorMovementInput");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFortAthenaHandleSoftDisableGuardStateTreeTaskInstanceData
{
    FStateTreeStructRef SoftDisableStateReference; // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<AActor*> ActorsToTeleportOnFailure; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortAthenaHandleSoftDisableGuardStateTreeTaskInstanceData) == 0x20, "Size mismatch for FFortAthenaHandleSoftDisableGuardStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaHandleSoftDisableGuardStateTreeTaskInstanceData, SoftDisableStateReference) == 0x0, "Offset mismatch for FFortAthenaHandleSoftDisableGuardStateTreeTaskInstanceData::SoftDisableStateReference");
static_assert(offsetof(FFortAthenaHandleSoftDisableGuardStateTreeTaskInstanceData, ActorsToTeleportOnFailure) == 0x10, "Offset mismatch for FFortAthenaHandleSoftDisableGuardStateTreeTaskInstanceData::ActorsToTeleportOnFailure");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortAthenaHandleSoftDisableGuardStateTreeTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortAthenaHandleSoftDisableGuardStateTreeTask) == 0x20, "Size mismatch for FFortAthenaHandleSoftDisableGuardStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortAthenaSoftDisableStateTreeParameter
{
    TArray<AActor*> ActorsToTeleportOnExit; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortAthenaSoftDisableStateTreeParameter) == 0x10, "Size mismatch for FFortAthenaSoftDisableStateTreeParameter");
static_assert(offsetof(FFortAthenaSoftDisableStateTreeParameter, ActorsToTeleportOnExit) == 0x0, "Offset mismatch for FFortAthenaSoftDisableStateTreeParameter::ActorsToTeleportOnExit");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FFortAthenaHandleSoftDisableStateTreeTaskInstanceData
{
    AActor* SmartObjectActor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<AActor*> ActorsToCleanup; // 0x8 (Size: 0x10, Type: ArrayProperty)
    bool bHasReceivedSoftDisableEvent; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
    FGameplayTag ReceivedSoftDisableEvent; // 0x1c (Size: 0x4, Type: StructProperty)
    FFortAthenaSoftDisableStateTreeParameter OutState; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FFortAthenaHandleSoftDisableStateTreeTaskInstanceData) == 0x30, "Size mismatch for FFortAthenaHandleSoftDisableStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaHandleSoftDisableStateTreeTaskInstanceData, SmartObjectActor) == 0x0, "Offset mismatch for FFortAthenaHandleSoftDisableStateTreeTaskInstanceData::SmartObjectActor");
static_assert(offsetof(FFortAthenaHandleSoftDisableStateTreeTaskInstanceData, ActorsToCleanup) == 0x8, "Offset mismatch for FFortAthenaHandleSoftDisableStateTreeTaskInstanceData::ActorsToCleanup");
static_assert(offsetof(FFortAthenaHandleSoftDisableStateTreeTaskInstanceData, bHasReceivedSoftDisableEvent) == 0x18, "Offset mismatch for FFortAthenaHandleSoftDisableStateTreeTaskInstanceData::bHasReceivedSoftDisableEvent");
static_assert(offsetof(FFortAthenaHandleSoftDisableStateTreeTaskInstanceData, ReceivedSoftDisableEvent) == 0x1c, "Offset mismatch for FFortAthenaHandleSoftDisableStateTreeTaskInstanceData::ReceivedSoftDisableEvent");
static_assert(offsetof(FFortAthenaHandleSoftDisableStateTreeTaskInstanceData, OutState) == 0x20, "Offset mismatch for FFortAthenaHandleSoftDisableStateTreeTaskInstanceData::OutState");

// Size: 0x58 (Inherited: 0x58, Single: 0x0)
struct FFortAthenaHandleSoftDisableStateTreeTask : FStateTreeTaskCommonBase
{
    FGameplayTag StateTreeEventTag; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FVector TeleportOnNavmeshQueryBoxExtents; // 0x28 (Size: 0x18, Type: StructProperty)
    int32_t MaxTeleportToTryPerActor; // 0x40 (Size: 0x4, Type: IntProperty)
    bool bEnableNavmeshTeleportForPlayers; // 0x44 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_45[0x3]; // 0x45 (Size: 0x3, Type: PaddingProperty)
    float MultiplierOnCapsuleHalfHeightForTeleportLocation; // 0x48 (Size: 0x4, Type: FloatProperty)
    float MultiplierOnCapsuleRadiusForFallbackTeleportSweepCastSize; // 0x4c (Size: 0x4, Type: FloatProperty)
    float MultiplierOnCapsuleHeightForFallbackTeleportSweepCasts; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaHandleSoftDisableStateTreeTask) == 0x58, "Size mismatch for FFortAthenaHandleSoftDisableStateTreeTask");
static_assert(offsetof(FFortAthenaHandleSoftDisableStateTreeTask, StateTreeEventTag) == 0x20, "Offset mismatch for FFortAthenaHandleSoftDisableStateTreeTask::StateTreeEventTag");
static_assert(offsetof(FFortAthenaHandleSoftDisableStateTreeTask, TeleportOnNavmeshQueryBoxExtents) == 0x28, "Offset mismatch for FFortAthenaHandleSoftDisableStateTreeTask::TeleportOnNavmeshQueryBoxExtents");
static_assert(offsetof(FFortAthenaHandleSoftDisableStateTreeTask, MaxTeleportToTryPerActor) == 0x40, "Offset mismatch for FFortAthenaHandleSoftDisableStateTreeTask::MaxTeleportToTryPerActor");
static_assert(offsetof(FFortAthenaHandleSoftDisableStateTreeTask, bEnableNavmeshTeleportForPlayers) == 0x44, "Offset mismatch for FFortAthenaHandleSoftDisableStateTreeTask::bEnableNavmeshTeleportForPlayers");
static_assert(offsetof(FFortAthenaHandleSoftDisableStateTreeTask, MultiplierOnCapsuleHalfHeightForTeleportLocation) == 0x48, "Offset mismatch for FFortAthenaHandleSoftDisableStateTreeTask::MultiplierOnCapsuleHalfHeightForTeleportLocation");
static_assert(offsetof(FFortAthenaHandleSoftDisableStateTreeTask, MultiplierOnCapsuleRadiusForFallbackTeleportSweepCastSize) == 0x4c, "Offset mismatch for FFortAthenaHandleSoftDisableStateTreeTask::MultiplierOnCapsuleRadiusForFallbackTeleportSweepCastSize");
static_assert(offsetof(FFortAthenaHandleSoftDisableStateTreeTask, MultiplierOnCapsuleHeightForFallbackTeleportSweepCasts) == 0x50, "Offset mismatch for FFortAthenaHandleSoftDisableStateTreeTask::MultiplierOnCapsuleHeightForFallbackTeleportSweepCasts");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FFortAthenaPickAnimByWorldConditionsConfig
{
    UAnimMontage* Montage; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UContextualAnimSceneAsset* SceneAsset; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FWorldConditionQueryDefinition RequiredConditions; // 0x10 (Size: 0x18, Type: StructProperty)
    FWorldConditionQueryState QueryState; // 0x28 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FFortAthenaPickAnimByWorldConditionsConfig) == 0x58, "Size mismatch for FFortAthenaPickAnimByWorldConditionsConfig");
static_assert(offsetof(FFortAthenaPickAnimByWorldConditionsConfig, Montage) == 0x0, "Offset mismatch for FFortAthenaPickAnimByWorldConditionsConfig::Montage");
static_assert(offsetof(FFortAthenaPickAnimByWorldConditionsConfig, SceneAsset) == 0x8, "Offset mismatch for FFortAthenaPickAnimByWorldConditionsConfig::SceneAsset");
static_assert(offsetof(FFortAthenaPickAnimByWorldConditionsConfig, RequiredConditions) == 0x10, "Offset mismatch for FFortAthenaPickAnimByWorldConditionsConfig::RequiredConditions");
static_assert(offsetof(FFortAthenaPickAnimByWorldConditionsConfig, QueryState) == 0x28, "Offset mismatch for FFortAthenaPickAnimByWorldConditionsConfig::QueryState");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData
{
    TArray<FFortAthenaPickAnimByWorldConditionsConfig> PossibleAnims; // 0x0 (Size: 0x10, Type: ArrayProperty)
    AActor* ActorAForWorldConditions; // 0x10 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorBForWorldConditions; // 0x18 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorCForWorldConditions; // 0x20 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* PickedMontage; // 0x28 (Size: 0x8, Type: ObjectProperty)
    UContextualAnimSceneAsset* PickedSceneAsset; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData) == 0x38, "Size mismatch for FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData, PossibleAnims) == 0x0, "Offset mismatch for FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData::PossibleAnims");
static_assert(offsetof(FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData, ActorAForWorldConditions) == 0x10, "Offset mismatch for FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData::ActorAForWorldConditions");
static_assert(offsetof(FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData, ActorBForWorldConditions) == 0x18, "Offset mismatch for FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData::ActorBForWorldConditions");
static_assert(offsetof(FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData, ActorCForWorldConditions) == 0x20, "Offset mismatch for FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData::ActorCForWorldConditions");
static_assert(offsetof(FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData, PickedMontage) == 0x28, "Offset mismatch for FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData::PickedMontage");
static_assert(offsetof(FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData, PickedSceneAsset) == 0x30, "Offset mismatch for FFortAthenaPickAnimByWorldConditionsStateTreeTaskInstanceData::PickedSceneAsset");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortAthenaPickAnimByWorldConditionsStateTreeTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortAthenaPickAnimByWorldConditionsStateTreeTask) == 0x20, "Size mismatch for FFortAthenaPickAnimByWorldConditionsStateTreeTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortAthenaPickRandomMontageConfig
{
    UAnimMontage* Montage; // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t RandomWeight; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaPickRandomMontageConfig) == 0x10, "Size mismatch for FFortAthenaPickRandomMontageConfig");
static_assert(offsetof(FFortAthenaPickRandomMontageConfig, Montage) == 0x0, "Offset mismatch for FFortAthenaPickRandomMontageConfig::Montage");
static_assert(offsetof(FFortAthenaPickRandomMontageConfig, RandomWeight) == 0x8, "Offset mismatch for FFortAthenaPickRandomMontageConfig::RandomWeight");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortAthenaPickRandomMontageStateTreeTaskInstanceData
{
    TArray<FFortAthenaPickRandomMontageConfig> PossibleMontages; // 0x0 (Size: 0x10, Type: ArrayProperty)
    UAnimMontage* PickedMontage; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortAthenaPickRandomMontageStateTreeTaskInstanceData) == 0x18, "Size mismatch for FFortAthenaPickRandomMontageStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaPickRandomMontageStateTreeTaskInstanceData, PossibleMontages) == 0x0, "Offset mismatch for FFortAthenaPickRandomMontageStateTreeTaskInstanceData::PossibleMontages");
static_assert(offsetof(FFortAthenaPickRandomMontageStateTreeTaskInstanceData, PickedMontage) == 0x10, "Offset mismatch for FFortAthenaPickRandomMontageStateTreeTaskInstanceData::PickedMontage");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortAthenaPickRandomMontageStateTreeTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortAthenaPickRandomMontageStateTreeTask) == 0x20, "Size mismatch for FFortAthenaPickRandomMontageStateTreeTask");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FFortUISmartObjectUIId UIId; // 0x8 (Size: 0x4, Type: StructProperty)
    FGameplayTag PayloadType; // 0xc (Size: 0x4, Type: StructProperty)
    FGameplayTagQuery PayloadTypeQuery; // 0x10 (Size: 0x48, Type: StructProperty)
    TArray<FFortUISmartObjectUIPayload> ReceivedPayloads; // 0x58 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_68[0x8]; // 0x68 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData) == 0x70, "Size mismatch for FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData, Actor) == 0x0, "Offset mismatch for FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData::Actor");
static_assert(offsetof(FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData, UIId) == 0x8, "Offset mismatch for FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData::UIId");
static_assert(offsetof(FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData, PayloadType) == 0xc, "Offset mismatch for FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData::PayloadType");
static_assert(offsetof(FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData, PayloadTypeQuery) == 0x10, "Offset mismatch for FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData::PayloadTypeQuery");
static_assert(offsetof(FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData, ReceivedPayloads) == 0x58, "Offset mismatch for FFortAthenaReceivePayloadSmartObjectUIStateTreeTaskInstanceData::ReceivedPayloads");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FFortAthenaReceivePayloadSmartObjectUIStateTreeTask : FStateTreeTaskCommonBase
{
    FGameplayTag ReceivedUIPayloadEventTag; // 0x20 (Size: 0x4, Type: StructProperty)
    bool bSilentFailWithInvalidPayloadType; // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bConnectToClientToServerPayload; // 0x25 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_26[0x2]; // 0x26 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaReceivePayloadSmartObjectUIStateTreeTask) == 0x28, "Size mismatch for FFortAthenaReceivePayloadSmartObjectUIStateTreeTask");
static_assert(offsetof(FFortAthenaReceivePayloadSmartObjectUIStateTreeTask, ReceivedUIPayloadEventTag) == 0x20, "Offset mismatch for FFortAthenaReceivePayloadSmartObjectUIStateTreeTask::ReceivedUIPayloadEventTag");
static_assert(offsetof(FFortAthenaReceivePayloadSmartObjectUIStateTreeTask, bSilentFailWithInvalidPayloadType) == 0x24, "Offset mismatch for FFortAthenaReceivePayloadSmartObjectUIStateTreeTask::bSilentFailWithInvalidPayloadType");
static_assert(offsetof(FFortAthenaReceivePayloadSmartObjectUIStateTreeTask, bConnectToClientToServerPayload) == 0x25, "Offset mismatch for FFortAthenaReceivePayloadSmartObjectUIStateTreeTask::bConnectToClientToServerPayload");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData
{
    AActor* SmartObjectActor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Actor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag UITag; // 0x10 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FFortUISmartObjectUIPayloadOptions UIOptions; // 0x18 (Size: 0x18, Type: StructProperty)
    FFortUISmartObjectUIId UIId; // 0x30 (Size: 0x4, Type: StructProperty)
    bool bIsClosed; // 0x34 (Size: 0x1, Type: BoolProperty)
    bool bCloseResult; // 0x35 (Size: 0x1, Type: BoolProperty)
    bool bTaskRequestedClose; // 0x36 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_37[0x9]; // 0x37 (Size: 0x9, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData) == 0x40, "Size mismatch for FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData, SmartObjectActor) == 0x0, "Offset mismatch for FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData::SmartObjectActor");
static_assert(offsetof(FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData, Actor) == 0x8, "Offset mismatch for FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData::Actor");
static_assert(offsetof(FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData, UITag) == 0x10, "Offset mismatch for FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData::UITag");
static_assert(offsetof(FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData, UIOptions) == 0x18, "Offset mismatch for FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData::UIOptions");
static_assert(offsetof(FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData, UIId) == 0x30, "Offset mismatch for FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData::UIId");
static_assert(offsetof(FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData, bIsClosed) == 0x34, "Offset mismatch for FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData::bIsClosed");
static_assert(offsetof(FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData, bCloseResult) == 0x35, "Offset mismatch for FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData::bCloseResult");
static_assert(offsetof(FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData, bTaskRequestedClose) == 0x36, "Offset mismatch for FFortAthenaRunSmartObjectUIStateTreeTaskInstanceData::bTaskRequestedClose");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FFortAthenaRunSmartObjectUIStateTreeTask : FStateTreeTaskCommonBase
{
    FGameplayTag UIClosedEventTag; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaRunSmartObjectUIStateTreeTask) == 0x28, "Size mismatch for FFortAthenaRunSmartObjectUIStateTreeTask");
static_assert(offsetof(FFortAthenaRunSmartObjectUIStateTreeTask, UIClosedEventTag) == 0x20, "Offset mismatch for FFortAthenaRunSmartObjectUIStateTreeTask::UIClosedEventTag");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFortAthenaSendPayloadSmartObjectUIStateTreeTaskInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FFortUISmartObjectUIId UIId; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    TArray<FFortUISmartObjectUIPayload> Payloads; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortAthenaSendPayloadSmartObjectUIStateTreeTaskInstanceData) == 0x20, "Size mismatch for FFortAthenaSendPayloadSmartObjectUIStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaSendPayloadSmartObjectUIStateTreeTaskInstanceData, Actor) == 0x0, "Offset mismatch for FFortAthenaSendPayloadSmartObjectUIStateTreeTaskInstanceData::Actor");
static_assert(offsetof(FFortAthenaSendPayloadSmartObjectUIStateTreeTaskInstanceData, UIId) == 0x8, "Offset mismatch for FFortAthenaSendPayloadSmartObjectUIStateTreeTaskInstanceData::UIId");
static_assert(offsetof(FFortAthenaSendPayloadSmartObjectUIStateTreeTaskInstanceData, Payloads) == 0x10, "Offset mismatch for FFortAthenaSendPayloadSmartObjectUIStateTreeTaskInstanceData::Payloads");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FFortAthenaSendPayloadSmartObjectUIStateTreeTask : FStateTreeTaskCommonBase
{
    uint8_t Trigger; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaSendPayloadSmartObjectUIStateTreeTask) == 0x28, "Size mismatch for FFortAthenaSendPayloadSmartObjectUIStateTreeTask");
static_assert(offsetof(FFortAthenaSendPayloadSmartObjectUIStateTreeTask, Trigger) == 0x20, "Offset mismatch for FFortAthenaSendPayloadSmartObjectUIStateTreeTask::Trigger");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortAthenaToggleAllowInteractStateTreeTaskInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortAthenaToggleAllowInteractStateTreeTaskInstanceData) == 0x10, "Size mismatch for FFortAthenaToggleAllowInteractStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaToggleAllowInteractStateTreeTaskInstanceData, Actor) == 0x0, "Offset mismatch for FFortAthenaToggleAllowInteractStateTreeTaskInstanceData::Actor");
static_assert(offsetof(FFortAthenaToggleAllowInteractStateTreeTaskInstanceData, TargetActor) == 0x8, "Offset mismatch for FFortAthenaToggleAllowInteractStateTreeTaskInstanceData::TargetActor");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FFortAthenaToggleAllowInteractStateTreeTaskTreeTask : FStateTreeTaskCommonBase
{
    uint8_t AddExecutionMode[0x4]; // 0x20 (Size: 0x4, Type: EnumProperty)
    uint8_t RemoveExecutionMode[0x4]; // 0x24 (Size: 0x4, Type: EnumProperty)
};

static_assert(sizeof(FFortAthenaToggleAllowInteractStateTreeTaskTreeTask) == 0x28, "Size mismatch for FFortAthenaToggleAllowInteractStateTreeTaskTreeTask");
static_assert(offsetof(FFortAthenaToggleAllowInteractStateTreeTaskTreeTask, AddExecutionMode) == 0x20, "Offset mismatch for FFortAthenaToggleAllowInteractStateTreeTaskTreeTask::AddExecutionMode");
static_assert(offsetof(FFortAthenaToggleAllowInteractStateTreeTaskTreeTask, RemoveExecutionMode) == 0x24, "Offset mismatch for FFortAthenaToggleAllowInteractStateTreeTaskTreeTask::RemoveExecutionMode");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortAthenaTrackEventConsumeStateTreeTaskInstanceData
{
    FStateTreeStructRef ReferencedEvent; // 0x0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FFortAthenaTrackEventConsumeStateTreeTaskInstanceData) == 0x10, "Size mismatch for FFortAthenaTrackEventConsumeStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaTrackEventConsumeStateTreeTaskInstanceData, ReferencedEvent) == 0x0, "Offset mismatch for FFortAthenaTrackEventConsumeStateTreeTaskInstanceData::ReferencedEvent");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortAthenaTrackEventConsumeStateTreeTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortAthenaTrackEventConsumeStateTreeTask) == 0x20, "Size mismatch for FFortAthenaTrackEventConsumeStateTreeTask");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFortAthenaTrackEventStateTreeTaskStateTreeParameter
{
    bool bHasReceivedTrackedEvent; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FGameplayTag ReceivedEventTag; // 0x4 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FFortAthenaTrackEventStateTreeTaskStateTreeParameter) == 0x8, "Size mismatch for FFortAthenaTrackEventStateTreeTaskStateTreeParameter");
static_assert(offsetof(FFortAthenaTrackEventStateTreeTaskStateTreeParameter, bHasReceivedTrackedEvent) == 0x0, "Offset mismatch for FFortAthenaTrackEventStateTreeTaskStateTreeParameter::bHasReceivedTrackedEvent");
static_assert(offsetof(FFortAthenaTrackEventStateTreeTaskStateTreeParameter, ReceivedEventTag) == 0x4, "Offset mismatch for FFortAthenaTrackEventStateTreeTaskStateTreeParameter::ReceivedEventTag");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFortAthenaTrackEventStateTreeTaskInstanceData
{
    FFortAthenaTrackEventStateTreeTaskStateTreeParameter OutParameter; // 0x0 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FFortAthenaTrackEventStateTreeTaskInstanceData) == 0x8, "Size mismatch for FFortAthenaTrackEventStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaTrackEventStateTreeTaskInstanceData, OutParameter) == 0x0, "Offset mismatch for FFortAthenaTrackEventStateTreeTaskInstanceData::OutParameter");

// Size: 0x70 (Inherited: 0x58, Single: 0x18)
struct FFortAthenaTrackEventStateTreeTask : FStateTreeTaskCommonBase
{
    FGameplayTagQuery EventTagQuery; // 0x20 (Size: 0x48, Type: StructProperty)
    FGameplayTag StateTreeEventTag; // 0x68 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaTrackEventStateTreeTask) == 0x70, "Size mismatch for FFortAthenaTrackEventStateTreeTask");
static_assert(offsetof(FFortAthenaTrackEventStateTreeTask, EventTagQuery) == 0x20, "Offset mismatch for FFortAthenaTrackEventStateTreeTask::EventTagQuery");
static_assert(offsetof(FFortAthenaTrackEventStateTreeTask, StateTreeEventTag) == 0x68, "Offset mismatch for FFortAthenaTrackEventStateTreeTask::StateTreeEventTag");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FFortAthenaWorldConditionInstanceData
{
    AActor* ActorA; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorB; // 0x8 (Size: 0x8, Type: ObjectProperty)
    AActor* ActorC; // 0x10 (Size: 0x8, Type: ObjectProperty)
    bool bOutResult; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    FWorldConditionQueryState QueryState; // 0x20 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FFortAthenaWorldConditionInstanceData) == 0x50, "Size mismatch for FFortAthenaWorldConditionInstanceData");
static_assert(offsetof(FFortAthenaWorldConditionInstanceData, ActorA) == 0x0, "Offset mismatch for FFortAthenaWorldConditionInstanceData::ActorA");
static_assert(offsetof(FFortAthenaWorldConditionInstanceData, ActorB) == 0x8, "Offset mismatch for FFortAthenaWorldConditionInstanceData::ActorB");
static_assert(offsetof(FFortAthenaWorldConditionInstanceData, ActorC) == 0x10, "Offset mismatch for FFortAthenaWorldConditionInstanceData::ActorC");
static_assert(offsetof(FFortAthenaWorldConditionInstanceData, bOutResult) == 0x18, "Offset mismatch for FFortAthenaWorldConditionInstanceData::bOutResult");
static_assert(offsetof(FFortAthenaWorldConditionInstanceData, QueryState) == 0x20, "Offset mismatch for FFortAthenaWorldConditionInstanceData::QueryState");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
struct FFortAthenaWorldConditionInstanceDataStateTreeTask : FStateTreeTaskCommonBase
{
    FWorldConditionQueryDefinition Conditions; // 0x20 (Size: 0x18, Type: StructProperty)
    FGameplayTag StateTreeEventTag; // 0x38 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaWorldConditionInstanceDataStateTreeTask) == 0x40, "Size mismatch for FFortAthenaWorldConditionInstanceDataStateTreeTask");
static_assert(offsetof(FFortAthenaWorldConditionInstanceDataStateTreeTask, Conditions) == 0x20, "Offset mismatch for FFortAthenaWorldConditionInstanceDataStateTreeTask::Conditions");
static_assert(offsetof(FFortAthenaWorldConditionInstanceDataStateTreeTask, StateTreeEventTag) == 0x38, "Offset mismatch for FFortAthenaWorldConditionInstanceDataStateTreeTask::StateTreeEventTag");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortBTService_InjectionTagKey
{
    FGameplayTag InjectionTag; // 0x0 (Size: 0x4, Type: StructProperty)
    FName InjectionKeyName; // 0x4 (Size: 0x4, Type: NameProperty)
    FName ActionInterfaceObjectKeyName; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortBTService_InjectionTagKey) == 0x10, "Size mismatch for FFortBTService_InjectionTagKey");
static_assert(offsetof(FFortBTService_InjectionTagKey, InjectionTag) == 0x0, "Offset mismatch for FFortBTService_InjectionTagKey::InjectionTag");
static_assert(offsetof(FFortBTService_InjectionTagKey, InjectionKeyName) == 0x4, "Offset mismatch for FFortBTService_InjectionTagKey::InjectionKeyName");
static_assert(offsetof(FFortBTService_InjectionTagKey, ActionInterfaceObjectKeyName) == 0x8, "Offset mismatch for FFortBTService_InjectionTagKey::ActionInterfaceObjectKeyName");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortStateTreeBotCrouchTaskInstanceData
{
    AFortAthenaAIBotController* BotController; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bShouldCrouch; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeBotCrouchTaskInstanceData) == 0x10, "Size mismatch for FFortStateTreeBotCrouchTaskInstanceData");
static_assert(offsetof(FFortStateTreeBotCrouchTaskInstanceData, BotController) == 0x0, "Offset mismatch for FFortStateTreeBotCrouchTaskInstanceData::BotController");
static_assert(offsetof(FFortStateTreeBotCrouchTaskInstanceData, bShouldCrouch) == 0x8, "Offset mismatch for FFortStateTreeBotCrouchTaskInstanceData::bShouldCrouch");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FFortStateTreeBotCrouchTask : FStateTreeAIActionTaskBase
{
};

static_assert(sizeof(FFortStateTreeBotCrouchTask) == 0x20, "Size mismatch for FFortStateTreeBotCrouchTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortStateTreeBotEquipItemTaskInstanceData
{
    AFortAthenaAIBotController* Controller; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UFortWorldItem* ItemToEquip; // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bValidateAbility; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeBotEquipItemTaskInstanceData) == 0x18, "Size mismatch for FFortStateTreeBotEquipItemTaskInstanceData");
static_assert(offsetof(FFortStateTreeBotEquipItemTaskInstanceData, Controller) == 0x0, "Offset mismatch for FFortStateTreeBotEquipItemTaskInstanceData::Controller");
static_assert(offsetof(FFortStateTreeBotEquipItemTaskInstanceData, ItemToEquip) == 0x8, "Offset mismatch for FFortStateTreeBotEquipItemTaskInstanceData::ItemToEquip");
static_assert(offsetof(FFortStateTreeBotEquipItemTaskInstanceData, bValidateAbility) == 0x10, "Offset mismatch for FFortStateTreeBotEquipItemTaskInstanceData::bValidateAbility");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FFortStateTreeBotEquipItemTask : FStateTreeAIActionTaskBase
{
};

static_assert(sizeof(FFortStateTreeBotEquipItemTask) == 0x20, "Size mismatch for FFortStateTreeBotEquipItemTask");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFortStateTreeGetItemFromInventoryTaskInstanceData
{
    AController* Controller; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FItemVariantHandle ItemVariant; // 0x8 (Size: 0x18, Type: StructProperty)
    UFortWorldItem* Item; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortStateTreeGetItemFromInventoryTaskInstanceData) == 0x28, "Size mismatch for FFortStateTreeGetItemFromInventoryTaskInstanceData");
static_assert(offsetof(FFortStateTreeGetItemFromInventoryTaskInstanceData, Controller) == 0x0, "Offset mismatch for FFortStateTreeGetItemFromInventoryTaskInstanceData::Controller");
static_assert(offsetof(FFortStateTreeGetItemFromInventoryTaskInstanceData, ItemVariant) == 0x8, "Offset mismatch for FFortStateTreeGetItemFromInventoryTaskInstanceData::ItemVariant");
static_assert(offsetof(FFortStateTreeGetItemFromInventoryTaskInstanceData, Item) == 0x20, "Offset mismatch for FFortStateTreeGetItemFromInventoryTaskInstanceData::Item");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FFortStateTreeGetItemFromInventoryTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeGetItemFromInventoryTask) == 0x28, "Size mismatch for FFortStateTreeGetItemFromInventoryTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortStateTreeBotSetSupportHolsteredWeaponInstanceData
{
    AFortAthenaAIBotController* Controller; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bSupportHolstering; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeBotSetSupportHolsteredWeaponInstanceData) == 0x10, "Size mismatch for FFortStateTreeBotSetSupportHolsteredWeaponInstanceData");
static_assert(offsetof(FFortStateTreeBotSetSupportHolsteredWeaponInstanceData, Controller) == 0x0, "Offset mismatch for FFortStateTreeBotSetSupportHolsteredWeaponInstanceData::Controller");
static_assert(offsetof(FFortStateTreeBotSetSupportHolsteredWeaponInstanceData, bSupportHolstering) == 0x8, "Offset mismatch for FFortStateTreeBotSetSupportHolsteredWeaponInstanceData::bSupportHolstering");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeBotSetSupportHolsteredWeapon : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeBotSetSupportHolsteredWeapon) == 0x20, "Size mismatch for FFortStateTreeBotSetSupportHolsteredWeapon");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortStateTreeBotSprintTaskInstanceData
{
    APawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bShouldSprint; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeBotSprintTaskInstanceData) == 0x10, "Size mismatch for FFortStateTreeBotSprintTaskInstanceData");
static_assert(offsetof(FFortStateTreeBotSprintTaskInstanceData, Pawn) == 0x0, "Offset mismatch for FFortStateTreeBotSprintTaskInstanceData::Pawn");
static_assert(offsetof(FFortStateTreeBotSprintTaskInstanceData, bShouldSprint) == 0x8, "Offset mismatch for FFortStateTreeBotSprintTaskInstanceData::bShouldSprint");

// Size: 0x40 (Inherited: 0x78, Single: 0xffffffc8)
struct FFortStateTreeBotSprintTask : FStateTreeAIActionTaskBase
{
};

static_assert(sizeof(FFortStateTreeBotSprintTask) == 0x40, "Size mismatch for FFortStateTreeBotSprintTask");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FFortStateTreeBotFireWeaponTaskInstanceData
{
    AFortAthenaAIBotController* BotController; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Behavior; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    TArray<FDigestedWeaponFiringTime> FiringTimes; // 0x10 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_20[0x10]; // 0x20 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeBotFireWeaponTaskInstanceData) == 0x30, "Size mismatch for FFortStateTreeBotFireWeaponTaskInstanceData");
static_assert(offsetof(FFortStateTreeBotFireWeaponTaskInstanceData, BotController) == 0x0, "Offset mismatch for FFortStateTreeBotFireWeaponTaskInstanceData::BotController");
static_assert(offsetof(FFortStateTreeBotFireWeaponTaskInstanceData, Behavior) == 0x8, "Offset mismatch for FFortStateTreeBotFireWeaponTaskInstanceData::Behavior");
static_assert(offsetof(FFortStateTreeBotFireWeaponTaskInstanceData, FiringTimes) == 0x10, "Offset mismatch for FFortStateTreeBotFireWeaponTaskInstanceData::FiringTimes");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FFortStateTreeBotFireWeaponTask : FStateTreeAIActionTaskBase
{
};

static_assert(sizeof(FFortStateTreeBotFireWeaponTask) == 0x20, "Size mismatch for FFortStateTreeBotFireWeaponTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortStateTreeBotGetCurrentWeaponTaskInstanceData
{
    AFortAthenaAIBotController* BotController; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AFortWeapon* CurrentWeapon; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortStateTreeBotGetCurrentWeaponTaskInstanceData) == 0x10, "Size mismatch for FFortStateTreeBotGetCurrentWeaponTaskInstanceData");
static_assert(offsetof(FFortStateTreeBotGetCurrentWeaponTaskInstanceData, BotController) == 0x0, "Offset mismatch for FFortStateTreeBotGetCurrentWeaponTaskInstanceData::BotController");
static_assert(offsetof(FFortStateTreeBotGetCurrentWeaponTaskInstanceData, CurrentWeapon) == 0x8, "Offset mismatch for FFortStateTreeBotGetCurrentWeaponTaskInstanceData::CurrentWeapon");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeBotGetCurrentWeaponTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeBotGetCurrentWeaponTask) == 0x20, "Size mismatch for FFortStateTreeBotGetCurrentWeaponTask");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FFortStateTreeBotGetFiringPatternTaskInstanceData
{
    AFortAthenaAIBotController* BotController; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AFortWeapon* CurrentWeapon; // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<FDigestedWeaponFiringTime> FiringTimes; // 0x10 (Size: 0x10, Type: ArrayProperty)
    UFortAthenaAIBotRangeAttackDigestedSkillSet* CacheRangeAttackDigestedSkillSet; // 0x20 (Size: 0x8, Type: ObjectProperty)
    AFortWeapon* LastUsedWeapon; // 0x28 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_30[0x38]; // 0x30 (Size: 0x38, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeBotGetFiringPatternTaskInstanceData) == 0x68, "Size mismatch for FFortStateTreeBotGetFiringPatternTaskInstanceData");
static_assert(offsetof(FFortStateTreeBotGetFiringPatternTaskInstanceData, BotController) == 0x0, "Offset mismatch for FFortStateTreeBotGetFiringPatternTaskInstanceData::BotController");
static_assert(offsetof(FFortStateTreeBotGetFiringPatternTaskInstanceData, CurrentWeapon) == 0x8, "Offset mismatch for FFortStateTreeBotGetFiringPatternTaskInstanceData::CurrentWeapon");
static_assert(offsetof(FFortStateTreeBotGetFiringPatternTaskInstanceData, FiringTimes) == 0x10, "Offset mismatch for FFortStateTreeBotGetFiringPatternTaskInstanceData::FiringTimes");
static_assert(offsetof(FFortStateTreeBotGetFiringPatternTaskInstanceData, CacheRangeAttackDigestedSkillSet) == 0x20, "Offset mismatch for FFortStateTreeBotGetFiringPatternTaskInstanceData::CacheRangeAttackDigestedSkillSet");
static_assert(offsetof(FFortStateTreeBotGetFiringPatternTaskInstanceData, LastUsedWeapon) == 0x28, "Offset mismatch for FFortStateTreeBotGetFiringPatternTaskInstanceData::LastUsedWeapon");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeBotGetFiringPatternTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeBotGetFiringPatternTask) == 0x20, "Size mismatch for FFortStateTreeBotGetFiringPatternTask");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFortStateTreeBotGetWeaponItemEffectivenessTaskInstanceData
{
    AFortAthenaAIBotController* BotController; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UFortItem* Item; // 0x10 (Size: 0x8, Type: ObjectProperty)
    float Effectiveness; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeBotGetWeaponItemEffectivenessTaskInstanceData) == 0x20, "Size mismatch for FFortStateTreeBotGetWeaponItemEffectivenessTaskInstanceData");
static_assert(offsetof(FFortStateTreeBotGetWeaponItemEffectivenessTaskInstanceData, BotController) == 0x0, "Offset mismatch for FFortStateTreeBotGetWeaponItemEffectivenessTaskInstanceData::BotController");
static_assert(offsetof(FFortStateTreeBotGetWeaponItemEffectivenessTaskInstanceData, Target) == 0x8, "Offset mismatch for FFortStateTreeBotGetWeaponItemEffectivenessTaskInstanceData::Target");
static_assert(offsetof(FFortStateTreeBotGetWeaponItemEffectivenessTaskInstanceData, Item) == 0x10, "Offset mismatch for FFortStateTreeBotGetWeaponItemEffectivenessTaskInstanceData::Item");
static_assert(offsetof(FFortStateTreeBotGetWeaponItemEffectivenessTaskInstanceData, Effectiveness) == 0x18, "Offset mismatch for FFortStateTreeBotGetWeaponItemEffectivenessTaskInstanceData::Effectiveness");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeBotGetWeaponItemEffectivenessTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeBotGetWeaponItemEffectivenessTask) == 0x20, "Size mismatch for FFortStateTreeBotGetWeaponItemEffectivenessTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortStateTreeBotGetMostEffectiveWeaponScoreTaskInstanceData
{
    AFortAthenaAIBotController* BotController; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target; // 0x8 (Size: 0x8, Type: ObjectProperty)
    float Effectiveness; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeBotGetMostEffectiveWeaponScoreTaskInstanceData) == 0x18, "Size mismatch for FFortStateTreeBotGetMostEffectiveWeaponScoreTaskInstanceData");
static_assert(offsetof(FFortStateTreeBotGetMostEffectiveWeaponScoreTaskInstanceData, BotController) == 0x0, "Offset mismatch for FFortStateTreeBotGetMostEffectiveWeaponScoreTaskInstanceData::BotController");
static_assert(offsetof(FFortStateTreeBotGetMostEffectiveWeaponScoreTaskInstanceData, Target) == 0x8, "Offset mismatch for FFortStateTreeBotGetMostEffectiveWeaponScoreTaskInstanceData::Target");
static_assert(offsetof(FFortStateTreeBotGetMostEffectiveWeaponScoreTaskInstanceData, Effectiveness) == 0x10, "Offset mismatch for FFortStateTreeBotGetMostEffectiveWeaponScoreTaskInstanceData::Effectiveness");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeBotGetMostEffectiveWeaponScoreTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeBotGetMostEffectiveWeaponScoreTask) == 0x20, "Size mismatch for FFortStateTreeBotGetMostEffectiveWeaponScoreTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortStateTreeBotGetWeaponItemTaskInstanceData
{
    AFortAthenaAIBotController* BotController; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AFortWeapon* Weapon; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UFortItem* Item; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortStateTreeBotGetWeaponItemTaskInstanceData) == 0x18, "Size mismatch for FFortStateTreeBotGetWeaponItemTaskInstanceData");
static_assert(offsetof(FFortStateTreeBotGetWeaponItemTaskInstanceData, BotController) == 0x0, "Offset mismatch for FFortStateTreeBotGetWeaponItemTaskInstanceData::BotController");
static_assert(offsetof(FFortStateTreeBotGetWeaponItemTaskInstanceData, Weapon) == 0x8, "Offset mismatch for FFortStateTreeBotGetWeaponItemTaskInstanceData::Weapon");
static_assert(offsetof(FFortStateTreeBotGetWeaponItemTaskInstanceData, Item) == 0x10, "Offset mismatch for FFortStateTreeBotGetWeaponItemTaskInstanceData::Item");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeBotGetWeaponItemTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeBotGetWeaponItemTask) == 0x20, "Size mismatch for FFortStateTreeBotGetWeaponItemTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortStateTreeGetControllerTaskInstanceData
{
    APawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AController* Controller; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortStateTreeGetControllerTaskInstanceData) == 0x10, "Size mismatch for FFortStateTreeGetControllerTaskInstanceData");
static_assert(offsetof(FFortStateTreeGetControllerTaskInstanceData, Pawn) == 0x0, "Offset mismatch for FFortStateTreeGetControllerTaskInstanceData::Pawn");
static_assert(offsetof(FFortStateTreeGetControllerTaskInstanceData, Controller) == 0x8, "Offset mismatch for FFortStateTreeGetControllerTaskInstanceData::Controller");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeGetControllerTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeGetControllerTask) == 0x20, "Size mismatch for FFortStateTreeGetControllerTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortStateTreeGetAIControllerTaskInstanceData
{
    APawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AAIController* AIController; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortStateTreeGetAIControllerTaskInstanceData) == 0x10, "Size mismatch for FFortStateTreeGetAIControllerTaskInstanceData");
static_assert(offsetof(FFortStateTreeGetAIControllerTaskInstanceData, Pawn) == 0x0, "Offset mismatch for FFortStateTreeGetAIControllerTaskInstanceData::Pawn");
static_assert(offsetof(FFortStateTreeGetAIControllerTaskInstanceData, AIController) == 0x8, "Offset mismatch for FFortStateTreeGetAIControllerTaskInstanceData::AIController");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeGetAIControllerTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeGetAIControllerTask) == 0x20, "Size mismatch for FFortStateTreeGetAIControllerTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortStateTreeGetBotControllerTaskInstanceData
{
    APawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AFortAthenaAIBotController* BotController; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortStateTreeGetBotControllerTaskInstanceData) == 0x10, "Size mismatch for FFortStateTreeGetBotControllerTaskInstanceData");
static_assert(offsetof(FFortStateTreeGetBotControllerTaskInstanceData, Pawn) == 0x0, "Offset mismatch for FFortStateTreeGetBotControllerTaskInstanceData::Pawn");
static_assert(offsetof(FFortStateTreeGetBotControllerTaskInstanceData, BotController) == 0x8, "Offset mismatch for FFortStateTreeGetBotControllerTaskInstanceData::BotController");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeGetBotControllerTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeGetBotControllerTask) == 0x20, "Size mismatch for FFortStateTreeGetBotControllerTask");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FFortStateTreeExecuteAbilityTaskInstanceData
{
    AAIController* Controller; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AbilityTag; // 0x8 (Size: 0x20, Type: StructProperty)
    UFortAITask_ExecuteAbility* ExecuteAbilityTask; // 0x28 (Size: 0x8, Type: ObjectProperty)
    TScriptInterface<Class> TaskOwner; // 0x30 (Size: 0x10, Type: InterfaceProperty)
};

static_assert(sizeof(FFortStateTreeExecuteAbilityTaskInstanceData) == 0x40, "Size mismatch for FFortStateTreeExecuteAbilityTaskInstanceData");
static_assert(offsetof(FFortStateTreeExecuteAbilityTaskInstanceData, Controller) == 0x0, "Offset mismatch for FFortStateTreeExecuteAbilityTaskInstanceData::Controller");
static_assert(offsetof(FFortStateTreeExecuteAbilityTaskInstanceData, AbilityTag) == 0x8, "Offset mismatch for FFortStateTreeExecuteAbilityTaskInstanceData::AbilityTag");
static_assert(offsetof(FFortStateTreeExecuteAbilityTaskInstanceData, ExecuteAbilityTask) == 0x28, "Offset mismatch for FFortStateTreeExecuteAbilityTaskInstanceData::ExecuteAbilityTask");
static_assert(offsetof(FFortStateTreeExecuteAbilityTaskInstanceData, TaskOwner) == 0x30, "Offset mismatch for FFortStateTreeExecuteAbilityTaskInstanceData::TaskOwner");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FFortStateTreeExecuteAbilityTask : FStateTreeAIActionTaskBase
{
};

static_assert(sizeof(FFortStateTreeExecuteAbilityTask) == 0x20, "Size mismatch for FFortStateTreeExecuteAbilityTask");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFortGetActorLocationStateTreeTaskInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FVector OutVector; // 0x8 (Size: 0x18, Type: StructProperty)
    FStateTreePropertyRef OutRefVector; // 0x20 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_22[0x6]; // 0x22 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FFortGetActorLocationStateTreeTaskInstanceData) == 0x28, "Size mismatch for FFortGetActorLocationStateTreeTaskInstanceData");
static_assert(offsetof(FFortGetActorLocationStateTreeTaskInstanceData, Actor) == 0x0, "Offset mismatch for FFortGetActorLocationStateTreeTaskInstanceData::Actor");
static_assert(offsetof(FFortGetActorLocationStateTreeTaskInstanceData, OutVector) == 0x8, "Offset mismatch for FFortGetActorLocationStateTreeTaskInstanceData::OutVector");
static_assert(offsetof(FFortGetActorLocationStateTreeTaskInstanceData, OutRefVector) == 0x20, "Offset mismatch for FFortGetActorLocationStateTreeTaskInstanceData::OutRefVector");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FFortGetActorLocationStateTreeTask : FStateTreeTaskCommonBase
{
    bool bRunOnce; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortGetActorLocationStateTreeTask) == 0x28, "Size mismatch for FFortGetActorLocationStateTreeTask");
static_assert(offsetof(FFortGetActorLocationStateTreeTask, bRunOnce) == 0x20, "Offset mismatch for FFortGetActorLocationStateTreeTask::bRunOnce");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FFortStateTreeGetDistanceParameterInstanceData
{
    AFortPawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AbilityTag; // 0x8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer DistancePropertyTag; // 0x28 (Size: 0x20, Type: StructProperty)
    float OutDistance; // 0x48 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeGetDistanceParameterInstanceData) == 0x50, "Size mismatch for FFortStateTreeGetDistanceParameterInstanceData");
static_assert(offsetof(FFortStateTreeGetDistanceParameterInstanceData, Pawn) == 0x0, "Offset mismatch for FFortStateTreeGetDistanceParameterInstanceData::Pawn");
static_assert(offsetof(FFortStateTreeGetDistanceParameterInstanceData, AbilityTag) == 0x8, "Offset mismatch for FFortStateTreeGetDistanceParameterInstanceData::AbilityTag");
static_assert(offsetof(FFortStateTreeGetDistanceParameterInstanceData, DistancePropertyTag) == 0x28, "Offset mismatch for FFortStateTreeGetDistanceParameterInstanceData::DistancePropertyTag");
static_assert(offsetof(FFortStateTreeGetDistanceParameterInstanceData, OutDistance) == 0x48, "Offset mismatch for FFortStateTreeGetDistanceParameterInstanceData::OutDistance");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeGetDistanceParameterStateTreeTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortStateTreeGetDistanceParameterStateTreeTask) == 0x20, "Size mismatch for FFortStateTreeGetDistanceParameterStateTreeTask");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFortStateTreeGetTargetActorTaskInstanceData
{
    AActor* TargetActor; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortStateTreeGetTargetActorTaskInstanceData) == 0x8, "Size mismatch for FFortStateTreeGetTargetActorTaskInstanceData");
static_assert(offsetof(FFortStateTreeGetTargetActorTaskInstanceData, TargetActor) == 0x0, "Offset mismatch for FFortStateTreeGetTargetActorTaskInstanceData::TargetActor");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FFortStateTreeGetTargetActorTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeGetTargetActorTask) == 0x28, "Size mismatch for FFortStateTreeGetTargetActorTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortStateTreeGetHealthTaskInstanceData
{
    AFortPawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    float CurrentHealth; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxHealth; // 0xc (Size: 0x4, Type: FloatProperty)
    float HealthPercentage; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeGetHealthTaskInstanceData) == 0x18, "Size mismatch for FFortStateTreeGetHealthTaskInstanceData");
static_assert(offsetof(FFortStateTreeGetHealthTaskInstanceData, Pawn) == 0x0, "Offset mismatch for FFortStateTreeGetHealthTaskInstanceData::Pawn");
static_assert(offsetof(FFortStateTreeGetHealthTaskInstanceData, CurrentHealth) == 0x8, "Offset mismatch for FFortStateTreeGetHealthTaskInstanceData::CurrentHealth");
static_assert(offsetof(FFortStateTreeGetHealthTaskInstanceData, MaxHealth) == 0xc, "Offset mismatch for FFortStateTreeGetHealthTaskInstanceData::MaxHealth");
static_assert(offsetof(FFortStateTreeGetHealthTaskInstanceData, HealthPercentage) == 0x10, "Offset mismatch for FFortStateTreeGetHealthTaskInstanceData::HealthPercentage");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeGetHealthTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortStateTreeGetHealthTask) == 0x20, "Size mismatch for FFortStateTreeGetHealthTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortStateTreeGetShieldTaskInstanceData
{
    AFortPawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    float CurrentShield; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxShield; // 0xc (Size: 0x4, Type: FloatProperty)
    float ShieldPercentage; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeGetShieldTaskInstanceData) == 0x18, "Size mismatch for FFortStateTreeGetShieldTaskInstanceData");
static_assert(offsetof(FFortStateTreeGetShieldTaskInstanceData, Pawn) == 0x0, "Offset mismatch for FFortStateTreeGetShieldTaskInstanceData::Pawn");
static_assert(offsetof(FFortStateTreeGetShieldTaskInstanceData, CurrentShield) == 0x8, "Offset mismatch for FFortStateTreeGetShieldTaskInstanceData::CurrentShield");
static_assert(offsetof(FFortStateTreeGetShieldTaskInstanceData, MaxShield) == 0xc, "Offset mismatch for FFortStateTreeGetShieldTaskInstanceData::MaxShield");
static_assert(offsetof(FFortStateTreeGetShieldTaskInstanceData, ShieldPercentage) == 0x10, "Offset mismatch for FFortStateTreeGetShieldTaskInstanceData::ShieldPercentage");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeGetShieldTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortStateTreeGetShieldTask) == 0x20, "Size mismatch for FFortStateTreeGetShieldTask");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFortStateTreeIsInsideLeashConditionInstanceData
{
    AAIController* AIController; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FVector Location; // 0x8 (Size: 0x18, Type: StructProperty)
    bool bUseInnerRadius; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeIsInsideLeashConditionInstanceData) == 0x28, "Size mismatch for FFortStateTreeIsInsideLeashConditionInstanceData");
static_assert(offsetof(FFortStateTreeIsInsideLeashConditionInstanceData, AIController) == 0x0, "Offset mismatch for FFortStateTreeIsInsideLeashConditionInstanceData::AIController");
static_assert(offsetof(FFortStateTreeIsInsideLeashConditionInstanceData, Location) == 0x8, "Offset mismatch for FFortStateTreeIsInsideLeashConditionInstanceData::Location");
static_assert(offsetof(FFortStateTreeIsInsideLeashConditionInstanceData, bUseInnerRadius) == 0x20, "Offset mismatch for FFortStateTreeIsInsideLeashConditionInstanceData::bUseInnerRadius");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FFortStateTreeIsInsideLeashCondition : FStateTreeAIConditionBase
{
    bool bInvert; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeIsInsideLeashCondition) == 0x28, "Size mismatch for FFortStateTreeIsInsideLeashCondition");
static_assert(offsetof(FFortStateTreeIsInsideLeashCondition, bInvert) == 0x20, "Offset mismatch for FFortStateTreeIsInsideLeashCondition::bInvert");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortStateTreeGetMoveStatusTaskInstanceData
{
    AAIController* AIController; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EPathFollowingStatus> MoveStatus; // 0x8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeGetMoveStatusTaskInstanceData) == 0x10, "Size mismatch for FFortStateTreeGetMoveStatusTaskInstanceData");
static_assert(offsetof(FFortStateTreeGetMoveStatusTaskInstanceData, AIController) == 0x0, "Offset mismatch for FFortStateTreeGetMoveStatusTaskInstanceData::AIController");
static_assert(offsetof(FFortStateTreeGetMoveStatusTaskInstanceData, MoveStatus) == 0x8, "Offset mismatch for FFortStateTreeGetMoveStatusTaskInstanceData::MoveStatus");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeGetMoveStatusTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeGetMoveStatusTask) == 0x20, "Size mismatch for FFortStateTreeGetMoveStatusTask");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFortStateTreeGetMoveDestinationTaskInstanceData
{
    AAIController* AIController; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FVector MoveDestination; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FFortStateTreeGetMoveDestinationTaskInstanceData) == 0x20, "Size mismatch for FFortStateTreeGetMoveDestinationTaskInstanceData");
static_assert(offsetof(FFortStateTreeGetMoveDestinationTaskInstanceData, AIController) == 0x0, "Offset mismatch for FFortStateTreeGetMoveDestinationTaskInstanceData::AIController");
static_assert(offsetof(FFortStateTreeGetMoveDestinationTaskInstanceData, MoveDestination) == 0x8, "Offset mismatch for FFortStateTreeGetMoveDestinationTaskInstanceData::MoveDestination");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeGetMoveDestinationTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeGetMoveDestinationTask) == 0x20, "Size mismatch for FFortStateTreeGetMoveDestinationTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortStateTreeSetFrustrationDiscouragementInstanceData
{
    AAIController* AIController; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    float DiscouragementDuration; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeSetFrustrationDiscouragementInstanceData) == 0x18, "Size mismatch for FFortStateTreeSetFrustrationDiscouragementInstanceData");
static_assert(offsetof(FFortStateTreeSetFrustrationDiscouragementInstanceData, AIController) == 0x0, "Offset mismatch for FFortStateTreeSetFrustrationDiscouragementInstanceData::AIController");
static_assert(offsetof(FFortStateTreeSetFrustrationDiscouragementInstanceData, TargetActor) == 0x8, "Offset mismatch for FFortStateTreeSetFrustrationDiscouragementInstanceData::TargetActor");
static_assert(offsetof(FFortStateTreeSetFrustrationDiscouragementInstanceData, DiscouragementDuration) == 0x10, "Offset mismatch for FFortStateTreeSetFrustrationDiscouragementInstanceData::DiscouragementDuration");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeSetFrustrationDiscouragementTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeSetFrustrationDiscouragementTask) == 0x20, "Size mismatch for FFortStateTreeSetFrustrationDiscouragementTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortStateTreeSetInTacticalActionTaskInstanceData
{
    AFortAthenaAIBotController* Controller; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bShouldSetInTacticalAction; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeSetInTacticalActionTaskInstanceData) == 0x10, "Size mismatch for FFortStateTreeSetInTacticalActionTaskInstanceData");
static_assert(offsetof(FFortStateTreeSetInTacticalActionTaskInstanceData, Controller) == 0x0, "Offset mismatch for FFortStateTreeSetInTacticalActionTaskInstanceData::Controller");
static_assert(offsetof(FFortStateTreeSetInTacticalActionTaskInstanceData, bShouldSetInTacticalAction) == 0x8, "Offset mismatch for FFortStateTreeSetInTacticalActionTaskInstanceData::bShouldSetInTacticalAction");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeSetInTacticalActionTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeSetInTacticalActionTask) == 0x20, "Size mismatch for FFortStateTreeSetInTacticalActionTask");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FFortStateTreeHasFreeTokenConditionInstanceData
{
    APawn* ReserverPawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery TokenTagQuery; // 0x10 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FFortStateTreeHasFreeTokenConditionInstanceData) == 0x58, "Size mismatch for FFortStateTreeHasFreeTokenConditionInstanceData");
static_assert(offsetof(FFortStateTreeHasFreeTokenConditionInstanceData, ReserverPawn) == 0x0, "Offset mismatch for FFortStateTreeHasFreeTokenConditionInstanceData::ReserverPawn");
static_assert(offsetof(FFortStateTreeHasFreeTokenConditionInstanceData, Target) == 0x8, "Offset mismatch for FFortStateTreeHasFreeTokenConditionInstanceData::Target");
static_assert(offsetof(FFortStateTreeHasFreeTokenConditionInstanceData, TokenTagQuery) == 0x10, "Offset mismatch for FFortStateTreeHasFreeTokenConditionInstanceData::TokenTagQuery");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeHasFreeTokenCondition : FStateTreeAIConditionBase
{
};

static_assert(sizeof(FFortStateTreeHasFreeTokenCondition) == 0x20, "Size mismatch for FFortStateTreeHasFreeTokenCondition");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FFortStateTreeReserveTokenTaskInstanceData
{
    APawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery TokenTagQuery; // 0x10 (Size: 0x48, Type: StructProperty)
    FTokenHandle GrantedToken; // 0x58 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FFortStateTreeReserveTokenTaskInstanceData) == 0x60, "Size mismatch for FFortStateTreeReserveTokenTaskInstanceData");
static_assert(offsetof(FFortStateTreeReserveTokenTaskInstanceData, Pawn) == 0x0, "Offset mismatch for FFortStateTreeReserveTokenTaskInstanceData::Pawn");
static_assert(offsetof(FFortStateTreeReserveTokenTaskInstanceData, Target) == 0x8, "Offset mismatch for FFortStateTreeReserveTokenTaskInstanceData::Target");
static_assert(offsetof(FFortStateTreeReserveTokenTaskInstanceData, TokenTagQuery) == 0x10, "Offset mismatch for FFortStateTreeReserveTokenTaskInstanceData::TokenTagQuery");
static_assert(offsetof(FFortStateTreeReserveTokenTaskInstanceData, GrantedToken) == 0x58, "Offset mismatch for FFortStateTreeReserveTokenTaskInstanceData::GrantedToken");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeReserveTokenTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeReserveTokenTask) == 0x20, "Size mismatch for FFortStateTreeReserveTokenTask");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FFortStateTreeReserveTokenPositionTaskInstanceData
{
    APawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector Position; // 0x10 (Size: 0x18, Type: StructProperty)
    FGameplayTagQuery TokenTagQuery; // 0x28 (Size: 0x48, Type: StructProperty)
    float HoldReservationAtExitDuration; // 0x70 (Size: 0x4, Type: FloatProperty)
    float AcceptableDistanceForPositionReservation; // 0x74 (Size: 0x4, Type: FloatProperty)
    bool bAllowAddingNewPositionToProvider; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0xf]; // 0x79 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeReserveTokenPositionTaskInstanceData) == 0x88, "Size mismatch for FFortStateTreeReserveTokenPositionTaskInstanceData");
static_assert(offsetof(FFortStateTreeReserveTokenPositionTaskInstanceData, Pawn) == 0x0, "Offset mismatch for FFortStateTreeReserveTokenPositionTaskInstanceData::Pawn");
static_assert(offsetof(FFortStateTreeReserveTokenPositionTaskInstanceData, Target) == 0x8, "Offset mismatch for FFortStateTreeReserveTokenPositionTaskInstanceData::Target");
static_assert(offsetof(FFortStateTreeReserveTokenPositionTaskInstanceData, Position) == 0x10, "Offset mismatch for FFortStateTreeReserveTokenPositionTaskInstanceData::Position");
static_assert(offsetof(FFortStateTreeReserveTokenPositionTaskInstanceData, TokenTagQuery) == 0x28, "Offset mismatch for FFortStateTreeReserveTokenPositionTaskInstanceData::TokenTagQuery");
static_assert(offsetof(FFortStateTreeReserveTokenPositionTaskInstanceData, HoldReservationAtExitDuration) == 0x70, "Offset mismatch for FFortStateTreeReserveTokenPositionTaskInstanceData::HoldReservationAtExitDuration");
static_assert(offsetof(FFortStateTreeReserveTokenPositionTaskInstanceData, AcceptableDistanceForPositionReservation) == 0x74, "Offset mismatch for FFortStateTreeReserveTokenPositionTaskInstanceData::AcceptableDistanceForPositionReservation");
static_assert(offsetof(FFortStateTreeReserveTokenPositionTaskInstanceData, bAllowAddingNewPositionToProvider) == 0x78, "Offset mismatch for FFortStateTreeReserveTokenPositionTaskInstanceData::bAllowAddingNewPositionToProvider");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeReserveTokenPositionTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeReserveTokenPositionTask) == 0x20, "Size mismatch for FFortStateTreeReserveTokenPositionTask");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FFortStateTreeWaitForTokenPositionTaskInstanceData
{
    AActor* Target; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery TokenTagQuery; // 0x8 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FFortStateTreeWaitForTokenPositionTaskInstanceData) == 0x50, "Size mismatch for FFortStateTreeWaitForTokenPositionTaskInstanceData");
static_assert(offsetof(FFortStateTreeWaitForTokenPositionTaskInstanceData, Target) == 0x0, "Offset mismatch for FFortStateTreeWaitForTokenPositionTaskInstanceData::Target");
static_assert(offsetof(FFortStateTreeWaitForTokenPositionTaskInstanceData, TokenTagQuery) == 0x8, "Offset mismatch for FFortStateTreeWaitForTokenPositionTaskInstanceData::TokenTagQuery");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeWaitForTokenPositionTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeWaitForTokenPositionTask) == 0x20, "Size mismatch for FFortStateTreeWaitForTokenPositionTask");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFortStateTreeGetReservedTokenPositionTaskInstanceData
{
    APawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector ReservedLocation; // 0x10 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FFortStateTreeGetReservedTokenPositionTaskInstanceData) == 0x28, "Size mismatch for FFortStateTreeGetReservedTokenPositionTaskInstanceData");
static_assert(offsetof(FFortStateTreeGetReservedTokenPositionTaskInstanceData, Pawn) == 0x0, "Offset mismatch for FFortStateTreeGetReservedTokenPositionTaskInstanceData::Pawn");
static_assert(offsetof(FFortStateTreeGetReservedTokenPositionTaskInstanceData, Target) == 0x8, "Offset mismatch for FFortStateTreeGetReservedTokenPositionTaskInstanceData::Target");
static_assert(offsetof(FFortStateTreeGetReservedTokenPositionTaskInstanceData, ReservedLocation) == 0x10, "Offset mismatch for FFortStateTreeGetReservedTokenPositionTaskInstanceData::ReservedLocation");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeGetReservedTokenPositionTask : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeGetReservedTokenPositionTask) == 0x20, "Size mismatch for FFortStateTreeGetReservedTokenPositionTask");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FFortStateTreeRequestProviderPositionGenerationInstanceData
{
    AActor* Target; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery TokenPositionTagQuery; // 0x8 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FFortStateTreeRequestProviderPositionGenerationInstanceData) == 0x50, "Size mismatch for FFortStateTreeRequestProviderPositionGenerationInstanceData");
static_assert(offsetof(FFortStateTreeRequestProviderPositionGenerationInstanceData, Target) == 0x0, "Offset mismatch for FFortStateTreeRequestProviderPositionGenerationInstanceData::Target");
static_assert(offsetof(FFortStateTreeRequestProviderPositionGenerationInstanceData, TokenPositionTagQuery) == 0x8, "Offset mismatch for FFortStateTreeRequestProviderPositionGenerationInstanceData::TokenPositionTagQuery");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeRequestProviderPositionGeneration : FStateTreeAITaskBase
{
};

static_assert(sizeof(FFortStateTreeRequestProviderPositionGeneration) == 0x20, "Size mismatch for FFortStateTreeRequestProviderPositionGeneration");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFortStateTreeReloadWeaponTaskInstanceData
{
    AFortWeapon* Weapon; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortStateTreeReloadWeaponTaskInstanceData) == 0x8, "Size mismatch for FFortStateTreeReloadWeaponTaskInstanceData");
static_assert(offsetof(FFortStateTreeReloadWeaponTaskInstanceData, Weapon) == 0x0, "Offset mismatch for FFortStateTreeReloadWeaponTaskInstanceData::Weapon");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FFortStateTreeReloadWeaponTask : FStateTreeAIActionTaskBase
{
};

static_assert(sizeof(FFortStateTreeReloadWeaponTask) == 0x20, "Size mismatch for FFortStateTreeReloadWeaponTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortStateTreeGetWeaponRemainingAmmoTaskInstanceData
{
    AFortWeapon* Weapon; // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t RemainingAmmo; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeGetWeaponRemainingAmmoTaskInstanceData) == 0x10, "Size mismatch for FFortStateTreeGetWeaponRemainingAmmoTaskInstanceData");
static_assert(offsetof(FFortStateTreeGetWeaponRemainingAmmoTaskInstanceData, Weapon) == 0x0, "Offset mismatch for FFortStateTreeGetWeaponRemainingAmmoTaskInstanceData::Weapon");
static_assert(offsetof(FFortStateTreeGetWeaponRemainingAmmoTaskInstanceData, RemainingAmmo) == 0x8, "Offset mismatch for FFortStateTreeGetWeaponRemainingAmmoTaskInstanceData::RemainingAmmo");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeGetWeaponRemainingAmmoTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortStateTreeGetWeaponRemainingAmmoTask) == 0x20, "Size mismatch for FFortStateTreeGetWeaponRemainingAmmoTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortStateTreeSetWeaponTargetingTaskInstanceData
{
    AFortWeapon* Weapon; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bShouldActivateTargeting; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeSetWeaponTargetingTaskInstanceData) == 0x10, "Size mismatch for FFortStateTreeSetWeaponTargetingTaskInstanceData");
static_assert(offsetof(FFortStateTreeSetWeaponTargetingTaskInstanceData, Weapon) == 0x0, "Offset mismatch for FFortStateTreeSetWeaponTargetingTaskInstanceData::Weapon");
static_assert(offsetof(FFortStateTreeSetWeaponTargetingTaskInstanceData, bShouldActivateTargeting) == 0x8, "Offset mismatch for FFortStateTreeSetWeaponTargetingTaskInstanceData::bShouldActivateTargeting");

// Size: 0x20 (Inherited: 0x78, Single: 0xffffffa8)
struct FFortStateTreeSetWeaponTargetingTask : FStateTreeAIActionTaskBase
{
};

static_assert(sizeof(FFortStateTreeSetWeaponTargetingTask) == 0x20, "Size mismatch for FFortStateTreeSetWeaponTargetingTask");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortStateTreeGetWeaponMagazineAmmoTaskInstanceData
{
    AFortWeapon* Weapon; // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t AmmoInMagazine; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeGetWeaponMagazineAmmoTaskInstanceData) == 0x10, "Size mismatch for FFortStateTreeGetWeaponMagazineAmmoTaskInstanceData");
static_assert(offsetof(FFortStateTreeGetWeaponMagazineAmmoTaskInstanceData, Weapon) == 0x0, "Offset mismatch for FFortStateTreeGetWeaponMagazineAmmoTaskInstanceData::Weapon");
static_assert(offsetof(FFortStateTreeGetWeaponMagazineAmmoTaskInstanceData, AmmoInMagazine) == 0x8, "Offset mismatch for FFortStateTreeGetWeaponMagazineAmmoTaskInstanceData::AmmoInMagazine");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeGetWeaponMagazineAmmoTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortStateTreeGetWeaponMagazineAmmoTask) == 0x20, "Size mismatch for FFortStateTreeGetWeaponMagazineAmmoTask");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFortStateTreeWaitUntilAbilityFinishedTaskInstanceData
{
    AFortPawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AFortWeapon* Weapon; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UGameplayAbility* ability; // 0x10 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_18[0x10]; // 0x18 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeWaitUntilAbilityFinishedTaskInstanceData) == 0x28, "Size mismatch for FFortStateTreeWaitUntilAbilityFinishedTaskInstanceData");
static_assert(offsetof(FFortStateTreeWaitUntilAbilityFinishedTaskInstanceData, Pawn) == 0x0, "Offset mismatch for FFortStateTreeWaitUntilAbilityFinishedTaskInstanceData::Pawn");
static_assert(offsetof(FFortStateTreeWaitUntilAbilityFinishedTaskInstanceData, Weapon) == 0x8, "Offset mismatch for FFortStateTreeWaitUntilAbilityFinishedTaskInstanceData::Weapon");
static_assert(offsetof(FFortStateTreeWaitUntilAbilityFinishedTaskInstanceData, ability) == 0x10, "Offset mismatch for FFortStateTreeWaitUntilAbilityFinishedTaskInstanceData::ability");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeWaitUntilAbilityFinishedTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortStateTreeWaitUntilAbilityFinishedTask) == 0x20, "Size mismatch for FFortStateTreeWaitUntilAbilityFinishedTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortStateTreeWaitUntilMantisBranchAvailableTaskInstanceData
{
    AFortWeapon* Weapon; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x10]; // 0x8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeWaitUntilMantisBranchAvailableTaskInstanceData) == 0x18, "Size mismatch for FFortStateTreeWaitUntilMantisBranchAvailableTaskInstanceData");
static_assert(offsetof(FFortStateTreeWaitUntilMantisBranchAvailableTaskInstanceData, Weapon) == 0x0, "Offset mismatch for FFortStateTreeWaitUntilMantisBranchAvailableTaskInstanceData::Weapon");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortStateTreeWaitUntilMantisBranchAvailableTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortStateTreeWaitUntilMantisBranchAvailableTask) == 0x20, "Size mismatch for FFortStateTreeWaitUntilMantisBranchAvailableTask");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFortWorldConditionGameplayTagActorQueryState
{
};

static_assert(sizeof(FFortWorldConditionGameplayTagActorQueryState) == 0x8, "Size mismatch for FFortWorldConditionGameplayTagActorQueryState");

// Size: 0x40 (Inherited: 0x20, Single: 0x20)
struct FFortWorldConditionGameplayTagActor : FWorldConditionCommonBase
{
    FWorldConditionContextDataRef ActorContextRef; // 0x10 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer TagContainerToCheck; // 0x18 (Size: 0x20, Type: StructProperty)
    uint8_t TestType; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortWorldConditionGameplayTagActor) == 0x40, "Size mismatch for FFortWorldConditionGameplayTagActor");
static_assert(offsetof(FFortWorldConditionGameplayTagActor, ActorContextRef) == 0x10, "Offset mismatch for FFortWorldConditionGameplayTagActor::ActorContextRef");
static_assert(offsetof(FFortWorldConditionGameplayTagActor, TagContainerToCheck) == 0x18, "Offset mismatch for FFortWorldConditionGameplayTagActor::TagContainerToCheck");
static_assert(offsetof(FFortWorldConditionGameplayTagActor, TestType) == 0x38, "Offset mismatch for FFortWorldConditionGameplayTagActor::TestType");

// Size: 0x20 (Inherited: 0x20, Single: 0x0)
struct FFortWorldConditionNativeAction : FWorldConditionCommonBase
{
    FWorldConditionContextDataRef BotControllerRef; // 0x10 (Size: 0x8, Type: StructProperty)
    FGameplayTag ActionTag; // 0x18 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortWorldConditionNativeAction) == 0x20, "Size mismatch for FFortWorldConditionNativeAction");
static_assert(offsetof(FFortWorldConditionNativeAction, BotControllerRef) == 0x10, "Offset mismatch for FFortWorldConditionNativeAction::BotControllerRef");
static_assert(offsetof(FFortWorldConditionNativeAction, ActionTag) == 0x18, "Offset mismatch for FFortWorldConditionNativeAction::ActionTag");

// Size: 0x20 (Inherited: 0x20, Single: 0x0)
struct FFortWorldConditionPlayerHasConvertedNPC : FWorldConditionCommonActorBase
{
    FWorldConditionContextDataRef ActorRef; // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t ConditionToCheck; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortWorldConditionPlayerHasConvertedNPC) == 0x20, "Size mismatch for FFortWorldConditionPlayerHasConvertedNPC");
static_assert(offsetof(FFortWorldConditionPlayerHasConvertedNPC, ActorRef) == 0x10, "Offset mismatch for FFortWorldConditionPlayerHasConvertedNPC::ActorRef");
static_assert(offsetof(FFortWorldConditionPlayerHasConvertedNPC, ConditionToCheck) == 0x18, "Offset mismatch for FFortWorldConditionPlayerHasConvertedNPC::ConditionToCheck");

// Size: 0x28 (Inherited: 0x20, Single: 0x8)
struct FFortWorldConditionPlayerUsesCID : FWorldConditionCommonActorBase
{
    FWorldConditionContextDataRef ActorRef; // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FPrimaryAssetId> AllowedCharacters; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortWorldConditionPlayerUsesCID) == 0x28, "Size mismatch for FFortWorldConditionPlayerUsesCID");
static_assert(offsetof(FFortWorldConditionPlayerUsesCID, ActorRef) == 0x10, "Offset mismatch for FFortWorldConditionPlayerUsesCID::ActorRef");
static_assert(offsetof(FFortWorldConditionPlayerUsesCID, AllowedCharacters) == 0x18, "Offset mismatch for FFortWorldConditionPlayerUsesCID::AllowedCharacters");

// Size: 0x28 (Inherited: 0x20, Single: 0x8)
struct FFortWorldConditionRealDateTime : FWorldConditionCommonBase
{
    int32_t ValidDaysOfWeek; // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t ValidMinHour; // 0x14 (Size: 0x4, Type: IntProperty)
    int32_t ValidMaxHour; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t ValidMinDayOfMonth; // 0x1c (Size: 0x4, Type: IntProperty)
    int32_t ValidMaxDayOfMonth; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortWorldConditionRealDateTime) == 0x28, "Size mismatch for FFortWorldConditionRealDateTime");
static_assert(offsetof(FFortWorldConditionRealDateTime, ValidDaysOfWeek) == 0x10, "Offset mismatch for FFortWorldConditionRealDateTime::ValidDaysOfWeek");
static_assert(offsetof(FFortWorldConditionRealDateTime, ValidMinHour) == 0x14, "Offset mismatch for FFortWorldConditionRealDateTime::ValidMinHour");
static_assert(offsetof(FFortWorldConditionRealDateTime, ValidMaxHour) == 0x18, "Offset mismatch for FFortWorldConditionRealDateTime::ValidMaxHour");
static_assert(offsetof(FFortWorldConditionRealDateTime, ValidMinDayOfMonth) == 0x1c, "Offset mismatch for FFortWorldConditionRealDateTime::ValidMinDayOfMonth");
static_assert(offsetof(FFortWorldConditionRealDateTime, ValidMaxDayOfMonth) == 0x20, "Offset mismatch for FFortWorldConditionRealDateTime::ValidMaxDayOfMonth");

// Size: 0x20 (Inherited: 0x20, Single: 0x0)
struct FFortWorldConditionTimeOfDay : FWorldConditionCommonBase
{
    FWorldConditionContextDataRef ActorContextRef; // 0x10 (Size: 0x8, Type: StructProperty)
    int32_t ValidTimesOfDay; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortWorldConditionTimeOfDay) == 0x20, "Size mismatch for FFortWorldConditionTimeOfDay");
static_assert(offsetof(FFortWorldConditionTimeOfDay, ActorContextRef) == 0x10, "Offset mismatch for FFortWorldConditionTimeOfDay::ActorContextRef");
static_assert(offsetof(FFortWorldConditionTimeOfDay, ValidTimesOfDay) == 0x18, "Offset mismatch for FFortWorldConditionTimeOfDay::ValidTimesOfDay");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFortWorldConditionWorldStatState
{
};

static_assert(sizeof(FFortWorldConditionWorldStatState) == 0x20, "Size mismatch for FFortWorldConditionWorldStatState");

// Size: 0x28 (Inherited: 0x20, Single: 0x8)
struct FFortWorldConditionWorldStat : FWorldConditionCommonBase
{
    FName WorldStatRowName; // 0x10 (Size: 0x4, Type: NameProperty)
    FInt32Range ValueRange; // 0x14 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortWorldConditionWorldStat) == 0x28, "Size mismatch for FFortWorldConditionWorldStat");
static_assert(offsetof(FFortWorldConditionWorldStat, WorldStatRowName) == 0x10, "Offset mismatch for FFortWorldConditionWorldStat::WorldStatRowName");
static_assert(offsetof(FFortWorldConditionWorldStat, ValueRange) == 0x14, "Offset mismatch for FFortWorldConditionWorldStat::ValueRange");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPFWNPCReactions_TriggeredReactions_PersistentInfoData
{
    TArray<FString> TriggeredReactionRowNames; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FPFWNPCReactions_TriggeredReactions_PersistentInfoData) == 0x10, "Size mismatch for FPFWNPCReactions_TriggeredReactions_PersistentInfoData");
static_assert(offsetof(FPFWNPCReactions_TriggeredReactions_PersistentInfoData, TriggeredReactionRowNames) == 0x0, "Offset mismatch for FPFWNPCReactions_TriggeredReactions_PersistentInfoData::TriggeredReactionRowNames");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPFWNPCReactions_PersistentInfo
{
    FPFWNPCReactions_TriggeredReactions_PersistentInfoData TriggeredReactions_PersistentInfoData; // 0x0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FPFWNPCReactions_PersistentInfo) == 0x10, "Size mismatch for FPFWNPCReactions_PersistentInfo");
static_assert(offsetof(FPFWNPCReactions_PersistentInfo, TriggeredReactions_PersistentInfoData) == 0x0, "Offset mismatch for FPFWNPCReactions_PersistentInfo::TriggeredReactions_PersistentInfoData");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FGameFeatureFortAIEvaluatorEntry
{
    TSoftObjectPtr<UBehaviorTree*> TreeAsset; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayTag InjectionTag; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TSoftClassPtr AIEvaluatorClass; // 0x28 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FGameFeatureFortAIEvaluatorEntry) == 0x48, "Size mismatch for FGameFeatureFortAIEvaluatorEntry");
static_assert(offsetof(FGameFeatureFortAIEvaluatorEntry, TreeAsset) == 0x0, "Offset mismatch for FGameFeatureFortAIEvaluatorEntry::TreeAsset");
static_assert(offsetof(FGameFeatureFortAIEvaluatorEntry, InjectionTag) == 0x20, "Offset mismatch for FGameFeatureFortAIEvaluatorEntry::InjectionTag");
static_assert(offsetof(FGameFeatureFortAIEvaluatorEntry, AIEvaluatorClass) == 0x28, "Offset mismatch for FGameFeatureFortAIEvaluatorEntry::AIEvaluatorClass");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFortPointOnCurveRange
{
    float MinPercentage; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxPercentage; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFortPointOnCurveRange) == 0x8, "Size mismatch for FFortPointOnCurveRange");
static_assert(offsetof(FFortPointOnCurveRange, MinPercentage) == 0x0, "Offset mismatch for FFortPointOnCurveRange::MinPercentage");
static_assert(offsetof(FFortPointOnCurveRange, MaxPercentage) == 0x4, "Offset mismatch for FFortPointOnCurveRange::MaxPercentage");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FFortPointsOnCurve
{
    TSoftObjectPtr<UCurveFloat*> Curve; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FFortPointOnCurveRange> RangesForPointsOnCurve; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortPointsOnCurve) == 0x30, "Size mismatch for FFortPointsOnCurve");
static_assert(offsetof(FFortPointsOnCurve, Curve) == 0x0, "Offset mismatch for FFortPointsOnCurve::Curve");
static_assert(offsetof(FFortPointsOnCurve, RangesForPointsOnCurve) == 0x20, "Offset mismatch for FFortPointsOnCurve::RangesForPointsOnCurve");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FFortQueryGenerator_PerceivedActors_Settings
{
    bool bIgnoreDBNOPawns; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreSleepingAIs; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x6]; // 0x2 (Size: 0x6, Type: PaddingProperty)
    FAIDataProviderFloatValue MaxTimeSincePerceived; // 0x8 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FFortQueryGenerator_PerceivedActors_Settings) == 0x40, "Size mismatch for FFortQueryGenerator_PerceivedActors_Settings");
static_assert(offsetof(FFortQueryGenerator_PerceivedActors_Settings, bIgnoreDBNOPawns) == 0x0, "Offset mismatch for FFortQueryGenerator_PerceivedActors_Settings::bIgnoreDBNOPawns");
static_assert(offsetof(FFortQueryGenerator_PerceivedActors_Settings, bIgnoreSleepingAIs) == 0x1, "Offset mismatch for FFortQueryGenerator_PerceivedActors_Settings::bIgnoreSleepingAIs");
static_assert(offsetof(FFortQueryGenerator_PerceivedActors_Settings, MaxTimeSincePerceived) == 0x8, "Offset mismatch for FFortQueryGenerator_PerceivedActors_Settings::MaxTimeSincePerceived");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FFortGameplayTagQueryPerDifficulty
{
    FDataTableRowHandle DifficultyInfo; // 0x0 (Size: 0x10, Type: StructProperty)
    FGameplayTagQuery TagQueryToMatch; // 0x10 (Size: 0x48, Type: StructProperty)
    float Difficulty; // 0x58 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortGameplayTagQueryPerDifficulty) == 0x60, "Size mismatch for FFortGameplayTagQueryPerDifficulty");
static_assert(offsetof(FFortGameplayTagQueryPerDifficulty, DifficultyInfo) == 0x0, "Offset mismatch for FFortGameplayTagQueryPerDifficulty::DifficultyInfo");
static_assert(offsetof(FFortGameplayTagQueryPerDifficulty, TagQueryToMatch) == 0x10, "Offset mismatch for FFortGameplayTagQueryPerDifficulty::TagQueryToMatch");
static_assert(offsetof(FFortGameplayTagQueryPerDifficulty, Difficulty) == 0x58, "Offset mismatch for FFortGameplayTagQueryPerDifficulty::Difficulty");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FGoalDistanceData
{
    bool bIgnoreScreeningDistance; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FAIDataProviderFloatValue ScreeningTestMaxDistance; // 0x8 (Size: 0x38, Type: StructProperty)
    TSoftObjectPtr<UCurveFloat*> TestScoreCurve; // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    FAIDataProviderFloatValue CurveDistanceScale; // 0x60 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FGoalDistanceData) == 0x98, "Size mismatch for FGoalDistanceData");
static_assert(offsetof(FGoalDistanceData, bIgnoreScreeningDistance) == 0x0, "Offset mismatch for FGoalDistanceData::bIgnoreScreeningDistance");
static_assert(offsetof(FGoalDistanceData, ScreeningTestMaxDistance) == 0x8, "Offset mismatch for FGoalDistanceData::ScreeningTestMaxDistance");
static_assert(offsetof(FGoalDistanceData, TestScoreCurve) == 0x40, "Offset mismatch for FGoalDistanceData::TestScoreCurve");
static_assert(offsetof(FGoalDistanceData, CurveDistanceScale) == 0x60, "Offset mismatch for FGoalDistanceData::CurveDistanceScale");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FFortStateTreeGameplayAbilityCondition : FStateTreeConditionCommonBase
{
    bool bInvert; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortStateTreeGameplayAbilityCondition) == 0x28, "Size mismatch for FFortStateTreeGameplayAbilityCondition");
static_assert(offsetof(FFortStateTreeGameplayAbilityCondition, bInvert) == 0x20, "Offset mismatch for FFortStateTreeGameplayAbilityCondition::bInvert");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFortGameplayAbilityIsOnCooldownInstanceData
{
    AActor* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AbilityTag; // 0x8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FFortGameplayAbilityIsOnCooldownInstanceData) == 0x28, "Size mismatch for FFortGameplayAbilityIsOnCooldownInstanceData");
static_assert(offsetof(FFortGameplayAbilityIsOnCooldownInstanceData, Pawn) == 0x0, "Offset mismatch for FFortGameplayAbilityIsOnCooldownInstanceData::Pawn");
static_assert(offsetof(FFortGameplayAbilityIsOnCooldownInstanceData, AbilityTag) == 0x8, "Offset mismatch for FFortGameplayAbilityIsOnCooldownInstanceData::AbilityTag");

// Size: 0x28 (Inherited: 0x80, Single: 0xffffffa8)
struct FFortGameplayAbilityIsOnCooldownCondition : FFortStateTreeGameplayAbilityCondition
{
};

static_assert(sizeof(FFortGameplayAbilityIsOnCooldownCondition) == 0x28, "Size mismatch for FFortGameplayAbilityIsOnCooldownCondition");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFortGameplayAbilityCanActivateAbilityInstanceData
{
    AActor* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AbilityTag; // 0x8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FFortGameplayAbilityCanActivateAbilityInstanceData) == 0x28, "Size mismatch for FFortGameplayAbilityCanActivateAbilityInstanceData");
static_assert(offsetof(FFortGameplayAbilityCanActivateAbilityInstanceData, Pawn) == 0x0, "Offset mismatch for FFortGameplayAbilityCanActivateAbilityInstanceData::Pawn");
static_assert(offsetof(FFortGameplayAbilityCanActivateAbilityInstanceData, AbilityTag) == 0x8, "Offset mismatch for FFortGameplayAbilityCanActivateAbilityInstanceData::AbilityTag");

// Size: 0x28 (Inherited: 0x80, Single: 0xffffffa8)
struct FFortGameplayAbilityCanActivateAbilityCondition : FFortStateTreeGameplayAbilityCondition
{
};

static_assert(sizeof(FFortGameplayAbilityCanActivateAbilityCondition) == 0x28, "Size mismatch for FFortGameplayAbilityCanActivateAbilityCondition");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FFortGameplayAbilityCanHitTargetInstanceData
{
    AFortPawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AbilityTag; // 0x10 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FFortGameplayAbilityCanHitTargetInstanceData) == 0x30, "Size mismatch for FFortGameplayAbilityCanHitTargetInstanceData");
static_assert(offsetof(FFortGameplayAbilityCanHitTargetInstanceData, Pawn) == 0x0, "Offset mismatch for FFortGameplayAbilityCanHitTargetInstanceData::Pawn");
static_assert(offsetof(FFortGameplayAbilityCanHitTargetInstanceData, TargetActor) == 0x8, "Offset mismatch for FFortGameplayAbilityCanHitTargetInstanceData::TargetActor");
static_assert(offsetof(FFortGameplayAbilityCanHitTargetInstanceData, AbilityTag) == 0x10, "Offset mismatch for FFortGameplayAbilityCanHitTargetInstanceData::AbilityTag");

// Size: 0x30 (Inherited: 0x80, Single: 0xffffffb0)
struct FFortGameplayAbilityCanHitTargetCondition : FFortStateTreeGameplayAbilityCondition
{
    bool bUseIdealYawRotationToTargetValue; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortGameplayAbilityCanHitTargetCondition) == 0x30, "Size mismatch for FFortGameplayAbilityCanHitTargetCondition");
static_assert(offsetof(FFortGameplayAbilityCanHitTargetCondition, bUseIdealYawRotationToTargetValue) == 0x28, "Offset mismatch for FFortGameplayAbilityCanHitTargetCondition::bUseIdealYawRotationToTargetValue");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FFortGameplayAbilityCompareDistanceInstanceData
{
    AFortPawn* Pawn; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer AbilityTag; // 0x10 (Size: 0x20, Type: StructProperty)
    TArray<FDistanceToTargetComparison> DistanceComparisons; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortGameplayAbilityCompareDistanceInstanceData) == 0x40, "Size mismatch for FFortGameplayAbilityCompareDistanceInstanceData");
static_assert(offsetof(FFortGameplayAbilityCompareDistanceInstanceData, Pawn) == 0x0, "Offset mismatch for FFortGameplayAbilityCompareDistanceInstanceData::Pawn");
static_assert(offsetof(FFortGameplayAbilityCompareDistanceInstanceData, TargetActor) == 0x8, "Offset mismatch for FFortGameplayAbilityCompareDistanceInstanceData::TargetActor");
static_assert(offsetof(FFortGameplayAbilityCompareDistanceInstanceData, AbilityTag) == 0x10, "Offset mismatch for FFortGameplayAbilityCompareDistanceInstanceData::AbilityTag");
static_assert(offsetof(FFortGameplayAbilityCompareDistanceInstanceData, DistanceComparisons) == 0x30, "Offset mismatch for FFortGameplayAbilityCompareDistanceInstanceData::DistanceComparisons");

// Size: 0x28 (Inherited: 0x80, Single: 0xffffffa8)
struct FFortGameplayAbilityCompareDistanceCondition : FFortStateTreeGameplayAbilityCondition
{
};

static_assert(sizeof(FFortGameplayAbilityCompareDistanceCondition) == 0x28, "Size mismatch for FFortGameplayAbilityCompareDistanceCondition");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FMimicConverterAbilityData
{
    FGameplayTagQuery RequiredConverterAbilityTags; // 0x0 (Size: 0x48, Type: StructProperty)
    FGameplayTagContainer AbilitiesToApply; // 0x48 (Size: 0x20, Type: StructProperty)
    TArray<UClass*> GEsToApply; // 0x68 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FMimicConverterAbilityData) == 0x78, "Size mismatch for FMimicConverterAbilityData");
static_assert(offsetof(FMimicConverterAbilityData, RequiredConverterAbilityTags) == 0x0, "Offset mismatch for FMimicConverterAbilityData::RequiredConverterAbilityTags");
static_assert(offsetof(FMimicConverterAbilityData, AbilitiesToApply) == 0x48, "Offset mismatch for FMimicConverterAbilityData::AbilitiesToApply");
static_assert(offsetof(FMimicConverterAbilityData, GEsToApply) == 0x68, "Offset mismatch for FMimicConverterAbilityData::GEsToApply");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FEscalateTargetData
{
    TWeakObjectPtr<AFortPlayerPawn*> Target; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_8[0x10]; // 0x8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FEscalateTargetData) == 0x18, "Size mismatch for FEscalateTargetData");
static_assert(offsetof(FEscalateTargetData, Target) == 0x0, "Offset mismatch for FEscalateTargetData::Target");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFlankingLocationInfo
{
};

static_assert(sizeof(FFlankingLocationInfo) == 0x20, "Size mismatch for FFlankingLocationInfo");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFailedToReachPOI
{
    int32_t BotPOIID; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t FailCount; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FFailedToReachPOI) == 0x8, "Size mismatch for FFailedToReachPOI");
static_assert(offsetof(FFailedToReachPOI, BotPOIID) == 0x0, "Offset mismatch for FFailedToReachPOI::BotPOIID");
static_assert(offsetof(FFailedToReachPOI, FailCount) == 0x4, "Offset mismatch for FFailedToReachPOI::FailCount");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FFortEvaluatorBlueprintBaseCooldown
{
    TEnumAsByte<ECooldownType> CooldownType; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FScalableFloat Cooldown; // 0x8 (Size: 0x28, Type: StructProperty)
    FScalableFloat CooldownVariation; // 0x30 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FFortEvaluatorBlueprintBaseCooldown) == 0x58, "Size mismatch for FFortEvaluatorBlueprintBaseCooldown");
static_assert(offsetof(FFortEvaluatorBlueprintBaseCooldown, CooldownType) == 0x0, "Offset mismatch for FFortEvaluatorBlueprintBaseCooldown::CooldownType");
static_assert(offsetof(FFortEvaluatorBlueprintBaseCooldown, Cooldown) == 0x8, "Offset mismatch for FFortEvaluatorBlueprintBaseCooldown::Cooldown");
static_assert(offsetof(FFortEvaluatorBlueprintBaseCooldown, CooldownVariation) == 0x30, "Offset mismatch for FFortEvaluatorBlueprintBaseCooldown::CooldownVariation");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameplayAbilityEvaluatorModule
{
    FGameplayTagContainer GameplayAbilityTag; // 0x0 (Size: 0x20, Type: StructProperty)
    UAbilitySystemComponent* CachedAbilitySystemComponent; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGameplayAbilityEvaluatorModule) == 0x28, "Size mismatch for FGameplayAbilityEvaluatorModule");
static_assert(offsetof(FGameplayAbilityEvaluatorModule, GameplayAbilityTag) == 0x0, "Offset mismatch for FGameplayAbilityEvaluatorModule::GameplayAbilityTag");
static_assert(offsetof(FGameplayAbilityEvaluatorModule, CachedAbilitySystemComponent) == 0x20, "Offset mismatch for FGameplayAbilityEvaluatorModule::CachedAbilitySystemComponent");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayTagActorHasMatchingGameplayTagInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag TagToCheck; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayTagActorHasMatchingGameplayTagInstanceData) == 0x10, "Size mismatch for FGameplayTagActorHasMatchingGameplayTagInstanceData");
static_assert(offsetof(FGameplayTagActorHasMatchingGameplayTagInstanceData, Actor) == 0x0, "Offset mismatch for FGameplayTagActorHasMatchingGameplayTagInstanceData::Actor");
static_assert(offsetof(FGameplayTagActorHasMatchingGameplayTagInstanceData, TagToCheck) == 0x8, "Offset mismatch for FGameplayTagActorHasMatchingGameplayTagInstanceData::TagToCheck");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FGameplayTagActorHasMatchingGameplayTagCondition : FStateTreeConditionCommonBase
{
    bool bInvert; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayTagActorHasMatchingGameplayTagCondition) == 0x28, "Size mismatch for FGameplayTagActorHasMatchingGameplayTagCondition");
static_assert(offsetof(FGameplayTagActorHasMatchingGameplayTagCondition, bInvert) == 0x20, "Offset mismatch for FGameplayTagActorHasMatchingGameplayTagCondition::bInvert");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameplayTagActorHasMatchingGameplayTagContainerInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer TagContainerToCheck; // 0x8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FGameplayTagActorHasMatchingGameplayTagContainerInstanceData) == 0x28, "Size mismatch for FGameplayTagActorHasMatchingGameplayTagContainerInstanceData");
static_assert(offsetof(FGameplayTagActorHasMatchingGameplayTagContainerInstanceData, Actor) == 0x0, "Offset mismatch for FGameplayTagActorHasMatchingGameplayTagContainerInstanceData::Actor");
static_assert(offsetof(FGameplayTagActorHasMatchingGameplayTagContainerInstanceData, TagContainerToCheck) == 0x8, "Offset mismatch for FGameplayTagActorHasMatchingGameplayTagContainerInstanceData::TagContainerToCheck");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FGameplayTagActorHasMatchingGameplayContainerTagCondition : FStateTreeConditionCommonBase
{
    uint8_t TestType; // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bInvert; // 0x21 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_22[0x6]; // 0x22 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayTagActorHasMatchingGameplayContainerTagCondition) == 0x28, "Size mismatch for FGameplayTagActorHasMatchingGameplayContainerTagCondition");
static_assert(offsetof(FGameplayTagActorHasMatchingGameplayContainerTagCondition, TestType) == 0x20, "Offset mismatch for FGameplayTagActorHasMatchingGameplayContainerTagCondition::TestType");
static_assert(offsetof(FGameplayTagActorHasMatchingGameplayContainerTagCondition, bInvert) == 0x21, "Offset mismatch for FGameplayTagActorHasMatchingGameplayContainerTagCondition::bInvert");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFortAthenaAddGameplayTagsStateTreeTaskInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer Tags; // 0x8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FFortAthenaAddGameplayTagsStateTreeTaskInstanceData) == 0x28, "Size mismatch for FFortAthenaAddGameplayTagsStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaAddGameplayTagsStateTreeTaskInstanceData, Actor) == 0x0, "Offset mismatch for FFortAthenaAddGameplayTagsStateTreeTaskInstanceData::Actor");
static_assert(offsetof(FFortAthenaAddGameplayTagsStateTreeTaskInstanceData, Tags) == 0x8, "Offset mismatch for FFortAthenaAddGameplayTagsStateTreeTaskInstanceData::Tags");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
struct FFortAthenaAddGameplayTagsStateTreeTask : FStateTreeTaskCommonBase
{
    bool bReplicateChange; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x3]; // 0x21 (Size: 0x3, Type: PaddingProperty)
    uint8_t AddExecutionMode[0x4]; // 0x24 (Size: 0x4, Type: EnumProperty)
    uint8_t RemoveExecutionMode[0x4]; // 0x28 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaAddGameplayTagsStateTreeTask) == 0x30, "Size mismatch for FFortAthenaAddGameplayTagsStateTreeTask");
static_assert(offsetof(FFortAthenaAddGameplayTagsStateTreeTask, bReplicateChange) == 0x20, "Offset mismatch for FFortAthenaAddGameplayTagsStateTreeTask::bReplicateChange");
static_assert(offsetof(FFortAthenaAddGameplayTagsStateTreeTask, AddExecutionMode) == 0x24, "Offset mismatch for FFortAthenaAddGameplayTagsStateTreeTask::AddExecutionMode");
static_assert(offsetof(FFortAthenaAddGameplayTagsStateTreeTask, RemoveExecutionMode) == 0x28, "Offset mismatch for FFortAthenaAddGameplayTagsStateTreeTask::RemoveExecutionMode");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FFortAthenaArithmeticStateTreeTask : FStateTreeTaskCommonBase
{
    uint8_t OperationTrigger; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Operation; // 0x21 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_22[0x6]; // 0x22 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaArithmeticStateTreeTask) == 0x28, "Size mismatch for FFortAthenaArithmeticStateTreeTask");
static_assert(offsetof(FFortAthenaArithmeticStateTreeTask, OperationTrigger) == 0x20, "Offset mismatch for FFortAthenaArithmeticStateTreeTask::OperationTrigger");
static_assert(offsetof(FFortAthenaArithmeticStateTreeTask, Operation) == 0x21, "Offset mismatch for FFortAthenaArithmeticStateTreeTask::Operation");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortAthenaIntArithmeticStateTreeTaskInstanceData
{
    int32_t FirstOperand; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t SecondOperand; // 0x4 (Size: 0x4, Type: IntProperty)
    FStateTreeStructRef ReferencedResult; // 0x8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FFortAthenaIntArithmeticStateTreeTaskInstanceData) == 0x18, "Size mismatch for FFortAthenaIntArithmeticStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaIntArithmeticStateTreeTaskInstanceData, FirstOperand) == 0x0, "Offset mismatch for FFortAthenaIntArithmeticStateTreeTaskInstanceData::FirstOperand");
static_assert(offsetof(FFortAthenaIntArithmeticStateTreeTaskInstanceData, SecondOperand) == 0x4, "Offset mismatch for FFortAthenaIntArithmeticStateTreeTaskInstanceData::SecondOperand");
static_assert(offsetof(FFortAthenaIntArithmeticStateTreeTaskInstanceData, ReferencedResult) == 0x8, "Offset mismatch for FFortAthenaIntArithmeticStateTreeTaskInstanceData::ReferencedResult");

// Size: 0x28 (Inherited: 0x80, Single: 0xffffffa8)
struct FFortAthenaIntArithmeticStateTreeTask : FFortAthenaArithmeticStateTreeTask
{
};

static_assert(sizeof(FFortAthenaIntArithmeticStateTreeTask) == 0x28, "Size mismatch for FFortAthenaIntArithmeticStateTreeTask");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData
{
    AActor* UserActor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* SmartObjectActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer Tags; // 0x10 (Size: 0x20, Type: StructProperty)
    UAnimMontage* PickedMontage; // 0x30 (Size: 0x8, Type: ObjectProperty)
    UContextualAnimSceneAsset* PickedSceneAsset; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData) == 0x40, "Size mismatch for FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData, UserActor) == 0x0, "Offset mismatch for FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData::UserActor");
static_assert(offsetof(FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData, SmartObjectActor) == 0x8, "Offset mismatch for FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData::SmartObjectActor");
static_assert(offsetof(FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData, Tags) == 0x10, "Offset mismatch for FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData::Tags");
static_assert(offsetof(FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData, PickedMontage) == 0x30, "Offset mismatch for FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData::PickedMontage");
static_assert(offsetof(FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData, PickedSceneAsset) == 0x38, "Offset mismatch for FFortAthenaFindSmartObjectAnimForActorStateTreeTaskInstanceData::PickedSceneAsset");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortAthenaFindSmartObjectAnimForActorStateTreeTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortAthenaFindSmartObjectAnimForActorStateTreeTask) == 0x20, "Size mismatch for FFortAthenaFindSmartObjectAnimForActorStateTreeTask");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FFortAthenaFocusAtStateTreeTaskInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* FocusActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector FocusActorOffset; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector FocusWorldPoint; // 0x28 (Size: 0x18, Type: StructProperty)
    bool bSetBackOnExit; // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bShouldSetFocus; // 0x41 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_42[0x4e]; // 0x42 (Size: 0x4e, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaFocusAtStateTreeTaskInstanceData) == 0x90, "Size mismatch for FFortAthenaFocusAtStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaFocusAtStateTreeTaskInstanceData, Actor) == 0x0, "Offset mismatch for FFortAthenaFocusAtStateTreeTaskInstanceData::Actor");
static_assert(offsetof(FFortAthenaFocusAtStateTreeTaskInstanceData, FocusActor) == 0x8, "Offset mismatch for FFortAthenaFocusAtStateTreeTaskInstanceData::FocusActor");
static_assert(offsetof(FFortAthenaFocusAtStateTreeTaskInstanceData, FocusActorOffset) == 0x10, "Offset mismatch for FFortAthenaFocusAtStateTreeTaskInstanceData::FocusActorOffset");
static_assert(offsetof(FFortAthenaFocusAtStateTreeTaskInstanceData, FocusWorldPoint) == 0x28, "Offset mismatch for FFortAthenaFocusAtStateTreeTaskInstanceData::FocusWorldPoint");
static_assert(offsetof(FFortAthenaFocusAtStateTreeTaskInstanceData, bSetBackOnExit) == 0x40, "Offset mismatch for FFortAthenaFocusAtStateTreeTaskInstanceData::bSetBackOnExit");
static_assert(offsetof(FFortAthenaFocusAtStateTreeTaskInstanceData, bShouldSetFocus) == 0x41, "Offset mismatch for FFortAthenaFocusAtStateTreeTaskInstanceData::bShouldSetFocus");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortAthenaFocusAtStateTreeTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortAthenaFocusAtStateTreeTask) == 0x20, "Size mismatch for FFortAthenaFocusAtStateTreeTask");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FFortAthenaIntStateTreeParameter
{
    int32_t int; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FFortAthenaIntStateTreeParameter) == 0x4, "Size mismatch for FFortAthenaIntStateTreeParameter");
static_assert(offsetof(FFortAthenaIntStateTreeParameter, int) == 0x0, "Offset mismatch for FFortAthenaIntStateTreeParameter::int");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFortAthenaMakeIntVariableStateTreeTaskInstanceData
{
    int32_t DefaultIntValue; // 0x0 (Size: 0x4, Type: IntProperty)
    FFortAthenaIntStateTreeParameter OutInt; // 0x4 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FFortAthenaMakeIntVariableStateTreeTaskInstanceData) == 0x8, "Size mismatch for FFortAthenaMakeIntVariableStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaMakeIntVariableStateTreeTaskInstanceData, DefaultIntValue) == 0x0, "Offset mismatch for FFortAthenaMakeIntVariableStateTreeTaskInstanceData::DefaultIntValue");
static_assert(offsetof(FFortAthenaMakeIntVariableStateTreeTaskInstanceData, OutInt) == 0x4, "Offset mismatch for FFortAthenaMakeIntVariableStateTreeTaskInstanceData::OutInt");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FFortAthenaMakeIntVariableStateTreeTask : FStateTreeTaskCommonBase
{
    bool bResetOnReselect; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaMakeIntVariableStateTreeTask) == 0x28, "Size mismatch for FFortAthenaMakeIntVariableStateTreeTask");
static_assert(offsetof(FFortAthenaMakeIntVariableStateTreeTask, bResetOnReselect) == 0x20, "Offset mismatch for FFortAthenaMakeIntVariableStateTreeTask::bResetOnReselect");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortAthenaPlayContextualAnimStateTreeTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortAthenaPlayContextualAnimStateTreeTask) == 0x20, "Size mismatch for FFortAthenaPlayContextualAnimStateTreeTask");

// Size: 0x24 (Inherited: 0x0, Single: 0x24)
struct FFortAthenaPlayInteractionStateTreeTaskActorInfo
{
};

static_assert(sizeof(FFortAthenaPlayInteractionStateTreeTaskActorInfo) == 0x24, "Size mismatch for FFortAthenaPlayInteractionStateTreeTaskActorInfo");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FSTFortAthenaPlayMontageWarpTarget
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector Location; // 0x8 (Size: 0x18, Type: StructProperty)
    FQuat Rotation; // 0x20 (Size: 0x20, Type: StructProperty)
    AActor* Actor; // 0x40 (Size: 0x8, Type: ObjectProperty)
    FName BoneOrSocketName; // 0x48 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FSTFortAthenaPlayMontageWarpTarget) == 0x50, "Size mismatch for FSTFortAthenaPlayMontageWarpTarget");
static_assert(offsetof(FSTFortAthenaPlayMontageWarpTarget, Name) == 0x0, "Offset mismatch for FSTFortAthenaPlayMontageWarpTarget::Name");
static_assert(offsetof(FSTFortAthenaPlayMontageWarpTarget, Location) == 0x8, "Offset mismatch for FSTFortAthenaPlayMontageWarpTarget::Location");
static_assert(offsetof(FSTFortAthenaPlayMontageWarpTarget, Rotation) == 0x20, "Offset mismatch for FSTFortAthenaPlayMontageWarpTarget::Rotation");
static_assert(offsetof(FSTFortAthenaPlayMontageWarpTarget, Actor) == 0x40, "Offset mismatch for FSTFortAthenaPlayMontageWarpTarget::Actor");
static_assert(offsetof(FSTFortAthenaPlayMontageWarpTarget, BoneOrSocketName) == 0x48, "Offset mismatch for FSTFortAthenaPlayMontageWarpTarget::BoneOrSocketName");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFortAthenaStateTreeCrouchTaskInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortAthenaStateTreeCrouchTaskInstanceData) == 0x8, "Size mismatch for FFortAthenaStateTreeCrouchTaskInstanceData");
static_assert(offsetof(FFortAthenaStateTreeCrouchTaskInstanceData, Actor) == 0x0, "Offset mismatch for FFortAthenaStateTreeCrouchTaskInstanceData::Actor");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortAthenaStateTreeCrouchTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortAthenaStateTreeCrouchTask) == 0x20, "Size mismatch for FFortAthenaStateTreeCrouchTask");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFortAthenaStateTreeInteractTaskInstanceData
{
    TEnumAsByte<TInteractionType> InteractType; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    AActor* Actor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    AActor* InteractTargetActor; // 0x10 (Size: 0x8, Type: ObjectProperty)
    float InteractDuration; // 0x18 (Size: 0x4, Type: FloatProperty)
    float Timer; // 0x1c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFortAthenaStateTreeInteractTaskInstanceData) == 0x20, "Size mismatch for FFortAthenaStateTreeInteractTaskInstanceData");
static_assert(offsetof(FFortAthenaStateTreeInteractTaskInstanceData, InteractType) == 0x0, "Offset mismatch for FFortAthenaStateTreeInteractTaskInstanceData::InteractType");
static_assert(offsetof(FFortAthenaStateTreeInteractTaskInstanceData, Actor) == 0x8, "Offset mismatch for FFortAthenaStateTreeInteractTaskInstanceData::Actor");
static_assert(offsetof(FFortAthenaStateTreeInteractTaskInstanceData, InteractTargetActor) == 0x10, "Offset mismatch for FFortAthenaStateTreeInteractTaskInstanceData::InteractTargetActor");
static_assert(offsetof(FFortAthenaStateTreeInteractTaskInstanceData, InteractDuration) == 0x18, "Offset mismatch for FFortAthenaStateTreeInteractTaskInstanceData::InteractDuration");
static_assert(offsetof(FFortAthenaStateTreeInteractTaskInstanceData, Timer) == 0x1c, "Offset mismatch for FFortAthenaStateTreeInteractTaskInstanceData::Timer");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortAthenaStateTreeInteractTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortAthenaStateTreeInteractTask) == 0x20, "Size mismatch for FFortAthenaStateTreeInteractTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortAthenaStateTreeLookAroundTaskInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    float LookAtDurationMin; // 0x8 (Size: 0x4, Type: FloatProperty)
    float LookAtDurationMax; // 0xc (Size: 0x4, Type: FloatProperty)
    float LookAtDuration; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Timer; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFortAthenaStateTreeLookAroundTaskInstanceData) == 0x18, "Size mismatch for FFortAthenaStateTreeLookAroundTaskInstanceData");
static_assert(offsetof(FFortAthenaStateTreeLookAroundTaskInstanceData, Actor) == 0x0, "Offset mismatch for FFortAthenaStateTreeLookAroundTaskInstanceData::Actor");
static_assert(offsetof(FFortAthenaStateTreeLookAroundTaskInstanceData, LookAtDurationMin) == 0x8, "Offset mismatch for FFortAthenaStateTreeLookAroundTaskInstanceData::LookAtDurationMin");
static_assert(offsetof(FFortAthenaStateTreeLookAroundTaskInstanceData, LookAtDurationMax) == 0xc, "Offset mismatch for FFortAthenaStateTreeLookAroundTaskInstanceData::LookAtDurationMax");
static_assert(offsetof(FFortAthenaStateTreeLookAroundTaskInstanceData, LookAtDuration) == 0x10, "Offset mismatch for FFortAthenaStateTreeLookAroundTaskInstanceData::LookAtDuration");
static_assert(offsetof(FFortAthenaStateTreeLookAroundTaskInstanceData, Timer) == 0x14, "Offset mismatch for FFortAthenaStateTreeLookAroundTaskInstanceData::Timer");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortAthenaStateTreeLookAroundTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortAthenaStateTreeLookAroundTask) == 0x20, "Size mismatch for FFortAthenaStateTreeLookAroundTask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortAthenaStateTreeSendGameplayEventTaskInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* Target; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag EventTag; // 0x10 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaStateTreeSendGameplayEventTaskInstanceData) == 0x18, "Size mismatch for FFortAthenaStateTreeSendGameplayEventTaskInstanceData");
static_assert(offsetof(FFortAthenaStateTreeSendGameplayEventTaskInstanceData, Actor) == 0x0, "Offset mismatch for FFortAthenaStateTreeSendGameplayEventTaskInstanceData::Actor");
static_assert(offsetof(FFortAthenaStateTreeSendGameplayEventTaskInstanceData, Target) == 0x8, "Offset mismatch for FFortAthenaStateTreeSendGameplayEventTaskInstanceData::Target");
static_assert(offsetof(FFortAthenaStateTreeSendGameplayEventTaskInstanceData, EventTag) == 0x10, "Offset mismatch for FFortAthenaStateTreeSendGameplayEventTaskInstanceData::EventTag");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortAthenaStateTreeSendGameplayEventTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortAthenaStateTreeSendGameplayEventTask) == 0x20, "Size mismatch for FFortAthenaStateTreeSendGameplayEventTask");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FFortAthenaTeleportToActorStateTreeTaskInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector TeleportRelativeLocation; // 0x10 (Size: 0x18, Type: StructProperty)
    FRotator TeleportRelativeRotation; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FFortAthenaTeleportToActorStateTreeTaskInstanceData) == 0x40, "Size mismatch for FFortAthenaTeleportToActorStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaTeleportToActorStateTreeTaskInstanceData, Actor) == 0x0, "Offset mismatch for FFortAthenaTeleportToActorStateTreeTaskInstanceData::Actor");
static_assert(offsetof(FFortAthenaTeleportToActorStateTreeTaskInstanceData, TargetActor) == 0x8, "Offset mismatch for FFortAthenaTeleportToActorStateTreeTaskInstanceData::TargetActor");
static_assert(offsetof(FFortAthenaTeleportToActorStateTreeTaskInstanceData, TeleportRelativeLocation) == 0x10, "Offset mismatch for FFortAthenaTeleportToActorStateTreeTaskInstanceData::TeleportRelativeLocation");
static_assert(offsetof(FFortAthenaTeleportToActorStateTreeTaskInstanceData, TeleportRelativeRotation) == 0x28, "Offset mismatch for FFortAthenaTeleportToActorStateTreeTaskInstanceData::TeleportRelativeRotation");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FFortAthenaTeleportToActorStateTreeTask : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FFortAthenaTeleportToActorStateTreeTask) == 0x20, "Size mismatch for FFortAthenaTeleportToActorStateTreeTask");

// Size: 0xc8 (Inherited: 0x0, Single: 0xc8)
struct FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* TargetActor; // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<UClass*> GameplayEffectClassesToAdd; // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bAutomaticallyRemoveAddedEffectsOnExit; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
    TArray<UClass*> GameplayEffectClassesToRemove; // 0x28 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer GameplayEffectsByTagsToRemove; // 0x38 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer GameplayEffectsBySourceTagsToRemove; // 0x58 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer GameplayEffectsByAppliedTagsToRemove; // 0x78 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer GameplayEffectsByGrantedTagsToRemove; // 0x98 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_b8[0x10]; // 0xb8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData) == 0xc8, "Size mismatch for FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData");
static_assert(offsetof(FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData, Actor) == 0x0, "Offset mismatch for FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData::Actor");
static_assert(offsetof(FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData, TargetActor) == 0x8, "Offset mismatch for FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData::TargetActor");
static_assert(offsetof(FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData, GameplayEffectClassesToAdd) == 0x10, "Offset mismatch for FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData::GameplayEffectClassesToAdd");
static_assert(offsetof(FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData, bAutomaticallyRemoveAddedEffectsOnExit) == 0x20, "Offset mismatch for FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData::bAutomaticallyRemoveAddedEffectsOnExit");
static_assert(offsetof(FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData, GameplayEffectClassesToRemove) == 0x28, "Offset mismatch for FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData::GameplayEffectClassesToRemove");
static_assert(offsetof(FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData, GameplayEffectsByTagsToRemove) == 0x38, "Offset mismatch for FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData::GameplayEffectsByTagsToRemove");
static_assert(offsetof(FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData, GameplayEffectsBySourceTagsToRemove) == 0x58, "Offset mismatch for FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData::GameplayEffectsBySourceTagsToRemove");
static_assert(offsetof(FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData, GameplayEffectsByAppliedTagsToRemove) == 0x78, "Offset mismatch for FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData::GameplayEffectsByAppliedTagsToRemove");
static_assert(offsetof(FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData, GameplayEffectsByGrantedTagsToRemove) == 0x98, "Offset mismatch for FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData::GameplayEffectsByGrantedTagsToRemove");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FFortAthenaToggleGameplayEffectStateTreeTask : FStateTreeTaskCommonBase
{
    uint8_t AddExecutionMode[0x4]; // 0x20 (Size: 0x4, Type: EnumProperty)
    uint8_t RemoveExecutionMode[0x4]; // 0x24 (Size: 0x4, Type: EnumProperty)
};

static_assert(sizeof(FFortAthenaToggleGameplayEffectStateTreeTask) == 0x28, "Size mismatch for FFortAthenaToggleGameplayEffectStateTreeTask");
static_assert(offsetof(FFortAthenaToggleGameplayEffectStateTreeTask, AddExecutionMode) == 0x20, "Offset mismatch for FFortAthenaToggleGameplayEffectStateTreeTask::AddExecutionMode");
static_assert(offsetof(FFortAthenaToggleGameplayEffectStateTreeTask, RemoveExecutionMode) == 0x24, "Offset mismatch for FFortAthenaToggleGameplayEffectStateTreeTask::RemoveExecutionMode");

// Size: 0x58 (Inherited: 0x20, Single: 0x38)
struct FFortWorldConditionPlaylist : FWorldConditionCommonBase
{
    FGameplayTagQuery PlaylistQuery; // 0x10 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FFortWorldConditionPlaylist) == 0x58, "Size mismatch for FFortWorldConditionPlaylist");
static_assert(offsetof(FFortWorldConditionPlaylist, PlaylistQuery) == 0x10, "Offset mismatch for FFortWorldConditionPlaylist::PlaylistQuery");

// Size: 0x58 (Inherited: 0x20, Single: 0x38)
struct FFortWorldConditionWorldState : FWorldConditionCommonBase
{
    FGameplayTagQuery WorldStateQuery; // 0x10 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FFortWorldConditionWorldState) == 0x58, "Size mismatch for FFortWorldConditionWorldState");
static_assert(offsetof(FFortWorldConditionWorldState, WorldStateQuery) == 0x10, "Offset mismatch for FFortWorldConditionWorldState::WorldStateQuery");

