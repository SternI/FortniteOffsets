/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FullBodyIK
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ControlRig.h"
#include "CoreUObject.h"

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFBIKBoneLimit
{
    uint8_t LimitType_X; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t LimitType_Y; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t LimitType_Z; // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3[0x5]; // 0x3 (Size: 0x5, Type: PaddingProperty)
    FVector Limit; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FFBIKBoneLimit) == 0x20, "Size mismatch for FFBIKBoneLimit");
static_assert(offsetof(FFBIKBoneLimit, LimitType_X) == 0x0, "Offset mismatch for FFBIKBoneLimit::LimitType_X");
static_assert(offsetof(FFBIKBoneLimit, LimitType_Y) == 0x1, "Offset mismatch for FFBIKBoneLimit::LimitType_Y");
static_assert(offsetof(FFBIKBoneLimit, LimitType_Z) == 0x2, "Offset mismatch for FFBIKBoneLimit::LimitType_Z");
static_assert(offsetof(FFBIKBoneLimit, Limit) == 0x8, "Offset mismatch for FFBIKBoneLimit::Limit");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FFBIKConstraintOption
{
    FRigElementKey Item; // 0x0 (Size: 0x8, Type: StructProperty)
    bool bEnabled; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bUseStiffness; // 0x9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a[0x6]; // 0xa (Size: 0x6, Type: PaddingProperty)
    FVector LinearStiffness; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector AngularStiffness; // 0x28 (Size: 0x18, Type: StructProperty)
    bool bUseAngularLimit; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
    FFBIKBoneLimit AngularLimit; // 0x48 (Size: 0x20, Type: StructProperty)
    bool bUsePoleVector; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t PoleVectorOption; // 0x69 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_6a[0x6]; // 0x6a (Size: 0x6, Type: PaddingProperty)
    FVector PoleVector; // 0x70 (Size: 0x18, Type: StructProperty)
    FRotator OffsetRotation; // 0x88 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FFBIKConstraintOption) == 0xa0, "Size mismatch for FFBIKConstraintOption");
static_assert(offsetof(FFBIKConstraintOption, Item) == 0x0, "Offset mismatch for FFBIKConstraintOption::Item");
static_assert(offsetof(FFBIKConstraintOption, bEnabled) == 0x8, "Offset mismatch for FFBIKConstraintOption::bEnabled");
static_assert(offsetof(FFBIKConstraintOption, bUseStiffness) == 0x9, "Offset mismatch for FFBIKConstraintOption::bUseStiffness");
static_assert(offsetof(FFBIKConstraintOption, LinearStiffness) == 0x10, "Offset mismatch for FFBIKConstraintOption::LinearStiffness");
static_assert(offsetof(FFBIKConstraintOption, AngularStiffness) == 0x28, "Offset mismatch for FFBIKConstraintOption::AngularStiffness");
static_assert(offsetof(FFBIKConstraintOption, bUseAngularLimit) == 0x40, "Offset mismatch for FFBIKConstraintOption::bUseAngularLimit");
static_assert(offsetof(FFBIKConstraintOption, AngularLimit) == 0x48, "Offset mismatch for FFBIKConstraintOption::AngularLimit");
static_assert(offsetof(FFBIKConstraintOption, bUsePoleVector) == 0x68, "Offset mismatch for FFBIKConstraintOption::bUsePoleVector");
static_assert(offsetof(FFBIKConstraintOption, PoleVectorOption) == 0x69, "Offset mismatch for FFBIKConstraintOption::PoleVectorOption");
static_assert(offsetof(FFBIKConstraintOption, PoleVector) == 0x70, "Offset mismatch for FFBIKConstraintOption::PoleVector");
static_assert(offsetof(FFBIKConstraintOption, OffsetRotation) == 0x88, "Offset mismatch for FFBIKConstraintOption::OffsetRotation");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FMotionProcessInput
{
    bool bForceEffectorRotationTarget; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bOnlyApplyWhenReachedToTarget; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FMotionProcessInput) == 0x2, "Size mismatch for FMotionProcessInput");
static_assert(offsetof(FMotionProcessInput, bForceEffectorRotationTarget) == 0x0, "Offset mismatch for FMotionProcessInput::bForceEffectorRotationTarget");
static_assert(offsetof(FMotionProcessInput, bOnlyApplyWhenReachedToTarget) == 0x1, "Offset mismatch for FMotionProcessInput::bOnlyApplyWhenReachedToTarget");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FFBIKDebugOption
{
    bool bDrawDebugHierarchy; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bColorAngularMotionStrength; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bColorLinearMotionStrength; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bDrawDebugAxes; // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bDrawDebugEffector; // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bDrawDebugConstraints; // 0x5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6[0xa]; // 0x6 (Size: 0xa, Type: PaddingProperty)
    FTransform DrawWorldOffset; // 0x10 (Size: 0x60, Type: StructProperty)
    float DrawSize; // 0x70 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_74[0xc]; // 0x74 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FFBIKDebugOption) == 0x80, "Size mismatch for FFBIKDebugOption");
static_assert(offsetof(FFBIKDebugOption, bDrawDebugHierarchy) == 0x0, "Offset mismatch for FFBIKDebugOption::bDrawDebugHierarchy");
static_assert(offsetof(FFBIKDebugOption, bColorAngularMotionStrength) == 0x1, "Offset mismatch for FFBIKDebugOption::bColorAngularMotionStrength");
static_assert(offsetof(FFBIKDebugOption, bColorLinearMotionStrength) == 0x2, "Offset mismatch for FFBIKDebugOption::bColorLinearMotionStrength");
static_assert(offsetof(FFBIKDebugOption, bDrawDebugAxes) == 0x3, "Offset mismatch for FFBIKDebugOption::bDrawDebugAxes");
static_assert(offsetof(FFBIKDebugOption, bDrawDebugEffector) == 0x4, "Offset mismatch for FFBIKDebugOption::bDrawDebugEffector");
static_assert(offsetof(FFBIKDebugOption, bDrawDebugConstraints) == 0x5, "Offset mismatch for FFBIKDebugOption::bDrawDebugConstraints");
static_assert(offsetof(FFBIKDebugOption, DrawWorldOffset) == 0x10, "Offset mismatch for FFBIKDebugOption::DrawWorldOffset");
static_assert(offsetof(FFBIKDebugOption, DrawSize) == 0x70, "Offset mismatch for FFBIKDebugOption::DrawSize");

// Size: 0x24 (Inherited: 0x0, Single: 0x24)
struct FSolverInput
{
    float LinearMotionStrength; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinLinearMotionStrength; // 0x4 (Size: 0x4, Type: FloatProperty)
    float AngularMotionStrength; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinAngularMotionStrength; // 0xc (Size: 0x4, Type: FloatProperty)
    float DefaultTargetClamp; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Precision; // 0x14 (Size: 0x4, Type: FloatProperty)
    float Damping; // 0x18 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations; // 0x1c (Size: 0x4, Type: IntProperty)
    bool bUseJacobianTranspose; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x3]; // 0x21 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FSolverInput) == 0x24, "Size mismatch for FSolverInput");
static_assert(offsetof(FSolverInput, LinearMotionStrength) == 0x0, "Offset mismatch for FSolverInput::LinearMotionStrength");
static_assert(offsetof(FSolverInput, MinLinearMotionStrength) == 0x4, "Offset mismatch for FSolverInput::MinLinearMotionStrength");
static_assert(offsetof(FSolverInput, AngularMotionStrength) == 0x8, "Offset mismatch for FSolverInput::AngularMotionStrength");
static_assert(offsetof(FSolverInput, MinAngularMotionStrength) == 0xc, "Offset mismatch for FSolverInput::MinAngularMotionStrength");
static_assert(offsetof(FSolverInput, DefaultTargetClamp) == 0x10, "Offset mismatch for FSolverInput::DefaultTargetClamp");
static_assert(offsetof(FSolverInput, Precision) == 0x14, "Offset mismatch for FSolverInput::Precision");
static_assert(offsetof(FSolverInput, Damping) == 0x18, "Offset mismatch for FSolverInput::Damping");
static_assert(offsetof(FSolverInput, MaxIterations) == 0x1c, "Offset mismatch for FSolverInput::MaxIterations");
static_assert(offsetof(FSolverInput, bUseJacobianTranspose) == 0x20, "Offset mismatch for FSolverInput::bUseJacobianTranspose");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FFBIKEndEffector
{
    FRigElementKey Item; // 0x0 (Size: 0x8, Type: StructProperty)
    FVector Position; // 0x8 (Size: 0x18, Type: StructProperty)
    float PositionAlpha; // 0x20 (Size: 0x4, Type: FloatProperty)
    int32_t PositionDepth; // 0x24 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FQuat Rotation; // 0x30 (Size: 0x20, Type: StructProperty)
    float RotationAlpha; // 0x50 (Size: 0x4, Type: FloatProperty)
    int32_t RotationDepth; // 0x54 (Size: 0x4, Type: IntProperty)
    float Pull; // 0x58 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFBIKEndEffector) == 0x60, "Size mismatch for FFBIKEndEffector");
static_assert(offsetof(FFBIKEndEffector, Item) == 0x0, "Offset mismatch for FFBIKEndEffector::Item");
static_assert(offsetof(FFBIKEndEffector, Position) == 0x8, "Offset mismatch for FFBIKEndEffector::Position");
static_assert(offsetof(FFBIKEndEffector, PositionAlpha) == 0x20, "Offset mismatch for FFBIKEndEffector::PositionAlpha");
static_assert(offsetof(FFBIKEndEffector, PositionDepth) == 0x24, "Offset mismatch for FFBIKEndEffector::PositionDepth");
static_assert(offsetof(FFBIKEndEffector, Rotation) == 0x30, "Offset mismatch for FFBIKEndEffector::Rotation");
static_assert(offsetof(FFBIKEndEffector, RotationAlpha) == 0x50, "Offset mismatch for FFBIKEndEffector::RotationAlpha");
static_assert(offsetof(FFBIKEndEffector, RotationDepth) == 0x54, "Offset mismatch for FFBIKEndEffector::RotationDepth");
static_assert(offsetof(FFBIKEndEffector, Pull) == 0x58, "Offset mismatch for FFBIKEndEffector::Pull");

// Size: 0x198 (Inherited: 0x0, Single: 0x198)
struct FRigUnit_FullbodyIK_WorkData
{
};

static_assert(sizeof(FRigUnit_FullbodyIK_WorkData) == 0x198, "Size mismatch for FRigUnit_FullbodyIK_WorkData");

// Size: 0x280 (Inherited: 0x30, Single: 0x250)
struct FRigUnit_FullbodyIK : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Root; // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FFBIKEndEffector> Effectors; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FFBIKConstraintOption> Constraints; // 0x28 (Size: 0x10, Type: ArrayProperty)
    FSolverInput SolverProperty; // 0x38 (Size: 0x24, Type: StructProperty)
    FMotionProcessInput MotionProperty; // 0x5c (Size: 0x2, Type: StructProperty)
    bool bPropagateToChildren; // 0x5e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5f[0x1]; // 0x5f (Size: 0x1, Type: PaddingProperty)
    FFBIKDebugOption DebugOption; // 0x60 (Size: 0x80, Type: StructProperty)
    FRigUnit_FullbodyIK_WorkData WorkData; // 0xe0 (Size: 0x198, Type: StructProperty)
    uint8_t Pad_278[0x8]; // 0x278 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_FullbodyIK) == 0x280, "Size mismatch for FRigUnit_FullbodyIK");
static_assert(offsetof(FRigUnit_FullbodyIK, Root) == 0x10, "Offset mismatch for FRigUnit_FullbodyIK::Root");
static_assert(offsetof(FRigUnit_FullbodyIK, Effectors) == 0x18, "Offset mismatch for FRigUnit_FullbodyIK::Effectors");
static_assert(offsetof(FRigUnit_FullbodyIK, Constraints) == 0x28, "Offset mismatch for FRigUnit_FullbodyIK::Constraints");
static_assert(offsetof(FRigUnit_FullbodyIK, SolverProperty) == 0x38, "Offset mismatch for FRigUnit_FullbodyIK::SolverProperty");
static_assert(offsetof(FRigUnit_FullbodyIK, MotionProperty) == 0x5c, "Offset mismatch for FRigUnit_FullbodyIK::MotionProperty");
static_assert(offsetof(FRigUnit_FullbodyIK, bPropagateToChildren) == 0x5e, "Offset mismatch for FRigUnit_FullbodyIK::bPropagateToChildren");
static_assert(offsetof(FRigUnit_FullbodyIK, DebugOption) == 0x60, "Offset mismatch for FRigUnit_FullbodyIK::DebugOption");
static_assert(offsetof(FRigUnit_FullbodyIK, WorkData) == 0xe0, "Offset mismatch for FRigUnit_FullbodyIK::WorkData");

