/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FieldNotification
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UNotifyFieldValueChanged : public UInterface
{
public:
};

static_assert(sizeof(UNotifyFieldValueChanged) == 0x28, "Size mismatch for UNotifyFieldValueChanged");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FFieldNotificationId
{
    FName FieldName; // 0x0 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FFieldNotificationId) == 0x4, "Size mismatch for FFieldNotificationId");
static_assert(offsetof(FFieldNotificationId, FieldName) == 0x0, "Offset mismatch for FFieldNotificationId::FieldName");

