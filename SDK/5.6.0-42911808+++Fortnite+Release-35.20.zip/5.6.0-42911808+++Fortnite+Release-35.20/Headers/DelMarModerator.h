/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarModerator
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "ModularGameplay.h"
#include "DelMarCore.h"
#include "DynamicUI.h"

// Size: 0xd0 (Inherited: 0x250, Single: 0xfffffe80)
class UDelMarModeratorModeComponent : public UControllerComponent
{
public:
    UDynamicUIScene* ModeratorScene; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c0[0x8]; // 0xc0 (Size: 0x8, Type: PaddingProperty)
    ADelMarVehicle* CachedVehicle; // 0xc8 (Size: 0x8, Type: ObjectProperty)

protected:
    void HandleEnterVehicle(); // 0x1216ead4 (Index: 0x0, Flags: Final|Native|Protected)
    void HandleExitVehicle(); // 0x1216eae8 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarModeratorModeComponent) == 0xd0, "Size mismatch for UDelMarModeratorModeComponent");
static_assert(offsetof(UDelMarModeratorModeComponent, ModeratorScene) == 0xb8, "Offset mismatch for UDelMarModeratorModeComponent::ModeratorScene");
static_assert(offsetof(UDelMarModeratorModeComponent, CachedVehicle) == 0xc8, "Offset mismatch for UDelMarModeratorModeComponent::CachedVehicle");

