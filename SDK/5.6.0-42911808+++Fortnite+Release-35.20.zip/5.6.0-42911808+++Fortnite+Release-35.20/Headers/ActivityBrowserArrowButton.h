/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserArrowButton
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUILegacy.h"
#include "CoreUObject.h"
#include "UMG.h"
#include "Engine.h"
#include "UIKit.h"

// Size: 0x1551 (Inherited: 0x30c0, Single: 0xffffe491)
class UActivityBrowserArrowButton_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x14f0 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_Block_Outline_C* WBP_UIKit_Block_Outline; // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Backplate_C* WBP_UIKit_Backplate; // 0x1500 (Size: 0x8, Type: ObjectProperty)
    USpacer* S_ButtonSize; // 0x1508 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* GP_ButtonWrapper; // 0x1510 (Size: 0x8, Type: ObjectProperty)
    UImage* BgFade; // 0x1518 (Size: 0x8, Type: ObjectProperty)
    UImage* Arrow; // 0x1520 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Hover; // 0x1528 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* RowActive; // 0x1530 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* RowInactive; // 0x1538 (Size: 0x8, Type: ObjectProperty)
    bool Flip; // 0x1540 (Size: 0x1, Type: BoolProperty)
    bool InputActionOnSide; // 0x1541 (Size: 0x1, Type: BoolProperty)
    bool IsActive; // 0x1542 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1543[0x5]; // 0x1543 (Size: 0x5, Type: PaddingProperty)
    double ActiveRatio; // 0x1548 (Size: 0x8, Type: DoubleProperty)
    bool ShowArrowBackgroundFade; // 0x1550 (Size: 0x1, Type: BoolProperty)

public:
    void UpdateArrowColor(FLinearColor& Color, FLinearColor& HoverColor); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetUseArrowBackgroundFade(bool& IsVisible); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetActiveRatio(double& NewParam); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x3, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void OnInitialized(); // 0x288a61c (Index: 0x6, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void HandleInputMethodChanged(ECommonInputType& bNewInputType); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetActiveAnimation(UWidgetAnimation*& ActiveAnimation); // 0x288a61c (Index: 0x8, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)

protected:
    virtual void BP_OnUnhovered(); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnHovered(); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UActivityBrowserArrowButton_C) == 0x1551, "Size mismatch for UActivityBrowserArrowButton_C");
static_assert(offsetof(UActivityBrowserArrowButton_C, UberGraphFrame) == 0x14f0, "Offset mismatch for UActivityBrowserArrowButton_C::UberGraphFrame");
static_assert(offsetof(UActivityBrowserArrowButton_C, WBP_UIKit_Block_Outline) == 0x14f8, "Offset mismatch for UActivityBrowserArrowButton_C::WBP_UIKit_Block_Outline");
static_assert(offsetof(UActivityBrowserArrowButton_C, WBP_UIKit_Backplate) == 0x1500, "Offset mismatch for UActivityBrowserArrowButton_C::WBP_UIKit_Backplate");
static_assert(offsetof(UActivityBrowserArrowButton_C, S_ButtonSize) == 0x1508, "Offset mismatch for UActivityBrowserArrowButton_C::S_ButtonSize");
static_assert(offsetof(UActivityBrowserArrowButton_C, GP_ButtonWrapper) == 0x1510, "Offset mismatch for UActivityBrowserArrowButton_C::GP_ButtonWrapper");
static_assert(offsetof(UActivityBrowserArrowButton_C, BgFade) == 0x1518, "Offset mismatch for UActivityBrowserArrowButton_C::BgFade");
static_assert(offsetof(UActivityBrowserArrowButton_C, Arrow) == 0x1520, "Offset mismatch for UActivityBrowserArrowButton_C::Arrow");
static_assert(offsetof(UActivityBrowserArrowButton_C, Hover) == 0x1528, "Offset mismatch for UActivityBrowserArrowButton_C::Hover");
static_assert(offsetof(UActivityBrowserArrowButton_C, RowActive) == 0x1530, "Offset mismatch for UActivityBrowserArrowButton_C::RowActive");
static_assert(offsetof(UActivityBrowserArrowButton_C, RowInactive) == 0x1538, "Offset mismatch for UActivityBrowserArrowButton_C::RowInactive");
static_assert(offsetof(UActivityBrowserArrowButton_C, Flip) == 0x1540, "Offset mismatch for UActivityBrowserArrowButton_C::Flip");
static_assert(offsetof(UActivityBrowserArrowButton_C, InputActionOnSide) == 0x1541, "Offset mismatch for UActivityBrowserArrowButton_C::InputActionOnSide");
static_assert(offsetof(UActivityBrowserArrowButton_C, IsActive) == 0x1542, "Offset mismatch for UActivityBrowserArrowButton_C::IsActive");
static_assert(offsetof(UActivityBrowserArrowButton_C, ActiveRatio) == 0x1548, "Offset mismatch for UActivityBrowserArrowButton_C::ActiveRatio");
static_assert(offsetof(UActivityBrowserArrowButton_C, ShowArrowBackgroundFade) == 0x1550, "Offset mismatch for UActivityBrowserArrowButton_C::ShowArrowBackgroundFade");

