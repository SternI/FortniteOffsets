/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicBacchusHUD
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"
#include "DynamicUI.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "FortniteUI.h"

// Size: 0xd8 (Inherited: 0x1b8, Single: 0xffffff20)
class UAthenaTouchHUDDirectorComponent : public UDynamicBacchusHUDDirectorComponent
{
public:

private:
    void HandleOnExitVehicle(); // 0x113d0138 (Index: 0x0, Flags: Final|Native|Private)
    void HandleOnPlayerPawnRespawned(); // 0x113d014c (Index: 0x1, Flags: Final|Native|Private)
    void HandleOnPlayerPawnRevived(); // 0x113d0160 (Index: 0x2, Flags: Final|Native|Private)
};

static_assert(sizeof(UAthenaTouchHUDDirectorComponent) == 0xd8, "Size mismatch for UAthenaTouchHUDDirectorComponent");

// Size: 0xd8 (Inherited: 0xe0, Single: 0xfffffff8)
class UDynamicBacchusHUDDirectorComponent : public UActorComponent
{
public:
    uint8_t OnPlayerPawnRevived[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPlayerPawnRespawned[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    ADynamicBacchusHUDDirector* GetOwningDirector(FString& CallerContextErrorString) const; // 0x113cfe24 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnPlayerPawnRespawned__DelegateSignature(); // 0x288a61c (Index: 0x7, Flags: MulticastDelegate|Public|Delegate)
    void OnPlayerPawnRevived__DelegateSignature(); // 0x288a61c (Index: 0x8, Flags: MulticastDelegate|Public|Delegate)

private:
    void HandleOnClientRefreshHUDForRespawn(); // 0xf4ffd08 (Index: 0x6, Flags: Final|Native|Private)

protected:
    void AddEnforcedHUDContextTags(const FGameplayTagContainer EnforcedContextTagsToAdd); // 0x113cee1c (Index: 0x0, Flags: Final|RequiredAPI|Native|Protected|HasOutParms|BlueprintCallable)
    void AddToUnallowedHUDContextTags(const FGameplayTagContainer HUDContextLayoutTags); // 0x113cf138 (Index: 0x1, Flags: Final|RequiredAPI|Native|Protected|HasOutParms|BlueprintCallable)
    void AddToUnallowedHUDWidgetTagQueries(const FGameplayTagQuery HUDWidgetTagQuery); // 0x113cf454 (Index: 0x2, Flags: Final|RequiredAPI|Native|Protected|HasOutParms|BlueprintCallable)
    void AddToUnallowedHUDWidgetTags(const FGameplayTagContainer HUDWidgetTags); // 0x113cf810 (Index: 0x3, Flags: Final|RequiredAPI|Native|Protected|HasOutParms|BlueprintCallable)
    UFortControllerComponent_InputContextTracker* GetContextTrackerComponent(FString& CallerContextErrorString) const; // 0x113cfb2c (Index: 0x4, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void RemoveEnforcedHUDContextTags(const FGameplayTagContainer EnforcedContextTagsToRemove); // 0x113d0174 (Index: 0x9, Flags: Final|RequiredAPI|Native|Protected|HasOutParms|BlueprintCallable)
    void RemoveFromUnallowedHUDContextTags(const FGameplayTagContainer HUDContextLayoutTags); // 0x113d0490 (Index: 0xa, Flags: Final|RequiredAPI|Native|Protected|HasOutParms|BlueprintCallable)
    void RemoveFromUnallowedHUDWidgetTagQueries(const FGameplayTagQuery HUDWidgetTagQuery); // 0x113d07ac (Index: 0xb, Flags: Final|RequiredAPI|Native|Protected|HasOutParms|BlueprintCallable)
    void RemoveFromUnallowedHUDWidgetTags(const FGameplayTagContainer HUDWidgetTags); // 0x113d0b68 (Index: 0xc, Flags: Final|RequiredAPI|Native|Protected|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UDynamicBacchusHUDDirectorComponent) == 0xd8, "Size mismatch for UDynamicBacchusHUDDirectorComponent");
static_assert(offsetof(UDynamicBacchusHUDDirectorComponent, OnPlayerPawnRevived) == 0xb8, "Offset mismatch for UDynamicBacchusHUDDirectorComponent::OnPlayerPawnRevived");
static_assert(offsetof(UDynamicBacchusHUDDirectorComponent, OnPlayerPawnRespawned) == 0xc8, "Offset mismatch for UDynamicBacchusHUDDirectorComponent::OnPlayerPawnRespawned");

// Size: 0x520 (Inherited: 0x598, Single: 0xffffff88)
class ADynamicBacchusHUDDirector : public ADynamicUIDirectorBase
{
public:
    FDynamicUIAllowed TouchControlRegionAllowed; // 0x2c8 (Size: 0x78, Type: StructProperty)
    UDynamicUIExcludeInputType* HUDSwitchExcludeConditions; // 0x340 (Size: 0x8, Type: ObjectProperty)
    UFortMobileHUDWidgetRegistry* BaseHUDWidgetRegistry; // 0x348 (Size: 0x8, Type: ObjectProperty)
    TMap<UDynamicUIMobileScene*, FGameplayTag> ScenesPool; // 0x350 (Size: 0x50, Type: MapProperty)
    UFortMobileHUDWidgetRegistry* HUDWidgetRegistry; // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_3a8[0xc0]; // 0x3a8 (Size: 0xc0, Type: PaddingProperty)
    TArray<FGameplayTagQuery> UnallowedHUDWidgetTagQueries; // 0x468 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_478[0x18]; // 0x478 (Size: 0x18, Type: PaddingProperty)
    FGameplayTagContainer CurrentContextTags; // 0x490 (Size: 0x20, Type: StructProperty)
    FFortMobileHUDLayoutProfile LayoutProfile; // 0x4b0 (Size: 0x38, Type: StructProperty)
    FGameplayTagContainer UnallowedHUDContextTags; // 0x4e8 (Size: 0x20, Type: StructProperty)
    FText ForcedPresetName; // 0x508 (Size: 0x10, Type: TextProperty)
    FGameplayTag ForcedProfile; // 0x518 (Size: 0x4, Type: StructProperty)
    FGameplayTag ForcedProfileContainer; // 0x51c (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(ADynamicBacchusHUDDirector) == 0x520, "Size mismatch for ADynamicBacchusHUDDirector");
static_assert(offsetof(ADynamicBacchusHUDDirector, TouchControlRegionAllowed) == 0x2c8, "Offset mismatch for ADynamicBacchusHUDDirector::TouchControlRegionAllowed");
static_assert(offsetof(ADynamicBacchusHUDDirector, HUDSwitchExcludeConditions) == 0x340, "Offset mismatch for ADynamicBacchusHUDDirector::HUDSwitchExcludeConditions");
static_assert(offsetof(ADynamicBacchusHUDDirector, BaseHUDWidgetRegistry) == 0x348, "Offset mismatch for ADynamicBacchusHUDDirector::BaseHUDWidgetRegistry");
static_assert(offsetof(ADynamicBacchusHUDDirector, ScenesPool) == 0x350, "Offset mismatch for ADynamicBacchusHUDDirector::ScenesPool");
static_assert(offsetof(ADynamicBacchusHUDDirector, HUDWidgetRegistry) == 0x3a0, "Offset mismatch for ADynamicBacchusHUDDirector::HUDWidgetRegistry");
static_assert(offsetof(ADynamicBacchusHUDDirector, UnallowedHUDWidgetTagQueries) == 0x468, "Offset mismatch for ADynamicBacchusHUDDirector::UnallowedHUDWidgetTagQueries");
static_assert(offsetof(ADynamicBacchusHUDDirector, CurrentContextTags) == 0x490, "Offset mismatch for ADynamicBacchusHUDDirector::CurrentContextTags");
static_assert(offsetof(ADynamicBacchusHUDDirector, LayoutProfile) == 0x4b0, "Offset mismatch for ADynamicBacchusHUDDirector::LayoutProfile");
static_assert(offsetof(ADynamicBacchusHUDDirector, UnallowedHUDContextTags) == 0x4e8, "Offset mismatch for ADynamicBacchusHUDDirector::UnallowedHUDContextTags");
static_assert(offsetof(ADynamicBacchusHUDDirector, ForcedPresetName) == 0x508, "Offset mismatch for ADynamicBacchusHUDDirector::ForcedPresetName");
static_assert(offsetof(ADynamicBacchusHUDDirector, ForcedProfile) == 0x518, "Offset mismatch for ADynamicBacchusHUDDirector::ForcedProfile");
static_assert(offsetof(ADynamicBacchusHUDDirector, ForcedProfileContainer) == 0x51c, "Offset mismatch for ADynamicBacchusHUDDirector::ForcedProfileContainer");

// Size: 0x130 (Inherited: 0xd0, Single: 0x60)
class UDynamicUIMobileScene : public UDynamicUIScene
{
public:
};

static_assert(sizeof(UDynamicUIMobileScene) == 0x130, "Size mismatch for UDynamicUIMobileScene");

