/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarGracefulUpgrade
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDelMarGracefulUpgradeOverride : public UGracefulUpgradeOverrider
{
public:
};

static_assert(sizeof(UDelMarGracefulUpgradeOverride) == 0x28, "Size mismatch for UDelMarGracefulUpgradeOverride");

