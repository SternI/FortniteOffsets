/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommonUIMVVMExtensions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUI.h"
#include "ModelViewViewModel.h"
#include "CoreUObject.h"
#include "EnhancedInput.h"
#include "Engine.h"

// Size: 0x420 (Inherited: 0x5c8, Single: 0xfffffe58)
class UActionWidget : public UCommonActionWidget
{
public:
};

static_assert(sizeof(UActionWidget) == 0x420, "Size mismatch for UActionWidget");

// Size: 0x78 (Inherited: 0x50, Single: 0x28)
class UMVVMViewEnhancedInputExtension : public UMVVMViewExtension
{
public:
    uint8_t OnEnhancedInputTriggered[0x10]; // 0x28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_38[0x20]; // 0x38 (Size: 0x20, Type: PaddingProperty)
    FUIActionBindingHandle UIActionBindingHandle; // 0x58 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    FTimerHandle PendingWidgetParentAssignmentTimer; // 0x60 (Size: 0x8, Type: StructProperty)
    TWeakObjectPtr<UCommonActionWidget*> ActionWidget; // 0x68 (Size: 0x8, Type: WeakObjectProperty)
    UMVVMViewEnhancedInputClassExtension* ClassExtension; // 0x70 (Size: 0x8, Type: ObjectProperty)

public:
    void AddInputMapping(UInputMappingContext*& const Context, int32_t& Priority); // 0x1296e984 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveInputMapping(UInputMappingContext*& const Context); // 0x1296ec8c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UMVVMViewEnhancedInputExtension) == 0x78, "Size mismatch for UMVVMViewEnhancedInputExtension");
static_assert(offsetof(UMVVMViewEnhancedInputExtension, OnEnhancedInputTriggered) == 0x28, "Offset mismatch for UMVVMViewEnhancedInputExtension::OnEnhancedInputTriggered");
static_assert(offsetof(UMVVMViewEnhancedInputExtension, UIActionBindingHandle) == 0x58, "Offset mismatch for UMVVMViewEnhancedInputExtension::UIActionBindingHandle");
static_assert(offsetof(UMVVMViewEnhancedInputExtension, PendingWidgetParentAssignmentTimer) == 0x60, "Offset mismatch for UMVVMViewEnhancedInputExtension::PendingWidgetParentAssignmentTimer");
static_assert(offsetof(UMVVMViewEnhancedInputExtension, ActionWidget) == 0x68, "Offset mismatch for UMVVMViewEnhancedInputExtension::ActionWidget");
static_assert(offsetof(UMVVMViewEnhancedInputExtension, ClassExtension) == 0x70, "Offset mismatch for UMVVMViewEnhancedInputExtension::ClassExtension");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UMVVMViewEnhancedInputClassExtension : public UMVVMViewClassExtension
{
public:
    FName WidgetName; // 0x28 (Size: 0x4, Type: NameProperty)
    FName EnhancedInputPropertyName; // 0x2c (Size: 0x4, Type: NameProperty)
    int32_t Priority; // 0x30 (Size: 0x4, Type: IntProperty)
    FMVVMVCompiledFieldPath WidgetPath; // 0x34 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(UMVVMViewEnhancedInputClassExtension) == 0x38, "Size mismatch for UMVVMViewEnhancedInputClassExtension");
static_assert(offsetof(UMVVMViewEnhancedInputClassExtension, WidgetName) == 0x28, "Offset mismatch for UMVVMViewEnhancedInputClassExtension::WidgetName");
static_assert(offsetof(UMVVMViewEnhancedInputClassExtension, EnhancedInputPropertyName) == 0x2c, "Offset mismatch for UMVVMViewEnhancedInputClassExtension::EnhancedInputPropertyName");
static_assert(offsetof(UMVVMViewEnhancedInputClassExtension, Priority) == 0x30, "Offset mismatch for UMVVMViewEnhancedInputClassExtension::Priority");
static_assert(offsetof(UMVVMViewEnhancedInputClassExtension, WidgetPath) == 0x34, "Offset mismatch for UMVVMViewEnhancedInputClassExtension::WidgetPath");

