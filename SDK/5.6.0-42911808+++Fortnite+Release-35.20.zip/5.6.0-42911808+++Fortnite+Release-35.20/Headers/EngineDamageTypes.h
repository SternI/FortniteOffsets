/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EngineDamageTypes
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x40 (Inherited: 0x68, Single: 0xffffffd8)
class UDmgTypeBP_Environmental_C : public UDamageType
{
public:
};

static_assert(sizeof(UDmgTypeBP_Environmental_C) == 0x40, "Size mismatch for UDmgTypeBP_Environmental_C");

