/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CraftingUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "FortniteUI.h"
#include "CommonUI.h"
#include "UMG.h"
#include "CommonUILegacy.h"
#include "GameFeatures.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CraftingRuntime.h"

// Size: 0x158 (Inherited: 0x28, Single: 0x130)
class UFortCraftingListItem : public UObject
{
public:
};

static_assert(sizeof(UFortCraftingListItem) == 0x158, "Size mismatch for UFortCraftingListItem");

// Size: 0x14d0 (Inherited: 0x3080, Single: 0xffffe450)
class UAthenaCraftingQuickBarButton : public UAthenaQuickBarSlotButtonBase
{
public:

protected:
    virtual void OnCanCraftNowChanged(bool& const bCanCraftNow); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnIsCraftableItemChanged(bool& const bIsCraftableItem); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UAthenaCraftingQuickBarButton) == 0x14d0, "Size mismatch for UAthenaCraftingQuickBarButton");

// Size: 0x2f8 (Inherited: 0x730, Single: 0xfffffbc8)
class UAthenaEquippedItemCraftingIndicator : public UCommonUserWidget
{
public:

private:
    void HandleInventoryActiveChanged(bool& bInventoryActive); // 0x101e1fd4 (Index: 0x0, Flags: Final|Native|Private)
    void HandleWeaponEquipped(AFortWeapon*& NewWeapon, AFortWeapon*& PrevWeapon); // 0x101e2474 (Index: 0x1, Flags: Final|Native|Private)

protected:
    virtual void OnCanCraftNowChanged(bool& const bCanCraftNow); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnIsCraftableItemChanged(bool& const bIsCraftableItem); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UAthenaEquippedItemCraftingIndicator) == 0x2f8, "Size mismatch for UAthenaEquippedItemCraftingIndicator");

// Size: 0x2f8 (Inherited: 0x730, Single: 0xfffffbc8)
class UAthenaInventoryItemInfoCraftingIndicator : public UCommonUserWidget
{
public:

private:
    void HandleInventoryItemSelected(UFortItem*& SelectedItem); // 0x101e221c (Index: 0x0, Flags: Final|Native|Private)

protected:
    virtual void OnCanCraftNowChanged(bool& const bCanCraftNow); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnIsCraftableItemChanged(bool& const bIsCraftableItem); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UAthenaInventoryItemInfoCraftingIndicator) == 0x2f8, "Size mismatch for UAthenaInventoryItemInfoCraftingIndicator");

// Size: 0x310 (Inherited: 0xa10, Single: 0xfffff900)
class UAthenaQuickBarSlotCraftingIndicator : public UAthenaQuickBarSlotExtensionWidgetBase
{
public:
    uint8_t Pad_2e0[0x20]; // 0x2e0 (Size: 0x20, Type: PaddingProperty)
    bool bCheckForIngredientChangesWhenCraftable; // 0x300 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_301[0xf]; // 0x301 (Size: 0xf, Type: PaddingProperty)

private:
    void HandleInventoryActiveChanged(bool& bInventoryActive); // 0x101e20f8 (Index: 0x0, Flags: Final|Native|Private)
    void HandleWeaponEquipped(AFortWeapon*& NewWeapon, AFortWeapon*& PrevWeapon); // 0x101e267c (Index: 0x1, Flags: Final|Native|Private)

protected:
    virtual void OnCanCraftNowChanged(bool& const bCanCraftNow); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnIngredientChanged(bool& const bCanCraftNow); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnIsCraftableItemChanged(bool& const bIsCraftableItem); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UAthenaQuickBarSlotCraftingIndicator) == 0x310, "Size mismatch for UAthenaQuickBarSlotCraftingIndicator");
static_assert(offsetof(UAthenaQuickBarSlotCraftingIndicator, bCheckForIngredientChangesWhenCraftable) == 0x300, "Offset mismatch for UAthenaQuickBarSlotCraftingIndicator::bCheckForIngredientChangesWhenCraftable");

// Size: 0x458 (Inherited: 0xb38, Single: 0xfffff920)
class UFortCookingScreen : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x8]; // 0x408 (Size: 0x8, Type: PaddingProperty)
    FDataTableRowHandle CloseInputAction; // 0x410 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_420[0x8]; // 0x420 (Size: 0x8, Type: PaddingProperty)
    UCommonButtonLegacy* Button_EjectAll; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonLegacy* Button_Cancel; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_RecipeName; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_RecipeDescription; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Recipe; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UFortSlottedRadialMenu* RadialMenu_Recipes; // 0x450 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortCookingScreen) == 0x458, "Size mismatch for UFortCookingScreen");
static_assert(offsetof(UFortCookingScreen, CloseInputAction) == 0x410, "Offset mismatch for UFortCookingScreen::CloseInputAction");
static_assert(offsetof(UFortCookingScreen, Button_EjectAll) == 0x428, "Offset mismatch for UFortCookingScreen::Button_EjectAll");
static_assert(offsetof(UFortCookingScreen, Button_Cancel) == 0x430, "Offset mismatch for UFortCookingScreen::Button_Cancel");
static_assert(offsetof(UFortCookingScreen, Text_RecipeName) == 0x438, "Offset mismatch for UFortCookingScreen::Text_RecipeName");
static_assert(offsetof(UFortCookingScreen, Text_RecipeDescription) == 0x440, "Offset mismatch for UFortCookingScreen::Text_RecipeDescription");
static_assert(offsetof(UFortCookingScreen, Image_Recipe) == 0x448, "Offset mismatch for UFortCookingScreen::Image_Recipe");
static_assert(offsetof(UFortCookingScreen, RadialMenu_Recipes) == 0x450, "Offset mismatch for UFortCookingScreen::RadialMenu_Recipes");

// Size: 0x2e0 (Inherited: 0x730, Single: 0xfffffbb0)
class UFortCraftingFormulaIngredientsWidget : public UCommonUserWidget
{
public:
    UDynamicEntryBox* EntryBox_Ingredients; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortCraftingFormulaIngredientsWidget) == 0x2e0, "Size mismatch for UFortCraftingFormulaIngredientsWidget");
static_assert(offsetof(UFortCraftingFormulaIngredientsWidget, EntryBox_Ingredients) == 0x2d8, "Offset mismatch for UFortCraftingFormulaIngredientsWidget::EntryBox_Ingredients");

// Size: 0x300 (Inherited: 0x730, Single: 0xfffffbd0)
class UFortCraftingIngredientWidget : public UCommonUserWidget
{
public:
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)
    UCommonTextBlock* Text_NumAvailable; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_NumRequired; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UAthenaItemIcon* ItemIcon; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UCommonLazyImage* LazyImage_Icon; // 0x2f8 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void OnIngredientWidgetUpdated(int32_t& const NumAvailable, int32_t& const NumRequired, bool& const bIsPrimaryIngredient, bool& const bIsLastIngredient); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortCraftingIngredientWidget) == 0x300, "Size mismatch for UFortCraftingIngredientWidget");
static_assert(offsetof(UFortCraftingIngredientWidget, Text_NumAvailable) == 0x2e0, "Offset mismatch for UFortCraftingIngredientWidget::Text_NumAvailable");
static_assert(offsetof(UFortCraftingIngredientWidget, Text_NumRequired) == 0x2e8, "Offset mismatch for UFortCraftingIngredientWidget::Text_NumRequired");
static_assert(offsetof(UFortCraftingIngredientWidget, ItemIcon) == 0x2f0, "Offset mismatch for UFortCraftingIngredientWidget::ItemIcon");
static_assert(offsetof(UFortCraftingIngredientWidget, LazyImage_Icon) == 0x2f8, "Offset mismatch for UFortCraftingIngredientWidget::LazyImage_Icon");

// Size: 0x468 (Inherited: 0xb38, Single: 0xfffff930)
class UFortCraftingItemInfoWidget : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x8]; // 0x408 (Size: 0x8, Type: PaddingProperty)
    FText RarityTextFormat; // 0x410 (Size: 0x10, Type: TextProperty)
    UCommonTextBlock* Text_ItemName; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ItemRarity; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ItemCategory; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UFortItemCategoryIndicator* ItemCategoryIndicator; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ItemDescription; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UAthenaInventoryItemStatsWidget* ItemStatsWidget; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UFortCraftingFormulaIngredientsWidget* IngredientsWidget; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonLegacy* Button_StartCrafting; // 0x458 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_460[0x8]; // 0x460 (Size: 0x8, Type: PaddingProperty)

protected:
    virtual void OnItemRaritySet(EFortRarity& const Rarity, FFortRarityItemData& const RarityItemData); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortCraftingItemInfoWidget) == 0x468, "Size mismatch for UFortCraftingItemInfoWidget");
static_assert(offsetof(UFortCraftingItemInfoWidget, RarityTextFormat) == 0x410, "Offset mismatch for UFortCraftingItemInfoWidget::RarityTextFormat");
static_assert(offsetof(UFortCraftingItemInfoWidget, Text_ItemName) == 0x420, "Offset mismatch for UFortCraftingItemInfoWidget::Text_ItemName");
static_assert(offsetof(UFortCraftingItemInfoWidget, Text_ItemRarity) == 0x428, "Offset mismatch for UFortCraftingItemInfoWidget::Text_ItemRarity");
static_assert(offsetof(UFortCraftingItemInfoWidget, Text_ItemCategory) == 0x430, "Offset mismatch for UFortCraftingItemInfoWidget::Text_ItemCategory");
static_assert(offsetof(UFortCraftingItemInfoWidget, ItemCategoryIndicator) == 0x438, "Offset mismatch for UFortCraftingItemInfoWidget::ItemCategoryIndicator");
static_assert(offsetof(UFortCraftingItemInfoWidget, Text_ItemDescription) == 0x440, "Offset mismatch for UFortCraftingItemInfoWidget::Text_ItemDescription");
static_assert(offsetof(UFortCraftingItemInfoWidget, ItemStatsWidget) == 0x448, "Offset mismatch for UFortCraftingItemInfoWidget::ItemStatsWidget");
static_assert(offsetof(UFortCraftingItemInfoWidget, IngredientsWidget) == 0x450, "Offset mismatch for UFortCraftingItemInfoWidget::IngredientsWidget");
static_assert(offsetof(UFortCraftingItemInfoWidget, Button_StartCrafting) == 0x458, "Offset mismatch for UFortCraftingItemInfoWidget::Button_StartCrafting");

// Size: 0x1510 (Inherited: 0x30c0, Single: 0xffffe450)
class UFortCraftingListEntry : public UCommonButtonLegacy
{
public:
    uint8_t Pad_14f0[0x8]; // 0x14f0 (Size: 0x8, Type: PaddingProperty)
    UAthenaItemIcon* ItemIcon; // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    bool bCanCraftItem; // 0x1500 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1501[0xf]; // 0x1501 (Size: 0xf, Type: PaddingProperty)

protected:
    virtual void OnCraftingListItemSet(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortCraftingListEntry) == 0x1510, "Size mismatch for UFortCraftingListEntry");
static_assert(offsetof(UFortCraftingListEntry, ItemIcon) == 0x14f8, "Offset mismatch for UFortCraftingListEntry::ItemIcon");
static_assert(offsetof(UFortCraftingListEntry, bCanCraftItem) == 0x1500, "Offset mismatch for UFortCraftingListEntry::bCanCraftItem");

// Size: 0x550 (Inherited: 0xb38, Single: 0xfffffa18)
class UFortCraftingTab : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x8]; // 0x408 (Size: 0x8, Type: PaddingProperty)
    FName TabNameID; // 0x410 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_414[0xc]; // 0x414 (Size: 0xc, Type: PaddingProperty)
    FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x420 (Size: 0xf0, Type: StructProperty)
    FGameplayTagContainer PrimaryIngredientTags; // 0x510 (Size: 0x20, Type: StructProperty)
    UFortCraftingItemInfoWidget* CraftingItemInfo; // 0x530 (Size: 0x8, Type: ObjectProperty)
    UCommonListView* ListView_Recipes; // 0x538 (Size: 0x8, Type: ObjectProperty)
    UAthenaQuickbarEditorBase* QuickbarEditor; // 0x540 (Size: 0x8, Type: ObjectProperty)
    UAthenaInventoryItemInfo* ItemInfoWidget; // 0x548 (Size: 0x8, Type: ObjectProperty)

private:
    void HandleInventoryItemSelected(UFortItem*& Item); // 0x101e2348 (Index: 0x0, Flags: Final|Native|Private)

protected:
    virtual void OnFormulaListUpdated(int32_t& const NumFormulas); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortCraftingTab) == 0x550, "Size mismatch for UFortCraftingTab");
static_assert(offsetof(UFortCraftingTab, TabNameID) == 0x410, "Offset mismatch for UFortCraftingTab::TabNameID");
static_assert(offsetof(UFortCraftingTab, TabButtonLabelInfo) == 0x420, "Offset mismatch for UFortCraftingTab::TabButtonLabelInfo");
static_assert(offsetof(UFortCraftingTab, PrimaryIngredientTags) == 0x510, "Offset mismatch for UFortCraftingTab::PrimaryIngredientTags");
static_assert(offsetof(UFortCraftingTab, CraftingItemInfo) == 0x530, "Offset mismatch for UFortCraftingTab::CraftingItemInfo");
static_assert(offsetof(UFortCraftingTab, ListView_Recipes) == 0x538, "Offset mismatch for UFortCraftingTab::ListView_Recipes");
static_assert(offsetof(UFortCraftingTab, QuickbarEditor) == 0x540, "Offset mismatch for UFortCraftingTab::QuickbarEditor");
static_assert(offsetof(UFortCraftingTab, ItemInfoWidget) == 0x548, "Offset mismatch for UFortCraftingTab::ItemInfoWidget");

// Size: 0x2d8 (Inherited: 0x458, Single: 0xfffffe80)
class UFortPotContentsPopup : public UUserWidget
{
public:
    int32_t MaxItemsToShow; // 0x2b0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2b4[0xc]; // 0x2b4 (Size: 0xc, Type: PaddingProperty)
    UCommonTileView* TileView_PotContents; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_MoreItems; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UWidget* Overlay_Popup; // 0x2d0 (Size: 0x8, Type: ObjectProperty)

public:
    void SetOwningCraftingObject(ACraftingObjectBGA*& InCraftingObject); // 0x101e2884 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortPotContentsPopup) == 0x2d8, "Size mismatch for UFortPotContentsPopup");
static_assert(offsetof(UFortPotContentsPopup, MaxItemsToShow) == 0x2b0, "Offset mismatch for UFortPotContentsPopup::MaxItemsToShow");
static_assert(offsetof(UFortPotContentsPopup, TileView_PotContents) == 0x2c0, "Offset mismatch for UFortPotContentsPopup::TileView_PotContents");
static_assert(offsetof(UFortPotContentsPopup, Text_MoreItems) == 0x2c8, "Offset mismatch for UFortPotContentsPopup::Text_MoreItems");
static_assert(offsetof(UFortPotContentsPopup, Overlay_Popup) == 0x2d0, "Offset mismatch for UFortPotContentsPopup::Overlay_Popup");

// Size: 0x1500 (Inherited: 0x30c0, Single: 0xffffe440)
class UFortPotContentsTile : public UCommonButtonLegacy
{
public:
    uint8_t Pad_14f0[0x8]; // 0x14f0 (Size: 0x8, Type: PaddingProperty)
    UCommonLazyImage* Image_Item; // 0x14f8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortPotContentsTile) == 0x1500, "Size mismatch for UFortPotContentsTile");
static_assert(offsetof(UFortPotContentsTile, Image_Item) == 0x14f8, "Offset mismatch for UFortPotContentsTile::Image_Item");

// Size: 0x58 (Inherited: 0x78, Single: 0xffffffe0)
class UFortUIGameFeatureAction_SetCraftMenuWidget : public UFortUIGameFeatureAction
{
public:
    UClass* CraftingObject; // 0x28 (Size: 0x8, Type: ClassProperty)
    TSoftClassPtr CraftingMenuWidget; // 0x30 (Size: 0x20, Type: SoftClassProperty)
    uint8_t Pad_50[0x8]; // 0x50 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortUIGameFeatureAction_SetCraftMenuWidget) == 0x58, "Size mismatch for UFortUIGameFeatureAction_SetCraftMenuWidget");
static_assert(offsetof(UFortUIGameFeatureAction_SetCraftMenuWidget, CraftingObject) == 0x28, "Offset mismatch for UFortUIGameFeatureAction_SetCraftMenuWidget::CraftingObject");
static_assert(offsetof(UFortUIGameFeatureAction_SetCraftMenuWidget, CraftingMenuWidget) == 0x30, "Offset mismatch for UFortUIGameFeatureAction_SetCraftMenuWidget::CraftingMenuWidget");

