/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CharacterDynamicsControlCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "PhysicsControl.h"
#include "AnimGraphRuntime.h"

// Size: 0xa0 (Inherited: 0x88, Single: 0x18)
class UFortCharacterDynamicsParameters : public UPrimaryDataAsset
{
public:
    TArray<FName> StateNames; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothParameters> ClothParameters; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FWindGustParameters> WindGustParameters; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FPhysicsControlControlAndModifierParameters> RBWCControlAndModifierParameters; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortRigidBodyWithControlStateTransitionParameters> RBWCTransitionParameters; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortGravityOverrideParameters> GravityOverrideParameters; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortRigidBodyAnimNodeParameters> RigidBodyAnimNodeParameters; // 0x90 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortCharacterDynamicsParameters) == 0xa0, "Size mismatch for UFortCharacterDynamicsParameters");
static_assert(offsetof(UFortCharacterDynamicsParameters, StateNames) == 0x30, "Offset mismatch for UFortCharacterDynamicsParameters::StateNames");
static_assert(offsetof(UFortCharacterDynamicsParameters, ClothParameters) == 0x40, "Offset mismatch for UFortCharacterDynamicsParameters::ClothParameters");
static_assert(offsetof(UFortCharacterDynamicsParameters, WindGustParameters) == 0x50, "Offset mismatch for UFortCharacterDynamicsParameters::WindGustParameters");
static_assert(offsetof(UFortCharacterDynamicsParameters, RBWCControlAndModifierParameters) == 0x60, "Offset mismatch for UFortCharacterDynamicsParameters::RBWCControlAndModifierParameters");
static_assert(offsetof(UFortCharacterDynamicsParameters, RBWCTransitionParameters) == 0x70, "Offset mismatch for UFortCharacterDynamicsParameters::RBWCTransitionParameters");
static_assert(offsetof(UFortCharacterDynamicsParameters, GravityOverrideParameters) == 0x80, "Offset mismatch for UFortCharacterDynamicsParameters::GravityOverrideParameters");
static_assert(offsetof(UFortCharacterDynamicsParameters, RigidBodyAnimNodeParameters) == 0x90, "Offset mismatch for UFortCharacterDynamicsParameters::RigidBodyAnimNodeParameters");

// Size: 0x98 (Inherited: 0x88, Single: 0x10)
class UFortCharacterDynamicsStateLogic : public UPrimaryDataAsset
{
public:
    TArray<FName> BlueprintCharacterPropertyNames; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> ActivityStateNames; // 0x40 (Size: 0x10, Type: ArrayProperty)
    FBinaryDecisionTree ActivityStateBinaryDecisionTree; // 0x50 (Size: 0x10, Type: StructProperty)
    FBitArrayBinaryDecisionTree DecisionTree; // 0x60 (Size: 0x10, Type: StructProperty)
    TArray<FProxyProperty> ProxyPropertyCollection; // 0x70 (Size: 0x10, Type: ArrayProperty)
    int32_t NativePropertyCount; // 0x80 (Size: 0x4, Type: IntProperty)
    float MinMovementSpeed; // 0x84 (Size: 0x4, Type: FloatProperty)
    float MinRidingMovementSpeed; // 0x88 (Size: 0x4, Type: FloatProperty)
    float MinUpwardVelocityThreshold; // 0x8c (Size: 0x4, Type: FloatProperty)
    float MaxFallingThreshold; // 0x90 (Size: 0x4, Type: FloatProperty)
    float HighRevolutionsPerSecondThreshold; // 0x94 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UFortCharacterDynamicsStateLogic) == 0x98, "Size mismatch for UFortCharacterDynamicsStateLogic");
static_assert(offsetof(UFortCharacterDynamicsStateLogic, BlueprintCharacterPropertyNames) == 0x30, "Offset mismatch for UFortCharacterDynamicsStateLogic::BlueprintCharacterPropertyNames");
static_assert(offsetof(UFortCharacterDynamicsStateLogic, ActivityStateNames) == 0x40, "Offset mismatch for UFortCharacterDynamicsStateLogic::ActivityStateNames");
static_assert(offsetof(UFortCharacterDynamicsStateLogic, ActivityStateBinaryDecisionTree) == 0x50, "Offset mismatch for UFortCharacterDynamicsStateLogic::ActivityStateBinaryDecisionTree");
static_assert(offsetof(UFortCharacterDynamicsStateLogic, DecisionTree) == 0x60, "Offset mismatch for UFortCharacterDynamicsStateLogic::DecisionTree");
static_assert(offsetof(UFortCharacterDynamicsStateLogic, ProxyPropertyCollection) == 0x70, "Offset mismatch for UFortCharacterDynamicsStateLogic::ProxyPropertyCollection");
static_assert(offsetof(UFortCharacterDynamicsStateLogic, NativePropertyCount) == 0x80, "Offset mismatch for UFortCharacterDynamicsStateLogic::NativePropertyCount");
static_assert(offsetof(UFortCharacterDynamicsStateLogic, MinMovementSpeed) == 0x84, "Offset mismatch for UFortCharacterDynamicsStateLogic::MinMovementSpeed");
static_assert(offsetof(UFortCharacterDynamicsStateLogic, MinRidingMovementSpeed) == 0x88, "Offset mismatch for UFortCharacterDynamicsStateLogic::MinRidingMovementSpeed");
static_assert(offsetof(UFortCharacterDynamicsStateLogic, MinUpwardVelocityThreshold) == 0x8c, "Offset mismatch for UFortCharacterDynamicsStateLogic::MinUpwardVelocityThreshold");
static_assert(offsetof(UFortCharacterDynamicsStateLogic, MaxFallingThreshold) == 0x90, "Offset mismatch for UFortCharacterDynamicsStateLogic::MaxFallingThreshold");
static_assert(offsetof(UFortCharacterDynamicsStateLogic, HighRevolutionsPerSecondThreshold) == 0x94, "Offset mismatch for UFortCharacterDynamicsStateLogic::HighRevolutionsPerSecondThreshold");

// Size: 0xb8 (Inherited: 0xe0, Single: 0xffffffd8)
class UFortCharacterDynamicsComponentInterface : public UActorComponent
{
public:

public:
    FName CurrentStateName(); // 0xc669b34 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    FName CurrentStateNameForLayer(FName& const LayerName); // 0xc669b60 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    bool GetProperty(FName& const PropertyName); // 0xc669c90 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    bool GetPropertyForLayer(FName& const LayerName, FName& const PropertyName); // 0xc669dd0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    float GetTimeInCurrentStateSeconds() const; // 0xc669fec (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTimeInCurrentStateSecondsForLayer(FName& const LayerName) const; // 0xc66a018 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasLayer(FName& const LayerName) const; // 0xc66a158 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName PreviousStateName(); // 0xc66a298 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    FName PreviousStateNameForLayer(FName& const LayerName); // 0xc66a2c8 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveLayer(FName& const LayerName); // 0xc66a3f8 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void SetProperty(FName& const PropertyName, bool& const PropertyValue); // 0xc66a524 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortCharacterDynamicsComponentInterface) == 0xb8, "Size mismatch for UFortCharacterDynamicsComponentInterface");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FBitArrayBinaryDecisionTreeElement
{
    int32_t Value; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FBitArrayWrapper BitArrayMask; // 0x8 (Size: 0x20, Type: StructProperty)
    FBitArrayWrapper BitArraySet; // 0x28 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FBitArrayBinaryDecisionTreeElement) == 0x48, "Size mismatch for FBitArrayBinaryDecisionTreeElement");
static_assert(offsetof(FBitArrayBinaryDecisionTreeElement, Value) == 0x0, "Offset mismatch for FBitArrayBinaryDecisionTreeElement::Value");
static_assert(offsetof(FBitArrayBinaryDecisionTreeElement, BitArrayMask) == 0x8, "Offset mismatch for FBitArrayBinaryDecisionTreeElement::BitArrayMask");
static_assert(offsetof(FBitArrayBinaryDecisionTreeElement, BitArraySet) == 0x28, "Offset mismatch for FBitArrayBinaryDecisionTreeElement::BitArraySet");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FBitArrayWrapper
{
};

static_assert(sizeof(FBitArrayWrapper) == 0x20, "Size mismatch for FBitArrayWrapper");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBitArrayBinaryDecisionTree
{
    TArray<FBitArrayBinaryDecisionTreeElement> TreeStructure; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FBitArrayBinaryDecisionTree) == 0x10, "Size mismatch for FBitArrayBinaryDecisionTree");
static_assert(offsetof(FBitArrayBinaryDecisionTree, TreeStructure) == 0x0, "Offset mismatch for FBitArrayBinaryDecisionTree::TreeStructure");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FBinaryDecisionTreeElement
{
    int32_t Value; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    int64_t BitMask; // 0x8 (Size: 0x8, Type: Int64Property)
    int64_t BitSet; // 0x10 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FBinaryDecisionTreeElement) == 0x18, "Size mismatch for FBinaryDecisionTreeElement");
static_assert(offsetof(FBinaryDecisionTreeElement, Value) == 0x0, "Offset mismatch for FBinaryDecisionTreeElement::Value");
static_assert(offsetof(FBinaryDecisionTreeElement, BitMask) == 0x8, "Offset mismatch for FBinaryDecisionTreeElement::BitMask");
static_assert(offsetof(FBinaryDecisionTreeElement, BitSet) == 0x10, "Offset mismatch for FBinaryDecisionTreeElement::BitSet");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBinaryDecisionTree
{
    TArray<FBinaryDecisionTreeElement> TreeStructure; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FBinaryDecisionTree) == 0x10, "Size mismatch for FBinaryDecisionTree");
static_assert(offsetof(FBinaryDecisionTree, TreeStructure) == 0x0, "Offset mismatch for FBinaryDecisionTree::TreeStructure");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FPropertyStatePair
{
    FName StateName; // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t BitSet; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t BitMask; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FPropertyStatePair) == 0xc, "Size mismatch for FPropertyStatePair");
static_assert(offsetof(FPropertyStatePair, StateName) == 0x0, "Offset mismatch for FPropertyStatePair::StateName");
static_assert(offsetof(FPropertyStatePair, BitSet) == 0x4, "Offset mismatch for FPropertyStatePair::BitSet");
static_assert(offsetof(FPropertyStatePair, BitMask) == 0x8, "Offset mismatch for FPropertyStatePair::BitMask");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FClothStateLogicTree
{
    TMap<int32_t, FName> PropertyNameToBitFlagMap; // 0x0 (Size: 0x50, Type: MapProperty)
    TArray<FPropertyStatePair> PropertyFlagsToStateNameTable; // 0x50 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FClothStateLogicTree) == 0x60, "Size mismatch for FClothStateLogicTree");
static_assert(offsetof(FClothStateLogicTree, PropertyNameToBitFlagMap) == 0x0, "Offset mismatch for FClothStateLogicTree::PropertyNameToBitFlagMap");
static_assert(offsetof(FClothStateLogicTree, PropertyFlagsToStateNameTable) == 0x50, "Offset mismatch for FClothStateLogicTree::PropertyFlagsToStateNameTable");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FClothCoreSettings
{
    FVector2D EdgeStiffness; // 0x0 (Size: 0x10, Type: StructProperty)
    FVector2D BendingStiffness; // 0x10 (Size: 0x10, Type: StructProperty)
    FVector2D AreaStiffness; // 0x20 (Size: 0x10, Type: StructProperty)
    FVector2D TetherStiffness; // 0x30 (Size: 0x10, Type: StructProperty)
    float CollisionThickness; // 0x40 (Size: 0x4, Type: FloatProperty)
    float FrictionCoefficient; // 0x44 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionThickness; // 0x48 (Size: 0x4, Type: FloatProperty)
    float DampingCoefficient; // 0x4c (Size: 0x4, Type: FloatProperty)
    float LocalDampingCoefficient; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
    FVector2D AnimDriveStiffness; // 0x58 (Size: 0x10, Type: StructProperty)
    FVector2D AnimDriveDamping; // 0x68 (Size: 0x10, Type: StructProperty)
    int32_t NumberIterations; // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t NumberSubsteps; // 0x7c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FClothCoreSettings) == 0x80, "Size mismatch for FClothCoreSettings");
static_assert(offsetof(FClothCoreSettings, EdgeStiffness) == 0x0, "Offset mismatch for FClothCoreSettings::EdgeStiffness");
static_assert(offsetof(FClothCoreSettings, BendingStiffness) == 0x10, "Offset mismatch for FClothCoreSettings::BendingStiffness");
static_assert(offsetof(FClothCoreSettings, AreaStiffness) == 0x20, "Offset mismatch for FClothCoreSettings::AreaStiffness");
static_assert(offsetof(FClothCoreSettings, TetherStiffness) == 0x30, "Offset mismatch for FClothCoreSettings::TetherStiffness");
static_assert(offsetof(FClothCoreSettings, CollisionThickness) == 0x40, "Offset mismatch for FClothCoreSettings::CollisionThickness");
static_assert(offsetof(FClothCoreSettings, FrictionCoefficient) == 0x44, "Offset mismatch for FClothCoreSettings::FrictionCoefficient");
static_assert(offsetof(FClothCoreSettings, SelfCollisionThickness) == 0x48, "Offset mismatch for FClothCoreSettings::SelfCollisionThickness");
static_assert(offsetof(FClothCoreSettings, DampingCoefficient) == 0x4c, "Offset mismatch for FClothCoreSettings::DampingCoefficient");
static_assert(offsetof(FClothCoreSettings, LocalDampingCoefficient) == 0x50, "Offset mismatch for FClothCoreSettings::LocalDampingCoefficient");
static_assert(offsetof(FClothCoreSettings, AnimDriveStiffness) == 0x58, "Offset mismatch for FClothCoreSettings::AnimDriveStiffness");
static_assert(offsetof(FClothCoreSettings, AnimDriveDamping) == 0x68, "Offset mismatch for FClothCoreSettings::AnimDriveDamping");
static_assert(offsetof(FClothCoreSettings, NumberIterations) == 0x78, "Offset mismatch for FClothCoreSettings::NumberIterations");
static_assert(offsetof(FClothCoreSettings, NumberSubsteps) == 0x7c, "Offset mismatch for FClothCoreSettings::NumberSubsteps");

// Size: 0xb8 (Inherited: 0x0, Single: 0xb8)
struct FClothParameters
{
    FVector LinearVelocityScale; // 0x0 (Size: 0x18, Type: StructProperty)
    float AngularVelocityScale; // 0x18 (Size: 0x4, Type: FloatProperty)
    float FictitiousAngularScale; // 0x1c (Size: 0x4, Type: FloatProperty)
    FVector GravityOverride; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector2D DragCoefficient; // 0x38 (Size: 0x10, Type: StructProperty)
    FVector2D LiftCoefficient; // 0x48 (Size: 0x10, Type: StructProperty)
    FVector2D OuterDrag; // 0x58 (Size: 0x10, Type: StructProperty)
    FVector2D OuterLift; // 0x68 (Size: 0x10, Type: StructProperty)
    FVector MaxLinearVelocity; // 0x78 (Size: 0x18, Type: StructProperty)
    FVector MaxLinearAcceleration; // 0x90 (Size: 0x18, Type: StructProperty)
    float MaxAngularVelocity; // 0xa8 (Size: 0x4, Type: FloatProperty)
    float MaxAngularAcceleration; // 0xac (Size: 0x4, Type: FloatProperty)
    bool bEnableLinearVelocityClamping; // 0xb0 (Size: 0x1, Type: BoolProperty)
    bool bEnableLinearAccelerationClamping; // 0xb1 (Size: 0x1, Type: BoolProperty)
    bool bEnableAngularVelocityClamping; // 0xb2 (Size: 0x1, Type: BoolProperty)
    bool bEnableAngularAccelerationClamping; // 0xb3 (Size: 0x1, Type: BoolProperty)
    FName JointName; // 0xb4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FClothParameters) == 0xb8, "Size mismatch for FClothParameters");
static_assert(offsetof(FClothParameters, LinearVelocityScale) == 0x0, "Offset mismatch for FClothParameters::LinearVelocityScale");
static_assert(offsetof(FClothParameters, AngularVelocityScale) == 0x18, "Offset mismatch for FClothParameters::AngularVelocityScale");
static_assert(offsetof(FClothParameters, FictitiousAngularScale) == 0x1c, "Offset mismatch for FClothParameters::FictitiousAngularScale");
static_assert(offsetof(FClothParameters, GravityOverride) == 0x20, "Offset mismatch for FClothParameters::GravityOverride");
static_assert(offsetof(FClothParameters, DragCoefficient) == 0x38, "Offset mismatch for FClothParameters::DragCoefficient");
static_assert(offsetof(FClothParameters, LiftCoefficient) == 0x48, "Offset mismatch for FClothParameters::LiftCoefficient");
static_assert(offsetof(FClothParameters, OuterDrag) == 0x58, "Offset mismatch for FClothParameters::OuterDrag");
static_assert(offsetof(FClothParameters, OuterLift) == 0x68, "Offset mismatch for FClothParameters::OuterLift");
static_assert(offsetof(FClothParameters, MaxLinearVelocity) == 0x78, "Offset mismatch for FClothParameters::MaxLinearVelocity");
static_assert(offsetof(FClothParameters, MaxLinearAcceleration) == 0x90, "Offset mismatch for FClothParameters::MaxLinearAcceleration");
static_assert(offsetof(FClothParameters, MaxAngularVelocity) == 0xa8, "Offset mismatch for FClothParameters::MaxAngularVelocity");
static_assert(offsetof(FClothParameters, MaxAngularAcceleration) == 0xac, "Offset mismatch for FClothParameters::MaxAngularAcceleration");
static_assert(offsetof(FClothParameters, bEnableLinearVelocityClamping) == 0xb0, "Offset mismatch for FClothParameters::bEnableLinearVelocityClamping");
static_assert(offsetof(FClothParameters, bEnableLinearAccelerationClamping) == 0xb1, "Offset mismatch for FClothParameters::bEnableLinearAccelerationClamping");
static_assert(offsetof(FClothParameters, bEnableAngularVelocityClamping) == 0xb2, "Offset mismatch for FClothParameters::bEnableAngularVelocityClamping");
static_assert(offsetof(FClothParameters, bEnableAngularAccelerationClamping) == 0xb3, "Offset mismatch for FClothParameters::bEnableAngularAccelerationClamping");
static_assert(offsetof(FClothParameters, JointName) == 0xb4, "Offset mismatch for FClothParameters::JointName");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FWindGustSettings
{
    float ElapsedTime; // 0x0 (Size: 0x4, Type: FloatProperty)
    float TimeBetweenGusts; // 0x4 (Size: 0x4, Type: FloatProperty)
    float GustStrength; // 0x8 (Size: 0x4, Type: FloatProperty)
    float GustDuration; // 0xc (Size: 0x4, Type: FloatProperty)
    float FinalGustStrengthLocal; // 0x10 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FWindGustSettings) == 0x14, "Size mismatch for FWindGustSettings");
static_assert(offsetof(FWindGustSettings, ElapsedTime) == 0x0, "Offset mismatch for FWindGustSettings::ElapsedTime");
static_assert(offsetof(FWindGustSettings, TimeBetweenGusts) == 0x4, "Offset mismatch for FWindGustSettings::TimeBetweenGusts");
static_assert(offsetof(FWindGustSettings, GustStrength) == 0x8, "Offset mismatch for FWindGustSettings::GustStrength");
static_assert(offsetof(FWindGustSettings, GustDuration) == 0xc, "Offset mismatch for FWindGustSettings::GustDuration");
static_assert(offsetof(FWindGustSettings, FinalGustStrengthLocal) == 0x10, "Offset mismatch for FWindGustSettings::FinalGustStrengthLocal");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FWindGustParameters
{
    float MinTimeBetweenGusts; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxTimeBetweenGusts; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinGustStrength; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxGustStrength; // 0xc (Size: 0x4, Type: FloatProperty)
    float MinGustDuration; // 0x10 (Size: 0x4, Type: FloatProperty)
    float MaxGustDuration; // 0x14 (Size: 0x4, Type: FloatProperty)
    float WindTurbulenceScalarA; // 0x18 (Size: 0x4, Type: FloatProperty)
    float WindTurbulenceScalarB; // 0x1c (Size: 0x4, Type: FloatProperty)
    float MinUpInterpSpeed; // 0x20 (Size: 0x4, Type: FloatProperty)
    float MaxUpInterpSpeed; // 0x24 (Size: 0x4, Type: FloatProperty)
    float MinDownInterpSpeed; // 0x28 (Size: 0x4, Type: FloatProperty)
    float MaxDownInterpSpeed; // 0x2c (Size: 0x4, Type: FloatProperty)
    FVector WindFrequency; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector WindAmplitude; // 0x48 (Size: 0x18, Type: StructProperty)
    FVector WindOffset; // 0x60 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FWindGustParameters) == 0x78, "Size mismatch for FWindGustParameters");
static_assert(offsetof(FWindGustParameters, MinTimeBetweenGusts) == 0x0, "Offset mismatch for FWindGustParameters::MinTimeBetweenGusts");
static_assert(offsetof(FWindGustParameters, MaxTimeBetweenGusts) == 0x4, "Offset mismatch for FWindGustParameters::MaxTimeBetweenGusts");
static_assert(offsetof(FWindGustParameters, MinGustStrength) == 0x8, "Offset mismatch for FWindGustParameters::MinGustStrength");
static_assert(offsetof(FWindGustParameters, MaxGustStrength) == 0xc, "Offset mismatch for FWindGustParameters::MaxGustStrength");
static_assert(offsetof(FWindGustParameters, MinGustDuration) == 0x10, "Offset mismatch for FWindGustParameters::MinGustDuration");
static_assert(offsetof(FWindGustParameters, MaxGustDuration) == 0x14, "Offset mismatch for FWindGustParameters::MaxGustDuration");
static_assert(offsetof(FWindGustParameters, WindTurbulenceScalarA) == 0x18, "Offset mismatch for FWindGustParameters::WindTurbulenceScalarA");
static_assert(offsetof(FWindGustParameters, WindTurbulenceScalarB) == 0x1c, "Offset mismatch for FWindGustParameters::WindTurbulenceScalarB");
static_assert(offsetof(FWindGustParameters, MinUpInterpSpeed) == 0x20, "Offset mismatch for FWindGustParameters::MinUpInterpSpeed");
static_assert(offsetof(FWindGustParameters, MaxUpInterpSpeed) == 0x24, "Offset mismatch for FWindGustParameters::MaxUpInterpSpeed");
static_assert(offsetof(FWindGustParameters, MinDownInterpSpeed) == 0x28, "Offset mismatch for FWindGustParameters::MinDownInterpSpeed");
static_assert(offsetof(FWindGustParameters, MaxDownInterpSpeed) == 0x2c, "Offset mismatch for FWindGustParameters::MaxDownInterpSpeed");
static_assert(offsetof(FWindGustParameters, WindFrequency) == 0x30, "Offset mismatch for FWindGustParameters::WindFrequency");
static_assert(offsetof(FWindGustParameters, WindAmplitude) == 0x48, "Offset mismatch for FWindGustParameters::WindAmplitude");
static_assert(offsetof(FWindGustParameters, WindOffset) == 0x60, "Offset mismatch for FWindGustParameters::WindOffset");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FClothControllerClothParameterMap
{
    TMap<FClothParameters, FName> Map; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FClothControllerClothParameterMap) == 0x50, "Size mismatch for FClothControllerClothParameterMap");
static_assert(offsetof(FClothControllerClothParameterMap, Map) == 0x0, "Offset mismatch for FClothControllerClothParameterMap::Map");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FClothControllerWindParameterMap
{
    TMap<FWindGustParameters, FName> Map; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FClothControllerWindParameterMap) == 0x50, "Size mismatch for FClothControllerWindParameterMap");
static_assert(offsetof(FClothControllerWindParameterMap, Map) == 0x0, "Offset mismatch for FClothControllerWindParameterMap::Map");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FClothControllerPropertiesMap
{
    TMap<bool, FName> Map; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FClothControllerPropertiesMap) == 0x50, "Size mismatch for FClothControllerPropertiesMap");
static_assert(offsetof(FClothControllerPropertiesMap, Map) == 0x0, "Offset mismatch for FClothControllerPropertiesMap::Map");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortCharacterDynamicsControlParameterSet
{
    TArray<FName> StateNames; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortCharacterDynamicsControlParameterSet) == 0x10, "Size mismatch for FFortCharacterDynamicsControlParameterSet");
static_assert(offsetof(FFortCharacterDynamicsControlParameterSet, StateNames) == 0x0, "Offset mismatch for FFortCharacterDynamicsControlParameterSet::StateNames");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FFortClothParameterSet : FFortCharacterDynamicsControlParameterSet
{
    TArray<FClothParameters> Parameters; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortClothParameterSet) == 0x20, "Size mismatch for FFortClothParameterSet");
static_assert(offsetof(FFortClothParameterSet, Parameters) == 0x10, "Offset mismatch for FFortClothParameterSet::Parameters");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FFortGravityOverrideParameterSet : FFortCharacterDynamicsControlParameterSet
{
    TArray<FFortGravityOverrideParameters> Parameters; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortGravityOverrideParameterSet) == 0x20, "Size mismatch for FFortGravityOverrideParameterSet");
static_assert(offsetof(FFortGravityOverrideParameterSet, Parameters) == 0x10, "Offset mismatch for FFortGravityOverrideParameterSet::Parameters");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FFortGravityOverrideParameters
{
    FVector WindFrequency; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector WindAmplitude; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector WindOffset; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector GravityOverride; // 0x48 (Size: 0x18, Type: StructProperty)
    FName JointName; // 0x60 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_64[0x4]; // 0x64 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortGravityOverrideParameters) == 0x68, "Size mismatch for FFortGravityOverrideParameters");
static_assert(offsetof(FFortGravityOverrideParameters, WindFrequency) == 0x0, "Offset mismatch for FFortGravityOverrideParameters::WindFrequency");
static_assert(offsetof(FFortGravityOverrideParameters, WindAmplitude) == 0x18, "Offset mismatch for FFortGravityOverrideParameters::WindAmplitude");
static_assert(offsetof(FFortGravityOverrideParameters, WindOffset) == 0x30, "Offset mismatch for FFortGravityOverrideParameters::WindOffset");
static_assert(offsetof(FFortGravityOverrideParameters, GravityOverride) == 0x48, "Offset mismatch for FFortGravityOverrideParameters::GravityOverride");
static_assert(offsetof(FFortGravityOverrideParameters, JointName) == 0x60, "Offset mismatch for FFortGravityOverrideParameters::JointName");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FFortRigidBodyAnimNodeParameterSet : FFortCharacterDynamicsControlParameterSet
{
    TArray<FFortRigidBodyAnimNodeParameters> Parameters; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortRigidBodyAnimNodeParameterSet) == 0x20, "Size mismatch for FFortRigidBodyAnimNodeParameterSet");
static_assert(offsetof(FFortRigidBodyAnimNodeParameterSet, Parameters) == 0x10, "Offset mismatch for FFortRigidBodyAnimNodeParameterSet::Parameters");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FFortRigidBodyAnimNodeParameters
{
    FVector ComponentLinearAccScale; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector ComponentLinearVelScale; // 0x18 (Size: 0x18, Type: StructProperty)
    FSimSpaceSettings SimSpaceSettings; // 0x30 (Size: 0x68, Type: StructProperty)
};

static_assert(sizeof(FFortRigidBodyAnimNodeParameters) == 0x98, "Size mismatch for FFortRigidBodyAnimNodeParameters");
static_assert(offsetof(FFortRigidBodyAnimNodeParameters, ComponentLinearAccScale) == 0x0, "Offset mismatch for FFortRigidBodyAnimNodeParameters::ComponentLinearAccScale");
static_assert(offsetof(FFortRigidBodyAnimNodeParameters, ComponentLinearVelScale) == 0x18, "Offset mismatch for FFortRigidBodyAnimNodeParameters::ComponentLinearVelScale");
static_assert(offsetof(FFortRigidBodyAnimNodeParameters, SimSpaceSettings) == 0x30, "Offset mismatch for FFortRigidBodyAnimNodeParameters::SimSpaceSettings");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FFortWindGustParameterSet : FFortCharacterDynamicsControlParameterSet
{
    TArray<FWindGustParameters> Parameters; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortWindGustParameterSet) == 0x20, "Size mismatch for FFortWindGustParameterSet");
static_assert(offsetof(FFortWindGustParameterSet, Parameters) == 0x10, "Offset mismatch for FFortWindGustParameterSet::Parameters");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FFortRigidBodyWithControlStateTransitionParameters
{
    FPhysicsControlControlAndModifierParameters ControlAndModifierParameters; // 0x0 (Size: 0x30, Type: StructProperty)
    float TransitionTimeSeconds; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortRigidBodyWithControlStateTransitionParameters) == 0x38, "Size mismatch for FFortRigidBodyWithControlStateTransitionParameters");
static_assert(offsetof(FFortRigidBodyWithControlStateTransitionParameters, ControlAndModifierParameters) == 0x0, "Offset mismatch for FFortRigidBodyWithControlStateTransitionParameters::ControlAndModifierParameters");
static_assert(offsetof(FFortRigidBodyWithControlStateTransitionParameters, TransitionTimeSeconds) == 0x30, "Offset mismatch for FFortRigidBodyWithControlStateTransitionParameters::TransitionTimeSeconds");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FProxyProperty
{
    uint32_t Operator; // 0x0 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FBitArrayWrapper BitArrayMask; // 0x8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FProxyProperty) == 0x28, "Size mismatch for FProxyProperty");
static_assert(offsetof(FProxyProperty, Operator) == 0x0, "Offset mismatch for FProxyProperty::Operator");
static_assert(offsetof(FProxyProperty, BitArrayMask) == 0x8, "Offset mismatch for FProxyProperty::BitArrayMask");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FProxyPropertyOrderingEditorData
{
    TArray<int32_t> ReversePropertyOrder; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t ProxyPropertyIndex; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FProxyPropertyOrderingEditorData) == 0x18, "Size mismatch for FProxyPropertyOrderingEditorData");
static_assert(offsetof(FProxyPropertyOrderingEditorData, ReversePropertyOrder) == 0x0, "Offset mismatch for FProxyPropertyOrderingEditorData::ReversePropertyOrder");
static_assert(offsetof(FProxyPropertyOrderingEditorData, ProxyPropertyIndex) == 0x10, "Offset mismatch for FProxyPropertyOrderingEditorData::ProxyPropertyIndex");

