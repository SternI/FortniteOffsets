/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRDLevelInstanceRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "PlayspaceSystem.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x368 (Inherited: 0xbc0, Single: 0xfffff7a8)
class AFortAthenaMutator_LevelInstanceDevice : public AFortAthenaMutator
{
public:
    TWeakObjectPtr<ALevelInstanceGameplayVolume*> CachedGameplayVolume; // 0x360 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(AFortAthenaMutator_LevelInstanceDevice) == 0x368, "Size mismatch for AFortAthenaMutator_LevelInstanceDevice");
static_assert(offsetof(AFortAthenaMutator_LevelInstanceDevice, CachedGameplayVolume) == 0x360, "Offset mismatch for AFortAthenaMutator_LevelInstanceDevice::CachedGameplayVolume");

// Size: 0x500 (Inherited: 0x618, Single: 0xfffffee8)
class ALevelInstanceGameplayVolume : public AGameplayVolume
{
public:
    uint8_t Pad_348[0x8]; // 0x348 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnLevelInstanceResolved[0x10]; // 0x350 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_360[0x30]; // 0x360 (Size: 0x30, Type: PaddingProperty)
    uint8_t OnDisabledStateChanged[0x10]; // 0x390 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLevelInstanceGuidChanged[0x10]; // 0x3a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLevelInstanceNameChanged[0x10]; // 0x3b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLevelInstanceSizeChanged[0x10]; // 0x3c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLevelInstanceContentCollectionChanged[0x10]; // 0x3d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_3e0[0x1]; // 0x3e0 (Size: 0x1, Type: PaddingProperty)
    bool bEditMode; // 0x3e1 (Size: 0x1, Type: BoolProperty)
    bool bDisabled; // 0x3e2 (Size: 0x1, Type: BoolProperty)
    uint8_t LoadingState; // 0x3e3 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3e4[0x4]; // 0x3e4 (Size: 0x4, Type: PaddingProperty)
    FString LevelInstanceName; // 0x3e8 (Size: 0x10, Type: StrProperty)
    bool bInstanceLoaded; // 0x3f8 (Size: 0x1, Type: BoolProperty)
    bool bWantsLevelLoaded; // 0x3f9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3fa[0x1]; // 0x3fa (Size: 0x1, Type: PaddingProperty)
    bool bConvertStructuresToProps; // 0x3fb (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3fc[0x4]; // 0x3fc (Size: 0x4, Type: PaddingProperty)
    AFortMinigame* CachedMinigame; // 0x400 (Size: 0x8, Type: ObjectProperty)
    UFortMutatorListComponent* MutatorListComponent; // 0x408 (Size: 0x8, Type: ObjectProperty)
    UFortClassTrackerComponent* ClassFilterComponent; // 0x410 (Size: 0x8, Type: ObjectProperty)
    TArray<UClass*> BlacklistedClasses; // 0x418 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_428[0x50]; // 0x428 (Size: 0x50, Type: PaddingProperty)
    FGuid LevelInstanceSaveActorGuid; // 0x478 (Size: 0x10, Type: StructProperty)
    AFortLevelInstanceSaveActor* LevelInstanceSaveActor; // 0x488 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_490[0x70]; // 0x490 (Size: 0x70, Type: PaddingProperty)

public:
    AFortLevelInstanceSaveActor* CreateLevelInstanceSaveActor(); // 0x11e66694 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    FString GetLevelInstanceName() const; // 0x11e666b8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsDisabled() const; // 0x11e668e0 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsInEditMode() const; // 0x11e668f8 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetEditMode(bool& bInEditMode); // 0x11e67ba4 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)
    void SetLevelInstanceActorGuid(FGuid& InLevelInstanceActorGuid); // 0x11e67d08 (Index: 0x15, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetLevelInstanceContentCollection(TSoftObjectPtr<UFortCreativeActorCollection*>& ContentCollection); // 0x11e67ddc (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void SetLevelInstanceName(FString& InName); // 0x11e680fc (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void SetWantsLevelLoaded(bool& bInWantsLevelLoaded); // 0x11e6851c (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void CheckForOverlappingVolumes(); // 0x11e66680 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleActorHealthChanged(AActor*& Actor, float& NewHealth); // 0x11e666d4 (Index: 0x3, Flags: Final|Native|Protected)
    void InstantiateFromLevelInstanceSaveActor(); // 0x11e668cc (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable)
    bool IsPreviewActor() const; // 0x11e66910 (Index: 0x7, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void LevelInstanceBeingDestroyed(); // 0x11e66934 (Index: 0x8, Flags: Final|Native|Protected)
    void LevelInstanceContentChanged(AActor*& const InstigatorActor); // 0x11e66948 (Index: 0x9, Flags: Final|Native|Protected)
    void LevelInstanceContentCollectionChanged(AActor*& const InstigatorActor, TSoftObjectPtr<UFortCreativeActorCollection*>& ContentCollection); // 0x11e66a74 (Index: 0xa, Flags: Final|Native|Protected)
    void LevelInstanceNameChanged(FString& Name); // 0x11e66e78 (Index: 0xb, Flags: Final|Native|Protected)
    void LevelInstanceSizeChanged(AActor*& const InstigatorActor); // 0x11e6716c (Index: 0xc, Flags: Final|Native|Protected)
    void OnMinigameStateChanged(AFortMinigame*& Minigame, EFortMinigameState& MinigameState); // 0x11e67298 (Index: 0xd, Flags: Final|Native|Protected)
    void OnRep_EditMode(); // 0x11e674a0 (Index: 0xe, Flags: Final|Native|Protected)
    void OnRep_InstanceLoaded(); // 0x11e674a0 (Index: 0xf, Flags: Final|Native|Protected)
    void OnRep_IsDisabled(); // 0x11e674a0 (Index: 0x10, Flags: Final|Native|Protected)
    virtual void OnVolumeChanged(); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
    void RemoveActorWhenDied(AActor*& DamagedActor, float& Damage, AController*& InstigatedBy, AActor*& DamageCauser, FVector& HitLocation, UPrimitiveComponent*& FHitComponent, FName& BoneName, FVector& Momentum); // 0x11e674b4 (Index: 0x12, Flags: Final|Native|Protected|HasDefaults)
    void RemoveActorWhenEndPlay(AActor*& Actor, TEnumAsByte<EEndPlayReason>& const EndPlayReason); // 0x11e67998 (Index: 0x13, Flags: Final|Native|Protected)
    void SetReadyForInstantiation(bool& bReady); // 0x11e683f0 (Index: 0x18, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(ALevelInstanceGameplayVolume) == 0x500, "Size mismatch for ALevelInstanceGameplayVolume");
static_assert(offsetof(ALevelInstanceGameplayVolume, OnLevelInstanceResolved) == 0x350, "Offset mismatch for ALevelInstanceGameplayVolume::OnLevelInstanceResolved");
static_assert(offsetof(ALevelInstanceGameplayVolume, OnDisabledStateChanged) == 0x390, "Offset mismatch for ALevelInstanceGameplayVolume::OnDisabledStateChanged");
static_assert(offsetof(ALevelInstanceGameplayVolume, OnLevelInstanceGuidChanged) == 0x3a0, "Offset mismatch for ALevelInstanceGameplayVolume::OnLevelInstanceGuidChanged");
static_assert(offsetof(ALevelInstanceGameplayVolume, OnLevelInstanceNameChanged) == 0x3b0, "Offset mismatch for ALevelInstanceGameplayVolume::OnLevelInstanceNameChanged");
static_assert(offsetof(ALevelInstanceGameplayVolume, OnLevelInstanceSizeChanged) == 0x3c0, "Offset mismatch for ALevelInstanceGameplayVolume::OnLevelInstanceSizeChanged");
static_assert(offsetof(ALevelInstanceGameplayVolume, OnLevelInstanceContentCollectionChanged) == 0x3d0, "Offset mismatch for ALevelInstanceGameplayVolume::OnLevelInstanceContentCollectionChanged");
static_assert(offsetof(ALevelInstanceGameplayVolume, bEditMode) == 0x3e1, "Offset mismatch for ALevelInstanceGameplayVolume::bEditMode");
static_assert(offsetof(ALevelInstanceGameplayVolume, bDisabled) == 0x3e2, "Offset mismatch for ALevelInstanceGameplayVolume::bDisabled");
static_assert(offsetof(ALevelInstanceGameplayVolume, LoadingState) == 0x3e3, "Offset mismatch for ALevelInstanceGameplayVolume::LoadingState");
static_assert(offsetof(ALevelInstanceGameplayVolume, LevelInstanceName) == 0x3e8, "Offset mismatch for ALevelInstanceGameplayVolume::LevelInstanceName");
static_assert(offsetof(ALevelInstanceGameplayVolume, bInstanceLoaded) == 0x3f8, "Offset mismatch for ALevelInstanceGameplayVolume::bInstanceLoaded");
static_assert(offsetof(ALevelInstanceGameplayVolume, bWantsLevelLoaded) == 0x3f9, "Offset mismatch for ALevelInstanceGameplayVolume::bWantsLevelLoaded");
static_assert(offsetof(ALevelInstanceGameplayVolume, bConvertStructuresToProps) == 0x3fb, "Offset mismatch for ALevelInstanceGameplayVolume::bConvertStructuresToProps");
static_assert(offsetof(ALevelInstanceGameplayVolume, CachedMinigame) == 0x400, "Offset mismatch for ALevelInstanceGameplayVolume::CachedMinigame");
static_assert(offsetof(ALevelInstanceGameplayVolume, MutatorListComponent) == 0x408, "Offset mismatch for ALevelInstanceGameplayVolume::MutatorListComponent");
static_assert(offsetof(ALevelInstanceGameplayVolume, ClassFilterComponent) == 0x410, "Offset mismatch for ALevelInstanceGameplayVolume::ClassFilterComponent");
static_assert(offsetof(ALevelInstanceGameplayVolume, BlacklistedClasses) == 0x418, "Offset mismatch for ALevelInstanceGameplayVolume::BlacklistedClasses");
static_assert(offsetof(ALevelInstanceGameplayVolume, LevelInstanceSaveActorGuid) == 0x478, "Offset mismatch for ALevelInstanceGameplayVolume::LevelInstanceSaveActorGuid");
static_assert(offsetof(ALevelInstanceGameplayVolume, LevelInstanceSaveActor) == 0x488, "Offset mismatch for ALevelInstanceGameplayVolume::LevelInstanceSaveActor");

// Size: 0x148 (Inherited: 0x228, Single: 0xffffff20)
class ULevelInstanceItemListComponent : public UFortMinigameItemContainerComponent
{
public:
};

static_assert(sizeof(ULevelInstanceItemListComponent) == 0x148, "Size mismatch for ULevelInstanceItemListComponent");

