/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EngineCameras
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "TemplateSequence.h"

// Size: 0x1f0 (Inherited: 0x108, Single: 0xe8)
class ULegacyCameraShake : public UCameraShakeBase
{
public:
    float OscillationDuration; // 0xd8 (Size: 0x4, Type: FloatProperty)
    float OscillationBlendInTime; // 0xdc (Size: 0x4, Type: FloatProperty)
    float OscillationBlendOutTime; // 0xe0 (Size: 0x4, Type: FloatProperty)
    FROscillator RotOscillation; // 0xe4 (Size: 0x24, Type: StructProperty)
    FVOscillator LocOscillation; // 0x108 (Size: 0x24, Type: StructProperty)
    FFOscillator FOVOscillation; // 0x12c (Size: 0xc, Type: StructProperty)
    float AnimPlayRate; // 0x138 (Size: 0x4, Type: FloatProperty)
    float AnimScale; // 0x13c (Size: 0x4, Type: FloatProperty)
    float AnimBlendInTime; // 0x140 (Size: 0x4, Type: FloatProperty)
    float AnimBlendOutTime; // 0x144 (Size: 0x4, Type: FloatProperty)
    float RandomAnimSegmentDuration; // 0x148 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14c[0x4]; // 0x14c (Size: 0x4, Type: PaddingProperty)
    UCameraAnimationSequence* AnimSequence; // 0x150 (Size: 0x8, Type: ObjectProperty)
    uint8_t bRandomAnimSegment : 1; // 0x158:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_159[0x3]; // 0x159 (Size: 0x3, Type: PaddingProperty)
    float OscillatorTimeRemaining; // 0x15c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_160[0x78]; // 0x160 (Size: 0x78, Type: PaddingProperty)
    USequenceCameraShakePattern* SequenceShakePattern; // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1e0[0x10]; // 0x1e0 (Size: 0x10, Type: PaddingProperty)

public:
    virtual void BlueprintUpdateCameraShake(float& DeltaTime, float& Alpha, const FMinimalViewInfo POV, FMinimalViewInfo& ModifiedPOV); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual bool ReceiveIsFinished() const; // 0x9e96818 (Index: 0x1, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual void ReceivePlayShake(float& Scale); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void ReceiveStopShake(bool& bImmediately); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    static ULegacyCameraShake* StartLegacyCameraShake(APlayerCameraManager*& PlayerCameraManager, UClass*& ShakeClass, float& Scale, ECameraShakePlaySpace& Playspace, FRotator& UserPlaySpaceRot); // 0x5825880 (Index: 0x4, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static ULegacyCameraShake* StartLegacyCameraShakeFromSource(APlayerCameraManager*& PlayerCameraManager, UClass*& ShakeClass, UCameraShakeSourceComponent*& SourceComponent, float& Scale, ECameraShakePlaySpace& Playspace, FRotator& UserPlaySpaceRot); // 0xc31662c (Index: 0x5, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(ULegacyCameraShake) == 0x1f0, "Size mismatch for ULegacyCameraShake");
static_assert(offsetof(ULegacyCameraShake, OscillationDuration) == 0xd8, "Offset mismatch for ULegacyCameraShake::OscillationDuration");
static_assert(offsetof(ULegacyCameraShake, OscillationBlendInTime) == 0xdc, "Offset mismatch for ULegacyCameraShake::OscillationBlendInTime");
static_assert(offsetof(ULegacyCameraShake, OscillationBlendOutTime) == 0xe0, "Offset mismatch for ULegacyCameraShake::OscillationBlendOutTime");
static_assert(offsetof(ULegacyCameraShake, RotOscillation) == 0xe4, "Offset mismatch for ULegacyCameraShake::RotOscillation");
static_assert(offsetof(ULegacyCameraShake, LocOscillation) == 0x108, "Offset mismatch for ULegacyCameraShake::LocOscillation");
static_assert(offsetof(ULegacyCameraShake, FOVOscillation) == 0x12c, "Offset mismatch for ULegacyCameraShake::FOVOscillation");
static_assert(offsetof(ULegacyCameraShake, AnimPlayRate) == 0x138, "Offset mismatch for ULegacyCameraShake::AnimPlayRate");
static_assert(offsetof(ULegacyCameraShake, AnimScale) == 0x13c, "Offset mismatch for ULegacyCameraShake::AnimScale");
static_assert(offsetof(ULegacyCameraShake, AnimBlendInTime) == 0x140, "Offset mismatch for ULegacyCameraShake::AnimBlendInTime");
static_assert(offsetof(ULegacyCameraShake, AnimBlendOutTime) == 0x144, "Offset mismatch for ULegacyCameraShake::AnimBlendOutTime");
static_assert(offsetof(ULegacyCameraShake, RandomAnimSegmentDuration) == 0x148, "Offset mismatch for ULegacyCameraShake::RandomAnimSegmentDuration");
static_assert(offsetof(ULegacyCameraShake, AnimSequence) == 0x150, "Offset mismatch for ULegacyCameraShake::AnimSequence");
static_assert(offsetof(ULegacyCameraShake, bRandomAnimSegment) == 0x158, "Offset mismatch for ULegacyCameraShake::bRandomAnimSegment");
static_assert(offsetof(ULegacyCameraShake, OscillatorTimeRemaining) == 0x15c, "Offset mismatch for ULegacyCameraShake::OscillatorTimeRemaining");
static_assert(offsetof(ULegacyCameraShake, SequenceShakePattern) == 0x1d8, "Offset mismatch for ULegacyCameraShake::SequenceShakePattern");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class ULegacyCameraShakePattern : public UCameraShakePattern
{
public:
};

static_assert(sizeof(ULegacyCameraShakePattern) == 0x28, "Size mismatch for ULegacyCameraShakePattern");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class ULegacyCameraShakeFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static ULegacyCameraShake* Conv_LegacyCameraShake(UCameraShakeBase*& CameraShake); // 0xc315458 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(ULegacyCameraShakeFunctionLibrary) == 0x28, "Size mismatch for ULegacyCameraShakeFunctionLibrary");

// Size: 0x60 (Inherited: 0x70, Single: 0xfffffff0)
class UCameraAnimationCameraModifier : public UCameraModifier
{
public:
    TArray<FActiveCameraAnimationInfo> ActiveAnimations; // 0x48 (Size: 0x10, Type: ArrayProperty)
    uint16_t NextInstanceSerialNumber; // 0x58 (Size: 0x2, Type: UInt16Property)
    uint8_t Pad_5a[0x6]; // 0x5a (Size: 0x6, Type: PaddingProperty)

public:
    static UCameraAnimationCameraModifier* GetCameraAnimationCameraModifier(UObject*& const WorldContextObject, int32_t& PlayerIndex); // 0xc31557c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UCameraAnimationCameraModifier* GetCameraAnimationCameraModifierFromID(UObject*& const WorldContextObject, int32_t& ControllerId); // 0xc31578c (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UCameraAnimationCameraModifier* GetCameraAnimationCameraModifierFromPlayerController(APlayerController*& const PlayerController); // 0xc31599c (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    bool IsCameraAnimationActive(const FCameraAnimationHandle Handle) const; // 0xc315ac4 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FCameraAnimationHandle PlayCameraAnimation(UCameraAnimationSequence*& Sequence, FCameraAnimationParams& Params); // 0xc315d70 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void StopAllCameraAnimations(bool& bImmediate); // 0xc316d14 (Index: 0x5, Flags: Native|Public|BlueprintCallable)
    void StopAllCameraAnimationsOf(UCameraAnimationSequence*& Sequence, bool& bImmediate); // 0xc317068 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void StopCameraAnimation(const FCameraAnimationHandle Handle, bool& bImmediate); // 0xc317564 (Index: 0x7, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UCameraAnimationCameraModifier) == 0x60, "Size mismatch for UCameraAnimationCameraModifier");
static_assert(offsetof(UCameraAnimationCameraModifier, ActiveAnimations) == 0x48, "Offset mismatch for UCameraAnimationCameraModifier::ActiveAnimations");
static_assert(offsetof(UCameraAnimationCameraModifier, NextInstanceSerialNumber) == 0x58, "Offset mismatch for UCameraAnimationCameraModifier::NextInstanceSerialNumber");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEngineCameraAnimationFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static UCameraAnimationCameraModifier* Conv_CameraAnimationCameraModifier(APlayerCameraManager*& PlayerCameraManager); // 0xc315014 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static ECameraAnimationPlaySpace Conv_CameraAnimationPlaySpace(ECameraShakePlaySpace& CameraShakePlaySpace); // 0xc315328 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static ECameraShakePlaySpace Conv_CameraShakePlaySpace(ECameraAnimationPlaySpace& CameraAnimationPlaySpace); // 0xc315328 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UEngineCameraAnimationFunctionLibrary) == 0x28, "Size mismatch for UEngineCameraAnimationFunctionLibrary");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UEngineCamerasSubsystem : public UWorldSubsystem
{
public:

public:
    bool IsCameraAnimationActive(APlayerController*& PlayerController, const FCameraAnimationHandle Handle) const; // 0xc315ba4 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FCameraAnimationHandle PlayCameraAnimation(APlayerController*& PlayerController, UCameraAnimationSequence*& Sequence, FCameraAnimationParams& Params); // 0xc316338 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void StopAllCameraAnimations(APlayerController*& PlayerController, bool& bImmediate); // 0xc316e44 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void StopAllCameraAnimationsOf(APlayerController*& PlayerController, UCameraAnimationSequence*& Sequence, bool& bImmediate); // 0xc317274 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void StopCameraAnimation(APlayerController*& PlayerController, const FCameraAnimationHandle Handle, bool& bImmediate); // 0xc3176bc (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UEngineCamerasSubsystem) == 0x30, "Size mismatch for UEngineCamerasSubsystem");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UCompositeCameraShakePattern : public UCameraShakePattern
{
public:
    TArray<UCameraShakePattern*> ChildPatterns; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCompositeCameraShakePattern) == 0x38, "Size mismatch for UCompositeCameraShakePattern");
static_assert(offsetof(UCompositeCameraShakePattern, ChildPatterns) == 0x28, "Offset mismatch for UCompositeCameraShakePattern::ChildPatterns");

// Size: 0xe0 (Inherited: 0x108, Single: 0xffffffd8)
class UDefaultCameraShakeBase : public UCameraShakeBase
{
public:
};

static_assert(sizeof(UDefaultCameraShakeBase) == 0xe0, "Size mismatch for UDefaultCameraShakeBase");

// Size: 0xd8 (Inherited: 0xa8, Single: 0x30)
class UPerlinNoiseCameraShakePattern : public USimpleCameraShakePattern
{
public:
    float LocationAmplitudeMultiplier; // 0x58 (Size: 0x4, Type: FloatProperty)
    float LocationFrequencyMultiplier; // 0x5c (Size: 0x4, Type: FloatProperty)
    FPerlinNoiseShaker X; // 0x60 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseShaker Y; // 0x68 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseShaker Z; // 0x70 (Size: 0x8, Type: StructProperty)
    float RotationAmplitudeMultiplier; // 0x78 (Size: 0x4, Type: FloatProperty)
    float RotationFrequencyMultiplier; // 0x7c (Size: 0x4, Type: FloatProperty)
    FPerlinNoiseShaker pitch; // 0x80 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseShaker Yaw; // 0x88 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseShaker Roll; // 0x90 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseShaker FOV; // 0x98 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_a0[0x38]; // 0xa0 (Size: 0x38, Type: PaddingProperty)
};

static_assert(sizeof(UPerlinNoiseCameraShakePattern) == 0xd8, "Size mismatch for UPerlinNoiseCameraShakePattern");
static_assert(offsetof(UPerlinNoiseCameraShakePattern, LocationAmplitudeMultiplier) == 0x58, "Offset mismatch for UPerlinNoiseCameraShakePattern::LocationAmplitudeMultiplier");
static_assert(offsetof(UPerlinNoiseCameraShakePattern, LocationFrequencyMultiplier) == 0x5c, "Offset mismatch for UPerlinNoiseCameraShakePattern::LocationFrequencyMultiplier");
static_assert(offsetof(UPerlinNoiseCameraShakePattern, X) == 0x60, "Offset mismatch for UPerlinNoiseCameraShakePattern::X");
static_assert(offsetof(UPerlinNoiseCameraShakePattern, Y) == 0x68, "Offset mismatch for UPerlinNoiseCameraShakePattern::Y");
static_assert(offsetof(UPerlinNoiseCameraShakePattern, Z) == 0x70, "Offset mismatch for UPerlinNoiseCameraShakePattern::Z");
static_assert(offsetof(UPerlinNoiseCameraShakePattern, RotationAmplitudeMultiplier) == 0x78, "Offset mismatch for UPerlinNoiseCameraShakePattern::RotationAmplitudeMultiplier");
static_assert(offsetof(UPerlinNoiseCameraShakePattern, RotationFrequencyMultiplier) == 0x7c, "Offset mismatch for UPerlinNoiseCameraShakePattern::RotationFrequencyMultiplier");
static_assert(offsetof(UPerlinNoiseCameraShakePattern, pitch) == 0x80, "Offset mismatch for UPerlinNoiseCameraShakePattern::pitch");
static_assert(offsetof(UPerlinNoiseCameraShakePattern, Yaw) == 0x88, "Offset mismatch for UPerlinNoiseCameraShakePattern::Yaw");
static_assert(offsetof(UPerlinNoiseCameraShakePattern, Roll) == 0x90, "Offset mismatch for UPerlinNoiseCameraShakePattern::Roll");
static_assert(offsetof(UPerlinNoiseCameraShakePattern, FOV) == 0x98, "Offset mismatch for UPerlinNoiseCameraShakePattern::FOV");

// Size: 0x58 (Inherited: 0x50, Single: 0x8)
class USimpleCameraShakePattern : public UCameraShakePattern
{
public:
    float duration; // 0x28 (Size: 0x4, Type: FloatProperty)
    float BlendInTime; // 0x2c (Size: 0x4, Type: FloatProperty)
    float BlendOutTime; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x24]; // 0x34 (Size: 0x24, Type: PaddingProperty)
};

static_assert(sizeof(USimpleCameraShakePattern) == 0x58, "Size mismatch for USimpleCameraShakePattern");
static_assert(offsetof(USimpleCameraShakePattern, duration) == 0x28, "Offset mismatch for USimpleCameraShakePattern::duration");
static_assert(offsetof(USimpleCameraShakePattern, BlendInTime) == 0x2c, "Offset mismatch for USimpleCameraShakePattern::BlendInTime");
static_assert(offsetof(USimpleCameraShakePattern, BlendOutTime) == 0x30, "Offset mismatch for USimpleCameraShakePattern::BlendOutTime");

// Size: 0xf8 (Inherited: 0xa8, Single: 0x50)
class UWaveOscillatorCameraShakePattern : public USimpleCameraShakePattern
{
public:
    float LocationAmplitudeMultiplier; // 0x58 (Size: 0x4, Type: FloatProperty)
    float LocationFrequencyMultiplier; // 0x5c (Size: 0x4, Type: FloatProperty)
    FWaveOscillator X; // 0x60 (Size: 0xc, Type: StructProperty)
    FWaveOscillator Y; // 0x6c (Size: 0xc, Type: StructProperty)
    FWaveOscillator Z; // 0x78 (Size: 0xc, Type: StructProperty)
    float RotationAmplitudeMultiplier; // 0x84 (Size: 0x4, Type: FloatProperty)
    float RotationFrequencyMultiplier; // 0x88 (Size: 0x4, Type: FloatProperty)
    FWaveOscillator pitch; // 0x8c (Size: 0xc, Type: StructProperty)
    FWaveOscillator Yaw; // 0x98 (Size: 0xc, Type: StructProperty)
    FWaveOscillator Roll; // 0xa4 (Size: 0xc, Type: StructProperty)
    FWaveOscillator FOV; // 0xb0 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_bc[0x3c]; // 0xbc (Size: 0x3c, Type: PaddingProperty)
};

static_assert(sizeof(UWaveOscillatorCameraShakePattern) == 0xf8, "Size mismatch for UWaveOscillatorCameraShakePattern");
static_assert(offsetof(UWaveOscillatorCameraShakePattern, LocationAmplitudeMultiplier) == 0x58, "Offset mismatch for UWaveOscillatorCameraShakePattern::LocationAmplitudeMultiplier");
static_assert(offsetof(UWaveOscillatorCameraShakePattern, LocationFrequencyMultiplier) == 0x5c, "Offset mismatch for UWaveOscillatorCameraShakePattern::LocationFrequencyMultiplier");
static_assert(offsetof(UWaveOscillatorCameraShakePattern, X) == 0x60, "Offset mismatch for UWaveOscillatorCameraShakePattern::X");
static_assert(offsetof(UWaveOscillatorCameraShakePattern, Y) == 0x6c, "Offset mismatch for UWaveOscillatorCameraShakePattern::Y");
static_assert(offsetof(UWaveOscillatorCameraShakePattern, Z) == 0x78, "Offset mismatch for UWaveOscillatorCameraShakePattern::Z");
static_assert(offsetof(UWaveOscillatorCameraShakePattern, RotationAmplitudeMultiplier) == 0x84, "Offset mismatch for UWaveOscillatorCameraShakePattern::RotationAmplitudeMultiplier");
static_assert(offsetof(UWaveOscillatorCameraShakePattern, RotationFrequencyMultiplier) == 0x88, "Offset mismatch for UWaveOscillatorCameraShakePattern::RotationFrequencyMultiplier");
static_assert(offsetof(UWaveOscillatorCameraShakePattern, pitch) == 0x8c, "Offset mismatch for UWaveOscillatorCameraShakePattern::pitch");
static_assert(offsetof(UWaveOscillatorCameraShakePattern, Yaw) == 0x98, "Offset mismatch for UWaveOscillatorCameraShakePattern::Yaw");
static_assert(offsetof(UWaveOscillatorCameraShakePattern, Roll) == 0xa4, "Offset mismatch for UWaveOscillatorCameraShakePattern::Roll");
static_assert(offsetof(UWaveOscillatorCameraShakePattern, FOV) == 0xb0, "Offset mismatch for UWaveOscillatorCameraShakePattern::FOV");

// Size: 0xe0 (Inherited: 0x108, Single: 0xffffffd8)
class UTestCameraShake : public UCameraShakeBase
{
public:
};

static_assert(sizeof(UTestCameraShake) == 0xe0, "Size mismatch for UTestCameraShake");

// Size: 0x88 (Inherited: 0xa8, Single: 0xffffffe0)
class UConstantCameraShakePattern : public USimpleCameraShakePattern
{
public:
    FVector LocationOffset; // 0x58 (Size: 0x18, Type: StructProperty)
    FRotator RotationOffset; // 0x70 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UConstantCameraShakePattern) == 0x88, "Size mismatch for UConstantCameraShakePattern");
static_assert(offsetof(UConstantCameraShakePattern, LocationOffset) == 0x58, "Offset mismatch for UConstantCameraShakePattern::LocationOffset");
static_assert(offsetof(UConstantCameraShakePattern, RotationOffset) == 0x70, "Offset mismatch for UConstantCameraShakePattern::RotationOffset");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FFOscillator
{
    float Amplitude; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Frequency; // 0x4 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EInitialOscillatorOffset> InitialOffset; // 0x8 (Size: 0x1, Type: ByteProperty)
    uint8_t Waveform; // 0x9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a[0x2]; // 0xa (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FFOscillator) == 0xc, "Size mismatch for FFOscillator");
static_assert(offsetof(FFOscillator, Amplitude) == 0x0, "Offset mismatch for FFOscillator::Amplitude");
static_assert(offsetof(FFOscillator, Frequency) == 0x4, "Offset mismatch for FFOscillator::Frequency");
static_assert(offsetof(FFOscillator, InitialOffset) == 0x8, "Offset mismatch for FFOscillator::InitialOffset");
static_assert(offsetof(FFOscillator, Waveform) == 0x9, "Offset mismatch for FFOscillator::Waveform");

// Size: 0x24 (Inherited: 0x0, Single: 0x24)
struct FROscillator
{
    FFOscillator pitch; // 0x0 (Size: 0xc, Type: StructProperty)
    FFOscillator Yaw; // 0xc (Size: 0xc, Type: StructProperty)
    FFOscillator Roll; // 0x18 (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(FROscillator) == 0x24, "Size mismatch for FROscillator");
static_assert(offsetof(FROscillator, pitch) == 0x0, "Offset mismatch for FROscillator::pitch");
static_assert(offsetof(FROscillator, Yaw) == 0xc, "Offset mismatch for FROscillator::Yaw");
static_assert(offsetof(FROscillator, Roll) == 0x18, "Offset mismatch for FROscillator::Roll");

// Size: 0x24 (Inherited: 0x0, Single: 0x24)
struct FVOscillator
{
    FFOscillator X; // 0x0 (Size: 0xc, Type: StructProperty)
    FFOscillator Y; // 0xc (Size: 0xc, Type: StructProperty)
    FFOscillator Z; // 0x18 (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(FVOscillator) == 0x24, "Size mismatch for FVOscillator");
static_assert(offsetof(FVOscillator, X) == 0x0, "Offset mismatch for FVOscillator::X");
static_assert(offsetof(FVOscillator, Y) == 0xc, "Offset mismatch for FVOscillator::Y");
static_assert(offsetof(FVOscillator, Z) == 0x18, "Offset mismatch for FVOscillator::Z");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FCameraAnimationParams
{
    float PlayRate; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t EaseInType; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    float EaseInDuration; // 0xc (Size: 0x4, Type: FloatProperty)
    uint8_t EaseOutType; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float EaseOutDuration; // 0x14 (Size: 0x4, Type: FloatProperty)
    bool bLoop; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
    int32_t StartOffset; // 0x1c (Size: 0x4, Type: IntProperty)
    bool bRandomStartTime; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x3]; // 0x21 (Size: 0x3, Type: PaddingProperty)
    float DurationOverride; // 0x24 (Size: 0x4, Type: FloatProperty)
    uint8_t Playspace; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    FRotator UserPlaySpaceRot; // 0x30 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FCameraAnimationParams) == 0x48, "Size mismatch for FCameraAnimationParams");
static_assert(offsetof(FCameraAnimationParams, PlayRate) == 0x0, "Offset mismatch for FCameraAnimationParams::PlayRate");
static_assert(offsetof(FCameraAnimationParams, Scale) == 0x4, "Offset mismatch for FCameraAnimationParams::Scale");
static_assert(offsetof(FCameraAnimationParams, EaseInType) == 0x8, "Offset mismatch for FCameraAnimationParams::EaseInType");
static_assert(offsetof(FCameraAnimationParams, EaseInDuration) == 0xc, "Offset mismatch for FCameraAnimationParams::EaseInDuration");
static_assert(offsetof(FCameraAnimationParams, EaseOutType) == 0x10, "Offset mismatch for FCameraAnimationParams::EaseOutType");
static_assert(offsetof(FCameraAnimationParams, EaseOutDuration) == 0x14, "Offset mismatch for FCameraAnimationParams::EaseOutDuration");
static_assert(offsetof(FCameraAnimationParams, bLoop) == 0x18, "Offset mismatch for FCameraAnimationParams::bLoop");
static_assert(offsetof(FCameraAnimationParams, StartOffset) == 0x1c, "Offset mismatch for FCameraAnimationParams::StartOffset");
static_assert(offsetof(FCameraAnimationParams, bRandomStartTime) == 0x20, "Offset mismatch for FCameraAnimationParams::bRandomStartTime");
static_assert(offsetof(FCameraAnimationParams, DurationOverride) == 0x24, "Offset mismatch for FCameraAnimationParams::DurationOverride");
static_assert(offsetof(FCameraAnimationParams, Playspace) == 0x28, "Offset mismatch for FCameraAnimationParams::Playspace");
static_assert(offsetof(FCameraAnimationParams, UserPlaySpaceRot) == 0x30, "Offset mismatch for FCameraAnimationParams::UserPlaySpaceRot");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCameraAnimationHandle
{
};

static_assert(sizeof(FCameraAnimationHandle) == 0x4, "Size mismatch for FCameraAnimationHandle");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FActiveCameraAnimationInfo
{
    UCameraAnimationSequence* Sequence; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FCameraAnimationParams Params; // 0x8 (Size: 0x48, Type: StructProperty)
    FCameraAnimationHandle Handle; // 0x50 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
    UCameraAnimationSequencePlayer* Player; // 0x58 (Size: 0x8, Type: ObjectProperty)
    UCameraAnimationSequenceCameraStandIn* CameraStandIn; // 0x60 (Size: 0x8, Type: ObjectProperty)
    float EaseInCurrentTime; // 0x68 (Size: 0x4, Type: FloatProperty)
    float EaseOutCurrentTime; // 0x6c (Size: 0x4, Type: FloatProperty)
    bool bIsEasingIn; // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bIsEasingOut; // 0x71 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_72[0x6]; // 0x72 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FActiveCameraAnimationInfo) == 0x78, "Size mismatch for FActiveCameraAnimationInfo");
static_assert(offsetof(FActiveCameraAnimationInfo, Sequence) == 0x0, "Offset mismatch for FActiveCameraAnimationInfo::Sequence");
static_assert(offsetof(FActiveCameraAnimationInfo, Params) == 0x8, "Offset mismatch for FActiveCameraAnimationInfo::Params");
static_assert(offsetof(FActiveCameraAnimationInfo, Handle) == 0x50, "Offset mismatch for FActiveCameraAnimationInfo::Handle");
static_assert(offsetof(FActiveCameraAnimationInfo, Player) == 0x58, "Offset mismatch for FActiveCameraAnimationInfo::Player");
static_assert(offsetof(FActiveCameraAnimationInfo, CameraStandIn) == 0x60, "Offset mismatch for FActiveCameraAnimationInfo::CameraStandIn");
static_assert(offsetof(FActiveCameraAnimationInfo, EaseInCurrentTime) == 0x68, "Offset mismatch for FActiveCameraAnimationInfo::EaseInCurrentTime");
static_assert(offsetof(FActiveCameraAnimationInfo, EaseOutCurrentTime) == 0x6c, "Offset mismatch for FActiveCameraAnimationInfo::EaseOutCurrentTime");
static_assert(offsetof(FActiveCameraAnimationInfo, bIsEasingIn) == 0x70, "Offset mismatch for FActiveCameraAnimationInfo::bIsEasingIn");
static_assert(offsetof(FActiveCameraAnimationInfo, bIsEasingOut) == 0x71, "Offset mismatch for FActiveCameraAnimationInfo::bIsEasingOut");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FPerlinNoiseShaker
{
    float Amplitude; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Frequency; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FPerlinNoiseShaker) == 0x8, "Size mismatch for FPerlinNoiseShaker");
static_assert(offsetof(FPerlinNoiseShaker, Amplitude) == 0x0, "Offset mismatch for FPerlinNoiseShaker::Amplitude");
static_assert(offsetof(FPerlinNoiseShaker, Frequency) == 0x4, "Offset mismatch for FPerlinNoiseShaker::Frequency");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FWaveOscillator
{
    float Amplitude; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Frequency; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t InitialOffsetType; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FWaveOscillator) == 0xc, "Size mismatch for FWaveOscillator");
static_assert(offsetof(FWaveOscillator, Amplitude) == 0x0, "Offset mismatch for FWaveOscillator::Amplitude");
static_assert(offsetof(FWaveOscillator, Frequency) == 0x4, "Offset mismatch for FWaveOscillator::Frequency");
static_assert(offsetof(FWaveOscillator, InitialOffsetType) == 0x8, "Offset mismatch for FWaveOscillator::InitialOffsetType");

