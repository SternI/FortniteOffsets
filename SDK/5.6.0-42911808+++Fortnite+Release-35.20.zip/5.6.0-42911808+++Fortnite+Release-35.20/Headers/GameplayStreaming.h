/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayStreaming
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x78 (Inherited: 0xa0, Single: 0xffffffd8)
class UGFNGameplayStreamingHandler : public UBaseGameplayStreamingHandler
{
public:
};

static_assert(sizeof(UGFNGameplayStreamingHandler) == 0x78, "Size mismatch for UGFNGameplayStreamingHandler");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UBaseGameplayStreamingHandler : public UObject
{
public:
};

static_assert(sizeof(UBaseGameplayStreamingHandler) == 0x78, "Size mismatch for UBaseGameplayStreamingHandler");

// Size: 0x78 (Inherited: 0xa0, Single: 0xffffffd8)
class ULunaGameplayStreamingHandler : public UBaseGameplayStreamingHandler
{
public:
};

static_assert(sizeof(ULunaGameplayStreamingHandler) == 0x78, "Size mismatch for ULunaGameplayStreamingHandler");

// Size: 0x78 (Inherited: 0xa0, Single: 0xffffffd8)
class USalmonGameplayStreamingHandler : public UBaseGameplayStreamingHandler
{
public:
};

static_assert(sizeof(USalmonGameplayStreamingHandler) == 0x78, "Size mismatch for USalmonGameplayStreamingHandler");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UGameplayStreamingClassLoader : public UObject
{
public:
    FSoftClassPath GameplayStreamingServiceClassName; // 0x28 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_40[0x8]; // 0x40 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UGameplayStreamingClassLoader) == 0x48, "Size mismatch for UGameplayStreamingClassLoader");
static_assert(offsetof(UGameplayStreamingClassLoader, GameplayStreamingServiceClassName) == 0x28, "Offset mismatch for UGameplayStreamingClassLoader::GameplayStreamingServiceClassName");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UGameplayStreamingService : public UObject
{
public:
    UBaseGameplayStreamingHandler* ActiveHandler; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UGameplayStreamingService) == 0x30, "Size mismatch for UGameplayStreamingService");
static_assert(offsetof(UGameplayStreamingService, ActiveHandler) == 0x28, "Offset mismatch for UGameplayStreamingService::ActiveHandler");

