/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CowCatcherModCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0x9b8 (Inherited: 0x13c8, Single: 0xfffff5f0)
class ACowCatcherBarricadeBase : public ABuildingGameplayActor
{
public:

protected:
    void BeginCheckingForTouchingPawns(); // 0x11240b68 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable)
    virtual void OnPlacementBlockedByPawnChanged(bool& const bBlockedByPawn); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ACowCatcherBarricadeBase) == 0x9b8, "Size mismatch for ACowCatcherBarricadeBase");

