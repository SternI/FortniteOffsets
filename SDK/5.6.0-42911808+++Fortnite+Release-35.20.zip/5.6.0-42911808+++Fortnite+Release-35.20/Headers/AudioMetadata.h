/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioMetadata
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DeveloperSettings.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "AudioModulation.h"

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UAudioMetadataDeveloperSettings : public UDeveloperSettings
{
public:
    FAudioMetadataModulationSettings ModulationSettings; // 0x30 (Size: 0x10, Type: StructProperty)
    FAudioMetadataSubmixSettings SubmixSettings; // 0x40 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UAudioMetadataDeveloperSettings) == 0x50, "Size mismatch for UAudioMetadataDeveloperSettings");
static_assert(offsetof(UAudioMetadataDeveloperSettings, ModulationSettings) == 0x30, "Offset mismatch for UAudioMetadataDeveloperSettings::ModulationSettings");
static_assert(offsetof(UAudioMetadataDeveloperSettings, SubmixSettings) == 0x40, "Offset mismatch for UAudioMetadataDeveloperSettings::SubmixSettings");

// Size: 0x40 (Inherited: 0xb8, Single: 0xffffff88)
class UAudioMetadataSubsystem : public UAudioEngineSubsystem
{
public:

public:
    static bool HasTag(USoundBase*& InSound, FGameplayTag& InTag, bool& bExactMatch); // 0xca05120 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UAudioMetadataSubsystem) == 0x40, "Size mismatch for UAudioMetadataSubsystem");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAudioMetadataModulationSettings
{
    USoundControlBus* ControlBusLicensedAudioMuteAll; // 0x0 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* ControlBusLicensedAudioMuteOthers; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAudioMetadataModulationSettings) == 0x10, "Size mismatch for FAudioMetadataModulationSettings");
static_assert(offsetof(FAudioMetadataModulationSettings, ControlBusLicensedAudioMuteAll) == 0x0, "Offset mismatch for FAudioMetadataModulationSettings::ControlBusLicensedAudioMuteAll");
static_assert(offsetof(FAudioMetadataModulationSettings, ControlBusLicensedAudioMuteOthers) == 0x8, "Offset mismatch for FAudioMetadataModulationSettings::ControlBusLicensedAudioMuteOthers");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FAudioMetadataSubmixSettings
{
    USoundSubmix* LicensedAudioSubmix; // 0x0 (Size: 0x8, Type: ObjectProperty)
    USoundSubmix* PostPartySubmix; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAudioMetadataSubmixSettings) == 0x10, "Size mismatch for FAudioMetadataSubmixSettings");
static_assert(offsetof(FAudioMetadataSubmixSettings, LicensedAudioSubmix) == 0x0, "Offset mismatch for FAudioMetadataSubmixSettings::LicensedAudioSubmix");
static_assert(offsetof(FAudioMetadataSubmixSettings, PostPartySubmix) == 0x8, "Offset mismatch for FAudioMetadataSubmixSettings::PostPartySubmix");

