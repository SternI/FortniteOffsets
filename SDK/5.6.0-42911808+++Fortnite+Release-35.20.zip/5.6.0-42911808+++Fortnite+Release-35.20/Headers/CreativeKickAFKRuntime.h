/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeKickAFKRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "Engine.h"

// Size: 0x2f0 (Inherited: 0x560, Single: 0xfffffd90)
class UFortCreativeKickAFKComponent : public UFortInputBasedAFKComponent
{
public:
    uint8_t Pad_1d0[0x10]; // 0x1d0 (Size: 0x10, Type: PaddingProperty)
    FDataTableRowHandle AFKTableRowEntry; // 0x1e0 (Size: 0x10, Type: StructProperty)
    FInputBasedAFKDetectionParameters KickAFKDetectionParameters; // 0x1f0 (Size: 0x70, Type: StructProperty)
    uint8_t Pad_260[0x90]; // 0x260 (Size: 0x90, Type: PaddingProperty)
};

static_assert(sizeof(UFortCreativeKickAFKComponent) == 0x2f0, "Size mismatch for UFortCreativeKickAFKComponent");
static_assert(offsetof(UFortCreativeKickAFKComponent, AFKTableRowEntry) == 0x1e0, "Offset mismatch for UFortCreativeKickAFKComponent::AFKTableRowEntry");
static_assert(offsetof(UFortCreativeKickAFKComponent, KickAFKDetectionParameters) == 0x1f0, "Offset mismatch for UFortCreativeKickAFKComponent::KickAFKDetectionParameters");

