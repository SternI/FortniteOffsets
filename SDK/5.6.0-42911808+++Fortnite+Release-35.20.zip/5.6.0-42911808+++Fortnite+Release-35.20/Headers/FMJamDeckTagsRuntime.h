/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamDeckTagsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UJamDeckTagsAsset : public UObject
{
public:
    FGameplayTag PermitJamDeckTag; // 0x28 (Size: 0x4, Type: StructProperty)
    FGameplayTag RestrictJamDeckTag; // 0x2c (Size: 0x4, Type: StructProperty)
    FGameplayTag AlwaysSpawnDecksTag; // 0x30 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UJamDeckTagsAsset) == 0x38, "Size mismatch for UJamDeckTagsAsset");
static_assert(offsetof(UJamDeckTagsAsset, PermitJamDeckTag) == 0x28, "Offset mismatch for UJamDeckTagsAsset::PermitJamDeckTag");
static_assert(offsetof(UJamDeckTagsAsset, RestrictJamDeckTag) == 0x2c, "Offset mismatch for UJamDeckTagsAsset::RestrictJamDeckTag");
static_assert(offsetof(UJamDeckTagsAsset, AlwaysSpawnDecksTag) == 0x30, "Offset mismatch for UJamDeckTagsAsset::AlwaysSpawnDecksTag");

