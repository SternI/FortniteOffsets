/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CommonInput
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "DeveloperSettings.h"
#include "EnhancedInput.h"
#include "InputCore.h"
#include "SlateCore.h"

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UCommonInputActionDomain : public UDataAsset
{
public:
    uint8_t Behavior[0x4]; // 0x30 (Size: 0x4, Type: EnumProperty)
    uint8_t InnerBehavior[0x4]; // 0x34 (Size: 0x4, Type: EnumProperty)
    bool bUseActionDomainDesiredInputConfig; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t InputMode; // 0x39 (Size: 0x1, Type: EnumProperty)
    uint8_t MouseCaptureMode; // 0x3a (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3b[0x5]; // 0x3b (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(UCommonInputActionDomain) == 0x40, "Size mismatch for UCommonInputActionDomain");
static_assert(offsetof(UCommonInputActionDomain, Behavior) == 0x30, "Offset mismatch for UCommonInputActionDomain::Behavior");
static_assert(offsetof(UCommonInputActionDomain, InnerBehavior) == 0x34, "Offset mismatch for UCommonInputActionDomain::InnerBehavior");
static_assert(offsetof(UCommonInputActionDomain, bUseActionDomainDesiredInputConfig) == 0x38, "Offset mismatch for UCommonInputActionDomain::bUseActionDomainDesiredInputConfig");
static_assert(offsetof(UCommonInputActionDomain, InputMode) == 0x39, "Offset mismatch for UCommonInputActionDomain::InputMode");
static_assert(offsetof(UCommonInputActionDomain, MouseCaptureMode) == 0x3a, "Offset mismatch for UCommonInputActionDomain::MouseCaptureMode");

// Size: 0x48 (Inherited: 0x58, Single: 0xfffffff0)
class UCommonInputActionDomainTable : public UDataAsset
{
public:
    TArray<UCommonInputActionDomain*> ActionDomains; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t InputMode; // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t MouseCaptureMode; // 0x41 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_42[0x6]; // 0x42 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UCommonInputActionDomainTable) == 0x48, "Size mismatch for UCommonInputActionDomainTable");
static_assert(offsetof(UCommonInputActionDomainTable, ActionDomains) == 0x30, "Offset mismatch for UCommonInputActionDomainTable::ActionDomains");
static_assert(offsetof(UCommonInputActionDomainTable, InputMode) == 0x40, "Offset mismatch for UCommonInputActionDomainTable::InputMode");
static_assert(offsetof(UCommonInputActionDomainTable, MouseCaptureMode) == 0x41, "Offset mismatch for UCommonInputActionDomainTable::MouseCaptureMode");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UCommonUIInputData : public UObject
{
public:
    FDataTableRowHandle DefaultClickAction; // 0x28 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle DefaultBackAction; // 0x38 (Size: 0x10, Type: StructProperty)
    TSoftClassPtr DefaultHoldData; // 0x48 (Size: 0x20, Type: SoftClassProperty)
    UInputAction* EnhancedInputClickAction; // 0x68 (Size: 0x8, Type: ObjectProperty)
    UInputAction* EnhancedInputBackAction; // 0x70 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UCommonUIInputData) == 0x78, "Size mismatch for UCommonUIInputData");
static_assert(offsetof(UCommonUIInputData, DefaultClickAction) == 0x28, "Offset mismatch for UCommonUIInputData::DefaultClickAction");
static_assert(offsetof(UCommonUIInputData, DefaultBackAction) == 0x38, "Offset mismatch for UCommonUIInputData::DefaultBackAction");
static_assert(offsetof(UCommonUIInputData, DefaultHoldData) == 0x48, "Offset mismatch for UCommonUIInputData::DefaultHoldData");
static_assert(offsetof(UCommonUIInputData, EnhancedInputClickAction) == 0x68, "Offset mismatch for UCommonUIInputData::EnhancedInputClickAction");
static_assert(offsetof(UCommonUIInputData, EnhancedInputBackAction) == 0x70, "Offset mismatch for UCommonUIInputData::EnhancedInputBackAction");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UCommonUIHoldData : public UObject
{
public:
    FInputHoldData KeyboardAndMouse; // 0x28 (Size: 0x8, Type: StructProperty)
    FInputHoldData Gamepad; // 0x30 (Size: 0x8, Type: StructProperty)
    FInputHoldData Touch; // 0x38 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(UCommonUIHoldData) == 0x40, "Size mismatch for UCommonUIHoldData");
static_assert(offsetof(UCommonUIHoldData, KeyboardAndMouse) == 0x28, "Offset mismatch for UCommonUIHoldData::KeyboardAndMouse");
static_assert(offsetof(UCommonUIHoldData, Gamepad) == 0x30, "Offset mismatch for UCommonUIHoldData::Gamepad");
static_assert(offsetof(UCommonUIHoldData, Touch) == 0x38, "Offset mismatch for UCommonUIHoldData::Touch");

// Size: 0xd0 (Inherited: 0x28, Single: 0xa8)
class UCommonInputBaseControllerData : public UObject
{
public:
    uint8_t InputType; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    FName GamepadName; // 0x2c (Size: 0x4, Type: NameProperty)
    FText GamepadDisplayName; // 0x30 (Size: 0x10, Type: TextProperty)
    FText GamepadCategory; // 0x40 (Size: 0x10, Type: TextProperty)
    FText GamepadPlatformName; // 0x50 (Size: 0x10, Type: TextProperty)
    TArray<FInputDeviceIdentifierPair> GamepadHardwareIdMapping; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UTexture2D*> ControllerTexture; // 0x70 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D*> ControllerButtonMaskTexture; // 0x90 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FCommonInputKeyBrushConfiguration> InputBrushDataMap; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<FCommonInputKeySetBrushConfiguration> InputBrushKeySets; // 0xc0 (Size: 0x10, Type: ArrayProperty)

public:
    static TArray<FName> GetRegisteredGamepads(); // 0xb483f1c (Index: 0x0, Flags: Final|Native|Static|Public)
};

static_assert(sizeof(UCommonInputBaseControllerData) == 0xd0, "Size mismatch for UCommonInputBaseControllerData");
static_assert(offsetof(UCommonInputBaseControllerData, InputType) == 0x28, "Offset mismatch for UCommonInputBaseControllerData::InputType");
static_assert(offsetof(UCommonInputBaseControllerData, GamepadName) == 0x2c, "Offset mismatch for UCommonInputBaseControllerData::GamepadName");
static_assert(offsetof(UCommonInputBaseControllerData, GamepadDisplayName) == 0x30, "Offset mismatch for UCommonInputBaseControllerData::GamepadDisplayName");
static_assert(offsetof(UCommonInputBaseControllerData, GamepadCategory) == 0x40, "Offset mismatch for UCommonInputBaseControllerData::GamepadCategory");
static_assert(offsetof(UCommonInputBaseControllerData, GamepadPlatformName) == 0x50, "Offset mismatch for UCommonInputBaseControllerData::GamepadPlatformName");
static_assert(offsetof(UCommonInputBaseControllerData, GamepadHardwareIdMapping) == 0x60, "Offset mismatch for UCommonInputBaseControllerData::GamepadHardwareIdMapping");
static_assert(offsetof(UCommonInputBaseControllerData, ControllerTexture) == 0x70, "Offset mismatch for UCommonInputBaseControllerData::ControllerTexture");
static_assert(offsetof(UCommonInputBaseControllerData, ControllerButtonMaskTexture) == 0x90, "Offset mismatch for UCommonInputBaseControllerData::ControllerButtonMaskTexture");
static_assert(offsetof(UCommonInputBaseControllerData, InputBrushDataMap) == 0xb0, "Offset mismatch for UCommonInputBaseControllerData::InputBrushDataMap");
static_assert(offsetof(UCommonInputBaseControllerData, InputBrushKeySets) == 0xc0, "Offset mismatch for UCommonInputBaseControllerData::InputBrushKeySets");

// Size: 0x70 (Inherited: 0x68, Single: 0x8)
class UCommonInputPlatformSettings : public UPlatformSettings
{
public:
    uint8_t DefaultInputType; // 0x40 (Size: 0x1, Type: EnumProperty)
    bool bSupportsMouseAndKeyboard; // 0x41 (Size: 0x1, Type: BoolProperty)
    bool bSupportsTouch; // 0x42 (Size: 0x1, Type: BoolProperty)
    bool bSupportsGamepad; // 0x43 (Size: 0x1, Type: BoolProperty)
    FName DefaultGamepadName; // 0x44 (Size: 0x4, Type: NameProperty)
    bool bCanChangeGamepadType; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
    TArray<TSoftClassPtr> ControllerData; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ControllerDataClasses; // 0x60 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCommonInputPlatformSettings) == 0x70, "Size mismatch for UCommonInputPlatformSettings");
static_assert(offsetof(UCommonInputPlatformSettings, DefaultInputType) == 0x40, "Offset mismatch for UCommonInputPlatformSettings::DefaultInputType");
static_assert(offsetof(UCommonInputPlatformSettings, bSupportsMouseAndKeyboard) == 0x41, "Offset mismatch for UCommonInputPlatformSettings::bSupportsMouseAndKeyboard");
static_assert(offsetof(UCommonInputPlatformSettings, bSupportsTouch) == 0x42, "Offset mismatch for UCommonInputPlatformSettings::bSupportsTouch");
static_assert(offsetof(UCommonInputPlatformSettings, bSupportsGamepad) == 0x43, "Offset mismatch for UCommonInputPlatformSettings::bSupportsGamepad");
static_assert(offsetof(UCommonInputPlatformSettings, DefaultGamepadName) == 0x44, "Offset mismatch for UCommonInputPlatformSettings::DefaultGamepadName");
static_assert(offsetof(UCommonInputPlatformSettings, bCanChangeGamepadType) == 0x48, "Offset mismatch for UCommonInputPlatformSettings::bCanChangeGamepadType");
static_assert(offsetof(UCommonInputPlatformSettings, ControllerData) == 0x50, "Offset mismatch for UCommonInputPlatformSettings::ControllerData");
static_assert(offsetof(UCommonInputPlatformSettings, ControllerDataClasses) == 0x60, "Offset mismatch for UCommonInputPlatformSettings::ControllerDataClasses");

// Size: 0x158 (Inherited: 0x58, Single: 0x100)
class UCommonInputSettings : public UDeveloperSettings
{
public:
    TSoftClassPtr InputData; // 0x30 (Size: 0x20, Type: SoftClassProperty)
    FPerPlatformSettings PlatformInput; // 0x50 (Size: 0x10, Type: StructProperty)
    TMap<FCommonInputPlatformBaseData, FName> CommonInputPlatformData; // 0x60 (Size: 0x50, Type: MapProperty)
    bool bEnableInputMethodThrashingProtection; // 0xb0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b1[0x3]; // 0xb1 (Size: 0x3, Type: PaddingProperty)
    int32_t InputMethodThrashingLimit; // 0xb4 (Size: 0x4, Type: IntProperty)
    double InputMethodThrashingWindowInSeconds; // 0xb8 (Size: 0x8, Type: DoubleProperty)
    double InputMethodThrashingCooldownInSeconds; // 0xc0 (Size: 0x8, Type: DoubleProperty)
    bool bAllowOutOfFocusDeviceInput; // 0xc8 (Size: 0x1, Type: BoolProperty)
    bool bEnableDefaultInputConfig; // 0xc9 (Size: 0x1, Type: BoolProperty)
    bool bEnableEnhancedInputSupport; // 0xca (Size: 0x1, Type: BoolProperty)
    bool bEnableAutomaticGamepadTypeDetection; // 0xcb (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UCommonInputActionDomainTable*> ActionDomainTable; // 0xd0 (Size: 0x20, Type: SoftObjectProperty)
    TMap<FName, FName> PlatformNameUpgrades; // 0xf0 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_140[0x8]; // 0x140 (Size: 0x8, Type: PaddingProperty)
    UClass* InputDataClass; // 0x148 (Size: 0x8, Type: ClassProperty)
    UCommonInputActionDomainTable* ActionDomainTablePtr; // 0x150 (Size: 0x8, Type: ObjectProperty)

public:
    static bool IsEnhancedInputSupportEnabled(); // 0xb483f48 (Index: 0x0, Flags: Final|Native|Static|Public)
};

static_assert(sizeof(UCommonInputSettings) == 0x158, "Size mismatch for UCommonInputSettings");
static_assert(offsetof(UCommonInputSettings, InputData) == 0x30, "Offset mismatch for UCommonInputSettings::InputData");
static_assert(offsetof(UCommonInputSettings, PlatformInput) == 0x50, "Offset mismatch for UCommonInputSettings::PlatformInput");
static_assert(offsetof(UCommonInputSettings, CommonInputPlatformData) == 0x60, "Offset mismatch for UCommonInputSettings::CommonInputPlatformData");
static_assert(offsetof(UCommonInputSettings, bEnableInputMethodThrashingProtection) == 0xb0, "Offset mismatch for UCommonInputSettings::bEnableInputMethodThrashingProtection");
static_assert(offsetof(UCommonInputSettings, InputMethodThrashingLimit) == 0xb4, "Offset mismatch for UCommonInputSettings::InputMethodThrashingLimit");
static_assert(offsetof(UCommonInputSettings, InputMethodThrashingWindowInSeconds) == 0xb8, "Offset mismatch for UCommonInputSettings::InputMethodThrashingWindowInSeconds");
static_assert(offsetof(UCommonInputSettings, InputMethodThrashingCooldownInSeconds) == 0xc0, "Offset mismatch for UCommonInputSettings::InputMethodThrashingCooldownInSeconds");
static_assert(offsetof(UCommonInputSettings, bAllowOutOfFocusDeviceInput) == 0xc8, "Offset mismatch for UCommonInputSettings::bAllowOutOfFocusDeviceInput");
static_assert(offsetof(UCommonInputSettings, bEnableDefaultInputConfig) == 0xc9, "Offset mismatch for UCommonInputSettings::bEnableDefaultInputConfig");
static_assert(offsetof(UCommonInputSettings, bEnableEnhancedInputSupport) == 0xca, "Offset mismatch for UCommonInputSettings::bEnableEnhancedInputSupport");
static_assert(offsetof(UCommonInputSettings, bEnableAutomaticGamepadTypeDetection) == 0xcb, "Offset mismatch for UCommonInputSettings::bEnableAutomaticGamepadTypeDetection");
static_assert(offsetof(UCommonInputSettings, ActionDomainTable) == 0xd0, "Offset mismatch for UCommonInputSettings::ActionDomainTable");
static_assert(offsetof(UCommonInputSettings, PlatformNameUpgrades) == 0xf0, "Offset mismatch for UCommonInputSettings::PlatformNameUpgrades");
static_assert(offsetof(UCommonInputSettings, InputDataClass) == 0x148, "Offset mismatch for UCommonInputSettings::InputDataClass");
static_assert(offsetof(UCommonInputSettings, ActionDomainTablePtr) == 0x150, "Offset mismatch for UCommonInputSettings::ActionDomainTablePtr");

// Size: 0x100 (Inherited: 0x88, Single: 0x78)
class UCommonInputSubsystem : public ULocalPlayerSubsystem
{
public:
    uint8_t Pad_30[0x38]; // 0x30 (Size: 0x38, Type: PaddingProperty)
    uint8_t OnInputMethodChanged[0x10]; // 0x68 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t NumberOfInputMethodChangesRecently; // 0x78 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
    double LastInputMethodChangeTime; // 0x80 (Size: 0x8, Type: DoubleProperty)
    double LastTimeInputMethodThrashingBegan; // 0x88 (Size: 0x8, Type: DoubleProperty)
    uint8_t RawInputType; // 0x90 (Size: 0x1, Type: EnumProperty)
    uint8_t CurrentInputType; // 0x91 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_92[0x2]; // 0x92 (Size: 0x2, Type: PaddingProperty)
    FName GamepadInputType; // 0x94 (Size: 0x4, Type: NameProperty)
    TMap<ECommonInputType, FName> CurrentInputLocks; // 0x98 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_e8[0x8]; // 0xe8 (Size: 0x8, Type: PaddingProperty)
    UCommonInputActionDomainTable* ActionDomainTable; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    bool bIsGamepadSimulatedClick; // 0xf8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f9[0x7]; // 0xf9 (Size: 0x7, Type: PaddingProperty)

public:
    FName GetCurrentGamepadName() const; // 0xb483edc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ECommonInputType GetCurrentInputType() const; // 0x4e15984 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ECommonInputType GetDefaultInputType() const; // 0xb483ef4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsInputMethodActive(ECommonInputType& InputMethod) const; // 0xb483f6c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsUsingPointerInput() const; // 0xb4840a4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetCurrentInputType(ECommonInputType& NewInputType); // 0xb4840d4 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void SetGamepadInputType(FName& const InGamepadInputType); // 0xb484200 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    bool ShouldShowInputKeys() const; // 0xb484328 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void BroadcastInputMethodChanged(); // 0xb483ec8 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UCommonInputSubsystem) == 0x100, "Size mismatch for UCommonInputSubsystem");
static_assert(offsetof(UCommonInputSubsystem, OnInputMethodChanged) == 0x68, "Offset mismatch for UCommonInputSubsystem::OnInputMethodChanged");
static_assert(offsetof(UCommonInputSubsystem, NumberOfInputMethodChangesRecently) == 0x78, "Offset mismatch for UCommonInputSubsystem::NumberOfInputMethodChangesRecently");
static_assert(offsetof(UCommonInputSubsystem, LastInputMethodChangeTime) == 0x80, "Offset mismatch for UCommonInputSubsystem::LastInputMethodChangeTime");
static_assert(offsetof(UCommonInputSubsystem, LastTimeInputMethodThrashingBegan) == 0x88, "Offset mismatch for UCommonInputSubsystem::LastTimeInputMethodThrashingBegan");
static_assert(offsetof(UCommonInputSubsystem, RawInputType) == 0x90, "Offset mismatch for UCommonInputSubsystem::RawInputType");
static_assert(offsetof(UCommonInputSubsystem, CurrentInputType) == 0x91, "Offset mismatch for UCommonInputSubsystem::CurrentInputType");
static_assert(offsetof(UCommonInputSubsystem, GamepadInputType) == 0x94, "Offset mismatch for UCommonInputSubsystem::GamepadInputType");
static_assert(offsetof(UCommonInputSubsystem, CurrentInputLocks) == 0x98, "Offset mismatch for UCommonInputSubsystem::CurrentInputLocks");
static_assert(offsetof(UCommonInputSubsystem, ActionDomainTable) == 0xf0, "Offset mismatch for UCommonInputSubsystem::ActionDomainTable");
static_assert(offsetof(UCommonInputSubsystem, bIsGamepadSimulatedClick) == 0xf8, "Offset mismatch for UCommonInputSubsystem::bIsGamepadSimulatedClick");

// Size: 0xd0 (Inherited: 0x0, Single: 0xd0)
struct FCommonInputKeyBrushConfiguration
{
    FKey Key; // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush KeyBrush; // 0x20 (Size: 0xb0, Type: StructProperty)
};

static_assert(sizeof(FCommonInputKeyBrushConfiguration) == 0xd0, "Size mismatch for FCommonInputKeyBrushConfiguration");
static_assert(offsetof(FCommonInputKeyBrushConfiguration, Key) == 0x0, "Offset mismatch for FCommonInputKeyBrushConfiguration::Key");
static_assert(offsetof(FCommonInputKeyBrushConfiguration, KeyBrush) == 0x20, "Offset mismatch for FCommonInputKeyBrushConfiguration::KeyBrush");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FCommonInputKeySetBrushConfiguration
{
    TArray<FKey> Keys; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FSlateBrush KeyBrush; // 0x10 (Size: 0xb0, Type: StructProperty)
};

static_assert(sizeof(FCommonInputKeySetBrushConfiguration) == 0xc0, "Size mismatch for FCommonInputKeySetBrushConfiguration");
static_assert(offsetof(FCommonInputKeySetBrushConfiguration, Keys) == 0x0, "Offset mismatch for FCommonInputKeySetBrushConfiguration::Keys");
static_assert(offsetof(FCommonInputKeySetBrushConfiguration, KeyBrush) == 0x10, "Offset mismatch for FCommonInputKeySetBrushConfiguration::KeyBrush");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FInputDeviceIdentifierPair
{
    FName InputDeviceName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FString HardwareDeviceIdentifier; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FInputDeviceIdentifierPair) == 0x18, "Size mismatch for FInputDeviceIdentifierPair");
static_assert(offsetof(FInputDeviceIdentifierPair, InputDeviceName) == 0x0, "Offset mismatch for FInputDeviceIdentifierPair::InputDeviceName");
static_assert(offsetof(FInputDeviceIdentifierPair, HardwareDeviceIdentifier) == 0x8, "Offset mismatch for FInputDeviceIdentifierPair::HardwareDeviceIdentifier");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FInputHoldData
{
    float HoldTime; // 0x0 (Size: 0x4, Type: FloatProperty)
    float HoldRollbackTime; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FInputHoldData) == 0x8, "Size mismatch for FInputHoldData");
static_assert(offsetof(FInputHoldData, HoldTime) == 0x0, "Offset mismatch for FInputHoldData::HoldTime");
static_assert(offsetof(FInputHoldData, HoldRollbackTime) == 0x4, "Offset mismatch for FInputHoldData::HoldRollbackTime");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FCommonInputPlatformBaseData
{
    uint8_t DefaultInputType; // 0x8 (Size: 0x1, Type: EnumProperty)
    bool bSupportsMouseAndKeyboard; // 0x9 (Size: 0x1, Type: BoolProperty)
    bool bSupportsGamepad; // 0xa (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b[0x1]; // 0xb (Size: 0x1, Type: PaddingProperty)
    FName DefaultGamepadName; // 0xc (Size: 0x4, Type: NameProperty)
    bool bCanChangeGamepadType; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bSupportsTouch; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
    TArray<TSoftClassPtr> ControllerData; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ControllerDataClasses; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCommonInputPlatformBaseData) == 0x38, "Size mismatch for FCommonInputPlatformBaseData");
static_assert(offsetof(FCommonInputPlatformBaseData, DefaultInputType) == 0x8, "Offset mismatch for FCommonInputPlatformBaseData::DefaultInputType");
static_assert(offsetof(FCommonInputPlatformBaseData, bSupportsMouseAndKeyboard) == 0x9, "Offset mismatch for FCommonInputPlatformBaseData::bSupportsMouseAndKeyboard");
static_assert(offsetof(FCommonInputPlatformBaseData, bSupportsGamepad) == 0xa, "Offset mismatch for FCommonInputPlatformBaseData::bSupportsGamepad");
static_assert(offsetof(FCommonInputPlatformBaseData, DefaultGamepadName) == 0xc, "Offset mismatch for FCommonInputPlatformBaseData::DefaultGamepadName");
static_assert(offsetof(FCommonInputPlatformBaseData, bCanChangeGamepadType) == 0x10, "Offset mismatch for FCommonInputPlatformBaseData::bCanChangeGamepadType");
static_assert(offsetof(FCommonInputPlatformBaseData, bSupportsTouch) == 0x11, "Offset mismatch for FCommonInputPlatformBaseData::bSupportsTouch");
static_assert(offsetof(FCommonInputPlatformBaseData, ControllerData) == 0x18, "Offset mismatch for FCommonInputPlatformBaseData::ControllerData");
static_assert(offsetof(FCommonInputPlatformBaseData, ControllerDataClasses) == 0x28, "Offset mismatch for FCommonInputPlatformBaseData::ControllerDataClasses");

