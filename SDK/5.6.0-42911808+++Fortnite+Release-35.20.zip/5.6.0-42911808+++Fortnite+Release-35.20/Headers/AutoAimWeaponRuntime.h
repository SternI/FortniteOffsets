/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AutoAimWeaponRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAutoAimWeaponKismetLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool DoesAutoAimWeaponHaveLineOfSight(AFortPawn*& SourcePawn, AFortPawn*& TargetPawn); // 0xfe4238c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool DoesAutoAimWeaponReticleIntersectTarget(float& OutReticleDistance, AFortPawn*& SourcePawn, AFortPawn*& TargetPawn, float& const ReticleSize); // 0xfe425a4 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void FindBestAutoAimTarget(AFortPawn*& OutTargetPawn, float& OutReticleDistance, AFortPlayerPawn*& SourcePawn, float& const ReticleSize, float& const Range); // 0xfe42830 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UAutoAimWeaponPawnComponent* GetAutoAimWeaponPawnComponent(AFortPawn*& SourcePawn); // 0xfe42c6c (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAutoAimWeaponKismetLibrary) == 0x28, "Size mismatch for UAutoAimWeaponKismetLibrary");

// Size: 0x1a0 (Inherited: 0x310, Single: 0xfffffe90)
class UAutoAimWeaponPawnComponent : public UFortPawnComponent
{
public:
    FGameplayTagContainer UseSingleLocationTargetingPawnTags; // 0xc0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer LowPriorityTargetPawnTags; // 0xe0 (Size: 0x20, Type: StructProperty)
    TArray<FAutoAimWeaponBoneSegmentData> MultiSocketTargetingBoneSegmentDatas; // 0x100 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat LockOnTimeReticleCenter; // 0x110 (Size: 0x28, Type: StructProperty)
    FScalableFloat LockOnTimeReticleEdge; // 0x138 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxLockOns; // 0x160 (Size: 0x28, Type: StructProperty)
    TEnumAsByte<ETraceTypeQuery> LineOfSightTraceChannel; // 0x188 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_189[0x3]; // 0x189 (Size: 0x3, Type: PaddingProperty)
    float ProgressTowardNextLockOn; // 0x18c (Size: 0x4, Type: FloatProperty)
    int32_t CurrentLockOnCount; // 0x190 (Size: 0x4, Type: IntProperty)
    float TargetToReticleDistanceNormalized; // 0x194 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<AFortPawn*> LockOnTarget; // 0x198 (Size: 0x8, Type: WeakObjectProperty)

public:
    int32_t GetCurrentLockOnCount() const; // 0xdf72044 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetLockOnProgress() const; // 0xfe42f68 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetLockOnTargetLocation(FVector& OutLockTargetLocation) const; // 0xfe42f90 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|Const)
    float GetTargetToReticleDistanceNormalized() const; // 0xfe4307c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UAutoAimWeaponPawnComponent) == 0x1a0, "Size mismatch for UAutoAimWeaponPawnComponent");
static_assert(offsetof(UAutoAimWeaponPawnComponent, UseSingleLocationTargetingPawnTags) == 0xc0, "Offset mismatch for UAutoAimWeaponPawnComponent::UseSingleLocationTargetingPawnTags");
static_assert(offsetof(UAutoAimWeaponPawnComponent, LowPriorityTargetPawnTags) == 0xe0, "Offset mismatch for UAutoAimWeaponPawnComponent::LowPriorityTargetPawnTags");
static_assert(offsetof(UAutoAimWeaponPawnComponent, MultiSocketTargetingBoneSegmentDatas) == 0x100, "Offset mismatch for UAutoAimWeaponPawnComponent::MultiSocketTargetingBoneSegmentDatas");
static_assert(offsetof(UAutoAimWeaponPawnComponent, LockOnTimeReticleCenter) == 0x110, "Offset mismatch for UAutoAimWeaponPawnComponent::LockOnTimeReticleCenter");
static_assert(offsetof(UAutoAimWeaponPawnComponent, LockOnTimeReticleEdge) == 0x138, "Offset mismatch for UAutoAimWeaponPawnComponent::LockOnTimeReticleEdge");
static_assert(offsetof(UAutoAimWeaponPawnComponent, MaxLockOns) == 0x160, "Offset mismatch for UAutoAimWeaponPawnComponent::MaxLockOns");
static_assert(offsetof(UAutoAimWeaponPawnComponent, LineOfSightTraceChannel) == 0x188, "Offset mismatch for UAutoAimWeaponPawnComponent::LineOfSightTraceChannel");
static_assert(offsetof(UAutoAimWeaponPawnComponent, ProgressTowardNextLockOn) == 0x18c, "Offset mismatch for UAutoAimWeaponPawnComponent::ProgressTowardNextLockOn");
static_assert(offsetof(UAutoAimWeaponPawnComponent, CurrentLockOnCount) == 0x190, "Offset mismatch for UAutoAimWeaponPawnComponent::CurrentLockOnCount");
static_assert(offsetof(UAutoAimWeaponPawnComponent, TargetToReticleDistanceNormalized) == 0x194, "Offset mismatch for UAutoAimWeaponPawnComponent::TargetToReticleDistanceNormalized");
static_assert(offsetof(UAutoAimWeaponPawnComponent, LockOnTarget) == 0x198, "Offset mismatch for UAutoAimWeaponPawnComponent::LockOnTarget");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FAutoAimWeaponBoneSegmentData
{
    FName BoneName1; // 0x0 (Size: 0x4, Type: NameProperty)
    FName BoneName2; // 0x4 (Size: 0x4, Type: NameProperty)
    float BoneCollisionCapsuleRadiusAproximation; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FAutoAimWeaponBoneSegmentData) == 0xc, "Size mismatch for FAutoAimWeaponBoneSegmentData");
static_assert(offsetof(FAutoAimWeaponBoneSegmentData, BoneName1) == 0x0, "Offset mismatch for FAutoAimWeaponBoneSegmentData::BoneName1");
static_assert(offsetof(FAutoAimWeaponBoneSegmentData, BoneName2) == 0x4, "Offset mismatch for FAutoAimWeaponBoneSegmentData::BoneName2");
static_assert(offsetof(FAutoAimWeaponBoneSegmentData, BoneCollisionCapsuleRadiusAproximation) == 0x8, "Offset mismatch for FAutoAimWeaponBoneSegmentData::BoneCollisionCapsuleRadiusAproximation");

