/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AndroidPermission
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UAndroidPermissionCallbackProxy : public UObject
{
public:
    uint8_t OnPermissionsGrantedDynamicDelegate[0x10]; // 0x28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_38[0x18]; // 0x38 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UAndroidPermissionCallbackProxy) == 0x50, "Size mismatch for UAndroidPermissionCallbackProxy");
static_assert(offsetof(UAndroidPermissionCallbackProxy, OnPermissionsGrantedDynamicDelegate) == 0x28, "Offset mismatch for UAndroidPermissionCallbackProxy::OnPermissionsGrantedDynamicDelegate");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAndroidPermissionFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static UAndroidPermissionCallbackProxy* AcquirePermissions(const TArray<FString> Permissions); // 0x1296d0a0 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool CheckPermission(FString& Permission); // 0x1296d17c (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAndroidPermissionFunctionLibrary) == 0x28, "Size mismatch for UAndroidPermissionFunctionLibrary");

