/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosSolverEngine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "DeveloperSettings.h"
#include "DataflowSimulation.h"
#include "ChaosVDRuntime.h"
#include "Chaos.h"

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UChaosDebugDrawSubsystem : public UWorldSubsystem
{
public:
};

static_assert(sizeof(UChaosDebugDrawSubsystem) == 0x30, "Size mismatch for UChaosDebugDrawSubsystem");

// Size: 0xc0 (Inherited: 0xe0, Single: 0xffffffe0)
class UChaosDebugDrawComponent : public UActorComponent
{
public:
};

static_assert(sizeof(UChaosDebugDrawComponent) == 0xc0, "Size mismatch for UChaosDebugDrawComponent");

// Size: 0xc0 (Inherited: 0xe0, Single: 0xffffffe0)
class UChaosEventListenerComponent : public UActorComponent
{
public:
};

static_assert(sizeof(UChaosEventListenerComponent) == 0xc0, "Size mismatch for UChaosEventListenerComponent");

// Size: 0x2d0 (Inherited: 0x1a0, Single: 0x130)
class UChaosGameplayEventDispatcher : public UChaosEventListenerComponent
{
public:
    uint8_t Pad_c0[0xc0]; // 0xc0 (Size: 0xc0, Type: PaddingProperty)
    TMap<FChaosHandlerSet, UPrimitiveComponent*> CollisionEventRegistrations; // 0x180 (Size: 0x50, Type: MapProperty)
    TMap<FBreakEventCallbackWrapper, UPrimitiveComponent*> BreakEventRegistrations; // 0x1d0 (Size: 0x50, Type: MapProperty)
    TMap<FRemovalEventCallbackWrapper, UPrimitiveComponent*> RemovalEventRegistrations; // 0x220 (Size: 0x50, Type: MapProperty)
    TMap<FCrumblingEventCallbackWrapper, UPrimitiveComponent*> CrumblingEventRegistrations; // 0x270 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_2c0[0x10]; // 0x2c0 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UChaosGameplayEventDispatcher) == 0x2d0, "Size mismatch for UChaosGameplayEventDispatcher");
static_assert(offsetof(UChaosGameplayEventDispatcher, CollisionEventRegistrations) == 0x180, "Offset mismatch for UChaosGameplayEventDispatcher::CollisionEventRegistrations");
static_assert(offsetof(UChaosGameplayEventDispatcher, BreakEventRegistrations) == 0x1d0, "Offset mismatch for UChaosGameplayEventDispatcher::BreakEventRegistrations");
static_assert(offsetof(UChaosGameplayEventDispatcher, RemovalEventRegistrations) == 0x220, "Offset mismatch for UChaosGameplayEventDispatcher::RemovalEventRegistrations");
static_assert(offsetof(UChaosGameplayEventDispatcher, CrumblingEventRegistrations) == 0x270, "Offset mismatch for UChaosGameplayEventDispatcher::CrumblingEventRegistrations");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChaosNotifyHandlerInterface : public UInterface
{
public:
};

static_assert(sizeof(UChaosNotifyHandlerInterface) == 0x28, "Size mismatch for UChaosNotifyHandlerInterface");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChaosSolverEngineBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FHitResult ConvertPhysicsCollisionToHitResult(const FChaosPhysicsCollisionInfo PhysicsCollision); // 0x9f0eee4 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UChaosSolverEngineBlueprintLibrary) == 0x28, "Size mismatch for UChaosSolverEngineBlueprintLibrary");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UChaosSolver : public UObject
{
public:
};

static_assert(sizeof(UChaosSolver) == 0x28, "Size mismatch for UChaosSolver");

// Size: 0x490 (Inherited: 0x2d0, Single: 0x1c0)
class AChaosSolverActor : public AActor
{
public:
    uint8_t Pad_2a8[0x8]; // 0x2a8 (Size: 0x8, Type: PaddingProperty)
    FChaosSolverConfiguration Properties; // 0x2b0 (Size: 0x6c, Type: StructProperty)
    float TimeStepMultiplier; // 0x31c (Size: 0x4, Type: FloatProperty)
    int32_t CollisionIterations; // 0x320 (Size: 0x4, Type: IntProperty)
    int32_t PushOutIterations; // 0x324 (Size: 0x4, Type: IntProperty)
    int32_t PushOutPairIterations; // 0x328 (Size: 0x4, Type: IntProperty)
    float ClusterConnectionFactor; // 0x32c (Size: 0x4, Type: FloatProperty)
    uint8_t ClusterUnionConnectionType; // 0x330 (Size: 0x1, Type: EnumProperty)
    bool DoGenerateCollisionData; // 0x331 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_332[0x2]; // 0x332 (Size: 0x2, Type: PaddingProperty)
    FSolverCollisionFilterSettings CollisionFilterSettings; // 0x334 (Size: 0x10, Type: StructProperty)
    bool DoGenerateBreakingData; // 0x344 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_345[0x3]; // 0x345 (Size: 0x3, Type: PaddingProperty)
    FSolverBreakingFilterSettings BreakingFilterSettings; // 0x348 (Size: 0x10, Type: StructProperty)
    bool DoGenerateTrailingData; // 0x358 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_359[0x3]; // 0x359 (Size: 0x3, Type: PaddingProperty)
    FSolverTrailingFilterSettings TrailingFilterSettings; // 0x35c (Size: 0x10, Type: StructProperty)
    float MassScale; // 0x36c (Size: 0x4, Type: FloatProperty)
    bool bHasFloor; // 0x370 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_371[0x3]; // 0x371 (Size: 0x3, Type: PaddingProperty)
    float FloorHeight; // 0x374 (Size: 0x4, Type: FloatProperty)
    FChaosDebugSubstepControl ChaosDebugSubstepControl; // 0x378 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_37b[0x5]; // 0x37b (Size: 0x5, Type: PaddingProperty)
    UBillboardComponent* SpriteComponent; // 0x380 (Size: 0x8, Type: ObjectProperty)
    FDataflowSimulationAsset SimulationAsset; // 0x388 (Size: 0x58, Type: StructProperty)
    uint8_t Pad_3e0[0xa0]; // 0x3e0 (Size: 0xa0, Type: PaddingProperty)
    UChaosGameplayEventDispatcher* GameplayEventDispatcherComponent; // 0x480 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_488[0x8]; // 0x488 (Size: 0x8, Type: PaddingProperty)

public:
    void SetAsCurrentWorldSolver(); // 0x9f0f04c (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSolverActive(bool& bActive); // 0x9f0f060 (Index: 0x1, Flags: RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(AChaosSolverActor) == 0x490, "Size mismatch for AChaosSolverActor");
static_assert(offsetof(AChaosSolverActor, Properties) == 0x2b0, "Offset mismatch for AChaosSolverActor::Properties");
static_assert(offsetof(AChaosSolverActor, TimeStepMultiplier) == 0x31c, "Offset mismatch for AChaosSolverActor::TimeStepMultiplier");
static_assert(offsetof(AChaosSolverActor, CollisionIterations) == 0x320, "Offset mismatch for AChaosSolverActor::CollisionIterations");
static_assert(offsetof(AChaosSolverActor, PushOutIterations) == 0x324, "Offset mismatch for AChaosSolverActor::PushOutIterations");
static_assert(offsetof(AChaosSolverActor, PushOutPairIterations) == 0x328, "Offset mismatch for AChaosSolverActor::PushOutPairIterations");
static_assert(offsetof(AChaosSolverActor, ClusterConnectionFactor) == 0x32c, "Offset mismatch for AChaosSolverActor::ClusterConnectionFactor");
static_assert(offsetof(AChaosSolverActor, ClusterUnionConnectionType) == 0x330, "Offset mismatch for AChaosSolverActor::ClusterUnionConnectionType");
static_assert(offsetof(AChaosSolverActor, DoGenerateCollisionData) == 0x331, "Offset mismatch for AChaosSolverActor::DoGenerateCollisionData");
static_assert(offsetof(AChaosSolverActor, CollisionFilterSettings) == 0x334, "Offset mismatch for AChaosSolverActor::CollisionFilterSettings");
static_assert(offsetof(AChaosSolverActor, DoGenerateBreakingData) == 0x344, "Offset mismatch for AChaosSolverActor::DoGenerateBreakingData");
static_assert(offsetof(AChaosSolverActor, BreakingFilterSettings) == 0x348, "Offset mismatch for AChaosSolverActor::BreakingFilterSettings");
static_assert(offsetof(AChaosSolverActor, DoGenerateTrailingData) == 0x358, "Offset mismatch for AChaosSolverActor::DoGenerateTrailingData");
static_assert(offsetof(AChaosSolverActor, TrailingFilterSettings) == 0x35c, "Offset mismatch for AChaosSolverActor::TrailingFilterSettings");
static_assert(offsetof(AChaosSolverActor, MassScale) == 0x36c, "Offset mismatch for AChaosSolverActor::MassScale");
static_assert(offsetof(AChaosSolverActor, bHasFloor) == 0x370, "Offset mismatch for AChaosSolverActor::bHasFloor");
static_assert(offsetof(AChaosSolverActor, FloorHeight) == 0x374, "Offset mismatch for AChaosSolverActor::FloorHeight");
static_assert(offsetof(AChaosSolverActor, ChaosDebugSubstepControl) == 0x378, "Offset mismatch for AChaosSolverActor::ChaosDebugSubstepControl");
static_assert(offsetof(AChaosSolverActor, SpriteComponent) == 0x380, "Offset mismatch for AChaosSolverActor::SpriteComponent");
static_assert(offsetof(AChaosSolverActor, SimulationAsset) == 0x388, "Offset mismatch for AChaosSolverActor::SimulationAsset");
static_assert(offsetof(AChaosSolverActor, GameplayEventDispatcherComponent) == 0x480, "Offset mismatch for AChaosSolverActor::GameplayEventDispatcherComponent");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UChaosSolverSettings : public UDeveloperSettings
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    FSoftClassPath DefaultChaosSolverActorClass; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UChaosSolverSettings) == 0x50, "Size mismatch for UChaosSolverSettings");
static_assert(offsetof(UChaosSolverSettings, DefaultChaosSolverActorClass) == 0x38, "Offset mismatch for UChaosSolverSettings::DefaultChaosSolverActorClass");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FChaosPhysicsCollisionInfo
{
    UPrimitiveComponent* Component; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* OtherComponent; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector Location; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector Normal; // 0x28 (Size: 0x18, Type: StructProperty)
    FVector AccumulatedImpulse; // 0x40 (Size: 0x18, Type: StructProperty)
    FVector Velocity; // 0x58 (Size: 0x18, Type: StructProperty)
    FVector OtherVelocity; // 0x70 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity; // 0x88 (Size: 0x18, Type: StructProperty)
    FVector OtherAngularVelocity; // 0xa0 (Size: 0x18, Type: StructProperty)
    float Mass; // 0xb8 (Size: 0x4, Type: FloatProperty)
    float OtherMass; // 0xbc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FChaosPhysicsCollisionInfo) == 0xc0, "Size mismatch for FChaosPhysicsCollisionInfo");
static_assert(offsetof(FChaosPhysicsCollisionInfo, Component) == 0x0, "Offset mismatch for FChaosPhysicsCollisionInfo::Component");
static_assert(offsetof(FChaosPhysicsCollisionInfo, OtherComponent) == 0x8, "Offset mismatch for FChaosPhysicsCollisionInfo::OtherComponent");
static_assert(offsetof(FChaosPhysicsCollisionInfo, Location) == 0x10, "Offset mismatch for FChaosPhysicsCollisionInfo::Location");
static_assert(offsetof(FChaosPhysicsCollisionInfo, Normal) == 0x28, "Offset mismatch for FChaosPhysicsCollisionInfo::Normal");
static_assert(offsetof(FChaosPhysicsCollisionInfo, AccumulatedImpulse) == 0x40, "Offset mismatch for FChaosPhysicsCollisionInfo::AccumulatedImpulse");
static_assert(offsetof(FChaosPhysicsCollisionInfo, Velocity) == 0x58, "Offset mismatch for FChaosPhysicsCollisionInfo::Velocity");
static_assert(offsetof(FChaosPhysicsCollisionInfo, OtherVelocity) == 0x70, "Offset mismatch for FChaosPhysicsCollisionInfo::OtherVelocity");
static_assert(offsetof(FChaosPhysicsCollisionInfo, AngularVelocity) == 0x88, "Offset mismatch for FChaosPhysicsCollisionInfo::AngularVelocity");
static_assert(offsetof(FChaosPhysicsCollisionInfo, OtherAngularVelocity) == 0xa0, "Offset mismatch for FChaosPhysicsCollisionInfo::OtherAngularVelocity");
static_assert(offsetof(FChaosPhysicsCollisionInfo, Mass) == 0xb8, "Offset mismatch for FChaosPhysicsCollisionInfo::Mass");
static_assert(offsetof(FChaosPhysicsCollisionInfo, OtherMass) == 0xbc, "Offset mismatch for FChaosPhysicsCollisionInfo::OtherMass");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FChaosVDSessionPing
{
    FGuid ControllerInstanceId; // 0x0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FChaosVDSessionPing) == 0x10, "Size mismatch for FChaosVDSessionPing");
static_assert(offsetof(FChaosVDSessionPing, ControllerInstanceId) == 0x0, "Offset mismatch for FChaosVDSessionPing::ControllerInstanceId");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FChaosVDSessionPong
{
    FGuid InstanceID; // 0x0 (Size: 0x10, Type: StructProperty)
    FGuid SessionId; // 0x10 (Size: 0x10, Type: StructProperty)
    FString SessionName; // 0x20 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FChaosVDSessionPong) == 0x30, "Size mismatch for FChaosVDSessionPong");
static_assert(offsetof(FChaosVDSessionPong, InstanceID) == 0x0, "Offset mismatch for FChaosVDSessionPong::InstanceID");
static_assert(offsetof(FChaosVDSessionPong, SessionId) == 0x10, "Offset mismatch for FChaosVDSessionPong::SessionId");
static_assert(offsetof(FChaosVDSessionPong, SessionName) == 0x20, "Offset mismatch for FChaosVDSessionPong::SessionName");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FChaosVDStartRecordingCommandMessage
{
    uint8_t RecordingMode; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FString Target; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FChaosVDStartRecordingCommandMessage) == 0x18, "Size mismatch for FChaosVDStartRecordingCommandMessage");
static_assert(offsetof(FChaosVDStartRecordingCommandMessage, RecordingMode) == 0x0, "Offset mismatch for FChaosVDStartRecordingCommandMessage::RecordingMode");
static_assert(offsetof(FChaosVDStartRecordingCommandMessage, Target) == 0x8, "Offset mismatch for FChaosVDStartRecordingCommandMessage::Target");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FChaosVDStopRecordingCommandMessage
{
};

static_assert(sizeof(FChaosVDStopRecordingCommandMessage) == 0x1, "Size mismatch for FChaosVDStopRecordingCommandMessage");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FChaosVDRecordingStatusMessage
{
    FGuid InstanceID; // 0x0 (Size: 0x10, Type: StructProperty)
    bool bIsRecording; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float ElapsedTime; // 0x14 (Size: 0x4, Type: FloatProperty)
    FChaosVDTraceDetails TraceDetails; // 0x18 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FChaosVDRecordingStatusMessage) == 0x50, "Size mismatch for FChaosVDRecordingStatusMessage");
static_assert(offsetof(FChaosVDRecordingStatusMessage, InstanceID) == 0x0, "Offset mismatch for FChaosVDRecordingStatusMessage::InstanceID");
static_assert(offsetof(FChaosVDRecordingStatusMessage, bIsRecording) == 0x10, "Offset mismatch for FChaosVDRecordingStatusMessage::bIsRecording");
static_assert(offsetof(FChaosVDRecordingStatusMessage, ElapsedTime) == 0x14, "Offset mismatch for FChaosVDRecordingStatusMessage::ElapsedTime");
static_assert(offsetof(FChaosVDRecordingStatusMessage, TraceDetails) == 0x18, "Offset mismatch for FChaosVDRecordingStatusMessage::TraceDetails");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FChaosVDDataChannelState
{
    FString ChannelName; // 0x0 (Size: 0x10, Type: StrProperty)
    bool bIsEnabled; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bCanChangeChannelState; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDDataChannelState) == 0x18, "Size mismatch for FChaosVDDataChannelState");
static_assert(offsetof(FChaosVDDataChannelState, ChannelName) == 0x0, "Offset mismatch for FChaosVDDataChannelState::ChannelName");
static_assert(offsetof(FChaosVDDataChannelState, bIsEnabled) == 0x10, "Offset mismatch for FChaosVDDataChannelState::bIsEnabled");
static_assert(offsetof(FChaosVDDataChannelState, bCanChangeChannelState) == 0x11, "Offset mismatch for FChaosVDDataChannelState::bCanChangeChannelState");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FChaosVDChannelStateChangeCommandMessage
{
    FChaosVDDataChannelState NewState; // 0x0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FChaosVDChannelStateChangeCommandMessage) == 0x18, "Size mismatch for FChaosVDChannelStateChangeCommandMessage");
static_assert(offsetof(FChaosVDChannelStateChangeCommandMessage, NewState) == 0x0, "Offset mismatch for FChaosVDChannelStateChangeCommandMessage::NewState");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FChaosVDChannelStateChangeResponseMessage
{
    FGuid InstanceID; // 0x0 (Size: 0x10, Type: StructProperty)
    FChaosVDDataChannelState NewState; // 0x10 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FChaosVDChannelStateChangeResponseMessage) == 0x28, "Size mismatch for FChaosVDChannelStateChangeResponseMessage");
static_assert(offsetof(FChaosVDChannelStateChangeResponseMessage, InstanceID) == 0x0, "Offset mismatch for FChaosVDChannelStateChangeResponseMessage::InstanceID");
static_assert(offsetof(FChaosVDChannelStateChangeResponseMessage, NewState) == 0x10, "Offset mismatch for FChaosVDChannelStateChangeResponseMessage::NewState");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FChaosVDFullSessionInfoRequestMessage
{
};

static_assert(sizeof(FChaosVDFullSessionInfoRequestMessage) == 0x1, "Size mismatch for FChaosVDFullSessionInfoRequestMessage");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FChaosVDFullSessionInfoResponseMessage
{
    FGuid InstanceID; // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<FChaosVDDataChannelState> DataChannelsStates; // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bIsRecording; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FChaosVDFullSessionInfoResponseMessage) == 0x28, "Size mismatch for FChaosVDFullSessionInfoResponseMessage");
static_assert(offsetof(FChaosVDFullSessionInfoResponseMessage, InstanceID) == 0x0, "Offset mismatch for FChaosVDFullSessionInfoResponseMessage::InstanceID");
static_assert(offsetof(FChaosVDFullSessionInfoResponseMessage, DataChannelsStates) == 0x10, "Offset mismatch for FChaosVDFullSessionInfoResponseMessage::DataChannelsStates");
static_assert(offsetof(FChaosVDFullSessionInfoResponseMessage, bIsRecording) == 0x20, "Offset mismatch for FChaosVDFullSessionInfoResponseMessage::bIsRecording");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FBreakEventCallbackWrapper
{
};

static_assert(sizeof(FBreakEventCallbackWrapper) == 0x30, "Size mismatch for FBreakEventCallbackWrapper");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FRemovalEventCallbackWrapper
{
};

static_assert(sizeof(FRemovalEventCallbackWrapper) == 0x30, "Size mismatch for FRemovalEventCallbackWrapper");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FCrumblingEventCallbackWrapper
{
};

static_assert(sizeof(FCrumblingEventCallbackWrapper) == 0x30, "Size mismatch for FCrumblingEventCallbackWrapper");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FChaosHandlerSet
{
    TSet<UObject*> ChaosHandlers; // 0x8 (Size: 0x50, Type: SetProperty)
};

static_assert(sizeof(FChaosHandlerSet) == 0x58, "Size mismatch for FChaosHandlerSet");
static_assert(offsetof(FChaosHandlerSet, ChaosHandlers) == 0x8, "Offset mismatch for FChaosHandlerSet::ChaosHandlers");

// Size: 0x3 (Inherited: 0x0, Single: 0x3)
struct FChaosDebugSubstepControl
{
    bool bPause; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bSubstep; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bStep; // 0x2 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FChaosDebugSubstepControl) == 0x3, "Size mismatch for FChaosDebugSubstepControl");
static_assert(offsetof(FChaosDebugSubstepControl, bPause) == 0x0, "Offset mismatch for FChaosDebugSubstepControl::bPause");
static_assert(offsetof(FChaosDebugSubstepControl, bSubstep) == 0x1, "Offset mismatch for FChaosDebugSubstepControl::bSubstep");
static_assert(offsetof(FChaosDebugSubstepControl, bStep) == 0x2, "Offset mismatch for FChaosDebugSubstepControl::bStep");

// Size: 0x90 (Inherited: 0xf0, Single: 0xffffffa0)
struct FDataflowRigidSolverProxy : FDataflowPhysicsSolverProxy
{
};

static_assert(sizeof(FDataflowRigidSolverProxy) == 0x90, "Size mismatch for FDataflowRigidSolverProxy");

