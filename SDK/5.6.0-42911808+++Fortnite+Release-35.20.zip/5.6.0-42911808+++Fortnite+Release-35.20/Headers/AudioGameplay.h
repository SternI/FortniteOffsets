/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioGameplay
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "AudioExtensions.h"

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UAudioAssetUserData : public UAssetUserData
{
public:
    FGameplayTagContainer MetadataTags; // 0x28 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UAudioAssetUserData) == 0x48, "Size mismatch for UAudioAssetUserData");
static_assert(offsetof(UAudioAssetUserData, MetadataTags) == 0x28, "Offset mismatch for UAudioAssetUserData::MetadataTags");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioComponentGroupExtension : public UInterface
{
public:
};

static_assert(sizeof(UAudioComponentGroupExtension) == 0x28, "Size mismatch for UAudioComponentGroupExtension");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioGameplayCondition : public UInterface
{
public:

public:
    virtual bool ConditionMet() const; // 0x28898d4 (Index: 0x0, Flags: RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual bool ConditionMet_Position(const FVector Position) const; // 0x2889788 (Index: 0x1, Flags: RequiredAPI|Native|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UAudioGameplayCondition) == 0x28, "Size mismatch for UAudioGameplayCondition");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioGameplayVolumeInteraction : public UInterface
{
public:

public:
    virtual void OnListenerEnter(); // 0x4e3f4f8 (Index: 0x0, Flags: RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void OnListenerExit(); // 0x538b694 (Index: 0x1, Flags: RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UAudioGameplayVolumeInteraction) == 0x28, "Size mismatch for UAudioGameplayVolumeInteraction");

// Size: 0xe0 (Inherited: 0xb8, Single: 0x28)
class USoundHandleSubsystem : public UAudioEngineSubsystem
{
public:
};

static_assert(sizeof(USoundHandleSubsystem) == 0xe0, "Size mismatch for USoundHandleSubsystem");

// Size: 0x3f0 (Inherited: 0x320, Single: 0xd0)
class UAudioComponentGroup : public USceneComponent
{
public:
    uint8_t Pad_240[0x8]; // 0x240 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnStopped[0x10]; // 0x248 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKilled[0x10]; // 0x258 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnVirtualized[0x10]; // 0x268 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnUnvirtualized[0x10]; // 0x278 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<UAudioComponent*> Components; // 0x288 (Size: 0x10, Type: ArrayProperty)
    TArray<FAudioParameter> ParamsToSet; // 0x298 (Size: 0x10, Type: ArrayProperty)
    TArray<FAudioParameter> PersistentParams; // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    TArray<TScriptInterface<Class>> Extensions; // 0x2b8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_2c8[0x128]; // 0x2c8 (Size: 0x128, Type: PaddingProperty)

public:
    void AddExtension(TScriptInterface<Class>& NewExtension); // 0xb07e1f8 (Index: 0x0, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void AddExternalComponent(UAudioComponent*& ComponentToAdd); // 0xb07e4e8 (Index: 0x1, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void BroadcastEvent(FName& const EventName); // 0xb07ea24 (Index: 0x2, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void BroadcastKill(); // 0xb07eb4c (Index: 0x3, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void BroadcastStopAll(); // 0xb07eb68 (Index: 0x4, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void DisableVirtualization(); // 0xb07eb84 (Index: 0x5, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void EnableVirtualization(); // 0xb07eb98 (Index: 0x6, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    bool GetBoolParamValue(FName& const ParamName) const; // 0xb07ebac (Index: 0x7, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetFloatParamValue(FName& const ParamName) const; // 0xb07ece4 (Index: 0x8, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetStringParamValue(FName& const ParamName) const; // 0xb07ee1c (Index: 0x9, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPlayingAny() const; // 0xb07f120 (Index: 0xa, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsVirtualized() const; // 0xb07f13c (Index: 0xb, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RemoveExtension(TScriptInterface<Class>& NewExtension); // 0xb07f154 (Index: 0xc, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void RemoveExternalComponent(UAudioComponent*& ComponentToRemove); // 0xb07f450 (Index: 0xd, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void SetLowPassFilter(float& const InFrequency); // 0xb07f8c8 (Index: 0xe, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void SetPitchMultiplier(float& const InPitch); // 0xb07f9f4 (Index: 0xf, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void SetVolumeMultiplier(float& const InVolume); // 0x9eec458 (Index: 0x10, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    static UAudioComponentGroup* StaticGetOrCreateComponentGroup(AActor*& Actor); // 0xb07fb20 (Index: 0x11, Flags: Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable)
    void StopSound(USoundBase*& Sound, float& const FadeTime); // 0xb07fc48 (Index: 0x12, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void SubscribeToBool(FName& const ParamName, FDelegate& Delegate); // 0xb07fe50 (Index: 0x13, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void SubscribeToEvent(FName& const EventName, FDelegate& Delegate); // 0xb080074 (Index: 0x14, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void SubscribeToStringParam(FName& const ParamName, FDelegate& Delegate); // 0xb080298 (Index: 0x15, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void UnsubscribeObject(UObject*& const Object); // 0xb0804bc (Index: 0x16, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioComponentGroup) == 0x3f0, "Size mismatch for UAudioComponentGroup");
static_assert(offsetof(UAudioComponentGroup, OnStopped) == 0x248, "Offset mismatch for UAudioComponentGroup::OnStopped");
static_assert(offsetof(UAudioComponentGroup, OnKilled) == 0x258, "Offset mismatch for UAudioComponentGroup::OnKilled");
static_assert(offsetof(UAudioComponentGroup, OnVirtualized) == 0x268, "Offset mismatch for UAudioComponentGroup::OnVirtualized");
static_assert(offsetof(UAudioComponentGroup, OnUnvirtualized) == 0x278, "Offset mismatch for UAudioComponentGroup::OnUnvirtualized");
static_assert(offsetof(UAudioComponentGroup, Components) == 0x288, "Offset mismatch for UAudioComponentGroup::Components");
static_assert(offsetof(UAudioComponentGroup, ParamsToSet) == 0x298, "Offset mismatch for UAudioComponentGroup::ParamsToSet");
static_assert(offsetof(UAudioComponentGroup, PersistentParams) == 0x2a8, "Offset mismatch for UAudioComponentGroup::PersistentParams");
static_assert(offsetof(UAudioComponentGroup, Extensions) == 0x2b8, "Offset mismatch for UAudioComponentGroup::Extensions");

// Size: 0xc0 (Inherited: 0xe0, Single: 0xffffffe0)
class UAudioGameplayComponent : public UActorComponent
{
public:
};

static_assert(sizeof(UAudioGameplayComponent) == 0xc0, "Size mismatch for UAudioGameplayComponent");

// Size: 0x78 (Inherited: 0x58, Single: 0x20)
class UAudioRequirementPreset : public UDataAsset
{
public:
    FGameplayTagQuery Query; // 0x30 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UAudioRequirementPreset) == 0x78, "Size mismatch for UAudioRequirementPreset");
static_assert(offsetof(UAudioRequirementPreset, Query) == 0x30, "Offset mismatch for UAudioRequirementPreset::Query");

// Size: 0x80 (Inherited: 0x88, Single: 0xfffffff8)
class UAudioGameplayTagCacheSubsystem : public UWorldSubsystem
{
public:
};

static_assert(sizeof(UAudioGameplayTagCacheSubsystem) == 0x80, "Size mismatch for UAudioGameplayTagCacheSubsystem");

// Size: 0xf0 (Inherited: 0x1a0, Single: 0xffffff50)
class UAudioParameterComponent : public UAudioGameplayComponent
{
public:
    uint8_t Pad_c0[0x10]; // 0xc0 (Size: 0x10, Type: PaddingProperty)
    TArray<TWeakObjectPtr<UAudioComponent*>> ActiveComponents; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAudioParameter> Parameters; // 0xe0 (Size: 0x10, Type: ArrayProperty)

public:
    TArray<FAudioParameter> GetParameters() const; // 0x5e1b684 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UAudioParameterComponent) == 0xf0, "Size mismatch for UAudioParameterComponent");
static_assert(offsetof(UAudioParameterComponent, ActiveComponents) == 0xd0, "Offset mismatch for UAudioParameterComponent::ActiveComponents");
static_assert(offsetof(UAudioParameterComponent, Parameters) == 0xe0, "Offset mismatch for UAudioParameterComponent::Parameters");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FAudioGameplayRequirements
{
    UAudioRequirementPreset* Preset; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery Custom; // 0x8 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FAudioGameplayRequirements) == 0x50, "Size mismatch for FAudioGameplayRequirements");
static_assert(offsetof(FAudioGameplayRequirements, Preset) == 0x0, "Offset mismatch for FAudioGameplayRequirements::Preset");
static_assert(offsetof(FAudioGameplayRequirements, Custom) == 0x8, "Offset mismatch for FAudioGameplayRequirements::Custom");

