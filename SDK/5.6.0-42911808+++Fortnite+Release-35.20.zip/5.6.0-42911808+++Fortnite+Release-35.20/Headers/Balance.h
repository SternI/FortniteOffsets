/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Balance
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0xf8 (Inherited: 0x160, Single: 0xffffff98)
class UBP_PhysicsCollisionHandler_C : public UFortPhysicsCollisionHandler
{
public:
};

static_assert(sizeof(UBP_PhysicsCollisionHandler_C) == 0xf8, "Size mismatch for UBP_PhysicsCollisionHandler_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_PhysicsObject_ImpactDamage_Default_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_PhysicsObject_ImpactDamage_Default_C) == 0xa68, "Size mismatch for UGE_PhysicsObject_ImpactDamage_Default_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_HidePlayerPawn_Default_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_HidePlayerPawn_Default_C) == 0xa68, "Size mismatch for UGE_HidePlayerPawn_Default_C");

// Size: 0x3d0 (Inherited: 0x948, Single: 0xfffffa88)
class ABP_FortPhysicsObjectManager_C : public AFortPhysicsObjectManager
{
public:
};

static_assert(sizeof(ABP_FortPhysicsObjectManager_C) == 0x3d0, "Size mismatch for ABP_FortPhysicsObjectManager_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Map_Fortitude_To_Health_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Map_Fortitude_To_Health_C) == 0xa68, "Size mismatch for UGE_Map_Fortitude_To_Health_C");

