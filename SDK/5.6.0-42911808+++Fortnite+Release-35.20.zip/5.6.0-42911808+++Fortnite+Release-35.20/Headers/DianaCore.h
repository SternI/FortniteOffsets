/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DianaCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "JunoGameNative.h"
#include "GameplayStateMachine.h"
#include "ModularGameplay.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "PlayspaceSystem.h"
#include "GameplayTags.h"

// Size: 0xac8 (Inherited: 0x3790, Single: 0xffffd338)
class ADianaRootPlayspaceBase : public AJunoSurvivalRootPlayspace
{
public:
};

static_assert(sizeof(ADianaRootPlayspaceBase) == 0xac8, "Size mismatch for ADianaRootPlayspaceBase");

// Size: 0x90 (Inherited: 0x130, Single: 0xffffff60)
class UDianaState_Setup : public UJunoState_SetupBase
{
public:
};

static_assert(sizeof(UDianaState_Setup) == 0x90, "Size mismatch for UDianaState_Setup");

// Size: 0x358 (Inherited: 0x900, Single: 0xfffffa58)
class UDianaControllerComponent_SessionAnalytics : public UJunoPlayerControllerComponent_JunoSessionAnalytics
{
public:
};

static_assert(sizeof(UDianaControllerComponent_SessionAnalytics) == 0x358, "Size mismatch for UDianaControllerComponent_SessionAnalytics");

// Size: 0x360 (Inherited: 0xbc0, Single: 0xfffff7a0)
class ADianaCoreMutators : public AFortAthenaMutator
{
public:
};

static_assert(sizeof(ADianaCoreMutators) == 0x360, "Size mismatch for ADianaCoreMutators");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UDianaGameplayCheatManager : public UChildCheatManager
{
public:
};

static_assert(sizeof(UDianaGameplayCheatManager) == 0x28, "Size mismatch for UDianaGameplayCheatManager");

// Size: 0xf8 (Inherited: 0x250, Single: 0xfffffea8)
class UDianaGameStateComponent : public UGameStateComponent
{
public:
    uint8_t OnPlayersAliveChanged[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLastPlayerStanding[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMatchEnding[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t MatchEndingThreshold; // 0xe8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_ec[0xc]; // 0xec (Size: 0xc, Type: PaddingProperty)

public:
    static UDianaGameStateComponent* Get(UObject*& const WorldContextObject); // 0x12504e14 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)

private:
    void HandlePlayerPawnChanged(APlayerState*& const PlayerState, APawn*& const NewPawn, APawn*& const OldPawn); // 0x12504f3c (Index: 0x1, Flags: Final|Native|Private)
    void HandlePlayerPawnDied(AFortPawn*& const Pawn); // 0x12505314 (Index: 0x2, Flags: Final|Native|Private)
    virtual void MulticastHandleLastPlayerStanding(AController*& LastPlayer); // 0xd540b0c (Index: 0x3, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private)
    virtual void MulticastHandleMatchEnding(); // 0x270d644 (Index: 0x4, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private)
    virtual void MulticastUpdatePlayersAlive(int32_t& const NumAlive); // 0xa7afb10 (Index: 0x5, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private)

protected:
    virtual void ReceiveLastPlayerStanding(AController*& Controller); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveMatchEnding(); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceivePlayersAliveChanged(int32_t& const NumAlive); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UDianaGameStateComponent) == 0xf8, "Size mismatch for UDianaGameStateComponent");
static_assert(offsetof(UDianaGameStateComponent, OnPlayersAliveChanged) == 0xb8, "Offset mismatch for UDianaGameStateComponent::OnPlayersAliveChanged");
static_assert(offsetof(UDianaGameStateComponent, OnLastPlayerStanding) == 0xc8, "Offset mismatch for UDianaGameStateComponent::OnLastPlayerStanding");
static_assert(offsetof(UDianaGameStateComponent, OnMatchEnding) == 0xd8, "Offset mismatch for UDianaGameStateComponent::OnMatchEnding");
static_assert(offsetof(UDianaGameStateComponent, MatchEndingThreshold) == 0xe8, "Offset mismatch for UDianaGameStateComponent::MatchEndingThreshold");

// Size: 0xe0 (Inherited: 0x330, Single: 0xfffffdb0)
class UDianaGameStateComponent_CommunicationOverride : public UFortGameStateComponent_CommunicationOverride
{
public:
};

static_assert(sizeof(UDianaGameStateComponent_CommunicationOverride) == 0xe0, "Size mismatch for UDianaGameStateComponent_CommunicationOverride");

// Size: 0x168 (Inherited: 0x460, Single: 0xfffffd08)
class UDianaPlayerSpawningComponent : public UJunoPlayerSpawningComponent
{
public:
    FGameplayTagContainer UsedSpawnPointGroups; // 0x148 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UDianaPlayerSpawningComponent) == 0x168, "Size mismatch for UDianaPlayerSpawningComponent");
static_assert(offsetof(UDianaPlayerSpawningComponent, UsedSpawnPointGroups) == 0x148, "Offset mismatch for UDianaPlayerSpawningComponent::UsedSpawnPointGroups");

