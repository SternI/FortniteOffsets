/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CoachMarks
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUI.h"
#include "FortniteUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "Blueprints.h"
#include "SlateCore.h"
#include "Engine.h"
#include "UIKit.h"

// Size: 0x648 (Inherited: 0x730, Single: 0xffffff18)
class UWBP_ChangeFlag_CoachMark_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2d8 (Size: 0x8, Type: StructProperty)
    USizeBox* WidgetSize; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UWBP_CaptureForPostBufferUpdate_C* WBP_CaptureForPostBufferUpdate; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* TopGrid; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_Header; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_Description; // 0x300 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Background; // 0x308 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Arrow; // 0x310 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* Description; // 0x318 (Size: 0x8, Type: ObjectProperty)
    UGridPanel* Content; // 0x320 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* Buttons; // 0x328 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Outro; // 0x330 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<E_UI_OutBoardPosition> ArrowPosition; // 0x338 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_339[0x7]; // 0x339 (Size: 0x7, Type: PaddingProperty)
    double OutsideOffset; // 0x340 (Size: 0x8, Type: DoubleProperty)
    uint8_t Pad_348[0x8]; // 0x348 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush Brush_Icon; // 0x350 (Size: 0xb0, Type: StructProperty)
    float Angle_Icon; // 0x400 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<E_UI_DirectionLeftRightNone> IconPosition; // 0x404 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_405[0x3]; // 0x405 (Size: 0x3, Type: PaddingProperty)
    FText TextHeader; // 0x408 (Size: 0x10, Type: TextProperty)
    TEnumAsByte<ETextJustify> JustificationHeader; // 0x418 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_419[0x7]; // 0x419 (Size: 0x7, Type: PaddingProperty)
    FText TextDescription; // 0x420 (Size: 0x10, Type: TextProperty)
    FSlateColor DefaultDescriptoinColor; // 0x430 (Size: 0x14, Type: StructProperty)
    TEnumAsByte<ETextJustify> JustificationDescription; // 0x444 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_445[0x3]; // 0x445 (Size: 0x3, Type: PaddingProperty)
    FText TextDismissButton; // 0x448 (Size: 0x10, Type: TextProperty)
    bool IsShowDismissButton; // 0x458 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_459[0x7]; // 0x459 (Size: 0x7, Type: PaddingProperty)
    FText TextOtherActionButton; // 0x460 (Size: 0x10, Type: TextProperty)
    bool IsShowOtherActionButton; // 0x470 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_471[0xf]; // 0x471 (Size: 0xf, Type: PaddingProperty)
    FSlateBrush BackgroundBrush; // 0x480 (Size: 0xb0, Type: StructProperty)
    float Widget_Width; // 0x530 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_534[0x4]; // 0x534 (Size: 0x4, Type: PaddingProperty)
    uint8_t ButtonDismissClicked[0x10]; // 0x538 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t ButtonDismissHoldCompleted[0x10]; // 0x548 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t ButtonOtherActionClicked[0x10]; // 0x558 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t ButtonOtherActionHoldCompleted[0x10]; // 0x568 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    double SafeZone; // 0x578 (Size: 0x8, Type: DoubleProperty)
    TArray<UClass*> In_Decorator_Classes; // 0x580 (Size: 0x10, Type: ArrayProperty)
    FDataTableRowHandle Input_Action_Other; // 0x590 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle Input_Action_Dismiss; // 0x5a0 (Size: 0x10, Type: StructProperty)
    UMaterialInstanceDynamic* BackgroundDynamicMaterial; // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    TSoftClassPtr DismissButtonClass; // 0x5b8 (Size: 0x20, Type: SoftClassProperty)
    UWBP_UIKit_Button_Regular_C* DismissButton; // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    TSoftClassPtr OtherActionButtonClass; // 0x5e0 (Size: 0x20, Type: SoftClassProperty)
    UWBP_UIKit_Button_Regular_C* OtherActionButton; // 0x600 (Size: 0x8, Type: ObjectProperty)
    UClass* HoldDataOther; // 0x608 (Size: 0x8, Type: ClassProperty)
    bool RequiresHoldOther; // 0x610 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_611[0x7]; // 0x611 (Size: 0x7, Type: PaddingProperty)
    UClass* HoldDataDismiss; // 0x618 (Size: 0x8, Type: ClassProperty)
    bool RequiresHoldDismiss; // 0x620 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_621[0x7]; // 0x621 (Size: 0x7, Type: PaddingProperty)
    UImage* Image_Icon; // 0x628 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<ESlateSizeRule> ButtonFillRule; // 0x630 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_631[0x7]; // 0x631 (Size: 0x7, Type: PaddingProperty)
    uint8_t HidingFinished[0x10]; // 0x638 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void HidingFinished__DelegateSignature(); // 0x288a61c (Index: 0x2, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void ButtonDismissClicked__DelegateSignature(); // 0x288a61c (Index: 0x3, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void ButtonOtherActionHoldCompleted__DelegateSignature(); // 0x288a61c (Index: 0x5, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void ButtonOtherActionClicked__DelegateSignature(); // 0x288a61c (Index: 0x6, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void HandleButtonClicked(UCommonButtonBase*& Button); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnRemovedFromFocusPath(FFocusEvent& InFocusEvent); // 0x288a61c (Index: 0xb, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void HideCoachMark(); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void OnHideAnimationFinished(); // 0x288a61c (Index: 0xd, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ButtonDismissHoldCompleted__DelegateSignature(); // 0x288a61c (Index: 0xe, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void ShowCoachMark(); // 0x288a61c (Index: 0x10, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetTextHeader(FText& Text, bool& Empty); // 0x288a61c (Index: 0x11, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetTextDescription(FText& Text, bool& Empty); // 0x288a61c (Index: 0x12, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void ResetState(); // 0x288a61c (Index: 0x14, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x15, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnShowAnimationFinished(); // 0x288a61c (Index: 0x16, Flags: Public|BlueprintCallable|BlueprintEvent)

private:
    void InitArrow(TEnumAsByte<E_UI_OutBoardPosition>& Position); // 0x288a61c (Index: 0x0, Flags: Private|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Init_Buttons(); // 0x288a61c (Index: 0x1, Flags: Private|HasDefaults|BlueprintCallable|BlueprintEvent)
    void InitBackground(); // 0x288a61c (Index: 0x7, Flags: Private|BlueprintCallable|BlueprintEvent)
    void InitIcon(TEnumAsByte<E_UI_DirectionLeftRightNone>& Direction); // 0x288a61c (Index: 0x8, Flags: Private|BlueprintCallable|BlueprintEvent)
    void UpdateVisibilityButtonBlock(); // 0x288a61c (Index: 0xf, Flags: Private|BlueprintCallable|BlueprintEvent)
    void SetText(FText& Text, UCommonRichTextBlock*& TextBlock, bool& Empty); // 0x288a61c (Index: 0x13, Flags: Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_ChangeFlag_CoachMark_C) == 0x648, "Size mismatch for UWBP_ChangeFlag_CoachMark_C");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, UberGraphFrame) == 0x2d8, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::UberGraphFrame");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, WidgetSize) == 0x2e0, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::WidgetSize");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, WBP_CaptureForPostBufferUpdate) == 0x2e8, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::WBP_CaptureForPostBufferUpdate");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, TopGrid) == 0x2f0, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::TopGrid");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, RichText_Header) == 0x2f8, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::RichText_Header");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, RichText_Description) == 0x300, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::RichText_Description");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, Image_Background) == 0x308, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::Image_Background");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, Image_Arrow) == 0x310, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::Image_Arrow");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, Description) == 0x318, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::Description");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, Content) == 0x320, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::Content");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, Buttons) == 0x328, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::Buttons");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, Anim_Outro) == 0x330, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::Anim_Outro");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, ArrowPosition) == 0x338, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::ArrowPosition");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, OutsideOffset) == 0x340, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::OutsideOffset");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, Brush_Icon) == 0x350, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::Brush_Icon");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, Angle_Icon) == 0x400, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::Angle_Icon");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, IconPosition) == 0x404, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::IconPosition");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, TextHeader) == 0x408, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::TextHeader");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, JustificationHeader) == 0x418, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::JustificationHeader");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, TextDescription) == 0x420, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::TextDescription");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, DefaultDescriptoinColor) == 0x430, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::DefaultDescriptoinColor");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, JustificationDescription) == 0x444, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::JustificationDescription");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, TextDismissButton) == 0x448, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::TextDismissButton");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, IsShowDismissButton) == 0x458, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::IsShowDismissButton");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, TextOtherActionButton) == 0x460, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::TextOtherActionButton");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, IsShowOtherActionButton) == 0x470, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::IsShowOtherActionButton");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, BackgroundBrush) == 0x480, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::BackgroundBrush");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, Widget_Width) == 0x530, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::Widget_Width");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, ButtonDismissClicked) == 0x538, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::ButtonDismissClicked");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, ButtonDismissHoldCompleted) == 0x548, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::ButtonDismissHoldCompleted");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, ButtonOtherActionClicked) == 0x558, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::ButtonOtherActionClicked");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, ButtonOtherActionHoldCompleted) == 0x568, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::ButtonOtherActionHoldCompleted");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, SafeZone) == 0x578, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::SafeZone");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, In_Decorator_Classes) == 0x580, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::In_Decorator_Classes");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, Input_Action_Other) == 0x590, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::Input_Action_Other");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, Input_Action_Dismiss) == 0x5a0, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::Input_Action_Dismiss");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, BackgroundDynamicMaterial) == 0x5b0, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::BackgroundDynamicMaterial");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, DismissButtonClass) == 0x5b8, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::DismissButtonClass");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, DismissButton) == 0x5d8, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::DismissButton");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, OtherActionButtonClass) == 0x5e0, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::OtherActionButtonClass");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, OtherActionButton) == 0x600, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::OtherActionButton");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, HoldDataOther) == 0x608, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::HoldDataOther");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, RequiresHoldOther) == 0x610, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::RequiresHoldOther");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, HoldDataDismiss) == 0x618, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::HoldDataDismiss");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, RequiresHoldDismiss) == 0x620, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::RequiresHoldDismiss");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, Image_Icon) == 0x628, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::Image_Icon");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, ButtonFillRule) == 0x630, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::ButtonFillRule");
static_assert(offsetof(UWBP_ChangeFlag_CoachMark_C, HidingFinished) == 0x638, "Offset mismatch for UWBP_ChangeFlag_CoachMark_C::HidingFinished");

// Size: 0x480 (Inherited: 0xfa8, Single: 0xfffff4d8)
class UWBP_Locker_PresetCap_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x470 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark; // 0x478 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void OnRemovedFromFocusPath(FFocusEvent& InFocusEvent); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void OnShowTooltip(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnEndTooltip(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_Locker_PresetCap_CoachMark_C) == 0x480, "Size mismatch for UWBP_Locker_PresetCap_CoachMark_C");
static_assert(offsetof(UWBP_Locker_PresetCap_CoachMark_C, UberGraphFrame) == 0x470, "Offset mismatch for UWBP_Locker_PresetCap_CoachMark_C::UberGraphFrame");
static_assert(offsetof(UWBP_Locker_PresetCap_CoachMark_C, WBP_UIKit_CoachMark) == 0x478, "Offset mismatch for UWBP_Locker_PresetCap_CoachMark_C::WBP_UIKit_CoachMark");

// Size: 0x4a0 (Inherited: 0xfa8, Single: 0xfffff4f8)
class UWBP_Locker_SaveLoadout_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x470 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark; // 0x478 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnOtherActionClicked[0x10]; // 0x480 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDismissActionClicked[0x10]; // 0x490 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    virtual void OnRemovedFromFocusPath(FFocusEvent& InFocusEvent); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnOtherActionClicked__DelegateSignature(); // 0x288a61c (Index: 0x2, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnDismissActionClicked__DelegateSignature(); // 0x288a61c (Index: 0x4, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnShowTooltip(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnEndTooltip(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_Locker_SaveLoadout_CoachMark_C) == 0x4a0, "Size mismatch for UWBP_Locker_SaveLoadout_CoachMark_C");
static_assert(offsetof(UWBP_Locker_SaveLoadout_CoachMark_C, UberGraphFrame) == 0x470, "Offset mismatch for UWBP_Locker_SaveLoadout_CoachMark_C::UberGraphFrame");
static_assert(offsetof(UWBP_Locker_SaveLoadout_CoachMark_C, WBP_UIKit_CoachMark) == 0x478, "Offset mismatch for UWBP_Locker_SaveLoadout_CoachMark_C::WBP_UIKit_CoachMark");
static_assert(offsetof(UWBP_Locker_SaveLoadout_CoachMark_C, OnOtherActionClicked) == 0x480, "Offset mismatch for UWBP_Locker_SaveLoadout_CoachMark_C::OnOtherActionClicked");
static_assert(offsetof(UWBP_Locker_SaveLoadout_CoachMark_C, OnDismissActionClicked) == 0x490, "Offset mismatch for UWBP_Locker_SaveLoadout_CoachMark_C::OnDismissActionClicked");

// Size: 0x490 (Inherited: 0xfa8, Single: 0xfffff4e8)
class UWBP_Locker_PCB_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x470 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark; // 0x478 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnDismissActionClicked[0x10]; // 0x480 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    virtual void OnRemovedFromFocusPath(FFocusEvent& InFocusEvent); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnDismissActionClicked__DelegateSignature(); // 0x288a61c (Index: 0x3, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnShowTooltip(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnEndTooltip(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_Locker_PCB_CoachMark_C) == 0x490, "Size mismatch for UWBP_Locker_PCB_CoachMark_C");
static_assert(offsetof(UWBP_Locker_PCB_CoachMark_C, UberGraphFrame) == 0x470, "Offset mismatch for UWBP_Locker_PCB_CoachMark_C::UberGraphFrame");
static_assert(offsetof(UWBP_Locker_PCB_CoachMark_C, WBP_UIKit_CoachMark) == 0x478, "Offset mismatch for UWBP_Locker_PCB_CoachMark_C::WBP_UIKit_CoachMark");
static_assert(offsetof(UWBP_Locker_PCB_CoachMark_C, OnDismissActionClicked) == 0x480, "Offset mismatch for UWBP_Locker_PCB_CoachMark_C::OnDismissActionClicked");

// Size: 0x480 (Inherited: 0xfa8, Single: 0xfffff4d8)
class UWBP_Locker_PresetAccess_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x470 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark; // 0x478 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void OnRemovedFromFocusPath(FFocusEvent& InFocusEvent); // 0x288a61c (Index: 0x2, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void OnShowTooltip(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnEndTooltip(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_Locker_PresetAccess_CoachMark_C) == 0x480, "Size mismatch for UWBP_Locker_PresetAccess_CoachMark_C");
static_assert(offsetof(UWBP_Locker_PresetAccess_CoachMark_C, UberGraphFrame) == 0x470, "Offset mismatch for UWBP_Locker_PresetAccess_CoachMark_C::UberGraphFrame");
static_assert(offsetof(UWBP_Locker_PresetAccess_CoachMark_C, WBP_UIKit_CoachMark) == 0x478, "Offset mismatch for UWBP_Locker_PresetAccess_CoachMark_C::WBP_UIKit_CoachMark");

// Size: 0x480 (Inherited: 0xfa8, Single: 0xfffff4d8)
class UWBP_Locker_MusicMoments_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x470 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark; // 0x478 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void OnRemovedFromFocusPath(FFocusEvent& InFocusEvent); // 0x288a61c (Index: 0x1, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void OnShowTooltip(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnEndTooltip(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UWBP_Locker_MusicMoments_CoachMark_C) == 0x480, "Size mismatch for UWBP_Locker_MusicMoments_CoachMark_C");
static_assert(offsetof(UWBP_Locker_MusicMoments_CoachMark_C, UberGraphFrame) == 0x470, "Offset mismatch for UWBP_Locker_MusicMoments_CoachMark_C::UberGraphFrame");
static_assert(offsetof(UWBP_Locker_MusicMoments_CoachMark_C, WBP_UIKit_CoachMark) == 0x478, "Offset mismatch for UWBP_Locker_MusicMoments_CoachMark_C::WBP_UIKit_CoachMark");

