/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GalileoRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "Engine.h"

// Size: 0x850 (Inherited: 0x1d08, Single: 0xffffeb48)
class UGalileoLobsterLayerAnimInstance : public UFortItemLayerAnimInstance_Lobster
{
public:
    float PelvisTwistAlpha; // 0x7e0 (Size: 0x4, Type: FloatProperty)
    float CustomPelvisTwist; // 0x7e4 (Size: 0x4, Type: FloatProperty)
    float ResultingPitch; // 0x7e8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_7ec[0x4]; // 0x7ec (Size: 0x4, Type: PaddingProperty)
    double BlendLowerBodyFloat; // 0x7f0 (Size: 0x8, Type: DoubleProperty)
    double IsMeleeGuardingFloat; // 0x7f8 (Size: 0x8, Type: DoubleProperty)
    double ResultingYaw; // 0x800 (Size: 0x8, Type: DoubleProperty)
    bool bIsUsingPowerAO; // 0x808 (Size: 0x1, Type: BoolProperty)
    bool bIsDoubleJumpFall; // 0x809 (Size: 0x1, Type: BoolProperty)
    bool bAO_BlendIn; // 0x80a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_80b[0x5]; // 0x80b (Size: 0x5, Type: PaddingProperty)
    FGameplayTagContainer InMeleeTags; // 0x810 (Size: 0x20, Type: StructProperty)
    FGameplayTag PassengerTagName; // 0x830 (Size: 0x4, Type: StructProperty)
    FGameplayTag InMotorcycleTagName; // 0x834 (Size: 0x4, Type: StructProperty)
    FGameplayTag HoverActiveTagName; // 0x838 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_83c[0x4]; // 0x83c (Size: 0x4, Type: PaddingProperty)
    UAnimMontage* GalileoLobsterEquipMAnimMontage; // 0x840 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_848[0x8]; // 0x848 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UGalileoLobsterLayerAnimInstance) == 0x850, "Size mismatch for UGalileoLobsterLayerAnimInstance");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, PelvisTwistAlpha) == 0x7e0, "Offset mismatch for UGalileoLobsterLayerAnimInstance::PelvisTwistAlpha");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, CustomPelvisTwist) == 0x7e4, "Offset mismatch for UGalileoLobsterLayerAnimInstance::CustomPelvisTwist");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, ResultingPitch) == 0x7e8, "Offset mismatch for UGalileoLobsterLayerAnimInstance::ResultingPitch");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, BlendLowerBodyFloat) == 0x7f0, "Offset mismatch for UGalileoLobsterLayerAnimInstance::BlendLowerBodyFloat");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, IsMeleeGuardingFloat) == 0x7f8, "Offset mismatch for UGalileoLobsterLayerAnimInstance::IsMeleeGuardingFloat");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, ResultingYaw) == 0x800, "Offset mismatch for UGalileoLobsterLayerAnimInstance::ResultingYaw");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, bIsUsingPowerAO) == 0x808, "Offset mismatch for UGalileoLobsterLayerAnimInstance::bIsUsingPowerAO");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, bIsDoubleJumpFall) == 0x809, "Offset mismatch for UGalileoLobsterLayerAnimInstance::bIsDoubleJumpFall");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, bAO_BlendIn) == 0x80a, "Offset mismatch for UGalileoLobsterLayerAnimInstance::bAO_BlendIn");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, InMeleeTags) == 0x810, "Offset mismatch for UGalileoLobsterLayerAnimInstance::InMeleeTags");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, PassengerTagName) == 0x830, "Offset mismatch for UGalileoLobsterLayerAnimInstance::PassengerTagName");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, InMotorcycleTagName) == 0x834, "Offset mismatch for UGalileoLobsterLayerAnimInstance::InMotorcycleTagName");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, HoverActiveTagName) == 0x838, "Offset mismatch for UGalileoLobsterLayerAnimInstance::HoverActiveTagName");
static_assert(offsetof(UGalileoLobsterLayerAnimInstance, GalileoLobsterEquipMAnimMontage) == 0x840, "Offset mismatch for UGalileoLobsterLayerAnimInstance::GalileoLobsterEquipMAnimMontage");

