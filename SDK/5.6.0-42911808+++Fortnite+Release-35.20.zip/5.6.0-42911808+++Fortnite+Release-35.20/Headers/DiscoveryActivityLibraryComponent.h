/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DiscoveryActivityLibraryComponent
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DiscoveryBrowserUI.h"

// Size: 0xe8 (Inherited: 0x1c8, Single: 0xffffff20)
class UDiscoveryActivityLibraryComponent_C : public UActivityLibraryComponent
{
public:
};

static_assert(sizeof(UDiscoveryActivityLibraryComponent_C) == 0xe8, "Size mismatch for UDiscoveryActivityLibraryComponent_C");

