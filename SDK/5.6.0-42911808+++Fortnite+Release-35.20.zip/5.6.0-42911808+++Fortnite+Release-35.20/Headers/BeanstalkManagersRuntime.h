/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeanstalkManagersRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "BeanstalkCosmeticsRuntime.h"
#include "FortniteGame.h"

// Size: 0xa8 (Inherited: 0x28, Single: 0x80)
class UBeanstalkAccountItemDefinitionOverrideManager : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TSoftObjectPtr<UBeanCosmeticsData*> BeanCosmetics; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    UBeanCosmeticsData* BeanCosmeticsDataCache; // 0x50 (Size: 0x8, Type: ObjectProperty)
    TMap<FBeanstalkAccountItemDefinitionOverride, FPrimaryAssetId> OverrideCache; // 0x58 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UBeanstalkAccountItemDefinitionOverrideManager) == 0xa8, "Size mismatch for UBeanstalkAccountItemDefinitionOverrideManager");
static_assert(offsetof(UBeanstalkAccountItemDefinitionOverrideManager, BeanCosmetics) == 0x30, "Offset mismatch for UBeanstalkAccountItemDefinitionOverrideManager::BeanCosmetics");
static_assert(offsetof(UBeanstalkAccountItemDefinitionOverrideManager, BeanCosmeticsDataCache) == 0x50, "Offset mismatch for UBeanstalkAccountItemDefinitionOverrideManager::BeanCosmeticsDataCache");
static_assert(offsetof(UBeanstalkAccountItemDefinitionOverrideManager, OverrideCache) == 0x58, "Offset mismatch for UBeanstalkAccountItemDefinitionOverrideManager::OverrideCache");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBeanstalkAccountItemDefinitionOverride
{
    UFortAccountItemDefinition* AccountItemDefinition; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FBeanstalkAccountItemDefinitionOverride) == 0x10, "Size mismatch for FBeanstalkAccountItemDefinitionOverride");
static_assert(offsetof(FBeanstalkAccountItemDefinitionOverride, AccountItemDefinition) == 0x0, "Offset mismatch for FBeanstalkAccountItemDefinitionOverride::AccountItemDefinition");

