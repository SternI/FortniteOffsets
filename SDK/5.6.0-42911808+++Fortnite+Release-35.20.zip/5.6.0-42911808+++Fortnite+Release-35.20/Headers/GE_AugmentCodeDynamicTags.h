/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GE_AugmentCodeDynamicTags
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayAbilities.h"

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_AugmentCodeDynamicTags_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_AugmentCodeDynamicTags_C) == 0xa68, "Size mismatch for UGE_AugmentCodeDynamicTags_C");

