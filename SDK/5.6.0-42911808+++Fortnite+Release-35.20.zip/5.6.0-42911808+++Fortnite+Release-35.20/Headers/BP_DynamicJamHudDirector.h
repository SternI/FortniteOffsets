/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_DynamicJamHudDirector
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DynamicUI.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "PlayspaceSystem.h"
#include "Engine.h"
#include "GameplayAbilities.h"
#include "InputPromptManagerRuntime.h"

// Size: 0x310 (Inherited: 0x598, Single: 0xfffffd78)
class ABP_DynamicJamHudDirector_C : public ADynamicUIDirectorBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2c8 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* StartJamPromptScene; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* LoudStartJamPromptScene; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    bool bHaveAddedStartJamPrompt; // 0x2e8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2e9[0x7]; // 0x2e9 (Size: 0x7, Type: PaddingProperty)
    UAbilityAsync_WaitGameplayTagRemoved* RemoveShowWhenInPlayspaceTagListener; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UAbilityAsync_WaitGameplayTagAdded* AddShowWhenInPlayspaceTagListener; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    TArray<UInputAlias*> Active_Input_Aliases; // 0x300 (Size: 0x10, Type: ArrayProperty)

protected:
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABP_DynamicJamHudDirector_C) == 0x310, "Size mismatch for ABP_DynamicJamHudDirector_C");
static_assert(offsetof(ABP_DynamicJamHudDirector_C, UberGraphFrame) == 0x2c8, "Offset mismatch for ABP_DynamicJamHudDirector_C::UberGraphFrame");
static_assert(offsetof(ABP_DynamicJamHudDirector_C, DefaultSceneRoot) == 0x2d0, "Offset mismatch for ABP_DynamicJamHudDirector_C::DefaultSceneRoot");
static_assert(offsetof(ABP_DynamicJamHudDirector_C, StartJamPromptScene) == 0x2d8, "Offset mismatch for ABP_DynamicJamHudDirector_C::StartJamPromptScene");
static_assert(offsetof(ABP_DynamicJamHudDirector_C, LoudStartJamPromptScene) == 0x2e0, "Offset mismatch for ABP_DynamicJamHudDirector_C::LoudStartJamPromptScene");
static_assert(offsetof(ABP_DynamicJamHudDirector_C, bHaveAddedStartJamPrompt) == 0x2e8, "Offset mismatch for ABP_DynamicJamHudDirector_C::bHaveAddedStartJamPrompt");
static_assert(offsetof(ABP_DynamicJamHudDirector_C, RemoveShowWhenInPlayspaceTagListener) == 0x2f0, "Offset mismatch for ABP_DynamicJamHudDirector_C::RemoveShowWhenInPlayspaceTagListener");
static_assert(offsetof(ABP_DynamicJamHudDirector_C, AddShowWhenInPlayspaceTagListener) == 0x2f8, "Offset mismatch for ABP_DynamicJamHudDirector_C::AddShowWhenInPlayspaceTagListener");
static_assert(offsetof(ABP_DynamicJamHudDirector_C, Active_Input_Aliases) == 0x300, "Offset mismatch for ABP_DynamicJamHudDirector_C::Active_Input_Aliases");

