/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActorEntity
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "NetCore.h"
#include "Entity.h"

// Size: 0x258 (Inherited: 0xe0, Single: 0x178)
class UActorEntityComponent : public UActorComponent
{
public:
    FActorEntityMappingArray EntityMappingArray; // 0xb8 (Size: 0x130, Type: StructProperty)
    uint8_t Pad_1e8[0x70]; // 0x1e8 (Size: 0x70, Type: PaddingProperty)
};

static_assert(sizeof(UActorEntityComponent) == 0x258, "Size mismatch for UActorEntityComponent");
static_assert(offsetof(UActorEntityComponent, EntityMappingArray) == 0xb8, "Offset mismatch for UActorEntityComponent::EntityMappingArray");

// Size: 0xa0 (Inherited: 0x88, Single: 0x18)
class UActorEntitySubsystem : public UWorldSubsystem
{
public:
    uint8_t Pad_30[0x68]; // 0x30 (Size: 0x68, Type: PaddingProperty)
    UPhysicsQueryConvertor* PhysicsQueryConvertor; // 0x98 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UActorEntitySubsystem) == 0xa0, "Size mismatch for UActorEntitySubsystem");
static_assert(offsetof(UActorEntitySubsystem, PhysicsQueryConvertor) == 0x98, "Offset mismatch for UActorEntitySubsystem::PhysicsQueryConvertor");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UPhysicsComponentBridgeHelper : public UObject
{
public:

private:
    void HandleActorComponentHit(UPrimitiveComponent*& PrimitiveComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComponent, FVector& NormalImpulse, const FHitResult Hit); // 0xbdac0bc (Index: 0x0, Flags: Final|Native|Private|HasOutParms|HasDefaults)
};

static_assert(sizeof(UPhysicsComponentBridgeHelper) == 0x38, "Size mismatch for UPhysicsComponentBridgeHelper");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UPhysicsQueryConvertor : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    UActorEntitySubsystem* ActorEntitySubsystem; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UPhysicsQueryConvertor) == 0x38, "Size mismatch for UPhysicsQueryConvertor");
static_assert(offsetof(UPhysicsQueryConvertor, ActorEntitySubsystem) == 0x30, "Offset mismatch for UPhysicsQueryConvertor::ActorEntitySubsystem");

// Size: 0x20 (Inherited: 0xc, Single: 0x14)
struct FActorEntityMappingArrayItem : FFastArraySerializerItem
{
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    UBaseEntity* Entity; // 0x10 (Size: 0x8, Type: ObjectProperty)
    UObject* Object; // 0x18 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FActorEntityMappingArrayItem) == 0x20, "Size mismatch for FActorEntityMappingArrayItem");
static_assert(offsetof(FActorEntityMappingArrayItem, Entity) == 0x10, "Offset mismatch for FActorEntityMappingArrayItem::Entity");
static_assert(offsetof(FActorEntityMappingArrayItem, Object) == 0x18, "Offset mismatch for FActorEntityMappingArrayItem::Object");

// Size: 0x130 (Inherited: 0x108, Single: 0x28)
struct FActorEntityMappingArray : FFastArraySerializer
{
    uint8_t Pad_108[0x18]; // 0x108 (Size: 0x18, Type: PaddingProperty)
    TArray<FActorEntityMappingArrayItem> Entities; // 0x120 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FActorEntityMappingArray) == 0x130, "Size mismatch for FActorEntityMappingArray");
static_assert(offsetof(FActorEntityMappingArray, Entities) == 0x120, "Offset mismatch for FActorEntityMappingArray::Entities");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FSubEntityInteropRules
{
    FName ComponentName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Considered[0x4]; // 0x4 (Size: 0x4, Type: EnumProperty)
    TArray<TSoftClassPtr> AllowedEntityComponents; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FSubEntityInteropRules) == 0x18, "Size mismatch for FSubEntityInteropRules");
static_assert(offsetof(FSubEntityInteropRules, ComponentName) == 0x0, "Offset mismatch for FSubEntityInteropRules::ComponentName");
static_assert(offsetof(FSubEntityInteropRules, Considered) == 0x4, "Offset mismatch for FSubEntityInteropRules::Considered");
static_assert(offsetof(FSubEntityInteropRules, AllowedEntityComponents) == 0x8, "Offset mismatch for FSubEntityInteropRules::AllowedEntityComponents");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FActorEntityInteropRules
{
    TSoftClassPtr ActorClass; // 0x0 (Size: 0x20, Type: SoftClassProperty)
    uint8_t ActorEntityConsidered[0x4]; // 0x20 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TArray<TSoftClassPtr> AllowedEntityComponents; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t SubEntitiesConsidered[0x4]; // 0x38 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    TArray<FSubEntityInteropRules> SubEntityRules; // 0x40 (Size: 0x10, Type: ArrayProperty)
    bool bEnableEntityReplication; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FActorEntityInteropRules) == 0x58, "Size mismatch for FActorEntityInteropRules");
static_assert(offsetof(FActorEntityInteropRules, ActorClass) == 0x0, "Offset mismatch for FActorEntityInteropRules::ActorClass");
static_assert(offsetof(FActorEntityInteropRules, ActorEntityConsidered) == 0x20, "Offset mismatch for FActorEntityInteropRules::ActorEntityConsidered");
static_assert(offsetof(FActorEntityInteropRules, AllowedEntityComponents) == 0x28, "Offset mismatch for FActorEntityInteropRules::AllowedEntityComponents");
static_assert(offsetof(FActorEntityInteropRules, SubEntitiesConsidered) == 0x38, "Offset mismatch for FActorEntityInteropRules::SubEntitiesConsidered");
static_assert(offsetof(FActorEntityInteropRules, SubEntityRules) == 0x40, "Offset mismatch for FActorEntityInteropRules::SubEntityRules");
static_assert(offsetof(FActorEntityInteropRules, bEnableEntityReplication) == 0x50, "Offset mismatch for FActorEntityInteropRules::bEnableEntityReplication");

