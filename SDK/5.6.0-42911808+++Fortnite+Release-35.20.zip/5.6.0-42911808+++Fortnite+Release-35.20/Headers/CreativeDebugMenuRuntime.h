/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeDebugMenuRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "Engine.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0x1f8 (Inherited: 0x310, Single: 0xfffffee8)
class UFortControllerComponent_CreativeDebugger : public UFortControllerComponent
{
public:
    uint8_t Pad_c0[0x8]; // 0xc0 (Size: 0x8, Type: PaddingProperty)
    FScalableFloat DebuggerEnabledByDataRegistry; // 0xc8 (Size: 0x28, Type: StructProperty)
    FScalableFloat VerseDebugDrawEnabledByDataRegistry; // 0xf0 (Size: 0x28, Type: StructProperty)
    FScalableFloat NavigationMeshEnabledByDataRegistry; // 0x118 (Size: 0x28, Type: StructProperty)
    FScalableFloat NavigationPathsEnabledByDataRegistry; // 0x140 (Size: 0x28, Type: StructProperty)
    FScalableFloat GhostModeEnabledByDataRegistry; // 0x168 (Size: 0x28, Type: StructProperty)
    FScalableFloat InvincibilityEnabledByDataRegistry; // 0x190 (Size: 0x28, Type: StructProperty)
    FScalableFloat FastIterationEnabledByDataRegistry; // 0x1b8 (Size: 0x28, Type: StructProperty)
    UClass* AIDebuggerClass; // 0x1e0 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_1e8[0x10]; // 0x1e8 (Size: 0x10, Type: PaddingProperty)

public:
    void OnMinigameStateChanged(AFortMinigame*& Minigame, EFortMinigameState& MinigameState); // 0x11a5b794 (Index: 0x0, Flags: Final|Native|Public)
    void OnMutatorUpdated(); // 0x11a5b99c (Index: 0x1, Flags: Final|Native|Public)
    void OnPlayerSpawned(AController*& PC); // 0x11a5b9b0 (Index: 0x2, Flags: Final|Native|Public)
};

static_assert(sizeof(UFortControllerComponent_CreativeDebugger) == 0x1f8, "Size mismatch for UFortControllerComponent_CreativeDebugger");
static_assert(offsetof(UFortControllerComponent_CreativeDebugger, DebuggerEnabledByDataRegistry) == 0xc8, "Offset mismatch for UFortControllerComponent_CreativeDebugger::DebuggerEnabledByDataRegistry");
static_assert(offsetof(UFortControllerComponent_CreativeDebugger, VerseDebugDrawEnabledByDataRegistry) == 0xf0, "Offset mismatch for UFortControllerComponent_CreativeDebugger::VerseDebugDrawEnabledByDataRegistry");
static_assert(offsetof(UFortControllerComponent_CreativeDebugger, NavigationMeshEnabledByDataRegistry) == 0x118, "Offset mismatch for UFortControllerComponent_CreativeDebugger::NavigationMeshEnabledByDataRegistry");
static_assert(offsetof(UFortControllerComponent_CreativeDebugger, NavigationPathsEnabledByDataRegistry) == 0x140, "Offset mismatch for UFortControllerComponent_CreativeDebugger::NavigationPathsEnabledByDataRegistry");
static_assert(offsetof(UFortControllerComponent_CreativeDebugger, GhostModeEnabledByDataRegistry) == 0x168, "Offset mismatch for UFortControllerComponent_CreativeDebugger::GhostModeEnabledByDataRegistry");
static_assert(offsetof(UFortControllerComponent_CreativeDebugger, InvincibilityEnabledByDataRegistry) == 0x190, "Offset mismatch for UFortControllerComponent_CreativeDebugger::InvincibilityEnabledByDataRegistry");
static_assert(offsetof(UFortControllerComponent_CreativeDebugger, FastIterationEnabledByDataRegistry) == 0x1b8, "Offset mismatch for UFortControllerComponent_CreativeDebugger::FastIterationEnabledByDataRegistry");
static_assert(offsetof(UFortControllerComponent_CreativeDebugger, AIDebuggerClass) == 0x1e0, "Offset mismatch for UFortControllerComponent_CreativeDebugger::AIDebuggerClass");

