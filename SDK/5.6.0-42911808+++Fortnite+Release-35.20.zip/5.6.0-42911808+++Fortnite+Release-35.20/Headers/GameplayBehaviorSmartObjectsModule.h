/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayBehaviorSmartObjectsModule
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "SmartObjectsModule.h"
#include "AIModule.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayBehaviorsModule.h"
#include "GameplayTags.h"

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UGameplayBehaviorSmartObjectBehaviorDefinition : public USmartObjectBehaviorDefinition
{
public:
    UGameplayBehaviorConfig* GameplayBehaviorConfig; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UGameplayBehaviorSmartObjectBehaviorDefinition) == 0x30, "Size mismatch for UGameplayBehaviorSmartObjectBehaviorDefinition");
static_assert(offsetof(UGameplayBehaviorSmartObjectBehaviorDefinition, GameplayBehaviorConfig) == 0x28, "Offset mismatch for UGameplayBehaviorSmartObjectBehaviorDefinition::GameplayBehaviorConfig");

// Size: 0xd8 (Inherited: 0xf0, Single: 0xffffffe8)
class UAITask_UseGameplayBehaviorSmartObject : public UAITask
{
public:
    uint8_t OnSucceeded[0x10]; // 0x68 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFailed[0x10]; // 0x78 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMoveToFailed[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UAITask_MoveTo* MoveToTask; // 0x98 (Size: 0x8, Type: ObjectProperty)
    UGameplayBehavior* GameplayBehavior; // 0xa0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_a8[0x30]; // 0xa8 (Size: 0x30, Type: PaddingProperty)

public:
    static UAITask_UseGameplayBehaviorSmartObject* MoveToAndUseSmartObjectWithGameplayBehavior(AAIController*& Controller, FSmartObjectClaimHandle& ClaimHandle, bool& bLockAILogic, ESmartObjectClaimPriority& ClaimPriority); // 0xca75e58 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAITask_UseGameplayBehaviorSmartObject* UseGameplayBehaviorSmartObject(AAIController*& Controller, AActor*& SmartObjectActor, USmartObjectComponent*& SmartObjectComponent, bool& bLockAILogic); // 0xca760e0 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UAITask_UseGameplayBehaviorSmartObject* UseSmartObjectWithGameplayBehavior(AAIController*& Controller, FSmartObjectClaimHandle& ClaimHandle, bool& bLockAILogic, ESmartObjectClaimPriority& ClaimPriority); // 0xca76920 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAITask_UseGameplayBehaviorSmartObject) == 0xd8, "Size mismatch for UAITask_UseGameplayBehaviorSmartObject");
static_assert(offsetof(UAITask_UseGameplayBehaviorSmartObject, OnSucceeded) == 0x68, "Offset mismatch for UAITask_UseGameplayBehaviorSmartObject::OnSucceeded");
static_assert(offsetof(UAITask_UseGameplayBehaviorSmartObject, OnFailed) == 0x78, "Offset mismatch for UAITask_UseGameplayBehaviorSmartObject::OnFailed");
static_assert(offsetof(UAITask_UseGameplayBehaviorSmartObject, OnMoveToFailed) == 0x88, "Offset mismatch for UAITask_UseGameplayBehaviorSmartObject::OnMoveToFailed");
static_assert(offsetof(UAITask_UseGameplayBehaviorSmartObject, MoveToTask) == 0x98, "Offset mismatch for UAITask_UseGameplayBehaviorSmartObject::MoveToTask");
static_assert(offsetof(UAITask_UseGameplayBehaviorSmartObject, GameplayBehavior) == 0xa0, "Offset mismatch for UAITask_UseGameplayBehaviorSmartObject::GameplayBehavior");

// Size: 0x120 (Inherited: 0xf0, Single: 0x30)
class UBTTask_FindAndUseGameplayBehaviorSmartObject : public UBTTaskNode
{
public:
    FGameplayTagQuery ActivityRequirements; // 0x70 (Size: 0x48, Type: StructProperty)
    uint8_t ClaimPriority; // 0xb8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
    FEQSParametrizedQueryExecutionRequest EQSRequest; // 0xc0 (Size: 0x48, Type: StructProperty)
    float Radius; // 0x108 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_10c[0x14]; // 0x10c (Size: 0x14, Type: PaddingProperty)
};

static_assert(sizeof(UBTTask_FindAndUseGameplayBehaviorSmartObject) == 0x120, "Size mismatch for UBTTask_FindAndUseGameplayBehaviorSmartObject");
static_assert(offsetof(UBTTask_FindAndUseGameplayBehaviorSmartObject, ActivityRequirements) == 0x70, "Offset mismatch for UBTTask_FindAndUseGameplayBehaviorSmartObject::ActivityRequirements");
static_assert(offsetof(UBTTask_FindAndUseGameplayBehaviorSmartObject, ClaimPriority) == 0xb8, "Offset mismatch for UBTTask_FindAndUseGameplayBehaviorSmartObject::ClaimPriority");
static_assert(offsetof(UBTTask_FindAndUseGameplayBehaviorSmartObject, EQSRequest) == 0xc0, "Offset mismatch for UBTTask_FindAndUseGameplayBehaviorSmartObject::EQSRequest");
static_assert(offsetof(UBTTask_FindAndUseGameplayBehaviorSmartObject, Radius) == 0x108, "Offset mismatch for UBTTask_FindAndUseGameplayBehaviorSmartObject::Radius");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameplayBehaviorSmartObjectsBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool UseGameplayBehaviorSmartObject(AActor*& Avatar, AActor*& SmartObject); // 0xca766b0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGameplayBehaviorSmartObjectsBlueprintFunctionLibrary) == 0x28, "Size mismatch for UGameplayBehaviorSmartObjectsBlueprintFunctionLibrary");

