/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarSettings
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "Engine.h"
#include "EnhancedInput.h"
#include "CoreUObject.h"
#include "GameFeatures.h"
#include "GameplayTags.h"

// Size: 0x40 (Inherited: 0x68, Single: 0xffffffd8)
class UDelMarClientSettingRecordPartition : public UFortClientSettingRecordPartition
{
public:
};

static_assert(sizeof(UDelMarClientSettingRecordPartition) == 0x40, "Size mismatch for UDelMarClientSettingRecordPartition");

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class UDelMarInputContextRedirectMap : public UDataAsset
{
public:
    TMap<UFortInputMappingContext*, UFortInputMappingContext*> RedirectMap; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UDelMarInputContextRedirectMap) == 0x80, "Size mismatch for UDelMarInputContextRedirectMap");
static_assert(offsetof(UDelMarInputContextRedirectMap, RedirectMap) == 0x30, "Offset mismatch for UDelMarInputContextRedirectMap::RedirectMap");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDelMarInputModifierPitchInversion : public UInputModifier
{
public:
};

static_assert(sizeof(UDelMarInputModifierPitchInversion) == 0x28, "Size mismatch for UDelMarInputModifierPitchInversion");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDelMarInputModifierZeroOut : public UInputModifier
{
public:
};

static_assert(sizeof(UDelMarInputModifierZeroOut) == 0x28, "Size mismatch for UDelMarInputModifierZeroOut");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDelMarInputModifierAlwaysOne : public UInputModifier
{
public:
};

static_assert(sizeof(UDelMarInputModifierAlwaysOne) == 0x28, "Size mismatch for UDelMarInputModifierAlwaysOne");

// Size: 0x58 (Inherited: 0x50, Single: 0x8)
class UDelMarInputModifierScalarBySign : public UInputModifier
{
public:
    FVector PositiveScalar; // 0x28 (Size: 0x18, Type: StructProperty)
    FVector NegativeScalar; // 0x40 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UDelMarInputModifierScalarBySign) == 0x58, "Size mismatch for UDelMarInputModifierScalarBySign");
static_assert(offsetof(UDelMarInputModifierScalarBySign, PositiveScalar) == 0x28, "Offset mismatch for UDelMarInputModifierScalarBySign::PositiveScalar");
static_assert(offsetof(UDelMarInputModifierScalarBySign, NegativeScalar) == 0x40, "Offset mismatch for UDelMarInputModifierScalarBySign::NegativeScalar");

// Size: 0x58 (Inherited: 0x50, Single: 0x8)
class UDelMarInputModifierClamp : public UInputModifier
{
public:
    FVector Minimum; // 0x28 (Size: 0x18, Type: StructProperty)
    FVector Maximum; // 0x40 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UDelMarInputModifierClamp) == 0x58, "Size mismatch for UDelMarInputModifierClamp");
static_assert(offsetof(UDelMarInputModifierClamp, Minimum) == 0x28, "Offset mismatch for UDelMarInputModifierClamp::Minimum");
static_assert(offsetof(UDelMarInputModifierClamp, Maximum) == 0x40, "Offset mismatch for UDelMarInputModifierClamp::Maximum");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UDelMarSettingsGlobals : public UObject
{
public:
    FGameplayTag DefaultTouchControlsLayout; // 0x28 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)

public:
    static bool IsQuestBrowserEnabled(); // 0x11abd5e0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UDelMarSettingsGlobals) == 0x30, "Size mismatch for UDelMarSettingsGlobals");
static_assert(offsetof(UDelMarSettingsGlobals, DefaultTouchControlsLayout) == 0x28, "Offset mismatch for UDelMarSettingsGlobals::DefaultTouchControlsLayout");

// Size: 0x110 (Inherited: 0x140, Single: 0xffffffd0)
class UGameFeatureAction_AddInputContextMappingPlatformOverrides : public UGameFeatureAction_AddInputContextMapping
{
public:
    TSoftObjectPtr<UDelMarInputContextRedirectMap*> DigitalRedirectMap; // 0xf0 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(UGameFeatureAction_AddInputContextMappingPlatformOverrides) == 0x110, "Size mismatch for UGameFeatureAction_AddInputContextMappingPlatformOverrides");
static_assert(offsetof(UGameFeatureAction_AddInputContextMappingPlatformOverrides, DigitalRedirectMap) == 0xf0, "Offset mismatch for UGameFeatureAction_AddInputContextMappingPlatformOverrides::DigitalRedirectMap");

