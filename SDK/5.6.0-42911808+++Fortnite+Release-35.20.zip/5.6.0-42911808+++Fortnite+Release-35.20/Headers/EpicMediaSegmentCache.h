/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaSegmentCache
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UEpicMediaSegmentCacheInit : public UObject
{
public:
    FEpicMediaSegmentCacheConfig CacheConfig; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UEpicMediaSegmentCacheInit) == 0x40, "Size mismatch for UEpicMediaSegmentCacheInit");
static_assert(offsetof(UEpicMediaSegmentCacheInit, CacheConfig) == 0x28, "Offset mismatch for UEpicMediaSegmentCacheInit::CacheConfig");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FEpicMediaSegmentCacheConfig
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bResetCache; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bPersistentCache; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bAllowPersistentCacheAsTemporary; // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bClearCache; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    int32_t CacheSizeMaxFiles; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    int64_t CacheSizeOnDiskMaxBytes; // 0x10 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FEpicMediaSegmentCacheConfig) == 0x18, "Size mismatch for FEpicMediaSegmentCacheConfig");
static_assert(offsetof(FEpicMediaSegmentCacheConfig, bEnabled) == 0x0, "Offset mismatch for FEpicMediaSegmentCacheConfig::bEnabled");
static_assert(offsetof(FEpicMediaSegmentCacheConfig, bResetCache) == 0x1, "Offset mismatch for FEpicMediaSegmentCacheConfig::bResetCache");
static_assert(offsetof(FEpicMediaSegmentCacheConfig, bPersistentCache) == 0x2, "Offset mismatch for FEpicMediaSegmentCacheConfig::bPersistentCache");
static_assert(offsetof(FEpicMediaSegmentCacheConfig, bAllowPersistentCacheAsTemporary) == 0x3, "Offset mismatch for FEpicMediaSegmentCacheConfig::bAllowPersistentCacheAsTemporary");
static_assert(offsetof(FEpicMediaSegmentCacheConfig, bClearCache) == 0x4, "Offset mismatch for FEpicMediaSegmentCacheConfig::bClearCache");
static_assert(offsetof(FEpicMediaSegmentCacheConfig, CacheSizeMaxFiles) == 0x8, "Offset mismatch for FEpicMediaSegmentCacheConfig::CacheSizeMaxFiles");
static_assert(offsetof(FEpicMediaSegmentCacheConfig, CacheSizeOnDiskMaxBytes) == 0x10, "Offset mismatch for FEpicMediaSegmentCacheConfig::CacheSizeOnDiskMaxBytes");

