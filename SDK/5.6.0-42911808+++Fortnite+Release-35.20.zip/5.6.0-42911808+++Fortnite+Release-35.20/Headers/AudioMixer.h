/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioMixer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "AudioExtensions.h"

// Size: 0x108 (Inherited: 0xb8, Single: 0x50)
class UAudioBusSubsystem : public UAudioEngineSubsystem
{
public:
};

static_assert(sizeof(UAudioBusSubsystem) == 0x108, "Size mismatch for UAudioBusSubsystem");

// Size: 0x128 (Inherited: 0xb8, Single: 0x70)
class UAudioDeviceNotificationSubsystem : public UEngineSubsystem
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    uint8_t DefaultCaptureDeviceChanged[0x10]; // 0x38 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_48[0x18]; // 0x48 (Size: 0x18, Type: PaddingProperty)
    uint8_t DefaultRenderDeviceChanged[0x10]; // 0x60 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_70[0x18]; // 0x70 (Size: 0x18, Type: PaddingProperty)
    uint8_t DeviceAdded[0x10]; // 0x88 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_98[0x18]; // 0x98 (Size: 0x18, Type: PaddingProperty)
    uint8_t DeviceRemoved[0x10]; // 0xb0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_c0[0x18]; // 0xc0 (Size: 0x18, Type: PaddingProperty)
    uint8_t DeviceStateChanged[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_e8[0x18]; // 0xe8 (Size: 0x18, Type: PaddingProperty)
    uint8_t DeviceSwitched[0x10]; // 0x100 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_110[0x18]; // 0x110 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UAudioDeviceNotificationSubsystem) == 0x128, "Size mismatch for UAudioDeviceNotificationSubsystem");
static_assert(offsetof(UAudioDeviceNotificationSubsystem, DefaultCaptureDeviceChanged) == 0x38, "Offset mismatch for UAudioDeviceNotificationSubsystem::DefaultCaptureDeviceChanged");
static_assert(offsetof(UAudioDeviceNotificationSubsystem, DefaultRenderDeviceChanged) == 0x60, "Offset mismatch for UAudioDeviceNotificationSubsystem::DefaultRenderDeviceChanged");
static_assert(offsetof(UAudioDeviceNotificationSubsystem, DeviceAdded) == 0x88, "Offset mismatch for UAudioDeviceNotificationSubsystem::DeviceAdded");
static_assert(offsetof(UAudioDeviceNotificationSubsystem, DeviceRemoved) == 0xb0, "Offset mismatch for UAudioDeviceNotificationSubsystem::DeviceRemoved");
static_assert(offsetof(UAudioDeviceNotificationSubsystem, DeviceStateChanged) == 0xd8, "Offset mismatch for UAudioDeviceNotificationSubsystem::DeviceStateChanged");
static_assert(offsetof(UAudioDeviceNotificationSubsystem, DeviceSwitched) == 0x100, "Offset mismatch for UAudioDeviceNotificationSubsystem::DeviceSwitched");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioMixerBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void AddMasterSubmixEffect(UObject*& const WorldContextObject, USoundEffectSubmixPreset*& SubmixEffectPreset); // 0xa17bdf4 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void AddSourceEffectToPresetChain(UObject*& const WorldContextObject, USoundEffectSourcePresetChain*& PresetChain, FSourceEffectChainEntry& Entry); // 0xa17bfec (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static int32_t AddSubmixEffect(UObject*& const WorldContextObject, USoundSubmix*& SoundSubmix, USoundEffectSubmixPreset*& SubmixEffectPreset); // 0xa17c270 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void ClearMasterSubmixEffects(UObject*& const WorldContextObject); // 0xa17c5d8 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void ClearSubmixEffectChainOverride(UObject*& const WorldContextObject, USoundSubmix*& SoundSubmix, float& FadeTimeSec); // 0xa17c718 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void ClearSubmixEffects(UObject*& const WorldContextObject, USoundSubmix*& SoundSubmix); // 0xa17c9f4 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static FString Conv_AudioOutputDeviceInfoToString(const FAudioOutputDeviceInfo Info); // 0xa17cc00 (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void GetAvailableAudioOutputDevices(UObject*& const WorldContextObject, const FDelegate OnObtainDevicesEvent); // 0xa17cd58 (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetCurrentAudioOutputDeviceName(UObject*& const WorldContextObject, const FDelegate OnObtainCurrentDeviceEvent); // 0xa17cf30 (Index: 0x8, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetMagnitudeForFrequencies(UObject*& const WorldContextObject, const TArray<float> Frequencies, TArray<float>& Magnitudes, USoundSubmix*& SubmixToAnalyze); // 0xa17d108 (Index: 0x9, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static int32_t GetNumberOfEntriesInSourceEffectChain(UObject*& const WorldContextObject, USoundEffectSourcePresetChain*& PresetChain); // 0xa17d5c8 (Index: 0xa, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void GetPhaseForFrequencies(UObject*& const WorldContextObject, const TArray<float> Frequencies, TArray<float>& Phases, USoundSubmix*& SubmixToAnalyze); // 0xa17d7d0 (Index: 0xb, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool IsAudioBusActive(UObject*& const WorldContextObject, UAudioBus*& AudioBus); // 0xa17dc90 (Index: 0xc, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static TArray<FSoundSubmixSpectralAnalysisBandSettings> MakeFullSpectrumSpectralAnalysisBandSettings(int32_t& InNumBands, float& InMinimumFrequency, float& InMaximumFrequency, int32_t& InAttackTimeMsec, int32_t& InReleaseTimeMsec); // 0xa17de98 (Index: 0xd, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TArray<FSoundSubmixSpectralAnalysisBandSettings> MakeMusicalSpectralAnalysisBandSettings(int32_t& InNumSemitones, EMusicalNoteName& InStartingMusicalNote, int32_t& InStartingOctave, int32_t& InAttackTimeMsec, int32_t& InReleaseTimeMsec); // 0xa17e450 (Index: 0xe, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TArray<FSoundSubmixSpectralAnalysisBandSettings> MakePresetSpectralAnalysisBandSettings(EAudioSpectrumBandPresetType& InBandPresetType, int32_t& InNumBands, int32_t& InAttackTimeMsec, int32_t& InReleaseTimeMsec); // 0xa17ea04 (Index: 0xf, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void PauseRecordingOutput(UObject*& const WorldContextObject, USoundSubmix*& SubmixToPause); // 0xa17ef4c (Index: 0x10, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void PrimeSoundCueForPlayback(USoundCue*& SoundCue); // 0xa17f144 (Index: 0x11, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void PrimeSoundForPlayback(USoundWave*& SoundWave, FDelegate& const OnLoadCompletion); // 0xa17f254 (Index: 0x12, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void RegisterAudioBusToSubmix(UObject*& const WorldContextObject, USoundSubmix*& SoundSubmix, UAudioBus*& AudioBus); // 0xa17f474 (Index: 0x13, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void RemoveMasterSubmixEffect(UObject*& const WorldContextObject, USoundEffectSubmixPreset*& SubmixEffectPreset); // 0xa17f750 (Index: 0x14, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void RemoveSourceEffectFromPresetChain(UObject*& const WorldContextObject, USoundEffectSourcePresetChain*& PresetChain, int32_t& EntryIndex); // 0xa17f948 (Index: 0x15, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void RemoveSubmixEffect(UObject*& const WorldContextObject, USoundSubmix*& SoundSubmix, USoundEffectSubmixPreset*& SubmixEffectPreset); // 0xa17fc20 (Index: 0x16, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void RemoveSubmixEffectAtIndex(UObject*& const WorldContextObject, USoundSubmix*& SoundSubmix, int32_t& SubmixChainIndex); // 0xa17fefc (Index: 0x17, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void RemoveSubmixEffectPreset(UObject*& const WorldContextObject, USoundSubmix*& SoundSubmix, USoundEffectSubmixPreset*& SubmixEffectPreset); // 0xa17fc20 (Index: 0x18, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void RemoveSubmixEffectPresetAtIndex(UObject*& const WorldContextObject, USoundSubmix*& SoundSubmix, int32_t& SubmixChainIndex); // 0xa17fefc (Index: 0x19, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void ReplaceSoundEffectSubmix(UObject*& const WorldContextObject, USoundSubmix*& InSoundSubmix, int32_t& SubmixChainIndex, USoundEffectSubmixPreset*& SubmixEffectPreset); // 0xa1801d4 (Index: 0x1a, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void ReplaceSubmixEffect(UObject*& const WorldContextObject, USoundSubmix*& InSoundSubmix, int32_t& SubmixChainIndex, USoundEffectSubmixPreset*& SubmixEffectPreset); // 0xa1801d4 (Index: 0x1b, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void ResumeRecordingOutput(UObject*& const WorldContextObject, USoundSubmix*& SubmixToPause); // 0xa1805fc (Index: 0x1c, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void SetBypassSourceEffectChainEntry(UObject*& const WorldContextObject, USoundEffectSourcePresetChain*& PresetChain, int32_t& EntryIndex, bool& bBypassed); // 0xa1807f4 (Index: 0x1d, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void SetSubmixEffectChainOverride(UObject*& const WorldContextObject, USoundSubmix*& SoundSubmix, TArray<USoundEffectSubmixPreset*>& SubmixEffectPresetChain, float& FadeTimeSec); // 0xa180b9c (Index: 0x1e, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void StartAnalyzingOutput(UObject*& const WorldContextObject, USoundSubmix*& SubmixToAnalyze, EFFTSize& FFTSize, EFFTPeakInterpolationMethod& InterpolationMethod, EFFTWindowType& WindowType, float& HopSize, EAudioSpectrumType& SpectrumType); // 0xa18117c (Index: 0x1f, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void StartAudioBus(UObject*& const WorldContextObject, UAudioBus*& AudioBus); // 0xa1817a0 (Index: 0x20, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void StartRecordingOutput(UObject*& const WorldContextObject, float& ExpectedDuration, USoundSubmix*& SubmixToRecord); // 0xa181998 (Index: 0x21, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void StopAnalyzingOutput(UObject*& const WorldContextObject, USoundSubmix*& SubmixToStopAnalyzing); // 0xa181c74 (Index: 0x22, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void StopAudioBus(UObject*& const WorldContextObject, UAudioBus*& AudioBus); // 0xa181e6c (Index: 0x23, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static USoundWave* StopRecordingOutput(UObject*& const WorldContextObject, EAudioRecordingExportType& ExportType, FString& Name, FString& Path, USoundSubmix*& SubmixToRecord, USoundWave*& ExistingSoundWaveToOverwrite); // 0xa182064 (Index: 0x24, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void SwapAudioOutputDevice(UObject*& const WorldContextObject, FString& NewDeviceId, const FDelegate OnCompletedDeviceSwap); // 0xa182764 (Index: 0x25, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static float TrimAudioCache(float& InMegabytesToFree); // 0xa182b9c (Index: 0x26, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void UnregisterAudioBusFromSubmix(UObject*& const WorldContextObject, USoundSubmix*& SoundSubmix, UAudioBus*& AudioBus); // 0xa182cc8 (Index: 0x27, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioMixerBlueprintLibrary) == 0x28, "Size mismatch for UAudioMixerBlueprintLibrary");

// Size: 0x470 (Inherited: 0x9f0, Single: 0xfffffa80)
class USynthSound : public USoundWaveProcedural
{
public:
    TWeakObjectPtr<USynthComponent*> OwningSynthComponent; // 0x450 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_458[0x18]; // 0x458 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(USynthSound) == 0x470, "Size mismatch for USynthSound");
static_assert(offsetof(USynthSound, OwningSynthComponent) == 0x450, "Offset mismatch for USynthSound::OwningSynthComponent");

// Size: 0x8a0 (Inherited: 0x320, Single: 0x580)
class USynthComponent : public USceneComponent
{
public:
    uint8_t bAutoDestroy : 1; // 0x240:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bStopWhenOwnerDestroyed : 1; // 0x240:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bAllowSpatialization : 1; // 0x240:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bOverrideAttenuation : 1; // 0x240:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_241[0x3]; // 0x241 (Size: 0x3, Type: PaddingProperty)
    uint8_t bEnableBusSends : 1; // 0x244:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableBaseSubmix : 1; // 0x244:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableSubmixSends : 1; // 0x244:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_245[0x3]; // 0x245 (Size: 0x3, Type: PaddingProperty)
    USoundAttenuation* AttenuationSettings; // 0x248 (Size: 0x8, Type: ObjectProperty)
    FSoundAttenuationSettings AttenuationOverrides; // 0x250 (Size: 0x3d0, Type: StructProperty)
    USoundConcurrency* ConcurrencySettings; // 0x620 (Size: 0x8, Type: ObjectProperty)
    TSet<USoundConcurrency*> ConcurrencySet; // 0x628 (Size: 0x50, Type: SetProperty)
    FSoundModulationDefaultRoutingSettings ModulationRouting; // 0x678 (Size: 0x168, Type: StructProperty)
    USoundClass* SoundClass; // 0x7e0 (Size: 0x8, Type: ObjectProperty)
    USoundEffectSourcePresetChain* SourceEffectChain; // 0x7e8 (Size: 0x8, Type: ObjectProperty)
    USoundSubmixBase* SoundSubmix; // 0x7f0 (Size: 0x8, Type: ObjectProperty)
    TArray<FSoundSubmixSendInfo> SoundSubmixSends; // 0x7f8 (Size: 0x10, Type: ArrayProperty)
    TArray<FSoundSourceBusSendInfo> BusSends; // 0x808 (Size: 0x10, Type: ArrayProperty)
    TArray<FSoundSourceBusSendInfo> PreEffectBusSends; // 0x818 (Size: 0x10, Type: ArrayProperty)
    uint8_t bIsUISound : 1; // 0x828:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsPreviewSound : 1; // 0x828:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_829[0x3]; // 0x829 (Size: 0x3, Type: PaddingProperty)
    int32_t EnvelopeFollowerAttackTime; // 0x82c (Size: 0x4, Type: IntProperty)
    int32_t EnvelopeFollowerReleaseTime; // 0x830 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_834[0x4]; // 0x834 (Size: 0x4, Type: PaddingProperty)
    uint8_t OnAudioEnvelopeValue[0x10]; // 0x838 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_848[0x20]; // 0x848 (Size: 0x20, Type: PaddingProperty)
    USynthSound* Synth; // 0x868 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* AudioComponent; // 0x870 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_878[0x28]; // 0x878 (Size: 0x28, Type: PaddingProperty)

public:
    void AdjustVolume(float& AdjustVolumeDuration, float& AdjustVolumeLevel, EAudioFaderCurve& const FadeCurve) const; // 0xa193fb8 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|Const)
    void FadeIn(float& FadeInDuration, float& FadeVolumeLevel, float& StartTime, EAudioFaderCurve& const FadeCurve) const; // 0xa194f30 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|Const)
    void FadeOut(float& FadeOutDuration, float& FadeVolumeLevel, EAudioFaderCurve& const FadeCurve) const; // 0xa1952dc (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|Const)
    TSet<USoundModulatorBase*> GetModulators(EModulationDestination& const Destination); // 0xa196bb0 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure)
    bool IsPlaying() const; // 0xa1978a4 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetAudioBusSendPostEffect(UAudioBus*& AudioBus, float& AudioBusSendLevel); // 0xa1989f8 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetAudioBusSendPreEffect(UAudioBus*& AudioBus, float& AudioBusSendLevel); // 0xa198c14 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetLowPassFilterEnabled(bool& InLowPassFilterEnabled); // 0xa199498 (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetLowPassFilterFrequency(float& InLowPassFilterFrequency); // 0xa1995c0 (Index: 0x8, Flags: RequiredAPI|Native|Public|BlueprintCallable)
    void SetModulationRouting(const TSet<USoundModulatorBase*> Modulators, EModulationDestination& const Destination, EModulationRouting& const RoutingMethod); // 0xa199bb4 (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetOutputToBusOnly(bool& bInOutputToBusOnly); // 0xa199e3c (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSourceBusSendPostEffect(USoundSourceBus*& SoundSourceBus, float& SourceBusSendLevel); // 0xa19ad88 (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSourceBusSendPreEffect(USoundSourceBus*& SoundSourceBus, float& SourceBusSendLevel); // 0xa19afa4 (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSubmixSend(USoundSubmixBase*& Submix, float& SendLevel); // 0xa19b1c0 (Index: 0xd, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetVolumeMultiplier(float& VolumeMultiplier); // 0xa19bd50 (Index: 0xe, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void Start(); // 0xa19be7c (Index: 0xf, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void Stop(); // 0xa19c4d4 (Index: 0x10, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(USynthComponent) == 0x8a0, "Size mismatch for USynthComponent");
static_assert(offsetof(USynthComponent, bAutoDestroy) == 0x240, "Offset mismatch for USynthComponent::bAutoDestroy");
static_assert(offsetof(USynthComponent, bStopWhenOwnerDestroyed) == 0x240, "Offset mismatch for USynthComponent::bStopWhenOwnerDestroyed");
static_assert(offsetof(USynthComponent, bAllowSpatialization) == 0x240, "Offset mismatch for USynthComponent::bAllowSpatialization");
static_assert(offsetof(USynthComponent, bOverrideAttenuation) == 0x240, "Offset mismatch for USynthComponent::bOverrideAttenuation");
static_assert(offsetof(USynthComponent, bEnableBusSends) == 0x244, "Offset mismatch for USynthComponent::bEnableBusSends");
static_assert(offsetof(USynthComponent, bEnableBaseSubmix) == 0x244, "Offset mismatch for USynthComponent::bEnableBaseSubmix");
static_assert(offsetof(USynthComponent, bEnableSubmixSends) == 0x244, "Offset mismatch for USynthComponent::bEnableSubmixSends");
static_assert(offsetof(USynthComponent, AttenuationSettings) == 0x248, "Offset mismatch for USynthComponent::AttenuationSettings");
static_assert(offsetof(USynthComponent, AttenuationOverrides) == 0x250, "Offset mismatch for USynthComponent::AttenuationOverrides");
static_assert(offsetof(USynthComponent, ConcurrencySettings) == 0x620, "Offset mismatch for USynthComponent::ConcurrencySettings");
static_assert(offsetof(USynthComponent, ConcurrencySet) == 0x628, "Offset mismatch for USynthComponent::ConcurrencySet");
static_assert(offsetof(USynthComponent, ModulationRouting) == 0x678, "Offset mismatch for USynthComponent::ModulationRouting");
static_assert(offsetof(USynthComponent, SoundClass) == 0x7e0, "Offset mismatch for USynthComponent::SoundClass");
static_assert(offsetof(USynthComponent, SourceEffectChain) == 0x7e8, "Offset mismatch for USynthComponent::SourceEffectChain");
static_assert(offsetof(USynthComponent, SoundSubmix) == 0x7f0, "Offset mismatch for USynthComponent::SoundSubmix");
static_assert(offsetof(USynthComponent, SoundSubmixSends) == 0x7f8, "Offset mismatch for USynthComponent::SoundSubmixSends");
static_assert(offsetof(USynthComponent, BusSends) == 0x808, "Offset mismatch for USynthComponent::BusSends");
static_assert(offsetof(USynthComponent, PreEffectBusSends) == 0x818, "Offset mismatch for USynthComponent::PreEffectBusSends");
static_assert(offsetof(USynthComponent, bIsUISound) == 0x828, "Offset mismatch for USynthComponent::bIsUISound");
static_assert(offsetof(USynthComponent, bIsPreviewSound) == 0x828, "Offset mismatch for USynthComponent::bIsPreviewSound");
static_assert(offsetof(USynthComponent, EnvelopeFollowerAttackTime) == 0x82c, "Offset mismatch for USynthComponent::EnvelopeFollowerAttackTime");
static_assert(offsetof(USynthComponent, EnvelopeFollowerReleaseTime) == 0x830, "Offset mismatch for USynthComponent::EnvelopeFollowerReleaseTime");
static_assert(offsetof(USynthComponent, OnAudioEnvelopeValue) == 0x838, "Offset mismatch for USynthComponent::OnAudioEnvelopeValue");
static_assert(offsetof(USynthComponent, Synth) == 0x868, "Offset mismatch for USynthComponent::Synth");
static_assert(offsetof(USynthComponent, AudioComponent) == 0x870, "Offset mismatch for USynthComponent::AudioComponent");

// Size: 0x150 (Inherited: 0xf8, Single: 0x58)
class USubmixEffectDynamicsProcessorPreset : public USoundEffectSubmixPreset
{
public:
    uint8_t Pad_68[0x88]; // 0x68 (Size: 0x88, Type: PaddingProperty)
    FSubmixEffectDynamicsProcessorSettings Settings; // 0xf0 (Size: 0x60, Type: StructProperty)

public:
    void ResetKey(); // 0xa197eb4 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetAudioBus(UAudioBus*& AudioBus); // 0xa19884c (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetExternalSubmix(USoundSubmix*& Submix); // 0xa1992f4 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSettings(const FSubmixEffectDynamicsProcessorSettings Settings); // 0xa19a554 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(USubmixEffectDynamicsProcessorPreset) == 0x150, "Size mismatch for USubmixEffectDynamicsProcessorPreset");
static_assert(offsetof(USubmixEffectDynamicsProcessorPreset, Settings) == 0xf0, "Offset mismatch for USubmixEffectDynamicsProcessorPreset::Settings");

// Size: 0xb0 (Inherited: 0xf8, Single: 0xffffffb8)
class USubmixEffectSubmixEQPreset : public USoundEffectSubmixPreset
{
public:
    uint8_t Pad_68[0x38]; // 0x68 (Size: 0x38, Type: PaddingProperty)
    FSubmixEffectSubmixEQSettings Settings; // 0xa0 (Size: 0x10, Type: StructProperty)

public:
    void SetSettings(const FSubmixEffectSubmixEQSettings InSettings); // 0xa19a7b0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(USubmixEffectSubmixEQPreset) == 0xb0, "Size mismatch for USubmixEffectSubmixEQPreset");
static_assert(offsetof(USubmixEffectSubmixEQPreset, Settings) == 0xa0, "Offset mismatch for USubmixEffectSubmixEQPreset::Settings");

// Size: 0x110 (Inherited: 0xf8, Single: 0x18)
class USubmixEffectReverbPreset : public USoundEffectSubmixPreset
{
public:
    uint8_t Pad_68[0x68]; // 0x68 (Size: 0x68, Type: PaddingProperty)
    FSubmixEffectReverbSettings Settings; // 0xd0 (Size: 0x40, Type: StructProperty)

public:
    void SetSettings(const FSubmixEffectReverbSettings InSettings); // 0xa19a68c (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetSettingsWithReverbEffect(UReverbEffect*& const InReverbEffect, float& const WetLevel, float& const DryLevel); // 0xa19aa28 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(USubmixEffectReverbPreset) == 0x110, "Size mismatch for USubmixEffectReverbPreset");
static_assert(offsetof(USubmixEffectReverbPreset, Settings) == 0xd0, "Offset mismatch for USubmixEffectReverbPreset::Settings");

// Size: 0xa8 (Inherited: 0x28, Single: 0x80)
class UAudioGenerator : public UObject
{
public:
};

static_assert(sizeof(UAudioGenerator) == 0xa8, "Size mismatch for UAudioGenerator");

// Size: 0x208 (Inherited: 0x28, Single: 0x1e0)
class UQuartzClockHandle : public UObject
{
public:

public:
    float GetBeatProgressPercent(EQuartzCommandQuantization& QuantizationBoundary, float& PhaseOffset, float& MSOffset); // 0xa195638 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    float GetBeatsPerMinute(UObject*& const WorldContextObject) const; // 0xa195920 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FQuartzTransportTimeStamp GetCurrentTimestamp(UObject*& const WorldContextObject); // 0xa195c60 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    float GetDurationOfQuantizationTypeInSeconds(UObject*& const WorldContextObject, const EQuartzCommandQuantization QuantizationType, float& Multiplier); // 0xa195da4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    float GetEstimatedRunTime(UObject*& const WorldContextObject); // 0xa1964a8 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    float GetMillisecondsPerTick(UObject*& const WorldContextObject) const; // 0xa196a78 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetSecondsPerTick(UObject*& const WorldContextObject) const; // 0xa197194 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetThirtySecondNotesPerMinute(UObject*& const WorldContextObject) const; // 0xa1972cc (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTicksPerSecond(UObject*& const WorldContextObject) const; // 0xa197404 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsClockRunning(UObject*& const WorldContextObject); // 0xa19753c (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void NotifyOnQuantizationBoundary(UObject*& const WorldContextObject, FQuartzQuantizationBoundary& InQuantizationBoundary, const FDelegate InDelegate, float& InMsOffset); // 0xa1978c8 (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void PauseClock(UObject*& const WorldContextObject, UQuartzClockHandle*& ClockHandle); // 0xa197b5c (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void ResetTransport(UObject*& const WorldContextObject, const FDelegate InDelegate); // 0xa197ec8 (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void ResetTransportQuantized(UObject*& const WorldContextObject, FQuartzQuantizationBoundary& InQuantizationBoundary, const FDelegate InDelegate, UQuartzClockHandle*& ClockHandle); // 0xa1980ac (Index: 0xd, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void ResumeClock(UObject*& const WorldContextObject, UQuartzClockHandle*& ClockHandle); // 0xa1984f4 (Index: 0xe, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetBeatsPerMinute(UObject*& const WorldContextObject, const FQuartzQuantizationBoundary QuantizationBoundary, const FDelegate Delegate, UQuartzClockHandle*& ClockHandle, float& BeatsPerMinute); // 0xa198e30 (Index: 0xf, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetMillisecondsPerTick(UObject*& const WorldContextObject, const FQuartzQuantizationBoundary QuantizationBoundary, const FDelegate Delegate, UQuartzClockHandle*& ClockHandle, float& MillisecondsPerTick); // 0xa1996f0 (Index: 0x10, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetSecondsPerTick(UObject*& const WorldContextObject, const FQuartzQuantizationBoundary QuantizationBoundary, const FDelegate Delegate, UQuartzClockHandle*& ClockHandle, float& SecondsPerTick); // 0xa19a090 (Index: 0x11, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetThirtySecondNotesPerMinute(UObject*& const WorldContextObject, const FQuartzQuantizationBoundary QuantizationBoundary, const FDelegate Delegate, UQuartzClockHandle*& ClockHandle, float& ThirtySecondsNotesPerMinute); // 0xa19b3c8 (Index: 0x12, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetTicksPerSecond(UObject*& const WorldContextObject, const FQuartzQuantizationBoundary QuantizationBoundary, const FDelegate Delegate, UQuartzClockHandle*& ClockHandle, float& TicksPerSecond); // 0xa19b88c (Index: 0x13, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void StartClock(UObject*& const WorldContextObject, UQuartzClockHandle*& ClockHandle); // 0xa19be90 (Index: 0x14, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void StartOtherClock(UObject*& const WorldContextObject, FName& OtherClockName, FQuartzQuantizationBoundary& InQuantizationBoundary, const FDelegate InDelegate); // 0xa19c1ec (Index: 0x15, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void StopClock(UObject*& const WorldContextObject, bool& CancelPendingEvents, UQuartzClockHandle*& ClockHandle); // 0xa19c4e8 (Index: 0x16, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SubscribeToAllQuantizationEvents(UObject*& const WorldContextObject, const FDelegate OnQuantizationEvent, UQuartzClockHandle*& ClockHandle); // 0xa19c918 (Index: 0x17, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SubscribeToQuantizationEvent(UObject*& const WorldContextObject, EQuartzCommandQuantization& InQuantizationBoundary, const FDelegate OnQuantizationEvent, UQuartzClockHandle*& ClockHandle); // 0xa19cccc (Index: 0x18, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void UnsubscribeFromAllTimeDivisions(UObject*& const WorldContextObject, UQuartzClockHandle*& ClockHandle); // 0xa19d0ec (Index: 0x19, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void UnsubscribeFromTimeDivision(UObject*& const WorldContextObject, EQuartzCommandQuantization& InQuantizationBoundary, UQuartzClockHandle*& ClockHandle); // 0xa19d444 (Index: 0x1a, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UQuartzClockHandle) == 0x208, "Size mismatch for UQuartzClockHandle");

// Size: 0x68 (Inherited: 0xc8, Single: 0xffffffa0)
class UQuartzSubsystem : public UTickableWorldSubsystem
{
public:

public:
    UQuartzClockHandle* CreateNewClock(UObject*& const WorldContextObject, FName& ClockName, FQuartzClockSettings& InSettings, bool& bOverrideSettingsIfClockExists, bool& bUseAudioEngineClockManager); // 0xa19429c (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void DeleteClockByHandle(UObject*& const WorldContextObject, UQuartzClockHandle* InClockHandle); // 0xa19479c (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void DeleteClockByName(UObject*& const WorldContextObject, FName& ClockName); // 0xa194af8 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    bool DoesClockExist(UObject*& const WorldContextObject, FName& ClockName); // 0xa194d00 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    float GetAudioRenderThreadToGameThreadAverageLatency(); // 0xa1955b8 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    float GetAudioRenderThreadToGameThreadMaxLatency(); // 0xa1955e4 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    float GetAudioRenderThreadToGameThreadMinLatency(); // 0xa19560c (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    FQuartzTransportTimeStamp GetCurrentClockTimestamp(UObject*& const WorldContextObject, const FName InClockName); // 0xa195a58 (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    float GetDurationOfQuantizationTypeInSeconds(UObject*& const WorldContextObject, FName& ClockName, const EQuartzCommandQuantization QuantizationType, float& Multiplier); // 0xa195fd0 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    float GetEstimatedClockRunTime(UObject*& const WorldContextObject, const FName InClockName); // 0xa1962e4 (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    float GetGameThreadToAudioRenderThreadAverageLatency(UObject*& const WorldContextObject); // 0xa1965e4 (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    float GetGameThreadToAudioRenderThreadMaxLatency(UObject*& const WorldContextObject); // 0xa196720 (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    float GetGameThreadToAudioRenderThreadMinLatency(UObject*& const WorldContextObject); // 0xa196720 (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    UQuartzClockHandle* GetHandleForClock(UObject*& const WorldContextObject, FName& ClockName); // 0xa19685c (Index: 0xd, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    float GetRoundTripAverageLatency(UObject*& const WorldContextObject); // 0xa196dc8 (Index: 0xe, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    float GetRoundTripMaxLatency(UObject*& const WorldContextObject); // 0xa196f04 (Index: 0xf, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    float GetRoundTripMinLatency(UObject*& const WorldContextObject); // 0xa197040 (Index: 0x10, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    bool IsClockRunning(UObject*& const WorldContextObject, FName& ClockName); // 0xa197674 (Index: 0x11, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    bool IsQuartzEnabled(); // 0x53bb30c (Index: 0x12, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetQuartzSubsystemTickableWhenPaused(bool& const bInTickableWhenPaused); // 0xa199f68 (Index: 0x13, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UQuartzSubsystem) == 0x68, "Size mismatch for UQuartzSubsystem");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FAudioOutputDeviceInfo
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FString DeviceID; // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t NumChannels; // 0x20 (Size: 0x4, Type: IntProperty)
    int32_t SampleRate; // 0x24 (Size: 0x4, Type: IntProperty)
    uint8_t Format; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    TArray<EAudioMixerChannelType> OutputChannelArray; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t bIsSystemDefault : 1; // 0x40:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsCurrentDevice : 1; // 0x40:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAudioOutputDeviceInfo) == 0x48, "Size mismatch for FAudioOutputDeviceInfo");
static_assert(offsetof(FAudioOutputDeviceInfo, Name) == 0x0, "Offset mismatch for FAudioOutputDeviceInfo::Name");
static_assert(offsetof(FAudioOutputDeviceInfo, DeviceID) == 0x10, "Offset mismatch for FAudioOutputDeviceInfo::DeviceID");
static_assert(offsetof(FAudioOutputDeviceInfo, NumChannels) == 0x20, "Offset mismatch for FAudioOutputDeviceInfo::NumChannels");
static_assert(offsetof(FAudioOutputDeviceInfo, SampleRate) == 0x24, "Offset mismatch for FAudioOutputDeviceInfo::SampleRate");
static_assert(offsetof(FAudioOutputDeviceInfo, Format) == 0x28, "Offset mismatch for FAudioOutputDeviceInfo::Format");
static_assert(offsetof(FAudioOutputDeviceInfo, OutputChannelArray) == 0x30, "Offset mismatch for FAudioOutputDeviceInfo::OutputChannelArray");
static_assert(offsetof(FAudioOutputDeviceInfo, bIsSystemDefault) == 0x40, "Offset mismatch for FAudioOutputDeviceInfo::bIsSystemDefault");
static_assert(offsetof(FAudioOutputDeviceInfo, bIsCurrentDevice) == 0x40, "Offset mismatch for FAudioOutputDeviceInfo::bIsCurrentDevice");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FSwapAudioOutputResult
{
    FString CurrentDeviceId; // 0x0 (Size: 0x10, Type: StrProperty)
    FString RequestedDeviceId; // 0x10 (Size: 0x10, Type: StrProperty)
    uint8_t Result; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FSwapAudioOutputResult) == 0x28, "Size mismatch for FSwapAudioOutputResult");
static_assert(offsetof(FSwapAudioOutputResult, CurrentDeviceId) == 0x0, "Offset mismatch for FSwapAudioOutputResult::CurrentDeviceId");
static_assert(offsetof(FSwapAudioOutputResult, RequestedDeviceId) == 0x10, "Offset mismatch for FSwapAudioOutputResult::RequestedDeviceId");
static_assert(offsetof(FSwapAudioOutputResult, Result) == 0x20, "Offset mismatch for FSwapAudioOutputResult::Result");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FSubmixEffectDynamicProcessorFilterSettings
{
    uint8_t bEnabled : 1; // 0x0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float Cutoff; // 0x4 (Size: 0x4, Type: FloatProperty)
    float GainDb; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FSubmixEffectDynamicProcessorFilterSettings) == 0xc, "Size mismatch for FSubmixEffectDynamicProcessorFilterSettings");
static_assert(offsetof(FSubmixEffectDynamicProcessorFilterSettings, bEnabled) == 0x0, "Offset mismatch for FSubmixEffectDynamicProcessorFilterSettings::bEnabled");
static_assert(offsetof(FSubmixEffectDynamicProcessorFilterSettings, Cutoff) == 0x4, "Offset mismatch for FSubmixEffectDynamicProcessorFilterSettings::Cutoff");
static_assert(offsetof(FSubmixEffectDynamicProcessorFilterSettings, GainDb) == 0x8, "Offset mismatch for FSubmixEffectDynamicProcessorFilterSettings::GainDb");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FSubmixEffectDynamicsProcessorSettings
{
    uint8_t DynamicsProcessorType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t PeakMode; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t LinkMode; // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    float InputGainDb; // 0x4 (Size: 0x4, Type: FloatProperty)
    float ThresholdDb; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Ratio; // 0xc (Size: 0x4, Type: FloatProperty)
    float KneeBandwidthDb; // 0x10 (Size: 0x4, Type: FloatProperty)
    float LookAheadMsec; // 0x14 (Size: 0x4, Type: FloatProperty)
    float AttackTimeMsec; // 0x18 (Size: 0x4, Type: FloatProperty)
    float ReleaseTimeMsec; // 0x1c (Size: 0x4, Type: FloatProperty)
    uint8_t KeySource; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
    UAudioBus* ExternalAudioBus; // 0x28 (Size: 0x8, Type: ObjectProperty)
    USoundSubmix* ExternalSubmix; // 0x30 (Size: 0x8, Type: ObjectProperty)
    uint8_t bChannelLinked : 1; // 0x38:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAnalogMode : 1; // 0x38:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bBypass : 1; // 0x38:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bKeyAudition : 1; // 0x38:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    float KeyGainDb; // 0x3c (Size: 0x4, Type: FloatProperty)
    float OutputGainDb; // 0x40 (Size: 0x4, Type: FloatProperty)
    FSubmixEffectDynamicProcessorFilterSettings KeyHighshelf; // 0x44 (Size: 0xc, Type: StructProperty)
    FSubmixEffectDynamicProcessorFilterSettings KeyLowshelf; // 0x50 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FSubmixEffectDynamicsProcessorSettings) == 0x60, "Size mismatch for FSubmixEffectDynamicsProcessorSettings");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, DynamicsProcessorType) == 0x0, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::DynamicsProcessorType");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, PeakMode) == 0x1, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::PeakMode");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, LinkMode) == 0x2, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::LinkMode");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, InputGainDb) == 0x4, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::InputGainDb");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, ThresholdDb) == 0x8, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::ThresholdDb");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, Ratio) == 0xc, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::Ratio");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, KneeBandwidthDb) == 0x10, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::KneeBandwidthDb");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, LookAheadMsec) == 0x14, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::LookAheadMsec");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, AttackTimeMsec) == 0x18, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::AttackTimeMsec");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, ReleaseTimeMsec) == 0x1c, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::ReleaseTimeMsec");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, KeySource) == 0x20, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::KeySource");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, ExternalAudioBus) == 0x28, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::ExternalAudioBus");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, ExternalSubmix) == 0x30, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::ExternalSubmix");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, bChannelLinked) == 0x38, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::bChannelLinked");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, bAnalogMode) == 0x38, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::bAnalogMode");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, bBypass) == 0x38, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::bBypass");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, bKeyAudition) == 0x38, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::bKeyAudition");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, KeyGainDb) == 0x3c, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::KeyGainDb");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, OutputGainDb) == 0x40, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::OutputGainDb");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, KeyHighshelf) == 0x44, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::KeyHighshelf");
static_assert(offsetof(FSubmixEffectDynamicsProcessorSettings, KeyLowshelf) == 0x50, "Offset mismatch for FSubmixEffectDynamicsProcessorSettings::KeyLowshelf");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSubmixEffectEQBand
{
    float Frequency; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Bandwidth; // 0x4 (Size: 0x4, Type: FloatProperty)
    float GainDb; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t bEnabled : 1; // 0xc:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FSubmixEffectEQBand) == 0x10, "Size mismatch for FSubmixEffectEQBand");
static_assert(offsetof(FSubmixEffectEQBand, Frequency) == 0x0, "Offset mismatch for FSubmixEffectEQBand::Frequency");
static_assert(offsetof(FSubmixEffectEQBand, Bandwidth) == 0x4, "Offset mismatch for FSubmixEffectEQBand::Bandwidth");
static_assert(offsetof(FSubmixEffectEQBand, GainDb) == 0x8, "Offset mismatch for FSubmixEffectEQBand::GainDb");
static_assert(offsetof(FSubmixEffectEQBand, bEnabled) == 0xc, "Offset mismatch for FSubmixEffectEQBand::bEnabled");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSubmixEffectSubmixEQSettings
{
    TArray<FSubmixEffectEQBand> EqBands; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FSubmixEffectSubmixEQSettings) == 0x10, "Size mismatch for FSubmixEffectSubmixEQSettings");
static_assert(offsetof(FSubmixEffectSubmixEQSettings, EqBands) == 0x0, "Offset mismatch for FSubmixEffectSubmixEQSettings::EqBands");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FSubmixEffectReverbSettings
{
    bool bBypassEarlyReflections; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float ReflectionsDelay; // 0x4 (Size: 0x4, Type: FloatProperty)
    float GainHF; // 0x8 (Size: 0x4, Type: FloatProperty)
    float ReflectionsGain; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bBypassLateReflections; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float LateDelay; // 0x14 (Size: 0x4, Type: FloatProperty)
    float DecayTime; // 0x18 (Size: 0x4, Type: FloatProperty)
    float Density; // 0x1c (Size: 0x4, Type: FloatProperty)
    float Diffusion; // 0x20 (Size: 0x4, Type: FloatProperty)
    float AirAbsorptionGainHF; // 0x24 (Size: 0x4, Type: FloatProperty)
    float DecayHFRatio; // 0x28 (Size: 0x4, Type: FloatProperty)
    float LateGain; // 0x2c (Size: 0x4, Type: FloatProperty)
    float Gain; // 0x30 (Size: 0x4, Type: FloatProperty)
    float WetLevel; // 0x34 (Size: 0x4, Type: FloatProperty)
    float DryLevel; // 0x38 (Size: 0x4, Type: FloatProperty)
    bool bBypass; // 0x3c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3d[0x3]; // 0x3d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FSubmixEffectReverbSettings) == 0x40, "Size mismatch for FSubmixEffectReverbSettings");
static_assert(offsetof(FSubmixEffectReverbSettings, bBypassEarlyReflections) == 0x0, "Offset mismatch for FSubmixEffectReverbSettings::bBypassEarlyReflections");
static_assert(offsetof(FSubmixEffectReverbSettings, ReflectionsDelay) == 0x4, "Offset mismatch for FSubmixEffectReverbSettings::ReflectionsDelay");
static_assert(offsetof(FSubmixEffectReverbSettings, GainHF) == 0x8, "Offset mismatch for FSubmixEffectReverbSettings::GainHF");
static_assert(offsetof(FSubmixEffectReverbSettings, ReflectionsGain) == 0xc, "Offset mismatch for FSubmixEffectReverbSettings::ReflectionsGain");
static_assert(offsetof(FSubmixEffectReverbSettings, bBypassLateReflections) == 0x10, "Offset mismatch for FSubmixEffectReverbSettings::bBypassLateReflections");
static_assert(offsetof(FSubmixEffectReverbSettings, LateDelay) == 0x14, "Offset mismatch for FSubmixEffectReverbSettings::LateDelay");
static_assert(offsetof(FSubmixEffectReverbSettings, DecayTime) == 0x18, "Offset mismatch for FSubmixEffectReverbSettings::DecayTime");
static_assert(offsetof(FSubmixEffectReverbSettings, Density) == 0x1c, "Offset mismatch for FSubmixEffectReverbSettings::Density");
static_assert(offsetof(FSubmixEffectReverbSettings, Diffusion) == 0x20, "Offset mismatch for FSubmixEffectReverbSettings::Diffusion");
static_assert(offsetof(FSubmixEffectReverbSettings, AirAbsorptionGainHF) == 0x24, "Offset mismatch for FSubmixEffectReverbSettings::AirAbsorptionGainHF");
static_assert(offsetof(FSubmixEffectReverbSettings, DecayHFRatio) == 0x28, "Offset mismatch for FSubmixEffectReverbSettings::DecayHFRatio");
static_assert(offsetof(FSubmixEffectReverbSettings, LateGain) == 0x2c, "Offset mismatch for FSubmixEffectReverbSettings::LateGain");
static_assert(offsetof(FSubmixEffectReverbSettings, Gain) == 0x30, "Offset mismatch for FSubmixEffectReverbSettings::Gain");
static_assert(offsetof(FSubmixEffectReverbSettings, WetLevel) == 0x34, "Offset mismatch for FSubmixEffectReverbSettings::WetLevel");
static_assert(offsetof(FSubmixEffectReverbSettings, DryLevel) == 0x38, "Offset mismatch for FSubmixEffectReverbSettings::DryLevel");
static_assert(offsetof(FSubmixEffectReverbSettings, bBypass) == 0x3c, "Offset mismatch for FSubmixEffectReverbSettings::bBypass");

