/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricDevices
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FabricFramework.h"
#include "FabricRuntime.h"
#include "FMCoreRuntime.h"
#include "HarmonixMetasound.h"

// Size: 0x178 (Inherited: 0x1d8, Single: 0xffffffa0)
class UFabricDeviceComponent : public UFabricDeviceComponentBase
{
public:
    bool bListenToMusicManagerEvents; // 0xf8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f9[0x7]; // 0xf9 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnTempoChangedDelegate[0x10]; // 0x100 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSpeedChangedDelegate[0x10]; // 0x110 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKeyChangedDelegate[0x10]; // 0x120 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnModeChangedDelegate[0x10]; // 0x130 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTimeSignatureChangedDelegate[0x10]; // 0x140 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TWeakObjectPtr<UFabricSpeakerManagerComponent*> SpeakerManager; // 0x150 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricMetaSoundManagerComponent*> MetaSoundManager; // 0x158 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFMCoreMusicManagerComponent*> MusicManager; // 0x160 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMusicClockComponent*> MusicClock; // 0x168 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMusicTempometerComponent*> MusicTempometer; // 0x170 (Size: 0x8, Type: WeakObjectProperty)

public:
    UFabricMetaSoundManagerComponent* GetMetaSoundManager() const; // 0x11e2ba54 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMusicClockComponent* GetMusicClock() const; // 0x11e2ba80 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFMCoreMusicManagerComponent* GetMusicManager() const; // 0x11e2baac (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMusicTempometerComponent* GetMusicTempometer() const; // 0x11e2bad8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFabricSpeakerManagerComponent* GetSpeakerManager() const; // 0x11e2bb04 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void OnKeyChanged(EMusicKey& Key); // 0x11e2bb30 (Index: 0x5, Flags: Final|Native|Protected)
    void OnModeChanged(EMusicKeyMode& Mode); // 0x11e2bc68 (Index: 0x6, Flags: Final|Native|Protected)
    void OnSpeedChanged(float& Speed); // 0x11e2bda0 (Index: 0x7, Flags: Final|Native|Protected)
    void OnTempoChanged(float& Tempo); // 0x11e2bedc (Index: 0x8, Flags: Final|Native|Protected)
    void OnTimeSignatureChanged(FFMCoreTimeSignature& TimeSignature); // 0x11e2c018 (Index: 0x9, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFabricDeviceComponent) == 0x178, "Size mismatch for UFabricDeviceComponent");
static_assert(offsetof(UFabricDeviceComponent, bListenToMusicManagerEvents) == 0xf8, "Offset mismatch for UFabricDeviceComponent::bListenToMusicManagerEvents");
static_assert(offsetof(UFabricDeviceComponent, OnTempoChangedDelegate) == 0x100, "Offset mismatch for UFabricDeviceComponent::OnTempoChangedDelegate");
static_assert(offsetof(UFabricDeviceComponent, OnSpeedChangedDelegate) == 0x110, "Offset mismatch for UFabricDeviceComponent::OnSpeedChangedDelegate");
static_assert(offsetof(UFabricDeviceComponent, OnKeyChangedDelegate) == 0x120, "Offset mismatch for UFabricDeviceComponent::OnKeyChangedDelegate");
static_assert(offsetof(UFabricDeviceComponent, OnModeChangedDelegate) == 0x130, "Offset mismatch for UFabricDeviceComponent::OnModeChangedDelegate");
static_assert(offsetof(UFabricDeviceComponent, OnTimeSignatureChangedDelegate) == 0x140, "Offset mismatch for UFabricDeviceComponent::OnTimeSignatureChangedDelegate");
static_assert(offsetof(UFabricDeviceComponent, SpeakerManager) == 0x150, "Offset mismatch for UFabricDeviceComponent::SpeakerManager");
static_assert(offsetof(UFabricDeviceComponent, MetaSoundManager) == 0x158, "Offset mismatch for UFabricDeviceComponent::MetaSoundManager");
static_assert(offsetof(UFabricDeviceComponent, MusicManager) == 0x160, "Offset mismatch for UFabricDeviceComponent::MusicManager");
static_assert(offsetof(UFabricDeviceComponent, MusicClock) == 0x168, "Offset mismatch for UFabricDeviceComponent::MusicClock");
static_assert(offsetof(UFabricDeviceComponent, MusicTempometer) == 0x170, "Offset mismatch for UFabricDeviceComponent::MusicTempometer");

