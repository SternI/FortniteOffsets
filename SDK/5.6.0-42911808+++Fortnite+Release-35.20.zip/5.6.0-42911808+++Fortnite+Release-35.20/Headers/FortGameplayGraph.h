/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortGameplayGraph
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayGraph.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x130 (Inherited: 0x158, Single: 0xffffffd8)
class UFortConnectivityGraph : public UGraph
{
public:
};

static_assert(sizeof(UFortConnectivityGraph) == 0x130, "Size mismatch for UFortConnectivityGraph");

// Size: 0x150 (Inherited: 0x170, Single: 0xffffffe0)
class UFortConnectivityGraphIsland : public UGraphIsland
{
public:
    TSet<FGraphVertexHandle> SupportNodes; // 0x100 (Size: 0x50, Type: SetProperty)
};

static_assert(sizeof(UFortConnectivityGraphIsland) == 0x150, "Size mismatch for UFortConnectivityGraphIsland");
static_assert(offsetof(UFortConnectivityGraphIsland, SupportNodes) == 0x100, "Offset mismatch for UFortConnectivityGraphIsland::SupportNodes");

// Size: 0x118 (Inherited: 0x160, Single: 0xffffffb8)
class UFortConnectivityGraphVertex : public UGraphVertex
{
public:
    uint8_t Pad_f0[0x18]; // 0xf0 (Size: 0x18, Type: PaddingProperty)
    bool bIsIndependentlySupported; // 0x108 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_109[0x3]; // 0x109 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> ConnectionActor; // 0x10c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_114[0x4]; // 0x114 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortConnectivityGraphVertex) == 0x118, "Size mismatch for UFortConnectivityGraphVertex");
static_assert(offsetof(UFortConnectivityGraphVertex, bIsIndependentlySupported) == 0x108, "Offset mismatch for UFortConnectivityGraphVertex::bIsIndependentlySupported");
static_assert(offsetof(UFortConnectivityGraphVertex, ConnectionActor) == 0x10c, "Offset mismatch for UFortConnectivityGraphVertex::ConnectionActor");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FSerializableConnectivityGraphVertex
{
    bool bIsIndependentlySupported; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FSerializableConnectivityGraphVertex) == 0x1, "Size mismatch for FSerializableConnectivityGraphVertex");
static_assert(offsetof(FSerializableConnectivityGraphVertex, bIsIndependentlySupported) == 0x0, "Offset mismatch for FSerializableConnectivityGraphVertex::bIsIndependentlySupported");

// Size: 0xc8 (Inherited: 0x78, Single: 0x50)
struct FSerializableConnectivityGraph_v2 : FSerializableGraph
{
    TMap<FSerializableConnectivityGraphVertex, FGraphVertexHandle> ConnectivityVertexData; // 0x78 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FSerializableConnectivityGraph_v2) == 0xc8, "Size mismatch for FSerializableConnectivityGraph_v2");
static_assert(offsetof(FSerializableConnectivityGraph_v2, ConnectivityVertexData) == 0x78, "Offset mismatch for FSerializableConnectivityGraph_v2::ConnectivityVertexData");

