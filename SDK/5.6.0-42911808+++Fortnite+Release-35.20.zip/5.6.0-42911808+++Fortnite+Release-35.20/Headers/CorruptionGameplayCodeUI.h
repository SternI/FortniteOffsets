/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CorruptionGameplayCodeUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Enums.h"
#include "FortniteUI.h"

// Size: 0x358 (Inherited: 0xd98, Single: 0xfffff5c0)
class UFortPowerupReticleExtensionWidget : public UFortWeaponReticleExtensionWidgetBase
{
public:
    uint8_t LastPowerupHeatState; // 0x350 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_351[0x7]; // 0x351 (Size: 0x7, Type: PaddingProperty)

protected:
    float GetCurrentOverheatPercent() const; // 0x101bdb30 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    float GetCurrentOverheatValue() const; // 0x101bdb58 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    float GetOverheatingMaxValue() const; // 0x101bdb80 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortPowerupReticleExtensionWidget) == 0x358, "Size mismatch for UFortPowerupReticleExtensionWidget");
static_assert(offsetof(UFortPowerupReticleExtensionWidget, LastPowerupHeatState) == 0x350, "Offset mismatch for UFortPowerupReticleExtensionWidget::LastPowerupHeatState");

