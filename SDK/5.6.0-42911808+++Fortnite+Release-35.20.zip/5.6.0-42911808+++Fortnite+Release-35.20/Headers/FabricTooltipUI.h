/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricTooltipUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "ModelViewViewModel.h"
#include "FortniteUI.h"
#include "Engine.h"
#include "CommonUI.h"
#include "UMG.h"

// Size: 0x88 (Inherited: 0x90, Single: 0xfffffff8)
class UFabricTooltipViewModel : public UMVVMViewModelBase
{
public:
    FText Name; // 0x68 (Size: 0x10, Type: TextProperty)
    FText Description; // 0x78 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(UFabricTooltipViewModel) == 0x88, "Size mismatch for UFabricTooltipViewModel");
static_assert(offsetof(UFabricTooltipViewModel, Name) == 0x68, "Offset mismatch for UFabricTooltipViewModel::Name");
static_assert(offsetof(UFabricTooltipViewModel, Description) == 0x78, "Offset mismatch for UFabricTooltipViewModel::Description");

// Size: 0x420 (Inherited: 0xe08, Single: 0xfffff618)
class UFabricTooltipWidget : public UFortActorIndicatorWidget
{
public:
    bool bUseShortDescription; // 0x3c0 (Size: 0x1, Type: BoolProperty)
    bool bUseShortDescriptionWithTouch; // 0x3c1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3c2[0x2]; // 0x3c2 (Size: 0x2, Type: PaddingProperty)
    float ShortDescriptionHeight; // 0x3c4 (Size: 0x4, Type: FloatProperty)
    float ShowMoreThreshold; // 0x3c8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3cc[0x4]; // 0x3cc (Size: 0x4, Type: PaddingProperty)
    FText ShowMoreText; // 0x3d0 (Size: 0x10, Type: TextProperty)
    FText ShowLessText; // 0x3e0 (Size: 0x10, Type: TextProperty)
    UAthenaMarkerPointer* MarkerPointer; // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Description; // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_Description; // 0x400 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* Panel_ShowMorePrompt; // 0x408 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ShowMorePrompt; // 0x410 (Size: 0x8, Type: ObjectProperty)
    bool bShowingFullDescription; // 0x418 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_419[0x7]; // 0x419 (Size: 0x7, Type: PaddingProperty)

public:
    void InitTooltip(AActor*& TargetedActor, UPrimitiveComponent*& TargetedComponent); // 0x1117df94 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    virtual void ToggleShowMore(); // 0x1117e2c8 (Index: 0x2, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)

protected:
    void SetShowMore(bool& bShowingMore); // 0x1117e19c (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    void UpdateShowMore(); // 0x1117e2dc (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFabricTooltipWidget) == 0x420, "Size mismatch for UFabricTooltipWidget");
static_assert(offsetof(UFabricTooltipWidget, bUseShortDescription) == 0x3c0, "Offset mismatch for UFabricTooltipWidget::bUseShortDescription");
static_assert(offsetof(UFabricTooltipWidget, bUseShortDescriptionWithTouch) == 0x3c1, "Offset mismatch for UFabricTooltipWidget::bUseShortDescriptionWithTouch");
static_assert(offsetof(UFabricTooltipWidget, ShortDescriptionHeight) == 0x3c4, "Offset mismatch for UFabricTooltipWidget::ShortDescriptionHeight");
static_assert(offsetof(UFabricTooltipWidget, ShowMoreThreshold) == 0x3c8, "Offset mismatch for UFabricTooltipWidget::ShowMoreThreshold");
static_assert(offsetof(UFabricTooltipWidget, ShowMoreText) == 0x3d0, "Offset mismatch for UFabricTooltipWidget::ShowMoreText");
static_assert(offsetof(UFabricTooltipWidget, ShowLessText) == 0x3e0, "Offset mismatch for UFabricTooltipWidget::ShowLessText");
static_assert(offsetof(UFabricTooltipWidget, MarkerPointer) == 0x3f0, "Offset mismatch for UFabricTooltipWidget::MarkerPointer");
static_assert(offsetof(UFabricTooltipWidget, Text_Description) == 0x3f8, "Offset mismatch for UFabricTooltipWidget::Text_Description");
static_assert(offsetof(UFabricTooltipWidget, SizeBox_Description) == 0x400, "Offset mismatch for UFabricTooltipWidget::SizeBox_Description");
static_assert(offsetof(UFabricTooltipWidget, Panel_ShowMorePrompt) == 0x408, "Offset mismatch for UFabricTooltipWidget::Panel_ShowMorePrompt");
static_assert(offsetof(UFabricTooltipWidget, Text_ShowMorePrompt) == 0x410, "Offset mismatch for UFabricTooltipWidget::Text_ShowMorePrompt");
static_assert(offsetof(UFabricTooltipWidget, bShowingFullDescription) == 0x418, "Offset mismatch for UFabricTooltipWidget::bShowingFullDescription");

