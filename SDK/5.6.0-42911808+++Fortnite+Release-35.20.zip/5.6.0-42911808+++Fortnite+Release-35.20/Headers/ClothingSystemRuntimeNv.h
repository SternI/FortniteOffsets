/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ClothingSystemRuntimeNv
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ClothingSystemRuntimeCommon.h"
#include "ClothingSystemRuntimeInterface.h"
#include "CoreUObject.h"

// Size: 0x1a0 (Inherited: 0x78, Single: 0x128)
class UClothConfigNv : public UClothConfigCommon
{
public:
    uint8_t ClothingWindMethod; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    FClothConstraintSetupNv VerticalConstraint; // 0x2c (Size: 0x10, Type: StructProperty)
    FClothConstraintSetupNv HorizontalConstraint; // 0x3c (Size: 0x10, Type: StructProperty)
    FClothConstraintSetupNv BendConstraint; // 0x4c (Size: 0x10, Type: StructProperty)
    FClothConstraintSetupNv ShearConstraint; // 0x5c (Size: 0x10, Type: StructProperty)
    float SelfCollisionRadius; // 0x6c (Size: 0x4, Type: FloatProperty)
    float SelfCollisionStiffness; // 0x70 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionCullScale; // 0x74 (Size: 0x4, Type: FloatProperty)
    FVector Damping; // 0x78 (Size: 0x18, Type: StructProperty)
    float Friction; // 0x90 (Size: 0x4, Type: FloatProperty)
    float WindDragCoefficient; // 0x94 (Size: 0x4, Type: FloatProperty)
    float WindLiftCoefficient; // 0x98 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
    FVector LinearDrag; // 0xa0 (Size: 0x18, Type: StructProperty)
    FVector AngularDrag; // 0xb8 (Size: 0x18, Type: StructProperty)
    FVector LinearInertiaScale; // 0xd0 (Size: 0x18, Type: StructProperty)
    FVector AngularInertiaScale; // 0xe8 (Size: 0x18, Type: StructProperty)
    FVector CentrifugalInertiaScale; // 0x100 (Size: 0x18, Type: StructProperty)
    float SolverFrequency; // 0x118 (Size: 0x4, Type: FloatProperty)
    float StiffnessFrequency; // 0x11c (Size: 0x4, Type: FloatProperty)
    float GravityScale; // 0x120 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_124[0x4]; // 0x124 (Size: 0x4, Type: PaddingProperty)
    FVector GravityOverride; // 0x128 (Size: 0x18, Type: StructProperty)
    bool bUseGravityOverride; // 0x140 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_141[0x3]; // 0x141 (Size: 0x3, Type: PaddingProperty)
    float TetherStiffness; // 0x144 (Size: 0x4, Type: FloatProperty)
    float TetherLimit; // 0x148 (Size: 0x4, Type: FloatProperty)
    float CollisionThickness; // 0x14c (Size: 0x4, Type: FloatProperty)
    float AnimDriveSpringStiffness; // 0x150 (Size: 0x4, Type: FloatProperty)
    float AnimDriveDamperStiffness; // 0x154 (Size: 0x4, Type: FloatProperty)
    uint8_t WindMethod; // 0x158 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_159[0x3]; // 0x159 (Size: 0x3, Type: PaddingProperty)
    FClothConstraintSetup_Legacy VerticalConstraintConfig; // 0x15c (Size: 0x10, Type: StructProperty)
    FClothConstraintSetup_Legacy HorizontalConstraintConfig; // 0x16c (Size: 0x10, Type: StructProperty)
    FClothConstraintSetup_Legacy BendConstraintConfig; // 0x17c (Size: 0x10, Type: StructProperty)
    FClothConstraintSetup_Legacy ShearConstraintConfig; // 0x18c (Size: 0x10, Type: StructProperty)
    uint8_t Pad_19c[0x4]; // 0x19c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UClothConfigNv) == 0x1a0, "Size mismatch for UClothConfigNv");
static_assert(offsetof(UClothConfigNv, ClothingWindMethod) == 0x28, "Offset mismatch for UClothConfigNv::ClothingWindMethod");
static_assert(offsetof(UClothConfigNv, VerticalConstraint) == 0x2c, "Offset mismatch for UClothConfigNv::VerticalConstraint");
static_assert(offsetof(UClothConfigNv, HorizontalConstraint) == 0x3c, "Offset mismatch for UClothConfigNv::HorizontalConstraint");
static_assert(offsetof(UClothConfigNv, BendConstraint) == 0x4c, "Offset mismatch for UClothConfigNv::BendConstraint");
static_assert(offsetof(UClothConfigNv, ShearConstraint) == 0x5c, "Offset mismatch for UClothConfigNv::ShearConstraint");
static_assert(offsetof(UClothConfigNv, SelfCollisionRadius) == 0x6c, "Offset mismatch for UClothConfigNv::SelfCollisionRadius");
static_assert(offsetof(UClothConfigNv, SelfCollisionStiffness) == 0x70, "Offset mismatch for UClothConfigNv::SelfCollisionStiffness");
static_assert(offsetof(UClothConfigNv, SelfCollisionCullScale) == 0x74, "Offset mismatch for UClothConfigNv::SelfCollisionCullScale");
static_assert(offsetof(UClothConfigNv, Damping) == 0x78, "Offset mismatch for UClothConfigNv::Damping");
static_assert(offsetof(UClothConfigNv, Friction) == 0x90, "Offset mismatch for UClothConfigNv::Friction");
static_assert(offsetof(UClothConfigNv, WindDragCoefficient) == 0x94, "Offset mismatch for UClothConfigNv::WindDragCoefficient");
static_assert(offsetof(UClothConfigNv, WindLiftCoefficient) == 0x98, "Offset mismatch for UClothConfigNv::WindLiftCoefficient");
static_assert(offsetof(UClothConfigNv, LinearDrag) == 0xa0, "Offset mismatch for UClothConfigNv::LinearDrag");
static_assert(offsetof(UClothConfigNv, AngularDrag) == 0xb8, "Offset mismatch for UClothConfigNv::AngularDrag");
static_assert(offsetof(UClothConfigNv, LinearInertiaScale) == 0xd0, "Offset mismatch for UClothConfigNv::LinearInertiaScale");
static_assert(offsetof(UClothConfigNv, AngularInertiaScale) == 0xe8, "Offset mismatch for UClothConfigNv::AngularInertiaScale");
static_assert(offsetof(UClothConfigNv, CentrifugalInertiaScale) == 0x100, "Offset mismatch for UClothConfigNv::CentrifugalInertiaScale");
static_assert(offsetof(UClothConfigNv, SolverFrequency) == 0x118, "Offset mismatch for UClothConfigNv::SolverFrequency");
static_assert(offsetof(UClothConfigNv, StiffnessFrequency) == 0x11c, "Offset mismatch for UClothConfigNv::StiffnessFrequency");
static_assert(offsetof(UClothConfigNv, GravityScale) == 0x120, "Offset mismatch for UClothConfigNv::GravityScale");
static_assert(offsetof(UClothConfigNv, GravityOverride) == 0x128, "Offset mismatch for UClothConfigNv::GravityOverride");
static_assert(offsetof(UClothConfigNv, bUseGravityOverride) == 0x140, "Offset mismatch for UClothConfigNv::bUseGravityOverride");
static_assert(offsetof(UClothConfigNv, TetherStiffness) == 0x144, "Offset mismatch for UClothConfigNv::TetherStiffness");
static_assert(offsetof(UClothConfigNv, TetherLimit) == 0x148, "Offset mismatch for UClothConfigNv::TetherLimit");
static_assert(offsetof(UClothConfigNv, CollisionThickness) == 0x14c, "Offset mismatch for UClothConfigNv::CollisionThickness");
static_assert(offsetof(UClothConfigNv, AnimDriveSpringStiffness) == 0x150, "Offset mismatch for UClothConfigNv::AnimDriveSpringStiffness");
static_assert(offsetof(UClothConfigNv, AnimDriveDamperStiffness) == 0x154, "Offset mismatch for UClothConfigNv::AnimDriveDamperStiffness");
static_assert(offsetof(UClothConfigNv, WindMethod) == 0x158, "Offset mismatch for UClothConfigNv::WindMethod");
static_assert(offsetof(UClothConfigNv, VerticalConstraintConfig) == 0x15c, "Offset mismatch for UClothConfigNv::VerticalConstraintConfig");
static_assert(offsetof(UClothConfigNv, HorizontalConstraintConfig) == 0x16c, "Offset mismatch for UClothConfigNv::HorizontalConstraintConfig");
static_assert(offsetof(UClothConfigNv, BendConstraintConfig) == 0x17c, "Offset mismatch for UClothConfigNv::BendConstraintConfig");
static_assert(offsetof(UClothConfigNv, ShearConstraintConfig) == 0x18c, "Offset mismatch for UClothConfigNv::ShearConstraintConfig");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UClothingSimulationFactoryNv : public UClothingSimulationFactory
{
public:
};

static_assert(sizeof(UClothingSimulationFactoryNv) == 0x28, "Size mismatch for UClothingSimulationFactoryNv");

// Size: 0x90 (Inherited: 0xb8, Single: 0xffffffd8)
class UClothingSimulationInteractorNv : public UClothingSimulationInteractor
{
public:

public:
    void SetAnimDriveDamperStiffness(float& InStiffness); // 0xa35c334 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UClothingSimulationInteractorNv) == 0x90, "Size mismatch for UClothingSimulationInteractorNv");

// Size: 0x120 (Inherited: 0x108, Single: 0x18)
class UClothPhysicalMeshDataNv_Legacy : public UClothPhysicalMeshDataBase_Legacy
{
public:
    TArray<float> MaxDistances; // 0xe0 (Size: 0x10, Type: ArrayProperty)
    TArray<float> BackstopDistances; // 0xf0 (Size: 0x10, Type: ArrayProperty)
    TArray<float> BackstopRadiuses; // 0x100 (Size: 0x10, Type: ArrayProperty)
    TArray<float> AnimDriveMultipliers; // 0x110 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UClothPhysicalMeshDataNv_Legacy) == 0x120, "Size mismatch for UClothPhysicalMeshDataNv_Legacy");
static_assert(offsetof(UClothPhysicalMeshDataNv_Legacy, MaxDistances) == 0xe0, "Offset mismatch for UClothPhysicalMeshDataNv_Legacy::MaxDistances");
static_assert(offsetof(UClothPhysicalMeshDataNv_Legacy, BackstopDistances) == 0xf0, "Offset mismatch for UClothPhysicalMeshDataNv_Legacy::BackstopDistances");
static_assert(offsetof(UClothPhysicalMeshDataNv_Legacy, BackstopRadiuses) == 0x100, "Offset mismatch for UClothPhysicalMeshDataNv_Legacy::BackstopRadiuses");
static_assert(offsetof(UClothPhysicalMeshDataNv_Legacy, AnimDriveMultipliers) == 0x110, "Offset mismatch for UClothPhysicalMeshDataNv_Legacy::AnimDriveMultipliers");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FClothConstraintSetupNv
{
    float Stiffness; // 0x0 (Size: 0x4, Type: FloatProperty)
    float StiffnessMultiplier; // 0x4 (Size: 0x4, Type: FloatProperty)
    float StretchLimit; // 0x8 (Size: 0x4, Type: FloatProperty)
    float CompressionLimit; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FClothConstraintSetupNv) == 0x10, "Size mismatch for FClothConstraintSetupNv");
static_assert(offsetof(FClothConstraintSetupNv, Stiffness) == 0x0, "Offset mismatch for FClothConstraintSetupNv::Stiffness");
static_assert(offsetof(FClothConstraintSetupNv, StiffnessMultiplier) == 0x4, "Offset mismatch for FClothConstraintSetupNv::StiffnessMultiplier");
static_assert(offsetof(FClothConstraintSetupNv, StretchLimit) == 0x8, "Offset mismatch for FClothConstraintSetupNv::StretchLimit");
static_assert(offsetof(FClothConstraintSetupNv, CompressionLimit) == 0xc, "Offset mismatch for FClothConstraintSetupNv::CompressionLimit");

