/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaVideoWidgetBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "CommonUI.h"
#include "EpicMediaBasePlayer.h"
#include "Engine.h"
#include "UMG.h"
#include "MediaAssets.h"

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UEpicMediaVideoWidgetConfig : public UObject
{
public:
    FString MediaID; // 0x28 (Size: 0x10, Type: StrProperty)
    FString MediaName; // 0x38 (Size: 0x10, Type: StrProperty)
    char PerfControl; // 0x48 (Size: 0x1, Type: ByteProperty)
    bool bAllowSkipping; // 0x49 (Size: 0x1, Type: BoolProperty)
    bool bHoldToSkip; // 0x4a (Size: 0x1, Type: BoolProperty)
    bool bHideControls; // 0x4b (Size: 0x1, Type: BoolProperty)
    bool bAutoPlay; // 0x4c (Size: 0x1, Type: BoolProperty)
    bool bLoop; // 0x4d (Size: 0x1, Type: BoolProperty)
    bool bNoAudio; // 0x4e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4f[0x1]; // 0x4f (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(UEpicMediaVideoWidgetConfig) == 0x50, "Size mismatch for UEpicMediaVideoWidgetConfig");
static_assert(offsetof(UEpicMediaVideoWidgetConfig, MediaID) == 0x28, "Offset mismatch for UEpicMediaVideoWidgetConfig::MediaID");
static_assert(offsetof(UEpicMediaVideoWidgetConfig, MediaName) == 0x38, "Offset mismatch for UEpicMediaVideoWidgetConfig::MediaName");
static_assert(offsetof(UEpicMediaVideoWidgetConfig, PerfControl) == 0x48, "Offset mismatch for UEpicMediaVideoWidgetConfig::PerfControl");
static_assert(offsetof(UEpicMediaVideoWidgetConfig, bAllowSkipping) == 0x49, "Offset mismatch for UEpicMediaVideoWidgetConfig::bAllowSkipping");
static_assert(offsetof(UEpicMediaVideoWidgetConfig, bHoldToSkip) == 0x4a, "Offset mismatch for UEpicMediaVideoWidgetConfig::bHoldToSkip");
static_assert(offsetof(UEpicMediaVideoWidgetConfig, bHideControls) == 0x4b, "Offset mismatch for UEpicMediaVideoWidgetConfig::bHideControls");
static_assert(offsetof(UEpicMediaVideoWidgetConfig, bAutoPlay) == 0x4c, "Offset mismatch for UEpicMediaVideoWidgetConfig::bAutoPlay");
static_assert(offsetof(UEpicMediaVideoWidgetConfig, bLoop) == 0x4d, "Offset mismatch for UEpicMediaVideoWidgetConfig::bLoop");
static_assert(offsetof(UEpicMediaVideoWidgetConfig, bNoAudio) == 0x4e, "Offset mismatch for UEpicMediaVideoWidgetConfig::bNoAudio");

// Size: 0x4b0 (Inherited: 0xb38, Single: 0xfffff978)
class UEpicMediaVideoWidgetBase : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x18]; // 0x408 (Size: 0x18, Type: PaddingProperty)
    UEpicBaseStreamingVideo* BasePlayer; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UEpicMediaVideoWidgetConfig* Config; // 0x428 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle PressToSkipAction; // 0x430 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle HoldToSkipAction; // 0x440 (Size: 0x10, Type: StructProperty)
    UCommonButtonBase* Button_Skip; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UMediaTexture* MediaTexture; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Throbber; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UMediaSoundComponent* SoundComponent; // 0x468 (Size: 0x8, Type: ObjectProperty)
    USoundMix* ActiveSoundMix; // 0x470 (Size: 0x8, Type: ObjectProperty)
    USoundSubmixBase* DefaultSubmix; // 0x478 (Size: 0x8, Type: ObjectProperty)
    USoundClass* SoundClass; // 0x480 (Size: 0x8, Type: ObjectProperty)
    USoundSubmixBase* LicensedSubmix; // 0x488 (Size: 0x8, Type: ObjectProperty)
    bool bAutoBroadcastRebuild; // 0x490 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_491[0x1f]; // 0x491 (Size: 0x1f, Type: PaddingProperty)

public:
    UEpicBaseStreamingVideo* GetBasePlayer(); // 0xec9a100 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool Init(); // 0xca98820 (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    void Play(); // 0xb4a85b4 (Index: 0x4, Flags: Native|Public|BlueprintCallable)
    void SetActiveSoundMix(USoundMix*& InActiveSoundMix); // 0xf14145c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    bool SetConfig(UEpicMediaVideoWidgetConfig*& InConfig); // 0xf141734 (Index: 0x6, Flags: Native|Public|BlueprintCallable)
    void SetSoundClass(USoundClass*& InSoundClass); // 0xde9da38 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void Stop(); // 0xc019b98 (Index: 0x8, Flags: Native|Public|BlueprintCallable)

private:
    void MediaEnded(); // 0x58f6d9c (Index: 0x2, Flags: Final|Native|Private)

protected:
    void MetadataSuccess(); // 0xeb6b8b4 (Index: 0x3, Flags: Native|Protected)
    void TerminalError(EBaseMediaTerminalErrorReason& Reason); // 0xf141874 (Index: 0x9, Flags: Native|Protected)
};

static_assert(sizeof(UEpicMediaVideoWidgetBase) == 0x4b0, "Size mismatch for UEpicMediaVideoWidgetBase");
static_assert(offsetof(UEpicMediaVideoWidgetBase, BasePlayer) == 0x420, "Offset mismatch for UEpicMediaVideoWidgetBase::BasePlayer");
static_assert(offsetof(UEpicMediaVideoWidgetBase, Config) == 0x428, "Offset mismatch for UEpicMediaVideoWidgetBase::Config");
static_assert(offsetof(UEpicMediaVideoWidgetBase, PressToSkipAction) == 0x430, "Offset mismatch for UEpicMediaVideoWidgetBase::PressToSkipAction");
static_assert(offsetof(UEpicMediaVideoWidgetBase, HoldToSkipAction) == 0x440, "Offset mismatch for UEpicMediaVideoWidgetBase::HoldToSkipAction");
static_assert(offsetof(UEpicMediaVideoWidgetBase, Button_Skip) == 0x450, "Offset mismatch for UEpicMediaVideoWidgetBase::Button_Skip");
static_assert(offsetof(UEpicMediaVideoWidgetBase, MediaTexture) == 0x458, "Offset mismatch for UEpicMediaVideoWidgetBase::MediaTexture");
static_assert(offsetof(UEpicMediaVideoWidgetBase, Image_Throbber) == 0x460, "Offset mismatch for UEpicMediaVideoWidgetBase::Image_Throbber");
static_assert(offsetof(UEpicMediaVideoWidgetBase, SoundComponent) == 0x468, "Offset mismatch for UEpicMediaVideoWidgetBase::SoundComponent");
static_assert(offsetof(UEpicMediaVideoWidgetBase, ActiveSoundMix) == 0x470, "Offset mismatch for UEpicMediaVideoWidgetBase::ActiveSoundMix");
static_assert(offsetof(UEpicMediaVideoWidgetBase, DefaultSubmix) == 0x478, "Offset mismatch for UEpicMediaVideoWidgetBase::DefaultSubmix");
static_assert(offsetof(UEpicMediaVideoWidgetBase, SoundClass) == 0x480, "Offset mismatch for UEpicMediaVideoWidgetBase::SoundClass");
static_assert(offsetof(UEpicMediaVideoWidgetBase, LicensedSubmix) == 0x488, "Offset mismatch for UEpicMediaVideoWidgetBase::LicensedSubmix");
static_assert(offsetof(UEpicMediaVideoWidgetBase, bAutoBroadcastRebuild) == 0x490, "Offset mismatch for UEpicMediaVideoWidgetBase::bAutoBroadcastRebuild");

