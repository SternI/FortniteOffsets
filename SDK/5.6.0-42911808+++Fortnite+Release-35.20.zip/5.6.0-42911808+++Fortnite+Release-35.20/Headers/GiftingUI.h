/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GiftingUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "FortniteUI.h"
#include "CommonUILegacy.h"
#include "SocialUMG.h"
#include "FortniteGame.h"
#include "GameSubCatalog.h"
#include "Engine.h"

// Size: 0x438 (Inherited: 0xb38, Single: 0xfffff900)
class UAthenaGiftConfirmedPanel : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x18]; // 0x408 (Size: 0x18, Type: PaddingProperty)
    URichTextBlock* Text_RecipientInfo; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch; // 0x430 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UAthenaGiftConfirmedPanel) == 0x438, "Size mismatch for UAthenaGiftConfirmedPanel");
static_assert(offsetof(UAthenaGiftConfirmedPanel, Text_RecipientInfo) == 0x420, "Offset mismatch for UAthenaGiftConfirmedPanel::Text_RecipientInfo");
static_assert(offsetof(UAthenaGiftConfirmedPanel, Button_Back) == 0x428, "Offset mismatch for UAthenaGiftConfirmedPanel::Button_Back");
static_assert(offsetof(UAthenaGiftConfirmedPanel, Button_CloseTouch) == 0x430, "Offset mismatch for UAthenaGiftConfirmedPanel::Button_CloseTouch");

// Size: 0x558 (Inherited: 0xb38, Single: 0xfffffa20)
class UAthenaGiftingConfirmationScreen : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x30]; // 0x408 (Size: 0x30, Type: PaddingProperty)
    UFortStoreFrontOfferInfo* PresentedGiftableOfferInfo; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UFortStoreFrontOfferInfo* PresentedOptionalTokenOfferInfo; // 0x440 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_448[0xb4]; // 0x448 (Size: 0xb4, Type: PaddingProperty)
    float MinGiftSubmissionDelay; // 0x4fc (Size: 0x4, Type: FloatProperty)
    float MaxGiftSubmissionDelay; // 0x500 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_504[0x14]; // 0x504 (Size: 0x14, Type: PaddingProperty)
    UCommonButtonBase* Button_WrapOptions; // 0x518 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back; // 0x520 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch; // 0x528 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_MtxWallet; // 0x530 (Size: 0x8, Type: ObjectProperty)
    UAthenaGiftingPurchasePanel* Panel_GiftingPurchase; // 0x538 (Size: 0x8, Type: ObjectProperty)
    UAthenaGiftingWrapOptionsPanel* Panel_WrapOptions; // 0x540 (Size: 0x8, Type: ObjectProperty)
    UAthenaGiftConfirmedPanel* Panel_GiftConfirmed; // 0x548 (Size: 0x8, Type: ObjectProperty)
    UAthenaGiftingErrorsPanel* Panel_GiftingErrors; // 0x550 (Size: 0x8, Type: ObjectProperty)

private:
    void Dismiss(bool& const bGiftConfirmed); // 0x1112009c (Index: 0x0, Flags: Final|Native|Private|BlueprintCallable)
    void HandleGiftSent(bool& bSuccess, const TArray<FString> IneligibleAccounts, const TArray<FString> ErrorCodes); // 0x111201e4 (Index: 0x1, Flags: Final|Native|Private|HasOutParms)
    void HandleTokenOfferPurchaseComplete(bool& bSuccess, const TArray<FPurchasedItemInfo> PurchasedItems); // 0x11120a9c (Index: 0x2, Flags: Final|Native|Private|HasOutParms)

protected:
    virtual void OnPresentationModeChanged(EGiftingPresentationMode& NewMode); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UAthenaGiftingConfirmationScreen) == 0x558, "Size mismatch for UAthenaGiftingConfirmationScreen");
static_assert(offsetof(UAthenaGiftingConfirmationScreen, PresentedGiftableOfferInfo) == 0x438, "Offset mismatch for UAthenaGiftingConfirmationScreen::PresentedGiftableOfferInfo");
static_assert(offsetof(UAthenaGiftingConfirmationScreen, PresentedOptionalTokenOfferInfo) == 0x440, "Offset mismatch for UAthenaGiftingConfirmationScreen::PresentedOptionalTokenOfferInfo");
static_assert(offsetof(UAthenaGiftingConfirmationScreen, MinGiftSubmissionDelay) == 0x4fc, "Offset mismatch for UAthenaGiftingConfirmationScreen::MinGiftSubmissionDelay");
static_assert(offsetof(UAthenaGiftingConfirmationScreen, MaxGiftSubmissionDelay) == 0x500, "Offset mismatch for UAthenaGiftingConfirmationScreen::MaxGiftSubmissionDelay");
static_assert(offsetof(UAthenaGiftingConfirmationScreen, Button_WrapOptions) == 0x518, "Offset mismatch for UAthenaGiftingConfirmationScreen::Button_WrapOptions");
static_assert(offsetof(UAthenaGiftingConfirmationScreen, Button_Back) == 0x520, "Offset mismatch for UAthenaGiftingConfirmationScreen::Button_Back");
static_assert(offsetof(UAthenaGiftingConfirmationScreen, Button_CloseTouch) == 0x528, "Offset mismatch for UAthenaGiftingConfirmationScreen::Button_CloseTouch");
static_assert(offsetof(UAthenaGiftingConfirmationScreen, Button_MtxWallet) == 0x530, "Offset mismatch for UAthenaGiftingConfirmationScreen::Button_MtxWallet");
static_assert(offsetof(UAthenaGiftingConfirmationScreen, Panel_GiftingPurchase) == 0x538, "Offset mismatch for UAthenaGiftingConfirmationScreen::Panel_GiftingPurchase");
static_assert(offsetof(UAthenaGiftingConfirmationScreen, Panel_WrapOptions) == 0x540, "Offset mismatch for UAthenaGiftingConfirmationScreen::Panel_WrapOptions");
static_assert(offsetof(UAthenaGiftingConfirmationScreen, Panel_GiftConfirmed) == 0x548, "Offset mismatch for UAthenaGiftingConfirmationScreen::Panel_GiftConfirmed");
static_assert(offsetof(UAthenaGiftingConfirmationScreen, Panel_GiftingErrors) == 0x550, "Offset mismatch for UAthenaGiftingConfirmationScreen::Panel_GiftingErrors");

// Size: 0x468 (Inherited: 0xb38, Single: 0xfffff930)
class UAthenaGiftingErrorsPanel : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x30]; // 0x408 (Size: 0x30, Type: PaddingProperty)
    URichTextBlock* Text_RecipientInfo; // 0x438 (Size: 0x8, Type: ObjectProperty)
    URichTextBlock* Text_Title; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Continue; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UTileView* TileView_Items; // 0x460 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void UpdateGiftEligibility(bool& bStillGiftable); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UAthenaGiftingErrorsPanel) == 0x468, "Size mismatch for UAthenaGiftingErrorsPanel");
static_assert(offsetof(UAthenaGiftingErrorsPanel, Text_RecipientInfo) == 0x438, "Offset mismatch for UAthenaGiftingErrorsPanel::Text_RecipientInfo");
static_assert(offsetof(UAthenaGiftingErrorsPanel, Text_Title) == 0x440, "Offset mismatch for UAthenaGiftingErrorsPanel::Text_Title");
static_assert(offsetof(UAthenaGiftingErrorsPanel, Button_CloseTouch) == 0x448, "Offset mismatch for UAthenaGiftingErrorsPanel::Button_CloseTouch");
static_assert(offsetof(UAthenaGiftingErrorsPanel, Button_Back) == 0x450, "Offset mismatch for UAthenaGiftingErrorsPanel::Button_Back");
static_assert(offsetof(UAthenaGiftingErrorsPanel, Button_Continue) == 0x458, "Offset mismatch for UAthenaGiftingErrorsPanel::Button_Continue");
static_assert(offsetof(UAthenaGiftingErrorsPanel, TileView_Items) == 0x460, "Offset mismatch for UAthenaGiftingErrorsPanel::TileView_Items");

// Size: 0x2f8 (Inherited: 0x730, Single: 0xfffffbc8)
class UAthenaGiftingPriceWidget : public UCommonUserWidget
{
public:
    UCommonTextBlock* Text_RealMoneyPrice; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_FinalPrice; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_RegularPrice; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UWidget* Overlay_SalePrice; // 0x2f0 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void SetPresentationMode(EGiftingPricePresentationMode& Mode); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UAthenaGiftingPriceWidget) == 0x2f8, "Size mismatch for UAthenaGiftingPriceWidget");
static_assert(offsetof(UAthenaGiftingPriceWidget, Text_RealMoneyPrice) == 0x2d8, "Offset mismatch for UAthenaGiftingPriceWidget::Text_RealMoneyPrice");
static_assert(offsetof(UAthenaGiftingPriceWidget, Text_FinalPrice) == 0x2e0, "Offset mismatch for UAthenaGiftingPriceWidget::Text_FinalPrice");
static_assert(offsetof(UAthenaGiftingPriceWidget, Text_RegularPrice) == 0x2e8, "Offset mismatch for UAthenaGiftingPriceWidget::Text_RegularPrice");
static_assert(offsetof(UAthenaGiftingPriceWidget, Overlay_SalePrice) == 0x2f0, "Offset mismatch for UAthenaGiftingPriceWidget::Overlay_SalePrice");

// Size: 0x1550 (Inherited: 0x3110, Single: 0xffffe440)
class UAthenaGiftingPurchaseButton : public UFortHoldableButton
{
public:
    UAthenaGiftingPriceWidget* Widget_Price; // 0x1538 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Title; // 0x1540 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1548[0x8]; // 0x1548 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UAthenaGiftingPurchaseButton) == 0x1550, "Size mismatch for UAthenaGiftingPurchaseButton");
static_assert(offsetof(UAthenaGiftingPurchaseButton, Widget_Price) == 0x1538, "Offset mismatch for UAthenaGiftingPurchaseButton::Widget_Price");
static_assert(offsetof(UAthenaGiftingPurchaseButton, Text_Title) == 0x1540, "Offset mismatch for UAthenaGiftingPurchaseButton::Text_Title");

// Size: 0x450 (Inherited: 0xb38, Single: 0xfffff918)
class UAthenaGiftingPurchasePanel : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x18]; // 0x408 (Size: 0x18, Type: PaddingProperty)
    UAthenaGiftingPurchaseButton* Button_PurchaseGift; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UFortSocialAvatarIcon* Avatar_MemberIcon; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_SocialNameInfo; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ItemsCount; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_OfferName; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UTileView* TileView_Items; // 0x448 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void PlayIntroAnimation(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UAthenaGiftingPurchasePanel) == 0x450, "Size mismatch for UAthenaGiftingPurchasePanel");
static_assert(offsetof(UAthenaGiftingPurchasePanel, Button_PurchaseGift) == 0x420, "Offset mismatch for UAthenaGiftingPurchasePanel::Button_PurchaseGift");
static_assert(offsetof(UAthenaGiftingPurchasePanel, Avatar_MemberIcon) == 0x428, "Offset mismatch for UAthenaGiftingPurchasePanel::Avatar_MemberIcon");
static_assert(offsetof(UAthenaGiftingPurchasePanel, Text_SocialNameInfo) == 0x430, "Offset mismatch for UAthenaGiftingPurchasePanel::Text_SocialNameInfo");
static_assert(offsetof(UAthenaGiftingPurchasePanel, Text_ItemsCount) == 0x438, "Offset mismatch for UAthenaGiftingPurchasePanel::Text_ItemsCount");
static_assert(offsetof(UAthenaGiftingPurchasePanel, Text_OfferName) == 0x440, "Offset mismatch for UAthenaGiftingPurchasePanel::Text_OfferName");
static_assert(offsetof(UAthenaGiftingPurchasePanel, TileView_Items) == 0x448, "Offset mismatch for UAthenaGiftingPurchasePanel::TileView_Items");

// Size: 0xa00 (Inherited: 0x1e10, Single: 0xffffebf0)
class UAthenaGiftingScreen : public UFortItemPreviewScreen
{
public:
    uint8_t Pad_820[0x8]; // 0x820 (Size: 0x8, Type: PaddingProperty)
    UFortGiftingUserSearchWidget* SearchWidget_SocialSearchWidget; // 0x828 (Size: 0x8, Type: ObjectProperty)
    UFortGiftingSocialUserListView* ListView_Recipients; // 0x830 (Size: 0x8, Type: ObjectProperty)
    UTileView* TileView_Items; // 0x838 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Back; // 0x840 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch; // 0x848 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_GiftingPolicy; // 0x850 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CameraControl; // 0x858 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_OfferName; // 0x860 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_VBucksOffCount; // 0x868 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ShownItemIndex; // 0x870 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* Text_NoContent; // 0x878 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_OfferItemOwnedCount; // 0x880 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Container_VBucksOffViolator; // 0x888 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_GiftCount; // 0x890 (Size: 0x8, Type: ObjectProperty)
    UAthenaGiftingPriceWidget* Widget_Price; // 0x898 (Size: 0x8, Type: ObjectProperty)
    UAthenaLockerItemInfo* Widget_ItemInfo; // 0x8a0 (Size: 0x8, Type: ObjectProperty)
    UDynamicEntryBox* EntryBox_FilterTabs; // 0x8a8 (Size: 0x8, Type: ObjectProperty)
    UCommonActionWidget* ActionWidget_FilterTabsPrevious; // 0x8b0 (Size: 0x8, Type: ObjectProperty)
    UCommonActionWidget* ActionWidget_FilterTabsNext; // 0x8b8 (Size: 0x8, Type: ObjectProperty)
    UAthenaGiftingConfirmationScreen* ActivatableWidget_GiftingConfirmation; // 0x8c0 (Size: 0x8, Type: ObjectProperty)
    float ItemCyclingInterval; // 0x8c8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_8cc[0x4]; // 0x8cc (Size: 0x4, Type: PaddingProperty)
    FDataTableRowHandle FilterTabsPreviousAction; // 0x8d0 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle FilterTabsNextAction; // 0x8e0 (Size: 0x10, Type: StructProperty)
    FText RegularGiftingPolicy; // 0x8f0 (Size: 0x10, Type: TextProperty)
    FText BattlePassGiftingPolicy; // 0x900 (Size: 0x10, Type: TextProperty)
    uint8_t Pad_910[0x60]; // 0x910 (Size: 0x60, Type: PaddingProperty)
    TMap<EFilterType, UCommonButtonBase*> FilterMap; // 0x970 (Size: 0x50, Type: MapProperty)
    UCommonButtonGroupBase* FilterGroup; // 0x9c0 (Size: 0x8, Type: ObjectProperty)
    TArray<UFortItemVM*> GiftableItems; // 0x9c8 (Size: 0x10, Type: ArrayProperty)
    UFortItemDefinition* PresentedItemDefinition; // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    UFortStoreFrontOfferInfo* GiftableOfferInfo; // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    UFortStoreFrontOfferInfo* OptionalTokenOfferInfo; // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_9f0[0x8]; // 0x9f0 (Size: 0x8, Type: PaddingProperty)
    UFortItemShopOfferVM* OfferVM; // 0x9f8 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void BlockScreenContent(bool& const bBlockScreen, const FText ContentBlockedText); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    void HandleGrantedItemsLoaded(TArray<UFortItemVM*>& GrantedItems); // 0x11120454 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnFilterChanged(EFilterType& FilterType); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnFriendSelectionChanged(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnHandlePreviewItem(bool& bUseWidePreview); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPartyListUpdated(bool& bEmpty); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPresentationModeChanged(EGiftingScreenPresentationMode& Mode); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSetupFilterTabButton(UCommonButtonBase*& Button, EFilterType& FilterType); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void OnShownItemChanged(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void OnShowSearchWarningText(bool& bShow); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UAthenaGiftingScreen) == 0xa00, "Size mismatch for UAthenaGiftingScreen");
static_assert(offsetof(UAthenaGiftingScreen, SearchWidget_SocialSearchWidget) == 0x828, "Offset mismatch for UAthenaGiftingScreen::SearchWidget_SocialSearchWidget");
static_assert(offsetof(UAthenaGiftingScreen, ListView_Recipients) == 0x830, "Offset mismatch for UAthenaGiftingScreen::ListView_Recipients");
static_assert(offsetof(UAthenaGiftingScreen, TileView_Items) == 0x838, "Offset mismatch for UAthenaGiftingScreen::TileView_Items");
static_assert(offsetof(UAthenaGiftingScreen, Button_Back) == 0x840, "Offset mismatch for UAthenaGiftingScreen::Button_Back");
static_assert(offsetof(UAthenaGiftingScreen, Button_CloseTouch) == 0x848, "Offset mismatch for UAthenaGiftingScreen::Button_CloseTouch");
static_assert(offsetof(UAthenaGiftingScreen, Button_GiftingPolicy) == 0x850, "Offset mismatch for UAthenaGiftingScreen::Button_GiftingPolicy");
static_assert(offsetof(UAthenaGiftingScreen, Button_CameraControl) == 0x858, "Offset mismatch for UAthenaGiftingScreen::Button_CameraControl");
static_assert(offsetof(UAthenaGiftingScreen, Text_OfferName) == 0x860, "Offset mismatch for UAthenaGiftingScreen::Text_OfferName");
static_assert(offsetof(UAthenaGiftingScreen, Text_VBucksOffCount) == 0x868, "Offset mismatch for UAthenaGiftingScreen::Text_VBucksOffCount");
static_assert(offsetof(UAthenaGiftingScreen, Text_ShownItemIndex) == 0x870, "Offset mismatch for UAthenaGiftingScreen::Text_ShownItemIndex");
static_assert(offsetof(UAthenaGiftingScreen, Text_NoContent) == 0x878, "Offset mismatch for UAthenaGiftingScreen::Text_NoContent");
static_assert(offsetof(UAthenaGiftingScreen, RichText_OfferItemOwnedCount) == 0x880, "Offset mismatch for UAthenaGiftingScreen::RichText_OfferItemOwnedCount");
static_assert(offsetof(UAthenaGiftingScreen, Container_VBucksOffViolator) == 0x888, "Offset mismatch for UAthenaGiftingScreen::Container_VBucksOffViolator");
static_assert(offsetof(UAthenaGiftingScreen, RichText_GiftCount) == 0x890, "Offset mismatch for UAthenaGiftingScreen::RichText_GiftCount");
static_assert(offsetof(UAthenaGiftingScreen, Widget_Price) == 0x898, "Offset mismatch for UAthenaGiftingScreen::Widget_Price");
static_assert(offsetof(UAthenaGiftingScreen, Widget_ItemInfo) == 0x8a0, "Offset mismatch for UAthenaGiftingScreen::Widget_ItemInfo");
static_assert(offsetof(UAthenaGiftingScreen, EntryBox_FilterTabs) == 0x8a8, "Offset mismatch for UAthenaGiftingScreen::EntryBox_FilterTabs");
static_assert(offsetof(UAthenaGiftingScreen, ActionWidget_FilterTabsPrevious) == 0x8b0, "Offset mismatch for UAthenaGiftingScreen::ActionWidget_FilterTabsPrevious");
static_assert(offsetof(UAthenaGiftingScreen, ActionWidget_FilterTabsNext) == 0x8b8, "Offset mismatch for UAthenaGiftingScreen::ActionWidget_FilterTabsNext");
static_assert(offsetof(UAthenaGiftingScreen, ActivatableWidget_GiftingConfirmation) == 0x8c0, "Offset mismatch for UAthenaGiftingScreen::ActivatableWidget_GiftingConfirmation");
static_assert(offsetof(UAthenaGiftingScreen, ItemCyclingInterval) == 0x8c8, "Offset mismatch for UAthenaGiftingScreen::ItemCyclingInterval");
static_assert(offsetof(UAthenaGiftingScreen, FilterTabsPreviousAction) == 0x8d0, "Offset mismatch for UAthenaGiftingScreen::FilterTabsPreviousAction");
static_assert(offsetof(UAthenaGiftingScreen, FilterTabsNextAction) == 0x8e0, "Offset mismatch for UAthenaGiftingScreen::FilterTabsNextAction");
static_assert(offsetof(UAthenaGiftingScreen, RegularGiftingPolicy) == 0x8f0, "Offset mismatch for UAthenaGiftingScreen::RegularGiftingPolicy");
static_assert(offsetof(UAthenaGiftingScreen, BattlePassGiftingPolicy) == 0x900, "Offset mismatch for UAthenaGiftingScreen::BattlePassGiftingPolicy");
static_assert(offsetof(UAthenaGiftingScreen, FilterMap) == 0x970, "Offset mismatch for UAthenaGiftingScreen::FilterMap");
static_assert(offsetof(UAthenaGiftingScreen, FilterGroup) == 0x9c0, "Offset mismatch for UAthenaGiftingScreen::FilterGroup");
static_assert(offsetof(UAthenaGiftingScreen, GiftableItems) == 0x9c8, "Offset mismatch for UAthenaGiftingScreen::GiftableItems");
static_assert(offsetof(UAthenaGiftingScreen, PresentedItemDefinition) == 0x9d8, "Offset mismatch for UAthenaGiftingScreen::PresentedItemDefinition");
static_assert(offsetof(UAthenaGiftingScreen, GiftableOfferInfo) == 0x9e0, "Offset mismatch for UAthenaGiftingScreen::GiftableOfferInfo");
static_assert(offsetof(UAthenaGiftingScreen, OptionalTokenOfferInfo) == 0x9e8, "Offset mismatch for UAthenaGiftingScreen::OptionalTokenOfferInfo");
static_assert(offsetof(UAthenaGiftingScreen, OfferVM) == 0x9f8, "Offset mismatch for UAthenaGiftingScreen::OfferVM");

// Size: 0x470 (Inherited: 0xb38, Single: 0xfffff938)
class UAthenaGiftingWrapOptionsPanel : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x28]; // 0x408 (Size: 0x28, Type: PaddingProperty)
    TArray<TSoftObjectPtr<UFortGiftBoxItemDefinition*>> GiftBoxes; // 0x430 (Size: 0x10, Type: ArrayProperty)
    TArray<UFortGiftBoxItemDefinition*> GiftBoxItemDefs; // 0x440 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_450[0x10]; // 0x450 (Size: 0x10, Type: PaddingProperty)
    UCommonButtonLegacy* Button_ConfirmWrap; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UTileView* TileView_WrapOptions; // 0x468 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UAthenaGiftingWrapOptionsPanel) == 0x470, "Size mismatch for UAthenaGiftingWrapOptionsPanel");
static_assert(offsetof(UAthenaGiftingWrapOptionsPanel, GiftBoxes) == 0x430, "Offset mismatch for UAthenaGiftingWrapOptionsPanel::GiftBoxes");
static_assert(offsetof(UAthenaGiftingWrapOptionsPanel, GiftBoxItemDefs) == 0x440, "Offset mismatch for UAthenaGiftingWrapOptionsPanel::GiftBoxItemDefs");
static_assert(offsetof(UAthenaGiftingWrapOptionsPanel, Button_ConfirmWrap) == 0x460, "Offset mismatch for UAthenaGiftingWrapOptionsPanel::Button_ConfirmWrap");
static_assert(offsetof(UAthenaGiftingWrapOptionsPanel, TileView_WrapOptions) == 0x468, "Offset mismatch for UAthenaGiftingWrapOptionsPanel::TileView_WrapOptions");

// Size: 0x15f0 (Inherited: 0x45d0, Single: 0xffffd020)
class UFortGiftingSocialUserListEntry : public USocialListEntryBase
{
public:
    uint8_t Pad_1510[0xb0]; // 0x1510 (Size: 0xb0, Type: PaddingProperty)
    UFortSocialAvatarIcon* Avatar_MemberIcon; // 0x15c0 (Size: 0x8, Type: ObjectProperty)
    USocialNameTextBlock* Text_SocialName; // 0x15c8 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_EligibilityStatus; // 0x15d0 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* RichText_OwnedItems; // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    UAthenaGiftingPriceWidget* Widget_Price; // 0x15e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_15e8[0x8]; // 0x15e8 (Size: 0x8, Type: PaddingProperty)

protected:
    virtual void BP_OnHighlightedStateChanged(bool& bInIsHighlighted, bool& bPlayAnimation); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnTouchSelectionConfirmed(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRecipientStatusUpdated(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUserItemSet(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void SetPresentationMode(ERecipientPresentationMode& Mode); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortGiftingSocialUserListEntry) == 0x15f0, "Size mismatch for UFortGiftingSocialUserListEntry");
static_assert(offsetof(UFortGiftingSocialUserListEntry, Avatar_MemberIcon) == 0x15c0, "Offset mismatch for UFortGiftingSocialUserListEntry::Avatar_MemberIcon");
static_assert(offsetof(UFortGiftingSocialUserListEntry, Text_SocialName) == 0x15c8, "Offset mismatch for UFortGiftingSocialUserListEntry::Text_SocialName");
static_assert(offsetof(UFortGiftingSocialUserListEntry, RichText_EligibilityStatus) == 0x15d0, "Offset mismatch for UFortGiftingSocialUserListEntry::RichText_EligibilityStatus");
static_assert(offsetof(UFortGiftingSocialUserListEntry, RichText_OwnedItems) == 0x15d8, "Offset mismatch for UFortGiftingSocialUserListEntry::RichText_OwnedItems");
static_assert(offsetof(UFortGiftingSocialUserListEntry, Widget_Price) == 0x15e0, "Offset mismatch for UFortGiftingSocialUserListEntry::Widget_Price");

// Size: 0x498 (Inherited: 0x7d8, Single: 0xfffffcc0)
class UFortGiftingSocialUserListView : public USocialUserListViewBase
{
public:
    float RefreshRecipientStatusDelay; // 0x3a0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3a4[0xf4]; // 0x3a4 (Size: 0xf4, Type: PaddingProperty)
};

static_assert(sizeof(UFortGiftingSocialUserListView) == 0x498, "Size mismatch for UFortGiftingSocialUserListView");
static_assert(offsetof(UFortGiftingSocialUserListView, RefreshRecipientStatusDelay) == 0x3a0, "Offset mismatch for UFortGiftingSocialUserListView::RefreshRecipientStatusDelay");

// Size: 0x320 (Inherited: 0x730, Single: 0xfffffbf0)
class UFortGiftingUserSearchWidget : public UCommonUserWidget
{
public:
    UEditableText* EditableText_SearchFriends; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_ClearQuery; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_SubmitQuery; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2f0[0x30]; // 0x2f0 (Size: 0x30, Type: PaddingProperty)

private:
    void HandleSearchFriendsTextChanged(const FText Text); // 0x1112075c (Index: 0x1, Flags: Final|Native|Private|HasOutParms)
    void HandleSearchFriendsTextEntered(const FText Text, TEnumAsByte<ETextCommit>& CommitMethod); // 0x11120844 (Index: 0x2, Flags: Final|Native|Private|HasOutParms)

protected:
    void FocusEditableText(); // 0x111201c8 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnSearchCommit(bool& bSearchStringShort); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortGiftingUserSearchWidget) == 0x320, "Size mismatch for UFortGiftingUserSearchWidget");
static_assert(offsetof(UFortGiftingUserSearchWidget, EditableText_SearchFriends) == 0x2d8, "Offset mismatch for UFortGiftingUserSearchWidget::EditableText_SearchFriends");
static_assert(offsetof(UFortGiftingUserSearchWidget, Button_ClearQuery) == 0x2e0, "Offset mismatch for UFortGiftingUserSearchWidget::Button_ClearQuery");
static_assert(offsetof(UFortGiftingUserSearchWidget, Button_SubmitQuery) == 0x2e8, "Offset mismatch for UFortGiftingUserSearchWidget::Button_SubmitQuery");

// Size: 0x1510 (Inherited: 0x30c0, Single: 0xffffe450)
class UFortGiftingWrapOptionListEntry : public UCommonButtonLegacy
{
public:
    uint8_t Pad_14f0[0x8]; // 0x14f0 (Size: 0x8, Type: PaddingProperty)
    UFortGiftBoxItemDefinition* GiftBoxDefinition; // 0x14f8 (Size: 0x8, Type: ObjectProperty)
    UCommonLazyImage* Image_Gift; // 0x1500 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1508[0x8]; // 0x1508 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortGiftingWrapOptionListEntry) == 0x1510, "Size mismatch for UFortGiftingWrapOptionListEntry");
static_assert(offsetof(UFortGiftingWrapOptionListEntry, GiftBoxDefinition) == 0x14f8, "Offset mismatch for UFortGiftingWrapOptionListEntry::GiftBoxDefinition");
static_assert(offsetof(UFortGiftingWrapOptionListEntry, Image_Gift) == 0x1500, "Offset mismatch for UFortGiftingWrapOptionListEntry::Image_Gift");

// Size: 0x510 (Inherited: 0x5c8, Single: 0xffffff48)
class UFortGiftingData : public UFortGameFeatureData
{
public:
    TSoftClassPtr GiftingScreenClass; // 0x4f0 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UFortGiftingData) == 0x510, "Size mismatch for UFortGiftingData");
static_assert(offsetof(UFortGiftingData, GiftingScreenClass) == 0x4f0, "Offset mismatch for UFortGiftingData::GiftingScreenClass");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FFortGiftingRecipientState
{
    FCatalogItemPrice Price; // 0x0 (Size: 0x48, Type: StructProperty)
    TArray<FItemQuantity> Items; // 0x48 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_58[0x28]; // 0x58 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(FFortGiftingRecipientState) == 0x80, "Size mismatch for FFortGiftingRecipientState");
static_assert(offsetof(FFortGiftingRecipientState, Price) == 0x0, "Offset mismatch for FFortGiftingRecipientState::Price");
static_assert(offsetof(FFortGiftingRecipientState, Items) == 0x48, "Offset mismatch for FFortGiftingRecipientState::Items");

