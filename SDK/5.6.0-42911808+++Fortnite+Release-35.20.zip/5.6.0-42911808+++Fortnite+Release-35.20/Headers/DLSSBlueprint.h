/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DLSSBlueprint
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDLSSLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void EnableDLAA(bool& bEnabled); // 0x12ae59f4 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void EnableDLSS(bool& bEnabled); // 0x12ae5b10 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static UDLSSMode GetDefaultDLSSMode(); // 0x12ae63cc (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void GetDLSSMinimumDriverVersion(int32_t& MinDriverVersionMajor, int32_t& MinDriverVersionMinor); // 0x12ae5c2c (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UDLSSMode GetDLSSMode(); // 0x12ae5da4 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void GetDLSSModeInformation(UDLSSMode& DLSSMode, FVector2D& ScreenResolution, bool& bIsSupported, float& OptimalScreenPercentage, bool& bIsFixedScreenPercentage, float& MinScreenPercentage, float& MaxScreenPercentage, float& OptimalSharpness); // 0x12ae5dc8 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static void GetDLSSScreenPercentageRange(float& MinScreenPercentage, float& MaxScreenPercentage); // 0x12ae622c (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static float GetDLSSSharpness(); // 0x12ae63a4 (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TArray<UDLSSMode> GetSupportedDLSSModes(); // 0x12ae63f0 (Index: 0x8, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsDLAAEnabled(); // 0x12ae645c (Index: 0x9, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsDLSSEnabled(); // 0x12ae6480 (Index: 0xa, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsDLSSModeSupported(UDLSSMode& DLSSMode); // 0x12ae64a4 (Index: 0xb, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsDLSSSupported(); // 0x12ae65cc (Index: 0xc, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UDLSSSupport QueryDLSSSupport(); // 0x12ae65f0 (Index: 0xd, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void SetDLSSMode(UObject*& WorldContextObject, UDLSSMode& DLSSMode); // 0x12ae6614 (Index: 0xe, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    static void SetDLSSSharpness(float& Sharpness); // 0x12ae6808 (Index: 0xf, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UDLSSLibrary) == 0x28, "Size mismatch for UDLSSLibrary");

