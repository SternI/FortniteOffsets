/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_VFX_Spawner
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"
#include "Niagara.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCRD_VFX_SpawnerFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static UNiagaraComponent* SpawnTransientSystemAttached(UNiagaraSystem*& SystemTemplate, USceneComponent*& AttachToComponent, FName& AttachPointName, FVector& Location, FRotator& Rotation, TEnumAsByte<EAttachLocation>& LocationType, bool& bAutoDestroy, bool& bAutoActivate, ENCPoolMethod& PoolingMethod, bool& bPreCullCheck); // 0x11e87cb4 (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UCRD_VFX_SpawnerFunctionLibrary) == 0x28, "Size mismatch for UCRD_VFX_SpawnerFunctionLibrary");

