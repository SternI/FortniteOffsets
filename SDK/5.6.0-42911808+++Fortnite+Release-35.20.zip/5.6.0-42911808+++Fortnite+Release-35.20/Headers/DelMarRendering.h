/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarRendering
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x50 (Inherited: 0xc8, Single: 0xffffff88)
class UDelMarMaterialFXSubsystem : public UTickableWorldSubsystem
{
public:
    UMaterialParameterCollection* GameplayMPC; // 0x40 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarMaterialFXSubsystem) == 0x50, "Size mismatch for UDelMarMaterialFXSubsystem");
static_assert(offsetof(UDelMarMaterialFXSubsystem, GameplayMPC) == 0x40, "Offset mismatch for UDelMarMaterialFXSubsystem::GameplayMPC");

