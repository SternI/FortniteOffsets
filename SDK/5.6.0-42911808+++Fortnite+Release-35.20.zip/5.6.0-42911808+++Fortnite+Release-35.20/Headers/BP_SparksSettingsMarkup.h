/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_SparksSettingsMarkup
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"

// Size: 0x38 (Inherited: 0x88, Single: 0xffffffb0)
class UBP_SparksSettingsMarkup_C : public UFortGameSettingRegistryMarkup
{
public:
};

static_assert(sizeof(UBP_SparksSettingsMarkup_C) == 0x38, "Size mismatch for UBP_SparksSettingsMarkup_C");

