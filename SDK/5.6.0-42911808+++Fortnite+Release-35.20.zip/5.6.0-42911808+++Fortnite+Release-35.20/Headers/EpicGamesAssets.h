/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicGamesAssets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "VerseAssets.h"
#include "Niagara.h"

// Size: 0x2e8 (Inherited: 0x2d0, Single: 0x18)
class APlayedSoundReplication : public AActor
{
public:
    double StartTime; // 0x2a8 (Size: 0x8, Type: DoubleProperty)
    bool bPlaySound2D; // 0x2b0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b1[0x7]; // 0x2b1 (Size: 0x7, Type: PaddingProperty)
    UVerseAssetPtr* SoundAsset; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* AudioComponent; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* SoundAttenuation; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2d0[0x18]; // 0x2d0 (Size: 0x18, Type: PaddingProperty)

private:
    void OnRep_SoundAsset(); // 0xfd4cea8 (Index: 0x0, Flags: Final|Native|Private)
    void OnSystemFinished(UAudioComponent*& FinishedComponent); // 0xfd4cf40 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(APlayedSoundReplication) == 0x2e8, "Size mismatch for APlayedSoundReplication");
static_assert(offsetof(APlayedSoundReplication, StartTime) == 0x2a8, "Offset mismatch for APlayedSoundReplication::StartTime");
static_assert(offsetof(APlayedSoundReplication, bPlaySound2D) == 0x2b0, "Offset mismatch for APlayedSoundReplication::bPlaySound2D");
static_assert(offsetof(APlayedSoundReplication, SoundAsset) == 0x2b8, "Offset mismatch for APlayedSoundReplication::SoundAsset");
static_assert(offsetof(APlayedSoundReplication, AudioComponent) == 0x2c0, "Offset mismatch for APlayedSoundReplication::AudioComponent");
static_assert(offsetof(APlayedSoundReplication, SoundAttenuation) == 0x2c8, "Offset mismatch for APlayedSoundReplication::SoundAttenuation");

// Size: 0x2e0 (Inherited: 0x2d0, Single: 0x10)
class ASpawnedParticleSystemReplication : public AActor
{
public:
    double StartTime; // 0x2a8 (Size: 0x8, Type: DoubleProperty)
    UVerseAssetPtr* VFXAsset; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* VFXComponent; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2c0[0x20]; // 0x2c0 (Size: 0x20, Type: PaddingProperty)

private:
    void OnRep_StartTime(); // 0xfd4cebc (Index: 0x0, Flags: Final|Native|Private)
    void OnRep_VFXAsset(); // 0xfd4cf2c (Index: 0x1, Flags: Final|Native|Private)
    void OnSystemFinished(UNiagaraComponent*& FinishedComponent); // 0xfd4cf40 (Index: 0x2, Flags: Final|Native|Private)
};

static_assert(sizeof(ASpawnedParticleSystemReplication) == 0x2e0, "Size mismatch for ASpawnedParticleSystemReplication");
static_assert(offsetof(ASpawnedParticleSystemReplication, StartTime) == 0x2a8, "Offset mismatch for ASpawnedParticleSystemReplication::StartTime");
static_assert(offsetof(ASpawnedParticleSystemReplication, VFXAsset) == 0x2b0, "Offset mismatch for ASpawnedParticleSystemReplication::VFXAsset");
static_assert(offsetof(ASpawnedParticleSystemReplication, VFXComponent) == 0x2b8, "Offset mismatch for ASpawnedParticleSystemReplication::VFXComponent");

