/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaCDNHostnames
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x178 (Inherited: 0x28, Single: 0x150)
class UEpicMediaCDNHostnames : public UObject
{
public:
    TArray<float> CDNDistribution; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_38[0x140]; // 0x38 (Size: 0x140, Type: PaddingProperty)

public:
    TArray<FString> GetHostnames() const; // 0xc590654 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetSelectedHostName() const; // 0xc590690 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UEpicMediaCDNHostnames) == 0x178, "Size mismatch for UEpicMediaCDNHostnames");
static_assert(offsetof(UEpicMediaCDNHostnames, CDNDistribution) == 0x28, "Offset mismatch for UEpicMediaCDNHostnames::CDNDistribution");

