/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamCoreRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "ModularGameplay.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0xc8 (Inherited: 0x3d0, Single: 0xfffffcf8)
class UJamControllerComponent_QuestPersistence : public UFortControllerComponent_QuestPersistence
{
public:
};

static_assert(sizeof(UJamControllerComponent_QuestPersistence) == 0xc8, "Size mismatch for UJamControllerComponent_QuestPersistence");

// Size: 0xc0 (Inherited: 0x250, Single: 0xfffffe70)
class UJamOverrides : public UGameStateComponent
{
public:
    UClass* JamVolume; // 0xb8 (Size: 0x8, Type: ClassProperty)

public:
    static UJamOverrides* GetJamOverrides(UObject*& const WorldContextObject); // 0x102fc2c4 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UJamOverrides) == 0xc0, "Size mismatch for UJamOverrides");
static_assert(offsetof(UJamOverrides, JamVolume) == 0xb8, "Offset mismatch for UJamOverrides::JamVolume");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UJamCoreBPFL : public UBlueprintFunctionLibrary
{
public:

public:
    static FColor GetDefaultColorForLoopType(EFMJamLoopType& const LoopType); // 0x102fbe6c (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static UFortClientSettingsRecord* GetFirstPlayerSettings(AActor*& const Context); // 0x102fbf94 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool ShouldRunClientCode(AActor*& const Context); // 0x102fc5c8 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool ShouldRunServerCode(AActor*& const Context); // 0x102fc9e8 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UJamCoreBPFL) == 0x28, "Size mismatch for UJamCoreBPFL");

