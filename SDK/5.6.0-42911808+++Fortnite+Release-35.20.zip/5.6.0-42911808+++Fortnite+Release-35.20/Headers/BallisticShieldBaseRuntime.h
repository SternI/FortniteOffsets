/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BallisticShieldBaseRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "TacticalSprintRuntime.h"
#include "TargetingSystem.h"
#include "GameplayAbilities.h"

// Size: 0x13d0 (Inherited: 0x20a8, Single: 0xfffff328)
class UBallisticShieldItemLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    bool bIsRush; // 0x12f0 (Size: 0x1, Type: BoolProperty)
    bool bIsEquipping; // 0x12f1 (Size: 0x1, Type: BoolProperty)
    bool bEnterLanding; // 0x12f2 (Size: 0x1, Type: BoolProperty)
    bool bExitLanding; // 0x12f3 (Size: 0x1, Type: BoolProperty)
    bool bIsShieldBlocking; // 0x12f4 (Size: 0x1, Type: BoolProperty)
    bool bIsStaggerBuildup; // 0x12f5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12f6[0x2]; // 0x12f6 (Size: 0x2, Type: PaddingProperty)
    float Yaw; // 0x12f8 (Size: 0x4, Type: FloatProperty)
    float ChargeAOAlpha; // 0x12fc (Size: 0x4, Type: FloatProperty)
    int32_t GenderAndSize; // 0x1300 (Size: 0x4, Type: IntProperty)
    float ReloadUBAlpha; // 0x1304 (Size: 0x4, Type: FloatProperty)
    float MaskLeftArmAlpha; // 0x1308 (Size: 0x4, Type: FloatProperty)
    float StaggerAmount; // 0x130c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1310[0xc0]; // 0x1310 (Size: 0xc0, Type: PaddingProperty)
};

static_assert(sizeof(UBallisticShieldItemLayerAnimInstance) == 0x13d0, "Size mismatch for UBallisticShieldItemLayerAnimInstance");
static_assert(offsetof(UBallisticShieldItemLayerAnimInstance, bIsRush) == 0x12f0, "Offset mismatch for UBallisticShieldItemLayerAnimInstance::bIsRush");
static_assert(offsetof(UBallisticShieldItemLayerAnimInstance, bIsEquipping) == 0x12f1, "Offset mismatch for UBallisticShieldItemLayerAnimInstance::bIsEquipping");
static_assert(offsetof(UBallisticShieldItemLayerAnimInstance, bEnterLanding) == 0x12f2, "Offset mismatch for UBallisticShieldItemLayerAnimInstance::bEnterLanding");
static_assert(offsetof(UBallisticShieldItemLayerAnimInstance, bExitLanding) == 0x12f3, "Offset mismatch for UBallisticShieldItemLayerAnimInstance::bExitLanding");
static_assert(offsetof(UBallisticShieldItemLayerAnimInstance, bIsShieldBlocking) == 0x12f4, "Offset mismatch for UBallisticShieldItemLayerAnimInstance::bIsShieldBlocking");
static_assert(offsetof(UBallisticShieldItemLayerAnimInstance, bIsStaggerBuildup) == 0x12f5, "Offset mismatch for UBallisticShieldItemLayerAnimInstance::bIsStaggerBuildup");
static_assert(offsetof(UBallisticShieldItemLayerAnimInstance, Yaw) == 0x12f8, "Offset mismatch for UBallisticShieldItemLayerAnimInstance::Yaw");
static_assert(offsetof(UBallisticShieldItemLayerAnimInstance, ChargeAOAlpha) == 0x12fc, "Offset mismatch for UBallisticShieldItemLayerAnimInstance::ChargeAOAlpha");
static_assert(offsetof(UBallisticShieldItemLayerAnimInstance, GenderAndSize) == 0x1300, "Offset mismatch for UBallisticShieldItemLayerAnimInstance::GenderAndSize");
static_assert(offsetof(UBallisticShieldItemLayerAnimInstance, ReloadUBAlpha) == 0x1304, "Offset mismatch for UBallisticShieldItemLayerAnimInstance::ReloadUBAlpha");
static_assert(offsetof(UBallisticShieldItemLayerAnimInstance, MaskLeftArmAlpha) == 0x1308, "Offset mismatch for UBallisticShieldItemLayerAnimInstance::MaskLeftArmAlpha");
static_assert(offsetof(UBallisticShieldItemLayerAnimInstance, StaggerAmount) == 0x130c, "Offset mismatch for UBallisticShieldItemLayerAnimInstance::StaggerAmount");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBallisticShieldWeaponInterface : public UInterface
{
public:

public:
    virtual void GetBallisticShieldData(EBallisticShieldPlayerActionState& BallisticShieldPlayerState, float& StaggerBuildupPercent); // 0x10109618 (Index: 0x0, Flags: Native|Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UBallisticShieldWeaponInterface) == 0x28, "Size mismatch for UBallisticShieldWeaponInterface");

// Size: 0x590 (Inherited: 0x978, Single: 0xfffffc18)
class UFortMovementMode_ELBShieldSprint : public UFortMovementMode_ELTacSprint
{
public:
    FScalableFloat ChargeRotationRate; // 0x558 (Size: 0x28, Type: StructProperty)
    UClass* GrantedAbility; // 0x580 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_588[0x8]; // 0x588 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortMovementMode_ELBShieldSprint) == 0x590, "Size mismatch for UFortMovementMode_ELBShieldSprint");
static_assert(offsetof(UFortMovementMode_ELBShieldSprint, ChargeRotationRate) == 0x558, "Offset mismatch for UFortMovementMode_ELBShieldSprint::ChargeRotationRate");
static_assert(offsetof(UFortMovementMode_ELBShieldSprint, GrantedAbility) == 0x580, "Offset mismatch for UFortMovementMode_ELBShieldSprint::GrantedAbility");

// Size: 0xb0 (Inherited: 0x78, Single: 0x38)
class UTargetingFilterTask_BShieldCharge : public UTargetingFilterTask_BasicFilterTemplate
{
public:
    TArray<UClass*> WalkableActorClasses; // 0x28 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat BashableActorAngle; // 0x38 (Size: 0x28, Type: StructProperty)
    FScalableFloat MainTraceDistance; // 0x60 (Size: 0x28, Type: StructProperty)
    FScalableFloat FloorHitZTolerance; // 0x88 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UTargetingFilterTask_BShieldCharge) == 0xb0, "Size mismatch for UTargetingFilterTask_BShieldCharge");
static_assert(offsetof(UTargetingFilterTask_BShieldCharge, WalkableActorClasses) == 0x28, "Offset mismatch for UTargetingFilterTask_BShieldCharge::WalkableActorClasses");
static_assert(offsetof(UTargetingFilterTask_BShieldCharge, BashableActorAngle) == 0x38, "Offset mismatch for UTargetingFilterTask_BShieldCharge::BashableActorAngle");
static_assert(offsetof(UTargetingFilterTask_BShieldCharge, MainTraceDistance) == 0x60, "Offset mismatch for UTargetingFilterTask_BShieldCharge::MainTraceDistance");
static_assert(offsetof(UTargetingFilterTask_BShieldCharge, FloorHitZTolerance) == 0x88, "Offset mismatch for UTargetingFilterTask_BShieldCharge::FloorHitZTolerance");

