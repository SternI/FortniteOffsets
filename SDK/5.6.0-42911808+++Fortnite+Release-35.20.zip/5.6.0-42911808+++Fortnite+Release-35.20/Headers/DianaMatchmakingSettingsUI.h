/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DianaMatchmakingSettingsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UDianaMatchmakingSettingsUI : public UMatchmakingSettingsUI
{
public:
    TSoftClassPtr ProductLogoWidget; // 0x28 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UDianaMatchmakingSettingsUI) == 0x48, "Size mismatch for UDianaMatchmakingSettingsUI");
static_assert(offsetof(UDianaMatchmakingSettingsUI, ProductLogoWidget) == 0x28, "Offset mismatch for UDianaMatchmakingSettingsUI::ProductLogoWidget");

