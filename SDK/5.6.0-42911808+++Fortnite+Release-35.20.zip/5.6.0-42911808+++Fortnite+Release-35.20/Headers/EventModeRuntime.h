/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EventModeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ModularGameplay.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "UMG.h"
#include "GameplayTags.h"
#include "CoreUObject.h"

// Size: 0x228 (Inherited: 0x198, Single: 0x90)
class UFortGameFrameworkComponent_EventMode : public UGameFrameworkComponent
{
public:
    uint8_t Pad_b8[0x60]; // 0xb8 (Size: 0x60, Type: PaddingProperty)
    TSoftObjectPtr<UFortWeaponItemDefinition*> ActivatorAsset; // 0x118 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FUIExtension> UIExtensions; // 0x138 (Size: 0x10, Type: ArrayProperty)
    TMap<TSoftClassPtr, FGameplayTag> TaggedUIExtensions; // 0x148 (Size: 0x50, Type: MapProperty)
    TArray<FEventModeFocusActor> FocusActors; // 0x198 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_1a8[0x8]; // 0x1a8 (Size: 0x8, Type: PaddingProperty)
    UInputComponent* InputComponent; // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    TArray<FEventModeWidgetCachedData> CachedWidgetData; // 0x1b8 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<AActor*> CurrentlyFocusedActor; // 0x1c8 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t Pad_1e8[0x40]; // 0x1e8 (Size: 0x40, Type: PaddingProperty)

public:
    bool GetIsEventModeActive() const; // 0x113e064c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsFocusAvailable() const; // 0x113e0664 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsFocusing() const; // 0x113e067c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    void OnEnterVehicle(); // 0x113e0694 (Index: 0x3, Flags: Final|Native|Private)
    void OnExitVehicle(); // 0x113e06a8 (Index: 0x4, Flags: Final|Native|Private)
    void OnPlayerPawnPossessed(APawn*& PossessedPawn); // 0x6023a08 (Index: 0x5, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortGameFrameworkComponent_EventMode) == 0x228, "Size mismatch for UFortGameFrameworkComponent_EventMode");
static_assert(offsetof(UFortGameFrameworkComponent_EventMode, ActivatorAsset) == 0x118, "Offset mismatch for UFortGameFrameworkComponent_EventMode::ActivatorAsset");
static_assert(offsetof(UFortGameFrameworkComponent_EventMode, UIExtensions) == 0x138, "Offset mismatch for UFortGameFrameworkComponent_EventMode::UIExtensions");
static_assert(offsetof(UFortGameFrameworkComponent_EventMode, TaggedUIExtensions) == 0x148, "Offset mismatch for UFortGameFrameworkComponent_EventMode::TaggedUIExtensions");
static_assert(offsetof(UFortGameFrameworkComponent_EventMode, FocusActors) == 0x198, "Offset mismatch for UFortGameFrameworkComponent_EventMode::FocusActors");
static_assert(offsetof(UFortGameFrameworkComponent_EventMode, InputComponent) == 0x1b0, "Offset mismatch for UFortGameFrameworkComponent_EventMode::InputComponent");
static_assert(offsetof(UFortGameFrameworkComponent_EventMode, CachedWidgetData) == 0x1b8, "Offset mismatch for UFortGameFrameworkComponent_EventMode::CachedWidgetData");
static_assert(offsetof(UFortGameFrameworkComponent_EventMode, CurrentlyFocusedActor) == 0x1c8, "Offset mismatch for UFortGameFrameworkComponent_EventMode::CurrentlyFocusedActor");

// Size: 0x19c0 (Inherited: 0x1c90, Single: 0xfffffd30)
class AFortWeapon_EventMode : public AFortWeapon
{
public:
};

static_assert(sizeof(AFortWeapon_EventMode) == 0x19c0, "Size mismatch for AFortWeapon_EventMode");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FEventModeFocusActor
{
    TSoftObjectPtr<AActor*> Target; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    float Distance; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FVector Offset; // 0x28 (Size: 0x18, Type: StructProperty)
    float FOV; // 0x40 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FEventModeFocusActor) == 0x48, "Size mismatch for FEventModeFocusActor");
static_assert(offsetof(FEventModeFocusActor, Target) == 0x0, "Offset mismatch for FEventModeFocusActor::Target");
static_assert(offsetof(FEventModeFocusActor, Distance) == 0x20, "Offset mismatch for FEventModeFocusActor::Distance");
static_assert(offsetof(FEventModeFocusActor, Offset) == 0x28, "Offset mismatch for FEventModeFocusActor::Offset");
static_assert(offsetof(FEventModeFocusActor, FOV) == 0x40, "Offset mismatch for FEventModeFocusActor::FOV");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FEventModeWidgetCachedData
{
    uint8_t Slot; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<UUserWidget*> Widget; // 0x4 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FEventModeWidgetCachedData) == 0xc, "Size mismatch for FEventModeWidgetCachedData");
static_assert(offsetof(FEventModeWidgetCachedData, Slot) == 0x0, "Offset mismatch for FEventModeWidgetCachedData::Slot");
static_assert(offsetof(FEventModeWidgetCachedData, Widget) == 0x4, "Offset mismatch for FEventModeWidgetCachedData::Widget");

