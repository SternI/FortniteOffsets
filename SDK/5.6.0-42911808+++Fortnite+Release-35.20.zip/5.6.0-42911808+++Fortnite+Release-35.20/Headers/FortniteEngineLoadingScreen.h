/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteEngineLoadingScreen
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DeveloperSettings.h"
#include "Engine.h"

// Size: 0x580 (Inherited: 0x58, Single: 0x528)
class UFortniteUserInterfaceSettings : public UDeveloperSettings
{
public:
    FRuntimeFloatCurve WidthScaleCurve; // 0x30 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve HeightScaleCurve; // 0xb8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve WidthScaleCurve_iOS_InGame; // 0x140 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve HeightScaleCurve_iOS_InGame; // 0x1c8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve WidthScaleCurve_iOS_FrontEnd; // 0x250 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve HeightScaleCurve_iOS_FrontEnd; // 0x2d8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve WidthScaleCurve_Android_InGame; // 0x360 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve HeightScaleCurve_Android_InGame; // 0x3e8 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve WidthScaleCurve_Android_FrontEnd; // 0x470 (Size: 0x88, Type: StructProperty)
    FRuntimeFloatCurve HeightScaleCurve_Android_FrontEnd; // 0x4f8 (Size: 0x88, Type: StructProperty)
};

static_assert(sizeof(UFortniteUserInterfaceSettings) == 0x580, "Size mismatch for UFortniteUserInterfaceSettings");
static_assert(offsetof(UFortniteUserInterfaceSettings, WidthScaleCurve) == 0x30, "Offset mismatch for UFortniteUserInterfaceSettings::WidthScaleCurve");
static_assert(offsetof(UFortniteUserInterfaceSettings, HeightScaleCurve) == 0xb8, "Offset mismatch for UFortniteUserInterfaceSettings::HeightScaleCurve");
static_assert(offsetof(UFortniteUserInterfaceSettings, WidthScaleCurve_iOS_InGame) == 0x140, "Offset mismatch for UFortniteUserInterfaceSettings::WidthScaleCurve_iOS_InGame");
static_assert(offsetof(UFortniteUserInterfaceSettings, HeightScaleCurve_iOS_InGame) == 0x1c8, "Offset mismatch for UFortniteUserInterfaceSettings::HeightScaleCurve_iOS_InGame");
static_assert(offsetof(UFortniteUserInterfaceSettings, WidthScaleCurve_iOS_FrontEnd) == 0x250, "Offset mismatch for UFortniteUserInterfaceSettings::WidthScaleCurve_iOS_FrontEnd");
static_assert(offsetof(UFortniteUserInterfaceSettings, HeightScaleCurve_iOS_FrontEnd) == 0x2d8, "Offset mismatch for UFortniteUserInterfaceSettings::HeightScaleCurve_iOS_FrontEnd");
static_assert(offsetof(UFortniteUserInterfaceSettings, WidthScaleCurve_Android_InGame) == 0x360, "Offset mismatch for UFortniteUserInterfaceSettings::WidthScaleCurve_Android_InGame");
static_assert(offsetof(UFortniteUserInterfaceSettings, HeightScaleCurve_Android_InGame) == 0x3e8, "Offset mismatch for UFortniteUserInterfaceSettings::HeightScaleCurve_Android_InGame");
static_assert(offsetof(UFortniteUserInterfaceSettings, WidthScaleCurve_Android_FrontEnd) == 0x470, "Offset mismatch for UFortniteUserInterfaceSettings::WidthScaleCurve_Android_FrontEnd");
static_assert(offsetof(UFortniteUserInterfaceSettings, HeightScaleCurve_Android_FrontEnd) == 0x4f8, "Offset mismatch for UFortniteUserInterfaceSettings::HeightScaleCurve_Android_FrontEnd");

