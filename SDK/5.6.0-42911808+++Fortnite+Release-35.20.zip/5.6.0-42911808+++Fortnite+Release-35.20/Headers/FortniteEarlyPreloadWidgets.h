/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteEarlyPreloadWidgets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "UMG.h"

// Size: 0x158 (Inherited: 0x1a8, Single: 0xffffffb0)
class UFortniteBootUpBackground : public UWidget
{
public:
};

static_assert(sizeof(UFortniteBootUpBackground) == 0x158, "Size mismatch for UFortniteBootUpBackground");

