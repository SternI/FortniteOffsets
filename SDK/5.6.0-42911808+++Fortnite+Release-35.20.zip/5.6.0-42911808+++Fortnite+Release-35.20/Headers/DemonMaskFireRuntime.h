/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DemonMaskFireRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "MaskAnimShared.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x820 (Inherited: 0x1e48, Single: 0xffffe9d8)
class UDemonMaskFireGadgetAnimInstance : public UMaskBaseCCPAnimInstance
{
public:
    FVector Floater; // 0x7f8 (Size: 0x18, Type: StructProperty)
    double ElapsedTime; // 0x810 (Size: 0x8, Type: DoubleProperty)
    uint8_t Pad_818[0x8]; // 0x818 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDemonMaskFireGadgetAnimInstance) == 0x820, "Size mismatch for UDemonMaskFireGadgetAnimInstance");
static_assert(offsetof(UDemonMaskFireGadgetAnimInstance, Floater) == 0x7f8, "Offset mismatch for UDemonMaskFireGadgetAnimInstance::Floater");
static_assert(offsetof(UDemonMaskFireGadgetAnimInstance, ElapsedTime) == 0x810, "Offset mismatch for UDemonMaskFireGadgetAnimInstance::ElapsedTime");

// Size: 0x1310 (Inherited: 0x20a8, Single: 0xfffff268)
class UDemonMaskLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    double IsPlayingFire01_Alpha; // 0x12f0 (Size: 0x8, Type: DoubleProperty)
    double IsPlayingFire02_Alpha; // 0x12f8 (Size: 0x8, Type: DoubleProperty)
    UObject* DemonMaskFirePlayerFire01MontageObject; // 0x1300 (Size: 0x8, Type: ObjectProperty)
    UObject* DemonMaskFirePlayerFire02MontageObject; // 0x1308 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDemonMaskLayerAnimInstance) == 0x1310, "Size mismatch for UDemonMaskLayerAnimInstance");
static_assert(offsetof(UDemonMaskLayerAnimInstance, IsPlayingFire01_Alpha) == 0x12f0, "Offset mismatch for UDemonMaskLayerAnimInstance::IsPlayingFire01_Alpha");
static_assert(offsetof(UDemonMaskLayerAnimInstance, IsPlayingFire02_Alpha) == 0x12f8, "Offset mismatch for UDemonMaskLayerAnimInstance::IsPlayingFire02_Alpha");
static_assert(offsetof(UDemonMaskLayerAnimInstance, DemonMaskFirePlayerFire01MontageObject) == 0x1300, "Offset mismatch for UDemonMaskLayerAnimInstance::DemonMaskFirePlayerFire01MontageObject");
static_assert(offsetof(UDemonMaskLayerAnimInstance, DemonMaskFirePlayerFire02MontageObject) == 0x1308, "Offset mismatch for UDemonMaskLayerAnimInstance::DemonMaskFirePlayerFire02MontageObject");

// Size: 0xd00 (Inherited: 0x2208, Single: 0xffffeaf8)
class AFortPrjAthenaDemonFireMask : public AFortProjectileAthena
{
public:
    TWeakObjectPtr<AFortPlayerPawn*> FortPlayerPawn; // 0xce8 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_cf0[0x10]; // 0xcf0 (Size: 0x10, Type: PaddingProperty)

private:
    AActor* GetAimedAtTarget(AFortPlayerController*& SourcePlayer, float& RectHalfWidth, float& RectHalfHeight, float& Range, const TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes, const TArray<AActor*> ActorsToIgnore); // 0x1139353c (Index: 0x0, Flags: Final|Native|Private|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(AFortPrjAthenaDemonFireMask) == 0xd00, "Size mismatch for AFortPrjAthenaDemonFireMask");
static_assert(offsetof(AFortPrjAthenaDemonFireMask, FortPlayerPawn) == 0xce8, "Offset mismatch for AFortPrjAthenaDemonFireMask::FortPlayerPawn");

// Size: 0x25a8 (Inherited: 0x4220, Single: 0xffffe388)
class AFortWeaponRangedDemonFireMask : public AFortWeaponRanged
{
public:
    TWeakObjectPtr<AFortPlayerPawn*> FortPlayerPawn; // 0x2590 (Size: 0x8, Type: WeakObjectProperty)
    TArray<FHitResult> OutHits; // 0x2598 (Size: 0x10, Type: ArrayProperty)

private:
    AActor* GetAimedAtTarget(AFortPlayerController*& SourcePlayer, float& RectHalfWidth, float& RectHalfHeight, float& Range, const TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes, const TArray<AActor*> ActorsToIgnore, const FGameplayTagContainer AvoidDetectionTagContainer); // 0x11393b70 (Index: 0x0, Flags: Final|Native|Private|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(AFortWeaponRangedDemonFireMask) == 0x25a8, "Size mismatch for AFortWeaponRangedDemonFireMask");
static_assert(offsetof(AFortWeaponRangedDemonFireMask, FortPlayerPawn) == 0x2590, "Offset mismatch for AFortWeaponRangedDemonFireMask::FortPlayerPawn");
static_assert(offsetof(AFortWeaponRangedDemonFireMask, OutHits) == 0x2598, "Offset mismatch for AFortWeaponRangedDemonFireMask::OutHits");

