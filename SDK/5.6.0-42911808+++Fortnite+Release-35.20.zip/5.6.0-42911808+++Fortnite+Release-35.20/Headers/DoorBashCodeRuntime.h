/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DoorBashCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "GameplayAbilities.h"

// Size: 0xd38 (Inherited: 0xf08, Single: 0xfffffe30)
class UFortGameplayAbility_DoorBash : public UFortGameplayAbility
{
public:
    FScalableFloat HF_DoorBashEnabled; // 0xb38 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_ForwardDoorCheckMult; // 0xb60 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_LaunchPawnImpulseMult; // 0xb88 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_PawnVelocityMinThreshold; // 0xbb0 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_EndAbilityGracePeriod; // 0xbd8 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_DoorCheckPeriod; // 0xc00 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_PawnLaunchOverlapRadius; // 0xc28 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_DelayNewDoorCheckTimerAfterSuccess; // 0xc50 (Size: 0x28, Type: StructProperty)
    UAnimMontage* DoorBashMale; // 0xc78 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* DoorBashFemale; // 0xc80 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GC_DoorImpact; // 0xc88 (Size: 0x4, Type: StructProperty)
    FGameplayTag GC_LaunchPlayer; // 0xc8c (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer AdditionalQuestSourceTags; // 0xc90 (Size: 0x20, Type: StructProperty)
    TArray<TEnumAsByte<EObjectTypeQuery>> DoorCheckQueryTypes; // 0xcb0 (Size: 0x10, Type: ArrayProperty)
    TArray<TEnumAsByte<EObjectTypeQuery>> PawnObjectQueryTypes; // 0xcc0 (Size: 0x10, Type: ArrayProperty)
    FGameplayTag SkipAnimationTag; // 0xcd0 (Size: 0x4, Type: StructProperty)
    FGameplayTag AllowActionWithoutSprintTag; // 0xcd4 (Size: 0x4, Type: StructProperty)
    FGameplayTag EventDoorBashSuccessTag; // 0xcd8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_cdc[0x5c]; // 0xcdc (Size: 0x5c, Type: PaddingProperty)

protected:
    void EventCallback_OnPawnJumped(); // 0x1126f40c (Index: 0x0, Flags: Final|Native|Protected)
    void EventCallback_OnPawnLanded(const FHitResult Result); // 0x1126f420 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UFortGameplayAbility_DoorBash) == 0xd38, "Size mismatch for UFortGameplayAbility_DoorBash");
static_assert(offsetof(UFortGameplayAbility_DoorBash, HF_DoorBashEnabled) == 0xb38, "Offset mismatch for UFortGameplayAbility_DoorBash::HF_DoorBashEnabled");
static_assert(offsetof(UFortGameplayAbility_DoorBash, HF_ForwardDoorCheckMult) == 0xb60, "Offset mismatch for UFortGameplayAbility_DoorBash::HF_ForwardDoorCheckMult");
static_assert(offsetof(UFortGameplayAbility_DoorBash, HF_LaunchPawnImpulseMult) == 0xb88, "Offset mismatch for UFortGameplayAbility_DoorBash::HF_LaunchPawnImpulseMult");
static_assert(offsetof(UFortGameplayAbility_DoorBash, HF_PawnVelocityMinThreshold) == 0xbb0, "Offset mismatch for UFortGameplayAbility_DoorBash::HF_PawnVelocityMinThreshold");
static_assert(offsetof(UFortGameplayAbility_DoorBash, HF_EndAbilityGracePeriod) == 0xbd8, "Offset mismatch for UFortGameplayAbility_DoorBash::HF_EndAbilityGracePeriod");
static_assert(offsetof(UFortGameplayAbility_DoorBash, HF_DoorCheckPeriod) == 0xc00, "Offset mismatch for UFortGameplayAbility_DoorBash::HF_DoorCheckPeriod");
static_assert(offsetof(UFortGameplayAbility_DoorBash, HF_PawnLaunchOverlapRadius) == 0xc28, "Offset mismatch for UFortGameplayAbility_DoorBash::HF_PawnLaunchOverlapRadius");
static_assert(offsetof(UFortGameplayAbility_DoorBash, HF_DelayNewDoorCheckTimerAfterSuccess) == 0xc50, "Offset mismatch for UFortGameplayAbility_DoorBash::HF_DelayNewDoorCheckTimerAfterSuccess");
static_assert(offsetof(UFortGameplayAbility_DoorBash, DoorBashMale) == 0xc78, "Offset mismatch for UFortGameplayAbility_DoorBash::DoorBashMale");
static_assert(offsetof(UFortGameplayAbility_DoorBash, DoorBashFemale) == 0xc80, "Offset mismatch for UFortGameplayAbility_DoorBash::DoorBashFemale");
static_assert(offsetof(UFortGameplayAbility_DoorBash, GC_DoorImpact) == 0xc88, "Offset mismatch for UFortGameplayAbility_DoorBash::GC_DoorImpact");
static_assert(offsetof(UFortGameplayAbility_DoorBash, GC_LaunchPlayer) == 0xc8c, "Offset mismatch for UFortGameplayAbility_DoorBash::GC_LaunchPlayer");
static_assert(offsetof(UFortGameplayAbility_DoorBash, AdditionalQuestSourceTags) == 0xc90, "Offset mismatch for UFortGameplayAbility_DoorBash::AdditionalQuestSourceTags");
static_assert(offsetof(UFortGameplayAbility_DoorBash, DoorCheckQueryTypes) == 0xcb0, "Offset mismatch for UFortGameplayAbility_DoorBash::DoorCheckQueryTypes");
static_assert(offsetof(UFortGameplayAbility_DoorBash, PawnObjectQueryTypes) == 0xcc0, "Offset mismatch for UFortGameplayAbility_DoorBash::PawnObjectQueryTypes");
static_assert(offsetof(UFortGameplayAbility_DoorBash, SkipAnimationTag) == 0xcd0, "Offset mismatch for UFortGameplayAbility_DoorBash::SkipAnimationTag");
static_assert(offsetof(UFortGameplayAbility_DoorBash, AllowActionWithoutSprintTag) == 0xcd4, "Offset mismatch for UFortGameplayAbility_DoorBash::AllowActionWithoutSprintTag");
static_assert(offsetof(UFortGameplayAbility_DoorBash, EventDoorBashSuccessTag) == 0xcd8, "Offset mismatch for UFortGameplayAbility_DoorBash::EventDoorBashSuccessTag");

