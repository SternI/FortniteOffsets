/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AssetRegistry
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAssetRegistryHelpers : public UObject
{
public:

public:
    static FAssetData CreateAssetData(UObject*& const InAsset, bool& bAllowBlueprintClass); // 0x9976558 (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static UClass* FindAssetNativeClass(const FAssetData AssetData); // 0x99767c8 (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static UObject* GetAsset(const FAssetData InAssetData); // 0x9976e24 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static TScriptInterface<Class> GetAssetRegistry(); // 0x99771ac (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void GetBlueprintAssets(const FARFilter InFilter, TArray<FAssetData>& OutAssetData); // 0x9977fec (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static UClass* GetClass(const FAssetData InAssetData); // 0x9978194 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FString GetExportTextName(const FAssetData InAssetData); // 0x9978784 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FString GetFullName(const FAssetData InAssetData); // 0x9978904 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool GetTagValue(const FAssetData InAssetData, const FName InTagName, FString& OutTagValue); // 0x99790bc (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool IsAssetLoaded(const FAssetData InAssetData); // 0x9979558 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool IsRedirector(const FAssetData InAssetData); // 0x997967c (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool IsUAsset(const FAssetData InAssetData); // 0x99797d4 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool IsValid(const FAssetData InAssetData); // 0x99798d0 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FARFilter SetFilterTagsAndValues(const FARFilter InFilter, const TArray<FTagAndValue> InTagsAndValues); // 0x997af9c (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static void SortByAssetName(TArray<FAssetData> Assets, EAssetRegistrySortOrder& SortOrder); // 0x997b164 (Index: 0xe, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SortByPredicate(TArray<FAssetData> Assets, FDelegate& SortingPredicate, EAssetRegistrySortOrder& SortOrder); // 0x997b2e4 (Index: 0xf, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    bool SortingPredicate__DelegateSignature(const FAssetData Left, const FAssetData Right); // 0x288a61c (Index: 0x10, Flags: Public|Delegate|HasOutParms|HasDefaults)
    static FSoftObjectPath ToSoftObjectPath(const FAssetData InAssetData); // 0x997b5f0 (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UAssetRegistryHelpers) == 0x28, "Size mismatch for UAssetRegistryHelpers");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAssetRegistry : public UInterface
{
public:

public:
    bool GetAllAssets(TArray<FAssetData>& OutAssetData, bool& bIncludeOnlyOnDiskAssets) const; // 0x99768c4 (Index: 0x0, Flags: Native|Public|HasOutParms|BlueprintCallable|Const)
    void GetAllCachedPaths(TArray<FString>& OutPathList) const; // 0x9976a3c (Index: 0x1, Flags: Native|Public|HasOutParms|BlueprintCallable|Const)
    bool GetAncestorClassNames(FTopLevelAssetPath& ClassPathName, TArray<FTopLevelAssetPath>& OutAncestorClassNames) const; // 0x9976b1c (Index: 0x2, Flags: Native|Public|HasOutParms|BlueprintCallable|Const)
    FAssetData GetAssetByObjectPath(FName& const ObjectPath, bool& bIncludeOnlyOnDiskAssets) const; // 0x9976f5c (Index: 0x3, Flags: Native|Public|HasDefaults|BlueprintCallable|Const)
    bool GetAssets(const FARFilter Filter, TArray<FAssetData>& OutAssetData, bool& bSkipARFilteredAssets) const; // 0x99771e0 (Index: 0x4, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable|Const)
    bool GetAssetsByClass(FTopLevelAssetPath& ClassPathName, TArray<FAssetData>& OutAssetData, bool& bSearchSubClasses) const; // 0x9977420 (Index: 0x5, Flags: Native|Public|HasOutParms|BlueprintCallable|Const)
    bool GetAssetsByPackageName(FName& PackageName, TArray<FAssetData>& OutAssetData, bool& bIncludeOnlyOnDiskAssets, bool& bSkipARFilteredAssets) const; // 0x99775f8 (Index: 0x6, Flags: Native|Public|HasOutParms|BlueprintCallable|Const)
    bool GetAssetsByPath(FName& PackagePath, TArray<FAssetData>& OutAssetData, bool& bRecursive, bool& bIncludeOnlyOnDiskAssets) const; // 0x99778a4 (Index: 0x7, Flags: Native|Public|HasOutParms|BlueprintCallable|Const)
    bool GetAssetsByPaths(TArray<FName>& PackagePaths, TArray<FAssetData>& OutAssetData, bool& bRecursive, bool& bIncludeOnlyOnDiskAssets) const; // 0x9977b50 (Index: 0x8, Flags: Native|Public|HasOutParms|BlueprintCallable|Const)
    void GetDerivedClassNames(const TArray<FTopLevelAssetPath> ClassNames, const TSet<FTopLevelAssetPath> ExcludedClassNames, TSet<FTopLevelAssetPath>& OutDerivedClassNames) const; // 0x9978294 (Index: 0x9, Flags: Native|Public|HasOutParms|BlueprintCallable|Const)
    bool GetInMemoryAssets(const FARFilter Filter, TArray<FAssetData>& OutAssetData, bool& bSkipARFilteredAssets) const; // 0x9978a84 (Index: 0xa, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable|Const)
    void GetSubPaths(FString& InBasePath, TArray<FString>& OutPathList, bool& bInRecurse) const; // 0x9978cc4 (Index: 0xb, Flags: Native|Public|HasOutParms|BlueprintCallable|Const)
    bool HasAssets(FName& const PackagePath, bool& const bRecursive) const; // 0x997933c (Index: 0xc, Flags: Native|Public|BlueprintCallable|Const)
    bool IsLoadingAssets() const; // 0x9979654 (Index: 0xd, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSearchAllAssets() const; // 0x9979784 (Index: 0xe, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSearchAsync() const; // 0x99797ac (Index: 0xf, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    FAssetData K2_GetAssetByObjectPath(const FSoftObjectPath ObjectPath, bool& bIncludeOnlyOnDiskAssets, bool& bSkipARFilteredAssets) const; // 0x99799e8 (Index: 0x10, Flags: RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|Const)
    bool K2_GetDependencies(FName& PackageName, const FAssetRegistryDependencyOptions DependencyOptions, TArray<FName>& OutDependencies) const; // 0x9979d94 (Index: 0x11, Flags: Native|Public|HasOutParms|BlueprintCallable|Const)
    bool K2_GetReferencers(FName& PackageName, const FAssetRegistryDependencyOptions ReferenceOptions, TArray<FName>& OutReferencers) const; // 0x997a19c (Index: 0x12, Flags: Native|Public|HasOutParms|BlueprintCallable|Const)
    void PrioritizeSearchPath(FString& PathToPrioritize); // 0x997a5a4 (Index: 0x13, Flags: Native|Public|BlueprintCallable)
    void RunAssetsThroughFilter(TArray<FAssetData> AssetDataList, const FARFilter Filter) const; // 0x997a89c (Index: 0x14, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable|Const)
    void ScanFilesSynchronous(const TArray<FString> InFilePaths, bool& bForceRescan); // 0x997aa4c (Index: 0x15, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void ScanModifiedAssetFiles(const TArray<FString> InFilePaths); // 0x997abb4 (Index: 0x16, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void ScanPathsSynchronous(const TArray<FString> InPaths, bool& bForceRescan, bool& bIgnoreDenyListScanFilters); // 0x997ac94 (Index: 0x17, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void SearchAllAssets(bool& bSynchronousSearch); // 0x997ae6c (Index: 0x18, Flags: Native|Public|BlueprintCallable)
    void UseFilterToExcludeAssets(TArray<FAssetData> AssetDataList, const FARFilter Filter) const; // 0x997b810 (Index: 0x19, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable|Const)
    void WaitForCompletion(); // 0x997b9c0 (Index: 0x1a, Flags: Native|Public|BlueprintCallable)
    void WaitForPackage(FString& PackageName); // 0x997b9d8 (Index: 0x1b, Flags: Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAssetRegistry) == 0x28, "Size mismatch for UAssetRegistry");

// Size: 0x1190 (Inherited: 0x28, Single: 0x1168)
class UAssetRegistryImpl : public UObject
{
public:
};

static_assert(sizeof(UAssetRegistryImpl) == 0x1190, "Size mismatch for UAssetRegistryImpl");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FTagAndValue
{
    FName Tag; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FString Value; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FTagAndValue) == 0x18, "Size mismatch for FTagAndValue");
static_assert(offsetof(FTagAndValue, Tag) == 0x0, "Offset mismatch for FTagAndValue::Tag");
static_assert(offsetof(FTagAndValue, Value) == 0x8, "Offset mismatch for FTagAndValue::Value");

// Size: 0x5 (Inherited: 0x0, Single: 0x5)
struct FAssetRegistryDependencyOptions
{
    bool bIncludeSoftPackageReferences; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bIncludeHardPackageReferences; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bIncludeSearchableNames; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bIncludeSoftManagementReferences; // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bIncludeHardManagementReferences; // 0x4 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FAssetRegistryDependencyOptions) == 0x5, "Size mismatch for FAssetRegistryDependencyOptions");
static_assert(offsetof(FAssetRegistryDependencyOptions, bIncludeSoftPackageReferences) == 0x0, "Offset mismatch for FAssetRegistryDependencyOptions::bIncludeSoftPackageReferences");
static_assert(offsetof(FAssetRegistryDependencyOptions, bIncludeHardPackageReferences) == 0x1, "Offset mismatch for FAssetRegistryDependencyOptions::bIncludeHardPackageReferences");
static_assert(offsetof(FAssetRegistryDependencyOptions, bIncludeSearchableNames) == 0x2, "Offset mismatch for FAssetRegistryDependencyOptions::bIncludeSearchableNames");
static_assert(offsetof(FAssetRegistryDependencyOptions, bIncludeSoftManagementReferences) == 0x3, "Offset mismatch for FAssetRegistryDependencyOptions::bIncludeSoftManagementReferences");
static_assert(offsetof(FAssetRegistryDependencyOptions, bIncludeHardManagementReferences) == 0x4, "Offset mismatch for FAssetRegistryDependencyOptions::bIncludeHardManagementReferences");

