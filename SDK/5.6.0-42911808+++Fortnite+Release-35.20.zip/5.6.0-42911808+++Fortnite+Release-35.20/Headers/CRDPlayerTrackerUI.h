/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRDPlayerTrackerUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "FortniteUI.h"

// Size: 0xc0 (Inherited: 0xe0, Single: 0xffffffe0)
class UCRDPlayerTrackerUIComponent : public UActorComponent
{
public:
    UCRDPlayerTrackerWidget* SpawnedWidget; // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UCRDPlayerTrackerUIComponent) == 0xc0, "Size mismatch for UCRDPlayerTrackerUIComponent");
static_assert(offsetof(UCRDPlayerTrackerUIComponent, SpawnedWidget) == 0xb8, "Offset mismatch for UCRDPlayerTrackerUIComponent::SpawnedWidget");

// Size: 0x328 (Inherited: 0xa48, Single: 0xfffff8e0)
class UCRDPlayerTrackerWidget : public UFortHUDElementWidget
{
public:
};

static_assert(sizeof(UCRDPlayerTrackerWidget) == 0x328, "Size mismatch for UCRDPlayerTrackerWidget");

