/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Actors
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "JunoGameNative.h"
#include "Engine.h"

// Size: 0x488 (Inherited: 0xa00, Single: 0xfffffa88)
class ABP_JunoSurvival_MapManager_C : public AJunoSurvivalMapManager
{
public:
    USceneComponent* DefaultSceneRoot; // 0x480 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ABP_JunoSurvival_MapManager_C) == 0x488, "Size mismatch for ABP_JunoSurvival_MapManager_C");
static_assert(offsetof(ABP_JunoSurvival_MapManager_C, DefaultSceneRoot) == 0x480, "Offset mismatch for ABP_JunoSurvival_MapManager_C::DefaultSceneRoot");

