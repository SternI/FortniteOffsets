/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GeometryScriptingCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GeometryFramework.h"

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UGeometryScriptDebug : public UObject
{
public:
    TArray<FGeometryScriptDebugMessage> Messages; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGeometryScriptDebug) == 0x38, "Size mismatch for UGeometryScriptDebug");
static_assert(offsetof(UGeometryScriptDebug, Messages) == 0x28, "Offset mismatch for UGeometryScriptDebug::Messages");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_CollisionFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static void ApproximateConvexHullsWithSimplerCollisionShapes(FGeometryScriptSimpleCollision SimpleCollision, const FGeometryScriptConvexHullApproximationOptions ApproximateOptions, bool& bHasApproximated, UGeometryScriptDebug*& Debug); // 0x109d9d78 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void CombineSimpleCollision(FGeometryScriptSimpleCollision CollisionToUpdate, const FGeometryScriptSimpleCollision AppendCollision, UGeometryScriptDebug*& Debug); // 0x109dbe58 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void CombineSimpleCollisionArray(const TArray<FGeometryScriptSimpleCollision> SimpleCollisionArray, FGeometryScriptSimpleCollision& SimpleCollision, UGeometryScriptDebug*& Debug); // 0x109dc060 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptSimpleCollision ComputeNavigableConvexDecomposition(UDynamicMesh*& const TargetMesh, const FNavigableConvexDecompositionOptions Options, UGeometryScriptDebug*& Debug); // 0x109dd230 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptSphereCovering ComputeNegativeSpace(const FGeometryScriptDynamicMeshBVH MeshBVH, const FComputeNegativeSpaceOptions NegativeSpaceOptions, UGeometryScriptDebug*& Debug); // 0x109dd4a8 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static TArray<FSphere> Conv_GeometryScriptSphereCoveringToSphereArray(const FGeometryScriptSphereCovering SphereCovering); // 0x109dd768 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGeometryScriptSphereCovering Conv_SphereArrayToGeometryScriptSphereCovering(const TArray<FSphere> Spheres); // 0x109dd99c (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGeometryScriptSimpleCollision GenerateCollisionFromMesh(UDynamicMesh*& FromDynamicMesh, FGeometryScriptCollisionFromMeshOptions& Options, UGeometryScriptDebug*& Debug); // 0x109e3304 (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGeometryScriptSimpleCollision GetSimpleCollisionFromComponent(UPrimitiveComponent*& Component, UGeometryScriptDebug*& Debug); // 0x109e59fc (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGeometryScriptSimpleCollision GetSimpleCollisionFromStaticMesh(UStaticMesh*& StaticMesh, UGeometryScriptDebug*& Debug); // 0x109e5c3c (Index: 0x9, Flags: Final|Native|Static|Public|BlueprintCallable)
    static int32_t GetSimpleCollisionShapeCount(const FGeometryScriptSimpleCollision SimpleCollision); // 0x109e5e7c (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptSimpleCollision MergeSimpleCollisionShapes(const FGeometryScriptSimpleCollision SimpleCollision, const FGeometryScriptMergeSimpleCollisionOptions MergeOptions, bool& bHasMerged, UGeometryScriptDebug*& Debug); // 0x109e86dc (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ResetDynamicMeshCollision(UDynamicMeshComponent*& Component, bool& bEmitTransaction, UGeometryScriptDebug*& Debug); // 0x109e8998 (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ResetSimpleCollision(FGeometryScriptSimpleCollision SimpleCollision); // 0x109e8c60 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SetDynamicMeshCollisionFromMesh(UDynamicMesh*& FromDynamicMesh, UDynamicMeshComponent*& ToDynamicMeshComponent, FGeometryScriptCollisionFromMeshOptions& Options, UGeometryScriptDebug*& Debug); // 0x109e8fa8 (Index: 0xe, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SetSimpleCollisionOfDynamicMeshComponent(const FGeometryScriptSimpleCollision SimpleCollision, UDynamicMeshComponent*& DynamicMeshComponent, FGeometryScriptSetSimpleCollisionOptions& Options, UGeometryScriptDebug*& Debug); // 0x109e97c4 (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetSimpleCollisionOfStaticMesh(const FGeometryScriptSimpleCollision SimpleCollision, UStaticMesh*& StaticMesh, FGeometryScriptSetSimpleCollisionOptions& Options, FGeometryScriptSetStaticMeshCollisionOptions& StaticMeshCollisionOptions, UGeometryScriptDebug*& Debug); // 0x109e99fc (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetStaticMeshCollisionFromComponent(UStaticMesh*& StaticMeshAsset, UPrimitiveComponent*& SourceComponent, FGeometryScriptSetSimpleCollisionOptions& Options, FGeometryScriptSetStaticMeshCollisionOptions& StaticMeshCollisionOptions, UGeometryScriptDebug*& Debug); // 0x109e9ca4 (Index: 0x11, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetStaticMeshCollisionFromMesh(UDynamicMesh*& FromDynamicMesh, UStaticMesh*& ToStaticMeshAsset, FGeometryScriptCollisionFromMeshOptions& Options, FGeometryScriptSetStaticMeshCollisionOptions& StaticMeshCollisionOptions, UGeometryScriptDebug*& Debug); // 0x109e9fec (Index: 0x12, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool SetStaticMeshCustomComplexCollision(UStaticMesh*& StaticMeshAsset, UStaticMesh*& StaticMeshCollisionAsset, bool& bEmitTransaction, bool& bMarkCollisionAsCustomized, UGeometryScriptDebug*& Debug); // 0x109ea38c (Index: 0x13, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SimplifyConvexHulls(FGeometryScriptSimpleCollision SimpleCollision, const FGeometryScriptConvexHullSimplificationOptions SimplifyOptions, bool& bHasSimplified, UGeometryScriptDebug*& Debug); // 0x109eaa88 (Index: 0x14, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool StaticMeshHasCustomizedCollision(UStaticMesh*& StaticMeshAsset); // 0x4b76ae0 (Index: 0x15, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGeometryScriptSimpleCollision TransformSimpleCollisionShapes(const FGeometryScriptSimpleCollision SimpleCollision, FTransform& Transform, const FGeometryScriptTransformCollisionOptions TransformOptions, bool& bSuccess, UGeometryScriptDebug*& Debug); // 0x109eacfc (Index: 0x16, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_CollisionFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_CollisionFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_ContainmentFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* ComputeMeshConvexDecomposition(UDynamicMesh*& TargetMesh, UDynamicMesh* CopyToMesh, UDynamicMesh*& CopyToMeshOut, FGeometryScriptConvexDecompositionOptions& Options, UGeometryScriptDebug*& Debug); // 0x109dc278 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ComputeMeshConvexHull(UDynamicMesh*& TargetMesh, UDynamicMesh* CopyToMesh, UDynamicMesh*& CopyToMeshOut, FGeometryScriptMeshSelection& Selection, FGeometryScriptConvexHullOptions& Options, UGeometryScriptDebug*& Debug); // 0x109dc72c (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ComputeMeshSweptHull(UDynamicMesh*& TargetMesh, UDynamicMesh* CopyToMesh, UDynamicMesh*& CopyToMeshOut, FTransform& ProjectionFrame, FGeometryScriptSweptHullOptions& Options, UGeometryScriptDebug*& Debug); // 0x109dcc60 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_ContainmentFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_ContainmentFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_ListUtilityFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static void ClearColorList(FGeometryScriptColorList ColorList, FLinearColor& ClearColor); // 0x109db5f8 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void ClearIndexList(FGeometryScriptIndexList IndexList, int32_t& ClearValue); // 0x109db7b0 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ClearScalarList(FGeometryScriptScalarList ScalarList, double& ClearValue); // 0x109db954 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ClearUVList(FGeometryScriptUVList UVList, FVector2D& ClearUV); // 0x109dbad8 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void ClearVectorList(FGeometryScriptVectorList VectorList, FVector& ClearValue); // 0x109dbc90 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void ConvertArrayToColorList(const TArray<FLinearColor> ColorArray, FGeometryScriptColorList& ColorList); // 0x109ddc80 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertArrayToIndexList(const TArray<int32_t> IndexArray, FGeometryScriptIndexList& IndexList, EGeometryScriptIndexType& IndexType); // 0x109ddfdc (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertArrayToScalarList(const TArray<double> VectorArray, FGeometryScriptScalarList& ScalarList); // 0x109de3ac (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertArrayToTriangleList(const TArray<FIntVector> TriangleArray, FGeometryScriptTriangleList& TriangleList); // 0x109de708 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertArrayToUVList(const TArray<FVector2D> UVArray, FGeometryScriptUVList& UVList); // 0x109dea64 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertArrayToVectorList(const TArray<FVector> VectorArray, FGeometryScriptVectorList& VectorList); // 0x109dedc0 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertColorListToArray(FGeometryScriptColorList& ColorList, TArray<FLinearColor>& ColorArray); // 0x109df24c (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertIndexListToArray(FGeometryScriptIndexList& IndexList, TArray<int32_t>& IndexArray); // 0x109df4a4 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertScalarListToArray(FGeometryScriptScalarList& ScalarList, TArray<double>& ScalarArray); // 0x109dfe50 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertTriangleListToArray(FGeometryScriptTriangleList& TriangleList, TArray<FIntVector>& TriangleArray); // 0x109e00a8 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertUVListToArray(FGeometryScriptUVList& UVList, TArray<FVector2D>& UVArray); // 0x109e0300 (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertVectorListToArray(FGeometryScriptVectorList& VectorList, TArray<FVector>& VectorArray); // 0x109e0570 (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void DuplicateColorList(FGeometryScriptColorList& ColorList, FGeometryScriptColorList& DuplicateList); // 0x109e2360 (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void DuplicateIndexList(FGeometryScriptIndexList& IndexList, FGeometryScriptIndexList& DuplicateList); // 0x109e2568 (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void DuplicateScalarList(FGeometryScriptScalarList& ScalarList, FGeometryScriptScalarList& DuplicateList); // 0x109e277c (Index: 0x13, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void DuplicateUVList(FGeometryScriptUVList& UVList, FGeometryScriptUVList& DuplicateList); // 0x109e2984 (Index: 0x14, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void DuplicateVectorList(FGeometryScriptVectorList& VectorList, FGeometryScriptVectorList& DuplicateList); // 0x109e2b8c (Index: 0x15, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ExtractColorListChannel(FGeometryScriptColorList& ColorList, FGeometryScriptScalarList& ScalarList, int32_t& ChannelIndex); // 0x109e2d94 (Index: 0x16, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ExtractColorListChannels(FGeometryScriptColorList& ColorList, FGeometryScriptVectorList& VectorList, int32_t& XChannelIndex, int32_t& YChannelIndex, int32_t& ZChannelIndex); // 0x109e2fd8 (Index: 0x17, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FLinearColor GetColorListItem(FGeometryScriptColorList& ColorList, int32_t& Index, bool& bIsValidIndex); // 0x109e3588 (Index: 0x18, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static int32_t GetColorListLastIndex(FGeometryScriptColorList& ColorList); // 0x109e37e4 (Index: 0x19, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetColorListLength(FGeometryScriptColorList& ColorList); // 0x109e3934 (Index: 0x1a, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetIndexListItem(FGeometryScriptIndexList& IndexList, int32_t& Index, bool& bIsValidIndex); // 0x109e3a40 (Index: 0x1b, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static int32_t GetIndexListLastIndex(FGeometryScriptIndexList& IndexList); // 0x109e3cc0 (Index: 0x1c, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetIndexListLength(FGeometryScriptIndexList& IndexList); // 0x109e3e14 (Index: 0x1d, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static double GetScalarListItem(FGeometryScriptScalarList& ScalarList, int32_t& Index, bool& bIsValidIndex); // 0x109e50fc (Index: 0x1e, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static int32_t GetScalarListLastIndex(FGeometryScriptScalarList& ScalarList); // 0x109e37e4 (Index: 0x1f, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetScalarListLength(FGeometryScriptScalarList& ScalarList); // 0x109e3934 (Index: 0x20, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FIntVector GetTriangleListItem(FGeometryScriptTriangleList& TriangleList, int32_t& Triangle, bool& bIsValidTriangle); // 0x109e5f7c (Index: 0x21, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static int32_t GetTriangleListLastTriangle(FGeometryScriptTriangleList& TriangleList); // 0x109e61ec (Index: 0x22, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetTriangleListLength(FGeometryScriptTriangleList& TriangleList); // 0x109e634c (Index: 0x23, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FVector2D GetUVListItem(FGeometryScriptUVList& UVList, int32_t& Index, bool& bIsValidIndex); // 0x109e6494 (Index: 0x24, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static int32_t GetUVListLastIndex(FGeometryScriptUVList& UVList); // 0x109e37e4 (Index: 0x25, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetUVListLength(FGeometryScriptUVList& UVList); // 0x109e3934 (Index: 0x26, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FVector GetVectorListItem(FGeometryScriptVectorList& VectorList, int32_t& Index, bool& bIsValidIndex); // 0x109e66f0 (Index: 0x27, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static int32_t GetVectorListLastIndex(FGeometryScriptVectorList& VectorList); // 0x109e37e4 (Index: 0x28, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetVectorListLength(FGeometryScriptVectorList& VectorList); // 0x109e3934 (Index: 0x29, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void SetColorListItem(FGeometryScriptColorList ColorList, int32_t& Index, FLinearColor& NewColor, bool& bIsValidIndex); // 0x109e8d38 (Index: 0x2a, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void SetIndexListItem(FGeometryScriptIndexList IndexList, int32_t& Index, int32_t& NewValue, bool& bIsValidIndex); // 0x109e92dc (Index: 0x2b, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetScalarListItem(FGeometryScriptScalarList ScalarList, int32_t& Index, double& NewValue, bool& bIsValidIndex); // 0x109e9550 (Index: 0x2c, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetUVListItem(FGeometryScriptUVList UVList, int32_t& Index, FVector2D& NewUV, bool& bIsValidIndex); // 0x109e8d38 (Index: 0x2d, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void SetVectorListItem(FGeometryScriptVectorList VectorList, int32_t& Index, FVector& NewValue, bool& bIsValidIndex); // 0x109ea810 (Index: 0x2e, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_ListUtilityFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_ListUtilityFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_StaticMeshFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static bool CheckStaticMeshHasAvailableLOD(UStaticMesh*& StaticMeshAsset, FGeometryScriptMeshReadLOD& RequestedLOD, EGeometryScriptSearchOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x109db374 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static TMap<UMaterialInterface*, FName> ConvertMaterialListToMaterialMap(const TArray<UMaterialInterface*> MaterialList, const TArray<FName> MaterialSlotNames); // 0x109df6f8 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertMaterialMapToMaterialList(const TMap<UMaterialInterface*, FName> MaterialMap, TArray<UMaterialInterface*>& MaterialList, TArray<FName>& MaterialSlotNames); // 0x109dfb40 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* CopyMeshFromSkeletalMesh(USkeletalMesh*& FromSkeletalMeshAsset, UDynamicMesh*& ToDynamicMesh, FGeometryScriptCopyMeshFromAssetOptions& AssetOptions, FGeometryScriptMeshReadLOD& RequestedLOD, EGeometryScriptOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x109e07bc (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* CopyMeshFromStaticMesh(UStaticMesh*& FromStaticMeshAsset, UDynamicMesh*& ToDynamicMesh, FGeometryScriptCopyMeshFromAssetOptions& AssetOptions, FGeometryScriptMeshReadLOD& RequestedLOD, EGeometryScriptOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x109e0b9c (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* CopyMeshFromStaticMeshV2(UStaticMesh*& FromStaticMeshAsset, UDynamicMesh*& ToDynamicMesh, FGeometryScriptCopyMeshFromAssetOptions& AssetOptions, FGeometryScriptMeshReadLOD& RequestedLOD, EGeometryScriptOutcomePins& Outcome, bool& bUseSectionMaterials, UGeometryScriptDebug*& Debug); // 0x109e0f80 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* CopyMeshToSkeletalMesh(UDynamicMesh*& FromDynamicMesh, USkeletalMesh*& ToSkeletalMeshAsset, FGeometryScriptCopyMeshToAssetOptions& Options, FGeometryScriptMeshWriteLOD& TargetLod, EGeometryScriptOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x109e1380 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* CopyMeshToStaticMesh(UDynamicMesh*& FromDynamicMesh, UStaticMesh*& ToStaticMeshAsset, FGeometryScriptCopyMeshToAssetOptions& Options, FGeometryScriptMeshWriteLOD& TargetLod, EGeometryScriptOutcomePins& Outcome, bool& bUseSectionMaterials, UGeometryScriptDebug*& Debug); // 0x109e1710 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* CopyMorphTargetToSkeletalMesh(UDynamicMesh*& FromMorphTarget, USkeletalMesh*& ToSkeletalMeshAsset, FName& MorphTargetName, FGeometryScriptCopyMorphTargetToAssetOptions& Options, FGeometryScriptMeshWriteLOD& TargetLod, EGeometryScriptOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x109e1b00 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* CopySkinWeightProfileToSkeletalMesh(UDynamicMesh*& FromDynamicMesh, USkeletalMesh*& ToSkeletalMeshAsset, FName& TargetProfileName, FName& SourceProfileName, FGeometryScriptCopySkinWeightProfileToAssetOptions& Options, FGeometryScriptMeshWriteLOD& TargetLod, EGeometryScriptOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x109e1ef4 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetLODMaterialListFromSkeletalMesh(USkeletalMesh*& FromSkeletalMeshAsset, FGeometryScriptMeshReadLOD& RequestedLOD, TArray<UMaterialInterface*>& MaterialList, TArray<int32_t>& MaterialIndex, TArray<FName>& MaterialSlotNames, EGeometryScriptOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x109e3f2c (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetMaterialListFromSkeletalMesh(USkeletalMesh*& const FromSkeletalMeshAsset, TArray<UMaterialInterface*>& MaterialList, TArray<FName>& MaterialSlotNames, UGeometryScriptDebug*& Debug); // 0x109e4560 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetMaterialListFromStaticMesh(UStaticMesh*& const FromStaticMeshAsset, TArray<UMaterialInterface*>& MaterialList, TArray<FName>& MaterialSlotNames, UGeometryScriptDebug*& Debug); // 0x109e4a20 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static int32_t GetNumStaticMeshLODsOfType(UStaticMesh*& StaticMeshAsset, EGeometryScriptLODType& LODType); // 0x109e4ee0 (Index: 0xd, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void GetSectionMaterialListFromStaticMesh(UStaticMesh*& FromStaticMeshAsset, FGeometryScriptMeshReadLOD& RequestedLOD, TArray<UMaterialInterface*>& MaterialList, TArray<int32_t>& MaterialIndex, TArray<FName>& MaterialSlotNames, EGeometryScriptOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x109e5384 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_StaticMeshFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_StaticMeshFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshBakeFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static TArray<UTexture2D*> BakeTexture(UDynamicMesh*& TargetMesh, FTransform& TargetTransform, FGeometryScriptBakeTargetMeshOptions& TargetOptions, UDynamicMesh*& SourceMesh, FTransform& SourceTransform, FGeometryScriptBakeSourceMeshOptions& SourceOptions, const TArray<FGeometryScriptBakeTypeOptions> BakeTypes, FGeometryScriptBakeTextureOptions& BakeOptions, UGeometryScriptDebug*& Debug); // 0x109d9fec (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FGeometryScriptRenderCaptureTextures BakeTextureFromRenderCaptures(UDynamicMesh*& TargetMesh, FTransform& TargetLocalToWorld, FGeometryScriptBakeTargetMeshOptions& TargetOptions, TArray<AActor*>& const SourceActors, FGeometryScriptBakeRenderCaptureOptions& BakeOptions, UGeometryScriptDebug*& Debug); // 0x109da6b0 (Index: 0x1, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* BakeVertex(UDynamicMesh*& TargetMesh, FTransform& TargetTransform, FGeometryScriptBakeTargetMeshOptions& TargetOptions, UDynamicMesh*& SourceMesh, FTransform& SourceTransform, FGeometryScriptBakeSourceMeshOptions& SourceOptions, FGeometryScriptBakeOutputType& BakeTypes, FGeometryScriptBakeVertexOptions& BakeOptions, UGeometryScriptDebug*& Debug); // 0x109dace4 (Index: 0x2, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static int32_t ConvertBakeResolutionToInt(EGeometryScriptBakeResolution& BakeResolution); // 0x109df11c (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeAmbientOcclusion(int32_t& OcclusionRays, float& MaxDistance, float& SpreadAngle, float& BiasAngle); // 0x109e6964 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeBentNormal(int32_t& OcclusionRays, float& MaxDistance, float& SpreadAngle, EGeometryScriptBakeNormalSpace& NormalSpace); // 0x109e6cfc (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeConstant(float& Value); // 0x109e70cc (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeCurvature(EGeometryScriptBakeCurvatureTypeMode& CurvatureType, EGeometryScriptBakeCurvatureColorMode& ColorMapping, float& ColorRangeMultiplier, float& MinRangeMultiplier, EGeometryScriptBakeCurvatureClampMode& Clamping); // 0x109e721c (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeFaceNormal(); // 0x109e767c (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeHeight(EGeometryScriptBakeHeightRangeMode& RangeMode, float& InnerDistance, float& OuterDistance); // 0x109e7734 (Index: 0x9, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeMaterialID(); // 0x109e7a38 (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeMultiTexture(const TArray<UTexture2D*> MaterialIDSourceTextures, int32_t& SourceUVLayer); // 0x109e7af0 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeObjectNormal(); // 0x109e7e28 (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypePosition(); // 0x109e7ee0 (Index: 0xd, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeTangentNormal(); // 0x109e7f98 (Index: 0xe, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeTexture(UTexture2D*& SourceTexture, int32_t& SourceUVLayer); // 0x109e8050 (Index: 0xf, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeUVShell(int32_t& SourceUVLayer, float& WireframeThickness, FLinearColor& WireframeColor, FLinearColor& ShellColor, FLinearColor& BackgroundColor); // 0x109e8290 (Index: 0x10, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FGeometryScriptBakeTypeOptions MakeBakeTypeVertexColor(); // 0x109e8624 (Index: 0x11, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshBakeFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshBakeFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshBasicEditFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* AddTrianglesToMesh(UDynamicMesh*& TargetMesh, FGeometryScriptTriangleList& NewTrianglesList, FGeometryScriptIndexList& NewIndicesList, int32_t& NewTriangleGroupID, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a1a074 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* AddTriangleToMesh(UDynamicMesh*& TargetMesh, FIntVector& NewTriangle, int32_t& NewTriangleIndex, int32_t& NewTriangleGroupID, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a19cfc (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AddVertexToMesh(UDynamicMesh*& TargetMesh, FVector& NewPosition, int32_t& NewVertexIndex, bool& bDeferChangeNotifications); // 0x10a1a444 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AddVerticesToMesh(UDynamicMesh*& TargetMesh, FGeometryScriptVectorList& NewPositionsList, FGeometryScriptIndexList& NewIndicesList, bool& bDeferChangeNotifications); // 0x10a1a714 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* AppendBuffersToMesh(UDynamicMesh*& TargetMesh, const FGeometryScriptSimpleMeshBuffers Buffers, FGeometryScriptIndexList& NewTriangleIndicesList, int32_t& MaterialID, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a1c21c (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* AppendMesh(UDynamicMesh*& TargetMesh, UDynamicMesh*& AppendMesh, FTransform& AppendTransform, bool& bDeferChangeNotifications, FGeometryScriptAppendMeshOptions& AppendOptions, UGeometryScriptDebug*& Debug); // 0x10a1f670 (Index: 0x5, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendMeshRepeated(UDynamicMesh*& TargetMesh, UDynamicMesh*& AppendMesh, FTransform& AppendTransform, int32_t& RepeatCount, bool& bApplyTransformToFirstInstance, bool& bDeferChangeNotifications, FGeometryScriptAppendMeshOptions& AppendOptions, UGeometryScriptDebug*& Debug); // 0x10a1fb0c (Index: 0x6, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendMeshRepeatedWithMaterials(UDynamicMesh*& TargetMesh, const TArray<UMaterialInterface*> TargetMeshMaterialList, UDynamicMesh*& AppendMesh, const TArray<UMaterialInterface*> AppendMeshMaterialList, TArray<UMaterialInterface*>& ResultMeshMaterialList, FTransform& AppendTransform, int32_t& RepeatCount, bool& bApplyTransformToFirstInstance, bool& bDeferChangeNotifications, FGeometryScriptAppendMeshOptions& AppendOptions, bool& bCompactAppendedMaterials, UGeometryScriptDebug*& Debug); // 0x10a1ffe0 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendMeshTransformed(UDynamicMesh*& TargetMesh, UDynamicMesh*& AppendMesh, const TArray<FTransform> AppendTransforms, FTransform& ConstantTransform, bool& bConstantTransformIsRelative, bool& bDeferChangeNotifications, FGeometryScriptAppendMeshOptions& AppendOptions, UGeometryScriptDebug*& Debug); // 0x10a20958 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendMeshTransformedWithMaterials(UDynamicMesh*& TargetMesh, const TArray<UMaterialInterface*> TargetMeshMaterialList, UDynamicMesh*& AppendMesh, const TArray<UMaterialInterface*> AppendMeshMaterialList, TArray<UMaterialInterface*>& ResultMeshMaterialList, const TArray<FTransform> AppendTransforms, FTransform& ConstantTransform, bool& bConstantTransformIsRelative, bool& bDeferChangeNotifications, FGeometryScriptAppendMeshOptions& AppendOptions, bool& bCompactAppendedMaterials, UGeometryScriptDebug*& Debug); // 0x10a21000 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendMeshWithMaterials(UDynamicMesh*& TargetMesh, const TArray<UMaterialInterface*> TargetMeshMaterialList, UDynamicMesh*& AppendMesh, const TArray<UMaterialInterface*> AppendMeshMaterialList, TArray<UMaterialInterface*>& ResultMeshMaterialList, FTransform& AppendTransform, bool& bDeferChangeNotifications, FGeometryScriptAppendMeshOptions& AppendOptions, bool& bCompactAppendedMaterials, UGeometryScriptDebug*& Debug); // 0x10a21a0c (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* DeleteSelectedTrianglesFromMesh(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, int32_t& NumDeleted, bool& bDeferChangeNotifications); // 0x10a36480 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* DeleteTriangleFromMesh(UDynamicMesh*& TargetMesh, int32_t& TriangleID, bool& bWasTriangleDeleted, bool& bDeferChangeNotifications); // 0x10a36778 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* DeleteTrianglesFromMesh(UDynamicMesh*& TargetMesh, FGeometryScriptIndexList& TriangleList, int32_t& NumDeleted, bool& bDeferChangeNotifications); // 0x10a36edc (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* DeleteVertexFromMesh(UDynamicMesh*& TargetMesh, int32_t& VertexID, bool& bWasVertexDeleted, bool& bDeferChangeNotifications); // 0x10a375e4 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* DeleteVerticesFromMesh(UDynamicMesh*& TargetMesh, FGeometryScriptIndexList& VertexList, int32_t& NumDeleted, bool& bDeferChangeNotifications); // 0x10a37948 (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* DiscardMeshAttributes(UDynamicMesh*& TargetMesh, bool& bDeferChangeNotifications); // 0x10a37ef4 (Index: 0x10, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* MergeMeshVertexPair(UDynamicMesh*& TargetMesh, int32_t& VertexKeep, int32_t& VertexDiscard, FGeometryScriptMergeVertexOptions& Options, bool& bSuccess, double& InterpParam, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a48230 (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* MergeMeshVerticesInSelections(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& SelectionKeep, FGeometryScriptMeshSelection& SelectionDiscard, FGeometryScriptMergeVertexOptions& Options, int32_t& NumMerged, double& InterpParam, double& DistanceThreshold, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a486b4 (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SetAllMeshVertexPositions(UDynamicMesh*& TargetMesh, FGeometryScriptVectorList& PositionList, UGeometryScriptDebug*& Debug); // 0x10a4b77c (Index: 0x13, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetVertexPosition(UDynamicMesh*& TargetMesh, int32_t& VertexID, FVector& NewPosition, bool& bIsValidVertex, bool& bDeferChangeNotifications); // 0x10a4ece4 (Index: 0x14, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshBasicEditFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshBasicEditFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshBoneWeightFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static void BlendBoneWeights(const TArray<FGeometryScriptBoneWeight> BoneWeightsA, const TArray<FGeometryScriptBoneWeight> BoneWeightsB, float& Alpha, TArray<FGeometryScriptBoneWeight>& Result, UGeometryScriptDebug*& Debug); // 0x10a2fa08 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UDynamicMesh* ComputeSmoothBoneWeights(UDynamicMesh*& TargetMesh, USkeleton*& Skeleton, FGeometryScriptSmoothBoneWeightsOptions& Options, FGeometryScriptBoneWeightProfile& Profile, UGeometryScriptDebug*& Debug); // 0x10a328d4 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* CopyBonesFromMesh(UDynamicMesh*& SourceMesh, UDynamicMesh*& TargetMesh, FGeometryScriptCopyBonesFromMeshOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a345a0 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* CopyBonesFromSkeleton(USkeleton*& SourceSkeleton, UDynamicMesh*& TargetMesh, FGeometryScriptCopyBonesFromMeshOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a34884 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* DiscardBonesFromMesh(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a37cd8 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* GetAllBonesInfo(UDynamicMesh*& TargetMesh, TArray<FGeometryScriptBoneInfo>& BonesInfo, UGeometryScriptDebug*& Debug); // 0x10a39300 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetBoneChildren(UDynamicMesh*& TargetMesh, FName& BoneName, bool& bRecursive, bool& bIsValidBoneName, TArray<FGeometryScriptBoneInfo>& ChildrenInfo, UGeometryScriptDebug*& Debug); // 0x10a3b498 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetBoneIndex(UDynamicMesh*& TargetMesh, FName& BoneName, bool& bIsValidBoneName, int32_t& BoneIndex, UGeometryScriptDebug*& Debug); // 0x10a3baa8 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetBoneInfo(UDynamicMesh*& TargetMesh, FName& BoneName, bool& bIsValidBoneName, FGeometryScriptBoneInfo& BoneInfo, UGeometryScriptDebug*& Debug); // 0x10a3be68 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetLargestVertexBoneWeight(UDynamicMesh*& TargetMesh, int32_t& VertexID, FGeometryScriptBoneWeight& BoneWeight, bool& bHasValidBoneWeights, FGeometryScriptBoneWeightProfile& Profile); // 0x10a3e2cc (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetMaxBoneWeightIndex(UDynamicMesh*& TargetMesh, bool& bHasBoneWeights, int32_t& MaxBoneIndex, FGeometryScriptBoneWeightProfile& Profile); // 0x10a3e924 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetRootBoneName(UDynamicMesh*& TargetMesh, FName& BoneName, UGeometryScriptDebug*& Debug); // 0x10a41f74 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetVertexBoneWeights(UDynamicMesh*& TargetMesh, int32_t& VertexID, TArray<FGeometryScriptBoneWeight>& BoneWeights, bool& bHasValidBoneWeights, FGeometryScriptBoneWeightProfile& Profile); // 0x10a45d20 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* MeshCopyBoneWeights(UDynamicMesh*& TargetMesh, bool& bProfileExisted, FGeometryScriptBoneWeightProfile& TargetProfile, FGeometryScriptBoneWeightProfile& SourceProfile); // 0x10a48bbc (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* MeshCreateBoneWeights(UDynamicMesh*& TargetMesh, bool& bProfileExisted, bool& bReplaceExistingProfile, FGeometryScriptBoneWeightProfile& Profile); // 0x10a48e84 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* MeshHasBoneWeights(UDynamicMesh*& TargetMesh, bool& bHasBoneWeights, FGeometryScriptBoneWeightProfile& Profile); // 0x10a4919c (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UDynamicMesh* PruneBoneWeights(UDynamicMesh*& TargetMesh, const TArray<FName> BonesToPrune, FGeometryScriptPruneBoneWeightsOptions& Options, FGeometryScriptBoneWeightProfile& Profile, UGeometryScriptDebug*& Debug); // 0x10a49424 (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SetAllVertexBoneWeights(UDynamicMesh*& TargetMesh, const TArray<FGeometryScriptBoneWeight> BoneWeights, FGeometryScriptBoneWeightProfile& Profile, UGeometryScriptDebug*& Debug); // 0x10a4bcb0 (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SetVertexBoneWeights(UDynamicMesh*& TargetMesh, int32_t& VertexID, const TArray<FGeometryScriptBoneWeight> BoneWeights, bool& bIsValidVertexID, FGeometryScriptBoneWeightProfile& Profile, UGeometryScriptDebug*& Debug); // 0x10a4e714 (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* TransferBoneWeightsFromMesh(UDynamicMesh*& SourceMesh, UDynamicMesh*& TargetMesh, FGeometryScriptTransferBoneWeightsOptions& Options, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a509f0 (Index: 0x13, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshBoneWeightFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshBoneWeightFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshBooleanFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* ApplyMeshBoolean(UDynamicMesh*& TargetMesh, FTransform& TargetTransform, UDynamicMesh*& ToolMesh, FTransform& ToolTransform, EGeometryScriptBooleanOperation& Operation, FGeometryScriptMeshBooleanOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a2c3fc (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* ApplyMeshMirror(UDynamicMesh*& TargetMesh, FTransform& MirrorFrame, FGeometryScriptMeshMirrorOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a2d8b8 (Index: 0x1, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* ApplyMeshPlaneCut(UDynamicMesh*& TargetMesh, FTransform& CutFrame, FGeometryScriptMeshPlaneCutOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a2e0e4 (Index: 0x2, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* ApplyMeshPlaneSlice(UDynamicMesh*& TargetMesh, FTransform& CutFrame, FGeometryScriptMeshPlaneSliceOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a2e410 (Index: 0x3, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* ApplyMeshSelfUnion(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelfUnionOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a2ea00 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshBooleanFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshBooleanFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshComparisonFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* IsIntersectingMesh(UDynamicMesh*& TargetMesh, FTransform& TargetTransform, UDynamicMesh*& OtherMesh, FTransform& OtherTransform, bool& bIsIntersecting, UGeometryScriptDebug*& Debug); // 0x10a46f34 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* IsSameMeshAs(UDynamicMesh*& TargetMesh, UDynamicMesh*& OtherMesh, FGeometryScriptIsSameMeshOptions& Options, bool& bIsSameMesh, FGeometryScriptMeshDifferenceInfo& DifferenceInfo, UGeometryScriptDebug*& Debug); // 0x10a473d0 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* MeasureDistancesBetweenMeshes(UDynamicMesh*& TargetMesh, UDynamicMesh*& OtherMesh, FGeometryScriptMeasureMeshDistanceOptions& Options, double& MaxDistance, double& MinDistance, double& AverageDistance, double& RootMeanSqrDeviation, UGeometryScriptDebug*& Debug); // 0x10a47db4 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshComparisonFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshComparisonFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshDecompositionFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* CopyMeshSelectionToMesh(UDynamicMesh*& TargetMesh, UDynamicMesh* StoreToSubmesh, FGeometryScriptMeshSelection& Selection, UDynamicMesh*& StoreToSubmeshOut, bool& bAppendToExisting, bool& bPreserveGroupIDs, UGeometryScriptDebug*& Debug); // 0x10a34b68 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* CopyMeshToMesh(UDynamicMesh*& CopyFromMesh, UDynamicMesh* CopyToMesh, UDynamicMesh*& CopyToMeshOut, UGeometryScriptDebug*& Debug); // 0x10a35104 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetSubMeshFromMesh(UDynamicMesh*& TargetMesh, UDynamicMesh* StoreToSubmesh, FGeometryScriptIndexList& TriangleList, UDynamicMesh*& StoreToSubmeshOut, UGeometryScriptDebug*& Debug); // 0x10a42ac8 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SplitMeshByComponents(UDynamicMesh*& TargetMesh, TArray<UDynamicMesh*>& ComponentMeshes, UDynamicMeshPool*& MeshPool, UGeometryScriptDebug*& Debug); // 0x10a4f68c (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SplitMeshByMaterialIDs(UDynamicMesh*& TargetMesh, TArray<UDynamicMesh*>& ComponentMeshes, TArray<int32_t>& ComponentMaterialIDs, UDynamicMeshPool*& MeshPool, UGeometryScriptDebug*& Debug); // 0x10a4fad0 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SplitMeshByPolygroups(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, TArray<UDynamicMesh*>& ComponentMeshes, TArray<int32_t>& ComponentPolygroups, UDynamicMeshPool*& MeshPool, UGeometryScriptDebug*& Debug); // 0x10a4ffc0 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SplitMeshByVertexOverlap(UDynamicMesh*& TargetMesh, TArray<UDynamicMesh*>& ComponentMeshes, UDynamicMeshPool*& MeshPool, double& ConnectVerticesThreshold, UGeometryScriptDebug*& Debug); // 0x10a50530 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshDecompositionFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshDecompositionFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshDeformFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* ApplyBendWarpToMesh(UDynamicMesh*& TargetMesh, FGeometryScriptBendWarpOptions& Options, FTransform& BendOrientation, float& BendAngle, float& BendExtent, UGeometryScriptDebug*& Debug); // 0x10a2a940 (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* ApplyDisplaceFromPerVertexVectors(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, const FGeometryScriptVectorList VectorList, float& Magnitude, UGeometryScriptDebug*& Debug); // 0x10a2ad28 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ApplyDisplaceFromTextureMap(UDynamicMesh*& TargetMesh, UTexture2D*& Texture, FGeometryScriptMeshSelection& Selection, FGeometryScriptDisplaceFromTextureOptions& Options, int32_t& UVLayer, UGeometryScriptDebug*& Debug); // 0x10a2b034 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyFlareWarpToMesh(UDynamicMesh*& TargetMesh, FGeometryScriptFlareWarpOptions& Options, FTransform& FlareOrientation, float& FlarePercentX, float& FlarePercentY, float& FlareExtent, UGeometryScriptDebug*& Debug); // 0x10a2b3b0 (Index: 0x3, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* ApplyIterativeSmoothingToMesh(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FGeometryScriptIterativeMeshSmoothingOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a2b80c (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyMathWarpToMesh(UDynamicMesh*& TargetMesh, FTransform& WarpOrientation, EGeometryScriptMathWarpType& WarpType, FGeometryScriptMathWarpOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a2babc (Index: 0x5, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* ApplyPerlinNoiseToMesh(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FGeometryScriptPerlinNoiseOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a2ee68 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyTwistWarpToMesh(UDynamicMesh*& TargetMesh, FGeometryScriptTwistWarpOptions& Options, FTransform& TwistOrientation, float& TwistAngle, float& TwistExtent, UGeometryScriptDebug*& Debug); // 0x10a2f144 (Index: 0x7, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshDeformFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshDeformFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshGeodesicFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* CreateSurfacePath(UDynamicMesh*& TargetMesh, FVector& Direction, int32_t& StartTriangleID, FVector& StartBaryCoords, float& MaxPathLength, FGeometryScriptPolyPath& SurfacePath, bool& bFoundErrors, UGeometryScriptDebug*& Debug); // 0x10a36000 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* GetShortestSurfacePath(UDynamicMesh*& TargetMesh, int32_t& StartTriangleID, FVector& StartBaryCoords, int32_t& EndTriangleID, FVector& EndBaryCoords, FGeometryScriptPolyPath& ShortestPath, bool& bFoundErrors, UGeometryScriptDebug*& Debug); // 0x10a421c8 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* GetShortestVertexPath(UDynamicMesh*& TargetMesh, int32_t& StartVertexID, int32_t& EndVertexID, FGeometryScriptIndexList& VertexIDList, bool& bFoundErrors, UGeometryScriptDebug*& Debug); // 0x10a42660 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshGeodesicFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshGeodesicFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshMaterialFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* ClearMaterialIDs(UDynamicMesh*& TargetMesh, int32_t& ClearValue, UGeometryScriptDebug*& Debug); // 0x10a2ff5c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* CompactMaterialIDs(UDynamicMesh*& TargetMesh, TArray<UMaterialInterface*>& SourceMaterialList, TArray<UMaterialInterface*>& CompactedMaterialList, bool& bRemoveDuplicateMaterials, UGeometryScriptDebug*& Debug); // 0x10a3049c (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* DeleteTrianglesByMaterialID(UDynamicMesh*& TargetMesh, int32_t& MaterialID, int32_t& NumDeleted, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a36adc (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* EnableMaterialIDs(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a3832c (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* GetAllTriangleMaterialIDs(UDynamicMesh*& TargetMesh, FGeometryScriptIndexList& MaterialIDList, bool& bHasMaterialIDs); // 0x10a3a2a8 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UDynamicMesh* GetMaterialIDsOfTriangles(UDynamicMesh*& TargetMesh, FGeometryScriptIndexList& TriangleIDList, FGeometryScriptIndexList& MaterialIDList, UGeometryScriptDebug*& Debug); // 0x10a3e658 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static int32_t GetMaxMaterialID(UDynamicMesh*& TargetMesh, bool& bHasMaterialIDs); // 0x10a3ec54 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static int32_t GetTriangleMaterialID(UDynamicMesh*& TargetMesh, int32_t& TriangleID, bool& bIsValidTriangle); // 0x10a4357c (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UDynamicMesh* GetTrianglesByMaterialID(UDynamicMesh*& TargetMesh, int32_t& MaterialID, FGeometryScriptIndexList& TriangleIDList, UGeometryScriptDebug*& Debug); // 0x10a452fc (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UDynamicMesh* RemapAndCombineMaterials(UDynamicMesh*& TargetMesh, const TArray<UMaterialInterface*> TargetMeshMaterials, const TArray<UMaterialInterface*> RequiredMaterials, TArray<UMaterialInterface*>& CombinedMaterials, int32_t& RemapInvalidMaterialID, bool& bCompactDuplicateMaterials, UGeometryScriptDebug*& Debug); // 0x10a49dcc (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* RemapMaterialIDs(UDynamicMesh*& TargetMesh, int32_t& FromMaterialID, int32_t& ToMaterialID, UGeometryScriptDebug*& Debug); // 0x10a4a448 (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* RemapToNewMaterialIDsByMaterial(UDynamicMesh*& TargetMesh, const TArray<UMaterialInterface*> FromMaterialList, const TArray<UMaterialInterface*> ToMaterialList, int32_t& MissingMaterialID, UGeometryScriptDebug*& Debug); // 0x10a4a7f8 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SetAllTriangleMaterialIDs(UDynamicMesh*& TargetMesh, FGeometryScriptIndexList& TriangleMaterialIDList, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a4b9d8 (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetMaterialIDForMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, int32_t& MaterialID, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a4c0f8 (Index: 0xd, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetMaterialIDOnTriangles(UDynamicMesh*& TargetMesh, FGeometryScriptIndexList& TriangleIDList, int32_t& MaterialID, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a4c3b0 (Index: 0xe, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetPolygroupMaterialID(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, int32_t& PolygroupID, int32_t& MaterialID, bool& bIsValidPolygroupID, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a4dae4 (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SetTriangleMaterialID(UDynamicMesh*& TargetMesh, int32_t& TriangleID, int32_t& MaterialID, bool& bIsValidTriangle, bool& bDeferChangeNotifications); // 0x10a4e2cc (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshMaterialFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshMaterialFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshModelingFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* ApplyMeshBevelEdgeSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FGeometryScriptMeshBevelSelectionOptions& BevelOptions, UGeometryScriptDebug*& Debug); // 0x10a2be60 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyMeshBevelSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, EGeometryScriptMeshBevelSelectionMode& BevelMode, FGeometryScriptMeshBevelSelectionOptions& BevelOptions, UGeometryScriptDebug*& Debug); // 0x10a2c11c (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyMeshDisconnectFaces(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, bool& bAllowBowtiesInOutput, UGeometryScriptDebug*& Debug); // 0x10a2c908 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyMeshDisconnectFacesAlongEdges(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a2cb94 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyMeshDuplicateFaces(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FGeometryScriptMeshSelection& NewTriangles, FGeometryScriptMeshEditPolygroupOptions& GroupOptions, UGeometryScriptDebug*& Debug); // 0x10a2cdc4 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ApplyMeshExtrude_Compatibility_5p0(UDynamicMesh*& TargetMesh, FGeometryScriptMeshExtrudeOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a2d0b4 (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyMeshInsetOutsetFaces(UDynamicMesh*& TargetMesh, FGeometryScriptMeshInsetOutsetFacesOptions& Options, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a2d300 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyMeshLinearExtrudeFaces(UDynamicMesh*& TargetMesh, FGeometryScriptMeshLinearExtrudeOptions& Options, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a2d5cc (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyMeshOffset(UDynamicMesh*& TargetMesh, FGeometryScriptMeshOffsetOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a2dbe4 (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyMeshOffsetFaces(UDynamicMesh*& TargetMesh, FGeometryScriptMeshOffsetFacesOptions& Options, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a2de20 (Index: 0x9, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyMeshPolygroupBevel(UDynamicMesh*& TargetMesh, FGeometryScriptMeshBevelOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a2e750 (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyMeshShell(UDynamicMesh*& TargetMesh, FGeometryScriptMeshOffsetOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a2ec2c (Index: 0xb, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshModelingFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshModelingFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshNormalsFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* AutoRepairNormals(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a2f800 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ComputeSplitNormals(UDynamicMesh*& TargetMesh, FGeometryScriptSplitNormalsOptions& SplitOptions, FGeometryScriptCalculateNormalsOptions& CalculateOptions, UGeometryScriptDebug*& Debug); // 0x10a32c44 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ComputeTangents(UDynamicMesh*& TargetMesh, FGeometryScriptTangentsOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a32ed4 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* DiscardTangents(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a38124 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* FlipNormals(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a38dd0 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* FlipTriangleSelectionNormals(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, bool& bFlipTriangleOrientation, bool& bFlipNormalDirection, UGeometryScriptDebug*& Debug); // 0x10a38fd8 (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* GetMeshHasTangents(UDynamicMesh*& TargetMesh, bool& bHasTangents, UGeometryScriptDebug*& Debug); // 0x10a3f118 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetMeshPerVertexNormals(UDynamicMesh*& TargetMesh, FGeometryScriptVectorList& NormalList, bool& bIsValidNormalSet, bool& bHasVertexIDGaps, bool& bAverageSplitVertexValues); // 0x10a3f6c4 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetMeshPerVertexTangents(UDynamicMesh*& TargetMesh, FGeometryScriptVectorList& TangentXList, FGeometryScriptVectorList& TangentYList, bool& bIsValidTangentSet, bool& bHasVertexIDGaps, bool& bAverageSplitVertexValues); // 0x10a3fa30 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* RecomputeNormals(UDynamicMesh*& TargetMesh, FGeometryScriptCalculateNormalsOptions& CalculateOptions, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a4989c (Index: 0x9, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* RecomputeNormalsForMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FGeometryScriptCalculateNormalsOptions& CalculateOptions, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a49b14 (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetMeshPerVertexNormals(UDynamicMesh*& TargetMesh, FGeometryScriptVectorList& VertexNormalList, UGeometryScriptDebug*& Debug); // 0x10a4c6a4 (Index: 0xb, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetMeshPerVertexTangents(UDynamicMesh*& TargetMesh, FGeometryScriptVectorList& TangentXList, FGeometryScriptVectorList& TangentYList, UGeometryScriptDebug*& Debug); // 0x10a4c900 (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetMeshTriangleNormals(UDynamicMesh*& TargetMesh, int32_t& TriangleID, FGeometryScriptTriangle& Normals, bool& bIsValidTriangle, bool& bDeferChangeNotifications); // 0x10a4cbc8 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SetPerFaceNormals(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a4d2ac (Index: 0xe, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetPerVertexNormals(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a4d4b4 (Index: 0xf, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetSplitNormalsAlongSelectedEdges(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, bool& bSplit, bool& bRecalculateNormals, FGeometryScriptCalculateNormalsOptions& CalculateOptions, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a4dee0 (Index: 0x10, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* UpdateVertexNormal(UDynamicMesh*& TargetMesh, int32_t& VertexID, bool& bUpdateNormal, FVector& NewNormal, bool& bUpdateTangents, FVector& NewTangentX, FVector& NewTangentY, bool& bIsValidVertex, bool& bMergeSplitValues, bool& bDeferChangeNotifications); // 0x10a50d6c (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshNormalsFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshNormalsFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshPolygroupFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* AddNamedPolygroupLayer(UDynamicMesh*& TargetMesh, FName& LayerName, FGeometryScriptGroupLayer& GroupLayer, bool& bAlreadyExisted, UGeometryScriptDebug*& Debug); // 0x10a19974 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ClearPolygroups(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, int32_t& ClearValue, UGeometryScriptDebug*& Debug); // 0x10a30230 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ComputePolygroupsFromAngleThreshold(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, float& CreaseAngle, int32_t& MinGroupSize, UGeometryScriptDebug*& Debug); // 0x10a31860 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ComputePolygroupsFromPolygonDetection(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, bool& bRespectUVSeams, bool& bRespectHardNormals, double& QuadAdjacencyWeight, double& QuadMetricClamp, int32_t& MaxSearchRounds, UGeometryScriptDebug*& Debug); // 0x10a31b3c (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ConvertComponentsToPolygroups(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, UGeometryScriptDebug*& Debug); // 0x10a3412c (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ConvertUVIslandsToPolygroups(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, int32_t& UVLayer, UGeometryScriptDebug*& Debug); // 0x10a34334 (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* CopyPolygroupsLayer(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& FromGroupLayer, FGeometryScriptGroupLayer& ToGroupLayer, UGeometryScriptDebug*& Debug); // 0x10a3554c (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* DeleteTrianglesInPolygroup(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, int32_t& PolygroupID, int32_t& NumDeleted, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a37260 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* EnablePolygroups(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a38534 (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* FindExtendedPolygroupLayerByName(UDynamicMesh*& const TargetMesh, FName& LayerName, FGeometryScriptGroupLayer& GroupLayer, EGeometryScriptSearchOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x10a38a48 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetAllTrianglePolygroupIDs(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, FGeometryScriptIndexList PolygroupIDsOut); // 0x10a3a544 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetPolyGroupBoundingBox(UDynamicMesh*& const TargetMesh, FGeometryScriptGroupLayer& GroupLayer, int32_t& GroupId, FBox& Bounds); // 0x10a41314 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* GetPolygroupIDsInMesh(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, FGeometryScriptIndexList PolygroupIDsOut); // 0x10a41d20 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetPolyGroupUVBoundingBox(UDynamicMesh*& const TargetMesh, FGeometryScriptGroupLayer& GroupLayer, int32_t& GroupId, int32_t& UVChannel, FBox2D& UVBounds); // 0x10a41624 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* GetPolyGroupUVCentroid(UDynamicMesh*& const TargetMesh, FGeometryScriptGroupLayer& GroupLayer, int32_t& GroupId, int32_t& UVChannel, FVector2D& Centroid, bool& bIsValid); // 0x10a41984 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static int32_t GetTrianglePolygroupID(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, int32_t& TriangleID, bool& bIsValidTriangle); // 0x10a441ac (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UDynamicMesh* GetTrianglesInPolygroup(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, int32_t& PolygroupID, FGeometryScriptIndexList TriangleIDsOut); // 0x10a45634 (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SetNumExtendedPolygroupLayers(UDynamicMesh*& TargetMesh, int32_t& NumLayers, UGeometryScriptDebug*& Debug); // 0x10a4cfd8 (Index: 0x11, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetPolygroupForMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, FGeometryScriptMeshSelection& Selection, int32_t& SetPolygroupIDOut, int32_t& SetPolygroupID, bool& bGenerateNewPolygroup, bool& bDeferChangeNotifications); // 0x10a4d6bc (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshPolygroupFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshPolygroupFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshPoolFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static void DiscardGlobalMeshPool(); // 0x10a37ee0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMeshPool* GetGlobalMeshPool(); // 0x10a3c240 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshPoolFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshPoolFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshPrimitiveFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* AppendBoundingBox(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, FBox& Box, int32_t& StepsX, int32_t& StepsY, int32_t& StepsZ, UGeometryScriptDebug*& Debug); // 0x10a1aa7c (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendBoundingBoxWithCollision(UDynamicMesh*& TargetMesh, FGeometryScriptSimpleCollision& SimpleCollision, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, FBox& Box, int32_t& StepsX, int32_t& StepsY, int32_t& StepsZ, UGeometryScriptDebug*& Debug); // 0x10a1af74 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendBox(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& DimensionX, float& DimensionY, float& DimensionZ, int32_t& StepsX, int32_t& StepsY, int32_t& StepsZ, EGeometryScriptPrimitiveOriginMode& origin, UGeometryScriptDebug*& Debug); // 0x10a1b508 (Index: 0x2, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendBoxWithCollision(UDynamicMesh*& TargetMesh, FGeometryScriptSimpleCollision& SimpleCollision, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& DimensionX, float& DimensionY, float& DimensionZ, int32_t& StepsX, int32_t& StepsY, int32_t& StepsZ, EGeometryScriptPrimitiveOriginMode& origin, UGeometryScriptDebug*& Debug); // 0x10a1bb1c (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendCapsule(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& Radius, float& LineLength, int32_t& HemisphereSteps, int32_t& CircleSteps, int32_t& SegmentSteps, EGeometryScriptPrimitiveOriginMode& origin, UGeometryScriptDebug*& Debug); // 0x10a1c5d4 (Index: 0x4, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendCapsuleWithCollision(UDynamicMesh*& TargetMesh, FGeometryScriptSimpleCollision& SimpleCollision, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& Radius, float& LineLength, int32_t& HemisphereSteps, int32_t& CircleSteps, int32_t& SegmentSteps, EGeometryScriptPrimitiveOriginMode& origin, UGeometryScriptDebug*& Debug); // 0x10a1cb74 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendCone(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& BaseRadius, float& TopRadius, float& Height, int32_t& RadialSteps, int32_t& HeightSteps, bool& bCapped, EGeometryScriptPrimitiveOriginMode& origin, UGeometryScriptDebug*& Debug); // 0x10a1d1fc (Index: 0x6, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendCurvedStairs(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& StepWidth, float& StepHeight, float& InnerRadius, float& CurveAngle, int32_t& NumSteps, bool& bFloating, UGeometryScriptDebug*& Debug); // 0x10a1d814 (Index: 0x7, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendCylinder(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& Radius, float& Height, int32_t& RadialSteps, int32_t& HeightSteps, bool& bCapped, EGeometryScriptPrimitiveOriginMode& origin, UGeometryScriptDebug*& Debug); // 0x10a1ddc4 (Index: 0x8, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendDelaunayTriangulation2D(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const TArray<FVector2D> VertexPositions, const TArray<FIntPoint> ConstrainedEdges, FGeometryScriptConstrainedDelaunayTriangulationOptions& TriangulationOptions, TArray<int32_t>& PositionsToVertexIDs, bool& bHasDuplicateVertices, UGeometryScriptDebug*& Debug); // 0x10a1e374 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendDisc(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& Radius, int32_t& AngleSteps, int32_t& SpokeSteps, float& StartAngle, float& EndAngle, float& HoleRadius, UGeometryScriptDebug*& Debug); // 0x10a1eb98 (Index: 0xa, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendLinearStairs(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& StepWidth, float& StepHeight, float& StepDepth, int32_t& NumSteps, bool& bFloating, UGeometryScriptDebug*& Debug); // 0x10a1f140 (Index: 0xb, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendPolygonListTriangulation(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, FGeometryScriptGeneralPolygonList& PolygonList, FGeometryScriptPolygonsTriangulationOptions& TriangulationOptions, bool& bTriangulationError, UGeometryScriptDebug*& Debug); // 0x10a22290 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendRectangle_Compatibility_5_0(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& DimensionX, float& DimensionY, int32_t& StepsWidth, int32_t& StepsHeight, UGeometryScriptDebug*& Debug); // 0x10a22bf8 (Index: 0xd, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendRectangleXY(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& DimensionX, float& DimensionY, int32_t& StepsWidth, int32_t& StepsHeight, UGeometryScriptDebug*& Debug); // 0x10a22740 (Index: 0xe, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendRevolvePath(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const TArray<FVector2D> PathVertices, FGeometryScriptRevolveOptions& RevolveOptions, int32_t& Steps, bool& bCapped, UGeometryScriptDebug*& Debug); // 0x10a230c0 (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendRevolvePolygon(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const TArray<FVector2D> PolygonVertices, FGeometryScriptRevolveOptions& RevolveOptions, float& Radius, int32_t& Steps, UGeometryScriptDebug*& Debug); // 0x10a23760 (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendRoundRectangle_Compatibility_5_0(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& DimensionX, float& DimensionY, float& CornerRadius, int32_t& StepsWidth, int32_t& StepsHeight, int32_t& StepsRound, UGeometryScriptDebug*& Debug); // 0x10a2439c (Index: 0x11, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendRoundRectangleXY(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& DimensionX, float& DimensionY, float& CornerRadius, int32_t& StepsWidth, int32_t& StepsHeight, int32_t& StepsRound, UGeometryScriptDebug*& Debug); // 0x10a23df8 (Index: 0x12, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendSimpleCollisionShapes(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const FGeometryScriptSimpleCollision SimpleCollision, FGeometryScriptSimpleCollisionTriangulationOptions& TriangulationOptions, UGeometryScriptDebug*& Debug); // 0x10a24950 (Index: 0x13, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendSimpleExtrudePolygon(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const TArray<FVector2D> PolygonVertices, float& Height, int32_t& HeightSteps, bool& bCapped, EGeometryScriptPrimitiveOriginMode& origin, UGeometryScriptDebug*& Debug); // 0x10a24d80 (Index: 0x14, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendSimpleSweptPolygon(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const TArray<FVector2D> PolygonVertices, const TArray<FVector> SweepPath, bool& bLoop, bool& bCapped, float& StartScale, float& EndScale, float& RotationAngleDeg, float& MiterLimit, UGeometryScriptDebug*& Debug); // 0x10a25478 (Index: 0x15, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendSphereBox(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& Radius, int32_t& StepsX, int32_t& StepsY, int32_t& StepsZ, EGeometryScriptPrimitiveOriginMode& origin, UGeometryScriptDebug*& Debug); // 0x10a25da4 (Index: 0x16, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendSphereBoxWithCollision(UDynamicMesh*& TargetMesh, FGeometryScriptSimpleCollision& SimpleCollision, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& Radius, int32_t& StepsX, int32_t& StepsY, int32_t& StepsZ, EGeometryScriptPrimitiveOriginMode& origin, UGeometryScriptDebug*& Debug); // 0x10a262d4 (Index: 0x17, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendSphereCovering(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const FGeometryScriptSphereCovering SphereCovering, int32_t& StepsX, int32_t& StepsY, int32_t& StepsZ, UGeometryScriptDebug*& Debug); // 0x10a268e8 (Index: 0x18, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendSphereLatLong(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& Radius, int32_t& StepsPhi, int32_t& StepsTheta, EGeometryScriptPrimitiveOriginMode& origin, UGeometryScriptDebug*& Debug); // 0x10a26e00 (Index: 0x19, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendSphereLatLongWithCollision(UDynamicMesh*& TargetMesh, FGeometryScriptSimpleCollision& SimpleCollision, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, float& Radius, int32_t& StepsPhi, int32_t& StepsTheta, EGeometryScriptPrimitiveOriginMode& origin, UGeometryScriptDebug*& Debug); // 0x10a272bc (Index: 0x1a, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendSpiralRevolvePolygon(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const TArray<FVector2D> PolygonVertices, FGeometryScriptRevolveOptions& RevolveOptions, float& Radius, int32_t& Steps, float& RisePerRevolution, UGeometryScriptDebug*& Debug); // 0x10a27830 (Index: 0x1b, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendSweepPolygon(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const TArray<FVector2D> PolygonVertices, const TArray<FTransform> SweepPath, bool& bLoop, bool& bCapped, float& StartScale, float& EndScale, float& RotationAngleDeg, float& MiterLimit, UGeometryScriptDebug*& Debug); // 0x10a27f3c (Index: 0x1c, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendSweepPolyline(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const TArray<FVector2D> PolylineVertices, const TArray<FTransform> SweepPath, const TArray<float> PolylineTexParamU, const TArray<float> SweepPathTexParamV, bool& bLoop, float& StartScale, float& EndScale, float& RotationAngleDeg, float& MiterLimit, UGeometryScriptDebug*& Debug); // 0x10a28868 (Index: 0x1d, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendTorus(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, FGeometryScriptRevolveOptions& RevolveOptions, float& MajorRadius, float& MinorRadius, int32_t& MajorSteps, int32_t& MinorSteps, EGeometryScriptPrimitiveOriginMode& origin, UGeometryScriptDebug*& Debug); // 0x10a29310 (Index: 0x1e, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendTriangulatedPolygon(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const TArray<FVector2D> PolygonVertices, bool& bAllowSelfIntersections, UGeometryScriptDebug*& Debug); // 0x10a29de8 (Index: 0x1f, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendTriangulatedPolygon3D(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const TArray<FVector> PolygonVertices3D, UGeometryScriptDebug*& Debug); // 0x10a298dc (Index: 0x20, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* AppendVoronoiDiagram2D(UDynamicMesh*& TargetMesh, FGeometryScriptPrimitiveOptions& PrimitiveOptions, FTransform& Transform, const TArray<FVector2D> VoronoiSites, FGeometryScriptVoronoiOptions& VoronoiOptions, UGeometryScriptDebug*& Debug); // 0x10a2a374 (Index: 0x21, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static TArray<FIntPoint> CreateConstrainedEdgesChain(int32_t& NumVertices, int32_t& Start); // 0x10a357bc (Index: 0x22, Flags: Final|Native|Static|Public|BlueprintCallable)
    static TArray<FIntPoint> CreateConstrainedEdgesLoop(int32_t& NumVertices, int32_t& Start); // 0x10a35be8 (Index: 0x23, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshPrimitiveFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshPrimitiveFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshQueryFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* ComputeTriangleBarycentricCoords(UDynamicMesh*& TargetMesh, int32_t& TriangleID, bool& bIsValidTriangle, FVector& Point, FVector& Vertex1, FVector& Vertex2, FVector& Vertex3, FVector& BarycentricCoords); // 0x10a330dc (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* GetAllSplitUVsAtVertex(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, int32_t& VertexID, TArray<int32_t>& ElementIDs, TArray<FVector2D>& ElementUVs, bool& bHaveValidUVs); // 0x10a396d8 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetAllTriangleIDs(UDynamicMesh*& TargetMesh, FGeometryScriptIndexList& TriangleIDList, bool& bHasTriangleIDGaps); // 0x10a39d08 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetAllTriangleIndices(UDynamicMesh*& TargetMesh, FGeometryScriptTriangleList& TriangleList, bool& bSkipGaps, bool& bHasTriangleIDGaps); // 0x10a39f98 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetAllUVSeamEdges(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, bool& bHaveValidUVs, FGeometryScriptIndexList& ElementIDs); // 0x10a3a804 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetAllVertexIDs(UDynamicMesh*& TargetMesh, FGeometryScriptIndexList& VertexIDList, bool& bHasVertexIDGaps); // 0x10a3abc8 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetAllVertexPositions(UDynamicMesh*& TargetMesh, FGeometryScriptVectorList& PositionList, bool& bSkipGaps, bool& bHasVertexIDGaps); // 0x10a3ae58 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetAllVertexPositionsAtEdges(UDynamicMesh*& TargetMesh, const FGeometryScriptIndexList EdgeIDs, FGeometryScriptVectorList& Start, FGeometryScriptVectorList& End); // 0x10a3b168 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool GetHasMaterialIDs(UDynamicMesh*& TargetMesh); // 0x10a3c268 (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool GetHasPolygroups(UDynamicMesh*& TargetMesh); // 0x10a3c3c8 (Index: 0x9, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool GetHasTriangleIDGaps(UDynamicMesh*& TargetMesh); // 0x10a3c528 (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool GetHasTriangleNormals(UDynamicMesh*& TargetMesh); // 0x10a3c688 (Index: 0xb, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool GetHasVertexColors(UDynamicMesh*& TargetMesh); // 0x10a3c7e8 (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool GetHasVertexIDGaps(UDynamicMesh*& TargetMesh); // 0x10a3c948 (Index: 0xd, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UDynamicMesh* GetInterpolatedTriangleNormal(UDynamicMesh*& TargetMesh, int32_t& TriangleID, FVector& BarycentricCoords, bool& bTriHasValidNormals, FVector& InterpolatedNormal); // 0x10a3caa8 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* GetInterpolatedTriangleNormalTangents(UDynamicMesh*& TargetMesh, int32_t& TriangleID, FVector& BarycentricCoords, bool& bTriHasValidElements, FVector& InterpolatedNormal, FVector& InterpolatedTangent, FVector& InterpolatedBiTangent); // 0x10a3ce2c (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* GetInterpolatedTrianglePosition(UDynamicMesh*& TargetMesh, int32_t& TriangleID, FVector& BarycentricCoords, bool& bIsValidTriangle, FVector& InterpolatedPosition); // 0x10a3d310 (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* GetInterpolatedTriangleUV(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, int32_t& TriangleID, FVector& BarycentricCoords, bool& bTriHasValidUVs, FVector2D& InterpolatedUV); // 0x10a3d6f4 (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* GetInterpolatedTriangleVertexColor(UDynamicMesh*& TargetMesh, int32_t& TriangleID, FVector& BarycentricCoords, FLinearColor& DefaultColor, bool& bTriHasValidVertexColors, FLinearColor& InterpolatedColor); // 0x10a3dbc4 (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static bool GetIsClosedMesh(UDynamicMesh*& TargetMesh); // 0x10a3e014 (Index: 0x13, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool GetIsDenseMesh(UDynamicMesh*& TargetMesh); // 0x10a3e170 (Index: 0x14, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FBox GetMeshBoundingBox(UDynamicMesh*& TargetMesh); // 0x10a3ee20 (Index: 0x15, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool GetMeshHasAttributeSet(UDynamicMesh*& TargetMesh); // 0x10a3efbc (Index: 0x16, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FString GetMeshInfoString(UDynamicMesh*& TargetMesh); // 0x10a3f36c (Index: 0x17, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static double GetMeshUVArea(UDynamicMesh*& TargetMesh, int32_t& UVChannel, bool& bIsValidUVChannel); // 0x10a3fe18 (Index: 0x18, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetMeshVolumeArea(UDynamicMesh*& TargetMesh, float& SurfaceArea, float& Volume); // 0x10a40100 (Index: 0x19, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void GetMeshVolumeAreaCenter(UDynamicMesh*& TargetMesh, float& SurfaceArea, float& Volume, FVector& CenterOfMass); // 0x10a4033c (Index: 0x1a, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static int32_t GetNumConnectedComponents(UDynamicMesh*& TargetMesh); // 0x10a40610 (Index: 0x1b, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetNumExtendedPolygroupLayers(UDynamicMesh*& TargetMesh); // 0x10a4076c (Index: 0x1c, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetNumOpenBorderEdges(UDynamicMesh*& TargetMesh); // 0x10a408c8 (Index: 0x1d, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetNumOpenBorderLoops(UDynamicMesh*& TargetMesh, bool& bAmbiguousTopologyFound); // 0x10a40a24 (Index: 0x1e, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static int32_t GetNumTriangleIDs(UDynamicMesh*& TargetMesh); // 0x10a40c20 (Index: 0x1f, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetNumUVIslands(UDynamicMesh*& TargetMesh, int32_t& UVChannel, bool& bIsValidUVChannel); // 0x10a40d7c (Index: 0x20, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static int32_t GetNumUVSets(UDynamicMesh*& TargetMesh); // 0x10a4105c (Index: 0x21, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetNumVertexIDs(UDynamicMesh*& TargetMesh); // 0x10a411b8 (Index: 0x22, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FVector GetTriangleFaceNormal(UDynamicMesh*& TargetMesh, int32_t& TriangleID, bool& bIsValidTriangle); // 0x10a42f94 (Index: 0x23, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FIntVector GetTriangleIndices(UDynamicMesh*& TargetMesh, int32_t& TriangleID, bool& bIsValidTriangle); // 0x10a43288 (Index: 0x24, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static UDynamicMesh* GetTriangleNormals(UDynamicMesh*& TargetMesh, int32_t& TriangleID, FVector& Normal1, FVector& Normal2, FVector& Normal3, bool& bTriHasValidNormals); // 0x10a43d08 (Index: 0x25, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* GetTriangleNormalTangents(UDynamicMesh*& TargetMesh, int32_t& TriangleID, bool& bTriHasValidElements, FGeometryScriptTriangle& Normals, FGeometryScriptTriangle& Tangents, FGeometryScriptTriangle& BiTangents); // 0x10a4383c (Index: 0x26, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetTrianglePositions(UDynamicMesh*& TargetMesh, int32_t& TriangleID, bool& bIsValidTriangle, FVector& Vertex1, FVector& Vertex2, FVector& Vertex3); // 0x10a44490 (Index: 0x27, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static void GetTriangleUVs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, int32_t& TriangleID, FVector2D& UV1, FVector2D& UV2, FVector2D& UV3, bool& bHaveValidUVs); // 0x10a44934 (Index: 0x28, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static UDynamicMesh* GetTriangleVertexColors(UDynamicMesh*& TargetMesh, int32_t& TriangleID, FLinearColor& Color1, FLinearColor& Color2, FLinearColor& Color3, bool& bTriHasValidVertexColors); // 0x10a44e58 (Index: 0x29, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FBox2D GetUVSetBoundingBox(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, bool& bIsValidUVSet, bool& bUVSetIsEmpty); // 0x10a45964 (Index: 0x2a, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static UDynamicMesh* GetVertexConnectedTriangles(UDynamicMesh*& TargetMesh, int32_t& VertexID, TArray<int32_t>& Triangles); // 0x10a4623c (Index: 0x2b, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetVertexConnectedVertices(UDynamicMesh*& TargetMesh, int32_t& VertexID, TArray<int32_t>& Vertices); // 0x10a46690 (Index: 0x2c, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static int32_t GetVertexCount(UDynamicMesh*& TargetMesh); // 0x10a46ae4 (Index: 0x2d, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FVector GetVertexPosition(UDynamicMesh*& TargetMesh, int32_t& VertexID, bool& bIsValidVertex); // 0x10a46c40 (Index: 0x2e, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool IsValidTriangleID(UDynamicMesh*& TargetMesh, int32_t& TriangleID); // 0x10a4792c (Index: 0x2f, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsValidVertexID(UDynamicMesh*& TargetMesh, int32_t& VertexID); // 0x10a47b70 (Index: 0x30, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshQueryFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshQueryFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_RemeshingFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* ApplyUniformRemesh(UDynamicMesh*& TargetMesh, FGeometryScriptRemeshOptions& RemeshOptions, FGeometryScriptUniformRemeshOptions& UniformOptions, UGeometryScriptDebug*& Debug); // 0x10a2f52c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_RemeshingFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_RemeshingFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshRepairFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* CompactMesh(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a30aac (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* FillAllMeshHoles(UDynamicMesh*& TargetMesh, FGeometryScriptFillHolesOptions& FillOptions, int32_t& NumFilledHoles, int32_t& NumFailedHoleFills, UGeometryScriptDebug*& Debug); // 0x10a3873c (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* RemoveHiddenTriangles(UDynamicMesh*& TargetMesh, FGeometryScriptRemoveHiddenTrianglesOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a4ace8 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* RemoveSmallComponents(UDynamicMesh*& TargetMesh, FGeometryScriptRemoveSmallComponentOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a4af1c (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* RemoveUnusedVertices(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a4b144 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* RepairMeshDegenerateGeometry(UDynamicMesh*& TargetMesh, FGeometryScriptDegenerateTriangleOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a4b34c (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ResolveMeshTJunctions(UDynamicMesh*& TargetMesh, FGeometryScriptResolveTJunctionOptions& ResolveOptions, UGeometryScriptDebug*& Debug); // 0x10a4b574 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SnapMeshOpenBoundaries(UDynamicMesh*& TargetMesh, FGeometryScriptSnapBoundariesOptions& SnapOptions, UGeometryScriptDebug*& Debug); // 0x10a4f0a0 (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SplitMeshBowties(UDynamicMesh*& TargetMesh, bool& bMeshBowties, bool& bAttributeBowties, UGeometryScriptDebug*& Debug); // 0x10a4f2c8 (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* WeldMeshEdges(UDynamicMesh*& TargetMesh, FGeometryScriptWeldEdgesOptions& WeldOptions, UGeometryScriptDebug*& Debug); // 0x10a5133c (Index: 0x9, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshRepairFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshRepairFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshSamplingFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* ComputeNonUniformPointSampling(UDynamicMesh*& TargetMesh, FGeometryScriptMeshPointSamplingOptions& Options, FGeometryScriptNonUniformPointSamplingOptions& NonUniformOptions, TArray<FTransform>& Samples, TArray<double>& SampleRadii, FGeometryScriptIndexList& TriangleIDs, UGeometryScriptDebug*& Debug); // 0x10a30cb4 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ComputePointSampling(UDynamicMesh*& TargetMesh, FGeometryScriptMeshPointSamplingOptions& Options, TArray<FTransform>& Samples, FGeometryScriptIndexList& TriangleIDs, UGeometryScriptDebug*& Debug); // 0x10a3135c (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ComputeRenderCaptureCamerasForBox(TArray<FGeometryScriptRenderCaptureCamera>& Cameras, FBox& Box, const FGeometryScriptRenderCaptureCamerasForBoxOptions Options, UGeometryScriptDebug*& Debug); // 0x10a31f70 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void ComputeRenderCapturePointSampling(TArray<FTransform>& Samples, const TArray<AActor*> Actors, const TArray<FGeometryScriptRenderCaptureCamera> Cameras, UGeometryScriptDebug*& Debug); // 0x10a323f0 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ComputeUniformRandomPointSampling(UDynamicMesh*& const TargetMesh, int32_t& NumSamples, TArray<FTransform>& Samples, FGeometryScriptIndexList& TriangleIDs, int32_t& RandomSeed, UGeometryScriptDebug*& Debug); // 0x10a335ac (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ComputeVertexWeightedPointSampling(UDynamicMesh*& TargetMesh, FGeometryScriptMeshPointSamplingOptions& Options, FGeometryScriptNonUniformPointSamplingOptions& NonUniformOptions, FGeometryScriptScalarList& VertexWeights, TArray<FTransform>& Samples, TArray<double>& SampleRadii, FGeometryScriptIndexList& TriangleIDs, UGeometryScriptDebug*& Debug); // 0x10a33af8 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshSamplingFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshSamplingFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshSculptLayersFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* DiscardSculptLayers(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a7d8c0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* EnableSculptLayers(UDynamicMesh*& TargetMesh, int32_t& NumLayers, UGeometryScriptDebug*& Debug); // 0x10a7e004 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static int32_t GetActiveSculptLayer(UDynamicMesh*& const TargetMesh); // 0x10a7fdb8 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetNumSculptLayers(UDynamicMesh*& const TargetMesh); // 0x10a8324c (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TArray<double> GetSculptLayerWeightsArray(UDynamicMesh*& TargetMesh); // 0x10a87a6c (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* MergeSculptLayers(UDynamicMesh*& TargetMesh, int32_t& OutActiveLayer, int32_t& MergeLayerStart, int32_t& MergeLayerNum, bool& bUseWeights, UGeometryScriptDebug*& Debug); // 0x10a8b7d0 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SetActiveSculptLayer(UDynamicMesh*& TargetMesh, int32_t& LayerIndex, UGeometryScriptDebug*& Debug); // 0x10a94488 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetSculptLayerWeight(UDynamicMesh*& TargetMesh, int32_t& LayerIndex, double& Weight, FGeometryScriptSculptLayerUpdateOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a97280 (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetSculptLayerWeightsArray(UDynamicMesh*& TargetMesh, TArray<double>& Weights, FGeometryScriptSculptLayerUpdateOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a97648 (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshSculptLayersFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshSculptLayersFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshSelectionFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static void CombineMeshSelections(FGeometryScriptMeshSelection& SelectionA, FGeometryScriptMeshSelection& SelectionB, FGeometryScriptMeshSelection& ResultSelection, EGeometryScriptCombineSelectionMode& CombineMode); // 0x10a74888 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ConvertIndexArrayToMeshSelection(UDynamicMesh*& TargetMesh, const TArray<int32_t> IndexArray, EGeometryScriptMeshSelectionType& SelectionType, FGeometryScriptMeshSelection& Selection); // 0x10a77570 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ConvertIndexListToMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptIndexList& IndexList, EGeometryScriptMeshSelectionType& SelectionType, FGeometryScriptMeshSelection& Selection); // 0x10a779d0 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ConvertIndexSetToMeshSelection(UDynamicMesh*& TargetMesh, const TSet<int32_t> IndexSet, EGeometryScriptMeshSelectionType& SelectionType, FGeometryScriptMeshSelection& Selection); // 0x10a77c64 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ConvertMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& FromSelection, FGeometryScriptMeshSelection& ToSelection, EGeometryScriptMeshSelectionType& NewType, bool& bAllowPartialInclusion); // 0x10a77fd4 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ConvertMeshSelectionToIndexArray(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, TArray<int32_t>& IndexArray, EGeometryScriptMeshSelectionType& SelectionType); // 0x10a782c4 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ConvertMeshSelectionToIndexList(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FGeometryScriptIndexList& IndexList, EGeometryScriptIndexType& ResultListType, EGeometryScriptIndexType& ConvertToType); // 0x10a785ac (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* CreateSelectAllMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, EGeometryScriptMeshSelectionType& SelectionType); // 0x10a7cac0 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void DebugPrintMeshSelection(FGeometryScriptMeshSelection& Selection, bool& bDisable); // 0x10a7cce8 (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ExpandContractMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FGeometryScriptMeshSelection& NewSelection, int32_t& Iterations, bool& bContract, bool& bOnlyExpandToFaceNeighbours); // 0x10a7e2d8 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* ExpandMeshSelectionToConnected(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FGeometryScriptMeshSelection& NewSelection, EGeometryScriptTopologyConnectionType& ConnectionType); // 0x10a7e644 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetMeshSelectionInfo(FGeometryScriptMeshSelection& Selection, EGeometryScriptMeshSelectionType& SelectionType, int32_t& NumSelected); // 0x10a81c94 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetMeshUniqueSelectionInfo(UDynamicMesh*& const TargetMesh, FGeometryScriptMeshSelection& Selection, EGeometryScriptMeshSelectionType& SelectionType, int32_t& NumSelected); // 0x10a82d28 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* InvertMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FGeometryScriptMeshSelection& NewSelection, bool& bOnlyToConnected); // 0x10a893d4 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SelectMeshBoundaryEdges(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection); // 0x10a917d4 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SelectMeshElementsByMaterialID(UDynamicMesh*& TargetMesh, int32_t& MaterialID, FGeometryScriptMeshSelection& Selection, EGeometryScriptMeshSelectionType& SelectionType); // 0x10a91998 (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SelectMeshElementsByNormalAngle(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FVector& Normal, double& MaxAngleDeg, EGeometryScriptMeshSelectionType& SelectionType, bool& bInvert, int32_t& MinNumTrianglePoints); // 0x10a91ca0 (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* SelectMeshElementsByPolygroup(UDynamicMesh*& TargetMesh, FGeometryScriptGroupLayer& GroupLayer, int32_t& PolygroupID, FGeometryScriptMeshSelection& Selection, EGeometryScriptMeshSelectionType& SelectionType); // 0x10a92064 (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SelectMeshElementsInBox(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FBox& Box, EGeometryScriptMeshSelectionType& SelectionType, bool& bInvert, int32_t& MinNumTrianglePoints); // 0x10a92324 (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* SelectMeshElementsInsideMesh(UDynamicMesh*& TargetMesh, UDynamicMesh*& SelectionMesh, FGeometryScriptMeshSelection& Selection, FTransform& SelectionMeshTransform, EGeometryScriptMeshSelectionType& SelectionType, bool& bInvert, double& ShellDistance, double& WindingThreshold, int32_t& MinNumTrianglePoints); // 0x10a92ee8 (Index: 0x13, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* SelectMeshElementsInSphere(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FVector& SphereOrigin, double& SphereRadius, EGeometryScriptMeshSelectionType& SelectionType, bool& bInvert, int32_t& MinNumTrianglePoints); // 0x10a92b24 (Index: 0x14, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* SelectMeshElementsWithPlane(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FVector& PlaneOrigin, FVector& PlaneNormal, EGeometryScriptMeshSelectionType& SelectionType, bool& bInvert, int32_t& MinNumTrianglePoints); // 0x10a93454 (Index: 0x15, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* SelectMeshPolyGroupBoundaryEdges(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FGeometryScriptGroupLayer& GroupLayer, bool& bExcludeMeshBoundaryEdges); // 0x10a93820 (Index: 0x16, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SelectMeshSharpEdges(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, double& MinAngleDeg); // 0x10a93ab8 (Index: 0x17, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SelectMeshSplitNormalEdges(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection); // 0x10a93ce4 (Index: 0x18, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SelectMeshUVSeamEdges(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, int32_t& UVChannel, bool& bHaveValidUVs, bool& bExcludeMeshBoundaryEdges); // 0x10a93ea8 (Index: 0x19, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SelectSelectionBoundaryEdges(UDynamicMesh*& TargetMesh, const FGeometryScriptMeshSelection Selection, FGeometryScriptMeshSelection& BoundarySelection, bool& bExcludeMeshBoundaryEdges); // 0x10a941c8 (Index: 0x1a, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshSelectionFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshSelectionFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshSelectionQueryFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* GetMeshSelectionBoundaryLoops(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, TArray<FGeometryScriptIndexList>& IndexLoops, TArray<FGeometryScriptPolyPath>& PathLoops, int32_t& NumLoops, bool& bFoundErrors, UGeometryScriptDebug*& Debug); // 0x10a81568 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetMeshSelectionBoundingBox(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FBox& SelectionBounds, bool& bIsEmpty, UGeometryScriptDebug*& Debug); // 0x10a81998 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshSelectionQueryFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshSelectionQueryFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshSimplifyFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* ApplyEditorSimplifyToTriangleCount(UDynamicMesh*& TargetMesh, int32_t& TriangleCount, UGeometryScriptDebug*& Debug); // 0x10a712f8 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyEditorSimplifyToVertexCount(UDynamicMesh*& TargetMesh, int32_t& VertexCount, UGeometryScriptDebug*& Debug); // 0x10a715cc (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplySimplifyToPlanar(UDynamicMesh*& TargetMesh, FGeometryScriptPlanarSimplifyOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a722d0 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplySimplifyToPolygroupTopology(UDynamicMesh*& TargetMesh, FGeometryScriptPolygroupSimplifyOptions& Options, FGeometryScriptGroupLayer& GroupLayer, UGeometryScriptDebug*& Debug); // 0x10a724dc (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplySimplifyToTolerance(UDynamicMesh*& TargetMesh, float& Tolerance, FGeometryScriptSimplifyMeshOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a72750 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplySimplifyToTriangleCount(UDynamicMesh*& TargetMesh, int32_t& TriangleCount, FGeometryScriptSimplifyMeshOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a72a50 (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplySimplifyToVertexCount(UDynamicMesh*& TargetMesh, int32_t& VertexCount, FGeometryScriptSimplifyMeshOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a72d50 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshSimplifyFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshSimplifyFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshSpatial : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* BuildBVHForMesh(UDynamicMesh*& TargetMesh, FGeometryScriptDynamicMeshBVH& OutputBVH, UGeometryScriptDebug*& Debug); // 0x10a7437c (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* FindNearestPointOnMesh(UDynamicMesh*& TargetMesh, const FGeometryScriptDynamicMeshBVH QueryBVH, FVector& QueryPoint, FGeometryScriptSpatialQueryOptions& Options, FGeometryScriptTrianglePoint& NearestResult, EGeometryScriptSearchOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x10a7ed54 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* FindNearestRayIntersectionWithMesh(UDynamicMesh*& TargetMesh, const FGeometryScriptDynamicMeshBVH QueryBVH, FVector& RayOrigin, FVector& RayDirection, FGeometryScriptSpatialQueryOptions& Options, FGeometryScriptRayHitResult& HitResult, EGeometryScriptSearchOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x10a7f18c (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* IsBVHValidForMesh(UDynamicMesh*& TargetMesh, const FGeometryScriptDynamicMeshBVH TestBVH, bool& bIsValid, UGeometryScriptDebug*& Debug); // 0x10a89648 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* IsPointInsideMesh(UDynamicMesh*& TargetMesh, const FGeometryScriptDynamicMeshBVH QueryBVH, FVector& QueryPoint, FGeometryScriptSpatialQueryOptions& Options, bool& bIsInside, EGeometryScriptContainmentOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x10a89904 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* RebuildBVHForMesh(UDynamicMesh*& TargetMesh, FGeometryScriptDynamicMeshBVH UpdateBVH, bool& bOnlyIfInvalid, UGeometryScriptDebug*& Debug); // 0x10a8d9e0 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ResetBVH(FGeometryScriptDynamicMeshBVH ResetBVH); // 0x10a8e2c0 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SelectMeshElementsInBoxWithBVH(UDynamicMesh*& TargetMesh, const FGeometryScriptDynamicMeshBVH QueryBVH, FBox& QueryBox, FGeometryScriptSpatialQueryOptions& Options, FGeometryScriptMeshSelection& Selection, EGeometryScriptMeshSelectionType& SelectionType, int32_t& MinNumTrianglePoints, UGeometryScriptDebug*& Debug); // 0x10a92688 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshSpatial) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshSpatial");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshSubdivideFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* ApplyPNTessellation(UDynamicMesh*& TargetMesh, FGeometryScriptPNTessellateOptions& Options, int32_t& TessellationLevel, UGeometryScriptDebug*& Debug); // 0x10a71d44 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplySelectiveTessellation(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FGeometryScriptSelectiveTessellateOptions& Options, int32_t& TessellationLevel, ESelectiveTessellatePatternType& PatternType, UGeometryScriptDebug*& Debug); // 0x10a71fac (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyUniformTessellation(UDynamicMesh*& TargetMesh, int32_t& TessellationLevel, UGeometryScriptDebug*& Debug); // 0x10a733e0 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshSubdivideFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshSubdivideFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshTransformFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* InverseTransformMesh(UDynamicMesh*& TargetMesh, FTransform& Transform, bool& bFixOrientationForNegativeScale, UGeometryScriptDebug*& Debug); // 0x10a88d70 (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* InverseTransformMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FTransform& Transform, UGeometryScriptDebug*& Debug); // 0x10a89090 (Index: 0x1, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* RotateMesh(UDynamicMesh*& TargetMesh, FRotator& Rotation, FVector& RotationOrigin, UGeometryScriptDebug*& Debug); // 0x10a8e398 (Index: 0x2, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* RotateMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FRotator& Rotation, FVector& RotationOrigin, UGeometryScriptDebug*& Debug); // 0x10a8e62c (Index: 0x3, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* ScaleMesh(UDynamicMesh*& TargetMesh, FVector& Scale, FVector& ScaleOrigin, bool& bFixOrientationForNegativeScale, UGeometryScriptDebug*& Debug); // 0x10a90e24 (Index: 0x4, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* ScaleMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FVector& Scale, FVector& ScaleOrigin, UGeometryScriptDebug*& Debug); // 0x10a9112c (Index: 0x5, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* TransformMesh(UDynamicMesh*& TargetMesh, FTransform& Transform, bool& bFixOrientationForNegativeScale, UGeometryScriptDebug*& Debug); // 0x10a990b8 (Index: 0x6, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* TransformMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FTransform& Transform, UGeometryScriptDebug*& Debug); // 0x10a993d8 (Index: 0x7, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* TranslateMesh(UDynamicMesh*& TargetMesh, FVector& Translation, UGeometryScriptDebug*& Debug); // 0x10a99ad4 (Index: 0x8, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* TranslateMeshSelection(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FVector& Translation, UGeometryScriptDebug*& Debug); // 0x10a99cec (Index: 0x9, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* TranslatePivotToLocation(UDynamicMesh*& TargetMesh, FVector& PivotLocation, UGeometryScriptDebug*& Debug); // 0x10a9a2a0 (Index: 0xa, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshTransformFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshTransformFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshUVFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* AddUVElementToMesh(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FVector2D& NewUVPosition, int32_t& NewUVElementID, bool& bIsValidUVSet, bool& bDeferChangeNotifications); // 0x10a70c98 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* ApplyTexelDensityUVScaling(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FGeometryScriptUVTexelDensityOptions& Options, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a73050 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* AutoGeneratePatchBuilderMeshUVs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FGeometryScriptPatchBuilderOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a736b4 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* AutoGenerateXAtlasMeshUVs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FGeometryScriptXAtlasOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a739fc (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ClearUVChannel(UDynamicMesh*& TargetMesh, int32_t& UVChannel, UGeometryScriptDebug*& Debug); // 0x10a745b4 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ComputeMeshLocalUVParam(UDynamicMesh*& TargetMesh, FVector& CenterPoint, int32_t& CenterPointTriangleID, TArray<int32_t>& VertexIDs, TArray<FVector2D>& VertexUVs, double& Radius, bool& bUseInterpolatedNormal, FVector& TangentYDirection, double& UVRotationDeg, UGeometryScriptDebug*& Debug); // 0x10a74b0c (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* CopyMeshToMeshUVLayer(UDynamicMesh*& CopyFromUVMesh, int32_t& ToUVSetIndex, UDynamicMesh* CopyToMesh, UDynamicMesh*& CopyToMeshOut, bool& bFoundTopologyErrors, bool& bIsValidUVSet, bool& bOnlyUVPositions, UGeometryScriptDebug*& Debug); // 0x10a7a40c (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* CopyMeshUVLayerToMesh(UDynamicMesh*& CopyFromMesh, int32_t& UvSetIndex, UDynamicMesh* CopyToUVMesh, UDynamicMesh*& CopyToUVMeshOut, bool& bInvalidTopology, bool& bIsValidUVSet, UGeometryScriptDebug*& Debug); // 0x10a7aa14 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* CopyUVSet(UDynamicMesh*& TargetMesh, int32_t& FromUVSet, int32_t& ToUVSet, UGeometryScriptDebug*& Debug); // 0x10a7afac (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* GetMeshPerVertexUVs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FGeometryScriptUVList& UVList, bool& bIsValidUVSet, bool& bHasVertexIDGaps, bool& bHasSplitUVs, UGeometryScriptDebug*& Debug); // 0x10a8109c (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* GetMeshTriangleUVElementIDs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, int32_t& TriangleID, FIntVector& TriangleUVElements, bool& bHaveValidUVs); // 0x10a81e9c (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* GetMeshUVElementPosition(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, int32_t& ElementID, FVector2D& UVPosition, bool& bIsValidElementID); // 0x10a8229c (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* GetMeshUVSizeInfo(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FGeometryScriptMeshSelection& Selection, double& MeshArea, double& UVArea, FBox& MeshBounds, FBox2D& UVBounds, bool& bIsValidUVSet, bool& bFoundUnsetUVs, bool& bOnlyIncludeValidUVTris, UGeometryScriptDebug*& Debug); // 0x10a826d0 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static bool IntersectsUVBox2D(FBox2D& A, FBox2D& B, bool& bWrappedToUnitRange); // 0x10a88b88 (Index: 0xd, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static UDynamicMesh* LayoutMeshUVs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FGeometryScriptLayoutUVsOptions& LayoutOptions, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a8a5e0 (Index: 0xe, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* RecomputeMeshUVs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FGeometryScriptRecomputeUVsOptions& Options, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a8dc90 (Index: 0xf, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* RepackMeshUVs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FGeometryScriptRepackUVsOptions& RepackOptions, UGeometryScriptDebug*& Debug); // 0x10a8dfd8 (Index: 0x10, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* RotateMeshUVs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, float& RotationAngle, FVector2D& RotationOrigin, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a8e948 (Index: 0x11, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* ScaleMeshUVs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FVector2D& Scale, FVector2D& ScaleOrigin, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a91448 (Index: 0x12, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* SetMeshTriangleUVElementIDs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, int32_t& TriangleID, FIntVector& TriangleUVElements, bool& bIsValidTriangle, bool& bDeferChangeNotifications); // 0x10a9539c (Index: 0x13, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* SetMeshTriangleUVs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, int32_t& TriangleID, FGeometryScriptUVTriangle& UVs, bool& bIsValidTriangle, bool& bDeferChangeNotifications); // 0x10a9583c (Index: 0x14, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SetMeshUVElementPosition(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, int32_t& ElementID, FVector2D& NewUVPosition, bool& bIsValidElementID, bool& bDeferChangeNotifications); // 0x10a95cd0 (Index: 0x15, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* SetMeshUVsFromBoxProjection(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FTransform& BoxTransform, FGeometryScriptMeshSelection& Selection, int32_t& MinIslandTriCount, UGeometryScriptDebug*& Debug); // 0x10a96168 (Index: 0x16, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* SetMeshUVsFromCylinderProjection(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FTransform& CylinderTransform, FGeometryScriptMeshSelection& Selection, float& SplitAngle, UGeometryScriptDebug*& Debug); // 0x10a96550 (Index: 0x17, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* SetMeshUVsFromPlanarProjection(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FTransform& PlaneTransform, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a9693c (Index: 0x18, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* SetNumUVSets(UDynamicMesh*& TargetMesh, int32_t& NumUVSets, UGeometryScriptDebug*& Debug); // 0x10a96d04 (Index: 0x19, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetUVSeamsAlongSelectedEdges(UDynamicMesh*& TargetMesh, int32_t& UVChannel, FGeometryScriptMeshSelection& Selection, bool& bInsertSeams, bool& bDeferChangeNotifications, UGeometryScriptDebug*& Debug); // 0x10a97b08 (Index: 0x1a, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* TransferMeshUVsByProjection(UDynamicMesh*& TargetMesh, int32_t& TargetUVChannel, FGeometryScriptMeshSelection& TargetSelection, FTransform& TargetTransform, UDynamicMesh*& const SourceMesh, FGeometryScriptDynamicMeshBVH& SourceMeshOptionalBVH, int32_t& SourceUVChannel, FGeometryScriptMeshSelection& SourceSelection, FTransform& SourceTransform, FGeometryScriptMeshProjectionSettings& Settings, FVector& ProjectionDirection, double& ProjectionOffset, UGeometryScriptDebug*& Debug); // 0x10a9844c (Index: 0x1b, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* TranslateMeshUVs(UDynamicMesh*& TargetMesh, int32_t& UvSetIndex, FVector2D& Translation, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a99f90 (Index: 0x1c, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshUVFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshUVFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshVertexColorFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* BlurMeshVertexColors(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, int32_t& NumIterations, double& Strength, EGeometryScriptBlurColorMode& BlurMode, FGeometryScriptBlurMeshVertexColorsOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a73fdc (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ConvertMeshVertexColorsLinearToSRGB(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a788dc (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ConvertMeshVertexColorsSRGBToLinear(UDynamicMesh*& TargetMesh, UGeometryScriptDebug*& Debug); // 0x10a78ae4 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* GetMeshPerVertexColors(UDynamicMesh*& TargetMesh, FGeometryScriptColorList& ColorList, bool& bIsValidColorSet, bool& bHasVertexIDGaps, bool& bBlendSplitVertexValues); // 0x10a80d04 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UDynamicMesh* SetMeshConstantVertexColor(UDynamicMesh*& TargetMesh, FLinearColor& Color, FGeometryScriptColorFlags& Flags, bool& bClearExisting, UGeometryScriptDebug*& Debug); // 0x10a94b24 (Index: 0x4, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* SetMeshPerVertexColors(UDynamicMesh*& TargetMesh, FGeometryScriptColorList& VertexColorList, UGeometryScriptDebug*& Debug); // 0x10a94e10 (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* SetMeshSelectionVertexColor(UDynamicMesh*& TargetMesh, FGeometryScriptMeshSelection& Selection, FLinearColor& Color, FGeometryScriptColorFlags& Flags, bool& bCreateColorSeam, UGeometryScriptDebug*& Debug); // 0x10a9506c (Index: 0x6, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static UDynamicMesh* TransferVertexColorsFromMesh(UDynamicMesh*& SourceMesh, UDynamicMesh*& TargetMesh, FGeometryScriptTransferMeshVertexColorsOptions& Options, FGeometryScriptMeshSelection& Selection, UGeometryScriptDebug*& Debug); // 0x10a98d68 (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshVertexColorFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshVertexColorFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_MeshVoxelFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* ApplyMeshMorphology(UDynamicMesh*& TargetMesh, FGeometryScriptMorphologyOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a718a0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UDynamicMesh* ApplyMeshSolidify(UDynamicMesh*& TargetMesh, FGeometryScriptSolidifyOptions& Options, UGeometryScriptDebug*& Debug); // 0x10a71aec (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_MeshVoxelFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_MeshVoxelFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_PointSetSamplingFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static void DownsamplePoints(const TArray<FVector> Points, const FGeometryScriptPointPriorityOptions Options, FGeometryScriptIndexList& DownsampledIndices, int32_t& KeepNumPoints, UGeometryScriptDebug*& Debug); // 0x10a7dac8 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void FlattenPoints(const TArray<FVector> PointsIn3D, TArray<FVector2D>& PointsIn2D, const FGeometryScriptPointFlatteningOptions Options); // 0x10a7f668 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetPointsFromIndexList(const TArray<FVector> AllPoints, const FGeometryScriptIndexList Indices, TArray<FVector>& SelectedPoints); // 0x10a83374 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void KMeansClusterToArrays(const TArray<FVector> Points, const FGeometryScriptPointClusteringOptions Options, TArray<FGeometryScriptIndexList>& ClusterIDToLists); // 0x10a89d10 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void KMeansClusterToIDs(const TArray<FVector> Points, const FGeometryScriptPointClusteringOptions Options, TArray<int32_t>& PointClusterIndices); // 0x10a8a134 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FBox MakeBoundingBoxFromPoints(const TArray<FVector> Points, double& ExpandBy); // 0x10a8a944 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void OffsetTransforms(TArray<FTransform> Transforms, double& Offset, FVector& Direction, EGeometryScriptCoordinateSpace& Space); // 0x10a8bb60 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void TransformsToPoints(const TArray<FTransform> Transforms, TArray<FVector>& Points); // 0x10a9971c (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void UnflattenPoints(const TArray<FVector2D> PointsIn2D, TArray<FVector>& PointsIn3D, const FGeometryScriptPointFlatteningOptions Options, double& Height); // 0x10a9a4c4 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_PointSetSamplingFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_PointSetSamplingFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_SimplePolygonFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static int32_t AddPolygonVertex(FGeometryScriptSimplePolygon Polygon, FVector2D& Position); // 0x10a70ac0 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FGeometryScriptSimplePolygon Conv_ArrayOfVector2DToGeometryScriptSimplePolygon(const TArray<FVector2D> PathVertices); // 0x10a75dd4 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGeometryScriptSimplePolygon Conv_ArrayToGeometryScriptSimplePolygon(const TArray<FVector> PathVertices); // 0x10a763c4 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static TArray<FVector> Conv_GeometryScriptSimplePolygonToArray(FGeometryScriptSimplePolygon& Polygon); // 0x10a76a48 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TArray<FVector2D> Conv_GeometryScriptSimplePolygonToArrayOfVector2D(FGeometryScriptSimplePolygon& Polygon); // 0x10a76cb4 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void ConvertSplineToPolygon(USplineComponent*& const Spline, FGeometryScriptSimplePolygon& Polygon, FGeometryScriptSplineSamplingOptions& SamplingOptions, EGeometryScriptAxis& DropAxis); // 0x10a794d8 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static double GetPolygonArcLength(FGeometryScriptSimplePolygon& Polygon); // 0x10a84148 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
    static double GetPolygonArea(FGeometryScriptSimplePolygon& Polygon); // 0x10a844f4 (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FBox2D GetPolygonBounds(FGeometryScriptSimplePolygon& Polygon); // 0x10a84944 (Index: 0x8, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FVector2D GetPolygonTangent(FGeometryScriptSimplePolygon& Polygon, int32_t& VertexIndex, bool& bPolygonIsEmpty); // 0x10a85104 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FVector2D GetPolygonVertex(FGeometryScriptSimplePolygon& Polygon, int32_t& VertexIndex, bool& bPolygonIsEmpty); // 0x10a856b8 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static int32_t GetPolygonVertexCount(FGeometryScriptSimplePolygon& Polygon); // 0x10a85c44 (Index: 0xb, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SetPolygonVertex(FGeometryScriptSimplePolygon Polygon, int32_t& VertexIndex, FVector2D& Position, bool& bPolygonIsEmpty); // 0x10a96fd8 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_SimplePolygonFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_SimplePolygonFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_PolygonListFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static int32_t AddPolygonToList(FGeometryScriptGeneralPolygonList PolygonList, FGeometryScriptSimplePolygon& OuterPolygon, const TArray<FGeometryScriptSimplePolygon> HolePolygons, bool& bFixHoleOrientations); // 0x10a707c8 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void AppendPolygonList(FGeometryScriptGeneralPolygonList PolygonList, FGeometryScriptGeneralPolygonList& PolygonsToAppend); // 0x10a710d8 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptGeneralPolygonList CreatePolygonListFromSimplePolygons(const TArray<FGeometryScriptSimplePolygon> OuterPolygons); // 0x10a7bdd8 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptGeneralPolygonList CreatePolygonListFromSinglePolygon(FGeometryScriptSimplePolygon& OuterPolygon, const TArray<FGeometryScriptSimplePolygon> HolePolygons, bool& bFixHoleOrientations); // 0x10a7bed8 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptGeneralPolygonList CreatePolygonsFromOpenPolyPathsOffset(TArray<FGeometryScriptPolyPath>& PolyPaths, FGeometryScriptOpenPathOffsetOptions& OffsetOptions, double& Offset, bool& bOperationSuccess, bool& bCopyInputOnFailure); // 0x10a7c1bc (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptGeneralPolygonList CreatePolygonsFromPathOffset(TArray<FVector2D>& Path, FGeometryScriptOpenPathOffsetOptions& OffsetOptions, double& Offset, bool& bOperationSuccess, bool& bCopyInputOnFailure); // 0x10a7c57c (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static double GetPolygonArea(FGeometryScriptGeneralPolygonList& PolygonList, bool& bValidIndex, int32_t& PolygonIndex); // 0x10a842e4 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FBox2D GetPolygonBounds(FGeometryScriptGeneralPolygonList& PolygonList, bool& bValidIndex, int32_t& PolygonIndex); // 0x10a84690 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static int32_t GetPolygonCount(FGeometryScriptGeneralPolygonList& PolygonList); // 0x109e634c (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable)
    static int32_t GetPolygonHoleCount(FGeometryScriptGeneralPolygonList& PolygonList, bool& bValidIndex, int32_t& PolygonIndex); // 0x10a84ac4 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static double GetPolygonListArea(FGeometryScriptGeneralPolygonList& PolygonList); // 0x10a84d50 (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FBox2D GetPolygonListBounds(FGeometryScriptGeneralPolygonList& PolygonList); // 0x10a84ec4 (Index: 0xb, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FVector2D GetPolygonVertex(FGeometryScriptGeneralPolygonList& PolygonList, bool& bIsValidVertex, int32_t& VertexIndex, int32_t& PolygonIndex, int32_t& HoleIndex); // 0x10a853b8 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static int32_t GetPolygonVertexCount(FGeometryScriptGeneralPolygonList& PolygonList, bool& bValidIndices, int32_t& PolygonIndex, int32_t& HoleIndex); // 0x10a85920 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetPolygonVertices(FGeometryScriptGeneralPolygonList& PolygonList, TArray<FVector2D>& OutVertices, bool& bValidIndices, int32_t& PolygonIndex, int32_t& HoleIndex); // 0x10a85dc8 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptSimplePolygon GetSimplePolygon(FGeometryScriptGeneralPolygonList& PolygonList, bool& bValidIndices, int32_t& PolygonIndex, int32_t& HoleIndex); // 0x10a87d68 (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptGeneralPolygonList PolygonsDifference(FGeometryScriptGeneralPolygonList& PolygonList, FGeometryScriptGeneralPolygonList& PolygonsToSubtract); // 0x10a8bf48 (Index: 0x10, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGeometryScriptGeneralPolygonList PolygonsExclusiveOr(FGeometryScriptGeneralPolygonList& PolygonList, FGeometryScriptGeneralPolygonList& PolygonsToExclusiveOr); // 0x10a8c2f8 (Index: 0x11, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGeometryScriptGeneralPolygonList PolygonsIntersection(FGeometryScriptGeneralPolygonList& PolygonList, FGeometryScriptGeneralPolygonList& PolygonsToIntersect); // 0x10a8c5e4 (Index: 0x12, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGeometryScriptGeneralPolygonList PolygonsMorphologyClose(FGeometryScriptGeneralPolygonList& PolygonList, FGeometryScriptPolygonOffsetOptions& OffsetOptions, double& Offset, bool& bOperationSuccess, bool& bCopyInputOnFailure); // 0x10a8c8d0 (Index: 0x13, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptGeneralPolygonList PolygonsMorphologyOpen(FGeometryScriptGeneralPolygonList& PolygonList, FGeometryScriptPolygonOffsetOptions& OffsetOptions, double& Offset, bool& bOperationSuccess, bool& bCopyInputOnFailure); // 0x10a8cc28 (Index: 0x14, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptGeneralPolygonList PolygonsOffset(FGeometryScriptGeneralPolygonList& PolygonList, FGeometryScriptPolygonOffsetOptions& OffsetOptions, double& Offset, bool& bOperationSuccess, bool& bCopyInputOnFailure); // 0x10a8cf80 (Index: 0x15, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptGeneralPolygonList PolygonsOffsets(FGeometryScriptGeneralPolygonList& PolygonList, FGeometryScriptPolygonOffsetOptions& OffsetOptions, double& FirstOffset, double& SecondOffset, bool& bOperationSuccess, bool& bCopyInputOnFailure); // 0x10a8d3b8 (Index: 0x16, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptGeneralPolygonList PolygonsUnion(FGeometryScriptGeneralPolygonList& PolygonList, bool& bCopyInputOnFailure); // 0x10a8d798 (Index: 0x17, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_PolygonListFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_PolygonListFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_PolyPathFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static FGeometryScriptPolyPath Conv_ArrayOfVector2DToGeometryScriptPolyPath(const TArray<FVector2D> PathVertices); // 0x10a75adc (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGeometryScriptPolyPath Conv_ArrayToGeometryScriptPolyPath(const TArray<FVector> PathVertices); // 0x10a760cc (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static TArray<FVector> Conv_GeometryScriptPolyPathToArray(FGeometryScriptPolyPath& PolyPath); // 0x10a76678 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TArray<FVector2D> Conv_GeometryScriptPolyPathToArrayOfVector2D(FGeometryScriptPolyPath& PolyPath); // 0x10a76860 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void ConvertArrayOfVector2DToPolyPath(const TArray<FVector2D> VertexArray, FGeometryScriptPolyPath& PolyPath); // 0x10a76ed0 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertArrayToPolyPath(const TArray<FVector> VertexArray, FGeometryScriptPolyPath& PolyPath); // 0x10a77220 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertPolyPathToArray(FGeometryScriptPolyPath& PolyPath, TArray<FVector>& VertexArray); // 0x10a78cec (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertPolyPathToArrayOfVector2D(FGeometryScriptPolyPath& PolyPath, TArray<FVector2D>& VertexArray); // 0x10a78f14 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertSplineToPolyPath(USplineComponent*& const Spline, FGeometryScriptPolyPath& PolyPath, FGeometryScriptSplineSamplingOptions& SamplingOptions); // 0x10a7913c (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptPolyPath CreateArcPath2D(FVector2D& Center, float& Radius, int32_t& NumPoints, float& StartAngle, float& EndAngle); // 0x10a7b35c (Index: 0x9, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FGeometryScriptPolyPath CreateArcPath3D(FTransform& Transform, float& Radius, int32_t& NumPoints, float& StartAngle, float& EndAngle); // 0x10a7b614 (Index: 0xa, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FGeometryScriptPolyPath CreateCirclePath2D(FVector2D& Center, float& Radius, int32_t& NumPoints); // 0x10a7b96c (Index: 0xb, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FGeometryScriptPolyPath CreateCirclePath3D(FTransform& Transform, float& Radius, int32_t& NumPoints); // 0x10a7bb3c (Index: 0xc, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FGeometryScriptPolyPath FlattenTo2DOnAxis(FGeometryScriptPolyPath& PolyPath, EGeometryScriptAxis& DropAxis); // 0x10a7fad0 (Index: 0xd, Flags: Final|Native|Static|Public|BlueprintCallable)
    static int32_t GetNearestVertexIndex(FGeometryScriptPolyPath& PolyPath, FVector& Point); // 0x10a82fd8 (Index: 0xe, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static double GetPolyPathArcLength(FGeometryScriptPolyPath& PolyPath); // 0x10a837c8 (Index: 0xf, Flags: Final|Native|Static|Public|BlueprintCallable)
    static int32_t GetPolyPathLastIndex(FGeometryScriptPolyPath& PolyPath); // 0x10a83978 (Index: 0x10, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetPolyPathNumVertices(FGeometryScriptPolyPath& PolyPath); // 0x10a83adc (Index: 0x11, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FVector GetPolyPathTangent(FGeometryScriptPolyPath& PolyPath, int32_t& Index, bool& bIsValidIndex); // 0x10a83c28 (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector GetPolyPathVertex(FGeometryScriptPolyPath& PolyPath, int32_t& Index, bool& bIsValidIndex); // 0x10a83ed0 (Index: 0x13, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool SampleSplineToTransforms(USplineComponent*& const Spline, TArray<FTransform>& Frames, TArray<double>& FrameTimes, FGeometryScriptSplineSamplingOptions& SamplingOptions, FTransform& RelativeTransform, bool& bIncludeScale); // 0x10a8ecdc (Index: 0x14, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_PolyPathFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_PolyPathFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_SceneUtilityFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static UDynamicMesh* CopyCollisionMeshesFromObject(UObject*& FromObject, UDynamicMesh*& ToDynamicMesh, bool& bTransformToWorld, FTransform& LocalToWorld, EGeometryScriptOutcomePins& Outcome, bool& bUseComplexCollision, int32_t& SphereResolution, UGeometryScriptDebug*& Debug); // 0x10a79a2c (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMesh* CopyMeshFromComponent(USceneComponent*& Component, UDynamicMesh*& ToDynamicMesh, FGeometryScriptCopyMeshFromComponentOptions& Options, bool& bTransformToWorld, FTransform& LocalToWorld, EGeometryScriptOutcomePins& Outcome, UGeometryScriptDebug*& Debug); // 0x10a79f50 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static UDynamicMeshPool* CreateDynamicMeshPool(); // 0x10a7bdac (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void DetermineMeshOcclusion(const TArray<UDynamicMesh*> SourceMeshes, const TArray<FTransform> SourceMeshTransforms, TArray<bool>& OutMeshIsHidden, const TArray<UDynamicMesh*> TransparentMeshes, const TArray<FTransform> TransparentMeshTransforms, TArray<bool>& OutTransparentMeshIsHidden, const TArray<UDynamicMesh*> OccludeMeshes, const TArray<FTransform> OccludeMeshTransforms, const FGeometryScriptDetermineMeshOcclusionOptions OcclusionOptions, UGeometryScriptDebug*& Debug); // 0x10a7ce50 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetComponentMaterialList(UPrimitiveComponent*& Component, const TArray<UMaterialInterface*> MaterialList, UGeometryScriptDebug*& Debug); // 0x10a9475c (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_SceneUtilityFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_SceneUtilityFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_TransformFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static FPlane GetTransformAxisPlane(FTransform& Transform, EGeometryScriptAxis& Axis); // 0x10a880b4 (Index: 0x0, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FRay GetTransformAxisRay(FTransform& Transform, EGeometryScriptAxis& Axis); // 0x10a882a8 (Index: 0x1, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector GetTransformAxisVector(FTransform& Transform, EGeometryScriptAxis& Axis); // 0x10a884a4 (Index: 0x2, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FTransform MakeTransformFromAxes(FVector& Location, FVector& ZAxis, FVector& TangentAxis, bool& bTangentIsX); // 0x10a8b34c (Index: 0x3, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FTransform MakeTransformFromZAxis(FVector& Location, FVector& ZAxis); // 0x10a8b600 (Index: 0x4, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UGeometryScriptLibrary_TransformFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_TransformFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_RayFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static bool GetRayBoxIntersection(FRay& Ray, FBox& Box, double& HitDistance); // 0x10a8617c (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector GetRayClosestPoint(FRay& Ray, FVector& Point); // 0x10a863b0 (Index: 0x1, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static double GetRayLineClosestPoint(FRay& Ray, FVector& LineOrigin, FVector& LineDirection, double& RayParameter, FVector& RayPoint, double& LineParameter, FVector& LinePoint); // 0x10a86568 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static double GetRayParameter(FRay& Ray, FVector& Point); // 0x10a869b8 (Index: 0x3, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool GetRayPlaneIntersection(FRay& Ray, FPlane& Plane, double& HitDistance); // 0x10a86b54 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector GetRayPoint(FRay& Ray, double& Distance); // 0x10a86d68 (Index: 0x5, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static double GetRayPointDistance(FRay& Ray, FVector& Point); // 0x10a86f08 (Index: 0x6, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static double GetRaySegmentClosestPoint(FRay& Ray, FVector& SegStartPoint, FVector& SegEndPoint, double& RayParameter, FVector& RayPoint, FVector& SegPoint); // 0x10a870b4 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool GetRaySphereIntersection(FRay& Ray, FVector& SphereCenter, double& SphereRadius, double& Distance1, double& Distance2); // 0x10a87460 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static void GetRayStartEnd(FRay& Ray, double& StartDistance, double& EndDistance, FVector& StartPoint, FVector& Endpoint); // 0x10a87774 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FRay GetTransformedRay(FRay& Ray, FTransform& Transform, bool& bInvert); // 0x10a888cc (Index: 0xa, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FRay MakeRayFromPointDirection(FVector& origin, FVector& Direction, bool& bDirectionIsNormalized); // 0x10a8afd0 (Index: 0xb, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FRay MakeRayFromPoints(FVector& A, FVector& B); // 0x10a8b1c0 (Index: 0xc, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UGeometryScriptLibrary_RayFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_RayFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_BoxFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static FBox FindBoxBoxIntersection(FBox& Box1, FBox& Box2, bool& bIsIntersecting); // 0x10a7e8b4 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector FindClosestPointOnBox(FBox& Box, FVector& Point, bool& bIsInside); // 0x10a7eb48 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static double GetBoxBoxDistance(FBox& Box1, FBox& Box2); // 0x10a7fee0 (Index: 0x2, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static void GetBoxCenterSize(FBox& Box, FVector& Center, FVector& Dimensions); // 0x10a80088 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector GetBoxCorner(FBox& Box, int32_t& CornerIndex); // 0x10a802c4 (Index: 0x4, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector GetBoxFaceCenter(FBox& Box, int32_t& FaceIndex, FVector& FaceNormal); // 0x10a804b8 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static double GetBoxPointDistance(FBox& Box, FVector& Point); // 0x10a807ac (Index: 0x6, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static void GetBoxVolumeArea(FBox& Box, double& Volume, double& SurfaceArea); // 0x10a80934 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FBox GetExpandedBox(FBox& Box, FVector& ExpandBy); // 0x10a80b50 (Index: 0x8, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FBox GetTransformedBox(FBox& Box, FTransform& Transform); // 0x10a8868c (Index: 0x9, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FBox MakeBoxFromCenterExtents(FVector& Center, FVector& Extents); // 0x10a8ac78 (Index: 0xa, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FBox MakeBoxFromCenterSize(FVector& Center, FVector& Dimensions); // 0x10a8ae3c (Index: 0xb, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool TestBoxBoxIntersection(FBox& Box1, FBox& Box2); // 0x10a97ebc (Index: 0xc, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool TestBoxSphereIntersection(FBox& Box, FVector& SphereCenter, double& SphereRadius); // 0x10a9804c (Index: 0xd, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool TestPointInsideBox(FBox& Box, FVector& Point, bool& bConsiderOnBoxAsInside); // 0x10a98240 (Index: 0xe, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UGeometryScriptLibrary_BoxFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_BoxFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_TextureMapFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static void SampleTexture2DAtUVPositions(FGeometryScriptUVList& UVList, UTexture2D*& Texture, FGeometryScriptSampleTextureOptions& SampleOptions, FGeometryScriptColorList& ColorList, UGeometryScriptDebug*& Debug); // 0x10a8f31c (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SampleTextureRenderTarget2DAtUVPositions(FGeometryScriptUVList& UVList, UTextureRenderTarget2D*& Texture, FGeometryScriptSampleTextureOptions& SampleOptions, FGeometryScriptColorList& ColorList, UGeometryScriptDebug*& Debug); // 0x10a8f680 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_TextureMapFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_TextureMapFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_VectorMathFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static FGeometryScriptScalarList ConstantScalarMultiply(double& Constant, FGeometryScriptScalarList& ScalarList); // 0x10a752cc (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ConstantScalarMultiplyInPlace(double& Constant, FGeometryScriptScalarList ScalarList); // 0x10a754f0 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptVectorList ConstantVectorMultiply(double& Constant, FGeometryScriptVectorList& VectorList); // 0x10a756d4 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ConstantVectorMultiplyInPlace(double& Constant, FGeometryScriptVectorList VectorList); // 0x10a758f8 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptScalarList ScalarBlend(FGeometryScriptScalarList& ScalarListA, FGeometryScriptScalarList& ScalarListB, double& ConstantA, double& ConstantB); // 0x10a8f9e4 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ScalarBlendInPlace(FGeometryScriptScalarList& ScalarListA, FGeometryScriptScalarList ScalarListB, double& ConstantA, double& ConstantB); // 0x10a8fcdc (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptScalarList ScalarInvert(FGeometryScriptScalarList& ScalarList, double& Numerator, double& SetOnFailure, double& Epsilon); // 0x10a8ff90 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ScalarInvertInPlace(FGeometryScriptScalarList ScalarList, double& Numerator, double& SetOnFailure, double& Epsilon); // 0x10a9022c (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptScalarList ScalarMultiply(FGeometryScriptScalarList& ScalarListA, FGeometryScriptScalarList& ScalarListB, double& ConstantMultiplier); // 0x10a9048c (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ScalarMultiplyInPlace(FGeometryScriptScalarList& ScalarListA, FGeometryScriptScalarList ScalarListB, double& ConstantMultiplier); // 0x10a9070c (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptVectorList ScalarVectorMultiply(FGeometryScriptScalarList& ScalarList, FGeometryScriptVectorList& VectorList, double& ScalarMultiplier); // 0x10a90958 (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ScalarVectorMultiplyInPlace(FGeometryScriptScalarList& ScalarList, FGeometryScriptVectorList VectorList, double& ScalarMultiplier); // 0x10a90bd8 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptVectorList VectorBlend(FGeometryScriptVectorList& VectorListA, FGeometryScriptVectorList& VectorListB, double& ConstantA, double& ConstantB); // 0x10a9a9ac (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void VectorBlendInPlace(FGeometryScriptVectorList& VectorListA, FGeometryScriptVectorList VectorListB, double& ConstantA, double& ConstantB); // 0x10a9aca4 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FGeometryScriptVectorList VectorCross(FGeometryScriptVectorList& VectorListA, FGeometryScriptVectorList& VectorListB); // 0x10a9af58 (Index: 0xe, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGeometryScriptScalarList VectorDot(FGeometryScriptVectorList& VectorListA, FGeometryScriptVectorList& VectorListB); // 0x10a9b16c (Index: 0xf, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void VectorInverseTransformInPlace(FGeometryScriptVectorList VectorList, FTransform& Transform, bool& bAsPosition); // 0x10a9b380 (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FGeometryScriptScalarList VectorLength(FGeometryScriptVectorList& VectorList); // 0x10a9b618 (Index: 0x11, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void VectorNormalizeInPlace(FGeometryScriptVectorList VectorList, FVector& SetOnFailure); // 0x10a9b750 (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void VectorPlaneProjectInPlace(FGeometryScriptVectorList VectorList, FPlane& Plane); // 0x10a9b8e4 (Index: 0x13, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FGeometryScriptScalarList VectorToScalar(FGeometryScriptVectorList& VectorList, double& ConstantX, double& ConstantY, double& ConstantZ); // 0x10a9ba74 (Index: 0x14, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void VectorTransformInPlace(FGeometryScriptVectorList VectorList, FTransform& Transform, bool& bAsPosition); // 0x10a9bd10 (Index: 0x15, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_VectorMathFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_VectorMathFunctions");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGeometryScriptLibrary_VolumeTextureBakeFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static bool BakeSignedDistanceToVolumeTexture(UDynamicMesh*& const TargetMesh, UVolumeTexture*& VolumeTexture, FComputeDistanceFieldSettings& DistanceSettings, FDistanceFieldToTextureSettings& TextureSettings); // 0x10a73ce0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UGeometryScriptLibrary_VolumeTextureBakeFunctions) == 0x28, "Size mismatch for UGeometryScriptLibrary_VolumeTextureBakeFunctions");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryScriptMeshReadLOD
{
    uint8_t LODType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t LODIndex; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptMeshReadLOD) == 0x8, "Size mismatch for FGeometryScriptMeshReadLOD");
static_assert(offsetof(FGeometryScriptMeshReadLOD, LODType) == 0x0, "Offset mismatch for FGeometryScriptMeshReadLOD::LODType");
static_assert(offsetof(FGeometryScriptMeshReadLOD, LODIndex) == 0x4, "Offset mismatch for FGeometryScriptMeshReadLOD::LODIndex");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryScriptMeshWriteLOD
{
    bool bWriteHiResSource; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t LODIndex; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptMeshWriteLOD) == 0x8, "Size mismatch for FGeometryScriptMeshWriteLOD");
static_assert(offsetof(FGeometryScriptMeshWriteLOD, bWriteHiResSource) == 0x0, "Offset mismatch for FGeometryScriptMeshWriteLOD::bWriteHiResSource");
static_assert(offsetof(FGeometryScriptMeshWriteLOD, LODIndex) == 0x4, "Offset mismatch for FGeometryScriptMeshWriteLOD::LODIndex");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FGeometryScriptSimpleCollision
{
    FKAggregateGeom AggGeom; // 0x0 (Size: 0xa0, Type: StructProperty)
};

static_assert(sizeof(FGeometryScriptSimpleCollision) == 0xa0, "Size mismatch for FGeometryScriptSimpleCollision");
static_assert(offsetof(FGeometryScriptSimpleCollision, AggGeom) == 0x0, "Offset mismatch for FGeometryScriptSimpleCollision::AggGeom");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptSphereCovering
{
};

static_assert(sizeof(FGeometryScriptSphereCovering) == 0x10, "Size mismatch for FGeometryScriptSphereCovering");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptSimpleCollisionTriangulationOptions
{
    int32_t SphereStepsPerSide; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t CapsuleHemisphereSteps; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t CapsuleCircleSteps; // 0x8 (Size: 0x4, Type: IntProperty)
    bool bApproximateLevelSetsWithCubes; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptSimpleCollisionTriangulationOptions) == 0x10, "Size mismatch for FGeometryScriptSimpleCollisionTriangulationOptions");
static_assert(offsetof(FGeometryScriptSimpleCollisionTriangulationOptions, SphereStepsPerSide) == 0x0, "Offset mismatch for FGeometryScriptSimpleCollisionTriangulationOptions::SphereStepsPerSide");
static_assert(offsetof(FGeometryScriptSimpleCollisionTriangulationOptions, CapsuleHemisphereSteps) == 0x4, "Offset mismatch for FGeometryScriptSimpleCollisionTriangulationOptions::CapsuleHemisphereSteps");
static_assert(offsetof(FGeometryScriptSimpleCollisionTriangulationOptions, CapsuleCircleSteps) == 0x8, "Offset mismatch for FGeometryScriptSimpleCollisionTriangulationOptions::CapsuleCircleSteps");
static_assert(offsetof(FGeometryScriptSimpleCollisionTriangulationOptions, bApproximateLevelSetsWithCubes) == 0xc, "Offset mismatch for FGeometryScriptSimpleCollisionTriangulationOptions::bApproximateLevelSetsWithCubes");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FGeometryScriptTriangle
{
    FVector Vector0; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Vector1; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector vector2; // 0x30 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FGeometryScriptTriangle) == 0x48, "Size mismatch for FGeometryScriptTriangle");
static_assert(offsetof(FGeometryScriptTriangle, Vector0) == 0x0, "Offset mismatch for FGeometryScriptTriangle::Vector0");
static_assert(offsetof(FGeometryScriptTriangle, Vector1) == 0x18, "Offset mismatch for FGeometryScriptTriangle::Vector1");
static_assert(offsetof(FGeometryScriptTriangle, vector2) == 0x30, "Offset mismatch for FGeometryScriptTriangle::vector2");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FGeometryScriptTrianglePoint
{
    bool bValid; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t TriangleID; // 0x4 (Size: 0x4, Type: IntProperty)
    FVector Position; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector BaryCoords; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FGeometryScriptTrianglePoint) == 0x38, "Size mismatch for FGeometryScriptTrianglePoint");
static_assert(offsetof(FGeometryScriptTrianglePoint, bValid) == 0x0, "Offset mismatch for FGeometryScriptTrianglePoint::bValid");
static_assert(offsetof(FGeometryScriptTrianglePoint, TriangleID) == 0x4, "Offset mismatch for FGeometryScriptTrianglePoint::TriangleID");
static_assert(offsetof(FGeometryScriptTrianglePoint, Position) == 0x8, "Offset mismatch for FGeometryScriptTrianglePoint::Position");
static_assert(offsetof(FGeometryScriptTrianglePoint, BaryCoords) == 0x20, "Offset mismatch for FGeometryScriptTrianglePoint::BaryCoords");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FGeometryScriptUVTriangle
{
    FVector2D UV0; // 0x0 (Size: 0x10, Type: StructProperty)
    FVector2D UV1; // 0x10 (Size: 0x10, Type: StructProperty)
    FVector2D UV2; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FGeometryScriptUVTriangle) == 0x30, "Size mismatch for FGeometryScriptUVTriangle");
static_assert(offsetof(FGeometryScriptUVTriangle, UV0) == 0x0, "Offset mismatch for FGeometryScriptUVTriangle::UV0");
static_assert(offsetof(FGeometryScriptUVTriangle, UV1) == 0x10, "Offset mismatch for FGeometryScriptUVTriangle::UV1");
static_assert(offsetof(FGeometryScriptUVTriangle, UV2) == 0x20, "Offset mismatch for FGeometryScriptUVTriangle::UV2");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGeometryScriptColorFlags
{
    bool bRed; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bGreen; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bBlue; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bAlpha; // 0x3 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptColorFlags) == 0x4, "Size mismatch for FGeometryScriptColorFlags");
static_assert(offsetof(FGeometryScriptColorFlags, bRed) == 0x0, "Offset mismatch for FGeometryScriptColorFlags::bRed");
static_assert(offsetof(FGeometryScriptColorFlags, bGreen) == 0x1, "Offset mismatch for FGeometryScriptColorFlags::bGreen");
static_assert(offsetof(FGeometryScriptColorFlags, bBlue) == 0x2, "Offset mismatch for FGeometryScriptColorFlags::bBlue");
static_assert(offsetof(FGeometryScriptColorFlags, bAlpha) == 0x3, "Offset mismatch for FGeometryScriptColorFlags::bAlpha");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryScriptGroupLayer
{
    bool bDefaultLayer; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t ExtendedLayerIndex; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptGroupLayer) == 0x8, "Size mismatch for FGeometryScriptGroupLayer");
static_assert(offsetof(FGeometryScriptGroupLayer, bDefaultLayer) == 0x0, "Offset mismatch for FGeometryScriptGroupLayer::bDefaultLayer");
static_assert(offsetof(FGeometryScriptGroupLayer, ExtendedLayerIndex) == 0x4, "Offset mismatch for FGeometryScriptGroupLayer::ExtendedLayerIndex");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGeometryScriptIndexList
{
    uint8_t IndexType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x17]; // 0x1 (Size: 0x17, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptIndexList) == 0x18, "Size mismatch for FGeometryScriptIndexList");
static_assert(offsetof(FGeometryScriptIndexList, IndexType) == 0x0, "Offset mismatch for FGeometryScriptIndexList::IndexType");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptTriangleList
{
};

static_assert(sizeof(FGeometryScriptTriangleList) == 0x10, "Size mismatch for FGeometryScriptTriangleList");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptScalarList
{
};

static_assert(sizeof(FGeometryScriptScalarList) == 0x10, "Size mismatch for FGeometryScriptScalarList");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptVectorList
{
};

static_assert(sizeof(FGeometryScriptVectorList) == 0x10, "Size mismatch for FGeometryScriptVectorList");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptUVList
{
};

static_assert(sizeof(FGeometryScriptUVList) == 0x10, "Size mismatch for FGeometryScriptUVList");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptColorList
{
};

static_assert(sizeof(FGeometryScriptColorList) == 0x10, "Size mismatch for FGeometryScriptColorList");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGeometryScriptPolyPath
{
    bool bClosedLoop; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptPolyPath) == 0x18, "Size mismatch for FGeometryScriptPolyPath");
static_assert(offsetof(FGeometryScriptPolyPath, bClosedLoop) == 0x10, "Offset mismatch for FGeometryScriptPolyPath::bClosedLoop");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptSimplePolygon
{
};

static_assert(sizeof(FGeometryScriptSimplePolygon) == 0x10, "Size mismatch for FGeometryScriptSimplePolygon");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptGeneralPolygonList
{
};

static_assert(sizeof(FGeometryScriptGeneralPolygonList) == 0x10, "Size mismatch for FGeometryScriptGeneralPolygonList");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGeometryScriptDynamicMeshBVH
{
};

static_assert(sizeof(FGeometryScriptDynamicMeshBVH) == 0x20, "Size mismatch for FGeometryScriptDynamicMeshBVH");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FGeometryScriptRenderCaptureCamera
{
    int32_t Resolution; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    double FieldOfViewDegrees; // 0x8 (Size: 0x8, Type: DoubleProperty)
    FVector ViewPosition; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector ViewDirection; // 0x28 (Size: 0x18, Type: StructProperty)
    double NearPlaneDist; // 0x40 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FGeometryScriptRenderCaptureCamera) == 0x48, "Size mismatch for FGeometryScriptRenderCaptureCamera");
static_assert(offsetof(FGeometryScriptRenderCaptureCamera, Resolution) == 0x0, "Offset mismatch for FGeometryScriptRenderCaptureCamera::Resolution");
static_assert(offsetof(FGeometryScriptRenderCaptureCamera, FieldOfViewDegrees) == 0x8, "Offset mismatch for FGeometryScriptRenderCaptureCamera::FieldOfViewDegrees");
static_assert(offsetof(FGeometryScriptRenderCaptureCamera, ViewPosition) == 0x10, "Offset mismatch for FGeometryScriptRenderCaptureCamera::ViewPosition");
static_assert(offsetof(FGeometryScriptRenderCaptureCamera, ViewDirection) == 0x28, "Offset mismatch for FGeometryScriptRenderCaptureCamera::ViewDirection");
static_assert(offsetof(FGeometryScriptRenderCaptureCamera, NearPlaneDist) == 0x40, "Offset mismatch for FGeometryScriptRenderCaptureCamera::NearPlaneDist");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGeometryScriptRenderCaptureCamerasForBoxOptions
{
    int32_t Resolution; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    double FieldOfViewDegrees; // 0x8 (Size: 0x8, Type: DoubleProperty)
    bool bViewFromBoxFaces; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bViewFromUpperCorners; // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bViewFromLowerCorners; // 0x12 (Size: 0x1, Type: BoolProperty)
    bool bViewFromUpperEdges; // 0x13 (Size: 0x1, Type: BoolProperty)
    bool bViewFromLowerEdges; // 0x14 (Size: 0x1, Type: BoolProperty)
    bool bViewFromSideEdges; // 0x15 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_16[0x2]; // 0x16 (Size: 0x2, Type: PaddingProperty)
    TArray<FVector> ExtraViewFromPositions; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGeometryScriptRenderCaptureCamerasForBoxOptions) == 0x28, "Size mismatch for FGeometryScriptRenderCaptureCamerasForBoxOptions");
static_assert(offsetof(FGeometryScriptRenderCaptureCamerasForBoxOptions, Resolution) == 0x0, "Offset mismatch for FGeometryScriptRenderCaptureCamerasForBoxOptions::Resolution");
static_assert(offsetof(FGeometryScriptRenderCaptureCamerasForBoxOptions, FieldOfViewDegrees) == 0x8, "Offset mismatch for FGeometryScriptRenderCaptureCamerasForBoxOptions::FieldOfViewDegrees");
static_assert(offsetof(FGeometryScriptRenderCaptureCamerasForBoxOptions, bViewFromBoxFaces) == 0x10, "Offset mismatch for FGeometryScriptRenderCaptureCamerasForBoxOptions::bViewFromBoxFaces");
static_assert(offsetof(FGeometryScriptRenderCaptureCamerasForBoxOptions, bViewFromUpperCorners) == 0x11, "Offset mismatch for FGeometryScriptRenderCaptureCamerasForBoxOptions::bViewFromUpperCorners");
static_assert(offsetof(FGeometryScriptRenderCaptureCamerasForBoxOptions, bViewFromLowerCorners) == 0x12, "Offset mismatch for FGeometryScriptRenderCaptureCamerasForBoxOptions::bViewFromLowerCorners");
static_assert(offsetof(FGeometryScriptRenderCaptureCamerasForBoxOptions, bViewFromUpperEdges) == 0x13, "Offset mismatch for FGeometryScriptRenderCaptureCamerasForBoxOptions::bViewFromUpperEdges");
static_assert(offsetof(FGeometryScriptRenderCaptureCamerasForBoxOptions, bViewFromLowerEdges) == 0x14, "Offset mismatch for FGeometryScriptRenderCaptureCamerasForBoxOptions::bViewFromLowerEdges");
static_assert(offsetof(FGeometryScriptRenderCaptureCamerasForBoxOptions, bViewFromSideEdges) == 0x15, "Offset mismatch for FGeometryScriptRenderCaptureCamerasForBoxOptions::bViewFromSideEdges");
static_assert(offsetof(FGeometryScriptRenderCaptureCamerasForBoxOptions, ExtraViewFromPositions) == 0x18, "Offset mismatch for FGeometryScriptRenderCaptureCamerasForBoxOptions::ExtraViewFromPositions");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGeometryScriptDebugMessage
{
    uint8_t MessageType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t ErrorType; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2[0x6]; // 0x2 (Size: 0x6, Type: PaddingProperty)
    FText Message; // 0x8 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FGeometryScriptDebugMessage) == 0x18, "Size mismatch for FGeometryScriptDebugMessage");
static_assert(offsetof(FGeometryScriptDebugMessage, MessageType) == 0x0, "Offset mismatch for FGeometryScriptDebugMessage::MessageType");
static_assert(offsetof(FGeometryScriptDebugMessage, ErrorType) == 0x1, "Offset mismatch for FGeometryScriptDebugMessage::ErrorType");
static_assert(offsetof(FGeometryScriptDebugMessage, Message) == 0x8, "Offset mismatch for FGeometryScriptDebugMessage::Message");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FGeometryScriptCollisionFromMeshOptions
{
    bool bEmitTransaction; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Method; // 0x1 (Size: 0x1, Type: EnumProperty)
    bool bAutoDetectSpheres; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bAutoDetectBoxes; // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bAutoDetectCapsules; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    float MinThickness; // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bSimplifyHulls; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    int32_t ConvexHullTargetFaceCount; // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t MaxConvexHullsPerMesh; // 0x14 (Size: 0x4, Type: IntProperty)
    float ConvexDecompositionSearchFactor; // 0x18 (Size: 0x4, Type: FloatProperty)
    float ConvexDecompositionErrorTolerance; // 0x1c (Size: 0x4, Type: FloatProperty)
    float ConvexDecompositionMinPartThickness; // 0x20 (Size: 0x4, Type: FloatProperty)
    float SweptHullSimplifyTolerance; // 0x24 (Size: 0x4, Type: FloatProperty)
    uint8_t SweptHullAxis; // 0x28 (Size: 0x1, Type: EnumProperty)
    bool bRemoveFullyContainedShapes; // 0x29 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    int32_t MaxShapeCount; // 0x2c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptCollisionFromMeshOptions) == 0x30, "Size mismatch for FGeometryScriptCollisionFromMeshOptions");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, bEmitTransaction) == 0x0, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::bEmitTransaction");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, Method) == 0x1, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::Method");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, bAutoDetectSpheres) == 0x2, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::bAutoDetectSpheres");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, bAutoDetectBoxes) == 0x3, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::bAutoDetectBoxes");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, bAutoDetectCapsules) == 0x4, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::bAutoDetectCapsules");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, MinThickness) == 0x8, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::MinThickness");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, bSimplifyHulls) == 0xc, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::bSimplifyHulls");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, ConvexHullTargetFaceCount) == 0x10, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::ConvexHullTargetFaceCount");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, MaxConvexHullsPerMesh) == 0x14, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::MaxConvexHullsPerMesh");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, ConvexDecompositionSearchFactor) == 0x18, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::ConvexDecompositionSearchFactor");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, ConvexDecompositionErrorTolerance) == 0x1c, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::ConvexDecompositionErrorTolerance");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, ConvexDecompositionMinPartThickness) == 0x20, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::ConvexDecompositionMinPartThickness");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, SweptHullSimplifyTolerance) == 0x24, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::SweptHullSimplifyTolerance");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, SweptHullAxis) == 0x28, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::SweptHullAxis");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, bRemoveFullyContainedShapes) == 0x29, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::bRemoveFullyContainedShapes");
static_assert(offsetof(FGeometryScriptCollisionFromMeshOptions, MaxShapeCount) == 0x2c, "Offset mismatch for FGeometryScriptCollisionFromMeshOptions::MaxShapeCount");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGeometryScriptSetSimpleCollisionOptions
{
    bool bEmitTransaction; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptSetSimpleCollisionOptions) == 0x1, "Size mismatch for FGeometryScriptSetSimpleCollisionOptions");
static_assert(offsetof(FGeometryScriptSetSimpleCollisionOptions, bEmitTransaction) == 0x0, "Offset mismatch for FGeometryScriptSetSimpleCollisionOptions::bEmitTransaction");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGeometryScriptSetStaticMeshCollisionOptions
{
    bool bMarkAsCustomized; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptSetStaticMeshCollisionOptions) == 0x1, "Size mismatch for FGeometryScriptSetStaticMeshCollisionOptions");
static_assert(offsetof(FGeometryScriptSetStaticMeshCollisionOptions, bMarkAsCustomized) == 0x0, "Offset mismatch for FGeometryScriptSetStaticMeshCollisionOptions::bMarkAsCustomized");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FNegativeSpaceDirectionalToleranceScale
{
    FVector Direction; // 0x0 (Size: 0x18, Type: StructProperty)
    double AngleRange; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double ScaleFactor; // 0x20 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FNegativeSpaceDirectionalToleranceScale) == 0x28, "Size mismatch for FNegativeSpaceDirectionalToleranceScale");
static_assert(offsetof(FNegativeSpaceDirectionalToleranceScale, Direction) == 0x0, "Offset mismatch for FNegativeSpaceDirectionalToleranceScale::Direction");
static_assert(offsetof(FNegativeSpaceDirectionalToleranceScale, AngleRange) == 0x18, "Offset mismatch for FNegativeSpaceDirectionalToleranceScale::AngleRange");
static_assert(offsetof(FNegativeSpaceDirectionalToleranceScale, ScaleFactor) == 0x20, "Offset mismatch for FNegativeSpaceDirectionalToleranceScale::ScaleFactor");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FComputeNegativeSpaceOptions
{
    uint8_t SampleMethod; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bRequireSearchSampleCoverage; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bOnlyConnectedToHull; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    int32_t MaxVoxelsPerDim; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t TargetNumSamples; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    double MinSampleSpacing; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double NegativeSpaceTolerance; // 0x18 (Size: 0x8, Type: DoubleProperty)
    TArray<FNegativeSpaceDirectionalToleranceScale> ToleranceDirectionalScales; // 0x20 (Size: 0x10, Type: ArrayProperty)
    double MinRadius; // 0x30 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FComputeNegativeSpaceOptions) == 0x38, "Size mismatch for FComputeNegativeSpaceOptions");
static_assert(offsetof(FComputeNegativeSpaceOptions, SampleMethod) == 0x0, "Offset mismatch for FComputeNegativeSpaceOptions::SampleMethod");
static_assert(offsetof(FComputeNegativeSpaceOptions, bRequireSearchSampleCoverage) == 0x1, "Offset mismatch for FComputeNegativeSpaceOptions::bRequireSearchSampleCoverage");
static_assert(offsetof(FComputeNegativeSpaceOptions, bOnlyConnectedToHull) == 0x2, "Offset mismatch for FComputeNegativeSpaceOptions::bOnlyConnectedToHull");
static_assert(offsetof(FComputeNegativeSpaceOptions, MaxVoxelsPerDim) == 0x4, "Offset mismatch for FComputeNegativeSpaceOptions::MaxVoxelsPerDim");
static_assert(offsetof(FComputeNegativeSpaceOptions, TargetNumSamples) == 0x8, "Offset mismatch for FComputeNegativeSpaceOptions::TargetNumSamples");
static_assert(offsetof(FComputeNegativeSpaceOptions, MinSampleSpacing) == 0x10, "Offset mismatch for FComputeNegativeSpaceOptions::MinSampleSpacing");
static_assert(offsetof(FComputeNegativeSpaceOptions, NegativeSpaceTolerance) == 0x18, "Offset mismatch for FComputeNegativeSpaceOptions::NegativeSpaceTolerance");
static_assert(offsetof(FComputeNegativeSpaceOptions, ToleranceDirectionalScales) == 0x20, "Offset mismatch for FComputeNegativeSpaceOptions::ToleranceDirectionalScales");
static_assert(offsetof(FComputeNegativeSpaceOptions, MinRadius) == 0x30, "Offset mismatch for FComputeNegativeSpaceOptions::MinRadius");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FNavigableConvexDecompositionOptions
{
    double MinRadius; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Tolerance; // 0x8 (Size: 0x8, Type: DoubleProperty)
    bool bIgnoreUnreachableInternalSpace; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    TArray<FVector> CustomNavigablePositions; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FPlane> UnreachablePlanes; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FNegativeSpaceDirectionalToleranceScale> ToleranceDirectionalScales; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FNavigableConvexDecompositionOptions) == 0x48, "Size mismatch for FNavigableConvexDecompositionOptions");
static_assert(offsetof(FNavigableConvexDecompositionOptions, MinRadius) == 0x0, "Offset mismatch for FNavigableConvexDecompositionOptions::MinRadius");
static_assert(offsetof(FNavigableConvexDecompositionOptions, Tolerance) == 0x8, "Offset mismatch for FNavigableConvexDecompositionOptions::Tolerance");
static_assert(offsetof(FNavigableConvexDecompositionOptions, bIgnoreUnreachableInternalSpace) == 0x10, "Offset mismatch for FNavigableConvexDecompositionOptions::bIgnoreUnreachableInternalSpace");
static_assert(offsetof(FNavigableConvexDecompositionOptions, CustomNavigablePositions) == 0x18, "Offset mismatch for FNavigableConvexDecompositionOptions::CustomNavigablePositions");
static_assert(offsetof(FNavigableConvexDecompositionOptions, UnreachablePlanes) == 0x28, "Offset mismatch for FNavigableConvexDecompositionOptions::UnreachablePlanes");
static_assert(offsetof(FNavigableConvexDecompositionOptions, ToleranceDirectionalScales) == 0x38, "Offset mismatch for FNavigableConvexDecompositionOptions::ToleranceDirectionalScales");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FGeometryScriptMergeSimpleCollisionOptions
{
    int32_t MaxShapeCount; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    double ErrorTolerance; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double MinThicknessTolerance; // 0x10 (Size: 0x8, Type: DoubleProperty)
    bool bConsiderAllPossibleMerges; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    FGeometryScriptSphereCovering PrecomputedNegativeSpace; // 0x20 (Size: 0x10, Type: StructProperty)
    bool bComputeNegativeSpace; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    FComputeNegativeSpaceOptions ComputeNegativeSpaceOptions; // 0x38 (Size: 0x38, Type: StructProperty)
    FGeometryScriptSimpleCollisionTriangulationOptions ShapeToHullTriangulation; // 0x70 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FGeometryScriptMergeSimpleCollisionOptions) == 0x80, "Size mismatch for FGeometryScriptMergeSimpleCollisionOptions");
static_assert(offsetof(FGeometryScriptMergeSimpleCollisionOptions, MaxShapeCount) == 0x0, "Offset mismatch for FGeometryScriptMergeSimpleCollisionOptions::MaxShapeCount");
static_assert(offsetof(FGeometryScriptMergeSimpleCollisionOptions, ErrorTolerance) == 0x8, "Offset mismatch for FGeometryScriptMergeSimpleCollisionOptions::ErrorTolerance");
static_assert(offsetof(FGeometryScriptMergeSimpleCollisionOptions, MinThicknessTolerance) == 0x10, "Offset mismatch for FGeometryScriptMergeSimpleCollisionOptions::MinThicknessTolerance");
static_assert(offsetof(FGeometryScriptMergeSimpleCollisionOptions, bConsiderAllPossibleMerges) == 0x18, "Offset mismatch for FGeometryScriptMergeSimpleCollisionOptions::bConsiderAllPossibleMerges");
static_assert(offsetof(FGeometryScriptMergeSimpleCollisionOptions, PrecomputedNegativeSpace) == 0x20, "Offset mismatch for FGeometryScriptMergeSimpleCollisionOptions::PrecomputedNegativeSpace");
static_assert(offsetof(FGeometryScriptMergeSimpleCollisionOptions, bComputeNegativeSpace) == 0x30, "Offset mismatch for FGeometryScriptMergeSimpleCollisionOptions::bComputeNegativeSpace");
static_assert(offsetof(FGeometryScriptMergeSimpleCollisionOptions, ComputeNegativeSpaceOptions) == 0x38, "Offset mismatch for FGeometryScriptMergeSimpleCollisionOptions::ComputeNegativeSpaceOptions");
static_assert(offsetof(FGeometryScriptMergeSimpleCollisionOptions, ShapeToHullTriangulation) == 0x70, "Offset mismatch for FGeometryScriptMergeSimpleCollisionOptions::ShapeToHullTriangulation");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptConvexHullSimplificationOptions
{
    uint8_t SimplificationMethod; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float SimplificationDistanceThreshold; // 0x4 (Size: 0x4, Type: FloatProperty)
    float SimplificationAngleThreshold; // 0x8 (Size: 0x4, Type: FloatProperty)
    int32_t MinTargetFaceCount; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptConvexHullSimplificationOptions) == 0x10, "Size mismatch for FGeometryScriptConvexHullSimplificationOptions");
static_assert(offsetof(FGeometryScriptConvexHullSimplificationOptions, SimplificationMethod) == 0x0, "Offset mismatch for FGeometryScriptConvexHullSimplificationOptions::SimplificationMethod");
static_assert(offsetof(FGeometryScriptConvexHullSimplificationOptions, SimplificationDistanceThreshold) == 0x4, "Offset mismatch for FGeometryScriptConvexHullSimplificationOptions::SimplificationDistanceThreshold");
static_assert(offsetof(FGeometryScriptConvexHullSimplificationOptions, SimplificationAngleThreshold) == 0x8, "Offset mismatch for FGeometryScriptConvexHullSimplificationOptions::SimplificationAngleThreshold");
static_assert(offsetof(FGeometryScriptConvexHullSimplificationOptions, MinTargetFaceCount) == 0xc, "Offset mismatch for FGeometryScriptConvexHullSimplificationOptions::MinTargetFaceCount");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptConvexHullApproximationOptions
{
    bool bFitSpheres; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bFitBoxes; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bFitCapsules; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    float DistanceThreshold; // 0x4 (Size: 0x4, Type: FloatProperty)
    float VolumeDiffThreshold_Fraction; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptConvexHullApproximationOptions) == 0xc, "Size mismatch for FGeometryScriptConvexHullApproximationOptions");
static_assert(offsetof(FGeometryScriptConvexHullApproximationOptions, bFitSpheres) == 0x0, "Offset mismatch for FGeometryScriptConvexHullApproximationOptions::bFitSpheres");
static_assert(offsetof(FGeometryScriptConvexHullApproximationOptions, bFitBoxes) == 0x1, "Offset mismatch for FGeometryScriptConvexHullApproximationOptions::bFitBoxes");
static_assert(offsetof(FGeometryScriptConvexHullApproximationOptions, bFitCapsules) == 0x2, "Offset mismatch for FGeometryScriptConvexHullApproximationOptions::bFitCapsules");
static_assert(offsetof(FGeometryScriptConvexHullApproximationOptions, DistanceThreshold) == 0x4, "Offset mismatch for FGeometryScriptConvexHullApproximationOptions::DistanceThreshold");
static_assert(offsetof(FGeometryScriptConvexHullApproximationOptions, VolumeDiffThreshold_Fraction) == 0x8, "Offset mismatch for FGeometryScriptConvexHullApproximationOptions::VolumeDiffThreshold_Fraction");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FGeometryScriptTransformCollisionOptions
{
    bool bWarnOnInvalidTransforms; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bCenterTransformPivotPerShape; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptTransformCollisionOptions) == 0x2, "Size mismatch for FGeometryScriptTransformCollisionOptions");
static_assert(offsetof(FGeometryScriptTransformCollisionOptions, bWarnOnInvalidTransforms) == 0x0, "Offset mismatch for FGeometryScriptTransformCollisionOptions::bWarnOnInvalidTransforms");
static_assert(offsetof(FGeometryScriptTransformCollisionOptions, bCenterTransformPivotPerShape) == 0x1, "Offset mismatch for FGeometryScriptTransformCollisionOptions::bCenterTransformPivotPerShape");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptConvexHullOptions
{
    bool bPrefilterVertices; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t PrefilterGridResolution; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t SimplifyToFaceCount; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptConvexHullOptions) == 0xc, "Size mismatch for FGeometryScriptConvexHullOptions");
static_assert(offsetof(FGeometryScriptConvexHullOptions, bPrefilterVertices) == 0x0, "Offset mismatch for FGeometryScriptConvexHullOptions::bPrefilterVertices");
static_assert(offsetof(FGeometryScriptConvexHullOptions, PrefilterGridResolution) == 0x4, "Offset mismatch for FGeometryScriptConvexHullOptions::PrefilterGridResolution");
static_assert(offsetof(FGeometryScriptConvexHullOptions, SimplifyToFaceCount) == 0x8, "Offset mismatch for FGeometryScriptConvexHullOptions::SimplifyToFaceCount");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGeometryScriptSweptHullOptions
{
    bool bPrefilterVertices; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t PrefilterGridResolution; // 0x4 (Size: 0x4, Type: IntProperty)
    float MinThickness; // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bSimplify; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    float MinEdgeLength; // 0x10 (Size: 0x4, Type: FloatProperty)
    float SimplifyTolerance; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptSweptHullOptions) == 0x18, "Size mismatch for FGeometryScriptSweptHullOptions");
static_assert(offsetof(FGeometryScriptSweptHullOptions, bPrefilterVertices) == 0x0, "Offset mismatch for FGeometryScriptSweptHullOptions::bPrefilterVertices");
static_assert(offsetof(FGeometryScriptSweptHullOptions, PrefilterGridResolution) == 0x4, "Offset mismatch for FGeometryScriptSweptHullOptions::PrefilterGridResolution");
static_assert(offsetof(FGeometryScriptSweptHullOptions, MinThickness) == 0x8, "Offset mismatch for FGeometryScriptSweptHullOptions::MinThickness");
static_assert(offsetof(FGeometryScriptSweptHullOptions, bSimplify) == 0xc, "Offset mismatch for FGeometryScriptSweptHullOptions::bSimplify");
static_assert(offsetof(FGeometryScriptSweptHullOptions, MinEdgeLength) == 0x10, "Offset mismatch for FGeometryScriptSweptHullOptions::MinEdgeLength");
static_assert(offsetof(FGeometryScriptSweptHullOptions, SimplifyTolerance) == 0x14, "Offset mismatch for FGeometryScriptSweptHullOptions::SimplifyTolerance");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGeometryScriptConvexDecompositionOptions
{
    int32_t NumHulls; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    double SearchFactor; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double ErrorTolerance; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double MinPartThickness; // 0x18 (Size: 0x8, Type: DoubleProperty)
    int32_t SimplifyToFaceCount; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptConvexDecompositionOptions) == 0x28, "Size mismatch for FGeometryScriptConvexDecompositionOptions");
static_assert(offsetof(FGeometryScriptConvexDecompositionOptions, NumHulls) == 0x0, "Offset mismatch for FGeometryScriptConvexDecompositionOptions::NumHulls");
static_assert(offsetof(FGeometryScriptConvexDecompositionOptions, SearchFactor) == 0x8, "Offset mismatch for FGeometryScriptConvexDecompositionOptions::SearchFactor");
static_assert(offsetof(FGeometryScriptConvexDecompositionOptions, ErrorTolerance) == 0x10, "Offset mismatch for FGeometryScriptConvexDecompositionOptions::ErrorTolerance");
static_assert(offsetof(FGeometryScriptConvexDecompositionOptions, MinPartThickness) == 0x18, "Offset mismatch for FGeometryScriptConvexDecompositionOptions::MinPartThickness");
static_assert(offsetof(FGeometryScriptConvexDecompositionOptions, SimplifyToFaceCount) == 0x20, "Offset mismatch for FGeometryScriptConvexDecompositionOptions::SimplifyToFaceCount");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptMeshSelection
{
};

static_assert(sizeof(FGeometryScriptMeshSelection) == 0x10, "Size mismatch for FGeometryScriptMeshSelection");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGeometryScriptCopyMeshFromAssetOptions
{
    bool bApplyBuildSettings; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bRequestTangents; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreRemoveDegenerates; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bUseBuildScale; // 0x3 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptCopyMeshFromAssetOptions) == 0x4, "Size mismatch for FGeometryScriptCopyMeshFromAssetOptions");
static_assert(offsetof(FGeometryScriptCopyMeshFromAssetOptions, bApplyBuildSettings) == 0x0, "Offset mismatch for FGeometryScriptCopyMeshFromAssetOptions::bApplyBuildSettings");
static_assert(offsetof(FGeometryScriptCopyMeshFromAssetOptions, bRequestTangents) == 0x1, "Offset mismatch for FGeometryScriptCopyMeshFromAssetOptions::bRequestTangents");
static_assert(offsetof(FGeometryScriptCopyMeshFromAssetOptions, bIgnoreRemoveDegenerates) == 0x2, "Offset mismatch for FGeometryScriptCopyMeshFromAssetOptions::bIgnoreRemoveDegenerates");
static_assert(offsetof(FGeometryScriptCopyMeshFromAssetOptions, bUseBuildScale) == 0x3, "Offset mismatch for FGeometryScriptCopyMeshFromAssetOptions::bUseBuildScale");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptNaniteOptions
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float FallbackPercentTriangles; // 0x4 (Size: 0x4, Type: FloatProperty)
    float FallbackRelativeError; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptNaniteOptions) == 0xc, "Size mismatch for FGeometryScriptNaniteOptions");
static_assert(offsetof(FGeometryScriptNaniteOptions, bEnabled) == 0x0, "Offset mismatch for FGeometryScriptNaniteOptions::bEnabled");
static_assert(offsetof(FGeometryScriptNaniteOptions, FallbackPercentTriangles) == 0x4, "Offset mismatch for FGeometryScriptNaniteOptions::FallbackPercentTriangles");
static_assert(offsetof(FGeometryScriptNaniteOptions, FallbackRelativeError) == 0x8, "Offset mismatch for FGeometryScriptNaniteOptions::FallbackRelativeError");

// Size: 0xb8 (Inherited: 0x0, Single: 0xb8)
struct FGeometryScriptCopyMeshToAssetOptions
{
    bool bEnableRecomputeNormals; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bEnableRecomputeTangents; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bEnableRemoveDegenerates; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t BoneHierarchyMismatchHandling; // 0x3 (Size: 0x1, Type: EnumProperty)
    bool bRemapBoneIndicesToMatchAsset; // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bUseOriginalVertexOrder; // 0x5 (Size: 0x1, Type: BoolProperty)
    bool bUseBuildScale; // 0x6 (Size: 0x1, Type: BoolProperty)
    bool bReplaceMaterials; // 0x7 (Size: 0x1, Type: BoolProperty)
    uint8_t GenerateLightmapUVs; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    TArray<UMaterialInterface*> NewMaterials; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> NewMaterialSlotNames; // 0x20 (Size: 0x10, Type: ArrayProperty)
    bool bApplyNaniteSettings; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x3]; // 0x31 (Size: 0x3, Type: PaddingProperty)
    FGeometryScriptNaniteOptions NaniteSettings; // 0x34 (Size: 0xc, Type: StructProperty)
    FMeshNaniteSettings NewNaniteSettings; // 0x40 (Size: 0x70, Type: StructProperty)
    bool bEmitTransaction; // 0xb0 (Size: 0x1, Type: BoolProperty)
    bool bDeferMeshPostEditChange; // 0xb1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b2[0x6]; // 0xb2 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptCopyMeshToAssetOptions) == 0xb8, "Size mismatch for FGeometryScriptCopyMeshToAssetOptions");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, bEnableRecomputeNormals) == 0x0, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::bEnableRecomputeNormals");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, bEnableRecomputeTangents) == 0x1, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::bEnableRecomputeTangents");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, bEnableRemoveDegenerates) == 0x2, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::bEnableRemoveDegenerates");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, BoneHierarchyMismatchHandling) == 0x3, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::BoneHierarchyMismatchHandling");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, bRemapBoneIndicesToMatchAsset) == 0x4, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::bRemapBoneIndicesToMatchAsset");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, bUseOriginalVertexOrder) == 0x5, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::bUseOriginalVertexOrder");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, bUseBuildScale) == 0x6, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::bUseBuildScale");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, bReplaceMaterials) == 0x7, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::bReplaceMaterials");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, GenerateLightmapUVs) == 0x8, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::GenerateLightmapUVs");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, NewMaterials) == 0x10, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::NewMaterials");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, NewMaterialSlotNames) == 0x20, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::NewMaterialSlotNames");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, bApplyNaniteSettings) == 0x30, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::bApplyNaniteSettings");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, NaniteSettings) == 0x34, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::NaniteSettings");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, NewNaniteSettings) == 0x40, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::NewNaniteSettings");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, bEmitTransaction) == 0xb0, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::bEmitTransaction");
static_assert(offsetof(FGeometryScriptCopyMeshToAssetOptions, bDeferMeshPostEditChange) == 0xb1, "Offset mismatch for FGeometryScriptCopyMeshToAssetOptions::bDeferMeshPostEditChange");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGeometryScriptCopyMorphTargetToAssetOptions
{
    bool bOverwriteExistingTarget; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bEmitTransaction; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bDeferMeshPostEditChange; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bCopyNormals; // 0x3 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptCopyMorphTargetToAssetOptions) == 0x4, "Size mismatch for FGeometryScriptCopyMorphTargetToAssetOptions");
static_assert(offsetof(FGeometryScriptCopyMorphTargetToAssetOptions, bOverwriteExistingTarget) == 0x0, "Offset mismatch for FGeometryScriptCopyMorphTargetToAssetOptions::bOverwriteExistingTarget");
static_assert(offsetof(FGeometryScriptCopyMorphTargetToAssetOptions, bEmitTransaction) == 0x1, "Offset mismatch for FGeometryScriptCopyMorphTargetToAssetOptions::bEmitTransaction");
static_assert(offsetof(FGeometryScriptCopyMorphTargetToAssetOptions, bDeferMeshPostEditChange) == 0x2, "Offset mismatch for FGeometryScriptCopyMorphTargetToAssetOptions::bDeferMeshPostEditChange");
static_assert(offsetof(FGeometryScriptCopyMorphTargetToAssetOptions, bCopyNormals) == 0x3, "Offset mismatch for FGeometryScriptCopyMorphTargetToAssetOptions::bCopyNormals");

// Size: 0x3 (Inherited: 0x0, Single: 0x3)
struct FGeometryScriptCopySkinWeightProfileToAssetOptions
{
    bool bOverwriteExistingProfile; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bEmitTransaction; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bDeferMeshPostEditChange; // 0x2 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptCopySkinWeightProfileToAssetOptions) == 0x3, "Size mismatch for FGeometryScriptCopySkinWeightProfileToAssetOptions");
static_assert(offsetof(FGeometryScriptCopySkinWeightProfileToAssetOptions, bOverwriteExistingProfile) == 0x0, "Offset mismatch for FGeometryScriptCopySkinWeightProfileToAssetOptions::bOverwriteExistingProfile");
static_assert(offsetof(FGeometryScriptCopySkinWeightProfileToAssetOptions, bEmitTransaction) == 0x1, "Offset mismatch for FGeometryScriptCopySkinWeightProfileToAssetOptions::bEmitTransaction");
static_assert(offsetof(FGeometryScriptCopySkinWeightProfileToAssetOptions, bDeferMeshPostEditChange) == 0x2, "Offset mismatch for FGeometryScriptCopySkinWeightProfileToAssetOptions::bDeferMeshPostEditChange");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGeometryScriptBakeTypeOptions
{
    uint8_t BakeType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x17]; // 0x1 (Size: 0x17, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptBakeTypeOptions) == 0x18, "Size mismatch for FGeometryScriptBakeTypeOptions");
static_assert(offsetof(FGeometryScriptBakeTypeOptions, BakeType) == 0x0, "Offset mismatch for FGeometryScriptBakeTypeOptions::BakeType");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGeometryScriptBakeTextureOptions
{
    uint8_t Resolution; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t BitDepth; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t SamplesPerPixel; // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3[0x5]; // 0x3 (Size: 0x5, Type: PaddingProperty)
    UTexture2D* SampleFilterMask; // 0x8 (Size: 0x8, Type: ObjectProperty)
    uint8_t FilteringType; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float ProjectionDistance; // 0x14 (Size: 0x4, Type: FloatProperty)
    bool bProjectionInWorldSpace; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptBakeTextureOptions) == 0x20, "Size mismatch for FGeometryScriptBakeTextureOptions");
static_assert(offsetof(FGeometryScriptBakeTextureOptions, Resolution) == 0x0, "Offset mismatch for FGeometryScriptBakeTextureOptions::Resolution");
static_assert(offsetof(FGeometryScriptBakeTextureOptions, BitDepth) == 0x1, "Offset mismatch for FGeometryScriptBakeTextureOptions::BitDepth");
static_assert(offsetof(FGeometryScriptBakeTextureOptions, SamplesPerPixel) == 0x2, "Offset mismatch for FGeometryScriptBakeTextureOptions::SamplesPerPixel");
static_assert(offsetof(FGeometryScriptBakeTextureOptions, SampleFilterMask) == 0x8, "Offset mismatch for FGeometryScriptBakeTextureOptions::SampleFilterMask");
static_assert(offsetof(FGeometryScriptBakeTextureOptions, FilteringType) == 0x10, "Offset mismatch for FGeometryScriptBakeTextureOptions::FilteringType");
static_assert(offsetof(FGeometryScriptBakeTextureOptions, ProjectionDistance) == 0x14, "Offset mismatch for FGeometryScriptBakeTextureOptions::ProjectionDistance");
static_assert(offsetof(FGeometryScriptBakeTextureOptions, bProjectionInWorldSpace) == 0x18, "Offset mismatch for FGeometryScriptBakeTextureOptions::bProjectionInWorldSpace");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptBakeVertexOptions
{
    uint8_t TopologyMode; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bSplitAtNormalSeams; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bSplitAtUVSeams; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    float ProjectionDistance; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bProjectionInWorldSpace; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptBakeVertexOptions) == 0xc, "Size mismatch for FGeometryScriptBakeVertexOptions");
static_assert(offsetof(FGeometryScriptBakeVertexOptions, TopologyMode) == 0x0, "Offset mismatch for FGeometryScriptBakeVertexOptions::TopologyMode");
static_assert(offsetof(FGeometryScriptBakeVertexOptions, bSplitAtNormalSeams) == 0x1, "Offset mismatch for FGeometryScriptBakeVertexOptions::bSplitAtNormalSeams");
static_assert(offsetof(FGeometryScriptBakeVertexOptions, bSplitAtUVSeams) == 0x2, "Offset mismatch for FGeometryScriptBakeVertexOptions::bSplitAtUVSeams");
static_assert(offsetof(FGeometryScriptBakeVertexOptions, ProjectionDistance) == 0x4, "Offset mismatch for FGeometryScriptBakeVertexOptions::ProjectionDistance");
static_assert(offsetof(FGeometryScriptBakeVertexOptions, bProjectionInWorldSpace) == 0x8, "Offset mismatch for FGeometryScriptBakeVertexOptions::bProjectionInWorldSpace");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FGeometryScriptBakeOutputType
{
    uint8_t OutputMode; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FGeometryScriptBakeTypeOptions RGBA; // 0x8 (Size: 0x18, Type: StructProperty)
    FGeometryScriptBakeTypeOptions R; // 0x20 (Size: 0x18, Type: StructProperty)
    FGeometryScriptBakeTypeOptions G; // 0x38 (Size: 0x18, Type: StructProperty)
    FGeometryScriptBakeTypeOptions B; // 0x50 (Size: 0x18, Type: StructProperty)
    FGeometryScriptBakeTypeOptions A; // 0x68 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FGeometryScriptBakeOutputType) == 0x80, "Size mismatch for FGeometryScriptBakeOutputType");
static_assert(offsetof(FGeometryScriptBakeOutputType, OutputMode) == 0x0, "Offset mismatch for FGeometryScriptBakeOutputType::OutputMode");
static_assert(offsetof(FGeometryScriptBakeOutputType, RGBA) == 0x8, "Offset mismatch for FGeometryScriptBakeOutputType::RGBA");
static_assert(offsetof(FGeometryScriptBakeOutputType, R) == 0x20, "Offset mismatch for FGeometryScriptBakeOutputType::R");
static_assert(offsetof(FGeometryScriptBakeOutputType, G) == 0x38, "Offset mismatch for FGeometryScriptBakeOutputType::G");
static_assert(offsetof(FGeometryScriptBakeOutputType, B) == 0x50, "Offset mismatch for FGeometryScriptBakeOutputType::B");
static_assert(offsetof(FGeometryScriptBakeOutputType, A) == 0x68, "Offset mismatch for FGeometryScriptBakeOutputType::A");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGeometryScriptBakeTargetMeshOptions
{
    int32_t TargetUVLayer; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptBakeTargetMeshOptions) == 0x4, "Size mismatch for FGeometryScriptBakeTargetMeshOptions");
static_assert(offsetof(FGeometryScriptBakeTargetMeshOptions, TargetUVLayer) == 0x0, "Offset mismatch for FGeometryScriptBakeTargetMeshOptions::TargetUVLayer");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptBakeSourceMeshOptions
{
    UTexture2D* SourceNormalMap; // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t SourceNormalUVLayer; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t SourceNormalSpace; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptBakeSourceMeshOptions) == 0x10, "Size mismatch for FGeometryScriptBakeSourceMeshOptions");
static_assert(offsetof(FGeometryScriptBakeSourceMeshOptions, SourceNormalMap) == 0x0, "Offset mismatch for FGeometryScriptBakeSourceMeshOptions::SourceNormalMap");
static_assert(offsetof(FGeometryScriptBakeSourceMeshOptions, SourceNormalUVLayer) == 0x8, "Offset mismatch for FGeometryScriptBakeSourceMeshOptions::SourceNormalUVLayer");
static_assert(offsetof(FGeometryScriptBakeSourceMeshOptions, SourceNormalSpace) == 0xc, "Offset mismatch for FGeometryScriptBakeSourceMeshOptions::SourceNormalSpace");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FGeometryScriptBakeRenderCaptureOptions
{
    TArray<FGeometryScriptRenderCaptureCamera> Cameras; // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint8_t RenderCaptureResolution; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    double FieldOfViewDegrees; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double NearPlaneDist; // 0x20 (Size: 0x8, Type: DoubleProperty)
    uint8_t Resolution; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t SamplesPerPixel; // 0x29 (Size: 0x1, Type: EnumProperty)
    bool bRenderCaptureAntiAliasing; // 0x2a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b[0x1]; // 0x2b (Size: 0x1, Type: PaddingProperty)
    float CleanupTolerance; // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bBaseColorMap; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bNormalMap; // 0x31 (Size: 0x1, Type: BoolProperty)
    bool bPackedMRSMap; // 0x32 (Size: 0x1, Type: BoolProperty)
    bool bMetallicMap; // 0x33 (Size: 0x1, Type: BoolProperty)
    bool bRoughnessMap; // 0x34 (Size: 0x1, Type: BoolProperty)
    bool bSpecularMap; // 0x35 (Size: 0x1, Type: BoolProperty)
    bool bEmissiveMap; // 0x36 (Size: 0x1, Type: BoolProperty)
    bool bOpacityMap; // 0x37 (Size: 0x1, Type: BoolProperty)
    bool bSubsurfaceColorMap; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptBakeRenderCaptureOptions) == 0x40, "Size mismatch for FGeometryScriptBakeRenderCaptureOptions");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, Cameras) == 0x0, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::Cameras");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, RenderCaptureResolution) == 0x10, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::RenderCaptureResolution");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, FieldOfViewDegrees) == 0x18, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::FieldOfViewDegrees");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, NearPlaneDist) == 0x20, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::NearPlaneDist");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, Resolution) == 0x28, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::Resolution");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, SamplesPerPixel) == 0x29, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::SamplesPerPixel");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, bRenderCaptureAntiAliasing) == 0x2a, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::bRenderCaptureAntiAliasing");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, CleanupTolerance) == 0x2c, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::CleanupTolerance");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, bBaseColorMap) == 0x30, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::bBaseColorMap");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, bNormalMap) == 0x31, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::bNormalMap");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, bPackedMRSMap) == 0x32, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::bPackedMRSMap");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, bMetallicMap) == 0x33, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::bMetallicMap");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, bRoughnessMap) == 0x34, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::bRoughnessMap");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, bSpecularMap) == 0x35, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::bSpecularMap");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, bEmissiveMap) == 0x36, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::bEmissiveMap");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, bOpacityMap) == 0x37, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::bOpacityMap");
static_assert(offsetof(FGeometryScriptBakeRenderCaptureOptions, bSubsurfaceColorMap) == 0x38, "Offset mismatch for FGeometryScriptBakeRenderCaptureOptions::bSubsurfaceColorMap");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FGeometryScriptRenderCaptureTextures
{
    UTexture2D* BaseColorMap; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bHasBaseColorMap; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    UTexture2D* NormalMap; // 0x10 (Size: 0x8, Type: ObjectProperty)
    bool bHasNormalMap; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    UTexture2D* PackedMRSMap; // 0x20 (Size: 0x8, Type: ObjectProperty)
    bool bHasPackedMRSMap; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    UTexture2D* MetallicMap; // 0x30 (Size: 0x8, Type: ObjectProperty)
    bool bHasMetallicMap; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
    UTexture2D* RoughnessMap; // 0x40 (Size: 0x8, Type: ObjectProperty)
    bool bHasRoughnessMap; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
    UTexture2D* SpecularMap; // 0x50 (Size: 0x8, Type: ObjectProperty)
    bool bHasSpecularMap; // 0x58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
    UTexture2D* EmissiveMap; // 0x60 (Size: 0x8, Type: ObjectProperty)
    bool bHasEmissiveMap; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
    UTexture2D* OpacityMap; // 0x70 (Size: 0x8, Type: ObjectProperty)
    bool bHasOpacityMap; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
    UTexture2D* SubsurfaceColorMap; // 0x80 (Size: 0x8, Type: ObjectProperty)
    bool bHasSubsurfaceColorMap; // 0x88 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0x7]; // 0x89 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptRenderCaptureTextures) == 0x90, "Size mismatch for FGeometryScriptRenderCaptureTextures");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, BaseColorMap) == 0x0, "Offset mismatch for FGeometryScriptRenderCaptureTextures::BaseColorMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, bHasBaseColorMap) == 0x8, "Offset mismatch for FGeometryScriptRenderCaptureTextures::bHasBaseColorMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, NormalMap) == 0x10, "Offset mismatch for FGeometryScriptRenderCaptureTextures::NormalMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, bHasNormalMap) == 0x18, "Offset mismatch for FGeometryScriptRenderCaptureTextures::bHasNormalMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, PackedMRSMap) == 0x20, "Offset mismatch for FGeometryScriptRenderCaptureTextures::PackedMRSMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, bHasPackedMRSMap) == 0x28, "Offset mismatch for FGeometryScriptRenderCaptureTextures::bHasPackedMRSMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, MetallicMap) == 0x30, "Offset mismatch for FGeometryScriptRenderCaptureTextures::MetallicMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, bHasMetallicMap) == 0x38, "Offset mismatch for FGeometryScriptRenderCaptureTextures::bHasMetallicMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, RoughnessMap) == 0x40, "Offset mismatch for FGeometryScriptRenderCaptureTextures::RoughnessMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, bHasRoughnessMap) == 0x48, "Offset mismatch for FGeometryScriptRenderCaptureTextures::bHasRoughnessMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, SpecularMap) == 0x50, "Offset mismatch for FGeometryScriptRenderCaptureTextures::SpecularMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, bHasSpecularMap) == 0x58, "Offset mismatch for FGeometryScriptRenderCaptureTextures::bHasSpecularMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, EmissiveMap) == 0x60, "Offset mismatch for FGeometryScriptRenderCaptureTextures::EmissiveMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, bHasEmissiveMap) == 0x68, "Offset mismatch for FGeometryScriptRenderCaptureTextures::bHasEmissiveMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, OpacityMap) == 0x70, "Offset mismatch for FGeometryScriptRenderCaptureTextures::OpacityMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, bHasOpacityMap) == 0x78, "Offset mismatch for FGeometryScriptRenderCaptureTextures::bHasOpacityMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, SubsurfaceColorMap) == 0x80, "Offset mismatch for FGeometryScriptRenderCaptureTextures::SubsurfaceColorMap");
static_assert(offsetof(FGeometryScriptRenderCaptureTextures, bHasSubsurfaceColorMap) == 0x88, "Offset mismatch for FGeometryScriptRenderCaptureTextures::bHasSubsurfaceColorMap");

// Size: 0xd0 (Inherited: 0x0, Single: 0xd0)
struct FGeometryScriptSimpleMeshBuffers
{
    TArray<FVector> Vertices; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> Normals; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2D> UV0; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2D> UV1; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2D> UV2; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2D> UV3; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2D> UV4; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2D> UV5; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2D> UV6; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2D> UV7; // 0x90 (Size: 0x10, Type: ArrayProperty)
    TArray<FLinearColor> VertexColors; // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FIntVector> Triangles; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> TriGroupIDs; // 0xc0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGeometryScriptSimpleMeshBuffers) == 0xd0, "Size mismatch for FGeometryScriptSimpleMeshBuffers");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, Vertices) == 0x0, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::Vertices");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, Normals) == 0x10, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::Normals");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, UV0) == 0x20, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::UV0");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, UV1) == 0x30, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::UV1");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, UV2) == 0x40, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::UV2");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, UV3) == 0x50, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::UV3");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, UV4) == 0x60, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::UV4");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, UV5) == 0x70, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::UV5");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, UV6) == 0x80, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::UV6");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, UV7) == 0x90, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::UV7");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, VertexColors) == 0xa0, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::VertexColors");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, Triangles) == 0xb0, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::Triangles");
static_assert(offsetof(FGeometryScriptSimpleMeshBuffers, TriGroupIDs) == 0xc0, "Offset mismatch for FGeometryScriptSimpleMeshBuffers::TriGroupIDs");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGeometryScriptAppendMeshOptions
{
    uint8_t CombineMode; // 0x0 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FGeometryScriptAppendMeshOptions) == 0x1, "Size mismatch for FGeometryScriptAppendMeshOptions");
static_assert(offsetof(FGeometryScriptAppendMeshOptions, CombineMode) == 0x0, "Offset mismatch for FGeometryScriptAppendMeshOptions::CombineMode");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FGeometryScriptMergeVertexOptions
{
    bool bOnlyBoundary; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bAllowNonBoundaryBowties; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptMergeVertexOptions) == 0x2, "Size mismatch for FGeometryScriptMergeVertexOptions");
static_assert(offsetof(FGeometryScriptMergeVertexOptions, bOnlyBoundary) == 0x0, "Offset mismatch for FGeometryScriptMergeVertexOptions::bOnlyBoundary");
static_assert(offsetof(FGeometryScriptMergeVertexOptions, bAllowNonBoundaryBowties) == 0x1, "Offset mismatch for FGeometryScriptMergeVertexOptions::bAllowNonBoundaryBowties");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryScriptBoneWeight
{
    int32_t BoneIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    float Weight; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptBoneWeight) == 0x8, "Size mismatch for FGeometryScriptBoneWeight");
static_assert(offsetof(FGeometryScriptBoneWeight, BoneIndex) == 0x0, "Offset mismatch for FGeometryScriptBoneWeight::BoneIndex");
static_assert(offsetof(FGeometryScriptBoneWeight, Weight) == 0x4, "Offset mismatch for FGeometryScriptBoneWeight::Weight");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGeometryScriptBoneWeightProfile
{
    FName ProfileName; // 0x0 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FGeometryScriptBoneWeightProfile) == 0x4, "Size mismatch for FGeometryScriptBoneWeightProfile");
static_assert(offsetof(FGeometryScriptBoneWeightProfile, ProfileName) == 0x0, "Offset mismatch for FGeometryScriptBoneWeightProfile::ProfileName");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FGeometryScriptPruneBoneWeightsOptions
{
    uint8_t ReassignmentType; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bIgnoredInvalidBones; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptPruneBoneWeightsOptions) == 0x2, "Size mismatch for FGeometryScriptPruneBoneWeightsOptions");
static_assert(offsetof(FGeometryScriptPruneBoneWeightsOptions, ReassignmentType) == 0x0, "Offset mismatch for FGeometryScriptPruneBoneWeightsOptions::ReassignmentType");
static_assert(offsetof(FGeometryScriptPruneBoneWeightsOptions, bIgnoredInvalidBones) == 0x1, "Offset mismatch for FGeometryScriptPruneBoneWeightsOptions::bIgnoredInvalidBones");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptSmoothBoneWeightsOptions
{
    uint8_t DistanceWeighingType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float Stiffness; // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t MaxInfluences; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t VoxelResolution; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptSmoothBoneWeightsOptions) == 0x10, "Size mismatch for FGeometryScriptSmoothBoneWeightsOptions");
static_assert(offsetof(FGeometryScriptSmoothBoneWeightsOptions, DistanceWeighingType) == 0x0, "Offset mismatch for FGeometryScriptSmoothBoneWeightsOptions::DistanceWeighingType");
static_assert(offsetof(FGeometryScriptSmoothBoneWeightsOptions, Stiffness) == 0x4, "Offset mismatch for FGeometryScriptSmoothBoneWeightsOptions::Stiffness");
static_assert(offsetof(FGeometryScriptSmoothBoneWeightsOptions, MaxInfluences) == 0x8, "Offset mismatch for FGeometryScriptSmoothBoneWeightsOptions::MaxInfluences");
static_assert(offsetof(FGeometryScriptSmoothBoneWeightsOptions, VoxelResolution) == 0xc, "Offset mismatch for FGeometryScriptSmoothBoneWeightsOptions::VoxelResolution");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FGeometryScriptTransferBoneWeightsOptions
{
    uint8_t TransferMethod; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t OutputTargetMeshBones; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    FGeometryScriptBoneWeightProfile SourceProfile; // 0x4 (Size: 0x4, Type: StructProperty)
    FGeometryScriptBoneWeightProfile TargetProfile; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    double RadiusPercentage; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double NormalThreshold; // 0x18 (Size: 0x8, Type: DoubleProperty)
    bool LayeredMeshSupport; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x3]; // 0x21 (Size: 0x3, Type: PaddingProperty)
    int32_t NumSmoothingIterations; // 0x24 (Size: 0x4, Type: IntProperty)
    float SmoothingStrength; // 0x28 (Size: 0x4, Type: FloatProperty)
    FName InpaintMask; // 0x2c (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FGeometryScriptTransferBoneWeightsOptions) == 0x30, "Size mismatch for FGeometryScriptTransferBoneWeightsOptions");
static_assert(offsetof(FGeometryScriptTransferBoneWeightsOptions, TransferMethod) == 0x0, "Offset mismatch for FGeometryScriptTransferBoneWeightsOptions::TransferMethod");
static_assert(offsetof(FGeometryScriptTransferBoneWeightsOptions, OutputTargetMeshBones) == 0x1, "Offset mismatch for FGeometryScriptTransferBoneWeightsOptions::OutputTargetMeshBones");
static_assert(offsetof(FGeometryScriptTransferBoneWeightsOptions, SourceProfile) == 0x4, "Offset mismatch for FGeometryScriptTransferBoneWeightsOptions::SourceProfile");
static_assert(offsetof(FGeometryScriptTransferBoneWeightsOptions, TargetProfile) == 0x8, "Offset mismatch for FGeometryScriptTransferBoneWeightsOptions::TargetProfile");
static_assert(offsetof(FGeometryScriptTransferBoneWeightsOptions, RadiusPercentage) == 0x10, "Offset mismatch for FGeometryScriptTransferBoneWeightsOptions::RadiusPercentage");
static_assert(offsetof(FGeometryScriptTransferBoneWeightsOptions, NormalThreshold) == 0x18, "Offset mismatch for FGeometryScriptTransferBoneWeightsOptions::NormalThreshold");
static_assert(offsetof(FGeometryScriptTransferBoneWeightsOptions, LayeredMeshSupport) == 0x20, "Offset mismatch for FGeometryScriptTransferBoneWeightsOptions::LayeredMeshSupport");
static_assert(offsetof(FGeometryScriptTransferBoneWeightsOptions, NumSmoothingIterations) == 0x24, "Offset mismatch for FGeometryScriptTransferBoneWeightsOptions::NumSmoothingIterations");
static_assert(offsetof(FGeometryScriptTransferBoneWeightsOptions, SmoothingStrength) == 0x28, "Offset mismatch for FGeometryScriptTransferBoneWeightsOptions::SmoothingStrength");
static_assert(offsetof(FGeometryScriptTransferBoneWeightsOptions, InpaintMask) == 0x2c, "Offset mismatch for FGeometryScriptTransferBoneWeightsOptions::InpaintMask");

// Size: 0xe0 (Inherited: 0x0, Single: 0xe0)
struct FGeometryScriptBoneInfo
{
    int32_t Index; // 0x0 (Size: 0x4, Type: IntProperty)
    FName Name; // 0x4 (Size: 0x4, Type: NameProperty)
    int32_t ParentIndex; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FTransform LocalTransform; // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform WorldTransform; // 0x70 (Size: 0x60, Type: StructProperty)
    FLinearColor Color; // 0xd0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FGeometryScriptBoneInfo) == 0xe0, "Size mismatch for FGeometryScriptBoneInfo");
static_assert(offsetof(FGeometryScriptBoneInfo, Index) == 0x0, "Offset mismatch for FGeometryScriptBoneInfo::Index");
static_assert(offsetof(FGeometryScriptBoneInfo, Name) == 0x4, "Offset mismatch for FGeometryScriptBoneInfo::Name");
static_assert(offsetof(FGeometryScriptBoneInfo, ParentIndex) == 0x8, "Offset mismatch for FGeometryScriptBoneInfo::ParentIndex");
static_assert(offsetof(FGeometryScriptBoneInfo, LocalTransform) == 0x10, "Offset mismatch for FGeometryScriptBoneInfo::LocalTransform");
static_assert(offsetof(FGeometryScriptBoneInfo, WorldTransform) == 0x70, "Offset mismatch for FGeometryScriptBoneInfo::WorldTransform");
static_assert(offsetof(FGeometryScriptBoneInfo, Color) == 0xd0, "Offset mismatch for FGeometryScriptBoneInfo::Color");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FGeometryScriptCopyBonesFromMeshOptions
{
    bool ReindexWeights; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t BonesToCopyFromSource; // 0x1 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FGeometryScriptCopyBonesFromMeshOptions) == 0x2, "Size mismatch for FGeometryScriptCopyBonesFromMeshOptions");
static_assert(offsetof(FGeometryScriptCopyBonesFromMeshOptions, ReindexWeights) == 0x0, "Offset mismatch for FGeometryScriptCopyBonesFromMeshOptions::ReindexWeights");
static_assert(offsetof(FGeometryScriptCopyBonesFromMeshOptions, BonesToCopyFromSource) == 0x1, "Offset mismatch for FGeometryScriptCopyBonesFromMeshOptions::BonesToCopyFromSource");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptMeshBooleanOptions
{
    bool bFillHoles; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bSimplifyOutput; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    float SimplifyPlanarTolerance; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bAllowEmptyResult; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t OutputTransformSpace; // 0x9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a[0x2]; // 0xa (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptMeshBooleanOptions) == 0xc, "Size mismatch for FGeometryScriptMeshBooleanOptions");
static_assert(offsetof(FGeometryScriptMeshBooleanOptions, bFillHoles) == 0x0, "Offset mismatch for FGeometryScriptMeshBooleanOptions::bFillHoles");
static_assert(offsetof(FGeometryScriptMeshBooleanOptions, bSimplifyOutput) == 0x1, "Offset mismatch for FGeometryScriptMeshBooleanOptions::bSimplifyOutput");
static_assert(offsetof(FGeometryScriptMeshBooleanOptions, SimplifyPlanarTolerance) == 0x4, "Offset mismatch for FGeometryScriptMeshBooleanOptions::SimplifyPlanarTolerance");
static_assert(offsetof(FGeometryScriptMeshBooleanOptions, bAllowEmptyResult) == 0x8, "Offset mismatch for FGeometryScriptMeshBooleanOptions::bAllowEmptyResult");
static_assert(offsetof(FGeometryScriptMeshBooleanOptions, OutputTransformSpace) == 0x9, "Offset mismatch for FGeometryScriptMeshBooleanOptions::OutputTransformSpace");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptMeshSelfUnionOptions
{
    bool bFillHoles; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bTrimFlaps; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bSimplifyOutput; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    float SimplifyPlanarTolerance; // 0x4 (Size: 0x4, Type: FloatProperty)
    float WindingThreshold; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptMeshSelfUnionOptions) == 0xc, "Size mismatch for FGeometryScriptMeshSelfUnionOptions");
static_assert(offsetof(FGeometryScriptMeshSelfUnionOptions, bFillHoles) == 0x0, "Offset mismatch for FGeometryScriptMeshSelfUnionOptions::bFillHoles");
static_assert(offsetof(FGeometryScriptMeshSelfUnionOptions, bTrimFlaps) == 0x1, "Offset mismatch for FGeometryScriptMeshSelfUnionOptions::bTrimFlaps");
static_assert(offsetof(FGeometryScriptMeshSelfUnionOptions, bSimplifyOutput) == 0x2, "Offset mismatch for FGeometryScriptMeshSelfUnionOptions::bSimplifyOutput");
static_assert(offsetof(FGeometryScriptMeshSelfUnionOptions, SimplifyPlanarTolerance) == 0x4, "Offset mismatch for FGeometryScriptMeshSelfUnionOptions::SimplifyPlanarTolerance");
static_assert(offsetof(FGeometryScriptMeshSelfUnionOptions, WindingThreshold) == 0x8, "Offset mismatch for FGeometryScriptMeshSelfUnionOptions::WindingThreshold");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptMeshPlaneCutOptions
{
    bool bFillHoles; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t HoleFillMaterialID; // 0x4 (Size: 0x4, Type: IntProperty)
    bool bFillSpans; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bFlipCutSide; // 0x9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a[0x2]; // 0xa (Size: 0x2, Type: PaddingProperty)
    float UVWorldDimension; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptMeshPlaneCutOptions) == 0x10, "Size mismatch for FGeometryScriptMeshPlaneCutOptions");
static_assert(offsetof(FGeometryScriptMeshPlaneCutOptions, bFillHoles) == 0x0, "Offset mismatch for FGeometryScriptMeshPlaneCutOptions::bFillHoles");
static_assert(offsetof(FGeometryScriptMeshPlaneCutOptions, HoleFillMaterialID) == 0x4, "Offset mismatch for FGeometryScriptMeshPlaneCutOptions::HoleFillMaterialID");
static_assert(offsetof(FGeometryScriptMeshPlaneCutOptions, bFillSpans) == 0x8, "Offset mismatch for FGeometryScriptMeshPlaneCutOptions::bFillSpans");
static_assert(offsetof(FGeometryScriptMeshPlaneCutOptions, bFlipCutSide) == 0x9, "Offset mismatch for FGeometryScriptMeshPlaneCutOptions::bFlipCutSide");
static_assert(offsetof(FGeometryScriptMeshPlaneCutOptions, UVWorldDimension) == 0xc, "Offset mismatch for FGeometryScriptMeshPlaneCutOptions::UVWorldDimension");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FGeometryScriptMeshPlaneSliceOptions
{
    bool bFillHoles; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t HoleFillMaterialID; // 0x4 (Size: 0x4, Type: IntProperty)
    bool bFillSpans; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    float GapWidth; // 0xc (Size: 0x4, Type: FloatProperty)
    float UVWorldDimension; // 0x10 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptMeshPlaneSliceOptions) == 0x14, "Size mismatch for FGeometryScriptMeshPlaneSliceOptions");
static_assert(offsetof(FGeometryScriptMeshPlaneSliceOptions, bFillHoles) == 0x0, "Offset mismatch for FGeometryScriptMeshPlaneSliceOptions::bFillHoles");
static_assert(offsetof(FGeometryScriptMeshPlaneSliceOptions, HoleFillMaterialID) == 0x4, "Offset mismatch for FGeometryScriptMeshPlaneSliceOptions::HoleFillMaterialID");
static_assert(offsetof(FGeometryScriptMeshPlaneSliceOptions, bFillSpans) == 0x8, "Offset mismatch for FGeometryScriptMeshPlaneSliceOptions::bFillSpans");
static_assert(offsetof(FGeometryScriptMeshPlaneSliceOptions, GapWidth) == 0xc, "Offset mismatch for FGeometryScriptMeshPlaneSliceOptions::GapWidth");
static_assert(offsetof(FGeometryScriptMeshPlaneSliceOptions, UVWorldDimension) == 0x10, "Offset mismatch for FGeometryScriptMeshPlaneSliceOptions::UVWorldDimension");

// Size: 0x3 (Inherited: 0x0, Single: 0x3)
struct FGeometryScriptMeshMirrorOptions
{
    bool bApplyPlaneCut; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bFlipCutSide; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bWeldAlongPlane; // 0x2 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptMeshMirrorOptions) == 0x3, "Size mismatch for FGeometryScriptMeshMirrorOptions");
static_assert(offsetof(FGeometryScriptMeshMirrorOptions, bApplyPlaneCut) == 0x0, "Offset mismatch for FGeometryScriptMeshMirrorOptions::bApplyPlaneCut");
static_assert(offsetof(FGeometryScriptMeshMirrorOptions, bFlipCutSide) == 0x1, "Offset mismatch for FGeometryScriptMeshMirrorOptions::bFlipCutSide");
static_assert(offsetof(FGeometryScriptMeshMirrorOptions, bWeldAlongPlane) == 0x2, "Offset mismatch for FGeometryScriptMeshMirrorOptions::bWeldAlongPlane");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptIsSameMeshOptions
{
    bool bCheckConnectivity; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bCheckEdgeIDs; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bCheckNormals; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bCheckColors; // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bCheckUVs; // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bCheckGroups; // 0x5 (Size: 0x1, Type: BoolProperty)
    bool bCheckAttributes; // 0x6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7[0x1]; // 0x7 (Size: 0x1, Type: PaddingProperty)
    float Epsilon; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptIsSameMeshOptions) == 0xc, "Size mismatch for FGeometryScriptIsSameMeshOptions");
static_assert(offsetof(FGeometryScriptIsSameMeshOptions, bCheckConnectivity) == 0x0, "Offset mismatch for FGeometryScriptIsSameMeshOptions::bCheckConnectivity");
static_assert(offsetof(FGeometryScriptIsSameMeshOptions, bCheckEdgeIDs) == 0x1, "Offset mismatch for FGeometryScriptIsSameMeshOptions::bCheckEdgeIDs");
static_assert(offsetof(FGeometryScriptIsSameMeshOptions, bCheckNormals) == 0x2, "Offset mismatch for FGeometryScriptIsSameMeshOptions::bCheckNormals");
static_assert(offsetof(FGeometryScriptIsSameMeshOptions, bCheckColors) == 0x3, "Offset mismatch for FGeometryScriptIsSameMeshOptions::bCheckColors");
static_assert(offsetof(FGeometryScriptIsSameMeshOptions, bCheckUVs) == 0x4, "Offset mismatch for FGeometryScriptIsSameMeshOptions::bCheckUVs");
static_assert(offsetof(FGeometryScriptIsSameMeshOptions, bCheckGroups) == 0x5, "Offset mismatch for FGeometryScriptIsSameMeshOptions::bCheckGroups");
static_assert(offsetof(FGeometryScriptIsSameMeshOptions, bCheckAttributes) == 0x6, "Offset mismatch for FGeometryScriptIsSameMeshOptions::bCheckAttributes");
static_assert(offsetof(FGeometryScriptIsSameMeshOptions, Epsilon) == 0x8, "Offset mismatch for FGeometryScriptIsSameMeshOptions::Epsilon");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGeometryScriptMeasureMeshDistanceOptions
{
    bool bSymmetric; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptMeasureMeshDistanceOptions) == 0x1, "Size mismatch for FGeometryScriptMeasureMeshDistanceOptions");
static_assert(offsetof(FGeometryScriptMeasureMeshDistanceOptions, bSymmetric) == 0x0, "Offset mismatch for FGeometryScriptMeasureMeshDistanceOptions::bSymmetric");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGeometryScriptMeshDifferenceInfo
{
    uint8_t Reason; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FString Detail; // 0x8 (Size: 0x10, Type: StrProperty)
    int32_t TargetMeshElementID; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t OtherMeshElementID; // 0x1c (Size: 0x4, Type: IntProperty)
    uint8_t ElementIDType; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptMeshDifferenceInfo) == 0x28, "Size mismatch for FGeometryScriptMeshDifferenceInfo");
static_assert(offsetof(FGeometryScriptMeshDifferenceInfo, Reason) == 0x0, "Offset mismatch for FGeometryScriptMeshDifferenceInfo::Reason");
static_assert(offsetof(FGeometryScriptMeshDifferenceInfo, Detail) == 0x8, "Offset mismatch for FGeometryScriptMeshDifferenceInfo::Detail");
static_assert(offsetof(FGeometryScriptMeshDifferenceInfo, TargetMeshElementID) == 0x18, "Offset mismatch for FGeometryScriptMeshDifferenceInfo::TargetMeshElementID");
static_assert(offsetof(FGeometryScriptMeshDifferenceInfo, OtherMeshElementID) == 0x1c, "Offset mismatch for FGeometryScriptMeshDifferenceInfo::OtherMeshElementID");
static_assert(offsetof(FGeometryScriptMeshDifferenceInfo, ElementIDType) == 0x20, "Offset mismatch for FGeometryScriptMeshDifferenceInfo::ElementIDType");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptBendWarpOptions
{
    bool bSymmetricExtents; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float LowerExtent; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bBidirectional; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptBendWarpOptions) == 0xc, "Size mismatch for FGeometryScriptBendWarpOptions");
static_assert(offsetof(FGeometryScriptBendWarpOptions, bSymmetricExtents) == 0x0, "Offset mismatch for FGeometryScriptBendWarpOptions::bSymmetricExtents");
static_assert(offsetof(FGeometryScriptBendWarpOptions, LowerExtent) == 0x4, "Offset mismatch for FGeometryScriptBendWarpOptions::LowerExtent");
static_assert(offsetof(FGeometryScriptBendWarpOptions, bBidirectional) == 0x8, "Offset mismatch for FGeometryScriptBendWarpOptions::bBidirectional");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptTwistWarpOptions
{
    bool bSymmetricExtents; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float LowerExtent; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bBidirectional; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptTwistWarpOptions) == 0xc, "Size mismatch for FGeometryScriptTwistWarpOptions");
static_assert(offsetof(FGeometryScriptTwistWarpOptions, bSymmetricExtents) == 0x0, "Offset mismatch for FGeometryScriptTwistWarpOptions::bSymmetricExtents");
static_assert(offsetof(FGeometryScriptTwistWarpOptions, LowerExtent) == 0x4, "Offset mismatch for FGeometryScriptTwistWarpOptions::LowerExtent");
static_assert(offsetof(FGeometryScriptTwistWarpOptions, bBidirectional) == 0x8, "Offset mismatch for FGeometryScriptTwistWarpOptions::bBidirectional");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptFlareWarpOptions
{
    bool bSymmetricExtents; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float LowerExtent; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t FlareType; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptFlareWarpOptions) == 0xc, "Size mismatch for FGeometryScriptFlareWarpOptions");
static_assert(offsetof(FGeometryScriptFlareWarpOptions, bSymmetricExtents) == 0x0, "Offset mismatch for FGeometryScriptFlareWarpOptions::bSymmetricExtents");
static_assert(offsetof(FGeometryScriptFlareWarpOptions, LowerExtent) == 0x4, "Offset mismatch for FGeometryScriptFlareWarpOptions::LowerExtent");
static_assert(offsetof(FGeometryScriptFlareWarpOptions, FlareType) == 0x8, "Offset mismatch for FGeometryScriptFlareWarpOptions::FlareType");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGeometryScriptPerlinNoiseLayerOptions
{
    float Magnitude; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Frequency; // 0x4 (Size: 0x4, Type: FloatProperty)
    FVector FrequencyShift; // 0x8 (Size: 0x18, Type: StructProperty)
    int32_t RandomSeed; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptPerlinNoiseLayerOptions) == 0x28, "Size mismatch for FGeometryScriptPerlinNoiseLayerOptions");
static_assert(offsetof(FGeometryScriptPerlinNoiseLayerOptions, Magnitude) == 0x0, "Offset mismatch for FGeometryScriptPerlinNoiseLayerOptions::Magnitude");
static_assert(offsetof(FGeometryScriptPerlinNoiseLayerOptions, Frequency) == 0x4, "Offset mismatch for FGeometryScriptPerlinNoiseLayerOptions::Frequency");
static_assert(offsetof(FGeometryScriptPerlinNoiseLayerOptions, FrequencyShift) == 0x8, "Offset mismatch for FGeometryScriptPerlinNoiseLayerOptions::FrequencyShift");
static_assert(offsetof(FGeometryScriptPerlinNoiseLayerOptions, RandomSeed) == 0x20, "Offset mismatch for FGeometryScriptPerlinNoiseLayerOptions::RandomSeed");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptMathWarpOptions
{
    float Magnitude; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Frequency; // 0x4 (Size: 0x4, Type: FloatProperty)
    float FrequencyShift; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptMathWarpOptions) == 0xc, "Size mismatch for FGeometryScriptMathWarpOptions");
static_assert(offsetof(FGeometryScriptMathWarpOptions, Magnitude) == 0x0, "Offset mismatch for FGeometryScriptMathWarpOptions::Magnitude");
static_assert(offsetof(FGeometryScriptMathWarpOptions, Frequency) == 0x4, "Offset mismatch for FGeometryScriptMathWarpOptions::Frequency");
static_assert(offsetof(FGeometryScriptMathWarpOptions, FrequencyShift) == 0x8, "Offset mismatch for FGeometryScriptMathWarpOptions::FrequencyShift");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FGeometryScriptPerlinNoiseOptions
{
    FGeometryScriptPerlinNoiseLayerOptions BaseLayer; // 0x0 (Size: 0x28, Type: StructProperty)
    bool bApplyAlongNormal; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t EmptyBehavior; // 0x29 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2a[0x6]; // 0x2a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptPerlinNoiseOptions) == 0x30, "Size mismatch for FGeometryScriptPerlinNoiseOptions");
static_assert(offsetof(FGeometryScriptPerlinNoiseOptions, BaseLayer) == 0x0, "Offset mismatch for FGeometryScriptPerlinNoiseOptions::BaseLayer");
static_assert(offsetof(FGeometryScriptPerlinNoiseOptions, bApplyAlongNormal) == 0x28, "Offset mismatch for FGeometryScriptPerlinNoiseOptions::bApplyAlongNormal");
static_assert(offsetof(FGeometryScriptPerlinNoiseOptions, EmptyBehavior) == 0x29, "Offset mismatch for FGeometryScriptPerlinNoiseOptions::EmptyBehavior");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptIterativeMeshSmoothingOptions
{
    int32_t NumIterations; // 0x0 (Size: 0x4, Type: IntProperty)
    float Alpha; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t EmptyBehavior; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptIterativeMeshSmoothingOptions) == 0xc, "Size mismatch for FGeometryScriptIterativeMeshSmoothingOptions");
static_assert(offsetof(FGeometryScriptIterativeMeshSmoothingOptions, NumIterations) == 0x0, "Offset mismatch for FGeometryScriptIterativeMeshSmoothingOptions::NumIterations");
static_assert(offsetof(FGeometryScriptIterativeMeshSmoothingOptions, Alpha) == 0x4, "Offset mismatch for FGeometryScriptIterativeMeshSmoothingOptions::Alpha");
static_assert(offsetof(FGeometryScriptIterativeMeshSmoothingOptions, EmptyBehavior) == 0x8, "Offset mismatch for FGeometryScriptIterativeMeshSmoothingOptions::EmptyBehavior");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FGeometryScriptDisplaceFromTextureOptions
{
    float Magnitude; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector2D UVScale; // 0x8 (Size: 0x10, Type: StructProperty)
    FVector2D UVOffset; // 0x18 (Size: 0x10, Type: StructProperty)
    float Center; // 0x28 (Size: 0x4, Type: FloatProperty)
    int32_t ImageChannel; // 0x2c (Size: 0x4, Type: IntProperty)
    uint8_t EmptyBehavior; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptDisplaceFromTextureOptions) == 0x38, "Size mismatch for FGeometryScriptDisplaceFromTextureOptions");
static_assert(offsetof(FGeometryScriptDisplaceFromTextureOptions, Magnitude) == 0x0, "Offset mismatch for FGeometryScriptDisplaceFromTextureOptions::Magnitude");
static_assert(offsetof(FGeometryScriptDisplaceFromTextureOptions, UVScale) == 0x8, "Offset mismatch for FGeometryScriptDisplaceFromTextureOptions::UVScale");
static_assert(offsetof(FGeometryScriptDisplaceFromTextureOptions, UVOffset) == 0x18, "Offset mismatch for FGeometryScriptDisplaceFromTextureOptions::UVOffset");
static_assert(offsetof(FGeometryScriptDisplaceFromTextureOptions, Center) == 0x28, "Offset mismatch for FGeometryScriptDisplaceFromTextureOptions::Center");
static_assert(offsetof(FGeometryScriptDisplaceFromTextureOptions, ImageChannel) == 0x2c, "Offset mismatch for FGeometryScriptDisplaceFromTextureOptions::ImageChannel");
static_assert(offsetof(FGeometryScriptDisplaceFromTextureOptions, EmptyBehavior) == 0x30, "Offset mismatch for FGeometryScriptDisplaceFromTextureOptions::EmptyBehavior");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryScriptMeshEditPolygroupOptions
{
    uint8_t GroupMode; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t ConstantGroup; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptMeshEditPolygroupOptions) == 0x8, "Size mismatch for FGeometryScriptMeshEditPolygroupOptions");
static_assert(offsetof(FGeometryScriptMeshEditPolygroupOptions, GroupMode) == 0x0, "Offset mismatch for FGeometryScriptMeshEditPolygroupOptions::GroupMode");
static_assert(offsetof(FGeometryScriptMeshEditPolygroupOptions, ConstantGroup) == 0x4, "Offset mismatch for FGeometryScriptMeshEditPolygroupOptions::ConstantGroup");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGeometryScriptMeshOffsetOptions
{
    float OffsetDistance; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bFixedBoundary; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    int32_t SolveSteps; // 0x8 (Size: 0x4, Type: IntProperty)
    float SmoothAlpha; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bReprojectDuringSmoothing; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float BoundaryAlpha; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptMeshOffsetOptions) == 0x18, "Size mismatch for FGeometryScriptMeshOffsetOptions");
static_assert(offsetof(FGeometryScriptMeshOffsetOptions, OffsetDistance) == 0x0, "Offset mismatch for FGeometryScriptMeshOffsetOptions::OffsetDistance");
static_assert(offsetof(FGeometryScriptMeshOffsetOptions, bFixedBoundary) == 0x4, "Offset mismatch for FGeometryScriptMeshOffsetOptions::bFixedBoundary");
static_assert(offsetof(FGeometryScriptMeshOffsetOptions, SolveSteps) == 0x8, "Offset mismatch for FGeometryScriptMeshOffsetOptions::SolveSteps");
static_assert(offsetof(FGeometryScriptMeshOffsetOptions, SmoothAlpha) == 0xc, "Offset mismatch for FGeometryScriptMeshOffsetOptions::SmoothAlpha");
static_assert(offsetof(FGeometryScriptMeshOffsetOptions, bReprojectDuringSmoothing) == 0x10, "Offset mismatch for FGeometryScriptMeshOffsetOptions::bReprojectDuringSmoothing");
static_assert(offsetof(FGeometryScriptMeshOffsetOptions, BoundaryAlpha) == 0x14, "Offset mismatch for FGeometryScriptMeshOffsetOptions::BoundaryAlpha");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGeometryScriptMeshExtrudeOptions
{
    float ExtrudeDistance; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector ExtrudeDirection; // 0x8 (Size: 0x18, Type: StructProperty)
    float UVScale; // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bSolidsToShells; // 0x24 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_25[0x3]; // 0x25 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptMeshExtrudeOptions) == 0x28, "Size mismatch for FGeometryScriptMeshExtrudeOptions");
static_assert(offsetof(FGeometryScriptMeshExtrudeOptions, ExtrudeDistance) == 0x0, "Offset mismatch for FGeometryScriptMeshExtrudeOptions::ExtrudeDistance");
static_assert(offsetof(FGeometryScriptMeshExtrudeOptions, ExtrudeDirection) == 0x8, "Offset mismatch for FGeometryScriptMeshExtrudeOptions::ExtrudeDirection");
static_assert(offsetof(FGeometryScriptMeshExtrudeOptions, UVScale) == 0x20, "Offset mismatch for FGeometryScriptMeshExtrudeOptions::UVScale");
static_assert(offsetof(FGeometryScriptMeshExtrudeOptions, bSolidsToShells) == 0x24, "Offset mismatch for FGeometryScriptMeshExtrudeOptions::bSolidsToShells");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FGeometryScriptMeshLinearExtrudeOptions
{
    float Distance; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t DirectionMode; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FVector Direction; // 0x8 (Size: 0x18, Type: StructProperty)
    uint8_t AreaMode; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x3]; // 0x21 (Size: 0x3, Type: PaddingProperty)
    FGeometryScriptMeshEditPolygroupOptions GroupOptions; // 0x24 (Size: 0x8, Type: StructProperty)
    float UVScale; // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bSolidsToShells; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptMeshLinearExtrudeOptions) == 0x38, "Size mismatch for FGeometryScriptMeshLinearExtrudeOptions");
static_assert(offsetof(FGeometryScriptMeshLinearExtrudeOptions, Distance) == 0x0, "Offset mismatch for FGeometryScriptMeshLinearExtrudeOptions::Distance");
static_assert(offsetof(FGeometryScriptMeshLinearExtrudeOptions, DirectionMode) == 0x4, "Offset mismatch for FGeometryScriptMeshLinearExtrudeOptions::DirectionMode");
static_assert(offsetof(FGeometryScriptMeshLinearExtrudeOptions, Direction) == 0x8, "Offset mismatch for FGeometryScriptMeshLinearExtrudeOptions::Direction");
static_assert(offsetof(FGeometryScriptMeshLinearExtrudeOptions, AreaMode) == 0x20, "Offset mismatch for FGeometryScriptMeshLinearExtrudeOptions::AreaMode");
static_assert(offsetof(FGeometryScriptMeshLinearExtrudeOptions, GroupOptions) == 0x24, "Offset mismatch for FGeometryScriptMeshLinearExtrudeOptions::GroupOptions");
static_assert(offsetof(FGeometryScriptMeshLinearExtrudeOptions, UVScale) == 0x2c, "Offset mismatch for FGeometryScriptMeshLinearExtrudeOptions::UVScale");
static_assert(offsetof(FGeometryScriptMeshLinearExtrudeOptions, bSolidsToShells) == 0x30, "Offset mismatch for FGeometryScriptMeshLinearExtrudeOptions::bSolidsToShells");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGeometryScriptMeshOffsetFacesOptions
{
    float Distance; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t OffsetType; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t AreaMode; // 0x5 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_6[0x2]; // 0x6 (Size: 0x2, Type: PaddingProperty)
    FGeometryScriptMeshEditPolygroupOptions GroupOptions; // 0x8 (Size: 0x8, Type: StructProperty)
    float UVScale; // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bSolidsToShells; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptMeshOffsetFacesOptions) == 0x18, "Size mismatch for FGeometryScriptMeshOffsetFacesOptions");
static_assert(offsetof(FGeometryScriptMeshOffsetFacesOptions, Distance) == 0x0, "Offset mismatch for FGeometryScriptMeshOffsetFacesOptions::Distance");
static_assert(offsetof(FGeometryScriptMeshOffsetFacesOptions, OffsetType) == 0x4, "Offset mismatch for FGeometryScriptMeshOffsetFacesOptions::OffsetType");
static_assert(offsetof(FGeometryScriptMeshOffsetFacesOptions, AreaMode) == 0x5, "Offset mismatch for FGeometryScriptMeshOffsetFacesOptions::AreaMode");
static_assert(offsetof(FGeometryScriptMeshOffsetFacesOptions, GroupOptions) == 0x8, "Offset mismatch for FGeometryScriptMeshOffsetFacesOptions::GroupOptions");
static_assert(offsetof(FGeometryScriptMeshOffsetFacesOptions, UVScale) == 0x10, "Offset mismatch for FGeometryScriptMeshOffsetFacesOptions::UVScale");
static_assert(offsetof(FGeometryScriptMeshOffsetFacesOptions, bSolidsToShells) == 0x14, "Offset mismatch for FGeometryScriptMeshOffsetFacesOptions::bSolidsToShells");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGeometryScriptMeshInsetOutsetFacesOptions
{
    float Distance; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bReproject; // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bBoundaryOnly; // 0x5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6[0x2]; // 0x6 (Size: 0x2, Type: PaddingProperty)
    float Softness; // 0x8 (Size: 0x4, Type: FloatProperty)
    float AreaScale; // 0xc (Size: 0x4, Type: FloatProperty)
    uint8_t AreaMode; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    FGeometryScriptMeshEditPolygroupOptions GroupOptions; // 0x14 (Size: 0x8, Type: StructProperty)
    float UVScale; // 0x1c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptMeshInsetOutsetFacesOptions) == 0x20, "Size mismatch for FGeometryScriptMeshInsetOutsetFacesOptions");
static_assert(offsetof(FGeometryScriptMeshInsetOutsetFacesOptions, Distance) == 0x0, "Offset mismatch for FGeometryScriptMeshInsetOutsetFacesOptions::Distance");
static_assert(offsetof(FGeometryScriptMeshInsetOutsetFacesOptions, bReproject) == 0x4, "Offset mismatch for FGeometryScriptMeshInsetOutsetFacesOptions::bReproject");
static_assert(offsetof(FGeometryScriptMeshInsetOutsetFacesOptions, bBoundaryOnly) == 0x5, "Offset mismatch for FGeometryScriptMeshInsetOutsetFacesOptions::bBoundaryOnly");
static_assert(offsetof(FGeometryScriptMeshInsetOutsetFacesOptions, Softness) == 0x8, "Offset mismatch for FGeometryScriptMeshInsetOutsetFacesOptions::Softness");
static_assert(offsetof(FGeometryScriptMeshInsetOutsetFacesOptions, AreaScale) == 0xc, "Offset mismatch for FGeometryScriptMeshInsetOutsetFacesOptions::AreaScale");
static_assert(offsetof(FGeometryScriptMeshInsetOutsetFacesOptions, AreaMode) == 0x10, "Offset mismatch for FGeometryScriptMeshInsetOutsetFacesOptions::AreaMode");
static_assert(offsetof(FGeometryScriptMeshInsetOutsetFacesOptions, GroupOptions) == 0x14, "Offset mismatch for FGeometryScriptMeshInsetOutsetFacesOptions::GroupOptions");
static_assert(offsetof(FGeometryScriptMeshInsetOutsetFacesOptions, UVScale) == 0x1c, "Offset mismatch for FGeometryScriptMeshInsetOutsetFacesOptions::UVScale");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FGeometryScriptMeshBevelOptions
{
    float BevelDistance; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bInferMaterialID; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    int32_t SetMaterialID; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t Subdivisions; // 0xc (Size: 0x4, Type: IntProperty)
    float RoundWeight; // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bApplyFilterBox; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    FBox FilterBox; // 0x18 (Size: 0x38, Type: StructProperty)
    FTransform FilterBoxTransform; // 0x50 (Size: 0x60, Type: StructProperty)
    bool bFullyContained; // 0xb0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b1[0xf]; // 0xb1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptMeshBevelOptions) == 0xc0, "Size mismatch for FGeometryScriptMeshBevelOptions");
static_assert(offsetof(FGeometryScriptMeshBevelOptions, BevelDistance) == 0x0, "Offset mismatch for FGeometryScriptMeshBevelOptions::BevelDistance");
static_assert(offsetof(FGeometryScriptMeshBevelOptions, bInferMaterialID) == 0x4, "Offset mismatch for FGeometryScriptMeshBevelOptions::bInferMaterialID");
static_assert(offsetof(FGeometryScriptMeshBevelOptions, SetMaterialID) == 0x8, "Offset mismatch for FGeometryScriptMeshBevelOptions::SetMaterialID");
static_assert(offsetof(FGeometryScriptMeshBevelOptions, Subdivisions) == 0xc, "Offset mismatch for FGeometryScriptMeshBevelOptions::Subdivisions");
static_assert(offsetof(FGeometryScriptMeshBevelOptions, RoundWeight) == 0x10, "Offset mismatch for FGeometryScriptMeshBevelOptions::RoundWeight");
static_assert(offsetof(FGeometryScriptMeshBevelOptions, bApplyFilterBox) == 0x14, "Offset mismatch for FGeometryScriptMeshBevelOptions::bApplyFilterBox");
static_assert(offsetof(FGeometryScriptMeshBevelOptions, FilterBox) == 0x18, "Offset mismatch for FGeometryScriptMeshBevelOptions::FilterBox");
static_assert(offsetof(FGeometryScriptMeshBevelOptions, FilterBoxTransform) == 0x50, "Offset mismatch for FGeometryScriptMeshBevelOptions::FilterBoxTransform");
static_assert(offsetof(FGeometryScriptMeshBevelOptions, bFullyContained) == 0xb0, "Offset mismatch for FGeometryScriptMeshBevelOptions::bFullyContained");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FGeometryScriptMeshBevelSelectionOptions
{
    float BevelDistance; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bInferMaterialID; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    int32_t SetMaterialID; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t Subdivisions; // 0xc (Size: 0x4, Type: IntProperty)
    float RoundWeight; // 0x10 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptMeshBevelSelectionOptions) == 0x14, "Size mismatch for FGeometryScriptMeshBevelSelectionOptions");
static_assert(offsetof(FGeometryScriptMeshBevelSelectionOptions, BevelDistance) == 0x0, "Offset mismatch for FGeometryScriptMeshBevelSelectionOptions::BevelDistance");
static_assert(offsetof(FGeometryScriptMeshBevelSelectionOptions, bInferMaterialID) == 0x4, "Offset mismatch for FGeometryScriptMeshBevelSelectionOptions::bInferMaterialID");
static_assert(offsetof(FGeometryScriptMeshBevelSelectionOptions, SetMaterialID) == 0x8, "Offset mismatch for FGeometryScriptMeshBevelSelectionOptions::SetMaterialID");
static_assert(offsetof(FGeometryScriptMeshBevelSelectionOptions, Subdivisions) == 0xc, "Offset mismatch for FGeometryScriptMeshBevelSelectionOptions::Subdivisions");
static_assert(offsetof(FGeometryScriptMeshBevelSelectionOptions, RoundWeight) == 0x10, "Offset mismatch for FGeometryScriptMeshBevelSelectionOptions::RoundWeight");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FGeometryScriptCalculateNormalsOptions
{
    bool bAngleWeighted; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bAreaWeighted; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptCalculateNormalsOptions) == 0x2, "Size mismatch for FGeometryScriptCalculateNormalsOptions");
static_assert(offsetof(FGeometryScriptCalculateNormalsOptions, bAngleWeighted) == 0x0, "Offset mismatch for FGeometryScriptCalculateNormalsOptions::bAngleWeighted");
static_assert(offsetof(FGeometryScriptCalculateNormalsOptions, bAreaWeighted) == 0x1, "Offset mismatch for FGeometryScriptCalculateNormalsOptions::bAreaWeighted");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FGeometryScriptSplitNormalsOptions
{
    bool bSplitByOpeningAngle; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float OpeningAngleDeg; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bSplitByFaceGroup; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    FGeometryScriptGroupLayer GroupLayer; // 0xc (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FGeometryScriptSplitNormalsOptions) == 0x14, "Size mismatch for FGeometryScriptSplitNormalsOptions");
static_assert(offsetof(FGeometryScriptSplitNormalsOptions, bSplitByOpeningAngle) == 0x0, "Offset mismatch for FGeometryScriptSplitNormalsOptions::bSplitByOpeningAngle");
static_assert(offsetof(FGeometryScriptSplitNormalsOptions, OpeningAngleDeg) == 0x4, "Offset mismatch for FGeometryScriptSplitNormalsOptions::OpeningAngleDeg");
static_assert(offsetof(FGeometryScriptSplitNormalsOptions, bSplitByFaceGroup) == 0x8, "Offset mismatch for FGeometryScriptSplitNormalsOptions::bSplitByFaceGroup");
static_assert(offsetof(FGeometryScriptSplitNormalsOptions, GroupLayer) == 0xc, "Offset mismatch for FGeometryScriptSplitNormalsOptions::GroupLayer");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryScriptTangentsOptions
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t UVLayer; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptTangentsOptions) == 0x8, "Size mismatch for FGeometryScriptTangentsOptions");
static_assert(offsetof(FGeometryScriptTangentsOptions, Type) == 0x0, "Offset mismatch for FGeometryScriptTangentsOptions::Type");
static_assert(offsetof(FGeometryScriptTangentsOptions, UVLayer) == 0x4, "Offset mismatch for FGeometryScriptTangentsOptions::UVLayer");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryScriptPrimitiveOptions
{
    uint8_t PolygroupMode; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bFlipOrientation; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t UVMode; // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    int32_t MaterialID; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptPrimitiveOptions) == 0x8, "Size mismatch for FGeometryScriptPrimitiveOptions");
static_assert(offsetof(FGeometryScriptPrimitiveOptions, PolygroupMode) == 0x0, "Offset mismatch for FGeometryScriptPrimitiveOptions::PolygroupMode");
static_assert(offsetof(FGeometryScriptPrimitiveOptions, bFlipOrientation) == 0x1, "Offset mismatch for FGeometryScriptPrimitiveOptions::bFlipOrientation");
static_assert(offsetof(FGeometryScriptPrimitiveOptions, UVMode) == 0x2, "Offset mismatch for FGeometryScriptPrimitiveOptions::UVMode");
static_assert(offsetof(FGeometryScriptPrimitiveOptions, MaterialID) == 0x4, "Offset mismatch for FGeometryScriptPrimitiveOptions::MaterialID");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FGeometryScriptRevolveOptions
{
    float RevolveDegrees; // 0x0 (Size: 0x4, Type: FloatProperty)
    float DegreeOffset; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bReverseDirection; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bHardNormals; // 0x9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a[0x2]; // 0xa (Size: 0x2, Type: PaddingProperty)
    float HardNormalAngle; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bProfileAtMidpoint; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bFillPartialRevolveEndcaps; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x2]; // 0x12 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptRevolveOptions) == 0x14, "Size mismatch for FGeometryScriptRevolveOptions");
static_assert(offsetof(FGeometryScriptRevolveOptions, RevolveDegrees) == 0x0, "Offset mismatch for FGeometryScriptRevolveOptions::RevolveDegrees");
static_assert(offsetof(FGeometryScriptRevolveOptions, DegreeOffset) == 0x4, "Offset mismatch for FGeometryScriptRevolveOptions::DegreeOffset");
static_assert(offsetof(FGeometryScriptRevolveOptions, bReverseDirection) == 0x8, "Offset mismatch for FGeometryScriptRevolveOptions::bReverseDirection");
static_assert(offsetof(FGeometryScriptRevolveOptions, bHardNormals) == 0x9, "Offset mismatch for FGeometryScriptRevolveOptions::bHardNormals");
static_assert(offsetof(FGeometryScriptRevolveOptions, HardNormalAngle) == 0xc, "Offset mismatch for FGeometryScriptRevolveOptions::HardNormalAngle");
static_assert(offsetof(FGeometryScriptRevolveOptions, bProfileAtMidpoint) == 0x10, "Offset mismatch for FGeometryScriptRevolveOptions::bProfileAtMidpoint");
static_assert(offsetof(FGeometryScriptRevolveOptions, bFillPartialRevolveEndcaps) == 0x11, "Offset mismatch for FGeometryScriptRevolveOptions::bFillPartialRevolveEndcaps");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FGeometryScriptVoronoiOptions
{
    float BoundsExpand; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FBox Bounds; // 0x8 (Size: 0x38, Type: StructProperty)
    TArray<int32_t> CreateCells; // 0x40 (Size: 0x10, Type: ArrayProperty)
    bool bIncludeBoundary; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptVoronoiOptions) == 0x58, "Size mismatch for FGeometryScriptVoronoiOptions");
static_assert(offsetof(FGeometryScriptVoronoiOptions, BoundsExpand) == 0x0, "Offset mismatch for FGeometryScriptVoronoiOptions::BoundsExpand");
static_assert(offsetof(FGeometryScriptVoronoiOptions, Bounds) == 0x8, "Offset mismatch for FGeometryScriptVoronoiOptions::Bounds");
static_assert(offsetof(FGeometryScriptVoronoiOptions, CreateCells) == 0x40, "Offset mismatch for FGeometryScriptVoronoiOptions::CreateCells");
static_assert(offsetof(FGeometryScriptVoronoiOptions, bIncludeBoundary) == 0x50, "Offset mismatch for FGeometryScriptVoronoiOptions::bIncludeBoundary");

// Size: 0x3 (Inherited: 0x0, Single: 0x3)
struct FGeometryScriptConstrainedDelaunayTriangulationOptions
{
    uint8_t ConstrainedEdgesFillMode; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bValidateEdgesInResult; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bRemoveDuplicateVertices; // 0x2 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptConstrainedDelaunayTriangulationOptions) == 0x3, "Size mismatch for FGeometryScriptConstrainedDelaunayTriangulationOptions");
static_assert(offsetof(FGeometryScriptConstrainedDelaunayTriangulationOptions, ConstrainedEdgesFillMode) == 0x0, "Offset mismatch for FGeometryScriptConstrainedDelaunayTriangulationOptions::ConstrainedEdgesFillMode");
static_assert(offsetof(FGeometryScriptConstrainedDelaunayTriangulationOptions, bValidateEdgesInResult) == 0x1, "Offset mismatch for FGeometryScriptConstrainedDelaunayTriangulationOptions::bValidateEdgesInResult");
static_assert(offsetof(FGeometryScriptConstrainedDelaunayTriangulationOptions, bRemoveDuplicateVertices) == 0x2, "Offset mismatch for FGeometryScriptConstrainedDelaunayTriangulationOptions::bRemoveDuplicateVertices");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGeometryScriptPolygonsTriangulationOptions
{
    bool bStillAppendOnTriangulationError; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptPolygonsTriangulationOptions) == 0x1, "Size mismatch for FGeometryScriptPolygonsTriangulationOptions");
static_assert(offsetof(FGeometryScriptPolygonsTriangulationOptions, bStillAppendOnTriangulationError) == 0x0, "Offset mismatch for FGeometryScriptPolygonsTriangulationOptions::bStillAppendOnTriangulationError");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FGeometryScriptRemeshOptions
{
    bool bDiscardAttributes; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bReprojectToInputMesh; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t SmoothingType; // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    float SmoothingRate; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t MeshBoundaryConstraint; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t GroupBoundaryConstraint; // 0x9 (Size: 0x1, Type: EnumProperty)
    uint8_t MaterialBoundaryConstraint; // 0xa (Size: 0x1, Type: EnumProperty)
    bool bAllowFlips; // 0xb (Size: 0x1, Type: BoolProperty)
    bool bAllowSplits; // 0xc (Size: 0x1, Type: BoolProperty)
    bool bAllowCollapses; // 0xd (Size: 0x1, Type: BoolProperty)
    bool bPreventNormalFlips; // 0xe (Size: 0x1, Type: BoolProperty)
    bool bPreventTinyTriangles; // 0xf (Size: 0x1, Type: BoolProperty)
    bool bUseFullRemeshPasses; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    int32_t RemeshIterations; // 0x14 (Size: 0x4, Type: IntProperty)
    bool bAutoCompact; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptRemeshOptions) == 0x1c, "Size mismatch for FGeometryScriptRemeshOptions");
static_assert(offsetof(FGeometryScriptRemeshOptions, bDiscardAttributes) == 0x0, "Offset mismatch for FGeometryScriptRemeshOptions::bDiscardAttributes");
static_assert(offsetof(FGeometryScriptRemeshOptions, bReprojectToInputMesh) == 0x1, "Offset mismatch for FGeometryScriptRemeshOptions::bReprojectToInputMesh");
static_assert(offsetof(FGeometryScriptRemeshOptions, SmoothingType) == 0x2, "Offset mismatch for FGeometryScriptRemeshOptions::SmoothingType");
static_assert(offsetof(FGeometryScriptRemeshOptions, SmoothingRate) == 0x4, "Offset mismatch for FGeometryScriptRemeshOptions::SmoothingRate");
static_assert(offsetof(FGeometryScriptRemeshOptions, MeshBoundaryConstraint) == 0x8, "Offset mismatch for FGeometryScriptRemeshOptions::MeshBoundaryConstraint");
static_assert(offsetof(FGeometryScriptRemeshOptions, GroupBoundaryConstraint) == 0x9, "Offset mismatch for FGeometryScriptRemeshOptions::GroupBoundaryConstraint");
static_assert(offsetof(FGeometryScriptRemeshOptions, MaterialBoundaryConstraint) == 0xa, "Offset mismatch for FGeometryScriptRemeshOptions::MaterialBoundaryConstraint");
static_assert(offsetof(FGeometryScriptRemeshOptions, bAllowFlips) == 0xb, "Offset mismatch for FGeometryScriptRemeshOptions::bAllowFlips");
static_assert(offsetof(FGeometryScriptRemeshOptions, bAllowSplits) == 0xc, "Offset mismatch for FGeometryScriptRemeshOptions::bAllowSplits");
static_assert(offsetof(FGeometryScriptRemeshOptions, bAllowCollapses) == 0xd, "Offset mismatch for FGeometryScriptRemeshOptions::bAllowCollapses");
static_assert(offsetof(FGeometryScriptRemeshOptions, bPreventNormalFlips) == 0xe, "Offset mismatch for FGeometryScriptRemeshOptions::bPreventNormalFlips");
static_assert(offsetof(FGeometryScriptRemeshOptions, bPreventTinyTriangles) == 0xf, "Offset mismatch for FGeometryScriptRemeshOptions::bPreventTinyTriangles");
static_assert(offsetof(FGeometryScriptRemeshOptions, bUseFullRemeshPasses) == 0x10, "Offset mismatch for FGeometryScriptRemeshOptions::bUseFullRemeshPasses");
static_assert(offsetof(FGeometryScriptRemeshOptions, RemeshIterations) == 0x14, "Offset mismatch for FGeometryScriptRemeshOptions::RemeshIterations");
static_assert(offsetof(FGeometryScriptRemeshOptions, bAutoCompact) == 0x18, "Offset mismatch for FGeometryScriptRemeshOptions::bAutoCompact");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptUniformRemeshOptions
{
    uint8_t TargetType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t TargetTriangleCount; // 0x4 (Size: 0x4, Type: IntProperty)
    float TargetEdgeLength; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptUniformRemeshOptions) == 0xc, "Size mismatch for FGeometryScriptUniformRemeshOptions");
static_assert(offsetof(FGeometryScriptUniformRemeshOptions, TargetType) == 0x0, "Offset mismatch for FGeometryScriptUniformRemeshOptions::TargetType");
static_assert(offsetof(FGeometryScriptUniformRemeshOptions, TargetTriangleCount) == 0x4, "Offset mismatch for FGeometryScriptUniformRemeshOptions::TargetTriangleCount");
static_assert(offsetof(FGeometryScriptUniformRemeshOptions, TargetEdgeLength) == 0x8, "Offset mismatch for FGeometryScriptUniformRemeshOptions::TargetEdgeLength");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryScriptWeldEdgesOptions
{
    float Tolerance; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bOnlyUniquePairs; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptWeldEdgesOptions) == 0x8, "Size mismatch for FGeometryScriptWeldEdgesOptions");
static_assert(offsetof(FGeometryScriptWeldEdgesOptions, Tolerance) == 0x0, "Offset mismatch for FGeometryScriptWeldEdgesOptions::Tolerance");
static_assert(offsetof(FGeometryScriptWeldEdgesOptions, bOnlyUniquePairs) == 0x4, "Offset mismatch for FGeometryScriptWeldEdgesOptions::bOnlyUniquePairs");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGeometryScriptResolveTJunctionOptions
{
    float Tolerance; // 0x0 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptResolveTJunctionOptions) == 0x4, "Size mismatch for FGeometryScriptResolveTJunctionOptions");
static_assert(offsetof(FGeometryScriptResolveTJunctionOptions, Tolerance) == 0x0, "Offset mismatch for FGeometryScriptResolveTJunctionOptions::Tolerance");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptSnapBoundariesOptions
{
    float Tolerance; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bSnapToEdges; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    int32_t MaxIterations; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptSnapBoundariesOptions) == 0xc, "Size mismatch for FGeometryScriptSnapBoundariesOptions");
static_assert(offsetof(FGeometryScriptSnapBoundariesOptions, Tolerance) == 0x0, "Offset mismatch for FGeometryScriptSnapBoundariesOptions::Tolerance");
static_assert(offsetof(FGeometryScriptSnapBoundariesOptions, bSnapToEdges) == 0x4, "Offset mismatch for FGeometryScriptSnapBoundariesOptions::bSnapToEdges");
static_assert(offsetof(FGeometryScriptSnapBoundariesOptions, MaxIterations) == 0x8, "Offset mismatch for FGeometryScriptSnapBoundariesOptions::MaxIterations");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FGeometryScriptFillHolesOptions
{
    uint8_t FillMethod; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bDeleteIsolatedTriangles; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptFillHolesOptions) == 0x2, "Size mismatch for FGeometryScriptFillHolesOptions");
static_assert(offsetof(FGeometryScriptFillHolesOptions, FillMethod) == 0x0, "Offset mismatch for FGeometryScriptFillHolesOptions::FillMethod");
static_assert(offsetof(FGeometryScriptFillHolesOptions, bDeleteIsolatedTriangles) == 0x1, "Offset mismatch for FGeometryScriptFillHolesOptions::bDeleteIsolatedTriangles");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptRemoveSmallComponentOptions
{
    float MinVolume; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MinArea; // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t MinTriangleCount; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptRemoveSmallComponentOptions) == 0xc, "Size mismatch for FGeometryScriptRemoveSmallComponentOptions");
static_assert(offsetof(FGeometryScriptRemoveSmallComponentOptions, MinVolume) == 0x0, "Offset mismatch for FGeometryScriptRemoveSmallComponentOptions::MinVolume");
static_assert(offsetof(FGeometryScriptRemoveSmallComponentOptions, MinArea) == 0x4, "Offset mismatch for FGeometryScriptRemoveSmallComponentOptions::MinArea");
static_assert(offsetof(FGeometryScriptRemoveSmallComponentOptions, MinTriangleCount) == 0x8, "Offset mismatch for FGeometryScriptRemoveSmallComponentOptions::MinTriangleCount");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FGeometryScriptRemoveHiddenTrianglesOptions
{
    uint8_t Method; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t SamplesPerTriangle; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t ShrinkSelection; // 0x8 (Size: 0x4, Type: IntProperty)
    float WindingIsoValue; // 0xc (Size: 0x4, Type: FloatProperty)
    int32_t RaysPerSample; // 0x10 (Size: 0x4, Type: IntProperty)
    float NormalOffset; // 0x14 (Size: 0x4, Type: FloatProperty)
    bool bCompactResult; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptRemoveHiddenTrianglesOptions) == 0x1c, "Size mismatch for FGeometryScriptRemoveHiddenTrianglesOptions");
static_assert(offsetof(FGeometryScriptRemoveHiddenTrianglesOptions, Method) == 0x0, "Offset mismatch for FGeometryScriptRemoveHiddenTrianglesOptions::Method");
static_assert(offsetof(FGeometryScriptRemoveHiddenTrianglesOptions, SamplesPerTriangle) == 0x4, "Offset mismatch for FGeometryScriptRemoveHiddenTrianglesOptions::SamplesPerTriangle");
static_assert(offsetof(FGeometryScriptRemoveHiddenTrianglesOptions, ShrinkSelection) == 0x8, "Offset mismatch for FGeometryScriptRemoveHiddenTrianglesOptions::ShrinkSelection");
static_assert(offsetof(FGeometryScriptRemoveHiddenTrianglesOptions, WindingIsoValue) == 0xc, "Offset mismatch for FGeometryScriptRemoveHiddenTrianglesOptions::WindingIsoValue");
static_assert(offsetof(FGeometryScriptRemoveHiddenTrianglesOptions, RaysPerSample) == 0x10, "Offset mismatch for FGeometryScriptRemoveHiddenTrianglesOptions::RaysPerSample");
static_assert(offsetof(FGeometryScriptRemoveHiddenTrianglesOptions, NormalOffset) == 0x14, "Offset mismatch for FGeometryScriptRemoveHiddenTrianglesOptions::NormalOffset");
static_assert(offsetof(FGeometryScriptRemoveHiddenTrianglesOptions, bCompactResult) == 0x18, "Offset mismatch for FGeometryScriptRemoveHiddenTrianglesOptions::bCompactResult");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGeometryScriptDegenerateTriangleOptions
{
    uint8_t Mode; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    double MinTriangleArea; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double MinEdgeLength; // 0x10 (Size: 0x8, Type: DoubleProperty)
    bool bCompactOnCompletion; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptDegenerateTriangleOptions) == 0x20, "Size mismatch for FGeometryScriptDegenerateTriangleOptions");
static_assert(offsetof(FGeometryScriptDegenerateTriangleOptions, Mode) == 0x0, "Offset mismatch for FGeometryScriptDegenerateTriangleOptions::Mode");
static_assert(offsetof(FGeometryScriptDegenerateTriangleOptions, MinTriangleArea) == 0x8, "Offset mismatch for FGeometryScriptDegenerateTriangleOptions::MinTriangleArea");
static_assert(offsetof(FGeometryScriptDegenerateTriangleOptions, MinEdgeLength) == 0x10, "Offset mismatch for FGeometryScriptDegenerateTriangleOptions::MinEdgeLength");
static_assert(offsetof(FGeometryScriptDegenerateTriangleOptions, bCompactOnCompletion) == 0x18, "Offset mismatch for FGeometryScriptDegenerateTriangleOptions::bCompactOnCompletion");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGeometryScriptMeshPointSamplingOptions
{
    float SamplingRadius; // 0x0 (Size: 0x4, Type: FloatProperty)
    int32_t MaxNumSamples; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t RandomSeed; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    double SubSampleDensity; // 0x10 (Size: 0x8, Type: DoubleProperty)
    int32_t SamplingMethodVersion; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptMeshPointSamplingOptions) == 0x20, "Size mismatch for FGeometryScriptMeshPointSamplingOptions");
static_assert(offsetof(FGeometryScriptMeshPointSamplingOptions, SamplingRadius) == 0x0, "Offset mismatch for FGeometryScriptMeshPointSamplingOptions::SamplingRadius");
static_assert(offsetof(FGeometryScriptMeshPointSamplingOptions, MaxNumSamples) == 0x4, "Offset mismatch for FGeometryScriptMeshPointSamplingOptions::MaxNumSamples");
static_assert(offsetof(FGeometryScriptMeshPointSamplingOptions, RandomSeed) == 0x8, "Offset mismatch for FGeometryScriptMeshPointSamplingOptions::RandomSeed");
static_assert(offsetof(FGeometryScriptMeshPointSamplingOptions, SubSampleDensity) == 0x10, "Offset mismatch for FGeometryScriptMeshPointSamplingOptions::SubSampleDensity");
static_assert(offsetof(FGeometryScriptMeshPointSamplingOptions, SamplingMethodVersion) == 0x18, "Offset mismatch for FGeometryScriptMeshPointSamplingOptions::SamplingMethodVersion");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGeometryScriptNonUniformPointSamplingOptions
{
    float MaxSamplingRadius; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t SizeDistribution; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    double SizeDistributionPower; // 0x8 (Size: 0x8, Type: DoubleProperty)
    uint8_t WeightMode; // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bInvertWeights; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptNonUniformPointSamplingOptions) == 0x18, "Size mismatch for FGeometryScriptNonUniformPointSamplingOptions");
static_assert(offsetof(FGeometryScriptNonUniformPointSamplingOptions, MaxSamplingRadius) == 0x0, "Offset mismatch for FGeometryScriptNonUniformPointSamplingOptions::MaxSamplingRadius");
static_assert(offsetof(FGeometryScriptNonUniformPointSamplingOptions, SizeDistribution) == 0x4, "Offset mismatch for FGeometryScriptNonUniformPointSamplingOptions::SizeDistribution");
static_assert(offsetof(FGeometryScriptNonUniformPointSamplingOptions, SizeDistributionPower) == 0x8, "Offset mismatch for FGeometryScriptNonUniformPointSamplingOptions::SizeDistributionPower");
static_assert(offsetof(FGeometryScriptNonUniformPointSamplingOptions, WeightMode) == 0x10, "Offset mismatch for FGeometryScriptNonUniformPointSamplingOptions::WeightMode");
static_assert(offsetof(FGeometryScriptNonUniformPointSamplingOptions, bInvertWeights) == 0x11, "Offset mismatch for FGeometryScriptNonUniformPointSamplingOptions::bInvertWeights");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGeometryScriptSculptLayerUpdateOptions
{
    bool bRecomputeNormals; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptSculptLayerUpdateOptions) == 0x1, "Size mismatch for FGeometryScriptSculptLayerUpdateOptions");
static_assert(offsetof(FGeometryScriptSculptLayerUpdateOptions, bRecomputeNormals) == 0x0, "Offset mismatch for FGeometryScriptSculptLayerUpdateOptions::bRecomputeNormals");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryScriptPlanarSimplifyOptions
{
    float AngleThreshold; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bAutoCompact; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptPlanarSimplifyOptions) == 0x8, "Size mismatch for FGeometryScriptPlanarSimplifyOptions");
static_assert(offsetof(FGeometryScriptPlanarSimplifyOptions, AngleThreshold) == 0x0, "Offset mismatch for FGeometryScriptPlanarSimplifyOptions::AngleThreshold");
static_assert(offsetof(FGeometryScriptPlanarSimplifyOptions, bAutoCompact) == 0x4, "Offset mismatch for FGeometryScriptPlanarSimplifyOptions::bAutoCompact");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryScriptPolygroupSimplifyOptions
{
    float AngleThreshold; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bAutoCompact; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptPolygroupSimplifyOptions) == 0x8, "Size mismatch for FGeometryScriptPolygroupSimplifyOptions");
static_assert(offsetof(FGeometryScriptPolygroupSimplifyOptions, AngleThreshold) == 0x0, "Offset mismatch for FGeometryScriptPolygroupSimplifyOptions::AngleThreshold");
static_assert(offsetof(FGeometryScriptPolygroupSimplifyOptions, bAutoCompact) == 0x4, "Offset mismatch for FGeometryScriptPolygroupSimplifyOptions::bAutoCompact");

// Size: 0x7 (Inherited: 0x0, Single: 0x7)
struct FGeometryScriptSimplifyMeshOptions
{
    uint8_t Method; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bAllowSeamCollapse; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bAllowSeamSmoothing; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool bAllowSeamSplits; // 0x3 (Size: 0x1, Type: BoolProperty)
    bool bPreserveVertexPositions; // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bRetainQuadricMemory; // 0x5 (Size: 0x1, Type: BoolProperty)
    bool bAutoCompact; // 0x6 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptSimplifyMeshOptions) == 0x7, "Size mismatch for FGeometryScriptSimplifyMeshOptions");
static_assert(offsetof(FGeometryScriptSimplifyMeshOptions, Method) == 0x0, "Offset mismatch for FGeometryScriptSimplifyMeshOptions::Method");
static_assert(offsetof(FGeometryScriptSimplifyMeshOptions, bAllowSeamCollapse) == 0x1, "Offset mismatch for FGeometryScriptSimplifyMeshOptions::bAllowSeamCollapse");
static_assert(offsetof(FGeometryScriptSimplifyMeshOptions, bAllowSeamSmoothing) == 0x2, "Offset mismatch for FGeometryScriptSimplifyMeshOptions::bAllowSeamSmoothing");
static_assert(offsetof(FGeometryScriptSimplifyMeshOptions, bAllowSeamSplits) == 0x3, "Offset mismatch for FGeometryScriptSimplifyMeshOptions::bAllowSeamSplits");
static_assert(offsetof(FGeometryScriptSimplifyMeshOptions, bPreserveVertexPositions) == 0x4, "Offset mismatch for FGeometryScriptSimplifyMeshOptions::bPreserveVertexPositions");
static_assert(offsetof(FGeometryScriptSimplifyMeshOptions, bRetainQuadricMemory) == 0x5, "Offset mismatch for FGeometryScriptSimplifyMeshOptions::bRetainQuadricMemory");
static_assert(offsetof(FGeometryScriptSimplifyMeshOptions, bAutoCompact) == 0x6, "Offset mismatch for FGeometryScriptSimplifyMeshOptions::bAutoCompact");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptSpatialQueryOptions
{
    float MaxDistance; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bAllowUnsafeModifiedQueries; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    float WindingIsoThreshold; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptSpatialQueryOptions) == 0xc, "Size mismatch for FGeometryScriptSpatialQueryOptions");
static_assert(offsetof(FGeometryScriptSpatialQueryOptions, MaxDistance) == 0x0, "Offset mismatch for FGeometryScriptSpatialQueryOptions::MaxDistance");
static_assert(offsetof(FGeometryScriptSpatialQueryOptions, bAllowUnsafeModifiedQueries) == 0x4, "Offset mismatch for FGeometryScriptSpatialQueryOptions::bAllowUnsafeModifiedQueries");
static_assert(offsetof(FGeometryScriptSpatialQueryOptions, WindingIsoThreshold) == 0x8, "Offset mismatch for FGeometryScriptSpatialQueryOptions::WindingIsoThreshold");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FGeometryScriptRayHitResult
{
    bool bHit; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float RayParameter; // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t HitTriangleID; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FVector HitPosition; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector HitBaryCoords; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FGeometryScriptRayHitResult) == 0x40, "Size mismatch for FGeometryScriptRayHitResult");
static_assert(offsetof(FGeometryScriptRayHitResult, bHit) == 0x0, "Offset mismatch for FGeometryScriptRayHitResult::bHit");
static_assert(offsetof(FGeometryScriptRayHitResult, RayParameter) == 0x4, "Offset mismatch for FGeometryScriptRayHitResult::RayParameter");
static_assert(offsetof(FGeometryScriptRayHitResult, HitTriangleID) == 0x8, "Offset mismatch for FGeometryScriptRayHitResult::HitTriangleID");
static_assert(offsetof(FGeometryScriptRayHitResult, HitPosition) == 0x10, "Offset mismatch for FGeometryScriptRayHitResult::HitPosition");
static_assert(offsetof(FGeometryScriptRayHitResult, HitBaryCoords) == 0x28, "Offset mismatch for FGeometryScriptRayHitResult::HitBaryCoords");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGeometryScriptPNTessellateOptions
{
    bool bRecomputeNormals; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptPNTessellateOptions) == 0x1, "Size mismatch for FGeometryScriptPNTessellateOptions");
static_assert(offsetof(FGeometryScriptPNTessellateOptions, bRecomputeNormals) == 0x0, "Offset mismatch for FGeometryScriptPNTessellateOptions::bRecomputeNormals");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FGeometryScriptSelectiveTessellateOptions
{
    bool bEnableMultithreading; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t EmptyBehavior; // 0x1 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FGeometryScriptSelectiveTessellateOptions) == 0x2, "Size mismatch for FGeometryScriptSelectiveTessellateOptions");
static_assert(offsetof(FGeometryScriptSelectiveTessellateOptions, bEnableMultithreading) == 0x0, "Offset mismatch for FGeometryScriptSelectiveTessellateOptions::bEnableMultithreading");
static_assert(offsetof(FGeometryScriptSelectiveTessellateOptions, EmptyBehavior) == 0x1, "Offset mismatch for FGeometryScriptSelectiveTessellateOptions::EmptyBehavior");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryScriptRepackUVsOptions
{
    int32_t TargetImageWidth; // 0x0 (Size: 0x4, Type: IntProperty)
    bool bOptimizeIslandRotation; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptRepackUVsOptions) == 0x8, "Size mismatch for FGeometryScriptRepackUVsOptions");
static_assert(offsetof(FGeometryScriptRepackUVsOptions, TargetImageWidth) == 0x0, "Offset mismatch for FGeometryScriptRepackUVsOptions::TargetImageWidth");
static_assert(offsetof(FGeometryScriptRepackUVsOptions, bOptimizeIslandRotation) == 0x4, "Offset mismatch for FGeometryScriptRepackUVsOptions::bOptimizeIslandRotation");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FGeometryScriptLayoutUVsOptions
{
    uint8_t LayoutType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t TextureResolution; // 0x4 (Size: 0x4, Type: IntProperty)
    float Scale; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FVector2D Translation; // 0x10 (Size: 0x10, Type: StructProperty)
    bool bPreserveScale; // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bPreserveRotation; // 0x21 (Size: 0x1, Type: BoolProperty)
    bool bAllowFlips; // 0x22 (Size: 0x1, Type: BoolProperty)
    bool bEnableUDIMLayout; // 0x23 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TMap<int32_t, int32_t> UDIMResolutions; // 0x28 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FGeometryScriptLayoutUVsOptions) == 0x78, "Size mismatch for FGeometryScriptLayoutUVsOptions");
static_assert(offsetof(FGeometryScriptLayoutUVsOptions, LayoutType) == 0x0, "Offset mismatch for FGeometryScriptLayoutUVsOptions::LayoutType");
static_assert(offsetof(FGeometryScriptLayoutUVsOptions, TextureResolution) == 0x4, "Offset mismatch for FGeometryScriptLayoutUVsOptions::TextureResolution");
static_assert(offsetof(FGeometryScriptLayoutUVsOptions, Scale) == 0x8, "Offset mismatch for FGeometryScriptLayoutUVsOptions::Scale");
static_assert(offsetof(FGeometryScriptLayoutUVsOptions, Translation) == 0x10, "Offset mismatch for FGeometryScriptLayoutUVsOptions::Translation");
static_assert(offsetof(FGeometryScriptLayoutUVsOptions, bPreserveScale) == 0x20, "Offset mismatch for FGeometryScriptLayoutUVsOptions::bPreserveScale");
static_assert(offsetof(FGeometryScriptLayoutUVsOptions, bPreserveRotation) == 0x21, "Offset mismatch for FGeometryScriptLayoutUVsOptions::bPreserveRotation");
static_assert(offsetof(FGeometryScriptLayoutUVsOptions, bAllowFlips) == 0x22, "Offset mismatch for FGeometryScriptLayoutUVsOptions::bAllowFlips");
static_assert(offsetof(FGeometryScriptLayoutUVsOptions, bEnableUDIMLayout) == 0x23, "Offset mismatch for FGeometryScriptLayoutUVsOptions::bEnableUDIMLayout");
static_assert(offsetof(FGeometryScriptLayoutUVsOptions, UDIMResolutions) == 0x28, "Offset mismatch for FGeometryScriptLayoutUVsOptions::UDIMResolutions");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGeometryScriptExpMapUVOptions
{
    int32_t NormalSmoothingRounds; // 0x0 (Size: 0x4, Type: IntProperty)
    float NormalSmoothingAlpha; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptExpMapUVOptions) == 0x8, "Size mismatch for FGeometryScriptExpMapUVOptions");
static_assert(offsetof(FGeometryScriptExpMapUVOptions, NormalSmoothingRounds) == 0x0, "Offset mismatch for FGeometryScriptExpMapUVOptions::NormalSmoothingRounds");
static_assert(offsetof(FGeometryScriptExpMapUVOptions, NormalSmoothingAlpha) == 0x4, "Offset mismatch for FGeometryScriptExpMapUVOptions::NormalSmoothingAlpha");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGeometryScriptSpectralConformalUVOptions
{
    bool bPreserveIrregularity; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptSpectralConformalUVOptions) == 0x1, "Size mismatch for FGeometryScriptSpectralConformalUVOptions");
static_assert(offsetof(FGeometryScriptSpectralConformalUVOptions, bPreserveIrregularity) == 0x0, "Offset mismatch for FGeometryScriptSpectralConformalUVOptions::bPreserveIrregularity");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FGeometryScriptRecomputeUVsOptions
{
    uint8_t Method; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t IslandSource; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    FGeometryScriptExpMapUVOptions ExpMapOptions; // 0x4 (Size: 0x8, Type: StructProperty)
    FGeometryScriptSpectralConformalUVOptions SpectralConformalOptions; // 0xc (Size: 0x1, Type: StructProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FGeometryScriptGroupLayer GroupLayer; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bAutoAlignIslandsWithAxes; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptRecomputeUVsOptions) == 0x1c, "Size mismatch for FGeometryScriptRecomputeUVsOptions");
static_assert(offsetof(FGeometryScriptRecomputeUVsOptions, Method) == 0x0, "Offset mismatch for FGeometryScriptRecomputeUVsOptions::Method");
static_assert(offsetof(FGeometryScriptRecomputeUVsOptions, IslandSource) == 0x1, "Offset mismatch for FGeometryScriptRecomputeUVsOptions::IslandSource");
static_assert(offsetof(FGeometryScriptRecomputeUVsOptions, ExpMapOptions) == 0x4, "Offset mismatch for FGeometryScriptRecomputeUVsOptions::ExpMapOptions");
static_assert(offsetof(FGeometryScriptRecomputeUVsOptions, SpectralConformalOptions) == 0xc, "Offset mismatch for FGeometryScriptRecomputeUVsOptions::SpectralConformalOptions");
static_assert(offsetof(FGeometryScriptRecomputeUVsOptions, GroupLayer) == 0x10, "Offset mismatch for FGeometryScriptRecomputeUVsOptions::GroupLayer");
static_assert(offsetof(FGeometryScriptRecomputeUVsOptions, bAutoAlignIslandsWithAxes) == 0x18, "Offset mismatch for FGeometryScriptRecomputeUVsOptions::bAutoAlignIslandsWithAxes");

// Size: 0x34 (Inherited: 0x0, Single: 0x34)
struct FGeometryScriptPatchBuilderOptions
{
    int32_t InitialPatchCount; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t MinPatchSize; // 0x4 (Size: 0x4, Type: IntProperty)
    float PatchCurvatureAlignmentWeight; // 0x8 (Size: 0x4, Type: FloatProperty)
    float PatchMergingMetricThresh; // 0xc (Size: 0x4, Type: FloatProperty)
    float PatchMergingAngleThresh; // 0x10 (Size: 0x4, Type: FloatProperty)
    FGeometryScriptExpMapUVOptions ExpMapOptions; // 0x14 (Size: 0x8, Type: StructProperty)
    bool bRespectInputGroups; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
    FGeometryScriptGroupLayer GroupLayer; // 0x20 (Size: 0x8, Type: StructProperty)
    bool bAutoPack; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    FGeometryScriptRepackUVsOptions PackingOptions; // 0x2c (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FGeometryScriptPatchBuilderOptions) == 0x34, "Size mismatch for FGeometryScriptPatchBuilderOptions");
static_assert(offsetof(FGeometryScriptPatchBuilderOptions, InitialPatchCount) == 0x0, "Offset mismatch for FGeometryScriptPatchBuilderOptions::InitialPatchCount");
static_assert(offsetof(FGeometryScriptPatchBuilderOptions, MinPatchSize) == 0x4, "Offset mismatch for FGeometryScriptPatchBuilderOptions::MinPatchSize");
static_assert(offsetof(FGeometryScriptPatchBuilderOptions, PatchCurvatureAlignmentWeight) == 0x8, "Offset mismatch for FGeometryScriptPatchBuilderOptions::PatchCurvatureAlignmentWeight");
static_assert(offsetof(FGeometryScriptPatchBuilderOptions, PatchMergingMetricThresh) == 0xc, "Offset mismatch for FGeometryScriptPatchBuilderOptions::PatchMergingMetricThresh");
static_assert(offsetof(FGeometryScriptPatchBuilderOptions, PatchMergingAngleThresh) == 0x10, "Offset mismatch for FGeometryScriptPatchBuilderOptions::PatchMergingAngleThresh");
static_assert(offsetof(FGeometryScriptPatchBuilderOptions, ExpMapOptions) == 0x14, "Offset mismatch for FGeometryScriptPatchBuilderOptions::ExpMapOptions");
static_assert(offsetof(FGeometryScriptPatchBuilderOptions, bRespectInputGroups) == 0x1c, "Offset mismatch for FGeometryScriptPatchBuilderOptions::bRespectInputGroups");
static_assert(offsetof(FGeometryScriptPatchBuilderOptions, GroupLayer) == 0x20, "Offset mismatch for FGeometryScriptPatchBuilderOptions::GroupLayer");
static_assert(offsetof(FGeometryScriptPatchBuilderOptions, bAutoPack) == 0x28, "Offset mismatch for FGeometryScriptPatchBuilderOptions::bAutoPack");
static_assert(offsetof(FGeometryScriptPatchBuilderOptions, PackingOptions) == 0x2c, "Offset mismatch for FGeometryScriptPatchBuilderOptions::PackingOptions");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGeometryScriptXAtlasOptions
{
    int32_t MaxIterations; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptXAtlasOptions) == 0x4, "Size mismatch for FGeometryScriptXAtlasOptions");
static_assert(offsetof(FGeometryScriptXAtlasOptions, MaxIterations) == 0x0, "Offset mismatch for FGeometryScriptXAtlasOptions::MaxIterations");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FGeometryScriptUVTexelDensityOptions
{
    uint8_t TexelDensityMode; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float TargetWorldUnits; // 0x4 (Size: 0x4, Type: FloatProperty)
    float TargetPixelCount; // 0x8 (Size: 0x4, Type: FloatProperty)
    float TextureResolution; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bEnableUDIMLayout; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    TMap<int32_t, int32_t> UDIMResolutions; // 0x18 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FGeometryScriptUVTexelDensityOptions) == 0x68, "Size mismatch for FGeometryScriptUVTexelDensityOptions");
static_assert(offsetof(FGeometryScriptUVTexelDensityOptions, TexelDensityMode) == 0x0, "Offset mismatch for FGeometryScriptUVTexelDensityOptions::TexelDensityMode");
static_assert(offsetof(FGeometryScriptUVTexelDensityOptions, TargetWorldUnits) == 0x4, "Offset mismatch for FGeometryScriptUVTexelDensityOptions::TargetWorldUnits");
static_assert(offsetof(FGeometryScriptUVTexelDensityOptions, TargetPixelCount) == 0x8, "Offset mismatch for FGeometryScriptUVTexelDensityOptions::TargetPixelCount");
static_assert(offsetof(FGeometryScriptUVTexelDensityOptions, TextureResolution) == 0xc, "Offset mismatch for FGeometryScriptUVTexelDensityOptions::TextureResolution");
static_assert(offsetof(FGeometryScriptUVTexelDensityOptions, bEnableUDIMLayout) == 0x10, "Offset mismatch for FGeometryScriptUVTexelDensityOptions::bEnableUDIMLayout");
static_assert(offsetof(FGeometryScriptUVTexelDensityOptions, UDIMResolutions) == 0x18, "Offset mismatch for FGeometryScriptUVTexelDensityOptions::UDIMResolutions");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptMeshProjectionSettings
{
    bool bProcessAllIfEmptySelection; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float ProjectionRangeMax; // 0x4 (Size: 0x4, Type: FloatProperty)
    float ProjectionRangeMin; // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bResetUVsForUnmatched; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptMeshProjectionSettings) == 0x10, "Size mismatch for FGeometryScriptMeshProjectionSettings");
static_assert(offsetof(FGeometryScriptMeshProjectionSettings, bProcessAllIfEmptySelection) == 0x0, "Offset mismatch for FGeometryScriptMeshProjectionSettings::bProcessAllIfEmptySelection");
static_assert(offsetof(FGeometryScriptMeshProjectionSettings, ProjectionRangeMax) == 0x4, "Offset mismatch for FGeometryScriptMeshProjectionSettings::ProjectionRangeMax");
static_assert(offsetof(FGeometryScriptMeshProjectionSettings, ProjectionRangeMin) == 0x8, "Offset mismatch for FGeometryScriptMeshProjectionSettings::ProjectionRangeMin");
static_assert(offsetof(FGeometryScriptMeshProjectionSettings, bResetUVsForUnmatched) == 0xc, "Offset mismatch for FGeometryScriptMeshProjectionSettings::bResetUVsForUnmatched");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGeometryScriptBlurMeshVertexColorsOptions
{
    bool Red; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool Green; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool Blue; // 0x2 (Size: 0x1, Type: BoolProperty)
    bool Alpha; // 0x3 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGeometryScriptBlurMeshVertexColorsOptions) == 0x4, "Size mismatch for FGeometryScriptBlurMeshVertexColorsOptions");
static_assert(offsetof(FGeometryScriptBlurMeshVertexColorsOptions, Red) == 0x0, "Offset mismatch for FGeometryScriptBlurMeshVertexColorsOptions::Red");
static_assert(offsetof(FGeometryScriptBlurMeshVertexColorsOptions, Green) == 0x1, "Offset mismatch for FGeometryScriptBlurMeshVertexColorsOptions::Green");
static_assert(offsetof(FGeometryScriptBlurMeshVertexColorsOptions, Blue) == 0x2, "Offset mismatch for FGeometryScriptBlurMeshVertexColorsOptions::Blue");
static_assert(offsetof(FGeometryScriptBlurMeshVertexColorsOptions, Alpha) == 0x3, "Offset mismatch for FGeometryScriptBlurMeshVertexColorsOptions::Alpha");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FGeometryScriptTransferMeshVertexColorsOptions
{
    uint8_t TransferMethod; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    double RadiusPercentage; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double NormalThreshold; // 0x10 (Size: 0x8, Type: DoubleProperty)
    bool LayeredMeshSupport; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
    int32_t NumSmoothingIterations; // 0x1c (Size: 0x4, Type: IntProperty)
    float SmoothingStrength; // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bHardEdges; // 0x24 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_25[0x3]; // 0x25 (Size: 0x3, Type: PaddingProperty)
    float BiasRatio; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptTransferMeshVertexColorsOptions) == 0x30, "Size mismatch for FGeometryScriptTransferMeshVertexColorsOptions");
static_assert(offsetof(FGeometryScriptTransferMeshVertexColorsOptions, TransferMethod) == 0x0, "Offset mismatch for FGeometryScriptTransferMeshVertexColorsOptions::TransferMethod");
static_assert(offsetof(FGeometryScriptTransferMeshVertexColorsOptions, RadiusPercentage) == 0x8, "Offset mismatch for FGeometryScriptTransferMeshVertexColorsOptions::RadiusPercentage");
static_assert(offsetof(FGeometryScriptTransferMeshVertexColorsOptions, NormalThreshold) == 0x10, "Offset mismatch for FGeometryScriptTransferMeshVertexColorsOptions::NormalThreshold");
static_assert(offsetof(FGeometryScriptTransferMeshVertexColorsOptions, LayeredMeshSupport) == 0x18, "Offset mismatch for FGeometryScriptTransferMeshVertexColorsOptions::LayeredMeshSupport");
static_assert(offsetof(FGeometryScriptTransferMeshVertexColorsOptions, NumSmoothingIterations) == 0x1c, "Offset mismatch for FGeometryScriptTransferMeshVertexColorsOptions::NumSmoothingIterations");
static_assert(offsetof(FGeometryScriptTransferMeshVertexColorsOptions, SmoothingStrength) == 0x20, "Offset mismatch for FGeometryScriptTransferMeshVertexColorsOptions::SmoothingStrength");
static_assert(offsetof(FGeometryScriptTransferMeshVertexColorsOptions, bHardEdges) == 0x24, "Offset mismatch for FGeometryScriptTransferMeshVertexColorsOptions::bHardEdges");
static_assert(offsetof(FGeometryScriptTransferMeshVertexColorsOptions, BiasRatio) == 0x28, "Offset mismatch for FGeometryScriptTransferMeshVertexColorsOptions::BiasRatio");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScript3DGridParameters
{
    uint8_t SizeMethod; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float GridCellSize; // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t GridResolution; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScript3DGridParameters) == 0xc, "Size mismatch for FGeometryScript3DGridParameters");
static_assert(offsetof(FGeometryScript3DGridParameters, SizeMethod) == 0x0, "Offset mismatch for FGeometryScript3DGridParameters::SizeMethod");
static_assert(offsetof(FGeometryScript3DGridParameters, GridCellSize) == 0x4, "Offset mismatch for FGeometryScript3DGridParameters::GridCellSize");
static_assert(offsetof(FGeometryScript3DGridParameters, GridResolution) == 0x8, "Offset mismatch for FGeometryScript3DGridParameters::GridResolution");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FGeometryScriptSolidifyOptions
{
    FGeometryScript3DGridParameters GridParameters; // 0x0 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FBox CustomBounds; // 0x10 (Size: 0x38, Type: StructProperty)
    float WindingThreshold; // 0x48 (Size: 0x4, Type: FloatProperty)
    bool bSolidAtBoundaries; // 0x4c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4d[0x3]; // 0x4d (Size: 0x3, Type: PaddingProperty)
    float ExtendBounds; // 0x50 (Size: 0x4, Type: FloatProperty)
    int32_t SurfaceSearchSteps; // 0x54 (Size: 0x4, Type: IntProperty)
    bool bThickenShells; // 0x58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
    double ShellThickness; // 0x60 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FGeometryScriptSolidifyOptions) == 0x68, "Size mismatch for FGeometryScriptSolidifyOptions");
static_assert(offsetof(FGeometryScriptSolidifyOptions, GridParameters) == 0x0, "Offset mismatch for FGeometryScriptSolidifyOptions::GridParameters");
static_assert(offsetof(FGeometryScriptSolidifyOptions, CustomBounds) == 0x10, "Offset mismatch for FGeometryScriptSolidifyOptions::CustomBounds");
static_assert(offsetof(FGeometryScriptSolidifyOptions, WindingThreshold) == 0x48, "Offset mismatch for FGeometryScriptSolidifyOptions::WindingThreshold");
static_assert(offsetof(FGeometryScriptSolidifyOptions, bSolidAtBoundaries) == 0x4c, "Offset mismatch for FGeometryScriptSolidifyOptions::bSolidAtBoundaries");
static_assert(offsetof(FGeometryScriptSolidifyOptions, ExtendBounds) == 0x50, "Offset mismatch for FGeometryScriptSolidifyOptions::ExtendBounds");
static_assert(offsetof(FGeometryScriptSolidifyOptions, SurfaceSearchSteps) == 0x54, "Offset mismatch for FGeometryScriptSolidifyOptions::SurfaceSearchSteps");
static_assert(offsetof(FGeometryScriptSolidifyOptions, bThickenShells) == 0x58, "Offset mismatch for FGeometryScriptSolidifyOptions::bThickenShells");
static_assert(offsetof(FGeometryScriptSolidifyOptions, ShellThickness) == 0x60, "Offset mismatch for FGeometryScriptSolidifyOptions::ShellThickness");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FGeometryScriptMorphologyOptions
{
    FGeometryScript3DGridParameters SDFGridParameters; // 0x0 (Size: 0xc, Type: StructProperty)
    bool bUseSeparateMeshGrid; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FGeometryScript3DGridParameters MeshGridParameters; // 0x10 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FBox CustomBounds; // 0x20 (Size: 0x38, Type: StructProperty)
    uint8_t Operation; // 0x58 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_59[0x3]; // 0x59 (Size: 0x3, Type: PaddingProperty)
    float Distance; // 0x5c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptMorphologyOptions) == 0x60, "Size mismatch for FGeometryScriptMorphologyOptions");
static_assert(offsetof(FGeometryScriptMorphologyOptions, SDFGridParameters) == 0x0, "Offset mismatch for FGeometryScriptMorphologyOptions::SDFGridParameters");
static_assert(offsetof(FGeometryScriptMorphologyOptions, bUseSeparateMeshGrid) == 0xc, "Offset mismatch for FGeometryScriptMorphologyOptions::bUseSeparateMeshGrid");
static_assert(offsetof(FGeometryScriptMorphologyOptions, MeshGridParameters) == 0x10, "Offset mismatch for FGeometryScriptMorphologyOptions::MeshGridParameters");
static_assert(offsetof(FGeometryScriptMorphologyOptions, CustomBounds) == 0x20, "Offset mismatch for FGeometryScriptMorphologyOptions::CustomBounds");
static_assert(offsetof(FGeometryScriptMorphologyOptions, Operation) == 0x58, "Offset mismatch for FGeometryScriptMorphologyOptions::Operation");
static_assert(offsetof(FGeometryScriptMorphologyOptions, Distance) == 0x5c, "Offset mismatch for FGeometryScriptMorphologyOptions::Distance");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGeometryScriptPointClusteringOptions
{
    TArray<FVector> InitialClusterCenters; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t TargetNumClusters; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t InitializeMethod; // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    int32_t RandomSeed; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t MaxIterations; // 0x1c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptPointClusteringOptions) == 0x20, "Size mismatch for FGeometryScriptPointClusteringOptions");
static_assert(offsetof(FGeometryScriptPointClusteringOptions, InitialClusterCenters) == 0x0, "Offset mismatch for FGeometryScriptPointClusteringOptions::InitialClusterCenters");
static_assert(offsetof(FGeometryScriptPointClusteringOptions, TargetNumClusters) == 0x10, "Offset mismatch for FGeometryScriptPointClusteringOptions::TargetNumClusters");
static_assert(offsetof(FGeometryScriptPointClusteringOptions, InitializeMethod) == 0x14, "Offset mismatch for FGeometryScriptPointClusteringOptions::InitializeMethod");
static_assert(offsetof(FGeometryScriptPointClusteringOptions, RandomSeed) == 0x18, "Offset mismatch for FGeometryScriptPointClusteringOptions::RandomSeed");
static_assert(offsetof(FGeometryScriptPointClusteringOptions, MaxIterations) == 0x1c, "Offset mismatch for FGeometryScriptPointClusteringOptions::MaxIterations");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGeometryScriptPointPriorityOptions
{
    TArray<float> OptionalPriorityWeights; // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bUniformSpacing; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptPointPriorityOptions) == 0x18, "Size mismatch for FGeometryScriptPointPriorityOptions");
static_assert(offsetof(FGeometryScriptPointPriorityOptions, OptionalPriorityWeights) == 0x0, "Offset mismatch for FGeometryScriptPointPriorityOptions::OptionalPriorityWeights");
static_assert(offsetof(FGeometryScriptPointPriorityOptions, bUniformSpacing) == 0x10, "Offset mismatch for FGeometryScriptPointPriorityOptions::bUniformSpacing");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FGeometryScriptPointFlatteningOptions
{
    FTransform Frame; // 0x0 (Size: 0x60, Type: StructProperty)
    uint8_t DropAxis; // 0x60 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_61[0xf]; // 0x61 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FGeometryScriptPointFlatteningOptions) == 0x70, "Size mismatch for FGeometryScriptPointFlatteningOptions");
static_assert(offsetof(FGeometryScriptPointFlatteningOptions, Frame) == 0x0, "Offset mismatch for FGeometryScriptPointFlatteningOptions::Frame");
static_assert(offsetof(FGeometryScriptPointFlatteningOptions, DropAxis) == 0x60, "Offset mismatch for FGeometryScriptPointFlatteningOptions::DropAxis");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGeometryScriptPolygonOffsetOptions
{
    uint8_t JoinType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    double MiterLimit; // 0x8 (Size: 0x8, Type: DoubleProperty)
    bool bOffsetBothSides; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    double StepsPerRadianScale; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double MaximumStepsPerRadian; // 0x20 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FGeometryScriptPolygonOffsetOptions) == 0x28, "Size mismatch for FGeometryScriptPolygonOffsetOptions");
static_assert(offsetof(FGeometryScriptPolygonOffsetOptions, JoinType) == 0x0, "Offset mismatch for FGeometryScriptPolygonOffsetOptions::JoinType");
static_assert(offsetof(FGeometryScriptPolygonOffsetOptions, MiterLimit) == 0x8, "Offset mismatch for FGeometryScriptPolygonOffsetOptions::MiterLimit");
static_assert(offsetof(FGeometryScriptPolygonOffsetOptions, bOffsetBothSides) == 0x10, "Offset mismatch for FGeometryScriptPolygonOffsetOptions::bOffsetBothSides");
static_assert(offsetof(FGeometryScriptPolygonOffsetOptions, StepsPerRadianScale) == 0x18, "Offset mismatch for FGeometryScriptPolygonOffsetOptions::StepsPerRadianScale");
static_assert(offsetof(FGeometryScriptPolygonOffsetOptions, MaximumStepsPerRadian) == 0x20, "Offset mismatch for FGeometryScriptPolygonOffsetOptions::MaximumStepsPerRadian");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGeometryScriptOpenPathOffsetOptions
{
    uint8_t JoinType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    double MiterLimit; // 0x8 (Size: 0x8, Type: DoubleProperty)
    uint8_t EndType; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    double StepsPerRadianScale; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double MaximumStepsPerRadian; // 0x20 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FGeometryScriptOpenPathOffsetOptions) == 0x28, "Size mismatch for FGeometryScriptOpenPathOffsetOptions");
static_assert(offsetof(FGeometryScriptOpenPathOffsetOptions, JoinType) == 0x0, "Offset mismatch for FGeometryScriptOpenPathOffsetOptions::JoinType");
static_assert(offsetof(FGeometryScriptOpenPathOffsetOptions, MiterLimit) == 0x8, "Offset mismatch for FGeometryScriptOpenPathOffsetOptions::MiterLimit");
static_assert(offsetof(FGeometryScriptOpenPathOffsetOptions, EndType) == 0x10, "Offset mismatch for FGeometryScriptOpenPathOffsetOptions::EndType");
static_assert(offsetof(FGeometryScriptOpenPathOffsetOptions, StepsPerRadianScale) == 0x18, "Offset mismatch for FGeometryScriptOpenPathOffsetOptions::StepsPerRadianScale");
static_assert(offsetof(FGeometryScriptOpenPathOffsetOptions, MaximumStepsPerRadian) == 0x20, "Offset mismatch for FGeometryScriptOpenPathOffsetOptions::MaximumStepsPerRadian");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FGeometryScriptSplineSamplingOptions
{
    int32_t NumSamples; // 0x0 (Size: 0x4, Type: IntProperty)
    float ErrorTolerance; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t SampleSpacing; // 0x8 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<ESplineCoordinateSpace> CoordinateSpace; // 0x9 (Size: 0x1, Type: ByteProperty)
    uint8_t RangeMethod; // 0xa (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_b[0x1]; // 0xb (Size: 0x1, Type: PaddingProperty)
    float RangeStart; // 0xc (Size: 0x4, Type: FloatProperty)
    float RangeEnd; // 0x10 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGeometryScriptSplineSamplingOptions) == 0x14, "Size mismatch for FGeometryScriptSplineSamplingOptions");
static_assert(offsetof(FGeometryScriptSplineSamplingOptions, NumSamples) == 0x0, "Offset mismatch for FGeometryScriptSplineSamplingOptions::NumSamples");
static_assert(offsetof(FGeometryScriptSplineSamplingOptions, ErrorTolerance) == 0x4, "Offset mismatch for FGeometryScriptSplineSamplingOptions::ErrorTolerance");
static_assert(offsetof(FGeometryScriptSplineSamplingOptions, SampleSpacing) == 0x8, "Offset mismatch for FGeometryScriptSplineSamplingOptions::SampleSpacing");
static_assert(offsetof(FGeometryScriptSplineSamplingOptions, CoordinateSpace) == 0x9, "Offset mismatch for FGeometryScriptSplineSamplingOptions::CoordinateSpace");
static_assert(offsetof(FGeometryScriptSplineSamplingOptions, RangeMethod) == 0xa, "Offset mismatch for FGeometryScriptSplineSamplingOptions::RangeMethod");
static_assert(offsetof(FGeometryScriptSplineSamplingOptions, RangeStart) == 0xc, "Offset mismatch for FGeometryScriptSplineSamplingOptions::RangeStart");
static_assert(offsetof(FGeometryScriptSplineSamplingOptions, RangeEnd) == 0x10, "Offset mismatch for FGeometryScriptSplineSamplingOptions::RangeEnd");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FGeometryScriptCopyMeshFromComponentOptions
{
    bool bWantNormals; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bWantTangents; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bWantInstanceColors; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    FGeometryScriptMeshReadLOD RequestedLOD; // 0x4 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FGeometryScriptCopyMeshFromComponentOptions) == 0xc, "Size mismatch for FGeometryScriptCopyMeshFromComponentOptions");
static_assert(offsetof(FGeometryScriptCopyMeshFromComponentOptions, bWantNormals) == 0x0, "Offset mismatch for FGeometryScriptCopyMeshFromComponentOptions::bWantNormals");
static_assert(offsetof(FGeometryScriptCopyMeshFromComponentOptions, bWantTangents) == 0x1, "Offset mismatch for FGeometryScriptCopyMeshFromComponentOptions::bWantTangents");
static_assert(offsetof(FGeometryScriptCopyMeshFromComponentOptions, bWantInstanceColors) == 0x2, "Offset mismatch for FGeometryScriptCopyMeshFromComponentOptions::bWantInstanceColors");
static_assert(offsetof(FGeometryScriptCopyMeshFromComponentOptions, RequestedLOD) == 0x4, "Offset mismatch for FGeometryScriptCopyMeshFromComponentOptions::RequestedLOD");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGeometryScriptDetermineMeshOcclusionOptions
{
    double SamplingDensity; // 0x0 (Size: 0x8, Type: DoubleProperty)
    bool bDoubleSided; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    int32_t NumSearchDirections; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FGeometryScriptDetermineMeshOcclusionOptions) == 0x10, "Size mismatch for FGeometryScriptDetermineMeshOcclusionOptions");
static_assert(offsetof(FGeometryScriptDetermineMeshOcclusionOptions, SamplingDensity) == 0x0, "Offset mismatch for FGeometryScriptDetermineMeshOcclusionOptions::SamplingDensity");
static_assert(offsetof(FGeometryScriptDetermineMeshOcclusionOptions, bDoubleSided) == 0x8, "Offset mismatch for FGeometryScriptDetermineMeshOcclusionOptions::bDoubleSided");
static_assert(offsetof(FGeometryScriptDetermineMeshOcclusionOptions, NumSearchDirections) == 0xc, "Offset mismatch for FGeometryScriptDetermineMeshOcclusionOptions::NumSearchDirections");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGeometryScriptSampleTextureOptions
{
    uint8_t SamplingMethod; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bWrap; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x6]; // 0x2 (Size: 0x6, Type: PaddingProperty)
    FVector2D UVScale; // 0x8 (Size: 0x10, Type: StructProperty)
    FVector2D UVOffset; // 0x18 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FGeometryScriptSampleTextureOptions) == 0x28, "Size mismatch for FGeometryScriptSampleTextureOptions");
static_assert(offsetof(FGeometryScriptSampleTextureOptions, SamplingMethod) == 0x0, "Offset mismatch for FGeometryScriptSampleTextureOptions::SamplingMethod");
static_assert(offsetof(FGeometryScriptSampleTextureOptions, bWrap) == 0x1, "Offset mismatch for FGeometryScriptSampleTextureOptions::bWrap");
static_assert(offsetof(FGeometryScriptSampleTextureOptions, UVScale) == 0x8, "Offset mismatch for FGeometryScriptSampleTextureOptions::UVScale");
static_assert(offsetof(FGeometryScriptSampleTextureOptions, UVOffset) == 0x18, "Offset mismatch for FGeometryScriptSampleTextureOptions::UVOffset");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FComputeDistanceFieldSettings
{
    uint8_t ComputeMode; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float NarrowBandWidth; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t NarrowBandUnits; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    FIntVector VoxelsPerDimensions; // 0xc (Size: 0xc, Type: StructProperty)
    bool bRequirePower2; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FComputeDistanceFieldSettings) == 0x1c, "Size mismatch for FComputeDistanceFieldSettings");
static_assert(offsetof(FComputeDistanceFieldSettings, ComputeMode) == 0x0, "Offset mismatch for FComputeDistanceFieldSettings::ComputeMode");
static_assert(offsetof(FComputeDistanceFieldSettings, NarrowBandWidth) == 0x4, "Offset mismatch for FComputeDistanceFieldSettings::NarrowBandWidth");
static_assert(offsetof(FComputeDistanceFieldSettings, NarrowBandUnits) == 0x8, "Offset mismatch for FComputeDistanceFieldSettings::NarrowBandUnits");
static_assert(offsetof(FComputeDistanceFieldSettings, VoxelsPerDimensions) == 0xc, "Offset mismatch for FComputeDistanceFieldSettings::VoxelsPerDimensions");
static_assert(offsetof(FComputeDistanceFieldSettings, bRequirePower2) == 0x18, "Offset mismatch for FComputeDistanceFieldSettings::bRequirePower2");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDistanceFieldToTextureSettings
{
    float Scale; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Offset; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDistanceFieldToTextureSettings) == 0x8, "Size mismatch for FDistanceFieldToTextureSettings");
static_assert(offsetof(FDistanceFieldToTextureSettings, Scale) == 0x0, "Offset mismatch for FDistanceFieldToTextureSettings::Scale");
static_assert(offsetof(FDistanceFieldToTextureSettings, Offset) == 0x4, "Offset mismatch for FDistanceFieldToTextureSettings::Offset");

