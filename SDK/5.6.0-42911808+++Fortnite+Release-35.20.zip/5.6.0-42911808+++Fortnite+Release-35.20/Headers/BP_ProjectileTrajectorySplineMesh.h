/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_ProjectileTrajectorySplineMesh
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x740 (Inherited: 0x1af0, Single: 0xffffec50)
class UBP_ProjectileTrajectorySplineMesh_C : public USplineMeshComponent
{
public:
};

static_assert(sizeof(UBP_ProjectileTrajectorySplineMesh_C) == 0x740, "Size mismatch for UBP_ProjectileTrajectorySplineMesh_C");

