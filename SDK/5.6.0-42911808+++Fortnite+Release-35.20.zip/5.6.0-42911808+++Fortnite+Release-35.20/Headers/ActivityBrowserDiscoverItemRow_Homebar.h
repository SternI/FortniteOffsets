/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserDiscoverItemRow_Homebar
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DiscoveryBrowserUI.h"
#include "UMG.h"
#include "Engine.h"
#include "TabScreens.h"
#include "ActivityBrowserArrowButton.h"
#include "CommonUI.h"

// Size: 0x4f0 (Inherited: 0xf48, Single: 0xfffff5a8)
class UActivityBrowserDiscoverItemRow_Homebar_C : public UFortDiscoverItemBrowserRow
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x440 (Size: 0x8, Type: StructProperty)
    UWBP_LoadingMorePages_C* WBP_LoadingMorePages; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* VBContent; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UImage* InactiveOverlayDim; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UCommonBorder* InactiveDarken; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowActiveInactiveAnim; // 0x468 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowMoveUpOutOfViewAnim; // 0x470 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowMoveDownIntoView; // 0x478 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnPeek; // 0x480 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnLoadingMore; // 0x488 (Size: 0x8, Type: ObjectProperty)
    TArray<UActivityBrowserArrowButton_C*> ArrowButtons; // 0x490 (Size: 0x10, Type: ArrayProperty)
    FName FontHoverAnimateParam; // 0x4a0 (Size: 0x4, Type: NameProperty)
    FName FontPressedAnimateParam; // 0x4a4 (Size: 0x4, Type: NameProperty)
    bool IsWaitingForInactiveAnim; // 0x4a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4a9[0x7]; // 0x4a9 (Size: 0x7, Type: PaddingProperty)
    double LoadingMoreDisplayDelay; // 0x4b0 (Size: 0x8, Type: DoubleProperty)
    bool IsLoadingMoreVisible; // 0x4b8 (Size: 0x1, Type: BoolProperty)
    bool IsLoadingMoreQueryActive; // 0x4b9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4ba[0x6]; // 0x4ba (Size: 0x6, Type: PaddingProperty)
    FTimerHandle LoadingMoreDelayTimer; // 0x4c0 (Size: 0x8, Type: StructProperty)
    uint8_t OnRowBroadcastClickToDiscover[0x10]; // 0x4c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    double EntriesSpacing; // 0x4d8 (Size: 0x8, Type: DoubleProperty)
    FString RowPanelName; // 0x4e0 (Size: 0x10, Type: StrProperty)

public:
    virtual void Destruct(); // 0x288a61c (Index: 0x3, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x4, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnRowBroadcastClickToDiscover__DelegateSignature(); // 0x288a61c (Index: 0xa, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void ResetOnPeekAnimation(); // 0x288a61c (Index: 0x10, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ResetOnRowActiveInactiveAnimation(bool& IsRowActive); // 0x288a61c (Index: 0x11, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SnapToEndOfAnimation(UWidgetAnimation*& InAnimation, TEnumAsByte<EUMGSequencePlayMode>& PlayMode); // 0x288a61c (Index: 0x12, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateNewRow(bool& IsActive, bool& PlayAnimation); // 0x288a61c (Index: 0x13, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateVisibility(); // 0x288a61c (Index: 0x14, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnCategoryItemChanged(bool& const bPlayAnimation, const FName CategoryPanelName); // 0x288a61c (Index: 0x8, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnRowIsActiveChanged(bool& const bIsActive); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowMoveDown(bool& const bMovingOffscreen); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowMoveUp(bool& const bMovingOffscreen); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowPeekStateChanged(bool& const bIsInPeekState); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UActivityBrowserDiscoverItemRow_Homebar_C) == 0x4f0, "Size mismatch for UActivityBrowserDiscoverItemRow_Homebar_C");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, UberGraphFrame) == 0x440, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::UberGraphFrame");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, WBP_LoadingMorePages) == 0x448, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::WBP_LoadingMorePages");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, VBContent) == 0x450, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::VBContent");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, InactiveOverlayDim) == 0x458, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::InactiveOverlayDim");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, InactiveDarken) == 0x460, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::InactiveDarken");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, OnRowActiveInactiveAnim) == 0x468, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::OnRowActiveInactiveAnim");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, OnRowMoveUpOutOfViewAnim) == 0x470, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::OnRowMoveUpOutOfViewAnim");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, OnRowMoveDownIntoView) == 0x478, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::OnRowMoveDownIntoView");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, OnPeek) == 0x480, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::OnPeek");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, OnLoadingMore) == 0x488, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::OnLoadingMore");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, ArrowButtons) == 0x490, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::ArrowButtons");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, FontHoverAnimateParam) == 0x4a0, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::FontHoverAnimateParam");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, FontPressedAnimateParam) == 0x4a4, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::FontPressedAnimateParam");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, IsWaitingForInactiveAnim) == 0x4a8, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::IsWaitingForInactiveAnim");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, LoadingMoreDisplayDelay) == 0x4b0, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::LoadingMoreDisplayDelay");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, IsLoadingMoreVisible) == 0x4b8, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::IsLoadingMoreVisible");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, IsLoadingMoreQueryActive) == 0x4b9, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::IsLoadingMoreQueryActive");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, LoadingMoreDelayTimer) == 0x4c0, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::LoadingMoreDelayTimer");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, OnRowBroadcastClickToDiscover) == 0x4c8, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::OnRowBroadcastClickToDiscover");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, EntriesSpacing) == 0x4d8, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::EntriesSpacing");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_Homebar_C, RowPanelName) == 0x4e0, "Offset mismatch for UActivityBrowserDiscoverItemRow_Homebar_C::RowPanelName");

