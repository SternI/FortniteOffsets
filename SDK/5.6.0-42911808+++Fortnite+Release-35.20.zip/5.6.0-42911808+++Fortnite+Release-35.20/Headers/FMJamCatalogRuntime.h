/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamCatalogRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DeveloperSettings.h"
#include "Engine.h"
#include "SparksCMS.h"
#include "ModularGameplay.h"
#include "CoreUObject.h"
#include "HarmonixDsp.h"
#include "HarmonixMidi.h"
#include "GameplayTags.h"

// Size: 0x48 (Inherited: 0x58, Single: 0xfffffff0)
class UFMJamCatalogDeveloperSettings : public UDeveloperSettings
{
public:
    bool bAddDebugJamSongLoadoutWheel; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bOverrideJamSongLoadout; // 0x31 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x6]; // 0x32 (Size: 0x6, Type: PaddingProperty)
    TArray<FName> JamSongLoadout; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFMJamCatalogDeveloperSettings) == 0x48, "Size mismatch for UFMJamCatalogDeveloperSettings");
static_assert(offsetof(UFMJamCatalogDeveloperSettings, bAddDebugJamSongLoadoutWheel) == 0x30, "Offset mismatch for UFMJamCatalogDeveloperSettings::bAddDebugJamSongLoadoutWheel");
static_assert(offsetof(UFMJamCatalogDeveloperSettings, bOverrideJamSongLoadout) == 0x31, "Offset mismatch for UFMJamCatalogDeveloperSettings::bOverrideJamSongLoadout");
static_assert(offsetof(UFMJamCatalogDeveloperSettings, JamSongLoadout) == 0x38, "Offset mismatch for UFMJamCatalogDeveloperSettings::JamSongLoadout");

// Size: 0x128 (Inherited: 0x88, Single: 0xa0)
class UFMJamLoop : public UPrimaryDataAsset
{
public:
    TSoftObjectPtr<UMidiFile*> MidiFileMajor; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMidiFile*> MidiFileMinor; // 0x50 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFusionPatch*> FusionPatchMajor; // 0x70 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFusionPatch*> FusionPatchMinor; // 0x90 (Size: 0x20, Type: SoftObjectProperty)
    bool bOverrideDefaultTransposition; // 0xb0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b1[0x7]; // 0xb1 (Size: 0x7, Type: PaddingProperty)
    TMap<int32_t, EMusicKey> Transposes; // 0xb8 (Size: 0x50, Type: MapProperty)
    TSoftObjectPtr<UFMJamSong*> Song; // 0x108 (Size: 0x20, Type: SoftObjectProperty)

public:
    EMusicKey GetKey() const; // 0x1079649c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFMJamLoopType GetLoopType() const; // 0x107965f8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetMajorMidi(TSoftObjectPtr<UMidiFile*>& OutMetasoundMidi, TSoftObjectPtr<UFusionPatch*>& OutMetasoundFusion) const; // 0x10796944 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetMidi(EMusicKeyMode& const Mode, TSoftObjectPtr<UMidiFile*>& OutMetasoundMidi, TSoftObjectPtr<UFusionPatch*>& OutMetasoundFusion) const; // 0x10796cf8 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetMinorMidi(TSoftObjectPtr<UMidiFile*>& OutMetasoundMidi, TSoftObjectPtr<UFusionPatch*>& OutMetasoundFusion) const; // 0x10797190 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    int32_t GetSemitoneTranspose(EMusicKey& const ToKey) const; // 0x10797544 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFMJamSong* GetSong() const; // 0x1079767c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasPitch() const; // 0x10797b7c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFMJamLoop) == 0x128, "Size mismatch for UFMJamLoop");
static_assert(offsetof(UFMJamLoop, MidiFileMajor) == 0x30, "Offset mismatch for UFMJamLoop::MidiFileMajor");
static_assert(offsetof(UFMJamLoop, MidiFileMinor) == 0x50, "Offset mismatch for UFMJamLoop::MidiFileMinor");
static_assert(offsetof(UFMJamLoop, FusionPatchMajor) == 0x70, "Offset mismatch for UFMJamLoop::FusionPatchMajor");
static_assert(offsetof(UFMJamLoop, FusionPatchMinor) == 0x90, "Offset mismatch for UFMJamLoop::FusionPatchMinor");
static_assert(offsetof(UFMJamLoop, bOverrideDefaultTransposition) == 0xb0, "Offset mismatch for UFMJamLoop::bOverrideDefaultTransposition");
static_assert(offsetof(UFMJamLoop, Transposes) == 0xb8, "Offset mismatch for UFMJamLoop::Transposes");
static_assert(offsetof(UFMJamLoop, Song) == 0x108, "Offset mismatch for UFMJamLoop::Song");

// Size: 0xd8 (Inherited: 0x138, Single: 0xffffffa0)
class UFMJamSong : public USparksSongData
{
public:
    int32_t Tempo; // 0xb0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_b4[0x4]; // 0xb4 (Size: 0x4, Type: PaddingProperty)
    UFMJamLoop* Lead; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UFMJamLoop* Misc; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UFMJamLoop* Bass; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UFMJamLoop* Beat; // 0xd0 (Size: 0x8, Type: ObjectProperty)

public:
    UFMJamLoop* GetLoop(EFMJamLoopType& const LoopType) const; // 0x107964c0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFMJamLoopType GetLoopTypeForLoop(UFMJamLoop*& const Loop) const; // 0x10796724 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetTempo() const; // 0x10797b50 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFMJamSong) == 0xd8, "Size mismatch for UFMJamSong");
static_assert(offsetof(UFMJamSong, Tempo) == 0xb0, "Offset mismatch for UFMJamSong::Tempo");
static_assert(offsetof(UFMJamSong, Lead) == 0xb8, "Offset mismatch for UFMJamSong::Lead");
static_assert(offsetof(UFMJamSong, Misc) == 0xc0, "Offset mismatch for UFMJamSong::Misc");
static_assert(offsetof(UFMJamSong, Bass) == 0xc8, "Offset mismatch for UFMJamSong::Bass");
static_assert(offsetof(UFMJamSong, Beat) == 0xd0, "Offset mismatch for UFMJamSong::Beat");

// Size: 0x178 (Inherited: 0x250, Single: 0xffffff28)
class UFMJamSongCatalog : public UGameStateComponent
{
public:
    uint8_t Pad_b8[0x58]; // 0xb8 (Size: 0x58, Type: PaddingProperty)
    TMap<UFMJamSong*, FName> SongsByShortName; // 0x110 (Size: 0x50, Type: MapProperty)
    USparksSongCatalog* CachedCMSCatalog; // 0x160 (Size: 0x8, Type: ObjectProperty)
    int32_t NumCMSRetries; // 0x168 (Size: 0x4, Type: IntProperty)
    bool bHaveSongCatalog; // 0x16c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_16d[0xb]; // 0x16d (Size: 0xb, Type: PaddingProperty)

public:
    static UFMJamSongCatalog* GetFMJamSongCatalog(UObject*& const WorldContextObject); // 0x10796374 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static EFMJamLoopType GetLoopTypeByTag(const FGameplayTag LoopTag); // 0x10796644 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FText GetLoopTypeText(const EFMJamLoopType LoopType); // 0x1079685c (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    UFMJamSong* GetSongByShortName(FName& const ShortName) const; // 0x107976a0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCatalogData* GetSongCatalogEntryByShortName(FName& const ShortName) const; // 0x10797828 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HaveCMSSongCatalog() const; // 0x10797bac (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static UFMJamSongCatalog* TryGetFMJamSongCatalog(UObject*& const WorldContextObject); // 0x10797bc4 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UFMJamSongCatalog) == 0x178, "Size mismatch for UFMJamSongCatalog");
static_assert(offsetof(UFMJamSongCatalog, SongsByShortName) == 0x110, "Offset mismatch for UFMJamSongCatalog::SongsByShortName");
static_assert(offsetof(UFMJamSongCatalog, CachedCMSCatalog) == 0x160, "Offset mismatch for UFMJamSongCatalog::CachedCMSCatalog");
static_assert(offsetof(UFMJamSongCatalog, NumCMSRetries) == 0x168, "Offset mismatch for UFMJamSongCatalog::NumCMSRetries");
static_assert(offsetof(UFMJamSongCatalog, bHaveSongCatalog) == 0x16c, "Offset mismatch for UFMJamSongCatalog::bHaveSongCatalog");

