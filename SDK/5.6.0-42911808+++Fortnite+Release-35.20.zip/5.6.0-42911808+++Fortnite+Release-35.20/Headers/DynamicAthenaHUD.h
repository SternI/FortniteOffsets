/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicAthenaHUD
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DynamicUI.h"
#include "Engine.h"
#include "FortniteGame.h"

// Size: 0x320 (Inherited: 0x598, Single: 0xfffffd88)
class ADynamicAthenaHUDDirector : public ADynamicUIDirectorBase
{
public:
    UDynamicUIScene* VehicleHUDScene; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* CreativeQuickbarScene; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* PlayerMessagesScene; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* TournamentScene; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* ArenaTournamentScene; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* BuildWatermarkScene; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* LoadingMessageScene; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* LocalPlayerInfoScene; // 0x300 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* BusReticleScene; // 0x308 (Size: 0x8, Type: ObjectProperty)
    TArray<UDynamicUIScene*> AddedScenes; // 0x310 (Size: 0x10, Type: ArrayProperty)

private:
    void HandleCreativeQuickbarEquippedChanged(bool& bIsQuickbarEquipped); // 0x113c6ee8 (Index: 0x0, Flags: Final|Native|Private)
    void HandleEnterBus(AController*& Controller); // 0x113c7014 (Index: 0x1, Flags: Final|Native|Private)
    void HandleEnterVehicle(); // 0x113c7140 (Index: 0x2, Flags: Final|Native|Private)
    void HandleExitBus(AController*& Controller); // 0x113c7154 (Index: 0x3, Flags: Final|Native|Private)
    void HandleExitVehicle(); // 0x113c7280 (Index: 0x4, Flags: Final|Native|Private)
    void HandleHUDElementVisibilityRefreshed(); // 0x113c7294 (Index: 0x5, Flags: Final|Native|Private)
    void HandleInGameLoadScreenChanged(AFortPlayerControllerAthena*& PlayerController, bool& bEnableLoadScreen, FText& HUDReasonText); // 0x113c72a8 (Index: 0x6, Flags: Final|Native|Private)
    void HandleNpcHired(AFortPawn*& const NpcHiredPawn); // 0x113c75ac (Index: 0x7, Flags: Final|Native|Private)
};

static_assert(sizeof(ADynamicAthenaHUDDirector) == 0x320, "Size mismatch for ADynamicAthenaHUDDirector");
static_assert(offsetof(ADynamicAthenaHUDDirector, VehicleHUDScene) == 0x2c8, "Offset mismatch for ADynamicAthenaHUDDirector::VehicleHUDScene");
static_assert(offsetof(ADynamicAthenaHUDDirector, CreativeQuickbarScene) == 0x2d0, "Offset mismatch for ADynamicAthenaHUDDirector::CreativeQuickbarScene");
static_assert(offsetof(ADynamicAthenaHUDDirector, PlayerMessagesScene) == 0x2d8, "Offset mismatch for ADynamicAthenaHUDDirector::PlayerMessagesScene");
static_assert(offsetof(ADynamicAthenaHUDDirector, TournamentScene) == 0x2e0, "Offset mismatch for ADynamicAthenaHUDDirector::TournamentScene");
static_assert(offsetof(ADynamicAthenaHUDDirector, ArenaTournamentScene) == 0x2e8, "Offset mismatch for ADynamicAthenaHUDDirector::ArenaTournamentScene");
static_assert(offsetof(ADynamicAthenaHUDDirector, BuildWatermarkScene) == 0x2f0, "Offset mismatch for ADynamicAthenaHUDDirector::BuildWatermarkScene");
static_assert(offsetof(ADynamicAthenaHUDDirector, LoadingMessageScene) == 0x2f8, "Offset mismatch for ADynamicAthenaHUDDirector::LoadingMessageScene");
static_assert(offsetof(ADynamicAthenaHUDDirector, LocalPlayerInfoScene) == 0x300, "Offset mismatch for ADynamicAthenaHUDDirector::LocalPlayerInfoScene");
static_assert(offsetof(ADynamicAthenaHUDDirector, BusReticleScene) == 0x308, "Offset mismatch for ADynamicAthenaHUDDirector::BusReticleScene");
static_assert(offsetof(ADynamicAthenaHUDDirector, AddedScenes) == 0x310, "Offset mismatch for ADynamicAthenaHUDDirector::AddedScenes");

