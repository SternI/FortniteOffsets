/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosCaching
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "MovieSceneTracks.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "MovieScene.h"

// Size: 0x40 (Inherited: 0xf8, Single: 0xffffff48)
class UMovieSceneSpawnableChaosCacheBinding : public UMovieSceneSpawnableActorBinding
{
public:
};

static_assert(sizeof(UMovieSceneSpawnableChaosCacheBinding) == 0x40, "Size mismatch for UMovieSceneSpawnableChaosCacheBinding");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UChaosCacheCollection : public UObject
{
public:
    TArray<UChaosCache*> Caches; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t InterpolationMode; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UChaosCacheCollection) == 0x40, "Size mismatch for UChaosCacheCollection");
static_assert(offsetof(UChaosCacheCollection, Caches) == 0x28, "Offset mismatch for UChaosCacheCollection::Caches");
static_assert(offsetof(UChaosCacheCollection, InterpolationMode) == 0x38, "Offset mismatch for UChaosCacheCollection::InterpolationMode");

// Size: 0x360 (Inherited: 0x2d0, Single: 0x90)
class AChaosCacheManager : public AActor
{
public:
    UChaosCacheCollection* CacheCollection; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    uint8_t CacheMode; // 0x2b0 (Size: 0x1, Type: EnumProperty)
    uint8_t StartMode; // 0x2b1 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2b2[0x2]; // 0x2b2 (Size: 0x2, Type: PaddingProperty)
    float StartTime; // 0x2b4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2b8[0x8]; // 0x2b8 (Size: 0x8, Type: PaddingProperty)
    TArray<FObservedComponent> ObservedComponents; // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_2d0[0x90]; // 0x2d0 (Size: 0x90, Type: PaddingProperty)

public:
    void ResetAllComponentTransforms(); // 0xc5ce538 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void ResetSingleTransform(int32_t& InIndex); // 0xc5ce54c (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetCurrentTime(float& CurrentTime); // 0xc5ce7fc (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetStartTime(float& InStartTime); // 0xc5ce7fc (Index: 0x6, Flags: Final|RequiredAPI|Native|Public)

protected:
    void EnablePlayback(int32_t& Index, bool& bEnable); // 0xc5ce0ac (Index: 0x0, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
    void EnablePlaybackByCache(FName& InCacheName, bool& bEnable); // 0xc5ce2c8 (Index: 0x1, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
    void SetCacheCollection(UChaosCacheCollection*& InCacheCollection); // 0xc5ce6d0 (Index: 0x4, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
    void TriggerAll(); // 0xc5ce934 (Index: 0x7, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
    void TriggerComponent(UPrimitiveComponent*& InComponent); // 0xc5ce9bc (Index: 0x8, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
    void TriggerComponentByCache(FName& InCacheName); // 0xc5ceae8 (Index: 0x9, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(AChaosCacheManager) == 0x360, "Size mismatch for AChaosCacheManager");
static_assert(offsetof(AChaosCacheManager, CacheCollection) == 0x2a8, "Offset mismatch for AChaosCacheManager::CacheCollection");
static_assert(offsetof(AChaosCacheManager, CacheMode) == 0x2b0, "Offset mismatch for AChaosCacheManager::CacheMode");
static_assert(offsetof(AChaosCacheManager, StartMode) == 0x2b1, "Offset mismatch for AChaosCacheManager::StartMode");
static_assert(offsetof(AChaosCacheManager, StartTime) == 0x2b4, "Offset mismatch for AChaosCacheManager::StartTime");
static_assert(offsetof(AChaosCacheManager, ObservedComponents) == 0x2c0, "Offset mismatch for AChaosCacheManager::ObservedComponents");

// Size: 0x360 (Inherited: 0x630, Single: 0xfffffd30)
class AChaosCachePlayer : public AChaosCacheManager
{
public:
};

static_assert(sizeof(AChaosCachePlayer) == 0x360, "Size mismatch for AChaosCachePlayer");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChaosCacheData : public UInterface
{
public:
};

static_assert(sizeof(UChaosCacheData) == 0x28, "Size mismatch for UChaosCacheData");

// Size: 0x390 (Inherited: 0x28, Single: 0x368)
class UChaosCache : public UObject
{
public:
    float RecordedDuration; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint32_t NumRecordedFrames; // 0x2c (Size: 0x4, Type: UInt32Property)
    uint8_t InterpolationMode; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    TArray<int32_t> TrackToParticle; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FPerParticleCacheData> ParticleTracks; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ChannelCurveToParticle; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TMap<FRichCurves, FName> ChannelsTracks; // 0x68 (Size: 0x50, Type: MapProperty)
    TMap<FCompressedRichCurves, FName> CompressedChannelsTracks; // 0xb8 (Size: 0x50, Type: MapProperty)
    TMap<FRichCurve, FName> CurveData; // 0x108 (Size: 0x50, Type: MapProperty)
    TMap<FParticleTransformTrack, FName> NamedTransformTracks; // 0x158 (Size: 0x50, Type: MapProperty)
    bool bCompressChannels; // 0x1a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a9[0x3]; // 0x1a9 (Size: 0x3, Type: PaddingProperty)
    float ChannelsCompressionErrorThreshold; // 0x1ac (Size: 0x4, Type: FloatProperty)
    float ChannelsCompressionSampleRate; // 0x1b0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1b4[0x4]; // 0x1b4 (Size: 0x4, Type: PaddingProperty)
    TScriptInterface<Class> CacheData; // 0x1b8 (Size: 0x10, Type: InterfaceProperty)
    TMap<FCacheEventTrack, FName> EventTracks; // 0x1c8 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_218[0x8]; // 0x218 (Size: 0x8, Type: PaddingProperty)
    FCacheSpawnableTemplate Spawnable; // 0x220 (Size: 0xd0, Type: StructProperty)
    FGuid AdapterGuid; // 0x2f0 (Size: 0x10, Type: StructProperty)
    int32_t Version; // 0x300 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_304[0x8c]; // 0x304 (Size: 0x8c, Type: PaddingProperty)
};

static_assert(sizeof(UChaosCache) == 0x390, "Size mismatch for UChaosCache");
static_assert(offsetof(UChaosCache, RecordedDuration) == 0x28, "Offset mismatch for UChaosCache::RecordedDuration");
static_assert(offsetof(UChaosCache, NumRecordedFrames) == 0x2c, "Offset mismatch for UChaosCache::NumRecordedFrames");
static_assert(offsetof(UChaosCache, InterpolationMode) == 0x30, "Offset mismatch for UChaosCache::InterpolationMode");
static_assert(offsetof(UChaosCache, TrackToParticle) == 0x38, "Offset mismatch for UChaosCache::TrackToParticle");
static_assert(offsetof(UChaosCache, ParticleTracks) == 0x48, "Offset mismatch for UChaosCache::ParticleTracks");
static_assert(offsetof(UChaosCache, ChannelCurveToParticle) == 0x58, "Offset mismatch for UChaosCache::ChannelCurveToParticle");
static_assert(offsetof(UChaosCache, ChannelsTracks) == 0x68, "Offset mismatch for UChaosCache::ChannelsTracks");
static_assert(offsetof(UChaosCache, CompressedChannelsTracks) == 0xb8, "Offset mismatch for UChaosCache::CompressedChannelsTracks");
static_assert(offsetof(UChaosCache, CurveData) == 0x108, "Offset mismatch for UChaosCache::CurveData");
static_assert(offsetof(UChaosCache, NamedTransformTracks) == 0x158, "Offset mismatch for UChaosCache::NamedTransformTracks");
static_assert(offsetof(UChaosCache, bCompressChannels) == 0x1a8, "Offset mismatch for UChaosCache::bCompressChannels");
static_assert(offsetof(UChaosCache, ChannelsCompressionErrorThreshold) == 0x1ac, "Offset mismatch for UChaosCache::ChannelsCompressionErrorThreshold");
static_assert(offsetof(UChaosCache, ChannelsCompressionSampleRate) == 0x1b0, "Offset mismatch for UChaosCache::ChannelsCompressionSampleRate");
static_assert(offsetof(UChaosCache, CacheData) == 0x1b8, "Offset mismatch for UChaosCache::CacheData");
static_assert(offsetof(UChaosCache, EventTracks) == 0x1c8, "Offset mismatch for UChaosCache::EventTracks");
static_assert(offsetof(UChaosCache, Spawnable) == 0x220, "Offset mismatch for UChaosCache::Spawnable");
static_assert(offsetof(UChaosCache, AdapterGuid) == 0x2f0, "Offset mismatch for UChaosCache::AdapterGuid");
static_assert(offsetof(UChaosCache, Version) == 0x300, "Offset mismatch for UChaosCache::Version");

// Size: 0x138 (Inherited: 0x300, Single: 0xfffffe38)
class UMovieSceneChaosCacheSection : public UMovieSceneBaseCacheSection
{
public:
    FMovieSceneChaosCacheParams Params; // 0x110 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UMovieSceneChaosCacheSection) == 0x138, "Size mismatch for UMovieSceneChaosCacheSection");
static_assert(offsetof(UMovieSceneChaosCacheSection, Params) == 0x110, "Offset mismatch for UMovieSceneChaosCacheSection::Params");

// Size: 0x128 (Inherited: 0x308, Single: 0xfffffe20)
class UMovieSceneChaosCacheTrack : public UMovieSceneNameableTrack
{
public:
    uint8_t Pad_110[0x8]; // 0x110 (Size: 0x8, Type: PaddingProperty)
    TArray<UMovieSceneSection*> AnimationSections; // 0x118 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UMovieSceneChaosCacheTrack) == 0x128, "Size mismatch for UMovieSceneChaosCacheTrack");
static_assert(offsetof(UMovieSceneChaosCacheTrack, AnimationSections) == 0x118, "Offset mismatch for UMovieSceneChaosCacheTrack::AnimationSections");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FCacheEventBase
{
};

static_assert(sizeof(FCacheEventBase) == 0x8, "Size mismatch for FCacheEventBase");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FEnableStateEvent : FCacheEventBase
{
    int32_t Index; // 0x8 (Size: 0x4, Type: IntProperty)
    bool bEnable; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FEnableStateEvent) == 0x10, "Size mismatch for FEnableStateEvent");
static_assert(offsetof(FEnableStateEvent, Index) == 0x8, "Offset mismatch for FEnableStateEvent::Index");
static_assert(offsetof(FEnableStateEvent, bEnable) == 0xc, "Offset mismatch for FEnableStateEvent::bEnable");

// Size: 0xc0 (Inherited: 0x8, Single: 0xb8)
struct FBreakingEvent : FCacheEventBase
{
    int32_t Index; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FVector Location; // 0x10 (Size: 0x18, Type: StructProperty)
    FQuat orientation; // 0x30 (Size: 0x20, Type: StructProperty)
    FVector Velocity; // 0x50 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity; // 0x68 (Size: 0x18, Type: StructProperty)
    float Mass; // 0x80 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
    FVector BoundingBoxMin; // 0x88 (Size: 0x18, Type: StructProperty)
    FVector BoundingBoxMax; // 0xa0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FBreakingEvent) == 0xc0, "Size mismatch for FBreakingEvent");
static_assert(offsetof(FBreakingEvent, Index) == 0x8, "Offset mismatch for FBreakingEvent::Index");
static_assert(offsetof(FBreakingEvent, Location) == 0x10, "Offset mismatch for FBreakingEvent::Location");
static_assert(offsetof(FBreakingEvent, orientation) == 0x30, "Offset mismatch for FBreakingEvent::orientation");
static_assert(offsetof(FBreakingEvent, Velocity) == 0x50, "Offset mismatch for FBreakingEvent::Velocity");
static_assert(offsetof(FBreakingEvent, AngularVelocity) == 0x68, "Offset mismatch for FBreakingEvent::AngularVelocity");
static_assert(offsetof(FBreakingEvent, Mass) == 0x80, "Offset mismatch for FBreakingEvent::Mass");
static_assert(offsetof(FBreakingEvent, BoundingBoxMin) == 0x88, "Offset mismatch for FBreakingEvent::BoundingBoxMin");
static_assert(offsetof(FBreakingEvent, BoundingBoxMax) == 0xa0, "Offset mismatch for FBreakingEvent::BoundingBoxMax");

// Size: 0xf0 (Inherited: 0x8, Single: 0xe8)
struct FCollisionEvent : FCacheEventBase
{
    FVector Location; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector AccumulatedImpulse; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector Normal; // 0x38 (Size: 0x18, Type: StructProperty)
    FVector Velocity1; // 0x50 (Size: 0x18, Type: StructProperty)
    FVector Velocity2; // 0x68 (Size: 0x18, Type: StructProperty)
    FVector DeltaVelocity1; // 0x80 (Size: 0x18, Type: StructProperty)
    FVector DeltaVelocity2; // 0x98 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity1; // 0xb0 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity2; // 0xc8 (Size: 0x18, Type: StructProperty)
    float Mass1; // 0xe0 (Size: 0x4, Type: FloatProperty)
    float Mass2; // 0xe4 (Size: 0x4, Type: FloatProperty)
    float PenetrationDepth; // 0xe8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_ec[0x4]; // 0xec (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCollisionEvent) == 0xf0, "Size mismatch for FCollisionEvent");
static_assert(offsetof(FCollisionEvent, Location) == 0x8, "Offset mismatch for FCollisionEvent::Location");
static_assert(offsetof(FCollisionEvent, AccumulatedImpulse) == 0x20, "Offset mismatch for FCollisionEvent::AccumulatedImpulse");
static_assert(offsetof(FCollisionEvent, Normal) == 0x38, "Offset mismatch for FCollisionEvent::Normal");
static_assert(offsetof(FCollisionEvent, Velocity1) == 0x50, "Offset mismatch for FCollisionEvent::Velocity1");
static_assert(offsetof(FCollisionEvent, Velocity2) == 0x68, "Offset mismatch for FCollisionEvent::Velocity2");
static_assert(offsetof(FCollisionEvent, DeltaVelocity1) == 0x80, "Offset mismatch for FCollisionEvent::DeltaVelocity1");
static_assert(offsetof(FCollisionEvent, DeltaVelocity2) == 0x98, "Offset mismatch for FCollisionEvent::DeltaVelocity2");
static_assert(offsetof(FCollisionEvent, AngularVelocity1) == 0xb0, "Offset mismatch for FCollisionEvent::AngularVelocity1");
static_assert(offsetof(FCollisionEvent, AngularVelocity2) == 0xc8, "Offset mismatch for FCollisionEvent::AngularVelocity2");
static_assert(offsetof(FCollisionEvent, Mass1) == 0xe0, "Offset mismatch for FCollisionEvent::Mass1");
static_assert(offsetof(FCollisionEvent, Mass2) == 0xe4, "Offset mismatch for FCollisionEvent::Mass2");
static_assert(offsetof(FCollisionEvent, PenetrationDepth) == 0xe8, "Offset mismatch for FCollisionEvent::PenetrationDepth");

// Size: 0xb0 (Inherited: 0x8, Single: 0xa8)
struct FTrailingEvent : FCacheEventBase
{
    int32_t Index; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FVector Location; // 0x10 (Size: 0x18, Type: StructProperty)
    FQuat orientation; // 0x30 (Size: 0x20, Type: StructProperty)
    FVector Velocity; // 0x50 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity; // 0x68 (Size: 0x18, Type: StructProperty)
    FVector BoundingBoxMin; // 0x80 (Size: 0x18, Type: StructProperty)
    FVector BoundingBoxMax; // 0x98 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FTrailingEvent) == 0xb0, "Size mismatch for FTrailingEvent");
static_assert(offsetof(FTrailingEvent, Index) == 0x8, "Offset mismatch for FTrailingEvent::Index");
static_assert(offsetof(FTrailingEvent, Location) == 0x10, "Offset mismatch for FTrailingEvent::Location");
static_assert(offsetof(FTrailingEvent, orientation) == 0x30, "Offset mismatch for FTrailingEvent::orientation");
static_assert(offsetof(FTrailingEvent, Velocity) == 0x50, "Offset mismatch for FTrailingEvent::Velocity");
static_assert(offsetof(FTrailingEvent, AngularVelocity) == 0x68, "Offset mismatch for FTrailingEvent::AngularVelocity");
static_assert(offsetof(FTrailingEvent, BoundingBoxMin) == 0x80, "Offset mismatch for FTrailingEvent::BoundingBoxMin");
static_assert(offsetof(FTrailingEvent, BoundingBoxMax) == 0x98, "Offset mismatch for FTrailingEvent::BoundingBoxMax");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FCacheEventTrack
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UScriptStruct* Struct; // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<float> TimeStamps; // 0x10 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_20[0x18]; // 0x20 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FCacheEventTrack) == 0x38, "Size mismatch for FCacheEventTrack");
static_assert(offsetof(FCacheEventTrack, Name) == 0x0, "Offset mismatch for FCacheEventTrack::Name");
static_assert(offsetof(FCacheEventTrack, Struct) == 0x8, "Offset mismatch for FCacheEventTrack::Struct");
static_assert(offsetof(FCacheEventTrack, TimeStamps) == 0x10, "Offset mismatch for FCacheEventTrack::TimeStamps");

// Size: 0x180 (Inherited: 0x0, Single: 0x180)
struct FObservedComponent
{
    FName CacheName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FComponentReference ComponentRef; // 0x8 (Size: 0x28, Type: StructProperty)
    FSoftComponentReference SoftComponentRef; // 0x30 (Size: 0x40, Type: StructProperty)
    bool bIsSimulating; // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bPlaybackEnabled; // 0x71 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_72[0x6]; // 0x72 (Size: 0x6, Type: PaddingProperty)
    FDirectoryPath USDCacheDirectory; // 0x78 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_88[0xf8]; // 0x88 (Size: 0xf8, Type: PaddingProperty)
};

static_assert(sizeof(FObservedComponent) == 0x180, "Size mismatch for FObservedComponent");
static_assert(offsetof(FObservedComponent, CacheName) == 0x0, "Offset mismatch for FObservedComponent::CacheName");
static_assert(offsetof(FObservedComponent, ComponentRef) == 0x8, "Offset mismatch for FObservedComponent::ComponentRef");
static_assert(offsetof(FObservedComponent, SoftComponentRef) == 0x30, "Offset mismatch for FObservedComponent::SoftComponentRef");
static_assert(offsetof(FObservedComponent, bIsSimulating) == 0x70, "Offset mismatch for FObservedComponent::bIsSimulating");
static_assert(offsetof(FObservedComponent, bPlaybackEnabled) == 0x71, "Offset mismatch for FObservedComponent::bPlaybackEnabled");
static_assert(offsetof(FObservedComponent, USDCacheDirectory) == 0x78, "Offset mismatch for FObservedComponent::USDCacheDirectory");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FParticleTransformTrack
{
    FRawAnimSequenceTrack RawTransformTrack; // 0x0 (Size: 0x30, Type: StructProperty)
    float BeginOffset; // 0x30 (Size: 0x4, Type: FloatProperty)
    bool bDeactivateOnEnd; // 0x34 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_35[0x3]; // 0x35 (Size: 0x3, Type: PaddingProperty)
    TArray<float> KeyTimestamps; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FParticleTransformTrack) == 0x48, "Size mismatch for FParticleTransformTrack");
static_assert(offsetof(FParticleTransformTrack, RawTransformTrack) == 0x0, "Offset mismatch for FParticleTransformTrack::RawTransformTrack");
static_assert(offsetof(FParticleTransformTrack, BeginOffset) == 0x30, "Offset mismatch for FParticleTransformTrack::BeginOffset");
static_assert(offsetof(FParticleTransformTrack, bDeactivateOnEnd) == 0x34, "Offset mismatch for FParticleTransformTrack::bDeactivateOnEnd");
static_assert(offsetof(FParticleTransformTrack, KeyTimestamps) == 0x38, "Offset mismatch for FParticleTransformTrack::KeyTimestamps");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FPerParticleCacheData
{
    FParticleTransformTrack TransformData; // 0x0 (Size: 0x48, Type: StructProperty)
    TMap<FRichCurve, FName> CurveData; // 0x48 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FPerParticleCacheData) == 0x98, "Size mismatch for FPerParticleCacheData");
static_assert(offsetof(FPerParticleCacheData, TransformData) == 0x0, "Offset mismatch for FPerParticleCacheData::TransformData");
static_assert(offsetof(FPerParticleCacheData, CurveData) == 0x48, "Offset mismatch for FPerParticleCacheData::CurveData");

// Size: 0xd0 (Inherited: 0x0, Single: 0xd0)
struct FCacheSpawnableTemplate
{
    UObject* DuplicatedTemplate; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform InitialTransform; // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform ComponentTransform; // 0x70 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FCacheSpawnableTemplate) == 0xd0, "Size mismatch for FCacheSpawnableTemplate");
static_assert(offsetof(FCacheSpawnableTemplate, DuplicatedTemplate) == 0x0, "Offset mismatch for FCacheSpawnableTemplate::DuplicatedTemplate");
static_assert(offsetof(FCacheSpawnableTemplate, InitialTransform) == 0x10, "Offset mismatch for FCacheSpawnableTemplate::InitialTransform");
static_assert(offsetof(FCacheSpawnableTemplate, ComponentTransform) == 0x70, "Offset mismatch for FCacheSpawnableTemplate::ComponentTransform");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRichCurves
{
    TArray<FRichCurve> RichCurves; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRichCurves) == 0x10, "Size mismatch for FRichCurves");
static_assert(offsetof(FRichCurves, RichCurves) == 0x0, "Offset mismatch for FRichCurves::RichCurves");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCompressedRichCurves
{
    TArray<FCompressedRichCurve> CompressedRichCurves; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCompressedRichCurves) == 0x10, "Size mismatch for FCompressedRichCurves");
static_assert(offsetof(FCompressedRichCurves, CompressedRichCurves) == 0x0, "Offset mismatch for FCompressedRichCurves::CompressedRichCurves");

// Size: 0x28 (Inherited: 0x20, Single: 0x8)
struct FMovieSceneChaosCacheParams : FMovieSceneBaseCacheParams
{
    UChaosCacheCollection* CacheCollection; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FMovieSceneChaosCacheParams) == 0x28, "Size mismatch for FMovieSceneChaosCacheParams");
static_assert(offsetof(FMovieSceneChaosCacheParams, CacheCollection) == 0x20, "Offset mismatch for FMovieSceneChaosCacheParams::CacheCollection");

// Size: 0x30 (Inherited: 0x8, Single: 0x28)
struct FMovieSceneChaosCacheSectionTemplateParameters : FMovieSceneBaseCacheSectionTemplateParameters
{
    FMovieSceneChaosCacheParams ChaosCacheParams; // 0x8 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FMovieSceneChaosCacheSectionTemplateParameters) == 0x30, "Size mismatch for FMovieSceneChaosCacheSectionTemplateParameters");
static_assert(offsetof(FMovieSceneChaosCacheSectionTemplateParameters, ChaosCacheParams) == 0x8, "Offset mismatch for FMovieSceneChaosCacheSectionTemplateParameters::ChaosCacheParams");

// Size: 0x50 (Inherited: 0x30, Single: 0x20)
struct FMovieSceneChaosCacheSectionTemplate : FMovieSceneEvalTemplate
{
    FMovieSceneChaosCacheSectionTemplateParameters Params; // 0x20 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FMovieSceneChaosCacheSectionTemplate) == 0x50, "Size mismatch for FMovieSceneChaosCacheSectionTemplate");
static_assert(offsetof(FMovieSceneChaosCacheSectionTemplate, Params) == 0x20, "Offset mismatch for FMovieSceneChaosCacheSectionTemplate::Params");

