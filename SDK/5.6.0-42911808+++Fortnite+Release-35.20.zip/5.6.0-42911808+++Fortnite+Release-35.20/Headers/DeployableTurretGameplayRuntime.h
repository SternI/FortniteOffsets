/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DeployableTurretGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "AnimationBudgetAllocator.h"

// Size: 0x420 (Inherited: 0x408, Single: 0x18)
class UDeployableTurretAnimInstance : public UAnimInstance
{
public:
    uint8_t bIsAttacking : 1; // 0x3d8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsWindUp : 1; // 0x3d8:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsTracking : 1; // 0x3d8:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsWindDown : 1; // 0x3d8:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsDeactivated : 1; // 0x3d8:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsScanning : 1; // 0x3d8:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsAggro : 1; // 0x3d8:6 (Size: 0x1, Type: BoolProperty)
    uint8_t bFallAndDeployToDeactivated : 1; // 0x3d8:7 (Size: 0x1, Type: BoolProperty)
    uint8_t bFallAndDeployToScan : 1; // 0x3d9:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAggroToFire : 1; // 0x3d9:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bInterruptibleCurveOverThreshold : 1; // 0x3d9:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bTurnEndCurveOverThreshold : 1; // 0x3d9:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3da[0x2]; // 0x3da (Size: 0x2, Type: PaddingProperty)
    FName InterruptibleCurveName; // 0x3dc (Size: 0x4, Type: NameProperty)
    float InterruptibleCurveThreshold; // 0x3e0 (Size: 0x4, Type: FloatProperty)
    FName TurnEndCurveName; // 0x3e4 (Size: 0x4, Type: NameProperty)
    float TurnEndCurveThreshold; // 0x3e8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3ec[0x4]; // 0x3ec (Size: 0x4, Type: PaddingProperty)
    FRotator AimRotationInComponentSpace; // 0x3f0 (Size: 0x18, Type: StructProperty)
    FRotator SurfaceRotation; // 0x408 (Size: 0x18, Type: StructProperty)

protected:
    void SetNativeVariables(ABuildingGameplayActor*& const OwningTurretBGA, const FDeployableTurretBPAnimData AnimData); // 0x10129864 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UDeployableTurretAnimInstance) == 0x420, "Size mismatch for UDeployableTurretAnimInstance");
static_assert(offsetof(UDeployableTurretAnimInstance, bIsAttacking) == 0x3d8, "Offset mismatch for UDeployableTurretAnimInstance::bIsAttacking");
static_assert(offsetof(UDeployableTurretAnimInstance, bIsWindUp) == 0x3d8, "Offset mismatch for UDeployableTurretAnimInstance::bIsWindUp");
static_assert(offsetof(UDeployableTurretAnimInstance, bIsTracking) == 0x3d8, "Offset mismatch for UDeployableTurretAnimInstance::bIsTracking");
static_assert(offsetof(UDeployableTurretAnimInstance, bIsWindDown) == 0x3d8, "Offset mismatch for UDeployableTurretAnimInstance::bIsWindDown");
static_assert(offsetof(UDeployableTurretAnimInstance, bIsDeactivated) == 0x3d8, "Offset mismatch for UDeployableTurretAnimInstance::bIsDeactivated");
static_assert(offsetof(UDeployableTurretAnimInstance, bIsScanning) == 0x3d8, "Offset mismatch for UDeployableTurretAnimInstance::bIsScanning");
static_assert(offsetof(UDeployableTurretAnimInstance, bIsAggro) == 0x3d8, "Offset mismatch for UDeployableTurretAnimInstance::bIsAggro");
static_assert(offsetof(UDeployableTurretAnimInstance, bFallAndDeployToDeactivated) == 0x3d8, "Offset mismatch for UDeployableTurretAnimInstance::bFallAndDeployToDeactivated");
static_assert(offsetof(UDeployableTurretAnimInstance, bFallAndDeployToScan) == 0x3d9, "Offset mismatch for UDeployableTurretAnimInstance::bFallAndDeployToScan");
static_assert(offsetof(UDeployableTurretAnimInstance, bAggroToFire) == 0x3d9, "Offset mismatch for UDeployableTurretAnimInstance::bAggroToFire");
static_assert(offsetof(UDeployableTurretAnimInstance, bInterruptibleCurveOverThreshold) == 0x3d9, "Offset mismatch for UDeployableTurretAnimInstance::bInterruptibleCurveOverThreshold");
static_assert(offsetof(UDeployableTurretAnimInstance, bTurnEndCurveOverThreshold) == 0x3d9, "Offset mismatch for UDeployableTurretAnimInstance::bTurnEndCurveOverThreshold");
static_assert(offsetof(UDeployableTurretAnimInstance, InterruptibleCurveName) == 0x3dc, "Offset mismatch for UDeployableTurretAnimInstance::InterruptibleCurveName");
static_assert(offsetof(UDeployableTurretAnimInstance, InterruptibleCurveThreshold) == 0x3e0, "Offset mismatch for UDeployableTurretAnimInstance::InterruptibleCurveThreshold");
static_assert(offsetof(UDeployableTurretAnimInstance, TurnEndCurveName) == 0x3e4, "Offset mismatch for UDeployableTurretAnimInstance::TurnEndCurveName");
static_assert(offsetof(UDeployableTurretAnimInstance, TurnEndCurveThreshold) == 0x3e8, "Offset mismatch for UDeployableTurretAnimInstance::TurnEndCurveThreshold");
static_assert(offsetof(UDeployableTurretAnimInstance, AimRotationInComponentSpace) == 0x3f0, "Offset mismatch for UDeployableTurretAnimInstance::AimRotationInComponentSpace");
static_assert(offsetof(UDeployableTurretAnimInstance, SurfaceRotation) == 0x408, "Offset mismatch for UDeployableTurretAnimInstance::SurfaceRotation");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDeployableTurretLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static float DeployableTurret_CalculateTargetingLaserScale(AActor*& const TurretActor, const FTransform CurrentTurretAimTransform, const FVector LaserOrigin, float& const MaxLaserRange, float& const DistMult); // 0x10128780 (Index: 0x0, Flags: Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void DeployableTurret_EnableSkeletalMeshComponentBudgeting(USkeletalMeshComponentBudgeted*& SkeletalMesh, bool& bEnable); // 0x10128b60 (Index: 0x1, Flags: Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable)
    static FVector DeployableTurret_GetAimLocationForTargetActor(AActor*& const TargetActor, const TMap<FScalableFloat, FGameplayTag> NonPlayerPawnTargetTagToZOffsetMap); // 0x101290e8 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void FireAnalyticsEvent_DeployableTurretSessionEnd(UObject*& WorldContextObject, const FUniqueNetIdRepl TurretOwnerAccountId, const TArray<FFortAnalyticsEventAttribute> Attributes); // 0x101295cc (Index: 0x3, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UDeployableTurretLibrary) == 0x28, "Size mismatch for UDeployableTurretLibrary");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDeployableTurretBPAnimData
{
    FRotator AimRotation; // 0x0 (Size: 0x18, Type: StructProperty)
    float SurfaceRollDegrees; // 0x18 (Size: 0x4, Type: FloatProperty)
    float SurfacePitchDegrees; // 0x1c (Size: 0x4, Type: FloatProperty)
    uint8_t State; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDeployableTurretBPAnimData) == 0x28, "Size mismatch for FDeployableTurretBPAnimData");
static_assert(offsetof(FDeployableTurretBPAnimData, AimRotation) == 0x0, "Offset mismatch for FDeployableTurretBPAnimData::AimRotation");
static_assert(offsetof(FDeployableTurretBPAnimData, SurfaceRollDegrees) == 0x18, "Offset mismatch for FDeployableTurretBPAnimData::SurfaceRollDegrees");
static_assert(offsetof(FDeployableTurretBPAnimData, SurfacePitchDegrees) == 0x1c, "Offset mismatch for FDeployableTurretBPAnimData::SurfacePitchDegrees");
static_assert(offsetof(FDeployableTurretBPAnimData, State) == 0x20, "Offset mismatch for FDeployableTurretBPAnimData::State");

