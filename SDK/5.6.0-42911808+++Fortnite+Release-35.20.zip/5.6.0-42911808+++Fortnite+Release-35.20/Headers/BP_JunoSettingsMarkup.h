/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_JunoSettingsMarkup
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"

// Size: 0x38 (Inherited: 0x88, Single: 0xffffffb0)
class UBP_JunoSettingsMarkup_C : public UFortGameSettingRegistryMarkup
{
public:
};

static_assert(sizeof(UBP_JunoSettingsMarkup_C) == 0x38, "Size mismatch for UBP_JunoSettingsMarkup_C");

