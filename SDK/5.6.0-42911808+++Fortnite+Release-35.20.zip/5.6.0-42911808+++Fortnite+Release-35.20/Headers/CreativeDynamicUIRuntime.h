/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeDynamicUIRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCreativeDynamicUIAlignmentConstraint
{
    uint8_t Alignment; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Anchor; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t AspectRatio; // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3[0x5]; // 0x3 (Size: 0x5, Type: PaddingProperty)
    FVector2D Offset; // 0x8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FCreativeDynamicUIAlignmentConstraint) == 0x18, "Size mismatch for FCreativeDynamicUIAlignmentConstraint");
static_assert(offsetof(FCreativeDynamicUIAlignmentConstraint, Alignment) == 0x0, "Offset mismatch for FCreativeDynamicUIAlignmentConstraint::Alignment");
static_assert(offsetof(FCreativeDynamicUIAlignmentConstraint, Anchor) == 0x1, "Offset mismatch for FCreativeDynamicUIAlignmentConstraint::Anchor");
static_assert(offsetof(FCreativeDynamicUIAlignmentConstraint, AspectRatio) == 0x2, "Offset mismatch for FCreativeDynamicUIAlignmentConstraint::AspectRatio");
static_assert(offsetof(FCreativeDynamicUIAlignmentConstraint, Offset) == 0x8, "Offset mismatch for FCreativeDynamicUIAlignmentConstraint::Offset");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FCreativeDynamicUIFixedSizeModifier
{
    FVector2f Size; // 0x0 (Size: 0x8, Type: StructProperty)
    bool bUseRenderTransform; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FCreativeDynamicUIFixedSizeModifier) == 0xc, "Size mismatch for FCreativeDynamicUIFixedSizeModifier");
static_assert(offsetof(FCreativeDynamicUIFixedSizeModifier, Size) == 0x0, "Offset mismatch for FCreativeDynamicUIFixedSizeModifier::Size");
static_assert(offsetof(FCreativeDynamicUIFixedSizeModifier, bUseRenderTransform) == 0x8, "Offset mismatch for FCreativeDynamicUIFixedSizeModifier::bUseRenderTransform");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FCreativeDynamicUIScaleSizeModifier
{
    FVector2f Scale; // 0x0 (Size: 0x8, Type: StructProperty)
    bool bUseRenderTransform; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FCreativeDynamicUIScaleSizeModifier) == 0xc, "Size mismatch for FCreativeDynamicUIScaleSizeModifier");
static_assert(offsetof(FCreativeDynamicUIScaleSizeModifier, Scale) == 0x0, "Offset mismatch for FCreativeDynamicUIScaleSizeModifier::Scale");
static_assert(offsetof(FCreativeDynamicUIScaleSizeModifier, bUseRenderTransform) == 0x8, "Offset mismatch for FCreativeDynamicUIScaleSizeModifier::bUseRenderTransform");

