/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnnualRefundTokenUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "CommonUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "CommonUILegacy.h"
#include "Engine.h"

// Size: 0x1580 (Inherited: 0x3110, Single: 0xffffe470)
class UFortPurchaseHistoryEntryBase : public UFortHoldableButton
{
public:
    UClass* ItemCardClass; // 0x1540 (Size: 0x8, Type: ClassProperty)
    float CardWidthOverride; // 0x1548 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_154c[0x4]; // 0x154c (Size: 0x4, Type: PaddingProperty)
    UCommonTextBlock* Text_Name; // 0x1550 (Size: 0x8, Type: ObjectProperty)
    TArray<FString> LootEntryItemTypesToExclude; // 0x1558 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> LootEntryItemTypesToCombine; // 0x1568 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_1578[0x8]; // 0x1578 (Size: 0x8, Type: PaddingProperty)

protected:
    virtual void UpdateItemList(const TArray<UFortCosmeticItemCard*> ItemCards); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortPurchaseHistoryEntryBase) == 0x1580, "Size mismatch for UFortPurchaseHistoryEntryBase");
static_assert(offsetof(UFortPurchaseHistoryEntryBase, ItemCardClass) == 0x1540, "Offset mismatch for UFortPurchaseHistoryEntryBase::ItemCardClass");
static_assert(offsetof(UFortPurchaseHistoryEntryBase, CardWidthOverride) == 0x1548, "Offset mismatch for UFortPurchaseHistoryEntryBase::CardWidthOverride");
static_assert(offsetof(UFortPurchaseHistoryEntryBase, Text_Name) == 0x1550, "Offset mismatch for UFortPurchaseHistoryEntryBase::Text_Name");
static_assert(offsetof(UFortPurchaseHistoryEntryBase, LootEntryItemTypesToExclude) == 0x1558, "Offset mismatch for UFortPurchaseHistoryEntryBase::LootEntryItemTypesToExclude");
static_assert(offsetof(UFortPurchaseHistoryEntryBase, LootEntryItemTypesToCombine) == 0x1568, "Offset mismatch for UFortPurchaseHistoryEntryBase::LootEntryItemTypesToCombine");

// Size: 0x1580 (Inherited: 0x4690, Single: 0xffffcef0)
class UFortPurchaseHistoryEntry : public UFortPurchaseHistoryEntryBase
{
public:

protected:
    virtual void OnSetHistory(bool& bHasBeenRefunded, bool& bIsCancelPurchaseEligible, bool& bIsTokenlessRefund, bool& bPlayerHasTokens, bool& bNonRefundable, bool& IsPartOfABundle, bool& IsNextRefundable, int32_t& IndexInBundle, int32_t& NumPurchasesInBundle); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void SetPurchaseText(const FText PurchaseDateText, const FText RefundDateText, bool& bHasBeenRefunded, EFortPurchaseHistoryRefundType& const RefundType); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void SetupItemCard(UFortCosmeticItemCard*& const ItemCard, UFortItem*& const Item); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortPurchaseHistoryEntry) == 0x1580, "Size mismatch for UFortPurchaseHistoryEntry");

// Size: 0x1580 (Inherited: 0x4690, Single: 0xffffcef0)
class UFortPurchaseHistoryBundleEntry : public UFortPurchaseHistoryEntryBase
{
public:
    bool bIsExpanded; // 0x1578 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1579[0x7]; // 0x1579 (Size: 0x7, Type: PaddingProperty)

public:
    virtual void SetExpandButtonText(int32_t& NumPurchases); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFortPurchaseHistoryBundleEntry) == 0x1580, "Size mismatch for UFortPurchaseHistoryBundleEntry");
static_assert(offsetof(UFortPurchaseHistoryBundleEntry, bIsExpanded) == 0x1578, "Offset mismatch for UFortPurchaseHistoryBundleEntry::bIsExpanded");

// Size: 0x3e8 (Inherited: 0x7e8, Single: 0xfffffc00)
class UFortPurchaseHistoryTreeView : public UFortPurchaseHistoryListView
{
public:
    uint8_t Pad_3b0[0x10]; // 0x3b0 (Size: 0x10, Type: PaddingProperty)
    UClass* HeaderEntryWidgetClass; // 0x3c0 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_3c8[0x20]; // 0x3c8 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UFortPurchaseHistoryTreeView) == 0x3e8, "Size mismatch for UFortPurchaseHistoryTreeView");
static_assert(offsetof(UFortPurchaseHistoryTreeView, HeaderEntryWidgetClass) == 0x3c0, "Offset mismatch for UFortPurchaseHistoryTreeView::HeaderEntryWidgetClass");

// Size: 0x3b0 (Inherited: 0x438, Single: 0xffffff78)
class UFortPurchaseHistoryListView : public UListViewBase
{
public:
};

static_assert(sizeof(UFortPurchaseHistoryListView) == 0x3b0, "Size mismatch for UFortPurchaseHistoryListView");

// Size: 0x2b8 (Inherited: 0x458, Single: 0xfffffe60)
class UFortAnnualRefundTicket : public UUserWidget
{
public:
    UCommonTextBlock* Text_AvailableDate; // 0x2b0 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void OnPlayLockingAnimation(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void OnUpdateAvailableState(bool& const bIsAvailable); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void OnUpdatePendingState(bool& const bIsPending); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFortAnnualRefundTicket) == 0x2b8, "Size mismatch for UFortAnnualRefundTicket");
static_assert(offsetof(UFortAnnualRefundTicket, Text_AvailableDate) == 0x2b0, "Offset mismatch for UFortAnnualRefundTicket::Text_AvailableDate");

// Size: 0x510 (Inherited: 0x5c8, Single: 0xffffff48)
class UFortAnnualRefundTokenData : public UFortGameFeatureData
{
public:
    TSoftClassPtr PurchaseHistoryScreenClass; // 0x4f0 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UFortAnnualRefundTokenData) == 0x510, "Size mismatch for UFortAnnualRefundTokenData");
static_assert(offsetof(UFortAnnualRefundTokenData, PurchaseHistoryScreenClass) == 0x4f0, "Offset mismatch for UFortAnnualRefundTokenData::PurchaseHistoryScreenClass");

// Size: 0x678 (Inherited: 0x15f0, Single: 0xfffff088)
class UFortPurchaseHistoryScreen : public UFortActivatablePanel
{
public:
    FDataTableRowHandle BackAction; // 0x578 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_588[0x18]; // 0x588 (Size: 0x18, Type: PaddingProperty)
    TSoftClassPtr RefundConfirmationClass; // 0x5a0 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr DirectPurchaseInfoModalClass; // 0x5c0 (Size: 0x20, Type: SoftClassProperty)
    UCommonAnimatedSwitcher* Switcher_MainContent; // 0x5e0 (Size: 0x8, Type: ObjectProperty)
    UFortPurchaseHistoryTreeView* TreeView_Purchases; // 0x5e8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch; // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PostApproval; // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    UScrollBox* ScrollBox_ReturnTypeInfo; // 0x600 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Desc; // 0x608 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_RefundCount; // 0x610 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ResultHeader; // 0x618 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ResultTitle; // 0x620 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ResultDesc; // 0x628 (Size: 0x8, Type: ObjectProperty)
    UFortAnnualRefundTicket* RefundTicket_Left; // 0x630 (Size: 0x8, Type: ObjectProperty)
    UFortAnnualRefundTicket* RefundTicket_Center; // 0x638 (Size: 0x8, Type: ObjectProperty)
    UFortAnnualRefundTicket* RefundTicket_Right; // 0x640 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_CancelPurchaseInfo; // 0x648 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_ReturnTicketInfo; // 0x650 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_TokenlessRefundInfo; // 0x658 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_NonRefundableInfo; // 0x660 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_BundledPurchaseInfo; // 0x668 (Size: 0x8, Type: ObjectProperty)
    UWidget* Widget_BundledPurchaseTokenlessRefundInfo; // 0x670 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual bool BP_IsShowingPurchases(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnBeginRefundSubmission(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnEndRefundSubmission(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnNoPurchasesAvailable(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPopulateView(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortPurchaseHistoryScreen) == 0x678, "Size mismatch for UFortPurchaseHistoryScreen");
static_assert(offsetof(UFortPurchaseHistoryScreen, BackAction) == 0x578, "Offset mismatch for UFortPurchaseHistoryScreen::BackAction");
static_assert(offsetof(UFortPurchaseHistoryScreen, RefundConfirmationClass) == 0x5a0, "Offset mismatch for UFortPurchaseHistoryScreen::RefundConfirmationClass");
static_assert(offsetof(UFortPurchaseHistoryScreen, DirectPurchaseInfoModalClass) == 0x5c0, "Offset mismatch for UFortPurchaseHistoryScreen::DirectPurchaseInfoModalClass");
static_assert(offsetof(UFortPurchaseHistoryScreen, Switcher_MainContent) == 0x5e0, "Offset mismatch for UFortPurchaseHistoryScreen::Switcher_MainContent");
static_assert(offsetof(UFortPurchaseHistoryScreen, TreeView_Purchases) == 0x5e8, "Offset mismatch for UFortPurchaseHistoryScreen::TreeView_Purchases");
static_assert(offsetof(UFortPurchaseHistoryScreen, Button_CloseTouch) == 0x5f0, "Offset mismatch for UFortPurchaseHistoryScreen::Button_CloseTouch");
static_assert(offsetof(UFortPurchaseHistoryScreen, Button_PostApproval) == 0x5f8, "Offset mismatch for UFortPurchaseHistoryScreen::Button_PostApproval");
static_assert(offsetof(UFortPurchaseHistoryScreen, ScrollBox_ReturnTypeInfo) == 0x600, "Offset mismatch for UFortPurchaseHistoryScreen::ScrollBox_ReturnTypeInfo");
static_assert(offsetof(UFortPurchaseHistoryScreen, Text_Desc) == 0x608, "Offset mismatch for UFortPurchaseHistoryScreen::Text_Desc");
static_assert(offsetof(UFortPurchaseHistoryScreen, Text_RefundCount) == 0x610, "Offset mismatch for UFortPurchaseHistoryScreen::Text_RefundCount");
static_assert(offsetof(UFortPurchaseHistoryScreen, Text_ResultHeader) == 0x618, "Offset mismatch for UFortPurchaseHistoryScreen::Text_ResultHeader");
static_assert(offsetof(UFortPurchaseHistoryScreen, Text_ResultTitle) == 0x620, "Offset mismatch for UFortPurchaseHistoryScreen::Text_ResultTitle");
static_assert(offsetof(UFortPurchaseHistoryScreen, Text_ResultDesc) == 0x628, "Offset mismatch for UFortPurchaseHistoryScreen::Text_ResultDesc");
static_assert(offsetof(UFortPurchaseHistoryScreen, RefundTicket_Left) == 0x630, "Offset mismatch for UFortPurchaseHistoryScreen::RefundTicket_Left");
static_assert(offsetof(UFortPurchaseHistoryScreen, RefundTicket_Center) == 0x638, "Offset mismatch for UFortPurchaseHistoryScreen::RefundTicket_Center");
static_assert(offsetof(UFortPurchaseHistoryScreen, RefundTicket_Right) == 0x640, "Offset mismatch for UFortPurchaseHistoryScreen::RefundTicket_Right");
static_assert(offsetof(UFortPurchaseHistoryScreen, Widget_CancelPurchaseInfo) == 0x648, "Offset mismatch for UFortPurchaseHistoryScreen::Widget_CancelPurchaseInfo");
static_assert(offsetof(UFortPurchaseHistoryScreen, Widget_ReturnTicketInfo) == 0x650, "Offset mismatch for UFortPurchaseHistoryScreen::Widget_ReturnTicketInfo");
static_assert(offsetof(UFortPurchaseHistoryScreen, Widget_TokenlessRefundInfo) == 0x658, "Offset mismatch for UFortPurchaseHistoryScreen::Widget_TokenlessRefundInfo");
static_assert(offsetof(UFortPurchaseHistoryScreen, Widget_NonRefundableInfo) == 0x660, "Offset mismatch for UFortPurchaseHistoryScreen::Widget_NonRefundableInfo");
static_assert(offsetof(UFortPurchaseHistoryScreen, Widget_BundledPurchaseInfo) == 0x668, "Offset mismatch for UFortPurchaseHistoryScreen::Widget_BundledPurchaseInfo");
static_assert(offsetof(UFortPurchaseHistoryScreen, Widget_BundledPurchaseTokenlessRefundInfo) == 0x670, "Offset mismatch for UFortPurchaseHistoryScreen::Widget_BundledPurchaseTokenlessRefundInfo");

// Size: 0x5d0 (Inherited: 0x15f0, Single: 0xffffefe0)
class UFortRefundConfirmation : public UFortActivatablePanel
{
public:
    uint8_t Pad_578[0x10]; // 0x578 (Size: 0x10, Type: PaddingProperty)
    UCommonTextBlock* Text_RefundsRemaining; // 0x588 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_RefundCount; // 0x590 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_AreYouSure; // 0x598 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Yes; // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_No; // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CloseTouch; // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    UFortAnnualRefundTicket* RefundTicket_Left; // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    UFortAnnualRefundTicket* RefundTicket_Center; // 0x5c0 (Size: 0x8, Type: ObjectProperty)
    UFortAnnualRefundTicket* RefundTicket_Right; // 0x5c8 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void BP_UpdateItemsList(const TArray<UFortItemDefinition*> SelectedItemDefs, int32_t& const TotalMtxPaid); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void BP_UpdateRefundType(EFortPurchaseHistoryRefundType& const RefundType, bool& const bBundledRefund); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortRefundConfirmation) == 0x5d0, "Size mismatch for UFortRefundConfirmation");
static_assert(offsetof(UFortRefundConfirmation, Text_RefundsRemaining) == 0x588, "Offset mismatch for UFortRefundConfirmation::Text_RefundsRemaining");
static_assert(offsetof(UFortRefundConfirmation, Text_RefundCount) == 0x590, "Offset mismatch for UFortRefundConfirmation::Text_RefundCount");
static_assert(offsetof(UFortRefundConfirmation, Text_AreYouSure) == 0x598, "Offset mismatch for UFortRefundConfirmation::Text_AreYouSure");
static_assert(offsetof(UFortRefundConfirmation, Button_Yes) == 0x5a0, "Offset mismatch for UFortRefundConfirmation::Button_Yes");
static_assert(offsetof(UFortRefundConfirmation, Button_No) == 0x5a8, "Offset mismatch for UFortRefundConfirmation::Button_No");
static_assert(offsetof(UFortRefundConfirmation, Button_CloseTouch) == 0x5b0, "Offset mismatch for UFortRefundConfirmation::Button_CloseTouch");
static_assert(offsetof(UFortRefundConfirmation, RefundTicket_Left) == 0x5b8, "Offset mismatch for UFortRefundConfirmation::RefundTicket_Left");
static_assert(offsetof(UFortRefundConfirmation, RefundTicket_Center) == 0x5c0, "Offset mismatch for UFortRefundConfirmation::RefundTicket_Center");
static_assert(offsetof(UFortRefundConfirmation, RefundTicket_Right) == 0x5c8, "Offset mismatch for UFortRefundConfirmation::RefundTicket_Right");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FPurchaseHistoryBundleEntry
{
    FString ID; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FPurchaseHistoryBundleEntry) == 0x20, "Size mismatch for FPurchaseHistoryBundleEntry");
static_assert(offsetof(FPurchaseHistoryBundleEntry, ID) == 0x10, "Offset mismatch for FPurchaseHistoryBundleEntry::ID");

