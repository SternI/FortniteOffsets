/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CustomControlsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "ModularGameplay.h"
#include "TargetingSystem.h"
#include "FortniteAI.h"
#include "GameplayTags.h"
#include "EnhancedInput.h"
#include "PlayspaceSystem.h"

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UCustomControlInputBindings_Base : public UObject
{
public:
    TWeakObjectPtr<UFortControllerComponent_CustomControls*> OwnerCustomControlsComponent; // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> OwnerController; // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerPawn*> OwnerPawn; // 0x38 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UCustomControlInputBindings_Base) == 0x40, "Size mismatch for UCustomControlInputBindings_Base");
static_assert(offsetof(UCustomControlInputBindings_Base, OwnerCustomControlsComponent) == 0x28, "Offset mismatch for UCustomControlInputBindings_Base::OwnerCustomControlsComponent");
static_assert(offsetof(UCustomControlInputBindings_Base, OwnerController) == 0x30, "Offset mismatch for UCustomControlInputBindings_Base::OwnerController");
static_assert(offsetof(UCustomControlInputBindings_Base, OwnerPawn) == 0x38, "Offset mismatch for UCustomControlInputBindings_Base::OwnerPawn");

// Size: 0x70 (Inherited: 0x68, Single: 0x8)
class UCustomControlInputBindings_EnhancedInput : public UCustomControlInputBindings_Base
{
public:
    TWeakObjectPtr<UFortEnhancedInputComponent*> OwnerInputComponent; // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    float Priority; // 0x48 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4c[0x14]; // 0x4c (Size: 0x14, Type: PaddingProperty)
    UFortInputMappingContext* InputMapping; // 0x60 (Size: 0x8, Type: ObjectProperty)
    FModifyContextOptions Options; // 0x68 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UCustomControlInputBindings_EnhancedInput) == 0x70, "Size mismatch for UCustomControlInputBindings_EnhancedInput");
static_assert(offsetof(UCustomControlInputBindings_EnhancedInput, OwnerInputComponent) == 0x40, "Offset mismatch for UCustomControlInputBindings_EnhancedInput::OwnerInputComponent");
static_assert(offsetof(UCustomControlInputBindings_EnhancedInput, Priority) == 0x48, "Offset mismatch for UCustomControlInputBindings_EnhancedInput::Priority");
static_assert(offsetof(UCustomControlInputBindings_EnhancedInput, InputMapping) == 0x60, "Offset mismatch for UCustomControlInputBindings_EnhancedInput::InputMapping");
static_assert(offsetof(UCustomControlInputBindings_EnhancedInput, Options) == 0x68, "Offset mismatch for UCustomControlInputBindings_EnhancedInput::Options");

// Size: 0x48 (Inherited: 0x68, Single: 0xffffffe0)
class UCustomControlInputBindings_InputComponent : public UCustomControlInputBindings_Base
{
public:
    UInputComponent* InputComponent; // 0x40 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UCustomControlInputBindings_InputComponent) == 0x48, "Size mismatch for UCustomControlInputBindings_InputComponent");
static_assert(offsetof(UCustomControlInputBindings_InputComponent, InputComponent) == 0x40, "Offset mismatch for UCustomControlInputBindings_InputComponent::InputComponent");

// Size: 0x90 (Inherited: 0xb0, Single: 0xffffffe0)
class UCustomControlInputBindings_SideScroller : public UCustomControlInputBindings_InputComponent
{
public:
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
    float AnalogInputDeadZone; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_54[0x3c]; // 0x54 (Size: 0x3c, Type: PaddingProperty)
};

static_assert(sizeof(UCustomControlInputBindings_SideScroller) == 0x90, "Size mismatch for UCustomControlInputBindings_SideScroller");
static_assert(offsetof(UCustomControlInputBindings_SideScroller, AnalogInputDeadZone) == 0x50, "Offset mismatch for UCustomControlInputBindings_SideScroller::AnalogInputDeadZone");

// Size: 0xe0 (Inherited: 0x140, Single: 0xffffffa0)
class UCustomControlInputBindings_SideScrollerManual : public UCustomControlInputBindings_SideScroller
{
public:
    float AimOrbitalDistance; // 0x90 (Size: 0x4, Type: FloatProperty)
    float TouchDirectionClamping; // 0x94 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_98[0x48]; // 0x98 (Size: 0x48, Type: PaddingProperty)
};

static_assert(sizeof(UCustomControlInputBindings_SideScrollerManual) == 0xe0, "Size mismatch for UCustomControlInputBindings_SideScrollerManual");
static_assert(offsetof(UCustomControlInputBindings_SideScrollerManual, AimOrbitalDistance) == 0x90, "Offset mismatch for UCustomControlInputBindings_SideScrollerManual::AimOrbitalDistance");
static_assert(offsetof(UCustomControlInputBindings_SideScrollerManual, TouchDirectionClamping) == 0x94, "Offset mismatch for UCustomControlInputBindings_SideScrollerManual::TouchDirectionClamping");

// Size: 0xb8 (Inherited: 0x140, Single: 0xffffff78)
class UCustomControlInputBindings_SideScrollerMovement : public UCustomControlInputBindings_SideScroller
{
public:
    float AimOrbitalDistance; // 0x90 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_94[0x24]; // 0x94 (Size: 0x24, Type: PaddingProperty)
};

static_assert(sizeof(UCustomControlInputBindings_SideScrollerMovement) == 0xb8, "Size mismatch for UCustomControlInputBindings_SideScrollerMovement");
static_assert(offsetof(UCustomControlInputBindings_SideScrollerMovement, AimOrbitalDistance) == 0x90, "Offset mismatch for UCustomControlInputBindings_SideScrollerMovement::AimOrbitalDistance");

// Size: 0xf0 (Inherited: 0xd8, Single: 0x18)
class UCustomControlInputBindings_Skydiving : public UCustomControlInputBindings_EnhancedInput
{
public:
    UInputAction* SkydivingDownInputAction; // 0x70 (Size: 0x8, Type: ObjectProperty)
    UInputAction* SkydivingUpInputAction; // 0x78 (Size: 0x8, Type: ObjectProperty)
    FName MappingNameSkydivingDown; // 0x80 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
    FText DisplayNameSkydivingDown; // 0x88 (Size: 0x10, Type: TextProperty)
    FName MappingNameSkydivingUp; // 0x98 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
    FText DisplayNameSkydivingUp; // 0xa0 (Size: 0x10, Type: TextProperty)
    float RotateStickThreshold; // 0xb0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_b4[0x4]; // 0xb4 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer InSkydiveVolumeTags; // 0xb8 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_d8[0x18]; // 0xd8 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UCustomControlInputBindings_Skydiving) == 0xf0, "Size mismatch for UCustomControlInputBindings_Skydiving");
static_assert(offsetof(UCustomControlInputBindings_Skydiving, SkydivingDownInputAction) == 0x70, "Offset mismatch for UCustomControlInputBindings_Skydiving::SkydivingDownInputAction");
static_assert(offsetof(UCustomControlInputBindings_Skydiving, SkydivingUpInputAction) == 0x78, "Offset mismatch for UCustomControlInputBindings_Skydiving::SkydivingUpInputAction");
static_assert(offsetof(UCustomControlInputBindings_Skydiving, MappingNameSkydivingDown) == 0x80, "Offset mismatch for UCustomControlInputBindings_Skydiving::MappingNameSkydivingDown");
static_assert(offsetof(UCustomControlInputBindings_Skydiving, DisplayNameSkydivingDown) == 0x88, "Offset mismatch for UCustomControlInputBindings_Skydiving::DisplayNameSkydivingDown");
static_assert(offsetof(UCustomControlInputBindings_Skydiving, MappingNameSkydivingUp) == 0x98, "Offset mismatch for UCustomControlInputBindings_Skydiving::MappingNameSkydivingUp");
static_assert(offsetof(UCustomControlInputBindings_Skydiving, DisplayNameSkydivingUp) == 0xa0, "Offset mismatch for UCustomControlInputBindings_Skydiving::DisplayNameSkydivingUp");
static_assert(offsetof(UCustomControlInputBindings_Skydiving, RotateStickThreshold) == 0xb0, "Offset mismatch for UCustomControlInputBindings_Skydiving::RotateStickThreshold");
static_assert(offsetof(UCustomControlInputBindings_Skydiving, InSkydiveVolumeTags) == 0xb8, "Offset mismatch for UCustomControlInputBindings_Skydiving::InSkydiveVolumeTags");

// Size: 0xf0 (Inherited: 0x1a8, Single: 0xffffff48)
class UCustomControlInputBindings_TwinStickDial : public UCustomControlInputBindings_TwinStick
{
public:
    UInputAction* MouseAimAtInputAction; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d8[0x18]; // 0xd8 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UCustomControlInputBindings_TwinStickDial) == 0xf0, "Size mismatch for UCustomControlInputBindings_TwinStickDial");
static_assert(offsetof(UCustomControlInputBindings_TwinStickDial, MouseAimAtInputAction) == 0xd0, "Offset mismatch for UCustomControlInputBindings_TwinStickDial::MouseAimAtInputAction");

// Size: 0xd0 (Inherited: 0xd8, Single: 0xfffffff8)
class UCustomControlInputBindings_TwinStick : public UCustomControlInputBindings_EnhancedInput
{
public:
    float InitialDialAimTargetOffsetScaleFactor; // 0x70 (Size: 0x4, Type: FloatProperty)
    float TargetingBreakOffsetGamepad; // 0x74 (Size: 0x4, Type: FloatProperty)
    float TargetingBreakOffsetMouse; // 0x78 (Size: 0x4, Type: FloatProperty)
    float DefaultAutoFireCooldown; // 0x7c (Size: 0x4, Type: FloatProperty)
    UInputAction* GamepadLookAtInputAction; // 0x80 (Size: 0x8, Type: ObjectProperty)
    UInputAction* GamepadAimAtInputAction; // 0x88 (Size: 0x8, Type: ObjectProperty)
    UInputAction* MouseLookAtInputAction; // 0x90 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_98[0x38]; // 0x98 (Size: 0x38, Type: PaddingProperty)

private:
    void OnWeaponUnEquippedDelegate(); // 0x1135c364 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UCustomControlInputBindings_TwinStick) == 0xd0, "Size mismatch for UCustomControlInputBindings_TwinStick");
static_assert(offsetof(UCustomControlInputBindings_TwinStick, InitialDialAimTargetOffsetScaleFactor) == 0x70, "Offset mismatch for UCustomControlInputBindings_TwinStick::InitialDialAimTargetOffsetScaleFactor");
static_assert(offsetof(UCustomControlInputBindings_TwinStick, TargetingBreakOffsetGamepad) == 0x74, "Offset mismatch for UCustomControlInputBindings_TwinStick::TargetingBreakOffsetGamepad");
static_assert(offsetof(UCustomControlInputBindings_TwinStick, TargetingBreakOffsetMouse) == 0x78, "Offset mismatch for UCustomControlInputBindings_TwinStick::TargetingBreakOffsetMouse");
static_assert(offsetof(UCustomControlInputBindings_TwinStick, DefaultAutoFireCooldown) == 0x7c, "Offset mismatch for UCustomControlInputBindings_TwinStick::DefaultAutoFireCooldown");
static_assert(offsetof(UCustomControlInputBindings_TwinStick, GamepadLookAtInputAction) == 0x80, "Offset mismatch for UCustomControlInputBindings_TwinStick::GamepadLookAtInputAction");
static_assert(offsetof(UCustomControlInputBindings_TwinStick, GamepadAimAtInputAction) == 0x88, "Offset mismatch for UCustomControlInputBindings_TwinStick::GamepadAimAtInputAction");
static_assert(offsetof(UCustomControlInputBindings_TwinStick, MouseLookAtInputAction) == 0x90, "Offset mismatch for UCustomControlInputBindings_TwinStick::MouseLookAtInputAction");

// Size: 0xa0 (Inherited: 0x28, Single: 0x78)
class UCustomControlOptions_Base : public UObject
{
public:
    UClass* MovementModeLogic; // 0x28 (Size: 0x8, Type: ClassProperty)
    float RangedAttackStateDuration; // 0x30 (Size: 0x4, Type: FloatProperty)
    float MeleeAttackStateDuration; // 0x34 (Size: 0x4, Type: FloatProperty)
    TArray<UClass*> InputBindingsClasses; // 0x38 (Size: 0x10, Type: ArrayProperty)
    FFortWeaponReticleData FortWeaponReticleData; // 0x48 (Size: 0x14, Type: StructProperty)
    FInteractionPointOptions InteractionPointOptions; // 0x5c (Size: 0x10, Type: StructProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
    FInteractSelectionData_TargetingPreset InteractionTargetingPreset; // 0x70 (Size: 0x8, Type: StructProperty)
    float BuildingPlacementDistanceOffset; // 0x78 (Size: 0x4, Type: FloatProperty)
    bool bShouldAffectNPC; // 0x7c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7d[0x23]; // 0x7d (Size: 0x23, Type: PaddingProperty)

public:
    void AddGameplayEffect(UClass*& GameplayEffectClass); // 0x1134420c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void AddGameplayEffectWithMagnitude(UClass*& GameplayEffectClass, FGameplayTag& AttributeTag, float& AttributeMagnitude); // 0x11344600 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    UFortControllerComponent_CustomControls* GetOwningComponent() const; // 0x113452dc (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual bool UsesCursor(); // 0xbea6ef4 (Index: 0x5, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void BP_OnActivate(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnDeactivate(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCustomControlOptions_Base) == 0xa0, "Size mismatch for UCustomControlOptions_Base");
static_assert(offsetof(UCustomControlOptions_Base, MovementModeLogic) == 0x28, "Offset mismatch for UCustomControlOptions_Base::MovementModeLogic");
static_assert(offsetof(UCustomControlOptions_Base, RangedAttackStateDuration) == 0x30, "Offset mismatch for UCustomControlOptions_Base::RangedAttackStateDuration");
static_assert(offsetof(UCustomControlOptions_Base, MeleeAttackStateDuration) == 0x34, "Offset mismatch for UCustomControlOptions_Base::MeleeAttackStateDuration");
static_assert(offsetof(UCustomControlOptions_Base, InputBindingsClasses) == 0x38, "Offset mismatch for UCustomControlOptions_Base::InputBindingsClasses");
static_assert(offsetof(UCustomControlOptions_Base, FortWeaponReticleData) == 0x48, "Offset mismatch for UCustomControlOptions_Base::FortWeaponReticleData");
static_assert(offsetof(UCustomControlOptions_Base, InteractionPointOptions) == 0x5c, "Offset mismatch for UCustomControlOptions_Base::InteractionPointOptions");
static_assert(offsetof(UCustomControlOptions_Base, InteractionTargetingPreset) == 0x70, "Offset mismatch for UCustomControlOptions_Base::InteractionTargetingPreset");
static_assert(offsetof(UCustomControlOptions_Base, BuildingPlacementDistanceOffset) == 0x78, "Offset mismatch for UCustomControlOptions_Base::BuildingPlacementDistanceOffset");
static_assert(offsetof(UCustomControlOptions_Base, bShouldAffectNPC) == 0x7c, "Offset mismatch for UCustomControlOptions_Base::bShouldAffectNPC");

// Size: 0x218 (Inherited: 0x290, Single: 0xffffff88)
class UCustomControlOptions_SideScroller : public UCustomControlOptions_Targeting
{
public:
    FFortMovementMode_CCSideScrollerCreationData MovementModeCreationData; // 0x1c8 (Size: 0x48, Type: StructProperty)
    FInputOptions_SideScroller InputOptions; // 0x210 (Size: 0x6, Type: StructProperty)
    bool bIsBeanstalkGFS; // 0x216 (Size: 0x1, Type: BoolProperty)
    bool bIsDeviceActive; // 0x217 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(UCustomControlOptions_SideScroller) == 0x218, "Size mismatch for UCustomControlOptions_SideScroller");
static_assert(offsetof(UCustomControlOptions_SideScroller, MovementModeCreationData) == 0x1c8, "Offset mismatch for UCustomControlOptions_SideScroller::MovementModeCreationData");
static_assert(offsetof(UCustomControlOptions_SideScroller, InputOptions) == 0x210, "Offset mismatch for UCustomControlOptions_SideScroller::InputOptions");
static_assert(offsetof(UCustomControlOptions_SideScroller, bIsBeanstalkGFS) == 0x216, "Offset mismatch for UCustomControlOptions_SideScroller::bIsBeanstalkGFS");
static_assert(offsetof(UCustomControlOptions_SideScroller, bIsDeviceActive) == 0x217, "Offset mismatch for UCustomControlOptions_SideScroller::bIsDeviceActive");

// Size: 0x1c8 (Inherited: 0xc8, Single: 0x100)
class UCustomControlOptions_Targeting : public UCustomControlOptions_Base
{
public:
    float AngleToClampFireHorizontal; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float AngleToClampFireVertical; // 0xa4 (Size: 0x4, Type: FloatProperty)
    UTargetingPreset* RangedTargetingPresetTemplate; // 0xa8 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* RetentionTargetingPresetTemplate; // 0xb0 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* RangedAimingTargetingPresetTemplate; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* MeleeTargetingPresetTemplate; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* RangedTargetingPreset; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* RetentionTargetingPreset; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* RangedAimTargetingPreset; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UTargetingPreset* MeleeTargetingPreset; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    bool bTargetingEnabled; // 0xe8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e9[0x7]; // 0xe9 (Size: 0x7, Type: PaddingProperty)
    FCustomControlTargetingData RangedTargetingData; // 0xf0 (Size: 0x48, Type: StructProperty)
    FCustomControlTargetingData MeleeTargetingData; // 0x138 (Size: 0x48, Type: StructProperty)
    FCustomControlTargetingData AimingTargetingData; // 0x180 (Size: 0x48, Type: StructProperty)

public:
    void SetTargetingData(bool& InTargetingEnabled, FCustomControlTargetingData& InRangedTargetingData, FCustomControlTargetingData& InMeleeTargetingData, FCustomControlTargetingData& InAimingTargetingData); // 0x11345df8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void BP_InitFilteringTask(UTargetingFilter_CC_Base*& const FilteringTask, ETargetingPresetType& PresetType); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_InitSelectionTask(UTargetingSelection_CC_Base*& const SelectionTask, ETargetingPresetType& PresetType); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_InitSortingTask(UTargetingSort_CC_Base*& const SortingTask, ETargetingPresetType& PresetType); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UCustomControlOptions_Targeting) == 0x1c8, "Size mismatch for UCustomControlOptions_Targeting");
static_assert(offsetof(UCustomControlOptions_Targeting, AngleToClampFireHorizontal) == 0xa0, "Offset mismatch for UCustomControlOptions_Targeting::AngleToClampFireHorizontal");
static_assert(offsetof(UCustomControlOptions_Targeting, AngleToClampFireVertical) == 0xa4, "Offset mismatch for UCustomControlOptions_Targeting::AngleToClampFireVertical");
static_assert(offsetof(UCustomControlOptions_Targeting, RangedTargetingPresetTemplate) == 0xa8, "Offset mismatch for UCustomControlOptions_Targeting::RangedTargetingPresetTemplate");
static_assert(offsetof(UCustomControlOptions_Targeting, RetentionTargetingPresetTemplate) == 0xb0, "Offset mismatch for UCustomControlOptions_Targeting::RetentionTargetingPresetTemplate");
static_assert(offsetof(UCustomControlOptions_Targeting, RangedAimingTargetingPresetTemplate) == 0xb8, "Offset mismatch for UCustomControlOptions_Targeting::RangedAimingTargetingPresetTemplate");
static_assert(offsetof(UCustomControlOptions_Targeting, MeleeTargetingPresetTemplate) == 0xc0, "Offset mismatch for UCustomControlOptions_Targeting::MeleeTargetingPresetTemplate");
static_assert(offsetof(UCustomControlOptions_Targeting, RangedTargetingPreset) == 0xc8, "Offset mismatch for UCustomControlOptions_Targeting::RangedTargetingPreset");
static_assert(offsetof(UCustomControlOptions_Targeting, RetentionTargetingPreset) == 0xd0, "Offset mismatch for UCustomControlOptions_Targeting::RetentionTargetingPreset");
static_assert(offsetof(UCustomControlOptions_Targeting, RangedAimTargetingPreset) == 0xd8, "Offset mismatch for UCustomControlOptions_Targeting::RangedAimTargetingPreset");
static_assert(offsetof(UCustomControlOptions_Targeting, MeleeTargetingPreset) == 0xe0, "Offset mismatch for UCustomControlOptions_Targeting::MeleeTargetingPreset");
static_assert(offsetof(UCustomControlOptions_Targeting, bTargetingEnabled) == 0xe8, "Offset mismatch for UCustomControlOptions_Targeting::bTargetingEnabled");
static_assert(offsetof(UCustomControlOptions_Targeting, RangedTargetingData) == 0xf0, "Offset mismatch for UCustomControlOptions_Targeting::RangedTargetingData");
static_assert(offsetof(UCustomControlOptions_Targeting, MeleeTargetingData) == 0x138, "Offset mismatch for UCustomControlOptions_Targeting::MeleeTargetingData");
static_assert(offsetof(UCustomControlOptions_Targeting, AimingTargetingData) == 0x180, "Offset mismatch for UCustomControlOptions_Targeting::AimingTargetingData");

// Size: 0x470 (Inherited: 0x290, Single: 0x1e0)
class UCustomControlOptions_ThirdPerson : public UCustomControlOptions_Targeting
{
public:
    FFortMovementMode_CCThirdPersonCreationData MovementModeCreationData; // 0x1c8 (Size: 0x38, Type: StructProperty)
    FInputOptions_ThirdPerson InputOptions; // 0x200 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_201[0x3]; // 0x201 (Size: 0x3, Type: PaddingProperty)
    FFortAnimInput_AdjustedAim AdjustedAim; // 0x204 (Size: 0x26c, Type: StructProperty)
};

static_assert(sizeof(UCustomControlOptions_ThirdPerson) == 0x470, "Size mismatch for UCustomControlOptions_ThirdPerson");
static_assert(offsetof(UCustomControlOptions_ThirdPerson, MovementModeCreationData) == 0x1c8, "Offset mismatch for UCustomControlOptions_ThirdPerson::MovementModeCreationData");
static_assert(offsetof(UCustomControlOptions_ThirdPerson, InputOptions) == 0x200, "Offset mismatch for UCustomControlOptions_ThirdPerson::InputOptions");
static_assert(offsetof(UCustomControlOptions_ThirdPerson, AdjustedAim) == 0x204, "Offset mismatch for UCustomControlOptions_ThirdPerson::AdjustedAim");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UTargetingDataHelperLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static TArray<TEnumAsByte<EObjectTypeQuery>> GetTargetableObjectTypes(FCustomControlTargetingData& TargetingData); // 0x11345300 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UTargetingDataHelperLibrary) == 0x28, "Size mismatch for UTargetingDataHelperLibrary");

// Size: 0x168 (Inherited: 0x470, Single: 0xfffffcf8)
class UFortAIPawnComponent_CustomControls : public UFortPawnComponent_BaseCC
{
public:
};

static_assert(sizeof(UFortAIPawnComponent_CustomControls) == 0x168, "Size mismatch for UFortAIPawnComponent_CustomControls");

// Size: 0x160 (Inherited: 0x310, Single: 0xfffffe50)
class UFortPawnComponent_BaseCC : public UFortPawnComponent
{
public:
    uint8_t Pad_c0[0x30]; // 0xc0 (Size: 0x30, Type: PaddingProperty)
    UCustomControlOptions_Base* ActiveOptions; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UCustomControlOptions_Base* HighestPriorityOptions; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_100[0x50]; // 0x100 (Size: 0x50, Type: PaddingProperty)
    TArray<UCustomControlOptions_Base*> OwnedOptions; // 0x150 (Size: 0x10, Type: ArrayProperty)

public:
    bool AddOptions(UObject*& const ContextObject, UCustomControlOptions_Base*& Options, float& Priority, bool& bEnabled); // 0x1135bca8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    UCustomControlOptions_Base* CreateOptions(UClass*& OptionsClass); // 0x1135c06c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    UCustomControlOptions_Base* GetActiveOptions() const; // 0xdcaedc4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCustomControlOptions_Base* GetHighestPriorityOptions() const; // 0xb251840 (Index: 0x3, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCustomControlOptions_Base* GetOptions(UObject*& const ContextObject); // 0x11345194 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveOptions(UObject*& const ContextObject); // 0x1135c38c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    bool SetOptionsEnabled(UObject*& const ContextObject, bool& bEnabled); // 0x1135c4b8 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    bool SetOptionsPriority(UObject*& const ContextObject, float& Priority, bool& bRefreshRelativePriority); // 0x1135c6ec (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnRep_HighestPriorityOptions(); // 0x1135c350 (Index: 0x5, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortPawnComponent_BaseCC) == 0x160, "Size mismatch for UFortPawnComponent_BaseCC");
static_assert(offsetof(UFortPawnComponent_BaseCC, ActiveOptions) == 0xf0, "Offset mismatch for UFortPawnComponent_BaseCC::ActiveOptions");
static_assert(offsetof(UFortPawnComponent_BaseCC, HighestPriorityOptions) == 0xf8, "Offset mismatch for UFortPawnComponent_BaseCC::HighestPriorityOptions");
static_assert(offsetof(UFortPawnComponent_BaseCC, OwnedOptions) == 0x150, "Offset mismatch for UFortPawnComponent_BaseCC::OwnedOptions");

// Size: 0x160 (Inherited: 0x310, Single: 0xfffffe50)
class UFortControllerComponent_BaseCC : public UFortControllerComponent
{
public:
    uint8_t Pad_c0[0x30]; // 0xc0 (Size: 0x30, Type: PaddingProperty)
    UCustomControlOptions_Base* ActiveOptions; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UCustomControlOptions_Base* HighestPriorityOptions; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_100[0x50]; // 0x100 (Size: 0x50, Type: PaddingProperty)
    TArray<UCustomControlOptions_Base*> OwnedOptions; // 0x150 (Size: 0x10, Type: ArrayProperty)

public:
    bool AddOptions(UObject*& const ContextObject, UCustomControlOptions_Base*& Options, float& Priority, bool& bEnabled); // 0x113449bc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    UCustomControlOptions_Base* CreateOptions(UClass*& OptionsClass); // 0x11344eb0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    UCustomControlOptions_Base* GetActiveOptions() const; // 0xdcaedc4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCustomControlOptions_Base* GetHighestPriorityOptions() const; // 0x11081e6c (Index: 0x3, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCustomControlOptions_Base* GetOptions(UObject*& const ContextObject); // 0x11345194 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveOptions(UObject*& const ContextObject); // 0x113456d4 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    bool SetOptionsEnabled(UObject*& const ContextObject, bool& bEnabled); // 0x113458c4 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    bool SetOptionsPriority(UObject*& const ContextObject, float& Priority, bool& bRefreshRelativePriority); // 0x11345af8 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnRep_HighestPriorityOptions(); // 0x113456c0 (Index: 0x5, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortControllerComponent_BaseCC) == 0x160, "Size mismatch for UFortControllerComponent_BaseCC");
static_assert(offsetof(UFortControllerComponent_BaseCC, ActiveOptions) == 0xf0, "Offset mismatch for UFortControllerComponent_BaseCC::ActiveOptions");
static_assert(offsetof(UFortControllerComponent_BaseCC, HighestPriorityOptions) == 0xf8, "Offset mismatch for UFortControllerComponent_BaseCC::HighestPriorityOptions");
static_assert(offsetof(UFortControllerComponent_BaseCC, OwnedOptions) == 0x150, "Offset mismatch for UFortControllerComponent_BaseCC::OwnedOptions");

// Size: 0x250 (Inherited: 0x470, Single: 0xfffffde0)
class UFortControllerComponent_CustomControls : public UFortControllerComponent_BaseCC
{
public:
    FCustomControlsState CurrentState; // 0x160 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_164[0xc]; // 0x164 (Size: 0xc, Type: PaddingProperty)
    FGameplayTagQuery BlockTagsQuery; // 0x170 (Size: 0x48, Type: StructProperty)
    uint8_t Pad_1b8[0x8]; // 0x1b8 (Size: 0x8, Type: PaddingProperty)
    TArray<UCustomControlInputBindings_Base*> ActiveInputBindings; // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_1d0[0x78]; // 0x1d0 (Size: 0x78, Type: PaddingProperty)
    TWeakObjectPtr<UInteractSelection_Base*> InteractSelectionPtr; // 0x248 (Size: 0x8, Type: WeakObjectProperty)

public:
    UFortMovementMode_BaseExtRuntimeData* GetMovementModeRuntimeData() const; // 0xa2b9ce8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    virtual void ClientRegisterTagsQueries(); // 0xf36f334 (Index: 0x0, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    virtual void ClientSetOptionsQueueBlocked(bool& bIsBlocked); // 0x11344d80 (Index: 0x1, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    void OnPlayspaceUserAdded(const FPlayspaceUser PlayspaceUser); // 0x113455bc (Index: 0x3, Flags: Final|Native|Private|HasOutParms)
    virtual void ServerResetAimLocation(); // 0xb4a9750 (Index: 0x4, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
    virtual void ServerResetAimTargetOffset(); // 0xd51b634 (Index: 0x5, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
    virtual void ServerSetAimLocation(FVector& const AimLocation); // 0x11345800 (Index: 0x6, Flags: Final|Net|NetReliableNative|Event|Private|NetServer|HasDefaults)
    virtual void ServerSetDesiredAimTargetOffset(float& const NewDesiredAimTargetOffset); // 0xd4f1698 (Index: 0x7, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
    virtual void ServerSetFocusTarget(AActor*& const NewFocusTarget); // 0x10118b2c (Index: 0x8, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
    virtual void ServerSetUseDesiredRotationOverride(bool& const bNewUseDesiredRotationOverride); // 0xd6edab8 (Index: 0x9, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
    void WeaponGetAimRotOverride(AFortWeapon*& const Weapon, EFortAbilityTargetingSource& const TargetingSource, FRotator& OutOverrideAimRot, bool& bOutExecutionResult); // 0x11346154 (Index: 0xa, Flags: Final|Native|Private|HasOutParms|HasDefaults)
};

static_assert(sizeof(UFortControllerComponent_CustomControls) == 0x250, "Size mismatch for UFortControllerComponent_CustomControls");
static_assert(offsetof(UFortControllerComponent_CustomControls, CurrentState) == 0x160, "Offset mismatch for UFortControllerComponent_CustomControls::CurrentState");
static_assert(offsetof(UFortControllerComponent_CustomControls, BlockTagsQuery) == 0x170, "Offset mismatch for UFortControllerComponent_CustomControls::BlockTagsQuery");
static_assert(offsetof(UFortControllerComponent_CustomControls, ActiveInputBindings) == 0x1c0, "Offset mismatch for UFortControllerComponent_CustomControls::ActiveInputBindings");
static_assert(offsetof(UFortControllerComponent_CustomControls, InteractSelectionPtr) == 0x248, "Offset mismatch for UFortControllerComponent_CustomControls::InteractSelectionPtr");

// Size: 0x58 (Inherited: 0x68, Single: 0xfffffff0)
class UFortMovementMode_BaseCCRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
};

static_assert(sizeof(UFortMovementMode_BaseCCRuntimeData) == 0x58, "Size mismatch for UFortMovementMode_BaseCCRuntimeData");

// Size: 0x200 (Inherited: 0x210, Single: 0xfffffff0)
class UFortMovementMode_BaseCCLogic : public UFortMovementMode_BaseExtLogic
{
public:
    TWeakObjectPtr<AController*> OwnerController; // 0x1e8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> FortPlayerController; // 0x1f0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortAIController*> FortAIController; // 0x1f8 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UFortMovementMode_BaseCCLogic) == 0x200, "Size mismatch for UFortMovementMode_BaseCCLogic");
static_assert(offsetof(UFortMovementMode_BaseCCLogic, OwnerController) == 0x1e8, "Offset mismatch for UFortMovementMode_BaseCCLogic::OwnerController");
static_assert(offsetof(UFortMovementMode_BaseCCLogic, FortPlayerController) == 0x1f0, "Offset mismatch for UFortMovementMode_BaseCCLogic::FortPlayerController");
static_assert(offsetof(UFortMovementMode_BaseCCLogic, FortAIController) == 0x1f8, "Offset mismatch for UFortMovementMode_BaseCCLogic::FortAIController");

// Size: 0x60 (Inherited: 0xc0, Single: 0xffffffa0)
class UFortMovementMode_CCLockOnRuntimeData : public UFortMovementMode_BaseCCRuntimeData
{
public:
};

static_assert(sizeof(UFortMovementMode_CCLockOnRuntimeData) == 0x60, "Size mismatch for UFortMovementMode_CCLockOnRuntimeData");

// Size: 0x200 (Inherited: 0x410, Single: 0xfffffdf0)
class UFortMovementMode_CCLockOnLogic : public UFortMovementMode_BaseCCLogic
{
public:
};

static_assert(sizeof(UFortMovementMode_CCLockOnLogic) == 0x200, "Size mismatch for UFortMovementMode_CCLockOnLogic");

// Size: 0x90 (Inherited: 0x120, Single: 0xffffff70)
class UFortMovementMode_CCSideScrollerRuntimeData : public UFortMovementMode_CCLockOnRuntimeData
{
public:
    uint8_t Pad_60[0x8]; // 0x60 (Size: 0x8, Type: PaddingProperty)
    float DesiredRotationYaw; // 0x68 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_6c[0x24]; // 0x6c (Size: 0x24, Type: PaddingProperty)
};

static_assert(sizeof(UFortMovementMode_CCSideScrollerRuntimeData) == 0x90, "Size mismatch for UFortMovementMode_CCSideScrollerRuntimeData");
static_assert(offsetof(UFortMovementMode_CCSideScrollerRuntimeData, DesiredRotationYaw) == 0x68, "Offset mismatch for UFortMovementMode_CCSideScrollerRuntimeData::DesiredRotationYaw");

// Size: 0x2b0 (Inherited: 0x610, Single: 0xfffffca0)
class UFortMovementMode_CCSideScrollerLogic : public UFortMovementMode_CCLockOnLogic
{
public:

public:
    void SetDesiredRotationYaw(float& NewDesiredRotationYaw); // 0xa3a1bb4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortMovementMode_CCSideScrollerLogic) == 0x2b0, "Size mismatch for UFortMovementMode_CCSideScrollerLogic");

// Size: 0x78 (Inherited: 0x120, Single: 0xffffff58)
class UFortMovementMode_CCThirdPersonRuntimeData : public UFortMovementMode_CCLockOnRuntimeData
{
public:
};

static_assert(sizeof(UFortMovementMode_CCThirdPersonRuntimeData) == 0x78, "Size mismatch for UFortMovementMode_CCThirdPersonRuntimeData");

// Size: 0x200 (Inherited: 0x610, Single: 0xfffffbf0)
class UFortMovementMode_CCThirdPersonLogic : public UFortMovementMode_CCLockOnLogic
{
public:
};

static_assert(sizeof(UFortMovementMode_CCThirdPersonLogic) == 0x200, "Size mismatch for UFortMovementMode_CCThirdPersonLogic");

// Size: 0x90 (Inherited: 0x198, Single: 0xfffffef8)
class UFortMovementMode_CCThirdPersonFixedRuntimeData : public UFortMovementMode_CCThirdPersonRuntimeData
{
public:
};

static_assert(sizeof(UFortMovementMode_CCThirdPersonFixedRuntimeData) == 0x90, "Size mismatch for UFortMovementMode_CCThirdPersonFixedRuntimeData");

// Size: 0x200 (Inherited: 0x810, Single: 0xfffff9f0)
class UFortMovementMode_CCThirdPersonFixedLogic : public UFortMovementMode_CCThirdPersonLogic
{
public:
};

static_assert(sizeof(UFortMovementMode_CCThirdPersonFixedLogic) == 0x200, "Size mismatch for UFortMovementMode_CCThirdPersonFixedLogic");

// Size: 0x98 (Inherited: 0x198, Single: 0xffffff00)
class UFortMovementMode_CCThirdPersonTwinStickRuntimeData : public UFortMovementMode_CCThirdPersonRuntimeData
{
public:
};

static_assert(sizeof(UFortMovementMode_CCThirdPersonTwinStickRuntimeData) == 0x98, "Size mismatch for UFortMovementMode_CCThirdPersonTwinStickRuntimeData");

// Size: 0x200 (Inherited: 0x810, Single: 0xfffff9f0)
class UFortMovementMode_CCThirdPersonTwinStickLogic : public UFortMovementMode_CCThirdPersonLogic
{
public:
};

static_assert(sizeof(UFortMovementMode_CCThirdPersonTwinStickLogic) == 0x200, "Size mismatch for UFortMovementMode_CCThirdPersonTwinStickLogic");

// Size: 0x30 (Inherited: 0xa0, Single: 0xffffff90)
class UTargetingFilterCCFOV : public USimpleTargetingFilterTask
{
public:
    float FliedOfView; // 0x28 (Size: 0x4, Type: FloatProperty)
    bool bRequireLineOfSight; // 0x2c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UTargetingFilterCCFOV) == 0x30, "Size mismatch for UTargetingFilterCCFOV");
static_assert(offsetof(UTargetingFilterCCFOV, FliedOfView) == 0x28, "Offset mismatch for UTargetingFilterCCFOV::FliedOfView");
static_assert(offsetof(UTargetingFilterCCFOV, bRequireLineOfSight) == 0x2c, "Offset mismatch for UTargetingFilterCCFOV::bRequireLineOfSight");

// Size: 0x78 (Inherited: 0xa0, Single: 0xffffffd8)
class UTargetingFilter_CC_Base : public USimpleTargetingFilterTask
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FCustomControlTargetingData TargetingData; // 0x30 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UTargetingFilter_CC_Base) == 0x78, "Size mismatch for UTargetingFilter_CC_Base");
static_assert(offsetof(UTargetingFilter_CC_Base, TargetingData) == 0x30, "Offset mismatch for UTargetingFilter_CC_Base::TargetingData");

// Size: 0x38 (Inherited: 0xb0, Single: 0xffffff88)
class UTargetingSelectionCCIdleInteract : public UTargetingSelectionCCRange
{
public:
};

static_assert(sizeof(UTargetingSelectionCCIdleInteract) == 0x38, "Size mismatch for UTargetingSelectionCCIdleInteract");

// Size: 0x38 (Inherited: 0x78, Single: 0xffffffc0)
class UTargetingSelectionCCRange : public USimpleTargetingSelectionTask
{
public:
    float Radius; // 0x28 (Size: 0x4, Type: FloatProperty)
    float Height; // 0x2c (Size: 0x4, Type: FloatProperty)
    float ForwardOffset; // 0x30 (Size: 0x4, Type: FloatProperty)
    float VerticalOffset; // 0x34 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UTargetingSelectionCCRange) == 0x38, "Size mismatch for UTargetingSelectionCCRange");
static_assert(offsetof(UTargetingSelectionCCRange, Radius) == 0x28, "Offset mismatch for UTargetingSelectionCCRange::Radius");
static_assert(offsetof(UTargetingSelectionCCRange, Height) == 0x2c, "Offset mismatch for UTargetingSelectionCCRange::Height");
static_assert(offsetof(UTargetingSelectionCCRange, ForwardOffset) == 0x30, "Offset mismatch for UTargetingSelectionCCRange::ForwardOffset");
static_assert(offsetof(UTargetingSelectionCCRange, VerticalOffset) == 0x34, "Offset mismatch for UTargetingSelectionCCRange::VerticalOffset");

// Size: 0x78 (Inherited: 0x78, Single: 0x0)
class UTargetingSelection_CC_Base : public USimpleTargetingSelectionTask
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FCustomControlTargetingData TargetingData; // 0x30 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UTargetingSelection_CC_Base) == 0x78, "Size mismatch for UTargetingSelection_CC_Base");
static_assert(offsetof(UTargetingSelection_CC_Base, TargetingData) == 0x30, "Offset mismatch for UTargetingSelection_CC_Base::TargetingData");

// Size: 0x80 (Inherited: 0xb0, Single: 0xffffffd0)
class UTargetingSort_CC_Base : public USimpleTargetingSortTask
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    FCustomControlTargetingData TargetingData; // 0x38 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UTargetingSort_CC_Base) == 0x80, "Size mismatch for UTargetingSort_CC_Base");
static_assert(offsetof(UTargetingSort_CC_Base, TargetingData) == 0x38, "Offset mismatch for UTargetingSort_CC_Base::TargetingData");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UTargetingTask_CC_DataHolder : public UInterface
{
public:
};

static_assert(sizeof(UTargetingTask_CC_DataHolder) == 0x28, "Size mismatch for UTargetingTask_CC_DataHolder");

// Size: 0x80 (Inherited: 0xb0, Single: 0xffffffd0)
class UCustomControlInputBindings_ThirdPersonSprint : public UCustomControlInputBindings_InputComponent
{
public:
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
    float AnalogInputDeadZone; // 0x50 (Size: 0x4, Type: FloatProperty)
    float RotateStickThreshold; // 0x54 (Size: 0x4, Type: FloatProperty)
    float CameraRotationThreshold; // 0x58 (Size: 0x4, Type: FloatProperty)
    float InputRateIfCameraRotationThreshold; // 0x5c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_60[0x20]; // 0x60 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UCustomControlInputBindings_ThirdPersonSprint) == 0x80, "Size mismatch for UCustomControlInputBindings_ThirdPersonSprint");
static_assert(offsetof(UCustomControlInputBindings_ThirdPersonSprint, AnalogInputDeadZone) == 0x50, "Offset mismatch for UCustomControlInputBindings_ThirdPersonSprint::AnalogInputDeadZone");
static_assert(offsetof(UCustomControlInputBindings_ThirdPersonSprint, RotateStickThreshold) == 0x54, "Offset mismatch for UCustomControlInputBindings_ThirdPersonSprint::RotateStickThreshold");
static_assert(offsetof(UCustomControlInputBindings_ThirdPersonSprint, CameraRotationThreshold) == 0x58, "Offset mismatch for UCustomControlInputBindings_ThirdPersonSprint::CameraRotationThreshold");
static_assert(offsetof(UCustomControlInputBindings_ThirdPersonSprint, InputRateIfCameraRotationThreshold) == 0x5c, "Offset mismatch for UCustomControlInputBindings_ThirdPersonSprint::InputRateIfCameraRotationThreshold");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInteractionPointOptions
{
    uint8_t InteractionOrigin; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float InteractDistance; // 0x4 (Size: 0x4, Type: FloatProperty)
    float InteractHighlightDistance; // 0x8 (Size: 0x4, Type: FloatProperty)
    float InteractExtentRadius; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FInteractionPointOptions) == 0x10, "Size mismatch for FInteractionPointOptions");
static_assert(offsetof(FInteractionPointOptions, InteractionOrigin) == 0x0, "Offset mismatch for FInteractionPointOptions::InteractionOrigin");
static_assert(offsetof(FInteractionPointOptions, InteractDistance) == 0x4, "Offset mismatch for FInteractionPointOptions::InteractDistance");
static_assert(offsetof(FInteractionPointOptions, InteractHighlightDistance) == 0x8, "Offset mismatch for FInteractionPointOptions::InteractHighlightDistance");
static_assert(offsetof(FInteractionPointOptions, InteractExtentRadius) == 0xc, "Offset mismatch for FInteractionPointOptions::InteractExtentRadius");

// Size: 0x6 (Inherited: 0x0, Single: 0x6)
struct FInputOptions_SideScroller
{
    bool bConstraintMovement; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bShootingLocomotionLockDirection; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bAimingLocomotionLockDirection; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t AimControls; // 0x3 (Size: 0x1, Type: EnumProperty)
    uint8_t SideScrollerJump; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t SideScrollerCrouch; // 0x5 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FInputOptions_SideScroller) == 0x6, "Size mismatch for FInputOptions_SideScroller");
static_assert(offsetof(FInputOptions_SideScroller, bConstraintMovement) == 0x0, "Offset mismatch for FInputOptions_SideScroller::bConstraintMovement");
static_assert(offsetof(FInputOptions_SideScroller, bShootingLocomotionLockDirection) == 0x1, "Offset mismatch for FInputOptions_SideScroller::bShootingLocomotionLockDirection");
static_assert(offsetof(FInputOptions_SideScroller, bAimingLocomotionLockDirection) == 0x2, "Offset mismatch for FInputOptions_SideScroller::bAimingLocomotionLockDirection");
static_assert(offsetof(FInputOptions_SideScroller, AimControls) == 0x3, "Offset mismatch for FInputOptions_SideScroller::AimControls");
static_assert(offsetof(FInputOptions_SideScroller, SideScrollerJump) == 0x4, "Offset mismatch for FInputOptions_SideScroller::SideScrollerJump");
static_assert(offsetof(FInputOptions_SideScroller, SideScrollerCrouch) == 0x5, "Offset mismatch for FInputOptions_SideScroller::SideScrollerCrouch");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FInputOptions_ThirdPerson
{
    bool bAutoFire; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FInputOptions_ThirdPerson) == 0x1, "Size mismatch for FInputOptions_ThirdPerson");
static_assert(offsetof(FInputOptions_ThirdPerson, bAutoFire) == 0x0, "Offset mismatch for FInputOptions_ThirdPerson::bAutoFire");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCustomControlsState
{
    bool bHasFocusTarget; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t AttackType; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t TargetingType; // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t WeaponType; // 0x3 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FCustomControlsState) == 0x4, "Size mismatch for FCustomControlsState");
static_assert(offsetof(FCustomControlsState, bHasFocusTarget) == 0x0, "Offset mismatch for FCustomControlsState::bHasFocusTarget");
static_assert(offsetof(FCustomControlsState, AttackType) == 0x1, "Offset mismatch for FCustomControlsState::AttackType");
static_assert(offsetof(FCustomControlsState, TargetingType) == 0x2, "Offset mismatch for FCustomControlsState::TargetingType");
static_assert(offsetof(FCustomControlsState, WeaponType) == 0x3, "Offset mismatch for FCustomControlsState::WeaponType");

// Size: 0x24 (Inherited: 0x0, Single: 0x24)
struct FCustomControlWeightingTargetingData
{
    float PlayerWeight; // 0x0 (Size: 0x4, Type: FloatProperty)
    float CreatureWeight; // 0x4 (Size: 0x4, Type: FloatProperty)
    float VehicleWeight; // 0x8 (Size: 0x4, Type: FloatProperty)
    float DestructiblesWeight; // 0xc (Size: 0x4, Type: FloatProperty)
    float AngleWeight; // 0x10 (Size: 0x4, Type: FloatProperty)
    bool bAngleWeightScaling; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    float DistanceWeight; // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bDistanceWeightScaling; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
    float RetainedTargetWeight; // 0x20 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FCustomControlWeightingTargetingData) == 0x24, "Size mismatch for FCustomControlWeightingTargetingData");
static_assert(offsetof(FCustomControlWeightingTargetingData, PlayerWeight) == 0x0, "Offset mismatch for FCustomControlWeightingTargetingData::PlayerWeight");
static_assert(offsetof(FCustomControlWeightingTargetingData, CreatureWeight) == 0x4, "Offset mismatch for FCustomControlWeightingTargetingData::CreatureWeight");
static_assert(offsetof(FCustomControlWeightingTargetingData, VehicleWeight) == 0x8, "Offset mismatch for FCustomControlWeightingTargetingData::VehicleWeight");
static_assert(offsetof(FCustomControlWeightingTargetingData, DestructiblesWeight) == 0xc, "Offset mismatch for FCustomControlWeightingTargetingData::DestructiblesWeight");
static_assert(offsetof(FCustomControlWeightingTargetingData, AngleWeight) == 0x10, "Offset mismatch for FCustomControlWeightingTargetingData::AngleWeight");
static_assert(offsetof(FCustomControlWeightingTargetingData, bAngleWeightScaling) == 0x14, "Offset mismatch for FCustomControlWeightingTargetingData::bAngleWeightScaling");
static_assert(offsetof(FCustomControlWeightingTargetingData, DistanceWeight) == 0x18, "Offset mismatch for FCustomControlWeightingTargetingData::DistanceWeight");
static_assert(offsetof(FCustomControlWeightingTargetingData, bDistanceWeightScaling) == 0x1c, "Offset mismatch for FCustomControlWeightingTargetingData::bDistanceWeightScaling");
static_assert(offsetof(FCustomControlWeightingTargetingData, RetainedTargetWeight) == 0x20, "Offset mismatch for FCustomControlWeightingTargetingData::RetainedTargetWeight");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FCustomControlCommonTargetingData
{
    FCustomControlWeightingTargetingData WeightingData; // 0x0 (Size: 0x24, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    AActor* DeviceTest; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCustomControlCommonTargetingData) == 0x30, "Size mismatch for FCustomControlCommonTargetingData");
static_assert(offsetof(FCustomControlCommonTargetingData, WeightingData) == 0x0, "Offset mismatch for FCustomControlCommonTargetingData::WeightingData");
static_assert(offsetof(FCustomControlCommonTargetingData, DeviceTest) == 0x28, "Offset mismatch for FCustomControlCommonTargetingData::DeviceTest");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FCustomControlStateDependentTargetingData
{
    float Distance; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Angle; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bUseAngleWhileMoving; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    float AngleWhileMoving; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bRequireLineOfSight; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FCustomControlStateDependentTargetingData) == 0x14, "Size mismatch for FCustomControlStateDependentTargetingData");
static_assert(offsetof(FCustomControlStateDependentTargetingData, Distance) == 0x0, "Offset mismatch for FCustomControlStateDependentTargetingData::Distance");
static_assert(offsetof(FCustomControlStateDependentTargetingData, Angle) == 0x4, "Offset mismatch for FCustomControlStateDependentTargetingData::Angle");
static_assert(offsetof(FCustomControlStateDependentTargetingData, bUseAngleWhileMoving) == 0x8, "Offset mismatch for FCustomControlStateDependentTargetingData::bUseAngleWhileMoving");
static_assert(offsetof(FCustomControlStateDependentTargetingData, AngleWhileMoving) == 0xc, "Offset mismatch for FCustomControlStateDependentTargetingData::AngleWhileMoving");
static_assert(offsetof(FCustomControlStateDependentTargetingData, bRequireLineOfSight) == 0x10, "Offset mismatch for FCustomControlStateDependentTargetingData::bRequireLineOfSight");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FCustomControlTargetingData
{
    FCustomControlCommonTargetingData CommonTargetingData; // 0x0 (Size: 0x30, Type: StructProperty)
    FCustomControlStateDependentTargetingData StateDependentTargetingData; // 0x30 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCustomControlTargetingData) == 0x48, "Size mismatch for FCustomControlTargetingData");
static_assert(offsetof(FCustomControlTargetingData, CommonTargetingData) == 0x0, "Offset mismatch for FCustomControlTargetingData::CommonTargetingData");
static_assert(offsetof(FCustomControlTargetingData, StateDependentTargetingData) == 0x30, "Offset mismatch for FCustomControlTargetingData::StateDependentTargetingData");

// Size: 0x48 (Inherited: 0x10, Single: 0x38)
struct FFortMovementMode_CCSideScrollerCreationData : FFortMovementMode_BaseExtCreationData
{
    bool bConstraintMovement; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float ForwardRotationYaw; // 0x14 (Size: 0x4, Type: FloatProperty)
    FVector DeviceForwardVector; // 0x18 (Size: 0x18, Type: StructProperty)
    float SpeedMultiplier; // 0x30 (Size: 0x4, Type: FloatProperty)
    float SpeedMultiplierWhenShooting; // 0x34 (Size: 0x4, Type: FloatProperty)
    float SpeedMultiplierWhenAiming; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t LockOnMode; // 0x3c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3d[0x3]; // 0x3d (Size: 0x3, Type: PaddingProperty)
    float NPCDistanceToFaceTarget; // 0x40 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortMovementMode_CCSideScrollerCreationData) == 0x48, "Size mismatch for FFortMovementMode_CCSideScrollerCreationData");
static_assert(offsetof(FFortMovementMode_CCSideScrollerCreationData, bConstraintMovement) == 0x10, "Offset mismatch for FFortMovementMode_CCSideScrollerCreationData::bConstraintMovement");
static_assert(offsetof(FFortMovementMode_CCSideScrollerCreationData, ForwardRotationYaw) == 0x14, "Offset mismatch for FFortMovementMode_CCSideScrollerCreationData::ForwardRotationYaw");
static_assert(offsetof(FFortMovementMode_CCSideScrollerCreationData, DeviceForwardVector) == 0x18, "Offset mismatch for FFortMovementMode_CCSideScrollerCreationData::DeviceForwardVector");
static_assert(offsetof(FFortMovementMode_CCSideScrollerCreationData, SpeedMultiplier) == 0x30, "Offset mismatch for FFortMovementMode_CCSideScrollerCreationData::SpeedMultiplier");
static_assert(offsetof(FFortMovementMode_CCSideScrollerCreationData, SpeedMultiplierWhenShooting) == 0x34, "Offset mismatch for FFortMovementMode_CCSideScrollerCreationData::SpeedMultiplierWhenShooting");
static_assert(offsetof(FFortMovementMode_CCSideScrollerCreationData, SpeedMultiplierWhenAiming) == 0x38, "Offset mismatch for FFortMovementMode_CCSideScrollerCreationData::SpeedMultiplierWhenAiming");
static_assert(offsetof(FFortMovementMode_CCSideScrollerCreationData, LockOnMode) == 0x3c, "Offset mismatch for FFortMovementMode_CCSideScrollerCreationData::LockOnMode");
static_assert(offsetof(FFortMovementMode_CCSideScrollerCreationData, NPCDistanceToFaceTarget) == 0x40, "Offset mismatch for FFortMovementMode_CCSideScrollerCreationData::NPCDistanceToFaceTarget");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FFortMovementMode_CCThirdPersonCreationData : FFortMovementMode_BaseExtCreationData
{
    float SpeedMultiplier; // 0x10 (Size: 0x4, Type: FloatProperty)
    float SpeedMultiplierWhenShooting; // 0x14 (Size: 0x4, Type: FloatProperty)
    float SpeedMultiplierWhenAiming; // 0x18 (Size: 0x4, Type: FloatProperty)
    float RotationRateMultiplier; // 0x1c (Size: 0x4, Type: FloatProperty)
    float RotationRateWhenShootingMultiplier; // 0x20 (Size: 0x4, Type: FloatProperty)
    float RotationRateWhenAimingMultiplier; // 0x24 (Size: 0x4, Type: FloatProperty)
    uint8_t LockOnMode; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    float FixedFacingYaw; // 0x2c (Size: 0x4, Type: FloatProperty)
    float TacticalSprintRotationRateYaw; // 0x30 (Size: 0x4, Type: FloatProperty)
    float SkydivingRotationRatePitch; // 0x34 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFortMovementMode_CCThirdPersonCreationData) == 0x38, "Size mismatch for FFortMovementMode_CCThirdPersonCreationData");
static_assert(offsetof(FFortMovementMode_CCThirdPersonCreationData, SpeedMultiplier) == 0x10, "Offset mismatch for FFortMovementMode_CCThirdPersonCreationData::SpeedMultiplier");
static_assert(offsetof(FFortMovementMode_CCThirdPersonCreationData, SpeedMultiplierWhenShooting) == 0x14, "Offset mismatch for FFortMovementMode_CCThirdPersonCreationData::SpeedMultiplierWhenShooting");
static_assert(offsetof(FFortMovementMode_CCThirdPersonCreationData, SpeedMultiplierWhenAiming) == 0x18, "Offset mismatch for FFortMovementMode_CCThirdPersonCreationData::SpeedMultiplierWhenAiming");
static_assert(offsetof(FFortMovementMode_CCThirdPersonCreationData, RotationRateMultiplier) == 0x1c, "Offset mismatch for FFortMovementMode_CCThirdPersonCreationData::RotationRateMultiplier");
static_assert(offsetof(FFortMovementMode_CCThirdPersonCreationData, RotationRateWhenShootingMultiplier) == 0x20, "Offset mismatch for FFortMovementMode_CCThirdPersonCreationData::RotationRateWhenShootingMultiplier");
static_assert(offsetof(FFortMovementMode_CCThirdPersonCreationData, RotationRateWhenAimingMultiplier) == 0x24, "Offset mismatch for FFortMovementMode_CCThirdPersonCreationData::RotationRateWhenAimingMultiplier");
static_assert(offsetof(FFortMovementMode_CCThirdPersonCreationData, LockOnMode) == 0x28, "Offset mismatch for FFortMovementMode_CCThirdPersonCreationData::LockOnMode");
static_assert(offsetof(FFortMovementMode_CCThirdPersonCreationData, FixedFacingYaw) == 0x2c, "Offset mismatch for FFortMovementMode_CCThirdPersonCreationData::FixedFacingYaw");
static_assert(offsetof(FFortMovementMode_CCThirdPersonCreationData, TacticalSprintRotationRateYaw) == 0x30, "Offset mismatch for FFortMovementMode_CCThirdPersonCreationData::TacticalSprintRotationRateYaw");
static_assert(offsetof(FFortMovementMode_CCThirdPersonCreationData, SkydivingRotationRatePitch) == 0x34, "Offset mismatch for FFortMovementMode_CCThirdPersonCreationData::SkydivingRotationRatePitch");

