/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ArmASR
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UArmASRSettings : public UObject
{
public:
};

static_assert(sizeof(UArmASRSettings) == 0x28, "Size mismatch for UArmASRSettings");

