/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_HUDControllerUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "UMG.h"
#include "DynamicUI.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "ModelViewViewModel.h"

// Size: 0x300 (Inherited: 0x458, Single: 0xfffffea8)
class UHUDControllerContainerBase : public UUserWidget
{
public:
    uint8_t Pad_2b0[0x8]; // 0x2b0 (Size: 0x8, Type: PaddingProperty)
    UClass* SlotViewModelClass; // 0x2b8 (Size: 0x8, Type: ClassProperty)
    TArray<UUserWidget*> SlotContentWidgets; // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    TArray<UMVVMViewModelBase*> SlotViewModels; // 0x2d0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_2e0[0x20]; // 0x2e0 (Size: 0x20, Type: PaddingProperty)

private:
    void HandleHUDElementVisibilityRefreshed(); // 0x11e5d4e0 (Index: 0x2, Flags: Final|Native|Private)

protected:
    virtual TSoftClassPtr GetContentWidgetClass(AFortAthenaMutator_HUDElementVisibility*& const HUDElementVisibilityMutator) const; // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent|Const)
    virtual TArray<UContentWidget*> GetContentWidgetContainers() const; // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent|Const)
    virtual void OnContentWidgetSet(UUserWidget*& ContentWidget, int32_t& Index, AFortAthenaMutator_HUDElementVisibility*& const HUDMutator); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnViewModelCreated(UMVVMViewModelBase*& ViewModel, UUserWidget*& ContentWidget, int32_t& Index); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UHUDControllerContainerBase) == 0x300, "Size mismatch for UHUDControllerContainerBase");
static_assert(offsetof(UHUDControllerContainerBase, SlotViewModelClass) == 0x2b8, "Offset mismatch for UHUDControllerContainerBase::SlotViewModelClass");
static_assert(offsetof(UHUDControllerContainerBase, SlotContentWidgets) == 0x2c0, "Offset mismatch for UHUDControllerContainerBase::SlotContentWidgets");
static_assert(offsetof(UHUDControllerContainerBase, SlotViewModels) == 0x2d0, "Offset mismatch for UHUDControllerContainerBase::SlotViewModels");

// Size: 0x2f0 (Inherited: 0x598, Single: 0xfffffd58)
class AHUDControllerDynamicUIDirector : public ADynamicUIDirectorBase
{
public:
    UDynamicUIScene* PlayerInfoWidgetOverrideScene; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* QuickbarWidgetOverrideScene; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* EquippedItemWidgetOverrideScene; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    TArray<UDynamicUIScene*> AddedScenes; // 0x2e0 (Size: 0x10, Type: ArrayProperty)

private:
    void HandleHUDElementVisibilityRefreshed(); // 0x11e5d4cc (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(AHUDControllerDynamicUIDirector) == 0x2f0, "Size mismatch for AHUDControllerDynamicUIDirector");
static_assert(offsetof(AHUDControllerDynamicUIDirector, PlayerInfoWidgetOverrideScene) == 0x2c8, "Offset mismatch for AHUDControllerDynamicUIDirector::PlayerInfoWidgetOverrideScene");
static_assert(offsetof(AHUDControllerDynamicUIDirector, QuickbarWidgetOverrideScene) == 0x2d0, "Offset mismatch for AHUDControllerDynamicUIDirector::QuickbarWidgetOverrideScene");
static_assert(offsetof(AHUDControllerDynamicUIDirector, EquippedItemWidgetOverrideScene) == 0x2d8, "Offset mismatch for AHUDControllerDynamicUIDirector::EquippedItemWidgetOverrideScene");
static_assert(offsetof(AHUDControllerDynamicUIDirector, AddedScenes) == 0x2e0, "Offset mismatch for AHUDControllerDynamicUIDirector::AddedScenes");

// Size: 0x2f0 (Inherited: 0x458, Single: 0xfffffe98)
class UHUDControllerWidgetBase : public UUserWidget
{
public:
    uint8_t Pad_2b0[0x8]; // 0x2b0 (Size: 0x8, Type: PaddingProperty)
    UClass* ViewModelClass; // 0x2b8 (Size: 0x8, Type: ClassProperty)
    UUserWidget* ContentWidget; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UMVVMViewModelBase* ViewModel; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2d0[0x20]; // 0x2d0 (Size: 0x20, Type: PaddingProperty)

private:
    void HandleHUDElementVisibilityRefreshed(); // 0x11e5d4f4 (Index: 0x2, Flags: Final|Native|Private)

protected:
    virtual TSoftClassPtr GetContentWidgetClass(AFortAthenaMutator_HUDElementVisibility*& const HUDElementVisibilityMutator) const; // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent|Const)
    virtual UContentWidget* GetContentWidgetContainer() const; // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent|Const)
    virtual void OnContentWidgetSet(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnViewModelCreated(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UHUDControllerWidgetBase) == 0x2f0, "Size mismatch for UHUDControllerWidgetBase");
static_assert(offsetof(UHUDControllerWidgetBase, ViewModelClass) == 0x2b8, "Offset mismatch for UHUDControllerWidgetBase::ViewModelClass");
static_assert(offsetof(UHUDControllerWidgetBase, ContentWidget) == 0x2c0, "Offset mismatch for UHUDControllerWidgetBase::ContentWidget");
static_assert(offsetof(UHUDControllerWidgetBase, ViewModel) == 0x2c8, "Offset mismatch for UHUDControllerWidgetBase::ViewModel");

