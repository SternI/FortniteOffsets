/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Curie
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"
#include "Engine.h"
#include "ModularGameplay.h"
#include "GameplayTags.h"

// Size: 0x30 (Inherited: 0xb8, Single: 0xffffff78)
class UFireSelfInteractHandler_C : public UFortCurieElementInteractWithSameElementHandlerFire
{
public:
};

static_assert(sizeof(UFireSelfInteractHandler_C) == 0x30, "Size mismatch for UFireSelfInteractHandler_C");

// Size: 0xa0 (Inherited: 0x178, Single: 0xffffff28)
class UWaterMaterialInteractHandler_C : public UFortCurieElementInteractWithMaterialHandlerWater
{
public:
};

static_assert(sizeof(UWaterMaterialInteractHandler_C) == 0xa0, "Size mismatch for UWaterMaterialInteractHandler_C");

// Size: 0x90 (Inherited: 0x150, Single: 0xffffff40)
class UFireContainerInteractHandler_C : public UFortCurieElementInteractWithContainerHandler
{
public:
};

static_assert(sizeof(UFireContainerInteractHandler_C) == 0x90, "Size mismatch for UFireContainerInteractHandler_C");

// Size: 0xe8 (Inherited: 0x2d8, Single: 0xfffffe10)
class UCurieEntityStateBehavior_Drying_C : public UFortCurieEntityStateBehavior_Drying
{
public:
};

static_assert(sizeof(UCurieEntityStateBehavior_Drying_C) == 0xe8, "Size mismatch for UCurieEntityStateBehavior_Drying_C");

// Size: 0xe0 (Inherited: 0x1f0, Single: 0xfffffef0)
class UCurieEntityStateBehavior_ElemInteraction_Fire_C : public UFortCurieEntityStateBehavior
{
public:
};

static_assert(sizeof(UCurieEntityStateBehavior_ElemInteraction_Fire_C) == 0xe0, "Size mismatch for UCurieEntityStateBehavior_ElemInteraction_Fire_C");

// Size: 0xe0 (Inherited: 0x1f0, Single: 0xfffffef0)
class UCurieEntityStateBehavior_ElemInteraction_Water_C : public UFortCurieEntityStateBehavior
{
public:
};

static_assert(sizeof(UCurieEntityStateBehavior_ElemInteraction_Water_C) == 0xe0, "Size mismatch for UCurieEntityStateBehavior_ElemInteraction_Water_C");

// Size: 0x40 (Inherited: 0xd8, Single: 0xffffff68)
class UFireAttachConditionHandler_C : public UFortCurieElementAttachConditionHandlerFire
{
public:
};

static_assert(sizeof(UFireAttachConditionHandler_C) == 0x40, "Size mismatch for UFireAttachConditionHandler_C");

// Size: 0xe0 (Inherited: 0x1f0, Single: 0xfffffef0)
class UCurieEntityStateBehavior_ElemAttached_Fire_C : public UFortCurieEntityStateBehavior
{
public:
};

static_assert(sizeof(UCurieEntityStateBehavior_ElemAttached_Fire_C) == 0xe0, "Size mismatch for UCurieEntityStateBehavior_ElemAttached_Fire_C");

// Size: 0xe0 (Inherited: 0x2d0, Single: 0xfffffe10)
class UCurieEntityStateBehavior_FullyIgnited_C : public UFortCurieEntityStateBehavior_Burning
{
public:
};

static_assert(sizeof(UCurieEntityStateBehavior_FullyIgnited_C) == 0xe0, "Size mismatch for UCurieEntityStateBehavior_FullyIgnited_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_CurieElementalStatus_Burning_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_CurieElementalStatus_Burning_C) == 0xa68, "Size mismatch for UGE_CurieElementalStatus_Burning_C");

// Size: 0x80 (Inherited: 0xd8, Single: 0xffffffa8)
class UWaterFireInteractHandler_C : public UFortCurieElementInteractWithElementHandler
{
public:
};

static_assert(sizeof(UWaterFireInteractHandler_C) == 0x80, "Size mismatch for UWaterFireInteractHandler_C");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UWaterSelfInteractHandler_C : public UFortCurieElementInteractWithSameElementHandler
{
public:
};

static_assert(sizeof(UWaterSelfInteractHandler_C) == 0x30, "Size mismatch for UWaterSelfInteractHandler_C");

// Size: 0x90 (Inherited: 0x1d0, Single: 0xfffffec0)
class UFireAttachHandler_C : public UFortCurieElementAttachHandlerFire
{
public:
};

static_assert(sizeof(UFireAttachHandler_C) == 0x90, "Size mismatch for UFireAttachHandler_C");

// Size: 0x80 (Inherited: 0xd8, Single: 0xffffffa8)
class UFireWaterInteractHandler_C : public UFortCurieElementInteractWithElementHandler
{
public:
};

static_assert(sizeof(UFireWaterInteractHandler_C) == 0x80, "Size mismatch for UFireWaterInteractHandler_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Curie_FireInteract_Vehicle_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Curie_FireInteract_Vehicle_C) == 0xa68, "Size mismatch for UGE_Curie_FireInteract_Vehicle_C");

// Size: 0x40 (Inherited: 0xd8, Single: 0xffffff68)
class UWaterAttachConditionHandler_C : public UFortCurieElementAttachConditionHandlerWater
{
public:
};

static_assert(sizeof(UWaterAttachConditionHandler_C) == 0x40, "Size mismatch for UWaterAttachConditionHandler_C");

// Size: 0x90 (Inherited: 0x168, Single: 0xffffff28)
class UFireMaterialInteractHandler_C : public UFortCurieElementInteractWithMaterialHandlerFire
{
public:
};

static_assert(sizeof(UFireMaterialInteractHandler_C) == 0x90, "Size mismatch for UFireMaterialInteractHandler_C");

// Size: 0x28 (Inherited: 0xa0, Single: 0xffffff88)
class UFireAllocationHandler_C : public UFortCurieElementAllocationHandlerFire
{
public:
};

static_assert(sizeof(UFireAllocationHandler_C) == 0x28, "Size mismatch for UFireAllocationHandler_C");

// Size: 0xc8 (Inherited: 0xe0, Single: 0xffffffe8)
class UCurieComponent : public UActorComponent
{
public:
};

static_assert(sizeof(UCurieComponent) == 0xc8, "Size mismatch for UCurieComponent");

// Size: 0xc0 (Inherited: 0x50, Single: 0x70)
class UCurieEntityStateBehavior : public UCurieElementGameplayEffectOwner
{
public:
    FGameplayTagContainer RequiredAttachedElements; // 0x28 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer RequiredInteractingElements; // 0x48 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AllowedAttachmentEntityTypes; // 0x68 (Size: 0x20, Type: StructProperty)
    TArray<FCurieEffectContainer> OnBeginEffects; // 0x88 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OngoingEffects; // 0x98 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OnEndEffects; // 0xa8 (Size: 0x10, Type: ArrayProperty)
    uint8_t bShouldDetach : 1; // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bSkipExecuteAttachDetach : 1; // 0xb8:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UCurieEntityStateBehavior) == 0xc0, "Size mismatch for UCurieEntityStateBehavior");
static_assert(offsetof(UCurieEntityStateBehavior, RequiredAttachedElements) == 0x28, "Offset mismatch for UCurieEntityStateBehavior::RequiredAttachedElements");
static_assert(offsetof(UCurieEntityStateBehavior, RequiredInteractingElements) == 0x48, "Offset mismatch for UCurieEntityStateBehavior::RequiredInteractingElements");
static_assert(offsetof(UCurieEntityStateBehavior, AllowedAttachmentEntityTypes) == 0x68, "Offset mismatch for UCurieEntityStateBehavior::AllowedAttachmentEntityTypes");
static_assert(offsetof(UCurieEntityStateBehavior, OnBeginEffects) == 0x88, "Offset mismatch for UCurieEntityStateBehavior::OnBeginEffects");
static_assert(offsetof(UCurieEntityStateBehavior, OngoingEffects) == 0x98, "Offset mismatch for UCurieEntityStateBehavior::OngoingEffects");
static_assert(offsetof(UCurieEntityStateBehavior, OnEndEffects) == 0xa8, "Offset mismatch for UCurieEntityStateBehavior::OnEndEffects");
static_assert(offsetof(UCurieEntityStateBehavior, bShouldDetach) == 0xb8, "Offset mismatch for UCurieEntityStateBehavior::bShouldDetach");
static_assert(offsetof(UCurieEntityStateBehavior, bSkipExecuteAttachDetach) == 0xb8, "Offset mismatch for UCurieEntityStateBehavior::bSkipExecuteAttachDetach");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UCurieElementGameplayEffectOwner : public UObject
{
public:
};

static_assert(sizeof(UCurieElementGameplayEffectOwner) == 0x28, "Size mismatch for UCurieElementGameplayEffectOwner");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UCurieGlobals : public UObject
{
public:
    bool bEnableCurie; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    FSoftClassPath CurieGlobalsClassName; // 0x30 (Size: 0x18, Type: StructProperty)
    UCurieManager* RegisteredCurieManager; // 0x48 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UCurieGlobals) == 0x50, "Size mismatch for UCurieGlobals");
static_assert(offsetof(UCurieGlobals, bEnableCurie) == 0x28, "Offset mismatch for UCurieGlobals::bEnableCurie");
static_assert(offsetof(UCurieGlobals, CurieGlobalsClassName) == 0x30, "Offset mismatch for UCurieGlobals::CurieGlobalsClassName");
static_assert(offsetof(UCurieGlobals, RegisteredCurieManager) == 0x48, "Offset mismatch for UCurieGlobals::RegisteredCurieManager");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UCurieElementAllocationHandler : public UObject
{
public:
};

static_assert(sizeof(UCurieElementAllocationHandler) == 0x28, "Size mismatch for UCurieElementAllocationHandler");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UCurieElementInteractWithElementHandler : public UObject
{
public:
    uint8_t HandlerPriority; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t HandlerBehavior; // 0x29 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    FGameplayTag ElementTag; // 0x2c (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(UCurieElementInteractWithElementHandler) == 0x30, "Size mismatch for UCurieElementInteractWithElementHandler");
static_assert(offsetof(UCurieElementInteractWithElementHandler, HandlerPriority) == 0x28, "Offset mismatch for UCurieElementInteractWithElementHandler::HandlerPriority");
static_assert(offsetof(UCurieElementInteractWithElementHandler, HandlerBehavior) == 0x29, "Offset mismatch for UCurieElementInteractWithElementHandler::HandlerBehavior");
static_assert(offsetof(UCurieElementInteractWithElementHandler, ElementTag) == 0x2c, "Offset mismatch for UCurieElementInteractWithElementHandler::ElementTag");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UCurieElementInteractWithMaterialHandler : public UObject
{
public:
    uint8_t HandlerPriority; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t HandlerBehavior; // 0x29 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    FGameplayTag ElementTag; // 0x2c (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(UCurieElementInteractWithMaterialHandler) == 0x30, "Size mismatch for UCurieElementInteractWithMaterialHandler");
static_assert(offsetof(UCurieElementInteractWithMaterialHandler, HandlerPriority) == 0x28, "Offset mismatch for UCurieElementInteractWithMaterialHandler::HandlerPriority");
static_assert(offsetof(UCurieElementInteractWithMaterialHandler, HandlerBehavior) == 0x29, "Offset mismatch for UCurieElementInteractWithMaterialHandler::HandlerBehavior");
static_assert(offsetof(UCurieElementInteractWithMaterialHandler, ElementTag) == 0x2c, "Offset mismatch for UCurieElementInteractWithMaterialHandler::ElementTag");

// Size: 0x60 (Inherited: 0x50, Single: 0x10)
class UCurieElementAttachHandler : public UCurieElementGameplayEffectOwner
{
public:
    uint8_t HandlerPriority; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t HandlerBehavior; // 0x29 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    FGameplayTag ElementTag; // 0x2c (Size: 0x4, Type: StructProperty)
    TArray<FCurieEffectContainer> OnBeginAttachmentEffects; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OngoingAttachmentEffects; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OnEndAttachmentEffects; // 0x50 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCurieElementAttachHandler) == 0x60, "Size mismatch for UCurieElementAttachHandler");
static_assert(offsetof(UCurieElementAttachHandler, HandlerPriority) == 0x28, "Offset mismatch for UCurieElementAttachHandler::HandlerPriority");
static_assert(offsetof(UCurieElementAttachHandler, HandlerBehavior) == 0x29, "Offset mismatch for UCurieElementAttachHandler::HandlerBehavior");
static_assert(offsetof(UCurieElementAttachHandler, ElementTag) == 0x2c, "Offset mismatch for UCurieElementAttachHandler::ElementTag");
static_assert(offsetof(UCurieElementAttachHandler, OnBeginAttachmentEffects) == 0x30, "Offset mismatch for UCurieElementAttachHandler::OnBeginAttachmentEffects");
static_assert(offsetof(UCurieElementAttachHandler, OngoingAttachmentEffects) == 0x40, "Offset mismatch for UCurieElementAttachHandler::OngoingAttachmentEffects");
static_assert(offsetof(UCurieElementAttachHandler, OnEndAttachmentEffects) == 0x50, "Offset mismatch for UCurieElementAttachHandler::OnEndAttachmentEffects");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UCurieElementAttachConditionHandler : public UObject
{
public:
    uint8_t HandlerPriority; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    FGameplayTag ElementTag; // 0x2c (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(UCurieElementAttachConditionHandler) == 0x30, "Size mismatch for UCurieElementAttachConditionHandler");
static_assert(offsetof(UCurieElementAttachConditionHandler, HandlerPriority) == 0x28, "Offset mismatch for UCurieElementAttachConditionHandler::HandlerPriority");
static_assert(offsetof(UCurieElementAttachConditionHandler, ElementTag) == 0x2c, "Offset mismatch for UCurieElementAttachConditionHandler::ElementTag");

// Size: 0x70 (Inherited: 0x50, Single: 0x20)
class UCurieElementInteractWithContainerHandler : public UCurieElementGameplayEffectOwner
{
public:
    uint8_t HandlerPriority; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t HandlerBehavior; // 0x29 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    FGameplayTag ElementTag; // 0x2c (Size: 0x4, Type: StructProperty)
    TArray<FCurieEffectContainer> OnInstantInteractionEffects; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OnBeginInteractionEffects; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OngoingInteractionEffects; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FCurieEffectContainer> OnEndInteractionEffects; // 0x60 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCurieElementInteractWithContainerHandler) == 0x70, "Size mismatch for UCurieElementInteractWithContainerHandler");
static_assert(offsetof(UCurieElementInteractWithContainerHandler, HandlerPriority) == 0x28, "Offset mismatch for UCurieElementInteractWithContainerHandler::HandlerPriority");
static_assert(offsetof(UCurieElementInteractWithContainerHandler, HandlerBehavior) == 0x29, "Offset mismatch for UCurieElementInteractWithContainerHandler::HandlerBehavior");
static_assert(offsetof(UCurieElementInteractWithContainerHandler, ElementTag) == 0x2c, "Offset mismatch for UCurieElementInteractWithContainerHandler::ElementTag");
static_assert(offsetof(UCurieElementInteractWithContainerHandler, OnInstantInteractionEffects) == 0x30, "Offset mismatch for UCurieElementInteractWithContainerHandler::OnInstantInteractionEffects");
static_assert(offsetof(UCurieElementInteractWithContainerHandler, OnBeginInteractionEffects) == 0x40, "Offset mismatch for UCurieElementInteractWithContainerHandler::OnBeginInteractionEffects");
static_assert(offsetof(UCurieElementInteractWithContainerHandler, OngoingInteractionEffects) == 0x50, "Offset mismatch for UCurieElementInteractWithContainerHandler::OngoingInteractionEffects");
static_assert(offsetof(UCurieElementInteractWithContainerHandler, OnEndInteractionEffects) == 0x60, "Offset mismatch for UCurieElementInteractWithContainerHandler::OnEndInteractionEffects");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCurieInterface : public UInterface
{
public:

public:
    virtual void OnCurieContainerAcquired_BP(FCurieContainerHandle& const CurieContainerHandle); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void OnCurieContainerReleased_BP(FCurieContainerHandle& const CurieContainerHandle); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void OnCurieContainerReparented_BP(FCurieContainerHandle& const CurieContainerHandle); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void OnCurieElementAttached_BP(FCurieContainerHandle& const CurieContainerHandle, FGameplayTag& const ElementTag); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void OnCurieElementDetached_BP(FCurieContainerHandle& const CurieContainerHandle, FGameplayTag& const ElementTag); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    virtual void OnCurieElementInteract_BP(FCurieContainerHandle& const CurieContainerHandle, FGameplayTag& const ElementTag, const FCurieInteractParamsHandle InteractParamsHandle); // 0x288a61c (Index: 0x5, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnCurieElementInteractBegun_BP(FCurieContainerHandle& const CurieContainerHandle, FGameplayTag& const ElementTag, const FCurieInteractParamsHandle InteractParamsHandle); // 0x288a61c (Index: 0x6, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnCurieElementInteractEnded_BP(FCurieContainerHandle& const CurieContainerHandle, FGameplayTag& const ElementTag, const FCurieInteractParamsHandle InteractParamsHandle); // 0x288a61c (Index: 0x7, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnCurieStateAttached_BP(FCurieContainerHandle& const CurieContainerHandle, FGameplayTag& const StateTag); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)
    virtual void OnCurieStateDetached_BP(FCurieContainerHandle& const CurieContainerHandle, FGameplayTag& const StateTag); // 0x288a61c (Index: 0x9, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UCurieInterface) == 0x28, "Size mismatch for UCurieInterface");

// Size: 0x648 (Inherited: 0x250, Single: 0x3f8)
class UCurieManager : public UGameStateComponent
{
public:
    UClass* CurieComponentClass; // 0xb8 (Size: 0x8, Type: ClassProperty)
    FName CurieManagerRegistryName; // 0xc0 (Size: 0x4, Type: NameProperty)
    FName MaterialDataRegistryName; // 0xc4 (Size: 0x4, Type: NameProperty)
    FName ElementDataRegistryName; // 0xc8 (Size: 0x4, Type: NameProperty)
    FName EntityStateDataRegistryName; // 0xcc (Size: 0x4, Type: NameProperty)
    uint8_t Pad_d0[0x298]; // 0xd0 (Size: 0x298, Type: PaddingProperty)
    TMap<UCurieElementAllocationHandler*, FGameplayTag> ElementAllocationHandlers; // 0x368 (Size: 0x50, Type: MapProperty)
    TMap<FCurieElementAttachHandlersContainer, FGameplayTag> ElementAttachmentHandlers; // 0x3b8 (Size: 0x50, Type: MapProperty)
    TMap<FCurieElementAttachConditionHandlersContainer, FGameplayTag> ElementAttachmentConditionHandlers; // 0x408 (Size: 0x50, Type: MapProperty)
    TMap<FCurieElementInteractWithElementHandlersContainer, FCurieElementPairKey> ElementInteractWithElementHandlers; // 0x458 (Size: 0x50, Type: MapProperty)
    TMap<FCurieElementInteractWithMaterialHandlersContainer, FGameplayTag> ElementInteractWithMaterialHandlers; // 0x4a8 (Size: 0x50, Type: MapProperty)
    TMap<FCurieElementInteractWithContainerHandlersContainer, FGameplayTag> ElementInteractWithContainerHandlers; // 0x4f8 (Size: 0x50, Type: MapProperty)
    TArray<UCurieManagerComponent*> CurieManagerComponents; // 0x548 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_558[0xf0]; // 0x558 (Size: 0xf0, Type: PaddingProperty)

public:
    void BindDelegateForCurieElementAttached(UObject*& CurieOwner, const FDelegate Delegate); // 0xb886f3c (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void BindDelegateForCurieElementBeginInteract(UObject*& CurieOwner, const FDelegate Delegate); // 0xb887124 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void BindDelegateForCurieElementDetached(UObject*& CurieOwner, const FDelegate Delegate); // 0xb887658 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void BindDelegateForCurieElementEndInteract(UObject*& CurieOwner, const FDelegate Delegate); // 0xb887840 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void BindDelegateForCurieElementInteract(UObject*& CurieOwner, const FDelegate Delegate); // 0xb887d74 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void BindDelegateForCurieStateAttached(UObject*& CurieOwner, const FDelegate Delegate); // 0xb8882a8 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void BindDelegateForCurieStateDetached(UObject*& CurieOwner, const FDelegate Delegate); // 0xb888490 (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UnbindDelegateForCurieElementAttached(UObject*& CurieOwner, const FDelegate Delegate); // 0xb888678 (Index: 0x8, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UnbindDelegateForCurieElementBeginInteract(UObject*& CurieOwner, const FDelegate Delegate); // 0xb888860 (Index: 0x9, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UnbindDelegateForCurieElementDetached(UObject*& CurieOwner, const FDelegate Delegate); // 0xb8890f4 (Index: 0xa, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UnbindDelegateForCurieElementEndInteract(UObject*& CurieOwner, const FDelegate Delegate); // 0xb8892dc (Index: 0xb, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UnbindDelegateForCurieElementInteract(UObject*& CurieOwner, const FDelegate Delegate); // 0xb889b70 (Index: 0xc, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UnbindDelegateForCurieStateAttached(UObject*& CurieOwner, const FDelegate Delegate); // 0xb88a404 (Index: 0xd, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UnbindDelegateForCurieStateDetached(UObject*& CurieOwner, const FDelegate Delegate); // 0xb88a5ec (Index: 0xe, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

private:
    void HandleContainerOwnerDestroyed(AActor*& OwnerActor); // 0xa43f24c (Index: 0x7, Flags: Final|Native|Private)
};

static_assert(sizeof(UCurieManager) == 0x648, "Size mismatch for UCurieManager");
static_assert(offsetof(UCurieManager, CurieComponentClass) == 0xb8, "Offset mismatch for UCurieManager::CurieComponentClass");
static_assert(offsetof(UCurieManager, CurieManagerRegistryName) == 0xc0, "Offset mismatch for UCurieManager::CurieManagerRegistryName");
static_assert(offsetof(UCurieManager, MaterialDataRegistryName) == 0xc4, "Offset mismatch for UCurieManager::MaterialDataRegistryName");
static_assert(offsetof(UCurieManager, ElementDataRegistryName) == 0xc8, "Offset mismatch for UCurieManager::ElementDataRegistryName");
static_assert(offsetof(UCurieManager, EntityStateDataRegistryName) == 0xcc, "Offset mismatch for UCurieManager::EntityStateDataRegistryName");
static_assert(offsetof(UCurieManager, ElementAllocationHandlers) == 0x368, "Offset mismatch for UCurieManager::ElementAllocationHandlers");
static_assert(offsetof(UCurieManager, ElementAttachmentHandlers) == 0x3b8, "Offset mismatch for UCurieManager::ElementAttachmentHandlers");
static_assert(offsetof(UCurieManager, ElementAttachmentConditionHandlers) == 0x408, "Offset mismatch for UCurieManager::ElementAttachmentConditionHandlers");
static_assert(offsetof(UCurieManager, ElementInteractWithElementHandlers) == 0x458, "Offset mismatch for UCurieManager::ElementInteractWithElementHandlers");
static_assert(offsetof(UCurieManager, ElementInteractWithMaterialHandlers) == 0x4a8, "Offset mismatch for UCurieManager::ElementInteractWithMaterialHandlers");
static_assert(offsetof(UCurieManager, ElementInteractWithContainerHandlers) == 0x4f8, "Offset mismatch for UCurieManager::ElementInteractWithContainerHandlers");
static_assert(offsetof(UCurieManager, CurieManagerComponents) == 0x548, "Offset mismatch for UCurieManager::CurieManagerComponents");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCurieManagerComponentInterface : public UInterface
{
public:
};

static_assert(sizeof(UCurieManagerComponentInterface) == 0x28, "Size mismatch for UCurieManagerComponentInterface");

// Size: 0x40 (Inherited: 0x88, Single: 0xffffffb8)
class UCurieManagerComponentConfig : public UPrimaryDataAsset
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    FName ConfigName; // 0x38 (Size: 0x4, Type: NameProperty)
    FGameplayTag ConfigTag; // 0x3c (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(UCurieManagerComponentConfig) == 0x40, "Size mismatch for UCurieManagerComponentConfig");
static_assert(offsetof(UCurieManagerComponentConfig, ConfigName) == 0x38, "Offset mismatch for UCurieManagerComponentConfig::ConfigName");
static_assert(offsetof(UCurieManagerComponentConfig, ConfigTag) == 0x3c, "Offset mismatch for UCurieManagerComponentConfig::ConfigTag");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UCurieManagerComponent : public UObject
{
public:
    UCurieManagerComponentConfig* CachedConfig; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UCurieManagerComponent) == 0x30, "Size mismatch for UCurieManagerComponent");
static_assert(offsetof(UCurieManagerComponent, CachedConfig) == 0x28, "Offset mismatch for UCurieManagerComponent::CachedConfig");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCurieContainerHandle
{
};

static_assert(sizeof(FCurieContainerHandle) == 0x4, "Size mismatch for FCurieContainerHandle");

// Size: 0x88 (Inherited: 0x8, Single: 0x80)
struct FCurieMaterialDefinitionBase : FTableRowBase
{
    FGameplayTagContainer ElementalImmunities; // 0x8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ElementAttachmentImmunities; // 0x28 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ElementsAllowedWhenCannotBeDamaged; // 0x48 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer MaterialProperties; // 0x68 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FCurieMaterialDefinitionBase) == 0x88, "Size mismatch for FCurieMaterialDefinitionBase");
static_assert(offsetof(FCurieMaterialDefinitionBase, ElementalImmunities) == 0x8, "Offset mismatch for FCurieMaterialDefinitionBase::ElementalImmunities");
static_assert(offsetof(FCurieMaterialDefinitionBase, ElementAttachmentImmunities) == 0x28, "Offset mismatch for FCurieMaterialDefinitionBase::ElementAttachmentImmunities");
static_assert(offsetof(FCurieMaterialDefinitionBase, ElementsAllowedWhenCannotBeDamaged) == 0x48, "Offset mismatch for FCurieMaterialDefinitionBase::ElementsAllowedWhenCannotBeDamaged");
static_assert(offsetof(FCurieMaterialDefinitionBase, MaterialProperties) == 0x68, "Offset mismatch for FCurieMaterialDefinitionBase::MaterialProperties");

// Size: 0x80 (Inherited: 0x8, Single: 0x78)
struct FCurieElementDefinitionBase : FTableRowBase
{
    UClass* ElementAllocationHandler; // 0x8 (Size: 0x8, Type: ClassProperty)
    TArray<UClass*> ElementAttachHandlers; // 0x10 (Size: 0x10, Type: ArrayProperty)
    UClass* ElementAttachConditionHandler; // 0x20 (Size: 0x8, Type: ClassProperty)
    TArray<UClass*> ElementInteractHandlers; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ElementMaterialInteractHandlers; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> ElementContainerInteractHandlers; // 0x48 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer ElementalImmunities; // 0x58 (Size: 0x20, Type: StructProperty)
    uint8_t bIsEnabled : 1; // 0x78:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FCurieElementDefinitionBase) == 0x80, "Size mismatch for FCurieElementDefinitionBase");
static_assert(offsetof(FCurieElementDefinitionBase, ElementAllocationHandler) == 0x8, "Offset mismatch for FCurieElementDefinitionBase::ElementAllocationHandler");
static_assert(offsetof(FCurieElementDefinitionBase, ElementAttachHandlers) == 0x10, "Offset mismatch for FCurieElementDefinitionBase::ElementAttachHandlers");
static_assert(offsetof(FCurieElementDefinitionBase, ElementAttachConditionHandler) == 0x20, "Offset mismatch for FCurieElementDefinitionBase::ElementAttachConditionHandler");
static_assert(offsetof(FCurieElementDefinitionBase, ElementInteractHandlers) == 0x28, "Offset mismatch for FCurieElementDefinitionBase::ElementInteractHandlers");
static_assert(offsetof(FCurieElementDefinitionBase, ElementMaterialInteractHandlers) == 0x38, "Offset mismatch for FCurieElementDefinitionBase::ElementMaterialInteractHandlers");
static_assert(offsetof(FCurieElementDefinitionBase, ElementContainerInteractHandlers) == 0x48, "Offset mismatch for FCurieElementDefinitionBase::ElementContainerInteractHandlers");
static_assert(offsetof(FCurieElementDefinitionBase, ElementalImmunities) == 0x58, "Offset mismatch for FCurieElementDefinitionBase::ElementalImmunities");
static_assert(offsetof(FCurieElementDefinitionBase, bIsEnabled) == 0x78, "Offset mismatch for FCurieElementDefinitionBase::bIsEnabled");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FCurieEntityStateDefinitionBase : FTableRowBase
{
    UClass* StateBehaviorClass; // 0x8 (Size: 0x8, Type: ClassProperty)
    uint8_t bIsEnabled : 1; // 0x10:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FCurieEntityStateDefinitionBase) == 0x18, "Size mismatch for FCurieEntityStateDefinitionBase");
static_assert(offsetof(FCurieEntityStateDefinitionBase, StateBehaviorClass) == 0x8, "Offset mismatch for FCurieEntityStateDefinitionBase::StateBehaviorClass");
static_assert(offsetof(FCurieEntityStateDefinitionBase, bIsEnabled) == 0x10, "Offset mismatch for FCurieEntityStateDefinitionBase::bIsEnabled");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCurieElementAttachHandlersContainer
{
    TArray<UCurieElementAttachHandler*> Handlers; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCurieElementAttachHandlersContainer) == 0x10, "Size mismatch for FCurieElementAttachHandlersContainer");
static_assert(offsetof(FCurieElementAttachHandlersContainer, Handlers) == 0x0, "Offset mismatch for FCurieElementAttachHandlersContainer::Handlers");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCurieElementAttachConditionHandlersContainer
{
    TArray<UCurieElementAttachConditionHandler*> Handlers; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCurieElementAttachConditionHandlersContainer) == 0x10, "Size mismatch for FCurieElementAttachConditionHandlersContainer");
static_assert(offsetof(FCurieElementAttachConditionHandlersContainer, Handlers) == 0x0, "Offset mismatch for FCurieElementAttachConditionHandlersContainer::Handlers");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCurieElementInteractWithElementHandlersContainer
{
    TArray<UCurieElementInteractWithElementHandler*> Handlers; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCurieElementInteractWithElementHandlersContainer) == 0x10, "Size mismatch for FCurieElementInteractWithElementHandlersContainer");
static_assert(offsetof(FCurieElementInteractWithElementHandlersContainer, Handlers) == 0x0, "Offset mismatch for FCurieElementInteractWithElementHandlersContainer::Handlers");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCurieElementInteractWithMaterialHandlersContainer
{
    TArray<UCurieElementInteractWithMaterialHandler*> Handlers; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCurieElementInteractWithMaterialHandlersContainer) == 0x10, "Size mismatch for FCurieElementInteractWithMaterialHandlersContainer");
static_assert(offsetof(FCurieElementInteractWithMaterialHandlersContainer, Handlers) == 0x0, "Offset mismatch for FCurieElementInteractWithMaterialHandlersContainer::Handlers");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCurieElementInteractWithContainerHandlersContainer
{
    TArray<UCurieElementInteractWithContainerHandler*> Handlers; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCurieElementInteractWithContainerHandlersContainer) == 0x10, "Size mismatch for FCurieElementInteractWithContainerHandlersContainer");
static_assert(offsetof(FCurieElementInteractWithContainerHandlersContainer, Handlers) == 0x0, "Offset mismatch for FCurieElementInteractWithContainerHandlersContainer::Handlers");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCurieInteractParamsHandle
{
};

static_assert(sizeof(FCurieInteractParamsHandle) == 0x10, "Size mismatch for FCurieInteractParamsHandle");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FCurieElementPairKey
{
};

static_assert(sizeof(FCurieElementPairKey) == 0x8, "Size mismatch for FCurieElementPairKey");

// Size: 0x20 (Inherited: 0x8, Single: 0x18)
struct FCurieManagerComponentEntry : FTableRowBase
{
    bool bIsActive; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Priority; // 0x9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a[0x6]; // 0xa (Size: 0x6, Type: PaddingProperty)
    UClass* ManagerType; // 0x10 (Size: 0x8, Type: ClassProperty)
    UCurieManagerComponentConfig* Config; // 0x18 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCurieManagerComponentEntry) == 0x20, "Size mismatch for FCurieManagerComponentEntry");
static_assert(offsetof(FCurieManagerComponentEntry, bIsActive) == 0x8, "Offset mismatch for FCurieManagerComponentEntry::bIsActive");
static_assert(offsetof(FCurieManagerComponentEntry, Priority) == 0x9, "Offset mismatch for FCurieManagerComponentEntry::Priority");
static_assert(offsetof(FCurieManagerComponentEntry, ManagerType) == 0x10, "Offset mismatch for FCurieManagerComponentEntry::ManagerType");
static_assert(offsetof(FCurieManagerComponentEntry, Config) == 0x18, "Offset mismatch for FCurieManagerComponentEntry::Config");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCurieInteractHandle
{
};

static_assert(sizeof(FCurieInteractHandle) == 0x4, "Size mismatch for FCurieInteractHandle");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FCurieEffectContainer
{
    FGameplayTagQuery TargetFilter; // 0x0 (Size: 0x48, Type: StructProperty)
    UClass* GameplayEffect; // 0x48 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FCurieEffectContainer) == 0x50, "Size mismatch for FCurieEffectContainer");
static_assert(offsetof(FCurieEffectContainer, TargetFilter) == 0x0, "Offset mismatch for FCurieEffectContainer::TargetFilter");
static_assert(offsetof(FCurieEffectContainer, GameplayEffect) == 0x48, "Offset mismatch for FCurieEffectContainer::GameplayEffect");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCurieStateHandle
{
};

static_assert(sizeof(FCurieStateHandle) == 0x4, "Size mismatch for FCurieStateHandle");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCurieElementHandle
{
};

static_assert(sizeof(FCurieElementHandle) == 0x4, "Size mismatch for FCurieElementHandle");

