/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CinematicCamera
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "DeveloperSettings.h"

// Size: 0x2d8 (Inherited: 0x2d0, Single: 0x8)
class ACameraRig_Crane : public AActor
{
public:
    float CranePitch; // 0x2a8 (Size: 0x4, Type: FloatProperty)
    float CraneYaw; // 0x2ac (Size: 0x4, Type: FloatProperty)
    float CraneArmLength; // 0x2b0 (Size: 0x4, Type: FloatProperty)
    bool bLockMountPitch; // 0x2b4 (Size: 0x1, Type: BoolProperty)
    bool bLockMountYaw; // 0x2b5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b6[0x2]; // 0x2b6 (Size: 0x2, Type: PaddingProperty)
    USceneComponent* TransformComponent; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* CraneYawControl; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* CranePitchControl; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* CraneCameraMount; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ACameraRig_Crane) == 0x2d8, "Size mismatch for ACameraRig_Crane");
static_assert(offsetof(ACameraRig_Crane, CranePitch) == 0x2a8, "Offset mismatch for ACameraRig_Crane::CranePitch");
static_assert(offsetof(ACameraRig_Crane, CraneYaw) == 0x2ac, "Offset mismatch for ACameraRig_Crane::CraneYaw");
static_assert(offsetof(ACameraRig_Crane, CraneArmLength) == 0x2b0, "Offset mismatch for ACameraRig_Crane::CraneArmLength");
static_assert(offsetof(ACameraRig_Crane, bLockMountPitch) == 0x2b4, "Offset mismatch for ACameraRig_Crane::bLockMountPitch");
static_assert(offsetof(ACameraRig_Crane, bLockMountYaw) == 0x2b5, "Offset mismatch for ACameraRig_Crane::bLockMountYaw");
static_assert(offsetof(ACameraRig_Crane, TransformComponent) == 0x2b8, "Offset mismatch for ACameraRig_Crane::TransformComponent");
static_assert(offsetof(ACameraRig_Crane, CraneYawControl) == 0x2c0, "Offset mismatch for ACameraRig_Crane::CraneYawControl");
static_assert(offsetof(ACameraRig_Crane, CranePitchControl) == 0x2c8, "Offset mismatch for ACameraRig_Crane::CranePitchControl");
static_assert(offsetof(ACameraRig_Crane, CraneCameraMount) == 0x2d0, "Offset mismatch for ACameraRig_Crane::CraneCameraMount");

// Size: 0x2c8 (Inherited: 0x2d0, Single: 0xfffffff8)
class ACameraRig_Rail : public AActor
{
public:
    float CurrentPositionOnRail; // 0x2a8 (Size: 0x4, Type: FloatProperty)
    bool bLockOrientationToRail; // 0x2ac (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2ad[0x3]; // 0x2ad (Size: 0x3, Type: PaddingProperty)
    USceneComponent* TransformComponent; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    USplineComponent* RailSplineComponent; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* RailCameraMount; // 0x2c0 (Size: 0x8, Type: ObjectProperty)

public:
    USplineComponent* GetRailSplineComponent(); // 0xa164804 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(ACameraRig_Rail) == 0x2c8, "Size mismatch for ACameraRig_Rail");
static_assert(offsetof(ACameraRig_Rail, CurrentPositionOnRail) == 0x2a8, "Offset mismatch for ACameraRig_Rail::CurrentPositionOnRail");
static_assert(offsetof(ACameraRig_Rail, bLockOrientationToRail) == 0x2ac, "Offset mismatch for ACameraRig_Rail::bLockOrientationToRail");
static_assert(offsetof(ACameraRig_Rail, TransformComponent) == 0x2b0, "Offset mismatch for ACameraRig_Rail::TransformComponent");
static_assert(offsetof(ACameraRig_Rail, RailSplineComponent) == 0x2b8, "Offset mismatch for ACameraRig_Rail::RailSplineComponent");
static_assert(offsetof(ACameraRig_Rail, RailCameraMount) == 0x2c0, "Offset mismatch for ACameraRig_Rail::RailCameraMount");

// Size: 0xaa0 (Inherited: 0xd00, Single: 0xfffffda0)
class ACineCameraActor : public ACameraActor
{
public:
    FCameraLookatTrackingSettings LookatTrackingSettings; // 0xa30 (Size: 0x60, Type: StructProperty)
    uint8_t Pad_a90[0x10]; // 0xa90 (Size: 0x10, Type: PaddingProperty)

public:
    UCineCameraComponent* GetCineCameraComponent() const; // 0xa1638ec (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(ACineCameraActor) == 0xaa0, "Size mismatch for ACineCameraActor");
static_assert(offsetof(ACineCameraActor, LookatTrackingSettings) == 0xa30, "Offset mismatch for ACineCameraActor::LookatTrackingSettings");

// Size: 0xba0 (Inherited: 0xda0, Single: 0xfffffe00)
class UCineCameraComponent : public UCameraComponent
{
public:
    FCameraFilmbackSettings FilmbackSettings; // 0xa80 (Size: 0x14, Type: StructProperty)
    FCameraFilmbackSettings Filmback; // 0xa94 (Size: 0x14, Type: StructProperty)
    FCameraLensSettings LensSettings; // 0xaa8 (Size: 0x1c, Type: StructProperty)
    uint8_t Pad_ac4[0x4]; // 0xac4 (Size: 0x4, Type: PaddingProperty)
    FCameraFocusSettings FocusSettings; // 0xac8 (Size: 0x58, Type: StructProperty)
    FPlateCropSettings CropSettings; // 0xb20 (Size: 0x4, Type: StructProperty)
    float CurrentFocalLength; // 0xb24 (Size: 0x4, Type: FloatProperty)
    float CurrentAperture; // 0xb28 (Size: 0x4, Type: FloatProperty)
    float CurrentFocusDistance; // 0xb2c (Size: 0x4, Type: FloatProperty)
    uint8_t bOverride_CustomNearClippingPlane : 1; // 0xb30:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b31[0x3]; // 0xb31 (Size: 0x3, Type: PaddingProperty)
    float CustomNearClippingPlane; // 0xb34 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_b38[0x8]; // 0xb38 (Size: 0x8, Type: PaddingProperty)
    TArray<FNamedFilmbackPreset> FilmbackPresets; // 0xb40 (Size: 0x10, Type: ArrayProperty)
    TArray<FNamedLensPreset> LensPresets; // 0xb50 (Size: 0x10, Type: ArrayProperty)
    FString DefaultFilmbackPresetName; // 0xb60 (Size: 0x10, Type: StrProperty)
    FString DefaultFilmbackPreset; // 0xb70 (Size: 0x10, Type: StrProperty)
    FString DefaultLensPresetName; // 0xb80 (Size: 0x10, Type: StrProperty)
    float DefaultLensFocalLength; // 0xb90 (Size: 0x4, Type: FloatProperty)
    float DefaultLensFStop; // 0xb94 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_b98[0x8]; // 0xb98 (Size: 0x8, Type: PaddingProperty)

public:
    FString GetCropPresetName() const; // 0xa163cc0 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetDefaultFilmbackPresetName() const; // 0xa163d94 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetFilmbackPresetName() const; // 0xa16419c (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static TArray<FNamedFilmbackPreset> GetFilmbackPresetsCopy(); // 0xa164278 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    float GetHorizontalFieldOfView() const; // 0xa164308 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetHorizontalProjectionOffset() const; // 0xa164330 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetLensPresetName() const; // 0xa1646f8 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static TArray<FNamedLensPreset> GetLensPresetsCopy(); // 0xa164774 (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)
    float GetVerticalFieldOfView() const; // 0xa16481c (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetVerticalProjectionOffset() const; // 0xa164844 (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetCropPresetByName(FString& InPresetName); // 0xa164864 (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetCropSettings(const FPlateCropSettings NewCropSettings); // 0xa164c3c (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetCurrentAperture(float& const NewCurrentAperture); // 0xa164d18 (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetCurrentFocalLength(float& InFocalLength); // 0xa164e4c (Index: 0xd, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetCustomNearClippingPlane(float& const NewCustomNearClippingPlane); // 0xa164f80 (Index: 0xe, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetFilmback(const FCameraFilmbackSettings NewFilmback); // 0xa165d6c (Index: 0xf, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetFilmbackPresetByName(FString& InPresetName); // 0xa165e5c (Index: 0x10, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetFocusSettings(const FCameraFocusSettings NewFocusSettings); // 0xa166278 (Index: 0x11, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetLensPresetByName(FString& InPresetName); // 0xa166514 (Index: 0x12, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetLensSettings(const FCameraLensSettings NewLensSettings); // 0xa166928 (Index: 0x13, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UCineCameraComponent) == 0xba0, "Size mismatch for UCineCameraComponent");
static_assert(offsetof(UCineCameraComponent, FilmbackSettings) == 0xa80, "Offset mismatch for UCineCameraComponent::FilmbackSettings");
static_assert(offsetof(UCineCameraComponent, Filmback) == 0xa94, "Offset mismatch for UCineCameraComponent::Filmback");
static_assert(offsetof(UCineCameraComponent, LensSettings) == 0xaa8, "Offset mismatch for UCineCameraComponent::LensSettings");
static_assert(offsetof(UCineCameraComponent, FocusSettings) == 0xac8, "Offset mismatch for UCineCameraComponent::FocusSettings");
static_assert(offsetof(UCineCameraComponent, CropSettings) == 0xb20, "Offset mismatch for UCineCameraComponent::CropSettings");
static_assert(offsetof(UCineCameraComponent, CurrentFocalLength) == 0xb24, "Offset mismatch for UCineCameraComponent::CurrentFocalLength");
static_assert(offsetof(UCineCameraComponent, CurrentAperture) == 0xb28, "Offset mismatch for UCineCameraComponent::CurrentAperture");
static_assert(offsetof(UCineCameraComponent, CurrentFocusDistance) == 0xb2c, "Offset mismatch for UCineCameraComponent::CurrentFocusDistance");
static_assert(offsetof(UCineCameraComponent, bOverride_CustomNearClippingPlane) == 0xb30, "Offset mismatch for UCineCameraComponent::bOverride_CustomNearClippingPlane");
static_assert(offsetof(UCineCameraComponent, CustomNearClippingPlane) == 0xb34, "Offset mismatch for UCineCameraComponent::CustomNearClippingPlane");
static_assert(offsetof(UCineCameraComponent, FilmbackPresets) == 0xb40, "Offset mismatch for UCineCameraComponent::FilmbackPresets");
static_assert(offsetof(UCineCameraComponent, LensPresets) == 0xb50, "Offset mismatch for UCineCameraComponent::LensPresets");
static_assert(offsetof(UCineCameraComponent, DefaultFilmbackPresetName) == 0xb60, "Offset mismatch for UCineCameraComponent::DefaultFilmbackPresetName");
static_assert(offsetof(UCineCameraComponent, DefaultFilmbackPreset) == 0xb70, "Offset mismatch for UCineCameraComponent::DefaultFilmbackPreset");
static_assert(offsetof(UCineCameraComponent, DefaultLensPresetName) == 0xb80, "Offset mismatch for UCineCameraComponent::DefaultLensPresetName");
static_assert(offsetof(UCineCameraComponent, DefaultLensFocalLength) == 0xb90, "Offset mismatch for UCineCameraComponent::DefaultLensFocalLength");
static_assert(offsetof(UCineCameraComponent, DefaultLensFStop) == 0xb94, "Offset mismatch for UCineCameraComponent::DefaultLensFStop");

// Size: 0xa8 (Inherited: 0x58, Single: 0x50)
class UCineCameraSettings : public UDeveloperSettings
{
public:
    FString DefaultLensPresetName; // 0x30 (Size: 0x10, Type: StrProperty)
    float DefaultLensFocalLength; // 0x40 (Size: 0x4, Type: FloatProperty)
    float DefaultLensFStop; // 0x44 (Size: 0x4, Type: FloatProperty)
    TArray<FNamedLensPreset> LensPresets; // 0x48 (Size: 0x10, Type: ArrayProperty)
    FString DefaultFilmbackPreset; // 0x58 (Size: 0x10, Type: StrProperty)
    TArray<FNamedFilmbackPreset> FilmbackPresets; // 0x68 (Size: 0x10, Type: ArrayProperty)
    FString DefaultCropPresetName; // 0x78 (Size: 0x10, Type: StrProperty)
    TArray<FNamedPlateCropPreset> CropPresets; // 0x88 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_98[0x10]; // 0x98 (Size: 0x10, Type: PaddingProperty)

public:
    bool GetCropPresetByName(FString& const PresetName, FPlateCropSettings& CropSettings); // 0xa163934 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    bool GetFilmbackPresetByName(FString& const PresetName, FCameraFilmbackSettings& FilmbackSettings); // 0xa163df8 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    bool GetLensPresetByName(FString& const PresetName, FCameraLensSettings& LensSettings); // 0xa164350 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)

private:
    static UCineCameraSettings* GetCineCameraSettings(); // 0xa163904 (Index: 0x0, Flags: Final|Native|Static|Private|BlueprintCallable)
    TArray<FString> GetCropPresetNames() const; // 0xa163d58 (Index: 0x2, Flags: Final|Native|Private|Const)
    TArray<FString> GetFilmbackPresetNames() const; // 0xa16423c (Index: 0x4, Flags: Final|Native|Private|Const)
    TArray<FString> GetLensPresetNames() const; // 0xa164738 (Index: 0x6, Flags: Final|Native|Private|Const)
    void SetCropPresets(const TArray<FNamedPlateCropPreset> InCropPresets); // 0xa164b60 (Index: 0x7, Flags: Final|Native|Private|HasOutParms|BlueprintCallable)
    void SetDefaultCropPresetName(FString& const InDefaultCropPresetName); // 0xa1650ac (Index: 0x8, Flags: Final|Native|Private|BlueprintCallable)
    void SetDefaultFilmbackPreset(FString& const InDefaultFilmbackPreset); // 0xa165414 (Index: 0x9, Flags: Final|Native|Private|BlueprintCallable)
    void SetDefaultLensFocalLength(float& const InDefaultLensFocalLength); // 0xa1658c0 (Index: 0xa, Flags: Final|Native|Private|BlueprintCallable)
    void SetDefaultLensFStop(float& const InDefaultLensFStop); // 0xa16577c (Index: 0xb, Flags: Final|Native|Private|BlueprintCallable)
    void SetDefaultLensPresetName(FString& const InDefaultLensPresetName); // 0xa165a04 (Index: 0xc, Flags: Final|Native|Private|BlueprintCallable)
    void SetFilmbackPresets(const TArray<FNamedFilmbackPreset> InFilmbackPresets); // 0xa166150 (Index: 0xd, Flags: Final|Native|Private|HasOutParms|BlueprintCallable)
    void SetLensPresets(const TArray<FNamedLensPreset> InLensPresets); // 0xa166808 (Index: 0xe, Flags: Final|Native|Private|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UCineCameraSettings) == 0xa8, "Size mismatch for UCineCameraSettings");
static_assert(offsetof(UCineCameraSettings, DefaultLensPresetName) == 0x30, "Offset mismatch for UCineCameraSettings::DefaultLensPresetName");
static_assert(offsetof(UCineCameraSettings, DefaultLensFocalLength) == 0x40, "Offset mismatch for UCineCameraSettings::DefaultLensFocalLength");
static_assert(offsetof(UCineCameraSettings, DefaultLensFStop) == 0x44, "Offset mismatch for UCineCameraSettings::DefaultLensFStop");
static_assert(offsetof(UCineCameraSettings, LensPresets) == 0x48, "Offset mismatch for UCineCameraSettings::LensPresets");
static_assert(offsetof(UCineCameraSettings, DefaultFilmbackPreset) == 0x58, "Offset mismatch for UCineCameraSettings::DefaultFilmbackPreset");
static_assert(offsetof(UCineCameraSettings, FilmbackPresets) == 0x68, "Offset mismatch for UCineCameraSettings::FilmbackPresets");
static_assert(offsetof(UCineCameraSettings, DefaultCropPresetName) == 0x78, "Offset mismatch for UCineCameraSettings::DefaultCropPresetName");
static_assert(offsetof(UCineCameraSettings, CropPresets) == 0x88, "Offset mismatch for UCineCameraSettings::CropPresets");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FCameraFocusSettings
{
    uint8_t FocusMethod; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float ManualFocusDistance; // 0x4 (Size: 0x4, Type: FloatProperty)
    FCameraTrackingFocusSettings TrackingFocusSettings; // 0x8 (Size: 0x40, Type: StructProperty)
    uint8_t bSmoothFocusChanges : 1; // 0x48:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x3]; // 0x49 (Size: 0x3, Type: PaddingProperty)
    float FocusSmoothingInterpSpeed; // 0x4c (Size: 0x4, Type: FloatProperty)
    float FocusOffset; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCameraFocusSettings) == 0x58, "Size mismatch for FCameraFocusSettings");
static_assert(offsetof(FCameraFocusSettings, FocusMethod) == 0x0, "Offset mismatch for FCameraFocusSettings::FocusMethod");
static_assert(offsetof(FCameraFocusSettings, ManualFocusDistance) == 0x4, "Offset mismatch for FCameraFocusSettings::ManualFocusDistance");
static_assert(offsetof(FCameraFocusSettings, TrackingFocusSettings) == 0x8, "Offset mismatch for FCameraFocusSettings::TrackingFocusSettings");
static_assert(offsetof(FCameraFocusSettings, bSmoothFocusChanges) == 0x48, "Offset mismatch for FCameraFocusSettings::bSmoothFocusChanges");
static_assert(offsetof(FCameraFocusSettings, FocusSmoothingInterpSpeed) == 0x4c, "Offset mismatch for FCameraFocusSettings::FocusSmoothingInterpSpeed");
static_assert(offsetof(FCameraFocusSettings, FocusOffset) == 0x50, "Offset mismatch for FCameraFocusSettings::FocusOffset");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FCameraTrackingFocusSettings
{
    TSoftObjectPtr<AActor*> ActorToTrack; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FVector RelativeOffset; // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t bDrawDebugTrackingFocusPoint : 1; // 0x38:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FCameraTrackingFocusSettings) == 0x40, "Size mismatch for FCameraTrackingFocusSettings");
static_assert(offsetof(FCameraTrackingFocusSettings, ActorToTrack) == 0x0, "Offset mismatch for FCameraTrackingFocusSettings::ActorToTrack");
static_assert(offsetof(FCameraTrackingFocusSettings, RelativeOffset) == 0x20, "Offset mismatch for FCameraTrackingFocusSettings::RelativeOffset");
static_assert(offsetof(FCameraTrackingFocusSettings, bDrawDebugTrackingFocusPoint) == 0x38, "Offset mismatch for FCameraTrackingFocusSettings::bDrawDebugTrackingFocusPoint");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FCameraLensSettings
{
    float MinFocalLength; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxFocalLength; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinFStop; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxFStop; // 0xc (Size: 0x4, Type: FloatProperty)
    float MinimumFocusDistance; // 0x10 (Size: 0x4, Type: FloatProperty)
    float SqueezeFactor; // 0x14 (Size: 0x4, Type: FloatProperty)
    int32_t DiaphragmBladeCount; // 0x18 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FCameraLensSettings) == 0x1c, "Size mismatch for FCameraLensSettings");
static_assert(offsetof(FCameraLensSettings, MinFocalLength) == 0x0, "Offset mismatch for FCameraLensSettings::MinFocalLength");
static_assert(offsetof(FCameraLensSettings, MaxFocalLength) == 0x4, "Offset mismatch for FCameraLensSettings::MaxFocalLength");
static_assert(offsetof(FCameraLensSettings, MinFStop) == 0x8, "Offset mismatch for FCameraLensSettings::MinFStop");
static_assert(offsetof(FCameraLensSettings, MaxFStop) == 0xc, "Offset mismatch for FCameraLensSettings::MaxFStop");
static_assert(offsetof(FCameraLensSettings, MinimumFocusDistance) == 0x10, "Offset mismatch for FCameraLensSettings::MinimumFocusDistance");
static_assert(offsetof(FCameraLensSettings, SqueezeFactor) == 0x14, "Offset mismatch for FCameraLensSettings::SqueezeFactor");
static_assert(offsetof(FCameraLensSettings, DiaphragmBladeCount) == 0x18, "Offset mismatch for FCameraLensSettings::DiaphragmBladeCount");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FCameraFilmbackSettings
{
    float SensorWidth; // 0x0 (Size: 0x4, Type: FloatProperty)
    float SensorHeight; // 0x4 (Size: 0x4, Type: FloatProperty)
    float SensorHorizontalOffset; // 0x8 (Size: 0x4, Type: FloatProperty)
    float SensorVerticalOffset; // 0xc (Size: 0x4, Type: FloatProperty)
    float SensorAspectRatio; // 0x10 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FCameraFilmbackSettings) == 0x14, "Size mismatch for FCameraFilmbackSettings");
static_assert(offsetof(FCameraFilmbackSettings, SensorWidth) == 0x0, "Offset mismatch for FCameraFilmbackSettings::SensorWidth");
static_assert(offsetof(FCameraFilmbackSettings, SensorHeight) == 0x4, "Offset mismatch for FCameraFilmbackSettings::SensorHeight");
static_assert(offsetof(FCameraFilmbackSettings, SensorHorizontalOffset) == 0x8, "Offset mismatch for FCameraFilmbackSettings::SensorHorizontalOffset");
static_assert(offsetof(FCameraFilmbackSettings, SensorVerticalOffset) == 0xc, "Offset mismatch for FCameraFilmbackSettings::SensorVerticalOffset");
static_assert(offsetof(FCameraFilmbackSettings, SensorAspectRatio) == 0x10, "Offset mismatch for FCameraFilmbackSettings::SensorAspectRatio");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FCameraLookatTrackingSettings
{
    uint8_t bEnableLookAtTracking : 1; // 0x0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bDrawDebugLookAtTrackingPosition : 1; // 0x0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float LookAtTrackingInterpSpeed; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_8[0x18]; // 0x8 (Size: 0x18, Type: PaddingProperty)
    TSoftObjectPtr<AActor*> ActorToTrack; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    FVector RelativeOffset; // 0x40 (Size: 0x18, Type: StructProperty)
    uint8_t bAllowRoll : 1; // 0x58:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FCameraLookatTrackingSettings) == 0x60, "Size mismatch for FCameraLookatTrackingSettings");
static_assert(offsetof(FCameraLookatTrackingSettings, bEnableLookAtTracking) == 0x0, "Offset mismatch for FCameraLookatTrackingSettings::bEnableLookAtTracking");
static_assert(offsetof(FCameraLookatTrackingSettings, bDrawDebugLookAtTrackingPosition) == 0x0, "Offset mismatch for FCameraLookatTrackingSettings::bDrawDebugLookAtTrackingPosition");
static_assert(offsetof(FCameraLookatTrackingSettings, LookAtTrackingInterpSpeed) == 0x4, "Offset mismatch for FCameraLookatTrackingSettings::LookAtTrackingInterpSpeed");
static_assert(offsetof(FCameraLookatTrackingSettings, ActorToTrack) == 0x20, "Offset mismatch for FCameraLookatTrackingSettings::ActorToTrack");
static_assert(offsetof(FCameraLookatTrackingSettings, RelativeOffset) == 0x40, "Offset mismatch for FCameraLookatTrackingSettings::RelativeOffset");
static_assert(offsetof(FCameraLookatTrackingSettings, bAllowRoll) == 0x58, "Offset mismatch for FCameraLookatTrackingSettings::bAllowRoll");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FNamedFilmbackPreset
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FText DisplayName; // 0x10 (Size: 0x10, Type: TextProperty)
    FCameraFilmbackSettings FilmbackSettings; // 0x20 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FNamedFilmbackPreset) == 0x38, "Size mismatch for FNamedFilmbackPreset");
static_assert(offsetof(FNamedFilmbackPreset, Name) == 0x0, "Offset mismatch for FNamedFilmbackPreset::Name");
static_assert(offsetof(FNamedFilmbackPreset, DisplayName) == 0x10, "Offset mismatch for FNamedFilmbackPreset::DisplayName");
static_assert(offsetof(FNamedFilmbackPreset, FilmbackSettings) == 0x20, "Offset mismatch for FNamedFilmbackPreset::FilmbackSettings");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FNamedLensPreset
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FCameraLensSettings LensSettings; // 0x10 (Size: 0x1c, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FNamedLensPreset) == 0x30, "Size mismatch for FNamedLensPreset");
static_assert(offsetof(FNamedLensPreset, Name) == 0x0, "Offset mismatch for FNamedLensPreset::Name");
static_assert(offsetof(FNamedLensPreset, LensSettings) == 0x10, "Offset mismatch for FNamedLensPreset::LensSettings");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FPlateCropSettings
{
    float AspectRatio; // 0x0 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FPlateCropSettings) == 0x4, "Size mismatch for FPlateCropSettings");
static_assert(offsetof(FPlateCropSettings, AspectRatio) == 0x0, "Offset mismatch for FPlateCropSettings::AspectRatio");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FNamedPlateCropPreset
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FPlateCropSettings CropSettings; // 0x10 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FNamedPlateCropPreset) == 0x18, "Size mismatch for FNamedPlateCropPreset");
static_assert(offsetof(FNamedPlateCropPreset, Name) == 0x0, "Offset mismatch for FNamedPlateCropPreset::Name");
static_assert(offsetof(FNamedPlateCropPreset, CropSettings) == 0x10, "Offset mismatch for FNamedPlateCropPreset::CropSettings");

