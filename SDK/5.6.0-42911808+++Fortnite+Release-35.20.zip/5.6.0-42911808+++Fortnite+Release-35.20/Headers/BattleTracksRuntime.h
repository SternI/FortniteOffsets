/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BattleTracksRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "Engine.h"
#include "FortniteMusic.h"
#include "SparksCoreCosmeticsRuntime.h"
#include "GameplayTags.h"

// Size: 0xe8 (Inherited: 0x310, Single: 0xfffffdd8)
class UBattleTracksPlayerComponent : public UFortControllerComponent
{
public:
    AFortPlayerController* PlayerController; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* PlayerPawn; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    USparksCosmeticComponent* SparksCosmeticComponent; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d8[0x10]; // 0xd8 (Size: 0x10, Type: PaddingProperty)

protected:
    virtual void BP_HandlePlayerPlaceChanged(int32_t& Placement); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_HandlePossessedPawnChanged(APawn*& OldPawn, APawn*& NewPawn); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_HandleSparksLoadoutFilled(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    void HandlePlayerPlaceChanged(); // 0x1123f844 (Index: 0x3, Flags: Final|Native|Protected)
    void HandlePlaySongEvent(const FFortBattleTracksPlaySongEvent Event); // 0x1123f558 (Index: 0x4, Flags: Final|Native|Protected|HasOutParms)
    void HandlePossessedPawnChanged(APawn*& OldPawn, APawn*& NewPawn); // 0x1123f858 (Index: 0x5, Flags: Final|Native|Protected)
    void HandlePrepareSongEvent(const FFortBattleTracksPrepareSongEvent Event); // 0x1123fa60 (Index: 0x6, Flags: Final|Native|Protected|HasOutParms)
    void HandleSparksLoadoutFilled(); // 0x1123fd4c (Index: 0x7, Flags: Final|Native|Protected)
    void PlayEquippedJamTrack(int32_t& Index, FFortMusicPlayerParams& PlayerParams); // 0x1123fd60 (Index: 0x8, Flags: Final|Native|Protected|BlueprintCallable)
    void PlayMomentTrack(const FGameplayTag MomentTag, FFortMusicPlayerParams& PlayerParams); // 0x1123ff34 (Index: 0x9, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    void PrepareEquippedJamTrack(int32_t& Index, FFortMusicPlayerParams& PlayerParams); // 0x112400c4 (Index: 0xa, Flags: Final|Native|Protected|BlueprintCallable)
    void PrepareMomentTrack(const FGameplayTag MomentTag, FFortMusicPlayerParams& PlayerParams); // 0x11240298 (Index: 0xb, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    void PrepareSong(TScriptInterface<Class>& Song, FFortMusicPlayerParams& PlayerParams); // 0x11240428 (Index: 0xc, Flags: Final|Native|Protected|BlueprintCallable)
    void StopSong(float& FadeOutTime); // 0x112407b0 (Index: 0xd, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UBattleTracksPlayerComponent) == 0xe8, "Size mismatch for UBattleTracksPlayerComponent");
static_assert(offsetof(UBattleTracksPlayerComponent, PlayerController) == 0xc0, "Offset mismatch for UBattleTracksPlayerComponent::PlayerController");
static_assert(offsetof(UBattleTracksPlayerComponent, PlayerPawn) == 0xc8, "Offset mismatch for UBattleTracksPlayerComponent::PlayerPawn");
static_assert(offsetof(UBattleTracksPlayerComponent, SparksCosmeticComponent) == 0xd0, "Offset mismatch for UBattleTracksPlayerComponent::SparksCosmeticComponent");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FFortBattleTracksPlaySongEvent
{
    TScriptInterface<Class> Song; // 0x8 (Size: 0x10, Type: InterfaceProperty)
    int32_t JamTrackIndex; // 0x18 (Size: 0x4, Type: IntProperty)
    FGameplayTag MomentTag; // 0x1c (Size: 0x4, Type: StructProperty)
    FGameplayTag MusicEventTag; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer MusicEventBehaviorTags; // 0x28 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FFortBattleTracksPlaySongEvent) == 0x48, "Size mismatch for FFortBattleTracksPlaySongEvent");
static_assert(offsetof(FFortBattleTracksPlaySongEvent, Song) == 0x8, "Offset mismatch for FFortBattleTracksPlaySongEvent::Song");
static_assert(offsetof(FFortBattleTracksPlaySongEvent, JamTrackIndex) == 0x18, "Offset mismatch for FFortBattleTracksPlaySongEvent::JamTrackIndex");
static_assert(offsetof(FFortBattleTracksPlaySongEvent, MomentTag) == 0x1c, "Offset mismatch for FFortBattleTracksPlaySongEvent::MomentTag");
static_assert(offsetof(FFortBattleTracksPlaySongEvent, MusicEventTag) == 0x20, "Offset mismatch for FFortBattleTracksPlaySongEvent::MusicEventTag");
static_assert(offsetof(FFortBattleTracksPlaySongEvent, MusicEventBehaviorTags) == 0x28, "Offset mismatch for FFortBattleTracksPlaySongEvent::MusicEventBehaviorTags");

// Size: 0x48 (Inherited: 0x48, Single: 0x0)
struct FFortBattleTracksPrepareSongEvent : FFortBattleTracksPlaySongEvent
{
};

static_assert(sizeof(FFortBattleTracksPrepareSongEvent) == 0x48, "Size mismatch for FFortBattleTracksPrepareSongEvent");

