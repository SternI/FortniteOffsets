/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataRegistry
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "DeveloperSettings.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"

// Size: 0x48 (Inherited: 0x58, Single: 0xfffffff0)
class UDataRegistrySettings : public UDeveloperSettings
{
public:
    TArray<FDirectoryPath> DirectoriesToScan; // 0x30 (Size: 0x10, Type: ArrayProperty)
    bool bInitializeAllLoadedRegistries; // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreMissingCookedAssetRegistryData; // 0x41 (Size: 0x1, Type: BoolProperty)
    bool bDelayLoadingDataRegistriesUntilPIE; // 0x42 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_43[0x5]; // 0x43 (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(UDataRegistrySettings) == 0x48, "Size mismatch for UDataRegistrySettings");
static_assert(offsetof(UDataRegistrySettings, DirectoriesToScan) == 0x30, "Offset mismatch for UDataRegistrySettings::DirectoriesToScan");
static_assert(offsetof(UDataRegistrySettings, bInitializeAllLoadedRegistries) == 0x40, "Offset mismatch for UDataRegistrySettings::bInitializeAllLoadedRegistries");
static_assert(offsetof(UDataRegistrySettings, bIgnoreMissingCookedAssetRegistryData) == 0x41, "Offset mismatch for UDataRegistrySettings::bIgnoreMissingCookedAssetRegistryData");
static_assert(offsetof(UDataRegistrySettings, bDelayLoadingDataRegistriesUntilPIE) == 0x42, "Offset mismatch for UDataRegistrySettings::bDelayLoadingDataRegistriesUntilPIE");

// Size: 0xb8 (Inherited: 0x28, Single: 0x90)
class UDataRegistry : public UObject
{
public:
    FName RegistryType; // 0x28 (Size: 0x4, Type: NameProperty)
    FDataRegistryIdFormat IdFormat; // 0x2c (Size: 0x4, Type: StructProperty)
    UScriptStruct* ItemStruct; // 0x30 (Size: 0x8, Type: ObjectProperty)
    TArray<UDataRegistrySource*> DataSources; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<UDataRegistrySource*> RuntimeSources; // 0x48 (Size: 0x10, Type: ArrayProperty)
    float TimerUpdateFrequency; // 0x58 (Size: 0x4, Type: FloatProperty)
    FDataRegistryCachePolicy DefaultCachePolicy; // 0x5c (Size: 0x14, Type: StructProperty)
    uint8_t Pad_70[0x48]; // 0x70 (Size: 0x48, Type: PaddingProperty)
};

static_assert(sizeof(UDataRegistry) == 0xb8, "Size mismatch for UDataRegistry");
static_assert(offsetof(UDataRegistry, RegistryType) == 0x28, "Offset mismatch for UDataRegistry::RegistryType");
static_assert(offsetof(UDataRegistry, IdFormat) == 0x2c, "Offset mismatch for UDataRegistry::IdFormat");
static_assert(offsetof(UDataRegistry, ItemStruct) == 0x30, "Offset mismatch for UDataRegistry::ItemStruct");
static_assert(offsetof(UDataRegistry, DataSources) == 0x38, "Offset mismatch for UDataRegistry::DataSources");
static_assert(offsetof(UDataRegistry, RuntimeSources) == 0x48, "Offset mismatch for UDataRegistry::RuntimeSources");
static_assert(offsetof(UDataRegistry, TimerUpdateFrequency) == 0x58, "Offset mismatch for UDataRegistry::TimerUpdateFrequency");
static_assert(offsetof(UDataRegistry, DefaultCachePolicy) == 0x5c, "Offset mismatch for UDataRegistry::DefaultCachePolicy");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UDataRegistrySource : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    UDataRegistrySource* ParentSource; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDataRegistrySource) == 0x38, "Size mismatch for UDataRegistrySource");
static_assert(offsetof(UDataRegistrySource, ParentSource) == 0x30, "Offset mismatch for UDataRegistrySource::ParentSource");

// Size: 0x108 (Inherited: 0x60, Single: 0xa8)
class UMetaDataRegistrySource : public UDataRegistrySource
{
public:
    uint8_t AssetUsage; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
    FAssetManagerSearchRules SearchRules; // 0x40 (Size: 0x50, Type: StructProperty)
    TMap<UDataRegistrySource*, FName> RuntimeChildren; // 0x90 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_e0[0x28]; // 0xe0 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(UMetaDataRegistrySource) == 0x108, "Size mismatch for UMetaDataRegistrySource");
static_assert(offsetof(UMetaDataRegistrySource, AssetUsage) == 0x38, "Offset mismatch for UMetaDataRegistrySource::AssetUsage");
static_assert(offsetof(UMetaDataRegistrySource, SearchRules) == 0x40, "Offset mismatch for UMetaDataRegistrySource::SearchRules");
static_assert(offsetof(UMetaDataRegistrySource, RuntimeChildren) == 0x90, "Offset mismatch for UMetaDataRegistrySource::RuntimeChildren");

// Size: 0x98 (Inherited: 0x60, Single: 0x38)
class UDataRegistrySource_CurveTable : public UDataRegistrySource
{
public:
    TSoftObjectPtr<UCurveTable*> SourceTable; // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    FDataRegistrySource_DataTableRules TableRules; // 0x58 (Size: 0x8, Type: StructProperty)
    UCurveTable* CachedTable; // 0x60 (Size: 0x8, Type: ObjectProperty)
    UCurveTable* PreloadTable; // 0x68 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_70[0x28]; // 0x70 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(UDataRegistrySource_CurveTable) == 0x98, "Size mismatch for UDataRegistrySource_CurveTable");
static_assert(offsetof(UDataRegistrySource_CurveTable, SourceTable) == 0x38, "Offset mismatch for UDataRegistrySource_CurveTable::SourceTable");
static_assert(offsetof(UDataRegistrySource_CurveTable, TableRules) == 0x58, "Offset mismatch for UDataRegistrySource_CurveTable::TableRules");
static_assert(offsetof(UDataRegistrySource_CurveTable, CachedTable) == 0x60, "Offset mismatch for UDataRegistrySource_CurveTable::CachedTable");
static_assert(offsetof(UDataRegistrySource_CurveTable, PreloadTable) == 0x68, "Offset mismatch for UDataRegistrySource_CurveTable::PreloadTable");

// Size: 0x118 (Inherited: 0x168, Single: 0xffffffb0)
class UMetaDataRegistrySource_CurveTable : public UMetaDataRegistrySource
{
public:
    UClass* CreatedSource; // 0x108 (Size: 0x8, Type: ClassProperty)
    FDataRegistrySource_DataTableRules TableRules; // 0x110 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(UMetaDataRegistrySource_CurveTable) == 0x118, "Size mismatch for UMetaDataRegistrySource_CurveTable");
static_assert(offsetof(UMetaDataRegistrySource_CurveTable, CreatedSource) == 0x108, "Offset mismatch for UMetaDataRegistrySource_CurveTable::CreatedSource");
static_assert(offsetof(UMetaDataRegistrySource_CurveTable, TableRules) == 0x110, "Offset mismatch for UMetaDataRegistrySource_CurveTable::TableRules");

// Size: 0x98 (Inherited: 0x60, Single: 0x38)
class UDataRegistrySource_DataTable : public UDataRegistrySource
{
public:
    TSoftObjectPtr<UDataTable*> SourceTable; // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    FDataRegistrySource_DataTableRules TableRules; // 0x58 (Size: 0x8, Type: StructProperty)
    UDataTable* CachedTable; // 0x60 (Size: 0x8, Type: ObjectProperty)
    UDataTable* PreloadTable; // 0x68 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_70[0x28]; // 0x70 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(UDataRegistrySource_DataTable) == 0x98, "Size mismatch for UDataRegistrySource_DataTable");
static_assert(offsetof(UDataRegistrySource_DataTable, SourceTable) == 0x38, "Offset mismatch for UDataRegistrySource_DataTable::SourceTable");
static_assert(offsetof(UDataRegistrySource_DataTable, TableRules) == 0x58, "Offset mismatch for UDataRegistrySource_DataTable::TableRules");
static_assert(offsetof(UDataRegistrySource_DataTable, CachedTable) == 0x60, "Offset mismatch for UDataRegistrySource_DataTable::CachedTable");
static_assert(offsetof(UDataRegistrySource_DataTable, PreloadTable) == 0x68, "Offset mismatch for UDataRegistrySource_DataTable::PreloadTable");

// Size: 0x118 (Inherited: 0x168, Single: 0xffffffb0)
class UMetaDataRegistrySource_DataTable : public UMetaDataRegistrySource
{
public:
    UClass* CreatedSource; // 0x108 (Size: 0x8, Type: ClassProperty)
    FDataRegistrySource_DataTableRules TableRules; // 0x110 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(UMetaDataRegistrySource_DataTable) == 0x118, "Size mismatch for UMetaDataRegistrySource_DataTable");
static_assert(offsetof(UMetaDataRegistrySource_DataTable, CreatedSource) == 0x108, "Offset mismatch for UMetaDataRegistrySource_DataTable::CreatedSource");
static_assert(offsetof(UMetaDataRegistrySource_DataTable, TableRules) == 0x110, "Offset mismatch for UMetaDataRegistrySource_DataTable::TableRules");

// Size: 0xf8 (Inherited: 0xb8, Single: 0x40)
class UDataRegistrySubsystem : public UEngineSubsystem
{
public:

public:
    static bool AcquireItemBP(FDataRegistryId& ItemId, FDelegate& AcquireCallback); // 0xae5024c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FString Conv_DataRegistryIdToString(FDataRegistryId& DataRegistryId); // 0xae503a0 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FString Conv_DataRegistryTypeToString(FDataRegistryType& DataRegistryType); // 0xa5e9790 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool EqualEqual_DataRegistryId(FDataRegistryId& A, FDataRegistryId& B); // 0xa5fbcec (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool EqualEqual_DataRegistryType(FDataRegistryType& A, FDataRegistryType& B); // 0xa5fbe2c (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void EvaluateDataRegistryCurve(FDataRegistryId& ItemId, float& InputValue, float& DefaultValue, EDataRegistrySubsystemGetItemResult& OutResult, float& OutValue); // 0xae50638 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void FindCachedItemBP(FDataRegistryId& ItemId, EDataRegistrySubsystemGetItemResult& OutResult, FTableRowBase& OutItem); // 0x596a354 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void FindCachedItemFromLookupBP(FDataRegistryId& ItemId, const FDataRegistryLookup ResolvedLookup, EDataRegistrySubsystemGetItemResult& OutResult, FTableRowBase& OutItem); // 0xae508dc (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool GetCachedItemBP(FDataRegistryId& ItemId, FTableRowBase OutItem); // 0xae50dcc (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool GetCachedItemFromLookupBP(FDataRegistryId& ItemId, const FDataRegistryLookup ResolvedLookup, FTableRowBase& OutItem); // 0xae50fd8 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetPossibleDataRegistryIdList(FDataRegistryType& RegistryType, TArray<FDataRegistryId>& OutIdList); // 0xae51464 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool IsValidDataRegistryId(FDataRegistryId& DataRegistryId); // 0xae51760 (Index: 0xb, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsValidDataRegistryType(FDataRegistryType& DataRegistryType); // 0xa616244 (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool NotEqual_DataRegistryId(FDataRegistryId& A, FDataRegistryId& B); // 0xae5182c (Index: 0xd, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool NotEqual_DataRegistryType(FDataRegistryType& A, FDataRegistryType& B); // 0xa632930 (Index: 0xe, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UDataRegistrySubsystem) == 0xf8, "Size mismatch for UDataRegistrySubsystem");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDataRegistryLookup
{
};

static_assert(sizeof(FDataRegistryLookup) == 0x18, "Size mismatch for FDataRegistryLookup");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDataRegistryId
{
    FDataRegistryType RegistryType; // 0x0 (Size: 0x4, Type: StructProperty)
    FName ItemName; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FDataRegistryId) == 0x8, "Size mismatch for FDataRegistryId");
static_assert(offsetof(FDataRegistryId, RegistryType) == 0x0, "Offset mismatch for FDataRegistryId::RegistryType");
static_assert(offsetof(FDataRegistryId, ItemName) == 0x4, "Offset mismatch for FDataRegistryId::ItemName");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FDataRegistryType
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FDataRegistryType) == 0x4, "Size mismatch for FDataRegistryType");
static_assert(offsetof(FDataRegistryType, Name) == 0x0, "Offset mismatch for FDataRegistryType::Name");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FSoftDataRegistryOrTable
{
    bool bUseDataRegistry; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TSoftObjectPtr<UDataTable*> Table; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    FDataRegistryType RegistryType; // 0x28 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FSoftDataRegistryOrTable) == 0x30, "Size mismatch for FSoftDataRegistryOrTable");
static_assert(offsetof(FSoftDataRegistryOrTable, bUseDataRegistry) == 0x0, "Offset mismatch for FSoftDataRegistryOrTable::bUseDataRegistry");
static_assert(offsetof(FSoftDataRegistryOrTable, Table) == 0x8, "Offset mismatch for FSoftDataRegistryOrTable::Table");
static_assert(offsetof(FSoftDataRegistryOrTable, RegistryType) == 0x28, "Offset mismatch for FSoftDataRegistryOrTable::RegistryType");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDataRegistrySource_DataTableRules
{
    bool bPrecacheTable; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float CachedTableKeepSeconds; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDataRegistrySource_DataTableRules) == 0x8, "Size mismatch for FDataRegistrySource_DataTableRules");
static_assert(offsetof(FDataRegistrySource_DataTableRules, bPrecacheTable) == 0x0, "Offset mismatch for FDataRegistrySource_DataTableRules::bPrecacheTable");
static_assert(offsetof(FDataRegistrySource_DataTableRules, CachedTableKeepSeconds) == 0x4, "Offset mismatch for FDataRegistrySource_DataTableRules::CachedTableKeepSeconds");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FDataRegistryIdFormat
{
    FGameplayTag BaseGameplayTag; // 0x0 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FDataRegistryIdFormat) == 0x4, "Size mismatch for FDataRegistryIdFormat");
static_assert(offsetof(FDataRegistryIdFormat, BaseGameplayTag) == 0x0, "Offset mismatch for FDataRegistryIdFormat::BaseGameplayTag");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FDataRegistryCachePolicy
{
    bool bCacheIsAlwaysVolatile; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bUseCurveTableCacheVersion; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    int32_t MinNumberKept; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t MaxNumberKept; // 0x8 (Size: 0x4, Type: IntProperty)
    float ForceKeepSeconds; // 0xc (Size: 0x4, Type: FloatProperty)
    float ForceReleaseSeconds; // 0x10 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDataRegistryCachePolicy) == 0x14, "Size mismatch for FDataRegistryCachePolicy");
static_assert(offsetof(FDataRegistryCachePolicy, bCacheIsAlwaysVolatile) == 0x0, "Offset mismatch for FDataRegistryCachePolicy::bCacheIsAlwaysVolatile");
static_assert(offsetof(FDataRegistryCachePolicy, bUseCurveTableCacheVersion) == 0x1, "Offset mismatch for FDataRegistryCachePolicy::bUseCurveTableCacheVersion");
static_assert(offsetof(FDataRegistryCachePolicy, MinNumberKept) == 0x4, "Offset mismatch for FDataRegistryCachePolicy::MinNumberKept");
static_assert(offsetof(FDataRegistryCachePolicy, MaxNumberKept) == 0x8, "Offset mismatch for FDataRegistryCachePolicy::MaxNumberKept");
static_assert(offsetof(FDataRegistryCachePolicy, ForceKeepSeconds) == 0xc, "Offset mismatch for FDataRegistryCachePolicy::ForceKeepSeconds");
static_assert(offsetof(FDataRegistryCachePolicy, ForceReleaseSeconds) == 0x10, "Offset mismatch for FDataRegistryCachePolicy::ForceReleaseSeconds");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDataRegistrySourceItemId
{
};

static_assert(sizeof(FDataRegistrySourceItemId) == 0x30, "Size mismatch for FDataRegistrySourceItemId");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDataRegistryOrTableRow
{
    bool bUseDataRegistryId; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FDataTableRowHandle DataTableRow; // 0x8 (Size: 0x10, Type: StructProperty)
    FDataRegistryId DataRegistryId; // 0x18 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FDataRegistryOrTableRow) == 0x20, "Size mismatch for FDataRegistryOrTableRow");
static_assert(offsetof(FDataRegistryOrTableRow, bUseDataRegistryId) == 0x0, "Offset mismatch for FDataRegistryOrTableRow::bUseDataRegistryId");
static_assert(offsetof(FDataRegistryOrTableRow, DataTableRow) == 0x8, "Offset mismatch for FDataRegistryOrTableRow::DataTableRow");
static_assert(offsetof(FDataRegistryOrTableRow, DataRegistryId) == 0x18, "Offset mismatch for FDataRegistryOrTableRow::DataRegistryId");

