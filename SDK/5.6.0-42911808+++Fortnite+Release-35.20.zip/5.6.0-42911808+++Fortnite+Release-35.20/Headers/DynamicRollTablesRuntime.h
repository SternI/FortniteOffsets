/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicRollTablesRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "ModularGameplay.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "DataRegistry.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"

// Size: 0x1b8 (Inherited: 0x310, Single: 0xfffffea8)
class UFortControllerComponent_DynamicRollPlayerComponent : public UFortControllerComponent
{
public:
    UClass* AssociatedManagerClass; // 0xc0 (Size: 0x8, Type: ClassProperty)
    FScalableFloat Enabled; // 0xc8 (Size: 0x28, Type: StructProperty)
    UFortGamestateComponent_DynamicRollTableManager* TableManager; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_f8[0x64]; // 0xf8 (Size: 0x64, Type: PaddingProperty)
    FRandomStream SeededRNG; // 0x15c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_164[0x54]; // 0x164 (Size: 0x54, Type: PaddingProperty)

public:
    TArray<FFortDynamicRollResult> AuthorityRollChoices(int32_t& const NumChoices, const TArray<UFortItemDefinition*> IgnoreItems); // 0x100b2eb8 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UFortControllerComponent_DynamicRollPlayerComponent) == 0x1b8, "Size mismatch for UFortControllerComponent_DynamicRollPlayerComponent");
static_assert(offsetof(UFortControllerComponent_DynamicRollPlayerComponent, AssociatedManagerClass) == 0xc0, "Offset mismatch for UFortControllerComponent_DynamicRollPlayerComponent::AssociatedManagerClass");
static_assert(offsetof(UFortControllerComponent_DynamicRollPlayerComponent, Enabled) == 0xc8, "Offset mismatch for UFortControllerComponent_DynamicRollPlayerComponent::Enabled");
static_assert(offsetof(UFortControllerComponent_DynamicRollPlayerComponent, TableManager) == 0xf0, "Offset mismatch for UFortControllerComponent_DynamicRollPlayerComponent::TableManager");
static_assert(offsetof(UFortControllerComponent_DynamicRollPlayerComponent, SeededRNG) == 0x15c, "Offset mismatch for UFortControllerComponent_DynamicRollPlayerComponent::SeededRNG");

// Size: 0x2f0 (Inherited: 0x308, Single: 0xffffffe8)
class UFortGamestateComponent_DynamicRollTableManager : public UFortGameStateComponent
{
public:
    uint8_t Pad_b8[0x30]; // 0xb8 (Size: 0x30, Type: PaddingProperty)
    FDataRegistryType DataRegistryType_BaseWeights; // 0xe8 (Size: 0x4, Type: StructProperty)
    FDataRegistryType DataRegistryType_WeightModifiers; // 0xec (Size: 0x4, Type: StructProperty)
    FScalableFloat Enabled; // 0xf0 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_118[0x1d8]; // 0x118 (Size: 0x1d8, Type: PaddingProperty)

private:
    void HandlePlaylistDataReady(AFortGameStateAthena*& GameState, UFortPlaylist*& const Playlist, const FGameplayTagContainer PlaylistContextTags); // 0x100b32c4 (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UFortGamestateComponent_DynamicRollTableManager) == 0x2f0, "Size mismatch for UFortGamestateComponent_DynamicRollTableManager");
static_assert(offsetof(UFortGamestateComponent_DynamicRollTableManager, DataRegistryType_BaseWeights) == 0xe8, "Offset mismatch for UFortGamestateComponent_DynamicRollTableManager::DataRegistryType_BaseWeights");
static_assert(offsetof(UFortGamestateComponent_DynamicRollTableManager, DataRegistryType_WeightModifiers) == 0xec, "Offset mismatch for UFortGamestateComponent_DynamicRollTableManager::DataRegistryType_WeightModifiers");
static_assert(offsetof(UFortGamestateComponent_DynamicRollTableManager, Enabled) == 0xf0, "Offset mismatch for UFortGamestateComponent_DynamicRollTableManager::Enabled");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFortDynamicRollResult
{
    UFortItemDefinition* Item; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortDynamicRollResult) == 0x8, "Size mismatch for FFortDynamicRollResult");
static_assert(offsetof(FFortDynamicRollResult, Item) == 0x0, "Offset mismatch for FFortDynamicRollResult::Item");

// Size: 0x38 (Inherited: 0x8, Single: 0x30)
struct FFortDynamicRollBaseWeightTableRow : FTableRowBase
{
    UFortItemDefinition* ItemDefinition; // 0x8 (Size: 0x8, Type: ObjectProperty)
    float BaseWeight; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    TArray<FGameplayTag> ModTags; // 0x18 (Size: 0x10, Type: ArrayProperty)
    bool bOwningItemZerosWeight; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    float MaxModifiedWeight; // 0x2c (Size: 0x4, Type: FloatProperty)
    float MinModifiedWeight; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortDynamicRollBaseWeightTableRow) == 0x38, "Size mismatch for FFortDynamicRollBaseWeightTableRow");
static_assert(offsetof(FFortDynamicRollBaseWeightTableRow, ItemDefinition) == 0x8, "Offset mismatch for FFortDynamicRollBaseWeightTableRow::ItemDefinition");
static_assert(offsetof(FFortDynamicRollBaseWeightTableRow, BaseWeight) == 0x10, "Offset mismatch for FFortDynamicRollBaseWeightTableRow::BaseWeight");
static_assert(offsetof(FFortDynamicRollBaseWeightTableRow, ModTags) == 0x18, "Offset mismatch for FFortDynamicRollBaseWeightTableRow::ModTags");
static_assert(offsetof(FFortDynamicRollBaseWeightTableRow, bOwningItemZerosWeight) == 0x28, "Offset mismatch for FFortDynamicRollBaseWeightTableRow::bOwningItemZerosWeight");
static_assert(offsetof(FFortDynamicRollBaseWeightTableRow, MaxModifiedWeight) == 0x2c, "Offset mismatch for FFortDynamicRollBaseWeightTableRow::MaxModifiedWeight");
static_assert(offsetof(FFortDynamicRollBaseWeightTableRow, MinModifiedWeight) == 0x30, "Offset mismatch for FFortDynamicRollBaseWeightTableRow::MinModifiedWeight");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FFortDynamicRollWeightModifierTableRow : FTableRowBase
{
    FGameplayTag ActivatingPlayerTag; // 0x8 (Size: 0x4, Type: StructProperty)
    FGameplayTag TargetModTag; // 0xc (Size: 0x4, Type: StructProperty)
    uint8_t WeightModifierOperation; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float WeightModificationValue; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFortDynamicRollWeightModifierTableRow) == 0x18, "Size mismatch for FFortDynamicRollWeightModifierTableRow");
static_assert(offsetof(FFortDynamicRollWeightModifierTableRow, ActivatingPlayerTag) == 0x8, "Offset mismatch for FFortDynamicRollWeightModifierTableRow::ActivatingPlayerTag");
static_assert(offsetof(FFortDynamicRollWeightModifierTableRow, TargetModTag) == 0xc, "Offset mismatch for FFortDynamicRollWeightModifierTableRow::TargetModTag");
static_assert(offsetof(FFortDynamicRollWeightModifierTableRow, WeightModifierOperation) == 0x10, "Offset mismatch for FFortDynamicRollWeightModifierTableRow::WeightModifierOperation");
static_assert(offsetof(FFortDynamicRollWeightModifierTableRow, WeightModificationValue) == 0x14, "Offset mismatch for FFortDynamicRollWeightModifierTableRow::WeightModificationValue");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDynamicRollModifiersActivatedByPlayerTagContainer
{
};

static_assert(sizeof(FDynamicRollModifiersActivatedByPlayerTagContainer) == 0x10, "Size mismatch for FDynamicRollModifiersActivatedByPlayerTagContainer");

