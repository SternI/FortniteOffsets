/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Blueprints
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "FortniteGame.h"
#include "UMG.h"
#include "ModularGameplay.h"
#include "EngineCameras.h"
#include "SlateRHIRenderer.h"
#include "AnimationBudgetAllocator.h"
#include "SlateCore.h"

// Size: 0x398 (Inherited: 0x5f8, Single: 0xfffffda0)
class ABP_VictoryDrone_C : public APawn
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x328 (Size: 0x8, Type: StructProperty)
    USkeletalMeshComponentBudgeted* SkeletalMeshComponentBudgeted; // 0x330 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* Scene; // 0x338 (Size: 0x8, Type: ObjectProperty)
    uint8_t SpawnOutAnimEndedDispatcher[0x10]; // 0x340 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    double AnimPlayRate; // 0x350 (Size: 0x8, Type: DoubleProperty)
    UMaterialInstanceDynamic* StaticMeshMID; // 0x358 (Size: 0x8, Type: ObjectProperty)
    bool TeleportIn; // 0x360 (Size: 0x1, Type: BoolProperty)
    bool IsAthena; // 0x361 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_362[0x6]; // 0x362 (Size: 0x6, Type: PaddingProperty)
    AFortPawn* TargetPlayer; // 0x368 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* CharacterAttached; // 0x370 (Size: 0x8, Type: ObjectProperty)
    bool InLobby; // 0x378 (Size: 0x1, Type: BoolProperty)
    bool IsNPC; // 0x379 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_37a[0x2]; // 0x37a (Size: 0x2, Type: PaddingProperty)
    FName AttachPoint; // 0x37c (Size: 0x4, Type: NameProperty)
    bool isDecoy; // 0x380 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_381[0x7]; // 0x381 (Size: 0x7, Type: PaddingProperty)
    USkeletalMeshComponent* Mesh_for_Attachment; // 0x388 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SoundOnNPCDeath; // 0x390 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    void PlaySpawnAnim(); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void NPC_FX_Parameters(TArray<FParticleSysParam>& Instance_Parameters); // 0x288a61c (Index: 0x4, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void NotifyTeleportFinishedTriggered(); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void InitDrone(); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Decoy_FX_Parameters(TArray<FParticleSysParam>& Instance_Parameters); // 0x288a61c (Index: 0x8, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void Added_Death_Audio(USoundBase*& Sound_to_Spawn); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SpawnOutAnimEndedDispatcher__DelegateSignature(ABP_VictoryDrone_C*& Drone); // 0x288a61c (Index: 0xa, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABP_VictoryDrone_C) == 0x398, "Size mismatch for ABP_VictoryDrone_C");
static_assert(offsetof(ABP_VictoryDrone_C, UberGraphFrame) == 0x328, "Offset mismatch for ABP_VictoryDrone_C::UberGraphFrame");
static_assert(offsetof(ABP_VictoryDrone_C, SkeletalMeshComponentBudgeted) == 0x330, "Offset mismatch for ABP_VictoryDrone_C::SkeletalMeshComponentBudgeted");
static_assert(offsetof(ABP_VictoryDrone_C, Scene) == 0x338, "Offset mismatch for ABP_VictoryDrone_C::Scene");
static_assert(offsetof(ABP_VictoryDrone_C, SpawnOutAnimEndedDispatcher) == 0x340, "Offset mismatch for ABP_VictoryDrone_C::SpawnOutAnimEndedDispatcher");
static_assert(offsetof(ABP_VictoryDrone_C, AnimPlayRate) == 0x350, "Offset mismatch for ABP_VictoryDrone_C::AnimPlayRate");
static_assert(offsetof(ABP_VictoryDrone_C, StaticMeshMID) == 0x358, "Offset mismatch for ABP_VictoryDrone_C::StaticMeshMID");
static_assert(offsetof(ABP_VictoryDrone_C, TeleportIn) == 0x360, "Offset mismatch for ABP_VictoryDrone_C::TeleportIn");
static_assert(offsetof(ABP_VictoryDrone_C, IsAthena) == 0x361, "Offset mismatch for ABP_VictoryDrone_C::IsAthena");
static_assert(offsetof(ABP_VictoryDrone_C, TargetPlayer) == 0x368, "Offset mismatch for ABP_VictoryDrone_C::TargetPlayer");
static_assert(offsetof(ABP_VictoryDrone_C, CharacterAttached) == 0x370, "Offset mismatch for ABP_VictoryDrone_C::CharacterAttached");
static_assert(offsetof(ABP_VictoryDrone_C, InLobby) == 0x378, "Offset mismatch for ABP_VictoryDrone_C::InLobby");
static_assert(offsetof(ABP_VictoryDrone_C, IsNPC) == 0x379, "Offset mismatch for ABP_VictoryDrone_C::IsNPC");
static_assert(offsetof(ABP_VictoryDrone_C, AttachPoint) == 0x37c, "Offset mismatch for ABP_VictoryDrone_C::AttachPoint");
static_assert(offsetof(ABP_VictoryDrone_C, isDecoy) == 0x380, "Offset mismatch for ABP_VictoryDrone_C::isDecoy");
static_assert(offsetof(ABP_VictoryDrone_C, Mesh_for_Attachment) == 0x388, "Offset mismatch for ABP_VictoryDrone_C::Mesh_for_Attachment");
static_assert(offsetof(ABP_VictoryDrone_C, SoundOnNPCDeath) == 0x390, "Offset mismatch for ABP_VictoryDrone_C::SoundOnNPCDeath");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UPlatformHelpersLibrary_C : public UBlueprintFunctionLibrary
{
public:

public:
    static bool isJanus(UObject*& __WorldContext); // 0x288a61c (Index: 0x0, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static bool isMithril(UObject*& __WorldContext); // 0x288a61c (Index: 0x1, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static bool isDamascus(UObject*& __WorldContext); // 0x288a61c (Index: 0x2, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static bool isPcPerfMode(UObject*& __WorldContext); // 0x288a61c (Index: 0x3, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
};

static_assert(sizeof(UPlatformHelpersLibrary_C) == 0x28, "Size mismatch for UPlatformHelpersLibrary_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class Uv3_PlayerCameraModeRanged_C : public Uv3_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(Uv3_PlayerCameraModeRanged_C) == 0x2020, "Size mismatch for Uv3_PlayerCameraModeRanged_C");

// Size: 0x2020 (Inherited: 0x20a8, Single: 0xffffff78)
class Uv3_PlayerCameraModeBase_C : public UFortCameraMode_ThirdPerson
{
public:
};

static_assert(sizeof(Uv3_PlayerCameraModeBase_C) == 0x2020, "Size mismatch for Uv3_PlayerCameraModeBase_C");

// Size: 0x2020 (Inherited: 0x60e8, Single: 0xffffbf38)
class Uv2_PlayerCameraModeTargetingVeryShortRange_C : public Uv2_PlayerCameraModeRanged_C
{
public:
};

static_assert(sizeof(Uv2_PlayerCameraModeTargetingVeryShortRange_C) == 0x2020, "Size mismatch for Uv2_PlayerCameraModeTargetingVeryShortRange_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCameraMode_WaterSprintBoost_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraMode_WaterSprintBoost_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraMode_WaterSprintBoost_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCamera_DBNO_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCamera_DBNO_C) == 0x2020, "Size mismatch for UAthena_PlayerCamera_DBNO_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class Uv2_PlayerCameraModeRanged_C : public Uv2_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(Uv2_PlayerCameraModeRanged_C) == 0x2020, "Size mismatch for Uv2_PlayerCameraModeRanged_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class Uv2_PlayerCameraModeMelee_C : public Uv2_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(Uv2_PlayerCameraModeMelee_C) == 0x2020, "Size mismatch for Uv2_PlayerCameraModeMelee_C");

// Size: 0x2020 (Inherited: 0x20a8, Single: 0xffffff78)
class Uv2_PlayerCameraModeBase_C : public UFortCameraMode_ThirdPerson
{
public:
};

static_assert(sizeof(Uv2_PlayerCameraModeBase_C) == 0x2020, "Size mismatch for Uv2_PlayerCameraModeBase_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCameraFocalPoint_C : public UFortCameraMode_FocalPoint
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraFocalPoint_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraFocalPoint_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCameraMode_HidingProp_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraMode_HidingProp_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraMode_HidingProp_C");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UUIKit_FunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:

public:
    static void IsInputType(ECommonInputType& InputType, bool& IsNot, UObject*& __WorldContext, bool& Result); // 0x288a61c (Index: 0x0, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void InstantTransitionToSelected(UMaterialInstanceDynamic*& Mid, UObject*& __WorldContext); // 0x288a61c (Index: 0x1, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void InstantTransitionToEnabled(UMaterialInstanceDynamic*& Mid, bool& IsSelected, UObject*& __WorldContext); // 0x288a61c (Index: 0x2, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void InstantTransitionToDisabled(UMaterialInstanceDynamic*& Mid, bool& IsSelected, UObject*& __WorldContext); // 0x288a61c (Index: 0x3, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void HexToColor(FString& HEX, UObject*& __WorldContext, FLinearColor& LinearColor); // 0x288a61c (Index: 0x4, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void FireEventElementInteractedByName(FString& Element_Name, UWidget*& WidgetCallingFrom, UObject*& __WorldContext, bool& Success); // 0x288a61c (Index: 0x5, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    static void Copy_MID_Parameter_Overrides(UMaterialInstanceDynamic*& Target_MID, UMaterialInstanceDynamic*& Source_MID, UObject*& __WorldContext); // 0x288a61c (Index: 0x6, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void TransitionToDeselectedIdle(UMaterialInstanceDynamic*& Mid, UObject*& __WorldContext); // 0x288a61c (Index: 0x7, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void TransitionToDeselectedFocused(UMaterialInstanceDynamic*& Mid, UObject*& __WorldContext); // 0x288a61c (Index: 0x8, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    void SetGridSlotPadding(UWidget*& Widget, FMargin& Padding, UObject*& __WorldContext); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)
    static void SetGridSlotNudge(UWidget*& Widget, FVector2D& Nudge, UObject*& __WorldContext); // 0x288a61c (Index: 0xa, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    void SetGridSlotLayer(UWidget*& Widget, int32_t& Layer, UObject*& __WorldContext); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetGridSlotColumnAndRow(UWidget*& Widget, int32_t& Row, int32_t& Row_Span, int32_t& Column, int32_t& Column_Span, UObject*& __WorldContext); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetGridSlotAlignment(UWidget*& Widget, TEnumAsByte<EHorizontalAlignment>& Horizontal, TEnumAsByte<EVerticalAlignment>& Vertical, UObject*& __WorldContext); // 0x288a61c (Index: 0xd, Flags: Public|BlueprintCallable|BlueprintEvent)
    static void RemoveWidget(UWidget*& const Widget, UObject*& __WorldContext); // 0x288a61c (Index: 0xe, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UUIKit_FunctionLibrary_C) == 0x28, "Size mismatch for UUIKit_FunctionLibrary_C");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBuildingFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:

public:
    static void SweepAgainstActorTypes(AActor*& TestActor, FVector& StartLocation, FVector& EndLocation, double& SweepRadius, TArray<TEnumAsByte<EObjectTypeQuery>> SweepObjectTypes, TArray<UClass*> ActorClassFilters, UObject*& __WorldContext, bool& Overlapped); // 0x288a61c (Index: 0x0, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void ShouldLogForInstigator(TEnumAsByte<BlueprintLogLevel>& Instance_Log_Level, UObject*& Instigator, UObject*& __WorldContext, bool& Should_Log_); // 0x288a61c (Index: 0x1, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    static void RequestComponentResource(UCreativeIslandResourceManagerComponent*& ResourceManager, FName& ResourceTag, UActorComponent*& Component, FVector& WorldLocation, UObject*& __WorldContext); // 0x288a61c (Index: 0x2, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void LogString(TEnumAsByte<BlueprintLogLevel>& Instance_Log_Level, FString& LogString, bool& PrintToScreen, UObject*& Instigator, UObject*& __WorldContext); // 0x288a61c (Index: 0x3, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UBuildingFunctionLibrary_C) == 0x28, "Size mismatch for UBuildingFunctionLibrary_C");

// Size: 0x2c1 (Inherited: 0x458, Single: 0xfffffe69)
class UWBP_CaptureForPostBufferUpdate_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2b0 (Size: 0x8, Type: StructProperty)
    UPostBufferUpdate* PostBufferUpdate; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    bool Perform_Default_Post_Buffer_Update; // 0x2c0 (Size: 0x1, Type: BoolProperty)

public:
    virtual void OnInitialized(); // 0x288a61c (Index: 0x0, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UWBP_CaptureForPostBufferUpdate_C) == 0x2c1, "Size mismatch for UWBP_CaptureForPostBufferUpdate_C");
static_assert(offsetof(UWBP_CaptureForPostBufferUpdate_C, UberGraphFrame) == 0x2b0, "Offset mismatch for UWBP_CaptureForPostBufferUpdate_C::UberGraphFrame");
static_assert(offsetof(UWBP_CaptureForPostBufferUpdate_C, PostBufferUpdate) == 0x2b8, "Offset mismatch for UWBP_CaptureForPostBufferUpdate_C::PostBufferUpdate");
static_assert(offsetof(UWBP_CaptureForPostBufferUpdate_C, Perform_Default_Post_Buffer_Update) == 0x2c0, "Offset mismatch for UWBP_CaptureForPostBufferUpdate_C::Perform_Default_Post_Buffer_Update");

// Size: 0xd8 (Inherited: 0x328, Single: 0xfffffdb0)
class UGSC_MiniMapDataOverride_C : public UFortGameStateComponent_MiniMapDataOverride
{
public:
};

static_assert(sizeof(UGSC_MiniMapDataOverride_C) == 0xd8, "Size mismatch for UGSC_MiniMapDataOverride_C");

// Size: 0x2600 (Inherited: 0x6ca8, Single: 0xffffb958)
class UAthena_PlayerCameraMode_Harveting_stock_1P_C : public UAthena_PlayerCameraMode_1P_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraMode_Harveting_stock_1P_C) == 0x2600, "Size mismatch for UAthena_PlayerCameraMode_Harveting_stock_1P_C");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UInterfacePlayerPawn_C : public UInterface
{
public:

public:
    void MeleeSwingRight_End(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void MeleeSwingLeft_End(); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Melee_Effect_Color(FVector& Melee_Color_Set); // 0x288a61c (Index: 0x4, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UInterfacePlayerPawn_C) == 0x28, "Size mismatch for UInterfacePlayerPawn_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCameraModeRangedTargeting_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraModeRangedTargeting_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraModeRangedTargeting_C");

// Size: 0x2600 (Inherited: 0x46a8, Single: 0xffffdf58)
class UPlayerCameraMode1P_C : public UFortCameraMode_Custom
{
public:
};

static_assert(sizeof(UPlayerCameraMode1P_C) == 0x2600, "Size mismatch for UPlayerCameraMode1P_C");

// Size: 0x2020 (Inherited: 0x20a8, Single: 0xffffff78)
class UAthena_PlayerCameraModeBase_C : public UFortCameraMode_ThirdPerson
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraModeBase_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraModeBase_C");

// Size: 0x2020 (Inherited: 0x60e8, Single: 0xffffbf38)
class Uv3_PlayerCameraModeTargetingRifle_C : public Uv3_PlayerCameraModeRanged_C
{
public:
};

static_assert(sizeof(Uv3_PlayerCameraModeTargetingRifle_C) == 0x2020, "Size mismatch for Uv3_PlayerCameraModeTargetingRifle_C");

// Size: 0x2020 (Inherited: 0x60e8, Single: 0xffffbf38)
class Uv2_PlayerCameraModeTargetingRifle_C : public Uv2_PlayerCameraModeRanged_C
{
public:
};

static_assert(sizeof(Uv2_PlayerCameraModeTargetingRifle_C) == 0x2020, "Size mismatch for Uv2_PlayerCameraModeTargetingRifle_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class Uv1_PlayerCameraModeTargetingRifle_C : public Uv1_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(Uv1_PlayerCameraModeTargetingRifle_C) == 0x2020, "Size mismatch for Uv1_PlayerCameraModeTargetingRifle_C");

// Size: 0x2600 (Inherited: 0x46a8, Single: 0xffffdf58)
class UAthena_PlayerCameraMode_1P_C : public UFortCameraMode_Custom
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraMode_1P_C) == 0x2600, "Size mismatch for UAthena_PlayerCameraMode_1P_C");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlueprintDebuggingInterface_C : public UInterface
{
public:

public:
    void GetBlueprintLogLevel(TEnumAsByte<BlueprintLogLevel>& BlueprintLogLevel); // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UBlueprintDebuggingInterface_C) == 0x28, "Size mismatch for UBlueprintDebuggingInterface_C");

// Size: 0x2020 (Inherited: 0x60e8, Single: 0xffffbf38)
class USTW_PlayerCameraModeMelee_C : public UAthena_PlayerCameraModeMelee_C
{
public:
};

static_assert(sizeof(USTW_PlayerCameraModeMelee_C) == 0x2020, "Size mismatch for USTW_PlayerCameraModeMelee_C");

// Size: 0x1f0 (Inherited: 0x468, Single: 0xfffffd88)
class UDefault3PCamera_C : public UFort3PCam_Default
{
public:
};

static_assert(sizeof(UDefault3PCamera_C) == 0x1f0, "Size mismatch for UDefault3PCamera_C");

// Size: 0x1f0 (Inherited: 0x468, Single: 0xfffffd88)
class URanged3PCamera_C : public UFort3PCam_Default
{
public:
};

static_assert(sizeof(URanged3PCamera_C) == 0x1f0, "Size mismatch for URanged3PCamera_C");

// Size: 0x2020 (Inherited: 0x60e8, Single: 0xffffbf38)
class USTW_PlayerCameraModeRangedTargeting_C : public UAthena_PlayerCameraModeRangedTargeting_C
{
public:
};

static_assert(sizeof(USTW_PlayerCameraModeRangedTargeting_C) == 0x2020, "Size mismatch for USTW_PlayerCameraModeRangedTargeting_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCameraModeMelee_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraModeMelee_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraModeMelee_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCameraHoisted_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraHoisted_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraHoisted_C");

// Size: 0x70 (Inherited: 0xf8, Single: 0xffffff78)
class UCinematicCamera_MatineeTransition_C : public UFortCinematicCamera
{
public:
};

static_assert(sizeof(UCinematicCamera_MatineeTransition_C) == 0x70, "Size mismatch for UCinematicCamera_MatineeTransition_C");

// Size: 0x2020 (Inherited: 0x60e8, Single: 0xffffbf38)
class Uv2_PlayerCameraModeTargetingPistol_C : public Uv2_PlayerCameraModeRanged_C
{
public:
};

static_assert(sizeof(Uv2_PlayerCameraModeTargetingPistol_C) == 0x2020, "Size mismatch for Uv2_PlayerCameraModeTargetingPistol_C");

// Size: 0x1f0 (Inherited: 0x468, Single: 0xfffffd88)
class UTargeting3PCamera_VeryShortRange_C : public UFort3PCam_Targeting
{
public:
};

static_assert(sizeof(UTargeting3PCamera_VeryShortRange_C) == 0x1f0, "Size mismatch for UTargeting3PCamera_VeryShortRange_C");

// Size: 0x2020 (Inherited: 0x60e8, Single: 0xffffbf38)
class Uv2_PlayerCameraModeTargetingScope_C : public Uv2_PlayerCameraModeRanged_C
{
public:
};

static_assert(sizeof(Uv2_PlayerCameraModeTargetingScope_C) == 0x2020, "Size mismatch for Uv2_PlayerCameraModeTargetingScope_C");

// Size: 0x1f0 (Inherited: 0x468, Single: 0xfffffd88)
class UTargeting3PCamera_C : public UFort3PCam_Targeting
{
public:
};

static_assert(sizeof(UTargeting3PCamera_C) == 0x1f0, "Size mismatch for UTargeting3PCamera_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UPlayerCameraMode_DBNO_C : public Uv3_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(UPlayerCameraMode_DBNO_C) == 0x2020, "Size mismatch for UPlayerCameraMode_DBNO_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCameraMode_RespawnedAir_C : public UFortCameraMode_RespawnedAir
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraMode_RespawnedAir_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraMode_RespawnedAir_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class Uv1_PlayerCameraModeTargetingScope_C : public Uv1_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(Uv1_PlayerCameraModeTargetingScope_C) == 0x2020, "Size mismatch for Uv1_PlayerCameraModeTargetingScope_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UHoverboardCameraMode_C : public UFortHoverboardCameraMode
{
public:
};

static_assert(sizeof(UHoverboardCameraMode_C) == 0x2020, "Size mismatch for UHoverboardCameraMode_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class Uv3_PlayerCameraModeMelee_C : public Uv3_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(Uv3_PlayerCameraModeMelee_C) == 0x2020, "Size mismatch for Uv3_PlayerCameraModeMelee_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class Uv1_PlayerCameraModeTargetingPistol_C : public Uv1_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(Uv1_PlayerCameraModeTargetingPistol_C) == 0x2020, "Size mismatch for Uv1_PlayerCameraModeTargetingPistol_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class Uv1_PlayerCameraModeMelee_C : public Uv1_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(Uv1_PlayerCameraModeMelee_C) == 0x2020, "Size mismatch for Uv1_PlayerCameraModeMelee_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class Uv1_PlayerCameraModeTargetingVeryShortRange_C : public Uv1_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(Uv1_PlayerCameraModeTargetingVeryShortRange_C) == 0x2020, "Size mismatch for Uv1_PlayerCameraModeTargetingVeryShortRange_C");

// Size: 0x2020 (Inherited: 0x8108, Single: 0xffff9f18)
class USTW_PlayerCameraModeBase_C : public USTW_PlayerCameraModeMelee_C
{
public:
};

static_assert(sizeof(USTW_PlayerCameraModeBase_C) == 0x2020, "Size mismatch for USTW_PlayerCameraModeBase_C");

// Size: 0x1f0 (Inherited: 0x468, Single: 0xfffffd88)
class UTargeting3PCamera_LongRange_C : public UFort3PCam_Targeting
{
public:
};

static_assert(sizeof(UTargeting3PCamera_LongRange_C) == 0x1f0, "Size mismatch for UTargeting3PCamera_LongRange_C");

// Size: 0x2020 (Inherited: 0x20a8, Single: 0xffffff78)
class Uv1_PlayerCameraModeBase_C : public UFortCameraMode_ThirdPerson
{
public:
};

static_assert(sizeof(Uv1_PlayerCameraModeBase_C) == 0x2020, "Size mismatch for Uv1_PlayerCameraModeBase_C");

// Size: 0x2020 (Inherited: 0x60e8, Single: 0xffffbf38)
class Uv3_PlayerCameraModeTargetingVeryShortRange_C : public Uv3_PlayerCameraModeRanged_C
{
public:
};

static_assert(sizeof(Uv3_PlayerCameraModeTargetingVeryShortRange_C) == 0x2020, "Size mismatch for Uv3_PlayerCameraModeTargetingVeryShortRange_C");

// Size: 0x3270 (Inherited: 0x8f40, Single: 0xffffa330)
class AMainPlayerCamera_C : public AFortPlayerCameraZone
{
public:
};

static_assert(sizeof(AMainPlayerCamera_C) == 0x3270, "Size mismatch for AMainPlayerCamera_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCameraModeSkydiveParachute_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraModeSkydiveParachute_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraModeSkydiveParachute_C");

// Size: 0x2020 (Inherited: 0x60e8, Single: 0xffffbf38)
class UAthena_PlayerCameraModeTargetingTethered_C : public UAthena_PlayerCameraModeRangedTargeting_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraModeTargetingTethered_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraModeTargetingTethered_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class Uv1_PlayerCameraModeRanged_C : public Uv1_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(Uv1_PlayerCameraModeRanged_C) == 0x2020, "Size mismatch for Uv1_PlayerCameraModeRanged_C");

// Size: 0x1f0 (Inherited: 0x468, Single: 0xfffffd88)
class UTargeting3PCamera_MidRange_C : public UFort3PCam_Targeting
{
public:
};

static_assert(sizeof(UTargeting3PCamera_MidRange_C) == 0x1f0, "Size mismatch for UTargeting3PCamera_MidRange_C");

// Size: 0x2020 (Inherited: 0x60e8, Single: 0xffffbf38)
class Uv3_PlayerCameraModeTargetingPistol_C : public Uv3_PlayerCameraModeRanged_C
{
public:
};

static_assert(sizeof(Uv3_PlayerCameraModeTargetingPistol_C) == 0x2020, "Size mismatch for Uv3_PlayerCameraModeTargetingPistol_C");

// Size: 0x1f0 (Inherited: 0x468, Single: 0xfffffd88)
class UTargeting3PCamera_Scope_C : public UFort3PCam_Targeting
{
public:
};

static_assert(sizeof(UTargeting3PCamera_Scope_C) == 0x1f0, "Size mismatch for UTargeting3PCamera_Scope_C");

// Size: 0x2020 (Inherited: 0x60e8, Single: 0xffffbf38)
class Uv3_PlayerCameraModeTargetingAssault_C : public Uv3_PlayerCameraModeRanged_C
{
public:
};

static_assert(sizeof(Uv3_PlayerCameraModeTargetingAssault_C) == 0x2020, "Size mismatch for Uv3_PlayerCameraModeTargetingAssault_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCameraModeSkydiveDive_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraModeSkydiveDive_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraModeSkydiveDive_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCameraModeSkydiveGlide_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraModeSkydiveGlide_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraModeSkydiveGlide_C");

// Size: 0x1f0 (Inherited: 0x468, Single: 0xfffffd88)
class USniper3PCamera_C : public UFort3PCam_Default
{
public:
};

static_assert(sizeof(USniper3PCamera_C) == 0x1f0, "Size mismatch for USniper3PCamera_C");

// Size: 0x2020 (Inherited: 0x60e8, Single: 0xffffbf38)
class Uv3_PlayerCameraModeTargetingScope_C : public Uv3_PlayerCameraModeRanged_C
{
public:
};

static_assert(sizeof(Uv3_PlayerCameraModeTargetingScope_C) == 0x2020, "Size mismatch for Uv3_PlayerCameraModeTargetingScope_C");

// Size: 0x1f0 (Inherited: 0x2f8, Single: 0xfffffef8)
class UPlayerTakeDamage_CameraShake_C : public ULegacyCameraShake
{
public:
};

static_assert(sizeof(UPlayerTakeDamage_CameraShake_C) == 0x1f0, "Size mismatch for UPlayerTakeDamage_CameraShake_C");

// Size: 0x370 (Inherited: 0x5f8, Single: 0xfffffd78)
class ABP_TeleportationDrone_C : public APawn
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x328 (Size: 0x8, Type: StructProperty)
    USkeletalMeshComponentBudgeted* SkeletalMeshComponentBudgeted; // 0x330 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* Scene; // 0x338 (Size: 0x8, Type: ObjectProperty)
    double AnimPlayRate; // 0x340 (Size: 0x8, Type: DoubleProperty)
    UMaterialInstanceDynamic* StaticMeshMID; // 0x348 (Size: 0x8, Type: ObjectProperty)
    bool TeleportIn; // 0x350 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_351[0x7]; // 0x351 (Size: 0x7, Type: PaddingProperty)
    UParticleSystemComponent* CharacterAttached; // 0x358 (Size: 0x8, Type: ObjectProperty)
    bool InLobby; // 0x360 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_361[0x7]; // 0x361 (Size: 0x7, Type: PaddingProperty)
    USkeletalMeshComponent* Mesh_for_Attachment; // 0x368 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    void PlaySpawnAnim(); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    UAnimationAsset* Get_Spawn_Animation() const; // 0x288a61c (Index: 0x5, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)

protected:
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABP_TeleportationDrone_C) == 0x370, "Size mismatch for ABP_TeleportationDrone_C");
static_assert(offsetof(ABP_TeleportationDrone_C, UberGraphFrame) == 0x328, "Offset mismatch for ABP_TeleportationDrone_C::UberGraphFrame");
static_assert(offsetof(ABP_TeleportationDrone_C, SkeletalMeshComponentBudgeted) == 0x330, "Offset mismatch for ABP_TeleportationDrone_C::SkeletalMeshComponentBudgeted");
static_assert(offsetof(ABP_TeleportationDrone_C, Scene) == 0x338, "Offset mismatch for ABP_TeleportationDrone_C::Scene");
static_assert(offsetof(ABP_TeleportationDrone_C, AnimPlayRate) == 0x340, "Offset mismatch for ABP_TeleportationDrone_C::AnimPlayRate");
static_assert(offsetof(ABP_TeleportationDrone_C, StaticMeshMID) == 0x348, "Offset mismatch for ABP_TeleportationDrone_C::StaticMeshMID");
static_assert(offsetof(ABP_TeleportationDrone_C, TeleportIn) == 0x350, "Offset mismatch for ABP_TeleportationDrone_C::TeleportIn");
static_assert(offsetof(ABP_TeleportationDrone_C, CharacterAttached) == 0x358, "Offset mismatch for ABP_TeleportationDrone_C::CharacterAttached");
static_assert(offsetof(ABP_TeleportationDrone_C, InLobby) == 0x360, "Offset mismatch for ABP_TeleportationDrone_C::InLobby");
static_assert(offsetof(ABP_TeleportationDrone_C, Mesh_for_Attachment) == 0x368, "Offset mismatch for ABP_TeleportationDrone_C::Mesh_for_Attachment");

// Size: 0x2600 (Inherited: 0x6ca8, Single: 0xffffb958)
class UAthena_PlayerCameraMode_Harveting_1blade_1P_C : public UAthena_PlayerCameraMode_1P_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraMode_Harveting_1blade_1P_C) == 0x2600, "Size mismatch for UAthena_PlayerCameraMode_Harveting_1blade_1P_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCameraMode_HidingProp_Teleport_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraMode_HidingProp_Teleport_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraMode_HidingProp_Teleport_C");

// Size: 0x358 (Inherited: 0x2d0, Single: 0x88)
class ALandscapeWaterInfo_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    double Flood_Water_Level; // 0x2b8 (Size: 0x8, Type: DoubleProperty)
    UTexture2D* Game_Texture__Water_Velocity_and_Height; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2c8[0x8]; // 0x2c8 (Size: 0x8, Type: PaddingProperty)
    FTransform LS_Transform; // 0x2d0 (Size: 0x60, Type: StructProperty)
    FIntPoint LS_RT_Res; // 0x330 (Size: 0x8, Type: StructProperty)
    FVector2D Quad_Size; // 0x338 (Size: 0x10, Type: StructProperty)
    bool Use_Terrain_Velocity_and_Height_Texture; // 0x348 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_349[0x7]; // 0x349 (Size: 0x7, Type: PaddingProperty)
    UMaterialInstanceDynamic* External_Water_MID_To_Update; // 0x350 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ALandscapeWaterInfo_C) == 0x358, "Size mismatch for ALandscapeWaterInfo_C");
static_assert(offsetof(ALandscapeWaterInfo_C, UberGraphFrame) == 0x2a8, "Offset mismatch for ALandscapeWaterInfo_C::UberGraphFrame");
static_assert(offsetof(ALandscapeWaterInfo_C, DefaultSceneRoot) == 0x2b0, "Offset mismatch for ALandscapeWaterInfo_C::DefaultSceneRoot");
static_assert(offsetof(ALandscapeWaterInfo_C, Flood_Water_Level) == 0x2b8, "Offset mismatch for ALandscapeWaterInfo_C::Flood_Water_Level");
static_assert(offsetof(ALandscapeWaterInfo_C, Game_Texture__Water_Velocity_and_Height) == 0x2c0, "Offset mismatch for ALandscapeWaterInfo_C::Game_Texture__Water_Velocity_and_Height");
static_assert(offsetof(ALandscapeWaterInfo_C, LS_Transform) == 0x2d0, "Offset mismatch for ALandscapeWaterInfo_C::LS_Transform");
static_assert(offsetof(ALandscapeWaterInfo_C, LS_RT_Res) == 0x330, "Offset mismatch for ALandscapeWaterInfo_C::LS_RT_Res");
static_assert(offsetof(ALandscapeWaterInfo_C, Quad_Size) == 0x338, "Offset mismatch for ALandscapeWaterInfo_C::Quad_Size");
static_assert(offsetof(ALandscapeWaterInfo_C, Use_Terrain_Velocity_and_Height_Texture) == 0x348, "Offset mismatch for ALandscapeWaterInfo_C::Use_Terrain_Velocity_and_Height_Texture");
static_assert(offsetof(ALandscapeWaterInfo_C, External_Water_MID_To_Update) == 0x350, "Offset mismatch for ALandscapeWaterInfo_C::External_Water_MID_To_Update");

// Size: 0x40 (Inherited: 0x90, Single: 0xffffffb0)
class UBP_UI_PostProcessBlur_C : public USlatePostBufferBlur
{
public:
};

static_assert(sizeof(UBP_UI_PostProcessBlur_C) == 0x40, "Size mismatch for UBP_UI_PostProcessBlur_C");

