/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DemonMaskVoidRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "MaskAnimShared.h"
#include "FortniteGame.h"
#include "GameplayAbilities.h"
#include "ModularGameplay.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x820 (Inherited: 0x1e48, Single: 0xffffe9d8)
class UDemonMaskVoidGadgetAnimInstance : public UMaskBaseCCPAnimInstance
{
public:
    FVector Floater; // 0x7f8 (Size: 0x18, Type: StructProperty)
    double ElapsedTime; // 0x810 (Size: 0x8, Type: DoubleProperty)
    uint8_t Pad_818[0x8]; // 0x818 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDemonMaskVoidGadgetAnimInstance) == 0x820, "Size mismatch for UDemonMaskVoidGadgetAnimInstance");
static_assert(offsetof(UDemonMaskVoidGadgetAnimInstance, Floater) == 0x7f8, "Offset mismatch for UDemonMaskVoidGadgetAnimInstance::Floater");
static_assert(offsetof(UDemonMaskVoidGadgetAnimInstance, ElapsedTime) == 0x810, "Offset mismatch for UDemonMaskVoidGadgetAnimInstance::ElapsedTime");

// Size: 0x1300 (Inherited: 0x20a8, Single: 0xfffff258)
class UDemonMaskVoidLayerAnimInstance : public UFortPlayerAnimInstanceProxy
{
public:
    float IsCasting; // 0x12f0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_12f4[0xc]; // 0x12f4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UDemonMaskVoidLayerAnimInstance) == 0x1300, "Size mismatch for UDemonMaskVoidLayerAnimInstance");
static_assert(offsetof(UDemonMaskVoidLayerAnimInstance, IsCasting) == 0x12f0, "Offset mismatch for UDemonMaskVoidLayerAnimInstance::IsCasting");

// Size: 0xb38 (Inherited: 0xf08, Single: 0xfffffc30)
class UFortGA_DemonMask_Void_Teleport_Base : public UFortGameplayAbility
{
public:
};

static_assert(sizeof(UFortGA_DemonMask_Void_Teleport_Base) == 0xb38, "Size mismatch for UFortGA_DemonMask_Void_Teleport_Base");

// Size: 0xf8 (Inherited: 0x310, Single: 0xfffffde8)
class UFortPawnComponent_VoidTeleport : public UFortPawnComponent
{
public:
    UClass* TeleportHelperClassToSpawn; // 0xc0 (Size: 0x8, Type: ClassProperty)
    FGameplayTag DemonMaskVoidEquipmentTag; // 0xc8 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<ABuildingGameplayActor*> BGAToTeleport; // 0xcc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortProjectileBase*> CurrentTrackedVoidProjectile; // 0xd4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPawn*> OwnerFortPawn; // 0xdc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AVoidMaskTeleportHelperActor*> TeleportHelperActor; // 0xe4 (Size: 0x8, Type: WeakObjectProperty)
    bool bForceCrouch; // 0xec (Size: 0x1, Type: BoolProperty)
    bool bForceCrouchPredicted; // 0xed (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ee[0x2]; // 0xee (Size: 0x2, Type: PaddingProperty)
    TWeakObjectPtr<UFortMovementComp_Character*> OwnerFortMovementComp; // 0xf0 (Size: 0x8, Type: WeakObjectProperty)

public:
    virtual void BP_OnVoidDemonMaskDropped(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    bool CanTeleportWhileVehicleAttached(); // 0x1139d380 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    bool FindWorldTeleportSpot(AActor*& const TestActor, FVector& TestLocation, FRotator& TestRotation); // 0x1139d3a4 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    virtual void ForceCrouch(); // 0x270d644 (Index: 0x3, Flags: Native|Event|Public|BlueprintEvent)
    bool GetForceCrouchPredicted(); // 0x1139d634 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    virtual FVector GetTeleportPositionFromBGA(); // 0x1139d64c (Index: 0x5, Flags: Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnRep_ForceCrouch(); // 0x1139dc50 (Index: 0x8, Flags: Final|Native|Public)
    void ServerSetBGAToTeleport(ABuildingGameplayActor*& NewBuidingActorToTeleportTo); // 0x1139dc78 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void ServerSetCurrentTrackedVoidProjectile(AFortProjectileBase*& NewProjectileToSet); // 0x1139dda4 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void SetForceCrouch(bool& Value); // 0x1139ded0 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void SetForceCrouchPredicted(bool& Value); // 0x1139ded0 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    virtual bool VoidTeleportToLocation(FVector& LocationToTeleport, bool& bIsJustTest, bool& bNoChecks); // 0x1139dffc (Index: 0xd, Flags: Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent)

private:
    void HandleControllerChanged(APawn*& Pawn, AController*& OldController, AController*& NewController); // 0x1139d688 (Index: 0x6, Flags: Final|Native|Private)
    void HandlePawnTeleported(AFortPawn*& TeleportedPawn); // 0x1139d994 (Index: 0x7, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortPawnComponent_VoidTeleport) == 0xf8, "Size mismatch for UFortPawnComponent_VoidTeleport");
static_assert(offsetof(UFortPawnComponent_VoidTeleport, TeleportHelperClassToSpawn) == 0xc0, "Offset mismatch for UFortPawnComponent_VoidTeleport::TeleportHelperClassToSpawn");
static_assert(offsetof(UFortPawnComponent_VoidTeleport, DemonMaskVoidEquipmentTag) == 0xc8, "Offset mismatch for UFortPawnComponent_VoidTeleport::DemonMaskVoidEquipmentTag");
static_assert(offsetof(UFortPawnComponent_VoidTeleport, BGAToTeleport) == 0xcc, "Offset mismatch for UFortPawnComponent_VoidTeleport::BGAToTeleport");
static_assert(offsetof(UFortPawnComponent_VoidTeleport, CurrentTrackedVoidProjectile) == 0xd4, "Offset mismatch for UFortPawnComponent_VoidTeleport::CurrentTrackedVoidProjectile");
static_assert(offsetof(UFortPawnComponent_VoidTeleport, OwnerFortPawn) == 0xdc, "Offset mismatch for UFortPawnComponent_VoidTeleport::OwnerFortPawn");
static_assert(offsetof(UFortPawnComponent_VoidTeleport, TeleportHelperActor) == 0xe4, "Offset mismatch for UFortPawnComponent_VoidTeleport::TeleportHelperActor");
static_assert(offsetof(UFortPawnComponent_VoidTeleport, bForceCrouch) == 0xec, "Offset mismatch for UFortPawnComponent_VoidTeleport::bForceCrouch");
static_assert(offsetof(UFortPawnComponent_VoidTeleport, bForceCrouchPredicted) == 0xed, "Offset mismatch for UFortPawnComponent_VoidTeleport::bForceCrouchPredicted");
static_assert(offsetof(UFortPawnComponent_VoidTeleport, OwnerFortMovementComp) == 0xf0, "Offset mismatch for UFortPawnComponent_VoidTeleport::OwnerFortMovementComp");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class AVoidMaskTeleportHelperActor : public AActor
{
public:
    UCapsuleComponent* CapsuleComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)

public:
    UCapsuleComponent* GetCapsuleComponent(); // 0xa598a54 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool HelperActorTeleportTo(const FVector DestLocation, const FRotator DestRotation); // 0x1139dac0 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(AVoidMaskTeleportHelperActor) == 0x2b0, "Size mismatch for AVoidMaskTeleportHelperActor");
static_assert(offsetof(AVoidMaskTeleportHelperActor, CapsuleComponent) == 0x2a8, "Offset mismatch for AVoidMaskTeleportHelperActor::CapsuleComponent");

