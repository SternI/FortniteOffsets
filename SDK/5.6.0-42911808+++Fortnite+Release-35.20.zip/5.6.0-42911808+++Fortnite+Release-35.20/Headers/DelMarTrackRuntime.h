/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarTrackRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "ModularGameplay.h"
#include "DeveloperSettings.h"
#include "AudioShapes.h"
#include "GameplayTags.h"

// Size: 0xce8 (Inherited: 0x5240, Single: 0xffffbaa8)
class ADelMarTrack : public ADelMarTrackBase
{
public:
    uint8_t TrackType; // 0xc90 (Size: 0x1, Type: EnumProperty)
    bool bIsIndependent; // 0xc91 (Size: 0x1, Type: BoolProperty)
    bool bUserSelectedStartTrack; // 0xc92 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c93[0x5]; // 0xc93 (Size: 0x5, Type: PaddingProperty)
    ADelMarTrack* StartTrackConnection; // 0xc98 (Size: 0x8, Type: ObjectProperty)
    bool bUserSelectedEndTrack; // 0xca0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ca1[0x7]; // 0xca1 (Size: 0x7, Type: PaddingProperty)
    ADelMarTrack* EndTrackConnection; // 0xca8 (Size: 0x8, Type: ObjectProperty)
    float ParentStartDistance; // 0xcb0 (Size: 0x4, Type: FloatProperty)
    float ParentEndDistance; // 0xcb4 (Size: 0x4, Type: FloatProperty)
    float PrimaryStartDistance; // 0xcb8 (Size: 0x4, Type: FloatProperty)
    float PrimaryEndDistance; // 0xcbc (Size: 0x4, Type: FloatProperty)
    float PrimarySegmentLength; // 0xcc0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_cc4[0x4]; // 0xcc4 (Size: 0x4, Type: PaddingProperty)
    UClass* OobTubeClass; // 0xcc8 (Size: 0x8, Type: ClassProperty)
    TWeakObjectPtr<ADelMarTrackOobTube*> AttachedOobTube; // 0xcd0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_cd8[0x10]; // 0xcd8 (Size: 0x10, Type: PaddingProperty)

public:
    float GetParentEndDistance() const; // 0xd2f5884 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetParentStartDistance() const; // 0x56f4d24 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPrimaryDistance(float& DistanceOnThisTrack) const; // 0x11ad54c0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPrimaryEndDistance() const; // 0x11ad55fc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPrimaryLength() const; // 0x11ad5614 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPrimaryStartDistance() const; // 0x11ad562c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetSecondaryDistance(float& const DistanceOnPrimaryTrack) const; // 0x11ad5644 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ADelMarTrack* GetSecondaryEndTrack() const; // 0x11ad5780 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ADelMarTrack* GetSecondaryStartTrack() const; // 0x11ad5798 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsIndependent() const; // 0x11ad637c (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool MergeTrack(ADelMarTrack*& OtherTrack, bool& MergeToEndPoint, bool& CopyFromStartPoint); // 0x11ad65ac (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    bool SplitTrackAtPoint(int32_t& SplitAtPoint); // 0x11ad7c94 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ADelMarTrack) == 0xce8, "Size mismatch for ADelMarTrack");
static_assert(offsetof(ADelMarTrack, TrackType) == 0xc90, "Offset mismatch for ADelMarTrack::TrackType");
static_assert(offsetof(ADelMarTrack, bIsIndependent) == 0xc91, "Offset mismatch for ADelMarTrack::bIsIndependent");
static_assert(offsetof(ADelMarTrack, bUserSelectedStartTrack) == 0xc92, "Offset mismatch for ADelMarTrack::bUserSelectedStartTrack");
static_assert(offsetof(ADelMarTrack, StartTrackConnection) == 0xc98, "Offset mismatch for ADelMarTrack::StartTrackConnection");
static_assert(offsetof(ADelMarTrack, bUserSelectedEndTrack) == 0xca0, "Offset mismatch for ADelMarTrack::bUserSelectedEndTrack");
static_assert(offsetof(ADelMarTrack, EndTrackConnection) == 0xca8, "Offset mismatch for ADelMarTrack::EndTrackConnection");
static_assert(offsetof(ADelMarTrack, ParentStartDistance) == 0xcb0, "Offset mismatch for ADelMarTrack::ParentStartDistance");
static_assert(offsetof(ADelMarTrack, ParentEndDistance) == 0xcb4, "Offset mismatch for ADelMarTrack::ParentEndDistance");
static_assert(offsetof(ADelMarTrack, PrimaryStartDistance) == 0xcb8, "Offset mismatch for ADelMarTrack::PrimaryStartDistance");
static_assert(offsetof(ADelMarTrack, PrimaryEndDistance) == 0xcbc, "Offset mismatch for ADelMarTrack::PrimaryEndDistance");
static_assert(offsetof(ADelMarTrack, PrimarySegmentLength) == 0xcc0, "Offset mismatch for ADelMarTrack::PrimarySegmentLength");
static_assert(offsetof(ADelMarTrack, OobTubeClass) == 0xcc8, "Offset mismatch for ADelMarTrack::OobTubeClass");
static_assert(offsetof(ADelMarTrack, AttachedOobTube) == 0xcd0, "Offset mismatch for ADelMarTrack::AttachedOobTube");

// Size: 0xc90 (Inherited: 0x45b0, Single: 0xffffc6e0)
class ADelMarTrackBase : public AFortCreativeDeviceProp
{
public:
    uint8_t Pad_c10[0x20]; // 0xc10 (Size: 0x20, Type: PaddingProperty)
    UDelMarTrackPaletteTheme* TrackPalette_V2; // 0xc30 (Size: 0x8, Type: ObjectProperty)
    UDelMarTrackPointData* TrackSplinePointData; // 0xc38 (Size: 0x8, Type: ObjectProperty)
    UDelMarTrackSplineComponent* Spline; // 0xc40 (Size: 0x8, Type: ObjectProperty)
    TArray<FDelMarTrackPropSection> TrackPropData; // 0xc48 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarSegmentActorCollection> SegmentCollections; // 0xc58 (Size: 0x10, Type: ArrayProperty)
    float DefaultMaxTrackWidth; // 0xc68 (Size: 0x4, Type: FloatProperty)
    int32_t TotalSegmentActors; // 0xc6c (Size: 0x4, Type: IntProperty)
    float TrackLength; // 0xc70 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c74[0x4]; // 0xc74 (Size: 0x4, Type: PaddingProperty)
    UDelMarTrackPalette* TrackPalette; // 0xc78 (Size: 0x8, Type: ObjectProperty)
    bool bEnableGlobalMaterialCollectionIndex; // 0xc80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c81[0x3]; // 0xc81 (Size: 0x3, Type: PaddingProperty)
    uint32_t GlobalMaterialCollectionIndex; // 0xc84 (Size: 0x4, Type: UInt32Property)
    bool bForceValidOOBTube; // 0xc88 (Size: 0x1, Type: BoolProperty)
    bool bForceValidTrack; // 0xc89 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c8a[0x6]; // 0xc8a (Size: 0x6, Type: PaddingProperty)

public:
    void ConvertTrackTagsToV2(); // 0x11ad4510 (Index: 0x0, Flags: Final|Native|Public)
    bool ForceValidOOBTube() const; // 0xc2f17f8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ForceValidTrack(int32_t& SplineIndex) const; // 0x11ad4740 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<ADelMarTrackSegmentBase*> GetAllTrackSegmentActors(); // 0x11ad4878 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    FDelMarTrackPointDistanceRange GetDistanceRangeFromPointRange(const FDelMarTrackPointIndexRange InRange) const; // 0x11ad4920 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UClass* GetEndCapClass(int32_t& SplineIndex) const; // 0x11ad49f8 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetForwardDistance(float& Start, float& End) const; // 0x11ad4b30 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetLoopDistance(float& InTotalDistance) const; // 0x11ad4d54 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FDelMarSplinePointMetaData GetMetaDataAtSplinePoint(int32_t& SplineIndex) const; // 0x11ad4e94 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNextSplinePoint(int32_t& InSplinePoint) const; // 0x11ad4fd4 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNextSplineSegment(int32_t& InSplineSegmentIndex) const; // 0x11ad5110 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNextSplineSegmentIndexWithActor(int32_t& SplineSegmentIndex) const; // 0x11ad524c (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetPreviousSplinePoint(int32_t& InSplinePoint) const; // 0x11ad5384 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetPreviousSplineSegment(int32_t& InSplineSegmentIndex) const; // 0x11ad5384 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UClass* GetSegmentClassAtSplinePoint(int32_t& SplineIndex) const; // 0x11ad57b0 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetSegmentTrackTypeTag(int32_t& SplineIndex) const; // 0x11ad58e8 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UClass* GetStartCapClass(int32_t& SplineIndex) const; // 0x11ad5b60 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UClass* GetTransitionSegmentClass(int32_t& FromSplineIndex, int32_t& ToSplineIndex) const; // 0x11ad5c98 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsCosmetic() const; // 0x11ad606c (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsDistanceWithinRange(float& InDistance, float& StartDistance, float& EndDistance) const; // 0x11ad6090 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual bool IsPointInOOBTube(const FVector Point) const; // 0x288a61c (Index: 0x15, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    bool IsPrimary() const; // 0x11ad63a0 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSecondary() const; // 0x11ad63c4 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsTrackable() const; // 0x11ad6588 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RebuildTrack(); // 0x11ad7a94 (Index: 0x22, Flags: Final|Native|Public)

protected:
    virtual void InitializeSpline(); // 0x288a61c (Index: 0x12, Flags: Event|Protected|BlueprintEvent)
    void OnMetadataChanged(UDelMarTrackSplineComponent*& InSpline, int32_t& SplineIndex); // 0x11ad706c (Index: 0x19, Flags: Final|Native|Protected)
    void OnSplineClosedLoopChanged(UDelMarTrackSplineComponent*& InSpline, int32_t& SplineIndex); // 0x11ad7274 (Index: 0x1a, Flags: Final|Native|Protected)
    void OnSplinePointAdded(UDelMarTrackSplineComponent*& InSpline, int32_t& SplineIndex); // 0x11ad747c (Index: 0x1b, Flags: Final|Native|Protected)
    void OnSplinePointChanged(UDelMarTrackSplineComponent*& InSpline, int32_t& SplineIndex); // 0x11ad7684 (Index: 0x1c, Flags: Final|Native|Protected)
    void OnSplinePointRemoved(UDelMarTrackSplineComponent*& InSpline, int32_t& SplineIndex); // 0x11ad788c (Index: 0x1d, Flags: Final|Native|Protected)
    virtual void PostRebuildTrack_BP(); // 0x288a61c (Index: 0x1e, Flags: Event|Protected|BlueprintEvent)
    virtual void PostSplineSegmentGenerated(UDelMarTrackSplineComponent*& SplineComp, int32_t& PointIndex); // 0x288a61c (Index: 0x1f, Flags: Event|Protected|BlueprintEvent)
    virtual void PreRebuildTrack_BP(); // 0x288a61c (Index: 0x20, Flags: Event|Protected|BlueprintEvent)
    virtual void PreSplineSegmentGenerated(UDelMarTrackSplineComponent*& SplineComp, int32_t& PointIndex); // 0x288a61c (Index: 0x21, Flags: Event|Protected|BlueprintEvent)
    void SetTrackTypeTagAtIndex(int32_t& SplineIndex, const FGameplayTag Tag); // 0x11ad7aa8 (Index: 0x23, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(ADelMarTrackBase) == 0xc90, "Size mismatch for ADelMarTrackBase");
static_assert(offsetof(ADelMarTrackBase, TrackPalette_V2) == 0xc30, "Offset mismatch for ADelMarTrackBase::TrackPalette_V2");
static_assert(offsetof(ADelMarTrackBase, TrackSplinePointData) == 0xc38, "Offset mismatch for ADelMarTrackBase::TrackSplinePointData");
static_assert(offsetof(ADelMarTrackBase, Spline) == 0xc40, "Offset mismatch for ADelMarTrackBase::Spline");
static_assert(offsetof(ADelMarTrackBase, TrackPropData) == 0xc48, "Offset mismatch for ADelMarTrackBase::TrackPropData");
static_assert(offsetof(ADelMarTrackBase, SegmentCollections) == 0xc58, "Offset mismatch for ADelMarTrackBase::SegmentCollections");
static_assert(offsetof(ADelMarTrackBase, DefaultMaxTrackWidth) == 0xc68, "Offset mismatch for ADelMarTrackBase::DefaultMaxTrackWidth");
static_assert(offsetof(ADelMarTrackBase, TotalSegmentActors) == 0xc6c, "Offset mismatch for ADelMarTrackBase::TotalSegmentActors");
static_assert(offsetof(ADelMarTrackBase, TrackLength) == 0xc70, "Offset mismatch for ADelMarTrackBase::TrackLength");
static_assert(offsetof(ADelMarTrackBase, TrackPalette) == 0xc78, "Offset mismatch for ADelMarTrackBase::TrackPalette");
static_assert(offsetof(ADelMarTrackBase, bEnableGlobalMaterialCollectionIndex) == 0xc80, "Offset mismatch for ADelMarTrackBase::bEnableGlobalMaterialCollectionIndex");
static_assert(offsetof(ADelMarTrackBase, GlobalMaterialCollectionIndex) == 0xc84, "Offset mismatch for ADelMarTrackBase::GlobalMaterialCollectionIndex");
static_assert(offsetof(ADelMarTrackBase, bForceValidOOBTube) == 0xc88, "Offset mismatch for ADelMarTrackBase::bForceValidOOBTube");
static_assert(offsetof(ADelMarTrackBase, bForceValidTrack) == 0xc89, "Offset mismatch for ADelMarTrackBase::bForceValidTrack");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDelMarTrackBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool IsTrackRadiusCheckDisabled(); // 0x11ad656c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool TrackPositionDebugDrawEnabled(); // 0x11ad7dcc (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UDelMarTrackBlueprintFunctionLibrary) == 0x28, "Size mismatch for UDelMarTrackBlueprintFunctionLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDelMarTrackCustomizationInterface : public UInterface
{
public:
};

static_assert(sizeof(UDelMarTrackCustomizationInterface) == 0x28, "Size mismatch for UDelMarTrackCustomizationInterface");

// Size: 0x2e0 (Inherited: 0x5a8, Single: 0xfffffd38)
class ADelMarTrackCustomSegment : public ADelMarTrackSegmentBase
{
public:
    float SegmentLength; // 0x2d8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2dc[0x4]; // 0x2dc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(ADelMarTrackCustomSegment) == 0x2e0, "Size mismatch for ADelMarTrackCustomSegment");
static_assert(offsetof(ADelMarTrackCustomSegment, SegmentLength) == 0x2d8, "Offset mismatch for ADelMarTrackCustomSegment::SegmentLength");

// Size: 0x2d8 (Inherited: 0x2d0, Single: 0x8)
class ADelMarTrackSegmentBase : public AActor
{
public:
    uint8_t Pad_2a8[0x8]; // 0x2a8 (Size: 0x8, Type: PaddingProperty)
    bool bIgnoreSplineLength; // 0x2b0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b1[0x3]; // 0x2b1 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<ADelMarTrackBase*> Track; // 0x2b4 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_2bc[0x4]; // 0x2bc (Size: 0x4, Type: PaddingProperty)
    UDelMarTrackMatLayerComponent* MaterialLayerComponent; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    float BeginDistanceAlongSpline; // 0x2c8 (Size: 0x4, Type: FloatProperty)
    float EndDistanceAlongSpline; // 0x2cc (Size: 0x4, Type: FloatProperty)
    int32_t TrackSegmentIndex; // 0x2d0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2d4[0x4]; // 0x2d4 (Size: 0x4, Type: PaddingProperty)

public:
    bool ContainsDistanceAlongSpline(float& const DistanceAlongSpline) const; // 0x11ad8f6c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FDelMarTrackPointDistanceRange GetSplineDistanceRange() const; // 0x11ad9278 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual USplineMeshComponent* GetSplineMeshComponent() const; // 0x4971f28 (Index: 0x2, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(ADelMarTrackSegmentBase) == 0x2d8, "Size mismatch for ADelMarTrackSegmentBase");
static_assert(offsetof(ADelMarTrackSegmentBase, bIgnoreSplineLength) == 0x2b0, "Offset mismatch for ADelMarTrackSegmentBase::bIgnoreSplineLength");
static_assert(offsetof(ADelMarTrackSegmentBase, Track) == 0x2b4, "Offset mismatch for ADelMarTrackSegmentBase::Track");
static_assert(offsetof(ADelMarTrackSegmentBase, MaterialLayerComponent) == 0x2c0, "Offset mismatch for ADelMarTrackSegmentBase::MaterialLayerComponent");
static_assert(offsetof(ADelMarTrackSegmentBase, BeginDistanceAlongSpline) == 0x2c8, "Offset mismatch for ADelMarTrackSegmentBase::BeginDistanceAlongSpline");
static_assert(offsetof(ADelMarTrackSegmentBase, EndDistanceAlongSpline) == 0x2cc, "Offset mismatch for ADelMarTrackSegmentBase::EndDistanceAlongSpline");
static_assert(offsetof(ADelMarTrackSegmentBase, TrackSegmentIndex) == 0x2d0, "Offset mismatch for ADelMarTrackSegmentBase::TrackSegmentIndex");

// Size: 0x60 (Inherited: 0x58, Single: 0x8)
class UDelMarTrackMaterialCollection : public UDataAsset
{
public:
    uint32_t SelectedIndex; // 0x30 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    TArray<FDelMarTrackMaterialCollectionEntry> Materials; // 0x38 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_48[0x18]; // 0x48 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarTrackMaterialCollection) == 0x60, "Size mismatch for UDelMarTrackMaterialCollection");
static_assert(offsetof(UDelMarTrackMaterialCollection, SelectedIndex) == 0x30, "Offset mismatch for UDelMarTrackMaterialCollection::SelectedIndex");
static_assert(offsetof(UDelMarTrackMaterialCollection, Materials) == 0x38, "Offset mismatch for UDelMarTrackMaterialCollection::Materials");

// Size: 0xd0 (Inherited: 0xe0, Single: 0xfffffff0)
class UDelMarTrackMatLayerComponent : public UActorComponent
{
public:
    TWeakObjectPtr<UStaticMeshComponent*> RoadMesh; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarTrackBase*> Track; // 0xc0 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarTrackMaterialCollection* MaterialCollection; // 0xc8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDelMarTrackMatLayerComponent) == 0xd0, "Size mismatch for UDelMarTrackMatLayerComponent");
static_assert(offsetof(UDelMarTrackMatLayerComponent, RoadMesh) == 0xb8, "Offset mismatch for UDelMarTrackMatLayerComponent::RoadMesh");
static_assert(offsetof(UDelMarTrackMatLayerComponent, Track) == 0xc0, "Offset mismatch for UDelMarTrackMatLayerComponent::Track");
static_assert(offsetof(UDelMarTrackMatLayerComponent, MaterialCollection) == 0xc8, "Offset mismatch for UDelMarTrackMatLayerComponent::MaterialCollection");

// Size: 0x750 (Inherited: 0x1af0, Single: 0xffffec60)
class UDelMarTrackMeshCustomization : public USplineMeshComponent
{
public:
    uint8_t Pad_740[0x1]; // 0x740 (Size: 0x1, Type: PaddingProperty)
    bool bIsADefaultCustomization; // 0x741 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_742[0xe]; // 0x742 (Size: 0xe, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarTrackMeshCustomization) == 0x750, "Size mismatch for UDelMarTrackMeshCustomization");
static_assert(offsetof(UDelMarTrackMeshCustomization, bIsADefaultCustomization) == 0x741, "Offset mismatch for UDelMarTrackMeshCustomization::bIsADefaultCustomization");

// Size: 0x388 (Inherited: 0x2d0, Single: 0xb8)
class ADelMarTrackOobTube : public AActor
{
public:
    ADelMarTrack* AttachedTrack; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UDelMarTrackSplineComponent* Spline; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UDelMarTrackOobTubePointData* SplinePointData; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    TSoftClassPtr TubeMeshComponentClass; // 0x2c0 (Size: 0x20, Type: SoftClassProperty)
    TArray<FDelMarTrackOobTubeMeshSection> OobTubeMeshSections; // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UStaticMesh*> TubeMesh; // 0x2f0 (Size: 0x20, Type: SoftObjectProperty)
    TMap<TSoftObjectPtr<UStaticMesh*>, EDelMarTrackOobTubeTransitionType> TransitionMeshes; // 0x310 (Size: 0x50, Type: MapProperty)
    float DefaultTransitionMeshLength; // 0x360 (Size: 0x4, Type: FloatProperty)
    int32_t DefaultNumSubsections; // 0x364 (Size: 0x4, Type: IntProperty)
    float SmallestSubsectionLength; // 0x368 (Size: 0x4, Type: FloatProperty)
    float MinimumMeshScale; // 0x36c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_370[0x18]; // 0x370 (Size: 0x18, Type: PaddingProperty)

public:
    FGameplayTag GetSplinePointTagAtIndex(int32_t& PointIndex) const; // 0x11ad5a20 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasTubeMeshAtDistance(float& InDistance) const; // 0x11ad5eb0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsAttachedToPrimaryTrack() const; // 0x11ad5fec (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsAttachedToSecondaryTrack() const; // 0x11ad6030 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    void OnAttachedTrackPointAdded(UDelMarTrackSplineComponent*& InSpline, int32_t& PointIndex); // 0x11ad6a54 (Index: 0x6, Flags: Final|Native|Private)
    void OnAttachedTrackPointChanged(UDelMarTrackSplineComponent*& InSpline, int32_t& PointIndex); // 0x11ad6c5c (Index: 0x7, Flags: Final|Native|Private)
    void OnAttachedTrackPointRemoved(UDelMarTrackSplineComponent*& InSpline, int32_t& PointIndex); // 0x11ad6e64 (Index: 0x8, Flags: Final|Native|Private)

protected:
    virtual EDelMarTrackOobTubeTransitionType DetermineTubeMeshTransitionType(int32_t& CurrentPointIndex, int32_t& NextPointIndex) const; // 0x11ad4524 (Index: 0x0, Flags: Native|Event|Protected|BlueprintEvent|Const)
    bool IsSplinePointOffset(int32_t& PointIndex) const; // 0x11ad63e8 (Index: 0x5, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void OnConstructTubeMesh(USplineMeshComponent*& TubeMeshComponent, bool& bIsTransitionMesh, bool& bIsTransitionIn); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPostContructedOOBTube(); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ADelMarTrackOobTube) == 0x388, "Size mismatch for ADelMarTrackOobTube");
static_assert(offsetof(ADelMarTrackOobTube, AttachedTrack) == 0x2a8, "Offset mismatch for ADelMarTrackOobTube::AttachedTrack");
static_assert(offsetof(ADelMarTrackOobTube, Spline) == 0x2b0, "Offset mismatch for ADelMarTrackOobTube::Spline");
static_assert(offsetof(ADelMarTrackOobTube, SplinePointData) == 0x2b8, "Offset mismatch for ADelMarTrackOobTube::SplinePointData");
static_assert(offsetof(ADelMarTrackOobTube, TubeMeshComponentClass) == 0x2c0, "Offset mismatch for ADelMarTrackOobTube::TubeMeshComponentClass");
static_assert(offsetof(ADelMarTrackOobTube, OobTubeMeshSections) == 0x2e0, "Offset mismatch for ADelMarTrackOobTube::OobTubeMeshSections");
static_assert(offsetof(ADelMarTrackOobTube, TubeMesh) == 0x2f0, "Offset mismatch for ADelMarTrackOobTube::TubeMesh");
static_assert(offsetof(ADelMarTrackOobTube, TransitionMeshes) == 0x310, "Offset mismatch for ADelMarTrackOobTube::TransitionMeshes");
static_assert(offsetof(ADelMarTrackOobTube, DefaultTransitionMeshLength) == 0x360, "Offset mismatch for ADelMarTrackOobTube::DefaultTransitionMeshLength");
static_assert(offsetof(ADelMarTrackOobTube, DefaultNumSubsections) == 0x364, "Offset mismatch for ADelMarTrackOobTube::DefaultNumSubsections");
static_assert(offsetof(ADelMarTrackOobTube, SmallestSubsectionLength) == 0x368, "Offset mismatch for ADelMarTrackOobTube::SmallestSubsectionLength");
static_assert(offsetof(ADelMarTrackOobTube, MinimumMeshScale) == 0x36c, "Offset mismatch for ADelMarTrackOobTube::MinimumMeshScale");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UDelMarTrackOobTubePointData : public USplineMetadata
{
public:
    TArray<FDelMarTrackOobTubePointMetaData> MetaData; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarTrackOobTubePointData) == 0x38, "Size mismatch for UDelMarTrackOobTubePointData");
static_assert(offsetof(UDelMarTrackOobTubePointData, MetaData) == 0x28, "Offset mismatch for UDelMarTrackOobTubePointData::MetaData");

// Size: 0x128 (Inherited: 0x250, Single: 0xfffffed8)
class UDelMarTrackOobTubePositionalRenderingComponent : public UControllerComponent
{
public:
    TWeakObjectPtr<UDelMarTrackPositionComponent*> PlayerPositionComponent; // 0xb8 (Size: 0x8, Type: WeakObjectProperty)
    TSet<USplineMeshComponent*> ActiveOOBTubeMeshes; // 0xc0 (Size: 0x50, Type: SetProperty)
    ADelMarTrackOobTube* ActiveOOBTube; // 0x110 (Size: 0x8, Type: ObjectProperty)
    float RenderDistanceInFrontOfPlayer; // 0x118 (Size: 0x4, Type: FloatProperty)
    float RenderDistanceBehindPlayer; // 0x11c (Size: 0x4, Type: FloatProperty)
    float UpdateIntervalInSeconds; // 0x120 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_124[0x4]; // 0x124 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarTrackOobTubePositionalRenderingComponent) == 0x128, "Size mismatch for UDelMarTrackOobTubePositionalRenderingComponent");
static_assert(offsetof(UDelMarTrackOobTubePositionalRenderingComponent, PlayerPositionComponent) == 0xb8, "Offset mismatch for UDelMarTrackOobTubePositionalRenderingComponent::PlayerPositionComponent");
static_assert(offsetof(UDelMarTrackOobTubePositionalRenderingComponent, ActiveOOBTubeMeshes) == 0xc0, "Offset mismatch for UDelMarTrackOobTubePositionalRenderingComponent::ActiveOOBTubeMeshes");
static_assert(offsetof(UDelMarTrackOobTubePositionalRenderingComponent, ActiveOOBTube) == 0x110, "Offset mismatch for UDelMarTrackOobTubePositionalRenderingComponent::ActiveOOBTube");
static_assert(offsetof(UDelMarTrackOobTubePositionalRenderingComponent, RenderDistanceInFrontOfPlayer) == 0x118, "Offset mismatch for UDelMarTrackOobTubePositionalRenderingComponent::RenderDistanceInFrontOfPlayer");
static_assert(offsetof(UDelMarTrackOobTubePositionalRenderingComponent, RenderDistanceBehindPlayer) == 0x11c, "Offset mismatch for UDelMarTrackOobTubePositionalRenderingComponent::RenderDistanceBehindPlayer");
static_assert(offsetof(UDelMarTrackOobTubePositionalRenderingComponent, UpdateIntervalInSeconds) == 0x120, "Offset mismatch for UDelMarTrackOobTubePositionalRenderingComponent::UpdateIntervalInSeconds");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDelMarTrackOobTubeProxy : public UObject
{
public:

public:
    virtual ADelMarTrack* GetAttachedTrack() const; // 0x4d89340 (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual int32_t GetDefaultSubsectionCount() const; // 0xa28fb10 (Index: 0x1, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual double GetDefaultTransitionMeshLength() const; // 0x11ad90b4 (Index: 0x2, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual double GetMinimumMeshScale() const; // 0x11ad90e0 (Index: 0x3, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual AActor* GetOobTubeActor() const; // 0xc99043c (Index: 0x4, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual double GetSmallestSubsectionLength() const; // 0x11ad924c (Index: 0x5, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual USplineComponent* GetSplineComponent() const; // 0xa51c778 (Index: 0x6, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual FDelMarTrackOobTubePointMetaData GetSplineMetadata(int32_t& PointIndex) const; // 0x11ad92a0 (Index: 0x7, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual double GetSplineVisualizationOffset() const; // 0x11ad93f8 (Index: 0x8, Flags: Native|Event|Public|BlueprintEvent|Const)
};

static_assert(sizeof(UDelMarTrackOobTubeProxy) == 0x28, "Size mismatch for UDelMarTrackOobTubeProxy");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UDelMarTrackOobTubeCollectionProxy : public UObject
{
public:
    UClass* OobTubeClass; // 0x28 (Size: 0x8, Type: ClassProperty)

public:
    virtual int32_t GetNumOobTubeProxies() const; // 0xa281860 (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual UDelMarTrackOobTubeProxy* GetOobTubeProxy(int32_t& OobTubeIndex); // 0x11ad910c (Index: 0x1, Flags: Native|Event|Public|BlueprintEvent)
    virtual void RegisterOobTube(AActor*& OobTubeActor); // 0xbff5700 (Index: 0x2, Flags: Native|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UDelMarTrackOobTubeCollectionProxy) == 0x30, "Size mismatch for UDelMarTrackOobTubeCollectionProxy");
static_assert(offsetof(UDelMarTrackOobTubeCollectionProxy, OobTubeClass) == 0x28, "Offset mismatch for UDelMarTrackOobTubeCollectionProxy::OobTubeClass");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UDelMarTrackPaletteTrackType : public UDataAsset
{
public:
    TArray<FDelMarTrackPaletteTrackTypeEntry> StyleArray; // 0x30 (Size: 0x10, Type: ArrayProperty)
    bool bShouldOOBTubeFunnel; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
    UStaticMesh* OOBTubeMeshOverride; // 0x48 (Size: 0x8, Type: ObjectProperty)

private:
    void AddSegmentClassActorToStyle(const FGameplayTag StyleTag, UClass*& SegmentClass); // 0x11ad8dfc (Index: 0x0, Flags: Final|Native|Private|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UDelMarTrackPaletteTrackType) == 0x50, "Size mismatch for UDelMarTrackPaletteTrackType");
static_assert(offsetof(UDelMarTrackPaletteTrackType, StyleArray) == 0x30, "Offset mismatch for UDelMarTrackPaletteTrackType::StyleArray");
static_assert(offsetof(UDelMarTrackPaletteTrackType, bShouldOOBTubeFunnel) == 0x40, "Offset mismatch for UDelMarTrackPaletteTrackType::bShouldOOBTubeFunnel");
static_assert(offsetof(UDelMarTrackPaletteTrackType, OOBTubeMeshOverride) == 0x48, "Offset mismatch for UDelMarTrackPaletteTrackType::OOBTubeMeshOverride");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UDelMarTrackPaletteTransitions : public UDataAsset
{
public:
    TArray<FDelMarTrackPaletteTransitionEntry_v2> TransitionArray; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarTrackPaletteTransitions) == 0x40, "Size mismatch for UDelMarTrackPaletteTransitions");
static_assert(offsetof(UDelMarTrackPaletteTransitions, TransitionArray) == 0x30, "Offset mismatch for UDelMarTrackPaletteTransitions::TransitionArray");

// Size: 0x70 (Inherited: 0x58, Single: 0x18)
class UDelMarTrackPaletteTheme : public UDataAsset
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    FName ThemeName; // 0x38 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    FString ThemeDescription; // 0x40 (Size: 0x10, Type: StrProperty)
    TArray<UDelMarTrackPaletteTrackType*> Tracks; // 0x50 (Size: 0x10, Type: ArrayProperty)
    UDelMarTrackPaletteTransitions* Transitions; // 0x60 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* OOBTubeMesh; // 0x68 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDelMarTrackPaletteTheme) == 0x70, "Size mismatch for UDelMarTrackPaletteTheme");
static_assert(offsetof(UDelMarTrackPaletteTheme, ThemeName) == 0x38, "Offset mismatch for UDelMarTrackPaletteTheme::ThemeName");
static_assert(offsetof(UDelMarTrackPaletteTheme, ThemeDescription) == 0x40, "Offset mismatch for UDelMarTrackPaletteTheme::ThemeDescription");
static_assert(offsetof(UDelMarTrackPaletteTheme, Tracks) == 0x50, "Offset mismatch for UDelMarTrackPaletteTheme::Tracks");
static_assert(offsetof(UDelMarTrackPaletteTheme, Transitions) == 0x60, "Offset mismatch for UDelMarTrackPaletteTheme::Transitions");
static_assert(offsetof(UDelMarTrackPaletteTheme, OOBTubeMesh) == 0x68, "Offset mismatch for UDelMarTrackPaletteTheme::OOBTubeMesh");

// Size: 0x360 (Inherited: 0x2d0, Single: 0x90)
class ADelMarTrackPerformanceScrubber : public AActor
{
public:
    UCameraComponent* Camera; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UDelMarTrackSplineComponent*> Spline; // 0x2b0 (Size: 0x8, Type: WeakObjectProperty)
    FString SplineSelection; // 0x2b8 (Size: 0x10, Type: StrProperty)
    int32_t ScrubUnits; // 0x2c8 (Size: 0x4, Type: IntProperty)
    float CameraHeightOffset; // 0x2cc (Size: 0x4, Type: FloatProperty)
    UCurveFloat* FloatCurve; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    int32_t RuntimeSpeed; // 0x2d8 (Size: 0x4, Type: IntProperty)
    uint8_t bRunCsvProfilerDuringScrub : 1; // 0x2dc:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2dd[0x1b]; // 0x2dd (Size: 0x1b, Type: PaddingProperty)
    int32_t ScrubUnitMax; // 0x2f8 (Size: 0x4, Type: IntProperty)
    uint8_t bRuntimeEnabled : 1; // 0x2fc:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2fd[0x3]; // 0x2fd (Size: 0x3, Type: PaddingProperty)
    TMap<UDelMarTrackSplineComponent*, FString> StringToSplineMap; // 0x300 (Size: 0x50, Type: MapProperty)
    UTimelineComponent* Timeline; // 0x350 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_358[0x8]; // 0x358 (Size: 0x8, Type: PaddingProperty)

protected:
    virtual void ClientStartScrub(); // 0x328ca4c (Index: 0x0, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientStopScrub(); // 0x4de3268 (Index: 0x1, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    void ReceiveRuntimeTrackScrubbingSpeed(); // 0x11ad9424 (Index: 0x2, Flags: Final|Native|Protected)
    void ReceiveRuntimeTrackScrubbingStart(); // 0x11ad9490 (Index: 0x3, Flags: Final|Native|Protected)
    void TimelineFinishedCallback(); // 0x11ad94b4 (Index: 0x4, Flags: Final|Native|Protected)
    void TimelineTickCallback(); // 0x11ad94ec (Index: 0x5, Flags: Final|Native|Protected)
    void TimelineTickFloatCallback(float& Progress); // 0x11ad9510 (Index: 0x6, Flags: Final|Native|Protected)
    TArray<FString> UpdateSplines(); // 0x11ad963c (Index: 0x7, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(ADelMarTrackPerformanceScrubber) == 0x360, "Size mismatch for ADelMarTrackPerformanceScrubber");
static_assert(offsetof(ADelMarTrackPerformanceScrubber, Camera) == 0x2a8, "Offset mismatch for ADelMarTrackPerformanceScrubber::Camera");
static_assert(offsetof(ADelMarTrackPerformanceScrubber, Spline) == 0x2b0, "Offset mismatch for ADelMarTrackPerformanceScrubber::Spline");
static_assert(offsetof(ADelMarTrackPerformanceScrubber, SplineSelection) == 0x2b8, "Offset mismatch for ADelMarTrackPerformanceScrubber::SplineSelection");
static_assert(offsetof(ADelMarTrackPerformanceScrubber, ScrubUnits) == 0x2c8, "Offset mismatch for ADelMarTrackPerformanceScrubber::ScrubUnits");
static_assert(offsetof(ADelMarTrackPerformanceScrubber, CameraHeightOffset) == 0x2cc, "Offset mismatch for ADelMarTrackPerformanceScrubber::CameraHeightOffset");
static_assert(offsetof(ADelMarTrackPerformanceScrubber, FloatCurve) == 0x2d0, "Offset mismatch for ADelMarTrackPerformanceScrubber::FloatCurve");
static_assert(offsetof(ADelMarTrackPerformanceScrubber, RuntimeSpeed) == 0x2d8, "Offset mismatch for ADelMarTrackPerformanceScrubber::RuntimeSpeed");
static_assert(offsetof(ADelMarTrackPerformanceScrubber, bRunCsvProfilerDuringScrub) == 0x2dc, "Offset mismatch for ADelMarTrackPerformanceScrubber::bRunCsvProfilerDuringScrub");
static_assert(offsetof(ADelMarTrackPerformanceScrubber, ScrubUnitMax) == 0x2f8, "Offset mismatch for ADelMarTrackPerformanceScrubber::ScrubUnitMax");
static_assert(offsetof(ADelMarTrackPerformanceScrubber, bRuntimeEnabled) == 0x2fc, "Offset mismatch for ADelMarTrackPerformanceScrubber::bRuntimeEnabled");
static_assert(offsetof(ADelMarTrackPerformanceScrubber, StringToSplineMap) == 0x300, "Offset mismatch for ADelMarTrackPerformanceScrubber::StringToSplineMap");
static_assert(offsetof(ADelMarTrackPerformanceScrubber, Timeline) == 0x350, "Offset mismatch for ADelMarTrackPerformanceScrubber::Timeline");

// Size: 0xc10 (Inherited: 0x39a0, Single: 0xffffd270)
class ADelMarTrackRoadProp : public ABuildingProp
{
public:
    uint8_t RoadPropType; // 0xc00 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c01[0x7]; // 0xc01 (Size: 0x7, Type: PaddingProperty)
    UDelMarTrackSnapToComponent* SnapToComponent; // 0xc08 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ADelMarTrackRoadProp) == 0xc10, "Size mismatch for ADelMarTrackRoadProp");
static_assert(offsetof(ADelMarTrackRoadProp, RoadPropType) == 0xc00, "Offset mismatch for ADelMarTrackRoadProp::RoadPropType");
static_assert(offsetof(ADelMarTrackRoadProp, SnapToComponent) == 0xc08, "Offset mismatch for ADelMarTrackRoadProp::SnapToComponent");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDelMarTrackSegmentCollectionSpawnDataProvider : public UInterface
{
public:
};

static_assert(sizeof(UDelMarTrackSegmentCollectionSpawnDataProvider) == 0x28, "Size mismatch for UDelMarTrackSegmentCollectionSpawnDataProvider");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UDelMarTrackSettings : public UDeveloperSettings
{
public:
    FGameplayTag RootTrackTag; // 0x30 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    TArray<FDelMarTrackTagConverterData> TagConverterData; // 0x38 (Size: 0x10, Type: ArrayProperty)
    FGameplayTag DefaultConverterTag; // 0x48 (Size: 0x4, Type: StructProperty)
    FGameplayTag HiddenTrackTag; // 0x4c (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(UDelMarTrackSettings) == 0x50, "Size mismatch for UDelMarTrackSettings");
static_assert(offsetof(UDelMarTrackSettings, RootTrackTag) == 0x30, "Offset mismatch for UDelMarTrackSettings::RootTrackTag");
static_assert(offsetof(UDelMarTrackSettings, TagConverterData) == 0x38, "Offset mismatch for UDelMarTrackSettings::TagConverterData");
static_assert(offsetof(UDelMarTrackSettings, DefaultConverterTag) == 0x48, "Offset mismatch for UDelMarTrackSettings::DefaultConverterTag");
static_assert(offsetof(UDelMarTrackSettings, HiddenTrackTag) == 0x4c, "Offset mismatch for UDelMarTrackSettings::HiddenTrackTag");

// Size: 0x270 (Inherited: 0x320, Single: 0xffffff50)
class UDelMarTrackSnapToComponent : public USceneComponent
{
public:
    FVector OffsetToOwnerActor; // 0x240 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_258[0x18]; // 0x258 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarTrackSnapToComponent) == 0x270, "Size mismatch for UDelMarTrackSnapToComponent");
static_assert(offsetof(UDelMarTrackSnapToComponent, OffsetToOwnerActor) == 0x240, "Offset mismatch for UDelMarTrackSnapToComponent::OffsetToOwnerActor");

// Size: 0x290 (Inherited: 0x590, Single: 0xfffffd00)
class UDelMarTrackSnapToSplinePointComponent : public UDelMarTrackSnapToComponent
{
public:
    USplineComponent* SplineToSnapTo; // 0x270 (Size: 0x8, Type: ObjectProperty)
    uint8_t SplinePointSnapMode; // 0x278 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_279[0x3]; // 0x279 (Size: 0x3, Type: PaddingProperty)
    int32_t SplinePointIndexToSnapTo; // 0x27c (Size: 0x4, Type: IntProperty)
    uint8_t Pad_280[0x10]; // 0x280 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarTrackSnapToSplinePointComponent) == 0x290, "Size mismatch for UDelMarTrackSnapToSplinePointComponent");
static_assert(offsetof(UDelMarTrackSnapToSplinePointComponent, SplineToSnapTo) == 0x270, "Offset mismatch for UDelMarTrackSnapToSplinePointComponent::SplineToSnapTo");
static_assert(offsetof(UDelMarTrackSnapToSplinePointComponent, SplinePointSnapMode) == 0x278, "Offset mismatch for UDelMarTrackSnapToSplinePointComponent::SplinePointSnapMode");
static_assert(offsetof(UDelMarTrackSnapToSplinePointComponent, SplinePointIndexToSnapTo) == 0x27c, "Offset mismatch for UDelMarTrackSnapToSplinePointComponent::SplinePointIndexToSnapTo");

// Size: 0x2e0 (Inherited: 0x5a8, Single: 0xfffffd38)
class ADelMarTrackStaticMeshSegment : public ADelMarTrackSegmentBase
{
public:
    UStaticMeshComponent* StaticMeshComponent; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ADelMarTrackStaticMeshSegment) == 0x2e0, "Size mismatch for ADelMarTrackStaticMeshSegment");
static_assert(offsetof(ADelMarTrackStaticMeshSegment, StaticMeshComponent) == 0x2d8, "Offset mismatch for ADelMarTrackStaticMeshSegment::StaticMeshComponent");

// Size: 0x360 (Inherited: 0x670, Single: 0xfffffcf0)
class UDelMarTrackVehiclePositionComponent : public UDelMarTrackPositionComponent
{
public:
    AFortAthenaVehicle* Vehicle; // 0x350 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_358[0x8]; // 0x358 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarTrackVehiclePositionComponent) == 0x360, "Size mismatch for UDelMarTrackVehiclePositionComponent");
static_assert(offsetof(UDelMarTrackVehiclePositionComponent, Vehicle) == 0x350, "Offset mismatch for UDelMarTrackVehiclePositionComponent::Vehicle");

// Size: 0x350 (Inherited: 0x320, Single: 0x30)
class UDelMarTrackPositionComponent : public USceneComponent
{
public:
    uint8_t Pad_240[0x30]; // 0x240 (Size: 0x30, Type: PaddingProperty)
    FTrackPosition ActiveTrackPosition; // 0x270 (Size: 0x20, Type: StructProperty)
    float TrackRadius; // 0x290 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_294[0xbc]; // 0x294 (Size: 0xbc, Type: PaddingProperty)

public:
    int32_t GetActiveSegmentIndex() const; // 0x11af4114 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ADelMarTrackBase* GetActiveTrack() const; // 0x11af412c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetActiveTrackDistance() const; // 0x11af4144 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FTrackPosition GetActiveTrackPosition() const; // 0x11af415c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetActiveTrackRadius() const; // 0x11af41c0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ADelMarTrackBase* GetBaseTrackFor(ADelMarTrack*& const Track) const; // 0x11af41e8 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetDistanceAlongSpline() const; // 0x11af4144 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetLastKnowGoodSplineLocation() const; // 0x11af4544 (Index: 0x7, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    float GetPrimaryDistance() const; // 0x11af4aa8 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ADelMarTrackBase* GetPrimaryTrack() const; // 0x11af4ad0 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetPrimaryWorldLocationAlongSpline() const; // 0x11af4af4 (Index: 0xa, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector GetRawClosestSplineLocation() const; // 0x11af4b2c (Index: 0xb, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    float GetRawDistanceAlongSpline() const; // 0x11af4bac (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetWorldDirectionAlongSpline() const; // 0x11af55a4 (Index: 0xd, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector GetWorldLocationAlongSpline() const; // 0x11af55dc (Index: 0xe, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector GetWorldRightVectorAlongSpline() const; // 0x11af5614 (Index: 0xf, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTransform GetWorldTransformAlongSpline() const; // 0x11af5694 (Index: 0x10, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector GetWorldUpVectorAlongSpline() const; // 0x11af5710 (Index: 0x11, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool HasValidPosition() const; // 0x11af5790 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsOnPrimaryTrack() const; // 0x11af6064 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsTouchingTrack() const; // 0xa7ed178 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetActiveTrack(ADelMarTrackBase*& Track, int32_t& TrackSegmentIndex, bool& bForce); // 0x11af60ac (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarTrackPositionComponent) == 0x350, "Size mismatch for UDelMarTrackPositionComponent");
static_assert(offsetof(UDelMarTrackPositionComponent, ActiveTrackPosition) == 0x270, "Offset mismatch for UDelMarTrackPositionComponent::ActiveTrackPosition");
static_assert(offsetof(UDelMarTrackPositionComponent, TrackRadius) == 0x290, "Offset mismatch for UDelMarTrackPositionComponent::TrackRadius");

// Size: 0x88 (Inherited: 0x88, Single: 0x0)
class UDelMarTrackManager : public UWorldSubsystem
{
public:
    uint8_t Pad_30[0x30]; // 0x30 (Size: 0x30, Type: PaddingProperty)
    TArray<ADelMarTrackBase*> DelMarTracks; // 0x60 (Size: 0x10, Type: ArrayProperty)
    ADelMarTrackBase* PrimaryTrack; // 0x70 (Size: 0x8, Type: ObjectProperty)
    ADelMarTrackBase* LowestTrack; // 0x78 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_80[0x8]; // 0x80 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarTrackManager) == 0x88, "Size mismatch for UDelMarTrackManager");
static_assert(offsetof(UDelMarTrackManager, DelMarTracks) == 0x60, "Offset mismatch for UDelMarTrackManager::DelMarTracks");
static_assert(offsetof(UDelMarTrackManager, PrimaryTrack) == 0x70, "Offset mismatch for UDelMarTrackManager::PrimaryTrack");
static_assert(offsetof(UDelMarTrackManager, LowestTrack) == 0x78, "Offset mismatch for UDelMarTrackManager::LowestTrack");

// Size: 0x60 (Inherited: 0x58, Single: 0x8)
class UDelMarTrackPalette : public UDataAsset
{
public:
    TArray<FDelMarTrackPaletteEntry> Palette; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarTrackPaletteTransitionEntry> Transitions; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarTrackCapEntry> Caps; // 0x50 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarTrackPalette) == 0x60, "Size mismatch for UDelMarTrackPalette");
static_assert(offsetof(UDelMarTrackPalette, Palette) == 0x30, "Offset mismatch for UDelMarTrackPalette::Palette");
static_assert(offsetof(UDelMarTrackPalette, Transitions) == 0x40, "Offset mismatch for UDelMarTrackPalette::Transitions");
static_assert(offsetof(UDelMarTrackPalette, Caps) == 0x50, "Offset mismatch for UDelMarTrackPalette::Caps");

// Size: 0x2f0 (Inherited: 0x5a8, Single: 0xfffffd48)
class ADelMarTrackPrefabSegment : public ADelMarTrackSegmentBase
{
public:
    float TangentLength; // 0x2d8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2dc[0x4]; // 0x2dc (Size: 0x4, Type: PaddingProperty)
    UStaticMeshComponent* PrefabStaticMesh; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    FName StartSocketName; // 0x2e8 (Size: 0x4, Type: NameProperty)
    FName EndSocketName; // 0x2ec (Size: 0x4, Type: NameProperty)

private:
    TArray<FString> GetSockets() const; // 0x11af5204 (Index: 0x0, Flags: Final|Native|Private|Const)
};

static_assert(sizeof(ADelMarTrackPrefabSegment) == 0x2f0, "Size mismatch for ADelMarTrackPrefabSegment");
static_assert(offsetof(ADelMarTrackPrefabSegment, TangentLength) == 0x2d8, "Offset mismatch for ADelMarTrackPrefabSegment::TangentLength");
static_assert(offsetof(ADelMarTrackPrefabSegment, PrefabStaticMesh) == 0x2e0, "Offset mismatch for ADelMarTrackPrefabSegment::PrefabStaticMesh");
static_assert(offsetof(ADelMarTrackPrefabSegment, StartSocketName) == 0x2e8, "Offset mismatch for ADelMarTrackPrefabSegment::StartSocketName");
static_assert(offsetof(ADelMarTrackPrefabSegment, EndSocketName) == 0x2ec, "Offset mismatch for ADelMarTrackPrefabSegment::EndSocketName");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDelMarTrackSegmentInterface : public UInterface
{
public:
};

static_assert(sizeof(UDelMarTrackSegmentInterface) == 0x28, "Size mismatch for UDelMarTrackSegmentInterface");

// Size: 0x40 (Inherited: 0x50, Single: 0xfffffff0)
class UDelMarTrackPointData : public USplineMetadata
{
public:
    TArray<FDelMarSplinePointMetaData> MetaData; // 0x28 (Size: 0x10, Type: ArrayProperty)
    UDelMarTrackSplineComponent* Spline; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDelMarTrackPointData) == 0x40, "Size mismatch for UDelMarTrackPointData");
static_assert(offsetof(UDelMarTrackPointData, MetaData) == 0x28, "Offset mismatch for UDelMarTrackPointData::MetaData");
static_assert(offsetof(UDelMarTrackPointData, Spline) == 0x38, "Offset mismatch for UDelMarTrackPointData::Spline");

// Size: 0x670 (Inherited: 0xe10, Single: 0xfffff860)
class UDelMarTrackSplineComponent : public USplineComponent
{
public:
    int32_t WorldPlaneLookupSubsteps; // 0x5c8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_5cc[0x94]; // 0x5cc (Size: 0x94, Type: PaddingProperty)
    TArray<FDelMarRotationalMinimalFrame> RotationalMinimalFrameNormals; // 0x660 (Size: 0x10, Type: ArrayProperty)

public:
    FClosestLocationToWorldPlaneResult FindClosestLocationForSegmentToWorldPlane(const FVector WorldPlaneOrigin, const FVector WorldPlaneNormal, int32_t& const SegmentIndex, TEnumAsByte<ESplineCoordinateSpace>& CoordinateSpace) const; // 0x11af391c (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FClosestLocationToWorldPlaneResult FindClosestLocationToWorldPlane(const FVector WorldPlaneOrigin, const FVector WorldPlaneNormal, TEnumAsByte<ESplineCoordinateSpace>& CoordinateSpace) const; // 0x11af3bec (Index: 0x1, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FClosestLocationToWorldPlaneResult FindInputKeyForNeighboringSegmentClosestToWorldPlane(const FVector WorldPlaneOrigin, const FVector WorldPlaneNormal, int32_t& const SegmentIndex, int32_t& OutClosestSegmentIndex) const; // 0x11af3e38 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    float GetForwardDistance(float& Start, float& End) const; // 0x11af4324 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetLoopDistance(float& InTotalDistance) const; // 0x11af45c4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNextSplinePoint(int32_t& InSplinePoint) const; // 0x11af4700 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNextSplineSegment(int32_t& InSplineSegmentIndex) const; // 0x11af4838 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetPreviousSplinePoint(int32_t& InSplinePoint) const; // 0x11af4970 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetPreviousSplineSegment(int32_t& InSplineSegmentIndex) const; // 0x11af4970 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FDelMarRotationalMinimalFrame> GetRotationalMinimalFrames() const; // 0x11af4bc4 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetRotationalMinimalUpVectorAtDistanceAlongSpline(float& DistanceAlongSpline, TEnumAsByte<ESplineCoordinateSpace>& CoordinateSpace) const; // 0x11af4c4c (Index: 0xa, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector GetRotationalMinimalUpVectorAtSplinePoint(int32_t& SplinePoint, TEnumAsByte<ESplineCoordinateSpace>& CoordinateSpace) const; // 0x11af4fd0 (Index: 0xb, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    int32_t GetSplinePointAtDistanceAlongSpline(float& DistanceAlongSpline) const; // 0x11af5240 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetSplinePointClosestToDistanceAlongSpline(float& DistanceAlongSpline) const; // 0x11af537c (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetSplinePointClosestToWorldLocation(const FVector WorldLocation) const; // 0x11af54b8 (Index: 0xe, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool IsDistanceAheadOfOtherDistance(float& Distance, float& OtherDistance, float& BaseDistance) const; // 0x11af57a8 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsDistanceBehindOtherDistance(float& Distance, float& OtherDistance, float& BaseDistance) const; // 0x11af5a90 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsDistanceWithinRange(float& InDistance, float& StartDistance, float& EndDistance) const; // 0x11af5d7c (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarTrackSplineComponent) == 0x670, "Size mismatch for UDelMarTrackSplineComponent");
static_assert(offsetof(UDelMarTrackSplineComponent, WorldPlaneLookupSubsteps) == 0x5c8, "Offset mismatch for UDelMarTrackSplineComponent::WorldPlaneLookupSubsteps");
static_assert(offsetof(UDelMarTrackSplineComponent, RotationalMinimalFrameNormals) == 0x660, "Offset mismatch for UDelMarTrackSplineComponent::RotationalMinimalFrameNormals");

// Size: 0x2e8 (Inherited: 0x5a8, Single: 0xfffffd40)
class ADelMarTrackSplineMeshSegment : public ADelMarTrackSegmentBase
{
public:
    USplineMeshComponent* SplineMesh; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    float SegmentLengthScaler; // 0x2e0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2e4[0x4]; // 0x2e4 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(ADelMarTrackSplineMeshSegment) == 0x2e8, "Size mismatch for ADelMarTrackSplineMeshSegment");
static_assert(offsetof(ADelMarTrackSplineMeshSegment, SplineMesh) == 0x2d8, "Offset mismatch for ADelMarTrackSplineMeshSegment::SplineMesh");
static_assert(offsetof(ADelMarTrackSplineMeshSegment, SegmentLengthScaler) == 0x2e0, "Offset mismatch for ADelMarTrackSplineMeshSegment::SegmentLengthScaler");

// Size: 0x338 (Inherited: 0x890, Single: 0xfffffaa8)
class ADelMarTrackVariableSplineMeshSegment : public ADelMarTrackSplineMeshSegment
{
public:
    TMap<UStaticMesh*, int32_t> VariableStaticMeshes; // 0x2e8 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(ADelMarTrackVariableSplineMeshSegment) == 0x338, "Size mismatch for ADelMarTrackVariableSplineMeshSegment");
static_assert(offsetof(ADelMarTrackVariableSplineMeshSegment, VariableStaticMeshes) == 0x2e8, "Offset mismatch for ADelMarTrackVariableSplineMeshSegment::VariableStaticMeshes");

// Size: 0x270 (Inherited: 0x518, Single: 0xfffffd58)
class UDelMarTrackTubeAudioComponent : public UAudioShapePrimitiveComponent
{
public:
    float Radius; // 0x218 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_21c[0x4]; // 0x21c (Size: 0x4, Type: PaddingProperty)
    FBox SplineAABB; // 0x220 (Size: 0x38, Type: StructProperty)
    USplineComponent* Spline; // 0x258 (Size: 0x8, Type: ObjectProperty)
    ADelMarTrackOobTube* ParentOobTube; // 0x260 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_268[0x8]; // 0x268 (Size: 0x8, Type: PaddingProperty)

public:
    void SetRadius(float& const InRadius); // 0xc3d67dc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetSpline(USplineComponent*& NewSpline); // 0x11af6390 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarTrackTubeAudioComponent) == 0x270, "Size mismatch for UDelMarTrackTubeAudioComponent");
static_assert(offsetof(UDelMarTrackTubeAudioComponent, Radius) == 0x218, "Offset mismatch for UDelMarTrackTubeAudioComponent::Radius");
static_assert(offsetof(UDelMarTrackTubeAudioComponent, SplineAABB) == 0x220, "Offset mismatch for UDelMarTrackTubeAudioComponent::SplineAABB");
static_assert(offsetof(UDelMarTrackTubeAudioComponent, Spline) == 0x258, "Offset mismatch for UDelMarTrackTubeAudioComponent::Spline");
static_assert(offsetof(UDelMarTrackTubeAudioComponent, ParentOobTube) == 0x260, "Offset mismatch for UDelMarTrackTubeAudioComponent::ParentOobTube");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarTrackAddedEvent
{
    TWeakObjectPtr<ADelMarTrackBase*> Track; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FDelMarTrackAddedEvent) == 0x8, "Size mismatch for FDelMarTrackAddedEvent");
static_assert(offsetof(FDelMarTrackAddedEvent, Track) == 0x0, "Offset mismatch for FDelMarTrackAddedEvent::Track");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarTrackMaterialCollectionEntry
{
    TArray<UMaterialInstanceConstant*> MICs; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarTrackMaterialCollectionEntry) == 0x10, "Size mismatch for FDelMarTrackMaterialCollectionEntry");
static_assert(offsetof(FDelMarTrackMaterialCollectionEntry, MICs) == 0x0, "Offset mismatch for FDelMarTrackMaterialCollectionEntry::MICs");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarTrackOobTubeMeshSection
{
    USplineMeshComponent* TubeMesh; // 0x0 (Size: 0x8, Type: ObjectProperty)
    int32_t PointIndex; // 0x8 (Size: 0x4, Type: IntProperty)
    float StartDistanceAlongSpline; // 0xc (Size: 0x4, Type: FloatProperty)
    float EndDistanceAlongSpline; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarTrackOobTubeMeshSection) == 0x18, "Size mismatch for FDelMarTrackOobTubeMeshSection");
static_assert(offsetof(FDelMarTrackOobTubeMeshSection, TubeMesh) == 0x0, "Offset mismatch for FDelMarTrackOobTubeMeshSection::TubeMesh");
static_assert(offsetof(FDelMarTrackOobTubeMeshSection, PointIndex) == 0x8, "Offset mismatch for FDelMarTrackOobTubeMeshSection::PointIndex");
static_assert(offsetof(FDelMarTrackOobTubeMeshSection, StartDistanceAlongSpline) == 0xc, "Offset mismatch for FDelMarTrackOobTubeMeshSection::StartDistanceAlongSpline");
static_assert(offsetof(FDelMarTrackOobTubeMeshSection, EndDistanceAlongSpline) == 0x10, "Offset mismatch for FDelMarTrackOobTubeMeshSection::EndDistanceAlongSpline");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDelMarTrackOobTubePointMetaData
{
    FVector2D LocationOffset; // 0x0 (Size: 0x10, Type: StructProperty)
    FVector2D ScaleOffset; // 0x10 (Size: 0x10, Type: StructProperty)
    int32_t NumSubsections; // 0x20 (Size: 0x4, Type: IntProperty)
    bool bShouldGenerateTube; // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bShouldMirrorAttachedTrackPoint; // 0x25 (Size: 0x1, Type: BoolProperty)
    bool bIgnoreAutoTransitionScaling; // 0x26 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_27[0x1]; // 0x27 (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarTrackOobTubePointMetaData) == 0x28, "Size mismatch for FDelMarTrackOobTubePointMetaData");
static_assert(offsetof(FDelMarTrackOobTubePointMetaData, LocationOffset) == 0x0, "Offset mismatch for FDelMarTrackOobTubePointMetaData::LocationOffset");
static_assert(offsetof(FDelMarTrackOobTubePointMetaData, ScaleOffset) == 0x10, "Offset mismatch for FDelMarTrackOobTubePointMetaData::ScaleOffset");
static_assert(offsetof(FDelMarTrackOobTubePointMetaData, NumSubsections) == 0x20, "Offset mismatch for FDelMarTrackOobTubePointMetaData::NumSubsections");
static_assert(offsetof(FDelMarTrackOobTubePointMetaData, bShouldGenerateTube) == 0x24, "Offset mismatch for FDelMarTrackOobTubePointMetaData::bShouldGenerateTube");
static_assert(offsetof(FDelMarTrackOobTubePointMetaData, bShouldMirrorAttachedTrackPoint) == 0x25, "Offset mismatch for FDelMarTrackOobTubePointMetaData::bShouldMirrorAttachedTrackPoint");
static_assert(offsetof(FDelMarTrackOobTubePointMetaData, bIgnoreAutoTransitionScaling) == 0x26, "Offset mismatch for FDelMarTrackOobTubePointMetaData::bIgnoreAutoTransitionScaling");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FDelMarTrackPaletteTransitionEntry_v2
{
    FGameplayTag TagA; // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag TagB; // 0x4 (Size: 0x4, Type: StructProperty)
    UClass* TRANSITION; // 0x8 (Size: 0x8, Type: ClassProperty)
    bool bUseReverse; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    UClass* Reverse; // 0x18 (Size: 0x8, Type: ClassProperty)
    bool bEnableOOBTubeTransitions; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
    UStaticMesh* OOBTubeTransitionMesh; // 0x28 (Size: 0x8, Type: ObjectProperty)
    bool bOverrideReverseOOBTubeMesh; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    UStaticMesh* ReverseOOBTubeTransitionMesh; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarTrackPaletteTransitionEntry_v2) == 0x40, "Size mismatch for FDelMarTrackPaletteTransitionEntry_v2");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry_v2, TagA) == 0x0, "Offset mismatch for FDelMarTrackPaletteTransitionEntry_v2::TagA");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry_v2, TagB) == 0x4, "Offset mismatch for FDelMarTrackPaletteTransitionEntry_v2::TagB");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry_v2, TRANSITION) == 0x8, "Offset mismatch for FDelMarTrackPaletteTransitionEntry_v2::TRANSITION");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry_v2, bUseReverse) == 0x10, "Offset mismatch for FDelMarTrackPaletteTransitionEntry_v2::bUseReverse");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry_v2, Reverse) == 0x18, "Offset mismatch for FDelMarTrackPaletteTransitionEntry_v2::Reverse");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry_v2, bEnableOOBTubeTransitions) == 0x20, "Offset mismatch for FDelMarTrackPaletteTransitionEntry_v2::bEnableOOBTubeTransitions");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry_v2, OOBTubeTransitionMesh) == 0x28, "Offset mismatch for FDelMarTrackPaletteTransitionEntry_v2::OOBTubeTransitionMesh");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry_v2, bOverrideReverseOOBTubeMesh) == 0x30, "Offset mismatch for FDelMarTrackPaletteTransitionEntry_v2::bOverrideReverseOOBTubeMesh");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry_v2, ReverseOOBTubeTransitionMesh) == 0x38, "Offset mismatch for FDelMarTrackPaletteTransitionEntry_v2::ReverseOOBTubeTransitionMesh");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FDelMarTrackPaletteTrackTypeEntry
{
    FGameplayTag StyleTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<UClass*> SegmentActors; // 0x8 (Size: 0x10, Type: ArrayProperty)
    UClass* FrontEndcap; // 0x18 (Size: 0x8, Type: ClassProperty)
    bool bIsFrontEndcapReversable; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
    UClass* BackEndcap; // 0x28 (Size: 0x8, Type: ClassProperty)
    UTexture* WidgetImage; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarTrackPaletteTrackTypeEntry) == 0x38, "Size mismatch for FDelMarTrackPaletteTrackTypeEntry");
static_assert(offsetof(FDelMarTrackPaletteTrackTypeEntry, StyleTag) == 0x0, "Offset mismatch for FDelMarTrackPaletteTrackTypeEntry::StyleTag");
static_assert(offsetof(FDelMarTrackPaletteTrackTypeEntry, SegmentActors) == 0x8, "Offset mismatch for FDelMarTrackPaletteTrackTypeEntry::SegmentActors");
static_assert(offsetof(FDelMarTrackPaletteTrackTypeEntry, FrontEndcap) == 0x18, "Offset mismatch for FDelMarTrackPaletteTrackTypeEntry::FrontEndcap");
static_assert(offsetof(FDelMarTrackPaletteTrackTypeEntry, bIsFrontEndcapReversable) == 0x20, "Offset mismatch for FDelMarTrackPaletteTrackTypeEntry::bIsFrontEndcapReversable");
static_assert(offsetof(FDelMarTrackPaletteTrackTypeEntry, BackEndcap) == 0x28, "Offset mismatch for FDelMarTrackPaletteTrackTypeEntry::BackEndcap");
static_assert(offsetof(FDelMarTrackPaletteTrackTypeEntry, WidgetImage) == 0x30, "Offset mismatch for FDelMarTrackPaletteTrackTypeEntry::WidgetImage");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarTrackPointDistanceRange
{
    float BeginDistanceAlongSpline; // 0x0 (Size: 0x4, Type: FloatProperty)
    float EndDistanceAlongSpline; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarTrackPointDistanceRange) == 0x8, "Size mismatch for FDelMarTrackPointDistanceRange");
static_assert(offsetof(FDelMarTrackPointDistanceRange, BeginDistanceAlongSpline) == 0x0, "Offset mismatch for FDelMarTrackPointDistanceRange::BeginDistanceAlongSpline");
static_assert(offsetof(FDelMarTrackPointDistanceRange, EndDistanceAlongSpline) == 0x4, "Offset mismatch for FDelMarTrackPointDistanceRange::EndDistanceAlongSpline");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarTrackPointIndexRange
{
    int32_t BeginPointIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t EndPointIndex; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FDelMarTrackPointIndexRange) == 0x8, "Size mismatch for FDelMarTrackPointIndexRange");
static_assert(offsetof(FDelMarTrackPointIndexRange, BeginPointIndex) == 0x0, "Offset mismatch for FDelMarTrackPointIndexRange::BeginPointIndex");
static_assert(offsetof(FDelMarTrackPointIndexRange, EndPointIndex) == 0x4, "Offset mismatch for FDelMarTrackPointIndexRange::EndPointIndex");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FDelMarTrackProp
{
    TSoftObjectPtr<USkeletalMesh*> SkeletalMesh; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh*> StaticMesh; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    TSoftClassPtr Blueprint; // 0x40 (Size: 0x20, Type: SoftClassProperty)
    uint8_t PropType; // 0x60 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_61[0x7]; // 0x61 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarTrackProp) == 0x68, "Size mismatch for FDelMarTrackProp");
static_assert(offsetof(FDelMarTrackProp, SkeletalMesh) == 0x0, "Offset mismatch for FDelMarTrackProp::SkeletalMesh");
static_assert(offsetof(FDelMarTrackProp, StaticMesh) == 0x20, "Offset mismatch for FDelMarTrackProp::StaticMesh");
static_assert(offsetof(FDelMarTrackProp, Blueprint) == 0x40, "Offset mismatch for FDelMarTrackProp::Blueprint");
static_assert(offsetof(FDelMarTrackProp, PropType) == 0x60, "Offset mismatch for FDelMarTrackProp::PropType");

// Size: 0xf0 (Inherited: 0x0, Single: 0xf0)
struct FDelMarTrackPropSection
{
    TArray<FDelMarTrackPointIndexRange> RangesToApplyTo; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FDelMarTrackProp PropToPlace; // 0x10 (Size: 0x68, Type: StructProperty)
    int32_t NumPropsToPlace; // 0x78 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
    double DistanceBetweenProps; // 0x80 (Size: 0x8, Type: DoubleProperty)
    FName CustomizationPlacementBase; // 0x88 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
    double PlacementBeginPadding; // 0x90 (Size: 0x8, Type: DoubleProperty)
    double PlacementEndPadding; // 0x98 (Size: 0x8, Type: DoubleProperty)
    double PlacementDistanceOffset; // 0xa0 (Size: 0x8, Type: DoubleProperty)
    FVector PlacementScale; // 0xa8 (Size: 0x18, Type: StructProperty)
    FRotator PlacementRotationOffset; // 0xc0 (Size: 0x18, Type: StructProperty)
    uint8_t SupportedTrackSide; // 0xd8 (Size: 0x1, Type: EnumProperty)
    uint8_t PlacementPosition; // 0xd9 (Size: 0x1, Type: EnumProperty)
    uint8_t PlacementSpread; // 0xda (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_db[0x5]; // 0xdb (Size: 0x5, Type: PaddingProperty)
    FString RangesToApplyToEditorString; // 0xe0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FDelMarTrackPropSection) == 0xf0, "Size mismatch for FDelMarTrackPropSection");
static_assert(offsetof(FDelMarTrackPropSection, RangesToApplyTo) == 0x0, "Offset mismatch for FDelMarTrackPropSection::RangesToApplyTo");
static_assert(offsetof(FDelMarTrackPropSection, PropToPlace) == 0x10, "Offset mismatch for FDelMarTrackPropSection::PropToPlace");
static_assert(offsetof(FDelMarTrackPropSection, NumPropsToPlace) == 0x78, "Offset mismatch for FDelMarTrackPropSection::NumPropsToPlace");
static_assert(offsetof(FDelMarTrackPropSection, DistanceBetweenProps) == 0x80, "Offset mismatch for FDelMarTrackPropSection::DistanceBetweenProps");
static_assert(offsetof(FDelMarTrackPropSection, CustomizationPlacementBase) == 0x88, "Offset mismatch for FDelMarTrackPropSection::CustomizationPlacementBase");
static_assert(offsetof(FDelMarTrackPropSection, PlacementBeginPadding) == 0x90, "Offset mismatch for FDelMarTrackPropSection::PlacementBeginPadding");
static_assert(offsetof(FDelMarTrackPropSection, PlacementEndPadding) == 0x98, "Offset mismatch for FDelMarTrackPropSection::PlacementEndPadding");
static_assert(offsetof(FDelMarTrackPropSection, PlacementDistanceOffset) == 0xa0, "Offset mismatch for FDelMarTrackPropSection::PlacementDistanceOffset");
static_assert(offsetof(FDelMarTrackPropSection, PlacementScale) == 0xa8, "Offset mismatch for FDelMarTrackPropSection::PlacementScale");
static_assert(offsetof(FDelMarTrackPropSection, PlacementRotationOffset) == 0xc0, "Offset mismatch for FDelMarTrackPropSection::PlacementRotationOffset");
static_assert(offsetof(FDelMarTrackPropSection, SupportedTrackSide) == 0xd8, "Offset mismatch for FDelMarTrackPropSection::SupportedTrackSide");
static_assert(offsetof(FDelMarTrackPropSection, PlacementPosition) == 0xd9, "Offset mismatch for FDelMarTrackPropSection::PlacementPosition");
static_assert(offsetof(FDelMarTrackPropSection, PlacementSpread) == 0xda, "Offset mismatch for FDelMarTrackPropSection::PlacementSpread");
static_assert(offsetof(FDelMarTrackPropSection, RangesToApplyToEditorString) == 0xe0, "Offset mismatch for FDelMarTrackPropSection::RangesToApplyToEditorString");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarTrackSegmentSpawnInfo
{
};

static_assert(sizeof(FDelMarTrackSegmentSpawnInfo) == 0x18, "Size mismatch for FDelMarTrackSegmentSpawnInfo");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarTrackSegmentCollectionProxyData
{
};

static_assert(sizeof(FDelMarTrackSegmentCollectionProxyData) == 0x30, "Size mismatch for FDelMarTrackSegmentCollectionProxyData");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDelMarSegmentActorCollection
{
    TArray<ADelMarTrackSegmentBase*> Segments; // 0x0 (Size: 0x10, Type: ArrayProperty)
    ADelMarTrackBase* Track; // 0x10 (Size: 0x8, Type: ObjectProperty)
    TArray<UActorComponent*> PropComponents; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarSegmentActorCollection) == 0x28, "Size mismatch for FDelMarSegmentActorCollection");
static_assert(offsetof(FDelMarSegmentActorCollection, Segments) == 0x0, "Offset mismatch for FDelMarSegmentActorCollection::Segments");
static_assert(offsetof(FDelMarSegmentActorCollection, Track) == 0x10, "Offset mismatch for FDelMarSegmentActorCollection::Track");
static_assert(offsetof(FDelMarSegmentActorCollection, PropComponents) == 0x18, "Offset mismatch for FDelMarSegmentActorCollection::PropComponents");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDelMarTrackTagConverterData
{
    FGameplayTag v1Tag; // 0x0 (Size: 0x4, Type: StructProperty)
    bool bCheckCustomizations; // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bNeedRightRail; // 0x5 (Size: 0x1, Type: BoolProperty)
    bool bNeedLeftRail; // 0x6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7[0x1]; // 0x7 (Size: 0x1, Type: PaddingProperty)
    FGameplayTag v2Tag; // 0x8 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FDelMarTrackTagConverterData) == 0xc, "Size mismatch for FDelMarTrackTagConverterData");
static_assert(offsetof(FDelMarTrackTagConverterData, v1Tag) == 0x0, "Offset mismatch for FDelMarTrackTagConverterData::v1Tag");
static_assert(offsetof(FDelMarTrackTagConverterData, bCheckCustomizations) == 0x4, "Offset mismatch for FDelMarTrackTagConverterData::bCheckCustomizations");
static_assert(offsetof(FDelMarTrackTagConverterData, bNeedRightRail) == 0x5, "Offset mismatch for FDelMarTrackTagConverterData::bNeedRightRail");
static_assert(offsetof(FDelMarTrackTagConverterData, bNeedLeftRail) == 0x6, "Offset mismatch for FDelMarTrackTagConverterData::bNeedLeftRail");
static_assert(offsetof(FDelMarTrackTagConverterData, v2Tag) == 0x8, "Offset mismatch for FDelMarTrackTagConverterData::v2Tag");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FDelMarTrackTransformData
{
    TWeakObjectPtr<ADelMarTrackBase*> Track; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform TrackTransform; // 0x10 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FDelMarTrackTransformData) == 0x70, "Size mismatch for FDelMarTrackTransformData");
static_assert(offsetof(FDelMarTrackTransformData, Track) == 0x0, "Offset mismatch for FDelMarTrackTransformData::Track");
static_assert(offsetof(FDelMarTrackTransformData, TrackTransform) == 0x10, "Offset mismatch for FDelMarTrackTransformData::TrackTransform");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FDelMarTrackPaletteTransitionEntry
{
    FGameplayTag TypeA; // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag TypeB; // 0x4 (Size: 0x4, Type: StructProperty)
    TSoftClassPtr AtoB; // 0x8 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr BtoA; // 0x28 (Size: 0x20, Type: SoftClassProperty)
    FString Title; // 0x48 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FDelMarTrackPaletteTransitionEntry) == 0x58, "Size mismatch for FDelMarTrackPaletteTransitionEntry");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry, TypeA) == 0x0, "Offset mismatch for FDelMarTrackPaletteTransitionEntry::TypeA");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry, TypeB) == 0x4, "Offset mismatch for FDelMarTrackPaletteTransitionEntry::TypeB");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry, AtoB) == 0x8, "Offset mismatch for FDelMarTrackPaletteTransitionEntry::AtoB");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry, BtoA) == 0x28, "Offset mismatch for FDelMarTrackPaletteTransitionEntry::BtoA");
static_assert(offsetof(FDelMarTrackPaletteTransitionEntry, Title) == 0x48, "Offset mismatch for FDelMarTrackPaletteTransitionEntry::Title");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FDelMarTrackCapEntry
{
    FGameplayTag Tag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftClassPtr StartCap; // 0x8 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr EndCap; // 0x28 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FDelMarTrackCapEntry) == 0x48, "Size mismatch for FDelMarTrackCapEntry");
static_assert(offsetof(FDelMarTrackCapEntry, Tag) == 0x0, "Offset mismatch for FDelMarTrackCapEntry::Tag");
static_assert(offsetof(FDelMarTrackCapEntry, StartCap) == 0x8, "Offset mismatch for FDelMarTrackCapEntry::StartCap");
static_assert(offsetof(FDelMarTrackCapEntry, EndCap) == 0x28, "Offset mismatch for FDelMarTrackCapEntry::EndCap");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FDelMarTrackPaletteEntry
{
    FGameplayTag TrackTypeTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftClassPtr TrackSegmentClass; // 0x8 (Size: 0x20, Type: SoftClassProperty)
    TArray<FString> MeshCustomizations; // 0x28 (Size: 0x10, Type: ArrayProperty)
    FString Title; // 0x38 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FDelMarTrackPaletteEntry) == 0x48, "Size mismatch for FDelMarTrackPaletteEntry");
static_assert(offsetof(FDelMarTrackPaletteEntry, TrackTypeTag) == 0x0, "Offset mismatch for FDelMarTrackPaletteEntry::TrackTypeTag");
static_assert(offsetof(FDelMarTrackPaletteEntry, TrackSegmentClass) == 0x8, "Offset mismatch for FDelMarTrackPaletteEntry::TrackSegmentClass");
static_assert(offsetof(FDelMarTrackPaletteEntry, MeshCustomizations) == 0x28, "Offset mismatch for FDelMarTrackPaletteEntry::MeshCustomizations");
static_assert(offsetof(FDelMarTrackPaletteEntry, Title) == 0x38, "Offset mismatch for FDelMarTrackPaletteEntry::Title");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FTrackPosition
{
    ADelMarTrackBase* Track; // 0x0 (Size: 0x8, Type: ObjectProperty)
    float DistanceAlongSpline; // 0x8 (Size: 0x4, Type: FloatProperty)
    float RawDistanceAlongSpline; // 0xc (Size: 0x4, Type: FloatProperty)
    float DistanceToVehicleSquared; // 0x10 (Size: 0x4, Type: FloatProperty)
    float LastKnownGoodDistance; // 0x14 (Size: 0x4, Type: FloatProperty)
    int32_t SegmentIndex; // 0x18 (Size: 0x4, Type: IntProperty)
    bool bIsValid; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FTrackPosition) == 0x20, "Size mismatch for FTrackPosition");
static_assert(offsetof(FTrackPosition, Track) == 0x0, "Offset mismatch for FTrackPosition::Track");
static_assert(offsetof(FTrackPosition, DistanceAlongSpline) == 0x8, "Offset mismatch for FTrackPosition::DistanceAlongSpline");
static_assert(offsetof(FTrackPosition, RawDistanceAlongSpline) == 0xc, "Offset mismatch for FTrackPosition::RawDistanceAlongSpline");
static_assert(offsetof(FTrackPosition, DistanceToVehicleSquared) == 0x10, "Offset mismatch for FTrackPosition::DistanceToVehicleSquared");
static_assert(offsetof(FTrackPosition, LastKnownGoodDistance) == 0x14, "Offset mismatch for FTrackPosition::LastKnownGoodDistance");
static_assert(offsetof(FTrackPosition, SegmentIndex) == 0x18, "Offset mismatch for FTrackPosition::SegmentIndex");
static_assert(offsetof(FTrackPosition, bIsValid) == 0x1c, "Offset mismatch for FTrackPosition::bIsValid");

// Size: 0xc8 (Inherited: 0x0, Single: 0xc8)
struct FDelMarSplineSegmentInfo
{
};

static_assert(sizeof(FDelMarSplineSegmentInfo) == 0xc8, "Size mismatch for FDelMarSplineSegmentInfo");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FDelMarSplinePointMetaData
{
    FGameplayTag TrackTypeTag; // 0x0 (Size: 0x4, Type: StructProperty)
    float TrackRadius; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bForceValidTrack; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bUseStableRoll; // 0x9 (Size: 0x1, Type: BoolProperty)
    bool bUseFrontEndcap; // 0xa (Size: 0x1, Type: BoolProperty)
    bool bUseBackEndcap; // 0xb (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    TSoftClassPtr SegmentClass; // 0x10 (Size: 0x20, Type: SoftClassProperty)
    TMap<bool, FString> EnabledMeshCustomizations; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FDelMarSplinePointMetaData) == 0x80, "Size mismatch for FDelMarSplinePointMetaData");
static_assert(offsetof(FDelMarSplinePointMetaData, TrackTypeTag) == 0x0, "Offset mismatch for FDelMarSplinePointMetaData::TrackTypeTag");
static_assert(offsetof(FDelMarSplinePointMetaData, TrackRadius) == 0x4, "Offset mismatch for FDelMarSplinePointMetaData::TrackRadius");
static_assert(offsetof(FDelMarSplinePointMetaData, bForceValidTrack) == 0x8, "Offset mismatch for FDelMarSplinePointMetaData::bForceValidTrack");
static_assert(offsetof(FDelMarSplinePointMetaData, bUseStableRoll) == 0x9, "Offset mismatch for FDelMarSplinePointMetaData::bUseStableRoll");
static_assert(offsetof(FDelMarSplinePointMetaData, bUseFrontEndcap) == 0xa, "Offset mismatch for FDelMarSplinePointMetaData::bUseFrontEndcap");
static_assert(offsetof(FDelMarSplinePointMetaData, bUseBackEndcap) == 0xb, "Offset mismatch for FDelMarSplinePointMetaData::bUseBackEndcap");
static_assert(offsetof(FDelMarSplinePointMetaData, SegmentClass) == 0x10, "Offset mismatch for FDelMarSplinePointMetaData::SegmentClass");
static_assert(offsetof(FDelMarSplinePointMetaData, EnabledMeshCustomizations) == 0x30, "Offset mismatch for FDelMarSplinePointMetaData::EnabledMeshCustomizations");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FClosestLocationToWorldPlaneResult
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    float Key; // 0x18 (Size: 0x4, Type: FloatProperty)
    float DistanceToPlane; // 0x1c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FClosestLocationToWorldPlaneResult) == 0x20, "Size mismatch for FClosestLocationToWorldPlaneResult");
static_assert(offsetof(FClosestLocationToWorldPlaneResult, Location) == 0x0, "Offset mismatch for FClosestLocationToWorldPlaneResult::Location");
static_assert(offsetof(FClosestLocationToWorldPlaneResult, Key) == 0x18, "Offset mismatch for FClosestLocationToWorldPlaneResult::Key");
static_assert(offsetof(FClosestLocationToWorldPlaneResult, DistanceToPlane) == 0x1c, "Offset mismatch for FClosestLocationToWorldPlaneResult::DistanceToPlane");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FDelMarRotationalMinimalFrame
{
    float InputKey; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector origin; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Tangent; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector RotationAxis; // 0x38 (Size: 0x18, Type: StructProperty)
    FVector Normal; // 0x50 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDelMarRotationalMinimalFrame) == 0x68, "Size mismatch for FDelMarRotationalMinimalFrame");
static_assert(offsetof(FDelMarRotationalMinimalFrame, InputKey) == 0x0, "Offset mismatch for FDelMarRotationalMinimalFrame::InputKey");
static_assert(offsetof(FDelMarRotationalMinimalFrame, origin) == 0x8, "Offset mismatch for FDelMarRotationalMinimalFrame::origin");
static_assert(offsetof(FDelMarRotationalMinimalFrame, Tangent) == 0x20, "Offset mismatch for FDelMarRotationalMinimalFrame::Tangent");
static_assert(offsetof(FDelMarRotationalMinimalFrame, RotationAxis) == 0x38, "Offset mismatch for FDelMarRotationalMinimalFrame::RotationAxis");
static_assert(offsetof(FDelMarRotationalMinimalFrame, Normal) == 0x50, "Offset mismatch for FDelMarRotationalMinimalFrame::Normal");

