/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserCategoryTile
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DiscoveryBrowserUI.h"
#include "Engine.h"
#include "UMG.h"

// Size: 0x1558 (Inherited: 0x4640, Single: 0xffffcf18)
class UActivityBrowserCategoryTile_C : public UFortActivityCategoryTile
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x1540 (Size: 0x8, Type: StructProperty)
    UImage* Image_Tile; // 0x1548 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* TileHover; // 0x1550 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void Construct(); // 0x288a61c (Index: 0x2, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void OnTileActiveSet(bool& const bIsTileActive); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnEntryReleased(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UActivityBrowserCategoryTile_C) == 0x1558, "Size mismatch for UActivityBrowserCategoryTile_C");
static_assert(offsetof(UActivityBrowserCategoryTile_C, UberGraphFrame) == 0x1540, "Offset mismatch for UActivityBrowserCategoryTile_C::UberGraphFrame");
static_assert(offsetof(UActivityBrowserCategoryTile_C, Image_Tile) == 0x1548, "Offset mismatch for UActivityBrowserCategoryTile_C::Image_Tile");
static_assert(offsetof(UActivityBrowserCategoryTile_C, TileHover) == 0x1550, "Offset mismatch for UActivityBrowserCategoryTile_C::TileHover");

