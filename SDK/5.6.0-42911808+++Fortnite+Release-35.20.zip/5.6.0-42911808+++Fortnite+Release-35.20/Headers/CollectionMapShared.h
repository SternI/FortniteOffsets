/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CollectionMapShared
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "CommonUI.h"
#include "GameplayTags.h"
#include "CoreUObject.h"

// Size: 0x6d8 (Inherited: 0x1188, Single: 0xfffff550)
class UAthenaCollectionScreenMapBase : public UAthenaCollectionScreenBase
{
public:
    UAthenaFullScreenMapBase* MapWidget; // 0x650 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_658[0x8]; // 0x658 (Size: 0x8, Type: PaddingProperty)
    UClass* CollectionIconType; // 0x660 (Size: 0x8, Type: ClassProperty)
    TMap<UAthenaMapCollectionIcon*, FGameplayTag> MapCollectionIcons; // 0x668 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_6b8[0x20]; // 0x6b8 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UAthenaCollectionScreenMapBase) == 0x6d8, "Size mismatch for UAthenaCollectionScreenMapBase");
static_assert(offsetof(UAthenaCollectionScreenMapBase, MapWidget) == 0x650, "Offset mismatch for UAthenaCollectionScreenMapBase::MapWidget");
static_assert(offsetof(UAthenaCollectionScreenMapBase, CollectionIconType) == 0x660, "Offset mismatch for UAthenaCollectionScreenMapBase::CollectionIconType");
static_assert(offsetof(UAthenaCollectionScreenMapBase, MapCollectionIcons) == 0x668, "Offset mismatch for UAthenaCollectionScreenMapBase::MapCollectionIcons");

// Size: 0x370 (Inherited: 0xe10, Single: 0xfffff560)
class UAthenaMapCollectionIcon : public UAthenaMapNavigableIconCustom
{
public:

public:
    virtual void SetIsKnown(bool& const bIsKnown); // 0x288a61c (Index: 0x0, Flags: RequiredAPI|Event|Public|BlueprintEvent)
    virtual void SetSecondaryIcon(const TSoftObjectPtr<UObject*> SecondaryIcon); // 0x288a61c (Index: 0x1, Flags: RequiredAPI|Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UAthenaMapCollectionIcon) == 0x370, "Size mismatch for UAthenaMapCollectionIcon");

