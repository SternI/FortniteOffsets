/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteVersion
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FFortReleaseVersion
{
    FName VersionName; // 0x0 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FFortReleaseVersion) == 0x4, "Size mismatch for FFortReleaseVersion");
static_assert(offsetof(FFortReleaseVersion, VersionName) == 0x0, "Offset mismatch for FFortReleaseVersion::VersionName");

