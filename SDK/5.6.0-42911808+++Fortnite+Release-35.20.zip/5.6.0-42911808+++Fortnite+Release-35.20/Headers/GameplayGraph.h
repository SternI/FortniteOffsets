/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayGraph
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UGraphElement : public UObject
{
public:
    uint8_t ElementType[0x4]; // 0x28 (Size: 0x4, Type: EnumProperty)
    FGraphUniqueIndex UniqueIndex; // 0x2c (Size: 0x14, Type: StructProperty)
    TWeakObjectPtr<UGraph*> ParentGraph; // 0x40 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UGraphElement) == 0x48, "Size mismatch for UGraphElement");
static_assert(offsetof(UGraphElement, ElementType) == 0x28, "Offset mismatch for UGraphElement::ElementType");
static_assert(offsetof(UGraphElement, UniqueIndex) == 0x2c, "Offset mismatch for UGraphElement::UniqueIndex");
static_assert(offsetof(UGraphElement, ParentGraph) == 0x40, "Offset mismatch for UGraphElement::ParentGraph");

// Size: 0x130 (Inherited: 0x28, Single: 0x108)
class UGraph : public UObject
{
public:
    uint8_t Pad_28[0x60]; // 0x28 (Size: 0x60, Type: PaddingProperty)
    TMap<UGraphVertex*, FGraphVertexHandle> Vertices; // 0x88 (Size: 0x50, Type: MapProperty)
    TMap<UGraphIsland*, FGraphIslandHandle> Islands; // 0xd8 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_128[0x8]; // 0x128 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UGraph) == 0x130, "Size mismatch for UGraph");
static_assert(offsetof(UGraph, Vertices) == 0x88, "Offset mismatch for UGraph::Vertices");
static_assert(offsetof(UGraph, Islands) == 0xd8, "Offset mismatch for UGraph::Islands");

// Size: 0x100 (Inherited: 0x70, Single: 0x90)
class UGraphIsland : public UGraphElement
{
public:
    uint8_t Pad_48[0x60]; // 0x48 (Size: 0x60, Type: PaddingProperty)
    TSet<FGraphVertexHandle> Vertices; // 0xa8 (Size: 0x50, Type: SetProperty)
    uint8_t AllowedOperations[0x4]; // 0xf8 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_fc[0x4]; // 0xfc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UGraphIsland) == 0x100, "Size mismatch for UGraphIsland");
static_assert(offsetof(UGraphIsland, Vertices) == 0xa8, "Offset mismatch for UGraphIsland::Vertices");
static_assert(offsetof(UGraphIsland, AllowedOperations) == 0xf8, "Offset mismatch for UGraphIsland::AllowedOperations");

// Size: 0xf0 (Inherited: 0x70, Single: 0x80)
class UGraphVertex : public UGraphElement
{
public:
    uint8_t Pad_48[0x30]; // 0x48 (Size: 0x30, Type: PaddingProperty)
    TSet<FGraphVertexHandle> Edges; // 0x78 (Size: 0x50, Type: SetProperty)
    FGraphIslandHandle ParentIsland; // 0xc8 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UGraphVertex) == 0xf0, "Size mismatch for UGraphVertex");
static_assert(offsetof(UGraphVertex, Edges) == 0x78, "Offset mismatch for UGraphVertex::Edges");
static_assert(offsetof(UGraphVertex, ParentIsland) == 0xc8, "Offset mismatch for UGraphVertex::ParentIsland");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGraphProperties
{
    bool bGenerateIslands; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FGraphProperties) == 0x1, "Size mismatch for FGraphProperties");
static_assert(offsetof(FGraphProperties, bGenerateIslands) == 0x0, "Offset mismatch for FGraphProperties::bGenerateIslands");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FSerializedEdgeData
{
    FGraphVertexHandle Node1; // 0x0 (Size: 0x28, Type: StructProperty)
    FGraphVertexHandle Node2; // 0x28 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FSerializedEdgeData) == 0x50, "Size mismatch for FSerializedEdgeData");
static_assert(offsetof(FSerializedEdgeData, Node1) == 0x0, "Offset mismatch for FSerializedEdgeData::Node1");
static_assert(offsetof(FSerializedEdgeData, Node2) == 0x28, "Offset mismatch for FSerializedEdgeData::Node2");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGraphHandle
{
    FGraphUniqueIndex UniqueIndex; // 0x8 (Size: 0x14, Type: StructProperty)
    TWeakObjectPtr<UGraph*> WeakGraph; // 0x1c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGraphHandle) == 0x28, "Size mismatch for FGraphHandle");
static_assert(offsetof(FGraphHandle, UniqueIndex) == 0x8, "Offset mismatch for FGraphHandle::UniqueIndex");
static_assert(offsetof(FGraphHandle, WeakGraph) == 0x1c, "Offset mismatch for FGraphHandle::WeakGraph");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FGraphUniqueIndex
{
    FGuid UniqueIndex; // 0x0 (Size: 0x10, Type: StructProperty)
    bool bIsTemporary; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGraphUniqueIndex) == 0x14, "Size mismatch for FGraphUniqueIndex");
static_assert(offsetof(FGraphUniqueIndex, UniqueIndex) == 0x0, "Offset mismatch for FGraphUniqueIndex::UniqueIndex");
static_assert(offsetof(FGraphUniqueIndex, bIsTemporary) == 0x10, "Offset mismatch for FGraphUniqueIndex::bIsTemporary");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
struct FGraphVertexHandle : FGraphHandle
{
};

static_assert(sizeof(FGraphVertexHandle) == 0x28, "Size mismatch for FGraphVertexHandle");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSerializedIslandData
{
    TArray<FGraphVertexHandle> Vertices; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FSerializedIslandData) == 0x10, "Size mismatch for FSerializedIslandData");
static_assert(offsetof(FSerializedIslandData, Vertices) == 0x0, "Offset mismatch for FSerializedIslandData::Vertices");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FSerializableGraph
{
    FGraphProperties Properties; // 0x0 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TArray<FGraphVertexHandle> Vertices; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FSerializedEdgeData> Edges; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TMap<FSerializedIslandData, FGraphIslandHandle> Islands; // 0x28 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FSerializableGraph) == 0x78, "Size mismatch for FSerializableGraph");
static_assert(offsetof(FSerializableGraph, Properties) == 0x0, "Offset mismatch for FSerializableGraph::Properties");
static_assert(offsetof(FSerializableGraph, Vertices) == 0x8, "Offset mismatch for FSerializableGraph::Vertices");
static_assert(offsetof(FSerializableGraph, Edges) == 0x18, "Offset mismatch for FSerializableGraph::Edges");
static_assert(offsetof(FSerializableGraph, Islands) == 0x28, "Offset mismatch for FSerializableGraph::Islands");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
struct FGraphIslandHandle : FGraphHandle
{
};

static_assert(sizeof(FGraphIslandHandle) == 0x28, "Size mismatch for FGraphIslandHandle");

