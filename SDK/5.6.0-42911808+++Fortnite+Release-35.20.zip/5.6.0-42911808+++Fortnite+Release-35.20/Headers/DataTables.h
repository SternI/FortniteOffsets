/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataTables
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "UMG.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FStruct_VEH_Windows
{
    TSoftObjectPtr<UMaterialInstanceConstant*> Window_23_9242D84D446944DD0D7D739136E38C28; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FStruct_VEH_Windows) == 0x20, "Size mismatch for FStruct_VEH_Windows");
static_assert(offsetof(FStruct_VEH_Windows, Window_23_9242D84D446944DD0D7D739136E38C28) == 0x0, "Offset mismatch for FStruct_VEH_Windows::Window_23_9242D84D446944DD0D7D739136E38C28");

// Size: 0x30 (Inherited: 0x80, Single: 0xffffffb0)
class UBP_FlagsDecorator_C : public URichTextBlockImageDecorator
{
public:
};

static_assert(sizeof(UBP_FlagsDecorator_C) == 0x30, "Size mismatch for UBP_FlagsDecorator_C");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FStruct_VehicleCosmetics_Painted
{
    FLinearColor PrimaryColor_32_9242D84D446944DD0D7D739136E38C28; // 0x0 (Size: 0x10, Type: StructProperty)
    FLinearColor Balanced_34_F677FC9D4B1B4146E8CC9DBCB9E0943E; // 0x10 (Size: 0x10, Type: StructProperty)
    FLinearColor Metallic_41_F57CE68E419E301DD160BEB5D0E32BFC; // 0x20 (Size: 0x10, Type: StructProperty)
    FLinearColor Emissive_44_23B897DD46FCCC1FE8A014AA4FE4104B; // 0x30 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FStruct_VehicleCosmetics_Painted) == 0x40, "Size mismatch for FStruct_VehicleCosmetics_Painted");
static_assert(offsetof(FStruct_VehicleCosmetics_Painted, PrimaryColor_32_9242D84D446944DD0D7D739136E38C28) == 0x0, "Offset mismatch for FStruct_VehicleCosmetics_Painted::PrimaryColor_32_9242D84D446944DD0D7D739136E38C28");
static_assert(offsetof(FStruct_VehicleCosmetics_Painted, Balanced_34_F677FC9D4B1B4146E8CC9DBCB9E0943E) == 0x10, "Offset mismatch for FStruct_VehicleCosmetics_Painted::Balanced_34_F677FC9D4B1B4146E8CC9DBCB9E0943E");
static_assert(offsetof(FStruct_VehicleCosmetics_Painted, Metallic_41_F57CE68E419E301DD160BEB5D0E32BFC) == 0x20, "Offset mismatch for FStruct_VehicleCosmetics_Painted::Metallic_41_F57CE68E419E301DD160BEB5D0E32BFC");
static_assert(offsetof(FStruct_VehicleCosmetics_Painted, Emissive_44_23B897DD46FCCC1FE8A014AA4FE4104B) == 0x30, "Offset mismatch for FStruct_VehicleCosmetics_Painted::Emissive_44_23B897DD46FCCC1FE8A014AA4FE4104B");

