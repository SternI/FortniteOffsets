/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AvfMediaFactory
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UAvfMediaSettings : public UObject
{
public:
    bool NativeAudioOut; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UAvfMediaSettings) == 0x30, "Size mismatch for UAvfMediaSettings");
static_assert(offsetof(UAvfMediaSettings, NativeAudioOut) == 0x28, "Offset mismatch for UAvfMediaSettings::NativeAudioOut");

