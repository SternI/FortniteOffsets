/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EventModeUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "Paper2D.h"
#include "UMG.h"
#include "FortniteGame.h"

// Size: 0x448 (Inherited: 0x1960, Single: 0xffffeae8)
class UFocusButton : public UBacchusActionButton
{
public:
    UPaperSprite* StartFocusingSprite; // 0x438 (Size: 0x8, Type: ObjectProperty)
    UPaperSprite* StopFocusingSprite; // 0x440 (Size: 0x8, Type: ObjectProperty)

private:
    void HandleCanUseEventModeFocusChanged(bool& bCanUseEventModeFocus); // 0x113e1b9c (Index: 0x0, Flags: Final|Native|Private)
    void HandleEventModeFocusingChanged(bool& bIsEventModeFocusing); // 0x113e1cc0 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UFocusButton) == 0x448, "Size mismatch for UFocusButton");
static_assert(offsetof(UFocusButton, StartFocusingSprite) == 0x438, "Offset mismatch for UFocusButton::StartFocusingSprite");
static_assert(offsetof(UFocusButton, StopFocusingSprite) == 0x440, "Offset mismatch for UFocusButton::StopFocusingSprite");

// Size: 0x3b0 (Inherited: 0xa48, Single: 0xfffff968)
class UFortEventModeEmotesWidget : public UFortHUDElementWidget
{
public:
    TSoftObjectPtr<UFortMontageItemDefinitionBase*> Emote1; // 0x318 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortMontageItemDefinitionBase*> Emote2; // 0x338 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UFortMontageItemDefinitionBase*> Emote3; // 0x358 (Size: 0x20, Type: SoftObjectProperty)
    TArray<TSoftObjectPtr<UFortMontageItemDefinitionBase*>> RandomEmotes; // 0x378 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_388[0x8]; // 0x388 (Size: 0x8, Type: PaddingProperty)
    URichTextBlock* Text_Emote1; // 0x390 (Size: 0x8, Type: ObjectProperty)
    URichTextBlock* Text_Emote2; // 0x398 (Size: 0x8, Type: ObjectProperty)
    URichTextBlock* Text_Emote3; // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    URichTextBlock* Text_EmoteRandom; // 0x3a8 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void OnFocusAvailableChanged(bool& bIsFocusAvailable); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void OnFocusStateChanged(bool& bIsFocusing); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFortEventModeEmotesWidget) == 0x3b0, "Size mismatch for UFortEventModeEmotesWidget");
static_assert(offsetof(UFortEventModeEmotesWidget, Emote1) == 0x318, "Offset mismatch for UFortEventModeEmotesWidget::Emote1");
static_assert(offsetof(UFortEventModeEmotesWidget, Emote2) == 0x338, "Offset mismatch for UFortEventModeEmotesWidget::Emote2");
static_assert(offsetof(UFortEventModeEmotesWidget, Emote3) == 0x358, "Offset mismatch for UFortEventModeEmotesWidget::Emote3");
static_assert(offsetof(UFortEventModeEmotesWidget, RandomEmotes) == 0x378, "Offset mismatch for UFortEventModeEmotesWidget::RandomEmotes");
static_assert(offsetof(UFortEventModeEmotesWidget, Text_Emote1) == 0x390, "Offset mismatch for UFortEventModeEmotesWidget::Text_Emote1");
static_assert(offsetof(UFortEventModeEmotesWidget, Text_Emote2) == 0x398, "Offset mismatch for UFortEventModeEmotesWidget::Text_Emote2");
static_assert(offsetof(UFortEventModeEmotesWidget, Text_Emote3) == 0x3a0, "Offset mismatch for UFortEventModeEmotesWidget::Text_Emote3");
static_assert(offsetof(UFortEventModeEmotesWidget, Text_EmoteRandom) == 0x3a8, "Offset mismatch for UFortEventModeEmotesWidget::Text_EmoteRandom");

// Size: 0x2a0 (Inherited: 0x378, Single: 0xffffff28)
class UFortMobileActionButtonBehavior_Focus : public UFortMobileActionButtonBehavior
{
public:
    UPaperSprite* StopFocusingSprite; // 0x298 (Size: 0x8, Type: ObjectProperty)

private:
    void HandleCanUseEventModeFocusChanged(bool& bCanUseEventModeFocus); // 0xf4852b0 (Index: 0x0, Flags: Final|Native|Private)
    void HandleEventModeFocusingChanged(bool& bIsEventModeFocusing); // 0xf485184 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortMobileActionButtonBehavior_Focus) == 0x2a0, "Size mismatch for UFortMobileActionButtonBehavior_Focus");
static_assert(offsetof(UFortMobileActionButtonBehavior_Focus, StopFocusingSprite) == 0x298, "Offset mismatch for UFortMobileActionButtonBehavior_Focus::StopFocusingSprite");

