/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMInWorldKnobsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "FabricRuntime.h"
#include "FMDeviceCablesRuntime.h"
#include "UMG.h"
#include "GameplayTags.h"
#include "FabricUI.h"
#include "HarmonixMetasound.h"
#include "FabricFramework.h"
#include "FabricMetasoundDataTypes.h"

// Size: 0xe8 (Inherited: 0x158, Single: 0xffffff90)
class UFabricChildActorTickSubsystem : public UFortManagedTickSubsystem
{
public:
    uint8_t Pad_d0[0x8]; // 0xd0 (Size: 0x8, Type: PaddingProperty)
    TArray<TWeakObjectPtr<UFabricChildActorComponent*>> ChildActorComponentsPendingSpawn; // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFabricChildActorTickSubsystem) == 0xe8, "Size mismatch for UFabricChildActorTickSubsystem");
static_assert(offsetof(UFabricChildActorTickSubsystem, ChildActorComponentsPendingSpawn) == 0xd8, "Offset mismatch for UFabricChildActorTickSubsystem::ChildActorComponentsPendingSpawn");

// Size: 0x310 (Inherited: 0x5b0, Single: 0xfffffd60)
class UFabricChildActorComponent : public UChildActorComponent
{
public:
    uint8_t Pad_290[0x10]; // 0x290 (Size: 0x10, Type: PaddingProperty)
    UFMDeviceCableModulatorPortComponent* InWorldKnobModulatorPort; // 0x2a0 (Size: 0x8, Type: ObjectProperty)
    bool bUseScreenGrid; // 0x2a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a9[0x7]; // 0x2a9 (Size: 0x7, Type: PaddingProperty)
    FVector2D ScreenGridPosition; // 0x2b0 (Size: 0x10, Type: StructProperty)
    FModulatorPortSaveData ModulatorPortSaveData; // 0x2c0 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_2e0[0x20]; // 0x2e0 (Size: 0x20, Type: PaddingProperty)
    UClass* CableManagerClassForModulatorPorts; // 0x300 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_308[0x8]; // 0x308 (Size: 0x8, Type: PaddingProperty)

public:
    UFMDeviceCableModulatorPortComponent* CreateModulatorPortIfNeeded(); // 0x11dfaf60 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    AFabricButtonBase* GetChildActorAsFabricButton() const; // 0x11dfb4a0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TScriptInterface<Class> GetChildActorAsFabricInteractable() const; // 0x11dfb4c4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AFMInWorldKnobActorBase* GetChildActorAsInWorldKnobActorBase() const; // 0x11dfb4f8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AActor* GetChildActorTemplateValue() const; // 0xa291bd4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetKnobOptionKey() const; // 0x11dfb8b4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    void OnModulatorPortConnected(UFMDeviceCablePortComponent*& ConnectedPort); // 0x11dfffb4 (Index: 0x6, Flags: Final|Native|Private)
    void OnModulatorPortDisconnected(UFMDeviceCablePortComponent*& DisconnectedPort); // 0x11dfffb4 (Index: 0x7, Flags: Final|Native|Private)
};

static_assert(sizeof(UFabricChildActorComponent) == 0x310, "Size mismatch for UFabricChildActorComponent");
static_assert(offsetof(UFabricChildActorComponent, InWorldKnobModulatorPort) == 0x2a0, "Offset mismatch for UFabricChildActorComponent::InWorldKnobModulatorPort");
static_assert(offsetof(UFabricChildActorComponent, bUseScreenGrid) == 0x2a8, "Offset mismatch for UFabricChildActorComponent::bUseScreenGrid");
static_assert(offsetof(UFabricChildActorComponent, ScreenGridPosition) == 0x2b0, "Offset mismatch for UFabricChildActorComponent::ScreenGridPosition");
static_assert(offsetof(UFabricChildActorComponent, ModulatorPortSaveData) == 0x2c0, "Offset mismatch for UFabricChildActorComponent::ModulatorPortSaveData");
static_assert(offsetof(UFabricChildActorComponent, CableManagerClassForModulatorPorts) == 0x300, "Offset mismatch for UFabricChildActorComponent::CableManagerClassForModulatorPorts");

// Size: 0x2e0 (Inherited: 0x320, Single: 0xffffffc0)
class UFabricScreenComponent : public USceneComponent
{
public:
    uint8_t OnWidgetCreated[0x10]; // 0x240 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnWidgetAdded[0x10]; // 0x250 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_260[0x18]; // 0x260 (Size: 0x18, Type: PaddingProperty)
    TWeakObjectPtr<UFabricScreenWidget*> ScreenWidget; // 0x278 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UWidgetComponent*> ScreenWidgetComponent; // 0x280 (Size: 0x8, Type: WeakObjectProperty)
    TMap<FScreenWidgetLayoutInfo, UFMInWorldKnobActorCopyComponent*> CopyComponentsToWidget; // 0x288 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)

public:
    FVector ConvertGridPositionToUnrealLocation(FVector2D& GridPosition) const; // 0x11dfabc4 (Index: 0x0, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector2D ConvertUnrealLocationToGridPosition(FVector& UnrealPosition) const; // 0x11dfad08 (Index: 0x1, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    int32_t GetScreenGridHeight() const; // 0x11dfbe14 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetScreenGridWidth() const; // 0xf418fc8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void Initialize(UWidgetComponent*& InScreenWidgetComponent, int32_t& InWidth, int32_t& InHeight, UFabricScreenLayoutDataAsset*& ScreenLayout); // 0x11dfc198 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SetScreenSize(int32_t& InWidth, int32_t& InHeight); // 0x11e0348c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    FVector SnapUnrealLocationToScreenGrid(FVector& UnrealPosition) const; // 0x11e03ac4 (Index: 0x7, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)

private:
    void OnCopiedKnobActorSet(UFMInWorldKnobActorCopyComponent*& CopyComponent, AFMInWorldKnobActorBase*& NewKnobActor); // 0x11dfc860 (Index: 0x5, Flags: Final|Native|Private)
};

static_assert(sizeof(UFabricScreenComponent) == 0x2e0, "Size mismatch for UFabricScreenComponent");
static_assert(offsetof(UFabricScreenComponent, OnWidgetCreated) == 0x240, "Offset mismatch for UFabricScreenComponent::OnWidgetCreated");
static_assert(offsetof(UFabricScreenComponent, OnWidgetAdded) == 0x250, "Offset mismatch for UFabricScreenComponent::OnWidgetAdded");
static_assert(offsetof(UFabricScreenComponent, ScreenWidget) == 0x278, "Offset mismatch for UFabricScreenComponent::ScreenWidget");
static_assert(offsetof(UFabricScreenComponent, ScreenWidgetComponent) == 0x280, "Offset mismatch for UFabricScreenComponent::ScreenWidgetComponent");
static_assert(offsetof(UFabricScreenComponent, CopyComponentsToWidget) == 0x288, "Offset mismatch for UFabricScreenComponent::CopyComponentsToWidget");

// Size: 0x58 (Inherited: 0x58, Single: 0x0)
class UFabricScreenLayoutDataAsset : public UDataAsset
{
public:
    TArray<FFabricScreenLayout> Layout; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FFabricWidgetLayout> AdditionalWidgetLayout; // 0x40 (Size: 0x10, Type: ArrayProperty)
    UClass* FabricScreenWidgetClass; // 0x50 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UFabricScreenLayoutDataAsset) == 0x58, "Size mismatch for UFabricScreenLayoutDataAsset");
static_assert(offsetof(UFabricScreenLayoutDataAsset, Layout) == 0x30, "Offset mismatch for UFabricScreenLayoutDataAsset::Layout");
static_assert(offsetof(UFabricScreenLayoutDataAsset, AdditionalWidgetLayout) == 0x40, "Offset mismatch for UFabricScreenLayoutDataAsset::AdditionalWidgetLayout");
static_assert(offsetof(UFabricScreenLayoutDataAsset, FabricScreenWidgetClass) == 0x50, "Offset mismatch for UFabricScreenLayoutDataAsset::FabricScreenWidgetClass");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UFabricUserOptionPresetAsset : public UDataAsset
{
public:
    FFabricUserOptionPresetCollection UserOptionPreset; // 0x30 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UFabricUserOptionPresetAsset) == 0x40, "Size mismatch for UFabricUserOptionPresetAsset");
static_assert(offsetof(UFabricUserOptionPresetAsset, UserOptionPreset) == 0x30, "Offset mismatch for UFabricUserOptionPresetAsset::UserOptionPreset");

// Size: 0x358 (Inherited: 0x350, Single: 0x8)
class UFabricUserOptionSaveModulatable : public UFabricModulatable
{
public:
};

static_assert(sizeof(UFabricUserOptionSaveModulatable) == 0x358, "Size mismatch for UFabricUserOptionSaveModulatable");

// Size: 0x220 (Inherited: 0xe0, Single: 0x140)
class UFabricUserOptionSaveComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    TArray<FString> UserOptionsToSave; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    int32_t MaxSaveSlots; // 0xd0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
    FString SaveIndexParam; // 0xd8 (Size: 0x10, Type: StrProperty)
    TArray<UFabricUserOptionPresetAsset*> PresetAssets; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    FString PresetIndexParam; // 0xf8 (Size: 0x10, Type: StrProperty)
    FString ApplyIndexImmediatelyToggleParam; // 0x108 (Size: 0x10, Type: StrProperty)
    uint8_t OnActiveOverridesChanged[0x10]; // 0x118 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    ABuildingActor* Owner; // 0x128 (Size: 0x8, Type: ObjectProperty)
    UFabricUserOptionSaveModulatable* UserOptionSaveModulatable; // 0x130 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_138[0x8]; // 0x138 (Size: 0x8, Type: PaddingProperty)
    TArray<FFabricUserOptionSaveData> Presets; // 0x140 (Size: 0x10, Type: ArrayProperty)
    TArray<FFabricUserOptionSaveData> Saves; // 0x150 (Size: 0x10, Type: ArrayProperty)
    TSet<FString> FloatUserOptions; // 0x160 (Size: 0x50, Type: SetProperty)
    int32_t ActiveSaveIndex; // 0x1b0 (Size: 0x4, Type: IntProperty)
    int32_t ActivePresetIndex; // 0x1b4 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1b8[0x68]; // 0x1b8 (Size: 0x68, Type: PaddingProperty)

public:
    FString GetOverrideForParam(FString& Param) const; // 0x11dfba94 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasOverrideForParam(FString& Param) const; // 0x11dfbe70 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsApplyingOverrides(); // 0xb4a9514 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    void OnActiveOverridesChanged__DelegateSignature(); // 0x288a61c (Index: 0x3, Flags: MulticastDelegate|Public|Delegate)
    void SetMusicClock(UMusicClockComponent*& MusicClockComponent); // 0x11e028c4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetPreset(int32_t& PresetIndex); // 0x11e0323c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void SetSaveSlot(int32_t& SaveSlotIndex); // 0x11e03364 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnAnyOptionUpdated(); // 0x11dfc84c (Index: 0x4, Flags: Final|Native|Private)
};

static_assert(sizeof(UFabricUserOptionSaveComponent) == 0x220, "Size mismatch for UFabricUserOptionSaveComponent");
static_assert(offsetof(UFabricUserOptionSaveComponent, UserOptionsToSave) == 0xc0, "Offset mismatch for UFabricUserOptionSaveComponent::UserOptionsToSave");
static_assert(offsetof(UFabricUserOptionSaveComponent, MaxSaveSlots) == 0xd0, "Offset mismatch for UFabricUserOptionSaveComponent::MaxSaveSlots");
static_assert(offsetof(UFabricUserOptionSaveComponent, SaveIndexParam) == 0xd8, "Offset mismatch for UFabricUserOptionSaveComponent::SaveIndexParam");
static_assert(offsetof(UFabricUserOptionSaveComponent, PresetAssets) == 0xe8, "Offset mismatch for UFabricUserOptionSaveComponent::PresetAssets");
static_assert(offsetof(UFabricUserOptionSaveComponent, PresetIndexParam) == 0xf8, "Offset mismatch for UFabricUserOptionSaveComponent::PresetIndexParam");
static_assert(offsetof(UFabricUserOptionSaveComponent, ApplyIndexImmediatelyToggleParam) == 0x108, "Offset mismatch for UFabricUserOptionSaveComponent::ApplyIndexImmediatelyToggleParam");
static_assert(offsetof(UFabricUserOptionSaveComponent, OnActiveOverridesChanged) == 0x118, "Offset mismatch for UFabricUserOptionSaveComponent::OnActiveOverridesChanged");
static_assert(offsetof(UFabricUserOptionSaveComponent, Owner) == 0x128, "Offset mismatch for UFabricUserOptionSaveComponent::Owner");
static_assert(offsetof(UFabricUserOptionSaveComponent, UserOptionSaveModulatable) == 0x130, "Offset mismatch for UFabricUserOptionSaveComponent::UserOptionSaveModulatable");
static_assert(offsetof(UFabricUserOptionSaveComponent, Presets) == 0x140, "Offset mismatch for UFabricUserOptionSaveComponent::Presets");
static_assert(offsetof(UFabricUserOptionSaveComponent, Saves) == 0x150, "Offset mismatch for UFabricUserOptionSaveComponent::Saves");
static_assert(offsetof(UFabricUserOptionSaveComponent, FloatUserOptions) == 0x160, "Offset mismatch for UFabricUserOptionSaveComponent::FloatUserOptions");
static_assert(offsetof(UFabricUserOptionSaveComponent, ActiveSaveIndex) == 0x1b0, "Offset mismatch for UFabricUserOptionSaveComponent::ActiveSaveIndex");
static_assert(offsetof(UFabricUserOptionSaveComponent, ActivePresetIndex) == 0x1b4, "Offset mismatch for UFabricUserOptionSaveComponent::ActivePresetIndex");

// Size: 0x198 (Inherited: 0xe0, Single: 0xb8)
class UFMInWorldCableOptionsComponent : public UActorComponent
{
public:

protected:
    void OnAnyOptionChanged(); // 0x11dfc834 (Index: 0x0, Flags: Final|Native|Protected)
    void OnFabricGlobalSystemChanged(AFabricGlobalSystem*& OldGlobalSystem, AFabricGlobalSystem*& GlobalSystem); // 0x11dfca68 (Index: 0x1, Flags: Final|Native|Protected)
    void OnInputCableConnected(UFMDeviceCablePortComponent*& SourcePort, UFMDeviceCablePortComponent*& ConnectedPort); // 0x11dfda00 (Index: 0x2, Flags: Final|Native|Protected)
    void OnInputCableDisconncted(UFMDeviceCablePortComponent*& SourcePort, UFMDeviceCablePortComponent*& DisconnectedPort); // 0x11dfdc08 (Index: 0x3, Flags: Final|Native|Protected)
    void OnOptionsLoaded(); // 0x11e000dc (Index: 0x4, Flags: Final|Native|Protected)
    void OnOutputCableConnected(UFMDeviceCablePortComponent*& SourcePort, UFMDeviceCablePortComponent*& ConnectedPort); // 0x11e000f0 (Index: 0x5, Flags: Final|Native|Protected)
    void OnOutputCableDisconncted(UFMDeviceCablePortComponent*& SourcePort, UFMDeviceCablePortComponent*& DisconnectedPort); // 0x11e002f8 (Index: 0x6, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFMInWorldCableOptionsComponent) == 0x198, "Size mismatch for UFMInWorldCableOptionsComponent");

// Size: 0x430 (Inherited: 0x370, Single: 0xc0)
class UFMInWorldDrumPlayerOptionsComponent : public UFMInWorldKnobOptionsBaseComponent
{
public:
    TMap<FFMLinkPreset, FString> SlotPropertyNameToParam; // 0x290 (Size: 0x50, Type: MapProperty)
    TArray<TWeakObjectPtr<AFMInWorldKnobActorBase*>> LinkButtonComponents; // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    TArray<TWeakObjectPtr<AFMInWorldKnobActorBase*>> SelectionSampleCarouselComponents; // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    TMap<FText, FString> ParamNameToLinkedCheckBoxWidgetText; // 0x300 (Size: 0x50, Type: MapProperty)
    TMap<FText, FString> ParamNameToSamplePropertyBoxWidgetText; // 0x350 (Size: 0x50, Type: MapProperty)
    FText LinkedCheckBoxToolTipText; // 0x3a0 (Size: 0x10, Type: TextProperty)
    FText SampleNamePropertyBoxToolTipText; // 0x3b0 (Size: 0x10, Type: TextProperty)
    TArray<FString> SlotUserOptions; // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> SlotLinkUserOptions; // 0x3d0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> SlotSampleUserOptions; // 0x3e0 (Size: 0x10, Type: ArrayProperty)
    FString MainKitParamUseroption; // 0x3f0 (Size: 0x10, Type: StrProperty)
    UFabricMetasoundDrumPlayerDataAsset* DrumPlayerBank; // 0x400 (Size: 0x8, Type: ObjectProperty)
    AFMInWorldKnobActorBase* MainKitIndexComponent; // 0x408 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_410[0x20]; // 0x410 (Size: 0x20, Type: PaddingProperty)

public:
    void AddDrumBankForCurrentKitIndeces(); // 0x11dfabb0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetDrumPlayerPatchWrapper(UFabricMetaSoundDrumPlayerPatchWrapper*& PatchWrapper); // 0x11e020a0 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnLinked1Changed(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11dfdf3c (Index: 0x1, Flags: Final|Native|Private)
    void OnLinked2Changed(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11dfe400 (Index: 0x2, Flags: Final|Native|Private)
    void OnLinked3Changed(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11dfe8c4 (Index: 0x3, Flags: Final|Native|Private)
    void OnLinked4Changed(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11dfed88 (Index: 0x4, Flags: Final|Native|Private)
    void OnLinked5Changed(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11dff24c (Index: 0x5, Flags: Final|Native|Private)
    void OnMainKitModulatedValueChanged(FString& Value, UObject*& ModulatorObject); // 0x11dff710 (Index: 0x6, Flags: Final|Native|Private)
    void OnMainKitValueChanged(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11dffaf0 (Index: 0x7, Flags: Final|Native|Private)
    void OnSelectionSample1Changed(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11e0078c (Index: 0x8, Flags: Final|Native|Private)
    void OnSelectionSample2Changed(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11e00c50 (Index: 0x9, Flags: Final|Native|Private)
    void OnSelectionSample3Changed(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11e01114 (Index: 0xa, Flags: Final|Native|Private)
    void OnSelectionSample4Changed(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11e015d8 (Index: 0xb, Flags: Final|Native|Private)
    void OnSelectionSample5Changed(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11e01a9c (Index: 0xc, Flags: Final|Native|Private)
};

static_assert(sizeof(UFMInWorldDrumPlayerOptionsComponent) == 0x430, "Size mismatch for UFMInWorldDrumPlayerOptionsComponent");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, SlotPropertyNameToParam) == 0x290, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::SlotPropertyNameToParam");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, LinkButtonComponents) == 0x2e0, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::LinkButtonComponents");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, SelectionSampleCarouselComponents) == 0x2f0, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::SelectionSampleCarouselComponents");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, ParamNameToLinkedCheckBoxWidgetText) == 0x300, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::ParamNameToLinkedCheckBoxWidgetText");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, ParamNameToSamplePropertyBoxWidgetText) == 0x350, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::ParamNameToSamplePropertyBoxWidgetText");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, LinkedCheckBoxToolTipText) == 0x3a0, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::LinkedCheckBoxToolTipText");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, SampleNamePropertyBoxToolTipText) == 0x3b0, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::SampleNamePropertyBoxToolTipText");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, SlotUserOptions) == 0x3c0, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::SlotUserOptions");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, SlotLinkUserOptions) == 0x3d0, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::SlotLinkUserOptions");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, SlotSampleUserOptions) == 0x3e0, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::SlotSampleUserOptions");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, MainKitParamUseroption) == 0x3f0, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::MainKitParamUseroption");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, DrumPlayerBank) == 0x400, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::DrumPlayerBank");
static_assert(offsetof(UFMInWorldDrumPlayerOptionsComponent, MainKitIndexComponent) == 0x408, "Offset mismatch for UFMInWorldDrumPlayerOptionsComponent::MainKitIndexComponent");

// Size: 0x290 (Inherited: 0xe0, Single: 0x1b0)
class UFMInWorldKnobOptionsBaseComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnInitialKnobValuesLoaded[0x10]; // 0xc0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnAllKnobsLoaded[0x10]; // 0xd0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnAnyKnobRuntimeValueChanged[0x10]; // 0xe0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnAnyKnobSerializedValueChanged[0x10]; // 0xf0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TSet<UObject*> InWorldKnobInterfaceObjects; // 0x100 (Size: 0x50, Type: SetProperty)
    ABuildingActor* BuildingActorOwner; // 0x150 (Size: 0x8, Type: ObjectProperty)
    UClass* OwnerClass; // 0x158 (Size: 0x8, Type: ClassProperty)
    UFabricUserOptionSaveComponent* SaveComponent; // 0x160 (Size: 0x8, Type: ObjectProperty)
    TMap<UPlaylistUserOptionBase*, FString> PropertiesEditedByUserOptions; // 0x168 (Size: 0x50, Type: MapProperty)
    TMap<UObject*, FString> OptionKeyToInWorldKnobObject; // 0x1b8 (Size: 0x50, Type: MapProperty)
    TMap<UFMDeviceCableModulatorPortComponent*, FString> OptionKeyToModulatorPort; // 0x208 (Size: 0x50, Type: MapProperty)
    TArray<UFabricModulatable*> PendingFabricModulatables; // 0x258 (Size: 0x10, Type: ArrayProperty)
    FTimerHandle ActorSaveRequestTimer; // 0x268 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_270[0x20]; // 0x270 (Size: 0x20, Type: PaddingProperty)

public:
    void OnAllKnobsLoaded__DelegateSignature(); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    void OnAnyKnobRuntimeValueChanged__DelegateSignature(); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
    void OnAnyKnobSerializedValueChanged__DelegateSignature(); // 0x288a61c (Index: 0x2, Flags: MulticastDelegate|Public|Delegate)
    void OnInitialKnobValuesLoaded__DelegateSignature(); // 0x288a61c (Index: 0x4, Flags: MulticastDelegate|Public|Delegate)

protected:
    void OnAnyOptionUpdated(); // 0x270d644 (Index: 0x3, Flags: Native|Protected)
    void OnInWorldKnobRuntimeOptionChanged(FString& Value, UPlaylistUserOptionBase*& Option); // 0x11e22864 (Index: 0x5, Flags: Native|Protected)
    void OnInWorldKnobSerializedOptionChanged(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11e2302c (Index: 0x6, Flags: Native|Protected)
    void OnOptionsLoaded(); // 0x43388fc (Index: 0x7, Flags: Native|Protected)
    void OnSaveOverridesChanged(); // 0x3abd220 (Index: 0x8, Flags: Native|Protected)
    void SetAllOptionsToCurrentOverride(bool& bSavedValuesOnly); // 0xd7b02fc (Index: 0x9, Flags: Native|Protected)
};

static_assert(sizeof(UFMInWorldKnobOptionsBaseComponent) == 0x290, "Size mismatch for UFMInWorldKnobOptionsBaseComponent");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, OnInitialKnobValuesLoaded) == 0xc0, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::OnInitialKnobValuesLoaded");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, OnAllKnobsLoaded) == 0xd0, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::OnAllKnobsLoaded");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, OnAnyKnobRuntimeValueChanged) == 0xe0, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::OnAnyKnobRuntimeValueChanged");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, OnAnyKnobSerializedValueChanged) == 0xf0, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::OnAnyKnobSerializedValueChanged");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, InWorldKnobInterfaceObjects) == 0x100, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::InWorldKnobInterfaceObjects");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, BuildingActorOwner) == 0x150, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::BuildingActorOwner");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, OwnerClass) == 0x158, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::OwnerClass");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, SaveComponent) == 0x160, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::SaveComponent");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, PropertiesEditedByUserOptions) == 0x168, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::PropertiesEditedByUserOptions");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, OptionKeyToInWorldKnobObject) == 0x1b8, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::OptionKeyToInWorldKnobObject");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, OptionKeyToModulatorPort) == 0x208, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::OptionKeyToModulatorPort");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, PendingFabricModulatables) == 0x258, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::PendingFabricModulatables");
static_assert(offsetof(UFMInWorldKnobOptionsBaseComponent, ActorSaveRequestTimer) == 0x268, "Offset mismatch for UFMInWorldKnobOptionsBaseComponent::ActorSaveRequestTimer");

// Size: 0x4c8 (Inherited: 0x2d0, Single: 0x1f8)
class AFMInWorldKnobActorBase : public AActor
{
public:
    uint8_t Pad_2a8[0x20]; // 0x2a8 (Size: 0x20, Type: PaddingProperty)
    uint8_t OnModulatedPropertyValueChanged[0x10]; // 0x2c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKnobRuntimeValueChanged[0x10]; // 0x2d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKnobSerializedValueChanged[0x10]; // 0x2e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFloatProviderConnectionChanged[0x10]; // 0x2f8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FString OptionKey; // 0x308 (Size: 0x10, Type: StrProperty)
    FText OverriddenTitle; // 0x318 (Size: 0x10, Type: TextProperty)
    FText OverriddenDescription; // 0x328 (Size: 0x10, Type: TextProperty)
    bool bCanBeModulated; // 0x338 (Size: 0x1, Type: BoolProperty)
    bool bKnobEnabled; // 0x339 (Size: 0x1, Type: BoolProperty)
    bool bKnobDisplayOnly; // 0x33a (Size: 0x1, Type: BoolProperty)
    bool bRestrictSettingNumericValues; // 0x33b (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_33c[0x4]; // 0x33c (Size: 0x4, Type: PaddingProperty)
    USceneComponent* ModulatorPortParent; // 0x340 (Size: 0x8, Type: ObjectProperty)
    UFMDeviceCableModulatorPortComponent* ModulatorPort; // 0x348 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_350[0x8]; // 0x350 (Size: 0x8, Type: PaddingProperty)
    FGameplayTagContainer GameplayTags; // 0x358 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_378[0x8]; // 0x378 (Size: 0x8, Type: PaddingProperty)
    UPlaylistUserOptionBase* MyUserOption; // 0x380 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_388[0x40]; // 0x388 (Size: 0x40, Type: PaddingProperty)
    TArray<TWeakObjectPtr<UFabricFloatProviderBase*>> CurrentFloatProviders; // 0x3c8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_3d8[0x58]; // 0x3d8 (Size: 0x58, Type: PaddingProperty)
    USceneComponent* HitComponent; // 0x430 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<APlayerController*> InteractingController; // 0x438 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t InteractableType; // 0x440 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_441[0x3]; // 0x441 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<UFabricInteractableViewModel*> WidgetViewModel; // 0x444 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_44c[0x4]; // 0x44c (Size: 0x4, Type: PaddingProperty)
    TArray<TWeakObjectPtr<UFabricButtonComponentBase*>> AttachedButtons; // 0x450 (Size: 0x10, Type: ArrayProperty)
    TArray<FText> OverrideLabels; // 0x460 (Size: 0x10, Type: ArrayProperty)
    TArray<FText> OptionLabels; // 0x470 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> OptionValues; // 0x480 (Size: 0x10, Type: ArrayProperty)
    int32_t SerializedOptionIndex; // 0x490 (Size: 0x4, Type: IntProperty)
    int32_t CurrentOptionIndex; // 0x494 (Size: 0x4, Type: IntProperty)
    FString SerializedUnrestrictedOptionValue; // 0x498 (Size: 0x10, Type: StrProperty)
    FString CurrentUnrestrictedOptionValue; // 0x4a8 (Size: 0x10, Type: StrProperty)
    float CurrentAlpha; // 0x4b8 (Size: 0x4, Type: FloatProperty)
    float AlphaAtStartOfTransition; // 0x4bc (Size: 0x4, Type: FloatProperty)
    float ClampedKnobValue; // 0x4c0 (Size: 0x4, Type: FloatProperty)
    bool bTrackingInput; // 0x4c4 (Size: 0x1, Type: BoolProperty)
    bool bIsVisibilityBound; // 0x4c5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4c6[0x2]; // 0x4c6 (Size: 0x2, Type: PaddingProperty)

public:
    void CopyAttributesFromOtherKnob(AFMInWorldKnobActorBase*& OtherKnob); // 0x11dfadf8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void EnsureProperCollision(); // 0x11dfaf84 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void FindAndChangeKnobValue(FString& Value, bool& SnapToSelection, APlayerController*& PlayerController); // 0x11dfafd4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    bool GetConsumeInteractionFromChildInteractable(APlayerController*& PlayerController) const; // 0x11dfb51c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual UClass* GetCopyClassInternal() const; // 0x4971f28 (Index: 0x5, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual UClass* GetCopyWidgetClassInternal() const; // 0x11dfb6b8 (Index: 0x6, Flags: Native|Event|Public|BlueprintEvent|Const)
    bool GetCurrentValueAsBool() const; // 0x11dfb708 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    char GetCurrentValueAsEnum() const; // 0x11dfb758 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCurrentValueAsFloat() const; // 0x11dfb77c (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetCurrentValueAsInt() const; // 0x11dfb7a4 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetCurrentValueAsName() const; // 0x11dfb7c8 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetCurrentValueAsString() const; // 0x11dfb7f4 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetCurrentValueLabel() const; // 0x11dfb834 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    APlayerController* GetInteractingController() const; // 0x11dfb888 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetOptionLabelsAndValues(TArray<FText>& OutLabels, TArray<FString>& OutValues) const; // 0x11dfb90c (Index: 0x12, Flags: Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    UFabricInteractableViewModel* GetWidgetViewModel() const; // 0x112b4468 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasActiveContinuousFloatProvider() const; // 0x11dfbe2c (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasActiveFloatProvider() const; // 0x11dfbe2c (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasEnabledFloatProvider() const; // 0x11dfbe4c (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void ReceiveOnWidgetViewModelSet(); // 0x288a61c (Index: 0x20, Flags: Event|Public|BlueprintEvent)
    void ResetToDefaultValue(APlayerController*& PlayerController); // 0x11e01f74 (Index: 0x21, Flags: Final|Native|Public|BlueprintCallable)
    void SetKnobDisplayOnly(bool& bDisplayOnly); // 0x11e02388 (Index: 0x23, Flags: Final|Native|Public|BlueprintCallable)
    void SetKnobEnabled(bool& bEnabled); // 0x11e024b4 (Index: 0x24, Flags: Final|Native|Public|BlueprintCallable)
    void SetModulatorPortCablesHidden(bool& bNewHidden); // 0x11e02794 (Index: 0x25, Flags: Final|Native|Public|BlueprintCallable)
    void SetOptionKey(FString& InOptionKey); // 0x11e02cc8 (Index: 0x27, Flags: Final|Native|Public|BlueprintCallable)
    void SetOverrideOptionLabels(const TArray<FText> Labels); // 0x11e02fc8 (Index: 0x28, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetWidgetViewModel(UFabricInteractableViewModel*& ViewModel); // 0x11e03998 (Index: 0x2b, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnFloatProviderEnabledChanged(bool& bEnabled, UFabricFloatProviderBase*& FloatProvider); // 0x11dfcc70 (Index: 0x1a, Flags: Final|Native|Private)
    void OnFloatProviderFloatUpdated(float& NewFloat, UFabricFloatProviderBase*& FloatProvider); // 0x11dfd510 (Index: 0x1b, Flags: Final|Native|Private)
    void OnFloatProviderTransitionFloatUpdated(float& NewFloat, float& BlendLerp, UFabricFloatProviderBase*& FloatProvider); // 0x11dfd71c (Index: 0x1c, Flags: Final|Native|Private)
    void OnReceiveFloatProvidersFromPort(const TArray<UFabricFloatProviderBase*> FloatProvider); // 0x11e00500 (Index: 0x1e, Flags: Final|Native|Private|HasOutParms)
    void RecalculateModulation(); // 0x11e01f60 (Index: 0x1f, Flags: Final|Native|Private)

protected:
    virtual void CopyAttributesFromOtherKnobInternal(AFMInWorldKnobActorBase*& OtherKnob); // 0xea9f274 (Index: 0x1, Flags: Native|Event|Protected|BlueprintEvent)
    int32_t GetCurrentOptionIndex() const; // 0x11dfb6f0 (Index: 0x7, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    USceneComponent* GetHitComponent() const; // 0x11dfb870 (Index: 0xf, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumberOptions() const; // 0x11dfb8f4 (Index: 0x11, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void HitComponentUpdated(USceneComponent*& NewHitComponent); // 0x288a61c (Index: 0x17, Flags: Event|Protected|BlueprintEvent)
    bool IsOverriddenByPort() const; // 0x11dfbe2c (Index: 0x18, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void KnobValueChanged(int32_t& NewIndex, bool& SnapToSelection, APlayerController*& PlayerController); // 0x11dfc550 (Index: 0x19, Flags: Final|Native|Protected|BlueprintCallable)
    void OnKnobIsVisible(bool& bInIsVisible); // 0x11dfde10 (Index: 0x1d, Flags: Final|Native|Protected)
    virtual void SetCurrentKnobPosition(float& KnobPosition); // 0xde866e0 (Index: 0x22, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void SetNumberOptions(int32_t& NumberOptions); // 0x11e02b9c (Index: 0x26, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void SetSelectedIndex(int32_t& Index, bool& SnapToSelection); // 0x11e03694 (Index: 0x29, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void SetTitle(const FText Title); // 0x11e038a0 (Index: 0x2a, Flags: Native|Event|Protected|HasOutParms|BlueprintEvent)
    virtual void StartTrackingInput(APlayerController*& PlayerController); // 0x288a61c (Index: 0x2c, Flags: Event|Protected|BlueprintEvent)
    virtual void StopTrackingInput(); // 0x288a61c (Index: 0x2d, Flags: Event|Protected|BlueprintEvent)
    virtual void UpdateDisplayOnlyVisuals(bool& bDisplayOnly); // 0x11e03bb4 (Index: 0x2e, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void UpdateEnabledVisuals(bool& bEnabled); // 0x11e03ce4 (Index: 0x2f, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void UpdateFocusVisuals(bool& bFocused); // 0x11e03e14 (Index: 0x30, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void UpdateInteractableVisuals(bool& bInteractable); // 0x11e03f44 (Index: 0x31, Flags: Native|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AFMInWorldKnobActorBase) == 0x4c8, "Size mismatch for AFMInWorldKnobActorBase");
static_assert(offsetof(AFMInWorldKnobActorBase, OnModulatedPropertyValueChanged) == 0x2c8, "Offset mismatch for AFMInWorldKnobActorBase::OnModulatedPropertyValueChanged");
static_assert(offsetof(AFMInWorldKnobActorBase, OnKnobRuntimeValueChanged) == 0x2d8, "Offset mismatch for AFMInWorldKnobActorBase::OnKnobRuntimeValueChanged");
static_assert(offsetof(AFMInWorldKnobActorBase, OnKnobSerializedValueChanged) == 0x2e8, "Offset mismatch for AFMInWorldKnobActorBase::OnKnobSerializedValueChanged");
static_assert(offsetof(AFMInWorldKnobActorBase, OnFloatProviderConnectionChanged) == 0x2f8, "Offset mismatch for AFMInWorldKnobActorBase::OnFloatProviderConnectionChanged");
static_assert(offsetof(AFMInWorldKnobActorBase, OptionKey) == 0x308, "Offset mismatch for AFMInWorldKnobActorBase::OptionKey");
static_assert(offsetof(AFMInWorldKnobActorBase, OverriddenTitle) == 0x318, "Offset mismatch for AFMInWorldKnobActorBase::OverriddenTitle");
static_assert(offsetof(AFMInWorldKnobActorBase, OverriddenDescription) == 0x328, "Offset mismatch for AFMInWorldKnobActorBase::OverriddenDescription");
static_assert(offsetof(AFMInWorldKnobActorBase, bCanBeModulated) == 0x338, "Offset mismatch for AFMInWorldKnobActorBase::bCanBeModulated");
static_assert(offsetof(AFMInWorldKnobActorBase, bKnobEnabled) == 0x339, "Offset mismatch for AFMInWorldKnobActorBase::bKnobEnabled");
static_assert(offsetof(AFMInWorldKnobActorBase, bKnobDisplayOnly) == 0x33a, "Offset mismatch for AFMInWorldKnobActorBase::bKnobDisplayOnly");
static_assert(offsetof(AFMInWorldKnobActorBase, bRestrictSettingNumericValues) == 0x33b, "Offset mismatch for AFMInWorldKnobActorBase::bRestrictSettingNumericValues");
static_assert(offsetof(AFMInWorldKnobActorBase, ModulatorPortParent) == 0x340, "Offset mismatch for AFMInWorldKnobActorBase::ModulatorPortParent");
static_assert(offsetof(AFMInWorldKnobActorBase, ModulatorPort) == 0x348, "Offset mismatch for AFMInWorldKnobActorBase::ModulatorPort");
static_assert(offsetof(AFMInWorldKnobActorBase, GameplayTags) == 0x358, "Offset mismatch for AFMInWorldKnobActorBase::GameplayTags");
static_assert(offsetof(AFMInWorldKnobActorBase, MyUserOption) == 0x380, "Offset mismatch for AFMInWorldKnobActorBase::MyUserOption");
static_assert(offsetof(AFMInWorldKnobActorBase, CurrentFloatProviders) == 0x3c8, "Offset mismatch for AFMInWorldKnobActorBase::CurrentFloatProviders");
static_assert(offsetof(AFMInWorldKnobActorBase, HitComponent) == 0x430, "Offset mismatch for AFMInWorldKnobActorBase::HitComponent");
static_assert(offsetof(AFMInWorldKnobActorBase, InteractingController) == 0x438, "Offset mismatch for AFMInWorldKnobActorBase::InteractingController");
static_assert(offsetof(AFMInWorldKnobActorBase, InteractableType) == 0x440, "Offset mismatch for AFMInWorldKnobActorBase::InteractableType");
static_assert(offsetof(AFMInWorldKnobActorBase, WidgetViewModel) == 0x444, "Offset mismatch for AFMInWorldKnobActorBase::WidgetViewModel");
static_assert(offsetof(AFMInWorldKnobActorBase, AttachedButtons) == 0x450, "Offset mismatch for AFMInWorldKnobActorBase::AttachedButtons");
static_assert(offsetof(AFMInWorldKnobActorBase, OverrideLabels) == 0x460, "Offset mismatch for AFMInWorldKnobActorBase::OverrideLabels");
static_assert(offsetof(AFMInWorldKnobActorBase, OptionLabels) == 0x470, "Offset mismatch for AFMInWorldKnobActorBase::OptionLabels");
static_assert(offsetof(AFMInWorldKnobActorBase, OptionValues) == 0x480, "Offset mismatch for AFMInWorldKnobActorBase::OptionValues");
static_assert(offsetof(AFMInWorldKnobActorBase, SerializedOptionIndex) == 0x490, "Offset mismatch for AFMInWorldKnobActorBase::SerializedOptionIndex");
static_assert(offsetof(AFMInWorldKnobActorBase, CurrentOptionIndex) == 0x494, "Offset mismatch for AFMInWorldKnobActorBase::CurrentOptionIndex");
static_assert(offsetof(AFMInWorldKnobActorBase, SerializedUnrestrictedOptionValue) == 0x498, "Offset mismatch for AFMInWorldKnobActorBase::SerializedUnrestrictedOptionValue");
static_assert(offsetof(AFMInWorldKnobActorBase, CurrentUnrestrictedOptionValue) == 0x4a8, "Offset mismatch for AFMInWorldKnobActorBase::CurrentUnrestrictedOptionValue");
static_assert(offsetof(AFMInWorldKnobActorBase, CurrentAlpha) == 0x4b8, "Offset mismatch for AFMInWorldKnobActorBase::CurrentAlpha");
static_assert(offsetof(AFMInWorldKnobActorBase, AlphaAtStartOfTransition) == 0x4bc, "Offset mismatch for AFMInWorldKnobActorBase::AlphaAtStartOfTransition");
static_assert(offsetof(AFMInWorldKnobActorBase, ClampedKnobValue) == 0x4c0, "Offset mismatch for AFMInWorldKnobActorBase::ClampedKnobValue");
static_assert(offsetof(AFMInWorldKnobActorBase, bTrackingInput) == 0x4c4, "Offset mismatch for AFMInWorldKnobActorBase::bTrackingInput");
static_assert(offsetof(AFMInWorldKnobActorBase, bIsVisibilityBound) == 0x4c5, "Offset mismatch for AFMInWorldKnobActorBase::bIsVisibilityBound");

// Size: 0x450 (Inherited: 0x8c0, Single: 0xfffffb90)
class UFMInWorldKnobActorCopyComponent : public UFabricChildActorComponent
{
public:
    uint8_t Pad_310[0x10]; // 0x310 (Size: 0x10, Type: PaddingProperty)
    uint8_t OnModulatedPropertyValueChanged[0x10]; // 0x320 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKnobRuntimeValueChanged[0x10]; // 0x330 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKnobSerializedValueChanged[0x10]; // 0x340 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFloatProviderConnectionChanged[0x10]; // 0x350 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKnobActorSet[0x10]; // 0x360 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UClass* DefaultKnobActorClass; // 0x370 (Size: 0x8, Type: ClassProperty)
    AFMInWorldKnobActorBase* InWorldKnobActor; // 0x378 (Size: 0x8, Type: ObjectProperty)
    FString OptionKey; // 0x380 (Size: 0x10, Type: StrProperty)
    FText OverriddenTitle; // 0x390 (Size: 0x10, Type: TextProperty)
    bool bCanBeModulated; // 0x3a0 (Size: 0x1, Type: BoolProperty)
    bool bKnobEnabled; // 0x3a1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3a2[0x6]; // 0x3a2 (Size: 0x6, Type: PaddingProperty)
    UPlaylistUserOptionBase* OuterUserOption; // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    FFabricUserOption OuterFabricUserOption; // 0x3b0 (Size: 0x38, Type: StructProperty)
    uint8_t Pad_3e8[0x30]; // 0x3e8 (Size: 0x30, Type: PaddingProperty)
    UPlaylistUserOptionBase* CopiedUserOption; // 0x418 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_420[0x30]; // 0x420 (Size: 0x30, Type: PaddingProperty)

public:
    void ClearCopiedInWorldKnob(); // 0x11e22208 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    FString GetCurrentKnobValueBP() const; // 0x11e2221c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetCopiedInWorldKnob(UObject*& InWorldKnobObject); // 0x11e23b5c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnInWorldKnobFloatProviderConnectionChanged(bool& bConnected, UObject*& ModulatorObject); // 0x11e22268 (Index: 0x2, Flags: Final|Native|Private)
    void OnInWorldKnobModulatedPropertyValueChanged(FString& Value, UObject*& ModulatorObject); // 0x11e22484 (Index: 0x3, Flags: Final|Native|Private)
    void OnInWorldKnobRuntimeValueChanged(FString& Value, UPlaylistUserOptionBase*& Option); // 0x11e22c4c (Index: 0x4, Flags: Final|Native|Private)
    void OnInWorldKnobSerializedValueChanged(FString& Value, UPlaylistUserOptionBase*& Option, APlayerController*& PlayerController); // 0x11e234f8 (Index: 0x5, Flags: Final|Native|Private)
};

static_assert(sizeof(UFMInWorldKnobActorCopyComponent) == 0x450, "Size mismatch for UFMInWorldKnobActorCopyComponent");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, OnModulatedPropertyValueChanged) == 0x320, "Offset mismatch for UFMInWorldKnobActorCopyComponent::OnModulatedPropertyValueChanged");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, OnKnobRuntimeValueChanged) == 0x330, "Offset mismatch for UFMInWorldKnobActorCopyComponent::OnKnobRuntimeValueChanged");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, OnKnobSerializedValueChanged) == 0x340, "Offset mismatch for UFMInWorldKnobActorCopyComponent::OnKnobSerializedValueChanged");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, OnFloatProviderConnectionChanged) == 0x350, "Offset mismatch for UFMInWorldKnobActorCopyComponent::OnFloatProviderConnectionChanged");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, OnKnobActorSet) == 0x360, "Offset mismatch for UFMInWorldKnobActorCopyComponent::OnKnobActorSet");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, DefaultKnobActorClass) == 0x370, "Offset mismatch for UFMInWorldKnobActorCopyComponent::DefaultKnobActorClass");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, InWorldKnobActor) == 0x378, "Offset mismatch for UFMInWorldKnobActorCopyComponent::InWorldKnobActor");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, OptionKey) == 0x380, "Offset mismatch for UFMInWorldKnobActorCopyComponent::OptionKey");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, OverriddenTitle) == 0x390, "Offset mismatch for UFMInWorldKnobActorCopyComponent::OverriddenTitle");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, bCanBeModulated) == 0x3a0, "Offset mismatch for UFMInWorldKnobActorCopyComponent::bCanBeModulated");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, bKnobEnabled) == 0x3a1, "Offset mismatch for UFMInWorldKnobActorCopyComponent::bKnobEnabled");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, OuterUserOption) == 0x3a8, "Offset mismatch for UFMInWorldKnobActorCopyComponent::OuterUserOption");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, OuterFabricUserOption) == 0x3b0, "Offset mismatch for UFMInWorldKnobActorCopyComponent::OuterFabricUserOption");
static_assert(offsetof(UFMInWorldKnobActorCopyComponent, CopiedUserOption) == 0x418, "Offset mismatch for UFMInWorldKnobActorCopyComponent::CopiedUserOption");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UInWorldKnobInterface : public UInterface
{
public:
};

static_assert(sizeof(UInWorldKnobInterface) == 0x28, "Size mismatch for UInWorldKnobInterface");

// Size: 0x2c0 (Inherited: 0x370, Single: 0xffffff50)
class UFMInWorldKnobOptionsComponent : public UFMInWorldKnobOptionsBaseComponent
{
public:
    TArray<UObject*> ReplicatedInWorldKnobInterfaceObjects; // 0x290 (Size: 0x10, Type: ArrayProperty)
    TArray<UObject*> ReplicatedFabricInteractableObjects; // 0x2a0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFMDeviceCableModulatorPortComponent*> ReplicatedModulatorPorts; // 0x2b0 (Size: 0x10, Type: ArrayProperty)

public:
    bool AreAllKnobsLoadedForNotify() const; // 0x54d2f28 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool CanMakeUserOptionChanges() const; // 0x11e221ac (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool OwnsInWorldKnobObject(UObject*& InWorldKnobObject) const; // 0x11e239f8 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    void OnRep_ReplicatedFabricInteractableObjects(); // 0x11e239bc (Index: 0x3, Flags: Final|Native|Private)
    void OnRep_ReplicatedInWorldKnobInterfaceObjects(); // 0x11e239d0 (Index: 0x4, Flags: Final|Native|Private)
    void OnRep_ReplicatedModulatorPorts(); // 0x11e239e4 (Index: 0x5, Flags: Final|Native|Private)

protected:
    virtual bool ActorHasValidControllerBP(AActor*& Actor, AFortPlayerPawn*& OutFortPlayerPawn, APlayerController*& OutPlayerController); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFMInWorldKnobOptionsComponent) == 0x2c0, "Size mismatch for UFMInWorldKnobOptionsComponent");
static_assert(offsetof(UFMInWorldKnobOptionsComponent, ReplicatedInWorldKnobInterfaceObjects) == 0x290, "Offset mismatch for UFMInWorldKnobOptionsComponent::ReplicatedInWorldKnobInterfaceObjects");
static_assert(offsetof(UFMInWorldKnobOptionsComponent, ReplicatedFabricInteractableObjects) == 0x2a0, "Offset mismatch for UFMInWorldKnobOptionsComponent::ReplicatedFabricInteractableObjects");
static_assert(offsetof(UFMInWorldKnobOptionsComponent, ReplicatedModulatorPorts) == 0x2b0, "Offset mismatch for UFMInWorldKnobOptionsComponent::ReplicatedModulatorPorts");

// Size: 0x1d0 (Inherited: 0x210, Single: 0xffffffc0)
class UPlaylistUserOptionFMLinkPreset : public UPlaylistUserOptionBase
{
public:
    FFMLinkPreset DefaultValue; // 0x1b8 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_1cc[0x4]; // 0x1cc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UPlaylistUserOptionFMLinkPreset) == 0x1d0, "Size mismatch for UPlaylistUserOptionFMLinkPreset");
static_assert(offsetof(UPlaylistUserOptionFMLinkPreset, DefaultValue) == 0x1b8, "Offset mismatch for UPlaylistUserOptionFMLinkPreset::DefaultValue");

// Size: 0x208 (Inherited: 0x210, Single: 0xfffffff8)
class UPlaylistUserOptionFMOutgoingCableConnection : public UPlaylistUserOptionBase
{
public:
    FFMOutgoingCableConnection DefaultValue; // 0x1b8 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(UPlaylistUserOptionFMOutgoingCableConnection) == 0x208, "Size mismatch for UPlaylistUserOptionFMOutgoingCableConnection");
static_assert(offsetof(UPlaylistUserOptionFMOutgoingCableConnection, DefaultValue) == 0x1b8, "Offset mismatch for UPlaylistUserOptionFMOutgoingCableConnection::DefaultValue");

// Size: 0x208 (Inherited: 0x210, Single: 0xfffffff8)
class UPlaylistUserOptionFMIncomingCableConnection : public UPlaylistUserOptionBase
{
public:
    FFMIncomingCableConnection DefaultValue; // 0x1b8 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(UPlaylistUserOptionFMIncomingCableConnection) == 0x208, "Size mismatch for UPlaylistUserOptionFMIncomingCableConnection");
static_assert(offsetof(UPlaylistUserOptionFMIncomingCableConnection, DefaultValue) == 0x1b8, "Offset mismatch for UPlaylistUserOptionFMIncomingCableConnection::DefaultValue");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFabricUserOptionSaveData
{
    TArray<FFabricUserOptionSavedValue> SavedUserOptions; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFabricUserOptionSaveData) == 0x10, "Size mismatch for FFabricUserOptionSaveData");
static_assert(offsetof(FFabricUserOptionSaveData, SavedUserOptions) == 0x0, "Offset mismatch for FFabricUserOptionSaveData::SavedUserOptions");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFabricUserOptionSavedValue
{
    FString Key; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FFabricUserOptionSavedValue) == 0x20, "Size mismatch for FFabricUserOptionSavedValue");
static_assert(offsetof(FFabricUserOptionSavedValue, Key) == 0x0, "Offset mismatch for FFabricUserOptionSavedValue::Key");
static_assert(offsetof(FFabricUserOptionSavedValue, Value) == 0x10, "Offset mismatch for FFabricUserOptionSavedValue::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FScreenMeshArray
{
    TArray<TSoftObjectPtr<UStaticMesh*>> ScreenMeshArrayByHeight; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FScreenMeshArray) == 0x10, "Size mismatch for FScreenMeshArray");
static_assert(offsetof(FScreenMeshArray, ScreenMeshArrayByHeight) == 0x0, "Offset mismatch for FScreenMeshArray::ScreenMeshArrayByHeight");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FScreenWidgetLayoutInfo
{
};

static_assert(sizeof(FScreenWidgetLayoutInfo) == 0x18, "Size mismatch for FScreenWidgetLayoutInfo");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFabricWidgetLayout
{
    FVector2D GridPosition; // 0x0 (Size: 0x10, Type: StructProperty)
    UClass* FabricWidgetClass; // 0x10 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FFabricWidgetLayout) == 0x18, "Size mismatch for FFabricWidgetLayout");
static_assert(offsetof(FFabricWidgetLayout, GridPosition) == 0x0, "Offset mismatch for FFabricWidgetLayout::GridPosition");
static_assert(offsetof(FFabricWidgetLayout, FabricWidgetClass) == 0x10, "Offset mismatch for FFabricWidgetLayout::FabricWidgetClass");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FFabricScreenLayout : FFabricWidgetLayout
{
    FName UserOptionName; // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFabricScreenLayout) == 0x20, "Size mismatch for FFabricScreenLayout");
static_assert(offsetof(FFabricScreenLayout, UserOptionName) == 0x18, "Offset mismatch for FFabricScreenLayout::UserOptionName");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFabricUserOptionValue
{
};

static_assert(sizeof(FFabricUserOptionValue) == 0x8, "Size mismatch for FFabricUserOptionValue");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FFabricUserOptionValueInt : FFabricUserOptionValue
{
    int32_t Value; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFabricUserOptionValueInt) == 0x10, "Size mismatch for FFabricUserOptionValueInt");
static_assert(offsetof(FFabricUserOptionValueInt, Value) == 0x8, "Offset mismatch for FFabricUserOptionValueInt::Value");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FFabricUserOptionValueFloat : FFabricUserOptionValue
{
    float Value; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFabricUserOptionValueFloat) == 0x10, "Size mismatch for FFabricUserOptionValueFloat");
static_assert(offsetof(FFabricUserOptionValueFloat, Value) == 0x8, "Offset mismatch for FFabricUserOptionValueFloat::Value");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FFabricUserOptionValueEnum : FFabricUserOptionValue
{
    FString Value; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FFabricUserOptionValueEnum) == 0x18, "Size mismatch for FFabricUserOptionValueEnum");
static_assert(offsetof(FFabricUserOptionValueEnum, Value) == 0x8, "Offset mismatch for FFabricUserOptionValueEnum::Value");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FFabricUserOptionValueBool : FFabricUserOptionValue
{
    bool Value; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFabricUserOptionValueBool) == 0x10, "Size mismatch for FFabricUserOptionValueBool");
static_assert(offsetof(FFabricUserOptionValueBool, Value) == 0x8, "Offset mismatch for FFabricUserOptionValueBool::Value");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FFabricUserOptionValueString : FFabricUserOptionValue
{
    FString Value; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FFabricUserOptionValueString) == 0x18, "Size mismatch for FFabricUserOptionValueString");
static_assert(offsetof(FFabricUserOptionValueString, Value) == 0x8, "Offset mismatch for FFabricUserOptionValueString::Value");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFabricUserOptionPreset
{
    FString UserOption; // 0x0 (Size: 0x10, Type: StrProperty)
    FInstancedStruct UserOptionValue; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FFabricUserOptionPreset) == 0x20, "Size mismatch for FFabricUserOptionPreset");
static_assert(offsetof(FFabricUserOptionPreset, UserOption) == 0x0, "Offset mismatch for FFabricUserOptionPreset::UserOption");
static_assert(offsetof(FFabricUserOptionPreset, UserOptionValue) == 0x10, "Offset mismatch for FFabricUserOptionPreset::UserOptionValue");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFabricUserOptionPresetCollection
{
    TArray<FFabricUserOptionPreset> UserOptionPresets; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFabricUserOptionPresetCollection) == 0x10, "Size mismatch for FFabricUserOptionPresetCollection");
static_assert(offsetof(FFabricUserOptionPresetCollection, UserOptionPresets) == 0x0, "Offset mismatch for FFabricUserOptionPresetCollection::UserOptionPresets");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FFloatProviderState
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t Weight; // 0x4 (Size: 0x4, Type: IntProperty)
    float LastValue; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFloatProviderState) == 0xc, "Size mismatch for FFloatProviderState");
static_assert(offsetof(FFloatProviderState, bEnabled) == 0x0, "Offset mismatch for FFloatProviderState::bEnabled");
static_assert(offsetof(FFloatProviderState, Weight) == 0x4, "Offset mismatch for FFloatProviderState::Weight");
static_assert(offsetof(FFloatProviderState, LastValue) == 0x8, "Offset mismatch for FFloatProviderState::LastValue");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FFMLinkPreset
{
    bool bIsLinked; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FName SelectionSampleIndexName; // 0x4 (Size: 0x4, Type: NameProperty)
    int32_t UnlinkedSelectionSampleIndex; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t UnlinkedKitIndex; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t MainKitIndex; // 0x10 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FFMLinkPreset) == 0x14, "Size mismatch for FFMLinkPreset");
static_assert(offsetof(FFMLinkPreset, bIsLinked) == 0x0, "Offset mismatch for FFMLinkPreset::bIsLinked");
static_assert(offsetof(FFMLinkPreset, SelectionSampleIndexName) == 0x4, "Offset mismatch for FFMLinkPreset::SelectionSampleIndexName");
static_assert(offsetof(FFMLinkPreset, UnlinkedSelectionSampleIndex) == 0x8, "Offset mismatch for FFMLinkPreset::UnlinkedSelectionSampleIndex");
static_assert(offsetof(FFMLinkPreset, UnlinkedKitIndex) == 0xc, "Offset mismatch for FFMLinkPreset::UnlinkedKitIndex");
static_assert(offsetof(FFMLinkPreset, MainKitIndex) == 0x10, "Offset mismatch for FFMLinkPreset::MainKitIndex");

// Size: 0x20 (Inherited: 0x8, Single: 0x18)
struct FUserOptionDefinitionFMLinkPresetMetaData : FUserOptionDefinitionMetaData
{
    FFMLinkPreset DefaultValue; // 0x8 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FUserOptionDefinitionFMLinkPresetMetaData) == 0x20, "Size mismatch for FUserOptionDefinitionFMLinkPresetMetaData");
static_assert(offsetof(FUserOptionDefinitionFMLinkPresetMetaData, DefaultValue) == 0x8, "Offset mismatch for FUserOptionDefinitionFMLinkPresetMetaData::DefaultValue");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFMCableAdditionalConnection
{
    FName OutputPortName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UObject*> Device; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FFMCableAdditionalConnection) == 0x28, "Size mismatch for FFMCableAdditionalConnection");
static_assert(offsetof(FFMCableAdditionalConnection, OutputPortName) == 0x0, "Offset mismatch for FFMCableAdditionalConnection::OutputPortName");
static_assert(offsetof(FFMCableAdditionalConnection, Device) == 0x8, "Offset mismatch for FFMCableAdditionalConnection::Device");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FFMCableConnection
{
    FName OutputPortName; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UObject*> Device; // 0x10 (Size: 0x20, Type: SoftObjectProperty)
    FName ComponentName; // 0x30 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    TArray<FFMCableAdditionalConnection> InputConnections; // 0x38 (Size: 0x10, Type: ArrayProperty)
    uint8_t PortDirectionType; // 0x48 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFMCableConnection) == 0x50, "Size mismatch for FFMCableConnection");
static_assert(offsetof(FFMCableConnection, OutputPortName) == 0x8, "Offset mismatch for FFMCableConnection::OutputPortName");
static_assert(offsetof(FFMCableConnection, Device) == 0x10, "Offset mismatch for FFMCableConnection::Device");
static_assert(offsetof(FFMCableConnection, ComponentName) == 0x30, "Offset mismatch for FFMCableConnection::ComponentName");
static_assert(offsetof(FFMCableConnection, InputConnections) == 0x38, "Offset mismatch for FFMCableConnection::InputConnections");
static_assert(offsetof(FFMCableConnection, PortDirectionType) == 0x48, "Offset mismatch for FFMCableConnection::PortDirectionType");

// Size: 0x50 (Inherited: 0x50, Single: 0x0)
struct FFMOutgoingCableConnection : FFMCableConnection
{
};

static_assert(sizeof(FFMOutgoingCableConnection) == 0x50, "Size mismatch for FFMOutgoingCableConnection");

// Size: 0x50 (Inherited: 0x50, Single: 0x0)
struct FFMIncomingCableConnection : FFMCableConnection
{
};

static_assert(sizeof(FFMIncomingCableConnection) == 0x50, "Size mismatch for FFMIncomingCableConnection");

// Size: 0x58 (Inherited: 0x8, Single: 0x50)
struct FUserOptionDefinitionFMOutgoingConnectionMetaData : FUserOptionDefinitionMetaData
{
    FFMOutgoingCableConnection DefaultValue; // 0x8 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FUserOptionDefinitionFMOutgoingConnectionMetaData) == 0x58, "Size mismatch for FUserOptionDefinitionFMOutgoingConnectionMetaData");
static_assert(offsetof(FUserOptionDefinitionFMOutgoingConnectionMetaData, DefaultValue) == 0x8, "Offset mismatch for FUserOptionDefinitionFMOutgoingConnectionMetaData::DefaultValue");

// Size: 0x58 (Inherited: 0x8, Single: 0x50)
struct FUserOptionDefinitionFMIncomingConnectionMetaData : FUserOptionDefinitionMetaData
{
    FFMIncomingCableConnection DefaultValue; // 0x8 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FUserOptionDefinitionFMIncomingConnectionMetaData) == 0x58, "Size mismatch for FUserOptionDefinitionFMIncomingConnectionMetaData");
static_assert(offsetof(FUserOptionDefinitionFMIncomingConnectionMetaData, DefaultValue) == 0x8, "Offset mismatch for FUserOptionDefinitionFMIncomingConnectionMetaData::DefaultValue");

