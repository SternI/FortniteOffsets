/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeVideoPlayerRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "MediaAssets.h"
#include "GameplayAbilities.h"
#include "UMG.h"

// Size: 0xbb8 (Inherited: 0xf08, Single: 0xfffffcb0)
class UCreativeVideoPlayerFullscreenGameplayAbility : public UFortGameplayAbility
{
public:
    UClass* NoCollisionGameplayEffectClass; // 0xb38 (Size: 0x8, Type: ClassProperty)
    UClass* NoDamageGameplayEffectClass; // 0xb40 (Size: 0x8, Type: ClassProperty)
    TArray<UClass*> AnimationStateGameplayEffectClasses; // 0xb48 (Size: 0x10, Type: ArrayProperty)
    UClass* FullscreenWidgetClass; // 0xb58 (Size: 0x8, Type: ClassProperty)
    uint8_t FullscreenEffects; // 0xb60 (Size: 0x1, Type: EnumProperty)
    bool bPromptToConfirmFullscreen; // 0xb61 (Size: 0x1, Type: BoolProperty)
    bool bIsDismissable; // 0xb62 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b63[0x5]; // 0xb63 (Size: 0x5, Type: PaddingProperty)
    UFortInputComponent* OverrideMovementInputComponent; // 0xb68 (Size: 0x8, Type: ObjectProperty)
    UFortInputComponent* SelectFullscreenModeInputComponent; // 0xb70 (Size: 0x8, Type: ObjectProperty)
    TArray<FActiveGameplayEffectHandle> ActiveGameplayEffects; // 0xb78 (Size: 0x10, Type: ArrayProperty)
    uint8_t RequestedFullscreenEffects; // 0xb88 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_b89[0x7]; // 0xb89 (Size: 0x7, Type: PaddingProperty)
    UUserWidget* VideoPlayerWidget; // 0xb90 (Size: 0x8, Type: ObjectProperty)
    UMediaTexture* ExtMediaTextureCached; // 0xb98 (Size: 0x8, Type: ObjectProperty)
    USoundSourceBus* ExtSourceBusCached; // 0xba0 (Size: 0x8, Type: ObjectProperty)
    UMediaSoundComponent* ExtMediaSoundComponentCached; // 0xba8 (Size: 0x8, Type: ObjectProperty)
    bool bExtComponentsSet; // 0xbb0 (Size: 0x1, Type: BoolProperty)
    bool bActivatedFullscreen; // 0xbb1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_bb2[0x6]; // 0xbb2 (Size: 0x6, Type: PaddingProperty)

public:
    void EnterFullscreenState(); // 0x11a93088 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void EnterFullscreenStateWithOptions(FCreativeVideoPlayerFullscreenOptions& Options); // 0x11a930b4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void ExitFullscreenState(); // 0x11a93178 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SetExternalComponents(UMediaTexture*& ExtMediaTexture, USoundSourceBus*& ExtSourceBus, UMediaSoundComponent*& ExtMediaSoundComponent); // 0x11a931cc (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)

private:
    virtual void ClientLeaveFullscreenVideo(); // 0x4e31194 (Index: 0x0, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    virtual void ClientTransitionToFullscreenVideo(); // 0xc018c0c (Index: 0x1, Flags: Final|Net|NetReliableNative|Event|Private|NetClient)
    void HandleEnterFullscreenActionPressed(); // 0x554e3c4 (Index: 0x5, Flags: Final|Native|Private)
    void HandleEnterFullscreenActionReleased(); // 0x11a931a4 (Index: 0x6, Flags: Final|Native|Private)
    void OnFullscreenUIEnds(); // 0x11a931b8 (Index: 0x7, Flags: Final|Native|Private)
    virtual void ServerEnterFullscreenMode(); // 0xcd5526c (Index: 0x8, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
    virtual void ServerLeaveFullscreenMode(); // 0xc018c24 (Index: 0x9, Flags: Final|Net|NetReliableNative|Event|Private|NetServer)
};

static_assert(sizeof(UCreativeVideoPlayerFullscreenGameplayAbility) == 0xbb8, "Size mismatch for UCreativeVideoPlayerFullscreenGameplayAbility");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, NoCollisionGameplayEffectClass) == 0xb38, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::NoCollisionGameplayEffectClass");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, NoDamageGameplayEffectClass) == 0xb40, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::NoDamageGameplayEffectClass");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, AnimationStateGameplayEffectClasses) == 0xb48, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::AnimationStateGameplayEffectClasses");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, FullscreenWidgetClass) == 0xb58, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::FullscreenWidgetClass");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, FullscreenEffects) == 0xb60, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::FullscreenEffects");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, bPromptToConfirmFullscreen) == 0xb61, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::bPromptToConfirmFullscreen");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, bIsDismissable) == 0xb62, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::bIsDismissable");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, OverrideMovementInputComponent) == 0xb68, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::OverrideMovementInputComponent");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, SelectFullscreenModeInputComponent) == 0xb70, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::SelectFullscreenModeInputComponent");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, ActiveGameplayEffects) == 0xb78, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::ActiveGameplayEffects");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, RequestedFullscreenEffects) == 0xb88, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::RequestedFullscreenEffects");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, VideoPlayerWidget) == 0xb90, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::VideoPlayerWidget");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, ExtMediaTextureCached) == 0xb98, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::ExtMediaTextureCached");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, ExtSourceBusCached) == 0xba0, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::ExtSourceBusCached");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, ExtMediaSoundComponentCached) == 0xba8, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::ExtMediaSoundComponentCached");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, bExtComponentsSet) == 0xbb0, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::bExtComponentsSet");
static_assert(offsetof(UCreativeVideoPlayerFullscreenGameplayAbility, bActivatedFullscreen) == 0xbb1, "Offset mismatch for UCreativeVideoPlayerFullscreenGameplayAbility::bActivatedFullscreen");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCreativeVideoPlayerFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void ShutdownFullscreenVideoMode(AController*& Controller); // 0x11a934b0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UCreativeVideoPlayerFunctionLibrary) == 0x28, "Size mismatch for UCreativeVideoPlayerFunctionLibrary");

// Size: 0x40 (Inherited: 0x88, Single: 0xffffffb8)
class UCreativeVideoPlayerWorldSubsystem : public UWorldSubsystem
{
public:
    uint8_t OnNotifyFullscreenChange[0x10]; // 0x30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
};

static_assert(sizeof(UCreativeVideoPlayerWorldSubsystem) == 0x40, "Size mismatch for UCreativeVideoPlayerWorldSubsystem");
static_assert(offsetof(UCreativeVideoPlayerWorldSubsystem, OnNotifyFullscreenChange) == 0x30, "Offset mismatch for UCreativeVideoPlayerWorldSubsystem::OnNotifyFullscreenChange");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FCreativeVideoPlayerFullscreenOptions
{
    uint8_t GameplayEffects; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bPromptFirst; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FCreativeVideoPlayerFullscreenOptions) == 0x2, "Size mismatch for FCreativeVideoPlayerFullscreenOptions");
static_assert(offsetof(FCreativeVideoPlayerFullscreenOptions, GameplayEffects) == 0x0, "Offset mismatch for FCreativeVideoPlayerFullscreenOptions::GameplayEffects");
static_assert(offsetof(FCreativeVideoPlayerFullscreenOptions, bPromptFirst) == 0x1, "Offset mismatch for FCreativeVideoPlayerFullscreenOptions::bPromptFirst");

