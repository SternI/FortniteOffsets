/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserTile_Homebar_NEW_VM
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DiscoveryBrowserUI.h"
#include "FortniteUI.h"
#include "Engine.h"

// Size: 0x1578 (Inherited: 0x4630, Single: 0xffffcf48)
class UActivityBrowserTile_Homebar_NEW_VM_C : public UFortActivityBrowserTile
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x1560 (Size: 0x8, Type: StructProperty)
    uint8_t BroadcastClickToRow[0x10]; // 0x1568 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    virtual void SetNestedButtonGroupSelectionVM(UFortNestedButtonGroupSelectionVM*& const InVM); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    virtual UFortNestedButtonGroupSelectionVM* GetNestedButtonGroupSelectionVM() const; // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void BroadcastClickToRow__DelegateSignature(); // 0x288a61c (Index: 0x3, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)

protected:
    virtual void BP_OnEntryReleased(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UActivityBrowserTile_Homebar_NEW_VM_C) == 0x1578, "Size mismatch for UActivityBrowserTile_Homebar_NEW_VM_C");
static_assert(offsetof(UActivityBrowserTile_Homebar_NEW_VM_C, UberGraphFrame) == 0x1560, "Offset mismatch for UActivityBrowserTile_Homebar_NEW_VM_C::UberGraphFrame");
static_assert(offsetof(UActivityBrowserTile_Homebar_NEW_VM_C, BroadcastClickToRow) == 0x1568, "Offset mismatch for UActivityBrowserTile_Homebar_NEW_VM_C::BroadcastClickToRow");

