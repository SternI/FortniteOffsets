/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DanceVolume
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "FortniteGame.h"

// Size: 0xf0 (Inherited: 0xe0, Single: 0x10)
class UDanceSynchronizerComponent : public UActorComponent
{
public:
    uint8_t bShouldHalfOrDoubleTimeDances : 1; // 0xb8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x3]; // 0xb9 (Size: 0x3, Type: PaddingProperty)
    FDanceBeatInfo BeatInfo; // 0xbc (Size: 0x8, Type: StructProperty)
    uint8_t SyncMode; // 0xc4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c5[0x3]; // 0xc5 (Size: 0x3, Type: PaddingProperty)
    float Tempo; // 0xc8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)
    AFortPlayerPawn* OwnerPlayerPawn; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* OwnerMeshComponent; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* LeaderMeshComponent; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_e8[0x8]; // 0xe8 (Size: 0x8, Type: PaddingProperty)

public:
    float CalculateDanceMontagePlayRate(float& const CurrentTempo, UAnimMontage*& const Montage, const FDanceBeatInfo DanceBeatInfo); // 0x11aa2698 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    AFortPlayerPawn* GetOwnerFortPlayerPawn(); // 0xdc2db3c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    USkeletalMeshComponent* GetOwnerSkeletalMeshComponent(); // 0xa7461d8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    bool IsTempoSyncEnabled(); // 0x11aa2c5c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    void SetBeatSyncMode(EDanceBeatSyncMode& NewMode); // 0x11aa2cfc (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetDanceBeatInfo(const FDanceBeatInfo NewDanceBeatInfo); // 0x11aa2e2c (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetTempo(float& NewTempo); // 0x11aa2f04 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void StopOwnerEmoteAudio(); // 0x11aa3038 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnRep_SyncMode(); // 0x11aa2c78 (Index: 0x4, Flags: Final|Native|Private)
};

static_assert(sizeof(UDanceSynchronizerComponent) == 0xf0, "Size mismatch for UDanceSynchronizerComponent");
static_assert(offsetof(UDanceSynchronizerComponent, bShouldHalfOrDoubleTimeDances) == 0xb8, "Offset mismatch for UDanceSynchronizerComponent::bShouldHalfOrDoubleTimeDances");
static_assert(offsetof(UDanceSynchronizerComponent, BeatInfo) == 0xbc, "Offset mismatch for UDanceSynchronizerComponent::BeatInfo");
static_assert(offsetof(UDanceSynchronizerComponent, SyncMode) == 0xc4, "Offset mismatch for UDanceSynchronizerComponent::SyncMode");
static_assert(offsetof(UDanceSynchronizerComponent, Tempo) == 0xc8, "Offset mismatch for UDanceSynchronizerComponent::Tempo");
static_assert(offsetof(UDanceSynchronizerComponent, OwnerPlayerPawn) == 0xd0, "Offset mismatch for UDanceSynchronizerComponent::OwnerPlayerPawn");
static_assert(offsetof(UDanceSynchronizerComponent, OwnerMeshComponent) == 0xd8, "Offset mismatch for UDanceSynchronizerComponent::OwnerMeshComponent");
static_assert(offsetof(UDanceSynchronizerComponent, LeaderMeshComponent) == 0xe0, "Offset mismatch for UDanceSynchronizerComponent::LeaderMeshComponent");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDanceVolumeLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void ForceStopMontage(AFortPawn*& const FortPawn); // 0x11aa298c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UFortItemDefinition* GetLastEmoteExecuted(AController*& Controller); // 0x11aa2af0 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UDanceVolumeLibrary) == 0x28, "Size mismatch for UDanceVolumeLibrary");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDanceBeatInfo
{
    float LengthBeats; // 0x0 (Size: 0x4, Type: FloatProperty)
    float StartOffsetMs; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDanceBeatInfo) == 0x8, "Size mismatch for FDanceBeatInfo");
static_assert(offsetof(FDanceBeatInfo, LengthBeats) == 0x0, "Offset mismatch for FDanceBeatInfo::LengthBeats");
static_assert(offsetof(FDanceBeatInfo, StartOffsetMs) == 0x4, "Offset mismatch for FDanceBeatInfo::StartOffsetMs");

