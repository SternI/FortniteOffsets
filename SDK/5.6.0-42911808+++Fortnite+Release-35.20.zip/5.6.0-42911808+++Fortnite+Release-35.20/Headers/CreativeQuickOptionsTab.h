/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeQuickOptionsTab
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUI.h"
#include "FortniteUI.h"

// Size: 0x580 (Inherited: 0xb38, Single: 0xfffffa48)
class UFortCreativeQuickOptionsTab : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x30]; // 0x408 (Size: 0x30, Type: PaddingProperty)
    FAthenaMapScreenContainerTabInfo MapScreenContainerTabInfo; // 0x438 (Size: 0x40, Type: StructProperty)
    FName QuickOptionsTabNameId; // 0x478 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_47c[0x4]; // 0x47c (Size: 0x4, Type: PaddingProperty)
    FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x480 (Size: 0xf0, Type: StructProperty)
    bool bIsDefaultActiveTab; // 0x570 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_571[0xf]; // 0x571 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(UFortCreativeQuickOptionsTab) == 0x580, "Size mismatch for UFortCreativeQuickOptionsTab");
static_assert(offsetof(UFortCreativeQuickOptionsTab, MapScreenContainerTabInfo) == 0x438, "Offset mismatch for UFortCreativeQuickOptionsTab::MapScreenContainerTabInfo");
static_assert(offsetof(UFortCreativeQuickOptionsTab, QuickOptionsTabNameId) == 0x478, "Offset mismatch for UFortCreativeQuickOptionsTab::QuickOptionsTabNameId");
static_assert(offsetof(UFortCreativeQuickOptionsTab, TabButtonLabelInfo) == 0x480, "Offset mismatch for UFortCreativeQuickOptionsTab::TabButtonLabelInfo");
static_assert(offsetof(UFortCreativeQuickOptionsTab, bIsDefaultActiveTab) == 0x570, "Offset mismatch for UFortCreativeQuickOptionsTab::bIsDefaultActiveTab");

