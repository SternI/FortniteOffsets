/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarSettingsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UFortGameSettingRegistryExtension_DelMar : public UFortGameSettingRegistryExtension
{
public:
};

static_assert(sizeof(UFortGameSettingRegistryExtension_DelMar) == 0x30, "Size mismatch for UFortGameSettingRegistryExtension_DelMar");

