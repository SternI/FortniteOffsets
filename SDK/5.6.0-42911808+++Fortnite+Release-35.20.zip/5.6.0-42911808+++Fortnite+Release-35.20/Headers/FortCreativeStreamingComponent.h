/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortCreativeStreamingComponent
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "SubtitlesWidgets.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "MetasoundEngine.h"
#include "HarmonixMidi.h"
#include "HarmonixMetasound.h"
#include "MediaAssets.h"

// Size: 0x160 (Inherited: 0xe0, Single: 0x80)
class UFortCreativeStreamingMusicalReactivityComponent : public UActorComponent
{
public:
    FComponentReference AudioComponentRef; // 0xb8 (Size: 0x28, Type: StructProperty)
    FComponentReference MusicClockComponentRef; // 0xe0 (Size: 0x28, Type: StructProperty)
    UMetaSoundSource* MetaSoundSource; // 0x108 (Size: 0x8, Type: ObjectProperty)
    FName MetaSoundParamNameMediaPlayer; // 0x110 (Size: 0x4, Type: NameProperty)
    FName MetaSoundParamNameMidiFile; // 0x114 (Size: 0x4, Type: NameProperty)
    UMidiFile* TempoMapMidiFile; // 0x118 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag MusicEventSubsystemEventTag; // 0x120 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_124[0x4]; // 0x124 (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer MusicEventSubsystemBehaviorTags; // 0x128 (Size: 0x20, Type: StructProperty)
    TWeakObjectPtr<UAudioComponent*> AudioComponent; // 0x148 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMusicClockComponent*> MusicClockComponent; // 0x150 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortCreativeStreamingComponent*> StreamingComponent; // 0x158 (Size: 0x8, Type: WeakObjectProperty)

private:
    void ConnectToStreamingComponent() const; // 0x11e94cb8 (Index: 0x0, Flags: Final|Native|Private|Const)
    void HandleStreamingEnd(); // 0x11e95308 (Index: 0x1, Flags: Final|Native|Private)
    void HandleStreamingStart(FString& OpenedUrl); // 0x11e9531c (Index: 0x2, Flags: Final|Native|Private)
    void OnStreamingComponentTornDown() const; // 0x11e95f38 (Index: 0x3, Flags: Final|Native|Private|Const)
};

static_assert(sizeof(UFortCreativeStreamingMusicalReactivityComponent) == 0x160, "Size mismatch for UFortCreativeStreamingMusicalReactivityComponent");
static_assert(offsetof(UFortCreativeStreamingMusicalReactivityComponent, AudioComponentRef) == 0xb8, "Offset mismatch for UFortCreativeStreamingMusicalReactivityComponent::AudioComponentRef");
static_assert(offsetof(UFortCreativeStreamingMusicalReactivityComponent, MusicClockComponentRef) == 0xe0, "Offset mismatch for UFortCreativeStreamingMusicalReactivityComponent::MusicClockComponentRef");
static_assert(offsetof(UFortCreativeStreamingMusicalReactivityComponent, MetaSoundSource) == 0x108, "Offset mismatch for UFortCreativeStreamingMusicalReactivityComponent::MetaSoundSource");
static_assert(offsetof(UFortCreativeStreamingMusicalReactivityComponent, MetaSoundParamNameMediaPlayer) == 0x110, "Offset mismatch for UFortCreativeStreamingMusicalReactivityComponent::MetaSoundParamNameMediaPlayer");
static_assert(offsetof(UFortCreativeStreamingMusicalReactivityComponent, MetaSoundParamNameMidiFile) == 0x114, "Offset mismatch for UFortCreativeStreamingMusicalReactivityComponent::MetaSoundParamNameMidiFile");
static_assert(offsetof(UFortCreativeStreamingMusicalReactivityComponent, TempoMapMidiFile) == 0x118, "Offset mismatch for UFortCreativeStreamingMusicalReactivityComponent::TempoMapMidiFile");
static_assert(offsetof(UFortCreativeStreamingMusicalReactivityComponent, MusicEventSubsystemEventTag) == 0x120, "Offset mismatch for UFortCreativeStreamingMusicalReactivityComponent::MusicEventSubsystemEventTag");
static_assert(offsetof(UFortCreativeStreamingMusicalReactivityComponent, MusicEventSubsystemBehaviorTags) == 0x128, "Offset mismatch for UFortCreativeStreamingMusicalReactivityComponent::MusicEventSubsystemBehaviorTags");
static_assert(offsetof(UFortCreativeStreamingMusicalReactivityComponent, AudioComponent) == 0x148, "Offset mismatch for UFortCreativeStreamingMusicalReactivityComponent::AudioComponent");
static_assert(offsetof(UFortCreativeStreamingMusicalReactivityComponent, MusicClockComponent) == 0x150, "Offset mismatch for UFortCreativeStreamingMusicalReactivityComponent::MusicClockComponent");
static_assert(offsetof(UFortCreativeStreamingMusicalReactivityComponent, StreamingComponent) == 0x158, "Offset mismatch for UFortCreativeStreamingMusicalReactivityComponent::StreamingComponent");

// Size: 0x308 (Inherited: 0xe0, Single: 0x228)
class UFortCreativeStreamingComponent : public UActorComponent
{
public:
    USoundSubmix* DefaultSubmix; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    USoundSubmix* LicensedSubmix; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    USoundSubmix* AudioAnalysisSubmix; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UMaterialParameterCollection* JukeboxMPC; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    FVideoPlayerDeviceAudioAnalysisSettings AudioAnalysisSettings; // 0xd8 (Size: 0x40, Type: StructProperty)
    USoundConcurrency* SoundConcurrency; // 0x118 (Size: 0x8, Type: ObjectProperty)
    USoundConcurrency* MirrorSoundConcurrency; // 0x120 (Size: 0x8, Type: ObjectProperty)
    USoundClass* AudioSoundClass; // 0x128 (Size: 0x8, Type: ObjectProperty)
    UMaterial* VideoMaterial; // 0x130 (Size: 0x8, Type: ObjectProperty)
    int32_t MaterialSlot; // 0x138 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_13c[0x4]; // 0x13c (Size: 0x4, Type: PaddingProperty)
    UFortDownloadLocalizedOverlays* LocalizedOverlays; // 0x140 (Size: 0x8, Type: ObjectProperty)
    UFortMediaSubtitlesPlayer* SubtitlesPlayer; // 0x148 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_150[0x60]; // 0x150 (Size: 0x60, Type: PaddingProperty)
    uint8_t OnPlayCompleted[0x10]; // 0x1b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t CMSMetadataEvent[0x10]; // 0x1c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_1d0[0x8]; // 0x1d0 (Size: 0x8, Type: PaddingProperty)
    UFortBaseStreamingVideo* BaseStreamingVideoPlayer; // 0x1d8 (Size: 0x8, Type: ObjectProperty)
    FVideoPlayerDeviceComponents DeviceComponents; // 0x1e0 (Size: 0x30, Type: StructProperty)
    FVideoPlayerDeviceMediaMetadata CurrentlyPlayingData; // 0x210 (Size: 0x48, Type: StructProperty)
    TSoftObjectPtr<AActor*> MirroredDevice; // 0x258 (Size: 0x20, Type: SoftObjectProperty)
    UAudioComponent* MirrorAudioComponent; // 0x278 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* MirrorSoundAttenuation; // 0x280 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_288[0x1]; // 0x288 (Size: 0x1, Type: PaddingProperty)
    uint8_t StreamingMode; // 0x289 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_28a[0x26]; // 0x28a (Size: 0x26, Type: PaddingProperty)
    uint8_t OnSubmixSpectralAnalysisDelegate[0xc]; // 0x2b0 (Size: 0xc, Type: DelegateProperty)
    uint8_t Pad_2bc[0x14]; // 0x2bc (Size: 0x14, Type: PaddingProperty)
    FVideoPlayerDeviceCMSEventData CMSEventData; // 0x2d0 (Size: 0x38, Type: StructProperty)

public:
    void CMSEventEnded(UMediaCMSEvent*& const Event); // 0x11e9447c (Index: 0x0, Flags: Final|Native|Public)
    void CMSEventStarted(UMediaCMSEvent*& const Event); // 0x11e94870 (Index: 0x1, Flags: Final|Native|Public)
    void DisableScreenAndAudio(bool& bDisabled); // 0x11e94ccc (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void ForceRestart(); // 0x11e94df8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    FVideoPlayerDeviceComponents GetDeviceComponents() const; // 0x11e94e0c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFortStreamingVideoDeviceState GetDeviceState() const; // 0xb4a965c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFortBaseStreamingVideo* GetFortBaseStreamingVideo() const; // 0xed0cc38 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVideoPlayerDeviceComponents GetStreamingComponents() const; // 0x11e94e40 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AFortCreativeStreamingController* GetStreamingController() const; // 0x11e94ec8 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AActor* GetStreamingDevice() const; // 0x11e94eec (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFortStreamingVideoSelectionMode GetStreamingVideoSelectionMode() const; // 0x11e94f10 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void HandleCMSEvents(FVideoPlayerDeviceCMSEventData& EventData, bool& bEnable); // 0x11e94f28 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void Init(bool& const InUsesAudio, bool& const InUsesVideo, UStaticMeshComponent*& ScreenMesh); // 0x11e95760 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    bool IsComponentInitialized() const; // 0x11e95a58 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsDevicePlaying() const; // 0x11e95a70 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsRestartStreamWhenPlaying() const; // 0x11e95a94 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void Play(); // 0x11e95f60 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    virtual void PrintVideoPlayerDebugData(); // 0x3473f70 (Index: 0x17, Flags: Net|Native|Event|NetMulticast|Public|NetClient|BlueprintCallable)
    void Restart(); // 0x11e95f74 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void Seek(FTimespan& SeekTime); // 0x11e95f88 (Index: 0x19, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetFullScreenComponents(bool& const bEnable); // 0x11e9604c (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)
    void SetRestartStreamWhenPlaying(bool& const bNewRestartStreamWhenPlaying); // 0x11e96178 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable)
    void Stop(); // 0x11e962a4 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable)
    void TearDownComponent(); // 0x11e962f4 (Index: 0x20, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateStaticMesh(UStaticMeshComponent*& ScreenMesh); // 0x11e96308 (Index: 0x21, Flags: Final|Native|Public|BlueprintCallable)
    void UseDeviceOverrideMode(); // 0x11e96490 (Index: 0x22, Flags: Final|Native|Public|BlueprintCallable)
    void UseMirrorMode(AActor*& NewMirrorDevice); // 0x11e964a4 (Index: 0x23, Flags: Final|Native|Public|BlueprintCallable)
    void UseMirrorModeByName(FString& DeviceName); // 0x11e965d0 (Index: 0x24, Flags: Final|Native|Public|BlueprintCallable)
    void UsePriorityMode(); // 0x11e968e4 (Index: 0x25, Flags: Final|Native|Public|BlueprintCallable)

private:
    void HandleVideoStreamingSuccess(); // 0x11e95620 (Index: 0xc, Flags: Final|Native|Private)
    void HandleVideoStreamingTerminalError(EBaseMediaTerminalErrorReason& ErrorReason); // 0x11e95634 (Index: 0xd, Flags: Final|Native|Private)
    void OnAudioAnalysisSpectrumUpdated(const TArray<float> MagnitudeArray); // 0x11e95aac (Index: 0x12, Flags: Final|Native|Private|HasOutParms)
    void OnMediaSoundComponentActivated(UActorComponent*& Component, bool& bReset); // 0x11e95d38 (Index: 0x13, Flags: Final|Native|Private)
    void OnRep_StreamingSelectionMode(); // 0x11e94df8 (Index: 0x14, Flags: Final|Native|Private)
    void OnStreamingDeviceChanged(); // 0x11e95f4c (Index: 0x15, Flags: Final|Native|Private)
    void StreamedVideoOnMediaPlayerClosed(); // 0x11e962b8 (Index: 0x1d, Flags: Final|Native|Private)
    void StreamedVideoOnMediaPlayerEndReached(); // 0x11e962cc (Index: 0x1e, Flags: Final|Native|Private)
    void StreamedVideoOpeningTimeout(); // 0x11e962e0 (Index: 0x1f, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortCreativeStreamingComponent) == 0x308, "Size mismatch for UFortCreativeStreamingComponent");
static_assert(offsetof(UFortCreativeStreamingComponent, DefaultSubmix) == 0xb8, "Offset mismatch for UFortCreativeStreamingComponent::DefaultSubmix");
static_assert(offsetof(UFortCreativeStreamingComponent, LicensedSubmix) == 0xc0, "Offset mismatch for UFortCreativeStreamingComponent::LicensedSubmix");
static_assert(offsetof(UFortCreativeStreamingComponent, AudioAnalysisSubmix) == 0xc8, "Offset mismatch for UFortCreativeStreamingComponent::AudioAnalysisSubmix");
static_assert(offsetof(UFortCreativeStreamingComponent, JukeboxMPC) == 0xd0, "Offset mismatch for UFortCreativeStreamingComponent::JukeboxMPC");
static_assert(offsetof(UFortCreativeStreamingComponent, AudioAnalysisSettings) == 0xd8, "Offset mismatch for UFortCreativeStreamingComponent::AudioAnalysisSettings");
static_assert(offsetof(UFortCreativeStreamingComponent, SoundConcurrency) == 0x118, "Offset mismatch for UFortCreativeStreamingComponent::SoundConcurrency");
static_assert(offsetof(UFortCreativeStreamingComponent, MirrorSoundConcurrency) == 0x120, "Offset mismatch for UFortCreativeStreamingComponent::MirrorSoundConcurrency");
static_assert(offsetof(UFortCreativeStreamingComponent, AudioSoundClass) == 0x128, "Offset mismatch for UFortCreativeStreamingComponent::AudioSoundClass");
static_assert(offsetof(UFortCreativeStreamingComponent, VideoMaterial) == 0x130, "Offset mismatch for UFortCreativeStreamingComponent::VideoMaterial");
static_assert(offsetof(UFortCreativeStreamingComponent, MaterialSlot) == 0x138, "Offset mismatch for UFortCreativeStreamingComponent::MaterialSlot");
static_assert(offsetof(UFortCreativeStreamingComponent, LocalizedOverlays) == 0x140, "Offset mismatch for UFortCreativeStreamingComponent::LocalizedOverlays");
static_assert(offsetof(UFortCreativeStreamingComponent, SubtitlesPlayer) == 0x148, "Offset mismatch for UFortCreativeStreamingComponent::SubtitlesPlayer");
static_assert(offsetof(UFortCreativeStreamingComponent, OnPlayCompleted) == 0x1b0, "Offset mismatch for UFortCreativeStreamingComponent::OnPlayCompleted");
static_assert(offsetof(UFortCreativeStreamingComponent, CMSMetadataEvent) == 0x1c0, "Offset mismatch for UFortCreativeStreamingComponent::CMSMetadataEvent");
static_assert(offsetof(UFortCreativeStreamingComponent, BaseStreamingVideoPlayer) == 0x1d8, "Offset mismatch for UFortCreativeStreamingComponent::BaseStreamingVideoPlayer");
static_assert(offsetof(UFortCreativeStreamingComponent, DeviceComponents) == 0x1e0, "Offset mismatch for UFortCreativeStreamingComponent::DeviceComponents");
static_assert(offsetof(UFortCreativeStreamingComponent, CurrentlyPlayingData) == 0x210, "Offset mismatch for UFortCreativeStreamingComponent::CurrentlyPlayingData");
static_assert(offsetof(UFortCreativeStreamingComponent, MirroredDevice) == 0x258, "Offset mismatch for UFortCreativeStreamingComponent::MirroredDevice");
static_assert(offsetof(UFortCreativeStreamingComponent, MirrorAudioComponent) == 0x278, "Offset mismatch for UFortCreativeStreamingComponent::MirrorAudioComponent");
static_assert(offsetof(UFortCreativeStreamingComponent, MirrorSoundAttenuation) == 0x280, "Offset mismatch for UFortCreativeStreamingComponent::MirrorSoundAttenuation");
static_assert(offsetof(UFortCreativeStreamingComponent, StreamingMode) == 0x289, "Offset mismatch for UFortCreativeStreamingComponent::StreamingMode");
static_assert(offsetof(UFortCreativeStreamingComponent, OnSubmixSpectralAnalysisDelegate) == 0x2b0, "Offset mismatch for UFortCreativeStreamingComponent::OnSubmixSpectralAnalysisDelegate");
static_assert(offsetof(UFortCreativeStreamingComponent, CMSEventData) == 0x2d0, "Offset mismatch for UFortCreativeStreamingComponent::CMSEventData");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FVideoPlayerDeviceComponents
{
    UStaticMeshComponent* ScreenMesh; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* ScreenMaterialDynamic; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UMediaSoundComponent* SoundComponent; // 0x10 (Size: 0x8, Type: ObjectProperty)
    UMediaTexture* VideoTexture; // 0x18 (Size: 0x8, Type: ObjectProperty)
    USoundSourceBus* SourceBus; // 0x20 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FVideoPlayerDeviceComponents) == 0x30, "Size mismatch for FVideoPlayerDeviceComponents");
static_assert(offsetof(FVideoPlayerDeviceComponents, ScreenMesh) == 0x0, "Offset mismatch for FVideoPlayerDeviceComponents::ScreenMesh");
static_assert(offsetof(FVideoPlayerDeviceComponents, ScreenMaterialDynamic) == 0x8, "Offset mismatch for FVideoPlayerDeviceComponents::ScreenMaterialDynamic");
static_assert(offsetof(FVideoPlayerDeviceComponents, SoundComponent) == 0x10, "Offset mismatch for FVideoPlayerDeviceComponents::SoundComponent");
static_assert(offsetof(FVideoPlayerDeviceComponents, VideoTexture) == 0x18, "Offset mismatch for FVideoPlayerDeviceComponents::VideoTexture");
static_assert(offsetof(FVideoPlayerDeviceComponents, SourceBus) == 0x20, "Offset mismatch for FVideoPlayerDeviceComponents::SourceBus");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FVideoPlayerDeviceFullscreenData
{
    bool bEnable; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t InstanceID; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FVideoPlayerDeviceFullscreenData) == 0x8, "Size mismatch for FVideoPlayerDeviceFullscreenData");
static_assert(offsetof(FVideoPlayerDeviceFullscreenData, bEnable) == 0x0, "Offset mismatch for FVideoPlayerDeviceFullscreenData::bEnable");
static_assert(offsetof(FVideoPlayerDeviceFullscreenData, InstanceID) == 0x4, "Offset mismatch for FVideoPlayerDeviceFullscreenData::InstanceID");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FVideoPlayerDevicePIPSettings
{
    float TriggerRange; // 0x0 (Size: 0x4, Type: FloatProperty)
    bool bEnabled; // 0x4 (Size: 0x1, Type: BoolProperty)
    bool bAlwaysAllow; // 0x5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6[0x2]; // 0x6 (Size: 0x2, Type: PaddingProperty)
    int32_t InstanceID; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FVideoPlayerDevicePIPSettings) == 0xc, "Size mismatch for FVideoPlayerDevicePIPSettings");
static_assert(offsetof(FVideoPlayerDevicePIPSettings, TriggerRange) == 0x0, "Offset mismatch for FVideoPlayerDevicePIPSettings::TriggerRange");
static_assert(offsetof(FVideoPlayerDevicePIPSettings, bEnabled) == 0x4, "Offset mismatch for FVideoPlayerDevicePIPSettings::bEnabled");
static_assert(offsetof(FVideoPlayerDevicePIPSettings, bAlwaysAllow) == 0x5, "Offset mismatch for FVideoPlayerDevicePIPSettings::bAlwaysAllow");
static_assert(offsetof(FVideoPlayerDevicePIPSettings, InstanceID) == 0x8, "Offset mismatch for FVideoPlayerDevicePIPSettings::InstanceID");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FVideoPlayerDevicePIPFullscreenSettings
{
    AController* Instigator; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bEnableFullscreen; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    int32_t InstanceID; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FVideoPlayerDevicePIPFullscreenSettings) == 0x10, "Size mismatch for FVideoPlayerDevicePIPFullscreenSettings");
static_assert(offsetof(FVideoPlayerDevicePIPFullscreenSettings, Instigator) == 0x0, "Offset mismatch for FVideoPlayerDevicePIPFullscreenSettings::Instigator");
static_assert(offsetof(FVideoPlayerDevicePIPFullscreenSettings, bEnableFullscreen) == 0x8, "Offset mismatch for FVideoPlayerDevicePIPFullscreenSettings::bEnableFullscreen");
static_assert(offsetof(FVideoPlayerDevicePIPFullscreenSettings, InstanceID) == 0xc, "Offset mismatch for FVideoPlayerDevicePIPFullscreenSettings::InstanceID");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FVideoPlayerDeviceCMSEventData
{
    FString EventName; // 0x0 (Size: 0x10, Type: StrProperty)
    FString EventPage; // 0x10 (Size: 0x10, Type: StrProperty)
    FString VUID; // 0x20 (Size: 0x10, Type: StrProperty)
    bool bEnabled; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FVideoPlayerDeviceCMSEventData) == 0x38, "Size mismatch for FVideoPlayerDeviceCMSEventData");
static_assert(offsetof(FVideoPlayerDeviceCMSEventData, EventName) == 0x0, "Offset mismatch for FVideoPlayerDeviceCMSEventData::EventName");
static_assert(offsetof(FVideoPlayerDeviceCMSEventData, EventPage) == 0x10, "Offset mismatch for FVideoPlayerDeviceCMSEventData::EventPage");
static_assert(offsetof(FVideoPlayerDeviceCMSEventData, VUID) == 0x20, "Offset mismatch for FVideoPlayerDeviceCMSEventData::VUID");
static_assert(offsetof(FVideoPlayerDeviceCMSEventData, bEnabled) == 0x30, "Offset mismatch for FVideoPlayerDeviceCMSEventData::bEnabled");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FVideoPlayerDeviceAudioAnalysisSettings
{
    TArray<FSoundSubmixSpectralAnalysisBandSettings> AudioAnalysisBandSettings; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> AudioAnalysisBandNames; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FName PercussionParameterName; // 0x20 (Size: 0x4, Type: NameProperty)
    FName AverageAmplitudeParameterName; // 0x24 (Size: 0x4, Type: NameProperty)
    float UpdateRate; // 0x28 (Size: 0x4, Type: FloatProperty)
    float DecibelNoiseFloor; // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bDoNormalize; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bDoAutoRange; // 0x31 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x2]; // 0x32 (Size: 0x2, Type: PaddingProperty)
    float AutoRangeAttackTime; // 0x34 (Size: 0x4, Type: FloatProperty)
    float AutoRangeReleaseTime; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FVideoPlayerDeviceAudioAnalysisSettings) == 0x40, "Size mismatch for FVideoPlayerDeviceAudioAnalysisSettings");
static_assert(offsetof(FVideoPlayerDeviceAudioAnalysisSettings, AudioAnalysisBandSettings) == 0x0, "Offset mismatch for FVideoPlayerDeviceAudioAnalysisSettings::AudioAnalysisBandSettings");
static_assert(offsetof(FVideoPlayerDeviceAudioAnalysisSettings, AudioAnalysisBandNames) == 0x10, "Offset mismatch for FVideoPlayerDeviceAudioAnalysisSettings::AudioAnalysisBandNames");
static_assert(offsetof(FVideoPlayerDeviceAudioAnalysisSettings, PercussionParameterName) == 0x20, "Offset mismatch for FVideoPlayerDeviceAudioAnalysisSettings::PercussionParameterName");
static_assert(offsetof(FVideoPlayerDeviceAudioAnalysisSettings, AverageAmplitudeParameterName) == 0x24, "Offset mismatch for FVideoPlayerDeviceAudioAnalysisSettings::AverageAmplitudeParameterName");
static_assert(offsetof(FVideoPlayerDeviceAudioAnalysisSettings, UpdateRate) == 0x28, "Offset mismatch for FVideoPlayerDeviceAudioAnalysisSettings::UpdateRate");
static_assert(offsetof(FVideoPlayerDeviceAudioAnalysisSettings, DecibelNoiseFloor) == 0x2c, "Offset mismatch for FVideoPlayerDeviceAudioAnalysisSettings::DecibelNoiseFloor");
static_assert(offsetof(FVideoPlayerDeviceAudioAnalysisSettings, bDoNormalize) == 0x30, "Offset mismatch for FVideoPlayerDeviceAudioAnalysisSettings::bDoNormalize");
static_assert(offsetof(FVideoPlayerDeviceAudioAnalysisSettings, bDoAutoRange) == 0x31, "Offset mismatch for FVideoPlayerDeviceAudioAnalysisSettings::bDoAutoRange");
static_assert(offsetof(FVideoPlayerDeviceAudioAnalysisSettings, AutoRangeAttackTime) == 0x34, "Offset mismatch for FVideoPlayerDeviceAudioAnalysisSettings::AutoRangeAttackTime");
static_assert(offsetof(FVideoPlayerDeviceAudioAnalysisSettings, AutoRangeReleaseTime) == 0x38, "Offset mismatch for FVideoPlayerDeviceAudioAnalysisSettings::AutoRangeReleaseTime");

