/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EcosystemMatchmakingSettingsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"

// Size: 0x68 (Inherited: 0x50, Single: 0x18)
class UEcosystemMatchmakingSettingsUI : public UMatchmakingSettingsUI
{
public:
    TSoftClassPtr MatchmakingSettingsModal; // 0x28 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr MatchFoundWidget; // 0x48 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UEcosystemMatchmakingSettingsUI) == 0x68, "Size mismatch for UEcosystemMatchmakingSettingsUI");
static_assert(offsetof(UEcosystemMatchmakingSettingsUI, MatchmakingSettingsModal) == 0x28, "Offset mismatch for UEcosystemMatchmakingSettingsUI::MatchmakingSettingsModal");
static_assert(offsetof(UEcosystemMatchmakingSettingsUI, MatchFoundWidget) == 0x48, "Offset mismatch for UEcosystemMatchmakingSettingsUI::MatchFoundWidget");

