/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortSpatialMetrics
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "SpatialMetricsCore.h"
#include "WorldMetricsCore.h"
#include "CoreUObject.h"

// Size: 0x488 (Inherited: 0x528, Single: 0xffffff60)
class UFortSpatialMetricsActorCount : public USpatialMetricsQuantityMetric
{
public:
};

static_assert(sizeof(UFortSpatialMetricsActorCount) == 0x488, "Size mismatch for UFortSpatialMetricsActorCount");

// Size: 0x488 (Inherited: 0x9b0, Single: 0xfffffad8)
class UFortSpatialMetricsBuildingCount : public UFortSpatialMetricsActorCount
{
public:
};

static_assert(sizeof(UFortSpatialMetricsBuildingCount) == 0x488, "Size mismatch for UFortSpatialMetricsBuildingCount");

// Size: 0x488 (Inherited: 0x9b0, Single: 0xfffffad8)
class UFortSpatialMetricsLootContainerCount : public UFortSpatialMetricsActorCount
{
public:
};

static_assert(sizeof(UFortSpatialMetricsLootContainerCount) == 0x488, "Size mismatch for UFortSpatialMetricsLootContainerCount");

// Size: 0x488 (Inherited: 0x9b0, Single: 0xfffffad8)
class UFortSpatialMetricsPickupCount : public UFortSpatialMetricsActorCount
{
public:
};

static_assert(sizeof(UFortSpatialMetricsPickupCount) == 0x488, "Size mismatch for UFortSpatialMetricsPickupCount");

