/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DashRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"
#include "Engine.h"

// Size: 0x60 (Inherited: 0x68, Single: 0xfffffff8)
class UFortMovementMode_DashRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
};

static_assert(sizeof(UFortMovementMode_DashRuntimeData) == 0x60, "Size mismatch for UFortMovementMode_DashRuntimeData");

// Size: 0x4a8 (Inherited: 0x210, Single: 0x298)
class UFortMovementMode_ExtDash : public UFortMovementMode_BaseExtLogic
{
public:
    FScalableFloat DashDistance; // 0x1e8 (Size: 0x28, Type: StructProperty)
    FScalableFloat DashDuration; // 0x210 (Size: 0x28, Type: StructProperty)
    FScalableFloat UseMovementForTargetDeadzone; // 0x238 (Size: 0x28, Type: StructProperty)
    FScalableFloat bUseDynamicZTarget; // 0x260 (Size: 0x28, Type: StructProperty)
    FScalableFloat DynamicZMaxReverseAngle; // 0x288 (Size: 0x28, Type: StructProperty)
    FScalableFloat DynamicZMinReverseAngle; // 0x2b0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DynamicZReverseModifier; // 0x2d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat DynamicZReverseTargetMinZ; // 0x300 (Size: 0x28, Type: StructProperty)
    FScalableFloat DashEndVelocity; // 0x328 (Size: 0x28, Type: StructProperty)
    FScalableFloat bDashEndVelocityUseZ; // 0x350 (Size: 0x28, Type: StructProperty)
    FScalableFloat DashAccelerationMultiplier; // 0x378 (Size: 0x28, Type: StructProperty)
    FScalableFloat EndVelocityMultiplier; // 0x3a0 (Size: 0x28, Type: StructProperty)
    FScalableFloat EndVelocityMultiplierOnNoUserInput; // 0x3c8 (Size: 0x28, Type: StructProperty)
    FScalableFloat bRestrictSpeedToExpected; // 0x3f0 (Size: 0x28, Type: StructProperty)
    uint8_t VelocityOnFinishMode; // 0x418 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_419[0x7]; // 0x419 (Size: 0x7, Type: PaddingProperty)
    FScalableFloat ClampVelocityOnFinish; // 0x420 (Size: 0x28, Type: StructProperty)
    FScalableFloat HeightAboveGround; // 0x448 (Size: 0x28, Type: StructProperty)
    FScalableFloat bEnsureHeightAboveGround; // 0x470 (Size: 0x28, Type: StructProperty)
    UCurveVector* PathOffsetCurve; // 0x498 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_4a0[0x8]; // 0x4a0 (Size: 0x8, Type: PaddingProperty)

public:
    static bool TryActivateDashMME(AFortPawn*& TargetPawn, UClass*& DashMME, const FFortMovementMode_DashCreationData CreationData, UFortMovementMode_BaseExtRuntimeData*& OutRuntimeData); // 0x11366dfc (Index: 0x0, Flags: Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UFortMovementMode_ExtDash) == 0x4a8, "Size mismatch for UFortMovementMode_ExtDash");
static_assert(offsetof(UFortMovementMode_ExtDash, DashDistance) == 0x1e8, "Offset mismatch for UFortMovementMode_ExtDash::DashDistance");
static_assert(offsetof(UFortMovementMode_ExtDash, DashDuration) == 0x210, "Offset mismatch for UFortMovementMode_ExtDash::DashDuration");
static_assert(offsetof(UFortMovementMode_ExtDash, UseMovementForTargetDeadzone) == 0x238, "Offset mismatch for UFortMovementMode_ExtDash::UseMovementForTargetDeadzone");
static_assert(offsetof(UFortMovementMode_ExtDash, bUseDynamicZTarget) == 0x260, "Offset mismatch for UFortMovementMode_ExtDash::bUseDynamicZTarget");
static_assert(offsetof(UFortMovementMode_ExtDash, DynamicZMaxReverseAngle) == 0x288, "Offset mismatch for UFortMovementMode_ExtDash::DynamicZMaxReverseAngle");
static_assert(offsetof(UFortMovementMode_ExtDash, DynamicZMinReverseAngle) == 0x2b0, "Offset mismatch for UFortMovementMode_ExtDash::DynamicZMinReverseAngle");
static_assert(offsetof(UFortMovementMode_ExtDash, DynamicZReverseModifier) == 0x2d8, "Offset mismatch for UFortMovementMode_ExtDash::DynamicZReverseModifier");
static_assert(offsetof(UFortMovementMode_ExtDash, DynamicZReverseTargetMinZ) == 0x300, "Offset mismatch for UFortMovementMode_ExtDash::DynamicZReverseTargetMinZ");
static_assert(offsetof(UFortMovementMode_ExtDash, DashEndVelocity) == 0x328, "Offset mismatch for UFortMovementMode_ExtDash::DashEndVelocity");
static_assert(offsetof(UFortMovementMode_ExtDash, bDashEndVelocityUseZ) == 0x350, "Offset mismatch for UFortMovementMode_ExtDash::bDashEndVelocityUseZ");
static_assert(offsetof(UFortMovementMode_ExtDash, DashAccelerationMultiplier) == 0x378, "Offset mismatch for UFortMovementMode_ExtDash::DashAccelerationMultiplier");
static_assert(offsetof(UFortMovementMode_ExtDash, EndVelocityMultiplier) == 0x3a0, "Offset mismatch for UFortMovementMode_ExtDash::EndVelocityMultiplier");
static_assert(offsetof(UFortMovementMode_ExtDash, EndVelocityMultiplierOnNoUserInput) == 0x3c8, "Offset mismatch for UFortMovementMode_ExtDash::EndVelocityMultiplierOnNoUserInput");
static_assert(offsetof(UFortMovementMode_ExtDash, bRestrictSpeedToExpected) == 0x3f0, "Offset mismatch for UFortMovementMode_ExtDash::bRestrictSpeedToExpected");
static_assert(offsetof(UFortMovementMode_ExtDash, VelocityOnFinishMode) == 0x418, "Offset mismatch for UFortMovementMode_ExtDash::VelocityOnFinishMode");
static_assert(offsetof(UFortMovementMode_ExtDash, ClampVelocityOnFinish) == 0x420, "Offset mismatch for UFortMovementMode_ExtDash::ClampVelocityOnFinish");
static_assert(offsetof(UFortMovementMode_ExtDash, HeightAboveGround) == 0x448, "Offset mismatch for UFortMovementMode_ExtDash::HeightAboveGround");
static_assert(offsetof(UFortMovementMode_ExtDash, bEnsureHeightAboveGround) == 0x470, "Offset mismatch for UFortMovementMode_ExtDash::bEnsureHeightAboveGround");
static_assert(offsetof(UFortMovementMode_ExtDash, PathOffsetCurve) == 0x498, "Offset mismatch for UFortMovementMode_ExtDash::PathOffsetCurve");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FFortMovementMode_DashCreationData : FFortMovementMode_BaseExtCreationData
{
    FRotator AimDirection; // 0x10 (Size: 0x18, Type: StructProperty)
    bool bHasMovementInput; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortMovementMode_DashCreationData) == 0x30, "Size mismatch for FFortMovementMode_DashCreationData");
static_assert(offsetof(FFortMovementMode_DashCreationData, AimDirection) == 0x10, "Offset mismatch for FFortMovementMode_DashCreationData::AimDirection");
static_assert(offsetof(FFortMovementMode_DashCreationData, bHasMovementInput) == 0x28, "Offset mismatch for FFortMovementMode_DashCreationData::bHasMovementInput");

