/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimationLayeringRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "AnimGraphRuntime.h"
#include "CoreUObject.h"

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UBoneMaskDefinitionDataAsset : public UDataAsset
{
public:
    FBoneMaskDefinition BoneMaskDefinition; // 0x30 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UBoneMaskDefinitionDataAsset) == 0x40, "Size mismatch for UBoneMaskDefinitionDataAsset");
static_assert(offsetof(UBoneMaskDefinitionDataAsset, BoneMaskDefinition) == 0x30, "Offset mismatch for UBoneMaskDefinitionDataAsset::BoneMaskDefinition");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FBoneMask
{
    TMap<FBoneMaskEntry, FName> BoneMaskMap; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FBoneMask) == 0x50, "Size mismatch for FBoneMask");
static_assert(offsetof(FBoneMask, BoneMaskMap) == 0x0, "Offset mismatch for FBoneMask::BoneMaskMap");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FBoneMaskEntry
{
    float LocalSpaceWeight; // 0x0 (Size: 0x4, Type: FloatProperty)
    float MeshSpaceWeight; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBoneMaskEntry) == 0x8, "Size mismatch for FBoneMaskEntry");
static_assert(offsetof(FBoneMaskEntry, LocalSpaceWeight) == 0x0, "Offset mismatch for FBoneMaskEntry::LocalSpaceWeight");
static_assert(offsetof(FBoneMaskEntry, MeshSpaceWeight) == 0x4, "Offset mismatch for FBoneMaskEntry::MeshSpaceWeight");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FBoneMaskPerBoneData
{
    int32_t SkeletonPoseBoneIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    float BlendWeight; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBoneMaskPerBoneData) == 0x8, "Size mismatch for FBoneMaskPerBoneData");
static_assert(offsetof(FBoneMaskPerBoneData, SkeletonPoseBoneIndex) == 0x0, "Offset mismatch for FBoneMaskPerBoneData::SkeletonPoseBoneIndex");
static_assert(offsetof(FBoneMaskPerBoneData, BlendWeight) == 0x4, "Offset mismatch for FBoneMaskPerBoneData::BlendWeight");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FBoneMaskBodyPartDefinition
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FBranchFilter> BranchFilters; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FBoneMaskPerBoneData> SkeletonPoseBoneWeights; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> SkeletonPoseChildBoneIndices; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FBoneMaskBodyPartDefinition) == 0x38, "Size mismatch for FBoneMaskBodyPartDefinition");
static_assert(offsetof(FBoneMaskBodyPartDefinition, Name) == 0x0, "Offset mismatch for FBoneMaskBodyPartDefinition::Name");
static_assert(offsetof(FBoneMaskBodyPartDefinition, BranchFilters) == 0x8, "Offset mismatch for FBoneMaskBodyPartDefinition::BranchFilters");
static_assert(offsetof(FBoneMaskBodyPartDefinition, SkeletonPoseBoneWeights) == 0x18, "Offset mismatch for FBoneMaskBodyPartDefinition::SkeletonPoseBoneWeights");
static_assert(offsetof(FBoneMaskBodyPartDefinition, SkeletonPoseChildBoneIndices) == 0x28, "Offset mismatch for FBoneMaskBodyPartDefinition::SkeletonPoseChildBoneIndices");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBoneMaskDefinition
{
    TArray<FBoneMaskBodyPartDefinition> BodyPartDefinitions; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FBoneMaskDefinition) == 0x10, "Size mismatch for FBoneMaskDefinition");
static_assert(offsetof(FBoneMaskDefinition, BodyPartDefinitions) == 0x0, "Offset mismatch for FBoneMaskDefinition::BodyPartDefinitions");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FBoneMaskUpdateMultiParam
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    float LocalSpaceWeight; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MeshSpaceWeight; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBoneMaskUpdateMultiParam) == 0xc, "Size mismatch for FBoneMaskUpdateMultiParam");
static_assert(offsetof(FBoneMaskUpdateMultiParam, Name) == 0x0, "Offset mismatch for FBoneMaskUpdateMultiParam::Name");
static_assert(offsetof(FBoneMaskUpdateMultiParam, LocalSpaceWeight) == 0x4, "Offset mismatch for FBoneMaskUpdateMultiParam::LocalSpaceWeight");
static_assert(offsetof(FBoneMaskUpdateMultiParam, MeshSpaceWeight) == 0x8, "Offset mismatch for FBoneMaskUpdateMultiParam::MeshSpaceWeight");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBoneMaskBodyPartNameContainer
{
    TArray<FName> Names; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FBoneMaskBodyPartNameContainer) == 0x10, "Size mismatch for FBoneMaskBodyPartNameContainer");
static_assert(offsetof(FBoneMaskBodyPartNameContainer, Names) == 0x0, "Offset mismatch for FBoneMaskBodyPartNameContainer::Names");

// Size: 0x118 (Inherited: 0x10, Single: 0x108)
struct FAnimNode_BoneMask : FAnimNode_Base
{
    FPoseLink BasePose; // 0x10 (Size: 0x10, Type: StructProperty)
    TArray<FPoseLink> BlendPoses; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<float> BlendWeights; // 0x30 (Size: 0x10, Type: ArrayProperty)
    FBoneMask BoneMask; // 0x40 (Size: 0x50, Type: StructProperty)
    UBoneMaskDefinitionDataAsset* BoneMaskDefinitionDataAsset; // 0x90 (Size: 0x8, Type: ObjectProperty)
    TArray<FBoneMaskBodyPartNameContainer> BodyParts; // 0x98 (Size: 0x10, Type: ArrayProperty)
    TEnumAsByte<ECurveBlendOption> CurveBlendOption; // 0xa8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_a9[0x3]; // 0xa9 (Size: 0x3, Type: PaddingProperty)
    int32_t LODThreshold; // 0xac (Size: 0x4, Type: IntProperty)
    bool bUpdateSkeletonDataOnDemand; // 0xb0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b1[0x67]; // 0xb1 (Size: 0x67, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_BoneMask) == 0x118, "Size mismatch for FAnimNode_BoneMask");
static_assert(offsetof(FAnimNode_BoneMask, BasePose) == 0x10, "Offset mismatch for FAnimNode_BoneMask::BasePose");
static_assert(offsetof(FAnimNode_BoneMask, BlendPoses) == 0x20, "Offset mismatch for FAnimNode_BoneMask::BlendPoses");
static_assert(offsetof(FAnimNode_BoneMask, BlendWeights) == 0x30, "Offset mismatch for FAnimNode_BoneMask::BlendWeights");
static_assert(offsetof(FAnimNode_BoneMask, BoneMask) == 0x40, "Offset mismatch for FAnimNode_BoneMask::BoneMask");
static_assert(offsetof(FAnimNode_BoneMask, BoneMaskDefinitionDataAsset) == 0x90, "Offset mismatch for FAnimNode_BoneMask::BoneMaskDefinitionDataAsset");
static_assert(offsetof(FAnimNode_BoneMask, BodyParts) == 0x98, "Offset mismatch for FAnimNode_BoneMask::BodyParts");
static_assert(offsetof(FAnimNode_BoneMask, CurveBlendOption) == 0xa8, "Offset mismatch for FAnimNode_BoneMask::CurveBlendOption");
static_assert(offsetof(FAnimNode_BoneMask, LODThreshold) == 0xac, "Offset mismatch for FAnimNode_BoneMask::LODThreshold");
static_assert(offsetof(FAnimNode_BoneMask, bUpdateSkeletonDataOnDemand) == 0xb0, "Offset mismatch for FAnimNode_BoneMask::bUpdateSkeletonDataOnDemand");

// Size: 0x128 (Inherited: 0xd8, Single: 0x50)
struct FAnimNode_CopyBoneAdvanced : FAnimNode_SkeletalControlBase
{
    FBoneReference SourceBone; // 0xc8 (Size: 0xc, Type: StructProperty)
    FBoneReference TargetBone; // 0xd4 (Size: 0xc, Type: StructProperty)
    FVector TranslationWeight; // 0xe0 (Size: 0x18, Type: StructProperty)
    float RotationWeight; // 0xf8 (Size: 0x4, Type: FloatProperty)
    float ScaleWeight; // 0xfc (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EBoneControlSpace> ControlSpace; // 0x100 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_101[0x3]; // 0x101 (Size: 0x3, Type: PaddingProperty)
    FBoneReference TranslationSpaceBone; // 0x104 (Size: 0xc, Type: StructProperty)
    bool bTranslationInCustomBoneSpace; // 0x110 (Size: 0x1, Type: BoolProperty)
    bool bPropagateToChildren; // 0x111 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_112[0x16]; // 0x112 (Size: 0x16, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_CopyBoneAdvanced) == 0x128, "Size mismatch for FAnimNode_CopyBoneAdvanced");
static_assert(offsetof(FAnimNode_CopyBoneAdvanced, SourceBone) == 0xc8, "Offset mismatch for FAnimNode_CopyBoneAdvanced::SourceBone");
static_assert(offsetof(FAnimNode_CopyBoneAdvanced, TargetBone) == 0xd4, "Offset mismatch for FAnimNode_CopyBoneAdvanced::TargetBone");
static_assert(offsetof(FAnimNode_CopyBoneAdvanced, TranslationWeight) == 0xe0, "Offset mismatch for FAnimNode_CopyBoneAdvanced::TranslationWeight");
static_assert(offsetof(FAnimNode_CopyBoneAdvanced, RotationWeight) == 0xf8, "Offset mismatch for FAnimNode_CopyBoneAdvanced::RotationWeight");
static_assert(offsetof(FAnimNode_CopyBoneAdvanced, ScaleWeight) == 0xfc, "Offset mismatch for FAnimNode_CopyBoneAdvanced::ScaleWeight");
static_assert(offsetof(FAnimNode_CopyBoneAdvanced, ControlSpace) == 0x100, "Offset mismatch for FAnimNode_CopyBoneAdvanced::ControlSpace");
static_assert(offsetof(FAnimNode_CopyBoneAdvanced, TranslationSpaceBone) == 0x104, "Offset mismatch for FAnimNode_CopyBoneAdvanced::TranslationSpaceBone");
static_assert(offsetof(FAnimNode_CopyBoneAdvanced, bTranslationInCustomBoneSpace) == 0x110, "Offset mismatch for FAnimNode_CopyBoneAdvanced::bTranslationInCustomBoneSpace");
static_assert(offsetof(FAnimNode_CopyBoneAdvanced, bPropagateToChildren) == 0x111, "Offset mismatch for FAnimNode_CopyBoneAdvanced::bPropagateToChildren");

// Size: 0x1e0 (Inherited: 0xd8, Single: 0x108)
struct FAnimNode_CopyMotion : FAnimNode_SkeletalControlBase
{
    FComponentSpacePoseLink BasePose; // 0xc8 (Size: 0x10, Type: StructProperty)
    FComponentSpacePoseLink BasePoseReference; // 0xd8 (Size: 0x10, Type: StructProperty)
    bool bUseBasePose; // 0xe8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e9[0x3]; // 0xe9 (Size: 0x3, Type: PaddingProperty)
    FName PoseHistoryTag; // 0xec (Size: 0x4, Type: NameProperty)
    float Delay; // 0xf0 (Size: 0x4, Type: FloatProperty)
    FBoneReference SourceBone; // 0xf4 (Size: 0xc, Type: StructProperty)
    FBoneReference BoneToModify; // 0x100 (Size: 0xc, Type: StructProperty)
    FBoneReference CopySpace; // 0x10c (Size: 0xc, Type: StructProperty)
    FBoneReference ApplySpace; // 0x118 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_124[0x4]; // 0x124 (Size: 0x4, Type: PaddingProperty)
    FRotator TranslationOffset; // 0x128 (Size: 0x18, Type: StructProperty)
    FRotator RotationOffset; // 0x140 (Size: 0x18, Type: StructProperty)
    FVector RotationPivot; // 0x158 (Size: 0x18, Type: StructProperty)
    FName CurvePrefix; // 0x170 (Size: 0x4, Type: NameProperty)
    FName TargetCurveName; // 0x174 (Size: 0x4, Type: NameProperty)
    float TargetCurveScale; // 0x178 (Size: 0x4, Type: FloatProperty)
    uint8_t TargetCurveComponent; // 0x17c (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EAxis> TargetCurveRotationAxis; // 0x17d (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_17e[0x2]; // 0x17e (Size: 0x2, Type: PaddingProperty)
    FName TranslationX_CurveName; // 0x180 (Size: 0x4, Type: NameProperty)
    FName TranslationY_CurveName; // 0x184 (Size: 0x4, Type: NameProperty)
    FName TranslationZ_CurveName; // 0x188 (Size: 0x4, Type: NameProperty)
    FName RotationRoll_CurveName; // 0x18c (Size: 0x4, Type: NameProperty)
    FName RotationPitch_CurveName; // 0x190 (Size: 0x4, Type: NameProperty)
    FName RotationYaw_CurveName; // 0x194 (Size: 0x4, Type: NameProperty)
    FVector TranslationScale; // 0x198 (Size: 0x18, Type: StructProperty)
    UCurveVector* TranslationRemapCurve; // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    float RotationScale; // 0x1b8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1bc[0x4]; // 0x1bc (Size: 0x4, Type: PaddingProperty)
    UCurveFloat* RotationRemapCurve; // 0x1c0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1c8[0x18]; // 0x1c8 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_CopyMotion) == 0x1e0, "Size mismatch for FAnimNode_CopyMotion");
static_assert(offsetof(FAnimNode_CopyMotion, BasePose) == 0xc8, "Offset mismatch for FAnimNode_CopyMotion::BasePose");
static_assert(offsetof(FAnimNode_CopyMotion, BasePoseReference) == 0xd8, "Offset mismatch for FAnimNode_CopyMotion::BasePoseReference");
static_assert(offsetof(FAnimNode_CopyMotion, bUseBasePose) == 0xe8, "Offset mismatch for FAnimNode_CopyMotion::bUseBasePose");
static_assert(offsetof(FAnimNode_CopyMotion, PoseHistoryTag) == 0xec, "Offset mismatch for FAnimNode_CopyMotion::PoseHistoryTag");
static_assert(offsetof(FAnimNode_CopyMotion, Delay) == 0xf0, "Offset mismatch for FAnimNode_CopyMotion::Delay");
static_assert(offsetof(FAnimNode_CopyMotion, SourceBone) == 0xf4, "Offset mismatch for FAnimNode_CopyMotion::SourceBone");
static_assert(offsetof(FAnimNode_CopyMotion, BoneToModify) == 0x100, "Offset mismatch for FAnimNode_CopyMotion::BoneToModify");
static_assert(offsetof(FAnimNode_CopyMotion, CopySpace) == 0x10c, "Offset mismatch for FAnimNode_CopyMotion::CopySpace");
static_assert(offsetof(FAnimNode_CopyMotion, ApplySpace) == 0x118, "Offset mismatch for FAnimNode_CopyMotion::ApplySpace");
static_assert(offsetof(FAnimNode_CopyMotion, TranslationOffset) == 0x128, "Offset mismatch for FAnimNode_CopyMotion::TranslationOffset");
static_assert(offsetof(FAnimNode_CopyMotion, RotationOffset) == 0x140, "Offset mismatch for FAnimNode_CopyMotion::RotationOffset");
static_assert(offsetof(FAnimNode_CopyMotion, RotationPivot) == 0x158, "Offset mismatch for FAnimNode_CopyMotion::RotationPivot");
static_assert(offsetof(FAnimNode_CopyMotion, CurvePrefix) == 0x170, "Offset mismatch for FAnimNode_CopyMotion::CurvePrefix");
static_assert(offsetof(FAnimNode_CopyMotion, TargetCurveName) == 0x174, "Offset mismatch for FAnimNode_CopyMotion::TargetCurveName");
static_assert(offsetof(FAnimNode_CopyMotion, TargetCurveScale) == 0x178, "Offset mismatch for FAnimNode_CopyMotion::TargetCurveScale");
static_assert(offsetof(FAnimNode_CopyMotion, TargetCurveComponent) == 0x17c, "Offset mismatch for FAnimNode_CopyMotion::TargetCurveComponent");
static_assert(offsetof(FAnimNode_CopyMotion, TargetCurveRotationAxis) == 0x17d, "Offset mismatch for FAnimNode_CopyMotion::TargetCurveRotationAxis");
static_assert(offsetof(FAnimNode_CopyMotion, TranslationX_CurveName) == 0x180, "Offset mismatch for FAnimNode_CopyMotion::TranslationX_CurveName");
static_assert(offsetof(FAnimNode_CopyMotion, TranslationY_CurveName) == 0x184, "Offset mismatch for FAnimNode_CopyMotion::TranslationY_CurveName");
static_assert(offsetof(FAnimNode_CopyMotion, TranslationZ_CurveName) == 0x188, "Offset mismatch for FAnimNode_CopyMotion::TranslationZ_CurveName");
static_assert(offsetof(FAnimNode_CopyMotion, RotationRoll_CurveName) == 0x18c, "Offset mismatch for FAnimNode_CopyMotion::RotationRoll_CurveName");
static_assert(offsetof(FAnimNode_CopyMotion, RotationPitch_CurveName) == 0x190, "Offset mismatch for FAnimNode_CopyMotion::RotationPitch_CurveName");
static_assert(offsetof(FAnimNode_CopyMotion, RotationYaw_CurveName) == 0x194, "Offset mismatch for FAnimNode_CopyMotion::RotationYaw_CurveName");
static_assert(offsetof(FAnimNode_CopyMotion, TranslationScale) == 0x198, "Offset mismatch for FAnimNode_CopyMotion::TranslationScale");
static_assert(offsetof(FAnimNode_CopyMotion, TranslationRemapCurve) == 0x1b0, "Offset mismatch for FAnimNode_CopyMotion::TranslationRemapCurve");
static_assert(offsetof(FAnimNode_CopyMotion, RotationScale) == 0x1b8, "Offset mismatch for FAnimNode_CopyMotion::RotationScale");
static_assert(offsetof(FAnimNode_CopyMotion, RotationRemapCurve) == 0x1c0, "Offset mismatch for FAnimNode_CopyMotion::RotationRemapCurve");

