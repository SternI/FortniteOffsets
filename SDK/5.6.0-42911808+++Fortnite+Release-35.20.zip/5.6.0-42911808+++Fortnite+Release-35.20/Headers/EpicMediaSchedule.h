/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaSchedule
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "LevelSequence.h"
#include "CoreUObject.h"

// Size: 0x110 (Inherited: 0xe0, Single: 0x30)
class UEpicMediaSchedule : public UActorComponent
{
public:
};

static_assert(sizeof(UEpicMediaSchedule) == 0x110, "Size mismatch for UEpicMediaSchedule");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FEpicMediaScheduleScheduleEntryHourly
{
    int32_t Minutes; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FString VUID; // 0x8 (Size: 0x10, Type: StrProperty)
    int32_t DurationSeconds; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    ULevelSequence* Sequence; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEpicMediaScheduleScheduleEntryHourly) == 0x28, "Size mismatch for FEpicMediaScheduleScheduleEntryHourly");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryHourly, Minutes) == 0x0, "Offset mismatch for FEpicMediaScheduleScheduleEntryHourly::Minutes");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryHourly, VUID) == 0x8, "Offset mismatch for FEpicMediaScheduleScheduleEntryHourly::VUID");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryHourly, DurationSeconds) == 0x18, "Offset mismatch for FEpicMediaScheduleScheduleEntryHourly::DurationSeconds");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryHourly, Sequence) == 0x20, "Offset mismatch for FEpicMediaScheduleScheduleEntryHourly::Sequence");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FEpicMediaScheduleScheduleEntryDaily
{
    int32_t Hours; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Minutes; // 0x4 (Size: 0x4, Type: IntProperty)
    FString VUID; // 0x8 (Size: 0x10, Type: StrProperty)
    int32_t DurationSeconds; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    ULevelSequence* Sequence; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEpicMediaScheduleScheduleEntryDaily) == 0x28, "Size mismatch for FEpicMediaScheduleScheduleEntryDaily");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryDaily, Hours) == 0x0, "Offset mismatch for FEpicMediaScheduleScheduleEntryDaily::Hours");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryDaily, Minutes) == 0x4, "Offset mismatch for FEpicMediaScheduleScheduleEntryDaily::Minutes");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryDaily, VUID) == 0x8, "Offset mismatch for FEpicMediaScheduleScheduleEntryDaily::VUID");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryDaily, DurationSeconds) == 0x18, "Offset mismatch for FEpicMediaScheduleScheduleEntryDaily::DurationSeconds");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryDaily, Sequence) == 0x20, "Offset mismatch for FEpicMediaScheduleScheduleEntryDaily::Sequence");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEpicMediaScheduleScheduleEntryAbsolute
{
    FString IsoStartTime; // 0x0 (Size: 0x10, Type: StrProperty)
    FString VUID; // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t DurationSeconds; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    ULevelSequence* Sequence; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEpicMediaScheduleScheduleEntryAbsolute) == 0x30, "Size mismatch for FEpicMediaScheduleScheduleEntryAbsolute");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryAbsolute, IsoStartTime) == 0x0, "Offset mismatch for FEpicMediaScheduleScheduleEntryAbsolute::IsoStartTime");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryAbsolute, VUID) == 0x10, "Offset mismatch for FEpicMediaScheduleScheduleEntryAbsolute::VUID");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryAbsolute, DurationSeconds) == 0x20, "Offset mismatch for FEpicMediaScheduleScheduleEntryAbsolute::DurationSeconds");
static_assert(offsetof(FEpicMediaScheduleScheduleEntryAbsolute, Sequence) == 0x28, "Offset mismatch for FEpicMediaScheduleScheduleEntryAbsolute::Sequence");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FEpicMediaScheduleScheduleInfo
{
    FDateTime StartTime; // 0x0 (Size: 0x8, Type: StructProperty)
    FTimespan RelativeStartTime; // 0x8 (Size: 0x8, Type: StructProperty)
    FString VUID; // 0x10 (Size: 0x10, Type: StrProperty)
    ULevelSequence* Sequence; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEpicMediaScheduleScheduleInfo) == 0x28, "Size mismatch for FEpicMediaScheduleScheduleInfo");
static_assert(offsetof(FEpicMediaScheduleScheduleInfo, StartTime) == 0x0, "Offset mismatch for FEpicMediaScheduleScheduleInfo::StartTime");
static_assert(offsetof(FEpicMediaScheduleScheduleInfo, RelativeStartTime) == 0x8, "Offset mismatch for FEpicMediaScheduleScheduleInfo::RelativeStartTime");
static_assert(offsetof(FEpicMediaScheduleScheduleInfo, VUID) == 0x10, "Offset mismatch for FEpicMediaScheduleScheduleInfo::VUID");
static_assert(offsetof(FEpicMediaScheduleScheduleInfo, Sequence) == 0x20, "Offset mismatch for FEpicMediaScheduleScheduleInfo::Sequence");

