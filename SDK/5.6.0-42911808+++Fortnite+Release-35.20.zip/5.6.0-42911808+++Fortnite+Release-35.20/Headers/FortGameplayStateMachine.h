/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortGameplayStateMachine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayStateMachine.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"

// Size: 0x88 (Inherited: 0xa0, Single: 0xffffffe8)
class UFortGameplayState : public UGameplayState
{
public:
    FText StateDisplayName; // 0x78 (Size: 0x10, Type: TextProperty)

public:
    UFortGameplayStateMachine* GetFortGameplayStateMachine() const; // 0x11a6a484 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetStateDisplayName() const; // 0x11a6a500 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual FText GetStateExtraStatusText() const; // 0x11a6a628 (Index: 0x2, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UFortGameplayState) == 0x88, "Size mismatch for UFortGameplayState");
static_assert(offsetof(UFortGameplayState, StateDisplayName) == 0x78, "Offset mismatch for UFortGameplayState::StateDisplayName");

// Size: 0xf0 (Inherited: 0x168, Single: 0xffffff88)
class UFortGameplayStateMachine : public UGameplayStateMachine
{
public:
    uint8_t Pad_c8[0x10]; // 0xc8 (Size: 0x10, Type: PaddingProperty)
    FFortGameplayStateTransitionData RootTransitionData; // 0xd8 (Size: 0x18, Type: StructProperty)

public:
    UFortGameplayState* GetActiveLeafGameplayStateDefaultObject() const; // 0x11a6a410 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetActiveLeafGameplayStateId() const; // 0x11a6a434 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFortGameplayState* GetActiveLeafGameplayStateObject() const; // 0x11a6a460 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetRemainingTransitionTime() const; // 0x11a6a4d8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetStateDisplayName(const FGameplayTag InStateId) const; // 0x11a6a51c (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool HasGameplayState(const FGameplayTag InStateId) const; // 0x11a6a668 (Index: 0x5, Flags: Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool IsRootStateMachine() const; // 0xdd06dc4 (Index: 0x6, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsTransitionActive() const; // 0x11a6a760 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void OnLeafStateChanged_BP(const FGameplayTag OldLeafStateId, const FGameplayTag NewLeafStateId); // 0x288a61c (Index: 0x8, Flags: Event|Public|HasOutParms|BlueprintEvent)
    void OnRep_RootTransitionData(); // 0x11a6a784 (Index: 0x9, Flags: Final|Native|Public)
    virtual void OnStateChanged_BP(const FGameplayTag OldStateId, const FGameplayTag NewStateId); // 0x288a61c (Index: 0xa, Flags: Event|Public|HasOutParms|BlueprintEvent)
    bool StartStateTransition(const FGameplayTag NewStateId, float& TransitionTime); // 0x11a6a798 (Index: 0xb, Flags: Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UFortGameplayStateMachine) == 0xf0, "Size mismatch for UFortGameplayStateMachine");
static_assert(offsetof(UFortGameplayStateMachine, RootTransitionData) == 0xd8, "Offset mismatch for UFortGameplayStateMachine::RootTransitionData");

// Size: 0x1d8 (Inherited: 0x2b8, Single: 0xffffff20)
class UFortGameplayStateMachineManager : public UGameplayStateMachineManager
{
public:
};

static_assert(sizeof(UFortGameplayStateMachineManager) == 0x1d8, "Size mismatch for UFortGameplayStateMachineManager");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortGameplayStateChanged
{
    UFortGameplayStateMachine* StateMachine; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag OldStateId; // 0x8 (Size: 0x4, Type: StructProperty)
    FGameplayTag NewStateId; // 0xc (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FFortGameplayStateChanged) == 0x10, "Size mismatch for FFortGameplayStateChanged");
static_assert(offsetof(FFortGameplayStateChanged, StateMachine) == 0x0, "Offset mismatch for FFortGameplayStateChanged::StateMachine");
static_assert(offsetof(FFortGameplayStateChanged, OldStateId) == 0x8, "Offset mismatch for FFortGameplayStateChanged::OldStateId");
static_assert(offsetof(FFortGameplayStateChanged, NewStateId) == 0xc, "Offset mismatch for FFortGameplayStateChanged::NewStateId");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortLeafGameplayStateChanged
{
    UFortGameplayStateMachine* RootStateMachine; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag OldLeafStateId; // 0x8 (Size: 0x4, Type: StructProperty)
    FGameplayTag NewLeafStateId; // 0xc (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FFortLeafGameplayStateChanged) == 0x10, "Size mismatch for FFortLeafGameplayStateChanged");
static_assert(offsetof(FFortLeafGameplayStateChanged, RootStateMachine) == 0x0, "Offset mismatch for FFortLeafGameplayStateChanged::RootStateMachine");
static_assert(offsetof(FFortLeafGameplayStateChanged, OldLeafStateId) == 0x8, "Offset mismatch for FFortLeafGameplayStateChanged::OldLeafStateId");
static_assert(offsetof(FFortLeafGameplayStateChanged, NewLeafStateId) == 0xc, "Offset mismatch for FFortLeafGameplayStateChanged::NewLeafStateId");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortGameplayStateTransitionData
{
    UFortGameplayStateMachine* TargetStateMachine; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag TargetStateId; // 0x8 (Size: 0x4, Type: StructProperty)
    float TransitionStartServerTime; // 0xc (Size: 0x4, Type: FloatProperty)
    float TransitionEndServerTime; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortGameplayStateTransitionData) == 0x18, "Size mismatch for FFortGameplayStateTransitionData");
static_assert(offsetof(FFortGameplayStateTransitionData, TargetStateMachine) == 0x0, "Offset mismatch for FFortGameplayStateTransitionData::TargetStateMachine");
static_assert(offsetof(FFortGameplayStateTransitionData, TargetStateId) == 0x8, "Offset mismatch for FFortGameplayStateTransitionData::TargetStateId");
static_assert(offsetof(FFortGameplayStateTransitionData, TransitionStartServerTime) == 0xc, "Offset mismatch for FFortGameplayStateTransitionData::TransitionStartServerTime");
static_assert(offsetof(FFortGameplayStateTransitionData, TransitionEndServerTime) == 0x10, "Offset mismatch for FFortGameplayStateTransitionData::TransitionEndServerTime");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRootStateMachineData
{
};

static_assert(sizeof(FRootStateMachineData) == 0x10, "Size mismatch for FRootStateMachineData");

// Size: 0x18 (Inherited: 0x18, Single: 0x0)
struct FFortGameplayStateTransitionStarted : FFortGameplayStateTransitionData
{
};

static_assert(sizeof(FFortGameplayStateTransitionStarted) == 0x18, "Size mismatch for FFortGameplayStateTransitionStarted");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FFortGameplayStateTransitionEnded
{
};

static_assert(sizeof(FFortGameplayStateTransitionEnded) == 0x1, "Size mismatch for FFortGameplayStateTransitionEnded");

