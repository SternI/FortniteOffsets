/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRDPostProcess
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "NetCore.h"
#include "FortniteGame.h"

// Size: 0x110 (Inherited: 0xe0, Single: 0x30)
class UCRDPostProcessDeviceComponent : public UActorComponent
{
public:
    UPostProcessComponent* PostProcessComponent; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    APlayerController* BlendInstigator; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c8[0x48]; // 0xc8 (Size: 0x48, Type: PaddingProperty)

public:
    bool ApplyPostProcessSettingsToDeviceComponent(UClass*& const ActorClass, bool& const bInEnabled, float& const InMaxStrength, int32_t& const InPriority, float& const InEffectDuration, float& const InBlendInDuration, float& const InBlendOutDuration); // 0x11e7a478 (Index: 0x0, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    float GetBlendInTime() const; // 0xafc7f10 (Index: 0x1, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetBlendOutTime() const; // 0xcef185c (Index: 0x2, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetClientEnabled() const; // 0xd4b4138 (Index: 0x3, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCurrentStrength() const; // 0xa287650 (Index: 0x4, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetPriority() const; // 0xa32d2c0 (Index: 0x5, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetCurrentStrength(float& Value); // 0x11e7bf54 (Index: 0x6, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void SetHiddenStrength(float& Value); // 0x11e7c08c (Index: 0x7, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void SetPostProcessEnabled(bool& bEnabled); // 0x11e7c1b8 (Index: 0x8, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void StartBlending(APlayerController*& InBlendInstigator, bool& bBlendIn, float& duration); // 0x11e7c2f8 (Index: 0x9, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void StartBlendingFromPriority(bool& bShouldHide, float& duration); // 0x11e7c5e0 (Index: 0xa, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void StartEffectTimer(APlayerController*& InBlendInstigator); // 0x11e7c7f8 (Index: 0xb, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCRDPostProcessDeviceComponent) == 0x110, "Size mismatch for UCRDPostProcessDeviceComponent");
static_assert(offsetof(UCRDPostProcessDeviceComponent, PostProcessComponent) == 0xb8, "Offset mismatch for UCRDPostProcessDeviceComponent::PostProcessComponent");
static_assert(offsetof(UCRDPostProcessDeviceComponent, BlendInstigator) == 0xc0, "Offset mismatch for UCRDPostProcessDeviceComponent::BlendInstigator");

// Size: 0xc8 (Inherited: 0xe0, Single: 0xffffffe8)
class UCRDPostProcessDevicePriorityControllerComponent : public UActorComponent
{
public:
    TArray<UCRDPostProcessDeviceComponent*> CachedAppliedEffects; // 0xb8 (Size: 0x10, Type: ArrayProperty)

public:
    void CachePostProcessDeviceApplication(UCRDPostProcessDeviceComponent*& InPostProcessDeviceComponent); // 0x11e7ad78 (Index: 0x0, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    void GetEffectsForPriority(int32_t& Priority, TArray<UCRDPostProcessDeviceComponent*>& OutEffects); // 0x11e7aef0 (Index: 0x1, Flags: Final|BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    int32_t GetHighestPriorityValue(); // 0x11e7b260 (Index: 0x2, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure)
    static UCRDPostProcessDevicePriorityControllerComponent* GetPostProcessDevicePriorityControllerComponentFromPlayerController(APlayerController*& PC, bool& bCreateIfNotFound); // 0x11e7b6dc (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    void RemovePostProcessDevice(UCRDPostProcessDeviceComponent*& InPostProcessDeviceComponent); // 0x11e7bb28 (Index: 0x4, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCRDPostProcessDevicePriorityControllerComponent) == 0xc8, "Size mismatch for UCRDPostProcessDevicePriorityControllerComponent");
static_assert(offsetof(UCRDPostProcessDevicePriorityControllerComponent, CachedAppliedEffects) == 0xb8, "Offset mismatch for UCRDPostProcessDevicePriorityControllerComponent::CachedAppliedEffects");

// Size: 0x248 (Inherited: 0xe0, Single: 0x168)
class UCRDPostProcessDeviceControllerComponent : public UActorComponent
{
public:
    uint8_t OnPostProcessDeviceMessageRecieved[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPostProcessDeviceBlendFinished[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FPostProcessDeviceMessageRingBuffer PostProcessDeviceMessageBatch; // 0xd8 (Size: 0x130, Type: StructProperty)
    uint8_t Pad_208[0x8]; // 0x208 (Size: 0x8, Type: PaddingProperty)
    TArray<FPostProcessDeviceMessage> PostProcessDeviceMessageQueue; // 0x210 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_220[0x28]; // 0x220 (Size: 0x28, Type: PaddingProperty)

public:
    static void GetMinigamePlayersForPostProcessDevice(AFortMinigame*& const FortMinigame, TArray<APlayerState*>& OutPlayers); // 0xceb149c (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UCRDPostProcessDeviceControllerComponent* GetPostProcessDeviceControllerComponentFromPlayerController(APlayerController*& PC, bool& bCreateIfNotFound); // 0x11e7b290 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    void Reset(); // 0x11e7bc64 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    virtual void ServerBlendFinished(AFortCreativeDeviceProp*& const PostProcessDevice, APlayerController*& const Instigator, bool& bBlendIn); // 0x11e7bc78 (Index: 0x5, Flags: Net|NetReliableNative|Event|Public|NetServer)

private:
    void OnRep_PostProcessDeviceMessageBatch(); // 0x43388fc (Index: 0x3, Flags: Final|Native|Private)

protected:
    void AddBlendMessageToQueue(AFortCreativeDeviceProp*& const PostProcessDevice, AFortPlayerState*& const PlayerStateMessage, EPostProcessDeviceState& const EndState); // 0x11e7a194 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UCRDPostProcessDeviceControllerComponent) == 0x248, "Size mismatch for UCRDPostProcessDeviceControllerComponent");
static_assert(offsetof(UCRDPostProcessDeviceControllerComponent, OnPostProcessDeviceMessageRecieved) == 0xb8, "Offset mismatch for UCRDPostProcessDeviceControllerComponent::OnPostProcessDeviceMessageRecieved");
static_assert(offsetof(UCRDPostProcessDeviceControllerComponent, OnPostProcessDeviceBlendFinished) == 0xc8, "Offset mismatch for UCRDPostProcessDeviceControllerComponent::OnPostProcessDeviceBlendFinished");
static_assert(offsetof(UCRDPostProcessDeviceControllerComponent, PostProcessDeviceMessageBatch) == 0xd8, "Offset mismatch for UCRDPostProcessDeviceControllerComponent::PostProcessDeviceMessageBatch");
static_assert(offsetof(UCRDPostProcessDeviceControllerComponent, PostProcessDeviceMessageQueue) == 0x210, "Offset mismatch for UCRDPostProcessDeviceControllerComponent::PostProcessDeviceMessageQueue");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FPostProcessDeviceMessage
{
    AFortCreativeDeviceProp* PostProcessDevice; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerState* PlayerStateMessage; // 0x8 (Size: 0x8, Type: ObjectProperty)
    uint8_t EndState; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FPostProcessDeviceMessage) == 0x18, "Size mismatch for FPostProcessDeviceMessage");
static_assert(offsetof(FPostProcessDeviceMessage, PostProcessDevice) == 0x0, "Offset mismatch for FPostProcessDeviceMessage::PostProcessDevice");
static_assert(offsetof(FPostProcessDeviceMessage, PlayerStateMessage) == 0x8, "Offset mismatch for FPostProcessDeviceMessage::PlayerStateMessage");
static_assert(offsetof(FPostProcessDeviceMessage, EndState) == 0x10, "Offset mismatch for FPostProcessDeviceMessage::EndState");

// Size: 0x28 (Inherited: 0xc, Single: 0x1c)
struct FPostProcessDeviceMessageRepl : FFastArraySerializerItem
{
    int32_t MessageIndex; // 0xc (Size: 0x4, Type: IntProperty)
    AFortCreativeDeviceProp* PostProcessDevice; // 0x10 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerState* PlayerStateMessage; // 0x18 (Size: 0x8, Type: ObjectProperty)
    uint8_t EndState; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FPostProcessDeviceMessageRepl) == 0x28, "Size mismatch for FPostProcessDeviceMessageRepl");
static_assert(offsetof(FPostProcessDeviceMessageRepl, MessageIndex) == 0xc, "Offset mismatch for FPostProcessDeviceMessageRepl::MessageIndex");
static_assert(offsetof(FPostProcessDeviceMessageRepl, PostProcessDevice) == 0x10, "Offset mismatch for FPostProcessDeviceMessageRepl::PostProcessDevice");
static_assert(offsetof(FPostProcessDeviceMessageRepl, PlayerStateMessage) == 0x18, "Offset mismatch for FPostProcessDeviceMessageRepl::PlayerStateMessage");
static_assert(offsetof(FPostProcessDeviceMessageRepl, EndState) == 0x20, "Offset mismatch for FPostProcessDeviceMessageRepl::EndState");

// Size: 0x130 (Inherited: 0x108, Single: 0x28)
struct FPostProcessDeviceMessageRingBuffer : FFastArraySerializer
{
    TArray<FPostProcessDeviceMessageRepl> Items; // 0x108 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_118[0x18]; // 0x118 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FPostProcessDeviceMessageRingBuffer) == 0x130, "Size mismatch for FPostProcessDeviceMessageRingBuffer");
static_assert(offsetof(FPostProcessDeviceMessageRingBuffer, Items) == 0x108, "Offset mismatch for FPostProcessDeviceMessageRingBuffer::Items");

