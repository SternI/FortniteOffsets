/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityCategoryTilePanelBase_VM
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUI.h"
#include "FortniteUI.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "DiscoveryBrowserUI.h"
#include "UMG.h"

// Size: 0x328 (Inherited: 0x730, Single: 0xfffffbf8)
class UActivityCategoryTilePanelBase_VM_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2d8 (Size: 0x8, Type: StructProperty)
    UVerticalBox* VerticalBox_Content; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UFortActivityTileView* TileView_Categories; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Title; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ActiveInactivate; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnMoveUpOutOfView; // 0x300 (Size: 0x8, Type: ObjectProperty)
    double EntryHeight; // 0x308 (Size: 0x8, Type: DoubleProperty)
    double EntryWidth; // 0x310 (Size: 0x8, Type: DoubleProperty)
    uint8_t OnPanelItemClicked[0x10]; // 0x318 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void Set_Panel_Display_Name(FText& In_Panel_Name); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Categories(TArray<UFortDiscoverTileItemVM*> In_Categories); // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x3, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void OnPanelItemClicked__DelegateSignature(); // 0x288a61c (Index: 0x4, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void OnInitialized(); // 0x288a61c (Index: 0x6, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0xb, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UActivityCategoryTilePanelBase_VM_C) == 0x328, "Size mismatch for UActivityCategoryTilePanelBase_VM_C");
static_assert(offsetof(UActivityCategoryTilePanelBase_VM_C, UberGraphFrame) == 0x2d8, "Offset mismatch for UActivityCategoryTilePanelBase_VM_C::UberGraphFrame");
static_assert(offsetof(UActivityCategoryTilePanelBase_VM_C, VerticalBox_Content) == 0x2e0, "Offset mismatch for UActivityCategoryTilePanelBase_VM_C::VerticalBox_Content");
static_assert(offsetof(UActivityCategoryTilePanelBase_VM_C, TileView_Categories) == 0x2e8, "Offset mismatch for UActivityCategoryTilePanelBase_VM_C::TileView_Categories");
static_assert(offsetof(UActivityCategoryTilePanelBase_VM_C, Text_Title) == 0x2f0, "Offset mismatch for UActivityCategoryTilePanelBase_VM_C::Text_Title");
static_assert(offsetof(UActivityCategoryTilePanelBase_VM_C, ActiveInactivate) == 0x2f8, "Offset mismatch for UActivityCategoryTilePanelBase_VM_C::ActiveInactivate");
static_assert(offsetof(UActivityCategoryTilePanelBase_VM_C, OnMoveUpOutOfView) == 0x300, "Offset mismatch for UActivityCategoryTilePanelBase_VM_C::OnMoveUpOutOfView");
static_assert(offsetof(UActivityCategoryTilePanelBase_VM_C, EntryHeight) == 0x308, "Offset mismatch for UActivityCategoryTilePanelBase_VM_C::EntryHeight");
static_assert(offsetof(UActivityCategoryTilePanelBase_VM_C, EntryWidth) == 0x310, "Offset mismatch for UActivityCategoryTilePanelBase_VM_C::EntryWidth");
static_assert(offsetof(UActivityCategoryTilePanelBase_VM_C, OnPanelItemClicked) == 0x318, "Offset mismatch for UActivityCategoryTilePanelBase_VM_C::OnPanelItemClicked");

