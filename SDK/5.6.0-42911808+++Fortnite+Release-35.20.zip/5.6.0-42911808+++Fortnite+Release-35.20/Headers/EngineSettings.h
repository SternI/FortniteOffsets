/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EngineSettings
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"

// Size: 0x70 (Inherited: 0x28, Single: 0x48)
class UConsoleSettings : public UObject
{
public:
    int32_t MaxScrollbackSize; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    TArray<FAutoCompleteCommand> ManualAutoCompleteList; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> AutoCompleteMapPaths; // 0x40 (Size: 0x10, Type: ArrayProperty)
    float BackgroundOpacityPercentage; // 0x50 (Size: 0x4, Type: FloatProperty)
    bool bOrderTopToBottom; // 0x54 (Size: 0x1, Type: BoolProperty)
    bool bDisplayHelpInAutoComplete; // 0x55 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_56[0x2]; // 0x56 (Size: 0x2, Type: PaddingProperty)
    FColor InputColor; // 0x58 (Size: 0x4, Type: StructProperty)
    FColor HistoryColor; // 0x5c (Size: 0x4, Type: StructProperty)
    FColor AutoCompleteCommandColor; // 0x60 (Size: 0x4, Type: StructProperty)
    FColor AutoCompleteCVarColor; // 0x64 (Size: 0x4, Type: StructProperty)
    FColor AutoCompleteFadedColor; // 0x68 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UConsoleSettings) == 0x70, "Size mismatch for UConsoleSettings");
static_assert(offsetof(UConsoleSettings, MaxScrollbackSize) == 0x28, "Offset mismatch for UConsoleSettings::MaxScrollbackSize");
static_assert(offsetof(UConsoleSettings, ManualAutoCompleteList) == 0x30, "Offset mismatch for UConsoleSettings::ManualAutoCompleteList");
static_assert(offsetof(UConsoleSettings, AutoCompleteMapPaths) == 0x40, "Offset mismatch for UConsoleSettings::AutoCompleteMapPaths");
static_assert(offsetof(UConsoleSettings, BackgroundOpacityPercentage) == 0x50, "Offset mismatch for UConsoleSettings::BackgroundOpacityPercentage");
static_assert(offsetof(UConsoleSettings, bOrderTopToBottom) == 0x54, "Offset mismatch for UConsoleSettings::bOrderTopToBottom");
static_assert(offsetof(UConsoleSettings, bDisplayHelpInAutoComplete) == 0x55, "Offset mismatch for UConsoleSettings::bDisplayHelpInAutoComplete");
static_assert(offsetof(UConsoleSettings, InputColor) == 0x58, "Offset mismatch for UConsoleSettings::InputColor");
static_assert(offsetof(UConsoleSettings, HistoryColor) == 0x5c, "Offset mismatch for UConsoleSettings::HistoryColor");
static_assert(offsetof(UConsoleSettings, AutoCompleteCommandColor) == 0x60, "Offset mismatch for UConsoleSettings::AutoCompleteCommandColor");
static_assert(offsetof(UConsoleSettings, AutoCompleteCVarColor) == 0x64, "Offset mismatch for UConsoleSettings::AutoCompleteCVarColor");
static_assert(offsetof(UConsoleSettings, AutoCompleteFadedColor) == 0x68, "Offset mismatch for UConsoleSettings::AutoCompleteFadedColor");

// Size: 0xf0 (Inherited: 0x28, Single: 0xc8)
class UGameMapsSettings : public UObject
{
public:
    FString LocalMapOptions; // 0x28 (Size: 0x10, Type: StrProperty)
    FSoftObjectPath TransitionMap; // 0x38 (Size: 0x18, Type: StructProperty)
    bool bUseSplitscreen; // 0x50 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ETwoPlayerSplitScreenType> TwoPlayerSplitscreenLayout; // 0x51 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EThreePlayerSplitScreenType> ThreePlayerSplitscreenLayout; // 0x52 (Size: 0x1, Type: ByteProperty)
    uint8_t FourPlayerSplitscreenLayout; // 0x53 (Size: 0x1, Type: EnumProperty)
    bool bOffsetPlayerGamepadIds; // 0x54 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_55[0x3]; // 0x55 (Size: 0x3, Type: PaddingProperty)
    FSoftClassPath GameInstanceClass; // 0x58 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath GameDefaultMap; // 0x70 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath ServerDefaultMap; // 0x88 (Size: 0x18, Type: StructProperty)
    FSoftClassPath GlobalDefaultGameMode; // 0xa0 (Size: 0x18, Type: StructProperty)
    FSoftClassPath GlobalDefaultServerGameMode; // 0xb8 (Size: 0x18, Type: StructProperty)
    TArray<FGameModeName> GameModeMapPrefixes; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameModeName> GameModeClassAliases; // 0xe0 (Size: 0x10, Type: ArrayProperty)

public:
    static UGameMapsSettings* GetGameMapsSettings(); // 0x93a740c (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    bool GetSkipAssigningGamepadToPlayer1() const; // 0x93a743c (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetSkipAssigningGamepadToPlayer1(bool& bSkipFirstPlayer); // 0x93a7450 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UGameMapsSettings) == 0xf0, "Size mismatch for UGameMapsSettings");
static_assert(offsetof(UGameMapsSettings, LocalMapOptions) == 0x28, "Offset mismatch for UGameMapsSettings::LocalMapOptions");
static_assert(offsetof(UGameMapsSettings, TransitionMap) == 0x38, "Offset mismatch for UGameMapsSettings::TransitionMap");
static_assert(offsetof(UGameMapsSettings, bUseSplitscreen) == 0x50, "Offset mismatch for UGameMapsSettings::bUseSplitscreen");
static_assert(offsetof(UGameMapsSettings, TwoPlayerSplitscreenLayout) == 0x51, "Offset mismatch for UGameMapsSettings::TwoPlayerSplitscreenLayout");
static_assert(offsetof(UGameMapsSettings, ThreePlayerSplitscreenLayout) == 0x52, "Offset mismatch for UGameMapsSettings::ThreePlayerSplitscreenLayout");
static_assert(offsetof(UGameMapsSettings, FourPlayerSplitscreenLayout) == 0x53, "Offset mismatch for UGameMapsSettings::FourPlayerSplitscreenLayout");
static_assert(offsetof(UGameMapsSettings, bOffsetPlayerGamepadIds) == 0x54, "Offset mismatch for UGameMapsSettings::bOffsetPlayerGamepadIds");
static_assert(offsetof(UGameMapsSettings, GameInstanceClass) == 0x58, "Offset mismatch for UGameMapsSettings::GameInstanceClass");
static_assert(offsetof(UGameMapsSettings, GameDefaultMap) == 0x70, "Offset mismatch for UGameMapsSettings::GameDefaultMap");
static_assert(offsetof(UGameMapsSettings, ServerDefaultMap) == 0x88, "Offset mismatch for UGameMapsSettings::ServerDefaultMap");
static_assert(offsetof(UGameMapsSettings, GlobalDefaultGameMode) == 0xa0, "Offset mismatch for UGameMapsSettings::GlobalDefaultGameMode");
static_assert(offsetof(UGameMapsSettings, GlobalDefaultServerGameMode) == 0xb8, "Offset mismatch for UGameMapsSettings::GlobalDefaultServerGameMode");
static_assert(offsetof(UGameMapsSettings, GameModeMapPrefixes) == 0xd0, "Offset mismatch for UGameMapsSettings::GameModeMapPrefixes");
static_assert(offsetof(UGameMapsSettings, GameModeClassAliases) == 0xe0, "Offset mismatch for UGameMapsSettings::GameModeClassAliases");

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
class UGameNetworkManagerSettings : public UObject
{
public:
    int32_t MinDynamicBandwidth; // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t MaxDynamicBandwidth; // 0x2c (Size: 0x4, Type: IntProperty)
    int32_t TotalNetBandwidth; // 0x30 (Size: 0x4, Type: IntProperty)
    int32_t BadPingThreshold; // 0x34 (Size: 0x4, Type: IntProperty)
    uint8_t bIsStandbyCheckingEnabled : 1; // 0x38:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    float StandbyRxCheatTime; // 0x3c (Size: 0x4, Type: FloatProperty)
    float StandbyTxCheatTime; // 0x40 (Size: 0x4, Type: FloatProperty)
    float PercentMissingForRxStandby; // 0x44 (Size: 0x4, Type: FloatProperty)
    float PercentMissingForTxStandby; // 0x48 (Size: 0x4, Type: FloatProperty)
    float PercentForBadPing; // 0x4c (Size: 0x4, Type: FloatProperty)
    float JoinInProgressStandbyWaitTime; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UGameNetworkManagerSettings) == 0x58, "Size mismatch for UGameNetworkManagerSettings");
static_assert(offsetof(UGameNetworkManagerSettings, MinDynamicBandwidth) == 0x28, "Offset mismatch for UGameNetworkManagerSettings::MinDynamicBandwidth");
static_assert(offsetof(UGameNetworkManagerSettings, MaxDynamicBandwidth) == 0x2c, "Offset mismatch for UGameNetworkManagerSettings::MaxDynamicBandwidth");
static_assert(offsetof(UGameNetworkManagerSettings, TotalNetBandwidth) == 0x30, "Offset mismatch for UGameNetworkManagerSettings::TotalNetBandwidth");
static_assert(offsetof(UGameNetworkManagerSettings, BadPingThreshold) == 0x34, "Offset mismatch for UGameNetworkManagerSettings::BadPingThreshold");
static_assert(offsetof(UGameNetworkManagerSettings, bIsStandbyCheckingEnabled) == 0x38, "Offset mismatch for UGameNetworkManagerSettings::bIsStandbyCheckingEnabled");
static_assert(offsetof(UGameNetworkManagerSettings, StandbyRxCheatTime) == 0x3c, "Offset mismatch for UGameNetworkManagerSettings::StandbyRxCheatTime");
static_assert(offsetof(UGameNetworkManagerSettings, StandbyTxCheatTime) == 0x40, "Offset mismatch for UGameNetworkManagerSettings::StandbyTxCheatTime");
static_assert(offsetof(UGameNetworkManagerSettings, PercentMissingForRxStandby) == 0x44, "Offset mismatch for UGameNetworkManagerSettings::PercentMissingForRxStandby");
static_assert(offsetof(UGameNetworkManagerSettings, PercentMissingForTxStandby) == 0x48, "Offset mismatch for UGameNetworkManagerSettings::PercentMissingForTxStandby");
static_assert(offsetof(UGameNetworkManagerSettings, PercentForBadPing) == 0x4c, "Offset mismatch for UGameNetworkManagerSettings::PercentForBadPing");
static_assert(offsetof(UGameNetworkManagerSettings, JoinInProgressStandbyWaitTime) == 0x50, "Offset mismatch for UGameNetworkManagerSettings::JoinInProgressStandbyWaitTime");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UGameSessionSettings : public UObject
{
public:
    int32_t MaxSpectators; // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t MaxPlayers; // 0x2c (Size: 0x4, Type: IntProperty)
    uint8_t bRequiresPushToTalk : 1; // 0x30:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UGameSessionSettings) == 0x38, "Size mismatch for UGameSessionSettings");
static_assert(offsetof(UGameSessionSettings, MaxSpectators) == 0x28, "Offset mismatch for UGameSessionSettings::MaxSpectators");
static_assert(offsetof(UGameSessionSettings, MaxPlayers) == 0x2c, "Offset mismatch for UGameSessionSettings::MaxPlayers");
static_assert(offsetof(UGameSessionSettings, bRequiresPushToTalk) == 0x30, "Offset mismatch for UGameSessionSettings::bRequiresPushToTalk");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UGeneralEngineSettings : public UObject
{
public:
};

static_assert(sizeof(UGeneralEngineSettings) == 0x28, "Size mismatch for UGeneralEngineSettings");

// Size: 0x110 (Inherited: 0x28, Single: 0xe8)
class UGeneralProjectSettings : public UObject
{
public:
    FString CompanyName; // 0x28 (Size: 0x10, Type: StrProperty)
    FString CompanyDistinguishedName; // 0x38 (Size: 0x10, Type: StrProperty)
    FString CopyrightNotice; // 0x48 (Size: 0x10, Type: StrProperty)
    FString Description; // 0x58 (Size: 0x10, Type: StrProperty)
    FString Homepage; // 0x68 (Size: 0x10, Type: StrProperty)
    FString LicensingTerms; // 0x78 (Size: 0x10, Type: StrProperty)
    FString PrivacyPolicy; // 0x88 (Size: 0x10, Type: StrProperty)
    FGuid ProjectID; // 0x98 (Size: 0x10, Type: StructProperty)
    FString ProjectName; // 0xa8 (Size: 0x10, Type: StrProperty)
    FString ProjectVersion; // 0xb8 (Size: 0x10, Type: StrProperty)
    FString SupportContact; // 0xc8 (Size: 0x10, Type: StrProperty)
    FText ProjectDisplayedTitle; // 0xd8 (Size: 0x10, Type: TextProperty)
    FText ProjectDebugTitleInfo; // 0xe8 (Size: 0x10, Type: TextProperty)
    bool bShouldWindowPreserveAspectRatio; // 0xf8 (Size: 0x1, Type: BoolProperty)
    bool bUseBorderlessWindow; // 0xf9 (Size: 0x1, Type: BoolProperty)
    bool bStartInVR; // 0xfa (Size: 0x1, Type: BoolProperty)
    bool bAllowWindowResize; // 0xfb (Size: 0x1, Type: BoolProperty)
    bool bAllowClose; // 0xfc (Size: 0x1, Type: BoolProperty)
    bool bAllowMaximize; // 0xfd (Size: 0x1, Type: BoolProperty)
    bool bAllowMinimize; // 0xfe (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ff[0x1]; // 0xff (Size: 0x1, Type: PaddingProperty)
    float EyeOffsetForFakeStereoRenderingDevice; // 0x100 (Size: 0x4, Type: FloatProperty)
    float FOVForFakeStereoRenderingDevice; // 0x104 (Size: 0x4, Type: FloatProperty)
    float TopFOVRatioForFakeStereoRenderingDevice; // 0x108 (Size: 0x4, Type: FloatProperty)
    float DifferenceBetweenEyesForFakeStereoRenderingDevice; // 0x10c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UGeneralProjectSettings) == 0x110, "Size mismatch for UGeneralProjectSettings");
static_assert(offsetof(UGeneralProjectSettings, CompanyName) == 0x28, "Offset mismatch for UGeneralProjectSettings::CompanyName");
static_assert(offsetof(UGeneralProjectSettings, CompanyDistinguishedName) == 0x38, "Offset mismatch for UGeneralProjectSettings::CompanyDistinguishedName");
static_assert(offsetof(UGeneralProjectSettings, CopyrightNotice) == 0x48, "Offset mismatch for UGeneralProjectSettings::CopyrightNotice");
static_assert(offsetof(UGeneralProjectSettings, Description) == 0x58, "Offset mismatch for UGeneralProjectSettings::Description");
static_assert(offsetof(UGeneralProjectSettings, Homepage) == 0x68, "Offset mismatch for UGeneralProjectSettings::Homepage");
static_assert(offsetof(UGeneralProjectSettings, LicensingTerms) == 0x78, "Offset mismatch for UGeneralProjectSettings::LicensingTerms");
static_assert(offsetof(UGeneralProjectSettings, PrivacyPolicy) == 0x88, "Offset mismatch for UGeneralProjectSettings::PrivacyPolicy");
static_assert(offsetof(UGeneralProjectSettings, ProjectID) == 0x98, "Offset mismatch for UGeneralProjectSettings::ProjectID");
static_assert(offsetof(UGeneralProjectSettings, ProjectName) == 0xa8, "Offset mismatch for UGeneralProjectSettings::ProjectName");
static_assert(offsetof(UGeneralProjectSettings, ProjectVersion) == 0xb8, "Offset mismatch for UGeneralProjectSettings::ProjectVersion");
static_assert(offsetof(UGeneralProjectSettings, SupportContact) == 0xc8, "Offset mismatch for UGeneralProjectSettings::SupportContact");
static_assert(offsetof(UGeneralProjectSettings, ProjectDisplayedTitle) == 0xd8, "Offset mismatch for UGeneralProjectSettings::ProjectDisplayedTitle");
static_assert(offsetof(UGeneralProjectSettings, ProjectDebugTitleInfo) == 0xe8, "Offset mismatch for UGeneralProjectSettings::ProjectDebugTitleInfo");
static_assert(offsetof(UGeneralProjectSettings, bShouldWindowPreserveAspectRatio) == 0xf8, "Offset mismatch for UGeneralProjectSettings::bShouldWindowPreserveAspectRatio");
static_assert(offsetof(UGeneralProjectSettings, bUseBorderlessWindow) == 0xf9, "Offset mismatch for UGeneralProjectSettings::bUseBorderlessWindow");
static_assert(offsetof(UGeneralProjectSettings, bStartInVR) == 0xfa, "Offset mismatch for UGeneralProjectSettings::bStartInVR");
static_assert(offsetof(UGeneralProjectSettings, bAllowWindowResize) == 0xfb, "Offset mismatch for UGeneralProjectSettings::bAllowWindowResize");
static_assert(offsetof(UGeneralProjectSettings, bAllowClose) == 0xfc, "Offset mismatch for UGeneralProjectSettings::bAllowClose");
static_assert(offsetof(UGeneralProjectSettings, bAllowMaximize) == 0xfd, "Offset mismatch for UGeneralProjectSettings::bAllowMaximize");
static_assert(offsetof(UGeneralProjectSettings, bAllowMinimize) == 0xfe, "Offset mismatch for UGeneralProjectSettings::bAllowMinimize");
static_assert(offsetof(UGeneralProjectSettings, EyeOffsetForFakeStereoRenderingDevice) == 0x100, "Offset mismatch for UGeneralProjectSettings::EyeOffsetForFakeStereoRenderingDevice");
static_assert(offsetof(UGeneralProjectSettings, FOVForFakeStereoRenderingDevice) == 0x104, "Offset mismatch for UGeneralProjectSettings::FOVForFakeStereoRenderingDevice");
static_assert(offsetof(UGeneralProjectSettings, TopFOVRatioForFakeStereoRenderingDevice) == 0x108, "Offset mismatch for UGeneralProjectSettings::TopFOVRatioForFakeStereoRenderingDevice");
static_assert(offsetof(UGeneralProjectSettings, DifferenceBetweenEyesForFakeStereoRenderingDevice) == 0x10c, "Offset mismatch for UGeneralProjectSettings::DifferenceBetweenEyesForFakeStereoRenderingDevice");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UHudSettings : public UObject
{
public:
    uint8_t bShowHUD : 1; // 0x28:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    TArray<FName> DebugDisplay; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UHudSettings) == 0x40, "Size mismatch for UHudSettings");
static_assert(offsetof(UHudSettings, bShowHUD) == 0x28, "Offset mismatch for UHudSettings::bShowHUD");
static_assert(offsetof(UHudSettings, DebugDisplay) == 0x30, "Offset mismatch for UHudSettings::DebugDisplay");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FAutoCompleteCommand
{
    FString Command; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Desc; // 0x10 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_20[0x8]; // 0x20 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAutoCompleteCommand) == 0x28, "Size mismatch for FAutoCompleteCommand");
static_assert(offsetof(FAutoCompleteCommand, Command) == 0x0, "Offset mismatch for FAutoCompleteCommand::Command");
static_assert(offsetof(FAutoCompleteCommand, Desc) == 0x10, "Offset mismatch for FAutoCompleteCommand::Desc");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameModeName
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FSoftClassPath GameMode; // 0x10 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FGameModeName) == 0x28, "Size mismatch for FGameModeName");
static_assert(offsetof(FGameModeName, Name) == 0x0, "Offset mismatch for FGameModeName::Name");
static_assert(offsetof(FGameModeName, GameMode) == 0x10, "Offset mismatch for FGameModeName::GameMode");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FTemplateMapInfoOverride
{
    FSoftObjectPath Thumbnail; // 0x0 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath Map; // 0x18 (Size: 0x18, Type: StructProperty)
    FText DisplayName; // 0x30 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FTemplateMapInfoOverride) == 0x40, "Size mismatch for FTemplateMapInfoOverride");
static_assert(offsetof(FTemplateMapInfoOverride, Thumbnail) == 0x0, "Offset mismatch for FTemplateMapInfoOverride::Thumbnail");
static_assert(offsetof(FTemplateMapInfoOverride, Map) == 0x18, "Offset mismatch for FTemplateMapInfoOverride::Map");
static_assert(offsetof(FTemplateMapInfoOverride, DisplayName) == 0x30, "Offset mismatch for FTemplateMapInfoOverride::DisplayName");

