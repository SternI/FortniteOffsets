/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BlastBerryRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "ModularGameplay.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "AIModule.h"
#include "GameplayAbilities.h"
#include "SlateCore.h"

// Size: 0x168 (Inherited: 0x310, Single: 0xfffffe58)
class UFortControllerComponent_BlastBerry : public UFortControllerComponent
{
public:
    uint8_t OnLastTeamMemberAliveChanged[0x10]; // 0xc0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnNoRebootsRemaining[0x10]; // 0xd0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTeammateRespawned[0x10]; // 0xe0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTeammateRevived[0x10]; // 0xf0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEnemyTeamEliminated[0x10]; // 0x100 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRespawnReward[0x10]; // 0x110 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_120[0x40]; // 0x120 (Size: 0x40, Type: PaddingProperty)
    bool bLastTeamMemberAlive; // 0x160 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_161[0x7]; // 0x161 (Size: 0x7, Type: PaddingProperty)

public:
    bool GetLastTeamMemberAlive() const; // 0xdcd8ff4 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void ServerRequestDeathFromDBNO(); // 0x112821f0 (Index: 0x11, Flags: RequiredAPI|Net|NetReliableNative|Event|Public|NetServer|NetValidate)

protected:
    void CleanupPossessedPawn(); // 0x112803fc (Index: 0x0, Flags: Final|Native|Protected)
    virtual void ClientHandlePreRespawn(FVector& RespawnLocation, FRotator& RespawnRotation, float& RespawnCameraDist); // 0x11280410 (Index: 0x1, Flags: Net|NetReliableNative|Event|Protected|HasDefaults|NetClient)
    virtual void ClientNotifyEnemyTeamEliminated(); // 0xceb4468 (Index: 0x2, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientNotifyNoRebootsRemaining(); // 0xcc5a53c (Index: 0x3, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientNotifyRespawnReward(TEnumAsByte<EBlastBerryRespawnRewardType>& RewardType, float& RewardTime); // 0x112805e8 (Index: 0x4, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientNotifyTeammateRespawned(AFortPlayerStateAthena*& PlayerState); // 0x10e431ac (Index: 0x5, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientNotifyTeammateRevived(AFortPlayerStateAthena*& PlayerState); // 0x10e42f7c (Index: 0x6, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    virtual void ClientNotifyWaitingForRespawn(FVector& const DeathLocation); // 0xd4b6054 (Index: 0x7, Flags: Net|NetReliableNative|Event|Protected|HasDefaults|NetClient)
    virtual void ClientNotifyWaitingForRespawnUsingDeathTransform(FVector& const DeathLocation, FRotator& const DeathRotation); // 0x112807f4 (Index: 0x8, Flags: Net|NetReliableNative|Event|Protected|HasDefaults|NetClient)
    void HandleBotPawnRespawned(AAIController*& BotController, AFortPawn*& BotPawn); // 0x11280d50 (Index: 0xa, Flags: Final|Native|Protected)
    void HandleDBNOChanged(AFortPawn*& Pawn, bool& bIsDBNO); // 0x11281160 (Index: 0xb, Flags: Final|Native|Protected)
    void HandlePlayerRespawnTimeUpdated(AFortPlayerStateAthena*& PlayerState, float& ServerTimeForRespawn); // 0x112814b8 (Index: 0xc, Flags: Final|Native|Protected)
    void HandlePlayerSpawned(AFortPlayerPawn*& NewPawn); // 0x112818e0 (Index: 0xd, Flags: Final|Native|Protected)
    void HandleViewTargetChanged(AFortPlayerController*& InController, AActor*& OldViewTarget, AActor*& NewViewTarget); // 0x11281b24 (Index: 0xe, Flags: Final|Native|Protected)
    virtual void LocalHandlePreRespawn(FVector& RespawnLocation, FRotator& RespawnRotation, float& RespawnCameraDist); // 0x11281e40 (Index: 0xf, Flags: Native|Event|Protected|HasDefaults|BlueprintEvent)
    void OnRep_LastTeamMemberAlive(); // 0x112820e4 (Index: 0x10, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortControllerComponent_BlastBerry) == 0x168, "Size mismatch for UFortControllerComponent_BlastBerry");
static_assert(offsetof(UFortControllerComponent_BlastBerry, OnLastTeamMemberAliveChanged) == 0xc0, "Offset mismatch for UFortControllerComponent_BlastBerry::OnLastTeamMemberAliveChanged");
static_assert(offsetof(UFortControllerComponent_BlastBerry, OnNoRebootsRemaining) == 0xd0, "Offset mismatch for UFortControllerComponent_BlastBerry::OnNoRebootsRemaining");
static_assert(offsetof(UFortControllerComponent_BlastBerry, OnTeammateRespawned) == 0xe0, "Offset mismatch for UFortControllerComponent_BlastBerry::OnTeammateRespawned");
static_assert(offsetof(UFortControllerComponent_BlastBerry, OnTeammateRevived) == 0xf0, "Offset mismatch for UFortControllerComponent_BlastBerry::OnTeammateRevived");
static_assert(offsetof(UFortControllerComponent_BlastBerry, OnEnemyTeamEliminated) == 0x100, "Offset mismatch for UFortControllerComponent_BlastBerry::OnEnemyTeamEliminated");
static_assert(offsetof(UFortControllerComponent_BlastBerry, OnRespawnReward) == 0x110, "Offset mismatch for UFortControllerComponent_BlastBerry::OnRespawnReward");
static_assert(offsetof(UFortControllerComponent_BlastBerry, bLastTeamMemberAlive) == 0x160, "Offset mismatch for UFortControllerComponent_BlastBerry::bLastTeamMemberAlive");

// Size: 0x270 (Inherited: 0x310, Single: 0xffffff60)
class UFortControllerComponent_BlastBerryUI : public UFortControllerComponent
{
public:
    FScalableFloat DeathLocationIndicatorDuration; // 0xc0 (Size: 0x28, Type: StructProperty)
    TSoftClassPtr DeathLocationIndicatorWidget; // 0xe8 (Size: 0x20, Type: SoftClassProperty)
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush DeathLocationIndicatorIconBrush; // 0x110 (Size: 0xb0, Type: StructProperty)
    FSlateBrush DeathLocationIndicatorClampedIconBrush; // 0x1c0 (Size: 0xb0, Type: StructProperty)
};

static_assert(sizeof(UFortControllerComponent_BlastBerryUI) == 0x270, "Size mismatch for UFortControllerComponent_BlastBerryUI");
static_assert(offsetof(UFortControllerComponent_BlastBerryUI, DeathLocationIndicatorDuration) == 0xc0, "Offset mismatch for UFortControllerComponent_BlastBerryUI::DeathLocationIndicatorDuration");
static_assert(offsetof(UFortControllerComponent_BlastBerryUI, DeathLocationIndicatorWidget) == 0xe8, "Offset mismatch for UFortControllerComponent_BlastBerryUI::DeathLocationIndicatorWidget");
static_assert(offsetof(UFortControllerComponent_BlastBerryUI, DeathLocationIndicatorIconBrush) == 0x110, "Offset mismatch for UFortControllerComponent_BlastBerryUI::DeathLocationIndicatorIconBrush");
static_assert(offsetof(UFortControllerComponent_BlastBerryUI, DeathLocationIndicatorClampedIconBrush) == 0x1c0, "Offset mismatch for UFortControllerComponent_BlastBerryUI::DeathLocationIndicatorClampedIconBrush");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UBlastBerryVerseRespawnLogic : public UObject
{
public:
};

static_assert(sizeof(UBlastBerryVerseRespawnLogic) == 0x38, "Size mismatch for UBlastBerryVerseRespawnLogic");

// Size: 0x4e0 (Inherited: 0x1070, Single: 0xfffff470)
class AFortAthenaMutator_BlastBerry : public AFortAthenaMutator_GameModeBase
{
public:
    FScalableFloat DBNOReviveTime; // 0x4b0 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_4d8[0x8]; // 0x4d8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(AFortAthenaMutator_BlastBerry) == 0x4e0, "Size mismatch for AFortAthenaMutator_BlastBerry");
static_assert(offsetof(AFortAthenaMutator_BlastBerry, DBNOReviveTime) == 0x4b0, "Offset mismatch for AFortAthenaMutator_BlastBerry::DBNOReviveTime");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UFortCheatManager_BlastBerry : public UChildCheatManager
{
public:

public:
    void BlastBerryForceRebootInPlace(); // 0x554e3c4 (Index: 0x0, Flags: Final|Exec|Native|Public)
    void BlastBerryForceRespawn(); // 0x554e3c4 (Index: 0x1, Flags: Final|Exec|Native|Public)
    void BlastBerrySetTeamLives(int32_t& TeamLives); // 0xa5dc3cc (Index: 0x2, Flags: Final|Exec|Native|Public)
};

static_assert(sizeof(UFortCheatManager_BlastBerry) == 0x28, "Size mismatch for UFortCheatManager_BlastBerry");

// Size: 0x640 (Inherited: 0x308, Single: 0x338)
class UFortGameStateComponent_BlastBerryManager : public UFortGameStateComponent
{
public:
    uint8_t OnPlayerPawnRespawned[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPlayerPawnDied[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTeamWon[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLocalTeamLivesChanged[0x10]; // 0xe8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLocalTimeUntilTeamLivesRechargeChanged[0x10]; // 0xf8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRespawnsEnabled[0x10]; // 0x108 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRespawnsDisabled[0x10]; // 0x118 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTimeUntilRespawnsDisabledUpdated[0x10]; // 0x128 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnConsumedRemainingTeamLives[0x10]; // 0x138 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float ServerTimeForRespawnsDisabled; // 0x148 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14c[0x4]; // 0x14c (Size: 0x4, Type: PaddingProperty)
    TArray<AFortPlayerStateAthena*> RespawnPendingPlayerStates; // 0x150 (Size: 0x10, Type: ArrayProperty)
    uint8_t CurrentGamePhaseStep; // 0x160 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_161[0x3]; // 0x161 (Size: 0x3, Type: PaddingProperty)
    int32_t CurrentSafeZonePhaseIndex; // 0x164 (Size: 0x4, Type: IntProperty)
    FScalableFloat MaxTeamLives; // 0x168 (Size: 0x28, Type: StructProperty)
    FScalableFloat TeamLivesRechargeDuration; // 0x190 (Size: 0x28, Type: StructProperty)
    FScalableFloat RespawnHeight; // 0x1b8 (Size: 0x28, Type: StructProperty)
    FScalableFloat RespawnRange; // 0x1e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat RespawnCameraDistance; // 0x208 (Size: 0x28, Type: StructProperty)
    FScalableFloat UseAdvancedSpawnBehavior; // 0x230 (Size: 0x28, Type: StructProperty)
    FScalableFloat UseSoloSpawnEQS; // 0x258 (Size: 0x28, Type: StructProperty)
    FScalableFloat SoloDisableEQSRadius; // 0x280 (Size: 0x28, Type: StructProperty)
    FScalableFloat SoloSpawnMaxDistanceFromDeathLocation; // 0x2a8 (Size: 0x28, Type: StructProperty)
    FScalableFloat AdvancedSpawnSafeZonePredictionTime; // 0x2d0 (Size: 0x28, Type: StructProperty)
    FScalableFloat AdvancedSpawnSafeZoneRadiusBuffer; // 0x2f8 (Size: 0x28, Type: StructProperty)
    FScalableFloat AdvancedSpawnGroupProximityDistance; // 0x320 (Size: 0x28, Type: StructProperty)
    FScalableFloat WaveRespawnEnabled; // 0x348 (Size: 0x28, Type: StructProperty)
    FScalableFloat WaveRespawnDelay; // 0x370 (Size: 0x28, Type: StructProperty)
    FScalableFloat IndividualRespawnDelay; // 0x398 (Size: 0x28, Type: StructProperty)
    FScalableFloat RespawnDownedTimeReward; // 0x3c0 (Size: 0x28, Type: StructProperty)
    FScalableFloat RespawnEliminationTimeReward; // 0x3e8 (Size: 0x28, Type: StructProperty)
    FScalableFloat RespawnTeamWipeTimeReward; // 0x410 (Size: 0x28, Type: StructProperty)
    UEnvQuery* SoloRespawnLocationQueryTemplate; // 0x438 (Size: 0x8, Type: ObjectProperty)
    TArray<FBlastBerryTeamLives> TeamLives; // 0x440 (Size: 0x10, Type: ArrayProperty)
    TArray<FBlastBerryTeamLives> PreviousTeamLives; // 0x450 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_460[0xf0]; // 0x460 (Size: 0xf0, Type: PaddingProperty)
    TMap<FTimerHandle, AFortPlayerStateAthena*> ActiveViewTargetValidationTimersMap; // 0x550 (Size: 0x50, Type: MapProperty)
    TMap<FBlastBerrySoloRespawnData, AFortPlayerStateAthena*> SoloRespawnDataMap; // 0x5a0 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_5f0[0x8]; // 0x5f0 (Size: 0x8, Type: PaddingProperty)
    UBlastBerryVerseRespawnLogic* RespawnLogicScript; // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_600[0x40]; // 0x600 (Size: 0x40, Type: PaddingProperty)

public:
    bool AreRespawnsActive() const; // 0x112803d8 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetRespawnDelay(AFortPlayerStateAthena*& PS) const; // 0x11280968 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetTeamLivesRemaining(char& TeamID) const; // 0x11280aa0 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTimeUntilRespawnDisabled() const; // 0x11280be4 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetTimeUntilTeamLivesRecharge(char& TeamID) const; // 0x11280c0c (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsWaveRespawnEnabled() const; // 0x11281e1c (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void HandleBotPawnRespawned(AAIController*& BotController, AFortPawn*& BotPawn); // 0x11280f58 (Index: 0x5, Flags: Final|Native|Protected)
    void HandlePlayerRespawnTimeUpdated(AFortPlayerStateAthena*& PlayerState, float& ServerTimeForRespawn); // 0x112816d8 (Index: 0x6, Flags: Final|Native|Protected)
    void HandleTeamLifeRecharged(char& TeamID); // 0x112819f8 (Index: 0x7, Flags: Final|Native|Protected)
    void HandleWaveRespawnTimerFinished(); // 0x11281e08 (Index: 0x8, Flags: Final|Native|Protected)
    void OnGamePhaseStepChanged(const FFortGamePhaseStepUpdatedEvent Event); // 0x11282018 (Index: 0xa, Flags: Final|Native|Protected|HasOutParms)
    void OnRep_ServerTimeForRespawnsDisabled(); // 0x112820f8 (Index: 0xb, Flags: Final|Native|Protected)
    void OnRep_TeamLives(); // 0x1128210c (Index: 0xc, Flags: Final|Native|Protected)
    void OnSafeZoneUpdated(const FFortSafeZonePhaseUpdatedEvent Event); // 0x11282120 (Index: 0xd, Flags: Final|Native|Protected|HasOutParms)
    void UpdateTeamInfo(char& TeamID, bool& bSendNotifications); // 0x1128223c (Index: 0xe, Flags: Final|Native|Protected)
    void ValidateRespawningViewTarget(TWeakObjectPtr<AFortPlayerStateAthena*>& WeakPS); // 0x11282448 (Index: 0xf, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortGameStateComponent_BlastBerryManager) == 0x640, "Size mismatch for UFortGameStateComponent_BlastBerryManager");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, OnPlayerPawnRespawned) == 0xb8, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::OnPlayerPawnRespawned");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, OnPlayerPawnDied) == 0xc8, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::OnPlayerPawnDied");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, OnTeamWon) == 0xd8, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::OnTeamWon");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, OnLocalTeamLivesChanged) == 0xe8, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::OnLocalTeamLivesChanged");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, OnLocalTimeUntilTeamLivesRechargeChanged) == 0xf8, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::OnLocalTimeUntilTeamLivesRechargeChanged");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, OnRespawnsEnabled) == 0x108, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::OnRespawnsEnabled");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, OnRespawnsDisabled) == 0x118, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::OnRespawnsDisabled");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, OnTimeUntilRespawnsDisabledUpdated) == 0x128, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::OnTimeUntilRespawnsDisabledUpdated");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, OnConsumedRemainingTeamLives) == 0x138, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::OnConsumedRemainingTeamLives");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, ServerTimeForRespawnsDisabled) == 0x148, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::ServerTimeForRespawnsDisabled");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, RespawnPendingPlayerStates) == 0x150, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::RespawnPendingPlayerStates");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, CurrentGamePhaseStep) == 0x160, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::CurrentGamePhaseStep");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, CurrentSafeZonePhaseIndex) == 0x164, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::CurrentSafeZonePhaseIndex");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, MaxTeamLives) == 0x168, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::MaxTeamLives");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, TeamLivesRechargeDuration) == 0x190, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::TeamLivesRechargeDuration");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, RespawnHeight) == 0x1b8, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::RespawnHeight");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, RespawnRange) == 0x1e0, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::RespawnRange");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, RespawnCameraDistance) == 0x208, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::RespawnCameraDistance");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, UseAdvancedSpawnBehavior) == 0x230, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::UseAdvancedSpawnBehavior");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, UseSoloSpawnEQS) == 0x258, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::UseSoloSpawnEQS");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, SoloDisableEQSRadius) == 0x280, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::SoloDisableEQSRadius");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, SoloSpawnMaxDistanceFromDeathLocation) == 0x2a8, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::SoloSpawnMaxDistanceFromDeathLocation");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, AdvancedSpawnSafeZonePredictionTime) == 0x2d0, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::AdvancedSpawnSafeZonePredictionTime");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, AdvancedSpawnSafeZoneRadiusBuffer) == 0x2f8, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::AdvancedSpawnSafeZoneRadiusBuffer");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, AdvancedSpawnGroupProximityDistance) == 0x320, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::AdvancedSpawnGroupProximityDistance");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, WaveRespawnEnabled) == 0x348, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::WaveRespawnEnabled");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, WaveRespawnDelay) == 0x370, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::WaveRespawnDelay");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, IndividualRespawnDelay) == 0x398, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::IndividualRespawnDelay");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, RespawnDownedTimeReward) == 0x3c0, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::RespawnDownedTimeReward");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, RespawnEliminationTimeReward) == 0x3e8, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::RespawnEliminationTimeReward");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, RespawnTeamWipeTimeReward) == 0x410, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::RespawnTeamWipeTimeReward");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, SoloRespawnLocationQueryTemplate) == 0x438, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::SoloRespawnLocationQueryTemplate");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, TeamLives) == 0x440, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::TeamLives");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, PreviousTeamLives) == 0x450, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::PreviousTeamLives");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, ActiveViewTargetValidationTimersMap) == 0x550, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::ActiveViewTargetValidationTimersMap");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, SoloRespawnDataMap) == 0x5a0, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::SoloRespawnDataMap");
static_assert(offsetof(UFortGameStateComponent_BlastBerryManager, RespawnLogicScript) == 0x5f8, "Offset mismatch for UFortGameStateComponent_BlastBerryManager::RespawnLogicScript");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_BlastBerryAllEnemies : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_BlastBerryAllEnemies) == 0x28, "Size mismatch for UFortQueryContext_BlastBerryAllEnemies");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_BlastBerryDeathLocation : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_BlastBerryDeathLocation) == 0x28, "Size mismatch for UFortQueryContext_BlastBerryDeathLocation");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortQueryContext_BlastBerryDefaultSpawnLocation : public UEnvQueryContext
{
public:
};

static_assert(sizeof(UFortQueryContext_BlastBerryDefaultSpawnLocation) == 0x28, "Size mismatch for UFortQueryContext_BlastBerryDefaultSpawnLocation");

// Size: 0x98 (Inherited: 0x190, Single: 0xffffff08)
class UBlastBerryObjectiveProcessor_PlayerRespawned : public UFortObjectiveProcessor
{
public:
};

static_assert(sizeof(UBlastBerryObjectiveProcessor_PlayerRespawned) == 0x98, "Size mismatch for UBlastBerryObjectiveProcessor_PlayerRespawned");

// Size: 0x98 (Inherited: 0x190, Single: 0xffffff08)
class UBlastBerryObjectiveProcessor_RespawnsDisabled : public UFortObjectiveProcessor
{
public:
};

static_assert(sizeof(UBlastBerryObjectiveProcessor_RespawnsDisabled) == 0x98, "Size mismatch for UBlastBerryObjectiveProcessor_RespawnsDisabled");

// Size: 0x98 (Inherited: 0x190, Single: 0xffffff08)
class UBlastBerryObjectiveProcessor_TeamEliminated : public UFortObjectiveProcessor
{
public:
};

static_assert(sizeof(UBlastBerryObjectiveProcessor_TeamEliminated) == 0x98, "Size mismatch for UBlastBerryObjectiveProcessor_TeamEliminated");

// Size: 0x80 (Inherited: 0x78, Single: 0x8)
struct FBlastBerryVerbMessage_PlayerRespawned : FVerbMessage
{
    int32_t TeamLivesRemaining; // 0x78 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FBlastBerryVerbMessage_PlayerRespawned) == 0x80, "Size mismatch for FBlastBerryVerbMessage_PlayerRespawned");
static_assert(offsetof(FBlastBerryVerbMessage_PlayerRespawned, TeamLivesRemaining) == 0x78, "Offset mismatch for FBlastBerryVerbMessage_PlayerRespawned::TeamLivesRemaining");

// Size: 0x80 (Inherited: 0x78, Single: 0x8)
struct FBlastBerryVerbMessage_RespawnsDisabled : FVerbMessage
{
    int32_t TeamLivesRemaining; // 0x78 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FBlastBerryVerbMessage_RespawnsDisabled) == 0x80, "Size mismatch for FBlastBerryVerbMessage_RespawnsDisabled");
static_assert(offsetof(FBlastBerryVerbMessage_RespawnsDisabled, TeamLivesRemaining) == 0x78, "Offset mismatch for FBlastBerryVerbMessage_RespawnsDisabled::TeamLivesRemaining");

// Size: 0xf0 (Inherited: 0x78, Single: 0x78)
struct FBlastBerryVerbMessage_TeamEliminated : FVerbMessage
{
    FSubjectTagsPair EliminatedPlayer; // 0x78 (Size: 0x38, Type: StructProperty)
    FSubjectTagsPair DamageType; // 0xb0 (Size: 0x38, Type: StructProperty)
    bool bWasAuthorKiller; // 0xe8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e9[0x7]; // 0xe9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FBlastBerryVerbMessage_TeamEliminated) == 0xf0, "Size mismatch for FBlastBerryVerbMessage_TeamEliminated");
static_assert(offsetof(FBlastBerryVerbMessage_TeamEliminated, EliminatedPlayer) == 0x78, "Offset mismatch for FBlastBerryVerbMessage_TeamEliminated::EliminatedPlayer");
static_assert(offsetof(FBlastBerryVerbMessage_TeamEliminated, DamageType) == 0xb0, "Offset mismatch for FBlastBerryVerbMessage_TeamEliminated::DamageType");
static_assert(offsetof(FBlastBerryVerbMessage_TeamEliminated, bWasAuthorKiller) == 0xe8, "Offset mismatch for FBlastBerryVerbMessage_TeamEliminated::bWasAuthorKiller");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FBlastBerryTeamLives
{
    char TeamID; // 0x0 (Size: 0x1, Type: ByteProperty)
    int8_t TeamLivesUsed; // 0x1 (Size: 0x1, Type: Int8Property)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    float ServerTimeForRecharge; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FBlastBerryTeamLives) == 0x8, "Size mismatch for FBlastBerryTeamLives");
static_assert(offsetof(FBlastBerryTeamLives, TeamID) == 0x0, "Offset mismatch for FBlastBerryTeamLives::TeamID");
static_assert(offsetof(FBlastBerryTeamLives, TeamLivesUsed) == 0x1, "Offset mismatch for FBlastBerryTeamLives::TeamLivesUsed");
static_assert(offsetof(FBlastBerryTeamLives, ServerTimeForRecharge) == 0x4, "Offset mismatch for FBlastBerryTeamLives::ServerTimeForRecharge");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FBlastBerrySoloRespawnData
{
};

static_assert(sizeof(FBlastBerrySoloRespawnData) == 0x38, "Size mismatch for FBlastBerrySoloRespawnData");

// Size: 0xb0 (Inherited: 0xa0, Single: 0x10)
struct FBlastBerryObjectiveFilter_PlayerRespawned : FObjectiveFilter
{
    FInt32Range TeamLivesRemaining; // 0xa0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FBlastBerryObjectiveFilter_PlayerRespawned) == 0xb0, "Size mismatch for FBlastBerryObjectiveFilter_PlayerRespawned");
static_assert(offsetof(FBlastBerryObjectiveFilter_PlayerRespawned, TeamLivesRemaining) == 0xa0, "Offset mismatch for FBlastBerryObjectiveFilter_PlayerRespawned::TeamLivesRemaining");

// Size: 0xb0 (Inherited: 0xa0, Single: 0x10)
struct FBlastBerryObjectiveFilter_RespawnsDisabled : FObjectiveFilter
{
    FInt32Range TeamLivesRemaining; // 0xa0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FBlastBerryObjectiveFilter_RespawnsDisabled) == 0xb0, "Size mismatch for FBlastBerryObjectiveFilter_RespawnsDisabled");
static_assert(offsetof(FBlastBerryObjectiveFilter_RespawnsDisabled, TeamLivesRemaining) == 0xa0, "Offset mismatch for FBlastBerryObjectiveFilter_RespawnsDisabled::TeamLivesRemaining");

// Size: 0x138 (Inherited: 0xa0, Single: 0x98)
struct FBlastBerryObjectiveFilter_TeamEliminated : FObjectiveFilter
{
    FObjectiveSubjectTags EliminatedPlayer; // 0xa0 (Size: 0x48, Type: StructProperty)
    FObjectiveSubjectTags DamageType; // 0xe8 (Size: 0x48, Type: StructProperty)
    uint8_t KillerHandling; // 0x130 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_131[0x7]; // 0x131 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FBlastBerryObjectiveFilter_TeamEliminated) == 0x138, "Size mismatch for FBlastBerryObjectiveFilter_TeamEliminated");
static_assert(offsetof(FBlastBerryObjectiveFilter_TeamEliminated, EliminatedPlayer) == 0xa0, "Offset mismatch for FBlastBerryObjectiveFilter_TeamEliminated::EliminatedPlayer");
static_assert(offsetof(FBlastBerryObjectiveFilter_TeamEliminated, DamageType) == 0xe8, "Offset mismatch for FBlastBerryObjectiveFilter_TeamEliminated::DamageType");
static_assert(offsetof(FBlastBerryObjectiveFilter_TeamEliminated, KillerHandling) == 0x130, "Offset mismatch for FBlastBerryObjectiveFilter_TeamEliminated::KillerHandling");

