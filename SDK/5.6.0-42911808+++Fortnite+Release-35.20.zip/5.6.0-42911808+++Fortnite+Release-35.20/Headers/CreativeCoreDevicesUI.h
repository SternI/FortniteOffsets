/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeCoreDevicesUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteUI.h"
#include "ModelViewViewModel.h"
#include "Engine.h"
#include "UMG.h"
#include "CoreUObject.h"

// Size: 0x3e0 (Inherited: 0xa48, Single: 0xfffff998)
class UFortCreativeTimerContainerWidget : public UFortHUDElementWidget
{
public:
    uint8_t Pad_318[0x48]; // 0x318 (Size: 0x48, Type: PaddingProperty)
    UClass* TimerViewModelClass; // 0x360 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_368[0x10]; // 0x368 (Size: 0x10, Type: PaddingProperty)
    UClass* TimerWidgetDefaultClass; // 0x378 (Size: 0x8, Type: ClassProperty)
    TMap<FViewModelRelation, UObject*> InterfaceViewModelMap; // 0x380 (Size: 0x50, Type: MapProperty)
    TScriptInterface<Class> ActiveInterface; // 0x3d0 (Size: 0x10, Type: InterfaceProperty)

public:
    virtual void OnTimerWidgetCreated(UUserWidget*& Widget, bool& bIsFullscreen, bool& bIsCustomWidget); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)

private:
    void HandleTimerWidgetActorUpdated(AActor*& const TimerWidgetActor); // 0x11324a10 (Index: 0x0, Flags: Final|Native|Private)

protected:
    virtual void OnMinigameEnded(); // 0x3f8cd94 (Index: 0x1, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void OnMinigameStarted(); // 0xf26263c (Index: 0x2, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void UpdateViewModel(UMVVMViewModelBase*& const ViewModel, UObject*& const TimerDeviceObject, int32_t& CurrentTime, int32_t& TotalTime, const FText LabelText, FName& TextStyle, const FText TimerName, bool& bIsPaused, bool& bIsStarted, bool& bIsUrgently); // 0x288a61c (Index: 0x4, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortCreativeTimerContainerWidget) == 0x3e0, "Size mismatch for UFortCreativeTimerContainerWidget");
static_assert(offsetof(UFortCreativeTimerContainerWidget, TimerViewModelClass) == 0x360, "Offset mismatch for UFortCreativeTimerContainerWidget::TimerViewModelClass");
static_assert(offsetof(UFortCreativeTimerContainerWidget, TimerWidgetDefaultClass) == 0x378, "Offset mismatch for UFortCreativeTimerContainerWidget::TimerWidgetDefaultClass");
static_assert(offsetof(UFortCreativeTimerContainerWidget, InterfaceViewModelMap) == 0x380, "Offset mismatch for UFortCreativeTimerContainerWidget::InterfaceViewModelMap");
static_assert(offsetof(UFortCreativeTimerContainerWidget, ActiveInterface) == 0x3d0, "Offset mismatch for UFortCreativeTimerContainerWidget::ActiveInterface");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FViewModelRelation
{
};

static_assert(sizeof(FViewModelRelation) == 0x10, "Size mismatch for FViewModelRelation");

