/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamDecksRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ModularGameplay.h"
#include "StateDrivenActorRuntime.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "StateTreeModule.h"
#include "FMJamPlayspaceRuntime.h"
#include "SparksCoreRuntime.h"
#include "GameplayTags.h"

// Size: 0x140 (Inherited: 0x250, Single: 0xfffffef0)
class UControllerComponent_JamDeckCoordinator : public UControllerComponent
{
public:
    uint8_t Pad_b8[0x10]; // 0xb8 (Size: 0x10, Type: PaddingProperty)
    AActor* LastFocusedActor; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_d0[0x70]; // 0xd0 (Size: 0x70, Type: PaddingProperty)

public:
    void JamDeckCoordinatorFocusActorChanged__DelegateSignature(UControllerComponent_JamDeckCoordinator*& ThisCoordinator, AActor*& ThePreviousFocusActor, AActor*& TheNewFocusActor); // 0x288a61c (Index: 0x0, Flags: Public|Delegate)
    void RegisterAndCallWhenFocusActorChanges(FDelegate& DelegateToAdd, FKismetDelegateHandle& OutDelegateHandle); // 0x1144ee04 (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    virtual void ServerSetLastFocusedActor(AActor*& FocusedActor); // 0x1144f468 (Index: 0x8, Flags: Net|NetReliableNative|Event|Public|NetServer)
    void UnregisterFromFocusActorChanges(FKismetDelegateHandle DelegateHandle); // 0x1144f8f8 (Index: 0xb, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

protected:
    void OnFocusActorEndedPlay(AActor*& ActorEndingPlay, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x1144e0f8 (Index: 0x1, Flags: Final|Native|Protected)
    virtual void OnFocusedEmitter(AJamDeckEmitter*& FocusedEmitter); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUnfocusedEmitter(AJamDeckEmitter*& UnfocusedEmitter); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    void OpenEmotePickerForPlayerOverride(); // 0x1144ec20 (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void QuickJoinDeckJam(); // 0x270d644 (Index: 0x5, Flags: Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable)
    virtual void SendJamToDeck(); // 0xc0194b8 (Index: 0x7, Flags: Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable)
    virtual void StopDeckJam(); // 0xcc87b74 (Index: 0x9, Flags: Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable)
    virtual void TakeJamFromDeck(); // 0x3abd220 (Index: 0xa, Flags: Net|NetReliableNative|Event|Protected|NetServer|BlueprintCallable)
};

static_assert(sizeof(UControllerComponent_JamDeckCoordinator) == 0x140, "Size mismatch for UControllerComponent_JamDeckCoordinator");
static_assert(offsetof(UControllerComponent_JamDeckCoordinator, LastFocusedActor) == 0xc8, "Offset mismatch for UControllerComponent_JamDeckCoordinator::LastFocusedActor");

// Size: 0x228 (Inherited: 0x640, Single: 0xfffffbe8)
class UFortClientsidePlayerInstancedStateTreeComponent : public UFortPlayerInstancedStateTreeComponent
{
public:
};

static_assert(sizeof(UFortClientsidePlayerInstancedStateTreeComponent) == 0x228, "Size mismatch for UFortClientsidePlayerInstancedStateTreeComponent");

// Size: 0xb38 (Inherited: 0xf08, Single: 0xfffffc30)
class UJamDeckAbility : public UFortGameplayAbility
{
public:

private:
    bool CanContextActorEditFocusedMusicSlot(AActor*& GivenActor) const; // 0x1144d4c4 (Index: 0x0, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
    bool DoesContextActorOwnFocusedMusicSlot(AActor*& GivenActor) const; // 0x1144d624 (Index: 0x1, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
    APlayerController* GetControllerFromAvatarOrInfo() const; // 0x1144dacc (Index: 0x2, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
    AJamDeckEmitter* GetFocusedEmitter() const; // 0x1144db14 (Index: 0x3, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
    UJamMusicSlot* GetFocusedMusicSlot() const; // 0x1144db38 (Index: 0x4, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
    AFortPlayerPawnAthena* GetFocusedPlayerPawn() const; // 0x1144db5c (Index: 0x5, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
    AJamDeckProxy* GetFocusedProxy() const; // 0x1144db80 (Index: 0x6, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
    UControllerComponent_JamDeckCoordinator* GetJamDeckCoordinator() const; // 0x1144dba4 (Index: 0x7, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
    bool IsFocusingValidJammer() const; // 0x1144e0a8 (Index: 0x8, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UJamDeckAbility) == 0xb38, "Size mismatch for UJamDeckAbility");

// Size: 0x438 (Inherited: 0x2d0, Single: 0x168)
class AJamDeckEmitter : public AActor
{
public:
    uint8_t Pad_2a8[0x8]; // 0x2a8 (Size: 0x8, Type: PaddingProperty)
    FCollisionResponseContainer CollisionResponse_AimMode; // 0x2b0 (Size: 0x20, Type: StructProperty)
    FCollisionResponseContainer CollisionResponse_OverlapMode; // 0x2d0 (Size: 0x20, Type: StructProperty)
    float HeartbeatTimerDelayInSeconds; // 0x2f0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2f4[0x5c]; // 0x2f4 (Size: 0x5c, Type: PaddingProperty)
    TArray<FJamDeckProxyControlEditorPrerequisite> ProxyControlConditions; // 0x350 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_360[0x50]; // 0x360 (Size: 0x50, Type: PaddingProperty)
    TArray<FJamDeckHotfixableProxySelection> PossibleProxyClasses; // 0x3b0 (Size: 0x10, Type: ArrayProperty)
    TSoftClassPtr ProxyClassToSpawn; // 0x3c0 (Size: 0x20, Type: SoftClassProperty)
    TArray<USceneComponent*> SceneComponentsForHeartbeat; // 0x3e0 (Size: 0x10, Type: ArrayProperty)
    AJamDeckProxy* SpawnedProxy; // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_3f8[0x30]; // 0x3f8 (Size: 0x30, Type: PaddingProperty)
    AJamPlayspace* PertinentPlayspace; // 0x428 (Size: 0x8, Type: ObjectProperty)
    uint8_t bSupportAllPartsPlayback : 1; // 0x430:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAllowNonJamEmotes : 1; // 0x430:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bAutoRemoveEmitterWhenOwningPlayerLeaves : 1; // 0x430:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_431[0x7]; // 0x431 (Size: 0x7, Type: PaddingProperty)

protected:
    virtual UPrimitiveComponent* GetCoreInteractionCollider() const; // 0x1144daf0 (Index: 0x0, Flags: RequiredAPI|Native|Event|Protected|BlueprintEvent|Const)
    virtual FTransform GetProxySpawnSpot() const; // 0x1144dbc8 (Index: 0x1, Flags: Native|Event|Protected|HasDefaults|BlueprintEvent|Const)
    void HideTaggedComponentsForTargetPlayer(AFortPlayerController*& TargetPlayer, const TArray<FName> ComponentTags, bool& bHide, bool& bPropagateToChildren); // 0x1144dc24 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    virtual void OnFocusedByPlayer(AFortPlayerController*& const FocusingPlayer); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    void OnHeartbeat(); // 0x1144e304 (Index: 0x4, Flags: Final|Native|Protected)
    void OnProxyEndedPlay(AActor*& ActorEndingPlay, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x1144e8dc (Index: 0x5, Flags: Final|Native|Protected)
    void OnRep_SpawnedProxy(AJamDeckProxy*& OldSpawnedProxy); // 0x1144eae8 (Index: 0x6, Flags: Final|Native|Protected)
    virtual void OnUnfocusedByPlayer(AFortPlayerController*& const FocusingPlayer); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    void RegisterSceneComponentForHeartbeat(USceneComponent*& InSceneComponent); // 0x1144efd4 (Index: 0x8, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
    void UnregisterSceneComponentForHeartbeat(USceneComponent*& InSceneComponent); // 0x1144f9c8 (Index: 0x9, Flags: Final|RequiredAPI|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(AJamDeckEmitter) == 0x438, "Size mismatch for AJamDeckEmitter");
static_assert(offsetof(AJamDeckEmitter, CollisionResponse_AimMode) == 0x2b0, "Offset mismatch for AJamDeckEmitter::CollisionResponse_AimMode");
static_assert(offsetof(AJamDeckEmitter, CollisionResponse_OverlapMode) == 0x2d0, "Offset mismatch for AJamDeckEmitter::CollisionResponse_OverlapMode");
static_assert(offsetof(AJamDeckEmitter, HeartbeatTimerDelayInSeconds) == 0x2f0, "Offset mismatch for AJamDeckEmitter::HeartbeatTimerDelayInSeconds");
static_assert(offsetof(AJamDeckEmitter, ProxyControlConditions) == 0x350, "Offset mismatch for AJamDeckEmitter::ProxyControlConditions");
static_assert(offsetof(AJamDeckEmitter, PossibleProxyClasses) == 0x3b0, "Offset mismatch for AJamDeckEmitter::PossibleProxyClasses");
static_assert(offsetof(AJamDeckEmitter, ProxyClassToSpawn) == 0x3c0, "Offset mismatch for AJamDeckEmitter::ProxyClassToSpawn");
static_assert(offsetof(AJamDeckEmitter, SceneComponentsForHeartbeat) == 0x3e0, "Offset mismatch for AJamDeckEmitter::SceneComponentsForHeartbeat");
static_assert(offsetof(AJamDeckEmitter, SpawnedProxy) == 0x3f0, "Offset mismatch for AJamDeckEmitter::SpawnedProxy");
static_assert(offsetof(AJamDeckEmitter, PertinentPlayspace) == 0x428, "Offset mismatch for AJamDeckEmitter::PertinentPlayspace");
static_assert(offsetof(AJamDeckEmitter, bSupportAllPartsPlayback) == 0x430, "Offset mismatch for AJamDeckEmitter::bSupportAllPartsPlayback");
static_assert(offsetof(AJamDeckEmitter, bAllowNonJamEmotes) == 0x430, "Offset mismatch for AJamDeckEmitter::bAllowNonJamEmotes");
static_assert(offsetof(AJamDeckEmitter, bAutoRemoveEmitterWhenOwningPlayerLeaves) == 0x430, "Offset mismatch for AJamDeckEmitter::bAutoRemoveEmitterWhenOwningPlayerLeaves");

// Size: 0x310 (Inherited: 0x2d0, Single: 0x40)
class AJamDeckProxy : public AActor
{
public:
    bool bShouldTieLifecycleToOwnersMusicSlot; // 0x2a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a9[0x7]; // 0x2a9 (Size: 0x7, Type: PaddingProperty)
    UJamMusicSlot* InUseMusicSlot; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2b8[0x58]; // 0x2b8 (Size: 0x58, Type: PaddingProperty)

private:
    void OnNewMusicSlot(UJamMusicSlot*& OldMusicSlot); // 0x1144e628 (Index: 0x4, Flags: Final|Native|Private)
    void OnOwnerJamMusicSlotStopped(const FJamPlayParams PlayParams, bool& bChangedLoop); // 0x1144e754 (Index: 0x5, Flags: Final|Native|Private|HasOutParms)

protected:
    virtual void HandleReplicatedEmote(UFortMontageItemDefinitionBase*& const NewEmote); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void HandleReplicatedMusicSlot(UJamMusicSlot*& NewMusicSlot); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    void OnJamMusicSlotStarted(const FJamPlayParams PlayParams, bool& bChangedLoop); // 0x1144e318 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
    void OnJamMusicSlotStopped(const FJamPlayParams PlayParams, bool& bChangedLoop); // 0x1144e4a0 (Index: 0x3, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(AJamDeckProxy) == 0x310, "Size mismatch for AJamDeckProxy");
static_assert(offsetof(AJamDeckProxy, bShouldTieLifecycleToOwnersMusicSlot) == 0x2a8, "Offset mismatch for AJamDeckProxy::bShouldTieLifecycleToOwnersMusicSlot");
static_assert(offsetof(AJamDeckProxy, InUseMusicSlot) == 0x2b0, "Offset mismatch for AJamDeckProxy::InUseMusicSlot");

// Size: 0x150 (Inherited: 0xe0, Single: 0x70)
class UJamPlayspaceVolumeComponent_EmitterSpawner : public UActorComponent
{
public:
    UClass* EmitterClassToSpawn; // 0xb8 (Size: 0x8, Type: ClassProperty)
    TArray<FJamDeckProxyControlEditorPrerequisite> DefaultProxyControlPrerequisitesForEmitters; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TArray<FJamPlayspaceEmitterSpawner_SpawnableEmitterPlacementData> EmitterData; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_e0[0x18]; // 0xe0 (Size: 0x18, Type: PaddingProperty)
    int32_t AmountOfEmittersToSpawn; // 0xf8 (Size: 0x4, Type: IntProperty)
    int32_t AmountOfEmittersWithoutProxiesAllowed; // 0xfc (Size: 0x4, Type: IntProperty)
    uint8_t Pad_100[0x50]; // 0x100 (Size: 0x50, Type: PaddingProperty)

public:
    AJamDeckEmitter* FindOrSpawnFreeEmitter(bool& bIgnoreEmittersWithoutProxiesCap); // 0x1144d75c (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    TArray<AJamDeckEmitter*> FindOrSpawnFreeEmitters(int32_t& RequestedCount, bool& bIgnoreEmittersWithoutProxiesCap); // 0x1144d898 (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void RegisterAndCallWhenAtCapacityChanges(FDelegate& DelegateToAdd, FKismetDelegateHandle& OutDelegateHandle); // 0x1144ec34 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    AJamDeckEmitter* TryCreateNewEmitter(bool& bIgnoreEmittersWithoutProxiesCap); // 0x1144f594 (Index: 0x3, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void TryCreateNewProxyWithCommand(FDelegate& CommandDelegate, bool& bIncludeExistingEmitters); // 0x1144f6d0 (Index: 0x4, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void UnregisterWhenAtCapacityChanges(FKismetDelegateHandle DelegateHandle); // 0x1144fca0 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UJamPlayspaceVolumeComponent_EmitterSpawner) == 0x150, "Size mismatch for UJamPlayspaceVolumeComponent_EmitterSpawner");
static_assert(offsetof(UJamPlayspaceVolumeComponent_EmitterSpawner, EmitterClassToSpawn) == 0xb8, "Offset mismatch for UJamPlayspaceVolumeComponent_EmitterSpawner::EmitterClassToSpawn");
static_assert(offsetof(UJamPlayspaceVolumeComponent_EmitterSpawner, DefaultProxyControlPrerequisitesForEmitters) == 0xc0, "Offset mismatch for UJamPlayspaceVolumeComponent_EmitterSpawner::DefaultProxyControlPrerequisitesForEmitters");
static_assert(offsetof(UJamPlayspaceVolumeComponent_EmitterSpawner, EmitterData) == 0xd0, "Offset mismatch for UJamPlayspaceVolumeComponent_EmitterSpawner::EmitterData");
static_assert(offsetof(UJamPlayspaceVolumeComponent_EmitterSpawner, AmountOfEmittersToSpawn) == 0xf8, "Offset mismatch for UJamPlayspaceVolumeComponent_EmitterSpawner::AmountOfEmittersToSpawn");
static_assert(offsetof(UJamPlayspaceVolumeComponent_EmitterSpawner, AmountOfEmittersWithoutProxiesAllowed) == 0xfc, "Offset mismatch for UJamPlayspaceVolumeComponent_EmitterSpawner::AmountOfEmittersWithoutProxiesAllowed");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FJamDeckProxyControlEditorPrerequisite
{
    uint8_t ControlType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagQuery TagQuery; // 0x8 (Size: 0x48, Type: StructProperty)
    TSoftClassPtr ActivatableGameplayAbility; // 0x50 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FJamDeckProxyControlEditorPrerequisite) == 0x70, "Size mismatch for FJamDeckProxyControlEditorPrerequisite");
static_assert(offsetof(FJamDeckProxyControlEditorPrerequisite, ControlType) == 0x0, "Offset mismatch for FJamDeckProxyControlEditorPrerequisite::ControlType");
static_assert(offsetof(FJamDeckProxyControlEditorPrerequisite, TagQuery) == 0x8, "Offset mismatch for FJamDeckProxyControlEditorPrerequisite::TagQuery");
static_assert(offsetof(FJamDeckProxyControlEditorPrerequisite, ActivatableGameplayAbility) == 0x50, "Offset mismatch for FJamDeckProxyControlEditorPrerequisite::ActivatableGameplayAbility");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FJamDeckHotfixableProxySelection
{
    TSoftClassPtr ProxyClassToSpawn; // 0x0 (Size: 0x20, Type: SoftClassProperty)
    uint8_t CVarName[0x10]; // 0x20 (Size: 0x10, Type: OptionalProperty)
    int32_t CVarValue; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FJamDeckHotfixableProxySelection) == 0x38, "Size mismatch for FJamDeckHotfixableProxySelection");
static_assert(offsetof(FJamDeckHotfixableProxySelection, ProxyClassToSpawn) == 0x0, "Offset mismatch for FJamDeckHotfixableProxySelection::ProxyClassToSpawn");
static_assert(offsetof(FJamDeckHotfixableProxySelection, CVarName) == 0x20, "Offset mismatch for FJamDeckHotfixableProxySelection::CVarName");
static_assert(offsetof(FJamDeckHotfixableProxySelection, CVarValue) == 0x30, "Offset mismatch for FJamDeckHotfixableProxySelection::CVarValue");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FJamDecksEventReactionBase
{
};

static_assert(sizeof(FJamDecksEventReactionBase) == 0x8, "Size mismatch for FJamDecksEventReactionBase");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FJamDecksEventReactionParams
{
    UObject* Target; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UObject* Source; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FJamDecksEventReactionParams) == 0x10, "Size mismatch for FJamDecksEventReactionParams");
static_assert(offsetof(FJamDecksEventReactionParams, Target) == 0x0, "Offset mismatch for FJamDecksEventReactionParams::Target");
static_assert(offsetof(FJamDecksEventReactionParams, Source) == 0x8, "Offset mismatch for FJamDecksEventReactionParams::Source");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FJamDecksEventReactionComponentSelection
{
    TArray<FName> ComponentTagsToInclude; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FJamDecksEventReactionComponentSelection) == 0x10, "Size mismatch for FJamDecksEventReactionComponentSelection");
static_assert(offsetof(FJamDecksEventReactionComponentSelection, ComponentTagsToInclude) == 0x0, "Offset mismatch for FJamDecksEventReactionComponentSelection::ComponentTagsToInclude");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FJamEventReactionComponentVisibilitySetting
{
    FJamDecksEventReactionComponentSelection ComponentSelection; // 0x0 (Size: 0x10, Type: StructProperty)
    uint8_t NewVisibilitySetting; // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bApplyToChildrenComponents; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FJamEventReactionComponentVisibilitySetting) == 0x18, "Size mismatch for FJamEventReactionComponentVisibilitySetting");
static_assert(offsetof(FJamEventReactionComponentVisibilitySetting, ComponentSelection) == 0x0, "Offset mismatch for FJamEventReactionComponentVisibilitySetting::ComponentSelection");
static_assert(offsetof(FJamEventReactionComponentVisibilitySetting, NewVisibilitySetting) == 0x10, "Offset mismatch for FJamEventReactionComponentVisibilitySetting::NewVisibilitySetting");
static_assert(offsetof(FJamEventReactionComponentVisibilitySetting, bApplyToChildrenComponents) == 0x11, "Offset mismatch for FJamEventReactionComponentVisibilitySetting::bApplyToChildrenComponents");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FJamDecksEventReaction_ManageComponentVisibility : FJamDecksEventReactionBase
{
    TArray<FJamEventReactionComponentVisibilitySetting> Settings; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FJamDecksEventReaction_ManageComponentVisibility) == 0x18, "Size mismatch for FJamDecksEventReaction_ManageComponentVisibility");
static_assert(offsetof(FJamDecksEventReaction_ManageComponentVisibility, Settings) == 0x8, "Offset mismatch for FJamDecksEventReaction_ManageComponentVisibility::Settings");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting
{
    FJamDecksEventReactionComponentSelection ComponentSelection; // 0x0 (Size: 0x10, Type: StructProperty)
    UStaticMesh* StaticMeshToApply; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting) == 0x18, "Size mismatch for FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting");
static_assert(offsetof(FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting, ComponentSelection) == 0x0, "Offset mismatch for FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting::ComponentSelection");
static_assert(offsetof(FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting, StaticMeshToApply) == 0x10, "Offset mismatch for FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting::StaticMeshToApply");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FJamDecksEventReaction_UpdateSpecificStaticMeshComponent : FJamDecksEventReactionBase
{
    TArray<FJamDecksEventReaction_UpdateSpecificStaticMeshComponentSetting> Settings; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FJamDecksEventReaction_UpdateSpecificStaticMeshComponent) == 0x18, "Size mismatch for FJamDecksEventReaction_UpdateSpecificStaticMeshComponent");
static_assert(offsetof(FJamDecksEventReaction_UpdateSpecificStaticMeshComponent, Settings) == 0x8, "Offset mismatch for FJamDecksEventReaction_UpdateSpecificStaticMeshComponent::Settings");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FJamDecksStateTreeTask_PerformReactionsInfo
{
    TArray<FInstancedStruct> ReactionsToPerform; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FJamDecksStateTreeTask_PerformReactionsInfo) == 0x10, "Size mismatch for FJamDecksStateTreeTask_PerformReactionsInfo");
static_assert(offsetof(FJamDecksStateTreeTask_PerformReactionsInfo, ReactionsToPerform) == 0x0, "Offset mismatch for FJamDecksStateTreeTask_PerformReactionsInfo::ReactionsToPerform");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FJamDecksStateTreeTask_PerformReactionsInstanceData
{
    FJamDecksStateTreeTask_PerformReactionsInfo ReactionInfo; // 0x0 (Size: 0x10, Type: StructProperty)
    UObject* SourceObject; // 0x10 (Size: 0x8, Type: ObjectProperty)
    uint8_t ResultStatus; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FJamDecksStateTreeTask_PerformReactionsInstanceData) == 0x20, "Size mismatch for FJamDecksStateTreeTask_PerformReactionsInstanceData");
static_assert(offsetof(FJamDecksStateTreeTask_PerformReactionsInstanceData, ReactionInfo) == 0x0, "Offset mismatch for FJamDecksStateTreeTask_PerformReactionsInstanceData::ReactionInfo");
static_assert(offsetof(FJamDecksStateTreeTask_PerformReactionsInstanceData, SourceObject) == 0x10, "Offset mismatch for FJamDecksStateTreeTask_PerformReactionsInstanceData::SourceObject");
static_assert(offsetof(FJamDecksStateTreeTask_PerformReactionsInstanceData, ResultStatus) == 0x18, "Offset mismatch for FJamDecksStateTreeTask_PerformReactionsInstanceData::ResultStatus");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FJamDecksStateTreeTask_PerformReactions : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FJamDecksStateTreeTask_PerformReactions) == 0x20, "Size mismatch for FJamDecksStateTreeTask_PerformReactions");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FJamDecksStateTreeEventDesc
{
    FGameplayTag Tag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UScriptStruct* PayloadStruct; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FJamDecksStateTreeEventDesc) == 0x10, "Size mismatch for FJamDecksStateTreeEventDesc");
static_assert(offsetof(FJamDecksStateTreeEventDesc, Tag) == 0x0, "Offset mismatch for FJamDecksStateTreeEventDesc::Tag");
static_assert(offsetof(FJamDecksStateTreeEventDesc, PayloadStruct) == 0x8, "Offset mismatch for FJamDecksStateTreeEventDesc::PayloadStruct");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FJamDecksStateTreeTask_TrackEvents_TrackedEventData
{
    FJamDecksStateTreeEventDesc EventDescription; // 0x0 (Size: 0x10, Type: StructProperty)
    int32_t NewValue; // 0x10 (Size: 0x4, Type: IntProperty)
    bool bConsumeEvent; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FJamDecksStateTreeTask_TrackEvents_TrackedEventData) == 0x18, "Size mismatch for FJamDecksStateTreeTask_TrackEvents_TrackedEventData");
static_assert(offsetof(FJamDecksStateTreeTask_TrackEvents_TrackedEventData, EventDescription) == 0x0, "Offset mismatch for FJamDecksStateTreeTask_TrackEvents_TrackedEventData::EventDescription");
static_assert(offsetof(FJamDecksStateTreeTask_TrackEvents_TrackedEventData, NewValue) == 0x10, "Offset mismatch for FJamDecksStateTreeTask_TrackEvents_TrackedEventData::NewValue");
static_assert(offsetof(FJamDecksStateTreeTask_TrackEvents_TrackedEventData, bConsumeEvent) == 0x14, "Offset mismatch for FJamDecksStateTreeTask_TrackEvents_TrackedEventData::bConsumeEvent");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FJamDecksStateTreeTask_TrackEventsInstanceData
{
    TArray<FJamDecksStateTreeTask_TrackEvents_TrackedEventData> ObservedEvents; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t Result; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FJamDecksStateTreeTask_TrackEventsInstanceData) == 0x18, "Size mismatch for FJamDecksStateTreeTask_TrackEventsInstanceData");
static_assert(offsetof(FJamDecksStateTreeTask_TrackEventsInstanceData, ObservedEvents) == 0x0, "Offset mismatch for FJamDecksStateTreeTask_TrackEventsInstanceData::ObservedEvents");
static_assert(offsetof(FJamDecksStateTreeTask_TrackEventsInstanceData, Result) == 0x10, "Offset mismatch for FJamDecksStateTreeTask_TrackEventsInstanceData::Result");

// Size: 0x20 (Inherited: 0x58, Single: 0xffffffc8)
struct FJamDecksStateTreeTask_TrackEvents : FStateTreeTaskCommonBase
{
};

static_assert(sizeof(FJamDecksStateTreeTask_TrackEvents) == 0x20, "Size mismatch for FJamDecksStateTreeTask_TrackEvents");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FJamPlayspaceEmitterSpawner_SpawnableEmitterPlacementData
{
    AJamDeckEmitter* SpawnedEmitter; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x78]; // 0x8 (Size: 0x78, Type: PaddingProperty)
};

static_assert(sizeof(FJamPlayspaceEmitterSpawner_SpawnableEmitterPlacementData) == 0x80, "Size mismatch for FJamPlayspaceEmitterSpawner_SpawnableEmitterPlacementData");
static_assert(offsetof(FJamPlayspaceEmitterSpawner_SpawnableEmitterPlacementData, SpawnedEmitter) == 0x0, "Offset mismatch for FJamPlayspaceEmitterSpawner_SpawnableEmitterPlacementData::SpawnedEmitter");

