/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMCoreRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "DeveloperSettings.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "ModularGameplay.h"
#include "GameplayEventRouter.h"
#include "HarmonixMidi.h"

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UFMCoreDeveloperSettings : public UDeveloperSettings
{
public:
};

static_assert(sizeof(UFMCoreDeveloperSettings) == 0x30, "Size mismatch for UFMCoreDeveloperSettings");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFMCoreMusicFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static int32_t GetDegreeShiftFromProgression(EHarmonicProgression& Progression); // 0x102eb1dc (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static EMusicInterval GetIntervalAtStepInScale(int32_t& ScaleStep, EMusicKeyMode& KeyMode); // 0x102eb304 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static EMusicInterval GetIntervalForNote(FMidiNote& Note, EMusicKey& Key); // 0x102eb50c (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static int32_t GetIntervalStepInScale(EMusicInterval& Interval, EMusicKeyMode& KeyMode); // 0x102eb65c (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FMidiNote GetMidiNoteFromScale(EMusicKey& Key, int32_t& Octave, EMusicInterval& Interval); // 0x102eb864 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FMidiNote SnapToScale(FMidiNote& Note, EMusicKey& Key, EMusicKeyMode& KeyMode); // 0x102ed224 (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UFMCoreMusicFunctionLibrary) == 0x28, "Size mismatch for UFMCoreMusicFunctionLibrary");

// Size: 0x148 (Inherited: 0xe0, Single: 0x68)
class UFMCoreMusicManagerComponent : public UActorComponent
{
public:
    uint8_t OnTempoChangedDelegate[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSpeedChangedDelegate[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnKeyChangedDelegate[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnModeChangedDelegate[0x10]; // 0xe8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnTimeSignatureChanged[0x10]; // 0xf8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t StartingKey; // 0x108 (Size: 0x1, Type: EnumProperty)
    uint8_t StartingMode; // 0x109 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_10a[0x2]; // 0x10a (Size: 0x2, Type: PaddingProperty)
    float StartingTempo; // 0x10c (Size: 0x4, Type: FloatProperty)
    float StartingSpeed; // 0x110 (Size: 0x4, Type: FloatProperty)
    int32_t StartingTimeSignatureNumerator; // 0x114 (Size: 0x4, Type: IntProperty)
    int32_t StartingTimeSignatureDenominator; // 0x118 (Size: 0x4, Type: IntProperty)
    uint8_t CurrentKey; // 0x11c (Size: 0x1, Type: EnumProperty)
    uint8_t CurrentMode; // 0x11d (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11e[0x2]; // 0x11e (Size: 0x2, Type: PaddingProperty)
    float CurrentTempo; // 0x120 (Size: 0x4, Type: FloatProperty)
    float CurrentSpeed; // 0x124 (Size: 0x4, Type: FloatProperty)
    FFMCoreTimeSignature CurrentTimeSignature; // 0x128 (Size: 0x8, Type: StructProperty)
    uint8_t ServerKey; // 0x130 (Size: 0x1, Type: EnumProperty)
    uint8_t ServerMode; // 0x131 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_132[0x2]; // 0x132 (Size: 0x2, Type: PaddingProperty)
    float ServerTempo; // 0x134 (Size: 0x4, Type: FloatProperty)
    float ServerSpeed; // 0x138 (Size: 0x4, Type: FloatProperty)
    FFMCoreTimeSignature ServerTimeSignature; // 0x13c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_144[0x4]; // 0x144 (Size: 0x4, Type: PaddingProperty)

public:
    void GetCurrentAudioState(EMusicKey& OutKey, EMusicKeyMode& OutKeyMode, float& OutTempo) const; // 0x102eafc4 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    EMusicKey GetCurrentKey() const; // 0xa554310 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EMusicKeyMode GetCurrentKeyMode() const; // 0x102eb1ac (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCurrentSpeed() const; // 0x102eb1c4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCurrentTempo() const; // 0xa064fac (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FFMCoreTimeSignature GetCurrentTimeSignature() const; // 0xbd72460 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnKeyChanged__DelegateSignature(EMusicKey& CurrentKey); // 0x288a61c (Index: 0x6, Flags: MulticastDelegate|Public|Delegate)
    void OnModeChanged__DelegateSignature(EMusicKeyMode& CurrentMode); // 0x288a61c (Index: 0x7, Flags: MulticastDelegate|Public|Delegate)
    void OnSpeedChanged__DelegateSignature(float& CurrentSpeed); // 0x288a61c (Index: 0xd, Flags: MulticastDelegate|Public|Delegate)
    void OnTempoChanged__DelegateSignature(float& CurrentTempo); // 0x288a61c (Index: 0xe, Flags: MulticastDelegate|Public|Delegate)
    void OnTimeSignatureChanged__DelegateSignature(FFMCoreTimeSignature& TimeSignature); // 0x288a61c (Index: 0xf, Flags: MulticastDelegate|Public|Delegate)
    void TriggerKeyChange(EMusicKey& InKey); // 0x102ed3c8 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    void TriggerModeChange(EMusicKeyMode& InMode); // 0x102ed4f4 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
    void TriggerSpeedChange(float& Speed, bool& bLocalChangeOnly); // 0x102ed620 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)
    void TriggerTempoChange(float& BPM, bool& bLocalChangeOnly); // 0x102ed82c (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)
    void TriggerTimeSignatureChange(int32_t& Numerator, int32_t& Denominator); // 0x102eda38 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnRep_ServerKeyChanged(); // 0x102ed0b0 (Index: 0x8, Flags: Final|Native|Private)
    void OnRep_ServerModeChanged(); // 0x102ed0e4 (Index: 0x9, Flags: Final|Native|Private)
    void OnRep_ServerSpeedChanged(); // 0x102ed118 (Index: 0xa, Flags: Final|Native|Private)
    void OnRep_ServerTempoChanged(); // 0x102ed150 (Index: 0xb, Flags: Final|Native|Private)
    void OnRep_ServerTimeSignatureChanged(); // 0x102ed188 (Index: 0xc, Flags: Final|Native|Private)
};

static_assert(sizeof(UFMCoreMusicManagerComponent) == 0x148, "Size mismatch for UFMCoreMusicManagerComponent");
static_assert(offsetof(UFMCoreMusicManagerComponent, OnTempoChangedDelegate) == 0xb8, "Offset mismatch for UFMCoreMusicManagerComponent::OnTempoChangedDelegate");
static_assert(offsetof(UFMCoreMusicManagerComponent, OnSpeedChangedDelegate) == 0xc8, "Offset mismatch for UFMCoreMusicManagerComponent::OnSpeedChangedDelegate");
static_assert(offsetof(UFMCoreMusicManagerComponent, OnKeyChangedDelegate) == 0xd8, "Offset mismatch for UFMCoreMusicManagerComponent::OnKeyChangedDelegate");
static_assert(offsetof(UFMCoreMusicManagerComponent, OnModeChangedDelegate) == 0xe8, "Offset mismatch for UFMCoreMusicManagerComponent::OnModeChangedDelegate");
static_assert(offsetof(UFMCoreMusicManagerComponent, OnTimeSignatureChanged) == 0xf8, "Offset mismatch for UFMCoreMusicManagerComponent::OnTimeSignatureChanged");
static_assert(offsetof(UFMCoreMusicManagerComponent, StartingKey) == 0x108, "Offset mismatch for UFMCoreMusicManagerComponent::StartingKey");
static_assert(offsetof(UFMCoreMusicManagerComponent, StartingMode) == 0x109, "Offset mismatch for UFMCoreMusicManagerComponent::StartingMode");
static_assert(offsetof(UFMCoreMusicManagerComponent, StartingTempo) == 0x10c, "Offset mismatch for UFMCoreMusicManagerComponent::StartingTempo");
static_assert(offsetof(UFMCoreMusicManagerComponent, StartingSpeed) == 0x110, "Offset mismatch for UFMCoreMusicManagerComponent::StartingSpeed");
static_assert(offsetof(UFMCoreMusicManagerComponent, StartingTimeSignatureNumerator) == 0x114, "Offset mismatch for UFMCoreMusicManagerComponent::StartingTimeSignatureNumerator");
static_assert(offsetof(UFMCoreMusicManagerComponent, StartingTimeSignatureDenominator) == 0x118, "Offset mismatch for UFMCoreMusicManagerComponent::StartingTimeSignatureDenominator");
static_assert(offsetof(UFMCoreMusicManagerComponent, CurrentKey) == 0x11c, "Offset mismatch for UFMCoreMusicManagerComponent::CurrentKey");
static_assert(offsetof(UFMCoreMusicManagerComponent, CurrentMode) == 0x11d, "Offset mismatch for UFMCoreMusicManagerComponent::CurrentMode");
static_assert(offsetof(UFMCoreMusicManagerComponent, CurrentTempo) == 0x120, "Offset mismatch for UFMCoreMusicManagerComponent::CurrentTempo");
static_assert(offsetof(UFMCoreMusicManagerComponent, CurrentSpeed) == 0x124, "Offset mismatch for UFMCoreMusicManagerComponent::CurrentSpeed");
static_assert(offsetof(UFMCoreMusicManagerComponent, CurrentTimeSignature) == 0x128, "Offset mismatch for UFMCoreMusicManagerComponent::CurrentTimeSignature");
static_assert(offsetof(UFMCoreMusicManagerComponent, ServerKey) == 0x130, "Offset mismatch for UFMCoreMusicManagerComponent::ServerKey");
static_assert(offsetof(UFMCoreMusicManagerComponent, ServerMode) == 0x131, "Offset mismatch for UFMCoreMusicManagerComponent::ServerMode");
static_assert(offsetof(UFMCoreMusicManagerComponent, ServerTempo) == 0x134, "Offset mismatch for UFMCoreMusicManagerComponent::ServerTempo");
static_assert(offsetof(UFMCoreMusicManagerComponent, ServerSpeed) == 0x138, "Offset mismatch for UFMCoreMusicManagerComponent::ServerSpeed");
static_assert(offsetof(UFMCoreMusicManagerComponent, ServerTimeSignature) == 0x13c, "Offset mismatch for UFMCoreMusicManagerComponent::ServerTimeSignature");

// Size: 0x148 (Inherited: 0x198, Single: 0xffffffb0)
class UFMPlayerMonitorComponent : public UGameFrameworkComponent
{
public:
    FGameplayEventListenerBackwardCompatibleHandle PlayerEnteredHandle; // 0xb8 (Size: 0x48, Type: StructProperty)
    FGameplayEventListenerBackwardCompatibleHandle PlayerExitedHandle; // 0x100 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UFMPlayerMonitorComponent) == 0x148, "Size mismatch for UFMPlayerMonitorComponent");
static_assert(offsetof(UFMPlayerMonitorComponent, PlayerEnteredHandle) == 0xb8, "Offset mismatch for UFMPlayerMonitorComponent::PlayerEnteredHandle");
static_assert(offsetof(UFMPlayerMonitorComponent, PlayerExitedHandle) == 0x100, "Offset mismatch for UFMPlayerMonitorComponent::PlayerExitedHandle");

// Size: 0xc8 (Inherited: 0xe0, Single: 0xffffffe8)
class UFMPlayspaceScopedSystemComponent : public UActorComponent
{
public:
    uint8_t OnAddedToPlayspaceSystemManager[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void OnAddedToPlayspaceSystemManager__DelegateSignature(bool& Success); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)

protected:
    int32_t GetRandomSeedForPlayspace() const; // 0x102ec4a8 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool RemoveFromPlayspaceSystemManager(); // 0x102ed1c0 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFMPlayspaceScopedSystemComponent) == 0xc8, "Size mismatch for UFMPlayspaceScopedSystemComponent");
static_assert(offsetof(UFMPlayspaceScopedSystemComponent, OnAddedToPlayspaceSystemManager) == 0xb8, "Offset mismatch for UFMPlayspaceScopedSystemComponent::OnAddedToPlayspaceSystemManager");

// Size: 0x178 (Inherited: 0xe0, Single: 0x98)
class UFMPlayspaceScopedSystemManager : public UActorComponent
{
public:
    TMap<UClass*, UClass*> VKClassRedirects; // 0xb8 (Size: 0x50, Type: MapProperty)
    TArray<TSoftClassPtr> VKClassDenyList; // 0x108 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftClassPtr> UEFNNotableActors; // 0x118 (Size: 0x10, Type: ArrayProperty)
    TMap<FFMPlayspaceSystemInfo, AActor*> PlayspacesSystemInfo; // 0x128 (Size: 0x50, Type: MapProperty)

public:
    static void GetOrCreateSystemForActorBP(UClass*& SystemClass, AActor*& Requester, AActor*& OutActor, ESystemGetResult& OutWasValid); // 0x102ebb40 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetSystemForActorIfExistsBP(UClass*& SystemClass, AActor*& Requester, AActor*& OutActor, ESystemGetResult& OutWasValid); // 0x102ec4cc (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)

private:
    virtual void MulticastNewSystemCreated(AActor*& PlayspaceActor, UClass*& SystemClass, AActor*& CreatedActor); // 0x102ecc2c (Index: 0x2, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private)
};

static_assert(sizeof(UFMPlayspaceScopedSystemManager) == 0x178, "Size mismatch for UFMPlayspaceScopedSystemManager");
static_assert(offsetof(UFMPlayspaceScopedSystemManager, VKClassRedirects) == 0xb8, "Offset mismatch for UFMPlayspaceScopedSystemManager::VKClassRedirects");
static_assert(offsetof(UFMPlayspaceScopedSystemManager, VKClassDenyList) == 0x108, "Offset mismatch for UFMPlayspaceScopedSystemManager::VKClassDenyList");
static_assert(offsetof(UFMPlayspaceScopedSystemManager, UEFNNotableActors) == 0x118, "Offset mismatch for UFMPlayspaceScopedSystemManager::UEFNNotableActors");
static_assert(offsetof(UFMPlayspaceScopedSystemManager, PlayspacesSystemInfo) == 0x128, "Offset mismatch for UFMPlayspaceScopedSystemManager::PlayspacesSystemInfo");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFMCoreTimeSignature
{
    int32_t Numerator; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t Denominator; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FFMCoreTimeSignature) == 0x8, "Size mismatch for FFMCoreTimeSignature");
static_assert(offsetof(FFMCoreTimeSignature, Numerator) == 0x0, "Offset mismatch for FFMCoreTimeSignature::Numerator");
static_assert(offsetof(FFMCoreTimeSignature, Denominator) == 0x4, "Offset mismatch for FFMCoreTimeSignature::Denominator");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FFMCoreEvent_MuteJamAudioChanged
{
    bool bIsMuted; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FFMCoreEvent_MuteJamAudioChanged) == 0x1, "Size mismatch for FFMCoreEvent_MuteJamAudioChanged");
static_assert(offsetof(FFMCoreEvent_MuteJamAudioChanged, bIsMuted) == 0x0, "Offset mismatch for FFMCoreEvent_MuteJamAudioChanged::bIsMuted");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FFMPlayspaceSystemInfo
{
};

static_assert(sizeof(FFMPlayspaceSystemInfo) == 0x50, "Size mismatch for FFMPlayspaceSystemInfo");

