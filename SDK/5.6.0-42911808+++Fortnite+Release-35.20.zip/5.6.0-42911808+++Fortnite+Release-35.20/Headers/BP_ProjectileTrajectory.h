/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_ProjectileTrajectory
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "AnimationBudgetAllocator.h"
#include "Engine.h"

// Size: 0x322 (Inherited: 0x5a0, Single: 0xfffffd82)
class ABP_ProjectileTrajectory_C : public AFortProjectileTrajectory
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2d0 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* InvalidTarget; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Target; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    int32_t MaxMeshCount; // 0x2e8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2ec[0x4]; // 0x2ec (Size: 0x4, Type: PaddingProperty)
    UMaterialInstanceDynamic* SplineMID; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    double SplineFadeDistance; // 0x2f8 (Size: 0x8, Type: DoubleProperty)
    double SplineFadeStartDistance; // 0x300 (Size: 0x8, Type: DoubleProperty)
    UObject* TrajectoryOwner; // 0x308 (Size: 0x8, Type: ObjectProperty)
    bool ShouldUpdate; // 0x310 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_311[0x7]; // 0x311 (Size: 0x7, Type: PaddingProperty)
    UMaterialInstanceDynamic* InvalidSplineMID; // 0x318 (Size: 0x8, Type: ObjectProperty)
    bool bIsTrajectoryValid; // 0x320 (Size: 0x1, Type: BoolProperty)
    bool bWaitFirstTrajectoryValid; // 0x321 (Size: 0x1, Type: BoolProperty)

public:
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    void UpdateFromTrajectoryOwner(); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void SetTrajectorySpline(const TArray<FVector> SplinePoints, const TArray<FVector> SplineTangents); // 0x288a61c (Index: 0x4, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetShouldUpdateFromOwner(bool& ShouldUpdate, UObject*& Owner); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetProjectileBudgetMesh(USkeletalMeshComponentBudgeted*& ProjectileBudgetMesh); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void ReceiveEndPlay(TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ABP_ProjectileTrajectory_C) == 0x322, "Size mismatch for ABP_ProjectileTrajectory_C");
static_assert(offsetof(ABP_ProjectileTrajectory_C, UberGraphFrame) == 0x2d0, "Offset mismatch for ABP_ProjectileTrajectory_C::UberGraphFrame");
static_assert(offsetof(ABP_ProjectileTrajectory_C, InvalidTarget) == 0x2d8, "Offset mismatch for ABP_ProjectileTrajectory_C::InvalidTarget");
static_assert(offsetof(ABP_ProjectileTrajectory_C, Target) == 0x2e0, "Offset mismatch for ABP_ProjectileTrajectory_C::Target");
static_assert(offsetof(ABP_ProjectileTrajectory_C, MaxMeshCount) == 0x2e8, "Offset mismatch for ABP_ProjectileTrajectory_C::MaxMeshCount");
static_assert(offsetof(ABP_ProjectileTrajectory_C, SplineMID) == 0x2f0, "Offset mismatch for ABP_ProjectileTrajectory_C::SplineMID");
static_assert(offsetof(ABP_ProjectileTrajectory_C, SplineFadeDistance) == 0x2f8, "Offset mismatch for ABP_ProjectileTrajectory_C::SplineFadeDistance");
static_assert(offsetof(ABP_ProjectileTrajectory_C, SplineFadeStartDistance) == 0x300, "Offset mismatch for ABP_ProjectileTrajectory_C::SplineFadeStartDistance");
static_assert(offsetof(ABP_ProjectileTrajectory_C, TrajectoryOwner) == 0x308, "Offset mismatch for ABP_ProjectileTrajectory_C::TrajectoryOwner");
static_assert(offsetof(ABP_ProjectileTrajectory_C, ShouldUpdate) == 0x310, "Offset mismatch for ABP_ProjectileTrajectory_C::ShouldUpdate");
static_assert(offsetof(ABP_ProjectileTrajectory_C, InvalidSplineMID) == 0x318, "Offset mismatch for ABP_ProjectileTrajectory_C::InvalidSplineMID");
static_assert(offsetof(ABP_ProjectileTrajectory_C, bIsTrajectoryValid) == 0x320, "Offset mismatch for ABP_ProjectileTrajectory_C::bIsTrajectoryValid");
static_assert(offsetof(ABP_ProjectileTrajectory_C, bWaitFirstTrajectoryValid) == 0x321, "Offset mismatch for ABP_ProjectileTrajectory_C::bWaitFirstTrajectoryValid");

