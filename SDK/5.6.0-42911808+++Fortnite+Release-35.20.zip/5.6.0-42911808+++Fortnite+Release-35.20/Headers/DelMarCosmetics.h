/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarCosmetics
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "DelMarCore.h"
#include "CoreUObject.h"
#include "AnimGraphRuntime.h"
#include "GameplayTags.h"
#include "AudioGameplayBehavior.h"
#include "CosmeticsFrameworkLoadouts.h"
#include "Niagara.h"
#include "AudioGameplay.h"
#include "PhysicsCore.h"
#include "AudioMotorSim.h"

// Size: 0x2a60 (Inherited: 0x5468, Single: 0xffffd5f8)
class ADelMarGaragePreviewVehicle : public ADelMarPreviewVehicle
{
public:
    uint8_t OnActiveCameraUpdatedDelegate[0x10]; // 0x2860 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRotationTransitionStateChanged[0x10]; // 0x2870 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    USceneComponent* PreviewPivotComponent; // 0x2880 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2888[0x8]; // 0x2888 (Size: 0x8, Type: PaddingProperty)
    UCameraComponent* ActiveCameraComponent; // 0x2890 (Size: 0x8, Type: ObjectProperty)
    UCameraComponent* DefaultZoomInCameraComponent; // 0x2898 (Size: 0x8, Type: ObjectProperty)
    UCameraComponent* DefaultZoomOutCameraComponent; // 0x28a0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_28a8[0xa0]; // 0x28a8 (Size: 0xa0, Type: PaddingProperty)
    TMap<FRotator, FGameplayTag> SlotPreviewRotations; // 0x2948 (Size: 0x50, Type: MapProperty)
    TMap<FDelMarPreviewConfigs, FGameplayTag> SlotPreviewConfigs; // 0x2998 (Size: 0x50, Type: MapProperty)
    float ZoomLevel; // 0x29e8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_29ec[0x4]; // 0x29ec (Size: 0x4, Type: PaddingProperty)
    FRotator UserRotationOffset; // 0x29f0 (Size: 0x18, Type: StructProperty)
    FGameplayTag PreviewSlot; // 0x2a08 (Size: 0x4, Type: StructProperty)
    FGameplayTag PreviewVehicleTag; // 0x2a0c (Size: 0x4, Type: StructProperty)
    float RotationTransitionTime; // 0x2a10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2a14[0x4c]; // 0x2a14 (Size: 0x4c, Type: PaddingProperty)

public:
    FRotator GetRotationOffset() const; // 0x11d28290 (Index: 0x0, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool IsRotationTransitioning() const; // 0x11d28d64 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void PreviewItem(UDelMarCosmeticItemDefinition*& const Item); // 0x11d29a54 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void PreviewLoadout(const FDelMarLoadout Loadout); // 0x11d29b84 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void ResetPreviewToCurrentLoadout(); // 0x554e3c4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetPreviewSlot(const FGameplayTag InSlot); // 0x11d2a8cc (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetUserRotationOffset(const FRotator InRotationOffset); // 0x11d2af48 (Index: 0x7, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetZoomLevel(float& InZoomLevel); // 0x11d2b070 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void K2_OnActiveCameraUpdated(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    void UpdateActiveCamera(); // 0xeb5b5d4 (Index: 0x9, Flags: Native|Protected)
};

static_assert(sizeof(ADelMarGaragePreviewVehicle) == 0x2a60, "Size mismatch for ADelMarGaragePreviewVehicle");
static_assert(offsetof(ADelMarGaragePreviewVehicle, OnActiveCameraUpdatedDelegate) == 0x2860, "Offset mismatch for ADelMarGaragePreviewVehicle::OnActiveCameraUpdatedDelegate");
static_assert(offsetof(ADelMarGaragePreviewVehicle, OnRotationTransitionStateChanged) == 0x2870, "Offset mismatch for ADelMarGaragePreviewVehicle::OnRotationTransitionStateChanged");
static_assert(offsetof(ADelMarGaragePreviewVehicle, PreviewPivotComponent) == 0x2880, "Offset mismatch for ADelMarGaragePreviewVehicle::PreviewPivotComponent");
static_assert(offsetof(ADelMarGaragePreviewVehicle, ActiveCameraComponent) == 0x2890, "Offset mismatch for ADelMarGaragePreviewVehicle::ActiveCameraComponent");
static_assert(offsetof(ADelMarGaragePreviewVehicle, DefaultZoomInCameraComponent) == 0x2898, "Offset mismatch for ADelMarGaragePreviewVehicle::DefaultZoomInCameraComponent");
static_assert(offsetof(ADelMarGaragePreviewVehicle, DefaultZoomOutCameraComponent) == 0x28a0, "Offset mismatch for ADelMarGaragePreviewVehicle::DefaultZoomOutCameraComponent");
static_assert(offsetof(ADelMarGaragePreviewVehicle, SlotPreviewRotations) == 0x2948, "Offset mismatch for ADelMarGaragePreviewVehicle::SlotPreviewRotations");
static_assert(offsetof(ADelMarGaragePreviewVehicle, SlotPreviewConfigs) == 0x2998, "Offset mismatch for ADelMarGaragePreviewVehicle::SlotPreviewConfigs");
static_assert(offsetof(ADelMarGaragePreviewVehicle, ZoomLevel) == 0x29e8, "Offset mismatch for ADelMarGaragePreviewVehicle::ZoomLevel");
static_assert(offsetof(ADelMarGaragePreviewVehicle, UserRotationOffset) == 0x29f0, "Offset mismatch for ADelMarGaragePreviewVehicle::UserRotationOffset");
static_assert(offsetof(ADelMarGaragePreviewVehicle, PreviewSlot) == 0x2a08, "Offset mismatch for ADelMarGaragePreviewVehicle::PreviewSlot");
static_assert(offsetof(ADelMarGaragePreviewVehicle, PreviewVehicleTag) == 0x2a0c, "Offset mismatch for ADelMarGaragePreviewVehicle::PreviewVehicleTag");
static_assert(offsetof(ADelMarGaragePreviewVehicle, RotationTransitionTime) == 0x2a10, "Offset mismatch for ADelMarGaragePreviewVehicle::RotationTransitionTime");

// Size: 0x2860 (Inherited: 0x2c08, Single: 0xfffffc58)
class ADelMarPreviewVehicle : public AFortAthenaVehicle
{
public:
    uint8_t Pad_2120[0x8]; // 0x2120 (Size: 0x8, Type: PaddingProperty)
    FCosmeticLoadout PreviewLoadout; // 0x2128 (Size: 0x10, Type: StructProperty)
    TArray<FDelMarPreviewCustomization> PreviewCustomizations; // 0x2138 (Size: 0x10, Type: ArrayProperty)
    int32_t NumAllowedVehicleCosmeticChanges; // 0x2148 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_214c[0x4]; // 0x214c (Size: 0x4, Type: PaddingProperty)
    UDelMarVehicleCosmeticComponent* CosmeticComponent; // 0x2150 (Size: 0x8, Type: ObjectProperty)
    FDelMarPreviewConfigs PreviewConfigs; // 0x2158 (Size: 0x108, Type: StructProperty)
    uint8_t Pad_2260[0x88]; // 0x2260 (Size: 0x88, Type: PaddingProperty)
    TArray<float> SpringTravelOffset; // 0x22e8 (Size: 0x10, Type: ArrayProperty)
    FDelMarBouncyChassisState BouncyChassisConfig; // 0x22f8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_2304[0x4]; // 0x2304 (Size: 0x4, Type: PaddingProperty)
    uint8_t OnVehicleForwardStateChanged[0x10]; // 0x2308 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_2318[0x40]; // 0x2318 (Size: 0x40, Type: PaddingProperty)
    uint8_t OnDelMarVehicleHitWall[0x10]; // 0x2358 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDelMarVehicleHitVehicle[0x10]; // 0x2368 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDelMarVehicleHitByVehicle[0x10]; // 0x2378 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_2388[0x3c8]; // 0x2388 (Size: 0x3c8, Type: PaddingProperty)
    uint8_t OnHazardHit[0x10]; // 0x2750 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnVehicleTeleportEntered[0x10]; // 0x2760 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnVehicleTeleportExit[0x10]; // 0x2770 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnVehicleAppliedTeleportRotation[0x10]; // 0x2780 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEnvironmentEffectCueActivated[0x10]; // 0x2790 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEnvironmentEffectCueRemoved[0x10]; // 0x27a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_27b0[0x30]; // 0x27b0 (Size: 0x30, Type: PaddingProperty)
    uint8_t OnHeadlightsChanged[0x10]; // 0x27e0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_27f0[0x70]; // 0x27f0 (Size: 0x70, Type: PaddingProperty)

public:
    void BroadcastVehicleDemolished(FGameplayTag& DemolishCausedByTag); // 0x11d269dc (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    FDelMarBouncyChassisState GetBouncyChassisConfig() const; // 0x11d27504 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsWheelOnGround(EDelMarVehicleWheelIndex& WheelIndex) const; // 0x11d28d7c (Index: 0x3, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void ApplyPreviewLoadout(); // 0x11d269c8 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarPreviewVehicle) == 0x2860, "Size mismatch for ADelMarPreviewVehicle");
static_assert(offsetof(ADelMarPreviewVehicle, PreviewLoadout) == 0x2128, "Offset mismatch for ADelMarPreviewVehicle::PreviewLoadout");
static_assert(offsetof(ADelMarPreviewVehicle, PreviewCustomizations) == 0x2138, "Offset mismatch for ADelMarPreviewVehicle::PreviewCustomizations");
static_assert(offsetof(ADelMarPreviewVehicle, NumAllowedVehicleCosmeticChanges) == 0x2148, "Offset mismatch for ADelMarPreviewVehicle::NumAllowedVehicleCosmeticChanges");
static_assert(offsetof(ADelMarPreviewVehicle, CosmeticComponent) == 0x2150, "Offset mismatch for ADelMarPreviewVehicle::CosmeticComponent");
static_assert(offsetof(ADelMarPreviewVehicle, PreviewConfigs) == 0x2158, "Offset mismatch for ADelMarPreviewVehicle::PreviewConfigs");
static_assert(offsetof(ADelMarPreviewVehicle, SpringTravelOffset) == 0x22e8, "Offset mismatch for ADelMarPreviewVehicle::SpringTravelOffset");
static_assert(offsetof(ADelMarPreviewVehicle, BouncyChassisConfig) == 0x22f8, "Offset mismatch for ADelMarPreviewVehicle::BouncyChassisConfig");
static_assert(offsetof(ADelMarPreviewVehicle, OnVehicleForwardStateChanged) == 0x2308, "Offset mismatch for ADelMarPreviewVehicle::OnVehicleForwardStateChanged");
static_assert(offsetof(ADelMarPreviewVehicle, OnDelMarVehicleHitWall) == 0x2358, "Offset mismatch for ADelMarPreviewVehicle::OnDelMarVehicleHitWall");
static_assert(offsetof(ADelMarPreviewVehicle, OnDelMarVehicleHitVehicle) == 0x2368, "Offset mismatch for ADelMarPreviewVehicle::OnDelMarVehicleHitVehicle");
static_assert(offsetof(ADelMarPreviewVehicle, OnDelMarVehicleHitByVehicle) == 0x2378, "Offset mismatch for ADelMarPreviewVehicle::OnDelMarVehicleHitByVehicle");
static_assert(offsetof(ADelMarPreviewVehicle, OnHazardHit) == 0x2750, "Offset mismatch for ADelMarPreviewVehicle::OnHazardHit");
static_assert(offsetof(ADelMarPreviewVehicle, OnVehicleTeleportEntered) == 0x2760, "Offset mismatch for ADelMarPreviewVehicle::OnVehicleTeleportEntered");
static_assert(offsetof(ADelMarPreviewVehicle, OnVehicleTeleportExit) == 0x2770, "Offset mismatch for ADelMarPreviewVehicle::OnVehicleTeleportExit");
static_assert(offsetof(ADelMarPreviewVehicle, OnVehicleAppliedTeleportRotation) == 0x2780, "Offset mismatch for ADelMarPreviewVehicle::OnVehicleAppliedTeleportRotation");
static_assert(offsetof(ADelMarPreviewVehicle, OnEnvironmentEffectCueActivated) == 0x2790, "Offset mismatch for ADelMarPreviewVehicle::OnEnvironmentEffectCueActivated");
static_assert(offsetof(ADelMarPreviewVehicle, OnEnvironmentEffectCueRemoved) == 0x27a0, "Offset mismatch for ADelMarPreviewVehicle::OnEnvironmentEffectCueRemoved");
static_assert(offsetof(ADelMarPreviewVehicle, OnHeadlightsChanged) == 0x27e0, "Offset mismatch for ADelMarPreviewVehicle::OnHeadlightsChanged");

// Size: 0x330 (Inherited: 0x5b0, Single: 0xfffffd80)
class ADelMarParamOverrideCosmeticActor : public ADelMarCosmeticActor
{
public:
    TMap<FDelMarParameterOverrides, UClass*> CosmeticActorsParamterOverrides; // 0x2e0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(ADelMarParamOverrideCosmeticActor) == 0x330, "Size mismatch for ADelMarParamOverrideCosmeticActor");
static_assert(offsetof(ADelMarParamOverrideCosmeticActor, CosmeticActorsParamterOverrides) == 0x2e0, "Offset mismatch for ADelMarParamOverrideCosmeticActor::CosmeticActorsParamterOverrides");

// Size: 0xa90 (Inherited: 0xda0, Single: 0xfffffcf0)
class UDelMarPreviewCameraComponent : public UCameraComponent
{
public:
    FGameplayTag PreviewSlot; // 0xa80 (Size: 0x4, Type: StructProperty)
    uint8_t PreviewType; // 0xa84 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a85[0xb]; // 0xa85 (Size: 0xb, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarPreviewCameraComponent) == 0xa90, "Size mismatch for UDelMarPreviewCameraComponent");
static_assert(offsetof(UDelMarPreviewCameraComponent, PreviewSlot) == 0xa80, "Offset mismatch for UDelMarPreviewCameraComponent::PreviewSlot");
static_assert(offsetof(UDelMarPreviewCameraComponent, PreviewType) == 0xa84, "Offset mismatch for UDelMarPreviewCameraComponent::PreviewType");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class ADelMarPreviewPivot : public AActor
{
public:
    USceneComponent* SceneComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ADelMarPreviewPivot) == 0x2b0, "Size mismatch for ADelMarPreviewPivot");
static_assert(offsetof(ADelMarPreviewPivot, SceneComponent) == 0x2a8, "Offset mismatch for ADelMarPreviewPivot::SceneComponent");

// Size: 0x5a8 (Inherited: 0x5b0, Single: 0xfffffff8)
class ADelMarUnifiedVehicleCosmeticActor : public ADelMarCosmeticActor
{
public:
    TArray<UNiagaraComponent*> CachedSideBoosters; // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_2f0[0x4]; // 0x2f0 (Size: 0x4, Type: PaddingProperty)
    FName SideBoosterParam_Scale; // 0x2f4 (Size: 0x4, Type: NameProperty)
    TArray<FDelMarVehicleBooster> Boosters; // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    FDelMarVehicleUnderthrustVfxData UnderthrustVfxData; // 0x308 (Size: 0x38, Type: StructProperty)
    uint8_t Pad_340[0x50]; // 0x340 (Size: 0x50, Type: PaddingProperty)
    USkeletalMeshComponent* BodySkeletalMeshComponent; // 0x390 (Size: 0x8, Type: ObjectProperty)
    FAudioGameplayBehaviorInstance KickflipAudioBehavior; // 0x398 (Size: 0x10, Type: StructProperty)
    FAudioGameplayBehaviorInstance JumpAudioBehavior; // 0x3a8 (Size: 0x10, Type: StructProperty)
    UNiagaraComponent* JumpFX; // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* SuperSonicFX; // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* SuperSonicRadialBlurMaterial; // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* SuperSonicRadialBlurMID; // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    float SuperSonicBlurOffset; // 0x3d8 (Size: 0x4, Type: FloatProperty)
    float SuperSonicForwardSpeedMin; // 0x3dc (Size: 0x4, Type: FloatProperty)
    float SuperSonicForwardSpeedMax; // 0x3e0 (Size: 0x4, Type: FloatProperty)
    FName SuperSonicParam_Spawn; // 0x3e4 (Size: 0x4, Type: NameProperty)
    FName RadialBlurParam_Offset; // 0x3e8 (Size: 0x4, Type: NameProperty)
    FName RadialBlurParam_Transition; // 0x3ec (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3f0[0x8]; // 0x3f0 (Size: 0x8, Type: PaddingProperty)
    FAudioGameplayBehaviorInstance DraftingAudioBehavior; // 0x3f8 (Size: 0x10, Type: StructProperty)
    UNiagaraComponent* DraftingFX; // 0x408 (Size: 0x8, Type: ObjectProperty)
    FName DraftingParam_Spawn; // 0x410 (Size: 0x4, Type: NameProperty)
    FName DraftingParam_SpeedGain; // 0x414 (Size: 0x4, Type: NameProperty)
    FName DraftingParam_Amount; // 0x418 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_41c[0x4]; // 0x41c (Size: 0x4, Type: PaddingProperty)
    FAudioGameplayBehaviorInstance WorldBonusSpeedAudioBehavior; // 0x420 (Size: 0x10, Type: StructProperty)
    FName WBSGroupEvent_OnBonusSpeedActivated; // 0x430 (Size: 0x4, Type: NameProperty)
    FName WBSGroupEvent_OnBonusSpeedDeactivated; // 0x434 (Size: 0x4, Type: NameProperty)
    FName WBSGroupEvent_OnWorldBonusSpeedStackGained; // 0x438 (Size: 0x4, Type: NameProperty)
    FGameplayTag DemolishTag_RaceFinished; // 0x43c (Size: 0x4, Type: StructProperty)
    FAudioGameplayBehaviorInstance RespawnAudioBehavior; // 0x440 (Size: 0x10, Type: StructProperty)
    FAudioGameplayBehaviorInstance DespawnAudioBehavior; // 0x450 (Size: 0x10, Type: StructProperty)
    UNiagaraComponent* TaillightTrailFX_Left; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* TaillightTrailFX_Right; // 0x468 (Size: 0x8, Type: ObjectProperty)
    FName TaillightTrailSocket_Left; // 0x470 (Size: 0x4, Type: NameProperty)
    FName TaillightTrailSocket_Right; // 0x474 (Size: 0x4, Type: NameProperty)
    float TaillightTrail_MinForwardSpeed; // 0x478 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_47c[0x4]; // 0x47c (Size: 0x4, Type: PaddingProperty)
    UNiagaraComponent* TeleportFx; // 0x480 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* TeleportEnterSystem; // 0x488 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* TeleportExitSystem; // 0x490 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* EnvironmentFx; // 0x498 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_4a0[0x20]; // 0x4a0 (Size: 0x20, Type: PaddingProperty)
    FAudioGameplayBehaviorInstance UnderthrustAudioBehavior; // 0x4c0 (Size: 0x10, Type: StructProperty)
    FAudioGameplayBehaviorInstance WheelsAudioBehavior; // 0x4d0 (Size: 0x10, Type: StructProperty)
    FName FrontLeftWheelContactBone; // 0x4e0 (Size: 0x4, Type: NameProperty)
    FName FrontRightWheelContactBone; // 0x4e4 (Size: 0x4, Type: NameProperty)
    FName BackRightWheelContactBone; // 0x4e8 (Size: 0x4, Type: NameProperty)
    FName BackLeftWheelContactBone; // 0x4ec (Size: 0x4, Type: NameProperty)
    TArray<FDelMarVehicleCosmeticWheelInfo> WheelInfos; // 0x4f0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_500[0xa0]; // 0x500 (Size: 0xa0, Type: PaddingProperty)
    float FxSideSpeedThreshold; // 0x5a0 (Size: 0x4, Type: FloatProperty)
    float FxForwardSpeedThreshold; // 0x5a4 (Size: 0x4, Type: FloatProperty)

public:
    void AddBoosterActivationFlags(EDelMarVehicleBoosterFlags& Flags, FName& Name); // 0x11d267c0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    TArray<UNiagaraComponent*> GetBoosters(EDelMarVehicleBoosterFlags& Flags) const; // 0x11d27200 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RemoveBoosterActivationFlags(FName& Name); // 0x11d29c80 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    bool ShouldTriggerFX() const; // 0x11d2b19c (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    FName GetWheelContactBoneName(EDelMarVehicleWheelIndex& WheelIndex) const; // 0x11d28308 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void HandleOnAppliedSystemFinished(UNiagaraComponent*& System); // 0x11d28874 (Index: 0x3, Flags: Final|Native|Protected)
    void HandleOnRemovedSystemFinished(UNiagaraComponent*& System); // 0x11d289a0 (Index: 0x4, Flags: Final|Native|Protected)
    void InitializeUnderthrustVfxSockets(); // 0x11d28cd8 (Index: 0x5, Flags: Final|Native|Protected)
    void OnBonusSpeedActivated(); // 0x11d28f18 (Index: 0x6, Flags: Final|Native|Protected)
    void OnBonusSpeedDeactivated(); // 0x11d28f2c (Index: 0x7, Flags: Final|Native|Protected)
    void OnDraftStateChanged(EDelmarDraftingState& CurrentState); // 0x11d28f40 (Index: 0x8, Flags: Final|Native|Protected)
    void OnDriftDeactivated(); // 0x11d2906c (Index: 0x9, Flags: Final|Native|Protected)
    void OnDriftDurationChanged(float& duration); // 0x11d29084 (Index: 0xa, Flags: Final|Native|Protected)
    void OnDriftKickActivated(float& DriftDirection, EDelMarVehicleDriftState& DriftState); // 0x11d291b0 (Index: 0xb, Flags: Final|Native|Protected)
    void OnDriftKickDeactivated(); // 0x11d2906c (Index: 0xc, Flags: Final|Native|Protected)
    void OnEnvironmentEffectCueActivated(FDelMarEnvironmentVFX& Effect); // 0x11d293bc (Index: 0xd, Flags: Final|Native|Protected|HasOutParms)
    void OnEnvironmentEffectCueRemoved(); // 0x11d29494 (Index: 0xe, Flags: Final|Native|Protected)
    void OnJumpActivated(); // 0x11d294a8 (Index: 0xf, Flags: Final|Native|Protected)
    void OnKickflipActivated(bool& bLeftSide); // 0x11d294bc (Index: 0x10, Flags: Final|Native|Protected)
    void OnKickflipDeactivated(); // 0x11d295e8 (Index: 0x11, Flags: Final|Native|Protected)
    void OnTeleportEntered(); // 0x11d29600 (Index: 0x12, Flags: Final|Native|Protected)
    void OnTeleportExited(); // 0x11d29614 (Index: 0x13, Flags: Final|Native|Protected)
    void OnUnderthrustActivated(); // 0x11d29628 (Index: 0x14, Flags: Final|Native|Protected)
    void OnUnderthrustDeactivated(); // 0x11d2963c (Index: 0x15, Flags: Final|Native|Protected)
    void OnVehicleDemolished(FGameplayTag& CausedByTag); // 0x11d29650 (Index: 0x16, Flags: Final|Native|Protected)
    void OnVehicleLanded(float& LandingForce, bool& bLandedKickflip); // 0x11d29710 (Index: 0x17, Flags: Final|Native|Protected)
    void OnWorldBonusSpeedStackGained(FGameplayTag& Source, int32_t& Stacks); // 0x11d2991c (Index: 0x18, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarUnifiedVehicleCosmeticActor) == 0x5a8, "Size mismatch for ADelMarUnifiedVehicleCosmeticActor");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, CachedSideBoosters) == 0x2e0, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::CachedSideBoosters");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, SideBoosterParam_Scale) == 0x2f4, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::SideBoosterParam_Scale");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, Boosters) == 0x2f8, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::Boosters");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, UnderthrustVfxData) == 0x308, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::UnderthrustVfxData");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, BodySkeletalMeshComponent) == 0x390, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::BodySkeletalMeshComponent");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, KickflipAudioBehavior) == 0x398, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::KickflipAudioBehavior");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, JumpAudioBehavior) == 0x3a8, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::JumpAudioBehavior");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, JumpFX) == 0x3b8, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::JumpFX");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, SuperSonicFX) == 0x3c0, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::SuperSonicFX");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, SuperSonicRadialBlurMaterial) == 0x3c8, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::SuperSonicRadialBlurMaterial");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, SuperSonicRadialBlurMID) == 0x3d0, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::SuperSonicRadialBlurMID");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, SuperSonicBlurOffset) == 0x3d8, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::SuperSonicBlurOffset");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, SuperSonicForwardSpeedMin) == 0x3dc, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::SuperSonicForwardSpeedMin");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, SuperSonicForwardSpeedMax) == 0x3e0, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::SuperSonicForwardSpeedMax");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, SuperSonicParam_Spawn) == 0x3e4, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::SuperSonicParam_Spawn");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, RadialBlurParam_Offset) == 0x3e8, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::RadialBlurParam_Offset");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, RadialBlurParam_Transition) == 0x3ec, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::RadialBlurParam_Transition");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, DraftingAudioBehavior) == 0x3f8, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::DraftingAudioBehavior");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, DraftingFX) == 0x408, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::DraftingFX");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, DraftingParam_Spawn) == 0x410, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::DraftingParam_Spawn");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, DraftingParam_SpeedGain) == 0x414, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::DraftingParam_SpeedGain");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, DraftingParam_Amount) == 0x418, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::DraftingParam_Amount");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, WorldBonusSpeedAudioBehavior) == 0x420, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::WorldBonusSpeedAudioBehavior");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, WBSGroupEvent_OnBonusSpeedActivated) == 0x430, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::WBSGroupEvent_OnBonusSpeedActivated");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, WBSGroupEvent_OnBonusSpeedDeactivated) == 0x434, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::WBSGroupEvent_OnBonusSpeedDeactivated");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, WBSGroupEvent_OnWorldBonusSpeedStackGained) == 0x438, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::WBSGroupEvent_OnWorldBonusSpeedStackGained");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, DemolishTag_RaceFinished) == 0x43c, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::DemolishTag_RaceFinished");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, RespawnAudioBehavior) == 0x440, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::RespawnAudioBehavior");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, DespawnAudioBehavior) == 0x450, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::DespawnAudioBehavior");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, TaillightTrailFX_Left) == 0x460, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::TaillightTrailFX_Left");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, TaillightTrailFX_Right) == 0x468, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::TaillightTrailFX_Right");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, TaillightTrailSocket_Left) == 0x470, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::TaillightTrailSocket_Left");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, TaillightTrailSocket_Right) == 0x474, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::TaillightTrailSocket_Right");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, TaillightTrail_MinForwardSpeed) == 0x478, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::TaillightTrail_MinForwardSpeed");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, TeleportFx) == 0x480, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::TeleportFx");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, TeleportEnterSystem) == 0x488, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::TeleportEnterSystem");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, TeleportExitSystem) == 0x490, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::TeleportExitSystem");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, EnvironmentFx) == 0x498, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::EnvironmentFx");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, UnderthrustAudioBehavior) == 0x4c0, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::UnderthrustAudioBehavior");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, WheelsAudioBehavior) == 0x4d0, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::WheelsAudioBehavior");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, FrontLeftWheelContactBone) == 0x4e0, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::FrontLeftWheelContactBone");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, FrontRightWheelContactBone) == 0x4e4, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::FrontRightWheelContactBone");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, BackRightWheelContactBone) == 0x4e8, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::BackRightWheelContactBone");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, BackLeftWheelContactBone) == 0x4ec, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::BackLeftWheelContactBone");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, WheelInfos) == 0x4f0, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::WheelInfos");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, FxSideSpeedThreshold) == 0x5a0, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::FxSideSpeedThreshold");
static_assert(offsetof(ADelMarUnifiedVehicleCosmeticActor, FxForwardSpeedThreshold) == 0x5a4, "Offset mismatch for ADelMarUnifiedVehicleCosmeticActor::FxForwardSpeedThreshold");

// Size: 0x710 (Inherited: 0x8d8, Single: 0xfffffe38)
class UDelMarVehicleAnimInstance : public UFortBaseAnimInstance
{
public:
    FDelMarBouncyChassisState BouncyChassis; // 0x4c8 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_4d4[0x4]; // 0x4d4 (Size: 0x4, Type: PaddingProperty)
    FDelMarBouncyChassisSetup BouncyChassisSetup; // 0x4d8 (Size: 0x58, Type: StructProperty)
    float BouncyChassisBlendRate; // 0x530 (Size: 0x4, Type: FloatProperty)
    float VisualSteerAngleInterpRate; // 0x534 (Size: 0x4, Type: FloatProperty)
    float WheelLerpSpeed; // 0x538 (Size: 0x4, Type: FloatProperty)
    float SuspensionInterpRate; // 0x53c (Size: 0x4, Type: FloatProperty)
    float AirSpinAccel; // 0x540 (Size: 0x4, Type: FloatProperty)
    float AirSpinBrake; // 0x544 (Size: 0x4, Type: FloatProperty)
    float AirSpinDecayRate; // 0x548 (Size: 0x4, Type: FloatProperty)
    FDelMarVehicleAnimInfo VehicleInfo; // 0x54c (Size: 0x8, Type: StructProperty)
    bool bThrottling; // 0x554 (Size: 0x1, Type: BoolProperty)
    bool bReversing; // 0x555 (Size: 0x1, Type: BoolProperty)
    bool bAccelerating; // 0x556 (Size: 0x1, Type: BoolProperty)
    bool bBraking; // 0x557 (Size: 0x1, Type: BoolProperty)
    float Throttle; // 0x558 (Size: 0x4, Type: FloatProperty)
    float Steering; // 0x55c (Size: 0x4, Type: FloatProperty)
    float SteeringAngle; // 0x560 (Size: 0x4, Type: FloatProperty)
    bool bWheelsOnGround; // 0x564 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_565[0x3]; // 0x565 (Size: 0x3, Type: PaddingProperty)
    float ForwardSpeed; // 0x568 (Size: 0x4, Type: FloatProperty)
    bool bDriftBoostActive; // 0x56c (Size: 0x1, Type: BoolProperty)
    bool bUnderthrustActive; // 0x56d (Size: 0x1, Type: BoolProperty)
    bool bDriftActive; // 0x56e (Size: 0x1, Type: BoolProperty)
    bool bKickflipActive; // 0x56f (Size: 0x1, Type: BoolProperty)
    bool bJumpActive; // 0x570 (Size: 0x1, Type: BoolProperty)
    bool bTurboActive; // 0x571 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_572[0x2]; // 0x572 (Size: 0x2, Type: PaddingProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoFR; // 0x574 (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoFL; // 0x590 (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoBR; // 0x5ac (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoBL; // 0x5c8 (Size: 0x1c, Type: StructProperty)
    uint8_t Pad_5e4[0x12c]; // 0x5e4 (Size: 0x12c, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarVehicleAnimInstance) == 0x710, "Size mismatch for UDelMarVehicleAnimInstance");
static_assert(offsetof(UDelMarVehicleAnimInstance, BouncyChassis) == 0x4c8, "Offset mismatch for UDelMarVehicleAnimInstance::BouncyChassis");
static_assert(offsetof(UDelMarVehicleAnimInstance, BouncyChassisSetup) == 0x4d8, "Offset mismatch for UDelMarVehicleAnimInstance::BouncyChassisSetup");
static_assert(offsetof(UDelMarVehicleAnimInstance, BouncyChassisBlendRate) == 0x530, "Offset mismatch for UDelMarVehicleAnimInstance::BouncyChassisBlendRate");
static_assert(offsetof(UDelMarVehicleAnimInstance, VisualSteerAngleInterpRate) == 0x534, "Offset mismatch for UDelMarVehicleAnimInstance::VisualSteerAngleInterpRate");
static_assert(offsetof(UDelMarVehicleAnimInstance, WheelLerpSpeed) == 0x538, "Offset mismatch for UDelMarVehicleAnimInstance::WheelLerpSpeed");
static_assert(offsetof(UDelMarVehicleAnimInstance, SuspensionInterpRate) == 0x53c, "Offset mismatch for UDelMarVehicleAnimInstance::SuspensionInterpRate");
static_assert(offsetof(UDelMarVehicleAnimInstance, AirSpinAccel) == 0x540, "Offset mismatch for UDelMarVehicleAnimInstance::AirSpinAccel");
static_assert(offsetof(UDelMarVehicleAnimInstance, AirSpinBrake) == 0x544, "Offset mismatch for UDelMarVehicleAnimInstance::AirSpinBrake");
static_assert(offsetof(UDelMarVehicleAnimInstance, AirSpinDecayRate) == 0x548, "Offset mismatch for UDelMarVehicleAnimInstance::AirSpinDecayRate");
static_assert(offsetof(UDelMarVehicleAnimInstance, VehicleInfo) == 0x54c, "Offset mismatch for UDelMarVehicleAnimInstance::VehicleInfo");
static_assert(offsetof(UDelMarVehicleAnimInstance, bThrottling) == 0x554, "Offset mismatch for UDelMarVehicleAnimInstance::bThrottling");
static_assert(offsetof(UDelMarVehicleAnimInstance, bReversing) == 0x555, "Offset mismatch for UDelMarVehicleAnimInstance::bReversing");
static_assert(offsetof(UDelMarVehicleAnimInstance, bAccelerating) == 0x556, "Offset mismatch for UDelMarVehicleAnimInstance::bAccelerating");
static_assert(offsetof(UDelMarVehicleAnimInstance, bBraking) == 0x557, "Offset mismatch for UDelMarVehicleAnimInstance::bBraking");
static_assert(offsetof(UDelMarVehicleAnimInstance, Throttle) == 0x558, "Offset mismatch for UDelMarVehicleAnimInstance::Throttle");
static_assert(offsetof(UDelMarVehicleAnimInstance, Steering) == 0x55c, "Offset mismatch for UDelMarVehicleAnimInstance::Steering");
static_assert(offsetof(UDelMarVehicleAnimInstance, SteeringAngle) == 0x560, "Offset mismatch for UDelMarVehicleAnimInstance::SteeringAngle");
static_assert(offsetof(UDelMarVehicleAnimInstance, bWheelsOnGround) == 0x564, "Offset mismatch for UDelMarVehicleAnimInstance::bWheelsOnGround");
static_assert(offsetof(UDelMarVehicleAnimInstance, ForwardSpeed) == 0x568, "Offset mismatch for UDelMarVehicleAnimInstance::ForwardSpeed");
static_assert(offsetof(UDelMarVehicleAnimInstance, bDriftBoostActive) == 0x56c, "Offset mismatch for UDelMarVehicleAnimInstance::bDriftBoostActive");
static_assert(offsetof(UDelMarVehicleAnimInstance, bUnderthrustActive) == 0x56d, "Offset mismatch for UDelMarVehicleAnimInstance::bUnderthrustActive");
static_assert(offsetof(UDelMarVehicleAnimInstance, bDriftActive) == 0x56e, "Offset mismatch for UDelMarVehicleAnimInstance::bDriftActive");
static_assert(offsetof(UDelMarVehicleAnimInstance, bKickflipActive) == 0x56f, "Offset mismatch for UDelMarVehicleAnimInstance::bKickflipActive");
static_assert(offsetof(UDelMarVehicleAnimInstance, bJumpActive) == 0x570, "Offset mismatch for UDelMarVehicleAnimInstance::bJumpActive");
static_assert(offsetof(UDelMarVehicleAnimInstance, bTurboActive) == 0x571, "Offset mismatch for UDelMarVehicleAnimInstance::bTurboActive");
static_assert(offsetof(UDelMarVehicleAnimInstance, WheelInfoFR) == 0x574, "Offset mismatch for UDelMarVehicleAnimInstance::WheelInfoFR");
static_assert(offsetof(UDelMarVehicleAnimInstance, WheelInfoFL) == 0x590, "Offset mismatch for UDelMarVehicleAnimInstance::WheelInfoFL");
static_assert(offsetof(UDelMarVehicleAnimInstance, WheelInfoBR) == 0x5ac, "Offset mismatch for UDelMarVehicleAnimInstance::WheelInfoBR");
static_assert(offsetof(UDelMarVehicleAnimInstance, WheelInfoBL) == 0x5c8, "Offset mismatch for UDelMarVehicleAnimInstance::WheelInfoBL");

// Size: 0x4f0 (Inherited: 0x8d8, Single: 0xfffffc18)
class UDelMarWheelAnimInstance : public UFortBaseAnimInstance
{
public:
    uint8_t Pad_4d0[0x14]; // 0x4d0 (Size: 0x14, Type: PaddingProperty)
    float SpinDegrees; // 0x4e4 (Size: 0x4, Type: FloatProperty)
    UDelMarVehicleAnimInstance* ParentAnimInstance; // 0x4e8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDelMarWheelAnimInstance) == 0x4f0, "Size mismatch for UDelMarWheelAnimInstance");
static_assert(offsetof(UDelMarWheelAnimInstance, SpinDegrees) == 0x4e4, "Offset mismatch for UDelMarWheelAnimInstance::SpinDegrees");
static_assert(offsetof(UDelMarWheelAnimInstance, ParentAnimInstance) == 0x4e8, "Offset mismatch for UDelMarWheelAnimInstance::ParentAnimInstance");

// Size: 0x378 (Inherited: 0x5b0, Single: 0xfffffdc8)
class ADelMarBodyCosmeticActor : public ADelMarCosmeticActor
{
public:
    TArray<FDelMarVehicleWheelSetup> FrontLeftWheelsBoneNames; // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarVehicleWheelSetup> FrontRightWheelsBoneNames; // 0x2f0 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarVehicleWheelSetup> BackRightWheelsBoneNames; // 0x300 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarVehicleWheelSetup> BackLeftWheelsBoneNames; // 0x310 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarVehicleBooster> LeftBoostersInfo; // 0x320 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarVehicleBooster> RightBoostersInfo; // 0x330 (Size: 0x10, Type: ArrayProperty)
    USkeletalMesh* SkeletalMesh; // 0x340 (Size: 0x8, Type: ObjectProperty)
    UPhysicsAsset* PhysicsAsset; // 0x348 (Size: 0x8, Type: ObjectProperty)
    UClass* AnimInstanceClass; // 0x350 (Size: 0x8, Type: ClassProperty)
    UDelMarVehicleBodySetup* BodySetup; // 0x358 (Size: 0x8, Type: ObjectProperty)
    FVector WheelContactFxOffset; // 0x360 (Size: 0x18, Type: StructProperty)

public:
    UClass* GetAnimInstanceClass() const; // 0x11d27058 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FDelMarVehicleWheelSetup> GetBackLeftWheelsBoneNames() const; // 0x11d27094 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FDelMarVehicleWheelSetup> GetBackRightWheelsBoneNames() const; // 0x11d270d0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarVehicleBodySetup* GetBodySetup() const; // 0x5a4edfc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UNiagaraComponent* GetBoosterBySocketName(const FName SocketName) const; // 0x11d2710c (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TArray<FDelMarVehicleWheelSetup> GetFrontLeftWheelsBoneNames() const; // 0x11d2752c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FDelMarVehicleWheelSetup> GetFrontRightWheelsBoneNames() const; // 0x11d27568 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FDelMarVehicleBooster> GetLeftBoostersInfo() const; // 0x11d27b64 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UPhysicsAsset* GetPhysicsAsset() const; // 0x4de5ed4 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FDelMarVehicleBooster> GetRightBoostersInfo() const; // 0x11d281ec (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    USkeletalMesh* GetSkeletalMesh() const; // 0xdf72438 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector GetWheelCosmeticActorOffset() const; // 0xa409534 (Index: 0xb, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    TArray<FDelMarVehicleWheelSetup> GetWheelSetups(EDelMarVehicleWheelIndex& WheelIndex) const; // 0x11d28568 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(ADelMarBodyCosmeticActor) == 0x378, "Size mismatch for ADelMarBodyCosmeticActor");
static_assert(offsetof(ADelMarBodyCosmeticActor, FrontLeftWheelsBoneNames) == 0x2e0, "Offset mismatch for ADelMarBodyCosmeticActor::FrontLeftWheelsBoneNames");
static_assert(offsetof(ADelMarBodyCosmeticActor, FrontRightWheelsBoneNames) == 0x2f0, "Offset mismatch for ADelMarBodyCosmeticActor::FrontRightWheelsBoneNames");
static_assert(offsetof(ADelMarBodyCosmeticActor, BackRightWheelsBoneNames) == 0x300, "Offset mismatch for ADelMarBodyCosmeticActor::BackRightWheelsBoneNames");
static_assert(offsetof(ADelMarBodyCosmeticActor, BackLeftWheelsBoneNames) == 0x310, "Offset mismatch for ADelMarBodyCosmeticActor::BackLeftWheelsBoneNames");
static_assert(offsetof(ADelMarBodyCosmeticActor, LeftBoostersInfo) == 0x320, "Offset mismatch for ADelMarBodyCosmeticActor::LeftBoostersInfo");
static_assert(offsetof(ADelMarBodyCosmeticActor, RightBoostersInfo) == 0x330, "Offset mismatch for ADelMarBodyCosmeticActor::RightBoostersInfo");
static_assert(offsetof(ADelMarBodyCosmeticActor, SkeletalMesh) == 0x340, "Offset mismatch for ADelMarBodyCosmeticActor::SkeletalMesh");
static_assert(offsetof(ADelMarBodyCosmeticActor, PhysicsAsset) == 0x348, "Offset mismatch for ADelMarBodyCosmeticActor::PhysicsAsset");
static_assert(offsetof(ADelMarBodyCosmeticActor, AnimInstanceClass) == 0x350, "Offset mismatch for ADelMarBodyCosmeticActor::AnimInstanceClass");
static_assert(offsetof(ADelMarBodyCosmeticActor, BodySetup) == 0x358, "Offset mismatch for ADelMarBodyCosmeticActor::BodySetup");
static_assert(offsetof(ADelMarBodyCosmeticActor, WheelContactFxOffset) == 0x360, "Offset mismatch for ADelMarBodyCosmeticActor::WheelContactFxOffset");

// Size: 0x310 (Inherited: 0x5b0, Single: 0xfffffd60)
class ADelMarBoosterCosmeticActor : public ADelMarCosmeticActor
{
public:
    UNiagaraSystem* BoosterFx; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    TArray<FDelMarVehicleBooster> LeftBoosters; // 0x2e8 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarVehicleBooster> RightBoosters; // 0x2f8 (Size: 0x10, Type: ArrayProperty)
    USkeletalMeshComponent* BodySkeletalMeshComponent; // 0x308 (Size: 0x8, Type: ObjectProperty)

public:
    TArray<UNiagaraComponent*> GetAllBoosters(bool& bFrontBoosters, bool& bBackBoosters, bool& bSideBoosters, bool& bDownBoosters) const; // 0x11d26aa0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UNiagaraComponent*> GetLeftBoosters(bool& bFrontBoosters, bool& bBackBoosters, bool& bSideBoosters, bool& bDownBoosters) const; // 0x11d275a4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UNiagaraComponent*> GetRightBoosters(bool& bFrontBoosters, bool& bBackBoosters, bool& bSideBoosters, bool& bDownBoosters) const; // 0x11d27c2c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetAllBoostersEnabled(bool& bSetFrontBoosters, bool& bSetBackBoosters, bool& bSetSideBoosters, bool& bSetDownBoosters, bool& bEnabled, bool& bReset); // 0x11d29da8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void SetLeftBoostersEnabled(bool& bSetFrontBoosters, bool& bSetBackBoosters, bool& bSetSideBoosters, bool& bSetDownBoosters, bool& bEnabled, bool& bReset); // 0x11d2a334 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SetRightBoostersEnabled(bool& bSetFrontBoosters, bool& bSetBackBoosters, bool& bSetSideBoosters, bool& bSetDownBoosters, bool& bEnabled, bool& bReset); // 0x11d2a9b0 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ADelMarBoosterCosmeticActor) == 0x310, "Size mismatch for ADelMarBoosterCosmeticActor");
static_assert(offsetof(ADelMarBoosterCosmeticActor, BoosterFx) == 0x2e0, "Offset mismatch for ADelMarBoosterCosmeticActor::BoosterFx");
static_assert(offsetof(ADelMarBoosterCosmeticActor, LeftBoosters) == 0x2e8, "Offset mismatch for ADelMarBoosterCosmeticActor::LeftBoosters");
static_assert(offsetof(ADelMarBoosterCosmeticActor, RightBoosters) == 0x2f8, "Offset mismatch for ADelMarBoosterCosmeticActor::RightBoosters");
static_assert(offsetof(ADelMarBoosterCosmeticActor, BodySkeletalMeshComponent) == 0x308, "Offset mismatch for ADelMarBoosterCosmeticActor::BodySkeletalMeshComponent");

// Size: 0x328 (Inherited: 0x5b0, Single: 0xfffffd78)
class ADelMarEngineAudioCosmeticActor : public ADelMarCosmeticActor
{
public:
    FAudioGameplayBehaviorInstance EngineAudio; // 0x2e0 (Size: 0x10, Type: StructProperty)
    float NonLocalVelocityInterpSpeed; // 0x2f0 (Size: 0x4, Type: FloatProperty)
    bool bDisabled; // 0x2f4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2f5[0x3]; // 0x2f5 (Size: 0x3, Type: PaddingProperty)
    UAudioComponentGroup* ComponentGroup; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UAudioMotorModelComponent* MotorModel; // 0x300 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_308[0x20]; // 0x308 (Size: 0x20, Type: PaddingProperty)

public:
    UAudioComponentGroup* GetComponentGroup() const; // 0xe594bf4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(ADelMarEngineAudioCosmeticActor) == 0x328, "Size mismatch for ADelMarEngineAudioCosmeticActor");
static_assert(offsetof(ADelMarEngineAudioCosmeticActor, EngineAudio) == 0x2e0, "Offset mismatch for ADelMarEngineAudioCosmeticActor::EngineAudio");
static_assert(offsetof(ADelMarEngineAudioCosmeticActor, NonLocalVelocityInterpSpeed) == 0x2f0, "Offset mismatch for ADelMarEngineAudioCosmeticActor::NonLocalVelocityInterpSpeed");
static_assert(offsetof(ADelMarEngineAudioCosmeticActor, bDisabled) == 0x2f4, "Offset mismatch for ADelMarEngineAudioCosmeticActor::bDisabled");
static_assert(offsetof(ADelMarEngineAudioCosmeticActor, ComponentGroup) == 0x2f8, "Offset mismatch for ADelMarEngineAudioCosmeticActor::ComponentGroup");
static_assert(offsetof(ADelMarEngineAudioCosmeticActor, MotorModel) == 0x300, "Offset mismatch for ADelMarEngineAudioCosmeticActor::MotorModel");

// Size: 0x3c0 (Inherited: 0x5b0, Single: 0xfffffe10)
class ADelMarWheelContactFxCosmeticActor : public ADelMarCosmeticActor
{
public:
    FAudioGameplayBehaviorInstance WheelSounds; // 0x2e0 (Size: 0x10, Type: StructProperty)
    float FxSideSpeedThreshold; // 0x2f0 (Size: 0x4, Type: FloatProperty)
    float FxForwardSpeedThreshold; // 0x2f4 (Size: 0x4, Type: FloatProperty)
    UPhysicalMaterial* ContactMaterial; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_300[0x8]; // 0x300 (Size: 0x8, Type: PaddingProperty)
    TArray<FDelMarVehicleCosmeticWheelInfo> WheelInfos; // 0x308 (Size: 0x10, Type: ArrayProperty)
    FName FrontLeftWheelContactBone; // 0x318 (Size: 0x4, Type: NameProperty)
    FName FrontRightWheelContactBone; // 0x31c (Size: 0x4, Type: NameProperty)
    FName BackRightWheelContactBone; // 0x320 (Size: 0x4, Type: NameProperty)
    FName BackLeftWheelContactBone; // 0x324 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_328[0x98]; // 0x328 (Size: 0x98, Type: PaddingProperty)

protected:
    virtual void BP_UpdateWheelContactFx(FDelMarVehicleCosmeticWheelInfo& const WheelInfo, bool& bActive, float& AbsForwardSpeed, float& AbsSideSpeed); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    UAudioGameplayBehavior* GetAudioBehavior() const; // 0xa200d50 (Index: 0x1, Flags: Final|BlueprintCosmetic|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    FName GetWheelContactBoneName(EDelMarVehicleWheelIndex& WheelIndex) const; // 0x11d28438 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void HandleVehicleLanded(float& LandingForce, bool& bLandedKickflip); // 0x11d28acc (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(ADelMarWheelContactFxCosmeticActor) == 0x3c0, "Size mismatch for ADelMarWheelContactFxCosmeticActor");
static_assert(offsetof(ADelMarWheelContactFxCosmeticActor, WheelSounds) == 0x2e0, "Offset mismatch for ADelMarWheelContactFxCosmeticActor::WheelSounds");
static_assert(offsetof(ADelMarWheelContactFxCosmeticActor, FxSideSpeedThreshold) == 0x2f0, "Offset mismatch for ADelMarWheelContactFxCosmeticActor::FxSideSpeedThreshold");
static_assert(offsetof(ADelMarWheelContactFxCosmeticActor, FxForwardSpeedThreshold) == 0x2f4, "Offset mismatch for ADelMarWheelContactFxCosmeticActor::FxForwardSpeedThreshold");
static_assert(offsetof(ADelMarWheelContactFxCosmeticActor, ContactMaterial) == 0x2f8, "Offset mismatch for ADelMarWheelContactFxCosmeticActor::ContactMaterial");
static_assert(offsetof(ADelMarWheelContactFxCosmeticActor, WheelInfos) == 0x308, "Offset mismatch for ADelMarWheelContactFxCosmeticActor::WheelInfos");
static_assert(offsetof(ADelMarWheelContactFxCosmeticActor, FrontLeftWheelContactBone) == 0x318, "Offset mismatch for ADelMarWheelContactFxCosmeticActor::FrontLeftWheelContactBone");
static_assert(offsetof(ADelMarWheelContactFxCosmeticActor, FrontRightWheelContactBone) == 0x31c, "Offset mismatch for ADelMarWheelContactFxCosmeticActor::FrontRightWheelContactBone");
static_assert(offsetof(ADelMarWheelContactFxCosmeticActor, BackRightWheelContactBone) == 0x320, "Offset mismatch for ADelMarWheelContactFxCosmeticActor::BackRightWheelContactBone");
static_assert(offsetof(ADelMarWheelContactFxCosmeticActor, BackLeftWheelContactBone) == 0x324, "Offset mismatch for ADelMarWheelContactFxCosmeticActor::BackLeftWheelContactBone");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UDelMarCosmeticActorSpawnLogic_Wheel : public UDelMarCosmeticActorSpawnLogic
{
public:
    bool bFrontWheel; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bBackWheel; // 0x29 (Size: 0x1, Type: BoolProperty)
    uint8_t AttachPoint; // 0x2a (Size: 0x1, Type: EnumProperty)
    uint8_t MirrorType; // 0x2b (Size: 0x1, Type: EnumProperty)
    bool bOnlyFxEligibleWheels; // 0x2c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarCosmeticActorSpawnLogic_Wheel) == 0x30, "Size mismatch for UDelMarCosmeticActorSpawnLogic_Wheel");
static_assert(offsetof(UDelMarCosmeticActorSpawnLogic_Wheel, bFrontWheel) == 0x28, "Offset mismatch for UDelMarCosmeticActorSpawnLogic_Wheel::bFrontWheel");
static_assert(offsetof(UDelMarCosmeticActorSpawnLogic_Wheel, bBackWheel) == 0x29, "Offset mismatch for UDelMarCosmeticActorSpawnLogic_Wheel::bBackWheel");
static_assert(offsetof(UDelMarCosmeticActorSpawnLogic_Wheel, AttachPoint) == 0x2a, "Offset mismatch for UDelMarCosmeticActorSpawnLogic_Wheel::AttachPoint");
static_assert(offsetof(UDelMarCosmeticActorSpawnLogic_Wheel, MirrorType) == 0x2b, "Offset mismatch for UDelMarCosmeticActorSpawnLogic_Wheel::MirrorType");
static_assert(offsetof(UDelMarCosmeticActorSpawnLogic_Wheel, bOnlyFxEligibleWheels) == 0x2c, "Offset mismatch for UDelMarCosmeticActorSpawnLogic_Wheel::bOnlyFxEligibleWheels");

// Size: 0x2e8 (Inherited: 0x5b0, Single: 0xfffffd38)
class ADelMarWheelsCosmeticActor : public ADelMarCosmeticActor
{
public:
    uint8_t WheelIndex; // 0x2e0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2e1[0x7]; // 0x2e1 (Size: 0x7, Type: PaddingProperty)

public:
    EDelMarWheelMirrorType GetMirrorType() const; // 0x11d27c08 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsBackWheel() const; // 0x11d28cec (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsFrontWheel() const; // 0x11d28d0c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsLeftWheel() const; // 0x11d28d28 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsMirrored() const; // 0x11d28d28 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsRightWheel() const; // 0x11d28d44 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsWheelOnGround() const; // 0x11d28ebc (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(ADelMarWheelsCosmeticActor) == 0x2e8, "Size mismatch for ADelMarWheelsCosmeticActor");
static_assert(offsetof(ADelMarWheelsCosmeticActor, WheelIndex) == 0x2e0, "Offset mismatch for ADelMarWheelsCosmeticActor::WheelIndex");

// Size: 0x2f0 (Inherited: 0x898, Single: 0xfffffa58)
class ADelMarWheelSKCosmeticActor : public ADelMarWheelsCosmeticActor
{
public:
    USkeletalMeshComponent* SkeletalMeshComponent; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ADelMarWheelSKCosmeticActor) == 0x2f0, "Size mismatch for ADelMarWheelSKCosmeticActor");
static_assert(offsetof(ADelMarWheelSKCosmeticActor, SkeletalMeshComponent) == 0x2e8, "Offset mismatch for ADelMarWheelSKCosmeticActor::SkeletalMeshComponent");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarVehicleAnimInfo
{
    float SteerAngleDegrees; // 0x0 (Size: 0x4, Type: FloatProperty)
    float VisualSteerAngleDegrees; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleAnimInfo) == 0x8, "Size mismatch for FDelMarVehicleAnimInfo");
static_assert(offsetof(FDelMarVehicleAnimInfo, SteerAngleDegrees) == 0x0, "Offset mismatch for FDelMarVehicleAnimInfo::SteerAngleDegrees");
static_assert(offsetof(FDelMarVehicleAnimInfo, VisualSteerAngleDegrees) == 0x4, "Offset mismatch for FDelMarVehicleAnimInfo::VisualSteerAngleDegrees");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FDelMarVehicleWheelAnimInfo
{
    float SpringToWheelOffsetZ; // 0x0 (Size: 0x4, Type: FloatProperty)
    FFloatInterval SpringTravelRange; // 0x4 (Size: 0x8, Type: StructProperty)
    float WheelRadius; // 0xc (Size: 0x4, Type: FloatProperty)
    float TravelDistance; // 0x10 (Size: 0x4, Type: FloatProperty)
    float SpinSpeedDegrees; // 0x14 (Size: 0x4, Type: FloatProperty)
    float SpinDegrees; // 0x18 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarVehicleWheelAnimInfo) == 0x1c, "Size mismatch for FDelMarVehicleWheelAnimInfo");
static_assert(offsetof(FDelMarVehicleWheelAnimInfo, SpringToWheelOffsetZ) == 0x0, "Offset mismatch for FDelMarVehicleWheelAnimInfo::SpringToWheelOffsetZ");
static_assert(offsetof(FDelMarVehicleWheelAnimInfo, SpringTravelRange) == 0x4, "Offset mismatch for FDelMarVehicleWheelAnimInfo::SpringTravelRange");
static_assert(offsetof(FDelMarVehicleWheelAnimInfo, WheelRadius) == 0xc, "Offset mismatch for FDelMarVehicleWheelAnimInfo::WheelRadius");
static_assert(offsetof(FDelMarVehicleWheelAnimInfo, TravelDistance) == 0x10, "Offset mismatch for FDelMarVehicleWheelAnimInfo::TravelDistance");
static_assert(offsetof(FDelMarVehicleWheelAnimInfo, SpinSpeedDegrees) == 0x14, "Offset mismatch for FDelMarVehicleWheelAnimInfo::SpinSpeedDegrees");
static_assert(offsetof(FDelMarVehicleWheelAnimInfo, SpinDegrees) == 0x18, "Offset mismatch for FDelMarVehicleWheelAnimInfo::SpinDegrees");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarVehicleBooster
{
    UNiagaraSystem* BoosterSystem; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* NiagaraComponent; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FName BoosterSocket; // 0x10 (Size: 0x4, Type: NameProperty)
    char BitFlags; // 0x14 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleBooster) == 0x18, "Size mismatch for FDelMarVehicleBooster");
static_assert(offsetof(FDelMarVehicleBooster, BoosterSystem) == 0x0, "Offset mismatch for FDelMarVehicleBooster::BoosterSystem");
static_assert(offsetof(FDelMarVehicleBooster, NiagaraComponent) == 0x8, "Offset mismatch for FDelMarVehicleBooster::NiagaraComponent");
static_assert(offsetof(FDelMarVehicleBooster, BoosterSocket) == 0x10, "Offset mismatch for FDelMarVehicleBooster::BoosterSocket");
static_assert(offsetof(FDelMarVehicleBooster, BitFlags) == 0x14, "Offset mismatch for FDelMarVehicleBooster::BitFlags");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarVehicleUnderthrustSocket
{
    FName SocketName; // 0x0 (Size: 0x4, Type: NameProperty)
    char SideFlags; // 0x4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleUnderthrustSocket) == 0x8, "Size mismatch for FDelMarVehicleUnderthrustSocket");
static_assert(offsetof(FDelMarVehicleUnderthrustSocket, SocketName) == 0x0, "Offset mismatch for FDelMarVehicleUnderthrustSocket::SocketName");
static_assert(offsetof(FDelMarVehicleUnderthrustSocket, SideFlags) == 0x4, "Offset mismatch for FDelMarVehicleUnderthrustSocket::SideFlags");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FDelMarVehicleUnderthrustVfxData
{
    UNiagaraSystem* UnderthrustVfxSystem; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* NiagaraComponent; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FName NiagaraLocationArrayParam; // 0x10 (Size: 0x4, Type: NameProperty)
    FName NiagaraActivationsArrayParam; // 0x14 (Size: 0x4, Type: NameProperty)
    TArray<FDelMarVehicleUnderthrustSocket> Sockets; // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_28[0x10]; // 0x28 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleUnderthrustVfxData) == 0x38, "Size mismatch for FDelMarVehicleUnderthrustVfxData");
static_assert(offsetof(FDelMarVehicleUnderthrustVfxData, UnderthrustVfxSystem) == 0x0, "Offset mismatch for FDelMarVehicleUnderthrustVfxData::UnderthrustVfxSystem");
static_assert(offsetof(FDelMarVehicleUnderthrustVfxData, NiagaraComponent) == 0x8, "Offset mismatch for FDelMarVehicleUnderthrustVfxData::NiagaraComponent");
static_assert(offsetof(FDelMarVehicleUnderthrustVfxData, NiagaraLocationArrayParam) == 0x10, "Offset mismatch for FDelMarVehicleUnderthrustVfxData::NiagaraLocationArrayParam");
static_assert(offsetof(FDelMarVehicleUnderthrustVfxData, NiagaraActivationsArrayParam) == 0x14, "Offset mismatch for FDelMarVehicleUnderthrustVfxData::NiagaraActivationsArrayParam");
static_assert(offsetof(FDelMarVehicleUnderthrustVfxData, Sockets) == 0x18, "Offset mismatch for FDelMarVehicleUnderthrustVfxData::Sockets");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarVehicleWheelSetup
{
    FName WheelSpinBone; // 0x0 (Size: 0x4, Type: NameProperty)
    FName WheelPivotBone; // 0x4 (Size: 0x4, Type: NameProperty)
    FName WheelContactBone; // 0x8 (Size: 0x4, Type: NameProperty)
    bool bEligibleForPhysMatContactFx; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleWheelSetup) == 0x10, "Size mismatch for FDelMarVehicleWheelSetup");
static_assert(offsetof(FDelMarVehicleWheelSetup, WheelSpinBone) == 0x0, "Offset mismatch for FDelMarVehicleWheelSetup::WheelSpinBone");
static_assert(offsetof(FDelMarVehicleWheelSetup, WheelPivotBone) == 0x4, "Offset mismatch for FDelMarVehicleWheelSetup::WheelPivotBone");
static_assert(offsetof(FDelMarVehicleWheelSetup, WheelContactBone) == 0x8, "Offset mismatch for FDelMarVehicleWheelSetup::WheelContactBone");
static_assert(offsetof(FDelMarVehicleWheelSetup, bEligibleForPhysMatContactFx) == 0xc, "Offset mismatch for FDelMarVehicleWheelSetup::bEligibleForPhysMatContactFx");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarVehicleCosmeticWheelInfo
{
    UNiagaraComponent* ContactParticleComponent; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* ContactParticle; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UPhysicalMaterial* ContactMaterial; // 0x10 (Size: 0x8, Type: ObjectProperty)
    uint8_t WheelIndex; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
    FDelMarVehicleWheelSetup Setup; // 0x1c (Size: 0x10, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarVehicleCosmeticWheelInfo) == 0x30, "Size mismatch for FDelMarVehicleCosmeticWheelInfo");
static_assert(offsetof(FDelMarVehicleCosmeticWheelInfo, ContactParticleComponent) == 0x0, "Offset mismatch for FDelMarVehicleCosmeticWheelInfo::ContactParticleComponent");
static_assert(offsetof(FDelMarVehicleCosmeticWheelInfo, ContactParticle) == 0x8, "Offset mismatch for FDelMarVehicleCosmeticWheelInfo::ContactParticle");
static_assert(offsetof(FDelMarVehicleCosmeticWheelInfo, ContactMaterial) == 0x10, "Offset mismatch for FDelMarVehicleCosmeticWheelInfo::ContactMaterial");
static_assert(offsetof(FDelMarVehicleCosmeticWheelInfo, WheelIndex) == 0x18, "Offset mismatch for FDelMarVehicleCosmeticWheelInfo::WheelIndex");
static_assert(offsetof(FDelMarVehicleCosmeticWheelInfo, Setup) == 0x1c, "Offset mismatch for FDelMarVehicleCosmeticWheelInfo::Setup");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarOverrideParameter_Bool
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    bool Value; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarOverrideParameter_Bool) == 0x8, "Size mismatch for FDelMarOverrideParameter_Bool");
static_assert(offsetof(FDelMarOverrideParameter_Bool, Name) == 0x0, "Offset mismatch for FDelMarOverrideParameter_Bool::Name");
static_assert(offsetof(FDelMarOverrideParameter_Bool, Value) == 0x4, "Offset mismatch for FDelMarOverrideParameter_Bool::Value");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarOverrideParameter_Int
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t Value; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FDelMarOverrideParameter_Int) == 0x8, "Size mismatch for FDelMarOverrideParameter_Int");
static_assert(offsetof(FDelMarOverrideParameter_Int, Name) == 0x0, "Offset mismatch for FDelMarOverrideParameter_Int::Name");
static_assert(offsetof(FDelMarOverrideParameter_Int, Value) == 0x4, "Offset mismatch for FDelMarOverrideParameter_Int::Value");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarOverrideParameter_Float
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    float Value; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarOverrideParameter_Float) == 0x8, "Size mismatch for FDelMarOverrideParameter_Float");
static_assert(offsetof(FDelMarOverrideParameter_Float, Name) == 0x0, "Offset mismatch for FDelMarOverrideParameter_Float::Name");
static_assert(offsetof(FDelMarOverrideParameter_Float, Value) == 0x4, "Offset mismatch for FDelMarOverrideParameter_Float::Value");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarOverrideParameter_Vector
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector Value; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDelMarOverrideParameter_Vector) == 0x20, "Size mismatch for FDelMarOverrideParameter_Vector");
static_assert(offsetof(FDelMarOverrideParameter_Vector, Name) == 0x0, "Offset mismatch for FDelMarOverrideParameter_Vector::Name");
static_assert(offsetof(FDelMarOverrideParameter_Vector, Value) == 0x8, "Offset mismatch for FDelMarOverrideParameter_Vector::Value");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FDelMarOverrideParameter_Color
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    FLinearColor Value; // 0x4 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FDelMarOverrideParameter_Color) == 0x14, "Size mismatch for FDelMarOverrideParameter_Color");
static_assert(offsetof(FDelMarOverrideParameter_Color, Name) == 0x0, "Offset mismatch for FDelMarOverrideParameter_Color::Name");
static_assert(offsetof(FDelMarOverrideParameter_Color, Value) == 0x4, "Offset mismatch for FDelMarOverrideParameter_Color::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarOverrideParameter_Texture
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UTexture* Value; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarOverrideParameter_Texture) == 0x10, "Size mismatch for FDelMarOverrideParameter_Texture");
static_assert(offsetof(FDelMarOverrideParameter_Texture, Name) == 0x0, "Offset mismatch for FDelMarOverrideParameter_Texture::Name");
static_assert(offsetof(FDelMarOverrideParameter_Texture, Value) == 0x8, "Offset mismatch for FDelMarOverrideParameter_Texture::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarOverrideParameter_StaticMesh
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UStaticMesh* Value; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarOverrideParameter_StaticMesh) == 0x10, "Size mismatch for FDelMarOverrideParameter_StaticMesh");
static_assert(offsetof(FDelMarOverrideParameter_StaticMesh, Name) == 0x0, "Offset mismatch for FDelMarOverrideParameter_StaticMesh::Name");
static_assert(offsetof(FDelMarOverrideParameter_StaticMesh, Value) == 0x8, "Offset mismatch for FDelMarOverrideParameter_StaticMesh::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarOverrideParameter_Actor
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    AActor* Value; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarOverrideParameter_Actor) == 0x10, "Size mismatch for FDelMarOverrideParameter_Actor");
static_assert(offsetof(FDelMarOverrideParameter_Actor, Name) == 0x0, "Offset mismatch for FDelMarOverrideParameter_Actor::Name");
static_assert(offsetof(FDelMarOverrideParameter_Actor, Value) == 0x8, "Offset mismatch for FDelMarOverrideParameter_Actor::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDelMarOverrideParameter_Material
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UMaterialInterface* Value; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarOverrideParameter_Material) == 0x10, "Size mismatch for FDelMarOverrideParameter_Material");
static_assert(offsetof(FDelMarOverrideParameter_Material, Name) == 0x0, "Offset mismatch for FDelMarOverrideParameter_Material::Name");
static_assert(offsetof(FDelMarOverrideParameter_Material, Value) == 0x8, "Offset mismatch for FDelMarOverrideParameter_Material::Value");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarMaterialParameterCollection
{
    TArray<FDelMarOverrideParameter_Float> OverrideFloatParameters; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Vector> OverrideVectorParameters; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Texture> OverrideTextureParameters; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarMaterialParameterCollection) == 0x30, "Size mismatch for FDelMarMaterialParameterCollection");
static_assert(offsetof(FDelMarMaterialParameterCollection, OverrideFloatParameters) == 0x0, "Offset mismatch for FDelMarMaterialParameterCollection::OverrideFloatParameters");
static_assert(offsetof(FDelMarMaterialParameterCollection, OverrideVectorParameters) == 0x10, "Offset mismatch for FDelMarMaterialParameterCollection::OverrideVectorParameters");
static_assert(offsetof(FDelMarMaterialParameterCollection, OverrideTextureParameters) == 0x20, "Offset mismatch for FDelMarMaterialParameterCollection::OverrideTextureParameters");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FDelMarNiagaraParameterCollection
{
    UNiagaraSystem* OverrideNiagaraSystem; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FDelMarOverrideParameter_Bool> OverrideBoolParameters; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Int> OverrideIntParameters; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Float> OverrideFloatParameters; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Vector> OverrideVectorParameters; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Color> OverrideColorParameters; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Texture> OverrideTextureParameters; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Material> OverrideMaterialsParameters; // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_StaticMesh> OverrideStaticMeshParameters; // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarOverrideParameter_Actor> OverrideActorParameters; // 0x88 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarNiagaraParameterCollection) == 0x98, "Size mismatch for FDelMarNiagaraParameterCollection");
static_assert(offsetof(FDelMarNiagaraParameterCollection, OverrideNiagaraSystem) == 0x0, "Offset mismatch for FDelMarNiagaraParameterCollection::OverrideNiagaraSystem");
static_assert(offsetof(FDelMarNiagaraParameterCollection, OverrideBoolParameters) == 0x8, "Offset mismatch for FDelMarNiagaraParameterCollection::OverrideBoolParameters");
static_assert(offsetof(FDelMarNiagaraParameterCollection, OverrideIntParameters) == 0x18, "Offset mismatch for FDelMarNiagaraParameterCollection::OverrideIntParameters");
static_assert(offsetof(FDelMarNiagaraParameterCollection, OverrideFloatParameters) == 0x28, "Offset mismatch for FDelMarNiagaraParameterCollection::OverrideFloatParameters");
static_assert(offsetof(FDelMarNiagaraParameterCollection, OverrideVectorParameters) == 0x38, "Offset mismatch for FDelMarNiagaraParameterCollection::OverrideVectorParameters");
static_assert(offsetof(FDelMarNiagaraParameterCollection, OverrideColorParameters) == 0x48, "Offset mismatch for FDelMarNiagaraParameterCollection::OverrideColorParameters");
static_assert(offsetof(FDelMarNiagaraParameterCollection, OverrideTextureParameters) == 0x58, "Offset mismatch for FDelMarNiagaraParameterCollection::OverrideTextureParameters");
static_assert(offsetof(FDelMarNiagaraParameterCollection, OverrideMaterialsParameters) == 0x68, "Offset mismatch for FDelMarNiagaraParameterCollection::OverrideMaterialsParameters");
static_assert(offsetof(FDelMarNiagaraParameterCollection, OverrideStaticMeshParameters) == 0x78, "Offset mismatch for FDelMarNiagaraParameterCollection::OverrideStaticMeshParameters");
static_assert(offsetof(FDelMarNiagaraParameterCollection, OverrideActorParameters) == 0x88, "Offset mismatch for FDelMarNiagaraParameterCollection::OverrideActorParameters");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FDelMarMaterialOverrides
{
    int32_t MaterialInstanceDynamicIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UMaterialInterface* MaterialInterface; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FDelMarMaterialParameterCollection ParameterOverrides; // 0x10 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FDelMarMaterialOverrides) == 0x40, "Size mismatch for FDelMarMaterialOverrides");
static_assert(offsetof(FDelMarMaterialOverrides, MaterialInstanceDynamicIndex) == 0x0, "Offset mismatch for FDelMarMaterialOverrides::MaterialInstanceDynamicIndex");
static_assert(offsetof(FDelMarMaterialOverrides, MaterialInterface) == 0x8, "Offset mismatch for FDelMarMaterialOverrides::MaterialInterface");
static_assert(offsetof(FDelMarMaterialOverrides, ParameterOverrides) == 0x10, "Offset mismatch for FDelMarMaterialOverrides::ParameterOverrides");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FDelMarNiagaraOverrides
{
    FDelMarNiagaraParameterCollection ParameterOverrides; // 0x0 (Size: 0x98, Type: StructProperty)
};

static_assert(sizeof(FDelMarNiagaraOverrides) == 0x98, "Size mismatch for FDelMarNiagaraOverrides");
static_assert(offsetof(FDelMarNiagaraOverrides, ParameterOverrides) == 0x0, "Offset mismatch for FDelMarNiagaraOverrides::ParameterOverrides");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FDelMarParameterOverrides
{
    TArray<FDelMarMaterialOverrides> MaterialOverrides; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FDelMarNiagaraOverrides> NiagaraOverrides; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarParameterOverrides) == 0x20, "Size mismatch for FDelMarParameterOverrides");
static_assert(offsetof(FDelMarParameterOverrides, MaterialOverrides) == 0x0, "Offset mismatch for FDelMarParameterOverrides::MaterialOverrides");
static_assert(offsetof(FDelMarParameterOverrides, NiagaraOverrides) == 0x10, "Offset mismatch for FDelMarParameterOverrides::NiagaraOverrides");

// Size: 0x24 (Inherited: 0x0, Single: 0x24)
struct FDelMarVehicleController_WheelData
{
    FBoneReference SuspensionBone; // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference SteeringBone; // 0xc (Size: 0xc, Type: StructProperty)
    FBoneReference RollBone; // 0x18 (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(FDelMarVehicleController_WheelData) == 0x24, "Size mismatch for FDelMarVehicleController_WheelData");
static_assert(offsetof(FDelMarVehicleController_WheelData, SuspensionBone) == 0x0, "Offset mismatch for FDelMarVehicleController_WheelData::SuspensionBone");
static_assert(offsetof(FDelMarVehicleController_WheelData, SteeringBone) == 0xc, "Offset mismatch for FDelMarVehicleController_WheelData::SteeringBone");
static_assert(offsetof(FDelMarVehicleController_WheelData, RollBone) == 0x18, "Offset mismatch for FDelMarVehicleController_WheelData::RollBone");

// Size: 0x1e8 (Inherited: 0xd8, Single: 0x110)
struct FDelMarAnimNode_VehicleController : FAnimNode_SkeletalControlBase
{
    FDelMarBouncyChassisState BouncyChassis; // 0xc8 (Size: 0xc, Type: StructProperty)
    FDelMarVehicleController_WheelData FrontLeftWheel; // 0xd4 (Size: 0x24, Type: StructProperty)
    FDelMarVehicleController_WheelData FrontRightWheel; // 0xf8 (Size: 0x24, Type: StructProperty)
    FDelMarVehicleController_WheelData BackLeftWheel; // 0x11c (Size: 0x24, Type: StructProperty)
    FDelMarVehicleController_WheelData BackRightWheel; // 0x140 (Size: 0x24, Type: StructProperty)
    FBoneReference ChassisBone; // 0x164 (Size: 0xc, Type: StructProperty)
    FDelMarVehicleAnimInfo VehicleInfo; // 0x170 (Size: 0x8, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoFR; // 0x178 (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoFL; // 0x194 (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoBR; // 0x1b0 (Size: 0x1c, Type: StructProperty)
    FDelMarVehicleWheelAnimInfo WheelInfoBL; // 0x1cc (Size: 0x1c, Type: StructProperty)
};

static_assert(sizeof(FDelMarAnimNode_VehicleController) == 0x1e8, "Size mismatch for FDelMarAnimNode_VehicleController");
static_assert(offsetof(FDelMarAnimNode_VehicleController, BouncyChassis) == 0xc8, "Offset mismatch for FDelMarAnimNode_VehicleController::BouncyChassis");
static_assert(offsetof(FDelMarAnimNode_VehicleController, FrontLeftWheel) == 0xd4, "Offset mismatch for FDelMarAnimNode_VehicleController::FrontLeftWheel");
static_assert(offsetof(FDelMarAnimNode_VehicleController, FrontRightWheel) == 0xf8, "Offset mismatch for FDelMarAnimNode_VehicleController::FrontRightWheel");
static_assert(offsetof(FDelMarAnimNode_VehicleController, BackLeftWheel) == 0x11c, "Offset mismatch for FDelMarAnimNode_VehicleController::BackLeftWheel");
static_assert(offsetof(FDelMarAnimNode_VehicleController, BackRightWheel) == 0x140, "Offset mismatch for FDelMarAnimNode_VehicleController::BackRightWheel");
static_assert(offsetof(FDelMarAnimNode_VehicleController, ChassisBone) == 0x164, "Offset mismatch for FDelMarAnimNode_VehicleController::ChassisBone");
static_assert(offsetof(FDelMarAnimNode_VehicleController, VehicleInfo) == 0x170, "Offset mismatch for FDelMarAnimNode_VehicleController::VehicleInfo");
static_assert(offsetof(FDelMarAnimNode_VehicleController, WheelInfoFR) == 0x178, "Offset mismatch for FDelMarAnimNode_VehicleController::WheelInfoFR");
static_assert(offsetof(FDelMarAnimNode_VehicleController, WheelInfoFL) == 0x194, "Offset mismatch for FDelMarAnimNode_VehicleController::WheelInfoFL");
static_assert(offsetof(FDelMarAnimNode_VehicleController, WheelInfoBR) == 0x1b0, "Offset mismatch for FDelMarAnimNode_VehicleController::WheelInfoBR");
static_assert(offsetof(FDelMarAnimNode_VehicleController, WheelInfoBL) == 0x1cc, "Offset mismatch for FDelMarAnimNode_VehicleController::WheelInfoBL");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDelMarBouncyChassisState
{
    float PitchDegrees; // 0x0 (Size: 0x4, Type: FloatProperty)
    float RollDegrees; // 0x4 (Size: 0x4, Type: FloatProperty)
    float TranslationZ; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarBouncyChassisState) == 0xc, "Size mismatch for FDelMarBouncyChassisState");
static_assert(offsetof(FDelMarBouncyChassisState, PitchDegrees) == 0x0, "Offset mismatch for FDelMarBouncyChassisState::PitchDegrees");
static_assert(offsetof(FDelMarBouncyChassisState, RollDegrees) == 0x4, "Offset mismatch for FDelMarBouncyChassisState::RollDegrees");
static_assert(offsetof(FDelMarBouncyChassisState, TranslationZ) == 0x8, "Offset mismatch for FDelMarBouncyChassisState::TranslationZ");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FDelMarBoxSpringSetup
{
    FVector Strength; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector Damping; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector MaxDisplacement; // 0x30 (Size: 0x18, Type: StructProperty)
    float MaxSpeed; // 0x48 (Size: 0x4, Type: FloatProperty)
    float Mass; // 0x4c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarBoxSpringSetup) == 0x50, "Size mismatch for FDelMarBoxSpringSetup");
static_assert(offsetof(FDelMarBoxSpringSetup, Strength) == 0x0, "Offset mismatch for FDelMarBoxSpringSetup::Strength");
static_assert(offsetof(FDelMarBoxSpringSetup, Damping) == 0x18, "Offset mismatch for FDelMarBoxSpringSetup::Damping");
static_assert(offsetof(FDelMarBoxSpringSetup, MaxDisplacement) == 0x30, "Offset mismatch for FDelMarBoxSpringSetup::MaxDisplacement");
static_assert(offsetof(FDelMarBoxSpringSetup, MaxSpeed) == 0x48, "Offset mismatch for FDelMarBoxSpringSetup::MaxSpeed");
static_assert(offsetof(FDelMarBoxSpringSetup, Mass) == 0x4c, "Offset mismatch for FDelMarBoxSpringSetup::Mass");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FDelMarBoxSpring
{
    FDelMarBoxSpringSetup Setup; // 0x0 (Size: 0x50, Type: StructProperty)
    uint8_t Pad_50[0x60]; // 0x50 (Size: 0x60, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarBoxSpring) == 0xb0, "Size mismatch for FDelMarBoxSpring");
static_assert(offsetof(FDelMarBoxSpring, Setup) == 0x0, "Offset mismatch for FDelMarBoxSpring::Setup");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarSpringSettings
{
    float Strength; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Damping; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelMarSpringSettings) == 0x8, "Size mismatch for FDelMarSpringSettings");
static_assert(offsetof(FDelMarSpringSettings, Strength) == 0x0, "Offset mismatch for FDelMarSpringSettings::Strength");
static_assert(offsetof(FDelMarSpringSettings, Damping) == 0x4, "Offset mismatch for FDelMarSpringSettings::Damping");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FDelMarBouncyChassisSetup
{
    FDelMarSpringSettings PitchSpring; // 0x0 (Size: 0x8, Type: StructProperty)
    float PitchMaxAngleDegrees; // 0x8 (Size: 0x4, Type: FloatProperty)
    FDelMarSpringSettings RollSpring; // 0xc (Size: 0x8, Type: StructProperty)
    float RollMaxAngleDegrees; // 0x14 (Size: 0x4, Type: FloatProperty)
    FDelMarSpringSettings ZSpring; // 0x18 (Size: 0x8, Type: StructProperty)
    float ZMaxDrop; // 0x20 (Size: 0x4, Type: FloatProperty)
    float ZMaxRaise; // 0x24 (Size: 0x4, Type: FloatProperty)
    FVector MaxDisplacement; // 0x28 (Size: 0x18, Type: StructProperty)
    FVector MassOffset; // 0x40 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDelMarBouncyChassisSetup) == 0x58, "Size mismatch for FDelMarBouncyChassisSetup");
static_assert(offsetof(FDelMarBouncyChassisSetup, PitchSpring) == 0x0, "Offset mismatch for FDelMarBouncyChassisSetup::PitchSpring");
static_assert(offsetof(FDelMarBouncyChassisSetup, PitchMaxAngleDegrees) == 0x8, "Offset mismatch for FDelMarBouncyChassisSetup::PitchMaxAngleDegrees");
static_assert(offsetof(FDelMarBouncyChassisSetup, RollSpring) == 0xc, "Offset mismatch for FDelMarBouncyChassisSetup::RollSpring");
static_assert(offsetof(FDelMarBouncyChassisSetup, RollMaxAngleDegrees) == 0x14, "Offset mismatch for FDelMarBouncyChassisSetup::RollMaxAngleDegrees");
static_assert(offsetof(FDelMarBouncyChassisSetup, ZSpring) == 0x18, "Offset mismatch for FDelMarBouncyChassisSetup::ZSpring");
static_assert(offsetof(FDelMarBouncyChassisSetup, ZMaxDrop) == 0x20, "Offset mismatch for FDelMarBouncyChassisSetup::ZMaxDrop");
static_assert(offsetof(FDelMarBouncyChassisSetup, ZMaxRaise) == 0x24, "Offset mismatch for FDelMarBouncyChassisSetup::ZMaxRaise");
static_assert(offsetof(FDelMarBouncyChassisSetup, MaxDisplacement) == 0x28, "Offset mismatch for FDelMarBouncyChassisSetup::MaxDisplacement");
static_assert(offsetof(FDelMarBouncyChassisSetup, MassOffset) == 0x40, "Offset mismatch for FDelMarBouncyChassisSetup::MassOffset");

// Size: 0x118 (Inherited: 0x0, Single: 0x118)
struct FDelMarBouncyChassisInstance
{
    FDelMarBoxSpring Spring; // 0x0 (Size: 0xb0, Type: StructProperty)
    uint8_t Pad_b0[0x68]; // 0xb0 (Size: 0x68, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarBouncyChassisInstance) == 0x118, "Size mismatch for FDelMarBouncyChassisInstance");
static_assert(offsetof(FDelMarBouncyChassisInstance, Spring) == 0x0, "Offset mismatch for FDelMarBouncyChassisInstance::Spring");

// Size: 0x108 (Inherited: 0x0, Single: 0x108)
struct FDelMarPreviewConfigs
{
    bool bAnyWheelsOnGround; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bWheelsOnGround; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    float ForwardSpeed; // 0x4 (Size: 0x4, Type: FloatProperty)
    float SideSpeed; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Acceleration; // 0xc (Size: 0x4, Type: FloatProperty)
    float Throttle; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Steering; // 0x14 (Size: 0x4, Type: FloatProperty)
    float SteerAngle; // 0x18 (Size: 0x4, Type: FloatProperty)
    float TargetSpeed; // 0x1c (Size: 0x4, Type: FloatProperty)
    float BaseTargetSpeed; // 0x20 (Size: 0x4, Type: FloatProperty)
    float NormalizedForwardSpeed; // 0x24 (Size: 0x4, Type: FloatProperty)
    float NormalizedBonusSpeed; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t VehicleForwardState; // 0x2c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
    float BonusSpeed; // 0x30 (Size: 0x4, Type: FloatProperty)
    float WorldAppliedBonusSpeed; // 0x34 (Size: 0x4, Type: FloatProperty)
    FDelMarVehicleLandingData LandingData; // 0x38 (Size: 0xc, Type: StructProperty)
    bool bLanded; // 0x44 (Size: 0x1, Type: BoolProperty)
    bool bSkydiving; // 0x45 (Size: 0x1, Type: BoolProperty)
    uint8_t DriftState; // 0x46 (Size: 0x1, Type: EnumProperty)
    bool bDriftControlled; // 0x47 (Size: 0x1, Type: BoolProperty)
    float DriftAngle; // 0x48 (Size: 0x4, Type: FloatProperty)
    float DriftSlipAngleRatio; // 0x4c (Size: 0x4, Type: FloatProperty)
    float DriftTargetSide; // 0x50 (Size: 0x4, Type: FloatProperty)
    float DriftDuration; // 0x54 (Size: 0x4, Type: FloatProperty)
    bool bDriftBoostInRange; // 0x58 (Size: 0x1, Type: BoolProperty)
    bool bDriftBoostLosingAppliedBonusSpeed; // 0x59 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5a[0x2]; // 0x5a (Size: 0x2, Type: PaddingProperty)
    float DriftBoostPotentialPercentage; // 0x5c (Size: 0x4, Type: FloatProperty)
    float DriftBoostAppliedBonusSpeed; // 0x60 (Size: 0x4, Type: FloatProperty)
    float DriftBoostQueuedBonusSpeed; // 0x64 (Size: 0x4, Type: FloatProperty)
    float DraftingAppliedBonusSpeed; // 0x68 (Size: 0x4, Type: FloatProperty)
    float DraftingMaxBonusSpeedPercentage; // 0x6c (Size: 0x4, Type: FloatProperty)
    float DraftingTargetDegrees; // 0x70 (Size: 0x4, Type: FloatProperty)
    float DraftingCurrentBonusSpeedPercentage; // 0x74 (Size: 0x4, Type: FloatProperty)
    bool bHasValidDraftingTarget; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t DraftingState; // 0x79 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_7a[0x2]; // 0x7a (Size: 0x2, Type: PaddingProperty)
    float OversteerAccumulationPercentage; // 0x7c (Size: 0x4, Type: FloatProperty)
    bool bStartlineBoostActive; // 0x80 (Size: 0x1, Type: BoolProperty)
    bool bFailedStartlineBoost; // 0x81 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_82[0x2]; // 0x82 (Size: 0x2, Type: PaddingProperty)
    float PercentageMaxBonusSpeedEarned; // 0x84 (Size: 0x4, Type: FloatProperty)
    float StartlineBoostAppliedBonusSpeed; // 0x88 (Size: 0x4, Type: FloatProperty)
    float MaxEarnedBonusSpeed; // 0x8c (Size: 0x4, Type: FloatProperty)
    bool bLeftStrafe; // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bStrafeActive; // 0x91 (Size: 0x1, Type: BoolProperty)
    bool bStrafeDisabled; // 0x92 (Size: 0x1, Type: BoolProperty)
    bool bCanStrafeBeActivated; // 0x93 (Size: 0x1, Type: BoolProperty)
    float StrafeCooldownPercentage; // 0x94 (Size: 0x4, Type: FloatProperty)
    bool bTurboActive; // 0x98 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x3]; // 0x99 (Size: 0x3, Type: PaddingProperty)
    float NumCurrentCharges; // 0x9c (Size: 0x4, Type: FloatProperty)
    float NumMaxCharges; // 0xa0 (Size: 0x4, Type: FloatProperty)
    uint8_t BonusZoneState; // 0xa4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a5[0x3]; // 0xa5 (Size: 0x3, Type: PaddingProperty)
    float PercentageTurboActiveTimeRemaining; // 0xa8 (Size: 0x4, Type: FloatProperty)
    float RemainingTurboActiveSeconds; // 0xac (Size: 0x4, Type: FloatProperty)
    float TurboAppliedBonusSpeed; // 0xb0 (Size: 0x4, Type: FloatProperty)
    float TurboBonusZoneBonusSpeed; // 0xb4 (Size: 0x4, Type: FloatProperty)
    float TurboAdditionalActiveSeconds; // 0xb8 (Size: 0x4, Type: FloatProperty)
    bool bKickflipActive; // 0xbc (Size: 0x1, Type: BoolProperty)
    bool bKickflipLeftSide; // 0xbd (Size: 0x1, Type: BoolProperty)
    bool bKickflipSuctionActive; // 0xbe (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_bf[0x1]; // 0xbf (Size: 0x1, Type: PaddingProperty)
    float DistanceToSuctionSurface; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float KickflipDuration; // 0xc4 (Size: 0x4, Type: FloatProperty)
    int32_t KickflipActivationCharges; // 0xc8 (Size: 0x4, Type: IntProperty)
    bool bReattachmentActive; // 0xcc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_cd[0x3]; // 0xcd (Size: 0x3, Type: PaddingProperty)
    FVector ReattachmentDirection; // 0xd0 (Size: 0x18, Type: StructProperty)
    bool bUnderthrustActive; // 0xe8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e9[0x3]; // 0xe9 (Size: 0x3, Type: PaddingProperty)
    float UnderthrustPercentageTankRemaining; // 0xec (Size: 0x4, Type: FloatProperty)
    float UnderthrustActiveDuration; // 0xf0 (Size: 0x4, Type: FloatProperty)
    bool bJumpActive; // 0xf4 (Size: 0x1, Type: BoolProperty)
    bool bAirFreestyleActive; // 0xf5 (Size: 0x1, Type: BoolProperty)
    bool bVehicleDemolished; // 0xf6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f7[0x1]; // 0xf7 (Size: 0x1, Type: PaddingProperty)
    FGameplayTag DemolishCausedByTag; // 0xf8 (Size: 0x4, Type: StructProperty)
    bool bInvulnerabilityActive; // 0xfc (Size: 0x1, Type: BoolProperty)
    bool bVehicleSpawnedThisFrame; // 0xfd (Size: 0x1, Type: BoolProperty)
    bool bFirstVehicleForPlayer; // 0xfe (Size: 0x1, Type: BoolProperty)
    bool bPreviousVehicleDemolished; // 0xff (Size: 0x1, Type: BoolProperty)
    bool bHeadlightsActive; // 0x100 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0x7]; // 0x101 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarPreviewConfigs) == 0x108, "Size mismatch for FDelMarPreviewConfigs");
static_assert(offsetof(FDelMarPreviewConfigs, bAnyWheelsOnGround) == 0x0, "Offset mismatch for FDelMarPreviewConfigs::bAnyWheelsOnGround");
static_assert(offsetof(FDelMarPreviewConfigs, bWheelsOnGround) == 0x1, "Offset mismatch for FDelMarPreviewConfigs::bWheelsOnGround");
static_assert(offsetof(FDelMarPreviewConfigs, ForwardSpeed) == 0x4, "Offset mismatch for FDelMarPreviewConfigs::ForwardSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, SideSpeed) == 0x8, "Offset mismatch for FDelMarPreviewConfigs::SideSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, Acceleration) == 0xc, "Offset mismatch for FDelMarPreviewConfigs::Acceleration");
static_assert(offsetof(FDelMarPreviewConfigs, Throttle) == 0x10, "Offset mismatch for FDelMarPreviewConfigs::Throttle");
static_assert(offsetof(FDelMarPreviewConfigs, Steering) == 0x14, "Offset mismatch for FDelMarPreviewConfigs::Steering");
static_assert(offsetof(FDelMarPreviewConfigs, SteerAngle) == 0x18, "Offset mismatch for FDelMarPreviewConfigs::SteerAngle");
static_assert(offsetof(FDelMarPreviewConfigs, TargetSpeed) == 0x1c, "Offset mismatch for FDelMarPreviewConfigs::TargetSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, BaseTargetSpeed) == 0x20, "Offset mismatch for FDelMarPreviewConfigs::BaseTargetSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, NormalizedForwardSpeed) == 0x24, "Offset mismatch for FDelMarPreviewConfigs::NormalizedForwardSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, NormalizedBonusSpeed) == 0x28, "Offset mismatch for FDelMarPreviewConfigs::NormalizedBonusSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, VehicleForwardState) == 0x2c, "Offset mismatch for FDelMarPreviewConfigs::VehicleForwardState");
static_assert(offsetof(FDelMarPreviewConfigs, BonusSpeed) == 0x30, "Offset mismatch for FDelMarPreviewConfigs::BonusSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, WorldAppliedBonusSpeed) == 0x34, "Offset mismatch for FDelMarPreviewConfigs::WorldAppliedBonusSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, LandingData) == 0x38, "Offset mismatch for FDelMarPreviewConfigs::LandingData");
static_assert(offsetof(FDelMarPreviewConfigs, bLanded) == 0x44, "Offset mismatch for FDelMarPreviewConfigs::bLanded");
static_assert(offsetof(FDelMarPreviewConfigs, bSkydiving) == 0x45, "Offset mismatch for FDelMarPreviewConfigs::bSkydiving");
static_assert(offsetof(FDelMarPreviewConfigs, DriftState) == 0x46, "Offset mismatch for FDelMarPreviewConfigs::DriftState");
static_assert(offsetof(FDelMarPreviewConfigs, bDriftControlled) == 0x47, "Offset mismatch for FDelMarPreviewConfigs::bDriftControlled");
static_assert(offsetof(FDelMarPreviewConfigs, DriftAngle) == 0x48, "Offset mismatch for FDelMarPreviewConfigs::DriftAngle");
static_assert(offsetof(FDelMarPreviewConfigs, DriftSlipAngleRatio) == 0x4c, "Offset mismatch for FDelMarPreviewConfigs::DriftSlipAngleRatio");
static_assert(offsetof(FDelMarPreviewConfigs, DriftTargetSide) == 0x50, "Offset mismatch for FDelMarPreviewConfigs::DriftTargetSide");
static_assert(offsetof(FDelMarPreviewConfigs, DriftDuration) == 0x54, "Offset mismatch for FDelMarPreviewConfigs::DriftDuration");
static_assert(offsetof(FDelMarPreviewConfigs, bDriftBoostInRange) == 0x58, "Offset mismatch for FDelMarPreviewConfigs::bDriftBoostInRange");
static_assert(offsetof(FDelMarPreviewConfigs, bDriftBoostLosingAppliedBonusSpeed) == 0x59, "Offset mismatch for FDelMarPreviewConfigs::bDriftBoostLosingAppliedBonusSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, DriftBoostPotentialPercentage) == 0x5c, "Offset mismatch for FDelMarPreviewConfigs::DriftBoostPotentialPercentage");
static_assert(offsetof(FDelMarPreviewConfigs, DriftBoostAppliedBonusSpeed) == 0x60, "Offset mismatch for FDelMarPreviewConfigs::DriftBoostAppliedBonusSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, DriftBoostQueuedBonusSpeed) == 0x64, "Offset mismatch for FDelMarPreviewConfigs::DriftBoostQueuedBonusSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, DraftingAppliedBonusSpeed) == 0x68, "Offset mismatch for FDelMarPreviewConfigs::DraftingAppliedBonusSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, DraftingMaxBonusSpeedPercentage) == 0x6c, "Offset mismatch for FDelMarPreviewConfigs::DraftingMaxBonusSpeedPercentage");
static_assert(offsetof(FDelMarPreviewConfigs, DraftingTargetDegrees) == 0x70, "Offset mismatch for FDelMarPreviewConfigs::DraftingTargetDegrees");
static_assert(offsetof(FDelMarPreviewConfigs, DraftingCurrentBonusSpeedPercentage) == 0x74, "Offset mismatch for FDelMarPreviewConfigs::DraftingCurrentBonusSpeedPercentage");
static_assert(offsetof(FDelMarPreviewConfigs, bHasValidDraftingTarget) == 0x78, "Offset mismatch for FDelMarPreviewConfigs::bHasValidDraftingTarget");
static_assert(offsetof(FDelMarPreviewConfigs, DraftingState) == 0x79, "Offset mismatch for FDelMarPreviewConfigs::DraftingState");
static_assert(offsetof(FDelMarPreviewConfigs, OversteerAccumulationPercentage) == 0x7c, "Offset mismatch for FDelMarPreviewConfigs::OversteerAccumulationPercentage");
static_assert(offsetof(FDelMarPreviewConfigs, bStartlineBoostActive) == 0x80, "Offset mismatch for FDelMarPreviewConfigs::bStartlineBoostActive");
static_assert(offsetof(FDelMarPreviewConfigs, bFailedStartlineBoost) == 0x81, "Offset mismatch for FDelMarPreviewConfigs::bFailedStartlineBoost");
static_assert(offsetof(FDelMarPreviewConfigs, PercentageMaxBonusSpeedEarned) == 0x84, "Offset mismatch for FDelMarPreviewConfigs::PercentageMaxBonusSpeedEarned");
static_assert(offsetof(FDelMarPreviewConfigs, StartlineBoostAppliedBonusSpeed) == 0x88, "Offset mismatch for FDelMarPreviewConfigs::StartlineBoostAppliedBonusSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, MaxEarnedBonusSpeed) == 0x8c, "Offset mismatch for FDelMarPreviewConfigs::MaxEarnedBonusSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, bLeftStrafe) == 0x90, "Offset mismatch for FDelMarPreviewConfigs::bLeftStrafe");
static_assert(offsetof(FDelMarPreviewConfigs, bStrafeActive) == 0x91, "Offset mismatch for FDelMarPreviewConfigs::bStrafeActive");
static_assert(offsetof(FDelMarPreviewConfigs, bStrafeDisabled) == 0x92, "Offset mismatch for FDelMarPreviewConfigs::bStrafeDisabled");
static_assert(offsetof(FDelMarPreviewConfigs, bCanStrafeBeActivated) == 0x93, "Offset mismatch for FDelMarPreviewConfigs::bCanStrafeBeActivated");
static_assert(offsetof(FDelMarPreviewConfigs, StrafeCooldownPercentage) == 0x94, "Offset mismatch for FDelMarPreviewConfigs::StrafeCooldownPercentage");
static_assert(offsetof(FDelMarPreviewConfigs, bTurboActive) == 0x98, "Offset mismatch for FDelMarPreviewConfigs::bTurboActive");
static_assert(offsetof(FDelMarPreviewConfigs, NumCurrentCharges) == 0x9c, "Offset mismatch for FDelMarPreviewConfigs::NumCurrentCharges");
static_assert(offsetof(FDelMarPreviewConfigs, NumMaxCharges) == 0xa0, "Offset mismatch for FDelMarPreviewConfigs::NumMaxCharges");
static_assert(offsetof(FDelMarPreviewConfigs, BonusZoneState) == 0xa4, "Offset mismatch for FDelMarPreviewConfigs::BonusZoneState");
static_assert(offsetof(FDelMarPreviewConfigs, PercentageTurboActiveTimeRemaining) == 0xa8, "Offset mismatch for FDelMarPreviewConfigs::PercentageTurboActiveTimeRemaining");
static_assert(offsetof(FDelMarPreviewConfigs, RemainingTurboActiveSeconds) == 0xac, "Offset mismatch for FDelMarPreviewConfigs::RemainingTurboActiveSeconds");
static_assert(offsetof(FDelMarPreviewConfigs, TurboAppliedBonusSpeed) == 0xb0, "Offset mismatch for FDelMarPreviewConfigs::TurboAppliedBonusSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, TurboBonusZoneBonusSpeed) == 0xb4, "Offset mismatch for FDelMarPreviewConfigs::TurboBonusZoneBonusSpeed");
static_assert(offsetof(FDelMarPreviewConfigs, TurboAdditionalActiveSeconds) == 0xb8, "Offset mismatch for FDelMarPreviewConfigs::TurboAdditionalActiveSeconds");
static_assert(offsetof(FDelMarPreviewConfigs, bKickflipActive) == 0xbc, "Offset mismatch for FDelMarPreviewConfigs::bKickflipActive");
static_assert(offsetof(FDelMarPreviewConfigs, bKickflipLeftSide) == 0xbd, "Offset mismatch for FDelMarPreviewConfigs::bKickflipLeftSide");
static_assert(offsetof(FDelMarPreviewConfigs, bKickflipSuctionActive) == 0xbe, "Offset mismatch for FDelMarPreviewConfigs::bKickflipSuctionActive");
static_assert(offsetof(FDelMarPreviewConfigs, DistanceToSuctionSurface) == 0xc0, "Offset mismatch for FDelMarPreviewConfigs::DistanceToSuctionSurface");
static_assert(offsetof(FDelMarPreviewConfigs, KickflipDuration) == 0xc4, "Offset mismatch for FDelMarPreviewConfigs::KickflipDuration");
static_assert(offsetof(FDelMarPreviewConfigs, KickflipActivationCharges) == 0xc8, "Offset mismatch for FDelMarPreviewConfigs::KickflipActivationCharges");
static_assert(offsetof(FDelMarPreviewConfigs, bReattachmentActive) == 0xcc, "Offset mismatch for FDelMarPreviewConfigs::bReattachmentActive");
static_assert(offsetof(FDelMarPreviewConfigs, ReattachmentDirection) == 0xd0, "Offset mismatch for FDelMarPreviewConfigs::ReattachmentDirection");
static_assert(offsetof(FDelMarPreviewConfigs, bUnderthrustActive) == 0xe8, "Offset mismatch for FDelMarPreviewConfigs::bUnderthrustActive");
static_assert(offsetof(FDelMarPreviewConfigs, UnderthrustPercentageTankRemaining) == 0xec, "Offset mismatch for FDelMarPreviewConfigs::UnderthrustPercentageTankRemaining");
static_assert(offsetof(FDelMarPreviewConfigs, UnderthrustActiveDuration) == 0xf0, "Offset mismatch for FDelMarPreviewConfigs::UnderthrustActiveDuration");
static_assert(offsetof(FDelMarPreviewConfigs, bJumpActive) == 0xf4, "Offset mismatch for FDelMarPreviewConfigs::bJumpActive");
static_assert(offsetof(FDelMarPreviewConfigs, bAirFreestyleActive) == 0xf5, "Offset mismatch for FDelMarPreviewConfigs::bAirFreestyleActive");
static_assert(offsetof(FDelMarPreviewConfigs, bVehicleDemolished) == 0xf6, "Offset mismatch for FDelMarPreviewConfigs::bVehicleDemolished");
static_assert(offsetof(FDelMarPreviewConfigs, DemolishCausedByTag) == 0xf8, "Offset mismatch for FDelMarPreviewConfigs::DemolishCausedByTag");
static_assert(offsetof(FDelMarPreviewConfigs, bInvulnerabilityActive) == 0xfc, "Offset mismatch for FDelMarPreviewConfigs::bInvulnerabilityActive");
static_assert(offsetof(FDelMarPreviewConfigs, bVehicleSpawnedThisFrame) == 0xfd, "Offset mismatch for FDelMarPreviewConfigs::bVehicleSpawnedThisFrame");
static_assert(offsetof(FDelMarPreviewConfigs, bFirstVehicleForPlayer) == 0xfe, "Offset mismatch for FDelMarPreviewConfigs::bFirstVehicleForPlayer");
static_assert(offsetof(FDelMarPreviewConfigs, bPreviousVehicleDemolished) == 0xff, "Offset mismatch for FDelMarPreviewConfigs::bPreviousVehicleDemolished");
static_assert(offsetof(FDelMarPreviewConfigs, bHeadlightsActive) == 0x100, "Offset mismatch for FDelMarPreviewConfigs::bHeadlightsActive");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FDelMarPreviousPreviewConfigs
{
};

static_assert(sizeof(FDelMarPreviousPreviewConfigs) == 0x38, "Size mismatch for FDelMarPreviousPreviewConfigs");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarPreviewCustomization
{
    FGameplayTag SlotTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FCosmeticCustomizationInfo> CustomizationInfo; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarPreviewCustomization) == 0x18, "Size mismatch for FDelMarPreviewCustomization");
static_assert(offsetof(FDelMarPreviewCustomization, SlotTag) == 0x0, "Offset mismatch for FDelMarPreviewCustomization::SlotTag");
static_assert(offsetof(FDelMarPreviewCustomization, CustomizationInfo) == 0x8, "Offset mismatch for FDelMarPreviewCustomization::CustomizationInfo");

