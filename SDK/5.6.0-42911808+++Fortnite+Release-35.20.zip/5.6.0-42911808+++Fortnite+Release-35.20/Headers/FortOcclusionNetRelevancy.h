/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortOcclusionNetRelevancy
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "IrisCore.h"

// Size: 0xe0 (Inherited: 0xe0, Single: 0x0)
class UFortOcclusionClientStatsComponent : public UActorComponent
{
public:
    int32_t NumPawnsWithinRelevancyRange; // 0xb8 (Size: 0x4, Type: IntProperty)
    int32_t NumPawnsCulled; // 0xbc (Size: 0x4, Type: IntProperty)
    bool bServerSystemEnabled; // 0xc0 (Size: 0x1, Type: BoolProperty)
    bool bServerUsingOcclusionFilter; // 0xc1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c2[0x6]; // 0xc2 (Size: 0x6, Type: PaddingProperty)
    TArray<FVector> OccludedLocations; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_d8[0x8]; // 0xd8 (Size: 0x8, Type: PaddingProperty)

private:
    void OnRep_IsSystemEnabled(); // 0x554e3c4 (Index: 0x0, Flags: Final|Native|Private)
    void OnRep_IsUsingOcclusionFilter(); // 0x554e3c4 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortOcclusionClientStatsComponent) == 0xe0, "Size mismatch for UFortOcclusionClientStatsComponent");
static_assert(offsetof(UFortOcclusionClientStatsComponent, NumPawnsWithinRelevancyRange) == 0xb8, "Offset mismatch for UFortOcclusionClientStatsComponent::NumPawnsWithinRelevancyRange");
static_assert(offsetof(UFortOcclusionClientStatsComponent, NumPawnsCulled) == 0xbc, "Offset mismatch for UFortOcclusionClientStatsComponent::NumPawnsCulled");
static_assert(offsetof(UFortOcclusionClientStatsComponent, bServerSystemEnabled) == 0xc0, "Offset mismatch for UFortOcclusionClientStatsComponent::bServerSystemEnabled");
static_assert(offsetof(UFortOcclusionClientStatsComponent, bServerUsingOcclusionFilter) == 0xc1, "Offset mismatch for UFortOcclusionClientStatsComponent::bServerUsingOcclusionFilter");
static_assert(offsetof(UFortOcclusionClientStatsComponent, OccludedLocations) == 0xc8, "Offset mismatch for UFortOcclusionClientStatsComponent::OccludedLocations");

// Size: 0x300 (Inherited: 0x2d0, Single: 0x30)
class AFortOcclusionNetRelevancyServerDebug : public AActor
{
public:
    FFortOcclusionNetRelevancyStats ServerCurrentStats; // 0x2a8 (Size: 0x50, Type: StructProperty)
    uint8_t Pad_2f8[0x8]; // 0x2f8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(AFortOcclusionNetRelevancyServerDebug) == 0x300, "Size mismatch for AFortOcclusionNetRelevancyServerDebug");
static_assert(offsetof(AFortOcclusionNetRelevancyServerDebug, ServerCurrentStats) == 0x2a8, "Offset mismatch for AFortOcclusionNetRelevancyServerDebug::ServerCurrentStats");

// Size: 0x168 (Inherited: 0xc8, Single: 0xa0)
class UFortOcclusionNetRelevancyWorldSubsystem : public UTickableWorldSubsystem
{
public:
    uint8_t Pad_40[0xa0]; // 0x40 (Size: 0xa0, Type: PaddingProperty)
    TArray<APawn*> AllPawns; // 0xe0 (Size: 0x10, Type: ArrayProperty)
    TSoftClassPtr PawnClass; // 0xf0 (Size: 0x20, Type: SoftClassProperty)
    UClass* PawnClassLoaded; // 0x110 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<ECollisionChannel> CollisionChannelForOcclusionTraces; // 0x118 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_119[0x7]; // 0x119 (Size: 0x7, Type: PaddingProperty)
    AFortOcclusionNetRelevancyServerDebug* ServerDebugActor; // 0x120 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_128[0x40]; // 0x128 (Size: 0x40, Type: PaddingProperty)

public:
    void FilterActorForAllConections(AActor*& Actor, bool& bOccluded); // 0x12b5d278 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)
    void SetActorOccludedToConnections(AActor*& Actor, TArray<int32_t>& ConnectionIds, bool& bOccluded); // 0x12b5d540 (Index: 0x2, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable)

protected:
    void OnPawnEndPlay(AActor*& Actor, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0xceb1d8c (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortOcclusionNetRelevancyWorldSubsystem) == 0x168, "Size mismatch for UFortOcclusionNetRelevancyWorldSubsystem");
static_assert(offsetof(UFortOcclusionNetRelevancyWorldSubsystem, AllPawns) == 0xe0, "Offset mismatch for UFortOcclusionNetRelevancyWorldSubsystem::AllPawns");
static_assert(offsetof(UFortOcclusionNetRelevancyWorldSubsystem, PawnClass) == 0xf0, "Offset mismatch for UFortOcclusionNetRelevancyWorldSubsystem::PawnClass");
static_assert(offsetof(UFortOcclusionNetRelevancyWorldSubsystem, PawnClassLoaded) == 0x110, "Offset mismatch for UFortOcclusionNetRelevancyWorldSubsystem::PawnClassLoaded");
static_assert(offsetof(UFortOcclusionNetRelevancyWorldSubsystem, CollisionChannelForOcclusionTraces) == 0x118, "Offset mismatch for UFortOcclusionNetRelevancyWorldSubsystem::CollisionChannelForOcclusionTraces");
static_assert(offsetof(UFortOcclusionNetRelevancyWorldSubsystem, ServerDebugActor) == 0x120, "Offset mismatch for UFortOcclusionNetRelevancyWorldSubsystem::ServerDebugActor");

// Size: 0x1b8 (Inherited: 0x3c0, Single: 0xfffffdf8)
class UNetObjectGridOcclusionFilter : public UNetObjectGridWorldLocFilter
{
public:
};

static_assert(sizeof(UNetObjectGridOcclusionFilter) == 0x1b8, "Size mismatch for UNetObjectGridOcclusionFilter");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FFortOcclusionNetRelevancyStats
{
    int32_t PlayerControllerCount; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t PlayerPawnCount; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t PawnsTestedForOcclusion; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t NumTraces; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t NumBlockedTraces; // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t NumEarlyOutTraces; // 0x14 (Size: 0x4, Type: IntProperty)
    int32_t NumTracesHitLandscape; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t NumTracesHitNonLandscape; // 0x1c (Size: 0x4, Type: IntProperty)
    int32_t OccludedPawns; // 0x20 (Size: 0x4, Type: IntProperty)
    int32_t PlayersBenefitingFromOcclusionCulling; // 0x24 (Size: 0x4, Type: IntProperty)
    int32_t PlayerWithMostOccludedPawns; // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t PlayerWithLeastOccludedPawns; // 0x2c (Size: 0x4, Type: IntProperty)
    int32_t PawnsSkippingTraces; // 0x30 (Size: 0x4, Type: IntProperty)
    int32_t PawnsOutsideNetCullDist; // 0x34 (Size: 0x4, Type: IntProperty)
    int32_t PawnsWithinFootStepRadius; // 0x38 (Size: 0x4, Type: IntProperty)
    int32_t NumProcessedPawns; // 0x3c (Size: 0x4, Type: IntProperty)
    int32_t NumPawnsReusingLastSeenResult; // 0x40 (Size: 0x4, Type: IntProperty)
    float TotalServerTickTimeMS; // 0x44 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FFortOcclusionNetRelevancyStats) == 0x50, "Size mismatch for FFortOcclusionNetRelevancyStats");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, PlayerControllerCount) == 0x0, "Offset mismatch for FFortOcclusionNetRelevancyStats::PlayerControllerCount");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, PlayerPawnCount) == 0x4, "Offset mismatch for FFortOcclusionNetRelevancyStats::PlayerPawnCount");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, PawnsTestedForOcclusion) == 0x8, "Offset mismatch for FFortOcclusionNetRelevancyStats::PawnsTestedForOcclusion");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, NumTraces) == 0xc, "Offset mismatch for FFortOcclusionNetRelevancyStats::NumTraces");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, NumBlockedTraces) == 0x10, "Offset mismatch for FFortOcclusionNetRelevancyStats::NumBlockedTraces");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, NumEarlyOutTraces) == 0x14, "Offset mismatch for FFortOcclusionNetRelevancyStats::NumEarlyOutTraces");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, NumTracesHitLandscape) == 0x18, "Offset mismatch for FFortOcclusionNetRelevancyStats::NumTracesHitLandscape");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, NumTracesHitNonLandscape) == 0x1c, "Offset mismatch for FFortOcclusionNetRelevancyStats::NumTracesHitNonLandscape");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, OccludedPawns) == 0x20, "Offset mismatch for FFortOcclusionNetRelevancyStats::OccludedPawns");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, PlayersBenefitingFromOcclusionCulling) == 0x24, "Offset mismatch for FFortOcclusionNetRelevancyStats::PlayersBenefitingFromOcclusionCulling");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, PlayerWithMostOccludedPawns) == 0x28, "Offset mismatch for FFortOcclusionNetRelevancyStats::PlayerWithMostOccludedPawns");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, PlayerWithLeastOccludedPawns) == 0x2c, "Offset mismatch for FFortOcclusionNetRelevancyStats::PlayerWithLeastOccludedPawns");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, PawnsSkippingTraces) == 0x30, "Offset mismatch for FFortOcclusionNetRelevancyStats::PawnsSkippingTraces");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, PawnsOutsideNetCullDist) == 0x34, "Offset mismatch for FFortOcclusionNetRelevancyStats::PawnsOutsideNetCullDist");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, PawnsWithinFootStepRadius) == 0x38, "Offset mismatch for FFortOcclusionNetRelevancyStats::PawnsWithinFootStepRadius");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, NumProcessedPawns) == 0x3c, "Offset mismatch for FFortOcclusionNetRelevancyStats::NumProcessedPawns");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, NumPawnsReusingLastSeenResult) == 0x40, "Offset mismatch for FFortOcclusionNetRelevancyStats::NumPawnsReusingLastSeenResult");
static_assert(offsetof(FFortOcclusionNetRelevancyStats, TotalServerTickTimeMS) == 0x44, "Offset mismatch for FFortOcclusionNetRelevancyStats::TotalServerTickTimeMS");

