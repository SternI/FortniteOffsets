/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ControlRig
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "RigVM.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "Constraints.h"
#include "Basic.h"
#include "MovieSceneTracks.h"
#include "MovieScene.h"
#include "DeveloperSettings.h"
#include "AnimationCore.h"

// Size: 0x138 (Inherited: 0x150, Single: 0xffffffe8)
class UControlRigShapeLibraryLink : public UNameSpacedUserData
{
public:
    TSoftObjectPtr<UControlRigShapeLibrary*> ShapeLibrary; // 0x100 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FName> ShapeNames; // 0x120 (Size: 0x10, Type: ArrayProperty)
    UControlRigShapeLibrary* ShapeLibraryCached; // 0x130 (Size: 0x8, Type: ObjectProperty)

public:
    TSoftObjectPtr<UControlRigShapeLibrary*> GetShapeLibrary() const; // 0xb00aab8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetShapeLibrary(TSoftObjectPtr<UControlRigShapeLibrary*>& InShapeLibrary); // 0xbe20dd0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UControlRigShapeLibraryLink) == 0x138, "Size mismatch for UControlRigShapeLibraryLink");
static_assert(offsetof(UControlRigShapeLibraryLink, ShapeLibrary) == 0x100, "Offset mismatch for UControlRigShapeLibraryLink::ShapeLibrary");
static_assert(offsetof(UControlRigShapeLibraryLink, ShapeNames) == 0x120, "Offset mismatch for UControlRigShapeLibraryLink::ShapeNames");
static_assert(offsetof(UControlRigShapeLibraryLink, ShapeLibraryCached) == 0x130, "Offset mismatch for UControlRigShapeLibraryLink::ShapeLibraryCached");

// Size: 0xc98 (Inherited: 0xd70, Single: 0xffffff28)
class UModularRig : public UControlRig
{
public:
    TArray<FRigModuleInstance> Modules; // 0xaf8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_b08[0x20]; // 0xb08 (Size: 0x20, Type: PaddingProperty)
    FModularRigSettings ModularRigSettings; // 0xb28 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_b29[0x7]; // 0xb29 (Size: 0x7, Type: PaddingProperty)
    FModularRigModel ModularRigModel; // 0xb30 (Size: 0x100, Type: StructProperty)
    TArray<FRigModuleExecutionElement> ExecutionQueue; // 0xc30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_c40[0x58]; // 0xc40 (Size: 0x58, Type: PaddingProperty)

public:
    TArray<FName> ExecuteEventOnAllModules(FName& InEvent); // 0xbe1f3b4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool ExecuteEventOnModuleByNameForBP(FName& InEvent, FName& InModuleName); // 0xbe1f6b8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    bool ExecuteEventOnModuleForBP(FName& InEvent, FString& InModulePath); // 0xbe1f8d0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FName> GetEventsForAllModules() const; // 0xbe1fcbc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetEventsForModule(FString& InModulePath) const; // 0xbe1fd2c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetEventsForModuleByName(FName& InModuleName) const; // 0xbe200bc (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetModuleNames() const; // 0xbe203c0 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FString> GetModulePaths() const; // 0xbe20478 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UControlRig* GetModuleRig(FString& InModulePath); // 0xbe204b4 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    UControlRig* GetModuleRigByName(FName& InModuleName); // 0xbe207bc (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    FName GetParentModuleNameForBP(FName& InModuleName) const; // 0xbe208f4 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetParentPathForBP(FString& InModulePath) const; // 0xbe20a40 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UModularRig) == 0xc98, "Size mismatch for UModularRig");
static_assert(offsetof(UModularRig, Modules) == 0xaf8, "Offset mismatch for UModularRig::Modules");
static_assert(offsetof(UModularRig, ModularRigSettings) == 0xb28, "Offset mismatch for UModularRig::ModularRigSettings");
static_assert(offsetof(UModularRig, ModularRigModel) == 0xb30, "Offset mismatch for UModularRig::ModularRigModel");
static_assert(offsetof(UModularRig, ExecutionQueue) == 0xc30, "Offset mismatch for UModularRig::ExecutionQueue");

// Size: 0xaf8 (Inherited: 0x278, Single: 0x880)
class UControlRig : public URigVMHost
{
public:
    uint8_t Pad_250[0x30]; // 0x250 (Size: 0x30, Type: PaddingProperty)
    uint8_t ExecutionType; // 0x280 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_281[0x3]; // 0x281 (Size: 0x3, Type: PaddingProperty)
    FRigHierarchySettings HierarchySettings; // 0x284 (Size: 0x4, Type: StructProperty)
    TMap<FRigControlElementCustomization, FRigElementKey> ControlCustomizations; // 0x288 (Size: 0x50, Type: MapProperty)
    URigHierarchy* DynamicHierarchy; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    TArray<TSoftObjectPtr<UControlRigShapeLibrary*>> ShapeLibraries; // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FString> ShapeLibraryNameMap; // 0x2f0 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_340[0x10]; // 0x340 (Size: 0x10, Type: PaddingProperty)
    FRigVMExtendedExecuteContext RigVMExtendedExecuteContext; // 0x350 (Size: 0x228, Type: StructProperty)
    uint8_t Pad_578[0x8]; // 0x578 (Size: 0x8, Type: PaddingProperty)
    UAnimationDataSourceRegistry* DataSourceRegistry; // 0x580 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_588[0xa8]; // 0x588 (Size: 0xa8, Type: PaddingProperty)
    FRigInfluenceMapPerEvent Influences; // 0x630 (Size: 0x60, Type: StructProperty)
    uint8_t Pad_690[0xb8]; // 0x690 (Size: 0xb8, Type: PaddingProperty)
    TMap<UDataAssetLink*, FName> ExternalVariableDataAssetLinks; // 0x748 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_798[0xd0]; // 0x798 (Size: 0xd0, Type: PaddingProperty)
    uint8_t OnControlSelected_BP; // 0x868 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    uint8_t Pad_869[0x17]; // 0x869 (Size: 0x17, Type: PaddingProperty)
    bool bIsAdditive; // 0x880 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_881[0x1df]; // 0x881 (Size: 0x1df, Type: PaddingProperty)
    FRigModuleSettings RigModuleSettings; // 0xa60 (Size: 0x78, Type: StructProperty)
    FString RigModulePrefix; // 0xad8 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_ae8[0x10]; // 0xae8 (Size: 0x10, Type: PaddingProperty)

public:
    bool ClearControlSelection(); // 0xa276cc0 (Index: 0x0, Flags: Native|Public|BlueprintCallable)
    UTransformableControlHandle* CreateTransformableControlHandle(const FName ControlName) const; // 0xbea3718 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> CurrentControlSelection() const; // 0xbea380c (Index: 0x2, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    static TArray<UControlRig*> FindControlRigs(UObject*& Outer, UClass*& OptionalClass); // 0xbea41d8 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    URigHierarchy* GetHierarchy(); // 0x4a41ec8 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    AActor* GetHostingActor() const; // 0xbea63e0 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UControlRig* GetInteractionRig() const; // 0xa5f3db8 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UClass* GetInteractionRigClass() const; // 0xbea68f0 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsControlSelected(const FName InControlName) const; // 0xbea6dac (Index: 0x8, Flags: Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void OnControlSelectedBP__DelegateSignature(UControlRig*& Rig, const FRigControlElement Control, bool& bSelected); // 0x288a61c (Index: 0x9, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void RequestConstruction(); // 0xbea7c60 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void SelectControl(const FName InControlName, bool& bSelect); // 0xbea7c88 (Index: 0xb, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void SetInteractionRig(UControlRig*& InInteractionRig); // 0x6023a08 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    void SetInteractionRigClass(UClass*& InInteractionRigClass); // 0xa20157c (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    bool SupportsBackwardsSolve() const; // 0xbeab9ac (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UControlRig) == 0xaf8, "Size mismatch for UControlRig");
static_assert(offsetof(UControlRig, ExecutionType) == 0x280, "Offset mismatch for UControlRig::ExecutionType");
static_assert(offsetof(UControlRig, HierarchySettings) == 0x284, "Offset mismatch for UControlRig::HierarchySettings");
static_assert(offsetof(UControlRig, ControlCustomizations) == 0x288, "Offset mismatch for UControlRig::ControlCustomizations");
static_assert(offsetof(UControlRig, DynamicHierarchy) == 0x2d8, "Offset mismatch for UControlRig::DynamicHierarchy");
static_assert(offsetof(UControlRig, ShapeLibraries) == 0x2e0, "Offset mismatch for UControlRig::ShapeLibraries");
static_assert(offsetof(UControlRig, ShapeLibraryNameMap) == 0x2f0, "Offset mismatch for UControlRig::ShapeLibraryNameMap");
static_assert(offsetof(UControlRig, RigVMExtendedExecuteContext) == 0x350, "Offset mismatch for UControlRig::RigVMExtendedExecuteContext");
static_assert(offsetof(UControlRig, DataSourceRegistry) == 0x580, "Offset mismatch for UControlRig::DataSourceRegistry");
static_assert(offsetof(UControlRig, Influences) == 0x630, "Offset mismatch for UControlRig::Influences");
static_assert(offsetof(UControlRig, ExternalVariableDataAssetLinks) == 0x748, "Offset mismatch for UControlRig::ExternalVariableDataAssetLinks");
static_assert(offsetof(UControlRig, OnControlSelected_BP) == 0x868, "Offset mismatch for UControlRig::OnControlSelected_BP");
static_assert(offsetof(UControlRig, bIsAdditive) == 0x880, "Offset mismatch for UControlRig::bIsAdditive");
static_assert(offsetof(UControlRig, RigModuleSettings) == 0xa60, "Offset mismatch for UControlRig::RigModuleSettings");
static_assert(offsetof(UControlRig, RigModulePrefix) == 0xad8, "Offset mismatch for UControlRig::RigModulePrefix");

// Size: 0x590 (Inherited: 0x28, Single: 0x568)
class URigHierarchy : public UObject
{
public:
    uint8_t Pad_28[0x18]; // 0x28 (Size: 0x18, Type: PaddingProperty)
    uint8_t ModifiedEventDynamic[0x10]; // 0x40 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_50[0x58]; // 0x50 (Size: 0x58, Type: PaddingProperty)
    uint32_t TopologyVersion; // 0xa8 (Size: 0x4, Type: UInt32Property)
    uint32_t MetadataVersion; // 0xac (Size: 0x4, Type: UInt32Property)
    uint16_t MetadataTagVersion; // 0xb0 (Size: 0x2, Type: UInt16Property)
    bool bEnableDirtyPropagation; // 0xb2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b3[0x1f9]; // 0xb3 (Size: 0x1f9, Type: PaddingProperty)
    int32_t TransformStackIndex; // 0x2ac (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2b0[0x70]; // 0x2b0 (Size: 0x70, Type: PaddingProperty)
    URigHierarchyController* HierarchyController; // 0x320 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_328[0x8]; // 0x328 (Size: 0x8, Type: PaddingProperty)
    UModularRigRuleManager* RuleManager; // 0x330 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_338[0x190]; // 0x338 (Size: 0x190, Type: PaddingProperty)
    URigHierarchy* HierarchyForCacheValidation; // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_4d0[0xc0]; // 0x4d0 (Size: 0xc0, Type: PaddingProperty)

public:
    bool Contains_ForBlueprint(FRigElementKey& InKey) const; // 0xbe2724c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void CopyHierarchy(URigHierarchy*& InHierarchy); // 0xbe27328 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void CopyPose(URigHierarchy*& InHierarchy, bool& bCurrent, bool& bInitial, bool& bWeights, bool& bMatchPoseInGlobalIfNeeded); // 0xbe27454 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FRigComponentKey> GetAllComponentKeys() const; // 0xbe27c9c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetAllKeys_ForBlueprint(bool& bTraverse) const; // 0xbe27cd8 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetBoneKeys(bool& bTraverse) const; // 0xbe27fe0 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<bool> GetBoolArrayMetadata(FRigElementKey& InItem, FName& InMetadataName) const; // 0xbe282e8 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetBoolMetadata(FRigElementKey& InItem, FName& InMetadataName, bool& DefaultValue) const; // 0xbe28600 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetChildren(FRigElementKey& InKey, bool& bRecursive) const; // 0xbe287b8 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetComponentContent(FRigElementKey& InElement, int32_t& InComponentIndex) const; // 0xbe28ad4 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FRigComponentKey GetComponentKey(FRigElementKey& InElement, int32_t& InComponentIndex) const; // 0xbe28dec (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigComponentKey> GetComponentKeys(FRigElementKey& InElement) const; // 0xbe28f50 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetComponentName(FRigElementKey& InElement, int32_t& InComponentIndex) const; // 0xbe29040 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UScriptStruct* GetComponentType(FRigElementKey& InElement, int32_t& InComponentIndex) const; // 0xbe29188 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetConnectorKeys(bool& bTraverse) const; // 0xbe292d8 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigConnectorState> GetConnectorStates() const; // 0xbe295e0 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetControlKeys(bool& bTraverse) const; // 0xbe29658 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    URigHierarchyController* GetController(bool& bCreateIfNeeded); // 0xbe2a9cc (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)
    FVector GetControlPreferredEulerAngles(FRigElementKey& InKey, EEulerRotationOrder& InRotationOrder, bool& bInitial) const; // 0xbe29960 (Index: 0x15, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FVector GetControlPreferredEulerAnglesByIndex(int32_t& InElementIndex, EEulerRotationOrder& InRotationOrder, bool& bInitial) const; // 0xbe29b4c (Index: 0x16, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    EEulerRotationOrder GetControlPreferredEulerRotationOrder(FRigElementKey& InKey, bool& bFromSettings) const; // 0xbe29e50 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EEulerRotationOrder GetControlPreferredEulerRotationOrderByIndex(int32_t& InElementIndex, bool& bFromSettings) const; // 0xbe29fac (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FRotator GetControlPreferredRotator(FRigElementKey& InKey, bool& bInitial) const; // 0xbe2a1c8 (Index: 0x19, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FRotator GetControlPreferredRotatorByIndex(int32_t& InElementIndex, bool& bInitial) const; // 0xbe2a340 (Index: 0x1a, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FRigControlValue GetControlValue(FRigElementKey& InKey, ERigControlValueType& InValueType) const; // 0xbe2a57c (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FRigControlValue GetControlValueByIndex(int32_t& InElementIndex, ERigControlValueType& InValueType) const; // 0xbe2a740 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetCurveKeys() const; // 0xbe2ab08 (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCurveValue(FRigElementKey& InKey) const; // 0xbe2ab4c (Index: 0x1e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCurveValueByIndex(int32_t& InElementIndex) const; // 0xbe2ac2c (Index: 0x1f, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FRigElementKey GetDefaultParent(FRigElementKey& InKey) const; // 0xbe2ad64 (Index: 0x20, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static FEulerTransform GetEulerTransformFromControlValue(FRigControlValue& InValue); // 0xbe2ae38 (Index: 0x21, Flags: Final|Native|Static|Public|BlueprintCallable)
    FRigElementKey GetFirstParent(FRigElementKey& InKey) const; // 0xbe2af98 (Index: 0x22, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<float> GetFloatArrayMetadata(FRigElementKey& InItem, FName& InMetadataName) const; // 0xbe2b06c (Index: 0x23, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static float GetFloatFromControlValue(FRigControlValue& InValue); // 0xbe2b384 (Index: 0x24, Flags: Final|Native|Static|Public|BlueprintCallable)
    float GetFloatMetadata(FRigElementKey& InItem, FName& InMetadataName, float& DefaultValue) const; // 0xbe2b458 (Index: 0x25, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FTransform GetGlobalControlOffsetTransform(FRigElementKey& InKey, bool& bInitial) const; // 0xbe2b610 (Index: 0x26, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTransform GetGlobalControlOffsetTransformByIndex(int32_t& InElementIndex, bool& bInitial) const; // 0xbe2b7b4 (Index: 0x27, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTransform GetGlobalControlShapeTransform(FRigElementKey& InKey, bool& bInitial) const; // 0xbe2ba24 (Index: 0x28, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTransform GetGlobalControlShapeTransformByIndex(int32_t& InElementIndex, bool& bInitial) const; // 0xbe2bbc4 (Index: 0x29, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTransform GetGlobalTransform(FRigElementKey& InKey, bool& bInitial) const; // 0xbe2be34 (Index: 0x2a, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTransform GetGlobalTransformByIndex(int32_t& InElementIndex, bool& bInitial) const; // 0xbe2bfd8 (Index: 0x2b, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    int32_t GetIndex_ForBlueprint(FRigElementKey& InKey) const; // 0xbe2c248 (Index: 0x2c, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<int32_t> GetInt32ArrayMetadata(FRigElementKey& InItem, FName& InMetadataName) const; // 0xbe2c31c (Index: 0x2d, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetInt32Metadata(FRigElementKey& InItem, FName& InMetadataName, int32_t& DefaultValue) const; // 0xbe2c634 (Index: 0x2e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static int32_t GetIntFromControlValue(FRigControlValue& InValue); // 0xbe2c7e8 (Index: 0x2f, Flags: Final|Native|Static|Public|BlueprintCallable)
    FRigElementKey GetKey(int32_t& InElementIndex) const; // 0xbe2c8b8 (Index: 0x30, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetKeys(TArray<int32_t>& const InElementIndices) const; // 0xbe2c9ec (Index: 0x31, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FLinearColor> GetLinearColorArrayMetadata(FRigElementKey& InItem, FName& InMetadataName) const; // 0xbe2cd84 (Index: 0x32, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FLinearColor GetLinearColorMetadata(FRigElementKey& InItem, FName& InMetadataName, FLinearColor& DefaultValue) const; // 0xbe2d0e0 (Index: 0x33, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTransform GetLocalControlShapeTransform(FRigElementKey& InKey, bool& bInitial) const; // 0xbe2d2ac (Index: 0x34, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTransform GetLocalControlShapeTransformByIndex(int32_t& InElementIndex, bool& bInitial) const; // 0xbe2d44c (Index: 0x35, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    int32_t GetLocalIndex_ForBlueprint(FRigElementKey& InKey) const; // 0xbe2d6bc (Index: 0x36, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FTransform GetLocalTransform(FRigElementKey& InKey, bool& bInitial) const; // 0xbe2d7a0 (Index: 0x37, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTransform GetLocalTransformByIndex(int32_t& InElementIndex, bool& bInitial) const; // 0xbe2d944 (Index: 0x38, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetMetadataNames(FRigElementKey& InItem) const; // 0xbe2dbb4 (Index: 0x39, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    ERigMetadataType GetMetadataType(FRigElementKey& InItem, FName& InMetadataName) const; // 0xbe2de44 (Index: 0x3a, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetModuleFName(FRigElementKey& InItem) const; // 0xbe2df94 (Index: 0x3b, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetModuleName(FRigElementKey& InItem) const; // 0xbe2e064 (Index: 0x3c, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetModulePath(FRigElementKey& InItem) const; // 0xbe2e2f4 (Index: 0x3d, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetModulePathFName(FRigElementKey& InItem) const; // 0xbe2e588 (Index: 0x3e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetModulePrefix(FRigElementKey& InItem) const; // 0xbe2e65c (Index: 0x3f, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetNameArrayMetadata(FRigElementKey& InItem, FName& InMetadataName) const; // 0xbe2e8ec (Index: 0x40, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetNameMetadata(FRigElementKey& InItem, FName& InMetadataName, FName& DefaultValue) const; // 0xbe2ec04 (Index: 0x41, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetNameSpace(FRigElementKey& InItem) const; // 0xbe2edc4 (Index: 0x42, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetNameSpaceFName(FRigElementKey& InItem) const; // 0xbe2f054 (Index: 0x43, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetNullKeys(bool& bTraverse) const; // 0xbe2f124 (Index: 0x44, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumberOfParents(FRigElementKey& InKey) const; // 0xbe2f42c (Index: 0x45, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetParents(FRigElementKey& InKey, bool& bRecursive) const; // 0xbe2fe34 (Index: 0x46, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FTransform GetParentTransform(FRigElementKey& InKey, bool& bInitial) const; // 0xbe2f508 (Index: 0x47, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTransform GetParentTransformByIndex(int32_t& InElementIndex, bool& bInitial) const; // 0xbe2f6a8 (Index: 0x48, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FRigElementWeight GetParentWeight(FRigElementKey& InChild, FRigElementKey& InParent, bool& bInitial) const; // 0xbe2f914 (Index: 0x49, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementWeight> GetParentWeightArray(FRigElementKey& InChild, bool& bInitial) const; // 0xbe2fb20 (Index: 0x4a, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FRigPose GetPose(bool& bInitial, bool& bIncludeTransientControls) const; // 0xbe30150 (Index: 0x4b, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetPreviousHierarchyName(const FRigHierarchyKey InKey) const; // 0xbe303b4 (Index: 0x4c, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FRigHierarchyKey GetPreviousHierarchyParent(const FRigHierarchyKey InKey) const; // 0xbe304b0 (Index: 0x4d, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FName GetPreviousName(const FRigElementKey InKey) const; // 0xbe305bc (Index: 0x4e, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FRigElementKey GetPreviousParent(const FRigElementKey InKey) const; // 0xbe30698 (Index: 0x4f, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TArray<FQuat> GetQuatArrayMetadata(FRigElementKey& InItem, FName& InMetadataName) const; // 0xbe30778 (Index: 0x50, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FQuat GetQuatMetadata(FRigElementKey& InItem, FName& InMetadataName, FQuat& DefaultValue) const; // 0xbe30a90 (Index: 0x51, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetReferenceKeys(bool& bTraverse) const; // 0xbe30c74 (Index: 0x52, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetRigElementKeyArrayMetadata(FRigElementKey& InItem, FName& InMetadataName) const; // 0xbe30f7c (Index: 0x53, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FRigElementKey GetRigElementKeyMetadata(FRigElementKey& InItem, FName& InMetadataName, FRigElementKey& DefaultValue) const; // 0xbe312d8 (Index: 0x54, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetRootElementKeys() const; // 0xbe314b0 (Index: 0x55, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRotator> GetRotatorArrayMetadata(FRigElementKey& InItem, FName& InMetadataName) const; // 0xbe31514 (Index: 0x56, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static FRotator GetRotatorFromControlValue(FRigControlValue& InValue); // 0xbe31870 (Index: 0x57, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    FRotator GetRotatorMetadata(FRigElementKey& InItem, FName& InMetadataName, FRotator& DefaultValue) const; // 0xbe31970 (Index: 0x58, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    UModularRigRuleManager* GetRuleManager(bool& bCreateIfNeeded); // 0xbe31b58 (Index: 0x59, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FRigHierarchyKey> GetSelectedHierarchyKeys_ForBlueprint() const; // 0xbe31c94 (Index: 0x5a, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetSelectedKeys(ERigElementType& InTypeFilter) const; // 0xbe31d6c (Index: 0x5b, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetSocketKeys(bool& bTraverse) const; // 0xbe32070 (Index: 0x5c, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigSocketState> GetSocketStates() const; // 0xbe32378 (Index: 0x5d, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetTags(FRigElementKey& InItem) const; // 0xbe323f0 (Index: 0x5e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetTopLevelComponentContent(int32_t& InTopLevelComponentIndex) const; // 0xbe32680 (Index: 0x5f, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FRigComponentKey GetTopLevelComponentKey(int32_t& InTopLevelComponentIndex) const; // 0xbe32990 (Index: 0x60, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigComponentKey> GetTopLevelComponentKeys() const; // 0xbe32ad8 (Index: 0x61, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetTopLevelComponentName(int32_t& InTopLevelComponentIndex) const; // 0xbe32b14 (Index: 0x62, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UScriptStruct* GetTopLevelComponentType(int32_t& InTopLevelComponentIndex) const; // 0xbe32c50 (Index: 0x63, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FTransform> GetTransformArrayMetadata(FRigElementKey& InItem, FName& InMetadataName) const; // 0xbe32d94 (Index: 0x64, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static FTransform GetTransformFromControlValue(FRigControlValue& InValue); // 0xbe330ac (Index: 0x65, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    FTransform GetTransformMetadata(FRigElementKey& InItem, FName& InMetadataName, FTransform& DefaultValue) const; // 0xbe33234 (Index: 0x66, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    static FTransformNoScale GetTransformNoScaleFromControlValue(FRigControlValue& InValue); // 0xbe334cc (Index: 0x67, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FVector2D GetVector2DFromControlValue(FRigControlValue& InValue); // 0xbe33624 (Index: 0x68, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    TArray<FVector> GetVectorArrayMetadata(FRigElementKey& InItem, FName& InMetadataName) const; // 0xbe3370c (Index: 0x69, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static FVector GetVectorFromControlValue(FRigControlValue& InValue); // 0xbe33a24 (Index: 0x6a, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    FVector GetVectorMetadata(FRigElementKey& InItem, FName& InMetadataName, FVector& DefaultValue) const; // 0xbe33b18 (Index: 0x6b, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool HasTag(FRigElementKey& InItem, FName& InTag) const; // 0xbe33d00 (Index: 0x6c, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsComponentSelected(FRigComponentKey& InKey) const; // 0xbe33e50 (Index: 0x6d, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsControllerAvailable() const; // 0xbe34110 (Index: 0x6e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsCurveValueSet(FRigElementKey& InKey) const; // 0xbe34128 (Index: 0x6f, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsCurveValueSetByIndex(int32_t& InElementIndex) const; // 0xbe34208 (Index: 0x70, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsParentedTo(FRigElementKey& InChild, FRigElementKey& InParent) const; // 0xbe34340 (Index: 0x71, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsProcedural(const FRigElementKey InKey) const; // 0xbe344f0 (Index: 0x72, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool IsSelected(FRigElementKey& InKey) const; // 0xbe345e4 (Index: 0x73, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSelectedByIndex(int32_t& InIndex) const; // 0xbe346bc (Index: 0x74, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsValidIndex(int32_t& InElementIndex) const; // 0xbe34818 (Index: 0x75, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static FRigControlValue MakeControlValueFromBool(bool& InValue); // 0xbe34958 (Index: 0x76, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FRigControlValue MakeControlValueFromEulerTransform(FEulerTransform& InValue); // 0xbe34b0c (Index: 0x77, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FRigControlValue MakeControlValueFromFloat(float& InValue); // 0xbe34c8c (Index: 0x78, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FRigControlValue MakeControlValueFromInt(int32_t& InValue); // 0xbe34e30 (Index: 0x79, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FRigControlValue MakeControlValueFromRotator(FRotator& InValue); // 0xbe34fcc (Index: 0x7a, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FRigControlValue MakeControlValueFromTransform(FTransform& InValue); // 0xbe35120 (Index: 0x7b, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FRigControlValue MakeControlValueFromTransformNoScale(FTransformNoScale& InValue); // 0xbe35310 (Index: 0x7c, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FRigControlValue MakeControlValueFromVector(FVector& InValue); // 0xbe355b8 (Index: 0x7d, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static FRigControlValue MakeControlValueFromVector2D(FVector2D& InValue); // 0xbe35470 (Index: 0x7e, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    int32_t Num() const; // 0x9eea980 (Index: 0x7f, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t NumComponents(FRigElementKey& InElement) const; // 0xbe3570c (Index: 0x80, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t NumTopLevelComponents() const; // 0xbe357e4 (Index: 0x81, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool RemoveAllMetadata(FRigElementKey& InItem); // 0xbe357fc (Index: 0x82, Flags: Final|Native|Public|BlueprintCallable)
    bool RemoveMetadata(FRigElementKey& InItem, FName& InMetadataName); // 0xbe358e0 (Index: 0x83, Flags: Final|Native|Public|BlueprintCallable)
    void Reset(); // 0xbe35a30 (Index: 0x84, Flags: Final|Native|Public|BlueprintCallable)
    void ResetCurveValues(); // 0xbe35a44 (Index: 0x85, Flags: Final|Native|Public|BlueprintCallable)
    void ResetPoseToInitial(ERigElementType& InTypeFilter); // 0xbe35a58 (Index: 0x86, Flags: Final|Native|Public|BlueprintCallable)
    void ResetToDefault(); // 0xbe35b84 (Index: 0x87, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FRigElementKey> RestoreConnectorsFromStates(TArray<FRigConnectorState>& InStates, bool& bSetupUndoRedo); // 0xbe35b98 (Index: 0x88, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FRigElementKey> RestoreSocketsFromStates(TArray<FRigSocketState>& InStates, bool& bSetupUndoRedo); // 0xbe35ea0 (Index: 0x89, Flags: Final|Native|Public|BlueprintCallable)
    void SendAutoKeyEvent(FRigElementKey& InElement, float& InOffsetInSeconds, bool& bAsynchronous); // 0xbe3619c (Index: 0x8a, Flags: Final|Native|Public|BlueprintCallable)
    bool SetBoolArrayMetadata(FRigElementKey& InItem, FName& InMetadataName, TArray<bool>& InValue); // 0xbe36354 (Index: 0x8b, Flags: Final|Native|Public|BlueprintCallable)
    bool SetBoolMetadata(FRigElementKey& InItem, FName& InMetadataName, bool& InValue); // 0xbe366d4 (Index: 0x8c, Flags: Final|Native|Public|BlueprintCallable)
    void SetConnectorSettings(FRigElementKey& InKey, FRigConnectorSettings& InSettings, bool& bSetupUndo, bool& bForce, bool& bPrintPythonCommands); // 0xbe3688c (Index: 0x8d, Flags: Final|Native|Public|BlueprintCallable)
    void SetConnectorSettingsByIndex(int32_t& InElementIndex, FRigConnectorSettings& InSettings, bool& bSetupUndo, bool& bForce, bool& bPrintPythonCommands); // 0xbe36d00 (Index: 0x8e, Flags: Final|Native|Public|BlueprintCallable)
    void SetControlOffsetTransform(FRigElementKey& InKey, FTransform& InTransform, bool& bInitial, bool& bAffectChildren, bool& bSetupUndo, bool& bPrintPythonCommands); // 0xbe371d0 (Index: 0x8f, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetControlOffsetTransformByIndex(int32_t& InElementIndex, FTransform& InTransform, bool& bInitial, bool& bAffectChildren, bool& bSetupUndo, bool& bPrintPythonCommands); // 0xbe37590 (Index: 0x90, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetControlPreferredEulerAngles(FRigElementKey& InKey, const FVector InEulerAngles, EEulerRotationOrder& InRotationOrder, bool& bInitial, bool& bFixEulerFlips); // 0xbe379a4 (Index: 0x91, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetControlPreferredEulerAnglesByIndex(int32_t& InElementIndex, const FVector InEulerAngles, EEulerRotationOrder& InRotationOrder, bool& bInitial, bool& bFixEulerFlips); // 0xbe37c68 (Index: 0x92, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetControlPreferredRotationOrder(FRigElementKey& InKey, EEulerRotationOrder& InRotationOrder); // 0xbe37fcc (Index: 0x93, Flags: Final|Native|Public|BlueprintCallable)
    void SetControlPreferredRotationOrderByIndex(int32_t& InElementIndex, EEulerRotationOrder& InRotationOrder); // 0xbe38124 (Index: 0x94, Flags: Final|Native|Public|BlueprintCallable)
    void SetControlPreferredRotator(FRigElementKey& InKey, const FRotator InRotator, bool& bInitial, bool& bFixEulerFlips); // 0xbe3832c (Index: 0x95, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetControlPreferredRotatorByIndex(int32_t& InElementIndex, const FRotator InRotator, bool& bInitial, bool& bFixEulerFlips); // 0xbe3857c (Index: 0x96, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetControlSettings(FRigElementKey& InKey, FRigControlSettings& InSettings, bool& bSetupUndo, bool& bForce, bool& bPrintPythonCommands); // 0xbe3885c (Index: 0x97, Flags: Final|Native|Public|BlueprintCallable)
    void SetControlSettingsByIndex(int32_t& InElementIndex, FRigControlSettings& InSettings, bool& bSetupUndo, bool& bForce, bool& bPrintPythonCommands); // 0xbe38b74 (Index: 0x98, Flags: Final|Native|Public|BlueprintCallable)
    void SetControlShapeTransform(FRigElementKey& InKey, FTransform& InTransform, bool& bInitial, bool& bSetupUndo); // 0xbe38eac (Index: 0x99, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetControlShapeTransformByIndex(int32_t& InElementIndex, FTransform& InTransform, bool& bInitial, bool& bSetupUndo); // 0xbe39174 (Index: 0x9a, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetControlValue(FRigElementKey& InKey, FRigControlValue& InValue, ERigControlValueType& InValueType, bool& bSetupUndo, bool& bPrintPythonCommands); // 0xbe3948c (Index: 0x9b, Flags: Final|Native|Public|BlueprintCallable)
    void SetControlValueByIndex(int32_t& InElementIndex, FRigControlValue& InValue, ERigControlValueType& InValueType, bool& bSetupUndo, bool& bPrintPythonCommands); // 0xbe397ac (Index: 0x9c, Flags: Final|Native|Public|BlueprintCallable)
    void SetControlVisibility(FRigElementKey& InKey, bool& bVisibility); // 0xbe39b0c (Index: 0x9d, Flags: Final|Native|Public|BlueprintCallable)
    void SetControlVisibilityByIndex(int32_t& InElementIndex, bool& bVisibility); // 0xbe39c64 (Index: 0x9e, Flags: Final|Native|Public|BlueprintCallable)
    void SetCurveValue(FRigElementKey& InKey, float& InValue, bool& bSetupUndo); // 0xbe39e6c (Index: 0x9f, Flags: Final|Native|Public|BlueprintCallable)
    void SetCurveValueByIndex(int32_t& InElementIndex, float& InValue, bool& bSetupUndo); // 0xbe3a018 (Index: 0xa0, Flags: Final|Native|Public|BlueprintCallable)
    bool SetFloatArrayMetadata(FRigElementKey& InItem, FName& InMetadataName, TArray<float>& InValue); // 0xbe3a2f8 (Index: 0xa1, Flags: Final|Native|Public|BlueprintCallable)
    bool SetFloatMetadata(FRigElementKey& InItem, FName& InMetadataName, float& InValue); // 0xbe3a678 (Index: 0xa2, Flags: Final|Native|Public|BlueprintCallable)
    void SetGlobalTransform(FRigElementKey& InKey, FTransform& InTransform, bool& bInitial, bool& bAffectChildren, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbe3a830 (Index: 0xa3, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetGlobalTransformByIndex(int32_t& InElementIndex, FTransform& InTransform, bool& bInitial, bool& bAffectChildren, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbe3abf0 (Index: 0xa4, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    bool SetInt32ArrayMetadata(FRigElementKey& InItem, FName& InMetadataName, TArray<int32_t>& InValue); // 0xbe3b004 (Index: 0xa5, Flags: Final|Native|Public|BlueprintCallable)
    bool SetInt32Metadata(FRigElementKey& InItem, FName& InMetadataName, int32_t& InValue); // 0xbe3b384 (Index: 0xa6, Flags: Final|Native|Public|BlueprintCallable)
    bool SetLinearColorArrayMetadata(FRigElementKey& InItem, FName& InMetadataName, TArray<FLinearColor>& InValue); // 0xbe3b538 (Index: 0xa7, Flags: Final|Native|Public|BlueprintCallable)
    bool SetLinearColorMetadata(FRigElementKey& InItem, FName& InMetadataName, FLinearColor& InValue); // 0xbe3b8b8 (Index: 0xa8, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetLocalTransform(FRigElementKey& InKey, FTransform& InTransform, bool& bInitial, bool& bAffectChildren, bool& bSetupUndo, bool& bPrintPythonCommands); // 0xbe3ba78 (Index: 0xa9, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetLocalTransformByIndex(int32_t& InElementIndex, FTransform& InTransform, bool& bInitial, bool& bAffectChildren, bool& bSetupUndo, bool& bPrintPythonCommands); // 0xbe3be38 (Index: 0xaa, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    bool SetNameArrayMetadata(FRigElementKey& InItem, FName& InMetadataName, TArray<FName>& InValue); // 0xbe3c24c (Index: 0xab, Flags: Final|Native|Public|BlueprintCallable)
    bool SetNameMetadata(FRigElementKey& InItem, FName& InMetadataName, FName& InValue); // 0xbe3c5cc (Index: 0xac, Flags: Final|Native|Public|BlueprintCallable)
    bool SetParentWeight(FRigElementKey& InChild, FRigElementKey& InParent, FRigElementWeight& InWeight, bool& bInitial, bool& bAffectChildren); // 0xbe3c780 (Index: 0xad, Flags: Final|Native|Public|BlueprintCallable)
    bool SetParentWeightArray(FRigElementKey& InChild, TArray<FRigElementWeight>& InWeights, bool& bInitial, bool& bAffectChildren); // 0xbe3ca58 (Index: 0xae, Flags: Final|Native|Public|BlueprintCallable)
    void SetPose_ForBlueprint(FRigPose& InPose); // 0xbe3cedc (Index: 0xaf, Flags: Final|Native|Public|BlueprintCallable)
    bool SetQuatArrayMetadata(FRigElementKey& InItem, FName& InMetadataName, TArray<FQuat>& InValue); // 0xbe3d018 (Index: 0xb0, Flags: Final|Native|Public|BlueprintCallable)
    bool SetQuatMetadata(FRigElementKey& InItem, FName& InMetadataName, FQuat& InValue); // 0xbe3d398 (Index: 0xb1, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    bool SetRigElementKeyArrayMetadata(FRigElementKey& InItem, FName& InMetadataName, TArray<FRigElementKey>& InValue); // 0xbe3d55c (Index: 0xb2, Flags: Final|Native|Public|BlueprintCallable)
    bool SetRigElementKeyMetadata(FRigElementKey& InItem, FName& InMetadataName, FRigElementKey& InValue); // 0xbe3d8dc (Index: 0xb3, Flags: Final|Native|Public|BlueprintCallable)
    bool SetRotatorArrayMetadata(FRigElementKey& InItem, FName& InMetadataName, TArray<FRotator>& InValue); // 0xbe3daa4 (Index: 0xb4, Flags: Final|Native|Public|BlueprintCallable)
    bool SetRotatorMetadata(FRigElementKey& InItem, FName& InMetadataName, FRotator& InValue); // 0xbe3de24 (Index: 0xb5, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    bool SetTag(FRigElementKey& InItem, FName& InTag); // 0xbe3dfec (Index: 0xb6, Flags: Final|Native|Public|BlueprintCallable)
    bool SetTransformArrayMetadata(FRigElementKey& InItem, FName& InMetadataName, TArray<FTransform>& InValue); // 0xbe3e13c (Index: 0xb7, Flags: Final|Native|Public|BlueprintCallable)
    bool SetTransformMetadata(FRigElementKey& InItem, FName& InMetadataName, FTransform& InValue); // 0xbe3e4bc (Index: 0xb8, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    bool SetVectorArrayMetadata(FRigElementKey& InItem, FName& InMetadataName, TArray<FVector>& InValue); // 0xbe3e718 (Index: 0xb9, Flags: Final|Native|Public|BlueprintCallable)
    bool SetVectorMetadata(FRigElementKey& InItem, FName& InMetadataName, FVector& InValue); // 0xbe3ea98 (Index: 0xba, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    TArray<FRigElementKey> SortKeys(const TArray<FRigElementKey> InKeys) const; // 0xbe3ec60 (Index: 0xbb, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool SwitchToDefaultParent(FRigElementKey& InChild, bool& bInitial, bool& bAffectChildren); // 0xbe3ef78 (Index: 0xbc, Flags: Final|Native|Public|BlueprintCallable)
    bool SwitchToParent(FRigElementKey& InChild, FRigElementKey& InParent, bool& bInitial, bool& bAffectChildren); // 0xbe3f13c (Index: 0xbd, Flags: Final|Native|Public|BlueprintCallable)
    bool SwitchToWorldSpace(FRigElementKey& InChild, bool& bInitial, bool& bAffectChildren); // 0xbe3f384 (Index: 0xbe, Flags: Final|Native|Public|BlueprintCallable)
    void UnsetCurveValue(FRigElementKey& InKey, bool& bSetupUndo); // 0xbe3f560 (Index: 0xbf, Flags: Final|Native|Public|BlueprintCallable)
    void UnsetCurveValueByIndex(int32_t& InElementIndex, bool& bSetupUndo); // 0xbe3f6b0 (Index: 0xc0, Flags: Final|Native|Public|BlueprintCallable)

private:
    FRigBoneElement FindBone_ForBlueprintOnly(const FRigElementKey InKey) const; // 0xbe278fc (Index: 0x3, Flags: Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FRigControlElement FindControl_ForBlueprintOnly(const FRigElementKey InKey) const; // 0xbe27a58 (Index: 0x4, Flags: Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    FRigNullElement FindNull_ForBlueprintOnly(const FRigElementKey InKey) const; // 0xbe27b78 (Index: 0x5, Flags: Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(URigHierarchy) == 0x590, "Size mismatch for URigHierarchy");
static_assert(offsetof(URigHierarchy, ModifiedEventDynamic) == 0x40, "Offset mismatch for URigHierarchy::ModifiedEventDynamic");
static_assert(offsetof(URigHierarchy, TopologyVersion) == 0xa8, "Offset mismatch for URigHierarchy::TopologyVersion");
static_assert(offsetof(URigHierarchy, MetadataVersion) == 0xac, "Offset mismatch for URigHierarchy::MetadataVersion");
static_assert(offsetof(URigHierarchy, MetadataTagVersion) == 0xb0, "Offset mismatch for URigHierarchy::MetadataTagVersion");
static_assert(offsetof(URigHierarchy, bEnableDirtyPropagation) == 0xb2, "Offset mismatch for URigHierarchy::bEnableDirtyPropagation");
static_assert(offsetof(URigHierarchy, TransformStackIndex) == 0x2ac, "Offset mismatch for URigHierarchy::TransformStackIndex");
static_assert(offsetof(URigHierarchy, HierarchyController) == 0x320, "Offset mismatch for URigHierarchy::HierarchyController");
static_assert(offsetof(URigHierarchy, RuleManager) == 0x330, "Offset mismatch for URigHierarchy::RuleManager");
static_assert(offsetof(URigHierarchy, HierarchyForCacheValidation) == 0x4c8, "Offset mismatch for URigHierarchy::HierarchyForCacheValidation");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class URigHierarchyProvider : public UInterface
{
public:
};

static_assert(sizeof(URigHierarchyProvider) == 0x28, "Size mismatch for URigHierarchyProvider");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAnimNodeControlRigLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FControlRigReference ConvertToControlRig(const FAnimNodeReference Node, EAnimNodeReferenceConversionResult& Result); // 0xbea2d10 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ConvertToControlRigPure(const FAnimNodeReference Node, FControlRigReference& ControlRig, bool& Result); // 0xbea2ecc (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FControlRigReference SetControlRigClass(const FControlRigReference Node, UClass*& ControlRigClass); // 0xbea940c (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAnimNodeControlRigLibrary) == 0x28, "Size mismatch for UAnimNodeControlRigLibrary");

// Size: 0x88 (Inherited: 0x88, Single: 0x0)
class UTransformableControlHandle : public UTransformableHandle
{
public:
    TSoftObjectPtr<UControlRig*> ControlRig; // 0x60 (Size: 0x20, Type: SoftObjectProperty)
    FName ControlName; // 0x80 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UTransformableControlHandle) == 0x88, "Size mismatch for UTransformableControlHandle");
static_assert(offsetof(UTransformableControlHandle, ControlRig) == 0x60, "Offset mismatch for UTransformableControlHandle::ControlRig");
static_assert(offsetof(UTransformableControlHandle, ControlName) == 0x80, "Offset mismatch for UTransformableControlHandle::ControlName");

// Size: 0x3e0 (Inherited: 0x408, Single: 0xffffffd8)
class UControlRigAnimInstance : public UAnimInstance
{
public:
};

static_assert(sizeof(UControlRigAnimInstance) == 0x3e0, "Size mismatch for UControlRigAnimInstance");

// Size: 0x390 (Inherited: 0xa10, Single: 0xfffff980)
class UControlRigBlueprintGeneratedClass : public URigVMBlueprintGeneratedClass
{
public:
};

static_assert(sizeof(UControlRigBlueprintGeneratedClass) == 0x390, "Size mismatch for UControlRigBlueprintGeneratedClass");

// Size: 0x680 (Inherited: 0x840, Single: 0xfffffe40)
class UControlRigComponent : public UPrimitiveComponent
{
public:
    UClass* ControlRigClass; // 0x518 (Size: 0x8, Type: ClassProperty)
    uint8_t OnPreInitializeDelegate[0x10]; // 0x520 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPostInitializeDelegate[0x10]; // 0x530 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPreConstructionDelegate[0x10]; // 0x540 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPostConstructionDelegate[0x10]; // 0x550 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPreForwardsSolveDelegate[0x10]; // 0x560 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPostForwardsSolveDelegate[0x10]; // 0x570 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<FControlRigComponentMappedElement> UserDefinedElements; // 0x580 (Size: 0x10, Type: ArrayProperty)
    TArray<FControlRigComponentMappedElement> MappedElements; // 0x590 (Size: 0x10, Type: ArrayProperty)
    bool bEnableLazyEvaluation; // 0x5a0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5a1[0x3]; // 0x5a1 (Size: 0x3, Type: PaddingProperty)
    float LazyEvaluationPositionThreshold; // 0x5a4 (Size: 0x4, Type: FloatProperty)
    float LazyEvaluationRotationThreshold; // 0x5a8 (Size: 0x4, Type: FloatProperty)
    float LazyEvaluationScaleThreshold; // 0x5ac (Size: 0x4, Type: FloatProperty)
    bool bResetTransformBeforeTick; // 0x5b0 (Size: 0x1, Type: BoolProperty)
    bool bResetInitialsBeforeConstruction; // 0x5b1 (Size: 0x1, Type: BoolProperty)
    bool bUpdateRigOnTick; // 0x5b2 (Size: 0x1, Type: BoolProperty)
    bool bUpdateInEditor; // 0x5b3 (Size: 0x1, Type: BoolProperty)
    bool bDrawBones; // 0x5b4 (Size: 0x1, Type: BoolProperty)
    bool bShowDebugDrawing; // 0x5b5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5b6[0x2]; // 0x5b6 (Size: 0x2, Type: PaddingProperty)
    UControlRig* ControlRig; // 0x5b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_5c0[0xc0]; // 0x5c0 (Size: 0xc0, Type: PaddingProperty)

public:
    void AddMappedCompleteSkeletalMesh(USkeletalMeshComponent*& SkeletalMeshComponent, EControlRigComponentMapDirection& const InDirection); // 0xbea0068 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void AddMappedComponents(TArray<FControlRigComponentMappedComponent>& Components); // 0xbea0290 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void AddMappedElements(TArray<FControlRigComponentMappedElement>& NewMappedElements); // 0xbea05cc (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void AddMappedSkeletalMesh(USkeletalMeshComponent*& SkeletalMeshComponent, TArray<FControlRigComponentMappedBone>& Bones, TArray<FControlRigComponentMappedCurve>& Curves, EControlRigComponentMapDirection& const InDirection); // 0xbea0718 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    bool CanExecute(); // 0xbea2550 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    void ClearMappedElements(); // 0xbea2588 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    bool DoesElementExist(FName& Name, ERigElementType& ElementType); // 0xbea3fa4 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    float GetAbsoluteTime() const; // 0xbea4638 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FTransform GetBoneTransform(FName& BoneName, EControlRigComponentSpace& Space); // 0xbea46e0 (Index: 0x8, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    bool GetControlBool(FName& ControlName); // 0xbea4c50 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    float GetControlFloat(FName& ControlName); // 0xbea4de8 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    int32_t GetControlInt(FName& ControlName); // 0xbea4f20 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    FTransform GetControlOffset(FName& ControlName, EControlRigComponentSpace& Space); // 0xbea50b8 (Index: 0xc, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    FVector GetControlPosition(FName& ControlName, EControlRigComponentSpace& Space); // 0xbea5324 (Index: 0xd, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    UControlRig* GetControlRig(); // 0xbea556c (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    FRotator GetControlRotator(FName& ControlName, EControlRigComponentSpace& Space); // 0xbea5590 (Index: 0xf, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    FVector GetControlScale(FName& ControlName, EControlRigComponentSpace& Space); // 0xbea5804 (Index: 0x10, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    FTransform GetControlTransform(FName& ControlName, EControlRigComponentSpace& Space); // 0xbea5a4c (Index: 0x11, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    FVector2D GetControlVector2D(FName& ControlName); // 0xbea5cb8 (Index: 0x12, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    TArray<FName> GetElementNames(ERigElementType& ElementType); // 0xbea5dfc (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    FTransform GetInitialBoneTransform(FName& BoneName, EControlRigComponentSpace& Space); // 0xbea6418 (Index: 0x14, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    FTransform GetInitialSpaceTransform(FName& SpaceName, EControlRigComponentSpace& Space); // 0xbea6684 (Index: 0x15, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    FTransform GetSpaceTransform(FName& SpaceName, EControlRigComponentSpace& Space); // 0xbea6af8 (Index: 0x16, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    void Initialize(); // 0xbea6d98 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    virtual void OnPostConstruction(UControlRigComponent*& Component); // 0xbea734c (Index: 0x18, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnPostForwardsSolve(UControlRigComponent*& Component); // 0xa20b278 (Index: 0x19, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnPostInitialize(UControlRigComponent*& Component); // 0xbea747c (Index: 0x1a, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnPreConstruction(UControlRigComponent*& Component); // 0xbea75ac (Index: 0x1b, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnPreForwardsSolve(UControlRigComponent*& Component); // 0xa7e8480 (Index: 0x1c, Flags: Native|Event|Public|BlueprintEvent)
    virtual void OnPreInitialize(UControlRigComponent*& Component); // 0xbea76dc (Index: 0x1d, Flags: Native|Event|Public|BlueprintEvent)
    void SetBoneInitialTransformsFromSkeletalMesh(USkeletalMesh*& InSkeletalMesh); // 0xbea7f7c (Index: 0x1e, Flags: Final|Native|Public|BlueprintCallable)
    void SetBoneTransform(FName& BoneName, FTransform& Transform, EControlRigComponentSpace& Space, float& Weight, bool& bPropagateToChildren); // 0xbea80bc (Index: 0x1f, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetControlBool(FName& ControlName, bool& Value); // 0xbea88a8 (Index: 0x20, Flags: Final|Native|Public|BlueprintCallable)
    void SetControlFloat(FName& ControlName, float& Value); // 0xbea8afc (Index: 0x21, Flags: Final|Native|Public|BlueprintCallable)
    void SetControlInt(FName& ControlName, int32_t& Value); // 0xbea8d04 (Index: 0x22, Flags: Final|Native|Public|BlueprintCallable)
    void SetControlOffset(FName& ControlName, FTransform& OffsetTransform, EControlRigComponentSpace& Space); // 0xbea8f50 (Index: 0x23, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetControlPosition(FName& ControlName, FVector& Value, EControlRigComponentSpace& Space); // 0xbea91f8 (Index: 0x24, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetControlRigClass(UClass*& InControlRigClass); // 0xbea989c (Index: 0x25, Flags: Final|Native|Public|BlueprintCallable)
    void SetControlRotator(FName& ControlName, FRotator& Value, EControlRigComponentSpace& Space); // 0xbea9d50 (Index: 0x26, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetControlScale(FName& ControlName, FVector& Value, EControlRigComponentSpace& Space); // 0xbea9f64 (Index: 0x27, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetControlTransform(FName& ControlName, FTransform& Value, EControlRigComponentSpace& Space); // 0xbeaa178 (Index: 0x28, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetControlVector2D(FName& ControlName, FVector2D& Value); // 0xbeaa420 (Index: 0x29, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetInitialBoneTransform(FName& BoneName, FTransform& InitialTransform, EControlRigComponentSpace& Space, bool& bPropagateToChildren); // 0xbeaa88c (Index: 0x2a, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetInitialSpaceTransform(FName& SpaceName, FTransform& InitialTransform, EControlRigComponentSpace& Space); // 0xbeaaba4 (Index: 0x2b, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetMappedElements(TArray<FControlRigComponentMappedElement>& NewMappedElements); // 0xbeaaeac (Index: 0x2c, Flags: Final|Native|Public|BlueprintCallable)
    void SetObjectBinding(UObject*& InObjectToBind); // 0xbeab2d4 (Index: 0x2d, Flags: Final|Native|Public|BlueprintCallable)
    void Update(float& DeltaTime); // 0xbeac5f0 (Index: 0x2e, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UControlRigComponent) == 0x680, "Size mismatch for UControlRigComponent");
static_assert(offsetof(UControlRigComponent, ControlRigClass) == 0x518, "Offset mismatch for UControlRigComponent::ControlRigClass");
static_assert(offsetof(UControlRigComponent, OnPreInitializeDelegate) == 0x520, "Offset mismatch for UControlRigComponent::OnPreInitializeDelegate");
static_assert(offsetof(UControlRigComponent, OnPostInitializeDelegate) == 0x530, "Offset mismatch for UControlRigComponent::OnPostInitializeDelegate");
static_assert(offsetof(UControlRigComponent, OnPreConstructionDelegate) == 0x540, "Offset mismatch for UControlRigComponent::OnPreConstructionDelegate");
static_assert(offsetof(UControlRigComponent, OnPostConstructionDelegate) == 0x550, "Offset mismatch for UControlRigComponent::OnPostConstructionDelegate");
static_assert(offsetof(UControlRigComponent, OnPreForwardsSolveDelegate) == 0x560, "Offset mismatch for UControlRigComponent::OnPreForwardsSolveDelegate");
static_assert(offsetof(UControlRigComponent, OnPostForwardsSolveDelegate) == 0x570, "Offset mismatch for UControlRigComponent::OnPostForwardsSolveDelegate");
static_assert(offsetof(UControlRigComponent, UserDefinedElements) == 0x580, "Offset mismatch for UControlRigComponent::UserDefinedElements");
static_assert(offsetof(UControlRigComponent, MappedElements) == 0x590, "Offset mismatch for UControlRigComponent::MappedElements");
static_assert(offsetof(UControlRigComponent, bEnableLazyEvaluation) == 0x5a0, "Offset mismatch for UControlRigComponent::bEnableLazyEvaluation");
static_assert(offsetof(UControlRigComponent, LazyEvaluationPositionThreshold) == 0x5a4, "Offset mismatch for UControlRigComponent::LazyEvaluationPositionThreshold");
static_assert(offsetof(UControlRigComponent, LazyEvaluationRotationThreshold) == 0x5a8, "Offset mismatch for UControlRigComponent::LazyEvaluationRotationThreshold");
static_assert(offsetof(UControlRigComponent, LazyEvaluationScaleThreshold) == 0x5ac, "Offset mismatch for UControlRigComponent::LazyEvaluationScaleThreshold");
static_assert(offsetof(UControlRigComponent, bResetTransformBeforeTick) == 0x5b0, "Offset mismatch for UControlRigComponent::bResetTransformBeforeTick");
static_assert(offsetof(UControlRigComponent, bResetInitialsBeforeConstruction) == 0x5b1, "Offset mismatch for UControlRigComponent::bResetInitialsBeforeConstruction");
static_assert(offsetof(UControlRigComponent, bUpdateRigOnTick) == 0x5b2, "Offset mismatch for UControlRigComponent::bUpdateRigOnTick");
static_assert(offsetof(UControlRigComponent, bUpdateInEditor) == 0x5b3, "Offset mismatch for UControlRigComponent::bUpdateInEditor");
static_assert(offsetof(UControlRigComponent, bDrawBones) == 0x5b4, "Offset mismatch for UControlRigComponent::bDrawBones");
static_assert(offsetof(UControlRigComponent, bShowDebugDrawing) == 0x5b5, "Offset mismatch for UControlRigComponent::bShowDebugDrawing");
static_assert(offsetof(UControlRigComponent, ControlRig) == 0x5b8, "Offset mismatch for UControlRigComponent::ControlRig");

// Size: 0x350 (Inherited: 0x2d0, Single: 0x80)
class AControlRigControlActor : public AActor
{
public:
    AActor* ActorToTrack; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UClass* ControlRigClass; // 0x2b0 (Size: 0x8, Type: ClassProperty)
    bool bRefreshOnTick; // 0x2b8 (Size: 0x1, Type: BoolProperty)
    bool bIsSelectable; // 0x2b9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2ba[0x6]; // 0x2ba (Size: 0x6, Type: PaddingProperty)
    UMaterialInterface* MaterialOverride; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    FString ColorParameter; // 0x2c8 (Size: 0x10, Type: StrProperty)
    bool bCastShadows; // 0x2d8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d9[0x7]; // 0x2d9 (Size: 0x7, Type: PaddingProperty)
    USceneComponent* ActorRootComponent; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UControlRig*> ControlRig; // 0x2e8 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FName> ControlNames; // 0x308 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> ShapeTransforms; // 0x318 (Size: 0x10, Type: ArrayProperty)
    TArray<UStaticMeshComponent*> Components; // 0x328 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> Materials; // 0x338 (Size: 0x10, Type: ArrayProperty)
    FName ColorParameterName; // 0x348 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34c[0x4]; // 0x34c (Size: 0x4, Type: PaddingProperty)

public:
    void Clear(); // 0xbea2574 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void Refresh(); // 0xbea780c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void ResetControlActor(); // 0xbea7c74 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(AControlRigControlActor) == 0x350, "Size mismatch for AControlRigControlActor");
static_assert(offsetof(AControlRigControlActor, ActorToTrack) == 0x2a8, "Offset mismatch for AControlRigControlActor::ActorToTrack");
static_assert(offsetof(AControlRigControlActor, ControlRigClass) == 0x2b0, "Offset mismatch for AControlRigControlActor::ControlRigClass");
static_assert(offsetof(AControlRigControlActor, bRefreshOnTick) == 0x2b8, "Offset mismatch for AControlRigControlActor::bRefreshOnTick");
static_assert(offsetof(AControlRigControlActor, bIsSelectable) == 0x2b9, "Offset mismatch for AControlRigControlActor::bIsSelectable");
static_assert(offsetof(AControlRigControlActor, MaterialOverride) == 0x2c0, "Offset mismatch for AControlRigControlActor::MaterialOverride");
static_assert(offsetof(AControlRigControlActor, ColorParameter) == 0x2c8, "Offset mismatch for AControlRigControlActor::ColorParameter");
static_assert(offsetof(AControlRigControlActor, bCastShadows) == 0x2d8, "Offset mismatch for AControlRigControlActor::bCastShadows");
static_assert(offsetof(AControlRigControlActor, ActorRootComponent) == 0x2e0, "Offset mismatch for AControlRigControlActor::ActorRootComponent");
static_assert(offsetof(AControlRigControlActor, ControlRig) == 0x2e8, "Offset mismatch for AControlRigControlActor::ControlRig");
static_assert(offsetof(AControlRigControlActor, ControlNames) == 0x308, "Offset mismatch for AControlRigControlActor::ControlNames");
static_assert(offsetof(AControlRigControlActor, ShapeTransforms) == 0x318, "Offset mismatch for AControlRigControlActor::ShapeTransforms");
static_assert(offsetof(AControlRigControlActor, Components) == 0x328, "Offset mismatch for AControlRigControlActor::Components");
static_assert(offsetof(AControlRigControlActor, Materials) == 0x338, "Offset mismatch for AControlRigControlActor::Materials");
static_assert(offsetof(AControlRigControlActor, ColorParameterName) == 0x348, "Offset mismatch for AControlRigControlActor::ColorParameterName");

// Size: 0x380 (Inherited: 0x2d0, Single: 0xb0)
class AControlRigShapeActor : public AActor
{
public:
    uint8_t Pad_2a8[0x8]; // 0x2a8 (Size: 0x8, Type: PaddingProperty)
    USceneComponent* ActorRootComponent; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMeshComponent; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    uint32_t ControlRigIndex; // 0x2c0 (Size: 0x4, Type: UInt32Property)
    TWeakObjectPtr<UControlRig*> ControlRig; // 0x2c4 (Size: 0x8, Type: WeakObjectProperty)
    FName ControlName; // 0x2cc (Size: 0x4, Type: NameProperty)
    FName ShapeName; // 0x2d0 (Size: 0x4, Type: NameProperty)
    FName ColorParameterName; // 0x2d4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_2d8[0x78]; // 0x2d8 (Size: 0x78, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x350 (Size: 0x18, Type: StructProperty)
    uint8_t bSelected : 1; // 0x368:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bHovered : 1; // 0x368:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_369[0x17]; // 0x369 (Size: 0x17, Type: PaddingProperty)

public:
    FTransform GetGlobalTransform() const; // 0xbea6324 (Index: 0x0, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool IsEnabled() const; // 0xbea6ea4 (Index: 0x1, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsHovered() const; // 0xbea6ecc (Index: 0x2, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsSelectedInEditor() const; // 0xa553874 (Index: 0x3, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void OnEnabledChanged(bool& bIsEnabled); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    virtual void OnHoveredChanged(bool& bIsSelected); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
    virtual void OnManipulatingChanged(bool& bIsManipulating); // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintEvent)
    virtual void OnSelectionChanged(bool& bIsSelected); // 0x288a61c (Index: 0x7, Flags: Event|Public|BlueprintEvent)
    virtual void OnTransformChanged(const FTransform NewTransform); // 0x288a61c (Index: 0x8, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintEvent)
    void SetEnabled(bool& bInEnabled); // 0x9f0f060 (Index: 0x9, Flags: Native|Public|BlueprintCallable)
    void SetGlobalTransform(const FTransform InTransform); // 0xbeaa5fc (Index: 0xa, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void SetHovered(bool& bInHovered); // 0xbeaa75c (Index: 0xb, Flags: Native|Public|BlueprintCallable)
    void SetSelectable(bool& bInSelectable); // 0xbeab52c (Index: 0xc, Flags: Native|Public|BlueprintCallable)
    void SetSelected(bool& bInSelected); // 0xbeab65c (Index: 0xd, Flags: Native|Public|BlueprintCallable)
};

static_assert(sizeof(AControlRigShapeActor) == 0x380, "Size mismatch for AControlRigShapeActor");
static_assert(offsetof(AControlRigShapeActor, ActorRootComponent) == 0x2b0, "Offset mismatch for AControlRigShapeActor::ActorRootComponent");
static_assert(offsetof(AControlRigShapeActor, StaticMeshComponent) == 0x2b8, "Offset mismatch for AControlRigShapeActor::StaticMeshComponent");
static_assert(offsetof(AControlRigShapeActor, ControlRigIndex) == 0x2c0, "Offset mismatch for AControlRigShapeActor::ControlRigIndex");
static_assert(offsetof(AControlRigShapeActor, ControlRig) == 0x2c4, "Offset mismatch for AControlRigShapeActor::ControlRig");
static_assert(offsetof(AControlRigShapeActor, ControlName) == 0x2cc, "Offset mismatch for AControlRigShapeActor::ControlName");
static_assert(offsetof(AControlRigShapeActor, ShapeName) == 0x2d0, "Offset mismatch for AControlRigShapeActor::ShapeName");
static_assert(offsetof(AControlRigShapeActor, ColorParameterName) == 0x2d4, "Offset mismatch for AControlRigShapeActor::ColorParameterName");
static_assert(offsetof(AControlRigShapeActor, CachedIndex) == 0x350, "Offset mismatch for AControlRigShapeActor::CachedIndex");
static_assert(offsetof(AControlRigShapeActor, bSelected) == 0x368, "Offset mismatch for AControlRigShapeActor::bSelected");
static_assert(offsetof(AControlRigShapeActor, bHovered) == 0x368, "Offset mismatch for AControlRigShapeActor::bHovered");

// Size: 0x140 (Inherited: 0x28, Single: 0x118)
class UControlRigShapeLibrary : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FControlRigShapeDefinition DefaultShape; // 0x30 (Size: 0xa0, Type: StructProperty)
    TSoftObjectPtr<UMaterial*> DefaultMaterial; // 0xd0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterial*> XRayMaterial; // 0xf0 (Size: 0x20, Type: SoftObjectProperty)
    FName MaterialColorParameter; // 0x110 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_114[0x4]; // 0x114 (Size: 0x4, Type: PaddingProperty)
    TArray<FControlRigShapeDefinition> Shapes; // 0x118 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_128[0x18]; // 0x128 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UControlRigShapeLibrary) == 0x140, "Size mismatch for UControlRigShapeLibrary");
static_assert(offsetof(UControlRigShapeLibrary, DefaultShape) == 0x30, "Offset mismatch for UControlRigShapeLibrary::DefaultShape");
static_assert(offsetof(UControlRigShapeLibrary, DefaultMaterial) == 0xd0, "Offset mismatch for UControlRigShapeLibrary::DefaultMaterial");
static_assert(offsetof(UControlRigShapeLibrary, XRayMaterial) == 0xf0, "Offset mismatch for UControlRigShapeLibrary::XRayMaterial");
static_assert(offsetof(UControlRigShapeLibrary, MaterialColorParameter) == 0x110, "Offset mismatch for UControlRigShapeLibrary::MaterialColorParameter");
static_assert(offsetof(UControlRigShapeLibrary, Shapes) == 0x118, "Offset mismatch for UControlRigShapeLibrary::Shapes");

// Size: 0x3d8 (Inherited: 0x28, Single: 0x3b0)
class UControlRigReplay : public UObject
{
public:
    FText Description; // 0x28 (Size: 0x10, Type: TextProperty)
    FSoftObjectPath ControlRigObjectPath; // 0x38 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath PreviewSkeletalMeshObjectPath; // 0x50 (Size: 0x18, Type: StructProperty)
    FControlRigReplayTracks InputTracks; // 0x68 (Size: 0x178, Type: StructProperty)
    FControlRigReplayTracks OutputTracks; // 0x1e0 (Size: 0x178, Type: StructProperty)
    double Tolerance; // 0x358 (Size: 0x8, Type: DoubleProperty)
    bool bValidateHierarchyTopology; // 0x360 (Size: 0x1, Type: BoolProperty)
    bool bValidatePose; // 0x361 (Size: 0x1, Type: BoolProperty)
    bool bValidateMetadata; // 0x362 (Size: 0x1, Type: BoolProperty)
    bool bValidateVariables; // 0x363 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_364[0x4]; // 0x364 (Size: 0x4, Type: PaddingProperty)
    TArray<int32_t> FramesToSkip; // 0x368 (Size: 0x10, Type: ArrayProperty)
    bool EnableTest; // 0x378 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_379[0x5f]; // 0x379 (Size: 0x5f, Type: PaddingProperty)

public:
    static UControlRigReplay* CreateNewAsset(FString& InDesiredPackagePath, FString& InBlueprintPathName, UClass*& InAssetClass); // 0xbea30f8 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    EControlRigReplayPlaybackMode GetPlaybackMode() const; // 0xbea6a94 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector2D GetTimeRange() const; // 0xbea6d64 (Index: 0x2, Flags: Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool IsPaused() const; // 0xa675388 (Index: 0x3, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsRecording() const; // 0xbea6ef4 (Index: 0x4, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsReplaying() const; // 0xa39d88c (Index: 0x5, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool PauseReplay(); // 0xa295148 (Index: 0x6, Flags: Native|Public|BlueprintCallable)
    void SetPlaybackMode(EControlRigReplayPlaybackMode& InMode); // 0xbeab400 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    bool StartRecording(UControlRig*& InControlRig); // 0xa8be280 (Index: 0x8, Flags: Native|Public|BlueprintCallable)
    bool StartReplay(UControlRig*& InControlRig, EControlRigReplayPlaybackMode& InMode); // 0xbeab78c (Index: 0x9, Flags: Native|Public|BlueprintCallable)
    bool StopRecording(); // 0xa554184 (Index: 0xa, Flags: Native|Public|BlueprintCallable)
    bool StopReplay(); // 0xa20aeec (Index: 0xb, Flags: Native|Public|BlueprintCallable)
};

static_assert(sizeof(UControlRigReplay) == 0x3d8, "Size mismatch for UControlRigReplay");
static_assert(offsetof(UControlRigReplay, Description) == 0x28, "Offset mismatch for UControlRigReplay::Description");
static_assert(offsetof(UControlRigReplay, ControlRigObjectPath) == 0x38, "Offset mismatch for UControlRigReplay::ControlRigObjectPath");
static_assert(offsetof(UControlRigReplay, PreviewSkeletalMeshObjectPath) == 0x50, "Offset mismatch for UControlRigReplay::PreviewSkeletalMeshObjectPath");
static_assert(offsetof(UControlRigReplay, InputTracks) == 0x68, "Offset mismatch for UControlRigReplay::InputTracks");
static_assert(offsetof(UControlRigReplay, OutputTracks) == 0x1e0, "Offset mismatch for UControlRigReplay::OutputTracks");
static_assert(offsetof(UControlRigReplay, Tolerance) == 0x358, "Offset mismatch for UControlRigReplay::Tolerance");
static_assert(offsetof(UControlRigReplay, bValidateHierarchyTopology) == 0x360, "Offset mismatch for UControlRigReplay::bValidateHierarchyTopology");
static_assert(offsetof(UControlRigReplay, bValidatePose) == 0x361, "Offset mismatch for UControlRigReplay::bValidatePose");
static_assert(offsetof(UControlRigReplay, bValidateMetadata) == 0x362, "Offset mismatch for UControlRigReplay::bValidateMetadata");
static_assert(offsetof(UControlRigReplay, bValidateVariables) == 0x363, "Offset mismatch for UControlRigReplay::bValidateVariables");
static_assert(offsetof(UControlRigReplay, FramesToSkip) == 0x368, "Offset mismatch for UControlRigReplay::FramesToSkip");
static_assert(offsetof(UControlRigReplay, EnableTest) == 0x378, "Offset mismatch for UControlRigReplay::EnableTest");

// Size: 0x518 (Inherited: 0x400, Single: 0x118)
class UControlRigTestData : public UControlRigReplay
{
public:
    FControlRigTestDataFrame Initial; // 0x3d8 (Size: 0x108, Type: StructProperty)
    TArray<FControlRigTestDataFrame> InputFrames; // 0x4e0 (Size: 0x10, Type: ArrayProperty)
    TArray<FControlRigTestDataFrame> OutputFrames; // 0x4f0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> EventQueue; // 0x500 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_510[0x8]; // 0x510 (Size: 0x8, Type: PaddingProperty)

public:
    int32_t GetFrameIndexForTime(double& InSeconds, bool& bInput) const; // 0xbea6100 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UControlRigTestData) == 0x518, "Size mismatch for UControlRigTestData");
static_assert(offsetof(UControlRigTestData, Initial) == 0x3d8, "Offset mismatch for UControlRigTestData::Initial");
static_assert(offsetof(UControlRigTestData, InputFrames) == 0x4e0, "Offset mismatch for UControlRigTestData::InputFrames");
static_assert(offsetof(UControlRigTestData, OutputFrames) == 0x4f0, "Offset mismatch for UControlRigTestData::OutputFrames");
static_assert(offsetof(UControlRigTestData, EventQueue) == 0x500, "Offset mismatch for UControlRigTestData::EventQueue");

// Size: 0x68 (Inherited: 0x28, Single: 0x40)
class UControlRigValidator : public UObject
{
public:
    TArray<UControlRigValidationPass*> Passes; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_38[0x30]; // 0x38 (Size: 0x30, Type: PaddingProperty)
};

static_assert(sizeof(UControlRigValidator) == 0x68, "Size mismatch for UControlRigValidator");
static_assert(offsetof(UControlRigValidator, Passes) == 0x28, "Offset mismatch for UControlRigValidator::Passes");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UControlRigValidationPass : public UObject
{
public:
};

static_assert(sizeof(UControlRigValidationPass) == 0x28, "Size mismatch for UControlRigValidationPass");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UModularRigController : public UObject
{
public:

public:
    FName AddModule(const FName InModuleName, UClass*& InClass, const FName InParentModuleName, bool& bSetupUndo); // 0xbea0d0c (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool AddTargetToArrayConnector(const FRigElementKey InConnectorKey, const FRigElementKey InTargetKey, bool& bSetupUndo, bool& bAutoResolveOtherConnectors, bool& bCheckValidConnection); // 0xbea116c (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool AutoConnectModules(const TArray<FName> InModuleNames, bool& bReplaceExistingConnections, bool& bSetupUndo); // 0xbea1454 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool AutoConnectSecondaryConnectors(const TArray<FRigElementKey> InConnectorKeys, bool& bReplaceExistingConnections, bool& bSetupUndo); // 0xbea17d4 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool BindModuleVariable(const FName InModuleName, const FName InVariableName, FString& InSourcePath, bool& bSetupUndo); // 0xbea1b20 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool CanConnectConnectorToElement(const FRigElementKey InConnectorKey, const FRigElementKey InTargetKey, FText& OutErrorMessage); // 0xbea1f84 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool CanConnectConnectorToElements(const FRigElementKey InConnectorKey, const TArray<FRigElementKey> InTargetKeys, FText& OutErrorMessage); // 0xbea2198 (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool ConnectConnectorToElement(const FRigElementKey InConnectorKey, const FRigElementKey InTargetKey, bool& bSetupUndo, bool& bAutoResolveOtherConnectors, bool& bCheckValidConnection); // 0xbea259c (Index: 0x7, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool ConnectConnectorToElements(const FRigElementKey InConnectorKey, const TArray<FRigElementKey> InTargetKeys, bool& bSetupUndo, bool& bAutoResolveOtherConnectors, bool& bCheckValidConnection); // 0xbea2884 (Index: 0x8, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool DeleteModule(const FName InModuleName, bool& bSetupUndo); // 0xbea3850 (Index: 0x9, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool DeselectModule(const FName InModuleName); // 0xbea39d0 (Index: 0xa, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool DisconnectConnector(const FRigElementKey InConnectorKey, bool& bDisconnectSubModules, bool& bSetupUndo); // 0xbea3ac4 (Index: 0xb, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    TArray<FRigElementKey> DisconnectCyclicConnectors(bool& bSetupUndo); // 0xbea3cac (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FName> GetAllModules() const; // 0xbea4664 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> GetConnectorsForModule(FName& InModuleName) const; // 0xbea494c (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FRigModuleReference GetModuleReference(FName& InModuleName) const; // 0xbea691c (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetSelectedModules() const; // 0xbea6ab8 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName MirrorModule(const FName InModuleName, const FRigVMMirrorSettings InSettings, bool& bSetupUndo); // 0xbea6f1c (Index: 0x11, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    FName RenameModule(const FName InModuleName, const FName InNewName, bool& bSetupUndo); // 0xbea7820 (Index: 0x12, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool ReparentModule(const FName InModuleName, const FName InNewParentModuleName, bool& bSetupUndo); // 0xbea7a48 (Index: 0x13, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool SelectModule(const FName InModuleName, bool& const InSelected); // 0xbea7dfc (Index: 0x14, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool SetConfigValueInModule(const FName InModuleName, const FName InVariableName, FString& InValue, bool& bSetupUndo); // 0xbea8444 (Index: 0x15, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool SetModuleSelection(const TArray<FName> InModuleNames); // 0xbeab02c (Index: 0x16, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool SwapModuleClass(const FName InModuleName, UClass*& InNewClass, bool& bSetupUndo); // 0xbeaba08 (Index: 0x17, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool SwapModulesOfClass(UClass*& InOldClass, UClass*& InNewClass, bool& bSetupUndo); // 0xbeabdc8 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    bool UnBindModuleVariable(const FName InModuleName, const FName InVariableName, bool& bSetupUndo); // 0xbeac3d8 (Index: 0x19, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UModularRigController) == 0x50, "Size mismatch for UModularRigController");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UModularRigRuleManager : public UObject
{
public:
};

static_assert(sizeof(UModularRigRuleManager) == 0x30, "Size mismatch for UModularRigRuleManager");

// Size: 0xb08 (Inherited: 0xd70, Single: 0xfffffd98)
class UAdditiveControlRig : public UControlRig
{
public:
};

static_assert(sizeof(UAdditiveControlRig) == 0xb08, "Size mismatch for UAdditiveControlRig");

// Size: 0xb38 (Inherited: 0xd70, Single: 0xfffffdc8)
class UFKControlRig : public UControlRig
{
public:
    TArray<bool> IsControlActive; // 0xaf8 (Size: 0x10, Type: ArrayProperty)
    uint8_t ApplyMode; // 0xb08 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_b09[0x2f]; // 0xb09 (Size: 0x2f, Type: PaddingProperty)
};

static_assert(sizeof(UFKControlRig) == 0xb38, "Size mismatch for UFKControlRig");
static_assert(offsetof(UFKControlRig, IsControlActive) == 0xaf8, "Offset mismatch for UFKControlRig::IsControlActive");
static_assert(offsetof(UFKControlRig, ApplyMode) == 0xb08, "Offset mismatch for UFKControlRig::ApplyMode");

// Size: 0x80 (Inherited: 0x28, Single: 0x58)
class URigHierarchyController : public UObject
{
public:
    bool bReportWarningsAndErrors; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x57]; // 0x29 (Size: 0x57, Type: PaddingProperty)

public:
    FRigElementKey AddAnimationChannel_ForBlueprint(FName& InName, FRigElementKey& InParentControl, FRigControlSettings& InSettings, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef2f9c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool AddAvailableSpace(FRigElementKey& InControl, FRigElementKey& InSpace, FName& InDisplayLabel, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef32c4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    FRigElementKey AddBone(FName& InName, FRigElementKey& InParent, FTransform& InTransform, bool& bTransformInGlobal, ERigBoneType& InBoneType, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef3560 (Index: 0x2, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    bool AddChannelHost(FRigElementKey& InChannel, FRigElementKey& InHost, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef39bc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    FRigComponentKey AddComponent(UScriptStruct*& InComponentStruct, FName& InName, FRigElementKey& InElement, FString& InContent, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef3bec (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    FRigElementKey AddConnector(FName& InName, FRigConnectorSettings& InSettings, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef4104 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    FRigElementKey AddControl_ForBlueprint(FName& InName, FRigElementKey& InParent, FRigControlSettings& InSettings, FRigControlValue& InValue, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef4560 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    FRigElementKey AddCurve(FName& InName, float& InValue, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef4998 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    FRigElementKey AddNull(FName& InName, FRigElementKey& InParent, FTransform& InTransform, bool& bTransformInGlobal, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef4d54 (Index: 0x8, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    bool AddParent(FRigElementKey& InChild, FRigElementKey& InParent, float& InWeight, bool& bMaintainGlobalTransform, FName& InDisplayLabel, bool& bSetupUndo); // 0xbef5188 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    FRigElementKey AddSocket(FName& InName, FRigElementKey& InParent, FTransform& InTransform, bool& bTransformInGlobal, const FLinearColor InColor, FString& InDescription, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef54ac (Index: 0xa, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    FRigComponentKey AddTopLevelComponent(UScriptStruct*& InComponentStruct, FName& InName, FString& InContent, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef5b60 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    bool ClearSelection(); // 0xbef61ac (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    bool DeselectComponent(FRigComponentKey& InKey); // 0xbef61d0 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    bool DeselectElement(FRigElementKey& InKey); // 0xbef62c0 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    bool DeselectHierarchyKey(FRigHierarchyKey& InKey); // 0xbef63a0 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FRigElementKey> DuplicateElements(TArray<FRigElementKey>& InKeys, bool& bSelectNewElements, bool& bSetupUndo, bool& bPrintPythonCommands); // 0xbef64c4 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    FString ExportSelectionToText() const; // 0xbef6b08 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString ExportToText(TArray<FRigElementKey>& InKeys) const; // 0xbef6b90 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FRigControlSettings GetControlSettings(FRigElementKey& InKey) const; // 0xbef6f28 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    URigHierarchy* GetHierarchy() const; // 0xbef7060 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FRigElementKey> ImportBones(USkeleton*& InSkeleton, FName& InNameSpace, bool& bReplaceExistingBones, bool& bRemoveObsoleteBones, bool& bSelectBones, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef7084 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FRigElementKey> ImportBonesFromSkeletalMesh(USkeletalMesh*& InSkeletalMesh, const FName InNameSpace, bool& bReplaceExistingBones, bool& bRemoveObsoleteBones, bool& bSelectBones, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef76a8 (Index: 0x16, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    TArray<FRigElementKey> ImportCurves(USkeleton*& InSkeleton, FName& InNameSpace, bool& bSelectCurves, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef7df0 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FRigElementKey> ImportCurvesFromSkeletalMesh(USkeletalMesh*& InSkeletalMesh, FName& InNameSpace, bool& bSelectCurves, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef84b8 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FRigElementKey> ImportFromText(FString& InContent, bool& bReplaceExistingElements, bool& bSelectNewElements, bool& bSetupUndo, bool& bPrintPythonCommands); // 0xbef8bd0 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FRigElementKey> ImportPreviewSkeletalMesh(USkeletalMesh*& InSkeletalMesh, bool& bReplaceExistingBones, bool& bRemoveObsoleteBones, bool& bSelectBones, bool& bSetupUndo); // 0xbef92b0 (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)
    TArray<FRigElementKey> ImportSocketsFromSkeletalMesh(USkeletalMesh*& InSkeletalMesh, const FName InNameSpace, bool& bReplaceExistingSockets, bool& bRemoveObsoleteSockets, bool& bSelectSockets, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbef9944 (Index: 0x1b, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    TArray<FRigElementKey> MirrorElements(TArray<FRigElementKey>& InKeys, FRigVMMirrorSettings& InSettings, bool& bSelectNewElements, bool& bSetupUndo, bool& bPrintPythonCommands); // 0xbef9f34 (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable)
    bool RemoveAllParents(FRigElementKey& InChild, bool& bMaintainGlobalTransform, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbefa538 (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable)
    bool RemoveAvailableSpace(FRigElementKey& InControl, FRigElementKey& InSpace, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbefa764 (Index: 0x1e, Flags: Final|Native|Public|BlueprintCallable)
    bool RemoveChannelHost(FRigElementKey& InChannel, FRigElementKey& InHost, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbefa994 (Index: 0x1f, Flags: Final|Native|Public|BlueprintCallable)
    bool RemoveComponent(FRigComponentKey& InComponent, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbefabc4 (Index: 0x20, Flags: Final|Native|Public|BlueprintCallable)
    bool RemoveElement(FRigElementKey& InElement, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbefad84 (Index: 0x21, Flags: Final|Native|Public|BlueprintCallable)
    bool RemoveParent(FRigElementKey& InChild, FRigElementKey& InParent, bool& bMaintainGlobalTransform, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbefaf2c (Index: 0x22, Flags: Final|Native|Public|BlueprintCallable)
    FRigComponentKey RenameComponent(FRigComponentKey& InComponent, FName& InName, bool& bSetupUndo, bool& bPrintPythonCommand, bool& bClearSelection); // 0xbefb1d8 (Index: 0x23, Flags: Final|Native|Public|BlueprintCallable)
    FRigElementKey RenameElement(FRigElementKey& InElement, FName& InName, bool& bSetupUndo, bool& bPrintPythonCommand, bool& bClearSelection); // 0xbefb48c (Index: 0x24, Flags: Final|Native|Public|BlueprintCallable)
    bool ReorderElement(FRigElementKey& InElement, int32_t& InIndex, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbefb724 (Index: 0x25, Flags: Final|Native|Public|BlueprintCallable)
    FRigComponentKey ReparentComponent(FRigComponentKey& InComponentKey, FRigElementKey& InParentElementKey, bool& bSetupUndo, bool& bPrintPythonCommand, bool& bClearSelection); // 0xbefb940 (Index: 0x26, Flags: Final|Native|Public|BlueprintCallable)
    bool SelectComponent(FRigComponentKey& InKey, bool& bSelect, bool& bClearSelection); // 0xbefbc08 (Index: 0x27, Flags: Final|Native|Public|BlueprintCallable)
    bool SelectElement(FRigElementKey& InKey, bool& bSelect, bool& bClearSelection); // 0xbefbddc (Index: 0x28, Flags: Final|Native|Public|BlueprintCallable)
    bool SelectHierarchyKey(FRigHierarchyKey& InKey, bool& bSelect, bool& bClearSelection); // 0xbefbfa0 (Index: 0x29, Flags: Final|Native|Public|BlueprintCallable)
    bool SetAvailableSpaceIndex(FRigElementKey& InControl, FRigElementKey& InSpace, int32_t& InIndex, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbefc18c (Index: 0x2a, Flags: Final|Native|Public|BlueprintCallable)
    bool SetAvailableSpaceLabel(FRigElementKey& InControl, FRigElementKey& InSpace, FName& InDisplayLabel, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbefc428 (Index: 0x2b, Flags: Final|Native|Public|BlueprintCallable)
    bool SetComponentContent(FRigComponentKey& InComponent, FString& InContent, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbefc6c4 (Index: 0x2c, Flags: Final|Native|Public|BlueprintCallable)
    bool SetComponentSelection(const TArray<FRigComponentKey> InKeys, bool& bPrintPythonCommand); // 0xbefcaa8 (Index: 0x2d, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool SetControlSettings(FRigElementKey& InKey, FRigControlSettings& InSettings, bool& bSetupUndo) const; // 0xbefcdc0 (Index: 0x2e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName SetDisplayName(FRigElementKey& InControl, FName& InDisplayName, bool& bRenameElement, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbefcfb8 (Index: 0x2f, Flags: Final|Native|Public|BlueprintCallable)
    void SetHierarchy(URigHierarchy*& InHierarchy); // 0xbefd25c (Index: 0x30, Flags: Final|Native|Public|BlueprintCallable)
    bool SetHierarchySelection(const TArray<FRigHierarchyKey> InKeys, bool& bPrintPythonCommand); // 0xbefd388 (Index: 0x31, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool SetParent(FRigElementKey& InChild, FRigElementKey& InParent, bool& bMaintainGlobalTransform, bool& bSetupUndo, bool& bPrintPythonCommand); // 0xbefd4f4 (Index: 0x32, Flags: Final|Native|Public|BlueprintCallable)
    bool SetSelection(const TArray<FRigElementKey> InKeys, bool& bPrintPythonCommand); // 0xbefd7a0 (Index: 0x33, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(URigHierarchyController) == 0x80, "Size mismatch for URigHierarchyController");
static_assert(offsetof(URigHierarchyController, bReportWarningsAndErrors) == 0x28, "Offset mismatch for URigHierarchyController::bReportWarningsAndErrors");

// Size: 0x3e0 (Inherited: 0x408, Single: 0xffffffd8)
class UControlRigLayerInstance : public UAnimInstance
{
public:
};

static_assert(sizeof(UControlRigLayerInstance) == 0x3e0, "Size mismatch for UControlRigLayerInstance");

// Size: 0x438 (Inherited: 0x360, Single: 0xd8)
class UMovieSceneControlRigParameterSection : public UMovieSceneParameterSection
{
public:
    uint8_t Pad_170[0x48]; // 0x170 (Size: 0x48, Type: PaddingProperty)
    UControlRig* ControlRig; // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    UClass* ControlRigClass; // 0x1c0 (Size: 0x8, Type: ClassProperty)
    TArray<bool> ControlsMask; // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    TSet<FName> ControlNameMask; // 0x1d8 (Size: 0x50, Type: SetProperty)
    FMovieSceneTransformMask TransformMask; // 0x228 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_22c[0x4]; // 0x22c (Size: 0x4, Type: PaddingProperty)
    FMovieSceneFloatChannel Weight; // 0x230 (Size: 0x110, Type: StructProperty)
    TMap<FChannelMapInfo, FName> ControlChannelMap; // 0x340 (Size: 0x50, Type: MapProperty)
    TArray<FEnumParameterNameAndCurve> EnumParameterNamesAndCurves; // 0x390 (Size: 0x10, Type: ArrayProperty)
    TArray<FIntegerParameterNameAndCurve> IntegerParameterNamesAndCurves; // 0x3a0 (Size: 0x10, Type: ArrayProperty)
    TArray<FSpaceControlNameAndChannel> SpaceChannels; // 0x3b0 (Size: 0x10, Type: ArrayProperty)
    TArray<FConstraintAndActiveChannel> ConstraintsChannels; // 0x3c0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_3d0[0x68]; // 0x3d0 (Size: 0x68, Type: PaddingProperty)
};

static_assert(sizeof(UMovieSceneControlRigParameterSection) == 0x438, "Size mismatch for UMovieSceneControlRigParameterSection");
static_assert(offsetof(UMovieSceneControlRigParameterSection, ControlRig) == 0x1b8, "Offset mismatch for UMovieSceneControlRigParameterSection::ControlRig");
static_assert(offsetof(UMovieSceneControlRigParameterSection, ControlRigClass) == 0x1c0, "Offset mismatch for UMovieSceneControlRigParameterSection::ControlRigClass");
static_assert(offsetof(UMovieSceneControlRigParameterSection, ControlsMask) == 0x1c8, "Offset mismatch for UMovieSceneControlRigParameterSection::ControlsMask");
static_assert(offsetof(UMovieSceneControlRigParameterSection, ControlNameMask) == 0x1d8, "Offset mismatch for UMovieSceneControlRigParameterSection::ControlNameMask");
static_assert(offsetof(UMovieSceneControlRigParameterSection, TransformMask) == 0x228, "Offset mismatch for UMovieSceneControlRigParameterSection::TransformMask");
static_assert(offsetof(UMovieSceneControlRigParameterSection, Weight) == 0x230, "Offset mismatch for UMovieSceneControlRigParameterSection::Weight");
static_assert(offsetof(UMovieSceneControlRigParameterSection, ControlChannelMap) == 0x340, "Offset mismatch for UMovieSceneControlRigParameterSection::ControlChannelMap");
static_assert(offsetof(UMovieSceneControlRigParameterSection, EnumParameterNamesAndCurves) == 0x390, "Offset mismatch for UMovieSceneControlRigParameterSection::EnumParameterNamesAndCurves");
static_assert(offsetof(UMovieSceneControlRigParameterSection, IntegerParameterNamesAndCurves) == 0x3a0, "Offset mismatch for UMovieSceneControlRigParameterSection::IntegerParameterNamesAndCurves");
static_assert(offsetof(UMovieSceneControlRigParameterSection, SpaceChannels) == 0x3b0, "Offset mismatch for UMovieSceneControlRigParameterSection::SpaceChannels");
static_assert(offsetof(UMovieSceneControlRigParameterSection, ConstraintsChannels) == 0x3c0, "Offset mismatch for UMovieSceneControlRigParameterSection::ConstraintsChannels");

// Size: 0x280 (Inherited: 0x308, Single: 0xffffff78)
class UMovieSceneControlRigParameterTrack : public UMovieSceneNameableTrack
{
public:
    uint8_t Pad_110[0x18]; // 0x110 (Size: 0x18, Type: PaddingProperty)
    TMap<TWeakObjectPtr<UMovieSceneSection*>, FName> SectionToKeyPerControl; // 0x128 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_178[0x38]; // 0x178 (Size: 0x38, Type: PaddingProperty)
    UControlRig* ControlRig; // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    UMovieSceneSection* SectionToKey; // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    TArray<UMovieSceneSection*> Sections; // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    FName TrackName; // 0x1d0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1d4[0x4]; // 0x1d4 (Size: 0x4, Type: PaddingProperty)
    TMap<FControlRotationOrder, FName> ControlsRotationOrder; // 0x1d8 (Size: 0x50, Type: MapProperty)
    int32_t PriorityOrder; // 0x228 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_22c[0x4]; // 0x22c (Size: 0x4, Type: PaddingProperty)
    TMap<UControlRig*, TWeakObjectPtr<UWorld*>> GameWorldControlRigs; // 0x230 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UMovieSceneControlRigParameterTrack) == 0x280, "Size mismatch for UMovieSceneControlRigParameterTrack");
static_assert(offsetof(UMovieSceneControlRigParameterTrack, SectionToKeyPerControl) == 0x128, "Offset mismatch for UMovieSceneControlRigParameterTrack::SectionToKeyPerControl");
static_assert(offsetof(UMovieSceneControlRigParameterTrack, ControlRig) == 0x1b0, "Offset mismatch for UMovieSceneControlRigParameterTrack::ControlRig");
static_assert(offsetof(UMovieSceneControlRigParameterTrack, SectionToKey) == 0x1b8, "Offset mismatch for UMovieSceneControlRigParameterTrack::SectionToKey");
static_assert(offsetof(UMovieSceneControlRigParameterTrack, Sections) == 0x1c0, "Offset mismatch for UMovieSceneControlRigParameterTrack::Sections");
static_assert(offsetof(UMovieSceneControlRigParameterTrack, TrackName) == 0x1d0, "Offset mismatch for UMovieSceneControlRigParameterTrack::TrackName");
static_assert(offsetof(UMovieSceneControlRigParameterTrack, ControlsRotationOrder) == 0x1d8, "Offset mismatch for UMovieSceneControlRigParameterTrack::ControlsRotationOrder");
static_assert(offsetof(UMovieSceneControlRigParameterTrack, PriorityOrder) == 0x228, "Offset mismatch for UMovieSceneControlRigParameterTrack::PriorityOrder");
static_assert(offsetof(UMovieSceneControlRigParameterTrack, GameWorldControlRigs) == 0x230, "Offset mismatch for UMovieSceneControlRigParameterTrack::GameWorldControlRigs");

// Size: 0x248 (Inherited: 0x68, Single: 0x1e0)
class UMovieSceneControlRigParameterEvaluatorSystem : public UMovieSceneEntitySystem
{
public:
    uint8_t Pad_40[0x200]; // 0x40 (Size: 0x200, Type: PaddingProperty)
    UMovieScenePiecewiseDoubleBlenderSystem* DoubleBlenderSystem; // 0x240 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UMovieSceneControlRigParameterEvaluatorSystem) == 0x248, "Size mismatch for UMovieSceneControlRigParameterEvaluatorSystem");
static_assert(offsetof(UMovieSceneControlRigParameterEvaluatorSystem, DoubleBlenderSystem) == 0x240, "Offset mismatch for UMovieSceneControlRigParameterEvaluatorSystem::DoubleBlenderSystem");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UControlRigSettings : public UDeveloperSettings
{
public:
};

static_assert(sizeof(UControlRigSettings) == 0x30, "Size mismatch for UControlRigSettings");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UControlRigEditorSettings : public URigVMEditorSettings
{
public:
};

static_assert(sizeof(UControlRigEditorSettings) == 0x30, "Size mismatch for UControlRigEditorSettings");

// Size: 0x88 (Inherited: 0x28, Single: 0x60)
class UControlRigPoseAsset : public UObject
{
public:
    FControlRigControlPose Pose; // 0x28 (Size: 0x60, Type: StructProperty)

public:
    bool DoesMirrorMatch(UControlRig*& ControlRig, const FName ControlName) const; // 0xbf92748 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetControlNames() const; // 0xbf92978 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GetCurrentPose(UControlRig*& InControlRig, FControlRigControlPose& OutPose); // 0xbf929c0 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void PastePose(UControlRig*& InControlRig, bool& bDoKey, bool& bDoMirror); // 0xbf92bc0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void ReplaceControlName(const FName CurrentName, const FName NewName); // 0xbf93094 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SavePose(UControlRig*& InControlRig, bool& bUseAll); // 0xbf93210 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SelectControls(UControlRig*& InControlRig, bool& bDoMirror, bool& bClearSelection); // 0xbf9341c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UControlRigPoseAsset) == 0x88, "Size mismatch for UControlRigPoseAsset");
static_assert(offsetof(UControlRigPoseAsset, Pose) == 0x28, "Offset mismatch for UControlRigPoseAsset::Pose");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UControlRigPoseMirrorSettings : public UObject
{
public:
    FString RightSide; // 0x28 (Size: 0x10, Type: StrProperty)
    FString LeftSide; // 0x38 (Size: 0x10, Type: StrProperty)
    TEnumAsByte<EAxis> MirrorAxis; // 0x48 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EAxis> AxisToFlip; // 0x49 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_4a[0x6]; // 0x4a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UControlRigPoseMirrorSettings) == 0x50, "Size mismatch for UControlRigPoseMirrorSettings");
static_assert(offsetof(UControlRigPoseMirrorSettings, RightSide) == 0x28, "Offset mismatch for UControlRigPoseMirrorSettings::RightSide");
static_assert(offsetof(UControlRigPoseMirrorSettings, LeftSide) == 0x38, "Offset mismatch for UControlRigPoseMirrorSettings::LeftSide");
static_assert(offsetof(UControlRigPoseMirrorSettings, MirrorAxis) == 0x48, "Offset mismatch for UControlRigPoseMirrorSettings::MirrorAxis");
static_assert(offsetof(UControlRigPoseMirrorSettings, AxisToFlip) == 0x49, "Offset mismatch for UControlRigPoseMirrorSettings::AxisToFlip");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UControlRigPoseProjectSettings : public UObject
{
public:
    TArray<FDirectoryPath> RootSaveDirs; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UControlRigPoseProjectSettings) == 0x38, "Size mismatch for UControlRigPoseProjectSettings");
static_assert(offsetof(UControlRigPoseProjectSettings, RootSaveDirs) == 0x28, "Offset mismatch for UControlRigPoseProjectSettings::RootSaveDirs");

// Size: 0xb0 (Inherited: 0xc0, Single: 0xfffffff0)
class UControlRigWorkflowOptions : public URigVMUserWorkflowOptions
{
public:
    URigHierarchy* Hierarchy; // 0x98 (Size: 0x8, Type: ObjectProperty)
    TArray<FRigElementKey> Selection; // 0xa0 (Size: 0x10, Type: ArrayProperty)

public:
    bool EnsureAtLeastOneRigElementSelected() const; // 0xbf92904 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UControlRigWorkflowOptions) == 0xb0, "Size mismatch for UControlRigWorkflowOptions");
static_assert(offsetof(UControlRigWorkflowOptions, Hierarchy) == 0x98, "Offset mismatch for UControlRigWorkflowOptions::Hierarchy");
static_assert(offsetof(UControlRigWorkflowOptions, Selection) == 0xa0, "Offset mismatch for UControlRigWorkflowOptions::Selection");

// Size: 0xb8 (Inherited: 0x170, Single: 0xffffff48)
class UControlRigTransformWorkflowOptions : public UControlRigWorkflowOptions
{
public:
    TEnumAsByte<ERigTransformType> TransformType; // 0xb0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_b1[0x7]; // 0xb1 (Size: 0x7, Type: PaddingProperty)

public:
    TArray<FRigVMUserWorkflow> ProvideWorkflows(UObject*& const InSubject); // 0xbf92ed0 (Index: 0x0, Flags: Final|Native|Public)
};

static_assert(sizeof(UControlRigTransformWorkflowOptions) == 0xb8, "Size mismatch for UControlRigTransformWorkflowOptions");
static_assert(offsetof(UControlRigTransformWorkflowOptions, TransformType) == 0xb0, "Offset mismatch for UControlRigTransformWorkflowOptions::TransformType");

// Size: 0xb8 (Inherited: 0x50, Single: 0x68)
class UControlRigNumericalValidationPass : public UControlRigValidationPass
{
public:
    bool bCheckControls; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bCheckBones; // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bCheckCurves; // 0x2a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b[0x1]; // 0x2b (Size: 0x1, Type: PaddingProperty)
    float TranslationPrecision; // 0x2c (Size: 0x4, Type: FloatProperty)
    float RotationPrecision; // 0x30 (Size: 0x4, Type: FloatProperty)
    float ScalePrecision; // 0x34 (Size: 0x4, Type: FloatProperty)
    float CurvePrecision; // 0x38 (Size: 0x4, Type: FloatProperty)
    FName EventNameA; // 0x3c (Size: 0x4, Type: NameProperty)
    FName EventNameB; // 0x40 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
    FRigPose Pose; // 0x48 (Size: 0x70, Type: StructProperty)
};

static_assert(sizeof(UControlRigNumericalValidationPass) == 0xb8, "Size mismatch for UControlRigNumericalValidationPass");
static_assert(offsetof(UControlRigNumericalValidationPass, bCheckControls) == 0x28, "Offset mismatch for UControlRigNumericalValidationPass::bCheckControls");
static_assert(offsetof(UControlRigNumericalValidationPass, bCheckBones) == 0x29, "Offset mismatch for UControlRigNumericalValidationPass::bCheckBones");
static_assert(offsetof(UControlRigNumericalValidationPass, bCheckCurves) == 0x2a, "Offset mismatch for UControlRigNumericalValidationPass::bCheckCurves");
static_assert(offsetof(UControlRigNumericalValidationPass, TranslationPrecision) == 0x2c, "Offset mismatch for UControlRigNumericalValidationPass::TranslationPrecision");
static_assert(offsetof(UControlRigNumericalValidationPass, RotationPrecision) == 0x30, "Offset mismatch for UControlRigNumericalValidationPass::RotationPrecision");
static_assert(offsetof(UControlRigNumericalValidationPass, ScalePrecision) == 0x34, "Offset mismatch for UControlRigNumericalValidationPass::ScalePrecision");
static_assert(offsetof(UControlRigNumericalValidationPass, CurvePrecision) == 0x38, "Offset mismatch for UControlRigNumericalValidationPass::CurvePrecision");
static_assert(offsetof(UControlRigNumericalValidationPass, EventNameA) == 0x3c, "Offset mismatch for UControlRigNumericalValidationPass::EventNameA");
static_assert(offsetof(UControlRigNumericalValidationPass, EventNameB) == 0x40, "Offset mismatch for UControlRigNumericalValidationPass::EventNameB");
static_assert(offsetof(UControlRigNumericalValidationPass, Pose) == 0x48, "Offset mismatch for UControlRigNumericalValidationPass::Pose");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FRigElementKey
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FName Name; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FRigElementKey) == 0x8, "Size mismatch for FRigElementKey");
static_assert(offsetof(FRigElementKey, Type) == 0x0, "Offset mismatch for FRigElementKey::Type");
static_assert(offsetof(FRigElementKey, Name) == 0x4, "Offset mismatch for FRigElementKey::Name");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FRigBaseElement
{
    FRigElementKey Key; // 0x10 (Size: 0x8, Type: StructProperty)
    int32_t Index; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t SubIndex; // 0x1c (Size: 0x4, Type: IntProperty)
    int32_t CreatedAtInstructionIndex; // 0x20 (Size: 0x4, Type: IntProperty)
    bool bSelected; // 0x24 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_25[0x33]; // 0x25 (Size: 0x33, Type: PaddingProperty)
};

static_assert(sizeof(FRigBaseElement) == 0x58, "Size mismatch for FRigBaseElement");
static_assert(offsetof(FRigBaseElement, Key) == 0x10, "Offset mismatch for FRigBaseElement::Key");
static_assert(offsetof(FRigBaseElement, Index) == 0x18, "Offset mismatch for FRigBaseElement::Index");
static_assert(offsetof(FRigBaseElement, SubIndex) == 0x1c, "Offset mismatch for FRigBaseElement::SubIndex");
static_assert(offsetof(FRigBaseElement, CreatedAtInstructionIndex) == 0x20, "Offset mismatch for FRigBaseElement::CreatedAtInstructionIndex");
static_assert(offsetof(FRigBaseElement, bSelected) == 0x24, "Offset mismatch for FRigBaseElement::bSelected");

// Size: 0x118 (Inherited: 0x58, Single: 0xc0)
struct FRigTransformElement : FRigBaseElement
{
};

static_assert(sizeof(FRigTransformElement) == 0x118, "Size mismatch for FRigTransformElement");

// Size: 0x230 (Inherited: 0x170, Single: 0xc0)
struct FRigMultiParentElement : FRigTransformElement
{
};

static_assert(sizeof(FRigMultiParentElement) == 0x230, "Size mismatch for FRigMultiParentElement");

// Size: 0x520 (Inherited: 0x3a0, Single: 0x180)
struct FRigControlElement : FRigMultiParentElement
{
    FRigControlSettings Settings; // 0x230 (Size: 0x1b0, Type: StructProperty)
    FRigPreferredEulerAngles PreferredEulerAngles; // 0x3e0 (Size: 0x38, Type: StructProperty)
    uint8_t Pad_418[0x108]; // 0x418 (Size: 0x108, Type: PaddingProperty)
};

static_assert(sizeof(FRigControlElement) == 0x520, "Size mismatch for FRigControlElement");
static_assert(offsetof(FRigControlElement, Settings) == 0x230, "Offset mismatch for FRigControlElement::Settings");
static_assert(offsetof(FRigControlElement, PreferredEulerAngles) == 0x3e0, "Offset mismatch for FRigControlElement::PreferredEulerAngles");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FRigPreferredEulerAngles
{
    uint8_t RotationOrder; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FVector Current; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Initial; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigPreferredEulerAngles) == 0x38, "Size mismatch for FRigPreferredEulerAngles");
static_assert(offsetof(FRigPreferredEulerAngles, RotationOrder) == 0x0, "Offset mismatch for FRigPreferredEulerAngles::RotationOrder");
static_assert(offsetof(FRigPreferredEulerAngles, Current) == 0x8, "Offset mismatch for FRigPreferredEulerAngles::Current");
static_assert(offsetof(FRigPreferredEulerAngles, Initial) == 0x20, "Offset mismatch for FRigPreferredEulerAngles::Initial");

// Size: 0x1b0 (Inherited: 0x0, Single: 0x1b0)
struct FRigControlSettings
{
    uint8_t AnimationType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t ControlType; // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    FName DisplayName; // 0x4 (Size: 0x4, Type: NameProperty)
    uint8_t PrimaryAxis; // 0x8 (Size: 0x1, Type: EnumProperty)
    bool bIsCurve; // 0x9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a[0x6]; // 0xa (Size: 0x6, Type: PaddingProperty)
    TArray<FRigControlLimitEnabled> LimitEnabled; // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bDrawLimits; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x3]; // 0x21 (Size: 0x3, Type: PaddingProperty)
    FRigControlValue MinimumValue; // 0x24 (Size: 0x84, Type: StructProperty)
    FRigControlValue MaximumValue; // 0xa8 (Size: 0x84, Type: StructProperty)
    bool bShapeVisible; // 0x12c (Size: 0x1, Type: BoolProperty)
    uint8_t ShapeVisibility; // 0x12d (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_12e[0x2]; // 0x12e (Size: 0x2, Type: PaddingProperty)
    FName ShapeName; // 0x130 (Size: 0x4, Type: NameProperty)
    FLinearColor ShapeColor; // 0x134 (Size: 0x10, Type: StructProperty)
    bool bIsTransientControl; // 0x144 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_145[0x3]; // 0x145 (Size: 0x3, Type: PaddingProperty)
    UEnum* ControlEnum; // 0x148 (Size: 0x8, Type: ObjectProperty)
    FRigControlElementCustomization Customization; // 0x150 (Size: 0x20, Type: StructProperty)
    TArray<FRigElementKey> DrivenControls; // 0x170 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_180[0x10]; // 0x180 (Size: 0x10, Type: PaddingProperty)
    bool bGroupWithParentControl; // 0x190 (Size: 0x1, Type: BoolProperty)
    bool bRestrictSpaceSwitching; // 0x191 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_192[0x6]; // 0x192 (Size: 0x6, Type: PaddingProperty)
    TArray<ERigControlTransformChannel> FilteredChannels; // 0x198 (Size: 0x10, Type: ArrayProperty)
    uint8_t PreferredRotationOrder; // 0x1a8 (Size: 0x1, Type: EnumProperty)
    bool bUsePreferredRotationOrder; // 0x1a9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1aa[0x6]; // 0x1aa (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FRigControlSettings) == 0x1b0, "Size mismatch for FRigControlSettings");
static_assert(offsetof(FRigControlSettings, AnimationType) == 0x0, "Offset mismatch for FRigControlSettings::AnimationType");
static_assert(offsetof(FRigControlSettings, ControlType) == 0x1, "Offset mismatch for FRigControlSettings::ControlType");
static_assert(offsetof(FRigControlSettings, DisplayName) == 0x4, "Offset mismatch for FRigControlSettings::DisplayName");
static_assert(offsetof(FRigControlSettings, PrimaryAxis) == 0x8, "Offset mismatch for FRigControlSettings::PrimaryAxis");
static_assert(offsetof(FRigControlSettings, bIsCurve) == 0x9, "Offset mismatch for FRigControlSettings::bIsCurve");
static_assert(offsetof(FRigControlSettings, LimitEnabled) == 0x10, "Offset mismatch for FRigControlSettings::LimitEnabled");
static_assert(offsetof(FRigControlSettings, bDrawLimits) == 0x20, "Offset mismatch for FRigControlSettings::bDrawLimits");
static_assert(offsetof(FRigControlSettings, MinimumValue) == 0x24, "Offset mismatch for FRigControlSettings::MinimumValue");
static_assert(offsetof(FRigControlSettings, MaximumValue) == 0xa8, "Offset mismatch for FRigControlSettings::MaximumValue");
static_assert(offsetof(FRigControlSettings, bShapeVisible) == 0x12c, "Offset mismatch for FRigControlSettings::bShapeVisible");
static_assert(offsetof(FRigControlSettings, ShapeVisibility) == 0x12d, "Offset mismatch for FRigControlSettings::ShapeVisibility");
static_assert(offsetof(FRigControlSettings, ShapeName) == 0x130, "Offset mismatch for FRigControlSettings::ShapeName");
static_assert(offsetof(FRigControlSettings, ShapeColor) == 0x134, "Offset mismatch for FRigControlSettings::ShapeColor");
static_assert(offsetof(FRigControlSettings, bIsTransientControl) == 0x144, "Offset mismatch for FRigControlSettings::bIsTransientControl");
static_assert(offsetof(FRigControlSettings, ControlEnum) == 0x148, "Offset mismatch for FRigControlSettings::ControlEnum");
static_assert(offsetof(FRigControlSettings, Customization) == 0x150, "Offset mismatch for FRigControlSettings::Customization");
static_assert(offsetof(FRigControlSettings, DrivenControls) == 0x170, "Offset mismatch for FRigControlSettings::DrivenControls");
static_assert(offsetof(FRigControlSettings, bGroupWithParentControl) == 0x190, "Offset mismatch for FRigControlSettings::bGroupWithParentControl");
static_assert(offsetof(FRigControlSettings, bRestrictSpaceSwitching) == 0x191, "Offset mismatch for FRigControlSettings::bRestrictSpaceSwitching");
static_assert(offsetof(FRigControlSettings, FilteredChannels) == 0x198, "Offset mismatch for FRigControlSettings::FilteredChannels");
static_assert(offsetof(FRigControlSettings, PreferredRotationOrder) == 0x1a8, "Offset mismatch for FRigControlSettings::PreferredRotationOrder");
static_assert(offsetof(FRigControlSettings, bUsePreferredRotationOrder) == 0x1a9, "Offset mismatch for FRigControlSettings::bUsePreferredRotationOrder");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FRigControlElementCustomization
{
    TArray<FRigElementKeyWithLabel> AvailableSpaces; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigElementKey> RemovedSpaces; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigControlElementCustomization) == 0x20, "Size mismatch for FRigControlElementCustomization");
static_assert(offsetof(FRigControlElementCustomization, AvailableSpaces) == 0x0, "Offset mismatch for FRigControlElementCustomization::AvailableSpaces");
static_assert(offsetof(FRigControlElementCustomization, RemovedSpaces) == 0x10, "Offset mismatch for FRigControlElementCustomization::RemovedSpaces");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FRigElementKeyWithLabel
{
    FRigElementKey Key; // 0x0 (Size: 0x8, Type: StructProperty)
    FName Label; // 0x8 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FRigElementKeyWithLabel) == 0xc, "Size mismatch for FRigElementKeyWithLabel");
static_assert(offsetof(FRigElementKeyWithLabel, Key) == 0x0, "Offset mismatch for FRigElementKeyWithLabel::Key");
static_assert(offsetof(FRigElementKeyWithLabel, Label) == 0x8, "Offset mismatch for FRigElementKeyWithLabel::Label");

// Size: 0x84 (Inherited: 0x0, Single: 0x84)
struct FRigControlValue
{
    FRigControlValueStorage FloatStorage; // 0x0 (Size: 0x84, Type: StructProperty)
};

static_assert(sizeof(FRigControlValue) == 0x84, "Size mismatch for FRigControlValue");
static_assert(offsetof(FRigControlValue, FloatStorage) == 0x0, "Offset mismatch for FRigControlValue::FloatStorage");

// Size: 0x84 (Inherited: 0x0, Single: 0x84)
struct FRigControlValueStorage
{
    float Float00; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Float01; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Float02; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Float03; // 0xc (Size: 0x4, Type: FloatProperty)
    float Float10; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Float11; // 0x14 (Size: 0x4, Type: FloatProperty)
    float Float12; // 0x18 (Size: 0x4, Type: FloatProperty)
    float Float13; // 0x1c (Size: 0x4, Type: FloatProperty)
    float Float20; // 0x20 (Size: 0x4, Type: FloatProperty)
    float Float21; // 0x24 (Size: 0x4, Type: FloatProperty)
    float Float22; // 0x28 (Size: 0x4, Type: FloatProperty)
    float Float23; // 0x2c (Size: 0x4, Type: FloatProperty)
    float Float30; // 0x30 (Size: 0x4, Type: FloatProperty)
    float Float31; // 0x34 (Size: 0x4, Type: FloatProperty)
    float Float32; // 0x38 (Size: 0x4, Type: FloatProperty)
    float Float33; // 0x3c (Size: 0x4, Type: FloatProperty)
    float Float00_2; // 0x40 (Size: 0x4, Type: FloatProperty)
    float Float01_2; // 0x44 (Size: 0x4, Type: FloatProperty)
    float Float02_2; // 0x48 (Size: 0x4, Type: FloatProperty)
    float Float03_2; // 0x4c (Size: 0x4, Type: FloatProperty)
    float Float10_2; // 0x50 (Size: 0x4, Type: FloatProperty)
    float Float11_2; // 0x54 (Size: 0x4, Type: FloatProperty)
    float Float12_2; // 0x58 (Size: 0x4, Type: FloatProperty)
    float Float13_2; // 0x5c (Size: 0x4, Type: FloatProperty)
    float Float20_2; // 0x60 (Size: 0x4, Type: FloatProperty)
    float Float21_2; // 0x64 (Size: 0x4, Type: FloatProperty)
    float Float22_2; // 0x68 (Size: 0x4, Type: FloatProperty)
    float Float23_2; // 0x6c (Size: 0x4, Type: FloatProperty)
    float Float30_2; // 0x70 (Size: 0x4, Type: FloatProperty)
    float Float31_2; // 0x74 (Size: 0x4, Type: FloatProperty)
    float Float32_2; // 0x78 (Size: 0x4, Type: FloatProperty)
    float Float33_2; // 0x7c (Size: 0x4, Type: FloatProperty)
    bool bValid; // 0x80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_81[0x3]; // 0x81 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigControlValueStorage) == 0x84, "Size mismatch for FRigControlValueStorage");
static_assert(offsetof(FRigControlValueStorage, Float00) == 0x0, "Offset mismatch for FRigControlValueStorage::Float00");
static_assert(offsetof(FRigControlValueStorage, Float01) == 0x4, "Offset mismatch for FRigControlValueStorage::Float01");
static_assert(offsetof(FRigControlValueStorage, Float02) == 0x8, "Offset mismatch for FRigControlValueStorage::Float02");
static_assert(offsetof(FRigControlValueStorage, Float03) == 0xc, "Offset mismatch for FRigControlValueStorage::Float03");
static_assert(offsetof(FRigControlValueStorage, Float10) == 0x10, "Offset mismatch for FRigControlValueStorage::Float10");
static_assert(offsetof(FRigControlValueStorage, Float11) == 0x14, "Offset mismatch for FRigControlValueStorage::Float11");
static_assert(offsetof(FRigControlValueStorage, Float12) == 0x18, "Offset mismatch for FRigControlValueStorage::Float12");
static_assert(offsetof(FRigControlValueStorage, Float13) == 0x1c, "Offset mismatch for FRigControlValueStorage::Float13");
static_assert(offsetof(FRigControlValueStorage, Float20) == 0x20, "Offset mismatch for FRigControlValueStorage::Float20");
static_assert(offsetof(FRigControlValueStorage, Float21) == 0x24, "Offset mismatch for FRigControlValueStorage::Float21");
static_assert(offsetof(FRigControlValueStorage, Float22) == 0x28, "Offset mismatch for FRigControlValueStorage::Float22");
static_assert(offsetof(FRigControlValueStorage, Float23) == 0x2c, "Offset mismatch for FRigControlValueStorage::Float23");
static_assert(offsetof(FRigControlValueStorage, Float30) == 0x30, "Offset mismatch for FRigControlValueStorage::Float30");
static_assert(offsetof(FRigControlValueStorage, Float31) == 0x34, "Offset mismatch for FRigControlValueStorage::Float31");
static_assert(offsetof(FRigControlValueStorage, Float32) == 0x38, "Offset mismatch for FRigControlValueStorage::Float32");
static_assert(offsetof(FRigControlValueStorage, Float33) == 0x3c, "Offset mismatch for FRigControlValueStorage::Float33");
static_assert(offsetof(FRigControlValueStorage, Float00_2) == 0x40, "Offset mismatch for FRigControlValueStorage::Float00_2");
static_assert(offsetof(FRigControlValueStorage, Float01_2) == 0x44, "Offset mismatch for FRigControlValueStorage::Float01_2");
static_assert(offsetof(FRigControlValueStorage, Float02_2) == 0x48, "Offset mismatch for FRigControlValueStorage::Float02_2");
static_assert(offsetof(FRigControlValueStorage, Float03_2) == 0x4c, "Offset mismatch for FRigControlValueStorage::Float03_2");
static_assert(offsetof(FRigControlValueStorage, Float10_2) == 0x50, "Offset mismatch for FRigControlValueStorage::Float10_2");
static_assert(offsetof(FRigControlValueStorage, Float11_2) == 0x54, "Offset mismatch for FRigControlValueStorage::Float11_2");
static_assert(offsetof(FRigControlValueStorage, Float12_2) == 0x58, "Offset mismatch for FRigControlValueStorage::Float12_2");
static_assert(offsetof(FRigControlValueStorage, Float13_2) == 0x5c, "Offset mismatch for FRigControlValueStorage::Float13_2");
static_assert(offsetof(FRigControlValueStorage, Float20_2) == 0x60, "Offset mismatch for FRigControlValueStorage::Float20_2");
static_assert(offsetof(FRigControlValueStorage, Float21_2) == 0x64, "Offset mismatch for FRigControlValueStorage::Float21_2");
static_assert(offsetof(FRigControlValueStorage, Float22_2) == 0x68, "Offset mismatch for FRigControlValueStorage::Float22_2");
static_assert(offsetof(FRigControlValueStorage, Float23_2) == 0x6c, "Offset mismatch for FRigControlValueStorage::Float23_2");
static_assert(offsetof(FRigControlValueStorage, Float30_2) == 0x70, "Offset mismatch for FRigControlValueStorage::Float30_2");
static_assert(offsetof(FRigControlValueStorage, Float31_2) == 0x74, "Offset mismatch for FRigControlValueStorage::Float31_2");
static_assert(offsetof(FRigControlValueStorage, Float32_2) == 0x78, "Offset mismatch for FRigControlValueStorage::Float32_2");
static_assert(offsetof(FRigControlValueStorage, Float33_2) == 0x7c, "Offset mismatch for FRigControlValueStorage::Float33_2");
static_assert(offsetof(FRigControlValueStorage, bValid) == 0x80, "Offset mismatch for FRigControlValueStorage::bValid");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FRigControlLimitEnabled
{
    bool bMinimum; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bMaximum; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FRigControlLimitEnabled) == 0x2, "Size mismatch for FRigControlLimitEnabled");
static_assert(offsetof(FRigControlLimitEnabled, bMinimum) == 0x0, "Offset mismatch for FRigControlLimitEnabled::bMinimum");
static_assert(offsetof(FRigControlLimitEnabled, bMaximum) == 0x1, "Offset mismatch for FRigControlLimitEnabled::bMaximum");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FRigModuleSettings
{
    FRigModuleIdentifier Identifier; // 0x0 (Size: 0x20, Type: StructProperty)
    FSoftObjectPath Icon; // 0x20 (Size: 0x18, Type: StructProperty)
    FString Category; // 0x38 (Size: 0x10, Type: StrProperty)
    FString Keywords; // 0x48 (Size: 0x10, Type: StrProperty)
    FString Description; // 0x58 (Size: 0x10, Type: StrProperty)
    TArray<FRigModuleConnector> ExposedConnectors; // 0x68 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigModuleSettings) == 0x78, "Size mismatch for FRigModuleSettings");
static_assert(offsetof(FRigModuleSettings, Identifier) == 0x0, "Offset mismatch for FRigModuleSettings::Identifier");
static_assert(offsetof(FRigModuleSettings, Icon) == 0x20, "Offset mismatch for FRigModuleSettings::Icon");
static_assert(offsetof(FRigModuleSettings, Category) == 0x38, "Offset mismatch for FRigModuleSettings::Category");
static_assert(offsetof(FRigModuleSettings, Keywords) == 0x48, "Offset mismatch for FRigModuleSettings::Keywords");
static_assert(offsetof(FRigModuleSettings, Description) == 0x58, "Offset mismatch for FRigModuleSettings::Description");
static_assert(offsetof(FRigModuleSettings, ExposedConnectors) == 0x68, "Offset mismatch for FRigModuleSettings::ExposedConnectors");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FRigModuleConnector
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FRigConnectorSettings Settings; // 0x10 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FRigModuleConnector) == 0x38, "Size mismatch for FRigModuleConnector");
static_assert(offsetof(FRigModuleConnector, Name) == 0x0, "Offset mismatch for FRigModuleConnector::Name");
static_assert(offsetof(FRigModuleConnector, Settings) == 0x10, "Offset mismatch for FRigModuleConnector::Settings");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FRigConnectorSettings
{
    FString Description; // 0x0 (Size: 0x10, Type: StrProperty)
    uint8_t Type; // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bOptional; // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bIsArray; // 0x12 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_13[0x5]; // 0x13 (Size: 0x5, Type: PaddingProperty)
    TArray<FRigConnectionRuleStash> Rules; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigConnectorSettings) == 0x28, "Size mismatch for FRigConnectorSettings");
static_assert(offsetof(FRigConnectorSettings, Description) == 0x0, "Offset mismatch for FRigConnectorSettings::Description");
static_assert(offsetof(FRigConnectorSettings, Type) == 0x10, "Offset mismatch for FRigConnectorSettings::Type");
static_assert(offsetof(FRigConnectorSettings, bOptional) == 0x11, "Offset mismatch for FRigConnectorSettings::bOptional");
static_assert(offsetof(FRigConnectorSettings, bIsArray) == 0x12, "Offset mismatch for FRigConnectorSettings::bIsArray");
static_assert(offsetof(FRigConnectorSettings, Rules) == 0x18, "Offset mismatch for FRigConnectorSettings::Rules");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FRigConnectionRuleStash
{
    FString ScriptStructPath; // 0x0 (Size: 0x10, Type: StrProperty)
    FString ExportedText; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FRigConnectionRuleStash) == 0x20, "Size mismatch for FRigConnectionRuleStash");
static_assert(offsetof(FRigConnectionRuleStash, ScriptStructPath) == 0x0, "Offset mismatch for FRigConnectionRuleStash::ScriptStructPath");
static_assert(offsetof(FRigConnectionRuleStash, ExportedText) == 0x10, "Offset mismatch for FRigConnectionRuleStash::ExportedText");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FRigModuleIdentifier
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Type; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FRigModuleIdentifier) == 0x20, "Size mismatch for FRigModuleIdentifier");
static_assert(offsetof(FRigModuleIdentifier, Name) == 0x0, "Offset mismatch for FRigModuleIdentifier::Name");
static_assert(offsetof(FRigModuleIdentifier, Type) == 0x10, "Offset mismatch for FRigModuleIdentifier::Type");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FRigInfluenceMapPerEvent
{
    TArray<FRigInfluenceMap> Maps; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TMap<int32_t, FName> EventToIndex; // 0x10 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FRigInfluenceMapPerEvent) == 0x60, "Size mismatch for FRigInfluenceMapPerEvent");
static_assert(offsetof(FRigInfluenceMapPerEvent, Maps) == 0x0, "Offset mismatch for FRigInfluenceMapPerEvent::Maps");
static_assert(offsetof(FRigInfluenceMapPerEvent, EventToIndex) == 0x10, "Offset mismatch for FRigInfluenceMapPerEvent::EventToIndex");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FRigInfluenceMap
{
    FName EventName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FRigInfluenceEntry> Entries; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TMap<int32_t, FRigElementKey> KeyToIndex; // 0x18 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FRigInfluenceMap) == 0x68, "Size mismatch for FRigInfluenceMap");
static_assert(offsetof(FRigInfluenceMap, EventName) == 0x0, "Offset mismatch for FRigInfluenceMap::EventName");
static_assert(offsetof(FRigInfluenceMap, Entries) == 0x8, "Offset mismatch for FRigInfluenceMap::Entries");
static_assert(offsetof(FRigInfluenceMap, KeyToIndex) == 0x18, "Offset mismatch for FRigInfluenceMap::KeyToIndex");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FRigInfluenceEntry
{
    FRigElementKey Source; // 0x0 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementKey> AffectedList; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigInfluenceEntry) == 0x18, "Size mismatch for FRigInfluenceEntry");
static_assert(offsetof(FRigInfluenceEntry, Source) == 0x0, "Offset mismatch for FRigInfluenceEntry::Source");
static_assert(offsetof(FRigInfluenceEntry, AffectedList) == 0x8, "Offset mismatch for FRigInfluenceEntry::AffectedList");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FRigHierarchySettings
{
    int32_t ProceduralElementLimit; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FRigHierarchySettings) == 0x4, "Size mismatch for FRigHierarchySettings");
static_assert(offsetof(FRigHierarchySettings, ProceduralElementLimit) == 0x0, "Offset mismatch for FRigHierarchySettings::ProceduralElementLimit");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FControlRigIOSettings
{
    bool bUpdatePose; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bUpdateCurves; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FControlRigIOSettings) == 0x2, "Size mismatch for FControlRigIOSettings");
static_assert(offsetof(FControlRigIOSettings, bUpdatePose) == 0x0, "Offset mismatch for FControlRigIOSettings::bUpdatePose");
static_assert(offsetof(FControlRigIOSettings, bUpdateCurves) == 0x1, "Offset mismatch for FControlRigIOSettings::bUpdateCurves");

// Size: 0xa8 (Inherited: 0x0, Single: 0xa8)
struct FRigModuleInstance
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UControlRig* RigPtr; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FString ParentPath; // 0x10 (Size: 0x10, Type: StrProperty)
    FName ParentModuleName; // 0x20 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TMap<FRigVMExternalVariable, FName> VariableBindings; // 0x28 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_78[0x30]; // 0x78 (Size: 0x30, Type: PaddingProperty)
};

static_assert(sizeof(FRigModuleInstance) == 0xa8, "Size mismatch for FRigModuleInstance");
static_assert(offsetof(FRigModuleInstance, Name) == 0x0, "Offset mismatch for FRigModuleInstance::Name");
static_assert(offsetof(FRigModuleInstance, RigPtr) == 0x8, "Offset mismatch for FRigModuleInstance::RigPtr");
static_assert(offsetof(FRigModuleInstance, ParentPath) == 0x10, "Offset mismatch for FRigModuleInstance::ParentPath");
static_assert(offsetof(FRigModuleInstance, ParentModuleName) == 0x20, "Offset mismatch for FRigModuleInstance::ParentModuleName");
static_assert(offsetof(FRigModuleInstance, VariableBindings) == 0x28, "Offset mismatch for FRigModuleInstance::VariableBindings");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FRigModuleExecutionElement
{
    FName ModuleName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0xc]; // 0x4 (Size: 0xc, Type: PaddingProperty)
    FName EventName; // 0x10 (Size: 0x4, Type: NameProperty)
    bool bExecuted; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigModuleExecutionElement) == 0x18, "Size mismatch for FRigModuleExecutionElement");
static_assert(offsetof(FRigModuleExecutionElement, ModuleName) == 0x0, "Offset mismatch for FRigModuleExecutionElement::ModuleName");
static_assert(offsetof(FRigModuleExecutionElement, EventName) == 0x10, "Offset mismatch for FRigModuleExecutionElement::EventName");
static_assert(offsetof(FRigModuleExecutionElement, bExecuted) == 0x14, "Offset mismatch for FRigModuleExecutionElement::bExecuted");

// Size: 0x148 (Inherited: 0x8, Single: 0x140)
struct FMovieSceneControlRigInstanceData : FMovieSceneSequenceInstanceData
{
    bool bAdditive; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bApplyBoneFilter; // 0x9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a[0x6]; // 0xa (Size: 0x6, Type: PaddingProperty)
    FInputBlendPose BoneFilter; // 0x10 (Size: 0x10, Type: StructProperty)
    FMovieSceneFloatChannel Weight; // 0x20 (Size: 0x110, Type: StructProperty)
    FMovieSceneEvaluationOperand Operand; // 0x130 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_144[0x4]; // 0x144 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FMovieSceneControlRigInstanceData) == 0x148, "Size mismatch for FMovieSceneControlRigInstanceData");
static_assert(offsetof(FMovieSceneControlRigInstanceData, bAdditive) == 0x8, "Offset mismatch for FMovieSceneControlRigInstanceData::bAdditive");
static_assert(offsetof(FMovieSceneControlRigInstanceData, bApplyBoneFilter) == 0x9, "Offset mismatch for FMovieSceneControlRigInstanceData::bApplyBoneFilter");
static_assert(offsetof(FMovieSceneControlRigInstanceData, BoneFilter) == 0x10, "Offset mismatch for FMovieSceneControlRigInstanceData::BoneFilter");
static_assert(offsetof(FMovieSceneControlRigInstanceData, Weight) == 0x20, "Offset mismatch for FMovieSceneControlRigInstanceData::Weight");
static_assert(offsetof(FMovieSceneControlRigInstanceData, Operand) == 0x130, "Offset mismatch for FMovieSceneControlRigInstanceData::Operand");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FRigUnit : FRigVMStruct
{
};

static_assert(sizeof(FRigUnit) == 0x8, "Size mismatch for FRigUnit");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_DebugBase : FRigUnit
{
    FRigVMDebugDrawSettings DebugDrawSettings; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_DebugBase) == 0x10, "Size mismatch for FRigUnit_DebugBase");
static_assert(offsetof(FRigUnit_DebugBase, DebugDrawSettings) == 0x8, "Offset mismatch for FRigUnit_DebugBase::DebugDrawSettings");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnitMutable : FRigUnit
{
    FRigVMExecutePin ExecutePin; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnitMutable) == 0x10, "Size mismatch for FRigUnitMutable");
static_assert(offsetof(FRigUnitMutable, ExecutePin) == 0x8, "Offset mismatch for FRigUnitMutable::ExecutePin");

// Size: 0x18 (Inherited: 0x20, Single: 0xfffffff8)
struct FRigUnit_DebugBaseMutable : FRigUnitMutable
{
    FRigVMDebugDrawSettings DebugDrawSettings; // 0x10 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_DebugBaseMutable) == 0x18, "Size mismatch for FRigUnit_DebugBaseMutable");
static_assert(offsetof(FRigUnit_DebugBaseMutable, DebugDrawSettings) == 0x10, "Offset mismatch for FRigUnit_DebugBaseMutable::DebugDrawSettings");

// Size: 0x8 (Inherited: 0x10, Single: 0xfffffff8)
struct FRigUnit_HighlevelBase : FRigUnit
{
};

static_assert(sizeof(FRigUnit_HighlevelBase) == 0x8, "Size mismatch for FRigUnit_HighlevelBase");

// Size: 0x10 (Inherited: 0x20, Single: 0xfffffff0)
struct FRigUnit_HighlevelBaseMutable : FRigUnitMutable
{
};

static_assert(sizeof(FRigUnit_HighlevelBaseMutable) == 0x10, "Size mismatch for FRigUnit_HighlevelBaseMutable");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FStructReference
{
};

static_assert(sizeof(FStructReference) == 0x8, "Size mismatch for FStructReference");

// Size: 0xf0 (Inherited: 0x0, Single: 0xf0)
struct FRigTransformStackEntry
{
    FRigElementKey Key; // 0x0 (Size: 0x8, Type: StructProperty)
    TEnumAsByte<ERigTransformStackEntryType> EntryType; // 0x8 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ERigTransformType> TransformType; // 0x9 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_a[0x6]; // 0xa (Size: 0x6, Type: PaddingProperty)
    FTransform OldTransform; // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform NewTransform; // 0x70 (Size: 0x60, Type: StructProperty)
    bool bAffectChildren; // 0xd0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d1[0x7]; // 0xd1 (Size: 0x7, Type: PaddingProperty)
    TArray<FString> Callstack; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_e8[0x8]; // 0xe8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigTransformStackEntry) == 0xf0, "Size mismatch for FRigTransformStackEntry");
static_assert(offsetof(FRigTransformStackEntry, Key) == 0x0, "Offset mismatch for FRigTransformStackEntry::Key");
static_assert(offsetof(FRigTransformStackEntry, EntryType) == 0x8, "Offset mismatch for FRigTransformStackEntry::EntryType");
static_assert(offsetof(FRigTransformStackEntry, TransformType) == 0x9, "Offset mismatch for FRigTransformStackEntry::TransformType");
static_assert(offsetof(FRigTransformStackEntry, OldTransform) == 0x10, "Offset mismatch for FRigTransformStackEntry::OldTransform");
static_assert(offsetof(FRigTransformStackEntry, NewTransform) == 0x70, "Offset mismatch for FRigTransformStackEntry::NewTransform");
static_assert(offsetof(FRigTransformStackEntry, bAffectChildren) == 0xd0, "Offset mismatch for FRigTransformStackEntry::bAffectChildren");
static_assert(offsetof(FRigTransformStackEntry, Callstack) == 0xd8, "Offset mismatch for FRigTransformStackEntry::Callstack");

// Size: 0x228 (Inherited: 0x68, Single: 0x1c0)
struct FAnimNode_ControlRigBase : FAnimNode_CustomProperty
{
    FPoseLink Source; // 0x58 (Size: 0x10, Type: StructProperty)
    bool bResetInputPoseToInitial; // 0x68 (Size: 0x1, Type: BoolProperty)
    bool bTransferInputPose; // 0x69 (Size: 0x1, Type: BoolProperty)
    bool bTransferInputCurves; // 0x6a (Size: 0x1, Type: BoolProperty)
    bool bTransferPoseInGlobalSpace; // 0x6b (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
    TArray<FBoneReference> InputBonesToTransfer; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FBoneReference> OutputBonesToTransfer; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<UAssetUserData*> AssetUserData; // 0x90 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UNodeMappingContainer*> NodeMappingContainer; // 0xa0 (Size: 0x8, Type: WeakObjectProperty)
    FControlRigIOSettings InputSettings; // 0xa8 (Size: 0x2, Type: StructProperty)
    FControlRigIOSettings OutputSettings; // 0xaa (Size: 0x2, Type: StructProperty)
    bool bExecute; // 0xac (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ad[0xb]; // 0xad (Size: 0xb, Type: PaddingProperty)
    TArray<FControlRigAnimNodeEventName> EventQueue; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_c8[0x160]; // 0xc8 (Size: 0x160, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_ControlRigBase) == 0x228, "Size mismatch for FAnimNode_ControlRigBase");
static_assert(offsetof(FAnimNode_ControlRigBase, Source) == 0x58, "Offset mismatch for FAnimNode_ControlRigBase::Source");
static_assert(offsetof(FAnimNode_ControlRigBase, bResetInputPoseToInitial) == 0x68, "Offset mismatch for FAnimNode_ControlRigBase::bResetInputPoseToInitial");
static_assert(offsetof(FAnimNode_ControlRigBase, bTransferInputPose) == 0x69, "Offset mismatch for FAnimNode_ControlRigBase::bTransferInputPose");
static_assert(offsetof(FAnimNode_ControlRigBase, bTransferInputCurves) == 0x6a, "Offset mismatch for FAnimNode_ControlRigBase::bTransferInputCurves");
static_assert(offsetof(FAnimNode_ControlRigBase, bTransferPoseInGlobalSpace) == 0x6b, "Offset mismatch for FAnimNode_ControlRigBase::bTransferPoseInGlobalSpace");
static_assert(offsetof(FAnimNode_ControlRigBase, InputBonesToTransfer) == 0x70, "Offset mismatch for FAnimNode_ControlRigBase::InputBonesToTransfer");
static_assert(offsetof(FAnimNode_ControlRigBase, OutputBonesToTransfer) == 0x80, "Offset mismatch for FAnimNode_ControlRigBase::OutputBonesToTransfer");
static_assert(offsetof(FAnimNode_ControlRigBase, AssetUserData) == 0x90, "Offset mismatch for FAnimNode_ControlRigBase::AssetUserData");
static_assert(offsetof(FAnimNode_ControlRigBase, NodeMappingContainer) == 0xa0, "Offset mismatch for FAnimNode_ControlRigBase::NodeMappingContainer");
static_assert(offsetof(FAnimNode_ControlRigBase, InputSettings) == 0xa8, "Offset mismatch for FAnimNode_ControlRigBase::InputSettings");
static_assert(offsetof(FAnimNode_ControlRigBase, OutputSettings) == 0xaa, "Offset mismatch for FAnimNode_ControlRigBase::OutputSettings");
static_assert(offsetof(FAnimNode_ControlRigBase, bExecute) == 0xac, "Offset mismatch for FAnimNode_ControlRigBase::bExecute");
static_assert(offsetof(FAnimNode_ControlRigBase, EventQueue) == 0xb8, "Offset mismatch for FAnimNode_ControlRigBase::EventQueue");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FControlRigAnimNodeEventName
{
    FName EventName; // 0x0 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FControlRigAnimNodeEventName) == 0x4, "Size mismatch for FControlRigAnimNodeEventName");
static_assert(offsetof(FControlRigAnimNodeEventName, EventName) == 0x0, "Offset mismatch for FControlRigAnimNodeEventName::EventName");

// Size: 0x4b8 (Inherited: 0x290, Single: 0x228)
struct FAnimNode_ControlRig : FAnimNode_ControlRigBase
{
    UClass* ControlRigClass; // 0x228 (Size: 0x8, Type: ClassProperty)
    UClass* DefaultControlRigClass; // 0x230 (Size: 0x8, Type: ClassProperty)
    UControlRig* ControlRig; // 0x238 (Size: 0x8, Type: ObjectProperty)
    TMap<UControlRig*, UClass*> ControlRigPerClass; // 0x240 (Size: 0x50, Type: MapProperty)
    float Alpha; // 0x290 (Size: 0x4, Type: FloatProperty)
    uint8_t AlphaInputType; // 0x294 (Size: 0x1, Type: EnumProperty)
    uint8_t bAlphaBoolEnabled : 1; // 0x295:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bSetRefPoseFromSkeleton : 1; // 0x295:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_296[0x2]; // 0x296 (Size: 0x2, Type: PaddingProperty)
    FInputScaleBias AlphaScaleBias; // 0x298 (Size: 0x8, Type: StructProperty)
    FInputAlphaBoolBlend AlphaBoolBlend; // 0x2a0 (Size: 0x48, Type: StructProperty)
    FName AlphaCurveName; // 0x2e8 (Size: 0x4, Type: NameProperty)
    FInputScaleBiasClamp AlphaScaleBiasClamp; // 0x2ec (Size: 0x30, Type: StructProperty)
    uint8_t Pad_31c[0x4]; // 0x31c (Size: 0x4, Type: PaddingProperty)
    TMap<FName, FName> InputMapping; // 0x320 (Size: 0x50, Type: MapProperty)
    TMap<FName, FName> OutputMapping; // 0x370 (Size: 0x50, Type: MapProperty)
    int32_t LODThreshold; // 0x3c0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_3c4[0xf4]; // 0x3c4 (Size: 0xf4, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_ControlRig) == 0x4b8, "Size mismatch for FAnimNode_ControlRig");
static_assert(offsetof(FAnimNode_ControlRig, ControlRigClass) == 0x228, "Offset mismatch for FAnimNode_ControlRig::ControlRigClass");
static_assert(offsetof(FAnimNode_ControlRig, DefaultControlRigClass) == 0x230, "Offset mismatch for FAnimNode_ControlRig::DefaultControlRigClass");
static_assert(offsetof(FAnimNode_ControlRig, ControlRig) == 0x238, "Offset mismatch for FAnimNode_ControlRig::ControlRig");
static_assert(offsetof(FAnimNode_ControlRig, ControlRigPerClass) == 0x240, "Offset mismatch for FAnimNode_ControlRig::ControlRigPerClass");
static_assert(offsetof(FAnimNode_ControlRig, Alpha) == 0x290, "Offset mismatch for FAnimNode_ControlRig::Alpha");
static_assert(offsetof(FAnimNode_ControlRig, AlphaInputType) == 0x294, "Offset mismatch for FAnimNode_ControlRig::AlphaInputType");
static_assert(offsetof(FAnimNode_ControlRig, bAlphaBoolEnabled) == 0x295, "Offset mismatch for FAnimNode_ControlRig::bAlphaBoolEnabled");
static_assert(offsetof(FAnimNode_ControlRig, bSetRefPoseFromSkeleton) == 0x295, "Offset mismatch for FAnimNode_ControlRig::bSetRefPoseFromSkeleton");
static_assert(offsetof(FAnimNode_ControlRig, AlphaScaleBias) == 0x298, "Offset mismatch for FAnimNode_ControlRig::AlphaScaleBias");
static_assert(offsetof(FAnimNode_ControlRig, AlphaBoolBlend) == 0x2a0, "Offset mismatch for FAnimNode_ControlRig::AlphaBoolBlend");
static_assert(offsetof(FAnimNode_ControlRig, AlphaCurveName) == 0x2e8, "Offset mismatch for FAnimNode_ControlRig::AlphaCurveName");
static_assert(offsetof(FAnimNode_ControlRig, AlphaScaleBiasClamp) == 0x2ec, "Offset mismatch for FAnimNode_ControlRig::AlphaScaleBiasClamp");
static_assert(offsetof(FAnimNode_ControlRig, InputMapping) == 0x320, "Offset mismatch for FAnimNode_ControlRig::InputMapping");
static_assert(offsetof(FAnimNode_ControlRig, OutputMapping) == 0x370, "Offset mismatch for FAnimNode_ControlRig::OutputMapping");
static_assert(offsetof(FAnimNode_ControlRig, LODThreshold) == 0x3c0, "Offset mismatch for FAnimNode_ControlRig::LODThreshold");

// Size: 0x230 (Inherited: 0x290, Single: 0xffffffa0)
struct FAnimNode_ControlRig_ExternalSource : FAnimNode_ControlRigBase
{
    TWeakObjectPtr<UControlRig*> ControlRig; // 0x228 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FAnimNode_ControlRig_ExternalSource) == 0x230, "Size mismatch for FAnimNode_ControlRig_ExternalSource");
static_assert(offsetof(FAnimNode_ControlRig_ExternalSource, ControlRig) == 0x228, "Offset mismatch for FAnimNode_ControlRig_ExternalSource::ControlRig");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FControlRigReference : FAnimNodeReference
{
};

static_assert(sizeof(FControlRigReference) == 0x10, "Size mismatch for FControlRigReference");

// Size: 0x880 (Inherited: 0x7a0, Single: 0xe0)
struct FControlRigAnimInstanceProxy : FAnimInstanceProxy
{
};

static_assert(sizeof(FControlRigAnimInstanceProxy) == 0x880, "Size mismatch for FControlRigAnimInstanceProxy");

// Size: 0xe0 (Inherited: 0x0, Single: 0xe0)
struct FControlRigComponentMappedElement
{
    FSoftComponentReference ComponentReference; // 0x0 (Size: 0x40, Type: StructProperty)
    int32_t TransformIndex; // 0x40 (Size: 0x4, Type: IntProperty)
    FName TransformName; // 0x44 (Size: 0x4, Type: NameProperty)
    uint8_t ElementType; // 0x48 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_49[0x3]; // 0x49 (Size: 0x3, Type: PaddingProperty)
    FName ElementName; // 0x4c (Size: 0x4, Type: NameProperty)
    uint8_t Direction; // 0x50 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_51[0xf]; // 0x51 (Size: 0xf, Type: PaddingProperty)
    FTransform Offset; // 0x60 (Size: 0x60, Type: StructProperty)
    float Weight; // 0xc0 (Size: 0x4, Type: FloatProperty)
    uint8_t Space; // 0xc4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c5[0x3]; // 0xc5 (Size: 0x3, Type: PaddingProperty)
    USceneComponent* SceneComponent; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    int32_t ElementIndex; // 0xd0 (Size: 0x4, Type: IntProperty)
    int32_t SubIndex; // 0xd4 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_d8[0x8]; // 0xd8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FControlRigComponentMappedElement) == 0xe0, "Size mismatch for FControlRigComponentMappedElement");
static_assert(offsetof(FControlRigComponentMappedElement, ComponentReference) == 0x0, "Offset mismatch for FControlRigComponentMappedElement::ComponentReference");
static_assert(offsetof(FControlRigComponentMappedElement, TransformIndex) == 0x40, "Offset mismatch for FControlRigComponentMappedElement::TransformIndex");
static_assert(offsetof(FControlRigComponentMappedElement, TransformName) == 0x44, "Offset mismatch for FControlRigComponentMappedElement::TransformName");
static_assert(offsetof(FControlRigComponentMappedElement, ElementType) == 0x48, "Offset mismatch for FControlRigComponentMappedElement::ElementType");
static_assert(offsetof(FControlRigComponentMappedElement, ElementName) == 0x4c, "Offset mismatch for FControlRigComponentMappedElement::ElementName");
static_assert(offsetof(FControlRigComponentMappedElement, Direction) == 0x50, "Offset mismatch for FControlRigComponentMappedElement::Direction");
static_assert(offsetof(FControlRigComponentMappedElement, Offset) == 0x60, "Offset mismatch for FControlRigComponentMappedElement::Offset");
static_assert(offsetof(FControlRigComponentMappedElement, Weight) == 0xc0, "Offset mismatch for FControlRigComponentMappedElement::Weight");
static_assert(offsetof(FControlRigComponentMappedElement, Space) == 0xc4, "Offset mismatch for FControlRigComponentMappedElement::Space");
static_assert(offsetof(FControlRigComponentMappedElement, SceneComponent) == 0xc8, "Offset mismatch for FControlRigComponentMappedElement::SceneComponent");
static_assert(offsetof(FControlRigComponentMappedElement, ElementIndex) == 0xd0, "Offset mismatch for FControlRigComponentMappedElement::ElementIndex");
static_assert(offsetof(FControlRigComponentMappedElement, SubIndex) == 0xd4, "Offset mismatch for FControlRigComponentMappedElement::SubIndex");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FControlRigComponentMappedComponent
{
    USceneComponent* Component; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName ElementName; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t ElementType; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Direction; // 0xd (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_e[0x2]; // 0xe (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FControlRigComponentMappedComponent) == 0x10, "Size mismatch for FControlRigComponentMappedComponent");
static_assert(offsetof(FControlRigComponentMappedComponent, Component) == 0x0, "Offset mismatch for FControlRigComponentMappedComponent::Component");
static_assert(offsetof(FControlRigComponentMappedComponent, ElementName) == 0x8, "Offset mismatch for FControlRigComponentMappedComponent::ElementName");
static_assert(offsetof(FControlRigComponentMappedComponent, ElementType) == 0xc, "Offset mismatch for FControlRigComponentMappedComponent::ElementType");
static_assert(offsetof(FControlRigComponentMappedComponent, Direction) == 0xd, "Offset mismatch for FControlRigComponentMappedComponent::Direction");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FControlRigComponentMappedBone
{
    FName Source; // 0x0 (Size: 0x4, Type: NameProperty)
    FName Target; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FControlRigComponentMappedBone) == 0x8, "Size mismatch for FControlRigComponentMappedBone");
static_assert(offsetof(FControlRigComponentMappedBone, Source) == 0x0, "Offset mismatch for FControlRigComponentMappedBone::Source");
static_assert(offsetof(FControlRigComponentMappedBone, Target) == 0x4, "Offset mismatch for FControlRigComponentMappedBone::Target");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FControlRigComponentMappedCurve
{
    FName Source; // 0x0 (Size: 0x4, Type: NameProperty)
    FName Target; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FControlRigComponentMappedCurve) == 0x8, "Size mismatch for FControlRigComponentMappedCurve");
static_assert(offsetof(FControlRigComponentMappedCurve, Source) == 0x0, "Offset mismatch for FControlRigComponentMappedCurve::Source");
static_assert(offsetof(FControlRigComponentMappedCurve, Target) == 0x4, "Offset mismatch for FControlRigComponentMappedCurve::Target");

// Size: 0x1a0 (Inherited: 0x0, Single: 0x1a0)
struct FControlShapeActorCreationParam
{
};

static_assert(sizeof(FControlShapeActorCreationParam) == 0x1a0, "Size mismatch for FControlShapeActorCreationParam");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FControlRigShapeDefinition
{
    FName ShapeName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UStaticMesh*> StaticMesh; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x30 (Size: 0x60, Type: StructProperty)
    uint8_t Pad_90[0x10]; // 0x90 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FControlRigShapeDefinition) == 0xa0, "Size mismatch for FControlRigShapeDefinition");
static_assert(offsetof(FControlRigShapeDefinition, ShapeName) == 0x0, "Offset mismatch for FControlRigShapeDefinition::ShapeName");
static_assert(offsetof(FControlRigShapeDefinition, StaticMesh) == 0x8, "Offset mismatch for FControlRigShapeDefinition::StaticMesh");
static_assert(offsetof(FControlRigShapeDefinition, Transform) == 0x30, "Offset mismatch for FControlRigShapeDefinition::Transform");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FControlRigReplayVariable
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    FName CPPType; // 0x4 (Size: 0x4, Type: NameProperty)
    FString Value; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FControlRigReplayVariable) == 0x18, "Size mismatch for FControlRigReplayVariable");
static_assert(offsetof(FControlRigReplayVariable, Name) == 0x0, "Offset mismatch for FControlRigReplayVariable::Name");
static_assert(offsetof(FControlRigReplayVariable, CPPType) == 0x4, "Offset mismatch for FControlRigReplayVariable::CPPType");
static_assert(offsetof(FControlRigReplayVariable, Value) == 0x8, "Offset mismatch for FControlRigReplayVariable::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSampleTrackHost
{
};

static_assert(sizeof(FSampleTrackHost) == 0x10, "Size mismatch for FSampleTrackHost");

// Size: 0x178 (Inherited: 0x10, Single: 0x168)
struct FControlRigReplayTracks : FSampleTrackHost
{
};

static_assert(sizeof(FControlRigReplayTracks) == 0x178, "Size mismatch for FControlRigReplayTracks");

// Size: 0x108 (Inherited: 0x0, Single: 0x108)
struct FControlRigTestDataFrame
{
    double AbsoluteTime; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double DeltaTime; // 0x8 (Size: 0x8, Type: DoubleProperty)
    TArray<FControlRigReplayVariable> Variables; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FRigPose Pose; // 0x20 (Size: 0x70, Type: StructProperty)
    TArray<char> MetaData; // 0x90 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_a0[0x68]; // 0xa0 (Size: 0x68, Type: PaddingProperty)
};

static_assert(sizeof(FControlRigTestDataFrame) == 0x108, "Size mismatch for FControlRigTestDataFrame");
static_assert(offsetof(FControlRigTestDataFrame, AbsoluteTime) == 0x0, "Offset mismatch for FControlRigTestDataFrame::AbsoluteTime");
static_assert(offsetof(FControlRigTestDataFrame, DeltaTime) == 0x8, "Offset mismatch for FControlRigTestDataFrame::DeltaTime");
static_assert(offsetof(FControlRigTestDataFrame, Variables) == 0x10, "Offset mismatch for FControlRigTestDataFrame::Variables");
static_assert(offsetof(FControlRigTestDataFrame, Pose) == 0x20, "Offset mismatch for FControlRigTestDataFrame::Pose");
static_assert(offsetof(FControlRigTestDataFrame, MetaData) == 0x90, "Offset mismatch for FControlRigTestDataFrame::MetaData");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FRigPose
{
    TArray<FRigPoseElement> Elements; // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t HierarchyTopologyVersion; // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t PoseHash; // 0x14 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_18[0x58]; // 0x18 (Size: 0x58, Type: PaddingProperty)
};

static_assert(sizeof(FRigPose) == 0x70, "Size mismatch for FRigPose");
static_assert(offsetof(FRigPose, Elements) == 0x0, "Offset mismatch for FRigPose::Elements");
static_assert(offsetof(FRigPose, HierarchyTopologyVersion) == 0x10, "Offset mismatch for FRigPose::HierarchyTopologyVersion");
static_assert(offsetof(FRigPose, PoseHash) == 0x14, "Offset mismatch for FRigPose::PoseHash");

// Size: 0x110 (Inherited: 0x0, Single: 0x110)
struct FRigPoseElement
{
    FCachedRigElement Index; // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform GlobalTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform LocalTransform; // 0x80 (Size: 0x60, Type: StructProperty)
    FVector PreferredEulerAngle; // 0xe0 (Size: 0x18, Type: StructProperty)
    FRigElementKey ActiveParent; // 0xf8 (Size: 0x8, Type: StructProperty)
    float CurveValue; // 0x100 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_104[0xc]; // 0x104 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FRigPoseElement) == 0x110, "Size mismatch for FRigPoseElement");
static_assert(offsetof(FRigPoseElement, Index) == 0x0, "Offset mismatch for FRigPoseElement::Index");
static_assert(offsetof(FRigPoseElement, GlobalTransform) == 0x20, "Offset mismatch for FRigPoseElement::GlobalTransform");
static_assert(offsetof(FRigPoseElement, LocalTransform) == 0x80, "Offset mismatch for FRigPoseElement::LocalTransform");
static_assert(offsetof(FRigPoseElement, PreferredEulerAngle) == 0xe0, "Offset mismatch for FRigPoseElement::PreferredEulerAngle");
static_assert(offsetof(FRigPoseElement, ActiveParent) == 0xf8, "Offset mismatch for FRigPoseElement::ActiveParent");
static_assert(offsetof(FRigPoseElement, CurveValue) == 0x100, "Offset mismatch for FRigPoseElement::CurveValue");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCachedRigElement
{
    FRigElementKey Key; // 0x0 (Size: 0x8, Type: StructProperty)
    uint16_t Index; // 0x8 (Size: 0x2, Type: UInt16Property)
    uint8_t Pad_a[0x2]; // 0xa (Size: 0x2, Type: PaddingProperty)
    int32_t ContainerVersion; // 0xc (Size: 0x4, Type: IntProperty)
    uint8_t Pad_10[0x8]; // 0x10 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FCachedRigElement) == 0x18, "Size mismatch for FCachedRigElement");
static_assert(offsetof(FCachedRigElement, Key) == 0x0, "Offset mismatch for FCachedRigElement::Key");
static_assert(offsetof(FCachedRigElement, Index) == 0x8, "Offset mismatch for FCachedRigElement::Index");
static_assert(offsetof(FCachedRigElement, ContainerVersion) == 0xc, "Offset mismatch for FCachedRigElement::ContainerVersion");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FControlRigValidationContext
{
};

static_assert(sizeof(FControlRigValidationContext) == 0x28, "Size mismatch for FControlRigValidationContext");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCRSimContainer
{
    float TimeStep; // 0x8 (Size: 0x4, Type: FloatProperty)
    float AccumulatedTime; // 0xc (Size: 0x4, Type: FloatProperty)
    float TimeLeftForStep; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCRSimContainer) == 0x18, "Size mismatch for FCRSimContainer");
static_assert(offsetof(FCRSimContainer, TimeStep) == 0x8, "Offset mismatch for FCRSimContainer::TimeStep");
static_assert(offsetof(FCRSimContainer, AccumulatedTime) == 0xc, "Offset mismatch for FCRSimContainer::AccumulatedTime");
static_assert(offsetof(FCRSimContainer, TimeLeftForStep) == 0x10, "Offset mismatch for FCRSimContainer::TimeLeftForStep");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCRSimLinearSpring
{
    int32_t SubjectA; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t SubjectB; // 0x4 (Size: 0x4, Type: IntProperty)
    float Coefficient; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Equilibrium; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FCRSimLinearSpring) == 0x10, "Size mismatch for FCRSimLinearSpring");
static_assert(offsetof(FCRSimLinearSpring, SubjectA) == 0x0, "Offset mismatch for FCRSimLinearSpring::SubjectA");
static_assert(offsetof(FCRSimLinearSpring, SubjectB) == 0x4, "Offset mismatch for FCRSimLinearSpring::SubjectB");
static_assert(offsetof(FCRSimLinearSpring, Coefficient) == 0x8, "Offset mismatch for FCRSimLinearSpring::Coefficient");
static_assert(offsetof(FCRSimLinearSpring, Equilibrium) == 0xc, "Offset mismatch for FCRSimLinearSpring::Equilibrium");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FCRSimPointConstraint
{
    uint8_t Type; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t SubjectA; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t SubjectB; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FVector DataA; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector DataB; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FCRSimPointConstraint) == 0x40, "Size mismatch for FCRSimPointConstraint");
static_assert(offsetof(FCRSimPointConstraint, Type) == 0x0, "Offset mismatch for FCRSimPointConstraint::Type");
static_assert(offsetof(FCRSimPointConstraint, SubjectA) == 0x4, "Offset mismatch for FCRSimPointConstraint::SubjectA");
static_assert(offsetof(FCRSimPointConstraint, SubjectB) == 0x8, "Offset mismatch for FCRSimPointConstraint::SubjectB");
static_assert(offsetof(FCRSimPointConstraint, DataA) == 0x10, "Offset mismatch for FCRSimPointConstraint::DataA");
static_assert(offsetof(FCRSimPointConstraint, DataB) == 0x28, "Offset mismatch for FCRSimPointConstraint::DataB");

// Size: 0x78 (Inherited: 0x18, Single: 0x60)
struct FCRSimPointContainer : FCRSimContainer
{
    TArray<FRigVMSimPoint> Points; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimLinearSpring> Springs; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimPointForce> Forces; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimSoftCollision> CollisionVolumes; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimPointConstraint> Constraints; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigVMSimPoint> PreviousStep; // 0x68 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCRSimPointContainer) == 0x78, "Size mismatch for FCRSimPointContainer");
static_assert(offsetof(FCRSimPointContainer, Points) == 0x18, "Offset mismatch for FCRSimPointContainer::Points");
static_assert(offsetof(FCRSimPointContainer, Springs) == 0x28, "Offset mismatch for FCRSimPointContainer::Springs");
static_assert(offsetof(FCRSimPointContainer, Forces) == 0x38, "Offset mismatch for FCRSimPointContainer::Forces");
static_assert(offsetof(FCRSimPointContainer, CollisionVolumes) == 0x48, "Offset mismatch for FCRSimPointContainer::CollisionVolumes");
static_assert(offsetof(FCRSimPointContainer, Constraints) == 0x58, "Offset mismatch for FCRSimPointContainer::Constraints");
static_assert(offsetof(FCRSimPointContainer, PreviousStep) == 0x68, "Offset mismatch for FCRSimPointContainer::PreviousStep");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FCRSimSoftCollision
{
    FTransform Transform; // 0x0 (Size: 0x60, Type: StructProperty)
    uint8_t ShapeType; // 0x60 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_61[0x3]; // 0x61 (Size: 0x3, Type: PaddingProperty)
    float MinimumDistance; // 0x64 (Size: 0x4, Type: FloatProperty)
    float MaximumDistance; // 0x68 (Size: 0x4, Type: FloatProperty)
    uint8_t FalloffType; // 0x6c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_6d[0x3]; // 0x6d (Size: 0x3, Type: PaddingProperty)
    float Coefficient; // 0x70 (Size: 0x4, Type: FloatProperty)
    bool bInverted; // 0x74 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_75[0xb]; // 0x75 (Size: 0xb, Type: PaddingProperty)
};

static_assert(sizeof(FCRSimSoftCollision) == 0x80, "Size mismatch for FCRSimSoftCollision");
static_assert(offsetof(FCRSimSoftCollision, Transform) == 0x0, "Offset mismatch for FCRSimSoftCollision::Transform");
static_assert(offsetof(FCRSimSoftCollision, ShapeType) == 0x60, "Offset mismatch for FCRSimSoftCollision::ShapeType");
static_assert(offsetof(FCRSimSoftCollision, MinimumDistance) == 0x64, "Offset mismatch for FCRSimSoftCollision::MinimumDistance");
static_assert(offsetof(FCRSimSoftCollision, MaximumDistance) == 0x68, "Offset mismatch for FCRSimSoftCollision::MaximumDistance");
static_assert(offsetof(FCRSimSoftCollision, FalloffType) == 0x6c, "Offset mismatch for FCRSimSoftCollision::FalloffType");
static_assert(offsetof(FCRSimSoftCollision, Coefficient) == 0x70, "Offset mismatch for FCRSimSoftCollision::Coefficient");
static_assert(offsetof(FCRSimSoftCollision, bInverted) == 0x74, "Offset mismatch for FCRSimSoftCollision::bInverted");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCRSimPointForce
{
    uint8_t ForceType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FVector Vector; // 0x8 (Size: 0x18, Type: StructProperty)
    float Coefficient; // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bNormalize; // 0x24 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_25[0x3]; // 0x25 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FCRSimPointForce) == 0x28, "Size mismatch for FCRSimPointForce");
static_assert(offsetof(FCRSimPointForce, ForceType) == 0x0, "Offset mismatch for FCRSimPointForce::ForceType");
static_assert(offsetof(FCRSimPointForce, Vector) == 0x8, "Offset mismatch for FCRSimPointForce::Vector");
static_assert(offsetof(FCRSimPointForce, Coefficient) == 0x20, "Offset mismatch for FCRSimPointForce::Coefficient");
static_assert(offsetof(FCRSimPointForce, bNormalize) == 0x24, "Offset mismatch for FCRSimPointForce::bNormalize");

// Size: 0x168 (Inherited: 0x0, Single: 0x168)
struct FRigModuleReference
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FString ShortName; // 0x8 (Size: 0x10, Type: StrProperty)
    bool bShortNameBasedOnPath; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    FString ParentPath; // 0x20 (Size: 0x10, Type: StrProperty)
    FName ParentModuleName; // 0x30 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    TSoftClassPtr Class; // 0x38 (Size: 0x20, Type: SoftClassProperty)
    TMap<FRigElementKey, FRigElementKey> Connections; // 0x58 (Size: 0x50, Type: MapProperty)
    TMap<FString, FName> ConfigValues; // 0xa8 (Size: 0x50, Type: MapProperty)
    TMap<FString, FName> Bindings; // 0xf8 (Size: 0x50, Type: MapProperty)
    FName PreviousName; // 0x148 (Size: 0x4, Type: NameProperty)
    FName PreviousParentName; // 0x14c (Size: 0x4, Type: NameProperty)
    uint8_t Pad_150[0x18]; // 0x150 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FRigModuleReference) == 0x168, "Size mismatch for FRigModuleReference");
static_assert(offsetof(FRigModuleReference, Name) == 0x0, "Offset mismatch for FRigModuleReference::Name");
static_assert(offsetof(FRigModuleReference, ShortName) == 0x8, "Offset mismatch for FRigModuleReference::ShortName");
static_assert(offsetof(FRigModuleReference, bShortNameBasedOnPath) == 0x18, "Offset mismatch for FRigModuleReference::bShortNameBasedOnPath");
static_assert(offsetof(FRigModuleReference, ParentPath) == 0x20, "Offset mismatch for FRigModuleReference::ParentPath");
static_assert(offsetof(FRigModuleReference, ParentModuleName) == 0x30, "Offset mismatch for FRigModuleReference::ParentModuleName");
static_assert(offsetof(FRigModuleReference, Class) == 0x38, "Offset mismatch for FRigModuleReference::Class");
static_assert(offsetof(FRigModuleReference, Connections) == 0x58, "Offset mismatch for FRigModuleReference::Connections");
static_assert(offsetof(FRigModuleReference, ConfigValues) == 0xa8, "Offset mismatch for FRigModuleReference::ConfigValues");
static_assert(offsetof(FRigModuleReference, Bindings) == 0xf8, "Offset mismatch for FRigModuleReference::Bindings");
static_assert(offsetof(FRigModuleReference, PreviousName) == 0x148, "Offset mismatch for FRigModuleReference::PreviousName");
static_assert(offsetof(FRigModuleReference, PreviousParentName) == 0x14c, "Offset mismatch for FRigModuleReference::PreviousParentName");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FModularRigSingleConnection
{
    FRigElementKey Connector; // 0x0 (Size: 0x8, Type: StructProperty)
    FRigElementKey Target; // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementKey> Targets; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FModularRigSingleConnection) == 0x20, "Size mismatch for FModularRigSingleConnection");
static_assert(offsetof(FModularRigSingleConnection, Connector) == 0x0, "Offset mismatch for FModularRigSingleConnection::Connector");
static_assert(offsetof(FModularRigSingleConnection, Target) == 0x8, "Offset mismatch for FModularRigSingleConnection::Target");
static_assert(offsetof(FModularRigSingleConnection, Targets) == 0x10, "Offset mismatch for FModularRigSingleConnection::Targets");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FModularRigConnections
{
    TArray<FModularRigSingleConnection> ConnectionList; // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_10[0x50]; // 0x10 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(FModularRigConnections) == 0x60, "Size mismatch for FModularRigConnections");
static_assert(offsetof(FModularRigConnections, ConnectionList) == 0x0, "Offset mismatch for FModularRigConnections::ConnectionList");

// Size: 0x100 (Inherited: 0x0, Single: 0x100)
struct FModularRigModel
{
    TArray<FRigModuleReference> Modules; // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_10[0x20]; // 0x10 (Size: 0x20, Type: PaddingProperty)
    FModularRigConnections Connections; // 0x30 (Size: 0x60, Type: StructProperty)
    UObject* Controller; // 0x90 (Size: 0x8, Type: ObjectProperty)
    TMap<FName, FRigHierarchyModulePath> PreviousModulePaths; // 0x98 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_e8[0x18]; // 0xe8 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FModularRigModel) == 0x100, "Size mismatch for FModularRigModel");
static_assert(offsetof(FModularRigModel, Modules) == 0x0, "Offset mismatch for FModularRigModel::Modules");
static_assert(offsetof(FModularRigModel, Connections) == 0x30, "Offset mismatch for FModularRigModel::Connections");
static_assert(offsetof(FModularRigModel, Controller) == 0x90, "Offset mismatch for FModularRigModel::Controller");
static_assert(offsetof(FModularRigModel, PreviousModulePaths) == 0x98, "Offset mismatch for FModularRigModel::PreviousModulePaths");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FRigHierarchyModulePath
{
    FString ModulePath; // 0x0 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_10[0x28]; // 0x10 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(FRigHierarchyModulePath) == 0x38, "Size mismatch for FRigHierarchyModulePath");
static_assert(offsetof(FRigHierarchyModulePath, ModulePath) == 0x0, "Offset mismatch for FRigHierarchyModulePath::ModulePath");

// Size: 0x140 (Inherited: 0x0, Single: 0x140)
struct FConstraintNodeData
{
    FTransform RelativeParent; // 0x0 (Size: 0x60, Type: StructProperty)
    FConstraintOffset ConstraintOffset; // 0x60 (Size: 0xc0, Type: StructProperty)
    FName LinkedNode; // 0x120 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_124[0x4]; // 0x124 (Size: 0x4, Type: PaddingProperty)
    TArray<FTransformConstraint> Constraints; // 0x128 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_138[0x8]; // 0x138 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FConstraintNodeData) == 0x140, "Size mismatch for FConstraintNodeData");
static_assert(offsetof(FConstraintNodeData, RelativeParent) == 0x0, "Offset mismatch for FConstraintNodeData::RelativeParent");
static_assert(offsetof(FConstraintNodeData, ConstraintOffset) == 0x60, "Offset mismatch for FConstraintNodeData::ConstraintOffset");
static_assert(offsetof(FConstraintNodeData, LinkedNode) == 0x120, "Offset mismatch for FConstraintNodeData::LinkedNode");
static_assert(offsetof(FConstraintNodeData, Constraints) == 0x128, "Offset mismatch for FConstraintNodeData::Constraints");

// Size: 0x88 (Inherited: 0x78, Single: 0x10)
struct FAnimationHierarchy : FNodeHierarchyWithUserData
{
    TArray<FConstraintNodeData> UserData; // 0x78 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FAnimationHierarchy) == 0x88, "Size mismatch for FAnimationHierarchy");
static_assert(offsetof(FAnimationHierarchy, UserData) == 0x78, "Offset mismatch for FAnimationHierarchy::UserData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigElement
{
    FName Name; // 0x8 (Size: 0x4, Type: NameProperty)
    int32_t Index; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FRigElement) == 0x10, "Size mismatch for FRigElement");
static_assert(offsetof(FRigElement, Name) == 0x8, "Offset mismatch for FRigElement::Name");
static_assert(offsetof(FRigElement, Index) == 0xc, "Offset mismatch for FRigElement::Index");

// Size: 0x160 (Inherited: 0x10, Single: 0x150)
struct FRigBone : FRigElement
{
    FName ParentName; // 0x10 (Size: 0x4, Type: NameProperty)
    int32_t ParentIndex; // 0x14 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform InitialTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform GlobalTransform; // 0x80 (Size: 0x60, Type: StructProperty)
    FTransform LocalTransform; // 0xe0 (Size: 0x60, Type: StructProperty)
    TArray<int32_t> Dependents; // 0x140 (Size: 0x10, Type: ArrayProperty)
    uint8_t Type; // 0x150 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_151[0xf]; // 0x151 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigBone) == 0x160, "Size mismatch for FRigBone");
static_assert(offsetof(FRigBone, ParentName) == 0x10, "Offset mismatch for FRigBone::ParentName");
static_assert(offsetof(FRigBone, ParentIndex) == 0x14, "Offset mismatch for FRigBone::ParentIndex");
static_assert(offsetof(FRigBone, InitialTransform) == 0x20, "Offset mismatch for FRigBone::InitialTransform");
static_assert(offsetof(FRigBone, GlobalTransform) == 0x80, "Offset mismatch for FRigBone::GlobalTransform");
static_assert(offsetof(FRigBone, LocalTransform) == 0xe0, "Offset mismatch for FRigBone::LocalTransform");
static_assert(offsetof(FRigBone, Dependents) == 0x140, "Offset mismatch for FRigBone::Dependents");
static_assert(offsetof(FRigBone, Type) == 0x150, "Offset mismatch for FRigBone::Type");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigBoneHierarchy
{
    TArray<FRigBone> Bones; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigBoneHierarchy) == 0x10, "Size mismatch for FRigBoneHierarchy");
static_assert(offsetof(FRigBoneHierarchy, Bones) == 0x0, "Offset mismatch for FRigBoneHierarchy::Bones");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FRigConnectionRule
{
};

static_assert(sizeof(FRigConnectionRule) == 0x8, "Size mismatch for FRigConnectionRule");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FRigAndConnectionRule : FRigConnectionRule
{
    TArray<FRigConnectionRuleStash> ChildRules; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigAndConnectionRule) == 0x18, "Size mismatch for FRigAndConnectionRule");
static_assert(offsetof(FRigAndConnectionRule, ChildRules) == 0x8, "Offset mismatch for FRigAndConnectionRule::ChildRules");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FRigOrConnectionRule : FRigConnectionRule
{
    TArray<FRigConnectionRuleStash> ChildRules; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigOrConnectionRule) == 0x18, "Size mismatch for FRigOrConnectionRule");
static_assert(offsetof(FRigOrConnectionRule, ChildRules) == 0x8, "Offset mismatch for FRigOrConnectionRule::ChildRules");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FRigTypeConnectionRule : FRigConnectionRule
{
    uint8_t ElementType; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigTypeConnectionRule) == 0x10, "Size mismatch for FRigTypeConnectionRule");
static_assert(offsetof(FRigTypeConnectionRule, ElementType) == 0x8, "Offset mismatch for FRigTypeConnectionRule::ElementType");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FRigTagConnectionRule : FRigConnectionRule
{
    FName Tag; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigTagConnectionRule) == 0x10, "Size mismatch for FRigTagConnectionRule");
static_assert(offsetof(FRigTagConnectionRule, Tag) == 0x8, "Offset mismatch for FRigTagConnectionRule::Tag");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FRigChildOfPrimaryConnectionRule : FRigConnectionRule
{
};

static_assert(sizeof(FRigChildOfPrimaryConnectionRule) == 0x8, "Size mismatch for FRigChildOfPrimaryConnectionRule");

// Size: 0x340 (Inherited: 0x10, Single: 0x330)
struct FRigControl : FRigElement
{
    uint8_t ControlType; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    FName DisplayName; // 0x14 (Size: 0x4, Type: NameProperty)
    FName ParentName; // 0x18 (Size: 0x4, Type: NameProperty)
    int32_t ParentIndex; // 0x1c (Size: 0x4, Type: IntProperty)
    FName SpaceName; // 0x20 (Size: 0x4, Type: NameProperty)
    int32_t SpaceIndex; // 0x24 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FTransform OffsetTransform; // 0x30 (Size: 0x60, Type: StructProperty)
    FRigControlValue InitialValue; // 0x90 (Size: 0x84, Type: StructProperty)
    FRigControlValue Value; // 0x114 (Size: 0x84, Type: StructProperty)
    uint8_t PrimaryAxis; // 0x198 (Size: 0x1, Type: EnumProperty)
    bool bIsCurve; // 0x199 (Size: 0x1, Type: BoolProperty)
    bool bAnimatable; // 0x19a (Size: 0x1, Type: BoolProperty)
    bool bLimitTranslation; // 0x19b (Size: 0x1, Type: BoolProperty)
    bool bLimitRotation; // 0x19c (Size: 0x1, Type: BoolProperty)
    bool bLimitScale; // 0x19d (Size: 0x1, Type: BoolProperty)
    bool bDrawLimits; // 0x19e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19f[0x1]; // 0x19f (Size: 0x1, Type: PaddingProperty)
    FRigControlValue MinimumValue; // 0x1a0 (Size: 0x84, Type: StructProperty)
    FRigControlValue MaximumValue; // 0x224 (Size: 0x84, Type: StructProperty)
    bool bGizmoEnabled; // 0x2a8 (Size: 0x1, Type: BoolProperty)
    bool bGizmoVisible; // 0x2a9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2aa[0x2]; // 0x2aa (Size: 0x2, Type: PaddingProperty)
    FName GizmoName; // 0x2ac (Size: 0x4, Type: NameProperty)
    FTransform GizmoTransform; // 0x2b0 (Size: 0x60, Type: StructProperty)
    FLinearColor GizmoColor; // 0x310 (Size: 0x10, Type: StructProperty)
    TArray<int32_t> Dependents; // 0x320 (Size: 0x10, Type: ArrayProperty)
    bool bIsTransientControl; // 0x330 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_331[0x7]; // 0x331 (Size: 0x7, Type: PaddingProperty)
    UEnum* ControlEnum; // 0x338 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FRigControl) == 0x340, "Size mismatch for FRigControl");
static_assert(offsetof(FRigControl, ControlType) == 0x10, "Offset mismatch for FRigControl::ControlType");
static_assert(offsetof(FRigControl, DisplayName) == 0x14, "Offset mismatch for FRigControl::DisplayName");
static_assert(offsetof(FRigControl, ParentName) == 0x18, "Offset mismatch for FRigControl::ParentName");
static_assert(offsetof(FRigControl, ParentIndex) == 0x1c, "Offset mismatch for FRigControl::ParentIndex");
static_assert(offsetof(FRigControl, SpaceName) == 0x20, "Offset mismatch for FRigControl::SpaceName");
static_assert(offsetof(FRigControl, SpaceIndex) == 0x24, "Offset mismatch for FRigControl::SpaceIndex");
static_assert(offsetof(FRigControl, OffsetTransform) == 0x30, "Offset mismatch for FRigControl::OffsetTransform");
static_assert(offsetof(FRigControl, InitialValue) == 0x90, "Offset mismatch for FRigControl::InitialValue");
static_assert(offsetof(FRigControl, Value) == 0x114, "Offset mismatch for FRigControl::Value");
static_assert(offsetof(FRigControl, PrimaryAxis) == 0x198, "Offset mismatch for FRigControl::PrimaryAxis");
static_assert(offsetof(FRigControl, bIsCurve) == 0x199, "Offset mismatch for FRigControl::bIsCurve");
static_assert(offsetof(FRigControl, bAnimatable) == 0x19a, "Offset mismatch for FRigControl::bAnimatable");
static_assert(offsetof(FRigControl, bLimitTranslation) == 0x19b, "Offset mismatch for FRigControl::bLimitTranslation");
static_assert(offsetof(FRigControl, bLimitRotation) == 0x19c, "Offset mismatch for FRigControl::bLimitRotation");
static_assert(offsetof(FRigControl, bLimitScale) == 0x19d, "Offset mismatch for FRigControl::bLimitScale");
static_assert(offsetof(FRigControl, bDrawLimits) == 0x19e, "Offset mismatch for FRigControl::bDrawLimits");
static_assert(offsetof(FRigControl, MinimumValue) == 0x1a0, "Offset mismatch for FRigControl::MinimumValue");
static_assert(offsetof(FRigControl, MaximumValue) == 0x224, "Offset mismatch for FRigControl::MaximumValue");
static_assert(offsetof(FRigControl, bGizmoEnabled) == 0x2a8, "Offset mismatch for FRigControl::bGizmoEnabled");
static_assert(offsetof(FRigControl, bGizmoVisible) == 0x2a9, "Offset mismatch for FRigControl::bGizmoVisible");
static_assert(offsetof(FRigControl, GizmoName) == 0x2ac, "Offset mismatch for FRigControl::GizmoName");
static_assert(offsetof(FRigControl, GizmoTransform) == 0x2b0, "Offset mismatch for FRigControl::GizmoTransform");
static_assert(offsetof(FRigControl, GizmoColor) == 0x310, "Offset mismatch for FRigControl::GizmoColor");
static_assert(offsetof(FRigControl, Dependents) == 0x320, "Offset mismatch for FRigControl::Dependents");
static_assert(offsetof(FRigControl, bIsTransientControl) == 0x330, "Offset mismatch for FRigControl::bIsTransientControl");
static_assert(offsetof(FRigControl, ControlEnum) == 0x338, "Offset mismatch for FRigControl::ControlEnum");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigControlHierarchy
{
    TArray<FRigControl> Controls; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigControlHierarchy) == 0x10, "Size mismatch for FRigControlHierarchy");
static_assert(offsetof(FRigControlHierarchy, Controls) == 0x0, "Offset mismatch for FRigControlHierarchy::Controls");

// Size: 0x18 (Inherited: 0x10, Single: 0x8)
struct FRigCurve : FRigElement
{
    float Value; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigCurve) == 0x18, "Size mismatch for FRigCurve");
static_assert(offsetof(FRigCurve, Value) == 0x10, "Offset mismatch for FRigCurve::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigCurveContainer
{
    TArray<FRigCurve> Curves; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigCurveContainer) == 0x10, "Size mismatch for FRigCurveContainer");
static_assert(offsetof(FRigCurveContainer, Curves) == 0x0, "Offset mismatch for FRigCurveContainer::Curves");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCachedRigComponent
{
    FCachedRigElement CachedElement; // 0x0 (Size: 0x18, Type: StructProperty)
    FName Name; // 0x18 (Size: 0x4, Type: NameProperty)
    uint16_t Index; // 0x1c (Size: 0x2, Type: UInt16Property)
    uint8_t Pad_1e[0xa]; // 0x1e (Size: 0xa, Type: PaddingProperty)
};

static_assert(sizeof(FCachedRigComponent) == 0x28, "Size mismatch for FCachedRigComponent");
static_assert(offsetof(FCachedRigComponent, CachedElement) == 0x0, "Offset mismatch for FCachedRigComponent::CachedElement");
static_assert(offsetof(FCachedRigComponent, Name) == 0x18, "Offset mismatch for FCachedRigComponent::Name");
static_assert(offsetof(FCachedRigComponent, Index) == 0x1c, "Offset mismatch for FCachedRigComponent::Index");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FRigBaseComponent
{
};

static_assert(sizeof(FRigBaseComponent) == 0x40, "Size mismatch for FRigBaseComponent");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FRigHierarchyContainer
{
    FRigBoneHierarchy BoneHierarchy; // 0x0 (Size: 0x10, Type: StructProperty)
    FRigSpaceHierarchy SpaceHierarchy; // 0x10 (Size: 0x10, Type: StructProperty)
    FRigControlHierarchy ControlHierarchy; // 0x20 (Size: 0x10, Type: StructProperty)
    FRigCurveContainer CurveContainer; // 0x30 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigHierarchyContainer) == 0x40, "Size mismatch for FRigHierarchyContainer");
static_assert(offsetof(FRigHierarchyContainer, BoneHierarchy) == 0x0, "Offset mismatch for FRigHierarchyContainer::BoneHierarchy");
static_assert(offsetof(FRigHierarchyContainer, SpaceHierarchy) == 0x10, "Offset mismatch for FRigHierarchyContainer::SpaceHierarchy");
static_assert(offsetof(FRigHierarchyContainer, ControlHierarchy) == 0x20, "Offset mismatch for FRigHierarchyContainer::ControlHierarchy");
static_assert(offsetof(FRigHierarchyContainer, CurveContainer) == 0x30, "Offset mismatch for FRigHierarchyContainer::CurveContainer");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigSpaceHierarchy
{
    TArray<FRigSpace> Spaces; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigSpaceHierarchy) == 0x10, "Size mismatch for FRigSpaceHierarchy");
static_assert(offsetof(FRigSpaceHierarchy, Spaces) == 0x0, "Offset mismatch for FRigSpaceHierarchy::Spaces");

// Size: 0xe0 (Inherited: 0x10, Single: 0xd0)
struct FRigSpace : FRigElement
{
    uint8_t SpaceType; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    FName ParentName; // 0x14 (Size: 0x4, Type: NameProperty)
    int32_t ParentIndex; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FTransform InitialTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform LocalTransform; // 0x80 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigSpace) == 0xe0, "Size mismatch for FRigSpace");
static_assert(offsetof(FRigSpace, SpaceType) == 0x10, "Offset mismatch for FRigSpace::SpaceType");
static_assert(offsetof(FRigSpace, ParentName) == 0x14, "Offset mismatch for FRigSpace::ParentName");
static_assert(offsetof(FRigSpace, ParentIndex) == 0x18, "Offset mismatch for FRigSpace::ParentIndex");
static_assert(offsetof(FRigSpace, InitialTransform) == 0x20, "Offset mismatch for FRigSpace::InitialTransform");
static_assert(offsetof(FRigSpace, LocalTransform) == 0x80, "Offset mismatch for FRigSpace::LocalTransform");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FRigHierarchyRef
{
};

static_assert(sizeof(FRigHierarchyRef) == 0x1, "Size mismatch for FRigHierarchyRef");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FRigControlModifiedContext
{
};

static_assert(sizeof(FRigControlModifiedContext) == 0x14, "Size mismatch for FRigControlModifiedContext");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FRigComponentKey
{
    FRigElementKey ElementKey; // 0x0 (Size: 0x8, Type: StructProperty)
    FName Name; // 0x8 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FRigComponentKey) == 0xc, "Size mismatch for FRigComponentKey");
static_assert(offsetof(FRigComponentKey, ElementKey) == 0x0, "Offset mismatch for FRigComponentKey::ElementKey");
static_assert(offsetof(FRigComponentKey, Name) == 0x8, "Offset mismatch for FRigComponentKey::Name");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FRigHierarchyKey
{
};

static_assert(sizeof(FRigHierarchyKey) == 0x1c, "Size mismatch for FRigHierarchyKey");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigElementKeyCollection
{
    TArray<FRigElementKey> Keys; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigElementKeyCollection) == 0x10, "Size mismatch for FRigElementKeyCollection");
static_assert(offsetof(FRigElementKeyCollection, Keys) == 0x0, "Offset mismatch for FRigElementKeyCollection::Keys");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FRigEventContext
{
};

static_assert(sizeof(FRigEventContext) == 0x20, "Size mismatch for FRigEventContext");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FRigElementResolveResult
{
    FRigElementKey Key; // 0x0 (Size: 0x8, Type: StructProperty)
    uint8_t State; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    FText Message; // 0x10 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FRigElementResolveResult) == 0x20, "Size mismatch for FRigElementResolveResult");
static_assert(offsetof(FRigElementResolveResult, Key) == 0x0, "Offset mismatch for FRigElementResolveResult::Key");
static_assert(offsetof(FRigElementResolveResult, State) == 0x8, "Offset mismatch for FRigElementResolveResult::State");
static_assert(offsetof(FRigElementResolveResult, Message) == 0x10, "Offset mismatch for FRigElementResolveResult::Message");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FModularRigResolveResult
{
    FRigElementKey Connector; // 0x0 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementResolveResult> Matches; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigElementResolveResult> Excluded; // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t State; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    FText Message; // 0x30 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FModularRigResolveResult) == 0x40, "Size mismatch for FModularRigResolveResult");
static_assert(offsetof(FModularRigResolveResult, Connector) == 0x0, "Offset mismatch for FModularRigResolveResult::Connector");
static_assert(offsetof(FModularRigResolveResult, Matches) == 0x8, "Offset mismatch for FModularRigResolveResult::Matches");
static_assert(offsetof(FModularRigResolveResult, Excluded) == 0x18, "Offset mismatch for FModularRigResolveResult::Excluded");
static_assert(offsetof(FModularRigResolveResult, State) == 0x28, "Offset mismatch for FModularRigResolveResult::State");
static_assert(offsetof(FModularRigResolveResult, Message) == 0x30, "Offset mismatch for FModularRigResolveResult::Message");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigTransformDirtyState
{
};

static_assert(sizeof(FRigTransformDirtyState) == 0x10, "Size mismatch for FRigTransformDirtyState");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FRigLocalAndGlobalDirtyState
{
    FRigTransformDirtyState Global; // 0x0 (Size: 0x10, Type: StructProperty)
    FRigTransformDirtyState Local; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigLocalAndGlobalDirtyState) == 0x20, "Size mismatch for FRigLocalAndGlobalDirtyState");
static_assert(offsetof(FRigLocalAndGlobalDirtyState, Global) == 0x0, "Offset mismatch for FRigLocalAndGlobalDirtyState::Global");
static_assert(offsetof(FRigLocalAndGlobalDirtyState, Local) == 0x10, "Offset mismatch for FRigLocalAndGlobalDirtyState::Local");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FRigCurrentAndInitialDirtyState
{
    FRigLocalAndGlobalDirtyState Current; // 0x0 (Size: 0x20, Type: StructProperty)
    FRigLocalAndGlobalDirtyState Initial; // 0x20 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigCurrentAndInitialDirtyState) == 0x40, "Size mismatch for FRigCurrentAndInitialDirtyState");
static_assert(offsetof(FRigCurrentAndInitialDirtyState, Current) == 0x0, "Offset mismatch for FRigCurrentAndInitialDirtyState::Current");
static_assert(offsetof(FRigCurrentAndInitialDirtyState, Initial) == 0x20, "Offset mismatch for FRigCurrentAndInitialDirtyState::Initial");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigComputedTransform
{
};

static_assert(sizeof(FRigComputedTransform) == 0x10, "Size mismatch for FRigComputedTransform");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FRigLocalAndGlobalTransform
{
    FRigComputedTransform Local; // 0x0 (Size: 0x10, Type: StructProperty)
    FRigComputedTransform Global; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigLocalAndGlobalTransform) == 0x20, "Size mismatch for FRigLocalAndGlobalTransform");
static_assert(offsetof(FRigLocalAndGlobalTransform, Local) == 0x0, "Offset mismatch for FRigLocalAndGlobalTransform::Local");
static_assert(offsetof(FRigLocalAndGlobalTransform, Global) == 0x10, "Offset mismatch for FRigLocalAndGlobalTransform::Global");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FRigCurrentAndInitialTransform
{
    FRigLocalAndGlobalTransform Current; // 0x0 (Size: 0x20, Type: StructProperty)
    FRigLocalAndGlobalTransform Initial; // 0x20 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigCurrentAndInitialTransform) == 0x40, "Size mismatch for FRigCurrentAndInitialTransform");
static_assert(offsetof(FRigCurrentAndInitialTransform, Current) == 0x0, "Offset mismatch for FRigCurrentAndInitialTransform::Current");
static_assert(offsetof(FRigCurrentAndInitialTransform, Initial) == 0x20, "Offset mismatch for FRigCurrentAndInitialTransform::Initial");

// Size: 0x120 (Inherited: 0x170, Single: 0xffffffb0)
struct FRigSingleParentElement : FRigTransformElement
{
};

static_assert(sizeof(FRigSingleParentElement) == 0x120, "Size mismatch for FRigSingleParentElement");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FRigElementWeight
{
    float Location; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Rotation; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigElementWeight) == 0xc, "Size mismatch for FRigElementWeight");
static_assert(offsetof(FRigElementWeight, Location) == 0x0, "Offset mismatch for FRigElementWeight::Location");
static_assert(offsetof(FRigElementWeight, Rotation) == 0x4, "Offset mismatch for FRigElementWeight::Rotation");
static_assert(offsetof(FRigElementWeight, Scale) == 0x8, "Offset mismatch for FRigElementWeight::Scale");

// Size: 0xa0 (Inherited: 0x0, Single: 0xa0)
struct FRigElementParentConstraint
{
};

static_assert(sizeof(FRigElementParentConstraint) == 0xa0, "Size mismatch for FRigElementParentConstraint");

// Size: 0x128 (Inherited: 0x290, Single: 0xfffffe98)
struct FRigBoneElement : FRigSingleParentElement
{
    uint8_t BoneType; // 0x120 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_121[0x7]; // 0x121 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigBoneElement) == 0x128, "Size mismatch for FRigBoneElement");
static_assert(offsetof(FRigBoneElement, BoneType) == 0x120, "Offset mismatch for FRigBoneElement::BoneType");

// Size: 0x230 (Inherited: 0x3a0, Single: 0xfffffe90)
struct FRigNullElement : FRigMultiParentElement
{
};

static_assert(sizeof(FRigNullElement) == 0x230, "Size mismatch for FRigNullElement");

// Size: 0x68 (Inherited: 0x58, Single: 0x10)
struct FRigCurveElement : FRigBaseElement
{
};

static_assert(sizeof(FRigCurveElement) == 0x68, "Size mismatch for FRigCurveElement");

// Size: 0x130 (Inherited: 0x290, Single: 0xfffffea0)
struct FRigReferenceElement : FRigSingleParentElement
{
};

static_assert(sizeof(FRigReferenceElement) == 0x130, "Size mismatch for FRigReferenceElement");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FRigConnectorState
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    FRigElementKey ResolvedTarget; // 0x4 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FRigConnectorSettings Settings; // 0x10 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FRigConnectorState) == 0x38, "Size mismatch for FRigConnectorState");
static_assert(offsetof(FRigConnectorState, Name) == 0x0, "Offset mismatch for FRigConnectorState::Name");
static_assert(offsetof(FRigConnectorState, ResolvedTarget) == 0x4, "Offset mismatch for FRigConnectorState::ResolvedTarget");
static_assert(offsetof(FRigConnectorState, Settings) == 0x10, "Offset mismatch for FRigConnectorState::Settings");

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
struct FRigConnectorElement : FRigBaseElement
{
    FRigConnectorSettings Settings; // 0x58 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FRigConnectorElement) == 0x80, "Size mismatch for FRigConnectorElement");
static_assert(offsetof(FRigConnectorElement, Settings) == 0x58, "Offset mismatch for FRigConnectorElement::Settings");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FRigSocketState
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    FRigElementKey Parent; // 0x4 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FTransform InitialLocalTransform; // 0x10 (Size: 0x60, Type: StructProperty)
    FLinearColor Color; // 0x70 (Size: 0x10, Type: StructProperty)
    FString Description; // 0x80 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FRigSocketState) == 0x90, "Size mismatch for FRigSocketState");
static_assert(offsetof(FRigSocketState, Name) == 0x0, "Offset mismatch for FRigSocketState::Name");
static_assert(offsetof(FRigSocketState, Parent) == 0x4, "Offset mismatch for FRigSocketState::Parent");
static_assert(offsetof(FRigSocketState, InitialLocalTransform) == 0x10, "Offset mismatch for FRigSocketState::InitialLocalTransform");
static_assert(offsetof(FRigSocketState, Color) == 0x70, "Offset mismatch for FRigSocketState::Color");
static_assert(offsetof(FRigSocketState, Description) == 0x80, "Offset mismatch for FRigSocketState::Description");

// Size: 0x120 (Inherited: 0x290, Single: 0xfffffe90)
struct FRigSocketElement : FRigSingleParentElement
{
};

static_assert(sizeof(FRigSocketElement) == 0x120, "Size mismatch for FRigSocketElement");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FRigHierarchyCopyPasteContentPerElement
{
    FRigElementKey Key; // 0x0 (Size: 0x8, Type: StructProperty)
    FString Content; // 0x8 (Size: 0x10, Type: StrProperty)
    TArray<FRigElementKeyWithLabel> Parents; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigElementWeight> ParentWeights; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> Poses; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<bool> DirtyStates; // 0x48 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigHierarchyCopyPasteContentPerElement) == 0x58, "Size mismatch for FRigHierarchyCopyPasteContentPerElement");
static_assert(offsetof(FRigHierarchyCopyPasteContentPerElement, Key) == 0x0, "Offset mismatch for FRigHierarchyCopyPasteContentPerElement::Key");
static_assert(offsetof(FRigHierarchyCopyPasteContentPerElement, Content) == 0x8, "Offset mismatch for FRigHierarchyCopyPasteContentPerElement::Content");
static_assert(offsetof(FRigHierarchyCopyPasteContentPerElement, Parents) == 0x18, "Offset mismatch for FRigHierarchyCopyPasteContentPerElement::Parents");
static_assert(offsetof(FRigHierarchyCopyPasteContentPerElement, ParentWeights) == 0x28, "Offset mismatch for FRigHierarchyCopyPasteContentPerElement::ParentWeights");
static_assert(offsetof(FRigHierarchyCopyPasteContentPerElement, Poses) == 0x38, "Offset mismatch for FRigHierarchyCopyPasteContentPerElement::Poses");
static_assert(offsetof(FRigHierarchyCopyPasteContentPerElement, DirtyStates) == 0x48, "Offset mismatch for FRigHierarchyCopyPasteContentPerElement::DirtyStates");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FRigHierarchyCopyPasteContent
{
    TArray<FRigHierarchyCopyPasteContentPerElement> Elements; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<ERigElementType> Types; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> Contents; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> LocalTransforms; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> GlobalTransforms; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigHierarchyCopyPasteContent) == 0x50, "Size mismatch for FRigHierarchyCopyPasteContent");
static_assert(offsetof(FRigHierarchyCopyPasteContent, Elements) == 0x0, "Offset mismatch for FRigHierarchyCopyPasteContent::Elements");
static_assert(offsetof(FRigHierarchyCopyPasteContent, Types) == 0x10, "Offset mismatch for FRigHierarchyCopyPasteContent::Types");
static_assert(offsetof(FRigHierarchyCopyPasteContent, Contents) == 0x20, "Offset mismatch for FRigHierarchyCopyPasteContent::Contents");
static_assert(offsetof(FRigHierarchyCopyPasteContent, LocalTransforms) == 0x30, "Offset mismatch for FRigHierarchyCopyPasteContent::LocalTransforms");
static_assert(offsetof(FRigHierarchyCopyPasteContent, GlobalTransforms) == 0x40, "Offset mismatch for FRigHierarchyCopyPasteContent::GlobalTransforms");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FRigBaseMetadata
{
    FName Name; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Type; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0xb]; // 0xd (Size: 0xb, Type: PaddingProperty)
};

static_assert(sizeof(FRigBaseMetadata) == 0x18, "Size mismatch for FRigBaseMetadata");
static_assert(offsetof(FRigBaseMetadata, Name) == 0x8, "Offset mismatch for FRigBaseMetadata::Name");
static_assert(offsetof(FRigBaseMetadata, Type) == 0xc, "Offset mismatch for FRigBaseMetadata::Type");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigBoolMetadata : FRigBaseMetadata
{
    bool Value; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigBoolMetadata) == 0x20, "Size mismatch for FRigBoolMetadata");
static_assert(offsetof(FRigBoolMetadata, Value) == 0x18, "Offset mismatch for FRigBoolMetadata::Value");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigBoolArrayMetadata : FRigBaseMetadata
{
    TArray<bool> Value; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigBoolArrayMetadata) == 0x28, "Size mismatch for FRigBoolArrayMetadata");
static_assert(offsetof(FRigBoolArrayMetadata, Value) == 0x18, "Offset mismatch for FRigBoolArrayMetadata::Value");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigFloatMetadata : FRigBaseMetadata
{
    float Value; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigFloatMetadata) == 0x20, "Size mismatch for FRigFloatMetadata");
static_assert(offsetof(FRigFloatMetadata, Value) == 0x18, "Offset mismatch for FRigFloatMetadata::Value");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigFloatArrayMetadata : FRigBaseMetadata
{
    TArray<float> Value; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigFloatArrayMetadata) == 0x28, "Size mismatch for FRigFloatArrayMetadata");
static_assert(offsetof(FRigFloatArrayMetadata, Value) == 0x18, "Offset mismatch for FRigFloatArrayMetadata::Value");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigInt32Metadata : FRigBaseMetadata
{
    int32_t Value; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigInt32Metadata) == 0x20, "Size mismatch for FRigInt32Metadata");
static_assert(offsetof(FRigInt32Metadata, Value) == 0x18, "Offset mismatch for FRigInt32Metadata::Value");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigInt32ArrayMetadata : FRigBaseMetadata
{
    TArray<int32_t> Value; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigInt32ArrayMetadata) == 0x28, "Size mismatch for FRigInt32ArrayMetadata");
static_assert(offsetof(FRigInt32ArrayMetadata, Value) == 0x18, "Offset mismatch for FRigInt32ArrayMetadata::Value");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigNameMetadata : FRigBaseMetadata
{
    FName Value; // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigNameMetadata) == 0x20, "Size mismatch for FRigNameMetadata");
static_assert(offsetof(FRigNameMetadata, Value) == 0x18, "Offset mismatch for FRigNameMetadata::Value");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigNameArrayMetadata : FRigBaseMetadata
{
    TArray<FName> Value; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigNameArrayMetadata) == 0x28, "Size mismatch for FRigNameArrayMetadata");
static_assert(offsetof(FRigNameArrayMetadata, Value) == 0x18, "Offset mismatch for FRigNameArrayMetadata::Value");

// Size: 0x30 (Inherited: 0x18, Single: 0x18)
struct FRigVectorMetadata : FRigBaseMetadata
{
    FVector Value; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigVectorMetadata) == 0x30, "Size mismatch for FRigVectorMetadata");
static_assert(offsetof(FRigVectorMetadata, Value) == 0x18, "Offset mismatch for FRigVectorMetadata::Value");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigVectorArrayMetadata : FRigBaseMetadata
{
    TArray<FVector> Value; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigVectorArrayMetadata) == 0x28, "Size mismatch for FRigVectorArrayMetadata");
static_assert(offsetof(FRigVectorArrayMetadata, Value) == 0x18, "Offset mismatch for FRigVectorArrayMetadata::Value");

// Size: 0x30 (Inherited: 0x18, Single: 0x18)
struct FRigRotatorMetadata : FRigBaseMetadata
{
    FRotator Value; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigRotatorMetadata) == 0x30, "Size mismatch for FRigRotatorMetadata");
static_assert(offsetof(FRigRotatorMetadata, Value) == 0x18, "Offset mismatch for FRigRotatorMetadata::Value");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigRotatorArrayMetadata : FRigBaseMetadata
{
    TArray<FRotator> Value; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigRotatorArrayMetadata) == 0x28, "Size mismatch for FRigRotatorArrayMetadata");
static_assert(offsetof(FRigRotatorArrayMetadata, Value) == 0x18, "Offset mismatch for FRigRotatorArrayMetadata::Value");

// Size: 0x40 (Inherited: 0x18, Single: 0x28)
struct FRigQuatMetadata : FRigBaseMetadata
{
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FQuat Value; // 0x20 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigQuatMetadata) == 0x40, "Size mismatch for FRigQuatMetadata");
static_assert(offsetof(FRigQuatMetadata, Value) == 0x20, "Offset mismatch for FRigQuatMetadata::Value");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigQuatArrayMetadata : FRigBaseMetadata
{
    TArray<FQuat> Value; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigQuatArrayMetadata) == 0x28, "Size mismatch for FRigQuatArrayMetadata");
static_assert(offsetof(FRigQuatArrayMetadata, Value) == 0x18, "Offset mismatch for FRigQuatArrayMetadata::Value");

// Size: 0x80 (Inherited: 0x18, Single: 0x68)
struct FRigTransformMetadata : FRigBaseMetadata
{
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform Value; // 0x20 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigTransformMetadata) == 0x80, "Size mismatch for FRigTransformMetadata");
static_assert(offsetof(FRigTransformMetadata, Value) == 0x20, "Offset mismatch for FRigTransformMetadata::Value");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigTransformArrayMetadata : FRigBaseMetadata
{
    TArray<FTransform> Value; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigTransformArrayMetadata) == 0x28, "Size mismatch for FRigTransformArrayMetadata");
static_assert(offsetof(FRigTransformArrayMetadata, Value) == 0x18, "Offset mismatch for FRigTransformArrayMetadata::Value");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigLinearColorMetadata : FRigBaseMetadata
{
    FLinearColor Value; // 0x18 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigLinearColorMetadata) == 0x28, "Size mismatch for FRigLinearColorMetadata");
static_assert(offsetof(FRigLinearColorMetadata, Value) == 0x18, "Offset mismatch for FRigLinearColorMetadata::Value");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigLinearColorArrayMetadata : FRigBaseMetadata
{
    TArray<FLinearColor> Value; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigLinearColorArrayMetadata) == 0x28, "Size mismatch for FRigLinearColorArrayMetadata");
static_assert(offsetof(FRigLinearColorArrayMetadata, Value) == 0x18, "Offset mismatch for FRigLinearColorArrayMetadata::Value");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigElementKeyMetadata : FRigBaseMetadata
{
    FRigElementKey Value; // 0x18 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigElementKeyMetadata) == 0x20, "Size mismatch for FRigElementKeyMetadata");
static_assert(offsetof(FRigElementKeyMetadata, Value) == 0x18, "Offset mismatch for FRigElementKeyMetadata::Value");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigElementKeyArrayMetadata : FRigBaseMetadata
{
    TArray<FRigElementKey> Value; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigElementKeyArrayMetadata) == 0x28, "Size mismatch for FRigElementKeyArrayMetadata");
static_assert(offsetof(FRigElementKeyArrayMetadata, Value) == 0x18, "Offset mismatch for FRigElementKeyArrayMetadata::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigInfluenceEntryModifier
{
    TArray<FRigElementKey> AffectedList; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigInfluenceEntryModifier) == 0x10, "Size mismatch for FRigInfluenceEntryModifier");
static_assert(offsetof(FRigInfluenceEntryModifier, AffectedList) == 0x0, "Offset mismatch for FRigInfluenceEntryModifier::AffectedList");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FModularRigSettings
{
    bool bAutoResolve; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FModularRigSettings) == 0x1, "Size mismatch for FModularRigSettings");
static_assert(offsetof(FModularRigSettings, bAutoResolve) == 0x0, "Offset mismatch for FModularRigSettings::bAutoResolve");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FRigModuleDescription
{
    FSoftObjectPath Path; // 0x0 (Size: 0x18, Type: StructProperty)
    FRigModuleSettings Settings; // 0x18 (Size: 0x78, Type: StructProperty)
};

static_assert(sizeof(FRigModuleDescription) == 0x90, "Size mismatch for FRigModuleDescription");
static_assert(offsetof(FRigModuleDescription, Path) == 0x0, "Offset mismatch for FRigModuleDescription::Path");
static_assert(offsetof(FRigModuleDescription, Settings) == 0x18, "Offset mismatch for FRigModuleDescription::Settings");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FRigPhysicsSimulationBase
{
};

static_assert(sizeof(FRigPhysicsSimulationBase) == 0x20, "Size mismatch for FRigPhysicsSimulationBase");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigPhysicsSolverID
{
    FGuid Guid; // 0x0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigPhysicsSolverID) == 0x10, "Size mismatch for FRigPhysicsSolverID");
static_assert(offsetof(FRigPhysicsSolverID, Guid) == 0x0, "Offset mismatch for FRigPhysicsSolverID::Guid");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FRigPhysicsSolverDescription
{
    FRigPhysicsSolverID ID; // 0x0 (Size: 0x10, Type: StructProperty)
    FName Name; // 0x10 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FRigPhysicsSolverDescription) == 0x14, "Size mismatch for FRigPhysicsSolverDescription");
static_assert(offsetof(FRigPhysicsSolverDescription, ID) == 0x0, "Offset mismatch for FRigPhysicsSolverDescription::ID");
static_assert(offsetof(FRigPhysicsSolverDescription, Name) == 0x10, "Offset mismatch for FRigPhysicsSolverDescription::Name");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FAnimNode_ControlRigInputPose : FAnimNode_Base
{
    FPoseLink InputPose; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FAnimNode_ControlRigInputPose) == 0x30, "Size mismatch for FAnimNode_ControlRigInputPose");
static_assert(offsetof(FAnimNode_ControlRigInputPose, InputPose) == 0x10, "Offset mismatch for FAnimNode_ControlRigInputPose::InputPose");

// Size: 0x840 (Inherited: 0x7a0, Single: 0xa0)
struct FControlRigLayerInstanceProxy : FAnimInstanceProxy
{
};

static_assert(sizeof(FControlRigLayerInstanceProxy) == 0x840, "Size mismatch for FControlRigLayerInstanceProxy");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FControlRigSequenceObjectReference
{
    UClass* ControlRigClass; // 0x0 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FControlRigSequenceObjectReference) == 0x8, "Size mismatch for FControlRigSequenceObjectReference");
static_assert(offsetof(FControlRigSequenceObjectReference, ControlRigClass) == 0x0, "Offset mismatch for FControlRigSequenceObjectReference::ControlRigClass");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FControlRigSequenceObjectReferences
{
    TArray<FControlRigSequenceObjectReference> Array; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FControlRigSequenceObjectReferences) == 0x10, "Size mismatch for FControlRigSequenceObjectReferences");
static_assert(offsetof(FControlRigSequenceObjectReferences, Array) == 0x0, "Offset mismatch for FControlRigSequenceObjectReferences::Array");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FControlRigSequenceObjectReferenceMap
{
    TArray<FGuid> BindingIds; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FControlRigSequenceObjectReferences> References; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FControlRigSequenceObjectReferenceMap) == 0x20, "Size mismatch for FControlRigSequenceObjectReferenceMap");
static_assert(offsetof(FControlRigSequenceObjectReferenceMap, BindingIds) == 0x0, "Offset mismatch for FControlRigSequenceObjectReferenceMap::BindingIds");
static_assert(offsetof(FControlRigSequenceObjectReferenceMap, References) == 0x10, "Offset mismatch for FControlRigSequenceObjectReferenceMap::References");

// Size: 0x118 (Inherited: 0x4, Single: 0x114)
struct FEnumParameterNameAndCurve : FBaseParameterNameAndValue
{
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FMovieSceneByteChannel ParameterCurve; // 0x8 (Size: 0x110, Type: StructProperty)
};

static_assert(sizeof(FEnumParameterNameAndCurve) == 0x118, "Size mismatch for FEnumParameterNameAndCurve");
static_assert(offsetof(FEnumParameterNameAndCurve, ParameterCurve) == 0x8, "Offset mismatch for FEnumParameterNameAndCurve::ParameterCurve");

// Size: 0x110 (Inherited: 0x4, Single: 0x10c)
struct FIntegerParameterNameAndCurve : FBaseParameterNameAndValue
{
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FMovieSceneIntegerChannel ParameterCurve; // 0x8 (Size: 0x108, Type: StructProperty)
};

static_assert(sizeof(FIntegerParameterNameAndCurve) == 0x110, "Size mismatch for FIntegerParameterNameAndCurve");
static_assert(offsetof(FIntegerParameterNameAndCurve, ParameterCurve) == 0x8, "Offset mismatch for FIntegerParameterNameAndCurve::ParameterCurve");

// Size: 0x118 (Inherited: 0x0, Single: 0x118)
struct FSpaceControlNameAndChannel
{
    FName ControlName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FMovieSceneControlRigSpaceChannel SpaceCurve; // 0x8 (Size: 0x110, Type: StructProperty)
};

static_assert(sizeof(FSpaceControlNameAndChannel) == 0x118, "Size mismatch for FSpaceControlNameAndChannel");
static_assert(offsetof(FSpaceControlNameAndChannel, ControlName) == 0x0, "Offset mismatch for FSpaceControlNameAndChannel::ControlName");
static_assert(offsetof(FSpaceControlNameAndChannel, SpaceCurve) == 0x8, "Offset mismatch for FSpaceControlNameAndChannel::SpaceCurve");

// Size: 0x110 (Inherited: 0x50, Single: 0xc0)
struct FMovieSceneControlRigSpaceChannel : FMovieSceneChannel
{
    TArray<FFrameNumber> KeyTimes; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FMovieSceneControlRigSpaceBaseKey> KeyValues; // 0x60 (Size: 0x10, Type: ArrayProperty)
    FMovieSceneKeyHandleMap KeyHandles; // 0x70 (Size: 0x88, Type: StructProperty)
    uint8_t Pad_f8[0x18]; // 0xf8 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FMovieSceneControlRigSpaceChannel) == 0x110, "Size mismatch for FMovieSceneControlRigSpaceChannel");
static_assert(offsetof(FMovieSceneControlRigSpaceChannel, KeyTimes) == 0x50, "Offset mismatch for FMovieSceneControlRigSpaceChannel::KeyTimes");
static_assert(offsetof(FMovieSceneControlRigSpaceChannel, KeyValues) == 0x60, "Offset mismatch for FMovieSceneControlRigSpaceChannel::KeyValues");
static_assert(offsetof(FMovieSceneControlRigSpaceChannel, KeyHandles) == 0x70, "Offset mismatch for FMovieSceneControlRigSpaceChannel::KeyHandles");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FMovieSceneControlRigSpaceBaseKey
{
    uint8_t SpaceType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FRigElementKey ControlRigElement; // 0x4 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FMovieSceneControlRigSpaceBaseKey) == 0xc, "Size mismatch for FMovieSceneControlRigSpaceBaseKey");
static_assert(offsetof(FMovieSceneControlRigSpaceBaseKey, SpaceType) == 0x0, "Offset mismatch for FMovieSceneControlRigSpaceBaseKey::SpaceType");
static_assert(offsetof(FMovieSceneControlRigSpaceBaseKey, ControlRigElement) == 0x4, "Offset mismatch for FMovieSceneControlRigSpaceBaseKey::ControlRigElement");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FChannelMapInfo
{
    int32_t ControlIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t TotalChannelIndex; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t ChannelIndex; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t ParentControlIndex; // 0xc (Size: 0x4, Type: IntProperty)
    FName ChannelTypeName; // 0x10 (Size: 0x4, Type: NameProperty)
    bool bDoesHaveSpace; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    int32_t SpaceChannelIndex; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t MaskIndex; // 0x1c (Size: 0x4, Type: IntProperty)
    int32_t CategoryIndex; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TArray<uint32_t> ConstraintsIndex; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FChannelMapInfo) == 0x38, "Size mismatch for FChannelMapInfo");
static_assert(offsetof(FChannelMapInfo, ControlIndex) == 0x0, "Offset mismatch for FChannelMapInfo::ControlIndex");
static_assert(offsetof(FChannelMapInfo, TotalChannelIndex) == 0x4, "Offset mismatch for FChannelMapInfo::TotalChannelIndex");
static_assert(offsetof(FChannelMapInfo, ChannelIndex) == 0x8, "Offset mismatch for FChannelMapInfo::ChannelIndex");
static_assert(offsetof(FChannelMapInfo, ParentControlIndex) == 0xc, "Offset mismatch for FChannelMapInfo::ParentControlIndex");
static_assert(offsetof(FChannelMapInfo, ChannelTypeName) == 0x10, "Offset mismatch for FChannelMapInfo::ChannelTypeName");
static_assert(offsetof(FChannelMapInfo, bDoesHaveSpace) == 0x14, "Offset mismatch for FChannelMapInfo::bDoesHaveSpace");
static_assert(offsetof(FChannelMapInfo, SpaceChannelIndex) == 0x18, "Offset mismatch for FChannelMapInfo::SpaceChannelIndex");
static_assert(offsetof(FChannelMapInfo, MaskIndex) == 0x1c, "Offset mismatch for FChannelMapInfo::MaskIndex");
static_assert(offsetof(FChannelMapInfo, CategoryIndex) == 0x20, "Offset mismatch for FChannelMapInfo::CategoryIndex");
static_assert(offsetof(FChannelMapInfo, ConstraintsIndex) == 0x28, "Offset mismatch for FChannelMapInfo::ConstraintsIndex");

// Size: 0xc0 (Inherited: 0xb0, Single: 0x10)
struct FMovieSceneControlRigParameterTemplate : FMovieSceneParameterSectionTemplate
{
    TArray<FEnumParameterNameAndCurve> Enums; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FIntegerParameterNameAndCurve> Integers; // 0x90 (Size: 0x10, Type: ArrayProperty)
    TArray<FSpaceControlNameAndChannel> Spaces; // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FConstraintAndActiveChannel> Constraints; // 0xb0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FMovieSceneControlRigParameterTemplate) == 0xc0, "Size mismatch for FMovieSceneControlRigParameterTemplate");
static_assert(offsetof(FMovieSceneControlRigParameterTemplate, Enums) == 0x80, "Offset mismatch for FMovieSceneControlRigParameterTemplate::Enums");
static_assert(offsetof(FMovieSceneControlRigParameterTemplate, Integers) == 0x90, "Offset mismatch for FMovieSceneControlRigParameterTemplate::Integers");
static_assert(offsetof(FMovieSceneControlRigParameterTemplate, Spaces) == 0xa0, "Offset mismatch for FMovieSceneControlRigParameterTemplate::Spaces");
static_assert(offsetof(FMovieSceneControlRigParameterTemplate, Constraints) == 0xb0, "Offset mismatch for FMovieSceneControlRigParameterTemplate::Constraints");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FControlRotationOrder
{
    uint8_t RotationOrder; // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bOverrideSetting; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FControlRotationOrder) == 0x2, "Size mismatch for FControlRotationOrder");
static_assert(offsetof(FControlRotationOrder, RotationOrder) == 0x0, "Offset mismatch for FControlRotationOrder::RotationOrder");
static_assert(offsetof(FControlRotationOrder, bOverrideSetting) == 0x1, "Offset mismatch for FControlRotationOrder::bOverrideSetting");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FControlRigSettingsPerPinBool
{
    TMap<bool, FString> Values; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FControlRigSettingsPerPinBool) == 0x50, "Size mismatch for FControlRigSettingsPerPinBool");
static_assert(offsetof(FControlRigSettingsPerPinBool, Values) == 0x0, "Offset mismatch for FControlRigSettingsPerPinBool::Values");

// Size: 0x220 (Inherited: 0x0, Single: 0x220)
struct FRigControlCopy
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t ControlType; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FRigElementKey ParentKey; // 0x8 (Size: 0x8, Type: StructProperty)
    FRigControlValue Value; // 0x10 (Size: 0x84, Type: StructProperty)
    uint8_t Pad_94[0xc]; // 0x94 (Size: 0xc, Type: PaddingProperty)
    FTransform OffsetTransform; // 0xa0 (Size: 0x60, Type: StructProperty)
    FTransform ParentTransform; // 0x100 (Size: 0x60, Type: StructProperty)
    FTransform LocalTransform; // 0x160 (Size: 0x60, Type: StructProperty)
    FTransform GlobalTransform; // 0x1c0 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigControlCopy) == 0x220, "Size mismatch for FRigControlCopy");
static_assert(offsetof(FRigControlCopy, Name) == 0x0, "Offset mismatch for FRigControlCopy::Name");
static_assert(offsetof(FRigControlCopy, ControlType) == 0x4, "Offset mismatch for FRigControlCopy::ControlType");
static_assert(offsetof(FRigControlCopy, ParentKey) == 0x8, "Offset mismatch for FRigControlCopy::ParentKey");
static_assert(offsetof(FRigControlCopy, Value) == 0x10, "Offset mismatch for FRigControlCopy::Value");
static_assert(offsetof(FRigControlCopy, OffsetTransform) == 0xa0, "Offset mismatch for FRigControlCopy::OffsetTransform");
static_assert(offsetof(FRigControlCopy, ParentTransform) == 0x100, "Offset mismatch for FRigControlCopy::ParentTransform");
static_assert(offsetof(FRigControlCopy, LocalTransform) == 0x160, "Offset mismatch for FRigControlCopy::LocalTransform");
static_assert(offsetof(FRigControlCopy, GlobalTransform) == 0x1c0, "Offset mismatch for FRigControlCopy::GlobalTransform");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FControlRigControlPose
{
    TArray<FRigControlCopy> CopyOfControls; // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_10[0x50]; // 0x10 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(FControlRigControlPose) == 0x60, "Size mismatch for FControlRigControlPose");
static_assert(offsetof(FControlRigControlPose, CopyOfControls) == 0x0, "Offset mismatch for FControlRigControlPose::CopyOfControls");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FSampleTrackMemoryData
{
    TArray<char> Buffer; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> Names; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> ObjectPaths; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FSampleTrackMemoryData) == 0x30, "Size mismatch for FSampleTrackMemoryData");
static_assert(offsetof(FSampleTrackMemoryData, Buffer) == 0x0, "Offset mismatch for FSampleTrackMemoryData::Buffer");
static_assert(offsetof(FSampleTrackMemoryData, Names) == 0x10, "Offset mismatch for FSampleTrackMemoryData::Names");
static_assert(offsetof(FSampleTrackMemoryData, ObjectPaths) == 0x20, "Offset mismatch for FSampleTrackMemoryData::ObjectPaths");

// Size: 0x70 (Inherited: 0x70, Single: 0x0)
struct FRigDispatchFactory : FRigVMDispatchFactory
{
};

static_assert(sizeof(FRigDispatchFactory) == 0x70, "Size mismatch for FRigDispatchFactory");

// Size: 0xa0 (Inherited: 0xe0, Single: 0xffffffc0)
struct FRigDispatch_AnimAttributeBase : FRigDispatchFactory
{
};

static_assert(sizeof(FRigDispatch_AnimAttributeBase) == 0xa0, "Size mismatch for FRigDispatch_AnimAttributeBase");

// Size: 0xa0 (Inherited: 0x180, Single: 0xffffff20)
struct FRigDispatch_GetAnimAttribute : FRigDispatch_AnimAttributeBase
{
};

static_assert(sizeof(FRigDispatch_GetAnimAttribute) == 0xa0, "Size mismatch for FRigDispatch_GetAnimAttribute");

// Size: 0xa0 (Inherited: 0x180, Single: 0xffffff20)
struct FRigDispatch_SetAnimAttribute : FRigDispatch_AnimAttributeBase
{
};

static_assert(sizeof(FRigDispatch_SetAnimAttribute) == 0xa0, "Size mismatch for FRigDispatch_SetAnimAttribute");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FRigUnit_SphereTrace_WorkData
{
    uint32_t Hash; // 0x0 (Size: 0x4, Type: UInt32Property)
    bool bHit; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FVector HitLocation; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector HitNormal; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SphereTrace_WorkData) == 0x38, "Size mismatch for FRigUnit_SphereTrace_WorkData");
static_assert(offsetof(FRigUnit_SphereTrace_WorkData, Hash) == 0x0, "Offset mismatch for FRigUnit_SphereTrace_WorkData::Hash");
static_assert(offsetof(FRigUnit_SphereTrace_WorkData, bHit) == 0x4, "Offset mismatch for FRigUnit_SphereTrace_WorkData::bHit");
static_assert(offsetof(FRigUnit_SphereTrace_WorkData, HitLocation) == 0x8, "Offset mismatch for FRigUnit_SphereTrace_WorkData::HitLocation");
static_assert(offsetof(FRigUnit_SphereTrace_WorkData, HitNormal) == 0x20, "Offset mismatch for FRigUnit_SphereTrace_WorkData::HitNormal");

// Size: 0xb0 (Inherited: 0x10, Single: 0xa0)
struct FRigUnit_SphereTraceWorld : FRigUnit
{
    FVector Start; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector End; // 0x20 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> Channel; // 0x38 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    float Radius; // 0x3c (Size: 0x4, Type: FloatProperty)
    bool bHit; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
    FVector HitLocation; // 0x48 (Size: 0x18, Type: StructProperty)
    FVector HitNormal; // 0x60 (Size: 0x18, Type: StructProperty)
    FRigUnit_SphereTrace_WorkData WorkData; // 0x78 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SphereTraceWorld) == 0xb0, "Size mismatch for FRigUnit_SphereTraceWorld");
static_assert(offsetof(FRigUnit_SphereTraceWorld, Start) == 0x8, "Offset mismatch for FRigUnit_SphereTraceWorld::Start");
static_assert(offsetof(FRigUnit_SphereTraceWorld, End) == 0x20, "Offset mismatch for FRigUnit_SphereTraceWorld::End");
static_assert(offsetof(FRigUnit_SphereTraceWorld, Channel) == 0x38, "Offset mismatch for FRigUnit_SphereTraceWorld::Channel");
static_assert(offsetof(FRigUnit_SphereTraceWorld, Radius) == 0x3c, "Offset mismatch for FRigUnit_SphereTraceWorld::Radius");
static_assert(offsetof(FRigUnit_SphereTraceWorld, bHit) == 0x40, "Offset mismatch for FRigUnit_SphereTraceWorld::bHit");
static_assert(offsetof(FRigUnit_SphereTraceWorld, HitLocation) == 0x48, "Offset mismatch for FRigUnit_SphereTraceWorld::HitLocation");
static_assert(offsetof(FRigUnit_SphereTraceWorld, HitNormal) == 0x60, "Offset mismatch for FRigUnit_SphereTraceWorld::HitNormal");
static_assert(offsetof(FRigUnit_SphereTraceWorld, WorkData) == 0x78, "Offset mismatch for FRigUnit_SphereTraceWorld::WorkData");

// Size: 0xb0 (Inherited: 0x10, Single: 0xa0)
struct FRigUnit_SphereTraceByTraceChannel : FRigUnit
{
    FVector Start; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector End; // 0x20 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ETraceTypeQuery> TraceChannel; // 0x38 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    float Radius; // 0x3c (Size: 0x4, Type: FloatProperty)
    bool bHit; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
    FVector HitLocation; // 0x48 (Size: 0x18, Type: StructProperty)
    FVector HitNormal; // 0x60 (Size: 0x18, Type: StructProperty)
    FRigUnit_SphereTrace_WorkData WorkData; // 0x78 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SphereTraceByTraceChannel) == 0xb0, "Size mismatch for FRigUnit_SphereTraceByTraceChannel");
static_assert(offsetof(FRigUnit_SphereTraceByTraceChannel, Start) == 0x8, "Offset mismatch for FRigUnit_SphereTraceByTraceChannel::Start");
static_assert(offsetof(FRigUnit_SphereTraceByTraceChannel, End) == 0x20, "Offset mismatch for FRigUnit_SphereTraceByTraceChannel::End");
static_assert(offsetof(FRigUnit_SphereTraceByTraceChannel, TraceChannel) == 0x38, "Offset mismatch for FRigUnit_SphereTraceByTraceChannel::TraceChannel");
static_assert(offsetof(FRigUnit_SphereTraceByTraceChannel, Radius) == 0x3c, "Offset mismatch for FRigUnit_SphereTraceByTraceChannel::Radius");
static_assert(offsetof(FRigUnit_SphereTraceByTraceChannel, bHit) == 0x40, "Offset mismatch for FRigUnit_SphereTraceByTraceChannel::bHit");
static_assert(offsetof(FRigUnit_SphereTraceByTraceChannel, HitLocation) == 0x48, "Offset mismatch for FRigUnit_SphereTraceByTraceChannel::HitLocation");
static_assert(offsetof(FRigUnit_SphereTraceByTraceChannel, HitNormal) == 0x60, "Offset mismatch for FRigUnit_SphereTraceByTraceChannel::HitNormal");
static_assert(offsetof(FRigUnit_SphereTraceByTraceChannel, WorkData) == 0x78, "Offset mismatch for FRigUnit_SphereTraceByTraceChannel::WorkData");

// Size: 0xb8 (Inherited: 0x10, Single: 0xa8)
struct FRigUnit_SphereTraceByObjectTypes : FRigUnit
{
    FVector Start; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector End; // 0x20 (Size: 0x18, Type: StructProperty)
    TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes; // 0x38 (Size: 0x10, Type: ArrayProperty)
    float Radius; // 0x48 (Size: 0x4, Type: FloatProperty)
    bool bHit; // 0x4c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4d[0x3]; // 0x4d (Size: 0x3, Type: PaddingProperty)
    FVector HitLocation; // 0x50 (Size: 0x18, Type: StructProperty)
    FVector HitNormal; // 0x68 (Size: 0x18, Type: StructProperty)
    FRigUnit_SphereTrace_WorkData WorkData; // 0x80 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SphereTraceByObjectTypes) == 0xb8, "Size mismatch for FRigUnit_SphereTraceByObjectTypes");
static_assert(offsetof(FRigUnit_SphereTraceByObjectTypes, Start) == 0x8, "Offset mismatch for FRigUnit_SphereTraceByObjectTypes::Start");
static_assert(offsetof(FRigUnit_SphereTraceByObjectTypes, End) == 0x20, "Offset mismatch for FRigUnit_SphereTraceByObjectTypes::End");
static_assert(offsetof(FRigUnit_SphereTraceByObjectTypes, ObjectTypes) == 0x38, "Offset mismatch for FRigUnit_SphereTraceByObjectTypes::ObjectTypes");
static_assert(offsetof(FRigUnit_SphereTraceByObjectTypes, Radius) == 0x48, "Offset mismatch for FRigUnit_SphereTraceByObjectTypes::Radius");
static_assert(offsetof(FRigUnit_SphereTraceByObjectTypes, bHit) == 0x4c, "Offset mismatch for FRigUnit_SphereTraceByObjectTypes::bHit");
static_assert(offsetof(FRigUnit_SphereTraceByObjectTypes, HitLocation) == 0x50, "Offset mismatch for FRigUnit_SphereTraceByObjectTypes::HitLocation");
static_assert(offsetof(FRigUnit_SphereTraceByObjectTypes, HitNormal) == 0x68, "Offset mismatch for FRigUnit_SphereTraceByObjectTypes::HitNormal");
static_assert(offsetof(FRigUnit_SphereTraceByObjectTypes, WorkData) == 0x80, "Offset mismatch for FRigUnit_SphereTraceByObjectTypes::WorkData");

// Size: 0x180 (Inherited: 0x10, Single: 0x170)
struct FRigUnit_Control : FRigUnit
{
    FEulerTransform Transform; // 0x8 (Size: 0x48, Type: StructProperty)
    FTransform base; // 0x50 (Size: 0x60, Type: StructProperty)
    FTransform InitTransform; // 0xb0 (Size: 0x60, Type: StructProperty)
    FTransform Result; // 0x110 (Size: 0x60, Type: StructProperty)
    FTransformFilter Filter; // 0x170 (Size: 0x9, Type: StructProperty)
    bool bIsInitialized; // 0x179 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_17a[0x6]; // 0x17a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_Control) == 0x180, "Size mismatch for FRigUnit_Control");
static_assert(offsetof(FRigUnit_Control, Transform) == 0x8, "Offset mismatch for FRigUnit_Control::Transform");
static_assert(offsetof(FRigUnit_Control, base) == 0x50, "Offset mismatch for FRigUnit_Control::base");
static_assert(offsetof(FRigUnit_Control, InitTransform) == 0xb0, "Offset mismatch for FRigUnit_Control::InitTransform");
static_assert(offsetof(FRigUnit_Control, Result) == 0x110, "Offset mismatch for FRigUnit_Control::Result");
static_assert(offsetof(FRigUnit_Control, Filter) == 0x170, "Offset mismatch for FRigUnit_Control::Filter");
static_assert(offsetof(FRigUnit_Control, bIsInitialized) == 0x179, "Offset mismatch for FRigUnit_Control::bIsInitialized");

// Size: 0x1e0 (Inherited: 0x190, Single: 0x50)
struct FRigUnit_Control_StaticMesh : FRigUnit_Control
{
    FTransform MeshTransform; // 0x180 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_Control_StaticMesh) == 0x1e0, "Size mismatch for FRigUnit_Control_StaticMesh");
static_assert(offsetof(FRigUnit_Control_StaticMesh, MeshTransform) == 0x180, "Offset mismatch for FRigUnit_Control_StaticMesh::MeshTransform");

// Size: 0x70 (Inherited: 0xe0, Single: 0xffffff90)
struct FRigDispatch_GetUserData : FRigDispatchFactory
{
};

static_assert(sizeof(FRigDispatch_GetUserData) == 0x70, "Size mismatch for FRigDispatch_GetUserData");

// Size: 0x48 (Inherited: 0x20, Single: 0x28)
struct FRigUnit_SetupShapeLibraryFromUserData : FRigUnitMutable
{
    FString Namespace; // 0x10 (Size: 0x10, Type: StrProperty)
    FString Path; // 0x20 (Size: 0x10, Type: StrProperty)
    FString LibraryName; // 0x30 (Size: 0x10, Type: StrProperty)
    bool LogShapeLibraries; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetupShapeLibraryFromUserData) == 0x48, "Size mismatch for FRigUnit_SetupShapeLibraryFromUserData");
static_assert(offsetof(FRigUnit_SetupShapeLibraryFromUserData, Namespace) == 0x10, "Offset mismatch for FRigUnit_SetupShapeLibraryFromUserData::Namespace");
static_assert(offsetof(FRigUnit_SetupShapeLibraryFromUserData, Path) == 0x20, "Offset mismatch for FRigUnit_SetupShapeLibraryFromUserData::Path");
static_assert(offsetof(FRigUnit_SetupShapeLibraryFromUserData, LibraryName) == 0x30, "Offset mismatch for FRigUnit_SetupShapeLibraryFromUserData::LibraryName");
static_assert(offsetof(FRigUnit_SetupShapeLibraryFromUserData, LogShapeLibraries) == 0x40, "Offset mismatch for FRigUnit_SetupShapeLibraryFromUserData::LogShapeLibraries");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_ShapeExists : FRigUnit
{
    FName ShapeName; // 0x8 (Size: 0x4, Type: NameProperty)
    bool Result; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ShapeExists) == 0x10, "Size mismatch for FRigUnit_ShapeExists");
static_assert(offsetof(FRigUnit_ShapeExists, ShapeName) == 0x8, "Offset mismatch for FRigUnit_ShapeExists::ShapeName");
static_assert(offsetof(FRigUnit_ShapeExists, Result) == 0xc, "Offset mismatch for FRigUnit_ShapeExists::Result");

// Size: 0x110 (Inherited: 0x30, Single: 0xe0)
struct FRigUnit_DebugBezier : FRigVMFunction_DebugBaseMutable
{
    FRigVMFourPointBezier Bezier; // 0x18 (Size: 0x60, Type: StructProperty)
    float MinimumU; // 0x78 (Size: 0x4, Type: FloatProperty)
    float MaximumU; // 0x7c (Size: 0x4, Type: FloatProperty)
    FLinearColor Color; // 0x80 (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x90 (Size: 0x4, Type: FloatProperty)
    int32_t Detail; // 0x94 (Size: 0x4, Type: IntProperty)
    FName Space; // 0x98 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
    FTransform WorldOffset; // 0xa0 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0x100 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0xf]; // 0x101 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugBezier) == 0x110, "Size mismatch for FRigUnit_DebugBezier");
static_assert(offsetof(FRigUnit_DebugBezier, Bezier) == 0x18, "Offset mismatch for FRigUnit_DebugBezier::Bezier");
static_assert(offsetof(FRigUnit_DebugBezier, MinimumU) == 0x78, "Offset mismatch for FRigUnit_DebugBezier::MinimumU");
static_assert(offsetof(FRigUnit_DebugBezier, MaximumU) == 0x7c, "Offset mismatch for FRigUnit_DebugBezier::MaximumU");
static_assert(offsetof(FRigUnit_DebugBezier, Color) == 0x80, "Offset mismatch for FRigUnit_DebugBezier::Color");
static_assert(offsetof(FRigUnit_DebugBezier, Thickness) == 0x90, "Offset mismatch for FRigUnit_DebugBezier::Thickness");
static_assert(offsetof(FRigUnit_DebugBezier, Detail) == 0x94, "Offset mismatch for FRigUnit_DebugBezier::Detail");
static_assert(offsetof(FRigUnit_DebugBezier, Space) == 0x98, "Offset mismatch for FRigUnit_DebugBezier::Space");
static_assert(offsetof(FRigUnit_DebugBezier, WorldOffset) == 0xa0, "Offset mismatch for FRigUnit_DebugBezier::WorldOffset");
static_assert(offsetof(FRigUnit_DebugBezier, bEnabled) == 0x100, "Offset mismatch for FRigUnit_DebugBezier::bEnabled");

// Size: 0x110 (Inherited: 0x30, Single: 0xe0)
struct FRigUnit_DebugBezierItemSpace : FRigVMFunction_DebugBaseMutable
{
    FRigVMFourPointBezier Bezier; // 0x18 (Size: 0x60, Type: StructProperty)
    float MinimumU; // 0x78 (Size: 0x4, Type: FloatProperty)
    float MaximumU; // 0x7c (Size: 0x4, Type: FloatProperty)
    FLinearColor Color; // 0x80 (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x90 (Size: 0x4, Type: FloatProperty)
    int32_t Detail; // 0x94 (Size: 0x4, Type: IntProperty)
    FRigElementKey Space; // 0x98 (Size: 0x8, Type: StructProperty)
    FTransform WorldOffset; // 0xa0 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0x100 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0xf]; // 0x101 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugBezierItemSpace) == 0x110, "Size mismatch for FRigUnit_DebugBezierItemSpace");
static_assert(offsetof(FRigUnit_DebugBezierItemSpace, Bezier) == 0x18, "Offset mismatch for FRigUnit_DebugBezierItemSpace::Bezier");
static_assert(offsetof(FRigUnit_DebugBezierItemSpace, MinimumU) == 0x78, "Offset mismatch for FRigUnit_DebugBezierItemSpace::MinimumU");
static_assert(offsetof(FRigUnit_DebugBezierItemSpace, MaximumU) == 0x7c, "Offset mismatch for FRigUnit_DebugBezierItemSpace::MaximumU");
static_assert(offsetof(FRigUnit_DebugBezierItemSpace, Color) == 0x80, "Offset mismatch for FRigUnit_DebugBezierItemSpace::Color");
static_assert(offsetof(FRigUnit_DebugBezierItemSpace, Thickness) == 0x90, "Offset mismatch for FRigUnit_DebugBezierItemSpace::Thickness");
static_assert(offsetof(FRigUnit_DebugBezierItemSpace, Detail) == 0x94, "Offset mismatch for FRigUnit_DebugBezierItemSpace::Detail");
static_assert(offsetof(FRigUnit_DebugBezierItemSpace, Space) == 0x98, "Offset mismatch for FRigUnit_DebugBezierItemSpace::Space");
static_assert(offsetof(FRigUnit_DebugBezierItemSpace, WorldOffset) == 0xa0, "Offset mismatch for FRigUnit_DebugBezierItemSpace::WorldOffset");
static_assert(offsetof(FRigUnit_DebugBezierItemSpace, bEnabled) == 0x100, "Offset mismatch for FRigUnit_DebugBezierItemSpace::bEnabled");

// Size: 0xb0 (Inherited: 0x18, Single: 0x98)
struct FRigUnit_DebugHierarchy : FRigVMFunction_DebugBase
{
    FRigVMExecutePin ExecutePin; // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementKey> Items; // 0x18 (Size: 0x10, Type: ArrayProperty)
    float Scale; // 0x28 (Size: 0x4, Type: FloatProperty)
    FLinearColor Color; // 0x2c (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x3c (Size: 0x4, Type: FloatProperty)
    FTransform WorldOffset; // 0x40 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0xf]; // 0xa1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugHierarchy) == 0xb0, "Size mismatch for FRigUnit_DebugHierarchy");
static_assert(offsetof(FRigUnit_DebugHierarchy, ExecutePin) == 0x10, "Offset mismatch for FRigUnit_DebugHierarchy::ExecutePin");
static_assert(offsetof(FRigUnit_DebugHierarchy, Items) == 0x18, "Offset mismatch for FRigUnit_DebugHierarchy::Items");
static_assert(offsetof(FRigUnit_DebugHierarchy, Scale) == 0x28, "Offset mismatch for FRigUnit_DebugHierarchy::Scale");
static_assert(offsetof(FRigUnit_DebugHierarchy, Color) == 0x2c, "Offset mismatch for FRigUnit_DebugHierarchy::Color");
static_assert(offsetof(FRigUnit_DebugHierarchy, Thickness) == 0x3c, "Offset mismatch for FRigUnit_DebugHierarchy::Thickness");
static_assert(offsetof(FRigUnit_DebugHierarchy, WorldOffset) == 0x40, "Offset mismatch for FRigUnit_DebugHierarchy::WorldOffset");
static_assert(offsetof(FRigUnit_DebugHierarchy, bEnabled) == 0xa0, "Offset mismatch for FRigUnit_DebugHierarchy::bEnabled");

// Size: 0x120 (Inherited: 0x18, Single: 0x108)
struct FRigUnit_DebugPose : FRigVMFunction_DebugBase
{
    FRigVMExecutePin ExecutePin; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigPose Pose; // 0x18 (Size: 0x70, Type: StructProperty)
    TArray<FRigElementKey> Items; // 0x88 (Size: 0x10, Type: ArrayProperty)
    float Scale; // 0x98 (Size: 0x4, Type: FloatProperty)
    FLinearColor Color; // 0x9c (Size: 0x10, Type: StructProperty)
    float Thickness; // 0xac (Size: 0x4, Type: FloatProperty)
    FTransform WorldOffset; // 0xb0 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_111[0xf]; // 0x111 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugPose) == 0x120, "Size mismatch for FRigUnit_DebugPose");
static_assert(offsetof(FRigUnit_DebugPose, ExecutePin) == 0x10, "Offset mismatch for FRigUnit_DebugPose::ExecutePin");
static_assert(offsetof(FRigUnit_DebugPose, Pose) == 0x18, "Offset mismatch for FRigUnit_DebugPose::Pose");
static_assert(offsetof(FRigUnit_DebugPose, Items) == 0x88, "Offset mismatch for FRigUnit_DebugPose::Items");
static_assert(offsetof(FRigUnit_DebugPose, Scale) == 0x98, "Offset mismatch for FRigUnit_DebugPose::Scale");
static_assert(offsetof(FRigUnit_DebugPose, Color) == 0x9c, "Offset mismatch for FRigUnit_DebugPose::Color");
static_assert(offsetof(FRigUnit_DebugPose, Thickness) == 0xac, "Offset mismatch for FRigUnit_DebugPose::Thickness");
static_assert(offsetof(FRigUnit_DebugPose, WorldOffset) == 0xb0, "Offset mismatch for FRigUnit_DebugPose::WorldOffset");
static_assert(offsetof(FRigUnit_DebugPose, bEnabled) == 0x110, "Offset mismatch for FRigUnit_DebugPose::bEnabled");

// Size: 0xd0 (Inherited: 0x38, Single: 0x98)
struct FRigUnit_DebugLine : FRigUnit_DebugBaseMutable
{
    FVector A; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector B; // 0x30 (Size: 0x18, Type: StructProperty)
    FLinearColor Color; // 0x48 (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x58 (Size: 0x4, Type: FloatProperty)
    FName Space; // 0x5c (Size: 0x4, Type: NameProperty)
    FTransform WorldOffset; // 0x60 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0xf]; // 0xc1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugLine) == 0xd0, "Size mismatch for FRigUnit_DebugLine");
static_assert(offsetof(FRigUnit_DebugLine, A) == 0x18, "Offset mismatch for FRigUnit_DebugLine::A");
static_assert(offsetof(FRigUnit_DebugLine, B) == 0x30, "Offset mismatch for FRigUnit_DebugLine::B");
static_assert(offsetof(FRigUnit_DebugLine, Color) == 0x48, "Offset mismatch for FRigUnit_DebugLine::Color");
static_assert(offsetof(FRigUnit_DebugLine, Thickness) == 0x58, "Offset mismatch for FRigUnit_DebugLine::Thickness");
static_assert(offsetof(FRigUnit_DebugLine, Space) == 0x5c, "Offset mismatch for FRigUnit_DebugLine::Space");
static_assert(offsetof(FRigUnit_DebugLine, WorldOffset) == 0x60, "Offset mismatch for FRigUnit_DebugLine::WorldOffset");
static_assert(offsetof(FRigUnit_DebugLine, bEnabled) == 0xc0, "Offset mismatch for FRigUnit_DebugLine::bEnabled");

// Size: 0xe0 (Inherited: 0x38, Single: 0xa8)
struct FRigUnit_DebugLineItemSpace : FRigUnit_DebugBaseMutable
{
    FVector A; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector B; // 0x30 (Size: 0x18, Type: StructProperty)
    FLinearColor Color; // 0x48 (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x58 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space; // 0x5c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_64[0xc]; // 0x64 (Size: 0xc, Type: PaddingProperty)
    FTransform WorldOffset; // 0x70 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0xd0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d1[0xf]; // 0xd1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugLineItemSpace) == 0xe0, "Size mismatch for FRigUnit_DebugLineItemSpace");
static_assert(offsetof(FRigUnit_DebugLineItemSpace, A) == 0x18, "Offset mismatch for FRigUnit_DebugLineItemSpace::A");
static_assert(offsetof(FRigUnit_DebugLineItemSpace, B) == 0x30, "Offset mismatch for FRigUnit_DebugLineItemSpace::B");
static_assert(offsetof(FRigUnit_DebugLineItemSpace, Color) == 0x48, "Offset mismatch for FRigUnit_DebugLineItemSpace::Color");
static_assert(offsetof(FRigUnit_DebugLineItemSpace, Thickness) == 0x58, "Offset mismatch for FRigUnit_DebugLineItemSpace::Thickness");
static_assert(offsetof(FRigUnit_DebugLineItemSpace, Space) == 0x5c, "Offset mismatch for FRigUnit_DebugLineItemSpace::Space");
static_assert(offsetof(FRigUnit_DebugLineItemSpace, WorldOffset) == 0x70, "Offset mismatch for FRigUnit_DebugLineItemSpace::WorldOffset");
static_assert(offsetof(FRigUnit_DebugLineItemSpace, bEnabled) == 0xd0, "Offset mismatch for FRigUnit_DebugLineItemSpace::bEnabled");

// Size: 0xb0 (Inherited: 0x38, Single: 0x78)
struct FRigUnit_DebugLineStrip : FRigUnit_DebugBaseMutable
{
    TArray<FVector> Points; // 0x18 (Size: 0x10, Type: ArrayProperty)
    FLinearColor Color; // 0x28 (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x38 (Size: 0x4, Type: FloatProperty)
    FName Space; // 0x3c (Size: 0x4, Type: NameProperty)
    FTransform WorldOffset; // 0x40 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0xf]; // 0xa1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugLineStrip) == 0xb0, "Size mismatch for FRigUnit_DebugLineStrip");
static_assert(offsetof(FRigUnit_DebugLineStrip, Points) == 0x18, "Offset mismatch for FRigUnit_DebugLineStrip::Points");
static_assert(offsetof(FRigUnit_DebugLineStrip, Color) == 0x28, "Offset mismatch for FRigUnit_DebugLineStrip::Color");
static_assert(offsetof(FRigUnit_DebugLineStrip, Thickness) == 0x38, "Offset mismatch for FRigUnit_DebugLineStrip::Thickness");
static_assert(offsetof(FRigUnit_DebugLineStrip, Space) == 0x3c, "Offset mismatch for FRigUnit_DebugLineStrip::Space");
static_assert(offsetof(FRigUnit_DebugLineStrip, WorldOffset) == 0x40, "Offset mismatch for FRigUnit_DebugLineStrip::WorldOffset");
static_assert(offsetof(FRigUnit_DebugLineStrip, bEnabled) == 0xa0, "Offset mismatch for FRigUnit_DebugLineStrip::bEnabled");

// Size: 0xc0 (Inherited: 0x38, Single: 0x88)
struct FRigUnit_DebugLineStripItemSpace : FRigUnit_DebugBaseMutable
{
    TArray<FVector> Points; // 0x18 (Size: 0x10, Type: ArrayProperty)
    FLinearColor Color; // 0x28 (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x38 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space; // 0x3c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_44[0xc]; // 0x44 (Size: 0xc, Type: PaddingProperty)
    FTransform WorldOffset; // 0x50 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0xb0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b1[0xf]; // 0xb1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugLineStripItemSpace) == 0xc0, "Size mismatch for FRigUnit_DebugLineStripItemSpace");
static_assert(offsetof(FRigUnit_DebugLineStripItemSpace, Points) == 0x18, "Offset mismatch for FRigUnit_DebugLineStripItemSpace::Points");
static_assert(offsetof(FRigUnit_DebugLineStripItemSpace, Color) == 0x28, "Offset mismatch for FRigUnit_DebugLineStripItemSpace::Color");
static_assert(offsetof(FRigUnit_DebugLineStripItemSpace, Thickness) == 0x38, "Offset mismatch for FRigUnit_DebugLineStripItemSpace::Thickness");
static_assert(offsetof(FRigUnit_DebugLineStripItemSpace, Space) == 0x3c, "Offset mismatch for FRigUnit_DebugLineStripItemSpace::Space");
static_assert(offsetof(FRigUnit_DebugLineStripItemSpace, WorldOffset) == 0x50, "Offset mismatch for FRigUnit_DebugLineStripItemSpace::WorldOffset");
static_assert(offsetof(FRigUnit_DebugLineStripItemSpace, bEnabled) == 0xb0, "Offset mismatch for FRigUnit_DebugLineStripItemSpace::bEnabled");

// Size: 0x110 (Inherited: 0x38, Single: 0xd8)
struct FRigUnit_DebugRectangle : FRigUnit_DebugBaseMutable
{
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    FLinearColor Color; // 0x80 (Size: 0x10, Type: StructProperty)
    float Scale; // 0x90 (Size: 0x4, Type: FloatProperty)
    float Thickness; // 0x94 (Size: 0x4, Type: FloatProperty)
    FName Space; // 0x98 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
    FTransform WorldOffset; // 0xa0 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0x100 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0xf]; // 0x101 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugRectangle) == 0x110, "Size mismatch for FRigUnit_DebugRectangle");
static_assert(offsetof(FRigUnit_DebugRectangle, Transform) == 0x20, "Offset mismatch for FRigUnit_DebugRectangle::Transform");
static_assert(offsetof(FRigUnit_DebugRectangle, Color) == 0x80, "Offset mismatch for FRigUnit_DebugRectangle::Color");
static_assert(offsetof(FRigUnit_DebugRectangle, Scale) == 0x90, "Offset mismatch for FRigUnit_DebugRectangle::Scale");
static_assert(offsetof(FRigUnit_DebugRectangle, Thickness) == 0x94, "Offset mismatch for FRigUnit_DebugRectangle::Thickness");
static_assert(offsetof(FRigUnit_DebugRectangle, Space) == 0x98, "Offset mismatch for FRigUnit_DebugRectangle::Space");
static_assert(offsetof(FRigUnit_DebugRectangle, WorldOffset) == 0xa0, "Offset mismatch for FRigUnit_DebugRectangle::WorldOffset");
static_assert(offsetof(FRigUnit_DebugRectangle, bEnabled) == 0x100, "Offset mismatch for FRigUnit_DebugRectangle::bEnabled");

// Size: 0x110 (Inherited: 0x38, Single: 0xd8)
struct FRigUnit_DebugRectangleItemSpace : FRigUnit_DebugBaseMutable
{
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    FLinearColor Color; // 0x80 (Size: 0x10, Type: StructProperty)
    float Scale; // 0x90 (Size: 0x4, Type: FloatProperty)
    float Thickness; // 0x94 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space; // 0x98 (Size: 0x8, Type: StructProperty)
    FTransform WorldOffset; // 0xa0 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0x100 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0xf]; // 0x101 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugRectangleItemSpace) == 0x110, "Size mismatch for FRigUnit_DebugRectangleItemSpace");
static_assert(offsetof(FRigUnit_DebugRectangleItemSpace, Transform) == 0x20, "Offset mismatch for FRigUnit_DebugRectangleItemSpace::Transform");
static_assert(offsetof(FRigUnit_DebugRectangleItemSpace, Color) == 0x80, "Offset mismatch for FRigUnit_DebugRectangleItemSpace::Color");
static_assert(offsetof(FRigUnit_DebugRectangleItemSpace, Scale) == 0x90, "Offset mismatch for FRigUnit_DebugRectangleItemSpace::Scale");
static_assert(offsetof(FRigUnit_DebugRectangleItemSpace, Thickness) == 0x94, "Offset mismatch for FRigUnit_DebugRectangleItemSpace::Thickness");
static_assert(offsetof(FRigUnit_DebugRectangleItemSpace, Space) == 0x98, "Offset mismatch for FRigUnit_DebugRectangleItemSpace::Space");
static_assert(offsetof(FRigUnit_DebugRectangleItemSpace, WorldOffset) == 0xa0, "Offset mismatch for FRigUnit_DebugRectangleItemSpace::WorldOffset");
static_assert(offsetof(FRigUnit_DebugRectangleItemSpace, bEnabled) == 0x100, "Offset mismatch for FRigUnit_DebugRectangleItemSpace::bEnabled");

// Size: 0x120 (Inherited: 0x38, Single: 0xe8)
struct FRigUnit_DebugArc : FRigUnit_DebugBaseMutable
{
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    FLinearColor Color; // 0x80 (Size: 0x10, Type: StructProperty)
    float Radius; // 0x90 (Size: 0x4, Type: FloatProperty)
    float MinimumDegrees; // 0x94 (Size: 0x4, Type: FloatProperty)
    float MaximumDegrees; // 0x98 (Size: 0x4, Type: FloatProperty)
    float Thickness; // 0x9c (Size: 0x4, Type: FloatProperty)
    int32_t Detail; // 0xa0 (Size: 0x4, Type: IntProperty)
    FName Space; // 0xa4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_a8[0x8]; // 0xa8 (Size: 0x8, Type: PaddingProperty)
    FTransform WorldOffset; // 0xb0 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_111[0xf]; // 0x111 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugArc) == 0x120, "Size mismatch for FRigUnit_DebugArc");
static_assert(offsetof(FRigUnit_DebugArc, Transform) == 0x20, "Offset mismatch for FRigUnit_DebugArc::Transform");
static_assert(offsetof(FRigUnit_DebugArc, Color) == 0x80, "Offset mismatch for FRigUnit_DebugArc::Color");
static_assert(offsetof(FRigUnit_DebugArc, Radius) == 0x90, "Offset mismatch for FRigUnit_DebugArc::Radius");
static_assert(offsetof(FRigUnit_DebugArc, MinimumDegrees) == 0x94, "Offset mismatch for FRigUnit_DebugArc::MinimumDegrees");
static_assert(offsetof(FRigUnit_DebugArc, MaximumDegrees) == 0x98, "Offset mismatch for FRigUnit_DebugArc::MaximumDegrees");
static_assert(offsetof(FRigUnit_DebugArc, Thickness) == 0x9c, "Offset mismatch for FRigUnit_DebugArc::Thickness");
static_assert(offsetof(FRigUnit_DebugArc, Detail) == 0xa0, "Offset mismatch for FRigUnit_DebugArc::Detail");
static_assert(offsetof(FRigUnit_DebugArc, Space) == 0xa4, "Offset mismatch for FRigUnit_DebugArc::Space");
static_assert(offsetof(FRigUnit_DebugArc, WorldOffset) == 0xb0, "Offset mismatch for FRigUnit_DebugArc::WorldOffset");
static_assert(offsetof(FRigUnit_DebugArc, bEnabled) == 0x110, "Offset mismatch for FRigUnit_DebugArc::bEnabled");

// Size: 0x120 (Inherited: 0x38, Single: 0xe8)
struct FRigUnit_DebugArcItemSpace : FRigUnit_DebugBaseMutable
{
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    FLinearColor Color; // 0x80 (Size: 0x10, Type: StructProperty)
    float Radius; // 0x90 (Size: 0x4, Type: FloatProperty)
    float MinimumDegrees; // 0x94 (Size: 0x4, Type: FloatProperty)
    float MaximumDegrees; // 0x98 (Size: 0x4, Type: FloatProperty)
    float Thickness; // 0x9c (Size: 0x4, Type: FloatProperty)
    int32_t Detail; // 0xa0 (Size: 0x4, Type: IntProperty)
    FRigElementKey Space; // 0xa4 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
    FTransform WorldOffset; // 0xb0 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_111[0xf]; // 0x111 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugArcItemSpace) == 0x120, "Size mismatch for FRigUnit_DebugArcItemSpace");
static_assert(offsetof(FRigUnit_DebugArcItemSpace, Transform) == 0x20, "Offset mismatch for FRigUnit_DebugArcItemSpace::Transform");
static_assert(offsetof(FRigUnit_DebugArcItemSpace, Color) == 0x80, "Offset mismatch for FRigUnit_DebugArcItemSpace::Color");
static_assert(offsetof(FRigUnit_DebugArcItemSpace, Radius) == 0x90, "Offset mismatch for FRigUnit_DebugArcItemSpace::Radius");
static_assert(offsetof(FRigUnit_DebugArcItemSpace, MinimumDegrees) == 0x94, "Offset mismatch for FRigUnit_DebugArcItemSpace::MinimumDegrees");
static_assert(offsetof(FRigUnit_DebugArcItemSpace, MaximumDegrees) == 0x98, "Offset mismatch for FRigUnit_DebugArcItemSpace::MaximumDegrees");
static_assert(offsetof(FRigUnit_DebugArcItemSpace, Thickness) == 0x9c, "Offset mismatch for FRigUnit_DebugArcItemSpace::Thickness");
static_assert(offsetof(FRigUnit_DebugArcItemSpace, Detail) == 0xa0, "Offset mismatch for FRigUnit_DebugArcItemSpace::Detail");
static_assert(offsetof(FRigUnit_DebugArcItemSpace, Space) == 0xa4, "Offset mismatch for FRigUnit_DebugArcItemSpace::Space");
static_assert(offsetof(FRigUnit_DebugArcItemSpace, WorldOffset) == 0xb0, "Offset mismatch for FRigUnit_DebugArcItemSpace::WorldOffset");
static_assert(offsetof(FRigUnit_DebugArcItemSpace, bEnabled) == 0x110, "Offset mismatch for FRigUnit_DebugArcItemSpace::bEnabled");

// Size: 0x100 (Inherited: 0x20, Single: 0xe0)
struct FRigUnit_DebugTransform : FRigUnit_DebugBase
{
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
    uint8_t Mode; // 0x70 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_71[0x3]; // 0x71 (Size: 0x3, Type: PaddingProperty)
    FLinearColor Color; // 0x74 (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x84 (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x88 (Size: 0x4, Type: FloatProperty)
    FName Space; // 0x8c (Size: 0x4, Type: NameProperty)
    FTransform WorldOffset; // 0x90 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0xf0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f1[0xf]; // 0xf1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugTransform) == 0x100, "Size mismatch for FRigUnit_DebugTransform");
static_assert(offsetof(FRigUnit_DebugTransform, Transform) == 0x10, "Offset mismatch for FRigUnit_DebugTransform::Transform");
static_assert(offsetof(FRigUnit_DebugTransform, Mode) == 0x70, "Offset mismatch for FRigUnit_DebugTransform::Mode");
static_assert(offsetof(FRigUnit_DebugTransform, Color) == 0x74, "Offset mismatch for FRigUnit_DebugTransform::Color");
static_assert(offsetof(FRigUnit_DebugTransform, Thickness) == 0x84, "Offset mismatch for FRigUnit_DebugTransform::Thickness");
static_assert(offsetof(FRigUnit_DebugTransform, Scale) == 0x88, "Offset mismatch for FRigUnit_DebugTransform::Scale");
static_assert(offsetof(FRigUnit_DebugTransform, Space) == 0x8c, "Offset mismatch for FRigUnit_DebugTransform::Space");
static_assert(offsetof(FRigUnit_DebugTransform, WorldOffset) == 0x90, "Offset mismatch for FRigUnit_DebugTransform::WorldOffset");
static_assert(offsetof(FRigUnit_DebugTransform, bEnabled) == 0xf0, "Offset mismatch for FRigUnit_DebugTransform::bEnabled");

// Size: 0x110 (Inherited: 0x38, Single: 0xd8)
struct FRigUnit_DebugTransformMutable : FRigUnit_DebugBaseMutable
{
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t Mode; // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_81[0x3]; // 0x81 (Size: 0x3, Type: PaddingProperty)
    FLinearColor Color; // 0x84 (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x94 (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x98 (Size: 0x4, Type: FloatProperty)
    FName Space; // 0x9c (Size: 0x4, Type: NameProperty)
    FTransform WorldOffset; // 0xa0 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0x100 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0xf]; // 0x101 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugTransformMutable) == 0x110, "Size mismatch for FRigUnit_DebugTransformMutable");
static_assert(offsetof(FRigUnit_DebugTransformMutable, Transform) == 0x20, "Offset mismatch for FRigUnit_DebugTransformMutable::Transform");
static_assert(offsetof(FRigUnit_DebugTransformMutable, Mode) == 0x80, "Offset mismatch for FRigUnit_DebugTransformMutable::Mode");
static_assert(offsetof(FRigUnit_DebugTransformMutable, Color) == 0x84, "Offset mismatch for FRigUnit_DebugTransformMutable::Color");
static_assert(offsetof(FRigUnit_DebugTransformMutable, Thickness) == 0x94, "Offset mismatch for FRigUnit_DebugTransformMutable::Thickness");
static_assert(offsetof(FRigUnit_DebugTransformMutable, Scale) == 0x98, "Offset mismatch for FRigUnit_DebugTransformMutable::Scale");
static_assert(offsetof(FRigUnit_DebugTransformMutable, Space) == 0x9c, "Offset mismatch for FRigUnit_DebugTransformMutable::Space");
static_assert(offsetof(FRigUnit_DebugTransformMutable, WorldOffset) == 0xa0, "Offset mismatch for FRigUnit_DebugTransformMutable::WorldOffset");
static_assert(offsetof(FRigUnit_DebugTransformMutable, bEnabled) == 0x100, "Offset mismatch for FRigUnit_DebugTransformMutable::bEnabled");

// Size: 0x120 (Inherited: 0x38, Single: 0xe8)
struct FRigUnit_DebugTransformMutableItemSpace : FRigUnit_DebugBaseMutable
{
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t Mode; // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_81[0x3]; // 0x81 (Size: 0x3, Type: PaddingProperty)
    FLinearColor Color; // 0x84 (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x94 (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x98 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space; // 0x9c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_a4[0xc]; // 0xa4 (Size: 0xc, Type: PaddingProperty)
    FTransform WorldOffset; // 0xb0 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_111[0xf]; // 0x111 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugTransformMutableItemSpace) == 0x120, "Size mismatch for FRigUnit_DebugTransformMutableItemSpace");
static_assert(offsetof(FRigUnit_DebugTransformMutableItemSpace, Transform) == 0x20, "Offset mismatch for FRigUnit_DebugTransformMutableItemSpace::Transform");
static_assert(offsetof(FRigUnit_DebugTransformMutableItemSpace, Mode) == 0x80, "Offset mismatch for FRigUnit_DebugTransformMutableItemSpace::Mode");
static_assert(offsetof(FRigUnit_DebugTransformMutableItemSpace, Color) == 0x84, "Offset mismatch for FRigUnit_DebugTransformMutableItemSpace::Color");
static_assert(offsetof(FRigUnit_DebugTransformMutableItemSpace, Thickness) == 0x94, "Offset mismatch for FRigUnit_DebugTransformMutableItemSpace::Thickness");
static_assert(offsetof(FRigUnit_DebugTransformMutableItemSpace, Scale) == 0x98, "Offset mismatch for FRigUnit_DebugTransformMutableItemSpace::Scale");
static_assert(offsetof(FRigUnit_DebugTransformMutableItemSpace, Space) == 0x9c, "Offset mismatch for FRigUnit_DebugTransformMutableItemSpace::Space");
static_assert(offsetof(FRigUnit_DebugTransformMutableItemSpace, WorldOffset) == 0xb0, "Offset mismatch for FRigUnit_DebugTransformMutableItemSpace::WorldOffset");
static_assert(offsetof(FRigUnit_DebugTransformMutableItemSpace, bEnabled) == 0x110, "Offset mismatch for FRigUnit_DebugTransformMutableItemSpace::bEnabled");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigUnit_DebugTransformArrayMutable_WorkData
{
    TArray<FTransform> DrawTransforms; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_DebugTransformArrayMutable_WorkData) == 0x10, "Size mismatch for FRigUnit_DebugTransformArrayMutable_WorkData");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutable_WorkData, DrawTransforms) == 0x0, "Offset mismatch for FRigUnit_DebugTransformArrayMutable_WorkData::DrawTransforms");

// Size: 0xd0 (Inherited: 0x38, Single: 0x98)
struct FRigUnit_DebugTransformArrayMutable : FRigUnit_DebugBaseMutable
{
    TArray<FTransform> Transforms; // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t Mode; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    FLinearColor Color; // 0x2c (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x3c (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x40 (Size: 0x4, Type: FloatProperty)
    FName Space; // 0x44 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
    FTransform WorldOffset; // 0x50 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0xb0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b1[0x7]; // 0xb1 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_DebugTransformArrayMutable_WorkData WorkData; // 0xb8 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugTransformArrayMutable) == 0xd0, "Size mismatch for FRigUnit_DebugTransformArrayMutable");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutable, Transforms) == 0x18, "Offset mismatch for FRigUnit_DebugTransformArrayMutable::Transforms");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutable, Mode) == 0x28, "Offset mismatch for FRigUnit_DebugTransformArrayMutable::Mode");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutable, Color) == 0x2c, "Offset mismatch for FRigUnit_DebugTransformArrayMutable::Color");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutable, Thickness) == 0x3c, "Offset mismatch for FRigUnit_DebugTransformArrayMutable::Thickness");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutable, Scale) == 0x40, "Offset mismatch for FRigUnit_DebugTransformArrayMutable::Scale");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutable, Space) == 0x44, "Offset mismatch for FRigUnit_DebugTransformArrayMutable::Space");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutable, WorldOffset) == 0x50, "Offset mismatch for FRigUnit_DebugTransformArrayMutable::WorldOffset");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutable, bEnabled) == 0xb0, "Offset mismatch for FRigUnit_DebugTransformArrayMutable::bEnabled");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutable, WorkData) == 0xb8, "Offset mismatch for FRigUnit_DebugTransformArrayMutable::WorkData");

// Size: 0xd0 (Inherited: 0x38, Single: 0x98)
struct FRigUnit_DebugTransformArrayMutableItemSpace : FRigUnit_DebugBaseMutable
{
    TArray<FTransform> Transforms; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ParentIndices; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t Mode; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    FLinearColor Color; // 0x3c (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x4c (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x50 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space; // 0x54 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    FTransform WorldOffset; // 0x60 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0xf]; // 0xc1 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DebugTransformArrayMutableItemSpace) == 0xd0, "Size mismatch for FRigUnit_DebugTransformArrayMutableItemSpace");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutableItemSpace, Transforms) == 0x18, "Offset mismatch for FRigUnit_DebugTransformArrayMutableItemSpace::Transforms");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutableItemSpace, ParentIndices) == 0x28, "Offset mismatch for FRigUnit_DebugTransformArrayMutableItemSpace::ParentIndices");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutableItemSpace, Mode) == 0x38, "Offset mismatch for FRigUnit_DebugTransformArrayMutableItemSpace::Mode");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutableItemSpace, Color) == 0x3c, "Offset mismatch for FRigUnit_DebugTransformArrayMutableItemSpace::Color");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutableItemSpace, Thickness) == 0x4c, "Offset mismatch for FRigUnit_DebugTransformArrayMutableItemSpace::Thickness");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutableItemSpace, Scale) == 0x50, "Offset mismatch for FRigUnit_DebugTransformArrayMutableItemSpace::Scale");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutableItemSpace, Space) == 0x54, "Offset mismatch for FRigUnit_DebugTransformArrayMutableItemSpace::Space");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutableItemSpace, WorldOffset) == 0x60, "Offset mismatch for FRigUnit_DebugTransformArrayMutableItemSpace::WorldOffset");
static_assert(offsetof(FRigUnit_DebugTransformArrayMutableItemSpace, bEnabled) == 0xc0, "Offset mismatch for FRigUnit_DebugTransformArrayMutableItemSpace::bEnabled");

// Size: 0x18 (Inherited: 0x30, Single: 0xffffffe8)
struct FRigUnit_StartProfilingTimer : FRigVMFunction_DebugBaseMutable
{
};

static_assert(sizeof(FRigUnit_StartProfilingTimer) == 0x18, "Size mismatch for FRigUnit_StartProfilingTimer");

// Size: 0x40 (Inherited: 0x30, Single: 0x10)
struct FRigUnit_EndProfilingTimer : FRigVMFunction_DebugBaseMutable
{
    int32_t NumberOfMeasurements; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FString Prefix; // 0x20 (Size: 0x10, Type: StrProperty)
    float AccumulatedTime; // 0x30 (Size: 0x4, Type: FloatProperty)
    int32_t MeasurementsLeft; // 0x34 (Size: 0x4, Type: IntProperty)
    bool bIsInitialized; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_EndProfilingTimer) == 0x40, "Size mismatch for FRigUnit_EndProfilingTimer");
static_assert(offsetof(FRigUnit_EndProfilingTimer, NumberOfMeasurements) == 0x18, "Offset mismatch for FRigUnit_EndProfilingTimer::NumberOfMeasurements");
static_assert(offsetof(FRigUnit_EndProfilingTimer, Prefix) == 0x20, "Offset mismatch for FRigUnit_EndProfilingTimer::Prefix");
static_assert(offsetof(FRigUnit_EndProfilingTimer, AccumulatedTime) == 0x30, "Offset mismatch for FRigUnit_EndProfilingTimer::AccumulatedTime");
static_assert(offsetof(FRigUnit_EndProfilingTimer, MeasurementsLeft) == 0x34, "Offset mismatch for FRigUnit_EndProfilingTimer::MeasurementsLeft");
static_assert(offsetof(FRigUnit_EndProfilingTimer, bIsInitialized) == 0x38, "Offset mismatch for FRigUnit_EndProfilingTimer::bIsInitialized");

// Size: 0x48 (Inherited: 0x20, Single: 0x28)
struct FRigUnit_VisualDebugVector : FRigUnit_DebugBase
{
    FVector Value; // 0x10 (Size: 0x18, Type: StructProperty)
    bool bEnabled; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Mode; // 0x29 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    FLinearColor Color; // 0x2c (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x3c (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x40 (Size: 0x4, Type: FloatProperty)
    FName BoneSpace; // 0x44 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FRigUnit_VisualDebugVector) == 0x48, "Size mismatch for FRigUnit_VisualDebugVector");
static_assert(offsetof(FRigUnit_VisualDebugVector, Value) == 0x10, "Offset mismatch for FRigUnit_VisualDebugVector::Value");
static_assert(offsetof(FRigUnit_VisualDebugVector, bEnabled) == 0x28, "Offset mismatch for FRigUnit_VisualDebugVector::bEnabled");
static_assert(offsetof(FRigUnit_VisualDebugVector, Mode) == 0x29, "Offset mismatch for FRigUnit_VisualDebugVector::Mode");
static_assert(offsetof(FRigUnit_VisualDebugVector, Color) == 0x2c, "Offset mismatch for FRigUnit_VisualDebugVector::Color");
static_assert(offsetof(FRigUnit_VisualDebugVector, Thickness) == 0x3c, "Offset mismatch for FRigUnit_VisualDebugVector::Thickness");
static_assert(offsetof(FRigUnit_VisualDebugVector, Scale) == 0x40, "Offset mismatch for FRigUnit_VisualDebugVector::Scale");
static_assert(offsetof(FRigUnit_VisualDebugVector, BoneSpace) == 0x44, "Offset mismatch for FRigUnit_VisualDebugVector::BoneSpace");

// Size: 0x50 (Inherited: 0x20, Single: 0x30)
struct FRigUnit_VisualDebugVectorItemSpace : FRigUnit_DebugBase
{
    FVector Value; // 0x10 (Size: 0x18, Type: StructProperty)
    bool bEnabled; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Mode; // 0x29 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2a[0x2]; // 0x2a (Size: 0x2, Type: PaddingProperty)
    FLinearColor Color; // 0x2c (Size: 0x10, Type: StructProperty)
    float Thickness; // 0x3c (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x40 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space; // 0x44 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_VisualDebugVectorItemSpace) == 0x50, "Size mismatch for FRigUnit_VisualDebugVectorItemSpace");
static_assert(offsetof(FRigUnit_VisualDebugVectorItemSpace, Value) == 0x10, "Offset mismatch for FRigUnit_VisualDebugVectorItemSpace::Value");
static_assert(offsetof(FRigUnit_VisualDebugVectorItemSpace, bEnabled) == 0x28, "Offset mismatch for FRigUnit_VisualDebugVectorItemSpace::bEnabled");
static_assert(offsetof(FRigUnit_VisualDebugVectorItemSpace, Mode) == 0x29, "Offset mismatch for FRigUnit_VisualDebugVectorItemSpace::Mode");
static_assert(offsetof(FRigUnit_VisualDebugVectorItemSpace, Color) == 0x2c, "Offset mismatch for FRigUnit_VisualDebugVectorItemSpace::Color");
static_assert(offsetof(FRigUnit_VisualDebugVectorItemSpace, Thickness) == 0x3c, "Offset mismatch for FRigUnit_VisualDebugVectorItemSpace::Thickness");
static_assert(offsetof(FRigUnit_VisualDebugVectorItemSpace, Scale) == 0x40, "Offset mismatch for FRigUnit_VisualDebugVectorItemSpace::Scale");
static_assert(offsetof(FRigUnit_VisualDebugVectorItemSpace, Space) == 0x44, "Offset mismatch for FRigUnit_VisualDebugVectorItemSpace::Space");

// Size: 0x40 (Inherited: 0x20, Single: 0x20)
struct FRigUnit_VisualDebugQuat : FRigUnit_DebugBase
{
    FQuat Value; // 0x10 (Size: 0x20, Type: StructProperty)
    bool bEnabled; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x3]; // 0x31 (Size: 0x3, Type: PaddingProperty)
    float Thickness; // 0x34 (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x38 (Size: 0x4, Type: FloatProperty)
    FName BoneSpace; // 0x3c (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FRigUnit_VisualDebugQuat) == 0x40, "Size mismatch for FRigUnit_VisualDebugQuat");
static_assert(offsetof(FRigUnit_VisualDebugQuat, Value) == 0x10, "Offset mismatch for FRigUnit_VisualDebugQuat::Value");
static_assert(offsetof(FRigUnit_VisualDebugQuat, bEnabled) == 0x30, "Offset mismatch for FRigUnit_VisualDebugQuat::bEnabled");
static_assert(offsetof(FRigUnit_VisualDebugQuat, Thickness) == 0x34, "Offset mismatch for FRigUnit_VisualDebugQuat::Thickness");
static_assert(offsetof(FRigUnit_VisualDebugQuat, Scale) == 0x38, "Offset mismatch for FRigUnit_VisualDebugQuat::Scale");
static_assert(offsetof(FRigUnit_VisualDebugQuat, BoneSpace) == 0x3c, "Offset mismatch for FRigUnit_VisualDebugQuat::BoneSpace");

// Size: 0x50 (Inherited: 0x20, Single: 0x30)
struct FRigUnit_VisualDebugQuatItemSpace : FRigUnit_DebugBase
{
    FQuat Value; // 0x10 (Size: 0x20, Type: StructProperty)
    bool bEnabled; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x3]; // 0x31 (Size: 0x3, Type: PaddingProperty)
    float Thickness; // 0x34 (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x38 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space; // 0x3c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_44[0xc]; // 0x44 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_VisualDebugQuatItemSpace) == 0x50, "Size mismatch for FRigUnit_VisualDebugQuatItemSpace");
static_assert(offsetof(FRigUnit_VisualDebugQuatItemSpace, Value) == 0x10, "Offset mismatch for FRigUnit_VisualDebugQuatItemSpace::Value");
static_assert(offsetof(FRigUnit_VisualDebugQuatItemSpace, bEnabled) == 0x30, "Offset mismatch for FRigUnit_VisualDebugQuatItemSpace::bEnabled");
static_assert(offsetof(FRigUnit_VisualDebugQuatItemSpace, Thickness) == 0x34, "Offset mismatch for FRigUnit_VisualDebugQuatItemSpace::Thickness");
static_assert(offsetof(FRigUnit_VisualDebugQuatItemSpace, Scale) == 0x38, "Offset mismatch for FRigUnit_VisualDebugQuatItemSpace::Scale");
static_assert(offsetof(FRigUnit_VisualDebugQuatItemSpace, Space) == 0x3c, "Offset mismatch for FRigUnit_VisualDebugQuatItemSpace::Space");

// Size: 0x80 (Inherited: 0x20, Single: 0x60)
struct FRigUnit_VisualDebugTransform : FRigUnit_DebugBase
{
    FTransform Value; // 0x10 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x3]; // 0x71 (Size: 0x3, Type: PaddingProperty)
    float Thickness; // 0x74 (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x78 (Size: 0x4, Type: FloatProperty)
    FName BoneSpace; // 0x7c (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FRigUnit_VisualDebugTransform) == 0x80, "Size mismatch for FRigUnit_VisualDebugTransform");
static_assert(offsetof(FRigUnit_VisualDebugTransform, Value) == 0x10, "Offset mismatch for FRigUnit_VisualDebugTransform::Value");
static_assert(offsetof(FRigUnit_VisualDebugTransform, bEnabled) == 0x70, "Offset mismatch for FRigUnit_VisualDebugTransform::bEnabled");
static_assert(offsetof(FRigUnit_VisualDebugTransform, Thickness) == 0x74, "Offset mismatch for FRigUnit_VisualDebugTransform::Thickness");
static_assert(offsetof(FRigUnit_VisualDebugTransform, Scale) == 0x78, "Offset mismatch for FRigUnit_VisualDebugTransform::Scale");
static_assert(offsetof(FRigUnit_VisualDebugTransform, BoneSpace) == 0x7c, "Offset mismatch for FRigUnit_VisualDebugTransform::BoneSpace");

// Size: 0x90 (Inherited: 0x20, Single: 0x70)
struct FRigUnit_VisualDebugTransformItemSpace : FRigUnit_DebugBase
{
    FTransform Value; // 0x10 (Size: 0x60, Type: StructProperty)
    bool bEnabled; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x3]; // 0x71 (Size: 0x3, Type: PaddingProperty)
    float Thickness; // 0x74 (Size: 0x4, Type: FloatProperty)
    float Scale; // 0x78 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space; // 0x7c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_84[0xc]; // 0x84 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_VisualDebugTransformItemSpace) == 0x90, "Size mismatch for FRigUnit_VisualDebugTransformItemSpace");
static_assert(offsetof(FRigUnit_VisualDebugTransformItemSpace, Value) == 0x10, "Offset mismatch for FRigUnit_VisualDebugTransformItemSpace::Value");
static_assert(offsetof(FRigUnit_VisualDebugTransformItemSpace, bEnabled) == 0x70, "Offset mismatch for FRigUnit_VisualDebugTransformItemSpace::bEnabled");
static_assert(offsetof(FRigUnit_VisualDebugTransformItemSpace, Thickness) == 0x74, "Offset mismatch for FRigUnit_VisualDebugTransformItemSpace::Thickness");
static_assert(offsetof(FRigUnit_VisualDebugTransformItemSpace, Scale) == 0x78, "Offset mismatch for FRigUnit_VisualDebugTransformItemSpace::Scale");
static_assert(offsetof(FRigUnit_VisualDebugTransformItemSpace, Space) == 0x7c, "Offset mismatch for FRigUnit_VisualDebugTransformItemSpace::Space");

// Size: 0xc0 (Inherited: 0x10, Single: 0xb0)
struct FRigUnit_ConvertTransform : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform Input; // 0x10 (Size: 0x60, Type: StructProperty)
    FEulerTransform Result; // 0x70 (Size: 0x48, Type: StructProperty)
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ConvertTransform) == 0xc0, "Size mismatch for FRigUnit_ConvertTransform");
static_assert(offsetof(FRigUnit_ConvertTransform, Input) == 0x10, "Offset mismatch for FRigUnit_ConvertTransform::Input");
static_assert(offsetof(FRigUnit_ConvertTransform, Result) == 0x70, "Offset mismatch for FRigUnit_ConvertTransform::Result");

// Size: 0xb0 (Inherited: 0x10, Single: 0xa0)
struct FRigUnit_ConvertEulerTransform : FRigUnit
{
    FEulerTransform Input; // 0x8 (Size: 0x48, Type: StructProperty)
    FTransform Result; // 0x50 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ConvertEulerTransform) == 0xb0, "Size mismatch for FRigUnit_ConvertEulerTransform");
static_assert(offsetof(FRigUnit_ConvertEulerTransform, Input) == 0x8, "Offset mismatch for FRigUnit_ConvertEulerTransform::Input");
static_assert(offsetof(FRigUnit_ConvertEulerTransform, Result) == 0x50, "Offset mismatch for FRigUnit_ConvertEulerTransform::Result");

// Size: 0x40 (Inherited: 0x10, Single: 0x30)
struct FRigUnit_ConvertRotation : FRigUnit
{
    FRotator Input; // 0x8 (Size: 0x18, Type: StructProperty)
    FQuat Result; // 0x20 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ConvertRotation) == 0x40, "Size mismatch for FRigUnit_ConvertRotation");
static_assert(offsetof(FRigUnit_ConvertRotation, Input) == 0x8, "Offset mismatch for FRigUnit_ConvertRotation::Input");
static_assert(offsetof(FRigUnit_ConvertRotation, Result) == 0x20, "Offset mismatch for FRigUnit_ConvertRotation::Result");

// Size: 0x40 (Inherited: 0x50, Single: 0xfffffff0)
struct FRigUnit_ConvertVectorRotation : FRigUnit_ConvertRotation
{
};

static_assert(sizeof(FRigUnit_ConvertVectorRotation) == 0x40, "Size mismatch for FRigUnit_ConvertVectorRotation");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FRigUnit_ConvertQuaternion : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FQuat Input; // 0x10 (Size: 0x20, Type: StructProperty)
    FRotator Result; // 0x30 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ConvertQuaternion) == 0x50, "Size mismatch for FRigUnit_ConvertQuaternion");
static_assert(offsetof(FRigUnit_ConvertQuaternion, Input) == 0x10, "Offset mismatch for FRigUnit_ConvertQuaternion::Input");
static_assert(offsetof(FRigUnit_ConvertQuaternion, Result) == 0x30, "Offset mismatch for FRigUnit_ConvertQuaternion::Result");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FRigUnit_ConvertVectorToRotation : FRigUnit
{
    FVector Input; // 0x8 (Size: 0x18, Type: StructProperty)
    FRotator Result; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ConvertVectorToRotation) == 0x38, "Size mismatch for FRigUnit_ConvertVectorToRotation");
static_assert(offsetof(FRigUnit_ConvertVectorToRotation, Input) == 0x8, "Offset mismatch for FRigUnit_ConvertVectorToRotation::Input");
static_assert(offsetof(FRigUnit_ConvertVectorToRotation, Result) == 0x20, "Offset mismatch for FRigUnit_ConvertVectorToRotation::Result");

// Size: 0x40 (Inherited: 0x10, Single: 0x30)
struct FRigUnit_ConvertVectorToQuaternion : FRigUnit
{
    FVector Input; // 0x8 (Size: 0x18, Type: StructProperty)
    FQuat Result; // 0x20 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ConvertVectorToQuaternion) == 0x40, "Size mismatch for FRigUnit_ConvertVectorToQuaternion");
static_assert(offsetof(FRigUnit_ConvertVectorToQuaternion, Input) == 0x8, "Offset mismatch for FRigUnit_ConvertVectorToQuaternion::Input");
static_assert(offsetof(FRigUnit_ConvertVectorToQuaternion, Result) == 0x20, "Offset mismatch for FRigUnit_ConvertVectorToQuaternion::Result");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FRigUnit_ConvertRotationToVector : FRigUnit
{
    FRotator Input; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Result; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ConvertRotationToVector) == 0x38, "Size mismatch for FRigUnit_ConvertRotationToVector");
static_assert(offsetof(FRigUnit_ConvertRotationToVector, Input) == 0x8, "Offset mismatch for FRigUnit_ConvertRotationToVector::Input");
static_assert(offsetof(FRigUnit_ConvertRotationToVector, Result) == 0x20, "Offset mismatch for FRigUnit_ConvertRotationToVector::Result");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FRigUnit_ConvertQuaternionToVector : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FQuat Input; // 0x10 (Size: 0x20, Type: StructProperty)
    FVector Result; // 0x30 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ConvertQuaternionToVector) == 0x50, "Size mismatch for FRigUnit_ConvertQuaternionToVector");
static_assert(offsetof(FRigUnit_ConvertQuaternionToVector, Input) == 0x10, "Offset mismatch for FRigUnit_ConvertQuaternionToVector::Input");
static_assert(offsetof(FRigUnit_ConvertQuaternionToVector, Result) == 0x30, "Offset mismatch for FRigUnit_ConvertQuaternionToVector::Result");

// Size: 0x90 (Inherited: 0x10, Single: 0x80)
struct FRigUnit_ToSwingAndTwist : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FQuat Input; // 0x10 (Size: 0x20, Type: StructProperty)
    FVector TwistAxis; // 0x30 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
    FQuat Swing; // 0x50 (Size: 0x20, Type: StructProperty)
    FQuat Twist; // 0x70 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ToSwingAndTwist) == 0x90, "Size mismatch for FRigUnit_ToSwingAndTwist");
static_assert(offsetof(FRigUnit_ToSwingAndTwist, Input) == 0x10, "Offset mismatch for FRigUnit_ToSwingAndTwist::Input");
static_assert(offsetof(FRigUnit_ToSwingAndTwist, TwistAxis) == 0x30, "Offset mismatch for FRigUnit_ToSwingAndTwist::TwistAxis");
static_assert(offsetof(FRigUnit_ToSwingAndTwist, Swing) == 0x50, "Offset mismatch for FRigUnit_ToSwingAndTwist::Swing");
static_assert(offsetof(FRigUnit_ToSwingAndTwist, Twist) == 0x70, "Offset mismatch for FRigUnit_ToSwingAndTwist::Twist");

// Size: 0x18 (Inherited: 0x10, Single: 0x8)
struct FRigUnit_BinaryFloatOp : FRigUnit
{
    float Argument0; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Argument1; // 0xc (Size: 0x4, Type: FloatProperty)
    float Result; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_BinaryFloatOp) == 0x18, "Size mismatch for FRigUnit_BinaryFloatOp");
static_assert(offsetof(FRigUnit_BinaryFloatOp, Argument0) == 0x8, "Offset mismatch for FRigUnit_BinaryFloatOp::Argument0");
static_assert(offsetof(FRigUnit_BinaryFloatOp, Argument1) == 0xc, "Offset mismatch for FRigUnit_BinaryFloatOp::Argument1");
static_assert(offsetof(FRigUnit_BinaryFloatOp, Result) == 0x10, "Offset mismatch for FRigUnit_BinaryFloatOp::Result");

// Size: 0x18 (Inherited: 0x28, Single: 0xfffffff0)
struct FRigUnit_Multiply_FloatFloat : FRigUnit_BinaryFloatOp
{
};

static_assert(sizeof(FRigUnit_Multiply_FloatFloat) == 0x18, "Size mismatch for FRigUnit_Multiply_FloatFloat");

// Size: 0x18 (Inherited: 0x28, Single: 0xfffffff0)
struct FRigUnit_Add_FloatFloat : FRigUnit_BinaryFloatOp
{
};

static_assert(sizeof(FRigUnit_Add_FloatFloat) == 0x18, "Size mismatch for FRigUnit_Add_FloatFloat");

// Size: 0x18 (Inherited: 0x28, Single: 0xfffffff0)
struct FRigUnit_Subtract_FloatFloat : FRigUnit_BinaryFloatOp
{
};

static_assert(sizeof(FRigUnit_Subtract_FloatFloat) == 0x18, "Size mismatch for FRigUnit_Subtract_FloatFloat");

// Size: 0x18 (Inherited: 0x28, Single: 0xfffffff0)
struct FRigUnit_Divide_FloatFloat : FRigUnit_BinaryFloatOp
{
};

static_assert(sizeof(FRigUnit_Divide_FloatFloat) == 0x18, "Size mismatch for FRigUnit_Divide_FloatFloat");

// Size: 0x18 (Inherited: 0x10, Single: 0x8)
struct FRigUnit_Clamp_Float : FRigUnit
{
    float Value; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Min; // 0xc (Size: 0x4, Type: FloatProperty)
    float Max; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Result; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_Clamp_Float) == 0x18, "Size mismatch for FRigUnit_Clamp_Float");
static_assert(offsetof(FRigUnit_Clamp_Float, Value) == 0x8, "Offset mismatch for FRigUnit_Clamp_Float::Value");
static_assert(offsetof(FRigUnit_Clamp_Float, Min) == 0xc, "Offset mismatch for FRigUnit_Clamp_Float::Min");
static_assert(offsetof(FRigUnit_Clamp_Float, Max) == 0x10, "Offset mismatch for FRigUnit_Clamp_Float::Max");
static_assert(offsetof(FRigUnit_Clamp_Float, Result) == 0x14, "Offset mismatch for FRigUnit_Clamp_Float::Result");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FRigUnit_MapRange_Float : FRigUnit
{
    float Value; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinIn; // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxIn; // 0x10 (Size: 0x4, Type: FloatProperty)
    float MinOut; // 0x14 (Size: 0x4, Type: FloatProperty)
    float MaxOut; // 0x18 (Size: 0x4, Type: FloatProperty)
    float Result; // 0x1c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_MapRange_Float) == 0x20, "Size mismatch for FRigUnit_MapRange_Float");
static_assert(offsetof(FRigUnit_MapRange_Float, Value) == 0x8, "Offset mismatch for FRigUnit_MapRange_Float::Value");
static_assert(offsetof(FRigUnit_MapRange_Float, MinIn) == 0xc, "Offset mismatch for FRigUnit_MapRange_Float::MinIn");
static_assert(offsetof(FRigUnit_MapRange_Float, MaxIn) == 0x10, "Offset mismatch for FRigUnit_MapRange_Float::MaxIn");
static_assert(offsetof(FRigUnit_MapRange_Float, MinOut) == 0x14, "Offset mismatch for FRigUnit_MapRange_Float::MinOut");
static_assert(offsetof(FRigUnit_MapRange_Float, MaxOut) == 0x18, "Offset mismatch for FRigUnit_MapRange_Float::MaxOut");
static_assert(offsetof(FRigUnit_MapRange_Float, Result) == 0x1c, "Offset mismatch for FRigUnit_MapRange_Float::Result");

// Size: 0x70 (Inherited: 0x10, Single: 0x60)
struct FRigUnit_BinaryQuaternionOp : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FQuat Argument0; // 0x10 (Size: 0x20, Type: StructProperty)
    FQuat Argument1; // 0x30 (Size: 0x20, Type: StructProperty)
    FQuat Result; // 0x50 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_BinaryQuaternionOp) == 0x70, "Size mismatch for FRigUnit_BinaryQuaternionOp");
static_assert(offsetof(FRigUnit_BinaryQuaternionOp, Argument0) == 0x10, "Offset mismatch for FRigUnit_BinaryQuaternionOp::Argument0");
static_assert(offsetof(FRigUnit_BinaryQuaternionOp, Argument1) == 0x30, "Offset mismatch for FRigUnit_BinaryQuaternionOp::Argument1");
static_assert(offsetof(FRigUnit_BinaryQuaternionOp, Result) == 0x50, "Offset mismatch for FRigUnit_BinaryQuaternionOp::Result");

// Size: 0x70 (Inherited: 0x80, Single: 0xfffffff0)
struct FRigUnit_MultiplyQuaternion : FRigUnit_BinaryQuaternionOp
{
};

static_assert(sizeof(FRigUnit_MultiplyQuaternion) == 0x70, "Size mismatch for FRigUnit_MultiplyQuaternion");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FRigUnit_UnaryQuaternionOp : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FQuat Argument; // 0x10 (Size: 0x20, Type: StructProperty)
    FQuat Result; // 0x30 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_UnaryQuaternionOp) == 0x50, "Size mismatch for FRigUnit_UnaryQuaternionOp");
static_assert(offsetof(FRigUnit_UnaryQuaternionOp, Argument) == 0x10, "Offset mismatch for FRigUnit_UnaryQuaternionOp::Argument");
static_assert(offsetof(FRigUnit_UnaryQuaternionOp, Result) == 0x30, "Offset mismatch for FRigUnit_UnaryQuaternionOp::Result");

// Size: 0x50 (Inherited: 0x60, Single: 0xfffffff0)
struct FRigUnit_InverseQuaterion : FRigUnit_UnaryQuaternionOp
{
};

static_assert(sizeof(FRigUnit_InverseQuaterion) == 0x50, "Size mismatch for FRigUnit_InverseQuaterion");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FRigUnit_QuaternionToAxisAndAngle : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FQuat Argument; // 0x10 (Size: 0x20, Type: StructProperty)
    FVector Axis; // 0x30 (Size: 0x18, Type: StructProperty)
    float Angle; // 0x48 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_QuaternionToAxisAndAngle) == 0x50, "Size mismatch for FRigUnit_QuaternionToAxisAndAngle");
static_assert(offsetof(FRigUnit_QuaternionToAxisAndAngle, Argument) == 0x10, "Offset mismatch for FRigUnit_QuaternionToAxisAndAngle::Argument");
static_assert(offsetof(FRigUnit_QuaternionToAxisAndAngle, Axis) == 0x30, "Offset mismatch for FRigUnit_QuaternionToAxisAndAngle::Axis");
static_assert(offsetof(FRigUnit_QuaternionToAxisAndAngle, Angle) == 0x48, "Offset mismatch for FRigUnit_QuaternionToAxisAndAngle::Angle");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FRigUnit_QuaternionFromAxisAndAngle : FRigUnit
{
    FVector Axis; // 0x8 (Size: 0x18, Type: StructProperty)
    float Angle; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0xc]; // 0x24 (Size: 0xc, Type: PaddingProperty)
    FQuat Result; // 0x30 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_QuaternionFromAxisAndAngle) == 0x50, "Size mismatch for FRigUnit_QuaternionFromAxisAndAngle");
static_assert(offsetof(FRigUnit_QuaternionFromAxisAndAngle, Axis) == 0x8, "Offset mismatch for FRigUnit_QuaternionFromAxisAndAngle::Axis");
static_assert(offsetof(FRigUnit_QuaternionFromAxisAndAngle, Angle) == 0x20, "Offset mismatch for FRigUnit_QuaternionFromAxisAndAngle::Angle");
static_assert(offsetof(FRigUnit_QuaternionFromAxisAndAngle, Result) == 0x30, "Offset mismatch for FRigUnit_QuaternionFromAxisAndAngle::Result");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FRigUnit_QuaternionToAngle : FRigUnit
{
    FVector Axis; // 0x8 (Size: 0x18, Type: StructProperty)
    FQuat Argument; // 0x20 (Size: 0x20, Type: StructProperty)
    float Angle; // 0x40 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_44[0xc]; // 0x44 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_QuaternionToAngle) == 0x50, "Size mismatch for FRigUnit_QuaternionToAngle");
static_assert(offsetof(FRigUnit_QuaternionToAngle, Axis) == 0x8, "Offset mismatch for FRigUnit_QuaternionToAngle::Axis");
static_assert(offsetof(FRigUnit_QuaternionToAngle, Argument) == 0x20, "Offset mismatch for FRigUnit_QuaternionToAngle::Argument");
static_assert(offsetof(FRigUnit_QuaternionToAngle, Angle) == 0x40, "Offset mismatch for FRigUnit_QuaternionToAngle::Angle");

// Size: 0x130 (Inherited: 0x10, Single: 0x120)
struct FRigUnit_BinaryTransformOp : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform Argument0; // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform Argument1; // 0x70 (Size: 0x60, Type: StructProperty)
    FTransform Result; // 0xd0 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_BinaryTransformOp) == 0x130, "Size mismatch for FRigUnit_BinaryTransformOp");
static_assert(offsetof(FRigUnit_BinaryTransformOp, Argument0) == 0x10, "Offset mismatch for FRigUnit_BinaryTransformOp::Argument0");
static_assert(offsetof(FRigUnit_BinaryTransformOp, Argument1) == 0x70, "Offset mismatch for FRigUnit_BinaryTransformOp::Argument1");
static_assert(offsetof(FRigUnit_BinaryTransformOp, Result) == 0xd0, "Offset mismatch for FRigUnit_BinaryTransformOp::Result");

// Size: 0x130 (Inherited: 0x140, Single: 0xfffffff0)
struct FRigUnit_MultiplyTransform : FRigUnit_BinaryTransformOp
{
};

static_assert(sizeof(FRigUnit_MultiplyTransform) == 0x130, "Size mismatch for FRigUnit_MultiplyTransform");

// Size: 0x130 (Inherited: 0x140, Single: 0xfffffff0)
struct FRigUnit_GetRelativeTransform : FRigUnit_BinaryTransformOp
{
};

static_assert(sizeof(FRigUnit_GetRelativeTransform) == 0x130, "Size mismatch for FRigUnit_GetRelativeTransform");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FRigUnit_BinaryVectorOp : FRigUnit
{
    FVector Argument0; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Argument1; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector Result; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_BinaryVectorOp) == 0x50, "Size mismatch for FRigUnit_BinaryVectorOp");
static_assert(offsetof(FRigUnit_BinaryVectorOp, Argument0) == 0x8, "Offset mismatch for FRigUnit_BinaryVectorOp::Argument0");
static_assert(offsetof(FRigUnit_BinaryVectorOp, Argument1) == 0x20, "Offset mismatch for FRigUnit_BinaryVectorOp::Argument1");
static_assert(offsetof(FRigUnit_BinaryVectorOp, Result) == 0x38, "Offset mismatch for FRigUnit_BinaryVectorOp::Result");

// Size: 0x50 (Inherited: 0x60, Single: 0xfffffff0)
struct FRigUnit_Multiply_VectorVector : FRigUnit_BinaryVectorOp
{
};

static_assert(sizeof(FRigUnit_Multiply_VectorVector) == 0x50, "Size mismatch for FRigUnit_Multiply_VectorVector");

// Size: 0x50 (Inherited: 0x60, Single: 0xfffffff0)
struct FRigUnit_Add_VectorVector : FRigUnit_BinaryVectorOp
{
};

static_assert(sizeof(FRigUnit_Add_VectorVector) == 0x50, "Size mismatch for FRigUnit_Add_VectorVector");

// Size: 0x50 (Inherited: 0x60, Single: 0xfffffff0)
struct FRigUnit_Subtract_VectorVector : FRigUnit_BinaryVectorOp
{
};

static_assert(sizeof(FRigUnit_Subtract_VectorVector) == 0x50, "Size mismatch for FRigUnit_Subtract_VectorVector");

// Size: 0x50 (Inherited: 0x60, Single: 0xfffffff0)
struct FRigUnit_Divide_VectorVector : FRigUnit_BinaryVectorOp
{
};

static_assert(sizeof(FRigUnit_Divide_VectorVector) == 0x50, "Size mismatch for FRigUnit_Divide_VectorVector");

// Size: 0x40 (Inherited: 0x10, Single: 0x30)
struct FRigUnit_Distance_VectorVector : FRigUnit
{
    FVector Argument0; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Argument1; // 0x20 (Size: 0x18, Type: StructProperty)
    float Result; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_Distance_VectorVector) == 0x40, "Size mismatch for FRigUnit_Distance_VectorVector");
static_assert(offsetof(FRigUnit_Distance_VectorVector, Argument0) == 0x8, "Offset mismatch for FRigUnit_Distance_VectorVector::Argument0");
static_assert(offsetof(FRigUnit_Distance_VectorVector, Argument1) == 0x20, "Offset mismatch for FRigUnit_Distance_VectorVector::Argument1");
static_assert(offsetof(FRigUnit_Distance_VectorVector, Result) == 0x38, "Offset mismatch for FRigUnit_Distance_VectorVector::Result");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FAimTarget
{
    float Weight; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0xc]; // 0x4 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
    FVector AlignVector; // 0x70 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAimTarget) == 0x90, "Size mismatch for FAimTarget");
static_assert(offsetof(FAimTarget, Weight) == 0x0, "Offset mismatch for FAimTarget::Weight");
static_assert(offsetof(FAimTarget, Transform) == 0x10, "Offset mismatch for FAimTarget::Transform");
static_assert(offsetof(FAimTarget, AlignVector) == 0x70, "Offset mismatch for FAimTarget::AlignVector");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigUnit_AimConstraint_WorkData
{
    TArray<FConstraintData> ConstraintData; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_AimConstraint_WorkData) == 0x10, "Size mismatch for FRigUnit_AimConstraint_WorkData");
static_assert(offsetof(FRigUnit_AimConstraint_WorkData, ConstraintData) == 0x0, "Offset mismatch for FRigUnit_AimConstraint_WorkData::ConstraintData");

// Size: 0x78 (Inherited: 0x20, Single: 0x58)
struct FRigUnit_AimConstraint : FRigUnitMutable
{
    FName Joint; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t AimMode; // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t UpMode; // 0x15 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_16[0x2]; // 0x16 (Size: 0x2, Type: PaddingProperty)
    FVector AimVector; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector UpVector; // 0x30 (Size: 0x18, Type: StructProperty)
    TArray<FAimTarget> AimTargets; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FAimTarget> UpTargets; // 0x58 (Size: 0x10, Type: ArrayProperty)
    FRigUnit_AimConstraint_WorkData WorkData; // 0x68 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_AimConstraint) == 0x78, "Size mismatch for FRigUnit_AimConstraint");
static_assert(offsetof(FRigUnit_AimConstraint, Joint) == 0x10, "Offset mismatch for FRigUnit_AimConstraint::Joint");
static_assert(offsetof(FRigUnit_AimConstraint, AimMode) == 0x14, "Offset mismatch for FRigUnit_AimConstraint::AimMode");
static_assert(offsetof(FRigUnit_AimConstraint, UpMode) == 0x15, "Offset mismatch for FRigUnit_AimConstraint::UpMode");
static_assert(offsetof(FRigUnit_AimConstraint, AimVector) == 0x18, "Offset mismatch for FRigUnit_AimConstraint::AimVector");
static_assert(offsetof(FRigUnit_AimConstraint, UpVector) == 0x30, "Offset mismatch for FRigUnit_AimConstraint::UpVector");
static_assert(offsetof(FRigUnit_AimConstraint, AimTargets) == 0x48, "Offset mismatch for FRigUnit_AimConstraint::AimTargets");
static_assert(offsetof(FRigUnit_AimConstraint, UpTargets) == 0x58, "Offset mismatch for FRigUnit_AimConstraint::UpTargets");
static_assert(offsetof(FRigUnit_AimConstraint, WorkData) == 0x68, "Offset mismatch for FRigUnit_AimConstraint::WorkData");

// Size: 0x100 (Inherited: 0x20, Single: 0xe0)
struct FRigUnit_ApplyFK : FRigUnitMutable
{
    FName Joint; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    FTransformFilter Filter; // 0x80 (Size: 0x9, Type: StructProperty)
    uint8_t ApplyTransformMode; // 0x89 (Size: 0x1, Type: EnumProperty)
    uint8_t ApplyTransformSpace; // 0x8a (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_8b[0x5]; // 0x8b (Size: 0x5, Type: PaddingProperty)
    FTransform BaseTransform; // 0x90 (Size: 0x60, Type: StructProperty)
    FName BaseJoint; // 0xf0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_f4[0xc]; // 0xf4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ApplyFK) == 0x100, "Size mismatch for FRigUnit_ApplyFK");
static_assert(offsetof(FRigUnit_ApplyFK, Joint) == 0x10, "Offset mismatch for FRigUnit_ApplyFK::Joint");
static_assert(offsetof(FRigUnit_ApplyFK, Transform) == 0x20, "Offset mismatch for FRigUnit_ApplyFK::Transform");
static_assert(offsetof(FRigUnit_ApplyFK, Filter) == 0x80, "Offset mismatch for FRigUnit_ApplyFK::Filter");
static_assert(offsetof(FRigUnit_ApplyFK, ApplyTransformMode) == 0x89, "Offset mismatch for FRigUnit_ApplyFK::ApplyTransformMode");
static_assert(offsetof(FRigUnit_ApplyFK, ApplyTransformSpace) == 0x8a, "Offset mismatch for FRigUnit_ApplyFK::ApplyTransformSpace");
static_assert(offsetof(FRigUnit_ApplyFK, BaseTransform) == 0x90, "Offset mismatch for FRigUnit_ApplyFK::BaseTransform");
static_assert(offsetof(FRigUnit_ApplyFK, BaseJoint) == 0xf0, "Offset mismatch for FRigUnit_ApplyFK::BaseJoint");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FBlendTarget
{
    FTransform Transform; // 0x0 (Size: 0x60, Type: StructProperty)
    float Weight; // 0x60 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_64[0xc]; // 0x64 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FBlendTarget) == 0x70, "Size mismatch for FBlendTarget");
static_assert(offsetof(FBlendTarget, Transform) == 0x0, "Offset mismatch for FBlendTarget::Transform");
static_assert(offsetof(FBlendTarget, Weight) == 0x60, "Offset mismatch for FBlendTarget::Weight");

// Size: 0xe0 (Inherited: 0x10, Single: 0xd0)
struct FRigUnit_BlendTransform : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform Source; // 0x10 (Size: 0x60, Type: StructProperty)
    TArray<FBlendTarget> Targets; // 0x70 (Size: 0x10, Type: ArrayProperty)
    FTransform Result; // 0x80 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_BlendTransform) == 0xe0, "Size mismatch for FRigUnit_BlendTransform");
static_assert(offsetof(FRigUnit_BlendTransform, Source) == 0x10, "Offset mismatch for FRigUnit_BlendTransform::Source");
static_assert(offsetof(FRigUnit_BlendTransform, Targets) == 0x70, "Offset mismatch for FRigUnit_BlendTransform::Targets");
static_assert(offsetof(FRigUnit_BlendTransform, Result) == 0x80, "Offset mismatch for FRigUnit_BlendTransform::Result");

// Size: 0xf0 (Inherited: 0x20, Single: 0xd0)
struct FRigUnit_GetJointTransform : FRigUnitMutable
{
    FName Joint; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Type; // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t TransformSpace; // 0x15 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_16[0xa]; // 0x16 (Size: 0xa, Type: PaddingProperty)
    FTransform BaseTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    FName BaseJoint; // 0x80 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_84[0xc]; // 0x84 (Size: 0xc, Type: PaddingProperty)
    FTransform Output; // 0x90 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetJointTransform) == 0xf0, "Size mismatch for FRigUnit_GetJointTransform");
static_assert(offsetof(FRigUnit_GetJointTransform, Joint) == 0x10, "Offset mismatch for FRigUnit_GetJointTransform::Joint");
static_assert(offsetof(FRigUnit_GetJointTransform, Type) == 0x14, "Offset mismatch for FRigUnit_GetJointTransform::Type");
static_assert(offsetof(FRigUnit_GetJointTransform, TransformSpace) == 0x15, "Offset mismatch for FRigUnit_GetJointTransform::TransformSpace");
static_assert(offsetof(FRigUnit_GetJointTransform, BaseTransform) == 0x20, "Offset mismatch for FRigUnit_GetJointTransform::BaseTransform");
static_assert(offsetof(FRigUnit_GetJointTransform, BaseJoint) == 0x80, "Offset mismatch for FRigUnit_GetJointTransform::BaseJoint");
static_assert(offsetof(FRigUnit_GetJointTransform, Output) == 0x90, "Offset mismatch for FRigUnit_GetJointTransform::Output");

// Size: 0x320 (Inherited: 0x20, Single: 0x300)
struct FRigUnit_TwoBoneIKFK : FRigUnitMutable
{
    FName StartJoint; // 0x10 (Size: 0x4, Type: NameProperty)
    FName EndJoint; // 0x14 (Size: 0x4, Type: NameProperty)
    FVector PoleTarget; // 0x18 (Size: 0x18, Type: StructProperty)
    float Spin; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0xc]; // 0x34 (Size: 0xc, Type: PaddingProperty)
    FTransform EndEffector; // 0x40 (Size: 0x60, Type: StructProperty)
    float IKBlend; // 0xa0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_a4[0xc]; // 0xa4 (Size: 0xc, Type: PaddingProperty)
    FTransform StartJointFKTransform; // 0xb0 (Size: 0x60, Type: StructProperty)
    FTransform MidJointFKTransform; // 0x110 (Size: 0x60, Type: StructProperty)
    FTransform EndJointFKTransform; // 0x170 (Size: 0x60, Type: StructProperty)
    float PreviousFKIKBlend; // 0x1d0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1d4[0xc]; // 0x1d4 (Size: 0xc, Type: PaddingProperty)
    FTransform StartJointIKTransform; // 0x1e0 (Size: 0x60, Type: StructProperty)
    FTransform MidJointIKTransform; // 0x240 (Size: 0x60, Type: StructProperty)
    FTransform EndJointIKTransform; // 0x2a0 (Size: 0x60, Type: StructProperty)
    int32_t StartJointIndex; // 0x300 (Size: 0x4, Type: IntProperty)
    int32_t MidJointIndex; // 0x304 (Size: 0x4, Type: IntProperty)
    int32_t EndJointIndex; // 0x308 (Size: 0x4, Type: IntProperty)
    float UpperLimbLength; // 0x30c (Size: 0x4, Type: FloatProperty)
    float LowerLimbLength; // 0x310 (Size: 0x4, Type: FloatProperty)
    bool bIsInitialized; // 0x314 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_315[0xb]; // 0x315 (Size: 0xb, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_TwoBoneIKFK) == 0x320, "Size mismatch for FRigUnit_TwoBoneIKFK");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, StartJoint) == 0x10, "Offset mismatch for FRigUnit_TwoBoneIKFK::StartJoint");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, EndJoint) == 0x14, "Offset mismatch for FRigUnit_TwoBoneIKFK::EndJoint");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, PoleTarget) == 0x18, "Offset mismatch for FRigUnit_TwoBoneIKFK::PoleTarget");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, Spin) == 0x30, "Offset mismatch for FRigUnit_TwoBoneIKFK::Spin");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, EndEffector) == 0x40, "Offset mismatch for FRigUnit_TwoBoneIKFK::EndEffector");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, IKBlend) == 0xa0, "Offset mismatch for FRigUnit_TwoBoneIKFK::IKBlend");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, StartJointFKTransform) == 0xb0, "Offset mismatch for FRigUnit_TwoBoneIKFK::StartJointFKTransform");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, MidJointFKTransform) == 0x110, "Offset mismatch for FRigUnit_TwoBoneIKFK::MidJointFKTransform");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, EndJointFKTransform) == 0x170, "Offset mismatch for FRigUnit_TwoBoneIKFK::EndJointFKTransform");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, PreviousFKIKBlend) == 0x1d0, "Offset mismatch for FRigUnit_TwoBoneIKFK::PreviousFKIKBlend");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, StartJointIKTransform) == 0x1e0, "Offset mismatch for FRigUnit_TwoBoneIKFK::StartJointIKTransform");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, MidJointIKTransform) == 0x240, "Offset mismatch for FRigUnit_TwoBoneIKFK::MidJointIKTransform");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, EndJointIKTransform) == 0x2a0, "Offset mismatch for FRigUnit_TwoBoneIKFK::EndJointIKTransform");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, StartJointIndex) == 0x300, "Offset mismatch for FRigUnit_TwoBoneIKFK::StartJointIndex");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, MidJointIndex) == 0x304, "Offset mismatch for FRigUnit_TwoBoneIKFK::MidJointIndex");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, EndJointIndex) == 0x308, "Offset mismatch for FRigUnit_TwoBoneIKFK::EndJointIndex");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, UpperLimbLength) == 0x30c, "Offset mismatch for FRigUnit_TwoBoneIKFK::UpperLimbLength");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, LowerLimbLength) == 0x310, "Offset mismatch for FRigUnit_TwoBoneIKFK::LowerLimbLength");
static_assert(offsetof(FRigUnit_TwoBoneIKFK, bIsInitialized) == 0x314, "Offset mismatch for FRigUnit_TwoBoneIKFK::bIsInitialized");

// Size: 0x80 (Inherited: 0x10, Single: 0x70)
struct FRigUnit_DrawContainerGetInstruction : FRigUnit
{
    FName InstructionName; // 0x8 (Size: 0x4, Type: NameProperty)
    FLinearColor Color; // 0xc (Size: 0x10, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_DrawContainerGetInstruction) == 0x80, "Size mismatch for FRigUnit_DrawContainerGetInstruction");
static_assert(offsetof(FRigUnit_DrawContainerGetInstruction, InstructionName) == 0x8, "Offset mismatch for FRigUnit_DrawContainerGetInstruction::InstructionName");
static_assert(offsetof(FRigUnit_DrawContainerGetInstruction, Color) == 0xc, "Offset mismatch for FRigUnit_DrawContainerGetInstruction::Color");
static_assert(offsetof(FRigUnit_DrawContainerGetInstruction, Transform) == 0x20, "Offset mismatch for FRigUnit_DrawContainerGetInstruction::Transform");

// Size: 0x28 (Inherited: 0x20, Single: 0x8)
struct FRigUnit_DrawContainerSetColor : FRigUnitMutable
{
    FName InstructionName; // 0x10 (Size: 0x4, Type: NameProperty)
    FLinearColor Color; // 0x14 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DrawContainerSetColor) == 0x28, "Size mismatch for FRigUnit_DrawContainerSetColor");
static_assert(offsetof(FRigUnit_DrawContainerSetColor, InstructionName) == 0x10, "Offset mismatch for FRigUnit_DrawContainerSetColor::InstructionName");
static_assert(offsetof(FRigUnit_DrawContainerSetColor, Color) == 0x14, "Offset mismatch for FRigUnit_DrawContainerSetColor::Color");

// Size: 0x18 (Inherited: 0x20, Single: 0xfffffff8)
struct FRigUnit_DrawContainerSetThickness : FRigUnitMutable
{
    FName InstructionName; // 0x10 (Size: 0x4, Type: NameProperty)
    float Thickness; // 0x14 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_DrawContainerSetThickness) == 0x18, "Size mismatch for FRigUnit_DrawContainerSetThickness");
static_assert(offsetof(FRigUnit_DrawContainerSetThickness, InstructionName) == 0x10, "Offset mismatch for FRigUnit_DrawContainerSetThickness::InstructionName");
static_assert(offsetof(FRigUnit_DrawContainerSetThickness, Thickness) == 0x14, "Offset mismatch for FRigUnit_DrawContainerSetThickness::Thickness");

// Size: 0x80 (Inherited: 0x20, Single: 0x60)
struct FRigUnit_DrawContainerSetTransform : FRigUnitMutable
{
    FName InstructionName; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_DrawContainerSetTransform) == 0x80, "Size mismatch for FRigUnit_DrawContainerSetTransform");
static_assert(offsetof(FRigUnit_DrawContainerSetTransform, InstructionName) == 0x10, "Offset mismatch for FRigUnit_DrawContainerSetTransform::InstructionName");
static_assert(offsetof(FRigUnit_DrawContainerSetTransform, Transform) == 0x20, "Offset mismatch for FRigUnit_DrawContainerSetTransform::Transform");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_BeginExecution : FRigUnit
{
    FRigVMExecutePin ExecutePin; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_BeginExecution) == 0x10, "Size mismatch for FRigUnit_BeginExecution");
static_assert(offsetof(FRigUnit_BeginExecution, ExecutePin) == 0x8, "Offset mismatch for FRigUnit_BeginExecution::ExecutePin");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_PreBeginExecution : FRigUnit
{
    FRigVMExecutePin ExecutePin; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_PreBeginExecution) == 0x10, "Size mismatch for FRigUnit_PreBeginExecution");
static_assert(offsetof(FRigUnit_PreBeginExecution, ExecutePin) == 0x8, "Offset mismatch for FRigUnit_PreBeginExecution::ExecutePin");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_PostBeginExecution : FRigUnit
{
    FRigVMExecutePin ExecutePin; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_PostBeginExecution) == 0x10, "Size mismatch for FRigUnit_PostBeginExecution");
static_assert(offsetof(FRigUnit_PostBeginExecution, ExecutePin) == 0x8, "Offset mismatch for FRigUnit_PostBeginExecution::ExecutePin");

// Size: 0x8 (Inherited: 0x10, Single: 0xfffffff8)
struct FRigUnit_CollectionBase : FRigUnit
{
};

static_assert(sizeof(FRigUnit_CollectionBase) == 0x8, "Size mismatch for FRigUnit_CollectionBase");

// Size: 0x10 (Inherited: 0x20, Single: 0xfffffff0)
struct FRigUnit_CollectionBaseMutable : FRigUnitMutable
{
};

static_assert(sizeof(FRigUnit_CollectionBaseMutable) == 0x10, "Size mismatch for FRigUnit_CollectionBaseMutable");

// Size: 0x30 (Inherited: 0x18, Single: 0x18)
struct FRigUnit_CollectionChain : FRigUnit_CollectionBase
{
    FRigElementKey FirstItem; // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey LastItem; // 0x10 (Size: 0x8, Type: StructProperty)
    bool Reverse; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    FRigElementKeyCollection Collection; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CollectionChain) == 0x30, "Size mismatch for FRigUnit_CollectionChain");
static_assert(offsetof(FRigUnit_CollectionChain, FirstItem) == 0x8, "Offset mismatch for FRigUnit_CollectionChain::FirstItem");
static_assert(offsetof(FRigUnit_CollectionChain, LastItem) == 0x10, "Offset mismatch for FRigUnit_CollectionChain::LastItem");
static_assert(offsetof(FRigUnit_CollectionChain, Reverse) == 0x18, "Offset mismatch for FRigUnit_CollectionChain::Reverse");
static_assert(offsetof(FRigUnit_CollectionChain, Collection) == 0x20, "Offset mismatch for FRigUnit_CollectionChain::Collection");

// Size: 0x30 (Inherited: 0x18, Single: 0x18)
struct FRigUnit_CollectionChainArray : FRigUnit_CollectionBase
{
    FRigElementKey FirstItem; // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey LastItem; // 0x10 (Size: 0x8, Type: StructProperty)
    bool Reverse; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    TArray<FRigElementKey> Items; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_CollectionChainArray) == 0x30, "Size mismatch for FRigUnit_CollectionChainArray");
static_assert(offsetof(FRigUnit_CollectionChainArray, FirstItem) == 0x8, "Offset mismatch for FRigUnit_CollectionChainArray::FirstItem");
static_assert(offsetof(FRigUnit_CollectionChainArray, LastItem) == 0x10, "Offset mismatch for FRigUnit_CollectionChainArray::LastItem");
static_assert(offsetof(FRigUnit_CollectionChainArray, Reverse) == 0x18, "Offset mismatch for FRigUnit_CollectionChainArray::Reverse");
static_assert(offsetof(FRigUnit_CollectionChainArray, Items) == 0x20, "Offset mismatch for FRigUnit_CollectionChainArray::Items");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigUnit_CollectionNameSearch : FRigUnit_CollectionBase
{
    FName PartialName; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t TypeToSearch; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FRigElementKeyCollection Collection; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CollectionNameSearch) == 0x20, "Size mismatch for FRigUnit_CollectionNameSearch");
static_assert(offsetof(FRigUnit_CollectionNameSearch, PartialName) == 0x8, "Offset mismatch for FRigUnit_CollectionNameSearch::PartialName");
static_assert(offsetof(FRigUnit_CollectionNameSearch, TypeToSearch) == 0xc, "Offset mismatch for FRigUnit_CollectionNameSearch::TypeToSearch");
static_assert(offsetof(FRigUnit_CollectionNameSearch, Collection) == 0x10, "Offset mismatch for FRigUnit_CollectionNameSearch::Collection");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigUnit_CollectionNameSearchArray : FRigUnit_CollectionBase
{
    FName PartialName; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t TypeToSearch; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_CollectionNameSearchArray) == 0x20, "Size mismatch for FRigUnit_CollectionNameSearchArray");
static_assert(offsetof(FRigUnit_CollectionNameSearchArray, PartialName) == 0x8, "Offset mismatch for FRigUnit_CollectionNameSearchArray::PartialName");
static_assert(offsetof(FRigUnit_CollectionNameSearchArray, TypeToSearch) == 0xc, "Offset mismatch for FRigUnit_CollectionNameSearchArray::TypeToSearch");
static_assert(offsetof(FRigUnit_CollectionNameSearchArray, Items) == 0x10, "Offset mismatch for FRigUnit_CollectionNameSearchArray::Items");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigUnit_CollectionChildren : FRigUnit_CollectionBase
{
    FRigElementKey Parent; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeParent; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bRecursive; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t TypeToSearch; // 0x12 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_13[0x5]; // 0x13 (Size: 0x5, Type: PaddingProperty)
    FRigElementKeyCollection Collection; // 0x18 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CollectionChildren) == 0x28, "Size mismatch for FRigUnit_CollectionChildren");
static_assert(offsetof(FRigUnit_CollectionChildren, Parent) == 0x8, "Offset mismatch for FRigUnit_CollectionChildren::Parent");
static_assert(offsetof(FRigUnit_CollectionChildren, bIncludeParent) == 0x10, "Offset mismatch for FRigUnit_CollectionChildren::bIncludeParent");
static_assert(offsetof(FRigUnit_CollectionChildren, bRecursive) == 0x11, "Offset mismatch for FRigUnit_CollectionChildren::bRecursive");
static_assert(offsetof(FRigUnit_CollectionChildren, TypeToSearch) == 0x12, "Offset mismatch for FRigUnit_CollectionChildren::TypeToSearch");
static_assert(offsetof(FRigUnit_CollectionChildren, Collection) == 0x18, "Offset mismatch for FRigUnit_CollectionChildren::Collection");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigUnit_CollectionChildrenArray : FRigUnit_CollectionBase
{
    FRigElementKey Parent; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeParent; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bRecursive; // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bDefaultChildren; // 0x12 (Size: 0x1, Type: BoolProperty)
    uint8_t TypeToSearch; // 0x13 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    TArray<FRigElementKey> Items; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_CollectionChildrenArray) == 0x28, "Size mismatch for FRigUnit_CollectionChildrenArray");
static_assert(offsetof(FRigUnit_CollectionChildrenArray, Parent) == 0x8, "Offset mismatch for FRigUnit_CollectionChildrenArray::Parent");
static_assert(offsetof(FRigUnit_CollectionChildrenArray, bIncludeParent) == 0x10, "Offset mismatch for FRigUnit_CollectionChildrenArray::bIncludeParent");
static_assert(offsetof(FRigUnit_CollectionChildrenArray, bRecursive) == 0x11, "Offset mismatch for FRigUnit_CollectionChildrenArray::bRecursive");
static_assert(offsetof(FRigUnit_CollectionChildrenArray, bDefaultChildren) == 0x12, "Offset mismatch for FRigUnit_CollectionChildrenArray::bDefaultChildren");
static_assert(offsetof(FRigUnit_CollectionChildrenArray, TypeToSearch) == 0x13, "Offset mismatch for FRigUnit_CollectionChildrenArray::TypeToSearch");
static_assert(offsetof(FRigUnit_CollectionChildrenArray, Items) == 0x18, "Offset mismatch for FRigUnit_CollectionChildrenArray::Items");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigUnit_CollectionGetAll : FRigUnit_CollectionBase
{
    uint8_t TypeToSearch; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_CollectionGetAll) == 0x20, "Size mismatch for FRigUnit_CollectionGetAll");
static_assert(offsetof(FRigUnit_CollectionGetAll, TypeToSearch) == 0x8, "Offset mismatch for FRigUnit_CollectionGetAll::TypeToSearch");
static_assert(offsetof(FRigUnit_CollectionGetAll, Items) == 0x10, "Offset mismatch for FRigUnit_CollectionGetAll::Items");

// Size: 0x38 (Inherited: 0x18, Single: 0x20)
struct FRigUnit_CollectionReplaceItems : FRigUnit_CollectionBase
{
    FRigElementKeyCollection Items; // 0x8 (Size: 0x10, Type: StructProperty)
    FName Old; // 0x18 (Size: 0x4, Type: NameProperty)
    FName New; // 0x1c (Size: 0x4, Type: NameProperty)
    bool RemoveInvalidItems; // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bAllowDuplicates; // 0x21 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_22[0x6]; // 0x22 (Size: 0x6, Type: PaddingProperty)
    FRigElementKeyCollection Collection; // 0x28 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CollectionReplaceItems) == 0x38, "Size mismatch for FRigUnit_CollectionReplaceItems");
static_assert(offsetof(FRigUnit_CollectionReplaceItems, Items) == 0x8, "Offset mismatch for FRigUnit_CollectionReplaceItems::Items");
static_assert(offsetof(FRigUnit_CollectionReplaceItems, Old) == 0x18, "Offset mismatch for FRigUnit_CollectionReplaceItems::Old");
static_assert(offsetof(FRigUnit_CollectionReplaceItems, New) == 0x1c, "Offset mismatch for FRigUnit_CollectionReplaceItems::New");
static_assert(offsetof(FRigUnit_CollectionReplaceItems, RemoveInvalidItems) == 0x20, "Offset mismatch for FRigUnit_CollectionReplaceItems::RemoveInvalidItems");
static_assert(offsetof(FRigUnit_CollectionReplaceItems, bAllowDuplicates) == 0x21, "Offset mismatch for FRigUnit_CollectionReplaceItems::bAllowDuplicates");
static_assert(offsetof(FRigUnit_CollectionReplaceItems, Collection) == 0x28, "Offset mismatch for FRigUnit_CollectionReplaceItems::Collection");

// Size: 0x38 (Inherited: 0x18, Single: 0x20)
struct FRigUnit_CollectionReplaceItemsArray : FRigUnit_CollectionBase
{
    TArray<FRigElementKey> Items; // 0x8 (Size: 0x10, Type: ArrayProperty)
    FName Old; // 0x18 (Size: 0x4, Type: NameProperty)
    FName New; // 0x1c (Size: 0x4, Type: NameProperty)
    bool RemoveInvalidItems; // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bAllowDuplicates; // 0x21 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_22[0x6]; // 0x22 (Size: 0x6, Type: PaddingProperty)
    TArray<FRigElementKey> Result; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_CollectionReplaceItemsArray) == 0x38, "Size mismatch for FRigUnit_CollectionReplaceItemsArray");
static_assert(offsetof(FRigUnit_CollectionReplaceItemsArray, Items) == 0x8, "Offset mismatch for FRigUnit_CollectionReplaceItemsArray::Items");
static_assert(offsetof(FRigUnit_CollectionReplaceItemsArray, Old) == 0x18, "Offset mismatch for FRigUnit_CollectionReplaceItemsArray::Old");
static_assert(offsetof(FRigUnit_CollectionReplaceItemsArray, New) == 0x1c, "Offset mismatch for FRigUnit_CollectionReplaceItemsArray::New");
static_assert(offsetof(FRigUnit_CollectionReplaceItemsArray, RemoveInvalidItems) == 0x20, "Offset mismatch for FRigUnit_CollectionReplaceItemsArray::RemoveInvalidItems");
static_assert(offsetof(FRigUnit_CollectionReplaceItemsArray, bAllowDuplicates) == 0x21, "Offset mismatch for FRigUnit_CollectionReplaceItemsArray::bAllowDuplicates");
static_assert(offsetof(FRigUnit_CollectionReplaceItemsArray, Result) == 0x28, "Offset mismatch for FRigUnit_CollectionReplaceItemsArray::Result");

// Size: 0x30 (Inherited: 0x18, Single: 0x18)
struct FRigUnit_CollectionItems : FRigUnit_CollectionBase
{
    TArray<FRigElementKey> Items; // 0x8 (Size: 0x10, Type: ArrayProperty)
    bool bAllowDuplicates; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    FRigElementKeyCollection Collection; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CollectionItems) == 0x30, "Size mismatch for FRigUnit_CollectionItems");
static_assert(offsetof(FRigUnit_CollectionItems, Items) == 0x8, "Offset mismatch for FRigUnit_CollectionItems::Items");
static_assert(offsetof(FRigUnit_CollectionItems, bAllowDuplicates) == 0x18, "Offset mismatch for FRigUnit_CollectionItems::bAllowDuplicates");
static_assert(offsetof(FRigUnit_CollectionItems, Collection) == 0x20, "Offset mismatch for FRigUnit_CollectionItems::Collection");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigUnit_CollectionGetItems : FRigUnit_CollectionBase
{
    FRigElementKeyCollection Collection; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FRigElementKey> Items; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_CollectionGetItems) == 0x28, "Size mismatch for FRigUnit_CollectionGetItems");
static_assert(offsetof(FRigUnit_CollectionGetItems, Collection) == 0x8, "Offset mismatch for FRigUnit_CollectionGetItems::Collection");
static_assert(offsetof(FRigUnit_CollectionGetItems, Items) == 0x18, "Offset mismatch for FRigUnit_CollectionGetItems::Items");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigUnit_CollectionGetParentIndices : FRigUnit_CollectionBase
{
    FRigElementKeyCollection Collection; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<int32_t> ParentIndices; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_CollectionGetParentIndices) == 0x28, "Size mismatch for FRigUnit_CollectionGetParentIndices");
static_assert(offsetof(FRigUnit_CollectionGetParentIndices, Collection) == 0x8, "Offset mismatch for FRigUnit_CollectionGetParentIndices::Collection");
static_assert(offsetof(FRigUnit_CollectionGetParentIndices, ParentIndices) == 0x18, "Offset mismatch for FRigUnit_CollectionGetParentIndices::ParentIndices");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigUnit_CollectionGetParentIndicesItemArray : FRigUnit_CollectionBase
{
    TArray<FRigElementKey> Items; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ParentIndices; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_CollectionGetParentIndicesItemArray) == 0x28, "Size mismatch for FRigUnit_CollectionGetParentIndicesItemArray");
static_assert(offsetof(FRigUnit_CollectionGetParentIndicesItemArray, Items) == 0x8, "Offset mismatch for FRigUnit_CollectionGetParentIndicesItemArray::Items");
static_assert(offsetof(FRigUnit_CollectionGetParentIndicesItemArray, ParentIndices) == 0x18, "Offset mismatch for FRigUnit_CollectionGetParentIndicesItemArray::ParentIndices");

// Size: 0x40 (Inherited: 0x18, Single: 0x28)
struct FRigUnit_CollectionUnion : FRigUnit_CollectionBase
{
    FRigElementKeyCollection A; // 0x8 (Size: 0x10, Type: StructProperty)
    FRigElementKeyCollection B; // 0x18 (Size: 0x10, Type: StructProperty)
    bool bAllowDuplicates; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    FRigElementKeyCollection Collection; // 0x30 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CollectionUnion) == 0x40, "Size mismatch for FRigUnit_CollectionUnion");
static_assert(offsetof(FRigUnit_CollectionUnion, A) == 0x8, "Offset mismatch for FRigUnit_CollectionUnion::A");
static_assert(offsetof(FRigUnit_CollectionUnion, B) == 0x18, "Offset mismatch for FRigUnit_CollectionUnion::B");
static_assert(offsetof(FRigUnit_CollectionUnion, bAllowDuplicates) == 0x28, "Offset mismatch for FRigUnit_CollectionUnion::bAllowDuplicates");
static_assert(offsetof(FRigUnit_CollectionUnion, Collection) == 0x30, "Offset mismatch for FRigUnit_CollectionUnion::Collection");

// Size: 0x38 (Inherited: 0x18, Single: 0x20)
struct FRigUnit_CollectionIntersection : FRigUnit_CollectionBase
{
    FRigElementKeyCollection A; // 0x8 (Size: 0x10, Type: StructProperty)
    FRigElementKeyCollection B; // 0x18 (Size: 0x10, Type: StructProperty)
    FRigElementKeyCollection Collection; // 0x28 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CollectionIntersection) == 0x38, "Size mismatch for FRigUnit_CollectionIntersection");
static_assert(offsetof(FRigUnit_CollectionIntersection, A) == 0x8, "Offset mismatch for FRigUnit_CollectionIntersection::A");
static_assert(offsetof(FRigUnit_CollectionIntersection, B) == 0x18, "Offset mismatch for FRigUnit_CollectionIntersection::B");
static_assert(offsetof(FRigUnit_CollectionIntersection, Collection) == 0x28, "Offset mismatch for FRigUnit_CollectionIntersection::Collection");

// Size: 0x38 (Inherited: 0x18, Single: 0x20)
struct FRigUnit_CollectionDifference : FRigUnit_CollectionBase
{
    FRigElementKeyCollection A; // 0x8 (Size: 0x10, Type: StructProperty)
    FRigElementKeyCollection B; // 0x18 (Size: 0x10, Type: StructProperty)
    FRigElementKeyCollection Collection; // 0x28 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CollectionDifference) == 0x38, "Size mismatch for FRigUnit_CollectionDifference");
static_assert(offsetof(FRigUnit_CollectionDifference, A) == 0x8, "Offset mismatch for FRigUnit_CollectionDifference::A");
static_assert(offsetof(FRigUnit_CollectionDifference, B) == 0x18, "Offset mismatch for FRigUnit_CollectionDifference::B");
static_assert(offsetof(FRigUnit_CollectionDifference, Collection) == 0x28, "Offset mismatch for FRigUnit_CollectionDifference::Collection");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigUnit_CollectionReverse : FRigUnit_CollectionBase
{
    FRigElementKeyCollection Collection; // 0x8 (Size: 0x10, Type: StructProperty)
    FRigElementKeyCollection Reversed; // 0x18 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CollectionReverse) == 0x28, "Size mismatch for FRigUnit_CollectionReverse");
static_assert(offsetof(FRigUnit_CollectionReverse, Collection) == 0x8, "Offset mismatch for FRigUnit_CollectionReverse::Collection");
static_assert(offsetof(FRigUnit_CollectionReverse, Reversed) == 0x18, "Offset mismatch for FRigUnit_CollectionReverse::Reversed");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigUnit_CollectionCount : FRigUnit_CollectionBase
{
    FRigElementKeyCollection Collection; // 0x8 (Size: 0x10, Type: StructProperty)
    int32_t Count; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_CollectionCount) == 0x20, "Size mismatch for FRigUnit_CollectionCount");
static_assert(offsetof(FRigUnit_CollectionCount, Collection) == 0x8, "Offset mismatch for FRigUnit_CollectionCount::Collection");
static_assert(offsetof(FRigUnit_CollectionCount, Count) == 0x18, "Offset mismatch for FRigUnit_CollectionCount::Count");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigUnit_CollectionItemAtIndex : FRigUnit_CollectionBase
{
    FRigElementKeyCollection Collection; // 0x8 (Size: 0x10, Type: StructProperty)
    int32_t Index; // 0x18 (Size: 0x4, Type: IntProperty)
    FRigElementKey Item; // 0x1c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_CollectionItemAtIndex) == 0x28, "Size mismatch for FRigUnit_CollectionItemAtIndex");
static_assert(offsetof(FRigUnit_CollectionItemAtIndex, Collection) == 0x8, "Offset mismatch for FRigUnit_CollectionItemAtIndex::Collection");
static_assert(offsetof(FRigUnit_CollectionItemAtIndex, Index) == 0x18, "Offset mismatch for FRigUnit_CollectionItemAtIndex::Index");
static_assert(offsetof(FRigUnit_CollectionItemAtIndex, Item) == 0x1c, "Offset mismatch for FRigUnit_CollectionItemAtIndex::Item");

// Size: 0x230 (Inherited: 0x30, Single: 0x200)
struct FRigUnit_CollectionLoop : FRigUnit_CollectionBaseMutable
{
    FName BlockToRun; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FRigElementKeyCollection Collection; // 0x18 (Size: 0x10, Type: StructProperty)
    FRigElementKey Item; // 0x28 (Size: 0x8, Type: StructProperty)
    int32_t Index; // 0x30 (Size: 0x4, Type: IntProperty)
    int32_t Count; // 0x34 (Size: 0x4, Type: IntProperty)
    float Ratio; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    FControlRigExecuteContext Completed; // 0x40 (Size: 0x1f0, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CollectionLoop) == 0x230, "Size mismatch for FRigUnit_CollectionLoop");
static_assert(offsetof(FRigUnit_CollectionLoop, BlockToRun) == 0x10, "Offset mismatch for FRigUnit_CollectionLoop::BlockToRun");
static_assert(offsetof(FRigUnit_CollectionLoop, Collection) == 0x18, "Offset mismatch for FRigUnit_CollectionLoop::Collection");
static_assert(offsetof(FRigUnit_CollectionLoop, Item) == 0x28, "Offset mismatch for FRigUnit_CollectionLoop::Item");
static_assert(offsetof(FRigUnit_CollectionLoop, Index) == 0x30, "Offset mismatch for FRigUnit_CollectionLoop::Index");
static_assert(offsetof(FRigUnit_CollectionLoop, Count) == 0x34, "Offset mismatch for FRigUnit_CollectionLoop::Count");
static_assert(offsetof(FRigUnit_CollectionLoop, Ratio) == 0x38, "Offset mismatch for FRigUnit_CollectionLoop::Ratio");
static_assert(offsetof(FRigUnit_CollectionLoop, Completed) == 0x40, "Offset mismatch for FRigUnit_CollectionLoop::Completed");

// Size: 0x1f0 (Inherited: 0x108, Single: 0xe8)
struct FControlRigExecuteContext : FRigVMExecuteContext
{
};

static_assert(sizeof(FControlRigExecuteContext) == 0x1f0, "Size mismatch for FControlRigExecuteContext");

// Size: 0x30 (Inherited: 0x18, Single: 0x18)
struct FRigUnit_CollectionAddItem : FRigUnit_CollectionBase
{
    FRigElementKeyCollection Collection; // 0x8 (Size: 0x10, Type: StructProperty)
    FRigElementKey Item; // 0x18 (Size: 0x8, Type: StructProperty)
    FRigElementKeyCollection Result; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CollectionAddItem) == 0x30, "Size mismatch for FRigUnit_CollectionAddItem");
static_assert(offsetof(FRigUnit_CollectionAddItem, Collection) == 0x8, "Offset mismatch for FRigUnit_CollectionAddItem::Collection");
static_assert(offsetof(FRigUnit_CollectionAddItem, Item) == 0x18, "Offset mismatch for FRigUnit_CollectionAddItem::Item");
static_assert(offsetof(FRigUnit_CollectionAddItem, Result) == 0x20, "Offset mismatch for FRigUnit_CollectionAddItem::Result");

// Size: 0x8 (Inherited: 0x10, Single: 0xfffffff8)
struct FRigUnit_DynamicHierarchyBase : FRigUnit
{
};

static_assert(sizeof(FRigUnit_DynamicHierarchyBase) == 0x8, "Size mismatch for FRigUnit_DynamicHierarchyBase");

// Size: 0x10 (Inherited: 0x20, Single: 0xfffffff0)
struct FRigUnit_DynamicHierarchyBaseMutable : FRigUnitMutable
{
};

static_assert(sizeof(FRigUnit_DynamicHierarchyBaseMutable) == 0x10, "Size mismatch for FRigUnit_DynamicHierarchyBaseMutable");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_AddParent : FRigUnit_DynamicHierarchyBaseMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey Parent; // 0x18 (Size: 0x8, Type: StructProperty)
    FName DisplayLabel; // 0x20 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_AddParent) == 0x28, "Size mismatch for FRigUnit_AddParent");
static_assert(offsetof(FRigUnit_AddParent, Child) == 0x10, "Offset mismatch for FRigUnit_AddParent::Child");
static_assert(offsetof(FRigUnit_AddParent, Parent) == 0x18, "Offset mismatch for FRigUnit_AddParent::Parent");
static_assert(offsetof(FRigUnit_AddParent, DisplayLabel) == 0x20, "Offset mismatch for FRigUnit_AddParent::DisplayLabel");

// Size: 0x20 (Inherited: 0x30, Single: 0xfffffff0)
struct FRigUnit_SetDefaultParent : FRigUnit_DynamicHierarchyBaseMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey Parent; // 0x18 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetDefaultParent) == 0x20, "Size mismatch for FRigUnit_SetDefaultParent");
static_assert(offsetof(FRigUnit_SetDefaultParent, Child) == 0x10, "Offset mismatch for FRigUnit_SetDefaultParent::Child");
static_assert(offsetof(FRigUnit_SetDefaultParent, Parent) == 0x18, "Offset mismatch for FRigUnit_SetDefaultParent::Parent");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_AddAvailableSpaces : FRigUnit_DynamicHierarchyBaseMutable
{
    FRigElementKey Control; // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementKeyWithLabel> Spaces; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_AddAvailableSpaces) == 0x28, "Size mismatch for FRigUnit_AddAvailableSpaces");
static_assert(offsetof(FRigUnit_AddAvailableSpaces, Control) == 0x10, "Offset mismatch for FRigUnit_AddAvailableSpaces::Control");
static_assert(offsetof(FRigUnit_AddAvailableSpaces, Spaces) == 0x18, "Offset mismatch for FRigUnit_AddAvailableSpaces::Spaces");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_SetChannelHosts : FRigUnit_DynamicHierarchyBaseMutable
{
    FRigElementKey Channel; // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementKey> Hosts; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_SetChannelHosts) == 0x28, "Size mismatch for FRigUnit_SetChannelHosts");
static_assert(offsetof(FRigUnit_SetChannelHosts, Channel) == 0x10, "Offset mismatch for FRigUnit_SetChannelHosts::Channel");
static_assert(offsetof(FRigUnit_SetChannelHosts, Hosts) == 0x18, "Offset mismatch for FRigUnit_SetChannelHosts::Hosts");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_SwitchParent : FRigUnit_DynamicHierarchyBaseMutable
{
    uint8_t Mode; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    FRigElementKey Child; // 0x14 (Size: 0x8, Type: StructProperty)
    FRigElementKey Parent; // 0x1c (Size: 0x8, Type: StructProperty)
    bool bMaintainGlobal; // 0x24 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_25[0x3]; // 0x25 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SwitchParent) == 0x28, "Size mismatch for FRigUnit_SwitchParent");
static_assert(offsetof(FRigUnit_SwitchParent, Mode) == 0x10, "Offset mismatch for FRigUnit_SwitchParent::Mode");
static_assert(offsetof(FRigUnit_SwitchParent, Child) == 0x14, "Offset mismatch for FRigUnit_SwitchParent::Child");
static_assert(offsetof(FRigUnit_SwitchParent, Parent) == 0x1c, "Offset mismatch for FRigUnit_SwitchParent::Parent");
static_assert(offsetof(FRigUnit_SwitchParent, bMaintainGlobal) == 0x24, "Offset mismatch for FRigUnit_SwitchParent::bMaintainGlobal");

// Size: 0x30 (Inherited: 0x18, Single: 0x18)
struct FRigUnit_HierarchyGetParentWeights : FRigUnit_DynamicHierarchyBase
{
    FRigElementKey Child; // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementWeight> Weights; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FRigElementKeyCollection Parents; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyGetParentWeights) == 0x30, "Size mismatch for FRigUnit_HierarchyGetParentWeights");
static_assert(offsetof(FRigUnit_HierarchyGetParentWeights, Child) == 0x8, "Offset mismatch for FRigUnit_HierarchyGetParentWeights::Child");
static_assert(offsetof(FRigUnit_HierarchyGetParentWeights, Weights) == 0x10, "Offset mismatch for FRigUnit_HierarchyGetParentWeights::Weights");
static_assert(offsetof(FRigUnit_HierarchyGetParentWeights, Parents) == 0x20, "Offset mismatch for FRigUnit_HierarchyGetParentWeights::Parents");

// Size: 0x30 (Inherited: 0x18, Single: 0x18)
struct FRigUnit_HierarchyGetParentWeightsArray : FRigUnit_DynamicHierarchyBase
{
    FRigElementKey Child; // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementWeight> Weights; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigElementKey> Parents; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_HierarchyGetParentWeightsArray) == 0x30, "Size mismatch for FRigUnit_HierarchyGetParentWeightsArray");
static_assert(offsetof(FRigUnit_HierarchyGetParentWeightsArray, Child) == 0x8, "Offset mismatch for FRigUnit_HierarchyGetParentWeightsArray::Child");
static_assert(offsetof(FRigUnit_HierarchyGetParentWeightsArray, Weights) == 0x10, "Offset mismatch for FRigUnit_HierarchyGetParentWeightsArray::Weights");
static_assert(offsetof(FRigUnit_HierarchyGetParentWeightsArray, Parents) == 0x20, "Offset mismatch for FRigUnit_HierarchyGetParentWeightsArray::Parents");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_HierarchySetParentWeights : FRigUnit_DynamicHierarchyBaseMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementWeight> Weights; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetParentWeights) == 0x28, "Size mismatch for FRigUnit_HierarchySetParentWeights");
static_assert(offsetof(FRigUnit_HierarchySetParentWeights, Child) == 0x10, "Offset mismatch for FRigUnit_HierarchySetParentWeights::Child");
static_assert(offsetof(FRigUnit_HierarchySetParentWeights, Weights) == 0x18, "Offset mismatch for FRigUnit_HierarchySetParentWeights::Weights");

// Size: 0x10 (Inherited: 0x30, Single: 0xffffffe0)
struct FRigUnit_HierarchyReset : FRigUnit_DynamicHierarchyBaseMutable
{
};

static_assert(sizeof(FRigUnit_HierarchyReset) == 0x10, "Size mismatch for FRigUnit_HierarchyReset");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_HierarchyImportFromSkeleton : FRigUnit_DynamicHierarchyBaseMutable
{
    FName Namespace; // 0x10 (Size: 0x4, Type: NameProperty)
    bool bIncludeCurves; // 0x14 (Size: 0x1, Type: BoolProperty)
    bool bIncludeMeshSockets; // 0x15 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_16[0x2]; // 0x16 (Size: 0x2, Type: PaddingProperty)
    TArray<FRigElementKey> Items; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_HierarchyImportFromSkeleton) == 0x28, "Size mismatch for FRigUnit_HierarchyImportFromSkeleton");
static_assert(offsetof(FRigUnit_HierarchyImportFromSkeleton, Namespace) == 0x10, "Offset mismatch for FRigUnit_HierarchyImportFromSkeleton::Namespace");
static_assert(offsetof(FRigUnit_HierarchyImportFromSkeleton, bIncludeCurves) == 0x14, "Offset mismatch for FRigUnit_HierarchyImportFromSkeleton::bIncludeCurves");
static_assert(offsetof(FRigUnit_HierarchyImportFromSkeleton, bIncludeMeshSockets) == 0x15, "Offset mismatch for FRigUnit_HierarchyImportFromSkeleton::bIncludeMeshSockets");
static_assert(offsetof(FRigUnit_HierarchyImportFromSkeleton, Items) == 0x18, "Offset mismatch for FRigUnit_HierarchyImportFromSkeleton::Items");

// Size: 0x20 (Inherited: 0x30, Single: 0xfffffff0)
struct FRigUnit_HierarchyRemoveElement : FRigUnit_DynamicHierarchyBaseMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bSuccess; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyRemoveElement) == 0x20, "Size mismatch for FRigUnit_HierarchyRemoveElement");
static_assert(offsetof(FRigUnit_HierarchyRemoveElement, Item) == 0x10, "Offset mismatch for FRigUnit_HierarchyRemoveElement::Item");
static_assert(offsetof(FRigUnit_HierarchyRemoveElement, bSuccess) == 0x18, "Offset mismatch for FRigUnit_HierarchyRemoveElement::bSuccess");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_HierarchyAddElement : FRigUnit_DynamicHierarchyBaseMutable
{
    FRigElementKey Parent; // 0x10 (Size: 0x8, Type: StructProperty)
    FName Name; // 0x18 (Size: 0x4, Type: NameProperty)
    FRigElementKey Item; // 0x1c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddElement) == 0x28, "Size mismatch for FRigUnit_HierarchyAddElement");
static_assert(offsetof(FRigUnit_HierarchyAddElement, Parent) == 0x10, "Offset mismatch for FRigUnit_HierarchyAddElement::Parent");
static_assert(offsetof(FRigUnit_HierarchyAddElement, Name) == 0x18, "Offset mismatch for FRigUnit_HierarchyAddElement::Name");
static_assert(offsetof(FRigUnit_HierarchyAddElement, Item) == 0x1c, "Offset mismatch for FRigUnit_HierarchyAddElement::Item");

// Size: 0xa0 (Inherited: 0x58, Single: 0x48)
struct FRigUnit_HierarchyAddBone : FRigUnit_HierarchyAddElement
{
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x30 (Size: 0x60, Type: StructProperty)
    uint8_t Space; // 0x90 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_91[0xf]; // 0x91 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddBone) == 0xa0, "Size mismatch for FRigUnit_HierarchyAddBone");
static_assert(offsetof(FRigUnit_HierarchyAddBone, Transform) == 0x30, "Offset mismatch for FRigUnit_HierarchyAddBone::Transform");
static_assert(offsetof(FRigUnit_HierarchyAddBone, Space) == 0x90, "Offset mismatch for FRigUnit_HierarchyAddBone::Space");

// Size: 0xa0 (Inherited: 0x58, Single: 0x48)
struct FRigUnit_HierarchyAddNull : FRigUnit_HierarchyAddElement
{
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x30 (Size: 0x60, Type: StructProperty)
    uint8_t Space; // 0x90 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_91[0xf]; // 0x91 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddNull) == 0xa0, "Size mismatch for FRigUnit_HierarchyAddNull");
static_assert(offsetof(FRigUnit_HierarchyAddNull, Transform) == 0x30, "Offset mismatch for FRigUnit_HierarchyAddNull::Transform");
static_assert(offsetof(FRigUnit_HierarchyAddNull, Space) == 0x90, "Offset mismatch for FRigUnit_HierarchyAddNull::Space");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigUnit_HierarchyAddControl_Settings
{
    FName DisplayName; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControl_Settings) == 0x10, "Size mismatch for FRigUnit_HierarchyAddControl_Settings");
static_assert(offsetof(FRigUnit_HierarchyAddControl_Settings, DisplayName) == 0x8, "Offset mismatch for FRigUnit_HierarchyAddControl_Settings::DisplayName");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FRigUnit_HierarchyAddControl_ShapeSettings
{
    bool bVisible; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FName Name; // 0x4 (Size: 0x4, Type: NameProperty)
    FLinearColor Color; // 0x8 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControl_ShapeSettings) == 0x80, "Size mismatch for FRigUnit_HierarchyAddControl_ShapeSettings");
static_assert(offsetof(FRigUnit_HierarchyAddControl_ShapeSettings, bVisible) == 0x0, "Offset mismatch for FRigUnit_HierarchyAddControl_ShapeSettings::bVisible");
static_assert(offsetof(FRigUnit_HierarchyAddControl_ShapeSettings, Name) == 0x4, "Offset mismatch for FRigUnit_HierarchyAddControl_ShapeSettings::Name");
static_assert(offsetof(FRigUnit_HierarchyAddControl_ShapeSettings, Color) == 0x8, "Offset mismatch for FRigUnit_HierarchyAddControl_ShapeSettings::Color");
static_assert(offsetof(FRigUnit_HierarchyAddControl_ShapeSettings, Transform) == 0x20, "Offset mismatch for FRigUnit_HierarchyAddControl_ShapeSettings::Transform");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FRigUnit_HierarchyAddControl_ProxySettings
{
    bool bIsProxy; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TArray<FRigElementKey> DrivenControls; // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t ShapeVisibility; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControl_ProxySettings) == 0x20, "Size mismatch for FRigUnit_HierarchyAddControl_ProxySettings");
static_assert(offsetof(FRigUnit_HierarchyAddControl_ProxySettings, bIsProxy) == 0x0, "Offset mismatch for FRigUnit_HierarchyAddControl_ProxySettings::bIsProxy");
static_assert(offsetof(FRigUnit_HierarchyAddControl_ProxySettings, DrivenControls) == 0x8, "Offset mismatch for FRigUnit_HierarchyAddControl_ProxySettings::DrivenControls");
static_assert(offsetof(FRigUnit_HierarchyAddControl_ProxySettings, ShapeVisibility) == 0x18, "Offset mismatch for FRigUnit_HierarchyAddControl_ProxySettings::ShapeVisibility");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigUnit_HierarchyAddControlFloat_LimitSettings
{
    FRigControlLimitEnabled Limit; // 0x0 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    float MinValue; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaxValue; // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bDrawLimits; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlFloat_LimitSettings) == 0x10, "Size mismatch for FRigUnit_HierarchyAddControlFloat_LimitSettings");
static_assert(offsetof(FRigUnit_HierarchyAddControlFloat_LimitSettings, Limit) == 0x0, "Offset mismatch for FRigUnit_HierarchyAddControlFloat_LimitSettings::Limit");
static_assert(offsetof(FRigUnit_HierarchyAddControlFloat_LimitSettings, MinValue) == 0x4, "Offset mismatch for FRigUnit_HierarchyAddControlFloat_LimitSettings::MinValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlFloat_LimitSettings, MaxValue) == 0x8, "Offset mismatch for FRigUnit_HierarchyAddControlFloat_LimitSettings::MaxValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlFloat_LimitSettings, bDrawLimits) == 0xc, "Offset mismatch for FRigUnit_HierarchyAddControlFloat_LimitSettings::bDrawLimits");

// Size: 0xd0 (Inherited: 0x10, Single: 0xc0)
struct FRigUnit_HierarchyAddControlFloat_Settings : FRigUnit_HierarchyAddControl_Settings
{
    uint8_t PrimaryAxis; // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bIsScale; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x2]; // 0x12 (Size: 0x2, Type: PaddingProperty)
    FRigUnit_HierarchyAddControlFloat_LimitSettings Limits; // 0x14 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_24[0xc]; // 0x24 (Size: 0xc, Type: PaddingProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Shape; // 0x30 (Size: 0x80, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ProxySettings Proxy; // 0xb0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlFloat_Settings) == 0xd0, "Size mismatch for FRigUnit_HierarchyAddControlFloat_Settings");
static_assert(offsetof(FRigUnit_HierarchyAddControlFloat_Settings, PrimaryAxis) == 0x10, "Offset mismatch for FRigUnit_HierarchyAddControlFloat_Settings::PrimaryAxis");
static_assert(offsetof(FRigUnit_HierarchyAddControlFloat_Settings, bIsScale) == 0x11, "Offset mismatch for FRigUnit_HierarchyAddControlFloat_Settings::bIsScale");
static_assert(offsetof(FRigUnit_HierarchyAddControlFloat_Settings, Limits) == 0x14, "Offset mismatch for FRigUnit_HierarchyAddControlFloat_Settings::Limits");
static_assert(offsetof(FRigUnit_HierarchyAddControlFloat_Settings, Shape) == 0x30, "Offset mismatch for FRigUnit_HierarchyAddControlFloat_Settings::Shape");
static_assert(offsetof(FRigUnit_HierarchyAddControlFloat_Settings, Proxy) == 0xb0, "Offset mismatch for FRigUnit_HierarchyAddControlFloat_Settings::Proxy");

// Size: 0xa0 (Inherited: 0x58, Single: 0x48)
struct FRigUnit_HierarchyAddControlElement : FRigUnit_HierarchyAddElement
{
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FTransform OffsetTransform; // 0x30 (Size: 0x60, Type: StructProperty)
    uint8_t OffsetSpace; // 0x90 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_91[0xf]; // 0x91 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlElement) == 0xa0, "Size mismatch for FRigUnit_HierarchyAddControlElement");
static_assert(offsetof(FRigUnit_HierarchyAddControlElement, OffsetTransform) == 0x30, "Offset mismatch for FRigUnit_HierarchyAddControlElement::OffsetTransform");
static_assert(offsetof(FRigUnit_HierarchyAddControlElement, OffsetSpace) == 0x90, "Offset mismatch for FRigUnit_HierarchyAddControlElement::OffsetSpace");

// Size: 0x170 (Inherited: 0xf8, Single: 0x78)
struct FRigUnit_HierarchyAddControlFloat : FRigUnit_HierarchyAddControlElement
{
    float InitialValue; // 0x98 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
    FRigUnit_HierarchyAddControlFloat_Settings Settings; // 0xa0 (Size: 0xd0, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlFloat) == 0x170, "Size mismatch for FRigUnit_HierarchyAddControlFloat");
static_assert(offsetof(FRigUnit_HierarchyAddControlFloat, InitialValue) == 0x98, "Offset mismatch for FRigUnit_HierarchyAddControlFloat::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlFloat, Settings) == 0xa0, "Offset mismatch for FRigUnit_HierarchyAddControlFloat::Settings");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigUnit_HierarchyAddControlInteger_LimitSettings
{
    FRigControlLimitEnabled Limit; // 0x0 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    int32_t MinValue; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t MaxValue; // 0x8 (Size: 0x4, Type: IntProperty)
    bool bDrawLimits; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlInteger_LimitSettings) == 0x10, "Size mismatch for FRigUnit_HierarchyAddControlInteger_LimitSettings");
static_assert(offsetof(FRigUnit_HierarchyAddControlInteger_LimitSettings, Limit) == 0x0, "Offset mismatch for FRigUnit_HierarchyAddControlInteger_LimitSettings::Limit");
static_assert(offsetof(FRigUnit_HierarchyAddControlInteger_LimitSettings, MinValue) == 0x4, "Offset mismatch for FRigUnit_HierarchyAddControlInteger_LimitSettings::MinValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlInteger_LimitSettings, MaxValue) == 0x8, "Offset mismatch for FRigUnit_HierarchyAddControlInteger_LimitSettings::MaxValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlInteger_LimitSettings, bDrawLimits) == 0xc, "Offset mismatch for FRigUnit_HierarchyAddControlInteger_LimitSettings::bDrawLimits");

// Size: 0xd0 (Inherited: 0x10, Single: 0xc0)
struct FRigUnit_HierarchyAddControlInteger_Settings : FRigUnit_HierarchyAddControl_Settings
{
    uint8_t PrimaryAxis; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    UEnum* ControlEnum; // 0x18 (Size: 0x8, Type: ObjectProperty)
    FRigUnit_HierarchyAddControlInteger_LimitSettings Limits; // 0x20 (Size: 0x10, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Shape; // 0x30 (Size: 0x80, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ProxySettings Proxy; // 0xb0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlInteger_Settings) == 0xd0, "Size mismatch for FRigUnit_HierarchyAddControlInteger_Settings");
static_assert(offsetof(FRigUnit_HierarchyAddControlInteger_Settings, PrimaryAxis) == 0x10, "Offset mismatch for FRigUnit_HierarchyAddControlInteger_Settings::PrimaryAxis");
static_assert(offsetof(FRigUnit_HierarchyAddControlInteger_Settings, ControlEnum) == 0x18, "Offset mismatch for FRigUnit_HierarchyAddControlInteger_Settings::ControlEnum");
static_assert(offsetof(FRigUnit_HierarchyAddControlInteger_Settings, Limits) == 0x20, "Offset mismatch for FRigUnit_HierarchyAddControlInteger_Settings::Limits");
static_assert(offsetof(FRigUnit_HierarchyAddControlInteger_Settings, Shape) == 0x30, "Offset mismatch for FRigUnit_HierarchyAddControlInteger_Settings::Shape");
static_assert(offsetof(FRigUnit_HierarchyAddControlInteger_Settings, Proxy) == 0xb0, "Offset mismatch for FRigUnit_HierarchyAddControlInteger_Settings::Proxy");

// Size: 0x170 (Inherited: 0xf8, Single: 0x78)
struct FRigUnit_HierarchyAddControlInteger : FRigUnit_HierarchyAddControlElement
{
    int32_t InitialValue; // 0x98 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
    FRigUnit_HierarchyAddControlInteger_Settings Settings; // 0xa0 (Size: 0xd0, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlInteger) == 0x170, "Size mismatch for FRigUnit_HierarchyAddControlInteger");
static_assert(offsetof(FRigUnit_HierarchyAddControlInteger, InitialValue) == 0x98, "Offset mismatch for FRigUnit_HierarchyAddControlInteger::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlInteger, Settings) == 0xa0, "Offset mismatch for FRigUnit_HierarchyAddControlInteger::Settings");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FRigUnit_HierarchyAddControlVector2D_LimitSettings
{
    FRigControlLimitEnabled LimitX; // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitY; // 0x2 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector2D MinValue; // 0x8 (Size: 0x10, Type: StructProperty)
    FVector2D MaxValue; // 0x18 (Size: 0x10, Type: StructProperty)
    bool bDrawLimits; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlVector2D_LimitSettings) == 0x30, "Size mismatch for FRigUnit_HierarchyAddControlVector2D_LimitSettings");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector2D_LimitSettings, LimitX) == 0x0, "Offset mismatch for FRigUnit_HierarchyAddControlVector2D_LimitSettings::LimitX");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector2D_LimitSettings, LimitY) == 0x2, "Offset mismatch for FRigUnit_HierarchyAddControlVector2D_LimitSettings::LimitY");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector2D_LimitSettings, MinValue) == 0x8, "Offset mismatch for FRigUnit_HierarchyAddControlVector2D_LimitSettings::MinValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector2D_LimitSettings, MaxValue) == 0x18, "Offset mismatch for FRigUnit_HierarchyAddControlVector2D_LimitSettings::MaxValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector2D_LimitSettings, bDrawLimits) == 0x28, "Offset mismatch for FRigUnit_HierarchyAddControlVector2D_LimitSettings::bDrawLimits");

// Size: 0x100 (Inherited: 0x10, Single: 0xf0)
struct FRigUnit_HierarchyAddControlVector2D_Settings : FRigUnit_HierarchyAddControl_Settings
{
    uint8_t PrimaryAxis; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_HierarchyAddControlVector2D_LimitSettings Limits; // 0x18 (Size: 0x30, Type: StructProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Shape; // 0x50 (Size: 0x80, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ProxySettings Proxy; // 0xd0 (Size: 0x20, Type: StructProperty)
    TArray<ERigControlTransformChannel> FilteredChannels; // 0xf0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlVector2D_Settings) == 0x100, "Size mismatch for FRigUnit_HierarchyAddControlVector2D_Settings");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector2D_Settings, PrimaryAxis) == 0x10, "Offset mismatch for FRigUnit_HierarchyAddControlVector2D_Settings::PrimaryAxis");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector2D_Settings, Limits) == 0x18, "Offset mismatch for FRigUnit_HierarchyAddControlVector2D_Settings::Limits");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector2D_Settings, Shape) == 0x50, "Offset mismatch for FRigUnit_HierarchyAddControlVector2D_Settings::Shape");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector2D_Settings, Proxy) == 0xd0, "Offset mismatch for FRigUnit_HierarchyAddControlVector2D_Settings::Proxy");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector2D_Settings, FilteredChannels) == 0xf0, "Offset mismatch for FRigUnit_HierarchyAddControlVector2D_Settings::FilteredChannels");

// Size: 0x1b0 (Inherited: 0xf8, Single: 0xb8)
struct FRigUnit_HierarchyAddControlVector2D : FRigUnit_HierarchyAddControlElement
{
    FVector2D InitialValue; // 0x98 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_a8[0x8]; // 0xa8 (Size: 0x8, Type: PaddingProperty)
    FRigUnit_HierarchyAddControlVector2D_Settings Settings; // 0xb0 (Size: 0x100, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlVector2D) == 0x1b0, "Size mismatch for FRigUnit_HierarchyAddControlVector2D");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector2D, InitialValue) == 0x98, "Offset mismatch for FRigUnit_HierarchyAddControlVector2D::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector2D, Settings) == 0xb0, "Offset mismatch for FRigUnit_HierarchyAddControlVector2D::Settings");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FRigUnit_HierarchyAddControlVector_LimitSettings
{
    FRigControlLimitEnabled LimitX; // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitY; // 0x2 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitZ; // 0x4 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_6[0x2]; // 0x6 (Size: 0x2, Type: PaddingProperty)
    FVector MinValue; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector MaxValue; // 0x20 (Size: 0x18, Type: StructProperty)
    bool bDrawLimits; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlVector_LimitSettings) == 0x40, "Size mismatch for FRigUnit_HierarchyAddControlVector_LimitSettings");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector_LimitSettings, LimitX) == 0x0, "Offset mismatch for FRigUnit_HierarchyAddControlVector_LimitSettings::LimitX");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector_LimitSettings, LimitY) == 0x2, "Offset mismatch for FRigUnit_HierarchyAddControlVector_LimitSettings::LimitY");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector_LimitSettings, LimitZ) == 0x4, "Offset mismatch for FRigUnit_HierarchyAddControlVector_LimitSettings::LimitZ");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector_LimitSettings, MinValue) == 0x8, "Offset mismatch for FRigUnit_HierarchyAddControlVector_LimitSettings::MinValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector_LimitSettings, MaxValue) == 0x20, "Offset mismatch for FRigUnit_HierarchyAddControlVector_LimitSettings::MaxValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector_LimitSettings, bDrawLimits) == 0x38, "Offset mismatch for FRigUnit_HierarchyAddControlVector_LimitSettings::bDrawLimits");

// Size: 0x110 (Inherited: 0x10, Single: 0x100)
struct FRigUnit_HierarchyAddControlVector_Settings : FRigUnit_HierarchyAddControl_Settings
{
    uint8_t InitialSpace; // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bIsPosition; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
    FRigUnit_HierarchyAddControlVector_LimitSettings Limits; // 0x18 (Size: 0x40, Type: StructProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Shape; // 0x60 (Size: 0x80, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ProxySettings Proxy; // 0xe0 (Size: 0x20, Type: StructProperty)
    TArray<ERigControlTransformChannel> FilteredChannels; // 0x100 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlVector_Settings) == 0x110, "Size mismatch for FRigUnit_HierarchyAddControlVector_Settings");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector_Settings, InitialSpace) == 0x10, "Offset mismatch for FRigUnit_HierarchyAddControlVector_Settings::InitialSpace");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector_Settings, bIsPosition) == 0x11, "Offset mismatch for FRigUnit_HierarchyAddControlVector_Settings::bIsPosition");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector_Settings, Limits) == 0x18, "Offset mismatch for FRigUnit_HierarchyAddControlVector_Settings::Limits");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector_Settings, Shape) == 0x60, "Offset mismatch for FRigUnit_HierarchyAddControlVector_Settings::Shape");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector_Settings, Proxy) == 0xe0, "Offset mismatch for FRigUnit_HierarchyAddControlVector_Settings::Proxy");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector_Settings, FilteredChannels) == 0x100, "Offset mismatch for FRigUnit_HierarchyAddControlVector_Settings::FilteredChannels");

// Size: 0x1c0 (Inherited: 0xf8, Single: 0xc8)
struct FRigUnit_HierarchyAddControlVector : FRigUnit_HierarchyAddControlElement
{
    FVector InitialValue; // 0x98 (Size: 0x18, Type: StructProperty)
    FRigUnit_HierarchyAddControlVector_Settings Settings; // 0xb0 (Size: 0x110, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlVector) == 0x1c0, "Size mismatch for FRigUnit_HierarchyAddControlVector");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector, InitialValue) == 0x98, "Offset mismatch for FRigUnit_HierarchyAddControlVector::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlVector, Settings) == 0xb0, "Offset mismatch for FRigUnit_HierarchyAddControlVector::Settings");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FRigUnit_HierarchyAddControlRotator_LimitSettings
{
    FRigControlLimitEnabled LimitPitch; // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitYaw; // 0x2 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitRoll; // 0x4 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_6[0x2]; // 0x6 (Size: 0x2, Type: PaddingProperty)
    FRotator MinValue; // 0x8 (Size: 0x18, Type: StructProperty)
    FRotator MaxValue; // 0x20 (Size: 0x18, Type: StructProperty)
    bool bDrawLimits; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlRotator_LimitSettings) == 0x40, "Size mismatch for FRigUnit_HierarchyAddControlRotator_LimitSettings");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_LimitSettings, LimitPitch) == 0x0, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_LimitSettings::LimitPitch");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_LimitSettings, LimitYaw) == 0x2, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_LimitSettings::LimitYaw");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_LimitSettings, LimitRoll) == 0x4, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_LimitSettings::LimitRoll");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_LimitSettings, MinValue) == 0x8, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_LimitSettings::MinValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_LimitSettings, MaxValue) == 0x20, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_LimitSettings::MaxValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_LimitSettings, bDrawLimits) == 0x38, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_LimitSettings::bDrawLimits");

// Size: 0x120 (Inherited: 0x10, Single: 0x110)
struct FRigUnit_HierarchyAddControlRotator_Settings : FRigUnit_HierarchyAddControl_Settings
{
    uint8_t InitialSpace; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_HierarchyAddControlRotator_LimitSettings Limits; // 0x18 (Size: 0x40, Type: StructProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Shape; // 0x60 (Size: 0x80, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ProxySettings Proxy; // 0xe0 (Size: 0x20, Type: StructProperty)
    TArray<ERigControlTransformChannel> FilteredChannels; // 0x100 (Size: 0x10, Type: ArrayProperty)
    bool bUsePreferredRotationOrder; // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t PreferredRotationOrder; // 0x111 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_112[0xe]; // 0x112 (Size: 0xe, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlRotator_Settings) == 0x120, "Size mismatch for FRigUnit_HierarchyAddControlRotator_Settings");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_Settings, InitialSpace) == 0x10, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_Settings::InitialSpace");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_Settings, Limits) == 0x18, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_Settings::Limits");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_Settings, Shape) == 0x60, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_Settings::Shape");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_Settings, Proxy) == 0xe0, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_Settings::Proxy");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_Settings, FilteredChannels) == 0x100, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_Settings::FilteredChannels");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_Settings, bUsePreferredRotationOrder) == 0x110, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_Settings::bUsePreferredRotationOrder");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator_Settings, PreferredRotationOrder) == 0x111, "Offset mismatch for FRigUnit_HierarchyAddControlRotator_Settings::PreferredRotationOrder");

// Size: 0x1d0 (Inherited: 0xf8, Single: 0xd8)
struct FRigUnit_HierarchyAddControlRotator : FRigUnit_HierarchyAddControlElement
{
    FRotator InitialValue; // 0x98 (Size: 0x18, Type: StructProperty)
    FRigUnit_HierarchyAddControlRotator_Settings Settings; // 0xb0 (Size: 0x120, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlRotator) == 0x1d0, "Size mismatch for FRigUnit_HierarchyAddControlRotator");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator, InitialValue) == 0x98, "Offset mismatch for FRigUnit_HierarchyAddControlRotator::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlRotator, Settings) == 0xb0, "Offset mismatch for FRigUnit_HierarchyAddControlRotator::Settings");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FRigUnit_HierarchyAddControlTransform_LimitSettings
{
    FRigControlLimitEnabled LimitTranslationX; // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitTranslationY; // 0x2 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitTranslationZ; // 0x4 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitPitch; // 0x6 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitYaw; // 0x8 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitRoll; // 0xa (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitScaleX; // 0xc (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitScaleY; // 0xe (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitScaleZ; // 0x10 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
    FEulerTransform MinValue; // 0x18 (Size: 0x48, Type: StructProperty)
    FEulerTransform MaxValue; // 0x60 (Size: 0x48, Type: StructProperty)
    bool bDrawLimits; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlTransform_LimitSettings) == 0xb0, "Size mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_LimitSettings, LimitTranslationX) == 0x0, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings::LimitTranslationX");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_LimitSettings, LimitTranslationY) == 0x2, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings::LimitTranslationY");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_LimitSettings, LimitTranslationZ) == 0x4, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings::LimitTranslationZ");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_LimitSettings, LimitPitch) == 0x6, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings::LimitPitch");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_LimitSettings, LimitYaw) == 0x8, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings::LimitYaw");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_LimitSettings, LimitRoll) == 0xa, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings::LimitRoll");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_LimitSettings, LimitScaleX) == 0xc, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings::LimitScaleX");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_LimitSettings, LimitScaleY) == 0xe, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings::LimitScaleY");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_LimitSettings, LimitScaleZ) == 0x10, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings::LimitScaleZ");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_LimitSettings, MinValue) == 0x18, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings::MinValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_LimitSettings, MaxValue) == 0x60, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings::MaxValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_LimitSettings, bDrawLimits) == 0xa8, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_LimitSettings::bDrawLimits");

// Size: 0x180 (Inherited: 0x10, Single: 0x170)
struct FRigUnit_HierarchyAddControlTransform_Settings : FRigUnit_HierarchyAddControl_Settings
{
    uint8_t InitialSpace; // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bUsePreferredRotationOrder; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t PreferredRotationOrder; // 0x12 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_13[0x5]; // 0x13 (Size: 0x5, Type: PaddingProperty)
    FRigUnit_HierarchyAddControlTransform_LimitSettings Limits; // 0x18 (Size: 0xb0, Type: StructProperty)
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Shape; // 0xd0 (Size: 0x80, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ProxySettings Proxy; // 0x150 (Size: 0x20, Type: StructProperty)
    TArray<ERigControlTransformChannel> FilteredChannels; // 0x170 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlTransform_Settings) == 0x180, "Size mismatch for FRigUnit_HierarchyAddControlTransform_Settings");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_Settings, InitialSpace) == 0x10, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_Settings::InitialSpace");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_Settings, bUsePreferredRotationOrder) == 0x11, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_Settings::bUsePreferredRotationOrder");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_Settings, PreferredRotationOrder) == 0x12, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_Settings::PreferredRotationOrder");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_Settings, Limits) == 0x18, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_Settings::Limits");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_Settings, Shape) == 0xd0, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_Settings::Shape");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_Settings, Proxy) == 0x150, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_Settings::Proxy");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform_Settings, FilteredChannels) == 0x170, "Offset mismatch for FRigUnit_HierarchyAddControlTransform_Settings::FilteredChannels");

// Size: 0x280 (Inherited: 0xf8, Single: 0x188)
struct FRigUnit_HierarchyAddControlTransform : FRigUnit_HierarchyAddControlElement
{
    FTransform InitialValue; // 0xa0 (Size: 0x60, Type: StructProperty)
    FRigUnit_HierarchyAddControlTransform_Settings Settings; // 0x100 (Size: 0x180, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddControlTransform) == 0x280, "Size mismatch for FRigUnit_HierarchyAddControlTransform");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform, InitialValue) == 0xa0, "Offset mismatch for FRigUnit_HierarchyAddControlTransform::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddControlTransform, Settings) == 0x100, "Offset mismatch for FRigUnit_HierarchyAddControlTransform::Settings");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings
{
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings) == 0x1, "Size mismatch for FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
struct FRigUnit_HierarchyAddAnimationChannelBool : FRigUnit_HierarchyAddElement
{
    bool InitialValue; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool MinimumValue; // 0x29 (Size: 0x1, Type: BoolProperty)
    bool MaximumValue; // 0x2a (Size: 0x1, Type: BoolProperty)
    FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings LimitsEnabled; // 0x2b (Size: 0x1, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannelBool) == 0x30, "Size mismatch for FRigUnit_HierarchyAddAnimationChannelBool");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelBool, InitialValue) == 0x28, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelBool::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelBool, MinimumValue) == 0x29, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelBool::MinimumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelBool, MaximumValue) == 0x2a, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelBool::MaximumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelBool, LimitsEnabled) == 0x2b, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelBool::LimitsEnabled");

// Size: 0x2 (Inherited: 0x1, Single: 0x1)
struct FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings : FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings
{
    FRigControlLimitEnabled Enabled; // 0x0 (Size: 0x2, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings) == 0x2, "Size mismatch for FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings, Enabled) == 0x0, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings::Enabled");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
struct FRigUnit_HierarchyAddAnimationChannelFloat : FRigUnit_HierarchyAddElement
{
    float InitialValue; // 0x28 (Size: 0x4, Type: FloatProperty)
    float MinimumValue; // 0x2c (Size: 0x4, Type: FloatProperty)
    float MaximumValue; // 0x30 (Size: 0x4, Type: FloatProperty)
    FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings LimitsEnabled; // 0x34 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_36[0x2]; // 0x36 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannelFloat) == 0x38, "Size mismatch for FRigUnit_HierarchyAddAnimationChannelFloat");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelFloat, InitialValue) == 0x28, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelFloat::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelFloat, MinimumValue) == 0x2c, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelFloat::MinimumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelFloat, MaximumValue) == 0x30, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelFloat::MaximumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelFloat, LimitsEnabled) == 0x34, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelFloat::LimitsEnabled");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
struct FRigUnit_HierarchyAddAnimationChannelScaleFloat : FRigUnit_HierarchyAddElement
{
    float InitialValue; // 0x28 (Size: 0x4, Type: FloatProperty)
    float MinimumValue; // 0x2c (Size: 0x4, Type: FloatProperty)
    float MaximumValue; // 0x30 (Size: 0x4, Type: FloatProperty)
    FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings LimitsEnabled; // 0x34 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_36[0x2]; // 0x36 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannelScaleFloat) == 0x38, "Size mismatch for FRigUnit_HierarchyAddAnimationChannelScaleFloat");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelScaleFloat, InitialValue) == 0x28, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelScaleFloat::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelScaleFloat, MinimumValue) == 0x2c, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelScaleFloat::MinimumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelScaleFloat, MaximumValue) == 0x30, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelScaleFloat::MaximumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelScaleFloat, LimitsEnabled) == 0x34, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelScaleFloat::LimitsEnabled");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
struct FRigUnit_HierarchyAddAnimationChannelInteger : FRigUnit_HierarchyAddElement
{
    int32_t InitialValue; // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t MinimumValue; // 0x2c (Size: 0x4, Type: IntProperty)
    int32_t MaximumValue; // 0x30 (Size: 0x4, Type: IntProperty)
    FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings LimitsEnabled; // 0x34 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_36[0x2]; // 0x36 (Size: 0x2, Type: PaddingProperty)
    UEnum* ControlEnum; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannelInteger) == 0x40, "Size mismatch for FRigUnit_HierarchyAddAnimationChannelInteger");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelInteger, InitialValue) == 0x28, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelInteger::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelInteger, MinimumValue) == 0x2c, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelInteger::MinimumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelInteger, MaximumValue) == 0x30, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelInteger::MaximumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelInteger, LimitsEnabled) == 0x34, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelInteger::LimitsEnabled");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelInteger, ControlEnum) == 0x38, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelInteger::ControlEnum");

// Size: 0x4 (Inherited: 0x1, Single: 0x3)
struct FRigUnit_HierarchyAddAnimationChannel2DLimitSettings : FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings
{
    FRigControlLimitEnabled X; // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled Y; // 0x2 (Size: 0x2, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannel2DLimitSettings) == 0x4, "Size mismatch for FRigUnit_HierarchyAddAnimationChannel2DLimitSettings");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannel2DLimitSettings, X) == 0x0, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannel2DLimitSettings::X");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannel2DLimitSettings, Y) == 0x2, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannel2DLimitSettings::Y");

// Size: 0x60 (Inherited: 0x58, Single: 0x8)
struct FRigUnit_HierarchyAddAnimationChannelVector2D : FRigUnit_HierarchyAddElement
{
    FVector2D InitialValue; // 0x28 (Size: 0x10, Type: StructProperty)
    FVector2D MinimumValue; // 0x38 (Size: 0x10, Type: StructProperty)
    FVector2D MaximumValue; // 0x48 (Size: 0x10, Type: StructProperty)
    FRigUnit_HierarchyAddAnimationChannel2DLimitSettings LimitsEnabled; // 0x58 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannelVector2D) == 0x60, "Size mismatch for FRigUnit_HierarchyAddAnimationChannelVector2D");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelVector2D, InitialValue) == 0x28, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelVector2D::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelVector2D, MinimumValue) == 0x38, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelVector2D::MinimumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelVector2D, MaximumValue) == 0x48, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelVector2D::MaximumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelVector2D, LimitsEnabled) == 0x58, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelVector2D::LimitsEnabled");

// Size: 0x6 (Inherited: 0x1, Single: 0x5)
struct FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings : FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings
{
    FRigControlLimitEnabled X; // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled Y; // 0x2 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled Z; // 0x4 (Size: 0x2, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings) == 0x6, "Size mismatch for FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings, X) == 0x0, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings::X");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings, Y) == 0x2, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings::Y");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings, Z) == 0x4, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings::Z");

// Size: 0x78 (Inherited: 0x58, Single: 0x20)
struct FRigUnit_HierarchyAddAnimationChannelVector : FRigUnit_HierarchyAddElement
{
    FVector InitialValue; // 0x28 (Size: 0x18, Type: StructProperty)
    FVector MinimumValue; // 0x40 (Size: 0x18, Type: StructProperty)
    FVector MaximumValue; // 0x58 (Size: 0x18, Type: StructProperty)
    FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings LimitsEnabled; // 0x70 (Size: 0x6, Type: StructProperty)
    uint8_t Pad_76[0x2]; // 0x76 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannelVector) == 0x78, "Size mismatch for FRigUnit_HierarchyAddAnimationChannelVector");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelVector, InitialValue) == 0x28, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelVector::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelVector, MinimumValue) == 0x40, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelVector::MinimumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelVector, MaximumValue) == 0x58, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelVector::MaximumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelVector, LimitsEnabled) == 0x70, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelVector::LimitsEnabled");

// Size: 0x78 (Inherited: 0x58, Single: 0x20)
struct FRigUnit_HierarchyAddAnimationChannelScaleVector : FRigUnit_HierarchyAddElement
{
    FVector InitialValue; // 0x28 (Size: 0x18, Type: StructProperty)
    FVector MinimumValue; // 0x40 (Size: 0x18, Type: StructProperty)
    FVector MaximumValue; // 0x58 (Size: 0x18, Type: StructProperty)
    FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings LimitsEnabled; // 0x70 (Size: 0x6, Type: StructProperty)
    uint8_t Pad_76[0x2]; // 0x76 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannelScaleVector) == 0x78, "Size mismatch for FRigUnit_HierarchyAddAnimationChannelScaleVector");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelScaleVector, InitialValue) == 0x28, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelScaleVector::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelScaleVector, MinimumValue) == 0x40, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelScaleVector::MinimumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelScaleVector, MaximumValue) == 0x58, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelScaleVector::MaximumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelScaleVector, LimitsEnabled) == 0x70, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelScaleVector::LimitsEnabled");

// Size: 0x6 (Inherited: 0x1, Single: 0x5)
struct FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings : FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings
{
    FRigControlLimitEnabled pitch; // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled Yaw; // 0x2 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled Roll; // 0x4 (Size: 0x2, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings) == 0x6, "Size mismatch for FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings, pitch) == 0x0, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings::pitch");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings, Yaw) == 0x2, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings::Yaw");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings, Roll) == 0x4, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings::Roll");

// Size: 0x78 (Inherited: 0x58, Single: 0x20)
struct FRigUnit_HierarchyAddAnimationChannelRotator : FRigUnit_HierarchyAddElement
{
    FRotator InitialValue; // 0x28 (Size: 0x18, Type: StructProperty)
    FRotator MinimumValue; // 0x40 (Size: 0x18, Type: StructProperty)
    FRotator MaximumValue; // 0x58 (Size: 0x18, Type: StructProperty)
    FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings LimitsEnabled; // 0x70 (Size: 0x6, Type: StructProperty)
    uint8_t Pad_76[0x2]; // 0x76 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddAnimationChannelRotator) == 0x78, "Size mismatch for FRigUnit_HierarchyAddAnimationChannelRotator");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelRotator, InitialValue) == 0x28, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelRotator::InitialValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelRotator, MinimumValue) == 0x40, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelRotator::MinimumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelRotator, MaximumValue) == 0x58, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelRotator::MaximumValue");
static_assert(offsetof(FRigUnit_HierarchyAddAnimationChannelRotator, LimitsEnabled) == 0x70, "Offset mismatch for FRigUnit_HierarchyAddAnimationChannelRotator::LimitsEnabled");

// Size: 0x90 (Inherited: 0x18, Single: 0x78)
struct FRigUnit_HierarchyGetShapeSettings : FRigUnit_DynamicHierarchyBase
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Settings; // 0x10 (Size: 0x80, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyGetShapeSettings) == 0x90, "Size mismatch for FRigUnit_HierarchyGetShapeSettings");
static_assert(offsetof(FRigUnit_HierarchyGetShapeSettings, Item) == 0x8, "Offset mismatch for FRigUnit_HierarchyGetShapeSettings::Item");
static_assert(offsetof(FRigUnit_HierarchyGetShapeSettings, Settings) == 0x10, "Offset mismatch for FRigUnit_HierarchyGetShapeSettings::Settings");

// Size: 0xa0 (Inherited: 0x30, Single: 0x70)
struct FRigUnit_HierarchySetShapeSettings : FRigUnit_DynamicHierarchyBaseMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Settings; // 0x20 (Size: 0x80, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetShapeSettings) == 0xa0, "Size mismatch for FRigUnit_HierarchySetShapeSettings");
static_assert(offsetof(FRigUnit_HierarchySetShapeSettings, Item) == 0x10, "Offset mismatch for FRigUnit_HierarchySetShapeSettings::Item");
static_assert(offsetof(FRigUnit_HierarchySetShapeSettings, Settings) == 0x20, "Offset mismatch for FRigUnit_HierarchySetShapeSettings::Settings");

// Size: 0xc0 (Inherited: 0x58, Single: 0x68)
struct FRigUnit_HierarchyAddSocket : FRigUnit_HierarchyAddElement
{
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x30 (Size: 0x60, Type: StructProperty)
    uint8_t Space; // 0x90 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_91[0x3]; // 0x91 (Size: 0x3, Type: PaddingProperty)
    FLinearColor Color; // 0x94 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_a4[0x4]; // 0xa4 (Size: 0x4, Type: PaddingProperty)
    FString Description; // 0xa8 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddSocket) == 0xc0, "Size mismatch for FRigUnit_HierarchyAddSocket");
static_assert(offsetof(FRigUnit_HierarchyAddSocket, Transform) == 0x30, "Offset mismatch for FRigUnit_HierarchyAddSocket::Transform");
static_assert(offsetof(FRigUnit_HierarchyAddSocket, Space) == 0x90, "Offset mismatch for FRigUnit_HierarchyAddSocket::Space");
static_assert(offsetof(FRigUnit_HierarchyAddSocket, Color) == 0x94, "Offset mismatch for FRigUnit_HierarchyAddSocket::Color");
static_assert(offsetof(FRigUnit_HierarchyAddSocket, Description) == 0xa8, "Offset mismatch for FRigUnit_HierarchyAddSocket::Description");

// Size: 0x8 (Inherited: 0x10, Single: 0xfffffff8)
struct FRigUnit_HierarchyBase : FRigUnit
{
};

static_assert(sizeof(FRigUnit_HierarchyBase) == 0x8, "Size mismatch for FRigUnit_HierarchyBase");

// Size: 0x10 (Inherited: 0x20, Single: 0xfffffff0)
struct FRigUnit_HierarchyBaseMutable : FRigUnitMutable
{
};

static_assert(sizeof(FRigUnit_HierarchyBaseMutable) == 0x10, "Size mismatch for FRigUnit_HierarchyBaseMutable");

// Size: 0x50 (Inherited: 0x18, Single: 0x38)
struct FRigUnit_HierarchyGetParent : FRigUnit_HierarchyBase
{
    FRigElementKey Child; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bDefaultParent; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    FRigElementKey Parent; // 0x14 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FCachedRigElement CachedChild; // 0x20 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyGetParent) == 0x50, "Size mismatch for FRigUnit_HierarchyGetParent");
static_assert(offsetof(FRigUnit_HierarchyGetParent, Child) == 0x8, "Offset mismatch for FRigUnit_HierarchyGetParent::Child");
static_assert(offsetof(FRigUnit_HierarchyGetParent, bDefaultParent) == 0x10, "Offset mismatch for FRigUnit_HierarchyGetParent::bDefaultParent");
static_assert(offsetof(FRigUnit_HierarchyGetParent, Parent) == 0x14, "Offset mismatch for FRigUnit_HierarchyGetParent::Parent");
static_assert(offsetof(FRigUnit_HierarchyGetParent, CachedChild) == 0x20, "Offset mismatch for FRigUnit_HierarchyGetParent::CachedChild");
static_assert(offsetof(FRigUnit_HierarchyGetParent, CachedParent) == 0x38, "Offset mismatch for FRigUnit_HierarchyGetParent::CachedParent");

// Size: 0x50 (Inherited: 0x18, Single: 0x38)
struct FRigUnit_HierarchyGetParents : FRigUnit_HierarchyBase
{
    FRigElementKey Child; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeChild; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bReverse; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
    FRigElementKeyCollection Parents; // 0x18 (Size: 0x10, Type: StructProperty)
    FCachedRigElement CachedChild; // 0x28 (Size: 0x18, Type: StructProperty)
    FRigElementKeyCollection CachedParents; // 0x40 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyGetParents) == 0x50, "Size mismatch for FRigUnit_HierarchyGetParents");
static_assert(offsetof(FRigUnit_HierarchyGetParents, Child) == 0x8, "Offset mismatch for FRigUnit_HierarchyGetParents::Child");
static_assert(offsetof(FRigUnit_HierarchyGetParents, bIncludeChild) == 0x10, "Offset mismatch for FRigUnit_HierarchyGetParents::bIncludeChild");
static_assert(offsetof(FRigUnit_HierarchyGetParents, bReverse) == 0x11, "Offset mismatch for FRigUnit_HierarchyGetParents::bReverse");
static_assert(offsetof(FRigUnit_HierarchyGetParents, Parents) == 0x18, "Offset mismatch for FRigUnit_HierarchyGetParents::Parents");
static_assert(offsetof(FRigUnit_HierarchyGetParents, CachedChild) == 0x28, "Offset mismatch for FRigUnit_HierarchyGetParents::CachedChild");
static_assert(offsetof(FRigUnit_HierarchyGetParents, CachedParents) == 0x40, "Offset mismatch for FRigUnit_HierarchyGetParents::CachedParents");

// Size: 0x50 (Inherited: 0x18, Single: 0x38)
struct FRigUnit_HierarchyGetParentsItemArray : FRigUnit_HierarchyBase
{
    FRigElementKey Child; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeChild; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bReverse; // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bDefaultParent; // 0x12 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_13[0x5]; // 0x13 (Size: 0x5, Type: PaddingProperty)
    TArray<FRigElementKey> Parents; // 0x18 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedChild; // 0x28 (Size: 0x18, Type: StructProperty)
    FRigElementKeyCollection CachedParents; // 0x40 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyGetParentsItemArray) == 0x50, "Size mismatch for FRigUnit_HierarchyGetParentsItemArray");
static_assert(offsetof(FRigUnit_HierarchyGetParentsItemArray, Child) == 0x8, "Offset mismatch for FRigUnit_HierarchyGetParentsItemArray::Child");
static_assert(offsetof(FRigUnit_HierarchyGetParentsItemArray, bIncludeChild) == 0x10, "Offset mismatch for FRigUnit_HierarchyGetParentsItemArray::bIncludeChild");
static_assert(offsetof(FRigUnit_HierarchyGetParentsItemArray, bReverse) == 0x11, "Offset mismatch for FRigUnit_HierarchyGetParentsItemArray::bReverse");
static_assert(offsetof(FRigUnit_HierarchyGetParentsItemArray, bDefaultParent) == 0x12, "Offset mismatch for FRigUnit_HierarchyGetParentsItemArray::bDefaultParent");
static_assert(offsetof(FRigUnit_HierarchyGetParentsItemArray, Parents) == 0x18, "Offset mismatch for FRigUnit_HierarchyGetParentsItemArray::Parents");
static_assert(offsetof(FRigUnit_HierarchyGetParentsItemArray, CachedChild) == 0x28, "Offset mismatch for FRigUnit_HierarchyGetParentsItemArray::CachedChild");
static_assert(offsetof(FRigUnit_HierarchyGetParentsItemArray, CachedParents) == 0x40, "Offset mismatch for FRigUnit_HierarchyGetParentsItemArray::CachedParents");

// Size: 0x50 (Inherited: 0x18, Single: 0x38)
struct FRigUnit_HierarchyGetChildren : FRigUnit_HierarchyBase
{
    FRigElementKey Parent; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeParent; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bRecursive; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
    FRigElementKeyCollection Children; // 0x18 (Size: 0x10, Type: StructProperty)
    FCachedRigElement CachedParent; // 0x28 (Size: 0x18, Type: StructProperty)
    FRigElementKeyCollection CachedChildren; // 0x40 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyGetChildren) == 0x50, "Size mismatch for FRigUnit_HierarchyGetChildren");
static_assert(offsetof(FRigUnit_HierarchyGetChildren, Parent) == 0x8, "Offset mismatch for FRigUnit_HierarchyGetChildren::Parent");
static_assert(offsetof(FRigUnit_HierarchyGetChildren, bIncludeParent) == 0x10, "Offset mismatch for FRigUnit_HierarchyGetChildren::bIncludeParent");
static_assert(offsetof(FRigUnit_HierarchyGetChildren, bRecursive) == 0x11, "Offset mismatch for FRigUnit_HierarchyGetChildren::bRecursive");
static_assert(offsetof(FRigUnit_HierarchyGetChildren, Children) == 0x18, "Offset mismatch for FRigUnit_HierarchyGetChildren::Children");
static_assert(offsetof(FRigUnit_HierarchyGetChildren, CachedParent) == 0x28, "Offset mismatch for FRigUnit_HierarchyGetChildren::CachedParent");
static_assert(offsetof(FRigUnit_HierarchyGetChildren, CachedChildren) == 0x40, "Offset mismatch for FRigUnit_HierarchyGetChildren::CachedChildren");

// Size: 0x50 (Inherited: 0x18, Single: 0x38)
struct FRigUnit_HierarchyGetSiblings : FRigUnit_HierarchyBase
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeItem; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FRigElementKeyCollection Siblings; // 0x18 (Size: 0x10, Type: StructProperty)
    FCachedRigElement CachedItem; // 0x28 (Size: 0x18, Type: StructProperty)
    FRigElementKeyCollection CachedSiblings; // 0x40 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyGetSiblings) == 0x50, "Size mismatch for FRigUnit_HierarchyGetSiblings");
static_assert(offsetof(FRigUnit_HierarchyGetSiblings, Item) == 0x8, "Offset mismatch for FRigUnit_HierarchyGetSiblings::Item");
static_assert(offsetof(FRigUnit_HierarchyGetSiblings, bIncludeItem) == 0x10, "Offset mismatch for FRigUnit_HierarchyGetSiblings::bIncludeItem");
static_assert(offsetof(FRigUnit_HierarchyGetSiblings, Siblings) == 0x18, "Offset mismatch for FRigUnit_HierarchyGetSiblings::Siblings");
static_assert(offsetof(FRigUnit_HierarchyGetSiblings, CachedItem) == 0x28, "Offset mismatch for FRigUnit_HierarchyGetSiblings::CachedItem");
static_assert(offsetof(FRigUnit_HierarchyGetSiblings, CachedSiblings) == 0x40, "Offset mismatch for FRigUnit_HierarchyGetSiblings::CachedSiblings");

// Size: 0x50 (Inherited: 0x18, Single: 0x38)
struct FRigUnit_HierarchyGetSiblingsItemArray : FRigUnit_HierarchyBase
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeItem; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bDefaultSiblings; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
    TArray<FRigElementKey> Siblings; // 0x18 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedItem; // 0x28 (Size: 0x18, Type: StructProperty)
    FRigElementKeyCollection CachedSiblings; // 0x40 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyGetSiblingsItemArray) == 0x50, "Size mismatch for FRigUnit_HierarchyGetSiblingsItemArray");
static_assert(offsetof(FRigUnit_HierarchyGetSiblingsItemArray, Item) == 0x8, "Offset mismatch for FRigUnit_HierarchyGetSiblingsItemArray::Item");
static_assert(offsetof(FRigUnit_HierarchyGetSiblingsItemArray, bIncludeItem) == 0x10, "Offset mismatch for FRigUnit_HierarchyGetSiblingsItemArray::bIncludeItem");
static_assert(offsetof(FRigUnit_HierarchyGetSiblingsItemArray, bDefaultSiblings) == 0x11, "Offset mismatch for FRigUnit_HierarchyGetSiblingsItemArray::bDefaultSiblings");
static_assert(offsetof(FRigUnit_HierarchyGetSiblingsItemArray, Siblings) == 0x18, "Offset mismatch for FRigUnit_HierarchyGetSiblingsItemArray::Siblings");
static_assert(offsetof(FRigUnit_HierarchyGetSiblingsItemArray, CachedItem) == 0x28, "Offset mismatch for FRigUnit_HierarchyGetSiblingsItemArray::CachedItem");
static_assert(offsetof(FRigUnit_HierarchyGetSiblingsItemArray, CachedSiblings) == 0x40, "Offset mismatch for FRigUnit_HierarchyGetSiblingsItemArray::CachedSiblings");

// Size: 0x70 (Inherited: 0x18, Single: 0x58)
struct FRigUnit_HierarchyGetChainItemArray : FRigUnit_HierarchyBase
{
    FRigElementKey Start; // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey End; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bIncludeStart; // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bIncludeEnd; // 0x19 (Size: 0x1, Type: BoolProperty)
    bool bReverse; // 0x1a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1b[0x5]; // 0x1b (Size: 0x5, Type: PaddingProperty)
    TArray<FRigElementKey> Chain; // 0x20 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedStart; // 0x30 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedEnd; // 0x48 (Size: 0x18, Type: StructProperty)
    FRigElementKeyCollection CachedChain; // 0x60 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyGetChainItemArray) == 0x70, "Size mismatch for FRigUnit_HierarchyGetChainItemArray");
static_assert(offsetof(FRigUnit_HierarchyGetChainItemArray, Start) == 0x8, "Offset mismatch for FRigUnit_HierarchyGetChainItemArray::Start");
static_assert(offsetof(FRigUnit_HierarchyGetChainItemArray, End) == 0x10, "Offset mismatch for FRigUnit_HierarchyGetChainItemArray::End");
static_assert(offsetof(FRigUnit_HierarchyGetChainItemArray, bIncludeStart) == 0x18, "Offset mismatch for FRigUnit_HierarchyGetChainItemArray::bIncludeStart");
static_assert(offsetof(FRigUnit_HierarchyGetChainItemArray, bIncludeEnd) == 0x19, "Offset mismatch for FRigUnit_HierarchyGetChainItemArray::bIncludeEnd");
static_assert(offsetof(FRigUnit_HierarchyGetChainItemArray, bReverse) == 0x1a, "Offset mismatch for FRigUnit_HierarchyGetChainItemArray::bReverse");
static_assert(offsetof(FRigUnit_HierarchyGetChainItemArray, Chain) == 0x20, "Offset mismatch for FRigUnit_HierarchyGetChainItemArray::Chain");
static_assert(offsetof(FRigUnit_HierarchyGetChainItemArray, CachedStart) == 0x30, "Offset mismatch for FRigUnit_HierarchyGetChainItemArray::CachedStart");
static_assert(offsetof(FRigUnit_HierarchyGetChainItemArray, CachedEnd) == 0x48, "Offset mismatch for FRigUnit_HierarchyGetChainItemArray::CachedEnd");
static_assert(offsetof(FRigUnit_HierarchyGetChainItemArray, CachedChain) == 0x60, "Offset mismatch for FRigUnit_HierarchyGetChainItemArray::CachedChain");

// Size: 0x90 (Inherited: 0x18, Single: 0x78)
struct FRigUnit_HierarchyGetPose : FRigUnit_HierarchyBase
{
    bool Initial; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t ElementType; // 0x9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a[0x6]; // 0xa (Size: 0x6, Type: PaddingProperty)
    FRigElementKeyCollection ItemsToGet; // 0x10 (Size: 0x10, Type: StructProperty)
    FRigPose Pose; // 0x20 (Size: 0x70, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyGetPose) == 0x90, "Size mismatch for FRigUnit_HierarchyGetPose");
static_assert(offsetof(FRigUnit_HierarchyGetPose, Initial) == 0x8, "Offset mismatch for FRigUnit_HierarchyGetPose::Initial");
static_assert(offsetof(FRigUnit_HierarchyGetPose, ElementType) == 0x9, "Offset mismatch for FRigUnit_HierarchyGetPose::ElementType");
static_assert(offsetof(FRigUnit_HierarchyGetPose, ItemsToGet) == 0x10, "Offset mismatch for FRigUnit_HierarchyGetPose::ItemsToGet");
static_assert(offsetof(FRigUnit_HierarchyGetPose, Pose) == 0x20, "Offset mismatch for FRigUnit_HierarchyGetPose::Pose");

// Size: 0x90 (Inherited: 0x18, Single: 0x78)
struct FRigUnit_HierarchyGetPoseItemArray : FRigUnit_HierarchyBase
{
    bool Initial; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t ElementType; // 0x9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a[0x6]; // 0xa (Size: 0x6, Type: PaddingProperty)
    TArray<FRigElementKey> ItemsToGet; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FRigPose Pose; // 0x20 (Size: 0x70, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyGetPoseItemArray) == 0x90, "Size mismatch for FRigUnit_HierarchyGetPoseItemArray");
static_assert(offsetof(FRigUnit_HierarchyGetPoseItemArray, Initial) == 0x8, "Offset mismatch for FRigUnit_HierarchyGetPoseItemArray::Initial");
static_assert(offsetof(FRigUnit_HierarchyGetPoseItemArray, ElementType) == 0x9, "Offset mismatch for FRigUnit_HierarchyGetPoseItemArray::ElementType");
static_assert(offsetof(FRigUnit_HierarchyGetPoseItemArray, ItemsToGet) == 0x10, "Offset mismatch for FRigUnit_HierarchyGetPoseItemArray::ItemsToGet");
static_assert(offsetof(FRigUnit_HierarchyGetPoseItemArray, Pose) == 0x20, "Offset mismatch for FRigUnit_HierarchyGetPoseItemArray::Pose");

// Size: 0xa0 (Inherited: 0x30, Single: 0x70)
struct FRigUnit_HierarchySetPose : FRigUnit_HierarchyBaseMutable
{
    FRigPose Pose; // 0x10 (Size: 0x70, Type: StructProperty)
    uint8_t ElementType; // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t Space; // 0x81 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_82[0x6]; // 0x82 (Size: 0x6, Type: PaddingProperty)
    FRigElementKeyCollection ItemsToSet; // 0x88 (Size: 0x10, Type: StructProperty)
    float Weight; // 0x98 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPose) == 0xa0, "Size mismatch for FRigUnit_HierarchySetPose");
static_assert(offsetof(FRigUnit_HierarchySetPose, Pose) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPose::Pose");
static_assert(offsetof(FRigUnit_HierarchySetPose, ElementType) == 0x80, "Offset mismatch for FRigUnit_HierarchySetPose::ElementType");
static_assert(offsetof(FRigUnit_HierarchySetPose, Space) == 0x81, "Offset mismatch for FRigUnit_HierarchySetPose::Space");
static_assert(offsetof(FRigUnit_HierarchySetPose, ItemsToSet) == 0x88, "Offset mismatch for FRigUnit_HierarchySetPose::ItemsToSet");
static_assert(offsetof(FRigUnit_HierarchySetPose, Weight) == 0x98, "Offset mismatch for FRigUnit_HierarchySetPose::Weight");

// Size: 0xa0 (Inherited: 0x30, Single: 0x70)
struct FRigUnit_HierarchySetPoseItemArray : FRigUnit_HierarchyBaseMutable
{
    FRigPose Pose; // 0x10 (Size: 0x70, Type: StructProperty)
    uint8_t ElementType; // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t Space; // 0x81 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_82[0x6]; // 0x82 (Size: 0x6, Type: PaddingProperty)
    TArray<FRigElementKey> ItemsToSet; // 0x88 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x98 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_9c[0x4]; // 0x9c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchySetPoseItemArray) == 0xa0, "Size mismatch for FRigUnit_HierarchySetPoseItemArray");
static_assert(offsetof(FRigUnit_HierarchySetPoseItemArray, Pose) == 0x10, "Offset mismatch for FRigUnit_HierarchySetPoseItemArray::Pose");
static_assert(offsetof(FRigUnit_HierarchySetPoseItemArray, ElementType) == 0x80, "Offset mismatch for FRigUnit_HierarchySetPoseItemArray::ElementType");
static_assert(offsetof(FRigUnit_HierarchySetPoseItemArray, Space) == 0x81, "Offset mismatch for FRigUnit_HierarchySetPoseItemArray::Space");
static_assert(offsetof(FRigUnit_HierarchySetPoseItemArray, ItemsToSet) == 0x88, "Offset mismatch for FRigUnit_HierarchySetPoseItemArray::ItemsToSet");
static_assert(offsetof(FRigUnit_HierarchySetPoseItemArray, Weight) == 0x98, "Offset mismatch for FRigUnit_HierarchySetPoseItemArray::Weight");

// Size: 0x80 (Inherited: 0x18, Single: 0x68)
struct FRigUnit_PoseIsEmpty : FRigUnit_HierarchyBase
{
    FRigPose Pose; // 0x8 (Size: 0x70, Type: StructProperty)
    bool IsEmpty; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_PoseIsEmpty) == 0x80, "Size mismatch for FRigUnit_PoseIsEmpty");
static_assert(offsetof(FRigUnit_PoseIsEmpty, Pose) == 0x8, "Offset mismatch for FRigUnit_PoseIsEmpty::Pose");
static_assert(offsetof(FRigUnit_PoseIsEmpty, IsEmpty) == 0x78, "Offset mismatch for FRigUnit_PoseIsEmpty::IsEmpty");

// Size: 0x90 (Inherited: 0x18, Single: 0x78)
struct FRigUnit_PoseGetItems : FRigUnit_HierarchyBase
{
    FRigPose Pose; // 0x8 (Size: 0x70, Type: StructProperty)
    uint8_t ElementType; // 0x78 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
    FRigElementKeyCollection Items; // 0x80 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_PoseGetItems) == 0x90, "Size mismatch for FRigUnit_PoseGetItems");
static_assert(offsetof(FRigUnit_PoseGetItems, Pose) == 0x8, "Offset mismatch for FRigUnit_PoseGetItems::Pose");
static_assert(offsetof(FRigUnit_PoseGetItems, ElementType) == 0x78, "Offset mismatch for FRigUnit_PoseGetItems::ElementType");
static_assert(offsetof(FRigUnit_PoseGetItems, Items) == 0x80, "Offset mismatch for FRigUnit_PoseGetItems::Items");

// Size: 0x90 (Inherited: 0x18, Single: 0x78)
struct FRigUnit_PoseGetItemsItemArray : FRigUnit_HierarchyBase
{
    FRigPose Pose; // 0x8 (Size: 0x70, Type: StructProperty)
    uint8_t ElementType; // 0x78 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
    TArray<FRigElementKey> Items; // 0x80 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_PoseGetItemsItemArray) == 0x90, "Size mismatch for FRigUnit_PoseGetItemsItemArray");
static_assert(offsetof(FRigUnit_PoseGetItemsItemArray, Pose) == 0x8, "Offset mismatch for FRigUnit_PoseGetItemsItemArray::Pose");
static_assert(offsetof(FRigUnit_PoseGetItemsItemArray, ElementType) == 0x78, "Offset mismatch for FRigUnit_PoseGetItemsItemArray::ElementType");
static_assert(offsetof(FRigUnit_PoseGetItemsItemArray, Items) == 0x80, "Offset mismatch for FRigUnit_PoseGetItemsItemArray::Items");

// Size: 0x128 (Inherited: 0x18, Single: 0x110)
struct FRigUnit_PoseGetDelta : FRigUnit_HierarchyBase
{
    FRigPose PoseA; // 0x8 (Size: 0x70, Type: StructProperty)
    FRigPose PoseB; // 0x78 (Size: 0x70, Type: StructProperty)
    float PositionThreshold; // 0xe8 (Size: 0x4, Type: FloatProperty)
    float RotationThreshold; // 0xec (Size: 0x4, Type: FloatProperty)
    float ScaleThreshold; // 0xf0 (Size: 0x4, Type: FloatProperty)
    float CurveThreshold; // 0xf4 (Size: 0x4, Type: FloatProperty)
    uint8_t ElementType; // 0xf8 (Size: 0x1, Type: EnumProperty)
    uint8_t Space; // 0xf9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_fa[0x6]; // 0xfa (Size: 0x6, Type: PaddingProperty)
    FRigElementKeyCollection ItemsToCompare; // 0x100 (Size: 0x10, Type: StructProperty)
    bool PosesAreEqual; // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_111[0x7]; // 0x111 (Size: 0x7, Type: PaddingProperty)
    FRigElementKeyCollection ItemsWithDelta; // 0x118 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_PoseGetDelta) == 0x128, "Size mismatch for FRigUnit_PoseGetDelta");
static_assert(offsetof(FRigUnit_PoseGetDelta, PoseA) == 0x8, "Offset mismatch for FRigUnit_PoseGetDelta::PoseA");
static_assert(offsetof(FRigUnit_PoseGetDelta, PoseB) == 0x78, "Offset mismatch for FRigUnit_PoseGetDelta::PoseB");
static_assert(offsetof(FRigUnit_PoseGetDelta, PositionThreshold) == 0xe8, "Offset mismatch for FRigUnit_PoseGetDelta::PositionThreshold");
static_assert(offsetof(FRigUnit_PoseGetDelta, RotationThreshold) == 0xec, "Offset mismatch for FRigUnit_PoseGetDelta::RotationThreshold");
static_assert(offsetof(FRigUnit_PoseGetDelta, ScaleThreshold) == 0xf0, "Offset mismatch for FRigUnit_PoseGetDelta::ScaleThreshold");
static_assert(offsetof(FRigUnit_PoseGetDelta, CurveThreshold) == 0xf4, "Offset mismatch for FRigUnit_PoseGetDelta::CurveThreshold");
static_assert(offsetof(FRigUnit_PoseGetDelta, ElementType) == 0xf8, "Offset mismatch for FRigUnit_PoseGetDelta::ElementType");
static_assert(offsetof(FRigUnit_PoseGetDelta, Space) == 0xf9, "Offset mismatch for FRigUnit_PoseGetDelta::Space");
static_assert(offsetof(FRigUnit_PoseGetDelta, ItemsToCompare) == 0x100, "Offset mismatch for FRigUnit_PoseGetDelta::ItemsToCompare");
static_assert(offsetof(FRigUnit_PoseGetDelta, PosesAreEqual) == 0x110, "Offset mismatch for FRigUnit_PoseGetDelta::PosesAreEqual");
static_assert(offsetof(FRigUnit_PoseGetDelta, ItemsWithDelta) == 0x118, "Offset mismatch for FRigUnit_PoseGetDelta::ItemsWithDelta");

// Size: 0x100 (Inherited: 0x18, Single: 0xe8)
struct FRigUnit_PoseGetTransform : FRigUnit_HierarchyBase
{
    FRigPose Pose; // 0x8 (Size: 0x70, Type: StructProperty)
    FRigElementKey Item; // 0x78 (Size: 0x8, Type: StructProperty)
    uint8_t Space; // 0x80 (Size: 0x1, Type: EnumProperty)
    bool Valid; // 0x81 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_82[0xe]; // 0x82 (Size: 0xe, Type: PaddingProperty)
    FTransform Transform; // 0x90 (Size: 0x60, Type: StructProperty)
    float CurveValue; // 0xf0 (Size: 0x4, Type: FloatProperty)
    int32_t CachedPoseElementIndex; // 0xf4 (Size: 0x4, Type: IntProperty)
    int32_t CachedPoseHash; // 0xf8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_fc[0x4]; // 0xfc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_PoseGetTransform) == 0x100, "Size mismatch for FRigUnit_PoseGetTransform");
static_assert(offsetof(FRigUnit_PoseGetTransform, Pose) == 0x8, "Offset mismatch for FRigUnit_PoseGetTransform::Pose");
static_assert(offsetof(FRigUnit_PoseGetTransform, Item) == 0x78, "Offset mismatch for FRigUnit_PoseGetTransform::Item");
static_assert(offsetof(FRigUnit_PoseGetTransform, Space) == 0x80, "Offset mismatch for FRigUnit_PoseGetTransform::Space");
static_assert(offsetof(FRigUnit_PoseGetTransform, Valid) == 0x81, "Offset mismatch for FRigUnit_PoseGetTransform::Valid");
static_assert(offsetof(FRigUnit_PoseGetTransform, Transform) == 0x90, "Offset mismatch for FRigUnit_PoseGetTransform::Transform");
static_assert(offsetof(FRigUnit_PoseGetTransform, CurveValue) == 0xf0, "Offset mismatch for FRigUnit_PoseGetTransform::CurveValue");
static_assert(offsetof(FRigUnit_PoseGetTransform, CachedPoseElementIndex) == 0xf4, "Offset mismatch for FRigUnit_PoseGetTransform::CachedPoseElementIndex");
static_assert(offsetof(FRigUnit_PoseGetTransform, CachedPoseHash) == 0xf8, "Offset mismatch for FRigUnit_PoseGetTransform::CachedPoseHash");

// Size: 0x90 (Inherited: 0x18, Single: 0x78)
struct FRigUnit_PoseGetTransformArray : FRigUnit_HierarchyBase
{
    FRigPose Pose; // 0x8 (Size: 0x70, Type: StructProperty)
    uint8_t Space; // 0x78 (Size: 0x1, Type: EnumProperty)
    bool Valid; // 0x79 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7a[0x6]; // 0x7a (Size: 0x6, Type: PaddingProperty)
    TArray<FTransform> Transforms; // 0x80 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_PoseGetTransformArray) == 0x90, "Size mismatch for FRigUnit_PoseGetTransformArray");
static_assert(offsetof(FRigUnit_PoseGetTransformArray, Pose) == 0x8, "Offset mismatch for FRigUnit_PoseGetTransformArray::Pose");
static_assert(offsetof(FRigUnit_PoseGetTransformArray, Space) == 0x78, "Offset mismatch for FRigUnit_PoseGetTransformArray::Space");
static_assert(offsetof(FRigUnit_PoseGetTransformArray, Valid) == 0x79, "Offset mismatch for FRigUnit_PoseGetTransformArray::Valid");
static_assert(offsetof(FRigUnit_PoseGetTransformArray, Transforms) == 0x80, "Offset mismatch for FRigUnit_PoseGetTransformArray::Transforms");

// Size: 0x90 (Inherited: 0x18, Single: 0x78)
struct FRigUnit_PoseGetCurve : FRigUnit_HierarchyBase
{
    FRigPose Pose; // 0x8 (Size: 0x70, Type: StructProperty)
    FName Curve; // 0x78 (Size: 0x4, Type: NameProperty)
    bool Valid; // 0x7c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7d[0x3]; // 0x7d (Size: 0x3, Type: PaddingProperty)
    float CurveValue; // 0x80 (Size: 0x4, Type: FloatProperty)
    int32_t CachedPoseElementIndex; // 0x84 (Size: 0x4, Type: IntProperty)
    int32_t CachedPoseHash; // 0x88 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_PoseGetCurve) == 0x90, "Size mismatch for FRigUnit_PoseGetCurve");
static_assert(offsetof(FRigUnit_PoseGetCurve, Pose) == 0x8, "Offset mismatch for FRigUnit_PoseGetCurve::Pose");
static_assert(offsetof(FRigUnit_PoseGetCurve, Curve) == 0x78, "Offset mismatch for FRigUnit_PoseGetCurve::Curve");
static_assert(offsetof(FRigUnit_PoseGetCurve, Valid) == 0x7c, "Offset mismatch for FRigUnit_PoseGetCurve::Valid");
static_assert(offsetof(FRigUnit_PoseGetCurve, CurveValue) == 0x80, "Offset mismatch for FRigUnit_PoseGetCurve::CurveValue");
static_assert(offsetof(FRigUnit_PoseGetCurve, CachedPoseElementIndex) == 0x84, "Offset mismatch for FRigUnit_PoseGetCurve::CachedPoseElementIndex");
static_assert(offsetof(FRigUnit_PoseGetCurve, CachedPoseHash) == 0x88, "Offset mismatch for FRigUnit_PoseGetCurve::CachedPoseHash");

// Size: 0x350 (Inherited: 0x30, Single: 0x320)
struct FRigUnit_PoseLoop : FRigUnit_HierarchyBaseMutable
{
    FName BlockToRun; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FRigPose Pose; // 0x18 (Size: 0x70, Type: StructProperty)
    FRigElementKey Item; // 0x88 (Size: 0x8, Type: StructProperty)
    FTransform GlobalTransform; // 0x90 (Size: 0x60, Type: StructProperty)
    FTransform LocalTransform; // 0xf0 (Size: 0x60, Type: StructProperty)
    float CurveValue; // 0x150 (Size: 0x4, Type: FloatProperty)
    int32_t Index; // 0x154 (Size: 0x4, Type: IntProperty)
    int32_t Count; // 0x158 (Size: 0x4, Type: IntProperty)
    float Ratio; // 0x15c (Size: 0x4, Type: FloatProperty)
    FControlRigExecuteContext Completed; // 0x160 (Size: 0x1f0, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_PoseLoop) == 0x350, "Size mismatch for FRigUnit_PoseLoop");
static_assert(offsetof(FRigUnit_PoseLoop, BlockToRun) == 0x10, "Offset mismatch for FRigUnit_PoseLoop::BlockToRun");
static_assert(offsetof(FRigUnit_PoseLoop, Pose) == 0x18, "Offset mismatch for FRigUnit_PoseLoop::Pose");
static_assert(offsetof(FRigUnit_PoseLoop, Item) == 0x88, "Offset mismatch for FRigUnit_PoseLoop::Item");
static_assert(offsetof(FRigUnit_PoseLoop, GlobalTransform) == 0x90, "Offset mismatch for FRigUnit_PoseLoop::GlobalTransform");
static_assert(offsetof(FRigUnit_PoseLoop, LocalTransform) == 0xf0, "Offset mismatch for FRigUnit_PoseLoop::LocalTransform");
static_assert(offsetof(FRigUnit_PoseLoop, CurveValue) == 0x150, "Offset mismatch for FRigUnit_PoseLoop::CurveValue");
static_assert(offsetof(FRigUnit_PoseLoop, Index) == 0x154, "Offset mismatch for FRigUnit_PoseLoop::Index");
static_assert(offsetof(FRigUnit_PoseLoop, Count) == 0x158, "Offset mismatch for FRigUnit_PoseLoop::Count");
static_assert(offsetof(FRigUnit_PoseLoop, Ratio) == 0x15c, "Offset mismatch for FRigUnit_PoseLoop::Ratio");
static_assert(offsetof(FRigUnit_PoseLoop, Completed) == 0x160, "Offset mismatch for FRigUnit_PoseLoop::Completed");

// Size: 0x100 (Inherited: 0x0, Single: 0x100)
struct FRigUnit_HierarchyCreatePoseItemArray_Entry
{
    FRigElementKey Item; // 0x0 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform LocalTransform; // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform GlobalTransform; // 0x70 (Size: 0x60, Type: StructProperty)
    bool UseEulerAngles; // 0xd0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d1[0x7]; // 0xd1 (Size: 0x7, Type: PaddingProperty)
    FVector EulerAngles; // 0xd8 (Size: 0x18, Type: StructProperty)
    float CurveValue; // 0xf0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_f4[0xc]; // 0xf4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyCreatePoseItemArray_Entry) == 0x100, "Size mismatch for FRigUnit_HierarchyCreatePoseItemArray_Entry");
static_assert(offsetof(FRigUnit_HierarchyCreatePoseItemArray_Entry, Item) == 0x0, "Offset mismatch for FRigUnit_HierarchyCreatePoseItemArray_Entry::Item");
static_assert(offsetof(FRigUnit_HierarchyCreatePoseItemArray_Entry, LocalTransform) == 0x10, "Offset mismatch for FRigUnit_HierarchyCreatePoseItemArray_Entry::LocalTransform");
static_assert(offsetof(FRigUnit_HierarchyCreatePoseItemArray_Entry, GlobalTransform) == 0x70, "Offset mismatch for FRigUnit_HierarchyCreatePoseItemArray_Entry::GlobalTransform");
static_assert(offsetof(FRigUnit_HierarchyCreatePoseItemArray_Entry, UseEulerAngles) == 0xd0, "Offset mismatch for FRigUnit_HierarchyCreatePoseItemArray_Entry::UseEulerAngles");
static_assert(offsetof(FRigUnit_HierarchyCreatePoseItemArray_Entry, EulerAngles) == 0xd8, "Offset mismatch for FRigUnit_HierarchyCreatePoseItemArray_Entry::EulerAngles");
static_assert(offsetof(FRigUnit_HierarchyCreatePoseItemArray_Entry, CurveValue) == 0xf0, "Offset mismatch for FRigUnit_HierarchyCreatePoseItemArray_Entry::CurveValue");

// Size: 0x88 (Inherited: 0x18, Single: 0x70)
struct FRigUnit_HierarchyCreatePoseItemArray : FRigUnit_HierarchyBase
{
    TArray<FRigUnit_HierarchyCreatePoseItemArray_Entry> Entries; // 0x8 (Size: 0x10, Type: ArrayProperty)
    FRigPose Pose; // 0x18 (Size: 0x70, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyCreatePoseItemArray) == 0x88, "Size mismatch for FRigUnit_HierarchyCreatePoseItemArray");
static_assert(offsetof(FRigUnit_HierarchyCreatePoseItemArray, Entries) == 0x8, "Offset mismatch for FRigUnit_HierarchyCreatePoseItemArray::Entries");
static_assert(offsetof(FRigUnit_HierarchyCreatePoseItemArray, Pose) == 0x18, "Offset mismatch for FRigUnit_HierarchyCreatePoseItemArray::Pose");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_InteractionExecution : FRigUnit
{
    FRigVMExecutePin ExecutePin; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_InteractionExecution) == 0x10, "Size mismatch for FRigUnit_InteractionExecution");
static_assert(offsetof(FRigUnit_InteractionExecution, ExecutePin) == 0x8, "Offset mismatch for FRigUnit_InteractionExecution::ExecutePin");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_InverseExecution : FRigUnit
{
    FRigVMExecutePin ExecutePin; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_InverseExecution) == 0x10, "Size mismatch for FRigUnit_InverseExecution");
static_assert(offsetof(FRigUnit_InverseExecution, ExecutePin) == 0x8, "Offset mismatch for FRigUnit_InverseExecution::ExecutePin");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FRigUnit_IsInteracting : FRigUnit
{
    bool bIsInteracting; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bIsTranslating; // 0x9 (Size: 0x1, Type: BoolProperty)
    bool bIsRotating; // 0xa (Size: 0x1, Type: BoolProperty)
    bool bIsScaling; // 0xb (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_IsInteracting) == 0x20, "Size mismatch for FRigUnit_IsInteracting");
static_assert(offsetof(FRigUnit_IsInteracting, bIsInteracting) == 0x8, "Offset mismatch for FRigUnit_IsInteracting::bIsInteracting");
static_assert(offsetof(FRigUnit_IsInteracting, bIsTranslating) == 0x9, "Offset mismatch for FRigUnit_IsInteracting::bIsTranslating");
static_assert(offsetof(FRigUnit_IsInteracting, bIsRotating) == 0xa, "Offset mismatch for FRigUnit_IsInteracting::bIsRotating");
static_assert(offsetof(FRigUnit_IsInteracting, bIsScaling) == 0xb, "Offset mismatch for FRigUnit_IsInteracting::bIsScaling");
static_assert(offsetof(FRigUnit_IsInteracting, Items) == 0x10, "Offset mismatch for FRigUnit_IsInteracting::Items");

// Size: 0x8 (Inherited: 0x10, Single: 0xfffffff8)
struct FRigUnit_ItemBase : FRigUnit
{
};

static_assert(sizeof(FRigUnit_ItemBase) == 0x8, "Size mismatch for FRigUnit_ItemBase");

// Size: 0x10 (Inherited: 0x20, Single: 0xfffffff0)
struct FRigUnit_ItemBaseMutable : FRigUnitMutable
{
};

static_assert(sizeof(FRigUnit_ItemBaseMutable) == 0x10, "Size mismatch for FRigUnit_ItemBaseMutable");

// Size: 0x30 (Inherited: 0x18, Single: 0x18)
struct FRigUnit_ItemExists : FRigUnit_ItemBase
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    bool Exists; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ItemExists) == 0x30, "Size mismatch for FRigUnit_ItemExists");
static_assert(offsetof(FRigUnit_ItemExists, Item) == 0x8, "Offset mismatch for FRigUnit_ItemExists::Item");
static_assert(offsetof(FRigUnit_ItemExists, Exists) == 0x10, "Offset mismatch for FRigUnit_ItemExists::Exists");
static_assert(offsetof(FRigUnit_ItemExists, CachedIndex) == 0x18, "Offset mismatch for FRigUnit_ItemExists::CachedIndex");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigUnit_ItemReplace : FRigUnit_ItemBase
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    FName Old; // 0x10 (Size: 0x4, Type: NameProperty)
    FName New; // 0x14 (Size: 0x4, Type: NameProperty)
    FRigElementKey Result; // 0x18 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ItemReplace) == 0x20, "Size mismatch for FRigUnit_ItemReplace");
static_assert(offsetof(FRigUnit_ItemReplace, Item) == 0x8, "Offset mismatch for FRigUnit_ItemReplace::Item");
static_assert(offsetof(FRigUnit_ItemReplace, Old) == 0x10, "Offset mismatch for FRigUnit_ItemReplace::Old");
static_assert(offsetof(FRigUnit_ItemReplace, New) == 0x14, "Offset mismatch for FRigUnit_ItemReplace::New");
static_assert(offsetof(FRigUnit_ItemReplace, Result) == 0x18, "Offset mismatch for FRigUnit_ItemReplace::Result");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigUnit_ItemEquals : FRigUnit_ItemBase
{
    FRigElementKey A; // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey B; // 0x10 (Size: 0x8, Type: StructProperty)
    bool Result; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ItemEquals) == 0x20, "Size mismatch for FRigUnit_ItemEquals");
static_assert(offsetof(FRigUnit_ItemEquals, A) == 0x8, "Offset mismatch for FRigUnit_ItemEquals::A");
static_assert(offsetof(FRigUnit_ItemEquals, B) == 0x10, "Offset mismatch for FRigUnit_ItemEquals::B");
static_assert(offsetof(FRigUnit_ItemEquals, Result) == 0x18, "Offset mismatch for FRigUnit_ItemEquals::Result");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigUnit_ItemNotEquals : FRigUnit_ItemBase
{
    FRigElementKey A; // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey B; // 0x10 (Size: 0x8, Type: StructProperty)
    bool Result; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ItemNotEquals) == 0x20, "Size mismatch for FRigUnit_ItemNotEquals");
static_assert(offsetof(FRigUnit_ItemNotEquals, A) == 0x8, "Offset mismatch for FRigUnit_ItemNotEquals::A");
static_assert(offsetof(FRigUnit_ItemNotEquals, B) == 0x10, "Offset mismatch for FRigUnit_ItemNotEquals::B");
static_assert(offsetof(FRigUnit_ItemNotEquals, Result) == 0x18, "Offset mismatch for FRigUnit_ItemNotEquals::Result");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigUnit_ItemTypeEquals : FRigUnit_ItemBase
{
    FRigElementKey A; // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey B; // 0x10 (Size: 0x8, Type: StructProperty)
    bool Result; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ItemTypeEquals) == 0x20, "Size mismatch for FRigUnit_ItemTypeEquals");
static_assert(offsetof(FRigUnit_ItemTypeEquals, A) == 0x8, "Offset mismatch for FRigUnit_ItemTypeEquals::A");
static_assert(offsetof(FRigUnit_ItemTypeEquals, B) == 0x10, "Offset mismatch for FRigUnit_ItemTypeEquals::B");
static_assert(offsetof(FRigUnit_ItemTypeEquals, Result) == 0x18, "Offset mismatch for FRigUnit_ItemTypeEquals::Result");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigUnit_ItemTypeNotEquals : FRigUnit_ItemBase
{
    FRigElementKey A; // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey B; // 0x10 (Size: 0x8, Type: StructProperty)
    bool Result; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ItemTypeNotEquals) == 0x20, "Size mismatch for FRigUnit_ItemTypeNotEquals");
static_assert(offsetof(FRigUnit_ItemTypeNotEquals, A) == 0x8, "Offset mismatch for FRigUnit_ItemTypeNotEquals::A");
static_assert(offsetof(FRigUnit_ItemTypeNotEquals, B) == 0x10, "Offset mismatch for FRigUnit_ItemTypeNotEquals::B");
static_assert(offsetof(FRigUnit_ItemTypeNotEquals, Result) == 0x18, "Offset mismatch for FRigUnit_ItemTypeNotEquals::Result");

// Size: 0x18 (Inherited: 0x18, Single: 0x0)
struct FRigUnit_ItemToName : FRigUnit_ItemBase
{
    FRigElementKey Value; // 0x8 (Size: 0x8, Type: StructProperty)
    FName Result; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ItemToName) == 0x18, "Size mismatch for FRigUnit_ItemToName");
static_assert(offsetof(FRigUnit_ItemToName, Value) == 0x8, "Offset mismatch for FRigUnit_ItemToName::Value");
static_assert(offsetof(FRigUnit_ItemToName, Result) == 0x10, "Offset mismatch for FRigUnit_ItemToName::Result");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_HierarchyAddPhysicsSolver : FRigUnit_DynamicHierarchyBaseMutable
{
    FName Name; // 0x10 (Size: 0x4, Type: NameProperty)
    FRigPhysicsSolverID Solver; // 0x14 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddPhysicsSolver) == 0x28, "Size mismatch for FRigUnit_HierarchyAddPhysicsSolver");
static_assert(offsetof(FRigUnit_HierarchyAddPhysicsSolver, Name) == 0x10, "Offset mismatch for FRigUnit_HierarchyAddPhysicsSolver::Name");
static_assert(offsetof(FRigUnit_HierarchyAddPhysicsSolver, Solver) == 0x14, "Offset mismatch for FRigUnit_HierarchyAddPhysicsSolver::Solver");

// Size: 0xa0 (Inherited: 0x58, Single: 0x48)
struct FRigUnit_HierarchyAddPhysicsJoint : FRigUnit_HierarchyAddElement
{
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x30 (Size: 0x60, Type: StructProperty)
    FRigPhysicsSolverID Solver; // 0x90 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HierarchyAddPhysicsJoint) == 0xa0, "Size mismatch for FRigUnit_HierarchyAddPhysicsJoint");
static_assert(offsetof(FRigUnit_HierarchyAddPhysicsJoint, Transform) == 0x30, "Offset mismatch for FRigUnit_HierarchyAddPhysicsJoint::Transform");
static_assert(offsetof(FRigUnit_HierarchyAddPhysicsJoint, Solver) == 0x90, "Offset mismatch for FRigUnit_HierarchyAddPhysicsJoint::Solver");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_PrepareForExecution : FRigUnit
{
    FRigVMExecutePin ExecutePin; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_PrepareForExecution) == 0x10, "Size mismatch for FRigUnit_PrepareForExecution");
static_assert(offsetof(FRigUnit_PrepareForExecution, ExecutePin) == 0x8, "Offset mismatch for FRigUnit_PrepareForExecution::ExecutePin");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_PostPrepareForExecution : FRigUnit
{
    FRigVMExecutePin ExecutePin; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_PostPrepareForExecution) == 0x10, "Size mismatch for FRigUnit_PostPrepareForExecution");
static_assert(offsetof(FRigUnit_PostPrepareForExecution, ExecutePin) == 0x8, "Offset mismatch for FRigUnit_PostPrepareForExecution::ExecutePin");

// Size: 0x8 (Inherited: 0x10, Single: 0xfffffff8)
struct FRigUnit_RigModulesBase : FRigUnit
{
};

static_assert(sizeof(FRigUnit_RigModulesBase) == 0x8, "Size mismatch for FRigUnit_RigModulesBase");

// Size: 0x10 (Inherited: 0x20, Single: 0xfffffff0)
struct FRigUnit_RigModulesBaseMutable : FRigUnitMutable
{
};

static_assert(sizeof(FRigUnit_RigModulesBaseMutable) == 0x10, "Size mismatch for FRigUnit_RigModulesBaseMutable");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigUnit_ResolveConnector : FRigUnit_RigModulesBase
{
    FRigElementKey Connector; // 0x8 (Size: 0x8, Type: StructProperty)
    bool SkipSocket; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    FRigElementKey Result; // 0x14 (Size: 0x8, Type: StructProperty)
    bool bIsConnected; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ResolveConnector) == 0x20, "Size mismatch for FRigUnit_ResolveConnector");
static_assert(offsetof(FRigUnit_ResolveConnector, Connector) == 0x8, "Offset mismatch for FRigUnit_ResolveConnector::Connector");
static_assert(offsetof(FRigUnit_ResolveConnector, SkipSocket) == 0x10, "Offset mismatch for FRigUnit_ResolveConnector::SkipSocket");
static_assert(offsetof(FRigUnit_ResolveConnector, Result) == 0x14, "Offset mismatch for FRigUnit_ResolveConnector::Result");
static_assert(offsetof(FRigUnit_ResolveConnector, bIsConnected) == 0x1c, "Offset mismatch for FRigUnit_ResolveConnector::bIsConnected");

// Size: 0x30 (Inherited: 0x18, Single: 0x18)
struct FRigUnit_ResolveArrayConnector : FRigUnit_RigModulesBase
{
    FRigElementKey Connector; // 0x8 (Size: 0x8, Type: StructProperty)
    bool SkipSocket; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    TArray<FRigElementKey> Result; // 0x18 (Size: 0x10, Type: ArrayProperty)
    bool bIsConnected; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ResolveArrayConnector) == 0x30, "Size mismatch for FRigUnit_ResolveArrayConnector");
static_assert(offsetof(FRigUnit_ResolveArrayConnector, Connector) == 0x8, "Offset mismatch for FRigUnit_ResolveArrayConnector::Connector");
static_assert(offsetof(FRigUnit_ResolveArrayConnector, SkipSocket) == 0x10, "Offset mismatch for FRigUnit_ResolveArrayConnector::SkipSocket");
static_assert(offsetof(FRigUnit_ResolveArrayConnector, Result) == 0x18, "Offset mismatch for FRigUnit_ResolveArrayConnector::Result");
static_assert(offsetof(FRigUnit_ResolveArrayConnector, bIsConnected) == 0x28, "Offset mismatch for FRigUnit_ResolveArrayConnector::bIsConnected");

// Size: 0x18 (Inherited: 0x18, Single: 0x0)
struct FRigUnit_GetCurrentNameSpace : FRigUnit_RigModulesBase
{
    FString Namespace; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FRigUnit_GetCurrentNameSpace) == 0x18, "Size mismatch for FRigUnit_GetCurrentNameSpace");
static_assert(offsetof(FRigUnit_GetCurrentNameSpace, Namespace) == 0x8, "Offset mismatch for FRigUnit_GetCurrentNameSpace::Namespace");

// Size: 0x18 (Inherited: 0x18, Single: 0x0)
struct FRigUnit_GetItemShortName : FRigUnit_RigModulesBase
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    FName ShortName; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_GetItemShortName) == 0x18, "Size mismatch for FRigUnit_GetItemShortName");
static_assert(offsetof(FRigUnit_GetItemShortName, Item) == 0x8, "Offset mismatch for FRigUnit_GetItemShortName::Item");
static_assert(offsetof(FRigUnit_GetItemShortName, ShortName) == 0x10, "Offset mismatch for FRigUnit_GetItemShortName::ShortName");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigUnit_GetItemNameSpace : FRigUnit_RigModulesBase
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    bool HasNameSpace; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FString Namespace; // 0x18 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FRigUnit_GetItemNameSpace) == 0x28, "Size mismatch for FRigUnit_GetItemNameSpace");
static_assert(offsetof(FRigUnit_GetItemNameSpace, Item) == 0x8, "Offset mismatch for FRigUnit_GetItemNameSpace::Item");
static_assert(offsetof(FRigUnit_GetItemNameSpace, HasNameSpace) == 0x10, "Offset mismatch for FRigUnit_GetItemNameSpace::HasNameSpace");
static_assert(offsetof(FRigUnit_GetItemNameSpace, Namespace) == 0x18, "Offset mismatch for FRigUnit_GetItemNameSpace::Namespace");

// Size: 0x18 (Inherited: 0x18, Single: 0x0)
struct FRigUnit_IsItemInCurrentNameSpace : FRigUnit_RigModulesBase
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    bool Result; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_IsItemInCurrentNameSpace) == 0x18, "Size mismatch for FRigUnit_IsItemInCurrentNameSpace");
static_assert(offsetof(FRigUnit_IsItemInCurrentNameSpace, Item) == 0x8, "Offset mismatch for FRigUnit_IsItemInCurrentNameSpace::Item");
static_assert(offsetof(FRigUnit_IsItemInCurrentNameSpace, Result) == 0x10, "Offset mismatch for FRigUnit_IsItemInCurrentNameSpace::Result");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigUnit_GetItemsInNameSpace : FRigUnit_RigModulesBase
{
    uint8_t TypeToSearch; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_GetItemsInNameSpace) == 0x20, "Size mismatch for FRigUnit_GetItemsInNameSpace");
static_assert(offsetof(FRigUnit_GetItemsInNameSpace, TypeToSearch) == 0x8, "Offset mismatch for FRigUnit_GetItemsInNameSpace::TypeToSearch");
static_assert(offsetof(FRigUnit_GetItemsInNameSpace, Items) == 0x10, "Offset mismatch for FRigUnit_GetItemsInNameSpace::Items");

// Size: 0x18 (Inherited: 0x18, Single: 0x0)
struct FRigUnit_GetModuleName : FRigUnit_RigModulesBase
{
    FString Module; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FRigUnit_GetModuleName) == 0x18, "Size mismatch for FRigUnit_GetModuleName");
static_assert(offsetof(FRigUnit_GetModuleName, Module) == 0x8, "Offset mismatch for FRigUnit_GetModuleName::Module");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FRigUnit_GetItemModuleName : FRigUnit_RigModulesBase
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    bool IsPartOfModule; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FString Module; // 0x18 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FRigUnit_GetItemModuleName) == 0x28, "Size mismatch for FRigUnit_GetItemModuleName");
static_assert(offsetof(FRigUnit_GetItemModuleName, Item) == 0x8, "Offset mismatch for FRigUnit_GetItemModuleName::Item");
static_assert(offsetof(FRigUnit_GetItemModuleName, IsPartOfModule) == 0x10, "Offset mismatch for FRigUnit_GetItemModuleName::IsPartOfModule");
static_assert(offsetof(FRigUnit_GetItemModuleName, Module) == 0x18, "Offset mismatch for FRigUnit_GetItemModuleName::Module");

// Size: 0x18 (Inherited: 0x18, Single: 0x0)
struct FRigUnit_IsItemInCurrentModule : FRigUnit_RigModulesBase
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    bool Result; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_IsItemInCurrentModule) == 0x18, "Size mismatch for FRigUnit_IsItemInCurrentModule");
static_assert(offsetof(FRigUnit_IsItemInCurrentModule, Item) == 0x8, "Offset mismatch for FRigUnit_IsItemInCurrentModule::Item");
static_assert(offsetof(FRigUnit_IsItemInCurrentModule, Result) == 0x10, "Offset mismatch for FRigUnit_IsItemInCurrentModule::Result");

// Size: 0x20 (Inherited: 0x18, Single: 0x8)
struct FRigUnit_GetItemsInModule : FRigUnit_RigModulesBase
{
    uint8_t TypeToSearch; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_GetItemsInModule) == 0x20, "Size mismatch for FRigUnit_GetItemsInModule");
static_assert(offsetof(FRigUnit_GetItemsInModule, TypeToSearch) == 0x8, "Offset mismatch for FRigUnit_GetItemsInModule::TypeToSearch");
static_assert(offsetof(FRigUnit_GetItemsInModule, Items) == 0x10, "Offset mismatch for FRigUnit_GetItemsInModule::Items");

// Size: 0x9c0 (Inherited: 0x10, Single: 0x9b0)
struct FRigUnit_SequenceExecution : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FControlRigExecuteContext ExecuteContext; // 0x10 (Size: 0x1f0, Type: StructProperty)
    FControlRigExecuteContext A; // 0x200 (Size: 0x1f0, Type: StructProperty)
    FControlRigExecuteContext B; // 0x3f0 (Size: 0x1f0, Type: StructProperty)
    FControlRigExecuteContext C; // 0x5e0 (Size: 0x1f0, Type: StructProperty)
    FControlRigExecuteContext D; // 0x7d0 (Size: 0x1f0, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SequenceExecution) == 0x9c0, "Size mismatch for FRigUnit_SequenceExecution");
static_assert(offsetof(FRigUnit_SequenceExecution, ExecuteContext) == 0x10, "Offset mismatch for FRigUnit_SequenceExecution::ExecuteContext");
static_assert(offsetof(FRigUnit_SequenceExecution, A) == 0x200, "Offset mismatch for FRigUnit_SequenceExecution::A");
static_assert(offsetof(FRigUnit_SequenceExecution, B) == 0x3f0, "Offset mismatch for FRigUnit_SequenceExecution::B");
static_assert(offsetof(FRigUnit_SequenceExecution, C) == 0x5e0, "Offset mismatch for FRigUnit_SequenceExecution::C");
static_assert(offsetof(FRigUnit_SequenceExecution, D) == 0x7d0, "Offset mismatch for FRigUnit_SequenceExecution::D");

// Size: 0xa0 (Inherited: 0x20, Single: 0x80)
struct FRigUnit_AddBoneTransform : FRigUnitMutable
{
    FName bone; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    float Weight; // 0x80 (Size: 0x4, Type: FloatProperty)
    bool bPostMultiply; // 0x84 (Size: 0x1, Type: BoolProperty)
    bool bPropagateToChildren; // 0x85 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_86[0x2]; // 0x86 (Size: 0x2, Type: PaddingProperty)
    FCachedRigElement CachedBone; // 0x88 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_AddBoneTransform) == 0xa0, "Size mismatch for FRigUnit_AddBoneTransform");
static_assert(offsetof(FRigUnit_AddBoneTransform, bone) == 0x10, "Offset mismatch for FRigUnit_AddBoneTransform::bone");
static_assert(offsetof(FRigUnit_AddBoneTransform, Transform) == 0x20, "Offset mismatch for FRigUnit_AddBoneTransform::Transform");
static_assert(offsetof(FRigUnit_AddBoneTransform, Weight) == 0x80, "Offset mismatch for FRigUnit_AddBoneTransform::Weight");
static_assert(offsetof(FRigUnit_AddBoneTransform, bPostMultiply) == 0x84, "Offset mismatch for FRigUnit_AddBoneTransform::bPostMultiply");
static_assert(offsetof(FRigUnit_AddBoneTransform, bPropagateToChildren) == 0x85, "Offset mismatch for FRigUnit_AddBoneTransform::bPropagateToChildren");
static_assert(offsetof(FRigUnit_AddBoneTransform, CachedBone) == 0x88, "Offset mismatch for FRigUnit_AddBoneTransform::CachedBone");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_Item : FRigUnit
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_Item) == 0x10, "Size mismatch for FRigUnit_Item");
static_assert(offsetof(FRigUnit_Item, Item) == 0x8, "Offset mismatch for FRigUnit_Item::Item");

// Size: 0x18 (Inherited: 0x10, Single: 0x8)
struct FRigUnit_ItemArray : FRigUnit
{
    TArray<FRigElementKey> Items; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_ItemArray) == 0x18, "Size mismatch for FRigUnit_ItemArray");
static_assert(offsetof(FRigUnit_ItemArray, Items) == 0x8, "Offset mismatch for FRigUnit_ItemArray::Items");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_BoneName : FRigUnit
{
    FName bone; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_BoneName) == 0x10, "Size mismatch for FRigUnit_BoneName");
static_assert(offsetof(FRigUnit_BoneName, bone) == 0x8, "Offset mismatch for FRigUnit_BoneName::bone");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_SpaceName : FRigUnit
{
    FName Space; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SpaceName) == 0x10, "Size mismatch for FRigUnit_SpaceName");
static_assert(offsetof(FRigUnit_SpaceName, Space) == 0x8, "Offset mismatch for FRigUnit_SpaceName::Space");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_ControlName : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ControlName) == 0x10, "Size mismatch for FRigUnit_ControlName");
static_assert(offsetof(FRigUnit_ControlName, Control) == 0x8, "Offset mismatch for FRigUnit_ControlName::Control");

// Size: 0xa8 (Inherited: 0xe0, Single: 0xffffffc8)
struct FRigDispatch_ComponentBase : FRigDispatchFactory
{
};

static_assert(sizeof(FRigDispatch_ComponentBase) == 0xa8, "Size mismatch for FRigDispatch_ComponentBase");

// Size: 0xa8 (Inherited: 0x188, Single: 0xffffff20)
struct FRigDispatch_SpawnComponent : FRigDispatch_ComponentBase
{
};

static_assert(sizeof(FRigDispatch_SpawnComponent) == 0xa8, "Size mismatch for FRigDispatch_SpawnComponent");

// Size: 0xa8 (Inherited: 0x188, Single: 0xffffff20)
struct FRigDispatch_SpawnTopLevelComponent : FRigDispatch_ComponentBase
{
};

static_assert(sizeof(FRigDispatch_SpawnTopLevelComponent) == 0xa8, "Size mismatch for FRigDispatch_SpawnTopLevelComponent");

// Size: 0xa8 (Inherited: 0x188, Single: 0xffffff20)
struct FRigDispatch_GetComponentContent : FRigDispatch_ComponentBase
{
};

static_assert(sizeof(FRigDispatch_GetComponentContent) == 0xa8, "Size mismatch for FRigDispatch_GetComponentContent");

// Size: 0xa8 (Inherited: 0x188, Single: 0xffffff20)
struct FRigDispatch_SetComponentContent : FRigDispatch_ComponentBase
{
};

static_assert(sizeof(FRigDispatch_SetComponentContent) == 0xa8, "Size mismatch for FRigDispatch_SetComponentContent");

// Size: 0xa8 (Inherited: 0x188, Single: 0xffffff20)
struct FRigDispatch_GetTopLevelComponentContent : FRigDispatch_ComponentBase
{
};

static_assert(sizeof(FRigDispatch_GetTopLevelComponentContent) == 0xa8, "Size mismatch for FRigDispatch_GetTopLevelComponentContent");

// Size: 0xa8 (Inherited: 0x188, Single: 0xffffff20)
struct FRigDispatch_SetTopLevelComponentContent : FRigDispatch_ComponentBase
{
};

static_assert(sizeof(FRigDispatch_SetTopLevelComponentContent) == 0xa8, "Size mismatch for FRigDispatch_SetTopLevelComponentContent");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FRigUnit_GetAnimationChannelBase : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    FName Channel; // 0xc (Size: 0x4, Type: NameProperty)
    bool bInitial; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    FRigElementKey CachedChannelKey; // 0x14 (Size: 0x8, Type: StructProperty)
    int32_t CachedChannelHash; // 0x1c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FRigUnit_GetAnimationChannelBase) == 0x20, "Size mismatch for FRigUnit_GetAnimationChannelBase");
static_assert(offsetof(FRigUnit_GetAnimationChannelBase, Control) == 0x8, "Offset mismatch for FRigUnit_GetAnimationChannelBase::Control");
static_assert(offsetof(FRigUnit_GetAnimationChannelBase, Channel) == 0xc, "Offset mismatch for FRigUnit_GetAnimationChannelBase::Channel");
static_assert(offsetof(FRigUnit_GetAnimationChannelBase, bInitial) == 0x10, "Offset mismatch for FRigUnit_GetAnimationChannelBase::bInitial");
static_assert(offsetof(FRigUnit_GetAnimationChannelBase, CachedChannelKey) == 0x14, "Offset mismatch for FRigUnit_GetAnimationChannelBase::CachedChannelKey");
static_assert(offsetof(FRigUnit_GetAnimationChannelBase, CachedChannelHash) == 0x1c, "Offset mismatch for FRigUnit_GetAnimationChannelBase::CachedChannelHash");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_GetBoolAnimationChannel : FRigUnit_GetAnimationChannelBase
{
    bool Value; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_GetBoolAnimationChannel) == 0x28, "Size mismatch for FRigUnit_GetBoolAnimationChannel");
static_assert(offsetof(FRigUnit_GetBoolAnimationChannel, Value) == 0x20, "Offset mismatch for FRigUnit_GetBoolAnimationChannel::Value");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_GetFloatAnimationChannel : FRigUnit_GetAnimationChannelBase
{
    float Value; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_GetFloatAnimationChannel) == 0x28, "Size mismatch for FRigUnit_GetFloatAnimationChannel");
static_assert(offsetof(FRigUnit_GetFloatAnimationChannel, Value) == 0x20, "Offset mismatch for FRigUnit_GetFloatAnimationChannel::Value");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_GetIntAnimationChannel : FRigUnit_GetAnimationChannelBase
{
    int32_t Value; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_GetIntAnimationChannel) == 0x28, "Size mismatch for FRigUnit_GetIntAnimationChannel");
static_assert(offsetof(FRigUnit_GetIntAnimationChannel, Value) == 0x20, "Offset mismatch for FRigUnit_GetIntAnimationChannel::Value");

// Size: 0x30 (Inherited: 0x30, Single: 0x0)
struct FRigUnit_GetVector2DAnimationChannel : FRigUnit_GetAnimationChannelBase
{
    FVector2D Value; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetVector2DAnimationChannel) == 0x30, "Size mismatch for FRigUnit_GetVector2DAnimationChannel");
static_assert(offsetof(FRigUnit_GetVector2DAnimationChannel, Value) == 0x20, "Offset mismatch for FRigUnit_GetVector2DAnimationChannel::Value");

// Size: 0x38 (Inherited: 0x30, Single: 0x8)
struct FRigUnit_GetVectorAnimationChannel : FRigUnit_GetAnimationChannelBase
{
    FVector Value; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetVectorAnimationChannel) == 0x38, "Size mismatch for FRigUnit_GetVectorAnimationChannel");
static_assert(offsetof(FRigUnit_GetVectorAnimationChannel, Value) == 0x20, "Offset mismatch for FRigUnit_GetVectorAnimationChannel::Value");

// Size: 0x38 (Inherited: 0x30, Single: 0x8)
struct FRigUnit_GetRotatorAnimationChannel : FRigUnit_GetAnimationChannelBase
{
    FRotator Value; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetRotatorAnimationChannel) == 0x38, "Size mismatch for FRigUnit_GetRotatorAnimationChannel");
static_assert(offsetof(FRigUnit_GetRotatorAnimationChannel, Value) == 0x20, "Offset mismatch for FRigUnit_GetRotatorAnimationChannel::Value");

// Size: 0x80 (Inherited: 0x30, Single: 0x50)
struct FRigUnit_GetTransformAnimationChannel : FRigUnit_GetAnimationChannelBase
{
    FTransform Value; // 0x20 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetTransformAnimationChannel) == 0x80, "Size mismatch for FRigUnit_GetTransformAnimationChannel");
static_assert(offsetof(FRigUnit_GetTransformAnimationChannel, Value) == 0x20, "Offset mismatch for FRigUnit_GetTransformAnimationChannel::Value");

// Size: 0x28 (Inherited: 0x30, Single: 0xfffffff8)
struct FRigUnit_SetAnimationChannelBase : FRigUnit_GetAnimationChannelBase
{
    FRigVMExecutePin ExecutePin; // 0x20 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetAnimationChannelBase) == 0x28, "Size mismatch for FRigUnit_SetAnimationChannelBase");
static_assert(offsetof(FRigUnit_SetAnimationChannelBase, ExecutePin) == 0x20, "Offset mismatch for FRigUnit_SetAnimationChannelBase::ExecutePin");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
struct FRigUnit_SetBoolAnimationChannel : FRigUnit_SetAnimationChannelBase
{
    bool Value; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetBoolAnimationChannel) == 0x30, "Size mismatch for FRigUnit_SetBoolAnimationChannel");
static_assert(offsetof(FRigUnit_SetBoolAnimationChannel, Value) == 0x28, "Offset mismatch for FRigUnit_SetBoolAnimationChannel::Value");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
struct FRigUnit_SetFloatAnimationChannel : FRigUnit_SetAnimationChannelBase
{
    float Value; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetFloatAnimationChannel) == 0x30, "Size mismatch for FRigUnit_SetFloatAnimationChannel");
static_assert(offsetof(FRigUnit_SetFloatAnimationChannel, Value) == 0x28, "Offset mismatch for FRigUnit_SetFloatAnimationChannel::Value");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
struct FRigUnit_SetIntAnimationChannel : FRigUnit_SetAnimationChannelBase
{
    int32_t Value; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetIntAnimationChannel) == 0x30, "Size mismatch for FRigUnit_SetIntAnimationChannel");
static_assert(offsetof(FRigUnit_SetIntAnimationChannel, Value) == 0x28, "Offset mismatch for FRigUnit_SetIntAnimationChannel::Value");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
struct FRigUnit_SetVector2DAnimationChannel : FRigUnit_SetAnimationChannelBase
{
    FVector2D Value; // 0x28 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetVector2DAnimationChannel) == 0x38, "Size mismatch for FRigUnit_SetVector2DAnimationChannel");
static_assert(offsetof(FRigUnit_SetVector2DAnimationChannel, Value) == 0x28, "Offset mismatch for FRigUnit_SetVector2DAnimationChannel::Value");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
struct FRigUnit_SetVectorAnimationChannel : FRigUnit_SetAnimationChannelBase
{
    FVector Value; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetVectorAnimationChannel) == 0x40, "Size mismatch for FRigUnit_SetVectorAnimationChannel");
static_assert(offsetof(FRigUnit_SetVectorAnimationChannel, Value) == 0x28, "Offset mismatch for FRigUnit_SetVectorAnimationChannel::Value");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
struct FRigUnit_SetRotatorAnimationChannel : FRigUnit_SetAnimationChannelBase
{
    FRotator Value; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetRotatorAnimationChannel) == 0x40, "Size mismatch for FRigUnit_SetRotatorAnimationChannel");
static_assert(offsetof(FRigUnit_SetRotatorAnimationChannel, Value) == 0x28, "Offset mismatch for FRigUnit_SetRotatorAnimationChannel::Value");

// Size: 0x90 (Inherited: 0x58, Single: 0x38)
struct FRigUnit_SetTransformAnimationChannel : FRigUnit_SetAnimationChannelBase
{
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FTransform Value; // 0x30 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetTransformAnimationChannel) == 0x90, "Size mismatch for FRigUnit_SetTransformAnimationChannel");
static_assert(offsetof(FRigUnit_SetTransformAnimationChannel, Value) == 0x30, "Offset mismatch for FRigUnit_SetTransformAnimationChannel::Value");

// Size: 0x18 (Inherited: 0x10, Single: 0x8)
struct FRigUnit_GetAnimationChannelFromItemBase : FRigUnit
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bInitial; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_GetAnimationChannelFromItemBase) == 0x18, "Size mismatch for FRigUnit_GetAnimationChannelFromItemBase");
static_assert(offsetof(FRigUnit_GetAnimationChannelFromItemBase, Item) == 0x8, "Offset mismatch for FRigUnit_GetAnimationChannelFromItemBase::Item");
static_assert(offsetof(FRigUnit_GetAnimationChannelFromItemBase, bInitial) == 0x10, "Offset mismatch for FRigUnit_GetAnimationChannelFromItemBase::bInitial");

// Size: 0x20 (Inherited: 0x28, Single: 0xfffffff8)
struct FRigUnit_GetBoolAnimationChannelFromItem : FRigUnit_GetAnimationChannelFromItemBase
{
    bool Value; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_GetBoolAnimationChannelFromItem) == 0x20, "Size mismatch for FRigUnit_GetBoolAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_GetBoolAnimationChannelFromItem, Value) == 0x18, "Offset mismatch for FRigUnit_GetBoolAnimationChannelFromItem::Value");

// Size: 0x20 (Inherited: 0x28, Single: 0xfffffff8)
struct FRigUnit_GetFloatAnimationChannelFromItem : FRigUnit_GetAnimationChannelFromItemBase
{
    float Value; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_GetFloatAnimationChannelFromItem) == 0x20, "Size mismatch for FRigUnit_GetFloatAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_GetFloatAnimationChannelFromItem, Value) == 0x18, "Offset mismatch for FRigUnit_GetFloatAnimationChannelFromItem::Value");

// Size: 0x20 (Inherited: 0x28, Single: 0xfffffff8)
struct FRigUnit_GetIntAnimationChannelFromItem : FRigUnit_GetAnimationChannelFromItemBase
{
    int32_t Value; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_GetIntAnimationChannelFromItem) == 0x20, "Size mismatch for FRigUnit_GetIntAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_GetIntAnimationChannelFromItem, Value) == 0x18, "Offset mismatch for FRigUnit_GetIntAnimationChannelFromItem::Value");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
struct FRigUnit_GetVector2DAnimationChannelFromItem : FRigUnit_GetAnimationChannelFromItemBase
{
    FVector2D Value; // 0x18 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetVector2DAnimationChannelFromItem) == 0x28, "Size mismatch for FRigUnit_GetVector2DAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_GetVector2DAnimationChannelFromItem, Value) == 0x18, "Offset mismatch for FRigUnit_GetVector2DAnimationChannelFromItem::Value");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
struct FRigUnit_GetVectorAnimationChannelFromItem : FRigUnit_GetAnimationChannelFromItemBase
{
    FVector Value; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetVectorAnimationChannelFromItem) == 0x30, "Size mismatch for FRigUnit_GetVectorAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_GetVectorAnimationChannelFromItem, Value) == 0x18, "Offset mismatch for FRigUnit_GetVectorAnimationChannelFromItem::Value");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
struct FRigUnit_GetRotatorAnimationChannelFromItem : FRigUnit_GetAnimationChannelFromItemBase
{
    FRotator Value; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetRotatorAnimationChannelFromItem) == 0x30, "Size mismatch for FRigUnit_GetRotatorAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_GetRotatorAnimationChannelFromItem, Value) == 0x18, "Offset mismatch for FRigUnit_GetRotatorAnimationChannelFromItem::Value");

// Size: 0x80 (Inherited: 0x28, Single: 0x58)
struct FRigUnit_GetTransformAnimationChannelFromItem : FRigUnit_GetAnimationChannelFromItemBase
{
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform Value; // 0x20 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetTransformAnimationChannelFromItem) == 0x80, "Size mismatch for FRigUnit_GetTransformAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_GetTransformAnimationChannelFromItem, Value) == 0x20, "Offset mismatch for FRigUnit_GetTransformAnimationChannelFromItem::Value");

// Size: 0x20 (Inherited: 0x28, Single: 0xfffffff8)
struct FRigUnit_SetAnimationChannelBaseFromItem : FRigUnit_GetAnimationChannelFromItemBase
{
    FRigVMExecutePin ExecutePin; // 0x18 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetAnimationChannelBaseFromItem) == 0x20, "Size mismatch for FRigUnit_SetAnimationChannelBaseFromItem");
static_assert(offsetof(FRigUnit_SetAnimationChannelBaseFromItem, ExecutePin) == 0x18, "Offset mismatch for FRigUnit_SetAnimationChannelBaseFromItem::ExecutePin");

// Size: 0x28 (Inherited: 0x48, Single: 0xffffffe0)
struct FRigUnit_SetBoolAnimationChannelFromItem : FRigUnit_SetAnimationChannelBaseFromItem
{
    bool Value; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetBoolAnimationChannelFromItem) == 0x28, "Size mismatch for FRigUnit_SetBoolAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_SetBoolAnimationChannelFromItem, Value) == 0x20, "Offset mismatch for FRigUnit_SetBoolAnimationChannelFromItem::Value");

// Size: 0x28 (Inherited: 0x48, Single: 0xffffffe0)
struct FRigUnit_SetFloatAnimationChannelFromItem : FRigUnit_SetAnimationChannelBaseFromItem
{
    float Value; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetFloatAnimationChannelFromItem) == 0x28, "Size mismatch for FRigUnit_SetFloatAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_SetFloatAnimationChannelFromItem, Value) == 0x20, "Offset mismatch for FRigUnit_SetFloatAnimationChannelFromItem::Value");

// Size: 0x28 (Inherited: 0x48, Single: 0xffffffe0)
struct FRigUnit_SetIntAnimationChannelFromItem : FRigUnit_SetAnimationChannelBaseFromItem
{
    int32_t Value; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetIntAnimationChannelFromItem) == 0x28, "Size mismatch for FRigUnit_SetIntAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_SetIntAnimationChannelFromItem, Value) == 0x20, "Offset mismatch for FRigUnit_SetIntAnimationChannelFromItem::Value");

// Size: 0x30 (Inherited: 0x48, Single: 0xffffffe8)
struct FRigUnit_SetVector2DAnimationChannelFromItem : FRigUnit_SetAnimationChannelBaseFromItem
{
    FVector2D Value; // 0x20 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetVector2DAnimationChannelFromItem) == 0x30, "Size mismatch for FRigUnit_SetVector2DAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_SetVector2DAnimationChannelFromItem, Value) == 0x20, "Offset mismatch for FRigUnit_SetVector2DAnimationChannelFromItem::Value");

// Size: 0x38 (Inherited: 0x48, Single: 0xfffffff0)
struct FRigUnit_SetVectorAnimationChannelFromItem : FRigUnit_SetAnimationChannelBaseFromItem
{
    FVector Value; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetVectorAnimationChannelFromItem) == 0x38, "Size mismatch for FRigUnit_SetVectorAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_SetVectorAnimationChannelFromItem, Value) == 0x20, "Offset mismatch for FRigUnit_SetVectorAnimationChannelFromItem::Value");

// Size: 0x38 (Inherited: 0x48, Single: 0xfffffff0)
struct FRigUnit_SetRotatorAnimationChannelFromItem : FRigUnit_SetAnimationChannelBaseFromItem
{
    FRotator Value; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetRotatorAnimationChannelFromItem) == 0x38, "Size mismatch for FRigUnit_SetRotatorAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_SetRotatorAnimationChannelFromItem, Value) == 0x20, "Offset mismatch for FRigUnit_SetRotatorAnimationChannelFromItem::Value");

// Size: 0x80 (Inherited: 0x48, Single: 0x38)
struct FRigUnit_SetTransformAnimationChannelFromItem : FRigUnit_SetAnimationChannelBaseFromItem
{
    FTransform Value; // 0x20 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetTransformAnimationChannelFromItem) == 0x80, "Size mismatch for FRigUnit_SetTransformAnimationChannelFromItem");
static_assert(offsetof(FRigUnit_SetTransformAnimationChannelFromItem, Value) == 0x20, "Offset mismatch for FRigUnit_SetTransformAnimationChannelFromItem::Value");

// Size: 0x28 (Inherited: 0x10, Single: 0x18)
struct FRigUnit_CurveExists : FRigUnit
{
    FName Curve; // 0x8 (Size: 0x4, Type: NameProperty)
    bool Exists; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedCurveIndex; // 0x10 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CurveExists) == 0x28, "Size mismatch for FRigUnit_CurveExists");
static_assert(offsetof(FRigUnit_CurveExists, Curve) == 0x8, "Offset mismatch for FRigUnit_CurveExists::Curve");
static_assert(offsetof(FRigUnit_CurveExists, Exists) == 0xc, "Offset mismatch for FRigUnit_CurveExists::Exists");
static_assert(offsetof(FRigUnit_CurveExists, CachedCurveIndex) == 0x10, "Offset mismatch for FRigUnit_CurveExists::CachedCurveIndex");

// Size: 0x50 (Inherited: 0x20, Single: 0x30)
struct FRigUnit_FindClosestItem : FRigUnitMutable
{
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FVector Point; // 0x20 (Size: 0x18, Type: StructProperty)
    FRigElementKey Item; // 0x38 (Size: 0x8, Type: StructProperty)
    TArray<FCachedRigElement> CachedItems; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_FindClosestItem) == 0x50, "Size mismatch for FRigUnit_FindClosestItem");
static_assert(offsetof(FRigUnit_FindClosestItem, Items) == 0x10, "Offset mismatch for FRigUnit_FindClosestItem::Items");
static_assert(offsetof(FRigUnit_FindClosestItem, Point) == 0x20, "Offset mismatch for FRigUnit_FindClosestItem::Point");
static_assert(offsetof(FRigUnit_FindClosestItem, Item) == 0x38, "Offset mismatch for FRigUnit_FindClosestItem::Item");
static_assert(offsetof(FRigUnit_FindClosestItem, CachedItems) == 0x40, "Offset mismatch for FRigUnit_FindClosestItem::CachedItems");

// Size: 0x90 (Inherited: 0x10, Single: 0x80)
struct FRigUnit_GetBoneTransform : FRigUnit
{
    FName bone; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedBone; // 0x70 (Size: 0x18, Type: StructProperty)
    bool bFirstUpdate; // 0x88 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0x7]; // 0x89 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_GetBoneTransform) == 0x90, "Size mismatch for FRigUnit_GetBoneTransform");
static_assert(offsetof(FRigUnit_GetBoneTransform, bone) == 0x8, "Offset mismatch for FRigUnit_GetBoneTransform::bone");
static_assert(offsetof(FRigUnit_GetBoneTransform, Space) == 0xc, "Offset mismatch for FRigUnit_GetBoneTransform::Space");
static_assert(offsetof(FRigUnit_GetBoneTransform, Transform) == 0x10, "Offset mismatch for FRigUnit_GetBoneTransform::Transform");
static_assert(offsetof(FRigUnit_GetBoneTransform, CachedBone) == 0x70, "Offset mismatch for FRigUnit_GetBoneTransform::CachedBone");
static_assert(offsetof(FRigUnit_GetBoneTransform, bFirstUpdate) == 0x88, "Offset mismatch for FRigUnit_GetBoneTransform::bFirstUpdate");

// Size: 0x90 (Inherited: 0x10, Single: 0x80)
struct FRigUnit_GetControlInitialTransform : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedControlIndex; // 0x70 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetControlInitialTransform) == 0x90, "Size mismatch for FRigUnit_GetControlInitialTransform");
static_assert(offsetof(FRigUnit_GetControlInitialTransform, Control) == 0x8, "Offset mismatch for FRigUnit_GetControlInitialTransform::Control");
static_assert(offsetof(FRigUnit_GetControlInitialTransform, Space) == 0xc, "Offset mismatch for FRigUnit_GetControlInitialTransform::Space");
static_assert(offsetof(FRigUnit_GetControlInitialTransform, Transform) == 0x10, "Offset mismatch for FRigUnit_GetControlInitialTransform::Transform");
static_assert(offsetof(FRigUnit_GetControlInitialTransform, CachedControlIndex) == 0x70, "Offset mismatch for FRigUnit_GetControlInitialTransform::CachedControlIndex");

// Size: 0x90 (Inherited: 0x10, Single: 0x80)
struct FRigUnit_GetControlOffset : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FTransform OffsetTransform; // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedIndex; // 0x70 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetControlOffset) == 0x90, "Size mismatch for FRigUnit_GetControlOffset");
static_assert(offsetof(FRigUnit_GetControlOffset, Control) == 0x8, "Offset mismatch for FRigUnit_GetControlOffset::Control");
static_assert(offsetof(FRigUnit_GetControlOffset, Space) == 0xc, "Offset mismatch for FRigUnit_GetControlOffset::Space");
static_assert(offsetof(FRigUnit_GetControlOffset, OffsetTransform) == 0x10, "Offset mismatch for FRigUnit_GetControlOffset::OffsetTransform");
static_assert(offsetof(FRigUnit_GetControlOffset, CachedIndex) == 0x70, "Offset mismatch for FRigUnit_GetControlOffset::CachedIndex");

// Size: 0x28 (Inherited: 0x10, Single: 0x18)
struct FRigUnit_GetControlBool : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    bool BoolValue; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x10 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetControlBool) == 0x28, "Size mismatch for FRigUnit_GetControlBool");
static_assert(offsetof(FRigUnit_GetControlBool, Control) == 0x8, "Offset mismatch for FRigUnit_GetControlBool::Control");
static_assert(offsetof(FRigUnit_GetControlBool, BoolValue) == 0xc, "Offset mismatch for FRigUnit_GetControlBool::BoolValue");
static_assert(offsetof(FRigUnit_GetControlBool, CachedControlIndex) == 0x10, "Offset mismatch for FRigUnit_GetControlBool::CachedControlIndex");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FRigUnit_GetControlFloat : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    float FloatValue; // 0xc (Size: 0x4, Type: FloatProperty)
    float Minimum; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Maximum; // 0x14 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement CachedControlIndex; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetControlFloat) == 0x30, "Size mismatch for FRigUnit_GetControlFloat");
static_assert(offsetof(FRigUnit_GetControlFloat, Control) == 0x8, "Offset mismatch for FRigUnit_GetControlFloat::Control");
static_assert(offsetof(FRigUnit_GetControlFloat, FloatValue) == 0xc, "Offset mismatch for FRigUnit_GetControlFloat::FloatValue");
static_assert(offsetof(FRigUnit_GetControlFloat, Minimum) == 0x10, "Offset mismatch for FRigUnit_GetControlFloat::Minimum");
static_assert(offsetof(FRigUnit_GetControlFloat, Maximum) == 0x14, "Offset mismatch for FRigUnit_GetControlFloat::Maximum");
static_assert(offsetof(FRigUnit_GetControlFloat, CachedControlIndex) == 0x18, "Offset mismatch for FRigUnit_GetControlFloat::CachedControlIndex");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FRigUnit_GetControlInteger : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    int32_t IntegerValue; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t Minimum; // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t Maximum; // 0x14 (Size: 0x4, Type: IntProperty)
    FCachedRigElement CachedControlIndex; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetControlInteger) == 0x30, "Size mismatch for FRigUnit_GetControlInteger");
static_assert(offsetof(FRigUnit_GetControlInteger, Control) == 0x8, "Offset mismatch for FRigUnit_GetControlInteger::Control");
static_assert(offsetof(FRigUnit_GetControlInteger, IntegerValue) == 0xc, "Offset mismatch for FRigUnit_GetControlInteger::IntegerValue");
static_assert(offsetof(FRigUnit_GetControlInteger, Minimum) == 0x10, "Offset mismatch for FRigUnit_GetControlInteger::Minimum");
static_assert(offsetof(FRigUnit_GetControlInteger, Maximum) == 0x14, "Offset mismatch for FRigUnit_GetControlInteger::Maximum");
static_assert(offsetof(FRigUnit_GetControlInteger, CachedControlIndex) == 0x18, "Offset mismatch for FRigUnit_GetControlInteger::CachedControlIndex");

// Size: 0x58 (Inherited: 0x10, Single: 0x48)
struct FRigUnit_GetControlVector2D : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FVector2D Vector; // 0x10 (Size: 0x10, Type: StructProperty)
    FVector2D Minimum; // 0x20 (Size: 0x10, Type: StructProperty)
    FVector2D Maximum; // 0x30 (Size: 0x10, Type: StructProperty)
    FCachedRigElement CachedControlIndex; // 0x40 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetControlVector2D) == 0x58, "Size mismatch for FRigUnit_GetControlVector2D");
static_assert(offsetof(FRigUnit_GetControlVector2D, Control) == 0x8, "Offset mismatch for FRigUnit_GetControlVector2D::Control");
static_assert(offsetof(FRigUnit_GetControlVector2D, Vector) == 0x10, "Offset mismatch for FRigUnit_GetControlVector2D::Vector");
static_assert(offsetof(FRigUnit_GetControlVector2D, Minimum) == 0x20, "Offset mismatch for FRigUnit_GetControlVector2D::Minimum");
static_assert(offsetof(FRigUnit_GetControlVector2D, Maximum) == 0x30, "Offset mismatch for FRigUnit_GetControlVector2D::Maximum");
static_assert(offsetof(FRigUnit_GetControlVector2D, CachedControlIndex) == 0x40, "Offset mismatch for FRigUnit_GetControlVector2D::CachedControlIndex");

// Size: 0x70 (Inherited: 0x10, Single: 0x60)
struct FRigUnit_GetControlVector : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FVector Vector; // 0x10 (Size: 0x18, Type: StructProperty)
    FVector Minimum; // 0x28 (Size: 0x18, Type: StructProperty)
    FVector Maximum; // 0x40 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedControlIndex; // 0x58 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetControlVector) == 0x70, "Size mismatch for FRigUnit_GetControlVector");
static_assert(offsetof(FRigUnit_GetControlVector, Control) == 0x8, "Offset mismatch for FRigUnit_GetControlVector::Control");
static_assert(offsetof(FRigUnit_GetControlVector, Space) == 0xc, "Offset mismatch for FRigUnit_GetControlVector::Space");
static_assert(offsetof(FRigUnit_GetControlVector, Vector) == 0x10, "Offset mismatch for FRigUnit_GetControlVector::Vector");
static_assert(offsetof(FRigUnit_GetControlVector, Minimum) == 0x28, "Offset mismatch for FRigUnit_GetControlVector::Minimum");
static_assert(offsetof(FRigUnit_GetControlVector, Maximum) == 0x40, "Offset mismatch for FRigUnit_GetControlVector::Maximum");
static_assert(offsetof(FRigUnit_GetControlVector, CachedControlIndex) == 0x58, "Offset mismatch for FRigUnit_GetControlVector::CachedControlIndex");

// Size: 0x70 (Inherited: 0x10, Single: 0x60)
struct FRigUnit_GetControlRotator : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FRotator Rotator; // 0x10 (Size: 0x18, Type: StructProperty)
    FRotator Minimum; // 0x28 (Size: 0x18, Type: StructProperty)
    FRotator Maximum; // 0x40 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedControlIndex; // 0x58 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetControlRotator) == 0x70, "Size mismatch for FRigUnit_GetControlRotator");
static_assert(offsetof(FRigUnit_GetControlRotator, Control) == 0x8, "Offset mismatch for FRigUnit_GetControlRotator::Control");
static_assert(offsetof(FRigUnit_GetControlRotator, Space) == 0xc, "Offset mismatch for FRigUnit_GetControlRotator::Space");
static_assert(offsetof(FRigUnit_GetControlRotator, Rotator) == 0x10, "Offset mismatch for FRigUnit_GetControlRotator::Rotator");
static_assert(offsetof(FRigUnit_GetControlRotator, Minimum) == 0x28, "Offset mismatch for FRigUnit_GetControlRotator::Minimum");
static_assert(offsetof(FRigUnit_GetControlRotator, Maximum) == 0x40, "Offset mismatch for FRigUnit_GetControlRotator::Maximum");
static_assert(offsetof(FRigUnit_GetControlRotator, CachedControlIndex) == 0x58, "Offset mismatch for FRigUnit_GetControlRotator::CachedControlIndex");

// Size: 0x150 (Inherited: 0x10, Single: 0x140)
struct FRigUnit_GetControlTransform : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform Minimum; // 0x70 (Size: 0x60, Type: StructProperty)
    FTransform Maximum; // 0xd0 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedControlIndex; // 0x130 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetControlTransform) == 0x150, "Size mismatch for FRigUnit_GetControlTransform");
static_assert(offsetof(FRigUnit_GetControlTransform, Control) == 0x8, "Offset mismatch for FRigUnit_GetControlTransform::Control");
static_assert(offsetof(FRigUnit_GetControlTransform, Space) == 0xc, "Offset mismatch for FRigUnit_GetControlTransform::Space");
static_assert(offsetof(FRigUnit_GetControlTransform, Transform) == 0x10, "Offset mismatch for FRigUnit_GetControlTransform::Transform");
static_assert(offsetof(FRigUnit_GetControlTransform, Minimum) == 0x70, "Offset mismatch for FRigUnit_GetControlTransform::Minimum");
static_assert(offsetof(FRigUnit_GetControlTransform, Maximum) == 0xd0, "Offset mismatch for FRigUnit_GetControlTransform::Maximum");
static_assert(offsetof(FRigUnit_GetControlTransform, CachedControlIndex) == 0x130, "Offset mismatch for FRigUnit_GetControlTransform::CachedControlIndex");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FRigUnit_GetCurveValue : FRigUnit
{
    FName Curve; // 0x8 (Size: 0x4, Type: NameProperty)
    bool Valid; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    float Value; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FCachedRigElement CachedCurveIndex; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetCurveValue) == 0x30, "Size mismatch for FRigUnit_GetCurveValue");
static_assert(offsetof(FRigUnit_GetCurveValue, Curve) == 0x8, "Offset mismatch for FRigUnit_GetCurveValue::Curve");
static_assert(offsetof(FRigUnit_GetCurveValue, Valid) == 0xc, "Offset mismatch for FRigUnit_GetCurveValue::Valid");
static_assert(offsetof(FRigUnit_GetCurveValue, Value) == 0x10, "Offset mismatch for FRigUnit_GetCurveValue::Value");
static_assert(offsetof(FRigUnit_GetCurveValue, CachedCurveIndex) == 0x18, "Offset mismatch for FRigUnit_GetCurveValue::CachedCurveIndex");

// Size: 0x90 (Inherited: 0x10, Single: 0x80)
struct FRigUnit_GetInitialBoneTransform : FRigUnit
{
    FName bone; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedBone; // 0x70 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetInitialBoneTransform) == 0x90, "Size mismatch for FRigUnit_GetInitialBoneTransform");
static_assert(offsetof(FRigUnit_GetInitialBoneTransform, bone) == 0x8, "Offset mismatch for FRigUnit_GetInitialBoneTransform::bone");
static_assert(offsetof(FRigUnit_GetInitialBoneTransform, Space) == 0xc, "Offset mismatch for FRigUnit_GetInitialBoneTransform::Space");
static_assert(offsetof(FRigUnit_GetInitialBoneTransform, Transform) == 0x10, "Offset mismatch for FRigUnit_GetInitialBoneTransform::Transform");
static_assert(offsetof(FRigUnit_GetInitialBoneTransform, CachedBone) == 0x70, "Offset mismatch for FRigUnit_GetInitialBoneTransform::CachedBone");

// Size: 0xa0 (Inherited: 0x10, Single: 0x90)
struct FRigUnit_GetRelativeBoneTransform : FRigUnit
{
    FName bone; // 0x8 (Size: 0x4, Type: NameProperty)
    FName Space; // 0xc (Size: 0x4, Type: NameProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedBone; // 0x70 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedSpace; // 0x88 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetRelativeBoneTransform) == 0xa0, "Size mismatch for FRigUnit_GetRelativeBoneTransform");
static_assert(offsetof(FRigUnit_GetRelativeBoneTransform, bone) == 0x8, "Offset mismatch for FRigUnit_GetRelativeBoneTransform::bone");
static_assert(offsetof(FRigUnit_GetRelativeBoneTransform, Space) == 0xc, "Offset mismatch for FRigUnit_GetRelativeBoneTransform::Space");
static_assert(offsetof(FRigUnit_GetRelativeBoneTransform, Transform) == 0x10, "Offset mismatch for FRigUnit_GetRelativeBoneTransform::Transform");
static_assert(offsetof(FRigUnit_GetRelativeBoneTransform, CachedBone) == 0x70, "Offset mismatch for FRigUnit_GetRelativeBoneTransform::CachedBone");
static_assert(offsetof(FRigUnit_GetRelativeBoneTransform, CachedSpace) == 0x88, "Offset mismatch for FRigUnit_GetRelativeBoneTransform::CachedSpace");

// Size: 0xb0 (Inherited: 0x10, Single: 0xa0)
struct FRigUnit_GetRelativeTransformForItem : FRigUnit
{
    FRigElementKey Child; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bChildInitial; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    FRigElementKey Parent; // 0x14 (Size: 0x8, Type: StructProperty)
    bool bParentInitial; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
    FTransform RelativeTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedChild; // 0x80 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent; // 0x98 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetRelativeTransformForItem) == 0xb0, "Size mismatch for FRigUnit_GetRelativeTransformForItem");
static_assert(offsetof(FRigUnit_GetRelativeTransformForItem, Child) == 0x8, "Offset mismatch for FRigUnit_GetRelativeTransformForItem::Child");
static_assert(offsetof(FRigUnit_GetRelativeTransformForItem, bChildInitial) == 0x10, "Offset mismatch for FRigUnit_GetRelativeTransformForItem::bChildInitial");
static_assert(offsetof(FRigUnit_GetRelativeTransformForItem, Parent) == 0x14, "Offset mismatch for FRigUnit_GetRelativeTransformForItem::Parent");
static_assert(offsetof(FRigUnit_GetRelativeTransformForItem, bParentInitial) == 0x1c, "Offset mismatch for FRigUnit_GetRelativeTransformForItem::bParentInitial");
static_assert(offsetof(FRigUnit_GetRelativeTransformForItem, RelativeTransform) == 0x20, "Offset mismatch for FRigUnit_GetRelativeTransformForItem::RelativeTransform");
static_assert(offsetof(FRigUnit_GetRelativeTransformForItem, CachedChild) == 0x80, "Offset mismatch for FRigUnit_GetRelativeTransformForItem::CachedChild");
static_assert(offsetof(FRigUnit_GetRelativeTransformForItem, CachedParent) == 0x98, "Offset mismatch for FRigUnit_GetRelativeTransformForItem::CachedParent");

// Size: 0x90 (Inherited: 0x10, Single: 0x80)
struct FRigUnit_GetSpaceTransform : FRigUnit
{
    FName Space; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t SpaceType; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedSpaceIndex; // 0x70 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetSpaceTransform) == 0x90, "Size mismatch for FRigUnit_GetSpaceTransform");
static_assert(offsetof(FRigUnit_GetSpaceTransform, Space) == 0x8, "Offset mismatch for FRigUnit_GetSpaceTransform::Space");
static_assert(offsetof(FRigUnit_GetSpaceTransform, SpaceType) == 0xc, "Offset mismatch for FRigUnit_GetSpaceTransform::SpaceType");
static_assert(offsetof(FRigUnit_GetSpaceTransform, Transform) == 0x10, "Offset mismatch for FRigUnit_GetSpaceTransform::Transform");
static_assert(offsetof(FRigUnit_GetSpaceTransform, CachedSpaceIndex) == 0x70, "Offset mismatch for FRigUnit_GetSpaceTransform::CachedSpaceIndex");

// Size: 0xa0 (Inherited: 0x10, Single: 0x90)
struct FRigUnit_GetTransform : FRigUnit
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    uint8_t Space; // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bInitial; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0xe]; // 0x12 (Size: 0xe, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedIndex; // 0x80 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetTransform) == 0xa0, "Size mismatch for FRigUnit_GetTransform");
static_assert(offsetof(FRigUnit_GetTransform, Item) == 0x8, "Offset mismatch for FRigUnit_GetTransform::Item");
static_assert(offsetof(FRigUnit_GetTransform, Space) == 0x10, "Offset mismatch for FRigUnit_GetTransform::Space");
static_assert(offsetof(FRigUnit_GetTransform, bInitial) == 0x11, "Offset mismatch for FRigUnit_GetTransform::bInitial");
static_assert(offsetof(FRigUnit_GetTransform, Transform) == 0x20, "Offset mismatch for FRigUnit_GetTransform::Transform");
static_assert(offsetof(FRigUnit_GetTransform, CachedIndex) == 0x80, "Offset mismatch for FRigUnit_GetTransform::CachedIndex");

// Size: 0x40 (Inherited: 0x10, Single: 0x30)
struct FRigUnit_GetTransformArray : FRigUnit
{
    FRigElementKeyCollection Items; // 0x8 (Size: 0x10, Type: StructProperty)
    uint8_t Space; // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bInitial; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x6]; // 0x1a (Size: 0x6, Type: PaddingProperty)
    TArray<FTransform> Transforms; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedIndex; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_GetTransformArray) == 0x40, "Size mismatch for FRigUnit_GetTransformArray");
static_assert(offsetof(FRigUnit_GetTransformArray, Items) == 0x8, "Offset mismatch for FRigUnit_GetTransformArray::Items");
static_assert(offsetof(FRigUnit_GetTransformArray, Space) == 0x18, "Offset mismatch for FRigUnit_GetTransformArray::Space");
static_assert(offsetof(FRigUnit_GetTransformArray, bInitial) == 0x19, "Offset mismatch for FRigUnit_GetTransformArray::bInitial");
static_assert(offsetof(FRigUnit_GetTransformArray, Transforms) == 0x20, "Offset mismatch for FRigUnit_GetTransformArray::Transforms");
static_assert(offsetof(FRigUnit_GetTransformArray, CachedIndex) == 0x30, "Offset mismatch for FRigUnit_GetTransformArray::CachedIndex");

// Size: 0x40 (Inherited: 0x10, Single: 0x30)
struct FRigUnit_GetTransformItemArray : FRigUnit
{
    TArray<FRigElementKey> Items; // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Space; // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bInitial; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x6]; // 0x1a (Size: 0x6, Type: PaddingProperty)
    TArray<FTransform> Transforms; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedIndex; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_GetTransformItemArray) == 0x40, "Size mismatch for FRigUnit_GetTransformItemArray");
static_assert(offsetof(FRigUnit_GetTransformItemArray, Items) == 0x8, "Offset mismatch for FRigUnit_GetTransformItemArray::Items");
static_assert(offsetof(FRigUnit_GetTransformItemArray, Space) == 0x18, "Offset mismatch for FRigUnit_GetTransformItemArray::Space");
static_assert(offsetof(FRigUnit_GetTransformItemArray, bInitial) == 0x19, "Offset mismatch for FRigUnit_GetTransformItemArray::bInitial");
static_assert(offsetof(FRigUnit_GetTransformItemArray, Transforms) == 0x20, "Offset mismatch for FRigUnit_GetTransformItemArray::Transforms");
static_assert(offsetof(FRigUnit_GetTransformItemArray, CachedIndex) == 0x30, "Offset mismatch for FRigUnit_GetTransformItemArray::CachedIndex");

// Size: 0xa0 (Inherited: 0xe0, Single: 0xffffffc0)
struct FRigDispatch_MetadataBase : FRigDispatchFactory
{
};

static_assert(sizeof(FRigDispatch_MetadataBase) == 0xa0, "Size mismatch for FRigDispatch_MetadataBase");

// Size: 0xa0 (Inherited: 0x180, Single: 0xffffff20)
struct FRigDispatch_GetMetadata : FRigDispatch_MetadataBase
{
};

static_assert(sizeof(FRigDispatch_GetMetadata) == 0xa0, "Size mismatch for FRigDispatch_GetMetadata");

// Size: 0xa0 (Inherited: 0x180, Single: 0xffffff20)
struct FRigDispatch_SetMetadata : FRigDispatch_MetadataBase
{
};

static_assert(sizeof(FRigDispatch_SetMetadata) == 0xa0, "Size mismatch for FRigDispatch_SetMetadata");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_RemoveMetadata : FRigUnitMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    FName Name; // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Namespace; // 0x1c (Size: 0x1, Type: EnumProperty)
    bool Removed; // 0x1d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1e[0x2]; // 0x1e (Size: 0x2, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_RemoveMetadata) == 0x38, "Size mismatch for FRigUnit_RemoveMetadata");
static_assert(offsetof(FRigUnit_RemoveMetadata, Item) == 0x10, "Offset mismatch for FRigUnit_RemoveMetadata::Item");
static_assert(offsetof(FRigUnit_RemoveMetadata, Name) == 0x18, "Offset mismatch for FRigUnit_RemoveMetadata::Name");
static_assert(offsetof(FRigUnit_RemoveMetadata, Namespace) == 0x1c, "Offset mismatch for FRigUnit_RemoveMetadata::Namespace");
static_assert(offsetof(FRigUnit_RemoveMetadata, Removed) == 0x1d, "Offset mismatch for FRigUnit_RemoveMetadata::Removed");
static_assert(offsetof(FRigUnit_RemoveMetadata, CachedIndex) == 0x20, "Offset mismatch for FRigUnit_RemoveMetadata::CachedIndex");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_RemoveAllMetadata : FRigUnitMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Namespace; // 0x18 (Size: 0x1, Type: EnumProperty)
    bool Removed; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x6]; // 0x1a (Size: 0x6, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_RemoveAllMetadata) == 0x38, "Size mismatch for FRigUnit_RemoveAllMetadata");
static_assert(offsetof(FRigUnit_RemoveAllMetadata, Item) == 0x10, "Offset mismatch for FRigUnit_RemoveAllMetadata::Item");
static_assert(offsetof(FRigUnit_RemoveAllMetadata, Namespace) == 0x18, "Offset mismatch for FRigUnit_RemoveAllMetadata::Namespace");
static_assert(offsetof(FRigUnit_RemoveAllMetadata, Removed) == 0x19, "Offset mismatch for FRigUnit_RemoveAllMetadata::Removed");
static_assert(offsetof(FRigUnit_RemoveAllMetadata, CachedIndex) == 0x20, "Offset mismatch for FRigUnit_RemoveAllMetadata::CachedIndex");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FRigUnit_HasMetadata : FRigUnit
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    FName Name; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Type; // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t Namespace; // 0x15 (Size: 0x1, Type: EnumProperty)
    bool Found; // 0x16 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_17[0x1]; // 0x17 (Size: 0x1, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HasMetadata) == 0x30, "Size mismatch for FRigUnit_HasMetadata");
static_assert(offsetof(FRigUnit_HasMetadata, Item) == 0x8, "Offset mismatch for FRigUnit_HasMetadata::Item");
static_assert(offsetof(FRigUnit_HasMetadata, Name) == 0x10, "Offset mismatch for FRigUnit_HasMetadata::Name");
static_assert(offsetof(FRigUnit_HasMetadata, Type) == 0x14, "Offset mismatch for FRigUnit_HasMetadata::Type");
static_assert(offsetof(FRigUnit_HasMetadata, Namespace) == 0x15, "Offset mismatch for FRigUnit_HasMetadata::Namespace");
static_assert(offsetof(FRigUnit_HasMetadata, Found) == 0x16, "Offset mismatch for FRigUnit_HasMetadata::Found");
static_assert(offsetof(FRigUnit_HasMetadata, CachedIndex) == 0x18, "Offset mismatch for FRigUnit_HasMetadata::CachedIndex");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FRigUnit_FindItemsWithMetadata : FRigUnit
{
    FName Name; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Type; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Namespace; // 0xd (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_e[0x2]; // 0xe (Size: 0x2, Type: PaddingProperty)
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_FindItemsWithMetadata) == 0x20, "Size mismatch for FRigUnit_FindItemsWithMetadata");
static_assert(offsetof(FRigUnit_FindItemsWithMetadata, Name) == 0x8, "Offset mismatch for FRigUnit_FindItemsWithMetadata::Name");
static_assert(offsetof(FRigUnit_FindItemsWithMetadata, Type) == 0xc, "Offset mismatch for FRigUnit_FindItemsWithMetadata::Type");
static_assert(offsetof(FRigUnit_FindItemsWithMetadata, Namespace) == 0xd, "Offset mismatch for FRigUnit_FindItemsWithMetadata::Namespace");
static_assert(offsetof(FRigUnit_FindItemsWithMetadata, Items) == 0x10, "Offset mismatch for FRigUnit_FindItemsWithMetadata::Items");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FRigUnit_GetMetadataTags : FRigUnit
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FName> Tags; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedIndex; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetMetadataTags) == 0x38, "Size mismatch for FRigUnit_GetMetadataTags");
static_assert(offsetof(FRigUnit_GetMetadataTags, Item) == 0x8, "Offset mismatch for FRigUnit_GetMetadataTags::Item");
static_assert(offsetof(FRigUnit_GetMetadataTags, Tags) == 0x10, "Offset mismatch for FRigUnit_GetMetadataTags::Tags");
static_assert(offsetof(FRigUnit_GetMetadataTags, CachedIndex) == 0x20, "Offset mismatch for FRigUnit_GetMetadataTags::CachedIndex");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_SetMetadataTag : FRigUnitMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    FName Tag; // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Namespace; // 0x1c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetMetadataTag) == 0x38, "Size mismatch for FRigUnit_SetMetadataTag");
static_assert(offsetof(FRigUnit_SetMetadataTag, Item) == 0x10, "Offset mismatch for FRigUnit_SetMetadataTag::Item");
static_assert(offsetof(FRigUnit_SetMetadataTag, Tag) == 0x18, "Offset mismatch for FRigUnit_SetMetadataTag::Tag");
static_assert(offsetof(FRigUnit_SetMetadataTag, Namespace) == 0x1c, "Offset mismatch for FRigUnit_SetMetadataTag::Namespace");
static_assert(offsetof(FRigUnit_SetMetadataTag, CachedIndex) == 0x20, "Offset mismatch for FRigUnit_SetMetadataTag::CachedIndex");

// Size: 0x48 (Inherited: 0x20, Single: 0x28)
struct FRigUnit_SetMetadataTagArray : FRigUnitMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FName> Tags; // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t Namespace; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x30 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetMetadataTagArray) == 0x48, "Size mismatch for FRigUnit_SetMetadataTagArray");
static_assert(offsetof(FRigUnit_SetMetadataTagArray, Item) == 0x10, "Offset mismatch for FRigUnit_SetMetadataTagArray::Item");
static_assert(offsetof(FRigUnit_SetMetadataTagArray, Tags) == 0x18, "Offset mismatch for FRigUnit_SetMetadataTagArray::Tags");
static_assert(offsetof(FRigUnit_SetMetadataTagArray, Namespace) == 0x28, "Offset mismatch for FRigUnit_SetMetadataTagArray::Namespace");
static_assert(offsetof(FRigUnit_SetMetadataTagArray, CachedIndex) == 0x30, "Offset mismatch for FRigUnit_SetMetadataTagArray::CachedIndex");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_RemoveMetadataTag : FRigUnitMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    FName Tag; // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Namespace; // 0x1c (Size: 0x1, Type: EnumProperty)
    bool Removed; // 0x1d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1e[0x2]; // 0x1e (Size: 0x2, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_RemoveMetadataTag) == 0x38, "Size mismatch for FRigUnit_RemoveMetadataTag");
static_assert(offsetof(FRigUnit_RemoveMetadataTag, Item) == 0x10, "Offset mismatch for FRigUnit_RemoveMetadataTag::Item");
static_assert(offsetof(FRigUnit_RemoveMetadataTag, Tag) == 0x18, "Offset mismatch for FRigUnit_RemoveMetadataTag::Tag");
static_assert(offsetof(FRigUnit_RemoveMetadataTag, Namespace) == 0x1c, "Offset mismatch for FRigUnit_RemoveMetadataTag::Namespace");
static_assert(offsetof(FRigUnit_RemoveMetadataTag, Removed) == 0x1d, "Offset mismatch for FRigUnit_RemoveMetadataTag::Removed");
static_assert(offsetof(FRigUnit_RemoveMetadataTag, CachedIndex) == 0x20, "Offset mismatch for FRigUnit_RemoveMetadataTag::CachedIndex");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FRigUnit_HasMetadataTag : FRigUnit
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    FName Tag; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Namespace; // 0x14 (Size: 0x1, Type: EnumProperty)
    bool Found; // 0x15 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_16[0x2]; // 0x16 (Size: 0x2, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HasMetadataTag) == 0x30, "Size mismatch for FRigUnit_HasMetadataTag");
static_assert(offsetof(FRigUnit_HasMetadataTag, Item) == 0x8, "Offset mismatch for FRigUnit_HasMetadataTag::Item");
static_assert(offsetof(FRigUnit_HasMetadataTag, Tag) == 0x10, "Offset mismatch for FRigUnit_HasMetadataTag::Tag");
static_assert(offsetof(FRigUnit_HasMetadataTag, Namespace) == 0x14, "Offset mismatch for FRigUnit_HasMetadataTag::Namespace");
static_assert(offsetof(FRigUnit_HasMetadataTag, Found) == 0x15, "Offset mismatch for FRigUnit_HasMetadataTag::Found");
static_assert(offsetof(FRigUnit_HasMetadataTag, CachedIndex) == 0x18, "Offset mismatch for FRigUnit_HasMetadataTag::CachedIndex");

// Size: 0x40 (Inherited: 0x10, Single: 0x30)
struct FRigUnit_HasMetadataTagArray : FRigUnit
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FName> Tags; // 0x10 (Size: 0x10, Type: ArrayProperty)
    uint8_t Namespace; // 0x20 (Size: 0x1, Type: EnumProperty)
    bool Found; // 0x21 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_22[0x6]; // 0x22 (Size: 0x6, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_HasMetadataTagArray) == 0x40, "Size mismatch for FRigUnit_HasMetadataTagArray");
static_assert(offsetof(FRigUnit_HasMetadataTagArray, Item) == 0x8, "Offset mismatch for FRigUnit_HasMetadataTagArray::Item");
static_assert(offsetof(FRigUnit_HasMetadataTagArray, Tags) == 0x10, "Offset mismatch for FRigUnit_HasMetadataTagArray::Tags");
static_assert(offsetof(FRigUnit_HasMetadataTagArray, Namespace) == 0x20, "Offset mismatch for FRigUnit_HasMetadataTagArray::Namespace");
static_assert(offsetof(FRigUnit_HasMetadataTagArray, Found) == 0x21, "Offset mismatch for FRigUnit_HasMetadataTagArray::Found");
static_assert(offsetof(FRigUnit_HasMetadataTagArray, CachedIndex) == 0x28, "Offset mismatch for FRigUnit_HasMetadataTagArray::CachedIndex");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FRigUnit_FindItemsWithMetadataTag : FRigUnit
{
    FName Tag; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Namespace; // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_FindItemsWithMetadataTag) == 0x20, "Size mismatch for FRigUnit_FindItemsWithMetadataTag");
static_assert(offsetof(FRigUnit_FindItemsWithMetadataTag, Tag) == 0x8, "Offset mismatch for FRigUnit_FindItemsWithMetadataTag::Tag");
static_assert(offsetof(FRigUnit_FindItemsWithMetadataTag, Namespace) == 0xc, "Offset mismatch for FRigUnit_FindItemsWithMetadataTag::Namespace");
static_assert(offsetof(FRigUnit_FindItemsWithMetadataTag, Items) == 0x10, "Offset mismatch for FRigUnit_FindItemsWithMetadataTag::Items");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FRigUnit_FindItemsWithMetadataTagArray : FRigUnit
{
    TArray<FName> Tags; // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Namespace; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    TArray<FRigElementKey> Items; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_FindItemsWithMetadataTagArray) == 0x30, "Size mismatch for FRigUnit_FindItemsWithMetadataTagArray");
static_assert(offsetof(FRigUnit_FindItemsWithMetadataTagArray, Tags) == 0x8, "Offset mismatch for FRigUnit_FindItemsWithMetadataTagArray::Tags");
static_assert(offsetof(FRigUnit_FindItemsWithMetadataTagArray, Namespace) == 0x18, "Offset mismatch for FRigUnit_FindItemsWithMetadataTagArray::Namespace");
static_assert(offsetof(FRigUnit_FindItemsWithMetadataTagArray, Items) == 0x20, "Offset mismatch for FRigUnit_FindItemsWithMetadataTagArray::Items");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FRigUnit_FilterItemsByMetadataTags : FRigUnit
{
    TArray<FRigElementKey> Items; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> Tags; // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t Namespace; // 0x28 (Size: 0x1, Type: EnumProperty)
    bool Inclusive; // 0x29 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a[0x6]; // 0x2a (Size: 0x6, Type: PaddingProperty)
    TArray<FRigElementKey> Result; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedIndices; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_FilterItemsByMetadataTags) == 0x50, "Size mismatch for FRigUnit_FilterItemsByMetadataTags");
static_assert(offsetof(FRigUnit_FilterItemsByMetadataTags, Items) == 0x8, "Offset mismatch for FRigUnit_FilterItemsByMetadataTags::Items");
static_assert(offsetof(FRigUnit_FilterItemsByMetadataTags, Tags) == 0x18, "Offset mismatch for FRigUnit_FilterItemsByMetadataTags::Tags");
static_assert(offsetof(FRigUnit_FilterItemsByMetadataTags, Namespace) == 0x28, "Offset mismatch for FRigUnit_FilterItemsByMetadataTags::Namespace");
static_assert(offsetof(FRigUnit_FilterItemsByMetadataTags, Inclusive) == 0x29, "Offset mismatch for FRigUnit_FilterItemsByMetadataTags::Inclusive");
static_assert(offsetof(FRigUnit_FilterItemsByMetadataTags, Result) == 0x30, "Offset mismatch for FRigUnit_FilterItemsByMetadataTags::Result");
static_assert(offsetof(FRigUnit_FilterItemsByMetadataTags, CachedIndices) == 0x40, "Offset mismatch for FRigUnit_FilterItemsByMetadataTags::CachedIndices");

// Size: 0xa0 (Inherited: 0x220, Single: 0xfffffe80)
struct FRigDispatch_GetModuleMetadata : FRigDispatch_GetMetadata
{
};

static_assert(sizeof(FRigDispatch_GetModuleMetadata) == 0xa0, "Size mismatch for FRigDispatch_GetModuleMetadata");

// Size: 0xa0 (Inherited: 0x220, Single: 0xfffffe80)
struct FRigDispatch_SetModuleMetadata : FRigDispatch_SetMetadata
{
};

static_assert(sizeof(FRigDispatch_SetModuleMetadata) == 0xa0, "Size mismatch for FRigDispatch_SetModuleMetadata");

// Size: 0xa0 (Inherited: 0x20, Single: 0x80)
struct FRigUnit_OffsetTransformForItem : FRigUnitMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform OffsetTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    float Weight; // 0x80 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x84 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_85[0x3]; // 0x85 (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x88 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_OffsetTransformForItem) == 0xa0, "Size mismatch for FRigUnit_OffsetTransformForItem");
static_assert(offsetof(FRigUnit_OffsetTransformForItem, Item) == 0x10, "Offset mismatch for FRigUnit_OffsetTransformForItem::Item");
static_assert(offsetof(FRigUnit_OffsetTransformForItem, OffsetTransform) == 0x20, "Offset mismatch for FRigUnit_OffsetTransformForItem::OffsetTransform");
static_assert(offsetof(FRigUnit_OffsetTransformForItem, Weight) == 0x80, "Offset mismatch for FRigUnit_OffsetTransformForItem::Weight");
static_assert(offsetof(FRigUnit_OffsetTransformForItem, bPropagateToChildren) == 0x84, "Offset mismatch for FRigUnit_OffsetTransformForItem::bPropagateToChildren");
static_assert(offsetof(FRigUnit_OffsetTransformForItem, CachedIndex) == 0x88, "Offset mismatch for FRigUnit_OffsetTransformForItem::CachedIndex");

// Size: 0x1a0 (Inherited: 0x20, Single: 0x180)
struct FRigUnit_ParentSwitchConstraint : FRigUnitMutable
{
    FRigElementKey Subject; // 0x10 (Size: 0x8, Type: StructProperty)
    int32_t ParentIndex; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FRigElementKeyCollection Parents; // 0x20 (Size: 0x10, Type: StructProperty)
    FTransform InitialGlobalTransform; // 0x30 (Size: 0x60, Type: StructProperty)
    float Weight; // 0x90 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_94[0xc]; // 0x94 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0xa0 (Size: 0x60, Type: StructProperty)
    bool Switched; // 0x100 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0x7]; // 0x101 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedSubject; // 0x108 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent; // 0x120 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_138[0x8]; // 0x138 (Size: 0x8, Type: PaddingProperty)
    FTransform RelativeOffset; // 0x140 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ParentSwitchConstraint) == 0x1a0, "Size mismatch for FRigUnit_ParentSwitchConstraint");
static_assert(offsetof(FRigUnit_ParentSwitchConstraint, Subject) == 0x10, "Offset mismatch for FRigUnit_ParentSwitchConstraint::Subject");
static_assert(offsetof(FRigUnit_ParentSwitchConstraint, ParentIndex) == 0x18, "Offset mismatch for FRigUnit_ParentSwitchConstraint::ParentIndex");
static_assert(offsetof(FRigUnit_ParentSwitchConstraint, Parents) == 0x20, "Offset mismatch for FRigUnit_ParentSwitchConstraint::Parents");
static_assert(offsetof(FRigUnit_ParentSwitchConstraint, InitialGlobalTransform) == 0x30, "Offset mismatch for FRigUnit_ParentSwitchConstraint::InitialGlobalTransform");
static_assert(offsetof(FRigUnit_ParentSwitchConstraint, Weight) == 0x90, "Offset mismatch for FRigUnit_ParentSwitchConstraint::Weight");
static_assert(offsetof(FRigUnit_ParentSwitchConstraint, Transform) == 0xa0, "Offset mismatch for FRigUnit_ParentSwitchConstraint::Transform");
static_assert(offsetof(FRigUnit_ParentSwitchConstraint, Switched) == 0x100, "Offset mismatch for FRigUnit_ParentSwitchConstraint::Switched");
static_assert(offsetof(FRigUnit_ParentSwitchConstraint, CachedSubject) == 0x108, "Offset mismatch for FRigUnit_ParentSwitchConstraint::CachedSubject");
static_assert(offsetof(FRigUnit_ParentSwitchConstraint, CachedParent) == 0x120, "Offset mismatch for FRigUnit_ParentSwitchConstraint::CachedParent");
static_assert(offsetof(FRigUnit_ParentSwitchConstraint, RelativeOffset) == 0x140, "Offset mismatch for FRigUnit_ParentSwitchConstraint::RelativeOffset");

// Size: 0x1a0 (Inherited: 0x20, Single: 0x180)
struct FRigUnit_ParentSwitchConstraintArray : FRigUnitMutable
{
    FRigElementKey Subject; // 0x10 (Size: 0x8, Type: StructProperty)
    int32_t ParentIndex; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    TArray<FRigElementKey> Parents; // 0x20 (Size: 0x10, Type: ArrayProperty)
    FTransform InitialGlobalTransform; // 0x30 (Size: 0x60, Type: StructProperty)
    float Weight; // 0x90 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_94[0xc]; // 0x94 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0xa0 (Size: 0x60, Type: StructProperty)
    bool Switched; // 0x100 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0x7]; // 0x101 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedSubject; // 0x108 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent; // 0x120 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_138[0x8]; // 0x138 (Size: 0x8, Type: PaddingProperty)
    FTransform RelativeOffset; // 0x140 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ParentSwitchConstraintArray) == 0x1a0, "Size mismatch for FRigUnit_ParentSwitchConstraintArray");
static_assert(offsetof(FRigUnit_ParentSwitchConstraintArray, Subject) == 0x10, "Offset mismatch for FRigUnit_ParentSwitchConstraintArray::Subject");
static_assert(offsetof(FRigUnit_ParentSwitchConstraintArray, ParentIndex) == 0x18, "Offset mismatch for FRigUnit_ParentSwitchConstraintArray::ParentIndex");
static_assert(offsetof(FRigUnit_ParentSwitchConstraintArray, Parents) == 0x20, "Offset mismatch for FRigUnit_ParentSwitchConstraintArray::Parents");
static_assert(offsetof(FRigUnit_ParentSwitchConstraintArray, InitialGlobalTransform) == 0x30, "Offset mismatch for FRigUnit_ParentSwitchConstraintArray::InitialGlobalTransform");
static_assert(offsetof(FRigUnit_ParentSwitchConstraintArray, Weight) == 0x90, "Offset mismatch for FRigUnit_ParentSwitchConstraintArray::Weight");
static_assert(offsetof(FRigUnit_ParentSwitchConstraintArray, Transform) == 0xa0, "Offset mismatch for FRigUnit_ParentSwitchConstraintArray::Transform");
static_assert(offsetof(FRigUnit_ParentSwitchConstraintArray, Switched) == 0x100, "Offset mismatch for FRigUnit_ParentSwitchConstraintArray::Switched");
static_assert(offsetof(FRigUnit_ParentSwitchConstraintArray, CachedSubject) == 0x108, "Offset mismatch for FRigUnit_ParentSwitchConstraintArray::CachedSubject");
static_assert(offsetof(FRigUnit_ParentSwitchConstraintArray, CachedParent) == 0x120, "Offset mismatch for FRigUnit_ParentSwitchConstraintArray::CachedParent");
static_assert(offsetof(FRigUnit_ParentSwitchConstraintArray, RelativeOffset) == 0x140, "Offset mismatch for FRigUnit_ParentSwitchConstraintArray::RelativeOffset");

// Size: 0xe0 (Inherited: 0x10, Single: 0xd0)
struct FRigUnit_ProjectTransformToNewParent : FRigUnit
{
    FRigElementKey Child; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bChildInitial; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    FRigElementKey OldParent; // 0x14 (Size: 0x8, Type: StructProperty)
    bool bOldParentInitial; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
    FRigElementKey NewParent; // 0x20 (Size: 0x8, Type: StructProperty)
    bool bNewParentInitial; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    FTransform Transform; // 0x30 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedChild; // 0x90 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedOldParent; // 0xa8 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedNewParent; // 0xc0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ProjectTransformToNewParent) == 0xe0, "Size mismatch for FRigUnit_ProjectTransformToNewParent");
static_assert(offsetof(FRigUnit_ProjectTransformToNewParent, Child) == 0x8, "Offset mismatch for FRigUnit_ProjectTransformToNewParent::Child");
static_assert(offsetof(FRigUnit_ProjectTransformToNewParent, bChildInitial) == 0x10, "Offset mismatch for FRigUnit_ProjectTransformToNewParent::bChildInitial");
static_assert(offsetof(FRigUnit_ProjectTransformToNewParent, OldParent) == 0x14, "Offset mismatch for FRigUnit_ProjectTransformToNewParent::OldParent");
static_assert(offsetof(FRigUnit_ProjectTransformToNewParent, bOldParentInitial) == 0x1c, "Offset mismatch for FRigUnit_ProjectTransformToNewParent::bOldParentInitial");
static_assert(offsetof(FRigUnit_ProjectTransformToNewParent, NewParent) == 0x20, "Offset mismatch for FRigUnit_ProjectTransformToNewParent::NewParent");
static_assert(offsetof(FRigUnit_ProjectTransformToNewParent, bNewParentInitial) == 0x28, "Offset mismatch for FRigUnit_ProjectTransformToNewParent::bNewParentInitial");
static_assert(offsetof(FRigUnit_ProjectTransformToNewParent, Transform) == 0x30, "Offset mismatch for FRigUnit_ProjectTransformToNewParent::Transform");
static_assert(offsetof(FRigUnit_ProjectTransformToNewParent, CachedChild) == 0x90, "Offset mismatch for FRigUnit_ProjectTransformToNewParent::CachedChild");
static_assert(offsetof(FRigUnit_ProjectTransformToNewParent, CachedOldParent) == 0xa8, "Offset mismatch for FRigUnit_ProjectTransformToNewParent::CachedOldParent");
static_assert(offsetof(FRigUnit_ProjectTransformToNewParent, CachedNewParent) == 0xc0, "Offset mismatch for FRigUnit_ProjectTransformToNewParent::CachedNewParent");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_PropagateTransform : FRigUnitMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bRecomputeGlobal; // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bApplyToChildren; // 0x19 (Size: 0x1, Type: BoolProperty)
    bool bRecursive; // 0x1a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1b[0x5]; // 0x1b (Size: 0x5, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_PropagateTransform) == 0x38, "Size mismatch for FRigUnit_PropagateTransform");
static_assert(offsetof(FRigUnit_PropagateTransform, Item) == 0x10, "Offset mismatch for FRigUnit_PropagateTransform::Item");
static_assert(offsetof(FRigUnit_PropagateTransform, bRecomputeGlobal) == 0x18, "Offset mismatch for FRigUnit_PropagateTransform::bRecomputeGlobal");
static_assert(offsetof(FRigUnit_PropagateTransform, bApplyToChildren) == 0x19, "Offset mismatch for FRigUnit_PropagateTransform::bApplyToChildren");
static_assert(offsetof(FRigUnit_PropagateTransform, bRecursive) == 0x1a, "Offset mismatch for FRigUnit_PropagateTransform::bRecursive");
static_assert(offsetof(FRigUnit_PropagateTransform, CachedIndex) == 0x20, "Offset mismatch for FRigUnit_PropagateTransform::CachedIndex");

// Size: 0x28 (Inherited: 0x20, Single: 0x8)
struct FRigUnit_SendEvent : FRigUnitMutable
{
    uint8_t Event; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    FRigElementKey Item; // 0x14 (Size: 0x8, Type: StructProperty)
    float OffsetInSeconds; // 0x1c (Size: 0x4, Type: FloatProperty)
    bool bEnable; // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bOnlyDuringInteraction; // 0x21 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_22[0x6]; // 0x22 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SendEvent) == 0x28, "Size mismatch for FRigUnit_SendEvent");
static_assert(offsetof(FRigUnit_SendEvent, Event) == 0x10, "Offset mismatch for FRigUnit_SendEvent::Event");
static_assert(offsetof(FRigUnit_SendEvent, Item) == 0x14, "Offset mismatch for FRigUnit_SendEvent::Item");
static_assert(offsetof(FRigUnit_SendEvent, OffsetInSeconds) == 0x1c, "Offset mismatch for FRigUnit_SendEvent::OffsetInSeconds");
static_assert(offsetof(FRigUnit_SendEvent, bEnable) == 0x20, "Offset mismatch for FRigUnit_SendEvent::bEnable");
static_assert(offsetof(FRigUnit_SendEvent, bOnlyDuringInteraction) == 0x21, "Offset mismatch for FRigUnit_SendEvent::bOnlyDuringInteraction");

// Size: 0x100 (Inherited: 0x20, Single: 0xe0)
struct FRigUnit_SetBoneInitialTransform : FRigUnitMutable
{
    FName bone; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform Result; // 0x80 (Size: 0x60, Type: StructProperty)
    uint8_t Space; // 0xe0 (Size: 0x1, Type: EnumProperty)
    bool bPropagateToChildren; // 0xe1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e2[0x6]; // 0xe2 (Size: 0x6, Type: PaddingProperty)
    FCachedRigElement CachedBone; // 0xe8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetBoneInitialTransform) == 0x100, "Size mismatch for FRigUnit_SetBoneInitialTransform");
static_assert(offsetof(FRigUnit_SetBoneInitialTransform, bone) == 0x10, "Offset mismatch for FRigUnit_SetBoneInitialTransform::bone");
static_assert(offsetof(FRigUnit_SetBoneInitialTransform, Transform) == 0x20, "Offset mismatch for FRigUnit_SetBoneInitialTransform::Transform");
static_assert(offsetof(FRigUnit_SetBoneInitialTransform, Result) == 0x80, "Offset mismatch for FRigUnit_SetBoneInitialTransform::Result");
static_assert(offsetof(FRigUnit_SetBoneInitialTransform, Space) == 0xe0, "Offset mismatch for FRigUnit_SetBoneInitialTransform::Space");
static_assert(offsetof(FRigUnit_SetBoneInitialTransform, bPropagateToChildren) == 0xe1, "Offset mismatch for FRigUnit_SetBoneInitialTransform::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetBoneInitialTransform, CachedBone) == 0xe8, "Offset mismatch for FRigUnit_SetBoneInitialTransform::CachedBone");

// Size: 0x70 (Inherited: 0x20, Single: 0x50)
struct FRigUnit_SetBoneRotation : FRigUnitMutable
{
    FName bone; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
    FQuat Rotation; // 0x20 (Size: 0x20, Type: StructProperty)
    uint8_t Space; // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_41[0x3]; // 0x41 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0x44 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedBone; // 0x50 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_68[0x8]; // 0x68 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetBoneRotation) == 0x70, "Size mismatch for FRigUnit_SetBoneRotation");
static_assert(offsetof(FRigUnit_SetBoneRotation, bone) == 0x10, "Offset mismatch for FRigUnit_SetBoneRotation::bone");
static_assert(offsetof(FRigUnit_SetBoneRotation, Rotation) == 0x20, "Offset mismatch for FRigUnit_SetBoneRotation::Rotation");
static_assert(offsetof(FRigUnit_SetBoneRotation, Space) == 0x40, "Offset mismatch for FRigUnit_SetBoneRotation::Space");
static_assert(offsetof(FRigUnit_SetBoneRotation, Weight) == 0x44, "Offset mismatch for FRigUnit_SetBoneRotation::Weight");
static_assert(offsetof(FRigUnit_SetBoneRotation, bPropagateToChildren) == 0x48, "Offset mismatch for FRigUnit_SetBoneRotation::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetBoneRotation, CachedBone) == 0x50, "Offset mismatch for FRigUnit_SetBoneRotation::CachedBone");

// Size: 0x110 (Inherited: 0x20, Single: 0xf0)
struct FRigUnit_SetBoneTransform : FRigUnitMutable
{
    FName bone; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform Result; // 0x80 (Size: 0x60, Type: StructProperty)
    uint8_t Space; // 0xe0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_e1[0x3]; // 0xe1 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0xe4 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0xe8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e9[0x7]; // 0xe9 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedBone; // 0xf0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetBoneTransform) == 0x110, "Size mismatch for FRigUnit_SetBoneTransform");
static_assert(offsetof(FRigUnit_SetBoneTransform, bone) == 0x10, "Offset mismatch for FRigUnit_SetBoneTransform::bone");
static_assert(offsetof(FRigUnit_SetBoneTransform, Transform) == 0x20, "Offset mismatch for FRigUnit_SetBoneTransform::Transform");
static_assert(offsetof(FRigUnit_SetBoneTransform, Result) == 0x80, "Offset mismatch for FRigUnit_SetBoneTransform::Result");
static_assert(offsetof(FRigUnit_SetBoneTransform, Space) == 0xe0, "Offset mismatch for FRigUnit_SetBoneTransform::Space");
static_assert(offsetof(FRigUnit_SetBoneTransform, Weight) == 0xe4, "Offset mismatch for FRigUnit_SetBoneTransform::Weight");
static_assert(offsetof(FRigUnit_SetBoneTransform, bPropagateToChildren) == 0xe8, "Offset mismatch for FRigUnit_SetBoneTransform::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetBoneTransform, CachedBone) == 0xf0, "Offset mismatch for FRigUnit_SetBoneTransform::CachedBone");

// Size: 0x58 (Inherited: 0x20, Single: 0x38)
struct FRigUnit_SetBoneTranslation : FRigUnitMutable
{
    FName bone; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FVector Translation; // 0x18 (Size: 0x18, Type: StructProperty)
    uint8_t Space; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x3]; // 0x31 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0x34 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedBone; // 0x40 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetBoneTranslation) == 0x58, "Size mismatch for FRigUnit_SetBoneTranslation");
static_assert(offsetof(FRigUnit_SetBoneTranslation, bone) == 0x10, "Offset mismatch for FRigUnit_SetBoneTranslation::bone");
static_assert(offsetof(FRigUnit_SetBoneTranslation, Translation) == 0x18, "Offset mismatch for FRigUnit_SetBoneTranslation::Translation");
static_assert(offsetof(FRigUnit_SetBoneTranslation, Space) == 0x30, "Offset mismatch for FRigUnit_SetBoneTranslation::Space");
static_assert(offsetof(FRigUnit_SetBoneTranslation, Weight) == 0x34, "Offset mismatch for FRigUnit_SetBoneTranslation::Weight");
static_assert(offsetof(FRigUnit_SetBoneTranslation, bPropagateToChildren) == 0x38, "Offset mismatch for FRigUnit_SetBoneTranslation::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetBoneTranslation, CachedBone) == 0x40, "Offset mismatch for FRigUnit_SetBoneTranslation::CachedBone");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FRigUnit_GetControlColor : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    FLinearColor Color; // 0xc (Size: 0x10, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetControlColor) == 0x38, "Size mismatch for FRigUnit_GetControlColor");
static_assert(offsetof(FRigUnit_GetControlColor, Control) == 0x8, "Offset mismatch for FRigUnit_GetControlColor::Control");
static_assert(offsetof(FRigUnit_GetControlColor, Color) == 0xc, "Offset mismatch for FRigUnit_GetControlColor::Color");
static_assert(offsetof(FRigUnit_GetControlColor, CachedControlIndex) == 0x20, "Offset mismatch for FRigUnit_GetControlColor::CachedControlIndex");

// Size: 0x40 (Inherited: 0x20, Single: 0x20)
struct FRigUnit_SetControlColor : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    FLinearColor Color; // 0x14 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlColor) == 0x40, "Size mismatch for FRigUnit_SetControlColor");
static_assert(offsetof(FRigUnit_SetControlColor, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlColor::Control");
static_assert(offsetof(FRigUnit_SetControlColor, Color) == 0x14, "Offset mismatch for FRigUnit_SetControlColor::Color");
static_assert(offsetof(FRigUnit_SetControlColor, CachedControlIndex) == 0x28, "Offset mismatch for FRigUnit_SetControlColor::CachedControlIndex");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FRigUnit_GetControlDrivenList : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    TArray<FRigElementKey> Driven; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedControlIndex; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetControlDrivenList) == 0x38, "Size mismatch for FRigUnit_GetControlDrivenList");
static_assert(offsetof(FRigUnit_GetControlDrivenList, Control) == 0x8, "Offset mismatch for FRigUnit_GetControlDrivenList::Control");
static_assert(offsetof(FRigUnit_GetControlDrivenList, Driven) == 0x10, "Offset mismatch for FRigUnit_GetControlDrivenList::Driven");
static_assert(offsetof(FRigUnit_GetControlDrivenList, CachedControlIndex) == 0x20, "Offset mismatch for FRigUnit_GetControlDrivenList::CachedControlIndex");

// Size: 0x40 (Inherited: 0x20, Single: 0x20)
struct FRigUnit_SetControlDrivenList : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    TArray<FRigElementKey> Driven; // 0x18 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedControlIndex; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlDrivenList) == 0x40, "Size mismatch for FRigUnit_SetControlDrivenList");
static_assert(offsetof(FRigUnit_SetControlDrivenList, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlDrivenList::Control");
static_assert(offsetof(FRigUnit_SetControlDrivenList, Driven) == 0x18, "Offset mismatch for FRigUnit_SetControlDrivenList::Driven");
static_assert(offsetof(FRigUnit_SetControlDrivenList, CachedControlIndex) == 0x28, "Offset mismatch for FRigUnit_SetControlDrivenList::CachedControlIndex");

// Size: 0xa0 (Inherited: 0x20, Single: 0x80)
struct FRigUnit_SetControlOffset : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
    FTransform Offset; // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t Space; // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_81[0x7]; // 0x81 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x88 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlOffset) == 0xa0, "Size mismatch for FRigUnit_SetControlOffset");
static_assert(offsetof(FRigUnit_SetControlOffset, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlOffset::Control");
static_assert(offsetof(FRigUnit_SetControlOffset, Offset) == 0x20, "Offset mismatch for FRigUnit_SetControlOffset::Offset");
static_assert(offsetof(FRigUnit_SetControlOffset, Space) == 0x80, "Offset mismatch for FRigUnit_SetControlOffset::Space");
static_assert(offsetof(FRigUnit_SetControlOffset, CachedControlIndex) == 0x88, "Offset mismatch for FRigUnit_SetControlOffset::CachedControlIndex");

// Size: 0x50 (Inherited: 0x20, Single: 0x30)
struct FRigUnit_SetControlTranslationOffset : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FVector Offset; // 0x18 (Size: 0x18, Type: StructProperty)
    uint8_t Space; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlTranslationOffset) == 0x50, "Size mismatch for FRigUnit_SetControlTranslationOffset");
static_assert(offsetof(FRigUnit_SetControlTranslationOffset, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlTranslationOffset::Control");
static_assert(offsetof(FRigUnit_SetControlTranslationOffset, Offset) == 0x18, "Offset mismatch for FRigUnit_SetControlTranslationOffset::Offset");
static_assert(offsetof(FRigUnit_SetControlTranslationOffset, Space) == 0x30, "Offset mismatch for FRigUnit_SetControlTranslationOffset::Space");
static_assert(offsetof(FRigUnit_SetControlTranslationOffset, CachedControlIndex) == 0x38, "Offset mismatch for FRigUnit_SetControlTranslationOffset::CachedControlIndex");

// Size: 0x60 (Inherited: 0x20, Single: 0x40)
struct FRigUnit_SetControlRotationOffset : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
    FQuat Offset; // 0x20 (Size: 0x20, Type: StructProperty)
    uint8_t Space; // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x48 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlRotationOffset) == 0x60, "Size mismatch for FRigUnit_SetControlRotationOffset");
static_assert(offsetof(FRigUnit_SetControlRotationOffset, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlRotationOffset::Control");
static_assert(offsetof(FRigUnit_SetControlRotationOffset, Offset) == 0x20, "Offset mismatch for FRigUnit_SetControlRotationOffset::Offset");
static_assert(offsetof(FRigUnit_SetControlRotationOffset, Space) == 0x40, "Offset mismatch for FRigUnit_SetControlRotationOffset::Space");
static_assert(offsetof(FRigUnit_SetControlRotationOffset, CachedControlIndex) == 0x48, "Offset mismatch for FRigUnit_SetControlRotationOffset::CachedControlIndex");

// Size: 0x50 (Inherited: 0x20, Single: 0x30)
struct FRigUnit_SetControlScaleOffset : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FVector Scale; // 0x18 (Size: 0x18, Type: StructProperty)
    uint8_t Space; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlScaleOffset) == 0x50, "Size mismatch for FRigUnit_SetControlScaleOffset");
static_assert(offsetof(FRigUnit_SetControlScaleOffset, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlScaleOffset::Control");
static_assert(offsetof(FRigUnit_SetControlScaleOffset, Scale) == 0x18, "Offset mismatch for FRigUnit_SetControlScaleOffset::Scale");
static_assert(offsetof(FRigUnit_SetControlScaleOffset, Space) == 0x30, "Offset mismatch for FRigUnit_SetControlScaleOffset::Space");
static_assert(offsetof(FRigUnit_SetControlScaleOffset, CachedControlIndex) == 0x38, "Offset mismatch for FRigUnit_SetControlScaleOffset::CachedControlIndex");

// Size: 0x90 (Inherited: 0x10, Single: 0x80)
struct FRigUnit_GetShapeTransform : FRigUnit
{
    FName Control; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedControlIndex; // 0x70 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetShapeTransform) == 0x90, "Size mismatch for FRigUnit_GetShapeTransform");
static_assert(offsetof(FRigUnit_GetShapeTransform, Control) == 0x8, "Offset mismatch for FRigUnit_GetShapeTransform::Control");
static_assert(offsetof(FRigUnit_GetShapeTransform, Transform) == 0x10, "Offset mismatch for FRigUnit_GetShapeTransform::Transform");
static_assert(offsetof(FRigUnit_GetShapeTransform, CachedControlIndex) == 0x70, "Offset mismatch for FRigUnit_GetShapeTransform::CachedControlIndex");

// Size: 0xa0 (Inherited: 0x20, Single: 0x80)
struct FRigUnit_SetShapeTransform : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedControlIndex; // 0x80 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_98[0x8]; // 0x98 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetShapeTransform) == 0xa0, "Size mismatch for FRigUnit_SetShapeTransform");
static_assert(offsetof(FRigUnit_SetShapeTransform, Control) == 0x10, "Offset mismatch for FRigUnit_SetShapeTransform::Control");
static_assert(offsetof(FRigUnit_SetShapeTransform, Transform) == 0x20, "Offset mismatch for FRigUnit_SetShapeTransform::Transform");
static_assert(offsetof(FRigUnit_SetShapeTransform, CachedControlIndex) == 0x80, "Offset mismatch for FRigUnit_SetShapeTransform::CachedControlIndex");

// Size: 0x30 (Inherited: 0x20, Single: 0x10)
struct FRigUnit_SetControlBool : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    bool BoolValue; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlBool) == 0x30, "Size mismatch for FRigUnit_SetControlBool");
static_assert(offsetof(FRigUnit_SetControlBool, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlBool::Control");
static_assert(offsetof(FRigUnit_SetControlBool, BoolValue) == 0x14, "Offset mismatch for FRigUnit_SetControlBool::BoolValue");
static_assert(offsetof(FRigUnit_SetControlBool, CachedControlIndex) == 0x18, "Offset mismatch for FRigUnit_SetControlBool::CachedControlIndex");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FRigUnit_SetMultiControlBool_Entry
{
    FName Control; // 0x0 (Size: 0x4, Type: NameProperty)
    bool BoolValue; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetMultiControlBool_Entry) == 0x8, "Size mismatch for FRigUnit_SetMultiControlBool_Entry");
static_assert(offsetof(FRigUnit_SetMultiControlBool_Entry, Control) == 0x0, "Offset mismatch for FRigUnit_SetMultiControlBool_Entry::Control");
static_assert(offsetof(FRigUnit_SetMultiControlBool_Entry, BoolValue) == 0x4, "Offset mismatch for FRigUnit_SetMultiControlBool_Entry::BoolValue");

// Size: 0x30 (Inherited: 0x20, Single: 0x10)
struct FRigUnit_SetMultiControlBool : FRigUnitMutable
{
    TArray<FRigUnit_SetMultiControlBool_Entry> Entries; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedControlIndices; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_SetMultiControlBool) == 0x30, "Size mismatch for FRigUnit_SetMultiControlBool");
static_assert(offsetof(FRigUnit_SetMultiControlBool, Entries) == 0x10, "Offset mismatch for FRigUnit_SetMultiControlBool::Entries");
static_assert(offsetof(FRigUnit_SetMultiControlBool, CachedControlIndices) == 0x20, "Offset mismatch for FRigUnit_SetMultiControlBool::CachedControlIndices");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_SetControlFloat : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    float Weight; // 0x14 (Size: 0x4, Type: FloatProperty)
    float FloatValue; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlFloat) == 0x38, "Size mismatch for FRigUnit_SetControlFloat");
static_assert(offsetof(FRigUnit_SetControlFloat, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlFloat::Control");
static_assert(offsetof(FRigUnit_SetControlFloat, Weight) == 0x14, "Offset mismatch for FRigUnit_SetControlFloat::Weight");
static_assert(offsetof(FRigUnit_SetControlFloat, FloatValue) == 0x18, "Offset mismatch for FRigUnit_SetControlFloat::FloatValue");
static_assert(offsetof(FRigUnit_SetControlFloat, CachedControlIndex) == 0x20, "Offset mismatch for FRigUnit_SetControlFloat::CachedControlIndex");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FRigUnit_SetMultiControlFloat_Entry
{
    FName Control; // 0x0 (Size: 0x4, Type: NameProperty)
    float FloatValue; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_SetMultiControlFloat_Entry) == 0x8, "Size mismatch for FRigUnit_SetMultiControlFloat_Entry");
static_assert(offsetof(FRigUnit_SetMultiControlFloat_Entry, Control) == 0x0, "Offset mismatch for FRigUnit_SetMultiControlFloat_Entry::Control");
static_assert(offsetof(FRigUnit_SetMultiControlFloat_Entry, FloatValue) == 0x4, "Offset mismatch for FRigUnit_SetMultiControlFloat_Entry::FloatValue");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_SetMultiControlFloat : FRigUnitMutable
{
    TArray<FRigUnit_SetMultiControlFloat_Entry> Entries; // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TArray<FCachedRigElement> CachedControlIndices; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_SetMultiControlFloat) == 0x38, "Size mismatch for FRigUnit_SetMultiControlFloat");
static_assert(offsetof(FRigUnit_SetMultiControlFloat, Entries) == 0x10, "Offset mismatch for FRigUnit_SetMultiControlFloat::Entries");
static_assert(offsetof(FRigUnit_SetMultiControlFloat, Weight) == 0x20, "Offset mismatch for FRigUnit_SetMultiControlFloat::Weight");
static_assert(offsetof(FRigUnit_SetMultiControlFloat, CachedControlIndices) == 0x28, "Offset mismatch for FRigUnit_SetMultiControlFloat::CachedControlIndices");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_SetControlInteger : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    int32_t Weight; // 0x14 (Size: 0x4, Type: IntProperty)
    int32_t IntegerValue; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlInteger) == 0x38, "Size mismatch for FRigUnit_SetControlInteger");
static_assert(offsetof(FRigUnit_SetControlInteger, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlInteger::Control");
static_assert(offsetof(FRigUnit_SetControlInteger, Weight) == 0x14, "Offset mismatch for FRigUnit_SetControlInteger::Weight");
static_assert(offsetof(FRigUnit_SetControlInteger, IntegerValue) == 0x18, "Offset mismatch for FRigUnit_SetControlInteger::IntegerValue");
static_assert(offsetof(FRigUnit_SetControlInteger, CachedControlIndex) == 0x20, "Offset mismatch for FRigUnit_SetControlInteger::CachedControlIndex");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FRigUnit_SetMultiControlInteger_Entry
{
    FName Control; // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t IntegerValue; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FRigUnit_SetMultiControlInteger_Entry) == 0x8, "Size mismatch for FRigUnit_SetMultiControlInteger_Entry");
static_assert(offsetof(FRigUnit_SetMultiControlInteger_Entry, Control) == 0x0, "Offset mismatch for FRigUnit_SetMultiControlInteger_Entry::Control");
static_assert(offsetof(FRigUnit_SetMultiControlInteger_Entry, IntegerValue) == 0x4, "Offset mismatch for FRigUnit_SetMultiControlInteger_Entry::IntegerValue");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_SetMultiControlInteger : FRigUnitMutable
{
    TArray<FRigUnit_SetMultiControlInteger_Entry> Entries; // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TArray<FCachedRigElement> CachedControlIndices; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_SetMultiControlInteger) == 0x38, "Size mismatch for FRigUnit_SetMultiControlInteger");
static_assert(offsetof(FRigUnit_SetMultiControlInteger, Entries) == 0x10, "Offset mismatch for FRigUnit_SetMultiControlInteger::Entries");
static_assert(offsetof(FRigUnit_SetMultiControlInteger, Weight) == 0x20, "Offset mismatch for FRigUnit_SetMultiControlInteger::Weight");
static_assert(offsetof(FRigUnit_SetMultiControlInteger, CachedControlIndices) == 0x28, "Offset mismatch for FRigUnit_SetMultiControlInteger::CachedControlIndices");

// Size: 0x40 (Inherited: 0x20, Single: 0x20)
struct FRigUnit_SetControlVector2D : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    float Weight; // 0x14 (Size: 0x4, Type: FloatProperty)
    FVector2D Vector; // 0x18 (Size: 0x10, Type: StructProperty)
    FCachedRigElement CachedControlIndex; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlVector2D) == 0x40, "Size mismatch for FRigUnit_SetControlVector2D");
static_assert(offsetof(FRigUnit_SetControlVector2D, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlVector2D::Control");
static_assert(offsetof(FRigUnit_SetControlVector2D, Weight) == 0x14, "Offset mismatch for FRigUnit_SetControlVector2D::Weight");
static_assert(offsetof(FRigUnit_SetControlVector2D, Vector) == 0x18, "Offset mismatch for FRigUnit_SetControlVector2D::Vector");
static_assert(offsetof(FRigUnit_SetControlVector2D, CachedControlIndex) == 0x28, "Offset mismatch for FRigUnit_SetControlVector2D::CachedControlIndex");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FRigUnit_SetMultiControlVector2D_Entry
{
    FName Control; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector2D Vector; // 0x8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetMultiControlVector2D_Entry) == 0x18, "Size mismatch for FRigUnit_SetMultiControlVector2D_Entry");
static_assert(offsetof(FRigUnit_SetMultiControlVector2D_Entry, Control) == 0x0, "Offset mismatch for FRigUnit_SetMultiControlVector2D_Entry::Control");
static_assert(offsetof(FRigUnit_SetMultiControlVector2D_Entry, Vector) == 0x8, "Offset mismatch for FRigUnit_SetMultiControlVector2D_Entry::Vector");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_SetMultiControlVector2D : FRigUnitMutable
{
    TArray<FRigUnit_SetMultiControlVector2D_Entry> Entries; // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TArray<FCachedRigElement> CachedControlIndices; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_SetMultiControlVector2D) == 0x38, "Size mismatch for FRigUnit_SetMultiControlVector2D");
static_assert(offsetof(FRigUnit_SetMultiControlVector2D, Entries) == 0x10, "Offset mismatch for FRigUnit_SetMultiControlVector2D::Entries");
static_assert(offsetof(FRigUnit_SetMultiControlVector2D, Weight) == 0x20, "Offset mismatch for FRigUnit_SetMultiControlVector2D::Weight");
static_assert(offsetof(FRigUnit_SetMultiControlVector2D, CachedControlIndices) == 0x28, "Offset mismatch for FRigUnit_SetMultiControlVector2D::CachedControlIndices");

// Size: 0x50 (Inherited: 0x20, Single: 0x30)
struct FRigUnit_SetControlVector : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    float Weight; // 0x14 (Size: 0x4, Type: FloatProperty)
    FVector Vector; // 0x18 (Size: 0x18, Type: StructProperty)
    uint8_t Space; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlVector) == 0x50, "Size mismatch for FRigUnit_SetControlVector");
static_assert(offsetof(FRigUnit_SetControlVector, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlVector::Control");
static_assert(offsetof(FRigUnit_SetControlVector, Weight) == 0x14, "Offset mismatch for FRigUnit_SetControlVector::Weight");
static_assert(offsetof(FRigUnit_SetControlVector, Vector) == 0x18, "Offset mismatch for FRigUnit_SetControlVector::Vector");
static_assert(offsetof(FRigUnit_SetControlVector, Space) == 0x30, "Offset mismatch for FRigUnit_SetControlVector::Space");
static_assert(offsetof(FRigUnit_SetControlVector, CachedControlIndex) == 0x38, "Offset mismatch for FRigUnit_SetControlVector::CachedControlIndex");

// Size: 0x50 (Inherited: 0x20, Single: 0x30)
struct FRigUnit_SetControlRotator : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    float Weight; // 0x14 (Size: 0x4, Type: FloatProperty)
    FRotator Rotator; // 0x18 (Size: 0x18, Type: StructProperty)
    uint8_t Space; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlRotator) == 0x50, "Size mismatch for FRigUnit_SetControlRotator");
static_assert(offsetof(FRigUnit_SetControlRotator, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlRotator::Control");
static_assert(offsetof(FRigUnit_SetControlRotator, Weight) == 0x14, "Offset mismatch for FRigUnit_SetControlRotator::Weight");
static_assert(offsetof(FRigUnit_SetControlRotator, Rotator) == 0x18, "Offset mismatch for FRigUnit_SetControlRotator::Rotator");
static_assert(offsetof(FRigUnit_SetControlRotator, Space) == 0x30, "Offset mismatch for FRigUnit_SetControlRotator::Space");
static_assert(offsetof(FRigUnit_SetControlRotator, CachedControlIndex) == 0x38, "Offset mismatch for FRigUnit_SetControlRotator::CachedControlIndex");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FRigUnit_SetMultiControlRotator_Entry
{
    FName Control; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FRotator Rotator; // 0x8 (Size: 0x18, Type: StructProperty)
    uint8_t Space; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetMultiControlRotator_Entry) == 0x28, "Size mismatch for FRigUnit_SetMultiControlRotator_Entry");
static_assert(offsetof(FRigUnit_SetMultiControlRotator_Entry, Control) == 0x0, "Offset mismatch for FRigUnit_SetMultiControlRotator_Entry::Control");
static_assert(offsetof(FRigUnit_SetMultiControlRotator_Entry, Rotator) == 0x8, "Offset mismatch for FRigUnit_SetMultiControlRotator_Entry::Rotator");
static_assert(offsetof(FRigUnit_SetMultiControlRotator_Entry, Space) == 0x20, "Offset mismatch for FRigUnit_SetMultiControlRotator_Entry::Space");

// Size: 0x38 (Inherited: 0x20, Single: 0x18)
struct FRigUnit_SetMultiControlRotator : FRigUnitMutable
{
    TArray<FRigUnit_SetMultiControlRotator_Entry> Entries; // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TArray<FCachedRigElement> CachedControlIndices; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_SetMultiControlRotator) == 0x38, "Size mismatch for FRigUnit_SetMultiControlRotator");
static_assert(offsetof(FRigUnit_SetMultiControlRotator, Entries) == 0x10, "Offset mismatch for FRigUnit_SetMultiControlRotator::Entries");
static_assert(offsetof(FRigUnit_SetMultiControlRotator, Weight) == 0x20, "Offset mismatch for FRigUnit_SetMultiControlRotator::Weight");
static_assert(offsetof(FRigUnit_SetMultiControlRotator, CachedControlIndices) == 0x28, "Offset mismatch for FRigUnit_SetMultiControlRotator::CachedControlIndices");

// Size: 0xa0 (Inherited: 0x20, Single: 0x80)
struct FRigUnit_SetControlTransform : FRigUnitMutable
{
    FName Control; // 0x10 (Size: 0x4, Type: NameProperty)
    float Weight; // 0x14 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t Space; // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_81[0x7]; // 0x81 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x88 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetControlTransform) == 0xa0, "Size mismatch for FRigUnit_SetControlTransform");
static_assert(offsetof(FRigUnit_SetControlTransform, Control) == 0x10, "Offset mismatch for FRigUnit_SetControlTransform::Control");
static_assert(offsetof(FRigUnit_SetControlTransform, Weight) == 0x14, "Offset mismatch for FRigUnit_SetControlTransform::Weight");
static_assert(offsetof(FRigUnit_SetControlTransform, Transform) == 0x20, "Offset mismatch for FRigUnit_SetControlTransform::Transform");
static_assert(offsetof(FRigUnit_SetControlTransform, Space) == 0x80, "Offset mismatch for FRigUnit_SetControlTransform::Space");
static_assert(offsetof(FRigUnit_SetControlTransform, CachedControlIndex) == 0x88, "Offset mismatch for FRigUnit_SetControlTransform::CachedControlIndex");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FRigUnit_GetControlVisibility : FRigUnit
{
    FRigElementKey Item; // 0x8 (Size: 0x8, Type: StructProperty)
    bool bVisible; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedControlIndex; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_GetControlVisibility) == 0x30, "Size mismatch for FRigUnit_GetControlVisibility");
static_assert(offsetof(FRigUnit_GetControlVisibility, Item) == 0x8, "Offset mismatch for FRigUnit_GetControlVisibility::Item");
static_assert(offsetof(FRigUnit_GetControlVisibility, bVisible) == 0x10, "Offset mismatch for FRigUnit_GetControlVisibility::bVisible");
static_assert(offsetof(FRigUnit_GetControlVisibility, CachedControlIndex) == 0x18, "Offset mismatch for FRigUnit_GetControlVisibility::CachedControlIndex");

// Size: 0x40 (Inherited: 0x20, Single: 0x20)
struct FRigUnit_SetControlVisibility : FRigUnitMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    FString Pattern; // 0x18 (Size: 0x10, Type: StrProperty)
    bool bVisible; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    TArray<FCachedRigElement> CachedControlIndices; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_SetControlVisibility) == 0x40, "Size mismatch for FRigUnit_SetControlVisibility");
static_assert(offsetof(FRigUnit_SetControlVisibility, Item) == 0x10, "Offset mismatch for FRigUnit_SetControlVisibility::Item");
static_assert(offsetof(FRigUnit_SetControlVisibility, Pattern) == 0x18, "Offset mismatch for FRigUnit_SetControlVisibility::Pattern");
static_assert(offsetof(FRigUnit_SetControlVisibility, bVisible) == 0x28, "Offset mismatch for FRigUnit_SetControlVisibility::bVisible");
static_assert(offsetof(FRigUnit_SetControlVisibility, CachedControlIndices) == 0x30, "Offset mismatch for FRigUnit_SetControlVisibility::CachedControlIndices");

// Size: 0x30 (Inherited: 0x20, Single: 0x10)
struct FRigUnit_SetCurveValue : FRigUnitMutable
{
    FName Curve; // 0x10 (Size: 0x4, Type: NameProperty)
    float Value; // 0x14 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement CachedCurveIndex; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetCurveValue) == 0x30, "Size mismatch for FRigUnit_SetCurveValue");
static_assert(offsetof(FRigUnit_SetCurveValue, Curve) == 0x10, "Offset mismatch for FRigUnit_SetCurveValue::Curve");
static_assert(offsetof(FRigUnit_SetCurveValue, Value) == 0x14, "Offset mismatch for FRigUnit_SetCurveValue::Value");
static_assert(offsetof(FRigUnit_SetCurveValue, CachedCurveIndex) == 0x18, "Offset mismatch for FRigUnit_SetCurveValue::CachedCurveIndex");

// Size: 0xc0 (Inherited: 0x20, Single: 0xa0)
struct FRigUnit_SetRelativeBoneTransform : FRigUnitMutable
{
    FName bone; // 0x10 (Size: 0x4, Type: NameProperty)
    FName Space; // 0x14 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    float Weight; // 0x80 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x84 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_85[0x3]; // 0x85 (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedBone; // 0x88 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedSpaceIndex; // 0xa0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetRelativeBoneTransform) == 0xc0, "Size mismatch for FRigUnit_SetRelativeBoneTransform");
static_assert(offsetof(FRigUnit_SetRelativeBoneTransform, bone) == 0x10, "Offset mismatch for FRigUnit_SetRelativeBoneTransform::bone");
static_assert(offsetof(FRigUnit_SetRelativeBoneTransform, Space) == 0x14, "Offset mismatch for FRigUnit_SetRelativeBoneTransform::Space");
static_assert(offsetof(FRigUnit_SetRelativeBoneTransform, Transform) == 0x20, "Offset mismatch for FRigUnit_SetRelativeBoneTransform::Transform");
static_assert(offsetof(FRigUnit_SetRelativeBoneTransform, Weight) == 0x80, "Offset mismatch for FRigUnit_SetRelativeBoneTransform::Weight");
static_assert(offsetof(FRigUnit_SetRelativeBoneTransform, bPropagateToChildren) == 0x84, "Offset mismatch for FRigUnit_SetRelativeBoneTransform::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetRelativeBoneTransform, CachedBone) == 0x88, "Offset mismatch for FRigUnit_SetRelativeBoneTransform::CachedBone");
static_assert(offsetof(FRigUnit_SetRelativeBoneTransform, CachedSpaceIndex) == 0xa0, "Offset mismatch for FRigUnit_SetRelativeBoneTransform::CachedSpaceIndex");

// Size: 0xd0 (Inherited: 0x20, Single: 0xb0)
struct FRigUnit_SetRelativeTransformForItem : FRigUnitMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey Parent; // 0x18 (Size: 0x8, Type: StructProperty)
    bool bParentInitial; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0xf]; // 0x21 (Size: 0xf, Type: PaddingProperty)
    FTransform Value; // 0x30 (Size: 0x60, Type: StructProperty)
    float Weight; // 0x90 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x94 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_95[0x3]; // 0x95 (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedChild; // 0x98 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent; // 0xb0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetRelativeTransformForItem) == 0xd0, "Size mismatch for FRigUnit_SetRelativeTransformForItem");
static_assert(offsetof(FRigUnit_SetRelativeTransformForItem, Child) == 0x10, "Offset mismatch for FRigUnit_SetRelativeTransformForItem::Child");
static_assert(offsetof(FRigUnit_SetRelativeTransformForItem, Parent) == 0x18, "Offset mismatch for FRigUnit_SetRelativeTransformForItem::Parent");
static_assert(offsetof(FRigUnit_SetRelativeTransformForItem, bParentInitial) == 0x20, "Offset mismatch for FRigUnit_SetRelativeTransformForItem::bParentInitial");
static_assert(offsetof(FRigUnit_SetRelativeTransformForItem, Value) == 0x30, "Offset mismatch for FRigUnit_SetRelativeTransformForItem::Value");
static_assert(offsetof(FRigUnit_SetRelativeTransformForItem, Weight) == 0x90, "Offset mismatch for FRigUnit_SetRelativeTransformForItem::Weight");
static_assert(offsetof(FRigUnit_SetRelativeTransformForItem, bPropagateToChildren) == 0x94, "Offset mismatch for FRigUnit_SetRelativeTransformForItem::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetRelativeTransformForItem, CachedChild) == 0x98, "Offset mismatch for FRigUnit_SetRelativeTransformForItem::CachedChild");
static_assert(offsetof(FRigUnit_SetRelativeTransformForItem, CachedParent) == 0xb0, "Offset mismatch for FRigUnit_SetRelativeTransformForItem::CachedParent");

// Size: 0x78 (Inherited: 0x20, Single: 0x58)
struct FRigUnit_SetRelativeTranslationForItem : FRigUnitMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey Parent; // 0x18 (Size: 0x8, Type: StructProperty)
    bool bParentInitial; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
    FVector Value; // 0x28 (Size: 0x18, Type: StructProperty)
    float Weight; // 0x40 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x44 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_45[0x3]; // 0x45 (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedChild; // 0x48 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent; // 0x60 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetRelativeTranslationForItem) == 0x78, "Size mismatch for FRigUnit_SetRelativeTranslationForItem");
static_assert(offsetof(FRigUnit_SetRelativeTranslationForItem, Child) == 0x10, "Offset mismatch for FRigUnit_SetRelativeTranslationForItem::Child");
static_assert(offsetof(FRigUnit_SetRelativeTranslationForItem, Parent) == 0x18, "Offset mismatch for FRigUnit_SetRelativeTranslationForItem::Parent");
static_assert(offsetof(FRigUnit_SetRelativeTranslationForItem, bParentInitial) == 0x20, "Offset mismatch for FRigUnit_SetRelativeTranslationForItem::bParentInitial");
static_assert(offsetof(FRigUnit_SetRelativeTranslationForItem, Value) == 0x28, "Offset mismatch for FRigUnit_SetRelativeTranslationForItem::Value");
static_assert(offsetof(FRigUnit_SetRelativeTranslationForItem, Weight) == 0x40, "Offset mismatch for FRigUnit_SetRelativeTranslationForItem::Weight");
static_assert(offsetof(FRigUnit_SetRelativeTranslationForItem, bPropagateToChildren) == 0x44, "Offset mismatch for FRigUnit_SetRelativeTranslationForItem::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetRelativeTranslationForItem, CachedChild) == 0x48, "Offset mismatch for FRigUnit_SetRelativeTranslationForItem::CachedChild");
static_assert(offsetof(FRigUnit_SetRelativeTranslationForItem, CachedParent) == 0x60, "Offset mismatch for FRigUnit_SetRelativeTranslationForItem::CachedParent");

// Size: 0x90 (Inherited: 0x20, Single: 0x70)
struct FRigUnit_SetRelativeRotationForItem : FRigUnitMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey Parent; // 0x18 (Size: 0x8, Type: StructProperty)
    bool bParentInitial; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0xf]; // 0x21 (Size: 0xf, Type: PaddingProperty)
    FQuat Value; // 0x30 (Size: 0x20, Type: StructProperty)
    float Weight; // 0x50 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x54 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_55[0x3]; // 0x55 (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedChild; // 0x58 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent; // 0x70 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SetRelativeRotationForItem) == 0x90, "Size mismatch for FRigUnit_SetRelativeRotationForItem");
static_assert(offsetof(FRigUnit_SetRelativeRotationForItem, Child) == 0x10, "Offset mismatch for FRigUnit_SetRelativeRotationForItem::Child");
static_assert(offsetof(FRigUnit_SetRelativeRotationForItem, Parent) == 0x18, "Offset mismatch for FRigUnit_SetRelativeRotationForItem::Parent");
static_assert(offsetof(FRigUnit_SetRelativeRotationForItem, bParentInitial) == 0x20, "Offset mismatch for FRigUnit_SetRelativeRotationForItem::bParentInitial");
static_assert(offsetof(FRigUnit_SetRelativeRotationForItem, Value) == 0x30, "Offset mismatch for FRigUnit_SetRelativeRotationForItem::Value");
static_assert(offsetof(FRigUnit_SetRelativeRotationForItem, Weight) == 0x50, "Offset mismatch for FRigUnit_SetRelativeRotationForItem::Weight");
static_assert(offsetof(FRigUnit_SetRelativeRotationForItem, bPropagateToChildren) == 0x54, "Offset mismatch for FRigUnit_SetRelativeRotationForItem::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetRelativeRotationForItem, CachedChild) == 0x58, "Offset mismatch for FRigUnit_SetRelativeRotationForItem::CachedChild");
static_assert(offsetof(FRigUnit_SetRelativeRotationForItem, CachedParent) == 0x70, "Offset mismatch for FRigUnit_SetRelativeRotationForItem::CachedParent");

// Size: 0x100 (Inherited: 0x20, Single: 0xe0)
struct FRigUnit_SetSpaceInitialTransform : FRigUnitMutable
{
    FName SpaceName; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform Result; // 0x80 (Size: 0x60, Type: StructProperty)
    uint8_t Space; // 0xe0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_e1[0x7]; // 0xe1 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedSpaceIndex; // 0xe8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetSpaceInitialTransform) == 0x100, "Size mismatch for FRigUnit_SetSpaceInitialTransform");
static_assert(offsetof(FRigUnit_SetSpaceInitialTransform, SpaceName) == 0x10, "Offset mismatch for FRigUnit_SetSpaceInitialTransform::SpaceName");
static_assert(offsetof(FRigUnit_SetSpaceInitialTransform, Transform) == 0x20, "Offset mismatch for FRigUnit_SetSpaceInitialTransform::Transform");
static_assert(offsetof(FRigUnit_SetSpaceInitialTransform, Result) == 0x80, "Offset mismatch for FRigUnit_SetSpaceInitialTransform::Result");
static_assert(offsetof(FRigUnit_SetSpaceInitialTransform, Space) == 0xe0, "Offset mismatch for FRigUnit_SetSpaceInitialTransform::Space");
static_assert(offsetof(FRigUnit_SetSpaceInitialTransform, CachedSpaceIndex) == 0xe8, "Offset mismatch for FRigUnit_SetSpaceInitialTransform::CachedSpaceIndex");

// Size: 0xa0 (Inherited: 0x20, Single: 0x80)
struct FRigUnit_SetSpaceTransform : FRigUnitMutable
{
    FName Space; // 0x10 (Size: 0x4, Type: NameProperty)
    float Weight; // 0x14 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t SpaceType; // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_81[0x7]; // 0x81 (Size: 0x7, Type: PaddingProperty)
    FCachedRigElement CachedSpaceIndex; // 0x88 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetSpaceTransform) == 0xa0, "Size mismatch for FRigUnit_SetSpaceTransform");
static_assert(offsetof(FRigUnit_SetSpaceTransform, Space) == 0x10, "Offset mismatch for FRigUnit_SetSpaceTransform::Space");
static_assert(offsetof(FRigUnit_SetSpaceTransform, Weight) == 0x14, "Offset mismatch for FRigUnit_SetSpaceTransform::Weight");
static_assert(offsetof(FRigUnit_SetSpaceTransform, Transform) == 0x20, "Offset mismatch for FRigUnit_SetSpaceTransform::Transform");
static_assert(offsetof(FRigUnit_SetSpaceTransform, SpaceType) == 0x80, "Offset mismatch for FRigUnit_SetSpaceTransform::SpaceType");
static_assert(offsetof(FRigUnit_SetSpaceTransform, CachedSpaceIndex) == 0x88, "Offset mismatch for FRigUnit_SetSpaceTransform::CachedSpaceIndex");

// Size: 0xa0 (Inherited: 0x20, Single: 0x80)
struct FRigUnit_SetTransform : FRigUnitMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Space; // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bInitial; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x6]; // 0x1a (Size: 0x6, Type: PaddingProperty)
    FTransform Value; // 0x20 (Size: 0x60, Type: StructProperty)
    float Weight; // 0x80 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x84 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_85[0x3]; // 0x85 (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x88 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetTransform) == 0xa0, "Size mismatch for FRigUnit_SetTransform");
static_assert(offsetof(FRigUnit_SetTransform, Item) == 0x10, "Offset mismatch for FRigUnit_SetTransform::Item");
static_assert(offsetof(FRigUnit_SetTransform, Space) == 0x18, "Offset mismatch for FRigUnit_SetTransform::Space");
static_assert(offsetof(FRigUnit_SetTransform, bInitial) == 0x19, "Offset mismatch for FRigUnit_SetTransform::bInitial");
static_assert(offsetof(FRigUnit_SetTransform, Value) == 0x20, "Offset mismatch for FRigUnit_SetTransform::Value");
static_assert(offsetof(FRigUnit_SetTransform, Weight) == 0x80, "Offset mismatch for FRigUnit_SetTransform::Weight");
static_assert(offsetof(FRigUnit_SetTransform, bPropagateToChildren) == 0x84, "Offset mismatch for FRigUnit_SetTransform::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetTransform, CachedIndex) == 0x88, "Offset mismatch for FRigUnit_SetTransform::CachedIndex");

// Size: 0x58 (Inherited: 0x20, Single: 0x38)
struct FRigUnit_SetTranslation : FRigUnitMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Space; // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bInitial; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x6]; // 0x1a (Size: 0x6, Type: PaddingProperty)
    FVector Value; // 0x20 (Size: 0x18, Type: StructProperty)
    float Weight; // 0x38 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x3c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3d[0x3]; // 0x3d (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x40 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetTranslation) == 0x58, "Size mismatch for FRigUnit_SetTranslation");
static_assert(offsetof(FRigUnit_SetTranslation, Item) == 0x10, "Offset mismatch for FRigUnit_SetTranslation::Item");
static_assert(offsetof(FRigUnit_SetTranslation, Space) == 0x18, "Offset mismatch for FRigUnit_SetTranslation::Space");
static_assert(offsetof(FRigUnit_SetTranslation, bInitial) == 0x19, "Offset mismatch for FRigUnit_SetTranslation::bInitial");
static_assert(offsetof(FRigUnit_SetTranslation, Value) == 0x20, "Offset mismatch for FRigUnit_SetTranslation::Value");
static_assert(offsetof(FRigUnit_SetTranslation, Weight) == 0x38, "Offset mismatch for FRigUnit_SetTranslation::Weight");
static_assert(offsetof(FRigUnit_SetTranslation, bPropagateToChildren) == 0x3c, "Offset mismatch for FRigUnit_SetTranslation::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetTranslation, CachedIndex) == 0x40, "Offset mismatch for FRigUnit_SetTranslation::CachedIndex");

// Size: 0x60 (Inherited: 0x20, Single: 0x40)
struct FRigUnit_SetRotation : FRigUnitMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Space; // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bInitial; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x6]; // 0x1a (Size: 0x6, Type: PaddingProperty)
    FQuat Value; // 0x20 (Size: 0x20, Type: StructProperty)
    float Weight; // 0x40 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x44 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_45[0x3]; // 0x45 (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x48 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetRotation) == 0x60, "Size mismatch for FRigUnit_SetRotation");
static_assert(offsetof(FRigUnit_SetRotation, Item) == 0x10, "Offset mismatch for FRigUnit_SetRotation::Item");
static_assert(offsetof(FRigUnit_SetRotation, Space) == 0x18, "Offset mismatch for FRigUnit_SetRotation::Space");
static_assert(offsetof(FRigUnit_SetRotation, bInitial) == 0x19, "Offset mismatch for FRigUnit_SetRotation::bInitial");
static_assert(offsetof(FRigUnit_SetRotation, Value) == 0x20, "Offset mismatch for FRigUnit_SetRotation::Value");
static_assert(offsetof(FRigUnit_SetRotation, Weight) == 0x40, "Offset mismatch for FRigUnit_SetRotation::Weight");
static_assert(offsetof(FRigUnit_SetRotation, bPropagateToChildren) == 0x44, "Offset mismatch for FRigUnit_SetRotation::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetRotation, CachedIndex) == 0x48, "Offset mismatch for FRigUnit_SetRotation::CachedIndex");

// Size: 0x58 (Inherited: 0x20, Single: 0x38)
struct FRigUnit_SetScale : FRigUnitMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Space; // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bInitial; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x6]; // 0x1a (Size: 0x6, Type: PaddingProperty)
    FVector Scale; // 0x20 (Size: 0x18, Type: StructProperty)
    float Weight; // 0x38 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x3c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3d[0x3]; // 0x3d (Size: 0x3, Type: PaddingProperty)
    FCachedRigElement CachedIndex; // 0x40 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetScale) == 0x58, "Size mismatch for FRigUnit_SetScale");
static_assert(offsetof(FRigUnit_SetScale, Item) == 0x10, "Offset mismatch for FRigUnit_SetScale::Item");
static_assert(offsetof(FRigUnit_SetScale, Space) == 0x18, "Offset mismatch for FRigUnit_SetScale::Space");
static_assert(offsetof(FRigUnit_SetScale, bInitial) == 0x19, "Offset mismatch for FRigUnit_SetScale::bInitial");
static_assert(offsetof(FRigUnit_SetScale, Scale) == 0x20, "Offset mismatch for FRigUnit_SetScale::Scale");
static_assert(offsetof(FRigUnit_SetScale, Weight) == 0x38, "Offset mismatch for FRigUnit_SetScale::Weight");
static_assert(offsetof(FRigUnit_SetScale, bPropagateToChildren) == 0x3c, "Offset mismatch for FRigUnit_SetScale::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetScale, CachedIndex) == 0x40, "Offset mismatch for FRigUnit_SetScale::CachedIndex");

// Size: 0x50 (Inherited: 0x20, Single: 0x30)
struct FRigUnit_SetTransformArray : FRigUnitMutable
{
    FRigElementKeyCollection Items; // 0x10 (Size: 0x10, Type: StructProperty)
    uint8_t Space; // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bInitial; // 0x21 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_22[0x6]; // 0x22 (Size: 0x6, Type: PaddingProperty)
    TArray<FTransform> Transforms; // 0x28 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x38 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x3c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3d[0x3]; // 0x3d (Size: 0x3, Type: PaddingProperty)
    TArray<FCachedRigElement> CachedIndex; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_SetTransformArray) == 0x50, "Size mismatch for FRigUnit_SetTransformArray");
static_assert(offsetof(FRigUnit_SetTransformArray, Items) == 0x10, "Offset mismatch for FRigUnit_SetTransformArray::Items");
static_assert(offsetof(FRigUnit_SetTransformArray, Space) == 0x20, "Offset mismatch for FRigUnit_SetTransformArray::Space");
static_assert(offsetof(FRigUnit_SetTransformArray, bInitial) == 0x21, "Offset mismatch for FRigUnit_SetTransformArray::bInitial");
static_assert(offsetof(FRigUnit_SetTransformArray, Transforms) == 0x28, "Offset mismatch for FRigUnit_SetTransformArray::Transforms");
static_assert(offsetof(FRigUnit_SetTransformArray, Weight) == 0x38, "Offset mismatch for FRigUnit_SetTransformArray::Weight");
static_assert(offsetof(FRigUnit_SetTransformArray, bPropagateToChildren) == 0x3c, "Offset mismatch for FRigUnit_SetTransformArray::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetTransformArray, CachedIndex) == 0x40, "Offset mismatch for FRigUnit_SetTransformArray::CachedIndex");

// Size: 0x50 (Inherited: 0x20, Single: 0x30)
struct FRigUnit_SetTransformItemArray : FRigUnitMutable
{
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
    uint8_t Space; // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bInitial; // 0x21 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_22[0x6]; // 0x22 (Size: 0x6, Type: PaddingProperty)
    TArray<FTransform> Transforms; // 0x28 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x38 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x3c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3d[0x3]; // 0x3d (Size: 0x3, Type: PaddingProperty)
    TArray<FCachedRigElement> CachedIndex; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_SetTransformItemArray) == 0x50, "Size mismatch for FRigUnit_SetTransformItemArray");
static_assert(offsetof(FRigUnit_SetTransformItemArray, Items) == 0x10, "Offset mismatch for FRigUnit_SetTransformItemArray::Items");
static_assert(offsetof(FRigUnit_SetTransformItemArray, Space) == 0x20, "Offset mismatch for FRigUnit_SetTransformItemArray::Space");
static_assert(offsetof(FRigUnit_SetTransformItemArray, bInitial) == 0x21, "Offset mismatch for FRigUnit_SetTransformItemArray::bInitial");
static_assert(offsetof(FRigUnit_SetTransformItemArray, Transforms) == 0x28, "Offset mismatch for FRigUnit_SetTransformItemArray::Transforms");
static_assert(offsetof(FRigUnit_SetTransformItemArray, Weight) == 0x38, "Offset mismatch for FRigUnit_SetTransformItemArray::Weight");
static_assert(offsetof(FRigUnit_SetTransformItemArray, bPropagateToChildren) == 0x3c, "Offset mismatch for FRigUnit_SetTransformItemArray::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SetTransformItemArray, CachedIndex) == 0x40, "Offset mismatch for FRigUnit_SetTransformItemArray::CachedIndex");

// Size: 0x30 (Inherited: 0x20, Single: 0x10)
struct FRigUnit_UnsetCurveValue : FRigUnitMutable
{
    FName Curve; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FCachedRigElement CachedCurveIndex; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_UnsetCurveValue) == 0x30, "Size mismatch for FRigUnit_UnsetCurveValue");
static_assert(offsetof(FRigUnit_UnsetCurveValue, Curve) == 0x10, "Offset mismatch for FRigUnit_UnsetCurveValue::Curve");
static_assert(offsetof(FRigUnit_UnsetCurveValue, CachedCurveIndex) == 0x18, "Offset mismatch for FRigUnit_UnsetCurveValue::CachedCurveIndex");

// Size: 0xd0 (Inherited: 0x10, Single: 0xc0)
struct FRigUnit_ToWorldSpace_Transform : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform Value; // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform World; // 0x70 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ToWorldSpace_Transform) == 0xd0, "Size mismatch for FRigUnit_ToWorldSpace_Transform");
static_assert(offsetof(FRigUnit_ToWorldSpace_Transform, Value) == 0x10, "Offset mismatch for FRigUnit_ToWorldSpace_Transform::Value");
static_assert(offsetof(FRigUnit_ToWorldSpace_Transform, World) == 0x70, "Offset mismatch for FRigUnit_ToWorldSpace_Transform::World");

// Size: 0xd0 (Inherited: 0x10, Single: 0xc0)
struct FRigUnit_ToRigSpace_Transform : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform Value; // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform Global; // 0x70 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ToRigSpace_Transform) == 0xd0, "Size mismatch for FRigUnit_ToRigSpace_Transform");
static_assert(offsetof(FRigUnit_ToRigSpace_Transform, Value) == 0x10, "Offset mismatch for FRigUnit_ToRigSpace_Transform::Value");
static_assert(offsetof(FRigUnit_ToRigSpace_Transform, Global) == 0x70, "Offset mismatch for FRigUnit_ToRigSpace_Transform::Global");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FRigUnit_ToWorldSpace_Location : FRigUnit
{
    FVector Value; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector World; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ToWorldSpace_Location) == 0x38, "Size mismatch for FRigUnit_ToWorldSpace_Location");
static_assert(offsetof(FRigUnit_ToWorldSpace_Location, Value) == 0x8, "Offset mismatch for FRigUnit_ToWorldSpace_Location::Value");
static_assert(offsetof(FRigUnit_ToWorldSpace_Location, World) == 0x20, "Offset mismatch for FRigUnit_ToWorldSpace_Location::World");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FRigUnit_ToRigSpace_Location : FRigUnit
{
    FVector Value; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Global; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ToRigSpace_Location) == 0x38, "Size mismatch for FRigUnit_ToRigSpace_Location");
static_assert(offsetof(FRigUnit_ToRigSpace_Location, Value) == 0x8, "Offset mismatch for FRigUnit_ToRigSpace_Location::Value");
static_assert(offsetof(FRigUnit_ToRigSpace_Location, Global) == 0x20, "Offset mismatch for FRigUnit_ToRigSpace_Location::Global");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FRigUnit_ToWorldSpace_Rotation : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FQuat Value; // 0x10 (Size: 0x20, Type: StructProperty)
    FQuat World; // 0x30 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ToWorldSpace_Rotation) == 0x50, "Size mismatch for FRigUnit_ToWorldSpace_Rotation");
static_assert(offsetof(FRigUnit_ToWorldSpace_Rotation, Value) == 0x10, "Offset mismatch for FRigUnit_ToWorldSpace_Rotation::Value");
static_assert(offsetof(FRigUnit_ToWorldSpace_Rotation, World) == 0x30, "Offset mismatch for FRigUnit_ToWorldSpace_Rotation::World");

// Size: 0x50 (Inherited: 0x10, Single: 0x40)
struct FRigUnit_ToRigSpace_Rotation : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FQuat Value; // 0x10 (Size: 0x20, Type: StructProperty)
    FQuat Global; // 0x30 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ToRigSpace_Rotation) == 0x50, "Size mismatch for FRigUnit_ToRigSpace_Rotation");
static_assert(offsetof(FRigUnit_ToRigSpace_Rotation, Value) == 0x10, "Offset mismatch for FRigUnit_ToRigSpace_Rotation::Value");
static_assert(offsetof(FRigUnit_ToRigSpace_Rotation, Global) == 0x30, "Offset mismatch for FRigUnit_ToRigSpace_Rotation::Global");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FRigUnit_BoneHarmonics_BoneTarget
{
    FName bone; // 0x0 (Size: 0x4, Type: NameProperty)
    float Ratio; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_BoneHarmonics_BoneTarget) == 0x8, "Size mismatch for FRigUnit_BoneHarmonics_BoneTarget");
static_assert(offsetof(FRigUnit_BoneHarmonics_BoneTarget, bone) == 0x0, "Offset mismatch for FRigUnit_BoneHarmonics_BoneTarget::bone");
static_assert(offsetof(FRigUnit_BoneHarmonics_BoneTarget, Ratio) == 0x4, "Offset mismatch for FRigUnit_BoneHarmonics_BoneTarget::Ratio");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FRigUnit_Harmonics_TargetItem
{
    FRigElementKey Item; // 0x0 (Size: 0x8, Type: StructProperty)
    float Ratio; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_Harmonics_TargetItem) == 0xc, "Size mismatch for FRigUnit_Harmonics_TargetItem");
static_assert(offsetof(FRigUnit_Harmonics_TargetItem, Item) == 0x0, "Offset mismatch for FRigUnit_Harmonics_TargetItem::Item");
static_assert(offsetof(FRigUnit_Harmonics_TargetItem, Ratio) == 0x8, "Offset mismatch for FRigUnit_Harmonics_TargetItem::Ratio");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FRigUnit_BoneHarmonics_WorkData
{
    TArray<FCachedRigElement> CachedItems; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FVector WaveTime; // 0x10 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_BoneHarmonics_WorkData) == 0x28, "Size mismatch for FRigUnit_BoneHarmonics_WorkData");
static_assert(offsetof(FRigUnit_BoneHarmonics_WorkData, CachedItems) == 0x0, "Offset mismatch for FRigUnit_BoneHarmonics_WorkData::CachedItems");
static_assert(offsetof(FRigUnit_BoneHarmonics_WorkData, WaveTime) == 0x10, "Offset mismatch for FRigUnit_BoneHarmonics_WorkData::WaveTime");

// Size: 0xd0 (Inherited: 0x30, Single: 0xa0)
struct FRigUnit_BoneHarmonics : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigUnit_BoneHarmonics_BoneTarget> Bones; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FVector WaveSpeed; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector WaveFrequency; // 0x38 (Size: 0x18, Type: StructProperty)
    FVector WaveAmplitude; // 0x50 (Size: 0x18, Type: StructProperty)
    FVector WaveOffset; // 0x68 (Size: 0x18, Type: StructProperty)
    FVector WaveNoise; // 0x80 (Size: 0x18, Type: StructProperty)
    uint8_t WaveEase; // 0x98 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_99[0x3]; // 0x99 (Size: 0x3, Type: PaddingProperty)
    float WaveMinimum; // 0x9c (Size: 0x4, Type: FloatProperty)
    float WaveMaximum; // 0xa0 (Size: 0x4, Type: FloatProperty)
    uint8_t RotationOrder; // 0xa4 (Size: 0x1, Type: EnumProperty)
    bool bPropagateToChildren; // 0xa5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a6[0x2]; // 0xa6 (Size: 0x2, Type: PaddingProperty)
    FRigUnit_BoneHarmonics_WorkData WorkData; // 0xa8 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_BoneHarmonics) == 0xd0, "Size mismatch for FRigUnit_BoneHarmonics");
static_assert(offsetof(FRigUnit_BoneHarmonics, Bones) == 0x10, "Offset mismatch for FRigUnit_BoneHarmonics::Bones");
static_assert(offsetof(FRigUnit_BoneHarmonics, WaveSpeed) == 0x20, "Offset mismatch for FRigUnit_BoneHarmonics::WaveSpeed");
static_assert(offsetof(FRigUnit_BoneHarmonics, WaveFrequency) == 0x38, "Offset mismatch for FRigUnit_BoneHarmonics::WaveFrequency");
static_assert(offsetof(FRigUnit_BoneHarmonics, WaveAmplitude) == 0x50, "Offset mismatch for FRigUnit_BoneHarmonics::WaveAmplitude");
static_assert(offsetof(FRigUnit_BoneHarmonics, WaveOffset) == 0x68, "Offset mismatch for FRigUnit_BoneHarmonics::WaveOffset");
static_assert(offsetof(FRigUnit_BoneHarmonics, WaveNoise) == 0x80, "Offset mismatch for FRigUnit_BoneHarmonics::WaveNoise");
static_assert(offsetof(FRigUnit_BoneHarmonics, WaveEase) == 0x98, "Offset mismatch for FRigUnit_BoneHarmonics::WaveEase");
static_assert(offsetof(FRigUnit_BoneHarmonics, WaveMinimum) == 0x9c, "Offset mismatch for FRigUnit_BoneHarmonics::WaveMinimum");
static_assert(offsetof(FRigUnit_BoneHarmonics, WaveMaximum) == 0xa0, "Offset mismatch for FRigUnit_BoneHarmonics::WaveMaximum");
static_assert(offsetof(FRigUnit_BoneHarmonics, RotationOrder) == 0xa4, "Offset mismatch for FRigUnit_BoneHarmonics::RotationOrder");
static_assert(offsetof(FRigUnit_BoneHarmonics, bPropagateToChildren) == 0xa5, "Offset mismatch for FRigUnit_BoneHarmonics::bPropagateToChildren");
static_assert(offsetof(FRigUnit_BoneHarmonics, WorkData) == 0xa8, "Offset mismatch for FRigUnit_BoneHarmonics::WorkData");

// Size: 0xd0 (Inherited: 0x30, Single: 0xa0)
struct FRigUnit_ItemHarmonics : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigUnit_Harmonics_TargetItem> Targets; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FVector WaveSpeed; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector WaveFrequency; // 0x38 (Size: 0x18, Type: StructProperty)
    FVector WaveAmplitude; // 0x50 (Size: 0x18, Type: StructProperty)
    FVector WaveOffset; // 0x68 (Size: 0x18, Type: StructProperty)
    FVector WaveNoise; // 0x80 (Size: 0x18, Type: StructProperty)
    uint8_t WaveEase; // 0x98 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_99[0x3]; // 0x99 (Size: 0x3, Type: PaddingProperty)
    float WaveMinimum; // 0x9c (Size: 0x4, Type: FloatProperty)
    float WaveMaximum; // 0xa0 (Size: 0x4, Type: FloatProperty)
    uint8_t RotationOrder; // 0xa4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a5[0x3]; // 0xa5 (Size: 0x3, Type: PaddingProperty)
    FRigUnit_BoneHarmonics_WorkData WorkData; // 0xa8 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ItemHarmonics) == 0xd0, "Size mismatch for FRigUnit_ItemHarmonics");
static_assert(offsetof(FRigUnit_ItemHarmonics, Targets) == 0x10, "Offset mismatch for FRigUnit_ItemHarmonics::Targets");
static_assert(offsetof(FRigUnit_ItemHarmonics, WaveSpeed) == 0x20, "Offset mismatch for FRigUnit_ItemHarmonics::WaveSpeed");
static_assert(offsetof(FRigUnit_ItemHarmonics, WaveFrequency) == 0x38, "Offset mismatch for FRigUnit_ItemHarmonics::WaveFrequency");
static_assert(offsetof(FRigUnit_ItemHarmonics, WaveAmplitude) == 0x50, "Offset mismatch for FRigUnit_ItemHarmonics::WaveAmplitude");
static_assert(offsetof(FRigUnit_ItemHarmonics, WaveOffset) == 0x68, "Offset mismatch for FRigUnit_ItemHarmonics::WaveOffset");
static_assert(offsetof(FRigUnit_ItemHarmonics, WaveNoise) == 0x80, "Offset mismatch for FRigUnit_ItemHarmonics::WaveNoise");
static_assert(offsetof(FRigUnit_ItemHarmonics, WaveEase) == 0x98, "Offset mismatch for FRigUnit_ItemHarmonics::WaveEase");
static_assert(offsetof(FRigUnit_ItemHarmonics, WaveMinimum) == 0x9c, "Offset mismatch for FRigUnit_ItemHarmonics::WaveMinimum");
static_assert(offsetof(FRigUnit_ItemHarmonics, WaveMaximum) == 0xa0, "Offset mismatch for FRigUnit_ItemHarmonics::WaveMaximum");
static_assert(offsetof(FRigUnit_ItemHarmonics, RotationOrder) == 0xa4, "Offset mismatch for FRigUnit_ItemHarmonics::RotationOrder");
static_assert(offsetof(FRigUnit_ItemHarmonics, WorkData) == 0xa8, "Offset mismatch for FRigUnit_ItemHarmonics::WorkData");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FRigUnit_ChainHarmonics_Reach
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FVector ReachTarget; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector ReachAxis; // 0x20 (Size: 0x18, Type: StructProperty)
    float ReachMinimum; // 0x38 (Size: 0x4, Type: FloatProperty)
    float ReachMaximum; // 0x3c (Size: 0x4, Type: FloatProperty)
    uint8_t ReachEase; // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ChainHarmonics_Reach) == 0x48, "Size mismatch for FRigUnit_ChainHarmonics_Reach");
static_assert(offsetof(FRigUnit_ChainHarmonics_Reach, bEnabled) == 0x0, "Offset mismatch for FRigUnit_ChainHarmonics_Reach::bEnabled");
static_assert(offsetof(FRigUnit_ChainHarmonics_Reach, ReachTarget) == 0x8, "Offset mismatch for FRigUnit_ChainHarmonics_Reach::ReachTarget");
static_assert(offsetof(FRigUnit_ChainHarmonics_Reach, ReachAxis) == 0x20, "Offset mismatch for FRigUnit_ChainHarmonics_Reach::ReachAxis");
static_assert(offsetof(FRigUnit_ChainHarmonics_Reach, ReachMinimum) == 0x38, "Offset mismatch for FRigUnit_ChainHarmonics_Reach::ReachMinimum");
static_assert(offsetof(FRigUnit_ChainHarmonics_Reach, ReachMaximum) == 0x3c, "Offset mismatch for FRigUnit_ChainHarmonics_Reach::ReachMaximum");
static_assert(offsetof(FRigUnit_ChainHarmonics_Reach, ReachEase) == 0x40, "Offset mismatch for FRigUnit_ChainHarmonics_Reach::ReachEase");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FRigUnit_ChainHarmonics_Wave
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FVector WaveFrequency; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector WaveAmplitude; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector WaveOffset; // 0x38 (Size: 0x18, Type: StructProperty)
    FVector WaveNoise; // 0x50 (Size: 0x18, Type: StructProperty)
    float WaveMinimum; // 0x68 (Size: 0x4, Type: FloatProperty)
    float WaveMaximum; // 0x6c (Size: 0x4, Type: FloatProperty)
    uint8_t WaveEase; // 0x70 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ChainHarmonics_Wave) == 0x78, "Size mismatch for FRigUnit_ChainHarmonics_Wave");
static_assert(offsetof(FRigUnit_ChainHarmonics_Wave, bEnabled) == 0x0, "Offset mismatch for FRigUnit_ChainHarmonics_Wave::bEnabled");
static_assert(offsetof(FRigUnit_ChainHarmonics_Wave, WaveFrequency) == 0x8, "Offset mismatch for FRigUnit_ChainHarmonics_Wave::WaveFrequency");
static_assert(offsetof(FRigUnit_ChainHarmonics_Wave, WaveAmplitude) == 0x20, "Offset mismatch for FRigUnit_ChainHarmonics_Wave::WaveAmplitude");
static_assert(offsetof(FRigUnit_ChainHarmonics_Wave, WaveOffset) == 0x38, "Offset mismatch for FRigUnit_ChainHarmonics_Wave::WaveOffset");
static_assert(offsetof(FRigUnit_ChainHarmonics_Wave, WaveNoise) == 0x50, "Offset mismatch for FRigUnit_ChainHarmonics_Wave::WaveNoise");
static_assert(offsetof(FRigUnit_ChainHarmonics_Wave, WaveMinimum) == 0x68, "Offset mismatch for FRigUnit_ChainHarmonics_Wave::WaveMinimum");
static_assert(offsetof(FRigUnit_ChainHarmonics_Wave, WaveMaximum) == 0x6c, "Offset mismatch for FRigUnit_ChainHarmonics_Wave::WaveMaximum");
static_assert(offsetof(FRigUnit_ChainHarmonics_Wave, WaveEase) == 0x70, "Offset mismatch for FRigUnit_ChainHarmonics_Wave::WaveEase");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FRigUnit_ChainHarmonics_Pendulum
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float PendulumStiffness; // 0x4 (Size: 0x4, Type: FloatProperty)
    FVector PendulumGravity; // 0x8 (Size: 0x18, Type: StructProperty)
    float PendulumBlend; // 0x20 (Size: 0x4, Type: FloatProperty)
    float PendulumDrag; // 0x24 (Size: 0x4, Type: FloatProperty)
    float PendulumMinimum; // 0x28 (Size: 0x4, Type: FloatProperty)
    float PendulumMaximum; // 0x2c (Size: 0x4, Type: FloatProperty)
    uint8_t PendulumEase; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    FVector UnwindAxis; // 0x38 (Size: 0x18, Type: StructProperty)
    float UnwindMinimum; // 0x50 (Size: 0x4, Type: FloatProperty)
    float UnwindMaximum; // 0x54 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_ChainHarmonics_Pendulum) == 0x58, "Size mismatch for FRigUnit_ChainHarmonics_Pendulum");
static_assert(offsetof(FRigUnit_ChainHarmonics_Pendulum, bEnabled) == 0x0, "Offset mismatch for FRigUnit_ChainHarmonics_Pendulum::bEnabled");
static_assert(offsetof(FRigUnit_ChainHarmonics_Pendulum, PendulumStiffness) == 0x4, "Offset mismatch for FRigUnit_ChainHarmonics_Pendulum::PendulumStiffness");
static_assert(offsetof(FRigUnit_ChainHarmonics_Pendulum, PendulumGravity) == 0x8, "Offset mismatch for FRigUnit_ChainHarmonics_Pendulum::PendulumGravity");
static_assert(offsetof(FRigUnit_ChainHarmonics_Pendulum, PendulumBlend) == 0x20, "Offset mismatch for FRigUnit_ChainHarmonics_Pendulum::PendulumBlend");
static_assert(offsetof(FRigUnit_ChainHarmonics_Pendulum, PendulumDrag) == 0x24, "Offset mismatch for FRigUnit_ChainHarmonics_Pendulum::PendulumDrag");
static_assert(offsetof(FRigUnit_ChainHarmonics_Pendulum, PendulumMinimum) == 0x28, "Offset mismatch for FRigUnit_ChainHarmonics_Pendulum::PendulumMinimum");
static_assert(offsetof(FRigUnit_ChainHarmonics_Pendulum, PendulumMaximum) == 0x2c, "Offset mismatch for FRigUnit_ChainHarmonics_Pendulum::PendulumMaximum");
static_assert(offsetof(FRigUnit_ChainHarmonics_Pendulum, PendulumEase) == 0x30, "Offset mismatch for FRigUnit_ChainHarmonics_Pendulum::PendulumEase");
static_assert(offsetof(FRigUnit_ChainHarmonics_Pendulum, UnwindAxis) == 0x38, "Offset mismatch for FRigUnit_ChainHarmonics_Pendulum::UnwindAxis");
static_assert(offsetof(FRigUnit_ChainHarmonics_Pendulum, UnwindMinimum) == 0x50, "Offset mismatch for FRigUnit_ChainHarmonics_Pendulum::UnwindMinimum");
static_assert(offsetof(FRigUnit_ChainHarmonics_Pendulum, UnwindMaximum) == 0x54, "Offset mismatch for FRigUnit_ChainHarmonics_Pendulum::UnwindMaximum");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FRigUnit_ChainHarmonics_WorkData
{
    FVector time; // 0x0 (Size: 0x18, Type: StructProperty)
    TArray<FCachedRigElement> Items; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<float> Ratio; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> LocalTip; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> PendulumTip; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> PendulumPosition; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> PendulumVelocity; // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> HierarchyLine; // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> VelocityLines; // 0x88 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_ChainHarmonics_WorkData) == 0x98, "Size mismatch for FRigUnit_ChainHarmonics_WorkData");
static_assert(offsetof(FRigUnit_ChainHarmonics_WorkData, time) == 0x0, "Offset mismatch for FRigUnit_ChainHarmonics_WorkData::time");
static_assert(offsetof(FRigUnit_ChainHarmonics_WorkData, Items) == 0x18, "Offset mismatch for FRigUnit_ChainHarmonics_WorkData::Items");
static_assert(offsetof(FRigUnit_ChainHarmonics_WorkData, Ratio) == 0x28, "Offset mismatch for FRigUnit_ChainHarmonics_WorkData::Ratio");
static_assert(offsetof(FRigUnit_ChainHarmonics_WorkData, LocalTip) == 0x38, "Offset mismatch for FRigUnit_ChainHarmonics_WorkData::LocalTip");
static_assert(offsetof(FRigUnit_ChainHarmonics_WorkData, PendulumTip) == 0x48, "Offset mismatch for FRigUnit_ChainHarmonics_WorkData::PendulumTip");
static_assert(offsetof(FRigUnit_ChainHarmonics_WorkData, PendulumPosition) == 0x58, "Offset mismatch for FRigUnit_ChainHarmonics_WorkData::PendulumPosition");
static_assert(offsetof(FRigUnit_ChainHarmonics_WorkData, PendulumVelocity) == 0x68, "Offset mismatch for FRigUnit_ChainHarmonics_WorkData::PendulumVelocity");
static_assert(offsetof(FRigUnit_ChainHarmonics_WorkData, HierarchyLine) == 0x78, "Offset mismatch for FRigUnit_ChainHarmonics_WorkData::HierarchyLine");
static_assert(offsetof(FRigUnit_ChainHarmonics_WorkData, VelocityLines) == 0x88, "Offset mismatch for FRigUnit_ChainHarmonics_WorkData::VelocityLines");

// Size: 0x2e0 (Inherited: 0x30, Single: 0x2b0)
struct FRigUnit_ChainHarmonics : FRigUnit_HighlevelBaseMutable
{
    FName ChainRoot; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FVector Speed; // 0x18 (Size: 0x18, Type: StructProperty)
    FRigUnit_ChainHarmonics_Reach Reach; // 0x30 (Size: 0x48, Type: StructProperty)
    FRigUnit_ChainHarmonics_Wave Wave; // 0x78 (Size: 0x78, Type: StructProperty)
    FRuntimeFloatCurve WaveCurve; // 0xf0 (Size: 0x88, Type: StructProperty)
    FRigUnit_ChainHarmonics_Pendulum Pendulum; // 0x178 (Size: 0x58, Type: StructProperty)
    bool bDrawDebug; // 0x1d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d1[0xf]; // 0x1d1 (Size: 0xf, Type: PaddingProperty)
    FTransform DrawWorldOffset; // 0x1e0 (Size: 0x60, Type: StructProperty)
    FRigUnit_ChainHarmonics_WorkData WorkData; // 0x240 (Size: 0x98, Type: StructProperty)
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ChainHarmonics) == 0x2e0, "Size mismatch for FRigUnit_ChainHarmonics");
static_assert(offsetof(FRigUnit_ChainHarmonics, ChainRoot) == 0x10, "Offset mismatch for FRigUnit_ChainHarmonics::ChainRoot");
static_assert(offsetof(FRigUnit_ChainHarmonics, Speed) == 0x18, "Offset mismatch for FRigUnit_ChainHarmonics::Speed");
static_assert(offsetof(FRigUnit_ChainHarmonics, Reach) == 0x30, "Offset mismatch for FRigUnit_ChainHarmonics::Reach");
static_assert(offsetof(FRigUnit_ChainHarmonics, Wave) == 0x78, "Offset mismatch for FRigUnit_ChainHarmonics::Wave");
static_assert(offsetof(FRigUnit_ChainHarmonics, WaveCurve) == 0xf0, "Offset mismatch for FRigUnit_ChainHarmonics::WaveCurve");
static_assert(offsetof(FRigUnit_ChainHarmonics, Pendulum) == 0x178, "Offset mismatch for FRigUnit_ChainHarmonics::Pendulum");
static_assert(offsetof(FRigUnit_ChainHarmonics, bDrawDebug) == 0x1d0, "Offset mismatch for FRigUnit_ChainHarmonics::bDrawDebug");
static_assert(offsetof(FRigUnit_ChainHarmonics, DrawWorldOffset) == 0x1e0, "Offset mismatch for FRigUnit_ChainHarmonics::DrawWorldOffset");
static_assert(offsetof(FRigUnit_ChainHarmonics, WorkData) == 0x240, "Offset mismatch for FRigUnit_ChainHarmonics::WorkData");

// Size: 0x2e0 (Inherited: 0x30, Single: 0x2b0)
struct FRigUnit_ChainHarmonicsPerItem : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey ChainRoot; // 0x10 (Size: 0x8, Type: StructProperty)
    FVector Speed; // 0x18 (Size: 0x18, Type: StructProperty)
    FRigUnit_ChainHarmonics_Reach Reach; // 0x30 (Size: 0x48, Type: StructProperty)
    FRigUnit_ChainHarmonics_Wave Wave; // 0x78 (Size: 0x78, Type: StructProperty)
    FRuntimeFloatCurve WaveCurve; // 0xf0 (Size: 0x88, Type: StructProperty)
    FRigUnit_ChainHarmonics_Pendulum Pendulum; // 0x178 (Size: 0x58, Type: StructProperty)
    bool bDrawDebug; // 0x1d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d1[0xf]; // 0x1d1 (Size: 0xf, Type: PaddingProperty)
    FTransform DrawWorldOffset; // 0x1e0 (Size: 0x60, Type: StructProperty)
    FRigUnit_ChainHarmonics_WorkData WorkData; // 0x240 (Size: 0x98, Type: StructProperty)
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ChainHarmonicsPerItem) == 0x2e0, "Size mismatch for FRigUnit_ChainHarmonicsPerItem");
static_assert(offsetof(FRigUnit_ChainHarmonicsPerItem, ChainRoot) == 0x10, "Offset mismatch for FRigUnit_ChainHarmonicsPerItem::ChainRoot");
static_assert(offsetof(FRigUnit_ChainHarmonicsPerItem, Speed) == 0x18, "Offset mismatch for FRigUnit_ChainHarmonicsPerItem::Speed");
static_assert(offsetof(FRigUnit_ChainHarmonicsPerItem, Reach) == 0x30, "Offset mismatch for FRigUnit_ChainHarmonicsPerItem::Reach");
static_assert(offsetof(FRigUnit_ChainHarmonicsPerItem, Wave) == 0x78, "Offset mismatch for FRigUnit_ChainHarmonicsPerItem::Wave");
static_assert(offsetof(FRigUnit_ChainHarmonicsPerItem, WaveCurve) == 0xf0, "Offset mismatch for FRigUnit_ChainHarmonicsPerItem::WaveCurve");
static_assert(offsetof(FRigUnit_ChainHarmonicsPerItem, Pendulum) == 0x178, "Offset mismatch for FRigUnit_ChainHarmonicsPerItem::Pendulum");
static_assert(offsetof(FRigUnit_ChainHarmonicsPerItem, bDrawDebug) == 0x1d0, "Offset mismatch for FRigUnit_ChainHarmonicsPerItem::bDrawDebug");
static_assert(offsetof(FRigUnit_ChainHarmonicsPerItem, DrawWorldOffset) == 0x1e0, "Offset mismatch for FRigUnit_ChainHarmonicsPerItem::DrawWorldOffset");
static_assert(offsetof(FRigUnit_ChainHarmonicsPerItem, WorkData) == 0x240, "Offset mismatch for FRigUnit_ChainHarmonicsPerItem::WorkData");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FRigUnit_AimBone_Target
{
    float Weight; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector Axis; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Target; // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t Kind; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    FName Space; // 0x3c (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FRigUnit_AimBone_Target) == 0x40, "Size mismatch for FRigUnit_AimBone_Target");
static_assert(offsetof(FRigUnit_AimBone_Target, Weight) == 0x0, "Offset mismatch for FRigUnit_AimBone_Target::Weight");
static_assert(offsetof(FRigUnit_AimBone_Target, Axis) == 0x8, "Offset mismatch for FRigUnit_AimBone_Target::Axis");
static_assert(offsetof(FRigUnit_AimBone_Target, Target) == 0x20, "Offset mismatch for FRigUnit_AimBone_Target::Target");
static_assert(offsetof(FRigUnit_AimBone_Target, Kind) == 0x38, "Offset mismatch for FRigUnit_AimBone_Target::Kind");
static_assert(offsetof(FRigUnit_AimBone_Target, Space) == 0x3c, "Offset mismatch for FRigUnit_AimBone_Target::Space");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FRigUnit_AimItem_Target
{
    float Weight; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector Axis; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Target; // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t Kind; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    FRigElementKey Space; // 0x3c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_AimItem_Target) == 0x48, "Size mismatch for FRigUnit_AimItem_Target");
static_assert(offsetof(FRigUnit_AimItem_Target, Weight) == 0x0, "Offset mismatch for FRigUnit_AimItem_Target::Weight");
static_assert(offsetof(FRigUnit_AimItem_Target, Axis) == 0x8, "Offset mismatch for FRigUnit_AimItem_Target::Axis");
static_assert(offsetof(FRigUnit_AimItem_Target, Target) == 0x20, "Offset mismatch for FRigUnit_AimItem_Target::Target");
static_assert(offsetof(FRigUnit_AimItem_Target, Kind) == 0x38, "Offset mismatch for FRigUnit_AimItem_Target::Kind");
static_assert(offsetof(FRigUnit_AimItem_Target, Space) == 0x3c, "Offset mismatch for FRigUnit_AimItem_Target::Space");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FRigUnit_AimBone_DebugSettings
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float Scale; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform WorldOffset; // 0x10 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_AimBone_DebugSettings) == 0x70, "Size mismatch for FRigUnit_AimBone_DebugSettings");
static_assert(offsetof(FRigUnit_AimBone_DebugSettings, bEnabled) == 0x0, "Offset mismatch for FRigUnit_AimBone_DebugSettings::bEnabled");
static_assert(offsetof(FRigUnit_AimBone_DebugSettings, Scale) == 0x4, "Offset mismatch for FRigUnit_AimBone_DebugSettings::Scale");
static_assert(offsetof(FRigUnit_AimBone_DebugSettings, WorldOffset) == 0x10, "Offset mismatch for FRigUnit_AimBone_DebugSettings::WorldOffset");

// Size: 0x220 (Inherited: 0x18, Single: 0x208)
struct FRigUnit_AimBoneMath : FRigUnit_HighlevelBase
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform InputTransform; // 0x10 (Size: 0x60, Type: StructProperty)
    FRigUnit_AimItem_Target Primary; // 0x70 (Size: 0x48, Type: StructProperty)
    FRigUnit_AimItem_Target Secondary; // 0xb8 (Size: 0x48, Type: StructProperty)
    float Weight; // 0x100 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_104[0xc]; // 0x104 (Size: 0xc, Type: PaddingProperty)
    FTransform Result; // 0x110 (Size: 0x60, Type: StructProperty)
    FRigUnit_AimBone_DebugSettings DebugSettings; // 0x170 (Size: 0x70, Type: StructProperty)
    FCachedRigElement PrimaryCachedSpace; // 0x1e0 (Size: 0x18, Type: StructProperty)
    FCachedRigElement SecondaryCachedSpace; // 0x1f8 (Size: 0x18, Type: StructProperty)
    bool bIsInitialized; // 0x210 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_211[0xf]; // 0x211 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_AimBoneMath) == 0x220, "Size mismatch for FRigUnit_AimBoneMath");
static_assert(offsetof(FRigUnit_AimBoneMath, InputTransform) == 0x10, "Offset mismatch for FRigUnit_AimBoneMath::InputTransform");
static_assert(offsetof(FRigUnit_AimBoneMath, Primary) == 0x70, "Offset mismatch for FRigUnit_AimBoneMath::Primary");
static_assert(offsetof(FRigUnit_AimBoneMath, Secondary) == 0xb8, "Offset mismatch for FRigUnit_AimBoneMath::Secondary");
static_assert(offsetof(FRigUnit_AimBoneMath, Weight) == 0x100, "Offset mismatch for FRigUnit_AimBoneMath::Weight");
static_assert(offsetof(FRigUnit_AimBoneMath, Result) == 0x110, "Offset mismatch for FRigUnit_AimBoneMath::Result");
static_assert(offsetof(FRigUnit_AimBoneMath, DebugSettings) == 0x170, "Offset mismatch for FRigUnit_AimBoneMath::DebugSettings");
static_assert(offsetof(FRigUnit_AimBoneMath, PrimaryCachedSpace) == 0x1e0, "Offset mismatch for FRigUnit_AimBoneMath::PrimaryCachedSpace");
static_assert(offsetof(FRigUnit_AimBoneMath, SecondaryCachedSpace) == 0x1f8, "Offset mismatch for FRigUnit_AimBoneMath::SecondaryCachedSpace");
static_assert(offsetof(FRigUnit_AimBoneMath, bIsInitialized) == 0x210, "Offset mismatch for FRigUnit_AimBoneMath::bIsInitialized");

// Size: 0x160 (Inherited: 0x30, Single: 0x130)
struct FRigUnit_AimBone : FRigUnit_HighlevelBaseMutable
{
    FName bone; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FRigUnit_AimBone_Target Primary; // 0x18 (Size: 0x40, Type: StructProperty)
    FRigUnit_AimBone_Target Secondary; // 0x58 (Size: 0x40, Type: StructProperty)
    float Weight; // 0x98 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x9c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9d[0x3]; // 0x9d (Size: 0x3, Type: PaddingProperty)
    FRigUnit_AimBone_DebugSettings DebugSettings; // 0xa0 (Size: 0x70, Type: StructProperty)
    FCachedRigElement CachedBoneIndex; // 0x110 (Size: 0x18, Type: StructProperty)
    FCachedRigElement PrimaryCachedSpace; // 0x128 (Size: 0x18, Type: StructProperty)
    FCachedRigElement SecondaryCachedSpace; // 0x140 (Size: 0x18, Type: StructProperty)
    bool bIsInitialized; // 0x158 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_159[0x7]; // 0x159 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_AimBone) == 0x160, "Size mismatch for FRigUnit_AimBone");
static_assert(offsetof(FRigUnit_AimBone, bone) == 0x10, "Offset mismatch for FRigUnit_AimBone::bone");
static_assert(offsetof(FRigUnit_AimBone, Primary) == 0x18, "Offset mismatch for FRigUnit_AimBone::Primary");
static_assert(offsetof(FRigUnit_AimBone, Secondary) == 0x58, "Offset mismatch for FRigUnit_AimBone::Secondary");
static_assert(offsetof(FRigUnit_AimBone, Weight) == 0x98, "Offset mismatch for FRigUnit_AimBone::Weight");
static_assert(offsetof(FRigUnit_AimBone, bPropagateToChildren) == 0x9c, "Offset mismatch for FRigUnit_AimBone::bPropagateToChildren");
static_assert(offsetof(FRigUnit_AimBone, DebugSettings) == 0xa0, "Offset mismatch for FRigUnit_AimBone::DebugSettings");
static_assert(offsetof(FRigUnit_AimBone, CachedBoneIndex) == 0x110, "Offset mismatch for FRigUnit_AimBone::CachedBoneIndex");
static_assert(offsetof(FRigUnit_AimBone, PrimaryCachedSpace) == 0x128, "Offset mismatch for FRigUnit_AimBone::PrimaryCachedSpace");
static_assert(offsetof(FRigUnit_AimBone, SecondaryCachedSpace) == 0x140, "Offset mismatch for FRigUnit_AimBone::SecondaryCachedSpace");
static_assert(offsetof(FRigUnit_AimBone, bIsInitialized) == 0x158, "Offset mismatch for FRigUnit_AimBone::bIsInitialized");

// Size: 0x170 (Inherited: 0x30, Single: 0x140)
struct FRigUnit_AimItem : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigUnit_AimItem_Target Primary; // 0x18 (Size: 0x48, Type: StructProperty)
    FRigUnit_AimItem_Target Secondary; // 0x60 (Size: 0x48, Type: StructProperty)
    float Weight; // 0xa8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
    FRigUnit_AimBone_DebugSettings DebugSettings; // 0xb0 (Size: 0x70, Type: StructProperty)
    FCachedRigElement CachedItem; // 0x120 (Size: 0x18, Type: StructProperty)
    FCachedRigElement PrimaryCachedSpace; // 0x138 (Size: 0x18, Type: StructProperty)
    FCachedRigElement SecondaryCachedSpace; // 0x150 (Size: 0x18, Type: StructProperty)
    bool bIsInitialized; // 0x168 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_169[0x7]; // 0x169 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_AimItem) == 0x170, "Size mismatch for FRigUnit_AimItem");
static_assert(offsetof(FRigUnit_AimItem, Item) == 0x10, "Offset mismatch for FRigUnit_AimItem::Item");
static_assert(offsetof(FRigUnit_AimItem, Primary) == 0x18, "Offset mismatch for FRigUnit_AimItem::Primary");
static_assert(offsetof(FRigUnit_AimItem, Secondary) == 0x60, "Offset mismatch for FRigUnit_AimItem::Secondary");
static_assert(offsetof(FRigUnit_AimItem, Weight) == 0xa8, "Offset mismatch for FRigUnit_AimItem::Weight");
static_assert(offsetof(FRigUnit_AimItem, DebugSettings) == 0xb0, "Offset mismatch for FRigUnit_AimItem::DebugSettings");
static_assert(offsetof(FRigUnit_AimItem, CachedItem) == 0x120, "Offset mismatch for FRigUnit_AimItem::CachedItem");
static_assert(offsetof(FRigUnit_AimItem, PrimaryCachedSpace) == 0x138, "Offset mismatch for FRigUnit_AimItem::PrimaryCachedSpace");
static_assert(offsetof(FRigUnit_AimItem, SecondaryCachedSpace) == 0x150, "Offset mismatch for FRigUnit_AimItem::SecondaryCachedSpace");
static_assert(offsetof(FRigUnit_AimItem, bIsInitialized) == 0x168, "Offset mismatch for FRigUnit_AimItem::bIsInitialized");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FRigUnit_AimConstraint_WorldUp
{
    FVector Target; // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t Kind; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
    FRigElementKey Space; // 0x1c (Size: 0x8, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_AimConstraint_WorldUp) == 0x28, "Size mismatch for FRigUnit_AimConstraint_WorldUp");
static_assert(offsetof(FRigUnit_AimConstraint_WorldUp, Target) == 0x0, "Offset mismatch for FRigUnit_AimConstraint_WorldUp::Target");
static_assert(offsetof(FRigUnit_AimConstraint_WorldUp, Kind) == 0x18, "Offset mismatch for FRigUnit_AimConstraint_WorldUp::Kind");
static_assert(offsetof(FRigUnit_AimConstraint_WorldUp, Space) == 0x1c, "Offset mismatch for FRigUnit_AimConstraint_WorldUp::Space");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FRigUnit_AimConstraint_AdvancedSettings
{
    FRigUnit_AimBone_DebugSettings DebugSettings; // 0x0 (Size: 0x70, Type: StructProperty)
    uint8_t RotationOrderForFilter; // 0x70 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_71[0xf]; // 0x71 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_AimConstraint_AdvancedSettings) == 0x80, "Size mismatch for FRigUnit_AimConstraint_AdvancedSettings");
static_assert(offsetof(FRigUnit_AimConstraint_AdvancedSettings, DebugSettings) == 0x0, "Offset mismatch for FRigUnit_AimConstraint_AdvancedSettings::DebugSettings");
static_assert(offsetof(FRigUnit_AimConstraint_AdvancedSettings, RotationOrderForFilter) == 0x70, "Offset mismatch for FRigUnit_AimConstraint_AdvancedSettings::RotationOrderForFilter");

// Size: 0x160 (Inherited: 0x30, Single: 0x130)
struct FRigUnit_AimConstraintLocalSpaceOffset : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset; // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter; // 0x19 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FVector AimAxis; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector UpAxis; // 0x38 (Size: 0x18, Type: StructProperty)
    FRigUnit_AimConstraint_WorldUp WorldUp; // 0x50 (Size: 0x28, Type: StructProperty)
    TArray<FConstraintParent> Parents; // 0x78 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
    FRigUnit_AimConstraint_AdvancedSettings AdvancedSettings; // 0x90 (Size: 0x80, Type: StructProperty)
    float Weight; // 0x110 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_114[0x4]; // 0x114 (Size: 0x4, Type: PaddingProperty)
    FCachedRigElement WorldUpSpaceCache; // 0x118 (Size: 0x18, Type: StructProperty)
    FCachedRigElement ChildCache; // 0x130 (Size: 0x18, Type: StructProperty)
    TArray<FCachedRigElement> ParentCaches; // 0x148 (Size: 0x10, Type: ArrayProperty)
    bool bIsInitialized; // 0x158 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_159[0x7]; // 0x159 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_AimConstraintLocalSpaceOffset) == 0x160, "Size mismatch for FRigUnit_AimConstraintLocalSpaceOffset");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, Child) == 0x10, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::Child");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, bMaintainOffset) == 0x18, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::bMaintainOffset");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, Filter) == 0x19, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::Filter");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, AimAxis) == 0x20, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::AimAxis");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, UpAxis) == 0x38, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::UpAxis");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, WorldUp) == 0x50, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::WorldUp");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, Parents) == 0x78, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::Parents");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, AdvancedSettings) == 0x90, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::AdvancedSettings");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, Weight) == 0x110, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::Weight");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, WorldUpSpaceCache) == 0x118, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::WorldUpSpaceCache");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, ChildCache) == 0x130, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::ChildCache");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, ParentCaches) == 0x148, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::ParentCaches");
static_assert(offsetof(FRigUnit_AimConstraintLocalSpaceOffset, bIsInitialized) == 0x158, "Offset mismatch for FRigUnit_AimConstraintLocalSpaceOffset::bIsInitialized");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FConstraintParent
{
    FRigElementKey Item; // 0x0 (Size: 0x8, Type: StructProperty)
    float Weight; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FConstraintParent) == 0xc, "Size mismatch for FConstraintParent");
static_assert(offsetof(FConstraintParent, Item) == 0x0, "Offset mismatch for FConstraintParent::Item");
static_assert(offsetof(FConstraintParent, Weight) == 0x8, "Offset mismatch for FConstraintParent::Weight");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FRigUnit_CCDIK_RotationLimit
{
    FName bone; // 0x0 (Size: 0x4, Type: NameProperty)
    float Limit; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_CCDIK_RotationLimit) == 0x8, "Size mismatch for FRigUnit_CCDIK_RotationLimit");
static_assert(offsetof(FRigUnit_CCDIK_RotationLimit, bone) == 0x0, "Offset mismatch for FRigUnit_CCDIK_RotationLimit::bone");
static_assert(offsetof(FRigUnit_CCDIK_RotationLimit, Limit) == 0x4, "Offset mismatch for FRigUnit_CCDIK_RotationLimit::Limit");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FRigUnit_CCDIK_RotationLimitPerItem
{
    FRigElementKey Item; // 0x0 (Size: 0x8, Type: StructProperty)
    float Limit; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_CCDIK_RotationLimitPerItem) == 0xc, "Size mismatch for FRigUnit_CCDIK_RotationLimitPerItem");
static_assert(offsetof(FRigUnit_CCDIK_RotationLimitPerItem, Item) == 0x0, "Offset mismatch for FRigUnit_CCDIK_RotationLimitPerItem::Item");
static_assert(offsetof(FRigUnit_CCDIK_RotationLimitPerItem, Limit) == 0x8, "Offset mismatch for FRigUnit_CCDIK_RotationLimitPerItem::Limit");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FRigUnit_CCDIK_WorkData
{
    TArray<FCCDIKChainLink> Chain; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedItems; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> RotationLimitIndex; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<float> RotationLimitsPerItem; // 0x30 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedEffector; // 0x40 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_CCDIK_WorkData) == 0x58, "Size mismatch for FRigUnit_CCDIK_WorkData");
static_assert(offsetof(FRigUnit_CCDIK_WorkData, Chain) == 0x0, "Offset mismatch for FRigUnit_CCDIK_WorkData::Chain");
static_assert(offsetof(FRigUnit_CCDIK_WorkData, CachedItems) == 0x10, "Offset mismatch for FRigUnit_CCDIK_WorkData::CachedItems");
static_assert(offsetof(FRigUnit_CCDIK_WorkData, RotationLimitIndex) == 0x20, "Offset mismatch for FRigUnit_CCDIK_WorkData::RotationLimitIndex");
static_assert(offsetof(FRigUnit_CCDIK_WorkData, RotationLimitsPerItem) == 0x30, "Offset mismatch for FRigUnit_CCDIK_WorkData::RotationLimitsPerItem");
static_assert(offsetof(FRigUnit_CCDIK_WorkData, CachedEffector) == 0x40, "Offset mismatch for FRigUnit_CCDIK_WorkData::CachedEffector");

// Size: 0x110 (Inherited: 0x30, Single: 0xe0)
struct FRigUnit_CCDIK : FRigUnit_HighlevelBaseMutable
{
    FName StartBone; // 0x10 (Size: 0x4, Type: NameProperty)
    FName EffectorBone; // 0x14 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform EffectorTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    float Precision; // 0x80 (Size: 0x4, Type: FloatProperty)
    float Weight; // 0x84 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations; // 0x88 (Size: 0x4, Type: IntProperty)
    bool bStartFromTail; // 0x8c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8d[0x3]; // 0x8d (Size: 0x3, Type: PaddingProperty)
    float BaseRotationLimit; // 0x90 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
    TArray<FRigUnit_CCDIK_RotationLimit> RotationLimits; // 0x98 (Size: 0x10, Type: ArrayProperty)
    bool bPropagateToChildren; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_CCDIK_WorkData WorkData; // 0xb0 (Size: 0x58, Type: StructProperty)
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_CCDIK) == 0x110, "Size mismatch for FRigUnit_CCDIK");
static_assert(offsetof(FRigUnit_CCDIK, StartBone) == 0x10, "Offset mismatch for FRigUnit_CCDIK::StartBone");
static_assert(offsetof(FRigUnit_CCDIK, EffectorBone) == 0x14, "Offset mismatch for FRigUnit_CCDIK::EffectorBone");
static_assert(offsetof(FRigUnit_CCDIK, EffectorTransform) == 0x20, "Offset mismatch for FRigUnit_CCDIK::EffectorTransform");
static_assert(offsetof(FRigUnit_CCDIK, Precision) == 0x80, "Offset mismatch for FRigUnit_CCDIK::Precision");
static_assert(offsetof(FRigUnit_CCDIK, Weight) == 0x84, "Offset mismatch for FRigUnit_CCDIK::Weight");
static_assert(offsetof(FRigUnit_CCDIK, MaxIterations) == 0x88, "Offset mismatch for FRigUnit_CCDIK::MaxIterations");
static_assert(offsetof(FRigUnit_CCDIK, bStartFromTail) == 0x8c, "Offset mismatch for FRigUnit_CCDIK::bStartFromTail");
static_assert(offsetof(FRigUnit_CCDIK, BaseRotationLimit) == 0x90, "Offset mismatch for FRigUnit_CCDIK::BaseRotationLimit");
static_assert(offsetof(FRigUnit_CCDIK, RotationLimits) == 0x98, "Offset mismatch for FRigUnit_CCDIK::RotationLimits");
static_assert(offsetof(FRigUnit_CCDIK, bPropagateToChildren) == 0xa8, "Offset mismatch for FRigUnit_CCDIK::bPropagateToChildren");
static_assert(offsetof(FRigUnit_CCDIK, WorkData) == 0xb0, "Offset mismatch for FRigUnit_CCDIK::WorkData");

// Size: 0x110 (Inherited: 0x30, Single: 0xe0)
struct FRigUnit_CCDIKPerItem : FRigUnit_HighlevelBaseMutable
{
    FRigElementKeyCollection Items; // 0x10 (Size: 0x10, Type: StructProperty)
    FTransform EffectorTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    float Precision; // 0x80 (Size: 0x4, Type: FloatProperty)
    float Weight; // 0x84 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations; // 0x88 (Size: 0x4, Type: IntProperty)
    bool bStartFromTail; // 0x8c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8d[0x3]; // 0x8d (Size: 0x3, Type: PaddingProperty)
    float BaseRotationLimit; // 0x90 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
    TArray<FRigUnit_CCDIK_RotationLimitPerItem> RotationLimits; // 0x98 (Size: 0x10, Type: ArrayProperty)
    bool bPropagateToChildren; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_CCDIK_WorkData WorkData; // 0xb0 (Size: 0x58, Type: StructProperty)
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_CCDIKPerItem) == 0x110, "Size mismatch for FRigUnit_CCDIKPerItem");
static_assert(offsetof(FRigUnit_CCDIKPerItem, Items) == 0x10, "Offset mismatch for FRigUnit_CCDIKPerItem::Items");
static_assert(offsetof(FRigUnit_CCDIKPerItem, EffectorTransform) == 0x20, "Offset mismatch for FRigUnit_CCDIKPerItem::EffectorTransform");
static_assert(offsetof(FRigUnit_CCDIKPerItem, Precision) == 0x80, "Offset mismatch for FRigUnit_CCDIKPerItem::Precision");
static_assert(offsetof(FRigUnit_CCDIKPerItem, Weight) == 0x84, "Offset mismatch for FRigUnit_CCDIKPerItem::Weight");
static_assert(offsetof(FRigUnit_CCDIKPerItem, MaxIterations) == 0x88, "Offset mismatch for FRigUnit_CCDIKPerItem::MaxIterations");
static_assert(offsetof(FRigUnit_CCDIKPerItem, bStartFromTail) == 0x8c, "Offset mismatch for FRigUnit_CCDIKPerItem::bStartFromTail");
static_assert(offsetof(FRigUnit_CCDIKPerItem, BaseRotationLimit) == 0x90, "Offset mismatch for FRigUnit_CCDIKPerItem::BaseRotationLimit");
static_assert(offsetof(FRigUnit_CCDIKPerItem, RotationLimits) == 0x98, "Offset mismatch for FRigUnit_CCDIKPerItem::RotationLimits");
static_assert(offsetof(FRigUnit_CCDIKPerItem, bPropagateToChildren) == 0xa8, "Offset mismatch for FRigUnit_CCDIKPerItem::bPropagateToChildren");
static_assert(offsetof(FRigUnit_CCDIKPerItem, WorkData) == 0xb0, "Offset mismatch for FRigUnit_CCDIKPerItem::WorkData");

// Size: 0x110 (Inherited: 0x30, Single: 0xe0)
struct FRigUnit_CCDIKItemArray : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FTransform EffectorTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    float Precision; // 0x80 (Size: 0x4, Type: FloatProperty)
    float Weight; // 0x84 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations; // 0x88 (Size: 0x4, Type: IntProperty)
    bool bStartFromTail; // 0x8c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8d[0x3]; // 0x8d (Size: 0x3, Type: PaddingProperty)
    float BaseRotationLimit; // 0x90 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
    TArray<FRigUnit_CCDIK_RotationLimitPerItem> RotationLimits; // 0x98 (Size: 0x10, Type: ArrayProperty)
    bool bPropagateToChildren; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_CCDIK_WorkData WorkData; // 0xb0 (Size: 0x58, Type: StructProperty)
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_CCDIKItemArray) == 0x110, "Size mismatch for FRigUnit_CCDIKItemArray");
static_assert(offsetof(FRigUnit_CCDIKItemArray, Items) == 0x10, "Offset mismatch for FRigUnit_CCDIKItemArray::Items");
static_assert(offsetof(FRigUnit_CCDIKItemArray, EffectorTransform) == 0x20, "Offset mismatch for FRigUnit_CCDIKItemArray::EffectorTransform");
static_assert(offsetof(FRigUnit_CCDIKItemArray, Precision) == 0x80, "Offset mismatch for FRigUnit_CCDIKItemArray::Precision");
static_assert(offsetof(FRigUnit_CCDIKItemArray, Weight) == 0x84, "Offset mismatch for FRigUnit_CCDIKItemArray::Weight");
static_assert(offsetof(FRigUnit_CCDIKItemArray, MaxIterations) == 0x88, "Offset mismatch for FRigUnit_CCDIKItemArray::MaxIterations");
static_assert(offsetof(FRigUnit_CCDIKItemArray, bStartFromTail) == 0x8c, "Offset mismatch for FRigUnit_CCDIKItemArray::bStartFromTail");
static_assert(offsetof(FRigUnit_CCDIKItemArray, BaseRotationLimit) == 0x90, "Offset mismatch for FRigUnit_CCDIKItemArray::BaseRotationLimit");
static_assert(offsetof(FRigUnit_CCDIKItemArray, RotationLimits) == 0x98, "Offset mismatch for FRigUnit_CCDIKItemArray::RotationLimits");
static_assert(offsetof(FRigUnit_CCDIKItemArray, bPropagateToChildren) == 0xa8, "Offset mismatch for FRigUnit_CCDIKItemArray::bPropagateToChildren");
static_assert(offsetof(FRigUnit_CCDIKItemArray, WorkData) == 0xb0, "Offset mismatch for FRigUnit_CCDIKItemArray::WorkData");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FRigUnit_ChainInfo_Segment
{
    FCachedRigElement StartItem; // 0x0 (Size: 0x18, Type: StructProperty)
    int32_t StartItemIndex; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FCachedRigElement EndItem; // 0x20 (Size: 0x18, Type: StructProperty)
    int32_t EndItemIndex; // 0x38 (Size: 0x4, Type: IntProperty)
    float InitialLength; // 0x3c (Size: 0x4, Type: FloatProperty)
    float InitialCumLength; // 0x40 (Size: 0x4, Type: FloatProperty)
    float Length; // 0x44 (Size: 0x4, Type: FloatProperty)
    float CumLength; // 0x48 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ChainInfo_Segment) == 0x50, "Size mismatch for FRigUnit_ChainInfo_Segment");
static_assert(offsetof(FRigUnit_ChainInfo_Segment, StartItem) == 0x0, "Offset mismatch for FRigUnit_ChainInfo_Segment::StartItem");
static_assert(offsetof(FRigUnit_ChainInfo_Segment, StartItemIndex) == 0x18, "Offset mismatch for FRigUnit_ChainInfo_Segment::StartItemIndex");
static_assert(offsetof(FRigUnit_ChainInfo_Segment, EndItem) == 0x20, "Offset mismatch for FRigUnit_ChainInfo_Segment::EndItem");
static_assert(offsetof(FRigUnit_ChainInfo_Segment, EndItemIndex) == 0x38, "Offset mismatch for FRigUnit_ChainInfo_Segment::EndItemIndex");
static_assert(offsetof(FRigUnit_ChainInfo_Segment, InitialLength) == 0x3c, "Offset mismatch for FRigUnit_ChainInfo_Segment::InitialLength");
static_assert(offsetof(FRigUnit_ChainInfo_Segment, InitialCumLength) == 0x40, "Offset mismatch for FRigUnit_ChainInfo_Segment::InitialCumLength");
static_assert(offsetof(FRigUnit_ChainInfo_Segment, Length) == 0x44, "Offset mismatch for FRigUnit_ChainInfo_Segment::Length");
static_assert(offsetof(FRigUnit_ChainInfo_Segment, CumLength) == 0x48, "Offset mismatch for FRigUnit_ChainInfo_Segment::CumLength");

// Size: 0xe0 (Inherited: 0x30, Single: 0xb0)
struct FRigUnit_ChainInfo : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Param; // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bCalculateStretch; // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bInitial; // 0x25 (Size: 0x1, Type: BoolProperty)
    bool bDebug; // 0x26 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_27[0x1]; // 0x27 (Size: 0x1, Type: PaddingProperty)
    float DebugScale; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    FTransform OutputTransform; // 0x30 (Size: 0x60, Type: StructProperty)
    float ChainLength; // 0x90 (Size: 0x4, Type: FloatProperty)
    float ParamLength; // 0x94 (Size: 0x4, Type: FloatProperty)
    int32_t SegmentIndex; // 0x98 (Size: 0x4, Type: IntProperty)
    float SegmentLength; // 0x9c (Size: 0x4, Type: FloatProperty)
    float SegmentParam; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float SegmentParamLength; // 0xa4 (Size: 0x4, Type: FloatProperty)
    FRigElementKey SegmentStartItem; // 0xa8 (Size: 0x8, Type: StructProperty)
    int32_t SegmentStartItemIndex; // 0xb0 (Size: 0x4, Type: IntProperty)
    FRigElementKey SegmentEndItem; // 0xb4 (Size: 0x8, Type: StructProperty)
    int32_t SegmentEndItemIndex; // 0xbc (Size: 0x4, Type: IntProperty)
    float ChainStretchFactor; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float SegmentStretchFactor; // 0xc4 (Size: 0x4, Type: FloatProperty)
    TArray<FCachedRigElement> CachedElements; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_d8[0x8]; // 0xd8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ChainInfo) == 0xe0, "Size mismatch for FRigUnit_ChainInfo");
static_assert(offsetof(FRigUnit_ChainInfo, Items) == 0x10, "Offset mismatch for FRigUnit_ChainInfo::Items");
static_assert(offsetof(FRigUnit_ChainInfo, Param) == 0x20, "Offset mismatch for FRigUnit_ChainInfo::Param");
static_assert(offsetof(FRigUnit_ChainInfo, bCalculateStretch) == 0x24, "Offset mismatch for FRigUnit_ChainInfo::bCalculateStretch");
static_assert(offsetof(FRigUnit_ChainInfo, bInitial) == 0x25, "Offset mismatch for FRigUnit_ChainInfo::bInitial");
static_assert(offsetof(FRigUnit_ChainInfo, bDebug) == 0x26, "Offset mismatch for FRigUnit_ChainInfo::bDebug");
static_assert(offsetof(FRigUnit_ChainInfo, DebugScale) == 0x28, "Offset mismatch for FRigUnit_ChainInfo::DebugScale");
static_assert(offsetof(FRigUnit_ChainInfo, OutputTransform) == 0x30, "Offset mismatch for FRigUnit_ChainInfo::OutputTransform");
static_assert(offsetof(FRigUnit_ChainInfo, ChainLength) == 0x90, "Offset mismatch for FRigUnit_ChainInfo::ChainLength");
static_assert(offsetof(FRigUnit_ChainInfo, ParamLength) == 0x94, "Offset mismatch for FRigUnit_ChainInfo::ParamLength");
static_assert(offsetof(FRigUnit_ChainInfo, SegmentIndex) == 0x98, "Offset mismatch for FRigUnit_ChainInfo::SegmentIndex");
static_assert(offsetof(FRigUnit_ChainInfo, SegmentLength) == 0x9c, "Offset mismatch for FRigUnit_ChainInfo::SegmentLength");
static_assert(offsetof(FRigUnit_ChainInfo, SegmentParam) == 0xa0, "Offset mismatch for FRigUnit_ChainInfo::SegmentParam");
static_assert(offsetof(FRigUnit_ChainInfo, SegmentParamLength) == 0xa4, "Offset mismatch for FRigUnit_ChainInfo::SegmentParamLength");
static_assert(offsetof(FRigUnit_ChainInfo, SegmentStartItem) == 0xa8, "Offset mismatch for FRigUnit_ChainInfo::SegmentStartItem");
static_assert(offsetof(FRigUnit_ChainInfo, SegmentStartItemIndex) == 0xb0, "Offset mismatch for FRigUnit_ChainInfo::SegmentStartItemIndex");
static_assert(offsetof(FRigUnit_ChainInfo, SegmentEndItem) == 0xb4, "Offset mismatch for FRigUnit_ChainInfo::SegmentEndItem");
static_assert(offsetof(FRigUnit_ChainInfo, SegmentEndItemIndex) == 0xbc, "Offset mismatch for FRigUnit_ChainInfo::SegmentEndItemIndex");
static_assert(offsetof(FRigUnit_ChainInfo, ChainStretchFactor) == 0xc0, "Offset mismatch for FRigUnit_ChainInfo::ChainStretchFactor");
static_assert(offsetof(FRigUnit_ChainInfo, SegmentStretchFactor) == 0xc4, "Offset mismatch for FRigUnit_ChainInfo::SegmentStretchFactor");
static_assert(offsetof(FRigUnit_ChainInfo, CachedElements) == 0xc8, "Offset mismatch for FRigUnit_ChainInfo::CachedElements");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FRigUnit_DistributeRotation_Rotation
{
    FQuat Rotation; // 0x0 (Size: 0x20, Type: StructProperty)
    float Ratio; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0xc]; // 0x24 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_DistributeRotation_Rotation) == 0x30, "Size mismatch for FRigUnit_DistributeRotation_Rotation");
static_assert(offsetof(FRigUnit_DistributeRotation_Rotation, Rotation) == 0x0, "Offset mismatch for FRigUnit_DistributeRotation_Rotation::Rotation");
static_assert(offsetof(FRigUnit_DistributeRotation_Rotation, Ratio) == 0x20, "Offset mismatch for FRigUnit_DistributeRotation_Rotation::Ratio");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FRigUnit_DistributeRotation_WorkData
{
    TArray<FCachedRigElement> CachedItems; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ItemRotationA; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ItemRotationB; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<float> ItemRotationT; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> ItemLocalTransforms; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_DistributeRotation_WorkData) == 0x50, "Size mismatch for FRigUnit_DistributeRotation_WorkData");
static_assert(offsetof(FRigUnit_DistributeRotation_WorkData, CachedItems) == 0x0, "Offset mismatch for FRigUnit_DistributeRotation_WorkData::CachedItems");
static_assert(offsetof(FRigUnit_DistributeRotation_WorkData, ItemRotationA) == 0x10, "Offset mismatch for FRigUnit_DistributeRotation_WorkData::ItemRotationA");
static_assert(offsetof(FRigUnit_DistributeRotation_WorkData, ItemRotationB) == 0x20, "Offset mismatch for FRigUnit_DistributeRotation_WorkData::ItemRotationB");
static_assert(offsetof(FRigUnit_DistributeRotation_WorkData, ItemRotationT) == 0x30, "Offset mismatch for FRigUnit_DistributeRotation_WorkData::ItemRotationT");
static_assert(offsetof(FRigUnit_DistributeRotation_WorkData, ItemLocalTransforms) == 0x40, "Offset mismatch for FRigUnit_DistributeRotation_WorkData::ItemLocalTransforms");

// Size: 0x88 (Inherited: 0x30, Single: 0x58)
struct FRigUnit_DistributeRotation : FRigUnit_HighlevelBaseMutable
{
    FName StartBone; // 0x10 (Size: 0x4, Type: NameProperty)
    FName EndBone; // 0x14 (Size: 0x4, Type: NameProperty)
    TArray<FRigUnit_DistributeRotation_Rotation> Rotations; // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_DistributeRotation_WorkData WorkData; // 0x38 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_DistributeRotation) == 0x88, "Size mismatch for FRigUnit_DistributeRotation");
static_assert(offsetof(FRigUnit_DistributeRotation, StartBone) == 0x10, "Offset mismatch for FRigUnit_DistributeRotation::StartBone");
static_assert(offsetof(FRigUnit_DistributeRotation, EndBone) == 0x14, "Offset mismatch for FRigUnit_DistributeRotation::EndBone");
static_assert(offsetof(FRigUnit_DistributeRotation, Rotations) == 0x18, "Offset mismatch for FRigUnit_DistributeRotation::Rotations");
static_assert(offsetof(FRigUnit_DistributeRotation, RotationEaseType) == 0x28, "Offset mismatch for FRigUnit_DistributeRotation::RotationEaseType");
static_assert(offsetof(FRigUnit_DistributeRotation, Weight) == 0x2c, "Offset mismatch for FRigUnit_DistributeRotation::Weight");
static_assert(offsetof(FRigUnit_DistributeRotation, bPropagateToChildren) == 0x30, "Offset mismatch for FRigUnit_DistributeRotation::bPropagateToChildren");
static_assert(offsetof(FRigUnit_DistributeRotation, WorkData) == 0x38, "Offset mismatch for FRigUnit_DistributeRotation::WorkData");

// Size: 0x88 (Inherited: 0x30, Single: 0x58)
struct FRigUnit_DistributeRotationForCollection : FRigUnit_HighlevelBaseMutable
{
    FRigElementKeyCollection Items; // 0x10 (Size: 0x10, Type: StructProperty)
    TArray<FRigUnit_DistributeRotation_Rotation> Rotations; // 0x20 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x3]; // 0x31 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0x34 (Size: 0x4, Type: FloatProperty)
    FRigUnit_DistributeRotation_WorkData WorkData; // 0x38 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_DistributeRotationForCollection) == 0x88, "Size mismatch for FRigUnit_DistributeRotationForCollection");
static_assert(offsetof(FRigUnit_DistributeRotationForCollection, Items) == 0x10, "Offset mismatch for FRigUnit_DistributeRotationForCollection::Items");
static_assert(offsetof(FRigUnit_DistributeRotationForCollection, Rotations) == 0x20, "Offset mismatch for FRigUnit_DistributeRotationForCollection::Rotations");
static_assert(offsetof(FRigUnit_DistributeRotationForCollection, RotationEaseType) == 0x30, "Offset mismatch for FRigUnit_DistributeRotationForCollection::RotationEaseType");
static_assert(offsetof(FRigUnit_DistributeRotationForCollection, Weight) == 0x34, "Offset mismatch for FRigUnit_DistributeRotationForCollection::Weight");
static_assert(offsetof(FRigUnit_DistributeRotationForCollection, WorkData) == 0x38, "Offset mismatch for FRigUnit_DistributeRotationForCollection::WorkData");

// Size: 0x88 (Inherited: 0x30, Single: 0x58)
struct FRigUnit_DistributeRotationForItemArray : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigUnit_DistributeRotation_Rotation> Rotations; // 0x20 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x3]; // 0x31 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0x34 (Size: 0x4, Type: FloatProperty)
    FRigUnit_DistributeRotation_WorkData WorkData; // 0x38 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_DistributeRotationForItemArray) == 0x88, "Size mismatch for FRigUnit_DistributeRotationForItemArray");
static_assert(offsetof(FRigUnit_DistributeRotationForItemArray, Items) == 0x10, "Offset mismatch for FRigUnit_DistributeRotationForItemArray::Items");
static_assert(offsetof(FRigUnit_DistributeRotationForItemArray, Rotations) == 0x20, "Offset mismatch for FRigUnit_DistributeRotationForItemArray::Rotations");
static_assert(offsetof(FRigUnit_DistributeRotationForItemArray, RotationEaseType) == 0x30, "Offset mismatch for FRigUnit_DistributeRotationForItemArray::RotationEaseType");
static_assert(offsetof(FRigUnit_DistributeRotationForItemArray, Weight) == 0x34, "Offset mismatch for FRigUnit_DistributeRotationForItemArray::Weight");
static_assert(offsetof(FRigUnit_DistributeRotationForItemArray, WorkData) == 0x38, "Offset mismatch for FRigUnit_DistributeRotationForItemArray::WorkData");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FRigUnit_FABRIK_WorkData
{
    TArray<FFABRIKChainLink> Chain; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedItems; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedEffector; // 0x20 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_FABRIK_WorkData) == 0x38, "Size mismatch for FRigUnit_FABRIK_WorkData");
static_assert(offsetof(FRigUnit_FABRIK_WorkData, Chain) == 0x0, "Offset mismatch for FRigUnit_FABRIK_WorkData::Chain");
static_assert(offsetof(FRigUnit_FABRIK_WorkData, CachedItems) == 0x10, "Offset mismatch for FRigUnit_FABRIK_WorkData::CachedItems");
static_assert(offsetof(FRigUnit_FABRIK_WorkData, CachedEffector) == 0x20, "Offset mismatch for FRigUnit_FABRIK_WorkData::CachedEffector");

// Size: 0xd0 (Inherited: 0x30, Single: 0xa0)
struct FRigUnit_FABRIK : FRigUnit_HighlevelBaseMutable
{
    FName StartBone; // 0x10 (Size: 0x4, Type: NameProperty)
    FName EffectorBone; // 0x14 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform EffectorTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    float Precision; // 0x80 (Size: 0x4, Type: FloatProperty)
    float Weight; // 0x84 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x88 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0x3]; // 0x89 (Size: 0x3, Type: PaddingProperty)
    int32_t MaxIterations; // 0x8c (Size: 0x4, Type: IntProperty)
    FRigUnit_FABRIK_WorkData WorkData; // 0x90 (Size: 0x38, Type: StructProperty)
    bool bSetEffectorTransform; // 0xc8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c9[0x7]; // 0xc9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_FABRIK) == 0xd0, "Size mismatch for FRigUnit_FABRIK");
static_assert(offsetof(FRigUnit_FABRIK, StartBone) == 0x10, "Offset mismatch for FRigUnit_FABRIK::StartBone");
static_assert(offsetof(FRigUnit_FABRIK, EffectorBone) == 0x14, "Offset mismatch for FRigUnit_FABRIK::EffectorBone");
static_assert(offsetof(FRigUnit_FABRIK, EffectorTransform) == 0x20, "Offset mismatch for FRigUnit_FABRIK::EffectorTransform");
static_assert(offsetof(FRigUnit_FABRIK, Precision) == 0x80, "Offset mismatch for FRigUnit_FABRIK::Precision");
static_assert(offsetof(FRigUnit_FABRIK, Weight) == 0x84, "Offset mismatch for FRigUnit_FABRIK::Weight");
static_assert(offsetof(FRigUnit_FABRIK, bPropagateToChildren) == 0x88, "Offset mismatch for FRigUnit_FABRIK::bPropagateToChildren");
static_assert(offsetof(FRigUnit_FABRIK, MaxIterations) == 0x8c, "Offset mismatch for FRigUnit_FABRIK::MaxIterations");
static_assert(offsetof(FRigUnit_FABRIK, WorkData) == 0x90, "Offset mismatch for FRigUnit_FABRIK::WorkData");
static_assert(offsetof(FRigUnit_FABRIK, bSetEffectorTransform) == 0xc8, "Offset mismatch for FRigUnit_FABRIK::bSetEffectorTransform");

// Size: 0xd0 (Inherited: 0x30, Single: 0xa0)
struct FRigUnit_FABRIKPerItem : FRigUnit_HighlevelBaseMutable
{
    FRigElementKeyCollection Items; // 0x10 (Size: 0x10, Type: StructProperty)
    FTransform EffectorTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    float Precision; // 0x80 (Size: 0x4, Type: FloatProperty)
    float Weight; // 0x84 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x88 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0x3]; // 0x89 (Size: 0x3, Type: PaddingProperty)
    int32_t MaxIterations; // 0x8c (Size: 0x4, Type: IntProperty)
    FRigUnit_FABRIK_WorkData WorkData; // 0x90 (Size: 0x38, Type: StructProperty)
    bool bSetEffectorTransform; // 0xc8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c9[0x7]; // 0xc9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_FABRIKPerItem) == 0xd0, "Size mismatch for FRigUnit_FABRIKPerItem");
static_assert(offsetof(FRigUnit_FABRIKPerItem, Items) == 0x10, "Offset mismatch for FRigUnit_FABRIKPerItem::Items");
static_assert(offsetof(FRigUnit_FABRIKPerItem, EffectorTransform) == 0x20, "Offset mismatch for FRigUnit_FABRIKPerItem::EffectorTransform");
static_assert(offsetof(FRigUnit_FABRIKPerItem, Precision) == 0x80, "Offset mismatch for FRigUnit_FABRIKPerItem::Precision");
static_assert(offsetof(FRigUnit_FABRIKPerItem, Weight) == 0x84, "Offset mismatch for FRigUnit_FABRIKPerItem::Weight");
static_assert(offsetof(FRigUnit_FABRIKPerItem, bPropagateToChildren) == 0x88, "Offset mismatch for FRigUnit_FABRIKPerItem::bPropagateToChildren");
static_assert(offsetof(FRigUnit_FABRIKPerItem, MaxIterations) == 0x8c, "Offset mismatch for FRigUnit_FABRIKPerItem::MaxIterations");
static_assert(offsetof(FRigUnit_FABRIKPerItem, WorkData) == 0x90, "Offset mismatch for FRigUnit_FABRIKPerItem::WorkData");
static_assert(offsetof(FRigUnit_FABRIKPerItem, bSetEffectorTransform) == 0xc8, "Offset mismatch for FRigUnit_FABRIKPerItem::bSetEffectorTransform");

// Size: 0xd0 (Inherited: 0x30, Single: 0xa0)
struct FRigUnit_FABRIKItemArray : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FTransform EffectorTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    float Precision; // 0x80 (Size: 0x4, Type: FloatProperty)
    float Weight; // 0x84 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x88 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_89[0x3]; // 0x89 (Size: 0x3, Type: PaddingProperty)
    int32_t MaxIterations; // 0x8c (Size: 0x4, Type: IntProperty)
    FRigUnit_FABRIK_WorkData WorkData; // 0x90 (Size: 0x38, Type: StructProperty)
    bool bSetEffectorTransform; // 0xc8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c9[0x7]; // 0xc9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_FABRIKItemArray) == 0xd0, "Size mismatch for FRigUnit_FABRIKItemArray");
static_assert(offsetof(FRigUnit_FABRIKItemArray, Items) == 0x10, "Offset mismatch for FRigUnit_FABRIKItemArray::Items");
static_assert(offsetof(FRigUnit_FABRIKItemArray, EffectorTransform) == 0x20, "Offset mismatch for FRigUnit_FABRIKItemArray::EffectorTransform");
static_assert(offsetof(FRigUnit_FABRIKItemArray, Precision) == 0x80, "Offset mismatch for FRigUnit_FABRIKItemArray::Precision");
static_assert(offsetof(FRigUnit_FABRIKItemArray, Weight) == 0x84, "Offset mismatch for FRigUnit_FABRIKItemArray::Weight");
static_assert(offsetof(FRigUnit_FABRIKItemArray, bPropagateToChildren) == 0x88, "Offset mismatch for FRigUnit_FABRIKItemArray::bPropagateToChildren");
static_assert(offsetof(FRigUnit_FABRIKItemArray, MaxIterations) == 0x8c, "Offset mismatch for FRigUnit_FABRIKItemArray::MaxIterations");
static_assert(offsetof(FRigUnit_FABRIKItemArray, WorkData) == 0x90, "Offset mismatch for FRigUnit_FABRIKItemArray::WorkData");
static_assert(offsetof(FRigUnit_FABRIKItemArray, bSetEffectorTransform) == 0xc8, "Offset mismatch for FRigUnit_FABRIKItemArray::bSetEffectorTransform");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FRigUnit_FitChainToCurve_Rotation
{
    FQuat Rotation; // 0x0 (Size: 0x20, Type: StructProperty)
    float Ratio; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0xc]; // 0x24 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_FitChainToCurve_Rotation) == 0x30, "Size mismatch for FRigUnit_FitChainToCurve_Rotation");
static_assert(offsetof(FRigUnit_FitChainToCurve_Rotation, Rotation) == 0x0, "Offset mismatch for FRigUnit_FitChainToCurve_Rotation::Rotation");
static_assert(offsetof(FRigUnit_FitChainToCurve_Rotation, Ratio) == 0x20, "Offset mismatch for FRigUnit_FitChainToCurve_Rotation::Ratio");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FRigUnit_FitChainToCurve_DebugSettings
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float Scale; // 0x4 (Size: 0x4, Type: FloatProperty)
    FLinearColor CurveColor; // 0x8 (Size: 0x10, Type: StructProperty)
    FLinearColor SegmentsColor; // 0x18 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FTransform WorldOffset; // 0x30 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_FitChainToCurve_DebugSettings) == 0x90, "Size mismatch for FRigUnit_FitChainToCurve_DebugSettings");
static_assert(offsetof(FRigUnit_FitChainToCurve_DebugSettings, bEnabled) == 0x0, "Offset mismatch for FRigUnit_FitChainToCurve_DebugSettings::bEnabled");
static_assert(offsetof(FRigUnit_FitChainToCurve_DebugSettings, Scale) == 0x4, "Offset mismatch for FRigUnit_FitChainToCurve_DebugSettings::Scale");
static_assert(offsetof(FRigUnit_FitChainToCurve_DebugSettings, CurveColor) == 0x8, "Offset mismatch for FRigUnit_FitChainToCurve_DebugSettings::CurveColor");
static_assert(offsetof(FRigUnit_FitChainToCurve_DebugSettings, SegmentsColor) == 0x18, "Offset mismatch for FRigUnit_FitChainToCurve_DebugSettings::SegmentsColor");
static_assert(offsetof(FRigUnit_FitChainToCurve_DebugSettings, WorldOffset) == 0x30, "Offset mismatch for FRigUnit_FitChainToCurve_DebugSettings::WorldOffset");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FRigUnit_FitChainToCurve_WorkData
{
    float ChainLength; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FVector> ItemPositions; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<float> ItemSegments; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> CurvePositions; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<float> CurveSegments; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedItems; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ItemRotationA; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ItemRotationB; // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<float> ItemRotationT; // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> ItemLocalTransforms; // 0x88 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_FitChainToCurve_WorkData) == 0x98, "Size mismatch for FRigUnit_FitChainToCurve_WorkData");
static_assert(offsetof(FRigUnit_FitChainToCurve_WorkData, ChainLength) == 0x0, "Offset mismatch for FRigUnit_FitChainToCurve_WorkData::ChainLength");
static_assert(offsetof(FRigUnit_FitChainToCurve_WorkData, ItemPositions) == 0x8, "Offset mismatch for FRigUnit_FitChainToCurve_WorkData::ItemPositions");
static_assert(offsetof(FRigUnit_FitChainToCurve_WorkData, ItemSegments) == 0x18, "Offset mismatch for FRigUnit_FitChainToCurve_WorkData::ItemSegments");
static_assert(offsetof(FRigUnit_FitChainToCurve_WorkData, CurvePositions) == 0x28, "Offset mismatch for FRigUnit_FitChainToCurve_WorkData::CurvePositions");
static_assert(offsetof(FRigUnit_FitChainToCurve_WorkData, CurveSegments) == 0x38, "Offset mismatch for FRigUnit_FitChainToCurve_WorkData::CurveSegments");
static_assert(offsetof(FRigUnit_FitChainToCurve_WorkData, CachedItems) == 0x48, "Offset mismatch for FRigUnit_FitChainToCurve_WorkData::CachedItems");
static_assert(offsetof(FRigUnit_FitChainToCurve_WorkData, ItemRotationA) == 0x58, "Offset mismatch for FRigUnit_FitChainToCurve_WorkData::ItemRotationA");
static_assert(offsetof(FRigUnit_FitChainToCurve_WorkData, ItemRotationB) == 0x68, "Offset mismatch for FRigUnit_FitChainToCurve_WorkData::ItemRotationB");
static_assert(offsetof(FRigUnit_FitChainToCurve_WorkData, ItemRotationT) == 0x78, "Offset mismatch for FRigUnit_FitChainToCurve_WorkData::ItemRotationT");
static_assert(offsetof(FRigUnit_FitChainToCurve_WorkData, ItemLocalTransforms) == 0x88, "Offset mismatch for FRigUnit_FitChainToCurve_WorkData::ItemLocalTransforms");

// Size: 0x220 (Inherited: 0x30, Single: 0x1f0)
struct FRigUnit_FitChainToCurve : FRigUnit_HighlevelBaseMutable
{
    FName StartBone; // 0x10 (Size: 0x4, Type: NameProperty)
    FName EndBone; // 0x14 (Size: 0x4, Type: NameProperty)
    FRigVMFourPointBezier Bezier; // 0x18 (Size: 0x60, Type: StructProperty)
    uint8_t Alignment; // 0x78 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_79[0x3]; // 0x79 (Size: 0x3, Type: PaddingProperty)
    float Minimum; // 0x7c (Size: 0x4, Type: FloatProperty)
    float Maximum; // 0x80 (Size: 0x4, Type: FloatProperty)
    int32_t SamplingPrecision; // 0x84 (Size: 0x4, Type: IntProperty)
    FVector PrimaryAxis; // 0x88 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0xa0 (Size: 0x18, Type: StructProperty)
    FVector PoleVectorPosition; // 0xb8 (Size: 0x18, Type: StructProperty)
    TArray<FRigUnit_FitChainToCurve_Rotation> Rotations; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType; // 0xe0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_e1[0x3]; // 0xe1 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0xe4 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0xe8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e9[0x7]; // 0xe9 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_FitChainToCurve_DebugSettings DebugSettings; // 0xf0 (Size: 0x90, Type: StructProperty)
    FRigUnit_FitChainToCurve_WorkData WorkData; // 0x180 (Size: 0x98, Type: StructProperty)
    uint8_t Pad_218[0x8]; // 0x218 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_FitChainToCurve) == 0x220, "Size mismatch for FRigUnit_FitChainToCurve");
static_assert(offsetof(FRigUnit_FitChainToCurve, StartBone) == 0x10, "Offset mismatch for FRigUnit_FitChainToCurve::StartBone");
static_assert(offsetof(FRigUnit_FitChainToCurve, EndBone) == 0x14, "Offset mismatch for FRigUnit_FitChainToCurve::EndBone");
static_assert(offsetof(FRigUnit_FitChainToCurve, Bezier) == 0x18, "Offset mismatch for FRigUnit_FitChainToCurve::Bezier");
static_assert(offsetof(FRigUnit_FitChainToCurve, Alignment) == 0x78, "Offset mismatch for FRigUnit_FitChainToCurve::Alignment");
static_assert(offsetof(FRigUnit_FitChainToCurve, Minimum) == 0x7c, "Offset mismatch for FRigUnit_FitChainToCurve::Minimum");
static_assert(offsetof(FRigUnit_FitChainToCurve, Maximum) == 0x80, "Offset mismatch for FRigUnit_FitChainToCurve::Maximum");
static_assert(offsetof(FRigUnit_FitChainToCurve, SamplingPrecision) == 0x84, "Offset mismatch for FRigUnit_FitChainToCurve::SamplingPrecision");
static_assert(offsetof(FRigUnit_FitChainToCurve, PrimaryAxis) == 0x88, "Offset mismatch for FRigUnit_FitChainToCurve::PrimaryAxis");
static_assert(offsetof(FRigUnit_FitChainToCurve, SecondaryAxis) == 0xa0, "Offset mismatch for FRigUnit_FitChainToCurve::SecondaryAxis");
static_assert(offsetof(FRigUnit_FitChainToCurve, PoleVectorPosition) == 0xb8, "Offset mismatch for FRigUnit_FitChainToCurve::PoleVectorPosition");
static_assert(offsetof(FRigUnit_FitChainToCurve, Rotations) == 0xd0, "Offset mismatch for FRigUnit_FitChainToCurve::Rotations");
static_assert(offsetof(FRigUnit_FitChainToCurve, RotationEaseType) == 0xe0, "Offset mismatch for FRigUnit_FitChainToCurve::RotationEaseType");
static_assert(offsetof(FRigUnit_FitChainToCurve, Weight) == 0xe4, "Offset mismatch for FRigUnit_FitChainToCurve::Weight");
static_assert(offsetof(FRigUnit_FitChainToCurve, bPropagateToChildren) == 0xe8, "Offset mismatch for FRigUnit_FitChainToCurve::bPropagateToChildren");
static_assert(offsetof(FRigUnit_FitChainToCurve, DebugSettings) == 0xf0, "Offset mismatch for FRigUnit_FitChainToCurve::DebugSettings");
static_assert(offsetof(FRigUnit_FitChainToCurve, WorkData) == 0x180, "Offset mismatch for FRigUnit_FitChainToCurve::WorkData");

// Size: 0x230 (Inherited: 0x30, Single: 0x200)
struct FRigUnit_FitChainToCurvePerItem : FRigUnit_HighlevelBaseMutable
{
    FRigElementKeyCollection Items; // 0x10 (Size: 0x10, Type: StructProperty)
    FRigVMFourPointBezier Bezier; // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t Alignment; // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_81[0x3]; // 0x81 (Size: 0x3, Type: PaddingProperty)
    float Minimum; // 0x84 (Size: 0x4, Type: FloatProperty)
    float Maximum; // 0x88 (Size: 0x4, Type: FloatProperty)
    int32_t SamplingPrecision; // 0x8c (Size: 0x4, Type: IntProperty)
    FVector PrimaryAxis; // 0x90 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0xa8 (Size: 0x18, Type: StructProperty)
    FVector PoleVectorPosition; // 0xc0 (Size: 0x18, Type: StructProperty)
    TArray<FRigUnit_FitChainToCurve_Rotation> Rotations; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType; // 0xe8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_e9[0x3]; // 0xe9 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0xec (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0xf0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f1[0xf]; // 0xf1 (Size: 0xf, Type: PaddingProperty)
    FRigUnit_FitChainToCurve_DebugSettings DebugSettings; // 0x100 (Size: 0x90, Type: StructProperty)
    FRigUnit_FitChainToCurve_WorkData WorkData; // 0x190 (Size: 0x98, Type: StructProperty)
    uint8_t Pad_228[0x8]; // 0x228 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_FitChainToCurvePerItem) == 0x230, "Size mismatch for FRigUnit_FitChainToCurvePerItem");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, Items) == 0x10, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::Items");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, Bezier) == 0x20, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::Bezier");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, Alignment) == 0x80, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::Alignment");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, Minimum) == 0x84, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::Minimum");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, Maximum) == 0x88, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::Maximum");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, SamplingPrecision) == 0x8c, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::SamplingPrecision");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, PrimaryAxis) == 0x90, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::PrimaryAxis");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, SecondaryAxis) == 0xa8, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::SecondaryAxis");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, PoleVectorPosition) == 0xc0, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::PoleVectorPosition");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, Rotations) == 0xd8, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::Rotations");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, RotationEaseType) == 0xe8, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::RotationEaseType");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, Weight) == 0xec, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::Weight");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, bPropagateToChildren) == 0xf0, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::bPropagateToChildren");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, DebugSettings) == 0x100, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::DebugSettings");
static_assert(offsetof(FRigUnit_FitChainToCurvePerItem, WorkData) == 0x190, "Offset mismatch for FRigUnit_FitChainToCurvePerItem::WorkData");

// Size: 0x230 (Inherited: 0x30, Single: 0x200)
struct FRigUnit_FitChainToCurveItemArray : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FRigVMFourPointBezier Bezier; // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t Alignment; // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_81[0x3]; // 0x81 (Size: 0x3, Type: PaddingProperty)
    float Minimum; // 0x84 (Size: 0x4, Type: FloatProperty)
    float Maximum; // 0x88 (Size: 0x4, Type: FloatProperty)
    int32_t SamplingPrecision; // 0x8c (Size: 0x4, Type: IntProperty)
    FVector PrimaryAxis; // 0x90 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0xa8 (Size: 0x18, Type: StructProperty)
    FVector PoleVectorPosition; // 0xc0 (Size: 0x18, Type: StructProperty)
    TArray<FRigUnit_FitChainToCurve_Rotation> Rotations; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType; // 0xe8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_e9[0x3]; // 0xe9 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0xec (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0xf0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f1[0xf]; // 0xf1 (Size: 0xf, Type: PaddingProperty)
    FRigUnit_FitChainToCurve_DebugSettings DebugSettings; // 0x100 (Size: 0x90, Type: StructProperty)
    FRigUnit_FitChainToCurve_WorkData WorkData; // 0x190 (Size: 0x98, Type: StructProperty)
    uint8_t Pad_228[0x8]; // 0x228 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_FitChainToCurveItemArray) == 0x230, "Size mismatch for FRigUnit_FitChainToCurveItemArray");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, Items) == 0x10, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::Items");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, Bezier) == 0x20, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::Bezier");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, Alignment) == 0x80, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::Alignment");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, Minimum) == 0x84, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::Minimum");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, Maximum) == 0x88, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::Maximum");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, SamplingPrecision) == 0x8c, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::SamplingPrecision");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, PrimaryAxis) == 0x90, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::PrimaryAxis");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, SecondaryAxis) == 0xa8, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::SecondaryAxis");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, PoleVectorPosition) == 0xc0, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::PoleVectorPosition");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, Rotations) == 0xd8, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::Rotations");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, RotationEaseType) == 0xe8, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::RotationEaseType");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, Weight) == 0xec, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::Weight");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, bPropagateToChildren) == 0xf0, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::bPropagateToChildren");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, DebugSettings) == 0x100, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::DebugSettings");
static_assert(offsetof(FRigUnit_FitChainToCurveItemArray, WorkData) == 0x190, "Offset mismatch for FRigUnit_FitChainToCurveItemArray::WorkData");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FRigUnit_ModifyBoneTransforms_PerBone
{
    FName bone; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0xc]; // 0x4 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ModifyBoneTransforms_PerBone) == 0x70, "Size mismatch for FRigUnit_ModifyBoneTransforms_PerBone");
static_assert(offsetof(FRigUnit_ModifyBoneTransforms_PerBone, bone) == 0x0, "Offset mismatch for FRigUnit_ModifyBoneTransforms_PerBone::bone");
static_assert(offsetof(FRigUnit_ModifyBoneTransforms_PerBone, Transform) == 0x10, "Offset mismatch for FRigUnit_ModifyBoneTransforms_PerBone::Transform");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigUnit_ModifyTransforms_WorkData
{
    TArray<FCachedRigElement> CachedItems; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_ModifyTransforms_WorkData) == 0x10, "Size mismatch for FRigUnit_ModifyTransforms_WorkData");
static_assert(offsetof(FRigUnit_ModifyTransforms_WorkData, CachedItems) == 0x0, "Offset mismatch for FRigUnit_ModifyTransforms_WorkData::CachedItems");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FRigUnit_ModifyBoneTransforms_WorkData : FRigUnit_ModifyTransforms_WorkData
{
};

static_assert(sizeof(FRigUnit_ModifyBoneTransforms_WorkData) == 0x10, "Size mismatch for FRigUnit_ModifyBoneTransforms_WorkData");

// Size: 0x40 (Inherited: 0x30, Single: 0x10)
struct FRigUnit_ModifyBoneTransforms : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigUnit_ModifyBoneTransforms_PerBone> BoneToModify; // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x20 (Size: 0x4, Type: FloatProperty)
    float WeightMinimum; // 0x24 (Size: 0x4, Type: FloatProperty)
    float WeightMaximum; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Mode; // 0x2c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
    FRigUnit_ModifyBoneTransforms_WorkData WorkData; // 0x30 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ModifyBoneTransforms) == 0x40, "Size mismatch for FRigUnit_ModifyBoneTransforms");
static_assert(offsetof(FRigUnit_ModifyBoneTransforms, BoneToModify) == 0x10, "Offset mismatch for FRigUnit_ModifyBoneTransforms::BoneToModify");
static_assert(offsetof(FRigUnit_ModifyBoneTransforms, Weight) == 0x20, "Offset mismatch for FRigUnit_ModifyBoneTransforms::Weight");
static_assert(offsetof(FRigUnit_ModifyBoneTransforms, WeightMinimum) == 0x24, "Offset mismatch for FRigUnit_ModifyBoneTransforms::WeightMinimum");
static_assert(offsetof(FRigUnit_ModifyBoneTransforms, WeightMaximum) == 0x28, "Offset mismatch for FRigUnit_ModifyBoneTransforms::WeightMaximum");
static_assert(offsetof(FRigUnit_ModifyBoneTransforms, Mode) == 0x2c, "Offset mismatch for FRigUnit_ModifyBoneTransforms::Mode");
static_assert(offsetof(FRigUnit_ModifyBoneTransforms, WorkData) == 0x30, "Offset mismatch for FRigUnit_ModifyBoneTransforms::WorkData");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FRigUnit_ModifyTransforms_PerItem
{
    FRigElementKey Item; // 0x0 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ModifyTransforms_PerItem) == 0x70, "Size mismatch for FRigUnit_ModifyTransforms_PerItem");
static_assert(offsetof(FRigUnit_ModifyTransforms_PerItem, Item) == 0x0, "Offset mismatch for FRigUnit_ModifyTransforms_PerItem::Item");
static_assert(offsetof(FRigUnit_ModifyTransforms_PerItem, Transform) == 0x10, "Offset mismatch for FRigUnit_ModifyTransforms_PerItem::Transform");

// Size: 0x40 (Inherited: 0x30, Single: 0x10)
struct FRigUnit_ModifyTransforms : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigUnit_ModifyTransforms_PerItem> ItemToModify; // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x20 (Size: 0x4, Type: FloatProperty)
    float WeightMinimum; // 0x24 (Size: 0x4, Type: FloatProperty)
    float WeightMaximum; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Mode; // 0x2c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
    FRigUnit_ModifyTransforms_WorkData WorkData; // 0x30 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ModifyTransforms) == 0x40, "Size mismatch for FRigUnit_ModifyTransforms");
static_assert(offsetof(FRigUnit_ModifyTransforms, ItemToModify) == 0x10, "Offset mismatch for FRigUnit_ModifyTransforms::ItemToModify");
static_assert(offsetof(FRigUnit_ModifyTransforms, Weight) == 0x20, "Offset mismatch for FRigUnit_ModifyTransforms::Weight");
static_assert(offsetof(FRigUnit_ModifyTransforms, WeightMinimum) == 0x24, "Offset mismatch for FRigUnit_ModifyTransforms::WeightMinimum");
static_assert(offsetof(FRigUnit_ModifyTransforms, WeightMaximum) == 0x28, "Offset mismatch for FRigUnit_ModifyTransforms::WeightMaximum");
static_assert(offsetof(FRigUnit_ModifyTransforms, Mode) == 0x2c, "Offset mismatch for FRigUnit_ModifyTransforms::Mode");
static_assert(offsetof(FRigUnit_ModifyTransforms, WorkData) == 0x30, "Offset mismatch for FRigUnit_ModifyTransforms::WorkData");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FRigUnit_MultiFABRIK_WorkData
{
};

static_assert(sizeof(FRigUnit_MultiFABRIK_WorkData) == 0x68, "Size mismatch for FRigUnit_MultiFABRIK_WorkData");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FRigUnit_MultiFABRIK_EndEffector
{
    FName bone; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector Location; // 0x8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_MultiFABRIK_EndEffector) == 0x20, "Size mismatch for FRigUnit_MultiFABRIK_EndEffector");
static_assert(offsetof(FRigUnit_MultiFABRIK_EndEffector, bone) == 0x0, "Offset mismatch for FRigUnit_MultiFABRIK_EndEffector::bone");
static_assert(offsetof(FRigUnit_MultiFABRIK_EndEffector, Location) == 0x8, "Offset mismatch for FRigUnit_MultiFABRIK_EndEffector::Location");

// Size: 0xa8 (Inherited: 0x30, Single: 0x78)
struct FRigUnit_MultiFABRIK : FRigUnit_HighlevelBaseMutable
{
    FName RootBone; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    TArray<FRigUnit_MultiFABRIK_EndEffector> Effectors; // 0x18 (Size: 0x10, Type: ArrayProperty)
    float Precision; // 0x28 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x2c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
    int32_t MaxIterations; // 0x30 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    FRigUnit_MultiFABRIK_WorkData WorkData; // 0x38 (Size: 0x68, Type: StructProperty)
    bool bIsInitialized; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0x7]; // 0xa1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_MultiFABRIK) == 0xa8, "Size mismatch for FRigUnit_MultiFABRIK");
static_assert(offsetof(FRigUnit_MultiFABRIK, RootBone) == 0x10, "Offset mismatch for FRigUnit_MultiFABRIK::RootBone");
static_assert(offsetof(FRigUnit_MultiFABRIK, Effectors) == 0x18, "Offset mismatch for FRigUnit_MultiFABRIK::Effectors");
static_assert(offsetof(FRigUnit_MultiFABRIK, Precision) == 0x28, "Offset mismatch for FRigUnit_MultiFABRIK::Precision");
static_assert(offsetof(FRigUnit_MultiFABRIK, bPropagateToChildren) == 0x2c, "Offset mismatch for FRigUnit_MultiFABRIK::bPropagateToChildren");
static_assert(offsetof(FRigUnit_MultiFABRIK, MaxIterations) == 0x30, "Offset mismatch for FRigUnit_MultiFABRIK::MaxIterations");
static_assert(offsetof(FRigUnit_MultiFABRIK, WorkData) == 0x38, "Offset mismatch for FRigUnit_MultiFABRIK::WorkData");
static_assert(offsetof(FRigUnit_MultiFABRIK, bIsInitialized) == 0xa0, "Offset mismatch for FRigUnit_MultiFABRIK::bIsInitialized");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FRigUnit_SlideChain_WorkData
{
    float ChainLength; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<float> ItemSegments; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedItems; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> Transforms; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> BlendedTransforms; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_SlideChain_WorkData) == 0x48, "Size mismatch for FRigUnit_SlideChain_WorkData");
static_assert(offsetof(FRigUnit_SlideChain_WorkData, ChainLength) == 0x0, "Offset mismatch for FRigUnit_SlideChain_WorkData::ChainLength");
static_assert(offsetof(FRigUnit_SlideChain_WorkData, ItemSegments) == 0x8, "Offset mismatch for FRigUnit_SlideChain_WorkData::ItemSegments");
static_assert(offsetof(FRigUnit_SlideChain_WorkData, CachedItems) == 0x18, "Offset mismatch for FRigUnit_SlideChain_WorkData::CachedItems");
static_assert(offsetof(FRigUnit_SlideChain_WorkData, Transforms) == 0x28, "Offset mismatch for FRigUnit_SlideChain_WorkData::Transforms");
static_assert(offsetof(FRigUnit_SlideChain_WorkData, BlendedTransforms) == 0x38, "Offset mismatch for FRigUnit_SlideChain_WorkData::BlendedTransforms");

// Size: 0x68 (Inherited: 0x30, Single: 0x38)
struct FRigUnit_SlideChain : FRigUnit_HighlevelBaseMutable
{
    FName StartBone; // 0x10 (Size: 0x4, Type: NameProperty)
    FName EndBone; // 0x14 (Size: 0x4, Type: NameProperty)
    float SlideAmount; // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x3]; // 0x1d (Size: 0x3, Type: PaddingProperty)
    FRigUnit_SlideChain_WorkData WorkData; // 0x20 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SlideChain) == 0x68, "Size mismatch for FRigUnit_SlideChain");
static_assert(offsetof(FRigUnit_SlideChain, StartBone) == 0x10, "Offset mismatch for FRigUnit_SlideChain::StartBone");
static_assert(offsetof(FRigUnit_SlideChain, EndBone) == 0x14, "Offset mismatch for FRigUnit_SlideChain::EndBone");
static_assert(offsetof(FRigUnit_SlideChain, SlideAmount) == 0x18, "Offset mismatch for FRigUnit_SlideChain::SlideAmount");
static_assert(offsetof(FRigUnit_SlideChain, bPropagateToChildren) == 0x1c, "Offset mismatch for FRigUnit_SlideChain::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SlideChain, WorkData) == 0x20, "Offset mismatch for FRigUnit_SlideChain::WorkData");

// Size: 0x70 (Inherited: 0x30, Single: 0x40)
struct FRigUnit_SlideChainPerItem : FRigUnit_HighlevelBaseMutable
{
    FRigElementKeyCollection Items; // 0x10 (Size: 0x10, Type: StructProperty)
    float SlideAmount; // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x24 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_25[0x3]; // 0x25 (Size: 0x3, Type: PaddingProperty)
    FRigUnit_SlideChain_WorkData WorkData; // 0x28 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SlideChainPerItem) == 0x70, "Size mismatch for FRigUnit_SlideChainPerItem");
static_assert(offsetof(FRigUnit_SlideChainPerItem, Items) == 0x10, "Offset mismatch for FRigUnit_SlideChainPerItem::Items");
static_assert(offsetof(FRigUnit_SlideChainPerItem, SlideAmount) == 0x20, "Offset mismatch for FRigUnit_SlideChainPerItem::SlideAmount");
static_assert(offsetof(FRigUnit_SlideChainPerItem, bPropagateToChildren) == 0x24, "Offset mismatch for FRigUnit_SlideChainPerItem::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SlideChainPerItem, WorkData) == 0x28, "Offset mismatch for FRigUnit_SlideChainPerItem::WorkData");

// Size: 0x70 (Inherited: 0x30, Single: 0x40)
struct FRigUnit_SlideChainItemArray : FRigUnit_HighlevelBaseMutable
{
    TArray<FRigElementKey> Items; // 0x10 (Size: 0x10, Type: ArrayProperty)
    float SlideAmount; // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x24 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_25[0x3]; // 0x25 (Size: 0x3, Type: PaddingProperty)
    FRigUnit_SlideChain_WorkData WorkData; // 0x28 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SlideChainItemArray) == 0x70, "Size mismatch for FRigUnit_SlideChainItemArray");
static_assert(offsetof(FRigUnit_SlideChainItemArray, Items) == 0x10, "Offset mismatch for FRigUnit_SlideChainItemArray::Items");
static_assert(offsetof(FRigUnit_SlideChainItemArray, SlideAmount) == 0x20, "Offset mismatch for FRigUnit_SlideChainItemArray::SlideAmount");
static_assert(offsetof(FRigUnit_SlideChainItemArray, bPropagateToChildren) == 0x24, "Offset mismatch for FRigUnit_SlideChainItemArray::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SlideChainItemArray, WorkData) == 0x28, "Offset mismatch for FRigUnit_SlideChainItemArray::WorkData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRegionScaleFactors
{
    float PositiveWidth; // 0x0 (Size: 0x4, Type: FloatProperty)
    float NegativeWidth; // 0x4 (Size: 0x4, Type: FloatProperty)
    float PositiveHeight; // 0x8 (Size: 0x4, Type: FloatProperty)
    float NegativeHeight; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRegionScaleFactors) == 0x10, "Size mismatch for FRegionScaleFactors");
static_assert(offsetof(FRegionScaleFactors, PositiveWidth) == 0x0, "Offset mismatch for FRegionScaleFactors::PositiveWidth");
static_assert(offsetof(FRegionScaleFactors, NegativeWidth) == 0x4, "Offset mismatch for FRegionScaleFactors::NegativeWidth");
static_assert(offsetof(FRegionScaleFactors, PositiveHeight) == 0x8, "Offset mismatch for FRegionScaleFactors::PositiveHeight");
static_assert(offsetof(FRegionScaleFactors, NegativeHeight) == 0xc, "Offset mismatch for FRegionScaleFactors::NegativeHeight");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FSphericalRegion
{
};

static_assert(sizeof(FSphericalRegion) == 0x14, "Size mismatch for FSphericalRegion");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSphericalPoseReaderDebugSettings
{
    bool bDrawDebug; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bDraw2D; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bDrawLocalAxes; // 0x2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3[0x1]; // 0x3 (Size: 0x1, Type: PaddingProperty)
    float DebugScale; // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t DebugSegments; // 0x8 (Size: 0x4, Type: IntProperty)
    float DebugThickness; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FSphericalPoseReaderDebugSettings) == 0x10, "Size mismatch for FSphericalPoseReaderDebugSettings");
static_assert(offsetof(FSphericalPoseReaderDebugSettings, bDrawDebug) == 0x0, "Offset mismatch for FSphericalPoseReaderDebugSettings::bDrawDebug");
static_assert(offsetof(FSphericalPoseReaderDebugSettings, bDraw2D) == 0x1, "Offset mismatch for FSphericalPoseReaderDebugSettings::bDraw2D");
static_assert(offsetof(FSphericalPoseReaderDebugSettings, bDrawLocalAxes) == 0x2, "Offset mismatch for FSphericalPoseReaderDebugSettings::bDrawLocalAxes");
static_assert(offsetof(FSphericalPoseReaderDebugSettings, DebugScale) == 0x4, "Offset mismatch for FSphericalPoseReaderDebugSettings::DebugScale");
static_assert(offsetof(FSphericalPoseReaderDebugSettings, DebugSegments) == 0x8, "Offset mismatch for FSphericalPoseReaderDebugSettings::DebugSegments");
static_assert(offsetof(FSphericalPoseReaderDebugSettings, DebugThickness) == 0xc, "Offset mismatch for FSphericalPoseReaderDebugSettings::DebugThickness");

// Size: 0x1a0 (Inherited: 0x30, Single: 0x170)
struct FRigUnit_SphericalPoseReader : FRigUnit_HighlevelBaseMutable
{
    float OutputParam; // 0x10 (Size: 0x4, Type: FloatProperty)
    FRigElementKey DriverItem; // 0x14 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FVector DriverAxis; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector RotationOffset; // 0x38 (Size: 0x18, Type: StructProperty)
    float ActiveRegionSize; // 0x50 (Size: 0x4, Type: FloatProperty)
    FRegionScaleFactors ActiveRegionScaleFactors; // 0x54 (Size: 0x10, Type: StructProperty)
    float FalloffSize; // 0x64 (Size: 0x4, Type: FloatProperty)
    FRegionScaleFactors FalloffRegionScaleFactors; // 0x68 (Size: 0x10, Type: StructProperty)
    bool FlipWidthScaling; // 0x78 (Size: 0x1, Type: BoolProperty)
    bool FlipHeightScaling; // 0x79 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7a[0x2]; // 0x7a (Size: 0x2, Type: PaddingProperty)
    FRigElementKey OptionalParentItem; // 0x7c (Size: 0x8, Type: StructProperty)
    FSphericalPoseReaderDebugSettings Debug; // 0x84 (Size: 0x10, Type: StructProperty)
    FSphericalRegion InnerRegion; // 0x94 (Size: 0x14, Type: StructProperty)
    FSphericalRegion OuterRegion; // 0xa8 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
    FVector DriverNormal; // 0xc0 (Size: 0x18, Type: StructProperty)
    FVector Driver2D; // 0xd8 (Size: 0x18, Type: StructProperty)
    FCachedRigElement DriverCache; // 0xf0 (Size: 0x18, Type: StructProperty)
    FCachedRigElement OptionalParentCache; // 0x108 (Size: 0x18, Type: StructProperty)
    FTransform LocalDriverTransformInit; // 0x120 (Size: 0x60, Type: StructProperty)
    FVector CachedRotationOffset; // 0x180 (Size: 0x18, Type: StructProperty)
    bool bCachedInitTransforms; // 0x198 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_199[0x7]; // 0x199 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SphericalPoseReader) == 0x1a0, "Size mismatch for FRigUnit_SphericalPoseReader");
static_assert(offsetof(FRigUnit_SphericalPoseReader, OutputParam) == 0x10, "Offset mismatch for FRigUnit_SphericalPoseReader::OutputParam");
static_assert(offsetof(FRigUnit_SphericalPoseReader, DriverItem) == 0x14, "Offset mismatch for FRigUnit_SphericalPoseReader::DriverItem");
static_assert(offsetof(FRigUnit_SphericalPoseReader, DriverAxis) == 0x20, "Offset mismatch for FRigUnit_SphericalPoseReader::DriverAxis");
static_assert(offsetof(FRigUnit_SphericalPoseReader, RotationOffset) == 0x38, "Offset mismatch for FRigUnit_SphericalPoseReader::RotationOffset");
static_assert(offsetof(FRigUnit_SphericalPoseReader, ActiveRegionSize) == 0x50, "Offset mismatch for FRigUnit_SphericalPoseReader::ActiveRegionSize");
static_assert(offsetof(FRigUnit_SphericalPoseReader, ActiveRegionScaleFactors) == 0x54, "Offset mismatch for FRigUnit_SphericalPoseReader::ActiveRegionScaleFactors");
static_assert(offsetof(FRigUnit_SphericalPoseReader, FalloffSize) == 0x64, "Offset mismatch for FRigUnit_SphericalPoseReader::FalloffSize");
static_assert(offsetof(FRigUnit_SphericalPoseReader, FalloffRegionScaleFactors) == 0x68, "Offset mismatch for FRigUnit_SphericalPoseReader::FalloffRegionScaleFactors");
static_assert(offsetof(FRigUnit_SphericalPoseReader, FlipWidthScaling) == 0x78, "Offset mismatch for FRigUnit_SphericalPoseReader::FlipWidthScaling");
static_assert(offsetof(FRigUnit_SphericalPoseReader, FlipHeightScaling) == 0x79, "Offset mismatch for FRigUnit_SphericalPoseReader::FlipHeightScaling");
static_assert(offsetof(FRigUnit_SphericalPoseReader, OptionalParentItem) == 0x7c, "Offset mismatch for FRigUnit_SphericalPoseReader::OptionalParentItem");
static_assert(offsetof(FRigUnit_SphericalPoseReader, Debug) == 0x84, "Offset mismatch for FRigUnit_SphericalPoseReader::Debug");
static_assert(offsetof(FRigUnit_SphericalPoseReader, InnerRegion) == 0x94, "Offset mismatch for FRigUnit_SphericalPoseReader::InnerRegion");
static_assert(offsetof(FRigUnit_SphericalPoseReader, OuterRegion) == 0xa8, "Offset mismatch for FRigUnit_SphericalPoseReader::OuterRegion");
static_assert(offsetof(FRigUnit_SphericalPoseReader, DriverNormal) == 0xc0, "Offset mismatch for FRigUnit_SphericalPoseReader::DriverNormal");
static_assert(offsetof(FRigUnit_SphericalPoseReader, Driver2D) == 0xd8, "Offset mismatch for FRigUnit_SphericalPoseReader::Driver2D");
static_assert(offsetof(FRigUnit_SphericalPoseReader, DriverCache) == 0xf0, "Offset mismatch for FRigUnit_SphericalPoseReader::DriverCache");
static_assert(offsetof(FRigUnit_SphericalPoseReader, OptionalParentCache) == 0x108, "Offset mismatch for FRigUnit_SphericalPoseReader::OptionalParentCache");
static_assert(offsetof(FRigUnit_SphericalPoseReader, LocalDriverTransformInit) == 0x120, "Offset mismatch for FRigUnit_SphericalPoseReader::LocalDriverTransformInit");
static_assert(offsetof(FRigUnit_SphericalPoseReader, CachedRotationOffset) == 0x180, "Offset mismatch for FRigUnit_SphericalPoseReader::CachedRotationOffset");
static_assert(offsetof(FRigUnit_SphericalPoseReader, bCachedInitTransforms) == 0x198, "Offset mismatch for FRigUnit_SphericalPoseReader::bCachedInitTransforms");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FRigUnit_SpringIK_DebugSettings
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float Scale; // 0x4 (Size: 0x4, Type: FloatProperty)
    FLinearColor Color; // 0x8 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_18[0x8]; // 0x18 (Size: 0x8, Type: PaddingProperty)
    FTransform WorldOffset; // 0x20 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SpringIK_DebugSettings) == 0x80, "Size mismatch for FRigUnit_SpringIK_DebugSettings");
static_assert(offsetof(FRigUnit_SpringIK_DebugSettings, bEnabled) == 0x0, "Offset mismatch for FRigUnit_SpringIK_DebugSettings::bEnabled");
static_assert(offsetof(FRigUnit_SpringIK_DebugSettings, Scale) == 0x4, "Offset mismatch for FRigUnit_SpringIK_DebugSettings::Scale");
static_assert(offsetof(FRigUnit_SpringIK_DebugSettings, Color) == 0x8, "Offset mismatch for FRigUnit_SpringIK_DebugSettings::Color");
static_assert(offsetof(FRigUnit_SpringIK_DebugSettings, WorldOffset) == 0x20, "Offset mismatch for FRigUnit_SpringIK_DebugSettings::WorldOffset");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FRigUnit_SpringIK_WorkData
{
    TArray<FCachedRigElement> CachedBones; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedPoleVector; // 0x10 (Size: 0x18, Type: StructProperty)
    TArray<FTransform> Transforms; // 0x28 (Size: 0x10, Type: ArrayProperty)
    FCRSimPointContainer Simulation; // 0x38 (Size: 0x78, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SpringIK_WorkData) == 0xb0, "Size mismatch for FRigUnit_SpringIK_WorkData");
static_assert(offsetof(FRigUnit_SpringIK_WorkData, CachedBones) == 0x0, "Offset mismatch for FRigUnit_SpringIK_WorkData::CachedBones");
static_assert(offsetof(FRigUnit_SpringIK_WorkData, CachedPoleVector) == 0x10, "Offset mismatch for FRigUnit_SpringIK_WorkData::CachedPoleVector");
static_assert(offsetof(FRigUnit_SpringIK_WorkData, Transforms) == 0x28, "Offset mismatch for FRigUnit_SpringIK_WorkData::Transforms");
static_assert(offsetof(FRigUnit_SpringIK_WorkData, Simulation) == 0x38, "Offset mismatch for FRigUnit_SpringIK_WorkData::Simulation");

// Size: 0x1c0 (Inherited: 0x30, Single: 0x190)
struct FRigUnit_SpringIK : FRigUnit_HighlevelBaseMutable
{
    FName StartBone; // 0x10 (Size: 0x4, Type: NameProperty)
    FName EndBone; // 0x14 (Size: 0x4, Type: NameProperty)
    float HierarchyStrength; // 0x18 (Size: 0x4, Type: FloatProperty)
    float EffectorStrength; // 0x1c (Size: 0x4, Type: FloatProperty)
    float EffectorRatio; // 0x20 (Size: 0x4, Type: FloatProperty)
    float RootStrength; // 0x24 (Size: 0x4, Type: FloatProperty)
    float RootRatio; // 0x28 (Size: 0x4, Type: FloatProperty)
    float Damping; // 0x2c (Size: 0x4, Type: FloatProperty)
    FVector PoleVector; // 0x30 (Size: 0x18, Type: StructProperty)
    bool bFlipPolePlane; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t PoleVectorKind; // 0x49 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_4a[0x2]; // 0x4a (Size: 0x2, Type: PaddingProperty)
    FName PoleVectorSpace; // 0x4c (Size: 0x4, Type: NameProperty)
    FVector PrimaryAxis; // 0x50 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0x68 (Size: 0x18, Type: StructProperty)
    bool bLiveSimulation; // 0x80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_81[0x3]; // 0x81 (Size: 0x3, Type: PaddingProperty)
    int32_t Iterations; // 0x84 (Size: 0x4, Type: IntProperty)
    bool bLimitLocalPosition; // 0x88 (Size: 0x1, Type: BoolProperty)
    bool bPropagateToChildren; // 0x89 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8a[0x6]; // 0x8a (Size: 0x6, Type: PaddingProperty)
    FRigUnit_SpringIK_DebugSettings DebugSettings; // 0x90 (Size: 0x80, Type: StructProperty)
    FRigUnit_SpringIK_WorkData WorkData; // 0x110 (Size: 0xb0, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SpringIK) == 0x1c0, "Size mismatch for FRigUnit_SpringIK");
static_assert(offsetof(FRigUnit_SpringIK, StartBone) == 0x10, "Offset mismatch for FRigUnit_SpringIK::StartBone");
static_assert(offsetof(FRigUnit_SpringIK, EndBone) == 0x14, "Offset mismatch for FRigUnit_SpringIK::EndBone");
static_assert(offsetof(FRigUnit_SpringIK, HierarchyStrength) == 0x18, "Offset mismatch for FRigUnit_SpringIK::HierarchyStrength");
static_assert(offsetof(FRigUnit_SpringIK, EffectorStrength) == 0x1c, "Offset mismatch for FRigUnit_SpringIK::EffectorStrength");
static_assert(offsetof(FRigUnit_SpringIK, EffectorRatio) == 0x20, "Offset mismatch for FRigUnit_SpringIK::EffectorRatio");
static_assert(offsetof(FRigUnit_SpringIK, RootStrength) == 0x24, "Offset mismatch for FRigUnit_SpringIK::RootStrength");
static_assert(offsetof(FRigUnit_SpringIK, RootRatio) == 0x28, "Offset mismatch for FRigUnit_SpringIK::RootRatio");
static_assert(offsetof(FRigUnit_SpringIK, Damping) == 0x2c, "Offset mismatch for FRigUnit_SpringIK::Damping");
static_assert(offsetof(FRigUnit_SpringIK, PoleVector) == 0x30, "Offset mismatch for FRigUnit_SpringIK::PoleVector");
static_assert(offsetof(FRigUnit_SpringIK, bFlipPolePlane) == 0x48, "Offset mismatch for FRigUnit_SpringIK::bFlipPolePlane");
static_assert(offsetof(FRigUnit_SpringIK, PoleVectorKind) == 0x49, "Offset mismatch for FRigUnit_SpringIK::PoleVectorKind");
static_assert(offsetof(FRigUnit_SpringIK, PoleVectorSpace) == 0x4c, "Offset mismatch for FRigUnit_SpringIK::PoleVectorSpace");
static_assert(offsetof(FRigUnit_SpringIK, PrimaryAxis) == 0x50, "Offset mismatch for FRigUnit_SpringIK::PrimaryAxis");
static_assert(offsetof(FRigUnit_SpringIK, SecondaryAxis) == 0x68, "Offset mismatch for FRigUnit_SpringIK::SecondaryAxis");
static_assert(offsetof(FRigUnit_SpringIK, bLiveSimulation) == 0x80, "Offset mismatch for FRigUnit_SpringIK::bLiveSimulation");
static_assert(offsetof(FRigUnit_SpringIK, Iterations) == 0x84, "Offset mismatch for FRigUnit_SpringIK::Iterations");
static_assert(offsetof(FRigUnit_SpringIK, bLimitLocalPosition) == 0x88, "Offset mismatch for FRigUnit_SpringIK::bLimitLocalPosition");
static_assert(offsetof(FRigUnit_SpringIK, bPropagateToChildren) == 0x89, "Offset mismatch for FRigUnit_SpringIK::bPropagateToChildren");
static_assert(offsetof(FRigUnit_SpringIK, DebugSettings) == 0x90, "Offset mismatch for FRigUnit_SpringIK::DebugSettings");
static_assert(offsetof(FRigUnit_SpringIK, WorkData) == 0x110, "Offset mismatch for FRigUnit_SpringIK::WorkData");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FConstraintTarget
{
    FTransform Transform; // 0x0 (Size: 0x60, Type: StructProperty)
    float Weight; // 0x60 (Size: 0x4, Type: FloatProperty)
    bool bMaintainOffset; // 0x64 (Size: 0x1, Type: BoolProperty)
    FTransformFilter Filter; // 0x65 (Size: 0x9, Type: StructProperty)
    uint8_t Pad_6e[0x2]; // 0x6e (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FConstraintTarget) == 0x70, "Size mismatch for FConstraintTarget");
static_assert(offsetof(FConstraintTarget, Transform) == 0x0, "Offset mismatch for FConstraintTarget::Transform");
static_assert(offsetof(FConstraintTarget, Weight) == 0x60, "Offset mismatch for FConstraintTarget::Weight");
static_assert(offsetof(FConstraintTarget, bMaintainOffset) == 0x64, "Offset mismatch for FConstraintTarget::bMaintainOffset");
static_assert(offsetof(FConstraintTarget, Filter) == 0x65, "Offset mismatch for FConstraintTarget::Filter");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FRigUnit_TransformConstraint_WorkData
{
    TArray<FConstraintData> ConstraintData; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TMap<int32_t, int32_t> ConstraintDataToTargets; // 0x10 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FRigUnit_TransformConstraint_WorkData) == 0x60, "Size mismatch for FRigUnit_TransformConstraint_WorkData");
static_assert(offsetof(FRigUnit_TransformConstraint_WorkData, ConstraintData) == 0x0, "Offset mismatch for FRigUnit_TransformConstraint_WorkData::ConstraintData");
static_assert(offsetof(FRigUnit_TransformConstraint_WorkData, ConstraintDataToTargets) == 0x10, "Offset mismatch for FRigUnit_TransformConstraint_WorkData::ConstraintDataToTargets");

// Size: 0x100 (Inherited: 0x30, Single: 0xd0)
struct FRigUnit_TransformConstraint : FRigUnit_HighlevelBaseMutable
{
    FName bone; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t BaseTransformSpace; // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_15[0xb]; // 0x15 (Size: 0xb, Type: PaddingProperty)
    FTransform BaseTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    FName BaseBone; // 0x80 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
    TArray<FConstraintTarget> Targets; // 0x88 (Size: 0x10, Type: ArrayProperty)
    bool bUseInitialTransforms; // 0x98 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_TransformConstraint_WorkData WorkData; // 0xa0 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TransformConstraint) == 0x100, "Size mismatch for FRigUnit_TransformConstraint");
static_assert(offsetof(FRigUnit_TransformConstraint, bone) == 0x10, "Offset mismatch for FRigUnit_TransformConstraint::bone");
static_assert(offsetof(FRigUnit_TransformConstraint, BaseTransformSpace) == 0x14, "Offset mismatch for FRigUnit_TransformConstraint::BaseTransformSpace");
static_assert(offsetof(FRigUnit_TransformConstraint, BaseTransform) == 0x20, "Offset mismatch for FRigUnit_TransformConstraint::BaseTransform");
static_assert(offsetof(FRigUnit_TransformConstraint, BaseBone) == 0x80, "Offset mismatch for FRigUnit_TransformConstraint::BaseBone");
static_assert(offsetof(FRigUnit_TransformConstraint, Targets) == 0x88, "Offset mismatch for FRigUnit_TransformConstraint::Targets");
static_assert(offsetof(FRigUnit_TransformConstraint, bUseInitialTransforms) == 0x98, "Offset mismatch for FRigUnit_TransformConstraint::bUseInitialTransforms");
static_assert(offsetof(FRigUnit_TransformConstraint, WorkData) == 0xa0, "Offset mismatch for FRigUnit_TransformConstraint::WorkData");

// Size: 0x100 (Inherited: 0x30, Single: 0xd0)
struct FRigUnit_TransformConstraintPerItem : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t BaseTransformSpace; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    FTransform BaseTransform; // 0x20 (Size: 0x60, Type: StructProperty)
    FRigElementKey BaseItem; // 0x80 (Size: 0x8, Type: StructProperty)
    TArray<FConstraintTarget> Targets; // 0x88 (Size: 0x10, Type: ArrayProperty)
    bool bUseInitialTransforms; // 0x98 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_TransformConstraint_WorkData WorkData; // 0xa0 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TransformConstraintPerItem) == 0x100, "Size mismatch for FRigUnit_TransformConstraintPerItem");
static_assert(offsetof(FRigUnit_TransformConstraintPerItem, Item) == 0x10, "Offset mismatch for FRigUnit_TransformConstraintPerItem::Item");
static_assert(offsetof(FRigUnit_TransformConstraintPerItem, BaseTransformSpace) == 0x18, "Offset mismatch for FRigUnit_TransformConstraintPerItem::BaseTransformSpace");
static_assert(offsetof(FRigUnit_TransformConstraintPerItem, BaseTransform) == 0x20, "Offset mismatch for FRigUnit_TransformConstraintPerItem::BaseTransform");
static_assert(offsetof(FRigUnit_TransformConstraintPerItem, BaseItem) == 0x80, "Offset mismatch for FRigUnit_TransformConstraintPerItem::BaseItem");
static_assert(offsetof(FRigUnit_TransformConstraintPerItem, Targets) == 0x88, "Offset mismatch for FRigUnit_TransformConstraintPerItem::Targets");
static_assert(offsetof(FRigUnit_TransformConstraintPerItem, bUseInitialTransforms) == 0x98, "Offset mismatch for FRigUnit_TransformConstraintPerItem::bUseInitialTransforms");
static_assert(offsetof(FRigUnit_TransformConstraintPerItem, WorkData) == 0xa0, "Offset mismatch for FRigUnit_TransformConstraintPerItem::WorkData");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FRigUnit_ParentConstraint_AdvancedSettings
{
    uint8_t InterpolationType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t RotationOrderForFilter; // 0x1 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FRigUnit_ParentConstraint_AdvancedSettings) == 0x2, "Size mismatch for FRigUnit_ParentConstraint_AdvancedSettings");
static_assert(offsetof(FRigUnit_ParentConstraint_AdvancedSettings, InterpolationType) == 0x0, "Offset mismatch for FRigUnit_ParentConstraint_AdvancedSettings::InterpolationType");
static_assert(offsetof(FRigUnit_ParentConstraint_AdvancedSettings, RotationOrderForFilter) == 0x1, "Offset mismatch for FRigUnit_ParentConstraint_AdvancedSettings::RotationOrderForFilter");

// Size: 0x68 (Inherited: 0x30, Single: 0x38)
struct FRigUnit_ParentConstraint : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset; // 0x18 (Size: 0x1, Type: BoolProperty)
    FTransformFilter Filter; // 0x19 (Size: 0x9, Type: StructProperty)
    uint8_t Pad_22[0x6]; // 0x22 (Size: 0x6, Type: PaddingProperty)
    TArray<FConstraintParent> Parents; // 0x28 (Size: 0x10, Type: ArrayProperty)
    FRigUnit_ParentConstraint_AdvancedSettings AdvancedSettings; // 0x38 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_3a[0x2]; // 0x3a (Size: 0x2, Type: PaddingProperty)
    float Weight; // 0x3c (Size: 0x4, Type: FloatProperty)
    FCachedRigElement ChildCache; // 0x40 (Size: 0x18, Type: StructProperty)
    TArray<FCachedRigElement> ParentCaches; // 0x58 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_ParentConstraint) == 0x68, "Size mismatch for FRigUnit_ParentConstraint");
static_assert(offsetof(FRigUnit_ParentConstraint, Child) == 0x10, "Offset mismatch for FRigUnit_ParentConstraint::Child");
static_assert(offsetof(FRigUnit_ParentConstraint, bMaintainOffset) == 0x18, "Offset mismatch for FRigUnit_ParentConstraint::bMaintainOffset");
static_assert(offsetof(FRigUnit_ParentConstraint, Filter) == 0x19, "Offset mismatch for FRigUnit_ParentConstraint::Filter");
static_assert(offsetof(FRigUnit_ParentConstraint, Parents) == 0x28, "Offset mismatch for FRigUnit_ParentConstraint::Parents");
static_assert(offsetof(FRigUnit_ParentConstraint, AdvancedSettings) == 0x38, "Offset mismatch for FRigUnit_ParentConstraint::AdvancedSettings");
static_assert(offsetof(FRigUnit_ParentConstraint, Weight) == 0x3c, "Offset mismatch for FRigUnit_ParentConstraint::Weight");
static_assert(offsetof(FRigUnit_ParentConstraint, ChildCache) == 0x40, "Offset mismatch for FRigUnit_ParentConstraint::ChildCache");
static_assert(offsetof(FRigUnit_ParentConstraint, ParentCaches) == 0x58, "Offset mismatch for FRigUnit_ParentConstraint::ParentCaches");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FRigUnit_ParentConstraintMath_AdvancedSettings
{
    uint8_t InterpolationType; // 0x0 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FRigUnit_ParentConstraintMath_AdvancedSettings) == 0x1, "Size mismatch for FRigUnit_ParentConstraintMath_AdvancedSettings");
static_assert(offsetof(FRigUnit_ParentConstraintMath_AdvancedSettings, InterpolationType) == 0x0, "Offset mismatch for FRigUnit_ParentConstraintMath_AdvancedSettings::InterpolationType");

// Size: 0x100 (Inherited: 0x18, Single: 0xe8)
struct FRigUnit_ParentConstraintMath : FRigUnit_HighlevelBase
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform Input; // 0x10 (Size: 0x60, Type: StructProperty)
    TArray<FConstraintParent> Parents; // 0x70 (Size: 0x10, Type: ArrayProperty)
    FRigUnit_ParentConstraintMath_AdvancedSettings AdvancedSettings; // 0x80 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_81[0xf]; // 0x81 (Size: 0xf, Type: PaddingProperty)
    FTransform Output; // 0x90 (Size: 0x60, Type: StructProperty)
    TArray<FCachedRigElement> ParentCaches; // 0xf0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_ParentConstraintMath) == 0x100, "Size mismatch for FRigUnit_ParentConstraintMath");
static_assert(offsetof(FRigUnit_ParentConstraintMath, Input) == 0x10, "Offset mismatch for FRigUnit_ParentConstraintMath::Input");
static_assert(offsetof(FRigUnit_ParentConstraintMath, Parents) == 0x70, "Offset mismatch for FRigUnit_ParentConstraintMath::Parents");
static_assert(offsetof(FRigUnit_ParentConstraintMath, AdvancedSettings) == 0x80, "Offset mismatch for FRigUnit_ParentConstraintMath::AdvancedSettings");
static_assert(offsetof(FRigUnit_ParentConstraintMath, Output) == 0x90, "Offset mismatch for FRigUnit_ParentConstraintMath::Output");
static_assert(offsetof(FRigUnit_ParentConstraintMath, ParentCaches) == 0xf0, "Offset mismatch for FRigUnit_ParentConstraintMath::ParentCaches");

// Size: 0x38 (Inherited: 0x30, Single: 0x8)
struct FRigUnit_PositionConstraint : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset; // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter; // 0x19 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    TArray<FConstraintParent> Parents; // 0x20 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_PositionConstraint) == 0x38, "Size mismatch for FRigUnit_PositionConstraint");
static_assert(offsetof(FRigUnit_PositionConstraint, Child) == 0x10, "Offset mismatch for FRigUnit_PositionConstraint::Child");
static_assert(offsetof(FRigUnit_PositionConstraint, bMaintainOffset) == 0x18, "Offset mismatch for FRigUnit_PositionConstraint::bMaintainOffset");
static_assert(offsetof(FRigUnit_PositionConstraint, Filter) == 0x19, "Offset mismatch for FRigUnit_PositionConstraint::Filter");
static_assert(offsetof(FRigUnit_PositionConstraint, Parents) == 0x20, "Offset mismatch for FRigUnit_PositionConstraint::Parents");
static_assert(offsetof(FRigUnit_PositionConstraint, Weight) == 0x30, "Offset mismatch for FRigUnit_PositionConstraint::Weight");

// Size: 0x60 (Inherited: 0x30, Single: 0x30)
struct FRigUnit_PositionConstraintLocalSpaceOffset : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset; // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter; // 0x19 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    TArray<FConstraintParent> Parents; // 0x20 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    FCachedRigElement ChildCache; // 0x38 (Size: 0x18, Type: StructProperty)
    TArray<FCachedRigElement> ParentCaches; // 0x50 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_PositionConstraintLocalSpaceOffset) == 0x60, "Size mismatch for FRigUnit_PositionConstraintLocalSpaceOffset");
static_assert(offsetof(FRigUnit_PositionConstraintLocalSpaceOffset, Child) == 0x10, "Offset mismatch for FRigUnit_PositionConstraintLocalSpaceOffset::Child");
static_assert(offsetof(FRigUnit_PositionConstraintLocalSpaceOffset, bMaintainOffset) == 0x18, "Offset mismatch for FRigUnit_PositionConstraintLocalSpaceOffset::bMaintainOffset");
static_assert(offsetof(FRigUnit_PositionConstraintLocalSpaceOffset, Filter) == 0x19, "Offset mismatch for FRigUnit_PositionConstraintLocalSpaceOffset::Filter");
static_assert(offsetof(FRigUnit_PositionConstraintLocalSpaceOffset, Parents) == 0x20, "Offset mismatch for FRigUnit_PositionConstraintLocalSpaceOffset::Parents");
static_assert(offsetof(FRigUnit_PositionConstraintLocalSpaceOffset, Weight) == 0x30, "Offset mismatch for FRigUnit_PositionConstraintLocalSpaceOffset::Weight");
static_assert(offsetof(FRigUnit_PositionConstraintLocalSpaceOffset, ChildCache) == 0x38, "Offset mismatch for FRigUnit_PositionConstraintLocalSpaceOffset::ChildCache");
static_assert(offsetof(FRigUnit_PositionConstraintLocalSpaceOffset, ParentCaches) == 0x50, "Offset mismatch for FRigUnit_PositionConstraintLocalSpaceOffset::ParentCaches");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FRigUnit_RotationConstraint_AdvancedSettings
{
    uint8_t InterpolationType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t RotationOrderForFilter; // 0x1 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FRigUnit_RotationConstraint_AdvancedSettings) == 0x2, "Size mismatch for FRigUnit_RotationConstraint_AdvancedSettings");
static_assert(offsetof(FRigUnit_RotationConstraint_AdvancedSettings, InterpolationType) == 0x0, "Offset mismatch for FRigUnit_RotationConstraint_AdvancedSettings::InterpolationType");
static_assert(offsetof(FRigUnit_RotationConstraint_AdvancedSettings, RotationOrderForFilter) == 0x1, "Offset mismatch for FRigUnit_RotationConstraint_AdvancedSettings::RotationOrderForFilter");

// Size: 0x38 (Inherited: 0x30, Single: 0x8)
struct FRigUnit_RotationConstraint : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset; // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter; // 0x19 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    TArray<FConstraintParent> Parents; // 0x20 (Size: 0x10, Type: ArrayProperty)
    FRigUnit_RotationConstraint_AdvancedSettings AdvancedSettings; // 0x30 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_32[0x2]; // 0x32 (Size: 0x2, Type: PaddingProperty)
    float Weight; // 0x34 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FRigUnit_RotationConstraint) == 0x38, "Size mismatch for FRigUnit_RotationConstraint");
static_assert(offsetof(FRigUnit_RotationConstraint, Child) == 0x10, "Offset mismatch for FRigUnit_RotationConstraint::Child");
static_assert(offsetof(FRigUnit_RotationConstraint, bMaintainOffset) == 0x18, "Offset mismatch for FRigUnit_RotationConstraint::bMaintainOffset");
static_assert(offsetof(FRigUnit_RotationConstraint, Filter) == 0x19, "Offset mismatch for FRigUnit_RotationConstraint::Filter");
static_assert(offsetof(FRigUnit_RotationConstraint, Parents) == 0x20, "Offset mismatch for FRigUnit_RotationConstraint::Parents");
static_assert(offsetof(FRigUnit_RotationConstraint, AdvancedSettings) == 0x30, "Offset mismatch for FRigUnit_RotationConstraint::AdvancedSettings");
static_assert(offsetof(FRigUnit_RotationConstraint, Weight) == 0x34, "Offset mismatch for FRigUnit_RotationConstraint::Weight");

// Size: 0x60 (Inherited: 0x30, Single: 0x30)
struct FRigUnit_RotationConstraintLocalSpaceOffset : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset; // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter; // 0x19 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    TArray<FConstraintParent> Parents; // 0x20 (Size: 0x10, Type: ArrayProperty)
    FRigUnit_RotationConstraint_AdvancedSettings AdvancedSettings; // 0x30 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_32[0x2]; // 0x32 (Size: 0x2, Type: PaddingProperty)
    float Weight; // 0x34 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement ChildCache; // 0x38 (Size: 0x18, Type: StructProperty)
    TArray<FCachedRigElement> ParentCaches; // 0x50 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_RotationConstraintLocalSpaceOffset) == 0x60, "Size mismatch for FRigUnit_RotationConstraintLocalSpaceOffset");
static_assert(offsetof(FRigUnit_RotationConstraintLocalSpaceOffset, Child) == 0x10, "Offset mismatch for FRigUnit_RotationConstraintLocalSpaceOffset::Child");
static_assert(offsetof(FRigUnit_RotationConstraintLocalSpaceOffset, bMaintainOffset) == 0x18, "Offset mismatch for FRigUnit_RotationConstraintLocalSpaceOffset::bMaintainOffset");
static_assert(offsetof(FRigUnit_RotationConstraintLocalSpaceOffset, Filter) == 0x19, "Offset mismatch for FRigUnit_RotationConstraintLocalSpaceOffset::Filter");
static_assert(offsetof(FRigUnit_RotationConstraintLocalSpaceOffset, Parents) == 0x20, "Offset mismatch for FRigUnit_RotationConstraintLocalSpaceOffset::Parents");
static_assert(offsetof(FRigUnit_RotationConstraintLocalSpaceOffset, AdvancedSettings) == 0x30, "Offset mismatch for FRigUnit_RotationConstraintLocalSpaceOffset::AdvancedSettings");
static_assert(offsetof(FRigUnit_RotationConstraintLocalSpaceOffset, Weight) == 0x34, "Offset mismatch for FRigUnit_RotationConstraintLocalSpaceOffset::Weight");
static_assert(offsetof(FRigUnit_RotationConstraintLocalSpaceOffset, ChildCache) == 0x38, "Offset mismatch for FRigUnit_RotationConstraintLocalSpaceOffset::ChildCache");
static_assert(offsetof(FRigUnit_RotationConstraintLocalSpaceOffset, ParentCaches) == 0x50, "Offset mismatch for FRigUnit_RotationConstraintLocalSpaceOffset::ParentCaches");

// Size: 0x38 (Inherited: 0x30, Single: 0x8)
struct FRigUnit_ScaleConstraint : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset; // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter; // 0x19 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    TArray<FConstraintParent> Parents; // 0x20 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ScaleConstraint) == 0x38, "Size mismatch for FRigUnit_ScaleConstraint");
static_assert(offsetof(FRigUnit_ScaleConstraint, Child) == 0x10, "Offset mismatch for FRigUnit_ScaleConstraint::Child");
static_assert(offsetof(FRigUnit_ScaleConstraint, bMaintainOffset) == 0x18, "Offset mismatch for FRigUnit_ScaleConstraint::bMaintainOffset");
static_assert(offsetof(FRigUnit_ScaleConstraint, Filter) == 0x19, "Offset mismatch for FRigUnit_ScaleConstraint::Filter");
static_assert(offsetof(FRigUnit_ScaleConstraint, Parents) == 0x20, "Offset mismatch for FRigUnit_ScaleConstraint::Parents");
static_assert(offsetof(FRigUnit_ScaleConstraint, Weight) == 0x30, "Offset mismatch for FRigUnit_ScaleConstraint::Weight");

// Size: 0x60 (Inherited: 0x30, Single: 0x30)
struct FRigUnit_ScaleConstraintLocalSpaceOffset : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Child; // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset; // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter; // 0x19 (Size: 0x3, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    TArray<FConstraintParent> Parents; // 0x20 (Size: 0x10, Type: ArrayProperty)
    float Weight; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    FCachedRigElement ChildCache; // 0x38 (Size: 0x18, Type: StructProperty)
    TArray<FCachedRigElement> ParentCaches; // 0x50 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_ScaleConstraintLocalSpaceOffset) == 0x60, "Size mismatch for FRigUnit_ScaleConstraintLocalSpaceOffset");
static_assert(offsetof(FRigUnit_ScaleConstraintLocalSpaceOffset, Child) == 0x10, "Offset mismatch for FRigUnit_ScaleConstraintLocalSpaceOffset::Child");
static_assert(offsetof(FRigUnit_ScaleConstraintLocalSpaceOffset, bMaintainOffset) == 0x18, "Offset mismatch for FRigUnit_ScaleConstraintLocalSpaceOffset::bMaintainOffset");
static_assert(offsetof(FRigUnit_ScaleConstraintLocalSpaceOffset, Filter) == 0x19, "Offset mismatch for FRigUnit_ScaleConstraintLocalSpaceOffset::Filter");
static_assert(offsetof(FRigUnit_ScaleConstraintLocalSpaceOffset, Parents) == 0x20, "Offset mismatch for FRigUnit_ScaleConstraintLocalSpaceOffset::Parents");
static_assert(offsetof(FRigUnit_ScaleConstraintLocalSpaceOffset, Weight) == 0x30, "Offset mismatch for FRigUnit_ScaleConstraintLocalSpaceOffset::Weight");
static_assert(offsetof(FRigUnit_ScaleConstraintLocalSpaceOffset, ChildCache) == 0x38, "Offset mismatch for FRigUnit_ScaleConstraintLocalSpaceOffset::ChildCache");
static_assert(offsetof(FRigUnit_ScaleConstraintLocalSpaceOffset, ParentCaches) == 0x50, "Offset mismatch for FRigUnit_ScaleConstraintLocalSpaceOffset::ParentCaches");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FRigUnit_TwistBones_WorkData
{
    TArray<FCachedRigElement> CachedItems; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<float> ItemRatios; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> ItemTransforms; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_TwistBones_WorkData) == 0x30, "Size mismatch for FRigUnit_TwistBones_WorkData");
static_assert(offsetof(FRigUnit_TwistBones_WorkData, CachedItems) == 0x0, "Offset mismatch for FRigUnit_TwistBones_WorkData::CachedItems");
static_assert(offsetof(FRigUnit_TwistBones_WorkData, ItemRatios) == 0x10, "Offset mismatch for FRigUnit_TwistBones_WorkData::ItemRatios");
static_assert(offsetof(FRigUnit_TwistBones_WorkData, ItemTransforms) == 0x20, "Offset mismatch for FRigUnit_TwistBones_WorkData::ItemTransforms");

// Size: 0x88 (Inherited: 0x30, Single: 0x58)
struct FRigUnit_TwistBones : FRigUnit_HighlevelBaseMutable
{
    FName StartBone; // 0x10 (Size: 0x4, Type: NameProperty)
    FName EndBone; // 0x14 (Size: 0x4, Type: NameProperty)
    FVector TwistAxis; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector PoleAxis; // 0x30 (Size: 0x18, Type: StructProperty)
    uint8_t TwistEaseType; // 0x48 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_49[0x3]; // 0x49 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0x4c (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x7]; // 0x51 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_TwistBones_WorkData WorkData; // 0x58 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TwistBones) == 0x88, "Size mismatch for FRigUnit_TwistBones");
static_assert(offsetof(FRigUnit_TwistBones, StartBone) == 0x10, "Offset mismatch for FRigUnit_TwistBones::StartBone");
static_assert(offsetof(FRigUnit_TwistBones, EndBone) == 0x14, "Offset mismatch for FRigUnit_TwistBones::EndBone");
static_assert(offsetof(FRigUnit_TwistBones, TwistAxis) == 0x18, "Offset mismatch for FRigUnit_TwistBones::TwistAxis");
static_assert(offsetof(FRigUnit_TwistBones, PoleAxis) == 0x30, "Offset mismatch for FRigUnit_TwistBones::PoleAxis");
static_assert(offsetof(FRigUnit_TwistBones, TwistEaseType) == 0x48, "Offset mismatch for FRigUnit_TwistBones::TwistEaseType");
static_assert(offsetof(FRigUnit_TwistBones, Weight) == 0x4c, "Offset mismatch for FRigUnit_TwistBones::Weight");
static_assert(offsetof(FRigUnit_TwistBones, bPropagateToChildren) == 0x50, "Offset mismatch for FRigUnit_TwistBones::bPropagateToChildren");
static_assert(offsetof(FRigUnit_TwistBones, WorkData) == 0x58, "Offset mismatch for FRigUnit_TwistBones::WorkData");

// Size: 0x90 (Inherited: 0x30, Single: 0x60)
struct FRigUnit_TwistBonesPerItem : FRigUnit_HighlevelBaseMutable
{
    FRigElementKeyCollection Items; // 0x10 (Size: 0x10, Type: StructProperty)
    FVector TwistAxis; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector PoleAxis; // 0x38 (Size: 0x18, Type: StructProperty)
    uint8_t TwistEaseType; // 0x50 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_51[0x3]; // 0x51 (Size: 0x3, Type: PaddingProperty)
    float Weight; // 0x54 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x58 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_59[0x7]; // 0x59 (Size: 0x7, Type: PaddingProperty)
    FRigUnit_TwistBones_WorkData WorkData; // 0x60 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TwistBonesPerItem) == 0x90, "Size mismatch for FRigUnit_TwistBonesPerItem");
static_assert(offsetof(FRigUnit_TwistBonesPerItem, Items) == 0x10, "Offset mismatch for FRigUnit_TwistBonesPerItem::Items");
static_assert(offsetof(FRigUnit_TwistBonesPerItem, TwistAxis) == 0x20, "Offset mismatch for FRigUnit_TwistBonesPerItem::TwistAxis");
static_assert(offsetof(FRigUnit_TwistBonesPerItem, PoleAxis) == 0x38, "Offset mismatch for FRigUnit_TwistBonesPerItem::PoleAxis");
static_assert(offsetof(FRigUnit_TwistBonesPerItem, TwistEaseType) == 0x50, "Offset mismatch for FRigUnit_TwistBonesPerItem::TwistEaseType");
static_assert(offsetof(FRigUnit_TwistBonesPerItem, Weight) == 0x54, "Offset mismatch for FRigUnit_TwistBonesPerItem::Weight");
static_assert(offsetof(FRigUnit_TwistBonesPerItem, bPropagateToChildren) == 0x58, "Offset mismatch for FRigUnit_TwistBonesPerItem::bPropagateToChildren");
static_assert(offsetof(FRigUnit_TwistBonesPerItem, WorkData) == 0x60, "Offset mismatch for FRigUnit_TwistBonesPerItem::WorkData");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FRigUnit_TwoBoneIKSimple_DebugSettings
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float Scale; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform WorldOffset; // 0x10 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TwoBoneIKSimple_DebugSettings) == 0x70, "Size mismatch for FRigUnit_TwoBoneIKSimple_DebugSettings");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple_DebugSettings, bEnabled) == 0x0, "Offset mismatch for FRigUnit_TwoBoneIKSimple_DebugSettings::bEnabled");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple_DebugSettings, Scale) == 0x4, "Offset mismatch for FRigUnit_TwoBoneIKSimple_DebugSettings::Scale");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple_DebugSettings, WorldOffset) == 0x10, "Offset mismatch for FRigUnit_TwoBoneIKSimple_DebugSettings::WorldOffset");

// Size: 0x1d0 (Inherited: 0x30, Single: 0x1a0)
struct FRigUnit_TwoBoneIKSimple : FRigUnit_HighlevelBaseMutable
{
    FName BoneA; // 0x10 (Size: 0x4, Type: NameProperty)
    FName BoneB; // 0x14 (Size: 0x4, Type: NameProperty)
    FName EffectorBone; // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    FTransform Effector; // 0x20 (Size: 0x60, Type: StructProperty)
    FVector PrimaryAxis; // 0x80 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0x98 (Size: 0x18, Type: StructProperty)
    float SecondaryAxisWeight; // 0xb0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_b4[0x4]; // 0xb4 (Size: 0x4, Type: PaddingProperty)
    FVector PoleVector; // 0xb8 (Size: 0x18, Type: StructProperty)
    uint8_t PoleVectorKind; // 0xd0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d1[0x3]; // 0xd1 (Size: 0x3, Type: PaddingProperty)
    FName PoleVectorSpace; // 0xd4 (Size: 0x4, Type: NameProperty)
    bool bEnableStretch; // 0xd8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d9[0x3]; // 0xd9 (Size: 0x3, Type: PaddingProperty)
    float StretchStartRatio; // 0xdc (Size: 0x4, Type: FloatProperty)
    float StretchMaximumRatio; // 0xe0 (Size: 0x4, Type: FloatProperty)
    float Weight; // 0xe4 (Size: 0x4, Type: FloatProperty)
    float BoneALength; // 0xe8 (Size: 0x4, Type: FloatProperty)
    float BoneBLength; // 0xec (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0xf0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f1[0xf]; // 0xf1 (Size: 0xf, Type: PaddingProperty)
    FRigUnit_TwoBoneIKSimple_DebugSettings DebugSettings; // 0x100 (Size: 0x70, Type: StructProperty)
    FCachedRigElement CachedBoneAIndex; // 0x170 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedBoneBIndex; // 0x188 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedEffectorBoneIndex; // 0x1a0 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedPoleVectorSpaceIndex; // 0x1b8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TwoBoneIKSimple) == 0x1d0, "Size mismatch for FRigUnit_TwoBoneIKSimple");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, BoneA) == 0x10, "Offset mismatch for FRigUnit_TwoBoneIKSimple::BoneA");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, BoneB) == 0x14, "Offset mismatch for FRigUnit_TwoBoneIKSimple::BoneB");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, EffectorBone) == 0x18, "Offset mismatch for FRigUnit_TwoBoneIKSimple::EffectorBone");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, Effector) == 0x20, "Offset mismatch for FRigUnit_TwoBoneIKSimple::Effector");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, PrimaryAxis) == 0x80, "Offset mismatch for FRigUnit_TwoBoneIKSimple::PrimaryAxis");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, SecondaryAxis) == 0x98, "Offset mismatch for FRigUnit_TwoBoneIKSimple::SecondaryAxis");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, SecondaryAxisWeight) == 0xb0, "Offset mismatch for FRigUnit_TwoBoneIKSimple::SecondaryAxisWeight");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, PoleVector) == 0xb8, "Offset mismatch for FRigUnit_TwoBoneIKSimple::PoleVector");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, PoleVectorKind) == 0xd0, "Offset mismatch for FRigUnit_TwoBoneIKSimple::PoleVectorKind");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, PoleVectorSpace) == 0xd4, "Offset mismatch for FRigUnit_TwoBoneIKSimple::PoleVectorSpace");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, bEnableStretch) == 0xd8, "Offset mismatch for FRigUnit_TwoBoneIKSimple::bEnableStretch");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, StretchStartRatio) == 0xdc, "Offset mismatch for FRigUnit_TwoBoneIKSimple::StretchStartRatio");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, StretchMaximumRatio) == 0xe0, "Offset mismatch for FRigUnit_TwoBoneIKSimple::StretchMaximumRatio");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, Weight) == 0xe4, "Offset mismatch for FRigUnit_TwoBoneIKSimple::Weight");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, BoneALength) == 0xe8, "Offset mismatch for FRigUnit_TwoBoneIKSimple::BoneALength");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, BoneBLength) == 0xec, "Offset mismatch for FRigUnit_TwoBoneIKSimple::BoneBLength");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, bPropagateToChildren) == 0xf0, "Offset mismatch for FRigUnit_TwoBoneIKSimple::bPropagateToChildren");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, DebugSettings) == 0x100, "Offset mismatch for FRigUnit_TwoBoneIKSimple::DebugSettings");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, CachedBoneAIndex) == 0x170, "Offset mismatch for FRigUnit_TwoBoneIKSimple::CachedBoneAIndex");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, CachedBoneBIndex) == 0x188, "Offset mismatch for FRigUnit_TwoBoneIKSimple::CachedBoneBIndex");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, CachedEffectorBoneIndex) == 0x1a0, "Offset mismatch for FRigUnit_TwoBoneIKSimple::CachedEffectorBoneIndex");
static_assert(offsetof(FRigUnit_TwoBoneIKSimple, CachedPoleVectorSpaceIndex) == 0x1b8, "Offset mismatch for FRigUnit_TwoBoneIKSimple::CachedPoleVectorSpaceIndex");

// Size: 0x1e0 (Inherited: 0x30, Single: 0x1b0)
struct FRigUnit_TwoBoneIKSimplePerItem : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey ItemA; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey ItemB; // 0x18 (Size: 0x8, Type: StructProperty)
    FRigElementKey EffectorItem; // 0x20 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FTransform Effector; // 0x30 (Size: 0x60, Type: StructProperty)
    FVector PrimaryAxis; // 0x90 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0xa8 (Size: 0x18, Type: StructProperty)
    float SecondaryAxisWeight; // 0xc0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c4[0x4]; // 0xc4 (Size: 0x4, Type: PaddingProperty)
    FVector PoleVector; // 0xc8 (Size: 0x18, Type: StructProperty)
    uint8_t PoleVectorKind; // 0xe0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_e1[0x3]; // 0xe1 (Size: 0x3, Type: PaddingProperty)
    FRigElementKey PoleVectorSpace; // 0xe4 (Size: 0x8, Type: StructProperty)
    bool bEnableStretch; // 0xec (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ed[0x3]; // 0xed (Size: 0x3, Type: PaddingProperty)
    float StretchStartRatio; // 0xf0 (Size: 0x4, Type: FloatProperty)
    float StretchMaximumRatio; // 0xf4 (Size: 0x4, Type: FloatProperty)
    float Weight; // 0xf8 (Size: 0x4, Type: FloatProperty)
    float ItemALength; // 0xfc (Size: 0x4, Type: FloatProperty)
    float ItemBLength; // 0x100 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren; // 0x104 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_105[0xb]; // 0x105 (Size: 0xb, Type: PaddingProperty)
    FRigUnit_TwoBoneIKSimple_DebugSettings DebugSettings; // 0x110 (Size: 0x70, Type: StructProperty)
    FCachedRigElement CachedItemAIndex; // 0x180 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedItemBIndex; // 0x198 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedEffectorItemIndex; // 0x1b0 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedPoleVectorSpaceIndex; // 0x1c8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TwoBoneIKSimplePerItem) == 0x1e0, "Size mismatch for FRigUnit_TwoBoneIKSimplePerItem");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, ItemA) == 0x10, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::ItemA");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, ItemB) == 0x18, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::ItemB");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, EffectorItem) == 0x20, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::EffectorItem");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, Effector) == 0x30, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::Effector");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, PrimaryAxis) == 0x90, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::PrimaryAxis");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, SecondaryAxis) == 0xa8, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::SecondaryAxis");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, SecondaryAxisWeight) == 0xc0, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::SecondaryAxisWeight");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, PoleVector) == 0xc8, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::PoleVector");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, PoleVectorKind) == 0xe0, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::PoleVectorKind");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, PoleVectorSpace) == 0xe4, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::PoleVectorSpace");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, bEnableStretch) == 0xec, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::bEnableStretch");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, StretchStartRatio) == 0xf0, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::StretchStartRatio");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, StretchMaximumRatio) == 0xf4, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::StretchMaximumRatio");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, Weight) == 0xf8, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::Weight");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, ItemALength) == 0xfc, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::ItemALength");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, ItemBLength) == 0x100, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::ItemBLength");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, bPropagateToChildren) == 0x104, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::bPropagateToChildren");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, DebugSettings) == 0x110, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::DebugSettings");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, CachedItemAIndex) == 0x180, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::CachedItemAIndex");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, CachedItemBIndex) == 0x198, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::CachedItemBIndex");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, CachedEffectorItemIndex) == 0x1b0, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::CachedEffectorItemIndex");
static_assert(offsetof(FRigUnit_TwoBoneIKSimplePerItem, CachedPoleVectorSpaceIndex) == 0x1c8, "Offset mismatch for FRigUnit_TwoBoneIKSimplePerItem::CachedPoleVectorSpaceIndex");

// Size: 0x80 (Inherited: 0x18, Single: 0x68)
struct FRigUnit_TwoBoneIKSimpleVectors : FRigUnit_HighlevelBase
{
    FVector Root; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector PoleVector; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector Effector; // 0x38 (Size: 0x18, Type: StructProperty)
    bool bEnableStretch; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0x3]; // 0x51 (Size: 0x3, Type: PaddingProperty)
    float StretchStartRatio; // 0x54 (Size: 0x4, Type: FloatProperty)
    float StretchMaximumRatio; // 0x58 (Size: 0x4, Type: FloatProperty)
    float BoneALength; // 0x5c (Size: 0x4, Type: FloatProperty)
    float BoneBLength; // 0x60 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_64[0x4]; // 0x64 (Size: 0x4, Type: PaddingProperty)
    FVector Elbow; // 0x68 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TwoBoneIKSimpleVectors) == 0x80, "Size mismatch for FRigUnit_TwoBoneIKSimpleVectors");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleVectors, Root) == 0x8, "Offset mismatch for FRigUnit_TwoBoneIKSimpleVectors::Root");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleVectors, PoleVector) == 0x20, "Offset mismatch for FRigUnit_TwoBoneIKSimpleVectors::PoleVector");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleVectors, Effector) == 0x38, "Offset mismatch for FRigUnit_TwoBoneIKSimpleVectors::Effector");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleVectors, bEnableStretch) == 0x50, "Offset mismatch for FRigUnit_TwoBoneIKSimpleVectors::bEnableStretch");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleVectors, StretchStartRatio) == 0x54, "Offset mismatch for FRigUnit_TwoBoneIKSimpleVectors::StretchStartRatio");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleVectors, StretchMaximumRatio) == 0x58, "Offset mismatch for FRigUnit_TwoBoneIKSimpleVectors::StretchMaximumRatio");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleVectors, BoneALength) == 0x5c, "Offset mismatch for FRigUnit_TwoBoneIKSimpleVectors::BoneALength");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleVectors, BoneBLength) == 0x60, "Offset mismatch for FRigUnit_TwoBoneIKSimpleVectors::BoneBLength");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleVectors, Elbow) == 0x68, "Offset mismatch for FRigUnit_TwoBoneIKSimpleVectors::Elbow");

// Size: 0x1a0 (Inherited: 0x18, Single: 0x188)
struct FRigUnit_TwoBoneIKSimpleTransforms : FRigUnit_HighlevelBase
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform Root; // 0x10 (Size: 0x60, Type: StructProperty)
    FVector PoleVector; // 0x70 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
    FTransform Effector; // 0x90 (Size: 0x60, Type: StructProperty)
    FVector PrimaryAxis; // 0xf0 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0x108 (Size: 0x18, Type: StructProperty)
    float SecondaryAxisWeight; // 0x120 (Size: 0x4, Type: FloatProperty)
    bool bEnableStretch; // 0x124 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_125[0x3]; // 0x125 (Size: 0x3, Type: PaddingProperty)
    float StretchStartRatio; // 0x128 (Size: 0x4, Type: FloatProperty)
    float StretchMaximumRatio; // 0x12c (Size: 0x4, Type: FloatProperty)
    float BoneALength; // 0x130 (Size: 0x4, Type: FloatProperty)
    float BoneBLength; // 0x134 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_138[0x8]; // 0x138 (Size: 0x8, Type: PaddingProperty)
    FTransform Elbow; // 0x140 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TwoBoneIKSimpleTransforms) == 0x1a0, "Size mismatch for FRigUnit_TwoBoneIKSimpleTransforms");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleTransforms, Root) == 0x10, "Offset mismatch for FRigUnit_TwoBoneIKSimpleTransforms::Root");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleTransforms, PoleVector) == 0x70, "Offset mismatch for FRigUnit_TwoBoneIKSimpleTransforms::PoleVector");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleTransforms, Effector) == 0x90, "Offset mismatch for FRigUnit_TwoBoneIKSimpleTransforms::Effector");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleTransforms, PrimaryAxis) == 0xf0, "Offset mismatch for FRigUnit_TwoBoneIKSimpleTransforms::PrimaryAxis");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleTransforms, SecondaryAxis) == 0x108, "Offset mismatch for FRigUnit_TwoBoneIKSimpleTransforms::SecondaryAxis");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleTransforms, SecondaryAxisWeight) == 0x120, "Offset mismatch for FRigUnit_TwoBoneIKSimpleTransforms::SecondaryAxisWeight");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleTransforms, bEnableStretch) == 0x124, "Offset mismatch for FRigUnit_TwoBoneIKSimpleTransforms::bEnableStretch");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleTransforms, StretchStartRatio) == 0x128, "Offset mismatch for FRigUnit_TwoBoneIKSimpleTransforms::StretchStartRatio");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleTransforms, StretchMaximumRatio) == 0x12c, "Offset mismatch for FRigUnit_TwoBoneIKSimpleTransforms::StretchMaximumRatio");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleTransforms, BoneALength) == 0x130, "Offset mismatch for FRigUnit_TwoBoneIKSimpleTransforms::BoneALength");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleTransforms, BoneBLength) == 0x134, "Offset mismatch for FRigUnit_TwoBoneIKSimpleTransforms::BoneBLength");
static_assert(offsetof(FRigUnit_TwoBoneIKSimpleTransforms, Elbow) == 0x140, "Offset mismatch for FRigUnit_TwoBoneIKSimpleTransforms::Elbow");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FRigUnit_GetCandidates : FRigUnit
{
    FRigElementKey Connector; // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementKey> Candidates; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_GetCandidates) == 0x20, "Size mismatch for FRigUnit_GetCandidates");
static_assert(offsetof(FRigUnit_GetCandidates, Connector) == 0x8, "Offset mismatch for FRigUnit_GetCandidates::Connector");
static_assert(offsetof(FRigUnit_GetCandidates, Candidates) == 0x10, "Offset mismatch for FRigUnit_GetCandidates::Candidates");

// Size: 0x30 (Inherited: 0x20, Single: 0x10)
struct FRigUnit_DiscardMatches : FRigUnitMutable
{
    TArray<FRigElementKey> Excluded; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FString Message; // 0x20 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FRigUnit_DiscardMatches) == 0x30, "Size mismatch for FRigUnit_DiscardMatches");
static_assert(offsetof(FRigUnit_DiscardMatches, Excluded) == 0x10, "Offset mismatch for FRigUnit_DiscardMatches::Excluded");
static_assert(offsetof(FRigUnit_DiscardMatches, Message) == 0x20, "Offset mismatch for FRigUnit_DiscardMatches::Message");

// Size: 0x18 (Inherited: 0x20, Single: 0xfffffff8)
struct FRigUnit_SetDefaultMatch : FRigUnitMutable
{
    FRigElementKey Default; // 0x10 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SetDefaultMatch) == 0x18, "Size mismatch for FRigUnit_SetDefaultMatch");
static_assert(offsetof(FRigUnit_SetDefaultMatch, Default) == 0x10, "Offset mismatch for FRigUnit_SetDefaultMatch::Default");

// Size: 0x200 (Inherited: 0x10, Single: 0x1f0)
struct FRigUnit_ConnectorExecution : FRigUnit
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FControlRigExecuteContext ExecuteContext; // 0x10 (Size: 0x1f0, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_ConnectorExecution) == 0x200, "Size mismatch for FRigUnit_ConnectorExecution");
static_assert(offsetof(FRigUnit_ConnectorExecution, ExecuteContext) == 0x10, "Offset mismatch for FRigUnit_ConnectorExecution::ExecuteContext");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FRigUnit_PointSimulation_DebugSettings
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float Scale; // 0x4 (Size: 0x4, Type: FloatProperty)
    float CollisionScale; // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bDrawPointsAsSpheres; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FLinearColor Color; // 0x10 (Size: 0x10, Type: StructProperty)
    FTransform WorldOffset; // 0x20 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_PointSimulation_DebugSettings) == 0x80, "Size mismatch for FRigUnit_PointSimulation_DebugSettings");
static_assert(offsetof(FRigUnit_PointSimulation_DebugSettings, bEnabled) == 0x0, "Offset mismatch for FRigUnit_PointSimulation_DebugSettings::bEnabled");
static_assert(offsetof(FRigUnit_PointSimulation_DebugSettings, Scale) == 0x4, "Offset mismatch for FRigUnit_PointSimulation_DebugSettings::Scale");
static_assert(offsetof(FRigUnit_PointSimulation_DebugSettings, CollisionScale) == 0x8, "Offset mismatch for FRigUnit_PointSimulation_DebugSettings::CollisionScale");
static_assert(offsetof(FRigUnit_PointSimulation_DebugSettings, bDrawPointsAsSpheres) == 0xc, "Offset mismatch for FRigUnit_PointSimulation_DebugSettings::bDrawPointsAsSpheres");
static_assert(offsetof(FRigUnit_PointSimulation_DebugSettings, Color) == 0x10, "Offset mismatch for FRigUnit_PointSimulation_DebugSettings::Color");
static_assert(offsetof(FRigUnit_PointSimulation_DebugSettings, WorldOffset) == 0x20, "Offset mismatch for FRigUnit_PointSimulation_DebugSettings::WorldOffset");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRigUnit_PointSimulation_BoneTarget
{
    FName bone; // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t TranslationPoint; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t PrimaryAimPoint; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t SecondaryAimPoint; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FRigUnit_PointSimulation_BoneTarget) == 0x10, "Size mismatch for FRigUnit_PointSimulation_BoneTarget");
static_assert(offsetof(FRigUnit_PointSimulation_BoneTarget, bone) == 0x0, "Offset mismatch for FRigUnit_PointSimulation_BoneTarget::bone");
static_assert(offsetof(FRigUnit_PointSimulation_BoneTarget, TranslationPoint) == 0x4, "Offset mismatch for FRigUnit_PointSimulation_BoneTarget::TranslationPoint");
static_assert(offsetof(FRigUnit_PointSimulation_BoneTarget, PrimaryAimPoint) == 0x8, "Offset mismatch for FRigUnit_PointSimulation_BoneTarget::PrimaryAimPoint");
static_assert(offsetof(FRigUnit_PointSimulation_BoneTarget, SecondaryAimPoint) == 0xc, "Offset mismatch for FRigUnit_PointSimulation_BoneTarget::SecondaryAimPoint");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FRigUnit_PointSimulation_WorkData
{
    FCRSimPointContainer Simulation; // 0x0 (Size: 0x78, Type: StructProperty)
    TArray<FCachedRigElement> BoneIndices; // 0x78 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRigUnit_PointSimulation_WorkData) == 0x88, "Size mismatch for FRigUnit_PointSimulation_WorkData");
static_assert(offsetof(FRigUnit_PointSimulation_WorkData, Simulation) == 0x0, "Offset mismatch for FRigUnit_PointSimulation_WorkData::Simulation");
static_assert(offsetof(FRigUnit_PointSimulation_WorkData, BoneIndices) == 0x78, "Offset mismatch for FRigUnit_PointSimulation_WorkData::BoneIndices");

// Size: 0x220 (Inherited: 0x28, Single: 0x1f8)
struct FRigUnit_PointSimulation : FRigVMFunction_SimBaseMutable
{
    TArray<FRigVMSimPoint> Points; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimLinearSpring> Links; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimPointForce> Forces; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimSoftCollision> CollisionVolumes; // 0x40 (Size: 0x10, Type: ArrayProperty)
    float SimulatedStepsPerSecond; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t IntegratorType; // 0x54 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_55[0x3]; // 0x55 (Size: 0x3, Type: PaddingProperty)
    float VerletBlend; // 0x58 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    TArray<FRigUnit_PointSimulation_BoneTarget> BoneTargets; // 0x60 (Size: 0x10, Type: ArrayProperty)
    bool bLimitLocalPosition; // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bPropagateToChildren; // 0x71 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_72[0x6]; // 0x72 (Size: 0x6, Type: PaddingProperty)
    FVector PrimaryAimAxis; // 0x78 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAimAxis; // 0x90 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_a8[0x8]; // 0xa8 (Size: 0x8, Type: PaddingProperty)
    FRigUnit_PointSimulation_DebugSettings DebugSettings; // 0xb0 (Size: 0x80, Type: StructProperty)
    FRigVMFourPointBezier Bezier; // 0x130 (Size: 0x60, Type: StructProperty)
    FRigUnit_PointSimulation_WorkData WorkData; // 0x190 (Size: 0x88, Type: StructProperty)
    uint8_t Pad_218[0x8]; // 0x218 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_PointSimulation) == 0x220, "Size mismatch for FRigUnit_PointSimulation");
static_assert(offsetof(FRigUnit_PointSimulation, Points) == 0x10, "Offset mismatch for FRigUnit_PointSimulation::Points");
static_assert(offsetof(FRigUnit_PointSimulation, Links) == 0x20, "Offset mismatch for FRigUnit_PointSimulation::Links");
static_assert(offsetof(FRigUnit_PointSimulation, Forces) == 0x30, "Offset mismatch for FRigUnit_PointSimulation::Forces");
static_assert(offsetof(FRigUnit_PointSimulation, CollisionVolumes) == 0x40, "Offset mismatch for FRigUnit_PointSimulation::CollisionVolumes");
static_assert(offsetof(FRigUnit_PointSimulation, SimulatedStepsPerSecond) == 0x50, "Offset mismatch for FRigUnit_PointSimulation::SimulatedStepsPerSecond");
static_assert(offsetof(FRigUnit_PointSimulation, IntegratorType) == 0x54, "Offset mismatch for FRigUnit_PointSimulation::IntegratorType");
static_assert(offsetof(FRigUnit_PointSimulation, VerletBlend) == 0x58, "Offset mismatch for FRigUnit_PointSimulation::VerletBlend");
static_assert(offsetof(FRigUnit_PointSimulation, BoneTargets) == 0x60, "Offset mismatch for FRigUnit_PointSimulation::BoneTargets");
static_assert(offsetof(FRigUnit_PointSimulation, bLimitLocalPosition) == 0x70, "Offset mismatch for FRigUnit_PointSimulation::bLimitLocalPosition");
static_assert(offsetof(FRigUnit_PointSimulation, bPropagateToChildren) == 0x71, "Offset mismatch for FRigUnit_PointSimulation::bPropagateToChildren");
static_assert(offsetof(FRigUnit_PointSimulation, PrimaryAimAxis) == 0x78, "Offset mismatch for FRigUnit_PointSimulation::PrimaryAimAxis");
static_assert(offsetof(FRigUnit_PointSimulation, SecondaryAimAxis) == 0x90, "Offset mismatch for FRigUnit_PointSimulation::SecondaryAimAxis");
static_assert(offsetof(FRigUnit_PointSimulation, DebugSettings) == 0xb0, "Offset mismatch for FRigUnit_PointSimulation::DebugSettings");
static_assert(offsetof(FRigUnit_PointSimulation, Bezier) == 0x130, "Offset mismatch for FRigUnit_PointSimulation::Bezier");
static_assert(offsetof(FRigUnit_PointSimulation, WorkData) == 0x190, "Offset mismatch for FRigUnit_PointSimulation::WorkData");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FRigUnit_SpringInterp : FRigVMFunction_SimBase
{
    float Current; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Target; // 0xc (Size: 0x4, Type: FloatProperty)
    float Stiffness; // 0x10 (Size: 0x4, Type: FloatProperty)
    float CriticalDamping; // 0x14 (Size: 0x4, Type: FloatProperty)
    float Mass; // 0x18 (Size: 0x4, Type: FloatProperty)
    float Result; // 0x1c (Size: 0x4, Type: FloatProperty)
    FFloatSpringState SpringState; // 0x20 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_SpringInterp) == 0x30, "Size mismatch for FRigUnit_SpringInterp");
static_assert(offsetof(FRigUnit_SpringInterp, Current) == 0x8, "Offset mismatch for FRigUnit_SpringInterp::Current");
static_assert(offsetof(FRigUnit_SpringInterp, Target) == 0xc, "Offset mismatch for FRigUnit_SpringInterp::Target");
static_assert(offsetof(FRigUnit_SpringInterp, Stiffness) == 0x10, "Offset mismatch for FRigUnit_SpringInterp::Stiffness");
static_assert(offsetof(FRigUnit_SpringInterp, CriticalDamping) == 0x14, "Offset mismatch for FRigUnit_SpringInterp::CriticalDamping");
static_assert(offsetof(FRigUnit_SpringInterp, Mass) == 0x18, "Offset mismatch for FRigUnit_SpringInterp::Mass");
static_assert(offsetof(FRigUnit_SpringInterp, Result) == 0x1c, "Offset mismatch for FRigUnit_SpringInterp::Result");
static_assert(offsetof(FRigUnit_SpringInterp, SpringState) == 0x20, "Offset mismatch for FRigUnit_SpringInterp::SpringState");

// Size: 0x98 (Inherited: 0x10, Single: 0x88)
struct FRigUnit_SpringInterpVector : FRigVMFunction_SimBase
{
    FVector Current; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Target; // 0x20 (Size: 0x18, Type: StructProperty)
    float Stiffness; // 0x38 (Size: 0x4, Type: FloatProperty)
    float CriticalDamping; // 0x3c (Size: 0x4, Type: FloatProperty)
    float Mass; // 0x40 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
    FVector Result; // 0x48 (Size: 0x18, Type: StructProperty)
    FVectorSpringState SpringState; // 0x60 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SpringInterpVector) == 0x98, "Size mismatch for FRigUnit_SpringInterpVector");
static_assert(offsetof(FRigUnit_SpringInterpVector, Current) == 0x8, "Offset mismatch for FRigUnit_SpringInterpVector::Current");
static_assert(offsetof(FRigUnit_SpringInterpVector, Target) == 0x20, "Offset mismatch for FRigUnit_SpringInterpVector::Target");
static_assert(offsetof(FRigUnit_SpringInterpVector, Stiffness) == 0x38, "Offset mismatch for FRigUnit_SpringInterpVector::Stiffness");
static_assert(offsetof(FRigUnit_SpringInterpVector, CriticalDamping) == 0x3c, "Offset mismatch for FRigUnit_SpringInterpVector::CriticalDamping");
static_assert(offsetof(FRigUnit_SpringInterpVector, Mass) == 0x40, "Offset mismatch for FRigUnit_SpringInterpVector::Mass");
static_assert(offsetof(FRigUnit_SpringInterpVector, Result) == 0x48, "Offset mismatch for FRigUnit_SpringInterpVector::Result");
static_assert(offsetof(FRigUnit_SpringInterpVector, SpringState) == 0x60, "Offset mismatch for FRigUnit_SpringInterpVector::SpringState");

// Size: 0x40 (Inherited: 0x10, Single: 0x30)
struct FRigUnit_SpringInterpV2 : FRigVMFunction_SimBase
{
    float Target; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Strength; // 0xc (Size: 0x4, Type: FloatProperty)
    float CriticalDamping; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Force; // 0x14 (Size: 0x4, Type: FloatProperty)
    bool bUseCurrentInput; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
    float Current; // 0x1c (Size: 0x4, Type: FloatProperty)
    float TargetVelocityAmount; // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bInitializeFromTarget; // 0x24 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_25[0x3]; // 0x25 (Size: 0x3, Type: PaddingProperty)
    float Result; // 0x28 (Size: 0x4, Type: FloatProperty)
    float Velocity; // 0x2c (Size: 0x4, Type: FloatProperty)
    float SimulatedResult; // 0x30 (Size: 0x4, Type: FloatProperty)
    FFloatSpringState SpringState; // 0x34 (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SpringInterpV2) == 0x40, "Size mismatch for FRigUnit_SpringInterpV2");
static_assert(offsetof(FRigUnit_SpringInterpV2, Target) == 0x8, "Offset mismatch for FRigUnit_SpringInterpV2::Target");
static_assert(offsetof(FRigUnit_SpringInterpV2, Strength) == 0xc, "Offset mismatch for FRigUnit_SpringInterpV2::Strength");
static_assert(offsetof(FRigUnit_SpringInterpV2, CriticalDamping) == 0x10, "Offset mismatch for FRigUnit_SpringInterpV2::CriticalDamping");
static_assert(offsetof(FRigUnit_SpringInterpV2, Force) == 0x14, "Offset mismatch for FRigUnit_SpringInterpV2::Force");
static_assert(offsetof(FRigUnit_SpringInterpV2, bUseCurrentInput) == 0x18, "Offset mismatch for FRigUnit_SpringInterpV2::bUseCurrentInput");
static_assert(offsetof(FRigUnit_SpringInterpV2, Current) == 0x1c, "Offset mismatch for FRigUnit_SpringInterpV2::Current");
static_assert(offsetof(FRigUnit_SpringInterpV2, TargetVelocityAmount) == 0x20, "Offset mismatch for FRigUnit_SpringInterpV2::TargetVelocityAmount");
static_assert(offsetof(FRigUnit_SpringInterpV2, bInitializeFromTarget) == 0x24, "Offset mismatch for FRigUnit_SpringInterpV2::bInitializeFromTarget");
static_assert(offsetof(FRigUnit_SpringInterpV2, Result) == 0x28, "Offset mismatch for FRigUnit_SpringInterpV2::Result");
static_assert(offsetof(FRigUnit_SpringInterpV2, Velocity) == 0x2c, "Offset mismatch for FRigUnit_SpringInterpV2::Velocity");
static_assert(offsetof(FRigUnit_SpringInterpV2, SimulatedResult) == 0x30, "Offset mismatch for FRigUnit_SpringInterpV2::SimulatedResult");
static_assert(offsetof(FRigUnit_SpringInterpV2, SpringState) == 0x34, "Offset mismatch for FRigUnit_SpringInterpV2::SpringState");

// Size: 0xe8 (Inherited: 0x10, Single: 0xd8)
struct FRigUnit_SpringInterpVectorV2 : FRigVMFunction_SimBase
{
    FVector Target; // 0x8 (Size: 0x18, Type: StructProperty)
    float Strength; // 0x20 (Size: 0x4, Type: FloatProperty)
    float CriticalDamping; // 0x24 (Size: 0x4, Type: FloatProperty)
    FVector Force; // 0x28 (Size: 0x18, Type: StructProperty)
    bool bUseCurrentInput; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
    FVector Current; // 0x48 (Size: 0x18, Type: StructProperty)
    float TargetVelocityAmount; // 0x60 (Size: 0x4, Type: FloatProperty)
    bool bInitializeFromTarget; // 0x64 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_65[0x3]; // 0x65 (Size: 0x3, Type: PaddingProperty)
    FVector Result; // 0x68 (Size: 0x18, Type: StructProperty)
    FVector Velocity; // 0x80 (Size: 0x18, Type: StructProperty)
    FVector SimulatedResult; // 0x98 (Size: 0x18, Type: StructProperty)
    FVectorSpringState SpringState; // 0xb0 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SpringInterpVectorV2) == 0xe8, "Size mismatch for FRigUnit_SpringInterpVectorV2");
static_assert(offsetof(FRigUnit_SpringInterpVectorV2, Target) == 0x8, "Offset mismatch for FRigUnit_SpringInterpVectorV2::Target");
static_assert(offsetof(FRigUnit_SpringInterpVectorV2, Strength) == 0x20, "Offset mismatch for FRigUnit_SpringInterpVectorV2::Strength");
static_assert(offsetof(FRigUnit_SpringInterpVectorV2, CriticalDamping) == 0x24, "Offset mismatch for FRigUnit_SpringInterpVectorV2::CriticalDamping");
static_assert(offsetof(FRigUnit_SpringInterpVectorV2, Force) == 0x28, "Offset mismatch for FRigUnit_SpringInterpVectorV2::Force");
static_assert(offsetof(FRigUnit_SpringInterpVectorV2, bUseCurrentInput) == 0x40, "Offset mismatch for FRigUnit_SpringInterpVectorV2::bUseCurrentInput");
static_assert(offsetof(FRigUnit_SpringInterpVectorV2, Current) == 0x48, "Offset mismatch for FRigUnit_SpringInterpVectorV2::Current");
static_assert(offsetof(FRigUnit_SpringInterpVectorV2, TargetVelocityAmount) == 0x60, "Offset mismatch for FRigUnit_SpringInterpVectorV2::TargetVelocityAmount");
static_assert(offsetof(FRigUnit_SpringInterpVectorV2, bInitializeFromTarget) == 0x64, "Offset mismatch for FRigUnit_SpringInterpVectorV2::bInitializeFromTarget");
static_assert(offsetof(FRigUnit_SpringInterpVectorV2, Result) == 0x68, "Offset mismatch for FRigUnit_SpringInterpVectorV2::Result");
static_assert(offsetof(FRigUnit_SpringInterpVectorV2, Velocity) == 0x80, "Offset mismatch for FRigUnit_SpringInterpVectorV2::Velocity");
static_assert(offsetof(FRigUnit_SpringInterpVectorV2, SimulatedResult) == 0x98, "Offset mismatch for FRigUnit_SpringInterpVectorV2::SimulatedResult");
static_assert(offsetof(FRigUnit_SpringInterpVectorV2, SpringState) == 0xb0, "Offset mismatch for FRigUnit_SpringInterpVectorV2::SpringState");

// Size: 0x130 (Inherited: 0x10, Single: 0x120)
struct FRigUnit_SpringInterpQuaternionV2 : FRigVMFunction_SimBase
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FQuat Target; // 0x10 (Size: 0x20, Type: StructProperty)
    float Strength; // 0x30 (Size: 0x4, Type: FloatProperty)
    float CriticalDamping; // 0x34 (Size: 0x4, Type: FloatProperty)
    FVector Torque; // 0x38 (Size: 0x18, Type: StructProperty)
    bool bUseCurrentInput; // 0x50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51[0xf]; // 0x51 (Size: 0xf, Type: PaddingProperty)
    FQuat Current; // 0x60 (Size: 0x20, Type: StructProperty)
    float TargetVelocityAmount; // 0x80 (Size: 0x4, Type: FloatProperty)
    bool bInitializeFromTarget; // 0x84 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_85[0xb]; // 0x85 (Size: 0xb, Type: PaddingProperty)
    FQuat Result; // 0x90 (Size: 0x20, Type: StructProperty)
    FVector AngularVelocity; // 0xb0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
    FQuat SimulatedResult; // 0xd0 (Size: 0x20, Type: StructProperty)
    FQuaternionSpringState SpringState; // 0xf0 (Size: 0x40, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_SpringInterpQuaternionV2) == 0x130, "Size mismatch for FRigUnit_SpringInterpQuaternionV2");
static_assert(offsetof(FRigUnit_SpringInterpQuaternionV2, Target) == 0x10, "Offset mismatch for FRigUnit_SpringInterpQuaternionV2::Target");
static_assert(offsetof(FRigUnit_SpringInterpQuaternionV2, Strength) == 0x30, "Offset mismatch for FRigUnit_SpringInterpQuaternionV2::Strength");
static_assert(offsetof(FRigUnit_SpringInterpQuaternionV2, CriticalDamping) == 0x34, "Offset mismatch for FRigUnit_SpringInterpQuaternionV2::CriticalDamping");
static_assert(offsetof(FRigUnit_SpringInterpQuaternionV2, Torque) == 0x38, "Offset mismatch for FRigUnit_SpringInterpQuaternionV2::Torque");
static_assert(offsetof(FRigUnit_SpringInterpQuaternionV2, bUseCurrentInput) == 0x50, "Offset mismatch for FRigUnit_SpringInterpQuaternionV2::bUseCurrentInput");
static_assert(offsetof(FRigUnit_SpringInterpQuaternionV2, Current) == 0x60, "Offset mismatch for FRigUnit_SpringInterpQuaternionV2::Current");
static_assert(offsetof(FRigUnit_SpringInterpQuaternionV2, TargetVelocityAmount) == 0x80, "Offset mismatch for FRigUnit_SpringInterpQuaternionV2::TargetVelocityAmount");
static_assert(offsetof(FRigUnit_SpringInterpQuaternionV2, bInitializeFromTarget) == 0x84, "Offset mismatch for FRigUnit_SpringInterpQuaternionV2::bInitializeFromTarget");
static_assert(offsetof(FRigUnit_SpringInterpQuaternionV2, Result) == 0x90, "Offset mismatch for FRigUnit_SpringInterpQuaternionV2::Result");
static_assert(offsetof(FRigUnit_SpringInterpQuaternionV2, AngularVelocity) == 0xb0, "Offset mismatch for FRigUnit_SpringInterpQuaternionV2::AngularVelocity");
static_assert(offsetof(FRigUnit_SpringInterpQuaternionV2, SimulatedResult) == 0xd0, "Offset mismatch for FRigUnit_SpringInterpQuaternionV2::SimulatedResult");
static_assert(offsetof(FRigUnit_SpringInterpQuaternionV2, SpringState) == 0xf0, "Offset mismatch for FRigUnit_SpringInterpQuaternionV2::SpringState");

