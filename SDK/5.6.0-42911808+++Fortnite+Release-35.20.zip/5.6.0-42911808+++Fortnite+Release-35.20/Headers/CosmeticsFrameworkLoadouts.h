/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticsFrameworkLoadouts
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UBasicCosmeticLoadoutContext : public UObject
{
public:
};

static_assert(sizeof(UBasicCosmeticLoadoutContext) == 0x30, "Size mismatch for UBasicCosmeticLoadoutContext");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCosmeticCustomizableItemDefinition : public UInterface
{
public:
};

static_assert(sizeof(UCosmeticCustomizableItemDefinition) == 0x28, "Size mismatch for UCosmeticCustomizableItemDefinition");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCosmeticLoadoutContext : public UInterface
{
public:
};

static_assert(sizeof(UCosmeticLoadoutContext) == 0x28, "Size mismatch for UCosmeticLoadoutContext");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCosmeticLoadoutItemDefinition : public UInterface
{
public:
};

static_assert(sizeof(UCosmeticLoadoutItemDefinition) == 0x28, "Size mismatch for UCosmeticLoadoutItemDefinition");

// Size: 0x80 (Inherited: 0x88, Single: 0xfffffff8)
class UCosmeticLoadoutSchema : public UPrimaryDataAsset
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    FText DisplayName; // 0x38 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D*> Icon; // 0x48 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayTag ArchetypeTag; // 0x68 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
    TArray<UCosmeticLoadoutSlotTemplate*> Slots; // 0x70 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCosmeticLoadoutSchema) == 0x80, "Size mismatch for UCosmeticLoadoutSchema");
static_assert(offsetof(UCosmeticLoadoutSchema, DisplayName) == 0x38, "Offset mismatch for UCosmeticLoadoutSchema::DisplayName");
static_assert(offsetof(UCosmeticLoadoutSchema, Icon) == 0x48, "Offset mismatch for UCosmeticLoadoutSchema::Icon");
static_assert(offsetof(UCosmeticLoadoutSchema, ArchetypeTag) == 0x68, "Offset mismatch for UCosmeticLoadoutSchema::ArchetypeTag");
static_assert(offsetof(UCosmeticLoadoutSchema, Slots) == 0x70, "Offset mismatch for UCosmeticLoadoutSchema::Slots");

// Size: 0xd0 (Inherited: 0x88, Single: 0x48)
class UCosmeticLoadoutSlotTemplate : public UPrimaryDataAsset
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    FGameplayTag SlotTag; // 0x38 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer MetaTags; // 0x40 (Size: 0x20, Type: StructProperty)
    FCosmeticLoadoutSlotRequirements Requirements; // 0x60 (Size: 0x50, Type: StructProperty)
    FString ShortName; // 0xb0 (Size: 0x10, Type: StrProperty)
    FPrimaryAssetId DefaultCosmeticItemId; // 0xc0 (Size: 0x8, Type: StructProperty)
    bool bAlwaysUseDefaultCosmeticItemId; // 0xc8 (Size: 0x1, Type: BoolProperty)
    bool bIsEquippable; // 0xc9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ca[0x6]; // 0xca (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UCosmeticLoadoutSlotTemplate) == 0xd0, "Size mismatch for UCosmeticLoadoutSlotTemplate");
static_assert(offsetof(UCosmeticLoadoutSlotTemplate, SlotTag) == 0x38, "Offset mismatch for UCosmeticLoadoutSlotTemplate::SlotTag");
static_assert(offsetof(UCosmeticLoadoutSlotTemplate, MetaTags) == 0x40, "Offset mismatch for UCosmeticLoadoutSlotTemplate::MetaTags");
static_assert(offsetof(UCosmeticLoadoutSlotTemplate, Requirements) == 0x60, "Offset mismatch for UCosmeticLoadoutSlotTemplate::Requirements");
static_assert(offsetof(UCosmeticLoadoutSlotTemplate, ShortName) == 0xb0, "Offset mismatch for UCosmeticLoadoutSlotTemplate::ShortName");
static_assert(offsetof(UCosmeticLoadoutSlotTemplate, DefaultCosmeticItemId) == 0xc0, "Offset mismatch for UCosmeticLoadoutSlotTemplate::DefaultCosmeticItemId");
static_assert(offsetof(UCosmeticLoadoutSlotTemplate, bAlwaysUseDefaultCosmeticItemId) == 0xc8, "Offset mismatch for UCosmeticLoadoutSlotTemplate::bAlwaysUseDefaultCosmeticItemId");
static_assert(offsetof(UCosmeticLoadoutSlotTemplate, bIsEquippable) == 0xc9, "Offset mismatch for UCosmeticLoadoutSlotTemplate::bIsEquippable");

// Size: 0x78 (Inherited: 0x88, Single: 0xfffffff0)
class UCosmeticLoadoutArchetype : public UPrimaryDataAsset
{
public:
    FText DisplayName; // 0x30 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D*> Icon; // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayTag ArchetypeGroupTag; // 0x60 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_64[0x4]; // 0x64 (Size: 0x4, Type: PaddingProperty)
    TArray<UCosmeticLoadoutSchema*> Schemas; // 0x68 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCosmeticLoadoutArchetype) == 0x78, "Size mismatch for UCosmeticLoadoutArchetype");
static_assert(offsetof(UCosmeticLoadoutArchetype, DisplayName) == 0x30, "Offset mismatch for UCosmeticLoadoutArchetype::DisplayName");
static_assert(offsetof(UCosmeticLoadoutArchetype, Icon) == 0x40, "Offset mismatch for UCosmeticLoadoutArchetype::Icon");
static_assert(offsetof(UCosmeticLoadoutArchetype, ArchetypeGroupTag) == 0x60, "Offset mismatch for UCosmeticLoadoutArchetype::ArchetypeGroupTag");
static_assert(offsetof(UCosmeticLoadoutArchetype, Schemas) == 0x68, "Offset mismatch for UCosmeticLoadoutArchetype::Schemas");

// Size: 0x80 (Inherited: 0x88, Single: 0xfffffff8)
class UCosmeticLoadoutSubsystem : public UGameInstanceSubsystem
{
public:
};

static_assert(sizeof(UCosmeticLoadoutSubsystem) == 0x80, "Size mismatch for UCosmeticLoadoutSubsystem");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FCosmeticLoadoutActiveArchetype
{
    FGameplayTag ArchetypeGroupTag; // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag ArchetypeTag; // 0x4 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FCosmeticLoadoutActiveArchetype) == 0x8, "Size mismatch for FCosmeticLoadoutActiveArchetype");
static_assert(offsetof(FCosmeticLoadoutActiveArchetype, ArchetypeGroupTag) == 0x0, "Offset mismatch for FCosmeticLoadoutActiveArchetype::ArchetypeGroupTag");
static_assert(offsetof(FCosmeticLoadoutActiveArchetype, ArchetypeTag) == 0x4, "Offset mismatch for FCosmeticLoadoutActiveArchetype::ArchetypeTag");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCosmeticLoadout
{
    TArray<FCosmeticLoadoutSlot> Slots; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCosmeticLoadout) == 0x10, "Size mismatch for FCosmeticLoadout");
static_assert(offsetof(FCosmeticLoadout, Slots) == 0x0, "Offset mismatch for FCosmeticLoadout::Slots");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCosmeticLoadoutSlot
{
    UCosmeticLoadoutSlotTemplate* SlotTemplate; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UObject* EquippedItemDefinitionObject; // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<FCosmeticCustomizationInfo> CustomizationInfo; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCosmeticLoadoutSlot) == 0x20, "Size mismatch for FCosmeticLoadoutSlot");
static_assert(offsetof(FCosmeticLoadoutSlot, SlotTemplate) == 0x0, "Offset mismatch for FCosmeticLoadoutSlot::SlotTemplate");
static_assert(offsetof(FCosmeticLoadoutSlot, EquippedItemDefinitionObject) == 0x8, "Offset mismatch for FCosmeticLoadoutSlot::EquippedItemDefinitionObject");
static_assert(offsetof(FCosmeticLoadoutSlot, CustomizationInfo) == 0x10, "Offset mismatch for FCosmeticLoadoutSlot::CustomizationInfo");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCosmeticCustomizationInfo
{
    FGameplayTag ChannelTag; // 0x0 (Size: 0x4, Type: StructProperty)
    FGameplayTag VariantTag; // 0x4 (Size: 0x4, Type: StructProperty)
    FString AdditionalData; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FCosmeticCustomizationInfo) == 0x18, "Size mismatch for FCosmeticCustomizationInfo");
static_assert(offsetof(FCosmeticCustomizationInfo, ChannelTag) == 0x0, "Offset mismatch for FCosmeticCustomizationInfo::ChannelTag");
static_assert(offsetof(FCosmeticCustomizationInfo, VariantTag) == 0x4, "Offset mismatch for FCosmeticCustomizationInfo::VariantTag");
static_assert(offsetof(FCosmeticCustomizationInfo, AdditionalData) == 0x8, "Offset mismatch for FCosmeticCustomizationInfo::AdditionalData");

// Size: 0xc0 (Inherited: 0x0, Single: 0xc0)
struct FCosmeticBackendLoadoutGroup
{
    TMap<FCosmeticBackendLoadoutGroupSlot, FString> Slots; // 0x0 (Size: 0x50, Type: MapProperty)
    FString ShuffleType; // 0x50 (Size: 0x10, Type: StrProperty)
    FString FavoriteStatus; // 0x60 (Size: 0x10, Type: StrProperty)
    FString DisplayName; // 0x70 (Size: 0x10, Type: StrProperty)
    FString ItemId; // 0x80 (Size: 0x10, Type: StrProperty)
    FString LinkedPresetId; // 0x90 (Size: 0x10, Type: StrProperty)
    FString PresetId; // 0xa0 (Size: 0x10, Type: StrProperty)
    int32_t PresetIndex; // 0xb0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_b4[0x4]; // 0xb4 (Size: 0x4, Type: PaddingProperty)
    FDateTime CreationTime; // 0xb8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FCosmeticBackendLoadoutGroup) == 0xc0, "Size mismatch for FCosmeticBackendLoadoutGroup");
static_assert(offsetof(FCosmeticBackendLoadoutGroup, Slots) == 0x0, "Offset mismatch for FCosmeticBackendLoadoutGroup::Slots");
static_assert(offsetof(FCosmeticBackendLoadoutGroup, ShuffleType) == 0x50, "Offset mismatch for FCosmeticBackendLoadoutGroup::ShuffleType");
static_assert(offsetof(FCosmeticBackendLoadoutGroup, FavoriteStatus) == 0x60, "Offset mismatch for FCosmeticBackendLoadoutGroup::FavoriteStatus");
static_assert(offsetof(FCosmeticBackendLoadoutGroup, DisplayName) == 0x70, "Offset mismatch for FCosmeticBackendLoadoutGroup::DisplayName");
static_assert(offsetof(FCosmeticBackendLoadoutGroup, ItemId) == 0x80, "Offset mismatch for FCosmeticBackendLoadoutGroup::ItemId");
static_assert(offsetof(FCosmeticBackendLoadoutGroup, LinkedPresetId) == 0x90, "Offset mismatch for FCosmeticBackendLoadoutGroup::LinkedPresetId");
static_assert(offsetof(FCosmeticBackendLoadoutGroup, PresetId) == 0xa0, "Offset mismatch for FCosmeticBackendLoadoutGroup::PresetId");
static_assert(offsetof(FCosmeticBackendLoadoutGroup, PresetIndex) == 0xb0, "Offset mismatch for FCosmeticBackendLoadoutGroup::PresetIndex");
static_assert(offsetof(FCosmeticBackendLoadoutGroup, CreationTime) == 0xb8, "Offset mismatch for FCosmeticBackendLoadoutGroup::CreationTime");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FCosmeticBackendLoadoutGroupSlot
{
    FString LinkedPresetId; // 0x0 (Size: 0x10, Type: StrProperty)
    TArray<FCosmeticBackendLoadoutSlot> Slots; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FString ShuffleType; // 0x20 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FCosmeticBackendLoadoutGroupSlot) == 0x30, "Size mismatch for FCosmeticBackendLoadoutGroupSlot");
static_assert(offsetof(FCosmeticBackendLoadoutGroupSlot, LinkedPresetId) == 0x0, "Offset mismatch for FCosmeticBackendLoadoutGroupSlot::LinkedPresetId");
static_assert(offsetof(FCosmeticBackendLoadoutGroupSlot, Slots) == 0x10, "Offset mismatch for FCosmeticBackendLoadoutGroupSlot::Slots");
static_assert(offsetof(FCosmeticBackendLoadoutGroupSlot, ShuffleType) == 0x20, "Offset mismatch for FCosmeticBackendLoadoutGroupSlot::ShuffleType");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCosmeticBackendLoadoutSlot
{
    FPrimaryAssetId SlotTemplate; // 0x0 (Size: 0x8, Type: StructProperty)
    FPrimaryAssetId EquippedItem; // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FCosmeticCustomizationInfo> CustomizationInfo; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCosmeticBackendLoadoutSlot) == 0x20, "Size mismatch for FCosmeticBackendLoadoutSlot");
static_assert(offsetof(FCosmeticBackendLoadoutSlot, SlotTemplate) == 0x0, "Offset mismatch for FCosmeticBackendLoadoutSlot::SlotTemplate");
static_assert(offsetof(FCosmeticBackendLoadoutSlot, EquippedItem) == 0x8, "Offset mismatch for FCosmeticBackendLoadoutSlot::EquippedItem");
static_assert(offsetof(FCosmeticBackendLoadoutSlot, CustomizationInfo) == 0x10, "Offset mismatch for FCosmeticBackendLoadoutSlot::CustomizationInfo");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FCosmeticLoadoutSlotRequirements
{
    FGameplayTagContainer RequiredTags; // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer DeniedTags; // 0x20 (Size: 0x20, Type: StructProperty)
    TArray<FPrimaryAssetType> AllowedItemTypes; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCosmeticLoadoutSlotRequirements) == 0x50, "Size mismatch for FCosmeticLoadoutSlotRequirements");
static_assert(offsetof(FCosmeticLoadoutSlotRequirements, RequiredTags) == 0x0, "Offset mismatch for FCosmeticLoadoutSlotRequirements::RequiredTags");
static_assert(offsetof(FCosmeticLoadoutSlotRequirements, DeniedTags) == 0x20, "Offset mismatch for FCosmeticLoadoutSlotRequirements::DeniedTags");
static_assert(offsetof(FCosmeticLoadoutSlotRequirements, AllowedItemTypes) == 0x40, "Offset mismatch for FCosmeticLoadoutSlotRequirements::AllowedItemTypes");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FCosmeticBackendLoadout
{
    FString ItemId; // 0x0 (Size: 0x10, Type: StrProperty)
    FString PresetId; // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t PresetIndex; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FDateTime CreationTime; // 0x28 (Size: 0x8, Type: StructProperty)
    TArray<FCosmeticBackendLoadoutSlot> Slots; // 0x30 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer UserTags; // 0x40 (Size: 0x20, Type: StructProperty)
    FString DisplayName; // 0x60 (Size: 0x10, Type: StrProperty)
    FString FavoriteStatus; // 0x70 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FCosmeticBackendLoadout) == 0x80, "Size mismatch for FCosmeticBackendLoadout");
static_assert(offsetof(FCosmeticBackendLoadout, ItemId) == 0x0, "Offset mismatch for FCosmeticBackendLoadout::ItemId");
static_assert(offsetof(FCosmeticBackendLoadout, PresetId) == 0x10, "Offset mismatch for FCosmeticBackendLoadout::PresetId");
static_assert(offsetof(FCosmeticBackendLoadout, PresetIndex) == 0x20, "Offset mismatch for FCosmeticBackendLoadout::PresetIndex");
static_assert(offsetof(FCosmeticBackendLoadout, CreationTime) == 0x28, "Offset mismatch for FCosmeticBackendLoadout::CreationTime");
static_assert(offsetof(FCosmeticBackendLoadout, Slots) == 0x30, "Offset mismatch for FCosmeticBackendLoadout::Slots");
static_assert(offsetof(FCosmeticBackendLoadout, UserTags) == 0x40, "Offset mismatch for FCosmeticBackendLoadout::UserTags");
static_assert(offsetof(FCosmeticBackendLoadout, DisplayName) == 0x60, "Offset mismatch for FCosmeticBackendLoadout::DisplayName");
static_assert(offsetof(FCosmeticBackendLoadout, FavoriteStatus) == 0x70, "Offset mismatch for FCosmeticBackendLoadout::FavoriteStatus");

