/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EnergyRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "ModularGameplay.h"
#include "GameplayTags.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayAbilities.h"

// Size: 0xa8 (Inherited: 0x88, Single: 0x20)
class UFortEnergyAttrSet : public UFortAttributeSet
{
public:
    FFortGameplayAttributeData MaxEnergy; // 0x30 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData RechargeAmountPerSecond; // 0x58 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData EnergyUsageMultiplier; // 0x80 (Size: 0x28, Type: StructProperty)

public:
    void OnRep_EnergyUsageMultiplier(const FFortGameplayAttributeData OldValue); // 0xff8aaec (Index: 0x0, Flags: Final|Native|Public|HasOutParms)
    void OnRep_MaxEnergy(const FFortGameplayAttributeData OldValue); // 0xff8abf4 (Index: 0x1, Flags: Final|Native|Public|HasOutParms)
    void OnRep_RechargeAmountPerSecond(const FFortGameplayAttributeData OldValue); // 0xff8acfc (Index: 0x2, Flags: Final|Native|Public|HasOutParms)
};

static_assert(sizeof(UFortEnergyAttrSet) == 0xa8, "Size mismatch for UFortEnergyAttrSet");
static_assert(offsetof(UFortEnergyAttrSet, MaxEnergy) == 0x30, "Offset mismatch for UFortEnergyAttrSet::MaxEnergy");
static_assert(offsetof(UFortEnergyAttrSet, RechargeAmountPerSecond) == 0x58, "Offset mismatch for UFortEnergyAttrSet::RechargeAmountPerSecond");
static_assert(offsetof(UFortEnergyAttrSet, EnergyUsageMultiplier) == 0x80, "Offset mismatch for UFortEnergyAttrSet::EnergyUsageMultiplier");

// Size: 0x3e8 (Inherited: 0x250, Single: 0x198)
class UFortComponent_Energy : public UPawnComponent
{
public:
    uint8_t OnEnergyCompletelyDrained[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEnergyRechargeComplete[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FGameplayAttribute MaxEnergyAttribute; // 0xd8 (Size: 0x38, Type: StructProperty)
    FScalableFloat MaxEnergy; // 0x110 (Size: 0x28, Type: StructProperty)
    FGameplayTagQuery RechargeDisabledQuery; // 0x138 (Size: 0x48, Type: StructProperty)
    uint8_t Pad_180[0x10]; // 0x180 (Size: 0x10, Type: PaddingProperty)
    FGameplayTagQuery EnergyUseDisabledQuery; // 0x190 (Size: 0x48, Type: StructProperty)
    FTimerHandle BeginRechargeTimerHandle; // 0x1d8 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer EnergyTypeIdentifierTagContainer; // 0x1e0 (Size: 0x20, Type: StructProperty)
    float CurrentEnergy; // 0x200 (Size: 0x4, Type: FloatProperty)
    float CachedMaxEnergy; // 0x204 (Size: 0x4, Type: FloatProperty)
    float NetEnergyDeltaPerSecond; // 0x208 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_20c[0x4]; // 0x20c (Size: 0x4, Type: PaddingProperty)
    FScalableFloat MinEnergyForUsing; // 0x210 (Size: 0x28, Type: StructProperty)
    FGameplayAttribute RechargeAmountPerSecondAttribute; // 0x238 (Size: 0x38, Type: StructProperty)
    FScalableFloat RechargeAmountPerSecond; // 0x270 (Size: 0x28, Type: StructProperty)
    FScalableFloat RechargeDelayInSeconds; // 0x298 (Size: 0x28, Type: StructProperty)
    FScalableFloat RechargePercentageLimit; // 0x2c0 (Size: 0x28, Type: StructProperty)
    FGameplayAttribute EnergyUsageMultiplierAttribute; // 0x2e8 (Size: 0x38, Type: StructProperty)
    FScalableFloat EnergyUsageMultiplier; // 0x320 (Size: 0x28, Type: StructProperty)
    bool bRemoveEnergyUsersWhenEmpty; // 0x348 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_349[0x7]; // 0x349 (Size: 0x7, Type: PaddingProperty)
    TArray<FEnergyChannelingData> ActiveEnergyChannels; // 0x350 (Size: 0x10, Type: ArrayProperty)
    TArray<FEnergyChannelingData> NewActiveEnergyChannels; // 0x360 (Size: 0x10, Type: ArrayProperty)
    TArray<FEnergyRegenOverrideData> EnergyRegenOverrides; // 0x370 (Size: 0x10, Type: ArrayProperty)
    uint8_t OnCurrentEnergyChanged[0x10]; // 0x380 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEnergyChunkAdded[0x10]; // 0x390 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEnergyRechargeBegun[0x10]; // 0x3a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEnergyRechargeInterrupted[0x10]; // 0x3b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEnergyReachedMax[0x10]; // 0x3c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEnergyReachedMinForUsing[0x10]; // 0x3d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t bRechargingEnabled : 1; // 0x3e0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsRecharging : 1; // 0x3e0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsUsingEnergy : 1; // 0x3e0:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bAllowEditMaxEnergyScalableFloat : 1; // 0x3e0:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bAllowEditRechargeAmountPerSecondScalableFloat : 1; // 0x3e0:5 (Size: 0x1, Type: BoolProperty)
    uint8_t bAllowEditEnergyUsageMultiplierScalableFloat : 1; // 0x3e0:6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3e1[0x7]; // 0x3e1 (Size: 0x7, Type: PaddingProperty)

public:
    bool AddEnergy(float& OutAmountOfEnergyAdded, float& AmountOfEnergyToAdd, UObject*& OptionalEnergySource, bool& bBroadcastEnergyPercentChanged, FGameplayTagContainer& AdditionalTags); // 0xff8a1ac (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void ApplyRegenDataOverride(const FGameplayTag RegenOverrideIdentifier, float& const NewRechargeAmountPerSecond, float& const NewRechargeDelayInSeconds, float& const NewRechargePercentageLimit); // 0xff8a708 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    virtual bool BP_HasSufficientEnergy(float& EnergyAmountToTest) const; // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent|Const)
    float GetCurrentEnergyPercentage() const; // 0xff8a984 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasSufficientEnergy(float& EnergyAmountToTest) const; // 0xff8a9ac (Index: 0x6, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool RemoveRegenDataOverride(const FGameplayTag RegenOverrideIdentifier); // 0xff8b2b4 (Index: 0xa, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool SetAllEnergyUsageFree(bool& bShouldEnergyUsageBeFree); // 0xff8b3b0 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    bool StartAddingEnergy(float& EnergyToAddPerSecond, const FGameplayTag EnergySourceIdentifier, UObject*& OptionalEnergySource); // 0xff8b4fc (Index: 0xc, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool StartUsingEnergy(float& EnergyToUseToStart, float& EnergyToUsePerSecond, const FGameplayTag EnergyUseIdentifier, UObject*& OptionalEnergyUser); // 0xff8b760 (Index: 0xd, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool StopAddingEnergy(const FGameplayTag EnergyUseIdentifier, UObject*& OptionalEnergySource); // 0xff8ba98 (Index: 0xe, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool StopUsingEnergy(const FGameplayTag EnergyUseIdentifier, UObject*& OptionalEnergyUser); // 0xff8bc14 (Index: 0xf, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool UseEnergy(float& OutAmountOfEnergyUsed, float& AmountOfEnergyToUse, bool& bUseEnergyEvenOnFailure, UObject*& OptionalEnergyUser, bool& bBroadcastEnergyPercentChanged); // 0x541c148 (Index: 0x10, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

private:
    void HandleAbilitySystemComponentInitialized(UFortAbilitySystemComponent*& AbilitySystemComponent, AFortPlayerPawn*& PlayerPawn); // 0x319ce4c (Index: 0x4, Flags: Final|Native|Private)
    void HandleAbilitySystemComponentInvalidated(); // 0x5ac8140 (Index: 0x5, Flags: Final|Native|Private)
    void OnMutatorUpdated(); // 0x2f9c118 (Index: 0x7, Flags: Final|Native|Private)
    void OnPlayerStatePawnSet(APlayerState*& Player, APawn*& NewPawn, APawn*& OldPawn); // 0x553458c (Index: 0x8, Flags: Final|Native|Private)
    void RegisterMutatorUpdatedDelegate(APawn*& AffectedPawn); // 0xff8ae04 (Index: 0x9, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortComponent_Energy) == 0x3e8, "Size mismatch for UFortComponent_Energy");
static_assert(offsetof(UFortComponent_Energy, OnEnergyCompletelyDrained) == 0xb8, "Offset mismatch for UFortComponent_Energy::OnEnergyCompletelyDrained");
static_assert(offsetof(UFortComponent_Energy, OnEnergyRechargeComplete) == 0xc8, "Offset mismatch for UFortComponent_Energy::OnEnergyRechargeComplete");
static_assert(offsetof(UFortComponent_Energy, MaxEnergyAttribute) == 0xd8, "Offset mismatch for UFortComponent_Energy::MaxEnergyAttribute");
static_assert(offsetof(UFortComponent_Energy, MaxEnergy) == 0x110, "Offset mismatch for UFortComponent_Energy::MaxEnergy");
static_assert(offsetof(UFortComponent_Energy, RechargeDisabledQuery) == 0x138, "Offset mismatch for UFortComponent_Energy::RechargeDisabledQuery");
static_assert(offsetof(UFortComponent_Energy, EnergyUseDisabledQuery) == 0x190, "Offset mismatch for UFortComponent_Energy::EnergyUseDisabledQuery");
static_assert(offsetof(UFortComponent_Energy, BeginRechargeTimerHandle) == 0x1d8, "Offset mismatch for UFortComponent_Energy::BeginRechargeTimerHandle");
static_assert(offsetof(UFortComponent_Energy, EnergyTypeIdentifierTagContainer) == 0x1e0, "Offset mismatch for UFortComponent_Energy::EnergyTypeIdentifierTagContainer");
static_assert(offsetof(UFortComponent_Energy, CurrentEnergy) == 0x200, "Offset mismatch for UFortComponent_Energy::CurrentEnergy");
static_assert(offsetof(UFortComponent_Energy, CachedMaxEnergy) == 0x204, "Offset mismatch for UFortComponent_Energy::CachedMaxEnergy");
static_assert(offsetof(UFortComponent_Energy, NetEnergyDeltaPerSecond) == 0x208, "Offset mismatch for UFortComponent_Energy::NetEnergyDeltaPerSecond");
static_assert(offsetof(UFortComponent_Energy, MinEnergyForUsing) == 0x210, "Offset mismatch for UFortComponent_Energy::MinEnergyForUsing");
static_assert(offsetof(UFortComponent_Energy, RechargeAmountPerSecondAttribute) == 0x238, "Offset mismatch for UFortComponent_Energy::RechargeAmountPerSecondAttribute");
static_assert(offsetof(UFortComponent_Energy, RechargeAmountPerSecond) == 0x270, "Offset mismatch for UFortComponent_Energy::RechargeAmountPerSecond");
static_assert(offsetof(UFortComponent_Energy, RechargeDelayInSeconds) == 0x298, "Offset mismatch for UFortComponent_Energy::RechargeDelayInSeconds");
static_assert(offsetof(UFortComponent_Energy, RechargePercentageLimit) == 0x2c0, "Offset mismatch for UFortComponent_Energy::RechargePercentageLimit");
static_assert(offsetof(UFortComponent_Energy, EnergyUsageMultiplierAttribute) == 0x2e8, "Offset mismatch for UFortComponent_Energy::EnergyUsageMultiplierAttribute");
static_assert(offsetof(UFortComponent_Energy, EnergyUsageMultiplier) == 0x320, "Offset mismatch for UFortComponent_Energy::EnergyUsageMultiplier");
static_assert(offsetof(UFortComponent_Energy, bRemoveEnergyUsersWhenEmpty) == 0x348, "Offset mismatch for UFortComponent_Energy::bRemoveEnergyUsersWhenEmpty");
static_assert(offsetof(UFortComponent_Energy, ActiveEnergyChannels) == 0x350, "Offset mismatch for UFortComponent_Energy::ActiveEnergyChannels");
static_assert(offsetof(UFortComponent_Energy, NewActiveEnergyChannels) == 0x360, "Offset mismatch for UFortComponent_Energy::NewActiveEnergyChannels");
static_assert(offsetof(UFortComponent_Energy, EnergyRegenOverrides) == 0x370, "Offset mismatch for UFortComponent_Energy::EnergyRegenOverrides");
static_assert(offsetof(UFortComponent_Energy, OnCurrentEnergyChanged) == 0x380, "Offset mismatch for UFortComponent_Energy::OnCurrentEnergyChanged");
static_assert(offsetof(UFortComponent_Energy, OnEnergyChunkAdded) == 0x390, "Offset mismatch for UFortComponent_Energy::OnEnergyChunkAdded");
static_assert(offsetof(UFortComponent_Energy, OnEnergyRechargeBegun) == 0x3a0, "Offset mismatch for UFortComponent_Energy::OnEnergyRechargeBegun");
static_assert(offsetof(UFortComponent_Energy, OnEnergyRechargeInterrupted) == 0x3b0, "Offset mismatch for UFortComponent_Energy::OnEnergyRechargeInterrupted");
static_assert(offsetof(UFortComponent_Energy, OnEnergyReachedMax) == 0x3c0, "Offset mismatch for UFortComponent_Energy::OnEnergyReachedMax");
static_assert(offsetof(UFortComponent_Energy, OnEnergyReachedMinForUsing) == 0x3d0, "Offset mismatch for UFortComponent_Energy::OnEnergyReachedMinForUsing");
static_assert(offsetof(UFortComponent_Energy, bRechargingEnabled) == 0x3e0, "Offset mismatch for UFortComponent_Energy::bRechargingEnabled");
static_assert(offsetof(UFortComponent_Energy, bIsRecharging) == 0x3e0, "Offset mismatch for UFortComponent_Energy::bIsRecharging");
static_assert(offsetof(UFortComponent_Energy, bIsUsingEnergy) == 0x3e0, "Offset mismatch for UFortComponent_Energy::bIsUsingEnergy");
static_assert(offsetof(UFortComponent_Energy, bAllowEditMaxEnergyScalableFloat) == 0x3e0, "Offset mismatch for UFortComponent_Energy::bAllowEditMaxEnergyScalableFloat");
static_assert(offsetof(UFortComponent_Energy, bAllowEditRechargeAmountPerSecondScalableFloat) == 0x3e0, "Offset mismatch for UFortComponent_Energy::bAllowEditRechargeAmountPerSecondScalableFloat");
static_assert(offsetof(UFortComponent_Energy, bAllowEditEnergyUsageMultiplierScalableFloat) == 0x3e0, "Offset mismatch for UFortComponent_Energy::bAllowEditEnergyUsageMultiplierScalableFloat");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FEnergyChannelingData
{
    float EnergyPerSecond; // 0x0 (Size: 0x4, Type: FloatProperty)
    FGameplayTag EnergyChannelingPurposeIdentifier; // 0x4 (Size: 0x4, Type: StructProperty)
    UObject* OptionalEnergyChannelingSource; // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bShouldStopApplyingNextTick; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FEnergyChannelingData) == 0x18, "Size mismatch for FEnergyChannelingData");
static_assert(offsetof(FEnergyChannelingData, EnergyPerSecond) == 0x0, "Offset mismatch for FEnergyChannelingData::EnergyPerSecond");
static_assert(offsetof(FEnergyChannelingData, EnergyChannelingPurposeIdentifier) == 0x4, "Offset mismatch for FEnergyChannelingData::EnergyChannelingPurposeIdentifier");
static_assert(offsetof(FEnergyChannelingData, OptionalEnergyChannelingSource) == 0x8, "Offset mismatch for FEnergyChannelingData::OptionalEnergyChannelingSource");
static_assert(offsetof(FEnergyChannelingData, bShouldStopApplyingNextTick) == 0x10, "Offset mismatch for FEnergyChannelingData::bShouldStopApplyingNextTick");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEnergyRegenOverrideData
{
    FGameplayTag EnergyRegenIdentifier; // 0x0 (Size: 0x4, Type: StructProperty)
    float RechargeAmountPerSecond; // 0x4 (Size: 0x4, Type: FloatProperty)
    float RechargeDelayInSeconds; // 0x8 (Size: 0x4, Type: FloatProperty)
    float RechargePercentageLimit; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FEnergyRegenOverrideData) == 0x10, "Size mismatch for FEnergyRegenOverrideData");
static_assert(offsetof(FEnergyRegenOverrideData, EnergyRegenIdentifier) == 0x0, "Offset mismatch for FEnergyRegenOverrideData::EnergyRegenIdentifier");
static_assert(offsetof(FEnergyRegenOverrideData, RechargeAmountPerSecond) == 0x4, "Offset mismatch for FEnergyRegenOverrideData::RechargeAmountPerSecond");
static_assert(offsetof(FEnergyRegenOverrideData, RechargeDelayInSeconds) == 0x8, "Offset mismatch for FEnergyRegenOverrideData::RechargeDelayInSeconds");
static_assert(offsetof(FEnergyRegenOverrideData, RechargePercentageLimit) == 0xc, "Offset mismatch for FEnergyRegenOverrideData::RechargePercentageLimit");

