/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayStateMachine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "NetCore.h"
#include "GameplayTags.h"

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UGameplayState : public UObject
{
public:
    FGameplayTag StateId; // 0x28 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer StateRuntimeTags; // 0x30 (Size: 0x20, Type: StructProperty)
    bool bEvaluateTransition; // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bReplicates; // 0x51 (Size: 0x1, Type: BoolProperty)
    bool bStateBegun; // 0x52 (Size: 0x1, Type: BoolProperty)
    bool bStateEnded; // 0x53 (Size: 0x1, Type: BoolProperty)
    float InitializationServerTime; // 0x54 (Size: 0x4, Type: FloatProperty)
    float BeginStateDelay; // 0x58 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    UGameplayStateMachine* CachedGameplayStateMachine; // 0x60 (Size: 0x8, Type: ObjectProperty)
    UGameplayStateMachineManager* CachedStateMachineManager; // 0x68 (Size: 0x8, Type: ObjectProperty)
    UGameplayState* Hack_StateToDelayProcess; // 0x70 (Size: 0x8, Type: ObjectProperty)

public:
    void AddStateRuntimeTag(const FGameplayTag AddedTag); // 0x10abbee0 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    UGameplayStateMachine* GetGameplayStateMachine() const; // 0xecd32b4 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AActor* GetOwningActor() const; // 0x10abbfec (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetStateId() const; // 0xa973be0 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTagContainer GetStateRuntimeTags() const; // 0xee175b8 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasAuthority() const; // 0x10abc010 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasStateRuntimeTag(const FGameplayTag QueryTag); // 0x10abc034 (Index: 0xc, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void MarkStateToEvaluateTransitions(); // 0x10abc18c (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveStateRuntimeTag(const FGameplayTag RemovedTag); // 0x10abc1b4 (Index: 0x11, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

protected:
    virtual void BeginStateEvent(const FGameplayTag PrevStateId); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void BeginStateEventClient(const FGameplayTag PrevStateId); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void BeginStateEventServer(const FGameplayTag PrevStateId); // 0x288a61c (Index: 0x3, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void EndStateEvent(const FGameplayTag NextStateId); // 0x288a61c (Index: 0x4, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void EndStateEventClient(const FGameplayTag NextStateId); // 0x288a61c (Index: 0x5, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void EndStateEventServer(const FGameplayTag NextStateId); // 0x288a61c (Index: 0x6, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void InitializeStateEvent(const FGameplayTag PrevStateId); // 0x288a61c (Index: 0xd, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void InitializeStateEventClient(const FGameplayTag PrevStateId); // 0x288a61c (Index: 0xe, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void InitializeStateEventServer(const FGameplayTag PrevStateId); // 0x288a61c (Index: 0xf, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void UpdateStateEvent(float& const DeltaTime); // 0x288a61c (Index: 0x12, Flags: Event|Protected|BlueprintEvent)
    virtual void UpdateStateEventClient(float& const DeltaTime); // 0x288a61c (Index: 0x13, Flags: Event|Protected|BlueprintEvent)
    virtual void UpdateStateEventServer(float& const DeltaTime); // 0x288a61c (Index: 0x14, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGameplayState) == 0x78, "Size mismatch for UGameplayState");
static_assert(offsetof(UGameplayState, StateId) == 0x28, "Offset mismatch for UGameplayState::StateId");
static_assert(offsetof(UGameplayState, StateRuntimeTags) == 0x30, "Offset mismatch for UGameplayState::StateRuntimeTags");
static_assert(offsetof(UGameplayState, bEvaluateTransition) == 0x50, "Offset mismatch for UGameplayState::bEvaluateTransition");
static_assert(offsetof(UGameplayState, bReplicates) == 0x51, "Offset mismatch for UGameplayState::bReplicates");
static_assert(offsetof(UGameplayState, bStateBegun) == 0x52, "Offset mismatch for UGameplayState::bStateBegun");
static_assert(offsetof(UGameplayState, bStateEnded) == 0x53, "Offset mismatch for UGameplayState::bStateEnded");
static_assert(offsetof(UGameplayState, InitializationServerTime) == 0x54, "Offset mismatch for UGameplayState::InitializationServerTime");
static_assert(offsetof(UGameplayState, BeginStateDelay) == 0x58, "Offset mismatch for UGameplayState::BeginStateDelay");
static_assert(offsetof(UGameplayState, CachedGameplayStateMachine) == 0x60, "Offset mismatch for UGameplayState::CachedGameplayStateMachine");
static_assert(offsetof(UGameplayState, CachedStateMachineManager) == 0x68, "Offset mismatch for UGameplayState::CachedStateMachineManager");
static_assert(offsetof(UGameplayState, Hack_StateToDelayProcess) == 0x70, "Offset mismatch for UGameplayState::Hack_StateToDelayProcess");

// Size: 0xc8 (Inherited: 0xa0, Single: 0x28)
class UGameplayStateMachine : public UGameplayState
{
public:
    uint8_t Pad_78[0x18]; // 0x78 (Size: 0x18, Type: PaddingProperty)
    FGameplayTag StateMachineId; // 0x90 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
    FActiveGameplayStateData ActiveGameplayStateData; // 0x98 (Size: 0x18, Type: StructProperty)
    TArray<FGameplayStateSettings> GameplayStateSettings; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    FGameplayTag InitialGameplayStateId; // 0xc0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c4[0x4]; // 0xc4 (Size: 0x4, Type: PaddingProperty)

public:
    FGameplayTag GetActiveStateId() const; // 0x10abbfc4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UGameplayState* GetActiveStateObject() const; // 0x5a5d724 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetStateMachineId() const; // 0x5478fc4 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetState(const FGameplayTag InStateId, float& InBeginStateDelay); // 0x10abc29c (Index: 0x5, Flags: Native|Public|HasOutParms|BlueprintCallable)

private:
    void OnRep_ActiveGameplayStateData(); // 0x10abc1a0 (Index: 0x4, Flags: Final|Native|Private)

protected:
    virtual void EvaluateStateTransition(); // 0xa39cba8 (Index: 0x0, Flags: Native|Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGameplayStateMachine) == 0xc8, "Size mismatch for UGameplayStateMachine");
static_assert(offsetof(UGameplayStateMachine, StateMachineId) == 0x90, "Offset mismatch for UGameplayStateMachine::StateMachineId");
static_assert(offsetof(UGameplayStateMachine, ActiveGameplayStateData) == 0x98, "Offset mismatch for UGameplayStateMachine::ActiveGameplayStateData");
static_assert(offsetof(UGameplayStateMachine, GameplayStateSettings) == 0xb0, "Offset mismatch for UGameplayStateMachine::GameplayStateSettings");
static_assert(offsetof(UGameplayStateMachine, InitialGameplayStateId) == 0xc0, "Offset mismatch for UGameplayStateMachine::InitialGameplayStateId");

// Size: 0x1d8 (Inherited: 0xe0, Single: 0xf8)
class UGameplayStateMachineManager : public UActorComponent
{
public:
    FGameplayStateMachineArray StateMachineList; // 0xb8 (Size: 0x120, Type: StructProperty)
};

static_assert(sizeof(UGameplayStateMachineManager) == 0x1d8, "Size mismatch for UGameplayStateMachineManager");
static_assert(offsetof(UGameplayStateMachineManager, StateMachineList) == 0xb8, "Offset mismatch for UGameplayStateMachineManager::StateMachineList");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameplayStateTransition
{
    FGameplayTagContainer TransitionConditionTags; // 0x0 (Size: 0x20, Type: StructProperty)
    FGameplayTag TransitionStateTag; // 0x20 (Size: 0x4, Type: StructProperty)
    float BeginStateDelay; // 0x24 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGameplayStateTransition) == 0x28, "Size mismatch for FGameplayStateTransition");
static_assert(offsetof(FGameplayStateTransition, TransitionConditionTags) == 0x0, "Offset mismatch for FGameplayStateTransition::TransitionConditionTags");
static_assert(offsetof(FGameplayStateTransition, TransitionStateTag) == 0x20, "Offset mismatch for FGameplayStateTransition::TransitionStateTag");
static_assert(offsetof(FGameplayStateTransition, BeginStateDelay) == 0x24, "Offset mismatch for FGameplayStateTransition::BeginStateDelay");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGameplayStateSettings
{
    UClass* StateClass; // 0x0 (Size: 0x8, Type: ClassProperty)
    FGameplayTag StateId; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    TArray<FGameplayStateTransition> StateTransitions; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayStateSettings) == 0x20, "Size mismatch for FGameplayStateSettings");
static_assert(offsetof(FGameplayStateSettings, StateClass) == 0x0, "Offset mismatch for FGameplayStateSettings::StateClass");
static_assert(offsetof(FGameplayStateSettings, StateId) == 0x8, "Offset mismatch for FGameplayStateSettings::StateId");
static_assert(offsetof(FGameplayStateSettings, StateTransitions) == 0x10, "Offset mismatch for FGameplayStateSettings::StateTransitions");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FActiveGameplayStateData
{
    UGameplayState* GameplayState; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag PreviousStateId; // 0x8 (Size: 0x4, Type: StructProperty)
    float BeginStateDelay; // 0xc (Size: 0x4, Type: FloatProperty)
    float InitializationTime; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FActiveGameplayStateData) == 0x18, "Size mismatch for FActiveGameplayStateData");
static_assert(offsetof(FActiveGameplayStateData, GameplayState) == 0x0, "Offset mismatch for FActiveGameplayStateData::GameplayState");
static_assert(offsetof(FActiveGameplayStateData, PreviousStateId) == 0x8, "Offset mismatch for FActiveGameplayStateData::PreviousStateId");
static_assert(offsetof(FActiveGameplayStateData, BeginStateDelay) == 0xc, "Offset mismatch for FActiveGameplayStateData::BeginStateDelay");
static_assert(offsetof(FActiveGameplayStateData, InitializationTime) == 0x10, "Offset mismatch for FActiveGameplayStateData::InitializationTime");

// Size: 0x20 (Inherited: 0xc, Single: 0x14)
struct FGameplayStateMachineItem : FFastArraySerializerItem
{
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    UGameplayStateMachine* StateMachine; // 0x10 (Size: 0x8, Type: ObjectProperty)
    float BeginStateDelay; // 0x18 (Size: 0x4, Type: FloatProperty)
    float InitializationTime; // 0x1c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FGameplayStateMachineItem) == 0x20, "Size mismatch for FGameplayStateMachineItem");
static_assert(offsetof(FGameplayStateMachineItem, StateMachine) == 0x10, "Offset mismatch for FGameplayStateMachineItem::StateMachine");
static_assert(offsetof(FGameplayStateMachineItem, BeginStateDelay) == 0x18, "Offset mismatch for FGameplayStateMachineItem::BeginStateDelay");
static_assert(offsetof(FGameplayStateMachineItem, InitializationTime) == 0x1c, "Offset mismatch for FGameplayStateMachineItem::InitializationTime");

// Size: 0x120 (Inherited: 0x108, Single: 0x18)
struct FGameplayStateMachineArray : FFastArraySerializer
{
    UGameplayStateMachineManager* StateMachineManager; // 0x108 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayStateMachineItem> StateMachineItems; // 0x110 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayStateMachineArray) == 0x120, "Size mismatch for FGameplayStateMachineArray");
static_assert(offsetof(FGameplayStateMachineArray, StateMachineManager) == 0x108, "Offset mismatch for FGameplayStateMachineArray::StateMachineManager");
static_assert(offsetof(FGameplayStateMachineArray, StateMachineItems) == 0x110, "Offset mismatch for FGameplayStateMachineArray::StateMachineItems");

