/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaOptions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x110 (Inherited: 0x0, Single: 0x110)
struct FEpicMediaOptions
{
    int32_t FrameRate; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t MaxResolutionForMediaStreaming; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t MaxElectraVerticalResolutionOf60fpsVideos; // 0xc (Size: 0x4, Type: IntProperty)
    int32_t MaxElectraVerticalResolutionOfWindowsSWD; // 0x10 (Size: 0x4, Type: IntProperty)
    bool bElectraLiveUseConservativePresentationOffset; // 0x14 (Size: 0x1, Type: BoolProperty)
    bool bElectraUseDedicatedMediaSegmentDownloadThreads; // 0x15 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_16[0x2]; // 0x16 (Size: 0x2, Type: PaddingProperty)
    double ElectraLivePresentationOffset; // 0x18 (Size: 0x8, Type: DoubleProperty)
    double ElectraLiveAudioPresentationOffset; // 0x20 (Size: 0x8, Type: DoubleProperty)
    bool bDisableBlastURLStreamSource; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bIsCN; // 0x29 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a[0x6]; // 0x2a (Size: 0x6, Type: PaddingProperty)
    TArray<FString> VideoEVMap; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<float> CDNDistribution; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> VODHostNames; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> VODHostNamesCN; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> LiveHostNames; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> LiveHostNamesCN; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> VODHostNamesDev; // 0x90 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> LiveHostNamesDev; // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> VODHostNamesHF; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> LiveHostNamesHF; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> VODHostNamesCNHF; // 0xd0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> LiveHostNamesCNHF; // 0xe0 (Size: 0x10, Type: ArrayProperty)
    bool bUseQuicksilverEntryPoint; // 0xf0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f1[0x17]; // 0xf1 (Size: 0x17, Type: PaddingProperty)
    bool bUseSegmentCaching; // 0x108 (Size: 0x1, Type: BoolProperty)
    bool bForceSegmentCaching; // 0x109 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_10a[0x2]; // 0x10a (Size: 0x2, Type: PaddingProperty)
    float MetadataRequestTimeout; // 0x10c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FEpicMediaOptions) == 0x110, "Size mismatch for FEpicMediaOptions");
static_assert(offsetof(FEpicMediaOptions, FrameRate) == 0x4, "Offset mismatch for FEpicMediaOptions::FrameRate");
static_assert(offsetof(FEpicMediaOptions, MaxResolutionForMediaStreaming) == 0x8, "Offset mismatch for FEpicMediaOptions::MaxResolutionForMediaStreaming");
static_assert(offsetof(FEpicMediaOptions, MaxElectraVerticalResolutionOf60fpsVideos) == 0xc, "Offset mismatch for FEpicMediaOptions::MaxElectraVerticalResolutionOf60fpsVideos");
static_assert(offsetof(FEpicMediaOptions, MaxElectraVerticalResolutionOfWindowsSWD) == 0x10, "Offset mismatch for FEpicMediaOptions::MaxElectraVerticalResolutionOfWindowsSWD");
static_assert(offsetof(FEpicMediaOptions, bElectraLiveUseConservativePresentationOffset) == 0x14, "Offset mismatch for FEpicMediaOptions::bElectraLiveUseConservativePresentationOffset");
static_assert(offsetof(FEpicMediaOptions, bElectraUseDedicatedMediaSegmentDownloadThreads) == 0x15, "Offset mismatch for FEpicMediaOptions::bElectraUseDedicatedMediaSegmentDownloadThreads");
static_assert(offsetof(FEpicMediaOptions, ElectraLivePresentationOffset) == 0x18, "Offset mismatch for FEpicMediaOptions::ElectraLivePresentationOffset");
static_assert(offsetof(FEpicMediaOptions, ElectraLiveAudioPresentationOffset) == 0x20, "Offset mismatch for FEpicMediaOptions::ElectraLiveAudioPresentationOffset");
static_assert(offsetof(FEpicMediaOptions, bDisableBlastURLStreamSource) == 0x28, "Offset mismatch for FEpicMediaOptions::bDisableBlastURLStreamSource");
static_assert(offsetof(FEpicMediaOptions, bIsCN) == 0x29, "Offset mismatch for FEpicMediaOptions::bIsCN");
static_assert(offsetof(FEpicMediaOptions, VideoEVMap) == 0x30, "Offset mismatch for FEpicMediaOptions::VideoEVMap");
static_assert(offsetof(FEpicMediaOptions, CDNDistribution) == 0x40, "Offset mismatch for FEpicMediaOptions::CDNDistribution");
static_assert(offsetof(FEpicMediaOptions, VODHostNames) == 0x50, "Offset mismatch for FEpicMediaOptions::VODHostNames");
static_assert(offsetof(FEpicMediaOptions, VODHostNamesCN) == 0x60, "Offset mismatch for FEpicMediaOptions::VODHostNamesCN");
static_assert(offsetof(FEpicMediaOptions, LiveHostNames) == 0x70, "Offset mismatch for FEpicMediaOptions::LiveHostNames");
static_assert(offsetof(FEpicMediaOptions, LiveHostNamesCN) == 0x80, "Offset mismatch for FEpicMediaOptions::LiveHostNamesCN");
static_assert(offsetof(FEpicMediaOptions, VODHostNamesDev) == 0x90, "Offset mismatch for FEpicMediaOptions::VODHostNamesDev");
static_assert(offsetof(FEpicMediaOptions, LiveHostNamesDev) == 0xa0, "Offset mismatch for FEpicMediaOptions::LiveHostNamesDev");
static_assert(offsetof(FEpicMediaOptions, VODHostNamesHF) == 0xb0, "Offset mismatch for FEpicMediaOptions::VODHostNamesHF");
static_assert(offsetof(FEpicMediaOptions, LiveHostNamesHF) == 0xc0, "Offset mismatch for FEpicMediaOptions::LiveHostNamesHF");
static_assert(offsetof(FEpicMediaOptions, VODHostNamesCNHF) == 0xd0, "Offset mismatch for FEpicMediaOptions::VODHostNamesCNHF");
static_assert(offsetof(FEpicMediaOptions, LiveHostNamesCNHF) == 0xe0, "Offset mismatch for FEpicMediaOptions::LiveHostNamesCNHF");
static_assert(offsetof(FEpicMediaOptions, bUseQuicksilverEntryPoint) == 0xf0, "Offset mismatch for FEpicMediaOptions::bUseQuicksilverEntryPoint");
static_assert(offsetof(FEpicMediaOptions, bUseSegmentCaching) == 0x108, "Offset mismatch for FEpicMediaOptions::bUseSegmentCaching");
static_assert(offsetof(FEpicMediaOptions, bForceSegmentCaching) == 0x109, "Offset mismatch for FEpicMediaOptions::bForceSegmentCaching");
static_assert(offsetof(FEpicMediaOptions, MetadataRequestTimeout) == 0x10c, "Offset mismatch for FEpicMediaOptions::MetadataRequestTimeout");

