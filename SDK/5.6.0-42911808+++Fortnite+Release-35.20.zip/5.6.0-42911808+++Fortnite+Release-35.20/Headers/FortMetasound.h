/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortMetasound
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "GameFeatures.h"
#include "CoreUObject.h"
#include "MetasoundEngine.h"

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UFortMetaSoundCacheDefinition : public UDataAsset
{
public:
    FFortMetaSoundCache Cache; // 0x30 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UFortMetaSoundCacheDefinition) == 0x40, "Size mismatch for UFortMetaSoundCacheDefinition");
static_assert(offsetof(UFortMetaSoundCacheDefinition, Cache) == 0x30, "Offset mismatch for UFortMetaSoundCacheDefinition::Cache");

// Size: 0xa8 (Inherited: 0x88, Single: 0x20)
class UFortGameFeatureAction_PrecacheMetaSounds : public UGameFeatureAction_AudioActionBase
{
public:
    bool bDefineCacheInline; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
    UFortMetaSoundCacheDefinition* CacheDefinition; // 0x40 (Size: 0x8, Type: ObjectProperty)
    FFortMetaSoundCache InlineCacheDefinition; // 0x48 (Size: 0x10, Type: StructProperty)
    TMap<FCachedMetaSoundContainer, uint32_t> CachedMetaSoundsForDevice; // 0x58 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UFortGameFeatureAction_PrecacheMetaSounds) == 0xa8, "Size mismatch for UFortGameFeatureAction_PrecacheMetaSounds");
static_assert(offsetof(UFortGameFeatureAction_PrecacheMetaSounds, bDefineCacheInline) == 0x38, "Offset mismatch for UFortGameFeatureAction_PrecacheMetaSounds::bDefineCacheInline");
static_assert(offsetof(UFortGameFeatureAction_PrecacheMetaSounds, CacheDefinition) == 0x40, "Offset mismatch for UFortGameFeatureAction_PrecacheMetaSounds::CacheDefinition");
static_assert(offsetof(UFortGameFeatureAction_PrecacheMetaSounds, InlineCacheDefinition) == 0x48, "Offset mismatch for UFortGameFeatureAction_PrecacheMetaSounds::InlineCacheDefinition");
static_assert(offsetof(UFortGameFeatureAction_PrecacheMetaSounds, CachedMetaSoundsForDevice) == 0x58, "Offset mismatch for UFortGameFeatureAction_PrecacheMetaSounds::CachedMetaSoundsForDevice");

// Size: 0x230 (Inherited: 0xb8, Single: 0x178)
class UFortMetaSoundInterfaceSubsystem : public UAudioEngineSubsystem
{
public:
};

static_assert(sizeof(UFortMetaSoundInterfaceSubsystem) == 0x230, "Size mismatch for UFortMetaSoundInterfaceSubsystem");

// Size: 0x48 (Inherited: 0x88, Single: 0xffffffc0)
class UGameFeatureAction_AddParameterInterfaceDefinitions : public UGameFeatureAction_AudioActionBase
{
public:
    TArray<FInstancedStruct> Definitions; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGameFeatureAction_AddParameterInterfaceDefinitions) == 0x48, "Size mismatch for UGameFeatureAction_AddParameterInterfaceDefinitions");
static_assert(offsetof(UGameFeatureAction_AddParameterInterfaceDefinitions, Definitions) == 0x38, "Offset mismatch for UGameFeatureAction_AddParameterInterfaceDefinitions::Definitions");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFortMetaSoundCacheEntry
{
    TSoftObjectPtr<UMetaSoundSource*> Metasound; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    int32_t MaxInstancesToCache; // 0x20 (Size: 0x4, Type: IntProperty)
    bool bUseSharedCache; // 0x24 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_25[0x3]; // 0x25 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FFortMetaSoundCacheEntry) == 0x28, "Size mismatch for FFortMetaSoundCacheEntry");
static_assert(offsetof(FFortMetaSoundCacheEntry, Metasound) == 0x0, "Offset mismatch for FFortMetaSoundCacheEntry::Metasound");
static_assert(offsetof(FFortMetaSoundCacheEntry, MaxInstancesToCache) == 0x20, "Offset mismatch for FFortMetaSoundCacheEntry::MaxInstancesToCache");
static_assert(offsetof(FFortMetaSoundCacheEntry, bUseSharedCache) == 0x24, "Offset mismatch for FFortMetaSoundCacheEntry::bUseSharedCache");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortMetaSoundCache
{
    TArray<FFortMetaSoundCacheEntry> CacheEntries; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortMetaSoundCache) == 0x10, "Size mismatch for FFortMetaSoundCache");
static_assert(offsetof(FFortMetaSoundCache, CacheEntries) == 0x0, "Offset mismatch for FFortMetaSoundCache::CacheEntries");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCachedMetaSoundContainer
{
    TArray<UMetaSoundSource*> CachedMetaSounds; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCachedMetaSoundContainer) == 0x10, "Size mismatch for FCachedMetaSoundContainer");
static_assert(offsetof(FCachedMetaSoundContainer, CachedMetaSounds) == 0x0, "Offset mismatch for FCachedMetaSoundContainer::CachedMetaSounds");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRecentPlayTimes
{
    TArray<float> RecentPlayTimes; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRecentPlayTimes) == 0x10, "Size mismatch for FRecentPlayTimes");
static_assert(offsetof(FRecentPlayTimes, RecentPlayTimes) == 0x0, "Offset mismatch for FRecentPlayTimes::RecentPlayTimes");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FParameterInterfaceContext
{
};

static_assert(sizeof(FParameterInterfaceContext) == 0x1, "Size mismatch for FParameterInterfaceContext");

// Size: 0x8 (Inherited: 0x1, Single: 0x7)
struct FParameterInterfaceContext_ActiveSound : FParameterInterfaceContext
{
};

static_assert(sizeof(FParameterInterfaceContext_ActiveSound) == 0x8, "Size mismatch for FParameterInterfaceContext_ActiveSound");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FParameterInterfaceDefinition
{
};

static_assert(sizeof(FParameterInterfaceDefinition) == 0x8, "Size mismatch for FParameterInterfaceDefinition");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FParameterInterfaceDefinition_ActiveSound : FParameterInterfaceDefinition
{
};

static_assert(sizeof(FParameterInterfaceDefinition_ActiveSound) == 0x8, "Size mismatch for FParameterInterfaceDefinition_ActiveSound");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FParameterInterfaceDefinition_ActiveSound_Movement : FParameterInterfaceDefinition
{
};

static_assert(sizeof(FParameterInterfaceDefinition_ActiveSound_Movement) == 0x8, "Size mismatch for FParameterInterfaceDefinition_ActiveSound_Movement");

// Size: 0x10 (Inherited: 0x9, Single: 0x7)
struct FParameterInterfaceContext_ActiveSound_RecentCollection : FParameterInterfaceContext_ActiveSound
{
};

static_assert(sizeof(FParameterInterfaceContext_ActiveSound_RecentCollection) == 0x10, "Size mismatch for FParameterInterfaceContext_ActiveSound_RecentCollection");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FParameterInterfaceDefinition_ActiveSound_RecentCollection : FParameterInterfaceDefinition
{
};

static_assert(sizeof(FParameterInterfaceDefinition_ActiveSound_RecentCollection) == 0x8, "Size mismatch for FParameterInterfaceDefinition_ActiveSound_RecentCollection");

// Size: 0x10 (Inherited: 0x9, Single: 0x7)
struct FParameterInterfaceContext_ActiveSound_Time : FParameterInterfaceContext_ActiveSound
{
};

static_assert(sizeof(FParameterInterfaceContext_ActiveSound_Time) == 0x10, "Size mismatch for FParameterInterfaceContext_ActiveSound_Time");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FParameterInterfaceDefinition_ActiveSound_Time : FParameterInterfaceDefinition
{
};

static_assert(sizeof(FParameterInterfaceDefinition_ActiveSound_Time) == 0x8, "Size mismatch for FParameterInterfaceDefinition_ActiveSound_Time");

