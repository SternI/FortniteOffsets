/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FriedRiceNativeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0x6e0 (Inherited: 0x1240, Single: 0xfffff4a0)
class AFriedRiceRootPlayspace : public AFortPlayspace
{
public:
};

static_assert(sizeof(AFriedRiceRootPlayspace) == 0x6e0, "Size mismatch for AFriedRiceRootPlayspace");

