/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticsFrameworkFlowgraph
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UOrderedOperation : public UObject
{
public:
};

static_assert(sizeof(UOrderedOperation) == 0x28, "Size mismatch for UOrderedOperation");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FCosmeticFlowData
{
    TMap<FInstancedStruct, FName> NamedData; // 0x0 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FCosmeticFlowData) == 0x50, "Size mismatch for FCosmeticFlowData");
static_assert(offsetof(FCosmeticFlowData, NamedData) == 0x0, "Offset mismatch for FCosmeticFlowData::NamedData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FOperationSequenceHandle
{
};

static_assert(sizeof(FOperationSequenceHandle) == 0x10, "Size mismatch for FOperationSequenceHandle");

