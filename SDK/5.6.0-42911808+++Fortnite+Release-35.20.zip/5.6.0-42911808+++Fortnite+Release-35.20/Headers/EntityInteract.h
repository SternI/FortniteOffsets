/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EntityInteract
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "FortniteGame.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEntityInteractLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static AActor* EntityInteractGetActor(UObject*& const WorldContextObject, const FHitResult HitResult); // 0x113dd85c (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms)
};

static_assert(sizeof(UEntityInteractLibrary) == 0x28, "Size mismatch for UEntityInteractLibrary");

// Size: 0x410 (Inherited: 0x2d0, Single: 0x140)
class AEntityInteractProxyActor : public AActor
{
public:
    uint8_t Pad_2a8[0x50]; // 0x2a8 (Size: 0x50, Type: PaddingProperty)
    FText InteractText; // 0x2f8 (Size: 0x10, Type: TextProperty)
    FText CannotInteractText; // 0x308 (Size: 0x10, Type: TextProperty)
    FTimerHandle CoolDownTimerHandle; // 0x318 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_320[0x18]; // 0x320 (Size: 0x18, Type: PaddingProperty)
    TMap<UFortControllerComponent_Interaction*, AController*> PerControllerOverriddenInteractDurationPlayerComponents; // 0x338 (Size: 0x50, Type: MapProperty)
    TMap<UFortControllerComponent_Interaction*, AController*> PerControllerCooldownTimerHandlePlayerComponents; // 0x388 (Size: 0x50, Type: MapProperty)
    TArray<AController*> InteractingControllers; // 0x3d8 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UObject*> CachedInteractComponent; // 0x3e8 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_3f0[0x10]; // 0x3f0 (Size: 0x10, Type: PaddingProperty)
    float ForwardInteractOffset; // 0x400 (Size: 0x4, Type: FloatProperty)
    float RightInteractOffset; // 0x404 (Size: 0x4, Type: FloatProperty)
    bool bInteractEnabled; // 0x408 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_409[0x7]; // 0x409 (Size: 0x7, Type: PaddingProperty)

public:
    void OnFortMinigameCreated(AFortMinigame*& NewMinigame); // 0x113dda38 (Index: 0x1, Flags: Final|Native|Public)
    void OnMinigameStateChanged(AFortMinigame*& InMinigame, EFortMinigameState& NewMinigameState); // 0x113ddb64 (Index: 0x2, Flags: Final|Native|Public)

private:
    virtual void NetMultiCastBeginCooldownTimer(float& const CooldownTime); // 0x9e7e174 (Index: 0x0, Flags: Final|Net|NetReliableNative|Event|NetMulticast|Private)

protected:
    void OnRep_CachedInteractComponent(); // 0x113ddd80 (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(AEntityInteractProxyActor) == 0x410, "Size mismatch for AEntityInteractProxyActor");
static_assert(offsetof(AEntityInteractProxyActor, InteractText) == 0x2f8, "Offset mismatch for AEntityInteractProxyActor::InteractText");
static_assert(offsetof(AEntityInteractProxyActor, CannotInteractText) == 0x308, "Offset mismatch for AEntityInteractProxyActor::CannotInteractText");
static_assert(offsetof(AEntityInteractProxyActor, CoolDownTimerHandle) == 0x318, "Offset mismatch for AEntityInteractProxyActor::CoolDownTimerHandle");
static_assert(offsetof(AEntityInteractProxyActor, PerControllerOverriddenInteractDurationPlayerComponents) == 0x338, "Offset mismatch for AEntityInteractProxyActor::PerControllerOverriddenInteractDurationPlayerComponents");
static_assert(offsetof(AEntityInteractProxyActor, PerControllerCooldownTimerHandlePlayerComponents) == 0x388, "Offset mismatch for AEntityInteractProxyActor::PerControllerCooldownTimerHandlePlayerComponents");
static_assert(offsetof(AEntityInteractProxyActor, InteractingControllers) == 0x3d8, "Offset mismatch for AEntityInteractProxyActor::InteractingControllers");
static_assert(offsetof(AEntityInteractProxyActor, CachedInteractComponent) == 0x3e8, "Offset mismatch for AEntityInteractProxyActor::CachedInteractComponent");
static_assert(offsetof(AEntityInteractProxyActor, ForwardInteractOffset) == 0x400, "Offset mismatch for AEntityInteractProxyActor::ForwardInteractOffset");
static_assert(offsetof(AEntityInteractProxyActor, RightInteractOffset) == 0x404, "Offset mismatch for AEntityInteractProxyActor::RightInteractOffset");
static_assert(offsetof(AEntityInteractProxyActor, bInteractEnabled) == 0x408, "Offset mismatch for AEntityInteractProxyActor::bInteractEnabled");

// Size: 0x360 (Inherited: 0xbc0, Single: 0xfffff7a0)
class AFortAthenaMutator_EntityInteract : public AFortAthenaMutator
{
public:
};

static_assert(sizeof(AFortAthenaMutator_EntityInteract) == 0x360, "Size mismatch for AFortAthenaMutator_EntityInteract");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FInteractComponentBackup
{
};

static_assert(sizeof(FInteractComponentBackup) == 0x30, "Size mismatch for FInteractComponentBackup");

