/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ContextualInteractions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "ModularGameplay.h"
#include "PlayspaceSystem.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UContextualInteractionHandler : public UInterface
{
public:
};

static_assert(sizeof(UContextualInteractionHandler) == 0x28, "Size mismatch for UContextualInteractionHandler");

// Size: 0x110 (Inherited: 0xe0, Single: 0x30)
class UContextualInteractionsComponent : public UActorComponent
{
public:
    UCapsuleComponent* QuickJoinInteractCollisionComponent; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c0[0x50]; // 0xc0 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UContextualInteractionsComponent) == 0x110, "Size mismatch for UContextualInteractionsComponent");
static_assert(offsetof(UContextualInteractionsComponent, QuickJoinInteractCollisionComponent) == 0xb8, "Offset mismatch for UContextualInteractionsComponent::QuickJoinInteractCollisionComponent");

// Size: 0x110 (Inherited: 0x250, Single: 0xfffffec0)
class UControllerComponent_ContextualInteractionsManager : public UControllerComponent
{
public:
    uint8_t Pad_b8[0x10]; // 0xb8 (Size: 0x10, Type: PaddingProperty)
    float TraceDistance; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float DesiredRadius; // 0xcc (Size: 0x4, Type: FloatProperty)
    float FullUpdateFrequencyInSeconds; // 0xd0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_d4[0x3c]; // 0xd4 (Size: 0x3c, Type: PaddingProperty)

private:
    void UpdateNextTick(); // 0x1143eca4 (Index: 0x0, Flags: Final|Native|Private|BlueprintCallable)
};

static_assert(sizeof(UControllerComponent_ContextualInteractionsManager) == 0x110, "Size mismatch for UControllerComponent_ContextualInteractionsManager");
static_assert(offsetof(UControllerComponent_ContextualInteractionsManager, TraceDistance) == 0xc8, "Offset mismatch for UControllerComponent_ContextualInteractionsManager::TraceDistance");
static_assert(offsetof(UControllerComponent_ContextualInteractionsManager, DesiredRadius) == 0xcc, "Offset mismatch for UControllerComponent_ContextualInteractionsManager::DesiredRadius");
static_assert(offsetof(UControllerComponent_ContextualInteractionsManager, FullUpdateFrequencyInSeconds) == 0xd0, "Offset mismatch for UControllerComponent_ContextualInteractionsManager::FullUpdateFrequencyInSeconds");

// Size: 0x118 (Inherited: 0x1f0, Single: 0xffffff28)
class UInteractableComponent_ContextualInteractionViaAim : public UContextualInteractionsComponent
{
public:
};

static_assert(sizeof(UInteractableComponent_ContextualInteractionViaAim) == 0x118, "Size mismatch for UInteractableComponent_ContextualInteractionViaAim");

// Size: 0xc0 (Inherited: 0xe0, Single: 0xffffffe0)
class UInteractableComponent_FocusedViaAim : public UActorComponent
{
public:
};

static_assert(sizeof(UInteractableComponent_FocusedViaAim) == 0xc0, "Size mismatch for UInteractableComponent_FocusedViaAim");

// Size: 0xc0 (Inherited: 0xe0, Single: 0xffffffe0)
class UInteractableComponent_FocusedViaOverlap : public UActorComponent
{
public:

private:
    void OnInteractionPrimitiveBeganOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult SweepResult); // 0x1143e38c (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
    void OnInteractionPrimitiveEndedOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex); // 0x1143e8ec (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UInteractableComponent_FocusedViaOverlap) == 0xc0, "Size mismatch for UInteractableComponent_FocusedViaOverlap");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UPlayerFocusable : public UInterface
{
public:
};

static_assert(sizeof(UPlayerFocusable) == 0x28, "Size mismatch for UPlayerFocusable");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UHandlesPlayerFocusable : public UInterface
{
public:
};

static_assert(sizeof(UHandlesPlayerFocusable) == 0x28, "Size mismatch for UHandlesPlayerFocusable");

// Size: 0xd8 (Inherited: 0x250, Single: 0xfffffe88)
class UPlayspaceComponent_ContextualInteractionsBridge : public UPlayspaceComponent
{
public:
};

static_assert(sizeof(UPlayspaceComponent_ContextualInteractionsBridge) == 0xd8, "Size mismatch for UPlayspaceComponent_ContextualInteractionsBridge");

