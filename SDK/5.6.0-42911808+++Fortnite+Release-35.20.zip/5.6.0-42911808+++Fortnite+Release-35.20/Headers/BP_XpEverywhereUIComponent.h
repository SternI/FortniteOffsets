/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_XpEverywhereUIComponent
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "XpEverywhereUI.h"

// Size: 0x190 (Inherited: 0x270, Single: 0xffffff20)
class UBP_XpEverywhereUIComponent_C : public UXpEverywhereUIComponent
{
public:
};

static_assert(sizeof(UBP_XpEverywhereUIComponent_C) == 0x190, "Size mismatch for UBP_XpEverywhereUIComponent_C");

