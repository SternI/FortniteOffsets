/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EmporiumRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x3c8 (Inherited: 0x28, Single: 0x3a0)
class UEmporiumAssetsPaths : public UObject
{
public:
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Opaque; // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Opaque_Clearcoat; // 0x48 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Opaque_Sheen; // 0x68 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Opaque_Unlit; // 0x88 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Translucent; // 0xa8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Translucent_Clearcoat; // 0xc8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Transmission; // 0xe8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Opaque_TS; // 0x108 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Opaque_Clearcoat_TS; // 0x128 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Opaque_Sheen_TS; // 0x148 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Opaque_Unlit_TS; // 0x168 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Translucent_TS; // 0x188 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Translucent_Clearcoat_TS; // 0x1a8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Transmission_TS; // 0x1c8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Opaque; // 0x1e8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Opaque_Clearcoat; // 0x208 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Opaque_Sheen; // 0x228 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Translucent; // 0x248 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Translucent_Clearcoat; // 0x268 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Transmission; // 0x288 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Opaque_TS; // 0x2a8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Opaque_Clearcoat_TS; // 0x2c8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Opaque_Sheen_TS; // 0x2e8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Translucent_TS; // 0x308 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Translucent_Clearcoat_TS; // 0x328 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Transmission_TS; // 0x348 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> SG_MI_Foliage_TS; // 0x368 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterialInstanceConstant*> MR_MI_Foliage_TS; // 0x388 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UStaticMesh*> PlaceholderSphere; // 0x3a8 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(UEmporiumAssetsPaths) == 0x3c8, "Size mismatch for UEmporiumAssetsPaths");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Opaque) == 0x28, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Opaque");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Opaque_Clearcoat) == 0x48, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Opaque_Clearcoat");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Opaque_Sheen) == 0x68, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Opaque_Sheen");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Opaque_Unlit) == 0x88, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Opaque_Unlit");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Translucent) == 0xa8, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Translucent");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Translucent_Clearcoat) == 0xc8, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Translucent_Clearcoat");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Transmission) == 0xe8, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Transmission");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Opaque_TS) == 0x108, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Opaque_TS");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Opaque_Clearcoat_TS) == 0x128, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Opaque_Clearcoat_TS");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Opaque_Sheen_TS) == 0x148, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Opaque_Sheen_TS");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Opaque_Unlit_TS) == 0x168, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Opaque_Unlit_TS");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Translucent_TS) == 0x188, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Translucent_TS");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Translucent_Clearcoat_TS) == 0x1a8, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Translucent_Clearcoat_TS");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Transmission_TS) == 0x1c8, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Transmission_TS");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Opaque) == 0x1e8, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Opaque");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Opaque_Clearcoat) == 0x208, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Opaque_Clearcoat");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Opaque_Sheen) == 0x228, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Opaque_Sheen");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Translucent) == 0x248, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Translucent");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Translucent_Clearcoat) == 0x268, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Translucent_Clearcoat");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Transmission) == 0x288, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Transmission");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Opaque_TS) == 0x2a8, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Opaque_TS");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Opaque_Clearcoat_TS) == 0x2c8, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Opaque_Clearcoat_TS");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Opaque_Sheen_TS) == 0x2e8, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Opaque_Sheen_TS");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Translucent_TS) == 0x308, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Translucent_TS");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Translucent_Clearcoat_TS) == 0x328, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Translucent_Clearcoat_TS");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Transmission_TS) == 0x348, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Transmission_TS");
static_assert(offsetof(UEmporiumAssetsPaths, SG_MI_Foliage_TS) == 0x368, "Offset mismatch for UEmporiumAssetsPaths::SG_MI_Foliage_TS");
static_assert(offsetof(UEmporiumAssetsPaths, MR_MI_Foliage_TS) == 0x388, "Offset mismatch for UEmporiumAssetsPaths::MR_MI_Foliage_TS");
static_assert(offsetof(UEmporiumAssetsPaths, PlaceholderSphere) == 0x3a8, "Offset mismatch for UEmporiumAssetsPaths::PlaceholderSphere");

