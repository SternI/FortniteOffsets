/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DianaReadyUpErrors
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0x38 (Inherited: 0xb8, Single: 0xffffff80)
class UDianaPlayerWarning : public UFortLocalPlayerSubsystem
{
public:
};

static_assert(sizeof(UDianaPlayerWarning) == 0x38, "Size mismatch for UDianaPlayerWarning");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UDianaReadyUpErrorsExtension : public UReadyUpErrorsExtension
{
public:
};

static_assert(sizeof(UDianaReadyUpErrorsExtension) == 0x30, "Size mismatch for UDianaReadyUpErrorsExtension");

