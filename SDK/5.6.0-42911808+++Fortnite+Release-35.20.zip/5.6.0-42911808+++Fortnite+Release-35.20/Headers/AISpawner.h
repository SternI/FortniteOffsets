/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AISpawner
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameFeatures.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0x58 (Inherited: 0x50, Single: 0x8)
class UFortGameFeatureAction_AddSpawnerDeviceBindingTrack : public UGameFeatureAction
{
public:
    FSoftClassPath SpawnerDeviceClassPath; // 0x28 (Size: 0x18, Type: StructProperty)
    FSoftClassPath BindingTrackClassPath; // 0x40 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UFortGameFeatureAction_AddSpawnerDeviceBindingTrack) == 0x58, "Size mismatch for UFortGameFeatureAction_AddSpawnerDeviceBindingTrack");
static_assert(offsetof(UFortGameFeatureAction_AddSpawnerDeviceBindingTrack, SpawnerDeviceClassPath) == 0x28, "Offset mismatch for UFortGameFeatureAction_AddSpawnerDeviceBindingTrack::SpawnerDeviceClassPath");
static_assert(offsetof(UFortGameFeatureAction_AddSpawnerDeviceBindingTrack, BindingTrackClassPath) == 0x40, "Offset mismatch for UFortGameFeatureAction_AddSpawnerDeviceBindingTrack::BindingTrackClassPath");

// Size: 0x2a0 (Inherited: 0x5b0, Single: 0xfffffcf0)
class UAISpawnerPreviewerComponent : public UChildActorComponent
{
public:
    UClass* PlayerMannequinClass; // 0x290 (Size: 0x8, Type: ClassProperty)
    UClass* DefaultCustomAnimationBPClass; // 0x298 (Size: 0x8, Type: ClassProperty)

protected:
    void ClearActorPreview(); // 0x11a608d8 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void ClearCIDPreview(); // 0x11a608d8 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    void SetActorForPreview(UClass*& const InActorClass, TArray<UCustomCharacterPart*>& const OptionalCharacterParts); // 0x11a608ec (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
    void SetCIDForPreview(UAthenaCharacterItemDefinition*& InCID); // 0x11a61150 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UAISpawnerPreviewerComponent) == 0x2a0, "Size mismatch for UAISpawnerPreviewerComponent");
static_assert(offsetof(UAISpawnerPreviewerComponent, PlayerMannequinClass) == 0x290, "Offset mismatch for UAISpawnerPreviewerComponent::PlayerMannequinClass");
static_assert(offsetof(UAISpawnerPreviewerComponent, DefaultCustomAnimationBPClass) == 0x298, "Offset mismatch for UAISpawnerPreviewerComponent::DefaultCustomAnimationBPClass");

// Size: 0x4b8 (Inherited: 0x1070, Single: 0xfffff448)
class AFortAthenaMutator_AISpawner : public AFortAthenaMutator_GameModeBase
{
public:
};

static_assert(sizeof(AFortAthenaMutator_AISpawner) == 0x4b8, "Size mismatch for AFortAthenaMutator_AISpawner");

