/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNE_UILibrary
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUI.h"
#include "UMG.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x14b0 (Inherited: 0x1bd0, Single: 0xfffff8e0)
class UFNE_ModularButton : public UCommonButtonBase
{
public:
    TArray<UFNE_UIBlock*> ModularBlocks; // 0x14a0 (Size: 0x10, Type: ArrayProperty)

public:
    void RegisterModularBlock(UFNE_UIBlock*& bLock); // 0x11ee2b8c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void RequestInstantTransitionOnBlocks(EFNE_UIBlockInstantTransitionState& State); // 0x11ee3168 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void RequestTransitionOnBlocks(EFNE_UIBlockVisualState& State); // 0x11ee33c0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void SetBlocksTiming(const FFNE_UIBlockTiming Timing); // 0x11ee35e4 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void UnregisterAllModularBlocks(); // 0x11ee38a0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void UnregisterModularBlock(UFNE_UIBlock*& bLock); // 0x11ee38b4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFNE_ModularButton) == 0x14b0, "Size mismatch for UFNE_ModularButton");
static_assert(offsetof(UFNE_ModularButton, ModularBlocks) == 0x14a0, "Offset mismatch for UFNE_ModularButton::ModularBlocks");

// Size: 0x2f0 (Inherited: 0x458, Single: 0xfffffe98)
class UFNE_UIBlock : public UUserWidget
{
public:
    uint8_t ViewportResizedEvent[0x10]; // 0x2b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FFNE_UIBlockTiming TransitionTiming; // 0x2c0 (Size: 0x2c, Type: StructProperty)
    uint8_t Pad_2ec[0x4]; // 0x2ec (Size: 0x4, Type: PaddingProperty)

public:
    float GetTransitionTime(EFNE_UIBlockVisualState& State); // 0x11ee2844 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    void PlayTransition(UWidgetAnimation*& Animation, bool& const bPlayForward); // 0x11ee2980 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)
    void RequestInstantTransition(EFNE_UIBlockInstantTransitionState& State); // 0x11ee303c (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)
    void RequestTransition(EFNE_UIBlockVisualState& State); // 0x11ee3294 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)
    void SetBlockTiming(const FFNE_UIBlockTiming Timing); // 0x11ee34ec (Index: 0x15, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void ViewportResizedEvent_Blueprint__DelegateSignature(); // 0x288a61c (Index: 0x16, Flags: MulticastDelegate|Public|Delegate)

protected:
    virtual void OnInstantTransitionToDeselected(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void OnInstantTransitionToDisabled(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void OnInstantTransitionToEnabled(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnInstantTransitionToLocked(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void OnInstantTransitionToSelected(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void OnInstantTransitionToUnlocked(); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionDeselectedFocusedRequested(); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionDeselectedIdleRequested(); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionDisabledRequested(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionEnabledRequested(); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionFocusedRequested(); // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionHoveredRequested(); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionPressedRequested(); // 0x288a61c (Index: 0xd, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionReleasedRequested(); // 0x288a61c (Index: 0xe, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionSelectedRequested(); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionUnfocusedRequested(); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTransitionUnhoveredRequested(); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFNE_UIBlock) == 0x2f0, "Size mismatch for UFNE_UIBlock");
static_assert(offsetof(UFNE_UIBlock, ViewportResizedEvent) == 0x2b0, "Offset mismatch for UFNE_UIBlock::ViewportResizedEvent");
static_assert(offsetof(UFNE_UIBlock, TransitionTiming) == 0x2c0, "Offset mismatch for UFNE_UIBlock::TransitionTiming");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFNE_UIBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void PlayAnimationDuringTime(UUserWidget*& Widget, UWidgetAnimation*& Animation, float& const PlayTime, bool& const bPlayForward); // 0xf1cbf50 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UFNE_UIBlueprintFunctionLibrary) == 0x28, "Size mismatch for UFNE_UIBlueprintFunctionLibrary");

// Size: 0x14d0 (Inherited: 0x3080, Single: 0xffffe450)
class UFNE_CTAButton : public UFNE_ModularButton
{
public:
    FText Text; // 0x14b0 (Size: 0x10, Type: TextProperty)
    FText SecondaryText; // 0x14c0 (Size: 0x10, Type: TextProperty)

public:
    void SetSecondaryText(const FText ButtonSecondaryText); // 0x11ee36b8 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetText(const FText ButtonText); // 0x11ee37ac (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

protected:
    virtual void BP_SetSecondaryText(const FText ButtonSecondaryText); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void BP_SetText(const FText ButtonText); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFNE_CTAButton) == 0x14d0, "Size mismatch for UFNE_CTAButton");
static_assert(offsetof(UFNE_CTAButton, Text) == 0x14b0, "Offset mismatch for UFNE_CTAButton::Text");
static_assert(offsetof(UFNE_CTAButton, SecondaryText) == 0x14c0, "Offset mismatch for UFNE_CTAButton::SecondaryText");

// Size: 0x14d0 (Inherited: 0x3080, Single: 0xffffe450)
class UFNE_StylableButton : public UFNE_ModularButton
{
public:
    FText Text; // 0x14b0 (Size: 0x10, Type: TextProperty)
    FText SecondaryText; // 0x14c0 (Size: 0x10, Type: TextProperty)

protected:
    virtual void BP_SetSecondaryText(const FText ButtonSecondaryText); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void BP_SetText(const FText ButtonText); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFNE_StylableButton) == 0x14d0, "Size mismatch for UFNE_StylableButton");
static_assert(offsetof(UFNE_StylableButton, Text) == 0x14b0, "Offset mismatch for UFNE_StylableButton::Text");
static_assert(offsetof(UFNE_StylableButton, SecondaryText) == 0x14c0, "Offset mismatch for UFNE_StylableButton::SecondaryText");

// Size: 0x2c (Inherited: 0x0, Single: 0x2c)
struct FFNE_UIBlockTiming
{
    float Hovering; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Unhovering; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Focusing; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Unfocusing; // 0xc (Size: 0x4, Type: FloatProperty)
    float Pressing; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Releasing; // 0x14 (Size: 0x4, Type: FloatProperty)
    float Disabling; // 0x18 (Size: 0x4, Type: FloatProperty)
    float Enabling; // 0x1c (Size: 0x4, Type: FloatProperty)
    float Selecting; // 0x20 (Size: 0x4, Type: FloatProperty)
    float DeselectingIdle; // 0x24 (Size: 0x4, Type: FloatProperty)
    float DeselectingFocused; // 0x28 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FFNE_UIBlockTiming) == 0x2c, "Size mismatch for FFNE_UIBlockTiming");
static_assert(offsetof(FFNE_UIBlockTiming, Hovering) == 0x0, "Offset mismatch for FFNE_UIBlockTiming::Hovering");
static_assert(offsetof(FFNE_UIBlockTiming, Unhovering) == 0x4, "Offset mismatch for FFNE_UIBlockTiming::Unhovering");
static_assert(offsetof(FFNE_UIBlockTiming, Focusing) == 0x8, "Offset mismatch for FFNE_UIBlockTiming::Focusing");
static_assert(offsetof(FFNE_UIBlockTiming, Unfocusing) == 0xc, "Offset mismatch for FFNE_UIBlockTiming::Unfocusing");
static_assert(offsetof(FFNE_UIBlockTiming, Pressing) == 0x10, "Offset mismatch for FFNE_UIBlockTiming::Pressing");
static_assert(offsetof(FFNE_UIBlockTiming, Releasing) == 0x14, "Offset mismatch for FFNE_UIBlockTiming::Releasing");
static_assert(offsetof(FFNE_UIBlockTiming, Disabling) == 0x18, "Offset mismatch for FFNE_UIBlockTiming::Disabling");
static_assert(offsetof(FFNE_UIBlockTiming, Enabling) == 0x1c, "Offset mismatch for FFNE_UIBlockTiming::Enabling");
static_assert(offsetof(FFNE_UIBlockTiming, Selecting) == 0x20, "Offset mismatch for FFNE_UIBlockTiming::Selecting");
static_assert(offsetof(FFNE_UIBlockTiming, DeselectingIdle) == 0x24, "Offset mismatch for FFNE_UIBlockTiming::DeselectingIdle");
static_assert(offsetof(FFNE_UIBlockTiming, DeselectingFocused) == 0x28, "Offset mismatch for FFNE_UIBlockTiming::DeselectingFocused");

