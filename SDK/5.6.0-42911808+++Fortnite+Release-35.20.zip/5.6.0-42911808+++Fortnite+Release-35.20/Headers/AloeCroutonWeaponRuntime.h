/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AloeCroutonWeaponRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0x158 (Inherited: 0xd0, Single: 0x88)
class UFortChargingSet_AloeCrouton : public UFortChargingSet_Base
{
public:
    FFortGameplayAttributeData Charge; // 0x48 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData MaxCharge; // 0x70 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData ChargeRate; // 0x98 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData ChargeIncrementAmount; // 0xc0 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData ChargeRegenThreshold; // 0xe8 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData ServerTimeChargeIncrements; // 0x110 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_138[0x20]; // 0x138 (Size: 0x20, Type: PaddingProperty)

public:
    float GetCooldownDuration() const; // 0x1005ea24 (Index: 0x0, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCooldownRemaining() const; // 0x1005ea50 (Index: 0x1, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void OnRep_Charge(const FFortGameplayAttributeData OldValue); // 0x1005ed04 (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UFortChargingSet_AloeCrouton) == 0x158, "Size mismatch for UFortChargingSet_AloeCrouton");
static_assert(offsetof(UFortChargingSet_AloeCrouton, Charge) == 0x48, "Offset mismatch for UFortChargingSet_AloeCrouton::Charge");
static_assert(offsetof(UFortChargingSet_AloeCrouton, MaxCharge) == 0x70, "Offset mismatch for UFortChargingSet_AloeCrouton::MaxCharge");
static_assert(offsetof(UFortChargingSet_AloeCrouton, ChargeRate) == 0x98, "Offset mismatch for UFortChargingSet_AloeCrouton::ChargeRate");
static_assert(offsetof(UFortChargingSet_AloeCrouton, ChargeIncrementAmount) == 0xc0, "Offset mismatch for UFortChargingSet_AloeCrouton::ChargeIncrementAmount");
static_assert(offsetof(UFortChargingSet_AloeCrouton, ChargeRegenThreshold) == 0xe8, "Offset mismatch for UFortChargingSet_AloeCrouton::ChargeRegenThreshold");
static_assert(offsetof(UFortChargingSet_AloeCrouton, ServerTimeChargeIncrements) == 0x110, "Offset mismatch for UFortChargingSet_AloeCrouton::ServerTimeChargeIncrements");

// Size: 0x88 (Inherited: 0xb0, Single: 0xffffffd8)
class UFortCosmeticStatObject_AloeCroutonCharge : public UFortCosmeticStatObject
{
public:

private:
    void HandleChargeCountChanged(float& OldChargeCount, float& NewChargeCount, TWeakObjectPtr<AFortPlayerController*>& PlayerController); // 0x1005ea7c (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortCosmeticStatObject_AloeCroutonCharge) == 0x88, "Size mismatch for UFortCosmeticStatObject_AloeCroutonCharge");

