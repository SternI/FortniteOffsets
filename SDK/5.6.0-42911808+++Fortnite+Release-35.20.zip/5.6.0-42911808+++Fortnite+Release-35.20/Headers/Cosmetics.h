/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Cosmetics
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FBeanstalkCosmetics_PatternAtlasTextureSlotsInfo
{
    FString Name_15_2545F8D141FCEFF4E1C26E95718DB478; // 0x0 (Size: 0x10, Type: StrProperty)
    FVector UV_Values_20_EF64094F4DFFACDF1F733FA3C3858409; // 0x10 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FBeanstalkCosmetics_PatternAtlasTextureSlotsInfo) == 0x28, "Size mismatch for FBeanstalkCosmetics_PatternAtlasTextureSlotsInfo");
static_assert(offsetof(FBeanstalkCosmetics_PatternAtlasTextureSlotsInfo, Name_15_2545F8D141FCEFF4E1C26E95718DB478) == 0x0, "Offset mismatch for FBeanstalkCosmetics_PatternAtlasTextureSlotsInfo::Name_15_2545F8D141FCEFF4E1C26E95718DB478");
static_assert(offsetof(FBeanstalkCosmetics_PatternAtlasTextureSlotsInfo, UV_Values_20_EF64094F4DFFACDF1F733FA3C3858409) == 0x10, "Offset mismatch for FBeanstalkCosmetics_PatternAtlasTextureSlotsInfo::UV_Values_20_EF64094F4DFFACDF1F733FA3C3858409");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FBeanstalkCosmetics_MaterialTypeInfo
{
    FName Name_5_2545F8D141FCEFF4E1C26E95718DB478; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    double Metallic_17_26B17D57490B8DE99FD6AD85D810F3EB; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Roughness_10_EF64094F4DFFACDF1F733FA3C3858409; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double Emissive_19_4467043B429E4D5BECF743BAE9E8BF3B; // 0x18 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FBeanstalkCosmetics_MaterialTypeInfo) == 0x20, "Size mismatch for FBeanstalkCosmetics_MaterialTypeInfo");
static_assert(offsetof(FBeanstalkCosmetics_MaterialTypeInfo, Name_5_2545F8D141FCEFF4E1C26E95718DB478) == 0x0, "Offset mismatch for FBeanstalkCosmetics_MaterialTypeInfo::Name_5_2545F8D141FCEFF4E1C26E95718DB478");
static_assert(offsetof(FBeanstalkCosmetics_MaterialTypeInfo, Metallic_17_26B17D57490B8DE99FD6AD85D810F3EB) == 0x8, "Offset mismatch for FBeanstalkCosmetics_MaterialTypeInfo::Metallic_17_26B17D57490B8DE99FD6AD85D810F3EB");
static_assert(offsetof(FBeanstalkCosmetics_MaterialTypeInfo, Roughness_10_EF64094F4DFFACDF1F733FA3C3858409) == 0x10, "Offset mismatch for FBeanstalkCosmetics_MaterialTypeInfo::Roughness_10_EF64094F4DFFACDF1F733FA3C3858409");
static_assert(offsetof(FBeanstalkCosmetics_MaterialTypeInfo, Emissive_19_4467043B429E4D5BECF743BAE9E8BF3B) == 0x18, "Offset mismatch for FBeanstalkCosmetics_MaterialTypeInfo::Emissive_19_4467043B429E4D5BECF743BAE9E8BF3B");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBeanstalkCosmetics_RoughnessValuesInfo
{
    FName Name_5_2545F8D141FCEFF4E1C26E95718DB478; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    double Roughness_10_EF64094F4DFFACDF1F733FA3C3858409; // 0x8 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FBeanstalkCosmetics_RoughnessValuesInfo) == 0x10, "Size mismatch for FBeanstalkCosmetics_RoughnessValuesInfo");
static_assert(offsetof(FBeanstalkCosmetics_RoughnessValuesInfo, Name_5_2545F8D141FCEFF4E1C26E95718DB478) == 0x0, "Offset mismatch for FBeanstalkCosmetics_RoughnessValuesInfo::Name_5_2545F8D141FCEFF4E1C26E95718DB478");
static_assert(offsetof(FBeanstalkCosmetics_RoughnessValuesInfo, Roughness_10_EF64094F4DFFACDF1F733FA3C3858409) == 0x8, "Offset mismatch for FBeanstalkCosmetics_RoughnessValuesInfo::Roughness_10_EF64094F4DFFACDF1F733FA3C3858409");

