/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnalyticsBlueprintLibrary
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAnalyticsBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void EndSession(); // 0xc9ff32c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void FlushEvents(); // 0xc9ff340 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FString GetSessionId(); // 0xc9ff354 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FString GetUserId(); // 0xc9ff3d4 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FAnalyticsEventAttr MakeEventAttribute(FString& AttributeName, FString& AttributeValue); // 0xc9ff454 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void RecordCurrencyGiven(FString& GameCurrencyType, int32_t& GameCurrencyAmount); // 0xc9ff978 (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void RecordCurrencyGivenWithAttributes(FString& GameCurrencyType, int32_t& GameCurrencyAmount, const TArray<FAnalyticsEventAttr> Attributes); // 0xc9ffd3c (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void RecordCurrencyPurchase(FString& GameCurrencyType, int32_t& GameCurrencyAmount, FString& RealCurrencyType, float& RealMoneyCost, FString& PaymentProvider); // 0xca00190 (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void RecordError(FString& Error); // 0xca00814 (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void RecordErrorWithAttributes(FString& Error, const TArray<FAnalyticsEventAttr> Attributes); // 0xca00b04 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void RecordEvent(FString& EventName); // 0xca00e7c (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void RecordEventWithAttribute(FString& EventName, FString& AttributeName, FString& AttributeValue); // 0xca0116c (Index: 0xb, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void RecordEventWithAttributes(FString& EventName, const TArray<FAnalyticsEventAttr> Attributes); // 0xca01704 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void RecordItemPurchase(FString& ItemId, FString& Currency, int32_t& PerItemCost, int32_t& ItemQuantity); // 0xca01a7c (Index: 0xd, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void RecordProgress(FString& ProgressType, FString& ProgressName); // 0xca02024 (Index: 0xe, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void RecordProgressWithAttributes(FString& ProgressType, FString& ProgressName, const TArray<FAnalyticsEventAttr> Attributes); // 0xca0246c (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void RecordProgressWithFullHierarchyAndAttributes(FString& ProgressType, const TArray<FString> ProgressNames, const TArray<FAnalyticsEventAttr> Attributes); // 0xca02948 (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void RecordSimpleCurrencyPurchase(FString& GameCurrencyType, int32_t& GameCurrencyAmount); // 0xca02d48 (Index: 0x11, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void RecordSimpleCurrencyPurchaseWithAttributes(FString& GameCurrencyType, int32_t& GameCurrencyAmount, const TArray<FAnalyticsEventAttr> Attributes); // 0xca0310c (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void RecordSimpleItemPurchase(FString& ItemId, int32_t& ItemQuantity); // 0xca03560 (Index: 0x13, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void RecordSimpleItemPurchaseWithAttributes(FString& ItemId, int32_t& ItemQuantity, const TArray<FAnalyticsEventAttr> Attributes); // 0xca03924 (Index: 0x14, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetAge(int32_t& Age); // 0xca03d78 (Index: 0x15, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SetBuildInfo(FString& BuildInfo); // 0xca03e90 (Index: 0x16, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SetGender(FString& Gender); // 0xca04180 (Index: 0x17, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SetLocation(FString& Location); // 0xca04470 (Index: 0x18, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SetSessionId(FString& SessionId); // 0xca04760 (Index: 0x19, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SetUserId(FString& UserId); // 0xca04a50 (Index: 0x1a, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool StartSession(); // 0xca04d40 (Index: 0x1b, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool StartSessionWithAttributes(const TArray<FAnalyticsEventAttr> Attributes); // 0xca04d64 (Index: 0x1c, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAnalyticsBlueprintLibrary) == 0x28, "Size mismatch for UAnalyticsBlueprintLibrary");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FAnalyticsEventAttr
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FAnalyticsEventAttr) == 0x20, "Size mismatch for FAnalyticsEventAttr");
static_assert(offsetof(FAnalyticsEventAttr, Name) == 0x0, "Offset mismatch for FAnalyticsEventAttr::Name");
static_assert(offsetof(FAnalyticsEventAttr, Value) == 0x10, "Offset mismatch for FAnalyticsEventAttr::Value");

