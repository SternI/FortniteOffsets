/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeDynamicUIClient
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCreativeDynamicUILibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static TEnumAsByte<EHorizontalAlignment> GetHorizontalAlignment(ECreativeDynamicUIAlignment& const Alignment); // 0x11e9e57c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TEnumAsByte<EVerticalAlignment> GetVerticalAlignment(ECreativeDynamicUIAlignment& const Alignment); // 0x11e9e6ec (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UCreativeDynamicUILibrary) == 0x28, "Size mismatch for UCreativeDynamicUILibrary");

