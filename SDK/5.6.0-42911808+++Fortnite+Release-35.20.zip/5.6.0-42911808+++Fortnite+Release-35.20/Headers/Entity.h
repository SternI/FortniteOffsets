/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Entity
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "IrisCore.h"
#include "NetCore.h"
#include "Execution.h"

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UBaseEntity : public UObject
{
public:
    TArray<UObject*> Components; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<UObject*> OwnedEntities; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UBaseEntity) == 0x48, "Size mismatch for UBaseEntity");
static_assert(offsetof(UBaseEntity, Components) == 0x28, "Offset mismatch for UBaseEntity::Components");
static_assert(offsetof(UBaseEntity, OwnedEntities) == 0x38, "Offset mismatch for UBaseEntity::OwnedEntities");

// Size: 0xa8 (Inherited: 0x120, Single: 0xffffff88)
class UEntityPrefab : public UBlueprint
{
public:
};

static_assert(sizeof(UEntityPrefab) == 0xa8, "Size mismatch for UEntityPrefab");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEntityReplicationSupport : public UInterface
{
public:
};

static_assert(sizeof(UEntityReplicationSupport) == 0x28, "Size mismatch for UEntityReplicationSupport");

// Size: 0x460 (Inherited: 0x2d0, Single: 0x190)
class AEntityReplicator : public AActor
{
public:
    uint8_t Pad_2a8[0x8]; // 0x2a8 (Size: 0x8, Type: PaddingProperty)
    bool bIsNetInitialized; // 0x2b0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b1[0x7]; // 0x2b1 (Size: 0x7, Type: PaddingProperty)
    TSoftObjectPtr<UObject*> EntityPtr; // 0x2b8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UObject*> EntityOwnerPtr; // 0x2d8 (Size: 0x20, Type: SoftObjectProperty)
    FSoftObjectPath EntityServerPath; // 0x2f8 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath EntityOwnerServerPath; // 0x310 (Size: 0x18, Type: StructProperty)
    FFastEntityComponentArray NonDynamicEntityComponents; // 0x328 (Size: 0x118, Type: StructProperty)
    UObject* EntityPendingInitialization; // 0x440 (Size: 0x8, Type: ObjectProperty)
    TArray<UObject*> EntityComponentsPendingInitialization; // 0x448 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_458[0x8]; // 0x458 (Size: 0x8, Type: PaddingProperty)

private:
    void OnRep_EntityOwnerPtr(); // 0x554e3c4 (Index: 0x0, Flags: Final|Native|Private)
    void OnRep_EntityPtr(); // 0x554e3c4 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(AEntityReplicator) == 0x460, "Size mismatch for AEntityReplicator");
static_assert(offsetof(AEntityReplicator, bIsNetInitialized) == 0x2b0, "Offset mismatch for AEntityReplicator::bIsNetInitialized");
static_assert(offsetof(AEntityReplicator, EntityPtr) == 0x2b8, "Offset mismatch for AEntityReplicator::EntityPtr");
static_assert(offsetof(AEntityReplicator, EntityOwnerPtr) == 0x2d8, "Offset mismatch for AEntityReplicator::EntityOwnerPtr");
static_assert(offsetof(AEntityReplicator, EntityServerPath) == 0x2f8, "Offset mismatch for AEntityReplicator::EntityServerPath");
static_assert(offsetof(AEntityReplicator, EntityOwnerServerPath) == 0x310, "Offset mismatch for AEntityReplicator::EntityOwnerServerPath");
static_assert(offsetof(AEntityReplicator, NonDynamicEntityComponents) == 0x328, "Offset mismatch for AEntityReplicator::NonDynamicEntityComponents");
static_assert(offsetof(AEntityReplicator, EntityPendingInitialization) == 0x440, "Offset mismatch for AEntityReplicator::EntityPendingInitialization");
static_assert(offsetof(AEntityReplicator, EntityComponentsPendingInitialization) == 0x448, "Offset mismatch for AEntityReplicator::EntityComponentsPendingInitialization");

// Size: 0x460 (Inherited: 0x730, Single: 0xfffffd30)
class AEntityReplicator_AlwaysRelevant : public AEntityReplicator
{
public:
};

static_assert(sizeof(AEntityReplicator_AlwaysRelevant) == 0x460, "Size mismatch for AEntityReplicator_AlwaysRelevant");

// Size: 0x250 (Inherited: 0x88, Single: 0x1c8)
class UWorldExecutionSubsystem : public UWorldSubsystem
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    UExecutionSubsystem* ExecutionSystem; // 0x38 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_40[0x210]; // 0x40 (Size: 0x210, Type: PaddingProperty)
};

static_assert(sizeof(UWorldExecutionSubsystem) == 0x250, "Size mismatch for UWorldExecutionSubsystem");
static_assert(offsetof(UWorldExecutionSubsystem, ExecutionSystem) == 0x38, "Offset mismatch for UWorldExecutionSubsystem::ExecutionSystem");

// Size: 0x48 (Inherited: 0x60, Single: 0xffffffe8)
class UNetEntityFactory : public UNetObjectFactory
{
public:
};

static_assert(sizeof(UNetEntityFactory) == 0x48, "Size mismatch for UNetEntityFactory");

// Size: 0x2e8 (Inherited: 0x2d0, Single: 0x18)
class ASimulationEntity : public AActor
{
public:
    UObject* SimulationEntity; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UClass* SavedEntityClass; // 0x2b0 (Size: 0x8, Type: ClassProperty)
    UClass* SavedEntityComponentClass; // 0x2b8 (Size: 0x8, Type: ClassProperty)
    TArray<FString> DefaultComponentClassNames; // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> DefaultComponentClasses; // 0x2d0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_2e0[0x8]; // 0x2e0 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(ASimulationEntity) == 0x2e8, "Size mismatch for ASimulationEntity");
static_assert(offsetof(ASimulationEntity, SimulationEntity) == 0x2a8, "Offset mismatch for ASimulationEntity::SimulationEntity");
static_assert(offsetof(ASimulationEntity, SavedEntityClass) == 0x2b0, "Offset mismatch for ASimulationEntity::SavedEntityClass");
static_assert(offsetof(ASimulationEntity, SavedEntityComponentClass) == 0x2b8, "Offset mismatch for ASimulationEntity::SavedEntityComponentClass");
static_assert(offsetof(ASimulationEntity, DefaultComponentClassNames) == 0x2c0, "Offset mismatch for ASimulationEntity::DefaultComponentClassNames");
static_assert(offsetof(ASimulationEntity, DefaultComponentClasses) == 0x2d0, "Offset mismatch for ASimulationEntity::DefaultComponentClasses");

// Size: 0xb8 (Inherited: 0xe0, Single: 0xffffffd8)
class USimulationLifetimeComponent : public UActorComponent
{
public:
};

static_assert(sizeof(USimulationLifetimeComponent) == 0xb8, "Size mismatch for USimulationLifetimeComponent");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UEntityPlayspaceRegistryBase : public UWorldSubsystem
{
public:
};

static_assert(sizeof(UEntityPlayspaceRegistryBase) == 0x30, "Size mismatch for UEntityPlayspaceRegistryBase");

// Size: 0x30 (Inherited: 0x88, Single: 0xffffffa8)
class UEntityRegistryBase : public UWorldSubsystem
{
public:
};

static_assert(sizeof(UEntityRegistryBase) == 0x30, "Size mismatch for UEntityRegistryBase");

// Size: 0x38 (Inherited: 0xb8, Single: 0xffffff80)
class UEntityVerseEngineSubsystem : public UEngineSubsystem
{
public:
};

static_assert(sizeof(UEntityVerseEngineSubsystem) == 0x38, "Size mismatch for UEntityVerseEngineSubsystem");

// Size: 0x10 (Inherited: 0xc, Single: 0x4)
struct FFastEntityComponentArrayItem : FFastArraySerializerItem
{
    FName ComponentName; // 0xc (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FFastEntityComponentArrayItem) == 0x10, "Size mismatch for FFastEntityComponentArrayItem");
static_assert(offsetof(FFastEntityComponentArrayItem, ComponentName) == 0xc, "Offset mismatch for FFastEntityComponentArrayItem::ComponentName");

// Size: 0x118 (Inherited: 0x108, Single: 0x10)
struct FFastEntityComponentArray : FFastArraySerializer
{
    TArray<FFastEntityComponentArrayItem> Components; // 0x108 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFastEntityComponentArray) == 0x118, "Size mismatch for FFastEntityComponentArray");
static_assert(offsetof(FFastEntityComponentArray, Components) == 0x108, "Offset mismatch for FFastEntityComponentArray::Components");

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
struct FWorldExecutionPhase : FTickFunction
{
};

static_assert(sizeof(FWorldExecutionPhase) == 0x58, "Size mismatch for FWorldExecutionPhase");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FReplicatedDataEntry
{
    UObject* ReplicatedData; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0x10]; // 0x8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FReplicatedDataEntry) == 0x18, "Size mismatch for FReplicatedDataEntry");
static_assert(offsetof(FReplicatedDataEntry, ReplicatedData) == 0x0, "Offset mismatch for FReplicatedDataEntry::ReplicatedData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FReplicatedDataRegistry
{
    TArray<FReplicatedDataEntry> Registry; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FReplicatedDataRegistry) == 0x10, "Size mismatch for FReplicatedDataRegistry");
static_assert(offsetof(FReplicatedDataRegistry, Registry) == 0x0, "Offset mismatch for FReplicatedDataRegistry::Registry");

