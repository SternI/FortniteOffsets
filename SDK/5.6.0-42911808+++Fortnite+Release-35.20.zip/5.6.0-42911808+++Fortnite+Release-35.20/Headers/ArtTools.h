/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ArtTools
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "UMG.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEUW_FunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:

public:
    static void Create_SliderLabel(FPaintContext& OnPaintContext, USlider*& Slider, FVector2D& PositionalShift, FString& Label, FLinearColor& Label_Color, int32_t& FontSize, UObject*& __WorldContext, FPaintContext& ContextOut); // 0x288a61c (Index: 0x0, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    static void PointVector_PointVector_Intersection(FVector& FirstVectorOrigin, FVector& FirstVectorDirection, FVector& SecondVectorOrigin, FVector& SecondVectorDirection, UObject*& __WorldContext, FVector& IntersectionPoint, bool& DoVectorsInersect_); // 0x288a61c (Index: 0x1, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    static FVector2D Lerp_Vector_2D(FVector2D& A, FVector2D& B, double& Alpha, UObject*& __WorldContext); // 0x288a61c (Index: 0x2, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
};

static_assert(sizeof(UEUW_FunctionLibrary_C) == 0x28, "Size mismatch for UEUW_FunctionLibrary_C");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UB_TechArt_GlobalLibrary_C : public UBlueprintFunctionLibrary
{
public:

public:
    static void UseVolumetricCloudsBR(UObject*& __WorldContext, bool& Return_Value); // 0x288a61c (Index: 0x0, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void IsLumenEnabled(UObject*& __WorldContext, bool& IsEnabled); // 0x288a61c (Index: 0x1, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void HoudiniInstanceHISMBuilder(UInstancedStaticMeshComponent*& InstancedStaticMeshComponent, UDataTable*& InstanceDataTable, double& InstancesCountToImport, bool& RandomScale, double& RandomScaleMin, double& RandomScaleMax, bool& RandomRotationZ, double& RandomRotationZMin, double& RandomRotationZMax, bool& UseWorldSpacePositions, UObject*& __WorldContext); // 0x288a61c (Index: 0x2, Flags: Static|Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    static void GetDynamicMaterialInstance(UMeshComponent*& MeshComponent, int32_t& MaterialIndex, UObject*& __WorldContext, UMaterialInstanceDynamic*& Material_Instance_Dynamic); // 0x288a61c (Index: 0x3, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void BindScalabilitySettings(const FDelegate Delegate, UObject*& __WorldContext); // 0x288a61c (Index: 0x4, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    static void AreBoundsOverlapping_(FBox& BoundsA, FBox& BoundsB, UObject*& __WorldContext, bool& BoundsOverlap_); // 0x288a61c (Index: 0x5, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void AddActorTag(AActor*& Actor, const FName Tag, UObject*& __WorldContext); // 0x288a61c (Index: 0x6, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UB_TechArt_GlobalLibrary_C) == 0x28, "Size mismatch for UB_TechArt_GlobalLibrary_C");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class URenderToTextureFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:

public:
    static void Set_Canvas_Material_Scale_and_Position(FVector2D& Size, FVector2D& Position, double& Scale, UObject*& __WorldContext, FVector2D& Screen_Position, FVector2D& Screen_Size); // 0x288a61c (Index: 0x0, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void Array_to_HLSL_Int_Array(TEnumAsByte<EIntTypes>& Type, FString Variable_Name, TArray<int32_t> int, TArray<FVector2D> int2, TArray<FVector> int3, TArray<FLinearColor> int4, UObject*& __WorldContext, FString& String); // 0x288a61c (Index: 0x1, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(URenderToTextureFunctionLibrary_C) == 0x28, "Size mismatch for URenderToTextureFunctionLibrary_C");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FHoudiniInstanceDataLayout
{
    float Px_4_F5C0CE7F4E57E0634EEBA7986A38B75B; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Py_7_462CEB644FCF8818190E0DA7A4233236; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Pz_8_488530224541EBF7D43F2F99AE2CCEAF; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Nx_18_51E5EF044A718D85E72395AA9D96475D; // 0xc (Size: 0x4, Type: FloatProperty)
    float Ny_22_85D94369412DF832716FAD9638F05274; // 0x10 (Size: 0x4, Type: FloatProperty)
    float Nz_23_267E08D5410B2BAA799B67975DE79784; // 0x14 (Size: 0x4, Type: FloatProperty)
    float pscale_24_C1C793994E739F1A41356ABC35528C18; // 0x18 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FHoudiniInstanceDataLayout) == 0x1c, "Size mismatch for FHoudiniInstanceDataLayout");
static_assert(offsetof(FHoudiniInstanceDataLayout, Px_4_F5C0CE7F4E57E0634EEBA7986A38B75B) == 0x0, "Offset mismatch for FHoudiniInstanceDataLayout::Px_4_F5C0CE7F4E57E0634EEBA7986A38B75B");
static_assert(offsetof(FHoudiniInstanceDataLayout, Py_7_462CEB644FCF8818190E0DA7A4233236) == 0x4, "Offset mismatch for FHoudiniInstanceDataLayout::Py_7_462CEB644FCF8818190E0DA7A4233236");
static_assert(offsetof(FHoudiniInstanceDataLayout, Pz_8_488530224541EBF7D43F2F99AE2CCEAF) == 0x8, "Offset mismatch for FHoudiniInstanceDataLayout::Pz_8_488530224541EBF7D43F2F99AE2CCEAF");
static_assert(offsetof(FHoudiniInstanceDataLayout, Nx_18_51E5EF044A718D85E72395AA9D96475D) == 0xc, "Offset mismatch for FHoudiniInstanceDataLayout::Nx_18_51E5EF044A718D85E72395AA9D96475D");
static_assert(offsetof(FHoudiniInstanceDataLayout, Ny_22_85D94369412DF832716FAD9638F05274) == 0x10, "Offset mismatch for FHoudiniInstanceDataLayout::Ny_22_85D94369412DF832716FAD9638F05274");
static_assert(offsetof(FHoudiniInstanceDataLayout, Nz_23_267E08D5410B2BAA799B67975DE79784) == 0x14, "Offset mismatch for FHoudiniInstanceDataLayout::Nz_23_267E08D5410B2BAA799B67975DE79784");
static_assert(offsetof(FHoudiniInstanceDataLayout, pscale_24_C1C793994E739F1A41356ABC35528C18) == 0x18, "Offset mismatch for FHoudiniInstanceDataLayout::pscale_24_C1C793994E739F1A41356ABC35528C18");

