/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_HUDController
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "DynamicUI.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "SlateCore.h"
#include "CoreUObject.h"
#include "GameplayEventRouter.h"

// Size: 0xe0 (Inherited: 0xe0, Single: 0x0)
class UCustomHUDLayoutComponent : public UActorComponent
{
public:
    char DynamicUISceneLayerID; // 0xb8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_b9[0x3]; // 0xb9 (Size: 0x3, Type: PaddingProperty)
    FGameplayEventListenerHandle LayoutChangeListenerHandle; // 0xbc (Size: 0x1c, Type: StructProperty)
    UDynamicUIScene* CachedScene; // 0xd8 (Size: 0x8, Type: ObjectProperty)

private:
    void BindToMinigame(AFortMinigame*& Minigame); // 0x11e59f84 (Index: 0x1, Flags: Final|Native|Private)
    void OnCreativePlotLinkedSpatialGameplayInterfaceChanged(TScriptInterface<Class>& SpatialGameplayInterface); // 0x11e5a2a8 (Index: 0x9, Flags: Final|Native|Private)

protected:
    virtual bool AllowRepositioning(const FGameplayTag GameplayTag); // 0x11e59e8c (Index: 0x0, Flags: Native|Event|Protected|HasOutParms|BlueprintEvent)
    virtual FMargin GetClampingPadding(const FGameplayTag GameplayTag); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual TSoftClassPtr GetTargetWidgetClassFromTag(const FGameplayTag GameplayTag); // 0x288a61c (Index: 0x3, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual FName GetTargetWidgetUniqueIDFromTag(const FGameplayTag GameplayTag); // 0x288a61c (Index: 0x4, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual FVector2D GetWidgetEstimatedSize(const FGameplayTag GameplayTag); // 0x288a61c (Index: 0x5, Flags: Event|Protected|HasOutParms|HasDefaults|BlueprintEvent)
    void HandleMinigameEnded(); // 0x11e5a0b0 (Index: 0x6, Flags: Final|Native|Protected)
    void HandleReceiveLayoutChange(const FHUDElementLayoutUpdatedEvent Event); // 0x11e5a0c4 (Index: 0x7, Flags: Final|Native|Protected|HasOutParms)
    void HandleTeamIndexChanged(char& TeamIndex); // 0x11e5a180 (Index: 0x8, Flags: Final|Native|Protected)
    void PlayerPreRemoved(FUniqueNetIdRepl& UniqueNetId, bool& bIsLocalPlayer); // 0x11e5a63c (Index: 0xa, Flags: Final|Native|Protected)
    virtual bool ShouldClampToScreen(const FGameplayTag GameplayTag); // 0x288a61c (Index: 0xb, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    void UpdateDynamicUIScene(); // 0x11e5a7d4 (Index: 0xc, Flags: Final|Native|Protected)
};

static_assert(sizeof(UCustomHUDLayoutComponent) == 0xe0, "Size mismatch for UCustomHUDLayoutComponent");
static_assert(offsetof(UCustomHUDLayoutComponent, DynamicUISceneLayerID) == 0xb8, "Offset mismatch for UCustomHUDLayoutComponent::DynamicUISceneLayerID");
static_assert(offsetof(UCustomHUDLayoutComponent, LayoutChangeListenerHandle) == 0xbc, "Offset mismatch for UCustomHUDLayoutComponent::LayoutChangeListenerHandle");
static_assert(offsetof(UCustomHUDLayoutComponent, CachedScene) == 0xd8, "Offset mismatch for UCustomHUDLayoutComponent::CachedScene");

