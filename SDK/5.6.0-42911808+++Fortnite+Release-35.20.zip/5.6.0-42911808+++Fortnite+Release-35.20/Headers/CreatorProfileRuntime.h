/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreatorProfileRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteGame.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCreatorProfileBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

private:
    static bool GetLinkData(AActor*& const ActorContext, FString& OutSupportCode, FString& OutCreatorId); // 0x11a9e6c0 (Index: 0x0, Flags: Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool GetOwnerProfile(AActor*& const ActorContext, FString& OutSupportCode, FString& OutCreatorId); // 0x11a9eb40 (Index: 0x1, Flags: Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsMinor(APlayerController*& const PC); // 0x11a9efa8 (Index: 0x2, Flags: Final|Native|Static|Private|BlueprintCallable|BlueprintPure)
    static bool IsUGCRestricted(APlayerController*& const PC); // 0x11a9f124 (Index: 0x3, Flags: Final|Native|Static|Private|BlueprintCallable|BlueprintPure)
    static bool ShouldUsePlayspaceComponent(); // 0x11a9f59c (Index: 0x4, Flags: Final|Native|Static|Private|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UCreatorProfileBlueprintFunctionLibrary) == 0x28, "Size mismatch for UCreatorProfileBlueprintFunctionLibrary");

// Size: 0x150 (Inherited: 0x360, Single: 0xfffffdf0)
class UFortPlayspaceComponent_CreatorProfile : public UFortPlayspaceComponent
{
public:
    uint8_t OnCreatorSocialInfoUpdated[0x10]; // 0x110 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_120[0x10]; // 0x120 (Size: 0x10, Type: PaddingProperty)
    TWeakObjectPtr<AFortPlayerController*> CachedPlayerController; // 0x130 (Size: 0x8, Type: WeakObjectProperty)
    TArray<FString> UpdatedCreatorSocialInfoStrings; // 0x138 (Size: 0x10, Type: ArrayProperty)
    bool HasCreatorSocialInfoFetched; // 0x148 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_149[0x7]; // 0x149 (Size: 0x7, Type: PaddingProperty)

protected:
    void SetGameAccountIdForFetch(FString& InIdString); // 0x11a9f2a8 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    TArray<FString> UpdatedCreatorSocialInfoArray() const; // 0x11a9f5b4 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortPlayspaceComponent_CreatorProfile) == 0x150, "Size mismatch for UFortPlayspaceComponent_CreatorProfile");
static_assert(offsetof(UFortPlayspaceComponent_CreatorProfile, OnCreatorSocialInfoUpdated) == 0x110, "Offset mismatch for UFortPlayspaceComponent_CreatorProfile::OnCreatorSocialInfoUpdated");
static_assert(offsetof(UFortPlayspaceComponent_CreatorProfile, CachedPlayerController) == 0x130, "Offset mismatch for UFortPlayspaceComponent_CreatorProfile::CachedPlayerController");
static_assert(offsetof(UFortPlayspaceComponent_CreatorProfile, UpdatedCreatorSocialInfoStrings) == 0x138, "Offset mismatch for UFortPlayspaceComponent_CreatorProfile::UpdatedCreatorSocialInfoStrings");
static_assert(offsetof(UFortPlayspaceComponent_CreatorProfile, HasCreatorSocialInfoFetched) == 0x148, "Offset mismatch for UFortPlayspaceComponent_CreatorProfile::HasCreatorSocialInfoFetched");

