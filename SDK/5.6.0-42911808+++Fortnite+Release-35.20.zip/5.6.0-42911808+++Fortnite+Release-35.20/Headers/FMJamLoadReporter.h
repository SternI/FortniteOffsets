/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamLoadReporter
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "ModularGameplay.h"
#include "CoreUObject.h"
#include "FMJamContentResolver.h"

// Size: 0x168 (Inherited: 0x250, Single: 0xffffff18)
class UJamLoadReporter : public UGameStateComponent
{
public:

public:
    TArray<FString> GenerateFullReport() const; // 0x10799774 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static UJamLoadReporter* Get(UObject*& const WorldContext); // 0x107997b0 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UJamLoadReporter* TryGet(UObject*& const WorldContext); // 0x107997b0 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable)

private:
    void OnResolveAndLoadComplete(UJamContentResolver*& Sender, FString& LinkCode, bool& bSuccess, bool& bWasAlreadyLoaded); // 0x107998d8 (Index: 0x2, Flags: Final|Native|Private)
    void OnResolveComplete(UJamContentResolver*& Sender, FString& LinkCode, bool& bSuccess); // 0x10799e74 (Index: 0x3, Flags: Final|Native|Private)
};

static_assert(sizeof(UJamLoadReporter) == 0x168, "Size mismatch for UJamLoadReporter");

