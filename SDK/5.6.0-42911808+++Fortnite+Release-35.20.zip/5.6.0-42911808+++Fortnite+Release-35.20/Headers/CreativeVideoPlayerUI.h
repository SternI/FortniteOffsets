/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeVideoPlayerUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CommonUI.h"
#include "MediaAssets.h"
#include "Engine.h"
#include "CommonUILegacy.h"
#include "UMG.h"

// Size: 0x480 (Inherited: 0xb38, Single: 0xfffff948)
class UCreativeVideoPlayerFullScreenWidget : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x18]; // 0x408 (Size: 0x18, Type: PaddingProperty)
    USoundSourceBus* SourceBus; // 0x420 (Size: 0x8, Type: ObjectProperty)
    USoundClass* SoundClass; // 0x428 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle HoldToSkipAction; // 0x430 (Size: 0x10, Type: StructProperty)
    UCommonButtonLegacy* Button_Skip; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_VideoTexture; // 0x448 (Size: 0x8, Type: ObjectProperty)
    float SkipButtonTimeout; // 0x450 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_454[0x14]; // 0x454 (Size: 0x14, Type: PaddingProperty)
    UAudioComponent* SoundComponent; // 0x468 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_470[0x10]; // 0x470 (Size: 0x10, Type: PaddingProperty)

public:
    void SetExternalComponents(UMediaTexture*& VideoTextureExt, USoundSourceBus*& ExtSourceBus); // 0x11a9179c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnSkipButtonActionComplete(); // 0x11a91660 (Index: 0x0, Flags: Final|Native|Private)
    void OnSkipButtonActionProgress(float& HeldPercent); // 0x11a91674 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UCreativeVideoPlayerFullScreenWidget) == 0x480, "Size mismatch for UCreativeVideoPlayerFullScreenWidget");
static_assert(offsetof(UCreativeVideoPlayerFullScreenWidget, SourceBus) == 0x420, "Offset mismatch for UCreativeVideoPlayerFullScreenWidget::SourceBus");
static_assert(offsetof(UCreativeVideoPlayerFullScreenWidget, SoundClass) == 0x428, "Offset mismatch for UCreativeVideoPlayerFullScreenWidget::SoundClass");
static_assert(offsetof(UCreativeVideoPlayerFullScreenWidget, HoldToSkipAction) == 0x430, "Offset mismatch for UCreativeVideoPlayerFullScreenWidget::HoldToSkipAction");
static_assert(offsetof(UCreativeVideoPlayerFullScreenWidget, Button_Skip) == 0x440, "Offset mismatch for UCreativeVideoPlayerFullScreenWidget::Button_Skip");
static_assert(offsetof(UCreativeVideoPlayerFullScreenWidget, Image_VideoTexture) == 0x448, "Offset mismatch for UCreativeVideoPlayerFullScreenWidget::Image_VideoTexture");
static_assert(offsetof(UCreativeVideoPlayerFullScreenWidget, SkipButtonTimeout) == 0x450, "Offset mismatch for UCreativeVideoPlayerFullScreenWidget::SkipButtonTimeout");
static_assert(offsetof(UCreativeVideoPlayerFullScreenWidget, SoundComponent) == 0x468, "Offset mismatch for UCreativeVideoPlayerFullScreenWidget::SoundComponent");

