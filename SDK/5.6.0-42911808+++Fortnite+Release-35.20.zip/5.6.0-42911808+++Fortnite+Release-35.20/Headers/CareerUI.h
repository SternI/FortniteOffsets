/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CareerUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "ModelViewViewModel.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "FortniteUI.h"
#include "GameplayTags.h"
#include "FortniteGame.h"

// Size: 0xb8 (Inherited: 0x90, Single: 0x28)
class UFortCareerChangeFlagModalItemVM : public UMVVMViewModelBase
{
public:
    FString RegionId; // 0x68 (Size: 0x10, Type: StrProperty)
    FText RegionDisplayName; // 0x78 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D*> RegionFlagAsset; // 0x88 (Size: 0x20, Type: SoftObjectProperty)
    bool bIsCurrent; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)
    UFortCareerUIManager* CareerUIManager; // 0xb0 (Size: 0x8, Type: ObjectProperty)

public:
    void InitializeVM(FString& InRegionID, FString& InCurrentRegionId); // 0x11007ef8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortCareerChangeFlagModalItemVM) == 0xb8, "Size mismatch for UFortCareerChangeFlagModalItemVM");
static_assert(offsetof(UFortCareerChangeFlagModalItemVM, RegionId) == 0x68, "Offset mismatch for UFortCareerChangeFlagModalItemVM::RegionId");
static_assert(offsetof(UFortCareerChangeFlagModalItemVM, RegionDisplayName) == 0x78, "Offset mismatch for UFortCareerChangeFlagModalItemVM::RegionDisplayName");
static_assert(offsetof(UFortCareerChangeFlagModalItemVM, RegionFlagAsset) == 0x88, "Offset mismatch for UFortCareerChangeFlagModalItemVM::RegionFlagAsset");
static_assert(offsetof(UFortCareerChangeFlagModalItemVM, bIsCurrent) == 0xa8, "Offset mismatch for UFortCareerChangeFlagModalItemVM::bIsCurrent");
static_assert(offsetof(UFortCareerChangeFlagModalItemVM, CareerUIManager) == 0xb0, "Offset mismatch for UFortCareerChangeFlagModalItemVM::CareerUIManager");

// Size: 0xd8 (Inherited: 0x140, Single: 0xffffff98)
class UFortCareerChangeFlagModalVM : public UFortCareerStatsScreenVM
{
public:
    uint8_t OnFlagChanged[0x10]; // 0xb0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t RegionLockDaysRemaining; // 0xc0 (Size: 0x4, Type: IntProperty)
    bool bAllowedToChangeFlag; // 0xc4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c5[0x3]; // 0xc5 (Size: 0x3, Type: PaddingProperty)
    TArray<UFortCareerChangeFlagModalItemVM*> AvailableRegions; // 0xc8 (Size: 0x10, Type: ArrayProperty)

public:
    void ChangeFlag(FString& InRegion); // 0x11007984 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    int32_t GetFlagChangeCooldownDays() const; // 0x11007c78 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnChangeFlagModalFlagChanged__DelegateSignature(const FFortCompetitiveIdentityInfo NewFlagRegionInfo); // 0x288a61c (Index: 0x2, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
};

static_assert(sizeof(UFortCareerChangeFlagModalVM) == 0xd8, "Size mismatch for UFortCareerChangeFlagModalVM");
static_assert(offsetof(UFortCareerChangeFlagModalVM, OnFlagChanged) == 0xb0, "Offset mismatch for UFortCareerChangeFlagModalVM::OnFlagChanged");
static_assert(offsetof(UFortCareerChangeFlagModalVM, RegionLockDaysRemaining) == 0xc0, "Offset mismatch for UFortCareerChangeFlagModalVM::RegionLockDaysRemaining");
static_assert(offsetof(UFortCareerChangeFlagModalVM, bAllowedToChangeFlag) == 0xc4, "Offset mismatch for UFortCareerChangeFlagModalVM::bAllowedToChangeFlag");
static_assert(offsetof(UFortCareerChangeFlagModalVM, AvailableRegions) == 0xc8, "Offset mismatch for UFortCareerChangeFlagModalVM::AvailableRegions");

// Size: 0xb0 (Inherited: 0x90, Single: 0x20)
class UFortCareerStatsScreenVM : public UMVVMViewModelBase
{
public:
    FString RegionId; // 0x68 (Size: 0x10, Type: StrProperty)
    FText RegionDisplayName; // 0x78 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D*> RegionFlagAsset; // 0x88 (Size: 0x20, Type: SoftObjectProperty)
    UFortCareerUIManager* CareerUIManager; // 0xa8 (Size: 0x8, Type: ObjectProperty)

public:
    bool HasSeenOnboarding(const FGameplayTag InOnboardingSeenId) const; // 0x11007cb0 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void InitializeVM(); // 0x41f1e2c (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    void SetOnboardingSeen(const FGameplayTag InOnboardingSeenId); // 0x11008360 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SetOtherAccountId(const FUniqueNetIdRepl InAccountId); // 0x11008468 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UFortCareerStatsScreenVM) == 0xb0, "Size mismatch for UFortCareerStatsScreenVM");
static_assert(offsetof(UFortCareerStatsScreenVM, RegionId) == 0x68, "Offset mismatch for UFortCareerStatsScreenVM::RegionId");
static_assert(offsetof(UFortCareerStatsScreenVM, RegionDisplayName) == 0x78, "Offset mismatch for UFortCareerStatsScreenVM::RegionDisplayName");
static_assert(offsetof(UFortCareerStatsScreenVM, RegionFlagAsset) == 0x88, "Offset mismatch for UFortCareerStatsScreenVM::RegionFlagAsset");
static_assert(offsetof(UFortCareerStatsScreenVM, CareerUIManager) == 0xa8, "Offset mismatch for UFortCareerStatsScreenVM::CareerUIManager");

// Size: 0x88 (Inherited: 0xb8, Single: 0xffffffd0)
class UFortCareerUIManager : public UEngineSubsystem
{
public:
    uint8_t Pad_30[0x50]; // 0x30 (Size: 0x50, Type: PaddingProperty)
    UFortCareerChangeFlagModalVM* ChangeFlagModalVM; // 0x80 (Size: 0x8, Type: ObjectProperty)

public:
    UFortCareerChangeFlagModalVM* GetChangeFlagModalVM(); // 0xfd1f838 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void InitializeManager(UObject*& const WorldContextObject); // 0x11007dcc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void SetMainAccountId(); // 0x1100834c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortCareerUIManager) == 0x88, "Size mismatch for UFortCareerUIManager");
static_assert(offsetof(UFortCareerUIManager, ChangeFlagModalVM) == 0x80, "Offset mismatch for UFortCareerUIManager::ChangeFlagModalVM");

// Size: 0x48 (Inherited: 0x78, Single: 0xffffffd0)
class UFortUIGameFeatureAction_CompeteTab : public UFortUIGameFeatureAction
{
public:
    TSoftClassPtr CareerStatsScreenClass; // 0x28 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UFortUIGameFeatureAction_CompeteTab) == 0x48, "Size mismatch for UFortUIGameFeatureAction_CompeteTab");
static_assert(offsetof(UFortUIGameFeatureAction_CompeteTab, CareerStatsScreenClass) == 0x28, "Offset mismatch for UFortUIGameFeatureAction_CompeteTab::CareerStatsScreenClass");

