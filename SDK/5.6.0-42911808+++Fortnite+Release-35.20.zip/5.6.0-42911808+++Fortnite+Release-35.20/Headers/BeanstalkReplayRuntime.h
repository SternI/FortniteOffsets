/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeanstalkReplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0xb8 (Inherited: 0x3c0, Single: 0xfffffcf8)
class UFortGameStateComponent_BeanstalkReplay : public UFortGameStateComponent_Replay
{
public:
};

static_assert(sizeof(UFortGameStateComponent_BeanstalkReplay) == 0xb8, "Size mismatch for UFortGameStateComponent_BeanstalkReplay");

