/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CilantroUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CommonUI.h"
#include "FortniteUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "ModelViewViewModel.h"
#include "CommonUILegacy.h"
#include "FortniteGame.h"

// Size: 0x458 (Inherited: 0xb38, Single: 0xfffff920)
class UFortPlaytimeBlock : public UCommonActivatableWidget
{
public:
    UCommonActivatableWidgetStack* WidgetStack_Takeover; // 0x408 (Size: 0x8, Type: ObjectProperty)
    TSoftClassPtr FortLegalInfoClass; // 0x410 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr ParentalControlsClass; // 0x430 (Size: 0x20, Type: SoftClassProperty)
    uint8_t Pad_450[0x8]; // 0x450 (Size: 0x8, Type: PaddingProperty)

public:
    void DisplayLegalModal(); // 0x11020d6c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void DisplayReporting(); // 0x11020d80 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void DisplayVoiceReporting(); // 0x11020d94 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void LaunchSupportURL(); // 0x1102159c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void OpenParentalControls(); // 0x110215c4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void OpenReturnPanel(); // 0x11021704 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void TryClose(bool& const bForceClose); // 0x3287c98 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void OnReturnFocusFromTakeover(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortPlaytimeBlock) == 0x458, "Size mismatch for UFortPlaytimeBlock");
static_assert(offsetof(UFortPlaytimeBlock, WidgetStack_Takeover) == 0x408, "Offset mismatch for UFortPlaytimeBlock::WidgetStack_Takeover");
static_assert(offsetof(UFortPlaytimeBlock, FortLegalInfoClass) == 0x410, "Offset mismatch for UFortPlaytimeBlock::FortLegalInfoClass");
static_assert(offsetof(UFortPlaytimeBlock, ParentalControlsClass) == 0x430, "Offset mismatch for UFortPlaytimeBlock::ParentalControlsClass");

// Size: 0x648 (Inherited: 0x15c8, Single: 0xfffff080)
class UFortPlaytimeManagementScreen : public UFortPinScreen
{
public:
    UCommonActivatableWidgetSwitcher* Switcher_SubViews; // 0x550 (Size: 0x8, Type: ObjectProperty)
    UFortSettingsPanel* Panel_PlaytimeSettings; // 0x558 (Size: 0x8, Type: ObjectProperty)
    UFortSettingsPanel* Panel_PlaytimeScheduleSettings; // 0x560 (Size: 0x8, Type: ObjectProperty)
    UFortSettingDetailView* Details_Settings; // 0x568 (Size: 0x8, Type: ObjectProperty)
    UFortPlaytimeScheduleWidget* PlaytimeScheduleWidget; // 0x570 (Size: 0x8, Type: ObjectProperty)
    UFortPlaytimeSettingRegistry* PlaytimeSettingRegistry; // 0x578 (Size: 0x8, Type: ObjectProperty)
    UFortPlaytimeScheduleSettingRegistry* PlaytimeSettingScheduleRegistry; // 0x580 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_588[0xc0]; // 0x588 (Size: 0xc0, Type: PaddingProperty)

public:
    void ExitScreen(); // 0x11020da8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    FText GetTimezoneText() const; // 0x11020fec (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void OnPlaytimeScheduleRequested(); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    void RefreshPlaytimeScheduleSettings(); // 0x1102175c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void RefreshPlaytimeSettings(); // 0x11021778 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortPlaytimeManagementScreen) == 0x648, "Size mismatch for UFortPlaytimeManagementScreen");
static_assert(offsetof(UFortPlaytimeManagementScreen, Switcher_SubViews) == 0x550, "Offset mismatch for UFortPlaytimeManagementScreen::Switcher_SubViews");
static_assert(offsetof(UFortPlaytimeManagementScreen, Panel_PlaytimeSettings) == 0x558, "Offset mismatch for UFortPlaytimeManagementScreen::Panel_PlaytimeSettings");
static_assert(offsetof(UFortPlaytimeManagementScreen, Panel_PlaytimeScheduleSettings) == 0x560, "Offset mismatch for UFortPlaytimeManagementScreen::Panel_PlaytimeScheduleSettings");
static_assert(offsetof(UFortPlaytimeManagementScreen, Details_Settings) == 0x568, "Offset mismatch for UFortPlaytimeManagementScreen::Details_Settings");
static_assert(offsetof(UFortPlaytimeManagementScreen, PlaytimeScheduleWidget) == 0x570, "Offset mismatch for UFortPlaytimeManagementScreen::PlaytimeScheduleWidget");
static_assert(offsetof(UFortPlaytimeManagementScreen, PlaytimeSettingRegistry) == 0x578, "Offset mismatch for UFortPlaytimeManagementScreen::PlaytimeSettingRegistry");
static_assert(offsetof(UFortPlaytimeManagementScreen, PlaytimeSettingScheduleRegistry) == 0x580, "Offset mismatch for UFortPlaytimeManagementScreen::PlaytimeSettingScheduleRegistry");

// Size: 0x2b0 (Inherited: 0x458, Single: 0xfffffe58)
class UFortPlaytimeScheduleWidget : public UUserWidget
{
public:

protected:
    virtual void OnScheduleTextsUpdated(const TArray<FPlaytimeScheduleEntryData> UpdatedScheduleEntries); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortPlaytimeScheduleWidget) == 0x2b0, "Size mismatch for UFortPlaytimeScheduleWidget");

// Size: 0x1c0 (Inherited: 0x1e0, Single: 0xffffffe0)
class UFortPlaytimeReportSettingRegistry : public UFortSettingRegistry
{
public:
    UFortSettingCollection* PlaytimeReportSettings; // 0x1b8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortPlaytimeReportSettingRegistry) == 0x1c0, "Size mismatch for UFortPlaytimeReportSettingRegistry");
static_assert(offsetof(UFortPlaytimeReportSettingRegistry, PlaytimeReportSettings) == 0x1b8, "Offset mismatch for UFortPlaytimeReportSettingRegistry::PlaytimeReportSettings");

// Size: 0x1d0 (Inherited: 0x1e0, Single: 0xfffffff0)
class UFortPlaytimeSettingRegistry : public UFortSettingRegistry
{
public:
    UFortSettingCollection* PlaytimeSettings; // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1c0[0x10]; // 0x1c0 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFortPlaytimeSettingRegistry) == 0x1d0, "Size mismatch for UFortPlaytimeSettingRegistry");
static_assert(offsetof(UFortPlaytimeSettingRegistry, PlaytimeSettings) == 0x1b8, "Offset mismatch for UFortPlaytimeSettingRegistry::PlaytimeSettings");

// Size: 0x1c0 (Inherited: 0x1e0, Single: 0xffffffe0)
class UFortPlaytimeScheduleSettingRegistry : public UFortSettingRegistry
{
public:
    UFortSettingCollection* PlaytimeScheduleSettings; // 0x1b8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortPlaytimeScheduleSettingRegistry) == 0x1c0, "Size mismatch for UFortPlaytimeScheduleSettingRegistry");
static_assert(offsetof(UFortPlaytimeScheduleSettingRegistry, PlaytimeScheduleSettings) == 0x1b8, "Offset mismatch for UFortPlaytimeScheduleSettingRegistry::PlaytimeScheduleSettings");

// Size: 0x1f8 (Inherited: 0x570, Single: 0xfffffc88)
class UFortSettingValueDiscreteSupervisedScheduleToggle : public UFortSettingValueDiscrete
{
public:
};

static_assert(sizeof(UFortSettingValueDiscreteSupervisedScheduleToggle) == 0x1f8, "Size mismatch for UFortSettingValueDiscreteSupervisedScheduleToggle");

// Size: 0x410 (Inherited: 0xb38, Single: 0xfffff8d8)
class UFortTimeLimitPanelStw : public UCommonActivatableWidget
{
public:
    UCommonActivatableWidget* ViewTimeLimitPanel; // 0x408 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortTimeLimitPanelStw) == 0x410, "Size mismatch for UFortTimeLimitPanelStw");
static_assert(offsetof(UFortTimeLimitPanelStw, ViewTimeLimitPanel) == 0x408, "Offset mismatch for UFortTimeLimitPanelStw::ViewTimeLimitPanel");

// Size: 0x408 (Inherited: 0xb38, Single: 0xfffff8d0)
class UFortViewTimeLimitPanel : public UCommonActivatableWidget
{
public:

public:
    virtual void OnSidebarVisibilityChanged(bool& bIsVisible); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFortViewTimeLimitPanel) == 0x408, "Size mismatch for UFortViewTimeLimitPanel");

// Size: 0xc8 (Inherited: 0x100, Single: 0xffffffc8)
class UPlayerPlaytimeVM : public UFortPerUserViewModel
{
public:
    uint8_t Pad_70[0x30]; // 0x70 (Size: 0x30, Type: PaddingProperty)
    float ElapsedSleepTime; // 0xa0 (Size: 0x4, Type: FloatProperty)
    uint8_t PlayState; // 0xa4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a5[0x3]; // 0xa5 (Size: 0x3, Type: PaddingProperty)
    uint8_t BP_OnGrantPlaytimeRequestStatusUpdate[0x10]; // 0xa8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t BP_OnRequestAdditionalPlaytimeStatusUpdate[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void CloseGame(); // 0x11020d58 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    FText ConvertServiceTimeToLocalTimeText(const FDateTime ServiceTime) const; // 0x3c093cc (Index: 0x1, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    TArray<int32_t> GetGrantPlaytimeDurations() const; // 0x11020dec (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetNextPlayPeriodText() const; // 0x11020e2c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FPlaytimeWindow GetNextWindowBounds() const; // 0x11020e68 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetPlaytimeAddResultText(const FTimespan AddedTime) const; // 0x11020ea4 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    EPlaytimeActiveScheduling GetPlaytimeScheduling() const; // 0x5ad8984 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetPlaytimeSummaryText() const; // 0x11020fb0 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FTimespan GetRemainingPlaytime() const; // 0x328576c (Index: 0x8, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTimespan GetTimePlayed() const; // 0x3285a0c (Index: 0x9, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FPlaytimeWindow GetWindowBounds() const; // 0x5e451c8 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GrantAdditionalPlaytime(FString& UserPin, int32_t& const SecondsToGrant); // 0x11021074 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    bool HasNextWindowBounds() const; // 0x11021584 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasWindowBounds() const; // 0x6059dc8 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void Init(); // 0x315dd78 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    bool IsAskForMoreTimeBlocked() const; // 0x5a4e5b8 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsAskForMoreTimeEnabled() const; // 0x324fba0 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPlaytimeLimitsEnabled() const; // 0x59297f0 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsReportingPlaytime() const; // 0x5b37eb8 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnGrantPlaytimeRequestStatusUpdate__DelegateSignature(EPlaytimeRequestState& RequestStatus); // 0x288a61c (Index: 0x14, Flags: MulticastDelegate|Public|Delegate)
    void OnRequestAdditionalPlaytimeStatusUpdate__DelegateSignature(EPlaytimeRequestState& RequestStatus); // 0x288a61c (Index: 0x15, Flags: MulticastDelegate|Public|Delegate)
    void OpenParentalControlsSchedule(); // 0x554e3c4 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void OpenPinTimeGrant(UUserWidget*& Context); // 0x110215d8 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void RequestAdditionalPlaytime(); // 0x11021794 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void SetListenToRefresh(bool& const bListenToRefresh); // 0x5b32570 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)

private:
    void HandlePlaytimeStateChanged(EPlaytimeState& NewState); // 0x11021444 (Index: 0xc, Flags: Final|Native|Private)
};

static_assert(sizeof(UPlayerPlaytimeVM) == 0xc8, "Size mismatch for UPlayerPlaytimeVM");
static_assert(offsetof(UPlayerPlaytimeVM, ElapsedSleepTime) == 0xa0, "Offset mismatch for UPlayerPlaytimeVM::ElapsedSleepTime");
static_assert(offsetof(UPlayerPlaytimeVM, PlayState) == 0xa4, "Offset mismatch for UPlayerPlaytimeVM::PlayState");
static_assert(offsetof(UPlayerPlaytimeVM, BP_OnGrantPlaytimeRequestStatusUpdate) == 0xa8, "Offset mismatch for UPlayerPlaytimeVM::BP_OnGrantPlaytimeRequestStatusUpdate");
static_assert(offsetof(UPlayerPlaytimeVM, BP_OnRequestAdditionalPlaytimeStatusUpdate) == 0xb8, "Offset mismatch for UPlayerPlaytimeVM::BP_OnRequestAdditionalPlaytimeStatusUpdate");

// Size: 0x5c8 (Inherited: 0x15c8, Single: 0xfffff000)
class UTimeReportsManagementScreen : public UFortPinScreen
{
public:
    UFortSettingsPanel* Panel_TimeReportSettings; // 0x550 (Size: 0x8, Type: ObjectProperty)
    UFortSettingDetailView* Details_Settings; // 0x558 (Size: 0x8, Type: ObjectProperty)
    UFortPlaytimeReportSettingRegistry* PlaytimeReportSettingRegistry; // 0x560 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_568[0x60]; // 0x568 (Size: 0x60, Type: PaddingProperty)

public:
    void ExitScreen(); // 0x11020da8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UTimeReportsManagementScreen) == 0x5c8, "Size mismatch for UTimeReportsManagementScreen");
static_assert(offsetof(UTimeReportsManagementScreen, Panel_TimeReportSettings) == 0x550, "Offset mismatch for UTimeReportsManagementScreen::Panel_TimeReportSettings");
static_assert(offsetof(UTimeReportsManagementScreen, Details_Settings) == 0x558, "Offset mismatch for UTimeReportsManagementScreen::Details_Settings");
static_assert(offsetof(UTimeReportsManagementScreen, PlaytimeReportSettingRegistry) == 0x560, "Offset mismatch for UTimeReportsManagementScreen::PlaytimeReportSettingRegistry");

// Size: 0x408 (Inherited: 0xb38, Single: 0xfffff8d0)
class UFortPlaytimePinActivatableWidget : public UCommonActivatableWidget
{
public:

public:
    virtual void OnUserPinProvided(FString& UserPin); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UFortPlaytimePinActivatableWidget) == 0x408, "Size mismatch for UFortPlaytimePinActivatableWidget");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FPlaytimeScheduleEntryData
{
    FText DayText; // 0x0 (Size: 0x10, Type: TextProperty)
    FText AllowedTimeText; // 0x10 (Size: 0x10, Type: TextProperty)
    TArray<FText> TimeWindowTexts; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FPlaytimeScheduleEntryData) == 0x30, "Size mismatch for FPlaytimeScheduleEntryData");
static_assert(offsetof(FPlaytimeScheduleEntryData, DayText) == 0x0, "Offset mismatch for FPlaytimeScheduleEntryData::DayText");
static_assert(offsetof(FPlaytimeScheduleEntryData, AllowedTimeText) == 0x10, "Offset mismatch for FPlaytimeScheduleEntryData::AllowedTimeText");
static_assert(offsetof(FPlaytimeScheduleEntryData, TimeWindowTexts) == 0x20, "Offset mismatch for FPlaytimeScheduleEntryData::TimeWindowTexts");

