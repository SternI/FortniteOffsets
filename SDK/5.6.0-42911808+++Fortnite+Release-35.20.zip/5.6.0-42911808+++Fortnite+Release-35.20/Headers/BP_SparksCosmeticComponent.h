/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_SparksCosmeticComponent
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "SparksCoreCosmeticsRuntime.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayEventRouter.h"
#include "UMG.h"

// Size: 0x500 (Inherited: 0x718, Single: 0xfffffde8)
class UBP_SparksCosmeticComponent_C : public USparksCosmeticComponent
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x4c8 (Size: 0x8, Type: StructProperty)
    UGameplayEventRouterComponent* Event_Router; // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    UUserWidget* DebugWidget; // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    TSoftClassPtr DebugWidgetSoftClass; // 0x4e0 (Size: 0x20, Type: SoftClassProperty)

public:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void Debug_BP_ShowCosmeticPicker(bool& bShow); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UBP_SparksCosmeticComponent_C) == 0x500, "Size mismatch for UBP_SparksCosmeticComponent_C");
static_assert(offsetof(UBP_SparksCosmeticComponent_C, UberGraphFrame) == 0x4c8, "Offset mismatch for UBP_SparksCosmeticComponent_C::UberGraphFrame");
static_assert(offsetof(UBP_SparksCosmeticComponent_C, Event_Router) == 0x4d0, "Offset mismatch for UBP_SparksCosmeticComponent_C::Event_Router");
static_assert(offsetof(UBP_SparksCosmeticComponent_C, DebugWidget) == 0x4d8, "Offset mismatch for UBP_SparksCosmeticComponent_C::DebugWidget");
static_assert(offsetof(UBP_SparksCosmeticComponent_C, DebugWidgetSoftClass) == 0x4e0, "Offset mismatch for UBP_SparksCosmeticComponent_C::DebugWidgetSoftClass");

