/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Abilities
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "GameplayAbilities.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "FortniteGameFramework.h"
#include "Athena.h"
#include "_Verse.h"
#include "EngineCameras.h"
#include "Blueprints.h"
#include "GameplayEffectTemplates.h"
#include "RidingCodeRuntime.h"
#include "UMG.h"
#include "GameplayTags.h"
#include "MotionWarping.h"
#include "Niagara.h"
#include "Characters.h"
#include "AnimGraphRuntime.h"

// Size: 0x1b9 (Inherited: 0x1, Single: 0x1b8)
struct FAnimBlueprintGeneratedMutableData : FAnimBlueprintMutableData
{
    bool __BoolProperty; // 0x1 (Size: 0x1, Type: BoolProperty)
    bool __BoolProperty_0; // 0x2 (Size: 0x1, Type: BoolProperty)
    float __FloatProperty_1; // 0x4 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_2; // 0x8 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_3; // 0xc (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_4; // 0x10 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_5; // 0x14 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_6; // 0x18 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_7; // 0x19 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_8; // 0x1a (Size: 0x1, Type: ByteProperty)
    float __FloatProperty_9; // 0x1c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_10; // 0x20 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_11; // 0x24 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_12; // 0x28 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_13; // 0x2c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_14; // 0x30 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_15; // 0x34 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_16; // 0x38 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_17; // 0x3c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_18; // 0x40 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_19; // 0x44 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_20; // 0x45 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_21; // 0x46 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_22; // 0x47 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_23; // 0x48 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_24; // 0x49 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_4a[0x2]; // 0x4a (Size: 0x2, Type: PaddingProperty)
    float __FloatProperty_25; // 0x4c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_26; // 0x50 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_27; // 0x54 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_28; // 0x58 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_29; // 0x5c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_30; // 0x60 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_31; // 0x64 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_32; // 0x65 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_33; // 0x66 (Size: 0x1, Type: ByteProperty)
    float __FloatProperty_34; // 0x68 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_35; // 0x6c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_36; // 0x70 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_37; // 0x74 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_38; // 0x78 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_39; // 0x7c (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_40; // 0x7d (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_7e[0x2]; // 0x7e (Size: 0x2, Type: PaddingProperty)
    float __FloatProperty_41; // 0x80 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_42; // 0x84 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_85[0x3]; // 0x85 (Size: 0x3, Type: PaddingProperty)
    float __FloatProperty_43; // 0x88 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_44; // 0x8c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_45; // 0x90 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_46; // 0x94 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_47; // 0x98 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_48; // 0x9c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_49; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_50; // 0xa4 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_51; // 0xa8 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_52; // 0xac (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_53; // 0xb0 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_54; // 0xb4 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_55; // 0xb8 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_56; // 0xbc (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_bd[0x3]; // 0xbd (Size: 0x3, Type: PaddingProperty)
    float __FloatProperty_57; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_58; // 0xc4 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_59; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_60; // 0xcc (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_61; // 0xd0 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_62; // 0xd1 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_63; // 0xd2 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_64; // 0xd3 (Size: 0x1, Type: ByteProperty)
    float __FloatProperty_65; // 0xd4 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_66; // 0xd8 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_67; // 0xdc (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_68; // 0xe0 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_69; // 0xe4 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_70; // 0xe8 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_71; // 0xe9 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_72; // 0xea (Size: 0x1, Type: ByteProperty)
    float __FloatProperty_73; // 0xec (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_74; // 0xf0 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_75; // 0xf4 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_76; // 0xf8 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_77; // 0xfc (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_78; // 0x100 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_79; // 0x101 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_80; // 0x102 (Size: 0x1, Type: ByteProperty)
    float __FloatProperty_81; // 0x104 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_82; // 0x108 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_83; // 0x10c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_84; // 0x110 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_85; // 0x114 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_86; // 0x118 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_87; // 0x11c (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_88; // 0x11d (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_11e[0x2]; // 0x11e (Size: 0x2, Type: PaddingProperty)
    float __FloatProperty_89; // 0x120 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_90; // 0x124 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_125[0x3]; // 0x125 (Size: 0x3, Type: PaddingProperty)
    float __FloatProperty_91; // 0x128 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_92; // 0x12c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_93; // 0x130 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_94; // 0x134 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_95; // 0x138 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_96; // 0x13c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_97; // 0x140 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_98; // 0x144 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_99; // 0x148 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_100; // 0x149 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_101; // 0x14a (Size: 0x1, Type: ByteProperty)
    float __FloatProperty_102; // 0x14c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_103; // 0x150 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_104; // 0x154 (Size: 0x4, Type: FloatProperty)
    bool __BoolProperty_105; // 0x158 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_159[0x3]; // 0x159 (Size: 0x3, Type: PaddingProperty)
    float __FloatProperty_106; // 0x15c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_107; // 0x160 (Size: 0x4, Type: FloatProperty)
    int32_t __IntProperty_108; // 0x164 (Size: 0x4, Type: IntProperty)
    int32_t __IntProperty_109; // 0x168 (Size: 0x4, Type: IntProperty)
    float __FloatProperty_110; // 0x16c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_111; // 0x170 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_112; // 0x174 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_113; // 0x178 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_114; // 0x17c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_115; // 0x180 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_116; // 0x184 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_117; // 0x188 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_118; // 0x18c (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_119; // 0x18d (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_18e[0x2]; // 0x18e (Size: 0x2, Type: PaddingProperty)
    int32_t __IntProperty_120; // 0x190 (Size: 0x4, Type: IntProperty)
    int32_t __IntProperty_121; // 0x194 (Size: 0x4, Type: IntProperty)
    float __FloatProperty_122; // 0x198 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_123; // 0x19c (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_124; // 0x1a0 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_125; // 0x1a4 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_126; // 0x1a8 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_127; // 0x1ac (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_128; // 0x1b0 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_129; // 0x1b4 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_130; // 0x1b8 (Size: 0x1, Type: ByteProperty)
};

static_assert(sizeof(FAnimBlueprintGeneratedMutableData) == 0x1b9, "Size mismatch for FAnimBlueprintGeneratedMutableData");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __BoolProperty) == 0x1, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__BoolProperty");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __BoolProperty_0) == 0x2, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__BoolProperty_0");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_1) == 0x4, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_1");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_2) == 0x8, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_2");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_3) == 0xc, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_3");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_4) == 0x10, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_4");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_5) == 0x14, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_5");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_6) == 0x18, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_6");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_7) == 0x19, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_7");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_8) == 0x1a, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_8");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_9) == 0x1c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_9");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_10) == 0x20, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_10");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_11) == 0x24, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_11");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_12) == 0x28, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_12");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_13) == 0x2c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_13");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_14) == 0x30, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_14");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_15) == 0x34, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_15");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_16) == 0x38, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_16");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_17) == 0x3c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_17");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_18) == 0x40, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_18");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_19) == 0x44, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_19");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_20) == 0x45, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_20");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_21) == 0x46, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_21");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_22) == 0x47, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_22");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_23) == 0x48, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_23");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_24) == 0x49, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_24");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_25) == 0x4c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_25");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_26) == 0x50, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_26");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_27) == 0x54, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_27");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_28) == 0x58, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_28");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_29) == 0x5c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_29");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_30) == 0x60, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_30");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_31) == 0x64, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_31");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_32) == 0x65, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_32");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_33) == 0x66, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_33");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_34) == 0x68, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_34");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_35) == 0x6c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_35");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_36) == 0x70, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_36");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_37) == 0x74, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_37");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_38) == 0x78, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_38");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_39) == 0x7c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_39");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_40) == 0x7d, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_40");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_41) == 0x80, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_41");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_42) == 0x84, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_42");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_43) == 0x88, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_43");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_44) == 0x8c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_44");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_45) == 0x90, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_45");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_46) == 0x94, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_46");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_47) == 0x98, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_47");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_48) == 0x9c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_48");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_49) == 0xa0, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_49");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_50) == 0xa4, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_50");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_51) == 0xa8, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_51");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_52) == 0xac, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_52");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_53) == 0xb0, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_53");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_54) == 0xb4, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_54");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_55) == 0xb8, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_55");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_56) == 0xbc, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_56");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_57) == 0xc0, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_57");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_58) == 0xc4, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_58");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_59) == 0xc8, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_59");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_60) == 0xcc, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_60");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_61) == 0xd0, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_61");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_62) == 0xd1, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_62");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_63) == 0xd2, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_63");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_64) == 0xd3, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_64");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_65) == 0xd4, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_65");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_66) == 0xd8, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_66");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_67) == 0xdc, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_67");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_68) == 0xe0, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_68");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_69) == 0xe4, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_69");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_70) == 0xe8, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_70");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_71) == 0xe9, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_71");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_72) == 0xea, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_72");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_73) == 0xec, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_73");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_74) == 0xf0, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_74");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_75) == 0xf4, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_75");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_76) == 0xf8, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_76");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_77) == 0xfc, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_77");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_78) == 0x100, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_78");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_79) == 0x101, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_79");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_80) == 0x102, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_80");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_81) == 0x104, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_81");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_82) == 0x108, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_82");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_83) == 0x10c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_83");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_84) == 0x110, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_84");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_85) == 0x114, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_85");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_86) == 0x118, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_86");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_87) == 0x11c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_87");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_88) == 0x11d, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_88");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_89) == 0x120, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_89");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_90) == 0x124, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_90");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_91) == 0x128, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_91");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_92) == 0x12c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_92");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_93) == 0x130, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_93");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_94) == 0x134, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_94");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_95) == 0x138, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_95");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_96) == 0x13c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_96");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_97) == 0x140, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_97");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_98) == 0x144, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_98");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_99) == 0x148, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_99");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_100) == 0x149, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_100");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_101) == 0x14a, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_101");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_102) == 0x14c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_102");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_103) == 0x150, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_103");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_104) == 0x154, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_104");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __BoolProperty_105) == 0x158, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__BoolProperty_105");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_106) == 0x15c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_106");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_107) == 0x160, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_107");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __IntProperty_108) == 0x164, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__IntProperty_108");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __IntProperty_109) == 0x168, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__IntProperty_109");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_110) == 0x16c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_110");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_111) == 0x170, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_111");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_112) == 0x174, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_112");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_113) == 0x178, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_113");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_114) == 0x17c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_114");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_115) == 0x180, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_115");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_116) == 0x184, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_116");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_117) == 0x188, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_117");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_118) == 0x18c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_118");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_119) == 0x18d, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_119");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __IntProperty_120) == 0x190, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__IntProperty_120");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __IntProperty_121) == 0x194, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__IntProperty_121");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_122) == 0x198, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_122");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_123) == 0x19c, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_123");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_124) == 0x1a0, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_124");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_125) == 0x1a4, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_125");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_126) == 0x1a8, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_126");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_127) == 0x1ac, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_127");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_128) == 0x1b0, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_128");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __FloatProperty_129) == 0x1b4, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__FloatProperty_129");
static_assert(offsetof(FAnimBlueprintGeneratedMutableData, __ByteProperty_130) == 0x1b8, "Offset mismatch for FAnimBlueprintGeneratedMutableData::__ByteProperty_130");

// Size: 0x2ae0 (Inherited: 0x1, Single: 0x2adf)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData
{
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FName __NameProperty_1801; // 0x4 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1802; // 0x8 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1803; // 0xc (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1804; // 0x10 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1805; // 0x14 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1806; // 0x18 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1807; // 0x1c (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1808; // 0x20 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1809; // 0x24 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1810; // 0x28 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1811; // 0x2c (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1812; // 0x30 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1813; // 0x34 (Size: 0x4, Type: NameProperty)
    TEnumAsByte<EAnimGroupRole> __ByteProperty_1814; // 0x38 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    FName __NameProperty_1815; // 0x3c (Size: 0x4, Type: NameProperty)
    uint8_t __EnumProperty_1816; // 0x40 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EAnimGroupRole> __ByteProperty_1817; // 0x41 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_42[0x2]; // 0x42 (Size: 0x2, Type: PaddingProperty)
    FName __NameProperty_1818; // 0x44 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1819; // 0x48 (Size: 0x4, Type: NameProperty)
    TArray<float> __ArrayProperty_1820; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> __ArrayProperty_1821; // 0x60 (Size: 0x10, Type: ArrayProperty)
    FName __NameProperty_1822; // 0x70 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1823; // 0x74 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1824; // 0x78 (Size: 0x4, Type: NameProperty)
    TArray<float> __ArrayProperty_1825; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> __ArrayProperty_1826; // 0x90 (Size: 0x10, Type: ArrayProperty)
    FName __NameProperty_1827; // 0xa0 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1828; // 0xa4 (Size: 0x4, Type: NameProperty)
    int32_t __IntProperty_1829; // 0xa8 (Size: 0x4, Type: IntProperty)
    uint8_t __EnumProperty_1830; // 0xac (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_ad[0x3]; // 0xad (Size: 0x3, Type: PaddingProperty)
    TArray<float> __ArrayProperty_1831; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    UBlendProfile* __BlendProfile_1832; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* __CurveFloat_1833; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    uint8_t __EnumProperty_1834; // 0xd0 (Size: 0x1, Type: EnumProperty)
    uint8_t __EnumProperty_1835; // 0xd1 (Size: 0x1, Type: EnumProperty)
    uint8_t __EnumProperty_1836; // 0xd2 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d3[0x5]; // 0xd3 (Size: 0x5, Type: PaddingProperty)
    TArray<float> __ArrayProperty_1837; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> __ArrayProperty_1838; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    FName __NameProperty_1839; // 0xf8 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1840; // 0xfc (Size: 0x4, Type: NameProperty)
    int32_t __IntProperty_1841; // 0x100 (Size: 0x4, Type: IntProperty)
    FName __NameProperty_1842; // 0x104 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1843; // 0x108 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1844; // 0x10c (Size: 0x4, Type: NameProperty)
    bool __BoolProperty_1845; // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_111[0x3]; // 0x111 (Size: 0x3, Type: PaddingProperty)
    float __FloatProperty_1846; // 0x114 (Size: 0x4, Type: FloatProperty)
    FInputScaleBiasClampConstants __StructProperty_1847; // 0x118 (Size: 0x2c, Type: StructProperty)
    float __FloatProperty_1848; // 0x144 (Size: 0x4, Type: FloatProperty)
    uint8_t __EnumProperty_1849; // 0x148 (Size: 0x1, Type: EnumProperty)
    bool __BoolProperty_1850; // 0x149 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EAnimGroupRole> __ByteProperty_1851; // 0x14a (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_14b[0x1]; // 0x14b (Size: 0x1, Type: PaddingProperty)
    FName __NameProperty_1852; // 0x14c (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1853; // 0x150 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1854; // 0x154 (Size: 0x4, Type: NameProperty)
    FAnimNodeFunctionRef __StructProperty_1855; // 0x158 (Size: 0x18, Type: StructProperty)
    FName __NameProperty_1856; // 0x170 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1857; // 0x174 (Size: 0x4, Type: NameProperty)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0x178 (Size: 0x80, Type: StructProperty)
    FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0x1f8 (Size: 0x40, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_16; // 0x238 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_14; // 0x240 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_15; // 0x270 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_16; // 0x278 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_13; // 0x2a8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_14; // 0x2d8 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_12; // 0x2e0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_11; // 0x310 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_13; // 0x340 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_10; // 0x348 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_12; // 0x378 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_11; // 0x380 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_9; // 0x388 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_10; // 0x3b8 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_8; // 0x3c0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_9; // 0x3f0 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_8; // 0x3f8 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_7; // 0x400 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_7; // 0x430 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_6; // 0x438 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_6; // 0x468 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_5; // 0x470 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_5; // 0x4a0 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Slot; // 0x4a8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_2; // 0x4d8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_1; // 0x508 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose_3; // 0x538 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_2; // 0x568 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_56; // 0x598 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_55; // 0x5c8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_54; // 0x5f8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_53; // 0x628 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_52; // 0x658 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_34; // 0x688 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_33; // 0x6b8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_32; // 0x6e8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_16; // 0x718 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_13; // 0x748 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_51; // 0x778 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_50; // 0x7a8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_49; // 0x7d8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_48; // 0x808 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_47; // 0x838 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_46; // 0x868 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_45; // 0x898 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_44; // 0x8c8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_43; // 0x8f8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_42; // 0x928 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TwoWayBlend; // 0x958 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_31; // 0x988 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_30; // 0x9b8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_29; // 0x9e8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_28; // 0xa18 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_27; // 0xa48 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_26; // 0xa78 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_15; // 0xaa8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_12; // 0xad8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_15; // 0xb08 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_14; // 0xb38 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_41; // 0xb68 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_14; // 0xb98 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_40; // 0xbc8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_39; // 0xbf8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_38; // 0xc28 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_37; // 0xc58 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_25; // 0xc88 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_24; // 0xcb8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_23; // 0xce8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_36; // 0xd18 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_13; // 0xd48 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_11; // 0xd78 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_35; // 0xda8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_34; // 0xdd8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_33; // 0xe08 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_32; // 0xe38 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_22; // 0xe68 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_21; // 0xe98 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_31; // 0xec8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_20; // 0xef8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_12; // 0xf28 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_10; // 0xf58 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_13; // 0xf88 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_30; // 0xfb8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_12; // 0xfe8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_11; // 0x1018 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_9; // 0x1048 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_11; // 0x1078 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_1; // 0x10a8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_29; // 0x10d8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_10; // 0x1108 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_8; // 0x1138 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_10; // 0x1168 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_9; // 0x1198 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_15; // 0x11c8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_8; // 0x11f8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_28; // 0x1228 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_7; // 0x1258 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_27; // 0x1288 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_26; // 0x12b8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_9; // 0x12e8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_6; // 0x1318 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_25; // 0x1348 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_24; // 0x1378 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_19; // 0x13a8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_5; // 0x13d8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_23; // 0x1408 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_22; // 0x1438 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_8; // 0x1468 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_7; // 0x1498 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_14; // 0x14c8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_13; // 0x14f8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_12; // 0x1528 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_11; // 0x1558 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_10; // 0x1588 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_18; // 0x15b8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_17; // 0x15e8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_16; // 0x1618 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_7; // 0x1648 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_6; // 0x1678 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_15; // 0x16a8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult; // 0x16d8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_21; // 0x1708 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_20; // 0x1738 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_19; // 0x1768 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_18; // 0x1798 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_17; // 0x17c8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_14; // 0x17f8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_13; // 0x1828 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_12; // 0x1858 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_6; // 0x1888 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_5; // 0x18b8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_16; // 0x18e8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_15; // 0x1918 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_14; // 0x1948 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_13; // 0x1978 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_12; // 0x19a8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_11; // 0x19d8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_10; // 0x1a08 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_9; // 0x1a38 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_5; // 0x1a68 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_4; // 0x1a98 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_4; // 0x1ac8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_3; // 0x1af8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_11; // 0x1b28 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_4; // 0x1b58 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_10; // 0x1b88 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_9; // 0x1bb8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_8; // 0x1be8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_7; // 0x1c18 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_8; // 0x1c48 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_7; // 0x1c78 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_6; // 0x1ca8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_6; // 0x1cd8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_3; // 0x1d08 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_3; // 0x1d38 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_5; // 0x1d68 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_4; // 0x1d98 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_3; // 0x1dc8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_2; // 0x1df8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_5; // 0x1e28 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_4; // 0x1e58 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_3; // 0x1e88 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_1; // 0x1eb8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_2; // 0x1ee8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_2; // 0x1f18 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_2; // 0x1f48 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer; // 0x1f78 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_1; // 0x1fa8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_1; // 0x1fd8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_1; // 0x2008 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose_2; // 0x2038 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose_1; // 0x2068 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_4; // 0x2098 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_3; // 0x20c8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool; // 0x20f8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_2; // 0x2128 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_1; // 0x2158 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_9; // 0x2188 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByInt_3; // 0x21b8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByInt_2; // 0x21e8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_8; // 0x2218 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_7; // 0x2248 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_6; // 0x2278 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_5; // 0x22a8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_2; // 0x22d8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_1; // 0x2308 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByInt_1; // 0x2338 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByInt; // 0x2368 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_4; // 0x2398 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_3; // 0x23c8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_2; // 0x23f8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_1; // 0x2428 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum; // 0x2458 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult; // 0x2488 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine; // 0x24b8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_4; // 0x24e8 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_4; // 0x2518 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ComponentToLocalSpace; // 0x2520 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LegIK_2; // 0x2550 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_3; // 0x2580 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LegIK_1; // 0x25b0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_11; // 0x25e0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_10; // 0x2610 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_9; // 0x2640 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LegIK; // 0x2670 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_8; // 0x26a0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_7; // 0x26d0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_6; // 0x2700 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_2; // 0x2730 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_5; // 0x2760 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_3; // 0x2790 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_4; // 0x27c0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone_1; // 0x27f0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ModifyBone; // 0x2820 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_3; // 0x2850 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LocalToComponentSpace; // 0x2880 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_2; // 0x28b0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose; // 0x28e0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose; // 0x2910 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone_1; // 0x2940 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Inertialization; // 0x2970 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer; // 0x29a0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive; // 0x29d0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_CopyBone; // 0x2a00 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_2; // 0x2a30 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_3; // 0x2a60 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_2; // 0x2a68 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_1; // 0x2a70 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_1; // 0x2aa0 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose; // 0x2aa8 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root; // 0x2ab0 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FAnimBlueprintGeneratedConstantData) == 0x2ae0, "Size mismatch for FAnimBlueprintGeneratedConstantData");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1801) == 0x4, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1801");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1802) == 0x8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1802");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1803) == 0xc, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1803");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1804) == 0x10, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1804");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1805) == 0x14, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1805");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1806) == 0x18, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1806");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1807) == 0x1c, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1807");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1808) == 0x20, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1808");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1809) == 0x24, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1809");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1810) == 0x28, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1810");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1811) == 0x2c, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1811");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1812) == 0x30, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1812");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1813) == 0x34, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1813");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __ByteProperty_1814) == 0x38, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__ByteProperty_1814");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1815) == 0x3c, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1815");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __EnumProperty_1816) == 0x40, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__EnumProperty_1816");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __ByteProperty_1817) == 0x41, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__ByteProperty_1817");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1818) == 0x44, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1818");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1819) == 0x48, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1819");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __ArrayProperty_1820) == 0x50, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__ArrayProperty_1820");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __ArrayProperty_1821) == 0x60, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__ArrayProperty_1821");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1822) == 0x70, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1822");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1823) == 0x74, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1823");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1824) == 0x78, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1824");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __ArrayProperty_1825) == 0x80, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__ArrayProperty_1825");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __ArrayProperty_1826) == 0x90, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__ArrayProperty_1826");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1827) == 0xa0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1827");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1828) == 0xa4, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1828");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __IntProperty_1829) == 0xa8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__IntProperty_1829");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __EnumProperty_1830) == 0xac, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__EnumProperty_1830");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __ArrayProperty_1831) == 0xb0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__ArrayProperty_1831");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __BlendProfile_1832) == 0xc0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__BlendProfile_1832");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __CurveFloat_1833) == 0xc8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__CurveFloat_1833");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __EnumProperty_1834) == 0xd0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__EnumProperty_1834");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __EnumProperty_1835) == 0xd1, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__EnumProperty_1835");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __EnumProperty_1836) == 0xd2, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__EnumProperty_1836");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __ArrayProperty_1837) == 0xd8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__ArrayProperty_1837");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __ArrayProperty_1838) == 0xe8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__ArrayProperty_1838");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1839) == 0xf8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1839");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1840) == 0xfc, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1840");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __IntProperty_1841) == 0x100, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__IntProperty_1841");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1842) == 0x104, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1842");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1843) == 0x108, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1843");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1844) == 0x10c, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1844");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __BoolProperty_1845) == 0x110, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__BoolProperty_1845");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __FloatProperty_1846) == 0x114, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__FloatProperty_1846");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __StructProperty_1847) == 0x118, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__StructProperty_1847");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __FloatProperty_1848) == 0x144, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__FloatProperty_1848");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __EnumProperty_1849) == 0x148, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__EnumProperty_1849");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __BoolProperty_1850) == 0x149, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__BoolProperty_1850");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __ByteProperty_1851) == 0x14a, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__ByteProperty_1851");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1852) == 0x14c, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1852");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1853) == 0x150, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1853");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1854) == 0x154, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1854");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __StructProperty_1855) == 0x158, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__StructProperty_1855");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1856) == 0x170, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1856");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, __NameProperty_1857) == 0x174, "Offset mismatch for FAnimBlueprintGeneratedConstantData::__NameProperty_1857");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimBlueprintExtension_PropertyAccess) == 0x178, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimBlueprintExtension_PropertyAccess");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimBlueprintExtension_Base) == 0x1f8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimBlueprintExtension_Base");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_16) == 0x238, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_16");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_14) == 0x240, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_14");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_15) == 0x270, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_15");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_16) == 0x278, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_16");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_13) == 0x2a8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_13");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_14) == 0x2d8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_14");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_12) == 0x2e0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_12");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_11) == 0x310, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_11");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_13) == 0x340, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_13");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_10) == 0x348, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_10");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_12) == 0x378, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_12");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_11) == 0x380, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_11");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_9) == 0x388, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_9");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_10) == 0x3b8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_10");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_8) == 0x3c0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_8");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_9) == 0x3f0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_9");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_8) == 0x3f8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_8");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_7) == 0x400, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_7");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_7) == 0x430, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_7");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_6) == 0x438, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_6");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_6) == 0x468, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_6");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_5) == 0x470, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_5");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_5) == 0x4a0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_5");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Slot) == 0x4a8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Slot");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByBool_2) == 0x4d8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByBool_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByBool_1) == 0x508, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByBool_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SaveCachedPose_3) == 0x538, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SaveCachedPose_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_TransitionResult_2) == 0x568, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_TransitionResult_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_56) == 0x598, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_56");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_55) == 0x5c8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_55");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_54) == 0x5f8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_54");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_53) == 0x628, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_53");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_52) == 0x658, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_52");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_34) == 0x688, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_34");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_33) == 0x6b8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_33");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_32) == 0x6e8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_32");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_16) == 0x718, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_16");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_13) == 0x748, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_13");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_51) == 0x778, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_51");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_50) == 0x7a8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_50");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_49) == 0x7d8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_49");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_48) == 0x808, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_48");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_47) == 0x838, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_47");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_46) == 0x868, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_46");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_45) == 0x898, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_45");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_44) == 0x8c8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_44");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_43) == 0x8f8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_43");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_42) == 0x928, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_42");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_TwoWayBlend) == 0x958, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_TwoWayBlend");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_31) == 0x988, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_31");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_30) == 0x9b8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_30");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_29) == 0x9e8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_29");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_28) == 0xa18, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_28");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_27) == 0xa48, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_27");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_26) == 0xa78, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_26");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_15) == 0xaa8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_15");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_12) == 0xad8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_12");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_15) == 0xb08, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_15");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_14) == 0xb38, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_14");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_41) == 0xb68, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_41");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_14) == 0xb98, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_14");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_40) == 0xbc8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_40");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_39) == 0xbf8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_39");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_38) == 0xc28, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_38");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_37) == 0xc58, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_37");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_25) == 0xc88, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_25");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_24) == 0xcb8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_24");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_23) == 0xce8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_23");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_36) == 0xd18, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_36");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_13) == 0xd48, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_13");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_11) == 0xd78, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_11");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_35) == 0xda8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_35");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_34) == 0xdd8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_34");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_33) == 0xe08, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_33");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_32) == 0xe38, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_32");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_22) == 0xe68, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_22");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_21) == 0xe98, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_21");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_31) == 0xec8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_31");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_20) == 0xef8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_20");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_12) == 0xf28, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_12");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_10) == 0xf58, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_10");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_13) == 0xf88, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_13");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_30) == 0xfb8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_30");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_12) == 0xfe8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_12");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_11) == 0x1018, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_11");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_9) == 0x1048, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_9");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_11) == 0x1078, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_11");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_TransitionResult_1) == 0x10a8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_TransitionResult_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_29) == 0x10d8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_29");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_10) == 0x1108, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_10");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_8) == 0x1138, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_8");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_10) == 0x1168, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_10");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_9) == 0x1198, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_9");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_15) == 0x11c8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_15");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_8) == 0x11f8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_8");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_28) == 0x1228, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_28");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_7) == 0x1258, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_7");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_27) == 0x1288, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_27");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_26) == 0x12b8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_26");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_9) == 0x12e8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_9");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_6) == 0x1318, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_6");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_25) == 0x1348, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_25");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_24) == 0x1378, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_24");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_19) == 0x13a8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_19");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_5) == 0x13d8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_5");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_23) == 0x1408, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_23");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_22) == 0x1438, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_22");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_8) == 0x1468, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_8");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_7) == 0x1498, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_7");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_14) == 0x14c8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_14");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_13) == 0x14f8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_13");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_12) == 0x1528, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_12");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_11) == 0x1558, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_11");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_10) == 0x1588, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_10");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_18) == 0x15b8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_18");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_17) == 0x15e8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_17");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_16) == 0x1618, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_16");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_7) == 0x1648, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_7");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_6) == 0x1678, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_6");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_15) == 0x16a8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_15");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_TransitionResult) == 0x16d8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_TransitionResult");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_21) == 0x1708, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_21");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_20) == 0x1738, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_20");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_19) == 0x1768, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_19");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_18) == 0x1798, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_18");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_17) == 0x17c8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_17");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_14) == 0x17f8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_14");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_13) == 0x1828, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_13");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_12) == 0x1858, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_12");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_6) == 0x1888, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_6");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_5) == 0x18b8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_5");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_16) == 0x18e8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_16");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_15) == 0x1918, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_15");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_14) == 0x1948, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_14");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_13) == 0x1978, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_13");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_12) == 0x19a8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_12");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_11) == 0x19d8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_11");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_10) == 0x1a08, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_10");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_9) == 0x1a38, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_9");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_5) == 0x1a68, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_5");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_4) == 0x1a98, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_4");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_4) == 0x1ac8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_4");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_3) == 0x1af8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_11) == 0x1b28, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_11");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_4) == 0x1b58, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_4");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_10) == 0x1b88, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_10");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_9) == 0x1bb8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_9");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_8) == 0x1be8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_8");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_7) == 0x1c18, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_7");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_8) == 0x1c48, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_8");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_7) == 0x1c78, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_7");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_6) == 0x1ca8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_6");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_6) == 0x1cd8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_6");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_3) == 0x1d08, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_3) == 0x1d38, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_5) == 0x1d68, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_5");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_4) == 0x1d98, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_4");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_3) == 0x1dc8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_2) == 0x1df8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_5) == 0x1e28, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_5");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_4) == 0x1e58, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_4");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_3) == 0x1e88, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer_1) == 0x1eb8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_2) == 0x1ee8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_2) == 0x1f18, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_2) == 0x1f48, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendSpacePlayer) == 0x1f78, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendSpacePlayer");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive_1) == 0x1fa8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult_1) == 0x1fd8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine_1) == 0x2008, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SaveCachedPose_2) == 0x2038, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SaveCachedPose_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SaveCachedPose_1) == 0x2068, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SaveCachedPose_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_UseCachedPose_4) == 0x2098, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_UseCachedPose_4");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_UseCachedPose_3) == 0x20c8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_UseCachedPose_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByBool) == 0x20f8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByBool");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_UseCachedPose_2) == 0x2128, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_UseCachedPose_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_UseCachedPose_1) == 0x2158, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_UseCachedPose_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_9) == 0x2188, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_9");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByInt_3) == 0x21b8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByInt_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByInt_2) == 0x21e8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByInt_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_8) == 0x2218, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_8");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_7) == 0x2248, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_7");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_6) == 0x2278, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_6");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_5) == 0x22a8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_5");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_2) == 0x22d8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum_1) == 0x2308, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByInt_1) == 0x2338, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByInt_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByInt) == 0x2368, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByInt");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_4) == 0x2398, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_4");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_3) == 0x23c8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_2) == 0x23f8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer_1) == 0x2428, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_BlendListByEnum) == 0x2458, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_BlendListByEnum");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateResult) == 0x2488, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateResult");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_StateMachine) == 0x24b8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_StateMachine");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_4) == 0x24e8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_4");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_4) == 0x2518, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_4");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ComponentToLocalSpace) == 0x2520, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ComponentToLocalSpace");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LegIK_2) == 0x2550, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LegIK_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ModifyBone_3) == 0x2580, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ModifyBone_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LegIK_1) == 0x25b0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LegIK_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_CopyBone_11) == 0x25e0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_CopyBone_11");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_CopyBone_10) == 0x2610, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_CopyBone_10");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_CopyBone_9) == 0x2640, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_CopyBone_9");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LegIK) == 0x2670, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LegIK");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_CopyBone_8) == 0x26a0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_CopyBone_8");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_CopyBone_7) == 0x26d0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_CopyBone_7");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_CopyBone_6) == 0x2700, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_CopyBone_6");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ModifyBone_2) == 0x2730, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ModifyBone_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_CopyBone_5) == 0x2760, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_CopyBone_5");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_3) == 0x2790, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_CopyBone_4) == 0x27c0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_CopyBone_4");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ModifyBone_1) == 0x27f0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ModifyBone_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ModifyBone) == 0x2820, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ModifyBone");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_CopyBone_3) == 0x2850, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_CopyBone_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LocalToComponentSpace) == 0x2880, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LocalToComponentSpace");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_CopyBone_2) == 0x28b0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_CopyBone_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SaveCachedPose) == 0x28e0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SaveCachedPose");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_UseCachedPose) == 0x2910, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_UseCachedPose");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_CopyBone_1) == 0x2940, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_CopyBone_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Inertialization) == 0x2970, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Inertialization");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_SequencePlayer) == 0x29a0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_SequencePlayer");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_ApplyAdditive) == 0x29d0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_ApplyAdditive");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_CopyBone) == 0x2a00, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_CopyBone");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_2) == 0x2a30, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_3) == 0x2a60, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_3");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_2) == 0x2a68, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_2");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root_1) == 0x2a70, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose_1) == 0x2aa0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose_1");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_LinkedInputPose) == 0x2aa8, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_LinkedInputPose");
static_assert(offsetof(FAnimBlueprintGeneratedConstantData, AnimGraphNode_Root) == 0x2ab0, "Offset mismatch for FAnimBlueprintGeneratedConstantData::AnimGraphNode_Root");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_ImpactImmunity_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_ImpactImmunity_C) == 0xa68, "Size mismatch for UGE_ImpactImmunity_C");

// Size: 0xb40 (Inherited: 0xf08, Single: 0xfffffc38)
class UGA_DefaultPlayer_InteractUse_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)

protected:
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGA_DefaultPlayer_InteractUse_C) == 0xb40, "Size mismatch for UGA_DefaultPlayer_InteractUse_C");
static_assert(offsetof(UGA_DefaultPlayer_InteractUse_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGA_DefaultPlayer_InteractUse_C::UberGraphFrame");

// Size: 0xb70 (Inherited: 0xf08, Single: 0xfffffc68)
class UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    UControllableRidableComponent* ControllableRidableComponent_Cached; // 0xb40 (Size: 0x8, Type: ObjectProperty)
    AFortAIPawn* FortAIPawnCached; // 0xb48 (Size: 0x8, Type: ObjectProperty)
    double InitialMaxAcceleration; // 0xb50 (Size: 0x8, Type: DoubleProperty)
    double MaxRotationRateYaw; // 0xb58 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag GCN_BoostTag; // 0xb60 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_b64[0x4]; // 0xb64 (Size: 0x4, Type: PaddingProperty)
    UFortGameplayAbility* TargetAbilityCached; // 0xb68 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C) == 0xb70, "Size mismatch for UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C");
static_assert(offsetof(UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C::UberGraphFrame");
static_assert(offsetof(UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C, ControllableRidableComponent_Cached) == 0xb40, "Offset mismatch for UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C::ControllableRidableComponent_Cached");
static_assert(offsetof(UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C, FortAIPawnCached) == 0xb48, "Offset mismatch for UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C::FortAIPawnCached");
static_assert(offsetof(UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C, InitialMaxAcceleration) == 0xb50, "Offset mismatch for UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C::InitialMaxAcceleration");
static_assert(offsetof(UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C, MaxRotationRateYaw) == 0xb58, "Offset mismatch for UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C::MaxRotationRateYaw");
static_assert(offsetof(UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C, GCN_BoostTag) == 0xb60, "Offset mismatch for UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C::GCN_BoostTag");
static_assert(offsetof(UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C, TargetAbilityCached) == 0xb68, "Offset mismatch for UGA_NPC_Irwin_Prey_Burt_Charge_RidingHelper_C::TargetAbilityCached");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_Creature_EnergyWarning_Base_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_Creature_EnergyWarning_Base_C) == 0xa68, "Size mismatch for UGE_Riding_Creature_EnergyWarning_Base_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_NPC_Irwin_RidingAbilities_CooldownReduction_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_NPC_Irwin_RidingAbilities_CooldownReduction_C) == 0xa68, "Size mismatch for UGE_NPC_Irwin_RidingAbilities_CooldownReduction_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_Creature_BlockAttackOnDismount_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_Creature_BlockAttackOnDismount_C) == 0xa68, "Size mismatch for UGE_Riding_Creature_BlockAttackOnDismount_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_Creature_EnergyCritical_Base_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_Creature_EnergyCritical_Base_C) == 0xa68, "Size mismatch for UGE_Riding_Creature_EnergyCritical_Base_C");

// Size: 0x53b9 (Inherited: 0xc760, Single: 0xffff8c59)
class APlayerPawn_Generic_C : public APlayerPawn_Generic_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x4dd0 (Size: 0x8, Type: StructProperty)
    UMotionWarpingComponent* MotionWarping; // 0x4dd8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* SplashEffectsForEnteringOrExitingWater; // 0x4de0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* GamplayWindInteractionEffects; // 0x4de8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* Effect_Player_Run_Land; // 0x4df0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* Effect_Player_Walk_Land; // 0x4df8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* Effect_Player_Walk_Water; // 0x4e00 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* Effect_Player_Run_Water; // 0x4e08 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* Effect_WaterInteraction_FX; // 0x4e10 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* HitDamageParticles; // 0x4e18 (Size: 0x8, Type: ObjectProperty)
    UWidgetComponent* SpeechBubbleComponent; // 0x4e20 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* PlayerLight; // 0x4e28 (Size: 0x8, Type: ObjectProperty)
    float ShatterShield_Push_3B96BD02488A8F69F3D086A2B7978EC8; // 0x4e30 (Size: 0x4, Type: FloatProperty)
    float ShatterShield_Opacity_3B96BD02488A8F69F3D086A2B7978EC8; // 0x4e34 (Size: 0x4, Type: FloatProperty)
    float ShatterShield_Highlight_Cracks_3B96BD02488A8F69F3D086A2B7978EC8; // 0x4e38 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> ShatterShield__Direction_3B96BD02488A8F69F3D086A2B7978EC8; // 0x4e3c (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_4e3d[0x3]; // 0x4e3d (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* ShatterShield; // 0x4e40 (Size: 0x8, Type: ObjectProperty)
    USoundBase* HitByHuskRangedSound; // 0x4e48 (Size: 0x8, Type: ObjectProperty)
    USoundBase* HitByHuskMeleeSound; // 0x4e50 (Size: 0x8, Type: ObjectProperty)
    double PlayerSpeed; // 0x4e58 (Size: 0x8, Type: DoubleProperty)
    double Run_Particle_Activate_Speed; // 0x4e60 (Size: 0x8, Type: DoubleProperty)
    double Walk_Dust_Activate_Speed; // 0x4e68 (Size: 0x8, Type: DoubleProperty)
    double Walk_Particle_Reset_Speed; // 0x4e70 (Size: 0x8, Type: DoubleProperty)
    FVector PreviousVelocityVector; // 0x4e78 (Size: 0x18, Type: StructProperty)
    bool CanSpawnRunKickupFX_; // 0x4e90 (Size: 0x1, Type: BoolProperty)
    bool CanSpawnWalkKickupFX_; // 0x4e91 (Size: 0x1, Type: BoolProperty)
    bool CanSpawnDustLandFX_; // 0x4e92 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4e93[0x5]; // 0x4e93 (Size: 0x5, Type: PaddingProperty)
    FRotator RunWalkParticleRotation; // 0x4e98 (Size: 0x18, Type: StructProperty)
    bool IsNinjaInShadowStance_; // 0x4eb0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4eb1[0x7]; // 0x4eb1 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagContainer GameplayTagsForHitByHuskMeleeSound; // 0x4eb8 (Size: 0x20, Type: StructProperty)
    UMaterialInterface* Shield_Material; // 0x4ed8 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInstanceDynamic*> BodyShieldMIDArray; // 0x4ee0 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> HeadShieldMIDArray; // 0x4ef0 (Size: 0x10, Type: ArrayProperty)
    bool Shield_Active; // 0x4f00 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4f01[0x7]; // 0x4f01 (Size: 0x7, Type: PaddingProperty)
    USoundBase* Sound_Shield_Impact; // 0x4f08 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Sound_Shield_Destroyed; // 0x4f10 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Sound_Shield_FullyCharged; // 0x4f18 (Size: 0x8, Type: ObjectProperty)
    double Shield_Shatter_Opacity; // 0x4f20 (Size: 0x8, Type: DoubleProperty)
    double Regen_Opacity; // 0x4f28 (Size: 0x8, Type: DoubleProperty)
    double Damage_Opacity; // 0x4f30 (Size: 0x8, Type: DoubleProperty)
    double Default_Shield_opacity; // 0x4f38 (Size: 0x8, Type: DoubleProperty)
    double Shield_PushMinValue; // 0x4f40 (Size: 0x8, Type: DoubleProperty)
    bool ShieldVisible_Hit; // 0x4f48 (Size: 0x1, Type: BoolProperty)
    bool ShieldVisible_Recover; // 0x4f49 (Size: 0x1, Type: BoolProperty)
    bool ShieldVisible_Shatter; // 0x4f4a (Size: 0x1, Type: BoolProperty)
    bool ShieldVisible_FullHealth; // 0x4f4b (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4f4c[0x4]; // 0x4f4c (Size: 0x4, Type: PaddingProperty)
    double Fully_Regened_Shield_health_Opacity; // 0x4f50 (Size: 0x8, Type: DoubleProperty)
    FGameplayTagContainer TC_GameplayCueDamageShielded; // 0x4f58 (Size: 0x20, Type: StructProperty)
    bool LatestDamageIsShieldDamage; // 0x4f78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4f79[0x7]; // 0x4f79 (Size: 0x7, Type: PaddingProperty)
    double Damage_Taken; // 0x4f80 (Size: 0x8, Type: DoubleProperty)
    double Last_Shield_Damage_Time; // 0x4f88 (Size: 0x8, Type: DoubleProperty)
    TArray<UMaterialInstanceDynamic*> CharmShieldMIDArray; // 0x4f90 (Size: 0x10, Type: ArrayProperty)
    bool BodyValid; // 0x4fa0 (Size: 0x1, Type: BoolProperty)
    bool BackpackValid; // 0x4fa1 (Size: 0x1, Type: BoolProperty)
    bool HatValid; // 0x4fa2 (Size: 0x1, Type: BoolProperty)
    bool FaceValid; // 0x4fa3 (Size: 0x1, Type: BoolProperty)
    bool CharmValid; // 0x4fa4 (Size: 0x1, Type: BoolProperty)
    bool HeadValid; // 0x4fa5 (Size: 0x1, Type: BoolProperty)
    bool On_Player_Built_Floor; // 0x4fa6 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4fa7[0x1]; // 0x4fa7 (Size: 0x1, Type: PaddingProperty)
    FGameplayTag Event_NeedRoadsActive; // 0x4fa8 (Size: 0x4, Type: StructProperty)
    FGameplayTag Event_NeedRoadsDeactive; // 0x4fac (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer TC_WhereWereGoingWeNeedRoads; // 0x4fb0 (Size: 0x20, Type: StructProperty)
    UParticleSystem* Effect_Player_LandedDust; // 0x4fd0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* Shield_BodySkeletalMesh; // 0x4fd8 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* Shield_HeadSkeletalMesh; // 0x4fe0 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* Shield_CharmSkeletalMesh; // 0x4fe8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* Sound_Player_Hit; // 0x4ff0 (Size: 0x8, Type: ObjectProperty)
    UForceFeedbackEffect* DamageForceFeedback; // 0x4ff8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* Effect_Player_Landed_WindVector_P; // 0x5000 (Size: 0x8, Type: ObjectProperty)
    UClass* SpeechBubbleWidgetClass; // 0x5008 (Size: 0x8, Type: ClassProperty)
    FText LastSpeechText; // 0x5010 (Size: 0x10, Type: TextProperty)
    UClass* DamageCameraShake; // 0x5020 (Size: 0x8, Type: ClassProperty)
    FVector StableVelocityVector; // 0x5028 (Size: 0x18, Type: StructProperty)
    bool TickWaterLevel; // 0x5040 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5041[0x7]; // 0x5041 (Size: 0x7, Type: PaddingProperty)
    UTextureRenderTarget2D* WetnessDepthTexture; // 0x5048 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* WaterLevelMID; // 0x5050 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* WaterDecayMID; // 0x5058 (Size: 0x8, Type: ObjectProperty)
    bool Was_RTT_Enabled_Var_Set; // 0x5060 (Size: 0x1, Type: BoolProperty)
    bool Is_the_Wind_Water_Scene_Capture_Enabled; // 0x5061 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5062[0x6]; // 0x5062 (Size: 0x6, Type: PaddingProperty)
    AActor* CachedEffect; // 0x5068 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInstanceDynamic*> WaterInteractionWakeMIDS; // 0x5070 (Size: 0x10, Type: ArrayProperty)
    FLinearColor WaterTraceImpactNormalAndZHeightLocation; // 0x5080 (Size: 0x10, Type: StructProperty)
    FVector PlayerVelocity; // 0x5090 (Size: 0x18, Type: StructProperty)
    bool EnableRunWalkWaterGroundFX; // 0x50a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_50a9[0x7]; // 0x50a9 (Size: 0x7, Type: PaddingProperty)
    TArray<UMaterialInstanceDynamic*> Previous_MID; // 0x50b0 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> Previous_Weapon_MID; // 0x50c0 (Size: 0x10, Type: ArrayProperty)
    USkeletalMeshComponent* DuplicateCharacterMesh; // 0x50d0 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInstanceDynamic*> Previous_Head_MID; // 0x50d8 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> Previous_Body_MID; // 0x50e8 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> Previous_Hat_MID; // 0x50f8 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> Previous_Backpack_MID; // 0x5108 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> Previous_Charm_MID; // 0x5118 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> Previous_Face_MID; // 0x5128 (Size: 0x10, Type: ArrayProperty)
    uint8_t SwingRight[0x10]; // 0x5138 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t SwingRightEnd[0x10]; // 0x5148 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t SwingLeft[0x10]; // 0x5158 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t SwingLeftEnd[0x10]; // 0x5168 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t AnimNotify_Begin[0x10]; // 0x5178 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t AnimNotify_End[0x10]; // 0x5188 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t SwingRight2[0x10]; // 0x5198 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t SwingLeft2[0x10]; // 0x51a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool BlockedByPawns; // 0x51b8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_51b9[0x7]; // 0x51b9 (Size: 0x7, Type: PaddingProperty)
    FGameplayAttribute Attribute_CurrentShield_Const; // 0x51c0 (Size: 0x38, Type: StructProperty)
    FGameplayAttribute Attribute_Shield_Const; // 0x51f8 (Size: 0x38, Type: StructProperty)
    FGameplayAttribute Attribute_CurrentHealth_Const; // 0x5230 (Size: 0x38, Type: StructProperty)
    FGameplayAttribute Attribute_Max_Health_Const; // 0x5268 (Size: 0x38, Type: StructProperty)
    FCameraLensInterfaceClassSupport LensEffectInterfaceClass_PlayerHealthDamage; // 0x52a0 (Size: 0x8, Type: StructProperty)
    FCameraLensInterfaceClassSupport LensEffectInterfaceClass_PlayerShieldDamage; // 0x52a8 (Size: 0x8, Type: StructProperty)
    FCameraLensInterfaceClassSupport LensEffectInterfaceClass_Directional_PlayerShieldDamage; // 0x52b0 (Size: 0x8, Type: StructProperty)
    FCameraLensInterfaceClassSupport LensEffectInterfaceClass_Directional_PlayerHealthDamage; // 0x52b8 (Size: 0x8, Type: StructProperty)
    TArray<UMaterialInstanceDynamic*> Temp_DIM_Array; // 0x52c0 (Size: 0x10, Type: ArrayProperty)
    TMap<bool, TEnumAsByte<EFortCustomPartType>> PartValid; // 0x52d0 (Size: 0x50, Type: MapProperty)
    TArray<TEnumAsByte<EFortCustomPartType>> ShieldPartList; // 0x5320 (Size: 0x10, Type: ArrayProperty)
    TArray<FCharacterPartMidArrayStruct> ShieldMIDArrays; // 0x5330 (Size: 0x10, Type: ArrayProperty)
    TMap<USkeletalMeshComponent*, TEnumAsByte<EFortCustomPartType>> ShieldSkMeshes; // 0x5340 (Size: 0x50, Type: MapProperty)
    int32_t L_ShieldMIDIndex; // 0x5390 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_5394[0x4]; // 0x5394 (Size: 0x4, Type: PaddingProperty)
    USkeletalMeshComponent* NullPart_Mesh; // 0x5398 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* PlayerDeath_Montage; // 0x53a0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* PlayerDeathDBNO_Montage; // 0x53a8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* PlayerDeathSkydive_Montage; // 0x53b0 (Size: 0x8, Type: ObjectProperty)
    bool PlayerDeath_EnableDeathDissolve; // 0x53b8 (Size: 0x1, Type: BoolProperty)

public:
    double GetShieldPercent2(); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    double GetHealthPercent2(); // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void FindShieldOpacity(); // 0x288a61c (Index: 0xb, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Find_Shield_MID_Array(TEnumAsByte<EFortCustomPartType>& PartType, bool& Found, int32_t& Index, TArray<UMaterialInstanceDynamic*>& MIDs); // 0x288a61c (Index: 0xc, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void EnableWaterAudio(bool& IsEnteringWater); // 0x288a61c (Index: 0xf, Flags: Public|BlueprintCallable|BlueprintEvent)
    void DisableWaterLevelTick(); // 0x288a61c (Index: 0x10, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Create_and_Duplicate_Effect_Skeletal_Meshes_Parent(USkeletalMeshComponent* DuplicatedSkeletalMeshComponent, UMaterialInterface*& Material_to_Apply, TArray<UMaterialInstanceDynamic*> Empty_MID_Array, int32_t& TranslucentSortPriority, USkeletalMeshComponent*& MeshPart, TEnumAsByte<EFortCustomPartType>& CustomBodyType); // 0x288a61c (Index: 0x11, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Create_and_Duplicate_Effect_Poseable_Skeletal_Mesh(UMaterialInterface*& Material_to_Apply, TArray<UMaterialInstanceDynamic*> Empty_MID_Array, int32_t& TranslucentSortPriority, UPoseableMeshComponent* PoseableMesh, TEnumAsByte<EFortCustomPartType>& CustomBodyType, USkeletalMeshComponent*& PartMesh); // 0x288a61c (Index: 0x12, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void BindToSwingFX2(const FDelegate SwingLeft2, const FDelegate SwingRight2); // 0x288a61c (Index: 0x15, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void BindToSwingFX(const FDelegate SwingLeft, const FDelegate SwingLeftEnd, const FDelegate SwingRight, const FDelegate SwingRightEnd); // 0x288a61c (Index: 0x16, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void BindToAnimTrailEvents(const FDelegate AnimNotifyBegin, const FDelegate AnimNotifyEnd); // 0x288a61c (Index: 0x17, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void Are_the_wind_and_water_RTT_passes_enabled(bool& NewParam); // 0x288a61c (Index: 0x18, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void AnimTrailsNotify(bool& bActive); // 0x288a61c (Index: 0x19, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void AnimTrailsDisable(); // 0x288a61c (Index: 0x1a, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    void AnimNotify_End__DelegateSignature(); // 0x288a61c (Index: 0x1b, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void AnimNotify_Begin__DelegateSignature(bool& bActive); // 0x288a61c (Index: 0x1c, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void Override_Materials_and_Copy_Parameters_on_Weapons_Mesh(UMaterialInterface*& Material_to_Apply); // 0x288a61c (Index: 0x1e, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void OnWeaponEquipped(AFortWeapon*& NewWeapon, AFortWeapon*& PrevWeapon); // 0x288a61c (Index: 0x1f, Flags: Event|Public|BlueprintEvent)
    virtual void OnLanded(const FHitResult Hit); // 0x288a61c (Index: 0x27, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnExitedWaterVolume(const FVector WaterSurfaceLocation); // 0x288a61c (Index: 0x29, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnExitedVehicle(); // 0x288a61c (Index: 0x2a, Flags: Event|Public|BlueprintEvent)
    virtual void OnEnteredWaterVolume(const FVector WaterSurfaceLocation); // 0x288a61c (Index: 0x2b, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnEnteredVehicle(); // 0x288a61c (Index: 0x2c, Flags: Event|Public|BlueprintEvent)
    virtual void OnDeathServer(float& Damage, const FGameplayTagContainer DamageTags, FVector& Momentum, const FHitResult HitInfo, AController*& InstigatedBy, AActor*& DamageCauser, FGameplayEffectContextHandle& EffectContext); // 0x288a61c (Index: 0x2e, Flags: BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnDeathPlayEffects(float& Damage, const FGameplayTagContainer DamageTags, FVector& Momentum, const FHitResult HitInfo, AFortPawn*& InstigatedBy, AActor*& DamageCauser, FGameplayEffectContextHandle& EffectContext); // 0x288a61c (Index: 0x2f, Flags: BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnDamagePlayEffects(float& Damage, const FGameplayTagContainer DamageTags, FVector& Momentum, const FHitResult HitInfo, AFortPawn*& InstigatedBy, AActor*& DamageCauser, FGameplayEffectContextHandle& EffectContext); // 0x288a61c (Index: 0x30, Flags: BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnBaseChanged(AActor*& NewBase); // 0x288a61c (Index: 0x33, Flags: Event|Public|BlueprintEvent)
    void On_Set_Material_Part(AFortPlayerPawn*& Pawn, UCustomCharacterPart*& Part, USkeletalMeshComponent*& MeshPart, TEnumAsByte<EFortCustomPartType>& const PartType); // 0x288a61c (Index: 0x36, Flags: Public|BlueprintCallable|BlueprintEvent)
    void MeleeSwingRight_End(); // 0x288a61c (Index: 0x39, Flags: Public|BlueprintCallable|BlueprintEvent)
    void MeleeSwingLeft_End(); // 0x288a61c (Index: 0x3b, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Melee_Effect_Color(FVector& Melee_Color_Set); // 0x288a61c (Index: 0x3c, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void UserConstructionScript(); // 0x288a61c (Index: 0x3e, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void UnbindFromSwingFX2(const FDelegate SwingLeft2, const FDelegate SwingRight2); // 0x288a61c (Index: 0x40, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void UnbindFromSwingFX(const FDelegate SwingLeft, const FDelegate SwingLeftEnd, const FDelegate SwingRight, const FDelegate SwingRightEnd); // 0x288a61c (Index: 0x41, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void UnbindFromAnimTrailEvents(const FDelegate AnimNotifyBegin, const FDelegate AnimNotifyEnd); // 0x288a61c (Index: 0x42, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void TriggerGameplayWindEmitter(TEnumAsByte<PlayerWindParticleEmitters>& Player_Wind_Particle_Emitter_To_Fire); // 0x288a61c (Index: 0x43, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SwingRightEnd__DelegateSignature(); // 0x288a61c (Index: 0x46, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void SwingRight__DelegateSignature(); // 0x288a61c (Index: 0x47, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void SwingRight2__DelegateSignature(); // 0x288a61c (Index: 0x48, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void SwingLeftEnd__DelegateSignature(); // 0x288a61c (Index: 0x49, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void SwingLeft__DelegateSignature(); // 0x288a61c (Index: 0x4a, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void SwingLeft2__DelegateSignature(); // 0x288a61c (Index: 0x4b, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void SlaveAMeshToTheBody(USkeletalMeshComponent*& Mesh, USkeletalMeshComponent*& Master); // 0x288a61c (Index: 0x4c, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Setup_Duplicate_FX_Mesh(UMaterialInterface* Material_to_Apply, TEnumAsByte<EFortCustomPartType>& PartType, TArray<UMaterialInstanceDynamic*> Empty_MID_Array, USkeletalMeshComponent* Duplicated_Mesh, bool& Transfer_Material_Parameters, int32_t& Translucent_Sort_Order, USkeletalMeshComponent*& MeshPart, bool& ObjectsValid); // 0x288a61c (Index: 0x4f, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetShieldMids(double& Highlight_Cracks, bool& Set_Highlight_Cracks, double& Push, bool& Set_Push); // 0x288a61c (Index: 0x51, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void SetFirstPersonCamera(bool& bNewUseFirstPersonCamera); // 0x288a61c (Index: 0x52, Flags: Event|Public|BlueprintEvent)
    void Set_Scalar_Parameter_on_Duplicate_Mesh_MIDs(FName& Parameter_Name, double& Parameter_Value); // 0x288a61c (Index: 0x54, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Part_Material(TArray<UMaterialInstanceDynamic*> Array, USkeletalMeshComponent*& MeshPart); // 0x288a61c (Index: 0x56, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void Set_Body_Type_Sounds(); // 0x288a61c (Index: 0x57, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Restore_Previous_Materials_on_Weapons_Mesh(AFortWeapon*& Weapon_to_Restore); // 0x288a61c (Index: 0x58, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Restore_Previous_Materials_on_Character_Mesh(); // 0x288a61c (Index: 0x59, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x5b, Flags: Event|Public|BlueprintEvent)
    virtual void ReceivePossessed(AController*& NewController); // 0x288a61c (Index: 0x5c, Flags: BlueprintAuthorityOnly|Event|Public|BlueprintEvent)
    void PlayHitSound(AFortPawn*& Instigator, AActor*& Damage_Causer); // 0x288a61c (Index: 0x5d, Flags: Public|BlueprintCallable|BlueprintEvent)

private:
    void SetShieldMids_InternalLoop(double& Highlight_Cracks, bool& Set_Highlight_Cracks, double& Push, bool& Set_Push, TArray<UMaterialInstanceDynamic*> MID_Array); // 0x288a61c (Index: 0x50, Flags: Private|HasOutParms|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnDisplaySentence(const FText SpeechText); // 0x288a61c (Index: 0x2d, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnClearSentence(); // 0x288a61c (Index: 0x31, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCharacterPartsReinitialized(); // 0x288a61c (Index: 0x32, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(APlayerPawn_Generic_C) == 0x53b9, "Size mismatch for APlayerPawn_Generic_C");
static_assert(offsetof(APlayerPawn_Generic_C, UberGraphFrame) == 0x4dd0, "Offset mismatch for APlayerPawn_Generic_C::UberGraphFrame");
static_assert(offsetof(APlayerPawn_Generic_C, MotionWarping) == 0x4dd8, "Offset mismatch for APlayerPawn_Generic_C::MotionWarping");
static_assert(offsetof(APlayerPawn_Generic_C, SplashEffectsForEnteringOrExitingWater) == 0x4de0, "Offset mismatch for APlayerPawn_Generic_C::SplashEffectsForEnteringOrExitingWater");
static_assert(offsetof(APlayerPawn_Generic_C, GamplayWindInteractionEffects) == 0x4de8, "Offset mismatch for APlayerPawn_Generic_C::GamplayWindInteractionEffects");
static_assert(offsetof(APlayerPawn_Generic_C, Effect_Player_Run_Land) == 0x4df0, "Offset mismatch for APlayerPawn_Generic_C::Effect_Player_Run_Land");
static_assert(offsetof(APlayerPawn_Generic_C, Effect_Player_Walk_Land) == 0x4df8, "Offset mismatch for APlayerPawn_Generic_C::Effect_Player_Walk_Land");
static_assert(offsetof(APlayerPawn_Generic_C, Effect_Player_Walk_Water) == 0x4e00, "Offset mismatch for APlayerPawn_Generic_C::Effect_Player_Walk_Water");
static_assert(offsetof(APlayerPawn_Generic_C, Effect_Player_Run_Water) == 0x4e08, "Offset mismatch for APlayerPawn_Generic_C::Effect_Player_Run_Water");
static_assert(offsetof(APlayerPawn_Generic_C, Effect_WaterInteraction_FX) == 0x4e10, "Offset mismatch for APlayerPawn_Generic_C::Effect_WaterInteraction_FX");
static_assert(offsetof(APlayerPawn_Generic_C, HitDamageParticles) == 0x4e18, "Offset mismatch for APlayerPawn_Generic_C::HitDamageParticles");
static_assert(offsetof(APlayerPawn_Generic_C, SpeechBubbleComponent) == 0x4e20, "Offset mismatch for APlayerPawn_Generic_C::SpeechBubbleComponent");
static_assert(offsetof(APlayerPawn_Generic_C, PlayerLight) == 0x4e28, "Offset mismatch for APlayerPawn_Generic_C::PlayerLight");
static_assert(offsetof(APlayerPawn_Generic_C, ShatterShield_Push_3B96BD02488A8F69F3D086A2B7978EC8) == 0x4e30, "Offset mismatch for APlayerPawn_Generic_C::ShatterShield_Push_3B96BD02488A8F69F3D086A2B7978EC8");
static_assert(offsetof(APlayerPawn_Generic_C, ShatterShield_Opacity_3B96BD02488A8F69F3D086A2B7978EC8) == 0x4e34, "Offset mismatch for APlayerPawn_Generic_C::ShatterShield_Opacity_3B96BD02488A8F69F3D086A2B7978EC8");
static_assert(offsetof(APlayerPawn_Generic_C, ShatterShield_Highlight_Cracks_3B96BD02488A8F69F3D086A2B7978EC8) == 0x4e38, "Offset mismatch for APlayerPawn_Generic_C::ShatterShield_Highlight_Cracks_3B96BD02488A8F69F3D086A2B7978EC8");
static_assert(offsetof(APlayerPawn_Generic_C, ShatterShield__Direction_3B96BD02488A8F69F3D086A2B7978EC8) == 0x4e3c, "Offset mismatch for APlayerPawn_Generic_C::ShatterShield__Direction_3B96BD02488A8F69F3D086A2B7978EC8");
static_assert(offsetof(APlayerPawn_Generic_C, ShatterShield) == 0x4e40, "Offset mismatch for APlayerPawn_Generic_C::ShatterShield");
static_assert(offsetof(APlayerPawn_Generic_C, HitByHuskRangedSound) == 0x4e48, "Offset mismatch for APlayerPawn_Generic_C::HitByHuskRangedSound");
static_assert(offsetof(APlayerPawn_Generic_C, HitByHuskMeleeSound) == 0x4e50, "Offset mismatch for APlayerPawn_Generic_C::HitByHuskMeleeSound");
static_assert(offsetof(APlayerPawn_Generic_C, PlayerSpeed) == 0x4e58, "Offset mismatch for APlayerPawn_Generic_C::PlayerSpeed");
static_assert(offsetof(APlayerPawn_Generic_C, Run_Particle_Activate_Speed) == 0x4e60, "Offset mismatch for APlayerPawn_Generic_C::Run_Particle_Activate_Speed");
static_assert(offsetof(APlayerPawn_Generic_C, Walk_Dust_Activate_Speed) == 0x4e68, "Offset mismatch for APlayerPawn_Generic_C::Walk_Dust_Activate_Speed");
static_assert(offsetof(APlayerPawn_Generic_C, Walk_Particle_Reset_Speed) == 0x4e70, "Offset mismatch for APlayerPawn_Generic_C::Walk_Particle_Reset_Speed");
static_assert(offsetof(APlayerPawn_Generic_C, PreviousVelocityVector) == 0x4e78, "Offset mismatch for APlayerPawn_Generic_C::PreviousVelocityVector");
static_assert(offsetof(APlayerPawn_Generic_C, CanSpawnRunKickupFX_) == 0x4e90, "Offset mismatch for APlayerPawn_Generic_C::CanSpawnRunKickupFX_");
static_assert(offsetof(APlayerPawn_Generic_C, CanSpawnWalkKickupFX_) == 0x4e91, "Offset mismatch for APlayerPawn_Generic_C::CanSpawnWalkKickupFX_");
static_assert(offsetof(APlayerPawn_Generic_C, CanSpawnDustLandFX_) == 0x4e92, "Offset mismatch for APlayerPawn_Generic_C::CanSpawnDustLandFX_");
static_assert(offsetof(APlayerPawn_Generic_C, RunWalkParticleRotation) == 0x4e98, "Offset mismatch for APlayerPawn_Generic_C::RunWalkParticleRotation");
static_assert(offsetof(APlayerPawn_Generic_C, IsNinjaInShadowStance_) == 0x4eb0, "Offset mismatch for APlayerPawn_Generic_C::IsNinjaInShadowStance_");
static_assert(offsetof(APlayerPawn_Generic_C, GameplayTagsForHitByHuskMeleeSound) == 0x4eb8, "Offset mismatch for APlayerPawn_Generic_C::GameplayTagsForHitByHuskMeleeSound");
static_assert(offsetof(APlayerPawn_Generic_C, Shield_Material) == 0x4ed8, "Offset mismatch for APlayerPawn_Generic_C::Shield_Material");
static_assert(offsetof(APlayerPawn_Generic_C, BodyShieldMIDArray) == 0x4ee0, "Offset mismatch for APlayerPawn_Generic_C::BodyShieldMIDArray");
static_assert(offsetof(APlayerPawn_Generic_C, HeadShieldMIDArray) == 0x4ef0, "Offset mismatch for APlayerPawn_Generic_C::HeadShieldMIDArray");
static_assert(offsetof(APlayerPawn_Generic_C, Shield_Active) == 0x4f00, "Offset mismatch for APlayerPawn_Generic_C::Shield_Active");
static_assert(offsetof(APlayerPawn_Generic_C, Sound_Shield_Impact) == 0x4f08, "Offset mismatch for APlayerPawn_Generic_C::Sound_Shield_Impact");
static_assert(offsetof(APlayerPawn_Generic_C, Sound_Shield_Destroyed) == 0x4f10, "Offset mismatch for APlayerPawn_Generic_C::Sound_Shield_Destroyed");
static_assert(offsetof(APlayerPawn_Generic_C, Sound_Shield_FullyCharged) == 0x4f18, "Offset mismatch for APlayerPawn_Generic_C::Sound_Shield_FullyCharged");
static_assert(offsetof(APlayerPawn_Generic_C, Shield_Shatter_Opacity) == 0x4f20, "Offset mismatch for APlayerPawn_Generic_C::Shield_Shatter_Opacity");
static_assert(offsetof(APlayerPawn_Generic_C, Regen_Opacity) == 0x4f28, "Offset mismatch for APlayerPawn_Generic_C::Regen_Opacity");
static_assert(offsetof(APlayerPawn_Generic_C, Damage_Opacity) == 0x4f30, "Offset mismatch for APlayerPawn_Generic_C::Damage_Opacity");
static_assert(offsetof(APlayerPawn_Generic_C, Default_Shield_opacity) == 0x4f38, "Offset mismatch for APlayerPawn_Generic_C::Default_Shield_opacity");
static_assert(offsetof(APlayerPawn_Generic_C, Shield_PushMinValue) == 0x4f40, "Offset mismatch for APlayerPawn_Generic_C::Shield_PushMinValue");
static_assert(offsetof(APlayerPawn_Generic_C, ShieldVisible_Hit) == 0x4f48, "Offset mismatch for APlayerPawn_Generic_C::ShieldVisible_Hit");
static_assert(offsetof(APlayerPawn_Generic_C, ShieldVisible_Recover) == 0x4f49, "Offset mismatch for APlayerPawn_Generic_C::ShieldVisible_Recover");
static_assert(offsetof(APlayerPawn_Generic_C, ShieldVisible_Shatter) == 0x4f4a, "Offset mismatch for APlayerPawn_Generic_C::ShieldVisible_Shatter");
static_assert(offsetof(APlayerPawn_Generic_C, ShieldVisible_FullHealth) == 0x4f4b, "Offset mismatch for APlayerPawn_Generic_C::ShieldVisible_FullHealth");
static_assert(offsetof(APlayerPawn_Generic_C, Fully_Regened_Shield_health_Opacity) == 0x4f50, "Offset mismatch for APlayerPawn_Generic_C::Fully_Regened_Shield_health_Opacity");
static_assert(offsetof(APlayerPawn_Generic_C, TC_GameplayCueDamageShielded) == 0x4f58, "Offset mismatch for APlayerPawn_Generic_C::TC_GameplayCueDamageShielded");
static_assert(offsetof(APlayerPawn_Generic_C, LatestDamageIsShieldDamage) == 0x4f78, "Offset mismatch for APlayerPawn_Generic_C::LatestDamageIsShieldDamage");
static_assert(offsetof(APlayerPawn_Generic_C, Damage_Taken) == 0x4f80, "Offset mismatch for APlayerPawn_Generic_C::Damage_Taken");
static_assert(offsetof(APlayerPawn_Generic_C, Last_Shield_Damage_Time) == 0x4f88, "Offset mismatch for APlayerPawn_Generic_C::Last_Shield_Damage_Time");
static_assert(offsetof(APlayerPawn_Generic_C, CharmShieldMIDArray) == 0x4f90, "Offset mismatch for APlayerPawn_Generic_C::CharmShieldMIDArray");
static_assert(offsetof(APlayerPawn_Generic_C, BodyValid) == 0x4fa0, "Offset mismatch for APlayerPawn_Generic_C::BodyValid");
static_assert(offsetof(APlayerPawn_Generic_C, BackpackValid) == 0x4fa1, "Offset mismatch for APlayerPawn_Generic_C::BackpackValid");
static_assert(offsetof(APlayerPawn_Generic_C, HatValid) == 0x4fa2, "Offset mismatch for APlayerPawn_Generic_C::HatValid");
static_assert(offsetof(APlayerPawn_Generic_C, FaceValid) == 0x4fa3, "Offset mismatch for APlayerPawn_Generic_C::FaceValid");
static_assert(offsetof(APlayerPawn_Generic_C, CharmValid) == 0x4fa4, "Offset mismatch for APlayerPawn_Generic_C::CharmValid");
static_assert(offsetof(APlayerPawn_Generic_C, HeadValid) == 0x4fa5, "Offset mismatch for APlayerPawn_Generic_C::HeadValid");
static_assert(offsetof(APlayerPawn_Generic_C, On_Player_Built_Floor) == 0x4fa6, "Offset mismatch for APlayerPawn_Generic_C::On_Player_Built_Floor");
static_assert(offsetof(APlayerPawn_Generic_C, Event_NeedRoadsActive) == 0x4fa8, "Offset mismatch for APlayerPawn_Generic_C::Event_NeedRoadsActive");
static_assert(offsetof(APlayerPawn_Generic_C, Event_NeedRoadsDeactive) == 0x4fac, "Offset mismatch for APlayerPawn_Generic_C::Event_NeedRoadsDeactive");
static_assert(offsetof(APlayerPawn_Generic_C, TC_WhereWereGoingWeNeedRoads) == 0x4fb0, "Offset mismatch for APlayerPawn_Generic_C::TC_WhereWereGoingWeNeedRoads");
static_assert(offsetof(APlayerPawn_Generic_C, Effect_Player_LandedDust) == 0x4fd0, "Offset mismatch for APlayerPawn_Generic_C::Effect_Player_LandedDust");
static_assert(offsetof(APlayerPawn_Generic_C, Shield_BodySkeletalMesh) == 0x4fd8, "Offset mismatch for APlayerPawn_Generic_C::Shield_BodySkeletalMesh");
static_assert(offsetof(APlayerPawn_Generic_C, Shield_HeadSkeletalMesh) == 0x4fe0, "Offset mismatch for APlayerPawn_Generic_C::Shield_HeadSkeletalMesh");
static_assert(offsetof(APlayerPawn_Generic_C, Shield_CharmSkeletalMesh) == 0x4fe8, "Offset mismatch for APlayerPawn_Generic_C::Shield_CharmSkeletalMesh");
static_assert(offsetof(APlayerPawn_Generic_C, Sound_Player_Hit) == 0x4ff0, "Offset mismatch for APlayerPawn_Generic_C::Sound_Player_Hit");
static_assert(offsetof(APlayerPawn_Generic_C, DamageForceFeedback) == 0x4ff8, "Offset mismatch for APlayerPawn_Generic_C::DamageForceFeedback");
static_assert(offsetof(APlayerPawn_Generic_C, Effect_Player_Landed_WindVector_P) == 0x5000, "Offset mismatch for APlayerPawn_Generic_C::Effect_Player_Landed_WindVector_P");
static_assert(offsetof(APlayerPawn_Generic_C, SpeechBubbleWidgetClass) == 0x5008, "Offset mismatch for APlayerPawn_Generic_C::SpeechBubbleWidgetClass");
static_assert(offsetof(APlayerPawn_Generic_C, LastSpeechText) == 0x5010, "Offset mismatch for APlayerPawn_Generic_C::LastSpeechText");
static_assert(offsetof(APlayerPawn_Generic_C, DamageCameraShake) == 0x5020, "Offset mismatch for APlayerPawn_Generic_C::DamageCameraShake");
static_assert(offsetof(APlayerPawn_Generic_C, StableVelocityVector) == 0x5028, "Offset mismatch for APlayerPawn_Generic_C::StableVelocityVector");
static_assert(offsetof(APlayerPawn_Generic_C, TickWaterLevel) == 0x5040, "Offset mismatch for APlayerPawn_Generic_C::TickWaterLevel");
static_assert(offsetof(APlayerPawn_Generic_C, WetnessDepthTexture) == 0x5048, "Offset mismatch for APlayerPawn_Generic_C::WetnessDepthTexture");
static_assert(offsetof(APlayerPawn_Generic_C, WaterLevelMID) == 0x5050, "Offset mismatch for APlayerPawn_Generic_C::WaterLevelMID");
static_assert(offsetof(APlayerPawn_Generic_C, WaterDecayMID) == 0x5058, "Offset mismatch for APlayerPawn_Generic_C::WaterDecayMID");
static_assert(offsetof(APlayerPawn_Generic_C, Was_RTT_Enabled_Var_Set) == 0x5060, "Offset mismatch for APlayerPawn_Generic_C::Was_RTT_Enabled_Var_Set");
static_assert(offsetof(APlayerPawn_Generic_C, Is_the_Wind_Water_Scene_Capture_Enabled) == 0x5061, "Offset mismatch for APlayerPawn_Generic_C::Is_the_Wind_Water_Scene_Capture_Enabled");
static_assert(offsetof(APlayerPawn_Generic_C, CachedEffect) == 0x5068, "Offset mismatch for APlayerPawn_Generic_C::CachedEffect");
static_assert(offsetof(APlayerPawn_Generic_C, WaterInteractionWakeMIDS) == 0x5070, "Offset mismatch for APlayerPawn_Generic_C::WaterInteractionWakeMIDS");
static_assert(offsetof(APlayerPawn_Generic_C, WaterTraceImpactNormalAndZHeightLocation) == 0x5080, "Offset mismatch for APlayerPawn_Generic_C::WaterTraceImpactNormalAndZHeightLocation");
static_assert(offsetof(APlayerPawn_Generic_C, PlayerVelocity) == 0x5090, "Offset mismatch for APlayerPawn_Generic_C::PlayerVelocity");
static_assert(offsetof(APlayerPawn_Generic_C, EnableRunWalkWaterGroundFX) == 0x50a8, "Offset mismatch for APlayerPawn_Generic_C::EnableRunWalkWaterGroundFX");
static_assert(offsetof(APlayerPawn_Generic_C, Previous_MID) == 0x50b0, "Offset mismatch for APlayerPawn_Generic_C::Previous_MID");
static_assert(offsetof(APlayerPawn_Generic_C, Previous_Weapon_MID) == 0x50c0, "Offset mismatch for APlayerPawn_Generic_C::Previous_Weapon_MID");
static_assert(offsetof(APlayerPawn_Generic_C, DuplicateCharacterMesh) == 0x50d0, "Offset mismatch for APlayerPawn_Generic_C::DuplicateCharacterMesh");
static_assert(offsetof(APlayerPawn_Generic_C, Previous_Head_MID) == 0x50d8, "Offset mismatch for APlayerPawn_Generic_C::Previous_Head_MID");
static_assert(offsetof(APlayerPawn_Generic_C, Previous_Body_MID) == 0x50e8, "Offset mismatch for APlayerPawn_Generic_C::Previous_Body_MID");
static_assert(offsetof(APlayerPawn_Generic_C, Previous_Hat_MID) == 0x50f8, "Offset mismatch for APlayerPawn_Generic_C::Previous_Hat_MID");
static_assert(offsetof(APlayerPawn_Generic_C, Previous_Backpack_MID) == 0x5108, "Offset mismatch for APlayerPawn_Generic_C::Previous_Backpack_MID");
static_assert(offsetof(APlayerPawn_Generic_C, Previous_Charm_MID) == 0x5118, "Offset mismatch for APlayerPawn_Generic_C::Previous_Charm_MID");
static_assert(offsetof(APlayerPawn_Generic_C, Previous_Face_MID) == 0x5128, "Offset mismatch for APlayerPawn_Generic_C::Previous_Face_MID");
static_assert(offsetof(APlayerPawn_Generic_C, SwingRight) == 0x5138, "Offset mismatch for APlayerPawn_Generic_C::SwingRight");
static_assert(offsetof(APlayerPawn_Generic_C, SwingRightEnd) == 0x5148, "Offset mismatch for APlayerPawn_Generic_C::SwingRightEnd");
static_assert(offsetof(APlayerPawn_Generic_C, SwingLeft) == 0x5158, "Offset mismatch for APlayerPawn_Generic_C::SwingLeft");
static_assert(offsetof(APlayerPawn_Generic_C, SwingLeftEnd) == 0x5168, "Offset mismatch for APlayerPawn_Generic_C::SwingLeftEnd");
static_assert(offsetof(APlayerPawn_Generic_C, AnimNotify_Begin) == 0x5178, "Offset mismatch for APlayerPawn_Generic_C::AnimNotify_Begin");
static_assert(offsetof(APlayerPawn_Generic_C, AnimNotify_End) == 0x5188, "Offset mismatch for APlayerPawn_Generic_C::AnimNotify_End");
static_assert(offsetof(APlayerPawn_Generic_C, SwingRight2) == 0x5198, "Offset mismatch for APlayerPawn_Generic_C::SwingRight2");
static_assert(offsetof(APlayerPawn_Generic_C, SwingLeft2) == 0x51a8, "Offset mismatch for APlayerPawn_Generic_C::SwingLeft2");
static_assert(offsetof(APlayerPawn_Generic_C, BlockedByPawns) == 0x51b8, "Offset mismatch for APlayerPawn_Generic_C::BlockedByPawns");
static_assert(offsetof(APlayerPawn_Generic_C, Attribute_CurrentShield_Const) == 0x51c0, "Offset mismatch for APlayerPawn_Generic_C::Attribute_CurrentShield_Const");
static_assert(offsetof(APlayerPawn_Generic_C, Attribute_Shield_Const) == 0x51f8, "Offset mismatch for APlayerPawn_Generic_C::Attribute_Shield_Const");
static_assert(offsetof(APlayerPawn_Generic_C, Attribute_CurrentHealth_Const) == 0x5230, "Offset mismatch for APlayerPawn_Generic_C::Attribute_CurrentHealth_Const");
static_assert(offsetof(APlayerPawn_Generic_C, Attribute_Max_Health_Const) == 0x5268, "Offset mismatch for APlayerPawn_Generic_C::Attribute_Max_Health_Const");
static_assert(offsetof(APlayerPawn_Generic_C, LensEffectInterfaceClass_PlayerHealthDamage) == 0x52a0, "Offset mismatch for APlayerPawn_Generic_C::LensEffectInterfaceClass_PlayerHealthDamage");
static_assert(offsetof(APlayerPawn_Generic_C, LensEffectInterfaceClass_PlayerShieldDamage) == 0x52a8, "Offset mismatch for APlayerPawn_Generic_C::LensEffectInterfaceClass_PlayerShieldDamage");
static_assert(offsetof(APlayerPawn_Generic_C, LensEffectInterfaceClass_Directional_PlayerShieldDamage) == 0x52b0, "Offset mismatch for APlayerPawn_Generic_C::LensEffectInterfaceClass_Directional_PlayerShieldDamage");
static_assert(offsetof(APlayerPawn_Generic_C, LensEffectInterfaceClass_Directional_PlayerHealthDamage) == 0x52b8, "Offset mismatch for APlayerPawn_Generic_C::LensEffectInterfaceClass_Directional_PlayerHealthDamage");
static_assert(offsetof(APlayerPawn_Generic_C, Temp_DIM_Array) == 0x52c0, "Offset mismatch for APlayerPawn_Generic_C::Temp_DIM_Array");
static_assert(offsetof(APlayerPawn_Generic_C, PartValid) == 0x52d0, "Offset mismatch for APlayerPawn_Generic_C::PartValid");
static_assert(offsetof(APlayerPawn_Generic_C, ShieldPartList) == 0x5320, "Offset mismatch for APlayerPawn_Generic_C::ShieldPartList");
static_assert(offsetof(APlayerPawn_Generic_C, ShieldMIDArrays) == 0x5330, "Offset mismatch for APlayerPawn_Generic_C::ShieldMIDArrays");
static_assert(offsetof(APlayerPawn_Generic_C, ShieldSkMeshes) == 0x5340, "Offset mismatch for APlayerPawn_Generic_C::ShieldSkMeshes");
static_assert(offsetof(APlayerPawn_Generic_C, L_ShieldMIDIndex) == 0x5390, "Offset mismatch for APlayerPawn_Generic_C::L_ShieldMIDIndex");
static_assert(offsetof(APlayerPawn_Generic_C, NullPart_Mesh) == 0x5398, "Offset mismatch for APlayerPawn_Generic_C::NullPart_Mesh");
static_assert(offsetof(APlayerPawn_Generic_C, PlayerDeath_Montage) == 0x53a0, "Offset mismatch for APlayerPawn_Generic_C::PlayerDeath_Montage");
static_assert(offsetof(APlayerPawn_Generic_C, PlayerDeathDBNO_Montage) == 0x53a8, "Offset mismatch for APlayerPawn_Generic_C::PlayerDeathDBNO_Montage");
static_assert(offsetof(APlayerPawn_Generic_C, PlayerDeathSkydive_Montage) == 0x53b0, "Offset mismatch for APlayerPawn_Generic_C::PlayerDeathSkydive_Montage");
static_assert(offsetof(APlayerPawn_Generic_C, PlayerDeath_EnableDeathDissolve) == 0x53b8, "Offset mismatch for APlayerPawn_Generic_C::PlayerDeath_EnableDeathDissolve");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_Creature_EnergyDepleted_Grandma_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_Creature_EnergyDepleted_Grandma_C) == 0xa68, "Size mismatch for UGE_Riding_Creature_EnergyDepleted_Grandma_C");

// Size: 0xed0 (Inherited: 0x2ca0, Single: 0xffffe230)
class UGA_Riding_Creature_EnergyDepleted_Grandma_C : public UGA_Riding_Creature_EnergyDepleted_Base_C
{
public:
};

static_assert(sizeof(UGA_Riding_Creature_EnergyDepleted_Grandma_C) == 0xed0, "Size mismatch for UGA_Riding_Creature_EnergyDepleted_Grandma_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Riding_Creature_EnergyDepleted_Burt_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Riding_Creature_EnergyDepleted_Burt_C) == 0xa68, "Size mismatch for UGE_Riding_Creature_EnergyDepleted_Burt_C");

// Size: 0xed0 (Inherited: 0x2ca0, Single: 0xffffe230)
class UGA_Riding_Creature_EnergyDepleted_Burt_C : public UGA_Riding_Creature_EnergyDepleted_Base_C
{
public:
};

static_assert(sizeof(UGA_Riding_Creature_EnergyDepleted_Burt_C) == 0xed0, "Size mismatch for UGA_Riding_Creature_EnergyDepleted_Burt_C");

// Size: 0xed0 (Inherited: 0x1dd0, Single: 0xfffff100)
class UGA_Riding_Creature_EnergyDepleted_Base_C : public UGA_NPC_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xec8 (Size: 0x8, Type: StructProperty)

public:
    virtual void FailedToActivatePassiveAbility(FGameplayAbilityActorInfo& ActorInfo); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGA_Riding_Creature_EnergyDepleted_Base_C) == 0xed0, "Size mismatch for UGA_Riding_Creature_EnergyDepleted_Base_C");
static_assert(offsetof(UGA_Riding_Creature_EnergyDepleted_Base_C, UberGraphFrame) == 0xec8, "Offset mismatch for UGA_Riding_Creature_EnergyDepleted_Base_C::UberGraphFrame");

// Size: 0x418 (Inherited: 0xd58, Single: 0xfffff6c0)
class AGCN_Athena_LowGravity_C : public AFortGameplayCueNotifyLoop_LowGravity
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x3e0 (Size: 0x8, Type: StructProperty)
    AActor* MyTargetCached; // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle ExpireTellDelayTimer; // 0x3f0 (Size: 0x8, Type: StructProperty)
    double ExpirationSoundPeriod; // 0x3f8 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle ExpirationSoundTimer; // 0x400 (Size: 0x8, Type: StructProperty)
    double MaxDrawDistance; // 0x408 (Size: 0x8, Type: DoubleProperty)
    UFXSystemComponent* LoopingFX; // 0x410 (Size: 0x8, Type: ObjectProperty)

public:
    virtual bool WhileActive(AActor*& MyTarget, const FGameplayCueParameters Parameters); // 0x288a61c (Index: 0x3, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual bool OnRemove(AActor*& MyTarget, const FGameplayCueParameters Parameters); // 0x288a61c (Index: 0x6, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void K2_HandleGameplayCue(AActor*& MyTarget, TEnumAsByte<EGameplayCueEvent>& EventType, const FGameplayCueParameters Parameters); // 0x288a61c (Index: 0x7, Flags: Event|Public|HasOutParms|BlueprintEvent)
    void Activated(AActor*& PlayerPawn); // 0x288a61c (Index: 0x8, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AGCN_Athena_LowGravity_C) == 0x418, "Size mismatch for AGCN_Athena_LowGravity_C");
static_assert(offsetof(AGCN_Athena_LowGravity_C, UberGraphFrame) == 0x3e0, "Offset mismatch for AGCN_Athena_LowGravity_C::UberGraphFrame");
static_assert(offsetof(AGCN_Athena_LowGravity_C, MyTargetCached) == 0x3e8, "Offset mismatch for AGCN_Athena_LowGravity_C::MyTargetCached");
static_assert(offsetof(AGCN_Athena_LowGravity_C, ExpireTellDelayTimer) == 0x3f0, "Offset mismatch for AGCN_Athena_LowGravity_C::ExpireTellDelayTimer");
static_assert(offsetof(AGCN_Athena_LowGravity_C, ExpirationSoundPeriod) == 0x3f8, "Offset mismatch for AGCN_Athena_LowGravity_C::ExpirationSoundPeriod");
static_assert(offsetof(AGCN_Athena_LowGravity_C, ExpirationSoundTimer) == 0x400, "Offset mismatch for AGCN_Athena_LowGravity_C::ExpirationSoundTimer");
static_assert(offsetof(AGCN_Athena_LowGravity_C, MaxDrawDistance) == 0x408, "Offset mismatch for AGCN_Athena_LowGravity_C::MaxDrawDistance");
static_assert(offsetof(AGCN_Athena_LowGravity_C, LoopingFX) == 0x410, "Offset mismatch for AGCN_Athena_LowGravity_C::LoopingFX");

// Size: 0x420 (Inherited: 0x1170, Single: 0xfffff2b0)
class AGCN_Athena_LowGravity_ZipLine_C : public AGCN_Athena_LowGravity_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x418 (Size: 0x8, Type: StructProperty)

public:
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(AGCN_Athena_LowGravity_ZipLine_C) == 0x420, "Size mismatch for AGCN_Athena_LowGravity_ZipLine_C");
static_assert(offsetof(AGCN_Athena_LowGravity_ZipLine_C, UberGraphFrame) == 0x418, "Offset mismatch for AGCN_Athena_LowGravity_ZipLine_C::UberGraphFrame");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Generic_HealthRegen_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Generic_HealthRegen_C) == 0xa68, "Size mismatch for UGE_Generic_HealthRegen_C");

// Size: 0xb91 (Inherited: 0x1a40, Single: 0xfffff151)
class UGAB_Emote_Generic_C : public UFortGameplayAbility_Emote
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn; // 0xb40 (Size: 0x8, Type: ObjectProperty)
    double PostTriggerCancelDelay; // 0xb48 (Size: 0x8, Type: DoubleProperty)
    bool HideReticle; // 0xb50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b51[0x7]; // 0xb51 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagContainer ReticleHUDElementTags; // 0xb58 (Size: 0x20, Type: StructProperty)
    FName MontageOverrideSection; // 0xb78 (Size: 0x4, Type: NameProperty)
    bool bAbilityStopped; // 0xb7c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b7d[0x3]; // 0xb7d (Size: 0x3, Type: PaddingProperty)
    FName EmoteHolsterId; // 0xb80 (Size: 0x4, Type: NameProperty)
    bool bHolstered; // 0xb84 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b85[0x3]; // 0xb85 (Size: 0x3, Type: PaddingProperty)
    FName HUDElementVisibilityReasonName; // 0xb88 (Size: 0x4, Type: NameProperty)
    int32_t WaitForLoadedCount; // 0xb8c (Size: 0x4, Type: IntProperty)
    bool bClearInteractOnActivate; // 0xb90 (Size: 0x1, Type: BoolProperty)

public:
    void IsMontagePlaying(UAnimMontage*& Montage, bool& Result); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    TSoftObjectPtr<UAnimMontage*> GetMontageToPlay(UFortMontageItemDefinitionBase*& EmoteAsset, TEnumAsByte<EFortCustomBodyType>& BodyType, TEnumAsByte<EFortCustomGender>& Gender); // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void GetBodyTypeAndGender(TEnumAsByte<EFortCustomBodyType>& BodyType, TEnumAsByte<EFortCustomGender>& Gender); // 0x288a61c (Index: 0x3, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void ForceStopMontage(); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual bool ShouldPlayFailedMontage(const FGameplayTagContainer FailedReason) const; // 0x288a61c (Index: 0x9, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const)
    void SetReticleVisibility(bool& ShouldHide); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintCallable|BlueprintEvent)
    virtual bool K2_CanActivateAbility(FGameplayAbilityActorInfo& ActorInfo, FGameplayAbilitySpecHandle& const Handle, FGameplayTagContainer& RelevantTags) const; // 0x288a61c (Index: 0x11, Flags: Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UGAB_Emote_Generic_C) == 0xb91, "Size mismatch for UGAB_Emote_Generic_C");
static_assert(offsetof(UGAB_Emote_Generic_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGAB_Emote_Generic_C::UberGraphFrame");
static_assert(offsetof(UGAB_Emote_Generic_C, PlayerPawn) == 0xb40, "Offset mismatch for UGAB_Emote_Generic_C::PlayerPawn");
static_assert(offsetof(UGAB_Emote_Generic_C, PostTriggerCancelDelay) == 0xb48, "Offset mismatch for UGAB_Emote_Generic_C::PostTriggerCancelDelay");
static_assert(offsetof(UGAB_Emote_Generic_C, HideReticle) == 0xb50, "Offset mismatch for UGAB_Emote_Generic_C::HideReticle");
static_assert(offsetof(UGAB_Emote_Generic_C, ReticleHUDElementTags) == 0xb58, "Offset mismatch for UGAB_Emote_Generic_C::ReticleHUDElementTags");
static_assert(offsetof(UGAB_Emote_Generic_C, MontageOverrideSection) == 0xb78, "Offset mismatch for UGAB_Emote_Generic_C::MontageOverrideSection");
static_assert(offsetof(UGAB_Emote_Generic_C, bAbilityStopped) == 0xb7c, "Offset mismatch for UGAB_Emote_Generic_C::bAbilityStopped");
static_assert(offsetof(UGAB_Emote_Generic_C, EmoteHolsterId) == 0xb80, "Offset mismatch for UGAB_Emote_Generic_C::EmoteHolsterId");
static_assert(offsetof(UGAB_Emote_Generic_C, bHolstered) == 0xb84, "Offset mismatch for UGAB_Emote_Generic_C::bHolstered");
static_assert(offsetof(UGAB_Emote_Generic_C, HUDElementVisibilityReasonName) == 0xb88, "Offset mismatch for UGAB_Emote_Generic_C::HUDElementVisibilityReasonName");
static_assert(offsetof(UGAB_Emote_Generic_C, WaitForLoadedCount) == 0xb8c, "Offset mismatch for UGAB_Emote_Generic_C::WaitForLoadedCount");
static_assert(offsetof(UGAB_Emote_Generic_C, bClearInteractOnActivate) == 0xb90, "Offset mismatch for UGAB_Emote_Generic_C::bClearInteractOnActivate");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_DefaultPlayer_Tooltips_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_DefaultPlayer_Tooltips_C) == 0xa68, "Size mismatch for UGE_DefaultPlayer_Tooltips_C");

// Size: 0x230 (Inherited: 0x6c0, Single: 0xfffffb70)
class UGCNS_GM_OnDisplayEmoji_C : public UGameplayCueNotify_OnDisplayEmoji
{
public:
};

static_assert(sizeof(UGCNS_GM_OnDisplayEmoji_C) == 0x230, "Size mismatch for UGCNS_GM_OnDisplayEmoji_C");

// Size: 0x88 (Inherited: 0xc8, Single: 0xffffffc0)
class UGCNS_GM_OnDisplayChatEmoji_C : public UFortGameplayCueNotify_Simple
{
public:
    FVector ParticleRelativeOffset; // 0x68 (Size: 0x18, Type: StructProperty)
    USoundBase* BubbleSound; // 0x80 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void OnStartParticleSystemSpawned(UParticleSystemComponent*& SpawnedParticleSysComponent, const FGameplayCueParameters Parameters) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const)
    virtual bool OnRemove(AActor*& MyTarget, const FGameplayCueParameters Parameters) const; // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual bool OnExecute(AActor*& MyTarget, const FGameplayCueParameters Parameters) const; // 0x288a61c (Index: 0x2, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual bool OnActive(AActor*& MyTarget, const FGameplayCueParameters Parameters) const; // 0x288a61c (Index: 0x3, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual void K2_HandleGameplayCue(AActor*& MyTarget, TEnumAsByte<EGameplayCueEvent>& EventType, const FGameplayCueParameters Parameters) const; // 0x288a61c (Index: 0x4, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UGCNS_GM_OnDisplayChatEmoji_C) == 0x88, "Size mismatch for UGCNS_GM_OnDisplayChatEmoji_C");
static_assert(offsetof(UGCNS_GM_OnDisplayChatEmoji_C, ParticleRelativeOffset) == 0x68, "Offset mismatch for UGCNS_GM_OnDisplayChatEmoji_C::ParticleRelativeOffset");
static_assert(offsetof(UGCNS_GM_OnDisplayChatEmoji_C, BubbleSound) == 0x80, "Offset mismatch for UGCNS_GM_OnDisplayChatEmoji_C::BubbleSound");

// Size: 0x248 (Inherited: 0x6d8, Single: 0xfffffb70)
class UGCNS_GM_OnPreviewEmoji_C : public UGameplayCueNotify_OnPreviewEmoji
{
public:
};

static_assert(sizeof(UGCNS_GM_OnPreviewEmoji_C) == 0x248, "Size mismatch for UGCNS_GM_OnPreviewEmoji_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_RestoreControlResistance_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_RestoreControlResistance_C) == 0xa68, "Size mismatch for UGE_RestoreControlResistance_C");

// Size: 0xa6c (Inherited: 0x1378, Single: 0xfffff6f4)
class AGCN_Athena_Bush_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x9c8 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* OwningPlayer_BushMesh; // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    UArrowComponent* Arrow2; // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    UArrowComponent* Arrow1; // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* BushMesh; // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    UArrowComponent* Arrow; // 0x9f0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* Trail_Leaves; // 0x9f8 (Size: 0x8, Type: ObjectProperty)
    float OpacityFade_OpacityFadeOut_B989988545DAA0B2E69D77AE069A4437; // 0xa00 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> OpacityFade__Direction_B989988545DAA0B2E69D77AE069A4437; // 0xa04 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_a05[0x3]; // 0xa05 (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* OpacityFade; // 0xa08 (Size: 0x8, Type: ObjectProperty)
    AActor* PlayerPawn; // 0xa10 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* MID_Bush; // 0xa18 (Size: 0x8, Type: ObjectProperty)
    bool IsActive; // 0xa20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a21[0x7]; // 0xa21 (Size: 0x7, Type: PaddingProperty)
    UMaterialInstanceDynamic* MID_OwningClientBush; // 0xa28 (Size: 0x8, Type: ObjectProperty)
    FCurveTableRowHandle ClientBushOpacity; // 0xa30 (Size: 0x10, Type: StructProperty)
    double TargetOpacity; // 0xa40 (Size: 0x8, Type: DoubleProperty)
    UParticleSystem* BushDestructionVFX; // 0xa48 (Size: 0x8, Type: ObjectProperty)
    USoundBase* BushDestructionSFX; // 0xa50 (Size: 0x8, Type: ObjectProperty)
    UAbilityAsync_WaitGameplayTagAdded* WaitHideStart_Async; // 0xa58 (Size: 0x8, Type: ObjectProperty)
    UAbilityAsync_WaitGameplayTagRemoved* WaitHideEnd_Async; // 0xa60 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag Granted_Athena_EnvItem_HidingProp_HidingInProp; // 0xa68 (Size: 0x4, Type: StructProperty)

public:
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void OnRemoval(AActor*& MyTarget, const FGameplayCueParameters Parameters, const TArray<UParticleSystemComponent*> ParticleComponents, const TArray<UAudioComponent*> AudioComponents, ULegacyCameraShake*& BurstCameraShakeInstance, ADecalActor*& BurstDecalInstance); // 0x288a61c (Index: 0x5, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnLoopingStart(AActor*& MyTarget, const FGameplayCueParameters Parameters, const TArray<UParticleSystemComponent*> ParticleComponents, const TArray<UAudioComponent*> AudioComponents); // 0x288a61c (Index: 0x6, Flags: Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(AGCN_Athena_Bush_C) == 0xa6c, "Size mismatch for AGCN_Athena_Bush_C");
static_assert(offsetof(AGCN_Athena_Bush_C, UberGraphFrame) == 0x9c8, "Offset mismatch for AGCN_Athena_Bush_C::UberGraphFrame");
static_assert(offsetof(AGCN_Athena_Bush_C, OwningPlayer_BushMesh) == 0x9d0, "Offset mismatch for AGCN_Athena_Bush_C::OwningPlayer_BushMesh");
static_assert(offsetof(AGCN_Athena_Bush_C, Arrow2) == 0x9d8, "Offset mismatch for AGCN_Athena_Bush_C::Arrow2");
static_assert(offsetof(AGCN_Athena_Bush_C, Arrow1) == 0x9e0, "Offset mismatch for AGCN_Athena_Bush_C::Arrow1");
static_assert(offsetof(AGCN_Athena_Bush_C, BushMesh) == 0x9e8, "Offset mismatch for AGCN_Athena_Bush_C::BushMesh");
static_assert(offsetof(AGCN_Athena_Bush_C, Arrow) == 0x9f0, "Offset mismatch for AGCN_Athena_Bush_C::Arrow");
static_assert(offsetof(AGCN_Athena_Bush_C, Trail_Leaves) == 0x9f8, "Offset mismatch for AGCN_Athena_Bush_C::Trail_Leaves");
static_assert(offsetof(AGCN_Athena_Bush_C, OpacityFade_OpacityFadeOut_B989988545DAA0B2E69D77AE069A4437) == 0xa00, "Offset mismatch for AGCN_Athena_Bush_C::OpacityFade_OpacityFadeOut_B989988545DAA0B2E69D77AE069A4437");
static_assert(offsetof(AGCN_Athena_Bush_C, OpacityFade__Direction_B989988545DAA0B2E69D77AE069A4437) == 0xa04, "Offset mismatch for AGCN_Athena_Bush_C::OpacityFade__Direction_B989988545DAA0B2E69D77AE069A4437");
static_assert(offsetof(AGCN_Athena_Bush_C, OpacityFade) == 0xa08, "Offset mismatch for AGCN_Athena_Bush_C::OpacityFade");
static_assert(offsetof(AGCN_Athena_Bush_C, PlayerPawn) == 0xa10, "Offset mismatch for AGCN_Athena_Bush_C::PlayerPawn");
static_assert(offsetof(AGCN_Athena_Bush_C, MID_Bush) == 0xa18, "Offset mismatch for AGCN_Athena_Bush_C::MID_Bush");
static_assert(offsetof(AGCN_Athena_Bush_C, IsActive) == 0xa20, "Offset mismatch for AGCN_Athena_Bush_C::IsActive");
static_assert(offsetof(AGCN_Athena_Bush_C, MID_OwningClientBush) == 0xa28, "Offset mismatch for AGCN_Athena_Bush_C::MID_OwningClientBush");
static_assert(offsetof(AGCN_Athena_Bush_C, ClientBushOpacity) == 0xa30, "Offset mismatch for AGCN_Athena_Bush_C::ClientBushOpacity");
static_assert(offsetof(AGCN_Athena_Bush_C, TargetOpacity) == 0xa40, "Offset mismatch for AGCN_Athena_Bush_C::TargetOpacity");
static_assert(offsetof(AGCN_Athena_Bush_C, BushDestructionVFX) == 0xa48, "Offset mismatch for AGCN_Athena_Bush_C::BushDestructionVFX");
static_assert(offsetof(AGCN_Athena_Bush_C, BushDestructionSFX) == 0xa50, "Offset mismatch for AGCN_Athena_Bush_C::BushDestructionSFX");
static_assert(offsetof(AGCN_Athena_Bush_C, WaitHideStart_Async) == 0xa58, "Offset mismatch for AGCN_Athena_Bush_C::WaitHideStart_Async");
static_assert(offsetof(AGCN_Athena_Bush_C, WaitHideEnd_Async) == 0xa60, "Offset mismatch for AGCN_Athena_Bush_C::WaitHideEnd_Async");
static_assert(offsetof(AGCN_Athena_Bush_C, Granted_Athena_EnvItem_HidingProp_HidingInProp) == 0xa68, "Offset mismatch for AGCN_Athena_Bush_C::Granted_Athena_EnvItem_HidingProp_HidingInProp");

// Size: 0x230 (Inherited: 0x6c0, Single: 0xfffffb70)
class UGCNS_GM_OnDisplayNiagaraEmoji_C : public UGameplayCueNotify_OnDisplayEmoji
{
public:
};

static_assert(sizeof(UGCNS_GM_OnDisplayNiagaraEmoji_C) == 0x230, "Size mismatch for UGCNS_GM_OnDisplayNiagaraEmoji_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_TrapArmGeneric_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_TrapArmGeneric_C) == 0xa68, "Size mismatch for UGE_TrapArmGeneric_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_HealthRegen_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_HealthRegen_C) == 0xa68, "Size mismatch for UGE_HealthRegen_C");

// Size: 0xb44 (Inherited: 0xf08, Single: 0xfffffc3c)
class UGA_TrapBuildGeneric_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    FGameplayTag PlacedCue; // 0xb40 (Size: 0x4, Type: StructProperty)

protected:
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGA_TrapBuildGeneric_C) == 0xb44, "Size mismatch for UGA_TrapBuildGeneric_C");
static_assert(offsetof(UGA_TrapBuildGeneric_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGA_TrapBuildGeneric_C::UberGraphFrame");
static_assert(offsetof(UGA_TrapBuildGeneric_C, PlacedCue) == 0xb40, "Offset mismatch for UGA_TrapBuildGeneric_C::PlacedCue");

// Size: 0xa50 (Inherited: 0x1378, Single: 0xfffff6d8)
class AGCNL_Athena_Tether_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x9c8 (Size: 0x8, Type: StructProperty)
    UFortLayeredAudioComponent* FortLayeredAudio; // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* LandFX; // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* WaterFX; // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* RightSki; // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* LeftSki; // 0x9f0 (Size: 0x8, Type: ObjectProperty)
    float ScaleInSkis_SkiScalar_93783D4A4F91BF9F887B16977978DDB4; // 0x9f8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> ScaleInSkis__Direction_93783D4A4F91BF9F887B16977978DDB4; // 0x9fc (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_9fd[0x3]; // 0x9fd (Size: 0x3, Type: PaddingProperty)
    UTimelineComponent* ScaleInSkis; // 0xa00 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* OwningFPP; // 0xa08 (Size: 0x8, Type: ObjectProperty)
    bool IsInWater; // 0xa10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a11[0x7]; // 0xa11 (Size: 0x7, Type: PaddingProperty)
    double NormalizedSpeed; // 0xa18 (Size: 0x8, Type: DoubleProperty)
    double TurnSpeed; // 0xa20 (Size: 0x8, Type: DoubleProperty)
    double ForceFeedbackIntensity; // 0xa28 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle ScaleInSkisTimerHandle; // 0xa30 (Size: 0x8, Type: StructProperty)
    double SkiScaleInDelay; // 0xa38 (Size: 0x8, Type: DoubleProperty)
    TScriptInterface<Class> CameraLensEffectInterface; // 0xa40 (Size: 0x10, Type: InterfaceProperty)

public:
    virtual bool WhileActive(AActor*& MyTarget, const FGameplayCueParameters Parameters); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void UpdateAudio(int32_t& Surface); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void ReceiveTick(float& DeltaSeconds); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)
    virtual bool OnRemove(AActor*& MyTarget, const FGameplayCueParameters Parameters); // 0x288a61c (Index: 0xa, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void OnRemoval(AActor*& MyTarget, const FGameplayCueParameters Parameters, const TArray<UParticleSystemComponent*> ParticleComponents, const TArray<UAudioComponent*> AudioComponents, ULegacyCameraShake*& BurstCameraShakeInstance, ADecalActor*& BurstDecalInstance); // 0x288a61c (Index: 0xb, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void OnApplication(AActor*& MyTarget, const FGameplayCueParameters Parameters, const TArray<UParticleSystemComponent*> ParticleComponents, const TArray<UAudioComponent*> AudioComponents, ULegacyCameraShake*& BurstCameraShakeInstance, ADecalActor*& BurstDecalInstance); // 0x288a61c (Index: 0xc, Flags: Event|Public|HasOutParms|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(AGCNL_Athena_Tether_C) == 0xa50, "Size mismatch for AGCNL_Athena_Tether_C");
static_assert(offsetof(AGCNL_Athena_Tether_C, UberGraphFrame) == 0x9c8, "Offset mismatch for AGCNL_Athena_Tether_C::UberGraphFrame");
static_assert(offsetof(AGCNL_Athena_Tether_C, FortLayeredAudio) == 0x9d0, "Offset mismatch for AGCNL_Athena_Tether_C::FortLayeredAudio");
static_assert(offsetof(AGCNL_Athena_Tether_C, LandFX) == 0x9d8, "Offset mismatch for AGCNL_Athena_Tether_C::LandFX");
static_assert(offsetof(AGCNL_Athena_Tether_C, WaterFX) == 0x9e0, "Offset mismatch for AGCNL_Athena_Tether_C::WaterFX");
static_assert(offsetof(AGCNL_Athena_Tether_C, RightSki) == 0x9e8, "Offset mismatch for AGCNL_Athena_Tether_C::RightSki");
static_assert(offsetof(AGCNL_Athena_Tether_C, LeftSki) == 0x9f0, "Offset mismatch for AGCNL_Athena_Tether_C::LeftSki");
static_assert(offsetof(AGCNL_Athena_Tether_C, ScaleInSkis_SkiScalar_93783D4A4F91BF9F887B16977978DDB4) == 0x9f8, "Offset mismatch for AGCNL_Athena_Tether_C::ScaleInSkis_SkiScalar_93783D4A4F91BF9F887B16977978DDB4");
static_assert(offsetof(AGCNL_Athena_Tether_C, ScaleInSkis__Direction_93783D4A4F91BF9F887B16977978DDB4) == 0x9fc, "Offset mismatch for AGCNL_Athena_Tether_C::ScaleInSkis__Direction_93783D4A4F91BF9F887B16977978DDB4");
static_assert(offsetof(AGCNL_Athena_Tether_C, ScaleInSkis) == 0xa00, "Offset mismatch for AGCNL_Athena_Tether_C::ScaleInSkis");
static_assert(offsetof(AGCNL_Athena_Tether_C, OwningFPP) == 0xa08, "Offset mismatch for AGCNL_Athena_Tether_C::OwningFPP");
static_assert(offsetof(AGCNL_Athena_Tether_C, IsInWater) == 0xa10, "Offset mismatch for AGCNL_Athena_Tether_C::IsInWater");
static_assert(offsetof(AGCNL_Athena_Tether_C, NormalizedSpeed) == 0xa18, "Offset mismatch for AGCNL_Athena_Tether_C::NormalizedSpeed");
static_assert(offsetof(AGCNL_Athena_Tether_C, TurnSpeed) == 0xa20, "Offset mismatch for AGCNL_Athena_Tether_C::TurnSpeed");
static_assert(offsetof(AGCNL_Athena_Tether_C, ForceFeedbackIntensity) == 0xa28, "Offset mismatch for AGCNL_Athena_Tether_C::ForceFeedbackIntensity");
static_assert(offsetof(AGCNL_Athena_Tether_C, ScaleInSkisTimerHandle) == 0xa30, "Offset mismatch for AGCNL_Athena_Tether_C::ScaleInSkisTimerHandle");
static_assert(offsetof(AGCNL_Athena_Tether_C, SkiScaleInDelay) == 0xa38, "Offset mismatch for AGCNL_Athena_Tether_C::SkiScaleInDelay");
static_assert(offsetof(AGCNL_Athena_Tether_C, CameraLensEffectInterface) == 0xa40, "Offset mismatch for AGCNL_Athena_Tether_C::CameraLensEffectInterface");

// Size: 0xb91 (Inherited: 0x25d1, Single: 0xffffe5c0)
class UGAB_Emote_Generic_Transformation_C : public UGAB_Emote_Generic_C
{
public:
};

static_assert(sizeof(UGAB_Emote_Generic_Transformation_C) == 0xb91, "Size mismatch for UGAB_Emote_Generic_Transformation_C");

// Size: 0x4dd0 (Inherited: 0x7990, Single: 0xffffd440)
class APlayerPawn_Generic_Parent_C : public AFortPlayerPawn
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x4cf0 (Size: 0x8, Type: StructProperty)
    TArray<UMaterialInterface*> Default_Weapon_Materials; // 0x4cf8 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnBackpackMaterials; // 0x4d08 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnHatMaterials; // 0x4d18 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnHeadMaterials; // 0x4d28 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnBodyMaterials; // 0x4d38 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnCharmMaterials; // 0x4d48 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnFaceMaterials; // 0x4d58 (Size: 0x10, Type: ArrayProperty)
    UPostProcessComponent* PlayerPostProcessFX; // 0x4d68 (Size: 0x8, Type: ObjectProperty)
    TArray<USkeletalMeshComponent*> SkeletalMeshes; // 0x4d70 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnMaterials_ALL; // 0x4d80 (Size: 0x10, Type: ArrayProperty)
    int32_t WaterCounter; // 0x4d90 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4d94[0x4]; // 0x4d94 (Size: 0x4, Type: PaddingProperty)
    AActor* CurrentWaterMeshActor; // 0x4d98 (Size: 0x8, Type: ObjectProperty)
    bool IsInWater; // 0x4da0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4da1[0x7]; // 0x4da1 (Size: 0x7, Type: PaddingProperty)
    double Time_when_you_ll_be_able_to_splash_again; // 0x4da8 (Size: 0x8, Type: DoubleProperty)
    uint8_t OnOverlapWaterVolume[0x10]; // 0x4db0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<FCharacterPartMidArrayStruct> PawnPartMaterials; // 0x4dc0 (Size: 0x10, Type: ArrayProperty)

public:
    void Find_Stored_Char_Part_Materials(TEnumAsByte<EFortCustomPartType>& PartType, bool& Found, int32_t& Index, TArray<UMaterialInstanceDynamic*>& MIDs); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void OnOverlapWaterVolume__DelegateSignature(bool& bIsInWater, AFortPlayerPawn*& Pawn, AActor*& Water); // 0x288a61c (Index: 0x2, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)

protected:
    virtual void ReceiveBeginPlay(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(APlayerPawn_Generic_Parent_C) == 0x4dd0, "Size mismatch for APlayerPawn_Generic_Parent_C");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, UberGraphFrame) == 0x4cf0, "Offset mismatch for APlayerPawn_Generic_Parent_C::UberGraphFrame");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, Default_Weapon_Materials) == 0x4cf8, "Offset mismatch for APlayerPawn_Generic_Parent_C::Default_Weapon_Materials");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, PawnBackpackMaterials) == 0x4d08, "Offset mismatch for APlayerPawn_Generic_Parent_C::PawnBackpackMaterials");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, PawnHatMaterials) == 0x4d18, "Offset mismatch for APlayerPawn_Generic_Parent_C::PawnHatMaterials");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, PawnHeadMaterials) == 0x4d28, "Offset mismatch for APlayerPawn_Generic_Parent_C::PawnHeadMaterials");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, PawnBodyMaterials) == 0x4d38, "Offset mismatch for APlayerPawn_Generic_Parent_C::PawnBodyMaterials");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, PawnCharmMaterials) == 0x4d48, "Offset mismatch for APlayerPawn_Generic_Parent_C::PawnCharmMaterials");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, PawnFaceMaterials) == 0x4d58, "Offset mismatch for APlayerPawn_Generic_Parent_C::PawnFaceMaterials");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, PlayerPostProcessFX) == 0x4d68, "Offset mismatch for APlayerPawn_Generic_Parent_C::PlayerPostProcessFX");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, SkeletalMeshes) == 0x4d70, "Offset mismatch for APlayerPawn_Generic_Parent_C::SkeletalMeshes");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, PawnMaterials_ALL) == 0x4d80, "Offset mismatch for APlayerPawn_Generic_Parent_C::PawnMaterials_ALL");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, WaterCounter) == 0x4d90, "Offset mismatch for APlayerPawn_Generic_Parent_C::WaterCounter");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, CurrentWaterMeshActor) == 0x4d98, "Offset mismatch for APlayerPawn_Generic_Parent_C::CurrentWaterMeshActor");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, IsInWater) == 0x4da0, "Offset mismatch for APlayerPawn_Generic_Parent_C::IsInWater");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, Time_when_you_ll_be_able_to_splash_again) == 0x4da8, "Offset mismatch for APlayerPawn_Generic_Parent_C::Time_when_you_ll_be_able_to_splash_again");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, OnOverlapWaterVolume) == 0x4db0, "Offset mismatch for APlayerPawn_Generic_Parent_C::OnOverlapWaterVolume");
static_assert(offsetof(APlayerPawn_Generic_Parent_C, PawnPartMaterials) == 0x4dc0, "Offset mismatch for APlayerPawn_Generic_Parent_C::PawnPartMaterials");

// Size: 0xbf8 (Inherited: 0x25d1, Single: 0xffffe627)
class UGAB_Spray_Generic_C : public UGAB_Emote_Generic_C
{
public:
    uint8_t Pad_b91[0x7]; // 0xb91 (Size: 0x7, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0xb98 (Size: 0x8, Type: StructProperty)
    double DecalSize; // 0xba0 (Size: 0x8, Type: DoubleProperty)
    UAthenaSprayItemDefinition* MySpray; // 0xba8 (Size: 0x8, Type: ObjectProperty)
    double DecalTraceDistance; // 0xbb0 (Size: 0x8, Type: DoubleProperty)
    TSoftObjectPtr<UAnimMontage*> DefaultSprayMontage_M; // 0xbb8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UAnimMontage*> DefaultSprayMontage_F; // 0xbd8 (Size: 0x20, Type: SoftObjectProperty)

public:
    void TargetLineTrace(AFortPawn*& ActivatingPawn, bool& HitSomething, FVector& Location, FVector& Normal); // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void HasNoSprayGameplayTag(AActor*& HitActor, UPrimitiveComponent*& HitComponent, bool& Result) const; // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    TSoftObjectPtr<UAnimMontage*> GetMontageToPlay(UFortMontageItemDefinitionBase*& EmoteAsset, TEnumAsByte<EFortCustomBodyType>& BodyType, TEnumAsByte<EFortCustomGender>& Gender); // 0x288a61c (Index: 0x3, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UGAB_Spray_Generic_C) == 0xbf8, "Size mismatch for UGAB_Spray_Generic_C");
static_assert(offsetof(UGAB_Spray_Generic_C, UberGraphFrame) == 0xb98, "Offset mismatch for UGAB_Spray_Generic_C::UberGraphFrame");
static_assert(offsetof(UGAB_Spray_Generic_C, DecalSize) == 0xba0, "Offset mismatch for UGAB_Spray_Generic_C::DecalSize");
static_assert(offsetof(UGAB_Spray_Generic_C, MySpray) == 0xba8, "Offset mismatch for UGAB_Spray_Generic_C::MySpray");
static_assert(offsetof(UGAB_Spray_Generic_C, DecalTraceDistance) == 0xbb0, "Offset mismatch for UGAB_Spray_Generic_C::DecalTraceDistance");
static_assert(offsetof(UGAB_Spray_Generic_C, DefaultSprayMontage_M) == 0xbb8, "Offset mismatch for UGAB_Spray_Generic_C::DefaultSprayMontage_M");
static_assert(offsetof(UGAB_Spray_Generic_C, DefaultSprayMontage_F) == 0xbd8, "Offset mismatch for UGAB_Spray_Generic_C::DefaultSprayMontage_F");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_TransferKnockback_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_TransferKnockback_C) == 0xa68, "Size mismatch for UGE_TransferKnockback_C");

// Size: 0xba9 (Inherited: 0xf08, Single: 0xfffffca1)
class UGAB_GenericApplyFullBodyHit_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    UClass* GE_FullBodyHitActiveEffect; // 0xb40 (Size: 0x8, Type: ClassProperty)
    FVector HitImpulse; // 0xb48 (Size: 0x18, Type: StructProperty)
    UClass* GE_RestoreControlResistance; // 0xb60 (Size: 0x8, Type: ClassProperty)
    FActiveGameplayEffectHandle ActiveImpactImmunity; // 0xb68 (Size: 0x8, Type: StructProperty)
    UClass* GE_ImpactImmunity; // 0xb70 (Size: 0x8, Type: ClassProperty)
    FActiveGameplayEffectHandle ActiveFullBodyHit; // 0xb78 (Size: 0x8, Type: StructProperty)
    FGameplayTag Event_Triggered_FullBodyHit; // 0xb80 (Size: 0x4, Type: StructProperty)
    FGameplayTag Event_Control_Ended; // 0xb84 (Size: 0x4, Type: StructProperty)
    UClass* GE_TransferFullBodyHit; // 0xb88 (Size: 0x8, Type: ClassProperty)
    UAnimMontage* FullBodyHitMontage; // 0xb90 (Size: 0x8, Type: ObjectProperty)
    FName FullBodyHitMontageSection; // 0xb98 (Size: 0x4, Type: NameProperty)
    bool EndAbilityOnBlendOut; // 0xb9c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9d[0x3]; // 0xb9d (Size: 0x3, Type: PaddingProperty)
    double Duration_NoAnim; // 0xba0 (Size: 0x8, Type: DoubleProperty)
    bool DebugFullBodyHitReact; // 0xba8 (Size: 0x1, Type: BoolProperty)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual bool K2_CanActivateAbility(FGameplayAbilityActorInfo& ActorInfo, FGameplayAbilitySpecHandle& const Handle, FGameplayTagContainer& RelevantTags) const; // 0x288a61c (Index: 0x8, Flags: Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const)
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0x9, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGAB_GenericApplyFullBodyHit_C) == 0xba9, "Size mismatch for UGAB_GenericApplyFullBodyHit_C");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::UberGraphFrame");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, GE_FullBodyHitActiveEffect) == 0xb40, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::GE_FullBodyHitActiveEffect");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, HitImpulse) == 0xb48, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::HitImpulse");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, GE_RestoreControlResistance) == 0xb60, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::GE_RestoreControlResistance");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, ActiveImpactImmunity) == 0xb68, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::ActiveImpactImmunity");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, GE_ImpactImmunity) == 0xb70, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::GE_ImpactImmunity");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, ActiveFullBodyHit) == 0xb78, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::ActiveFullBodyHit");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, Event_Triggered_FullBodyHit) == 0xb80, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::Event_Triggered_FullBodyHit");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, Event_Control_Ended) == 0xb84, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::Event_Control_Ended");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, GE_TransferFullBodyHit) == 0xb88, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::GE_TransferFullBodyHit");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, FullBodyHitMontage) == 0xb90, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::FullBodyHitMontage");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, FullBodyHitMontageSection) == 0xb98, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::FullBodyHitMontageSection");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, EndAbilityOnBlendOut) == 0xb9c, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::EndAbilityOnBlendOut");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, Duration_NoAnim) == 0xba0, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::Duration_NoAnim");
static_assert(offsetof(UGAB_GenericApplyFullBodyHit_C, DebugFullBodyHitReact) == 0xba8, "Offset mismatch for UGAB_GenericApplyFullBodyHit_C::DebugFullBodyHitReact");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_TransferFullBodyHit_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_TransferFullBodyHit_C) == 0xa68, "Size mismatch for UGE_TransferFullBodyHit_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Generic_ShieldRegen_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Generic_ShieldRegen_C) == 0xa68, "Size mismatch for UGE_Generic_ShieldRegen_C");

// Size: 0x1f0 (Inherited: 0x2f8, Single: 0xfffffef8)
class UB_GrenadeCameraShake_C : public ULegacyCameraShake
{
public:
};

static_assert(sizeof(UB_GrenadeCameraShake_C) == 0x1f0, "Size mismatch for UB_GrenadeCameraShake_C");

// Size: 0xbd8 (Inherited: 0x2698, Single: 0xffffe540)
class UGAB_ThrowPlayer_C : public UFortGameplayAbility_CarryPlayer
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xbc8 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn; // 0xbd0 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGAB_ThrowPlayer_C) == 0xbd8, "Size mismatch for UGAB_ThrowPlayer_C");
static_assert(offsetof(UGAB_ThrowPlayer_C, UberGraphFrame) == 0xbc8, "Offset mismatch for UGAB_ThrowPlayer_C::UberGraphFrame");
static_assert(offsetof(UGAB_ThrowPlayer_C, PlayerPawn) == 0xbd0, "Offset mismatch for UGAB_ThrowPlayer_C::PlayerPawn");

// Size: 0xfc0 (Inherited: 0xf08, Single: 0xb8)
class UGAB_InterrogatePlayer_Reveal_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn; // 0xb40 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerControllerAthena* PlayerController; // 0xb48 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* InterrogatedPlayer; // 0xb50 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Anim_Reveal; // 0xb58 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Anim_End; // 0xb60 (Size: 0x8, Type: ObjectProperty)
    FName RevealHolster; // 0xb68 (Size: 0x4, Type: NameProperty)
    FGameplayTag GC_Reveal; // 0xb6c (Size: 0x4, Type: StructProperty)
    FScalableFloat MarkDurationPlayer; // 0xb70 (Size: 0x28, Type: StructProperty)
    FScalableFloat MarkDurationNPC; // 0xb98 (Size: 0x28, Type: StructProperty)
    FScalableFloat MarkRadius; // 0xbc0 (Size: 0x28, Type: StructProperty)
    TArray<AActor*> SquadmatesToMark; // 0xbe8 (Size: 0x10, Type: ArrayProperty)
    FTimerHandle Timer_Reveal; // 0xbf8 (Size: 0x8, Type: StructProperty)
    FGameplayTag T_NPC; // 0xc00 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c04[0x4]; // 0xc04 (Size: 0x4, Type: PaddingProperty)
    double RevealDuration; // 0xc08 (Size: 0x8, Type: DoubleProperty)
    double EndAbilityDelay; // 0xc10 (Size: 0x8, Type: DoubleProperty)
    double SweepDelay; // 0xc18 (Size: 0x8, Type: DoubleProperty)
    bool Ending; // 0xc20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c21[0x7]; // 0xc21 (Size: 0x7, Type: PaddingProperty)
    FString IndicatorGroup; // 0xc28 (Size: 0x10, Type: StrProperty)
    UClass* CameraMode; // 0xc38 (Size: 0x8, Type: ClassProperty)
    TArray<AActor*> ActorsToMark; // 0xc40 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer T_ReticleHUD; // 0xc50 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer NPCTagsToMark; // 0xc70 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ChestTagsToMark; // 0xc90 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer GameplayItemTagsToMark; // 0xcb0 (Size: 0x20, Type: StructProperty)
    FName ParticleSystemParamName; // 0xcd0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_cd4[0x4]; // 0xcd4 (Size: 0x4, Type: PaddingProperty)
    UParticleSystem* IndicatedPS; // 0xcd8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* IndicatedSound; // 0xce0 (Size: 0x8, Type: ObjectProperty)
    FVector PSOffset; // 0xce8 (Size: 0x18, Type: StructProperty)
    FName PSVectorParamName; // 0xd00 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_d04[0x4]; // 0xd04 (Size: 0x4, Type: PaddingProperty)
    FVector PSDBNOOffset; // 0xd08 (Size: 0x18, Type: StructProperty)
    FName EnemyStencilName; // 0xd20 (Size: 0x4, Type: NameProperty)
    FName TreasureChestStencilName; // 0xd24 (Size: 0x4, Type: NameProperty)
    double StepTime; // 0xd28 (Size: 0x8, Type: DoubleProperty)
    bool testbool; // 0xd30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d31[0x7]; // 0xd31 (Size: 0x7, Type: PaddingProperty)
    FScalableFloat EnemyStencilID; // 0xd38 (Size: 0x28, Type: StructProperty)
    FScalableFloat StencilStepTime; // 0xd60 (Size: 0x28, Type: StructProperty)
    FScalableFloat bUseDefaultStencil; // 0xd88 (Size: 0x28, Type: StructProperty)
    FScalableFloat IndicatorStepTime; // 0xdb0 (Size: 0x28, Type: StructProperty)
    FGameplayTagQuery NPCGameplayTagQuery; // 0xdd8 (Size: 0x48, Type: StructProperty)
    FIndicatedActorData IndicatedActorDataPlayers; // 0xe20 (Size: 0x100, Type: StructProperty)
    FStenciledActorData StenciledActorDataPlayers; // 0xf20 (Size: 0x80, Type: StructProperty)
    FGameplayTagContainer T_QuestTagContainer; // 0xfa0 (Size: 0x20, Type: StructProperty)

public:
    void ToggleReticleVisibility(bool& Hide); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Reveal(); // 0x288a61c (Index: 0x6, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void InitAbility(); // 0x288a61c (Index: 0xb, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    TArray<AFortPlayerStateAthena*> GetTeamMembers(APawn*& Target, bool& bIncludeSelf); // 0x288a61c (Index: 0xc, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void GAB_InterrogatePlayer_Reveal_AutoGenFunc(AActor*& IndicatedActor); // 0x288a61c (Index: 0xd, Flags: Public|BlueprintCallable|BlueprintEvent)
    void EndAbilityCleanup(); // 0x288a61c (Index: 0x10, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0xa, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGAB_InterrogatePlayer_Reveal_C) == 0xfc0, "Size mismatch for UGAB_InterrogatePlayer_Reveal_C");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::UberGraphFrame");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, PlayerPawn) == 0xb40, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::PlayerPawn");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, PlayerController) == 0xb48, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::PlayerController");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, InterrogatedPlayer) == 0xb50, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::InterrogatedPlayer");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, Anim_Reveal) == 0xb58, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::Anim_Reveal");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, Anim_End) == 0xb60, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::Anim_End");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, RevealHolster) == 0xb68, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::RevealHolster");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, GC_Reveal) == 0xb6c, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::GC_Reveal");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, MarkDurationPlayer) == 0xb70, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::MarkDurationPlayer");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, MarkDurationNPC) == 0xb98, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::MarkDurationNPC");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, MarkRadius) == 0xbc0, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::MarkRadius");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, SquadmatesToMark) == 0xbe8, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::SquadmatesToMark");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, Timer_Reveal) == 0xbf8, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::Timer_Reveal");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, T_NPC) == 0xc00, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::T_NPC");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, RevealDuration) == 0xc08, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::RevealDuration");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, EndAbilityDelay) == 0xc10, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::EndAbilityDelay");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, SweepDelay) == 0xc18, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::SweepDelay");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, Ending) == 0xc20, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::Ending");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, IndicatorGroup) == 0xc28, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::IndicatorGroup");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, CameraMode) == 0xc38, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::CameraMode");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, ActorsToMark) == 0xc40, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::ActorsToMark");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, T_ReticleHUD) == 0xc50, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::T_ReticleHUD");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, NPCTagsToMark) == 0xc70, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::NPCTagsToMark");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, ChestTagsToMark) == 0xc90, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::ChestTagsToMark");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, GameplayItemTagsToMark) == 0xcb0, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::GameplayItemTagsToMark");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, ParticleSystemParamName) == 0xcd0, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::ParticleSystemParamName");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, IndicatedPS) == 0xcd8, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::IndicatedPS");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, IndicatedSound) == 0xce0, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::IndicatedSound");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, PSOffset) == 0xce8, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::PSOffset");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, PSVectorParamName) == 0xd00, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::PSVectorParamName");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, PSDBNOOffset) == 0xd08, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::PSDBNOOffset");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, EnemyStencilName) == 0xd20, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::EnemyStencilName");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, TreasureChestStencilName) == 0xd24, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::TreasureChestStencilName");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, StepTime) == 0xd28, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::StepTime");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, testbool) == 0xd30, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::testbool");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, EnemyStencilID) == 0xd38, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::EnemyStencilID");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, StencilStepTime) == 0xd60, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::StencilStepTime");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, bUseDefaultStencil) == 0xd88, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::bUseDefaultStencil");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, IndicatorStepTime) == 0xdb0, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::IndicatorStepTime");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, NPCGameplayTagQuery) == 0xdd8, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::NPCGameplayTagQuery");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, IndicatedActorDataPlayers) == 0xe20, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::IndicatedActorDataPlayers");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, StenciledActorDataPlayers) == 0xf20, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::StenciledActorDataPlayers");
static_assert(offsetof(UGAB_InterrogatePlayer_Reveal_C, T_QuestTagContainer) == 0xfa0, "Offset mismatch for UGAB_InterrogatePlayer_Reveal_C::T_QuestTagContainer");

// Size: 0xd88 (Inherited: 0x1c90, Single: 0xfffff0f8)
class UGA_DefaultPlayer_InteractReboot_C : public UGA_DefaultPlayer_InteractSearch_C
{
public:

public:
    void StartInteractSearch(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UGA_DefaultPlayer_InteractReboot_C) == 0xd88, "Size mismatch for UGA_DefaultPlayer_InteractReboot_C");

// Size: 0xd88 (Inherited: 0x1c90, Single: 0xfffff0f8)
class UGA_DefaultPlayer_InteractDBNO_C : public UGA_DefaultPlayer_InteractSearch_C
{
public:

public:
    void StartInteractSearch(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UGA_DefaultPlayer_InteractDBNO_C) == 0xd88, "Size mismatch for UGA_DefaultPlayer_InteractDBNO_C");

// Size: 0xd88 (Inherited: 0xf08, Single: 0xfffffe80)
class UGA_DefaultPlayer_InteractSearch_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn; // 0xb40 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag RefillGasTankTag; // 0xb48 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_b4c[0x4]; // 0xb4c (Size: 0x4, Type: PaddingProperty)
    FFortGameplayAbilityMontageInfo RefillGasTankMontage; // 0xb50 (Size: 0x58, Type: StructProperty)
    FGameplayTag CatchFireflyTag; // 0xba8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_bac[0x4]; // 0xbac (Size: 0x4, Type: PaddingProperty)
    FFortGameplayAbilityMontageInfo FireflyCatchMontage; // 0xbb0 (Size: 0x58, Type: StructProperty)
    FFortGameplayAbilityMontageInfo RefillVehicleFuelMontage; // 0xc08 (Size: 0x58, Type: StructProperty)
    FGameplayTag GasCanRefillVehicleTag; // 0xc60 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c64[0x4]; // 0xc64 (Size: 0x4, Type: PaddingProperty)
    FFortGameplayAbilityMontageInfo DBNOMontageInfo; // 0xc68 (Size: 0x58, Type: StructProperty)
    FGameplayTag Tag_UseOverrideSearchMontage; // 0xcc0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_cc4[0x4]; // 0xcc4 (Size: 0x4, Type: PaddingProperty)
    FFortGameplayAbilityMontageInfo OverrideSearchMontageInfo; // 0xcc8 (Size: 0x58, Type: StructProperty)
    FGameplayTag TagSkipInteractSearchMontage; // 0xd20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_d24[0x4]; // 0xd24 (Size: 0x4, Type: PaddingProperty)
    FFortGameplayAbilityMontageInfo SearchFPMontageInfo; // 0xd28 (Size: 0x58, Type: StructProperty)
    AFortPlayerController* Fort_Player_Controller; // 0xd80 (Size: 0x8, Type: ObjectProperty)

public:
    void StartInteractSearch(); // 0x288a61c (Index: 0x13, Flags: Public|BlueprintCallable|BlueprintEvent)
    void EndInteractSearch(); // 0x288a61c (Index: 0x17, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x14, Flags: Event|Protected|BlueprintCallable|BlueprintEvent)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x15, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGA_DefaultPlayer_InteractSearch_C) == 0xd88, "Size mismatch for UGA_DefaultPlayer_InteractSearch_C");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::UberGraphFrame");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, PlayerPawn) == 0xb40, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::PlayerPawn");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, RefillGasTankTag) == 0xb48, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::RefillGasTankTag");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, RefillGasTankMontage) == 0xb50, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::RefillGasTankMontage");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, CatchFireflyTag) == 0xba8, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::CatchFireflyTag");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, FireflyCatchMontage) == 0xbb0, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::FireflyCatchMontage");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, RefillVehicleFuelMontage) == 0xc08, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::RefillVehicleFuelMontage");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, GasCanRefillVehicleTag) == 0xc60, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::GasCanRefillVehicleTag");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, DBNOMontageInfo) == 0xc68, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::DBNOMontageInfo");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, Tag_UseOverrideSearchMontage) == 0xcc0, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::Tag_UseOverrideSearchMontage");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, OverrideSearchMontageInfo) == 0xcc8, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::OverrideSearchMontageInfo");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, TagSkipInteractSearchMontage) == 0xd20, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::TagSkipInteractSearchMontage");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, SearchFPMontageInfo) == 0xd28, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::SearchFPMontageInfo");
static_assert(offsetof(UGA_DefaultPlayer_InteractSearch_C, Fort_Player_Controller) == 0xd80, "Offset mismatch for UGA_DefaultPlayer_InteractSearch_C::Fort_Player_Controller");

// Size: 0xd38 (Inherited: 0x1c2c, Single: 0xfffff10c)
class UGA_DefaultPlayer_Death_C : public UGAB_GenericDeath_C
{
public:
    uint8_t Pad_d24[0x4]; // 0xd24 (Size: 0x4, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0xd28 (Size: 0x8, Type: StructProperty)
    FGameplayTag FadeCapsuleStWCue; // 0xd30 (Size: 0x4, Type: StructProperty)
    FGameplayTag FadeCapsuleAthenaCue; // 0xd34 (Size: 0x4, Type: StructProperty)

};

static_assert(sizeof(UGA_DefaultPlayer_Death_C) == 0xd38, "Size mismatch for UGA_DefaultPlayer_Death_C");
static_assert(offsetof(UGA_DefaultPlayer_Death_C, UberGraphFrame) == 0xd28, "Offset mismatch for UGA_DefaultPlayer_Death_C::UberGraphFrame");
static_assert(offsetof(UGA_DefaultPlayer_Death_C, FadeCapsuleStWCue) == 0xd30, "Offset mismatch for UGA_DefaultPlayer_Death_C::FadeCapsuleStWCue");
static_assert(offsetof(UGA_DefaultPlayer_Death_C, FadeCapsuleAthenaCue) == 0xd34, "Offset mismatch for UGA_DefaultPlayer_Death_C::FadeCapsuleAthenaCue");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Resist_Damage_AoE_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Resist_Damage_AoE_C) == 0xa68, "Size mismatch for UGE_Resist_Damage_AoE_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Generic_StaminaRegenLockout_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Generic_StaminaRegenLockout_C) == 0xa68, "Size mismatch for UGE_Generic_StaminaRegenLockout_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UBuff_PartyXPBoost_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UBuff_PartyXPBoost_C) == 0xa68, "Size mismatch for UBuff_PartyXPBoost_C");

// Size: 0x2a8 (Inherited: 0x820, Single: 0xfffffa88)
class AB_FortGlobalAbilityTargetingActor_C : public AFortGlobalAbilityTargetingActor
{
public:
};

static_assert(sizeof(AB_FortGlobalAbilityTargetingActor_C) == 0x2a8, "Size mismatch for AB_FortGlobalAbilityTargetingActor_C");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCharacterPartMidArrayStruct
{
    TEnumAsByte<EFortCustomPartType> PartType_5_EBDFFF5740627902CC51DD966B8EE419; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TArray<UMaterialInstanceDynamic*> MID_7_A0D19AC74319389A5DF2019166F976F0; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCharacterPartMidArrayStruct) == 0x18, "Size mismatch for FCharacterPartMidArrayStruct");
static_assert(offsetof(FCharacterPartMidArrayStruct, PartType_5_EBDFFF5740627902CC51DD966B8EE419) == 0x0, "Offset mismatch for FCharacterPartMidArrayStruct::PartType_5_EBDFFF5740627902CC51DD966B8EE419");
static_assert(offsetof(FCharacterPartMidArrayStruct, MID_7_A0D19AC74319389A5DF2019166F976F0) == 0x8, "Offset mismatch for FCharacterPartMidArrayStruct::MID_7_A0D19AC74319389A5DF2019166F976F0");

// Size: 0xa68 (Inherited: 0x14f8, Single: 0xfffff570)
class UGE_ExtraLifeRevive_C : public UGE_Generic_Revive_C
{
public:
};

static_assert(sizeof(UGE_ExtraLifeRevive_C) == 0xa68, "Size mismatch for UGE_ExtraLifeRevive_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Generic_Revive_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Generic_Revive_C) == 0xa68, "Size mismatch for UGE_Generic_Revive_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_ShieldRegen_Delay_Damaged_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_ShieldRegen_Delay_Damaged_C) == 0xa68, "Size mismatch for UGE_ShieldRegen_Delay_Damaged_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_HealthRegen_Delay_Damaged_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_HealthRegen_Delay_Damaged_C) == 0xa68, "Size mismatch for UGE_HealthRegen_Delay_Damaged_C");

// Size: 0xce0 (Inherited: 0x2698, Single: 0xffffe648)
class UGAB_InterrogatePlayer_Search_C : public UFortGameplayAbility_CarryPlayer
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xbc8 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn; // 0xbd0 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerControllerAthena* PlayerController; // 0xbd8 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* InterrogatedPlayer; // 0xbe0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Anim_Search; // 0xbe8 (Size: 0x8, Type: ObjectProperty)
    FName InterrogateHolster; // 0xbf0 (Size: 0x4, Type: NameProperty)
    FName LootTierGroupName; // 0xbf4 (Size: 0x4, Type: NameProperty)
    UFortWorldItemDefinition* ItemDefinition; // 0xbf8 (Size: 0x8, Type: ObjectProperty)
    int32_t NumberToSpawn; // 0xc00 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c04[0x4]; // 0xc04 (Size: 0x4, Type: PaddingProperty)
    FVector LootSpawnOffset; // 0xc08 (Size: 0x18, Type: StructProperty)
    FScalableFloat MaxDropsInstance; // 0xc20 (Size: 0x28, Type: StructProperty)
    int32_t NumDropsInstance; // 0xc48 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_c4c[0x4]; // 0xc4c (Size: 0x4, Type: PaddingProperty)
    FScalableFloat KeycardDropBias; // 0xc50 (Size: 0x28, Type: StructProperty)
    TArray<UFortWorldItemDefinition*> KeycardItemDefinitions; // 0xc78 (Size: 0x10, Type: ArrayProperty)
    FGameplayTag T_Keycard_Yacht; // 0xc88 (Size: 0x4, Type: StructProperty)
    FGameplayTag T_Keycard_OilRig; // 0xc8c (Size: 0x4, Type: StructProperty)
    FGameplayTag T_Keycard_SharkIsland; // 0xc90 (Size: 0x4, Type: StructProperty)
    FGameplayTag T_Keycard_HQ; // 0xc94 (Size: 0x4, Type: StructProperty)
    FGameplayTag T_Keycard_MountainBase; // 0xc98 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c9c[0x4]; // 0xc9c (Size: 0x4, Type: PaddingProperty)
    FTimerHandle Timer_Interrogation; // 0xca0 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer T_ReticleHUD; // 0xca8 (Size: 0x20, Type: StructProperty)
    FGameplayTag T_NPC; // 0xcc8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_ccc[0x4]; // 0xccc (Size: 0x4, Type: PaddingProperty)
    UClass* GE_Cooldown; // 0xcd0 (Size: 0x8, Type: ClassProperty)
    UClass* GE_PickedUp; // 0xcd8 (Size: 0x8, Type: ClassProperty)

public:
    void InitAbility(); // 0x288a61c (Index: 0x3, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void GetKeycardToDrop(bool& HasKeycard, UFortWorldItemDefinition*& Output); // 0x288a61c (Index: 0x4, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void EndAbilityCleanup(); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void DropLoot(); // 0x288a61c (Index: 0x7, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void DropKeycard(); // 0x288a61c (Index: 0x8, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ApplyGameplayEffectToNPC(UClass*& GameplayEffect); // 0x288a61c (Index: 0xb, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void ToggleReticleVisibility(bool& Hide); // 0x288a61c (Index: 0xe, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGAB_InterrogatePlayer_Search_C) == 0xce0, "Size mismatch for UGAB_InterrogatePlayer_Search_C");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, UberGraphFrame) == 0xbc8, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::UberGraphFrame");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, PlayerPawn) == 0xbd0, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::PlayerPawn");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, PlayerController) == 0xbd8, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::PlayerController");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, InterrogatedPlayer) == 0xbe0, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::InterrogatedPlayer");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, Anim_Search) == 0xbe8, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::Anim_Search");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, InterrogateHolster) == 0xbf0, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::InterrogateHolster");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, LootTierGroupName) == 0xbf4, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::LootTierGroupName");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, ItemDefinition) == 0xbf8, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::ItemDefinition");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, NumberToSpawn) == 0xc00, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::NumberToSpawn");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, LootSpawnOffset) == 0xc08, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::LootSpawnOffset");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, MaxDropsInstance) == 0xc20, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::MaxDropsInstance");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, NumDropsInstance) == 0xc48, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::NumDropsInstance");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, KeycardDropBias) == 0xc50, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::KeycardDropBias");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, KeycardItemDefinitions) == 0xc78, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::KeycardItemDefinitions");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, T_Keycard_Yacht) == 0xc88, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::T_Keycard_Yacht");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, T_Keycard_OilRig) == 0xc8c, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::T_Keycard_OilRig");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, T_Keycard_SharkIsland) == 0xc90, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::T_Keycard_SharkIsland");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, T_Keycard_HQ) == 0xc94, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::T_Keycard_HQ");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, T_Keycard_MountainBase) == 0xc98, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::T_Keycard_MountainBase");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, Timer_Interrogation) == 0xca0, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::Timer_Interrogation");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, T_ReticleHUD) == 0xca8, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::T_ReticleHUD");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, T_NPC) == 0xcc8, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::T_NPC");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, GE_Cooldown) == 0xcd0, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::GE_Cooldown");
static_assert(offsetof(UGAB_InterrogatePlayer_Search_C, GE_PickedUp) == 0xcd8, "Offset mismatch for UGAB_InterrogatePlayer_Search_C::GE_PickedUp");

// Size: 0xd24 (Inherited: 0xf08, Single: 0xfffffe1c)
class UGAB_GenericDeath_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    UAnimMontage* DeathMontage; // 0xb40 (Size: 0x8, Type: ObjectProperty)
    FName DeathMontageSectionName; // 0xb48 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b4c[0x4]; // 0xb4c (Size: 0x4, Type: PaddingProperty)
    FVector DeathHitDirection; // 0xb50 (Size: 0x18, Type: StructProperty)
    FHitResult DeathHitResult; // 0xb68 (Size: 0xf8, Type: StructProperty)
    FGameplayTagContainer DamageTags; // 0xc60 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer SpawnDroneTags; // 0xc80 (Size: 0x20, Type: StructProperty)
    UAnimMontage* Front; // 0xca0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Left; // 0xca8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Right; // 0xcb0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Back; // 0xcb8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Head_Front; // 0xcc0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Head_Left; // 0xcc8 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Head_Right; // 0xcd0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Head_Back; // 0xcd8 (Size: 0x8, Type: ObjectProperty)
    int32_t FrontSectionNameCount; // 0xce0 (Size: 0x4, Type: IntProperty)
    int32_t LeftSectionNameCount; // 0xce4 (Size: 0x4, Type: IntProperty)
    int32_t RightSectionNameCount; // 0xce8 (Size: 0x4, Type: IntProperty)
    int32_t BackSectionNameCount; // 0xcec (Size: 0x4, Type: IntProperty)
    int32_t Head_FrontSectionNameCount; // 0xcf0 (Size: 0x4, Type: IntProperty)
    int32_t Head_LeftSectionNameCount; // 0xcf4 (Size: 0x4, Type: IntProperty)
    int32_t Head_RightSectionNameCount; // 0xcf8 (Size: 0x4, Type: IntProperty)
    int32_t Head_BackSectionNameCount; // 0xcfc (Size: 0x4, Type: IntProperty)
    FName FrontMontageSectionPrefix; // 0xd00 (Size: 0x4, Type: NameProperty)
    FName BackMontageSectionPrefix; // 0xd04 (Size: 0x4, Type: NameProperty)
    FName LeftMontageSectionPrefix; // 0xd08 (Size: 0x4, Type: NameProperty)
    FName RightMontageSectionPrefix; // 0xd0c (Size: 0x4, Type: NameProperty)
    FName HeadFrontMontageSectionPrefix; // 0xd10 (Size: 0x4, Type: NameProperty)
    FName HeadBackMontageSectionPrefix; // 0xd14 (Size: 0x4, Type: NameProperty)
    FName HeadLeftMontageSectionPrefix; // 0xd18 (Size: 0x4, Type: NameProperty)
    FName HeadRightMontageSectionPrefix; // 0xd1c (Size: 0x4, Type: NameProperty)
    FGameplayTag TeleportOutCue; // 0xd20 (Size: 0x4, Type: StructProperty)

public:
    void InitializeDeathHitDirection(FGameplayEventData& EventHitData); // 0x288a61c (Index: 0xa, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void GetRandomSectionName(int32_t& MaxNumberOfSections, FName& OriginalSectionName, FName& SectionName); // 0x288a61c (Index: 0xb, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0x9, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGAB_GenericDeath_C) == 0xd24, "Size mismatch for UGAB_GenericDeath_C");
static_assert(offsetof(UGAB_GenericDeath_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGAB_GenericDeath_C::UberGraphFrame");
static_assert(offsetof(UGAB_GenericDeath_C, DeathMontage) == 0xb40, "Offset mismatch for UGAB_GenericDeath_C::DeathMontage");
static_assert(offsetof(UGAB_GenericDeath_C, DeathMontageSectionName) == 0xb48, "Offset mismatch for UGAB_GenericDeath_C::DeathMontageSectionName");
static_assert(offsetof(UGAB_GenericDeath_C, DeathHitDirection) == 0xb50, "Offset mismatch for UGAB_GenericDeath_C::DeathHitDirection");
static_assert(offsetof(UGAB_GenericDeath_C, DeathHitResult) == 0xb68, "Offset mismatch for UGAB_GenericDeath_C::DeathHitResult");
static_assert(offsetof(UGAB_GenericDeath_C, DamageTags) == 0xc60, "Offset mismatch for UGAB_GenericDeath_C::DamageTags");
static_assert(offsetof(UGAB_GenericDeath_C, SpawnDroneTags) == 0xc80, "Offset mismatch for UGAB_GenericDeath_C::SpawnDroneTags");
static_assert(offsetof(UGAB_GenericDeath_C, Front) == 0xca0, "Offset mismatch for UGAB_GenericDeath_C::Front");
static_assert(offsetof(UGAB_GenericDeath_C, Left) == 0xca8, "Offset mismatch for UGAB_GenericDeath_C::Left");
static_assert(offsetof(UGAB_GenericDeath_C, Right) == 0xcb0, "Offset mismatch for UGAB_GenericDeath_C::Right");
static_assert(offsetof(UGAB_GenericDeath_C, Back) == 0xcb8, "Offset mismatch for UGAB_GenericDeath_C::Back");
static_assert(offsetof(UGAB_GenericDeath_C, Head_Front) == 0xcc0, "Offset mismatch for UGAB_GenericDeath_C::Head_Front");
static_assert(offsetof(UGAB_GenericDeath_C, Head_Left) == 0xcc8, "Offset mismatch for UGAB_GenericDeath_C::Head_Left");
static_assert(offsetof(UGAB_GenericDeath_C, Head_Right) == 0xcd0, "Offset mismatch for UGAB_GenericDeath_C::Head_Right");
static_assert(offsetof(UGAB_GenericDeath_C, Head_Back) == 0xcd8, "Offset mismatch for UGAB_GenericDeath_C::Head_Back");
static_assert(offsetof(UGAB_GenericDeath_C, FrontSectionNameCount) == 0xce0, "Offset mismatch for UGAB_GenericDeath_C::FrontSectionNameCount");
static_assert(offsetof(UGAB_GenericDeath_C, LeftSectionNameCount) == 0xce4, "Offset mismatch for UGAB_GenericDeath_C::LeftSectionNameCount");
static_assert(offsetof(UGAB_GenericDeath_C, RightSectionNameCount) == 0xce8, "Offset mismatch for UGAB_GenericDeath_C::RightSectionNameCount");
static_assert(offsetof(UGAB_GenericDeath_C, BackSectionNameCount) == 0xcec, "Offset mismatch for UGAB_GenericDeath_C::BackSectionNameCount");
static_assert(offsetof(UGAB_GenericDeath_C, Head_FrontSectionNameCount) == 0xcf0, "Offset mismatch for UGAB_GenericDeath_C::Head_FrontSectionNameCount");
static_assert(offsetof(UGAB_GenericDeath_C, Head_LeftSectionNameCount) == 0xcf4, "Offset mismatch for UGAB_GenericDeath_C::Head_LeftSectionNameCount");
static_assert(offsetof(UGAB_GenericDeath_C, Head_RightSectionNameCount) == 0xcf8, "Offset mismatch for UGAB_GenericDeath_C::Head_RightSectionNameCount");
static_assert(offsetof(UGAB_GenericDeath_C, Head_BackSectionNameCount) == 0xcfc, "Offset mismatch for UGAB_GenericDeath_C::Head_BackSectionNameCount");
static_assert(offsetof(UGAB_GenericDeath_C, FrontMontageSectionPrefix) == 0xd00, "Offset mismatch for UGAB_GenericDeath_C::FrontMontageSectionPrefix");
static_assert(offsetof(UGAB_GenericDeath_C, BackMontageSectionPrefix) == 0xd04, "Offset mismatch for UGAB_GenericDeath_C::BackMontageSectionPrefix");
static_assert(offsetof(UGAB_GenericDeath_C, LeftMontageSectionPrefix) == 0xd08, "Offset mismatch for UGAB_GenericDeath_C::LeftMontageSectionPrefix");
static_assert(offsetof(UGAB_GenericDeath_C, RightMontageSectionPrefix) == 0xd0c, "Offset mismatch for UGAB_GenericDeath_C::RightMontageSectionPrefix");
static_assert(offsetof(UGAB_GenericDeath_C, HeadFrontMontageSectionPrefix) == 0xd10, "Offset mismatch for UGAB_GenericDeath_C::HeadFrontMontageSectionPrefix");
static_assert(offsetof(UGAB_GenericDeath_C, HeadBackMontageSectionPrefix) == 0xd14, "Offset mismatch for UGAB_GenericDeath_C::HeadBackMontageSectionPrefix");
static_assert(offsetof(UGAB_GenericDeath_C, HeadLeftMontageSectionPrefix) == 0xd18, "Offset mismatch for UGAB_GenericDeath_C::HeadLeftMontageSectionPrefix");
static_assert(offsetof(UGAB_GenericDeath_C, HeadRightMontageSectionPrefix) == 0xd1c, "Offset mismatch for UGAB_GenericDeath_C::HeadRightMontageSectionPrefix");
static_assert(offsetof(UGAB_GenericDeath_C, TeleportOutCue) == 0xd20, "Offset mismatch for UGAB_GenericDeath_C::TeleportOutCue");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Interrogation_Voice_PickedUp_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Interrogation_Voice_PickedUp_C) == 0xa68, "Size mismatch for UGE_Interrogation_Voice_PickedUp_C");

// Size: 0x2020 (Inherited: 0x40c8, Single: 0xffffdf58)
class UAthena_PlayerCameraMode_Interrogation_Map_C : public UAthena_PlayerCameraModeBase_C
{
public:
};

static_assert(sizeof(UAthena_PlayerCameraMode_Interrogation_Map_C) == 0x2020, "Size mismatch for UAthena_PlayerCameraMode_Interrogation_Map_C");

// Size: 0xb44 (Inherited: 0xf08, Single: 0xfffffc3c)
class UGA_Interrogate_GC_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    FGameplayTag Cue; // 0xb40 (Size: 0x4, Type: StructProperty)

public:
    virtual void FailedToActivatePassiveAbility(FGameplayAbilityActorInfo& ActorInfo); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)

protected:
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGA_Interrogate_GC_C) == 0xb44, "Size mismatch for UGA_Interrogate_GC_C");
static_assert(offsetof(UGA_Interrogate_GC_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGA_Interrogate_GC_C::UberGraphFrame");
static_assert(offsetof(UGA_Interrogate_GC_C, Cue) == 0xb40, "Offset mismatch for UGA_Interrogate_GC_C::Cue");

// Size: 0xa68 (Inherited: 0x14f8, Single: 0xfffff570)
class UGE_KnockbackActive_C : public UGET_TagContainer_C
{
public:
};

static_assert(sizeof(UGE_KnockbackActive_C) == 0xa68, "Size mismatch for UGE_KnockbackActive_C");

// Size: 0xbc8 (Inherited: 0x2698, Single: 0xffffe530)
class UGA_DefaultPlayer_Jump_C : public UFortGameplayAbility_Jump
{
public:
};

static_assert(sizeof(UGA_DefaultPlayer_Jump_C) == 0xbc8, "Size mismatch for UGA_DefaultPlayer_Jump_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Interrogation_Cooldown_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Interrogation_Cooldown_C) == 0xa68, "Size mismatch for UGE_Interrogation_Cooldown_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Interrogate_GC_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Interrogate_GC_C) == 0xa68, "Size mismatch for UGE_Interrogate_GC_C");

// Size: 0xa68 (Inherited: 0x29c8, Single: 0xffffe0a0)
class UGE_Ranged_GenericDamage_Explosive_C : public UGET_DirectPhysicalDamage_C
{
public:
};

static_assert(sizeof(UGE_Ranged_GenericDamage_Explosive_C) == 0xa68, "Size mismatch for UGE_Ranged_GenericDamage_Explosive_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Generic_Character_Launch_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Generic_Character_Launch_C) == 0xa68, "Size mismatch for UGE_Generic_Character_Launch_C");

// Size: 0xbd8 (Inherited: 0x2698, Single: 0xffffe540)
class UGAB_DropPlayer_C : public UFortGameplayAbility_CarryPlayer
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xbc8 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn; // 0xbd0 (Size: 0x8, Type: ObjectProperty)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGAB_DropPlayer_C) == 0xbd8, "Size mismatch for UGAB_DropPlayer_C");
static_assert(offsetof(UGAB_DropPlayer_C, UberGraphFrame) == 0xbc8, "Offset mismatch for UGAB_DropPlayer_C::UberGraphFrame");
static_assert(offsetof(UGAB_DropPlayer_C, PlayerPawn) == 0xbd0, "Offset mismatch for UGAB_DropPlayer_C::PlayerPawn");

// Size: 0xc20 (Inherited: 0x2698, Single: 0xffffe588)
class UGAB_CarryPlayer_C : public UFortGameplayAbility_CarryPlayer
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xbc8 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn; // 0xbd0 (Size: 0x8, Type: ObjectProperty)
    FName DBNOCarryHolster; // 0xbd8 (Size: 0x4, Type: NameProperty)
    bool bCompletedPickup; // 0xbdc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_bdd[0x3]; // 0xbdd (Size: 0x3, Type: PaddingProperty)
    FVector PickupLocation; // 0xbe0 (Size: 0x18, Type: StructProperty)
    int32_t CarryLongDistanceThreshold; // 0xbf8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_bfc[0x4]; // 0xbfc (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer BlockHolsterTags; // 0xc00 (Size: 0x20, Type: StructProperty)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGAB_CarryPlayer_C) == 0xc20, "Size mismatch for UGAB_CarryPlayer_C");
static_assert(offsetof(UGAB_CarryPlayer_C, UberGraphFrame) == 0xbc8, "Offset mismatch for UGAB_CarryPlayer_C::UberGraphFrame");
static_assert(offsetof(UGAB_CarryPlayer_C, PlayerPawn) == 0xbd0, "Offset mismatch for UGAB_CarryPlayer_C::PlayerPawn");
static_assert(offsetof(UGAB_CarryPlayer_C, DBNOCarryHolster) == 0xbd8, "Offset mismatch for UGAB_CarryPlayer_C::DBNOCarryHolster");
static_assert(offsetof(UGAB_CarryPlayer_C, bCompletedPickup) == 0xbdc, "Offset mismatch for UGAB_CarryPlayer_C::bCompletedPickup");
static_assert(offsetof(UGAB_CarryPlayer_C, PickupLocation) == 0xbe0, "Offset mismatch for UGAB_CarryPlayer_C::PickupLocation");
static_assert(offsetof(UGAB_CarryPlayer_C, CarryLongDistanceThreshold) == 0xbf8, "Offset mismatch for UGAB_CarryPlayer_C::CarryLongDistanceThreshold");
static_assert(offsetof(UGAB_CarryPlayer_C, BlockHolsterTags) == 0xc00, "Offset mismatch for UGAB_CarryPlayer_C::BlockHolsterTags");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Impulse_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Impulse_C) == 0xa68, "Size mismatch for UGE_Impulse_C");

// Size: 0xa68 (Inherited: 0x3430, Single: 0xffffd638)
class UGE_Damage_Explosive_LineOfSight_C : public UGE_Ranged_GenericDamage_Explosive_C
{
public:
};

static_assert(sizeof(UGE_Damage_Explosive_LineOfSight_C) == 0xa68, "Size mismatch for UGE_Damage_Explosive_LineOfSight_C");

// Size: 0xb45 (Inherited: 0xf08, Single: 0xfffffc3d)
class UGAT_TriggeredAbility_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    FGameplayTag TC_AbilitiesGenericTriggeredAbilityActivate; // 0xb40 (Size: 0x4, Type: StructProperty)
    bool bPlayerHolsterState; // 0xb44 (Size: 0x1, Type: BoolProperty)

public:
    void TriggeredAbilitySetup(UAbilitySystemComponent*& AbilitySystemIn, UAbilitySystemComponent*& AbilitySystemOut); // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetHolsterWeaponWithName(AFortPawn*& Target_Fort_Pawn, bool& ShouldHolster, bool& PlayEquipAnim, bool& ShowDebugPrintName, bool& IsWeaponHolstered, bool& OperationSuccessful); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void EndAbilityWithReason(FString& Reason); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGAT_TriggeredAbility_C) == 0xb45, "Size mismatch for UGAT_TriggeredAbility_C");
static_assert(offsetof(UGAT_TriggeredAbility_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGAT_TriggeredAbility_C::UberGraphFrame");
static_assert(offsetof(UGAT_TriggeredAbility_C, TC_AbilitiesGenericTriggeredAbilityActivate) == 0xb40, "Offset mismatch for UGAT_TriggeredAbility_C::TC_AbilitiesGenericTriggeredAbilityActivate");
static_assert(offsetof(UGAT_TriggeredAbility_C, bPlayerHolsterState) == 0xb44, "Offset mismatch for UGAT_TriggeredAbility_C::bPlayerHolsterState");

// Size: 0xa68 (Inherited: 0x3430, Single: 0xffffd638)
class UGE_Damage_Explosive_NoLineOfSight_C : public UGE_Ranged_GenericDamage_Explosive_C
{
public:
};

static_assert(sizeof(UGE_Damage_Explosive_NoLineOfSight_C) == 0xa68, "Size mismatch for UGE_Damage_Explosive_NoLineOfSight_C");

// Size: 0xd10 (Inherited: 0xf08, Single: 0xfffffe08)
class UGAB_AthenaDBNO_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    UAnimMontage* DeathMontage; // 0xb40 (Size: 0x8, Type: ObjectProperty)
    FVector DeathHitDirection; // 0xb48 (Size: 0x18, Type: StructProperty)
    FHitResult DeathHitResult; // 0xb60 (Size: 0xf8, Type: StructProperty)
    FGameplayTagContainer DamageTags; // 0xc58 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer GameplayStatusAfflicted; // 0xc78 (Size: 0x20, Type: StructProperty)
    UAnimMontage* DeathMontageSkydive; // 0xc98 (Size: 0x8, Type: ObjectProperty)
    FActiveGameplayEffectHandle DBNOBleedGEHandle; // 0xca0 (Size: 0x8, Type: StructProperty)
    FName HolsterId; // 0xca8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_cac[0x4]; // 0xcac (Size: 0x4, Type: PaddingProperty)
    UAnimMontage* DeathMontageSwimming; // 0xcb0 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawnAthena* FortPlayerPawn; // 0xcb8 (Size: 0x8, Type: ObjectProperty)
    UClass* DBNOStart_GE_Class; // 0xcc0 (Size: 0x8, Type: ClassProperty)
    bool ImprovedDBNO; // 0xcc8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_cc9[0x7]; // 0xcc9 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagContainer Old_DBNO_Block_Tags; // 0xcd0 (Size: 0x20, Type: StructProperty)
    FActiveGameplayEffectHandle GE_Handle__Health_Bonus; // 0xcf0 (Size: 0x8, Type: StructProperty)
    double TenacityAmount; // 0xcf8 (Size: 0x8, Type: DoubleProperty)
    uint8_t TenacityType; // 0xd00 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_d01[0x7]; // 0xd01 (Size: 0x7, Type: PaddingProperty)
    UClass* GE_PlayerDamage_Immune_FX; // 0xd08 (Size: 0x8, Type: ClassProperty)

public:
    void InitializeDeathHitDirection(FGameplayEventData& EventHitData); // 0x288a61c (Index: 0x9, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Get_Max_Health_Tenacity(double& Tenacity); // 0x288a61c (Index: 0xa, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void Get_Initial_Heal_Amount(double& Health); // 0x288a61c (Index: 0xb, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    UAnimMontage* Get_DBNO_Montage(); // 0x288a61c (Index: 0xc, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void Get_Custom_Tenacity(double& Tenacity); // 0x288a61c (Index: 0xd, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void ApplyBleeding(FActiveGameplayEffectHandle& EffectHandle); // 0x288a61c (Index: 0x10, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Apply_Health_Bonus(FActiveGameplayEffectHandle& EffectHandle); // 0x288a61c (Index: 0x11, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0x8, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGAB_AthenaDBNO_C) == 0xd10, "Size mismatch for UGAB_AthenaDBNO_C");
static_assert(offsetof(UGAB_AthenaDBNO_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGAB_AthenaDBNO_C::UberGraphFrame");
static_assert(offsetof(UGAB_AthenaDBNO_C, DeathMontage) == 0xb40, "Offset mismatch for UGAB_AthenaDBNO_C::DeathMontage");
static_assert(offsetof(UGAB_AthenaDBNO_C, DeathHitDirection) == 0xb48, "Offset mismatch for UGAB_AthenaDBNO_C::DeathHitDirection");
static_assert(offsetof(UGAB_AthenaDBNO_C, DeathHitResult) == 0xb60, "Offset mismatch for UGAB_AthenaDBNO_C::DeathHitResult");
static_assert(offsetof(UGAB_AthenaDBNO_C, DamageTags) == 0xc58, "Offset mismatch for UGAB_AthenaDBNO_C::DamageTags");
static_assert(offsetof(UGAB_AthenaDBNO_C, GameplayStatusAfflicted) == 0xc78, "Offset mismatch for UGAB_AthenaDBNO_C::GameplayStatusAfflicted");
static_assert(offsetof(UGAB_AthenaDBNO_C, DeathMontageSkydive) == 0xc98, "Offset mismatch for UGAB_AthenaDBNO_C::DeathMontageSkydive");
static_assert(offsetof(UGAB_AthenaDBNO_C, DBNOBleedGEHandle) == 0xca0, "Offset mismatch for UGAB_AthenaDBNO_C::DBNOBleedGEHandle");
static_assert(offsetof(UGAB_AthenaDBNO_C, HolsterId) == 0xca8, "Offset mismatch for UGAB_AthenaDBNO_C::HolsterId");
static_assert(offsetof(UGAB_AthenaDBNO_C, DeathMontageSwimming) == 0xcb0, "Offset mismatch for UGAB_AthenaDBNO_C::DeathMontageSwimming");
static_assert(offsetof(UGAB_AthenaDBNO_C, FortPlayerPawn) == 0xcb8, "Offset mismatch for UGAB_AthenaDBNO_C::FortPlayerPawn");
static_assert(offsetof(UGAB_AthenaDBNO_C, DBNOStart_GE_Class) == 0xcc0, "Offset mismatch for UGAB_AthenaDBNO_C::DBNOStart_GE_Class");
static_assert(offsetof(UGAB_AthenaDBNO_C, ImprovedDBNO) == 0xcc8, "Offset mismatch for UGAB_AthenaDBNO_C::ImprovedDBNO");
static_assert(offsetof(UGAB_AthenaDBNO_C, Old_DBNO_Block_Tags) == 0xcd0, "Offset mismatch for UGAB_AthenaDBNO_C::Old_DBNO_Block_Tags");
static_assert(offsetof(UGAB_AthenaDBNO_C, GE_Handle__Health_Bonus) == 0xcf0, "Offset mismatch for UGAB_AthenaDBNO_C::GE_Handle__Health_Bonus");
static_assert(offsetof(UGAB_AthenaDBNO_C, TenacityAmount) == 0xcf8, "Offset mismatch for UGAB_AthenaDBNO_C::TenacityAmount");
static_assert(offsetof(UGAB_AthenaDBNO_C, TenacityType) == 0xd00, "Offset mismatch for UGAB_AthenaDBNO_C::TenacityType");
static_assert(offsetof(UGAB_AthenaDBNO_C, GE_PlayerDamage_Immune_FX) == 0xd08, "Offset mismatch for UGAB_AthenaDBNO_C::GE_PlayerDamage_Immune_FX");

// Size: 0xb70 (Inherited: 0xf08, Single: 0xfffffc68)
class UGAB_AthenaDBNORevive_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    FGameplayTag EC_AppliedEffect; // 0xb40 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_b44[0x4]; // 0xb44 (Size: 0x4, Type: PaddingProperty)
    AFortPlayerPawn* PlayerPawn; // 0xb48 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag ResurrectCue; // 0xb50 (Size: 0x4, Type: StructProperty)
    FGameplayTag ResurrectAthenaCue; // 0xb54 (Size: 0x4, Type: StructProperty)
    UAnimMontage* DBNOMontageOutro; // 0xb58 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* DBNOMontageOutroSwimming; // 0xb60 (Size: 0x8, Type: ObjectProperty)
    UClass* GE_PlayerDamage_Immune_FX; // 0xb68 (Size: 0x8, Type: ClassProperty)

public:
    void Get_DBNO_Outro_Montage(UAnimMontage*& DBNOMontageOutro); // 0x288a61c (Index: 0x5, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0x4, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGAB_AthenaDBNORevive_C) == 0xb70, "Size mismatch for UGAB_AthenaDBNORevive_C");
static_assert(offsetof(UGAB_AthenaDBNORevive_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGAB_AthenaDBNORevive_C::UberGraphFrame");
static_assert(offsetof(UGAB_AthenaDBNORevive_C, EC_AppliedEffect) == 0xb40, "Offset mismatch for UGAB_AthenaDBNORevive_C::EC_AppliedEffect");
static_assert(offsetof(UGAB_AthenaDBNORevive_C, PlayerPawn) == 0xb48, "Offset mismatch for UGAB_AthenaDBNORevive_C::PlayerPawn");
static_assert(offsetof(UGAB_AthenaDBNORevive_C, ResurrectCue) == 0xb50, "Offset mismatch for UGAB_AthenaDBNORevive_C::ResurrectCue");
static_assert(offsetof(UGAB_AthenaDBNORevive_C, ResurrectAthenaCue) == 0xb54, "Offset mismatch for UGAB_AthenaDBNORevive_C::ResurrectAthenaCue");
static_assert(offsetof(UGAB_AthenaDBNORevive_C, DBNOMontageOutro) == 0xb58, "Offset mismatch for UGAB_AthenaDBNORevive_C::DBNOMontageOutro");
static_assert(offsetof(UGAB_AthenaDBNORevive_C, DBNOMontageOutroSwimming) == 0xb60, "Offset mismatch for UGAB_AthenaDBNORevive_C::DBNOMontageOutroSwimming");
static_assert(offsetof(UGAB_AthenaDBNORevive_C, GE_PlayerDamage_Immune_FX) == 0xb68, "Offset mismatch for UGAB_AthenaDBNORevive_C::GE_PlayerDamage_Immune_FX");

// Size: 0xb40 (Inherited: 0xf08, Single: 0xfffffc38)
class UGA_DefaultPlayer_PetOtherPet_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)

protected:
    virtual void K2_ActivateAbility(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UGA_DefaultPlayer_PetOtherPet_C) == 0xb40, "Size mismatch for UGA_DefaultPlayer_PetOtherPet_C");
static_assert(offsetof(UGA_DefaultPlayer_PetOtherPet_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGA_DefaultPlayer_PetOtherPet_C::UberGraphFrame");

// Size: 0xc61 (Inherited: 0xf08, Single: 0xfffffd59)
class UGAB_GenericApplyKnockback_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xb38 (Size: 0x8, Type: StructProperty)
    UClass* GE_TransferKnockback; // 0xb40 (Size: 0x8, Type: ClassProperty)
    UClass* GE_KnockbackActive; // 0xb48 (Size: 0x8, Type: ClassProperty)
    double KnockbackPropagationThreshold; // 0xb50 (Size: 0x8, Type: DoubleProperty)
    UAnimMontage* KnockbackUpMontage; // 0xb58 (Size: 0x8, Type: ObjectProperty)
    FName KnockbackUpMontageSection; // 0xb60 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b64[0x4]; // 0xb64 (Size: 0x4, Type: PaddingProperty)
    UAnimMontage* KnockbackDownMontage; // 0xb68 (Size: 0x8, Type: ObjectProperty)
    FName KnockbackDownMontageSection; // 0xb70 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b74[0x4]; // 0xb74 (Size: 0x4, Type: PaddingProperty)
    UAnimMontage* KnockbackLandMontage; // 0xb78 (Size: 0x8, Type: ObjectProperty)
    FName KnockbackLandMontageSection; // 0xb80 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b84[0x4]; // 0xb84 (Size: 0x4, Type: PaddingProperty)
    UAnimMontage* KnockbackLandToIdleMontage; // 0xb88 (Size: 0x8, Type: ObjectProperty)
    FName KnockbackLandToIdleMontageSection; // 0xb90 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_b94[0x4]; // 0xb94 (Size: 0x4, Type: PaddingProperty)
    UAnimMontage* KnockbackLandToStunMontage; // 0xb98 (Size: 0x8, Type: ObjectProperty)
    FName KnockbackLandToStunMontageSection; // 0xba0 (Size: 0x4, Type: NameProperty)
    bool DebugDraw; // 0xba4 (Size: 0x1, Type: BoolProperty)
    bool DebugNumbers; // 0xba5 (Size: 0x1, Type: BoolProperty)
    bool DebugForceKnockbackValues; // 0xba6 (Size: 0x1, Type: BoolProperty)
    bool bOrientToImpulse; // 0xba7 (Size: 0x1, Type: BoolProperty)
    FActiveGameplayEffectHandle ActiveKnockback; // 0xba8 (Size: 0x8, Type: StructProperty)
    FVector OrientDirection; // 0xbb0 (Size: 0x18, Type: StructProperty)
    FVector HitDirection; // 0xbc8 (Size: 0x18, Type: StructProperty)
    FVector ImpulseDirectionVelocityOrRotation; // 0xbe0 (Size: 0x18, Type: StructProperty)
    FVector DebugLastLocation; // 0xbf8 (Size: 0x18, Type: StructProperty)
    FGameplayTag TC_NPCStatusLockedInPlace; // 0xc10 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c14[0x4]; // 0xc14 (Size: 0x4, Type: PaddingProperty)
    double LockedInPlaceKnockbackAngle; // 0xc18 (Size: 0x8, Type: DoubleProperty)
    double LockedInPlaceKnockbackMagnitude; // 0xc20 (Size: 0x8, Type: DoubleProperty)
    UClass* GE_RestoreControlResistance; // 0xc28 (Size: 0x8, Type: ClassProperty)
    UClass* GE_ImpactImmunity; // 0xc30 (Size: 0x8, Type: ClassProperty)
    FActiveGameplayEffectHandle ActiveImpactImmunity; // 0xc38 (Size: 0x8, Type: StructProperty)
    bool bHasImpactImmunity; // 0xc40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c41[0x7]; // 0xc41 (Size: 0x7, Type: PaddingProperty)
    double F_OneFrameDelay; // 0xc48 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag Event_Triggered_Knockback; // 0xc50 (Size: 0x4, Type: StructProperty)
    bool KnockbackFromFloorTrap; // 0xc54 (Size: 0x1, Type: BoolProperty)
    bool KnockbackFromFloorTrap_PlayUpMontage; // 0xc55 (Size: 0x1, Type: BoolProperty)
    bool KnockbackFromFloorTrap_PlayDownMontage; // 0xc56 (Size: 0x1, Type: BoolProperty)
    bool KnockbackFromFloorTrap_PlayLandMontage; // 0xc57 (Size: 0x1, Type: BoolProperty)
    FGameplayTag Event_Control_Ended; // 0xc58 (Size: 0x4, Type: StructProperty)
    FGameplayTag GC_TrapKnockback_Tag; // 0xc5c (Size: 0x4, Type: StructProperty)
    bool AllowKnockbackAnimation; // 0xc60 (Size: 0x1, Type: BoolProperty)

public:
    void GetPawnFromInstigator(AActor*& InActor, AFortPlayerPawn*& OutPawn); // 0x288a61c (Index: 0xc, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void DoesUseInstagorInsteadOfImpulseDirection(FGameplayEffectContextHandle& EffectContext, UObject*& OptionalObject, bool& Value); // 0x288a61c (Index: 0xe, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void CheckForPawnDeath(AFortPawn*& Pawn, bool& IsDead); // 0x288a61c (Index: 0x10, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    FVector CalculateImpulseDirection(AFortPlayerPawn*& InPawn); // 0x288a61c (Index: 0x11, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)

protected:
    virtual void K2_OnEndAbility(bool& bWasCancelled); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
    virtual void K2_ActivateAbilityFromEvent(const FGameplayEventData EventData); // 0x288a61c (Index: 0xb, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UGAB_GenericApplyKnockback_C) == 0xc61, "Size mismatch for UGAB_GenericApplyKnockback_C");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, UberGraphFrame) == 0xb38, "Offset mismatch for UGAB_GenericApplyKnockback_C::UberGraphFrame");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, GE_TransferKnockback) == 0xb40, "Offset mismatch for UGAB_GenericApplyKnockback_C::GE_TransferKnockback");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, GE_KnockbackActive) == 0xb48, "Offset mismatch for UGAB_GenericApplyKnockback_C::GE_KnockbackActive");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackPropagationThreshold) == 0xb50, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackPropagationThreshold");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackUpMontage) == 0xb58, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackUpMontage");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackUpMontageSection) == 0xb60, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackUpMontageSection");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackDownMontage) == 0xb68, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackDownMontage");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackDownMontageSection) == 0xb70, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackDownMontageSection");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackLandMontage) == 0xb78, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackLandMontage");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackLandMontageSection) == 0xb80, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackLandMontageSection");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackLandToIdleMontage) == 0xb88, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackLandToIdleMontage");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackLandToIdleMontageSection) == 0xb90, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackLandToIdleMontageSection");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackLandToStunMontage) == 0xb98, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackLandToStunMontage");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackLandToStunMontageSection) == 0xba0, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackLandToStunMontageSection");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, DebugDraw) == 0xba4, "Offset mismatch for UGAB_GenericApplyKnockback_C::DebugDraw");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, DebugNumbers) == 0xba5, "Offset mismatch for UGAB_GenericApplyKnockback_C::DebugNumbers");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, DebugForceKnockbackValues) == 0xba6, "Offset mismatch for UGAB_GenericApplyKnockback_C::DebugForceKnockbackValues");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, bOrientToImpulse) == 0xba7, "Offset mismatch for UGAB_GenericApplyKnockback_C::bOrientToImpulse");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, ActiveKnockback) == 0xba8, "Offset mismatch for UGAB_GenericApplyKnockback_C::ActiveKnockback");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, OrientDirection) == 0xbb0, "Offset mismatch for UGAB_GenericApplyKnockback_C::OrientDirection");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, HitDirection) == 0xbc8, "Offset mismatch for UGAB_GenericApplyKnockback_C::HitDirection");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, ImpulseDirectionVelocityOrRotation) == 0xbe0, "Offset mismatch for UGAB_GenericApplyKnockback_C::ImpulseDirectionVelocityOrRotation");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, DebugLastLocation) == 0xbf8, "Offset mismatch for UGAB_GenericApplyKnockback_C::DebugLastLocation");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, TC_NPCStatusLockedInPlace) == 0xc10, "Offset mismatch for UGAB_GenericApplyKnockback_C::TC_NPCStatusLockedInPlace");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, LockedInPlaceKnockbackAngle) == 0xc18, "Offset mismatch for UGAB_GenericApplyKnockback_C::LockedInPlaceKnockbackAngle");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, LockedInPlaceKnockbackMagnitude) == 0xc20, "Offset mismatch for UGAB_GenericApplyKnockback_C::LockedInPlaceKnockbackMagnitude");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, GE_RestoreControlResistance) == 0xc28, "Offset mismatch for UGAB_GenericApplyKnockback_C::GE_RestoreControlResistance");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, GE_ImpactImmunity) == 0xc30, "Offset mismatch for UGAB_GenericApplyKnockback_C::GE_ImpactImmunity");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, ActiveImpactImmunity) == 0xc38, "Offset mismatch for UGAB_GenericApplyKnockback_C::ActiveImpactImmunity");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, bHasImpactImmunity) == 0xc40, "Offset mismatch for UGAB_GenericApplyKnockback_C::bHasImpactImmunity");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, F_OneFrameDelay) == 0xc48, "Offset mismatch for UGAB_GenericApplyKnockback_C::F_OneFrameDelay");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, Event_Triggered_Knockback) == 0xc50, "Offset mismatch for UGAB_GenericApplyKnockback_C::Event_Triggered_Knockback");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackFromFloorTrap) == 0xc54, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackFromFloorTrap");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackFromFloorTrap_PlayUpMontage) == 0xc55, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackFromFloorTrap_PlayUpMontage");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackFromFloorTrap_PlayDownMontage) == 0xc56, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackFromFloorTrap_PlayDownMontage");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, KnockbackFromFloorTrap_PlayLandMontage) == 0xc57, "Offset mismatch for UGAB_GenericApplyKnockback_C::KnockbackFromFloorTrap_PlayLandMontage");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, Event_Control_Ended) == 0xc58, "Offset mismatch for UGAB_GenericApplyKnockback_C::Event_Control_Ended");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, GC_TrapKnockback_Tag) == 0xc5c, "Offset mismatch for UGAB_GenericApplyKnockback_C::GC_TrapKnockback_Tag");
static_assert(offsetof(UGAB_GenericApplyKnockback_C, AllowKnockbackAnimation) == 0xc60, "Offset mismatch for UGAB_GenericApplyKnockback_C::AllowKnockbackAnimation");

// Size: 0x7a80 (Inherited: 0x1cc8, Single: 0x5db8)
class UMenuScreen_AthenaLayer_C : public UFrontendLayerAnimInstance
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0xa00 (Size: 0x8, Type: StructProperty)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables; // 0xa08 (Size: 0x1bc, Type: StructProperty)
    uint8_t Pad_bc4[0x4]; // 0xbc4 (Size: 0x4, Type: PaddingProperty)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess; // 0xbc8 (Size: 0x8, Type: StructProperty)
    FAnimSubsystemInstance AnimBlueprintExtension_Base; // 0xbd0 (Size: 0x8, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_16; // 0xbd8 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_14; // 0xc88 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_15; // 0xca8 (Size: 0xb0, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_16; // 0xd58 (Size: 0x48, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_13; // 0xda0 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_14; // 0xdc0 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_12; // 0xe70 (Size: 0x20, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_11; // 0xe90 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_13; // 0xeb0 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_10; // 0xf60 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_12; // 0xf80 (Size: 0xb0, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_11; // 0x1030 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_9; // 0x10e0 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_10; // 0x1100 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_8; // 0x11b0 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_9; // 0x11d0 (Size: 0xb0, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_8; // 0x1280 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_7; // 0x1330 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_7; // 0x1350 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_6; // 0x1400 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_6; // 0x1420 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_5; // 0x14d0 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_5; // 0x14f0 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Slot AnimGraphNode_Slot; // 0x15a0 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2; // 0x15e8 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_1; // 0x1638 (Size: 0x50, Type: StructProperty)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3; // 0x1688 (Size: 0x78, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x1700 (Size: 0x28, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_56; // 0x1728 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_55; // 0x1798 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_54; // 0x1808 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_53; // 0x1878 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_52; // 0x18e8 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_34; // 0x1958 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_33; // 0x19a8 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_32; // 0x19f8 (Size: 0x50, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_16; // 0x1a48 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_13; // 0x1a68 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_51; // 0x1b30 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_50; // 0x1ba0 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_49; // 0x1c10 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_48; // 0x1c80 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_47; // 0x1cf0 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_46; // 0x1d60 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_45; // 0x1dd0 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_44; // 0x1e40 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_43; // 0x1eb0 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_42; // 0x1f20 (Size: 0x70, Type: StructProperty)
    FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend; // 0x1f90 (Size: 0xc0, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_31; // 0x2050 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_30; // 0x20a0 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_29; // 0x20f0 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_28; // 0x2140 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_27; // 0x2190 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_26; // 0x21e0 (Size: 0x50, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_15; // 0x2230 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_12; // 0x2250 (Size: 0xc8, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_15; // 0x2318 (Size: 0xc8, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_14; // 0x23e0 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_41; // 0x24a8 (Size: 0x70, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_14; // 0x2518 (Size: 0x20, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_40; // 0x2538 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_39; // 0x25a8 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_38; // 0x2618 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_37; // 0x2688 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_25; // 0x26f8 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_24; // 0x2748 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_23; // 0x2798 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_36; // 0x27e8 (Size: 0x70, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_13; // 0x2858 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_11; // 0x2878 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_35; // 0x2940 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_34; // 0x29b0 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_33; // 0x2a20 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_32; // 0x2a90 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_22; // 0x2b00 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_21; // 0x2b50 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_31; // 0x2ba0 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_20; // 0x2c10 (Size: 0x50, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_12; // 0x2c60 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_10; // 0x2c80 (Size: 0xc8, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_13; // 0x2d48 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_30; // 0x2e10 (Size: 0x70, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_12; // 0x2e80 (Size: 0xc8, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_11; // 0x2f48 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_9; // 0x2f68 (Size: 0xc8, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_11; // 0x3030 (Size: 0xc8, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1; // 0x30f8 (Size: 0x28, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_29; // 0x3120 (Size: 0x70, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_10; // 0x3190 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_8; // 0x31b0 (Size: 0xc8, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_10; // 0x3278 (Size: 0xc8, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_9; // 0x3340 (Size: 0xc8, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_15; // 0x3408 (Size: 0x48, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_8; // 0x3450 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_28; // 0x3518 (Size: 0x70, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_7; // 0x3588 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_27; // 0x3650 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_26; // 0x36c0 (Size: 0x70, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_9; // 0x3730 (Size: 0x20, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_6; // 0x3750 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_25; // 0x3818 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_24; // 0x3888 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_19; // 0x38f8 (Size: 0x50, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_5; // 0x3948 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_23; // 0x3a10 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_22; // 0x3a80 (Size: 0x70, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_8; // 0x3af0 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_7; // 0x3b10 (Size: 0xc8, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_14; // 0x3bd8 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_13; // 0x3c20 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_12; // 0x3c68 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_11; // 0x3cb0 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_10; // 0x3cf8 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_18; // 0x3d40 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_17; // 0x3d90 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_16; // 0x3de0 (Size: 0x50, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_7; // 0x3e30 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_6; // 0x3e50 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_15; // 0x3f18 (Size: 0x50, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x3f68 (Size: 0x28, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_21; // 0x3f90 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_20; // 0x4000 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_19; // 0x4070 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_18; // 0x40e0 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_17; // 0x4150 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_14; // 0x41c0 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_13; // 0x4210 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_12; // 0x4260 (Size: 0x50, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_6; // 0x42b0 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_5; // 0x42d0 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_16; // 0x4398 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_15; // 0x4408 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_14; // 0x4478 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_13; // 0x44e8 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_12; // 0x4558 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_11; // 0x45c8 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_10; // 0x4618 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_9; // 0x4668 (Size: 0x50, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_5; // 0x46b8 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_4; // 0x46d8 (Size: 0xc8, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_4; // 0x47a0 (Size: 0xc8, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_3; // 0x4868 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_11; // 0x4930 (Size: 0x70, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_4; // 0x49a0 (Size: 0x20, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_10; // 0x49c0 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_9; // 0x4a30 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_8; // 0x4aa0 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_7; // 0x4b10 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_8; // 0x4b80 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_7; // 0x4bd0 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_6; // 0x4c20 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_6; // 0x4c90 (Size: 0x50, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x4ce0 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_3; // 0x4d00 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_5; // 0x4dc8 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_4; // 0x4e38 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_3; // 0x4ea8 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2; // 0x4f18 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_5; // 0x4f88 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_4; // 0x4fd8 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_3; // 0x5028 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_1; // 0x5078 (Size: 0x70, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x50e8 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_2; // 0x5108 (Size: 0xc8, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_2; // 0x51d0 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer; // 0x5298 (Size: 0x70, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_1; // 0x5308 (Size: 0xc8, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_1; // 0x53d0 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_1; // 0x53f0 (Size: 0xc8, Type: StructProperty)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2; // 0x54b8 (Size: 0x78, Type: StructProperty)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_1; // 0x5530 (Size: 0x78, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4; // 0x55a8 (Size: 0x28, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3; // 0x55d0 (Size: 0x28, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x55f8 (Size: 0x50, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0x5648 (Size: 0x28, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_1; // 0x5670 (Size: 0x28, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9; // 0x5698 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt_3; // 0x56e0 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt_2; // 0x5730 (Size: 0x50, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8; // 0x5780 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7; // 0x57c8 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6; // 0x5810 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5; // 0x5858 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_2; // 0x58a0 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_1; // 0x58f0 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt_1; // 0x5940 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt; // 0x5990 (Size: 0x50, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0x59e0 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x5a28 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x5a70 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1; // 0x5ab8 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum; // 0x5b00 (Size: 0x50, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult; // 0x5b50 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x5b70 (Size: 0xc8, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_4; // 0x5c38 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_4; // 0x5c58 (Size: 0xb0, Type: StructProperty)
    FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0x5d08 (Size: 0x20, Type: StructProperty)
    FAnimNode_LegIK AnimGraphNode_LegIK_2; // 0x5d28 (Size: 0x100, Type: StructProperty)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3; // 0x5e28 (Size: 0x128, Type: StructProperty)
    FAnimNode_LegIK AnimGraphNode_LegIK_1; // 0x5f50 (Size: 0x100, Type: StructProperty)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_11; // 0x6050 (Size: 0xe8, Type: StructProperty)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_10; // 0x6138 (Size: 0xe8, Type: StructProperty)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_9; // 0x6220 (Size: 0xe8, Type: StructProperty)
    FAnimNode_LegIK AnimGraphNode_LegIK; // 0x6308 (Size: 0x100, Type: StructProperty)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_8; // 0x6408 (Size: 0xe8, Type: StructProperty)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_7; // 0x64f0 (Size: 0xe8, Type: StructProperty)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_6; // 0x65d8 (Size: 0xe8, Type: StructProperty)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2; // 0x66c0 (Size: 0x128, Type: StructProperty)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_5; // 0x67e8 (Size: 0xe8, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_3; // 0x68d0 (Size: 0x20, Type: StructProperty)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_4; // 0x68f0 (Size: 0xe8, Type: StructProperty)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone_1; // 0x69d8 (Size: 0x128, Type: StructProperty)
    FAnimNode_ModifyBone AnimGraphNode_ModifyBone; // 0x6b00 (Size: 0x128, Type: StructProperty)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_3; // 0x6c28 (Size: 0xe8, Type: StructProperty)
    FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0x6d10 (Size: 0x20, Type: StructProperty)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_2; // 0x6d30 (Size: 0xe8, Type: StructProperty)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x6e18 (Size: 0x78, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x6e90 (Size: 0x28, Type: StructProperty)
    FAnimNode_CopyBone AnimGraphNode_CopyBone_1; // 0x6eb8 (Size: 0xe8, Type: StructProperty)
    FAnimNode_Inertialization AnimGraphNode_Inertialization; // 0x6fa0 (Size: 0x530, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x74d0 (Size: 0x48, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive; // 0x7518 (Size: 0xc8, Type: StructProperty)
    FAnimNode_CopyBone AnimGraphNode_CopyBone; // 0x75e0 (Size: 0xe8, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_2; // 0x76c8 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_3; // 0x76e8 (Size: 0xb0, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_2; // 0x7798 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_1; // 0x7848 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_1; // 0x7868 (Size: 0xb0, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose; // 0x7918 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root; // 0x79c8 (Size: 0x20, Type: StructProperty)
    uint8_t MenuScreenDispatcher[0x10]; // 0x79e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool IsSkydiveDiving_Potato; // 0x79f8 (Size: 0x1, Type: BoolProperty)
    bool HasBeenSelected; // 0x79f9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79fa[0x2]; // 0x79fa (Size: 0x2, Type: PaddingProperty)
    int32_t PoseInt; // 0x79fc (Size: 0x4, Type: IntProperty)
    FVector OffsetTranslate; // 0x7a00 (Size: 0x18, Type: StructProperty)
    FRotator OffsetRotate; // 0x7a18 (Size: 0x18, Type: StructProperty)
    APlayerPawn_Athena_C* PawnOwner; // 0x7a30 (Size: 0x8, Type: ObjectProperty)
    double StartTime; // 0x7a38 (Size: 0x8, Type: DoubleProperty)
    double PlayRate; // 0x7a40 (Size: 0x8, Type: DoubleProperty)
    double HidePropTimeRemaining; // 0x7a48 (Size: 0x8, Type: DoubleProperty)
    bool HidePropBones; // 0x7a50 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7a51[0x7]; // 0x7a51 (Size: 0x7, Type: PaddingProperty)
    UAnimMontage* Current_Idle_Montage; // 0x7a58 (Size: 0x8, Type: ObjectProperty)
    double Skydive_Aim_Yaw; // 0x7a60 (Size: 0x8, Type: DoubleProperty)
    double Skydive_Aim_Pitch; // 0x7a68 (Size: 0x8, Type: DoubleProperty)
    UAnimInstance* MainAnimInstance; // 0x7a70 (Size: 0x8, Type: ObjectProperty)
    double WeaponAdditiveAlpha; // 0x7a78 (Size: 0x8, Type: DoubleProperty)

public:
    void MenuScreenDispatcher__DelegateSignature(); // 0x288a61c (Index: 0x7, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void BlueprintInitializeAnimation(); // 0x288a61c (Index: 0x11, Flags: Event|Public|BlueprintEvent)
    virtual void BlueprintUpdateAnimation(float& DeltaTimeX); // 0x288a61c (Index: 0x15, Flags: Event|Public|BlueprintEvent)
    void CalculateMontagePlayTiming(); // 0x288a61c (Index: 0x17, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HidePropsForBlend(UAnimMontage*& NewMontage, bool& BlendingIn); // 0x288a61c (Index: 0x23, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnFocusedItemChanged(UFortItemDefinition*& const FocusedItem, AFortWeapon*& const EquippedWeapon, AFortPlayerParachute*& const InCurrentParachute); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UMenuScreen_AthenaLayer_C) == 0x7a80, "Size mismatch for UMenuScreen_AthenaLayer_C");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, UberGraphFrame) == 0xa00, "Offset mismatch for UMenuScreen_AthenaLayer_C::UberGraphFrame");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, __AnimBlueprintMutables) == 0xa08, "Offset mismatch for UMenuScreen_AthenaLayer_C::__AnimBlueprintMutables");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimBlueprintExtension_PropertyAccess) == 0xbc8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimBlueprintExtension_PropertyAccess");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimBlueprintExtension_Base) == 0xbd0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimBlueprintExtension_Base");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_16) == 0xbd8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_16");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_14) == 0xc88, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_14");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_15) == 0xca8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_15");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_16) == 0xd58, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_16");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_13) == 0xda0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_13");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_14) == 0xdc0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_14");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_12) == 0xe70, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_12");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_11) == 0xe90, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_11");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_13) == 0xeb0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_13");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_10) == 0xf60, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_10");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_12) == 0xf80, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_12");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_11) == 0x1030, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_11");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_9) == 0x10e0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_9");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_10) == 0x1100, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_10");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_8) == 0x11b0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_8");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_9) == 0x11d0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_9");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_8) == 0x1280, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_8");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_7) == 0x1330, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_7");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_7) == 0x1350, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_7");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_6) == 0x1400, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_6");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_6) == 0x1420, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_6");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_5) == 0x14d0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_5");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_5) == 0x14f0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_5");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Slot) == 0x15a0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Slot");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByBool_2) == 0x15e8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByBool_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByBool_1) == 0x1638, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByBool_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SaveCachedPose_3) == 0x1688, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SaveCachedPose_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_TransitionResult_2) == 0x1700, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_TransitionResult_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_56) == 0x1728, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_56");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_55) == 0x1798, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_55");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_54) == 0x1808, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_54");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_53) == 0x1878, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_53");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_52) == 0x18e8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_52");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_34) == 0x1958, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_34");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_33) == 0x19a8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_33");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_32) == 0x19f8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_32");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_16) == 0x1a48, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_16");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_13) == 0x1a68, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_13");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_51) == 0x1b30, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_51");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_50) == 0x1ba0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_50");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_49) == 0x1c10, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_49");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_48) == 0x1c80, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_48");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_47) == 0x1cf0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_47");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_46) == 0x1d60, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_46");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_45) == 0x1dd0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_45");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_44) == 0x1e40, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_44");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_43) == 0x1eb0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_43");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_42) == 0x1f20, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_42");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_TwoWayBlend) == 0x1f90, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_TwoWayBlend");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_31) == 0x2050, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_31");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_30) == 0x20a0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_30");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_29) == 0x20f0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_29");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_28) == 0x2140, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_28");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_27) == 0x2190, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_27");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_26) == 0x21e0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_26");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_15) == 0x2230, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_15");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_12) == 0x2250, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_12");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_15) == 0x2318, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_15");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_14) == 0x23e0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_14");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_41) == 0x24a8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_41");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_14) == 0x2518, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_14");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_40) == 0x2538, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_40");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_39) == 0x25a8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_39");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_38) == 0x2618, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_38");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_37) == 0x2688, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_37");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_25) == 0x26f8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_25");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_24) == 0x2748, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_24");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_23) == 0x2798, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_23");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_36) == 0x27e8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_36");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_13) == 0x2858, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_13");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_11) == 0x2878, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_11");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_35) == 0x2940, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_35");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_34) == 0x29b0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_34");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_33) == 0x2a20, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_33");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_32) == 0x2a90, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_32");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_22) == 0x2b00, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_22");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_21) == 0x2b50, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_21");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_31) == 0x2ba0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_31");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_20) == 0x2c10, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_20");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_12) == 0x2c60, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_12");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_10) == 0x2c80, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_10");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_13) == 0x2d48, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_13");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_30) == 0x2e10, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_30");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_12) == 0x2e80, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_12");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_11) == 0x2f48, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_11");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_9) == 0x2f68, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_9");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_11) == 0x3030, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_11");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_TransitionResult_1) == 0x30f8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_TransitionResult_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_29) == 0x3120, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_29");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_10) == 0x3190, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_10");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_8) == 0x31b0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_8");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_10) == 0x3278, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_10");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_9) == 0x3340, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_9");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_15) == 0x3408, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_15");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_8) == 0x3450, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_8");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_28) == 0x3518, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_28");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_7) == 0x3588, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_7");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_27) == 0x3650, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_27");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_26) == 0x36c0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_26");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_9) == 0x3730, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_9");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_6) == 0x3750, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_6");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_25) == 0x3818, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_25");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_24) == 0x3888, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_24");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_19) == 0x38f8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_19");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_5) == 0x3948, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_5");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_23) == 0x3a10, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_23");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_22) == 0x3a80, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_22");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_8) == 0x3af0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_8");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_7) == 0x3b10, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_7");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_14) == 0x3bd8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_14");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_13) == 0x3c20, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_13");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_12) == 0x3c68, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_12");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_11) == 0x3cb0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_11");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_10) == 0x3cf8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_10");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_18) == 0x3d40, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_18");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_17) == 0x3d90, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_17");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_16) == 0x3de0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_16");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_7) == 0x3e30, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_7");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_6) == 0x3e50, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_6");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_15) == 0x3f18, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_15");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_TransitionResult) == 0x3f68, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_TransitionResult");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_21) == 0x3f90, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_21");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_20) == 0x4000, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_20");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_19) == 0x4070, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_19");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_18) == 0x40e0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_18");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_17) == 0x4150, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_17");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_14) == 0x41c0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_14");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_13) == 0x4210, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_13");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_12) == 0x4260, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_12");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_6) == 0x42b0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_6");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_5) == 0x42d0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_5");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_16) == 0x4398, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_16");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_15) == 0x4408, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_15");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_14) == 0x4478, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_14");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_13) == 0x44e8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_13");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_12) == 0x4558, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_12");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_11) == 0x45c8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_11");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_10) == 0x4618, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_10");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_9) == 0x4668, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_9");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_5) == 0x46b8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_5");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_4) == 0x46d8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_4");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_4) == 0x47a0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_4");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_3) == 0x4868, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_11) == 0x4930, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_11");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_4) == 0x49a0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_4");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_10) == 0x49c0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_10");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_9) == 0x4a30, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_9");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_8) == 0x4aa0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_8");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_7) == 0x4b10, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_7");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_8) == 0x4b80, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_8");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_7) == 0x4bd0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_7");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_6) == 0x4c20, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_6");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_6) == 0x4c90, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_6");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_3) == 0x4ce0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_3) == 0x4d00, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_5) == 0x4dc8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_5");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_4) == 0x4e38, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_4");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_3) == 0x4ea8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_2) == 0x4f18, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_5) == 0x4f88, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_5");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_4) == 0x4fd8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_4");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_3) == 0x5028, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer_1) == 0x5078, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_2) == 0x50e8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_2) == 0x5108, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_2) == 0x51d0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendSpacePlayer) == 0x5298, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendSpacePlayer");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive_1) == 0x5308, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult_1) == 0x53d0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine_1) == 0x53f0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SaveCachedPose_2) == 0x54b8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SaveCachedPose_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SaveCachedPose_1) == 0x5530, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SaveCachedPose_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_UseCachedPose_4) == 0x55a8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_UseCachedPose_4");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_UseCachedPose_3) == 0x55d0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_UseCachedPose_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByBool) == 0x55f8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByBool");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_UseCachedPose_2) == 0x5648, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_UseCachedPose_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_UseCachedPose_1) == 0x5670, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_UseCachedPose_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_9) == 0x5698, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_9");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByInt_3) == 0x56e0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByInt_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByInt_2) == 0x5730, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByInt_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_8) == 0x5780, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_8");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_7) == 0x57c8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_7");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_6) == 0x5810, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_6");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_5) == 0x5858, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_5");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_2) == 0x58a0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum_1) == 0x58f0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByInt_1) == 0x5940, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByInt_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByInt) == 0x5990, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByInt");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_4) == 0x59e0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_4");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_3) == 0x5a28, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_2) == 0x5a70, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer_1) == 0x5ab8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_BlendListByEnum) == 0x5b00, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_BlendListByEnum");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateResult) == 0x5b50, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateResult");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_StateMachine) == 0x5b70, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_StateMachine");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_4) == 0x5c38, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_4");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_4) == 0x5c58, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_4");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ComponentToLocalSpace) == 0x5d08, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ComponentToLocalSpace");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LegIK_2) == 0x5d28, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LegIK_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ModifyBone_3) == 0x5e28, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ModifyBone_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LegIK_1) == 0x5f50, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LegIK_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_CopyBone_11) == 0x6050, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_CopyBone_11");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_CopyBone_10) == 0x6138, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_CopyBone_10");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_CopyBone_9) == 0x6220, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_CopyBone_9");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LegIK) == 0x6308, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LegIK");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_CopyBone_8) == 0x6408, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_CopyBone_8");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_CopyBone_7) == 0x64f0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_CopyBone_7");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_CopyBone_6) == 0x65d8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_CopyBone_6");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ModifyBone_2) == 0x66c0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ModifyBone_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_CopyBone_5) == 0x67e8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_CopyBone_5");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_3) == 0x68d0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_CopyBone_4) == 0x68f0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_CopyBone_4");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ModifyBone_1) == 0x69d8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ModifyBone_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ModifyBone) == 0x6b00, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ModifyBone");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_CopyBone_3) == 0x6c28, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_CopyBone_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LocalToComponentSpace) == 0x6d10, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LocalToComponentSpace");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_CopyBone_2) == 0x6d30, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_CopyBone_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SaveCachedPose) == 0x6e18, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SaveCachedPose");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_UseCachedPose) == 0x6e90, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_UseCachedPose");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_CopyBone_1) == 0x6eb8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_CopyBone_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Inertialization) == 0x6fa0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Inertialization");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_SequencePlayer) == 0x74d0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_SequencePlayer");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_ApplyAdditive) == 0x7518, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_ApplyAdditive");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_CopyBone) == 0x75e0, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_CopyBone");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_2) == 0x76c8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_3) == 0x76e8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_3");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_2) == 0x7798, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_2");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root_1) == 0x7848, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose_1) == 0x7868, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose_1");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_LinkedInputPose) == 0x7918, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_LinkedInputPose");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, AnimGraphNode_Root) == 0x79c8, "Offset mismatch for UMenuScreen_AthenaLayer_C::AnimGraphNode_Root");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, MenuScreenDispatcher) == 0x79e8, "Offset mismatch for UMenuScreen_AthenaLayer_C::MenuScreenDispatcher");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, IsSkydiveDiving_Potato) == 0x79f8, "Offset mismatch for UMenuScreen_AthenaLayer_C::IsSkydiveDiving_Potato");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, HasBeenSelected) == 0x79f9, "Offset mismatch for UMenuScreen_AthenaLayer_C::HasBeenSelected");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, PoseInt) == 0x79fc, "Offset mismatch for UMenuScreen_AthenaLayer_C::PoseInt");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, OffsetTranslate) == 0x7a00, "Offset mismatch for UMenuScreen_AthenaLayer_C::OffsetTranslate");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, OffsetRotate) == 0x7a18, "Offset mismatch for UMenuScreen_AthenaLayer_C::OffsetRotate");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, PawnOwner) == 0x7a30, "Offset mismatch for UMenuScreen_AthenaLayer_C::PawnOwner");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, StartTime) == 0x7a38, "Offset mismatch for UMenuScreen_AthenaLayer_C::StartTime");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, PlayRate) == 0x7a40, "Offset mismatch for UMenuScreen_AthenaLayer_C::PlayRate");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, HidePropTimeRemaining) == 0x7a48, "Offset mismatch for UMenuScreen_AthenaLayer_C::HidePropTimeRemaining");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, HidePropBones) == 0x7a50, "Offset mismatch for UMenuScreen_AthenaLayer_C::HidePropBones");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, Current_Idle_Montage) == 0x7a58, "Offset mismatch for UMenuScreen_AthenaLayer_C::Current_Idle_Montage");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, Skydive_Aim_Yaw) == 0x7a60, "Offset mismatch for UMenuScreen_AthenaLayer_C::Skydive_Aim_Yaw");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, Skydive_Aim_Pitch) == 0x7a68, "Offset mismatch for UMenuScreen_AthenaLayer_C::Skydive_Aim_Pitch");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, MainAnimInstance) == 0x7a70, "Offset mismatch for UMenuScreen_AthenaLayer_C::MainAnimInstance");
static_assert(offsetof(UMenuScreen_AthenaLayer_C, WeaponAdditiveAlpha) == 0x7a78, "Offset mismatch for UMenuScreen_AthenaLayer_C::WeaponAdditiveAlpha");

