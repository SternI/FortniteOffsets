/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioMotorSimStandardComponents
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "AudioMotorSim.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x170 (Inherited: 0x1a8, Single: 0xffffffc8)
class UBoostMotorSimComponent : public UAudioMotorSimComponent
{
public:
    float ThrottleScale; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float InterpExp; // 0xcc (Size: 0x4, Type: FloatProperty)
    float InterpTime; // 0xd0 (Size: 0x4, Type: FloatProperty)
    bool ScaleThrottleWithBoostStrength; // 0xd4 (Size: 0x1, Type: BoolProperty)
    bool bModifyPitch; // 0xd5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d6[0x2]; // 0xd6 (Size: 0x2, Type: PaddingProperty)
    float PitchModifierInterpSpeed; // 0xd8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_dc[0x4]; // 0xdc (Size: 0x4, Type: PaddingProperty)
    FRuntimeFloatCurve BoostToPitchCurve; // 0xe0 (Size: 0x88, Type: StructProperty)
    uint8_t Pad_168[0x8]; // 0x168 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UBoostMotorSimComponent) == 0x170, "Size mismatch for UBoostMotorSimComponent");
static_assert(offsetof(UBoostMotorSimComponent, ThrottleScale) == 0xc8, "Offset mismatch for UBoostMotorSimComponent::ThrottleScale");
static_assert(offsetof(UBoostMotorSimComponent, InterpExp) == 0xcc, "Offset mismatch for UBoostMotorSimComponent::InterpExp");
static_assert(offsetof(UBoostMotorSimComponent, InterpTime) == 0xd0, "Offset mismatch for UBoostMotorSimComponent::InterpTime");
static_assert(offsetof(UBoostMotorSimComponent, ScaleThrottleWithBoostStrength) == 0xd4, "Offset mismatch for UBoostMotorSimComponent::ScaleThrottleWithBoostStrength");
static_assert(offsetof(UBoostMotorSimComponent, bModifyPitch) == 0xd5, "Offset mismatch for UBoostMotorSimComponent::bModifyPitch");
static_assert(offsetof(UBoostMotorSimComponent, PitchModifierInterpSpeed) == 0xd8, "Offset mismatch for UBoostMotorSimComponent::PitchModifierInterpSpeed");
static_assert(offsetof(UBoostMotorSimComponent, BoostToPitchCurve) == 0xe0, "Offset mismatch for UBoostMotorSimComponent::BoostToPitchCurve");

// Size: 0x130 (Inherited: 0x1a8, Single: 0xffffff88)
class UMotorPhysicsSimComponent : public UAudioMotorSimComponent
{
public:
    float Weight; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float EngineTorque; // 0xcc (Size: 0x4, Type: FloatProperty)
    float BrakingHorsePower; // 0xd0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_d4[0x4]; // 0xd4 (Size: 0x4, Type: PaddingProperty)
    TArray<float> GearRatios; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    float ClutchedGearRatio; // 0xe8 (Size: 0x4, Type: FloatProperty)
    bool bUseInfiniteGears; // 0xec (Size: 0x1, Type: BoolProperty)
    bool bAlwaysDownshiftToZerothGear; // 0xed (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ee[0x2]; // 0xee (Size: 0x2, Type: PaddingProperty)
    float InfiniteGearRatio; // 0xf0 (Size: 0x4, Type: FloatProperty)
    float UpShiftMaxRpm; // 0xf4 (Size: 0x4, Type: FloatProperty)
    float DownShiftStartRpm; // 0xf8 (Size: 0x4, Type: FloatProperty)
    float ClutchedForceModifier; // 0xfc (Size: 0x4, Type: FloatProperty)
    float ClutchedDecelScale; // 0x100 (Size: 0x4, Type: FloatProperty)
    float EngineGearRatio; // 0x104 (Size: 0x4, Type: FloatProperty)
    float EngineFriction; // 0x108 (Size: 0x4, Type: FloatProperty)
    float GroundFriction; // 0x10c (Size: 0x4, Type: FloatProperty)
    float WindResistancePerVelocity; // 0x110 (Size: 0x4, Type: FloatProperty)
    float ThrottleInterpolationTime; // 0x114 (Size: 0x4, Type: FloatProperty)
    float RpmInterpSpeed; // 0x118 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_11c[0x4]; // 0x11c (Size: 0x4, Type: PaddingProperty)
    uint8_t OnGearChangedEvent[0x10]; // 0x120 (Size: 0x10, Type: MulticastInlineDelegateProperty)
};

static_assert(sizeof(UMotorPhysicsSimComponent) == 0x130, "Size mismatch for UMotorPhysicsSimComponent");
static_assert(offsetof(UMotorPhysicsSimComponent, Weight) == 0xc8, "Offset mismatch for UMotorPhysicsSimComponent::Weight");
static_assert(offsetof(UMotorPhysicsSimComponent, EngineTorque) == 0xcc, "Offset mismatch for UMotorPhysicsSimComponent::EngineTorque");
static_assert(offsetof(UMotorPhysicsSimComponent, BrakingHorsePower) == 0xd0, "Offset mismatch for UMotorPhysicsSimComponent::BrakingHorsePower");
static_assert(offsetof(UMotorPhysicsSimComponent, GearRatios) == 0xd8, "Offset mismatch for UMotorPhysicsSimComponent::GearRatios");
static_assert(offsetof(UMotorPhysicsSimComponent, ClutchedGearRatio) == 0xe8, "Offset mismatch for UMotorPhysicsSimComponent::ClutchedGearRatio");
static_assert(offsetof(UMotorPhysicsSimComponent, bUseInfiniteGears) == 0xec, "Offset mismatch for UMotorPhysicsSimComponent::bUseInfiniteGears");
static_assert(offsetof(UMotorPhysicsSimComponent, bAlwaysDownshiftToZerothGear) == 0xed, "Offset mismatch for UMotorPhysicsSimComponent::bAlwaysDownshiftToZerothGear");
static_assert(offsetof(UMotorPhysicsSimComponent, InfiniteGearRatio) == 0xf0, "Offset mismatch for UMotorPhysicsSimComponent::InfiniteGearRatio");
static_assert(offsetof(UMotorPhysicsSimComponent, UpShiftMaxRpm) == 0xf4, "Offset mismatch for UMotorPhysicsSimComponent::UpShiftMaxRpm");
static_assert(offsetof(UMotorPhysicsSimComponent, DownShiftStartRpm) == 0xf8, "Offset mismatch for UMotorPhysicsSimComponent::DownShiftStartRpm");
static_assert(offsetof(UMotorPhysicsSimComponent, ClutchedForceModifier) == 0xfc, "Offset mismatch for UMotorPhysicsSimComponent::ClutchedForceModifier");
static_assert(offsetof(UMotorPhysicsSimComponent, ClutchedDecelScale) == 0x100, "Offset mismatch for UMotorPhysicsSimComponent::ClutchedDecelScale");
static_assert(offsetof(UMotorPhysicsSimComponent, EngineGearRatio) == 0x104, "Offset mismatch for UMotorPhysicsSimComponent::EngineGearRatio");
static_assert(offsetof(UMotorPhysicsSimComponent, EngineFriction) == 0x108, "Offset mismatch for UMotorPhysicsSimComponent::EngineFriction");
static_assert(offsetof(UMotorPhysicsSimComponent, GroundFriction) == 0x10c, "Offset mismatch for UMotorPhysicsSimComponent::GroundFriction");
static_assert(offsetof(UMotorPhysicsSimComponent, WindResistancePerVelocity) == 0x110, "Offset mismatch for UMotorPhysicsSimComponent::WindResistancePerVelocity");
static_assert(offsetof(UMotorPhysicsSimComponent, ThrottleInterpolationTime) == 0x114, "Offset mismatch for UMotorPhysicsSimComponent::ThrottleInterpolationTime");
static_assert(offsetof(UMotorPhysicsSimComponent, RpmInterpSpeed) == 0x118, "Offset mismatch for UMotorPhysicsSimComponent::RpmInterpSpeed");
static_assert(offsetof(UMotorPhysicsSimComponent, OnGearChangedEvent) == 0x120, "Offset mismatch for UMotorPhysicsSimComponent::OnGearChangedEvent");

// Size: 0x158 (Inherited: 0x1a8, Single: 0xffffffb0)
class UResistanceMotorSimComponent : public UAudioMotorSimComponent
{
public:
    float UpSpeedMaxFriction; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float MinSpeed; // 0xcc (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve SideSpeedFrictionCurve; // 0xd0 (Size: 0x88, Type: StructProperty)
};

static_assert(sizeof(UResistanceMotorSimComponent) == 0x158, "Size mismatch for UResistanceMotorSimComponent");
static_assert(offsetof(UResistanceMotorSimComponent, UpSpeedMaxFriction) == 0xc8, "Offset mismatch for UResistanceMotorSimComponent::UpSpeedMaxFriction");
static_assert(offsetof(UResistanceMotorSimComponent, MinSpeed) == 0xcc, "Offset mismatch for UResistanceMotorSimComponent::MinSpeed");
static_assert(offsetof(UResistanceMotorSimComponent, SideSpeedFrictionCurve) == 0xd0, "Offset mismatch for UResistanceMotorSimComponent::SideSpeedFrictionCurve");

// Size: 0xd0 (Inherited: 0x1a8, Single: 0xffffff28)
class UReverseMotorSimComponent : public UAudioMotorSimComponent
{
public:
    float ReverseEngineResistanceModifier; // 0xc8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_cc[0x4]; // 0xcc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UReverseMotorSimComponent) == 0xd0, "Size mismatch for UReverseMotorSimComponent");
static_assert(offsetof(UReverseMotorSimComponent, ReverseEngineResistanceModifier) == 0xc8, "Offset mismatch for UReverseMotorSimComponent::ReverseEngineResistanceModifier");

// Size: 0x118 (Inherited: 0x1a8, Single: 0xffffff70)
class URevLimiterMotorSimComponent : public UAudioMotorSimComponent
{
public:
    float LimitTime; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float DecelScale; // 0xcc (Size: 0x4, Type: FloatProperty)
    float AirMaxThrottleTime; // 0xd0 (Size: 0x4, Type: FloatProperty)
    float SideSpeedThreshold; // 0xd4 (Size: 0x4, Type: FloatProperty)
    float LimiterMaxRpm; // 0xd8 (Size: 0x4, Type: FloatProperty)
    bool bRevLimitOnClutchEngaged; // 0xdc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_dd[0x3]; // 0xdd (Size: 0x3, Type: PaddingProperty)
    float RecoverRPM; // 0xe0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_e4[0x4]; // 0xe4 (Size: 0x4, Type: PaddingProperty)
    uint8_t OnRevLimiterHit[0x10]; // 0xe8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnRevLimiterStateChanged[0x10]; // 0xf8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_108[0x10]; // 0x108 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(URevLimiterMotorSimComponent) == 0x118, "Size mismatch for URevLimiterMotorSimComponent");
static_assert(offsetof(URevLimiterMotorSimComponent, LimitTime) == 0xc8, "Offset mismatch for URevLimiterMotorSimComponent::LimitTime");
static_assert(offsetof(URevLimiterMotorSimComponent, DecelScale) == 0xcc, "Offset mismatch for URevLimiterMotorSimComponent::DecelScale");
static_assert(offsetof(URevLimiterMotorSimComponent, AirMaxThrottleTime) == 0xd0, "Offset mismatch for URevLimiterMotorSimComponent::AirMaxThrottleTime");
static_assert(offsetof(URevLimiterMotorSimComponent, SideSpeedThreshold) == 0xd4, "Offset mismatch for URevLimiterMotorSimComponent::SideSpeedThreshold");
static_assert(offsetof(URevLimiterMotorSimComponent, LimiterMaxRpm) == 0xd8, "Offset mismatch for URevLimiterMotorSimComponent::LimiterMaxRpm");
static_assert(offsetof(URevLimiterMotorSimComponent, bRevLimitOnClutchEngaged) == 0xdc, "Offset mismatch for URevLimiterMotorSimComponent::bRevLimitOnClutchEngaged");
static_assert(offsetof(URevLimiterMotorSimComponent, RecoverRPM) == 0xe0, "Offset mismatch for URevLimiterMotorSimComponent::RecoverRPM");
static_assert(offsetof(URevLimiterMotorSimComponent, OnRevLimiterHit) == 0xe8, "Offset mismatch for URevLimiterMotorSimComponent::OnRevLimiterHit");
static_assert(offsetof(URevLimiterMotorSimComponent, OnRevLimiterStateChanged) == 0xf8, "Offset mismatch for URevLimiterMotorSimComponent::OnRevLimiterStateChanged");

// Size: 0x100 (Inherited: 0x1a8, Single: 0xffffff58)
class URpmCurveMotorSimComponent : public UAudioMotorSimComponent
{
public:
    TArray<FMotorSimGearCurve> Gears; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    float InterpSpeed; // 0xd8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_dc[0x4]; // 0xdc (Size: 0x4, Type: PaddingProperty)
    uint8_t OnUpShift[0x10]; // 0xe0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnDownShift[0x10]; // 0xf0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
};

static_assert(sizeof(URpmCurveMotorSimComponent) == 0x100, "Size mismatch for URpmCurveMotorSimComponent");
static_assert(offsetof(URpmCurveMotorSimComponent, Gears) == 0xc8, "Offset mismatch for URpmCurveMotorSimComponent::Gears");
static_assert(offsetof(URpmCurveMotorSimComponent, InterpSpeed) == 0xd8, "Offset mismatch for URpmCurveMotorSimComponent::InterpSpeed");
static_assert(offsetof(URpmCurveMotorSimComponent, OnUpShift) == 0xe0, "Offset mismatch for URpmCurveMotorSimComponent::OnUpShift");
static_assert(offsetof(URpmCurveMotorSimComponent, OnDownShift) == 0xf0, "Offset mismatch for URpmCurveMotorSimComponent::OnDownShift");

// Size: 0x108 (Inherited: 0x1a8, Single: 0xffffff60)
class UThrottleStateMotorSimComponent : public UAudioMotorSimComponent
{
public:
    uint8_t OnThrottleEngaged[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnThrottleReleased[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEngineBlowoff[0x10]; // 0xe8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float BlowoffMinThrottleTime; // 0xf8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_fc[0xc]; // 0xfc (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UThrottleStateMotorSimComponent) == 0x108, "Size mismatch for UThrottleStateMotorSimComponent");
static_assert(offsetof(UThrottleStateMotorSimComponent, OnThrottleEngaged) == 0xc8, "Offset mismatch for UThrottleStateMotorSimComponent::OnThrottleEngaged");
static_assert(offsetof(UThrottleStateMotorSimComponent, OnThrottleReleased) == 0xd8, "Offset mismatch for UThrottleStateMotorSimComponent::OnThrottleReleased");
static_assert(offsetof(UThrottleStateMotorSimComponent, OnEngineBlowoff) == 0xe8, "Offset mismatch for UThrottleStateMotorSimComponent::OnEngineBlowoff");
static_assert(offsetof(UThrottleStateMotorSimComponent, BlowoffMinThrottleTime) == 0xf8, "Offset mismatch for UThrottleStateMotorSimComponent::BlowoffMinThrottleTime");

// Size: 0x170 (Inherited: 0x1a8, Single: 0xffffffc8)
class UVelocitySyncMotorSimComponent : public UAudioMotorSimComponent
{
public:
    float NoThrottleTime; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float SpeedThreshold; // 0xcc (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve SpeedToRpmCurve; // 0xd0 (Size: 0x88, Type: StructProperty)
    float InterpSpeed; // 0x158 (Size: 0x4, Type: FloatProperty)
    float InterpTime; // 0x15c (Size: 0x4, Type: FloatProperty)
    float FirstGearThrottleThreshold; // 0x160 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_164[0xc]; // 0x164 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(UVelocitySyncMotorSimComponent) == 0x170, "Size mismatch for UVelocitySyncMotorSimComponent");
static_assert(offsetof(UVelocitySyncMotorSimComponent, NoThrottleTime) == 0xc8, "Offset mismatch for UVelocitySyncMotorSimComponent::NoThrottleTime");
static_assert(offsetof(UVelocitySyncMotorSimComponent, SpeedThreshold) == 0xcc, "Offset mismatch for UVelocitySyncMotorSimComponent::SpeedThreshold");
static_assert(offsetof(UVelocitySyncMotorSimComponent, SpeedToRpmCurve) == 0xd0, "Offset mismatch for UVelocitySyncMotorSimComponent::SpeedToRpmCurve");
static_assert(offsetof(UVelocitySyncMotorSimComponent, InterpSpeed) == 0x158, "Offset mismatch for UVelocitySyncMotorSimComponent::InterpSpeed");
static_assert(offsetof(UVelocitySyncMotorSimComponent, InterpTime) == 0x15c, "Offset mismatch for UVelocitySyncMotorSimComponent::InterpTime");
static_assert(offsetof(UVelocitySyncMotorSimComponent, FirstGearThrottleThreshold) == 0x160, "Offset mismatch for UVelocitySyncMotorSimComponent::FirstGearThrottleThreshold");

// Size: 0xc (Inherited: 0x1, Single: 0xb)
struct FMotorPhysicsSimConfigData : FAudioMotorSimConfigData
{
    float Weight; // 0x0 (Size: 0x4, Type: FloatProperty)
    float EngineTorque; // 0x4 (Size: 0x4, Type: FloatProperty)
    float BrakingHorsePower; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FMotorPhysicsSimConfigData) == 0xc, "Size mismatch for FMotorPhysicsSimConfigData");
static_assert(offsetof(FMotorPhysicsSimConfigData, Weight) == 0x0, "Offset mismatch for FMotorPhysicsSimConfigData::Weight");
static_assert(offsetof(FMotorPhysicsSimConfigData, EngineTorque) == 0x4, "Offset mismatch for FMotorPhysicsSimConfigData::EngineTorque");
static_assert(offsetof(FMotorPhysicsSimConfigData, BrakingHorsePower) == 0x8, "Offset mismatch for FMotorPhysicsSimConfigData::BrakingHorsePower");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FMotorSimGearCurve
{
    FRuntimeFloatCurve RpmCurve; // 0x0 (Size: 0x88, Type: StructProperty)
    float SpeedTopThreshold; // 0x88 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FMotorSimGearCurve) == 0x90, "Size mismatch for FMotorSimGearCurve");
static_assert(offsetof(FMotorSimGearCurve, RpmCurve) == 0x0, "Offset mismatch for FMotorSimGearCurve::RpmCurve");
static_assert(offsetof(FMotorSimGearCurve, SpeedTopThreshold) == 0x88, "Offset mismatch for FMotorSimGearCurve::SpeedTopThreshold");

