/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AdvancedWidgets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "UMG.h"
#include "SlateCore.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x720 (Inherited: 0x1a8, Single: 0x578)
class URadialSlider : public UWidget
{
public:
    float Value; // 0x158 (Size: 0x4, Type: FloatProperty)
    uint8_t ValueDelegate[0xc]; // 0x15c (Size: 0xc, Type: DelegateProperty)
    bool bUseCustomDefaultValue; // 0x168 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_169[0x3]; // 0x169 (Size: 0x3, Type: PaddingProperty)
    float CustomDefaultValue; // 0x16c (Size: 0x4, Type: FloatProperty)
    FRuntimeFloatCurve SliderRange; // 0x170 (Size: 0x88, Type: StructProperty)
    TArray<float> ValueTags; // 0x1f8 (Size: 0x10, Type: ArrayProperty)
    float SliderHandleStartAngle; // 0x208 (Size: 0x4, Type: FloatProperty)
    float SliderHandleEndAngle; // 0x20c (Size: 0x4, Type: FloatProperty)
    float AngularOffset; // 0x210 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_214[0x4]; // 0x214 (Size: 0x4, Type: PaddingProperty)
    FVector2D HandStartEndRatio; // 0x218 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_228[0x8]; // 0x228 (Size: 0x8, Type: PaddingProperty)
    FSliderStyle WidgetStyle; // 0x230 (Size: 0x440, Type: StructProperty)
    FLinearColor SliderBarColor; // 0x670 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderProgressColor; // 0x680 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderHandleColor; // 0x690 (Size: 0x10, Type: StructProperty)
    FLinearColor CenterBackgroundColor; // 0x6a0 (Size: 0x10, Type: StructProperty)
    bool Locked; // 0x6b0 (Size: 0x1, Type: BoolProperty)
    bool MouseUsesStep; // 0x6b1 (Size: 0x1, Type: BoolProperty)
    bool RequiresControllerLock; // 0x6b2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6b3[0x1]; // 0x6b3 (Size: 0x1, Type: PaddingProperty)
    float StepSize; // 0x6b4 (Size: 0x4, Type: FloatProperty)
    bool IsFocusable; // 0x6b8 (Size: 0x1, Type: BoolProperty)
    bool UseVerticalDrag; // 0x6b9 (Size: 0x1, Type: BoolProperty)
    bool ShowSliderHandle; // 0x6ba (Size: 0x1, Type: BoolProperty)
    bool ShowSliderHand; // 0x6bb (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6bc[0x4]; // 0x6bc (Size: 0x4, Type: PaddingProperty)
    uint8_t OnMouseCaptureBegin[0x10]; // 0x6c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMouseCaptureEnd[0x10]; // 0x6d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnControllerCaptureBegin[0x10]; // 0x6e0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnControllerCaptureEnd[0x10]; // 0x6f0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnValueChanged[0x10]; // 0x700 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_710[0x10]; // 0x710 (Size: 0x10, Type: PaddingProperty)

public:
    float GetCustomDefaultValue() const; // 0xfd68570 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetNormalizedSliderHandlePosition() const; // 0xfd68598 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetValue() const; // 0xfd685d0 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetAngularOffset(float& InValue); // 0xfd685f8 (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetCenterBackgroundColor(FLinearColor& InValue); // 0xfd68728 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetCustomDefaultValue(float& InValue); // 0xfd68804 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetHandStartEndRatio(FVector2D& InValue); // 0xfd68930 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetLocked(bool& InValue); // 0xfd68a34 (Index: 0x7, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetShowSliderHand(bool& InShowSliderHand); // 0xfd68db4 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetShowSliderHandle(bool& InShowSliderHandle); // 0xfd68ee4 (Index: 0x9, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSliderBarColor(FLinearColor& InValue); // 0xfd69014 (Index: 0xa, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetSliderHandleColor(FLinearColor& InValue); // 0xfd690f0 (Index: 0xb, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetSliderHandleEndAngle(float& InValue); // 0xfd691cc (Index: 0xc, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSliderHandleStartAngle(float& InValue); // 0xfd69304 (Index: 0xd, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetSliderProgressColor(FLinearColor& InValue); // 0xfd6943c (Index: 0xe, Flags: Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable)
    void SetSliderRange(const FRuntimeFloatCurve InSliderRange); // 0xfd69518 (Index: 0xf, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
    void SetStepSize(float& InValue); // 0xfd69640 (Index: 0x10, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetUseVerticalDrag(bool& InUseVerticalDrag); // 0xfd6976c (Index: 0x11, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetValue(float& InValue); // 0xfd6989c (Index: 0x12, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetValueTags(const TArray<float> InValueTags); // 0xfd699c8 (Index: 0x13, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(URadialSlider) == 0x720, "Size mismatch for URadialSlider");
static_assert(offsetof(URadialSlider, Value) == 0x158, "Offset mismatch for URadialSlider::Value");
static_assert(offsetof(URadialSlider, ValueDelegate) == 0x15c, "Offset mismatch for URadialSlider::ValueDelegate");
static_assert(offsetof(URadialSlider, bUseCustomDefaultValue) == 0x168, "Offset mismatch for URadialSlider::bUseCustomDefaultValue");
static_assert(offsetof(URadialSlider, CustomDefaultValue) == 0x16c, "Offset mismatch for URadialSlider::CustomDefaultValue");
static_assert(offsetof(URadialSlider, SliderRange) == 0x170, "Offset mismatch for URadialSlider::SliderRange");
static_assert(offsetof(URadialSlider, ValueTags) == 0x1f8, "Offset mismatch for URadialSlider::ValueTags");
static_assert(offsetof(URadialSlider, SliderHandleStartAngle) == 0x208, "Offset mismatch for URadialSlider::SliderHandleStartAngle");
static_assert(offsetof(URadialSlider, SliderHandleEndAngle) == 0x20c, "Offset mismatch for URadialSlider::SliderHandleEndAngle");
static_assert(offsetof(URadialSlider, AngularOffset) == 0x210, "Offset mismatch for URadialSlider::AngularOffset");
static_assert(offsetof(URadialSlider, HandStartEndRatio) == 0x218, "Offset mismatch for URadialSlider::HandStartEndRatio");
static_assert(offsetof(URadialSlider, WidgetStyle) == 0x230, "Offset mismatch for URadialSlider::WidgetStyle");
static_assert(offsetof(URadialSlider, SliderBarColor) == 0x670, "Offset mismatch for URadialSlider::SliderBarColor");
static_assert(offsetof(URadialSlider, SliderProgressColor) == 0x680, "Offset mismatch for URadialSlider::SliderProgressColor");
static_assert(offsetof(URadialSlider, SliderHandleColor) == 0x690, "Offset mismatch for URadialSlider::SliderHandleColor");
static_assert(offsetof(URadialSlider, CenterBackgroundColor) == 0x6a0, "Offset mismatch for URadialSlider::CenterBackgroundColor");
static_assert(offsetof(URadialSlider, Locked) == 0x6b0, "Offset mismatch for URadialSlider::Locked");
static_assert(offsetof(URadialSlider, MouseUsesStep) == 0x6b1, "Offset mismatch for URadialSlider::MouseUsesStep");
static_assert(offsetof(URadialSlider, RequiresControllerLock) == 0x6b2, "Offset mismatch for URadialSlider::RequiresControllerLock");
static_assert(offsetof(URadialSlider, StepSize) == 0x6b4, "Offset mismatch for URadialSlider::StepSize");
static_assert(offsetof(URadialSlider, IsFocusable) == 0x6b8, "Offset mismatch for URadialSlider::IsFocusable");
static_assert(offsetof(URadialSlider, UseVerticalDrag) == 0x6b9, "Offset mismatch for URadialSlider::UseVerticalDrag");
static_assert(offsetof(URadialSlider, ShowSliderHandle) == 0x6ba, "Offset mismatch for URadialSlider::ShowSliderHandle");
static_assert(offsetof(URadialSlider, ShowSliderHand) == 0x6bb, "Offset mismatch for URadialSlider::ShowSliderHand");
static_assert(offsetof(URadialSlider, OnMouseCaptureBegin) == 0x6c0, "Offset mismatch for URadialSlider::OnMouseCaptureBegin");
static_assert(offsetof(URadialSlider, OnMouseCaptureEnd) == 0x6d0, "Offset mismatch for URadialSlider::OnMouseCaptureEnd");
static_assert(offsetof(URadialSlider, OnControllerCaptureBegin) == 0x6e0, "Offset mismatch for URadialSlider::OnControllerCaptureBegin");
static_assert(offsetof(URadialSlider, OnControllerCaptureEnd) == 0x6f0, "Offset mismatch for URadialSlider::OnControllerCaptureEnd");
static_assert(offsetof(URadialSlider, OnValueChanged) == 0x700, "Offset mismatch for URadialSlider::OnValueChanged");

// Size: 0x2e0 (Inherited: 0x8, Single: 0x2d8)
struct FColorGradingSpinBoxStyle : FSlateWidgetStyle
{
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush BorderBrush; // 0x10 (Size: 0xb0, Type: StructProperty)
    FSlateBrush ActiveBorderBrush; // 0xc0 (Size: 0xb0, Type: StructProperty)
    FSlateBrush HoveredBorderBrush; // 0x170 (Size: 0xb0, Type: StructProperty)
    FSlateBrush SelectorBrush; // 0x220 (Size: 0xb0, Type: StructProperty)
    float SelectorWidth; // 0x2d0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2d4[0xc]; // 0x2d4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FColorGradingSpinBoxStyle) == 0x2e0, "Size mismatch for FColorGradingSpinBoxStyle");
static_assert(offsetof(FColorGradingSpinBoxStyle, BorderBrush) == 0x10, "Offset mismatch for FColorGradingSpinBoxStyle::BorderBrush");
static_assert(offsetof(FColorGradingSpinBoxStyle, ActiveBorderBrush) == 0xc0, "Offset mismatch for FColorGradingSpinBoxStyle::ActiveBorderBrush");
static_assert(offsetof(FColorGradingSpinBoxStyle, HoveredBorderBrush) == 0x170, "Offset mismatch for FColorGradingSpinBoxStyle::HoveredBorderBrush");
static_assert(offsetof(FColorGradingSpinBoxStyle, SelectorBrush) == 0x220, "Offset mismatch for FColorGradingSpinBoxStyle::SelectorBrush");
static_assert(offsetof(FColorGradingSpinBoxStyle, SelectorWidth) == 0x2d0, "Offset mismatch for FColorGradingSpinBoxStyle::SelectorWidth");

