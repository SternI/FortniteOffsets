/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioPlatformConfiguration
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FPlatformRuntimeAudioCompressionOverrides
{
    bool bOverrideCompressionTimes; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float DurationThreshold; // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t MaxNumRandomBranches; // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t SoundCueQualityIndex; // 0xc (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FPlatformRuntimeAudioCompressionOverrides) == 0x10, "Size mismatch for FPlatformRuntimeAudioCompressionOverrides");
static_assert(offsetof(FPlatformRuntimeAudioCompressionOverrides, bOverrideCompressionTimes) == 0x0, "Offset mismatch for FPlatformRuntimeAudioCompressionOverrides::bOverrideCompressionTimes");
static_assert(offsetof(FPlatformRuntimeAudioCompressionOverrides, DurationThreshold) == 0x4, "Offset mismatch for FPlatformRuntimeAudioCompressionOverrides::DurationThreshold");
static_assert(offsetof(FPlatformRuntimeAudioCompressionOverrides, MaxNumRandomBranches) == 0x8, "Offset mismatch for FPlatformRuntimeAudioCompressionOverrides::MaxNumRandomBranches");
static_assert(offsetof(FPlatformRuntimeAudioCompressionOverrides, SoundCueQualityIndex) == 0xc, "Offset mismatch for FPlatformRuntimeAudioCompressionOverrides::SoundCueQualityIndex");

