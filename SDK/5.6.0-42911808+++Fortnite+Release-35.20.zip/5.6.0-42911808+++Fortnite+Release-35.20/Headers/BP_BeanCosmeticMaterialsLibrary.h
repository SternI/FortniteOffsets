/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_BeanCosmeticMaterialsLibrary
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"
#include "BeanstalkCosmeticsRuntime.h"
#include "Cosmetics.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBP_BeanCosmeticMaterialsLibrary_C : public UBlueprintFunctionLibrary
{
public:

public:
    static void Update_Character_Material(UBeanCosmeticItemDefinitionBase*& BeanCD, UMaterialInstanceDynamic*& BodyMaterial, UMaterialInstanceDynamic*& CostumeBodyMaterial, UMaterialInstanceDynamic*& CostumeHeadMaterial, UDataTable*& DT_Colors, UDataTable*& DT_Materials, UDataTable*& DT_PatternAtlasTextureSlots, UDataTable*& DT_Roughness, UObject*& __WorldContext); // 0x288a61c (Index: 0x0, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void SetMaterialUvPatternPositionFromTextureSlot(UMaterialInstanceDynamic*& Material, FName& ParameterName, int32_t& TextureSlot, UDataTable*& DT_PatternAtlasTextureSlots, UObject*& __WorldContext); // 0x288a61c (Index: 0x1, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void SetColorMaterialParameterFromIndex(UMaterialInstanceDynamic*& Material, FName& ParameterName, UDataTable*& DT_Colors, int32_t& ColorIndexFromDT, UObject*& __WorldContext); // 0x288a61c (Index: 0x2, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void MergeMaterialPropsIntoMaterial(UMaterialInstanceDynamic*& Material, FName& ParameterName, UDataTable*& DT_Materials, int32_t& MaterialIndexFromDT, UObject*& __WorldContext); // 0x288a61c (Index: 0x3, Flags: Static|Public|BlueprintCallable|BlueprintEvent)
    static void GetMaterialValuesFromDT(UDataTable*& DT_Materials, int32_t& RowNameToFind, UObject*& __WorldContext, FBeanstalkCosmetics_MaterialTypeInfo& MaterialType); // 0x288a61c (Index: 0x4, Flags: Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    static void GetColorFromIndex(UDataTable*& DT_Colors, int32_t& Index, UObject*& __WorldContext, FLinearColor& Color, bool& ColorFoundInDT); // 0x288a61c (Index: 0x5, Flags: Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure)
};

static_assert(sizeof(UBP_BeanCosmeticMaterialsLibrary_C) == 0x28, "Size mismatch for UBP_BeanCosmeticMaterialsLibrary_C");

