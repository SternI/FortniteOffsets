/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Accessories
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UVariantScript_Backpack_BistroAstronaut_Style_C : public UFortLoadoutTagDrivenVariantScript
{
public:

public:
    virtual FGameplayTag DetermineVariantSelection(const FFortAthenaLoadout Loadout) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UVariantScript_Backpack_BistroAstronaut_Style_C) == 0x28, "Size mismatch for UVariantScript_Backpack_BistroAstronaut_Style_C");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UVariantScript_Backpack_BistroAstronaut_Color_C : public UFortLoadoutTagDrivenVariantScript
{
public:

public:
    virtual FGameplayTag DetermineVariantSelection(const FFortAthenaLoadout Loadout) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UVariantScript_Backpack_BistroAstronaut_Color_C) == 0x28, "Size mismatch for UVariantScript_Backpack_BistroAstronaut_Color_C");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UVariantScript_Backpack_AnglePatch_Style_C : public UFortLoadoutTagDrivenVariantScript
{
public:

public:
    virtual FGameplayTag DetermineVariantSelection(const FFortAthenaLoadout Loadout) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const)
};

static_assert(sizeof(UVariantScript_Backpack_AnglePatch_Style_C) == 0x28, "Size mismatch for UVariantScript_Backpack_AnglePatch_Style_C");

