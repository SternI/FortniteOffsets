/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Chooser
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "BlendStack.h"
#include "GameplayTags.h"

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UChooserParameterBool_ContextProperty : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TArray<FName> PropertyBindingChain; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UChooserParameterBool_ContextProperty) == 0x40, "Size mismatch for UChooserParameterBool_ContextProperty");
static_assert(offsetof(UChooserParameterBool_ContextProperty, PropertyBindingChain) == 0x30, "Offset mismatch for UChooserParameterBool_ContextProperty::PropertyBindingChain");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UChooserColumnBool : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TScriptInterface<Class> InputValue; // 0x30 (Size: 0x10, Type: InterfaceProperty)
    TArray<bool> RowValues; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UChooserColumnBool) == 0x50, "Size mismatch for UChooserColumnBool");
static_assert(offsetof(UChooserColumnBool, InputValue) == 0x30, "Offset mismatch for UChooserColumnBool::InputValue");
static_assert(offsetof(UChooserColumnBool, RowValues) == 0x40, "Offset mismatch for UChooserColumnBool::RowValues");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UChooserParameterEnum_ContextProperty : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TArray<FName> PropertyBindingChain; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UChooserParameterEnum_ContextProperty) == 0x40, "Size mismatch for UChooserParameterEnum_ContextProperty");
static_assert(offsetof(UChooserParameterEnum_ContextProperty, PropertyBindingChain) == 0x30, "Offset mismatch for UChooserParameterEnum_ContextProperty::PropertyBindingChain");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UChooserColumnEnum : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TScriptInterface<Class> InputValue; // 0x30 (Size: 0x10, Type: InterfaceProperty)
    TArray<FChooserEnumRowData> RowValues; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UChooserColumnEnum) == 0x50, "Size mismatch for UChooserColumnEnum");
static_assert(offsetof(UChooserColumnEnum, InputValue) == 0x30, "Offset mismatch for UChooserColumnEnum::InputValue");
static_assert(offsetof(UChooserColumnEnum, RowValues) == 0x40, "Offset mismatch for UChooserColumnEnum::RowValues");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UFloatAutoPopulator : public UObject
{
public:
};

static_assert(sizeof(UFloatAutoPopulator) == 0x28, "Size mismatch for UFloatAutoPopulator");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UChooserParameterFloat_ContextProperty : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TArray<FName> PropertyBindingChain; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UChooserParameterFloat_ContextProperty) == 0x40, "Size mismatch for UChooserParameterFloat_ContextProperty");
static_assert(offsetof(UChooserParameterFloat_ContextProperty, PropertyBindingChain) == 0x30, "Offset mismatch for UChooserParameterFloat_ContextProperty::PropertyBindingChain");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UChooserColumnFloatRange : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TScriptInterface<Class> InputValue; // 0x30 (Size: 0x10, Type: InterfaceProperty)
    TArray<FChooserFloatRangeRowData> RowValues; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UChooserColumnFloatRange) == 0x50, "Size mismatch for UChooserColumnFloatRange");
static_assert(offsetof(UChooserColumnFloatRange, InputValue) == 0x30, "Offset mismatch for UChooserColumnFloatRange::InputValue");
static_assert(offsetof(UChooserColumnFloatRange, RowValues) == 0x40, "Offset mismatch for UChooserColumnFloatRange::RowValues");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UChooserParameterGameplayTag_ContextProperty : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TArray<FName> PropertyBindingChain; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UChooserParameterGameplayTag_ContextProperty) == 0x40, "Size mismatch for UChooserParameterGameplayTag_ContextProperty");
static_assert(offsetof(UChooserParameterGameplayTag_ContextProperty, PropertyBindingChain) == 0x30, "Offset mismatch for UChooserParameterGameplayTag_ContextProperty::PropertyBindingChain");

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
class UChooserColumnGameplayTag : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TScriptInterface<Class> InputValue; // 0x30 (Size: 0x10, Type: InterfaceProperty)
    uint8_t TagMatchType; // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
    TArray<FGameplayTagContainer> RowValues; // 0x48 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UChooserColumnGameplayTag) == 0x58, "Size mismatch for UChooserColumnGameplayTag");
static_assert(offsetof(UChooserColumnGameplayTag, InputValue) == 0x30, "Offset mismatch for UChooserColumnGameplayTag::InputValue");
static_assert(offsetof(UChooserColumnGameplayTag, TagMatchType) == 0x40, "Offset mismatch for UChooserColumnGameplayTag::TagMatchType");
static_assert(offsetof(UChooserColumnGameplayTag, RowValues) == 0x48, "Offset mismatch for UChooserColumnGameplayTag::RowValues");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChooserColumn : public UInterface
{
public:
};

static_assert(sizeof(UChooserColumn) == 0x28, "Size mismatch for UChooserColumn");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChooserParameterBool : public UInterface
{
public:
};

static_assert(sizeof(UChooserParameterBool) == 0x28, "Size mismatch for UChooserParameterBool");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChooserParameterEnum : public UInterface
{
public:
};

static_assert(sizeof(UChooserParameterEnum) == 0x28, "Size mismatch for UChooserParameterEnum");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChooserParameterFloat : public UInterface
{
public:
};

static_assert(sizeof(UChooserParameterFloat) == 0x28, "Size mismatch for UChooserParameterFloat");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChooserParameterGameplayTag : public UInterface
{
public:
};

static_assert(sizeof(UChooserParameterGameplayTag) == 0x28, "Size mismatch for UChooserParameterGameplayTag");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UHasContextClass : public UInterface
{
public:
};

static_assert(sizeof(UHasContextClass) == 0x28, "Size mismatch for UHasContextClass");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UObjectChooser : public UInterface
{
public:
};

static_assert(sizeof(UObjectChooser) == 0x28, "Size mismatch for UObjectChooser");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UObjectChooser_Asset : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    UObject* Asset; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UObjectChooser_Asset) == 0x38, "Size mismatch for UObjectChooser_Asset");
static_assert(offsetof(UObjectChooser_Asset, Asset) == 0x30, "Offset mismatch for UObjectChooser_Asset::Asset");

// Size: 0xa0 (Inherited: 0x28, Single: 0x78)
class UChooserTable : public UObject
{
public:
    uint8_t Pad_28[0x20]; // 0x28 (Size: 0x20, Type: PaddingProperty)
    UChooserTable* RootChooser; // 0x48 (Size: 0x8, Type: ObjectProperty)
    FInstancedStruct FallbackResult; // 0x50 (Size: 0x10, Type: StructProperty)
    TArray<FInstancedStruct> CookedResults; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> ColumnsStructs; // 0x70 (Size: 0x10, Type: ArrayProperty)
    uint8_t ResultType[0x4]; // 0x80 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
    UClass* OutputObjectType; // 0x88 (Size: 0x8, Type: ClassProperty)
    TArray<FInstancedStruct> ContextData; // 0x90 (Size: 0x10, Type: ArrayProperty)

public:
    bool ResultAssetFilter(const FAssetData AssetData); // 0xc066f48 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|HasDefaults)
};

static_assert(sizeof(UChooserTable) == 0xa0, "Size mismatch for UChooserTable");
static_assert(offsetof(UChooserTable, RootChooser) == 0x48, "Offset mismatch for UChooserTable::RootChooser");
static_assert(offsetof(UChooserTable, FallbackResult) == 0x50, "Offset mismatch for UChooserTable::FallbackResult");
static_assert(offsetof(UChooserTable, CookedResults) == 0x60, "Offset mismatch for UChooserTable::CookedResults");
static_assert(offsetof(UChooserTable, ColumnsStructs) == 0x70, "Offset mismatch for UChooserTable::ColumnsStructs");
static_assert(offsetof(UChooserTable, ResultType) == 0x80, "Offset mismatch for UChooserTable::ResultType");
static_assert(offsetof(UChooserTable, OutputObjectType) == 0x88, "Offset mismatch for UChooserTable::OutputObjectType");
static_assert(offsetof(UChooserTable, ContextData) == 0x90, "Offset mismatch for UChooserTable::ContextData");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UObjectChooser_EvaluateChooser : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    UChooserTable* Chooser; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UObjectChooser_EvaluateChooser) == 0x38, "Size mismatch for UObjectChooser_EvaluateChooser");
static_assert(offsetof(UObjectChooser_EvaluateChooser, Chooser) == 0x30, "Offset mismatch for UObjectChooser_EvaluateChooser::Chooser");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UChooserColumnMenuContext : public UObject
{
public:
};

static_assert(sizeof(UChooserColumnMenuContext) == 0x40, "Size mismatch for UChooserColumnMenuContext");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UChooserFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void AddChooserObjectInput(FChooserEvaluationContext Context, UObject*& Object); // 0xc063f10 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void AddChooserStructInput(FChooserEvaluationContext Context, int32_t& Value); // 0xc064228 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UObject* EvaluateChooser(UObject*& const ContextObject, UChooserTable*& const ChooserTable, UClass*& ObjectClass); // 0xc0645f0 (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TArray<UObject*> EvaluateChooserMulti(UObject*& const ContextObject, UChooserTable*& const ChooserTable, UClass*& ObjectClass); // 0xc064a68 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static UObject* EvaluateObjectChooserBase(FChooserEvaluationContext Context, const FInstancedStruct ObjectChooser, UClass*& ObjectClass, bool& bResultIsClass); // 0xc064f08 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static TArray<UObject*> EvaluateObjectChooserBaseMulti(FChooserEvaluationContext Context, const FInstancedStruct ObjectChooser, UClass*& ObjectClass, bool& bResultIsClass); // 0xc0654dc (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static TArray<TSoftObjectPtr<UObject*>> EvaluateObjectChooserBaseMultiSoft(FChooserEvaluationContext Context, const FInstancedStruct ObjectChooser, UClass*& ObjectClass, bool& bResultIsClass); // 0xc065b38 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static TSoftObjectPtr<UObject*> EvaluateObjectChooserBaseSoft(FChooserEvaluationContext Context, const FInstancedStruct ObjectChooser, UClass*& ObjectClass, bool& bResultIsClass); // 0xc066124 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetChooserStructOutput(FChooserEvaluationContext Context, int32_t& Index, int32_t& Value); // 0xc0667ac (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FChooserEvaluationContext MakeChooserEvaluationContext(); // 0xc066bc4 (Index: 0x9, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FInstancedStruct MakeEvaluateChooser(UChooserTable*& Chooser); // 0xc066c40 (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UChooserFunctionLibrary) == 0x28, "Size mismatch for UChooserFunctionLibrary");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FChooserParameterBase
{
};

static_assert(sizeof(FChooserParameterBase) == 0x8, "Size mismatch for FChooserParameterBase");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FChooserParameterBoolBase : FChooserParameterBase
{
};

static_assert(sizeof(FChooserParameterBoolBase) == 0x8, "Size mismatch for FChooserParameterBoolBase");

// Size: 0x48 (Inherited: 0x10, Single: 0x38)
struct FBoolContextProperty : FChooserParameterBoolBase
{
    TArray<FName> PropertyBindingChain; // 0x8 (Size: 0x10, Type: ArrayProperty)
    FChooserPropertyBinding Binding; // 0x18 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FBoolContextProperty) == 0x48, "Size mismatch for FBoolContextProperty");
static_assert(offsetof(FBoolContextProperty, PropertyBindingChain) == 0x8, "Offset mismatch for FBoolContextProperty::PropertyBindingChain");
static_assert(offsetof(FBoolContextProperty, Binding) == 0x18, "Offset mismatch for FBoolContextProperty::Binding");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FChooserPropertyBinding
{
    TArray<FName> PropertyBindingChain; // 0x8 (Size: 0x10, Type: ArrayProperty)
    int32_t ContextIndex; // 0x18 (Size: 0x4, Type: IntProperty)
    bool IsBoundToRoot; // 0x1c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d[0x13]; // 0x1d (Size: 0x13, Type: PaddingProperty)
};

static_assert(sizeof(FChooserPropertyBinding) == 0x30, "Size mismatch for FChooserPropertyBinding");
static_assert(offsetof(FChooserPropertyBinding, PropertyBindingChain) == 0x8, "Offset mismatch for FChooserPropertyBinding::PropertyBindingChain");
static_assert(offsetof(FChooserPropertyBinding, ContextIndex) == 0x18, "Offset mismatch for FChooserPropertyBinding::ContextIndex");
static_assert(offsetof(FChooserPropertyBinding, IsBoundToRoot) == 0x1c, "Offset mismatch for FChooserPropertyBinding::IsBoundToRoot");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FChooserColumnBase
{
};

static_assert(sizeof(FChooserColumnBase) == 0x8, "Size mismatch for FChooserColumnBase");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FBoolColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<EBoolColumnCellValue> RowValuesWithAny; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FBoolColumn) == 0x28, "Size mismatch for FBoolColumn");
static_assert(offsetof(FBoolColumn, InputValue) == 0x8, "Offset mismatch for FBoolColumn::InputValue");
static_assert(offsetof(FBoolColumn, RowValuesWithAny) == 0x18, "Offset mismatch for FBoolColumn::RowValuesWithAny");

// Size: 0x30 (Inherited: 0x30, Single: 0x0)
struct FChooserEnumPropertyBinding : FChooserPropertyBinding
{
};

static_assert(sizeof(FChooserEnumPropertyBinding) == 0x30, "Size mismatch for FChooserEnumPropertyBinding");

// Size: 0x30 (Inherited: 0x30, Single: 0x0)
struct FChooserObjectPropertyBinding : FChooserPropertyBinding
{
};

static_assert(sizeof(FChooserObjectPropertyBinding) == 0x30, "Size mismatch for FChooserObjectPropertyBinding");

// Size: 0x30 (Inherited: 0x30, Single: 0x0)
struct FChooserStructPropertyBinding : FChooserPropertyBinding
{
};

static_assert(sizeof(FChooserStructPropertyBinding) == 0x30, "Size mismatch for FChooserStructPropertyBinding");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FContextObjectTypeBase
{
    uint8_t Direction[0x4]; // 0x0 (Size: 0x4, Type: EnumProperty)
};

static_assert(sizeof(FContextObjectTypeBase) == 0x4, "Size mismatch for FContextObjectTypeBase");
static_assert(offsetof(FContextObjectTypeBase, Direction) == 0x0, "Offset mismatch for FContextObjectTypeBase::Direction");

// Size: 0x10 (Inherited: 0x4, Single: 0xc)
struct FContextObjectTypeClass : FContextObjectTypeBase
{
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UClass* Class; // 0x8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FContextObjectTypeClass) == 0x10, "Size mismatch for FContextObjectTypeClass");
static_assert(offsetof(FContextObjectTypeClass, Class) == 0x8, "Offset mismatch for FContextObjectTypeClass::Class");

// Size: 0x10 (Inherited: 0x4, Single: 0xc)
struct FContextObjectTypeStruct : FContextObjectTypeBase
{
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UScriptStruct* Struct; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FContextObjectTypeStruct) == 0x10, "Size mismatch for FContextObjectTypeStruct");
static_assert(offsetof(FContextObjectTypeStruct, Struct) == 0x8, "Offset mismatch for FContextObjectTypeStruct::Struct");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FChooserParameterEnumBase : FChooserParameterBase
{
};

static_assert(sizeof(FChooserParameterEnumBase) == 0x8, "Size mismatch for FChooserParameterEnumBase");

// Size: 0x48 (Inherited: 0x10, Single: 0x38)
struct FEnumContextProperty : FChooserParameterEnumBase
{
    TArray<FName> PropertyBindingChain; // 0x8 (Size: 0x10, Type: ArrayProperty)
    FChooserEnumPropertyBinding Binding; // 0x18 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FEnumContextProperty) == 0x48, "Size mismatch for FEnumContextProperty");
static_assert(offsetof(FEnumContextProperty, PropertyBindingChain) == 0x8, "Offset mismatch for FEnumContextProperty::PropertyBindingChain");
static_assert(offsetof(FEnumContextProperty, Binding) == 0x18, "Offset mismatch for FEnumContextProperty::Binding");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FChooserEnumRowData
{
    uint8_t Comparison[0x4]; // 0x0 (Size: 0x4, Type: EnumProperty)
    char Value; // 0x4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FChooserEnumRowData) == 0x8, "Size mismatch for FChooserEnumRowData");
static_assert(offsetof(FChooserEnumRowData, Comparison) == 0x0, "Offset mismatch for FChooserEnumRowData::Comparison");
static_assert(offsetof(FChooserEnumRowData, Value) == 0x4, "Offset mismatch for FChooserEnumRowData::Value");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FEnumColumnBase : FChooserColumnBase
{
};

static_assert(sizeof(FEnumColumnBase) == 0x8, "Size mismatch for FEnumColumnBase");

// Size: 0x28 (Inherited: 0x10, Single: 0x18)
struct FEnumColumn : FEnumColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FChooserEnumRowData> RowValues; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FEnumColumn) == 0x28, "Size mismatch for FEnumColumn");
static_assert(offsetof(FEnumColumn, InputValue) == 0x8, "Offset mismatch for FEnumColumn::InputValue");
static_assert(offsetof(FEnumColumn, RowValues) == 0x18, "Offset mismatch for FEnumColumn::RowValues");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FChooserFloatDistanceRowData
{
    float Value; // 0x0 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FChooserFloatDistanceRowData) == 0x4, "Size mismatch for FChooserFloatDistanceRowData");
static_assert(offsetof(FChooserFloatDistanceRowData, Value) == 0x0, "Offset mismatch for FChooserFloatDistanceRowData::Value");

// Size: 0x48 (Inherited: 0x8, Single: 0x40)
struct FFloatDistanceColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    double MaxDistance; // 0x18 (Size: 0x8, Type: DoubleProperty)
    float CostMultiplier; // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bFilterOverMaxDistance; // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bWrapInput; // 0x25 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_26[0x2]; // 0x26 (Size: 0x2, Type: PaddingProperty)
    double MinValue; // 0x28 (Size: 0x8, Type: DoubleProperty)
    double MaxValue; // 0x30 (Size: 0x8, Type: DoubleProperty)
    TArray<FChooserFloatDistanceRowData> RowValues; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFloatDistanceColumn) == 0x48, "Size mismatch for FFloatDistanceColumn");
static_assert(offsetof(FFloatDistanceColumn, InputValue) == 0x8, "Offset mismatch for FFloatDistanceColumn::InputValue");
static_assert(offsetof(FFloatDistanceColumn, MaxDistance) == 0x18, "Offset mismatch for FFloatDistanceColumn::MaxDistance");
static_assert(offsetof(FFloatDistanceColumn, CostMultiplier) == 0x20, "Offset mismatch for FFloatDistanceColumn::CostMultiplier");
static_assert(offsetof(FFloatDistanceColumn, bFilterOverMaxDistance) == 0x24, "Offset mismatch for FFloatDistanceColumn::bFilterOverMaxDistance");
static_assert(offsetof(FFloatDistanceColumn, bWrapInput) == 0x25, "Offset mismatch for FFloatDistanceColumn::bWrapInput");
static_assert(offsetof(FFloatDistanceColumn, MinValue) == 0x28, "Offset mismatch for FFloatDistanceColumn::MinValue");
static_assert(offsetof(FFloatDistanceColumn, MaxValue) == 0x30, "Offset mismatch for FFloatDistanceColumn::MaxValue");
static_assert(offsetof(FFloatDistanceColumn, RowValues) == 0x38, "Offset mismatch for FFloatDistanceColumn::RowValues");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FChooserParameterFloatBase : FChooserParameterBase
{
};

static_assert(sizeof(FChooserParameterFloatBase) == 0x8, "Size mismatch for FChooserParameterFloatBase");

// Size: 0x48 (Inherited: 0x10, Single: 0x38)
struct FFloatContextProperty : FChooserParameterFloatBase
{
    TArray<FName> PropertyBindingChain; // 0x8 (Size: 0x10, Type: ArrayProperty)
    FChooserPropertyBinding Binding; // 0x18 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FFloatContextProperty) == 0x48, "Size mismatch for FFloatContextProperty");
static_assert(offsetof(FFloatContextProperty, PropertyBindingChain) == 0x8, "Offset mismatch for FFloatContextProperty::PropertyBindingChain");
static_assert(offsetof(FFloatContextProperty, Binding) == 0x18, "Offset mismatch for FFloatContextProperty::Binding");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FChooserFloatRangeRowData
{
    float Min; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Max; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bNoMin; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bNoMax; // 0x9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a[0x2]; // 0xa (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FChooserFloatRangeRowData) == 0xc, "Size mismatch for FChooserFloatRangeRowData");
static_assert(offsetof(FChooserFloatRangeRowData, Min) == 0x0, "Offset mismatch for FChooserFloatRangeRowData::Min");
static_assert(offsetof(FChooserFloatRangeRowData, Max) == 0x4, "Offset mismatch for FChooserFloatRangeRowData::Max");
static_assert(offsetof(FChooserFloatRangeRowData, bNoMin) == 0x8, "Offset mismatch for FChooserFloatRangeRowData::bNoMin");
static_assert(offsetof(FChooserFloatRangeRowData, bNoMax) == 0x9, "Offset mismatch for FChooserFloatRangeRowData::bNoMax");

// Size: 0x40 (Inherited: 0x8, Single: 0x38)
struct FFloatRangeColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    bool bWrapInput; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    double MinValue; // 0x20 (Size: 0x8, Type: DoubleProperty)
    double MaxValue; // 0x28 (Size: 0x8, Type: DoubleProperty)
    TArray<FChooserFloatRangeRowData> RowValues; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFloatRangeColumn) == 0x40, "Size mismatch for FFloatRangeColumn");
static_assert(offsetof(FFloatRangeColumn, InputValue) == 0x8, "Offset mismatch for FFloatRangeColumn::InputValue");
static_assert(offsetof(FFloatRangeColumn, bWrapInput) == 0x18, "Offset mismatch for FFloatRangeColumn::bWrapInput");
static_assert(offsetof(FFloatRangeColumn, MinValue) == 0x20, "Offset mismatch for FFloatRangeColumn::MinValue");
static_assert(offsetof(FFloatRangeColumn, MaxValue) == 0x28, "Offset mismatch for FFloatRangeColumn::MaxValue");
static_assert(offsetof(FFloatRangeColumn, RowValues) == 0x30, "Offset mismatch for FFloatRangeColumn::RowValues");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FChooserParameterGameplayTagBase : FChooserParameterBase
{
};

static_assert(sizeof(FChooserParameterGameplayTagBase) == 0x8, "Size mismatch for FChooserParameterGameplayTagBase");

// Size: 0x48 (Inherited: 0x10, Single: 0x38)
struct FGameplayTagContextProperty : FChooserParameterGameplayTagBase
{
    TArray<FName> PropertyBindingChain; // 0x8 (Size: 0x10, Type: ArrayProperty)
    FChooserPropertyBinding Binding; // 0x18 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FGameplayTagContextProperty) == 0x48, "Size mismatch for FGameplayTagContextProperty");
static_assert(offsetof(FGameplayTagContextProperty, PropertyBindingChain) == 0x8, "Offset mismatch for FGameplayTagContextProperty::PropertyBindingChain");
static_assert(offsetof(FGameplayTagContextProperty, Binding) == 0x18, "Offset mismatch for FGameplayTagContextProperty::Binding");

// Size: 0x30 (Inherited: 0x8, Single: 0x28)
struct FGameplayTagColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    uint8_t TagMatchType; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t TagMatchDirection; // 0x19 (Size: 0x1, Type: EnumProperty)
    bool bMatchExact; // 0x1a (Size: 0x1, Type: BoolProperty)
    bool bInvertMatchingLogic; // 0x1b (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    TArray<FGameplayTagContainer> RowValues; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayTagColumn) == 0x30, "Size mismatch for FGameplayTagColumn");
static_assert(offsetof(FGameplayTagColumn, InputValue) == 0x8, "Offset mismatch for FGameplayTagColumn::InputValue");
static_assert(offsetof(FGameplayTagColumn, TagMatchType) == 0x18, "Offset mismatch for FGameplayTagColumn::TagMatchType");
static_assert(offsetof(FGameplayTagColumn, TagMatchDirection) == 0x19, "Offset mismatch for FGameplayTagColumn::TagMatchDirection");
static_assert(offsetof(FGameplayTagColumn, bMatchExact) == 0x1a, "Offset mismatch for FGameplayTagColumn::bMatchExact");
static_assert(offsetof(FGameplayTagColumn, bInvertMatchingLogic) == 0x1b, "Offset mismatch for FGameplayTagColumn::bInvertMatchingLogic");
static_assert(offsetof(FGameplayTagColumn, RowValues) == 0x20, "Offset mismatch for FGameplayTagColumn::RowValues");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FGameplayTagQueryColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FGameplayTagQuery> RowValues; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayTagQueryColumn) == 0x28, "Size mismatch for FGameplayTagQueryColumn");
static_assert(offsetof(FGameplayTagQueryColumn, InputValue) == 0x8, "Offset mismatch for FGameplayTagQueryColumn::InputValue");
static_assert(offsetof(FGameplayTagQueryColumn, RowValues) == 0x18, "Offset mismatch for FGameplayTagQueryColumn::RowValues");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FChooserParameterObjectBase : FChooserParameterBase
{
};

static_assert(sizeof(FChooserParameterObjectBase) == 0x8, "Size mismatch for FChooserParameterObjectBase");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FChooserRandomizationContext
{
};

static_assert(sizeof(FChooserRandomizationContext) == 0x50, "Size mismatch for FChooserRandomizationContext");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FChooserParameterRandomizeBase : FChooserParameterBase
{
};

static_assert(sizeof(FChooserParameterRandomizeBase) == 0x8, "Size mismatch for FChooserParameterRandomizeBase");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FChooserParameterStructBase : FChooserParameterBase
{
};

static_assert(sizeof(FChooserParameterStructBase) == 0x8, "Size mismatch for FChooserParameterStructBase");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FChooserEvaluationInputObject
{
};

static_assert(sizeof(FChooserEvaluationInputObject) == 0x8, "Size mismatch for FChooserEvaluationInputObject");

// Size: 0x78 (Inherited: 0x0, Single: 0x78)
struct FChooserEvaluationContext
{
};

static_assert(sizeof(FChooserEvaluationContext) == 0x78, "Size mismatch for FChooserEvaluationContext");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FObjectChooserBase
{
};

static_assert(sizeof(FObjectChooserBase) == 0x8, "Size mismatch for FObjectChooserBase");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FChooserMultiEnumRowData
{
    uint32_t Value; // 0x0 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FChooserMultiEnumRowData) == 0x4, "Size mismatch for FChooserMultiEnumRowData");
static_assert(offsetof(FChooserMultiEnumRowData, Value) == 0x0, "Offset mismatch for FChooserMultiEnumRowData::Value");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FMultiEnumColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FChooserMultiEnumRowData> RowValues; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FMultiEnumColumn) == 0x28, "Size mismatch for FMultiEnumColumn");
static_assert(offsetof(FMultiEnumColumn, InputValue) == 0x8, "Offset mismatch for FMultiEnumColumn::InputValue");
static_assert(offsetof(FMultiEnumColumn, RowValues) == 0x18, "Offset mismatch for FMultiEnumColumn::RowValues");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FAssetChooser : FObjectChooserBase
{
    UObject* Asset; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAssetChooser) == 0x10, "Size mismatch for FAssetChooser");
static_assert(offsetof(FAssetChooser, Asset) == 0x8, "Offset mismatch for FAssetChooser::Asset");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FSoftAssetChooser : FObjectChooserBase
{
    TSoftObjectPtr<UObject*> Asset; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FSoftAssetChooser) == 0x28, "Size mismatch for FSoftAssetChooser");
static_assert(offsetof(FSoftAssetChooser, Asset) == 0x8, "Offset mismatch for FSoftAssetChooser::Asset");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FClassChooser : FObjectChooserBase
{
    UClass* Class; // 0x8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FClassChooser) == 0x10, "Size mismatch for FClassChooser");
static_assert(offsetof(FClassChooser, Class) == 0x8, "Offset mismatch for FClassChooser::Class");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FChooserObjectClassRowData
{
    uint8_t Comparison[0x4]; // 0x0 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UClass* Value; // 0x8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(FChooserObjectClassRowData) == 0x10, "Size mismatch for FChooserObjectClassRowData");
static_assert(offsetof(FChooserObjectClassRowData, Comparison) == 0x0, "Offset mismatch for FChooserObjectClassRowData::Comparison");
static_assert(offsetof(FChooserObjectClassRowData, Value) == 0x8, "Offset mismatch for FChooserObjectClassRowData::Value");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FObjectClassColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FChooserObjectClassRowData> RowValues; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FObjectClassColumn) == 0x28, "Size mismatch for FObjectClassColumn");
static_assert(offsetof(FObjectClassColumn, InputValue) == 0x8, "Offset mismatch for FObjectClassColumn::InputValue");
static_assert(offsetof(FObjectClassColumn, RowValues) == 0x18, "Offset mismatch for FObjectClassColumn::RowValues");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FObjectContextProperty : FChooserParameterObjectBase
{
    FChooserObjectPropertyBinding Binding; // 0x8 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FObjectContextProperty) == 0x38, "Size mismatch for FObjectContextProperty");
static_assert(offsetof(FObjectContextProperty, Binding) == 0x8, "Offset mismatch for FObjectContextProperty::Binding");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FChooserObjectRowData
{
    uint8_t Comparison[0x4]; // 0x0 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UObject*> Value; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FChooserObjectRowData) == 0x28, "Size mismatch for FChooserObjectRowData");
static_assert(offsetof(FChooserObjectRowData, Comparison) == 0x0, "Offset mismatch for FChooserObjectRowData::Comparison");
static_assert(offsetof(FChooserObjectRowData, Value) == 0x8, "Offset mismatch for FChooserObjectRowData::Value");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FObjectColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FChooserObjectRowData> RowValues; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FObjectColumn) == 0x28, "Size mismatch for FObjectColumn");
static_assert(offsetof(FObjectColumn, InputValue) == 0x8, "Offset mismatch for FObjectColumn::InputValue");
static_assert(offsetof(FObjectColumn, RowValues) == 0x18, "Offset mismatch for FObjectColumn::RowValues");

// Size: 0x30 (Inherited: 0x8, Single: 0x28)
struct FOutputBoolColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    bool bFallbackValue; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    TArray<bool> RowValues; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FOutputBoolColumn) == 0x30, "Size mismatch for FOutputBoolColumn");
static_assert(offsetof(FOutputBoolColumn, InputValue) == 0x8, "Offset mismatch for FOutputBoolColumn::InputValue");
static_assert(offsetof(FOutputBoolColumn, bFallbackValue) == 0x18, "Offset mismatch for FOutputBoolColumn::bFallbackValue");
static_assert(offsetof(FOutputBoolColumn, RowValues) == 0x20, "Offset mismatch for FOutputBoolColumn::RowValues");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FChooserOutputEnumRowData
{
    char Value; // 0x0 (Size: 0x1, Type: ByteProperty)
};

static_assert(sizeof(FChooserOutputEnumRowData) == 0x1, "Size mismatch for FChooserOutputEnumRowData");
static_assert(offsetof(FChooserOutputEnumRowData, Value) == 0x0, "Offset mismatch for FChooserOutputEnumRowData::Value");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FOutputEnumColumn : FEnumColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    FChooserOutputEnumRowData FallbackValue; // 0x18 (Size: 0x1, Type: StructProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    TArray<FChooserOutputEnumRowData> RowValues; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FOutputEnumColumn) == 0x30, "Size mismatch for FOutputEnumColumn");
static_assert(offsetof(FOutputEnumColumn, InputValue) == 0x8, "Offset mismatch for FOutputEnumColumn::InputValue");
static_assert(offsetof(FOutputEnumColumn, FallbackValue) == 0x18, "Offset mismatch for FOutputEnumColumn::FallbackValue");
static_assert(offsetof(FOutputEnumColumn, RowValues) == 0x20, "Offset mismatch for FOutputEnumColumn::RowValues");

// Size: 0x30 (Inherited: 0x8, Single: 0x28)
struct FOutputFloatColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    double FallbackValue; // 0x18 (Size: 0x8, Type: DoubleProperty)
    TArray<double> RowValues; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FOutputFloatColumn) == 0x30, "Size mismatch for FOutputFloatColumn");
static_assert(offsetof(FOutputFloatColumn, InputValue) == 0x8, "Offset mismatch for FOutputFloatColumn::InputValue");
static_assert(offsetof(FOutputFloatColumn, FallbackValue) == 0x18, "Offset mismatch for FOutputFloatColumn::FallbackValue");
static_assert(offsetof(FOutputFloatColumn, RowValues) == 0x20, "Offset mismatch for FOutputFloatColumn::RowValues");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FChooserOutputObjectRowData
{
    FInstancedStruct Value; // 0x0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FChooserOutputObjectRowData) == 0x10, "Size mismatch for FChooserOutputObjectRowData");
static_assert(offsetof(FChooserOutputObjectRowData, Value) == 0x0, "Offset mismatch for FChooserOutputObjectRowData::Value");

// Size: 0x38 (Inherited: 0x8, Single: 0x30)
struct FOutputObjectColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FChooserOutputObjectRowData> RowValues; // 0x18 (Size: 0x10, Type: ArrayProperty)
    FChooserOutputObjectRowData FallbackValue; // 0x28 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FOutputObjectColumn) == 0x38, "Size mismatch for FOutputObjectColumn");
static_assert(offsetof(FOutputObjectColumn, InputValue) == 0x8, "Offset mismatch for FOutputObjectColumn::InputValue");
static_assert(offsetof(FOutputObjectColumn, RowValues) == 0x18, "Offset mismatch for FOutputObjectColumn::RowValues");
static_assert(offsetof(FOutputObjectColumn, FallbackValue) == 0x28, "Offset mismatch for FOutputObjectColumn::FallbackValue");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FStructContextProperty : FChooserParameterStructBase
{
    FChooserStructPropertyBinding Binding; // 0x8 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FStructContextProperty) == 0x38, "Size mismatch for FStructContextProperty");
static_assert(offsetof(FStructContextProperty, Binding) == 0x8, "Offset mismatch for FStructContextProperty::Binding");

// Size: 0x38 (Inherited: 0x8, Single: 0x30)
struct FOutputStructColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    FInstancedStruct FallbackValue; // 0x18 (Size: 0x10, Type: StructProperty)
    TArray<FInstancedStruct> RowValues; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FOutputStructColumn) == 0x38, "Size mismatch for FOutputStructColumn");
static_assert(offsetof(FOutputStructColumn, InputValue) == 0x8, "Offset mismatch for FOutputStructColumn::InputValue");
static_assert(offsetof(FOutputStructColumn, FallbackValue) == 0x18, "Offset mismatch for FOutputStructColumn::FallbackValue");
static_assert(offsetof(FOutputStructColumn, RowValues) == 0x28, "Offset mismatch for FOutputStructColumn::RowValues");

// Size: 0x38 (Inherited: 0x10, Single: 0x28)
struct FRandomizeContextProperty : FChooserParameterRandomizeBase
{
    FChooserPropertyBinding Binding; // 0x8 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FRandomizeContextProperty) == 0x38, "Size mismatch for FRandomizeContextProperty");
static_assert(offsetof(FRandomizeContextProperty, Binding) == 0x8, "Offset mismatch for FRandomizeContextProperty::Binding");

// Size: 0x30 (Inherited: 0x8, Single: 0x28)
struct FRandomizeColumn : FChooserColumnBase
{
    FInstancedStruct InputValue; // 0x8 (Size: 0x10, Type: StructProperty)
    float RepeatProbabilityMultiplier; // 0x18 (Size: 0x4, Type: FloatProperty)
    float EqualCostThreshold; // 0x1c (Size: 0x4, Type: FloatProperty)
    TArray<float> RowValues; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRandomizeColumn) == 0x30, "Size mismatch for FRandomizeColumn");
static_assert(offsetof(FRandomizeColumn, InputValue) == 0x8, "Offset mismatch for FRandomizeColumn::InputValue");
static_assert(offsetof(FRandomizeColumn, RepeatProbabilityMultiplier) == 0x18, "Offset mismatch for FRandomizeColumn::RepeatProbabilityMultiplier");
static_assert(offsetof(FRandomizeColumn, EqualCostThreshold) == 0x1c, "Offset mismatch for FRandomizeColumn::EqualCostThreshold");
static_assert(offsetof(FRandomizeColumn, RowValues) == 0x20, "Offset mismatch for FRandomizeColumn::RowValues");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FAnimCurveOverride
{
    FName CurveName; // 0x0 (Size: 0x4, Type: NameProperty)
    float CurveValue; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FAnimCurveOverride) == 0x8, "Size mismatch for FAnimCurveOverride");
static_assert(offsetof(FAnimCurveOverride, CurveName) == 0x0, "Offset mismatch for FAnimCurveOverride::CurveName");
static_assert(offsetof(FAnimCurveOverride, CurveValue) == 0x4, "Offset mismatch for FAnimCurveOverride::CurveValue");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAnimCurveOverrideList
{
    TArray<FAnimCurveOverride> Values; // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint32_t Hash; // 0x10 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FAnimCurveOverrideList) == 0x18, "Size mismatch for FAnimCurveOverrideList");
static_assert(offsetof(FAnimCurveOverrideList, Values) == 0x0, "Offset mismatch for FAnimCurveOverrideList::Values");
static_assert(offsetof(FAnimCurveOverrideList, Hash) == 0x10, "Offset mismatch for FAnimCurveOverrideList::Hash");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FChooserPlayerSettings
{
    bool bMirror; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float StartTime; // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bForceLooping; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    float PlaybackRate; // 0xc (Size: 0x4, Type: FloatProperty)
    FAnimCurveOverrideList CurveOverrides; // 0x10 (Size: 0x18, Type: StructProperty)
    float BlendTime; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    UBlendProfile* BlendProfile; // 0x30 (Size: 0x8, Type: ObjectProperty)
    uint8_t BlendOption; // 0x38 (Size: 0x1, Type: EnumProperty)
    bool bUseInertialBlend; // 0x39 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3a[0x6]; // 0x3a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FChooserPlayerSettings) == 0x40, "Size mismatch for FChooserPlayerSettings");
static_assert(offsetof(FChooserPlayerSettings, bMirror) == 0x0, "Offset mismatch for FChooserPlayerSettings::bMirror");
static_assert(offsetof(FChooserPlayerSettings, StartTime) == 0x4, "Offset mismatch for FChooserPlayerSettings::StartTime");
static_assert(offsetof(FChooserPlayerSettings, bForceLooping) == 0x8, "Offset mismatch for FChooserPlayerSettings::bForceLooping");
static_assert(offsetof(FChooserPlayerSettings, PlaybackRate) == 0xc, "Offset mismatch for FChooserPlayerSettings::PlaybackRate");
static_assert(offsetof(FChooserPlayerSettings, CurveOverrides) == 0x10, "Offset mismatch for FChooserPlayerSettings::CurveOverrides");
static_assert(offsetof(FChooserPlayerSettings, BlendTime) == 0x28, "Offset mismatch for FChooserPlayerSettings::BlendTime");
static_assert(offsetof(FChooserPlayerSettings, BlendProfile) == 0x30, "Offset mismatch for FChooserPlayerSettings::BlendProfile");
static_assert(offsetof(FChooserPlayerSettings, BlendOption) == 0x38, "Offset mismatch for FChooserPlayerSettings::BlendOption");
static_assert(offsetof(FChooserPlayerSettings, bUseInertialBlend) == 0x39, "Offset mismatch for FChooserPlayerSettings::bUseInertialBlend");

// Size: 0x248 (Inherited: 0x118, Single: 0x130)
struct FAnimNode_ChooserPlayer : FAnimNode_BlendStack_Standalone
{
    uint8_t Pad_c0[0x20]; // 0xc0 (Size: 0x20, Type: PaddingProperty)
    uint8_t EvaluationFrequency[0x4]; // 0xe0 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_e4[0x4]; // 0xe4 (Size: 0x4, Type: PaddingProperty)
    FInstancedStruct Chooser; // 0xe8 (Size: 0x10, Type: StructProperty)
    UMirrorDataTable* MirrorDataTable; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    float BlendSpaceX; // 0x100 (Size: 0x4, Type: FloatProperty)
    float BlendSpaceY; // 0x104 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
    FChooserPlayerSettings DefaultSettings; // 0x110 (Size: 0x40, Type: StructProperty)
    TArray<FInstancedStruct> ChooserContextDefinition; // 0x150 (Size: 0x10, Type: ArrayProperty)
    bool bStartFromMatchingPose; // 0x160 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_161[0xe7]; // 0x161 (Size: 0xe7, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_ChooserPlayer) == 0x248, "Size mismatch for FAnimNode_ChooserPlayer");
static_assert(offsetof(FAnimNode_ChooserPlayer, EvaluationFrequency) == 0xe0, "Offset mismatch for FAnimNode_ChooserPlayer::EvaluationFrequency");
static_assert(offsetof(FAnimNode_ChooserPlayer, Chooser) == 0xe8, "Offset mismatch for FAnimNode_ChooserPlayer::Chooser");
static_assert(offsetof(FAnimNode_ChooserPlayer, MirrorDataTable) == 0xf8, "Offset mismatch for FAnimNode_ChooserPlayer::MirrorDataTable");
static_assert(offsetof(FAnimNode_ChooserPlayer, BlendSpaceX) == 0x100, "Offset mismatch for FAnimNode_ChooserPlayer::BlendSpaceX");
static_assert(offsetof(FAnimNode_ChooserPlayer, BlendSpaceY) == 0x104, "Offset mismatch for FAnimNode_ChooserPlayer::BlendSpaceY");
static_assert(offsetof(FAnimNode_ChooserPlayer, DefaultSettings) == 0x110, "Offset mismatch for FAnimNode_ChooserPlayer::DefaultSettings");
static_assert(offsetof(FAnimNode_ChooserPlayer, ChooserContextDefinition) == 0x150, "Offset mismatch for FAnimNode_ChooserPlayer::ChooserContextDefinition");
static_assert(offsetof(FAnimNode_ChooserPlayer, bStartFromMatchingPose) == 0x160, "Offset mismatch for FAnimNode_ChooserPlayer::bStartFromMatchingPose");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FNestedChooser : FObjectChooserBase
{
    UChooserTable* Chooser; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FNestedChooser) == 0x10, "Size mismatch for FNestedChooser");
static_assert(offsetof(FNestedChooser, Chooser) == 0x8, "Offset mismatch for FNestedChooser::Chooser");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FEvaluateChooser : FObjectChooserBase
{
    UChooserTable* Chooser; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEvaluateChooser) == 0x10, "Size mismatch for FEvaluateChooser");
static_assert(offsetof(FEvaluateChooser, Chooser) == 0x8, "Offset mismatch for FEvaluateChooser::Chooser");

