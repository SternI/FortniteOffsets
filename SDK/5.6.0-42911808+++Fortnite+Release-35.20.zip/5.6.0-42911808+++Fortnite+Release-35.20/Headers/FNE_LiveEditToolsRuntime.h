/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNE_LiveEditToolsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x158 (Inherited: 0x228, Single: 0xffffff30)
class UDeleteEntities : public UObjectInteractionBehavior
{
public:

protected:
    virtual void ServerDelete(TArray<UObject*>& const EntitiesToDelete); // 0xe4568f8 (Index: 0x0, Flags: Net|NetReliableNative|Event|Protected|NetServer)
};

static_assert(sizeof(UDeleteEntities) == 0x158, "Size mismatch for UDeleteEntities");

// Size: 0x150 (Inherited: 0x370, Single: 0xfffffde0)
class UMoveEntitiesFreely : public UMoveObjectsFreely
{
public:
    APhoneToolEntityInteractionMode* OwningEntityInteractionMode; // 0x148 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UMoveEntitiesFreely) == 0x150, "Size mismatch for UMoveEntitiesFreely");
static_assert(offsetof(UMoveEntitiesFreely, OwningEntityInteractionMode) == 0x148, "Offset mismatch for UMoveEntitiesFreely::OwningEntityInteractionMode");

// Size: 0x40 (Inherited: 0x68, Single: 0xffffffd8)
class UUEFNEntityInteractionTargetDetection : public UInteractionTargetDetection
{
public:

protected:
    virtual void ServerRunTraceOperations(EHitTraceType& const InTraceType, FVector& const TraceStart, FVector& const TraceEnd); // 0x1215e9e8 (Index: 0x0, Flags: Net|NetReliableNative|Event|Protected|NetServer|HasDefaults|NetValidate)
};

static_assert(sizeof(UUEFNEntityInteractionTargetDetection) == 0x40, "Size mismatch for UUEFNEntityInteractionTargetDetection");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UUEFNEntityInteractionTargetEvaluator : public UInteractionTargetEvaluator
{
public:
};

static_assert(sizeof(UUEFNEntityInteractionTargetEvaluator) == 0x30, "Size mismatch for UUEFNEntityInteractionTargetEvaluator");

// Size: 0x5a0 (Inherited: 0x528, Single: 0x78)
class ULevelRecordSpawnerEntities : public ULevelRecordSpawner
{
public:
    TArray<UObject*> SpawnedEntities; // 0x4f8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_508[0x98]; // 0x508 (Size: 0x98, Type: PaddingProperty)
};

static_assert(sizeof(ULevelRecordSpawnerEntities) == 0x5a0, "Size mismatch for ULevelRecordSpawnerEntities");
static_assert(offsetof(ULevelRecordSpawnerEntities, SpawnedEntities) == 0x4f8, "Offset mismatch for ULevelRecordSpawnerEntities::SpawnedEntities");

// Size: 0x7e8 (Inherited: 0x7a0, Single: 0x48)
class ULevelSaveRecordEntities : public ULevelSaveRecord
{
public:
    uint8_t Pad_778[0x8]; // 0x778 (Size: 0x8, Type: PaddingProperty)
    uint64_t LastEntityRecordID; // 0x780 (Size: 0x8, Type: UInt64Property)
    TMap<FEntityTemplateRecord, int32_t> EntityTemplateRecords; // 0x788 (Size: 0x50, Type: MapProperty)
    TArray<FEntityInstanceRecord> EntityInstanceRecords; // 0x7d8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(ULevelSaveRecordEntities) == 0x7e8, "Size mismatch for ULevelSaveRecordEntities");
static_assert(offsetof(ULevelSaveRecordEntities, LastEntityRecordID) == 0x780, "Offset mismatch for ULevelSaveRecordEntities::LastEntityRecordID");
static_assert(offsetof(ULevelSaveRecordEntities, EntityTemplateRecords) == 0x788, "Offset mismatch for ULevelSaveRecordEntities::EntityTemplateRecords");
static_assert(offsetof(ULevelSaveRecordEntities, EntityInstanceRecords) == 0x7d8, "Offset mismatch for ULevelSaveRecordEntities::EntityInstanceRecords");

// Size: 0x180 (Inherited: 0x198, Single: 0xffffffe8)
class ULSRThumbnailGeneratorEntities : public ULevelSaveRecordThumbnailGenerator
{
public:
    TArray<UObject*> SpawnedEntities; // 0x170 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(ULSRThumbnailGeneratorEntities) == 0x180, "Size mismatch for ULSRThumbnailGeneratorEntities");
static_assert(offsetof(ULSRThumbnailGeneratorEntities, SpawnedEntities) == 0x170, "Offset mismatch for ULSRThumbnailGeneratorEntities::SpawnedEntities");

// Size: 0x520 (Inherited: 0x690, Single: 0xfffffe90)
class APhoneToolEntityInteractionMode : public AObjectInteractionMode
{
public:
    uint8_t Pad_3c0[0x58]; // 0x3c0 (Size: 0x58, Type: PaddingProperty)
    UMoveEntitiesFreely* MoveEntitiesFreelyInteractionBehavior; // 0x418 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_420[0x20]; // 0x420 (Size: 0x20, Type: PaddingProperty)
    UObjectInteractionBehavior* ActiveBoundBehaviorReplicateToRemoteClients; // 0x440 (Size: 0x8, Type: ObjectProperty)
    TArray<FCreativeSelectedEntityInfo> PlacementModeEntitiesReplicateToRemoteClients; // 0x448 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_458[0xc8]; // 0x458 (Size: 0xc8, Type: PaddingProperty)

public:
    virtual void MulticastUpdateSelectionSetExceptServer(UObjectInteractionBehavior*& const BehaviorHandlingMove, FTransform& const NewTransformToWorld); // 0x1215dd34 (Index: 0x2, Flags: Net|NetReliableNative|Event|NetMulticast|Public|HasDefaults)
    virtual void MulticastUpdateSelectionSetExceptServerAndOwningClient(UObjectInteractionBehavior*& const BehaviorHandlingMove, FTransform& const NewTransformToWorld); // 0x1215df40 (Index: 0x3, Flags: Net|NetReliableNative|Event|NetMulticast|Public|HasDefaults)
    virtual void ServerMoveSelectionSet(UObjectInteractionBehavior*& const BehaviorHandlingMove, FTransform& const NewSelectionToWorld, bool& const bShouldUpdateOwningClient); // 0x1215e568 (Index: 0x7, Flags: Net|NetReliableNative|Event|Public|NetServer|HasDefaults)
    virtual void ServerPlaceEntitiesAndClearMovementMode(UObjectInteractionBehavior*& const BehaviorHandlingMove, FTransform& const TargetTransformForBuildings); // 0x1215e7dc (Index: 0x8, Flags: Net|NetReliableNative|Event|Public|NetServer|HasDefaults)
    virtual void ServerSetNewlyPlacedObjectsHiddenInGame(); // 0x5479144 (Index: 0x9, Flags: Net|NetReliableNative|Event|Public|NetServer)
    virtual void ServerSpawnSelectedEntitiesWithTransform(bool& const bAllowOverlap, bool& const bAllowGravity, bool& const bIgnoreStructuralIssues, bool& const bForPreviewing, bool& const bNotifyOwnerOnFailure); // 0x1215ec10 (Index: 0xa, Flags: Net|NetReliableNative|Event|Public|NetServer)

protected:
    virtual void ClientStartInteracting(ESelectionProperty& SelectionProperty, UObjectInteractionBehavior*& NewActiveBoundBehavior, FTransform& const NewSelectionToWorld, FBox& const NewSelectionSpaceBounds, FQuat& const InitialRotationOffset, TArray<UObject*>& const Targets); // 0x1215d780 (Index: 0x0, Flags: Net|NetReliableNative|Event|Protected|HasDefaults|NetClient)
    virtual void ClientStopInteracting(); // 0x328c6e8 (Index: 0x1, Flags: Net|NetReliableNative|Event|Protected|NetClient)
    void OnRep_ActiveBoundBehaviorReplicateToRemoteClients(); // 0x1215e14c (Index: 0x4, Flags: Final|Native|Protected)
    void OnRep_PlacementEntitiesReplicateToRemoteClients(); // 0x1215e190 (Index: 0x5, Flags: Final|Native|Protected)
    virtual void ServerDuplicateStartInteracting(TArray<UObject*>& const Targets, FTransform& const DragStart); // 0x1215e1a4 (Index: 0x6, Flags: Net|NetReliableNative|Event|Protected|NetServer|HasDefaults)
    virtual void ServerStartInteracting(TArray<UObject*>& const Targets, FTransform& const DragStart); // 0x1215f0cc (Index: 0xb, Flags: Net|NetReliableNative|Event|Protected|NetServer|HasDefaults)
};

static_assert(sizeof(APhoneToolEntityInteractionMode) == 0x520, "Size mismatch for APhoneToolEntityInteractionMode");
static_assert(offsetof(APhoneToolEntityInteractionMode, MoveEntitiesFreelyInteractionBehavior) == 0x418, "Offset mismatch for APhoneToolEntityInteractionMode::MoveEntitiesFreelyInteractionBehavior");
static_assert(offsetof(APhoneToolEntityInteractionMode, ActiveBoundBehaviorReplicateToRemoteClients) == 0x440, "Offset mismatch for APhoneToolEntityInteractionMode::ActiveBoundBehaviorReplicateToRemoteClients");
static_assert(offsetof(APhoneToolEntityInteractionMode, PlacementModeEntitiesReplicateToRemoteClients) == 0x448, "Offset mismatch for APhoneToolEntityInteractionMode::PlacementModeEntitiesReplicateToRemoteClients");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FEntityTemplateRecord
{
    uint64_t TemplateRecordID; // 0x0 (Size: 0x8, Type: UInt64Property)
    TSoftClassPtr EntityClass; // 0x8 (Size: 0x20, Type: SoftClassProperty)
    int16_t LevelRecordSaveVersion; // 0x28 (Size: 0x2, Type: Int16Property)
    uint8_t Pad_2a[0x6]; // 0x2a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FEntityTemplateRecord) == 0x30, "Size mismatch for FEntityTemplateRecord");
static_assert(offsetof(FEntityTemplateRecord, TemplateRecordID) == 0x0, "Offset mismatch for FEntityTemplateRecord::TemplateRecordID");
static_assert(offsetof(FEntityTemplateRecord, EntityClass) == 0x8, "Offset mismatch for FEntityTemplateRecord::EntityClass");
static_assert(offsetof(FEntityTemplateRecord, LevelRecordSaveVersion) == 0x28, "Offset mismatch for FEntityTemplateRecord::LevelRecordSaveVersion");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FEntityInstanceRecord
{
    uint64_t RecordID; // 0x0 (Size: 0x8, Type: UInt64Property)
    uint64_t TemplateRecordID; // 0x8 (Size: 0x8, Type: UInt64Property)
    FName EntityID; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x20 (Size: 0x60, Type: StructProperty)
    TWeakObjectPtr<UObject*> EntityPtr; // 0x80 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FEntityInstanceRecord) == 0x90, "Size mismatch for FEntityInstanceRecord");
static_assert(offsetof(FEntityInstanceRecord, RecordID) == 0x0, "Offset mismatch for FEntityInstanceRecord::RecordID");
static_assert(offsetof(FEntityInstanceRecord, TemplateRecordID) == 0x8, "Offset mismatch for FEntityInstanceRecord::TemplateRecordID");
static_assert(offsetof(FEntityInstanceRecord, EntityID) == 0x10, "Offset mismatch for FEntityInstanceRecord::EntityID");
static_assert(offsetof(FEntityInstanceRecord, Transform) == 0x20, "Offset mismatch for FEntityInstanceRecord::Transform");
static_assert(offsetof(FEntityInstanceRecord, EntityPtr) == 0x80, "Offset mismatch for FEntityInstanceRecord::EntityPtr");

// Size: 0xf0 (Inherited: 0xa0, Single: 0x50)
struct FCreativeSelectedEntityInfo : FCreativeSelectedObjectInfo
{
    uint8_t Pad_a0[0x8]; // 0xa0 (Size: 0x8, Type: PaddingProperty)
    TSoftObjectPtr<UObject*> EntitySoftPath; // 0xa8 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t Pad_c8[0x28]; // 0xc8 (Size: 0x28, Type: PaddingProperty)
};

static_assert(sizeof(FCreativeSelectedEntityInfo) == 0xf0, "Size mismatch for FCreativeSelectedEntityInfo");
static_assert(offsetof(FCreativeSelectedEntityInfo, EntitySoftPath) == 0xa8, "Offset mismatch for FCreativeSelectedEntityInfo::EntitySoftPath");

