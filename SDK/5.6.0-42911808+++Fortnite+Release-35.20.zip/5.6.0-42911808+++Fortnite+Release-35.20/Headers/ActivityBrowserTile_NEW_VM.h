/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserTile_NEW_VM
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DiscoveryBrowserUI.h"
#include "FortniteUI.h"
#include "Engine.h"

// Size: 0x1568 (Inherited: 0x4630, Single: 0xffffcf38)
class UActivityBrowserTile_NEW_VM_C : public UFortActivityBrowserTile
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x1560 (Size: 0x8, Type: StructProperty)

public:
    virtual void SetNestedButtonGroupSelectionVM(UFortNestedButtonGroupSelectionVM*& const InVM); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    virtual UFortNestedButtonGroupSelectionVM* GetNestedButtonGroupSelectionVM() const; // 0x288a61c (Index: 0x1, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)

protected:
    virtual void BP_OnEntryReleased(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UActivityBrowserTile_NEW_VM_C) == 0x1568, "Size mismatch for UActivityBrowserTile_NEW_VM_C");
static_assert(offsetof(UActivityBrowserTile_NEW_VM_C, UberGraphFrame) == 0x1560, "Offset mismatch for UActivityBrowserTile_NEW_VM_C::UberGraphFrame");

