/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Damage
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayEffectTemplates.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0xa68 (Inherited: 0x1f60, Single: 0xffffeb08)
class UGE_Rock_Explode_PlayerDamage_C : public UGet_DirectDamageParent_C
{
public:
};

static_assert(sizeof(UGE_Rock_Explode_PlayerDamage_C) == 0xa68, "Size mismatch for UGE_Rock_Explode_PlayerDamage_C");

// Size: 0xa68 (Inherited: 0x1f60, Single: 0xffffeb08)
class UGE_Rock_Explode_BuildingDamage_C : public UGET_DirectDamage_LootOnDestroy_C
{
public:
};

static_assert(sizeof(UGE_Rock_Explode_BuildingDamage_C) == 0xa68, "Size mismatch for UGE_Rock_Explode_BuildingDamage_C");

// Size: 0xa68 (Inherited: 0xa90, Single: 0xffffffd8)
class UGE_Rock_Explode_VehicleDamage_C : public UGameplayEffect
{
public:
};

static_assert(sizeof(UGE_Rock_Explode_VehicleDamage_C) == 0xa68, "Size mismatch for UGE_Rock_Explode_VehicleDamage_C");

