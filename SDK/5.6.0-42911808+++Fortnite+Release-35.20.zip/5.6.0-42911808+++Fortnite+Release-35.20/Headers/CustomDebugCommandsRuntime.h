/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CustomDebugCommandsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "ModularGameplay.h"

// Size: 0xd8 (Inherited: 0x250, Single: 0xfffffe88)
class UFortControllerComponent_CustomDebugCommands : public UControllerComponent
{
public:
    FString CommandValidationPrefix; // 0xb8 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_c8[0x10]; // 0xc8 (Size: 0x10, Type: PaddingProperty)

public:
    virtual void ClientOnDebugCommandResult(EDebugCommandResult& const Result); // 0x11ed8268 (Index: 0x0, Flags: Net|NetReliableNative|Event|Public|NetClient)
    virtual void MulticastOnDebugCommandResult(EDebugCommandResult& const Result, FString& PlayerName); // 0x11ed8398 (Index: 0x1, Flags: Net|NetReliableNative|Event|NetMulticast|Public)
    virtual void ServerExecCustomDebugCommand(FString& Command); // 0x11ed876c (Index: 0x2, Flags: RequiredAPI|Net|NetReliableNative|Event|Public|NetServer|NetValidate)
};

static_assert(sizeof(UFortControllerComponent_CustomDebugCommands) == 0xd8, "Size mismatch for UFortControllerComponent_CustomDebugCommands");
static_assert(offsetof(UFortControllerComponent_CustomDebugCommands, CommandValidationPrefix) == 0xb8, "Offset mismatch for UFortControllerComponent_CustomDebugCommands::CommandValidationPrefix");

