/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FallTeleportationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"

// Size: 0x180 (Inherited: 0xe0, Single: 0xa0)
class UFortFallTeleportSpawnerComponent : public UActorComponent
{
public:
    TSoftClassPtr PlayerPawnReceiverClass; // 0xb8 (Size: 0x20, Type: SoftClassProperty)
    UClass* ComponentToAddClass; // 0xd8 (Size: 0x8, Type: ClassProperty)
    FScalableFloat TeleportEnabled; // 0xe0 (Size: 0x28, Type: StructProperty)
    FScalableFloat RemoveComponentRequestTimeOffset; // 0x108 (Size: 0x28, Type: StructProperty)
    uint8_t Pad_130[0x50]; // 0x130 (Size: 0x50, Type: PaddingProperty)

protected:
    void HandleGamePhaseChanged(const FFortGamePhaseUpdatedEvent Event); // 0x113f71c8 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void HandleWarmupCountdownEndTimeUpdated(float& NewEndTime); // 0x113f7294 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortFallTeleportSpawnerComponent) == 0x180, "Size mismatch for UFortFallTeleportSpawnerComponent");
static_assert(offsetof(UFortFallTeleportSpawnerComponent, PlayerPawnReceiverClass) == 0xb8, "Offset mismatch for UFortFallTeleportSpawnerComponent::PlayerPawnReceiverClass");
static_assert(offsetof(UFortFallTeleportSpawnerComponent, ComponentToAddClass) == 0xd8, "Offset mismatch for UFortFallTeleportSpawnerComponent::ComponentToAddClass");
static_assert(offsetof(UFortFallTeleportSpawnerComponent, TeleportEnabled) == 0xe0, "Offset mismatch for UFortFallTeleportSpawnerComponent::TeleportEnabled");
static_assert(offsetof(UFortFallTeleportSpawnerComponent, RemoveComponentRequestTimeOffset) == 0x108, "Offset mismatch for UFortFallTeleportSpawnerComponent::RemoveComponentRequestTimeOffset");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UFortFallTeleportCheatManager : public UChildCheatManager
{
public:

private:
    void EnableFallTeleportationIndefinitely(); // 0x554e3c4 (Index: 0x0, Flags: Final|Exec|Native|Private)
};

static_assert(sizeof(UFortFallTeleportCheatManager) == 0x28, "Size mismatch for UFortFallTeleportCheatManager");

// Size: 0x208 (Inherited: 0xe0, Single: 0x128)
class UFortFallTeleportComponentBase : public UActorComponent
{
public:
    FScalableFloat TeleportEnabled; // 0xb8 (Size: 0x28, Type: StructProperty)
    FScalableFloat ContinuousTeleportUpdateEnabled; // 0xe0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ForceTeleportZHeight; // 0x108 (Size: 0x28, Type: StructProperty)
    FScalableFloat SphereTraceRadius; // 0x130 (Size: 0x28, Type: StructProperty)
    float WalkingLocationUpdateRate; // 0x158 (Size: 0x4, Type: FloatProperty)
    float ZHeightThresholdCheckRate; // 0x15c (Size: 0x4, Type: FloatProperty)
    float TeleportZModifier; // 0x160 (Size: 0x4, Type: FloatProperty)
    float DistanceFromPawnToTraceLocation; // 0x164 (Size: 0x4, Type: FloatProperty)
    TArray<UClass*> TeleportOnBlocklist; // 0x168 (Size: 0x10, Type: ArrayProperty)
    FName NoTeleportActorTag; // 0x178 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_17c[0x4]; // 0x17c (Size: 0x4, Type: PaddingProperty)
    FVector SafeManualLocation; // 0x180 (Size: 0x18, Type: StructProperty)
    UClass* TeleportGEClass; // 0x198 (Size: 0x8, Type: ClassProperty)
    FVector TeleportLocation; // 0x1a0 (Size: 0x18, Type: StructProperty)
    FVector FallbackLocation; // 0x1b8 (Size: 0x18, Type: StructProperty)
    bool bValidFallbackLocation; // 0x1d0 (Size: 0x1, Type: BoolProperty)
    bool bTeleporting; // 0x1d1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1d2[0x2]; // 0x1d2 (Size: 0x2, Type: PaddingProperty)
    int32_t TeleportLimitBeforeFail; // 0x1d4 (Size: 0x4, Type: IntProperty)
    int32_t TeleportCount; // 0x1d8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1dc[0x4]; // 0x1dc (Size: 0x4, Type: PaddingProperty)
    AFortPlayerPawnAthena* OwningPawn; // 0x1e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1e8[0x20]; // 0x1e8 (Size: 0x20, Type: PaddingProperty)

protected:
    bool IsTeleportLocationValid(const FVector LocationToTest) const; // 0x113f73bc (Index: 0x0, Flags: Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    bool IsValidActorToTeleportOn(AActor*& ActorToTeleportOn) const; // 0x113f74a8 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void UpdateLastGroundLocation(ACharacter*& Character, TEnumAsByte<EMovementMode>& PrevMovementMode, char& PreviousCustomMode); // 0x113f7604 (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortFallTeleportComponentBase) == 0x208, "Size mismatch for UFortFallTeleportComponentBase");
static_assert(offsetof(UFortFallTeleportComponentBase, TeleportEnabled) == 0xb8, "Offset mismatch for UFortFallTeleportComponentBase::TeleportEnabled");
static_assert(offsetof(UFortFallTeleportComponentBase, ContinuousTeleportUpdateEnabled) == 0xe0, "Offset mismatch for UFortFallTeleportComponentBase::ContinuousTeleportUpdateEnabled");
static_assert(offsetof(UFortFallTeleportComponentBase, ForceTeleportZHeight) == 0x108, "Offset mismatch for UFortFallTeleportComponentBase::ForceTeleportZHeight");
static_assert(offsetof(UFortFallTeleportComponentBase, SphereTraceRadius) == 0x130, "Offset mismatch for UFortFallTeleportComponentBase::SphereTraceRadius");
static_assert(offsetof(UFortFallTeleportComponentBase, WalkingLocationUpdateRate) == 0x158, "Offset mismatch for UFortFallTeleportComponentBase::WalkingLocationUpdateRate");
static_assert(offsetof(UFortFallTeleportComponentBase, ZHeightThresholdCheckRate) == 0x15c, "Offset mismatch for UFortFallTeleportComponentBase::ZHeightThresholdCheckRate");
static_assert(offsetof(UFortFallTeleportComponentBase, TeleportZModifier) == 0x160, "Offset mismatch for UFortFallTeleportComponentBase::TeleportZModifier");
static_assert(offsetof(UFortFallTeleportComponentBase, DistanceFromPawnToTraceLocation) == 0x164, "Offset mismatch for UFortFallTeleportComponentBase::DistanceFromPawnToTraceLocation");
static_assert(offsetof(UFortFallTeleportComponentBase, TeleportOnBlocklist) == 0x168, "Offset mismatch for UFortFallTeleportComponentBase::TeleportOnBlocklist");
static_assert(offsetof(UFortFallTeleportComponentBase, NoTeleportActorTag) == 0x178, "Offset mismatch for UFortFallTeleportComponentBase::NoTeleportActorTag");
static_assert(offsetof(UFortFallTeleportComponentBase, SafeManualLocation) == 0x180, "Offset mismatch for UFortFallTeleportComponentBase::SafeManualLocation");
static_assert(offsetof(UFortFallTeleportComponentBase, TeleportGEClass) == 0x198, "Offset mismatch for UFortFallTeleportComponentBase::TeleportGEClass");
static_assert(offsetof(UFortFallTeleportComponentBase, TeleportLocation) == 0x1a0, "Offset mismatch for UFortFallTeleportComponentBase::TeleportLocation");
static_assert(offsetof(UFortFallTeleportComponentBase, FallbackLocation) == 0x1b8, "Offset mismatch for UFortFallTeleportComponentBase::FallbackLocation");
static_assert(offsetof(UFortFallTeleportComponentBase, bValidFallbackLocation) == 0x1d0, "Offset mismatch for UFortFallTeleportComponentBase::bValidFallbackLocation");
static_assert(offsetof(UFortFallTeleportComponentBase, bTeleporting) == 0x1d1, "Offset mismatch for UFortFallTeleportComponentBase::bTeleporting");
static_assert(offsetof(UFortFallTeleportComponentBase, TeleportLimitBeforeFail) == 0x1d4, "Offset mismatch for UFortFallTeleportComponentBase::TeleportLimitBeforeFail");
static_assert(offsetof(UFortFallTeleportComponentBase, TeleportCount) == 0x1d8, "Offset mismatch for UFortFallTeleportComponentBase::TeleportCount");
static_assert(offsetof(UFortFallTeleportComponentBase, OwningPawn) == 0x1e0, "Offset mismatch for UFortFallTeleportComponentBase::OwningPawn");

