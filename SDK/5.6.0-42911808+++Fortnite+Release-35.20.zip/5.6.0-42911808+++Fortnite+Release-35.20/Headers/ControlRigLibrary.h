/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ControlRigLibrary
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "ControlRig.h"
#include "RigVM.h"
#include "CoreUObject.h"

// Size: 0x140 (Inherited: 0x30, Single: 0x110)
struct FRigUnit_ProjectItemOnPlane : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    FCachedRigElement CachedItem; // 0x18 (Size: 0x18, Type: StructProperty)
    FTransform Original; // 0x30 (Size: 0x60, Type: StructProperty)
    FVector PlanePoint; // 0x90 (Size: 0x18, Type: StructProperty)
    FVector PlaneNormal; // 0xa8 (Size: 0x18, Type: StructProperty)
    float ProjectAlongNormal; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float Weight; // 0xc4 (Size: 0x4, Type: FloatProperty)
    bool SetItem; // 0xc8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c9[0x7]; // 0xc9 (Size: 0x7, Type: PaddingProperty)
    FTransform Result; // 0xd0 (Size: 0x60, Type: StructProperty)
    bool bIsInitialized; // 0x130 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_131[0xf]; // 0x131 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_ProjectItemOnPlane) == 0x140, "Size mismatch for FRigUnit_ProjectItemOnPlane");
static_assert(offsetof(FRigUnit_ProjectItemOnPlane, Item) == 0x10, "Offset mismatch for FRigUnit_ProjectItemOnPlane::Item");
static_assert(offsetof(FRigUnit_ProjectItemOnPlane, CachedItem) == 0x18, "Offset mismatch for FRigUnit_ProjectItemOnPlane::CachedItem");
static_assert(offsetof(FRigUnit_ProjectItemOnPlane, Original) == 0x30, "Offset mismatch for FRigUnit_ProjectItemOnPlane::Original");
static_assert(offsetof(FRigUnit_ProjectItemOnPlane, PlanePoint) == 0x90, "Offset mismatch for FRigUnit_ProjectItemOnPlane::PlanePoint");
static_assert(offsetof(FRigUnit_ProjectItemOnPlane, PlaneNormal) == 0xa8, "Offset mismatch for FRigUnit_ProjectItemOnPlane::PlaneNormal");
static_assert(offsetof(FRigUnit_ProjectItemOnPlane, ProjectAlongNormal) == 0xc0, "Offset mismatch for FRigUnit_ProjectItemOnPlane::ProjectAlongNormal");
static_assert(offsetof(FRigUnit_ProjectItemOnPlane, Weight) == 0xc4, "Offset mismatch for FRigUnit_ProjectItemOnPlane::Weight");
static_assert(offsetof(FRigUnit_ProjectItemOnPlane, SetItem) == 0xc8, "Offset mismatch for FRigUnit_ProjectItemOnPlane::SetItem");
static_assert(offsetof(FRigUnit_ProjectItemOnPlane, Result) == 0xd0, "Offset mismatch for FRigUnit_ProjectItemOnPlane::Result");
static_assert(offsetof(FRigUnit_ProjectItemOnPlane, bIsInitialized) == 0x130, "Offset mismatch for FRigUnit_ProjectItemOnPlane::bIsInitialized");

// Size: 0x110 (Inherited: 0x30, Single: 0xe0)
struct FRigUnit_JunoRuntine_SolveIKTwoBones : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey BoneA; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey BoneB; // 0x18 (Size: 0x8, Type: StructProperty)
    FRigElementKey BoneC; // 0x20 (Size: 0x8, Type: StructProperty)
    FCachedRigElement CachedBoneA; // 0x28 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedBoneB; // 0x40 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedBoneC; // 0x58 (Size: 0x18, Type: StructProperty)
    FTransform Effector; // 0x70 (Size: 0x60, Type: StructProperty)
    float InitialLength; // 0xd0 (Size: 0x4, Type: FloatProperty)
    bool PullEffector; // 0xd4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d5[0x3]; // 0xd5 (Size: 0x3, Type: PaddingProperty)
    FVector PrimaryAxis; // 0xd8 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0xf0 (Size: 0x18, Type: StructProperty)
    bool bIsInitialized; // 0x108 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_109[0x7]; // 0x109 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_JunoRuntine_SolveIKTwoBones) == 0x110, "Size mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones");
static_assert(offsetof(FRigUnit_JunoRuntine_SolveIKTwoBones, BoneA) == 0x10, "Offset mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones::BoneA");
static_assert(offsetof(FRigUnit_JunoRuntine_SolveIKTwoBones, BoneB) == 0x18, "Offset mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones::BoneB");
static_assert(offsetof(FRigUnit_JunoRuntine_SolveIKTwoBones, BoneC) == 0x20, "Offset mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones::BoneC");
static_assert(offsetof(FRigUnit_JunoRuntine_SolveIKTwoBones, CachedBoneA) == 0x28, "Offset mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones::CachedBoneA");
static_assert(offsetof(FRigUnit_JunoRuntine_SolveIKTwoBones, CachedBoneB) == 0x40, "Offset mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones::CachedBoneB");
static_assert(offsetof(FRigUnit_JunoRuntine_SolveIKTwoBones, CachedBoneC) == 0x58, "Offset mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones::CachedBoneC");
static_assert(offsetof(FRigUnit_JunoRuntine_SolveIKTwoBones, Effector) == 0x70, "Offset mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones::Effector");
static_assert(offsetof(FRigUnit_JunoRuntine_SolveIKTwoBones, InitialLength) == 0xd0, "Offset mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones::InitialLength");
static_assert(offsetof(FRigUnit_JunoRuntine_SolveIKTwoBones, PullEffector) == 0xd4, "Offset mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones::PullEffector");
static_assert(offsetof(FRigUnit_JunoRuntine_SolveIKTwoBones, PrimaryAxis) == 0xd8, "Offset mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones::PrimaryAxis");
static_assert(offsetof(FRigUnit_JunoRuntine_SolveIKTwoBones, SecondaryAxis) == 0xf0, "Offset mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones::SecondaryAxis");
static_assert(offsetof(FRigUnit_JunoRuntine_SolveIKTwoBones, bIsInitialized) == 0x108, "Offset mismatch for FRigUnit_JunoRuntine_SolveIKTwoBones::bIsInitialized");

// Size: 0x70 (Inherited: 0x30, Single: 0x40)
struct FRigUnit_JunoRuntine_RootAlignment : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey Item; // 0x10 (Size: 0x8, Type: StructProperty)
    FCachedRigElement CachedItem; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector HitLocation; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector HitNormal; // 0x48 (Size: 0x18, Type: StructProperty)
    float SideRotationFactor; // 0x60 (Size: 0x4, Type: FloatProperty)
    float CrouchingAmount; // 0x64 (Size: 0x4, Type: FloatProperty)
    bool bIsInitialized; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRigUnit_JunoRuntine_RootAlignment) == 0x70, "Size mismatch for FRigUnit_JunoRuntine_RootAlignment");
static_assert(offsetof(FRigUnit_JunoRuntine_RootAlignment, Item) == 0x10, "Offset mismatch for FRigUnit_JunoRuntine_RootAlignment::Item");
static_assert(offsetof(FRigUnit_JunoRuntine_RootAlignment, CachedItem) == 0x18, "Offset mismatch for FRigUnit_JunoRuntine_RootAlignment::CachedItem");
static_assert(offsetof(FRigUnit_JunoRuntine_RootAlignment, HitLocation) == 0x30, "Offset mismatch for FRigUnit_JunoRuntine_RootAlignment::HitLocation");
static_assert(offsetof(FRigUnit_JunoRuntine_RootAlignment, HitNormal) == 0x48, "Offset mismatch for FRigUnit_JunoRuntine_RootAlignment::HitNormal");
static_assert(offsetof(FRigUnit_JunoRuntine_RootAlignment, SideRotationFactor) == 0x60, "Offset mismatch for FRigUnit_JunoRuntine_RootAlignment::SideRotationFactor");
static_assert(offsetof(FRigUnit_JunoRuntine_RootAlignment, CrouchingAmount) == 0x64, "Offset mismatch for FRigUnit_JunoRuntine_RootAlignment::CrouchingAmount");
static_assert(offsetof(FRigUnit_JunoRuntine_RootAlignment, bIsInitialized) == 0x68, "Offset mismatch for FRigUnit_JunoRuntine_RootAlignment::bIsInitialized");

// Size: 0xf8 (Inherited: 0x30, Single: 0xc8)
struct FRigUnit_TwoBoneIKOffPlane : FRigUnit_HighlevelBaseMutable
{
    FRigElementKey BoneA; // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey BoneB; // 0x18 (Size: 0x8, Type: StructProperty)
    FRigElementKey BoneC; // 0x20 (Size: 0x8, Type: StructProperty)
    FRigElementKey BoneD; // 0x28 (Size: 0x8, Type: StructProperty)
    FVector Effector; // 0x30 (Size: 0x18, Type: StructProperty)
    FVector PoleVector; // 0x48 (Size: 0x18, Type: StructProperty)
    FVector PrimaryAxis; // 0x60 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis; // 0x78 (Size: 0x18, Type: StructProperty)
    int32_t MaxIterations; // 0x90 (Size: 0x4, Type: IntProperty)
    float Tolerance; // 0x94 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement CachedBoneAIndex; // 0x98 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedBoneBIndex; // 0xb0 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedBoneCIndex; // 0xc8 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedBoneDIndex; // 0xe0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRigUnit_TwoBoneIKOffPlane) == 0xf8, "Size mismatch for FRigUnit_TwoBoneIKOffPlane");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, BoneA) == 0x10, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::BoneA");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, BoneB) == 0x18, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::BoneB");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, BoneC) == 0x20, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::BoneC");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, BoneD) == 0x28, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::BoneD");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, Effector) == 0x30, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::Effector");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, PoleVector) == 0x48, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::PoleVector");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, PrimaryAxis) == 0x60, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::PrimaryAxis");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, SecondaryAxis) == 0x78, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::SecondaryAxis");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, MaxIterations) == 0x90, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::MaxIterations");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, Tolerance) == 0x94, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::Tolerance");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, CachedBoneAIndex) == 0x98, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::CachedBoneAIndex");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, CachedBoneBIndex) == 0xb0, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::CachedBoneBIndex");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, CachedBoneCIndex) == 0xc8, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::CachedBoneCIndex");
static_assert(offsetof(FRigUnit_TwoBoneIKOffPlane, CachedBoneDIndex) == 0xe0, "Offset mismatch for FRigUnit_TwoBoneIKOffPlane::CachedBoneDIndex");

