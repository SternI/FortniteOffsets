/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: F5PlayerFactory
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UF5PlayerFactorySettings : public UObject
{
public:
};

static_assert(sizeof(UF5PlayerFactorySettings) == 0x28, "Size mismatch for UF5PlayerFactorySettings");

