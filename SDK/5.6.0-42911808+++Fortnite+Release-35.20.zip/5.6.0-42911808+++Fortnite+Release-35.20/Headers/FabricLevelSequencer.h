/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricLevelSequencer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "FabricRuntime.h"
#include "HarmonixMidi.h"
#include "FabricFramework.h"
#include "LevelSequence.h"
#include "HarmonixMetasound.h"
#include "FabricEngineSequencer.h"

// Size: 0x268 (Inherited: 0xe0, Single: 0x188)
class UFabricSongSyncComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    float MinAllowedTempo; // 0xc0 (Size: 0x4, Type: FloatProperty)
    float MaxAllowedTempo; // 0xc4 (Size: 0x4, Type: FloatProperty)
    TArray<int32_t> AllowedTimeSignatureNumerators; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> AllowedTimeSignatureDenominators; // 0xd8 (Size: 0x10, Type: ArrayProperty)
    FName MidiFilePropertyName; // 0xe8 (Size: 0x4, Type: NameProperty)
    FName OffsetBarsProperty; // 0xec (Size: 0x4, Type: NameProperty)
    FName OffsetBeatsProperty; // 0xf0 (Size: 0x4, Type: NameProperty)
    FName IgnoreSeeksProperty; // 0xf4 (Size: 0x4, Type: NameProperty)
    UClass* MidiFileClockProviderPatchClass; // 0xf8 (Size: 0x8, Type: ClassProperty)
    FName AudioComponentName; // 0x100 (Size: 0x4, Type: NameProperty)
    bool bAllowSpeedAdjustSyncChanges; // 0x104 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_105[0x3]; // 0x105 (Size: 0x3, Type: PaddingProperty)
    uint8_t OnSongSyncPlayInitiated[0x10]; // 0x108 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSongSyncStarted[0x10]; // 0x118 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSongSyncStopped[0x10]; // 0x128 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    FSongSyncPlaybackRequest ServerPlaybackRequest; // 0x138 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_144[0x10]; // 0x144 (Size: 0x10, Type: PaddingProperty)
    FMusicTimestamp PlaybackStartTimestamp; // 0x154 (Size: 0x8, Type: StructProperty)
    FMusicTimestamp RelativeOffsetTimestampMidi; // 0x15c (Size: 0x8, Type: StructProperty)
    FMusicTimestamp RelativeOffsetTimestampLinked; // 0x164 (Size: 0x8, Type: StructProperty)
    bool bWaitForClockRestart; // 0x16c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_16d[0x3]; // 0x16d (Size: 0x3, Type: PaddingProperty)
    FMusicTimestamp CachedTimeStampPreRestart; // 0x170 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_178[0x58]; // 0x178 (Size: 0x58, Type: PaddingProperty)
    FSongSyncMidiSource MidiSource; // 0x1d0 (Size: 0x18, Type: StructProperty)
    TScriptInterface<Class> CurrentFabricMidiProvider; // 0x1e8 (Size: 0x10, Type: InterfaceProperty)
    UMidiFile* MidiSourceLatestMidi; // 0x1f8 (Size: 0x8, Type: ObjectProperty)
    FSongSyncSequenceActor ServerLevelSequenceActor; // 0x200 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_20c[0x10]; // 0x20c (Size: 0x10, Type: PaddingProperty)
    TWeakObjectPtr<UFabricSongSyncComponent*> AuthoritySongSync; // 0x21c (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_224[0x4]; // 0x224 (Size: 0x4, Type: PaddingProperty)
    TArray<TWeakObjectPtr<UFabricSongSyncComponent*>> LinkedSongSyncs; // 0x228 (Size: 0x10, Type: ArrayProperty)
    UMusicClockMovieSceneClockSource* CustomClockSource; // 0x238 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFabricTimelineSyncComponent*> FabricTimelineSyncComponent; // 0x240 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricMidiFollowComponent*> FollowComponent; // 0x248 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMusicClockComponent*> MusicClock; // 0x250 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFabricMetaSoundManagerComponent*> FabricMetasoundManager; // 0x258 (Size: 0x8, Type: WeakObjectProperty)
    UFabricSongSyncUtilityProviderPatchWrapper* MidiFileClockProviderPatchInstance; // 0x260 (Size: 0x8, Type: ObjectProperty)

public:
    void AddLinkedSongSync(UFabricSongSyncComponent*& FollowerSongSync); // 0x11231d78 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    FMusicTimestamp GetCurrentTimestamp() const; // 0x112321e0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetMidiTrackName(UMidiFile*& InMidiFile, int32_t& TrackIndex, FName& Name); // 0x1123220c (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void InitialiseFromOptions(EFabricSongSyncTimingType& InTimingType, EFabricSongSyncPlaybackType& InPlaybackType, float& InStartSeekToTimeSeconds); // 0x112326e8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    bool IsClockAuthority() const; // 0xd248020 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsPlaying() const; // 0x112329c8 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void LocalStopSongSync(); // 0x112329e4 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    bool MidiFileHasAnyTempoData(UMidiFile*& InMidiFile) const; // 0x112329f8 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnFabricZoneSystemSet(AFabricZoneSystem*& const FabricZoneSystem); // 0x11233290 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void OnFollowLengthFinished(); // 0x112333bc (Index: 0xb, Flags: Final|Native|Public)
    void ServerPlaySongSync(const FMusicTimestamp StartingTimestamp); // 0x11233d8c (Index: 0x14, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void ServerSetLevelSequence(TSoftObjectPtr<ULevelSequence*>& LevelSequenceAsset); // 0x11233e64 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)
    void ServerSetMidiSource(const FSongSyncMidiSource InMidiSource); // 0x11234184 (Index: 0x16, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void ServerStopSongSync(); // 0x1123425c (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void SetControllingTempoInGroup(bool& bInControllingTempoInGroup); // 0x112342a8 (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void SetFabricMIDIPlayerPatchWrapper(UFabricMIDIPlayerPatchWrapper*& PatchWrapper); // 0x112343d4 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    void SetLooping(bool& bInLooping); // 0x11234500 (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnClockAuthorityChanged(FName& OldAuthority, FName& NewAuthority, bool& bManagesOwnMusicState); // 0x11232b64 (Index: 0x8, Flags: Final|Native|Private)
    void OnDiscontinuity(EMusicTimeDiscontinuityType& DiscontinuityType, FMidiSongPos& PreviousPos, FMidiSongPos& NewPos); // 0x11232e48 (Index: 0x9, Flags: Final|Native|Private)
    void OnLevelSequenceLooped(const FMusicTimestamp NewStartTimestamp); // 0x112333d0 (Index: 0xc, Flags: Final|Native|Private|HasOutParms)
    void OnMidiLooped(const FMusicTimestamp NewStartTimestamp); // 0x112334ac (Index: 0xd, Flags: Final|Native|Private|HasOutParms)
    void OnMidiProviderMidiChanged(UMidiFile*& InMidiFile); // 0x11233584 (Index: 0xe, Flags: Final|Native|Private)
    void OnMidiProviderMidiCleared(); // 0x112336b0 (Index: 0xf, Flags: Final|Native|Private)
    void OnRep_MidiSource(FSongSyncMidiSource& MidiSourceOld); // 0x112336c4 (Index: 0x10, Flags: Final|Native|Private)
    void OnRep_ServerLevelSequenceActor(); // 0x1123395c (Index: 0x11, Flags: Final|Native|Private)
    void OnRep_ServerPlaybackRequest(); // 0x11233970 (Index: 0x12, Flags: Final|Native|Private)
    void OnTimelineSyncSeek(const FMidiSongPos ClientPos, const FMidiSongPos ServerPos); // 0x112339d4 (Index: 0x13, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UFabricSongSyncComponent) == 0x268, "Size mismatch for UFabricSongSyncComponent");
static_assert(offsetof(UFabricSongSyncComponent, MinAllowedTempo) == 0xc0, "Offset mismatch for UFabricSongSyncComponent::MinAllowedTempo");
static_assert(offsetof(UFabricSongSyncComponent, MaxAllowedTempo) == 0xc4, "Offset mismatch for UFabricSongSyncComponent::MaxAllowedTempo");
static_assert(offsetof(UFabricSongSyncComponent, AllowedTimeSignatureNumerators) == 0xc8, "Offset mismatch for UFabricSongSyncComponent::AllowedTimeSignatureNumerators");
static_assert(offsetof(UFabricSongSyncComponent, AllowedTimeSignatureDenominators) == 0xd8, "Offset mismatch for UFabricSongSyncComponent::AllowedTimeSignatureDenominators");
static_assert(offsetof(UFabricSongSyncComponent, MidiFilePropertyName) == 0xe8, "Offset mismatch for UFabricSongSyncComponent::MidiFilePropertyName");
static_assert(offsetof(UFabricSongSyncComponent, OffsetBarsProperty) == 0xec, "Offset mismatch for UFabricSongSyncComponent::OffsetBarsProperty");
static_assert(offsetof(UFabricSongSyncComponent, OffsetBeatsProperty) == 0xf0, "Offset mismatch for UFabricSongSyncComponent::OffsetBeatsProperty");
static_assert(offsetof(UFabricSongSyncComponent, IgnoreSeeksProperty) == 0xf4, "Offset mismatch for UFabricSongSyncComponent::IgnoreSeeksProperty");
static_assert(offsetof(UFabricSongSyncComponent, MidiFileClockProviderPatchClass) == 0xf8, "Offset mismatch for UFabricSongSyncComponent::MidiFileClockProviderPatchClass");
static_assert(offsetof(UFabricSongSyncComponent, AudioComponentName) == 0x100, "Offset mismatch for UFabricSongSyncComponent::AudioComponentName");
static_assert(offsetof(UFabricSongSyncComponent, bAllowSpeedAdjustSyncChanges) == 0x104, "Offset mismatch for UFabricSongSyncComponent::bAllowSpeedAdjustSyncChanges");
static_assert(offsetof(UFabricSongSyncComponent, OnSongSyncPlayInitiated) == 0x108, "Offset mismatch for UFabricSongSyncComponent::OnSongSyncPlayInitiated");
static_assert(offsetof(UFabricSongSyncComponent, OnSongSyncStarted) == 0x118, "Offset mismatch for UFabricSongSyncComponent::OnSongSyncStarted");
static_assert(offsetof(UFabricSongSyncComponent, OnSongSyncStopped) == 0x128, "Offset mismatch for UFabricSongSyncComponent::OnSongSyncStopped");
static_assert(offsetof(UFabricSongSyncComponent, ServerPlaybackRequest) == 0x138, "Offset mismatch for UFabricSongSyncComponent::ServerPlaybackRequest");
static_assert(offsetof(UFabricSongSyncComponent, PlaybackStartTimestamp) == 0x154, "Offset mismatch for UFabricSongSyncComponent::PlaybackStartTimestamp");
static_assert(offsetof(UFabricSongSyncComponent, RelativeOffsetTimestampMidi) == 0x15c, "Offset mismatch for UFabricSongSyncComponent::RelativeOffsetTimestampMidi");
static_assert(offsetof(UFabricSongSyncComponent, RelativeOffsetTimestampLinked) == 0x164, "Offset mismatch for UFabricSongSyncComponent::RelativeOffsetTimestampLinked");
static_assert(offsetof(UFabricSongSyncComponent, bWaitForClockRestart) == 0x16c, "Offset mismatch for UFabricSongSyncComponent::bWaitForClockRestart");
static_assert(offsetof(UFabricSongSyncComponent, CachedTimeStampPreRestart) == 0x170, "Offset mismatch for UFabricSongSyncComponent::CachedTimeStampPreRestart");
static_assert(offsetof(UFabricSongSyncComponent, MidiSource) == 0x1d0, "Offset mismatch for UFabricSongSyncComponent::MidiSource");
static_assert(offsetof(UFabricSongSyncComponent, CurrentFabricMidiProvider) == 0x1e8, "Offset mismatch for UFabricSongSyncComponent::CurrentFabricMidiProvider");
static_assert(offsetof(UFabricSongSyncComponent, MidiSourceLatestMidi) == 0x1f8, "Offset mismatch for UFabricSongSyncComponent::MidiSourceLatestMidi");
static_assert(offsetof(UFabricSongSyncComponent, ServerLevelSequenceActor) == 0x200, "Offset mismatch for UFabricSongSyncComponent::ServerLevelSequenceActor");
static_assert(offsetof(UFabricSongSyncComponent, AuthoritySongSync) == 0x21c, "Offset mismatch for UFabricSongSyncComponent::AuthoritySongSync");
static_assert(offsetof(UFabricSongSyncComponent, LinkedSongSyncs) == 0x228, "Offset mismatch for UFabricSongSyncComponent::LinkedSongSyncs");
static_assert(offsetof(UFabricSongSyncComponent, CustomClockSource) == 0x238, "Offset mismatch for UFabricSongSyncComponent::CustomClockSource");
static_assert(offsetof(UFabricSongSyncComponent, FabricTimelineSyncComponent) == 0x240, "Offset mismatch for UFabricSongSyncComponent::FabricTimelineSyncComponent");
static_assert(offsetof(UFabricSongSyncComponent, FollowComponent) == 0x248, "Offset mismatch for UFabricSongSyncComponent::FollowComponent");
static_assert(offsetof(UFabricSongSyncComponent, MusicClock) == 0x250, "Offset mismatch for UFabricSongSyncComponent::MusicClock");
static_assert(offsetof(UFabricSongSyncComponent, FabricMetasoundManager) == 0x258, "Offset mismatch for UFabricSongSyncComponent::FabricMetasoundManager");
static_assert(offsetof(UFabricSongSyncComponent, MidiFileClockProviderPatchInstance) == 0x260, "Offset mismatch for UFabricSongSyncComponent::MidiFileClockProviderPatchInstance");

// Size: 0x1d0 (Inherited: 0x210, Single: 0xffffffc0)
class UPlaylistUserOptionMidiSource : public UPlaylistUserOptionBase
{
public:
    FMidiSource DefaultValue; // 0x1b8 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UPlaylistUserOptionMidiSource) == 0x1d0, "Size mismatch for UPlaylistUserOptionMidiSource");
static_assert(offsetof(UPlaylistUserOptionMidiSource, DefaultValue) == 0x1b8, "Offset mismatch for UPlaylistUserOptionMidiSource::DefaultValue");

// Size: 0x1d8 (Inherited: 0x210, Single: 0xffffffc8)
class UPlaylistUserOptionLinkedSequence : public UPlaylistUserOptionBase
{
public:
    FLinkedSequence DefaultValue; // 0x1b8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UPlaylistUserOptionLinkedSequence) == 0x1d8, "Size mismatch for UPlaylistUserOptionLinkedSequence");
static_assert(offsetof(UPlaylistUserOptionLinkedSequence, DefaultValue) == 0x1b8, "Offset mismatch for UPlaylistUserOptionLinkedSequence::DefaultValue");

// Size: 0x1c8 (Inherited: 0x210, Single: 0xffffffb8)
class UPlaylistUserOptionLinkedSongSyncList : public UPlaylistUserOptionBase
{
public:
    FLinkedSongSyncList DefaultValue; // 0x1b8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UPlaylistUserOptionLinkedSongSyncList) == 0x1c8, "Size mismatch for UPlaylistUserOptionLinkedSongSyncList");
static_assert(offsetof(UPlaylistUserOptionLinkedSongSyncList, DefaultValue) == 0x1b8, "Offset mismatch for UPlaylistUserOptionLinkedSongSyncList::DefaultValue");

// Size: 0x1f8 (Inherited: 0x1d0, Single: 0x28)
class UFabricSongSyncUtilityProviderPatchWrapper : public UFabricMetaSoundUtilityProviderPatchWrapper
{
public:
    uint8_t Pad_1a8[0x38]; // 0x1a8 (Size: 0x38, Type: PaddingProperty)
    FName ClockProviderMidiFileInName; // 0x1e0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1e4[0x4]; // 0x1e4 (Size: 0x4, Type: PaddingProperty)
    UMidiFile* DefaultMidiFile; // 0x1e8 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UMidiFile*> TempoMapMidiFile; // 0x1f0 (Size: 0x8, Type: WeakObjectProperty)

public:
    void SetMidiFile(UMidiFile*& MidiFile); // 0x1123462c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFabricSongSyncUtilityProviderPatchWrapper) == 0x1f8, "Size mismatch for UFabricSongSyncUtilityProviderPatchWrapper");
static_assert(offsetof(UFabricSongSyncUtilityProviderPatchWrapper, ClockProviderMidiFileInName) == 0x1e0, "Offset mismatch for UFabricSongSyncUtilityProviderPatchWrapper::ClockProviderMidiFileInName");
static_assert(offsetof(UFabricSongSyncUtilityProviderPatchWrapper, DefaultMidiFile) == 0x1e8, "Offset mismatch for UFabricSongSyncUtilityProviderPatchWrapper::DefaultMidiFile");
static_assert(offsetof(UFabricSongSyncUtilityProviderPatchWrapper, TempoMapMidiFile) == 0x1f0, "Offset mismatch for UFabricSongSyncUtilityProviderPatchWrapper::TempoMapMidiFile");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FSongSyncPlaybackRequest
{
    FMusicTimestamp StartingTimestamp; // 0x0 (Size: 0x8, Type: StructProperty)
    bool bPlay; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FSongSyncPlaybackRequest) == 0xc, "Size mismatch for FSongSyncPlaybackRequest");
static_assert(offsetof(FSongSyncPlaybackRequest, StartingTimestamp) == 0x0, "Offset mismatch for FSongSyncPlaybackRequest::StartingTimestamp");
static_assert(offsetof(FSongSyncPlaybackRequest, bPlay) == 0x8, "Offset mismatch for FSongSyncPlaybackRequest::bPlay");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FSongSyncSequenceActor
{
    TWeakObjectPtr<ALevelSequenceActor*> LevelSequenceActor; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t SequenceState; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FSongSyncSequenceActor) == 0xc, "Size mismatch for FSongSyncSequenceActor");
static_assert(offsetof(FSongSyncSequenceActor, LevelSequenceActor) == 0x0, "Offset mismatch for FSongSyncSequenceActor::LevelSequenceActor");
static_assert(offsetof(FSongSyncSequenceActor, SequenceState) == 0x8, "Offset mismatch for FSongSyncSequenceActor::SequenceState");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FSongSyncMidiSource
{
    UMidiFile* MidiFile; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t MidiSourceType; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    FName SelectedMidiTrackName; // 0xc (Size: 0x4, Type: NameProperty)
    bool bHasBeenSet; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FSongSyncMidiSource) == 0x18, "Size mismatch for FSongSyncMidiSource");
static_assert(offsetof(FSongSyncMidiSource, MidiFile) == 0x0, "Offset mismatch for FSongSyncMidiSource::MidiFile");
static_assert(offsetof(FSongSyncMidiSource, MidiSourceType) == 0x8, "Offset mismatch for FSongSyncMidiSource::MidiSourceType");
static_assert(offsetof(FSongSyncMidiSource, SelectedMidiTrackName) == 0xc, "Offset mismatch for FSongSyncMidiSource::SelectedMidiTrackName");
static_assert(offsetof(FSongSyncMidiSource, bHasBeenSet) == 0x10, "Offset mismatch for FSongSyncMidiSource::bHasBeenSet");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FMidiSource
{
    uint8_t MidiSourceType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UMidiFile* MidiFile; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FName SelectedMidiTrackName; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FMidiSource) == 0x18, "Size mismatch for FMidiSource");
static_assert(offsetof(FMidiSource, MidiSourceType) == 0x0, "Offset mismatch for FMidiSource::MidiSourceType");
static_assert(offsetof(FMidiSource, MidiFile) == 0x8, "Offset mismatch for FMidiSource::MidiFile");
static_assert(offsetof(FMidiSource, SelectedMidiTrackName) == 0x10, "Offset mismatch for FMidiSource::SelectedMidiTrackName");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FLinkedSequence
{
    TSoftObjectPtr<ULevelSequence*> LevelSequence; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FLinkedSequence) == 0x20, "Size mismatch for FLinkedSequence");
static_assert(offsetof(FLinkedSequence, LevelSequence) == 0x0, "Offset mismatch for FLinkedSequence::LevelSequence");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FLinkedSongSync
{
    TSoftObjectPtr<AActor*> LinkedSongSync; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FLinkedSongSync) == 0x20, "Size mismatch for FLinkedSongSync");
static_assert(offsetof(FLinkedSongSync, LinkedSongSync) == 0x0, "Offset mismatch for FLinkedSongSync::LinkedSongSync");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FLinkedSongSyncList
{
    TArray<FLinkedSongSync> LinkedSongSyncs; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FLinkedSongSyncList) == 0x10, "Size mismatch for FLinkedSongSyncList");
static_assert(offsetof(FLinkedSongSyncList, LinkedSongSyncs) == 0x0, "Offset mismatch for FLinkedSongSyncList::LinkedSongSyncs");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FUserOptionDefinitionMidiSourceMetaData : FUserOptionDefinitionMetaData
{
};

static_assert(sizeof(FUserOptionDefinitionMidiSourceMetaData) == 0x8, "Size mismatch for FUserOptionDefinitionMidiSourceMetaData");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FUserOptionDefinitionLinkedSequenceMetaData : FUserOptionDefinitionMetaData
{
};

static_assert(sizeof(FUserOptionDefinitionLinkedSequenceMetaData) == 0x8, "Size mismatch for FUserOptionDefinitionLinkedSequenceMetaData");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FUserOptionDefinitionLinkedSongSyncListMetaData : FUserOptionDefinitionMetaData
{
    FLinkedSongSyncList DefaultValue; // 0x8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FUserOptionDefinitionLinkedSongSyncListMetaData) == 0x18, "Size mismatch for FUserOptionDefinitionLinkedSongSyncListMetaData");
static_assert(offsetof(FUserOptionDefinitionLinkedSongSyncListMetaData, DefaultValue) == 0x8, "Offset mismatch for FUserOptionDefinitionLinkedSongSyncListMetaData::DefaultValue");

