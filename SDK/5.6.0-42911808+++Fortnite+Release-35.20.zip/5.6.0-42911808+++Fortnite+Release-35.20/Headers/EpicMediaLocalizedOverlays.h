/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaLocalizedOverlays
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Overlay.h"
#include "MediaAssets.h"

// Size: 0x90 (Inherited: 0xd0, Single: 0xffffffc0)
class UEpicMediaDownloadLocalizedOverlays : public ULocalizedOverlays
{
public:
    UMediaPlayer* MediaPlayer; // 0x80 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_88[0x8]; // 0x88 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UEpicMediaDownloadLocalizedOverlays) == 0x90, "Size mismatch for UEpicMediaDownloadLocalizedOverlays");
static_assert(offsetof(UEpicMediaDownloadLocalizedOverlays, MediaPlayer) == 0x80, "Offset mismatch for UEpicMediaDownloadLocalizedOverlays::MediaPlayer");

