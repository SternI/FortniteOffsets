/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityDiscoverView_NEW_VM
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DiscoveryBrowserUI.h"
#include "FortniteGame.h"
#include "UMG.h"
#include "ActivityBrowserDiscoverGridRowMax.h"
#include "Engine.h"
#include "FortniteUI.h"
#include "AudioModulation.h"
#include "UIKit.h"

// Size: 0x969 (Inherited: 0x23b8, Single: 0xffffe5b1)
class UActivityDiscoverView_NEW_VM_C : public UFortActivityDiscoverViewV2
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x830 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_Throbber_C* WBP_UIKit_Throbber; // 0x838 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Nav; // 0x840 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Intro; // 0x848 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ShowAndHideRowLoadingSpinner; // 0x850 (Size: 0x8, Type: ObjectProperty)
    UTexture* NextImage; // 0x858 (Size: 0x8, Type: ObjectProperty)
    FName KeyArtParameter; // 0x860 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_864[0x4]; // 0x864 (Size: 0x4, Type: PaddingProperty)
    UTexture* DefaultImage; // 0x868 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnPlayIntro[0x10]; // 0x870 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool HasIntroPlayed; // 0x880 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_881[0x7]; // 0x881 (Size: 0x7, Type: PaddingProperty)
    double DetailsMaxHeight; // 0x888 (Size: 0x8, Type: DoubleProperty)
    double DetailsMaxHeightMobile; // 0x890 (Size: 0x8, Type: DoubleProperty)
    double KeyArtMaxWidth; // 0x898 (Size: 0x8, Type: DoubleProperty)
    double KeyArtMaxWidthMobile; // 0x8a0 (Size: 0x8, Type: DoubleProperty)
    TArray<UImage*> KeyArt_ImageWidgets; // 0x8a8 (Size: 0x10, Type: ArrayProperty)
    bool IsPromotedContentDisplayed; // 0x8b8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8b9[0x7]; // 0x8b9 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnRowUpdated[0x10]; // 0x8c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool IsImageLoadingSpinnerActive; // 0x8d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8d1[0x7]; // 0x8d1 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnListScrolled[0x10]; // 0x8d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnHomeBarUpdated[0x10]; // 0x8e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    int32_t RowIndex; // 0x8f8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_8fc[0x4]; // 0x8fc (Size: 0x4, Type: PaddingProperty)
    uint8_t BroadcastToHomespaceTileClicked[0x10]; // 0x900 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    USoundBase* AmbientBackgroundLoop; // 0x910 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* BackgroundAmbience; // 0x918 (Size: 0x8, Type: ObjectProperty)
    USoundSubmix* MusicSubmix; // 0x920 (Size: 0x8, Type: ObjectProperty)
    USubmixEffectDynamicReverbPreset* ReverbSubmixEffect; // 0x928 (Size: 0x8, Type: ObjectProperty)
    USoundControlBusMix* ControlBusMix; // 0x930 (Size: 0x8, Type: ObjectProperty)
    UAthenaLobbyBase* Athena_Lobby; // 0x938 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnOverSwipeUp[0x10]; // 0x940 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool IsFullscreen; // 0x950 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_951[0x7]; // 0x951 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnSwipeDownWhenCollapsed[0x10]; // 0x958 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool WasViewAllSelected; // 0x968 (Size: 0x1, Type: BoolProperty)

public:
    void AllowMouseWheelScrolling(bool& AllowMouseWheelScrolling); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SnapToEndOfAnimation(UWidgetAnimation*& InAnimation, TEnumAsByte<EUMGSequencePlayMode>& PlayMode); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ResetScreenState(); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    void OnSwipeDownWhenCollapsed__DelegateSignature(); // 0x288a61c (Index: 0x6, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnRowUpdated__DelegateSignature(bool& IsPromoted, bool& IsFirstRow); // 0x288a61c (Index: 0x7, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void OnRowChanged(int32_t& const NewCategoryIndex); // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent)
    virtual void OnQueryActivitiesFinished(); // 0x288a61c (Index: 0xa, Flags: Event|Public|BlueprintEvent)
    void OnPlayIntro__DelegateSignature(); // 0x288a61c (Index: 0xb, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnOverSwipeUp__DelegateSignature(); // 0x288a61c (Index: 0xc, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void OnListViewScrolled(float& ItemOffset, float& DistanceRemaining); // 0x288a61c (Index: 0xd, Flags: Event|Public|BlueprintEvent)
    void OnListScrolled__DelegateSignature(double& ItemOffset, double& DistanceRemaining); // 0x288a61c (Index: 0xe, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    void OnHomeBarUpdated__DelegateSignature(bool& IsFirstRow); // 0x288a61c (Index: 0xf, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
    virtual void OnActivityUpdated(); // 0x288a61c (Index: 0x11, Flags: Event|Public|BlueprintEvent)
    void GetIndexOfCurrentActivity(int32_t& TileIndex); // 0x288a61c (Index: 0x12, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent)
    void GetHasIntroPlayed(bool& IsFinishedLoading); // 0x288a61c (Index: 0x13, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    virtual void Construct(); // 0x288a61c (Index: 0x15, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void BroadcastToHomespaceTileClicked__DelegateSignature(); // 0x288a61c (Index: 0x16, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UActivityDiscoverView_NEW_VM_C) == 0x969, "Size mismatch for UActivityDiscoverView_NEW_VM_C");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, UberGraphFrame) == 0x830, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::UberGraphFrame");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, WBP_UIKit_Throbber) == 0x838, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::WBP_UIKit_Throbber");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, Overlay_Nav) == 0x840, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::Overlay_Nav");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, Intro) == 0x848, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::Intro");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, ShowAndHideRowLoadingSpinner) == 0x850, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::ShowAndHideRowLoadingSpinner");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, NextImage) == 0x858, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::NextImage");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, KeyArtParameter) == 0x860, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::KeyArtParameter");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, DefaultImage) == 0x868, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::DefaultImage");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, OnPlayIntro) == 0x870, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::OnPlayIntro");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, HasIntroPlayed) == 0x880, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::HasIntroPlayed");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, DetailsMaxHeight) == 0x888, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::DetailsMaxHeight");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, DetailsMaxHeightMobile) == 0x890, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::DetailsMaxHeightMobile");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, KeyArtMaxWidth) == 0x898, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::KeyArtMaxWidth");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, KeyArtMaxWidthMobile) == 0x8a0, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::KeyArtMaxWidthMobile");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, KeyArt_ImageWidgets) == 0x8a8, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::KeyArt_ImageWidgets");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, IsPromotedContentDisplayed) == 0x8b8, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::IsPromotedContentDisplayed");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, OnRowUpdated) == 0x8c0, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::OnRowUpdated");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, IsImageLoadingSpinnerActive) == 0x8d0, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::IsImageLoadingSpinnerActive");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, OnListScrolled) == 0x8d8, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::OnListScrolled");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, OnHomeBarUpdated) == 0x8e8, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::OnHomeBarUpdated");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, RowIndex) == 0x8f8, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::RowIndex");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, BroadcastToHomespaceTileClicked) == 0x900, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::BroadcastToHomespaceTileClicked");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, AmbientBackgroundLoop) == 0x910, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::AmbientBackgroundLoop");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, BackgroundAmbience) == 0x918, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::BackgroundAmbience");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, MusicSubmix) == 0x920, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::MusicSubmix");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, ReverbSubmixEffect) == 0x928, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::ReverbSubmixEffect");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, ControlBusMix) == 0x930, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::ControlBusMix");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, Athena_Lobby) == 0x938, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::Athena_Lobby");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, OnOverSwipeUp) == 0x940, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::OnOverSwipeUp");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, IsFullscreen) == 0x950, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::IsFullscreen");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, OnSwipeDownWhenCollapsed) == 0x958, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::OnSwipeDownWhenCollapsed");
static_assert(offsetof(UActivityDiscoverView_NEW_VM_C, WasViewAllSelected) == 0x968, "Offset mismatch for UActivityDiscoverView_NEW_VM_C::WasViewAllSelected");

