/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_CinematicSequence
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "MovieScene.h"
#include "LevelSequence.h"
#include "CoreUObject.h"

// Size: 0xce0 (Inherited: 0x39a0, Single: 0xffffd340)
class ACinematicSequenceDeviceBase : public ABuildingProp
{
public:
    uint8_t Pad_c00[0x50]; // 0xc00 (Size: 0x50, Type: PaddingProperty)
    FSoftClassPath AISpawnerDeviceClassPath; // 0xc50 (Size: 0x18, Type: StructProperty)
    ULevelSequence* Sequence; // 0xc68 (Size: 0x8, Type: ObjectProperty)
    ALevelSequenceActor* LevelSequenceActor; // 0xc70 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerController* InstigatingController; // 0xc78 (Size: 0x8, Type: ObjectProperty)
    char InstigatingTeam; // 0xc80 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_c81[0x3]; // 0xc81 (Size: 0x3, Type: PaddingProperty)
    uint8_t bLoopPlayback : 1; // 0xc84:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAutoPlay : 1; // 0xc84:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c85[0x3]; // 0xc85 (Size: 0x3, Type: PaddingProperty)
    uint8_t EnabledOnPhase; // 0xc88 (Size: 0x1, Type: EnumProperty)
    uint8_t Visibility; // 0xc89 (Size: 0x1, Type: EnumProperty)
    bool bLevelSequenceActorAlwaysRelevant; // 0xc8a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c8b[0x1]; // 0xc8b (Size: 0x1, Type: PaddingProperty)
    float PlayRate; // 0xc8c (Size: 0x4, Type: FloatProperty)
    uint8_t FinishCompletionStateOverride; // 0xc90 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c91[0x4f]; // 0xc91 (Size: 0x4f, Type: PaddingProperty)

public:
    int32_t GetPlaybackFrame() const; // 0x11a903b0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPlaybackTime() const; // 0x11a903dc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetPlayRate() const; // 0x11a90388 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMovieSceneSequencePlayer* GetSequencePlayer() const; // 0x11a90400 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void GoToEndAndStop(); // 0x11a90420 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void Pause(); // 0x11a90434 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void Play(); // 0x11a90448 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void PlayReverse(); // 0x11a9045c (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void SetPlaybackFrame(int32_t& Frame); // 0x11a90604 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void SetPlaybackTime(float& time); // 0x11a9072c (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void SetPlayRate(float& PlayRate); // 0x11a904d8 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    void SetSequence(ULevelSequence*& Sequence); // 0x11a90858 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    void Stop(); // 0x11a90984 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void HandleSequencePlayerCreated(ULevelSequencePlayer*& Player); // 0x4327fd0 (Index: 0x5, Flags: Native|Event|Protected|BlueprintEvent)
    void OnSequenceFinished(); // 0x554e3c4 (Index: 0x6, Flags: Final|Native|Protected)
};

static_assert(sizeof(ACinematicSequenceDeviceBase) == 0xce0, "Size mismatch for ACinematicSequenceDeviceBase");
static_assert(offsetof(ACinematicSequenceDeviceBase, AISpawnerDeviceClassPath) == 0xc50, "Offset mismatch for ACinematicSequenceDeviceBase::AISpawnerDeviceClassPath");
static_assert(offsetof(ACinematicSequenceDeviceBase, Sequence) == 0xc68, "Offset mismatch for ACinematicSequenceDeviceBase::Sequence");
static_assert(offsetof(ACinematicSequenceDeviceBase, LevelSequenceActor) == 0xc70, "Offset mismatch for ACinematicSequenceDeviceBase::LevelSequenceActor");
static_assert(offsetof(ACinematicSequenceDeviceBase, InstigatingController) == 0xc78, "Offset mismatch for ACinematicSequenceDeviceBase::InstigatingController");
static_assert(offsetof(ACinematicSequenceDeviceBase, InstigatingTeam) == 0xc80, "Offset mismatch for ACinematicSequenceDeviceBase::InstigatingTeam");
static_assert(offsetof(ACinematicSequenceDeviceBase, bLoopPlayback) == 0xc84, "Offset mismatch for ACinematicSequenceDeviceBase::bLoopPlayback");
static_assert(offsetof(ACinematicSequenceDeviceBase, bAutoPlay) == 0xc84, "Offset mismatch for ACinematicSequenceDeviceBase::bAutoPlay");
static_assert(offsetof(ACinematicSequenceDeviceBase, EnabledOnPhase) == 0xc88, "Offset mismatch for ACinematicSequenceDeviceBase::EnabledOnPhase");
static_assert(offsetof(ACinematicSequenceDeviceBase, Visibility) == 0xc89, "Offset mismatch for ACinematicSequenceDeviceBase::Visibility");
static_assert(offsetof(ACinematicSequenceDeviceBase, bLevelSequenceActorAlwaysRelevant) == 0xc8a, "Offset mismatch for ACinematicSequenceDeviceBase::bLevelSequenceActorAlwaysRelevant");
static_assert(offsetof(ACinematicSequenceDeviceBase, PlayRate) == 0xc8c, "Offset mismatch for ACinematicSequenceDeviceBase::PlayRate");
static_assert(offsetof(ACinematicSequenceDeviceBase, FinishCompletionStateOverride) == 0xc90, "Offset mismatch for ACinematicSequenceDeviceBase::FinishCompletionStateOverride");

