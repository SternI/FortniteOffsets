/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamSystemRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "ModularGameplay.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "PlayspaceSystem.h"
#include "FortniteGame.h"
#include "SparksCoreCosmeticsRuntime.h"
#include "GameplayTags.h"
#include "FMJamPlayspaceRuntime.h"
#include "GameplayAbilities.h"
#include "GameplayEventRouter.h"

// Size: 0xe0 (Inherited: 0x250, Single: 0xfffffe90)
class UJamControllerComponent : public UControllerComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    FGameplayTagContainer AdditionalTags; // 0xc0 (Size: 0x20, Type: StructProperty)

public:
    AController* GetControllerOfClass(UClass*& ControllerType, bool& bMatchChildTypes); // 0x107f7918 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)

protected:
    static bool CanSuppressJamControls(); // 0x107f78e8 (Index: 0x0, Flags: Final|Native|Static|Protected|BlueprintCallable)
    virtual void UpdateJamUI(); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UJamControllerComponent) == 0xe0, "Size mismatch for UJamControllerComponent");
static_assert(offsetof(UJamControllerComponent, AdditionalTags) == 0xc0, "Offset mismatch for UJamControllerComponent::AdditionalTags");

// Size: 0x138 (Inherited: 0x250, Single: 0xfffffee8)
class UJamControllerComponent_LoopOptions : public UControllerComponent
{
public:
    FName CategoryNameLocker; // 0xb8 (Size: 0x4, Type: NameProperty)
    FName CategoryNameAll; // 0xbc (Size: 0x4, Type: NameProperty)
    FText CategoryTitleLocker; // 0xc0 (Size: 0x10, Type: TextProperty)
    FText CategoryTitleAll; // 0xd0 (Size: 0x10, Type: TextProperty)
    FGameplayTag CategoryTagLocker; // 0xe0 (Size: 0x4, Type: StructProperty)
    FGameplayTag CategoryTagAll; // 0xe4 (Size: 0x4, Type: StructProperty)
    TSoftClassPtr EmoteWheelOverlay; // 0xe8 (Size: 0x20, Type: SoftClassProperty)
    TArray<FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry> LoopTypeToIndexMapping; // 0x108 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_118[0x10]; // 0x118 (Size: 0x10, Type: PaddingProperty)
    TArray<USparksJamEmoteItemDefinition*> LoadedItemDefs; // 0x128 (Size: 0x10, Type: ArrayProperty)

public:
    bool GetLoopTypeForMultiEmoteIndex(int32_t& Index, EFMJamLoopType& OutLoopType) const; // 0x107f8050 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    int32_t GetMultiEmoteIndexForLoopType(EFMJamLoopType& LoopType) const; // 0x107f8238 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void LoadJamCategories(); // 0x107f8cf8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveJamCategories(); // 0x107f9bfc (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void BeginSetup(); // 0x47abb70 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void OnFinishedLoadingItemDefs(); // 0x107f8d0c (Index: 0x4, Flags: Final|Native|Protected)
    void OnFirstPawnSet(APawn*& OldPawn, APawn*& NewPawn); // 0x107f8d20 (Index: 0x5, Flags: Final|Native|Protected)
    void OnJamBlockingTagAdded(); // 0x107f8f28 (Index: 0x6, Flags: Final|Native|Protected)
    void OnJamBlockingTagChanged(FGameplayTag& const UpdatedTag, int32_t& TagCount); // 0x107f8f3c (Index: 0x7, Flags: Final|Native|Protected)
    void OnJamBlockingTagRemoved(); // 0x107f906c (Index: 0x8, Flags: Final|Native|Protected)
    void OnPawnSetAfterBlockingTag(APawn*& OldPawn, APawn*& NewPawn); // 0x107f938c (Index: 0x9, Flags: Final|Native|Protected)
    void OnSparksLoadoutFilled(); // 0x107f9878 (Index: 0xa, Flags: Final|Native|Protected)
    virtual bool ShouldAddJamCategoriesBeforeLocker() const; // 0x4c4e47c (Index: 0xc, Flags: Native|Event|Protected|BlueprintEvent|Const)
};

static_assert(sizeof(UJamControllerComponent_LoopOptions) == 0x138, "Size mismatch for UJamControllerComponent_LoopOptions");
static_assert(offsetof(UJamControllerComponent_LoopOptions, CategoryNameLocker) == 0xb8, "Offset mismatch for UJamControllerComponent_LoopOptions::CategoryNameLocker");
static_assert(offsetof(UJamControllerComponent_LoopOptions, CategoryNameAll) == 0xbc, "Offset mismatch for UJamControllerComponent_LoopOptions::CategoryNameAll");
static_assert(offsetof(UJamControllerComponent_LoopOptions, CategoryTitleLocker) == 0xc0, "Offset mismatch for UJamControllerComponent_LoopOptions::CategoryTitleLocker");
static_assert(offsetof(UJamControllerComponent_LoopOptions, CategoryTitleAll) == 0xd0, "Offset mismatch for UJamControllerComponent_LoopOptions::CategoryTitleAll");
static_assert(offsetof(UJamControllerComponent_LoopOptions, CategoryTagLocker) == 0xe0, "Offset mismatch for UJamControllerComponent_LoopOptions::CategoryTagLocker");
static_assert(offsetof(UJamControllerComponent_LoopOptions, CategoryTagAll) == 0xe4, "Offset mismatch for UJamControllerComponent_LoopOptions::CategoryTagAll");
static_assert(offsetof(UJamControllerComponent_LoopOptions, EmoteWheelOverlay) == 0xe8, "Offset mismatch for UJamControllerComponent_LoopOptions::EmoteWheelOverlay");
static_assert(offsetof(UJamControllerComponent_LoopOptions, LoopTypeToIndexMapping) == 0x108, "Offset mismatch for UJamControllerComponent_LoopOptions::LoopTypeToIndexMapping");
static_assert(offsetof(UJamControllerComponent_LoopOptions, LoadedItemDefs) == 0x128, "Offset mismatch for UJamControllerComponent_LoopOptions::LoadedItemDefs");

// Size: 0x110 (Inherited: 0x250, Single: 0xfffffec0)
class UJamControllerComponent_LoopPreloader : public UControllerComponent
{
public:
    bool bHaveRegisteredForOnLoadoutFilled; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x57]; // 0xb9 (Size: 0x57, Type: PaddingProperty)

protected:
    void OnLoadoutFilled(); // 0x107f9080 (Index: 0x0, Flags: Final|Native|Protected)
    void OnPawnSet(APlayerState*& Player, APawn*& NewPawn, APawn*& OldPawn); // 0x107f90a8 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UJamControllerComponent_LoopPreloader) == 0x110, "Size mismatch for UJamControllerComponent_LoopPreloader");
static_assert(offsetof(UJamControllerComponent_LoopPreloader, bHaveRegisteredForOnLoadoutFilled) == 0xb8, "Offset mismatch for UJamControllerComponent_LoopPreloader::bHaveRegisteredForOnLoadoutFilled");

// Size: 0x440 (Inherited: 0xb38, Single: 0xfffff908)
class UJamGlobalControlsWidget : public UCommonActivatableWidget
{
public:
    UCommonButtonBase* Button_Close; // 0x408 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AJamPlayspace*> JamPlayspace; // 0x410 (Size: 0x8, Type: WeakObjectProperty)
    UGameplayAbility* GameplayAbility; // 0x418 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_420[0x20]; // 0x420 (Size: 0x20, Type: PaddingProperty)

protected:
    void Close(); // 0x107f7904 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    AJamPlayspace* GetPlayspace() const; // 0x107f8728 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void HandleOnJamLoopStopped(const FJamEvent_JamLoopStopped Payload); // 0x107f874c (Index: 0x2, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UJamGlobalControlsWidget) == 0x440, "Size mismatch for UJamGlobalControlsWidget");
static_assert(offsetof(UJamGlobalControlsWidget, Button_Close) == 0x408, "Offset mismatch for UJamGlobalControlsWidget::Button_Close");
static_assert(offsetof(UJamGlobalControlsWidget, JamPlayspace) == 0x410, "Offset mismatch for UJamGlobalControlsWidget::JamPlayspace");
static_assert(offsetof(UJamGlobalControlsWidget, GameplayAbility) == 0x418, "Offset mismatch for UJamGlobalControlsWidget::GameplayAbility");

// Size: 0x1c8 (Inherited: 0x250, Single: 0xffffff78)
class UJamOnOffSwitchComponent : public UPlayerStateComponent
{
public:
    FScalableFloat bEnableJam; // 0xb8 (Size: 0x28, Type: StructProperty)
    UClass* JamBlockerEffect; // 0xe0 (Size: 0x8, Type: ClassProperty)
    FActiveGameplayEffectHandle JamBlockerEffectHandle; // 0xe8 (Size: 0x8, Type: StructProperty)
    FGameplayEventListenerHandle GamePhaseUpdatedEventHandle; // 0xf0 (Size: 0x1c, Type: StructProperty)
    FGameplayEventListenerHandle GamePhaseStepUpdatedEventHandle; // 0x10c (Size: 0x1c, Type: StructProperty)
    FGlobalMemoryRequestHandle GlobalMemoryRequestHandle; // 0x128 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_130[0x98]; // 0x130 (Size: 0x98, Type: PaddingProperty)

public:
    static bool ShouldApplyJamOnSplitscreenLogic(UObject*& WorldContextObject, APlayerController*& ReferenceController); // 0x107f9c10 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable)

protected:
    void OnMutatorUpdated(); // 0x107f9094 (Index: 0x0, Flags: Final|Native|Protected)
    void OnPlayerStatePawnSet(APlayerState*& Player, APawn*& NewPawn, APawn*& OldPawn); // 0x107f9594 (Index: 0x1, Flags: Final|Native|Protected)
    void OnStasisModeChanged(AFortPlayerPawn*& PlayerPawn, EFortPawnStasisMode& NewStasisMode); // 0x107f988c (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UJamOnOffSwitchComponent) == 0x1c8, "Size mismatch for UJamOnOffSwitchComponent");
static_assert(offsetof(UJamOnOffSwitchComponent, bEnableJam) == 0xb8, "Offset mismatch for UJamOnOffSwitchComponent::bEnableJam");
static_assert(offsetof(UJamOnOffSwitchComponent, JamBlockerEffect) == 0xe0, "Offset mismatch for UJamOnOffSwitchComponent::JamBlockerEffect");
static_assert(offsetof(UJamOnOffSwitchComponent, JamBlockerEffectHandle) == 0xe8, "Offset mismatch for UJamOnOffSwitchComponent::JamBlockerEffectHandle");
static_assert(offsetof(UJamOnOffSwitchComponent, GamePhaseUpdatedEventHandle) == 0xf0, "Offset mismatch for UJamOnOffSwitchComponent::GamePhaseUpdatedEventHandle");
static_assert(offsetof(UJamOnOffSwitchComponent, GamePhaseStepUpdatedEventHandle) == 0x10c, "Offset mismatch for UJamOnOffSwitchComponent::GamePhaseStepUpdatedEventHandle");
static_assert(offsetof(UJamOnOffSwitchComponent, GlobalMemoryRequestHandle) == 0x128, "Offset mismatch for UJamOnOffSwitchComponent::GlobalMemoryRequestHandle");

// Size: 0xe0 (Inherited: 0x250, Single: 0xfffffe90)
class UJamPlayerPawnComponent : public UPawnComponent
{
public:
    uint8_t Pad_b8[0x8]; // 0xb8 (Size: 0x8, Type: PaddingProperty)
    FGameplayTagContainer AdditionalTags; // 0xc0 (Size: 0x20, Type: StructProperty)

public:
    APawn* GetPawnOfClass(UClass*& PawnType, bool& bMatchChildTypes); // 0x107f8370 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UJamPlayerPawnComponent) == 0xe0, "Size mismatch for UJamPlayerPawnComponent");
static_assert(offsetof(UJamPlayerPawnComponent, AdditionalTags) == 0xc0, "Offset mismatch for UJamPlayerPawnComponent::AdditionalTags");

// Size: 0x100 (Inherited: 0x250, Single: 0xfffffeb0)
class UJamQuestComponent : public UPlayspaceComponent
{
public:
};

static_assert(sizeof(UJamQuestComponent) == 0x100, "Size mismatch for UJamQuestComponent");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UJamSystemBPFL : public UBlueprintFunctionLibrary
{
public:

public:
    static bool IsLoopTypeUsableByEmote(EFMJamLoopType& const LoopType, AFortPlayerController*& const PlayerController); // 0x107f8870 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UJamSystemBPFL) == 0x28, "Size mismatch for UJamSystemBPFL");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UJamSystemEmoteBPFL : public UBlueprintFunctionLibrary
{
public:

public:
    static void GetEmoteActionBinding(FString& EmoteTemplateID, FEmoteActionBinding& OutCreatedEmote); // 0x107f7cd0 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsJamDebugDisplayEnabled(); // 0x107f8854 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UJamSystemEmoteBPFL) == 0x28, "Size mismatch for UJamSystemEmoteBPFL");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry
{
    uint8_t LoopType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t MultiEmoteIndex; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry) == 0x8, "Size mismatch for FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry");
static_assert(offsetof(FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry, LoopType) == 0x0, "Offset mismatch for FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry::LoopType");
static_assert(offsetof(FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry, MultiEmoteIndex) == 0x4, "Offset mismatch for FJamControllerComponent_LoopOptions_TypeToIndexMappingEntry::MultiEmoteIndex");

