/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DynamicBacchusHUDCreativeComponentsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DynamicBacchusHUD.h"
#include "GameplayTags.h"

// Size: 0x100 (Inherited: 0x1b8, Single: 0xffffff48)
class UDynamicBacchusHUDDirectorComponent_PlayerInfoOverride : public UDynamicBacchusHUDDirectorComponent
{
public:
    FGameplayTagContainer LocalPlayerInfoTags; // 0xd8 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_f8[0x8]; // 0xf8 (Size: 0x8, Type: PaddingProperty)

private:
    void HandleHUDElementVisibilityRefreshed(); // 0x11ee0fac (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UDynamicBacchusHUDDirectorComponent_PlayerInfoOverride) == 0x100, "Size mismatch for UDynamicBacchusHUDDirectorComponent_PlayerInfoOverride");
static_assert(offsetof(UDynamicBacchusHUDDirectorComponent_PlayerInfoOverride, LocalPlayerInfoTags) == 0xd8, "Offset mismatch for UDynamicBacchusHUDDirectorComponent_PlayerInfoOverride::LocalPlayerInfoTags");

