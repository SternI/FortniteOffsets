/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteQuest
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "ModularGameplay.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "PlayspaceSystem.h"
#include "NetCore.h"
#include "GameplayTags.h"
#include "DataRegistry.h"
#include "GameplayAbilities.h"

// Size: 0xa8 (Inherited: 0x78, Single: 0x30)
class UFortCheatManager_Quests : public UChildCheatManager
{
public:

public:
    void CheckObjectiveStatUsage(); // 0x554e3c4 (Index: 0x0, Flags: Final|Exec|Native|Public)
    void CheckQuestProcessorLoads() const; // 0x554e3c4 (Index: 0x1, Flags: Final|Exec|Native|Public|Const)
    void CompleteAccoladesByDisplayName(FString& const DisplayNameSearchString); // 0xd7d6cf4 (Index: 0x2, Flags: Final|Exec|Native|Public)
    void CompleteAllQuestsByName(FString& QuestPartialName); // 0xa974244 (Index: 0x3, Flags: Final|RequiredAPI|Exec|Native|Public|HasOutParms)
    void CompleteAllSquadMemberQuestsByName(FString& QuestPartialName); // 0xa974244 (Index: 0x4, Flags: Final|Exec|Native|Public|HasOutParms)
    void CompleteQuestAndForceVictory(FString& QuestName); // 0xa974244 (Index: 0x5, Flags: Final|Exec|Native|Public|HasOutParms)
    void CompleteQuestObjective(FString& const ObjectiveName); // 0xd7d6cf4 (Index: 0x6, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Public)
    void DebugDistanceTraveled(EGameplayDebugState& const DebugState, float& const InDelay, bool& const bShowAll) const; // 0xefdc4c0 (Index: 0x7, Flags: Final|Exec|Native|Public|Const)
    void DebugGameplayEvents(EGameplayDebugState& const DebugState) const; // 0xcf8da58 (Index: 0x8, Flags: Final|Exec|Native|Public|Const)
    void DisableQuestStateLogging(); // 0xefdc778 (Index: 0x9, Flags: Final|Exec|Native|Public)
    void EnableQuestStateLogging(); // 0xefdc7b4 (Index: 0xa, Flags: Final|Exec|Native|Public)
    void ForceCompleteAccolades(float& TimerDelay, bool& bSkipAcknowledgements); // 0xefdc7f0 (Index: 0xb, Flags: Final|Exec|Native|Public)
    void GiveAthenaXpAtLocation(float& const XpAmount, FString& const DesiredPriority); // 0xefdc9d8 (Index: 0xc, Flags: Final|Exec|Native|Public)
    void GiveAthenaXpLegacy(float& const XpAmount); // 0xefdcda8 (Index: 0xd, Flags: Final|Exec|Native|Public)
    void GrantAccoladeDeprecated(FString& AccoladeName, int32_t& const AccoladeIndex); // 0xde8be7c (Index: 0xe, Flags: Final|Exec|Native|Public)
    void GrantQuest(FString& const QuestName, EQuestParticipationScope& const QuestParticipationScope) const; // 0xefdced0 (Index: 0xf, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Public|Const)
    void GrantXp(float& const XpAmount, EXpRewardRestedXpUsage& const RestedXpUsage, int32_t& const FixedRestedXpAmount); // 0xefdd314 (Index: 0x10, Flags: Final|Exec|Native|Public)
    void ListActiveQuestContextTags(); // 0x554e3c4 (Index: 0x11, Flags: Final|Exec|Native|Public)
    void ListChallenges(FString& Filter) const; // 0xd7d6cf4 (Index: 0x12, Flags: Final|Exec|Native|Public|Const)
    void LogActiveTransientQuests(); // 0x554e3c4 (Index: 0x13, Flags: Final|Exec|Native|Public)
    void LogCurrentQuests(); // 0x554e3c4 (Index: 0x14, Flags: Final|Exec|Native|Public)
    void LogGameplayConditionalLedger(); // 0x554e3c4 (Index: 0x15, Flags: Final|Exec|Native|Public)
    void LogPinnedQuests(); // 0x554e3c4 (Index: 0x16, Flags: Final|Exec|Native|Public)
    void LogQuestInfo(FString& QuestName); // 0xa63baa0 (Index: 0x17, Flags: Final|Exec|Native|Public)
    void LogQuestManagerState(EQuestParticipationScope& const ManagerScope); // 0xcf8da58 (Index: 0x18, Flags: Final|Exec|Native|Public)
    void LogRebootData(); // 0x554e3c4 (Index: 0x19, Flags: Final|Exec|Native|Public)
    void LogSquadSharedQuestData() const; // 0x554e3c4 (Index: 0x1a, Flags: Final|Exec|Native|Public|Const)
    void LogTrackedQuests(); // 0x554e3c4 (Index: 0x1b, Flags: Final|Exec|Native|Public)
    void LogWorldReactions(); // 0x554e3c4 (Index: 0x1c, Flags: Final|Exec|Native|Public)
    void LogWorldStats(); // 0x554e3c4 (Index: 0x1d, Flags: Final|Exec|Native|Public)
    void PrintQuestMemory(); // 0x554e3c4 (Index: 0x1f, Flags: Final|Exec|Native|Public)
    void ProgressAllQuestsByName(FString& QuestPartialName, int32_t& Count); // 0xefdd6b4 (Index: 0x20, Flags: Final|Exec|Native|Public|HasOutParms)
    void ProgressQuestObjective(FString& const ObjectiveName, int32_t& const Count); // 0xcf8ee68 (Index: 0x21, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Public)
    void QueryRebootData(); // 0x554e3c4 (Index: 0x22, Flags: Final|Exec|Native|Public)
    void SendQuestEvent(FName& Type, FString& TargetTag, FString& SourceTag, FString& ContextTag, int32_t& Count); // 0xefdd998 (Index: 0x23, Flags: Final|Exec|Native|Public|HasOutParms)
    void SetWorldStatCount(FString& WorldStatName, uint32_t& const NewCount); // 0xefddebc (Index: 0x24, Flags: Final|Exec|Native|Public)
    void TeleportToBountyTarget(); // 0x554e3c4 (Index: 0x25, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Public)
    void TestHashingForQuests(); // 0x554e3c4 (Index: 0x26, Flags: Final|Exec|Native|Public)
    void TrackQuest(FString& QuestName, int32_t& TrackedIndex); // 0xcf8ee68 (Index: 0x27, Flags: Final|BlueprintCosmetic|Exec|Native|Public)
    void TriggerGameplayConditional(FString& GameplayConditionalDebugName); // 0xa63baa0 (Index: 0x28, Flags: Final|Exec|Native|Public)
    void TriggerWorldReactions(FString& RowName); // 0xa63baa0 (Index: 0x29, Flags: Final|Exec|Native|Public)
    void UntrackQuest(FString& QuestName); // 0xd7d6cf4 (Index: 0x2a, Flags: Final|BlueprintCosmetic|Exec|Native|Public)

private:
    void OnXPEvent(const FXPEventInfo XPEvent); // 0xefdd5cc (Index: 0x1e, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UFortCheatManager_Quests) == 0xa8, "Size mismatch for UFortCheatManager_Quests");

// Size: 0x130 (Inherited: 0x308, Single: 0xfffffe28)
class UFortGameStateComponent_MilestoneQuests : public UFortGameStateComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    FDataRegistryType DataRegistryType_SeasonalMilestoneQuests; // 0xd0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_d4[0x5c]; // 0xd4 (Size: 0x5c, Type: PaddingProperty)

protected:
    void HandlePlaylistDataReady(AFortGameStateAthena*& GameState, UFortPlaylist*& const Playlist, const FGameplayTagContainer GameplayTags); // 0xefde948 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UFortGameStateComponent_MilestoneQuests) == 0x130, "Size mismatch for UFortGameStateComponent_MilestoneQuests");
static_assert(offsetof(UFortGameStateComponent_MilestoneQuests, DataRegistryType_SeasonalMilestoneQuests) == 0xd0, "Offset mismatch for UFortGameStateComponent_MilestoneQuests::DataRegistryType_SeasonalMilestoneQuests");

// Size: 0x110 (Inherited: 0x308, Single: 0xfffffe08)
class UFortPlayerStateComponent_MilestoneQuests : public UFortPlayerStateComponent
{
public:
};

static_assert(sizeof(UFortPlayerStateComponent_MilestoneQuests) == 0x110, "Size mismatch for UFortPlayerStateComponent_MilestoneQuests");

// Size: 0x78 (Inherited: 0xa0, Single: 0xffffffd8)
class UFortQuestDefinitionComponent_Accolade : public UFortQuestDefinitionComponent
{
public:
};

static_assert(sizeof(UFortQuestDefinitionComponent_Accolade) == 0x78, "Size mismatch for UFortQuestDefinitionComponent_Accolade");

// Size: 0x78 (Inherited: 0xa0, Single: 0xffffffd8)
class UFortQuestDefinitionComponent_Conditionals : public UFortQuestDefinitionComponent
{
public:
};

static_assert(sizeof(UFortQuestDefinitionComponent_Conditionals) == 0x78, "Size mismatch for UFortQuestDefinitionComponent_Conditionals");

// Size: 0x78 (Inherited: 0xa0, Single: 0xffffffd8)
class UFortQuestDefinitionComponent_InitialProgress : public UFortQuestDefinitionComponent
{
public:
};

static_assert(sizeof(UFortQuestDefinitionComponent_InitialProgress) == 0x78, "Size mismatch for UFortQuestDefinitionComponent_InitialProgress");

// Size: 0x78 (Inherited: 0xa0, Single: 0xffffffd8)
class UFortQuestDefinitionComponent_MilestoneQuest : public UFortQuestDefinitionComponent
{
public:
};

static_assert(sizeof(UFortQuestDefinitionComponent_MilestoneQuest) == 0x78, "Size mismatch for UFortQuestDefinitionComponent_MilestoneQuest");

// Size: 0x78 (Inherited: 0x118, Single: 0xffffff60)
class UFortQuestDefinitionComponent_ProductCompatibilityInjector_GameModeRanked : public UFortQuestDefinitionComponent_ProductCompatibilityInjector
{
public:
};

static_assert(sizeof(UFortQuestDefinitionComponent_ProductCompatibilityInjector_GameModeRanked) == 0x78, "Size mismatch for UFortQuestDefinitionComponent_ProductCompatibilityInjector_GameModeRanked");

// Size: 0x78 (Inherited: 0x118, Single: 0xffffff60)
class UFortQuestDefinitionComponent_ProductCompatibilityInjector_IslandMetadata : public UFortQuestDefinitionComponent_ProductCompatibilityInjector
{
public:
};

static_assert(sizeof(UFortQuestDefinitionComponent_ProductCompatibilityInjector_IslandMetadata) == 0x78, "Size mismatch for UFortQuestDefinitionComponent_ProductCompatibilityInjector_IslandMetadata");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UFortQuestItemComponent_Accolade : public UFortQuestItemComponent
{
public:
};

static_assert(sizeof(UFortQuestItemComponent_Accolade) == 0x30, "Size mismatch for UFortQuestItemComponent_Accolade");

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class UFortQuestItemComponent_Conditionals : public UFortQuestItemComponent
{
public:
};

static_assert(sizeof(UFortQuestItemComponent_Conditionals) == 0x80, "Size mismatch for UFortQuestItemComponent_Conditionals");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UFortQuestItemComponent_InitialProgress : public UFortQuestItemComponent
{
public:
};

static_assert(sizeof(UFortQuestItemComponent_InitialProgress) == 0x30, "Size mismatch for UFortQuestItemComponent_InitialProgress");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
class UFortQuestItemComponent_MilestoneQuest : public UFortQuestItemComponent
{
public:
};

static_assert(sizeof(UFortQuestItemComponent_MilestoneQuest) == 0x38, "Size mismatch for UFortQuestItemComponent_MilestoneQuest");

// Size: 0x440 (Inherited: 0x618, Single: 0xfffffe28)
class AFortReactionGrantVolume : public AGameplayVolume
{
public:
    UOverlapComponent* OverlapComponent; // 0x348 (Size: 0x8, Type: ObjectProperty)
    TArray<FInstancedStruct> ReactionsToGrantOnEnter; // 0x350 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> ReactionsToGrantOnExit; // 0x360 (Size: 0x10, Type: ArrayProperty)
    bool bUseQuestRequirement; // 0x370 (Size: 0x1, Type: BoolProperty)
    bool bTriggerExitOnObjectiveCompletion; // 0x371 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_372[0x6]; // 0x372 (Size: 0x6, Type: PaddingProperty)
    TSoftObjectPtr<UFortQuestItemDefinition*> RequiredQuest; // 0x378 (Size: 0x20, Type: SoftObjectProperty)
    FName RequiredObjective; // 0x398 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_39c[0xa4]; // 0x39c (Size: 0xa4, Type: PaddingProperty)
};

static_assert(sizeof(AFortReactionGrantVolume) == 0x440, "Size mismatch for AFortReactionGrantVolume");
static_assert(offsetof(AFortReactionGrantVolume, OverlapComponent) == 0x348, "Offset mismatch for AFortReactionGrantVolume::OverlapComponent");
static_assert(offsetof(AFortReactionGrantVolume, ReactionsToGrantOnEnter) == 0x350, "Offset mismatch for AFortReactionGrantVolume::ReactionsToGrantOnEnter");
static_assert(offsetof(AFortReactionGrantVolume, ReactionsToGrantOnExit) == 0x360, "Offset mismatch for AFortReactionGrantVolume::ReactionsToGrantOnExit");
static_assert(offsetof(AFortReactionGrantVolume, bUseQuestRequirement) == 0x370, "Offset mismatch for AFortReactionGrantVolume::bUseQuestRequirement");
static_assert(offsetof(AFortReactionGrantVolume, bTriggerExitOnObjectiveCompletion) == 0x371, "Offset mismatch for AFortReactionGrantVolume::bTriggerExitOnObjectiveCompletion");
static_assert(offsetof(AFortReactionGrantVolume, RequiredQuest) == 0x378, "Offset mismatch for AFortReactionGrantVolume::RequiredQuest");
static_assert(offsetof(AFortReactionGrantVolume, RequiredObjective) == 0x398, "Offset mismatch for AFortReactionGrantVolume::RequiredObjective");

// Size: 0x878 (Inherited: 0x928, Single: 0xffffff50)
class AFortQuestManagerVolume : public AFortOverlapTrackingVolume
{
public:
    uint8_t Pad_370[0xe0]; // 0x370 (Size: 0xe0, Type: PaddingProperty)
    TArray<TSoftObjectPtr<UFortQuestItemDefinition*>> QuestsToGrantOnStart; // 0x450 (Size: 0x10, Type: ArrayProperty)
    FFortGrantedQuestDataArray GrantedQuestDataArray; // 0x460 (Size: 0x128, Type: StructProperty)
    FUpdatedQuestObjectiveDataArray UpdatedQuestObjectivesArray; // 0x588 (Size: 0x148, Type: StructProperty)
    UFortQuestVolumeComponent_QueuedReactions* ReactionComponent; // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    FTrackingVolumeParticipantList VolumeParticipants; // 0x6d8 (Size: 0x178, Type: StructProperty)
    TArray<FUniqueNetIdRepl> PendingUsers; // 0x850 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_860[0x18]; // 0x860 (Size: 0x18, Type: PaddingProperty)

private:
    void OnRep_VolumeParticipants(); // 0xefe5e30 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(AFortQuestManagerVolume) == 0x878, "Size mismatch for AFortQuestManagerVolume");
static_assert(offsetof(AFortQuestManagerVolume, QuestsToGrantOnStart) == 0x450, "Offset mismatch for AFortQuestManagerVolume::QuestsToGrantOnStart");
static_assert(offsetof(AFortQuestManagerVolume, GrantedQuestDataArray) == 0x460, "Offset mismatch for AFortQuestManagerVolume::GrantedQuestDataArray");
static_assert(offsetof(AFortQuestManagerVolume, UpdatedQuestObjectivesArray) == 0x588, "Offset mismatch for AFortQuestManagerVolume::UpdatedQuestObjectivesArray");
static_assert(offsetof(AFortQuestManagerVolume, ReactionComponent) == 0x6d0, "Offset mismatch for AFortQuestManagerVolume::ReactionComponent");
static_assert(offsetof(AFortQuestManagerVolume, VolumeParticipants) == 0x6d8, "Offset mismatch for AFortQuestManagerVolume::VolumeParticipants");
static_assert(offsetof(AFortQuestManagerVolume, PendingUsers) == 0x850, "Offset mismatch for AFortQuestManagerVolume::PendingUsers");

// Size: 0x270 (Inherited: 0x630, Single: 0xfffffc40)
class UFortQuestVolumeComponent_QueuedReactions : public UFortGameFrameworkComponent_QueuedReactionsManager
{
public:
};

static_assert(sizeof(UFortQuestVolumeComponent_QueuedReactions) == 0x270, "Size mismatch for UFortQuestVolumeComponent_QueuedReactions");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FMilestoneQuestTableRow : FTableRowBase
{
    TScriptInterface<Class> Quest; // 0x8 (Size: 0x10, Type: InterfaceProperty)
};

static_assert(sizeof(FMilestoneQuestTableRow) == 0x18, "Size mismatch for FMilestoneQuestTableRow");
static_assert(offsetof(FMilestoneQuestTableRow, Quest) == 0x8, "Offset mismatch for FMilestoneQuestTableRow::Quest");

// Size: 0x10 (Inherited: 0x1, Single: 0xf)
struct FObjectiveExtension_Conditionals : FObjectiveExtensionData
{
    TArray<FInstancedStruct> Conditionals; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FObjectiveExtension_Conditionals) == 0x10, "Size mismatch for FObjectiveExtension_Conditionals");
static_assert(offsetof(FObjectiveExtension_Conditionals, Conditionals) == 0x0, "Offset mismatch for FObjectiveExtension_Conditionals::Conditionals");

// Size: 0x10 (Inherited: 0x1, Single: 0xf)
struct FObjectiveExtension_InitialProgress : FObjectiveExtensionData
{
    FInstancedStruct InitialProgress; // 0x0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FObjectiveExtension_InitialProgress) == 0x10, "Size mismatch for FObjectiveExtension_InitialProgress");
static_assert(offsetof(FObjectiveExtension_InitialProgress, InitialProgress) == 0x0, "Offset mismatch for FObjectiveExtension_InitialProgress::InitialProgress");

// Size: 0x20 (Inherited: 0x20, Single: 0x0)
struct FObjectiveUpdateGate_ZoneDifficulty : FGateType_ObjectiveUpdate_Base
{
    FInt32Range RequiredDifficulty; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FObjectiveUpdateGate_ZoneDifficulty) == 0x20, "Size mismatch for FObjectiveUpdateGate_ZoneDifficulty");
static_assert(offsetof(FObjectiveUpdateGate_ZoneDifficulty, RequiredDifficulty) == 0x10, "Offset mismatch for FObjectiveUpdateGate_ZoneDifficulty::RequiredDifficulty");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FReactionCondition
{
};

static_assert(sizeof(FReactionCondition) == 0x8, "Size mismatch for FReactionCondition");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FReactionConditionalGrant
{
    TArray<FInstancedStruct> ReactionsToGrant; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FInstancedStruct Condition; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FReactionConditionalGrant) == 0x20, "Size mismatch for FReactionConditionalGrant");
static_assert(offsetof(FReactionConditionalGrant, ReactionsToGrant) == 0x0, "Offset mismatch for FReactionConditionalGrant::ReactionsToGrant");
static_assert(offsetof(FReactionConditionalGrant, Condition) == 0x10, "Offset mismatch for FReactionConditionalGrant::Condition");

// Size: 0x20 (Inherited: 0x8, Single: 0x18)
struct FEventReaction_Conditional : FEventReactionBase
{
    uint8_t GrantType; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    TArray<FReactionConditionalGrant> ConditionalReactions; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FEventReaction_Conditional) == 0x20, "Size mismatch for FEventReaction_Conditional");
static_assert(offsetof(FEventReaction_Conditional, GrantType) == 0x8, "Offset mismatch for FEventReaction_Conditional::GrantType");
static_assert(offsetof(FEventReaction_Conditional, ConditionalReactions) == 0x10, "Offset mismatch for FEventReaction_Conditional::ConditionalReactions");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FEventReactionCumulativeRollEntry
{
    int32_t RollChance; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FInstancedStruct> Reactions; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FEventReactionCumulativeRollEntry) == 0x18, "Size mismatch for FEventReactionCumulativeRollEntry");
static_assert(offsetof(FEventReactionCumulativeRollEntry, RollChance) == 0x0, "Offset mismatch for FEventReactionCumulativeRollEntry::RollChance");
static_assert(offsetof(FEventReactionCumulativeRollEntry, Reactions) == 0x8, "Offset mismatch for FEventReactionCumulativeRollEntry::Reactions");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FEventReaction_CumulativeRoll : FEventReactionBase
{
    TArray<FEventReactionCumulativeRollEntry> CumulativeRollEntries; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FEventReaction_CumulativeRoll) == 0x18, "Size mismatch for FEventReaction_CumulativeRoll");
static_assert(offsetof(FEventReaction_CumulativeRoll, CumulativeRollEntries) == 0x8, "Offset mismatch for FEventReaction_CumulativeRoll::CumulativeRollEntries");

// Size: 0x90 (Inherited: 0x18, Single: 0x78)
struct FFortEventReaction_SpawnLoot : FFortEventReaction_SideEffect
{
    FVector RewardOffset; // 0x8 (Size: 0x18, Type: StructProperty)
    FVector RewardDirection; // 0x20 (Size: 0x18, Type: StructProperty)
    FScalableFloat RewardConeAngle; // 0x38 (Size: 0x28, Type: StructProperty)
    FScalableFloat RewardFlingMagnitude; // 0x60 (Size: 0x28, Type: StructProperty)
    FName LootTier; // 0x88 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortEventReaction_SpawnLoot) == 0x90, "Size mismatch for FFortEventReaction_SpawnLoot");
static_assert(offsetof(FFortEventReaction_SpawnLoot, RewardOffset) == 0x8, "Offset mismatch for FFortEventReaction_SpawnLoot::RewardOffset");
static_assert(offsetof(FFortEventReaction_SpawnLoot, RewardDirection) == 0x20, "Offset mismatch for FFortEventReaction_SpawnLoot::RewardDirection");
static_assert(offsetof(FFortEventReaction_SpawnLoot, RewardConeAngle) == 0x38, "Offset mismatch for FFortEventReaction_SpawnLoot::RewardConeAngle");
static_assert(offsetof(FFortEventReaction_SpawnLoot, RewardFlingMagnitude) == 0x60, "Offset mismatch for FFortEventReaction_SpawnLoot::RewardFlingMagnitude");
static_assert(offsetof(FFortEventReaction_SpawnLoot, LootTier) == 0x88, "Offset mismatch for FFortEventReaction_SpawnLoot::LootTier");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FReactionCondition_AllConditionsPass : FReactionCondition
{
    TArray<FInstancedStruct> Conditions; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FReactionCondition_AllConditionsPass) == 0x18, "Size mismatch for FReactionCondition_AllConditionsPass");
static_assert(offsetof(FReactionCondition_AllConditionsPass, Conditions) == 0x8, "Offset mismatch for FReactionCondition_AllConditionsPass::Conditions");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FReactionCondition_AnyConditionsPass : FReactionCondition
{
    TArray<FInstancedStruct> Conditions; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FReactionCondition_AnyConditionsPass) == 0x18, "Size mismatch for FReactionCondition_AnyConditionsPass");
static_assert(offsetof(FReactionCondition_AnyConditionsPass, Conditions) == 0x8, "Offset mismatch for FReactionCondition_AnyConditionsPass::Conditions");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FReactionCondition_NoConditionsPass : FReactionCondition
{
    TArray<FInstancedStruct> Conditions; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FReactionCondition_NoConditionsPass) == 0x18, "Size mismatch for FReactionCondition_NoConditionsPass");
static_assert(offsetof(FReactionCondition_NoConditionsPass, Conditions) == 0x8, "Offset mismatch for FReactionCondition_NoConditionsPass::Conditions");

// Size: 0x50 (Inherited: 0x8, Single: 0x48)
struct FReactionCondition_GameplayTagQuery : FReactionCondition
{
    FGameplayTagQuery TargetQuery; // 0x8 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(FReactionCondition_GameplayTagQuery) == 0x50, "Size mismatch for FReactionCondition_GameplayTagQuery");
static_assert(offsetof(FReactionCondition_GameplayTagQuery, TargetQuery) == 0x8, "Offset mismatch for FReactionCondition_GameplayTagQuery::TargetQuery");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FReactionCondition_HasRequiredToken : FReactionCondition
{
    TSoftObjectPtr<UFortTokenType*> RequiredTokenDefinition; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FReactionCondition_HasRequiredToken) == 0x28, "Size mismatch for FReactionCondition_HasRequiredToken");
static_assert(offsetof(FReactionCondition_HasRequiredToken, RequiredTokenDefinition) == 0x8, "Offset mismatch for FReactionCondition_HasRequiredToken::RequiredTokenDefinition");

// Size: 0x78 (Inherited: 0x18, Single: 0x60)
struct FFortEventReaction_GrantEmote : FFortEventReaction_SideEffect
{
    FExternalEmoteCategory EmoteToGrant; // 0x8 (Size: 0x70, Type: StructProperty)
};

static_assert(sizeof(FFortEventReaction_GrantEmote) == 0x78, "Size mismatch for FFortEventReaction_GrantEmote");
static_assert(offsetof(FFortEventReaction_GrantEmote, EmoteToGrant) == 0x8, "Offset mismatch for FFortEventReaction_GrantEmote::EmoteToGrant");

// Size: 0x10 (Inherited: 0x18, Single: 0xfffffff8)
struct FFortEventReaction_RemoveEmote : FFortEventReaction_SideEffect
{
    FName EmoteCategoryToRemove; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortEventReaction_RemoveEmote) == 0x10, "Size mismatch for FFortEventReaction_RemoveEmote");
static_assert(offsetof(FFortEventReaction_RemoveEmote, EmoteCategoryToRemove) == 0x8, "Offset mismatch for FFortEventReaction_RemoveEmote::EmoteCategoryToRemove");

// Size: 0x58 (Inherited: 0xc, Single: 0x4c)
struct FTrackingVolumeParticipant : FFastArraySerializerItem
{
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FUniqueNetIdRepl UserId; // 0x10 (Size: 0x30, Type: StructProperty)
    TWeakObjectPtr<AFortQuestManagerVolume*> TrackingVolume; // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<APlayerState*> PlayerStateCached; // 0x48 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AController*> ControllerCached; // 0x50 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FTrackingVolumeParticipant) == 0x58, "Size mismatch for FTrackingVolumeParticipant");
static_assert(offsetof(FTrackingVolumeParticipant, UserId) == 0x10, "Offset mismatch for FTrackingVolumeParticipant::UserId");
static_assert(offsetof(FTrackingVolumeParticipant, TrackingVolume) == 0x40, "Offset mismatch for FTrackingVolumeParticipant::TrackingVolume");
static_assert(offsetof(FTrackingVolumeParticipant, PlayerStateCached) == 0x48, "Offset mismatch for FTrackingVolumeParticipant::PlayerStateCached");
static_assert(offsetof(FTrackingVolumeParticipant, ControllerCached) == 0x50, "Offset mismatch for FTrackingVolumeParticipant::ControllerCached");

// Size: 0x178 (Inherited: 0x108, Single: 0x70)
struct FTrackingVolumeParticipantList : FFastArraySerializer
{
    TArray<FTrackingVolumeParticipant> TrackingVolumeParticipants; // 0x108 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_118[0x58]; // 0x118 (Size: 0x58, Type: PaddingProperty)
    AFortQuestManagerVolume* TrackingVolume; // 0x170 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FTrackingVolumeParticipantList) == 0x178, "Size mismatch for FTrackingVolumeParticipantList");
static_assert(offsetof(FTrackingVolumeParticipantList, TrackingVolumeParticipants) == 0x108, "Offset mismatch for FTrackingVolumeParticipantList::TrackingVolumeParticipants");
static_assert(offsetof(FTrackingVolumeParticipantList, TrackingVolume) == 0x170, "Offset mismatch for FTrackingVolumeParticipantList::TrackingVolume");

