/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicCMSUIFramework
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CommonUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "CommonUILegacy.h"
#include "Engine.h"
#include "SlateCore.h"

// Size: 0x460 (Inherited: 0x798, Single: 0xfffffcc8)
class UEpicCMSImage : public UCommonLazyImage
{
public:
    uint8_t OnImageLoadingComplete[0x10]; // 0x370 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnExternalMediaChanged[0x10]; // 0x380 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bMatchImageSize; // 0x390 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_391[0xf]; // 0x391 (Size: 0xf, Type: PaddingProperty)
    FSlateBrush LoadingFailFallback; // 0x3a0 (Size: 0xb0, Type: StructProperty)
    UTexture2D* ExternalMedia; // 0x450 (Size: 0x8, Type: ObjectProperty)
    bool bDownloadingExternalMedia; // 0x458 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_459[0x7]; // 0x459 (Size: 0x7, Type: PaddingProperty)

public:
    void SetMediaURL(FString& MediaUrl); // 0x5fa27e0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UEpicCMSImage) == 0x460, "Size mismatch for UEpicCMSImage");
static_assert(offsetof(UEpicCMSImage, OnImageLoadingComplete) == 0x370, "Offset mismatch for UEpicCMSImage::OnImageLoadingComplete");
static_assert(offsetof(UEpicCMSImage, OnExternalMediaChanged) == 0x380, "Offset mismatch for UEpicCMSImage::OnExternalMediaChanged");
static_assert(offsetof(UEpicCMSImage, bMatchImageSize) == 0x390, "Offset mismatch for UEpicCMSImage::bMatchImageSize");
static_assert(offsetof(UEpicCMSImage, LoadingFailFallback) == 0x3a0, "Offset mismatch for UEpicCMSImage::LoadingFailFallback");
static_assert(offsetof(UEpicCMSImage, ExternalMedia) == 0x450, "Offset mismatch for UEpicCMSImage::ExternalMedia");
static_assert(offsetof(UEpicCMSImage, bDownloadingExternalMedia) == 0x458, "Offset mismatch for UEpicCMSImage::bDownloadingExternalMedia");

// Size: 0x318 (Inherited: 0x458, Single: 0xfffffec0)
class UEpicCMSLayoutBase : public UUserWidget
{
public:
    TArray<FSlotDescription> CarouselSlotDescriptions; // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    UClass* CarouselClass; // 0x2c0 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_2c8[0x50]; // 0x2c8 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UEpicCMSLayoutBase) == 0x318, "Size mismatch for UEpicCMSLayoutBase");
static_assert(offsetof(UEpicCMSLayoutBase, CarouselSlotDescriptions) == 0x2b0, "Offset mismatch for UEpicCMSLayoutBase::CarouselSlotDescriptions");
static_assert(offsetof(UEpicCMSLayoutBase, CarouselClass) == 0x2c0, "Offset mismatch for UEpicCMSLayoutBase::CarouselClass");

// Size: 0xa0 (Inherited: 0x28, Single: 0x78)
class UEpicCMSManager : public UObject
{
public:
};

static_assert(sizeof(UEpicCMSManager) == 0xa0, "Size mismatch for UEpicCMSManager");

// Size: 0x5b8 (Inherited: 0x1078, Single: 0xfffff540)
class UEpicCMSScreenBase : public UCommonActivatablePanelLegacy
{
public:
    FString TileSetFieldName; // 0x540 (Size: 0x10, Type: StrProperty)
    TSoftObjectPtr<UDataTable*> TileTypeToTileClassDataTable; // 0x550 (Size: 0x20, Type: SoftObjectProperty)
    TSoftClassPtr LayoutErrorClass; // 0x570 (Size: 0x20, Type: SoftClassProperty)
    TSoftObjectPtr<UDataTable*> LayoutTypeToLayoutClassDataTable; // 0x590 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t Pad_5b0[0x8]; // 0x5b0 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UEpicCMSScreenBase) == 0x5b8, "Size mismatch for UEpicCMSScreenBase");
static_assert(offsetof(UEpicCMSScreenBase, TileSetFieldName) == 0x540, "Offset mismatch for UEpicCMSScreenBase::TileSetFieldName");
static_assert(offsetof(UEpicCMSScreenBase, TileTypeToTileClassDataTable) == 0x550, "Offset mismatch for UEpicCMSScreenBase::TileTypeToTileClassDataTable");
static_assert(offsetof(UEpicCMSScreenBase, LayoutErrorClass) == 0x570, "Offset mismatch for UEpicCMSScreenBase::LayoutErrorClass");
static_assert(offsetof(UEpicCMSScreenBase, LayoutTypeToLayoutClassDataTable) == 0x590, "Offset mismatch for UEpicCMSScreenBase::LayoutTypeToLayoutClassDataTable");

// Size: 0x2f0 (Inherited: 0x730, Single: 0xfffffbc0)
class UEpicCMSSimpleMessage : public UCommonUserWidget
{
public:
    UCommonTextBlock* TitleText; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* BodyText; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UEpicCMSImage* PrimaryImage; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UEpicCMSSimpleMessage) == 0x2f0, "Size mismatch for UEpicCMSSimpleMessage");
static_assert(offsetof(UEpicCMSSimpleMessage, TitleText) == 0x2d8, "Offset mismatch for UEpicCMSSimpleMessage::TitleText");
static_assert(offsetof(UEpicCMSSimpleMessage, BodyText) == 0x2e0, "Offset mismatch for UEpicCMSSimpleMessage::BodyText");
static_assert(offsetof(UEpicCMSSimpleMessage, PrimaryImage) == 0x2e8, "Offset mismatch for UEpicCMSSimpleMessage::PrimaryImage");

// Size: 0x1600 (Inherited: 0x30c0, Single: 0xffffe540)
class UEpicCMSTileBase : public UCommonButtonLegacy
{
public:
    uint8_t Pad_14f0[0x8]; // 0x14f0 (Size: 0x8, Type: PaddingProperty)
    UClass* DefaultTitleTextStyle; // 0x14f8 (Size: 0x8, Type: ClassProperty)
    UClass* FeaturedTitleTextStyle; // 0x1500 (Size: 0x8, Type: ClassProperty)
    FText Title; // 0x1508 (Size: 0x10, Type: TextProperty)
    FString Link; // 0x1518 (Size: 0x10, Type: StrProperty)
    bool bDownloadingExternalMedia; // 0x1528 (Size: 0x1, Type: BoolProperty)
    bool bRefreshingMcpCatalog; // 0x1529 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_152a[0x6]; // 0x152a (Size: 0x6, Type: PaddingProperty)
    UTexture2D* ExternalMedia; // 0x1530 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1538[0x18]; // 0x1538 (Size: 0x18, Type: PaddingProperty)
    UCommonLazyImage* LazyImage_Icon; // 0x1550 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* TitleTextBlock; // 0x1558 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* SubtitleTextBlock; // 0x1560 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* EyebrowTextBlock; // 0x1568 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1570[0x90]; // 0x1570 (Size: 0x90, Type: PaddingProperty)

protected:
    void Launch(); // 0xc0c7df8 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UEpicCMSTileBase) == 0x1600, "Size mismatch for UEpicCMSTileBase");
static_assert(offsetof(UEpicCMSTileBase, DefaultTitleTextStyle) == 0x14f8, "Offset mismatch for UEpicCMSTileBase::DefaultTitleTextStyle");
static_assert(offsetof(UEpicCMSTileBase, FeaturedTitleTextStyle) == 0x1500, "Offset mismatch for UEpicCMSTileBase::FeaturedTitleTextStyle");
static_assert(offsetof(UEpicCMSTileBase, Title) == 0x1508, "Offset mismatch for UEpicCMSTileBase::Title");
static_assert(offsetof(UEpicCMSTileBase, Link) == 0x1518, "Offset mismatch for UEpicCMSTileBase::Link");
static_assert(offsetof(UEpicCMSTileBase, bDownloadingExternalMedia) == 0x1528, "Offset mismatch for UEpicCMSTileBase::bDownloadingExternalMedia");
static_assert(offsetof(UEpicCMSTileBase, bRefreshingMcpCatalog) == 0x1529, "Offset mismatch for UEpicCMSTileBase::bRefreshingMcpCatalog");
static_assert(offsetof(UEpicCMSTileBase, ExternalMedia) == 0x1530, "Offset mismatch for UEpicCMSTileBase::ExternalMedia");
static_assert(offsetof(UEpicCMSTileBase, LazyImage_Icon) == 0x1550, "Offset mismatch for UEpicCMSTileBase::LazyImage_Icon");
static_assert(offsetof(UEpicCMSTileBase, TitleTextBlock) == 0x1558, "Offset mismatch for UEpicCMSTileBase::TitleTextBlock");
static_assert(offsetof(UEpicCMSTileBase, SubtitleTextBlock) == 0x1560, "Offset mismatch for UEpicCMSTileBase::SubtitleTextBlock");
static_assert(offsetof(UEpicCMSTileBase, EyebrowTextBlock) == 0x1568, "Offset mismatch for UEpicCMSTileBase::EyebrowTextBlock");

// Size: 0x300 (Inherited: 0x458, Single: 0xfffffea8)
class UEpicCMSTileCarousel : public UUserWidget
{
public:
    FSlateSound PreviousButtonSound; // 0x2b0 (Size: 0x18, Type: StructProperty)
    FSlateSound NextButtonSound; // 0x2c8 (Size: 0x18, Type: StructProperty)
    UCommonWidgetCarousel* Carousel; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UWidget* NextPageButton; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UWidget* PreviousPageButton; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    bool bShouldShowNavigationOnlyOnHover; // 0x2f8 (Size: 0x1, Type: BoolProperty)
    bool bInputActionsForPaging; // 0x2f9 (Size: 0x1, Type: BoolProperty)
    bool bIsShowingNavigation; // 0x2fa (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2fb[0x5]; // 0x2fb (Size: 0x5, Type: PaddingProperty)

public:
    void AddTilePage(UWidget*& TilePageWidget); // 0xc0c76e4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void BeginAutoScrolling(); // 0xc0c7d9c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)

protected:
    int32_t GetCurrentPageIndex() const; // 0xc0c7dd0 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void HandleTilePageAdded(UWidget*& TileWidget); // 0xa40b038 (Index: 0x3, Flags: Native|Event|Protected|BlueprintEvent)
    virtual void NavigationVisibilityChanged(bool& bShowNavigation); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    void NextPage(); // 0xc0c7e0c (Index: 0x5, Flags: Final|Native|Protected|BlueprintCallable)
    void PreviousPage(); // 0xc0c7e20 (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable)
    void SetCurrentPageByIndex(int32_t& const PageIndex); // 0xc0c7e34 (Index: 0x7, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UEpicCMSTileCarousel) == 0x300, "Size mismatch for UEpicCMSTileCarousel");
static_assert(offsetof(UEpicCMSTileCarousel, PreviousButtonSound) == 0x2b0, "Offset mismatch for UEpicCMSTileCarousel::PreviousButtonSound");
static_assert(offsetof(UEpicCMSTileCarousel, NextButtonSound) == 0x2c8, "Offset mismatch for UEpicCMSTileCarousel::NextButtonSound");
static_assert(offsetof(UEpicCMSTileCarousel, Carousel) == 0x2e0, "Offset mismatch for UEpicCMSTileCarousel::Carousel");
static_assert(offsetof(UEpicCMSTileCarousel, NextPageButton) == 0x2e8, "Offset mismatch for UEpicCMSTileCarousel::NextPageButton");
static_assert(offsetof(UEpicCMSTileCarousel, PreviousPageButton) == 0x2f0, "Offset mismatch for UEpicCMSTileCarousel::PreviousPageButton");
static_assert(offsetof(UEpicCMSTileCarousel, bShouldShowNavigationOnlyOnHover) == 0x2f8, "Offset mismatch for UEpicCMSTileCarousel::bShouldShowNavigationOnlyOnHover");
static_assert(offsetof(UEpicCMSTileCarousel, bInputActionsForPaging) == 0x2f9, "Offset mismatch for UEpicCMSTileCarousel::bInputActionsForPaging");
static_assert(offsetof(UEpicCMSTileCarousel, bIsShowingNavigation) == 0x2fa, "Offset mismatch for UEpicCMSTileCarousel::bIsShowingNavigation");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FEpicCMSTileTypeMapping : FTableRowBase
{
    TSoftClassPtr TileClass; // 0x8 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FEpicCMSTileTypeMapping) == 0x28, "Size mismatch for FEpicCMSTileTypeMapping");
static_assert(offsetof(FEpicCMSTileTypeMapping, TileClass) == 0x8, "Offset mismatch for FEpicCMSTileTypeMapping::TileClass");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FSlotDescription
{
    FName SlotName; // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t ColumnCount; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t RowCount; // 0x8 (Size: 0x4, Type: IntProperty)
    bool bUseFeaturedTextStyle; // 0xc (Size: 0x1, Type: BoolProperty)
    bool bEnableAutoScroll; // 0xd (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e[0x2]; // 0xe (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FSlotDescription) == 0x10, "Size mismatch for FSlotDescription");
static_assert(offsetof(FSlotDescription, SlotName) == 0x0, "Offset mismatch for FSlotDescription::SlotName");
static_assert(offsetof(FSlotDescription, ColumnCount) == 0x4, "Offset mismatch for FSlotDescription::ColumnCount");
static_assert(offsetof(FSlotDescription, RowCount) == 0x8, "Offset mismatch for FSlotDescription::RowCount");
static_assert(offsetof(FSlotDescription, bUseFeaturedTextStyle) == 0xc, "Offset mismatch for FSlotDescription::bUseFeaturedTextStyle");
static_assert(offsetof(FSlotDescription, bEnableAutoScroll) == 0xd, "Offset mismatch for FSlotDescription::bEnableAutoScroll");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FEpicCMSPage
{
};

static_assert(sizeof(FEpicCMSPage) == 0x70, "Size mismatch for FEpicCMSPage");

// Size: 0x28 (Inherited: 0x8, Single: 0x20)
struct FEpicCMSLayoutTypeMapping : FTableRowBase
{
    TSoftClassPtr LayoutType; // 0x8 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FEpicCMSLayoutTypeMapping) == 0x28, "Size mismatch for FEpicCMSLayoutTypeMapping");
static_assert(offsetof(FEpicCMSLayoutTypeMapping, LayoutType) == 0x8, "Offset mismatch for FEpicCMSLayoutTypeMapping::LayoutType");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FTileDefinition
{
    FString TypeString; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Title; // 0x10 (Size: 0x10, Type: StrProperty)
    FString Subtitle; // 0x20 (Size: 0x10, Type: StrProperty)
    FString Eyebrow; // 0x30 (Size: 0x10, Type: StrProperty)
    FString Link; // 0x40 (Size: 0x10, Type: StrProperty)
    FString GroupId; // 0x50 (Size: 0x10, Type: StrProperty)
    FDateTime Countdown; // 0x60 (Size: 0x8, Type: StructProperty)
    uint8_t CountdownType; // 0x68 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
    FString MediaUrl; // 0x70 (Size: 0x10, Type: StrProperty)
    bool IsVisible; // 0x80 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_81[0x7]; // 0x81 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FTileDefinition) == 0x88, "Size mismatch for FTileDefinition");
static_assert(offsetof(FTileDefinition, TypeString) == 0x0, "Offset mismatch for FTileDefinition::TypeString");
static_assert(offsetof(FTileDefinition, Title) == 0x10, "Offset mismatch for FTileDefinition::Title");
static_assert(offsetof(FTileDefinition, Subtitle) == 0x20, "Offset mismatch for FTileDefinition::Subtitle");
static_assert(offsetof(FTileDefinition, Eyebrow) == 0x30, "Offset mismatch for FTileDefinition::Eyebrow");
static_assert(offsetof(FTileDefinition, Link) == 0x40, "Offset mismatch for FTileDefinition::Link");
static_assert(offsetof(FTileDefinition, GroupId) == 0x50, "Offset mismatch for FTileDefinition::GroupId");
static_assert(offsetof(FTileDefinition, Countdown) == 0x60, "Offset mismatch for FTileDefinition::Countdown");
static_assert(offsetof(FTileDefinition, CountdownType) == 0x68, "Offset mismatch for FTileDefinition::CountdownType");
static_assert(offsetof(FTileDefinition, MediaUrl) == 0x70, "Offset mismatch for FTileDefinition::MediaUrl");
static_assert(offsetof(FTileDefinition, IsVisible) == 0x80, "Offset mismatch for FTileDefinition::IsVisible");

