/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_GameStreamRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "PlayspaceSystem.h"
#include "FortniteGame.h"

// Size: 0xc8 (Inherited: 0xe0, Single: 0xffffffe8)
class UCreativeGameStreamDeviceComponent : public UActorComponent
{
public:
    uint8_t OnTriggered; // 0xb8 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    uint8_t Pad_b9[0x3]; // 0xb9 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<UFortMinigameLogicComponent*> MinigameLogicComponent; // 0xbc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_c4[0x4]; // 0xc4 (Size: 0x4, Type: PaddingProperty)

public:
    void AddToEndGameQueue(); // 0x554e3c4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void CreativeGameStreamDeviceComponentSignature__DelegateSignature(UCreativeGameStreamDeviceComponent*& CreativeGameStreamDeviceComponent); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
    void Init(UFortMinigameLogicComponent*& InMinigameLogicComponent); // 0x6023a08 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    bool IsWithinPublishedPlayspace() const; // 0x4c4e47c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RemoveFromEndGameQueue(); // 0x554e3c4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

private:
    void OnMinigameStateChanged(AFortMinigame*& Minigame, EFortMinigameState& const NewMinigameState); // 0xa29d5e0 (Index: 0x4, Flags: Final|Native|Private)
};

static_assert(sizeof(UCreativeGameStreamDeviceComponent) == 0xc8, "Size mismatch for UCreativeGameStreamDeviceComponent");
static_assert(offsetof(UCreativeGameStreamDeviceComponent, OnTriggered) == 0xb8, "Offset mismatch for UCreativeGameStreamDeviceComponent::OnTriggered");
static_assert(offsetof(UCreativeGameStreamDeviceComponent, MinigameLogicComponent) == 0xbc, "Offset mismatch for UCreativeGameStreamDeviceComponent::MinigameLogicComponent");

// Size: 0xd0 (Inherited: 0x250, Single: 0xfffffe80)
class UCreativeGameStreamDeviceCoordinatorComponent : public UPlayspaceComponent
{
public:
    TArray<TWeakObjectPtr<UCreativeGameStreamDeviceComponent*>> EndGameCreativeGameStreamDeviceComponentQueue; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<AFortMinigame*> Minigame; // 0xc8 (Size: 0x8, Type: WeakObjectProperty)

private:
    void OnMinigameStateChanged(AFortMinigame*& InMinigame, EFortMinigameState& const NewMinigameState); // 0xa29d5e0 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UCreativeGameStreamDeviceCoordinatorComponent) == 0xd0, "Size mismatch for UCreativeGameStreamDeviceCoordinatorComponent");
static_assert(offsetof(UCreativeGameStreamDeviceCoordinatorComponent, EndGameCreativeGameStreamDeviceComponentQueue) == 0xb8, "Offset mismatch for UCreativeGameStreamDeviceCoordinatorComponent::EndGameCreativeGameStreamDeviceComponentQueue");
static_assert(offsetof(UCreativeGameStreamDeviceCoordinatorComponent, Minigame) == 0xc8, "Offset mismatch for UCreativeGameStreamDeviceCoordinatorComponent::Minigame");

