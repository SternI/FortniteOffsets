/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CharacterCollectionMapScreen
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CollectionMapShared.h"
#include "FortniteUI.h"
#include "UMG.h"
#include "GameplayTags.h"

// Size: 0x700 (Inherited: 0x1860, Single: 0xffffeea0)
class UAthenaCollectionScreenMapCharacter : public UAthenaCollectionScreenMapBase
{
public:
    UCollectionScreenServiceVisualData* SharedServiceVisualData; // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer ExcludedProducts; // 0x6e0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UAthenaCollectionScreenMapCharacter) == 0x700, "Size mismatch for UAthenaCollectionScreenMapCharacter");
static_assert(offsetof(UAthenaCollectionScreenMapCharacter, SharedServiceVisualData) == 0x6d8, "Offset mismatch for UAthenaCollectionScreenMapCharacter::SharedServiceVisualData");
static_assert(offsetof(UAthenaCollectionScreenMapCharacter, ExcludedProducts) == 0x6e0, "Offset mismatch for UAthenaCollectionScreenMapCharacter::ExcludedProducts");

// Size: 0x4d8 (Inherited: 0xff8, Single: 0xfffff4e0)
class UCollectionNPCServiceInfoOverlay : public UAthenaCollectionScreenInfoOverlay
{
public:
    UCollectionNPCServiceContainer* Services; // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_ServiceIcon; // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UCollectionScreenServiceVisualData* SharedServiceVisualData; // 0x4d0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UCollectionNPCServiceInfoOverlay) == 0x4d8, "Size mismatch for UCollectionNPCServiceInfoOverlay");
static_assert(offsetof(UCollectionNPCServiceInfoOverlay, Services) == 0x4c0, "Offset mismatch for UCollectionNPCServiceInfoOverlay::Services");
static_assert(offsetof(UCollectionNPCServiceInfoOverlay, Image_ServiceIcon) == 0x4c8, "Offset mismatch for UCollectionNPCServiceInfoOverlay::Image_ServiceIcon");
static_assert(offsetof(UCollectionNPCServiceInfoOverlay, SharedServiceVisualData) == 0x4d0, "Offset mismatch for UCollectionNPCServiceInfoOverlay::SharedServiceVisualData");

