/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FlyingCodeRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "GameplayAbilities.h"

// Size: 0x2020 (Inherited: 0x20a8, Single: 0xffffff78)
class UFortCameraMode_Flying : public UFortCameraMode_ThirdPerson
{
public:
    float LastActiveTimeSeconds; // 0x2018 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_201c[0x4]; // 0x201c (Size: 0x4, Type: PaddingProperty)

public:
    virtual void BP_ProcessViewRotation(const FRotator InViewRotation, const FRotator InDeltaRot, float& DeltaTime, bool& bOutShouldOverride, FRotator& OutViewRotation, FRotator& OutDeltaRot) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const)
};

static_assert(sizeof(UFortCameraMode_Flying) == 0x2020, "Size mismatch for UFortCameraMode_Flying");
static_assert(offsetof(UFortCameraMode_Flying, LastActiveTimeSeconds) == 0x2018, "Offset mismatch for UFortCameraMode_Flying::LastActiveTimeSeconds");

// Size: 0x78 (Inherited: 0x68, Single: 0x10)
class UFortMovementMode_FlyingRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
    FVector2D MovementInput; // 0x40 (Size: 0x10, Type: StructProperty)
    float CeilingHeight; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
    FRotator MoveOrientation; // 0x58 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_70[0x8]; // 0x70 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortMovementMode_FlyingRuntimeData) == 0x78, "Size mismatch for UFortMovementMode_FlyingRuntimeData");
static_assert(offsetof(UFortMovementMode_FlyingRuntimeData, MovementInput) == 0x40, "Offset mismatch for UFortMovementMode_FlyingRuntimeData::MovementInput");
static_assert(offsetof(UFortMovementMode_FlyingRuntimeData, CeilingHeight) == 0x50, "Offset mismatch for UFortMovementMode_FlyingRuntimeData::CeilingHeight");
static_assert(offsetof(UFortMovementMode_FlyingRuntimeData, MoveOrientation) == 0x58, "Offset mismatch for UFortMovementMode_FlyingRuntimeData::MoveOrientation");

// Size: 0x1f0 (Inherited: 0x210, Single: 0xffffffe0)
class UFortMovementMode_ExtLogicFlying : public UFortMovementMode_BaseExtLogic
{
public:
    bool bEnableInput; // 0x1e8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1e9[0x7]; // 0x1e9 (Size: 0x7, Type: PaddingProperty)

public:
    virtual bool CanBeginFlying() const; // 0x53bb30c (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent|Const)
    void ClearInputActionDisplayContext(UFortInputMappingContext*& const InputMappingContext); // 0x1141a93c (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void SetInputActionDisplayContext(UFortInputMappingContext*& const InputMappingContext); // 0x1141aef8 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortMovementMode_ExtLogicFlying) == 0x1f0, "Size mismatch for UFortMovementMode_ExtLogicFlying");
static_assert(offsetof(UFortMovementMode_ExtLogicFlying, bEnableInput) == 0x1e8, "Offset mismatch for UFortMovementMode_ExtLogicFlying::bEnableInput");

// Size: 0xb0 (Inherited: 0x88, Single: 0x28)
class UFlyingAttributeSet : public UFortAttributeSet
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    FFortGameplayAttributeData MaxFuel; // 0x38 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData FuelUsageRate; // 0x60 (Size: 0x28, Type: StructProperty)
    FFortGameplayAttributeData LocalFuel; // 0x88 (Size: 0x28, Type: StructProperty)

private:
    void OnRep_FuelUsageRate(const FFortGameplayAttributeData OldValue); // 0x1141ace8 (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
    void OnRep_LocalFuel(const FFortGameplayAttributeData OldValue); // 0x1141adf0 (Index: 0x1, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UFlyingAttributeSet) == 0xb0, "Size mismatch for UFlyingAttributeSet");
static_assert(offsetof(UFlyingAttributeSet, MaxFuel) == 0x38, "Offset mismatch for UFlyingAttributeSet::MaxFuel");
static_assert(offsetof(UFlyingAttributeSet, FuelUsageRate) == 0x60, "Offset mismatch for UFlyingAttributeSet::FuelUsageRate");
static_assert(offsetof(UFlyingAttributeSet, LocalFuel) == 0x88, "Offset mismatch for UFlyingAttributeSet::LocalFuel");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FFortMovementMode_FlyingCreationData : FFortMovementMode_BaseExtCreationData
{
    float CeilingHeight; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FRotator MoveOrientation; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FFortMovementMode_FlyingCreationData) == 0x30, "Size mismatch for FFortMovementMode_FlyingCreationData");
static_assert(offsetof(FFortMovementMode_FlyingCreationData, CeilingHeight) == 0x10, "Offset mismatch for FFortMovementMode_FlyingCreationData::CeilingHeight");
static_assert(offsetof(FFortMovementMode_FlyingCreationData, MoveOrientation) == 0x18, "Offset mismatch for FFortMovementMode_FlyingCreationData::MoveOrientation");

