/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicStreamMediaSource
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "MediaAssets.h"
#include "EpicMediaUtilities.h"
#include "EpicMediaCDNHostnames.h"
#include "Engine.h"
#include "MediaUtils.h"
#include "EpicMediaLocalizedOverlays.h"
#include "CoreUObject.h"
#include "EpicMediaMetadataResolver.h"

// Size: 0x870 (Inherited: 0x1c8, Single: 0x6a8)
class UEpicStreamMediaSource : public UStreamMediaSource
{
public:
    FString VideoStreamSource; // 0x98 (Size: 0x10, Type: StrProperty)
    float VideoStreamSourceAB; // 0xa8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
    TMap<FString, FString> VideoId; // 0xb0 (Size: 0x50, Type: MapProperty)
    bool bIsLive; // 0x100 (Size: 0x1, Type: BoolProperty)
    bool bBlurlLive; // 0x101 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_102[0x2]; // 0x102 (Size: 0x2, Type: PaddingProperty)
    int32_t MaxResolution; // 0x104 (Size: 0x4, Type: IntProperty)
    int32_t MaxBandwidth; // 0x108 (Size: 0x4, Type: IntProperty)
    float AspectRatio; // 0x10c (Size: 0x4, Type: FloatProperty)
    bool bSharelock; // 0x110 (Size: 0x1, Type: BoolProperty)
    bool bAudioOnly; // 0x111 (Size: 0x1, Type: BoolProperty)
    bool bPartySync; // 0x112 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_113[0x1]; // 0x113 (Size: 0x1, Type: PaddingProperty)
    float MediaDuration; // 0x114 (Size: 0x4, Type: FloatProperty)
    FString mimetype; // 0x118 (Size: 0x10, Type: StrProperty)
    FString StreamDenyHTTPCode; // 0x128 (Size: 0x10, Type: StrProperty)
    UEpicMediaCDNHostnames* CDNHostNames; // 0x138 (Size: 0x8, Type: ObjectProperty)
    bool bEnableCDNFailureRetries; // 0x140 (Size: 0x1, Type: BoolProperty)
    bool bEnableBLURLRetries; // 0x141 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_142[0x2]; // 0x142 (Size: 0x2, Type: PaddingProperty)
    int32_t MaxBLURLRetryAttempts; // 0x144 (Size: 0x4, Type: IntProperty)
    bool bEnableScrubOptimization; // 0x148 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_149[0x3]; // 0x149 (Size: 0x3, Type: PaddingProperty)
    int32_t SeekBitrate; // 0x14c (Size: 0x4, Type: IntProperty)
    int32_t CacheSizeKiB; // 0x150 (Size: 0x4, Type: IntProperty)
    int32_t TimeToCacheMilliseconds; // 0x154 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_158[0x3a8]; // 0x158 (Size: 0x3a8, Type: PaddingProperty)
    uint8_t OnVideoUrlSuccess[0x10]; // 0x500 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnVideoUrlFailed[0x10]; // 0x510 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMetaDataFailure[0x10]; // 0x520 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMediaLicensedAudioTreatmentChanged[0x10]; // 0x530 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_540[0x10]; // 0x540 (Size: 0x10, Type: PaddingProperty)
    UEpicMediaDownloadLocalizedOverlays* EpicMediaDownloadLocalizedOverlays; // 0x550 (Size: 0x8, Type: ObjectProperty)
    FString ProtectUserFromAVSettings; // 0x558 (Size: 0x10, Type: StrProperty)
    FString StreamID; // 0x568 (Size: 0x10, Type: StrProperty)
    FString StreamID_Development; // 0x578 (Size: 0x10, Type: StrProperty)
    UMediaSource* LocalFilePlaybackAsset; // 0x588 (Size: 0x8, Type: ObjectProperty)
    double HighestFramerate; // 0x590 (Size: 0x8, Type: DoubleProperty)
    uint8_t Pad_598[0x18]; // 0x598 (Size: 0x18, Type: PaddingProperty)
    TMap<int32_t, FString> RetryAttempts; // 0x5b0 (Size: 0x50, Type: MapProperty)
    TArray<int32_t> RetryErrorCodes; // 0x600 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> SwitchCDNErrorCodes; // 0x610 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> RetryDelayMS; // 0x620 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_630[0x18]; // 0x630 (Size: 0x18, Type: PaddingProperty)
    UEpicMediaMetadataResolver* MetadataResolver; // 0x648 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_650[0x220]; // 0x650 (Size: 0x220, Type: PaddingProperty)

public:
    void CancelVideoUrlRequest(bool& bInCancelled); // 0xc5a768c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void ClearSyncTimes(); // 0xc5a77b8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void ClearTimeWindowTimes(); // 0xc5a77cc (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void DisableSharing(); // 0x3305bfc (Index: 0x3, Flags: Native|Public|BlueprintCallable)
    void ForceSegmentCaching(bool& bForce); // 0xc5a77e0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    bool HasLocalFilePlayback() const; // 0xc5a790c (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsScreenRecordingInProgress(); // 0x4c4e47c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    bool IsSyncTimeSet(); // 0xc5a7980 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    bool IsTimeWindowSet(); // 0xc5a79a4 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void MetadataResultHandler(const FEpicMediaMetadataExt MetaData, bool& bSuccess); // 0xc5a79c8 (Index: 0x9, Flags: Final|Native|Public|HasOutParms)
    void ReinstateSharing(); // 0x472ef98 (Index: 0xa, Flags: Native|Public|BlueprintCallable)
    void RequestVideoUrl(APlayerController*& const FortPC); // 0xc5a7b58 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void SetLocalizedOverlaysV2(UEpicMediaDownloadLocalizedOverlays*& InOverlays); // 0xa86074c (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    void SetMediaTimeWindowSeconds(FTimespan& InStartTime, FTimespan& InEndTime); // 0xc5a7c80 (Index: 0xd, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetPlaybackStartTime(float& StartTime); // 0xc5a7db8 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    void SetSyncTimes(FDateTime& InNowTime, FDateTime& InStartTime, bool& DynamicStart, float& InOffset_s, float& InDelay_s); // 0xc5a7ee4 (Index: 0xf, Flags: Final|Native|Public|HasDefaults|BlueprintCallable)
    void SetUrl(FString InURL); // 0xc5a8180 (Index: 0x10, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    UCPTypes ShouldProtectPlayerFromContent(); // 0xa20aeec (Index: 0x11, Flags: Native|Public|BlueprintCallable|BlueprintPure)
    bool ShouldStreamBePlaying(UObject*& const WorldContextObject, UPrimitiveComponent*& const PrimitiveComponent, float& CullRadius) const; // 0xc5a8414 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FMediaPlayerOptions UpdatePlayerOptions(FMediaPlayerOptions& PlayerOptions) const; // 0xc5a888c (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void UpdateStreamUrlArguments(); // 0xc5a89c4 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UEpicStreamMediaSource) == 0x870, "Size mismatch for UEpicStreamMediaSource");
static_assert(offsetof(UEpicStreamMediaSource, VideoStreamSource) == 0x98, "Offset mismatch for UEpicStreamMediaSource::VideoStreamSource");
static_assert(offsetof(UEpicStreamMediaSource, VideoStreamSourceAB) == 0xa8, "Offset mismatch for UEpicStreamMediaSource::VideoStreamSourceAB");
static_assert(offsetof(UEpicStreamMediaSource, VideoId) == 0xb0, "Offset mismatch for UEpicStreamMediaSource::VideoId");
static_assert(offsetof(UEpicStreamMediaSource, bIsLive) == 0x100, "Offset mismatch for UEpicStreamMediaSource::bIsLive");
static_assert(offsetof(UEpicStreamMediaSource, bBlurlLive) == 0x101, "Offset mismatch for UEpicStreamMediaSource::bBlurlLive");
static_assert(offsetof(UEpicStreamMediaSource, MaxResolution) == 0x104, "Offset mismatch for UEpicStreamMediaSource::MaxResolution");
static_assert(offsetof(UEpicStreamMediaSource, MaxBandwidth) == 0x108, "Offset mismatch for UEpicStreamMediaSource::MaxBandwidth");
static_assert(offsetof(UEpicStreamMediaSource, AspectRatio) == 0x10c, "Offset mismatch for UEpicStreamMediaSource::AspectRatio");
static_assert(offsetof(UEpicStreamMediaSource, bSharelock) == 0x110, "Offset mismatch for UEpicStreamMediaSource::bSharelock");
static_assert(offsetof(UEpicStreamMediaSource, bAudioOnly) == 0x111, "Offset mismatch for UEpicStreamMediaSource::bAudioOnly");
static_assert(offsetof(UEpicStreamMediaSource, bPartySync) == 0x112, "Offset mismatch for UEpicStreamMediaSource::bPartySync");
static_assert(offsetof(UEpicStreamMediaSource, MediaDuration) == 0x114, "Offset mismatch for UEpicStreamMediaSource::MediaDuration");
static_assert(offsetof(UEpicStreamMediaSource, mimetype) == 0x118, "Offset mismatch for UEpicStreamMediaSource::mimetype");
static_assert(offsetof(UEpicStreamMediaSource, StreamDenyHTTPCode) == 0x128, "Offset mismatch for UEpicStreamMediaSource::StreamDenyHTTPCode");
static_assert(offsetof(UEpicStreamMediaSource, CDNHostNames) == 0x138, "Offset mismatch for UEpicStreamMediaSource::CDNHostNames");
static_assert(offsetof(UEpicStreamMediaSource, bEnableCDNFailureRetries) == 0x140, "Offset mismatch for UEpicStreamMediaSource::bEnableCDNFailureRetries");
static_assert(offsetof(UEpicStreamMediaSource, bEnableBLURLRetries) == 0x141, "Offset mismatch for UEpicStreamMediaSource::bEnableBLURLRetries");
static_assert(offsetof(UEpicStreamMediaSource, MaxBLURLRetryAttempts) == 0x144, "Offset mismatch for UEpicStreamMediaSource::MaxBLURLRetryAttempts");
static_assert(offsetof(UEpicStreamMediaSource, bEnableScrubOptimization) == 0x148, "Offset mismatch for UEpicStreamMediaSource::bEnableScrubOptimization");
static_assert(offsetof(UEpicStreamMediaSource, SeekBitrate) == 0x14c, "Offset mismatch for UEpicStreamMediaSource::SeekBitrate");
static_assert(offsetof(UEpicStreamMediaSource, CacheSizeKiB) == 0x150, "Offset mismatch for UEpicStreamMediaSource::CacheSizeKiB");
static_assert(offsetof(UEpicStreamMediaSource, TimeToCacheMilliseconds) == 0x154, "Offset mismatch for UEpicStreamMediaSource::TimeToCacheMilliseconds");
static_assert(offsetof(UEpicStreamMediaSource, OnVideoUrlSuccess) == 0x500, "Offset mismatch for UEpicStreamMediaSource::OnVideoUrlSuccess");
static_assert(offsetof(UEpicStreamMediaSource, OnVideoUrlFailed) == 0x510, "Offset mismatch for UEpicStreamMediaSource::OnVideoUrlFailed");
static_assert(offsetof(UEpicStreamMediaSource, OnMetaDataFailure) == 0x520, "Offset mismatch for UEpicStreamMediaSource::OnMetaDataFailure");
static_assert(offsetof(UEpicStreamMediaSource, OnMediaLicensedAudioTreatmentChanged) == 0x530, "Offset mismatch for UEpicStreamMediaSource::OnMediaLicensedAudioTreatmentChanged");
static_assert(offsetof(UEpicStreamMediaSource, EpicMediaDownloadLocalizedOverlays) == 0x550, "Offset mismatch for UEpicStreamMediaSource::EpicMediaDownloadLocalizedOverlays");
static_assert(offsetof(UEpicStreamMediaSource, ProtectUserFromAVSettings) == 0x558, "Offset mismatch for UEpicStreamMediaSource::ProtectUserFromAVSettings");
static_assert(offsetof(UEpicStreamMediaSource, StreamID) == 0x568, "Offset mismatch for UEpicStreamMediaSource::StreamID");
static_assert(offsetof(UEpicStreamMediaSource, StreamID_Development) == 0x578, "Offset mismatch for UEpicStreamMediaSource::StreamID_Development");
static_assert(offsetof(UEpicStreamMediaSource, LocalFilePlaybackAsset) == 0x588, "Offset mismatch for UEpicStreamMediaSource::LocalFilePlaybackAsset");
static_assert(offsetof(UEpicStreamMediaSource, HighestFramerate) == 0x590, "Offset mismatch for UEpicStreamMediaSource::HighestFramerate");
static_assert(offsetof(UEpicStreamMediaSource, RetryAttempts) == 0x5b0, "Offset mismatch for UEpicStreamMediaSource::RetryAttempts");
static_assert(offsetof(UEpicStreamMediaSource, RetryErrorCodes) == 0x600, "Offset mismatch for UEpicStreamMediaSource::RetryErrorCodes");
static_assert(offsetof(UEpicStreamMediaSource, SwitchCDNErrorCodes) == 0x610, "Offset mismatch for UEpicStreamMediaSource::SwitchCDNErrorCodes");
static_assert(offsetof(UEpicStreamMediaSource, RetryDelayMS) == 0x620, "Offset mismatch for UEpicStreamMediaSource::RetryDelayMS");
static_assert(offsetof(UEpicStreamMediaSource, MetadataResolver) == 0x648, "Offset mismatch for UEpicStreamMediaSource::MetadataResolver");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRetryRequestResponse
{
    float RetryDelay; // 0x0 (Size: 0x4, Type: FloatProperty)
    int32_t ErrorCode; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t RetryAttempt; // 0x8 (Size: 0x4, Type: IntProperty)
    bool ShouldRetry; // 0xc (Size: 0x1, Type: BoolProperty)
    bool SwitchCDN; // 0xd (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e[0x2]; // 0xe (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FRetryRequestResponse) == 0x10, "Size mismatch for FRetryRequestResponse");
static_assert(offsetof(FRetryRequestResponse, RetryDelay) == 0x0, "Offset mismatch for FRetryRequestResponse::RetryDelay");
static_assert(offsetof(FRetryRequestResponse, ErrorCode) == 0x4, "Offset mismatch for FRetryRequestResponse::ErrorCode");
static_assert(offsetof(FRetryRequestResponse, RetryAttempt) == 0x8, "Offset mismatch for FRetryRequestResponse::RetryAttempt");
static_assert(offsetof(FRetryRequestResponse, ShouldRetry) == 0xc, "Offset mismatch for FRetryRequestResponse::ShouldRetry");
static_assert(offsetof(FRetryRequestResponse, SwitchCDN) == 0xd, "Offset mismatch for FRetryRequestResponse::SwitchCDN");

