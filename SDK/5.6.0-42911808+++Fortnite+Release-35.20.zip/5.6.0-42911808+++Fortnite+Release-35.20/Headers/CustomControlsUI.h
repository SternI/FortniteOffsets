/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CustomControlsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "DynamicUI.h"
#include "UMG.h"
#include "CustomControlsRuntime.h"

// Size: 0x2c8 (Inherited: 0x598, Single: 0xfffffd30)
class ACustomControlsUIDirector : public ADynamicUIDirectorBase
{
public:

protected:
    virtual void BP_OnOptionsActivated(UCustomControlOptions_Base*& const Options); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnOptionsDeactivated(UCustomControlOptions_Base*& const Options); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(ACustomControlsUIDirector) == 0x2c8, "Size mismatch for ACustomControlsUIDirector");

// Size: 0x2b8 (Inherited: 0x458, Single: 0xfffffe60)
class UTwinStickCursorWidget : public UUserWidget
{
public:
};

static_assert(sizeof(UTwinStickCursorWidget) == 0x2b8, "Size mismatch for UTwinStickCursorWidget");

