/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameSubCatalog
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "McpProfileSys.h"
#include "JsonUtilities.h"

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UCatalogOffersPriceConfig : public UObject
{
public:
    TMap<FOfferNumericPriceAdjustments, EAppStore> AppStoreOfferNumericPriceAdjustments; // 0x28 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UCatalogOffersPriceConfig) == 0x78, "Size mismatch for UCatalogOffersPriceConfig");
static_assert(offsetof(UCatalogOffersPriceConfig, AppStoreOfferNumericPriceAdjustments) == 0x28, "Offset mismatch for UCatalogOffersPriceConfig::AppStoreOfferNumericPriceAdjustments");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UMcpCatalogItemsForRandomPlayer : public UObject
{
public:
    uint32_t Percentage; // 0x28 (Size: 0x4, Type: UInt32Property)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    FString Salt; // 0x30 (Size: 0x10, Type: StrProperty)
    TArray<FString> CatalogItems; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UMcpCatalogItemsForRandomPlayer) == 0x50, "Size mismatch for UMcpCatalogItemsForRandomPlayer");
static_assert(offsetof(UMcpCatalogItemsForRandomPlayer, Percentage) == 0x28, "Offset mismatch for UMcpCatalogItemsForRandomPlayer::Percentage");
static_assert(offsetof(UMcpCatalogItemsForRandomPlayer, Salt) == 0x30, "Offset mismatch for UMcpCatalogItemsForRandomPlayer::Salt");
static_assert(offsetof(UMcpCatalogItemsForRandomPlayer, CatalogItems) == 0x40, "Offset mismatch for UMcpCatalogItemsForRandomPlayer::CatalogItems");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UMcpRmtParamOverrideSelector : public UObject
{
public:
    uint32_t RangeStart; // 0x28 (Size: 0x4, Type: UInt32Property)
    uint32_t RangeEnd; // 0x2c (Size: 0x4, Type: UInt32Property)
    FString Salt; // 0x30 (Size: 0x10, Type: StrProperty)
    uint8_t FulfillmentVerifierModeOverride; // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UMcpRmtParamOverrideSelector) == 0x48, "Size mismatch for UMcpRmtParamOverrideSelector");
static_assert(offsetof(UMcpRmtParamOverrideSelector, RangeStart) == 0x28, "Offset mismatch for UMcpRmtParamOverrideSelector::RangeStart");
static_assert(offsetof(UMcpRmtParamOverrideSelector, RangeEnd) == 0x2c, "Offset mismatch for UMcpRmtParamOverrideSelector::RangeEnd");
static_assert(offsetof(UMcpRmtParamOverrideSelector, Salt) == 0x30, "Offset mismatch for UMcpRmtParamOverrideSelector::Salt");
static_assert(offsetof(UMcpRmtParamOverrideSelector, FulfillmentVerifierModeOverride) == 0x40, "Offset mismatch for UMcpRmtParamOverrideSelector::FulfillmentVerifierModeOverride");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FOfferNumericPriceAdjustment
{
    FString Currency; // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t DecimalPower; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FOfferNumericPriceAdjustment) == 0x18, "Size mismatch for FOfferNumericPriceAdjustment");
static_assert(offsetof(FOfferNumericPriceAdjustment, Currency) == 0x0, "Offset mismatch for FOfferNumericPriceAdjustment::Currency");
static_assert(offsetof(FOfferNumericPriceAdjustment, DecimalPower) == 0x10, "Offset mismatch for FOfferNumericPriceAdjustment::DecimalPower");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FOfferNumericPriceAdjustments
{
    TArray<FOfferNumericPriceAdjustment> OfferPriceAdjustments; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FOfferNumericPriceAdjustments) == 0x10, "Size mismatch for FOfferNumericPriceAdjustments");
static_assert(offsetof(FOfferNumericPriceAdjustments, OfferPriceAdjustments) == 0x0, "Offset mismatch for FOfferNumericPriceAdjustments::OfferPriceAdjustments");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCatalogItemSalePrice
{
    int32_t SalePrice; // 0x0 (Size: 0x4, Type: IntProperty)
    TEnumAsByte<ECatalogSaleType> SaleType; // 0x4 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FDateTime StartTime; // 0x8 (Size: 0x8, Type: StructProperty)
    FDateTime EndTime; // 0x10 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FCatalogItemSalePrice) == 0x18, "Size mismatch for FCatalogItemSalePrice");
static_assert(offsetof(FCatalogItemSalePrice, SalePrice) == 0x0, "Offset mismatch for FCatalogItemSalePrice::SalePrice");
static_assert(offsetof(FCatalogItemSalePrice, SaleType) == 0x4, "Offset mismatch for FCatalogItemSalePrice::SaleType");
static_assert(offsetof(FCatalogItemSalePrice, StartTime) == 0x8, "Offset mismatch for FCatalogItemSalePrice::StartTime");
static_assert(offsetof(FCatalogItemSalePrice, EndTime) == 0x10, "Offset mismatch for FCatalogItemSalePrice::EndTime");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FCatalogItemPrice
{
    TEnumAsByte<EStoreCurrencyType> CurrencyType; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FString CurrencySubType; // 0x8 (Size: 0x10, Type: StrProperty)
    int32_t RegularPrice; // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t FinalPrice; // 0x1c (Size: 0x4, Type: IntProperty)
    FText PriceTextOverride; // 0x20 (Size: 0x10, Type: TextProperty)
    TEnumAsByte<ECatalogSaleType> SaleType; // 0x30 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    FDateTime SaleExpiration; // 0x38 (Size: 0x8, Type: StructProperty)
    uint8_t AppStoreId; // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FCatalogItemPrice) == 0x48, "Size mismatch for FCatalogItemPrice");
static_assert(offsetof(FCatalogItemPrice, CurrencyType) == 0x0, "Offset mismatch for FCatalogItemPrice::CurrencyType");
static_assert(offsetof(FCatalogItemPrice, CurrencySubType) == 0x8, "Offset mismatch for FCatalogItemPrice::CurrencySubType");
static_assert(offsetof(FCatalogItemPrice, RegularPrice) == 0x18, "Offset mismatch for FCatalogItemPrice::RegularPrice");
static_assert(offsetof(FCatalogItemPrice, FinalPrice) == 0x1c, "Offset mismatch for FCatalogItemPrice::FinalPrice");
static_assert(offsetof(FCatalogItemPrice, PriceTextOverride) == 0x20, "Offset mismatch for FCatalogItemPrice::PriceTextOverride");
static_assert(offsetof(FCatalogItemPrice, SaleType) == 0x30, "Offset mismatch for FCatalogItemPrice::SaleType");
static_assert(offsetof(FCatalogItemPrice, SaleExpiration) == 0x38, "Offset mismatch for FCatalogItemPrice::SaleExpiration");
static_assert(offsetof(FCatalogItemPrice, AppStoreId) == 0x40, "Offset mismatch for FCatalogItemPrice::AppStoreId");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FAppStoreCheckoutConfig
{
    uint8_t AppStore; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t CheckoutType; // 0x1 (Size: 0x1, Type: EnumProperty)
};

static_assert(sizeof(FAppStoreCheckoutConfig) == 0x2, "Size mismatch for FAppStoreCheckoutConfig");
static_assert(offsetof(FAppStoreCheckoutConfig, AppStore) == 0x0, "Offset mismatch for FAppStoreCheckoutConfig::AppStore");
static_assert(offsetof(FAppStoreCheckoutConfig, CheckoutType) == 0x1, "Offset mismatch for FAppStoreCheckoutConfig::CheckoutType");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FStoreOfferInfo
{
    FString Storefront; // 0x0 (Size: 0x10, Type: StrProperty)
    FString StoreId; // 0x10 (Size: 0x10, Type: StrProperty)
    FString GroupId; // 0x20 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FStoreOfferInfo) == 0x30, "Size mismatch for FStoreOfferInfo");
static_assert(offsetof(FStoreOfferInfo, Storefront) == 0x0, "Offset mismatch for FStoreOfferInfo::Storefront");
static_assert(offsetof(FStoreOfferInfo, StoreId) == 0x10, "Offset mismatch for FStoreOfferInfo::StoreId");
static_assert(offsetof(FStoreOfferInfo, GroupId) == 0x20, "Offset mismatch for FStoreOfferInfo::GroupId");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFortItemShopFilterContext
{
    TArray<FString> ActiveFilters; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> InactiveFilters; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortItemShopFilterContext) == 0x20, "Size mismatch for FFortItemShopFilterContext");
static_assert(offsetof(FFortItemShopFilterContext, ActiveFilters) == 0x0, "Offset mismatch for FFortItemShopFilterContext::ActiveFilters");
static_assert(offsetof(FFortItemShopFilterContext, InactiveFilters) == 0x10, "Offset mismatch for FFortItemShopFilterContext::InactiveFilters");

// Size: 0xf8 (Inherited: 0x30, Single: 0xc8)
struct FCatalogPurchaseAdditionalData : FStoreOfferInfo
{
    FString IslandId; // 0x30 (Size: 0x10, Type: StrProperty)
    FString IslandTitle; // 0x40 (Size: 0x10, Type: StrProperty)
    FString ProductTag; // 0x50 (Size: 0x10, Type: StrProperty)
    FString StoreContext; // 0x60 (Size: 0x10, Type: StrProperty)
    FString SourceContext; // 0x70 (Size: 0x10, Type: StrProperty)
    TMap<FString, FString> CheckoutProperties; // 0x80 (Size: 0x50, Type: MapProperty)
    FFortItemShopFilterContext ItemShopFilterContext; // 0xd0 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_f0[0x8]; // 0xf0 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FCatalogPurchaseAdditionalData) == 0xf8, "Size mismatch for FCatalogPurchaseAdditionalData");
static_assert(offsetof(FCatalogPurchaseAdditionalData, IslandId) == 0x30, "Offset mismatch for FCatalogPurchaseAdditionalData::IslandId");
static_assert(offsetof(FCatalogPurchaseAdditionalData, IslandTitle) == 0x40, "Offset mismatch for FCatalogPurchaseAdditionalData::IslandTitle");
static_assert(offsetof(FCatalogPurchaseAdditionalData, ProductTag) == 0x50, "Offset mismatch for FCatalogPurchaseAdditionalData::ProductTag");
static_assert(offsetof(FCatalogPurchaseAdditionalData, StoreContext) == 0x60, "Offset mismatch for FCatalogPurchaseAdditionalData::StoreContext");
static_assert(offsetof(FCatalogPurchaseAdditionalData, SourceContext) == 0x70, "Offset mismatch for FCatalogPurchaseAdditionalData::SourceContext");
static_assert(offsetof(FCatalogPurchaseAdditionalData, CheckoutProperties) == 0x80, "Offset mismatch for FCatalogPurchaseAdditionalData::CheckoutProperties");
static_assert(offsetof(FCatalogPurchaseAdditionalData, ItemShopFilterContext) == 0xd0, "Offset mismatch for FCatalogPurchaseAdditionalData::ItemShopFilterContext");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FAdditionalCheckoutProperty
{
    FString Key; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FAdditionalCheckoutProperty) == 0x20, "Size mismatch for FAdditionalCheckoutProperty");
static_assert(offsetof(FAdditionalCheckoutProperty, Key) == 0x0, "Offset mismatch for FAdditionalCheckoutProperty::Key");
static_assert(offsetof(FAdditionalCheckoutProperty, Value) == 0x10, "Offset mismatch for FAdditionalCheckoutProperty::Value");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCatalogCheckoutOptions
{
    TArray<FAdditionalCheckoutProperty> AdditionalCheckoutProperties; // 0x0 (Size: 0x10, Type: ArrayProperty)
    bool bSkipCheckingEntitlementCount; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FCatalogCheckoutOptions) == 0x18, "Size mismatch for FCatalogCheckoutOptions");
static_assert(offsetof(FCatalogCheckoutOptions, AdditionalCheckoutProperties) == 0x0, "Offset mismatch for FCatalogCheckoutOptions::AdditionalCheckoutProperties");
static_assert(offsetof(FCatalogCheckoutOptions, bSkipCheckingEntitlementCount) == 0x10, "Offset mismatch for FCatalogCheckoutOptions::bSkipCheckingEntitlementCount");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCatalogRedeemRealMoneyPurchasesPurchaseInfo
{
    FString AppStoreId; // 0x0 (Size: 0x10, Type: StrProperty)
    FString InstanceID; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FCatalogRedeemRealMoneyPurchasesPurchaseInfo) == 0x20, "Size mismatch for FCatalogRedeemRealMoneyPurchasesPurchaseInfo");
static_assert(offsetof(FCatalogRedeemRealMoneyPurchasesPurchaseInfo, AppStoreId) == 0x0, "Offset mismatch for FCatalogRedeemRealMoneyPurchasesPurchaseInfo::AppStoreId");
static_assert(offsetof(FCatalogRedeemRealMoneyPurchasesPurchaseInfo, InstanceID) == 0x10, "Offset mismatch for FCatalogRedeemRealMoneyPurchasesPurchaseInfo::InstanceID");

// Size: 0x170 (Inherited: 0x0, Single: 0x170)
struct FCatalogRedeemRealMoneyPurchasesInfo
{
    uint8_t AppStore; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TArray<FString> AuthTokens; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> ReceiptIds; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FCatalogRedeemRealMoneyPurchasesPurchaseInfo> PurchaseInfos; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t RefreshType; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t FulfillmentVerifierModeOverride; // 0x39 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3a[0x6]; // 0x3a (Size: 0x6, Type: PaddingProperty)
    TArray<FString> CatalogItems; // 0x40 (Size: 0x10, Type: ArrayProperty)
    FString PurchaseCorrelationId; // 0x50 (Size: 0x10, Type: StrProperty)
    FCatalogPurchaseAdditionalData AdditionalData; // 0x60 (Size: 0xf8, Type: StructProperty)
    uint8_t Pad_158[0x18]; // 0x158 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FCatalogRedeemRealMoneyPurchasesInfo) == 0x170, "Size mismatch for FCatalogRedeemRealMoneyPurchasesInfo");
static_assert(offsetof(FCatalogRedeemRealMoneyPurchasesInfo, AppStore) == 0x0, "Offset mismatch for FCatalogRedeemRealMoneyPurchasesInfo::AppStore");
static_assert(offsetof(FCatalogRedeemRealMoneyPurchasesInfo, AuthTokens) == 0x8, "Offset mismatch for FCatalogRedeemRealMoneyPurchasesInfo::AuthTokens");
static_assert(offsetof(FCatalogRedeemRealMoneyPurchasesInfo, ReceiptIds) == 0x18, "Offset mismatch for FCatalogRedeemRealMoneyPurchasesInfo::ReceiptIds");
static_assert(offsetof(FCatalogRedeemRealMoneyPurchasesInfo, PurchaseInfos) == 0x28, "Offset mismatch for FCatalogRedeemRealMoneyPurchasesInfo::PurchaseInfos");
static_assert(offsetof(FCatalogRedeemRealMoneyPurchasesInfo, RefreshType) == 0x38, "Offset mismatch for FCatalogRedeemRealMoneyPurchasesInfo::RefreshType");
static_assert(offsetof(FCatalogRedeemRealMoneyPurchasesInfo, FulfillmentVerifierModeOverride) == 0x39, "Offset mismatch for FCatalogRedeemRealMoneyPurchasesInfo::FulfillmentVerifierModeOverride");
static_assert(offsetof(FCatalogRedeemRealMoneyPurchasesInfo, CatalogItems) == 0x40, "Offset mismatch for FCatalogRedeemRealMoneyPurchasesInfo::CatalogItems");
static_assert(offsetof(FCatalogRedeemRealMoneyPurchasesInfo, PurchaseCorrelationId) == 0x50, "Offset mismatch for FCatalogRedeemRealMoneyPurchasesInfo::PurchaseCorrelationId");
static_assert(offsetof(FCatalogRedeemRealMoneyPurchasesInfo, AdditionalData) == 0x60, "Offset mismatch for FCatalogRedeemRealMoneyPurchasesInfo::AdditionalData");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FCatalogReceiptInfo
{
    uint8_t AppStore; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FString AppStoreId; // 0x8 (Size: 0x10, Type: StrProperty)
    FString ReceiptId; // 0x18 (Size: 0x10, Type: StrProperty)
    FString ReceiptInfo; // 0x28 (Size: 0x10, Type: StrProperty)
    FString PurchaseCorrelationId; // 0x38 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FCatalogReceiptInfo) == 0x50, "Size mismatch for FCatalogReceiptInfo");
static_assert(offsetof(FCatalogReceiptInfo, AppStore) == 0x0, "Offset mismatch for FCatalogReceiptInfo::AppStore");
static_assert(offsetof(FCatalogReceiptInfo, AppStoreId) == 0x8, "Offset mismatch for FCatalogReceiptInfo::AppStoreId");
static_assert(offsetof(FCatalogReceiptInfo, ReceiptId) == 0x18, "Offset mismatch for FCatalogReceiptInfo::ReceiptId");
static_assert(offsetof(FCatalogReceiptInfo, ReceiptInfo) == 0x28, "Offset mismatch for FCatalogReceiptInfo::ReceiptInfo");
static_assert(offsetof(FCatalogReceiptInfo, PurchaseCorrelationId) == 0x38, "Offset mismatch for FCatalogReceiptInfo::PurchaseCorrelationId");

// Size: 0x138 (Inherited: 0x0, Single: 0x138)
struct FCatalogPurchaseInfo
{
    FString OfferId; // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t PurchaseQuantity; // 0x10 (Size: 0x4, Type: IntProperty)
    TEnumAsByte<EStoreCurrencyType> Currency; // 0x14 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    FString CurrencySubType; // 0x18 (Size: 0x10, Type: StrProperty)
    int32_t ExpectedTotalPrice; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    FString GameContext; // 0x30 (Size: 0x10, Type: StrProperty)
    FCatalogPurchaseAdditionalData AdditionalData; // 0x40 (Size: 0xf8, Type: StructProperty)
};

static_assert(sizeof(FCatalogPurchaseInfo) == 0x138, "Size mismatch for FCatalogPurchaseInfo");
static_assert(offsetof(FCatalogPurchaseInfo, OfferId) == 0x0, "Offset mismatch for FCatalogPurchaseInfo::OfferId");
static_assert(offsetof(FCatalogPurchaseInfo, PurchaseQuantity) == 0x10, "Offset mismatch for FCatalogPurchaseInfo::PurchaseQuantity");
static_assert(offsetof(FCatalogPurchaseInfo, Currency) == 0x14, "Offset mismatch for FCatalogPurchaseInfo::Currency");
static_assert(offsetof(FCatalogPurchaseInfo, CurrencySubType) == 0x18, "Offset mismatch for FCatalogPurchaseInfo::CurrencySubType");
static_assert(offsetof(FCatalogPurchaseInfo, ExpectedTotalPrice) == 0x28, "Offset mismatch for FCatalogPurchaseInfo::ExpectedTotalPrice");
static_assert(offsetof(FCatalogPurchaseInfo, GameContext) == 0x30, "Offset mismatch for FCatalogPurchaseInfo::GameContext");
static_assert(offsetof(FCatalogPurchaseInfo, AdditionalData) == 0x40, "Offset mismatch for FCatalogPurchaseInfo::AdditionalData");

// Size: 0x168 (Inherited: 0x0, Single: 0x168)
struct FCatalogPurchaseInfoGift
{
    FString OfferId; // 0x0 (Size: 0x10, Type: StrProperty)
    TEnumAsByte<EStoreCurrencyType> Currency; // 0x10 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FString CurrencySubType; // 0x18 (Size: 0x10, Type: StrProperty)
    int32_t ExpectedTotalPrice; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    FString GameContext; // 0x30 (Size: 0x10, Type: StrProperty)
    TArray<FString> ReceiverAccountIds; // 0x40 (Size: 0x10, Type: ArrayProperty)
    FString GiftWrapTemplateId; // 0x50 (Size: 0x10, Type: StrProperty)
    FString PersonalMessage; // 0x60 (Size: 0x10, Type: StrProperty)
    FCatalogPurchaseAdditionalData AdditionalData; // 0x70 (Size: 0xf8, Type: StructProperty)
};

static_assert(sizeof(FCatalogPurchaseInfoGift) == 0x168, "Size mismatch for FCatalogPurchaseInfoGift");
static_assert(offsetof(FCatalogPurchaseInfoGift, OfferId) == 0x0, "Offset mismatch for FCatalogPurchaseInfoGift::OfferId");
static_assert(offsetof(FCatalogPurchaseInfoGift, Currency) == 0x10, "Offset mismatch for FCatalogPurchaseInfoGift::Currency");
static_assert(offsetof(FCatalogPurchaseInfoGift, CurrencySubType) == 0x18, "Offset mismatch for FCatalogPurchaseInfoGift::CurrencySubType");
static_assert(offsetof(FCatalogPurchaseInfoGift, ExpectedTotalPrice) == 0x28, "Offset mismatch for FCatalogPurchaseInfoGift::ExpectedTotalPrice");
static_assert(offsetof(FCatalogPurchaseInfoGift, GameContext) == 0x30, "Offset mismatch for FCatalogPurchaseInfoGift::GameContext");
static_assert(offsetof(FCatalogPurchaseInfoGift, ReceiverAccountIds) == 0x40, "Offset mismatch for FCatalogPurchaseInfoGift::ReceiverAccountIds");
static_assert(offsetof(FCatalogPurchaseInfoGift, GiftWrapTemplateId) == 0x50, "Offset mismatch for FCatalogPurchaseInfoGift::GiftWrapTemplateId");
static_assert(offsetof(FCatalogPurchaseInfoGift, PersonalMessage) == 0x60, "Offset mismatch for FCatalogPurchaseInfoGift::PersonalMessage");
static_assert(offsetof(FCatalogPurchaseInfoGift, AdditionalData) == 0x70, "Offset mismatch for FCatalogPurchaseInfoGift::AdditionalData");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCatalogKeyValue
{
    FString Key; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FCatalogKeyValue) == 0x20, "Size mismatch for FCatalogKeyValue");
static_assert(offsetof(FCatalogKeyValue, Key) == 0x0, "Offset mismatch for FCatalogKeyValue::Key");
static_assert(offsetof(FCatalogKeyValue, Value) == 0x10, "Offset mismatch for FCatalogKeyValue::Value");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FCatalogMetaAssetInfo
{
    FString StructName; // 0x0 (Size: 0x10, Type: StrProperty)
    FJsonObjectWrapper Payload; // 0x10 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FCatalogMetaAssetInfo) == 0x30, "Size mismatch for FCatalogMetaAssetInfo");
static_assert(offsetof(FCatalogMetaAssetInfo, StructName) == 0x0, "Offset mismatch for FCatalogMetaAssetInfo::StructName");
static_assert(offsetof(FCatalogMetaAssetInfo, Payload) == 0x10, "Offset mismatch for FCatalogMetaAssetInfo::Payload");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FItemQuantity
{
    FString TemplateId; // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t Quantity; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FJsonObjectWrapper Attributes; // 0x18 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FItemQuantity) == 0x38, "Size mismatch for FItemQuantity");
static_assert(offsetof(FItemQuantity, TemplateId) == 0x0, "Offset mismatch for FItemQuantity::TemplateId");
static_assert(offsetof(FItemQuantity, Quantity) == 0x10, "Offset mismatch for FItemQuantity::Quantity");
static_assert(offsetof(FItemQuantity, Attributes) == 0x18, "Offset mismatch for FItemQuantity::Attributes");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FCatalogDynamicBundleItem
{
    FItemQuantity Item; // 0x0 (Size: 0x38, Type: StructProperty)
    bool bCanOwnMultiple; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    int32_t RegularPrice; // 0x3c (Size: 0x4, Type: IntProperty)
    int32_t DiscountedPrice; // 0x40 (Size: 0x4, Type: IntProperty)
    int32_t AlreadyOwnedPriceReduction; // 0x44 (Size: 0x4, Type: IntProperty)
    FText Title; // 0x48 (Size: 0x10, Type: TextProperty)
    FText Description; // 0x58 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FCatalogDynamicBundleItem) == 0x68, "Size mismatch for FCatalogDynamicBundleItem");
static_assert(offsetof(FCatalogDynamicBundleItem, Item) == 0x0, "Offset mismatch for FCatalogDynamicBundleItem::Item");
static_assert(offsetof(FCatalogDynamicBundleItem, bCanOwnMultiple) == 0x38, "Offset mismatch for FCatalogDynamicBundleItem::bCanOwnMultiple");
static_assert(offsetof(FCatalogDynamicBundleItem, RegularPrice) == 0x3c, "Offset mismatch for FCatalogDynamicBundleItem::RegularPrice");
static_assert(offsetof(FCatalogDynamicBundleItem, DiscountedPrice) == 0x40, "Offset mismatch for FCatalogDynamicBundleItem::DiscountedPrice");
static_assert(offsetof(FCatalogDynamicBundleItem, AlreadyOwnedPriceReduction) == 0x44, "Offset mismatch for FCatalogDynamicBundleItem::AlreadyOwnedPriceReduction");
static_assert(offsetof(FCatalogDynamicBundleItem, Title) == 0x48, "Offset mismatch for FCatalogDynamicBundleItem::Title");
static_assert(offsetof(FCatalogDynamicBundleItem, Description) == 0x58, "Offset mismatch for FCatalogDynamicBundleItem::Description");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FCatalogDynamicBundle
{
    int32_t DiscountedBasePrice; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t RegularBasePrice; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t FloorPrice; // 0x8 (Size: 0x4, Type: IntProperty)
    TEnumAsByte<EStoreCurrencyType> CurrencyType; // 0xc (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FString CurrencySubType; // 0x10 (Size: 0x10, Type: StrProperty)
    TEnumAsByte<ECatalogSaleType> DisplayType; // 0x20 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
    TArray<FCatalogDynamicBundleItem> BundleItems; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCatalogDynamicBundle) == 0x38, "Size mismatch for FCatalogDynamicBundle");
static_assert(offsetof(FCatalogDynamicBundle, DiscountedBasePrice) == 0x0, "Offset mismatch for FCatalogDynamicBundle::DiscountedBasePrice");
static_assert(offsetof(FCatalogDynamicBundle, RegularBasePrice) == 0x4, "Offset mismatch for FCatalogDynamicBundle::RegularBasePrice");
static_assert(offsetof(FCatalogDynamicBundle, FloorPrice) == 0x8, "Offset mismatch for FCatalogDynamicBundle::FloorPrice");
static_assert(offsetof(FCatalogDynamicBundle, CurrencyType) == 0xc, "Offset mismatch for FCatalogDynamicBundle::CurrencyType");
static_assert(offsetof(FCatalogDynamicBundle, CurrencySubType) == 0x10, "Offset mismatch for FCatalogDynamicBundle::CurrencySubType");
static_assert(offsetof(FCatalogDynamicBundle, DisplayType) == 0x20, "Offset mismatch for FCatalogDynamicBundle::DisplayType");
static_assert(offsetof(FCatalogDynamicBundle, BundleItems) == 0x28, "Offset mismatch for FCatalogDynamicBundle::BundleItems");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCatalogOfferRequirement
{
    uint8_t RequirementType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t MinQuantity; // 0x4 (Size: 0x4, Type: IntProperty)
    FString RequiredId; // 0x8 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FCatalogOfferRequirement) == 0x18, "Size mismatch for FCatalogOfferRequirement");
static_assert(offsetof(FCatalogOfferRequirement, RequirementType) == 0x0, "Offset mismatch for FCatalogOfferRequirement::RequirementType");
static_assert(offsetof(FCatalogOfferRequirement, MinQuantity) == 0x4, "Offset mismatch for FCatalogOfferRequirement::MinQuantity");
static_assert(offsetof(FCatalogOfferRequirement, RequiredId) == 0x8, "Offset mismatch for FCatalogOfferRequirement::RequiredId");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCatalogGiftInfo
{
    bool bIsEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FString ForcedGiftBoxTemplateId; // 0x8 (Size: 0x10, Type: StrProperty)
    TArray<FCatalogOfferRequirement> PurchaseRequirements; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCatalogGiftInfo) == 0x28, "Size mismatch for FCatalogGiftInfo");
static_assert(offsetof(FCatalogGiftInfo, bIsEnabled) == 0x0, "Offset mismatch for FCatalogGiftInfo::bIsEnabled");
static_assert(offsetof(FCatalogGiftInfo, ForcedGiftBoxTemplateId) == 0x8, "Offset mismatch for FCatalogGiftInfo::ForcedGiftBoxTemplateId");
static_assert(offsetof(FCatalogGiftInfo, PurchaseRequirements) == 0x18, "Offset mismatch for FCatalogGiftInfo::PurchaseRequirements");

// Size: 0x258 (Inherited: 0x0, Single: 0x258)
struct FCatalogOffer
{
    FString OfferId; // 0x0 (Size: 0x10, Type: StrProperty)
    FString DevName; // 0x10 (Size: 0x10, Type: StrProperty)
    TArray<FCatalogKeyValue> MetaInfo; // 0x20 (Size: 0x10, Type: ArrayProperty)
    uint8_t OfferType; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
    TArray<FCatalogItemPrice> Prices; // 0x38 (Size: 0x10, Type: ArrayProperty)
    FCatalogDynamicBundle DynamicBundleInfo; // 0x48 (Size: 0x38, Type: StructProperty)
    int32_t DailyLimit; // 0x80 (Size: 0x4, Type: IntProperty)
    int32_t WeeklyLimit; // 0x84 (Size: 0x4, Type: IntProperty)
    int32_t MonthlyLimit; // 0x88 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_8c[0x4]; // 0x8c (Size: 0x4, Type: PaddingProperty)
    TArray<FString> Categories; // 0x90 (Size: 0x10, Type: ArrayProperty)
    FString CatalogGroup; // 0xa0 (Size: 0x10, Type: StrProperty)
    int32_t CatalogGroupPriority; // 0xb0 (Size: 0x4, Type: IntProperty)
    int32_t SortPriority; // 0xb4 (Size: 0x4, Type: IntProperty)
    FText Title; // 0xb8 (Size: 0x10, Type: TextProperty)
    FText ShortDescription; // 0xc8 (Size: 0x10, Type: TextProperty)
    FText Description; // 0xd8 (Size: 0x10, Type: TextProperty)
    FString AppStoreId[0xd]; // 0xe8 (Size: 0xd0, Type: StrProperty)
    FCatalogMetaAssetInfo MetaAssetInfo; // 0x1b8 (Size: 0x30, Type: StructProperty)
    FString DisplayAssetPath; // 0x1e8 (Size: 0x10, Type: StrProperty)
    TArray<FItemQuantity> ItemGrants; // 0x1f8 (Size: 0x10, Type: ArrayProperty)
    TArray<FCatalogOfferRequirement> Requirements; // 0x208 (Size: 0x10, Type: ArrayProperty)
    FCatalogGiftInfo GiftInfo; // 0x218 (Size: 0x28, Type: StructProperty)
    bool Refundable; // 0x240 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_241[0x7]; // 0x241 (Size: 0x7, Type: PaddingProperty)
    TArray<FString> DenyItemTemplateIds; // 0x248 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCatalogOffer) == 0x258, "Size mismatch for FCatalogOffer");
static_assert(offsetof(FCatalogOffer, OfferId) == 0x0, "Offset mismatch for FCatalogOffer::OfferId");
static_assert(offsetof(FCatalogOffer, DevName) == 0x10, "Offset mismatch for FCatalogOffer::DevName");
static_assert(offsetof(FCatalogOffer, MetaInfo) == 0x20, "Offset mismatch for FCatalogOffer::MetaInfo");
static_assert(offsetof(FCatalogOffer, OfferType) == 0x30, "Offset mismatch for FCatalogOffer::OfferType");
static_assert(offsetof(FCatalogOffer, Prices) == 0x38, "Offset mismatch for FCatalogOffer::Prices");
static_assert(offsetof(FCatalogOffer, DynamicBundleInfo) == 0x48, "Offset mismatch for FCatalogOffer::DynamicBundleInfo");
static_assert(offsetof(FCatalogOffer, DailyLimit) == 0x80, "Offset mismatch for FCatalogOffer::DailyLimit");
static_assert(offsetof(FCatalogOffer, WeeklyLimit) == 0x84, "Offset mismatch for FCatalogOffer::WeeklyLimit");
static_assert(offsetof(FCatalogOffer, MonthlyLimit) == 0x88, "Offset mismatch for FCatalogOffer::MonthlyLimit");
static_assert(offsetof(FCatalogOffer, Categories) == 0x90, "Offset mismatch for FCatalogOffer::Categories");
static_assert(offsetof(FCatalogOffer, CatalogGroup) == 0xa0, "Offset mismatch for FCatalogOffer::CatalogGroup");
static_assert(offsetof(FCatalogOffer, CatalogGroupPriority) == 0xb0, "Offset mismatch for FCatalogOffer::CatalogGroupPriority");
static_assert(offsetof(FCatalogOffer, SortPriority) == 0xb4, "Offset mismatch for FCatalogOffer::SortPriority");
static_assert(offsetof(FCatalogOffer, Title) == 0xb8, "Offset mismatch for FCatalogOffer::Title");
static_assert(offsetof(FCatalogOffer, ShortDescription) == 0xc8, "Offset mismatch for FCatalogOffer::ShortDescription");
static_assert(offsetof(FCatalogOffer, Description) == 0xd8, "Offset mismatch for FCatalogOffer::Description");
static_assert(offsetof(FCatalogOffer, AppStoreId) == 0xe8, "Offset mismatch for FCatalogOffer::AppStoreId");
static_assert(offsetof(FCatalogOffer, MetaAssetInfo) == 0x1b8, "Offset mismatch for FCatalogOffer::MetaAssetInfo");
static_assert(offsetof(FCatalogOffer, DisplayAssetPath) == 0x1e8, "Offset mismatch for FCatalogOffer::DisplayAssetPath");
static_assert(offsetof(FCatalogOffer, ItemGrants) == 0x1f8, "Offset mismatch for FCatalogOffer::ItemGrants");
static_assert(offsetof(FCatalogOffer, Requirements) == 0x208, "Offset mismatch for FCatalogOffer::Requirements");
static_assert(offsetof(FCatalogOffer, GiftInfo) == 0x218, "Offset mismatch for FCatalogOffer::GiftInfo");
static_assert(offsetof(FCatalogOffer, Refundable) == 0x240, "Offset mismatch for FCatalogOffer::Refundable");
static_assert(offsetof(FCatalogOffer, DenyItemTemplateIds) == 0x248, "Offset mismatch for FCatalogOffer::DenyItemTemplateIds");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FStorefront
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    TArray<FCatalogOffer> CatalogEntries; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FStorefront) == 0x20, "Size mismatch for FStorefront");
static_assert(offsetof(FStorefront, Name) == 0x0, "Offset mismatch for FStorefront::Name");
static_assert(offsetof(FStorefront, CatalogEntries) == 0x10, "Offset mismatch for FStorefront::CatalogEntries");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCatalogDownload
{
    int32_t RefreshIntervalHrs; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t DailyPurchaseHrs; // 0x4 (Size: 0x4, Type: IntProperty)
    FDateTime Expiration; // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FStorefront> Storefronts; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCatalogDownload) == 0x20, "Size mismatch for FCatalogDownload");
static_assert(offsetof(FCatalogDownload, RefreshIntervalHrs) == 0x0, "Offset mismatch for FCatalogDownload::RefreshIntervalHrs");
static_assert(offsetof(FCatalogDownload, DailyPurchaseHrs) == 0x4, "Offset mismatch for FCatalogDownload::DailyPurchaseHrs");
static_assert(offsetof(FCatalogDownload, Expiration) == 0x8, "Offset mismatch for FCatalogDownload::Expiration");
static_assert(offsetof(FCatalogDownload, Storefronts) == 0x10, "Offset mismatch for FCatalogDownload::Storefronts");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCatalogPurchaseNotification
{
    FMcpLootResult LootResult; // 0x0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FCatalogPurchaseNotification) == 0x20, "Size mismatch for FCatalogPurchaseNotification");
static_assert(offsetof(FCatalogPurchaseNotification, LootResult) == 0x0, "Offset mismatch for FCatalogPurchaseNotification::LootResult");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FCatalogRefundNotification
{
};

static_assert(sizeof(FCatalogRefundNotification) == 0x1, "Size mismatch for FCatalogRefundNotification");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FMcpEntitlementRefreshTimerInfo
{
    FDateTime NextEntitlementRefresh; // 0x0 (Size: 0x8, Type: StructProperty)
    FDateTime MustRefreshAuthBy; // 0x8 (Size: 0x8, Type: StructProperty)
    FDateTime LastAuthRefresh; // 0x10 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(FMcpEntitlementRefreshTimerInfo) == 0x18, "Size mismatch for FMcpEntitlementRefreshTimerInfo");
static_assert(offsetof(FMcpEntitlementRefreshTimerInfo, NextEntitlementRefresh) == 0x0, "Offset mismatch for FMcpEntitlementRefreshTimerInfo::NextEntitlementRefresh");
static_assert(offsetof(FMcpEntitlementRefreshTimerInfo, MustRefreshAuthBy) == 0x8, "Offset mismatch for FMcpEntitlementRefreshTimerInfo::MustRefreshAuthBy");
static_assert(offsetof(FMcpEntitlementRefreshTimerInfo, LastAuthRefresh) == 0x10, "Offset mismatch for FMcpEntitlementRefreshTimerInfo::LastAuthRefresh");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FMcpSubscriptionEndAction
{
    FString UniqueSubscriptionId; // 0x0 (Size: 0x10, Type: StrProperty)
    FString SeasonTemplateId; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FMcpSubscriptionEndAction) == 0x20, "Size mismatch for FMcpSubscriptionEndAction");
static_assert(offsetof(FMcpSubscriptionEndAction, UniqueSubscriptionId) == 0x0, "Offset mismatch for FMcpSubscriptionEndAction::UniqueSubscriptionId");
static_assert(offsetof(FMcpSubscriptionEndAction, SeasonTemplateId) == 0x10, "Offset mismatch for FMcpSubscriptionEndAction::SeasonTemplateId");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FMcpProcessedConsumables
{
    uint8_t AppStore; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TArray<FString> Ids; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FMcpProcessedConsumables) == 0x18, "Size mismatch for FMcpProcessedConsumables");
static_assert(offsetof(FMcpProcessedConsumables, AppStore) == 0x0, "Offset mismatch for FMcpProcessedConsumables::AppStore");
static_assert(offsetof(FMcpProcessedConsumables, Ids) == 0x8, "Offset mismatch for FMcpProcessedConsumables::Ids");

// Size: 0xe0 (Inherited: 0x0, Single: 0xe0)
struct FMcpInAppPurchases
{
    TArray<FString> Fulfillments; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TMap<int32_t, FString> FulfillmentCounts; // 0x10 (Size: 0x50, Type: MapProperty)
    TArray<FMcpSubscriptionEndAction> SubscriptionEndActions; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TMap<FMcpEntitlementRefreshTimerInfo, EAppStore> RefreshTimers; // 0x70 (Size: 0x50, Type: MapProperty)
    TArray<FMcpProcessedConsumables> ProcessedConsumables; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TArray<ECheckpointToSendClientLogs> CheckpointToSendClientLogs; // 0xd0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FMcpInAppPurchases) == 0xe0, "Size mismatch for FMcpInAppPurchases");
static_assert(offsetof(FMcpInAppPurchases, Fulfillments) == 0x0, "Offset mismatch for FMcpInAppPurchases::Fulfillments");
static_assert(offsetof(FMcpInAppPurchases, FulfillmentCounts) == 0x10, "Offset mismatch for FMcpInAppPurchases::FulfillmentCounts");
static_assert(offsetof(FMcpInAppPurchases, SubscriptionEndActions) == 0x60, "Offset mismatch for FMcpInAppPurchases::SubscriptionEndActions");
static_assert(offsetof(FMcpInAppPurchases, RefreshTimers) == 0x70, "Offset mismatch for FMcpInAppPurchases::RefreshTimers");
static_assert(offsetof(FMcpInAppPurchases, ProcessedConsumables) == 0xc0, "Offset mismatch for FMcpInAppPurchases::ProcessedConsumables");
static_assert(offsetof(FMcpInAppPurchases, CheckpointToSendClientLogs) == 0xd0, "Offset mismatch for FMcpInAppPurchases::CheckpointToSendClientLogs");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FKeychainDownload
{
};

static_assert(sizeof(FKeychainDownload) == 0x10, "Size mismatch for FKeychainDownload");

