/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataAssetDirectory
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDataAssetDirectoryPatchableAsset : public UInterface
{
public:
};

static_assert(sizeof(UDataAssetDirectoryPatchableAsset) == 0x28, "Size mismatch for UDataAssetDirectoryPatchableAsset");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UDataAssetDirectorySimpleObject : public UObject
{
public:
    int32_t IntProperty; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDataAssetDirectorySimpleObject) == 0x30, "Size mismatch for UDataAssetDirectorySimpleObject");
static_assert(offsetof(UDataAssetDirectorySimpleObject, IntProperty) == 0x28, "Offset mismatch for UDataAssetDirectorySimpleObject::IntProperty");

// Size: 0x70 (Inherited: 0x28, Single: 0x48)
class UDataAssetDirectoryTestPODAsset : public UObject
{
public:
    FString AssetName; // 0x28 (Size: 0x10, Type: StrProperty)
    uint8_t EnumProperty; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_39[0x3]; // 0x39 (Size: 0x3, Type: PaddingProperty)
    int32_t IntProperty; // 0x3c (Size: 0x4, Type: IntProperty)
    float FloatProperty; // 0x40 (Size: 0x4, Type: FloatProperty)
    bool BoolProperty; // 0x44 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_45[0x3]; // 0x45 (Size: 0x3, Type: PaddingProperty)
    FString StringProperty; // 0x48 (Size: 0x10, Type: StrProperty)
    FName NameProperty; // 0x58 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
    FText TextProperty; // 0x60 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(UDataAssetDirectoryTestPODAsset) == 0x70, "Size mismatch for UDataAssetDirectoryTestPODAsset");
static_assert(offsetof(UDataAssetDirectoryTestPODAsset, AssetName) == 0x28, "Offset mismatch for UDataAssetDirectoryTestPODAsset::AssetName");
static_assert(offsetof(UDataAssetDirectoryTestPODAsset, EnumProperty) == 0x38, "Offset mismatch for UDataAssetDirectoryTestPODAsset::EnumProperty");
static_assert(offsetof(UDataAssetDirectoryTestPODAsset, IntProperty) == 0x3c, "Offset mismatch for UDataAssetDirectoryTestPODAsset::IntProperty");
static_assert(offsetof(UDataAssetDirectoryTestPODAsset, FloatProperty) == 0x40, "Offset mismatch for UDataAssetDirectoryTestPODAsset::FloatProperty");
static_assert(offsetof(UDataAssetDirectoryTestPODAsset, BoolProperty) == 0x44, "Offset mismatch for UDataAssetDirectoryTestPODAsset::BoolProperty");
static_assert(offsetof(UDataAssetDirectoryTestPODAsset, StringProperty) == 0x48, "Offset mismatch for UDataAssetDirectoryTestPODAsset::StringProperty");
static_assert(offsetof(UDataAssetDirectoryTestPODAsset, NameProperty) == 0x58, "Offset mismatch for UDataAssetDirectoryTestPODAsset::NameProperty");
static_assert(offsetof(UDataAssetDirectoryTestPODAsset, TextProperty) == 0x60, "Offset mismatch for UDataAssetDirectoryTestPODAsset::TextProperty");

// Size: 0x60 (Inherited: 0x28, Single: 0x38)
class UDataAssetDirectoryTestStructAsset : public UObject
{
public:
    FDataAssetDirectoryTestPODStruct TestStruct; // 0x28 (Size: 0x38, Type: StructProperty)
};

static_assert(sizeof(UDataAssetDirectoryTestStructAsset) == 0x60, "Size mismatch for UDataAssetDirectoryTestStructAsset");
static_assert(offsetof(UDataAssetDirectoryTestStructAsset, TestStruct) == 0x28, "Offset mismatch for UDataAssetDirectoryTestStructAsset::TestStruct");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UDataAssetDirectoryTestArrayAsset : public UObject
{
public:
    TArray<int32_t> IntArray; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FDataAssetDirectoryTestSimpleStruct> SimpleStructArray; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDataAssetDirectoryTestArrayAsset) == 0x48, "Size mismatch for UDataAssetDirectoryTestArrayAsset");
static_assert(offsetof(UDataAssetDirectoryTestArrayAsset, IntArray) == 0x28, "Offset mismatch for UDataAssetDirectoryTestArrayAsset::IntArray");
static_assert(offsetof(UDataAssetDirectoryTestArrayAsset, SimpleStructArray) == 0x38, "Offset mismatch for UDataAssetDirectoryTestArrayAsset::SimpleStructArray");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UDataAssetDirectoryTestObjectAsset : public UObject
{
public:
    UDataAssetDirectorySimpleObject* SimpleObject; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDataAssetDirectoryTestObjectAsset) == 0x30, "Size mismatch for UDataAssetDirectoryTestObjectAsset");
static_assert(offsetof(UDataAssetDirectoryTestObjectAsset, SimpleObject) == 0x28, "Offset mismatch for UDataAssetDirectoryTestObjectAsset::SimpleObject");

// Size: 0x168 (Inherited: 0x28, Single: 0x140)
class UDataAssetDirectoryTestMapAsset : public UObject
{
public:
    TMap<int32_t, FString> StringIntMap; // 0x28 (Size: 0x50, Type: MapProperty)
    TMap<int32_t, FString> ShrinkStringIntMap; // 0x78 (Size: 0x50, Type: MapProperty)
    TMap<int32_t, FString> GrowStringIntMap; // 0xc8 (Size: 0x50, Type: MapProperty)
    TMap<FDataAssetDirectoryTestSimpleStruct, int32_t> IntStructMap; // 0x118 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UDataAssetDirectoryTestMapAsset) == 0x168, "Size mismatch for UDataAssetDirectoryTestMapAsset");
static_assert(offsetof(UDataAssetDirectoryTestMapAsset, StringIntMap) == 0x28, "Offset mismatch for UDataAssetDirectoryTestMapAsset::StringIntMap");
static_assert(offsetof(UDataAssetDirectoryTestMapAsset, ShrinkStringIntMap) == 0x78, "Offset mismatch for UDataAssetDirectoryTestMapAsset::ShrinkStringIntMap");
static_assert(offsetof(UDataAssetDirectoryTestMapAsset, GrowStringIntMap) == 0xc8, "Offset mismatch for UDataAssetDirectoryTestMapAsset::GrowStringIntMap");
static_assert(offsetof(UDataAssetDirectoryTestMapAsset, IntStructMap) == 0x118, "Offset mismatch for UDataAssetDirectoryTestMapAsset::IntStructMap");

// Size: 0x1d0 (Inherited: 0x28, Single: 0x1a8)
class UDataAssetDirectoryManager : public UObject
{
public:
    uint8_t Pad_28[0x178]; // 0x28 (Size: 0x178, Type: PaddingProperty)
    TArray<UObject*> PatchedAssets; // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    FDateTime LastUpdateCheck; // 0x1b0 (Size: 0x8, Type: StructProperty)
    uint32_t UpdateCheckLimitSeconds; // 0x1b8 (Size: 0x4, Type: UInt32Property)
    bool bEnabled; // 0x1bc (Size: 0x1, Type: BoolProperty)
    bool bFailOnError; // 0x1bd (Size: 0x1, Type: BoolProperty)
    bool bAnalyticsEnabled; // 0x1be (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1bf[0x11]; // 0x1bf (Size: 0x11, Type: PaddingProperty)
};

static_assert(sizeof(UDataAssetDirectoryManager) == 0x1d0, "Size mismatch for UDataAssetDirectoryManager");
static_assert(offsetof(UDataAssetDirectoryManager, PatchedAssets) == 0x1a0, "Offset mismatch for UDataAssetDirectoryManager::PatchedAssets");
static_assert(offsetof(UDataAssetDirectoryManager, LastUpdateCheck) == 0x1b0, "Offset mismatch for UDataAssetDirectoryManager::LastUpdateCheck");
static_assert(offsetof(UDataAssetDirectoryManager, UpdateCheckLimitSeconds) == 0x1b8, "Offset mismatch for UDataAssetDirectoryManager::UpdateCheckLimitSeconds");
static_assert(offsetof(UDataAssetDirectoryManager, bEnabled) == 0x1bc, "Offset mismatch for UDataAssetDirectoryManager::bEnabled");
static_assert(offsetof(UDataAssetDirectoryManager, bFailOnError) == 0x1bd, "Offset mismatch for UDataAssetDirectoryManager::bFailOnError");
static_assert(offsetof(UDataAssetDirectoryManager, bAnalyticsEnabled) == 0x1be, "Offset mismatch for UDataAssetDirectoryManager::bAnalyticsEnabled");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDataAssetDirectoryPatcher : public UObject
{
public:
};

static_assert(sizeof(UDataAssetDirectoryPatcher) == 0x28, "Size mismatch for UDataAssetDirectoryPatcher");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FDataAssetDirectoryTestPODStruct
{
    uint8_t EnumProperty; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    int32_t IntProperty; // 0x4 (Size: 0x4, Type: IntProperty)
    float FloatProperty; // 0x8 (Size: 0x4, Type: FloatProperty)
    bool BoolProperty; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
    FString StringProperty; // 0x10 (Size: 0x10, Type: StrProperty)
    FName NameProperty; // 0x20 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    FText TextProperty; // 0x28 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FDataAssetDirectoryTestPODStruct) == 0x38, "Size mismatch for FDataAssetDirectoryTestPODStruct");
static_assert(offsetof(FDataAssetDirectoryTestPODStruct, EnumProperty) == 0x0, "Offset mismatch for FDataAssetDirectoryTestPODStruct::EnumProperty");
static_assert(offsetof(FDataAssetDirectoryTestPODStruct, IntProperty) == 0x4, "Offset mismatch for FDataAssetDirectoryTestPODStruct::IntProperty");
static_assert(offsetof(FDataAssetDirectoryTestPODStruct, FloatProperty) == 0x8, "Offset mismatch for FDataAssetDirectoryTestPODStruct::FloatProperty");
static_assert(offsetof(FDataAssetDirectoryTestPODStruct, BoolProperty) == 0xc, "Offset mismatch for FDataAssetDirectoryTestPODStruct::BoolProperty");
static_assert(offsetof(FDataAssetDirectoryTestPODStruct, StringProperty) == 0x10, "Offset mismatch for FDataAssetDirectoryTestPODStruct::StringProperty");
static_assert(offsetof(FDataAssetDirectoryTestPODStruct, NameProperty) == 0x20, "Offset mismatch for FDataAssetDirectoryTestPODStruct::NameProperty");
static_assert(offsetof(FDataAssetDirectoryTestPODStruct, TextProperty) == 0x28, "Offset mismatch for FDataAssetDirectoryTestPODStruct::TextProperty");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FDataAssetDirectoryTestSimpleStruct
{
    int32_t IntProperty; // 0x0 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FDataAssetDirectoryTestSimpleStruct) == 0x4, "Size mismatch for FDataAssetDirectoryTestSimpleStruct");
static_assert(offsetof(FDataAssetDirectoryTestSimpleStruct, IntProperty) == 0x0, "Offset mismatch for FDataAssetDirectoryTestSimpleStruct::IntProperty");

