/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayTags
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "DeveloperSettings.h"
#include "IrisCore.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlueprintGameplayTagLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void AddGameplayTag(FGameplayTagContainer TagContainer, FGameplayTag& Tag); // 0xa1a786c (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void AppendGameplayTagContainers(FGameplayTagContainer InOutTagContainer, const FGameplayTagContainer InTagContainer); // 0xa1a7bec (Index: 0x1, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void BreakGameplayTagContainer(const FGameplayTagContainer GameplayTagContainer, TArray<FGameplayTag>& GameplayTags); // 0x3404ed4 (Index: 0x2, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static TScriptInterface<Class> Conv_ObjectToGameplayTagAssetInterface(UObject*& InObject); // 0xa1a8040 (Index: 0x3, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool DoesContainerMatchTagQuery(const FGameplayTagContainer TagContainer, const FGameplayTagQuery TagQuery); // 0xa1a84c0 (Index: 0x4, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool DoesTagAssetInterfaceHaveTag(TScriptInterface<Class>& TagContainerInterface, FGameplayTag& Tag); // 0xa1a8a08 (Index: 0x5, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool EqualEqual_GameplayTag(FGameplayTag& A, FGameplayTag& B); // 0x4ce0740 (Index: 0x6, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool EqualEqual_GameplayTagContainer(const FGameplayTagContainer A, const FGameplayTagContainer B); // 0xa1a8d60 (Index: 0x7, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayTagContainer Filter(const FGameplayTagContainer TagContainer, const FGameplayTagContainer OtherContainer, bool& bExactMatch); // 0xa1a91bc (Index: 0x8, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void GetAllActorsOfClassMatchingTagQuery(UObject*& WorldContextObject, UClass*& ActorClass, const FGameplayTagQuery GameplayTagQuery, TArray<AActor*>& OutActors); // 0xa1a96d8 (Index: 0x9, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FString GetDebugStringFromGameplayTag(FGameplayTag& GameplayTag); // 0xa1a9bd8 (Index: 0xa, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FString GetDebugStringFromGameplayTagContainer(const FGameplayTagContainer TagContainer); // 0xa1a9e5c (Index: 0xb, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static int32_t GetNumGameplayTagsInContainer(const FGameplayTagContainer TagContainer); // 0x3407ae8 (Index: 0xc, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayTagContainer GetOwnedGameplayTags(TScriptInterface<Class>& TagContainerInterface); // 0x34ece90 (Index: 0xd, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FName GetTagName(const FGameplayTag GameplayTag); // 0x605b89c (Index: 0xe, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool HasAllMatchingGameplayTags(TScriptInterface<Class>& TagContainerInterface, const FGameplayTagContainer OtherContainer); // 0xa1aa514 (Index: 0xf, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool HasAllTags(const FGameplayTagContainer TagContainer, const FGameplayTagContainer OtherContainer, bool& bExactMatch); // 0x52a26bc (Index: 0x10, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool HasAnyTags(const FGameplayTagContainer TagContainer, const FGameplayTagContainer OtherContainer, bool& bExactMatch); // 0x4f2b170 (Index: 0x11, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool HasTag(const FGameplayTagContainer TagContainer, FGameplayTag& Tag, bool& bExactMatch); // 0x3406690 (Index: 0x12, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsGameplayTagValid(FGameplayTag& GameplayTag); // 0x504d09c (Index: 0x13, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsTagQueryEmpty(const FGameplayTagQuery TagQuery); // 0xa1aaacc (Index: 0x14, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayTagContainer MakeGameplayTagContainerFromArray(const TArray<FGameplayTag> GameplayTags); // 0xa1aae88 (Index: 0x15, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayTagContainer MakeGameplayTagContainerFromTag(FGameplayTag& SingleTag); // 0x553d77c (Index: 0x16, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGameplayTagQuery MakeGameplayTagQuery(FGameplayTagQuery& TagQuery); // 0xa1ab144 (Index: 0x17, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGameplayTagQuery MakeGameplayTagQuery_MatchAllTags(const FGameplayTagContainer InTags); // 0xa1ab52c (Index: 0x18, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayTagQuery MakeGameplayTagQuery_MatchAnyTags(const FGameplayTagContainer InTags); // 0xa1ab85c (Index: 0x19, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayTagQuery MakeGameplayTagQuery_MatchNoTags(const FGameplayTagContainer InTags); // 0xa1abb8c (Index: 0x1a, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayTag MakeLiteralGameplayTag(FGameplayTag& Value); // 0x5380bf0 (Index: 0x1b, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FGameplayTagContainer MakeLiteralGameplayTagContainer(FGameplayTagContainer& Value); // 0x5873a3c (Index: 0x1c, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool MatchesAnyTags(FGameplayTag& TagOne, const FGameplayTagContainer OtherContainer, bool& bExactMatch); // 0xa1abebc (Index: 0x1d, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool MatchesTag(FGameplayTag& TagOne, FGameplayTag& TagTwo, bool& bExactMatch); // 0x47a7a78 (Index: 0x1e, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool NotEqual_GameplayTag(FGameplayTag& A, FGameplayTag& B); // 0x5500bc8 (Index: 0x1f, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool NotEqual_GameplayTagContainer(const FGameplayTagContainer A, const FGameplayTagContainer B); // 0xa1ac2b8 (Index: 0x20, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool NotEqual_TagContainerTagContainer(FGameplayTagContainer& A, FString& B); // 0x5448690 (Index: 0x21, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool NotEqual_TagTag(FGameplayTag& A, FString& B); // 0x34c51dc (Index: 0x22, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool RemoveGameplayTag(FGameplayTagContainer TagContainer, FGameplayTag& Tag); // 0xa1ac718 (Index: 0x23, Flags: Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UBlueprintGameplayTagLibrary) == 0x28, "Size mismatch for UBlueprintGameplayTagLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameplayTagAssetInterface : public UInterface
{
public:

public:
    bool HasAllMatchingGameplayTags(const FGameplayTagContainer TagContainer) const; // 0xa1aa1f4 (Index: 0x1, Flags: RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool HasAnyMatchingGameplayTags(const FGameplayTagContainer TagContainer) const; // 0x52b9ccc (Index: 0x2, Flags: RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool HasMatchingGameplayTag(FGameplayTag& TagToCheck) const; // 0x4329d08 (Index: 0x3, Flags: RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    FGameplayTagContainer BP_GetOwnedGameplayTags() const; // 0x34ec6b0 (Index: 0x0, Flags: RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UGameplayTagAssetInterface) == 0x28, "Size mismatch for UGameplayTagAssetInterface");

// Size: 0x98 (Inherited: 0x28, Single: 0x70)
class UEditableGameplayTagQuery : public UObject
{
public:
    FString UserDescription; // 0x28 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_38[0x10]; // 0x38 (Size: 0x10, Type: PaddingProperty)
    UEditableGameplayTagQueryExpression* RootExpression; // 0x48 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagQuery TagQueryExportText_Helper; // 0x50 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UEditableGameplayTagQuery) == 0x98, "Size mismatch for UEditableGameplayTagQuery");
static_assert(offsetof(UEditableGameplayTagQuery, UserDescription) == 0x28, "Offset mismatch for UEditableGameplayTagQuery::UserDescription");
static_assert(offsetof(UEditableGameplayTagQuery, RootExpression) == 0x48, "Offset mismatch for UEditableGameplayTagQuery::RootExpression");
static_assert(offsetof(UEditableGameplayTagQuery, TagQueryExportText_Helper) == 0x50, "Offset mismatch for UEditableGameplayTagQuery::TagQueryExportText_Helper");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UEditableGameplayTagQueryExpression : public UObject
{
public:
};

static_assert(sizeof(UEditableGameplayTagQueryExpression) == 0x28, "Size mismatch for UEditableGameplayTagQueryExpression");

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UEditableGameplayTagQueryExpression_AnyTagsMatch : public UEditableGameplayTagQueryExpression
{
public:
    FGameplayTagContainer Tags; // 0x28 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UEditableGameplayTagQueryExpression_AnyTagsMatch) == 0x48, "Size mismatch for UEditableGameplayTagQueryExpression_AnyTagsMatch");
static_assert(offsetof(UEditableGameplayTagQueryExpression_AnyTagsMatch, Tags) == 0x28, "Offset mismatch for UEditableGameplayTagQueryExpression_AnyTagsMatch::Tags");

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UEditableGameplayTagQueryExpression_AllTagsMatch : public UEditableGameplayTagQueryExpression
{
public:
    FGameplayTagContainer Tags; // 0x28 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UEditableGameplayTagQueryExpression_AllTagsMatch) == 0x48, "Size mismatch for UEditableGameplayTagQueryExpression_AllTagsMatch");
static_assert(offsetof(UEditableGameplayTagQueryExpression_AllTagsMatch, Tags) == 0x28, "Offset mismatch for UEditableGameplayTagQueryExpression_AllTagsMatch::Tags");

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UEditableGameplayTagQueryExpression_NoTagsMatch : public UEditableGameplayTagQueryExpression
{
public:
    FGameplayTagContainer Tags; // 0x28 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UEditableGameplayTagQueryExpression_NoTagsMatch) == 0x48, "Size mismatch for UEditableGameplayTagQueryExpression_NoTagsMatch");
static_assert(offsetof(UEditableGameplayTagQueryExpression_NoTagsMatch, Tags) == 0x28, "Offset mismatch for UEditableGameplayTagQueryExpression_NoTagsMatch::Tags");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UEditableGameplayTagQueryExpression_AnyExprMatch : public UEditableGameplayTagQueryExpression
{
public:
    TArray<UEditableGameplayTagQueryExpression*> Expressions; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UEditableGameplayTagQueryExpression_AnyExprMatch) == 0x38, "Size mismatch for UEditableGameplayTagQueryExpression_AnyExprMatch");
static_assert(offsetof(UEditableGameplayTagQueryExpression_AnyExprMatch, Expressions) == 0x28, "Offset mismatch for UEditableGameplayTagQueryExpression_AnyExprMatch::Expressions");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UEditableGameplayTagQueryExpression_AllExprMatch : public UEditableGameplayTagQueryExpression
{
public:
    TArray<UEditableGameplayTagQueryExpression*> Expressions; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UEditableGameplayTagQueryExpression_AllExprMatch) == 0x38, "Size mismatch for UEditableGameplayTagQueryExpression_AllExprMatch");
static_assert(offsetof(UEditableGameplayTagQueryExpression_AllExprMatch, Expressions) == 0x28, "Offset mismatch for UEditableGameplayTagQueryExpression_AllExprMatch::Expressions");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UEditableGameplayTagQueryExpression_NoExprMatch : public UEditableGameplayTagQueryExpression
{
public:
    TArray<UEditableGameplayTagQueryExpression*> Expressions; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UEditableGameplayTagQueryExpression_NoExprMatch) == 0x38, "Size mismatch for UEditableGameplayTagQueryExpression_NoExprMatch");
static_assert(offsetof(UEditableGameplayTagQueryExpression_NoExprMatch, Expressions) == 0x28, "Offset mismatch for UEditableGameplayTagQueryExpression_NoExprMatch::Expressions");

// Size: 0x2a0 (Inherited: 0x28, Single: 0x278)
class UGameplayTagsManager : public UObject
{
public:
    uint8_t Pad_28[0x160]; // 0x28 (Size: 0x160, Type: PaddingProperty)
    TMap<FGameplayTagSource, FName> TagSources; // 0x188 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_1d8[0xb8]; // 0x1d8 (Size: 0xb8, Type: PaddingProperty)
    TArray<UDataTable*> GameplayTagTables; // 0x290 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGameplayTagsManager) == 0x2a0, "Size mismatch for UGameplayTagsManager");
static_assert(offsetof(UGameplayTagsManager, TagSources) == 0x188, "Offset mismatch for UGameplayTagsManager::TagSources");
static_assert(offsetof(UGameplayTagsManager, GameplayTagTables) == 0x290, "Offset mismatch for UGameplayTagsManager::GameplayTagTables");

// Size: 0x58 (Inherited: 0x28, Single: 0x30)
class UGameplayTagsList : public UObject
{
public:
    FString ConfigFileName; // 0x28 (Size: 0x10, Type: StrProperty)
    TArray<FGameplayTagRedirect> GameplayTagRedirects; // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayTagTableRow> GameplayTagList; // 0x48 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGameplayTagsList) == 0x58, "Size mismatch for UGameplayTagsList");
static_assert(offsetof(UGameplayTagsList, ConfigFileName) == 0x28, "Offset mismatch for UGameplayTagsList::ConfigFileName");
static_assert(offsetof(UGameplayTagsList, GameplayTagRedirects) == 0x38, "Offset mismatch for UGameplayTagsList::GameplayTagRedirects");
static_assert(offsetof(UGameplayTagsList, GameplayTagList) == 0x48, "Offset mismatch for UGameplayTagsList::GameplayTagList");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class URestrictedGameplayTagsList : public UObject
{
public:
    FString ConfigFileName; // 0x28 (Size: 0x10, Type: StrProperty)
    TArray<FRestrictedGameplayTagTableRow> RestrictedGameplayTagList; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(URestrictedGameplayTagsList) == 0x48, "Size mismatch for URestrictedGameplayTagsList");
static_assert(offsetof(URestrictedGameplayTagsList, ConfigFileName) == 0x28, "Offset mismatch for URestrictedGameplayTagsList::ConfigFileName");
static_assert(offsetof(URestrictedGameplayTagsList, RestrictedGameplayTagList) == 0x38, "Offset mismatch for URestrictedGameplayTagsList::RestrictedGameplayTagList");

// Size: 0xb8 (Inherited: 0x80, Single: 0x38)
class UGameplayTagsSettings : public UGameplayTagsList
{
public:
    bool ImportTagsFromConfig; // 0x58 (Size: 0x1, Type: BoolProperty)
    bool WarnOnInvalidTags; // 0x59 (Size: 0x1, Type: BoolProperty)
    bool ClearInvalidTags; // 0x5a (Size: 0x1, Type: BoolProperty)
    bool AllowEditorTagUnloading; // 0x5b (Size: 0x1, Type: BoolProperty)
    bool AllowGameTagUnloading; // 0x5c (Size: 0x1, Type: BoolProperty)
    bool FastReplication; // 0x5d (Size: 0x1, Type: BoolProperty)
    bool bDynamicReplication; // 0x5e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5f[0x1]; // 0x5f (Size: 0x1, Type: PaddingProperty)
    FString InvalidTagCharacters; // 0x60 (Size: 0x10, Type: StrProperty)
    TArray<FGameplayTagCategoryRemap> CategoryRemapping; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FSoftObjectPath> GameplayTagTableList; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> CommonlyReplicatedTags; // 0x90 (Size: 0x10, Type: ArrayProperty)
    int32_t NumBitsForContainerSize; // 0xa0 (Size: 0x4, Type: IntProperty)
    int32_t NetIndexFirstBitSegment; // 0xa4 (Size: 0x4, Type: IntProperty)
    TArray<FRestrictedConfigInfo> RestrictedConfigFiles; // 0xa8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGameplayTagsSettings) == 0xb8, "Size mismatch for UGameplayTagsSettings");
static_assert(offsetof(UGameplayTagsSettings, ImportTagsFromConfig) == 0x58, "Offset mismatch for UGameplayTagsSettings::ImportTagsFromConfig");
static_assert(offsetof(UGameplayTagsSettings, WarnOnInvalidTags) == 0x59, "Offset mismatch for UGameplayTagsSettings::WarnOnInvalidTags");
static_assert(offsetof(UGameplayTagsSettings, ClearInvalidTags) == 0x5a, "Offset mismatch for UGameplayTagsSettings::ClearInvalidTags");
static_assert(offsetof(UGameplayTagsSettings, AllowEditorTagUnloading) == 0x5b, "Offset mismatch for UGameplayTagsSettings::AllowEditorTagUnloading");
static_assert(offsetof(UGameplayTagsSettings, AllowGameTagUnloading) == 0x5c, "Offset mismatch for UGameplayTagsSettings::AllowGameTagUnloading");
static_assert(offsetof(UGameplayTagsSettings, FastReplication) == 0x5d, "Offset mismatch for UGameplayTagsSettings::FastReplication");
static_assert(offsetof(UGameplayTagsSettings, bDynamicReplication) == 0x5e, "Offset mismatch for UGameplayTagsSettings::bDynamicReplication");
static_assert(offsetof(UGameplayTagsSettings, InvalidTagCharacters) == 0x60, "Offset mismatch for UGameplayTagsSettings::InvalidTagCharacters");
static_assert(offsetof(UGameplayTagsSettings, CategoryRemapping) == 0x70, "Offset mismatch for UGameplayTagsSettings::CategoryRemapping");
static_assert(offsetof(UGameplayTagsSettings, GameplayTagTableList) == 0x80, "Offset mismatch for UGameplayTagsSettings::GameplayTagTableList");
static_assert(offsetof(UGameplayTagsSettings, CommonlyReplicatedTags) == 0x90, "Offset mismatch for UGameplayTagsSettings::CommonlyReplicatedTags");
static_assert(offsetof(UGameplayTagsSettings, NumBitsForContainerSize) == 0xa0, "Offset mismatch for UGameplayTagsSettings::NumBitsForContainerSize");
static_assert(offsetof(UGameplayTagsSettings, NetIndexFirstBitSegment) == 0xa4, "Offset mismatch for UGameplayTagsSettings::NetIndexFirstBitSegment");
static_assert(offsetof(UGameplayTagsSettings, RestrictedConfigFiles) == 0xa8, "Offset mismatch for UGameplayTagsSettings::RestrictedConfigFiles");

// Size: 0x48 (Inherited: 0x58, Single: 0xfffffff0)
class UGameplayTagsDeveloperSettings : public UDeveloperSettings
{
public:
    FString DeveloperConfigName; // 0x30 (Size: 0x10, Type: StrProperty)
    FName FavoriteTagSource; // 0x40 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UGameplayTagsDeveloperSettings) == 0x48, "Size mismatch for UGameplayTagsDeveloperSettings");
static_assert(offsetof(UGameplayTagsDeveloperSettings, DeveloperConfigName) == 0x30, "Offset mismatch for UGameplayTagsDeveloperSettings::DeveloperConfigName");
static_assert(offsetof(UGameplayTagsDeveloperSettings, FavoriteTagSource) == 0x40, "Offset mismatch for UGameplayTagsDeveloperSettings::FavoriteTagSource");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FGameplayTag
{
    FName TagName; // 0x0 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FGameplayTag) == 0x4, "Size mismatch for FGameplayTag");
static_assert(offsetof(FGameplayTag, TagName) == 0x0, "Offset mismatch for FGameplayTag::TagName");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGameplayTagContainer
{
    TArray<FGameplayTag> GameplayTags; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayTag> ParentTags; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayTagContainer) == 0x20, "Size mismatch for FGameplayTagContainer");
static_assert(offsetof(FGameplayTagContainer, GameplayTags) == 0x0, "Offset mismatch for FGameplayTagContainer::GameplayTags");
static_assert(offsetof(FGameplayTagContainer, ParentTags) == 0x10, "Offset mismatch for FGameplayTagContainer::ParentTags");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FGameplayTagQuery
{
    int32_t TokenStreamVersion; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FGameplayTag> TagDictionary; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<char> QueryTokenStream; // 0x18 (Size: 0x10, Type: ArrayProperty)
    FString UserDescription; // 0x28 (Size: 0x10, Type: StrProperty)
    FString AutoDescription; // 0x38 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FGameplayTagQuery) == 0x48, "Size mismatch for FGameplayTagQuery");
static_assert(offsetof(FGameplayTagQuery, TokenStreamVersion) == 0x0, "Offset mismatch for FGameplayTagQuery::TokenStreamVersion");
static_assert(offsetof(FGameplayTagQuery, TagDictionary) == 0x8, "Offset mismatch for FGameplayTagQuery::TagDictionary");
static_assert(offsetof(FGameplayTagQuery, QueryTokenStream) == 0x18, "Offset mismatch for FGameplayTagQuery::QueryTokenStream");
static_assert(offsetof(FGameplayTagQuery, UserDescription) == 0x28, "Offset mismatch for FGameplayTagQuery::UserDescription");
static_assert(offsetof(FGameplayTagQuery, AutoDescription) == 0x38, "Offset mismatch for FGameplayTagQuery::AutoDescription");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayTagContainerNetSerializerSerializationHelper
{
    TArray<FGameplayTag> GameplayTags; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayTagContainerNetSerializerSerializationHelper) == 0x10, "Size mismatch for FGameplayTagContainerNetSerializerSerializationHelper");
static_assert(offsetof(FGameplayTagContainerNetSerializerSerializationHelper, GameplayTags) == 0x0, "Offset mismatch for FGameplayTagContainerNetSerializerSerializationHelper::GameplayTags");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FGameplayTagCreationWidgetHelper
{
};

static_assert(sizeof(FGameplayTagCreationWidgetHelper) == 0x1, "Size mismatch for FGameplayTagCreationWidgetHelper");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FGameplayTagContainerNetSerializerConfig : FNetSerializerConfig
{
};

static_assert(sizeof(FGameplayTagContainerNetSerializerConfig) == 0x10, "Size mismatch for FGameplayTagContainerNetSerializerConfig");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FGameplayTagNetSerializerConfig : FNetSerializerConfig
{
};

static_assert(sizeof(FGameplayTagNetSerializerConfig) == 0x10, "Size mismatch for FGameplayTagNetSerializerConfig");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGameplayTagRedirect
{
    FName OldTagName; // 0x0 (Size: 0x4, Type: NameProperty)
    FName NewTagName; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FGameplayTagRedirect) == 0x8, "Size mismatch for FGameplayTagRedirect");
static_assert(offsetof(FGameplayTagRedirect, OldTagName) == 0x0, "Offset mismatch for FGameplayTagRedirect::OldTagName");
static_assert(offsetof(FGameplayTagRedirect, NewTagName) == 0x4, "Offset mismatch for FGameplayTagRedirect::NewTagName");

// Size: 0x20 (Inherited: 0x8, Single: 0x18)
struct FGameplayTagTableRow : FTableRowBase
{
    FName Tag; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FString DevComment; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FGameplayTagTableRow) == 0x20, "Size mismatch for FGameplayTagTableRow");
static_assert(offsetof(FGameplayTagTableRow, Tag) == 0x8, "Offset mismatch for FGameplayTagTableRow::Tag");
static_assert(offsetof(FGameplayTagTableRow, DevComment) == 0x10, "Offset mismatch for FGameplayTagTableRow::DevComment");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
struct FRestrictedGameplayTagTableRow : FGameplayTagTableRow
{
    bool bAllowNonRestrictedChildren; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FRestrictedGameplayTagTableRow) == 0x28, "Size mismatch for FRestrictedGameplayTagTableRow");
static_assert(offsetof(FRestrictedGameplayTagTableRow, bAllowNonRestrictedChildren) == 0x20, "Offset mismatch for FRestrictedGameplayTagTableRow::bAllowNonRestrictedChildren");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameplayTagSource
{
    FName SourceName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t SourceType; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    UGameplayTagsList* SourceTagList; // 0x8 (Size: 0x8, Type: ObjectProperty)
    URestrictedGameplayTagsList* SourceRestrictedTagList; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGameplayTagSource) == 0x18, "Size mismatch for FGameplayTagSource");
static_assert(offsetof(FGameplayTagSource, SourceName) == 0x0, "Offset mismatch for FGameplayTagSource::SourceName");
static_assert(offsetof(FGameplayTagSource, SourceType) == 0x4, "Offset mismatch for FGameplayTagSource::SourceType");
static_assert(offsetof(FGameplayTagSource, SourceTagList) == 0x8, "Offset mismatch for FGameplayTagSource::SourceTagList");
static_assert(offsetof(FGameplayTagSource, SourceRestrictedTagList) == 0x10, "Offset mismatch for FGameplayTagSource::SourceRestrictedTagList");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FGameplayTagNode
{
};

static_assert(sizeof(FGameplayTagNode) == 0x50, "Size mismatch for FGameplayTagNode");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGameplayTagCategoryRemap
{
    FString BaseCategory; // 0x0 (Size: 0x10, Type: StrProperty)
    TArray<FString> RemapCategories; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayTagCategoryRemap) == 0x20, "Size mismatch for FGameplayTagCategoryRemap");
static_assert(offsetof(FGameplayTagCategoryRemap, BaseCategory) == 0x0, "Offset mismatch for FGameplayTagCategoryRemap::BaseCategory");
static_assert(offsetof(FGameplayTagCategoryRemap, RemapCategories) == 0x10, "Offset mismatch for FGameplayTagCategoryRemap::RemapCategories");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FRestrictedConfigInfo
{
    FString RestrictedConfigName; // 0x0 (Size: 0x10, Type: StrProperty)
    TArray<FString> Owners; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FRestrictedConfigInfo) == 0x20, "Size mismatch for FRestrictedConfigInfo");
static_assert(offsetof(FRestrictedConfigInfo, RestrictedConfigName) == 0x0, "Offset mismatch for FRestrictedConfigInfo::RestrictedConfigName");
static_assert(offsetof(FRestrictedConfigInfo, Owners) == 0x10, "Offset mismatch for FRestrictedConfigInfo::Owners");

