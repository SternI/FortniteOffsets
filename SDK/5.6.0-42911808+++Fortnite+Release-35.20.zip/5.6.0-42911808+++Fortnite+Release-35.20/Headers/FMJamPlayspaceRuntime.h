/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamPlayspaceRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameFeatures.h"
#include "FortniteGame.h"
#include "SparksMusicPlayspaceRuntime.h"
#include "PlayspaceSystem.h"
#include "ModularGameplay.h"
#include "NetCore.h"
#include "GameplayTags.h"
#include "FMJamCatalogRuntime.h"
#include "SparksMidiParser.h"
#include "GameplayAbilities.h"
#include "GameplayEventRouter.h"
#include "SparksCMS.h"
#include "SparksCoreCosmeticsRuntime.h"
#include "FMJamContentResolver.h"
#include "HarmonixDsp.h"
#include "Niagara.h"
#include "HarmonixMidi.h"

// Size: 0x100 (Inherited: 0xe0, Single: 0x20)
class UAddAbilitySetToOverlappingActorsComponent : public UActorComponent
{
public:
    TArray<TSoftObjectPtr<UFortAbilitySet*>> AbilitySetsToAdd; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_c8[0x38]; // 0xc8 (Size: 0x38, Type: PaddingProperty)

private:
    void OnOwningActorBeganOverlap(AActor*& OwningActor, AActor*& OtherActor); // 0x107a5d5c (Index: 0x0, Flags: Final|Native|Private)
    void OnOwningActorEndedOverlap(AActor*& OwningActor, AActor*& OtherActor); // 0x107a5f64 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UAddAbilitySetToOverlappingActorsComponent) == 0x100, "Size mismatch for UAddAbilitySetToOverlappingActorsComponent");
static_assert(offsetof(UAddAbilitySetToOverlappingActorsComponent, AbilitySetsToAdd) == 0xb8, "Offset mismatch for UAddAbilitySetToOverlappingActorsComponent::AbilitySetsToAdd");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEnhancedInputHelpers : public UBlueprintFunctionLibrary
{
public:

public:
    static void ClearAndRemoveInputComponentForPlayer(UInputComponent* TheInputComponent, APlayerController*& TheController); // 0x107a3804 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void CreateOrApplyInputComponentForPlayer(UInputComponent* TheInputComponent, bool& bUseEnhancedInput, UObject*& ContextObject, APlayerController*& TheController); // 0x107a3d14 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UEnhancedInputHelpers) == 0x28, "Size mismatch for UEnhancedInputHelpers");

// Size: 0xf8 (Inherited: 0x50, Single: 0xa8)
class UFortGameFeatureAction_AddAbilitiesToPlayspaceUsers : public UGameFeatureAction
{
public:
    FGameplayTagQuery PlayspaceTagQuery; // 0x28 (Size: 0x48, Type: StructProperty)
    TSoftClassPtr PlayspaceClass; // 0x70 (Size: 0x20, Type: SoftClassProperty)
    TArray<TSoftObjectPtr<UFortAbilitySet*>> AbilitySetsToAdd; // 0x90 (Size: 0x10, Type: ArrayProperty)
    uint8_t CVarCondition[0x20]; // 0xa0 (Size: 0x20, Type: OptionalProperty)
    uint8_t Pad_c0[0x38]; // 0xc0 (Size: 0x38, Type: PaddingProperty)
};

static_assert(sizeof(UFortGameFeatureAction_AddAbilitiesToPlayspaceUsers) == 0xf8, "Size mismatch for UFortGameFeatureAction_AddAbilitiesToPlayspaceUsers");
static_assert(offsetof(UFortGameFeatureAction_AddAbilitiesToPlayspaceUsers, PlayspaceTagQuery) == 0x28, "Offset mismatch for UFortGameFeatureAction_AddAbilitiesToPlayspaceUsers::PlayspaceTagQuery");
static_assert(offsetof(UFortGameFeatureAction_AddAbilitiesToPlayspaceUsers, PlayspaceClass) == 0x70, "Offset mismatch for UFortGameFeatureAction_AddAbilitiesToPlayspaceUsers::PlayspaceClass");
static_assert(offsetof(UFortGameFeatureAction_AddAbilitiesToPlayspaceUsers, AbilitySetsToAdd) == 0x90, "Offset mismatch for UFortGameFeatureAction_AddAbilitiesToPlayspaceUsers::AbilitySetsToAdd");
static_assert(offsetof(UFortGameFeatureAction_AddAbilitiesToPlayspaceUsers, CVarCondition) == 0xa0, "Offset mismatch for UFortGameFeatureAction_AddAbilitiesToPlayspaceUsers::CVarCondition");

// Size: 0x180 (Inherited: 0x310, Single: 0xfffffe70)
class UJamAnalytics : public UFortControllerComponent
{
public:
    uint8_t Pad_c0[0x40]; // 0xc0 (Size: 0x40, Type: PaddingProperty)
    FScalableFloat MinLoopLength; // 0x100 (Size: 0x28, Type: StructProperty)
    AJamPlayspace* JamPlayspace; // 0x128 (Size: 0x8, Type: ObjectProperty)
    TMap<float, int32_t> LoopStartTimes; // 0x130 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UJamAnalytics) == 0x180, "Size mismatch for UJamAnalytics");
static_assert(offsetof(UJamAnalytics, MinLoopLength) == 0x100, "Offset mismatch for UJamAnalytics::MinLoopLength");
static_assert(offsetof(UJamAnalytics, JamPlayspace) == 0x128, "Offset mismatch for UJamAnalytics::JamPlayspace");
static_assert(offsetof(UJamAnalytics, LoopStartTimes) == 0x130, "Offset mismatch for UJamAnalytics::LoopStartTimes");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UJamMidiEventDriver : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TWeakObjectPtr<UJamMusicSlot*> WeakOwningMusicSlotPtr; // 0x30 (Size: 0x8, Type: WeakObjectProperty)
    UParsedMidiEventData* ParsedMidiEventData; // 0x38 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_40[0x8]; // 0x40 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UJamMidiEventDriver) == 0x48, "Size mismatch for UJamMidiEventDriver");
static_assert(offsetof(UJamMidiEventDriver, WeakOwningMusicSlotPtr) == 0x30, "Offset mismatch for UJamMidiEventDriver::WeakOwningMusicSlotPtr");
static_assert(offsetof(UJamMidiEventDriver, ParsedMidiEventData) == 0x38, "Offset mismatch for UJamMidiEventDriver::ParsedMidiEventData");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UJamPlayParamsUtilities : public UBlueprintFunctionLibrary
{
public:

public:
    static FGameplayTag GetJamStartedByQuickJoinTag(); // 0x107a4844 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FLinearColor GetLoopColorFromPlayParams(const FJamPlayParams PlayParams); // 0x107a4898 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static APlayerController* GetOwningPlayerControllerFromPlayParams(UObject*& WorldContext, const FJamPlayParams PlayParams); // 0x107a4ecc (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static APawn* GetOwningPlayerPawnFromPlayParams(UObject*& WorldContext, const FJamPlayParams PlayParams); // 0x107a50e0 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static APlayerState* GetOwningPlayerStateFromPlayParams(UObject*& WorldContext, const FJamPlayParams PlayParams); // 0x107a54e0 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UJamPlayParamsUtilities) == 0x28, "Size mismatch for UJamPlayParamsUtilities");

// Size: 0x828 (Inherited: 0x1990, Single: 0xffffee98)
class AJamPlayspace : public ASparksMusicPlayspace
{
public:
    uint8_t Pad_750[0x28]; // 0x750 (Size: 0x28, Type: PaddingProperty)
    UJamPlayspaceComponent_MusicManager* MusicManager; // 0x778 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_780[0x18]; // 0x780 (Size: 0x18, Type: PaddingProperty)
    UJamPlayspaceComponent_ReactiveFX* ReactiveFXComponent; // 0x798 (Size: 0x8, Type: ObjectProperty)
    UPlayspaceComponent_DispatchExternallyReachable* ExternalReachabilityComponent; // 0x7a0 (Size: 0x8, Type: ObjectProperty)
    FGuid JamSessionGuid; // 0x7a8 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_7b8[0x70]; // 0x7b8 (Size: 0x70, Type: PaddingProperty)

public:
    virtual void BeginShutdownJam(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    void ConvertPlayerToAutoJammer(const FUniqueNetIdRepl PlayerNetId); // 0x107a3af0 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    int32_t CountActiveLoopsWithParams(const FJamMusicSlotSearchParams SearchParams) const; // 0x107a3c14 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool DoAnyOtherJammersHaveGameplayTag(const FUniqueNetIdRepl LocalPlayerNetId, FGameplayTag& GlobalControlsTag) const; // 0x107a4118 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetAllowGlobalControlAccess(bool& OutAllowGlobalControlAccess, FGameplayTagContainer& OutRestrictionReason) const; // 0x107a42c4 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TSoftObjectPtr<UTexture2D*> GetAutoJammerProfilPic() const; // 0x107a4658 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFMJamLoopType GetFirstUnusedLoopType(bool& const bGuaranteeFullList); // 0x107a46a0 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    virtual UAudioComponent* GetJamAudioSource(); // 0x107a47dc (Index: 0x7, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
    TArray<FUniqueNetIdRepl> GetJammers() const; // 0x107a485c (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    AJamPlayspaceVolume* GetJamPlayspaceVolume() const; // 0x107a4804 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGuid GetJamSessionGuid() const; // 0x107a4828 (Index: 0xa, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    UJamMusicSlot* GetMusicSlotForPlayer(const FUniqueNetIdRepl PlayerNetId) const; // 0x107a49e0 (Index: 0xb, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TArray<UJamMusicSlot*> GetMusicSlots() const; // 0x107a4b08 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UJamMusicSlot*> GetMusicSlotsForLoopType(EFMJamLoopType& const LoopType) const; // 0x107a4b44 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UJamMusicSlot*> GetMusicSlotsInUse() const; // 0x107a4e38 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UJamMusicSlot*> GetMusicSlotsSortedByLoopType() const; // 0x107a4e74 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<EFMJamLoopType> GetUnusedLoopTypes(bool& const bGuaranteeFullList) const; // 0x107a5740 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsJamFullWithParams(const FJamMusicSlotSearchParams SearchParams) const; // 0x107a5ad4 (Index: 0x11, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    virtual void OnJamAudioSourceActiveStateChange(UAudioComponent*& JamAudioSource, bool& bNewActiveState); // 0x288a61c (Index: 0x12, Flags: Event|Public|BlueprintEvent)
    UJamMusicSlot* PlayLoop(const FUniqueNetIdRepl PlayerNetId, FName& const SongShortname, EFMJamLoopType& const LoopType, EJamSlotStartMethod& const StartMethod, bool& const bForceAudioState, bool& const bIsAutoJammer); // 0x107a6180 (Index: 0x14, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void RequestExternalFillJamSlotsWithSong(const FUniqueNetIdRepl PlayerNetId, FName& const SongShortname); // 0x107a6590 (Index: 0x15, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void StopAllLoops(bool& const bStopAutoJammers); // 0x107a6774 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    void StopAllLoopsForLoopType(EFMJamLoopType& const LoopType); // 0x107a68a0 (Index: 0x17, Flags: Final|Native|Public|BlueprintCallable)
    void StopAllLoopsWithTag(FGameplayTag& const Tag); // 0x107a69cc (Index: 0x18, Flags: Final|Native|Public|BlueprintCallable)
    void StopAutoJammersForPlayer(const FUniqueNetIdRepl PlayerNetId); // 0x107a6a8c (Index: 0x19, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void StopLoopByInstanceId(int32_t& const LoopInstanceId); // 0x107a6bb0 (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)
    void StopLoopForPlayer(const FUniqueNetIdRepl PlayerNetId, bool& const bStopAutoJammers); // 0x107a6cd8 (Index: 0x1b, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

protected:
    void OnSuppressEmoteMusicInJamChanged(); // 0x107a616c (Index: 0x13, Flags: Final|Native|Protected)
};

static_assert(sizeof(AJamPlayspace) == 0x828, "Size mismatch for AJamPlayspace");
static_assert(offsetof(AJamPlayspace, MusicManager) == 0x778, "Offset mismatch for AJamPlayspace::MusicManager");
static_assert(offsetof(AJamPlayspace, ReactiveFXComponent) == 0x798, "Offset mismatch for AJamPlayspace::ReactiveFXComponent");
static_assert(offsetof(AJamPlayspace, ExternalReachabilityComponent) == 0x7a0, "Offset mismatch for AJamPlayspace::ExternalReachabilityComponent");
static_assert(offsetof(AJamPlayspace, JamSessionGuid) == 0x7a8, "Offset mismatch for AJamPlayspace::JamSessionGuid");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UJamPlayspaceBlockerInterface : public UInterface
{
public:

public:
    virtual FGameplayTag GetTooCloseToJamErrorMessage() const; // 0xae453fc (Index: 0x0, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual bool ShouldBlockJamPlayspace(AJamPlayspaceVolume*& const Volume) const; // 0xd917998 (Index: 0x1, Flags: Native|Event|Public|BlueprintEvent|Const)
};

static_assert(sizeof(UJamPlayspaceBlockerInterface) == 0x28, "Size mismatch for UJamPlayspaceBlockerInterface");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UJamPlayspaceBPFL : public UBlueprintFunctionLibrary
{
public:

public:
    static FJamMusicSlotSearchParams GetSearchParamsForIsJamFull(); // 0x107a56c8 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UJamPlayspaceBPFL) == 0x28, "Size mismatch for UJamPlayspaceBPFL");

// Size: 0x1f0 (Inherited: 0xe0, Single: 0x110)
class UJamPlayspaceComponent_AutojammerProxyRegistry : public UActorComponent
{
public:
    FAutojammerProxyList AutojammerProxyList; // 0xb8 (Size: 0x120, Type: StructProperty)
    uint8_t Pad_1d8[0x18]; // 0x1d8 (Size: 0x18, Type: PaddingProperty)

protected:
    void OnAnyMusicSlotChangedPlayParams(const FJamPlayParams PlayParams, bool& bChangedLoop); // 0x107a5bd4 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UJamPlayspaceComponent_AutojammerProxyRegistry) == 0x1f0, "Size mismatch for UJamPlayspaceComponent_AutojammerProxyRegistry");
static_assert(offsetof(UJamPlayspaceComponent_AutojammerProxyRegistry, AutojammerProxyList) == 0xb8, "Offset mismatch for UJamPlayspaceComponent_AutojammerProxyRegistry::AutojammerProxyList");

// Size: 0x140 (Inherited: 0x250, Single: 0xfffffef0)
class UJamPlayspaceComponent_JamCompanion : public UPlayspaceComponent
{
public:
    uint8_t Pad_b8[0x18]; // 0xb8 (Size: 0x18, Type: PaddingProperty)
    bool bOverrideShouldPlaySongAlone; // 0xd0 (Size: 0x1, Type: BoolProperty)
    bool bForceShouldPlaySongAlone; // 0xd1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d2[0x6e]; // 0xd2 (Size: 0x6e, Type: PaddingProperty)

public:
    UGameplayEventRouterComponent* GetEventRouter() const; // 0x107a8118 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    static FGameplayTag GetJamCompanionSlotTag(); // 0x107a813c (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    AJamPlayspace* GetJamPlayspace() const; // 0x107a8154 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UJamPlayspaceComponent_MusicManager* GetMusicManager() const; // 0x107a81d8 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetShouldPlaySongAlone() const; // 0x107a93e8 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    virtual void BP_OnJamLoopStarted(const FJamEvent_JamLoopStarted Payload); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void BP_OnJamLoopStopped(const FJamEvent_JamLoopStopped Payload); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UJamPlayspaceComponent_JamCompanion) == 0x140, "Size mismatch for UJamPlayspaceComponent_JamCompanion");
static_assert(offsetof(UJamPlayspaceComponent_JamCompanion, bOverrideShouldPlaySongAlone) == 0xd0, "Offset mismatch for UJamPlayspaceComponent_JamCompanion::bOverrideShouldPlaySongAlone");
static_assert(offsetof(UJamPlayspaceComponent_JamCompanion, bForceShouldPlaySongAlone) == 0xd1, "Offset mismatch for UJamPlayspaceComponent_JamCompanion::bForceShouldPlaySongAlone");

// Size: 0x1c0 (Inherited: 0x28, Single: 0x198)
class UJamMusicSlot : public UObject
{
public:
    uint8_t OnLoopStarted[0x10]; // 0x28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLoopStopped[0x10]; // 0x38 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UMidiFile* CurrentMidiFile; // 0x48 (Size: 0x8, Type: ObjectProperty)
    UFusionPatch* CurrentFusionPatch; // 0x50 (Size: 0x8, Type: ObjectProperty)
    USparksJamEmoteItemDefinition* CurrentItemDef; // 0x58 (Size: 0x8, Type: ObjectProperty)
    UJamMidiEventDriver* MidiEventDriver; // 0x60 (Size: 0x8, Type: ObjectProperty)
    bool bAttemptingResolveAndLoad; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x67]; // 0x69 (Size: 0x67, Type: PaddingProperty)
    FJamPlayParams CurrentPlayParams; // 0xd0 (Size: 0x50, Type: StructProperty)
    FJamPlayParams LastStartedPlayParams; // 0x120 (Size: 0x50, Type: StructProperty)
    UJamPlayspaceComponent_MusicManager* JamMusicManager; // 0x170 (Size: 0x8, Type: ObjectProperty)
    int32_t NthSlot; // 0x178 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_17c[0x4]; // 0x17c (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer OwnedGameplayTags; // 0x180 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_1a0[0x20]; // 0x1a0 (Size: 0x20, Type: PaddingProperty)

public:
    void AddGameplayTag(FGameplayTag& const Tag); // 0x107a7310 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    UCatalogData* GetCurrentCatalogEntry() const; // 0x107a7dc0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    USparksJamEmoteItemDefinition* GetCurrentEmoteItemDef() const; // 0x107a7de4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EMusicKey GetCurrentKey() const; // 0x107a7dfc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFMJamLoop* GetCurrentLoop() const; // 0x107a7e44 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetCurrentLoopInstanceId() const; // 0xa1ee830 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EFMJamLoopType GetCurrentLoopType() const; // 0x107a7e68 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EMusicKeyMode GetCurrentMode() const; // 0x107a7ecc (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FUniqueNetIdRepl GetCurrentPlayerId() const; // 0x107a7f14 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFMJamSong* GetCurrentSong() const; // 0x107a7f30 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FString GetCurrentSongLinkCode() const; // 0x107a7f54 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetCurrentSongShortName() const; // 0xa287650 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetCurrentTempo() const; // 0x107a7f94 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsAutoJammer() const; // 0xd782050 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UJamPlayspaceComponent_MusicManager* GetMusicManager() const; // 0xde372c8 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FJamEvent_JamLoopStarted GetParamsAsJamEvent() const; // 0x107a89a0 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FJamPlayParams GetPlayParams() const; // 0x107a8a1c (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasGameplayTag(FGameplayTag& const Tag) const; // 0x107a999c (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsInUse() const; // 0x107a9f14 (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnRep_CurrentPlayParams(const FJamPlayParams OldPlayParams); // 0x107ab0c0 (Index: 0x16, Flags: Final|Native|Public|HasOutParms)
    void RemoveAllGameplayTags(); // 0x107abd80 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    bool RemoveGameplayTag(FGameplayTag& const Tag); // 0x107abd94 (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnCMSCatalogRequestFinished(UFMJamSongCatalog*& Sender, bool& bSuccess); // 0x107aa4b4 (Index: 0x13, Flags: Final|Native|Protected)
    void OnJamLoadRequestComplete(FJamLoadResult& const LoadResult); // 0x107aa6c0 (Index: 0x14, Flags: Final|Native|Protected)
    void OnJamResolverComplete(UJamContentResolver*& Sender, FString& LinkCode, bool& bSuccess, bool& bWasAlreadyLoaded); // 0x107aa7dc (Index: 0x15, Flags: Final|Native|Protected)
    void OnScanForSongsCompleted(UFMJamSongCatalog*& Sender, TArray<UFMJamSong*>& AddedSongs); // 0x107ab450 (Index: 0x17, Flags: Final|Native|Protected)
    void OnTerminatingLinkCode(UJamContentResolver*& Sender, FString& LinkCode); // 0x107ab884 (Index: 0x18, Flags: Final|Native|Protected)
};

static_assert(sizeof(UJamMusicSlot) == 0x1c0, "Size mismatch for UJamMusicSlot");
static_assert(offsetof(UJamMusicSlot, OnLoopStarted) == 0x28, "Offset mismatch for UJamMusicSlot::OnLoopStarted");
static_assert(offsetof(UJamMusicSlot, OnLoopStopped) == 0x38, "Offset mismatch for UJamMusicSlot::OnLoopStopped");
static_assert(offsetof(UJamMusicSlot, CurrentMidiFile) == 0x48, "Offset mismatch for UJamMusicSlot::CurrentMidiFile");
static_assert(offsetof(UJamMusicSlot, CurrentFusionPatch) == 0x50, "Offset mismatch for UJamMusicSlot::CurrentFusionPatch");
static_assert(offsetof(UJamMusicSlot, CurrentItemDef) == 0x58, "Offset mismatch for UJamMusicSlot::CurrentItemDef");
static_assert(offsetof(UJamMusicSlot, MidiEventDriver) == 0x60, "Offset mismatch for UJamMusicSlot::MidiEventDriver");
static_assert(offsetof(UJamMusicSlot, bAttemptingResolveAndLoad) == 0x68, "Offset mismatch for UJamMusicSlot::bAttemptingResolveAndLoad");
static_assert(offsetof(UJamMusicSlot, CurrentPlayParams) == 0xd0, "Offset mismatch for UJamMusicSlot::CurrentPlayParams");
static_assert(offsetof(UJamMusicSlot, LastStartedPlayParams) == 0x120, "Offset mismatch for UJamMusicSlot::LastStartedPlayParams");
static_assert(offsetof(UJamMusicSlot, JamMusicManager) == 0x170, "Offset mismatch for UJamMusicSlot::JamMusicManager");
static_assert(offsetof(UJamMusicSlot, NthSlot) == 0x178, "Offset mismatch for UJamMusicSlot::NthSlot");
static_assert(offsetof(UJamMusicSlot, OwnedGameplayTags) == 0x180, "Offset mismatch for UJamMusicSlot::OwnedGameplayTags");

// Size: 0x218 (Inherited: 0x250, Single: 0xffffffc8)
class UJamPlayspaceComponent_MusicManager : public UPlayspaceComponent
{
public:
    uint8_t OnLoopStarted[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLoopStopped[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEmoteMusicSettingChanged[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_e8[0x18]; // 0xe8 (Size: 0x18, Type: PaddingProperty)
    TArray<UJamMusicSlot*> MusicSlots; // 0x100 (Size: 0x10, Type: ArrayProperty)
    FGameplayEventListenerHandle KeyChangedEventHandle; // 0x110 (Size: 0x1c, Type: StructProperty)
    FGameplayEventListenerHandle ModeChangedEventHandle; // 0x12c (Size: 0x1c, Type: StructProperty)
    FGameplayEventListenerHandle TempoChangedEventHandle; // 0x148 (Size: 0x1c, Type: StructProperty)
    uint8_t Pad_164[0x34]; // 0x164 (Size: 0x34, Type: PaddingProperty)
    float LocalPlayerGainParam; // 0x198 (Size: 0x4, Type: FloatProperty)
    float StandardGainParam; // 0x19c (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1a0[0x20]; // 0x1a0 (Size: 0x20, Type: PaddingProperty)
    FGameplayTagContainer MutingTags; // 0x1c0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer MetasoundStoppingTags; // 0x1e0 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_200[0x18]; // 0x200 (Size: 0x18, Type: PaddingProperty)

public:
    int32_t CountActiveSlotsWithParams(const FJamMusicSlotSearchParams SearchParams) const; // 0x107a790c (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void FireGlobalControlsAnalytics(const FUniqueNetIdRepl PlayerNetId); // 0x107a7a0c (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    TArray<FUniqueNetIdRepl> GetAllJammers() const; // 0x107a7b30 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UJamMusicSlot*> GetAllMusicSlots() const; // 0x107a7b6c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UJamMusicSlot*> GetAllSlotsWithTag(FGameplayTag& const Tag) const; // 0x107a7ba8 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UJamMusicSlot*> GetAutoJammersForPlayer(const FUniqueNetIdRepl PlayerNetId) const; // 0x107a7c90 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    EMusicKey GetCurrentKey() const; // 0x107a7e20 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetCurrentMidiSeconds() const; // 0x107a7e80 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetCurrentMidiTick() const; // 0x107a7ea8 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EMusicKeyMode GetCurrentMode() const; // 0x107a7ef0 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetCurrentTempo() const; // 0x107a7fcc (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetDesiredGain(const FUniqueNetIdRepl PlayerNetId) const; // 0x107a7ff0 (Index: 0xb, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    AJamPlayspace* GetJamPlayspace() const; // 0x107a8178 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetLocalPlayerGainValue() const; // 0x107a819c (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UAudioComponent* GetMetasoundPlayer() const; // 0x107a81b4 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UJamMusicSlot* GetMusicSlotByLoopInstanceId(int32_t& const LoopInstanceId) const; // 0x107a81fc (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UJamMusicSlot* GetMusicSlotBySlotIndex(int32_t& const SlotIndex) const; // 0x107a8334 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UJamMusicSlot* GetMusicSlotForPlayerId(const FUniqueNetIdRepl PlayerNetId) const; // 0x107a8484 (Index: 0x11, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    int32_t GetMusicSlotIndexForLoopInstanceId(int32_t& const LoopInstanceId) const; // 0x107a85ac (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetMusicSlotIndexForPlayer(const FUniqueNetIdRepl PlayerNetId) const; // 0x107a86e4 (Index: 0x13, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TArray<UJamMusicSlot*> GetMusicSlotsForLoopType(EFMJamLoopType& const LoopType) const; // 0x107a8814 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UJamMusicSlot*> GetMusicSlotsInUse() const; // 0x107a8964 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetStandardGainValue() const; // 0x107a9408 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void HandleOnLoopStarted(const FJamPlayParams PlayParams, bool& bChangedLoop); // 0x107a95c0 (Index: 0x19, Flags: Final|Native|Public|HasOutParms)
    void HandleOnLoopStopped(const FJamPlayParams PlayParams, bool& bChangedLoop); // 0x107a9748 (Index: 0x1a, Flags: Final|Native|Public|HasOutParms)
    void OnLicensedAudioTreatmentChanged(); // 0x107aad78 (Index: 0x1d, Flags: Final|Native|Public)
    void OnPlayspaceUserAdded(FPlayspaceUser& AddedUser); // 0x107aad8c (Index: 0x1e, Flags: Final|Native|Public|HasOutParms)
    void OnPlayspaceUserRemoved(FPlayspaceUser& RemovedUser); // 0x107aae90 (Index: 0x1f, Flags: Final|Native|Public|HasOutParms)
    void OnSuppressEmoteMusicInJamChanged(); // 0x107ab870 (Index: 0x22, Flags: Final|Native|Public)
    int32_t SecondsToTick(float& const Seconds) const; // 0x107ac088 (Index: 0x23, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool ShouldPlayLocalSound(const FUniqueNetIdRepl PlayerNetId) const; // 0x107ac1c4 (Index: 0x24, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    float TickToSeconds(int32_t& const Tick) const; // 0x107ac2ec (Index: 0x25, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void UpdateAllMetasounds(const FUniqueNetIdRepl PlayerNetIdToIgnore); // 0x107ac424 (Index: 0x26, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

private:
    static bool IsAllowedToJamInSplitscreen(UObject*& const WorldContextObject, const FUniqueNetIdRepl PlayerNetId); // 0x107a9c38 (Index: 0x1c, Flags: Final|Native|Static|Private|HasOutParms|BlueprintCallable)

protected:
    void HandleKeyChangedEvent(const FSparksPlayspaceEvent_KeyChanged Payload); // 0x107a9420 (Index: 0x17, Flags: Final|Native|Protected|HasOutParms)
    void HandleModeChangedEvent(const FSparksPlayspaceEvent_KeyModeChanged Payload); // 0x107a94f0 (Index: 0x18, Flags: Final|Native|Protected|HasOutParms)
    void HandleTempoChangedEvent(const FSparksPlayspaceEvent_TempoChanged Payload); // 0x107a98d0 (Index: 0x1b, Flags: Final|Native|Protected|HasOutParms)
    void OnPlaytimeStateChanged(EPlaytimeState& NewPlaytimeState); // 0x107aaf94 (Index: 0x20, Flags: Final|Native|Protected)
    void OnRep_MusicSlots(const TArray<UJamMusicSlot*> PreviousMusicSlots); // 0x107ab1c4 (Index: 0x21, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UJamPlayspaceComponent_MusicManager) == 0x218, "Size mismatch for UJamPlayspaceComponent_MusicManager");
static_assert(offsetof(UJamPlayspaceComponent_MusicManager, OnLoopStarted) == 0xb8, "Offset mismatch for UJamPlayspaceComponent_MusicManager::OnLoopStarted");
static_assert(offsetof(UJamPlayspaceComponent_MusicManager, OnLoopStopped) == 0xc8, "Offset mismatch for UJamPlayspaceComponent_MusicManager::OnLoopStopped");
static_assert(offsetof(UJamPlayspaceComponent_MusicManager, OnEmoteMusicSettingChanged) == 0xd8, "Offset mismatch for UJamPlayspaceComponent_MusicManager::OnEmoteMusicSettingChanged");
static_assert(offsetof(UJamPlayspaceComponent_MusicManager, MusicSlots) == 0x100, "Offset mismatch for UJamPlayspaceComponent_MusicManager::MusicSlots");
static_assert(offsetof(UJamPlayspaceComponent_MusicManager, KeyChangedEventHandle) == 0x110, "Offset mismatch for UJamPlayspaceComponent_MusicManager::KeyChangedEventHandle");
static_assert(offsetof(UJamPlayspaceComponent_MusicManager, ModeChangedEventHandle) == 0x12c, "Offset mismatch for UJamPlayspaceComponent_MusicManager::ModeChangedEventHandle");
static_assert(offsetof(UJamPlayspaceComponent_MusicManager, TempoChangedEventHandle) == 0x148, "Offset mismatch for UJamPlayspaceComponent_MusicManager::TempoChangedEventHandle");
static_assert(offsetof(UJamPlayspaceComponent_MusicManager, LocalPlayerGainParam) == 0x198, "Offset mismatch for UJamPlayspaceComponent_MusicManager::LocalPlayerGainParam");
static_assert(offsetof(UJamPlayspaceComponent_MusicManager, StandardGainParam) == 0x19c, "Offset mismatch for UJamPlayspaceComponent_MusicManager::StandardGainParam");
static_assert(offsetof(UJamPlayspaceComponent_MusicManager, MutingTags) == 0x1c0, "Offset mismatch for UJamPlayspaceComponent_MusicManager::MutingTags");
static_assert(offsetof(UJamPlayspaceComponent_MusicManager, MetasoundStoppingTags) == 0x1e0, "Offset mismatch for UJamPlayspaceComponent_MusicManager::MetasoundStoppingTags");

// Size: 0x238 (Inherited: 0x660, Single: 0xfffffbd8)
class UJamPlayspaceComponent_PlayerManager : public UPlayspaceComponent_SparksPlayerManager
{
public:
};

static_assert(sizeof(UJamPlayspaceComponent_PlayerManager) == 0x238, "Size mismatch for UJamPlayspaceComponent_PlayerManager");

// Size: 0x288 (Inherited: 0x250, Single: 0x38)
class UJamPlayspaceComponent_ReactiveFX : public UPlayspaceComponent
{
public:
    FJamReactiveFXState ReactiveFXState; // 0xb8 (Size: 0x28, Type: StructProperty)
    bool bSetReactivityUpdateRateToTargetFPS; // 0xe0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_e1[0x3]; // 0xe1 (Size: 0x3, Type: PaddingProperty)
    float ReactivityUpdateRate; // 0xe4 (Size: 0x4, Type: FloatProperty)
    float PeakTamerValueReleaseTimeSec; // 0xe8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_ec[0x4]; // 0xec (Size: 0x4, Type: PaddingProperty)
    TMap<FJamLoopReactiveFX, int32_t> LoopReactiveFX; // 0xf0 (Size: 0x50, Type: MapProperty)
    TMap<FTimerHandle, int32_t> PendingVFXHandles; // 0x140 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_190[0x90]; // 0x190 (Size: 0x90, Type: PaddingProperty)
    UNiagaraSystem* DefaultPlayerFXToSpawn; // 0x220 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* DefaultPlayerDropFXToSpawn; // 0x228 (Size: 0x8, Type: ObjectProperty)
    TMap<float, EFMJamLoopType> DefaultLoopFXAmplitude; // 0x230 (Size: 0x50, Type: MapProperty)
    UJamPlayspaceComponent_AutojammerProxyRegistry* BoundAutojammerRegistry; // 0x280 (Size: 0x8, Type: ObjectProperty)

public:
    void AddReactiveNiagaraEffect(int32_t& LoopInstanceId, UNiagaraComponent*& NiagaraComponent); // 0x107a73d0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void ClearReactiveEffects(bool& bStopEffectsImmediately); // 0x107a75d8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void ClearReactiveEffectsForLoop(int32_t& LoopInstanceId, bool& bStopEffectsImmediately); // 0x107a7704 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    TArray<UNiagaraComponent*> GetReactiveNiagaraEffects(int32_t& LoopInstanceId) const; // 0x107a90e4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasReactiveEffectsForLoop(int32_t& LoopInstanceId); // 0x107a9ad4 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void OnAudioAnalysisAmplitude(USoundSubmix*& Submix, float& Amplitude); // 0x107a9f3c (Index: 0x6, Flags: Final|Native|Public)
    void OnAudioAnalysisSpectral(USoundSubmix*& Submix, const TArray<float> Amplitudes); // 0x107aa144 (Index: 0x7, Flags: Final|Native|Public|HasOutParms)
    void OverrideAnalysis(bool& bOverride); // 0x107abc54 (Index: 0x8, Flags: Final|Native|Public)
    bool RemoveReactiveNiagaraEffect(int32_t& LoopInstanceId, UNiagaraComponent*& NiagaraComponent); // 0x107abe70 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual bool GetPlayerVFXSpawnProps(const FJamEvent_JamLoopStarted Event, USceneComponent*& OutComponentToFollow, FVector& OutSpawnLocation, FRotator& OutSpawnRotation, FVector& OutSpawnScale, UNiagaraSystem*& OutNiagaraSystemToSpawn) const; // 0x107a8a38 (Index: 0x3, Flags: Native|Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UJamPlayspaceComponent_ReactiveFX) == 0x288, "Size mismatch for UJamPlayspaceComponent_ReactiveFX");
static_assert(offsetof(UJamPlayspaceComponent_ReactiveFX, ReactiveFXState) == 0xb8, "Offset mismatch for UJamPlayspaceComponent_ReactiveFX::ReactiveFXState");
static_assert(offsetof(UJamPlayspaceComponent_ReactiveFX, bSetReactivityUpdateRateToTargetFPS) == 0xe0, "Offset mismatch for UJamPlayspaceComponent_ReactiveFX::bSetReactivityUpdateRateToTargetFPS");
static_assert(offsetof(UJamPlayspaceComponent_ReactiveFX, ReactivityUpdateRate) == 0xe4, "Offset mismatch for UJamPlayspaceComponent_ReactiveFX::ReactivityUpdateRate");
static_assert(offsetof(UJamPlayspaceComponent_ReactiveFX, PeakTamerValueReleaseTimeSec) == 0xe8, "Offset mismatch for UJamPlayspaceComponent_ReactiveFX::PeakTamerValueReleaseTimeSec");
static_assert(offsetof(UJamPlayspaceComponent_ReactiveFX, LoopReactiveFX) == 0xf0, "Offset mismatch for UJamPlayspaceComponent_ReactiveFX::LoopReactiveFX");
static_assert(offsetof(UJamPlayspaceComponent_ReactiveFX, PendingVFXHandles) == 0x140, "Offset mismatch for UJamPlayspaceComponent_ReactiveFX::PendingVFXHandles");
static_assert(offsetof(UJamPlayspaceComponent_ReactiveFX, DefaultPlayerFXToSpawn) == 0x220, "Offset mismatch for UJamPlayspaceComponent_ReactiveFX::DefaultPlayerFXToSpawn");
static_assert(offsetof(UJamPlayspaceComponent_ReactiveFX, DefaultPlayerDropFXToSpawn) == 0x228, "Offset mismatch for UJamPlayspaceComponent_ReactiveFX::DefaultPlayerDropFXToSpawn");
static_assert(offsetof(UJamPlayspaceComponent_ReactiveFX, DefaultLoopFXAmplitude) == 0x230, "Offset mismatch for UJamPlayspaceComponent_ReactiveFX::DefaultLoopFXAmplitude");
static_assert(offsetof(UJamPlayspaceComponent_ReactiveFX, BoundAutojammerRegistry) == 0x280, "Offset mismatch for UJamPlayspaceComponent_ReactiveFX::BoundAutojammerRegistry");

// Size: 0x3a8 (Inherited: 0x618, Single: 0xfffffd90)
class AJamPlayspaceVolume : public AGameplayVolume
{
public:
    uint8_t Pad_348[0x8]; // 0x348 (Size: 0x8, Type: PaddingProperty)
    TArray<EFMJamLoopType> PriorityFillOrder; // 0x350 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UTexture2D*> AutoJammerProfilePic; // 0x360 (Size: 0x20, Type: SoftObjectProperty)
    FName JamCompanionSong; // 0x380 (Size: 0x4, Type: NameProperty)
    bool bShouldJamCompanionStaggerAutoJammers; // 0x384 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_385[0x3]; // 0x385 (Size: 0x3, Type: PaddingProperty)
    FGameplayTag TooCloseToJamErrorMessage; // 0x388 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_38c[0x1c]; // 0x38c (Size: 0x1c, Type: PaddingProperty)

public:
    virtual void BP_UpdateReactiveFX(float& JamAmplitude); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    static bool IsJamVolumePlacementValid(AJamPlayspaceVolume*& const Volume, FGameplayTag& Out_BlockedErrorMessage); // 0x107e7fdc (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)

protected:
    virtual void BP_OnPlayspaceSet(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual UPrimitiveComponent* GetOuterCollider() const; // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent|Const)
};

static_assert(sizeof(AJamPlayspaceVolume) == 0x3a8, "Size mismatch for AJamPlayspaceVolume");
static_assert(offsetof(AJamPlayspaceVolume, PriorityFillOrder) == 0x350, "Offset mismatch for AJamPlayspaceVolume::PriorityFillOrder");
static_assert(offsetof(AJamPlayspaceVolume, AutoJammerProfilePic) == 0x360, "Offset mismatch for AJamPlayspaceVolume::AutoJammerProfilePic");
static_assert(offsetof(AJamPlayspaceVolume, JamCompanionSong) == 0x380, "Offset mismatch for AJamPlayspaceVolume::JamCompanionSong");
static_assert(offsetof(AJamPlayspaceVolume, bShouldJamCompanionStaggerAutoJammers) == 0x384, "Offset mismatch for AJamPlayspaceVolume::bShouldJamCompanionStaggerAutoJammers");
static_assert(offsetof(AJamPlayspaceVolume, TooCloseToJamErrorMessage) == 0x388, "Offset mismatch for AJamPlayspaceVolume::TooCloseToJamErrorMessage");

// Size: 0x110 (Inherited: 0xe0, Single: 0x30)
class UJamPlayspaceVolumeComponent_ProvideTransforms : public UActorComponent
{
public:
    FComponentReference TransformsBaseComponent; // 0xb8 (Size: 0x28, Type: StructProperty)
    TArray<FTransform> SignificantTransforms; // 0xe0 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer ProviderTags; // 0xf0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UJamPlayspaceVolumeComponent_ProvideTransforms) == 0x110, "Size mismatch for UJamPlayspaceVolumeComponent_ProvideTransforms");
static_assert(offsetof(UJamPlayspaceVolumeComponent_ProvideTransforms, TransformsBaseComponent) == 0xb8, "Offset mismatch for UJamPlayspaceVolumeComponent_ProvideTransforms::TransformsBaseComponent");
static_assert(offsetof(UJamPlayspaceVolumeComponent_ProvideTransforms, SignificantTransforms) == 0xe0, "Offset mismatch for UJamPlayspaceVolumeComponent_ProvideTransforms::SignificantTransforms");
static_assert(offsetof(UJamPlayspaceVolumeComponent_ProvideTransforms, ProviderTags) == 0xf0, "Offset mismatch for UJamPlayspaceVolumeComponent_ProvideTransforms::ProviderTags");

// Size: 0xe8 (Inherited: 0x318, Single: 0xfffffdd0)
class UJamQuickplayPlayerSpawningComponent : public UPlayspaceComponent_PlayerSpawning
{
public:
    FGameplayTagContainer PregameSpawnTags; // 0xc8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UJamQuickplayPlayerSpawningComponent) == 0xe8, "Size mismatch for UJamQuickplayPlayerSpawningComponent");
static_assert(offsetof(UJamQuickplayPlayerSpawningComponent, PregameSpawnTags) == 0xc8, "Offset mismatch for UJamQuickplayPlayerSpawningComponent::PregameSpawnTags");

// Size: 0xc8 (Inherited: 0x250, Single: 0xfffffe78)
class UPlayspaceComponent_AddGameFeatureAbilitiesToUsers : public UPlayspaceComponent
{
public:

private:
    void OnPlayerStateNewPawn(APlayerState*& ThePlayerState, APawn*& NewPawn, APawn*& OldPawn); // 0x107e8198 (Index: 0x0, Flags: Final|Native|Private)
};

static_assert(sizeof(UPlayspaceComponent_AddGameFeatureAbilitiesToUsers) == 0xc8, "Size mismatch for UPlayspaceComponent_AddGameFeatureAbilitiesToUsers");

// Size: 0x120 (Inherited: 0x320, Single: 0xfffffe00)
class UJamPlayspaceComponent_LipSyncAssetManager : public UPlayspaceComponent_LipSyncAssetManager
{
public:
};

static_assert(sizeof(UJamPlayspaceComponent_LipSyncAssetManager) == 0x120, "Size mismatch for UJamPlayspaceComponent_LipSyncAssetManager");

// Size: 0x108 (Inherited: 0x358, Single: 0xfffffdb0)
class UJamPlayspaceComponent_MidiEventDataManager : public UPlayspaceComponent_MidiEventDataManager
{
public:
};

static_assert(sizeof(UJamPlayspaceComponent_MidiEventDataManager) == 0x108, "Size mismatch for UJamPlayspaceComponent_MidiEventDataManager");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FJamPlayParams
{
    FName SongShortname; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t LoopType; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FUniqueNetIdRepl PlayerNetId; // 0x8 (Size: 0x30, Type: StructProperty)
    int32_t LoopInstanceId; // 0x38 (Size: 0x4, Type: IntProperty)
    bool bIsAutoJammer; // 0x3c (Size: 0x1, Type: BoolProperty)
    uint8_t SlotStartMethod; // 0x3d (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3e[0x2]; // 0x3e (Size: 0x2, Type: PaddingProperty)
    TWeakObjectPtr<UCatalogData*> CMSCatalogEntry; // 0x40 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFMJamSong*> Song; // 0x48 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FJamPlayParams) == 0x50, "Size mismatch for FJamPlayParams");
static_assert(offsetof(FJamPlayParams, SongShortname) == 0x0, "Offset mismatch for FJamPlayParams::SongShortname");
static_assert(offsetof(FJamPlayParams, LoopType) == 0x4, "Offset mismatch for FJamPlayParams::LoopType");
static_assert(offsetof(FJamPlayParams, PlayerNetId) == 0x8, "Offset mismatch for FJamPlayParams::PlayerNetId");
static_assert(offsetof(FJamPlayParams, LoopInstanceId) == 0x38, "Offset mismatch for FJamPlayParams::LoopInstanceId");
static_assert(offsetof(FJamPlayParams, bIsAutoJammer) == 0x3c, "Offset mismatch for FJamPlayParams::bIsAutoJammer");
static_assert(offsetof(FJamPlayParams, SlotStartMethod) == 0x3d, "Offset mismatch for FJamPlayParams::SlotStartMethod");
static_assert(offsetof(FJamPlayParams, CMSCatalogEntry) == 0x40, "Offset mismatch for FJamPlayParams::CMSCatalogEntry");
static_assert(offsetof(FJamPlayParams, Song) == 0x48, "Offset mismatch for FJamPlayParams::Song");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortGameFeatureAction_AddAbilitiesToPlayspaceUsers_Condition
{
    FString CVarName; // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t RequiredValue; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortGameFeatureAction_AddAbilitiesToPlayspaceUsers_Condition) == 0x18, "Size mismatch for FFortGameFeatureAction_AddAbilitiesToPlayspaceUsers_Condition");
static_assert(offsetof(FFortGameFeatureAction_AddAbilitiesToPlayspaceUsers_Condition, CVarName) == 0x0, "Offset mismatch for FFortGameFeatureAction_AddAbilitiesToPlayspaceUsers_Condition::CVarName");
static_assert(offsetof(FFortGameFeatureAction_AddAbilitiesToPlayspaceUsers_Condition, RequiredValue) == 0x10, "Offset mismatch for FFortGameFeatureAction_AddAbilitiesToPlayspaceUsers_Condition::RequiredValue");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FJammerTypeBreakdown
{
    int32_t TotalNumPlayerJammers; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t TotalNumHoloJammers; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t TotalNumAutoJammers; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FJammerTypeBreakdown) == 0xc, "Size mismatch for FJammerTypeBreakdown");
static_assert(offsetof(FJammerTypeBreakdown, TotalNumPlayerJammers) == 0x0, "Offset mismatch for FJammerTypeBreakdown::TotalNumPlayerJammers");
static_assert(offsetof(FJammerTypeBreakdown, TotalNumHoloJammers) == 0x4, "Offset mismatch for FJammerTypeBreakdown::TotalNumHoloJammers");
static_assert(offsetof(FJammerTypeBreakdown, TotalNumAutoJammers) == 0x8, "Offset mismatch for FJammerTypeBreakdown::TotalNumAutoJammers");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FJamLoadResult
{
    UJamMusicSlot* Slot; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UFusionPatch* FusionPatch; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UMidiFile* MidiFile; // 0x10 (Size: 0x8, Type: ObjectProperty)
    USparksJamEmoteItemDefinition* ItemDef; // 0x18 (Size: 0x8, Type: ObjectProperty)
    uint8_t Mode; // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bSuccess; // 0x21 (Size: 0x1, Type: BoolProperty)
    bool bWasCancelled; // 0x22 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_23[0x15]; // 0x23 (Size: 0x15, Type: PaddingProperty)
};

static_assert(sizeof(FJamLoadResult) == 0x38, "Size mismatch for FJamLoadResult");
static_assert(offsetof(FJamLoadResult, Slot) == 0x0, "Offset mismatch for FJamLoadResult::Slot");
static_assert(offsetof(FJamLoadResult, FusionPatch) == 0x8, "Offset mismatch for FJamLoadResult::FusionPatch");
static_assert(offsetof(FJamLoadResult, MidiFile) == 0x10, "Offset mismatch for FJamLoadResult::MidiFile");
static_assert(offsetof(FJamLoadResult, ItemDef) == 0x18, "Offset mismatch for FJamLoadResult::ItemDef");
static_assert(offsetof(FJamLoadResult, Mode) == 0x20, "Offset mismatch for FJamLoadResult::Mode");
static_assert(offsetof(FJamLoadResult, bSuccess) == 0x21, "Offset mismatch for FJamLoadResult::bSuccess");
static_assert(offsetof(FJamLoadResult, bWasCancelled) == 0x22, "Offset mismatch for FJamLoadResult::bWasCancelled");

// Size: 0xa8 (Inherited: 0x0, Single: 0xa8)
struct FJamEvent_JamLoopBase
{
    FName SongShortname; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    UCatalogData* CatalogEntry; // 0x10 (Size: 0x8, Type: ObjectProperty)
    uint8_t LoopType; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    FUniqueNetIdRepl PlayerNetId; // 0x20 (Size: 0x30, Type: StructProperty)
    int32_t LoopInstanceId; // 0x50 (Size: 0x4, Type: IntProperty)
    bool bIsAutoJammer; // 0x54 (Size: 0x1, Type: BoolProperty)
    bool bChangedLoop; // 0x55 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_56[0x2]; // 0x56 (Size: 0x2, Type: PaddingProperty)
    FJamPlayParams SlotParams; // 0x58 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FJamEvent_JamLoopBase) == 0xa8, "Size mismatch for FJamEvent_JamLoopBase");
static_assert(offsetof(FJamEvent_JamLoopBase, SongShortname) == 0x8, "Offset mismatch for FJamEvent_JamLoopBase::SongShortname");
static_assert(offsetof(FJamEvent_JamLoopBase, CatalogEntry) == 0x10, "Offset mismatch for FJamEvent_JamLoopBase::CatalogEntry");
static_assert(offsetof(FJamEvent_JamLoopBase, LoopType) == 0x18, "Offset mismatch for FJamEvent_JamLoopBase::LoopType");
static_assert(offsetof(FJamEvent_JamLoopBase, PlayerNetId) == 0x20, "Offset mismatch for FJamEvent_JamLoopBase::PlayerNetId");
static_assert(offsetof(FJamEvent_JamLoopBase, LoopInstanceId) == 0x50, "Offset mismatch for FJamEvent_JamLoopBase::LoopInstanceId");
static_assert(offsetof(FJamEvent_JamLoopBase, bIsAutoJammer) == 0x54, "Offset mismatch for FJamEvent_JamLoopBase::bIsAutoJammer");
static_assert(offsetof(FJamEvent_JamLoopBase, bChangedLoop) == 0x55, "Offset mismatch for FJamEvent_JamLoopBase::bChangedLoop");
static_assert(offsetof(FJamEvent_JamLoopBase, SlotParams) == 0x58, "Offset mismatch for FJamEvent_JamLoopBase::SlotParams");

// Size: 0xa8 (Inherited: 0xa8, Single: 0x0)
struct FJamEvent_JamLoopStarted : FJamEvent_JamLoopBase
{
};

static_assert(sizeof(FJamEvent_JamLoopStarted) == 0xa8, "Size mismatch for FJamEvent_JamLoopStarted");

// Size: 0xa8 (Inherited: 0xa8, Single: 0x0)
struct FJamEvent_JamLoopStopped : FJamEvent_JamLoopBase
{
};

static_assert(sizeof(FJamEvent_JamLoopStopped) == 0xa8, "Size mismatch for FJamEvent_JamLoopStopped");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FJamEvent_LoopsChangedThisFrame
{
};

static_assert(sizeof(FJamEvent_LoopsChangedThisFrame) == 0x1, "Size mismatch for FJamEvent_LoopsChangedThisFrame");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FJamEvent_OnPrimaryPlayerPresenceChanged
{
    bool bPrimaryPlayerInPlayspace; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FJamEvent_OnPrimaryPlayerPresenceChanged) == 0x1, "Size mismatch for FJamEvent_OnPrimaryPlayerPresenceChanged");
static_assert(offsetof(FJamEvent_OnPrimaryPlayerPresenceChanged, bPrimaryPlayerInPlayspace) == 0x0, "Offset mismatch for FJamEvent_OnPrimaryPlayerPresenceChanged::bPrimaryPlayerInPlayspace");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FJamMusicSlotSearchParams
{
    FUniqueNetIdRepl ContextPlayer; // 0x0 (Size: 0x30, Type: StructProperty)
    uint8_t SpecificLoopType; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t AutojammerMode; // 0x31 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_32[0x6]; // 0x32 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FJamMusicSlotSearchParams) == 0x38, "Size mismatch for FJamMusicSlotSearchParams");
static_assert(offsetof(FJamMusicSlotSearchParams, ContextPlayer) == 0x0, "Offset mismatch for FJamMusicSlotSearchParams::ContextPlayer");
static_assert(offsetof(FJamMusicSlotSearchParams, SpecificLoopType) == 0x30, "Offset mismatch for FJamMusicSlotSearchParams::SpecificLoopType");
static_assert(offsetof(FJamMusicSlotSearchParams, AutojammerMode) == 0x31, "Offset mismatch for FJamMusicSlotSearchParams::AutojammerMode");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FAutojammerProxyData
{
    int32_t LoopInstanceId; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UJamMusicSlot* MusicSlot; // 0x8 (Size: 0x8, Type: ObjectProperty)
    AActor* ProxyActor; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FAutojammerProxyData) == 0x18, "Size mismatch for FAutojammerProxyData");
static_assert(offsetof(FAutojammerProxyData, LoopInstanceId) == 0x0, "Offset mismatch for FAutojammerProxyData::LoopInstanceId");
static_assert(offsetof(FAutojammerProxyData, MusicSlot) == 0x8, "Offset mismatch for FAutojammerProxyData::MusicSlot");
static_assert(offsetof(FAutojammerProxyData, ProxyActor) == 0x10, "Offset mismatch for FAutojammerProxyData::ProxyActor");

// Size: 0x40 (Inherited: 0xc, Single: 0x34)
struct FAutojammerProxyEntry : FFastArraySerializerItem
{
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FAutojammerProxyData Data; // 0x10 (Size: 0x18, Type: StructProperty)
    FAutojammerProxyData LastData; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FAutojammerProxyEntry) == 0x40, "Size mismatch for FAutojammerProxyEntry");
static_assert(offsetof(FAutojammerProxyEntry, Data) == 0x10, "Offset mismatch for FAutojammerProxyEntry::Data");
static_assert(offsetof(FAutojammerProxyEntry, LastData) == 0x28, "Offset mismatch for FAutojammerProxyEntry::LastData");

// Size: 0x120 (Inherited: 0x108, Single: 0x18)
struct FAutojammerProxyList : FFastArraySerializer
{
    TArray<FAutojammerProxyEntry> Proxies; // 0x108 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_118[0x8]; // 0x118 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FAutojammerProxyList) == 0x120, "Size mismatch for FAutojammerProxyList");
static_assert(offsetof(FAutojammerProxyList, Proxies) == 0x108, "Offset mismatch for FAutojammerProxyList::Proxies");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FJamReactiveFXState
{
    float OverallAmplitude; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<float> LoopAmplitudes; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector4f> LoopBandValues; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FJamReactiveFXState) == 0x28, "Size mismatch for FJamReactiveFXState");
static_assert(offsetof(FJamReactiveFXState, OverallAmplitude) == 0x0, "Offset mismatch for FJamReactiveFXState::OverallAmplitude");
static_assert(offsetof(FJamReactiveFXState, LoopAmplitudes) == 0x8, "Offset mismatch for FJamReactiveFXState::LoopAmplitudes");
static_assert(offsetof(FJamReactiveFXState, LoopBandValues) == 0x18, "Offset mismatch for FJamReactiveFXState::LoopBandValues");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FJamLoopReactiveFX
{
    TArray<TWeakObjectPtr<UNiagaraComponent*>> NiagaraComponents; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FJamLoopReactiveFX) == 0x10, "Size mismatch for FJamLoopReactiveFX");
static_assert(offsetof(FJamLoopReactiveFX, NiagaraComponents) == 0x0, "Offset mismatch for FJamLoopReactiveFX::NiagaraComponents");

