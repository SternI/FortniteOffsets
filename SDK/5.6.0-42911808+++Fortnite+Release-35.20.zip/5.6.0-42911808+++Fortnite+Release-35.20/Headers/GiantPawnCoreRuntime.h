/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GiantPawnCoreRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "FortniteGameFramework.h"
#include "CoreUObject.h"
#include "ModularGameplay.h"
#include "GameplayTags.h"

// Size: 0xb8 (Inherited: 0x308, Single: 0xfffffdb0)
class UFortGameStateComponent_GiantPawnMode : public UFortGameStateComponent
{
public:
};

static_assert(sizeof(UFortGameStateComponent_GiantPawnMode) == 0xb8, "Size mismatch for UFortGameStateComponent_GiantPawnMode");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortGiantPawnFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void GiantPredictBuildingActorDeath(ABuildingActor*& BuildingActor, const FGameplayTag DeathTag, AFortPawn*& InstigatedBy, AActor*& DamageCauser, UPrimitiveComponent*& HitComponent, bool& bHideActor, bool& bDestroyLocally); // 0x11480f78 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static APawn* SpawnGiantPawn(UObject*& WorldContextObject, const FFortGiantPawnSpawnParameters GiantSpawnParameters); // 0x114813dc (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable)
    static AFortPlayerPawn* SwitchBackFromAndDestroyGiant(AController*& Controller); // 0xa1ff000 (Index: 0x2, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable)
    static AFortGiantPlayerPawn* SwitchToGiant(AFortGiantPlayerPawn*& Giant, AController*& Controller); // 0xe8602e8 (Index: 0x3, Flags: Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable)
    static bool TraceForGroundBP(UObject*& const WorldContextObject, FVector& const Start, FVector& const End, FHitResult& OutHitResult, bool& const bIgnoreBlockingVolumes); // 0x1148187c (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UFortGiantPawnFunctionLibrary) == 0x28, "Size mismatch for UFortGiantPawnFunctionLibrary");

// Size: 0x61c0 (Inherited: 0x13920, Single: 0xffff28a0)
class AFortGiantPlayerPawn : public AFortStandInPlayerPawn
{
public:
    uint8_t Pad_6000[0x8]; // 0x6000 (Size: 0x8, Type: PaddingProperty)
    TArray<FGameplayTag> InventoryItemsToRemoveWhileGiant; // 0x6008 (Size: 0x10, Type: ArrayProperty)
    bool bUsesCharacterParts; // 0x6018 (Size: 0x1, Type: BoolProperty)
    uint8_t bDedicatedServerAlwaysTickPoseAndRefreshBones : 1; // 0x6019:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bEquipWeaponOnControllerChange : 1; // 0x6019:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_601a[0x6]; // 0x601a (Size: 0x6, Type: PaddingProperty)
    UFortWeaponItemDefinition* DefaultWeapon; // 0x6020 (Size: 0x8, Type: ObjectProperty)
    FFortItemEntry WeaponItemCopy; // 0x6028 (Size: 0x158, Type: StructProperty)
    UFortAbilitySet* GiantAbilitySet; // 0x6180 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_6188[0x38]; // 0x6188 (Size: 0x38, Type: PaddingProperty)

public:
    virtual TEnumAsByte<EFortDamageZone> GetComponentDamageZone(UPrimitiveComponent*& HitComponent) const; // 0x288a61c (Index: 0x0, Flags: RequiredAPI|Event|Public|BlueprintEvent|Const)
    void TryEquipDefaultItem(); // 0x11481bb8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(AFortGiantPlayerPawn) == 0x61c0, "Size mismatch for AFortGiantPlayerPawn");
static_assert(offsetof(AFortGiantPlayerPawn, InventoryItemsToRemoveWhileGiant) == 0x6008, "Offset mismatch for AFortGiantPlayerPawn::InventoryItemsToRemoveWhileGiant");
static_assert(offsetof(AFortGiantPlayerPawn, bUsesCharacterParts) == 0x6018, "Offset mismatch for AFortGiantPlayerPawn::bUsesCharacterParts");
static_assert(offsetof(AFortGiantPlayerPawn, bDedicatedServerAlwaysTickPoseAndRefreshBones) == 0x6019, "Offset mismatch for AFortGiantPlayerPawn::bDedicatedServerAlwaysTickPoseAndRefreshBones");
static_assert(offsetof(AFortGiantPlayerPawn, bEquipWeaponOnControllerChange) == 0x6019, "Offset mismatch for AFortGiantPlayerPawn::bEquipWeaponOnControllerChange");
static_assert(offsetof(AFortGiantPlayerPawn, DefaultWeapon) == 0x6020, "Offset mismatch for AFortGiantPlayerPawn::DefaultWeapon");
static_assert(offsetof(AFortGiantPlayerPawn, WeaponItemCopy) == 0x6028, "Offset mismatch for AFortGiantPlayerPawn::WeaponItemCopy");
static_assert(offsetof(AFortGiantPlayerPawn, GiantAbilitySet) == 0x6180, "Offset mismatch for AFortGiantPlayerPawn::GiantAbilitySet");

// Size: 0x40 (Inherited: 0x68, Single: 0xffffffd8)
class UFortMovementMode_GiantWalkingRuntimeData : public UFortMovementMode_BaseExtRuntimeData
{
public:
};

static_assert(sizeof(UFortMovementMode_GiantWalkingRuntimeData) == 0x40, "Size mismatch for UFortMovementMode_GiantWalkingRuntimeData");

// Size: 0x1e8 (Inherited: 0x210, Single: 0xffffffd8)
class UFortMovementMode_GiantWalking : public UFortMovementMode_BaseExtLogic
{
public:

protected:
    FFortGiantWalkingTerrainGridPointsQueryResult GetTerrainPointsForLocation(const FVector CurrentLocation, const FFortGiantWalkingTerrainGridConfig TerrainGridConfig); // 0x11480d60 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable)
    bool IsValidDebugRole() const; // 0x114813b4 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool TraceForGround(const FVector Start, const FVector End, FHitResult& OutHitResult, float& const AboveLandscapeDiscardHeight); // 0x1148159c (Index: 0x2, Flags: Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UFortMovementMode_GiantWalking) == 0x1e8, "Size mismatch for UFortMovementMode_GiantWalking");

// Size: 0xb8 (Inherited: 0x308, Single: 0xfffffdb0)
class UGiantGroupDestructionManager : public UFortGameStateComponent
{
public:
};

static_assert(sizeof(UGiantGroupDestructionManager) == 0xb8, "Size mismatch for UGiantGroupDestructionManager");

// Size: 0xb8 (Inherited: 0xe0, Single: 0xffffffd8)
class UGiantPawnDestructionComponent : public UActorComponent
{
public:
};

static_assert(sizeof(UGiantPawnDestructionComponent) == 0xb8, "Size mismatch for UGiantPawnDestructionComponent");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FFortGiantPawnSpawnParameters
{
    UClass* PawnClass; // 0x0 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform SpawnTransform; // 0x10 (Size: 0x60, Type: StructProperty)
    uint8_t SpawnCollisionHandlingOverride; // 0x70 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_71[0xf]; // 0x71 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(FFortGiantPawnSpawnParameters) == 0x80, "Size mismatch for FFortGiantPawnSpawnParameters");
static_assert(offsetof(FFortGiantPawnSpawnParameters, PawnClass) == 0x0, "Offset mismatch for FFortGiantPawnSpawnParameters::PawnClass");
static_assert(offsetof(FFortGiantPawnSpawnParameters, SpawnTransform) == 0x10, "Offset mismatch for FFortGiantPawnSpawnParameters::SpawnTransform");
static_assert(offsetof(FFortGiantPawnSpawnParameters, SpawnCollisionHandlingOverride) == 0x70, "Offset mismatch for FFortGiantPawnSpawnParameters::SpawnCollisionHandlingOverride");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FFortGiantWalkingTerrainGridConfig
{
    float GridSize; // 0x0 (Size: 0x4, Type: FloatProperty)
    float GroundTraceHalfHeight; // 0x4 (Size: 0x4, Type: FloatProperty)
    float AboveLandscapeDiscardHeight; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x54]; // 0xc (Size: 0x54, Type: PaddingProperty)
};

static_assert(sizeof(FFortGiantWalkingTerrainGridConfig) == 0x60, "Size mismatch for FFortGiantWalkingTerrainGridConfig");
static_assert(offsetof(FFortGiantWalkingTerrainGridConfig, GridSize) == 0x0, "Offset mismatch for FFortGiantWalkingTerrainGridConfig::GridSize");
static_assert(offsetof(FFortGiantWalkingTerrainGridConfig, GroundTraceHalfHeight) == 0x4, "Offset mismatch for FFortGiantWalkingTerrainGridConfig::GroundTraceHalfHeight");
static_assert(offsetof(FFortGiantWalkingTerrainGridConfig, AboveLandscapeDiscardHeight) == 0x8, "Offset mismatch for FFortGiantWalkingTerrainGridConfig::AboveLandscapeDiscardHeight");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FFortGiantWalkingTerrainGridPointsQueryResult
{
    FVector LocA; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector LocB; // 0x18 (Size: 0x18, Type: StructProperty)
    FVector LocC; // 0x30 (Size: 0x18, Type: StructProperty)
    bool bHitGroundLocA; // 0x48 (Size: 0x1, Type: BoolProperty)
    bool bHitGroundLocB; // 0x49 (Size: 0x1, Type: BoolProperty)
    bool bHitGroundLocC; // 0x4a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4b[0x5]; // 0x4b (Size: 0x5, Type: PaddingProperty)
    FVector DesiredLocation; // 0x50 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FFortGiantWalkingTerrainGridPointsQueryResult) == 0x68, "Size mismatch for FFortGiantWalkingTerrainGridPointsQueryResult");
static_assert(offsetof(FFortGiantWalkingTerrainGridPointsQueryResult, LocA) == 0x0, "Offset mismatch for FFortGiantWalkingTerrainGridPointsQueryResult::LocA");
static_assert(offsetof(FFortGiantWalkingTerrainGridPointsQueryResult, LocB) == 0x18, "Offset mismatch for FFortGiantWalkingTerrainGridPointsQueryResult::LocB");
static_assert(offsetof(FFortGiantWalkingTerrainGridPointsQueryResult, LocC) == 0x30, "Offset mismatch for FFortGiantWalkingTerrainGridPointsQueryResult::LocC");
static_assert(offsetof(FFortGiantWalkingTerrainGridPointsQueryResult, bHitGroundLocA) == 0x48, "Offset mismatch for FFortGiantWalkingTerrainGridPointsQueryResult::bHitGroundLocA");
static_assert(offsetof(FFortGiantWalkingTerrainGridPointsQueryResult, bHitGroundLocB) == 0x49, "Offset mismatch for FFortGiantWalkingTerrainGridPointsQueryResult::bHitGroundLocB");
static_assert(offsetof(FFortGiantWalkingTerrainGridPointsQueryResult, bHitGroundLocC) == 0x4a, "Offset mismatch for FFortGiantWalkingTerrainGridPointsQueryResult::bHitGroundLocC");
static_assert(offsetof(FFortGiantWalkingTerrainGridPointsQueryResult, DesiredLocation) == 0x50, "Offset mismatch for FFortGiantWalkingTerrainGridPointsQueryResult::DesiredLocation");

// Size: 0x10 (Inherited: 0x10, Single: 0x0)
struct FFortMovementMode_GiantWalkingCreationData : FFortMovementMode_BaseExtCreationData
{
};

static_assert(sizeof(FFortMovementMode_GiantWalkingCreationData) == 0x10, "Size mismatch for FFortMovementMode_GiantWalkingCreationData");

