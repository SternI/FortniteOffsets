/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BattlePassBase
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "UMG.h"
#include "CoreUObject.h"
#include "CommonUI.h"

// Size: 0x2c0 (Inherited: 0x458, Single: 0xfffffe68)
class UFortBattlePassLevelCount : public UUserWidget
{
public:
    UCommonTextBlock* Text_LevelCount; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2b8[0x8]; // 0x2b8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortBattlePassLevelCount) == 0x2c0, "Size mismatch for UFortBattlePassLevelCount");
static_assert(offsetof(UFortBattlePassLevelCount, Text_LevelCount) == 0x2b0, "Offset mismatch for UFortBattlePassLevelCount::Text_LevelCount");

// Size: 0x2b0 (Inherited: 0x458, Single: 0xfffffe58)
class URebootRallyQuestPanel : public UUserWidget
{
public:

public:
    virtual void OnRebootRallyEligibilityUpdated(bool& bEligible); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(URebootRallyQuestPanel) == 0x2b0, "Size mismatch for URebootRallyQuestPanel");

