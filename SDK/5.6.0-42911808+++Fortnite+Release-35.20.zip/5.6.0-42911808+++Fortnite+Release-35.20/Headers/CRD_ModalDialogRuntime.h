/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_ModalDialogRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CommonUI.h"
#include "UMG.h"

// Size: 0x428 (Inherited: 0xb38, Single: 0xfffff8f0)
class UModalDialogVariant : public UCommonActivatableWidget
{
public:
    UWidgetAnimation* BoundAnim_Open; // 0x408 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* BoundAnim_Response; // 0x410 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnResponseAnimationFinished[0x10]; // 0x418 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void AttemptToPlayOpenAnimation(); // 0x11a99784 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void AttemptToPlayResponseAnimation(); // 0x11a997c4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    bool HasResponseAnimation() const; // 0x11a99818 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnResponseAnimationFinished__DelegateSignature(); // 0x288a61c (Index: 0x4, Flags: MulticastDelegate|Public|Delegate)
    void SetIsModal(bool& ModalState); // 0x11a99834 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)

private:
    void HandleResponseAnimationFinished(); // 0x11a99804 (Index: 0x2, Flags: Final|Native|Private)
};

static_assert(sizeof(UModalDialogVariant) == 0x428, "Size mismatch for UModalDialogVariant");
static_assert(offsetof(UModalDialogVariant, BoundAnim_Open) == 0x408, "Offset mismatch for UModalDialogVariant::BoundAnim_Open");
static_assert(offsetof(UModalDialogVariant, BoundAnim_Response) == 0x410, "Offset mismatch for UModalDialogVariant::BoundAnim_Response");
static_assert(offsetof(UModalDialogVariant, OnResponseAnimationFinished) == 0x418, "Offset mismatch for UModalDialogVariant::OnResponseAnimationFinished");

