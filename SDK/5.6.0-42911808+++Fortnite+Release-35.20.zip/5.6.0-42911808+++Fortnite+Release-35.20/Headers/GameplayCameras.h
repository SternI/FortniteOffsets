/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayCameras
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "StateTreeModule.h"
#include "DeveloperSettings.h"
#include "MovieSceneTracks.h"
#include "MovieScene.h"
#include "CinematicCamera.h"
#include "EnhancedInput.h"
#include "GameplayTags.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlueprintCameraNodeEvaluationResultFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FBlueprintCameraPose GetCameraPose(const FBlueprintCameraNodeEvaluationResult Data); // 0xb703b10 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FBlueprintCameraContextDataTable GetContextDataTable(const FBlueprintCameraNodeEvaluationResult Data); // 0xb703c70 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FBlueprintCameraVariableTable GetVariableTable(const FBlueprintCameraNodeEvaluationResult Data); // 0xb703d4c (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void SetCameraPose(FBlueprintCameraNodeEvaluationResult Data, const FBlueprintCameraPose CameraPose); // 0xb703eec (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UBlueprintCameraNodeEvaluationResultFunctionLibrary) == 0x28, "Size mismatch for UBlueprintCameraNodeEvaluationResultFunctionLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UHasCameraBuildStatus : public UInterface
{
public:
};

static_assert(sizeof(UHasCameraBuildStatus) == 0x28, "Size mismatch for UHasCameraBuildStatus");

// Size: 0x48 (Inherited: 0x60, Single: 0xffffffe8)
class UCombinedCameraRigsCameraNode : public UCameraNode
{
public:
    TArray<FCameraRigAssetReference> CameraRigReferences; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCombinedCameraRigsCameraNode) == 0x48, "Size mismatch for UCombinedCameraRigsCameraNode");
static_assert(offsetof(UCombinedCameraRigsCameraNode, CameraRigReferences) == 0x38, "Offset mismatch for UCombinedCameraRigsCameraNode::CameraRigReferences");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UCameraNode : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    bool bIsEnabled; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UCameraNode) == 0x38, "Size mismatch for UCameraNode");
static_assert(offsetof(UCameraNode, bIsEnabled) == 0x30, "Offset mismatch for UCameraNode::bIsEnabled");

// Size: 0x88 (Inherited: 0x98, Single: 0xfffffff0)
class UCameraRigInput1DSlot : public UInput1DCameraNode
{
public:
    FCameraRigInputSlotParameters InputSlotParameters; // 0x38 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_3a[0x6]; // 0x3a (Size: 0x6, Type: PaddingProperty)
    FCameraParameterClamping clamp; // 0x40 (Size: 0x18, Type: StructProperty)
    FCameraParameterNormalization Normalize; // 0x58 (Size: 0x10, Type: StructProperty)
    uint8_t BuiltInVariable[0x4]; // 0x68 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
    FDoubleCameraVariableReference CustomVariable; // 0x70 (Size: 0x10, Type: StructProperty)
    FCameraVariableID TransientVariableID; // 0x80 (Size: 0x4, Type: StructProperty)
    FCameraVariableID VariableID; // 0x84 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(UCameraRigInput1DSlot) == 0x88, "Size mismatch for UCameraRigInput1DSlot");
static_assert(offsetof(UCameraRigInput1DSlot, InputSlotParameters) == 0x38, "Offset mismatch for UCameraRigInput1DSlot::InputSlotParameters");
static_assert(offsetof(UCameraRigInput1DSlot, clamp) == 0x40, "Offset mismatch for UCameraRigInput1DSlot::clamp");
static_assert(offsetof(UCameraRigInput1DSlot, Normalize) == 0x58, "Offset mismatch for UCameraRigInput1DSlot::Normalize");
static_assert(offsetof(UCameraRigInput1DSlot, BuiltInVariable) == 0x68, "Offset mismatch for UCameraRigInput1DSlot::BuiltInVariable");
static_assert(offsetof(UCameraRigInput1DSlot, CustomVariable) == 0x70, "Offset mismatch for UCameraRigInput1DSlot::CustomVariable");
static_assert(offsetof(UCameraRigInput1DSlot, TransientVariableID) == 0x80, "Offset mismatch for UCameraRigInput1DSlot::TransientVariableID");
static_assert(offsetof(UCameraRigInput1DSlot, VariableID) == 0x84, "Offset mismatch for UCameraRigInput1DSlot::VariableID");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class UInput1DCameraNode : public UCameraNode
{
public:
};

static_assert(sizeof(UInput1DCameraNode) == 0x38, "Size mismatch for UInput1DCameraNode");

// Size: 0xb0 (Inherited: 0x98, Single: 0x18)
class UCameraRigInput2DSlot : public UInput2DCameraNode
{
public:
    FCameraRigInputSlotParameters InputSlotParameters; // 0x38 (Size: 0x2, Type: StructProperty)
    uint8_t Pad_3a[0x6]; // 0x3a (Size: 0x6, Type: PaddingProperty)
    FCameraParameterClamping ClampX; // 0x40 (Size: 0x18, Type: StructProperty)
    FCameraParameterClamping ClampY; // 0x58 (Size: 0x18, Type: StructProperty)
    FCameraParameterNormalization NormalizeX; // 0x70 (Size: 0x10, Type: StructProperty)
    FCameraParameterNormalization NormalizeY; // 0x80 (Size: 0x10, Type: StructProperty)
    uint8_t BuiltInVariable[0x4]; // 0x90 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
    FVector2dCameraVariableReference CustomVariable; // 0x98 (Size: 0x10, Type: StructProperty)
    FCameraVariableID TransientVariableID; // 0xa8 (Size: 0x4, Type: StructProperty)
    FCameraVariableID VariableID; // 0xac (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(UCameraRigInput2DSlot) == 0xb0, "Size mismatch for UCameraRigInput2DSlot");
static_assert(offsetof(UCameraRigInput2DSlot, InputSlotParameters) == 0x38, "Offset mismatch for UCameraRigInput2DSlot::InputSlotParameters");
static_assert(offsetof(UCameraRigInput2DSlot, ClampX) == 0x40, "Offset mismatch for UCameraRigInput2DSlot::ClampX");
static_assert(offsetof(UCameraRigInput2DSlot, ClampY) == 0x58, "Offset mismatch for UCameraRigInput2DSlot::ClampY");
static_assert(offsetof(UCameraRigInput2DSlot, NormalizeX) == 0x70, "Offset mismatch for UCameraRigInput2DSlot::NormalizeX");
static_assert(offsetof(UCameraRigInput2DSlot, NormalizeY) == 0x80, "Offset mismatch for UCameraRigInput2DSlot::NormalizeY");
static_assert(offsetof(UCameraRigInput2DSlot, BuiltInVariable) == 0x90, "Offset mismatch for UCameraRigInput2DSlot::BuiltInVariable");
static_assert(offsetof(UCameraRigInput2DSlot, CustomVariable) == 0x98, "Offset mismatch for UCameraRigInput2DSlot::CustomVariable");
static_assert(offsetof(UCameraRigInput2DSlot, TransientVariableID) == 0xa8, "Offset mismatch for UCameraRigInput2DSlot::TransientVariableID");
static_assert(offsetof(UCameraRigInput2DSlot, VariableID) == 0xac, "Offset mismatch for UCameraRigInput2DSlot::VariableID");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class UInput2DCameraNode : public UCameraNode
{
public:
};

static_assert(sizeof(UInput2DCameraNode) == 0x38, "Size mismatch for UInput2DCameraNode");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCameraRigInstanceFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static bool IsValid(FCameraRigInstanceID& InstanceID); // 0xb703e28 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UCameraRigInstanceFunctions) == 0x28, "Size mismatch for UCameraRigInstanceFunctions");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UCameraRigProxyAsset : public UObject
{
public:
    FGuid Guid; // 0x28 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UCameraRigProxyAsset) == 0x38, "Size mismatch for UCameraRigProxyAsset");
static_assert(offsetof(UCameraRigProxyAsset, Guid) == 0x28, "Offset mismatch for UCameraRigProxyAsset::Guid");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UCameraRigProxyTable : public UObject
{
public:
    TArray<FCameraRigProxyTableEntry> Entries; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCameraRigProxyTable) == 0x38, "Size mismatch for UCameraRigProxyTable");
static_assert(offsetof(UCameraRigProxyTable, Entries) == 0x28, "Offset mismatch for UCameraRigProxyTable::Entries");

// Size: 0x48 (Inherited: 0x98, Single: 0xffffffb0)
class UCompositeShakeCameraNode : public UShakeCameraNode
{
public:
    TArray<UShakeCameraNode*> Shakes; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCompositeShakeCameraNode) == 0x48, "Size mismatch for UCompositeShakeCameraNode");
static_assert(offsetof(UCompositeShakeCameraNode, Shakes) == 0x38, "Offset mismatch for UCompositeShakeCameraNode::Shakes");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class UShakeCameraNode : public UCameraNode
{
public:
};

static_assert(sizeof(UShakeCameraNode) == 0x38, "Size mismatch for UShakeCameraNode");

// Size: 0x70 (Inherited: 0x98, Single: 0xffffffd8)
class UEnvelopeShakeCameraNode : public UShakeCameraNode
{
public:
    FFloatCameraParameter EaseInTime; // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter EaseOutTime; // 0x48 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter TotalTime; // 0x58 (Size: 0x10, Type: StructProperty)
    UShakeCameraNode* Shake; // 0x68 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UEnvelopeShakeCameraNode) == 0x70, "Size mismatch for UEnvelopeShakeCameraNode");
static_assert(offsetof(UEnvelopeShakeCameraNode, EaseInTime) == 0x38, "Offset mismatch for UEnvelopeShakeCameraNode::EaseInTime");
static_assert(offsetof(UEnvelopeShakeCameraNode, EaseOutTime) == 0x48, "Offset mismatch for UEnvelopeShakeCameraNode::EaseOutTime");
static_assert(offsetof(UEnvelopeShakeCameraNode, TotalTime) == 0x58, "Offset mismatch for UEnvelopeShakeCameraNode::TotalTime");
static_assert(offsetof(UEnvelopeShakeCameraNode, Shake) == 0x68, "Offset mismatch for UEnvelopeShakeCameraNode::Shake");

// Size: 0x30d0 (Inherited: 0x2ab0, Single: 0x620)
class AGameplayCamerasPlayerCameraManager : public APlayerCameraManager
{
public:
    UGameplayCameraSystemHost* CameraSystemHost; // 0x27d8 (Size: 0x8, Type: ObjectProperty)
    APlayerCameraManager* OriginalCameraManager; // 0x27e0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AGameplayCameraSystemActor*> WeakOriginalAutoCameraSystemActor; // 0x27e8 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_27f0[0x8e0]; // 0x27f0 (Size: 0x8e0, Type: PaddingProperty)

public:
    void ReleasePlayerController(); // 0xb71c66c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    FCameraRigInstanceID StartGlobalCameraModifierRig(UCameraRigAsset*& const CameraRig, int32_t& OrderKey); // 0xb71c680 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    FCameraRigInstanceID StartVisualCameraModifierRig(UCameraRigAsset*& const CameraRig, int32_t& OrderKey); // 0xb71c8c0 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void StealPlayerController(APlayerController*& PlayerController); // 0xb71cb00 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void StopCameraModifierRig(FCameraRigInstanceID& InstanceID, bool& bImmediately); // 0xb71cc2c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(AGameplayCamerasPlayerCameraManager) == 0x30d0, "Size mismatch for AGameplayCamerasPlayerCameraManager");
static_assert(offsetof(AGameplayCamerasPlayerCameraManager, CameraSystemHost) == 0x27d8, "Offset mismatch for AGameplayCamerasPlayerCameraManager::CameraSystemHost");
static_assert(offsetof(AGameplayCamerasPlayerCameraManager, OriginalCameraManager) == 0x27e0, "Offset mismatch for AGameplayCamerasPlayerCameraManager::OriginalCameraManager");
static_assert(offsetof(AGameplayCamerasPlayerCameraManager, WeakOriginalAutoCameraSystemActor) == 0x27e8, "Offset mismatch for AGameplayCamerasPlayerCameraManager::WeakOriginalAutoCameraSystemActor");

// Size: 0x48 (Inherited: 0xd0, Single: 0xffffff78)
class UViewTargetTransitionParamsBlendCameraNode : public USimpleBlendCameraNode
{
public:
    FViewTargetTransitionParams TransitionParams; // 0x38 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UViewTargetTransitionParamsBlendCameraNode) == 0x48, "Size mismatch for UViewTargetTransitionParamsBlendCameraNode");
static_assert(offsetof(UViewTargetTransitionParamsBlendCameraNode, TransitionParams) == 0x38, "Offset mismatch for UViewTargetTransitionParamsBlendCameraNode::TransitionParams");

// Size: 0x38 (Inherited: 0x98, Single: 0xffffffa0)
class USimpleBlendCameraNode : public UBlendCameraNode
{
public:
};

static_assert(sizeof(USimpleBlendCameraNode) == 0x38, "Size mismatch for USimpleBlendCameraNode");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class UBlendCameraNode : public UCameraNode
{
public:
};

static_assert(sizeof(UBlendCameraNode) == 0x38, "Size mismatch for UBlendCameraNode");

// Size: 0x78 (Inherited: 0x60, Single: 0x18)
class UUpdateTrackerCameraNode : public UCameraNode
{
public:
    FDoubleCameraParameter DoubleParameter; // 0x38 (Size: 0x18, Type: StructProperty)
    FVector3dCameraParameter VectorParameter; // 0x50 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UUpdateTrackerCameraNode) == 0x78, "Size mismatch for UUpdateTrackerCameraNode");
static_assert(offsetof(UUpdateTrackerCameraNode, DoubleParameter) == 0x38, "Offset mismatch for UUpdateTrackerCameraNode::DoubleParameter");
static_assert(offsetof(UUpdateTrackerCameraNode, VectorParameter) == 0x50, "Offset mismatch for UUpdateTrackerCameraNode::VectorParameter");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UGameplayCameraSystemHost : public UObject
{
public:
};

static_assert(sizeof(UGameplayCameraSystemHost) == 0x38, "Size mismatch for UGameplayCameraSystemHost");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCustomCameraNodeParameterProvider : public UInterface
{
public:
};

static_assert(sizeof(UCustomCameraNodeParameterProvider) == 0x28, "Size mismatch for UCustomCameraNodeParameterProvider");

// Size: 0x100 (Inherited: 0x148, Single: 0xffffffb8)
class UInputAxisBinding2DCameraNode : public UCameraRigInput2DSlot
{
public:
    TArray<UInputAction*> AxisActions; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    FBooleanCameraParameter RevertAxisX; // 0xc0 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter RevertAxisY; // 0xd0 (Size: 0x10, Type: StructProperty)
    FVector2dCameraParameter Multiplier; // 0xe0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UInputAxisBinding2DCameraNode) == 0x100, "Size mismatch for UInputAxisBinding2DCameraNode");
static_assert(offsetof(UInputAxisBinding2DCameraNode, AxisActions) == 0xb0, "Offset mismatch for UInputAxisBinding2DCameraNode::AxisActions");
static_assert(offsetof(UInputAxisBinding2DCameraNode, RevertAxisX) == 0xc0, "Offset mismatch for UInputAxisBinding2DCameraNode::RevertAxisX");
static_assert(offsetof(UInputAxisBinding2DCameraNode, RevertAxisY) == 0xd0, "Offset mismatch for UInputAxisBinding2DCameraNode::RevertAxisY");
static_assert(offsetof(UInputAxisBinding2DCameraNode, Multiplier) == 0xe0, "Offset mismatch for UInputAxisBinding2DCameraNode::Multiplier");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UObjectTreeGraphObject : public UInterface
{
public:
};

static_assert(sizeof(UObjectTreeGraphObject) == 0x28, "Size mismatch for UObjectTreeGraphObject");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UObjectTreeGraphRootObject : public UInterface
{
public:
};

static_assert(sizeof(UObjectTreeGraphRootObject) == 0x28, "Size mismatch for UObjectTreeGraphRootObject");

// Size: 0x80 (Inherited: 0x98, Single: 0xffffffe8)
class UPerlinNoiseLocationShakeCameraNode : public UShakeCameraNode
{
public:
    FFloatCameraParameter AmplitudeMultiplier; // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter FrequencyMultiplier; // 0x48 (Size: 0x10, Type: StructProperty)
    FInteger32CameraParameter Octaves; // 0x58 (Size: 0x10, Type: StructProperty)
    FPerlinNoiseData X; // 0x68 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseData Y; // 0x70 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseData Z; // 0x78 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(UPerlinNoiseLocationShakeCameraNode) == 0x80, "Size mismatch for UPerlinNoiseLocationShakeCameraNode");
static_assert(offsetof(UPerlinNoiseLocationShakeCameraNode, AmplitudeMultiplier) == 0x38, "Offset mismatch for UPerlinNoiseLocationShakeCameraNode::AmplitudeMultiplier");
static_assert(offsetof(UPerlinNoiseLocationShakeCameraNode, FrequencyMultiplier) == 0x48, "Offset mismatch for UPerlinNoiseLocationShakeCameraNode::FrequencyMultiplier");
static_assert(offsetof(UPerlinNoiseLocationShakeCameraNode, Octaves) == 0x58, "Offset mismatch for UPerlinNoiseLocationShakeCameraNode::Octaves");
static_assert(offsetof(UPerlinNoiseLocationShakeCameraNode, X) == 0x68, "Offset mismatch for UPerlinNoiseLocationShakeCameraNode::X");
static_assert(offsetof(UPerlinNoiseLocationShakeCameraNode, Y) == 0x70, "Offset mismatch for UPerlinNoiseLocationShakeCameraNode::Y");
static_assert(offsetof(UPerlinNoiseLocationShakeCameraNode, Z) == 0x78, "Offset mismatch for UPerlinNoiseLocationShakeCameraNode::Z");

// Size: 0x80 (Inherited: 0x98, Single: 0xffffffe8)
class UPerlinNoiseRotationShakeCameraNode : public UShakeCameraNode
{
public:
    FFloatCameraParameter AmplitudeMultiplier; // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter FrequencyMultiplier; // 0x48 (Size: 0x10, Type: StructProperty)
    FInteger32CameraParameter Octaves; // 0x58 (Size: 0x10, Type: StructProperty)
    FPerlinNoiseData Yaw; // 0x68 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseData pitch; // 0x70 (Size: 0x8, Type: StructProperty)
    FPerlinNoiseData Roll; // 0x78 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(UPerlinNoiseRotationShakeCameraNode) == 0x80, "Size mismatch for UPerlinNoiseRotationShakeCameraNode");
static_assert(offsetof(UPerlinNoiseRotationShakeCameraNode, AmplitudeMultiplier) == 0x38, "Offset mismatch for UPerlinNoiseRotationShakeCameraNode::AmplitudeMultiplier");
static_assert(offsetof(UPerlinNoiseRotationShakeCameraNode, FrequencyMultiplier) == 0x48, "Offset mismatch for UPerlinNoiseRotationShakeCameraNode::FrequencyMultiplier");
static_assert(offsetof(UPerlinNoiseRotationShakeCameraNode, Octaves) == 0x58, "Offset mismatch for UPerlinNoiseRotationShakeCameraNode::Octaves");
static_assert(offsetof(UPerlinNoiseRotationShakeCameraNode, Yaw) == 0x68, "Offset mismatch for UPerlinNoiseRotationShakeCameraNode::Yaw");
static_assert(offsetof(UPerlinNoiseRotationShakeCameraNode, pitch) == 0x70, "Offset mismatch for UPerlinNoiseRotationShakeCameraNode::pitch");
static_assert(offsetof(UPerlinNoiseRotationShakeCameraNode, Roll) == 0x78, "Offset mismatch for UPerlinNoiseRotationShakeCameraNode::Roll");

// Size: 0x98 (Inherited: 0x28, Single: 0x70)
class UBaseCameraObject : public UObject
{
public:
    FCameraObjectInterface Interface; // 0x28 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_48[0x8]; // 0x48 (Size: 0x8, Type: PaddingProperty)
    FCameraObjectAllocationInfo AllocationInfo; // 0x50 (Size: 0x28, Type: StructProperty)
    FInstancedPropertyBag DefaultParameters; // 0x78 (Size: 0x10, Type: StructProperty)
    TArray<FCameraObjectInterfaceParameterDefinition> ParameterDefinitions; // 0x88 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UBaseCameraObject) == 0x98, "Size mismatch for UBaseCameraObject");
static_assert(offsetof(UBaseCameraObject, Interface) == 0x28, "Offset mismatch for UBaseCameraObject::Interface");
static_assert(offsetof(UBaseCameraObject, AllocationInfo) == 0x50, "Offset mismatch for UBaseCameraObject::AllocationInfo");
static_assert(offsetof(UBaseCameraObject, DefaultParameters) == 0x78, "Offset mismatch for UBaseCameraObject::DefaultParameters");
static_assert(offsetof(UBaseCameraObject, ParameterDefinitions) == 0x88, "Offset mismatch for UBaseCameraObject::ParameterDefinitions");

// Size: 0x40 (Inherited: 0x60, Single: 0xffffffe0)
class UBlendStackCameraNode : public UCameraNode
{
public:
    uint8_t BlendStackType[0x4]; // 0x38 (Size: 0x4, Type: EnumProperty)
    uint8_t Layer; // 0x3c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_3d[0x3]; // 0x3d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UBlendStackCameraNode) == 0x40, "Size mismatch for UBlendStackCameraNode");
static_assert(offsetof(UBlendStackCameraNode, BlendStackType) == 0x38, "Offset mismatch for UBlendStackCameraNode::BlendStackType");
static_assert(offsetof(UBlendStackCameraNode, Layer) == 0x3c, "Offset mismatch for UBlendStackCameraNode::Layer");

// Size: 0x48 (Inherited: 0x60, Single: 0xffffffe8)
class UBlendStackRootCameraNode : public UCameraNode
{
public:
    UBlendCameraNode* Blend; // 0x38 (Size: 0x8, Type: ObjectProperty)
    UCameraNode* RootNode; // 0x40 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UBlendStackRootCameraNode) == 0x48, "Size mismatch for UBlendStackRootCameraNode");
static_assert(offsetof(UBlendStackRootCameraNode, Blend) == 0x38, "Offset mismatch for UBlendStackRootCameraNode::Blend");
static_assert(offsetof(UBlendStackRootCameraNode, RootNode) == 0x40, "Offset mismatch for UBlendStackRootCameraNode::RootNode");

// Size: 0xd8 (Inherited: 0x28, Single: 0xb0)
class UCameraAsset : public UObject
{
public:
    uint8_t Pad_28[0x20]; // 0x28 (Size: 0x20, Type: PaddingProperty)
    UCameraDirector* CameraDirector; // 0x48 (Size: 0x8, Type: ObjectProperty)
    TArray<UCameraRigTransition*> EnterTransitions; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<UCameraRigTransition*> ExitTransitions; // 0x60 (Size: 0x10, Type: ArrayProperty)
    uint8_t BuildStatus; // 0x70 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
    FInstancedPropertyBag DefaultParameters; // 0x78 (Size: 0x10, Type: StructProperty)
    TArray<FCameraObjectInterfaceParameterDefinition> ParameterDefinitions; // 0x88 (Size: 0x10, Type: ArrayProperty)
    TArray<UCameraRigAsset*> ParameterOwners; // 0x98 (Size: 0x10, Type: ArrayProperty)
    FCameraAssetAllocationInfo AllocationInfo; // 0xa8 (Size: 0x20, Type: StructProperty)
    TArray<UCameraRigAsset*> CameraRigs; // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCameraAsset) == 0xd8, "Size mismatch for UCameraAsset");
static_assert(offsetof(UCameraAsset, CameraDirector) == 0x48, "Offset mismatch for UCameraAsset::CameraDirector");
static_assert(offsetof(UCameraAsset, EnterTransitions) == 0x50, "Offset mismatch for UCameraAsset::EnterTransitions");
static_assert(offsetof(UCameraAsset, ExitTransitions) == 0x60, "Offset mismatch for UCameraAsset::ExitTransitions");
static_assert(offsetof(UCameraAsset, BuildStatus) == 0x70, "Offset mismatch for UCameraAsset::BuildStatus");
static_assert(offsetof(UCameraAsset, DefaultParameters) == 0x78, "Offset mismatch for UCameraAsset::DefaultParameters");
static_assert(offsetof(UCameraAsset, ParameterDefinitions) == 0x88, "Offset mismatch for UCameraAsset::ParameterDefinitions");
static_assert(offsetof(UCameraAsset, ParameterOwners) == 0x98, "Offset mismatch for UCameraAsset::ParameterOwners");
static_assert(offsetof(UCameraAsset, AllocationInfo) == 0xa8, "Offset mismatch for UCameraAsset::AllocationInfo");
static_assert(offsetof(UCameraAsset, CameraRigs) == 0xc8, "Offset mismatch for UCameraAsset::CameraRigs");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UCameraDirector : public UObject
{
public:
};

static_assert(sizeof(UCameraDirector) == 0x28, "Size mismatch for UCameraDirector");

// Size: 0x60 (Inherited: 0x28, Single: 0x38)
class UCameraObjectInterfaceParameterBase : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FString InterfaceParameterName; // 0x30 (Size: 0x10, Type: StrProperty)
    UCameraNode* Target; // 0x40 (Size: 0x8, Type: ObjectProperty)
    FName TargetPropertyName; // 0x48 (Size: 0x4, Type: NameProperty)
    FGuid Guid; // 0x4c (Size: 0x10, Type: StructProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UCameraObjectInterfaceParameterBase) == 0x60, "Size mismatch for UCameraObjectInterfaceParameterBase");
static_assert(offsetof(UCameraObjectInterfaceParameterBase, InterfaceParameterName) == 0x30, "Offset mismatch for UCameraObjectInterfaceParameterBase::InterfaceParameterName");
static_assert(offsetof(UCameraObjectInterfaceParameterBase, Target) == 0x40, "Offset mismatch for UCameraObjectInterfaceParameterBase::Target");
static_assert(offsetof(UCameraObjectInterfaceParameterBase, TargetPropertyName) == 0x48, "Offset mismatch for UCameraObjectInterfaceParameterBase::TargetPropertyName");
static_assert(offsetof(UCameraObjectInterfaceParameterBase, Guid) == 0x4c, "Offset mismatch for UCameraObjectInterfaceParameterBase::Guid");

// Size: 0x80 (Inherited: 0x88, Single: 0xfffffff8)
class UCameraObjectInterfaceBlendableParameter : public UCameraObjectInterfaceParameterBase
{
public:
    uint8_t ParameterType[0x4]; // 0x60 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_64[0x4]; // 0x64 (Size: 0x4, Type: PaddingProperty)
    UScriptStruct* BlendableStructType; // 0x68 (Size: 0x8, Type: ObjectProperty)
    bool bIsPreBlended; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x3]; // 0x71 (Size: 0x3, Type: PaddingProperty)
    FCameraVariableID PrivateVariableID; // 0x74 (Size: 0x4, Type: StructProperty)
    UCameraVariableAsset* PrivateVariable; // 0x78 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UCameraObjectInterfaceBlendableParameter) == 0x80, "Size mismatch for UCameraObjectInterfaceBlendableParameter");
static_assert(offsetof(UCameraObjectInterfaceBlendableParameter, ParameterType) == 0x60, "Offset mismatch for UCameraObjectInterfaceBlendableParameter::ParameterType");
static_assert(offsetof(UCameraObjectInterfaceBlendableParameter, BlendableStructType) == 0x68, "Offset mismatch for UCameraObjectInterfaceBlendableParameter::BlendableStructType");
static_assert(offsetof(UCameraObjectInterfaceBlendableParameter, bIsPreBlended) == 0x70, "Offset mismatch for UCameraObjectInterfaceBlendableParameter::bIsPreBlended");
static_assert(offsetof(UCameraObjectInterfaceBlendableParameter, PrivateVariableID) == 0x74, "Offset mismatch for UCameraObjectInterfaceBlendableParameter::PrivateVariableID");
static_assert(offsetof(UCameraObjectInterfaceBlendableParameter, PrivateVariable) == 0x78, "Offset mismatch for UCameraObjectInterfaceBlendableParameter::PrivateVariable");

// Size: 0x78 (Inherited: 0x88, Single: 0xfffffff0)
class UCameraObjectInterfaceDataParameter : public UCameraObjectInterfaceParameterBase
{
public:
    uint8_t DataType[0x4]; // 0x60 (Size: 0x4, Type: EnumProperty)
    uint8_t DataContainerType[0x4]; // 0x64 (Size: 0x4, Type: EnumProperty)
    UObject* DataTypeObject; // 0x68 (Size: 0x8, Type: ObjectProperty)
    FCameraContextDataID PrivateDataID; // 0x70 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UCameraObjectInterfaceDataParameter) == 0x78, "Size mismatch for UCameraObjectInterfaceDataParameter");
static_assert(offsetof(UCameraObjectInterfaceDataParameter, DataType) == 0x60, "Offset mismatch for UCameraObjectInterfaceDataParameter::DataType");
static_assert(offsetof(UCameraObjectInterfaceDataParameter, DataContainerType) == 0x64, "Offset mismatch for UCameraObjectInterfaceDataParameter::DataContainerType");
static_assert(offsetof(UCameraObjectInterfaceDataParameter, DataTypeObject) == 0x68, "Offset mismatch for UCameraObjectInterfaceDataParameter::DataTypeObject");
static_assert(offsetof(UCameraObjectInterfaceDataParameter, PrivateDataID) == 0x70, "Offset mismatch for UCameraObjectInterfaceDataParameter::PrivateDataID");

// Size: 0x118 (Inherited: 0xc0, Single: 0x58)
class UCameraRigAsset : public UBaseCameraObject
{
public:
    uint8_t Pad_98[0x20]; // 0x98 (Size: 0x20, Type: PaddingProperty)
    UCameraNode* RootNode; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer GameplayTags; // 0xc0 (Size: 0x20, Type: StructProperty)
    TArray<UCameraRigTransition*> EnterTransitions; // 0xe0 (Size: 0x10, Type: ArrayProperty)
    TArray<UCameraRigTransition*> ExitTransitions; // 0xf0 (Size: 0x10, Type: ArrayProperty)
    uint8_t InitialOrientation[0x4]; // 0x100 (Size: 0x4, Type: EnumProperty)
    uint8_t BuildStatus; // 0x104 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_105[0x3]; // 0x105 (Size: 0x3, Type: PaddingProperty)
    FGuid Guid; // 0x108 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UCameraRigAsset) == 0x118, "Size mismatch for UCameraRigAsset");
static_assert(offsetof(UCameraRigAsset, RootNode) == 0xb8, "Offset mismatch for UCameraRigAsset::RootNode");
static_assert(offsetof(UCameraRigAsset, GameplayTags) == 0xc0, "Offset mismatch for UCameraRigAsset::GameplayTags");
static_assert(offsetof(UCameraRigAsset, EnterTransitions) == 0xe0, "Offset mismatch for UCameraRigAsset::EnterTransitions");
static_assert(offsetof(UCameraRigAsset, ExitTransitions) == 0xf0, "Offset mismatch for UCameraRigAsset::ExitTransitions");
static_assert(offsetof(UCameraRigAsset, InitialOrientation) == 0x100, "Offset mismatch for UCameraRigAsset::InitialOrientation");
static_assert(offsetof(UCameraRigAsset, BuildStatus) == 0x104, "Offset mismatch for UCameraRigAsset::BuildStatus");
static_assert(offsetof(UCameraRigAsset, Guid) == 0x108, "Offset mismatch for UCameraRigAsset::Guid");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UCameraRigTransitionCondition : public UObject
{
public:
};

static_assert(sizeof(UCameraRigTransitionCondition) == 0x30, "Size mismatch for UCameraRigTransitionCondition");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UCameraRigTransition : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TArray<UCameraRigTransitionCondition*> Conditions; // 0x30 (Size: 0x10, Type: ArrayProperty)
    UBlendCameraNode* Blend; // 0x40 (Size: 0x8, Type: ObjectProperty)
    uint8_t InitialOrientation[0x4]; // 0x48 (Size: 0x4, Type: EnumProperty)
    bool bOverrideInitialOrientation; // 0x4c (Size: 0x1, Type: BoolProperty)
    bool bAllowCameraRigMerging; // 0x4d (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4e[0x2]; // 0x4e (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(UCameraRigTransition) == 0x50, "Size mismatch for UCameraRigTransition");
static_assert(offsetof(UCameraRigTransition, Conditions) == 0x30, "Offset mismatch for UCameraRigTransition::Conditions");
static_assert(offsetof(UCameraRigTransition, Blend) == 0x40, "Offset mismatch for UCameraRigTransition::Blend");
static_assert(offsetof(UCameraRigTransition, InitialOrientation) == 0x48, "Offset mismatch for UCameraRigTransition::InitialOrientation");
static_assert(offsetof(UCameraRigTransition, bOverrideInitialOrientation) == 0x4c, "Offset mismatch for UCameraRigTransition::bOverrideInitialOrientation");
static_assert(offsetof(UCameraRigTransition, bAllowCameraRigMerging) == 0x4d, "Offset mismatch for UCameraRigTransition::bAllowCameraRigMerging");

// Size: 0xe0 (Inherited: 0xc0, Single: 0x20)
class UCameraShakeAsset : public UBaseCameraObject
{
public:
    uint8_t Pad_98[0x18]; // 0x98 (Size: 0x18, Type: PaddingProperty)
    UShakeCameraNode* RootNode; // 0xb0 (Size: 0x8, Type: ObjectProperty)
    USimpleFixedTimeBlendCameraNode* BlendIn; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    USimpleFixedTimeBlendCameraNode* BlendOut; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    bool bIsSingleInstance; // 0xc8 (Size: 0x1, Type: BoolProperty)
    uint8_t BuildStatus; // 0xc9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_ca[0x2]; // 0xca (Size: 0x2, Type: PaddingProperty)
    FGuid Guid; // 0xcc (Size: 0x10, Type: StructProperty)
    uint8_t Pad_dc[0x4]; // 0xdc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UCameraShakeAsset) == 0xe0, "Size mismatch for UCameraShakeAsset");
static_assert(offsetof(UCameraShakeAsset, RootNode) == 0xb0, "Offset mismatch for UCameraShakeAsset::RootNode");
static_assert(offsetof(UCameraShakeAsset, BlendIn) == 0xb8, "Offset mismatch for UCameraShakeAsset::BlendIn");
static_assert(offsetof(UCameraShakeAsset, BlendOut) == 0xc0, "Offset mismatch for UCameraShakeAsset::BlendOut");
static_assert(offsetof(UCameraShakeAsset, bIsSingleInstance) == 0xc8, "Offset mismatch for UCameraShakeAsset::bIsSingleInstance");
static_assert(offsetof(UCameraShakeAsset, BuildStatus) == 0xc9, "Offset mismatch for UCameraShakeAsset::BuildStatus");
static_assert(offsetof(UCameraShakeAsset, Guid) == 0xcc, "Offset mismatch for UCameraShakeAsset::Guid");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UCameraValueInterpolator : public UObject
{
public:
};

static_assert(sizeof(UCameraValueInterpolator) == 0x28, "Size mismatch for UCameraValueInterpolator");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UPopValueInterpolator : public UCameraValueInterpolator
{
public:
};

static_assert(sizeof(UPopValueInterpolator) == 0x28, "Size mismatch for UPopValueInterpolator");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UCameraVariableAsset : public UObject
{
public:
    bool bAutoReset; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bIsPrivate; // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bIsInput; // 0x2a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b[0x1]; // 0x2b (Size: 0x1, Type: PaddingProperty)
    FGuid Guid; // 0x2c (Size: 0x10, Type: StructProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UCameraVariableAsset) == 0x40, "Size mismatch for UCameraVariableAsset");
static_assert(offsetof(UCameraVariableAsset, bAutoReset) == 0x28, "Offset mismatch for UCameraVariableAsset::bAutoReset");
static_assert(offsetof(UCameraVariableAsset, bIsPrivate) == 0x29, "Offset mismatch for UCameraVariableAsset::bIsPrivate");
static_assert(offsetof(UCameraVariableAsset, bIsInput) == 0x2a, "Offset mismatch for UCameraVariableAsset::bIsInput");
static_assert(offsetof(UCameraVariableAsset, Guid) == 0x2c, "Offset mismatch for UCameraVariableAsset::Guid");

// Size: 0x48 (Inherited: 0x68, Single: 0xffffffe0)
class UBooleanCameraVariable : public UCameraVariableAsset
{
public:
    bool bDefaultValue; // 0x40 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UBooleanCameraVariable) == 0x48, "Size mismatch for UBooleanCameraVariable");
static_assert(offsetof(UBooleanCameraVariable, bDefaultValue) == 0x40, "Offset mismatch for UBooleanCameraVariable::bDefaultValue");

// Size: 0x48 (Inherited: 0x68, Single: 0xffffffe0)
class UInteger32CameraVariable : public UCameraVariableAsset
{
public:
    int32_t DefaultValue; // 0x40 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UInteger32CameraVariable) == 0x48, "Size mismatch for UInteger32CameraVariable");
static_assert(offsetof(UInteger32CameraVariable, DefaultValue) == 0x40, "Offset mismatch for UInteger32CameraVariable::DefaultValue");

// Size: 0x48 (Inherited: 0x68, Single: 0xffffffe0)
class UFloatCameraVariable : public UCameraVariableAsset
{
public:
    float DefaultValue; // 0x40 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFloatCameraVariable) == 0x48, "Size mismatch for UFloatCameraVariable");
static_assert(offsetof(UFloatCameraVariable, DefaultValue) == 0x40, "Offset mismatch for UFloatCameraVariable::DefaultValue");

// Size: 0x48 (Inherited: 0x68, Single: 0xffffffe0)
class UDoubleCameraVariable : public UCameraVariableAsset
{
public:
    double DefaultValue; // 0x40 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(UDoubleCameraVariable) == 0x48, "Size mismatch for UDoubleCameraVariable");
static_assert(offsetof(UDoubleCameraVariable, DefaultValue) == 0x40, "Offset mismatch for UDoubleCameraVariable::DefaultValue");

// Size: 0x48 (Inherited: 0x68, Single: 0xffffffe0)
class UVector2fCameraVariable : public UCameraVariableAsset
{
public:
    FVector2f DefaultValue; // 0x40 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(UVector2fCameraVariable) == 0x48, "Size mismatch for UVector2fCameraVariable");
static_assert(offsetof(UVector2fCameraVariable, DefaultValue) == 0x40, "Offset mismatch for UVector2fCameraVariable::DefaultValue");

// Size: 0x50 (Inherited: 0x68, Single: 0xffffffe8)
class UVector2dCameraVariable : public UCameraVariableAsset
{
public:
    FVector2D DefaultValue; // 0x40 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UVector2dCameraVariable) == 0x50, "Size mismatch for UVector2dCameraVariable");
static_assert(offsetof(UVector2dCameraVariable, DefaultValue) == 0x40, "Offset mismatch for UVector2dCameraVariable::DefaultValue");

// Size: 0x50 (Inherited: 0x68, Single: 0xffffffe8)
class UVector3fCameraVariable : public UCameraVariableAsset
{
public:
    FVector3f DefaultValue; // 0x40 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UVector3fCameraVariable) == 0x50, "Size mismatch for UVector3fCameraVariable");
static_assert(offsetof(UVector3fCameraVariable, DefaultValue) == 0x40, "Offset mismatch for UVector3fCameraVariable::DefaultValue");

// Size: 0x58 (Inherited: 0x68, Single: 0xfffffff0)
class UVector3dCameraVariable : public UCameraVariableAsset
{
public:
    FVector3d DefaultValue; // 0x40 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UVector3dCameraVariable) == 0x58, "Size mismatch for UVector3dCameraVariable");
static_assert(offsetof(UVector3dCameraVariable, DefaultValue) == 0x40, "Offset mismatch for UVector3dCameraVariable::DefaultValue");

// Size: 0x50 (Inherited: 0x68, Single: 0xffffffe8)
class UVector4fCameraVariable : public UCameraVariableAsset
{
public:
    FVector4f DefaultValue; // 0x40 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UVector4fCameraVariable) == 0x50, "Size mismatch for UVector4fCameraVariable");
static_assert(offsetof(UVector4fCameraVariable, DefaultValue) == 0x40, "Offset mismatch for UVector4fCameraVariable::DefaultValue");

// Size: 0x60 (Inherited: 0x68, Single: 0xfffffff8)
class UVector4dCameraVariable : public UCameraVariableAsset
{
public:
    FVector4d DefaultValue; // 0x40 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UVector4dCameraVariable) == 0x60, "Size mismatch for UVector4dCameraVariable");
static_assert(offsetof(UVector4dCameraVariable, DefaultValue) == 0x40, "Offset mismatch for UVector4dCameraVariable::DefaultValue");

// Size: 0x50 (Inherited: 0x68, Single: 0xffffffe8)
class URotator3fCameraVariable : public UCameraVariableAsset
{
public:
    FRotator3f DefaultValue; // 0x40 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(URotator3fCameraVariable) == 0x50, "Size mismatch for URotator3fCameraVariable");
static_assert(offsetof(URotator3fCameraVariable, DefaultValue) == 0x40, "Offset mismatch for URotator3fCameraVariable::DefaultValue");

// Size: 0x58 (Inherited: 0x68, Single: 0xfffffff0)
class URotator3dCameraVariable : public UCameraVariableAsset
{
public:
    FRotator3d DefaultValue; // 0x40 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(URotator3dCameraVariable) == 0x58, "Size mismatch for URotator3dCameraVariable");
static_assert(offsetof(URotator3dCameraVariable, DefaultValue) == 0x40, "Offset mismatch for URotator3dCameraVariable::DefaultValue");

// Size: 0x70 (Inherited: 0x68, Single: 0x8)
class UTransform3fCameraVariable : public UCameraVariableAsset
{
public:
    FTransform3f DefaultValue; // 0x40 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(UTransform3fCameraVariable) == 0x70, "Size mismatch for UTransform3fCameraVariable");
static_assert(offsetof(UTransform3fCameraVariable, DefaultValue) == 0x40, "Offset mismatch for UTransform3fCameraVariable::DefaultValue");

// Size: 0xa0 (Inherited: 0x68, Single: 0x38)
class UTransform3dCameraVariable : public UCameraVariableAsset
{
public:
    FTransform3d DefaultValue; // 0x40 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(UTransform3dCameraVariable) == 0xa0, "Size mismatch for UTransform3dCameraVariable");
static_assert(offsetof(UTransform3dCameraVariable, DefaultValue) == 0x40, "Offset mismatch for UTransform3dCameraVariable::DefaultValue");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UCameraVariableCollection : public UObject
{
public:
    TArray<UCameraVariableAsset*> Variables; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCameraVariableCollection) == 0x38, "Size mismatch for UCameraVariableCollection");
static_assert(offsetof(UCameraVariableCollection, Variables) == 0x28, "Offset mismatch for UCameraVariableCollection::Variables");

// Size: 0x58 (Inherited: 0x98, Single: 0xffffffc0)
class UDefaultRootCameraNode : public URootCameraNode
{
public:
    UBlendStackCameraNode* BaseLayer; // 0x38 (Size: 0x8, Type: ObjectProperty)
    UBlendStackCameraNode* MainLayer; // 0x40 (Size: 0x8, Type: ObjectProperty)
    UBlendStackCameraNode* GlobalLayer; // 0x48 (Size: 0x8, Type: ObjectProperty)
    UBlendStackCameraNode* VisualLayer; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDefaultRootCameraNode) == 0x58, "Size mismatch for UDefaultRootCameraNode");
static_assert(offsetof(UDefaultRootCameraNode, BaseLayer) == 0x38, "Offset mismatch for UDefaultRootCameraNode::BaseLayer");
static_assert(offsetof(UDefaultRootCameraNode, MainLayer) == 0x40, "Offset mismatch for UDefaultRootCameraNode::MainLayer");
static_assert(offsetof(UDefaultRootCameraNode, GlobalLayer) == 0x48, "Offset mismatch for UDefaultRootCameraNode::GlobalLayer");
static_assert(offsetof(UDefaultRootCameraNode, VisualLayer) == 0x50, "Offset mismatch for UDefaultRootCameraNode::VisualLayer");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class URootCameraNode : public UCameraNode
{
public:
};

static_assert(sizeof(URootCameraNode) == 0x38, "Size mismatch for URootCameraNode");

// Size: 0x80 (Inherited: 0x28, Single: 0x58)
class UBlueprintCameraDirectorEvaluator : public UObject
{
public:

public:
    virtual void ActivateCameraDirector(const FBlueprintCameraDirectorActivateParams Params); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void ActivateCameraRig(UCameraRigAsset*& CameraRig, bool& bForceNewInstance); // 0xb7372d8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void ActivateCameraRigViaProxy(UCameraRigProxyAsset*& CameraRigProxy); // 0xb737510 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void ActivatePersistentBaseCameraRig(UCameraRigAsset*& CameraRigPrefab); // 0xb737930 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void ActivatePersistentGlobalCameraRig(UCameraRigAsset*& CameraRigPrefab); // 0xb737d64 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void ActivatePersistentVisualCameraRig(UCameraRigAsset*& CameraRigPrefab); // 0xb738198 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    virtual void DeactivateCameraDirector(const FBlueprintCameraDirectorDeactivateParams Params); // 0x288a61c (Index: 0x6, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void DeactivatePersistentBaseCameraRig(UCameraRigAsset*& CameraRigPrefab); // 0xb738314 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void DeactivatePersistentGlobalCameraRig(UCameraRigAsset*& CameraRigPrefab); // 0xb73847c (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void DeactivatePersistentVisualCameraRig(UCameraRigAsset*& CameraRigPrefab); // 0xb7385e4 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    AActor* FindEvaluationContextOwnerActor(UClass*& ActorClass) const; // 0xb73874c (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBlueprintCameraNodeEvaluationResult GetConditionalContextResult(ECameraEvaluationDataCondition& Condition) const; // 0xb738f78 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBlueprintCameraPose GetInitialContextCameraPose() const; // 0xb739978 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBlueprintCameraNodeEvaluationResult GetInitialContextResult() const; // 0xb7399dc (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBlueprintCameraVariableTable GetInitialContextVariableTable() const; // 0xb739a24 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void RunCameraDirector(const FBlueprintCameraDirectorEvaluationParams Params); // 0x288a61c (Index: 0xf, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void SetInitialContextCameraPose(const FBlueprintCameraPose InCameraPose); // 0xb73e5cc (Index: 0x10, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UBlueprintCameraDirectorEvaluator) == 0x80, "Size mismatch for UBlueprintCameraDirectorEvaluator");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UBlueprintCameraDirector : public UCameraDirector
{
public:
    UClass* CameraDirectorEvaluatorClass; // 0x28 (Size: 0x8, Type: ClassProperty)
    UCameraRigProxyTable* CameraRigProxyTable; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UBlueprintCameraDirector) == 0x38, "Size mismatch for UBlueprintCameraDirector");
static_assert(offsetof(UBlueprintCameraDirector, CameraDirectorEvaluatorClass) == 0x28, "Offset mismatch for UBlueprintCameraDirector::CameraDirectorEvaluatorClass");
static_assert(offsetof(UBlueprintCameraDirector, CameraRigProxyTable) == 0x30, "Offset mismatch for UBlueprintCameraDirector::CameraRigProxyTable");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UCameraDirectorStateTreeSchema : public UStateTreeSchema
{
public:
    TArray<FStateTreeExternalDataDesc> ContextDataDescs; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UCameraDirectorStateTreeSchema) == 0x38, "Size mismatch for UCameraDirectorStateTreeSchema");
static_assert(offsetof(UCameraDirectorStateTreeSchema, ContextDataDescs) == 0x28, "Offset mismatch for UCameraDirectorStateTreeSchema::ContextDataDescs");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UPriorityQueueCameraDirector : public UCameraDirector
{
public:
};

static_assert(sizeof(UPriorityQueueCameraDirector) == 0x28, "Size mismatch for UPriorityQueueCameraDirector");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class USingleCameraDirector : public UCameraDirector
{
public:
    UCameraRigAsset* CameraRig; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(USingleCameraDirector) == 0x30, "Size mismatch for USingleCameraDirector");
static_assert(offsetof(USingleCameraDirector, CameraRig) == 0x28, "Offset mismatch for USingleCameraDirector::CameraRig");

// Size: 0x58 (Inherited: 0x50, Single: 0x8)
class UStateTreeCameraDirector : public UCameraDirector
{
public:
    FStateTreeReference StateTreeReference; // 0x28 (Size: 0x28, Type: StructProperty)
    UCameraRigProxyTable* CameraRigProxyTable; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UStateTreeCameraDirector) == 0x58, "Size mismatch for UStateTreeCameraDirector");
static_assert(offsetof(UStateTreeCameraDirector, StateTreeReference) == 0x28, "Offset mismatch for UStateTreeCameraDirector::StateTreeReference");
static_assert(offsetof(UStateTreeCameraDirector, CameraRigProxyTable) == 0x50, "Offset mismatch for UStateTreeCameraDirector::CameraRigProxyTable");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UActivateCameraRigFunctions : public UBlueprintFunctionLibrary
{
public:

public:
    static void ActivatePersistentBaseCameraRig(UObject*& WorldContextObject, APlayerController*& PlayerController, UCameraRigAsset*& CameraRig); // 0xb737664 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ActivatePersistentGlobalCameraRig(UObject*& WorldContextObject, APlayerController*& PlayerController, UCameraRigAsset*& CameraRig); // 0xb737a98 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ActivatePersistentVisualCameraRig(UObject*& WorldContextObject, APlayerController*& PlayerController, UCameraRigAsset*& CameraRig); // 0xb737ecc (Index: 0x2, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UActivateCameraRigFunctions) == 0x28, "Size mismatch for UActivateCameraRigFunctions");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class UCameraComponentCameraNode : public UCameraNode
{
public:
};

static_assert(sizeof(UCameraComponentCameraNode) == 0x38, "Size mismatch for UCameraComponentCameraNode");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class UCalcCameraActorCameraNode : public UCameraNode
{
public:
};

static_assert(sizeof(UCalcCameraActorCameraNode) == 0x38, "Size mismatch for UCalcCameraActorCameraNode");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlueprintCameraContextDataTableFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static UClass* GetClassData(const FBlueprintCameraContextDataTable ContextDataTable, FCameraContextDataID& DataID); // 0xb738de0 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static char GetEnumData(const FBlueprintCameraContextDataTable ContextDataTable, FCameraContextDataID& DataID, UEnum*& const EnumType); // 0xb739450 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FName GetNameData(const FBlueprintCameraContextDataTable ContextDataTable, FCameraContextDataID& DataID); // 0xb739d98 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static UObject* GetObjectData(const FBlueprintCameraContextDataTable ContextDataTable, FCameraContextDataID& DataID); // 0xb738de0 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FString GetStringData(const FBlueprintCameraContextDataTable ContextDataTable, FCameraContextDataID& DataID); // 0xb73a294 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FInstancedStruct GetStructData(const FBlueprintCameraContextDataTable ContextDataTable, FCameraContextDataID& DataID, UScriptStruct*& const DataStructType); // 0xb73a58c (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool SetClassData(const FBlueprintCameraContextDataTable ContextDataTable, FCameraContextDataID& DataID, UClass*& Data); // 0xb73c4b8 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool SetEnumData(const FBlueprintCameraContextDataTable ContextDataTable, FCameraContextDataID& DataID, UEnum*& const EnumType, char& Data); // 0xb73d564 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool SetNameData(const FBlueprintCameraContextDataTable ContextDataTable, FCameraContextDataID& DataID, const FName Data); // 0xb73f3e8 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool SetObjectData(const FBlueprintCameraContextDataTable ContextDataTable, FCameraContextDataID& DataID, UObject*& Data); // 0xb73fe24 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool SetStringData(const FBlueprintCameraContextDataTable ContextDataTable, FCameraContextDataID& DataID, FString& Data); // 0xb741024 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool SetStructData(const FBlueprintCameraContextDataTable ContextDataTable, FCameraContextDataID& DataID, const FInstancedStruct Data); // 0xb741c98 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UBlueprintCameraContextDataTableFunctionLibrary) == 0x28, "Size mismatch for UBlueprintCameraContextDataTableFunctionLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlueprintCameraPoseFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FVector GetAimDir(const FBlueprintCameraPose CameraPose); // 0xb738a28 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FRay GetAimRay(const FBlueprintCameraPose CameraPose); // 0xb738b18 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static double GetEffectiveFieldOfView(const FBlueprintCameraPose CameraPose); // 0xb739354 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static double GetFieldOfView(const FBlueprintCameraPose CameraPose); // 0xb739664 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static double GetFocalLength(const FBlueprintCameraPose CameraPose); // 0xb739898 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FVector GetLocation(const FBlueprintCameraPose CameraPose); // 0xb739cb4 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FRotator GetRotation(const FBlueprintCameraPose CameraPose); // 0xb739f10 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static double GetSensorAspectRatio(const FBlueprintCameraPose CameraPose); // 0xb73a1ac (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FVector GetTarget(const FBlueprintCameraPose CameraPose); // 0xb73a7bc (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector GetTargetAtDistance(const FBlueprintCameraPose CameraPose, double& TargetDistance); // 0xb73a8e8 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static double GetTargetDistance(const FBlueprintCameraPose CameraPose); // 0xb73aa70 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FTransform GetTransform(const FBlueprintCameraPose CameraPose); // 0xb73ab4c (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FBlueprintCameraPose MakeCameraPoseFromCameraComponent(UCameraComponent*& const CameraComponent); // 0xb73b318 (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FBlueprintCameraPose MakeCameraPoseFromCineCameraComponent(UCineCameraComponent*& const CameraComponent); // 0xb73b494 (Index: 0xd, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FBlueprintCameraPose SetFieldOfView(const FBlueprintCameraPose CameraPose, float& FieldOfView); // 0xb73dc58 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FBlueprintCameraPose SetFocalLength(const FBlueprintCameraPose CameraPose, float& FocalLength); // 0xb73e408 (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FBlueprintCameraPose SetLocation(const FBlueprintCameraPose CameraPose, const FVector Location); // 0xb73edac (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FBlueprintCameraPose SetRotation(const FBlueprintCameraPose CameraPose, const FRotator Rotation); // 0xb740400 (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FBlueprintCameraPose SetTargetDistance(const FBlueprintCameraPose CameraPose, double& TargetDistance); // 0xb7422bc (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FBlueprintCameraPose SetTransform(const FBlueprintCameraPose CameraPose, const FTransform Transform); // 0xb742484 (Index: 0x13, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UBlueprintCameraPoseFunctionLibrary) == 0x28, "Size mismatch for UBlueprintCameraPoseFunctionLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlueprintCameraVariableTableFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool GetBooleanCameraVariable(const FBlueprintCameraVariableTable VariableTable, UBooleanCameraVariable*& Variable); // 0xb738c58 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static double GetDoubleCameraVariable(const FBlueprintCameraVariableTable VariableTable, UDoubleCameraVariable*& Variable); // 0xb739200 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static float GetFloatCameraVariable(const FBlueprintCameraVariableTable VariableTable, UFloatCameraVariable*& Variable); // 0xb739744 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static int32_t GetInteger32CameraVariable(const FBlueprintCameraVariableTable VariableTable, UInteger32CameraVariable*& Variable); // 0xb739b2c (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FRotator GetRotatorCameraVariable(const FBlueprintCameraVariableTable VariableTable, URotator3dCameraVariable*& Variable); // 0xb739ff8 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FTransform GetTransformCameraVariable(const FBlueprintCameraVariableTable VariableTable, UTransform3dCameraVariable*& Variable); // 0xb73ac80 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FVector2D GetVector2CameraVariable(const FBlueprintCameraVariableTable VariableTable, UVector2dCameraVariable*& Variable); // 0xb73ae20 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FVector GetVector3CameraVariable(const FBlueprintCameraVariableTable VariableTable, UVector3dCameraVariable*& Variable); // 0xb73afb4 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FVector4 GetVector4CameraVariable(const FBlueprintCameraVariableTable VariableTable, UVector4dCameraVariable*& Variable); // 0xb73b168 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void SetBooleanCameraVariable(const FBlueprintCameraVariableTable VariableTable, UBooleanCameraVariable*& Variable, bool& Value); // 0xb73ba70 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetDoubleCameraVariable(const FBlueprintCameraVariableTable VariableTable, UDoubleCameraVariable*& Variable, double& Value); // 0xb73ca94 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetFloatCameraVariable(const FBlueprintCameraVariableTable VariableTable, UFloatCameraVariable*& Variable, float& Value); // 0xb73de1c (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetInteger32CameraVariable(const FBlueprintCameraVariableTable VariableTable, UInteger32CameraVariable*& Variable, int32_t& Value); // 0xb73e7a4 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetRotatorCameraVariable(const FBlueprintCameraVariableTable VariableTable, URotator3dCameraVariable*& Variable, const FRotator Value); // 0xb7405dc (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void SetTransformCameraVariable(const FBlueprintCameraVariableTable VariableTable, UTransform3dCameraVariable*& Variable, const FTransform Value); // 0xb742698 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void SetVector2CameraVariable(const FBlueprintCameraVariableTable VariableTable, UVector2dCameraVariable*& Variable, const FVector2D Value); // 0xb742dcc (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void SetVector3CameraVariable(const FBlueprintCameraVariableTable VariableTable, UVector3dCameraVariable*& Variable, const FVector Value); // 0xb7405dc (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void SetVector4CameraVariable(const FBlueprintCameraVariableTable VariableTable, UVector4dCameraVariable*& Variable, const FVector4 Value); // 0xb743404 (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UBlueprintCameraVariableTableFunctionLibrary) == 0x28, "Size mismatch for UBlueprintCameraVariableTableFunctionLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCameraRigParameterInterop : public UBlueprintFunctionLibrary
{
public:

public:
    static void SetBlendableStructParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, const FInstancedStruct ParameterValue); // 0xb73b688 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetBooleanParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, bool& ParameterValue); // 0xb73bc80 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetClassArrayParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, const TArray<UClass*> ParameterValue); // 0xb73c050 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetClassParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, UClass*& ParameterValue); // 0xb73c694 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetDoubleParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, double& ParameterValue); // 0xb73ccb0 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetEnumArrayParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, UEnum*& const EnumType, const TArray<char> ParameterValue); // 0xb73d084 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetEnumParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, UEnum*& const EnumType, char& ParameterValue); // 0xb73d7ec (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetFloatParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, double& ParameterValue); // 0xb73e034 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetIntegerParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, int32_t& ParameterValue); // 0xb73e9ac (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetNameArrayParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, const TArray<FName> ParameterValue); // 0xb73ef7c (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetNameParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, FName& ParameterValue); // 0xb73f600 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetObjectArrayParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, const TArray<UObject*> ParameterValue); // 0xb73f9d4 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetObjectParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, UObject*& ParameterValue); // 0xb740000 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetRotatorParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, FRotator& ParameterValue); // 0xb740804 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void SetStringArrayParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, const TArray<FString> ParameterValue); // 0xb740c20 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetStringParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, FString& ParameterValue); // 0xb7413bc (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetStructArrayParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, const TArray<FInstancedStruct> ParameterValue); // 0xb741898 (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetStructParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, const FInstancedStruct ParameterValue); // 0xb741ea0 (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void SetTransformParameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, FTransform& ParameterValue); // 0xb742928 (Index: 0x12, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void SetVector2Parameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, FVector2D& ParameterValue); // 0xb742ff4 (Index: 0x13, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void SetVector3Parameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, FVector& ParameterValue); // 0xb740804 (Index: 0x14, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static void SetVector4Parameter(FBlueprintCameraNodeEvaluationResult Result, UCameraRigAsset*& CameraRig, FString& ParameterName, FVector4& ParameterValue); // 0xb7435d8 (Index: 0x15, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UCameraRigParameterInterop) == 0x28, "Size mismatch for UCameraRigParameterInterop");

// Size: 0xe0 (Inherited: 0xe0, Single: 0x0)
class UControllerGameplayCameraEvaluationComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x20]; // 0xb8 (Size: 0x20, Type: PaddingProperty)
    UGameplayCameraSystemHost* CameraSystemHost; // 0xd8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UControllerGameplayCameraEvaluationComponent) == 0xe0, "Size mismatch for UControllerGameplayCameraEvaluationComponent");
static_assert(offsetof(UControllerGameplayCameraEvaluationComponent, CameraSystemHost) == 0xd8, "Offset mismatch for UControllerGameplayCameraEvaluationComponent::CameraSystemHost");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class AGameplayCameraActor : public AActor
{
public:
    UGameplayCameraComponent* CameraComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)

public:
    UGameplayCameraComponent* GetCameraComponent() const; // 0xa598a54 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(AGameplayCameraActor) == 0x2b0, "Size mismatch for AGameplayCameraActor");
static_assert(offsetof(AGameplayCameraActor, CameraComponent) == 0x2a8, "Offset mismatch for AGameplayCameraActor::CameraComponent");

// Size: 0x2b0 (Inherited: 0x590, Single: 0xfffffd20)
class UGameplayCameraComponent : public UGameplayCameraComponentBase
{
public:
    FCameraAssetReference CameraReference; // 0x270 (Size: 0x38, Type: StructProperty)
    UCameraAsset* Camera; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UGameplayCameraComponent) == 0x2b0, "Size mismatch for UGameplayCameraComponent");
static_assert(offsetof(UGameplayCameraComponent, CameraReference) == 0x270, "Offset mismatch for UGameplayCameraComponent::CameraReference");
static_assert(offsetof(UGameplayCameraComponent, Camera) == 0x2a8, "Offset mismatch for UGameplayCameraComponent::Camera");

// Size: 0x270 (Inherited: 0x320, Single: 0xffffff50)
class UGameplayCameraComponentBase : public USceneComponent
{
public:
    TEnumAsByte<EAutoReceiveInput> AutoActivateForPlayer; // 0x240 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_241[0x7]; // 0x241 (Size: 0x7, Type: PaddingProperty)
    UCineCameraComponent* OutputCameraComponent; // 0x248 (Size: 0x8, Type: ObjectProperty)
    UGameplayCameraSystemHost* CameraSystemHost; // 0x250 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_258[0x18]; // 0x258 (Size: 0x18, Type: PaddingProperty)

public:
    void ActivateCameraForPlayerController(APlayerController*& PlayerController); // 0xb73706c (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void ActivateCameraForPlayerIndex(int32_t& PlayerIndex); // 0xb737198 (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void DeactivateCamera(); // 0xb738300 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    FBlueprintCameraNodeEvaluationResult GetConditionalResult(ECameraEvaluationDataCondition& Condition) const; // 0xb7390cc (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBlueprintCameraPose GetInitialPose() const; // 0xb739a70 (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBlueprintCameraNodeEvaluationResult GetInitialResult() const; // 0xb739ad4 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FBlueprintCameraVariableTable GetInitialVariableTable() const; // 0xb739b00 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UCineCameraComponent* GetOutputCameraComponent() const; // 0xa291d20 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool SetInitialPose(const FBlueprintCameraPose CameraPose); // 0xb73e6b8 (Index: 0x8, Flags: Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGameplayCameraComponentBase) == 0x270, "Size mismatch for UGameplayCameraComponentBase");
static_assert(offsetof(UGameplayCameraComponentBase, AutoActivateForPlayer) == 0x240, "Offset mismatch for UGameplayCameraComponentBase::AutoActivateForPlayer");
static_assert(offsetof(UGameplayCameraComponentBase, OutputCameraComponent) == 0x248, "Offset mismatch for UGameplayCameraComponentBase::OutputCameraComponent");
static_assert(offsetof(UGameplayCameraComponentBase, CameraSystemHost) == 0x250, "Offset mismatch for UGameplayCameraComponentBase::CameraSystemHost");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class AGameplayCameraRigActor : public AActor
{
public:
    UGameplayCameraRigComponent* CameraRigComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)

public:
    UGameplayCameraRigComponent* GetCameraRigComponent() const; // 0xa598a54 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(AGameplayCameraRigActor) == 0x2b0, "Size mismatch for AGameplayCameraRigActor");
static_assert(offsetof(AGameplayCameraRigActor, CameraRigComponent) == 0x2a8, "Offset mismatch for AGameplayCameraRigActor::CameraRigComponent");

// Size: 0x3a0 (Inherited: 0x590, Single: 0xfffffe10)
class UGameplayCameraRigComponent : public UGameplayCameraComponentBase
{
public:
    FCameraRigAssetReference CameraRigReference; // 0x270 (Size: 0x120, Type: StructProperty)
    UCameraAsset* GeneratedCameraAsset; // 0x390 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_398[0x8]; // 0x398 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UGameplayCameraRigComponent) == 0x3a0, "Size mismatch for UGameplayCameraRigComponent");
static_assert(offsetof(UGameplayCameraRigComponent, CameraRigReference) == 0x270, "Offset mismatch for UGameplayCameraRigComponent::CameraRigReference");
static_assert(offsetof(UGameplayCameraRigComponent, GeneratedCameraAsset) == 0x390, "Offset mismatch for UGameplayCameraRigComponent::GeneratedCameraAsset");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class AGameplayCameraSystemActor : public AActor
{
public:
    UGameplayCameraSystemComponent* CameraSystemComponent; // 0x2a8 (Size: 0x8, Type: ObjectProperty)

public:
    static void AutoManageActiveViewTarget(APlayerController*& PlayerController); // 0xb7664f8 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static AGameplayCameraSystemActor* GetAutoSpawnedCameraSystemActor(APlayerController*& PlayerController, bool& bSpawnIfMissing); // 0xb766750 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    UGameplayCameraSystemComponent* GetCameraSystemComponent() const; // 0xa598a54 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(AGameplayCameraSystemActor) == 0x2b0, "Size mismatch for AGameplayCameraSystemActor");
static_assert(offsetof(AGameplayCameraSystemActor, CameraSystemComponent) == 0x2a8, "Offset mismatch for AGameplayCameraSystemActor::CameraSystemComponent");

// Size: 0x260 (Inherited: 0x320, Single: 0xffffff40)
class UGameplayCameraSystemComponent : public USceneComponent
{
public:
    TEnumAsByte<EAutoReceiveInput> AutoActivateForPlayer; // 0x240 (Size: 0x1, Type: ByteProperty)
    bool bSetPlayerControllerRotation; // 0x241 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_242[0x6]; // 0x242 (Size: 0x6, Type: PaddingProperty)
    UGameplayCameraSystemHost* CameraSystemHost; // 0x248 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<APlayerController*> WeakPlayerController; // 0x250 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_258[0x8]; // 0x258 (Size: 0x8, Type: PaddingProperty)

public:
    void ActivateCameraSystemForPlayerController(APlayerController*& PlayerController); // 0xb766050 (Index: 0x0, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void ActivateCameraSystemForPlayerIndex(int32_t& PlayerIndex); // 0xb76617c (Index: 0x1, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void DeactivateCameraSystem(AActor*& NextViewTarget); // 0xb766610 (Index: 0x2, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    bool IsCameraSystemActiveForPlayController(APlayerController*& PlayerController) const; // 0xb76695c (Index: 0x3, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FCameraRigInstanceID StartGlobalCameraModifierRig(UCameraRigAsset*& const CameraRig, int32_t& OrderKey); // 0xb766b6c (Index: 0x4, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    FCameraRigInstanceID StartVisualCameraModifierRig(UCameraRigAsset*& const CameraRig, int32_t& OrderKey); // 0xb766dc0 (Index: 0x5, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
    void StopCameraModifierRig(FCameraRigInstanceID& InstanceID, bool& bImmediately); // 0xb767010 (Index: 0x6, Flags: Final|RequiredAPI|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UGameplayCameraSystemComponent) == 0x260, "Size mismatch for UGameplayCameraSystemComponent");
static_assert(offsetof(UGameplayCameraSystemComponent, AutoActivateForPlayer) == 0x240, "Offset mismatch for UGameplayCameraSystemComponent::AutoActivateForPlayer");
static_assert(offsetof(UGameplayCameraSystemComponent, bSetPlayerControllerRotation) == 0x241, "Offset mismatch for UGameplayCameraSystemComponent::bSetPlayerControllerRotation");
static_assert(offsetof(UGameplayCameraSystemComponent, CameraSystemHost) == 0x248, "Offset mismatch for UGameplayCameraSystemComponent::CameraSystemHost");
static_assert(offsetof(UGameplayCameraSystemComponent, WeakPlayerController) == 0x250, "Offset mismatch for UGameplayCameraSystemComponent::WeakPlayerController");

// Size: 0xf8 (Inherited: 0xe0, Single: 0x18)
class UGameplayControlRotationComponent : public UActorComponent
{
public:
    TArray<UInputAction*> AxisActions; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    float AxisActionAngularSpeedThreshold; // 0xc8 (Size: 0x4, Type: FloatProperty)
    float AxisActionMagnitudeThreshold; // 0xcc (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EAutoReceiveInput> AutoActivateForPlayer; // 0xd0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_d1[0x7]; // 0xd1 (Size: 0x7, Type: PaddingProperty)
    APlayerController* PlayerController; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UGameplayCameraSystemHost* CameraSystemHost; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_e8[0x10]; // 0xe8 (Size: 0x10, Type: PaddingProperty)

public:
    void ActivateControlRotationManagementForPlayerController(APlayerController*& PlayerController); // 0xb7662a4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void ActivateControlRotationManagementForPlayerIndex(int32_t& PlayerIndex); // 0xb7663d0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void DeactivateControlRotationManagement(); // 0xb76673c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UGameplayControlRotationComponent) == 0xf8, "Size mismatch for UGameplayControlRotationComponent");
static_assert(offsetof(UGameplayControlRotationComponent, AxisActions) == 0xb8, "Offset mismatch for UGameplayControlRotationComponent::AxisActions");
static_assert(offsetof(UGameplayControlRotationComponent, AxisActionAngularSpeedThreshold) == 0xc8, "Offset mismatch for UGameplayControlRotationComponent::AxisActionAngularSpeedThreshold");
static_assert(offsetof(UGameplayControlRotationComponent, AxisActionMagnitudeThreshold) == 0xcc, "Offset mismatch for UGameplayControlRotationComponent::AxisActionMagnitudeThreshold");
static_assert(offsetof(UGameplayControlRotationComponent, AutoActivateForPlayer) == 0xd0, "Offset mismatch for UGameplayControlRotationComponent::AutoActivateForPlayer");
static_assert(offsetof(UGameplayControlRotationComponent, PlayerController) == 0xd8, "Offset mismatch for UGameplayControlRotationComponent::PlayerController");
static_assert(offsetof(UGameplayControlRotationComponent, CameraSystemHost) == 0xe0, "Offset mismatch for UGameplayControlRotationComponent::CameraSystemHost");

// Size: 0x58 (Inherited: 0x58, Single: 0x0)
class UGameplayCamerasSettings : public UDeveloperSettings
{
public:
    bool bAutoSpawnCameraSystemActor; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bAutoSpawnCameraSystemActorSetsControlRotation; // 0x31 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x2]; // 0x32 (Size: 0x2, Type: PaddingProperty)
    int32_t CombinedCameraRigNumThreshold; // 0x34 (Size: 0x4, Type: IntProperty)
    double DefaultIKAimingAngleTolerance; // 0x38 (Size: 0x8, Type: DoubleProperty)
    double DefaultIKAimingDistanceTolerance; // 0x40 (Size: 0x8, Type: DoubleProperty)
    char DefaultIKAimingMaxIterations; // 0x48 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
    double DefaultIKAimingMinDistance; // 0x50 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(UGameplayCamerasSettings) == 0x58, "Size mismatch for UGameplayCamerasSettings");
static_assert(offsetof(UGameplayCamerasSettings, bAutoSpawnCameraSystemActor) == 0x30, "Offset mismatch for UGameplayCamerasSettings::bAutoSpawnCameraSystemActor");
static_assert(offsetof(UGameplayCamerasSettings, bAutoSpawnCameraSystemActorSetsControlRotation) == 0x31, "Offset mismatch for UGameplayCamerasSettings::bAutoSpawnCameraSystemActorSetsControlRotation");
static_assert(offsetof(UGameplayCamerasSettings, CombinedCameraRigNumThreshold) == 0x34, "Offset mismatch for UGameplayCamerasSettings::CombinedCameraRigNumThreshold");
static_assert(offsetof(UGameplayCamerasSettings, DefaultIKAimingAngleTolerance) == 0x38, "Offset mismatch for UGameplayCamerasSettings::DefaultIKAimingAngleTolerance");
static_assert(offsetof(UGameplayCamerasSettings, DefaultIKAimingDistanceTolerance) == 0x40, "Offset mismatch for UGameplayCamerasSettings::DefaultIKAimingDistanceTolerance");
static_assert(offsetof(UGameplayCamerasSettings, DefaultIKAimingMaxIterations) == 0x48, "Offset mismatch for UGameplayCamerasSettings::DefaultIKAimingMaxIterations");
static_assert(offsetof(UGameplayCamerasSettings, DefaultIKAimingMinDistance) == 0x50, "Offset mismatch for UGameplayCamerasSettings::DefaultIKAimingMinDistance");

// Size: 0x58 (Inherited: 0xc0, Single: 0xffffff98)
class UMovieSceneCameraFramingZonePropertySystem : public UMovieScenePropertySystem
{
public:
};

static_assert(sizeof(UMovieSceneCameraFramingZonePropertySystem) == 0x58, "Size mismatch for UMovieSceneCameraFramingZonePropertySystem");

// Size: 0x570 (Inherited: 0x1f0, Single: 0x380)
class UMovieSceneCameraFramingZoneSection : public UMovieSceneSection
{
public:
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)
    FMovieSceneDoubleChannel LeftMarginCurve; // 0x110 (Size: 0x118, Type: StructProperty)
    FMovieSceneDoubleChannel TopMarginCurve; // 0x228 (Size: 0x118, Type: StructProperty)
    FMovieSceneDoubleChannel RightMarginCurve; // 0x340 (Size: 0x118, Type: StructProperty)
    FMovieSceneDoubleChannel BottomMarginCurve; // 0x458 (Size: 0x118, Type: StructProperty)
};

static_assert(sizeof(UMovieSceneCameraFramingZoneSection) == 0x570, "Size mismatch for UMovieSceneCameraFramingZoneSection");
static_assert(offsetof(UMovieSceneCameraFramingZoneSection, LeftMarginCurve) == 0x110, "Offset mismatch for UMovieSceneCameraFramingZoneSection::LeftMarginCurve");
static_assert(offsetof(UMovieSceneCameraFramingZoneSection, TopMarginCurve) == 0x228, "Offset mismatch for UMovieSceneCameraFramingZoneSection::TopMarginCurve");
static_assert(offsetof(UMovieSceneCameraFramingZoneSection, RightMarginCurve) == 0x340, "Offset mismatch for UMovieSceneCameraFramingZoneSection::RightMarginCurve");
static_assert(offsetof(UMovieSceneCameraFramingZoneSection, BottomMarginCurve) == 0x458, "Offset mismatch for UMovieSceneCameraFramingZoneSection::BottomMarginCurve");

// Size: 0x138 (Inherited: 0x440, Single: 0xfffffcf8)
class UMovieSceneCameraFramingZoneTrack : public UMovieScenePropertyTrack
{
public:
};

static_assert(sizeof(UMovieSceneCameraFramingZoneTrack) == 0x138, "Size mismatch for UMovieSceneCameraFramingZoneTrack");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UMovieSceneCameraParameterDecoration : public UObject
{
public:
};

static_assert(sizeof(UMovieSceneCameraParameterDecoration) == 0x30, "Size mismatch for UMovieSceneCameraParameterDecoration");

// Size: 0x50 (Inherited: 0xa8, Single: 0xffffffa8)
class UMovieSceneCameraParameterInstantiator : public UMovieSceneEntityInstantiatorSystem
{
public:
};

static_assert(sizeof(UMovieSceneCameraParameterInstantiator) == 0x50, "Size mismatch for UMovieSceneCameraParameterInstantiator");

// Size: 0x78 (Inherited: 0x60, Single: 0x18)
class UAttachToActorCameraNode : public UCameraNode
{
public:
    FCameraActorAttachmentInfo Attachment; // 0x38 (Size: 0x18, Type: StructProperty)
    FCameraContextDataID AttachmentDataID; // 0x50 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
    FBooleanCameraParameter AttachToLocation; // 0x58 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter AttachToRotation; // 0x68 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UAttachToActorCameraNode) == 0x78, "Size mismatch for UAttachToActorCameraNode");
static_assert(offsetof(UAttachToActorCameraNode, Attachment) == 0x38, "Offset mismatch for UAttachToActorCameraNode::Attachment");
static_assert(offsetof(UAttachToActorCameraNode, AttachmentDataID) == 0x50, "Offset mismatch for UAttachToActorCameraNode::AttachmentDataID");
static_assert(offsetof(UAttachToActorCameraNode, AttachToLocation) == 0x58, "Offset mismatch for UAttachToActorCameraNode::AttachToLocation");
static_assert(offsetof(UAttachToActorCameraNode, AttachToRotation) == 0x68, "Offset mismatch for UAttachToActorCameraNode::AttachToRotation");

// Size: 0x50 (Inherited: 0x60, Single: 0xfffffff0)
class UAttachToActorGroupCameraNode : public UCameraNode
{
public:
    TArray<FCameraActorAttachmentInfo> Attachments; // 0x38 (Size: 0x10, Type: ArrayProperty)
    FCameraContextDataID AttachmentsDataID; // 0x48 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UAttachToActorGroupCameraNode) == 0x50, "Size mismatch for UAttachToActorGroupCameraNode");
static_assert(offsetof(UAttachToActorGroupCameraNode, Attachments) == 0x38, "Offset mismatch for UAttachToActorGroupCameraNode::Attachments");
static_assert(offsetof(UAttachToActorGroupCameraNode, AttachmentsDataID) == 0x48, "Offset mismatch for UAttachToActorGroupCameraNode::AttachmentsDataID");

// Size: 0x58 (Inherited: 0x60, Single: 0xfffffff8)
class UAttachToPlayerPawnCameraNode : public UCameraNode
{
public:
    FBooleanCameraParameter AttachToLocation; // 0x38 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter AttachToRotation; // 0x48 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UAttachToPlayerPawnCameraNode) == 0x58, "Size mismatch for UAttachToPlayerPawnCameraNode");
static_assert(offsetof(UAttachToPlayerPawnCameraNode, AttachToLocation) == 0x38, "Offset mismatch for UAttachToPlayerPawnCameraNode::AttachToLocation");
static_assert(offsetof(UAttachToPlayerPawnCameraNode, AttachToRotation) == 0x48, "Offset mismatch for UAttachToPlayerPawnCameraNode::AttachToRotation");

// Size: 0x40 (Inherited: 0x110, Single: 0xffffff30)
class ULinearBlendCameraNode : public USimpleFixedTimeBlendCameraNode
{
public:
};

static_assert(sizeof(ULinearBlendCameraNode) == 0x40, "Size mismatch for ULinearBlendCameraNode");

// Size: 0x40 (Inherited: 0xd0, Single: 0xffffff70)
class USimpleFixedTimeBlendCameraNode : public USimpleBlendCameraNode
{
public:
    float BlendTime; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(USimpleFixedTimeBlendCameraNode) == 0x40, "Size mismatch for USimpleFixedTimeBlendCameraNode");
static_assert(offsetof(USimpleFixedTimeBlendCameraNode, BlendTime) == 0x38, "Offset mismatch for USimpleFixedTimeBlendCameraNode::BlendTime");

// Size: 0x50 (Inherited: 0x98, Single: 0xffffffb8)
class ULocationRotationBlendCameraNode : public UBlendCameraNode
{
public:
    USimpleBlendCameraNode* LocationBlend; // 0x38 (Size: 0x8, Type: ObjectProperty)
    USimpleBlendCameraNode* RotationBlend; // 0x40 (Size: 0x8, Type: ObjectProperty)
    USimpleBlendCameraNode* OtherBlend; // 0x48 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(ULocationRotationBlendCameraNode) == 0x50, "Size mismatch for ULocationRotationBlendCameraNode");
static_assert(offsetof(ULocationRotationBlendCameraNode, LocationBlend) == 0x38, "Offset mismatch for ULocationRotationBlendCameraNode::LocationBlend");
static_assert(offsetof(ULocationRotationBlendCameraNode, RotationBlend) == 0x40, "Offset mismatch for ULocationRotationBlendCameraNode::RotationBlend");
static_assert(offsetof(ULocationRotationBlendCameraNode, OtherBlend) == 0x48, "Offset mismatch for ULocationRotationBlendCameraNode::OtherBlend");

// Size: 0x40 (Inherited: 0x98, Single: 0xffffffa8)
class UOrbitBlendCameraNode : public UBlendCameraNode
{
public:
    USimpleBlendCameraNode* DrivingBlend; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UOrbitBlendCameraNode) == 0x40, "Size mismatch for UOrbitBlendCameraNode");
static_assert(offsetof(UOrbitBlendCameraNode, DrivingBlend) == 0x38, "Offset mismatch for UOrbitBlendCameraNode::DrivingBlend");

// Size: 0x38 (Inherited: 0x98, Single: 0xffffffa0)
class UPopBlendCameraNode : public UBlendCameraNode
{
public:
};

static_assert(sizeof(UPopBlendCameraNode) == 0x38, "Size mismatch for UPopBlendCameraNode");

// Size: 0x48 (Inherited: 0x110, Single: 0xffffff38)
class USmoothBlendCameraNode : public USimpleFixedTimeBlendCameraNode
{
public:
    uint8_t BlendType[0x4]; // 0x40 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(USmoothBlendCameraNode) == 0x48, "Size mismatch for USmoothBlendCameraNode");
static_assert(offsetof(USmoothBlendCameraNode, BlendType) == 0x40, "Offset mismatch for USmoothBlendCameraNode::BlendType");

// Size: 0xc0 (Inherited: 0x60, Single: 0x60)
class UCollisionPushCameraNode : public UCameraNode
{
public:
    uint8_t SafePosition; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
    FVector3dCameraVariableReference CustomSafePosition; // 0x40 (Size: 0x10, Type: StructProperty)
    FVector3dCameraParameter SafePositionOffset; // 0x50 (Size: 0x28, Type: StructProperty)
    uint8_t SafePositionOffsetSpace; // 0x78 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
    FBooleanCameraVariableReference EnableCollision; // 0x80 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter CollisionSphereRadius; // 0x90 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> CollisionChannel; // 0xa0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_a1[0x7]; // 0xa1 (Size: 0x7, Type: PaddingProperty)
    UCameraValueInterpolator* PushInterpolator; // 0xa8 (Size: 0x8, Type: ObjectProperty)
    UCameraValueInterpolator* PullInterpolator; // 0xb0 (Size: 0x8, Type: ObjectProperty)
    bool bRunAsyncCollision; // 0xb8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b9[0x7]; // 0xb9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UCollisionPushCameraNode) == 0xc0, "Size mismatch for UCollisionPushCameraNode");
static_assert(offsetof(UCollisionPushCameraNode, SafePosition) == 0x38, "Offset mismatch for UCollisionPushCameraNode::SafePosition");
static_assert(offsetof(UCollisionPushCameraNode, CustomSafePosition) == 0x40, "Offset mismatch for UCollisionPushCameraNode::CustomSafePosition");
static_assert(offsetof(UCollisionPushCameraNode, SafePositionOffset) == 0x50, "Offset mismatch for UCollisionPushCameraNode::SafePositionOffset");
static_assert(offsetof(UCollisionPushCameraNode, SafePositionOffsetSpace) == 0x78, "Offset mismatch for UCollisionPushCameraNode::SafePositionOffsetSpace");
static_assert(offsetof(UCollisionPushCameraNode, EnableCollision) == 0x80, "Offset mismatch for UCollisionPushCameraNode::EnableCollision");
static_assert(offsetof(UCollisionPushCameraNode, CollisionSphereRadius) == 0x90, "Offset mismatch for UCollisionPushCameraNode::CollisionSphereRadius");
static_assert(offsetof(UCollisionPushCameraNode, CollisionChannel) == 0xa0, "Offset mismatch for UCollisionPushCameraNode::CollisionChannel");
static_assert(offsetof(UCollisionPushCameraNode, PushInterpolator) == 0xa8, "Offset mismatch for UCollisionPushCameraNode::PushInterpolator");
static_assert(offsetof(UCollisionPushCameraNode, PullInterpolator) == 0xb0, "Offset mismatch for UCollisionPushCameraNode::PullInterpolator");
static_assert(offsetof(UCollisionPushCameraNode, bRunAsyncCollision) == 0xb8, "Offset mismatch for UCollisionPushCameraNode::bRunAsyncCollision");

// Size: 0x80 (Inherited: 0x60, Single: 0x20)
class UOcclusionMaterialCameraNode : public UCameraNode
{
public:
    UMaterialInterface* OcclusionTransparencyMaterial; // 0x38 (Size: 0x8, Type: ObjectProperty)
    FFloatCameraParameter OcclusionSphereRadius; // 0x40 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> OcclusionChannel; // 0x50 (Size: 0x1, Type: ByteProperty)
    uint8_t OcclusionTargetPosition; // 0x51 (Size: 0x1, Type: EnumProperty)
    uint8_t OcclusionTargetOffsetSpace; // 0x52 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_53[0x5]; // 0x53 (Size: 0x5, Type: PaddingProperty)
    FVector3dCameraParameter OcclusionTargetOffset; // 0x58 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(UOcclusionMaterialCameraNode) == 0x80, "Size mismatch for UOcclusionMaterialCameraNode");
static_assert(offsetof(UOcclusionMaterialCameraNode, OcclusionTransparencyMaterial) == 0x38, "Offset mismatch for UOcclusionMaterialCameraNode::OcclusionTransparencyMaterial");
static_assert(offsetof(UOcclusionMaterialCameraNode, OcclusionSphereRadius) == 0x40, "Offset mismatch for UOcclusionMaterialCameraNode::OcclusionSphereRadius");
static_assert(offsetof(UOcclusionMaterialCameraNode, OcclusionChannel) == 0x50, "Offset mismatch for UOcclusionMaterialCameraNode::OcclusionChannel");
static_assert(offsetof(UOcclusionMaterialCameraNode, OcclusionTargetPosition) == 0x51, "Offset mismatch for UOcclusionMaterialCameraNode::OcclusionTargetPosition");
static_assert(offsetof(UOcclusionMaterialCameraNode, OcclusionTargetOffsetSpace) == 0x52, "Offset mismatch for UOcclusionMaterialCameraNode::OcclusionTargetOffsetSpace");
static_assert(offsetof(UOcclusionMaterialCameraNode, OcclusionTargetOffset) == 0x58, "Offset mismatch for UOcclusionMaterialCameraNode::OcclusionTargetOffset");

// Size: 0x48 (Inherited: 0x60, Single: 0xffffffe8)
class UArrayCameraNode : public UCameraNode
{
public:
    TArray<UCameraNode*> Children; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UArrayCameraNode) == 0x48, "Size mismatch for UArrayCameraNode");
static_assert(offsetof(UArrayCameraNode, Children) == 0x38, "Offset mismatch for UArrayCameraNode::Children");

// Size: 0x58 (Inherited: 0x60, Single: 0xfffffff8)
class UAutoFocusCameraNode : public UCameraNode
{
public:
    FBooleanCameraVariableReference EnableAutoFocus; // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter AutoFocusDampingFactor; // 0x48 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UAutoFocusCameraNode) == 0x58, "Size mismatch for UAutoFocusCameraNode");
static_assert(offsetof(UAutoFocusCameraNode, EnableAutoFocus) == 0x38, "Offset mismatch for UAutoFocusCameraNode::EnableAutoFocus");
static_assert(offsetof(UAutoFocusCameraNode, AutoFocusDampingFactor) == 0x48, "Offset mismatch for UAutoFocusCameraNode::AutoFocusDampingFactor");

// Size: 0xa0 (Inherited: 0x60, Single: 0x40)
class UBoomArmCameraNode : public UCameraNode
{
public:
    FVector3dCameraParameter BoomOffset; // 0x38 (Size: 0x28, Type: StructProperty)
    UCameraValueInterpolator* BoomLengthInterpolator; // 0x60 (Size: 0x8, Type: ObjectProperty)
    FDoubleCameraParameter MaxForwardInterpolationFactor; // 0x68 (Size: 0x18, Type: StructProperty)
    FDoubleCameraParameter MaxBackwardInterpolationFactor; // 0x80 (Size: 0x18, Type: StructProperty)
    UInput2DCameraNode* InputSlot; // 0x98 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UBoomArmCameraNode) == 0xa0, "Size mismatch for UBoomArmCameraNode");
static_assert(offsetof(UBoomArmCameraNode, BoomOffset) == 0x38, "Offset mismatch for UBoomArmCameraNode::BoomOffset");
static_assert(offsetof(UBoomArmCameraNode, BoomLengthInterpolator) == 0x60, "Offset mismatch for UBoomArmCameraNode::BoomLengthInterpolator");
static_assert(offsetof(UBoomArmCameraNode, MaxForwardInterpolationFactor) == 0x68, "Offset mismatch for UBoomArmCameraNode::MaxForwardInterpolationFactor");
static_assert(offsetof(UBoomArmCameraNode, MaxBackwardInterpolationFactor) == 0x80, "Offset mismatch for UBoomArmCameraNode::MaxBackwardInterpolationFactor");
static_assert(offsetof(UBoomArmCameraNode, InputSlot) == 0x98, "Offset mismatch for UBoomArmCameraNode::InputSlot");

// Size: 0x160 (Inherited: 0x60, Single: 0x100)
class UCameraRigCameraNode : public UCameraNode
{
public:
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    FCameraRigAssetReference CameraRigReference; // 0x40 (Size: 0x120, Type: StructProperty)
};

static_assert(sizeof(UCameraRigCameraNode) == 0x160, "Size mismatch for UCameraRigCameraNode");
static_assert(offsetof(UCameraRigCameraNode, CameraRigReference) == 0x40, "Offset mismatch for UCameraRigCameraNode::CameraRigReference");

// Size: 0x68 (Inherited: 0x60, Single: 0x8)
class UClippingPlanesCameraNode : public UCameraNode
{
public:
    FDoubleCameraParameter NearPlane; // 0x38 (Size: 0x18, Type: StructProperty)
    FDoubleCameraParameter FarPlane; // 0x50 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UClippingPlanesCameraNode) == 0x68, "Size mismatch for UClippingPlanesCameraNode");
static_assert(offsetof(UClippingPlanesCameraNode, NearPlane) == 0x38, "Offset mismatch for UClippingPlanesCameraNode::NearPlane");
static_assert(offsetof(UClippingPlanesCameraNode, FarPlane) == 0x50, "Offset mismatch for UClippingPlanesCameraNode::FarPlane");

// Size: 0x70 (Inherited: 0x60, Single: 0x10)
class UDampenPositionCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter ForwardDampingFactor; // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter LateralDampingFactor; // 0x48 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter VerticalDampingFactor; // 0x58 (Size: 0x10, Type: StructProperty)
    uint8_t DampenSpace; // 0x68 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_69[0x7]; // 0x69 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDampenPositionCameraNode) == 0x70, "Size mismatch for UDampenPositionCameraNode");
static_assert(offsetof(UDampenPositionCameraNode, ForwardDampingFactor) == 0x38, "Offset mismatch for UDampenPositionCameraNode::ForwardDampingFactor");
static_assert(offsetof(UDampenPositionCameraNode, LateralDampingFactor) == 0x48, "Offset mismatch for UDampenPositionCameraNode::LateralDampingFactor");
static_assert(offsetof(UDampenPositionCameraNode, VerticalDampingFactor) == 0x58, "Offset mismatch for UDampenPositionCameraNode::VerticalDampingFactor");
static_assert(offsetof(UDampenPositionCameraNode, DampenSpace) == 0x68, "Offset mismatch for UDampenPositionCameraNode::DampenSpace");

// Size: 0x68 (Inherited: 0x60, Single: 0x8)
class UDampenRotationCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter YawDampingFactor; // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter PitchDampingFactor; // 0x48 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter RollDampingFactor; // 0x58 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UDampenRotationCameraNode) == 0x68, "Size mismatch for UDampenRotationCameraNode");
static_assert(offsetof(UDampenRotationCameraNode, YawDampingFactor) == 0x38, "Offset mismatch for UDampenRotationCameraNode::YawDampingFactor");
static_assert(offsetof(UDampenRotationCameraNode, PitchDampingFactor) == 0x48, "Offset mismatch for UDampenRotationCameraNode::PitchDampingFactor");
static_assert(offsetof(UDampenRotationCameraNode, RollDampingFactor) == 0x58, "Offset mismatch for UDampenRotationCameraNode::RollDampingFactor");

// Size: 0x48 (Inherited: 0x60, Single: 0xffffffe8)
class UFieldOfViewCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter FieldOfView; // 0x38 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UFieldOfViewCameraNode) == 0x48, "Size mismatch for UFieldOfViewCameraNode");
static_assert(offsetof(UFieldOfViewCameraNode, FieldOfView) == 0x38, "Offset mismatch for UFieldOfViewCameraNode::FieldOfView");

// Size: 0x90 (Inherited: 0x60, Single: 0x30)
class UFilmbackCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter SensorWidth; // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter SensorHeight; // 0x48 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter ISO; // 0x58 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter ConstrainAspectRatio; // 0x68 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter OverrideAspectRatioAxisConstraint; // 0x78 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<EAspectRatioAxisConstraint> AspectRatioAxisConstraint; // 0x88 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_89[0x7]; // 0x89 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UFilmbackCameraNode) == 0x90, "Size mismatch for UFilmbackCameraNode");
static_assert(offsetof(UFilmbackCameraNode, SensorWidth) == 0x38, "Offset mismatch for UFilmbackCameraNode::SensorWidth");
static_assert(offsetof(UFilmbackCameraNode, SensorHeight) == 0x48, "Offset mismatch for UFilmbackCameraNode::SensorHeight");
static_assert(offsetof(UFilmbackCameraNode, ISO) == 0x58, "Offset mismatch for UFilmbackCameraNode::ISO");
static_assert(offsetof(UFilmbackCameraNode, ConstrainAspectRatio) == 0x68, "Offset mismatch for UFilmbackCameraNode::ConstrainAspectRatio");
static_assert(offsetof(UFilmbackCameraNode, OverrideAspectRatioAxisConstraint) == 0x78, "Offset mismatch for UFilmbackCameraNode::OverrideAspectRatioAxisConstraint");
static_assert(offsetof(UFilmbackCameraNode, AspectRatioAxisConstraint) == 0x88, "Offset mismatch for UFilmbackCameraNode::AspectRatioAxisConstraint");

// Size: 0x88 (Inherited: 0x60, Single: 0x28)
class ULensParametersCameraNode : public UCameraNode
{
public:
    FFloatCameraParameter FocalLength; // 0x38 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter FocusDistance; // 0x48 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter Aperture; // 0x58 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter ShutterSpeed; // 0x68 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter EnablePhysicalCamera; // 0x78 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(ULensParametersCameraNode) == 0x88, "Size mismatch for ULensParametersCameraNode");
static_assert(offsetof(ULensParametersCameraNode, FocalLength) == 0x38, "Offset mismatch for ULensParametersCameraNode::FocalLength");
static_assert(offsetof(ULensParametersCameraNode, FocusDistance) == 0x48, "Offset mismatch for ULensParametersCameraNode::FocusDistance");
static_assert(offsetof(ULensParametersCameraNode, Aperture) == 0x58, "Offset mismatch for ULensParametersCameraNode::Aperture");
static_assert(offsetof(ULensParametersCameraNode, ShutterSpeed) == 0x68, "Offset mismatch for ULensParametersCameraNode::ShutterSpeed");
static_assert(offsetof(ULensParametersCameraNode, EnablePhysicalCamera) == 0x78, "Offset mismatch for ULensParametersCameraNode::EnablePhysicalCamera");

// Size: 0x90 (Inherited: 0x60, Single: 0x30)
class UOffsetCameraNode : public UCameraNode
{
public:
    FVector3dCameraParameter TranslationOffset; // 0x38 (Size: 0x28, Type: StructProperty)
    FRotator3dCameraParameter RotationOffset; // 0x60 (Size: 0x28, Type: StructProperty)
    uint8_t OffsetSpace; // 0x88 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_89[0x7]; // 0x89 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UOffsetCameraNode) == 0x90, "Size mismatch for UOffsetCameraNode");
static_assert(offsetof(UOffsetCameraNode, TranslationOffset) == 0x38, "Offset mismatch for UOffsetCameraNode::TranslationOffset");
static_assert(offsetof(UOffsetCameraNode, RotationOffset) == 0x60, "Offset mismatch for UOffsetCameraNode::RotationOffset");
static_assert(offsetof(UOffsetCameraNode, OffsetSpace) == 0x88, "Offset mismatch for UOffsetCameraNode::OffsetSpace");

// Size: 0x7a0 (Inherited: 0x60, Single: 0x740)
class UPostProcessCameraNode : public UCameraNode
{
public:
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    FPostProcessSettings PostProcessSettings; // 0x40 (Size: 0x760, Type: StructProperty)
};

static_assert(sizeof(UPostProcessCameraNode) == 0x7a0, "Size mismatch for UPostProcessCameraNode");
static_assert(offsetof(UPostProcessCameraNode, PostProcessSettings) == 0x40, "Offset mismatch for UPostProcessCameraNode::PostProcessSettings");

// Size: 0x4c8 (Inherited: 0x60, Single: 0x468)
class USplineOrbitCameraNode : public UCameraNode
{
public:
    FCameraVectorCurve LocationOffsetSpline; // 0x38 (Size: 0x180, Type: StructProperty)
    FCameraVectorCurve TargetOffsetSpline; // 0x1b8 (Size: 0x180, Type: StructProperty)
    FCameraRotatorCurve RotationOffsetSpline; // 0x338 (Size: 0x180, Type: StructProperty)
    uint8_t TargetOffsetSpace; // 0x4b8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_4b9[0x7]; // 0x4b9 (Size: 0x7, Type: PaddingProperty)
    UInput2DCameraNode* InputSlot; // 0x4c0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(USplineOrbitCameraNode) == 0x4c8, "Size mismatch for USplineOrbitCameraNode");
static_assert(offsetof(USplineOrbitCameraNode, LocationOffsetSpline) == 0x38, "Offset mismatch for USplineOrbitCameraNode::LocationOffsetSpline");
static_assert(offsetof(USplineOrbitCameraNode, TargetOffsetSpline) == 0x1b8, "Offset mismatch for USplineOrbitCameraNode::TargetOffsetSpline");
static_assert(offsetof(USplineOrbitCameraNode, RotationOffsetSpline) == 0x338, "Offset mismatch for USplineOrbitCameraNode::RotationOffsetSpline");
static_assert(offsetof(USplineOrbitCameraNode, TargetOffsetSpace) == 0x4b8, "Offset mismatch for USplineOrbitCameraNode::TargetOffsetSpace");
static_assert(offsetof(USplineOrbitCameraNode, InputSlot) == 0x4c0, "Offset mismatch for USplineOrbitCameraNode::InputSlot");

// Size: 0x50 (Inherited: 0x60, Single: 0xfffffff0)
class UTargetRayCastCameraNode : public UCameraNode
{
public:
    TEnumAsByte<ECollisionChannel> TraceChannel; // 0x38 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
    FBooleanCameraParameter AutoFocus; // 0x40 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UTargetRayCastCameraNode) == 0x50, "Size mismatch for UTargetRayCastCameraNode");
static_assert(offsetof(UTargetRayCastCameraNode, TraceChannel) == 0x38, "Offset mismatch for UTargetRayCastCameraNode::TraceChannel");
static_assert(offsetof(UTargetRayCastCameraNode, AutoFocus) == 0x40, "Offset mismatch for UTargetRayCastCameraNode::AutoFocus");

// Size: 0x158 (Inherited: 0x60, Single: 0xf8)
class UBaseFramingCameraNode : public UCameraNode
{
public:
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    FVector3dCameraVariableReference TargetLocation; // 0x40 (Size: 0x10, Type: StructProperty)
    TArray<FCameraActorTargetInfo> TargetInfos; // 0x50 (Size: 0x10, Type: ArrayProperty)
    FCameraContextDataID TargetInfosDataID; // 0x60 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_64[0x4]; // 0x64 (Size: 0x4, Type: PaddingProperty)
    FBooleanCameraParameter SetTargetDistance; // 0x68 (Size: 0x10, Type: StructProperty)
    FVector2dCameraParameter IdealFramingLocation; // 0x78 (Size: 0x20, Type: StructProperty)
    FFloatCameraParameter ReframeDampingFactor; // 0x98 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter LowReframeDampingFactor; // 0xa8 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter ReengageTime; // 0xb8 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter DisengageTime; // 0xc8 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter TargetMovementAnticipationTime; // 0xd8 (Size: 0x10, Type: StructProperty)
    FCameraFramingZoneParameter DeadZone; // 0xe8 (Size: 0x28, Type: StructProperty)
    FCameraFramingZoneParameter SoftZone; // 0x110 (Size: 0x28, Type: StructProperty)
    FCameraActorTargetInfo TargetInfo; // 0x138 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UBaseFramingCameraNode) == 0x158, "Size mismatch for UBaseFramingCameraNode");
static_assert(offsetof(UBaseFramingCameraNode, TargetLocation) == 0x40, "Offset mismatch for UBaseFramingCameraNode::TargetLocation");
static_assert(offsetof(UBaseFramingCameraNode, TargetInfos) == 0x50, "Offset mismatch for UBaseFramingCameraNode::TargetInfos");
static_assert(offsetof(UBaseFramingCameraNode, TargetInfosDataID) == 0x60, "Offset mismatch for UBaseFramingCameraNode::TargetInfosDataID");
static_assert(offsetof(UBaseFramingCameraNode, SetTargetDistance) == 0x68, "Offset mismatch for UBaseFramingCameraNode::SetTargetDistance");
static_assert(offsetof(UBaseFramingCameraNode, IdealFramingLocation) == 0x78, "Offset mismatch for UBaseFramingCameraNode::IdealFramingLocation");
static_assert(offsetof(UBaseFramingCameraNode, ReframeDampingFactor) == 0x98, "Offset mismatch for UBaseFramingCameraNode::ReframeDampingFactor");
static_assert(offsetof(UBaseFramingCameraNode, LowReframeDampingFactor) == 0xa8, "Offset mismatch for UBaseFramingCameraNode::LowReframeDampingFactor");
static_assert(offsetof(UBaseFramingCameraNode, ReengageTime) == 0xb8, "Offset mismatch for UBaseFramingCameraNode::ReengageTime");
static_assert(offsetof(UBaseFramingCameraNode, DisengageTime) == 0xc8, "Offset mismatch for UBaseFramingCameraNode::DisengageTime");
static_assert(offsetof(UBaseFramingCameraNode, TargetMovementAnticipationTime) == 0xd8, "Offset mismatch for UBaseFramingCameraNode::TargetMovementAnticipationTime");
static_assert(offsetof(UBaseFramingCameraNode, DeadZone) == 0xe8, "Offset mismatch for UBaseFramingCameraNode::DeadZone");
static_assert(offsetof(UBaseFramingCameraNode, SoftZone) == 0x110, "Offset mismatch for UBaseFramingCameraNode::SoftZone");
static_assert(offsetof(UBaseFramingCameraNode, TargetInfo) == 0x138, "Offset mismatch for UBaseFramingCameraNode::TargetInfo");

// Size: 0x178 (Inherited: 0x1b8, Single: 0xffffffc0)
class UDollyFramingCameraNode : public UBaseFramingCameraNode
{
public:
    FBooleanCameraParameter CanMoveLaterally; // 0x158 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter CanMoveVertically; // 0x168 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UDollyFramingCameraNode) == 0x178, "Size mismatch for UDollyFramingCameraNode");
static_assert(offsetof(UDollyFramingCameraNode, CanMoveLaterally) == 0x158, "Offset mismatch for UDollyFramingCameraNode::CanMoveLaterally");
static_assert(offsetof(UDollyFramingCameraNode, CanMoveVertically) == 0x168, "Offset mismatch for UDollyFramingCameraNode::CanMoveVertically");

// Size: 0x178 (Inherited: 0x1b8, Single: 0xffffffc0)
class UPanningFramingCameraNode : public UBaseFramingCameraNode
{
public:
    FBooleanCameraParameter CanPanLaterally; // 0x158 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter CanPanVertically; // 0x168 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UPanningFramingCameraNode) == 0x178, "Size mismatch for UPanningFramingCameraNode");
static_assert(offsetof(UPanningFramingCameraNode, CanPanLaterally) == 0x158, "Offset mismatch for UPanningFramingCameraNode::CanPanLaterally");
static_assert(offsetof(UPanningFramingCameraNode, CanPanVertically) == 0x168, "Offset mismatch for UPanningFramingCameraNode::CanPanVertically");

// Size: 0xb0 (Inherited: 0x98, Single: 0x18)
class UAutoRotateInput2DCameraNode : public UInput2DCameraNode
{
public:
    uint8_t Direction[0x4]; // 0x38 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    FFloatCameraParameter WaitTime; // 0x40 (Size: 0x10, Type: StructProperty)
    FFloatCameraParameter DeactivationThreshold; // 0x50 (Size: 0x10, Type: StructProperty)
    UCameraValueInterpolator* Interpolator; // 0x60 (Size: 0x8, Type: ObjectProperty)
    FBooleanCameraParameter FreezeControlRotation; // 0x68 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter EnableAutoRotate; // 0x78 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter AutoRotateYaw; // 0x88 (Size: 0x10, Type: StructProperty)
    FBooleanCameraParameter AutoRotatePitch; // 0x98 (Size: 0x10, Type: StructProperty)
    UInput2DCameraNode* InputNode; // 0xa8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UAutoRotateInput2DCameraNode) == 0xb0, "Size mismatch for UAutoRotateInput2DCameraNode");
static_assert(offsetof(UAutoRotateInput2DCameraNode, Direction) == 0x38, "Offset mismatch for UAutoRotateInput2DCameraNode::Direction");
static_assert(offsetof(UAutoRotateInput2DCameraNode, WaitTime) == 0x40, "Offset mismatch for UAutoRotateInput2DCameraNode::WaitTime");
static_assert(offsetof(UAutoRotateInput2DCameraNode, DeactivationThreshold) == 0x50, "Offset mismatch for UAutoRotateInput2DCameraNode::DeactivationThreshold");
static_assert(offsetof(UAutoRotateInput2DCameraNode, Interpolator) == 0x60, "Offset mismatch for UAutoRotateInput2DCameraNode::Interpolator");
static_assert(offsetof(UAutoRotateInput2DCameraNode, FreezeControlRotation) == 0x68, "Offset mismatch for UAutoRotateInput2DCameraNode::FreezeControlRotation");
static_assert(offsetof(UAutoRotateInput2DCameraNode, EnableAutoRotate) == 0x78, "Offset mismatch for UAutoRotateInput2DCameraNode::EnableAutoRotate");
static_assert(offsetof(UAutoRotateInput2DCameraNode, AutoRotateYaw) == 0x88, "Offset mismatch for UAutoRotateInput2DCameraNode::AutoRotateYaw");
static_assert(offsetof(UAutoRotateInput2DCameraNode, AutoRotatePitch) == 0x98, "Offset mismatch for UAutoRotateInput2DCameraNode::AutoRotatePitch");
static_assert(offsetof(UAutoRotateInput2DCameraNode, InputNode) == 0xa8, "Offset mismatch for UAutoRotateInput2DCameraNode::InputNode");

// Size: 0x78 (Inherited: 0x60, Single: 0x18)
class UCameraShakeCameraNode : public UCameraNode
{
public:
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    FCameraShakeAssetReference CameraShakeReference; // 0x40 (Size: 0x30, Type: StructProperty)
    uint8_t EvaluationMode; // 0x70 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UCameraShakeCameraNode) == 0x78, "Size mismatch for UCameraShakeCameraNode");
static_assert(offsetof(UCameraShakeCameraNode, CameraShakeReference) == 0x40, "Offset mismatch for UCameraShakeCameraNode::CameraShakeReference");
static_assert(offsetof(UCameraShakeCameraNode, EvaluationMode) == 0x70, "Offset mismatch for UCameraShakeCameraNode::EvaluationMode");

// Size: 0xd0 (Inherited: 0x28, Single: 0xa8)
class UBlueprintCameraNodeEvaluator : public UObject
{
public:
    bool bIsFirstFrame; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    UObject* EvaluationContextOwner; // 0x30 (Size: 0x8, Type: ObjectProperty)
    FBlueprintCameraPose CameraPose; // 0x38 (Size: 0x70, Type: StructProperty)
    FBlueprintCameraVariableTable VariableTable; // 0xa8 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_b0[0x20]; // 0xb0 (Size: 0x20, Type: PaddingProperty)

public:
    AActor* FindEvaluationContextOwnerActor(UClass*& ActorClass) const; // 0xb770294 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void InitializeCameraNode(); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void TickCameraNode(float& DeltaTime); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UBlueprintCameraNodeEvaluator) == 0xd0, "Size mismatch for UBlueprintCameraNodeEvaluator");
static_assert(offsetof(UBlueprintCameraNodeEvaluator, bIsFirstFrame) == 0x28, "Offset mismatch for UBlueprintCameraNodeEvaluator::bIsFirstFrame");
static_assert(offsetof(UBlueprintCameraNodeEvaluator, EvaluationContextOwner) == 0x30, "Offset mismatch for UBlueprintCameraNodeEvaluator::EvaluationContextOwner");
static_assert(offsetof(UBlueprintCameraNodeEvaluator, CameraPose) == 0x38, "Offset mismatch for UBlueprintCameraNodeEvaluator::CameraPose");
static_assert(offsetof(UBlueprintCameraNodeEvaluator, VariableTable) == 0xa8, "Offset mismatch for UBlueprintCameraNodeEvaluator::VariableTable");

// Size: 0x70 (Inherited: 0x60, Single: 0x10)
class UBlueprintCameraNode : public UCameraNode
{
public:
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    UBlueprintCameraNodeEvaluator* CameraNodeEvaluatorTemplate; // 0x40 (Size: 0x8, Type: ObjectProperty)
    FCustomCameraNodeParameters CameraNodeEvaluatorOverrides; // 0x48 (Size: 0x20, Type: StructProperty)
    UClass* CameraNodeEvaluatorClass; // 0x68 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UBlueprintCameraNode) == 0x70, "Size mismatch for UBlueprintCameraNode");
static_assert(offsetof(UBlueprintCameraNode, CameraNodeEvaluatorTemplate) == 0x40, "Offset mismatch for UBlueprintCameraNode::CameraNodeEvaluatorTemplate");
static_assert(offsetof(UBlueprintCameraNode, CameraNodeEvaluatorOverrides) == 0x48, "Offset mismatch for UBlueprintCameraNode::CameraNodeEvaluatorOverrides");
static_assert(offsetof(UBlueprintCameraNode, CameraNodeEvaluatorClass) == 0x68, "Offset mismatch for UBlueprintCameraNode::CameraNodeEvaluatorClass");

// Size: 0x38 (Inherited: 0x60, Single: 0xffffffd8)
class UCameraShakeServiceCameraNode : public UCameraNode
{
public:
};

static_assert(sizeof(UCameraShakeServiceCameraNode) == 0x38, "Size mismatch for UCameraShakeServiceCameraNode");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UIsCameraRigTransitionCondition : public UCameraRigTransitionCondition
{
public:
    UCameraRigAsset* PreviousCameraRig; // 0x30 (Size: 0x8, Type: ObjectProperty)
    UCameraRigAsset* NextCameraRig; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UIsCameraRigTransitionCondition) == 0x40, "Size mismatch for UIsCameraRigTransitionCondition");
static_assert(offsetof(UIsCameraRigTransitionCondition, PreviousCameraRig) == 0x30, "Offset mismatch for UIsCameraRigTransitionCondition::PreviousCameraRig");
static_assert(offsetof(UIsCameraRigTransitionCondition, NextCameraRig) == 0x38, "Offset mismatch for UIsCameraRigTransitionCondition::NextCameraRig");

// Size: 0xc0 (Inherited: 0x58, Single: 0x68)
class UGameplayTagTransitionCondition : public UCameraRigTransitionCondition
{
public:
    FGameplayTagQuery PreviousGameplayTagQuery; // 0x30 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery NextGameplayTagQuery; // 0x78 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(UGameplayTagTransitionCondition) == 0xc0, "Size mismatch for UGameplayTagTransitionCondition");
static_assert(offsetof(UGameplayTagTransitionCondition, PreviousGameplayTagQuery) == 0x30, "Offset mismatch for UGameplayTagTransitionCondition::PreviousGameplayTagQuery");
static_assert(offsetof(UGameplayTagTransitionCondition, NextGameplayTagQuery) == 0x78, "Offset mismatch for UGameplayTagTransitionCondition::NextGameplayTagQuery");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UAccelerationDecelerationValueInterpolator : public UCameraValueInterpolator
{
public:
    float Acceleration; // 0x28 (Size: 0x4, Type: FloatProperty)
    float MaxSpeed; // 0x2c (Size: 0x4, Type: FloatProperty)
    float Deceleration; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UAccelerationDecelerationValueInterpolator) == 0x38, "Size mismatch for UAccelerationDecelerationValueInterpolator");
static_assert(offsetof(UAccelerationDecelerationValueInterpolator, Acceleration) == 0x28, "Offset mismatch for UAccelerationDecelerationValueInterpolator::Acceleration");
static_assert(offsetof(UAccelerationDecelerationValueInterpolator, MaxSpeed) == 0x2c, "Offset mismatch for UAccelerationDecelerationValueInterpolator::MaxSpeed");
static_assert(offsetof(UAccelerationDecelerationValueInterpolator, Deceleration) == 0x30, "Offset mismatch for UAccelerationDecelerationValueInterpolator::Deceleration");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UCriticalDamperValueInterpolator : public UCameraValueInterpolator
{
public:
    float DampingFactor; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UCriticalDamperValueInterpolator) == 0x30, "Size mismatch for UCriticalDamperValueInterpolator");
static_assert(offsetof(UCriticalDamperValueInterpolator, DampingFactor) == 0x28, "Offset mismatch for UCriticalDamperValueInterpolator::DampingFactor");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UDoubleIIRValueInterpolator : public UCameraValueInterpolator
{
public:
    float PrimarySpeed; // 0x28 (Size: 0x4, Type: FloatProperty)
    float IntermediateSpeed; // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bUseFixedStep; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDoubleIIRValueInterpolator) == 0x38, "Size mismatch for UDoubleIIRValueInterpolator");
static_assert(offsetof(UDoubleIIRValueInterpolator, PrimarySpeed) == 0x28, "Offset mismatch for UDoubleIIRValueInterpolator::PrimarySpeed");
static_assert(offsetof(UDoubleIIRValueInterpolator, IntermediateSpeed) == 0x2c, "Offset mismatch for UDoubleIIRValueInterpolator::IntermediateSpeed");
static_assert(offsetof(UDoubleIIRValueInterpolator, bUseFixedStep) == 0x30, "Offset mismatch for UDoubleIIRValueInterpolator::bUseFixedStep");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UIIRValueInterpolator : public UCameraValueInterpolator
{
public:
    float Speed; // 0x28 (Size: 0x4, Type: FloatProperty)
    bool bUseFixedStep; // 0x2c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UIIRValueInterpolator) == 0x30, "Size mismatch for UIIRValueInterpolator");
static_assert(offsetof(UIIRValueInterpolator, Speed) == 0x28, "Offset mismatch for UIIRValueInterpolator::Speed");
static_assert(offsetof(UIIRValueInterpolator, bUseFixedStep) == 0x2c, "Offset mismatch for UIIRValueInterpolator::bUseFixedStep");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FBlueprintCameraNodeEvaluationResult
{
};

static_assert(sizeof(FBlueprintCameraNodeEvaluationResult) == 0x8, "Size mismatch for FBlueprintCameraNodeEvaluationResult");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCameraActorAttachmentInfo
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName SocketName; // 0x8 (Size: 0x4, Type: NameProperty)
    FName BoneName; // 0xc (Size: 0x4, Type: NameProperty)
    float Weight; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCameraActorAttachmentInfo) == 0x18, "Size mismatch for FCameraActorAttachmentInfo");
static_assert(offsetof(FCameraActorAttachmentInfo, Actor) == 0x0, "Offset mismatch for FCameraActorAttachmentInfo::Actor");
static_assert(offsetof(FCameraActorAttachmentInfo, SocketName) == 0x8, "Offset mismatch for FCameraActorAttachmentInfo::SocketName");
static_assert(offsetof(FCameraActorAttachmentInfo, BoneName) == 0xc, "Offset mismatch for FCameraActorAttachmentInfo::BoneName");
static_assert(offsetof(FCameraActorAttachmentInfo, Weight) == 0x10, "Offset mismatch for FCameraActorAttachmentInfo::Weight");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCameraActorTargetInfo
{
    AActor* Actor; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName SocketName; // 0x8 (Size: 0x4, Type: NameProperty)
    FName BoneName; // 0xc (Size: 0x4, Type: NameProperty)
    uint8_t TargetShape; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
    float TargetSize; // 0x14 (Size: 0x4, Type: FloatProperty)
    float Weight; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCameraActorTargetInfo) == 0x20, "Size mismatch for FCameraActorTargetInfo");
static_assert(offsetof(FCameraActorTargetInfo, Actor) == 0x0, "Offset mismatch for FCameraActorTargetInfo::Actor");
static_assert(offsetof(FCameraActorTargetInfo, SocketName) == 0x8, "Offset mismatch for FCameraActorTargetInfo::SocketName");
static_assert(offsetof(FCameraActorTargetInfo, BoneName) == 0xc, "Offset mismatch for FCameraActorTargetInfo::BoneName");
static_assert(offsetof(FCameraActorTargetInfo, TargetShape) == 0x10, "Offset mismatch for FCameraActorTargetInfo::TargetShape");
static_assert(offsetof(FCameraActorTargetInfo, TargetSize) == 0x14, "Offset mismatch for FCameraActorTargetInfo::TargetSize");
static_assert(offsetof(FCameraActorTargetInfo, Weight) == 0x18, "Offset mismatch for FCameraActorTargetInfo::Weight");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCameraContextDataDefinition
{
    FCameraContextDataID DataID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t DataType[0x4]; // 0x4 (Size: 0x4, Type: EnumProperty)
    uint8_t DataContainerType[0x4]; // 0x8 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    UObject* DataTypeObject; // 0x10 (Size: 0x8, Type: ObjectProperty)
    bool bAutoReset; // 0x18 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FCameraContextDataDefinition) == 0x20, "Size mismatch for FCameraContextDataDefinition");
static_assert(offsetof(FCameraContextDataDefinition, DataID) == 0x0, "Offset mismatch for FCameraContextDataDefinition::DataID");
static_assert(offsetof(FCameraContextDataDefinition, DataType) == 0x4, "Offset mismatch for FCameraContextDataDefinition::DataType");
static_assert(offsetof(FCameraContextDataDefinition, DataContainerType) == 0x8, "Offset mismatch for FCameraContextDataDefinition::DataContainerType");
static_assert(offsetof(FCameraContextDataDefinition, DataTypeObject) == 0x10, "Offset mismatch for FCameraContextDataDefinition::DataTypeObject");
static_assert(offsetof(FCameraContextDataDefinition, bAutoReset) == 0x18, "Offset mismatch for FCameraContextDataDefinition::bAutoReset");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCameraContextDataID
{
    uint32_t Value; // 0x0 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FCameraContextDataID) == 0x4, "Size mismatch for FCameraContextDataID");
static_assert(offsetof(FCameraContextDataID, Value) == 0x0, "Offset mismatch for FCameraContextDataID::Value");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCameraContextDataTableAllocationInfo
{
    TArray<FCameraContextDataDefinition> DataDefinitions; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCameraContextDataTableAllocationInfo) == 0x10, "Size mismatch for FCameraContextDataTableAllocationInfo");
static_assert(offsetof(FCameraContextDataTableAllocationInfo, DataDefinitions) == 0x0, "Offset mismatch for FCameraContextDataTableAllocationInfo::DataDefinitions");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCameraFramingZone
{
    double Left; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double Top; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double Right; // 0x10 (Size: 0x8, Type: DoubleProperty)
    double Bottom; // 0x18 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FCameraFramingZone) == 0x20, "Size mismatch for FCameraFramingZone");
static_assert(offsetof(FCameraFramingZone, Left) == 0x0, "Offset mismatch for FCameraFramingZone::Left");
static_assert(offsetof(FCameraFramingZone, Top) == 0x8, "Offset mismatch for FCameraFramingZone::Top");
static_assert(offsetof(FCameraFramingZone, Right) == 0x10, "Offset mismatch for FCameraFramingZone::Right");
static_assert(offsetof(FCameraFramingZone, Bottom) == 0x18, "Offset mismatch for FCameraFramingZone::Bottom");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCameraFramingZoneParameter
{
    FCameraFramingZone Value; // 0x0 (Size: 0x20, Type: StructProperty)
    FCameraVariableID VariableID; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCameraFramingZoneParameter) == 0x28, "Size mismatch for FCameraFramingZoneParameter");
static_assert(offsetof(FCameraFramingZoneParameter, Value) == 0x0, "Offset mismatch for FCameraFramingZoneParameter::Value");
static_assert(offsetof(FCameraFramingZoneParameter, VariableID) == 0x20, "Offset mismatch for FCameraFramingZoneParameter::VariableID");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCameraVariableID
{
    uint32_t Value; // 0x0 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FCameraVariableID) == 0x4, "Size mismatch for FCameraVariableID");
static_assert(offsetof(FCameraVariableID, Value) == 0x0, "Offset mismatch for FCameraVariableID::Value");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FCameraNodeEvaluatorAllocationInfo
{
    int16_t TotalSizeof; // 0x0 (Size: 0x2, Type: Int16Property)
    int16_t MaxAlignof; // 0x2 (Size: 0x2, Type: Int16Property)
};

static_assert(sizeof(FCameraNodeEvaluatorAllocationInfo) == 0x4, "Size mismatch for FCameraNodeEvaluatorAllocationInfo");
static_assert(offsetof(FCameraNodeEvaluatorAllocationInfo, TotalSizeof) == 0x0, "Offset mismatch for FCameraNodeEvaluatorAllocationInfo::TotalSizeof");
static_assert(offsetof(FCameraNodeEvaluatorAllocationInfo, MaxAlignof) == 0x2, "Offset mismatch for FCameraNodeEvaluatorAllocationInfo::MaxAlignof");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FCameraObjectInterfaceParameterDefinition
{
    FName ParameterName; // 0x0 (Size: 0x4, Type: NameProperty)
    FGuid ParameterGuid; // 0x4 (Size: 0x10, Type: StructProperty)
    uint8_t ParameterType; // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    FCameraVariableID VariableID; // 0x18 (Size: 0x4, Type: StructProperty)
    uint8_t VariableType[0x4]; // 0x1c (Size: 0x4, Type: EnumProperty)
    UScriptStruct* BlendableStructType; // 0x20 (Size: 0x8, Type: ObjectProperty)
    FCameraContextDataID DataID; // 0x28 (Size: 0x4, Type: StructProperty)
    uint8_t DataType[0x4]; // 0x2c (Size: 0x4, Type: EnumProperty)
    uint8_t DataContainerType[0x4]; // 0x30 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    UObject* DataTypeObject; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCameraObjectInterfaceParameterDefinition) == 0x40, "Size mismatch for FCameraObjectInterfaceParameterDefinition");
static_assert(offsetof(FCameraObjectInterfaceParameterDefinition, ParameterName) == 0x0, "Offset mismatch for FCameraObjectInterfaceParameterDefinition::ParameterName");
static_assert(offsetof(FCameraObjectInterfaceParameterDefinition, ParameterGuid) == 0x4, "Offset mismatch for FCameraObjectInterfaceParameterDefinition::ParameterGuid");
static_assert(offsetof(FCameraObjectInterfaceParameterDefinition, ParameterType) == 0x14, "Offset mismatch for FCameraObjectInterfaceParameterDefinition::ParameterType");
static_assert(offsetof(FCameraObjectInterfaceParameterDefinition, VariableID) == 0x18, "Offset mismatch for FCameraObjectInterfaceParameterDefinition::VariableID");
static_assert(offsetof(FCameraObjectInterfaceParameterDefinition, VariableType) == 0x1c, "Offset mismatch for FCameraObjectInterfaceParameterDefinition::VariableType");
static_assert(offsetof(FCameraObjectInterfaceParameterDefinition, BlendableStructType) == 0x20, "Offset mismatch for FCameraObjectInterfaceParameterDefinition::BlendableStructType");
static_assert(offsetof(FCameraObjectInterfaceParameterDefinition, DataID) == 0x28, "Offset mismatch for FCameraObjectInterfaceParameterDefinition::DataID");
static_assert(offsetof(FCameraObjectInterfaceParameterDefinition, DataType) == 0x2c, "Offset mismatch for FCameraObjectInterfaceParameterDefinition::DataType");
static_assert(offsetof(FCameraObjectInterfaceParameterDefinition, DataContainerType) == 0x30, "Offset mismatch for FCameraObjectInterfaceParameterDefinition::DataContainerType");
static_assert(offsetof(FCameraObjectInterfaceParameterDefinition, DataTypeObject) == 0x38, "Offset mismatch for FCameraObjectInterfaceParameterDefinition::DataTypeObject");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBooleanCameraParameter
{
    bool Value; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FCameraVariableID VariableID; // 0x4 (Size: 0x4, Type: StructProperty)
    UBooleanCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FBooleanCameraParameter) == 0x10, "Size mismatch for FBooleanCameraParameter");
static_assert(offsetof(FBooleanCameraParameter, Value) == 0x0, "Offset mismatch for FBooleanCameraParameter::Value");
static_assert(offsetof(FBooleanCameraParameter, VariableID) == 0x4, "Offset mismatch for FBooleanCameraParameter::VariableID");
static_assert(offsetof(FBooleanCameraParameter, Variable) == 0x8, "Offset mismatch for FBooleanCameraParameter::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInteger32CameraParameter
{
    int32_t Value; // 0x0 (Size: 0x4, Type: IntProperty)
    FCameraVariableID VariableID; // 0x4 (Size: 0x4, Type: StructProperty)
    UInteger32CameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FInteger32CameraParameter) == 0x10, "Size mismatch for FInteger32CameraParameter");
static_assert(offsetof(FInteger32CameraParameter, Value) == 0x0, "Offset mismatch for FInteger32CameraParameter::Value");
static_assert(offsetof(FInteger32CameraParameter, VariableID) == 0x4, "Offset mismatch for FInteger32CameraParameter::VariableID");
static_assert(offsetof(FInteger32CameraParameter, Variable) == 0x8, "Offset mismatch for FInteger32CameraParameter::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFloatCameraParameter
{
    float Value; // 0x0 (Size: 0x4, Type: FloatProperty)
    FCameraVariableID VariableID; // 0x4 (Size: 0x4, Type: StructProperty)
    UFloatCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFloatCameraParameter) == 0x10, "Size mismatch for FFloatCameraParameter");
static_assert(offsetof(FFloatCameraParameter, Value) == 0x0, "Offset mismatch for FFloatCameraParameter::Value");
static_assert(offsetof(FFloatCameraParameter, VariableID) == 0x4, "Offset mismatch for FFloatCameraParameter::VariableID");
static_assert(offsetof(FFloatCameraParameter, Variable) == 0x8, "Offset mismatch for FFloatCameraParameter::Variable");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDoubleCameraParameter
{
    double Value; // 0x0 (Size: 0x8, Type: DoubleProperty)
    FCameraVariableID VariableID; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    UDoubleCameraVariable* Variable; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDoubleCameraParameter) == 0x18, "Size mismatch for FDoubleCameraParameter");
static_assert(offsetof(FDoubleCameraParameter, Value) == 0x0, "Offset mismatch for FDoubleCameraParameter::Value");
static_assert(offsetof(FDoubleCameraParameter, VariableID) == 0x8, "Offset mismatch for FDoubleCameraParameter::VariableID");
static_assert(offsetof(FDoubleCameraParameter, Variable) == 0x10, "Offset mismatch for FDoubleCameraParameter::Variable");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FVector2fCameraParameter
{
    FVector2f Value; // 0x0 (Size: 0x8, Type: StructProperty)
    FCameraVariableID VariableID; // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    UVector2fCameraVariable* Variable; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVector2fCameraParameter) == 0x18, "Size mismatch for FVector2fCameraParameter");
static_assert(offsetof(FVector2fCameraParameter, Value) == 0x0, "Offset mismatch for FVector2fCameraParameter::Value");
static_assert(offsetof(FVector2fCameraParameter, VariableID) == 0x8, "Offset mismatch for FVector2fCameraParameter::VariableID");
static_assert(offsetof(FVector2fCameraParameter, Variable) == 0x10, "Offset mismatch for FVector2fCameraParameter::Variable");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FVector2dCameraParameter
{
    FVector2D Value; // 0x0 (Size: 0x10, Type: StructProperty)
    FCameraVariableID VariableID; // 0x10 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    UVector2dCameraVariable* Variable; // 0x18 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVector2dCameraParameter) == 0x20, "Size mismatch for FVector2dCameraParameter");
static_assert(offsetof(FVector2dCameraParameter, Value) == 0x0, "Offset mismatch for FVector2dCameraParameter::Value");
static_assert(offsetof(FVector2dCameraParameter, VariableID) == 0x10, "Offset mismatch for FVector2dCameraParameter::VariableID");
static_assert(offsetof(FVector2dCameraParameter, Variable) == 0x18, "Offset mismatch for FVector2dCameraParameter::Variable");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FVector3fCameraParameter
{
    FVector3f Value; // 0x0 (Size: 0xc, Type: StructProperty)
    FCameraVariableID VariableID; // 0xc (Size: 0x4, Type: StructProperty)
    UVector3fCameraVariable* Variable; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVector3fCameraParameter) == 0x18, "Size mismatch for FVector3fCameraParameter");
static_assert(offsetof(FVector3fCameraParameter, Value) == 0x0, "Offset mismatch for FVector3fCameraParameter::Value");
static_assert(offsetof(FVector3fCameraParameter, VariableID) == 0xc, "Offset mismatch for FVector3fCameraParameter::VariableID");
static_assert(offsetof(FVector3fCameraParameter, Variable) == 0x10, "Offset mismatch for FVector3fCameraParameter::Variable");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FVector3dCameraParameter
{
    FVector Value; // 0x0 (Size: 0x18, Type: StructProperty)
    FCameraVariableID VariableID; // 0x18 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    UVector3dCameraVariable* Variable; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVector3dCameraParameter) == 0x28, "Size mismatch for FVector3dCameraParameter");
static_assert(offsetof(FVector3dCameraParameter, Value) == 0x0, "Offset mismatch for FVector3dCameraParameter::Value");
static_assert(offsetof(FVector3dCameraParameter, VariableID) == 0x18, "Offset mismatch for FVector3dCameraParameter::VariableID");
static_assert(offsetof(FVector3dCameraParameter, Variable) == 0x20, "Offset mismatch for FVector3dCameraParameter::Variable");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FVector4fCameraParameter
{
    FVector4f Value; // 0x0 (Size: 0x10, Type: StructProperty)
    FCameraVariableID VariableID; // 0x10 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    UVector4fCameraVariable* Variable; // 0x18 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVector4fCameraParameter) == 0x20, "Size mismatch for FVector4fCameraParameter");
static_assert(offsetof(FVector4fCameraParameter, Value) == 0x0, "Offset mismatch for FVector4fCameraParameter::Value");
static_assert(offsetof(FVector4fCameraParameter, VariableID) == 0x10, "Offset mismatch for FVector4fCameraParameter::VariableID");
static_assert(offsetof(FVector4fCameraParameter, Variable) == 0x18, "Offset mismatch for FVector4fCameraParameter::Variable");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FVector4dCameraParameter
{
    FVector4 Value; // 0x0 (Size: 0x20, Type: StructProperty)
    FCameraVariableID VariableID; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    UVector4dCameraVariable* Variable; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVector4dCameraParameter) == 0x30, "Size mismatch for FVector4dCameraParameter");
static_assert(offsetof(FVector4dCameraParameter, Value) == 0x0, "Offset mismatch for FVector4dCameraParameter::Value");
static_assert(offsetof(FVector4dCameraParameter, VariableID) == 0x20, "Offset mismatch for FVector4dCameraParameter::VariableID");
static_assert(offsetof(FVector4dCameraParameter, Variable) == 0x28, "Offset mismatch for FVector4dCameraParameter::Variable");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FRotator3fCameraParameter
{
    FRotator3f Value; // 0x0 (Size: 0xc, Type: StructProperty)
    FCameraVariableID VariableID; // 0xc (Size: 0x4, Type: StructProperty)
    URotator3fCameraVariable* Variable; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FRotator3fCameraParameter) == 0x18, "Size mismatch for FRotator3fCameraParameter");
static_assert(offsetof(FRotator3fCameraParameter, Value) == 0x0, "Offset mismatch for FRotator3fCameraParameter::Value");
static_assert(offsetof(FRotator3fCameraParameter, VariableID) == 0xc, "Offset mismatch for FRotator3fCameraParameter::VariableID");
static_assert(offsetof(FRotator3fCameraParameter, Variable) == 0x10, "Offset mismatch for FRotator3fCameraParameter::Variable");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FRotator3dCameraParameter
{
    FRotator Value; // 0x0 (Size: 0x18, Type: StructProperty)
    FCameraVariableID VariableID; // 0x18 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    URotator3dCameraVariable* Variable; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FRotator3dCameraParameter) == 0x28, "Size mismatch for FRotator3dCameraParameter");
static_assert(offsetof(FRotator3dCameraParameter, Value) == 0x0, "Offset mismatch for FRotator3dCameraParameter::Value");
static_assert(offsetof(FRotator3dCameraParameter, VariableID) == 0x18, "Offset mismatch for FRotator3dCameraParameter::VariableID");
static_assert(offsetof(FRotator3dCameraParameter, Variable) == 0x20, "Offset mismatch for FRotator3dCameraParameter::Variable");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FTransform3fCameraParameter
{
    FTransform3f Value; // 0x0 (Size: 0x30, Type: StructProperty)
    FCameraVariableID VariableID; // 0x30 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    UTransform3fCameraVariable* Variable; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FTransform3fCameraParameter) == 0x40, "Size mismatch for FTransform3fCameraParameter");
static_assert(offsetof(FTransform3fCameraParameter, Value) == 0x0, "Offset mismatch for FTransform3fCameraParameter::Value");
static_assert(offsetof(FTransform3fCameraParameter, VariableID) == 0x30, "Offset mismatch for FTransform3fCameraParameter::VariableID");
static_assert(offsetof(FTransform3fCameraParameter, Variable) == 0x38, "Offset mismatch for FTransform3fCameraParameter::Variable");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FTransform3dCameraParameter
{
    FTransform Value; // 0x0 (Size: 0x60, Type: StructProperty)
    FCameraVariableID VariableID; // 0x60 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_64[0x4]; // 0x64 (Size: 0x4, Type: PaddingProperty)
    UTransform3dCameraVariable* Variable; // 0x68 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FTransform3dCameraParameter) == 0x70, "Size mismatch for FTransform3dCameraParameter");
static_assert(offsetof(FTransform3dCameraParameter, Value) == 0x0, "Offset mismatch for FTransform3dCameraParameter::Value");
static_assert(offsetof(FTransform3dCameraParameter, VariableID) == 0x60, "Offset mismatch for FTransform3dCameraParameter::VariableID");
static_assert(offsetof(FTransform3dCameraParameter, Variable) == 0x68, "Offset mismatch for FTransform3dCameraParameter::Variable");

// Size: 0x2 (Inherited: 0x0, Single: 0x2)
struct FCameraRigInputSlotParameters
{
    bool bIsAccumulated; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bIsPreBlended; // 0x1 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FCameraRigInputSlotParameters) == 0x2, "Size mismatch for FCameraRigInputSlotParameters");
static_assert(offsetof(FCameraRigInputSlotParameters, bIsAccumulated) == 0x0, "Offset mismatch for FCameraRigInputSlotParameters::bIsAccumulated");
static_assert(offsetof(FCameraRigInputSlotParameters, bIsPreBlended) == 0x1, "Offset mismatch for FCameraRigInputSlotParameters::bIsPreBlended");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCameraParameterClamping
{
    double MinValue; // 0x0 (Size: 0x8, Type: DoubleProperty)
    double MaxValue; // 0x8 (Size: 0x8, Type: DoubleProperty)
    bool bClampMin; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bClampMax; // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FCameraParameterClamping) == 0x18, "Size mismatch for FCameraParameterClamping");
static_assert(offsetof(FCameraParameterClamping, MinValue) == 0x0, "Offset mismatch for FCameraParameterClamping::MinValue");
static_assert(offsetof(FCameraParameterClamping, MaxValue) == 0x8, "Offset mismatch for FCameraParameterClamping::MaxValue");
static_assert(offsetof(FCameraParameterClamping, bClampMin) == 0x10, "Offset mismatch for FCameraParameterClamping::bClampMin");
static_assert(offsetof(FCameraParameterClamping, bClampMax) == 0x11, "Offset mismatch for FCameraParameterClamping::bClampMax");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCameraParameterNormalization
{
    double MaxValue; // 0x0 (Size: 0x8, Type: DoubleProperty)
    bool bNormalize; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FCameraParameterNormalization) == 0x10, "Size mismatch for FCameraParameterNormalization");
static_assert(offsetof(FCameraParameterNormalization, MaxValue) == 0x0, "Offset mismatch for FCameraParameterNormalization::MaxValue");
static_assert(offsetof(FCameraParameterNormalization, bNormalize) == 0x8, "Offset mismatch for FCameraParameterNormalization::bNormalize");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FCameraRigInstanceID
{
    uint32_t Value; // 0x0 (Size: 0x4, Type: UInt32Property)
    uint8_t Layer; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FCameraRigInstanceID) == 0x8, "Size mismatch for FCameraRigInstanceID");
static_assert(offsetof(FCameraRigInstanceID, Value) == 0x0, "Offset mismatch for FCameraRigInstanceID::Value");
static_assert(offsetof(FCameraRigInstanceID, Layer) == 0x4, "Offset mismatch for FCameraRigInstanceID::Layer");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCameraRigProxyTableEntry
{
    UCameraRigProxyAsset* CameraRigProxy; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UCameraRigAsset* CameraRig; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCameraRigProxyTableEntry) == 0x10, "Size mismatch for FCameraRigProxyTableEntry");
static_assert(offsetof(FCameraRigProxyTableEntry, CameraRigProxy) == 0x0, "Offset mismatch for FCameraRigProxyTableEntry::CameraRigProxy");
static_assert(offsetof(FCameraRigProxyTableEntry, CameraRig) == 0x8, "Offset mismatch for FCameraRigProxyTableEntry::CameraRig");

// Size: 0x180 (Inherited: 0x0, Single: 0x180)
struct FCameraRotatorCurve
{
    FRichCurve Curves[0x3]; // 0x0 (Size: 0x180, Type: StructProperty)
};

static_assert(sizeof(FCameraRotatorCurve) == 0x180, "Size mismatch for FCameraRotatorCurve");
static_assert(offsetof(FCameraRotatorCurve, Curves) == 0x0, "Offset mismatch for FCameraRotatorCurve::Curves");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FCameraSingleCurve
{
    FRichCurve Curve; // 0x0 (Size: 0x80, Type: StructProperty)
};

static_assert(sizeof(FCameraSingleCurve) == 0x80, "Size mismatch for FCameraSingleCurve");
static_assert(offsetof(FCameraSingleCurve, Curve) == 0x0, "Offset mismatch for FCameraSingleCurve::Curve");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBooleanCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UBooleanCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FBooleanCameraVariableReference) == 0x10, "Size mismatch for FBooleanCameraVariableReference");
static_assert(offsetof(FBooleanCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FBooleanCameraVariableReference::VariableID");
static_assert(offsetof(FBooleanCameraVariableReference, Variable) == 0x8, "Offset mismatch for FBooleanCameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInteger32CameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UInteger32CameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FInteger32CameraVariableReference) == 0x10, "Size mismatch for FInteger32CameraVariableReference");
static_assert(offsetof(FInteger32CameraVariableReference, VariableID) == 0x0, "Offset mismatch for FInteger32CameraVariableReference::VariableID");
static_assert(offsetof(FInteger32CameraVariableReference, Variable) == 0x8, "Offset mismatch for FInteger32CameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFloatCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UFloatCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFloatCameraVariableReference) == 0x10, "Size mismatch for FFloatCameraVariableReference");
static_assert(offsetof(FFloatCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FFloatCameraVariableReference::VariableID");
static_assert(offsetof(FFloatCameraVariableReference, Variable) == 0x8, "Offset mismatch for FFloatCameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FDoubleCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UDoubleCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDoubleCameraVariableReference) == 0x10, "Size mismatch for FDoubleCameraVariableReference");
static_assert(offsetof(FDoubleCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FDoubleCameraVariableReference::VariableID");
static_assert(offsetof(FDoubleCameraVariableReference, Variable) == 0x8, "Offset mismatch for FDoubleCameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FVector2fCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UVector2fCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVector2fCameraVariableReference) == 0x10, "Size mismatch for FVector2fCameraVariableReference");
static_assert(offsetof(FVector2fCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FVector2fCameraVariableReference::VariableID");
static_assert(offsetof(FVector2fCameraVariableReference, Variable) == 0x8, "Offset mismatch for FVector2fCameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FVector2dCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UVector2dCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVector2dCameraVariableReference) == 0x10, "Size mismatch for FVector2dCameraVariableReference");
static_assert(offsetof(FVector2dCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FVector2dCameraVariableReference::VariableID");
static_assert(offsetof(FVector2dCameraVariableReference, Variable) == 0x8, "Offset mismatch for FVector2dCameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FVector3fCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UVector3fCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVector3fCameraVariableReference) == 0x10, "Size mismatch for FVector3fCameraVariableReference");
static_assert(offsetof(FVector3fCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FVector3fCameraVariableReference::VariableID");
static_assert(offsetof(FVector3fCameraVariableReference, Variable) == 0x8, "Offset mismatch for FVector3fCameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FVector3dCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UVector3dCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVector3dCameraVariableReference) == 0x10, "Size mismatch for FVector3dCameraVariableReference");
static_assert(offsetof(FVector3dCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FVector3dCameraVariableReference::VariableID");
static_assert(offsetof(FVector3dCameraVariableReference, Variable) == 0x8, "Offset mismatch for FVector3dCameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FVector4fCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UVector4fCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVector4fCameraVariableReference) == 0x10, "Size mismatch for FVector4fCameraVariableReference");
static_assert(offsetof(FVector4fCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FVector4fCameraVariableReference::VariableID");
static_assert(offsetof(FVector4fCameraVariableReference, Variable) == 0x8, "Offset mismatch for FVector4fCameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FVector4dCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UVector4dCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FVector4dCameraVariableReference) == 0x10, "Size mismatch for FVector4dCameraVariableReference");
static_assert(offsetof(FVector4dCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FVector4dCameraVariableReference::VariableID");
static_assert(offsetof(FVector4dCameraVariableReference, Variable) == 0x8, "Offset mismatch for FVector4dCameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRotator3fCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    URotator3fCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FRotator3fCameraVariableReference) == 0x10, "Size mismatch for FRotator3fCameraVariableReference");
static_assert(offsetof(FRotator3fCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FRotator3fCameraVariableReference::VariableID");
static_assert(offsetof(FRotator3fCameraVariableReference, Variable) == 0x8, "Offset mismatch for FRotator3fCameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FRotator3dCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    URotator3dCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FRotator3dCameraVariableReference) == 0x10, "Size mismatch for FRotator3dCameraVariableReference");
static_assert(offsetof(FRotator3dCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FRotator3dCameraVariableReference::VariableID");
static_assert(offsetof(FRotator3dCameraVariableReference, Variable) == 0x8, "Offset mismatch for FRotator3dCameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FTransform3fCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UTransform3fCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FTransform3fCameraVariableReference) == 0x10, "Size mismatch for FTransform3fCameraVariableReference");
static_assert(offsetof(FTransform3fCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FTransform3fCameraVariableReference::VariableID");
static_assert(offsetof(FTransform3fCameraVariableReference, Variable) == 0x8, "Offset mismatch for FTransform3fCameraVariableReference::Variable");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FTransform3dCameraVariableReference
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UTransform3dCameraVariable* Variable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FTransform3dCameraVariableReference) == 0x10, "Size mismatch for FTransform3dCameraVariableReference");
static_assert(offsetof(FTransform3dCameraVariableReference, VariableID) == 0x0, "Offset mismatch for FTransform3dCameraVariableReference::VariableID");
static_assert(offsetof(FTransform3dCameraVariableReference, Variable) == 0x8, "Offset mismatch for FTransform3dCameraVariableReference::Variable");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCameraVariableDefinition
{
    FCameraVariableID VariableID; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t VariableType[0x4]; // 0x4 (Size: 0x4, Type: EnumProperty)
    UScriptStruct* BlendableStructType; // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bIsPrivate; // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bIsInput; // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bAutoReset; // 0x12 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_13[0x5]; // 0x13 (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(FCameraVariableDefinition) == 0x18, "Size mismatch for FCameraVariableDefinition");
static_assert(offsetof(FCameraVariableDefinition, VariableID) == 0x0, "Offset mismatch for FCameraVariableDefinition::VariableID");
static_assert(offsetof(FCameraVariableDefinition, VariableType) == 0x4, "Offset mismatch for FCameraVariableDefinition::VariableType");
static_assert(offsetof(FCameraVariableDefinition, BlendableStructType) == 0x8, "Offset mismatch for FCameraVariableDefinition::BlendableStructType");
static_assert(offsetof(FCameraVariableDefinition, bIsPrivate) == 0x10, "Offset mismatch for FCameraVariableDefinition::bIsPrivate");
static_assert(offsetof(FCameraVariableDefinition, bIsInput) == 0x11, "Offset mismatch for FCameraVariableDefinition::bIsInput");
static_assert(offsetof(FCameraVariableDefinition, bAutoReset) == 0x12, "Offset mismatch for FCameraVariableDefinition::bAutoReset");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCameraVariableTableAllocationInfo
{
    TArray<FCameraVariableDefinition> VariableDefinitions; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCameraVariableTableAllocationInfo) == 0x10, "Size mismatch for FCameraVariableTableAllocationInfo");
static_assert(offsetof(FCameraVariableTableAllocationInfo, VariableDefinitions) == 0x0, "Offset mismatch for FCameraVariableTableAllocationInfo::VariableDefinitions");

// Size: 0x180 (Inherited: 0x0, Single: 0x180)
struct FCameraVectorCurve
{
    FRichCurve Curves[0x3]; // 0x0 (Size: 0x180, Type: StructProperty)
};

static_assert(sizeof(FCameraVectorCurve) == 0x180, "Size mismatch for FCameraVectorCurve");
static_assert(offsetof(FCameraVectorCurve, Curves) == 0x0, "Offset mismatch for FCameraVectorCurve::Curves");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCustomCameraNodeBlendableParameter
{
    FName ParameterName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t ParameterType[0x4]; // 0x4 (Size: 0x4, Type: EnumProperty)
    UScriptStruct* BlendableStructType; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FCameraVariableID OverrideVariableID; // 0x10 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    UCameraVariableAsset* OverrideVariable; // 0x18 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCustomCameraNodeBlendableParameter) == 0x20, "Size mismatch for FCustomCameraNodeBlendableParameter");
static_assert(offsetof(FCustomCameraNodeBlendableParameter, ParameterName) == 0x0, "Offset mismatch for FCustomCameraNodeBlendableParameter::ParameterName");
static_assert(offsetof(FCustomCameraNodeBlendableParameter, ParameterType) == 0x4, "Offset mismatch for FCustomCameraNodeBlendableParameter::ParameterType");
static_assert(offsetof(FCustomCameraNodeBlendableParameter, BlendableStructType) == 0x8, "Offset mismatch for FCustomCameraNodeBlendableParameter::BlendableStructType");
static_assert(offsetof(FCustomCameraNodeBlendableParameter, OverrideVariableID) == 0x10, "Offset mismatch for FCustomCameraNodeBlendableParameter::OverrideVariableID");
static_assert(offsetof(FCustomCameraNodeBlendableParameter, OverrideVariable) == 0x18, "Offset mismatch for FCustomCameraNodeBlendableParameter::OverrideVariable");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCustomCameraNodeDataParameter
{
    FName ParameterName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t ParameterType[0x4]; // 0x4 (Size: 0x4, Type: EnumProperty)
    uint8_t ParameterContainerType[0x4]; // 0x8 (Size: 0x4, Type: EnumProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    UObject* ParameterTypeObject; // 0x10 (Size: 0x8, Type: ObjectProperty)
    FCameraContextDataID OverrideDataID; // 0x18 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCustomCameraNodeDataParameter) == 0x20, "Size mismatch for FCustomCameraNodeDataParameter");
static_assert(offsetof(FCustomCameraNodeDataParameter, ParameterName) == 0x0, "Offset mismatch for FCustomCameraNodeDataParameter::ParameterName");
static_assert(offsetof(FCustomCameraNodeDataParameter, ParameterType) == 0x4, "Offset mismatch for FCustomCameraNodeDataParameter::ParameterType");
static_assert(offsetof(FCustomCameraNodeDataParameter, ParameterContainerType) == 0x8, "Offset mismatch for FCustomCameraNodeDataParameter::ParameterContainerType");
static_assert(offsetof(FCustomCameraNodeDataParameter, ParameterTypeObject) == 0x10, "Offset mismatch for FCustomCameraNodeDataParameter::ParameterTypeObject");
static_assert(offsetof(FCustomCameraNodeDataParameter, OverrideDataID) == 0x18, "Offset mismatch for FCustomCameraNodeDataParameter::OverrideDataID");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCustomCameraNodeParameters
{
    TArray<FCustomCameraNodeBlendableParameter> BlendableParameters; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FCustomCameraNodeDataParameter> DataParameters; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCustomCameraNodeParameters) == 0x20, "Size mismatch for FCustomCameraNodeParameters");
static_assert(offsetof(FCustomCameraNodeParameters, BlendableParameters) == 0x0, "Offset mismatch for FCustomCameraNodeParameters::BlendableParameters");
static_assert(offsetof(FCustomCameraNodeParameters, DataParameters) == 0x10, "Offset mismatch for FCustomCameraNodeParameters::DataParameters");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCameraObjectAllocationInfo
{
    FCameraNodeEvaluatorAllocationInfo EvaluatorInfo; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FCameraVariableTableAllocationInfo VariableTableInfo; // 0x8 (Size: 0x10, Type: StructProperty)
    FCameraContextDataTableAllocationInfo ContextDataTableInfo; // 0x18 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FCameraObjectAllocationInfo) == 0x28, "Size mismatch for FCameraObjectAllocationInfo");
static_assert(offsetof(FCameraObjectAllocationInfo, EvaluatorInfo) == 0x0, "Offset mismatch for FCameraObjectAllocationInfo::EvaluatorInfo");
static_assert(offsetof(FCameraObjectAllocationInfo, VariableTableInfo) == 0x8, "Offset mismatch for FCameraObjectAllocationInfo::VariableTableInfo");
static_assert(offsetof(FCameraObjectAllocationInfo, ContextDataTableInfo) == 0x18, "Offset mismatch for FCameraObjectAllocationInfo::ContextDataTableInfo");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FCameraObjectInterfaceParameterMetaData
{
    FGuid ParameterGuid; // 0x0 (Size: 0x10, Type: StructProperty)
    FCameraVariableID OverrideVariableID; // 0x10 (Size: 0x4, Type: StructProperty)
    FCameraContextDataID OverrideDataID; // 0x14 (Size: 0x4, Type: StructProperty)
    bool bIsOverridden; // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bIsAnimated; // 0x19 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1a[0x2]; // 0x1a (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FCameraObjectInterfaceParameterMetaData) == 0x1c, "Size mismatch for FCameraObjectInterfaceParameterMetaData");
static_assert(offsetof(FCameraObjectInterfaceParameterMetaData, ParameterGuid) == 0x0, "Offset mismatch for FCameraObjectInterfaceParameterMetaData::ParameterGuid");
static_assert(offsetof(FCameraObjectInterfaceParameterMetaData, OverrideVariableID) == 0x10, "Offset mismatch for FCameraObjectInterfaceParameterMetaData::OverrideVariableID");
static_assert(offsetof(FCameraObjectInterfaceParameterMetaData, OverrideDataID) == 0x14, "Offset mismatch for FCameraObjectInterfaceParameterMetaData::OverrideDataID");
static_assert(offsetof(FCameraObjectInterfaceParameterMetaData, bIsOverridden) == 0x18, "Offset mismatch for FCameraObjectInterfaceParameterMetaData::bIsOverridden");
static_assert(offsetof(FCameraObjectInterfaceParameterMetaData, bIsAnimated) == 0x19, "Offset mismatch for FCameraObjectInterfaceParameterMetaData::bIsAnimated");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FBaseCameraObjectReference
{
    FInstancedPropertyBag Parameters; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FCameraObjectInterfaceParameterMetaData> ParameterMetaData; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FBaseCameraObjectReference) == 0x28, "Size mismatch for FBaseCameraObjectReference");
static_assert(offsetof(FBaseCameraObjectReference, Parameters) == 0x8, "Offset mismatch for FBaseCameraObjectReference::Parameters");
static_assert(offsetof(FBaseCameraObjectReference, ParameterMetaData) == 0x18, "Offset mismatch for FBaseCameraObjectReference::ParameterMetaData");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCameraAssetAllocationInfo
{
    FCameraVariableTableAllocationInfo VariableTableInfo; // 0x0 (Size: 0x10, Type: StructProperty)
    FCameraContextDataTableAllocationInfo ContextDataTableInfo; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FCameraAssetAllocationInfo) == 0x20, "Size mismatch for FCameraAssetAllocationInfo");
static_assert(offsetof(FCameraAssetAllocationInfo, VariableTableInfo) == 0x0, "Offset mismatch for FCameraAssetAllocationInfo::VariableTableInfo");
static_assert(offsetof(FCameraAssetAllocationInfo, ContextDataTableInfo) == 0x10, "Offset mismatch for FCameraAssetAllocationInfo::ContextDataTableInfo");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FCameraAssetReference
{
    UCameraAsset* CameraAsset; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FInstancedPropertyBag Parameters; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FGuid> ParameterOverrideGuids; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FGuid> ParameterAnimatedGuids; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCameraAssetReference) == 0x38, "Size mismatch for FCameraAssetReference");
static_assert(offsetof(FCameraAssetReference, CameraAsset) == 0x0, "Offset mismatch for FCameraAssetReference::CameraAsset");
static_assert(offsetof(FCameraAssetReference, Parameters) == 0x8, "Offset mismatch for FCameraAssetReference::Parameters");
static_assert(offsetof(FCameraAssetReference, ParameterOverrideGuids) == 0x18, "Offset mismatch for FCameraAssetReference::ParameterOverrideGuids");
static_assert(offsetof(FCameraAssetReference, ParameterAnimatedGuids) == 0x28, "Offset mismatch for FCameraAssetReference::ParameterAnimatedGuids");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCameraObjectInterface
{
    TArray<UCameraObjectInterfaceBlendableParameter*> BlendableParameters; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UCameraObjectInterfaceDataParameter*> DataParameters; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCameraObjectInterface) == 0x20, "Size mismatch for FCameraObjectInterface");
static_assert(offsetof(FCameraObjectInterface, BlendableParameters) == 0x0, "Offset mismatch for FCameraObjectInterface::BlendableParameters");
static_assert(offsetof(FCameraObjectInterface, DataParameters) == 0x10, "Offset mismatch for FCameraObjectInterface::DataParameters");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FCameraPose
{
    FVector3d Location; // 0x0 (Size: 0x18, Type: StructProperty)
    FRotator3d Rotation; // 0x18 (Size: 0x18, Type: StructProperty)
    double TargetDistance; // 0x30 (Size: 0x8, Type: DoubleProperty)
    float FieldOfView; // 0x38 (Size: 0x4, Type: FloatProperty)
    float FocalLength; // 0x3c (Size: 0x4, Type: FloatProperty)
    float Aperture; // 0x40 (Size: 0x4, Type: FloatProperty)
    float ShutterSpeed; // 0x44 (Size: 0x4, Type: FloatProperty)
    float FocusDistance; // 0x48 (Size: 0x4, Type: FloatProperty)
    float SensorWidth; // 0x4c (Size: 0x4, Type: FloatProperty)
    float SensorHeight; // 0x50 (Size: 0x4, Type: FloatProperty)
    float ISO; // 0x54 (Size: 0x4, Type: FloatProperty)
    float SqueezeFactor; // 0x58 (Size: 0x4, Type: FloatProperty)
    int32_t DiaphragmBladeCount; // 0x5c (Size: 0x4, Type: IntProperty)
    float NearClippingPlane; // 0x60 (Size: 0x4, Type: FloatProperty)
    float FarClippingPlane; // 0x64 (Size: 0x4, Type: FloatProperty)
    float PhysicalCameraBlendWeight; // 0x68 (Size: 0x4, Type: FloatProperty)
    bool EnablePhysicalCamera; // 0x6c (Size: 0x1, Type: BoolProperty)
    bool ConstrainAspectRatio; // 0x6d (Size: 0x1, Type: BoolProperty)
    bool OverrideAspectRatioAxisConstraint; // 0x6e (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EAspectRatioAxisConstraint> AspectRatioAxisConstraint; // 0x6f (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_70[0x18]; // 0x70 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(FCameraPose) == 0x88, "Size mismatch for FCameraPose");
static_assert(offsetof(FCameraPose, Location) == 0x0, "Offset mismatch for FCameraPose::Location");
static_assert(offsetof(FCameraPose, Rotation) == 0x18, "Offset mismatch for FCameraPose::Rotation");
static_assert(offsetof(FCameraPose, TargetDistance) == 0x30, "Offset mismatch for FCameraPose::TargetDistance");
static_assert(offsetof(FCameraPose, FieldOfView) == 0x38, "Offset mismatch for FCameraPose::FieldOfView");
static_assert(offsetof(FCameraPose, FocalLength) == 0x3c, "Offset mismatch for FCameraPose::FocalLength");
static_assert(offsetof(FCameraPose, Aperture) == 0x40, "Offset mismatch for FCameraPose::Aperture");
static_assert(offsetof(FCameraPose, ShutterSpeed) == 0x44, "Offset mismatch for FCameraPose::ShutterSpeed");
static_assert(offsetof(FCameraPose, FocusDistance) == 0x48, "Offset mismatch for FCameraPose::FocusDistance");
static_assert(offsetof(FCameraPose, SensorWidth) == 0x4c, "Offset mismatch for FCameraPose::SensorWidth");
static_assert(offsetof(FCameraPose, SensorHeight) == 0x50, "Offset mismatch for FCameraPose::SensorHeight");
static_assert(offsetof(FCameraPose, ISO) == 0x54, "Offset mismatch for FCameraPose::ISO");
static_assert(offsetof(FCameraPose, SqueezeFactor) == 0x58, "Offset mismatch for FCameraPose::SqueezeFactor");
static_assert(offsetof(FCameraPose, DiaphragmBladeCount) == 0x5c, "Offset mismatch for FCameraPose::DiaphragmBladeCount");
static_assert(offsetof(FCameraPose, NearClippingPlane) == 0x60, "Offset mismatch for FCameraPose::NearClippingPlane");
static_assert(offsetof(FCameraPose, FarClippingPlane) == 0x64, "Offset mismatch for FCameraPose::FarClippingPlane");
static_assert(offsetof(FCameraPose, PhysicalCameraBlendWeight) == 0x68, "Offset mismatch for FCameraPose::PhysicalCameraBlendWeight");
static_assert(offsetof(FCameraPose, EnablePhysicalCamera) == 0x6c, "Offset mismatch for FCameraPose::EnablePhysicalCamera");
static_assert(offsetof(FCameraPose, ConstrainAspectRatio) == 0x6d, "Offset mismatch for FCameraPose::ConstrainAspectRatio");
static_assert(offsetof(FCameraPose, OverrideAspectRatioAxisConstraint) == 0x6e, "Offset mismatch for FCameraPose::OverrideAspectRatioAxisConstraint");
static_assert(offsetof(FCameraPose, AspectRatioAxisConstraint) == 0x6f, "Offset mismatch for FCameraPose::AspectRatioAxisConstraint");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FCameraRigParameterOverrideBase
{
    FGuid InterfaceParameterGuid; // 0x0 (Size: 0x10, Type: StructProperty)
    FGuid PrivateVariableGuid; // 0x10 (Size: 0x10, Type: StructProperty)
    FString InterfaceParameterName; // 0x20 (Size: 0x10, Type: StrProperty)
    bool bInvalid; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FCameraRigParameterOverrideBase) == 0x38, "Size mismatch for FCameraRigParameterOverrideBase");
static_assert(offsetof(FCameraRigParameterOverrideBase, InterfaceParameterGuid) == 0x0, "Offset mismatch for FCameraRigParameterOverrideBase::InterfaceParameterGuid");
static_assert(offsetof(FCameraRigParameterOverrideBase, PrivateVariableGuid) == 0x10, "Offset mismatch for FCameraRigParameterOverrideBase::PrivateVariableGuid");
static_assert(offsetof(FCameraRigParameterOverrideBase, InterfaceParameterName) == 0x20, "Offset mismatch for FCameraRigParameterOverrideBase::InterfaceParameterName");
static_assert(offsetof(FCameraRigParameterOverrideBase, bInvalid) == 0x30, "Offset mismatch for FCameraRigParameterOverrideBase::bInvalid");

// Size: 0x48 (Inherited: 0x38, Single: 0x10)
struct FBooleanCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    FBooleanCameraParameter Value; // 0x38 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FBooleanCameraRigParameterOverride) == 0x48, "Size mismatch for FBooleanCameraRigParameterOverride");
static_assert(offsetof(FBooleanCameraRigParameterOverride, Value) == 0x38, "Offset mismatch for FBooleanCameraRigParameterOverride::Value");

// Size: 0x48 (Inherited: 0x38, Single: 0x10)
struct FInteger32CameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    FInteger32CameraParameter Value; // 0x38 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FInteger32CameraRigParameterOverride) == 0x48, "Size mismatch for FInteger32CameraRigParameterOverride");
static_assert(offsetof(FInteger32CameraRigParameterOverride, Value) == 0x38, "Offset mismatch for FInteger32CameraRigParameterOverride::Value");

// Size: 0x48 (Inherited: 0x38, Single: 0x10)
struct FFloatCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    FFloatCameraParameter Value; // 0x38 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FFloatCameraRigParameterOverride) == 0x48, "Size mismatch for FFloatCameraRigParameterOverride");
static_assert(offsetof(FFloatCameraRigParameterOverride, Value) == 0x38, "Offset mismatch for FFloatCameraRigParameterOverride::Value");

// Size: 0x50 (Inherited: 0x38, Single: 0x18)
struct FDoubleCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    FDoubleCameraParameter Value; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDoubleCameraRigParameterOverride) == 0x50, "Size mismatch for FDoubleCameraRigParameterOverride");
static_assert(offsetof(FDoubleCameraRigParameterOverride, Value) == 0x38, "Offset mismatch for FDoubleCameraRigParameterOverride::Value");

// Size: 0x50 (Inherited: 0x38, Single: 0x18)
struct FVector2fCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    FVector2fCameraParameter Value; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FVector2fCameraRigParameterOverride) == 0x50, "Size mismatch for FVector2fCameraRigParameterOverride");
static_assert(offsetof(FVector2fCameraRigParameterOverride, Value) == 0x38, "Offset mismatch for FVector2fCameraRigParameterOverride::Value");

// Size: 0x58 (Inherited: 0x38, Single: 0x20)
struct FVector2dCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    FVector2dCameraParameter Value; // 0x38 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FVector2dCameraRigParameterOverride) == 0x58, "Size mismatch for FVector2dCameraRigParameterOverride");
static_assert(offsetof(FVector2dCameraRigParameterOverride, Value) == 0x38, "Offset mismatch for FVector2dCameraRigParameterOverride::Value");

// Size: 0x50 (Inherited: 0x38, Single: 0x18)
struct FVector3fCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    FVector3fCameraParameter Value; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FVector3fCameraRigParameterOverride) == 0x50, "Size mismatch for FVector3fCameraRigParameterOverride");
static_assert(offsetof(FVector3fCameraRigParameterOverride, Value) == 0x38, "Offset mismatch for FVector3fCameraRigParameterOverride::Value");

// Size: 0x60 (Inherited: 0x38, Single: 0x28)
struct FVector3dCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    FVector3dCameraParameter Value; // 0x38 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FVector3dCameraRigParameterOverride) == 0x60, "Size mismatch for FVector3dCameraRigParameterOverride");
static_assert(offsetof(FVector3dCameraRigParameterOverride, Value) == 0x38, "Offset mismatch for FVector3dCameraRigParameterOverride::Value");

// Size: 0x60 (Inherited: 0x38, Single: 0x28)
struct FVector4fCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    FVector4fCameraParameter Value; // 0x40 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FVector4fCameraRigParameterOverride) == 0x60, "Size mismatch for FVector4fCameraRigParameterOverride");
static_assert(offsetof(FVector4fCameraRigParameterOverride, Value) == 0x40, "Offset mismatch for FVector4fCameraRigParameterOverride::Value");

// Size: 0x70 (Inherited: 0x38, Single: 0x38)
struct FVector4dCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    FVector4dCameraParameter Value; // 0x40 (Size: 0x30, Type: StructProperty)
};

static_assert(sizeof(FVector4dCameraRigParameterOverride) == 0x70, "Size mismatch for FVector4dCameraRigParameterOverride");
static_assert(offsetof(FVector4dCameraRigParameterOverride, Value) == 0x40, "Offset mismatch for FVector4dCameraRigParameterOverride::Value");

// Size: 0x50 (Inherited: 0x38, Single: 0x18)
struct FRotator3fCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    FRotator3fCameraParameter Value; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FRotator3fCameraRigParameterOverride) == 0x50, "Size mismatch for FRotator3fCameraRigParameterOverride");
static_assert(offsetof(FRotator3fCameraRigParameterOverride, Value) == 0x38, "Offset mismatch for FRotator3fCameraRigParameterOverride::Value");

// Size: 0x60 (Inherited: 0x38, Single: 0x28)
struct FRotator3dCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    FRotator3dCameraParameter Value; // 0x38 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FRotator3dCameraRigParameterOverride) == 0x60, "Size mismatch for FRotator3dCameraRigParameterOverride");
static_assert(offsetof(FRotator3dCameraRigParameterOverride, Value) == 0x38, "Offset mismatch for FRotator3dCameraRigParameterOverride::Value");

// Size: 0x80 (Inherited: 0x38, Single: 0x48)
struct FTransform3fCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    FTransform3fCameraParameter Value; // 0x40 (Size: 0x40, Type: StructProperty)
};

static_assert(sizeof(FTransform3fCameraRigParameterOverride) == 0x80, "Size mismatch for FTransform3fCameraRigParameterOverride");
static_assert(offsetof(FTransform3fCameraRigParameterOverride, Value) == 0x40, "Offset mismatch for FTransform3fCameraRigParameterOverride::Value");

// Size: 0xb0 (Inherited: 0x38, Single: 0x78)
struct FTransform3dCameraRigParameterOverride : FCameraRigParameterOverrideBase
{
    uint8_t Pad_38[0x8]; // 0x38 (Size: 0x8, Type: PaddingProperty)
    FTransform3dCameraParameter Value; // 0x40 (Size: 0x70, Type: StructProperty)
};

static_assert(sizeof(FTransform3dCameraRigParameterOverride) == 0xb0, "Size mismatch for FTransform3dCameraRigParameterOverride");
static_assert(offsetof(FTransform3dCameraRigParameterOverride, Value) == 0x40, "Offset mismatch for FTransform3dCameraRigParameterOverride::Value");

// Size: 0xe0 (Inherited: 0x0, Single: 0xe0)
struct FCameraRigParameterOverrides
{
    TArray<FBooleanCameraRigParameterOverride> BooleanOverrides; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FInteger32CameraRigParameterOverride> Integer32Overrides; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FFloatCameraRigParameterOverride> FloatOverrides; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FDoubleCameraRigParameterOverride> DoubleOverrides; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2fCameraRigParameterOverride> Vector2fOverrides; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector2dCameraRigParameterOverride> Vector2dOverrides; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector3fCameraRigParameterOverride> Vector3fOverrides; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector3dCameraRigParameterOverride> Vector3dOverrides; // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector4fCameraRigParameterOverride> Vector4fOverrides; // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector4dCameraRigParameterOverride> Vector4dOverrides; // 0x90 (Size: 0x10, Type: ArrayProperty)
    TArray<FRotator3fCameraRigParameterOverride> Rotator3fOverrides; // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FRotator3dCameraRigParameterOverride> Rotator3dOverrides; // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform3fCameraRigParameterOverride> Transform3fOverrides; // 0xc0 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform3dCameraRigParameterOverride> Transform3dOverrides; // 0xd0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCameraRigParameterOverrides) == 0xe0, "Size mismatch for FCameraRigParameterOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, BooleanOverrides) == 0x0, "Offset mismatch for FCameraRigParameterOverrides::BooleanOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, Integer32Overrides) == 0x10, "Offset mismatch for FCameraRigParameterOverrides::Integer32Overrides");
static_assert(offsetof(FCameraRigParameterOverrides, FloatOverrides) == 0x20, "Offset mismatch for FCameraRigParameterOverrides::FloatOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, DoubleOverrides) == 0x30, "Offset mismatch for FCameraRigParameterOverrides::DoubleOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, Vector2fOverrides) == 0x40, "Offset mismatch for FCameraRigParameterOverrides::Vector2fOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, Vector2dOverrides) == 0x50, "Offset mismatch for FCameraRigParameterOverrides::Vector2dOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, Vector3fOverrides) == 0x60, "Offset mismatch for FCameraRigParameterOverrides::Vector3fOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, Vector3dOverrides) == 0x70, "Offset mismatch for FCameraRigParameterOverrides::Vector3dOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, Vector4fOverrides) == 0x80, "Offset mismatch for FCameraRigParameterOverrides::Vector4fOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, Vector4dOverrides) == 0x90, "Offset mismatch for FCameraRigParameterOverrides::Vector4dOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, Rotator3fOverrides) == 0xa0, "Offset mismatch for FCameraRigParameterOverrides::Rotator3fOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, Rotator3dOverrides) == 0xb0, "Offset mismatch for FCameraRigParameterOverrides::Rotator3dOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, Transform3fOverrides) == 0xc0, "Offset mismatch for FCameraRigParameterOverrides::Transform3fOverrides");
static_assert(offsetof(FCameraRigParameterOverrides, Transform3dOverrides) == 0xd0, "Offset mismatch for FCameraRigParameterOverrides::Transform3dOverrides");

// Size: 0x120 (Inherited: 0x28, Single: 0xf8)
struct FCameraRigAssetReference : FBaseCameraObjectReference
{
    UCameraRigAsset* CameraRig; // 0x28 (Size: 0x8, Type: ObjectProperty)
    TArray<FGuid> ParameterOverrideGuids; // 0x30 (Size: 0x10, Type: ArrayProperty)
    FCameraRigParameterOverrides ParameterOverrides; // 0x40 (Size: 0xe0, Type: StructProperty)
};

static_assert(sizeof(FCameraRigAssetReference) == 0x120, "Size mismatch for FCameraRigAssetReference");
static_assert(offsetof(FCameraRigAssetReference, CameraRig) == 0x28, "Offset mismatch for FCameraRigAssetReference::CameraRig");
static_assert(offsetof(FCameraRigAssetReference, ParameterOverrideGuids) == 0x30, "Offset mismatch for FCameraRigAssetReference::ParameterOverrideGuids");
static_assert(offsetof(FCameraRigAssetReference, ParameterOverrides) == 0x40, "Offset mismatch for FCameraRigAssetReference::ParameterOverrides");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
struct FCameraShakeAssetReference : FBaseCameraObjectReference
{
    UCameraShakeAsset* CameraShake; // 0x28 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCameraShakeAssetReference) == 0x30, "Size mismatch for FCameraShakeAssetReference");
static_assert(offsetof(FCameraShakeAssetReference, CameraShake) == 0x28, "Offset mismatch for FCameraShakeAssetReference::CameraShake");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FBlueprintCameraDirectorActivateParams
{
    UObject* EvaluationContextOwner; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FBlueprintCameraDirectorActivateParams) == 0x8, "Size mismatch for FBlueprintCameraDirectorActivateParams");
static_assert(offsetof(FBlueprintCameraDirectorActivateParams, EvaluationContextOwner) == 0x0, "Offset mismatch for FBlueprintCameraDirectorActivateParams::EvaluationContextOwner");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FBlueprintCameraDirectorDeactivateParams
{
    UObject* EvaluationContextOwner; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FBlueprintCameraDirectorDeactivateParams) == 0x8, "Size mismatch for FBlueprintCameraDirectorDeactivateParams");
static_assert(offsetof(FBlueprintCameraDirectorDeactivateParams, EvaluationContextOwner) == 0x0, "Offset mismatch for FBlueprintCameraDirectorDeactivateParams::EvaluationContextOwner");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBlueprintCameraDirectorEvaluationParams
{
    float DeltaTime; // 0x0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UObject* EvaluationContextOwner; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FBlueprintCameraDirectorEvaluationParams) == 0x10, "Size mismatch for FBlueprintCameraDirectorEvaluationParams");
static_assert(offsetof(FBlueprintCameraDirectorEvaluationParams, DeltaTime) == 0x0, "Offset mismatch for FBlueprintCameraDirectorEvaluationParams::DeltaTime");
static_assert(offsetof(FBlueprintCameraDirectorEvaluationParams, EvaluationContextOwner) == 0x8, "Offset mismatch for FBlueprintCameraDirectorEvaluationParams::EvaluationContextOwner");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FCameraDirectorStateTreeEvaluationData
{
    TArray<UCameraRigAsset*> ActiveCameraRigs; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UCameraRigProxyAsset*> ActiveCameraRigProxies; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCameraDirectorStateTreeEvaluationData) == 0x20, "Size mismatch for FCameraDirectorStateTreeEvaluationData");
static_assert(offsetof(FCameraDirectorStateTreeEvaluationData, ActiveCameraRigs) == 0x0, "Offset mismatch for FCameraDirectorStateTreeEvaluationData::ActiveCameraRigs");
static_assert(offsetof(FCameraDirectorStateTreeEvaluationData, ActiveCameraRigProxies) == 0x10, "Offset mismatch for FCameraDirectorStateTreeEvaluationData::ActiveCameraRigProxies");

// Size: 0x20 (Inherited: 0x38, Single: 0xffffffe8)
struct FGameplayCamerasStateTreeTask : FStateTreeTaskBase
{
};

static_assert(sizeof(FGameplayCamerasStateTreeTask) == 0x20, "Size mismatch for FGameplayCamerasStateTreeTask");

// Size: 0x20 (Inherited: 0x38, Single: 0xffffffe8)
struct FGameplayCamerasStateTreeCondition : FStateTreeConditionBase
{
};

static_assert(sizeof(FGameplayCamerasStateTreeCondition) == 0x20, "Size mismatch for FGameplayCamerasStateTreeCondition");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGameplayCamerasActivateCameraRigTaskInstanceData
{
    UCameraRigAsset* CameraRig; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGameplayCamerasActivateCameraRigTaskInstanceData) == 0x8, "Size mismatch for FGameplayCamerasActivateCameraRigTaskInstanceData");
static_assert(offsetof(FGameplayCamerasActivateCameraRigTaskInstanceData, CameraRig) == 0x0, "Offset mismatch for FGameplayCamerasActivateCameraRigTaskInstanceData::CameraRig");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FGameplayCamerasActivateCameraRigTask : FGameplayCamerasStateTreeTask
{
    uint8_t Pad_20[0x6]; // 0x20 (Size: 0x6, Type: PaddingProperty)
    bool bRunOnce; // 0x26 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_27[0x1]; // 0x27 (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayCamerasActivateCameraRigTask) == 0x28, "Size mismatch for FGameplayCamerasActivateCameraRigTask");
static_assert(offsetof(FGameplayCamerasActivateCameraRigTask, bRunOnce) == 0x26, "Offset mismatch for FGameplayCamerasActivateCameraRigTask::bRunOnce");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGameplayCamerasActivateCameraRigViaProxyTaskInstanceData
{
    UCameraRigProxyAsset* CameraRigProxy; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGameplayCamerasActivateCameraRigViaProxyTaskInstanceData) == 0x8, "Size mismatch for FGameplayCamerasActivateCameraRigViaProxyTaskInstanceData");
static_assert(offsetof(FGameplayCamerasActivateCameraRigViaProxyTaskInstanceData, CameraRigProxy) == 0x0, "Offset mismatch for FGameplayCamerasActivateCameraRigViaProxyTaskInstanceData::CameraRigProxy");

// Size: 0x28 (Inherited: 0x58, Single: 0xffffffd0)
struct FGameplayCamerasActivateCameraRigViaProxyTask : FGameplayCamerasStateTreeTask
{
    uint8_t Pad_20[0x6]; // 0x20 (Size: 0x6, Type: PaddingProperty)
    bool bRunOnce; // 0x26 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_27[0x1]; // 0x27 (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayCamerasActivateCameraRigViaProxyTask) == 0x28, "Size mismatch for FGameplayCamerasActivateCameraRigViaProxyTask");
static_assert(offsetof(FGameplayCamerasActivateCameraRigViaProxyTask, bRunOnce) == 0x26, "Offset mismatch for FGameplayCamerasActivateCameraRigViaProxyTask::bRunOnce");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FBlueprintCameraContextDataTable
{
};

static_assert(sizeof(FBlueprintCameraContextDataTable) == 0x8, "Size mismatch for FBlueprintCameraContextDataTable");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FBlueprintCameraPose
{
    FVector Location; // 0x0 (Size: 0x18, Type: StructProperty)
    FRotator Rotation; // 0x18 (Size: 0x18, Type: StructProperty)
    double TargetDistance; // 0x30 (Size: 0x8, Type: DoubleProperty)
    float FieldOfView; // 0x38 (Size: 0x4, Type: FloatProperty)
    float FocalLength; // 0x3c (Size: 0x4, Type: FloatProperty)
    float Aperture; // 0x40 (Size: 0x4, Type: FloatProperty)
    float ShutterSpeed; // 0x44 (Size: 0x4, Type: FloatProperty)
    float FocusDistance; // 0x48 (Size: 0x4, Type: FloatProperty)
    float SensorWidth; // 0x4c (Size: 0x4, Type: FloatProperty)
    float SensorHeight; // 0x50 (Size: 0x4, Type: FloatProperty)
    float ISO; // 0x54 (Size: 0x4, Type: FloatProperty)
    float SqueezeFactor; // 0x58 (Size: 0x4, Type: FloatProperty)
    int32_t DiaphragmBladeCount; // 0x5c (Size: 0x4, Type: IntProperty)
    float NearClippingPlane; // 0x60 (Size: 0x4, Type: FloatProperty)
    float FarClippingPlane; // 0x64 (Size: 0x4, Type: FloatProperty)
    float PhysicalCameraBlendWeight; // 0x68 (Size: 0x4, Type: FloatProperty)
    bool EnablePhysicalCamera; // 0x6c (Size: 0x1, Type: BoolProperty)
    bool ConstrainAspectRatio; // 0x6d (Size: 0x1, Type: BoolProperty)
    bool OverrideAspectRatioAxisConstraint; // 0x6e (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EAspectRatioAxisConstraint> AspectRatioAxisConstraint; // 0x6f (Size: 0x1, Type: ByteProperty)
};

static_assert(sizeof(FBlueprintCameraPose) == 0x70, "Size mismatch for FBlueprintCameraPose");
static_assert(offsetof(FBlueprintCameraPose, Location) == 0x0, "Offset mismatch for FBlueprintCameraPose::Location");
static_assert(offsetof(FBlueprintCameraPose, Rotation) == 0x18, "Offset mismatch for FBlueprintCameraPose::Rotation");
static_assert(offsetof(FBlueprintCameraPose, TargetDistance) == 0x30, "Offset mismatch for FBlueprintCameraPose::TargetDistance");
static_assert(offsetof(FBlueprintCameraPose, FieldOfView) == 0x38, "Offset mismatch for FBlueprintCameraPose::FieldOfView");
static_assert(offsetof(FBlueprintCameraPose, FocalLength) == 0x3c, "Offset mismatch for FBlueprintCameraPose::FocalLength");
static_assert(offsetof(FBlueprintCameraPose, Aperture) == 0x40, "Offset mismatch for FBlueprintCameraPose::Aperture");
static_assert(offsetof(FBlueprintCameraPose, ShutterSpeed) == 0x44, "Offset mismatch for FBlueprintCameraPose::ShutterSpeed");
static_assert(offsetof(FBlueprintCameraPose, FocusDistance) == 0x48, "Offset mismatch for FBlueprintCameraPose::FocusDistance");
static_assert(offsetof(FBlueprintCameraPose, SensorWidth) == 0x4c, "Offset mismatch for FBlueprintCameraPose::SensorWidth");
static_assert(offsetof(FBlueprintCameraPose, SensorHeight) == 0x50, "Offset mismatch for FBlueprintCameraPose::SensorHeight");
static_assert(offsetof(FBlueprintCameraPose, ISO) == 0x54, "Offset mismatch for FBlueprintCameraPose::ISO");
static_assert(offsetof(FBlueprintCameraPose, SqueezeFactor) == 0x58, "Offset mismatch for FBlueprintCameraPose::SqueezeFactor");
static_assert(offsetof(FBlueprintCameraPose, DiaphragmBladeCount) == 0x5c, "Offset mismatch for FBlueprintCameraPose::DiaphragmBladeCount");
static_assert(offsetof(FBlueprintCameraPose, NearClippingPlane) == 0x60, "Offset mismatch for FBlueprintCameraPose::NearClippingPlane");
static_assert(offsetof(FBlueprintCameraPose, FarClippingPlane) == 0x64, "Offset mismatch for FBlueprintCameraPose::FarClippingPlane");
static_assert(offsetof(FBlueprintCameraPose, PhysicalCameraBlendWeight) == 0x68, "Offset mismatch for FBlueprintCameraPose::PhysicalCameraBlendWeight");
static_assert(offsetof(FBlueprintCameraPose, EnablePhysicalCamera) == 0x6c, "Offset mismatch for FBlueprintCameraPose::EnablePhysicalCamera");
static_assert(offsetof(FBlueprintCameraPose, ConstrainAspectRatio) == 0x6d, "Offset mismatch for FBlueprintCameraPose::ConstrainAspectRatio");
static_assert(offsetof(FBlueprintCameraPose, OverrideAspectRatioAxisConstraint) == 0x6e, "Offset mismatch for FBlueprintCameraPose::OverrideAspectRatioAxisConstraint");
static_assert(offsetof(FBlueprintCameraPose, AspectRatioAxisConstraint) == 0x6f, "Offset mismatch for FBlueprintCameraPose::AspectRatioAxisConstraint");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FBlueprintCameraVariableTable
{
};

static_assert(sizeof(FBlueprintCameraVariableTable) == 0x8, "Size mismatch for FBlueprintCameraVariableTable");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FPerlinNoiseData
{
    float Amplitude; // 0x0 (Size: 0x4, Type: FloatProperty)
    float Frequency; // 0x4 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FPerlinNoiseData) == 0x8, "Size mismatch for FPerlinNoiseData");
static_assert(offsetof(FPerlinNoiseData, Amplitude) == 0x0, "Offset mismatch for FPerlinNoiseData::Amplitude");
static_assert(offsetof(FPerlinNoiseData, Frequency) == 0x4, "Offset mismatch for FPerlinNoiseData::Frequency");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FSplineOrbitControlPoint
{
    FVector3d LocationOffset; // 0x0 (Size: 0x18, Type: StructProperty)
    FVector3d TargetOffset; // 0x18 (Size: 0x18, Type: StructProperty)
    FRotator3d RotationOffset; // 0x30 (Size: 0x18, Type: StructProperty)
    float PitchAngle; // 0x48 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FSplineOrbitControlPoint) == 0x50, "Size mismatch for FSplineOrbitControlPoint");
static_assert(offsetof(FSplineOrbitControlPoint, LocationOffset) == 0x0, "Offset mismatch for FSplineOrbitControlPoint::LocationOffset");
static_assert(offsetof(FSplineOrbitControlPoint, TargetOffset) == 0x18, "Offset mismatch for FSplineOrbitControlPoint::TargetOffset");
static_assert(offsetof(FSplineOrbitControlPoint, RotationOffset) == 0x30, "Offset mismatch for FSplineOrbitControlPoint::RotationOffset");
static_assert(offsetof(FSplineOrbitControlPoint, PitchAngle) == 0x48, "Offset mismatch for FSplineOrbitControlPoint::PitchAngle");

