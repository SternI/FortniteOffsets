/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayStreamingFN
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "GameplayStreaming.h"
#include "FortniteGame.h"

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UFortLocalPlayerAccountHelper : public UObject
{
public:
};

static_assert(sizeof(UFortLocalPlayerAccountHelper) == 0x50, "Size mismatch for UFortLocalPlayerAccountHelper");

// Size: 0xb0 (Inherited: 0x118, Single: 0xffffff98)
class UFortGFNGameplayStreamingHandler : public UGFNGameplayStreamingHandler
{
public:
    uint8_t Pad_78[0x8]; // 0x78 (Size: 0x8, Type: PaddingProperty)
    UFortLocalPlayerAccountHelper* FortLocalPlayerAccountHelper; // 0x80 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFortOnlineAccount*> WeakFortOnlineAccount; // 0x88 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_90[0x20]; // 0x90 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(UFortGFNGameplayStreamingHandler) == 0xb0, "Size mismatch for UFortGFNGameplayStreamingHandler");
static_assert(offsetof(UFortGFNGameplayStreamingHandler, FortLocalPlayerAccountHelper) == 0x80, "Offset mismatch for UFortGFNGameplayStreamingHandler::FortLocalPlayerAccountHelper");
static_assert(offsetof(UFortGFNGameplayStreamingHandler, WeakFortOnlineAccount) == 0x88, "Offset mismatch for UFortGFNGameplayStreamingHandler::WeakFortOnlineAccount");

// Size: 0xf8 (Inherited: 0x118, Single: 0xffffffe0)
class UFortLunaGameplayStreamingHandler : public ULunaGameplayStreamingHandler
{
public:
    uint8_t Pad_78[0x58]; // 0x78 (Size: 0x58, Type: PaddingProperty)
    UFortLocalPlayerAccountHelper* FortLocalPlayerAccountHelper; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UFortOnlineAccount*> WeakFortOnlineAccount; // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_e0[0x8]; // 0xe0 (Size: 0x8, Type: PaddingProperty)
    TArray<FGameEntryDeepLink> GameEntryDeepLinks; // 0xe8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortLunaGameplayStreamingHandler) == 0xf8, "Size mismatch for UFortLunaGameplayStreamingHandler");
static_assert(offsetof(UFortLunaGameplayStreamingHandler, FortLocalPlayerAccountHelper) == 0xd0, "Offset mismatch for UFortLunaGameplayStreamingHandler::FortLocalPlayerAccountHelper");
static_assert(offsetof(UFortLunaGameplayStreamingHandler, WeakFortOnlineAccount) == 0xd8, "Offset mismatch for UFortLunaGameplayStreamingHandler::WeakFortOnlineAccount");
static_assert(offsetof(UFortLunaGameplayStreamingHandler, GameEntryDeepLinks) == 0xe8, "Offset mismatch for UFortLunaGameplayStreamingHandler::GameEntryDeepLinks");

// Size: 0x90 (Inherited: 0x118, Single: 0xffffff78)
class UFortSalmonGameplayStreamingHandler : public USalmonGameplayStreamingHandler
{
public:
};

static_assert(sizeof(UFortSalmonGameplayStreamingHandler) == 0x90, "Size mismatch for UFortSalmonGameplayStreamingHandler");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortGameplayStreamingHandler : public UInterface
{
public:
};

static_assert(sizeof(UFortGameplayStreamingHandler) == 0x28, "Size mismatch for UFortGameplayStreamingHandler");

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
class UFortGameplayStreamingService : public UGameplayStreamingService
{
public:
};

static_assert(sizeof(UFortGameplayStreamingService) == 0x38, "Size mismatch for UFortGameplayStreamingService");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FGameEntryDeepLink
{
    FString ProductID; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Playlist; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FGameEntryDeepLink) == 0x20, "Size mismatch for FGameEntryDeepLink");
static_assert(offsetof(FGameEntryDeepLink, ProductID) == 0x0, "Offset mismatch for FGameEntryDeepLink::ProductID");
static_assert(offsetof(FGameEntryDeepLink, Playlist) == 0x10, "Offset mismatch for FGameEntryDeepLink::Playlist");

