/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMCalibrationUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "ModelViewViewModel.h"
#include "CoreUObject.h"
#include "HarmonixMetasound.h"
#include "FMCalibrationRuntime.h"

// Size: 0xf8 (Inherited: 0x90, Single: 0x68)
class UCalibrationProcessVM : public UMVVMViewModelBase
{
public:
    UFMCalibrationControllerComponent* CalibrationComponent; // 0x68 (Size: 0x8, Type: ObjectProperty)
    float MinAudioCalibrationMs; // 0x70 (Size: 0x4, Type: FloatProperty)
    float MaxAudioCalibrationMs; // 0x74 (Size: 0x4, Type: FloatProperty)
    float MinVideoCalibrationMs; // 0x78 (Size: 0x4, Type: FloatProperty)
    float MaxVideoCalibrationMs; // 0x7c (Size: 0x4, Type: FloatProperty)
    float ErrorFractionOutOfWindow; // 0x80 (Size: 0x4, Type: FloatProperty)
    float ErrorHalfWindowFrames; // 0x84 (Size: 0x4, Type: FloatProperty)
    float MinErrorHalfWindowSizeMs; // 0x88 (Size: 0x4, Type: FloatProperty)
    float AudioSamplesMultiplier; // 0x8c (Size: 0x4, Type: FloatProperty)

public:
    void CommitCalibrationValues(); // 0x122abd1c (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool CompletedWithError() const; // 0x122abda0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool DoCalibrometerDisplay() const; // 0x122abdd4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void EndProcess(); // 0x122abe08 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    float GetBpm() const; // 0xec61128 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetErrorBody() const; // 0x122abe54 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetErrorTitle() const; // 0x122abe90 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetInputProgress() const; // 0x122abecc (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetIntermediateAudioLatencyMs() const; // 0xe7736e0 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetIntermediateVideoLatencyMs() const; // 0xf418cac (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FVector2D GetLatencyMsMinMax() const; // 0x122abef8 (Index: 0xa, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    float GetLatencyPrecision() const; // 0x122abf14 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnInputReceived(UMusicClockComponent*& MusicClock); // 0x122abf40 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    void SetIntermediateAudioLatencyMs(float& Latency); // 0x122ac06c (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)
    void SetIntermediateVideoLatencyMs(float& Latency); // 0x122ac198 (Index: 0xe, Flags: Final|Native|Public|BlueprintCallable)
    void StartAudioCalibration(); // 0x122ac2c4 (Index: 0xf, Flags: Final|Native|Public|BlueprintCallable)
    void StartProcess(); // 0x122ac2d8 (Index: 0x10, Flags: Final|Native|Public|BlueprintCallable)
    void StartVideoCalibration(); // 0x122ac2ec (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCalibrationProcessVM) == 0xf8, "Size mismatch for UCalibrationProcessVM");
static_assert(offsetof(UCalibrationProcessVM, CalibrationComponent) == 0x68, "Offset mismatch for UCalibrationProcessVM::CalibrationComponent");
static_assert(offsetof(UCalibrationProcessVM, MinAudioCalibrationMs) == 0x70, "Offset mismatch for UCalibrationProcessVM::MinAudioCalibrationMs");
static_assert(offsetof(UCalibrationProcessVM, MaxAudioCalibrationMs) == 0x74, "Offset mismatch for UCalibrationProcessVM::MaxAudioCalibrationMs");
static_assert(offsetof(UCalibrationProcessVM, MinVideoCalibrationMs) == 0x78, "Offset mismatch for UCalibrationProcessVM::MinVideoCalibrationMs");
static_assert(offsetof(UCalibrationProcessVM, MaxVideoCalibrationMs) == 0x7c, "Offset mismatch for UCalibrationProcessVM::MaxVideoCalibrationMs");
static_assert(offsetof(UCalibrationProcessVM, ErrorFractionOutOfWindow) == 0x80, "Offset mismatch for UCalibrationProcessVM::ErrorFractionOutOfWindow");
static_assert(offsetof(UCalibrationProcessVM, ErrorHalfWindowFrames) == 0x84, "Offset mismatch for UCalibrationProcessVM::ErrorHalfWindowFrames");
static_assert(offsetof(UCalibrationProcessVM, MinErrorHalfWindowSizeMs) == 0x88, "Offset mismatch for UCalibrationProcessVM::MinErrorHalfWindowSizeMs");
static_assert(offsetof(UCalibrationProcessVM, AudioSamplesMultiplier) == 0x8c, "Offset mismatch for UCalibrationProcessVM::AudioSamplesMultiplier");

// Size: 0x78 (Inherited: 0x90, Single: 0xffffffe8)
class UCalibrationProfileVM : public UMVVMViewModelBase
{
public:
    bool bHasUsedCalibrationProfileFeature; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x3]; // 0x69 (Size: 0x3, Type: PaddingProperty)
    int32_t ActiveProfileIndex; // 0x6c (Size: 0x4, Type: IntProperty)
    UFMCalibrationControllerComponent* CalibrationComponent; // 0x70 (Size: 0x8, Type: ObjectProperty)

protected:
    void OnCalibrationUpdated(); // 0x122abf2c (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UCalibrationProfileVM) == 0x78, "Size mismatch for UCalibrationProfileVM");
static_assert(offsetof(UCalibrationProfileVM, bHasUsedCalibrationProfileFeature) == 0x68, "Offset mismatch for UCalibrationProfileVM::bHasUsedCalibrationProfileFeature");
static_assert(offsetof(UCalibrationProfileVM, ActiveProfileIndex) == 0x6c, "Offset mismatch for UCalibrationProfileVM::ActiveProfileIndex");
static_assert(offsetof(UCalibrationProfileVM, CalibrationComponent) == 0x70, "Offset mismatch for UCalibrationProfileVM::CalibrationComponent");

