/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticsFrameworkEvents
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCosmeticsEventRegistrar : public UInterface
{
public:

public:
    FCosmeticsEventHandle RegisterOnCosmeticApplicationCompleted_BP(const FDelegate Delegate, int32_t& Flags); // 0xc990ed8 (Index: 0x0, Flags: Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UCosmeticsEventRegistrar) == 0x28, "Size mismatch for UCosmeticsEventRegistrar");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCosmeticsFinishable : public UInterface
{
public:
};

static_assert(sizeof(UCosmeticsFinishable) == 0x28, "Size mismatch for UCosmeticsFinishable");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCosmeticsMeshTarget : public UInterface
{
public:
};

static_assert(sizeof(UCosmeticsMeshTarget) == 0x28, "Size mismatch for UCosmeticsMeshTarget");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCosmeticsStreaming : public UInterface
{
public:
};

static_assert(sizeof(UCosmeticsStreaming) == 0x28, "Size mismatch for UCosmeticsStreaming");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FCosmeticsEventHandle
{
};

static_assert(sizeof(FCosmeticsEventHandle) == 0x1, "Size mismatch for FCosmeticsEventHandle");

