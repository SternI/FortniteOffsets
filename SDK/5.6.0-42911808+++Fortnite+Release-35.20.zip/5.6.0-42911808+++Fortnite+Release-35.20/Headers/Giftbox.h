/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Giftbox
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CommonUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "GiftBox.h"
#include "SlateCore.h"
#include "SeasonPass.h"
#include "Engine.h"
#include "UI.h"
#include "Widgets.h"

// Size: 0x2d8 (Inherited: 0x730, Single: 0xfffffba8)
class USubscriptionProgressiveGiftBoxHeader_C : public UCommonUserWidget
{
public:

public:
    void GetCustomBackground(TSoftObjectPtr<UObject*>& Background); // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(USubscriptionProgressiveGiftBoxHeader_C) == 0x2d8, "Size mismatch for USubscriptionProgressiveGiftBoxHeader_C");

// Size: 0x2d8 (Inherited: 0x730, Single: 0xfffffba8)
class USubscriptionGiftBoxHeader_C : public UCommonUserWidget
{
public:

public:
    void GetCustomBackground(TSoftObjectPtr<UObject*>& Background); // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(USubscriptionGiftBoxHeader_C) == 0x2d8, "Size mismatch for USubscriptionGiftBoxHeader_C");

// Size: 0x3a8 (Inherited: 0x730, Single: 0xfffffc78)
class UBPGiftBoxScreenHeader_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2d8 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_SubHeader; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Header; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Body; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    USeasonPassBadgeIcon_C* SeasonPassBadgeIcon; // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UWBP_GiftBox_AutoClaimedStatus_C* AutoClaimStatus; // 0x300 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* IntroAnim; // 0x308 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* InitialState; // 0x310 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* FadeAnim; // 0x318 (Size: 0x8, Type: ObjectProperty)
    UGiftBoxVM* GiftBoxVM; // 0x320 (Size: 0x8, Type: ObjectProperty)
    UGiftBoxItemVM* GiftBoxItemVM; // 0x328 (Size: 0x8, Type: ObjectProperty)
    USeasonPassSystemVM* SeasonPassSystemVM; // 0x330 (Size: 0x8, Type: ObjectProperty)
    FSlateColor Header_Color; // 0x338 (Size: 0x14, Type: StructProperty)
    FSlateColor SubHeader_Color; // 0x34c (Size: 0x14, Type: StructProperty)
    FSlateColor Body_Color; // 0x360 (Size: 0x14, Type: StructProperty)
    FSlateColor Badge_Color; // 0x374 (Size: 0x14, Type: StructProperty)
    TSoftObjectPtr<UObject*> Custom_Background; // 0x388 (Size: 0x20, Type: SoftObjectProperty)

public:
    void GetCustomBackground(TSoftObjectPtr<UObject*>& Background); // 0x288a61c (Index: 0x0, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void Get_Season_Pass(UGiftBoxVM*& Gift_Box, USeasonPassSystemVM*& Season_Pass_System, USeasonPassVM*& Result) const; // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void Get_Header_Text(FText& Gift_Box_Text, FText& Item_Text, FText& Result) const; // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void Get_Color_Override(FSlateColor& Color, FSlateColor& Color_Override, bool& Use_Color_Override, FSlateColor& NewParam1) const; // 0x288a61c (Index: 0x3, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void SetGiftBoxVM(UGiftBoxVM*& ViewModel); // 0x288a61c (Index: 0xa, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void SetGiftBoxItemVM(UGiftBoxItemVM*& ViewModel); // 0x288a61c (Index: 0xb, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void Set_Sub_Header_Text(FText& Text); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Season_Pass(USeasonPassVM*& Pass); // 0x288a61c (Index: 0xd, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Body_Text(FText& Text); // 0x288a61c (Index: 0xf, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x10, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void HandleOutro(); // 0x288a61c (Index: 0x11, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleIntro(); // 0x288a61c (Index: 0x12, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleInitialState(); // 0x288a61c (Index: 0x13, Flags: Public|BlueprintCallable|BlueprintEvent)
    void HandleGiftBoxSet(UGiftBoxVM*& GiftBox); // 0x288a61c (Index: 0x14, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    void __ea0356c4_461a_c0cb_5afa_d9a6e56f5765_SourceToDest(FText& Result) const; // 0x288a61c (Index: 0x5, Flags: Final|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void __c2743850_4f29_5649_9cb2_ec9f9229aae6_SourceToDest(FSlateColor& NewParam1) const; // 0x288a61c (Index: 0x6, Flags: Final|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void __b603b9f1_412a_7ae4_1e3f_b2a7f67fb171_SourceToDest(USeasonPassVM*& Result) const; // 0x288a61c (Index: 0x7, Flags: Final|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void __3401639b_4c1d_c9ed_48a3_cfb796fad25e_SourceToDest(FSlateColor& NewParam1) const; // 0x288a61c (Index: 0x8, Flags: Final|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void __0b2e8ccb_4261_b9d7_2a40_6fa11b53c4cf_SourceToDest(FSlateColor& NewParam1) const; // 0x288a61c (Index: 0x9, Flags: Final|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UBPGiftBoxScreenHeader_C) == 0x3a8, "Size mismatch for UBPGiftBoxScreenHeader_C");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, UberGraphFrame) == 0x2d8, "Offset mismatch for UBPGiftBoxScreenHeader_C::UberGraphFrame");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, Text_SubHeader) == 0x2e0, "Offset mismatch for UBPGiftBoxScreenHeader_C::Text_SubHeader");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, Text_Header) == 0x2e8, "Offset mismatch for UBPGiftBoxScreenHeader_C::Text_Header");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, Text_Body) == 0x2f0, "Offset mismatch for UBPGiftBoxScreenHeader_C::Text_Body");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, SeasonPassBadgeIcon) == 0x2f8, "Offset mismatch for UBPGiftBoxScreenHeader_C::SeasonPassBadgeIcon");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, AutoClaimStatus) == 0x300, "Offset mismatch for UBPGiftBoxScreenHeader_C::AutoClaimStatus");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, IntroAnim) == 0x308, "Offset mismatch for UBPGiftBoxScreenHeader_C::IntroAnim");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, InitialState) == 0x310, "Offset mismatch for UBPGiftBoxScreenHeader_C::InitialState");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, FadeAnim) == 0x318, "Offset mismatch for UBPGiftBoxScreenHeader_C::FadeAnim");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, GiftBoxVM) == 0x320, "Offset mismatch for UBPGiftBoxScreenHeader_C::GiftBoxVM");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, GiftBoxItemVM) == 0x328, "Offset mismatch for UBPGiftBoxScreenHeader_C::GiftBoxItemVM");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, SeasonPassSystemVM) == 0x330, "Offset mismatch for UBPGiftBoxScreenHeader_C::SeasonPassSystemVM");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, Header_Color) == 0x338, "Offset mismatch for UBPGiftBoxScreenHeader_C::Header_Color");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, SubHeader_Color) == 0x34c, "Offset mismatch for UBPGiftBoxScreenHeader_C::SubHeader_Color");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, Body_Color) == 0x360, "Offset mismatch for UBPGiftBoxScreenHeader_C::Body_Color");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, Badge_Color) == 0x374, "Offset mismatch for UBPGiftBoxScreenHeader_C::Badge_Color");
static_assert(offsetof(UBPGiftBoxScreenHeader_C, Custom_Background) == 0x388, "Offset mismatch for UBPGiftBoxScreenHeader_C::Custom_Background");

