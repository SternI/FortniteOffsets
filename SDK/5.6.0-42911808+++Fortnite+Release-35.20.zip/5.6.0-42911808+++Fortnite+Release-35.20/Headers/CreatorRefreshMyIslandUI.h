/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreatorRefreshMyIslandUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CommonUI.h"
#include "Engine.h"
#include "SlateCore.h"

// Size: 0x430 (Inherited: 0xb38, Single: 0xfffff8f8)
class UFortCreativeMyIslandSideNavWidget : public UCommonActivatableWidget
{
public:
    FDataTableRowHandle SearchInputActionRow; // 0x408 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ClearSearchInputActionRow; // 0x418 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_428[0x8]; // 0x428 (Size: 0x8, Type: PaddingProperty)

protected:
    FDataTableRowHandle GetClearSearchInputAction(); // 0x11e9e0b4 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure)
    FDataTableRowHandle GetFocusSearchInputAction(); // 0x11e9e0f0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure)
    FSlateBrush GetIconForInputAction(bool& bOutFoundIcon, const FDataTableRowHandle InInputActionRow); // 0x11e9e12c (Index: 0x2, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    virtual void OnClearSearchInput(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintCallable|BlueprintEvent)
    virtual void OnClearSearchProgress(float& Progress); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSearchInput(); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    void SetClearSearchInputEnabled(bool& const bEnabled); // 0x11e9e2d8 (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable)
    void SetSearchInputEnabled(bool& const bEnabled); // 0x11e9e40c (Index: 0x7, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortCreativeMyIslandSideNavWidget) == 0x430, "Size mismatch for UFortCreativeMyIslandSideNavWidget");
static_assert(offsetof(UFortCreativeMyIslandSideNavWidget, SearchInputActionRow) == 0x408, "Offset mismatch for UFortCreativeMyIslandSideNavWidget::SearchInputActionRow");
static_assert(offsetof(UFortCreativeMyIslandSideNavWidget, ClearSearchInputActionRow) == 0x418, "Offset mismatch for UFortCreativeMyIslandSideNavWidget::ClearSearchInputActionRow");

