/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Customization
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "UMG.h"
#include "Systems.h"
#include "CoreUObject.h"
#include "FortniteUI.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "UIKit.h"
#include "CommonUI.h"

// Size: 0x2b0 (Inherited: 0x458, Single: 0xfffffe58)
class UWBP_CustomItemDetailsBase_C : public UUserWidget
{
public:

public:
    void SetItemDetailsVM(UFortItemDetailsVM*& Item_Details_VM); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_CustomItemDetailsBase_C) == 0x2b0, "Size mismatch for UWBP_CustomItemDetailsBase_C");

// Size: 0x4d8 (Inherited: 0x90c, Single: 0xfffffbcc)
class UWBP_UIKit_ItemDescription_MPL_C : public UWBP_UIKit_ItemDescription_Base_C
{
public:
    uint8_t Pad_4b4[0x4]; // 0x4b4 (Size: 0x4, Type: PaddingProperty)
    FPointerToUberGraphFrame UberGraphFrame; // 0x4b8 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_InfoBox_C* AccessRestriction_Warning; // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UFortItemDetailsVM* FortItemDetailsVM; // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UFortLockerCategoryItemVM* FortLockerCategoryItemVM; // 0x4d0 (Size: 0x8, Type: ObjectProperty)

public:
    void Update_Category_Text_From_Item(FText& Category_Text); // 0x288a61c (Index: 0x0, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void Update_Category_Text_From_Category_Item(FText& Category_Text); // 0x288a61c (Index: 0x1, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void SetFortLockerCategoryItemVM(UFortLockerCategoryItemVM*& ViewModel); // 0x288a61c (Index: 0x2, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    void SetFortItemDetailsVM(UFortItemDetailsVM*& ViewModel); // 0x288a61c (Index: 0x3, Flags: Final|Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x4, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void isDetailedFigureIncoming(bool& isDetailedFigureIncoming); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Get_Category_Text(FText& Item_Text, FText& Category_Text, FText& Result) const; // 0x288a61c (Index: 0x7, Flags: Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void Access_Restrictions_Changed(EItemAccessRestriction& Restriction); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    void GetRarityColors(bool& IsSeries, const FFortColorPalette FortColorPalette, FFortColorPalette& RarityColors) const; // 0x288a61c (Index: 0x6, Flags: Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    void __569107d4_4513_b561_d0f9_999fd629fbc7_SourceToDest(FFortColorPalette& RarityColors) const; // 0x288a61c (Index: 0xa, Flags: Final|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UWBP_UIKit_ItemDescription_MPL_C) == 0x4d8, "Size mismatch for UWBP_UIKit_ItemDescription_MPL_C");
static_assert(offsetof(UWBP_UIKit_ItemDescription_MPL_C, UberGraphFrame) == 0x4b8, "Offset mismatch for UWBP_UIKit_ItemDescription_MPL_C::UberGraphFrame");
static_assert(offsetof(UWBP_UIKit_ItemDescription_MPL_C, AccessRestriction_Warning) == 0x4c0, "Offset mismatch for UWBP_UIKit_ItemDescription_MPL_C::AccessRestriction_Warning");
static_assert(offsetof(UWBP_UIKit_ItemDescription_MPL_C, FortItemDetailsVM) == 0x4c8, "Offset mismatch for UWBP_UIKit_ItemDescription_MPL_C::FortItemDetailsVM");
static_assert(offsetof(UWBP_UIKit_ItemDescription_MPL_C, FortLockerCategoryItemVM) == 0x4d0, "Offset mismatch for UWBP_UIKit_ItemDescription_MPL_C::FortLockerCategoryItemVM");

// Size: 0x2c9 (Inherited: 0x458, Single: 0xfffffe71)
class UWBP_MPLocker_Heading_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x2b0 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_SubHeader; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Header; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    bool Show_Sub_Heading_; // 0x2c8 (Size: 0x1, Type: BoolProperty)

public:
    void SetSubHeadingVisibility(bool& ShowSubHeading_); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetSubHeader(FText& Text); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SetHeader(FText& Text); // 0x288a61c (Index: 0x2, Flags: Public|BlueprintCallable|BlueprintEvent)
    void PresetForDesignTime(); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void PreConstruct(bool& IsDesignTime); // 0x288a61c (Index: 0x4, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UWBP_MPLocker_Heading_C) == 0x2c9, "Size mismatch for UWBP_MPLocker_Heading_C");
static_assert(offsetof(UWBP_MPLocker_Heading_C, UberGraphFrame) == 0x2b0, "Offset mismatch for UWBP_MPLocker_Heading_C::UberGraphFrame");
static_assert(offsetof(UWBP_MPLocker_Heading_C, Text_SubHeader) == 0x2b8, "Offset mismatch for UWBP_MPLocker_Heading_C::Text_SubHeader");
static_assert(offsetof(UWBP_MPLocker_Heading_C, Text_Header) == 0x2c0, "Offset mismatch for UWBP_MPLocker_Heading_C::Text_Header");
static_assert(offsetof(UWBP_MPLocker_Heading_C, Show_Sub_Heading_) == 0x2c8, "Offset mismatch for UWBP_MPLocker_Heading_C::Show_Sub_Heading_");

// Size: 0x2c8 (Inherited: 0x458, Single: 0xfffffe70)
class UWBP_CustomItemDetailsContainer_C : public UUserWidget
{
public:
    UNamedSlot* NamedSlot_CustomDetails; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnCustomWidgetSet[0x10]; // 0x2b8 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void CreateCustomItemDetails(UFortItemDetailsVM*& Item_Details_VM); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void RemoveCustomItemDetails(); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void OnCustomWidgetSet__DelegateSignature(UUserWidget*& Widget); // 0x288a61c (Index: 0x2, Flags: Public|Delegate|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UWBP_CustomItemDetailsContainer_C) == 0x2c8, "Size mismatch for UWBP_CustomItemDetailsContainer_C");
static_assert(offsetof(UWBP_CustomItemDetailsContainer_C, NamedSlot_CustomDetails) == 0x2b0, "Offset mismatch for UWBP_CustomItemDetailsContainer_C::NamedSlot_CustomDetails");
static_assert(offsetof(UWBP_CustomItemDetailsContainer_C, OnCustomWidgetSet) == 0x2b8, "Offset mismatch for UWBP_CustomItemDetailsContainer_C::OnCustomWidgetSet");

