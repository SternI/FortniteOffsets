/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_SkilledInteractionDevice
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CommonUI.h"
#include "Engine.h"

// Size: 0x448 (Inherited: 0xb38, Single: 0xfffff910)
class UFortSkilledInteractContainerBase : public UCommonActivatableWidget
{
public:
    uint8_t OnInputPressed[0x10]; // 0x408 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnInputReleased[0x10]; // 0x418 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<FActionIdentifier> TriggeringActions; // 0x428 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_438[0x10]; // 0x438 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UFortSkilledInteractContainerBase) == 0x448, "Size mismatch for UFortSkilledInteractContainerBase");
static_assert(offsetof(UFortSkilledInteractContainerBase, OnInputPressed) == 0x408, "Offset mismatch for UFortSkilledInteractContainerBase::OnInputPressed");
static_assert(offsetof(UFortSkilledInteractContainerBase, OnInputReleased) == 0x418, "Offset mismatch for UFortSkilledInteractContainerBase::OnInputReleased");
static_assert(offsetof(UFortSkilledInteractContainerBase, TriggeringActions) == 0x428, "Offset mismatch for UFortSkilledInteractContainerBase::TriggeringActions");

// Size: 0xd8 (Inherited: 0xe0, Single: 0xfffffff8)
class UFortSkilledInteractionPlayerQueueComponent : public UActorComponent
{
public:
    uint8_t QueueType; // 0xb8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_b9[0x3]; // 0xb9 (Size: 0x3, Type: PaddingProperty)
    int32_t SynchronousExecutionAmount; // 0xbc (Size: 0x4, Type: IntProperty)
    bool bAllowDuplicateControllerEntries; // 0xc0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c1[0x7]; // 0xc1 (Size: 0x7, Type: PaddingProperty)
    TArray<TSoftObjectPtr<AController*>> ControllerQueue; // 0xc8 (Size: 0x10, Type: ArrayProperty)

public:
    bool AddActorToControllerQueue(AActor*& ExpectedControllerActor); // 0x11e7e224 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void ClearQueue(); // 0x11e7e8d8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    TArray<AController*> PopControllersForInteraction(); // 0x11e7e940 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortSkilledInteractionPlayerQueueComponent) == 0xd8, "Size mismatch for UFortSkilledInteractionPlayerQueueComponent");
static_assert(offsetof(UFortSkilledInteractionPlayerQueueComponent, QueueType) == 0xb8, "Offset mismatch for UFortSkilledInteractionPlayerQueueComponent::QueueType");
static_assert(offsetof(UFortSkilledInteractionPlayerQueueComponent, SynchronousExecutionAmount) == 0xbc, "Offset mismatch for UFortSkilledInteractionPlayerQueueComponent::SynchronousExecutionAmount");
static_assert(offsetof(UFortSkilledInteractionPlayerQueueComponent, bAllowDuplicateControllerEntries) == 0xc0, "Offset mismatch for UFortSkilledInteractionPlayerQueueComponent::bAllowDuplicateControllerEntries");
static_assert(offsetof(UFortSkilledInteractionPlayerQueueComponent, ControllerQueue) == 0xc8, "Offset mismatch for UFortSkilledInteractionPlayerQueueComponent::ControllerQueue");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FActionIdentifier
{
    uint8_t CommonInputType; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    FName ActionName; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FActionIdentifier) == 0x8, "Size mismatch for FActionIdentifier");
static_assert(offsetof(FActionIdentifier, CommonInputType) == 0x0, "Offset mismatch for FActionIdentifier::CommonInputType");
static_assert(offsetof(FActionIdentifier, ActionName) == 0x4, "Offset mismatch for FActionIdentifier::ActionName");

