/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteConversationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "CommonConversationRuntime.h"
#include "Engine.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "GameplayTags.h"
#include "PlayspaceSystem.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortConversationGetGraphInterface : public UInterface
{
public:

public:
    virtual UConversationDatabase* GetConversationGraph(); // 0x497c904 (Index: 0x0, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UFortConversationGetGraphInterface) == 0x28, "Size mismatch for UFortConversationGetGraphInterface");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortConversationMarkerInterface : public UInterface
{
public:
};

static_assert(sizeof(UFortConversationMarkerInterface) == 0x28, "Size mismatch for UFortConversationMarkerInterface");

// Size: 0x1a8 (Inherited: 0x288, Single: 0xffffff20)
class UFortConversationParticipantComponent : public UConversationParticipantComponent
{
public:
};

static_assert(sizeof(UFortConversationParticipantComponent) == 0x1a8, "Size mismatch for UFortConversationParticipantComponent");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UFortConversationContextCondition : public UObject
{
public:

public:
    bool DoesContextPass(const FConversationContext Context) const; // 0xfe8a974 (Index: 0x0, Flags: Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortConversationContextCondition) == 0x28, "Size mismatch for UFortConversationContextCondition");

// Size: 0x40 (Inherited: 0x50, Single: 0xfffffff0)
class UFortConversationContextCondition_ParticipantHasCID : public UFortConversationContextCondition
{
public:
    FGameplayTag ParticipantID; // 0x28 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    TArray<FSoftObjectPath> AllowedCIDs; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortConversationContextCondition_ParticipantHasCID) == 0x40, "Size mismatch for UFortConversationContextCondition_ParticipantHasCID");
static_assert(offsetof(UFortConversationContextCondition_ParticipantHasCID, ParticipantID) == 0x28, "Offset mismatch for UFortConversationContextCondition_ParticipantHasCID::ParticipantID");
static_assert(offsetof(UFortConversationContextCondition_ParticipantHasCID, AllowedCIDs) == 0x30, "Offset mismatch for UFortConversationContextCondition_ParticipantHasCID::AllowedCIDs");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UFortConversationContextCondition_ParticipantHasMetaTag : public UFortConversationContextCondition
{
public:
    FGameplayTag ParticipantID; // 0x28 (Size: 0x4, Type: StructProperty)
    FGameplayTag MetaTag; // 0x2c (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(UFortConversationContextCondition_ParticipantHasMetaTag) == 0x30, "Size mismatch for UFortConversationContextCondition_ParticipantHasMetaTag");
static_assert(offsetof(UFortConversationContextCondition_ParticipantHasMetaTag, ParticipantID) == 0x28, "Offset mismatch for UFortConversationContextCondition_ParticipantHasMetaTag::ParticipantID");
static_assert(offsetof(UFortConversationContextCondition_ParticipantHasMetaTag, MetaTag) == 0x2c, "Offset mismatch for UFortConversationContextCondition_ParticipantHasMetaTag::MetaTag");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UFortConversationContextCondition_ParticipantHasOwnedTag : public UFortConversationContextCondition
{
public:
    FGameplayTag ParticipantID; // 0x28 (Size: 0x4, Type: StructProperty)
    FGameplayTag OwnedTag; // 0x2c (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(UFortConversationContextCondition_ParticipantHasOwnedTag) == 0x30, "Size mismatch for UFortConversationContextCondition_ParticipantHasOwnedTag");
static_assert(offsetof(UFortConversationContextCondition_ParticipantHasOwnedTag, ParticipantID) == 0x28, "Offset mismatch for UFortConversationContextCondition_ParticipantHasOwnedTag::ParticipantID");
static_assert(offsetof(UFortConversationContextCondition_ParticipantHasOwnedTag, OwnedTag) == 0x2c, "Offset mismatch for UFortConversationContextCondition_ParticipantHasOwnedTag::OwnedTag");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UFortConversationContextCondition_ParticipantControllerMeetsRequirement : public UFortConversationContextCondition
{
public:
    FGameplayTag ParticipantID; // 0x28 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    UFortControllerRequirement* Requirement; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortConversationContextCondition_ParticipantControllerMeetsRequirement) == 0x38, "Size mismatch for UFortConversationContextCondition_ParticipantControllerMeetsRequirement");
static_assert(offsetof(UFortConversationContextCondition_ParticipantControllerMeetsRequirement, ParticipantID) == 0x28, "Offset mismatch for UFortConversationContextCondition_ParticipantControllerMeetsRequirement::ParticipantID");
static_assert(offsetof(UFortConversationContextCondition_ParticipantControllerMeetsRequirement, Requirement) == 0x30, "Offset mismatch for UFortConversationContextCondition_ParticipantControllerMeetsRequirement::Requirement");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortConversationContextConditionHelpers : public UBlueprintFunctionLibrary
{
public:

private:
    static bool GetMessageForContext(const FFortConversationNodeConditionalMessages Messages, const FConversationContext Context, FText& OutText); // 0xfe8aea0 (Index: 0x0, Flags: Final|Native|Static|Private|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UFortConversationContextConditionHelpers) == 0x28, "Size mismatch for UFortConversationContextConditionHelpers");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortConversationParamLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool ExtractConversationParameterValue(const TArray<FConversationNodeParameterPair> ConversationParameters, FString& DesiredParameterName, FString& ParameterValueOut); // 0xfe8abe0 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UFortConversationParamLibrary) == 0x28, "Size mismatch for UFortConversationParamLibrary");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UFortniteConversationGlobals : public UObject
{
public:
};

static_assert(sizeof(UFortniteConversationGlobals) == 0x28, "Size mismatch for UFortniteConversationGlobals");

// Size: 0x3f0 (Inherited: 0x430, Single: 0xffffffc0)
class UFortPlayerConversationComponent : public UFortConversationParticipantComponent
{
public:
    uint8_t Pad_1a8[0x8]; // 0x1a8 (Size: 0x8, Type: PaddingProperty)
    TArray<UFortNonPlayerConversationParticipantComponent*> ConversationParticipantsInRange; // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    float GreetSphereRadius; // 0x1c0 (Size: 0x4, Type: FloatProperty)
    float IconVisibilityRadius; // 0x1c4 (Size: 0x4, Type: FloatProperty)
    float AbortConversationRange; // 0x1c8 (Size: 0x4, Type: FloatProperty)
    FGameplayTag RidingOnActorTag; // 0x1cc (Size: 0x4, Type: StructProperty)
    float RidingOnActorRangeMultiplierSquared; // 0x1d0 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1d4[0x3c]; // 0x1d4 (Size: 0x3c, Type: PaddingProperty)
    TSet<UFortNonPlayerConversationParticipantComponent*> IndicatedNPCConversationComponents; // 0x210 (Size: 0x50, Type: SetProperty)
    uint8_t Pad_260[0x8]; // 0x260 (Size: 0x8, Type: PaddingProperty)
    bool bMoveShouldAbortConversation; // 0x268 (Size: 0x1, Type: BoolProperty)
    bool bCachedDefaultMoveShouldAbortConverationValue; // 0x269 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_26a[0x11e]; // 0x26a (Size: 0x11e, Type: PaddingProperty)
    FClientConversationMessagePayload LastSanitizationMessage; // 0x388 (Size: 0x68, Type: StructProperty)

public:
    virtual void ClientReceiveConversationGiftUINotification(FGiftUINotificationInfo& const ConversationGiftUINotification); // 0xfe8a89c (Index: 0x0, Flags: Net|NetReliableNative|Event|Public|NetClient)
    virtual void ClientSpectatorCloseUI(); // 0xc018c0c (Index: 0x1, Flags: Net|NetReliableNative|Event|Public|NetClient)
    virtual void ClientSpectatorEnterConversationState(); // 0xcd4c71c (Index: 0x2, Flags: Net|NetReliableNative|Event|Public|NetClient)
    virtual void ClientSpectatorLeaveConversationState(); // 0xcd5526c (Index: 0x3, Flags: Net|NetReliableNative|Event|Public|NetClient)
    virtual void ClientSpectatorOpenUI(); // 0xc018c24 (Index: 0x4, Flags: Net|NetReliableNative|Event|Public|NetClient)
    virtual void FortConversationScreenInitialized(UWidget*& WidgetToUpdate); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
    virtual void RequestServerAbortConversation(); // 0xceafd84 (Index: 0xe, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable)
    virtual void RequestServerAbortConversationWithParticipant(UFortNonPlayerConversationParticipantComponent*& const Participant); // 0xceef77c (Index: 0xf, Flags: Net|NetReliableNative|Event|Public|NetServer)

private:
    void HandleDBNOChanged(AFortPawn*& Pawn, bool& bIsDBNO); // 0xa2025c0 (Index: 0x6, Flags: Final|Native|Private)
    void HandleFollowedPlayerChanged(AFortPlayerControllerSpectating*& SpectatingPC, AFortPlayerState*& FollowedPlayerState); // 0xfe8b1c8 (Index: 0x7, Flags: Final|Native|Private)
    void HandlePossessedPawnChangedWhileRefreshTriggersBound(APawn*& OldPawn, APawn*& NewPawn); // 0xfe8b3d0 (Index: 0x8, Flags: Final|Native|Private)
    void HandleViewTargetChanged(); // 0xfe8b608 (Index: 0x9, Flags: Final|Native|Private)
    void HandleWeaponEquipped(AFortWeapon*& NewWeapon, AFortWeapon*& PrevWeapon); // 0xa93bc70 (Index: 0xa, Flags: Final|Native|Private)

protected:
    void OnMinigameEnded(); // 0x554e3c4 (Index: 0xb, Flags: Final|Native|Protected)
    void OnMinigameReady(AFortMinigame*& InMinigame); // 0xfe8b61c (Index: 0xc, Flags: Final|Native|Protected)
    void OnRootPlayspaceSet(APlayspace*& RootPlayspace); // 0xfe8b8d4 (Index: 0xd, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortPlayerConversationComponent) == 0x3f0, "Size mismatch for UFortPlayerConversationComponent");
static_assert(offsetof(UFortPlayerConversationComponent, ConversationParticipantsInRange) == 0x1b0, "Offset mismatch for UFortPlayerConversationComponent::ConversationParticipantsInRange");
static_assert(offsetof(UFortPlayerConversationComponent, GreetSphereRadius) == 0x1c0, "Offset mismatch for UFortPlayerConversationComponent::GreetSphereRadius");
static_assert(offsetof(UFortPlayerConversationComponent, IconVisibilityRadius) == 0x1c4, "Offset mismatch for UFortPlayerConversationComponent::IconVisibilityRadius");
static_assert(offsetof(UFortPlayerConversationComponent, AbortConversationRange) == 0x1c8, "Offset mismatch for UFortPlayerConversationComponent::AbortConversationRange");
static_assert(offsetof(UFortPlayerConversationComponent, RidingOnActorTag) == 0x1cc, "Offset mismatch for UFortPlayerConversationComponent::RidingOnActorTag");
static_assert(offsetof(UFortPlayerConversationComponent, RidingOnActorRangeMultiplierSquared) == 0x1d0, "Offset mismatch for UFortPlayerConversationComponent::RidingOnActorRangeMultiplierSquared");
static_assert(offsetof(UFortPlayerConversationComponent, IndicatedNPCConversationComponents) == 0x210, "Offset mismatch for UFortPlayerConversationComponent::IndicatedNPCConversationComponents");
static_assert(offsetof(UFortPlayerConversationComponent, bMoveShouldAbortConversation) == 0x268, "Offset mismatch for UFortPlayerConversationComponent::bMoveShouldAbortConversation");
static_assert(offsetof(UFortPlayerConversationComponent, bCachedDefaultMoveShouldAbortConverationValue) == 0x269, "Offset mismatch for UFortPlayerConversationComponent::bCachedDefaultMoveShouldAbortConverationValue");
static_assert(offsetof(UFortPlayerConversationComponent, LastSanitizationMessage) == 0x388, "Offset mismatch for UFortPlayerConversationComponent::LastSanitizationMessage");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFortConversationEnterEvent
{
    APlayerController* PlayerController; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortConversationEnterEvent) == 0x8, "Size mismatch for FFortConversationEnterEvent");
static_assert(offsetof(FFortConversationEnterEvent, PlayerController) == 0x0, "Offset mismatch for FFortConversationEnterEvent::PlayerController");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FFortConversationLeaveEvent
{
    APlayerController* PlayerController; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FFortConversationLeaveEvent) == 0x8, "Size mismatch for FFortConversationLeaveEvent");
static_assert(offsetof(FFortConversationLeaveEvent, PlayerController) == 0x0, "Offset mismatch for FFortConversationLeaveEvent::PlayerController");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FFortConversation_Spectator_EnterConversation
{
};

static_assert(sizeof(FFortConversation_Spectator_EnterConversation) == 0x1, "Size mismatch for FFortConversation_Spectator_EnterConversation");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FFortConversation_Spectator_LeaveConversation
{
};

static_assert(sizeof(FFortConversation_Spectator_LeaveConversation) == 0x1, "Size mismatch for FFortConversation_Spectator_LeaveConversation");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FFortConversation_SetDialogMarkerClassEvent
{
};

static_assert(sizeof(FFortConversation_SetDialogMarkerClassEvent) == 0x1, "Size mismatch for FFortConversation_SetDialogMarkerClassEvent");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FNPCConversationIndicatorMessage
{
    UFortNonPlayerConversationParticipantComponent* NPCConversationComponent; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FNPCConversationIndicatorMessage) == 0x8, "Size mismatch for FNPCConversationIndicatorMessage");
static_assert(offsetof(FNPCConversationIndicatorMessage, NPCConversationComponent) == 0x0, "Offset mismatch for FNPCConversationIndicatorMessage::NPCConversationComponent");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FFortConversation_NPC_AddIndicator : FNPCConversationIndicatorMessage
{
};

static_assert(sizeof(FFortConversation_NPC_AddIndicator) == 0x8, "Size mismatch for FFortConversation_NPC_AddIndicator");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FFortConversation_NPC_RemoveIndicator : FNPCConversationIndicatorMessage
{
};

static_assert(sizeof(FFortConversation_NPC_RemoveIndicator) == 0x8, "Size mismatch for FFortConversation_NPC_RemoveIndicator");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FConversationSettingDialogMarkerData
{
    TSoftClassPtr DialogMarkerSoftClass; // 0x0 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FConversationSettingDialogMarkerData) == 0x20, "Size mismatch for FConversationSettingDialogMarkerData");
static_assert(offsetof(FConversationSettingDialogMarkerData, DialogMarkerSoftClass) == 0x0, "Offset mismatch for FConversationSettingDialogMarkerData::DialogMarkerSoftClass");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortConversationConditionalMessage
{
    UFortConversationContextCondition* Condition; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FText Message; // 0x8 (Size: 0x10, Type: TextProperty)
};

static_assert(sizeof(FFortConversationConditionalMessage) == 0x18, "Size mismatch for FFortConversationConditionalMessage");
static_assert(offsetof(FFortConversationConditionalMessage, Condition) == 0x0, "Offset mismatch for FFortConversationConditionalMessage::Condition");
static_assert(offsetof(FFortConversationConditionalMessage, Message) == 0x8, "Offset mismatch for FFortConversationConditionalMessage::Message");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortConversationNodeConditionalMessages
{
    TArray<FFortConversationConditionalMessage> Messages; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortConversationNodeConditionalMessages) == 0x10, "Size mismatch for FFortConversationNodeConditionalMessages");
static_assert(offsetof(FFortConversationNodeConditionalMessages, Messages) == 0x0, "Offset mismatch for FFortConversationNodeConditionalMessages::Messages");

