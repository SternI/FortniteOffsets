/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortSoundCueTemplates
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "SoundCueTemplates.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "DeveloperSettings.h"

// Size: 0x570 (Inherited: 0x11f0, Single: 0xfffff380)
class UEmoteBase : public UFortSoundCueTemplateBase
{
public:
};

static_assert(sizeof(UEmoteBase) == 0x570, "Size mismatch for UEmoteBase");

// Size: 0x570 (Inherited: 0xc80, Single: 0xfffff8f0)
class UFortSoundCueTemplateBase : public USoundCueTemplate
{
public:
};

static_assert(sizeof(UFortSoundCueTemplateBase) == 0x570, "Size mismatch for UFortSoundCueTemplateBase");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UEmoteFoley : public UEmoteBase
{
public:
};

static_assert(sizeof(UEmoteFoley) == 0x570, "Size mismatch for UEmoteFoley");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UEmoteMusic : public UEmoteBase
{
public:
};

static_assert(sizeof(UEmoteMusic) == 0x570, "Size mismatch for UEmoteMusic");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UEmoteMusic3P : public UEmoteBase
{
public:
};

static_assert(sizeof(UEmoteMusic3P) == 0x570, "Size mismatch for UEmoteMusic3P");

// Size: 0x570 (Inherited: 0x1cd0, Single: 0xffffe8a0)
class UFootstepFoley : public UPlayerFoley
{
public:
};

static_assert(sizeof(UFootstepFoley) == 0x570, "Size mismatch for UFootstepFoley");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UPlayerFoley : public UPlayerFoleyBase
{
public:
};

static_assert(sizeof(UPlayerFoley) == 0x570, "Size mismatch for UPlayerFoley");

// Size: 0x570 (Inherited: 0x11f0, Single: 0xfffff380)
class UPlayerFoleyBase : public UFortSoundCueTemplateBase
{
public:
};

static_assert(sizeof(UPlayerFoleyBase) == 0x570, "Size mismatch for UPlayerFoleyBase");

// Size: 0x90 (Inherited: 0x58, Single: 0x38)
class UFortSoundCueTemplateDefaults : public UDataAsset
{
public:
    USoundClass* SoundClass; // 0x30 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* Attenuation; // 0x38 (Size: 0x8, Type: ObjectProperty)
    USoundConcurrency* Concurrency; // 0x40 (Size: 0x8, Type: ObjectProperty)
    float VolumeMultiplier; // 0x48 (Size: 0x4, Type: FloatProperty)
    float PitchMultiplier; // 0x4c (Size: 0x4, Type: FloatProperty)
    TArray<FFortSubmixPair> SubmixSends; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortBusPair> PreEffectBusSends; // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortBusPair> PostEffectBusSends; // 0x70 (Size: 0x10, Type: ArrayProperty)
    USoundWave* LicensedTrackAlternative; // 0x80 (Size: 0x8, Type: ObjectProperty)
    USoundSubmixBase* LicensedSubmix; // 0x88 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortSoundCueTemplateDefaults) == 0x90, "Size mismatch for UFortSoundCueTemplateDefaults");
static_assert(offsetof(UFortSoundCueTemplateDefaults, SoundClass) == 0x30, "Offset mismatch for UFortSoundCueTemplateDefaults::SoundClass");
static_assert(offsetof(UFortSoundCueTemplateDefaults, Attenuation) == 0x38, "Offset mismatch for UFortSoundCueTemplateDefaults::Attenuation");
static_assert(offsetof(UFortSoundCueTemplateDefaults, Concurrency) == 0x40, "Offset mismatch for UFortSoundCueTemplateDefaults::Concurrency");
static_assert(offsetof(UFortSoundCueTemplateDefaults, VolumeMultiplier) == 0x48, "Offset mismatch for UFortSoundCueTemplateDefaults::VolumeMultiplier");
static_assert(offsetof(UFortSoundCueTemplateDefaults, PitchMultiplier) == 0x4c, "Offset mismatch for UFortSoundCueTemplateDefaults::PitchMultiplier");
static_assert(offsetof(UFortSoundCueTemplateDefaults, SubmixSends) == 0x50, "Offset mismatch for UFortSoundCueTemplateDefaults::SubmixSends");
static_assert(offsetof(UFortSoundCueTemplateDefaults, PreEffectBusSends) == 0x60, "Offset mismatch for UFortSoundCueTemplateDefaults::PreEffectBusSends");
static_assert(offsetof(UFortSoundCueTemplateDefaults, PostEffectBusSends) == 0x70, "Offset mismatch for UFortSoundCueTemplateDefaults::PostEffectBusSends");
static_assert(offsetof(UFortSoundCueTemplateDefaults, LicensedTrackAlternative) == 0x80, "Offset mismatch for UFortSoundCueTemplateDefaults::LicensedTrackAlternative");
static_assert(offsetof(UFortSoundCueTemplateDefaults, LicensedSubmix) == 0x88, "Offset mismatch for UFortSoundCueTemplateDefaults::LicensedSubmix");

// Size: 0x80 (Inherited: 0x58, Single: 0x28)
class UFortSoundCueTemplateDefaultSettings : public UDataAsset
{
public:
    TMap<UFortSoundCueTemplateDefaults*, UClass*> TemplateDefaults; // 0x30 (Size: 0x50, Type: MapProperty)

public:
    UFortSoundCueTemplateDefaults* GetSettingsForTemplateType(UClass*& TemplateType); // 0xfea3b00 (Index: 0x0, Flags: Final|Native|Public)
};

static_assert(sizeof(UFortSoundCueTemplateDefaultSettings) == 0x80, "Size mismatch for UFortSoundCueTemplateDefaultSettings");
static_assert(offsetof(UFortSoundCueTemplateDefaultSettings, TemplateDefaults) == 0x30, "Offset mismatch for UFortSoundCueTemplateDefaultSettings::TemplateDefaults");

// Size: 0x50 (Inherited: 0x58, Single: 0xfffffff8)
class UFortSoundCueTemplateSettings : public UDeveloperSettings
{
public:
    TSoftObjectPtr<UFortSoundCueTemplateDefaultSettings*> DefaultTemplateSettings; // 0x30 (Size: 0x20, Type: SoftObjectProperty)

public:
    UFortSoundCueTemplateDefaults* GetDefaultSettingsForTemplateType(UClass*& TemplateType) const; // 0xfea368c (Index: 0x0, Flags: Final|Native|Public|Const)
};

static_assert(sizeof(UFortSoundCueTemplateSettings) == 0x50, "Size mismatch for UFortSoundCueTemplateSettings");
static_assert(offsetof(UFortSoundCueTemplateSettings, DefaultTemplateSettings) == 0x30, "Offset mismatch for UFortSoundCueTemplateSettings::DefaultTemplateSettings");

// Size: 0x570 (Inherited: 0x11f0, Single: 0xfffff380)
class UFortSoundCueTemplateSimple : public UFortSoundCueTemplateBase
{
public:
};

static_assert(sizeof(UFortSoundCueTemplateSimple) == 0x570, "Size mismatch for UFortSoundCueTemplateSimple");

// Size: 0x1f0 (Inherited: 0xe8, Single: 0x108)
class UGliderThrustSCTDefaults : public UFortSoundCueTemplateDefaults
{
public:
    FGliderThrustData Forward; // 0x90 (Size: 0x58, Type: StructProperty)
    FGliderThrustData Sideways; // 0xe8 (Size: 0x58, Type: StructProperty)
    FGliderThrustData Backwards; // 0x140 (Size: 0x58, Type: StructProperty)
    FGliderThrustData AnyDirection; // 0x198 (Size: 0x58, Type: StructProperty)
};

static_assert(sizeof(UGliderThrustSCTDefaults) == 0x1f0, "Size mismatch for UGliderThrustSCTDefaults");
static_assert(offsetof(UGliderThrustSCTDefaults, Forward) == 0x90, "Offset mismatch for UGliderThrustSCTDefaults::Forward");
static_assert(offsetof(UGliderThrustSCTDefaults, Sideways) == 0xe8, "Offset mismatch for UGliderThrustSCTDefaults::Sideways");
static_assert(offsetof(UGliderThrustSCTDefaults, Backwards) == 0x140, "Offset mismatch for UGliderThrustSCTDefaults::Backwards");
static_assert(offsetof(UGliderThrustSCTDefaults, AnyDirection) == 0x198, "Offset mismatch for UGliderThrustSCTDefaults::AnyDirection");

// Size: 0x570 (Inherited: 0x11f0, Single: 0xfffff380)
class UGliderThrustLoop : public UFortSoundCueTemplateBase
{
public:
};

static_assert(sizeof(UGliderThrustLoop) == 0x570, "Size mismatch for UGliderThrustLoop");

// Size: 0x570 (Inherited: 0x11f0, Single: 0xfffff380)
class UGliderThrustStart : public UFortSoundCueTemplateBase
{
public:
};

static_assert(sizeof(UGliderThrustStart) == 0x570, "Size mismatch for UGliderThrustStart");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UGliderOpen : public UFortSoundCueTemplateSimple
{
public:
};

static_assert(sizeof(UGliderOpen) == 0x570, "Size mismatch for UGliderOpen");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UGliderClose : public UFortSoundCueTemplateSimple
{
public:
};

static_assert(sizeof(UGliderClose) == 0x570, "Size mismatch for UGliderClose");

// Size: 0x570 (Inherited: 0x11f0, Single: 0xfffff380)
class UMusicPack : public UFortSoundCueTemplateBase
{
public:
};

static_assert(sizeof(UMusicPack) == 0x570, "Size mismatch for UMusicPack");

// Size: 0x2d8 (Inherited: 0xe8, Single: 0x1f0)
class UPhysicsStateSCTDefaults : public UFortSoundCueTemplateDefaults
{
public:
    FName SpeedParameterName; // 0x90 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
    FPhysicsStateData Rolling; // 0x98 (Size: 0x90, Type: StructProperty)
    FPhysicsStateData Sliding; // 0x128 (Size: 0x90, Type: StructProperty)
    FPhysicsStateData Flying; // 0x1b8 (Size: 0x90, Type: StructProperty)
    FPhysicsStateData Floating; // 0x248 (Size: 0x90, Type: StructProperty)
};

static_assert(sizeof(UPhysicsStateSCTDefaults) == 0x2d8, "Size mismatch for UPhysicsStateSCTDefaults");
static_assert(offsetof(UPhysicsStateSCTDefaults, SpeedParameterName) == 0x90, "Offset mismatch for UPhysicsStateSCTDefaults::SpeedParameterName");
static_assert(offsetof(UPhysicsStateSCTDefaults, Rolling) == 0x98, "Offset mismatch for UPhysicsStateSCTDefaults::Rolling");
static_assert(offsetof(UPhysicsStateSCTDefaults, Sliding) == 0x128, "Offset mismatch for UPhysicsStateSCTDefaults::Sliding");
static_assert(offsetof(UPhysicsStateSCTDefaults, Flying) == 0x1b8, "Offset mismatch for UPhysicsStateSCTDefaults::Flying");
static_assert(offsetof(UPhysicsStateSCTDefaults, Floating) == 0x248, "Offset mismatch for UPhysicsStateSCTDefaults::Floating");

// Size: 0x570 (Inherited: 0x11f0, Single: 0xfffff380)
class UPhysicsStateLoop : public UFortSoundCueTemplateBase
{
public:
};

static_assert(sizeof(UPhysicsStateLoop) == 0x570, "Size mismatch for UPhysicsStateLoop");

// Size: 0x1a0 (Inherited: 0xe8, Single: 0xb8)
class UPhysicsImpactSCTDefaults : public UFortSoundCueTemplateDefaults
{
public:
    FName ImpactTypeParameterName; // 0x90 (Size: 0x4, Type: NameProperty)
    FName StrengthParameterName; // 0x94 (Size: 0x4, Type: NameProperty)
    FPhysicsImpactData Light; // 0x98 (Size: 0x58, Type: StructProperty)
    FPhysicsImpactData Medium; // 0xf0 (Size: 0x58, Type: StructProperty)
    FPhysicsImpactData Heavy; // 0x148 (Size: 0x58, Type: StructProperty)
};

static_assert(sizeof(UPhysicsImpactSCTDefaults) == 0x1a0, "Size mismatch for UPhysicsImpactSCTDefaults");
static_assert(offsetof(UPhysicsImpactSCTDefaults, ImpactTypeParameterName) == 0x90, "Offset mismatch for UPhysicsImpactSCTDefaults::ImpactTypeParameterName");
static_assert(offsetof(UPhysicsImpactSCTDefaults, StrengthParameterName) == 0x94, "Offset mismatch for UPhysicsImpactSCTDefaults::StrengthParameterName");
static_assert(offsetof(UPhysicsImpactSCTDefaults, Light) == 0x98, "Offset mismatch for UPhysicsImpactSCTDefaults::Light");
static_assert(offsetof(UPhysicsImpactSCTDefaults, Medium) == 0xf0, "Offset mismatch for UPhysicsImpactSCTDefaults::Medium");
static_assert(offsetof(UPhysicsImpactSCTDefaults, Heavy) == 0x148, "Offset mismatch for UPhysicsImpactSCTDefaults::Heavy");

// Size: 0x570 (Inherited: 0x11f0, Single: 0xfffff380)
class UPhysicsImpact : public UFortSoundCueTemplateBase
{
public:
};

static_assert(sizeof(UPhysicsImpact) == 0x570, "Size mismatch for UPhysicsImpact");

// Size: 0xb0 (Inherited: 0xe8, Single: 0xffffffc8)
class UPickaxeSCTDefaults : public UFortSoundCueTemplateDefaults
{
public:
    USoundAttenuation* CloseAttenuation; // 0x90 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* DistantAttenuation; // 0x98 (Size: 0x8, Type: ObjectProperty)
    TArray<USoundWave*> DistantVariations; // 0xa0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UPickaxeSCTDefaults) == 0xb0, "Size mismatch for UPickaxeSCTDefaults");
static_assert(offsetof(UPickaxeSCTDefaults, CloseAttenuation) == 0x90, "Offset mismatch for UPickaxeSCTDefaults::CloseAttenuation");
static_assert(offsetof(UPickaxeSCTDefaults, DistantAttenuation) == 0x98, "Offset mismatch for UPickaxeSCTDefaults::DistantAttenuation");
static_assert(offsetof(UPickaxeSCTDefaults, DistantVariations) == 0xa0, "Offset mismatch for UPickaxeSCTDefaults::DistantVariations");

// Size: 0x570 (Inherited: 0x11f0, Single: 0xfffff380)
class UPickaxeBase : public UFortSoundCueTemplateBase
{
public:
};

static_assert(sizeof(UPickaxeBase) == 0x570, "Size mismatch for UPickaxeBase");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UPickaxeSwing : public UPickaxeBase
{
public:
};

static_assert(sizeof(UPickaxeSwing) == 0x570, "Size mismatch for UPickaxeSwing");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UPickaxeReady : public UPickaxeBase
{
public:
};

static_assert(sizeof(UPickaxeReady) == 0x570, "Size mismatch for UPickaxeReady");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UPickaxeImpactEnemy : public UFortSoundCueTemplateSimple
{
public:
};

static_assert(sizeof(UPickaxeImpactEnemy) == 0x570, "Size mismatch for UPickaxeImpactEnemy");

// Size: 0xd8 (Inherited: 0xe8, Single: 0xfffffff0)
class UPlayerFoleyDefaults : public UFortSoundCueTemplateDefaults
{
public:
    USoundClass* LocalPlayerSoundClass; // 0x90 (Size: 0x8, Type: ObjectProperty)
    USoundClass* TeammateSoundClass; // 0x98 (Size: 0x8, Type: ObjectProperty)
    USoundClass* HostileSoundClass; // 0xa0 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* LocalPlayerAttenuation; // 0xa8 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* AboveAttenuation; // 0xb0 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* BelowAttenuation; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* ParallelAttenuation; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TArray<FDistanceDatum> ElevationCrossfadeDistances; // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UPlayerFoleyDefaults) == 0xd8, "Size mismatch for UPlayerFoleyDefaults");
static_assert(offsetof(UPlayerFoleyDefaults, LocalPlayerSoundClass) == 0x90, "Offset mismatch for UPlayerFoleyDefaults::LocalPlayerSoundClass");
static_assert(offsetof(UPlayerFoleyDefaults, TeammateSoundClass) == 0x98, "Offset mismatch for UPlayerFoleyDefaults::TeammateSoundClass");
static_assert(offsetof(UPlayerFoleyDefaults, HostileSoundClass) == 0xa0, "Offset mismatch for UPlayerFoleyDefaults::HostileSoundClass");
static_assert(offsetof(UPlayerFoleyDefaults, LocalPlayerAttenuation) == 0xa8, "Offset mismatch for UPlayerFoleyDefaults::LocalPlayerAttenuation");
static_assert(offsetof(UPlayerFoleyDefaults, AboveAttenuation) == 0xb0, "Offset mismatch for UPlayerFoleyDefaults::AboveAttenuation");
static_assert(offsetof(UPlayerFoleyDefaults, BelowAttenuation) == 0xb8, "Offset mismatch for UPlayerFoleyDefaults::BelowAttenuation");
static_assert(offsetof(UPlayerFoleyDefaults, ParallelAttenuation) == 0xc0, "Offset mismatch for UPlayerFoleyDefaults::ParallelAttenuation");
static_assert(offsetof(UPlayerFoleyDefaults, ElevationCrossfadeDistances) == 0xc8, "Offset mismatch for UPlayerFoleyDefaults::ElevationCrossfadeDistances");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UWeaponLowAmmo : public UFortSoundCueTemplateSimple
{
public:
};

static_assert(sizeof(UWeaponLowAmmo) == 0x570, "Size mismatch for UWeaponLowAmmo");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UWeaponOutOfAmmo : public UFortSoundCueTemplateSimple
{
public:
};

static_assert(sizeof(UWeaponOutOfAmmo) == 0x570, "Size mismatch for UWeaponOutOfAmmo");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UWeaponReloadStart : public UFortSoundCueTemplateSimple
{
public:
};

static_assert(sizeof(UWeaponReloadStart) == 0x570, "Size mismatch for UWeaponReloadStart");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UWeaponReloadInsert : public UFortSoundCueTemplateSimple
{
public:
};

static_assert(sizeof(UWeaponReloadInsert) == 0x570, "Size mismatch for UWeaponReloadInsert");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UWeaponReloadEnd : public UFortSoundCueTemplateSimple
{
public:
};

static_assert(sizeof(UWeaponReloadEnd) == 0x570, "Size mismatch for UWeaponReloadEnd");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UWeaponTargetingStart : public UFortSoundCueTemplateSimple
{
public:
};

static_assert(sizeof(UWeaponTargetingStart) == 0x570, "Size mismatch for UWeaponTargetingStart");

// Size: 0x570 (Inherited: 0x1760, Single: 0xffffee10)
class UWeaponTargetingEnd : public UFortSoundCueTemplateSimple
{
public:
};

static_assert(sizeof(UWeaponTargetingEnd) == 0x570, "Size mismatch for UWeaponTargetingEnd");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FFortContinuousModulatorConfig
{
    FVector2D VolumeRange; // 0x0 (Size: 0x10, Type: StructProperty)
    FVector2D PitchRange; // 0x10 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<ModulationParamMode> VolumeMode; // 0x20 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ModulationParamMode> PitchMode; // 0x21 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_22[0x6]; // 0x22 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FFortContinuousModulatorConfig) == 0x28, "Size mismatch for FFortContinuousModulatorConfig");
static_assert(offsetof(FFortContinuousModulatorConfig, VolumeRange) == 0x0, "Offset mismatch for FFortContinuousModulatorConfig::VolumeRange");
static_assert(offsetof(FFortContinuousModulatorConfig, PitchRange) == 0x10, "Offset mismatch for FFortContinuousModulatorConfig::PitchRange");
static_assert(offsetof(FFortContinuousModulatorConfig, VolumeMode) == 0x20, "Offset mismatch for FFortContinuousModulatorConfig::VolumeMode");
static_assert(offsetof(FFortContinuousModulatorConfig, PitchMode) == 0x21, "Offset mismatch for FFortContinuousModulatorConfig::PitchMode");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortSubmixPair
{
    USoundSubmixBase* Submix; // 0x0 (Size: 0x8, Type: ObjectProperty)
    float SendAmount; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortSubmixPair) == 0x10, "Size mismatch for FFortSubmixPair");
static_assert(offsetof(FFortSubmixPair, Submix) == 0x0, "Offset mismatch for FFortSubmixPair::Submix");
static_assert(offsetof(FFortSubmixPair, SendAmount) == 0x8, "Offset mismatch for FFortSubmixPair::SendAmount");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortBusPair
{
    USoundSourceBus* SourceBus; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UAudioBus* AudioBus; // 0x8 (Size: 0x8, Type: ObjectProperty)
    float SendAmount; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFortBusPair) == 0x18, "Size mismatch for FFortBusPair");
static_assert(offsetof(FFortBusPair, SourceBus) == 0x0, "Offset mismatch for FFortBusPair::SourceBus");
static_assert(offsetof(FFortBusPair, AudioBus) == 0x8, "Offset mismatch for FFortBusPair::AudioBus");
static_assert(offsetof(FFortBusPair, SendAmount) == 0x10, "Offset mismatch for FFortBusPair::SendAmount");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FGliderThrustData
{
    FName ParameterName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector2D PitchOutput; // 0x8 (Size: 0x10, Type: StructProperty)
    FVector2D VolumeOutput; // 0x18 (Size: 0x10, Type: StructProperty)
    USoundWave* Sound; // 0x28 (Size: 0x8, Type: ObjectProperty)
    FFortContinuousModulatorConfig Settings; // 0x30 (Size: 0x28, Type: StructProperty)
};

static_assert(sizeof(FGliderThrustData) == 0x58, "Size mismatch for FGliderThrustData");
static_assert(offsetof(FGliderThrustData, ParameterName) == 0x0, "Offset mismatch for FGliderThrustData::ParameterName");
static_assert(offsetof(FGliderThrustData, PitchOutput) == 0x8, "Offset mismatch for FGliderThrustData::PitchOutput");
static_assert(offsetof(FGliderThrustData, VolumeOutput) == 0x18, "Offset mismatch for FGliderThrustData::VolumeOutput");
static_assert(offsetof(FGliderThrustData, Sound) == 0x28, "Offset mismatch for FGliderThrustData::Sound");
static_assert(offsetof(FGliderThrustData, Settings) == 0x30, "Offset mismatch for FGliderThrustData::Settings");

// Size: 0x90 (Inherited: 0x0, Single: 0x90)
struct FPhysicsStateData
{
    FName ParameterName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector2D VolumeOutput; // 0x8 (Size: 0x10, Type: StructProperty)
    FVector2D PitchOutput; // 0x18 (Size: 0x10, Type: StructProperty)
    FFortContinuousModulatorConfig Settings; // 0x28 (Size: 0x28, Type: StructProperty)
    FDistanceDatum CrossfadeInputSlow; // 0x50 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_64[0x4]; // 0x64 (Size: 0x4, Type: PaddingProperty)
    USoundWave* SlowLoop; // 0x68 (Size: 0x8, Type: ObjectProperty)
    FDistanceDatum CrossfadeInputFast; // 0x70 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
    USoundWave* FastLoop; // 0x88 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FPhysicsStateData) == 0x90, "Size mismatch for FPhysicsStateData");
static_assert(offsetof(FPhysicsStateData, ParameterName) == 0x0, "Offset mismatch for FPhysicsStateData::ParameterName");
static_assert(offsetof(FPhysicsStateData, VolumeOutput) == 0x8, "Offset mismatch for FPhysicsStateData::VolumeOutput");
static_assert(offsetof(FPhysicsStateData, PitchOutput) == 0x18, "Offset mismatch for FPhysicsStateData::PitchOutput");
static_assert(offsetof(FPhysicsStateData, Settings) == 0x28, "Offset mismatch for FPhysicsStateData::Settings");
static_assert(offsetof(FPhysicsStateData, CrossfadeInputSlow) == 0x50, "Offset mismatch for FPhysicsStateData::CrossfadeInputSlow");
static_assert(offsetof(FPhysicsStateData, SlowLoop) == 0x68, "Offset mismatch for FPhysicsStateData::SlowLoop");
static_assert(offsetof(FPhysicsStateData, CrossfadeInputFast) == 0x70, "Offset mismatch for FPhysicsStateData::CrossfadeInputFast");
static_assert(offsetof(FPhysicsStateData, FastLoop) == 0x88, "Offset mismatch for FPhysicsStateData::FastLoop");

// Size: 0x58 (Inherited: 0x0, Single: 0x58)
struct FPhysicsImpactData
{
    FVector2D VolumeOutput; // 0x0 (Size: 0x10, Type: StructProperty)
    FVector2D PitchOutput; // 0x10 (Size: 0x10, Type: StructProperty)
    FFortContinuousModulatorConfig Settings; // 0x20 (Size: 0x28, Type: StructProperty)
    TArray<USoundWave*> Variations; // 0x48 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FPhysicsImpactData) == 0x58, "Size mismatch for FPhysicsImpactData");
static_assert(offsetof(FPhysicsImpactData, VolumeOutput) == 0x0, "Offset mismatch for FPhysicsImpactData::VolumeOutput");
static_assert(offsetof(FPhysicsImpactData, PitchOutput) == 0x10, "Offset mismatch for FPhysicsImpactData::PitchOutput");
static_assert(offsetof(FPhysicsImpactData, Settings) == 0x20, "Offset mismatch for FPhysicsImpactData::Settings");
static_assert(offsetof(FPhysicsImpactData, Variations) == 0x48, "Offset mismatch for FPhysicsImpactData::Variations");

