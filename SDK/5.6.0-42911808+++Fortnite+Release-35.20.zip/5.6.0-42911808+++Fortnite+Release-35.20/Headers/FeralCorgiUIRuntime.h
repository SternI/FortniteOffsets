/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FeralCorgiUIRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CommonUI.h"
#include "Engine.h"
#include "FortniteUI.h"

// Size: 0x430 (Inherited: 0xb38, Single: 0xfffff8f8)
class UFeralCorgiPurchaseModal : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x8]; // 0x408 (Size: 0x8, Type: PaddingProperty)
    UInputComponent* IntroModalInputComp; // 0x410 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle AcceptActionBinding; // 0x418 (Size: 0x10, Type: StructProperty)
    FPrimaryContentSetup PrimaryContentSetup; // 0x428 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_42c[0x4]; // 0x42c (Size: 0x4, Type: PaddingProperty)

protected:
    void HandleAcceptInput(); // 0x11ee13f8 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFeralCorgiPurchaseModal) == 0x430, "Size mismatch for UFeralCorgiPurchaseModal");
static_assert(offsetof(UFeralCorgiPurchaseModal, IntroModalInputComp) == 0x410, "Offset mismatch for UFeralCorgiPurchaseModal::IntroModalInputComp");
static_assert(offsetof(UFeralCorgiPurchaseModal, AcceptActionBinding) == 0x418, "Offset mismatch for UFeralCorgiPurchaseModal::AcceptActionBinding");
static_assert(offsetof(UFeralCorgiPurchaseModal, PrimaryContentSetup) == 0x428, "Offset mismatch for UFeralCorgiPurchaseModal::PrimaryContentSetup");

