/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserRow_NEW_VM
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DiscoveryBrowserUI.h"
#include "Rows.h"
#include "UMG.h"
#include "Engine.h"
#include "TabScreens.h"
#include "ActivityBrowserArrowButton.h"
#include "CommonUI.h"

// Size: 0x488 (Inherited: 0xf00, Single: 0xfffff588)
class UActivityBrowserRow_NEW_VM_C : public UFortActivityBrowserRowList
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x3f8 (Size: 0x8, Type: StructProperty)
    UWBP_Row_Header_C* WBP_Row_Header; // 0x400 (Size: 0x8, Type: ObjectProperty)
    UWBP_LoadingMorePages_C* WBP_LoadingMorePages; // 0x408 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* VBContent; // 0x410 (Size: 0x8, Type: ObjectProperty)
    UImage* InactiveOverlayDim; // 0x418 (Size: 0x8, Type: ObjectProperty)
    UCommonBorder* InactiveDarken; // 0x420 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowActiveInactiveAnim; // 0x428 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnPeek; // 0x430 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnLoadingMore; // 0x438 (Size: 0x8, Type: ObjectProperty)
    TArray<UActivityBrowserArrowButton_C*> ArrowButtons; // 0x440 (Size: 0x10, Type: ArrayProperty)
    FName FontHoverAnimateParam; // 0x450 (Size: 0x4, Type: NameProperty)
    FName FontPressedAnimateParam; // 0x454 (Size: 0x4, Type: NameProperty)
    bool IsWaitingForInactiveAnim; // 0x458 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_459[0x7]; // 0x459 (Size: 0x7, Type: PaddingProperty)
    double LoadingMoreDisplayDelay; // 0x460 (Size: 0x8, Type: DoubleProperty)
    bool IsLoadingMoreVisible; // 0x468 (Size: 0x1, Type: BoolProperty)
    bool IsLoadingMoreQueryActive; // 0x469 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_46a[0x6]; // 0x46a (Size: 0x6, Type: PaddingProperty)
    FTimerHandle LoadingMoreDelayTimer; // 0x470 (Size: 0x8, Type: StructProperty)
    FString RowPanelName; // 0x478 (Size: 0x10, Type: StrProperty)

public:
    virtual void OnQueryStatusChanged(bool& bIsActive); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    void UpdateVisibility(); // 0x288a61c (Index: 0x5, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateNewRow(bool& IsActive, bool& PlayAnimation); // 0x288a61c (Index: 0x6, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SnapToEndOfAnimation(UWidgetAnimation*& InAnimation, TEnumAsByte<EUMGSequencePlayMode>& PlayMode); // 0x288a61c (Index: 0x7, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ResetOnRowActiveInactiveAnimation(bool& IsRowActive); // 0x288a61c (Index: 0x8, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ResetOnPeekAnimation(); // 0x288a61c (Index: 0x9, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0xa, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Destruct(); // 0x288a61c (Index: 0xd, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void OnCategoryTextChanged(const FText CategoryText, const FText CategorySubtitle); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnRowIsActiveChanged(bool& const bIsActive); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowPeekStateChanged(bool& const bIsInPeekState); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCategoryItemChanged(bool& const bPlayAnimation, const FName CategoryPanelName); // 0x288a61c (Index: 0xc, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UActivityBrowserRow_NEW_VM_C) == 0x488, "Size mismatch for UActivityBrowserRow_NEW_VM_C");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, UberGraphFrame) == 0x3f8, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::UberGraphFrame");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, WBP_Row_Header) == 0x400, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::WBP_Row_Header");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, WBP_LoadingMorePages) == 0x408, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::WBP_LoadingMorePages");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, VBContent) == 0x410, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::VBContent");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, InactiveOverlayDim) == 0x418, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::InactiveOverlayDim");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, InactiveDarken) == 0x420, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::InactiveDarken");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, OnRowActiveInactiveAnim) == 0x428, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::OnRowActiveInactiveAnim");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, OnPeek) == 0x430, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::OnPeek");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, OnLoadingMore) == 0x438, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::OnLoadingMore");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, ArrowButtons) == 0x440, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::ArrowButtons");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, FontHoverAnimateParam) == 0x450, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::FontHoverAnimateParam");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, FontPressedAnimateParam) == 0x454, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::FontPressedAnimateParam");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, IsWaitingForInactiveAnim) == 0x458, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::IsWaitingForInactiveAnim");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, LoadingMoreDisplayDelay) == 0x460, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::LoadingMoreDisplayDelay");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, IsLoadingMoreVisible) == 0x468, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::IsLoadingMoreVisible");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, IsLoadingMoreQueryActive) == 0x469, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::IsLoadingMoreQueryActive");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, LoadingMoreDelayTimer) == 0x470, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::LoadingMoreDelayTimer");
static_assert(offsetof(UActivityBrowserRow_NEW_VM_C, RowPanelName) == 0x478, "Offset mismatch for UActivityBrowserRow_NEW_VM_C::RowPanelName");

