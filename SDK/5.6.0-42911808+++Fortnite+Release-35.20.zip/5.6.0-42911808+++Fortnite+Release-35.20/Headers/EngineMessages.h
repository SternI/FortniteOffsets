/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EngineMessages
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FEngineServicePing
{
};

static_assert(sizeof(FEngineServicePing) == 0x1, "Size mismatch for FEngineServicePing");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FEngineServicePong
{
    FString CurrentLevel; // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t EngineVersion; // 0x10 (Size: 0x4, Type: IntProperty)
    bool HasBegunPlay; // 0x14 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_15[0x3]; // 0x15 (Size: 0x3, Type: PaddingProperty)
    FGuid InstanceID; // 0x18 (Size: 0x10, Type: StructProperty)
    FString InstanceType; // 0x28 (Size: 0x10, Type: StrProperty)
    FGuid SessionId; // 0x38 (Size: 0x10, Type: StructProperty)
    float WorldTimeSeconds; // 0x48 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FEngineServicePong) == 0x50, "Size mismatch for FEngineServicePong");
static_assert(offsetof(FEngineServicePong, CurrentLevel) == 0x0, "Offset mismatch for FEngineServicePong::CurrentLevel");
static_assert(offsetof(FEngineServicePong, EngineVersion) == 0x10, "Offset mismatch for FEngineServicePong::EngineVersion");
static_assert(offsetof(FEngineServicePong, HasBegunPlay) == 0x14, "Offset mismatch for FEngineServicePong::HasBegunPlay");
static_assert(offsetof(FEngineServicePong, InstanceID) == 0x18, "Offset mismatch for FEngineServicePong::InstanceID");
static_assert(offsetof(FEngineServicePong, InstanceType) == 0x28, "Offset mismatch for FEngineServicePong::InstanceType");
static_assert(offsetof(FEngineServicePong, SessionId) == 0x38, "Offset mismatch for FEngineServicePong::SessionId");
static_assert(offsetof(FEngineServicePong, WorldTimeSeconds) == 0x48, "Offset mismatch for FEngineServicePong::WorldTimeSeconds");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FEngineServiceAuthDeny
{
    FString UserName; // 0x0 (Size: 0x10, Type: StrProperty)
    FString UserToDeny; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FEngineServiceAuthDeny) == 0x20, "Size mismatch for FEngineServiceAuthDeny");
static_assert(offsetof(FEngineServiceAuthDeny, UserName) == 0x0, "Offset mismatch for FEngineServiceAuthDeny::UserName");
static_assert(offsetof(FEngineServiceAuthDeny, UserToDeny) == 0x10, "Offset mismatch for FEngineServiceAuthDeny::UserToDeny");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FEngineServiceAuthGrant
{
    FString UserName; // 0x0 (Size: 0x10, Type: StrProperty)
    FString UserToGrant; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FEngineServiceAuthGrant) == 0x20, "Size mismatch for FEngineServiceAuthGrant");
static_assert(offsetof(FEngineServiceAuthGrant, UserName) == 0x0, "Offset mismatch for FEngineServiceAuthGrant::UserName");
static_assert(offsetof(FEngineServiceAuthGrant, UserToGrant) == 0x10, "Offset mismatch for FEngineServiceAuthGrant::UserToGrant");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FEngineServiceExecuteCommand
{
    FString Command; // 0x0 (Size: 0x10, Type: StrProperty)
    FString UserName; // 0x10 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FEngineServiceExecuteCommand) == 0x20, "Size mismatch for FEngineServiceExecuteCommand");
static_assert(offsetof(FEngineServiceExecuteCommand, Command) == 0x0, "Offset mismatch for FEngineServiceExecuteCommand::Command");
static_assert(offsetof(FEngineServiceExecuteCommand, UserName) == 0x10, "Offset mismatch for FEngineServiceExecuteCommand::UserName");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FEngineServiceTerminate
{
    FString UserName; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FEngineServiceTerminate) == 0x10, "Size mismatch for FEngineServiceTerminate");
static_assert(offsetof(FEngineServiceTerminate, UserName) == 0x0, "Offset mismatch for FEngineServiceTerminate::UserName");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FEngineServiceNotification
{
    FString Text; // 0x0 (Size: 0x10, Type: StrProperty)
    double TimeSeconds; // 0x10 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FEngineServiceNotification) == 0x18, "Size mismatch for FEngineServiceNotification");
static_assert(offsetof(FEngineServiceNotification, Text) == 0x0, "Offset mismatch for FEngineServiceNotification::Text");
static_assert(offsetof(FEngineServiceNotification, TimeSeconds) == 0x10, "Offset mismatch for FEngineServiceNotification::TimeSeconds");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FTraceControlStatusPing
{
};

static_assert(sizeof(FTraceControlStatusPing) == 0x1, "Size mismatch for FTraceControlStatusPing");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FTraceControlStatus
{
    FString Endpoint; // 0x0 (Size: 0x10, Type: StrProperty)
    FGuid SessionGuid; // 0x10 (Size: 0x10, Type: StructProperty)
    FGuid TraceGuid; // 0x20 (Size: 0x10, Type: StructProperty)
    uint64_t BytesSent; // 0x30 (Size: 0x8, Type: UInt64Property)
    uint64_t BytesTraced; // 0x38 (Size: 0x8, Type: UInt64Property)
    uint64_t MemoryUsed; // 0x40 (Size: 0x8, Type: UInt64Property)
    uint32_t CacheAllocated; // 0x48 (Size: 0x4, Type: UInt32Property)
    uint32_t CacheUsed; // 0x4c (Size: 0x4, Type: UInt32Property)
    uint32_t CacheWaste; // 0x50 (Size: 0x4, Type: UInt32Property)
    bool bAreStatNamedEventsEnabled; // 0x54 (Size: 0x1, Type: BoolProperty)
    bool bIsPaused; // 0x55 (Size: 0x1, Type: BoolProperty)
    bool bIsTracing; // 0x56 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_57[0x1]; // 0x57 (Size: 0x1, Type: PaddingProperty)
    FDateTime StatusTimestamp; // 0x58 (Size: 0x8, Type: StructProperty)
    char TraceSystemStatus; // 0x60 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_61[0x7]; // 0x61 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FTraceControlStatus) == 0x68, "Size mismatch for FTraceControlStatus");
static_assert(offsetof(FTraceControlStatus, Endpoint) == 0x0, "Offset mismatch for FTraceControlStatus::Endpoint");
static_assert(offsetof(FTraceControlStatus, SessionGuid) == 0x10, "Offset mismatch for FTraceControlStatus::SessionGuid");
static_assert(offsetof(FTraceControlStatus, TraceGuid) == 0x20, "Offset mismatch for FTraceControlStatus::TraceGuid");
static_assert(offsetof(FTraceControlStatus, BytesSent) == 0x30, "Offset mismatch for FTraceControlStatus::BytesSent");
static_assert(offsetof(FTraceControlStatus, BytesTraced) == 0x38, "Offset mismatch for FTraceControlStatus::BytesTraced");
static_assert(offsetof(FTraceControlStatus, MemoryUsed) == 0x40, "Offset mismatch for FTraceControlStatus::MemoryUsed");
static_assert(offsetof(FTraceControlStatus, CacheAllocated) == 0x48, "Offset mismatch for FTraceControlStatus::CacheAllocated");
static_assert(offsetof(FTraceControlStatus, CacheUsed) == 0x4c, "Offset mismatch for FTraceControlStatus::CacheUsed");
static_assert(offsetof(FTraceControlStatus, CacheWaste) == 0x50, "Offset mismatch for FTraceControlStatus::CacheWaste");
static_assert(offsetof(FTraceControlStatus, bAreStatNamedEventsEnabled) == 0x54, "Offset mismatch for FTraceControlStatus::bAreStatNamedEventsEnabled");
static_assert(offsetof(FTraceControlStatus, bIsPaused) == 0x55, "Offset mismatch for FTraceControlStatus::bIsPaused");
static_assert(offsetof(FTraceControlStatus, bIsTracing) == 0x56, "Offset mismatch for FTraceControlStatus::bIsTracing");
static_assert(offsetof(FTraceControlStatus, StatusTimestamp) == 0x58, "Offset mismatch for FTraceControlStatus::StatusTimestamp");
static_assert(offsetof(FTraceControlStatus, TraceSystemStatus) == 0x60, "Offset mismatch for FTraceControlStatus::TraceSystemStatus");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FTraceControlSettingsPing
{
};

static_assert(sizeof(FTraceControlSettingsPing) == 0x1, "Size mismatch for FTraceControlSettingsPing");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FTraceChannelPreset
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    FString ChannelList; // 0x10 (Size: 0x10, Type: StrProperty)
    bool bIsReadOnly; // 0x20 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FTraceChannelPreset) == 0x28, "Size mismatch for FTraceChannelPreset");
static_assert(offsetof(FTraceChannelPreset, Name) == 0x0, "Offset mismatch for FTraceChannelPreset::Name");
static_assert(offsetof(FTraceChannelPreset, ChannelList) == 0x10, "Offset mismatch for FTraceChannelPreset::ChannelList");
static_assert(offsetof(FTraceChannelPreset, bIsReadOnly) == 0x20, "Offset mismatch for FTraceChannelPreset::bIsReadOnly");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FTraceControlSettings
{
    bool bUseWorkerThread; // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bUseImportantCache; // 0x1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2[0x2]; // 0x2 (Size: 0x2, Type: PaddingProperty)
    uint32_t TailSizeBytes; // 0x4 (Size: 0x4, Type: UInt32Property)
    TArray<FTraceChannelPreset> ChannelPresets; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FTraceControlSettings) == 0x18, "Size mismatch for FTraceControlSettings");
static_assert(offsetof(FTraceControlSettings, bUseWorkerThread) == 0x0, "Offset mismatch for FTraceControlSettings::bUseWorkerThread");
static_assert(offsetof(FTraceControlSettings, bUseImportantCache) == 0x1, "Offset mismatch for FTraceControlSettings::bUseImportantCache");
static_assert(offsetof(FTraceControlSettings, TailSizeBytes) == 0x4, "Offset mismatch for FTraceControlSettings::TailSizeBytes");
static_assert(offsetof(FTraceControlSettings, ChannelPresets) == 0x8, "Offset mismatch for FTraceControlSettings::ChannelPresets");

// Size: 0x4 (Inherited: 0x0, Single: 0x4)
struct FTraceControlChannelsPing
{
    uint32_t KnownChannelCount; // 0x0 (Size: 0x4, Type: UInt32Property)
};

static_assert(sizeof(FTraceControlChannelsPing) == 0x4, "Size mismatch for FTraceControlChannelsPing");
static_assert(offsetof(FTraceControlChannelsPing, KnownChannelCount) == 0x0, "Offset mismatch for FTraceControlChannelsPing::KnownChannelCount");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FTraceControlChannelsDesc
{
    TArray<FString> Channels; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> Ids; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> Descriptions; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> ReadOnlyIds; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FTraceControlChannelsDesc) == 0x40, "Size mismatch for FTraceControlChannelsDesc");
static_assert(offsetof(FTraceControlChannelsDesc, Channels) == 0x0, "Offset mismatch for FTraceControlChannelsDesc::Channels");
static_assert(offsetof(FTraceControlChannelsDesc, Ids) == 0x10, "Offset mismatch for FTraceControlChannelsDesc::Ids");
static_assert(offsetof(FTraceControlChannelsDesc, Descriptions) == 0x20, "Offset mismatch for FTraceControlChannelsDesc::Descriptions");
static_assert(offsetof(FTraceControlChannelsDesc, ReadOnlyIds) == 0x30, "Offset mismatch for FTraceControlChannelsDesc::ReadOnlyIds");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FTraceControlChannelsStatus
{
    TArray<uint32_t> EnabledIds; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FTraceControlChannelsStatus) == 0x10, "Size mismatch for FTraceControlChannelsStatus");
static_assert(offsetof(FTraceControlChannelsStatus, EnabledIds) == 0x0, "Offset mismatch for FTraceControlChannelsStatus::EnabledIds");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FTraceControlChannelsSet
{
    TArray<uint32_t> ChannelIdsToEnable; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> ChannelIdsToDisable; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FTraceControlChannelsSet) == 0x20, "Size mismatch for FTraceControlChannelsSet");
static_assert(offsetof(FTraceControlChannelsSet, ChannelIdsToEnable) == 0x0, "Offset mismatch for FTraceControlChannelsSet::ChannelIdsToEnable");
static_assert(offsetof(FTraceControlChannelsSet, ChannelIdsToDisable) == 0x10, "Offset mismatch for FTraceControlChannelsSet::ChannelIdsToDisable");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FTraceControlDiscoveryPing
{
    FGuid SessionId; // 0x0 (Size: 0x10, Type: StructProperty)
    FGuid InstanceID; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FTraceControlDiscoveryPing) == 0x20, "Size mismatch for FTraceControlDiscoveryPing");
static_assert(offsetof(FTraceControlDiscoveryPing, SessionId) == 0x0, "Offset mismatch for FTraceControlDiscoveryPing::SessionId");
static_assert(offsetof(FTraceControlDiscoveryPing, InstanceID) == 0x10, "Offset mismatch for FTraceControlDiscoveryPing::InstanceID");

// Size: 0x88 (Inherited: 0x68, Single: 0x20)
struct FTraceControlDiscovery : FTraceControlStatus
{
    FGuid SessionId; // 0x68 (Size: 0x10, Type: StructProperty)
    FGuid InstanceID; // 0x78 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FTraceControlDiscovery) == 0x88, "Size mismatch for FTraceControlDiscovery");
static_assert(offsetof(FTraceControlDiscovery, SessionId) == 0x68, "Offset mismatch for FTraceControlDiscovery::SessionId");
static_assert(offsetof(FTraceControlDiscovery, InstanceID) == 0x78, "Offset mismatch for FTraceControlDiscovery::InstanceID");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FTraceControlStop
{
};

static_assert(sizeof(FTraceControlStop) == 0x1, "Size mismatch for FTraceControlStop");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FTraceControlStartCommon
{
    FString Channels; // 0x0 (Size: 0x10, Type: StrProperty)
    bool bExcludeTail; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FTraceControlStartCommon) == 0x18, "Size mismatch for FTraceControlStartCommon");
static_assert(offsetof(FTraceControlStartCommon, Channels) == 0x0, "Offset mismatch for FTraceControlStartCommon::Channels");
static_assert(offsetof(FTraceControlStartCommon, bExcludeTail) == 0x10, "Offset mismatch for FTraceControlStartCommon::bExcludeTail");

// Size: 0x28 (Inherited: 0x18, Single: 0x10)
struct FTraceControlSend : FTraceControlStartCommon
{
    FString Host; // 0x18 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FTraceControlSend) == 0x28, "Size mismatch for FTraceControlSend");
static_assert(offsetof(FTraceControlSend, Host) == 0x18, "Offset mismatch for FTraceControlSend::Host");

// Size: 0x30 (Inherited: 0x18, Single: 0x18)
struct FTraceControlFile : FTraceControlStartCommon
{
    FString File; // 0x18 (Size: 0x10, Type: StrProperty)
    bool bTruncateFile; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FTraceControlFile) == 0x30, "Size mismatch for FTraceControlFile");
static_assert(offsetof(FTraceControlFile, File) == 0x18, "Offset mismatch for FTraceControlFile::File");
static_assert(offsetof(FTraceControlFile, bTruncateFile) == 0x28, "Offset mismatch for FTraceControlFile::bTruncateFile");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FTraceControlPause
{
};

static_assert(sizeof(FTraceControlPause) == 0x1, "Size mismatch for FTraceControlPause");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FTraceControlResume
{
};

static_assert(sizeof(FTraceControlResume) == 0x1, "Size mismatch for FTraceControlResume");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FTraceControlSnapshotSend
{
    FString Host; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FTraceControlSnapshotSend) == 0x10, "Size mismatch for FTraceControlSnapshotSend");
static_assert(offsetof(FTraceControlSnapshotSend, Host) == 0x0, "Offset mismatch for FTraceControlSnapshotSend::Host");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FTraceControlSnapshotFile
{
    FString File; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FTraceControlSnapshotFile) == 0x10, "Size mismatch for FTraceControlSnapshotFile");
static_assert(offsetof(FTraceControlSnapshotFile, File) == 0x0, "Offset mismatch for FTraceControlSnapshotFile::File");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FTraceControlBookmark
{
    FString Label; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FTraceControlBookmark) == 0x10, "Size mismatch for FTraceControlBookmark");
static_assert(offsetof(FTraceControlBookmark, Label) == 0x0, "Offset mismatch for FTraceControlBookmark::Label");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FTraceControlScreenshot
{
    FString Name; // 0x0 (Size: 0x10, Type: StrProperty)
    bool bShowUI; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FTraceControlScreenshot) == 0x18, "Size mismatch for FTraceControlScreenshot");
static_assert(offsetof(FTraceControlScreenshot, Name) == 0x0, "Offset mismatch for FTraceControlScreenshot::Name");
static_assert(offsetof(FTraceControlScreenshot, bShowUI) == 0x10, "Offset mismatch for FTraceControlScreenshot::bShowUI");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FTraceControlSetStatNamedEvents
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FTraceControlSetStatNamedEvents) == 0x1, "Size mismatch for FTraceControlSetStatNamedEvents");
static_assert(offsetof(FTraceControlSetStatNamedEvents, bEnabled) == 0x0, "Offset mismatch for FTraceControlSetStatNamedEvents::bEnabled");

