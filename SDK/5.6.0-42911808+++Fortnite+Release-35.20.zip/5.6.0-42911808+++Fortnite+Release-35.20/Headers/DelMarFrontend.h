/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarFrontend
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "CoreUObject.h"
#include "GameFeatures.h"
#include "FortniteUI.h"
#include "CommonUI.h"
#include "ModelViewViewModel.h"
#include "UMG.h"
#include "Engine.h"
#include "DelMarCore.h"

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UDelMarFrontendCheatManager : public UChildCheatManager
{
public:

protected:
    void DelMarMarkTutorialPlayed(); // 0x554e3c4 (Index: 0x0, Flags: Final|Exec|Native|Protected)
    void DelMarResetNux(); // 0x554e3c4 (Index: 0x1, Flags: Final|Exec|Native|Protected)
};

static_assert(sizeof(UDelMarFrontendCheatManager) == 0x28, "Size mismatch for UDelMarFrontendCheatManager");

// Size: 0x188 (Inherited: 0x28, Single: 0x160)
class UDelMarFrontendExperienceFlow : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    AFortPlayerController* CachedPlayerController; // 0x30 (Size: 0x8, Type: ObjectProperty)
    TSoftClassPtr VideoPlayerClass; // 0x38 (Size: 0x20, Type: SoftClassProperty)
    UClass* ConfirmationWindowClass; // 0x58 (Size: 0x8, Type: ClassProperty)
    FText TutorialPromptTitle; // 0x60 (Size: 0x10, Type: TextProperty)
    FText TutorialPromptDescription; // 0x70 (Size: 0x10, Type: TextProperty)
    FText TutorialPromptConfirmButtonText; // 0x80 (Size: 0x10, Type: TextProperty)
    FText TutorialPromptDeclineButtonText; // 0x90 (Size: 0x10, Type: TextProperty)
    FText SpeedRunPromptTitle; // 0xa0 (Size: 0x10, Type: TextProperty)
    FText SpeedRunPromptDescription; // 0xb0 (Size: 0x10, Type: TextProperty)
    FText SpeedRunPromptConfirmButtonText; // 0xc0 (Size: 0x10, Type: TextProperty)
    FText SpeedRunPromptDeclineButtonText; // 0xd0 (Size: 0x10, Type: TextProperty)
    TWeakObjectPtr<UDelMarGameUserSettings*> DelMarUserSettings; // 0xe0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_e8[0x8]; // 0xe8 (Size: 0x8, Type: PaddingProperty)
    TMap<FString, FString> NUXTrailerRating; // 0xf0 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_140[0x48]; // 0x140 (Size: 0x48, Type: PaddingProperty)

protected:
    void FinishTrailerStep(); // 0x1216a974 (Index: 0x0, Flags: Final|Native|Protected)
    void HandleVideoTerminalError(EBaseMediaTerminalErrorReason& Reason); // 0x1216ad78 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarFrontendExperienceFlow) == 0x188, "Size mismatch for UDelMarFrontendExperienceFlow");
static_assert(offsetof(UDelMarFrontendExperienceFlow, CachedPlayerController) == 0x30, "Offset mismatch for UDelMarFrontendExperienceFlow::CachedPlayerController");
static_assert(offsetof(UDelMarFrontendExperienceFlow, VideoPlayerClass) == 0x38, "Offset mismatch for UDelMarFrontendExperienceFlow::VideoPlayerClass");
static_assert(offsetof(UDelMarFrontendExperienceFlow, ConfirmationWindowClass) == 0x58, "Offset mismatch for UDelMarFrontendExperienceFlow::ConfirmationWindowClass");
static_assert(offsetof(UDelMarFrontendExperienceFlow, TutorialPromptTitle) == 0x60, "Offset mismatch for UDelMarFrontendExperienceFlow::TutorialPromptTitle");
static_assert(offsetof(UDelMarFrontendExperienceFlow, TutorialPromptDescription) == 0x70, "Offset mismatch for UDelMarFrontendExperienceFlow::TutorialPromptDescription");
static_assert(offsetof(UDelMarFrontendExperienceFlow, TutorialPromptConfirmButtonText) == 0x80, "Offset mismatch for UDelMarFrontendExperienceFlow::TutorialPromptConfirmButtonText");
static_assert(offsetof(UDelMarFrontendExperienceFlow, TutorialPromptDeclineButtonText) == 0x90, "Offset mismatch for UDelMarFrontendExperienceFlow::TutorialPromptDeclineButtonText");
static_assert(offsetof(UDelMarFrontendExperienceFlow, SpeedRunPromptTitle) == 0xa0, "Offset mismatch for UDelMarFrontendExperienceFlow::SpeedRunPromptTitle");
static_assert(offsetof(UDelMarFrontendExperienceFlow, SpeedRunPromptDescription) == 0xb0, "Offset mismatch for UDelMarFrontendExperienceFlow::SpeedRunPromptDescription");
static_assert(offsetof(UDelMarFrontendExperienceFlow, SpeedRunPromptConfirmButtonText) == 0xc0, "Offset mismatch for UDelMarFrontendExperienceFlow::SpeedRunPromptConfirmButtonText");
static_assert(offsetof(UDelMarFrontendExperienceFlow, SpeedRunPromptDeclineButtonText) == 0xd0, "Offset mismatch for UDelMarFrontendExperienceFlow::SpeedRunPromptDeclineButtonText");
static_assert(offsetof(UDelMarFrontendExperienceFlow, DelMarUserSettings) == 0xe0, "Offset mismatch for UDelMarFrontendExperienceFlow::DelMarUserSettings");
static_assert(offsetof(UDelMarFrontendExperienceFlow, NUXTrailerRating) == 0xf0, "Offset mismatch for UDelMarFrontendExperienceFlow::NUXTrailerRating");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UDelMarGFA_OverrideFrontendIsland : public UGameFeatureAction
{
public:
    TWeakObjectPtr<UDelMarGameUserSettings*> DelMarUserSettings; // 0x28 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UDelMarGFA_OverrideFrontendIsland) == 0x30, "Size mismatch for UDelMarGFA_OverrideFrontendIsland");
static_assert(offsetof(UDelMarGFA_OverrideFrontendIsland, DelMarUserSettings) == 0x28, "Offset mismatch for UDelMarGFA_OverrideFrontendIsland::DelMarUserSettings");

// Size: 0x468 (Inherited: 0xf58, Single: 0xfffff510)
class UDelMarModeSetModificationModal : public UFortActivityModeSetSelectionModalBase
{
public:
    UClass* TrackSelectScreenClass; // 0x420 (Size: 0x8, Type: ClassProperty)
    UDelMarActivityVM* DelMarActivityVM; // 0x428 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_430[0x38]; // 0x430 (Size: 0x38, Type: PaddingProperty)

protected:
    void HandleBrowseTrackButtonClicked(); // 0x1216acfc (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleCloseButtonClicked(); // 0x58f6d9c (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnActivityViewModelInitialized(UDelMarActivityVM*& ViewModel); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UDelMarModeSetModificationModal) == 0x468, "Size mismatch for UDelMarModeSetModificationModal");
static_assert(offsetof(UDelMarModeSetModificationModal, TrackSelectScreenClass) == 0x420, "Offset mismatch for UDelMarModeSetModificationModal::TrackSelectScreenClass");
static_assert(offsetof(UDelMarModeSetModificationModal, DelMarActivityVM) == 0x428, "Offset mismatch for UDelMarModeSetModificationModal::DelMarActivityVM");

// Size: 0x5d0 (Inherited: 0x1530, Single: 0xfffff0a0)
class UDelMarModeSetPreviewModal : public UFortActivityDetailsModalBase
{
public:
    UDelMarActivityVM* DelMarActivityVM; // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_5a8[0x8]; // 0x5a8 (Size: 0x8, Type: PaddingProperty)
    UClass* RegularDetailsModalClass; // 0x5b0 (Size: 0x8, Type: ClassProperty)
    UClass* ActivityCreatorPageViewClass; // 0x5b8 (Size: 0x8, Type: ClassProperty)
    UClass* ActivityCampaignPurchaseScreenClass; // 0x5c0 (Size: 0x8, Type: ClassProperty)
    UClass* ActivityAttributionsClass; // 0x5c8 (Size: 0x8, Type: ClassProperty)

protected:
    void HandleBrowseTrackButtonClicked(); // 0x1216ad10 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleCloseButtonClicked(); // 0x1216ad10 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleConfirmButtonClicked(); // 0x1216ad50 (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleDetailsButtonClicked(); // 0x1216ad64 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnActivityViewModelInitialized(UDelMarActivityVM*& ViewModel); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UDelMarModeSetPreviewModal) == 0x5d0, "Size mismatch for UDelMarModeSetPreviewModal");
static_assert(offsetof(UDelMarModeSetPreviewModal, DelMarActivityVM) == 0x5a0, "Offset mismatch for UDelMarModeSetPreviewModal::DelMarActivityVM");
static_assert(offsetof(UDelMarModeSetPreviewModal, RegularDetailsModalClass) == 0x5b0, "Offset mismatch for UDelMarModeSetPreviewModal::RegularDetailsModalClass");
static_assert(offsetof(UDelMarModeSetPreviewModal, ActivityCreatorPageViewClass) == 0x5b8, "Offset mismatch for UDelMarModeSetPreviewModal::ActivityCreatorPageViewClass");
static_assert(offsetof(UDelMarModeSetPreviewModal, ActivityCampaignPurchaseScreenClass) == 0x5c0, "Offset mismatch for UDelMarModeSetPreviewModal::ActivityCampaignPurchaseScreenClass");
static_assert(offsetof(UDelMarModeSetPreviewModal, ActivityAttributionsClass) == 0x5c8, "Offset mismatch for UDelMarModeSetPreviewModal::ActivityAttributionsClass");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UDelMarRankedWidgetExtension : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    TSoftClassPtr RankInfoModalOverride; // 0x30 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(UDelMarRankedWidgetExtension) == 0x50, "Size mismatch for UDelMarRankedWidgetExtension");
static_assert(offsetof(UDelMarRankedWidgetExtension, RankInfoModalOverride) == 0x30, "Offset mismatch for UDelMarRankedWidgetExtension::RankInfoModalOverride");

// Size: 0x170 (Inherited: 0x1c8, Single: 0xffffffa8)
class UDelMarTrackSelectionViewModel : public UFortDiscoverSurfaceViewModel
{
public:
    UFortDiscoverPanelTreeViewModel* IndexPanelTree; // 0x138 (Size: 0x8, Type: ObjectProperty)
    UFortDiscoverProviderViewModel* FrontPagePanel; // 0x140 (Size: 0x8, Type: ObjectProperty)
    TArray<UFortDiscoverPanelTreeViewModel*> Categories; // 0x148 (Size: 0x10, Type: ArrayProperty)
    UFortDiscoverPanelTreeViewModel* SelectedCategory; // 0x158 (Size: 0x8, Type: ObjectProperty)
    TArray<UFortDiscoverPanelTreeViewModel*> CurrentSubCategories; // 0x160 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarTrackSelectionViewModel) == 0x170, "Size mismatch for UDelMarTrackSelectionViewModel");
static_assert(offsetof(UDelMarTrackSelectionViewModel, IndexPanelTree) == 0x138, "Offset mismatch for UDelMarTrackSelectionViewModel::IndexPanelTree");
static_assert(offsetof(UDelMarTrackSelectionViewModel, FrontPagePanel) == 0x140, "Offset mismatch for UDelMarTrackSelectionViewModel::FrontPagePanel");
static_assert(offsetof(UDelMarTrackSelectionViewModel, Categories) == 0x148, "Offset mismatch for UDelMarTrackSelectionViewModel::Categories");
static_assert(offsetof(UDelMarTrackSelectionViewModel, SelectedCategory) == 0x158, "Offset mismatch for UDelMarTrackSelectionViewModel::SelectedCategory");
static_assert(offsetof(UDelMarTrackSelectionViewModel, CurrentSubCategories) == 0x160, "Offset mismatch for UDelMarTrackSelectionViewModel::CurrentSubCategories");

// Size: 0x448 (Inherited: 0xf58, Single: 0xfffff4f0)
class UDelMarTrackSelectScreen : public UFortActivityModeSetSelectionModalBase
{
public:

protected:
    void HandleCloseButtonClicked(); // 0x1216ad24 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarTrackSelectScreen) == 0x448, "Size mismatch for UDelMarTrackSelectScreen");

// Size: 0x38 (Inherited: 0xb8, Single: 0xffffff80)
class UDelMarUserSettingsSubsystem : public UFortLocalPlayerSubsystem
{
public:
    UDelMarGameUserSettings* DelMarGameUserSettings; // 0x30 (Size: 0x8, Type: ObjectProperty)

public:
    static UDelMarGameUserSettings* GetDelMarGameUserSettings(ULocalPlayer*& const LocalPlayer); // 0x1216a9b8 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UDelMarUserSettingsSubsystem) == 0x38, "Size mismatch for UDelMarUserSettingsSubsystem");
static_assert(offsetof(UDelMarUserSettingsSubsystem, DelMarGameUserSettings) == 0x30, "Offset mismatch for UDelMarUserSettingsSubsystem::DelMarGameUserSettings");

// Size: 0xb0 (Inherited: 0x60, Single: 0x50)
class UDelMarFrontendRuntimeOptions : public URuntimeOptionsBase
{
public:
    FString FrontendNuxVideoKey; // 0x38 (Size: 0x10, Type: StrProperty)
    FName FrontendNuxVideoName; // 0x48 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    FString FrontendNuxVideoId; // 0x50 (Size: 0x10, Type: StrProperty)
    int32_t NuxVideoVersion; // 0x60 (Size: 0x4, Type: IntProperty)
    bool bAlwaysShowNuxVideo; // 0x64 (Size: 0x1, Type: BoolProperty)
    bool bDisableFrontendNuxFlow; // 0x65 (Size: 0x1, Type: BoolProperty)
    bool bDisableFrontendSpeedRunPrompt; // 0x66 (Size: 0x1, Type: BoolProperty)
    bool bFrontendSpeedRunPromptUsesTwoButtons; // 0x67 (Size: 0x1, Type: BoolProperty)
    FString DelMarTutorialLinkCode; // 0x68 (Size: 0x10, Type: StrProperty)
    FString DelMarSpeedRunLinkCode; // 0x78 (Size: 0x10, Type: StrProperty)
    FString DelMarDefaultLinkCode; // 0x88 (Size: 0x10, Type: StrProperty)
    bool bUseNewTrackSelectFlow; // 0x98 (Size: 0x1, Type: BoolProperty)
    bool bUseTrackSelectGrids; // 0x99 (Size: 0x1, Type: BoolProperty)
    bool bUsePreviewModal; // 0x9a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9b[0x5]; // 0x9b (Size: 0x5, Type: PaddingProperty)
    TArray<FString> DelMarNewLinkCodes; // 0xa0 (Size: 0x10, Type: ArrayProperty)

public:
    static UDelMarFrontendRuntimeOptions* GetDelMarFrontendRuntimeOptions(); // 0x1216a988 (Index: 0x0, Flags: Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure)
    bool IsNewTrack(FString& LinkCode); // 0x1216aea0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarFrontendRuntimeOptions) == 0xb0, "Size mismatch for UDelMarFrontendRuntimeOptions");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, FrontendNuxVideoKey) == 0x38, "Offset mismatch for UDelMarFrontendRuntimeOptions::FrontendNuxVideoKey");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, FrontendNuxVideoName) == 0x48, "Offset mismatch for UDelMarFrontendRuntimeOptions::FrontendNuxVideoName");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, FrontendNuxVideoId) == 0x50, "Offset mismatch for UDelMarFrontendRuntimeOptions::FrontendNuxVideoId");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, NuxVideoVersion) == 0x60, "Offset mismatch for UDelMarFrontendRuntimeOptions::NuxVideoVersion");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, bAlwaysShowNuxVideo) == 0x64, "Offset mismatch for UDelMarFrontendRuntimeOptions::bAlwaysShowNuxVideo");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, bDisableFrontendNuxFlow) == 0x65, "Offset mismatch for UDelMarFrontendRuntimeOptions::bDisableFrontendNuxFlow");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, bDisableFrontendSpeedRunPrompt) == 0x66, "Offset mismatch for UDelMarFrontendRuntimeOptions::bDisableFrontendSpeedRunPrompt");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, bFrontendSpeedRunPromptUsesTwoButtons) == 0x67, "Offset mismatch for UDelMarFrontendRuntimeOptions::bFrontendSpeedRunPromptUsesTwoButtons");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, DelMarTutorialLinkCode) == 0x68, "Offset mismatch for UDelMarFrontendRuntimeOptions::DelMarTutorialLinkCode");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, DelMarSpeedRunLinkCode) == 0x78, "Offset mismatch for UDelMarFrontendRuntimeOptions::DelMarSpeedRunLinkCode");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, DelMarDefaultLinkCode) == 0x88, "Offset mismatch for UDelMarFrontendRuntimeOptions::DelMarDefaultLinkCode");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, bUseNewTrackSelectFlow) == 0x98, "Offset mismatch for UDelMarFrontendRuntimeOptions::bUseNewTrackSelectFlow");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, bUseTrackSelectGrids) == 0x99, "Offset mismatch for UDelMarFrontendRuntimeOptions::bUseTrackSelectGrids");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, bUsePreviewModal) == 0x9a, "Offset mismatch for UDelMarFrontendRuntimeOptions::bUsePreviewModal");
static_assert(offsetof(UDelMarFrontendRuntimeOptions, DelMarNewLinkCodes) == 0xa0, "Offset mismatch for UDelMarFrontendRuntimeOptions::DelMarNewLinkCodes");

// Size: 0xb0 (Inherited: 0x90, Single: 0x20)
class UDelMarActivityVM : public UMVVMViewModelBase
{
public:
    TArray<FString> ProductModes; // 0x68 (Size: 0x10, Type: ArrayProperty)
    FString CurrentProductMode; // 0x78 (Size: 0x10, Type: StrProperty)
    UFortActivityViewModel* FortActivityVM; // 0x88 (Size: 0x8, Type: ObjectProperty)
    bool bActivitySupportsPrivateMatch; // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bIsPreviewModal; // 0x91 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_92[0x1e]; // 0x92 (Size: 0x1e, Type: PaddingProperty)

public:
    void SetCurrentProductMode(FString& SelectedProductMode); // 0x1216b1a0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarActivityVM) == 0xb0, "Size mismatch for UDelMarActivityVM");
static_assert(offsetof(UDelMarActivityVM, ProductModes) == 0x68, "Offset mismatch for UDelMarActivityVM::ProductModes");
static_assert(offsetof(UDelMarActivityVM, CurrentProductMode) == 0x78, "Offset mismatch for UDelMarActivityVM::CurrentProductMode");
static_assert(offsetof(UDelMarActivityVM, FortActivityVM) == 0x88, "Offset mismatch for UDelMarActivityVM::FortActivityVM");
static_assert(offsetof(UDelMarActivityVM, bActivitySupportsPrivateMatch) == 0x90, "Offset mismatch for UDelMarActivityVM::bActivitySupportsPrivateMatch");
static_assert(offsetof(UDelMarActivityVM, bIsPreviewModal) == 0x91, "Offset mismatch for UDelMarActivityVM::bIsPreviewModal");

