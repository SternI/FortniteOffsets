/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ActivityBrowserDiscoverItemRow_NEW_VM
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "DiscoveryBrowserUI.h"
#include "CommonUI.h"
#include "Rows.h"
#include "UMG.h"
#include "Engine.h"
#include "TabScreens.h"
#include "ActivityBrowserArrowButton.h"

// Size: 0x4e0 (Inherited: 0xf48, Single: 0xfffff598)
class UActivityBrowserDiscoverItemRow_NEW_VM_C : public UFortDiscoverItemBrowserRow
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x440 (Size: 0x8, Type: StructProperty)
    UWBP_Row_Header_C* WBP_Row_Header; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UWBP_LoadingMorePages_C* WBP_LoadingMorePages; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* VBContent; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UImage* InactiveOverlayDim; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UCommonBorder* InactiveDarken; // 0x468 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowActiveInactiveAnim; // 0x470 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowMoveUpOutOfViewAnim; // 0x478 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowMoveDownIntoView; // 0x480 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnPeek; // 0x488 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnLoadingMore; // 0x490 (Size: 0x8, Type: ObjectProperty)
    TArray<UActivityBrowserArrowButton_C*> ArrowButtons; // 0x498 (Size: 0x10, Type: ArrayProperty)
    FName FontHoverAnimateParam; // 0x4a8 (Size: 0x4, Type: NameProperty)
    FName FontPressedAnimateParam; // 0x4ac (Size: 0x4, Type: NameProperty)
    bool IsWaitingForInactiveAnim; // 0x4b0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4b1[0x7]; // 0x4b1 (Size: 0x7, Type: PaddingProperty)
    double LoadingMoreDisplayDelay; // 0x4b8 (Size: 0x8, Type: DoubleProperty)
    bool IsLoadingMoreVisible; // 0x4c0 (Size: 0x1, Type: BoolProperty)
    bool IsLoadingMoreQueryActive; // 0x4c1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4c2[0x6]; // 0x4c2 (Size: 0x6, Type: PaddingProperty)
    FTimerHandle LoadingMoreDelayTimer; // 0x4c8 (Size: 0x8, Type: StructProperty)
    FString RowPanelName; // 0x4d0 (Size: 0x10, Type: StrProperty)

public:
    virtual void Destruct(); // 0x288a61c (Index: 0x7, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x8, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    void UpdateVisibility(); // 0x288a61c (Index: 0xa, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateNewRow(bool& IsActive, bool& PlayAnimation); // 0x288a61c (Index: 0xb, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SnapToEndOfAnimation(UWidgetAnimation*& InAnimation, TEnumAsByte<EUMGSequencePlayMode>& PlayMode); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ResetOnRowActiveInactiveAnimation(bool& IsRowActive); // 0x288a61c (Index: 0xd, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ResetOnPeekAnimation(); // 0x288a61c (Index: 0xe, Flags: Public|BlueprintCallable|BlueprintEvent)

protected:
    virtual void OnCategoryTextChanged(const FText CategoryText, const FText CategorySubtitle); // 0x288a61c (Index: 0x0, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnCategoryItemChanged(bool& const bPlayAnimation, const FName CategoryPanelName); // 0x288a61c (Index: 0x1, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnRowPeekStateChanged(bool& const bIsInPeekState); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowMoveUp(bool& const bMovingOffscreen); // 0x288a61c (Index: 0x10, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowMoveDown(bool& const bMovingOffscreen); // 0x288a61c (Index: 0x11, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowIsActiveChanged(bool& const bIsActive); // 0x288a61c (Index: 0x12, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UActivityBrowserDiscoverItemRow_NEW_VM_C) == 0x4e0, "Size mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, UberGraphFrame) == 0x440, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::UberGraphFrame");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, WBP_Row_Header) == 0x448, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::WBP_Row_Header");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, WBP_LoadingMorePages) == 0x450, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::WBP_LoadingMorePages");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, VBContent) == 0x458, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::VBContent");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, InactiveOverlayDim) == 0x460, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::InactiveOverlayDim");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, InactiveDarken) == 0x468, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::InactiveDarken");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, OnRowActiveInactiveAnim) == 0x470, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::OnRowActiveInactiveAnim");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, OnRowMoveUpOutOfViewAnim) == 0x478, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::OnRowMoveUpOutOfViewAnim");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, OnRowMoveDownIntoView) == 0x480, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::OnRowMoveDownIntoView");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, OnPeek) == 0x488, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::OnPeek");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, OnLoadingMore) == 0x490, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::OnLoadingMore");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, ArrowButtons) == 0x498, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::ArrowButtons");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, FontHoverAnimateParam) == 0x4a8, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::FontHoverAnimateParam");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, FontPressedAnimateParam) == 0x4ac, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::FontPressedAnimateParam");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, IsWaitingForInactiveAnim) == 0x4b0, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::IsWaitingForInactiveAnim");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, LoadingMoreDisplayDelay) == 0x4b8, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::LoadingMoreDisplayDelay");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, IsLoadingMoreVisible) == 0x4c0, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::IsLoadingMoreVisible");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, IsLoadingMoreQueryActive) == 0x4c1, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::IsLoadingMoreQueryActive");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, LoadingMoreDelayTimer) == 0x4c8, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::LoadingMoreDelayTimer");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_NEW_VM_C, RowPanelName) == 0x4d0, "Offset mismatch for UActivityBrowserDiscoverItemRow_NEW_VM_C::RowPanelName");

// Size: 0x4c8 (Inherited: 0xf48, Single: 0xfffff580)
class UActivityBrowserDiscoverItemRow_C : public UFortDiscoverItemBrowserRow
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x440 (Size: 0x8, Type: StructProperty)
    UVerticalBox* VBContent; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* LoadingMoreTilesHB; // 0x450 (Size: 0x8, Type: ObjectProperty)
    UImage* InactiveOverlayDim; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UCommonBorder* InactiveDarken; // 0x460 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowActiveInactiveAnim; // 0x468 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowMoveUpOutOfViewAnim; // 0x470 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnRowMoveDownIntoView; // 0x478 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnPeek; // 0x480 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnLoadingMore; // 0x488 (Size: 0x8, Type: ObjectProperty)
    TArray<UActivityBrowserArrowButton_C*> ArrowButtons; // 0x490 (Size: 0x10, Type: ArrayProperty)
    FName FontHoverAnimateParam; // 0x4a0 (Size: 0x4, Type: NameProperty)
    FName FontPressedAnimateParam; // 0x4a4 (Size: 0x4, Type: NameProperty)
    bool IsWaitingForInactiveAnim; // 0x4a8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4a9[0x7]; // 0x4a9 (Size: 0x7, Type: PaddingProperty)
    double LoadingMoreDisplayDelay; // 0x4b0 (Size: 0x8, Type: DoubleProperty)
    bool IsLoadingMoreVisible; // 0x4b8 (Size: 0x1, Type: BoolProperty)
    bool IsLoadingMoreQueryActive; // 0x4b9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4ba[0x6]; // 0x4ba (Size: 0x6, Type: PaddingProperty)
    FTimerHandle LoadingMoreDelayTimer; // 0x4c0 (Size: 0x8, Type: StructProperty)

public:
    void UpdateNewRow(bool& IsActive, bool& PlayAnimation); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void SnapToEndOfAnimation(UWidgetAnimation*& InAnimation, TEnumAsByte<EUMGSequencePlayMode>& PlayMode); // 0x288a61c (Index: 0x1, Flags: Public|BlueprintCallable|BlueprintEvent)
    void Set_Font_Category_Size(); // 0x288a61c (Index: 0x2, Flags: Public|HasDefaults|BlueprintCallable|BlueprintEvent)
    void ResetOnRowActiveInactiveAnimation(bool& IsRowActive); // 0x288a61c (Index: 0x3, Flags: Public|BlueprintCallable|BlueprintEvent)
    void ResetOnPeekAnimation(); // 0x288a61c (Index: 0x4, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void Destruct(); // 0x288a61c (Index: 0xf, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)
    virtual void Construct(); // 0x288a61c (Index: 0x10, Flags: BlueprintCosmetic|Event|Public|BlueprintEvent)

protected:
    virtual void OnRowPeekStateChanged(bool& const bIsInPeekState); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowMoveUp(bool& const bMovingOffscreen); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowMoveDown(bool& const bMovingOffscreen); // 0x288a61c (Index: 0x7, Flags: Event|Protected|BlueprintEvent)
    virtual void OnRowIsActiveChanged(bool& const bIsActive); // 0x288a61c (Index: 0x8, Flags: Event|Protected|BlueprintEvent)
    virtual void OnCategoryItemChanged(bool& const bPlayAnimation, const FName CategoryPanelName); // 0x288a61c (Index: 0x11, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UActivityBrowserDiscoverItemRow_C) == 0x4c8, "Size mismatch for UActivityBrowserDiscoverItemRow_C");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, UberGraphFrame) == 0x440, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::UberGraphFrame");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, VBContent) == 0x448, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::VBContent");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, LoadingMoreTilesHB) == 0x450, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::LoadingMoreTilesHB");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, InactiveOverlayDim) == 0x458, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::InactiveOverlayDim");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, InactiveDarken) == 0x460, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::InactiveDarken");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, OnRowActiveInactiveAnim) == 0x468, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::OnRowActiveInactiveAnim");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, OnRowMoveUpOutOfViewAnim) == 0x470, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::OnRowMoveUpOutOfViewAnim");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, OnRowMoveDownIntoView) == 0x478, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::OnRowMoveDownIntoView");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, OnPeek) == 0x480, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::OnPeek");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, OnLoadingMore) == 0x488, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::OnLoadingMore");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, ArrowButtons) == 0x490, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::ArrowButtons");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, FontHoverAnimateParam) == 0x4a0, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::FontHoverAnimateParam");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, FontPressedAnimateParam) == 0x4a4, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::FontPressedAnimateParam");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, IsWaitingForInactiveAnim) == 0x4a8, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::IsWaitingForInactiveAnim");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, LoadingMoreDisplayDelay) == 0x4b0, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::LoadingMoreDisplayDelay");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, IsLoadingMoreVisible) == 0x4b8, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::IsLoadingMoreVisible");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, IsLoadingMoreQueryActive) == 0x4b9, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::IsLoadingMoreQueryActive");
static_assert(offsetof(UActivityBrowserDiscoverItemRow_C, LoadingMoreDelayTimer) == 0x4c0, "Offset mismatch for UActivityBrowserDiscoverItemRow_C::LoadingMoreDelayTimer");

