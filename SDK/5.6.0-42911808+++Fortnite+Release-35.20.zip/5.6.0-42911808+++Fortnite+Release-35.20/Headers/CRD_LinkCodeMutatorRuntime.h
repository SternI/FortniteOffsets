/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_LinkCodeMutatorRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0xc20 (Inherited: 0x45b0, Single: 0xffffc670)
class ALinkCodeMutatorDevice : public AFortCreativeDeviceProp
{
public:
    TArray<FString> MutatorsToApply; // 0xc10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(ALinkCodeMutatorDevice) == 0xc20, "Size mismatch for ALinkCodeMutatorDevice");
static_assert(offsetof(ALinkCodeMutatorDevice, MutatorsToApply) == 0xc10, "Offset mismatch for ALinkCodeMutatorDevice::MutatorsToApply");

