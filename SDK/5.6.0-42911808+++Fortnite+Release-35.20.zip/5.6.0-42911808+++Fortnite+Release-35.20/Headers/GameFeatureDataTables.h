/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameFeatureDataTables
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameFeatures.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "CoreUObject.h"

// Size: 0x50 (Inherited: 0x50, Single: 0x0)
class UGameFeatureAction_GameFeatureDataTables : public UGameFeatureAction
{
public:
    FGameplayTag GameFeatureDataTableID; // 0x28 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    FSoftObjectPath DataTable; // 0x30 (Size: 0x18, Type: StructProperty)
    bool bIsParentDataTable; // 0x48 (Size: 0x1, Type: BoolProperty)
    bool bAllowOnDedicatedServers; // 0x49 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_4a[0x6]; // 0x4a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeatureAction_GameFeatureDataTables) == 0x50, "Size mismatch for UGameFeatureAction_GameFeatureDataTables");
static_assert(offsetof(UGameFeatureAction_GameFeatureDataTables, GameFeatureDataTableID) == 0x28, "Offset mismatch for UGameFeatureAction_GameFeatureDataTables::GameFeatureDataTableID");
static_assert(offsetof(UGameFeatureAction_GameFeatureDataTables, DataTable) == 0x30, "Offset mismatch for UGameFeatureAction_GameFeatureDataTables::DataTable");
static_assert(offsetof(UGameFeatureAction_GameFeatureDataTables, bIsParentDataTable) == 0x48, "Offset mismatch for UGameFeatureAction_GameFeatureDataTables::bIsParentDataTable");
static_assert(offsetof(UGameFeatureAction_GameFeatureDataTables, bAllowOnDedicatedServers) == 0x49, "Offset mismatch for UGameFeatureAction_GameFeatureDataTables::bAllowOnDedicatedServers");

// Size: 0x80 (Inherited: 0xb8, Single: 0xffffffc8)
class UGameFeatureDataTablesSubsystem : public UEngineSubsystem
{
public:
    TMap<FGameFeatureDataTableEntry, FGameplayTag> DataTableEntryMap; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UGameFeatureDataTablesSubsystem) == 0x80, "Size mismatch for UGameFeatureDataTablesSubsystem");
static_assert(offsetof(UGameFeatureDataTablesSubsystem, DataTableEntryMap) == 0x30, "Offset mismatch for UGameFeatureDataTablesSubsystem::DataTableEntryMap");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FGameFeatureDataTableEntry
{
    TArray<UCompositeDataTable*> CompositeDataTables; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UDataTable*> ParentDataTables; // 0x10 (Size: 0x10, Type: ArrayProperty)
    UScriptStruct* StructType; // 0x20 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_28[0x20]; // 0x28 (Size: 0x20, Type: PaddingProperty)
};

static_assert(sizeof(FGameFeatureDataTableEntry) == 0x48, "Size mismatch for FGameFeatureDataTableEntry");
static_assert(offsetof(FGameFeatureDataTableEntry, CompositeDataTables) == 0x0, "Offset mismatch for FGameFeatureDataTableEntry::CompositeDataTables");
static_assert(offsetof(FGameFeatureDataTableEntry, ParentDataTables) == 0x10, "Offset mismatch for FGameFeatureDataTableEntry::ParentDataTables");
static_assert(offsetof(FGameFeatureDataTableEntry, StructType) == 0x20, "Offset mismatch for FGameFeatureDataTableEntry::StructType");

