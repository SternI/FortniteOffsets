/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FirePetalShrineGameplayRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "LagerRuntime.h"
#include "Engine.h"

// Size: 0x9e0 (Inherited: 0x13c8, Single: 0xfffff618)
class AFirePetalShrineBase : public ABuildingGameplayActor
{
public:

public:
    void ServerOnInteractRadar(AFortPlayerController*& FortPlayerController) const; // 0x11416e90 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|Const)
    void ServerOnSpritePickedUp(AFortPlayerController*& FortPlayerController) const; // 0x1141723c (Index: 0x1, Flags: Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|Const)
};

static_assert(sizeof(AFirePetalShrineBase) == 0x9e0, "Size mismatch for AFirePetalShrineBase");

// Size: 0x618 (Inherited: 0xe88, Single: 0xfffff790)
class AFirePetalShrineSpriteSpawner : public AFortAthenaLivingWorldVolume
{
public:
    uint8_t OnFinishedSpawning[0x10]; // 0x5f8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<TWeakObjectPtr<AActor*>> SpawnedActors; // 0x608 (Size: 0x10, Type: ArrayProperty)

public:
    TArray<AActor*> GetSpawnedActors(); // 0x11416e50 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void OnFinishedSpawning__DelegateSignature(bool& bSuccess); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
};

static_assert(sizeof(AFirePetalShrineSpriteSpawner) == 0x618, "Size mismatch for AFirePetalShrineSpriteSpawner");
static_assert(offsetof(AFirePetalShrineSpriteSpawner, OnFinishedSpawning) == 0x5f8, "Offset mismatch for AFirePetalShrineSpriteSpawner::OnFinishedSpawning");
static_assert(offsetof(AFirePetalShrineSpriteSpawner, SpawnedActors) == 0x608, "Offset mismatch for AFirePetalShrineSpriteSpawner::SpawnedActors");

