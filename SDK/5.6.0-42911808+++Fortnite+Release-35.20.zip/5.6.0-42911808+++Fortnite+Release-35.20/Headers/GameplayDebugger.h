/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayDebugger
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "DeveloperSettings.h"
#include "InputCore.h"

// Size: 0x360 (Inherited: 0x2d0, Single: 0x90)
class AGameplayDebuggerCategoryReplicator : public AActor
{
public:
    APlayerController* OwnerPC; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    bool bIsEnabled; // 0x2b0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b1[0x7]; // 0x2b1 (Size: 0x7, Type: PaddingProperty)
    FGameplayDebuggerNetPack ReplicatedData; // 0x2b8 (Size: 0x18, Type: StructProperty)
    FGameplayDebuggerDebugActor DebugActor; // 0x2d0 (Size: 0x10, Type: StructProperty)
    FGameplayDebuggerVisLogSync VisLogSync; // 0x2e0 (Size: 0x10, Type: StructProperty)
    UGameplayDebuggerRenderingComponent* RenderingComp; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2f8[0x68]; // 0x2f8 (Size: 0x68, Type: PaddingProperty)

protected:
    virtual void ClientDataPackPacket(FGameplayDebuggerDataPackRPCParams& const Params); // 0xaeaf068 (Index: 0x0, Flags: RequiredAPI|Net|NetReliableNative|Event|Protected|NetClient)
    void OnRep_ReplicatedData(); // 0xaeaf2ec (Index: 0x1, Flags: Final|RequiredAPI|Native|Protected)
    virtual void ServerResetViewPoint(); // 0xaeaf320 (Index: 0x2, Flags: RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerSendCategoryInputEvent(int32_t& CategoryID, int32_t& HandlerId); // 0xaeaf36c (Index: 0x3, Flags: RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerSendExtensionInputEvent(int32_t& ExtensionId, int32_t& HandlerId); // 0xaeaf5a0 (Index: 0x4, Flags: RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerSetCategoryEnabled(int32_t& CategoryID, bool& bEnable); // 0xaeaf7d4 (Index: 0x5, Flags: RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerSetDebugActor(AActor*& Actor, bool& bSelectInEditor); // 0xaeafa0c (Index: 0x6, Flags: RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerSetEnabled(bool& bEnable); // 0xaeafc48 (Index: 0x7, Flags: RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerSetViewPoint(FVector& const InViewLocation, FVector& const InViewDirection); // 0xaeafd9c (Index: 0x8, Flags: RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|HasDefaults|NetValidate)
};

static_assert(sizeof(AGameplayDebuggerCategoryReplicator) == 0x360, "Size mismatch for AGameplayDebuggerCategoryReplicator");
static_assert(offsetof(AGameplayDebuggerCategoryReplicator, OwnerPC) == 0x2a8, "Offset mismatch for AGameplayDebuggerCategoryReplicator::OwnerPC");
static_assert(offsetof(AGameplayDebuggerCategoryReplicator, bIsEnabled) == 0x2b0, "Offset mismatch for AGameplayDebuggerCategoryReplicator::bIsEnabled");
static_assert(offsetof(AGameplayDebuggerCategoryReplicator, ReplicatedData) == 0x2b8, "Offset mismatch for AGameplayDebuggerCategoryReplicator::ReplicatedData");
static_assert(offsetof(AGameplayDebuggerCategoryReplicator, DebugActor) == 0x2d0, "Offset mismatch for AGameplayDebuggerCategoryReplicator::DebugActor");
static_assert(offsetof(AGameplayDebuggerCategoryReplicator, VisLogSync) == 0x2e0, "Offset mismatch for AGameplayDebuggerCategoryReplicator::VisLogSync");
static_assert(offsetof(AGameplayDebuggerCategoryReplicator, RenderingComp) == 0x2f0, "Offset mismatch for AGameplayDebuggerCategoryReplicator::RenderingComp");

// Size: 0x258 (Inherited: 0x28, Single: 0x230)
class UGameplayDebuggerConfig : public UObject
{
public:
    FKey ActivationKey; // 0x28 (Size: 0x18, Type: StructProperty)
    FKey CategoryRowNextKey; // 0x40 (Size: 0x18, Type: StructProperty)
    FKey CategoryRowPrevKey; // 0x58 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot0; // 0x70 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot1; // 0x88 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot2; // 0xa0 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot3; // 0xb8 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot4; // 0xd0 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot5; // 0xe8 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot6; // 0x100 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot7; // 0x118 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot8; // 0x130 (Size: 0x18, Type: StructProperty)
    FKey CategorySlot9; // 0x148 (Size: 0x18, Type: StructProperty)
    float DebugCanvasPaddingLeft; // 0x160 (Size: 0x4, Type: FloatProperty)
    float DebugCanvasPaddingRight; // 0x164 (Size: 0x4, Type: FloatProperty)
    float DebugCanvasPaddingTop; // 0x168 (Size: 0x4, Type: FloatProperty)
    float DebugCanvasPaddingBottom; // 0x16c (Size: 0x4, Type: FloatProperty)
    bool bDebugCanvasEnableTextShadow; // 0x170 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_171[0x7]; // 0x171 (Size: 0x7, Type: PaddingProperty)
    TArray<FGameplayDebuggerCategoryConfig> Categories; // 0x178 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayDebuggerExtensionConfig> Extensions; // 0x188 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_198[0xc0]; // 0x198 (Size: 0xc0, Type: PaddingProperty)
};

static_assert(sizeof(UGameplayDebuggerConfig) == 0x258, "Size mismatch for UGameplayDebuggerConfig");
static_assert(offsetof(UGameplayDebuggerConfig, ActivationKey) == 0x28, "Offset mismatch for UGameplayDebuggerConfig::ActivationKey");
static_assert(offsetof(UGameplayDebuggerConfig, CategoryRowNextKey) == 0x40, "Offset mismatch for UGameplayDebuggerConfig::CategoryRowNextKey");
static_assert(offsetof(UGameplayDebuggerConfig, CategoryRowPrevKey) == 0x58, "Offset mismatch for UGameplayDebuggerConfig::CategoryRowPrevKey");
static_assert(offsetof(UGameplayDebuggerConfig, CategorySlot0) == 0x70, "Offset mismatch for UGameplayDebuggerConfig::CategorySlot0");
static_assert(offsetof(UGameplayDebuggerConfig, CategorySlot1) == 0x88, "Offset mismatch for UGameplayDebuggerConfig::CategorySlot1");
static_assert(offsetof(UGameplayDebuggerConfig, CategorySlot2) == 0xa0, "Offset mismatch for UGameplayDebuggerConfig::CategorySlot2");
static_assert(offsetof(UGameplayDebuggerConfig, CategorySlot3) == 0xb8, "Offset mismatch for UGameplayDebuggerConfig::CategorySlot3");
static_assert(offsetof(UGameplayDebuggerConfig, CategorySlot4) == 0xd0, "Offset mismatch for UGameplayDebuggerConfig::CategorySlot4");
static_assert(offsetof(UGameplayDebuggerConfig, CategorySlot5) == 0xe8, "Offset mismatch for UGameplayDebuggerConfig::CategorySlot5");
static_assert(offsetof(UGameplayDebuggerConfig, CategorySlot6) == 0x100, "Offset mismatch for UGameplayDebuggerConfig::CategorySlot6");
static_assert(offsetof(UGameplayDebuggerConfig, CategorySlot7) == 0x118, "Offset mismatch for UGameplayDebuggerConfig::CategorySlot7");
static_assert(offsetof(UGameplayDebuggerConfig, CategorySlot8) == 0x130, "Offset mismatch for UGameplayDebuggerConfig::CategorySlot8");
static_assert(offsetof(UGameplayDebuggerConfig, CategorySlot9) == 0x148, "Offset mismatch for UGameplayDebuggerConfig::CategorySlot9");
static_assert(offsetof(UGameplayDebuggerConfig, DebugCanvasPaddingLeft) == 0x160, "Offset mismatch for UGameplayDebuggerConfig::DebugCanvasPaddingLeft");
static_assert(offsetof(UGameplayDebuggerConfig, DebugCanvasPaddingRight) == 0x164, "Offset mismatch for UGameplayDebuggerConfig::DebugCanvasPaddingRight");
static_assert(offsetof(UGameplayDebuggerConfig, DebugCanvasPaddingTop) == 0x168, "Offset mismatch for UGameplayDebuggerConfig::DebugCanvasPaddingTop");
static_assert(offsetof(UGameplayDebuggerConfig, DebugCanvasPaddingBottom) == 0x16c, "Offset mismatch for UGameplayDebuggerConfig::DebugCanvasPaddingBottom");
static_assert(offsetof(UGameplayDebuggerConfig, bDebugCanvasEnableTextShadow) == 0x170, "Offset mismatch for UGameplayDebuggerConfig::bDebugCanvasEnableTextShadow");
static_assert(offsetof(UGameplayDebuggerConfig, Categories) == 0x178, "Offset mismatch for UGameplayDebuggerConfig::Categories");
static_assert(offsetof(UGameplayDebuggerConfig, Extensions) == 0x188, "Offset mismatch for UGameplayDebuggerConfig::Extensions");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UGameplayDebuggerUserSettings : public UDeveloperSettings
{
public:
    uint8_t bEnableGameplayDebuggerInEditor : 1; // 0x30:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x3]; // 0x31 (Size: 0x3, Type: PaddingProperty)
    float MaxViewDistance; // 0x34 (Size: 0x4, Type: FloatProperty)
    float MaxViewAngle; // 0x38 (Size: 0x4, Type: FloatProperty)
    int32_t FontSize; // 0x3c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(UGameplayDebuggerUserSettings) == 0x40, "Size mismatch for UGameplayDebuggerUserSettings");
static_assert(offsetof(UGameplayDebuggerUserSettings, bEnableGameplayDebuggerInEditor) == 0x30, "Offset mismatch for UGameplayDebuggerUserSettings::bEnableGameplayDebuggerInEditor");
static_assert(offsetof(UGameplayDebuggerUserSettings, MaxViewDistance) == 0x34, "Offset mismatch for UGameplayDebuggerUserSettings::MaxViewDistance");
static_assert(offsetof(UGameplayDebuggerUserSettings, MaxViewAngle) == 0x38, "Offset mismatch for UGameplayDebuggerUserSettings::MaxViewAngle");
static_assert(offsetof(UGameplayDebuggerUserSettings, FontSize) == 0x3c, "Offset mismatch for UGameplayDebuggerUserSettings::FontSize");

// Size: 0x88 (Inherited: 0x28, Single: 0x60)
class UGameplayDebuggerLocalController : public UObject
{
public:
    AGameplayDebuggerCategoryReplicator* CachedReplicator; // 0x28 (Size: 0x8, Type: ObjectProperty)
    AGameplayDebuggerPlayerManager* CachedPlayerManager; // 0x30 (Size: 0x8, Type: ObjectProperty)
    AActor* DebugActorCandidate; // 0x38 (Size: 0x8, Type: ObjectProperty)
    UFont* HUDFont; // 0x40 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_48[0x40]; // 0x48 (Size: 0x40, Type: PaddingProperty)
};

static_assert(sizeof(UGameplayDebuggerLocalController) == 0x88, "Size mismatch for UGameplayDebuggerLocalController");
static_assert(offsetof(UGameplayDebuggerLocalController, CachedReplicator) == 0x28, "Offset mismatch for UGameplayDebuggerLocalController::CachedReplicator");
static_assert(offsetof(UGameplayDebuggerLocalController, CachedPlayerManager) == 0x30, "Offset mismatch for UGameplayDebuggerLocalController::CachedPlayerManager");
static_assert(offsetof(UGameplayDebuggerLocalController, DebugActorCandidate) == 0x38, "Offset mismatch for UGameplayDebuggerLocalController::DebugActorCandidate");
static_assert(offsetof(UGameplayDebuggerLocalController, HUDFont) == 0x40, "Offset mismatch for UGameplayDebuggerLocalController::HUDFont");

// Size: 0x2d8 (Inherited: 0x2d0, Single: 0x8)
class AGameplayDebuggerPlayerManager : public AActor
{
public:
    uint8_t Pad_2a8[0x8]; // 0x2a8 (Size: 0x8, Type: PaddingProperty)
    TArray<FGameplayDebuggerPlayerData> PlayerData; // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    TArray<AGameplayDebuggerCategoryReplicator*> PendingRegistrations; // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_2d0[0x8]; // 0x2d0 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(AGameplayDebuggerPlayerManager) == 0x2d8, "Size mismatch for AGameplayDebuggerPlayerManager");
static_assert(offsetof(AGameplayDebuggerPlayerManager, PlayerData) == 0x2b0, "Offset mismatch for AGameplayDebuggerPlayerManager::PlayerData");
static_assert(offsetof(AGameplayDebuggerPlayerManager, PendingRegistrations) == 0x2c0, "Offset mismatch for AGameplayDebuggerPlayerManager::PendingRegistrations");

// Size: 0x5f0 (Inherited: 0xdc0, Single: 0xfffff830)
class UGameplayDebuggerRenderingComponent : public UDebugDrawComponent
{
public:
};

static_assert(sizeof(UGameplayDebuggerRenderingComponent) == 0x5f0, "Size mismatch for UGameplayDebuggerRenderingComponent");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameplayDebuggerDataPackRPCParams
{
    FName CategoryName; // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t DataPackIdx; // 0x4 (Size: 0x4, Type: IntProperty)
    FGameplayDebuggerDataPackHeader Header; // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<char> Data; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayDebuggerDataPackRPCParams) == 0x28, "Size mismatch for FGameplayDebuggerDataPackRPCParams");
static_assert(offsetof(FGameplayDebuggerDataPackRPCParams, CategoryName) == 0x0, "Offset mismatch for FGameplayDebuggerDataPackRPCParams::CategoryName");
static_assert(offsetof(FGameplayDebuggerDataPackRPCParams, DataPackIdx) == 0x4, "Offset mismatch for FGameplayDebuggerDataPackRPCParams::DataPackIdx");
static_assert(offsetof(FGameplayDebuggerDataPackRPCParams, Header) == 0x8, "Offset mismatch for FGameplayDebuggerDataPackRPCParams::Header");
static_assert(offsetof(FGameplayDebuggerDataPackRPCParams, Data) == 0x18, "Offset mismatch for FGameplayDebuggerDataPackRPCParams::Data");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayDebuggerDataPackHeader
{
    int16_t DataVersion; // 0x0 (Size: 0x2, Type: Int16Property)
    int16_t SyncCounter; // 0x2 (Size: 0x2, Type: Int16Property)
    int32_t DataSize; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t DataOffset; // 0x8 (Size: 0x4, Type: IntProperty)
    uint8_t bIsCompressed : 1; // 0xc:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayDebuggerDataPackHeader) == 0x10, "Size mismatch for FGameplayDebuggerDataPackHeader");
static_assert(offsetof(FGameplayDebuggerDataPackHeader, DataVersion) == 0x0, "Offset mismatch for FGameplayDebuggerDataPackHeader::DataVersion");
static_assert(offsetof(FGameplayDebuggerDataPackHeader, SyncCounter) == 0x2, "Offset mismatch for FGameplayDebuggerDataPackHeader::SyncCounter");
static_assert(offsetof(FGameplayDebuggerDataPackHeader, DataSize) == 0x4, "Offset mismatch for FGameplayDebuggerDataPackHeader::DataSize");
static_assert(offsetof(FGameplayDebuggerDataPackHeader, DataOffset) == 0x8, "Offset mismatch for FGameplayDebuggerDataPackHeader::DataOffset");
static_assert(offsetof(FGameplayDebuggerDataPackHeader, bIsCompressed) == 0xc, "Offset mismatch for FGameplayDebuggerDataPackHeader::bIsCompressed");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FGameplayDebuggerCategoryData
{
    FName CategoryName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FString> TextLines; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayDebuggerShape> Shapes; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayDebuggerDataPackHeader> DataPacks; // 0x28 (Size: 0x10, Type: ArrayProperty)
    bool bIsEnabled; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayDebuggerCategoryData) == 0x40, "Size mismatch for FGameplayDebuggerCategoryData");
static_assert(offsetof(FGameplayDebuggerCategoryData, CategoryName) == 0x0, "Offset mismatch for FGameplayDebuggerCategoryData::CategoryName");
static_assert(offsetof(FGameplayDebuggerCategoryData, TextLines) == 0x8, "Offset mismatch for FGameplayDebuggerCategoryData::TextLines");
static_assert(offsetof(FGameplayDebuggerCategoryData, Shapes) == 0x18, "Offset mismatch for FGameplayDebuggerCategoryData::Shapes");
static_assert(offsetof(FGameplayDebuggerCategoryData, DataPacks) == 0x28, "Offset mismatch for FGameplayDebuggerCategoryData::DataPacks");
static_assert(offsetof(FGameplayDebuggerCategoryData, bIsEnabled) == 0x38, "Offset mismatch for FGameplayDebuggerCategoryData::bIsEnabled");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameplayDebuggerShape
{
    TArray<FVector> ShapeData; // 0x0 (Size: 0x10, Type: ArrayProperty)
    FString Description; // 0x10 (Size: 0x10, Type: StrProperty)
    FColor Color; // 0x20 (Size: 0x4, Type: StructProperty)
    uint8_t Type; // 0x24 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_25[0x3]; // 0x25 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayDebuggerShape) == 0x28, "Size mismatch for FGameplayDebuggerShape");
static_assert(offsetof(FGameplayDebuggerShape, ShapeData) == 0x0, "Offset mismatch for FGameplayDebuggerShape::ShapeData");
static_assert(offsetof(FGameplayDebuggerShape, Description) == 0x10, "Offset mismatch for FGameplayDebuggerShape::Description");
static_assert(offsetof(FGameplayDebuggerShape, Color) == 0x20, "Offset mismatch for FGameplayDebuggerShape::Color");
static_assert(offsetof(FGameplayDebuggerShape, Type) == 0x24, "Offset mismatch for FGameplayDebuggerShape::Type");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameplayDebuggerNetPack
{
    AGameplayDebuggerCategoryReplicator* Owner; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayDebuggerCategoryData> SavedData; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayDebuggerNetPack) == 0x18, "Size mismatch for FGameplayDebuggerNetPack");
static_assert(offsetof(FGameplayDebuggerNetPack, Owner) == 0x0, "Offset mismatch for FGameplayDebuggerNetPack::Owner");
static_assert(offsetof(FGameplayDebuggerNetPack, SavedData) == 0x8, "Offset mismatch for FGameplayDebuggerNetPack::SavedData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayDebuggerDebugActor
{
    TWeakObjectPtr<AActor*> Actor; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    FName ActorName; // 0x8 (Size: 0x4, Type: NameProperty)
    int16_t SyncCounter; // 0xc (Size: 0x2, Type: Int16Property)
    uint8_t Pad_e[0x2]; // 0xe (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayDebuggerDebugActor) == 0x10, "Size mismatch for FGameplayDebuggerDebugActor");
static_assert(offsetof(FGameplayDebuggerDebugActor, Actor) == 0x0, "Offset mismatch for FGameplayDebuggerDebugActor::Actor");
static_assert(offsetof(FGameplayDebuggerDebugActor, ActorName) == 0x8, "Offset mismatch for FGameplayDebuggerDebugActor::ActorName");
static_assert(offsetof(FGameplayDebuggerDebugActor, SyncCounter) == 0xc, "Offset mismatch for FGameplayDebuggerDebugActor::SyncCounter");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayDebuggerVisLogSync
{
    FString DeviceIDs; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FGameplayDebuggerVisLogSync) == 0x10, "Size mismatch for FGameplayDebuggerVisLogSync");
static_assert(offsetof(FGameplayDebuggerVisLogSync, DeviceIDs) == 0x0, "Offset mismatch for FGameplayDebuggerVisLogSync::DeviceIDs");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FGameplayDebuggerInputConfig
{
    FString ConfigName; // 0x0 (Size: 0x10, Type: StrProperty)
    FKey Key; // 0x10 (Size: 0x18, Type: StructProperty)
    uint8_t bModShift : 1; // 0x28:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bModCtrl : 1; // 0x28:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bModAlt : 1; // 0x28:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bModCmd : 1; // 0x28:3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayDebuggerInputConfig) == 0x30, "Size mismatch for FGameplayDebuggerInputConfig");
static_assert(offsetof(FGameplayDebuggerInputConfig, ConfigName) == 0x0, "Offset mismatch for FGameplayDebuggerInputConfig::ConfigName");
static_assert(offsetof(FGameplayDebuggerInputConfig, Key) == 0x10, "Offset mismatch for FGameplayDebuggerInputConfig::Key");
static_assert(offsetof(FGameplayDebuggerInputConfig, bModShift) == 0x28, "Offset mismatch for FGameplayDebuggerInputConfig::bModShift");
static_assert(offsetof(FGameplayDebuggerInputConfig, bModCtrl) == 0x28, "Offset mismatch for FGameplayDebuggerInputConfig::bModCtrl");
static_assert(offsetof(FGameplayDebuggerInputConfig, bModAlt) == 0x28, "Offset mismatch for FGameplayDebuggerInputConfig::bModAlt");
static_assert(offsetof(FGameplayDebuggerInputConfig, bModCmd) == 0x28, "Offset mismatch for FGameplayDebuggerInputConfig::bModCmd");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FGameplayDebuggerCategoryConfig
{
    FString CategoryName; // 0x0 (Size: 0x10, Type: StrProperty)
    int32_t SlotIdx; // 0x10 (Size: 0x4, Type: IntProperty)
    uint8_t ActiveInGame; // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t ActiveInSimulate; // 0x15 (Size: 0x1, Type: EnumProperty)
    uint8_t Hidden; // 0x16 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_17[0x1]; // 0x17 (Size: 0x1, Type: PaddingProperty)
    uint8_t bOverrideSlotIdx : 1; // 0x18:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
    TArray<FGameplayDebuggerInputConfig> InputHandlers; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayDebuggerCategoryConfig) == 0x30, "Size mismatch for FGameplayDebuggerCategoryConfig");
static_assert(offsetof(FGameplayDebuggerCategoryConfig, CategoryName) == 0x0, "Offset mismatch for FGameplayDebuggerCategoryConfig::CategoryName");
static_assert(offsetof(FGameplayDebuggerCategoryConfig, SlotIdx) == 0x10, "Offset mismatch for FGameplayDebuggerCategoryConfig::SlotIdx");
static_assert(offsetof(FGameplayDebuggerCategoryConfig, ActiveInGame) == 0x14, "Offset mismatch for FGameplayDebuggerCategoryConfig::ActiveInGame");
static_assert(offsetof(FGameplayDebuggerCategoryConfig, ActiveInSimulate) == 0x15, "Offset mismatch for FGameplayDebuggerCategoryConfig::ActiveInSimulate");
static_assert(offsetof(FGameplayDebuggerCategoryConfig, Hidden) == 0x16, "Offset mismatch for FGameplayDebuggerCategoryConfig::Hidden");
static_assert(offsetof(FGameplayDebuggerCategoryConfig, bOverrideSlotIdx) == 0x18, "Offset mismatch for FGameplayDebuggerCategoryConfig::bOverrideSlotIdx");
static_assert(offsetof(FGameplayDebuggerCategoryConfig, InputHandlers) == 0x20, "Offset mismatch for FGameplayDebuggerCategoryConfig::InputHandlers");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameplayDebuggerExtensionConfig
{
    FString ExtensionName; // 0x0 (Size: 0x10, Type: StrProperty)
    uint8_t UseExtension; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    TArray<FGameplayDebuggerInputConfig> InputHandlers; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayDebuggerExtensionConfig) == 0x28, "Size mismatch for FGameplayDebuggerExtensionConfig");
static_assert(offsetof(FGameplayDebuggerExtensionConfig, ExtensionName) == 0x0, "Offset mismatch for FGameplayDebuggerExtensionConfig::ExtensionName");
static_assert(offsetof(FGameplayDebuggerExtensionConfig, UseExtension) == 0x10, "Offset mismatch for FGameplayDebuggerExtensionConfig::UseExtension");
static_assert(offsetof(FGameplayDebuggerExtensionConfig, InputHandlers) == 0x18, "Offset mismatch for FGameplayDebuggerExtensionConfig::InputHandlers");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameplayDebuggerPlayerData
{
    UGameplayDebuggerLocalController* Controller; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UInputComponent* InputComponent; // 0x8 (Size: 0x8, Type: ObjectProperty)
    AGameplayDebuggerCategoryReplicator* Replicator; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FGameplayDebuggerPlayerData) == 0x18, "Size mismatch for FGameplayDebuggerPlayerData");
static_assert(offsetof(FGameplayDebuggerPlayerData, Controller) == 0x0, "Offset mismatch for FGameplayDebuggerPlayerData::Controller");
static_assert(offsetof(FGameplayDebuggerPlayerData, InputComponent) == 0x8, "Offset mismatch for FGameplayDebuggerPlayerData::InputComponent");
static_assert(offsetof(FGameplayDebuggerPlayerData, Replicator) == 0x10, "Offset mismatch for FGameplayDebuggerPlayerData::Replicator");

