/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeEmporiumUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CommonUI.h"
#include "UMG.h"
#include "CoreUObject.h"
#include "FortniteUI.h"
#include "FortniteGame.h"
#include "ItemizationCoreRuntime.h"
#include "Engine.h"
#include "SlateCore.h"
#include "InputCore.h"

// Size: 0x1510 (Inherited: 0x1bd0, Single: 0xfffff940)
class UEmporiumBrowserFilterEntry : public UCommonButtonBase
{
public:
    uint8_t OnFilterEnabled[0x10]; // 0x14a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFilterSelected[0x10]; // 0x14b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFilterHovered[0x10]; // 0x14c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnWidgetDestroyed[0x10]; // 0x14d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UCommonTextBlock* TextBlock_FilterName; // 0x14e0 (Size: 0x8, Type: ObjectProperty)
    bool bFilterActive; // 0x14e8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_14e9[0x7]; // 0x14e9 (Size: 0x7, Type: PaddingProperty)
    UEmporiumBrowserTag* Tag; // 0x14f0 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText; // 0x14f8 (Size: 0x10, Type: TextProperty)
    uint8_t Pad_1508[0x8]; // 0x1508 (Size: 0x8, Type: PaddingProperty)

public:
    bool IsFilterActive() const; // 0x11ed2f60 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetIsFilterActive(bool& bInFilterActive); // 0x11ed42e0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateButtonText(); // 0x11ed55fc (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    virtual void UpdateCheckMarkState(bool& bIsChecked); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void UpdateItemCount(int32_t& ItemCount); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UEmporiumBrowserFilterEntry) == 0x1510, "Size mismatch for UEmporiumBrowserFilterEntry");
static_assert(offsetof(UEmporiumBrowserFilterEntry, OnFilterEnabled) == 0x14a0, "Offset mismatch for UEmporiumBrowserFilterEntry::OnFilterEnabled");
static_assert(offsetof(UEmporiumBrowserFilterEntry, OnFilterSelected) == 0x14b0, "Offset mismatch for UEmporiumBrowserFilterEntry::OnFilterSelected");
static_assert(offsetof(UEmporiumBrowserFilterEntry, OnFilterHovered) == 0x14c0, "Offset mismatch for UEmporiumBrowserFilterEntry::OnFilterHovered");
static_assert(offsetof(UEmporiumBrowserFilterEntry, OnWidgetDestroyed) == 0x14d0, "Offset mismatch for UEmporiumBrowserFilterEntry::OnWidgetDestroyed");
static_assert(offsetof(UEmporiumBrowserFilterEntry, TextBlock_FilterName) == 0x14e0, "Offset mismatch for UEmporiumBrowserFilterEntry::TextBlock_FilterName");
static_assert(offsetof(UEmporiumBrowserFilterEntry, bFilterActive) == 0x14e8, "Offset mismatch for UEmporiumBrowserFilterEntry::bFilterActive");
static_assert(offsetof(UEmporiumBrowserFilterEntry, Tag) == 0x14f0, "Offset mismatch for UEmporiumBrowserFilterEntry::Tag");
static_assert(offsetof(UEmporiumBrowserFilterEntry, ButtonText) == 0x14f8, "Offset mismatch for UEmporiumBrowserFilterEntry::ButtonText");

// Size: 0x560 (Inherited: 0x730, Single: 0xfffffe30)
class UEmporiumBrowserFiltersPanel : public UCommonUserWidget
{
public:
    uint8_t OnFilterChanged[0x10]; // 0x2d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSortChanged[0x10]; // 0x2e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSortPanelToggled[0x10]; // 0x2f8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFocusChanged[0x10]; // 0x308 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCategoryActivated[0x10]; // 0x318 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCategoryFocused[0x10]; // 0x328 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_338[0x18]; // 0x338 (Size: 0x18, Type: PaddingProperty)
    uint8_t OnUpdateCategoryCounts[0x10]; // 0x350 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_360[0x88]; // 0x360 (Size: 0x88, Type: PaddingProperty)
    UClass* FilterSectionHeaderWidgetClass; // 0x3e8 (Size: 0x8, Type: ClassProperty)
    UClass* FilterCategoryHeaderWidgetClass; // 0x3f0 (Size: 0x8, Type: ClassProperty)
    UClass* FilterHomeHeaderWidgetClass; // 0x3f8 (Size: 0x8, Type: ClassProperty)
    UClass* FilterEntryWidgetClass; // 0x400 (Size: 0x8, Type: ClassProperty)
    TArray<FFortEmporiumSortEntry> SortEntries; // 0x408 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortEmporiumFilterEntry> FilterEntries; // 0x418 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortEmporiumPriceFilterEntry> PriceFilterEntries; // 0x428 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> LicenseFilterEntries; // 0x438 (Size: 0x10, Type: ArrayProperty)
    FName DefaultCategoryFilter; // 0x448 (Size: 0x4, Type: NameProperty)
    uint8_t DefaultTagFilterMode; // 0x44c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_44d[0x53]; // 0x44d (Size: 0x53, Type: PaddingProperty)
    UCommonButtonBase* Button_SortAndFilter; // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_4a8[0x38]; // 0x4a8 (Size: 0x38, Type: PaddingProperty)
    TWeakObjectPtr<UFortCreativeContentBrowserTabPanelBase*> LastSelectedTab; // 0x4e0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_4e8[0x78]; // 0x4e8 (Size: 0x78, Type: PaddingProperty)

public:
    void CategoryActivatedDelegate__DelegateSignature(FName& CategoryID); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    void CategoryFocusedDelegate__DelegateSignature(FName& CategoryID); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
    void ExcludeItemDetailTag(const FName TagID); // 0x11ece590 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void FilterChangedDelegate__DelegateSignature(); // 0x288a61c (Index: 0x3, Flags: MulticastDelegate|Public|Delegate)
    void FilterUpdateCategoryCountsDelegate__DelegateSignature(); // 0x288a61c (Index: 0x4, Flags: MulticastDelegate|Public|Delegate)
    void FocusChangedDelegate__DelegateSignature(bool& bIsFocused); // 0x288a61c (Index: 0x5, Flags: MulticastDelegate|Public|Delegate)
    int32_t GetFilterCount() const; // 0x11ecf640 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetHomeSectionID() const; // 0x11ecf718 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetIncludedTags() const; // 0x11ecf730 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetItemDetailTags() const; // 0x11ecf74c (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumFilterSectionWidgets() const; // 0xf3f5b98 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void HandleFilterEnabled(bool& bIsFilterEnabled, UObject*& ListItemObject); // 0x11ed0400 (Index: 0x10, Flags: Final|Native|Public)
    void HandleShowAllEnabled(bool& bShowAllItems, UObject*& ListItemObject); // 0x11ed1f68 (Index: 0x12, Flags: Final|Native|Public)
    void IncludeItemDetailTag(const FName TagID); // 0x11ed2d18 (Index: 0x14, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool IsInFocusPath() const; // 0x11ed2f78 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsShowingCategoryModal() const; // 0x11ed2f90 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ResetSearch(); // 0x11ed3dd8 (Index: 0x1f, Flags: Final|Native|Public|BlueprintCallable)
    void SetActiveCategory(FName& CategoryID, bool& bAllowCategoryModal); // 0x11ed3e00 (Index: 0x20, Flags: Final|Native|Public|BlueprintCallable)
    void SetItemDetailTags(const TArray<FName> TagIDs); // 0x11ed4538 (Index: 0x21, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void SortChangedDelegate__DelegateSignature(); // 0x288a61c (Index: 0x22, Flags: MulticastDelegate|Public|Delegate)
    void SortPanelToggled__DelegateSignature(); // 0x288a61c (Index: 0x23, Flags: MulticastDelegate|Public|Delegate)

private:
    void HandleCategoryButtonClicked(FName& const CategoryID); // 0x11ecfaec (Index: 0xe, Flags: Final|Native|Private|BlueprintCallable)
    void HandleCategoryButtonFocused(FName& const CategoryID); // 0x11ecfd4c (Index: 0xf, Flags: Final|Native|Private|BlueprintCallable)
    void HandleSearchTextChanged(const FText Text); // 0x11ed1d48 (Index: 0x11, Flags: Final|Native|Private|HasOutParms|BlueprintCallable)
    void HandleSortAndFilterClicked(); // 0x11ed239c (Index: 0x13, Flags: Final|Native|Private)

protected:
    FDataTableRowHandle GetClearSearchInputAction(); // 0x11ecefb0 (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure)
    FDataTableRowHandle GetFocusSearchInputAction(); // 0x11ecf658 (Index: 0x8, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure)
    FSlateBrush GetIconForInputAction(bool& bOutFoundIcon, const FDataTableRowHandle InInputActionRow); // 0x11e9e12c (Index: 0xa, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    virtual void OnClearSearchProgress(float& Progress); // 0x288a61c (Index: 0x17, Flags: Event|Protected|BlueprintEvent)
    virtual void OnPopulateCategories(const TArray<FName> CategoryIDs); // 0x288a61c (Index: 0x18, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnSetSearchFocused(); // 0x288a61c (Index: 0x19, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSetSearchText(const FText NewSearchText); // 0x288a61c (Index: 0x1a, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnSetSearchVisible(bool& bVisible); // 0x288a61c (Index: 0x1b, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUpdateActiveCategory(const FName CategoryID); // 0x288a61c (Index: 0x1c, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnUpdateCategoryCountDisplay(const FName CategoryID, int32_t& NumItems, bool& bHideIfEmpty); // 0x288a61c (Index: 0x1d, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual UWidget* RefreshSideNavigationFocus(FName& OutFocusCategory); // 0x288a61c (Index: 0x1e, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UEmporiumBrowserFiltersPanel) == 0x560, "Size mismatch for UEmporiumBrowserFiltersPanel");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, OnFilterChanged) == 0x2d8, "Offset mismatch for UEmporiumBrowserFiltersPanel::OnFilterChanged");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, OnSortChanged) == 0x2e8, "Offset mismatch for UEmporiumBrowserFiltersPanel::OnSortChanged");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, OnSortPanelToggled) == 0x2f8, "Offset mismatch for UEmporiumBrowserFiltersPanel::OnSortPanelToggled");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, OnFocusChanged) == 0x308, "Offset mismatch for UEmporiumBrowserFiltersPanel::OnFocusChanged");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, OnCategoryActivated) == 0x318, "Offset mismatch for UEmporiumBrowserFiltersPanel::OnCategoryActivated");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, OnCategoryFocused) == 0x328, "Offset mismatch for UEmporiumBrowserFiltersPanel::OnCategoryFocused");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, OnUpdateCategoryCounts) == 0x350, "Offset mismatch for UEmporiumBrowserFiltersPanel::OnUpdateCategoryCounts");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, FilterSectionHeaderWidgetClass) == 0x3e8, "Offset mismatch for UEmporiumBrowserFiltersPanel::FilterSectionHeaderWidgetClass");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, FilterCategoryHeaderWidgetClass) == 0x3f0, "Offset mismatch for UEmporiumBrowserFiltersPanel::FilterCategoryHeaderWidgetClass");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, FilterHomeHeaderWidgetClass) == 0x3f8, "Offset mismatch for UEmporiumBrowserFiltersPanel::FilterHomeHeaderWidgetClass");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, FilterEntryWidgetClass) == 0x400, "Offset mismatch for UEmporiumBrowserFiltersPanel::FilterEntryWidgetClass");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, SortEntries) == 0x408, "Offset mismatch for UEmporiumBrowserFiltersPanel::SortEntries");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, FilterEntries) == 0x418, "Offset mismatch for UEmporiumBrowserFiltersPanel::FilterEntries");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, PriceFilterEntries) == 0x428, "Offset mismatch for UEmporiumBrowserFiltersPanel::PriceFilterEntries");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, LicenseFilterEntries) == 0x438, "Offset mismatch for UEmporiumBrowserFiltersPanel::LicenseFilterEntries");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, DefaultCategoryFilter) == 0x448, "Offset mismatch for UEmporiumBrowserFiltersPanel::DefaultCategoryFilter");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, DefaultTagFilterMode) == 0x44c, "Offset mismatch for UEmporiumBrowserFiltersPanel::DefaultTagFilterMode");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, Button_SortAndFilter) == 0x4a0, "Offset mismatch for UEmporiumBrowserFiltersPanel::Button_SortAndFilter");
static_assert(offsetof(UEmporiumBrowserFiltersPanel, LastSelectedTab) == 0x4e0, "Offset mismatch for UEmporiumBrowserFiltersPanel::LastSelectedTab");

// Size: 0x2e8 (Inherited: 0x458, Single: 0xfffffe90)
class UFortEmporiumFilterCategoryHeader : public UUserWidget
{
public:
    uint8_t OnCategoryActivated[0x10]; // 0x2b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnWidgetDestroyed[0x10]; // 0x2c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnExpandCategory[0x10]; // 0x2d0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UEmporiumBrowserTag* Tag; // 0x2e0 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void AddSubcategoryWidget(UWidget*& SubcategoryWidget); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void ClearSubcategoryWidgets(); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void EnableCategoryExpansion(bool& bShow); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void ExpandCategory(bool& bExpanded); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    void ExpandSection(); // 0x11ece674 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    virtual UCommonButtonBase* GetCategoryButton() const; // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintEvent|Const)
    virtual TArray<UWidget*> GetSubcategoryWidgets() const; // 0xa605b4c (Index: 0x7, Flags: Native|Event|Public|BlueprintEvent|Const)
    virtual void SetCycleSectionIcon(FSlateBrush& CycleSectionIcon); // 0x288a61c (Index: 0x9, Flags: Event|Public|BlueprintEvent)
    virtual void ShowCategoryActive(bool& bIsActive); // 0x288a61c (Index: 0xb, Flags: Event|Public|BlueprintEvent)
    virtual void ShowCycleSectionPrompt(bool& bShow); // 0x288a61c (Index: 0xc, Flags: Event|Public|BlueprintEvent)
    virtual void ShowUpperSpacer(bool& bShow); // 0x288a61c (Index: 0xd, Flags: Event|Public|BlueprintEvent)
    virtual void UpdateCategoryCount(int32_t& NewCount, bool& bHideIfEmpty); // 0x288a61c (Index: 0xe, Flags: Event|Public|BlueprintEvent)

protected:
    void ActivateCategory(bool& bExpanded); // 0x11ecd7d8 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void SetCategoryText(const FText NewButtonText); // 0x288a61c (Index: 0x8, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void SetSubcategoryCount(int32_t& NewCount); // 0x288a61c (Index: 0xa, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortEmporiumFilterCategoryHeader) == 0x2e8, "Size mismatch for UFortEmporiumFilterCategoryHeader");
static_assert(offsetof(UFortEmporiumFilterCategoryHeader, OnCategoryActivated) == 0x2b0, "Offset mismatch for UFortEmporiumFilterCategoryHeader::OnCategoryActivated");
static_assert(offsetof(UFortEmporiumFilterCategoryHeader, OnWidgetDestroyed) == 0x2c0, "Offset mismatch for UFortEmporiumFilterCategoryHeader::OnWidgetDestroyed");
static_assert(offsetof(UFortEmporiumFilterCategoryHeader, OnExpandCategory) == 0x2d0, "Offset mismatch for UFortEmporiumFilterCategoryHeader::OnExpandCategory");
static_assert(offsetof(UFortEmporiumFilterCategoryHeader, Tag) == 0x2e0, "Offset mismatch for UFortEmporiumFilterCategoryHeader::Tag");

// Size: 0x2f8 (Inherited: 0x458, Single: 0xfffffea0)
class UFortEmporiumFiltersSubPanel : public UUserWidget
{
public:
    uint8_t OnFilterEnabled[0x10]; // 0x2b0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnShowAllEnabled[0x10]; // 0x2c0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UClass* FilterEntryWidgetClass; // 0x2d0 (Size: 0x8, Type: ClassProperty)
    UEmporiumBrowserFilterEntry* Button_All; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UEmporiumBrowserFilterEntry* Button_LastSelected; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemListTabPanel* CachedItemTab; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2f0[0x8]; // 0x2f0 (Size: 0x8, Type: PaddingProperty)

private:
    void HandleFilterEnabled(bool& bIsFilterEnabled, UObject*& ListItemObject); // 0x11ed06d8 (Index: 0x1, Flags: Final|Native|Private)
    void HandleFilterHovered(UEmporiumBrowserFilterEntry*& Entry); // 0x11ed08f8 (Index: 0x2, Flags: Final|Native|Private)
    void HandleFilterSelected(bool& bIsFilterEnabled, UEmporiumBrowserFilterEntry*& Entry); // 0x11ed0cfc (Index: 0x3, Flags: Final|Native|Private)
    void HandleShowAllEnabled(bool& bShowAllItems, UObject*& ListItemObject); // 0x11ed217c (Index: 0x4, Flags: Final|Native|Private)

protected:
    virtual void ClearFilterWidgets(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void OnAddSubcategoryWidget(UEmporiumBrowserFilterEntry*& SubcategoryWidget); // 0x288a61c (Index: 0x5, Flags: Event|Protected|BlueprintEvent)
    virtual void OnFilterSelected(UEmporiumBrowserFilterEntry*& SubcategoryWidget); // 0x288a61c (Index: 0x6, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUpdateFilterEntries(const TArray<FName> IncludedTags); // 0x288a61c (Index: 0x7, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnUpdateSubcategoryCount(const FName CategoryID, int32_t& Count, bool& bShowOnEmpty); // 0x288a61c (Index: 0x8, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UFortEmporiumFiltersSubPanel) == 0x2f8, "Size mismatch for UFortEmporiumFiltersSubPanel");
static_assert(offsetof(UFortEmporiumFiltersSubPanel, OnFilterEnabled) == 0x2b0, "Offset mismatch for UFortEmporiumFiltersSubPanel::OnFilterEnabled");
static_assert(offsetof(UFortEmporiumFiltersSubPanel, OnShowAllEnabled) == 0x2c0, "Offset mismatch for UFortEmporiumFiltersSubPanel::OnShowAllEnabled");
static_assert(offsetof(UFortEmporiumFiltersSubPanel, FilterEntryWidgetClass) == 0x2d0, "Offset mismatch for UFortEmporiumFiltersSubPanel::FilterEntryWidgetClass");
static_assert(offsetof(UFortEmporiumFiltersSubPanel, Button_All) == 0x2d8, "Offset mismatch for UFortEmporiumFiltersSubPanel::Button_All");
static_assert(offsetof(UFortEmporiumFiltersSubPanel, Button_LastSelected) == 0x2e0, "Offset mismatch for UFortEmporiumFiltersSubPanel::Button_LastSelected");
static_assert(offsetof(UFortEmporiumFiltersSubPanel, CachedItemTab) == 0x2e8, "Offset mismatch for UFortEmporiumFiltersSubPanel::CachedItemTab");

// Size: 0x40 (Inherited: 0x28, Single: 0x18)
class UFortEmporiumHomeEntryObjectWrapper : public UObject
{
public:
    uint8_t EntrySource; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    UFortEmporiumItemListTabPanel* TabPanel; // 0x30 (Size: 0x8, Type: ObjectProperty)
    int32_t MaxItemsToShow; // 0x38 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UFortEmporiumHomeEntryObjectWrapper) == 0x40, "Size mismatch for UFortEmporiumHomeEntryObjectWrapper");
static_assert(offsetof(UFortEmporiumHomeEntryObjectWrapper, EntrySource) == 0x28, "Offset mismatch for UFortEmporiumHomeEntryObjectWrapper::EntrySource");
static_assert(offsetof(UFortEmporiumHomeEntryObjectWrapper, TabPanel) == 0x30, "Offset mismatch for UFortEmporiumHomeEntryObjectWrapper::TabPanel");
static_assert(offsetof(UFortEmporiumHomeEntryObjectWrapper, MaxItemsToShow) == 0x38, "Offset mismatch for UFortEmporiumHomeEntryObjectWrapper::MaxItemsToShow");

// Size: 0x4d8 (Inherited: 0x458, Single: 0x80)
class UFortEmporiumHomeListEntry : public UUserWidget
{
public:
    uint8_t Pad_2b0[0x8]; // 0x2b0 (Size: 0x8, Type: PaddingProperty)
    UFortEmporiumHomeListView* ParentView; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2c0[0x68]; // 0x2c0 (Size: 0x68, Type: PaddingProperty)
    int32_t MaxItemsToShow; // 0x328 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_32c[0x4]; // 0x32c (Size: 0x4, Type: PaddingProperty)
    UFortEmporiumItemListTabPanel* TabPanel; // 0x330 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_CategoryLabel; // 0x338 (Size: 0x8, Type: ObjectProperty)
    UAthenaCreativeItemTileView* HomeListView_ItemOptions; // 0x340 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_348[0x190]; // 0x348 (Size: 0x190, Type: PaddingProperty)

protected:
    EFortItemCardSize GetCardSizeForCategory() const; // 0x11ecece4 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    bool GetCollapseBorderPadFlagForCategory() const; // 0x11ecf048 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    virtual void UpdateOverflowDisplay(UAthenaCreativeItemTileButton*& OverflowTile, int32_t& OverflowCount); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
    virtual void UpdateWarningMessage(bool& bShowMessage); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortEmporiumHomeListEntry) == 0x4d8, "Size mismatch for UFortEmporiumHomeListEntry");
static_assert(offsetof(UFortEmporiumHomeListEntry, ParentView) == 0x2b8, "Offset mismatch for UFortEmporiumHomeListEntry::ParentView");
static_assert(offsetof(UFortEmporiumHomeListEntry, MaxItemsToShow) == 0x328, "Offset mismatch for UFortEmporiumHomeListEntry::MaxItemsToShow");
static_assert(offsetof(UFortEmporiumHomeListEntry, TabPanel) == 0x330, "Offset mismatch for UFortEmporiumHomeListEntry::TabPanel");
static_assert(offsetof(UFortEmporiumHomeListEntry, Text_CategoryLabel) == 0x338, "Offset mismatch for UFortEmporiumHomeListEntry::Text_CategoryLabel");
static_assert(offsetof(UFortEmporiumHomeListEntry, HomeListView_ItemOptions) == 0x340, "Offset mismatch for UFortEmporiumHomeListEntry::HomeListView_ItemOptions");

// Size: 0xdd0 (Inherited: 0x1af8, Single: 0xfffff2d8)
class UFortEmporiumHomeListView : public UCommonListView
{
public:
    uint8_t Pad_b60[0x80]; // 0xb60 (Size: 0x80, Type: PaddingProperty)
    TMap<UFortEmporiumHomeListEntry*, UFortEmporiumItemListTabPanel*> Map_TabToHomeList; // 0xbe0 (Size: 0x50, Type: MapProperty)
    TArray<UFortEmporiumItemListTabPanel*> TabPanelList; // 0xc30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_c40[0x168]; // 0xc40 (Size: 0x168, Type: PaddingProperty)
    UFortEmporiumItemListTabPanel* CurrentSelectionTab; // 0xda8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_db0[0x8]; // 0xdb0 (Size: 0x8, Type: PaddingProperty)
    UFortEmporiumHomeListEntry* RecentItemsEntry; // 0xdb8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_dc0[0x10]; // 0xdc0 (Size: 0x10, Type: PaddingProperty)

public:
    UWidget* GetFocusWidget(); // 0x11ecf6f0 (Index: 0x0, Flags: Native|Public|BlueprintCallable)
};

static_assert(sizeof(UFortEmporiumHomeListView) == 0xdd0, "Size mismatch for UFortEmporiumHomeListView");
static_assert(offsetof(UFortEmporiumHomeListView, Map_TabToHomeList) == 0xbe0, "Offset mismatch for UFortEmporiumHomeListView::Map_TabToHomeList");
static_assert(offsetof(UFortEmporiumHomeListView, TabPanelList) == 0xc30, "Offset mismatch for UFortEmporiumHomeListView::TabPanelList");
static_assert(offsetof(UFortEmporiumHomeListView, CurrentSelectionTab) == 0xda8, "Offset mismatch for UFortEmporiumHomeListView::CurrentSelectionTab");
static_assert(offsetof(UFortEmporiumHomeListView, RecentItemsEntry) == 0xdb8, "Offset mismatch for UFortEmporiumHomeListView::RecentItemsEntry");

// Size: 0x4c0 (Inherited: 0xf80, Single: 0xfffff540)
class UFortEmporiumHomeTabPanel : public UFortCreativeContentBrowserTabPanelBase
{
public:
    uint8_t Pad_448[0x68]; // 0x448 (Size: 0x68, Type: PaddingProperty)
    FName FeaturedItemTag; // 0x4b0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4b4[0x4]; // 0x4b4 (Size: 0x4, Type: PaddingProperty)
    UFortEmporiumHomeListView* FortEmporiumHomeListView_Options; // 0x4b8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortEmporiumHomeTabPanel) == 0x4c0, "Size mismatch for UFortEmporiumHomeTabPanel");
static_assert(offsetof(UFortEmporiumHomeTabPanel, FeaturedItemTag) == 0x4b0, "Offset mismatch for UFortEmporiumHomeTabPanel::FeaturedItemTag");
static_assert(offsetof(UFortEmporiumHomeTabPanel, FortEmporiumHomeListView_Options) == 0x4b8, "Offset mismatch for UFortEmporiumHomeTabPanel::FortEmporiumHomeListView_Options");

// Size: 0xa8 (Inherited: 0xc8, Single: 0xffffffe0)
class UFortEmporiumItem : public UFortItem
{
public:
    UFortEmporiumItemDefinition* ItemDefinition; // 0xa0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UFortEmporiumItem) == 0xa8, "Size mismatch for UFortEmporiumItem");
static_assert(offsetof(UFortEmporiumItem, ItemDefinition) == 0xa0, "Offset mismatch for UFortEmporiumItem::ItemDefinition");

// Size: 0x1b0 (Inherited: 0x1e0, Single: 0xffffffd0)
class UFortEmporiumItemDefinition : public UFortItemDefinition
{
public:
    uint8_t Pad_a8[0x8]; // 0xa8 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnItemThumbnailDownloaded[0x10]; // 0xb0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_c0[0xf0]; // 0xc0 (Size: 0xf0, Type: PaddingProperty)

public:
    FFortEmporiumItemData GetEmporiumItemData() const; // 0x11ecf5b0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortEmporiumItemDefinition) == 0x1b0, "Size mismatch for UFortEmporiumItemDefinition");
static_assert(offsetof(UFortEmporiumItemDefinition, OnItemThumbnailDownloaded) == 0xb0, "Offset mismatch for UFortEmporiumItemDefinition::OnItemThumbnailDownloaded");

// Size: 0x348 (Inherited: 0x730, Single: 0xfffffc18)
class UFortEmporiumItemDetailsPanel : public UCommonUserWidget
{
public:
    uint8_t Pad_2d8[0x30]; // 0x2d8 (Size: 0x30, Type: PaddingProperty)
    FDataTableRowHandle ItemDetailTagsInputRowHandle; // 0x308 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_318[0x8]; // 0x318 (Size: 0x8, Type: PaddingProperty)
    UItemDefinitionBase* CachedItemDefinition; // 0x320 (Size: 0x8, Type: ObjectProperty)
    UItemDefinitionBase* CachedParentDefinition; // 0x328 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* Switcher_Details; // 0x330 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemInfo* ItemDetails; // 0x338 (Size: 0x8, Type: ObjectProperty)
    UAthenaInventoryItemInfo* LegacyItemDetails; // 0x340 (Size: 0x8, Type: ObjectProperty)

public:
    virtual bool HasLegacyItemDetailsPanel() const; // 0x4c4e47c (Index: 0x2, Flags: Native|Event|Public|BlueprintEvent|Const)
    void RequestItemFocus(); // 0x11ed389c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    virtual void SetActiveItemDetailTags(const TArray<FName> ActiveTags); // 0x288a61c (Index: 0x8, Flags: Event|Public|HasOutParms|BlueprintEvent)
    void SetItemToDetail(UFortItem*& const InItemToDetail, UItemDefinitionBase*& const ParentDefinition, bool& const bUseLargeThumbnail, bool& const bAllowInteractiveTags); // 0x11ed47dc (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    virtual void SetSpecialItemTagVisibility(const FName SpecialItemTag); // 0x288a61c (Index: 0xb, Flags: Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void SwitchItemDetailsPanel(bool& bUseLegacy); // 0x11ed5274 (Index: 0xd, Flags: Native|Event|Public|BlueprintEvent)
    virtual void ToggleItemDetailsPanel(); // 0x288a61c (Index: 0xe, Flags: Event|Public|BlueprintEvent)

protected:
    virtual TArray<FName> BP_GetSpecialItemTags() const; // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent|Const)
    void HandleItemTagSelected(FName& TagID, bool& bSelected); // 0x11ed13dc (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void HideAdditionalButtons(); // 0x288a61c (Index: 0x3, Flags: Event|Protected|BlueprintEvent)
    virtual void HideExtendedDataPanel(); // 0x288a61c (Index: 0x4, Flags: Event|Protected|BlueprintEvent)
    virtual bool IsShowingAdditionalButtons(); // 0x4c4e47c (Index: 0x5, Flags: Native|Event|Protected|BlueprintEvent)
    virtual bool IsShowingExtendedDataPanel() const; // 0x4c4e47c (Index: 0x6, Flags: Native|Event|Protected|BlueprintEvent|Const)
    virtual void SetItemDetails(UFortItem*& const FortItem, UItemDefinitionBase*& const ParentDefinition, bool& const bUseLargeThumbnail, bool& const bAllowInteractiveTags); // 0x288a61c (Index: 0x9, Flags: Event|Protected|BlueprintCallable|BlueprintEvent)
    virtual void ShowExtendedDataPanel(); // 0x288a61c (Index: 0xc, Flags: Event|Protected|BlueprintEvent)
    virtual void UpdateItemDetailsDisplay(bool& bShowItemDetails); // 0x288a61c (Index: 0xf, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UFortEmporiumItemDetailsPanel) == 0x348, "Size mismatch for UFortEmporiumItemDetailsPanel");
static_assert(offsetof(UFortEmporiumItemDetailsPanel, ItemDetailTagsInputRowHandle) == 0x308, "Offset mismatch for UFortEmporiumItemDetailsPanel::ItemDetailTagsInputRowHandle");
static_assert(offsetof(UFortEmporiumItemDetailsPanel, CachedItemDefinition) == 0x320, "Offset mismatch for UFortEmporiumItemDetailsPanel::CachedItemDefinition");
static_assert(offsetof(UFortEmporiumItemDetailsPanel, CachedParentDefinition) == 0x328, "Offset mismatch for UFortEmporiumItemDetailsPanel::CachedParentDefinition");
static_assert(offsetof(UFortEmporiumItemDetailsPanel, Switcher_Details) == 0x330, "Offset mismatch for UFortEmporiumItemDetailsPanel::Switcher_Details");
static_assert(offsetof(UFortEmporiumItemDetailsPanel, ItemDetails) == 0x338, "Offset mismatch for UFortEmporiumItemDetailsPanel::ItemDetails");
static_assert(offsetof(UFortEmporiumItemDetailsPanel, LegacyItemDetails) == 0x340, "Offset mismatch for UFortEmporiumItemDetailsPanel::LegacyItemDetails");

// Size: 0x2e8 (Inherited: 0x730, Single: 0xfffffbb8)
class UFortEmporiumItemInfo : public UCommonUserWidget
{
public:
    TArray<FName> HiddenTags; // 0x2d8 (Size: 0x10, Type: ArrayProperty)

public:
    virtual bool HasFocusableTags() const; // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual void SetSelectItemTagsIcon(FSlateBrush& SelectItemTagsIcon); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void SetSelectItemTagsPrompt(const FText Prompt); // 0x288a61c (Index: 0x2, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void SetTagFocus(); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void ShowSelectItemTagsPrompt(bool& bShowPrompt); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    virtual void UpdateWithFortItem(UFortItem*& const Item, UItemDefinitionBase*& const ParentDefinition, bool& const bAllowInteractiveTags); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UFortEmporiumItemInfo) == 0x2e8, "Size mismatch for UFortEmporiumItemInfo");
static_assert(offsetof(UFortEmporiumItemInfo, HiddenTags) == 0x2d8, "Offset mismatch for UFortEmporiumItemInfo::HiddenTags");

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UFortEmporiumCategoryEntry : public UObject
{
public:
    FString Path; // 0x28 (Size: 0x10, Type: StrProperty)
    FString Hash; // 0x38 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(UFortEmporiumCategoryEntry) == 0x48, "Size mismatch for UFortEmporiumCategoryEntry");
static_assert(offsetof(UFortEmporiumCategoryEntry, Path) == 0x28, "Offset mismatch for UFortEmporiumCategoryEntry::Path");
static_assert(offsetof(UFortEmporiumCategoryEntry, Hash) == 0x38, "Offset mismatch for UFortEmporiumCategoryEntry::Hash");

// Size: 0xc00 (Inherited: 0xb38, Single: 0xc8)
class UFortEmporiumItemListMenu : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x30]; // 0x408 (Size: 0x30, Type: PaddingProperty)
    UClass* PanelDataClass; // 0x438 (Size: 0x8, Type: ClassProperty)
    UDataTable* ItemListCategorySource; // 0x440 (Size: 0x8, Type: ObjectProperty)
    UFortCreativeItemListPanelData* ItemListPanelData; // 0x448 (Size: 0x8, Type: ObjectProperty)
    UClass* InventoryTabClass; // 0x450 (Size: 0x8, Type: ClassProperty)
    UClass* LevelManagementTabClass; // 0x458 (Size: 0x8, Type: ClassProperty)
    UClass* HomeTabClass; // 0x460 (Size: 0x8, Type: ClassProperty)
    UClass* InventoryTabButton; // 0x468 (Size: 0x8, Type: ClassProperty)
    TMap<FText, FName> Map_CreativeBetaTagNames; // 0x470 (Size: 0x50, Type: MapProperty)
    TMap<FFortEmporiumKeyEdgeMappings, ECommonInputType> Map_ToggleFilterFocusKeys; // 0x4c0 (Size: 0x50, Type: MapProperty)
    TMap<FFortEmporiumKeyEdgeMappings, ECommonInputType> Map_ToggleFilterSubPanelFocusKeys; // 0x510 (Size: 0x50, Type: MapProperty)
    TMap<FFortEmporiumKeyEdgeMappings, ECommonInputType> Map_CycleTagFilterModeModifierKeys; // 0x560 (Size: 0x50, Type: MapProperty)
    TMap<FFortEmporiumKeyEdgeMappings, ECommonInputType> Map_ClearTagFiltersModifierKeys; // 0x5b0 (Size: 0x50, Type: MapProperty)
    TMap<FFortEmporiumKeyEdgeMappings, ECommonInputType> Map_ToggleSidePanelDockingModifierKeys; // 0x600 (Size: 0x50, Type: MapProperty)
    FKey ToggleSidePanelDockingKey; // 0x650 (Size: 0x18, Type: StructProperty)
    FKey ToggleSubPanelMode; // 0x668 (Size: 0x18, Type: StructProperty)
    FDataTableRowHandle FocusSearchInputActionRow; // 0x680 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_690[0x8]; // 0x690 (Size: 0x8, Type: PaddingProperty)
    FDataTableRowHandle ClearSearchInputActionRow; // 0x698 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_6a8[0x8]; // 0x6a8 (Size: 0x8, Type: PaddingProperty)
    FDataTableRowHandle CycleSortInputActionRow; // 0x6b0 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_6c0[0x8]; // 0x6c0 (Size: 0x8, Type: PaddingProperty)
    FDataTableRowHandle RequestItemFocusInputActionRow; // 0x6c8 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_6d8[0x8]; // 0x6d8 (Size: 0x8, Type: PaddingProperty)
    UFortEmporiumItemListTabPanel* ChestTabPanel; // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemListTabPanel* VersePrefabsTabPanel; // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    UFortCreativeLevelManagementTabPanel* LevelManagementTabPanel; // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumHomeTabPanel* HomeTabPanel; // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemListTabPanel* FabTabPanel; // 0x700 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemListTabPanel* SubItemsTabPanel; // 0x708 (Size: 0x8, Type: ObjectProperty)
    FName FabTabNameId; // 0x710 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_714[0xc]; // 0x714 (Size: 0xc, Type: PaddingProperty)
    FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x720 (Size: 0xf0, Type: StructProperty)
    FAthenaMapScreenContainerTabInfo MapScreenContainerTabInfo; // 0x810 (Size: 0x40, Type: StructProperty)
    bool bIsDefaultActiveTab; // 0x850 (Size: 0x1, Type: BoolProperty)
    bool bAddItemToInventoryOnEquip; // 0x851 (Size: 0x1, Type: BoolProperty)
    bool bLoadItemsOnInitialized; // 0x852 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_853[0x1]; // 0x853 (Size: 0x1, Type: PaddingProperty)
    int32_t LastUsedSlot; // 0x854 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_858[0x8]; // 0x858 (Size: 0x8, Type: PaddingProperty)
    TMap<UFortCreativeContentBrowserTabPanelBase*, FName> TabMap; // 0x860 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_8b0[0x1b8]; // 0x8b0 (Size: 0x1b8, Type: PaddingProperty)
    TArray<UFortEmporiumItemDefinition*> EmporiumItemDefinitionList; // 0xa68 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_a78[0x18]; // 0xa78 (Size: 0x18, Type: PaddingProperty)
    TMap<UFortEmporiumItemListTabPanel*, FName> Map_ItemNameToTab; // 0xa90 (Size: 0x50, Type: MapProperty)
    UCommonVisibilitySwitcher* Switcher_SidePanels; // 0xae0 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* Switcher_Categories; // 0xae8 (Size: 0x8, Type: ObjectProperty)
    UWidgetSwitcher* Switcher_ItemTabWarnings; // 0xaf0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_ChestEmpty; // 0xaf8 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_TabEmpty; // 0xb00 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_DownloadingFabCategories; // 0xb08 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_FabCategoriesNotLoaded; // 0xb10 (Size: 0x8, Type: ObjectProperty)
    UWidgetSwitcher* Switcher_CommandBar; // 0xb18 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_ChestCommands; // 0xb20 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_VendCommands; // 0xb28 (Size: 0x8, Type: ObjectProperty)
    UFortCreativeMenuQuickbar* MenuQuickbar_QuickBars; // 0xb30 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_ResetChest; // 0xb38 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CreateChest; // 0xb40 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_AddToQuickBar; // 0xb48 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_OpenItem; // 0xb50 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_PlaceNow; // 0xb58 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Equip; // 0xb60 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_AddToChest; // 0xb68 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Drop; // 0xb70 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_CreateLlama; // 0xb78 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_RemoveFromChest; // 0xb80 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_SearchFilters; // 0xb88 (Size: 0x8, Type: ObjectProperty)
    UCommonAnimatedSwitcher* Switcher_LeftPanel; // 0xb90 (Size: 0x8, Type: ObjectProperty)
    UEmporiumBrowserFiltersPanel* FiltersPanel; // 0xb98 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumFiltersSubPanel* FiltersSubPanel; // 0xba0 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemDetailsPanel* SubTabItemDetailsPanel; // 0xba8 (Size: 0x8, Type: ObjectProperty)
    UAthenaCustomizationPickerSortAndFilterBlade* Blade_SortAndFilter; // 0xbb0 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemDetailsPanel* ItemDetailsSidePanel_DefaultSidePanel; // 0xbb8 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* Switcher_ProductPage; // 0xbc0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_ItemBrowser; // 0xbc8 (Size: 0x8, Type: ObjectProperty)
    UFortEmporiumItemDetailsPanel* ItemProductPagePanel; // 0xbd0 (Size: 0x8, Type: ObjectProperty)
    UWidgetSwitcher* Switcher_InventoryPermission; // 0xbd8 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_EmporiumPanel; // 0xbe0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_InventoryNotAllowed; // 0xbe8 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_EditorDisconnected; // 0xbf0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_InitializingInventory; // 0xbf8 (Size: 0x8, Type: ObjectProperty)

public:
    bool AddSelectionToQuickBar(); // 0x11ecdba8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool CanAddToChest(const FFortItemEntry SelectedItem) const; // 0x11ecdf58 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool CanDropItem(const FFortItemEntry SelectedItem) const; // 0x11ece078 (Index: 0x2, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool CanEquip(const FFortItemEntry SelectedItem) const; // 0x11ece198 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool DropItem(const FFortItemEntry SelectedItem); // 0x11ece32c (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool EquipItem(const FFortItemEntry ItemEntry); // 0x11ece44c (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool EquipSelection(); // 0x11ece56c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    FFortItemEntry GetCurrentSelection() const; // 0x11ecf51c (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UFortCreativeContentBrowserTabPanelBase* GetCurrentTab() const; // 0x11ecf58c (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FName GetLastSelectedTabName() const; // 0x11ecf768 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UItemDefinitionBase* GetSubTabSelectedItemDefinition() const; // 0x11ecf7c0 (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void InitializeFabTab(); // 0x11ed2dfc (Index: 0x2a, Flags: Final|Native|Public|BlueprintCallable)
    void InitializeTabs(); // 0x11ed2e10 (Index: 0x2b, Flags: Final|Native|Public|BlueprintCallable)
    bool IsSubTabOpened() const; // 0x11ed2fa8 (Index: 0x2e, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void LoadFabItems(); // 0x11ed2fe8 (Index: 0x2f, Flags: Final|Native|Public|BlueprintCallable)
    void NativeOnBuiltInItemsLoaded(); // 0x11ed2ffc (Index: 0x30, Flags: Final|Native|Public)
    void NativeOnItemsLoaded(); // 0x11ed3010 (Index: 0x31, Flags: Final|Native|Public)
    void NativeOnItemsRefreshed(); // 0x11ed3024 (Index: 0x32, Flags: Final|Native|Public)
    virtual void OnBuiltInItemsLoaded(); // 0x288a61c (Index: 0x34, Flags: Event|Public|BlueprintEvent)
    void OnCreativeQuickbarComponentLoaded(); // 0x11ed3038 (Index: 0x36, Flags: Final|Native|Public)
    virtual void OnExitSubTab(); // 0x288a61c (Index: 0x37, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void OnItemsLoaded(); // 0x288a61c (Index: 0x3b, Flags: Event|Public|BlueprintEvent)
    virtual void OnSearchFiltersVisibilityChanged(bool& bIsVisible); // 0x288a61c (Index: 0x3e, Flags: Event|Public|BlueprintEvent)
    virtual void OnSelectionOpened(UItemDefinitionBase*& const SelectedItemDefinition); // 0x288a61c (Index: 0x3f, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    virtual bool OnShouldAllowCommandBar(UUserWidget*& FocusPathWidget, bool& bAllowCommandBar); // 0x288a61c (Index: 0x40, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual bool OnShouldAllowModifierKeys(); // 0x288a61c (Index: 0x41, Flags: Event|Public|BlueprintEvent)
    virtual void OnShowGridBlocker(bool& bShow); // 0x288a61c (Index: 0x43, Flags: Event|Public|BlueprintEvent)
    virtual void OnTabChanged(); // 0x288a61c (Index: 0x47, Flags: Event|Public|BlueprintEvent)
    virtual void OnUpdateTagFilterButton(EFortEmporiumItemTagFilterMode& const Mode); // 0x288a61c (Index: 0x4a, Flags: Event|Public|BlueprintEvent)
    bool OpenSelection(); // 0x11ed382c (Index: 0x4b, Flags: Final|Native|Public|BlueprintCallable)
    bool PlaceSelectionInMoveTool(); // 0x11ed3850 (Index: 0x4c, Flags: Final|Native|Public|BlueprintCallable)
    void RefreshTabWarningState(); // 0x11ed3874 (Index: 0x4d, Flags: Final|Native|Public|BlueprintCallable)
    void SetIsItemCommandsEnabled(bool& bInIsItemCommandEnabled); // 0x11ed440c (Index: 0x4f, Flags: Final|Native|Public|BlueprintCallable)
    void SetSubTabOpened(UItemDefinitionBase*& ItemDefinition); // 0x11ed4ba0 (Index: 0x50, Flags: Final|Native|Public|BlueprintCallable)
    void SpawnContainer(UClass*& SupplyDropClass); // 0x11ed4cfc (Index: 0x51, Flags: Final|Native|Public|BlueprintCallable)
    void SwitchItemDetailsPanel(bool& bUseLegacy); // 0x11ed53a4 (Index: 0x52, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateDetailsPanel(); // 0x11ed5610 (Index: 0x54, Flags: Final|Native|Public|BlueprintCallable)

private:
    void HandleAddSelectionToMoveToolComplete(); // 0x11ecf9b0 (Index: 0xe, Flags: Final|Native|Private)
    void HandleCategoryActivated(FName& CategoryID); // 0x11ecf9c4 (Index: 0xf, Flags: Final|Native|Private)
    void HandleCategoryButtonClicked(const FName CategoryID); // 0x11ecfc68 (Index: 0x10, Flags: Final|Native|Private|HasOutParms)
    void HandleCategoryFocused(FName& CategoryID); // 0x11ecfe74 (Index: 0x11, Flags: Final|Native|Private)
    void HandleChestItemCountChanged(int32_t& Count); // 0x11ecff9c (Index: 0x12, Flags: Final|Native|Private)
    void HandleEquipItem(const FFortItemEntry ItemEntry); // 0x11ed00c4 (Index: 0x13, Flags: Final|Native|Private|HasOutParms)
    void HandleFilterButtonClicked(FName& FilterNameId, UCommonButtonBase*& NewButton); // 0x11ed01e4 (Index: 0x14, Flags: Final|Native|Private)
    void HandleFilterChanged(); // 0x11ed03ec (Index: 0x15, Flags: Final|Native|Private)
    void HandleFilterPanelIsFocused(bool& bIsFocused); // 0x11ed0bd0 (Index: 0x16, Flags: Final|Native|Private)
    void HandleGlobalSortPanelToggle(); // 0x11ed0f2c (Index: 0x17, Flags: Final|Native|Private)
    void HandleHomeItemClicked(UFortEmporiumItemListTabPanel*& ItemTab); // 0x11ed0f40 (Index: 0x18, Flags: Final|Native|Private)
    void HandleItemClicked(const FFortItemEntry ItemEntry); // 0x11ed1070 (Index: 0x19, Flags: Final|Native|Private|HasOutParms)
    void HandleItemDoubleClicked(const FFortItemEntry ItemEntry); // 0x11ed12cc (Index: 0x1a, Flags: Final|Native|Private|HasOutParms)
    void HandleItemTagSelected(const FName TagID, bool& bSelected); // 0x11ed15f4 (Index: 0x1b, Flags: Final|Native|Private|HasOutParms)
    void HandleItemThumbnailDownloaded(UFortEmporiumItemDefinition*& ItemDefinition); // 0x11ed1764 (Index: 0x1c, Flags: Final|Native|Private)
    void HandleModalHitBlockerClicked(); // 0x11ed1890 (Index: 0x1d, Flags: Final|Native|Private|BlueprintCallable)
    void HandleQuickbarPanelIsFocused(bool& bIsFocused); // 0x11ed18cc (Index: 0x1e, Flags: Final|Native|Private)
    void HandleQuickbarStateChanged(EFortContentBrowserQuickbarState& const State); // 0x11ed19f8 (Index: 0x1f, Flags: Final|Native|Private)
    void HandleRequestItemFocus(UItemDefinitionBase*& const SelectedItemDefinition, UItemDefinitionBase*& const ParentItemDefinition); // 0x11ed1b40 (Index: 0x20, Flags: Final|Native|Private)
    void HandleSelectionChanged(UFortCreativeContentBrowserTabPanelBase*& Tab); // 0x11ed1e3c (Index: 0x21, Flags: Final|Native|Private)
    void HandleSortButtonClicked(FName& SortNameId, UCommonButtonBase*& NewButton); // 0x11ed23b0 (Index: 0x22, Flags: Final|Native|Private)
    void HandleSortChanged(); // 0x11ed25b8 (Index: 0x23, Flags: Final|Native|Private)
    void HandleSubFilterEnabled(bool& bIsFilterEnabled, UObject*& ListItemObject); // 0x11ed25cc (Index: 0x24, Flags: Final|Native|Private)
    void HandleSubFilterShowAllEnabled(bool& bIsFilterEnabled, UObject*& ListItemObject); // 0x11ed27e8 (Index: 0x25, Flags: Final|Native|Private)
    void HandleTabItemDetailClicked(const FName TagID); // 0x11ed2a04 (Index: 0x26, Flags: Final|Native|Private|HasOutParms)
    void HandleTabSelected(FName& TabID, bool& bCaptureFocus); // 0x11ed2ae8 (Index: 0x27, Flags: Final|Native|Private|BlueprintCallable)
    void HandleTabSortButtonClicked(); // 0x11ed2cf0 (Index: 0x28, Flags: Final|Native|Private)
    void HandleUpdateCategoryCounts(); // 0x11ed2d04 (Index: 0x29, Flags: Final|Native|Private)
    void OnContentRatingFilterChanged(); // 0x11ed25b8 (Index: 0x35, Flags: Final|Native|Private)
    void OnFabCategoryListLoaded(bool& bSuccess, FString& JsonString); // 0x11ed304c (Index: 0x38, Flags: Final|Native|Private)
    void OnFabItemQueryComplete(bool& bSuccess, FString& JsonString); // 0x11ed343c (Index: 0x39, Flags: Final|Native|Private)
    void SetActiveTab(UFortCreativeContentBrowserTabPanelBase*& Tab, bool& bCaptureFocus); // 0x11ed4008 (Index: 0x4e, Flags: Final|Native|Private|BlueprintCallable)
    void UpdatePermissionsDisplay(); // 0x11ed5624 (Index: 0x55, Flags: Final|Native|Private)

protected:
    void CycleTagFilterMode(); // 0x11ece318 (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable)
    void FocusSidePanel(bool& bIsRightPanel, bool& bFocus); // 0x11ece6a8 (Index: 0x8, Flags: Final|Native|Protected|BlueprintCallable)
    virtual UWidget* GetEmptyTabFocusWidget(UFortEmporiumItemListTabPanel*& const Tab) const; // 0x288a61c (Index: 0xb, Flags: Event|Protected|BlueprintEvent|Const)
    virtual bool IsShowingModal() const; // 0x288a61c (Index: 0x2c, Flags: Event|Protected|BlueprintEvent|Const)
    virtual bool IsSidePanelOpen(bool& bRightPanel) const; // 0x288a61c (Index: 0x2d, Flags: Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    virtual void OnAnimateSidePanel(bool& bIsRightPanel, bool& bShow); // 0x288a61c (Index: 0x33, Flags: Event|Protected|BlueprintEvent)
    virtual void OnItemEquipped(const FFortItemEntry EquippedItemEntry); // 0x288a61c (Index: 0x3a, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnQuickbarStateChanged(EFortContentBrowserQuickbarState& const State); // 0x288a61c (Index: 0x3c, Flags: Event|Protected|BlueprintEvent)
    virtual UWidget* OnRefreshFocusWidget() const; // 0x288a61c (Index: 0x3d, Flags: Event|Protected|BlueprintEvent|Const)
    virtual void OnShowCategoryModal(bool& bShowModal); // 0x288a61c (Index: 0x42, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSidePanelDockToggled(); // 0x288a61c (Index: 0x44, Flags: Event|Protected|BlueprintEvent)
    virtual void OnSubPanelModeChanged(); // 0x288a61c (Index: 0x45, Flags: Event|Protected|BlueprintEvent)
    virtual void OnTabAdded(UFortCreativeContentBrowserTabPanelBase*& Tab); // 0x288a61c (Index: 0x46, Flags: Event|Protected|BlueprintEvent)
    virtual void OnUpdateCategoryLabel(const FText SectionLabel, const FText CategoryLabel); // 0x288a61c (Index: 0x48, Flags: Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnUpdateCommandBarVisibility(bool& bShowBar); // 0x288a61c (Index: 0x49, Flags: Event|Protected|BlueprintEvent)
    void UpdateBackButtonText(bool& bFilterFocus); // 0x11ed54d0 (Index: 0x53, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UFortEmporiumItemListMenu) == 0xc00, "Size mismatch for UFortEmporiumItemListMenu");
static_assert(offsetof(UFortEmporiumItemListMenu, PanelDataClass) == 0x438, "Offset mismatch for UFortEmporiumItemListMenu::PanelDataClass");
static_assert(offsetof(UFortEmporiumItemListMenu, ItemListCategorySource) == 0x440, "Offset mismatch for UFortEmporiumItemListMenu::ItemListCategorySource");
static_assert(offsetof(UFortEmporiumItemListMenu, ItemListPanelData) == 0x448, "Offset mismatch for UFortEmporiumItemListMenu::ItemListPanelData");
static_assert(offsetof(UFortEmporiumItemListMenu, InventoryTabClass) == 0x450, "Offset mismatch for UFortEmporiumItemListMenu::InventoryTabClass");
static_assert(offsetof(UFortEmporiumItemListMenu, LevelManagementTabClass) == 0x458, "Offset mismatch for UFortEmporiumItemListMenu::LevelManagementTabClass");
static_assert(offsetof(UFortEmporiumItemListMenu, HomeTabClass) == 0x460, "Offset mismatch for UFortEmporiumItemListMenu::HomeTabClass");
static_assert(offsetof(UFortEmporiumItemListMenu, InventoryTabButton) == 0x468, "Offset mismatch for UFortEmporiumItemListMenu::InventoryTabButton");
static_assert(offsetof(UFortEmporiumItemListMenu, Map_CreativeBetaTagNames) == 0x470, "Offset mismatch for UFortEmporiumItemListMenu::Map_CreativeBetaTagNames");
static_assert(offsetof(UFortEmporiumItemListMenu, Map_ToggleFilterFocusKeys) == 0x4c0, "Offset mismatch for UFortEmporiumItemListMenu::Map_ToggleFilterFocusKeys");
static_assert(offsetof(UFortEmporiumItemListMenu, Map_ToggleFilterSubPanelFocusKeys) == 0x510, "Offset mismatch for UFortEmporiumItemListMenu::Map_ToggleFilterSubPanelFocusKeys");
static_assert(offsetof(UFortEmporiumItemListMenu, Map_CycleTagFilterModeModifierKeys) == 0x560, "Offset mismatch for UFortEmporiumItemListMenu::Map_CycleTagFilterModeModifierKeys");
static_assert(offsetof(UFortEmporiumItemListMenu, Map_ClearTagFiltersModifierKeys) == 0x5b0, "Offset mismatch for UFortEmporiumItemListMenu::Map_ClearTagFiltersModifierKeys");
static_assert(offsetof(UFortEmporiumItemListMenu, Map_ToggleSidePanelDockingModifierKeys) == 0x600, "Offset mismatch for UFortEmporiumItemListMenu::Map_ToggleSidePanelDockingModifierKeys");
static_assert(offsetof(UFortEmporiumItemListMenu, ToggleSidePanelDockingKey) == 0x650, "Offset mismatch for UFortEmporiumItemListMenu::ToggleSidePanelDockingKey");
static_assert(offsetof(UFortEmporiumItemListMenu, ToggleSubPanelMode) == 0x668, "Offset mismatch for UFortEmporiumItemListMenu::ToggleSubPanelMode");
static_assert(offsetof(UFortEmporiumItemListMenu, FocusSearchInputActionRow) == 0x680, "Offset mismatch for UFortEmporiumItemListMenu::FocusSearchInputActionRow");
static_assert(offsetof(UFortEmporiumItemListMenu, ClearSearchInputActionRow) == 0x698, "Offset mismatch for UFortEmporiumItemListMenu::ClearSearchInputActionRow");
static_assert(offsetof(UFortEmporiumItemListMenu, CycleSortInputActionRow) == 0x6b0, "Offset mismatch for UFortEmporiumItemListMenu::CycleSortInputActionRow");
static_assert(offsetof(UFortEmporiumItemListMenu, RequestItemFocusInputActionRow) == 0x6c8, "Offset mismatch for UFortEmporiumItemListMenu::RequestItemFocusInputActionRow");
static_assert(offsetof(UFortEmporiumItemListMenu, ChestTabPanel) == 0x6e0, "Offset mismatch for UFortEmporiumItemListMenu::ChestTabPanel");
static_assert(offsetof(UFortEmporiumItemListMenu, VersePrefabsTabPanel) == 0x6e8, "Offset mismatch for UFortEmporiumItemListMenu::VersePrefabsTabPanel");
static_assert(offsetof(UFortEmporiumItemListMenu, LevelManagementTabPanel) == 0x6f0, "Offset mismatch for UFortEmporiumItemListMenu::LevelManagementTabPanel");
static_assert(offsetof(UFortEmporiumItemListMenu, HomeTabPanel) == 0x6f8, "Offset mismatch for UFortEmporiumItemListMenu::HomeTabPanel");
static_assert(offsetof(UFortEmporiumItemListMenu, FabTabPanel) == 0x700, "Offset mismatch for UFortEmporiumItemListMenu::FabTabPanel");
static_assert(offsetof(UFortEmporiumItemListMenu, SubItemsTabPanel) == 0x708, "Offset mismatch for UFortEmporiumItemListMenu::SubItemsTabPanel");
static_assert(offsetof(UFortEmporiumItemListMenu, FabTabNameId) == 0x710, "Offset mismatch for UFortEmporiumItemListMenu::FabTabNameId");
static_assert(offsetof(UFortEmporiumItemListMenu, TabButtonLabelInfo) == 0x720, "Offset mismatch for UFortEmporiumItemListMenu::TabButtonLabelInfo");
static_assert(offsetof(UFortEmporiumItemListMenu, MapScreenContainerTabInfo) == 0x810, "Offset mismatch for UFortEmporiumItemListMenu::MapScreenContainerTabInfo");
static_assert(offsetof(UFortEmporiumItemListMenu, bIsDefaultActiveTab) == 0x850, "Offset mismatch for UFortEmporiumItemListMenu::bIsDefaultActiveTab");
static_assert(offsetof(UFortEmporiumItemListMenu, bAddItemToInventoryOnEquip) == 0x851, "Offset mismatch for UFortEmporiumItemListMenu::bAddItemToInventoryOnEquip");
static_assert(offsetof(UFortEmporiumItemListMenu, bLoadItemsOnInitialized) == 0x852, "Offset mismatch for UFortEmporiumItemListMenu::bLoadItemsOnInitialized");
static_assert(offsetof(UFortEmporiumItemListMenu, LastUsedSlot) == 0x854, "Offset mismatch for UFortEmporiumItemListMenu::LastUsedSlot");
static_assert(offsetof(UFortEmporiumItemListMenu, TabMap) == 0x860, "Offset mismatch for UFortEmporiumItemListMenu::TabMap");
static_assert(offsetof(UFortEmporiumItemListMenu, EmporiumItemDefinitionList) == 0xa68, "Offset mismatch for UFortEmporiumItemListMenu::EmporiumItemDefinitionList");
static_assert(offsetof(UFortEmporiumItemListMenu, Map_ItemNameToTab) == 0xa90, "Offset mismatch for UFortEmporiumItemListMenu::Map_ItemNameToTab");
static_assert(offsetof(UFortEmporiumItemListMenu, Switcher_SidePanels) == 0xae0, "Offset mismatch for UFortEmporiumItemListMenu::Switcher_SidePanels");
static_assert(offsetof(UFortEmporiumItemListMenu, Switcher_Categories) == 0xae8, "Offset mismatch for UFortEmporiumItemListMenu::Switcher_Categories");
static_assert(offsetof(UFortEmporiumItemListMenu, Switcher_ItemTabWarnings) == 0xaf0, "Offset mismatch for UFortEmporiumItemListMenu::Switcher_ItemTabWarnings");
static_assert(offsetof(UFortEmporiumItemListMenu, Overlay_ChestEmpty) == 0xaf8, "Offset mismatch for UFortEmporiumItemListMenu::Overlay_ChestEmpty");
static_assert(offsetof(UFortEmporiumItemListMenu, Overlay_TabEmpty) == 0xb00, "Offset mismatch for UFortEmporiumItemListMenu::Overlay_TabEmpty");
static_assert(offsetof(UFortEmporiumItemListMenu, Overlay_DownloadingFabCategories) == 0xb08, "Offset mismatch for UFortEmporiumItemListMenu::Overlay_DownloadingFabCategories");
static_assert(offsetof(UFortEmporiumItemListMenu, Overlay_FabCategoriesNotLoaded) == 0xb10, "Offset mismatch for UFortEmporiumItemListMenu::Overlay_FabCategoriesNotLoaded");
static_assert(offsetof(UFortEmporiumItemListMenu, Switcher_CommandBar) == 0xb18, "Offset mismatch for UFortEmporiumItemListMenu::Switcher_CommandBar");
static_assert(offsetof(UFortEmporiumItemListMenu, Overlay_ChestCommands) == 0xb20, "Offset mismatch for UFortEmporiumItemListMenu::Overlay_ChestCommands");
static_assert(offsetof(UFortEmporiumItemListMenu, Overlay_VendCommands) == 0xb28, "Offset mismatch for UFortEmporiumItemListMenu::Overlay_VendCommands");
static_assert(offsetof(UFortEmporiumItemListMenu, MenuQuickbar_QuickBars) == 0xb30, "Offset mismatch for UFortEmporiumItemListMenu::MenuQuickbar_QuickBars");
static_assert(offsetof(UFortEmporiumItemListMenu, Button_ResetChest) == 0xb38, "Offset mismatch for UFortEmporiumItemListMenu::Button_ResetChest");
static_assert(offsetof(UFortEmporiumItemListMenu, Button_CreateChest) == 0xb40, "Offset mismatch for UFortEmporiumItemListMenu::Button_CreateChest");
static_assert(offsetof(UFortEmporiumItemListMenu, Button_AddToQuickBar) == 0xb48, "Offset mismatch for UFortEmporiumItemListMenu::Button_AddToQuickBar");
static_assert(offsetof(UFortEmporiumItemListMenu, Button_OpenItem) == 0xb50, "Offset mismatch for UFortEmporiumItemListMenu::Button_OpenItem");
static_assert(offsetof(UFortEmporiumItemListMenu, Button_PlaceNow) == 0xb58, "Offset mismatch for UFortEmporiumItemListMenu::Button_PlaceNow");
static_assert(offsetof(UFortEmporiumItemListMenu, Button_Equip) == 0xb60, "Offset mismatch for UFortEmporiumItemListMenu::Button_Equip");
static_assert(offsetof(UFortEmporiumItemListMenu, Button_AddToChest) == 0xb68, "Offset mismatch for UFortEmporiumItemListMenu::Button_AddToChest");
static_assert(offsetof(UFortEmporiumItemListMenu, Button_Drop) == 0xb70, "Offset mismatch for UFortEmporiumItemListMenu::Button_Drop");
static_assert(offsetof(UFortEmporiumItemListMenu, Button_CreateLlama) == 0xb78, "Offset mismatch for UFortEmporiumItemListMenu::Button_CreateLlama");
static_assert(offsetof(UFortEmporiumItemListMenu, Button_RemoveFromChest) == 0xb80, "Offset mismatch for UFortEmporiumItemListMenu::Button_RemoveFromChest");
static_assert(offsetof(UFortEmporiumItemListMenu, Overlay_SearchFilters) == 0xb88, "Offset mismatch for UFortEmporiumItemListMenu::Overlay_SearchFilters");
static_assert(offsetof(UFortEmporiumItemListMenu, Switcher_LeftPanel) == 0xb90, "Offset mismatch for UFortEmporiumItemListMenu::Switcher_LeftPanel");
static_assert(offsetof(UFortEmporiumItemListMenu, FiltersPanel) == 0xb98, "Offset mismatch for UFortEmporiumItemListMenu::FiltersPanel");
static_assert(offsetof(UFortEmporiumItemListMenu, FiltersSubPanel) == 0xba0, "Offset mismatch for UFortEmporiumItemListMenu::FiltersSubPanel");
static_assert(offsetof(UFortEmporiumItemListMenu, SubTabItemDetailsPanel) == 0xba8, "Offset mismatch for UFortEmporiumItemListMenu::SubTabItemDetailsPanel");
static_assert(offsetof(UFortEmporiumItemListMenu, Blade_SortAndFilter) == 0xbb0, "Offset mismatch for UFortEmporiumItemListMenu::Blade_SortAndFilter");
static_assert(offsetof(UFortEmporiumItemListMenu, ItemDetailsSidePanel_DefaultSidePanel) == 0xbb8, "Offset mismatch for UFortEmporiumItemListMenu::ItemDetailsSidePanel_DefaultSidePanel");
static_assert(offsetof(UFortEmporiumItemListMenu, Switcher_ProductPage) == 0xbc0, "Offset mismatch for UFortEmporiumItemListMenu::Switcher_ProductPage");
static_assert(offsetof(UFortEmporiumItemListMenu, Overlay_ItemBrowser) == 0xbc8, "Offset mismatch for UFortEmporiumItemListMenu::Overlay_ItemBrowser");
static_assert(offsetof(UFortEmporiumItemListMenu, ItemProductPagePanel) == 0xbd0, "Offset mismatch for UFortEmporiumItemListMenu::ItemProductPagePanel");
static_assert(offsetof(UFortEmporiumItemListMenu, Switcher_InventoryPermission) == 0xbd8, "Offset mismatch for UFortEmporiumItemListMenu::Switcher_InventoryPermission");
static_assert(offsetof(UFortEmporiumItemListMenu, Overlay_EmporiumPanel) == 0xbe0, "Offset mismatch for UFortEmporiumItemListMenu::Overlay_EmporiumPanel");
static_assert(offsetof(UFortEmporiumItemListMenu, Overlay_InventoryNotAllowed) == 0xbe8, "Offset mismatch for UFortEmporiumItemListMenu::Overlay_InventoryNotAllowed");
static_assert(offsetof(UFortEmporiumItemListMenu, Overlay_EditorDisconnected) == 0xbf0, "Offset mismatch for UFortEmporiumItemListMenu::Overlay_EditorDisconnected");
static_assert(offsetof(UFortEmporiumItemListMenu, Overlay_InitializingInventory) == 0xbf8, "Offset mismatch for UFortEmporiumItemListMenu::Overlay_InitializingInventory");

// Size: 0x7d0 (Inherited: 0xf80, Single: 0xfffff850)
class UFortEmporiumItemListTabPanel : public UFortCreativeContentBrowserTabPanelBase
{
public:
    uint8_t Pad_448[0x8]; // 0x448 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnSourceItemCountChanged[0x10]; // 0x450 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnItemClickedDelegate[0x10]; // 0x460 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnItemDoubleClickedDelegate[0x10]; // 0x470 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_480[0x40]; // 0x480 (Size: 0x40, Type: PaddingProperty)
    UAthenaCreativeItemTileView* CreativeTileView_ItemOptions; // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_Sort; // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    FFortItemEntry CurrentItemEntry; // 0x4d0 (Size: 0x158, Type: StructProperty)
    uint8_t OnItemCountChanged[0x10]; // 0x628 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<FFortItemEntry> Items; // 0x638 (Size: 0x10, Type: ArrayProperty)
    TArray<FFortItemEntry> SourceItems; // 0x648 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_658[0x160]; // 0x658 (Size: 0x160, Type: PaddingProperty)
    UFortEmporiumItemListMenu* EmporiumItemListMenuParent; // 0x7b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_7c0[0x10]; // 0x7c0 (Size: 0x10, Type: PaddingProperty)

public:
    void AddItem(FFortItemEntry ItemToAdd); // 0x11ecd918 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void AddItemToSource(FFortItemEntry ItemToAdd); // 0x11ecda38 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool CanPlayerCreateInVolume() const; // 0x11ece2b8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ClearAllItems(); // 0x11ece2f0 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void ClearFilteredItems(); // 0x11ece304 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    virtual void FocusCurrentSelection(); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    EFortItemCardSize GetCardSizeForCategory() const; // 0x11eced04 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetCollapseBorderPadFlagForCategory() const; // 0x11ecf070 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsEmpty(); // 0x11ed2f44 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure)
    virtual void ItemEquipped(const FFortItemEntry Item); // 0x288a61c (Index: 0xd, Flags: Event|Public|HasOutParms|BlueprintEvent)
    void OnEmporiumItemClickedDelegate__DelegateSignature(const FFortItemEntry ItemClicked); // 0x288a61c (Index: 0xe, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void OnEmporiumItemCountChangedDelegate__DelegateSignature(int32_t& Count); // 0x288a61c (Index: 0xf, Flags: MulticastDelegate|Public|Delegate)
    void OnEmporiumItemDoubleClickedDelegate__DelegateSignature(const FFortItemEntry ItemClicked); // 0x288a61c (Index: 0x10, Flags: MulticastDelegate|Public|Delegate|HasOutParms)
    void RemoveSelectedItem(); // 0x11ed3888 (Index: 0x11, Flags: Final|Native|Public|BlueprintCallable)
    void RestoreLastSelection(); // 0x11ed3dec (Index: 0x12, Flags: Final|Native|Public|BlueprintCallable)
    virtual void ShowLegacyFilterCounter(bool& bShow); // 0x288a61c (Index: 0x13, Flags: Event|Public|BlueprintEvent)
    bool ShowLegacyItemDetailsPanel() const; // 0x11ed4ce4 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void ShowTopButtonBar(bool& bShow); // 0x288a61c (Index: 0x15, Flags: Event|Public|BlueprintEvent)
    virtual void UpdateSortButton(const FText SortType); // 0x288a61c (Index: 0x16, Flags: Event|Public|HasOutParms|BlueprintEvent)
    virtual void UpdateTabHeader(); // 0x288a61c (Index: 0x17, Flags: Event|Public|BlueprintCallable|BlueprintEvent)

protected:
    UWidget* GetEmptyTabFocusWidget() const; // 0x11ecf5cc (Index: 0x8, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    UItemDefinitionBase* GetSubTabSelectedItemDefinition() const; // 0x11ecf7ec (Index: 0x9, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void HandleItemDetailTagSelected(const FName TagID); // 0x11ed1190 (Index: 0xa, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    bool IsSubTabOpened() const; // 0x11ed2fc0 (Index: 0xc, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UFortEmporiumItemListTabPanel) == 0x7d0, "Size mismatch for UFortEmporiumItemListTabPanel");
static_assert(offsetof(UFortEmporiumItemListTabPanel, OnSourceItemCountChanged) == 0x450, "Offset mismatch for UFortEmporiumItemListTabPanel::OnSourceItemCountChanged");
static_assert(offsetof(UFortEmporiumItemListTabPanel, OnItemClickedDelegate) == 0x460, "Offset mismatch for UFortEmporiumItemListTabPanel::OnItemClickedDelegate");
static_assert(offsetof(UFortEmporiumItemListTabPanel, OnItemDoubleClickedDelegate) == 0x470, "Offset mismatch for UFortEmporiumItemListTabPanel::OnItemDoubleClickedDelegate");
static_assert(offsetof(UFortEmporiumItemListTabPanel, CreativeTileView_ItemOptions) == 0x4c0, "Offset mismatch for UFortEmporiumItemListTabPanel::CreativeTileView_ItemOptions");
static_assert(offsetof(UFortEmporiumItemListTabPanel, Button_Sort) == 0x4c8, "Offset mismatch for UFortEmporiumItemListTabPanel::Button_Sort");
static_assert(offsetof(UFortEmporiumItemListTabPanel, CurrentItemEntry) == 0x4d0, "Offset mismatch for UFortEmporiumItemListTabPanel::CurrentItemEntry");
static_assert(offsetof(UFortEmporiumItemListTabPanel, OnItemCountChanged) == 0x628, "Offset mismatch for UFortEmporiumItemListTabPanel::OnItemCountChanged");
static_assert(offsetof(UFortEmporiumItemListTabPanel, Items) == 0x638, "Offset mismatch for UFortEmporiumItemListTabPanel::Items");
static_assert(offsetof(UFortEmporiumItemListTabPanel, SourceItems) == 0x648, "Offset mismatch for UFortEmporiumItemListTabPanel::SourceItems");
static_assert(offsetof(UFortEmporiumItemListTabPanel, EmporiumItemListMenuParent) == 0x7b8, "Offset mismatch for UFortEmporiumItemListTabPanel::EmporiumItemListMenuParent");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UEmporiumBrowserTag : public UObject
{
public:
    FName TagID; // 0x28 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UEmporiumBrowserTag) == 0x30, "Size mismatch for UEmporiumBrowserTag");
static_assert(offsetof(UEmporiumBrowserTag, TagID) == 0x28, "Offset mismatch for UEmporiumBrowserTag::TagID");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UFortEmporiumUtilities : public UBlueprintFunctionLibrary
{
public:

public:
    static bool BP_GetCategoryHierarchyEntry(const FName CategoryID, FFortEmporiumFilterCategory& OutFoundCategory); // 0x11ecdbcc (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FText GenerateDisplayNameForPlaysetPropDefinition(UFortPlaysetPropItemDefinition*& const PlaysetDefinition); // 0x11ece8c4 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FText GetCategoryDisplayName(const FName CategoryID); // 0x11eced1c (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FText GetCategoryLabelForPlaysetDefinition(UFortPlaysetItemDefinition*& const PlaysetDefinition); // 0x11ecee30 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TArray<FName> GetCreativeTagIDs(UItemDefinitionBase*& const ItemDefinition); // 0x11ecf088 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FText GetCreativeTagLabel(const FName TagID, bool& bOutIsBeta); // 0x11ecf384 (Index: 0x5, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FName GetShowAllButtonID(); // 0x11ecf7a8 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FText GetTextFromEmporiumLicense(EFortEmporiumItemLicense& const License); // 0x11ecf82c (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FName GetVerseEntityPrefabsCategoryID(); // 0x11ecf984 (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsCreativeBetaTag(const FName TagID); // 0x11ed2e24 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void RequestJSON(UObject*& const WorldContextObject, const FUniqueNetIdRepl UniqueNetId, FString& JSONURL, const FDelegate Callback); // 0x11ed38b0 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void RequestLicenseText(EFortEmporiumItemLicense& const License, const FDelegate Callback); // 0x11ed3c00 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool ShouldEnableRecentlyUsedList(); // 0x11ed4ccc (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static TArray<FName> SplitTagID(const FName TagID); // 0x11ed4fd0 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UFortEmporiumUtilities) == 0x28, "Size mismatch for UFortEmporiumUtilities");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFortEmporiumPriceFilterEntry
{
    FName ID; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FText Text; // 0x8 (Size: 0x10, Type: TextProperty)
    uint8_t Filter; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortEmporiumPriceFilterEntry) == 0x20, "Size mismatch for FFortEmporiumPriceFilterEntry");
static_assert(offsetof(FFortEmporiumPriceFilterEntry, ID) == 0x0, "Offset mismatch for FFortEmporiumPriceFilterEntry::ID");
static_assert(offsetof(FFortEmporiumPriceFilterEntry, Text) == 0x8, "Offset mismatch for FFortEmporiumPriceFilterEntry::Text");
static_assert(offsetof(FFortEmporiumPriceFilterEntry, Filter) == 0x18, "Offset mismatch for FFortEmporiumPriceFilterEntry::Filter");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFortEmporiumFilterEntry
{
    FName ID; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FText TextRoot; // 0x8 (Size: 0x10, Type: TextProperty)
    uint8_t Mode; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_19[0x7]; // 0x19 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortEmporiumFilterEntry) == 0x20, "Size mismatch for FFortEmporiumFilterEntry");
static_assert(offsetof(FFortEmporiumFilterEntry, ID) == 0x0, "Offset mismatch for FFortEmporiumFilterEntry::ID");
static_assert(offsetof(FFortEmporiumFilterEntry, TextRoot) == 0x8, "Offset mismatch for FFortEmporiumFilterEntry::TextRoot");
static_assert(offsetof(FFortEmporiumFilterEntry, Mode) == 0x18, "Offset mismatch for FFortEmporiumFilterEntry::Mode");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFortEmporiumSortEntry
{
    FText Text; // 0x0 (Size: 0x10, Type: TextProperty)
    uint8_t Mode; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FFortEmporiumSortEntry) == 0x18, "Size mismatch for FFortEmporiumSortEntry");
static_assert(offsetof(FFortEmporiumSortEntry, Text) == 0x0, "Offset mismatch for FFortEmporiumSortEntry::Text");
static_assert(offsetof(FFortEmporiumSortEntry, Mode) == 0x10, "Offset mismatch for FFortEmporiumSortEntry::Mode");

// Size: 0xe8 (Inherited: 0x0, Single: 0xe8)
struct FFortEmporiumItemData
{
    FString ID; // 0x0 (Size: 0x10, Type: StrProperty)
    FString Title; // 0x10 (Size: 0x10, Type: StrProperty)
    FString Namespace; // 0x20 (Size: 0x10, Type: StrProperty)
    FString EntityType; // 0x30 (Size: 0x10, Type: StrProperty)
    FString ThumbnailURL; // 0x40 (Size: 0x10, Type: StrProperty)
    float Price; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
    FString BaseCurrency; // 0x58 (Size: 0x10, Type: StrProperty)
    FString SketchfabUID; // 0x68 (Size: 0x10, Type: StrProperty)
    TArray<FName> TagList; // 0x78 (Size: 0x10, Type: ArrayProperty)
    uint8_t LicenseType; // 0x88 (Size: 0x1, Type: EnumProperty)
    bool bRequiresEntitlement; // 0x89 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_8a[0x6]; // 0x8a (Size: 0x6, Type: PaddingProperty)
    FString VersePath; // 0x90 (Size: 0x10, Type: StrProperty)
    TArray<FString> AssetIds; // 0xa0 (Size: 0x10, Type: ArrayProperty)
    int32_t FileSize; // 0xb0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_b4[0x4]; // 0xb4 (Size: 0x4, Type: PaddingProperty)
    FString Description; // 0xb8 (Size: 0x10, Type: StrProperty)
    FString Seller; // 0xc8 (Size: 0x10, Type: StrProperty)
    int32_t MaterialCount; // 0xd8 (Size: 0x4, Type: IntProperty)
    int32_t PolygonCount; // 0xdc (Size: 0x4, Type: IntProperty)
    int32_t VertexCount; // 0xe0 (Size: 0x4, Type: IntProperty)
    int32_t ChildAssetCount; // 0xe4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FFortEmporiumItemData) == 0xe8, "Size mismatch for FFortEmporiumItemData");
static_assert(offsetof(FFortEmporiumItemData, ID) == 0x0, "Offset mismatch for FFortEmporiumItemData::ID");
static_assert(offsetof(FFortEmporiumItemData, Title) == 0x10, "Offset mismatch for FFortEmporiumItemData::Title");
static_assert(offsetof(FFortEmporiumItemData, Namespace) == 0x20, "Offset mismatch for FFortEmporiumItemData::Namespace");
static_assert(offsetof(FFortEmporiumItemData, EntityType) == 0x30, "Offset mismatch for FFortEmporiumItemData::EntityType");
static_assert(offsetof(FFortEmporiumItemData, ThumbnailURL) == 0x40, "Offset mismatch for FFortEmporiumItemData::ThumbnailURL");
static_assert(offsetof(FFortEmporiumItemData, Price) == 0x50, "Offset mismatch for FFortEmporiumItemData::Price");
static_assert(offsetof(FFortEmporiumItemData, BaseCurrency) == 0x58, "Offset mismatch for FFortEmporiumItemData::BaseCurrency");
static_assert(offsetof(FFortEmporiumItemData, SketchfabUID) == 0x68, "Offset mismatch for FFortEmporiumItemData::SketchfabUID");
static_assert(offsetof(FFortEmporiumItemData, TagList) == 0x78, "Offset mismatch for FFortEmporiumItemData::TagList");
static_assert(offsetof(FFortEmporiumItemData, LicenseType) == 0x88, "Offset mismatch for FFortEmporiumItemData::LicenseType");
static_assert(offsetof(FFortEmporiumItemData, bRequiresEntitlement) == 0x89, "Offset mismatch for FFortEmporiumItemData::bRequiresEntitlement");
static_assert(offsetof(FFortEmporiumItemData, VersePath) == 0x90, "Offset mismatch for FFortEmporiumItemData::VersePath");
static_assert(offsetof(FFortEmporiumItemData, AssetIds) == 0xa0, "Offset mismatch for FFortEmporiumItemData::AssetIds");
static_assert(offsetof(FFortEmporiumItemData, FileSize) == 0xb0, "Offset mismatch for FFortEmporiumItemData::FileSize");
static_assert(offsetof(FFortEmporiumItemData, Description) == 0xb8, "Offset mismatch for FFortEmporiumItemData::Description");
static_assert(offsetof(FFortEmporiumItemData, Seller) == 0xc8, "Offset mismatch for FFortEmporiumItemData::Seller");
static_assert(offsetof(FFortEmporiumItemData, MaterialCount) == 0xd8, "Offset mismatch for FFortEmporiumItemData::MaterialCount");
static_assert(offsetof(FFortEmporiumItemData, PolygonCount) == 0xdc, "Offset mismatch for FFortEmporiumItemData::PolygonCount");
static_assert(offsetof(FFortEmporiumItemData, VertexCount) == 0xe0, "Offset mismatch for FFortEmporiumItemData::VertexCount");
static_assert(offsetof(FFortEmporiumItemData, ChildAssetCount) == 0xe4, "Offset mismatch for FFortEmporiumItemData::ChildAssetCount");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FFortEmporiumKeyEdgeMappings
{
    TArray<FKey> Keys; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortEmporiumKeyEdgeMappings) == 0x10, "Size mismatch for FFortEmporiumKeyEdgeMappings");
static_assert(offsetof(FFortEmporiumKeyEdgeMappings, Keys) == 0x0, "Offset mismatch for FFortEmporiumKeyEdgeMappings::Keys");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FFortEmporiumItemLicenseData
{
    FName ID; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FString Keyword; // 0x8 (Size: 0x10, Type: StrProperty)
    FText Name; // 0x18 (Size: 0x10, Type: TextProperty)
    uint8_t License; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    FString URL; // 0x30 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FFortEmporiumItemLicenseData) == 0x40, "Size mismatch for FFortEmporiumItemLicenseData");
static_assert(offsetof(FFortEmporiumItemLicenseData, ID) == 0x0, "Offset mismatch for FFortEmporiumItemLicenseData::ID");
static_assert(offsetof(FFortEmporiumItemLicenseData, Keyword) == 0x8, "Offset mismatch for FFortEmporiumItemLicenseData::Keyword");
static_assert(offsetof(FFortEmporiumItemLicenseData, Name) == 0x18, "Offset mismatch for FFortEmporiumItemLicenseData::Name");
static_assert(offsetof(FFortEmporiumItemLicenseData, License) == 0x28, "Offset mismatch for FFortEmporiumItemLicenseData::License");
static_assert(offsetof(FFortEmporiumItemLicenseData, URL) == 0x30, "Offset mismatch for FFortEmporiumItemLicenseData::URL");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFortEmporiumFilterCategory
{
    FName ID; // 0x0 (Size: 0x4, Type: NameProperty)
    FName ParentID; // 0x4 (Size: 0x4, Type: NameProperty)
    bool bIsTab; // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bShowCategoryModal; // 0x9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a[0x6]; // 0xa (Size: 0x6, Type: PaddingProperty)
    TArray<FName> SubcategoryIDList; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FFortEmporiumFilterCategory) == 0x20, "Size mismatch for FFortEmporiumFilterCategory");
static_assert(offsetof(FFortEmporiumFilterCategory, ID) == 0x0, "Offset mismatch for FFortEmporiumFilterCategory::ID");
static_assert(offsetof(FFortEmporiumFilterCategory, ParentID) == 0x4, "Offset mismatch for FFortEmporiumFilterCategory::ParentID");
static_assert(offsetof(FFortEmporiumFilterCategory, bIsTab) == 0x8, "Offset mismatch for FFortEmporiumFilterCategory::bIsTab");
static_assert(offsetof(FFortEmporiumFilterCategory, bShowCategoryModal) == 0x9, "Offset mismatch for FFortEmporiumFilterCategory::bShowCategoryModal");
static_assert(offsetof(FFortEmporiumFilterCategory, SubcategoryIDList) == 0x10, "Offset mismatch for FFortEmporiumFilterCategory::SubcategoryIDList");

