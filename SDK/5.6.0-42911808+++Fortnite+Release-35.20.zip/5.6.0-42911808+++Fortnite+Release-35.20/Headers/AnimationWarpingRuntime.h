/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimationWarpingRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "AnimGraphRuntime.h"
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAnimationWarpingLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool GetCurveValueFromAnimation(UAnimSequenceBase*& const Animation, FName& CurveName, float& time, float& OutValue); // 0xc695220 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FTransform GetOffsetRootTransform(const FAnimNodeReference Node); // 0xc695580 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UAnimationWarpingLibrary) == 0x28, "Size mismatch for UAnimationWarpingLibrary");

// Size: 0xb0 (Inherited: 0x10, Single: 0xa0)
struct FAnimNode_WarpTest : FAnimNode_Base
{
    FPoseLink Source; // 0x10 (Size: 0x10, Type: StructProperty)
    TArray<FTransform> Transforms; // 0x20 (Size: 0x10, Type: ArrayProperty)
    float SecondsToWait; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x7c]; // 0x34 (Size: 0x7c, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_WarpTest) == 0xb0, "Size mismatch for FAnimNode_WarpTest");
static_assert(offsetof(FAnimNode_WarpTest, Source) == 0x10, "Offset mismatch for FAnimNode_WarpTest::Source");
static_assert(offsetof(FAnimNode_WarpTest, Transforms) == 0x20, "Offset mismatch for FAnimNode_WarpTest::Transforms");
static_assert(offsetof(FAnimNode_WarpTest, SecondsToWait) == 0x30, "Offset mismatch for FAnimNode_WarpTest::SecondsToWait");

// Size: 0x2c (Inherited: 0x0, Single: 0x2c)
struct FFootPlacementInterpolationSettings
{
    float UnplantLinearStiffness; // 0x0 (Size: 0x4, Type: FloatProperty)
    float UnplantLinearDamping; // 0x4 (Size: 0x4, Type: FloatProperty)
    float UnplantAngularStiffness; // 0x8 (Size: 0x4, Type: FloatProperty)
    float UnplantAngularDamping; // 0xc (Size: 0x4, Type: FloatProperty)
    float SeparationStiffness; // 0x10 (Size: 0x4, Type: FloatProperty)
    float SeparationDamping; // 0x14 (Size: 0x4, Type: FloatProperty)
    float FloorLinearStiffness; // 0x18 (Size: 0x4, Type: FloatProperty)
    float FloorLinearDamping; // 0x1c (Size: 0x4, Type: FloatProperty)
    float FloorAngularStiffness; // 0x20 (Size: 0x4, Type: FloatProperty)
    float FloorAngularDamping; // 0x24 (Size: 0x4, Type: FloatProperty)
    bool bEnableFloorInterpolation; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bSmoothRootBone; // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bEnableSeparationInterpolation; // 0x2a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b[0x1]; // 0x2b (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(FFootPlacementInterpolationSettings) == 0x2c, "Size mismatch for FFootPlacementInterpolationSettings");
static_assert(offsetof(FFootPlacementInterpolationSettings, UnplantLinearStiffness) == 0x0, "Offset mismatch for FFootPlacementInterpolationSettings::UnplantLinearStiffness");
static_assert(offsetof(FFootPlacementInterpolationSettings, UnplantLinearDamping) == 0x4, "Offset mismatch for FFootPlacementInterpolationSettings::UnplantLinearDamping");
static_assert(offsetof(FFootPlacementInterpolationSettings, UnplantAngularStiffness) == 0x8, "Offset mismatch for FFootPlacementInterpolationSettings::UnplantAngularStiffness");
static_assert(offsetof(FFootPlacementInterpolationSettings, UnplantAngularDamping) == 0xc, "Offset mismatch for FFootPlacementInterpolationSettings::UnplantAngularDamping");
static_assert(offsetof(FFootPlacementInterpolationSettings, SeparationStiffness) == 0x10, "Offset mismatch for FFootPlacementInterpolationSettings::SeparationStiffness");
static_assert(offsetof(FFootPlacementInterpolationSettings, SeparationDamping) == 0x14, "Offset mismatch for FFootPlacementInterpolationSettings::SeparationDamping");
static_assert(offsetof(FFootPlacementInterpolationSettings, FloorLinearStiffness) == 0x18, "Offset mismatch for FFootPlacementInterpolationSettings::FloorLinearStiffness");
static_assert(offsetof(FFootPlacementInterpolationSettings, FloorLinearDamping) == 0x1c, "Offset mismatch for FFootPlacementInterpolationSettings::FloorLinearDamping");
static_assert(offsetof(FFootPlacementInterpolationSettings, FloorAngularStiffness) == 0x20, "Offset mismatch for FFootPlacementInterpolationSettings::FloorAngularStiffness");
static_assert(offsetof(FFootPlacementInterpolationSettings, FloorAngularDamping) == 0x24, "Offset mismatch for FFootPlacementInterpolationSettings::FloorAngularDamping");
static_assert(offsetof(FFootPlacementInterpolationSettings, bEnableFloorInterpolation) == 0x28, "Offset mismatch for FFootPlacementInterpolationSettings::bEnableFloorInterpolation");
static_assert(offsetof(FFootPlacementInterpolationSettings, bSmoothRootBone) == 0x29, "Offset mismatch for FFootPlacementInterpolationSettings::bSmoothRootBone");
static_assert(offsetof(FFootPlacementInterpolationSettings, bEnableSeparationInterpolation) == 0x2a, "Offset mismatch for FFootPlacementInterpolationSettings::bEnableSeparationInterpolation");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFootPlacementTraceSettings
{
    float StartOffset; // 0x0 (Size: 0x4, Type: FloatProperty)
    float EndOffset; // 0x4 (Size: 0x4, Type: FloatProperty)
    float SweepRadius; // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bDisableComplexTrace; // 0xc (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ETraceTypeQuery> ComplexTraceChannel; // 0xd (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_e[0x2]; // 0xe (Size: 0x2, Type: PaddingProperty)
    float MaxGroundPenetration; // 0x10 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETraceTypeQuery> SimpleTraceChannel; // 0x14 (Size: 0x1, Type: ByteProperty)
    bool bEnabled; // 0x15 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_16[0x2]; // 0x16 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FFootPlacementTraceSettings) == 0x18, "Size mismatch for FFootPlacementTraceSettings");
static_assert(offsetof(FFootPlacementTraceSettings, StartOffset) == 0x0, "Offset mismatch for FFootPlacementTraceSettings::StartOffset");
static_assert(offsetof(FFootPlacementTraceSettings, EndOffset) == 0x4, "Offset mismatch for FFootPlacementTraceSettings::EndOffset");
static_assert(offsetof(FFootPlacementTraceSettings, SweepRadius) == 0x8, "Offset mismatch for FFootPlacementTraceSettings::SweepRadius");
static_assert(offsetof(FFootPlacementTraceSettings, bDisableComplexTrace) == 0xc, "Offset mismatch for FFootPlacementTraceSettings::bDisableComplexTrace");
static_assert(offsetof(FFootPlacementTraceSettings, ComplexTraceChannel) == 0xd, "Offset mismatch for FFootPlacementTraceSettings::ComplexTraceChannel");
static_assert(offsetof(FFootPlacementTraceSettings, MaxGroundPenetration) == 0x10, "Offset mismatch for FFootPlacementTraceSettings::MaxGroundPenetration");
static_assert(offsetof(FFootPlacementTraceSettings, SimpleTraceChannel) == 0x14, "Offset mismatch for FFootPlacementTraceSettings::SimpleTraceChannel");
static_assert(offsetof(FFootPlacementTraceSettings, bEnabled) == 0x15, "Offset mismatch for FFootPlacementTraceSettings::bEnabled");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FFootPlacementRootDefinition
{
    FBoneReference PelvisBone; // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference IKRootBone; // 0xc (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(FFootPlacementRootDefinition) == 0x18, "Size mismatch for FFootPlacementRootDefinition");
static_assert(offsetof(FFootPlacementRootDefinition, PelvisBone) == 0x0, "Offset mismatch for FFootPlacementRootDefinition::PelvisBone");
static_assert(offsetof(FFootPlacementRootDefinition, IKRootBone) == 0xc, "Offset mismatch for FFootPlacementRootDefinition::IKRootBone");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FFootPlacementPelvisSettings
{
    float MaxOffset; // 0x0 (Size: 0x4, Type: FloatProperty)
    float LinearStiffness; // 0x4 (Size: 0x4, Type: FloatProperty)
    float LinearDamping; // 0x8 (Size: 0x4, Type: FloatProperty)
    float HorizontalRebalancingWeight; // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxOffsetHorizontal; // 0x10 (Size: 0x4, Type: FloatProperty)
    float HeelLiftRatio; // 0x14 (Size: 0x4, Type: FloatProperty)
    uint8_t PelvisHeightMode; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t ActorMovementCompensationMode; // 0x19 (Size: 0x1, Type: EnumProperty)
    bool bEnableInterpolation; // 0x1a (Size: 0x1, Type: BoolProperty)
    bool bDisablePelvisOffsetInAir; // 0x1b (Size: 0x1, Type: BoolProperty)
    FName DisablePelvisCurveName; // 0x1c (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FFootPlacementPelvisSettings) == 0x20, "Size mismatch for FFootPlacementPelvisSettings");
static_assert(offsetof(FFootPlacementPelvisSettings, MaxOffset) == 0x0, "Offset mismatch for FFootPlacementPelvisSettings::MaxOffset");
static_assert(offsetof(FFootPlacementPelvisSettings, LinearStiffness) == 0x4, "Offset mismatch for FFootPlacementPelvisSettings::LinearStiffness");
static_assert(offsetof(FFootPlacementPelvisSettings, LinearDamping) == 0x8, "Offset mismatch for FFootPlacementPelvisSettings::LinearDamping");
static_assert(offsetof(FFootPlacementPelvisSettings, HorizontalRebalancingWeight) == 0xc, "Offset mismatch for FFootPlacementPelvisSettings::HorizontalRebalancingWeight");
static_assert(offsetof(FFootPlacementPelvisSettings, MaxOffsetHorizontal) == 0x10, "Offset mismatch for FFootPlacementPelvisSettings::MaxOffsetHorizontal");
static_assert(offsetof(FFootPlacementPelvisSettings, HeelLiftRatio) == 0x14, "Offset mismatch for FFootPlacementPelvisSettings::HeelLiftRatio");
static_assert(offsetof(FFootPlacementPelvisSettings, PelvisHeightMode) == 0x18, "Offset mismatch for FFootPlacementPelvisSettings::PelvisHeightMode");
static_assert(offsetof(FFootPlacementPelvisSettings, ActorMovementCompensationMode) == 0x19, "Offset mismatch for FFootPlacementPelvisSettings::ActorMovementCompensationMode");
static_assert(offsetof(FFootPlacementPelvisSettings, bEnableInterpolation) == 0x1a, "Offset mismatch for FFootPlacementPelvisSettings::bEnableInterpolation");
static_assert(offsetof(FFootPlacementPelvisSettings, bDisablePelvisOffsetInAir) == 0x1b, "Offset mismatch for FFootPlacementPelvisSettings::bDisablePelvisOffsetInAir");
static_assert(offsetof(FFootPlacementPelvisSettings, DisablePelvisCurveName) == 0x1c, "Offset mismatch for FFootPlacementPelvisSettings::DisablePelvisCurveName");

// Size: 0x34 (Inherited: 0x0, Single: 0x34)
struct FFootPlacemenLegDefinition
{
    FBoneReference FKFootBone; // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference IKFootBone; // 0xc (Size: 0xc, Type: StructProperty)
    FBoneReference BallBone; // 0x18 (Size: 0xc, Type: StructProperty)
    int32_t NumBonesInLimb; // 0x24 (Size: 0x4, Type: IntProperty)
    FName SpeedCurveName; // 0x28 (Size: 0x4, Type: NameProperty)
    FName DisableLockCurveName; // 0x2c (Size: 0x4, Type: NameProperty)
    FName DisableLegCurveName; // 0x30 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FFootPlacemenLegDefinition) == 0x34, "Size mismatch for FFootPlacemenLegDefinition");
static_assert(offsetof(FFootPlacemenLegDefinition, FKFootBone) == 0x0, "Offset mismatch for FFootPlacemenLegDefinition::FKFootBone");
static_assert(offsetof(FFootPlacemenLegDefinition, IKFootBone) == 0xc, "Offset mismatch for FFootPlacemenLegDefinition::IKFootBone");
static_assert(offsetof(FFootPlacemenLegDefinition, BallBone) == 0x18, "Offset mismatch for FFootPlacemenLegDefinition::BallBone");
static_assert(offsetof(FFootPlacemenLegDefinition, NumBonesInLimb) == 0x24, "Offset mismatch for FFootPlacemenLegDefinition::NumBonesInLimb");
static_assert(offsetof(FFootPlacemenLegDefinition, SpeedCurveName) == 0x28, "Offset mismatch for FFootPlacemenLegDefinition::SpeedCurveName");
static_assert(offsetof(FFootPlacemenLegDefinition, DisableLockCurveName) == 0x2c, "Offset mismatch for FFootPlacemenLegDefinition::DisableLockCurveName");
static_assert(offsetof(FFootPlacemenLegDefinition, DisableLegCurveName) == 0x30, "Offset mismatch for FFootPlacemenLegDefinition::DisableLegCurveName");

// Size: 0x34 (Inherited: 0x0, Single: 0x34)
struct FFootPlacementPlantSettings
{
    float SpeedThreshold; // 0x0 (Size: 0x4, Type: FloatProperty)
    float DistanceToGround; // 0x4 (Size: 0x4, Type: FloatProperty)
    uint8_t LockType; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    float UnplantRadius; // 0xc (Size: 0x4, Type: FloatProperty)
    float ReplantRadiusRatio; // 0x10 (Size: 0x4, Type: FloatProperty)
    float UnplantAngle; // 0x14 (Size: 0x4, Type: FloatProperty)
    float ReplantAngleRatio; // 0x18 (Size: 0x4, Type: FloatProperty)
    float MaxExtensionRatio; // 0x1c (Size: 0x4, Type: FloatProperty)
    float MinExtensionRatio; // 0x20 (Size: 0x4, Type: FloatProperty)
    float SeparatingDistance; // 0x24 (Size: 0x4, Type: FloatProperty)
    float UnalignmentSpeedThreshold; // 0x28 (Size: 0x4, Type: FloatProperty)
    float AnkleTwistReduction; // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bReconstructWorldPlantFromVelocity; // 0x30 (Size: 0x1, Type: BoolProperty)
    bool bAdjustHeelBeforePlanting; // 0x31 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_32[0x2]; // 0x32 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FFootPlacementPlantSettings) == 0x34, "Size mismatch for FFootPlacementPlantSettings");
static_assert(offsetof(FFootPlacementPlantSettings, SpeedThreshold) == 0x0, "Offset mismatch for FFootPlacementPlantSettings::SpeedThreshold");
static_assert(offsetof(FFootPlacementPlantSettings, DistanceToGround) == 0x4, "Offset mismatch for FFootPlacementPlantSettings::DistanceToGround");
static_assert(offsetof(FFootPlacementPlantSettings, LockType) == 0x8, "Offset mismatch for FFootPlacementPlantSettings::LockType");
static_assert(offsetof(FFootPlacementPlantSettings, UnplantRadius) == 0xc, "Offset mismatch for FFootPlacementPlantSettings::UnplantRadius");
static_assert(offsetof(FFootPlacementPlantSettings, ReplantRadiusRatio) == 0x10, "Offset mismatch for FFootPlacementPlantSettings::ReplantRadiusRatio");
static_assert(offsetof(FFootPlacementPlantSettings, UnplantAngle) == 0x14, "Offset mismatch for FFootPlacementPlantSettings::UnplantAngle");
static_assert(offsetof(FFootPlacementPlantSettings, ReplantAngleRatio) == 0x18, "Offset mismatch for FFootPlacementPlantSettings::ReplantAngleRatio");
static_assert(offsetof(FFootPlacementPlantSettings, MaxExtensionRatio) == 0x1c, "Offset mismatch for FFootPlacementPlantSettings::MaxExtensionRatio");
static_assert(offsetof(FFootPlacementPlantSettings, MinExtensionRatio) == 0x20, "Offset mismatch for FFootPlacementPlantSettings::MinExtensionRatio");
static_assert(offsetof(FFootPlacementPlantSettings, SeparatingDistance) == 0x24, "Offset mismatch for FFootPlacementPlantSettings::SeparatingDistance");
static_assert(offsetof(FFootPlacementPlantSettings, UnalignmentSpeedThreshold) == 0x28, "Offset mismatch for FFootPlacementPlantSettings::UnalignmentSpeedThreshold");
static_assert(offsetof(FFootPlacementPlantSettings, AnkleTwistReduction) == 0x2c, "Offset mismatch for FFootPlacementPlantSettings::AnkleTwistReduction");
static_assert(offsetof(FFootPlacementPlantSettings, bReconstructWorldPlantFromVelocity) == 0x30, "Offset mismatch for FFootPlacementPlantSettings::bReconstructWorldPlantFromVelocity");
static_assert(offsetof(FFootPlacementPlantSettings, bAdjustHeelBeforePlanting) == 0x31, "Offset mismatch for FFootPlacementPlantSettings::bAdjustHeelBeforePlanting");

// Size: 0x4c0 (Inherited: 0xd8, Single: 0x3e8)
struct FAnimNode_FootPlacement : FAnimNode_SkeletalControlBase
{
    uint8_t PlantSpeedMode; // 0xc8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c9[0x3]; // 0xc9 (Size: 0x3, Type: PaddingProperty)
    FBoneReference IKFootRootBone; // 0xcc (Size: 0xc, Type: StructProperty)
    FBoneReference PelvisBone; // 0xd8 (Size: 0xc, Type: StructProperty)
    FFootPlacementPelvisSettings PelvisSettings; // 0xe4 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_104[0x4]; // 0x104 (Size: 0x4, Type: PaddingProperty)
    TArray<FFootPlacemenLegDefinition> LegDefinitions; // 0x108 (Size: 0x10, Type: ArrayProperty)
    FFootPlacementPlantSettings PlantSettings; // 0x118 (Size: 0x34, Type: StructProperty)
    FFootPlacementInterpolationSettings InterpolationSettings; // 0x14c (Size: 0x2c, Type: StructProperty)
    FFootPlacementTraceSettings TraceSettings; // 0x178 (Size: 0x18, Type: StructProperty)
    FVector BaseTranslationDelta; // 0x190 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_1a8[0x318]; // 0x1a8 (Size: 0x318, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_FootPlacement) == 0x4c0, "Size mismatch for FAnimNode_FootPlacement");
static_assert(offsetof(FAnimNode_FootPlacement, PlantSpeedMode) == 0xc8, "Offset mismatch for FAnimNode_FootPlacement::PlantSpeedMode");
static_assert(offsetof(FAnimNode_FootPlacement, IKFootRootBone) == 0xcc, "Offset mismatch for FAnimNode_FootPlacement::IKFootRootBone");
static_assert(offsetof(FAnimNode_FootPlacement, PelvisBone) == 0xd8, "Offset mismatch for FAnimNode_FootPlacement::PelvisBone");
static_assert(offsetof(FAnimNode_FootPlacement, PelvisSettings) == 0xe4, "Offset mismatch for FAnimNode_FootPlacement::PelvisSettings");
static_assert(offsetof(FAnimNode_FootPlacement, LegDefinitions) == 0x108, "Offset mismatch for FAnimNode_FootPlacement::LegDefinitions");
static_assert(offsetof(FAnimNode_FootPlacement, PlantSettings) == 0x118, "Offset mismatch for FAnimNode_FootPlacement::PlantSettings");
static_assert(offsetof(FAnimNode_FootPlacement, InterpolationSettings) == 0x14c, "Offset mismatch for FAnimNode_FootPlacement::InterpolationSettings");
static_assert(offsetof(FAnimNode_FootPlacement, TraceSettings) == 0x178, "Offset mismatch for FAnimNode_FootPlacement::TraceSettings");
static_assert(offsetof(FAnimNode_FootPlacement, BaseTranslationDelta) == 0x190, "Offset mismatch for FAnimNode_FootPlacement::BaseTranslationDelta");

// Size: 0x100 (Inherited: 0x10, Single: 0xf0)
struct FAnimNode_OffsetRootBone : FAnimNode_Base
{
    FPoseLink Source; // 0x10 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_20[0xe0]; // 0x20 (Size: 0xe0, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_OffsetRootBone) == 0x100, "Size mismatch for FAnimNode_OffsetRootBone");
static_assert(offsetof(FAnimNode_OffsetRootBone, Source) == 0x10, "Offset mismatch for FAnimNode_OffsetRootBone::Source");

// Size: 0x260 (Inherited: 0xd8, Single: 0x188)
struct FAnimNode_OrientationWarping : FAnimNode_SkeletalControlBase
{
    uint8_t Mode; // 0xc8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c9[0x3]; // 0xc9 (Size: 0x3, Type: PaddingProperty)
    float TargetTime; // 0xcc (Size: 0x4, Type: FloatProperty)
    float OrientationAngle; // 0xd0 (Size: 0x4, Type: FloatProperty)
    float LocomotionAngle; // 0xd4 (Size: 0x4, Type: FloatProperty)
    FVector LocomotionDirection; // 0xd8 (Size: 0x18, Type: StructProperty)
    float MinRootMotionSpeedThreshold; // 0xf0 (Size: 0x4, Type: FloatProperty)
    float LocomotionAngleDeltaThreshold; // 0xf4 (Size: 0x4, Type: FloatProperty)
    TArray<FBoneReference> SpineBones; // 0xf8 (Size: 0x10, Type: ArrayProperty)
    FBoneReference IKFootRootBone; // 0x108 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_114[0x4]; // 0x114 (Size: 0x4, Type: PaddingProperty)
    TArray<FBoneReference> IKFootBones; // 0x118 (Size: 0x10, Type: ArrayProperty)
    UAnimationAsset* CurrentAnimAsset; // 0x128 (Size: 0x8, Type: ObjectProperty)
    float CurrentAnimAssetTime; // 0x130 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EAxis> RotationAxis; // 0x134 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_135[0x3]; // 0x135 (Size: 0x3, Type: PaddingProperty)
    float DistributedBoneOrientationAlpha; // 0x138 (Size: 0x4, Type: FloatProperty)
    float RotationInterpSpeed; // 0x13c (Size: 0x4, Type: FloatProperty)
    float CounterCompensateInterpSpeed; // 0x140 (Size: 0x4, Type: FloatProperty)
    float MaxCorrectionDegrees; // 0x144 (Size: 0x4, Type: FloatProperty)
    float MaxRootMotionDeltaToCompensateDegrees; // 0x148 (Size: 0x4, Type: FloatProperty)
    bool bCounterCompenstateInterpolationByRootMotion; // 0x14c (Size: 0x1, Type: BoolProperty)
    bool bScaleByGlobalBlendWeight; // 0x14d (Size: 0x1, Type: BoolProperty)
    bool bUseManualRootMotionVelocity; // 0x14e (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_14f[0x1]; // 0x14f (Size: 0x1, Type: PaddingProperty)
    FVector ManualRootMotionVelocity; // 0x150 (Size: 0x18, Type: StructProperty)
    uint8_t WarpingSpace; // 0x168 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_169[0x7]; // 0x169 (Size: 0x7, Type: PaddingProperty)
    FTransform WarpingSpaceTransform; // 0x170 (Size: 0x60, Type: StructProperty)
    uint8_t Pad_1d0[0x90]; // 0x1d0 (Size: 0x90, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_OrientationWarping) == 0x260, "Size mismatch for FAnimNode_OrientationWarping");
static_assert(offsetof(FAnimNode_OrientationWarping, Mode) == 0xc8, "Offset mismatch for FAnimNode_OrientationWarping::Mode");
static_assert(offsetof(FAnimNode_OrientationWarping, TargetTime) == 0xcc, "Offset mismatch for FAnimNode_OrientationWarping::TargetTime");
static_assert(offsetof(FAnimNode_OrientationWarping, OrientationAngle) == 0xd0, "Offset mismatch for FAnimNode_OrientationWarping::OrientationAngle");
static_assert(offsetof(FAnimNode_OrientationWarping, LocomotionAngle) == 0xd4, "Offset mismatch for FAnimNode_OrientationWarping::LocomotionAngle");
static_assert(offsetof(FAnimNode_OrientationWarping, LocomotionDirection) == 0xd8, "Offset mismatch for FAnimNode_OrientationWarping::LocomotionDirection");
static_assert(offsetof(FAnimNode_OrientationWarping, MinRootMotionSpeedThreshold) == 0xf0, "Offset mismatch for FAnimNode_OrientationWarping::MinRootMotionSpeedThreshold");
static_assert(offsetof(FAnimNode_OrientationWarping, LocomotionAngleDeltaThreshold) == 0xf4, "Offset mismatch for FAnimNode_OrientationWarping::LocomotionAngleDeltaThreshold");
static_assert(offsetof(FAnimNode_OrientationWarping, SpineBones) == 0xf8, "Offset mismatch for FAnimNode_OrientationWarping::SpineBones");
static_assert(offsetof(FAnimNode_OrientationWarping, IKFootRootBone) == 0x108, "Offset mismatch for FAnimNode_OrientationWarping::IKFootRootBone");
static_assert(offsetof(FAnimNode_OrientationWarping, IKFootBones) == 0x118, "Offset mismatch for FAnimNode_OrientationWarping::IKFootBones");
static_assert(offsetof(FAnimNode_OrientationWarping, CurrentAnimAsset) == 0x128, "Offset mismatch for FAnimNode_OrientationWarping::CurrentAnimAsset");
static_assert(offsetof(FAnimNode_OrientationWarping, CurrentAnimAssetTime) == 0x130, "Offset mismatch for FAnimNode_OrientationWarping::CurrentAnimAssetTime");
static_assert(offsetof(FAnimNode_OrientationWarping, RotationAxis) == 0x134, "Offset mismatch for FAnimNode_OrientationWarping::RotationAxis");
static_assert(offsetof(FAnimNode_OrientationWarping, DistributedBoneOrientationAlpha) == 0x138, "Offset mismatch for FAnimNode_OrientationWarping::DistributedBoneOrientationAlpha");
static_assert(offsetof(FAnimNode_OrientationWarping, RotationInterpSpeed) == 0x13c, "Offset mismatch for FAnimNode_OrientationWarping::RotationInterpSpeed");
static_assert(offsetof(FAnimNode_OrientationWarping, CounterCompensateInterpSpeed) == 0x140, "Offset mismatch for FAnimNode_OrientationWarping::CounterCompensateInterpSpeed");
static_assert(offsetof(FAnimNode_OrientationWarping, MaxCorrectionDegrees) == 0x144, "Offset mismatch for FAnimNode_OrientationWarping::MaxCorrectionDegrees");
static_assert(offsetof(FAnimNode_OrientationWarping, MaxRootMotionDeltaToCompensateDegrees) == 0x148, "Offset mismatch for FAnimNode_OrientationWarping::MaxRootMotionDeltaToCompensateDegrees");
static_assert(offsetof(FAnimNode_OrientationWarping, bCounterCompenstateInterpolationByRootMotion) == 0x14c, "Offset mismatch for FAnimNode_OrientationWarping::bCounterCompenstateInterpolationByRootMotion");
static_assert(offsetof(FAnimNode_OrientationWarping, bScaleByGlobalBlendWeight) == 0x14d, "Offset mismatch for FAnimNode_OrientationWarping::bScaleByGlobalBlendWeight");
static_assert(offsetof(FAnimNode_OrientationWarping, bUseManualRootMotionVelocity) == 0x14e, "Offset mismatch for FAnimNode_OrientationWarping::bUseManualRootMotionVelocity");
static_assert(offsetof(FAnimNode_OrientationWarping, ManualRootMotionVelocity) == 0x150, "Offset mismatch for FAnimNode_OrientationWarping::ManualRootMotionVelocity");
static_assert(offsetof(FAnimNode_OrientationWarping, WarpingSpace) == 0x168, "Offset mismatch for FAnimNode_OrientationWarping::WarpingSpace");
static_assert(offsetof(FAnimNode_OrientationWarping, WarpingSpaceTransform) == 0x170, "Offset mismatch for FAnimNode_OrientationWarping::WarpingSpaceTransform");

// Size: 0x30 (Inherited: 0x10, Single: 0x20)
struct FAnimNode_OverrideRootMotion : FAnimNode_Base
{
    FPoseLink Source; // 0x10 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FAnimNode_OverrideRootMotion) == 0x30, "Size mismatch for FAnimNode_OverrideRootMotion");
static_assert(offsetof(FAnimNode_OverrideRootMotion, Source) == 0x10, "Offset mismatch for FAnimNode_OverrideRootMotion::Source");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FSlopeWarpingFootDefinition
{
    FBoneReference IKFootBone; // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference FKFootBone; // 0xc (Size: 0xc, Type: StructProperty)
    int32_t NumBonesInLimb; // 0x18 (Size: 0x4, Type: IntProperty)
    float FootSize; // 0x1c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FSlopeWarpingFootDefinition) == 0x20, "Size mismatch for FSlopeWarpingFootDefinition");
static_assert(offsetof(FSlopeWarpingFootDefinition, IKFootBone) == 0x0, "Offset mismatch for FSlopeWarpingFootDefinition::IKFootBone");
static_assert(offsetof(FSlopeWarpingFootDefinition, FKFootBone) == 0xc, "Offset mismatch for FSlopeWarpingFootDefinition::FKFootBone");
static_assert(offsetof(FSlopeWarpingFootDefinition, NumBonesInLimb) == 0x18, "Offset mismatch for FSlopeWarpingFootDefinition::NumBonesInLimb");
static_assert(offsetof(FSlopeWarpingFootDefinition, FootSize) == 0x1c, "Offset mismatch for FSlopeWarpingFootDefinition::FootSize");

// Size: 0xb0 (Inherited: 0x0, Single: 0xb0)
struct FSlopeWarpingFootData
{
};

static_assert(sizeof(FSlopeWarpingFootData) == 0xb0, "Size mismatch for FSlopeWarpingFootData");

// Size: 0x2d8 (Inherited: 0xd8, Single: 0x200)
struct FAnimNode_SlopeWarping : FAnimNode_SkeletalControlBase
{
    uint8_t Pad_c8[0x18]; // 0xc8 (Size: 0x18, Type: PaddingProperty)
    FBoneReference IKFootRootBone; // 0xe0 (Size: 0xc, Type: StructProperty)
    FBoneReference PelvisBone; // 0xec (Size: 0xc, Type: StructProperty)
    TArray<FSlopeWarpingFootDefinition> FeetDefinitions; // 0xf8 (Size: 0x10, Type: ArrayProperty)
    TArray<FSlopeWarpingFootData> FeetData; // 0x108 (Size: 0x10, Type: ArrayProperty)
    FVectorRK4SpringInterpolator PelvisOffsetInterpolator; // 0x118 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_120[0x58]; // 0x120 (Size: 0x58, Type: PaddingProperty)
    FVector GravityDir; // 0x178 (Size: 0x18, Type: StructProperty)
    FVector CustomFloorOffset; // 0x190 (Size: 0x18, Type: StructProperty)
    float CachedDeltaTime; // 0x1a8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1ac[0x4]; // 0x1ac (Size: 0x4, Type: PaddingProperty)
    FVector TargetFloorNormalWorldSpace; // 0x1b0 (Size: 0x18, Type: StructProperty)
    FVectorRK4SpringInterpolator FloorNormalInterpolator; // 0x1c8 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_1d0[0x58]; // 0x1d0 (Size: 0x58, Type: PaddingProperty)
    FVector TargetFloorOffsetLocalSpace; // 0x228 (Size: 0x18, Type: StructProperty)
    FVectorRK4SpringInterpolator FloorOffsetInterpolator; // 0x240 (Size: 0x8, Type: StructProperty)
    uint8_t Pad_248[0x58]; // 0x248 (Size: 0x58, Type: PaddingProperty)
    float MaxStepHeight; // 0x2a0 (Size: 0x4, Type: FloatProperty)
    uint8_t bKeepMeshInsideOfCapsule : 1; // 0x2a4:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bPullPelvisDown : 1; // 0x2a4:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bUseCustomFloorOffset : 1; // 0x2a4:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bWasOnGround : 1; // 0x2a4:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bShowDebug : 1; // 0x2a4:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bFloorSmoothingInitialized : 1; // 0x2a4:5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a5[0x3]; // 0x2a5 (Size: 0x3, Type: PaddingProperty)
    FVector ActorLocation; // 0x2a8 (Size: 0x18, Type: StructProperty)
    FVector GravityDirCompSpace; // 0x2c0 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FAnimNode_SlopeWarping) == 0x2d8, "Size mismatch for FAnimNode_SlopeWarping");
static_assert(offsetof(FAnimNode_SlopeWarping, IKFootRootBone) == 0xe0, "Offset mismatch for FAnimNode_SlopeWarping::IKFootRootBone");
static_assert(offsetof(FAnimNode_SlopeWarping, PelvisBone) == 0xec, "Offset mismatch for FAnimNode_SlopeWarping::PelvisBone");
static_assert(offsetof(FAnimNode_SlopeWarping, FeetDefinitions) == 0xf8, "Offset mismatch for FAnimNode_SlopeWarping::FeetDefinitions");
static_assert(offsetof(FAnimNode_SlopeWarping, FeetData) == 0x108, "Offset mismatch for FAnimNode_SlopeWarping::FeetData");
static_assert(offsetof(FAnimNode_SlopeWarping, PelvisOffsetInterpolator) == 0x118, "Offset mismatch for FAnimNode_SlopeWarping::PelvisOffsetInterpolator");
static_assert(offsetof(FAnimNode_SlopeWarping, GravityDir) == 0x178, "Offset mismatch for FAnimNode_SlopeWarping::GravityDir");
static_assert(offsetof(FAnimNode_SlopeWarping, CustomFloorOffset) == 0x190, "Offset mismatch for FAnimNode_SlopeWarping::CustomFloorOffset");
static_assert(offsetof(FAnimNode_SlopeWarping, CachedDeltaTime) == 0x1a8, "Offset mismatch for FAnimNode_SlopeWarping::CachedDeltaTime");
static_assert(offsetof(FAnimNode_SlopeWarping, TargetFloorNormalWorldSpace) == 0x1b0, "Offset mismatch for FAnimNode_SlopeWarping::TargetFloorNormalWorldSpace");
static_assert(offsetof(FAnimNode_SlopeWarping, FloorNormalInterpolator) == 0x1c8, "Offset mismatch for FAnimNode_SlopeWarping::FloorNormalInterpolator");
static_assert(offsetof(FAnimNode_SlopeWarping, TargetFloorOffsetLocalSpace) == 0x228, "Offset mismatch for FAnimNode_SlopeWarping::TargetFloorOffsetLocalSpace");
static_assert(offsetof(FAnimNode_SlopeWarping, FloorOffsetInterpolator) == 0x240, "Offset mismatch for FAnimNode_SlopeWarping::FloorOffsetInterpolator");
static_assert(offsetof(FAnimNode_SlopeWarping, MaxStepHeight) == 0x2a0, "Offset mismatch for FAnimNode_SlopeWarping::MaxStepHeight");
static_assert(offsetof(FAnimNode_SlopeWarping, bKeepMeshInsideOfCapsule) == 0x2a4, "Offset mismatch for FAnimNode_SlopeWarping::bKeepMeshInsideOfCapsule");
static_assert(offsetof(FAnimNode_SlopeWarping, bPullPelvisDown) == 0x2a4, "Offset mismatch for FAnimNode_SlopeWarping::bPullPelvisDown");
static_assert(offsetof(FAnimNode_SlopeWarping, bUseCustomFloorOffset) == 0x2a4, "Offset mismatch for FAnimNode_SlopeWarping::bUseCustomFloorOffset");
static_assert(offsetof(FAnimNode_SlopeWarping, bWasOnGround) == 0x2a4, "Offset mismatch for FAnimNode_SlopeWarping::bWasOnGround");
static_assert(offsetof(FAnimNode_SlopeWarping, bShowDebug) == 0x2a4, "Offset mismatch for FAnimNode_SlopeWarping::bShowDebug");
static_assert(offsetof(FAnimNode_SlopeWarping, bFloorSmoothingInitialized) == 0x2a4, "Offset mismatch for FAnimNode_SlopeWarping::bFloorSmoothingInitialized");
static_assert(offsetof(FAnimNode_SlopeWarping, ActorLocation) == 0x2a8, "Offset mismatch for FAnimNode_SlopeWarping::ActorLocation");
static_assert(offsetof(FAnimNode_SlopeWarping, GravityDirCompSpace) == 0x2c0, "Offset mismatch for FAnimNode_SlopeWarping::GravityDirCompSpace");

// Size: 0x1b0 (Inherited: 0xd8, Single: 0xd8)
struct FAnimNode_Steering : FAnimNode_SkeletalControlBase
{
    uint8_t Pad_c8[0x8]; // 0xc8 (Size: 0x8, Type: PaddingProperty)
    FQuat TargetOrientation; // 0xd0 (Size: 0x20, Type: StructProperty)
    bool bMirrored; // 0xf0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f1[0x3]; // 0xf1 (Size: 0x3, Type: PaddingProperty)
    float ProceduralTargetTime; // 0xf4 (Size: 0x4, Type: FloatProperty)
    float TargetTime; // 0xf8 (Size: 0x4, Type: FloatProperty)
    float AnimatedTargetTime; // 0xfc (Size: 0x4, Type: FloatProperty)
    float RootMotionThreshold; // 0x100 (Size: 0x4, Type: FloatProperty)
    float DisableSteeringBelowSpeed; // 0x104 (Size: 0x4, Type: FloatProperty)
    float DisableAdditiveBelowSpeed; // 0x108 (Size: 0x4, Type: FloatProperty)
    float MinScaleRatio; // 0x10c (Size: 0x4, Type: FloatProperty)
    float MaxScaleRatio; // 0x110 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_114[0x4]; // 0x114 (Size: 0x4, Type: PaddingProperty)
    UMirrorDataTable* MirrorDataTable; // 0x118 (Size: 0x8, Type: ObjectProperty)
    UAnimationAsset* CurrentAnimAsset; // 0x120 (Size: 0x8, Type: ObjectProperty)
    float CurrentAnimAssetTime; // 0x128 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_12c[0x84]; // 0x12c (Size: 0x84, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_Steering) == 0x1b0, "Size mismatch for FAnimNode_Steering");
static_assert(offsetof(FAnimNode_Steering, TargetOrientation) == 0xd0, "Offset mismatch for FAnimNode_Steering::TargetOrientation");
static_assert(offsetof(FAnimNode_Steering, bMirrored) == 0xf0, "Offset mismatch for FAnimNode_Steering::bMirrored");
static_assert(offsetof(FAnimNode_Steering, ProceduralTargetTime) == 0xf4, "Offset mismatch for FAnimNode_Steering::ProceduralTargetTime");
static_assert(offsetof(FAnimNode_Steering, TargetTime) == 0xf8, "Offset mismatch for FAnimNode_Steering::TargetTime");
static_assert(offsetof(FAnimNode_Steering, AnimatedTargetTime) == 0xfc, "Offset mismatch for FAnimNode_Steering::AnimatedTargetTime");
static_assert(offsetof(FAnimNode_Steering, RootMotionThreshold) == 0x100, "Offset mismatch for FAnimNode_Steering::RootMotionThreshold");
static_assert(offsetof(FAnimNode_Steering, DisableSteeringBelowSpeed) == 0x104, "Offset mismatch for FAnimNode_Steering::DisableSteeringBelowSpeed");
static_assert(offsetof(FAnimNode_Steering, DisableAdditiveBelowSpeed) == 0x108, "Offset mismatch for FAnimNode_Steering::DisableAdditiveBelowSpeed");
static_assert(offsetof(FAnimNode_Steering, MinScaleRatio) == 0x10c, "Offset mismatch for FAnimNode_Steering::MinScaleRatio");
static_assert(offsetof(FAnimNode_Steering, MaxScaleRatio) == 0x110, "Offset mismatch for FAnimNode_Steering::MaxScaleRatio");
static_assert(offsetof(FAnimNode_Steering, MirrorDataTable) == 0x118, "Offset mismatch for FAnimNode_Steering::MirrorDataTable");
static_assert(offsetof(FAnimNode_Steering, CurrentAnimAsset) == 0x120, "Offset mismatch for FAnimNode_Steering::CurrentAnimAsset");
static_assert(offsetof(FAnimNode_Steering, CurrentAnimAssetTime) == 0x128, "Offset mismatch for FAnimNode_Steering::CurrentAnimAssetTime");

// Size: 0x24 (Inherited: 0x0, Single: 0x24)
struct FStrideWarpingFootDefinition
{
    FBoneReference IKFootBone; // 0x0 (Size: 0xc, Type: StructProperty)
    FBoneReference FKFootBone; // 0xc (Size: 0xc, Type: StructProperty)
    FBoneReference ThighBone; // 0x18 (Size: 0xc, Type: StructProperty)
};

static_assert(sizeof(FStrideWarpingFootDefinition) == 0x24, "Size mismatch for FStrideWarpingFootDefinition");
static_assert(offsetof(FStrideWarpingFootDefinition, IKFootBone) == 0x0, "Offset mismatch for FStrideWarpingFootDefinition::IKFootBone");
static_assert(offsetof(FStrideWarpingFootDefinition, FKFootBone) == 0xc, "Offset mismatch for FStrideWarpingFootDefinition::FKFootBone");
static_assert(offsetof(FStrideWarpingFootDefinition, ThighBone) == 0x18, "Offset mismatch for FStrideWarpingFootDefinition::ThighBone");

// Size: 0x240 (Inherited: 0xd8, Single: 0x168)
struct FAnimNode_StrideWarping : FAnimNode_SkeletalControlBase
{
    uint8_t Mode; // 0xc8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_c9[0x7]; // 0xc9 (Size: 0x7, Type: PaddingProperty)
    FVector StrideDirection; // 0xd0 (Size: 0x18, Type: StructProperty)
    float StrideScale; // 0xe8 (Size: 0x4, Type: FloatProperty)
    float LocomotionSpeed; // 0xec (Size: 0x4, Type: FloatProperty)
    float MinRootMotionSpeedThreshold; // 0xf0 (Size: 0x4, Type: FloatProperty)
    FBoneReference PelvisBone; // 0xf4 (Size: 0xc, Type: StructProperty)
    FBoneReference IKFootRootBone; // 0x100 (Size: 0xc, Type: StructProperty)
    uint8_t Pad_10c[0x4]; // 0x10c (Size: 0x4, Type: PaddingProperty)
    TArray<FStrideWarpingFootDefinition> FootDefinitions; // 0x110 (Size: 0x10, Type: ArrayProperty)
    FInputClampConstants StrideScaleModifier; // 0x120 (Size: 0x14, Type: StructProperty)
    uint8_t Pad_134[0x4]; // 0x134 (Size: 0x4, Type: PaddingProperty)
    FWarpingVectorValue FloorNormalDirection; // 0x138 (Size: 0x20, Type: StructProperty)
    FWarpingVectorValue GravityDirection; // 0x158 (Size: 0x20, Type: StructProperty)
    FIKFootPelvisPullDownSolver PelvisIKFootSolver; // 0x178 (Size: 0x80, Type: StructProperty)
    bool bOrientStrideDirectionUsingFloorNormal; // 0x1f8 (Size: 0x1, Type: BoolProperty)
    bool bCompensateIKUsingFKThighRotation; // 0x1f9 (Size: 0x1, Type: BoolProperty)
    bool bClampIKUsingFKLimits; // 0x1fa (Size: 0x1, Type: BoolProperty)
    bool bDisableIfMissingRootMotion; // 0x1fb (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1fc[0x44]; // 0x1fc (Size: 0x44, Type: PaddingProperty)
};

static_assert(sizeof(FAnimNode_StrideWarping) == 0x240, "Size mismatch for FAnimNode_StrideWarping");
static_assert(offsetof(FAnimNode_StrideWarping, Mode) == 0xc8, "Offset mismatch for FAnimNode_StrideWarping::Mode");
static_assert(offsetof(FAnimNode_StrideWarping, StrideDirection) == 0xd0, "Offset mismatch for FAnimNode_StrideWarping::StrideDirection");
static_assert(offsetof(FAnimNode_StrideWarping, StrideScale) == 0xe8, "Offset mismatch for FAnimNode_StrideWarping::StrideScale");
static_assert(offsetof(FAnimNode_StrideWarping, LocomotionSpeed) == 0xec, "Offset mismatch for FAnimNode_StrideWarping::LocomotionSpeed");
static_assert(offsetof(FAnimNode_StrideWarping, MinRootMotionSpeedThreshold) == 0xf0, "Offset mismatch for FAnimNode_StrideWarping::MinRootMotionSpeedThreshold");
static_assert(offsetof(FAnimNode_StrideWarping, PelvisBone) == 0xf4, "Offset mismatch for FAnimNode_StrideWarping::PelvisBone");
static_assert(offsetof(FAnimNode_StrideWarping, IKFootRootBone) == 0x100, "Offset mismatch for FAnimNode_StrideWarping::IKFootRootBone");
static_assert(offsetof(FAnimNode_StrideWarping, FootDefinitions) == 0x110, "Offset mismatch for FAnimNode_StrideWarping::FootDefinitions");
static_assert(offsetof(FAnimNode_StrideWarping, StrideScaleModifier) == 0x120, "Offset mismatch for FAnimNode_StrideWarping::StrideScaleModifier");
static_assert(offsetof(FAnimNode_StrideWarping, FloorNormalDirection) == 0x138, "Offset mismatch for FAnimNode_StrideWarping::FloorNormalDirection");
static_assert(offsetof(FAnimNode_StrideWarping, GravityDirection) == 0x158, "Offset mismatch for FAnimNode_StrideWarping::GravityDirection");
static_assert(offsetof(FAnimNode_StrideWarping, PelvisIKFootSolver) == 0x178, "Offset mismatch for FAnimNode_StrideWarping::PelvisIKFootSolver");
static_assert(offsetof(FAnimNode_StrideWarping, bOrientStrideDirectionUsingFloorNormal) == 0x1f8, "Offset mismatch for FAnimNode_StrideWarping::bOrientStrideDirectionUsingFloorNormal");
static_assert(offsetof(FAnimNode_StrideWarping, bCompensateIKUsingFKThighRotation) == 0x1f9, "Offset mismatch for FAnimNode_StrideWarping::bCompensateIKUsingFKThighRotation");
static_assert(offsetof(FAnimNode_StrideWarping, bClampIKUsingFKLimits) == 0x1fa, "Offset mismatch for FAnimNode_StrideWarping::bClampIKUsingFKLimits");
static_assert(offsetof(FAnimNode_StrideWarping, bDisableIfMissingRootMotion) == 0x1fb, "Offset mismatch for FAnimNode_StrideWarping::bDisableIfMissingRootMotion");

