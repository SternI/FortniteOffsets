/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AIPatrolPath
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"
#include "AIModule.h"
#include "GameplayTags.h"
#include "FortniteAI.h"
#include "NavigationSystem.h"

// Size: 0x620 (Inherited: 0xdc0, Single: 0xfffff860)
class UAIPatrolPathEditorComponent : public UDebugDrawComponent
{
public:
};

static_assert(sizeof(UAIPatrolPathEditorComponent) == 0x620, "Size mismatch for UAIPatrolPathEditorComponent");

// Size: 0x3d0 (Inherited: 0xe0, Single: 0x2f0)
class UAIPatrolPathComponent : public UActorComponent
{
public:
    uint8_t Pad_b8[0x28]; // 0xb8 (Size: 0x28, Type: PaddingProperty)
    TArray<FString> SharedOptionNames; // 0xe0 (Size: 0x10, Type: ArrayProperty)
    TSoftClassPtr DefaultAIPawn; // 0xf0 (Size: 0x20, Type: SoftClassProperty)
    UClass* PathRendererClass; // 0x110 (Size: 0x8, Type: ClassProperty)
    bool bAllowPartialPaths; // 0x118 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_119[0x7]; // 0x119 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagContainer UnableToPlaceNewDeviceTags; // 0x120 (Size: 0x20, Type: StructProperty)
    FNavAgentProperties CachedAIAgentProperties; // 0x140 (Size: 0x30, Type: StructProperty)
    UNavigationSystemV1* CachedNavSystem; // 0x170 (Size: 0x8, Type: ObjectProperty)
    ANavigationData* CachedNavData; // 0x178 (Size: 0x8, Type: ObjectProperty)
    UClass* CachedFilterClass; // 0x180 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_188[0x10]; // 0x188 (Size: 0x10, Type: PaddingProperty)
    uint8_t OnNextPatrolPointFailedToReach[0x10]; // 0x198 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPatrolPointFailedToReach[0x10]; // 0x1a8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPatrolPointReached[0x10]; // 0x1b8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPatrolPathStarted[0x10]; // 0x1c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPatrolPathStopped[0x10]; // 0x1d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_1e8[0x8]; // 0x1e8 (Size: 0x8, Type: PaddingProperty)
    TArray<AActor*> PatrolPath; // 0x1f0 (Size: 0x10, Type: ArrayProperty)
    FPatrolPathSegmentDetails PathSegmentDetails; // 0x200 (Size: 0x108, Type: StructProperty)
    uint8_t Pad_308[0x10]; // 0x308 (Size: 0x10, Type: PaddingProperty)
    UAIPatrolPathComponent* CopiedFrom; // 0x318 (Size: 0x8, Type: ObjectProperty)
    AActor* CurrentCloningNode; // 0x320 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_328[0x8]; // 0x328 (Size: 0x8, Type: PaddingProperty)
    UAIPatrolPathComponent* CopiedFromCut; // 0x330 (Size: 0x8, Type: ObjectProperty)
    AFortCreativePatrolPath* PatrolPathActor; // 0x338 (Size: 0x8, Type: ObjectProperty)
    AFortAthenaPatrolPoint* PatrolPointActor; // 0x340 (Size: 0x8, Type: ObjectProperty)
    TArray<UAIPatrolPathComponent*> MultiSelectActorToEnterList; // 0x348 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_358[0x68]; // 0x358 (Size: 0x68, Type: PaddingProperty)
    bool bCurrentlyPropagatingSharedOptions; // 0x3c0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3c1[0x7]; // 0x3c1 (Size: 0x7, Type: PaddingProperty)
    UAIPatrolPathEditorComponent* PatrolPathEditorComponent; // 0x3c8 (Size: 0x8, Type: ObjectProperty)

public:
    void GeneratePathPoints(EFortCreativePatrolPathGroup& const PatrolPathGroup, bool& const bGenerationCausedByDuplication); // 0x11333800 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    TArray<UAIPatrolPathComponent*> GetLinkedPatrolPoints() const; // 0x11333a0c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetNextAvailablePatrolPathIndex(int32_t& NextAvailableIndex) const; // 0x11333a78 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    virtual UClass* GetPatrolFilterOptions(); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    virtual EPatrollingMode GetPatrollingMode() const; // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent|Const)
    virtual EFortCreativePatrolPathGroup GetPatrolPathGroup() const; // 0x288a61c (Index: 0x6, Flags: Event|Public|BlueprintEvent|Const)
    int32_t GetPatrolPathIndex() const; // 0x11333b6c (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual int32_t GetPatrolPathIndexFromDevice() const; // 0x288a61c (Index: 0x8, Flags: Event|Public|BlueprintEvent|Const)
    UAIPatrolPathComponent* GetPatrolPathPoint(int32_t& const InPatrolPathIndex, int32_t& const InPatrolPathPointIndex) const; // 0x11333b90 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetPatrolPathPointIndex() const; // 0x11333da8 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual int32_t GetPatrolPathPointIndexFromDevice() const; // 0x288a61c (Index: 0xb, Flags: Event|Public|BlueprintEvent|Const)
    bool HasValidPatrolPath() const; // 0x11333dcc (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void OnPathExtremitiesChanged(bool& const bIsStart, bool& const bIsEnd); // 0x288a61c (Index: 0x10, Flags: Event|Public|BlueprintEvent)
    virtual void OnPatrolPathActorAssigned(); // 0x288a61c (Index: 0x11, Flags: Event|Public|BlueprintEvent)
    void PostFinishSpawningActor(); // 0x11334764 (Index: 0x16, Flags: Final|Native|Public|BlueprintCallable)
    bool RemovePoint(); // 0x11334778 (Index: 0x19, Flags: Final|Native|Public|BlueprintCallable)
    void RenderToNextAndPreviousPoint(); // 0x1133479c (Index: 0x1a, Flags: Final|Native|Public|BlueprintCallable)
    void RenderToNextPoint(); // 0x11334808 (Index: 0x1b, Flags: Final|Native|Public|BlueprintCallable)
    void RequestRenderPath(); // 0x1133481c (Index: 0x1c, Flags: Final|Native|Public|BlueprintCallable)
    void SetPatrollingMode(EPatrollingMode& const NewMode); // 0x11334a7c (Index: 0x1d, Flags: Final|Native|Public|BlueprintCallable)
    void SetPatrolPathEnabled(bool& const bIsEnabled); // 0x11334830 (Index: 0x1e, Flags: Final|Native|Public|BlueprintCallable)
    void SetPatrolPathGroup(EFortCreativePatrolPathGroup& const PatrolPathGroup); // 0x11334958 (Index: 0x1f, Flags: Final|Native|Public|BlueprintCallable)
    void SetRenderPath(bool& const bRenderPath); // 0x11334bb4 (Index: 0x20, Flags: Final|Native|Public|BlueprintCallable)
    void UpdateEditorComponent(); // 0x554e3c4 (Index: 0x22, Flags: Final|Native|Public|BlueprintCallable)

private:
    void NextPatrolPointFailedToReach(AFortAthenaPatrolPoint*& PathPoint, AAIController*& PatrolInstigator); // 0x11333e18 (Index: 0xd, Flags: Final|Native|Private)
    void PatrolPathStarted(AAIController*& Instigator); // 0x11334020 (Index: 0x12, Flags: Final|Native|Private)
    void PatrolPathStopped(AAIController*& Instigator); // 0x1133414c (Index: 0x13, Flags: Final|Native|Private)
    void PatrolPointFailedToReach(AFortAthenaPatrolPoint*& PathPoint, AAIController*& Instigator); // 0x11334278 (Index: 0x14, Flags: Final|Native|Private)
    void PatrolPointReached(AFortAthenaPatrolPoint*& PathPoint, AAIController*& Instigator, bool& bReachedBackward); // 0x11334480 (Index: 0x15, Flags: Final|Native|Private)

protected:
    bool CanNextPointBeReached() const; // 0x113337e0 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void NotifyEditorUserOptionChanged(const TArray<FString> UserOptions); // 0xcf2734c (Index: 0xe, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    void OnAnyPropertyChanged(); // 0x554e3c4 (Index: 0xf, Flags: Final|Native|Protected)
    virtual void PropagatePatrolPathIndexToDevice(int32_t& const NewPatrolPathIndex); // 0x288a61c (Index: 0x17, Flags: Event|Protected|BlueprintEvent)
    virtual void PropagatePatrolPathPointIndexToDevice(int32_t& const NewPatrolPathPointIndex); // 0x288a61c (Index: 0x18, Flags: Event|Protected|BlueprintEvent)
    virtual bool ShouldRenderPath(); // 0x288a61c (Index: 0x21, Flags: Event|Protected|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UAIPatrolPathComponent) == 0x3d0, "Size mismatch for UAIPatrolPathComponent");
static_assert(offsetof(UAIPatrolPathComponent, SharedOptionNames) == 0xe0, "Offset mismatch for UAIPatrolPathComponent::SharedOptionNames");
static_assert(offsetof(UAIPatrolPathComponent, DefaultAIPawn) == 0xf0, "Offset mismatch for UAIPatrolPathComponent::DefaultAIPawn");
static_assert(offsetof(UAIPatrolPathComponent, PathRendererClass) == 0x110, "Offset mismatch for UAIPatrolPathComponent::PathRendererClass");
static_assert(offsetof(UAIPatrolPathComponent, bAllowPartialPaths) == 0x118, "Offset mismatch for UAIPatrolPathComponent::bAllowPartialPaths");
static_assert(offsetof(UAIPatrolPathComponent, UnableToPlaceNewDeviceTags) == 0x120, "Offset mismatch for UAIPatrolPathComponent::UnableToPlaceNewDeviceTags");
static_assert(offsetof(UAIPatrolPathComponent, CachedAIAgentProperties) == 0x140, "Offset mismatch for UAIPatrolPathComponent::CachedAIAgentProperties");
static_assert(offsetof(UAIPatrolPathComponent, CachedNavSystem) == 0x170, "Offset mismatch for UAIPatrolPathComponent::CachedNavSystem");
static_assert(offsetof(UAIPatrolPathComponent, CachedNavData) == 0x178, "Offset mismatch for UAIPatrolPathComponent::CachedNavData");
static_assert(offsetof(UAIPatrolPathComponent, CachedFilterClass) == 0x180, "Offset mismatch for UAIPatrolPathComponent::CachedFilterClass");
static_assert(offsetof(UAIPatrolPathComponent, OnNextPatrolPointFailedToReach) == 0x198, "Offset mismatch for UAIPatrolPathComponent::OnNextPatrolPointFailedToReach");
static_assert(offsetof(UAIPatrolPathComponent, OnPatrolPointFailedToReach) == 0x1a8, "Offset mismatch for UAIPatrolPathComponent::OnPatrolPointFailedToReach");
static_assert(offsetof(UAIPatrolPathComponent, OnPatrolPointReached) == 0x1b8, "Offset mismatch for UAIPatrolPathComponent::OnPatrolPointReached");
static_assert(offsetof(UAIPatrolPathComponent, OnPatrolPathStarted) == 0x1c8, "Offset mismatch for UAIPatrolPathComponent::OnPatrolPathStarted");
static_assert(offsetof(UAIPatrolPathComponent, OnPatrolPathStopped) == 0x1d8, "Offset mismatch for UAIPatrolPathComponent::OnPatrolPathStopped");
static_assert(offsetof(UAIPatrolPathComponent, PatrolPath) == 0x1f0, "Offset mismatch for UAIPatrolPathComponent::PatrolPath");
static_assert(offsetof(UAIPatrolPathComponent, PathSegmentDetails) == 0x200, "Offset mismatch for UAIPatrolPathComponent::PathSegmentDetails");
static_assert(offsetof(UAIPatrolPathComponent, CopiedFrom) == 0x318, "Offset mismatch for UAIPatrolPathComponent::CopiedFrom");
static_assert(offsetof(UAIPatrolPathComponent, CurrentCloningNode) == 0x320, "Offset mismatch for UAIPatrolPathComponent::CurrentCloningNode");
static_assert(offsetof(UAIPatrolPathComponent, CopiedFromCut) == 0x330, "Offset mismatch for UAIPatrolPathComponent::CopiedFromCut");
static_assert(offsetof(UAIPatrolPathComponent, PatrolPathActor) == 0x338, "Offset mismatch for UAIPatrolPathComponent::PatrolPathActor");
static_assert(offsetof(UAIPatrolPathComponent, PatrolPointActor) == 0x340, "Offset mismatch for UAIPatrolPathComponent::PatrolPointActor");
static_assert(offsetof(UAIPatrolPathComponent, MultiSelectActorToEnterList) == 0x348, "Offset mismatch for UAIPatrolPathComponent::MultiSelectActorToEnterList");
static_assert(offsetof(UAIPatrolPathComponent, bCurrentlyPropagatingSharedOptions) == 0x3c0, "Offset mismatch for UAIPatrolPathComponent::bCurrentlyPropagatingSharedOptions");
static_assert(offsetof(UAIPatrolPathComponent, PatrolPathEditorComponent) == 0x3c8, "Offset mismatch for UAIPatrolPathComponent::PatrolPathEditorComponent");

// Size: 0x108 (Inherited: 0x0, Single: 0x108)
struct FPatrolPathSegmentDetails
{
    UAIPatrolPathComponent* Start; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_c0[0x48]; // 0xc0 (Size: 0x48, Type: PaddingProperty)
};

static_assert(sizeof(FPatrolPathSegmentDetails) == 0x108, "Size mismatch for FPatrolPathSegmentDetails");
static_assert(offsetof(FPatrolPathSegmentDetails, Start) == 0xb8, "Offset mismatch for FPatrolPathSegmentDetails::Start");

