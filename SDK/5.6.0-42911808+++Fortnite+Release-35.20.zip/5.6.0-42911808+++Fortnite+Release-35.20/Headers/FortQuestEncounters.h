/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortQuestEncounters
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "EncountersRuntime.h"
#include "FortniteGame.h"
#include "LagerRuntime.h"
#include "GameplayTags.h"
#include "Engine.h"

// Size: 0x48 (Inherited: 0x28, Single: 0x20)
class UFortQuestEncounterHotfixData : public UObject
{
public:
    TArray<FString> DisabledScenarios; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> DisabledSpawners; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UFortQuestEncounterHotfixData) == 0x48, "Size mismatch for UFortQuestEncounterHotfixData");
static_assert(offsetof(UFortQuestEncounterHotfixData, DisabledScenarios) == 0x28, "Offset mismatch for UFortQuestEncounterHotfixData::DisabledScenarios");
static_assert(offsetof(UFortQuestEncounterHotfixData, DisabledSpawners) == 0x38, "Offset mismatch for UFortQuestEncounterHotfixData::DisabledSpawners");

// Size: 0x9a0 (Inherited: 0x1af0, Single: 0xffffeeb0)
class AFortQuestEncounterGameplayVolume : public AEncounterGameplayVolume
{
public:
    bool bShouldOverridePlayspaceParticipation; // 0x950 (Size: 0x1, Type: BoolProperty)
    bool bShouldOverrideQuestSpatialRelevancy; // 0x951 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_952[0x6]; // 0x952 (Size: 0x6, Type: PaddingProperty)
    FGameplayTagQuery IncludedOverlapTagQuery; // 0x958 (Size: 0x48, Type: StructProperty)
};

static_assert(sizeof(AFortQuestEncounterGameplayVolume) == 0x9a0, "Size mismatch for AFortQuestEncounterGameplayVolume");
static_assert(offsetof(AFortQuestEncounterGameplayVolume, bShouldOverridePlayspaceParticipation) == 0x950, "Offset mismatch for AFortQuestEncounterGameplayVolume::bShouldOverridePlayspaceParticipation");
static_assert(offsetof(AFortQuestEncounterGameplayVolume, bShouldOverrideQuestSpatialRelevancy) == 0x951, "Offset mismatch for AFortQuestEncounterGameplayVolume::bShouldOverrideQuestSpatialRelevancy");
static_assert(offsetof(AFortQuestEncounterGameplayVolume, IncludedOverlapTagQuery) == 0x958, "Offset mismatch for AFortQuestEncounterGameplayVolume::IncludedOverlapTagQuery");

// Size: 0x428 (Inherited: 0x928, Single: 0xfffffb00)
class AFortQuestEncounterSpawnerVolume : public AFortOverlapTrackingVolume
{
public:
    USceneComponent* ComponentAnchor; // 0x370 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* EncounterSpawnPoint; // 0x378 (Size: 0x8, Type: ObjectProperty)
    FInstancedStruct EncounterTrigger; // 0x380 (Size: 0x10, Type: StructProperty)
    TArray<FEncounterPrefabInfo> EncounterEntries; // 0x390 (Size: 0x10, Type: ArrayProperty)
    FName SpawnerVolumeName; // 0x3a0 (Size: 0x4, Type: NameProperty)
    bool bAllowInclusionInExternalOverlaps; // 0x3a4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3a5[0x3]; // 0x3a5 (Size: 0x3, Type: PaddingProperty)
    ALivingWorldEncounterPrefab* LivingWorldPrefab; // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_3b0[0x60]; // 0x3b0 (Size: 0x60, Type: PaddingProperty)
    TArray<FFilteredEventReceiverHandle> VerbHandles; // 0x410 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_420[0x8]; // 0x420 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(AFortQuestEncounterSpawnerVolume) == 0x428, "Size mismatch for AFortQuestEncounterSpawnerVolume");
static_assert(offsetof(AFortQuestEncounterSpawnerVolume, ComponentAnchor) == 0x370, "Offset mismatch for AFortQuestEncounterSpawnerVolume::ComponentAnchor");
static_assert(offsetof(AFortQuestEncounterSpawnerVolume, EncounterSpawnPoint) == 0x378, "Offset mismatch for AFortQuestEncounterSpawnerVolume::EncounterSpawnPoint");
static_assert(offsetof(AFortQuestEncounterSpawnerVolume, EncounterTrigger) == 0x380, "Offset mismatch for AFortQuestEncounterSpawnerVolume::EncounterTrigger");
static_assert(offsetof(AFortQuestEncounterSpawnerVolume, EncounterEntries) == 0x390, "Offset mismatch for AFortQuestEncounterSpawnerVolume::EncounterEntries");
static_assert(offsetof(AFortQuestEncounterSpawnerVolume, SpawnerVolumeName) == 0x3a0, "Offset mismatch for AFortQuestEncounterSpawnerVolume::SpawnerVolumeName");
static_assert(offsetof(AFortQuestEncounterSpawnerVolume, bAllowInclusionInExternalOverlaps) == 0x3a4, "Offset mismatch for AFortQuestEncounterSpawnerVolume::bAllowInclusionInExternalOverlaps");
static_assert(offsetof(AFortQuestEncounterSpawnerVolume, LivingWorldPrefab) == 0x3a8, "Offset mismatch for AFortQuestEncounterSpawnerVolume::LivingWorldPrefab");
static_assert(offsetof(AFortQuestEncounterSpawnerVolume, VerbHandles) == 0x410, "Offset mismatch for AFortQuestEncounterSpawnerVolume::VerbHandles");

// Size: 0xa88 (Inherited: 0x2e78, Single: 0xffffdc10)
class ALivingWorldEncounterPrefab_QuestEncounters : public ALivingWorldEncounterPrefab
{
public:
};

static_assert(sizeof(ALivingWorldEncounterPrefab_QuestEncounters) == 0xa88, "Size mismatch for ALivingWorldEncounterPrefab_QuestEncounters");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FQuestEncounterTriggerType
{
};

static_assert(sizeof(FQuestEncounterTriggerType) == 0x8, "Size mismatch for FQuestEncounterTriggerType");

// Size: 0x8 (Inherited: 0x8, Single: 0x0)
struct FQuestEncounterTriggerType_VolumeEntered : FQuestEncounterTriggerType
{
};

static_assert(sizeof(FQuestEncounterTriggerType_VolumeEntered) == 0x8, "Size mismatch for FQuestEncounterTriggerType_VolumeEntered");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FQuestEncounterTriggerType_RequiredQuest : FQuestEncounterTriggerType
{
    UFortQuestItemDefinition* RequiredQuest; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FQuestEncounterTriggerType_RequiredQuest) == 0x10, "Size mismatch for FQuestEncounterTriggerType_RequiredQuest");
static_assert(offsetof(FQuestEncounterTriggerType_RequiredQuest, RequiredQuest) == 0x8, "Offset mismatch for FQuestEncounterTriggerType_RequiredQuest::RequiredQuest");

// Size: 0x20 (Inherited: 0x8, Single: 0x18)
struct FQuestEncounterTriggerType_EventTrigger : FQuestEncounterTriggerType
{
    TArray<FInstancedStruct> EventVerbs; // 0x8 (Size: 0x10, Type: ArrayProperty)
    int32_t DesiredCount; // 0x18 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FQuestEncounterTriggerType_EventTrigger) == 0x20, "Size mismatch for FQuestEncounterTriggerType_EventTrigger");
static_assert(offsetof(FQuestEncounterTriggerType_EventTrigger, EventVerbs) == 0x8, "Offset mismatch for FQuestEncounterTriggerType_EventTrigger::EventVerbs");
static_assert(offsetof(FQuestEncounterTriggerType_EventTrigger, DesiredCount) == 0x18, "Offset mismatch for FQuestEncounterTriggerType_EventTrigger::DesiredCount");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
struct FQuestEncounterTriggerType_QuestAndEventTrigger : FQuestEncounterTriggerType_EventTrigger
{
    UFortQuestItemDefinition* RequiredQuest; // 0x20 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FQuestEncounterTriggerType_QuestAndEventTrigger) == 0x28, "Size mismatch for FQuestEncounterTriggerType_QuestAndEventTrigger");
static_assert(offsetof(FQuestEncounterTriggerType_QuestAndEventTrigger, RequiredQuest) == 0x20, "Offset mismatch for FQuestEncounterTriggerType_QuestAndEventTrigger::RequiredQuest");

