/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioCapture
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "AudioMixer.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0xb0 (Inherited: 0xd0, Single: 0xffffffe0)
class UAudioCapture : public UAudioGenerator
{
public:

public:
    bool GetAudioCaptureDeviceInfo(FAudioCaptureDeviceInfo& OutInfo); // 0x10137ff4 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool IsCapturingAudio(); // 0x101382ac (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void StartCapturingAudio(); // 0x101382e4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void StopCapturingAudio(); // 0x10138318 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioCapture) == 0xb0, "Size mismatch for UAudioCapture");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioCaptureFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static UAudioCapture* CreateAudioCapture(); // 0x10137fd0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioCaptureFunctionLibrary) == 0x28, "Size mismatch for UAudioCaptureFunctionLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAudioCaptureBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FString Conv_AudioInputDeviceInfoToString(const FAudioInputDeviceInfo Info); // 0x10137e34 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void GetAvailableAudioInputDevices(UObject*& const WorldContextObject, const FDelegate OnObtainDevicesEvent); // 0x101380d4 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UAudioCaptureBlueprintLibrary) == 0x28, "Size mismatch for UAudioCaptureBlueprintLibrary");

// Size: 0x960 (Inherited: 0xbc0, Single: 0xfffffda0)
class UAudioCaptureComponent : public USynthComponent
{
public:
    int32_t JitterLatencyFrames; // 0x8a0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_8a4[0xbc]; // 0x8a4 (Size: 0xbc, Type: PaddingProperty)
};

static_assert(sizeof(UAudioCaptureComponent) == 0x960, "Size mismatch for UAudioCaptureComponent");
static_assert(offsetof(UAudioCaptureComponent, JitterLatencyFrames) == 0x8a0, "Offset mismatch for UAudioCaptureComponent::JitterLatencyFrames");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FAudioInputDeviceInfo
{
    FString DeviceName; // 0x0 (Size: 0x10, Type: StrProperty)
    FString DeviceID; // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t InputChannels; // 0x20 (Size: 0x4, Type: IntProperty)
    int32_t PreferredSampleRate; // 0x24 (Size: 0x4, Type: IntProperty)
    uint8_t bSupportsHardwareAEC : 1; // 0x28:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FAudioInputDeviceInfo) == 0x30, "Size mismatch for FAudioInputDeviceInfo");
static_assert(offsetof(FAudioInputDeviceInfo, DeviceName) == 0x0, "Offset mismatch for FAudioInputDeviceInfo::DeviceName");
static_assert(offsetof(FAudioInputDeviceInfo, DeviceID) == 0x10, "Offset mismatch for FAudioInputDeviceInfo::DeviceID");
static_assert(offsetof(FAudioInputDeviceInfo, InputChannels) == 0x20, "Offset mismatch for FAudioInputDeviceInfo::InputChannels");
static_assert(offsetof(FAudioInputDeviceInfo, PreferredSampleRate) == 0x24, "Offset mismatch for FAudioInputDeviceInfo::PreferredSampleRate");
static_assert(offsetof(FAudioInputDeviceInfo, bSupportsHardwareAEC) == 0x28, "Offset mismatch for FAudioInputDeviceInfo::bSupportsHardwareAEC");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FAudioCaptureDeviceInfo
{
    FName DeviceName; // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t NumInputChannels; // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t SampleRate; // 0x8 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FAudioCaptureDeviceInfo) == 0xc, "Size mismatch for FAudioCaptureDeviceInfo");
static_assert(offsetof(FAudioCaptureDeviceInfo, DeviceName) == 0x0, "Offset mismatch for FAudioCaptureDeviceInfo::DeviceName");
static_assert(offsetof(FAudioCaptureDeviceInfo, NumInputChannels) == 0x4, "Offset mismatch for FAudioCaptureDeviceInfo::NumInputChannels");
static_assert(offsetof(FAudioCaptureDeviceInfo, SampleRate) == 0x8, "Offset mismatch for FAudioCaptureDeviceInfo::SampleRate");

