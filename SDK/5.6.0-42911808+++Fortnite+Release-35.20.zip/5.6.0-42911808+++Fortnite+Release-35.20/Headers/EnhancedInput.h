/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EnhancedInput
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "DeveloperSettings.h"
#include "GameplayTags.h"
#include "InputCore.h"
#include "Slate.h"

// Size: 0x90 (Inherited: 0x28, Single: 0x68)
class UEnhancedPlayerMappableKeyProfile : public UObject
{
public:
    FGameplayTag ProfileIdentifier; // 0x28 (Size: 0x4, Type: StructProperty)
    FPlatformUserId OwningUserId; // 0x2c (Size: 0x4, Type: StructProperty)
    FText DisplayName; // 0x30 (Size: 0x10, Type: TextProperty)
    TMap<FKeyMappingRow, FName> PlayerMappedKeys; // 0x40 (Size: 0x50, Type: MapProperty)

public:
    bool DoesMappingPassQueryOptions(const FPlayerKeyMapping PlayerMapping, const FPlayerMappableKeyQueryOptions Options) const; // 0xb477ef4 (Index: 0x0, Flags: Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void DumpProfileToLog() const; // 0xa20b3a8 (Index: 0x1, Flags: Native|Public|BlueprintCallable|Const)
    int32_t GetMappedKeysInRow(FName& const MappingName, TArray<FKey>& OutKeys) const; // 0xb478af0 (Index: 0x2, Flags: Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    int32_t GetMappingNamesForKey(const FKey InKey, TArray<FName>& OutMappingNames) const; // 0xb478fc0 (Index: 0x3, Flags: Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TMap<FKeyMappingRow, FName> GetPlayerMappingRows() const; // 0xb479338 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetProfileDisplayName() const; // 0xb4793c8 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetProfileIdentifer() const; // 0xa973be0 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void K2_FindKeyMapping(FPlayerKeyMapping& OutKeyMapping, const FMapPlayerKeyArgs InArgs) const; // 0xb47b1f8 (Index: 0x7, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    int32_t QueryPlayerMappedKeys(const FPlayerMappableKeyQueryOptions Options, TArray<FKey>& OutKeys) const; // 0xb47cc00 (Index: 0x8, Flags: Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void ResetMappingToDefault(FName& const InMappingName); // 0xb47e6d4 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void ResetToDefault(); // 0xa39d578 (Index: 0xa, Flags: Native|Public|BlueprintCallable)
    void SetDisplayName(const FText NewDisplayName); // 0xb47e7fc (Index: 0xb, Flags: Native|Public|HasOutParms|BlueprintCallable)
    FString ToString() const; // 0xb47fa2c (Index: 0xc, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UEnhancedPlayerMappableKeyProfile) == 0x90, "Size mismatch for UEnhancedPlayerMappableKeyProfile");
static_assert(offsetof(UEnhancedPlayerMappableKeyProfile, ProfileIdentifier) == 0x28, "Offset mismatch for UEnhancedPlayerMappableKeyProfile::ProfileIdentifier");
static_assert(offsetof(UEnhancedPlayerMappableKeyProfile, OwningUserId) == 0x2c, "Offset mismatch for UEnhancedPlayerMappableKeyProfile::OwningUserId");
static_assert(offsetof(UEnhancedPlayerMappableKeyProfile, DisplayName) == 0x30, "Offset mismatch for UEnhancedPlayerMappableKeyProfile::DisplayName");
static_assert(offsetof(UEnhancedPlayerMappableKeyProfile, PlayerMappedKeys) == 0x40, "Offset mismatch for UEnhancedPlayerMappableKeyProfile::PlayerMappedKeys");

// Size: 0x120 (Inherited: 0x50, Single: 0xd0)
class UEnhancedInputUserSettings : public USaveGame
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnSettingsChanged[0x10]; // 0x30 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnSettingsApplied[0x10]; // 0x40 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_50[0x20]; // 0x50 (Size: 0x20, Type: PaddingProperty)
    FGameplayTag CurrentProfileIdentifier; // 0x70 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
    TMap<UEnhancedPlayerMappableKeyProfile*, FGameplayTag> SavedKeyProfiles; // 0x78 (Size: 0x50, Type: MapProperty)
    TWeakObjectPtr<ULocalPlayer*> OwningLocalPlayer; // 0xc8 (Size: 0x8, Type: WeakObjectProperty)
    TSet<UInputMappingContext*> RegisteredMappingContexts; // 0xd0 (Size: 0x50, Type: SetProperty)

public:
    void ApplySettings(); // 0xa20b3a8 (Index: 0x0, Flags: Native|Public|BlueprintCallable)
    void AsyncSaveSettings(); // 0x472ef98 (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    UEnhancedPlayerMappableKeyProfile* CreateNewKeyProfile(const FPlayerMappableKeyProfileCreationArgs InArgs); // 0xb477e00 (Index: 0x2, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void EnhancedInputUserSettingsApplied__DelegateSignature(); // 0x288a61c (Index: 0x3, Flags: MulticastDelegate|Public|Delegate)
    void EnhancedInputUserSettingsChanged__DelegateSignature(UEnhancedInputUserSettings*& Settings); // 0x288a61c (Index: 0x4, Flags: MulticastDelegate|Public|Delegate)
    TSet<FPlayerKeyMapping> FindMappingsInRow(FName& const MappingName) const; // 0xb478090 (Index: 0x5, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    UEnhancedPlayerMappableKeyProfile* GetCurrentKeyProfile() const; // 0xb4787d4 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTag GetCurrentKeyProfileIdentifier() const; // 0xb4787f8 (Index: 0x7, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    UEnhancedPlayerMappableKeyProfile* GetKeyProfileWithIdentifier(const FGameplayTag ProfileId) const; // 0xb478880 (Index: 0x8, Flags: Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    bool IsMappingContextRegistered(UInputMappingContext*& const IMC) const; // 0xb47ad68 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void MappableKeyProfileChanged__DelegateSignature(UEnhancedPlayerMappableKeyProfile*& const NewProfile); // 0x288a61c (Index: 0xa, Flags: MulticastDelegate|Public|Delegate)
    void MappingContextRegisteredWithSettings__DelegateSignature(UInputMappingContext*& const IMC); // 0x288a61c (Index: 0xb, Flags: MulticastDelegate|Public|Delegate)
    void MapPlayerKey(const FMapPlayerKeyArgs InArgs, FGameplayTagContainer& FailureReason); // 0xb47b9a0 (Index: 0xc, Flags: Native|Public|HasOutParms|BlueprintCallable)
    bool RegisterInputMappingContext(UInputMappingContext*& const IMC); // 0xb47cd94 (Index: 0xd, Flags: Native|Public|BlueprintCallable)
    bool RegisterInputMappingContexts(const TSet<UInputMappingContext*> MappingContexts); // 0xb47ced4 (Index: 0xe, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void ResetAllPlayerKeysInRow(const FMapPlayerKeyArgs InArgs, FGameplayTagContainer& FailureReason); // 0xb47e0cc (Index: 0xf, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void ResetKeyProfileToDefault(const FGameplayTag ProfileId, FGameplayTagContainer& FailureReason); // 0xb47e328 (Index: 0x10, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void SaveSettings(); // 0x3305bfc (Index: 0x11, Flags: Native|Public|BlueprintCallable)
    bool SetKeyProfile(const FGameplayTag InProfileId); // 0xb47ec94 (Index: 0x12, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void UnMapPlayerKey(const FMapPlayerKeyArgs InArgs, FGameplayTagContainer& FailureReason); // 0xb47fa70 (Index: 0x13, Flags: Native|Public|HasOutParms|BlueprintCallable)
    bool UnregisterInputMappingContext(UInputMappingContext*& const IMC); // 0xb480060 (Index: 0x14, Flags: Native|Public|BlueprintCallable)
    bool UnregisterInputMappingContexts(const TSet<UInputMappingContext*> MappingContexts); // 0xb4801a0 (Index: 0x15, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UEnhancedInputUserSettings) == 0x120, "Size mismatch for UEnhancedInputUserSettings");
static_assert(offsetof(UEnhancedInputUserSettings, OnSettingsChanged) == 0x30, "Offset mismatch for UEnhancedInputUserSettings::OnSettingsChanged");
static_assert(offsetof(UEnhancedInputUserSettings, OnSettingsApplied) == 0x40, "Offset mismatch for UEnhancedInputUserSettings::OnSettingsApplied");
static_assert(offsetof(UEnhancedInputUserSettings, CurrentProfileIdentifier) == 0x70, "Offset mismatch for UEnhancedInputUserSettings::CurrentProfileIdentifier");
static_assert(offsetof(UEnhancedInputUserSettings, SavedKeyProfiles) == 0x78, "Offset mismatch for UEnhancedInputUserSettings::SavedKeyProfiles");
static_assert(offsetof(UEnhancedInputUserSettings, OwningLocalPlayer) == 0xc8, "Offset mismatch for UEnhancedInputUserSettings::OwningLocalPlayer");
static_assert(offsetof(UEnhancedInputUserSettings, RegisteredMappingContexts) == 0xd0, "Offset mismatch for UEnhancedInputUserSettings::RegisteredMappingContexts");

// Size: 0x38 (Inherited: 0x78, Single: 0xffffffc0)
class UEnhancedInputActionDelegateBinding : public UInputDelegateBinding
{
public:
    TArray<FBlueprintEnhancedInputActionBinding> InputActionDelegateBindings; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UEnhancedInputActionDelegateBinding) == 0x38, "Size mismatch for UEnhancedInputActionDelegateBinding");
static_assert(offsetof(UEnhancedInputActionDelegateBinding, InputActionDelegateBindings) == 0x28, "Offset mismatch for UEnhancedInputActionDelegateBinding::InputActionDelegateBindings");

// Size: 0x38 (Inherited: 0x78, Single: 0xffffffc0)
class UEnhancedInputActionValueBinding : public UInputDelegateBinding
{
public:
    TArray<FBlueprintEnhancedInputActionBinding> InputActionValueBindings; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UEnhancedInputActionValueBinding) == 0x38, "Size mismatch for UEnhancedInputActionValueBinding");
static_assert(offsetof(UEnhancedInputActionValueBinding, InputActionValueBindings) == 0x28, "Offset mismatch for UEnhancedInputActionValueBinding::InputActionValueBindings");

// Size: 0x178 (Inherited: 0x220, Single: 0xffffff58)
class UEnhancedInputComponent : public UInputComponent
{
public:

public:
    FInputActionValue GetBoundActionValue(UInputAction*& const Action) const; // 0xb478328 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UEnhancedInputComponent) == 0x178, "Size mismatch for UEnhancedInputComponent");

// Size: 0x140 (Inherited: 0x88, Single: 0xb8)
class UEnhancedInputDeveloperSettings : public UDeveloperSettingsBackedByCVars
{
public:
    TArray<FDefaultContextSetting> DefaultMappingContexts; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FDefaultContextSetting> DefaultWorldSubsystemMappingContexts; // 0x40 (Size: 0x10, Type: ArrayProperty)
    FPerPlatformSettings PlatformSettings; // 0x50 (Size: 0x10, Type: StructProperty)
    TSoftClassPtr UserSettingsClass; // 0x60 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr DefaultPlayerMappableKeyProfileClass; // 0x80 (Size: 0x20, Type: SoftClassProperty)
    FString InputSettingsSaveSlotName; // 0xa0 (Size: 0x10, Type: StrProperty)
    TSoftClassPtr DefaultWorldInputClass; // 0xb0 (Size: 0x20, Type: SoftClassProperty)
    uint8_t bSendTriggeredEventsWhenInputIsFlushed : 1; // 0xd0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableUserSettings : 1; // 0xd0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableDefaultMappingContexts : 1; // 0xd0:2 (Size: 0x1, Type: BoolProperty)
    uint8_t bShouldOnlyTriggerLastActionInChord : 1; // 0xd0:3 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableInputModeFiltering : 1; // 0xd0:4 (Size: 0x1, Type: BoolProperty)
    uint8_t bEnableWorldSubsystem : 1; // 0xd0:5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d1[0x7]; // 0xd1 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagQuery DefaultMappingContextInputModeQuery; // 0xd8 (Size: 0x48, Type: StructProperty)
    FGameplayTagContainer DefaultInputMode; // 0x120 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UEnhancedInputDeveloperSettings) == 0x140, "Size mismatch for UEnhancedInputDeveloperSettings");
static_assert(offsetof(UEnhancedInputDeveloperSettings, DefaultMappingContexts) == 0x30, "Offset mismatch for UEnhancedInputDeveloperSettings::DefaultMappingContexts");
static_assert(offsetof(UEnhancedInputDeveloperSettings, DefaultWorldSubsystemMappingContexts) == 0x40, "Offset mismatch for UEnhancedInputDeveloperSettings::DefaultWorldSubsystemMappingContexts");
static_assert(offsetof(UEnhancedInputDeveloperSettings, PlatformSettings) == 0x50, "Offset mismatch for UEnhancedInputDeveloperSettings::PlatformSettings");
static_assert(offsetof(UEnhancedInputDeveloperSettings, UserSettingsClass) == 0x60, "Offset mismatch for UEnhancedInputDeveloperSettings::UserSettingsClass");
static_assert(offsetof(UEnhancedInputDeveloperSettings, DefaultPlayerMappableKeyProfileClass) == 0x80, "Offset mismatch for UEnhancedInputDeveloperSettings::DefaultPlayerMappableKeyProfileClass");
static_assert(offsetof(UEnhancedInputDeveloperSettings, InputSettingsSaveSlotName) == 0xa0, "Offset mismatch for UEnhancedInputDeveloperSettings::InputSettingsSaveSlotName");
static_assert(offsetof(UEnhancedInputDeveloperSettings, DefaultWorldInputClass) == 0xb0, "Offset mismatch for UEnhancedInputDeveloperSettings::DefaultWorldInputClass");
static_assert(offsetof(UEnhancedInputDeveloperSettings, bSendTriggeredEventsWhenInputIsFlushed) == 0xd0, "Offset mismatch for UEnhancedInputDeveloperSettings::bSendTriggeredEventsWhenInputIsFlushed");
static_assert(offsetof(UEnhancedInputDeveloperSettings, bEnableUserSettings) == 0xd0, "Offset mismatch for UEnhancedInputDeveloperSettings::bEnableUserSettings");
static_assert(offsetof(UEnhancedInputDeveloperSettings, bEnableDefaultMappingContexts) == 0xd0, "Offset mismatch for UEnhancedInputDeveloperSettings::bEnableDefaultMappingContexts");
static_assert(offsetof(UEnhancedInputDeveloperSettings, bShouldOnlyTriggerLastActionInChord) == 0xd0, "Offset mismatch for UEnhancedInputDeveloperSettings::bShouldOnlyTriggerLastActionInChord");
static_assert(offsetof(UEnhancedInputDeveloperSettings, bEnableInputModeFiltering) == 0xd0, "Offset mismatch for UEnhancedInputDeveloperSettings::bEnableInputModeFiltering");
static_assert(offsetof(UEnhancedInputDeveloperSettings, bEnableWorldSubsystem) == 0xd0, "Offset mismatch for UEnhancedInputDeveloperSettings::bEnableWorldSubsystem");
static_assert(offsetof(UEnhancedInputDeveloperSettings, DefaultMappingContextInputModeQuery) == 0xd8, "Offset mismatch for UEnhancedInputDeveloperSettings::DefaultMappingContextInputModeQuery");
static_assert(offsetof(UEnhancedInputDeveloperSettings, DefaultInputMode) == 0x120, "Offset mismatch for UEnhancedInputDeveloperSettings::DefaultInputMode");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEnhancedInputLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void BreakInputActionValue(FInputActionValue& InActionValue, double& X, double& Y, double& Z, EInputActionValueType& Type); // 0xb477194 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static double Conv_InputActionValueToAxis1D(FInputActionValue& InValue); // 0xb4774bc (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FVector2D Conv_InputActionValueToAxis2D(FInputActionValue& InValue); // 0xb47759c (Index: 0x2, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector Conv_InputActionValueToAxis3D(FInputActionValue& ActionValue); // 0xb477670 (Index: 0x3, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool Conv_InputActionValueToBool(FInputActionValue& InValue); // 0xb477750 (Index: 0x4, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FString Conv_InputActionValueToString(FInputActionValue& ActionValue); // 0xb477854 (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FString Conv_TriggerEventValueToString(ETriggerEvent& const TriggerEvent); // 0xb477b04 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void FlushPlayerInput(APlayerController*& PlayerController); // 0xb4781d4 (Index: 0x7, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FInputActionValue GetBoundActionValue(AActor*& Actor, UInputAction*& const Action); // 0xb478474 (Index: 0x8, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FName GetMappingName(const FEnhancedActionKeyMapping ActionKeyMapping); // 0xb478eb4 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UPlayerMappableKeySettings* GetPlayerMappableKeySettings(const FEnhancedActionKeyMapping ActionKeyMapping); // 0xb479200 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool IsActionKeyMappingPlayerMappable(const FEnhancedActionKeyMapping ActionKeyMapping); // 0xb47ab58 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FInputActionValue MakeInputActionValueOfType(double& X, double& Y, double& Z, EInputActionValueType& const ValueType); // 0xb47b39c (Index: 0xc, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void RequestRebuildControlMappingsUsingContext(UInputMappingContext*& const Context, bool& bForceImmediately); // 0xb47ded4 (Index: 0xd, Flags: Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable)
};

static_assert(sizeof(UEnhancedInputLibrary) == 0x28, "Size mismatch for UEnhancedInputLibrary");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UEnhancedInputPlatformData : public UObject
{
public:
    TMap<UInputMappingContext*, UInputMappingContext*> MappingContextRedirects; // 0x28 (Size: 0x50, Type: MapProperty)

public:
    UInputMappingContext* GetContextRedirect(UInputMappingContext*& InContext) const; // 0xb478698 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UEnhancedInputPlatformData) == 0x78, "Size mismatch for UEnhancedInputPlatformData");
static_assert(offsetof(UEnhancedInputPlatformData, MappingContextRedirects) == 0x28, "Offset mismatch for UEnhancedInputPlatformData::MappingContextRedirects");

// Size: 0x68 (Inherited: 0x68, Single: 0x0)
class UEnhancedInputPlatformSettings : public UPlatformSettings
{
public:
    TArray<TSoftClassPtr> InputData; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> InputDataClasses; // 0x50 (Size: 0x10, Type: ArrayProperty)
    bool bShouldLogMappingContextRedirects; // 0x60 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_61[0x7]; // 0x61 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UEnhancedInputPlatformSettings) == 0x68, "Size mismatch for UEnhancedInputPlatformSettings");
static_assert(offsetof(UEnhancedInputPlatformSettings, InputData) == 0x40, "Offset mismatch for UEnhancedInputPlatformSettings::InputData");
static_assert(offsetof(UEnhancedInputPlatformSettings, InputDataClasses) == 0x50, "Offset mismatch for UEnhancedInputPlatformSettings::InputDataClasses");
static_assert(offsetof(UEnhancedInputPlatformSettings, bShouldLogMappingContextRedirects) == 0x60, "Offset mismatch for UEnhancedInputPlatformSettings::bShouldLogMappingContextRedirects");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UEnhancedInputSubsystemInterface : public UInterface
{
public:

public:
    void AddMappingContext(UInputMappingContext*& const MappingContext, int32_t& Priority, const FModifyContextOptions Options); // 0xb4769ec (Index: 0x0, Flags: BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable)
    void AddTagToInputMode(const FGameplayTag TagToAdd, const FModifyContextOptions Options); // 0xb476c78 (Index: 0x1, Flags: BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable)
    void AppendTagsToInputMode(const FGameplayTagContainer TagsToAdd, const FModifyContextOptions Options); // 0xb476df4 (Index: 0x2, Flags: BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable)
    void ClearAllMappings(); // 0xb4774a4 (Index: 0x3, Flags: BlueprintCosmetic|Native|Public|BlueprintCallable)
    TArray<FEnhancedActionKeyMapping> GetAllPlayerMappableActionKeyMappings() const; // 0xb4782e8 (Index: 0x4, Flags: BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FGameplayTagContainer GetInputMode() const; // 0xb478840 (Index: 0x5, Flags: BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UEnhancedInputUserSettings* GetUserSettings() const; // 0x54e5764 (Index: 0x6, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasMappingContext(UInputMappingContext*& const MappingContext, int32_t& OutFoundPriority) const; // 0xb47959c (Index: 0x7, Flags: BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void InjectInputForAction(UInputAction*& const Action, FInputActionValue& RawValue, const TArray<UInputModifier*> Modifiers, const TArray<UInputTrigger*> Triggers); // 0xb479768 (Index: 0x8, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void InjectInputForPlayerMapping(FName& const MappingName, FInputActionValue& RawValue, const TArray<UInputModifier*> Modifiers, const TArray<UInputTrigger*> Triggers); // 0xb479c74 (Index: 0x9, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void InjectInputVectorForAction(UInputAction*& const Action, FVector& Value, const TArray<UInputModifier*> Modifiers, const TArray<UInputTrigger*> Triggers); // 0xb47a17c (Index: 0xa, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    void InjectInputVectorForPlayerMapping(FName& const MappingName, FVector& Value, const TArray<UInputModifier*> Modifiers, const TArray<UInputTrigger*> Triggers); // 0xb47a66c (Index: 0xb, Flags: Native|Public|HasOutParms|HasDefaults|BlueprintCallable)
    TArray<FKey> QueryKeysMappedToAction(UInputAction*& const Action) const; // 0xb47c0b8 (Index: 0xe, Flags: BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const)
    EMappingQueryResult QueryMapKeyInActiveContextSet(UInputMappingContext*& const InputContext, UInputAction*& const Action, FKey& Key, TArray<FMappingQueryIssue>& OutIssues, EMappingQueryIssue& BlockingIssues); // 0xb47c20c (Index: 0xf, Flags: BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable)
    EMappingQueryResult QueryMapKeyInContextSet(const TArray<UInputMappingContext*> PrioritizedActiveContexts, UInputMappingContext*& const InputContext, UInputAction*& const Action, FKey& Key, TArray<FMappingQueryIssue>& OutIssues, EMappingQueryIssue& BlockingIssues); // 0xb47c614 (Index: 0x10, Flags: BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable)
    void RemoveMappingContext(UInputMappingContext*& const MappingContext, const FModifyContextOptions Options); // 0xb47d814 (Index: 0x11, Flags: BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable)
    void RemoveTagFromInputMode(const FGameplayTag TagToRemove, const FModifyContextOptions Options); // 0x2f9a00c (Index: 0x12, Flags: BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable)
    void RemoveTagsFromInputMode(const FGameplayTagContainer TagsToRemove, const FModifyContextOptions Options); // 0xb47d9d4 (Index: 0x13, Flags: BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable)
    void RequestRebuildControlMappings(const FModifyContextOptions Options, EInputMappingRebuildType& RebuildType); // 0xb47dd74 (Index: 0x14, Flags: BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable)
    void SetInputMode(const FGameplayTagContainer NewMode, const FModifyContextOptions Options); // 0xb47e8f4 (Index: 0x15, Flags: BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable)
    void StartContinuousInputInjectionForAction(UInputAction*& const Action, FInputActionValue& RawValue, const TArray<UInputModifier*> Modifiers, const TArray<UInputTrigger*> Triggers); // 0xb47edbc (Index: 0x16, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void StartContinuousInputInjectionForPlayerMapping(FName& const MappingName, FInputActionValue& RawValue, const TArray<UInputModifier*> Modifiers, const TArray<UInputTrigger*> Triggers); // 0xb47f2c8 (Index: 0x17, Flags: Native|Public|HasOutParms|BlueprintCallable)
    void StopContinuousInputInjectionForAction(UInputAction*& const Action); // 0xb47f7d0 (Index: 0x18, Flags: Native|Public|BlueprintCallable)
    void StopContinuousInputInjectionForPlayerMapping(FName& const MappingName); // 0xb47f900 (Index: 0x19, Flags: Native|Public|BlueprintCallable)
    void UpdateValueOfContinuousInputInjectionForAction(UInputAction*& const Action, FInputActionValue& RawValue); // 0xb480570 (Index: 0x1a, Flags: Native|Public|BlueprintCallable)
    void UpdateValueOfContinuousInputInjectionForPlayerMapping(FName& const MappingName, FInputActionValue& RawValue); // 0xb480748 (Index: 0x1b, Flags: Native|Public|BlueprintCallable)

protected:
    void OnUserKeyProfileChanged(UEnhancedPlayerMappableKeyProfile*& const InNewProfile); // 0xb47be60 (Index: 0xc, Flags: Native|Protected)
    void OnUserSettingsChanged(UEnhancedInputUserSettings*& Settings); // 0xb47bf8c (Index: 0xd, Flags: Native|Protected)
};

static_assert(sizeof(UEnhancedInputSubsystemInterface) == 0x28, "Size mismatch for UEnhancedInputSubsystemInterface");

// Size: 0x208 (Inherited: 0x88, Single: 0x180)
class UEnhancedInputLocalPlayerSubsystem : public ULocalPlayerSubsystem
{
public:
    uint8_t Pad_30[0x150]; // 0x30 (Size: 0x150, Type: PaddingProperty)
    uint8_t ControlMappingsRebuiltDelegate[0x10]; // 0x180 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMappingContextAdded[0x10]; // 0x190 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMappingContextRemoved[0x10]; // 0x1a0 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UEnhancedInputUserSettings* UserSettings; // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    TMap<FInjectedInput, UInputAction*> ContinuouslyInjectedInputs; // 0x1b8 (Size: 0x50, Type: MapProperty)

public:
    void OnControlMappingsRebuilt__DelegateSignature(); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
    void OnMappingContextAdded__DelegateSignature(UInputMappingContext*& const MappingContext); // 0x288a61c (Index: 0x1, Flags: MulticastDelegate|Public|Delegate)
    void OnMappingContextRemoved__DelegateSignature(UInputMappingContext*& const MappingContext); // 0x288a61c (Index: 0x2, Flags: MulticastDelegate|Public|Delegate)
};

static_assert(sizeof(UEnhancedInputLocalPlayerSubsystem) == 0x208, "Size mismatch for UEnhancedInputLocalPlayerSubsystem");
static_assert(offsetof(UEnhancedInputLocalPlayerSubsystem, ControlMappingsRebuiltDelegate) == 0x180, "Offset mismatch for UEnhancedInputLocalPlayerSubsystem::ControlMappingsRebuiltDelegate");
static_assert(offsetof(UEnhancedInputLocalPlayerSubsystem, OnMappingContextAdded) == 0x190, "Offset mismatch for UEnhancedInputLocalPlayerSubsystem::OnMappingContextAdded");
static_assert(offsetof(UEnhancedInputLocalPlayerSubsystem, OnMappingContextRemoved) == 0x1a0, "Offset mismatch for UEnhancedInputLocalPlayerSubsystem::OnMappingContextRemoved");
static_assert(offsetof(UEnhancedInputLocalPlayerSubsystem, UserSettings) == 0x1b0, "Offset mismatch for UEnhancedInputLocalPlayerSubsystem::UserSettings");
static_assert(offsetof(UEnhancedInputLocalPlayerSubsystem, ContinuouslyInjectedInputs) == 0x1b8, "Offset mismatch for UEnhancedInputLocalPlayerSubsystem::ContinuouslyInjectedInputs");

// Size: 0x1f8 (Inherited: 0x88, Single: 0x170)
class UEnhancedInputWorldSubsystem : public UWorldSubsystem
{
public:
    uint8_t Pad_30[0x150]; // 0x30 (Size: 0x150, Type: PaddingProperty)
    UEnhancedPlayerInput* PlayerInput; // 0x180 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_188[0x10]; // 0x188 (Size: 0x10, Type: PaddingProperty)
    TArray<TWeakObjectPtr<UInputComponent*>> CurrentInputStack; // 0x198 (Size: 0x10, Type: ArrayProperty)
    TMap<FInjectedInput, UInputAction*> ContinuouslyInjectedInputs; // 0x1a8 (Size: 0x50, Type: MapProperty)

public:
    void AddActorInputComponent(AActor*& Actor); // 0xb4768c0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    bool RemoveActorInputComponent(AActor*& Actor); // 0xb47d060 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UEnhancedInputWorldSubsystem) == 0x1f8, "Size mismatch for UEnhancedInputWorldSubsystem");
static_assert(offsetof(UEnhancedInputWorldSubsystem, PlayerInput) == 0x180, "Offset mismatch for UEnhancedInputWorldSubsystem::PlayerInput");
static_assert(offsetof(UEnhancedInputWorldSubsystem, CurrentInputStack) == 0x198, "Offset mismatch for UEnhancedInputWorldSubsystem::CurrentInputStack");
static_assert(offsetof(UEnhancedInputWorldSubsystem, ContinuouslyInjectedInputs) == 0x1a8, "Offset mismatch for UEnhancedInputWorldSubsystem::ContinuouslyInjectedInputs");

// Size: 0x8a8 (Inherited: 0x4c0, Single: 0x3e8)
class UEnhancedPlayerInput : public UPlayerInput
{
public:
    TMap<FKeyConsumptionOptions, UInputAction*> KeyConsumptionData; // 0x498 (Size: 0x50, Type: MapProperty)
    TMap<FInputActionInstance, UInputAction*> ActionInstanceData; // 0x4e8 (Size: 0x50, Type: MapProperty)
    TMap<FAppliedInputContextData, UInputMappingContext*> AppliedInputContextData; // 0x538 (Size: 0x50, Type: MapProperty)
    TMap<int32_t, UInputMappingContext*> AppliedInputContexts; // 0x588 (Size: 0x50, Type: MapProperty)
    TArray<FEnhancedActionKeyMapping> EnhancedActionMappings; // 0x5d8 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer CurrentInputMode; // 0x5e8 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_608[0x140]; // 0x608 (Size: 0x140, Type: PaddingProperty)
    TMap<FVector, FKey> KeysPressedThisTick; // 0x748 (Size: 0x50, Type: MapProperty)
    TMap<FInjectedInputArray, UInputAction*> InputsInjectedThisTick; // 0x798 (Size: 0x50, Type: MapProperty)
    TSet<UInputAction*> LastInjectedActions; // 0x7e8 (Size: 0x50, Type: SetProperty)
    uint8_t Pad_838[0x70]; // 0x838 (Size: 0x70, Type: PaddingProperty)
};

static_assert(sizeof(UEnhancedPlayerInput) == 0x8a8, "Size mismatch for UEnhancedPlayerInput");
static_assert(offsetof(UEnhancedPlayerInput, KeyConsumptionData) == 0x498, "Offset mismatch for UEnhancedPlayerInput::KeyConsumptionData");
static_assert(offsetof(UEnhancedPlayerInput, ActionInstanceData) == 0x4e8, "Offset mismatch for UEnhancedPlayerInput::ActionInstanceData");
static_assert(offsetof(UEnhancedPlayerInput, AppliedInputContextData) == 0x538, "Offset mismatch for UEnhancedPlayerInput::AppliedInputContextData");
static_assert(offsetof(UEnhancedPlayerInput, AppliedInputContexts) == 0x588, "Offset mismatch for UEnhancedPlayerInput::AppliedInputContexts");
static_assert(offsetof(UEnhancedPlayerInput, EnhancedActionMappings) == 0x5d8, "Offset mismatch for UEnhancedPlayerInput::EnhancedActionMappings");
static_assert(offsetof(UEnhancedPlayerInput, CurrentInputMode) == 0x5e8, "Offset mismatch for UEnhancedPlayerInput::CurrentInputMode");
static_assert(offsetof(UEnhancedPlayerInput, KeysPressedThisTick) == 0x748, "Offset mismatch for UEnhancedPlayerInput::KeysPressedThisTick");
static_assert(offsetof(UEnhancedPlayerInput, InputsInjectedThisTick) == 0x798, "Offset mismatch for UEnhancedPlayerInput::InputsInjectedThisTick");
static_assert(offsetof(UEnhancedPlayerInput, LastInjectedActions) == 0x7e8, "Offset mismatch for UEnhancedPlayerInput::LastInjectedActions");

// Size: 0x78 (Inherited: 0x58, Single: 0x20)
class UInputAction : public UDataAsset
{
public:
    FText ActionDescription; // 0x30 (Size: 0x10, Type: TextProperty)
    bool bTriggerWhenPaused; // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bConsumeInput; // 0x41 (Size: 0x1, Type: BoolProperty)
    bool bConsumesActionAndAxisMappings; // 0x42 (Size: 0x1, Type: BoolProperty)
    bool bReserveAllMappings; // 0x43 (Size: 0x1, Type: BoolProperty)
    int32_t TriggerEventsThatConsumeLegacyKeys; // 0x44 (Size: 0x4, Type: IntProperty)
    uint8_t ValueType; // 0x48 (Size: 0x1, Type: EnumProperty)
    uint8_t AccumulationBehavior; // 0x49 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_4a[0x6]; // 0x4a (Size: 0x6, Type: PaddingProperty)
    TArray<UInputTrigger*> Triggers; // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<UInputModifier*> Modifiers; // 0x60 (Size: 0x10, Type: ArrayProperty)
    UPlayerMappableKeySettings* PlayerMappableKeySettings; // 0x70 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UInputAction) == 0x78, "Size mismatch for UInputAction");
static_assert(offsetof(UInputAction, ActionDescription) == 0x30, "Offset mismatch for UInputAction::ActionDescription");
static_assert(offsetof(UInputAction, bTriggerWhenPaused) == 0x40, "Offset mismatch for UInputAction::bTriggerWhenPaused");
static_assert(offsetof(UInputAction, bConsumeInput) == 0x41, "Offset mismatch for UInputAction::bConsumeInput");
static_assert(offsetof(UInputAction, bConsumesActionAndAxisMappings) == 0x42, "Offset mismatch for UInputAction::bConsumesActionAndAxisMappings");
static_assert(offsetof(UInputAction, bReserveAllMappings) == 0x43, "Offset mismatch for UInputAction::bReserveAllMappings");
static_assert(offsetof(UInputAction, TriggerEventsThatConsumeLegacyKeys) == 0x44, "Offset mismatch for UInputAction::TriggerEventsThatConsumeLegacyKeys");
static_assert(offsetof(UInputAction, ValueType) == 0x48, "Offset mismatch for UInputAction::ValueType");
static_assert(offsetof(UInputAction, AccumulationBehavior) == 0x49, "Offset mismatch for UInputAction::AccumulationBehavior");
static_assert(offsetof(UInputAction, Triggers) == 0x50, "Offset mismatch for UInputAction::Triggers");
static_assert(offsetof(UInputAction, Modifiers) == 0x60, "Offset mismatch for UInputAction::Modifiers");
static_assert(offsetof(UInputAction, PlayerMappableKeySettings) == 0x70, "Offset mismatch for UInputAction::PlayerMappableKeySettings");

// Size: 0x38 (Inherited: 0x78, Single: 0xffffffc0)
class UInputDebugKeyDelegateBinding : public UInputDelegateBinding
{
public:
    TArray<FBlueprintInputDebugKeyDelegateBinding> InputDebugKeyDelegateBindings; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UInputDebugKeyDelegateBinding) == 0x38, "Size mismatch for UInputDebugKeyDelegateBinding");
static_assert(offsetof(UInputDebugKeyDelegateBinding, InputDebugKeyDelegateBindings) == 0x28, "Offset mismatch for UInputDebugKeyDelegateBinding::InputDebugKeyDelegateBindings");

// Size: 0xa8 (Inherited: 0x58, Single: 0x50)
class UInputMappingContext : public UDataAsset
{
public:
    TArray<FEnhancedActionKeyMapping> Mappings; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t InputModeFilterOptions; // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_41[0x7]; // 0x41 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagQuery InputModeQueryOverride; // 0x48 (Size: 0x48, Type: StructProperty)
    uint8_t RegistrationTrackingMode; // 0x90 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_91[0x7]; // 0x91 (Size: 0x7, Type: PaddingProperty)
    FText ContextDescription; // 0x98 (Size: 0x10, Type: TextProperty)

public:
    FEnhancedActionKeyMapping MapKey(UInputAction*& const Action, FKey& ToKey); // 0xb47b790 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    static bool ShouldShowInputModeQuery(); // 0xb47ed8c (Index: 0x1, Flags: Final|Native|Static|Public)
    void UnmapAll(); // 0xb47fccc (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void UnmapAllKeysFromAction(UInputAction*& const Action); // 0xb47fd14 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void UnmapKey(UInputAction*& const Action, FKey& Key); // 0xb47fe64 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UInputMappingContext) == 0xa8, "Size mismatch for UInputMappingContext");
static_assert(offsetof(UInputMappingContext, Mappings) == 0x30, "Offset mismatch for UInputMappingContext::Mappings");
static_assert(offsetof(UInputMappingContext, InputModeFilterOptions) == 0x40, "Offset mismatch for UInputMappingContext::InputModeFilterOptions");
static_assert(offsetof(UInputMappingContext, InputModeQueryOverride) == 0x48, "Offset mismatch for UInputMappingContext::InputModeQueryOverride");
static_assert(offsetof(UInputMappingContext, RegistrationTrackingMode) == 0x90, "Offset mismatch for UInputMappingContext::RegistrationTrackingMode");
static_assert(offsetof(UInputMappingContext, ContextDescription) == 0x98, "Offset mismatch for UInputMappingContext::ContextDescription");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UInputModifier : public UObject
{
public:

public:
    virtual FLinearColor GetVisualizationColor(FInputActionValue& SampleValue, FInputActionValue& FinalValue) const; // 0xb4793e4 (Index: 0x0, Flags: Native|Event|Public|HasDefaults|BlueprintEvent|Const)
    virtual FInputActionValue ModifyRaw(UEnhancedPlayerInput*& const PlayerInput, FInputActionValue& CurrentValue, float& DeltaTime) const; // 0xb47bbfc (Index: 0x1, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UInputModifier) == 0x28, "Size mismatch for UInputModifier");

// Size: 0x68 (Inherited: 0x50, Single: 0x18)
class UInputModifierSmoothDelta : public UInputModifier
{
public:
    uint8_t SmoothingMethod; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    float Speed; // 0x2c (Size: 0x4, Type: FloatProperty)
    float EasingExponent; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x34]; // 0x34 (Size: 0x34, Type: PaddingProperty)
};

static_assert(sizeof(UInputModifierSmoothDelta) == 0x68, "Size mismatch for UInputModifierSmoothDelta");
static_assert(offsetof(UInputModifierSmoothDelta, SmoothingMethod) == 0x28, "Offset mismatch for UInputModifierSmoothDelta::SmoothingMethod");
static_assert(offsetof(UInputModifierSmoothDelta, Speed) == 0x2c, "Offset mismatch for UInputModifierSmoothDelta::Speed");
static_assert(offsetof(UInputModifierSmoothDelta, EasingExponent) == 0x30, "Offset mismatch for UInputModifierSmoothDelta::EasingExponent");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UInputModifierDeadZone : public UInputModifier
{
public:
    float LowerThreshold; // 0x28 (Size: 0x4, Type: FloatProperty)
    float UpperThreshold; // 0x2c (Size: 0x4, Type: FloatProperty)
    uint8_t Type; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UInputModifierDeadZone) == 0x38, "Size mismatch for UInputModifierDeadZone");
static_assert(offsetof(UInputModifierDeadZone, LowerThreshold) == 0x28, "Offset mismatch for UInputModifierDeadZone::LowerThreshold");
static_assert(offsetof(UInputModifierDeadZone, UpperThreshold) == 0x2c, "Offset mismatch for UInputModifierDeadZone::UpperThreshold");
static_assert(offsetof(UInputModifierDeadZone, Type) == 0x30, "Offset mismatch for UInputModifierDeadZone::Type");

// Size: 0x40 (Inherited: 0x50, Single: 0xfffffff0)
class UInputModifierScalar : public UInputModifier
{
public:
    FVector Scalar; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UInputModifierScalar) == 0x40, "Size mismatch for UInputModifierScalar");
static_assert(offsetof(UInputModifierScalar, Scalar) == 0x28, "Offset mismatch for UInputModifierScalar::Scalar");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UInputModifierScaleByDeltaTime : public UInputModifier
{
public:
};

static_assert(sizeof(UInputModifierScaleByDeltaTime) == 0x28, "Size mismatch for UInputModifierScaleByDeltaTime");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UInputModifierNegate : public UInputModifier
{
public:
    bool bX; // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bY; // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bZ; // 0x2a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b[0x5]; // 0x2b (Size: 0x5, Type: PaddingProperty)
};

static_assert(sizeof(UInputModifierNegate) == 0x30, "Size mismatch for UInputModifierNegate");
static_assert(offsetof(UInputModifierNegate, bX) == 0x28, "Offset mismatch for UInputModifierNegate::bX");
static_assert(offsetof(UInputModifierNegate, bY) == 0x29, "Offset mismatch for UInputModifierNegate::bY");
static_assert(offsetof(UInputModifierNegate, bZ) == 0x2a, "Offset mismatch for UInputModifierNegate::bZ");

// Size: 0x58 (Inherited: 0x50, Single: 0x8)
class UInputModifierSmooth : public UInputModifier
{
public:
};

static_assert(sizeof(UInputModifierSmooth) == 0x58, "Size mismatch for UInputModifierSmooth");

// Size: 0x40 (Inherited: 0x50, Single: 0xfffffff0)
class UInputModifierResponseCurveExponential : public UInputModifier
{
public:
    FVector CurveExponent; // 0x28 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(UInputModifierResponseCurveExponential) == 0x40, "Size mismatch for UInputModifierResponseCurveExponential");
static_assert(offsetof(UInputModifierResponseCurveExponential, CurveExponent) == 0x28, "Offset mismatch for UInputModifierResponseCurveExponential::CurveExponent");

// Size: 0x40 (Inherited: 0x50, Single: 0xfffffff0)
class UInputModifierResponseCurveUser : public UInputModifier
{
public:
    UCurveFloat* ResponseX; // 0x28 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* ResponseY; // 0x30 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* ResponseZ; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UInputModifierResponseCurveUser) == 0x40, "Size mismatch for UInputModifierResponseCurveUser");
static_assert(offsetof(UInputModifierResponseCurveUser, ResponseX) == 0x28, "Offset mismatch for UInputModifierResponseCurveUser::ResponseX");
static_assert(offsetof(UInputModifierResponseCurveUser, ResponseY) == 0x30, "Offset mismatch for UInputModifierResponseCurveUser::ResponseY");
static_assert(offsetof(UInputModifierResponseCurveUser, ResponseZ) == 0x38, "Offset mismatch for UInputModifierResponseCurveUser::ResponseZ");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UInputModifierFOVScaling : public UInputModifier
{
public:
    float FOVScale; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t FOVScalingType; // 0x2c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UInputModifierFOVScaling) == 0x30, "Size mismatch for UInputModifierFOVScaling");
static_assert(offsetof(UInputModifierFOVScaling, FOVScale) == 0x28, "Offset mismatch for UInputModifierFOVScaling::FOVScale");
static_assert(offsetof(UInputModifierFOVScaling, FOVScalingType) == 0x2c, "Offset mismatch for UInputModifierFOVScaling::FOVScalingType");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UInputModifierToWorldSpace : public UInputModifier
{
public:
};

static_assert(sizeof(UInputModifierToWorldSpace) == 0x28, "Size mismatch for UInputModifierToWorldSpace");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UInputModifierSwizzleAxis : public UInputModifier
{
public:
    uint8_t Order; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UInputModifierSwizzleAxis) == 0x30, "Size mismatch for UInputModifierSwizzleAxis");
static_assert(offsetof(UInputModifierSwizzleAxis, Order) == 0x28, "Offset mismatch for UInputModifierSwizzleAxis::Order");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UInputTrigger : public UObject
{
public:
    float ActuationThreshold; // 0x28 (Size: 0x4, Type: FloatProperty)
    bool bShouldAlwaysTick; // 0x2c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d[0x3]; // 0x2d (Size: 0x3, Type: PaddingProperty)
    FInputActionValue LastValue; // 0x30 (Size: 0x20, Type: StructProperty)

public:
    virtual ETriggerType GetTriggerType() const; // 0x9e96818 (Index: 0x0, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    bool IsActuated(const FInputActionValue ForValue) const; // 0xb47ac54 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    virtual ETriggerState UpdateState(UEnhancedPlayerInput*& const PlayerInput, FInputActionValue& ModifiedValue, float& DeltaTime); // 0xb48032c (Index: 0x2, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UInputTrigger) == 0x50, "Size mismatch for UInputTrigger");
static_assert(offsetof(UInputTrigger, ActuationThreshold) == 0x28, "Offset mismatch for UInputTrigger::ActuationThreshold");
static_assert(offsetof(UInputTrigger, bShouldAlwaysTick) == 0x2c, "Offset mismatch for UInputTrigger::bShouldAlwaysTick");
static_assert(offsetof(UInputTrigger, LastValue) == 0x30, "Offset mismatch for UInputTrigger::LastValue");

// Size: 0x58 (Inherited: 0x78, Single: 0xffffffe0)
class UInputTriggerTimedBase : public UInputTrigger
{
public:
    float HeldDuration; // 0x50 (Size: 0x4, Type: FloatProperty)
    bool bAffectedByTimeDilation; // 0x54 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_55[0x3]; // 0x55 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(UInputTriggerTimedBase) == 0x58, "Size mismatch for UInputTriggerTimedBase");
static_assert(offsetof(UInputTriggerTimedBase, HeldDuration) == 0x50, "Offset mismatch for UInputTriggerTimedBase::HeldDuration");
static_assert(offsetof(UInputTriggerTimedBase, bAffectedByTimeDilation) == 0x54, "Offset mismatch for UInputTriggerTimedBase::bAffectedByTimeDilation");

// Size: 0x50 (Inherited: 0x78, Single: 0xffffffd8)
class UInputTriggerDown : public UInputTrigger
{
public:
};

static_assert(sizeof(UInputTriggerDown) == 0x50, "Size mismatch for UInputTriggerDown");

// Size: 0x50 (Inherited: 0x78, Single: 0xffffffd8)
class UInputTriggerPressed : public UInputTrigger
{
public:
};

static_assert(sizeof(UInputTriggerPressed) == 0x50, "Size mismatch for UInputTriggerPressed");

// Size: 0x50 (Inherited: 0x78, Single: 0xffffffd8)
class UInputTriggerReleased : public UInputTrigger
{
public:
};

static_assert(sizeof(UInputTriggerReleased) == 0x50, "Size mismatch for UInputTriggerReleased");

// Size: 0x68 (Inherited: 0xd0, Single: 0xffffff98)
class UInputTriggerHold : public UInputTriggerTimedBase
{
public:
    uint8_t Pad_58[0x4]; // 0x58 (Size: 0x4, Type: PaddingProperty)
    float HoldTimeThreshold; // 0x5c (Size: 0x4, Type: FloatProperty)
    bool bIsOneShot; // 0x60 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_61[0x7]; // 0x61 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UInputTriggerHold) == 0x68, "Size mismatch for UInputTriggerHold");
static_assert(offsetof(UInputTriggerHold, HoldTimeThreshold) == 0x5c, "Offset mismatch for UInputTriggerHold::HoldTimeThreshold");
static_assert(offsetof(UInputTriggerHold, bIsOneShot) == 0x60, "Offset mismatch for UInputTriggerHold::bIsOneShot");

// Size: 0x60 (Inherited: 0xd0, Single: 0xffffff90)
class UInputTriggerHoldAndRelease : public UInputTriggerTimedBase
{
public:
    float HoldTimeThreshold; // 0x58 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UInputTriggerHoldAndRelease) == 0x60, "Size mismatch for UInputTriggerHoldAndRelease");
static_assert(offsetof(UInputTriggerHoldAndRelease, HoldTimeThreshold) == 0x58, "Offset mismatch for UInputTriggerHoldAndRelease::HoldTimeThreshold");

// Size: 0x60 (Inherited: 0xd0, Single: 0xffffff90)
class UInputTriggerTap : public UInputTriggerTimedBase
{
public:
    float TapReleaseTimeThreshold; // 0x58 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_5c[0x4]; // 0x5c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UInputTriggerTap) == 0x60, "Size mismatch for UInputTriggerTap");
static_assert(offsetof(UInputTriggerTap, TapReleaseTimeThreshold) == 0x58, "Offset mismatch for UInputTriggerTap::TapReleaseTimeThreshold");

// Size: 0x78 (Inherited: 0xd0, Single: 0xffffffa8)
class UInputTriggerRepeatedTap : public UInputTriggerTimedBase
{
public:
    double RepeatDelay; // 0x58 (Size: 0x8, Type: DoubleProperty)
    double RepeatTime; // 0x60 (Size: 0x8, Type: DoubleProperty)
    int32_t NumberOfTapsWhichTriggerRepeat; // 0x68 (Size: 0x4, Type: IntProperty)
    float TapReleaseTimeThreshold; // 0x6c (Size: 0x4, Type: FloatProperty)
    int32_t NumberOfTapsSinceLastTrigger; // 0x70 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_74[0x4]; // 0x74 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UInputTriggerRepeatedTap) == 0x78, "Size mismatch for UInputTriggerRepeatedTap");
static_assert(offsetof(UInputTriggerRepeatedTap, RepeatDelay) == 0x58, "Offset mismatch for UInputTriggerRepeatedTap::RepeatDelay");
static_assert(offsetof(UInputTriggerRepeatedTap, RepeatTime) == 0x60, "Offset mismatch for UInputTriggerRepeatedTap::RepeatTime");
static_assert(offsetof(UInputTriggerRepeatedTap, NumberOfTapsWhichTriggerRepeat) == 0x68, "Offset mismatch for UInputTriggerRepeatedTap::NumberOfTapsWhichTriggerRepeat");
static_assert(offsetof(UInputTriggerRepeatedTap, TapReleaseTimeThreshold) == 0x6c, "Offset mismatch for UInputTriggerRepeatedTap::TapReleaseTimeThreshold");
static_assert(offsetof(UInputTriggerRepeatedTap, NumberOfTapsSinceLastTrigger) == 0x70, "Offset mismatch for UInputTriggerRepeatedTap::NumberOfTapsSinceLastTrigger");

// Size: 0x68 (Inherited: 0xd0, Single: 0xffffff98)
class UInputTriggerPulse : public UInputTriggerTimedBase
{
public:
    uint8_t Pad_58[0x4]; // 0x58 (Size: 0x4, Type: PaddingProperty)
    bool bTriggerOnStart; // 0x5c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5d[0x3]; // 0x5d (Size: 0x3, Type: PaddingProperty)
    float Interval; // 0x60 (Size: 0x4, Type: FloatProperty)
    int32_t TriggerLimit; // 0x64 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(UInputTriggerPulse) == 0x68, "Size mismatch for UInputTriggerPulse");
static_assert(offsetof(UInputTriggerPulse, bTriggerOnStart) == 0x5c, "Offset mismatch for UInputTriggerPulse::bTriggerOnStart");
static_assert(offsetof(UInputTriggerPulse, Interval) == 0x60, "Offset mismatch for UInputTriggerPulse::Interval");
static_assert(offsetof(UInputTriggerPulse, TriggerLimit) == 0x64, "Offset mismatch for UInputTriggerPulse::TriggerLimit");

// Size: 0x58 (Inherited: 0x78, Single: 0xffffffe0)
class UInputTriggerChordAction : public UInputTrigger
{
public:
    UInputAction* ChordAction; // 0x50 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UInputTriggerChordAction) == 0x58, "Size mismatch for UInputTriggerChordAction");
static_assert(offsetof(UInputTriggerChordAction, ChordAction) == 0x50, "Offset mismatch for UInputTriggerChordAction::ChordAction");

// Size: 0x58 (Inherited: 0xd0, Single: 0xffffff88)
class UInputTriggerChordBlocker : public UInputTriggerChordAction
{
public:
};

static_assert(sizeof(UInputTriggerChordBlocker) == 0x58, "Size mismatch for UInputTriggerChordBlocker");

// Size: 0x78 (Inherited: 0x78, Single: 0x0)
class UInputTriggerCombo : public UInputTrigger
{
public:
    int32_t CurrentComboStepIndex; // 0x50 (Size: 0x4, Type: IntProperty)
    float CurrentTimeBetweenComboSteps; // 0x54 (Size: 0x4, Type: FloatProperty)
    TArray<FInputComboStepData> ComboActions; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FInputCancelAction> InputCancelActions; // 0x68 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UInputTriggerCombo) == 0x78, "Size mismatch for UInputTriggerCombo");
static_assert(offsetof(UInputTriggerCombo, CurrentComboStepIndex) == 0x50, "Offset mismatch for UInputTriggerCombo::CurrentComboStepIndex");
static_assert(offsetof(UInputTriggerCombo, CurrentTimeBetweenComboSteps) == 0x54, "Offset mismatch for UInputTriggerCombo::CurrentTimeBetweenComboSteps");
static_assert(offsetof(UInputTriggerCombo, ComboActions) == 0x58, "Offset mismatch for UInputTriggerCombo::ComboActions");
static_assert(offsetof(UInputTriggerCombo, InputCancelActions) == 0x68, "Offset mismatch for UInputTriggerCombo::InputCancelActions");

// Size: 0xa8 (Inherited: 0x88, Single: 0x20)
class UPlayerMappableInputConfig : public UPrimaryDataAsset
{
public:
    FName ConfigName; // 0x30 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    FText ConfigDisplayName; // 0x38 (Size: 0x10, Type: TextProperty)
    bool bIsDeprecated; // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_49[0x7]; // 0x49 (Size: 0x7, Type: PaddingProperty)
    UObject* MetaData; // 0x50 (Size: 0x8, Type: ObjectProperty)
    TMap<int32_t, UInputMappingContext*> Contexts; // 0x58 (Size: 0x50, Type: MapProperty)

public:
    FName GetConfigName() const; // 0xa1f08f4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FText GetDisplayName() const; // 0xb478824 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FEnhancedActionKeyMapping> GetKeysBoundToAction(UInputAction*& const InAction) const; // 0xb478978 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FEnhancedActionKeyMapping GetMappingByName(FName& const MappingName) const; // 0xb478cc8 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TMap<int32_t, UInputMappingContext*> GetMappingContexts() const; // 0xb478e24 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UObject* GetMetadata() const; // 0xb4791e8 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FEnhancedActionKeyMapping> GetPlayerMappableKeys() const; // 0xb4792fc (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsDeprecated() const; // 0xb47ad54 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void ResetToDefault(); // 0x554e3c4 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UPlayerMappableInputConfig) == 0xa8, "Size mismatch for UPlayerMappableInputConfig");
static_assert(offsetof(UPlayerMappableInputConfig, ConfigName) == 0x30, "Offset mismatch for UPlayerMappableInputConfig::ConfigName");
static_assert(offsetof(UPlayerMappableInputConfig, ConfigDisplayName) == 0x38, "Offset mismatch for UPlayerMappableInputConfig::ConfigDisplayName");
static_assert(offsetof(UPlayerMappableInputConfig, bIsDeprecated) == 0x48, "Offset mismatch for UPlayerMappableInputConfig::bIsDeprecated");
static_assert(offsetof(UPlayerMappableInputConfig, MetaData) == 0x50, "Offset mismatch for UPlayerMappableInputConfig::MetaData");
static_assert(offsetof(UPlayerMappableInputConfig, Contexts) == 0x58, "Offset mismatch for UPlayerMappableInputConfig::Contexts");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UPlayerMappableKeySettings : public UObject
{
public:
    UObject* MetaData; // 0x28 (Size: 0x8, Type: ObjectProperty)
    FName Name; // 0x30 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    FText DisplayName; // 0x38 (Size: 0x10, Type: TextProperty)
    FText DisplayCategory; // 0x48 (Size: 0x10, Type: TextProperty)
    FGameplayTagContainer SupportedKeyProfiles; // 0x58 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UPlayerMappableKeySettings) == 0x78, "Size mismatch for UPlayerMappableKeySettings");
static_assert(offsetof(UPlayerMappableKeySettings, MetaData) == 0x28, "Offset mismatch for UPlayerMappableKeySettings::MetaData");
static_assert(offsetof(UPlayerMappableKeySettings, Name) == 0x30, "Offset mismatch for UPlayerMappableKeySettings::Name");
static_assert(offsetof(UPlayerMappableKeySettings, DisplayName) == 0x38, "Offset mismatch for UPlayerMappableKeySettings::DisplayName");
static_assert(offsetof(UPlayerMappableKeySettings, DisplayCategory) == 0x48, "Offset mismatch for UPlayerMappableKeySettings::DisplayCategory");
static_assert(offsetof(UPlayerMappableKeySettings, SupportedKeyProfiles) == 0x58, "Offset mismatch for UPlayerMappableKeySettings::SupportedKeyProfiles");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FInputActionValue
{
};

static_assert(sizeof(FInputActionValue) == 0x20, "Size mismatch for FInputActionValue");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FInjectedInput
{
    TArray<UInputTrigger*> Triggers; // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<UInputModifier*> Modifiers; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FInjectedInput) == 0x40, "Size mismatch for FInjectedInput");
static_assert(offsetof(FInjectedInput, Triggers) == 0x20, "Offset mismatch for FInjectedInput::Triggers");
static_assert(offsetof(FInjectedInput, Modifiers) == 0x30, "Offset mismatch for FInjectedInput::Modifiers");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FPlayerMappableKeyProfileCreationArgs
{
    UClass* ProfileType; // 0x0 (Size: 0x8, Type: ClassProperty)
    FGameplayTag ProfileIdentifier; // 0x8 (Size: 0x4, Type: StructProperty)
    FPlatformUserId UserId; // 0xc (Size: 0x4, Type: StructProperty)
    FText DisplayName; // 0x10 (Size: 0x10, Type: TextProperty)
    uint8_t bSetAsCurrentProfile : 1; // 0x20:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_21[0x7]; // 0x21 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FPlayerMappableKeyProfileCreationArgs) == 0x28, "Size mismatch for FPlayerMappableKeyProfileCreationArgs");
static_assert(offsetof(FPlayerMappableKeyProfileCreationArgs, ProfileType) == 0x0, "Offset mismatch for FPlayerMappableKeyProfileCreationArgs::ProfileType");
static_assert(offsetof(FPlayerMappableKeyProfileCreationArgs, ProfileIdentifier) == 0x8, "Offset mismatch for FPlayerMappableKeyProfileCreationArgs::ProfileIdentifier");
static_assert(offsetof(FPlayerMappableKeyProfileCreationArgs, UserId) == 0xc, "Offset mismatch for FPlayerMappableKeyProfileCreationArgs::UserId");
static_assert(offsetof(FPlayerMappableKeyProfileCreationArgs, DisplayName) == 0x10, "Offset mismatch for FPlayerMappableKeyProfileCreationArgs::DisplayName");
static_assert(offsetof(FPlayerMappableKeyProfileCreationArgs, bSetAsCurrentProfile) == 0x20, "Offset mismatch for FPlayerMappableKeyProfileCreationArgs::bSetAsCurrentProfile");

// Size: 0x98 (Inherited: 0x0, Single: 0x98)
struct FPlayerKeyMapping
{
    FName MappingName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FText DisplayName; // 0x8 (Size: 0x10, Type: TextProperty)
    FText DisplayCategory; // 0x18 (Size: 0x10, Type: TextProperty)
    uint8_t Slot; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t bIsDirty : 1; // 0x29:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2a[0x6]; // 0x2a (Size: 0x6, Type: PaddingProperty)
    FKey DefaultKey; // 0x30 (Size: 0x18, Type: StructProperty)
    FKey CurrentKey; // 0x48 (Size: 0x18, Type: StructProperty)
    FHardwareDeviceIdentifier HardwareDeviceId; // 0x60 (Size: 0x10, Type: StructProperty)
    UInputAction* AssociatedInputAction; // 0x70 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UInputAction*> AssociatedInputActionSoft; // 0x78 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FPlayerKeyMapping) == 0x98, "Size mismatch for FPlayerKeyMapping");
static_assert(offsetof(FPlayerKeyMapping, MappingName) == 0x0, "Offset mismatch for FPlayerKeyMapping::MappingName");
static_assert(offsetof(FPlayerKeyMapping, DisplayName) == 0x8, "Offset mismatch for FPlayerKeyMapping::DisplayName");
static_assert(offsetof(FPlayerKeyMapping, DisplayCategory) == 0x18, "Offset mismatch for FPlayerKeyMapping::DisplayCategory");
static_assert(offsetof(FPlayerKeyMapping, Slot) == 0x28, "Offset mismatch for FPlayerKeyMapping::Slot");
static_assert(offsetof(FPlayerKeyMapping, bIsDirty) == 0x29, "Offset mismatch for FPlayerKeyMapping::bIsDirty");
static_assert(offsetof(FPlayerKeyMapping, DefaultKey) == 0x30, "Offset mismatch for FPlayerKeyMapping::DefaultKey");
static_assert(offsetof(FPlayerKeyMapping, CurrentKey) == 0x48, "Offset mismatch for FPlayerKeyMapping::CurrentKey");
static_assert(offsetof(FPlayerKeyMapping, HardwareDeviceId) == 0x60, "Offset mismatch for FPlayerKeyMapping::HardwareDeviceId");
static_assert(offsetof(FPlayerKeyMapping, AssociatedInputAction) == 0x70, "Offset mismatch for FPlayerKeyMapping::AssociatedInputAction");
static_assert(offsetof(FPlayerKeyMapping, AssociatedInputActionSoft) == 0x78, "Offset mismatch for FPlayerKeyMapping::AssociatedInputActionSoft");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FMapPlayerKeyArgs
{
    FName MappingName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Slot; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FKey NewKey; // 0x8 (Size: 0x18, Type: StructProperty)
    FName HardwareDeviceId; // 0x20 (Size: 0x4, Type: NameProperty)
    FGameplayTag ProfileId; // 0x24 (Size: 0x4, Type: StructProperty)
    uint8_t bCreateMatchingSlotIfNeeded : 1; // 0x28:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bDeferOnSettingsChangedBroadcast : 1; // 0x28:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FMapPlayerKeyArgs) == 0x30, "Size mismatch for FMapPlayerKeyArgs");
static_assert(offsetof(FMapPlayerKeyArgs, MappingName) == 0x0, "Offset mismatch for FMapPlayerKeyArgs::MappingName");
static_assert(offsetof(FMapPlayerKeyArgs, Slot) == 0x4, "Offset mismatch for FMapPlayerKeyArgs::Slot");
static_assert(offsetof(FMapPlayerKeyArgs, NewKey) == 0x8, "Offset mismatch for FMapPlayerKeyArgs::NewKey");
static_assert(offsetof(FMapPlayerKeyArgs, HardwareDeviceId) == 0x20, "Offset mismatch for FMapPlayerKeyArgs::HardwareDeviceId");
static_assert(offsetof(FMapPlayerKeyArgs, ProfileId) == 0x24, "Offset mismatch for FMapPlayerKeyArgs::ProfileId");
static_assert(offsetof(FMapPlayerKeyArgs, bCreateMatchingSlotIfNeeded) == 0x28, "Offset mismatch for FMapPlayerKeyArgs::bCreateMatchingSlotIfNeeded");
static_assert(offsetof(FMapPlayerKeyArgs, bDeferOnSettingsChangedBroadcast) == 0x28, "Offset mismatch for FMapPlayerKeyArgs::bDeferOnSettingsChangedBroadcast");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FInputActionInstance
{
    UInputAction* SourceAction; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_8[0xb]; // 0x8 (Size: 0xb, Type: PaddingProperty)
    uint8_t TriggerEvent; // 0x13 (Size: 0x1, Type: EnumProperty)
    float LastTriggeredWorldTime; // 0x14 (Size: 0x4, Type: FloatProperty)
    TArray<UInputTrigger*> Triggers; // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<UInputModifier*> Modifiers; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_38[0x20]; // 0x38 (Size: 0x20, Type: PaddingProperty)
    float ElapsedProcessedTime; // 0x58 (Size: 0x4, Type: FloatProperty)
    float ElapsedTriggeredTime; // 0x5c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FInputActionInstance) == 0x60, "Size mismatch for FInputActionInstance");
static_assert(offsetof(FInputActionInstance, SourceAction) == 0x0, "Offset mismatch for FInputActionInstance::SourceAction");
static_assert(offsetof(FInputActionInstance, TriggerEvent) == 0x13, "Offset mismatch for FInputActionInstance::TriggerEvent");
static_assert(offsetof(FInputActionInstance, LastTriggeredWorldTime) == 0x14, "Offset mismatch for FInputActionInstance::LastTriggeredWorldTime");
static_assert(offsetof(FInputActionInstance, Triggers) == 0x18, "Offset mismatch for FInputActionInstance::Triggers");
static_assert(offsetof(FInputActionInstance, Modifiers) == 0x28, "Offset mismatch for FInputActionInstance::Modifiers");
static_assert(offsetof(FInputActionInstance, ElapsedProcessedTime) == 0x58, "Offset mismatch for FInputActionInstance::ElapsedProcessedTime");
static_assert(offsetof(FInputActionInstance, ElapsedTriggeredTime) == 0x5c, "Offset mismatch for FInputActionInstance::ElapsedTriggeredTime");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FKeyMappingRow
{
    TSet<FPlayerKeyMapping> Mappings; // 0x0 (Size: 0x50, Type: SetProperty)
};

static_assert(sizeof(FKeyMappingRow) == 0x50, "Size mismatch for FKeyMappingRow");
static_assert(offsetof(FKeyMappingRow, Mappings) == 0x0, "Offset mismatch for FKeyMappingRow::Mappings");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FPlayerMappableKeyQueryOptions
{
    FName MappingName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FKey KeyToMatch; // 0x8 (Size: 0x18, Type: StructProperty)
    uint8_t SlotToMatch; // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t bMatchBasicKeyTypes : 1; // 0x21:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bMatchKeyAxisType : 1; // 0x21:1 (Size: 0x1, Type: BoolProperty)
    uint8_t RequiredDeviceType; // 0x22 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_23[0x1]; // 0x23 (Size: 0x1, Type: PaddingProperty)
    int32_t RequiredDeviceFlags; // 0x24 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FPlayerMappableKeyQueryOptions) == 0x28, "Size mismatch for FPlayerMappableKeyQueryOptions");
static_assert(offsetof(FPlayerMappableKeyQueryOptions, MappingName) == 0x0, "Offset mismatch for FPlayerMappableKeyQueryOptions::MappingName");
static_assert(offsetof(FPlayerMappableKeyQueryOptions, KeyToMatch) == 0x8, "Offset mismatch for FPlayerMappableKeyQueryOptions::KeyToMatch");
static_assert(offsetof(FPlayerMappableKeyQueryOptions, SlotToMatch) == 0x20, "Offset mismatch for FPlayerMappableKeyQueryOptions::SlotToMatch");
static_assert(offsetof(FPlayerMappableKeyQueryOptions, bMatchBasicKeyTypes) == 0x21, "Offset mismatch for FPlayerMappableKeyQueryOptions::bMatchBasicKeyTypes");
static_assert(offsetof(FPlayerMappableKeyQueryOptions, bMatchKeyAxisType) == 0x21, "Offset mismatch for FPlayerMappableKeyQueryOptions::bMatchKeyAxisType");
static_assert(offsetof(FPlayerMappableKeyQueryOptions, RequiredDeviceType) == 0x22, "Offset mismatch for FPlayerMappableKeyQueryOptions::RequiredDeviceType");
static_assert(offsetof(FPlayerMappableKeyQueryOptions, RequiredDeviceFlags) == 0x24, "Offset mismatch for FPlayerMappableKeyQueryOptions::RequiredDeviceFlags");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FMappingQueryIssue
{
    uint8_t Issue; // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UInputMappingContext* BlockingContext; // 0x8 (Size: 0x8, Type: ObjectProperty)
    UInputAction* BlockingAction; // 0x10 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FMappingQueryIssue) == 0x18, "Size mismatch for FMappingQueryIssue");
static_assert(offsetof(FMappingQueryIssue, Issue) == 0x0, "Offset mismatch for FMappingQueryIssue::Issue");
static_assert(offsetof(FMappingQueryIssue, BlockingContext) == 0x8, "Offset mismatch for FMappingQueryIssue::BlockingContext");
static_assert(offsetof(FMappingQueryIssue, BlockingAction) == 0x10, "Offset mismatch for FMappingQueryIssue::BlockingAction");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FEnhancedActionKeyMapping
{
    TArray<UInputTrigger*> Triggers; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UInputModifier*> Modifiers; // 0x10 (Size: 0x10, Type: ArrayProperty)
    UInputAction* Action; // 0x20 (Size: 0x8, Type: ObjectProperty)
    FKey Key; // 0x28 (Size: 0x18, Type: StructProperty)
    uint8_t bShouldBeIgnored : 1; // 0x40:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bHasAlwaysTickTrigger : 1; // 0x40:1 (Size: 0x1, Type: BoolProperty)
    uint8_t SettingBehavior; // 0x41 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_42[0x6]; // 0x42 (Size: 0x6, Type: PaddingProperty)
    UPlayerMappableKeySettings* PlayerMappableKeySettings; // 0x48 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FEnhancedActionKeyMapping) == 0x50, "Size mismatch for FEnhancedActionKeyMapping");
static_assert(offsetof(FEnhancedActionKeyMapping, Triggers) == 0x0, "Offset mismatch for FEnhancedActionKeyMapping::Triggers");
static_assert(offsetof(FEnhancedActionKeyMapping, Modifiers) == 0x10, "Offset mismatch for FEnhancedActionKeyMapping::Modifiers");
static_assert(offsetof(FEnhancedActionKeyMapping, Action) == 0x20, "Offset mismatch for FEnhancedActionKeyMapping::Action");
static_assert(offsetof(FEnhancedActionKeyMapping, Key) == 0x28, "Offset mismatch for FEnhancedActionKeyMapping::Key");
static_assert(offsetof(FEnhancedActionKeyMapping, bShouldBeIgnored) == 0x40, "Offset mismatch for FEnhancedActionKeyMapping::bShouldBeIgnored");
static_assert(offsetof(FEnhancedActionKeyMapping, bHasAlwaysTickTrigger) == 0x40, "Offset mismatch for FEnhancedActionKeyMapping::bHasAlwaysTickTrigger");
static_assert(offsetof(FEnhancedActionKeyMapping, SettingBehavior) == 0x41, "Offset mismatch for FEnhancedActionKeyMapping::SettingBehavior");
static_assert(offsetof(FEnhancedActionKeyMapping, PlayerMappableKeySettings) == 0x48, "Offset mismatch for FEnhancedActionKeyMapping::PlayerMappableKeySettings");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBlueprintEnhancedInputActionBinding
{
    UInputAction* InputAction; // 0x0 (Size: 0x8, Type: ObjectProperty)
    uint8_t TriggerEvent; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    FName FunctionNameToBind; // 0xc (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FBlueprintEnhancedInputActionBinding) == 0x10, "Size mismatch for FBlueprintEnhancedInputActionBinding");
static_assert(offsetof(FBlueprintEnhancedInputActionBinding, InputAction) == 0x0, "Offset mismatch for FBlueprintEnhancedInputActionBinding::InputAction");
static_assert(offsetof(FBlueprintEnhancedInputActionBinding, TriggerEvent) == 0x8, "Offset mismatch for FBlueprintEnhancedInputActionBinding::TriggerEvent");
static_assert(offsetof(FBlueprintEnhancedInputActionBinding, FunctionNameToBind) == 0xc, "Offset mismatch for FBlueprintEnhancedInputActionBinding::FunctionNameToBind");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDefaultContextSetting
{
    TSoftObjectPtr<UInputMappingContext*> InputMappingContext; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    int32_t Priority; // 0x20 (Size: 0x4, Type: IntProperty)
    bool bAddImmediately; // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bRegisterWithUserSettings; // 0x25 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_26[0x2]; // 0x26 (Size: 0x2, Type: PaddingProperty)
};

static_assert(sizeof(FDefaultContextSetting) == 0x28, "Size mismatch for FDefaultContextSetting");
static_assert(offsetof(FDefaultContextSetting, InputMappingContext) == 0x0, "Offset mismatch for FDefaultContextSetting::InputMappingContext");
static_assert(offsetof(FDefaultContextSetting, Priority) == 0x20, "Offset mismatch for FDefaultContextSetting::Priority");
static_assert(offsetof(FDefaultContextSetting, bAddImmediately) == 0x24, "Offset mismatch for FDefaultContextSetting::bAddImmediately");
static_assert(offsetof(FDefaultContextSetting, bRegisterWithUserSettings) == 0x25, "Offset mismatch for FDefaultContextSetting::bRegisterWithUserSettings");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FModifyContextOptions
{
    uint8_t bIgnoreAllPressedKeysUntilRelease : 1; // 0x0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bForceImmediately : 1; // 0x0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bNotifyUserSettings : 1; // 0x0:2 (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(FModifyContextOptions) == 0x1, "Size mismatch for FModifyContextOptions");
static_assert(offsetof(FModifyContextOptions, bIgnoreAllPressedKeysUntilRelease) == 0x0, "Offset mismatch for FModifyContextOptions::bIgnoreAllPressedKeysUntilRelease");
static_assert(offsetof(FModifyContextOptions, bForceImmediately) == 0x0, "Offset mismatch for FModifyContextOptions::bForceImmediately");
static_assert(offsetof(FModifyContextOptions, bNotifyUserSettings) == 0x0, "Offset mismatch for FModifyContextOptions::bNotifyUserSettings");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FKeyConsumptionOptions
{
};

static_assert(sizeof(FKeyConsumptionOptions) == 0x18, "Size mismatch for FKeyConsumptionOptions");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInjectedInputArray
{
    TArray<FInjectedInput> Injected; // 0x0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FInjectedInputArray) == 0x10, "Size mismatch for FInjectedInputArray");
static_assert(offsetof(FInjectedInputArray, Injected) == 0x0, "Offset mismatch for FInjectedInputArray::Injected");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FAppliedInputContextData
{
    int32_t Priority; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t RegistrationCount; // 0x4 (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FAppliedInputContextData) == 0x8, "Size mismatch for FAppliedInputContextData");
static_assert(offsetof(FAppliedInputContextData, Priority) == 0x0, "Offset mismatch for FAppliedInputContextData::Priority");
static_assert(offsetof(FAppliedInputContextData, RegistrationCount) == 0x4, "Offset mismatch for FAppliedInputContextData::RegistrationCount");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FBlueprintInputDebugKeyDelegateBinding
{
    FInputChord InputChord; // 0x0 (Size: 0x20, Type: StructProperty)
    TEnumAsByte<EInputEvent> InputKeyEvent; // 0x20 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_21[0x3]; // 0x21 (Size: 0x3, Type: PaddingProperty)
    FName FunctionNameToBind; // 0x24 (Size: 0x4, Type: NameProperty)
    bool bExecuteWhenPaused; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FBlueprintInputDebugKeyDelegateBinding) == 0x30, "Size mismatch for FBlueprintInputDebugKeyDelegateBinding");
static_assert(offsetof(FBlueprintInputDebugKeyDelegateBinding, InputChord) == 0x0, "Offset mismatch for FBlueprintInputDebugKeyDelegateBinding::InputChord");
static_assert(offsetof(FBlueprintInputDebugKeyDelegateBinding, InputKeyEvent) == 0x20, "Offset mismatch for FBlueprintInputDebugKeyDelegateBinding::InputKeyEvent");
static_assert(offsetof(FBlueprintInputDebugKeyDelegateBinding, FunctionNameToBind) == 0x24, "Offset mismatch for FBlueprintInputDebugKeyDelegateBinding::FunctionNameToBind");
static_assert(offsetof(FBlueprintInputDebugKeyDelegateBinding, bExecuteWhenPaused) == 0x28, "Offset mismatch for FBlueprintInputDebugKeyDelegateBinding::bExecuteWhenPaused");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInputComboStepData
{
    UInputAction* ComboStepAction; // 0x0 (Size: 0x8, Type: ObjectProperty)
    char ComboStepCompletionStates; // 0x8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    float TimeToPressKey; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FInputComboStepData) == 0x10, "Size mismatch for FInputComboStepData");
static_assert(offsetof(FInputComboStepData, ComboStepAction) == 0x0, "Offset mismatch for FInputComboStepData::ComboStepAction");
static_assert(offsetof(FInputComboStepData, ComboStepCompletionStates) == 0x8, "Offset mismatch for FInputComboStepData::ComboStepCompletionStates");
static_assert(offsetof(FInputComboStepData, TimeToPressKey) == 0xc, "Offset mismatch for FInputComboStepData::TimeToPressKey");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FInputCancelAction
{
    UInputAction* CancelAction; // 0x0 (Size: 0x8, Type: ObjectProperty)
    char CancellationStates; // 0x8 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FInputCancelAction) == 0x10, "Size mismatch for FInputCancelAction");
static_assert(offsetof(FInputCancelAction, CancelAction) == 0x0, "Offset mismatch for FInputCancelAction::CancelAction");
static_assert(offsetof(FInputCancelAction, CancellationStates) == 0x8, "Offset mismatch for FInputCancelAction::CancellationStates");

