/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AirJellyfishRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0x5f0 (Inherited: 0xea8, Single: 0xfffff748)
class UFortAirJellyfishAnimInstance : public UFortAnimInstance
{
public:
    float RotatorLerpRate; // 0x5c8 (Size: 0x4, Type: FloatProperty)
    float VelocityDirectionScalar; // 0x5cc (Size: 0x4, Type: FloatProperty)
    FRotator RootRotation; // 0x5d0 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_5e8[0x8]; // 0x5e8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UFortAirJellyfishAnimInstance) == 0x5f0, "Size mismatch for UFortAirJellyfishAnimInstance");
static_assert(offsetof(UFortAirJellyfishAnimInstance, RotatorLerpRate) == 0x5c8, "Offset mismatch for UFortAirJellyfishAnimInstance::RotatorLerpRate");
static_assert(offsetof(UFortAirJellyfishAnimInstance, VelocityDirectionScalar) == 0x5cc, "Offset mismatch for UFortAirJellyfishAnimInstance::VelocityDirectionScalar");
static_assert(offsetof(UFortAirJellyfishAnimInstance, RootRotation) == 0x5d0, "Offset mismatch for UFortAirJellyfishAnimInstance::RootRotation");

