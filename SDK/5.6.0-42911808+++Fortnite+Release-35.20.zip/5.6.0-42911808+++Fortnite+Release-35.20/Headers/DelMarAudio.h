/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarAudio
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "PlayspaceSystem.h"
#include "ModularGameplay.h"
#include "DelMarCore.h"
#include "GameplayTags.h"
#include "AudioModulation.h"

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UDelMarAudioCheatManager : public UChildCheatManager
{
public:

protected:
    void DelMarPrintMusicTrackName(); // 0x554e3c4 (Index: 0x0, Flags: Final|Exec|Native|Protected)
    void DelMarSetMusicTrigger(FName& TriggerName); // 0xa28ddc8 (Index: 0x1, Flags: Final|Exec|Native|Protected)
    void DelMarSkipMusic(); // 0x554e3c4 (Index: 0x2, Flags: Final|Exec|Native|Protected)
    void DelMarStartMusic(); // 0x554e3c4 (Index: 0x3, Flags: Final|Exec|Native|Protected)
    void DelMarStopMusic(); // 0x554e3c4 (Index: 0x4, Flags: Final|Exec|Native|Protected)
};

static_assert(sizeof(UDelMarAudioCheatManager) == 0x28, "Size mismatch for UDelMarAudioCheatManager");

// Size: 0x160 (Inherited: 0x2e0, Single: 0xfffffe80)
class UDelMarAudioPassbyComponent : public UDelMarAudioProximityComponent
{
public:
    USoundBase* PassBySound; // 0x110 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* PassbyComponent; // 0x118 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnPassbyStart[0x10]; // 0x120 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPassbyStop[0x10]; // 0x130 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    float MinRelativeSpeed; // 0x140 (Size: 0x4, Type: FloatProperty)
    float MinSpeedStopThresholdOffset; // 0x144 (Size: 0x4, Type: FloatProperty)
    float PassbyStartRadiusMax; // 0x148 (Size: 0x4, Type: FloatProperty)
    float PassbyStartRadiusMin; // 0x14c (Size: 0x4, Type: FloatProperty)
    float MinRelativeDirection; // 0x150 (Size: 0x4, Type: FloatProperty)
    float PassbyCooldown; // 0x154 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_158[0x8]; // 0x158 (Size: 0x8, Type: PaddingProperty)

public:
    virtual void BP_StartPassby(AActor*& Instigator, float& const PassbySpeed); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void BP_StopPassby(); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    void HandlePassbyFinished(); // 0x11d14a84 (Index: 0x2, Flags: Final|Native|Public)
    bool IsPlayingPassby() const; // 0xc3d64b4 (Index: 0x3, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarAudioPassbyComponent) == 0x160, "Size mismatch for UDelMarAudioPassbyComponent");
static_assert(offsetof(UDelMarAudioPassbyComponent, PassBySound) == 0x110, "Offset mismatch for UDelMarAudioPassbyComponent::PassBySound");
static_assert(offsetof(UDelMarAudioPassbyComponent, PassbyComponent) == 0x118, "Offset mismatch for UDelMarAudioPassbyComponent::PassbyComponent");
static_assert(offsetof(UDelMarAudioPassbyComponent, OnPassbyStart) == 0x120, "Offset mismatch for UDelMarAudioPassbyComponent::OnPassbyStart");
static_assert(offsetof(UDelMarAudioPassbyComponent, OnPassbyStop) == 0x130, "Offset mismatch for UDelMarAudioPassbyComponent::OnPassbyStop");
static_assert(offsetof(UDelMarAudioPassbyComponent, MinRelativeSpeed) == 0x140, "Offset mismatch for UDelMarAudioPassbyComponent::MinRelativeSpeed");
static_assert(offsetof(UDelMarAudioPassbyComponent, MinSpeedStopThresholdOffset) == 0x144, "Offset mismatch for UDelMarAudioPassbyComponent::MinSpeedStopThresholdOffset");
static_assert(offsetof(UDelMarAudioPassbyComponent, PassbyStartRadiusMax) == 0x148, "Offset mismatch for UDelMarAudioPassbyComponent::PassbyStartRadiusMax");
static_assert(offsetof(UDelMarAudioPassbyComponent, PassbyStartRadiusMin) == 0x14c, "Offset mismatch for UDelMarAudioPassbyComponent::PassbyStartRadiusMin");
static_assert(offsetof(UDelMarAudioPassbyComponent, MinRelativeDirection) == 0x150, "Offset mismatch for UDelMarAudioPassbyComponent::MinRelativeDirection");
static_assert(offsetof(UDelMarAudioPassbyComponent, PassbyCooldown) == 0x154, "Offset mismatch for UDelMarAudioPassbyComponent::PassbyCooldown");

// Size: 0x110 (Inherited: 0x1d0, Single: 0xffffff40)
class UDelMarAudioProximityComponent : public UDelMarAudioProximityComponentBase
{
public:
    USoundBase* ProximitySound; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* ProximityComponent; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    float ObjectScaleAttenuationModifier; // 0x100 (Size: 0x4, Type: FloatProperty)
    float FadeOutDuration; // 0x104 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_108[0x8]; // 0x108 (Size: 0x8, Type: PaddingProperty)

public:
    float GetObjectScale() const; // 0xa1ee830 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarAudioProximityComponent) == 0x110, "Size mismatch for UDelMarAudioProximityComponent");
static_assert(offsetof(UDelMarAudioProximityComponent, ProximitySound) == 0xf0, "Offset mismatch for UDelMarAudioProximityComponent::ProximitySound");
static_assert(offsetof(UDelMarAudioProximityComponent, ProximityComponent) == 0xf8, "Offset mismatch for UDelMarAudioProximityComponent::ProximityComponent");
static_assert(offsetof(UDelMarAudioProximityComponent, ObjectScaleAttenuationModifier) == 0x100, "Offset mismatch for UDelMarAudioProximityComponent::ObjectScaleAttenuationModifier");
static_assert(offsetof(UDelMarAudioProximityComponent, FadeOutDuration) == 0x104, "Offset mismatch for UDelMarAudioProximityComponent::FadeOutDuration");

// Size: 0xf0 (Inherited: 0xe0, Single: 0x10)
class UDelMarAudioProximityComponentBase : public UActorComponent
{
public:
    uint8_t OnProximityStart[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnProximityStop[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bProximityActive; // 0xd8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d9[0xf]; // 0xd9 (Size: 0xf, Type: PaddingProperty)
    UDelMarAudioProximitySubsystem* Subsystem; // 0xe8 (Size: 0x8, Type: ObjectProperty)

public:
    virtual void BP_StartProximity(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void BP_StopProximity(); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void BP_Update(APlayerCameraManager*& const Camera, ADelMarVehicle*& const Vehicle); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)

protected:
    UAudioComponent* CreateSoundAttached(USoundBase*& Sound, USceneComponent*& AttachComponent, FName& AttachPointName, float& VolumeMultiplier, float& PitchMultiplier, bool& bStopWhenAttachedToDestroyed, bool& bAutoDestroy); // 0x11d14444 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarAudioProximityComponentBase) == 0xf0, "Size mismatch for UDelMarAudioProximityComponentBase");
static_assert(offsetof(UDelMarAudioProximityComponentBase, OnProximityStart) == 0xb8, "Offset mismatch for UDelMarAudioProximityComponentBase::OnProximityStart");
static_assert(offsetof(UDelMarAudioProximityComponentBase, OnProximityStop) == 0xc8, "Offset mismatch for UDelMarAudioProximityComponentBase::OnProximityStop");
static_assert(offsetof(UDelMarAudioProximityComponentBase, bProximityActive) == 0xd8, "Offset mismatch for UDelMarAudioProximityComponentBase::bProximityActive");
static_assert(offsetof(UDelMarAudioProximityComponentBase, Subsystem) == 0xe8, "Offset mismatch for UDelMarAudioProximityComponentBase::Subsystem");

// Size: 0xe0 (Inherited: 0xc8, Single: 0x18)
class UDelMarAudioProximitySubsystem : public UTickableWorldSubsystem
{
public:
};

static_assert(sizeof(UDelMarAudioProximitySubsystem) == 0xe0, "Size mismatch for UDelMarAudioProximitySubsystem");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UDelMarAudioAudioCookSettings : public UObject
{
public:
    int32_t SoundWaveChannelThreshold; // 0x28 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    TArray<FString> PathsToScan; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> PlatformQualitySettingsToExclude; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarAudioAudioCookSettings) == 0x50, "Size mismatch for UDelMarAudioAudioCookSettings");
static_assert(offsetof(UDelMarAudioAudioCookSettings, SoundWaveChannelThreshold) == 0x28, "Offset mismatch for UDelMarAudioAudioCookSettings::SoundWaveChannelThreshold");
static_assert(offsetof(UDelMarAudioAudioCookSettings, PathsToScan) == 0x30, "Offset mismatch for UDelMarAudioAudioCookSettings::PathsToScan");
static_assert(offsetof(UDelMarAudioAudioCookSettings, PlatformQualitySettingsToExclude) == 0x40, "Offset mismatch for UDelMarAudioAudioCookSettings::PlatformQualitySettingsToExclude");

// Size: 0xf0 (Inherited: 0xc8, Single: 0x28)
class UDelMarAudioStateMixerSubsystem : public UTickableWorldSubsystem
{
public:
    TArray<FDelMarStateMixCollection> AvailableMixes; // 0x40 (Size: 0x10, Type: ArrayProperty)
    TMap<FDelMarStateMix, FGameplayTag> ActiveMixes; // 0x50 (Size: 0x50, Type: MapProperty)
    TMap<FDelMarStateMix, FGameplayTag> TemporaryMixes; // 0xa0 (Size: 0x50, Type: MapProperty)

public:
    void AddMixes(FName& const GroupName, const TArray<FDelMarStateMix> Mixes); // 0x11d14114 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void ClearMixState(const FGameplayTag MixState, bool& bDeactivateChildren); // 0x11d142d4 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    TMap<FDelMarStateMix, FGameplayTag> GetActiveMixes() const; // 0x11d149f4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void RemoveMixes(FName& const GroupName); // 0x11d14f70 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    bool SetMixState(const FGameplayTag MixState, bool& bFallBackToNearestParent, bool& bDeactivateChildren); // 0x11d151c0 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UDelMarAudioStateMixerSubsystem) == 0xf0, "Size mismatch for UDelMarAudioStateMixerSubsystem");
static_assert(offsetof(UDelMarAudioStateMixerSubsystem, AvailableMixes) == 0x40, "Offset mismatch for UDelMarAudioStateMixerSubsystem::AvailableMixes");
static_assert(offsetof(UDelMarAudioStateMixerSubsystem, ActiveMixes) == 0x50, "Offset mismatch for UDelMarAudioStateMixerSubsystem::ActiveMixes");
static_assert(offsetof(UDelMarAudioStateMixerSubsystem, TemporaryMixes) == 0xa0, "Offset mismatch for UDelMarAudioStateMixerSubsystem::TemporaryMixes");

// Size: 0xc8 (Inherited: 0x250, Single: 0xfffffe78)
class UDelMarCrowdAudioManager : public UPlayspaceComponent
{
public:
    UDelMarAudioStatePlayspaceComponent* CachedStateComponent; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag RaceModeTag; // 0xc0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c4[0x4]; // 0xc4 (Size: 0x4, Type: PaddingProperty)

public:
    virtual void BP_OnApproachingFinishLine(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnGameplayStateChanged(FGameplayTag& const NewStateTag); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnPlayerFinishedRace(); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnRaceModeChanged(FGameplayTag& const NewRaceModeTag); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnRacerStateChanged(FGameplayTag& const NewStateTag); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnVehicleDemolished(); // 0x288a61c (Index: 0x5, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UDelMarCrowdAudioManager) == 0xc8, "Size mismatch for UDelMarCrowdAudioManager");
static_assert(offsetof(UDelMarCrowdAudioManager, CachedStateComponent) == 0xb8, "Offset mismatch for UDelMarCrowdAudioManager::CachedStateComponent");
static_assert(offsetof(UDelMarCrowdAudioManager, RaceModeTag) == 0xc0, "Offset mismatch for UDelMarCrowdAudioManager::RaceModeTag");

// Size: 0x190 (Inherited: 0x250, Single: 0xffffff40)
class UDelMarRaceMusicManager : public UPlayspaceComponent
{
public:
    FGameplayTag RaceModeTag; // 0xb8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
    USoundBase* MusicPlayer; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* MusicPlayer_LowSpec; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag MusicEventSystemTag; // 0xd0 (Size: 0x4, Type: StructProperty)
    float FadeInDuration; // 0xd4 (Size: 0x4, Type: FloatProperty)
    float FadeOutDuration; // 0xd8 (Size: 0x4, Type: FloatProperty)
    float StartLineFadeOutDurtation; // 0xdc (Size: 0x4, Type: FloatProperty)
    USoundBase* PreRaceMusic; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* PostRaceMusic; // 0xe8 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* MainMusicComponent; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* StartLineComponent; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UDelMarRaceMusicPlaylist*> DefaultPlaylist; // 0x100 (Size: 0x20, Type: SoftObjectProperty)
    UDelMarRaceMusicPlaylist* Playlist; // 0x120 (Size: 0x8, Type: ObjectProperty)
    TArray<FDelMarMusicTrack> Songs; // 0x128 (Size: 0x10, Type: ArrayProperty)
    FDelMarMusicTrack PlayingSong; // 0x138 (Size: 0x20, Type: StructProperty)
    UDelMarAudioStatePlayspaceComponent* CachedStateComponent; // 0x158 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_160[0x30]; // 0x160 (Size: 0x30, Type: PaddingProperty)

public:
    virtual void BP_OnCountdownTimeSet(float& const TimeUntilRunStart); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnGameplayStateChanged(FGameplayTag& const NewStateTag); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnPlayerFinishedRace(); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnRaceModeChanged(FGameplayTag& const NewModeTag); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnRacerStateChanged(FGameplayTag& const NewStateTag); // 0x288a61c (Index: 0x4, Flags: Event|Public|BlueprintEvent)
    void SetPlaylist(UDelMarRaceMusicPlaylist*& InPlaylist); // 0x11d153dc (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
    void SetPostRaceMusic(USoundBase*& InPostRaceMusic); // 0x11d15508 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    void SetPreRaceMusic(USoundBase*& InPreRaceMusic); // 0xe563878 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void SkipTrack(); // 0x11d157e0 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void StartRaceMusic(); // 0x11d1580c (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void StartStartLineMusic(float& const CountdownLength); // 0x11d15820 (Index: 0xc, Flags: Final|Native|Public|BlueprintCallable)
    void StopMusic(); // 0x11d1594c (Index: 0xd, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void HandleSpectatorViewTargetChange(AFortPlayerController*& PlayerController, AActor*& OldViewTarget, AActor*& NewViewTarget); // 0x11d14b68 (Index: 0x5, Flags: Final|Native|Protected)
    void SetAudioTrigger(FName& const InTrigger); // 0x11d15098 (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable)
    void TryGetFortClientSettings(); // 0x11d15960 (Index: 0xe, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarRaceMusicManager) == 0x190, "Size mismatch for UDelMarRaceMusicManager");
static_assert(offsetof(UDelMarRaceMusicManager, RaceModeTag) == 0xb8, "Offset mismatch for UDelMarRaceMusicManager::RaceModeTag");
static_assert(offsetof(UDelMarRaceMusicManager, MusicPlayer) == 0xc0, "Offset mismatch for UDelMarRaceMusicManager::MusicPlayer");
static_assert(offsetof(UDelMarRaceMusicManager, MusicPlayer_LowSpec) == 0xc8, "Offset mismatch for UDelMarRaceMusicManager::MusicPlayer_LowSpec");
static_assert(offsetof(UDelMarRaceMusicManager, MusicEventSystemTag) == 0xd0, "Offset mismatch for UDelMarRaceMusicManager::MusicEventSystemTag");
static_assert(offsetof(UDelMarRaceMusicManager, FadeInDuration) == 0xd4, "Offset mismatch for UDelMarRaceMusicManager::FadeInDuration");
static_assert(offsetof(UDelMarRaceMusicManager, FadeOutDuration) == 0xd8, "Offset mismatch for UDelMarRaceMusicManager::FadeOutDuration");
static_assert(offsetof(UDelMarRaceMusicManager, StartLineFadeOutDurtation) == 0xdc, "Offset mismatch for UDelMarRaceMusicManager::StartLineFadeOutDurtation");
static_assert(offsetof(UDelMarRaceMusicManager, PreRaceMusic) == 0xe0, "Offset mismatch for UDelMarRaceMusicManager::PreRaceMusic");
static_assert(offsetof(UDelMarRaceMusicManager, PostRaceMusic) == 0xe8, "Offset mismatch for UDelMarRaceMusicManager::PostRaceMusic");
static_assert(offsetof(UDelMarRaceMusicManager, MainMusicComponent) == 0xf0, "Offset mismatch for UDelMarRaceMusicManager::MainMusicComponent");
static_assert(offsetof(UDelMarRaceMusicManager, StartLineComponent) == 0xf8, "Offset mismatch for UDelMarRaceMusicManager::StartLineComponent");
static_assert(offsetof(UDelMarRaceMusicManager, DefaultPlaylist) == 0x100, "Offset mismatch for UDelMarRaceMusicManager::DefaultPlaylist");
static_assert(offsetof(UDelMarRaceMusicManager, Playlist) == 0x120, "Offset mismatch for UDelMarRaceMusicManager::Playlist");
static_assert(offsetof(UDelMarRaceMusicManager, Songs) == 0x128, "Offset mismatch for UDelMarRaceMusicManager::Songs");
static_assert(offsetof(UDelMarRaceMusicManager, PlayingSong) == 0x138, "Offset mismatch for UDelMarRaceMusicManager::PlayingSong");
static_assert(offsetof(UDelMarRaceMusicManager, CachedStateComponent) == 0x158, "Offset mismatch for UDelMarRaceMusicManager::CachedStateComponent");

// Size: 0x2c8 (Inherited: 0x2d0, Single: 0xfffffff8)
class ADelMarRaceMusicSettingsActor : public AActor
{
public:
    UDelMarRaceMusicPlaylist* Playlist; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* PreRaceMusic; // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* PostRaceMusic; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    bool bEnableMusic; // 0x2c0 (Size: 0x1, Type: BoolProperty)
    bool bEnableAudioAnalysis; // 0x2c1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2c2[0x6]; // 0x2c2 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(ADelMarRaceMusicSettingsActor) == 0x2c8, "Size mismatch for ADelMarRaceMusicSettingsActor");
static_assert(offsetof(ADelMarRaceMusicSettingsActor, Playlist) == 0x2a8, "Offset mismatch for ADelMarRaceMusicSettingsActor::Playlist");
static_assert(offsetof(ADelMarRaceMusicSettingsActor, PreRaceMusic) == 0x2b0, "Offset mismatch for ADelMarRaceMusicSettingsActor::PreRaceMusic");
static_assert(offsetof(ADelMarRaceMusicSettingsActor, PostRaceMusic) == 0x2b8, "Offset mismatch for ADelMarRaceMusicSettingsActor::PostRaceMusic");
static_assert(offsetof(ADelMarRaceMusicSettingsActor, bEnableMusic) == 0x2c0, "Offset mismatch for ADelMarRaceMusicSettingsActor::bEnableMusic");
static_assert(offsetof(ADelMarRaceMusicSettingsActor, bEnableAudioAnalysis) == 0x2c1, "Offset mismatch for ADelMarRaceMusicSettingsActor::bEnableAudioAnalysis");

// Size: 0x1f8 (Inherited: 0x250, Single: 0xffffffa8)
class UDelMarAudioStatePlayspaceComponent : public UPlayspaceComponent
{
public:
    uint8_t Pad_b8[0xc0]; // 0xb8 (Size: 0xc0, Type: PaddingProperty)
    FName MixGroupName; // 0x178 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_17c[0x4]; // 0x17c (Size: 0x4, Type: PaddingProperty)
    TArray<FDelMarStateMix> Mixes; // 0x180 (Size: 0x10, Type: ArrayProperty)
    float CloseVehicleDistanceThreshold; // 0x190 (Size: 0x4, Type: FloatProperty)
    int32_t CloseVehiclesPackRacingThreshold; // 0x194 (Size: 0x4, Type: IntProperty)
    USoundControlBus* UserMusicSettingBus; // 0x198 (Size: 0x8, Type: ObjectProperty)
    USoundControlBusMix* UserMusicMix; // 0x1a0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1a8[0x8]; // 0x1a8 (Size: 0x8, Type: PaddingProperty)
    UDelMarAudioStateMixerSubsystem* MixSubsystem; // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    UDelMarVehicleManager* VehicleManager; // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1c0[0x38]; // 0x1c0 (Size: 0x38, Type: PaddingProperty)

public:
    void HandleVehicleBigAirStarted(); // 0x11d14e4c (Index: 0x0, Flags: Final|Native|Public)
    void HandleVehicleBigAirStopped(); // 0x11d14e60 (Index: 0x1, Flags: Final|Native|Public)
    void HandleVehicleDemolished(FGameplayTag& CausedByTag); // 0x11d14e74 (Index: 0x2, Flags: Final|Native|Public)
    void HandleVehicleHitHazard(); // 0x11d14f34 (Index: 0x3, Flags: Final|Native|Public)
    void HandleVehicleTurboStarted(); // 0x11d14f48 (Index: 0x4, Flags: Final|Native|Public)
    void HandleVehicleTurboStopped(); // 0x11d14f5c (Index: 0x5, Flags: Final|Native|Public)
};

static_assert(sizeof(UDelMarAudioStatePlayspaceComponent) == 0x1f8, "Size mismatch for UDelMarAudioStatePlayspaceComponent");
static_assert(offsetof(UDelMarAudioStatePlayspaceComponent, MixGroupName) == 0x178, "Offset mismatch for UDelMarAudioStatePlayspaceComponent::MixGroupName");
static_assert(offsetof(UDelMarAudioStatePlayspaceComponent, Mixes) == 0x180, "Offset mismatch for UDelMarAudioStatePlayspaceComponent::Mixes");
static_assert(offsetof(UDelMarAudioStatePlayspaceComponent, CloseVehicleDistanceThreshold) == 0x190, "Offset mismatch for UDelMarAudioStatePlayspaceComponent::CloseVehicleDistanceThreshold");
static_assert(offsetof(UDelMarAudioStatePlayspaceComponent, CloseVehiclesPackRacingThreshold) == 0x194, "Offset mismatch for UDelMarAudioStatePlayspaceComponent::CloseVehiclesPackRacingThreshold");
static_assert(offsetof(UDelMarAudioStatePlayspaceComponent, UserMusicSettingBus) == 0x198, "Offset mismatch for UDelMarAudioStatePlayspaceComponent::UserMusicSettingBus");
static_assert(offsetof(UDelMarAudioStatePlayspaceComponent, UserMusicMix) == 0x1a0, "Offset mismatch for UDelMarAudioStatePlayspaceComponent::UserMusicMix");
static_assert(offsetof(UDelMarAudioStatePlayspaceComponent, MixSubsystem) == 0x1b0, "Offset mismatch for UDelMarAudioStatePlayspaceComponent::MixSubsystem");
static_assert(offsetof(UDelMarAudioStatePlayspaceComponent, VehicleManager) == 0x1b8, "Offset mismatch for UDelMarAudioStatePlayspaceComponent::VehicleManager");

// Size: 0xb8 (Inherited: 0xc8, Single: 0xfffffff0)
class UDelMarAudioVirtualizationSubsystem : public UTickableWorldSubsystem
{
public:
    uint8_t Pad_40[0x10]; // 0x40 (Size: 0x10, Type: PaddingProperty)
    TMap<FDelmarAudioVirtualizationSettings, FGameplayTag> PlayerNumMap; // 0x50 (Size: 0x50, Type: MapProperty)
    int32_t MaxNumPlayers; // 0xa0 (Size: 0x4, Type: IntProperty)
    int32_t MaxDistantPlayers; // 0xa4 (Size: 0x4, Type: IntProperty)
    int32_t DistantPlayerThreshold; // 0xa8 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
    UDelMarVehicleManager* VehicleManager; // 0xb0 (Size: 0x8, Type: ObjectProperty)

public:
    void HandleRaceModeChanged(const FDelMarEvent_RaceModeSet Event); // 0x11d14a9c (Index: 0x0, Flags: Final|Native|Public|HasOutParms)
};

static_assert(sizeof(UDelMarAudioVirtualizationSubsystem) == 0xb8, "Size mismatch for UDelMarAudioVirtualizationSubsystem");
static_assert(offsetof(UDelMarAudioVirtualizationSubsystem, PlayerNumMap) == 0x50, "Offset mismatch for UDelMarAudioVirtualizationSubsystem::PlayerNumMap");
static_assert(offsetof(UDelMarAudioVirtualizationSubsystem, MaxNumPlayers) == 0xa0, "Offset mismatch for UDelMarAudioVirtualizationSubsystem::MaxNumPlayers");
static_assert(offsetof(UDelMarAudioVirtualizationSubsystem, MaxDistantPlayers) == 0xa4, "Offset mismatch for UDelMarAudioVirtualizationSubsystem::MaxDistantPlayers");
static_assert(offsetof(UDelMarAudioVirtualizationSubsystem, DistantPlayerThreshold) == 0xa8, "Offset mismatch for UDelMarAudioVirtualizationSubsystem::DistantPlayerThreshold");
static_assert(offsetof(UDelMarAudioVirtualizationSubsystem, VehicleManager) == 0xb0, "Offset mismatch for UDelMarAudioVirtualizationSubsystem::VehicleManager");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FDelMarStateMix
{
    FGameplayTag MixStateTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FAudioMixModifierGroup ActorMixModifiers; // 0x8 (Size: 0x18, Type: StructProperty)
    USoundControlBusMix* ControlBusMix; // 0x20 (Size: 0x8, Type: ObjectProperty)
    bool bAutoDeactivate; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x3]; // 0x29 (Size: 0x3, Type: PaddingProperty)
    float duration; // 0x2c (Size: 0x4, Type: FloatProperty)
    FGameplayTag FallbackState; // 0x30 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarStateMix) == 0x38, "Size mismatch for FDelMarStateMix");
static_assert(offsetof(FDelMarStateMix, MixStateTag) == 0x0, "Offset mismatch for FDelMarStateMix::MixStateTag");
static_assert(offsetof(FDelMarStateMix, ActorMixModifiers) == 0x8, "Offset mismatch for FDelMarStateMix::ActorMixModifiers");
static_assert(offsetof(FDelMarStateMix, ControlBusMix) == 0x20, "Offset mismatch for FDelMarStateMix::ControlBusMix");
static_assert(offsetof(FDelMarStateMix, bAutoDeactivate) == 0x28, "Offset mismatch for FDelMarStateMix::bAutoDeactivate");
static_assert(offsetof(FDelMarStateMix, duration) == 0x2c, "Offset mismatch for FDelMarStateMix::duration");
static_assert(offsetof(FDelMarStateMix, FallbackState) == 0x30, "Offset mismatch for FDelMarStateMix::FallbackState");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarStateMixCollection
{
    FName Group; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FDelMarStateMix> Mixes; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FDelMarStateMixCollection) == 0x18, "Size mismatch for FDelMarStateMixCollection");
static_assert(offsetof(FDelMarStateMixCollection, Group) == 0x0, "Offset mismatch for FDelMarStateMixCollection::Group");
static_assert(offsetof(FDelMarStateMixCollection, Mixes) == 0x8, "Offset mismatch for FDelMarStateMixCollection::Mixes");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarEvent_AudioStateComponent
{
    UDelMarAudioStatePlayspaceComponent* StateComponent; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FDelMarEvent_AudioStateComponent) == 0x8, "Size mismatch for FDelMarEvent_AudioStateComponent");
static_assert(offsetof(FDelMarEvent_AudioStateComponent, StateComponent) == 0x0, "Offset mismatch for FDelMarEvent_AudioStateComponent::StateComponent");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FDelmarAudioVirtualizationSettings
{
    int32_t MaxNumPlayers; // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t MaxNumDistantPlayers; // 0x4 (Size: 0x4, Type: IntProperty)
    float DistantPlayerThreshold; // 0x8 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FDelmarAudioVirtualizationSettings) == 0xc, "Size mismatch for FDelmarAudioVirtualizationSettings");
static_assert(offsetof(FDelmarAudioVirtualizationSettings, MaxNumPlayers) == 0x0, "Offset mismatch for FDelmarAudioVirtualizationSettings::MaxNumPlayers");
static_assert(offsetof(FDelmarAudioVirtualizationSettings, MaxNumDistantPlayers) == 0x4, "Offset mismatch for FDelmarAudioVirtualizationSettings::MaxNumDistantPlayers");
static_assert(offsetof(FDelmarAudioVirtualizationSettings, DistantPlayerThreshold) == 0x8, "Offset mismatch for FDelmarAudioVirtualizationSettings::DistantPlayerThreshold");

