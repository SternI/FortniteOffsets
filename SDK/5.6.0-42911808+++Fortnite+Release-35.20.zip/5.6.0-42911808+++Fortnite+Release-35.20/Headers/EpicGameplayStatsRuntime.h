/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicGameplayStatsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UBlueprintGameplayStatsLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static bool EqualEqual_GameplayStatTagGameplayStatTag(FGameplayStatTag& A, FGameplayStatTag& B); // 0xcb7b71c (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool NotEqual_GameplayStatTagGameplayStatTag(FGameplayStatTag& A, FGameplayStatTag& B); // 0xcb7b888 (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UBlueprintGameplayStatsLibrary) == 0x28, "Size mismatch for UBlueprintGameplayStatsLibrary");

// Size: 0x98 (Inherited: 0x58, Single: 0x40)
class UGameplayTagTableManager : public UDataAsset
{
public:
    TArray<FManagedGameplayTagDataTableItem> Tables; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_40[0x58]; // 0x40 (Size: 0x58, Type: PaddingProperty)
};

static_assert(sizeof(UGameplayTagTableManager) == 0x98, "Size mismatch for UGameplayTagTableManager");
static_assert(offsetof(UGameplayTagTableManager, Tables) == 0x30, "Offset mismatch for UGameplayTagTableManager::Tables");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FTagTableManagerHelper
{
};

static_assert(sizeof(FTagTableManagerHelper) == 0x1, "Size mismatch for FTagTableManagerHelper");

// Size: 0x48 (Inherited: 0x8, Single: 0x40)
struct FGameplayStatMetadataTableRow : FTableRowBase
{
    FString BackendName; // 0x8 (Size: 0x10, Type: StrProperty)
    FText DisplayName; // 0x18 (Size: 0x10, Type: TextProperty)
    TArray<EEpicLeaderboardTimeWindow> Windows; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t Metric; // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t DataType; // 0x39 (Size: 0x1, Type: EnumProperty)
    bool bPublish; // 0x3a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3b[0x1]; // 0x3b (Size: 0x1, Type: PaddingProperty)
    int32_t WeeklyRefreshInterval; // 0x3c (Size: 0x4, Type: IntProperty)
    bool bExportToBackEnd; // 0x40 (Size: 0x1, Type: BoolProperty)
    bool bShowInFrontEnd; // 0x41 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_42[0x6]; // 0x42 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayStatMetadataTableRow) == 0x48, "Size mismatch for FGameplayStatMetadataTableRow");
static_assert(offsetof(FGameplayStatMetadataTableRow, BackendName) == 0x8, "Offset mismatch for FGameplayStatMetadataTableRow::BackendName");
static_assert(offsetof(FGameplayStatMetadataTableRow, DisplayName) == 0x18, "Offset mismatch for FGameplayStatMetadataTableRow::DisplayName");
static_assert(offsetof(FGameplayStatMetadataTableRow, Windows) == 0x28, "Offset mismatch for FGameplayStatMetadataTableRow::Windows");
static_assert(offsetof(FGameplayStatMetadataTableRow, Metric) == 0x38, "Offset mismatch for FGameplayStatMetadataTableRow::Metric");
static_assert(offsetof(FGameplayStatMetadataTableRow, DataType) == 0x39, "Offset mismatch for FGameplayStatMetadataTableRow::DataType");
static_assert(offsetof(FGameplayStatMetadataTableRow, bPublish) == 0x3a, "Offset mismatch for FGameplayStatMetadataTableRow::bPublish");
static_assert(offsetof(FGameplayStatMetadataTableRow, WeeklyRefreshInterval) == 0x3c, "Offset mismatch for FGameplayStatMetadataTableRow::WeeklyRefreshInterval");
static_assert(offsetof(FGameplayStatMetadataTableRow, bExportToBackEnd) == 0x40, "Offset mismatch for FGameplayStatMetadataTableRow::bExportToBackEnd");
static_assert(offsetof(FGameplayStatMetadataTableRow, bShowInFrontEnd) == 0x41, "Offset mismatch for FGameplayStatMetadataTableRow::bShowInFrontEnd");

// Size: 0x8 (Inherited: 0x4, Single: 0x4)
struct FGameplayStatTag : FGameplayTag
{
    FGameplayTag Tag; // 0x4 (Size: 0x4, Type: StructProperty)
};

static_assert(sizeof(FGameplayStatTag) == 0x8, "Size mismatch for FGameplayStatTag");
static_assert(offsetof(FGameplayStatTag, Tag) == 0x4, "Offset mismatch for FGameplayStatTag::Tag");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FManagedGameplayTagDataTableItem
{
    FGameplayTag RootTag; // 0x0 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    UDataTable* DataTable; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FManagedGameplayTagDataTableItem) == 0x10, "Size mismatch for FManagedGameplayTagDataTableItem");
static_assert(offsetof(FManagedGameplayTagDataTableItem, RootTag) == 0x0, "Offset mismatch for FManagedGameplayTagDataTableItem::RootTag");
static_assert(offsetof(FManagedGameplayTagDataTableItem, DataTable) == 0x8, "Offset mismatch for FManagedGameplayTagDataTableItem::DataTable");

