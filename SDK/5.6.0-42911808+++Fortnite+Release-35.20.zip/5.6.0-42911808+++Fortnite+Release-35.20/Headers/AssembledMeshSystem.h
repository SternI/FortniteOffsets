/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AssembledMeshSystem
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "RigVM.h"
#include "CosmeticsFrameworkItems.h"
#include "GameplayTags.h"
#include "CustomizableObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAssembledMeshUser_AttachToComponentSpecifier : public UInterface
{
public:
};

static_assert(sizeof(UAssembledMeshUser_AttachToComponentSpecifier) == 0x28, "Size mismatch for UAssembledMeshUser_AttachToComponentSpecifier");

// Size: 0x1e0 (Inherited: 0x88, Single: 0x158)
class UAssembledMeshSchema : public UPrimaryDataAsset
{
public:
    FGameplayTag MeshSchemaTag; // 0x30 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UCustomizableObjectInstance*> CustomizableObjectInstance; // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UCustomizableObject*> CustomizableObject; // 0x58 (Size: 0x20, Type: SoftObjectProperty)
    int32_t ComponentIndex; // 0x78 (Size: 0x4, Type: IntProperty)
    FName ComponentName; // 0x7c (Size: 0x4, Type: NameProperty)
    TSoftObjectPtr<USkeletalMesh*> SkeletalMesh; // 0x80 (Size: 0x20, Type: SoftObjectProperty)
    TMap<FString, FString> SelectedIntParams; // 0xa0 (Size: 0x50, Type: MapProperty)
    TMap<float, FString> SelectedFloatParams; // 0xf0 (Size: 0x50, Type: MapProperty)
    FAssembledMeshAttachmentRules AttachmentRules; // 0x140 (Size: 0x50, Type: StructProperty)
    TSoftClassPtr AnimClass; // 0x190 (Size: 0x20, Type: SoftClassProperty)
    FGameplayTagContainer SoundLibraryTags; // 0x1b0 (Size: 0x20, Type: StructProperty)
    TArray<FInstancedStruct> AdditionalData; // 0x1d0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UAssembledMeshSchema) == 0x1e0, "Size mismatch for UAssembledMeshSchema");
static_assert(offsetof(UAssembledMeshSchema, MeshSchemaTag) == 0x30, "Offset mismatch for UAssembledMeshSchema::MeshSchemaTag");
static_assert(offsetof(UAssembledMeshSchema, CustomizableObjectInstance) == 0x38, "Offset mismatch for UAssembledMeshSchema::CustomizableObjectInstance");
static_assert(offsetof(UAssembledMeshSchema, CustomizableObject) == 0x58, "Offset mismatch for UAssembledMeshSchema::CustomizableObject");
static_assert(offsetof(UAssembledMeshSchema, ComponentIndex) == 0x78, "Offset mismatch for UAssembledMeshSchema::ComponentIndex");
static_assert(offsetof(UAssembledMeshSchema, ComponentName) == 0x7c, "Offset mismatch for UAssembledMeshSchema::ComponentName");
static_assert(offsetof(UAssembledMeshSchema, SkeletalMesh) == 0x80, "Offset mismatch for UAssembledMeshSchema::SkeletalMesh");
static_assert(offsetof(UAssembledMeshSchema, SelectedIntParams) == 0xa0, "Offset mismatch for UAssembledMeshSchema::SelectedIntParams");
static_assert(offsetof(UAssembledMeshSchema, SelectedFloatParams) == 0xf0, "Offset mismatch for UAssembledMeshSchema::SelectedFloatParams");
static_assert(offsetof(UAssembledMeshSchema, AttachmentRules) == 0x140, "Offset mismatch for UAssembledMeshSchema::AttachmentRules");
static_assert(offsetof(UAssembledMeshSchema, AnimClass) == 0x190, "Offset mismatch for UAssembledMeshSchema::AnimClass");
static_assert(offsetof(UAssembledMeshSchema, SoundLibraryTags) == 0x1b0, "Offset mismatch for UAssembledMeshSchema::SoundLibraryTags");
static_assert(offsetof(UAssembledMeshSchema, AdditionalData) == 0x1d0, "Offset mismatch for UAssembledMeshSchema::AdditionalData");

// Size: 0x128 (Inherited: 0x278, Single: 0xfffffeb0)
class UHeadAccDataAssetLink : public UDataAssetLink
{
public:
};

static_assert(sizeof(UHeadAccDataAssetLink) == 0x128, "Size mismatch for UHeadAccDataAssetLink");

// Size: 0x128 (Inherited: 0x278, Single: 0xfffffeb0)
class UNeckAccDataAssetLink : public UDataAssetLink
{
public:
};

static_assert(sizeof(UNeckAccDataAssetLink) == 0x128, "Size mismatch for UNeckAccDataAssetLink");

// Size: 0x128 (Inherited: 0x278, Single: 0xfffffeb0)
class UHipAccDataAssetLink : public UDataAssetLink
{
public:
};

static_assert(sizeof(UHipAccDataAssetLink) == 0x128, "Size mismatch for UHipAccDataAssetLink");

// Size: 0x110 (Inherited: 0xe0, Single: 0x30)
class UAssembledMeshUserComponent : public UActorComponent
{
public:
    TArray<UObject*> LoadedAssets; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_c8[0x20]; // 0xc8 (Size: 0x20, Type: PaddingProperty)
    TArray<UAssembledMeshSchema*> MeshParts; // 0xe8 (Size: 0x10, Type: ArrayProperty)
    TArray<FAssembledComponentReferences> MeshPartComponents; // 0xf8 (Size: 0x10, Type: ArrayProperty)
    bool bDuplicateCOIs; // 0x108 (Size: 0x1, Type: BoolProperty)
    uint8_t bAssignMeshPartsOnBeginPlay : 1; // 0x109:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_10a[0x6]; // 0x10a (Size: 0x6, Type: PaddingProperty)

public:
    void GatherAndAssignAssembledMeshParts(); // 0x43388fc (Index: 0x1, Flags: Native|Public)

private:
    UAssembledMeshSchema* GetMeshPart() const; // 0xa5f3db8 (Index: 0x3, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
    void SetMeshPart(UAssembledMeshSchema*& InMeshPart); // 0xb251868 (Index: 0x5, Flags: Final|Native|Private|BlueprintCallable)
    void SetMeshParts(TArray<UAssembledMeshSchema*>& InMeshParts); // 0xb251d08 (Index: 0x6, Flags: Final|Native|Private|BlueprintCallable)

protected:
    void CustomizationCompleted(int32_t& const PartIndex); // 0xb251714 (Index: 0x0, Flags: Native|Protected)
    virtual USkeletalMeshComponent* GetAttachToComponent(); // 0xb251840 (Index: 0x2, Flags: Native|Event|Protected|BlueprintEvent)
    void OnRep_MeshParts(); // 0x4e31194 (Index: 0x4, Flags: Native|Protected)
};

static_assert(sizeof(UAssembledMeshUserComponent) == 0x110, "Size mismatch for UAssembledMeshUserComponent");
static_assert(offsetof(UAssembledMeshUserComponent, LoadedAssets) == 0xb8, "Offset mismatch for UAssembledMeshUserComponent::LoadedAssets");
static_assert(offsetof(UAssembledMeshUserComponent, MeshParts) == 0xe8, "Offset mismatch for UAssembledMeshUserComponent::MeshParts");
static_assert(offsetof(UAssembledMeshUserComponent, MeshPartComponents) == 0xf8, "Offset mismatch for UAssembledMeshUserComponent::MeshPartComponents");
static_assert(offsetof(UAssembledMeshUserComponent, bDuplicateCOIs) == 0x108, "Offset mismatch for UAssembledMeshUserComponent::bDuplicateCOIs");
static_assert(offsetof(UAssembledMeshUserComponent, bAssignMeshPartsOnBeginPlay) == 0x109, "Offset mismatch for UAssembledMeshUserComponent::bAssignMeshPartsOnBeginPlay");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FAssembledComponentReferences
{
    USkeletalMeshComponent* SkeletalMeshComponent; // 0x0 (Size: 0x8, Type: ObjectProperty)
    UCustomizableObjectInstanceUsage* CustomizableObjectInstanceUsage; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag AssembledMeshSchemaTag; // 0x10 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_14[0xc]; // 0x14 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FAssembledComponentReferences) == 0x20, "Size mismatch for FAssembledComponentReferences");
static_assert(offsetof(FAssembledComponentReferences, SkeletalMeshComponent) == 0x0, "Offset mismatch for FAssembledComponentReferences::SkeletalMeshComponent");
static_assert(offsetof(FAssembledComponentReferences, CustomizableObjectInstanceUsage) == 0x8, "Offset mismatch for FAssembledComponentReferences::CustomizableObjectInstanceUsage");
static_assert(offsetof(FAssembledComponentReferences, AssembledMeshSchemaTag) == 0x10, "Offset mismatch for FAssembledComponentReferences::AssembledMeshSchemaTag");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FAssembledMeshSchemaData
{
};

static_assert(sizeof(FAssembledMeshSchemaData) == 0x1, "Size mismatch for FAssembledMeshSchemaData");

// Size: 0x80 (Inherited: 0x1, Single: 0x7f)
struct FAssembledMeshSchemaData_Icons : FAssembledMeshSchemaData
{
    TSoftObjectPtr<UTexture2D*> WidePreviewImage; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D*> SmallPreviewImage; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D*> LargePreviewImage; // 0x40 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D*> FullScreenImage; // 0x60 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FAssembledMeshSchemaData_Icons) == 0x80, "Size mismatch for FAssembledMeshSchemaData_Icons");
static_assert(offsetof(FAssembledMeshSchemaData_Icons, WidePreviewImage) == 0x0, "Offset mismatch for FAssembledMeshSchemaData_Icons::WidePreviewImage");
static_assert(offsetof(FAssembledMeshSchemaData_Icons, SmallPreviewImage) == 0x20, "Offset mismatch for FAssembledMeshSchemaData_Icons::SmallPreviewImage");
static_assert(offsetof(FAssembledMeshSchemaData_Icons, LargePreviewImage) == 0x40, "Offset mismatch for FAssembledMeshSchemaData_Icons::LargePreviewImage");
static_assert(offsetof(FAssembledMeshSchemaData_Icons, FullScreenImage) == 0x60, "Offset mismatch for FAssembledMeshSchemaData_Icons::FullScreenImage");

// Size: 0x28 (Inherited: 0x4, Single: 0x24)
struct FCosmeticProperty_AssembledMeshSchema : FCosmeticPropertyBase
{
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UAssembledMeshSchema*> AssembledMeshSchema; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FCosmeticProperty_AssembledMeshSchema) == 0x28, "Size mismatch for FCosmeticProperty_AssembledMeshSchema");
static_assert(offsetof(FCosmeticProperty_AssembledMeshSchema, AssembledMeshSchema) == 0x8, "Offset mismatch for FCosmeticProperty_AssembledMeshSchema::AssembledMeshSchema");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FAssembledMeshAttachmentRules
{
    FName AttachSocketName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    FVector AttachOffset; // 0x8 (Size: 0x18, Type: StructProperty)
    FRotator AttachRotation; // 0x20 (Size: 0x18, Type: StructProperty)
    FVector AttachScale; // 0x38 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FAssembledMeshAttachmentRules) == 0x50, "Size mismatch for FAssembledMeshAttachmentRules");
static_assert(offsetof(FAssembledMeshAttachmentRules, AttachSocketName) == 0x0, "Offset mismatch for FAssembledMeshAttachmentRules::AttachSocketName");
static_assert(offsetof(FAssembledMeshAttachmentRules, AttachOffset) == 0x8, "Offset mismatch for FAssembledMeshAttachmentRules::AttachOffset");
static_assert(offsetof(FAssembledMeshAttachmentRules, AttachRotation) == 0x20, "Offset mismatch for FAssembledMeshAttachmentRules::AttachRotation");
static_assert(offsetof(FAssembledMeshAttachmentRules, AttachScale) == 0x38, "Offset mismatch for FAssembledMeshAttachmentRules::AttachScale");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FBaseParamData
{
    FString ParamName; // 0x0 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(FBaseParamData) == 0x10, "Size mismatch for FBaseParamData");
static_assert(offsetof(FBaseParamData, ParamName) == 0x0, "Offset mismatch for FBaseParamData::ParamName");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FIntParamData : FBaseParamData
{
    TArray<FString> ParamOptions; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FIntParamData) == 0x20, "Size mismatch for FIntParamData");
static_assert(offsetof(FIntParamData, ParamOptions) == 0x10, "Offset mismatch for FIntParamData::ParamOptions");

// Size: 0x20 (Inherited: 0x10, Single: 0x10)
struct FFloatParamData : FBaseParamData
{
    float FloatValue; // 0x10 (Size: 0x4, Type: FloatProperty)
    float MinFloatValue; // 0x14 (Size: 0x4, Type: FloatProperty)
    float MaxFloatValue; // 0x18 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FFloatParamData) == 0x20, "Size mismatch for FFloatParamData");
static_assert(offsetof(FFloatParamData, FloatValue) == 0x10, "Offset mismatch for FFloatParamData::FloatValue");
static_assert(offsetof(FFloatParamData, MinFloatValue) == 0x14, "Offset mismatch for FFloatParamData::MinFloatValue");
static_assert(offsetof(FFloatParamData, MaxFloatValue) == 0x18, "Offset mismatch for FFloatParamData::MaxFloatValue");

