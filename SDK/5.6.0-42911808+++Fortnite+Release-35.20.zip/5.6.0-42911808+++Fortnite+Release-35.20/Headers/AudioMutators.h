/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioMutators
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameFeatures.h"
#include "GameplayTags.h"
#include "AudioExtensions.h"

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UAudioMutator : public UAudioMutatorBase
{
public:
    TArray<FInstancedStruct> Selectors; // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> Actions; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UAudioMutator) == 0x48, "Size mismatch for UAudioMutator");
static_assert(offsetof(UAudioMutator, Selectors) == 0x28, "Offset mismatch for UAudioMutator::Selectors");
static_assert(offsetof(UAudioMutator, Actions) == 0x38, "Offset mismatch for UAudioMutator::Actions");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UAudioMutatorBase : public UObject
{
public:
};

static_assert(sizeof(UAudioMutatorBase) == 0x28, "Size mismatch for UAudioMutatorBase");

// Size: 0x58 (Inherited: 0xb8, Single: 0xffffffa0)
class UAudioMutatorsSubsystem : public UAudioEngineSubsystem
{
public:

public:
    void AddMutator(UAudioMutatorBase*& Mutator); // 0xc8433b8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveMutator(UAudioMutatorBase*& Mutator); // 0xc8435ac (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void ReplaceMutator(UAudioMutatorBase*& Mutator); // 0xc843720 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAudioMutatorsSubsystem) == 0x58, "Size mismatch for UAudioMutatorsSubsystem");

// Size: 0x98 (Inherited: 0xb8, Single: 0xffffffe0)
class UAudioOwnerRegistry : public UAudioEngineSubsystem
{
public:
};

static_assert(sizeof(UAudioOwnerRegistry) == 0x98, "Size mismatch for UAudioOwnerRegistry");

// Size: 0x50 (Inherited: 0x50, Single: 0x0)
class UAudioMutatorBespoke : public UAudioMutatorBase
{
public:
    TWeakObjectPtr<AActor*> Actor; // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    FGameplayTag Tag; // 0x30 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    TArray<FSourceEffectChainEntry> EffectChain; // 0x38 (Size: 0x10, Type: ArrayProperty)
    float PitchMultiplier; // 0x48 (Size: 0x4, Type: FloatProperty)
    float VolumeMultiplier; // 0x4c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UAudioMutatorBespoke) == 0x50, "Size mismatch for UAudioMutatorBespoke");
static_assert(offsetof(UAudioMutatorBespoke, Actor) == 0x28, "Offset mismatch for UAudioMutatorBespoke::Actor");
static_assert(offsetof(UAudioMutatorBespoke, Tag) == 0x30, "Offset mismatch for UAudioMutatorBespoke::Tag");
static_assert(offsetof(UAudioMutatorBespoke, EffectChain) == 0x38, "Offset mismatch for UAudioMutatorBespoke::EffectChain");
static_assert(offsetof(UAudioMutatorBespoke, PitchMultiplier) == 0x48, "Offset mismatch for UAudioMutatorBespoke::PitchMultiplier");
static_assert(offsetof(UAudioMutatorBespoke, VolumeMultiplier) == 0x4c, "Offset mismatch for UAudioMutatorBespoke::VolumeMultiplier");

// Size: 0x78 (Inherited: 0x50, Single: 0x28)
class UAudioMutatorReusingParts : public UAudioMutatorBase
{
public:
    FSoundSelectorActorInstance SelectorActorInstance; // 0x28 (Size: 0x10, Type: StructProperty)
    FSoundSelectorTag SelectorTag; // 0x38 (Size: 0x10, Type: StructProperty)
    FSoundActionPitch ActionPitch; // 0x48 (Size: 0x10, Type: StructProperty)
    FSoundActionSourceEffect ActionSourceEffect; // 0x58 (Size: 0x10, Type: StructProperty)
    FSoundActionVolume ActionVolume; // 0x68 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UAudioMutatorReusingParts) == 0x78, "Size mismatch for UAudioMutatorReusingParts");
static_assert(offsetof(UAudioMutatorReusingParts, SelectorActorInstance) == 0x28, "Offset mismatch for UAudioMutatorReusingParts::SelectorActorInstance");
static_assert(offsetof(UAudioMutatorReusingParts, SelectorTag) == 0x38, "Offset mismatch for UAudioMutatorReusingParts::SelectorTag");
static_assert(offsetof(UAudioMutatorReusingParts, ActionPitch) == 0x48, "Offset mismatch for UAudioMutatorReusingParts::ActionPitch");
static_assert(offsetof(UAudioMutatorReusingParts, ActionSourceEffect) == 0x58, "Offset mismatch for UAudioMutatorReusingParts::ActionSourceEffect");
static_assert(offsetof(UAudioMutatorReusingParts, ActionVolume) == 0x68, "Offset mismatch for UAudioMutatorReusingParts::ActionVolume");

// Size: 0x48 (Inherited: 0x88, Single: 0xffffffc0)
class UGameFeatureAction_AddAudioMutators : public UGameFeatureAction_AudioActionBase
{
public:
    TArray<UAudioMutatorBase*> Mutators; // 0x38 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UGameFeatureAction_AddAudioMutators) == 0x48, "Size mismatch for UGameFeatureAction_AddAudioMutators");
static_assert(offsetof(UGameFeatureAction_AddAudioMutators, Mutators) == 0x38, "Offset mismatch for UGameFeatureAction_AddAudioMutators::Mutators");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FAudioMutatorAction
{
};

static_assert(sizeof(FAudioMutatorAction) == 0x8, "Size mismatch for FAudioMutatorAction");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FAudioMutatorSelector
{
};

static_assert(sizeof(FAudioMutatorSelector) == 0x8, "Size mismatch for FAudioMutatorSelector");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FSoundActionModulator : FAudioMutatorAction
{
    USoundModulatorBase* Modulator; // 0x8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Destination; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FSoundActionModulator) == 0x18, "Size mismatch for FSoundActionModulator");
static_assert(offsetof(FSoundActionModulator, Modulator) == 0x8, "Offset mismatch for FSoundActionModulator::Modulator");
static_assert(offsetof(FSoundActionModulator, Destination) == 0x10, "Offset mismatch for FSoundActionModulator::Destination");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FSoundActionPitch : FAudioMutatorAction
{
    float PitchMultiplier; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FSoundActionPitch) == 0x10, "Size mismatch for FSoundActionPitch");
static_assert(offsetof(FSoundActionPitch, PitchMultiplier) == 0x8, "Offset mismatch for FSoundActionPitch::PitchMultiplier");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FSoundActionSourceEffect : FAudioMutatorAction
{
    USoundEffectSourcePresetChain* PresetChain; // 0x8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FSoundActionSourceEffect) == 0x10, "Size mismatch for FSoundActionSourceEffect");
static_assert(offsetof(FSoundActionSourceEffect, PresetChain) == 0x8, "Offset mismatch for FSoundActionSourceEffect::PresetChain");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FSoundActionSubmixSend : FAudioMutatorAction
{
    TArray<FSoundSubmixSendInfo> SubmixSends; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FSoundActionSubmixSend) == 0x18, "Size mismatch for FSoundActionSubmixSend");
static_assert(offsetof(FSoundActionSubmixSend, SubmixSends) == 0x8, "Offset mismatch for FSoundActionSubmixSend::SubmixSends");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FSoundActionVolume : FAudioMutatorAction
{
    float VolumeMultiplier; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FSoundActionVolume) == 0x10, "Size mismatch for FSoundActionVolume");
static_assert(offsetof(FSoundActionVolume, VolumeMultiplier) == 0x8, "Offset mismatch for FSoundActionVolume::VolumeMultiplier");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FSoundSelectorActorClass : FAudioMutatorSelector
{
    UClass* ActorClass; // 0x8 (Size: 0x8, Type: ClassProperty)
    bool bExactClass; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FSoundSelectorActorClass) == 0x18, "Size mismatch for FSoundSelectorActorClass");
static_assert(offsetof(FSoundSelectorActorClass, ActorClass) == 0x8, "Offset mismatch for FSoundSelectorActorClass::ActorClass");
static_assert(offsetof(FSoundSelectorActorClass, bExactClass) == 0x10, "Offset mismatch for FSoundSelectorActorClass::bExactClass");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FSoundSelectorActorInstance : FAudioMutatorSelector
{
    TWeakObjectPtr<AActor*> Actor; // 0x8 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FSoundSelectorActorInstance) == 0x10, "Size mismatch for FSoundSelectorActorInstance");
static_assert(offsetof(FSoundSelectorActorInstance, Actor) == 0x8, "Offset mismatch for FSoundSelectorActorInstance::Actor");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FSoundSelectorSoundBaseSubclass : FAudioMutatorSelector
{
    UClass* SoundBaseSubclass; // 0x8 (Size: 0x8, Type: ClassProperty)
    bool bExactClass; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FSoundSelectorSoundBaseSubclass) == 0x18, "Size mismatch for FSoundSelectorSoundBaseSubclass");
static_assert(offsetof(FSoundSelectorSoundBaseSubclass, SoundBaseSubclass) == 0x8, "Offset mismatch for FSoundSelectorSoundBaseSubclass::SoundBaseSubclass");
static_assert(offsetof(FSoundSelectorSoundBaseSubclass, bExactClass) == 0x10, "Offset mismatch for FSoundSelectorSoundBaseSubclass::bExactClass");

// Size: 0x18 (Inherited: 0x8, Single: 0x10)
struct FSoundSelectorSoundClass : FAudioMutatorSelector
{
    USoundClass* SoundClass; // 0x8 (Size: 0x8, Type: ObjectProperty)
    bool bExactClass; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FSoundSelectorSoundClass) == 0x18, "Size mismatch for FSoundSelectorSoundClass");
static_assert(offsetof(FSoundSelectorSoundClass, SoundClass) == 0x8, "Offset mismatch for FSoundSelectorSoundClass::SoundClass");
static_assert(offsetof(FSoundSelectorSoundClass, bExactClass) == 0x10, "Offset mismatch for FSoundSelectorSoundClass::bExactClass");

// Size: 0x10 (Inherited: 0x8, Single: 0x8)
struct FSoundSelectorTag : FAudioMutatorSelector
{
    FGameplayTag Tag; // 0x8 (Size: 0x4, Type: StructProperty)
    bool bExactMatch; // 0xc (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d[0x3]; // 0xd (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FSoundSelectorTag) == 0x10, "Size mismatch for FSoundSelectorTag");
static_assert(offsetof(FSoundSelectorTag, Tag) == 0x8, "Offset mismatch for FSoundSelectorTag::Tag");
static_assert(offsetof(FSoundSelectorTag, bExactMatch) == 0xc, "Offset mismatch for FSoundSelectorTag::bExactMatch");

