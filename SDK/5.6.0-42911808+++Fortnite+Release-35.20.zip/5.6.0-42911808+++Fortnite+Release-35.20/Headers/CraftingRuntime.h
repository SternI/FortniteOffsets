/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CraftingRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "ModularGameplay.h"
#include "CoreUObject.h"
#include "ItemShopHelperRuntime.h"
#include "GameplayTags.h"
#include "UMG.h"
#include "GameplayAbilities.h"
#include "DataRegistry.h"
#include "ItemizationCoreRuntime.h"

// Size: 0xa18 (Inherited: 0x13c8, Single: 0xfffff650)
class ACraftingObjectBGA : public ABuildingGameplayActor
{
public:
    uint8_t Pad_9b0[0x8]; // 0x9b0 (Size: 0x8, Type: PaddingProperty)
    AFortInventory* Inventory; // 0x9b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_9c0[0x18]; // 0x9c0 (Size: 0x18, Type: PaddingProperty)
    USphereComponent* SphereComponent_InteractionRange; // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    TSoftClassPtr MenuWidget; // 0x9e0 (Size: 0x20, Type: SoftClassProperty)
    UWidgetComponent* WidgetComponent_PotContents; // 0xa00 (Size: 0x8, Type: ObjectProperty)
    bool bShowCraftingUI; // 0xa08 (Size: 0x1, Type: BoolProperty)
    bool bSendEventMessageOnLocalInteract; // 0xa09 (Size: 0x1, Type: BoolProperty)
    bool bRunServerInteractionWhenSendingEventMessage; // 0xa0a (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a0b[0x5]; // 0xa0b (Size: 0x5, Type: PaddingProperty)
    UStaticMeshComponent* CraftingObjectMesh; // 0xa10 (Size: 0x8, Type: ObjectProperty)

public:
    void HandleInteractionRangeBeginOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex, bool& bFromSweep, const FHitResult SweepResult); // 0xd7defd4 (Index: 0x0, Flags: Native|Public|HasOutParms)
    void HandleInteractionRangeEndOverlap(UPrimitiveComponent*& OverlappedComponent, AActor*& OtherActor, UPrimitiveComponent*& OtherComp, int32_t& OtherBodyIndex); // 0xd7df544 (Index: 0x1, Flags: Native|Public)
};

static_assert(sizeof(ACraftingObjectBGA) == 0xa18, "Size mismatch for ACraftingObjectBGA");
static_assert(offsetof(ACraftingObjectBGA, Inventory) == 0x9b8, "Offset mismatch for ACraftingObjectBGA::Inventory");
static_assert(offsetof(ACraftingObjectBGA, SphereComponent_InteractionRange) == 0x9d8, "Offset mismatch for ACraftingObjectBGA::SphereComponent_InteractionRange");
static_assert(offsetof(ACraftingObjectBGA, MenuWidget) == 0x9e0, "Offset mismatch for ACraftingObjectBGA::MenuWidget");
static_assert(offsetof(ACraftingObjectBGA, WidgetComponent_PotContents) == 0xa00, "Offset mismatch for ACraftingObjectBGA::WidgetComponent_PotContents");
static_assert(offsetof(ACraftingObjectBGA, bShowCraftingUI) == 0xa08, "Offset mismatch for ACraftingObjectBGA::bShowCraftingUI");
static_assert(offsetof(ACraftingObjectBGA, bSendEventMessageOnLocalInteract) == 0xa09, "Offset mismatch for ACraftingObjectBGA::bSendEventMessageOnLocalInteract");
static_assert(offsetof(ACraftingObjectBGA, bRunServerInteractionWhenSendingEventMessage) == 0xa0a, "Offset mismatch for ACraftingObjectBGA::bRunServerInteractionWhenSendingEventMessage");
static_assert(offsetof(ACraftingObjectBGA, CraftingObjectMesh) == 0xa10, "Offset mismatch for ACraftingObjectBGA::CraftingObjectMesh");

// Size: 0x28 (Inherited: 0x78, Single: 0xffffffb0)
class UCraftingCheatManager : public UChildCheatManager
{
public:

public:
    void StartSelfCrafting(FName& FormulaName); // 0xa28ddc8 (Index: 0x0, Flags: Final|BlueprintAuthorityOnly|Exec|Native|Public)
    void ToggleFreeCrafting(); // 0x554e3c4 (Index: 0x1, Flags: Final|Exec|Native|Public)
};

static_assert(sizeof(UCraftingCheatManager) == 0x28, "Size mismatch for UCraftingCheatManager");

// Size: 0x510 (Inherited: 0x198, Single: 0x378)
class UCraftingObjectComponent : public UGameFrameworkComponent
{
public:
    uint8_t CraftingObjectStateChanged[0x10]; // 0xb8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnFormulaCraftableChanged[0x10]; // 0xc8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCraftingSuccess[0x10]; // 0xd8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCraftingAdditionalValidationCheck[0xc]; // 0xe8 (Size: 0xc, Type: DelegateProperty)
    uint8_t Pad_f4[0x1c]; // 0xf4 (Size: 0x1c, Type: PaddingProperty)
    FCraftingObjectRepStateData CraftingObjectRepStateData; // 0x110 (Size: 0x18, Type: StructProperty)
    TMap<FCraftingObjectServerStateData, FCraftingMultiKey> CraftingObjectServerStateData; // 0x128 (Size: 0x50, Type: MapProperty)
    FName LastCraftedItemFormulaRow; // 0x178 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_17c[0x4]; // 0x17c (Size: 0x4, Type: PaddingProperty)
    FString LastIngredientStringForAnalytics; // 0x180 (Size: 0x10, Type: StrProperty)
    FString LastFormulaStringForAnalytics; // 0x190 (Size: 0x10, Type: StrProperty)
    FString LastResultsStringForAnalytics; // 0x1a0 (Size: 0x10, Type: StrProperty)
    FGameplayAbilitySpecHandle WhileCraftingAbilitySpecHandle; // 0x1b0 (Size: 0x4, Type: StructProperty)
    FGameplayAbilitySpecHandle OwnerCraftingAbilitySpecHandle; // 0x1b4 (Size: 0x4, Type: StructProperty)
    FGameplayTag CraftingObjectTag; // 0x1b8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1bc[0x4]; // 0x1bc (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer CraftingObjectTags; // 0x1c0 (Size: 0x20, Type: StructProperty)
    FScalableFloat CraftingTimeLength; // 0x1e0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ReadyTimeLength; // 0x208 (Size: 0x28, Type: StructProperty)
    FScalableFloat OverCraftingTimeLength; // 0x230 (Size: 0x28, Type: StructProperty)
    FScalableFloat ResettingTimeLength; // 0x258 (Size: 0x28, Type: StructProperty)
    FScalableFloat DefaultCraftingSpeedMultiplier; // 0x280 (Size: 0x28, Type: StructProperty)
    FName OverCraftingLootTierKey; // 0x2a8 (Size: 0x4, Type: NameProperty)
    uint8_t bTakeItemsAtCraftingStart : 1; // 0x2ac:0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2ad[0x3]; // 0x2ad (Size: 0x3, Type: PaddingProperty)
    float DecayRate; // 0x2b0 (Size: 0x4, Type: FloatProperty)
    uint8_t bGiveIngredientsToCraftingObject : 1; // 0x2b4:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bGiveIngredientsToInstigator : 1; // 0x2b4:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b5[0x3]; // 0x2b5 (Size: 0x3, Type: PaddingProperty)
    FVector IngredientSpawnOffset; // 0x2b8 (Size: 0x18, Type: StructProperty)
    uint8_t bPrioritizeSmallestIngredientStacks : 1; // 0x2d0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bGiveToCraftingObject : 1; // 0x2d0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bGiveResultToInstigator : 1; // 0x2d0:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2d1[0x7]; // 0x2d1 (Size: 0x7, Type: PaddingProperty)
    TSoftClassPtr OwnerCraftingAbility; // 0x2d8 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr WhileCraftingAbility; // 0x2f8 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr InstigatorWhileCraftingAbility; // 0x318 (Size: 0x20, Type: SoftClassProperty)
    bool bScaleMultiCraftingTime; // 0x338 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_339[0x7]; // 0x339 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagContainer CraftingFailedTags; // 0x340 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_360[0x138]; // 0x360 (Size: 0x138, Type: PaddingProperty)
    FGameplayTagContainer IngredientsInventoryGroupTag; // 0x498 (Size: 0x20, Type: StructProperty)
    uint8_t Pad_4b8[0x50]; // 0x4b8 (Size: 0x50, Type: PaddingProperty)
    bool FreeCraftingEnabled; // 0x508 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_509[0x7]; // 0x509 (Size: 0x7, Type: PaddingProperty)

public:
    void CraftingObjectOnFormulaCraftableChanged__DelegateSignature(const FName FormulaRowName, bool& bIsCraftable); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate|HasOutParms)

private:
    void HandlePickupCraftingItemPickedUp(AFortPickup*& Pickup, AFortPawn*& InteractingPawn); // 0x101d6b34 (Index: 0x1, Flags: Final|Native|Private)
    void OnRep_CraftingObjectRepStateData(const FCraftingObjectRepStateData OldValue); // 0x101d7df4 (Index: 0x2, Flags: Final|Native|Private|HasOutParms)
    void OnRep_CraftingObjectTags(); // 0x101d7ed8 (Index: 0x3, Flags: Final|Native|Private)
};

static_assert(sizeof(UCraftingObjectComponent) == 0x510, "Size mismatch for UCraftingObjectComponent");
static_assert(offsetof(UCraftingObjectComponent, CraftingObjectStateChanged) == 0xb8, "Offset mismatch for UCraftingObjectComponent::CraftingObjectStateChanged");
static_assert(offsetof(UCraftingObjectComponent, OnFormulaCraftableChanged) == 0xc8, "Offset mismatch for UCraftingObjectComponent::OnFormulaCraftableChanged");
static_assert(offsetof(UCraftingObjectComponent, OnCraftingSuccess) == 0xd8, "Offset mismatch for UCraftingObjectComponent::OnCraftingSuccess");
static_assert(offsetof(UCraftingObjectComponent, OnCraftingAdditionalValidationCheck) == 0xe8, "Offset mismatch for UCraftingObjectComponent::OnCraftingAdditionalValidationCheck");
static_assert(offsetof(UCraftingObjectComponent, CraftingObjectRepStateData) == 0x110, "Offset mismatch for UCraftingObjectComponent::CraftingObjectRepStateData");
static_assert(offsetof(UCraftingObjectComponent, CraftingObjectServerStateData) == 0x128, "Offset mismatch for UCraftingObjectComponent::CraftingObjectServerStateData");
static_assert(offsetof(UCraftingObjectComponent, LastCraftedItemFormulaRow) == 0x178, "Offset mismatch for UCraftingObjectComponent::LastCraftedItemFormulaRow");
static_assert(offsetof(UCraftingObjectComponent, LastIngredientStringForAnalytics) == 0x180, "Offset mismatch for UCraftingObjectComponent::LastIngredientStringForAnalytics");
static_assert(offsetof(UCraftingObjectComponent, LastFormulaStringForAnalytics) == 0x190, "Offset mismatch for UCraftingObjectComponent::LastFormulaStringForAnalytics");
static_assert(offsetof(UCraftingObjectComponent, LastResultsStringForAnalytics) == 0x1a0, "Offset mismatch for UCraftingObjectComponent::LastResultsStringForAnalytics");
static_assert(offsetof(UCraftingObjectComponent, WhileCraftingAbilitySpecHandle) == 0x1b0, "Offset mismatch for UCraftingObjectComponent::WhileCraftingAbilitySpecHandle");
static_assert(offsetof(UCraftingObjectComponent, OwnerCraftingAbilitySpecHandle) == 0x1b4, "Offset mismatch for UCraftingObjectComponent::OwnerCraftingAbilitySpecHandle");
static_assert(offsetof(UCraftingObjectComponent, CraftingObjectTag) == 0x1b8, "Offset mismatch for UCraftingObjectComponent::CraftingObjectTag");
static_assert(offsetof(UCraftingObjectComponent, CraftingObjectTags) == 0x1c0, "Offset mismatch for UCraftingObjectComponent::CraftingObjectTags");
static_assert(offsetof(UCraftingObjectComponent, CraftingTimeLength) == 0x1e0, "Offset mismatch for UCraftingObjectComponent::CraftingTimeLength");
static_assert(offsetof(UCraftingObjectComponent, ReadyTimeLength) == 0x208, "Offset mismatch for UCraftingObjectComponent::ReadyTimeLength");
static_assert(offsetof(UCraftingObjectComponent, OverCraftingTimeLength) == 0x230, "Offset mismatch for UCraftingObjectComponent::OverCraftingTimeLength");
static_assert(offsetof(UCraftingObjectComponent, ResettingTimeLength) == 0x258, "Offset mismatch for UCraftingObjectComponent::ResettingTimeLength");
static_assert(offsetof(UCraftingObjectComponent, DefaultCraftingSpeedMultiplier) == 0x280, "Offset mismatch for UCraftingObjectComponent::DefaultCraftingSpeedMultiplier");
static_assert(offsetof(UCraftingObjectComponent, OverCraftingLootTierKey) == 0x2a8, "Offset mismatch for UCraftingObjectComponent::OverCraftingLootTierKey");
static_assert(offsetof(UCraftingObjectComponent, bTakeItemsAtCraftingStart) == 0x2ac, "Offset mismatch for UCraftingObjectComponent::bTakeItemsAtCraftingStart");
static_assert(offsetof(UCraftingObjectComponent, DecayRate) == 0x2b0, "Offset mismatch for UCraftingObjectComponent::DecayRate");
static_assert(offsetof(UCraftingObjectComponent, bGiveIngredientsToCraftingObject) == 0x2b4, "Offset mismatch for UCraftingObjectComponent::bGiveIngredientsToCraftingObject");
static_assert(offsetof(UCraftingObjectComponent, bGiveIngredientsToInstigator) == 0x2b4, "Offset mismatch for UCraftingObjectComponent::bGiveIngredientsToInstigator");
static_assert(offsetof(UCraftingObjectComponent, IngredientSpawnOffset) == 0x2b8, "Offset mismatch for UCraftingObjectComponent::IngredientSpawnOffset");
static_assert(offsetof(UCraftingObjectComponent, bPrioritizeSmallestIngredientStacks) == 0x2d0, "Offset mismatch for UCraftingObjectComponent::bPrioritizeSmallestIngredientStacks");
static_assert(offsetof(UCraftingObjectComponent, bGiveToCraftingObject) == 0x2d0, "Offset mismatch for UCraftingObjectComponent::bGiveToCraftingObject");
static_assert(offsetof(UCraftingObjectComponent, bGiveResultToInstigator) == 0x2d0, "Offset mismatch for UCraftingObjectComponent::bGiveResultToInstigator");
static_assert(offsetof(UCraftingObjectComponent, OwnerCraftingAbility) == 0x2d8, "Offset mismatch for UCraftingObjectComponent::OwnerCraftingAbility");
static_assert(offsetof(UCraftingObjectComponent, WhileCraftingAbility) == 0x2f8, "Offset mismatch for UCraftingObjectComponent::WhileCraftingAbility");
static_assert(offsetof(UCraftingObjectComponent, InstigatorWhileCraftingAbility) == 0x318, "Offset mismatch for UCraftingObjectComponent::InstigatorWhileCraftingAbility");
static_assert(offsetof(UCraftingObjectComponent, bScaleMultiCraftingTime) == 0x338, "Offset mismatch for UCraftingObjectComponent::bScaleMultiCraftingTime");
static_assert(offsetof(UCraftingObjectComponent, CraftingFailedTags) == 0x340, "Offset mismatch for UCraftingObjectComponent::CraftingFailedTags");
static_assert(offsetof(UCraftingObjectComponent, IngredientsInventoryGroupTag) == 0x498, "Offset mismatch for UCraftingObjectComponent::IngredientsInventoryGroupTag");
static_assert(offsetof(UCraftingObjectComponent, FreeCraftingEnabled) == 0x508, "Offset mismatch for UCraftingObjectComponent::FreeCraftingEnabled");

// Size: 0xd0 (Inherited: 0x310, Single: 0xfffffdc0)
class UFortControllerComponent_CraftingNetworkEvents : public UFortControllerComponent
{
public:
    uint8_t OnCraftingSuccess[0x10]; // 0xc0 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    virtual void ClientNotifyCraftingFailed(AActor*& CraftingObject, FGameplayTagContainer& const FailedReason, FCraftingMultiKey& Key); // 0x101d1820 (Index: 0x0, Flags: Net|Native|Event|Public|NetClient)
    virtual void ClientNotifyCraftingSuccess(AActor*& CraftingObject, FName& const FormulaRowName, TArray<FFortItemEntry>& const ConsumedIngredients, FCraftingMultiKey& Key); // 0x101d1c5c (Index: 0x1, Flags: Net|NetReliableNative|Event|Public|NetClient)
    void NotifyCraftingSuccess(AActor*& CraftingObject, const FName FormulaRowName, const TArray<FFortItemEntry> ConsumedIngredients, FCraftingMultiKey& Key); // 0x101d7528 (Index: 0x2, Flags: Final|Native|Public|HasOutParms)
    virtual void ServerCancelCrafting(AActor*& CraftingObject, FCraftingMultiKey& Key); // 0x101d8c80 (Index: 0x3, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate)
    virtual void ServerClaimCraftingResults(AActor*& CraftingObject, FCraftingMultiKey& Key); // 0x101d8e48 (Index: 0x4, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate)
    virtual void ServerEjectItems(AActor*& CraftingObject); // 0x101d9010 (Index: 0x5, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate)
    virtual void ServerPauseCrafting(AActor*& CraftingObject, bool& bDecayPausedTime, FCraftingMultiKey& Key); // 0x101d9158 (Index: 0x6, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate)
    virtual void ServerPickupItemAndStartCrafting(AActor*& CraftingObject, AFortPickup*& Pickup, FName& const CraftingFormulaName, FCraftingMultiKey& Key); // 0x101d9400 (Index: 0x7, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate)
    virtual void ServerReportCraftingSuccess(AActor*& CraftingObject, FCraftingMultiKey& Key); // 0x101d9788 (Index: 0x8, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate)
    virtual void ServerResumeCrafting(AActor*& CraftingObject, FCraftingMultiKey& Key); // 0x101d9950 (Index: 0x9, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate)
    virtual void ServerStartCrafting(AActor*& CraftingObject, FName& const CraftingFormulaName, int32_t& const NumberToCraft, FCraftingMultiKey& Key, float& const OverriddenObjectStateLength); // 0x101d9b18 (Index: 0xa, Flags: Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate)
};

static_assert(sizeof(UFortControllerComponent_CraftingNetworkEvents) == 0xd0, "Size mismatch for UFortControllerComponent_CraftingNetworkEvents");
static_assert(offsetof(UFortControllerComponent_CraftingNetworkEvents, OnCraftingSuccess) == 0xc0, "Offset mismatch for UFortControllerComponent_CraftingNetworkEvents::OnCraftingSuccess");

// Size: 0x268 (Inherited: 0x308, Single: 0xffffff60)
class UFortGameStateComponent_Crafting : public UFortGameStateComponent
{
public:
    FDataRegistryType CraftingFormulaRegistryType; // 0xb8 (Size: 0x4, Type: StructProperty)
    FDataRegistryType CraftingIngredientsUIDataRegistryType; // 0xbc (Size: 0x4, Type: StructProperty)
    uint8_t Pad_c0[0x148]; // 0xc0 (Size: 0x148, Type: PaddingProperty)
    TArray<FCraftingResult> CraftingResultsList; // 0x208 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_218[0x50]; // 0x218 (Size: 0x50, Type: PaddingProperty)

protected:
    void OnPlaylistDataReady(AFortGameStateAthena*& GameState, UFortPlaylist*& const Playlist, const FGameplayTagContainer PlaylistContextTags); // 0x101d791c (Index: 0x0, Flags: RequiredAPI|Native|Protected|HasOutParms)
    void OnRep_CraftingResultsList(); // 0x101d7f2c (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UFortGameStateComponent_Crafting) == 0x268, "Size mismatch for UFortGameStateComponent_Crafting");
static_assert(offsetof(UFortGameStateComponent_Crafting, CraftingFormulaRegistryType) == 0xb8, "Offset mismatch for UFortGameStateComponent_Crafting::CraftingFormulaRegistryType");
static_assert(offsetof(UFortGameStateComponent_Crafting, CraftingIngredientsUIDataRegistryType) == 0xbc, "Offset mismatch for UFortGameStateComponent_Crafting::CraftingIngredientsUIDataRegistryType");
static_assert(offsetof(UFortGameStateComponent_Crafting, CraftingResultsList) == 0x208, "Offset mismatch for UFortGameStateComponent_Crafting::CraftingResultsList");

// Size: 0xf8 (Inherited: 0x270, Single: 0xfffffe88)
class UFortPickupInteractOverrideComponent_Crafting : public UFortPickupInteractOverrideComponent
{
public:
    UItemDefinitionBase* LastPickupItemDef; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UItemDefinitionBase* LastFocusedItemDef; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    FName LastTargetFormulaName; // 0xe8 (Size: 0x4, Type: NameProperty)
    float ContextualCraftingInteractDuration; // 0xec (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<TInteractionType> CachedInteractionType; // 0xf0 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EInteractionBeingAttempted> CachedInteractionBeingAttempted; // 0xf1 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_f2[0x6]; // 0xf2 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UFortPickupInteractOverrideComponent_Crafting) == 0xf8, "Size mismatch for UFortPickupInteractOverrideComponent_Crafting");
static_assert(offsetof(UFortPickupInteractOverrideComponent_Crafting, LastPickupItemDef) == 0xd8, "Offset mismatch for UFortPickupInteractOverrideComponent_Crafting::LastPickupItemDef");
static_assert(offsetof(UFortPickupInteractOverrideComponent_Crafting, LastFocusedItemDef) == 0xe0, "Offset mismatch for UFortPickupInteractOverrideComponent_Crafting::LastFocusedItemDef");
static_assert(offsetof(UFortPickupInteractOverrideComponent_Crafting, LastTargetFormulaName) == 0xe8, "Offset mismatch for UFortPickupInteractOverrideComponent_Crafting::LastTargetFormulaName");
static_assert(offsetof(UFortPickupInteractOverrideComponent_Crafting, ContextualCraftingInteractDuration) == 0xec, "Offset mismatch for UFortPickupInteractOverrideComponent_Crafting::ContextualCraftingInteractDuration");
static_assert(offsetof(UFortPickupInteractOverrideComponent_Crafting, CachedInteractionType) == 0xf0, "Offset mismatch for UFortPickupInteractOverrideComponent_Crafting::CachedInteractionType");
static_assert(offsetof(UFortPickupInteractOverrideComponent_Crafting, CachedInteractionBeingAttempted) == 0xf1, "Offset mismatch for UFortPickupInteractOverrideComponent_Crafting::CachedInteractionBeingAttempted");

// Size: 0xf0 (Inherited: 0x118, Single: 0xffffffd8)
class UFortContextualTutorial_CraftingComplete : public UFortContextualTutorial
{
public:

private:
    void OnCraftingSuccess(const FCraftingObjectSuccessEvent Event); // 0x101d7830 (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UFortContextualTutorial_CraftingComplete) == 0xf0, "Size mismatch for UFortContextualTutorial_CraftingComplete");

// Size: 0xf0 (Inherited: 0x118, Single: 0xffffffd8)
class UFortContextualTutorial_CraftingReady : public UFortContextualTutorial
{
public:

private:
    void HandleFormulaCraftableChanged(const FName FormulaRowName, bool& bIsCraftable); // 0x101d673c (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
};

static_assert(sizeof(UFortContextualTutorial_CraftingReady) == 0xf0, "Size mismatch for UFortContextualTutorial_CraftingReady");

// Size: 0xf8 (Inherited: 0x118, Single: 0xffffffe0)
class UFortContextualTutorial_CraftingTabOpen : public UFortContextualTutorial
{
public:

private:
    void HandleFormulaCraftableChanged(const FName FormulaRowName, bool& bIsCraftable); // 0x101d68ac (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
    void HandleInventoryTabChanged(FName& const InventoryTabNameId); // 0x101d6a0c (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UFortContextualTutorial_CraftingTabOpen) == 0xf8, "Size mismatch for UFortContextualTutorial_CraftingTabOpen");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCraftingLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void CancelAllCrafting(AActor*& CraftingObject); // 0x6023a08 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void CancelCrafting(AFortPlayerController*& Instigator, AActor*& CraftingObject, FCraftingMultiKey& Key); // 0x101d12bc (Index: 0x1, Flags: Final|Native|Static|Public|BlueprintCallable)
    static bool CanCraftFormula(AFortPlayerController*& const FortPC, AActor*& const CraftingObject, FName& const CraftingFormulaRow, TArray<FCraftingIngredientQueryState>& OutIngredientStates, int32_t& const NumberToCraft, const FGameplayTagContainer InInventoryGroups); // 0x101d07e4 (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool CanCraftFormulaWithAdditionalItems(AFortPlayerController*& const FortPC, AActor*& const CraftingObject, FName& const CraftingFormulaRow, const TArray<FItemAndCount> AdditionalItems, TArray<FCraftingIngredientQueryState>& OutIngredientStates, int32_t& const NumberToCraft, const FGameplayTagContainer InInventoryGroups); // 0x101d0c20 (Index: 0x3, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool CanCraftFormulaWithParameters(const FCraftingQueryParameters Parameters, TArray<FCraftingIngredientQueryState>& OutIngredientStates); // 0x101d1108 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ClaimCraftingResults(AFortPlayerController*& Instigator, AActor*& CraftingObject, FCraftingMultiKey& Key); // 0x101d156c (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void EjectItems(AFortPlayerController*& Instigator, AActor*& CraftingObject); // 0x101d1fbc (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void GetAllCraftableFormulas(AFortPlayerController*& const FortPC, AActor*& const CraftingObject, TArray<FName>& OutFormulas); // 0x101d21f8 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetAllCraftingFormulas(AFortPlayerController*& const FortPC, AActor*& const CraftingObject, TArray<FName>& OutFormulas); // 0x101d2650 (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetAllValidIngredients(AFortPlayerController*& const FortPC, AActor*& const CraftingObject, TArray<FGameplayTagContainer>& OutIngredients); // 0x101d2ab0 (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static TArray<UFortWorldItem*> GetCraftedResults_TempItems(AActor*& CraftingObject, FCraftingMultiKey& Key); // 0x101d2da4 (Index: 0xa, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void GetCraftingDetailsForRowName(UObject*& const WorldContextObject, const FName CraftingFormulaRow, FCraftingFormula& OutFormulaDetails, bool& bOutFoundDetails); // 0x101d3118 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool GetCraftingFormulaIngredientRequirements(UObject*& const WorldContextObject, const FName CraftingFormulaRow, TArray<FCraftingIngredientRequirement>& OutIngredientRequirements); // 0x101d3428 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FName GetCraftingFormulaNameBeingCrafted(AActor*& CraftingObject, FCraftingMultiKey& Key); // 0x101d366c (Index: 0xd, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void GetCraftingFormulasForCraftingObject(AActor*& const CraftingObject, TArray<FName>& OutFormulas); // 0x101d380c (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static TArray<UFortWorldItem*> GetCraftingIngredients_TempItems(AActor*& CraftingObject, FCraftingMultiKey& Key); // 0x101d3b90 (Index: 0xf, Flags: Final|Native|Static|Public|BlueprintCallable)
    static UCraftingObjectComponent* GetCraftingObjectComponent(AActor*& const CraftingObject); // 0x101d3f04 (Index: 0x10, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static ECraftingObjectState GetCraftingObjectCraftingState(AActor*& CraftingObject, FCraftingMultiKey& Key); // 0x101d4038 (Index: 0x11, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static float GetCraftingObjectCurrentCraftingStateEndTime(AActor*& const CraftingObject, FCraftingMultiKey& Key); // 0x101d41e0 (Index: 0x12, Flags: Final|Native|Static|Public|BlueprintCallable)
    static float GetCraftingObjectCurrentCraftingStateStartTime(AActor*& const CraftingObject, FCraftingMultiKey& Key); // 0x101d4394 (Index: 0x13, Flags: Final|Native|Static|Public|BlueprintCallable)
    static float GetCraftingObjectCurrentCraftingStateTimeLeft(AActor*& const CraftingObject, FCraftingMultiKey& Key); // 0x101d4540 (Index: 0x14, Flags: Final|Native|Static|Public|BlueprintCallable)
    static float GetCraftingObjectPausedTime(AActor*& const CraftingObject, FCraftingMultiKey& Key); // 0x101d46f4 (Index: 0x15, Flags: Final|Native|Static|Public|BlueprintCallable)
    static FGameplayTagContainer GetCraftingObjectTags(AActor*& const CraftingObject); // 0x101d48a8 (Index: 0x16, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static void GetCraftingResultsForRowName(UObject*& const WorldContextObject, const FName CraftingFormulaRow, TArray<FItemAndCount>& OutResults, int32_t& NumToCraft); // 0x101d49e8 (Index: 0x17, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static TArray<UFortWorldItem*> GetIngredientsInCraftingObject(AActor*& CraftingObject); // 0x101d4c94 (Index: 0x18, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void GetKnownCraftingFormulas(AFortPlayerController*& const FortPC, AActor*& const CraftingObject, TArray<FName>& OutFormulas); // 0x101d4fd4 (Index: 0x19, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FName GetLastCraftedItemFormulaName(AActor*& CraftingObject); // 0x101d5460 (Index: 0x1a, Flags: Final|Native|Static|Public|BlueprintCallable)
    static float GetTimeToCraftRecipe(AActor*& const CraftingObject, const FName CraftingFormulaName); // 0x101d559c (Index: 0x1b, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetUIDataForCraftingIngredientTags(UObject*& const WorldContextObject, const FGameplayTagContainer IngredientTags, TArray<TSoftObjectPtr<UItemDefinitionBase*>>& OutItemDefs, TArray<TSoftObjectPtr<UObject*>>& OutIcons); // 0x101d575c (Index: 0x1c, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GetValidIngredientsInInventory(AFortPlayerController*& const FortPC, AActor*& const CraftingObject, TArray<UFortWorldItem*>& OutIngredients); // 0x101d5c0c (Index: 0x1d, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void GiveItemToCraftingObject(AFortPlayerController*& Instigator, AActor*& CraftingObject, const FFortItemEntry ItemEntryToGrant); // 0x101d6214 (Index: 0x1e, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool IsFreeCraftingEnabled(AActor*& const CraftingObject); // 0x101d6d3c (Index: 0x1f, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static bool IsValidIngredient(AFortPlayerController*& const FortPC, AActor*& const CraftingObject, UItemDefinitionBase*& const ItemDef); // 0x101d6e78 (Index: 0x20, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void PauseCrafting(AFortPlayerController*& Instigator, AActor*& CraftingObject, bool& bDecayPausedTime, FCraftingMultiKey& Key); // 0x101d7f40 (Index: 0x21, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void PickupItemAndStartCrafting(AFortPlayerController*& Instigator, AActor*& CraftingObject, AFortPickup*& Pickup, const FName CraftingFormulaName, FCraftingMultiKey& Key); // 0x101d82c8 (Index: 0x22, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void ReportCraftingSuccess(AFortPlayerController*& Instigator, AActor*& CraftingObject, FCraftingMultiKey& Key); // 0x101d8718 (Index: 0x23, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void ResumeCrafting(AFortPlayerController*& Instigator, AActor*& CraftingObject, FCraftingMultiKey& Key); // 0x101d89cc (Index: 0x24, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void StartCrafting(AFortPlayerController*& Instigator, AActor*& CraftingObject, const FName CraftingFormulaName, int32_t& const NumberToCraft, FCraftingMultiKey& Key, float& const OverriddenCraftingLength); // 0x101d9edc (Index: 0x25, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void StartCraftingWithParameters(const FCraftingParameters Parameters); // 0x101da23c (Index: 0x26, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UCraftingLibrary) == 0x28, "Size mismatch for UCraftingLibrary");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FCraftingObjectAdditionalValidationEvent
{
    AFortPlayerController* Instigator; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName FormulaRow; // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCraftingObjectAdditionalValidationEvent) == 0x10, "Size mismatch for FCraftingObjectAdditionalValidationEvent");
static_assert(offsetof(FCraftingObjectAdditionalValidationEvent, Instigator) == 0x0, "Offset mismatch for FCraftingObjectAdditionalValidationEvent::Instigator");
static_assert(offsetof(FCraftingObjectAdditionalValidationEvent, FormulaRow) == 0x8, "Offset mismatch for FCraftingObjectAdditionalValidationEvent::FormulaRow");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FCraftingObjectSuccessEvent
{
    AActor* CraftingObject; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FCraftingMultiKey Key; // 0x8 (Size: 0x8, Type: StructProperty)
    AFortPlayerController* Instigator; // 0x10 (Size: 0x8, Type: ObjectProperty)
    FName FormulaRowName; // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_1c[0x4]; // 0x1c (Size: 0x4, Type: PaddingProperty)
    TArray<FFortItemEntry> ConsumedIngredients; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCraftingObjectSuccessEvent) == 0x30, "Size mismatch for FCraftingObjectSuccessEvent");
static_assert(offsetof(FCraftingObjectSuccessEvent, CraftingObject) == 0x0, "Offset mismatch for FCraftingObjectSuccessEvent::CraftingObject");
static_assert(offsetof(FCraftingObjectSuccessEvent, Key) == 0x8, "Offset mismatch for FCraftingObjectSuccessEvent::Key");
static_assert(offsetof(FCraftingObjectSuccessEvent, Instigator) == 0x10, "Offset mismatch for FCraftingObjectSuccessEvent::Instigator");
static_assert(offsetof(FCraftingObjectSuccessEvent, FormulaRowName) == 0x18, "Offset mismatch for FCraftingObjectSuccessEvent::FormulaRowName");
static_assert(offsetof(FCraftingObjectSuccessEvent, ConsumedIngredients) == 0x20, "Offset mismatch for FCraftingObjectSuccessEvent::ConsumedIngredients");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FCraftingMultiKey
{
    int64_t Key; // 0x0 (Size: 0x8, Type: Int64Property)
};

static_assert(sizeof(FCraftingMultiKey) == 0x8, "Size mismatch for FCraftingMultiKey");
static_assert(offsetof(FCraftingMultiKey, Key) == 0x0, "Offset mismatch for FCraftingMultiKey::Key");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCraftingObjectStateChangedEvent
{
    AActor* CraftingObject; // 0x0 (Size: 0x8, Type: ObjectProperty)
    FCraftingMultiKey Key; // 0x8 (Size: 0x8, Type: StructProperty)
    AFortPlayerController* Instigator; // 0x10 (Size: 0x8, Type: ObjectProperty)
    uint8_t CraftingState; // 0x18 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_19[0x3]; // 0x19 (Size: 0x3, Type: PaddingProperty)
    float CraftingStateStartTime; // 0x1c (Size: 0x4, Type: FloatProperty)
    float CraftingStateDuration; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCraftingObjectStateChangedEvent) == 0x28, "Size mismatch for FCraftingObjectStateChangedEvent");
static_assert(offsetof(FCraftingObjectStateChangedEvent, CraftingObject) == 0x0, "Offset mismatch for FCraftingObjectStateChangedEvent::CraftingObject");
static_assert(offsetof(FCraftingObjectStateChangedEvent, Key) == 0x8, "Offset mismatch for FCraftingObjectStateChangedEvent::Key");
static_assert(offsetof(FCraftingObjectStateChangedEvent, Instigator) == 0x10, "Offset mismatch for FCraftingObjectStateChangedEvent::Instigator");
static_assert(offsetof(FCraftingObjectStateChangedEvent, CraftingState) == 0x18, "Offset mismatch for FCraftingObjectStateChangedEvent::CraftingState");
static_assert(offsetof(FCraftingObjectStateChangedEvent, CraftingStateStartTime) == 0x1c, "Offset mismatch for FCraftingObjectStateChangedEvent::CraftingStateStartTime");
static_assert(offsetof(FCraftingObjectStateChangedEvent, CraftingStateDuration) == 0x20, "Offset mismatch for FCraftingObjectStateChangedEvent::CraftingStateDuration");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCraftingObjectRepStateData
{
    TArray<FCraftingObjectEntryState> CraftingObjectEntryStates; // 0x0 (Size: 0x10, Type: ArrayProperty)
    float CraftingSpeedMultiplier; // 0x10 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCraftingObjectRepStateData) == 0x18, "Size mismatch for FCraftingObjectRepStateData");
static_assert(offsetof(FCraftingObjectRepStateData, CraftingObjectEntryStates) == 0x0, "Offset mismatch for FCraftingObjectRepStateData::CraftingObjectEntryStates");
static_assert(offsetof(FCraftingObjectRepStateData, CraftingSpeedMultiplier) == 0x10, "Offset mismatch for FCraftingObjectRepStateData::CraftingSpeedMultiplier");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FCraftingObjectEntryState
{
    FCraftingMultiKey Key; // 0x0 (Size: 0x8, Type: StructProperty)
    uint8_t CraftingObjectState; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    float StateChangeServerTime; // 0xc (Size: 0x4, Type: FloatProperty)
    float PausedCraftingTime; // 0x10 (Size: 0x4, Type: FloatProperty)
    float OverriddenObjectStateLength; // 0x14 (Size: 0x4, Type: FloatProperty)
    FName CraftingFormulaRow; // 0x18 (Size: 0x4, Type: NameProperty)
    int32_t NumToCraft; // 0x1c (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<AFortPlayerController*> CraftingInstigator; // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    TArray<FCraftingObjectEntryInventory> Inventories; // 0x28 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCraftingObjectEntryState) == 0x38, "Size mismatch for FCraftingObjectEntryState");
static_assert(offsetof(FCraftingObjectEntryState, Key) == 0x0, "Offset mismatch for FCraftingObjectEntryState::Key");
static_assert(offsetof(FCraftingObjectEntryState, CraftingObjectState) == 0x8, "Offset mismatch for FCraftingObjectEntryState::CraftingObjectState");
static_assert(offsetof(FCraftingObjectEntryState, StateChangeServerTime) == 0xc, "Offset mismatch for FCraftingObjectEntryState::StateChangeServerTime");
static_assert(offsetof(FCraftingObjectEntryState, PausedCraftingTime) == 0x10, "Offset mismatch for FCraftingObjectEntryState::PausedCraftingTime");
static_assert(offsetof(FCraftingObjectEntryState, OverriddenObjectStateLength) == 0x14, "Offset mismatch for FCraftingObjectEntryState::OverriddenObjectStateLength");
static_assert(offsetof(FCraftingObjectEntryState, CraftingFormulaRow) == 0x18, "Offset mismatch for FCraftingObjectEntryState::CraftingFormulaRow");
static_assert(offsetof(FCraftingObjectEntryState, NumToCraft) == 0x1c, "Offset mismatch for FCraftingObjectEntryState::NumToCraft");
static_assert(offsetof(FCraftingObjectEntryState, CraftingInstigator) == 0x20, "Offset mismatch for FCraftingObjectEntryState::CraftingInstigator");
static_assert(offsetof(FCraftingObjectEntryState, Inventories) == 0x28, "Offset mismatch for FCraftingObjectEntryState::Inventories");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FCraftingObjectEntryInventory
{
    TWeakObjectPtr<UObject*> Inventory; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(FCraftingObjectEntryInventory) == 0x8, "Size mismatch for FCraftingObjectEntryInventory");
static_assert(offsetof(FCraftingObjectEntryInventory, Inventory) == 0x0, "Offset mismatch for FCraftingObjectEntryInventory::Inventory");

// Size: 0x1b0 (Inherited: 0x0, Single: 0x1b0)
struct FCraftingObjectServerStateData
{
    uint8_t bNextResultsHandledExternally : 1; // 0x0:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bIsNextCraftFree : 1; // 0x0:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bCraftingCompleted : 1; // 0x0:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    AFortPickup* PendingPickupCraftingItem; // 0x8 (Size: 0x8, Type: ObjectProperty)
    FName PendingPickupCraftingFormula; // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_14[0x4]; // 0x14 (Size: 0x4, Type: PaddingProperty)
    FFortItemEntry PendingPickupCraftingItemEntry; // 0x18 (Size: 0x158, Type: StructProperty)
    int32_t PendingPickupHeldCount; // 0x170 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_174[0x4]; // 0x174 (Size: 0x4, Type: PaddingProperty)
    TArray<FFortItemEntry> AllOfTheIngredientItems; // 0x178 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> NonConsumedIngredientItemIndices; // 0x188 (Size: 0x10, Type: ArrayProperty)
    TArray<FItemAndCount> CraftingResults; // 0x198 (Size: 0x10, Type: ArrayProperty)
    FGameplayAbilitySpecHandle InstigatorWhileCraftingAbilitySpecHandle; // 0x1a8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_1ac[0x4]; // 0x1ac (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCraftingObjectServerStateData) == 0x1b0, "Size mismatch for FCraftingObjectServerStateData");
static_assert(offsetof(FCraftingObjectServerStateData, bNextResultsHandledExternally) == 0x0, "Offset mismatch for FCraftingObjectServerStateData::bNextResultsHandledExternally");
static_assert(offsetof(FCraftingObjectServerStateData, bIsNextCraftFree) == 0x0, "Offset mismatch for FCraftingObjectServerStateData::bIsNextCraftFree");
static_assert(offsetof(FCraftingObjectServerStateData, bCraftingCompleted) == 0x0, "Offset mismatch for FCraftingObjectServerStateData::bCraftingCompleted");
static_assert(offsetof(FCraftingObjectServerStateData, PendingPickupCraftingItem) == 0x8, "Offset mismatch for FCraftingObjectServerStateData::PendingPickupCraftingItem");
static_assert(offsetof(FCraftingObjectServerStateData, PendingPickupCraftingFormula) == 0x10, "Offset mismatch for FCraftingObjectServerStateData::PendingPickupCraftingFormula");
static_assert(offsetof(FCraftingObjectServerStateData, PendingPickupCraftingItemEntry) == 0x18, "Offset mismatch for FCraftingObjectServerStateData::PendingPickupCraftingItemEntry");
static_assert(offsetof(FCraftingObjectServerStateData, PendingPickupHeldCount) == 0x170, "Offset mismatch for FCraftingObjectServerStateData::PendingPickupHeldCount");
static_assert(offsetof(FCraftingObjectServerStateData, AllOfTheIngredientItems) == 0x178, "Offset mismatch for FCraftingObjectServerStateData::AllOfTheIngredientItems");
static_assert(offsetof(FCraftingObjectServerStateData, NonConsumedIngredientItemIndices) == 0x188, "Offset mismatch for FCraftingObjectServerStateData::NonConsumedIngredientItemIndices");
static_assert(offsetof(FCraftingObjectServerStateData, CraftingResults) == 0x198, "Offset mismatch for FCraftingObjectServerStateData::CraftingResults");
static_assert(offsetof(FCraftingObjectServerStateData, InstigatorWhileCraftingAbilitySpecHandle) == 0x1a8, "Offset mismatch for FCraftingObjectServerStateData::InstigatorWhileCraftingAbilitySpecHandle");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FCraftingEvent_OpenCraftingMenu
{
    AActor* CraftingObject; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCraftingEvent_OpenCraftingMenu) == 0x8, "Size mismatch for FCraftingEvent_OpenCraftingMenu");
static_assert(offsetof(FCraftingEvent_OpenCraftingMenu, CraftingObject) == 0x0, "Offset mismatch for FCraftingEvent_OpenCraftingMenu::CraftingObject");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FCraftingIngredientRequirement
{
    FGameplayTagContainer IngredientTags; // 0x0 (Size: 0x20, Type: StructProperty)
    int32_t Count; // 0x20 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCraftingIngredientRequirement) == 0x28, "Size mismatch for FCraftingIngredientRequirement");
static_assert(offsetof(FCraftingIngredientRequirement, IngredientTags) == 0x0, "Offset mismatch for FCraftingIngredientRequirement::IngredientTags");
static_assert(offsetof(FCraftingIngredientRequirement, Count) == 0x20, "Offset mismatch for FCraftingIngredientRequirement::Count");

// Size: 0x118 (Inherited: 0x0, Single: 0x118)
struct FCraftingUpgradeRule
{
    FGameplayTagRequirements SourceItemTags; // 0x0 (Size: 0x88, Type: StructProperty)
    FGameplayTagRequirements TargetItemTags; // 0x88 (Size: 0x88, Type: StructProperty)
    char UpgradeFlags; // 0x110 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_111[0x7]; // 0x111 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FCraftingUpgradeRule) == 0x118, "Size mismatch for FCraftingUpgradeRule");
static_assert(offsetof(FCraftingUpgradeRule, SourceItemTags) == 0x0, "Offset mismatch for FCraftingUpgradeRule::SourceItemTags");
static_assert(offsetof(FCraftingUpgradeRule, TargetItemTags) == 0x88, "Offset mismatch for FCraftingUpgradeRule::TargetItemTags");
static_assert(offsetof(FCraftingUpgradeRule, UpgradeFlags) == 0x110, "Offset mismatch for FCraftingUpgradeRule::UpgradeFlags");

// Size: 0xe0 (Inherited: 0x18, Single: 0xc8)
struct FCraftingFormula : FItemShopTableRowBase
{
    FText DisplayName; // 0x10 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UObject*> PreviewImage; // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t bEnabled : 1; // 0x40:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bAlwaysKnownFormula : 1; // 0x40:1 (Size: 0x1, Type: BoolProperty)
    uint8_t bInstantlyConsumeIngredients : 1; // 0x40:2 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_41[0x3]; // 0x41 (Size: 0x3, Type: PaddingProperty)
    int32_t SortingPriority; // 0x44 (Size: 0x4, Type: IntProperty)
    FGameplayTag SourceObjectTag; // 0x48 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_4c[0x4]; // 0x4c (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer AttributeTags; // 0x50 (Size: 0x20, Type: StructProperty)
    TArray<FCraftingIngredientRequirement> RequiredIngredients; // 0x70 (Size: 0x10, Type: ArrayProperty)
    FName ResultLootTierKey; // 0x80 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_84[0x4]; // 0x84 (Size: 0x4, Type: PaddingProperty)
    TSoftClassPtr WhileCraftingAbility; // 0x88 (Size: 0x20, Type: SoftClassProperty)
    TArray<FCraftingUpgradeRule> UpgradeRules; // 0xa8 (Size: 0x10, Type: ArrayProperty)
    float OverrideCraftingTime; // 0xb8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_bc[0x4]; // 0xbc (Size: 0x4, Type: PaddingProperty)
    TSoftClassPtr InstigatorWhileCraftingAbility; // 0xc0 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FCraftingFormula) == 0xe0, "Size mismatch for FCraftingFormula");
static_assert(offsetof(FCraftingFormula, DisplayName) == 0x10, "Offset mismatch for FCraftingFormula::DisplayName");
static_assert(offsetof(FCraftingFormula, PreviewImage) == 0x20, "Offset mismatch for FCraftingFormula::PreviewImage");
static_assert(offsetof(FCraftingFormula, bEnabled) == 0x40, "Offset mismatch for FCraftingFormula::bEnabled");
static_assert(offsetof(FCraftingFormula, bAlwaysKnownFormula) == 0x40, "Offset mismatch for FCraftingFormula::bAlwaysKnownFormula");
static_assert(offsetof(FCraftingFormula, bInstantlyConsumeIngredients) == 0x40, "Offset mismatch for FCraftingFormula::bInstantlyConsumeIngredients");
static_assert(offsetof(FCraftingFormula, SortingPriority) == 0x44, "Offset mismatch for FCraftingFormula::SortingPriority");
static_assert(offsetof(FCraftingFormula, SourceObjectTag) == 0x48, "Offset mismatch for FCraftingFormula::SourceObjectTag");
static_assert(offsetof(FCraftingFormula, AttributeTags) == 0x50, "Offset mismatch for FCraftingFormula::AttributeTags");
static_assert(offsetof(FCraftingFormula, RequiredIngredients) == 0x70, "Offset mismatch for FCraftingFormula::RequiredIngredients");
static_assert(offsetof(FCraftingFormula, ResultLootTierKey) == 0x80, "Offset mismatch for FCraftingFormula::ResultLootTierKey");
static_assert(offsetof(FCraftingFormula, WhileCraftingAbility) == 0x88, "Offset mismatch for FCraftingFormula::WhileCraftingAbility");
static_assert(offsetof(FCraftingFormula, UpgradeRules) == 0xa8, "Offset mismatch for FCraftingFormula::UpgradeRules");
static_assert(offsetof(FCraftingFormula, OverrideCraftingTime) == 0xb8, "Offset mismatch for FCraftingFormula::OverrideCraftingTime");
static_assert(offsetof(FCraftingFormula, InstigatorWhileCraftingAbility) == 0xc0, "Offset mismatch for FCraftingFormula::InstigatorWhileCraftingAbility");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FCraftingResult
{
    FName ResultLootTierKey; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FItemAndCount> Results; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCraftingResult) == 0x18, "Size mismatch for FCraftingResult");
static_assert(offsetof(FCraftingResult, ResultLootTierKey) == 0x0, "Offset mismatch for FCraftingResult::ResultLootTierKey");
static_assert(offsetof(FCraftingResult, Results) == 0x8, "Offset mismatch for FCraftingResult::Results");

// Size: 0x50 (Inherited: 0x18, Single: 0x38)
struct FCraftingIngredientUIData : FItemShopTableRowBase
{
    FGameplayTagContainer IngredientTags; // 0x10 (Size: 0x20, Type: StructProperty)
    TArray<TSoftObjectPtr<UItemDefinitionBase*>> ItemDefs; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<TSoftObjectPtr<UObject*>> Icons; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FCraftingIngredientUIData) == 0x50, "Size mismatch for FCraftingIngredientUIData");
static_assert(offsetof(FCraftingIngredientUIData, IngredientTags) == 0x10, "Offset mismatch for FCraftingIngredientUIData::IngredientTags");
static_assert(offsetof(FCraftingIngredientUIData, ItemDefs) == 0x30, "Offset mismatch for FCraftingIngredientUIData::ItemDefs");
static_assert(offsetof(FCraftingIngredientUIData, Icons) == 0x40, "Offset mismatch for FCraftingIngredientUIData::Icons");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FCraftingIngredientQueryState
{
    FCraftingIngredientRequirement Requirement; // 0x0 (Size: 0x28, Type: StructProperty)
    int32_t Owned; // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t Missing; // 0x2c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FCraftingIngredientQueryState) == 0x30, "Size mismatch for FCraftingIngredientQueryState");
static_assert(offsetof(FCraftingIngredientQueryState, Requirement) == 0x0, "Offset mismatch for FCraftingIngredientQueryState::Requirement");
static_assert(offsetof(FCraftingIngredientQueryState, Owned) == 0x28, "Offset mismatch for FCraftingIngredientQueryState::Owned");
static_assert(offsetof(FCraftingIngredientQueryState, Missing) == 0x2c, "Offset mismatch for FCraftingIngredientQueryState::Missing");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FCraftingTagsChangedMessage
{
    AActor* CraftingObject; // 0x0 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(FCraftingTagsChangedMessage) == 0x8, "Size mismatch for FCraftingTagsChangedMessage");
static_assert(offsetof(FCraftingTagsChangedMessage, CraftingObject) == 0x0, "Offset mismatch for FCraftingTagsChangedMessage::CraftingObject");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FCraftingParameters
{
    AFortPlayerController* Instigator; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* CraftingObject; // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<TScriptInterface<Class>> Inventories; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FName FormulaRow; // 0x20 (Size: 0x4, Type: NameProperty)
    int32_t NumberToCraft; // 0x24 (Size: 0x4, Type: IntProperty)
    FCraftingMultiKey Key; // 0x28 (Size: 0x8, Type: StructProperty)
    float OverriddenObjectStateLength; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FCraftingParameters) == 0x38, "Size mismatch for FCraftingParameters");
static_assert(offsetof(FCraftingParameters, Instigator) == 0x0, "Offset mismatch for FCraftingParameters::Instigator");
static_assert(offsetof(FCraftingParameters, CraftingObject) == 0x8, "Offset mismatch for FCraftingParameters::CraftingObject");
static_assert(offsetof(FCraftingParameters, Inventories) == 0x10, "Offset mismatch for FCraftingParameters::Inventories");
static_assert(offsetof(FCraftingParameters, FormulaRow) == 0x20, "Offset mismatch for FCraftingParameters::FormulaRow");
static_assert(offsetof(FCraftingParameters, NumberToCraft) == 0x24, "Offset mismatch for FCraftingParameters::NumberToCraft");
static_assert(offsetof(FCraftingParameters, Key) == 0x28, "Offset mismatch for FCraftingParameters::Key");
static_assert(offsetof(FCraftingParameters, OverriddenObjectStateLength) == 0x30, "Offset mismatch for FCraftingParameters::OverriddenObjectStateLength");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FCraftingQueryParameters
{
    AFortPlayerController* Instigator; // 0x0 (Size: 0x8, Type: ObjectProperty)
    AActor* CraftingObject; // 0x8 (Size: 0x8, Type: ObjectProperty)
    TArray<TScriptInterface<Class>> Inventories; // 0x10 (Size: 0x10, Type: ArrayProperty)
    FName FormulaRow; // 0x20 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
    TArray<FItemAndCount> AdditionalItems; // 0x28 (Size: 0x10, Type: ArrayProperty)
    int32_t NumberToCraft; // 0x38 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    FGameplayTagContainer InventoryGroups; // 0x40 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FCraftingQueryParameters) == 0x60, "Size mismatch for FCraftingQueryParameters");
static_assert(offsetof(FCraftingQueryParameters, Instigator) == 0x0, "Offset mismatch for FCraftingQueryParameters::Instigator");
static_assert(offsetof(FCraftingQueryParameters, CraftingObject) == 0x8, "Offset mismatch for FCraftingQueryParameters::CraftingObject");
static_assert(offsetof(FCraftingQueryParameters, Inventories) == 0x10, "Offset mismatch for FCraftingQueryParameters::Inventories");
static_assert(offsetof(FCraftingQueryParameters, FormulaRow) == 0x20, "Offset mismatch for FCraftingQueryParameters::FormulaRow");
static_assert(offsetof(FCraftingQueryParameters, AdditionalItems) == 0x28, "Offset mismatch for FCraftingQueryParameters::AdditionalItems");
static_assert(offsetof(FCraftingQueryParameters, NumberToCraft) == 0x38, "Offset mismatch for FCraftingQueryParameters::NumberToCraft");
static_assert(offsetof(FCraftingQueryParameters, InventoryGroups) == 0x40, "Offset mismatch for FCraftingQueryParameters::InventoryGroups");

