/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ContextualAnimation
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"
#include "MotionWarping.h"

// Size: 0x38 (Inherited: 0x58, Single: 0xffffffe0)
class UAnimNotifyState_EarlyOutContextualAnimWindow : public UAnimNotifyState
{
public:
    bool bStopEveryone; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UAnimNotifyState_EarlyOutContextualAnimWindow) == 0x38, "Size mismatch for UAnimNotifyState_EarlyOutContextualAnimWindow");
static_assert(offsetof(UAnimNotifyState_EarlyOutContextualAnimWindow, bStopEveryone) == 0x30, "Offset mismatch for UAnimNotifyState_EarlyOutContextualAnimWindow::bStopEveryone");

// Size: 0xa0 (Inherited: 0x58, Single: 0x48)
class UAnimNotifyState_IKWindow : public UAnimNotifyState
{
public:
    FName GoalName; // 0x30 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
    FAlphaBlend BlendIn; // 0x38 (Size: 0x30, Type: StructProperty)
    FAlphaBlend BlendOut; // 0x68 (Size: 0x30, Type: StructProperty)
    bool bEnable; // 0x98 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_99[0x7]; // 0x99 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UAnimNotifyState_IKWindow) == 0xa0, "Size mismatch for UAnimNotifyState_IKWindow");
static_assert(offsetof(UAnimNotifyState_IKWindow, GoalName) == 0x30, "Offset mismatch for UAnimNotifyState_IKWindow::GoalName");
static_assert(offsetof(UAnimNotifyState_IKWindow, BlendIn) == 0x38, "Offset mismatch for UAnimNotifyState_IKWindow::BlendIn");
static_assert(offsetof(UAnimNotifyState_IKWindow, BlendOut) == 0x68, "Offset mismatch for UAnimNotifyState_IKWindow::BlendOut");
static_assert(offsetof(UAnimNotifyState_IKWindow, bEnable) == 0x98, "Offset mismatch for UAnimNotifyState_IKWindow::bEnable");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UContextualAnimActorInterface : public UInterface
{
public:

public:
    virtual USkeletalMeshComponent* GetMesh() const; // 0xc93b220 (Index: 0x0, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
};

static_assert(sizeof(UContextualAnimActorInterface) == 0x28, "Size mismatch for UContextualAnimActorInterface");

// Size: 0x410 (Inherited: 0x320, Single: 0xf0)
class UContextualAnimSceneActorComponent : public USceneComponent
{
public:
    uint8_t Pad_240[0x8]; // 0x240 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnJoinedSceneDelegate[0x10]; // 0x248 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnLeftSceneDelegate[0x10]; // 0x258 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnPlayMontageNotifyBeginDelegate[0x10]; // 0x268 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnMontageBlendingOutDelegate[0x10]; // 0x278 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UContextualAnimSceneAsset* SceneAsset; // 0x288 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<UAnimInstance*> OwnerAnimInstance; // 0x290 (Size: 0x8, Type: WeakObjectProperty)
    FContextualAnimRepBindingsData RepBindings; // 0x298 (Size: 0x50, Type: StructProperty)
    FContextualAnimRepLateJoinData RepLateJoinData; // 0x2e8 (Size: 0x30, Type: StructProperty)
    FContextualAnimRepTransitionData RepTransitionData; // 0x318 (Size: 0x28, Type: StructProperty)
    FContextualAnimRepTransitionData RepTransitionSingleActorData; // 0x340 (Size: 0x28, Type: StructProperty)
    FContextualAnimSceneBindings Bindings; // 0x368 (Size: 0x28, Type: StructProperty)
    TArray<FContextualAnimIKTarget> IKTargets; // 0x390 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> WarpTargetNamesCache; // 0x3a0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_3b0[0x60]; // 0x3b0 (Size: 0x60, Type: PaddingProperty)

public:
    void EarlyOutContextualAnimScene(bool& bStopEveryone); // 0xc93a750 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    FContextualAnimSceneBindings GetBindings() const; // 0xc93b01c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FContextualAnimIKTarget GetIKTargetByGoalName(FName& GoalName) const; // 0xc93b038 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<FContextualAnimIKTarget> GetIKTargets() const; // 0xc93b204 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsInActiveScene() const; // 0xc93b2d0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool LateJoinContextualAnimScene(AActor*& Actor, FName& Role); // 0xc93b328 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void OnIgnoredActorEndPlay(AActor*& Actor, TEnumAsByte<EEndPlayReason>& EndPlayReason); // 0xc93b700 (Index: 0x6, Flags: Final|Native|Public)
    void OnJoinedScene(const FContextualAnimSceneBindings InBindings); // 0xc93b90c (Index: 0x7, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    void OnLeftScene(); // 0x554e3c4 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable)
    bool StartContextualAnimScene(const FContextualAnimSceneBindings InBindings); // 0xc93c67c (Index: 0x12, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool TransitionContextualAnimScene(FName& SectionName); // 0xc93c778 (Index: 0x13, Flags: Final|Native|Public|BlueprintCallable)
    bool TransitionContextualAnimSceneToSpecificSet(FName& SectionName, int32_t& AnimSetIdx); // 0xc93ca88 (Index: 0x14, Flags: Final|Native|Public|BlueprintCallable)
    bool TransitionSingleActor(int32_t& SectionIdx, int32_t& AnimSetIdx); // 0xc93cca0 (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnMontageBlendingOut(UAnimMontage*& Montage, bool& bInterrupted); // 0xc93b9d8 (Index: 0x9, Flags: Final|Native|Protected)
    void OnPlayMontageNotifyBegin(FName& NotifyName, const FBranchingPointNotifyPayload BranchingPointNotifyPayload); // 0xc93bbe4 (Index: 0xa, Flags: Final|Native|Protected|HasOutParms)
    void OnRep_Bindings(); // 0xc93bdac (Index: 0xb, Flags: Final|Native|Protected)
    void OnRep_LateJoinData(); // 0xc93bdc0 (Index: 0xc, Flags: Final|Native|Protected)
    void OnRep_RepTransitionSingleActor(); // 0xc93bdd4 (Index: 0xd, Flags: Final|Native|Protected)
    void OnRep_TransitionData(); // 0xc93bde8 (Index: 0xe, Flags: Final|Native|Protected)
    void OnTickPose(USkinnedMeshComponent*& SkinnedMeshComponent, float& DeltaTime, bool& bNeedsValidRootMotion); // 0xc93bdfc (Index: 0xf, Flags: Native|Protected)
    virtual void ServerEarlyOutContextualAnimScene(bool& bStopEveryone); // 0xc93c41c (Index: 0x10, Flags: Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
    virtual void ServerStartContextualAnimScene(FContextualAnimSceneBindings& const InBindings); // 0xc93c570 (Index: 0x11, Flags: Net|NetReliableNative|Event|Protected|NetServer|NetValidate)
};

static_assert(sizeof(UContextualAnimSceneActorComponent) == 0x410, "Size mismatch for UContextualAnimSceneActorComponent");
static_assert(offsetof(UContextualAnimSceneActorComponent, OnJoinedSceneDelegate) == 0x248, "Offset mismatch for UContextualAnimSceneActorComponent::OnJoinedSceneDelegate");
static_assert(offsetof(UContextualAnimSceneActorComponent, OnLeftSceneDelegate) == 0x258, "Offset mismatch for UContextualAnimSceneActorComponent::OnLeftSceneDelegate");
static_assert(offsetof(UContextualAnimSceneActorComponent, OnPlayMontageNotifyBeginDelegate) == 0x268, "Offset mismatch for UContextualAnimSceneActorComponent::OnPlayMontageNotifyBeginDelegate");
static_assert(offsetof(UContextualAnimSceneActorComponent, OnMontageBlendingOutDelegate) == 0x278, "Offset mismatch for UContextualAnimSceneActorComponent::OnMontageBlendingOutDelegate");
static_assert(offsetof(UContextualAnimSceneActorComponent, SceneAsset) == 0x288, "Offset mismatch for UContextualAnimSceneActorComponent::SceneAsset");
static_assert(offsetof(UContextualAnimSceneActorComponent, OwnerAnimInstance) == 0x290, "Offset mismatch for UContextualAnimSceneActorComponent::OwnerAnimInstance");
static_assert(offsetof(UContextualAnimSceneActorComponent, RepBindings) == 0x298, "Offset mismatch for UContextualAnimSceneActorComponent::RepBindings");
static_assert(offsetof(UContextualAnimSceneActorComponent, RepLateJoinData) == 0x2e8, "Offset mismatch for UContextualAnimSceneActorComponent::RepLateJoinData");
static_assert(offsetof(UContextualAnimSceneActorComponent, RepTransitionData) == 0x318, "Offset mismatch for UContextualAnimSceneActorComponent::RepTransitionData");
static_assert(offsetof(UContextualAnimSceneActorComponent, RepTransitionSingleActorData) == 0x340, "Offset mismatch for UContextualAnimSceneActorComponent::RepTransitionSingleActorData");
static_assert(offsetof(UContextualAnimSceneActorComponent, Bindings) == 0x368, "Offset mismatch for UContextualAnimSceneActorComponent::Bindings");
static_assert(offsetof(UContextualAnimSceneActorComponent, IKTargets) == 0x390, "Offset mismatch for UContextualAnimSceneActorComponent::IKTargets");
static_assert(offsetof(UContextualAnimSceneActorComponent, WarpTargetNamesCache) == 0x3a0, "Offset mismatch for UContextualAnimSceneActorComponent::WarpTargetNamesCache");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UContextualAnimRolesAsset : public UDataAsset
{
public:
    TArray<FContextualAnimRoleDefinition> Roles; // 0x30 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UContextualAnimRolesAsset) == 0x40, "Size mismatch for UContextualAnimRolesAsset");
static_assert(offsetof(UContextualAnimRolesAsset, Roles) == 0x30, "Offset mismatch for UContextualAnimRolesAsset::Roles");

// Size: 0x98 (Inherited: 0x58, Single: 0x40)
class UContextualAnimSceneAsset : public UDataAsset
{
public:
    UContextualAnimRolesAsset* RolesAsset; // 0x30 (Size: 0x8, Type: ObjectProperty)
    FName PrimaryRole; // 0x38 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
    TArray<FContextualAnimSceneSection> Sections; // 0x40 (Size: 0x10, Type: ArrayProperty)
    float Radius; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t CollisionBehavior; // 0x54 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_55[0x3]; // 0x55 (Size: 0x3, Type: PaddingProperty)
    TArray<FContextualAnimIgnoreChannelsParam> CollisionChannelsToIgnoreParams; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FContextualAnimAttachmentParams> AttachmentParams; // 0x68 (Size: 0x10, Type: ArrayProperty)
    FContextualAnimIKTargetParams IKTargetParams; // 0x78 (Size: 0x18, Type: StructProperty)
    bool bIgnoreClientMovementErrorChecksAndCorrection; // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bDisableMovementReplicationForSimulatedProxy; // 0x91 (Size: 0x1, Type: BoolProperty)
    bool bPrecomputeAlignmentTracks; // 0x92 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_93[0x1]; // 0x93 (Size: 0x1, Type: PaddingProperty)
    int32_t SampleRate; // 0x94 (Size: 0x4, Type: IntProperty)

public:
    UAnimSequenceBase* BP_FindAnimationForRole(int32_t& SectionIdx, int32_t& AnimSetIdx, FName& Role) const; // 0xc935f60 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t BP_FindAnimSetIndexByAnimation(int32_t& SectionIdx, UAnimSequenceBase*& const Animation) const; // 0xc935cf0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FTransform BP_GetAlignmentTransformForRoleRelativeToWarpPoint(int32_t& SectionIdx, int32_t& AnimSetIdx, FName& Role, float& time) const; // 0xc9363f8 (Index: 0x2, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    FTransform BP_GetIKTargetTransformForRoleAtTime(int32_t& SectionIdx, int32_t& AnimSetIdx, FName& Role, FName& TrackName, float& time) const; // 0xc936814 (Index: 0x3, Flags: Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const)
    void BP_GetStartAndEndTimeForWarpSection(int32_t& SectionIdx, int32_t& AnimSetIdx, FName& Role, FName& WarpSectionName, float& OutStartTime, float& OutEndTime) const; // 0xc936cb0 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetAlignmentPointsForSecondaryRole(EContextualAnimPointType& Type, int32_t& SectionIdx, const FContextualAnimSceneBindingContext Primary, TArray<FContextualAnimPoint>& OutResult) const; // 0xc93a87c (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    void GetAlignmentPointsForSecondaryRoleConsideringSelectionCriteria(EContextualAnimPointType& Type, int32_t& SectionIdx, const FContextualAnimSceneBindingContext Primary, const FContextualAnimSceneBindingContext Querier, EContextualAnimCriterionToConsider& CriterionToConsider, TArray<FContextualAnimPoint>& OutResult) const; // 0xc93abec (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    TArray<FName> GetRoles() const; // 0xc93b248 (Index: 0x7, Flags: Final|Native|Public|Const)
    bool Query(FName& Role, FContextualAnimQueryResult& OutResult, const FContextualAnimQueryParams QueryParams, const FTransform ToWorldTransform) const; // 0xc93c0d8 (Index: 0x8, Flags: Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UContextualAnimSceneAsset) == 0x98, "Size mismatch for UContextualAnimSceneAsset");
static_assert(offsetof(UContextualAnimSceneAsset, RolesAsset) == 0x30, "Offset mismatch for UContextualAnimSceneAsset::RolesAsset");
static_assert(offsetof(UContextualAnimSceneAsset, PrimaryRole) == 0x38, "Offset mismatch for UContextualAnimSceneAsset::PrimaryRole");
static_assert(offsetof(UContextualAnimSceneAsset, Sections) == 0x40, "Offset mismatch for UContextualAnimSceneAsset::Sections");
static_assert(offsetof(UContextualAnimSceneAsset, Radius) == 0x50, "Offset mismatch for UContextualAnimSceneAsset::Radius");
static_assert(offsetof(UContextualAnimSceneAsset, CollisionBehavior) == 0x54, "Offset mismatch for UContextualAnimSceneAsset::CollisionBehavior");
static_assert(offsetof(UContextualAnimSceneAsset, CollisionChannelsToIgnoreParams) == 0x58, "Offset mismatch for UContextualAnimSceneAsset::CollisionChannelsToIgnoreParams");
static_assert(offsetof(UContextualAnimSceneAsset, AttachmentParams) == 0x68, "Offset mismatch for UContextualAnimSceneAsset::AttachmentParams");
static_assert(offsetof(UContextualAnimSceneAsset, IKTargetParams) == 0x78, "Offset mismatch for UContextualAnimSceneAsset::IKTargetParams");
static_assert(offsetof(UContextualAnimSceneAsset, bIgnoreClientMovementErrorChecksAndCorrection) == 0x90, "Offset mismatch for UContextualAnimSceneAsset::bIgnoreClientMovementErrorChecksAndCorrection");
static_assert(offsetof(UContextualAnimSceneAsset, bDisableMovementReplicationForSimulatedProxy) == 0x91, "Offset mismatch for UContextualAnimSceneAsset::bDisableMovementReplicationForSimulatedProxy");
static_assert(offsetof(UContextualAnimSceneAsset, bPrecomputeAlignmentTracks) == 0x92, "Offset mismatch for UContextualAnimSceneAsset::bPrecomputeAlignmentTracks");
static_assert(offsetof(UContextualAnimSceneAsset, SampleRate) == 0x94, "Offset mismatch for UContextualAnimSceneAsset::SampleRate");

// Size: 0x30 (Inherited: 0x28, Single: 0x8)
class UContextualAnimSelectionCriterion : public UObject
{
public:
    uint8_t Type; // 0x28 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UContextualAnimSelectionCriterion) == 0x30, "Size mismatch for UContextualAnimSelectionCriterion");
static_assert(offsetof(UContextualAnimSelectionCriterion, Type) == 0x28, "Offset mismatch for UContextualAnimSelectionCriterion::Type");

// Size: 0x30 (Inherited: 0x58, Single: 0xffffffd8)
class UContextualAnimSelectionCriterion_Blueprint : public UContextualAnimSelectionCriterion
{
public:

public:
    virtual bool BP_DoesQuerierPassCondition(const FContextualAnimSceneBindingContext Primary, const FContextualAnimSceneBindingContext Querier) const; // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent|Const)
    UContextualAnimSceneAsset* GetSceneAsset() const; // 0xc93b288 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UContextualAnimSelectionCriterion_Blueprint) == 0x30, "Size mismatch for UContextualAnimSelectionCriterion_Blueprint");

// Size: 0x48 (Inherited: 0x58, Single: 0xfffffff0)
class UContextualAnimSelectionCriterion_TriggerArea : public UContextualAnimSelectionCriterion
{
public:
    TArray<FVector> PolygonPoints; // 0x30 (Size: 0x10, Type: ArrayProperty)
    float Height; // 0x40 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_44[0x4]; // 0x44 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UContextualAnimSelectionCriterion_TriggerArea) == 0x48, "Size mismatch for UContextualAnimSelectionCriterion_TriggerArea");
static_assert(offsetof(UContextualAnimSelectionCriterion_TriggerArea, PolygonPoints) == 0x30, "Offset mismatch for UContextualAnimSelectionCriterion_TriggerArea::PolygonPoints");
static_assert(offsetof(UContextualAnimSelectionCriterion_TriggerArea, Height) == 0x40, "Offset mismatch for UContextualAnimSelectionCriterion_TriggerArea::Height");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UContextualAnimSelectionCriterion_Cone : public UContextualAnimSelectionCriterion
{
public:
    uint8_t Mode; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x3]; // 0x31 (Size: 0x3, Type: PaddingProperty)
    float Distance; // 0x34 (Size: 0x4, Type: FloatProperty)
    float HalfAngle; // 0x38 (Size: 0x4, Type: FloatProperty)
    float Offset; // 0x3c (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(UContextualAnimSelectionCriterion_Cone) == 0x40, "Size mismatch for UContextualAnimSelectionCriterion_Cone");
static_assert(offsetof(UContextualAnimSelectionCriterion_Cone, Mode) == 0x30, "Offset mismatch for UContextualAnimSelectionCriterion_Cone::Mode");
static_assert(offsetof(UContextualAnimSelectionCriterion_Cone, Distance) == 0x34, "Offset mismatch for UContextualAnimSelectionCriterion_Cone::Distance");
static_assert(offsetof(UContextualAnimSelectionCriterion_Cone, HalfAngle) == 0x38, "Offset mismatch for UContextualAnimSelectionCriterion_Cone::HalfAngle");
static_assert(offsetof(UContextualAnimSelectionCriterion_Cone, Offset) == 0x3c, "Offset mismatch for UContextualAnimSelectionCriterion_Cone::Offset");

// Size: 0x40 (Inherited: 0x58, Single: 0xffffffe8)
class UContextualAnimSelectionCriterion_Distance : public UContextualAnimSelectionCriterion
{
public:
    uint8_t Mode; // 0x30 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_31[0x3]; // 0x31 (Size: 0x3, Type: PaddingProperty)
    float MinDistance; // 0x34 (Size: 0x4, Type: FloatProperty)
    float MaxDistance; // 0x38 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_3c[0x4]; // 0x3c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UContextualAnimSelectionCriterion_Distance) == 0x40, "Size mismatch for UContextualAnimSelectionCriterion_Distance");
static_assert(offsetof(UContextualAnimSelectionCriterion_Distance, Mode) == 0x30, "Offset mismatch for UContextualAnimSelectionCriterion_Distance::Mode");
static_assert(offsetof(UContextualAnimSelectionCriterion_Distance, MinDistance) == 0x34, "Offset mismatch for UContextualAnimSelectionCriterion_Distance::MinDistance");
static_assert(offsetof(UContextualAnimSelectionCriterion_Distance, MaxDistance) == 0x38, "Offset mismatch for UContextualAnimSelectionCriterion_Distance::MaxDistance");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UContextualAnimUtilities : public UBlueprintFunctionLibrary
{
public:

public:
    static bool BP_CreateContextualAnimSceneBindings(UContextualAnimSceneAsset*& const SceneAsset, const TMap<FContextualAnimSceneBindingContext, FName> Params, FContextualAnimSceneBindings& OutBindings); // 0xc9352c4 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static bool BP_CreateContextualAnimSceneBindingsForTwoActors(UContextualAnimSceneAsset*& const SceneAsset, const FContextualAnimSceneBindingContext Primary, const FContextualAnimSceneBindingContext Secondary, FContextualAnimSceneBindings& OutBindings); // 0xc935570 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void BP_DrawDebugPose(UObject*& const WorldContextObject, UAnimSequenceBase*& const Animation, float& time, FTransform& LocalToWorldTransform, FLinearColor& Color, float& Lifetime, float& Thickness); // 0xc935848 (Index: 0x2, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable)
    static float BP_Montage_GetSectionLength(UAnimMontage*& const Montage, int32_t& SectionIndex); // 0xc9370e8 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void BP_Montage_GetSectionStartAndEndTime(UAnimMontage*& const Montage, int32_t& SectionIndex, float& OutStartTime, float& OutEndTime); // 0xc937300 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static float BP_Montage_GetSectionTimeLeftFromPos(UAnimMontage*& const Montage, float& Position); // 0xc93761c (Index: 0x5, Flags: Final|Native|Static|Public|BlueprintCallable)
    static AActor* BP_SceneBinding_GetActor(const FContextualAnimSceneBinding Binding); // 0xc938bb4 (Index: 0x6, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UAnimSequenceBase* BP_SceneBinding_GetAnimationFromBinding(const FContextualAnimSceneBindings Bindings, const FContextualAnimSceneBinding Binding); // 0xc938d54 (Index: 0x7, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FName BP_SceneBinding_GetRoleFromBinding(const FContextualAnimSceneBindings Bindings, const FContextualAnimSceneBinding Binding); // 0xc938f0c (Index: 0x8, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static USkeletalMeshComponent* BP_SceneBinding_GetSkeletalMesh(const FContextualAnimSceneBinding Binding); // 0xc9390cc (Index: 0x9, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static AActor* BP_SceneBindingContext_GetActor(const FContextualAnimSceneBindingContext BindingContext); // 0xc937838 (Index: 0xa, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void BP_SceneBindingContext_GetCurrentSectionAndAnimSetNames(const FContextualAnimSceneBindingContext BindingContext, FName& SectionName, FName& AnimSetName); // 0xc9379d8 (Index: 0xb, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FGameplayTagContainer BP_SceneBindingContext_GetGameplayTags(const FContextualAnimSceneBindingContext BindingContext); // 0xc937bf0 (Index: 0xc, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FTransform BP_SceneBindingContext_GetTransform(const FContextualAnimSceneBindingContext BindingContext); // 0xc937d00 (Index: 0xd, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector BP_SceneBindingContext_GetVelocity(const FContextualAnimSceneBindingContext BindingContext); // 0xc937e34 (Index: 0xe, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static bool BP_SceneBindingContext_HasAllMatchingGameplayTags(const FContextualAnimSceneBindingContext BindingContext, const FGameplayTagContainer TagContainer); // 0xc938020 (Index: 0xf, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool BP_SceneBindingContext_HasAnyMatchingGameplayTags(const FContextualAnimSceneBindingContext BindingContext, const FGameplayTagContainer TagContainer); // 0xc9382ec (Index: 0x10, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static bool BP_SceneBindingContext_HasMatchingGameplayTag(const FContextualAnimSceneBindingContext BindingContext, const FGameplayTag TagToCheck); // 0xc9385b8 (Index: 0x11, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FContextualAnimSceneBindingContext BP_SceneBindingContext_MakeFromActor(AActor*& Actor); // 0xc9387c0 (Index: 0x12, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    static FContextualAnimSceneBindingContext BP_SceneBindingContext_MakeFromActorWithExternalTransform(AActor*& Actor, FTransform& ExternalTransform); // 0xc938940 (Index: 0x13, Flags: Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure)
    static void BP_SceneBindings_AddOrUpdateWarpTargetsForBindings(const FContextualAnimSceneBindings Bindings); // 0xc9391d4 (Index: 0x14, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void BP_SceneBindings_CalculateWarpPoints(const FContextualAnimSceneBindings Bindings, TArray<FContextualAnimWarpPoint>& OutWarpPoints); // 0xc9392b4 (Index: 0x15, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FTransform BP_SceneBindings_GetAlignmentTransformForRoleRelativeToOtherRole(const FContextualAnimSceneBindings Bindings, FName& Role, FName& RelativeToRole, float& time); // 0xc9394a4 (Index: 0x16, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FTransform BP_SceneBindings_GetAlignmentTransformForRoleRelativeToWarpPoint(const FContextualAnimSceneBindings Bindings, FName& Role, const FContextualAnimWarpPoint WarpPoint, float& time); // 0xc93972c (Index: 0x17, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FTransform BP_SceneBindings_GetAlignmentTransformFromBinding(const FContextualAnimSceneBindings Bindings, const FContextualAnimSceneBinding Binding, const FContextualAnimWarpPoint WarpPoint); // 0xc939a00 (Index: 0x18, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FContextualAnimSceneBinding BP_SceneBindings_GetBindingByActor(const FContextualAnimSceneBindings Bindings, AActor*& const Actor); // 0xc939c84 (Index: 0x19, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FContextualAnimSceneBinding BP_SceneBindings_GetBindingByRole(const FContextualAnimSceneBindings Bindings, FName& Role); // 0xc939eec (Index: 0x1a, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static TArray<FContextualAnimSceneBinding> BP_SceneBindings_GetBindings(const FContextualAnimSceneBindings Bindings); // 0xc93a084 (Index: 0x1b, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static FContextualAnimSceneBinding BP_SceneBindings_GetPrimaryBinding(const FContextualAnimSceneBindings Bindings); // 0xc93a178 (Index: 0x1c, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static UContextualAnimSceneAsset* BP_SceneBindings_GetSceneAsset(const FContextualAnimSceneBindings Bindings); // 0xc93a288 (Index: 0x1d, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void BP_SceneBindings_GetSectionAndAnimSetIndices(const FContextualAnimSceneBindings Bindings, int32_t& SectionIdx, int32_t& AnimSetIdx); // 0xc93a378 (Index: 0x1e, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
    static void BP_SceneBindings_GetSectionAndAnimSetNames(const FContextualAnimSceneBindings Bindings, FName& SectionName, FName& AnimSetName); // 0xc93a564 (Index: 0x1f, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UContextualAnimUtilities) == 0x28, "Size mismatch for UContextualAnimUtilities");

// Size: 0x40 (Inherited: 0x0, Single: 0x40)
struct FContextualAnimWarpTarget
{
    FName Role; // 0x0 (Size: 0x4, Type: NameProperty)
    FName TargetName; // 0x4 (Size: 0x4, Type: NameProperty)
    FVector TargetLocation; // 0x8 (Size: 0x18, Type: StructProperty)
    FQuat TargetRotation; // 0x20 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FContextualAnimWarpTarget) == 0x40, "Size mismatch for FContextualAnimWarpTarget");
static_assert(offsetof(FContextualAnimWarpTarget, Role) == 0x0, "Offset mismatch for FContextualAnimWarpTarget::Role");
static_assert(offsetof(FContextualAnimWarpTarget, TargetName) == 0x4, "Offset mismatch for FContextualAnimWarpTarget::TargetName");
static_assert(offsetof(FContextualAnimWarpTarget, TargetLocation) == 0x8, "Offset mismatch for FContextualAnimWarpTarget::TargetLocation");
static_assert(offsetof(FContextualAnimWarpTarget, TargetRotation) == 0x20, "Offset mismatch for FContextualAnimWarpTarget::TargetRotation");

// Size: 0x1 (Inherited: 0x0, Single: 0x1)
struct FContextualAnimRepData
{
    char RepCounter; // 0x0 (Size: 0x1, Type: ByteProperty)
};

static_assert(sizeof(FContextualAnimRepData) == 0x1, "Size mismatch for FContextualAnimRepData");
static_assert(offsetof(FContextualAnimRepData, RepCounter) == 0x0, "Offset mismatch for FContextualAnimRepData::RepCounter");

// Size: 0x50 (Inherited: 0x1, Single: 0x4f)
struct FContextualAnimRepBindingsData : FContextualAnimRepData
{
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    FContextualAnimSceneBindings Bindings; // 0x8 (Size: 0x28, Type: StructProperty)
    TArray<FContextualAnimWarpPoint> WarpPoints; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FContextualAnimWarpTarget> ExternalWarpTargets; // 0x40 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FContextualAnimRepBindingsData) == 0x50, "Size mismatch for FContextualAnimRepBindingsData");
static_assert(offsetof(FContextualAnimRepBindingsData, Bindings) == 0x8, "Offset mismatch for FContextualAnimRepBindingsData::Bindings");
static_assert(offsetof(FContextualAnimRepBindingsData, WarpPoints) == 0x30, "Offset mismatch for FContextualAnimRepBindingsData::WarpPoints");
static_assert(offsetof(FContextualAnimRepBindingsData, ExternalWarpTargets) == 0x40, "Offset mismatch for FContextualAnimRepBindingsData::ExternalWarpTargets");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FContextualAnimWarpPoint
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0xc]; // 0x4 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FContextualAnimWarpPoint) == 0x70, "Size mismatch for FContextualAnimWarpPoint");
static_assert(offsetof(FContextualAnimWarpPoint, Name) == 0x0, "Offset mismatch for FContextualAnimWarpPoint::Name");
static_assert(offsetof(FContextualAnimWarpPoint, Transform) == 0x10, "Offset mismatch for FContextualAnimWarpPoint::Transform");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FContextualAnimSceneBindings
{
    char ID; // 0x0 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    UContextualAnimSceneAsset* SceneAsset; // 0x8 (Size: 0x8, Type: ObjectProperty)
    int32_t SectionIdx; // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t AnimSetIdx; // 0x14 (Size: 0x4, Type: IntProperty)
    TArray<FContextualAnimSceneBinding> Data; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FContextualAnimSceneBindings) == 0x28, "Size mismatch for FContextualAnimSceneBindings");
static_assert(offsetof(FContextualAnimSceneBindings, ID) == 0x0, "Offset mismatch for FContextualAnimSceneBindings::ID");
static_assert(offsetof(FContextualAnimSceneBindings, SceneAsset) == 0x8, "Offset mismatch for FContextualAnimSceneBindings::SceneAsset");
static_assert(offsetof(FContextualAnimSceneBindings, SectionIdx) == 0x10, "Offset mismatch for FContextualAnimSceneBindings::SectionIdx");
static_assert(offsetof(FContextualAnimSceneBindings, AnimSetIdx) == 0x14, "Offset mismatch for FContextualAnimSceneBindings::AnimSetIdx");
static_assert(offsetof(FContextualAnimSceneBindings, Data) == 0x18, "Offset mismatch for FContextualAnimSceneBindings::Data");

// Size: 0xf0 (Inherited: 0x0, Single: 0xf0)
struct FContextualAnimSceneBinding
{
    FContextualAnimSceneBindingContext Context; // 0x0 (Size: 0xe0, Type: StructProperty)
    int32_t AnimTrackIdx; // 0xe0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_e4[0xc]; // 0xe4 (Size: 0xc, Type: PaddingProperty)
};

static_assert(sizeof(FContextualAnimSceneBinding) == 0xf0, "Size mismatch for FContextualAnimSceneBinding");
static_assert(offsetof(FContextualAnimSceneBinding, Context) == 0x0, "Offset mismatch for FContextualAnimSceneBinding::Context");
static_assert(offsetof(FContextualAnimSceneBinding, AnimTrackIdx) == 0xe0, "Offset mismatch for FContextualAnimSceneBinding::AnimTrackIdx");

// Size: 0xe0 (Inherited: 0x0, Single: 0xe0)
struct FContextualAnimSceneBindingContext
{
    TWeakObjectPtr<AActor*> Actor; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UContextualAnimSceneActorComponent*> CachedSceneActorComp; // 0x8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UAnimInstance*> CachedAnimInstance; // 0x10 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<USkeletalMeshComponent*> CachedSkeletalMesh; // 0x18 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UCharacterMovementComponent*> CachedMovementComp; // 0x20 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UMotionWarpingComponent*> CachedMotionWarpingComp; // 0x28 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_30[0xb0]; // 0x30 (Size: 0xb0, Type: PaddingProperty)
};

static_assert(sizeof(FContextualAnimSceneBindingContext) == 0xe0, "Size mismatch for FContextualAnimSceneBindingContext");
static_assert(offsetof(FContextualAnimSceneBindingContext, Actor) == 0x0, "Offset mismatch for FContextualAnimSceneBindingContext::Actor");
static_assert(offsetof(FContextualAnimSceneBindingContext, CachedSceneActorComp) == 0x8, "Offset mismatch for FContextualAnimSceneBindingContext::CachedSceneActorComp");
static_assert(offsetof(FContextualAnimSceneBindingContext, CachedAnimInstance) == 0x10, "Offset mismatch for FContextualAnimSceneBindingContext::CachedAnimInstance");
static_assert(offsetof(FContextualAnimSceneBindingContext, CachedSkeletalMesh) == 0x18, "Offset mismatch for FContextualAnimSceneBindingContext::CachedSkeletalMesh");
static_assert(offsetof(FContextualAnimSceneBindingContext, CachedMovementComp) == 0x20, "Offset mismatch for FContextualAnimSceneBindingContext::CachedMovementComp");
static_assert(offsetof(FContextualAnimSceneBindingContext, CachedMotionWarpingComp) == 0x28, "Offset mismatch for FContextualAnimSceneBindingContext::CachedMotionWarpingComp");

// Size: 0x30 (Inherited: 0x1, Single: 0x2f)
struct FContextualAnimRepLateJoinData : FContextualAnimRepData
{
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<AActor*> Actor; // 0x4 (Size: 0x8, Type: WeakObjectProperty)
    FName Role; // 0xc (Size: 0x4, Type: NameProperty)
    TArray<FContextualAnimWarpPoint> WarpPoints; // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FContextualAnimWarpTarget> ExternalWarpTargets; // 0x20 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FContextualAnimRepLateJoinData) == 0x30, "Size mismatch for FContextualAnimRepLateJoinData");
static_assert(offsetof(FContextualAnimRepLateJoinData, Actor) == 0x4, "Offset mismatch for FContextualAnimRepLateJoinData::Actor");
static_assert(offsetof(FContextualAnimRepLateJoinData, Role) == 0xc, "Offset mismatch for FContextualAnimRepLateJoinData::Role");
static_assert(offsetof(FContextualAnimRepLateJoinData, WarpPoints) == 0x10, "Offset mismatch for FContextualAnimRepLateJoinData::WarpPoints");
static_assert(offsetof(FContextualAnimRepLateJoinData, ExternalWarpTargets) == 0x20, "Offset mismatch for FContextualAnimRepLateJoinData::ExternalWarpTargets");

// Size: 0x28 (Inherited: 0x1, Single: 0x27)
struct FContextualAnimRepTransitionData : FContextualAnimRepData
{
    char ID; // 0x1 (Size: 0x1, Type: ByteProperty)
    char SectionIdx; // 0x2 (Size: 0x1, Type: ByteProperty)
    char AnimSetIdx; // 0x3 (Size: 0x1, Type: ByteProperty)
    bool bStopEveryone; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    TArray<FContextualAnimWarpPoint> WarpPoints; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FContextualAnimWarpTarget> ExternalWarpTargets; // 0x18 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FContextualAnimRepTransitionData) == 0x28, "Size mismatch for FContextualAnimRepTransitionData");
static_assert(offsetof(FContextualAnimRepTransitionData, ID) == 0x1, "Offset mismatch for FContextualAnimRepTransitionData::ID");
static_assert(offsetof(FContextualAnimRepTransitionData, SectionIdx) == 0x2, "Offset mismatch for FContextualAnimRepTransitionData::SectionIdx");
static_assert(offsetof(FContextualAnimRepTransitionData, AnimSetIdx) == 0x3, "Offset mismatch for FContextualAnimRepTransitionData::AnimSetIdx");
static_assert(offsetof(FContextualAnimRepTransitionData, bStopEveryone) == 0x4, "Offset mismatch for FContextualAnimRepTransitionData::bStopEveryone");
static_assert(offsetof(FContextualAnimRepTransitionData, WarpPoints) == 0x8, "Offset mismatch for FContextualAnimRepTransitionData::WarpPoints");
static_assert(offsetof(FContextualAnimRepTransitionData, ExternalWarpTargets) == 0x18, "Offset mismatch for FContextualAnimRepTransitionData::ExternalWarpTargets");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FContextualAnimIgnoreChannelsParam
{
    FName Role; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<TEnumAsByte<ECollisionChannel>> Channels; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FContextualAnimIgnoreChannelsParam) == 0x18, "Size mismatch for FContextualAnimIgnoreChannelsParam");
static_assert(offsetof(FContextualAnimIgnoreChannelsParam, Role) == 0x0, "Offset mismatch for FContextualAnimIgnoreChannelsParam::Role");
static_assert(offsetof(FContextualAnimIgnoreChannelsParam, Channels) == 0x8, "Offset mismatch for FContextualAnimIgnoreChannelsParam::Channels");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FContextualAnimAttachmentParams
{
    FName Role; // 0x0 (Size: 0x4, Type: NameProperty)
    FName SocketName; // 0x4 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform RelativeTransform; // 0x10 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FContextualAnimAttachmentParams) == 0x70, "Size mismatch for FContextualAnimAttachmentParams");
static_assert(offsetof(FContextualAnimAttachmentParams, Role) == 0x0, "Offset mismatch for FContextualAnimAttachmentParams::Role");
static_assert(offsetof(FContextualAnimAttachmentParams, SocketName) == 0x4, "Offset mismatch for FContextualAnimAttachmentParams::SocketName");
static_assert(offsetof(FContextualAnimAttachmentParams, RelativeTransform) == 0x10, "Offset mismatch for FContextualAnimAttachmentParams::RelativeTransform");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FContextualAnimSet
{
    TArray<FContextualAnimTrack> Tracks; // 0x0 (Size: 0x10, Type: ArrayProperty)
    TMap<FTransform, FName> WarpPoints; // 0x10 (Size: 0x50, Type: MapProperty)
    FName Name; // 0x60 (Size: 0x4, Type: NameProperty)
    float RandomWeight; // 0x64 (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FContextualAnimSet) == 0x68, "Size mismatch for FContextualAnimSet");
static_assert(offsetof(FContextualAnimSet, Tracks) == 0x0, "Offset mismatch for FContextualAnimSet::Tracks");
static_assert(offsetof(FContextualAnimSet, WarpPoints) == 0x10, "Offset mismatch for FContextualAnimSet::WarpPoints");
static_assert(offsetof(FContextualAnimSet, Name) == 0x60, "Offset mismatch for FContextualAnimSet::Name");
static_assert(offsetof(FContextualAnimSet, RandomWeight) == 0x64, "Offset mismatch for FContextualAnimSet::RandomWeight");

// Size: 0xf0 (Inherited: 0x0, Single: 0xf0)
struct FContextualAnimTrack
{
    UAnimSequenceBase* Animation; // 0x0 (Size: 0x8, Type: ObjectProperty)
    float AnimMaxStartTime; // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bChangeMovementMode; // 0xc (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EMovementMode> MovementMode; // 0xd (Size: 0x1, Type: ByteProperty)
    char CustomMovementMode; // 0xe (Size: 0x1, Type: ByteProperty)
    bool bControlCharacterRotation; // 0xf (Size: 0x1, Type: BoolProperty)
    bool bOptional; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
    FContextualAnimAlignmentTrackContainer AlignmentData; // 0x18 (Size: 0x28, Type: StructProperty)
    FContextualAnimAlignmentTrackContainer IKTargetData; // 0x40 (Size: 0x28, Type: StructProperty)
    TArray<UContextualAnimSelectionCriterion*> SelectionCriteria; // 0x68 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_78[0x8]; // 0x78 (Size: 0x8, Type: PaddingProperty)
    FTransform MeshToScene; // 0x80 (Size: 0x60, Type: StructProperty)
    FName Role; // 0xe0 (Size: 0x4, Type: NameProperty)
    int32_t SectionIdx; // 0xe4 (Size: 0x4, Type: IntProperty)
    int32_t AnimSetIdx; // 0xe8 (Size: 0x4, Type: IntProperty)
    int32_t AnimTrackIdx; // 0xec (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FContextualAnimTrack) == 0xf0, "Size mismatch for FContextualAnimTrack");
static_assert(offsetof(FContextualAnimTrack, Animation) == 0x0, "Offset mismatch for FContextualAnimTrack::Animation");
static_assert(offsetof(FContextualAnimTrack, AnimMaxStartTime) == 0x8, "Offset mismatch for FContextualAnimTrack::AnimMaxStartTime");
static_assert(offsetof(FContextualAnimTrack, bChangeMovementMode) == 0xc, "Offset mismatch for FContextualAnimTrack::bChangeMovementMode");
static_assert(offsetof(FContextualAnimTrack, MovementMode) == 0xd, "Offset mismatch for FContextualAnimTrack::MovementMode");
static_assert(offsetof(FContextualAnimTrack, CustomMovementMode) == 0xe, "Offset mismatch for FContextualAnimTrack::CustomMovementMode");
static_assert(offsetof(FContextualAnimTrack, bControlCharacterRotation) == 0xf, "Offset mismatch for FContextualAnimTrack::bControlCharacterRotation");
static_assert(offsetof(FContextualAnimTrack, bOptional) == 0x10, "Offset mismatch for FContextualAnimTrack::bOptional");
static_assert(offsetof(FContextualAnimTrack, AlignmentData) == 0x18, "Offset mismatch for FContextualAnimTrack::AlignmentData");
static_assert(offsetof(FContextualAnimTrack, IKTargetData) == 0x40, "Offset mismatch for FContextualAnimTrack::IKTargetData");
static_assert(offsetof(FContextualAnimTrack, SelectionCriteria) == 0x68, "Offset mismatch for FContextualAnimTrack::SelectionCriteria");
static_assert(offsetof(FContextualAnimTrack, MeshToScene) == 0x80, "Offset mismatch for FContextualAnimTrack::MeshToScene");
static_assert(offsetof(FContextualAnimTrack, Role) == 0xe0, "Offset mismatch for FContextualAnimTrack::Role");
static_assert(offsetof(FContextualAnimTrack, SectionIdx) == 0xe4, "Offset mismatch for FContextualAnimTrack::SectionIdx");
static_assert(offsetof(FContextualAnimTrack, AnimSetIdx) == 0xe8, "Offset mismatch for FContextualAnimTrack::AnimSetIdx");
static_assert(offsetof(FContextualAnimTrack, AnimTrackIdx) == 0xec, "Offset mismatch for FContextualAnimTrack::AnimTrackIdx");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FContextualAnimAlignmentTrackContainer
{
    FAnimSequenceTrackContainer Tracks; // 0x0 (Size: 0x20, Type: StructProperty)
    float SampleInterval; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_24[0x4]; // 0x24 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FContextualAnimAlignmentTrackContainer) == 0x28, "Size mismatch for FContextualAnimAlignmentTrackContainer");
static_assert(offsetof(FContextualAnimAlignmentTrackContainer, Tracks) == 0x0, "Offset mismatch for FContextualAnimAlignmentTrackContainer::Tracks");
static_assert(offsetof(FContextualAnimAlignmentTrackContainer, SampleInterval) == 0x20, "Offset mismatch for FContextualAnimAlignmentTrackContainer::SampleInterval");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FContextualAnimSceneSection
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FContextualAnimSet> AnimSets; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FContextualAnimWarpPointDefinition> WarpPointDefinitions; // 0x18 (Size: 0x10, Type: ArrayProperty)
    bool bSyncAnimations; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FContextualAnimSceneSection) == 0x30, "Size mismatch for FContextualAnimSceneSection");
static_assert(offsetof(FContextualAnimSceneSection, Name) == 0x0, "Offset mismatch for FContextualAnimSceneSection::Name");
static_assert(offsetof(FContextualAnimSceneSection, AnimSets) == 0x8, "Offset mismatch for FContextualAnimSceneSection::AnimSets");
static_assert(offsetof(FContextualAnimSceneSection, WarpPointDefinitions) == 0x18, "Offset mismatch for FContextualAnimSceneSection::WarpPointDefinitions");
static_assert(offsetof(FContextualAnimSceneSection, bSyncAnimations) == 0x28, "Offset mismatch for FContextualAnimSceneSection::bSyncAnimations");

// Size: 0x1c (Inherited: 0x0, Single: 0x1c)
struct FContextualAnimWarpPointDefinition
{
    FName WarpTargetName; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Mode; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FName SocketName; // 0x8 (Size: 0x4, Type: NameProperty)
    FContextualAnimWarpPointCustomParams Params; // 0xc (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FContextualAnimWarpPointDefinition) == 0x1c, "Size mismatch for FContextualAnimWarpPointDefinition");
static_assert(offsetof(FContextualAnimWarpPointDefinition, WarpTargetName) == 0x0, "Offset mismatch for FContextualAnimWarpPointDefinition::WarpTargetName");
static_assert(offsetof(FContextualAnimWarpPointDefinition, Mode) == 0x4, "Offset mismatch for FContextualAnimWarpPointDefinition::Mode");
static_assert(offsetof(FContextualAnimWarpPointDefinition, SocketName) == 0x8, "Offset mismatch for FContextualAnimWarpPointDefinition::SocketName");
static_assert(offsetof(FContextualAnimWarpPointDefinition, Params) == 0xc, "Offset mismatch for FContextualAnimWarpPointDefinition::Params");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FContextualAnimWarpPointCustomParams
{
    FName origin; // 0x0 (Size: 0x4, Type: NameProperty)
    bool bAlongClosestDistance; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    FName OtherRole; // 0x8 (Size: 0x4, Type: NameProperty)
    float Weight; // 0xc (Size: 0x4, Type: FloatProperty)
};

static_assert(sizeof(FContextualAnimWarpPointCustomParams) == 0x10, "Size mismatch for FContextualAnimWarpPointCustomParams");
static_assert(offsetof(FContextualAnimWarpPointCustomParams, origin) == 0x0, "Offset mismatch for FContextualAnimWarpPointCustomParams::origin");
static_assert(offsetof(FContextualAnimWarpPointCustomParams, bAlongClosestDistance) == 0x4, "Offset mismatch for FContextualAnimWarpPointCustomParams::bAlongClosestDistance");
static_assert(offsetof(FContextualAnimWarpPointCustomParams, OtherRole) == 0x8, "Offset mismatch for FContextualAnimWarpPointCustomParams::OtherRole");
static_assert(offsetof(FContextualAnimWarpPointCustomParams, Weight) == 0xc, "Offset mismatch for FContextualAnimWarpPointCustomParams::Weight");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FContextualAnimPoint
{
    FName Role; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0xc]; // 0x4 (Size: 0xc, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
    float Speed; // 0x70 (Size: 0x4, Type: FloatProperty)
    int32_t SectionIdx; // 0x74 (Size: 0x4, Type: IntProperty)
    int32_t AnimSetIdx; // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t AnimTrackIdx; // 0x7c (Size: 0x4, Type: IntProperty)
};

static_assert(sizeof(FContextualAnimPoint) == 0x80, "Size mismatch for FContextualAnimPoint");
static_assert(offsetof(FContextualAnimPoint, Role) == 0x0, "Offset mismatch for FContextualAnimPoint::Role");
static_assert(offsetof(FContextualAnimPoint, Transform) == 0x10, "Offset mismatch for FContextualAnimPoint::Transform");
static_assert(offsetof(FContextualAnimPoint, Speed) == 0x70, "Offset mismatch for FContextualAnimPoint::Speed");
static_assert(offsetof(FContextualAnimPoint, SectionIdx) == 0x74, "Offset mismatch for FContextualAnimPoint::SectionIdx");
static_assert(offsetof(FContextualAnimPoint, AnimSetIdx) == 0x78, "Offset mismatch for FContextualAnimPoint::AnimSetIdx");
static_assert(offsetof(FContextualAnimPoint, AnimTrackIdx) == 0x7c, "Offset mismatch for FContextualAnimPoint::AnimTrackIdx");

// Size: 0x88 (Inherited: 0x0, Single: 0x88)
struct FContextualAnimActorPreviewData
{
    FName Role; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Type; // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    TSoftObjectPtr<USkeletalMesh*> PreviewSkeletalMesh; // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftClassPtr PreviewAnimInstance; // 0x28 (Size: 0x20, Type: SoftClassProperty)
    TSoftObjectPtr<UStaticMesh*> PreviewStaticMesh; // 0x48 (Size: 0x20, Type: SoftObjectProperty)
    TSoftClassPtr PreviewActorClass; // 0x68 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FContextualAnimActorPreviewData) == 0x88, "Size mismatch for FContextualAnimActorPreviewData");
static_assert(offsetof(FContextualAnimActorPreviewData, Role) == 0x0, "Offset mismatch for FContextualAnimActorPreviewData::Role");
static_assert(offsetof(FContextualAnimActorPreviewData, Type) == 0x4, "Offset mismatch for FContextualAnimActorPreviewData::Type");
static_assert(offsetof(FContextualAnimActorPreviewData, PreviewSkeletalMesh) == 0x8, "Offset mismatch for FContextualAnimActorPreviewData::PreviewSkeletalMesh");
static_assert(offsetof(FContextualAnimActorPreviewData, PreviewAnimInstance) == 0x28, "Offset mismatch for FContextualAnimActorPreviewData::PreviewAnimInstance");
static_assert(offsetof(FContextualAnimActorPreviewData, PreviewStaticMesh) == 0x48, "Offset mismatch for FContextualAnimActorPreviewData::PreviewStaticMesh");
static_assert(offsetof(FContextualAnimActorPreviewData, PreviewActorClass) == 0x68, "Offset mismatch for FContextualAnimActorPreviewData::PreviewActorClass");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FContextualAnimIKTargetDefinition
{
    FName GoalName; // 0x0 (Size: 0x4, Type: NameProperty)
    FName BoneName; // 0x4 (Size: 0x4, Type: NameProperty)
    uint8_t Provider; // 0x8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_9[0x3]; // 0x9 (Size: 0x3, Type: PaddingProperty)
    FName TargetRoleName; // 0xc (Size: 0x4, Type: NameProperty)
    FName TargetBoneName; // 0x10 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FContextualAnimIKTargetDefinition) == 0x14, "Size mismatch for FContextualAnimIKTargetDefinition");
static_assert(offsetof(FContextualAnimIKTargetDefinition, GoalName) == 0x0, "Offset mismatch for FContextualAnimIKTargetDefinition::GoalName");
static_assert(offsetof(FContextualAnimIKTargetDefinition, BoneName) == 0x4, "Offset mismatch for FContextualAnimIKTargetDefinition::BoneName");
static_assert(offsetof(FContextualAnimIKTargetDefinition, Provider) == 0x8, "Offset mismatch for FContextualAnimIKTargetDefinition::Provider");
static_assert(offsetof(FContextualAnimIKTargetDefinition, TargetRoleName) == 0xc, "Offset mismatch for FContextualAnimIKTargetDefinition::TargetRoleName");
static_assert(offsetof(FContextualAnimIKTargetDefinition, TargetBoneName) == 0x10, "Offset mismatch for FContextualAnimIKTargetDefinition::TargetBoneName");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FContextualAnimIKTarget
{
    FName GoalName; // 0x0 (Size: 0x4, Type: NameProperty)
    FName BoneName; // 0x4 (Size: 0x4, Type: NameProperty)
    float Alpha; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FTransform Transform; // 0x10 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FContextualAnimIKTarget) == 0x70, "Size mismatch for FContextualAnimIKTarget");
static_assert(offsetof(FContextualAnimIKTarget, GoalName) == 0x0, "Offset mismatch for FContextualAnimIKTarget::GoalName");
static_assert(offsetof(FContextualAnimIKTarget, BoneName) == 0x4, "Offset mismatch for FContextualAnimIKTarget::BoneName");
static_assert(offsetof(FContextualAnimIKTarget, Alpha) == 0x8, "Offset mismatch for FContextualAnimIKTarget::Alpha");
static_assert(offsetof(FContextualAnimIKTarget, Transform) == 0x10, "Offset mismatch for FContextualAnimIKTarget::Transform");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FContextualAnimIKTargetDefContainer
{
    FName Role; // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    TArray<FContextualAnimIKTargetDefinition> IKTargetDefs; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FContextualAnimIKTargetDefContainer) == 0x18, "Size mismatch for FContextualAnimIKTargetDefContainer");
static_assert(offsetof(FContextualAnimIKTargetDefContainer, Role) == 0x0, "Offset mismatch for FContextualAnimIKTargetDefContainer::Role");
static_assert(offsetof(FContextualAnimIKTargetDefContainer, IKTargetDefs) == 0x8, "Offset mismatch for FContextualAnimIKTargetDefContainer::IKTargetDefs");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FContextualAnimIKTargetParams
{
    TArray<FContextualAnimIKTargetDefContainer> IKTargetDefsForEachRole; // 0x0 (Size: 0x10, Type: ArrayProperty)
    uint8_t AlphaProvider; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_11[0x7]; // 0x11 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FContextualAnimIKTargetParams) == 0x18, "Size mismatch for FContextualAnimIKTargetParams");
static_assert(offsetof(FContextualAnimIKTargetParams, IKTargetDefsForEachRole) == 0x0, "Offset mismatch for FContextualAnimIKTargetParams::IKTargetDefsForEachRole");
static_assert(offsetof(FContextualAnimIKTargetParams, AlphaProvider) == 0x10, "Offset mismatch for FContextualAnimIKTargetParams::AlphaProvider");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FContextualAnimRoleDefinition
{
    FName Name; // 0x0 (Size: 0x4, Type: NameProperty)
    bool bIsCharacter; // 0x4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5[0x3]; // 0x5 (Size: 0x3, Type: PaddingProperty)
    float PreviewCapsuleHalfHeight; // 0x8 (Size: 0x4, Type: FloatProperty)
    float PreviewCapsuleRadius; // 0xc (Size: 0x4, Type: FloatProperty)
    FTransform MeshToComponent; // 0x10 (Size: 0x60, Type: StructProperty)
};

static_assert(sizeof(FContextualAnimRoleDefinition) == 0x70, "Size mismatch for FContextualAnimRoleDefinition");
static_assert(offsetof(FContextualAnimRoleDefinition, Name) == 0x0, "Offset mismatch for FContextualAnimRoleDefinition::Name");
static_assert(offsetof(FContextualAnimRoleDefinition, bIsCharacter) == 0x4, "Offset mismatch for FContextualAnimRoleDefinition::bIsCharacter");
static_assert(offsetof(FContextualAnimRoleDefinition, PreviewCapsuleHalfHeight) == 0x8, "Offset mismatch for FContextualAnimRoleDefinition::PreviewCapsuleHalfHeight");
static_assert(offsetof(FContextualAnimRoleDefinition, PreviewCapsuleRadius) == 0xc, "Offset mismatch for FContextualAnimRoleDefinition::PreviewCapsuleRadius");
static_assert(offsetof(FContextualAnimRoleDefinition, MeshToComponent) == 0x10, "Offset mismatch for FContextualAnimRoleDefinition::MeshToComponent");

// Size: 0x68 (Inherited: 0x0, Single: 0x68)
struct FContextualAnimStartSceneParams
{
    TMap<FContextualAnimSceneBindingContext, FName> RoleToActorMap; // 0x0 (Size: 0x50, Type: MapProperty)
    int32_t SectionIdx; // 0x50 (Size: 0x4, Type: IntProperty)
    int32_t AnimSetIdx; // 0x54 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_58[0x10]; // 0x58 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(FContextualAnimStartSceneParams) == 0x68, "Size mismatch for FContextualAnimStartSceneParams");
static_assert(offsetof(FContextualAnimStartSceneParams, RoleToActorMap) == 0x0, "Offset mismatch for FContextualAnimStartSceneParams::RoleToActorMap");
static_assert(offsetof(FContextualAnimStartSceneParams, SectionIdx) == 0x50, "Offset mismatch for FContextualAnimStartSceneParams::SectionIdx");
static_assert(offsetof(FContextualAnimStartSceneParams, AnimSetIdx) == 0x54, "Offset mismatch for FContextualAnimStartSceneParams::AnimSetIdx");

// Size: 0xe0 (Inherited: 0x0, Single: 0xe0)
struct FContextualAnimQueryResult
{
    TWeakObjectPtr<UAnimMontage*> Animation; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform EntryTransform; // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform SyncTransform; // 0x70 (Size: 0x60, Type: StructProperty)
    float AnimStartTime; // 0xd0 (Size: 0x4, Type: FloatProperty)
    int32_t AnimSetIdx; // 0xd4 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_d8[0x8]; // 0xd8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(FContextualAnimQueryResult) == 0xe0, "Size mismatch for FContextualAnimQueryResult");
static_assert(offsetof(FContextualAnimQueryResult, Animation) == 0x0, "Offset mismatch for FContextualAnimQueryResult::Animation");
static_assert(offsetof(FContextualAnimQueryResult, EntryTransform) == 0x10, "Offset mismatch for FContextualAnimQueryResult::EntryTransform");
static_assert(offsetof(FContextualAnimQueryResult, SyncTransform) == 0x70, "Offset mismatch for FContextualAnimQueryResult::SyncTransform");
static_assert(offsetof(FContextualAnimQueryResult, AnimStartTime) == 0xd0, "Offset mismatch for FContextualAnimQueryResult::AnimStartTime");
static_assert(offsetof(FContextualAnimQueryResult, AnimSetIdx) == 0xd4, "Offset mismatch for FContextualAnimQueryResult::AnimSetIdx");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FContextualAnimQueryParams
{
    TWeakObjectPtr<AActor*> Querier; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_8[0x8]; // 0x8 (Size: 0x8, Type: PaddingProperty)
    FTransform QueryTransform; // 0x10 (Size: 0x60, Type: StructProperty)
    bool bComplexQuery; // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bFindAnimStartTime; // 0x71 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_72[0xe]; // 0x72 (Size: 0xe, Type: PaddingProperty)
};

static_assert(sizeof(FContextualAnimQueryParams) == 0x80, "Size mismatch for FContextualAnimQueryParams");
static_assert(offsetof(FContextualAnimQueryParams, Querier) == 0x0, "Offset mismatch for FContextualAnimQueryParams::Querier");
static_assert(offsetof(FContextualAnimQueryParams, QueryTransform) == 0x10, "Offset mismatch for FContextualAnimQueryParams::QueryTransform");
static_assert(offsetof(FContextualAnimQueryParams, bComplexQuery) == 0x70, "Offset mismatch for FContextualAnimQueryParams::bComplexQuery");
static_assert(offsetof(FContextualAnimQueryParams, bFindAnimStartTime) == 0x71, "Offset mismatch for FContextualAnimQueryParams::bFindAnimStartTime");

