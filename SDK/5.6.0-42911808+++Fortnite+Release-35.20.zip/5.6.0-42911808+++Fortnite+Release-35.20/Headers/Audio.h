/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Audio
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "RockVehicleRuntime.h"
#include "CoreUObject.h"
#include "Rock_Vehicle.h"
#include "Engine.h"
#include "FortniteGame.h"
#include "AudioMotorSimStandardComponents.h"
#include "REVRuntime.h"

// Size: 0x601 (Inherited: 0x1210, Single: 0xfffff3f1)
class ABP_RockVehicleAudioController_C : public ARockVehicleAudioController
{
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x528 (Size: 0x8, Type: StructProperty)
    UAudioComponent* BoostFailedSound; // 0x530 (Size: 0x8, Type: ObjectProperty)
    UREVComponent* REV; // 0x538 (Size: 0x8, Type: ObjectProperty)
    UVelocitySyncMotorSimComponent* VelocitySyncMotorSim; // 0x540 (Size: 0x8, Type: ObjectProperty)
    UMotorPhysicsSimComponent* MotorPhysicsSim; // 0x548 (Size: 0x8, Type: ObjectProperty)
    UReverseMotorSimComponent* ReverseMotorSim; // 0x550 (Size: 0x8, Type: ObjectProperty)
    URevLimiterMotorSimComponent* RevLimiterMotorSim; // 0x558 (Size: 0x8, Type: ObjectProperty)
    UResistanceMotorSimComponent* ResistanceMotorSim; // 0x560 (Size: 0x8, Type: ObjectProperty)
    UThrottleStateMotorSimComponent* ThrottleStateMotorSim; // 0x568 (Size: 0x8, Type: ObjectProperty)
    UBoostMotorSimComponent* BoostMotorSim; // 0x570 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* OnGround; // 0x578 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* Boost; // 0x580 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* BoostEnd; // 0x588 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* SuperSonicLoop; // 0x590 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* InAir; // 0x598 (Size: 0x8, Type: ObjectProperty)
    UFortLayeredAudioComponent* Engine; // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    UFortCollisionAudioComponent* Collision_Body; // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    ARock_Vehicle_C* RockVehicle; // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    bool IsLocal; // 0x5b8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5b9[0x7]; // 0x5b9 (Size: 0x7, Type: PaddingProperty)
    double Boost_Fade_Out_Duration; // 0x5c0 (Size: 0x8, Type: DoubleProperty)
    double EngineRampVolume; // 0x5c8 (Size: 0x8, Type: DoubleProperty)
    UCurveFloat* WheelImpactCurve; // 0x5d0 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* WheelImpactSkidCurve; // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EPhysicalSurface> CachedSurface; // 0x5e0 (Size: 0x1, Type: ByteProperty)
    bool In_Air; // 0x5e1 (Size: 0x1, Type: BoolProperty)
    bool Occupied; // 0x5e2 (Size: 0x1, Type: BoolProperty)
    bool TiresActive; // 0x5e3 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_5e4[0x4]; // 0x5e4 (Size: 0x4, Type: PaddingProperty)
    UAudioComponent* PreDestroyAudioComponent; // 0x5e8 (Size: 0x8, Type: ObjectProperty)
    double DamageValue; // 0x5f0 (Size: 0x8, Type: DoubleProperty)
    USoundBase* PreDestroySoundCue; // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    bool bOutOfFuel; // 0x600 (Size: 0x1, Type: BoolProperty)

public:
    void InitRockVehicle(); // 0x288a61c (Index: 0x0, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetNewSnowmanTransform(FTransform& Transform); // 0x288a61c (Index: 0x1, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void GetVehicleSurfaceType(TEnumAsByte<EPhysicalSurface>& InPhysicalSurface, int32_t& Surface_ID); // 0x288a61c (Index: 0x2, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure)
    void OnBodyCollision(FVector& HitLocation, FVector& NormalImpulse, bool& FilteredHit, double& Magnitude); // 0x288a61c (Index: 0x3, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    void OnExplode(AController*& const LastDamageInstigator, AActor*& Vehicle); // 0x288a61c (Index: 0xc, Flags: Public|BlueprintCallable|BlueprintEvent)
    virtual void OnInAirUpdated(bool& const bNewInAir); // 0x288a61c (Index: 0xd, Flags: Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void OnInit(); // 0x288a61c (Index: 0xe, Flags: Event|Public|BlueprintEvent)
    void OnTireCollision(FName& Socket, float& ImpactSpeed, const FHitResult OutHit); // 0x288a61c (Index: 0x15, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    virtual void OnUpdate(float& DeltaSeconds); // 0x288a61c (Index: 0x16, Flags: Event|Public|BlueprintEvent)
    void UpdateSurfaceType(TEnumAsByte<EPhysicalSurface>& InPhysicalSurface); // 0x288a61c (Index: 0x19, Flags: Public|BlueprintCallable|BlueprintEvent)
    void UpdateTireSounds(); // 0x288a61c (Index: 0x1a, Flags: Public|BlueprintCallable|BlueprintEvent)
    void GetMaterialInt(int32_t& MatInt); // 0x288a61c (Index: 0x1e, Flags: Public|HasOutParms|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(ABP_RockVehicleAudioController_C) == 0x601, "Size mismatch for ABP_RockVehicleAudioController_C");
static_assert(offsetof(ABP_RockVehicleAudioController_C, UberGraphFrame) == 0x528, "Offset mismatch for ABP_RockVehicleAudioController_C::UberGraphFrame");
static_assert(offsetof(ABP_RockVehicleAudioController_C, BoostFailedSound) == 0x530, "Offset mismatch for ABP_RockVehicleAudioController_C::BoostFailedSound");
static_assert(offsetof(ABP_RockVehicleAudioController_C, REV) == 0x538, "Offset mismatch for ABP_RockVehicleAudioController_C::REV");
static_assert(offsetof(ABP_RockVehicleAudioController_C, VelocitySyncMotorSim) == 0x540, "Offset mismatch for ABP_RockVehicleAudioController_C::VelocitySyncMotorSim");
static_assert(offsetof(ABP_RockVehicleAudioController_C, MotorPhysicsSim) == 0x548, "Offset mismatch for ABP_RockVehicleAudioController_C::MotorPhysicsSim");
static_assert(offsetof(ABP_RockVehicleAudioController_C, ReverseMotorSim) == 0x550, "Offset mismatch for ABP_RockVehicleAudioController_C::ReverseMotorSim");
static_assert(offsetof(ABP_RockVehicleAudioController_C, RevLimiterMotorSim) == 0x558, "Offset mismatch for ABP_RockVehicleAudioController_C::RevLimiterMotorSim");
static_assert(offsetof(ABP_RockVehicleAudioController_C, ResistanceMotorSim) == 0x560, "Offset mismatch for ABP_RockVehicleAudioController_C::ResistanceMotorSim");
static_assert(offsetof(ABP_RockVehicleAudioController_C, ThrottleStateMotorSim) == 0x568, "Offset mismatch for ABP_RockVehicleAudioController_C::ThrottleStateMotorSim");
static_assert(offsetof(ABP_RockVehicleAudioController_C, BoostMotorSim) == 0x570, "Offset mismatch for ABP_RockVehicleAudioController_C::BoostMotorSim");
static_assert(offsetof(ABP_RockVehicleAudioController_C, OnGround) == 0x578, "Offset mismatch for ABP_RockVehicleAudioController_C::OnGround");
static_assert(offsetof(ABP_RockVehicleAudioController_C, Boost) == 0x580, "Offset mismatch for ABP_RockVehicleAudioController_C::Boost");
static_assert(offsetof(ABP_RockVehicleAudioController_C, BoostEnd) == 0x588, "Offset mismatch for ABP_RockVehicleAudioController_C::BoostEnd");
static_assert(offsetof(ABP_RockVehicleAudioController_C, SuperSonicLoop) == 0x590, "Offset mismatch for ABP_RockVehicleAudioController_C::SuperSonicLoop");
static_assert(offsetof(ABP_RockVehicleAudioController_C, InAir) == 0x598, "Offset mismatch for ABP_RockVehicleAudioController_C::InAir");
static_assert(offsetof(ABP_RockVehicleAudioController_C, Engine) == 0x5a0, "Offset mismatch for ABP_RockVehicleAudioController_C::Engine");
static_assert(offsetof(ABP_RockVehicleAudioController_C, Collision_Body) == 0x5a8, "Offset mismatch for ABP_RockVehicleAudioController_C::Collision_Body");
static_assert(offsetof(ABP_RockVehicleAudioController_C, RockVehicle) == 0x5b0, "Offset mismatch for ABP_RockVehicleAudioController_C::RockVehicle");
static_assert(offsetof(ABP_RockVehicleAudioController_C, IsLocal) == 0x5b8, "Offset mismatch for ABP_RockVehicleAudioController_C::IsLocal");
static_assert(offsetof(ABP_RockVehicleAudioController_C, Boost_Fade_Out_Duration) == 0x5c0, "Offset mismatch for ABP_RockVehicleAudioController_C::Boost_Fade_Out_Duration");
static_assert(offsetof(ABP_RockVehicleAudioController_C, EngineRampVolume) == 0x5c8, "Offset mismatch for ABP_RockVehicleAudioController_C::EngineRampVolume");
static_assert(offsetof(ABP_RockVehicleAudioController_C, WheelImpactCurve) == 0x5d0, "Offset mismatch for ABP_RockVehicleAudioController_C::WheelImpactCurve");
static_assert(offsetof(ABP_RockVehicleAudioController_C, WheelImpactSkidCurve) == 0x5d8, "Offset mismatch for ABP_RockVehicleAudioController_C::WheelImpactSkidCurve");
static_assert(offsetof(ABP_RockVehicleAudioController_C, CachedSurface) == 0x5e0, "Offset mismatch for ABP_RockVehicleAudioController_C::CachedSurface");
static_assert(offsetof(ABP_RockVehicleAudioController_C, In_Air) == 0x5e1, "Offset mismatch for ABP_RockVehicleAudioController_C::In_Air");
static_assert(offsetof(ABP_RockVehicleAudioController_C, Occupied) == 0x5e2, "Offset mismatch for ABP_RockVehicleAudioController_C::Occupied");
static_assert(offsetof(ABP_RockVehicleAudioController_C, TiresActive) == 0x5e3, "Offset mismatch for ABP_RockVehicleAudioController_C::TiresActive");
static_assert(offsetof(ABP_RockVehicleAudioController_C, PreDestroyAudioComponent) == 0x5e8, "Offset mismatch for ABP_RockVehicleAudioController_C::PreDestroyAudioComponent");
static_assert(offsetof(ABP_RockVehicleAudioController_C, DamageValue) == 0x5f0, "Offset mismatch for ABP_RockVehicleAudioController_C::DamageValue");
static_assert(offsetof(ABP_RockVehicleAudioController_C, PreDestroySoundCue) == 0x5f8, "Offset mismatch for ABP_RockVehicleAudioController_C::PreDestroySoundCue");
static_assert(offsetof(ABP_RockVehicleAudioController_C, bOutOfFuel) == 0x600, "Offset mismatch for ABP_RockVehicleAudioController_C::bOutOfFuel");

