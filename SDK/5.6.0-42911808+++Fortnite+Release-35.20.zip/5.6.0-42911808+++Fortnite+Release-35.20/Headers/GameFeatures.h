/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameFeatures
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "DeveloperSettings.h"
#include "DataRegistry.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameFeatureStateChangeObserver : public UInterface
{
public:
};

static_assert(sizeof(UGameFeatureStateChangeObserver) == 0x28, "Size mismatch for UGameFeatureStateChangeObserver");

// Size: 0x80 (Inherited: 0xa8, Single: 0xffffffd8)
class UGameFeatureVersePathMapperCommandlet : public UCommandlet
{
public:
};

static_assert(sizeof(UGameFeatureVersePathMapperCommandlet) == 0x80, "Size mismatch for UGameFeatureVersePathMapperCommandlet");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UGameFeatureAction : public UObject
{
public:
};

static_assert(sizeof(UGameFeatureAction) == 0x28, "Size mismatch for UGameFeatureAction");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameFeatureAction_AddActorFactory : public UGameFeatureAction
{
public:
};

static_assert(sizeof(UGameFeatureAction_AddActorFactory) == 0x28, "Size mismatch for UGameFeatureAction_AddActorFactory");

// Size: 0x60 (Inherited: 0x50, Single: 0x10)
class UGameFeatureAction_AddCheats : public UGameFeatureAction
{
public:
    TArray<TSoftClassPtr> CheatManagers; // 0x28 (Size: 0x10, Type: ArrayProperty)
    bool bLoadCheatManagersAsync; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0xf]; // 0x39 (Size: 0xf, Type: PaddingProperty)
    TArray<TWeakObjectPtr<UCheatManagerExtension*>> SpawnedCheatManagers; // 0x48 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeatureAction_AddCheats) == 0x60, "Size mismatch for UGameFeatureAction_AddCheats");
static_assert(offsetof(UGameFeatureAction_AddCheats, CheatManagers) == 0x28, "Offset mismatch for UGameFeatureAction_AddCheats::CheatManagers");
static_assert(offsetof(UGameFeatureAction_AddCheats, bLoadCheatManagersAsync) == 0x38, "Offset mismatch for UGameFeatureAction_AddCheats::bLoadCheatManagersAsync");
static_assert(offsetof(UGameFeatureAction_AddCheats, SpawnedCheatManagers) == 0x48, "Offset mismatch for UGameFeatureAction_AddCheats::SpawnedCheatManagers");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameFeatureAction_AddChunkOverride : public UGameFeatureAction
{
public:
};

static_assert(sizeof(UGameFeatureAction_AddChunkOverride) == 0x28, "Size mismatch for UGameFeatureAction_AddChunkOverride");

// Size: 0x88 (Inherited: 0x50, Single: 0x38)
class UGameFeatureAction_AddComponents : public UGameFeatureAction
{
public:
    TArray<FGameFeatureComponentEntry> ComponentList; // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_38[0x50]; // 0x38 (Size: 0x50, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeatureAction_AddComponents) == 0x88, "Size mismatch for UGameFeatureAction_AddComponents");
static_assert(offsetof(UGameFeatureAction_AddComponents, ComponentList) == 0x28, "Offset mismatch for UGameFeatureAction_AddComponents::ComponentList");

// Size: 0x40 (Inherited: 0x50, Single: 0xfffffff0)
class UGameFeatureAction_AddWorldPartitionContent : public UGameFeatureAction
{
public:
    uint8_t Pad_28[0x10]; // 0x28 (Size: 0x10, Type: PaddingProperty)
    UExternalDataLayerAsset* ExternalDataLayerAsset; // 0x38 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UGameFeatureAction_AddWorldPartitionContent) == 0x40, "Size mismatch for UGameFeatureAction_AddWorldPartitionContent");
static_assert(offsetof(UGameFeatureAction_AddWorldPartitionContent, ExternalDataLayerAsset) == 0x38, "Offset mismatch for UGameFeatureAction_AddWorldPartitionContent::ExternalDataLayerAsset");

// Size: 0x40 (Inherited: 0x50, Single: 0xfffffff0)
class UGameFeatureAction_AddWPContent : public UGameFeatureAction
{
public:
    UContentBundleDescriptor* ContentBundleDescriptor; // 0x28 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_30[0x10]; // 0x30 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeatureAction_AddWPContent) == 0x40, "Size mismatch for UGameFeatureAction_AddWPContent");
static_assert(offsetof(UGameFeatureAction_AddWPContent, ContentBundleDescriptor) == 0x28, "Offset mismatch for UGameFeatureAction_AddWPContent::ContentBundleDescriptor");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UGameFeatureAction_AudioActionBase : public UGameFeatureAction
{
public:
};

static_assert(sizeof(UGameFeatureAction_AudioActionBase) == 0x38, "Size mismatch for UGameFeatureAction_AudioActionBase");

// Size: 0x40 (Inherited: 0x50, Single: 0xfffffff0)
class UGameFeatureAction_DataRegistry : public UGameFeatureAction
{
public:
    TArray<TSoftObjectPtr<UDataRegistry*>> RegistriesToAdd; // 0x28 (Size: 0x10, Type: ArrayProperty)
    bool bPreloadInEditor; // 0x38 (Size: 0x1, Type: BoolProperty)
    bool bPreloadInCommandlets; // 0x39 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3a[0x6]; // 0x3a (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeatureAction_DataRegistry) == 0x40, "Size mismatch for UGameFeatureAction_DataRegistry");
static_assert(offsetof(UGameFeatureAction_DataRegistry, RegistriesToAdd) == 0x28, "Offset mismatch for UGameFeatureAction_DataRegistry::RegistriesToAdd");
static_assert(offsetof(UGameFeatureAction_DataRegistry, bPreloadInEditor) == 0x38, "Offset mismatch for UGameFeatureAction_DataRegistry::bPreloadInEditor");
static_assert(offsetof(UGameFeatureAction_DataRegistry, bPreloadInCommandlets) == 0x39, "Offset mismatch for UGameFeatureAction_DataRegistry::bPreloadInCommandlets");

// Size: 0x40 (Inherited: 0x50, Single: 0xfffffff0)
class UGameFeatureAction_DataRegistrySource : public UGameFeatureAction
{
public:
    TArray<FDataRegistrySourceToAdd> SourcesToAdd; // 0x28 (Size: 0x10, Type: ArrayProperty)
    bool bPreloadInEditor; // 0x38 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_39[0x7]; // 0x39 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeatureAction_DataRegistrySource) == 0x40, "Size mismatch for UGameFeatureAction_DataRegistrySource");
static_assert(offsetof(UGameFeatureAction_DataRegistrySource, SourcesToAdd) == 0x28, "Offset mismatch for UGameFeatureAction_DataRegistrySource::SourcesToAdd");
static_assert(offsetof(UGameFeatureAction_DataRegistrySource, bPreloadInEditor) == 0x38, "Offset mismatch for UGameFeatureAction_DataRegistrySource::bPreloadInEditor");

// Size: 0x50 (Inherited: 0x88, Single: 0xffffffc8)
class UGameFeatureData : public UPrimaryDataAsset
{
public:
    TArray<UGameFeatureAction*> Actions; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FPrimaryAssetTypeInfo> PrimaryAssetTypesToScan; // 0x40 (Size: 0x10, Type: ArrayProperty)

public:
    static void GetPluginName(UGameFeatureData*& const GFD, FString& PluginName); // 0xae6a3e4 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGameFeatureData) == 0x50, "Size mismatch for UGameFeatureData");
static_assert(offsetof(UGameFeatureData, Actions) == 0x30, "Offset mismatch for UGameFeatureData::Actions");
static_assert(offsetof(UGameFeatureData, PrimaryAssetTypesToScan) == 0x40, "Offset mismatch for UGameFeatureData::PrimaryAssetTypesToScan");

// Size: 0x270 (Inherited: 0x28, Single: 0x248)
class UGameFeatureOptionalContentInstaller : public UObject
{
public:
};

static_assert(sizeof(UGameFeatureOptionalContentInstaller) == 0x270, "Size mismatch for UGameFeatureOptionalContentInstaller");

// Size: 0x248 (Inherited: 0x28, Single: 0x220)
class UGameFeaturePluginStateMachine : public UObject
{
public:
    uint8_t Pad_28[0x8]; // 0x28 (Size: 0x8, Type: PaddingProperty)
    FGameFeaturePluginStateMachineProperties StateProperties; // 0x30 (Size: 0xe8, Type: StructProperty)
    uint8_t Pad_118[0x130]; // 0x118 (Size: 0x130, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeaturePluginStateMachine) == 0x248, "Size mismatch for UGameFeaturePluginStateMachine");
static_assert(offsetof(UGameFeaturePluginStateMachine, StateProperties) == 0x30, "Offset mismatch for UGameFeaturePluginStateMachine::StateProperties");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UGameFeaturesProjectPolicies : public UObject
{
public:
};

static_assert(sizeof(UGameFeaturesProjectPolicies) == 0x28, "Size mismatch for UGameFeaturesProjectPolicies");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDefaultGameFeaturesProjectPolicies : public UGameFeaturesProjectPolicies
{
public:
};

static_assert(sizeof(UDefaultGameFeaturesProjectPolicies) == 0x28, "Size mismatch for UDefaultGameFeaturesProjectPolicies");

// Size: 0x1d8 (Inherited: 0xb8, Single: 0x120)
class UGameFeaturesSubsystem : public UEngineSubsystem
{
public:
    TMap<UGameFeaturePluginStateMachine*, FString> GameFeaturePluginStateMachines; // 0x30 (Size: 0x50, Type: MapProperty)
    uint8_t Pad_80[0x70]; // 0x80 (Size: 0x70, Type: PaddingProperty)
    TArray<UGameFeaturePluginStateMachine*> TerminalGameFeaturePluginStateMachines; // 0xf0 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_100[0xa8]; // 0x100 (Size: 0xa8, Type: PaddingProperty)
    TArray<UObject*> Observers; // 0x1a8 (Size: 0x10, Type: ArrayProperty)
    UGameFeaturesProjectPolicies* GameSpecificPolicies; // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_1c0[0x18]; // 0x1c0 (Size: 0x18, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeaturesSubsystem) == 0x1d8, "Size mismatch for UGameFeaturesSubsystem");
static_assert(offsetof(UGameFeaturesSubsystem, GameFeaturePluginStateMachines) == 0x30, "Offset mismatch for UGameFeaturesSubsystem::GameFeaturePluginStateMachines");
static_assert(offsetof(UGameFeaturesSubsystem, TerminalGameFeaturePluginStateMachines) == 0xf0, "Offset mismatch for UGameFeaturesSubsystem::TerminalGameFeaturePluginStateMachines");
static_assert(offsetof(UGameFeaturesSubsystem, Observers) == 0x1a8, "Offset mismatch for UGameFeaturesSubsystem::Observers");
static_assert(offsetof(UGameFeaturesSubsystem, GameSpecificPolicies) == 0x1b8, "Offset mismatch for UGameFeaturesSubsystem::GameSpecificPolicies");

// Size: 0x88 (Inherited: 0x58, Single: 0x30)
class UGameFeaturesSubsystemSettings : public UDeveloperSettings
{
public:
    FSoftClassPath GameFeaturesManagerClassName; // 0x30 (Size: 0x18, Type: StructProperty)
    TArray<FString> EnabledPlugins; // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> DisabledPlugins; // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> AdditionalPluginMetadataKeys; // 0x68 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_78[0x10]; // 0x78 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeaturesSubsystemSettings) == 0x88, "Size mismatch for UGameFeaturesSubsystemSettings");
static_assert(offsetof(UGameFeaturesSubsystemSettings, GameFeaturesManagerClassName) == 0x30, "Offset mismatch for UGameFeaturesSubsystemSettings::GameFeaturesManagerClassName");
static_assert(offsetof(UGameFeaturesSubsystemSettings, EnabledPlugins) == 0x48, "Offset mismatch for UGameFeaturesSubsystemSettings::EnabledPlugins");
static_assert(offsetof(UGameFeaturesSubsystemSettings, DisabledPlugins) == 0x58, "Offset mismatch for UGameFeaturesSubsystemSettings::DisabledPlugins");
static_assert(offsetof(UGameFeaturesSubsystemSettings, AdditionalPluginMetadataKeys) == 0x68, "Offset mismatch for UGameFeaturesSubsystemSettings::AdditionalPluginMetadataKeys");

// Size: 0x48 (Inherited: 0x0, Single: 0x48)
struct FGameFeatureComponentEntry
{
    TSoftClassPtr ActorClass; // 0x0 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr ComponentClass; // 0x20 (Size: 0x20, Type: SoftClassProperty)
    uint8_t bClientComponent : 1; // 0x40:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bServerComponent : 1; // 0x40:1 (Size: 0x1, Type: BoolProperty)
    char AdditionFlags; // 0x41 (Size: 0x1, Type: ByteProperty)
    uint8_t Pad_42[0x6]; // 0x42 (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FGameFeatureComponentEntry) == 0x48, "Size mismatch for FGameFeatureComponentEntry");
static_assert(offsetof(FGameFeatureComponentEntry, ActorClass) == 0x0, "Offset mismatch for FGameFeatureComponentEntry::ActorClass");
static_assert(offsetof(FGameFeatureComponentEntry, ComponentClass) == 0x20, "Offset mismatch for FGameFeatureComponentEntry::ComponentClass");
static_assert(offsetof(FGameFeatureComponentEntry, bClientComponent) == 0x40, "Offset mismatch for FGameFeatureComponentEntry::bClientComponent");
static_assert(offsetof(FGameFeatureComponentEntry, bServerComponent) == 0x40, "Offset mismatch for FGameFeatureComponentEntry::bServerComponent");
static_assert(offsetof(FGameFeatureComponentEntry, AdditionFlags) == 0x41, "Offset mismatch for FGameFeatureComponentEntry::AdditionFlags");

// Size: 0x50 (Inherited: 0x0, Single: 0x50)
struct FDataRegistrySourceToAdd
{
    FName RegistryToAddTo; // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t AssetPriority; // 0x4 (Size: 0x4, Type: IntProperty)
    uint8_t bClientSource : 1; // 0x8:0 (Size: 0x1, Type: BoolProperty)
    uint8_t bServerSource : 1; // 0x8:1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_9[0x7]; // 0x9 (Size: 0x7, Type: PaddingProperty)
    TSoftObjectPtr<UDataTable*> DataTableToAdd; // 0x10 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UCurveTable*> CurveTableToAdd; // 0x30 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(FDataRegistrySourceToAdd) == 0x50, "Size mismatch for FDataRegistrySourceToAdd");
static_assert(offsetof(FDataRegistrySourceToAdd, RegistryToAddTo) == 0x0, "Offset mismatch for FDataRegistrySourceToAdd::RegistryToAddTo");
static_assert(offsetof(FDataRegistrySourceToAdd, AssetPriority) == 0x4, "Offset mismatch for FDataRegistrySourceToAdd::AssetPriority");
static_assert(offsetof(FDataRegistrySourceToAdd, bClientSource) == 0x8, "Offset mismatch for FDataRegistrySourceToAdd::bClientSource");
static_assert(offsetof(FDataRegistrySourceToAdd, bServerSource) == 0x8, "Offset mismatch for FDataRegistrySourceToAdd::bServerSource");
static_assert(offsetof(FDataRegistrySourceToAdd, DataTableToAdd) == 0x10, "Offset mismatch for FDataRegistrySourceToAdd::DataTableToAdd");
static_assert(offsetof(FDataRegistrySourceToAdd, CurveTableToAdd) == 0x30, "Offset mismatch for FDataRegistrySourceToAdd::CurveTableToAdd");

// Size: 0xe8 (Inherited: 0x0, Single: 0xe8)
struct FGameFeaturePluginStateMachineProperties
{
    UGameFeatureData* GameFeatureData; // 0xa8 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_b0[0x38]; // 0xb0 (Size: 0x38, Type: PaddingProperty)
};

static_assert(sizeof(FGameFeaturePluginStateMachineProperties) == 0xe8, "Size mismatch for FGameFeaturePluginStateMachineProperties");
static_assert(offsetof(FGameFeaturePluginStateMachineProperties, GameFeatureData) == 0xa8, "Offset mismatch for FGameFeaturePluginStateMachineProperties::GameFeatureData");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FGameFeaturePluginIdentifier
{
};

static_assert(sizeof(FGameFeaturePluginIdentifier) == 0x28, "Size mismatch for FGameFeaturePluginIdentifier");

// Size: 0xc (Inherited: 0x0, Single: 0xc)
struct FInstallBundlePluginProtocolOptions
{
};

static_assert(sizeof(FInstallBundlePluginProtocolOptions) == 0xc, "Size mismatch for FInstallBundlePluginProtocolOptions");

