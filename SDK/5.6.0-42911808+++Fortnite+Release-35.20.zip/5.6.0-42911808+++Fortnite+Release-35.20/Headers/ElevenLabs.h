/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ElevenLabs
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "DataRegistry.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UElevenLabsFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static void CloseTextToSpeechStream(FElevenLabsTextToSpeechStreamHandle TextToSpeechStream); // 0x114f581c (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void EnqueueTextToSpeech(FElevenLabsTextToSpeechStreamHandle TextToSpeechStream, FString& Text, bool& bFlush); // 0x114f5ac4 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void EnqueueTextToSpeechEnd(FElevenLabsTextToSpeechStreamHandle TextToSpeechStream); // 0x114f5d2c (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static void PlayPCMAudioData(UObject*& WorldContextObject, TArray<char>& PCMAudioData, int64_t& const SampleRate); // 0x114f6d70 (Index: 0x3, Flags: Final|Native|Static|Public|BlueprintCallable)
    static void SetTextToSpeechStreamResultsDelegate(FElevenLabsTextToSpeechStreamHandle TextToSpeechStream, const FDelegate TextToSpeechStreamResultsDelegate); // 0x114f76a0 (Index: 0x4, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UElevenLabsFunctionLibrary) == 0x28, "Size mismatch for UElevenLabsFunctionLibrary");

// Size: 0x50 (Inherited: 0x28, Single: 0x28)
class UElevenLabsSettings : public UObject
{
public:
    FDataRegistryType VoiceRegistryType; // 0x28 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    FString TextToSpeechEndpoint; // 0x30 (Size: 0x10, Type: StrProperty)
    FString Location; // 0x40 (Size: 0x10, Type: StrProperty)

public:
    FString GetEndpointURL() const; // 0x114f5e30 (Index: 0x0, Flags: Final|Native|Public|Const)
    FString GetLocation() const; // 0x114f5e5c (Index: 0x1, Flags: Final|Native|Public|Const)
};

static_assert(sizeof(UElevenLabsSettings) == 0x50, "Size mismatch for UElevenLabsSettings");
static_assert(offsetof(UElevenLabsSettings, VoiceRegistryType) == 0x28, "Offset mismatch for UElevenLabsSettings::VoiceRegistryType");
static_assert(offsetof(UElevenLabsSettings, TextToSpeechEndpoint) == 0x30, "Offset mismatch for UElevenLabsSettings::TextToSpeechEndpoint");
static_assert(offsetof(UElevenLabsSettings, Location) == 0x40, "Offset mismatch for UElevenLabsSettings::Location");

// Size: 0x88 (Inherited: 0xb8, Single: 0xffffffd0)
class UElevenLabsSubsystem : public UEngineSubsystem
{
public:
    FString AnalyticsEventNamespace; // 0x30 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_40[0x48]; // 0x40 (Size: 0x48, Type: PaddingProperty)

public:
    FElevenLabsTextToSpeechStreamHandle CreateTextToSpeechStream(const FElevenLabsTextToSpeechStreamParams Params, USoundWaveProcedural*& OutSoundWave); // 0x114f5920 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    bool GetRegisteredVoice(const FDataRegistryId VoiceName, FElevenLabsVoice& OutVoice) const; // 0x114f5e88 (Index: 0x1, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)
    int32_t GetSampleRateValue(EElevenLabsAudioFormat& AudioFormat) const; // 0x114f608c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    USoundWaveProcedural* MakeProceduralSoundWaveFromPcmData(const TArray<char> PcmData, EElevenLabsAudioFormat& Format, UObject*& Outer); // 0x114f61b4 (Index: 0x3, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    USoundWave* MakeSoundWaveAssetFromPcmData(const TArray<char> PcmData, FString& AssetPath, FString& AssetName, EElevenLabsAudioFormat& Format); // 0x114f6514 (Index: 0x4, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    USoundWave* MakeSoundWaveFromPcmData(const TArray<char> PcmData, EElevenLabsAudioFormat& Format, UObject*& Outer); // 0x114f6a10 (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
    FElevenLabsTextToSpeechRequestHandle RequestTextToSpeech(FString& Text, const FElevenLabsTextToSpeechRequestParams Params, const FDelegate RequestCompleteDelegate); // 0x114f7230 (Index: 0x6, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UElevenLabsSubsystem) == 0x88, "Size mismatch for UElevenLabsSubsystem");
static_assert(offsetof(UElevenLabsSubsystem, AnalyticsEventNamespace) == 0x30, "Offset mismatch for UElevenLabsSubsystem::AnalyticsEventNamespace");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FElevenLabsTextToSpeechResult
{
    FGuid RequestID; // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<char> PCMAudioData; // 0x10 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FElevenLabsTextToSpeechResult) == 0x20, "Size mismatch for FElevenLabsTextToSpeechResult");
static_assert(offsetof(FElevenLabsTextToSpeechResult, RequestID) == 0x0, "Offset mismatch for FElevenLabsTextToSpeechResult::RequestID");
static_assert(offsetof(FElevenLabsTextToSpeechResult, PCMAudioData) == 0x10, "Offset mismatch for FElevenLabsTextToSpeechResult::PCMAudioData");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FElevenLabsTextToSpeechStreamHandle
{
};

static_assert(sizeof(FElevenLabsTextToSpeechStreamHandle) == 0x10, "Size mismatch for FElevenLabsTextToSpeechStreamHandle");

// Size: 0x14 (Inherited: 0x0, Single: 0x14)
struct FElevenLabsVoiceSettings
{
    float Stability; // 0x0 (Size: 0x4, Type: FloatProperty)
    float SimilarityBoost; // 0x4 (Size: 0x4, Type: FloatProperty)
    float Style; // 0x8 (Size: 0x4, Type: FloatProperty)
    float Speed; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bUseSpearkerBoost; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_11[0x3]; // 0x11 (Size: 0x3, Type: PaddingProperty)
};

static_assert(sizeof(FElevenLabsVoiceSettings) == 0x14, "Size mismatch for FElevenLabsVoiceSettings");
static_assert(offsetof(FElevenLabsVoiceSettings, Stability) == 0x0, "Offset mismatch for FElevenLabsVoiceSettings::Stability");
static_assert(offsetof(FElevenLabsVoiceSettings, SimilarityBoost) == 0x4, "Offset mismatch for FElevenLabsVoiceSettings::SimilarityBoost");
static_assert(offsetof(FElevenLabsVoiceSettings, Style) == 0x8, "Offset mismatch for FElevenLabsVoiceSettings::Style");
static_assert(offsetof(FElevenLabsVoiceSettings, Speed) == 0xc, "Offset mismatch for FElevenLabsVoiceSettings::Speed");
static_assert(offsetof(FElevenLabsVoiceSettings, bUseSpearkerBoost) == 0x10, "Offset mismatch for FElevenLabsVoiceSettings::bUseSpearkerBoost");

// Size: 0x38 (Inherited: 0x8, Single: 0x30)
struct FElevenLabsVoice : FTableRowBase
{
    FString VoiceId; // 0x8 (Size: 0x10, Type: StrProperty)
    FElevenLabsVoiceSettings VoiceSettings; // 0x18 (Size: 0x14, Type: StructProperty)
    float PlaybackVolumeMultiplier; // 0x2c (Size: 0x4, Type: FloatProperty)
    float PlaybackPitch; // 0x30 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_34[0x4]; // 0x34 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FElevenLabsVoice) == 0x38, "Size mismatch for FElevenLabsVoice");
static_assert(offsetof(FElevenLabsVoice, VoiceId) == 0x8, "Offset mismatch for FElevenLabsVoice::VoiceId");
static_assert(offsetof(FElevenLabsVoice, VoiceSettings) == 0x18, "Offset mismatch for FElevenLabsVoice::VoiceSettings");
static_assert(offsetof(FElevenLabsVoice, PlaybackVolumeMultiplier) == 0x2c, "Offset mismatch for FElevenLabsVoice::PlaybackVolumeMultiplier");
static_assert(offsetof(FElevenLabsVoice, PlaybackPitch) == 0x30, "Offset mismatch for FElevenLabsVoice::PlaybackPitch");

// Size: 0x60 (Inherited: 0x0, Single: 0x60)
struct FElevenLabsTextToSpeechRequestParams
{
    FGuid RequestID; // 0x0 (Size: 0x10, Type: StructProperty)
    uint8_t Model; // 0x10 (Size: 0x1, Type: EnumProperty)
    uint8_t OutputFormat; // 0x11 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
    FElevenLabsVoice Voice; // 0x18 (Size: 0x38, Type: StructProperty)
    FGuid AnalyticsEventGroupID; // 0x50 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FElevenLabsTextToSpeechRequestParams) == 0x60, "Size mismatch for FElevenLabsTextToSpeechRequestParams");
static_assert(offsetof(FElevenLabsTextToSpeechRequestParams, RequestID) == 0x0, "Offset mismatch for FElevenLabsTextToSpeechRequestParams::RequestID");
static_assert(offsetof(FElevenLabsTextToSpeechRequestParams, Model) == 0x10, "Offset mismatch for FElevenLabsTextToSpeechRequestParams::Model");
static_assert(offsetof(FElevenLabsTextToSpeechRequestParams, OutputFormat) == 0x11, "Offset mismatch for FElevenLabsTextToSpeechRequestParams::OutputFormat");
static_assert(offsetof(FElevenLabsTextToSpeechRequestParams, Voice) == 0x18, "Offset mismatch for FElevenLabsTextToSpeechRequestParams::Voice");
static_assert(offsetof(FElevenLabsTextToSpeechRequestParams, AnalyticsEventGroupID) == 0x50, "Offset mismatch for FElevenLabsTextToSpeechRequestParams::AnalyticsEventGroupID");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FElevenLabsTextToSpeechRequestHandle
{
};

static_assert(sizeof(FElevenLabsTextToSpeechRequestHandle) == 0x10, "Size mismatch for FElevenLabsTextToSpeechRequestHandle");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FElevenLabsStreamGenerationConfig
{
    bool bAutoMode; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x7]; // 0x1 (Size: 0x7, Type: PaddingProperty)
    TArray<int32_t> ChunkLengthSchedule; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FElevenLabsStreamGenerationConfig) == 0x18, "Size mismatch for FElevenLabsStreamGenerationConfig");
static_assert(offsetof(FElevenLabsStreamGenerationConfig, bAutoMode) == 0x0, "Offset mismatch for FElevenLabsStreamGenerationConfig::bAutoMode");
static_assert(offsetof(FElevenLabsStreamGenerationConfig, ChunkLengthSchedule) == 0x8, "Offset mismatch for FElevenLabsStreamGenerationConfig::ChunkLengthSchedule");

// Size: 0x78 (Inherited: 0x60, Single: 0x18)
struct FElevenLabsTextToSpeechStreamParams : FElevenLabsTextToSpeechRequestParams
{
    FElevenLabsStreamGenerationConfig GenerationConfig; // 0x60 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FElevenLabsTextToSpeechStreamParams) == 0x78, "Size mismatch for FElevenLabsTextToSpeechStreamParams");
static_assert(offsetof(FElevenLabsTextToSpeechStreamParams, GenerationConfig) == 0x60, "Offset mismatch for FElevenLabsTextToSpeechStreamParams::GenerationConfig");

