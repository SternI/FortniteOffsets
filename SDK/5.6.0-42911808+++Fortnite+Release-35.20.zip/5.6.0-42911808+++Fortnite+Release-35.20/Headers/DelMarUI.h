/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CommonUI.h"
#include "UMG.h"
#include "DynamicUI.h"
#include "CoreUObject.h"
#include "ModelViewViewModel.h"
#include "FortniteUI.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "ModularGameplay.h"
#include "UIChart.h"
#include "CommonInput.h"
#include "GameplayTags.h"
#include "InputCore.h"
#include "DelMarCore.h"
#include "SlateCore.h"
#include "EnhancedInput.h"
#include "Slate.h"

// Size: 0x390 (Inherited: 0xa80, Single: 0xfffff910)
class UDelMarCountdownTimerWidget : public UDelMarUserWidget
{
public:
    UTextBlock* TextBlock_RemainingTime; // 0x350 (Size: 0x8, Type: ObjectProperty)
    double InitialCoundownTime; // 0x358 (Size: 0x8, Type: DoubleProperty)
    uint8_t OnCountdownTimeChanged[0x10]; // 0x360 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCountdownTimeSet[0x10]; // 0x370 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnCountdownTimeEnded[0x10]; // 0x380 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    double GetTimeRemainingSeconds() const; // 0x11d408c8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetInitialCountdownTime(double& InTime); // 0x11d413d0 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarCountdownTimerWidget) == 0x390, "Size mismatch for UDelMarCountdownTimerWidget");
static_assert(offsetof(UDelMarCountdownTimerWidget, TextBlock_RemainingTime) == 0x350, "Offset mismatch for UDelMarCountdownTimerWidget::TextBlock_RemainingTime");
static_assert(offsetof(UDelMarCountdownTimerWidget, InitialCoundownTime) == 0x358, "Offset mismatch for UDelMarCountdownTimerWidget::InitialCoundownTime");
static_assert(offsetof(UDelMarCountdownTimerWidget, OnCountdownTimeChanged) == 0x360, "Offset mismatch for UDelMarCountdownTimerWidget::OnCountdownTimeChanged");
static_assert(offsetof(UDelMarCountdownTimerWidget, OnCountdownTimeSet) == 0x370, "Offset mismatch for UDelMarCountdownTimerWidget::OnCountdownTimeSet");
static_assert(offsetof(UDelMarCountdownTimerWidget, OnCountdownTimeEnded) == 0x380, "Offset mismatch for UDelMarCountdownTimerWidget::OnCountdownTimeEnded");

// Size: 0x350 (Inherited: 0x730, Single: 0xfffffc20)
class UDelMarUserWidget : public UCommonUserWidget
{
public:
    uint8_t Pad_2d8[0x58]; // 0x2d8 (Size: 0x58, Type: PaddingProperty)
    uint8_t InitialTransitionStatus; // 0x330 (Size: 0x1, Type: EnumProperty)
    uint8_t HiddenVisibility; // 0x331 (Size: 0x1, Type: EnumProperty)
    bool bAlwaysReverseInterruptedAnimations; // 0x332 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_333[0x5]; // 0x333 (Size: 0x5, Type: PaddingProperty)
    UWidgetTransitioner* WidgetTransitioner; // 0x338 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* NormalTransitionIn; // 0x340 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* NormalTransitionOut; // 0x348 (Size: 0x8, Type: ObjectProperty)

public:
    void BP_Hide(bool& bSkipAnimation); // 0x11dc02a0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void BP_Show(bool& bSkipAnimation); // 0x11dc053c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    UUIStateChartManager* GetUIStateChartManager(); // 0x11d4dfd8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    UWidgetTransitioner* GetWidgetTransitioner() const; // 0xd018788 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void HandleWidgetTransitionerStatusChanged(UWidgetTransitioner*& InTransitioner, EWidgetTransitionerStatus& InStatus); // 0x11dc2fb8 (Index: 0x4, Flags: Final|Native|Protected)
    bool IsDisplayEnabled() const; // 0xe55ee18 (Index: 0x5, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void SetDisplayEnabled(bool& bEnabled, bool& bSkipAnimation); // 0x11dc3964 (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarUserWidget) == 0x350, "Size mismatch for UDelMarUserWidget");
static_assert(offsetof(UDelMarUserWidget, InitialTransitionStatus) == 0x330, "Offset mismatch for UDelMarUserWidget::InitialTransitionStatus");
static_assert(offsetof(UDelMarUserWidget, HiddenVisibility) == 0x331, "Offset mismatch for UDelMarUserWidget::HiddenVisibility");
static_assert(offsetof(UDelMarUserWidget, bAlwaysReverseInterruptedAnimations) == 0x332, "Offset mismatch for UDelMarUserWidget::bAlwaysReverseInterruptedAnimations");
static_assert(offsetof(UDelMarUserWidget, WidgetTransitioner) == 0x338, "Offset mismatch for UDelMarUserWidget::WidgetTransitioner");
static_assert(offsetof(UDelMarUserWidget, NormalTransitionIn) == 0x340, "Offset mismatch for UDelMarUserWidget::NormalTransitionIn");
static_assert(offsetof(UDelMarUserWidget, NormalTransitionOut) == 0x348, "Offset mismatch for UDelMarUserWidget::NormalTransitionOut");

// Size: 0x2e0 (Inherited: 0x598, Single: 0xfffffd48)
class ADelMarCreativeUIDirector : public ADynamicUIDirectorBase
{
public:
    ADelMarVehicle* CachedDelMarVehicle; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* CreativeDelMarUI; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag VehicleInAirTag; // 0x2d8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2dc[0x4]; // 0x2dc (Size: 0x4, Type: PaddingProperty)

private:
    void OnVehicleAnyWheelsOnGroundChanged(const TScriptInterface<Class> VehicleRef, bool& bAnyWheelsOnGround); // 0x11d41204 (Index: 0x0, Flags: Final|Native|Private|HasOutParms)
    void OnVehicleEnter(); // 0x11d4135c (Index: 0x1, Flags: Final|Native|Private)
    void OnVehicleExit(); // 0x11d41370 (Index: 0x2, Flags: Final|Native|Private)
};

static_assert(sizeof(ADelMarCreativeUIDirector) == 0x2e0, "Size mismatch for ADelMarCreativeUIDirector");
static_assert(offsetof(ADelMarCreativeUIDirector, CachedDelMarVehicle) == 0x2c8, "Offset mismatch for ADelMarCreativeUIDirector::CachedDelMarVehicle");
static_assert(offsetof(ADelMarCreativeUIDirector, CreativeDelMarUI) == 0x2d0, "Offset mismatch for ADelMarCreativeUIDirector::CreativeDelMarUI");
static_assert(offsetof(ADelMarCreativeUIDirector, VehicleInAirTag) == 0x2d8, "Offset mismatch for ADelMarCreativeUIDirector::VehicleInAirTag");

// Size: 0x478 (Inherited: 0xa80, Single: 0xfffff9f8)
class UDelMarDriverCameraWidget : public UDelMarUserWidget
{
public:
    UWidgetAnimation* DefaultIntercomAnimation; // 0x350 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ReactiveDriverCamera_Persistent; // 0x358 (Size: 0x8, Type: ObjectProperty)
    float ReactiveWidgetOutroDelay; // 0x360 (Size: 0x4, Type: FloatProperty)
    float ReactiveWidgetMaxActiveTime; // 0x364 (Size: 0x4, Type: FloatProperty)
    TMap<FName, FGameplayTag> MainChannelAnimationTagTable; // 0x368 (Size: 0x50, Type: MapProperty)
    TMap<FDelMarReactiveWidgetAnimation, int32_t> ReactiveAnimationTable; // 0x3b8 (Size: 0x50, Type: MapProperty)
    TMap<UWidgetAnimation*, FName> AnimationNameTable; // 0x408 (Size: 0x50, Type: MapProperty)
    UUMGSequencePlayer* IntercomSequencePlayer; // 0x458 (Size: 0x8, Type: ObjectProperty)
    UUMGSequencePlayer* ReactiveSequencePlayer; // 0x460 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_468[0x10]; // 0x468 (Size: 0x10, Type: PaddingProperty)

protected:
    TArray<FName> GetAnimationNames() const; // 0x11d406c8 (Index: 0x0, Flags: Final|Native|Protected|Const)
};

static_assert(sizeof(UDelMarDriverCameraWidget) == 0x478, "Size mismatch for UDelMarDriverCameraWidget");
static_assert(offsetof(UDelMarDriverCameraWidget, DefaultIntercomAnimation) == 0x350, "Offset mismatch for UDelMarDriverCameraWidget::DefaultIntercomAnimation");
static_assert(offsetof(UDelMarDriverCameraWidget, ReactiveDriverCamera_Persistent) == 0x358, "Offset mismatch for UDelMarDriverCameraWidget::ReactiveDriverCamera_Persistent");
static_assert(offsetof(UDelMarDriverCameraWidget, ReactiveWidgetOutroDelay) == 0x360, "Offset mismatch for UDelMarDriverCameraWidget::ReactiveWidgetOutroDelay");
static_assert(offsetof(UDelMarDriverCameraWidget, ReactiveWidgetMaxActiveTime) == 0x364, "Offset mismatch for UDelMarDriverCameraWidget::ReactiveWidgetMaxActiveTime");
static_assert(offsetof(UDelMarDriverCameraWidget, MainChannelAnimationTagTable) == 0x368, "Offset mismatch for UDelMarDriverCameraWidget::MainChannelAnimationTagTable");
static_assert(offsetof(UDelMarDriverCameraWidget, ReactiveAnimationTable) == 0x3b8, "Offset mismatch for UDelMarDriverCameraWidget::ReactiveAnimationTable");
static_assert(offsetof(UDelMarDriverCameraWidget, AnimationNameTable) == 0x408, "Offset mismatch for UDelMarDriverCameraWidget::AnimationNameTable");
static_assert(offsetof(UDelMarDriverCameraWidget, IntercomSequencePlayer) == 0x458, "Offset mismatch for UDelMarDriverCameraWidget::IntercomSequencePlayer");
static_assert(offsetof(UDelMarDriverCameraWidget, ReactiveSequencePlayer) == 0x460, "Offset mismatch for UDelMarDriverCameraWidget::ReactiveSequencePlayer");

// Size: 0x130 (Inherited: 0x50, Single: 0xe0)
class UDelMarInputActionRichTextBlockDecorator : public URichTextBlockDecorator
{
public:
    UInputAction* InputAction; // 0x28 (Size: 0x8, Type: ObjectProperty)
    FText DisplayName; // 0x30 (Size: 0x10, Type: TextProperty)
    FKey Key; // 0x40 (Size: 0x18, Type: StructProperty)
    uint8_t Pad_58[0x8]; // 0x58 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush Icon; // 0x60 (Size: 0xb0, Type: StructProperty)
    URichTextBlock* OwnerWidget; // 0x110 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ULocalPlayer*> OwningLocalPlayer; // 0x118 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UCommonInputSubsystem*> CommonInputSubsystem; // 0x120 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UEnhancedInputLocalPlayerSubsystem*> EnhancedInputSubsystem; // 0x128 (Size: 0x8, Type: WeakObjectProperty)
};

static_assert(sizeof(UDelMarInputActionRichTextBlockDecorator) == 0x130, "Size mismatch for UDelMarInputActionRichTextBlockDecorator");
static_assert(offsetof(UDelMarInputActionRichTextBlockDecorator, InputAction) == 0x28, "Offset mismatch for UDelMarInputActionRichTextBlockDecorator::InputAction");
static_assert(offsetof(UDelMarInputActionRichTextBlockDecorator, DisplayName) == 0x30, "Offset mismatch for UDelMarInputActionRichTextBlockDecorator::DisplayName");
static_assert(offsetof(UDelMarInputActionRichTextBlockDecorator, Key) == 0x40, "Offset mismatch for UDelMarInputActionRichTextBlockDecorator::Key");
static_assert(offsetof(UDelMarInputActionRichTextBlockDecorator, Icon) == 0x60, "Offset mismatch for UDelMarInputActionRichTextBlockDecorator::Icon");
static_assert(offsetof(UDelMarInputActionRichTextBlockDecorator, OwnerWidget) == 0x110, "Offset mismatch for UDelMarInputActionRichTextBlockDecorator::OwnerWidget");
static_assert(offsetof(UDelMarInputActionRichTextBlockDecorator, OwningLocalPlayer) == 0x118, "Offset mismatch for UDelMarInputActionRichTextBlockDecorator::OwningLocalPlayer");
static_assert(offsetof(UDelMarInputActionRichTextBlockDecorator, CommonInputSubsystem) == 0x120, "Offset mismatch for UDelMarInputActionRichTextBlockDecorator::CommonInputSubsystem");
static_assert(offsetof(UDelMarInputActionRichTextBlockDecorator, EnhancedInputSubsystem) == 0x128, "Offset mismatch for UDelMarInputActionRichTextBlockDecorator::EnhancedInputSubsystem");

// Size: 0xb80 (Inherited: 0x1af8, Single: 0xfffff088)
class UDelMarListView : public UCommonListView
{
public:
    uint8_t Pad_b60[0x10]; // 0xb60 (Size: 0x10, Type: PaddingProperty)
    bool bTreatNavigationAsScrolling; // 0xb70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_b71[0xf]; // 0xb71 (Size: 0xf, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarListView) == 0xb80, "Size mismatch for UDelMarListView");
static_assert(offsetof(UDelMarListView, bTreatNavigationAsScrolling) == 0xb70, "Offset mismatch for UDelMarListView::bTreatNavigationAsScrolling");

// Size: 0x78 (Inherited: 0x90, Single: 0xffffffe8)
class UDelMarListViewModel : public UMVVMViewModelBase
{
public:
    TArray<UMVVMViewModelBase*> Elements; // 0x68 (Size: 0x10, Type: ArrayProperty)

public:
    UMVVMViewModelBase* GetElementAt(int32_t& InIndex) const; // 0x11d40708 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    TArray<UMVVMViewModelBase*> GetElements() const; // 0x11d40840 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarListViewModel) == 0x78, "Size mismatch for UDelMarListViewModel");
static_assert(offsetof(UDelMarListViewModel, Elements) == 0x68, "Offset mismatch for UDelMarListViewModel::Elements");

// Size: 0x80 (Inherited: 0x170, Single: 0xffffff10)
class UDelMarMatchEventViewModel : public UDelMarViewModelBase
{
public:
    uint8_t OnMatchEventOccured[0x10]; // 0x70 (Size: 0x10, Type: MulticastInlineDelegateProperty)

public:
    void OnMatchEventOccured__DelegateSignature(AFortPlayerState*& PlayerState, FGameplayTag& EventTag, FString& Context); // 0x288a61c (Index: 0x0, Flags: MulticastDelegate|Public|Delegate)
};

static_assert(sizeof(UDelMarMatchEventViewModel) == 0x80, "Size mismatch for UDelMarMatchEventViewModel");
static_assert(offsetof(UDelMarMatchEventViewModel, OnMatchEventOccured) == 0x70, "Offset mismatch for UDelMarMatchEventViewModel::OnMatchEventOccured");

// Size: 0x70 (Inherited: 0x100, Single: 0xffffff70)
class UDelMarViewModelBase : public UFortPerUserViewModel
{
public:
};

static_assert(sizeof(UDelMarViewModelBase) == 0x70, "Size mismatch for UDelMarViewModelBase");

// Size: 0x4a8 (Inherited: 0xa80, Single: 0xfffffa28)
class UDelMarPlayerIndicatorsContainer : public UDelMarUserWidget
{
public:
    UCanvasPanel* IndicatorCanvas; // 0x350 (Size: 0x8, Type: ObjectProperty)
    UClass* IndicatorWidgetClass; // 0x358 (Size: 0x8, Type: ClassProperty)
    FVector IndicatorOffset; // 0x360 (Size: 0x18, Type: StructProperty)
    float RearVerticalHintThreshold; // 0x378 (Size: 0x4, Type: FloatProperty)
    float RearIndicatorMaxDistance; // 0x37c (Size: 0x4, Type: FloatProperty)
    float RearIndicatorMinDistance; // 0x380 (Size: 0x4, Type: FloatProperty)
    float RearIndicatorRangeWidth; // 0x384 (Size: 0x4, Type: FloatProperty)
    float RearIndicatorRangeDegree; // 0x388 (Size: 0x4, Type: FloatProperty)
    float ForwardIndicatorMaxDistance; // 0x38c (Size: 0x4, Type: FloatProperty)
    FAnchors IndicatorAnchors; // 0x390 (Size: 0x20, Type: StructProperty)
    FVector2D IndicatorAlignment; // 0x3b0 (Size: 0x10, Type: StructProperty)
    FVector2D RearIndicatorSize; // 0x3c0 (Size: 0x10, Type: StructProperty)
    UCurveFloat* RearDistanceScaleCurve; // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* RearDistanceOpacityCurve; // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* ForwardDistanceScaleCurve; // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* ForwardDistanceOpacityCurve; // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    int32_t MaxRearIndicators; // 0x3f0 (Size: 0x4, Type: IntProperty)
    int32_t MaxForwardIndicators; // 0x3f4 (Size: 0x4, Type: IntProperty)
    TWeakObjectPtr<UDelMarVehicleManager*> VehicleManager; // 0x3f8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> ViewingVehicle; // 0x400 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> ViewingPlayerState; // 0x408 (Size: 0x8, Type: WeakObjectProperty)
    TArray<FDelMarPlayerIndicatorData> IndicatorsData; // 0x410 (Size: 0x10, Type: ArrayProperty)
    TMap<UDelMarPlayerIndicatorWidget*, AFortPlayerState*> IndicatorWidgets; // 0x420 (Size: 0x50, Type: MapProperty)
    TArray<UDelMarPlayerIndicatorWidget*> IndicatorPool; // 0x470 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> PositionalTrackerComponent; // 0x480 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_488[0x20]; // 0x488 (Size: 0x20, Type: PaddingProperty)

protected:
    void HandleIconOnlySettingChanged(bool& bUseIconOnly); // 0x11d40904 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleRacePlayersChanged(const TMap<UDelMarPlayerViewModel*, int32_t> RacePlayers); // 0x11d40a44 (Index: 0x1, Flags: Final|Native|Protected|HasOutParms|BlueprintCallable)
    void HandleViewTargetChanged(AFortPlayerController*& InController, AActor*& OldViewTarget, AActor*& NewViewTarget); // 0x11d40b6c (Index: 0x2, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerIndicatorsContainer) == 0x4a8, "Size mismatch for UDelMarPlayerIndicatorsContainer");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, IndicatorCanvas) == 0x350, "Offset mismatch for UDelMarPlayerIndicatorsContainer::IndicatorCanvas");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, IndicatorWidgetClass) == 0x358, "Offset mismatch for UDelMarPlayerIndicatorsContainer::IndicatorWidgetClass");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, IndicatorOffset) == 0x360, "Offset mismatch for UDelMarPlayerIndicatorsContainer::IndicatorOffset");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, RearVerticalHintThreshold) == 0x378, "Offset mismatch for UDelMarPlayerIndicatorsContainer::RearVerticalHintThreshold");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, RearIndicatorMaxDistance) == 0x37c, "Offset mismatch for UDelMarPlayerIndicatorsContainer::RearIndicatorMaxDistance");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, RearIndicatorMinDistance) == 0x380, "Offset mismatch for UDelMarPlayerIndicatorsContainer::RearIndicatorMinDistance");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, RearIndicatorRangeWidth) == 0x384, "Offset mismatch for UDelMarPlayerIndicatorsContainer::RearIndicatorRangeWidth");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, RearIndicatorRangeDegree) == 0x388, "Offset mismatch for UDelMarPlayerIndicatorsContainer::RearIndicatorRangeDegree");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, ForwardIndicatorMaxDistance) == 0x38c, "Offset mismatch for UDelMarPlayerIndicatorsContainer::ForwardIndicatorMaxDistance");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, IndicatorAnchors) == 0x390, "Offset mismatch for UDelMarPlayerIndicatorsContainer::IndicatorAnchors");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, IndicatorAlignment) == 0x3b0, "Offset mismatch for UDelMarPlayerIndicatorsContainer::IndicatorAlignment");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, RearIndicatorSize) == 0x3c0, "Offset mismatch for UDelMarPlayerIndicatorsContainer::RearIndicatorSize");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, RearDistanceScaleCurve) == 0x3d0, "Offset mismatch for UDelMarPlayerIndicatorsContainer::RearDistanceScaleCurve");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, RearDistanceOpacityCurve) == 0x3d8, "Offset mismatch for UDelMarPlayerIndicatorsContainer::RearDistanceOpacityCurve");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, ForwardDistanceScaleCurve) == 0x3e0, "Offset mismatch for UDelMarPlayerIndicatorsContainer::ForwardDistanceScaleCurve");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, ForwardDistanceOpacityCurve) == 0x3e8, "Offset mismatch for UDelMarPlayerIndicatorsContainer::ForwardDistanceOpacityCurve");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, MaxRearIndicators) == 0x3f0, "Offset mismatch for UDelMarPlayerIndicatorsContainer::MaxRearIndicators");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, MaxForwardIndicators) == 0x3f4, "Offset mismatch for UDelMarPlayerIndicatorsContainer::MaxForwardIndicators");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, VehicleManager) == 0x3f8, "Offset mismatch for UDelMarPlayerIndicatorsContainer::VehicleManager");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, ViewingVehicle) == 0x400, "Offset mismatch for UDelMarPlayerIndicatorsContainer::ViewingVehicle");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, ViewingPlayerState) == 0x408, "Offset mismatch for UDelMarPlayerIndicatorsContainer::ViewingPlayerState");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, IndicatorsData) == 0x410, "Offset mismatch for UDelMarPlayerIndicatorsContainer::IndicatorsData");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, IndicatorWidgets) == 0x420, "Offset mismatch for UDelMarPlayerIndicatorsContainer::IndicatorWidgets");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, IndicatorPool) == 0x470, "Offset mismatch for UDelMarPlayerIndicatorsContainer::IndicatorPool");
static_assert(offsetof(UDelMarPlayerIndicatorsContainer, PositionalTrackerComponent) == 0x480, "Offset mismatch for UDelMarPlayerIndicatorsContainer::PositionalTrackerComponent");

// Size: 0x308 (Inherited: 0x458, Single: 0xfffffeb0)
class UDelMarPlayerIndicatorWidget : public UUserWidget
{
public:
    uint8_t Pad_2b0[0x8]; // 0x2b0 (Size: 0x8, Type: PaddingProperty)
    USizeBox* AvatarSizeBox; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UFortLazyImage* AvatarLazyImage; // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    USizeBox* PlayerNameSizeBox; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UImage* UpArrowImage; // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UImage* DownArrowImage; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UOverlay* BackgroundOverlay; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2e8[0x4]; // 0x2e8 (Size: 0x4, Type: PaddingProperty)
    float BehindAvatarSizeBoxWidth; // 0x2ec (Size: 0x4, Type: FloatProperty)
    float AheadAvatarSizeBoxWidth; // 0x2f0 (Size: 0x4, Type: FloatProperty)
    bool bBehindAvatarImageIsExpanded; // 0x2f4 (Size: 0x1, Type: BoolProperty)
    bool bAheadAvatarImageIsExpanded; // 0x2f5 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2f6[0x2]; // 0x2f6 (Size: 0x2, Type: PaddingProperty)
    float BehindPlayerNameSizeBoxMaxWidth; // 0x2f8 (Size: 0x4, Type: FloatProperty)
    float AheadPlayerNameSizeBoxMaxWidth; // 0x2fc (Size: 0x4, Type: FloatProperty)
    float BehindBackgroundOverlaySlotPadding; // 0x300 (Size: 0x4, Type: FloatProperty)
    float AheadBackgroundOverlaySlotPadding; // 0x304 (Size: 0x4, Type: FloatProperty)

public:
    virtual void BP_HideIndicator(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void BP_SetViewModel(UDelMarPlayerViewModel*& ViewModel); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void BP_UpdateIndicator(float& Scale, float& Opacity, bool& bRearIndicator, EDelMarRearAlertVerticalHint& VerticalHint); // 0x11d402dc (Index: 0x2, Flags: Native|Event|Public|BlueprintEvent)
};

static_assert(sizeof(UDelMarPlayerIndicatorWidget) == 0x308, "Size mismatch for UDelMarPlayerIndicatorWidget");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, AvatarSizeBox) == 0x2b8, "Offset mismatch for UDelMarPlayerIndicatorWidget::AvatarSizeBox");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, AvatarLazyImage) == 0x2c0, "Offset mismatch for UDelMarPlayerIndicatorWidget::AvatarLazyImage");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, PlayerNameSizeBox) == 0x2c8, "Offset mismatch for UDelMarPlayerIndicatorWidget::PlayerNameSizeBox");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, UpArrowImage) == 0x2d0, "Offset mismatch for UDelMarPlayerIndicatorWidget::UpArrowImage");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, DownArrowImage) == 0x2d8, "Offset mismatch for UDelMarPlayerIndicatorWidget::DownArrowImage");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, BackgroundOverlay) == 0x2e0, "Offset mismatch for UDelMarPlayerIndicatorWidget::BackgroundOverlay");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, BehindAvatarSizeBoxWidth) == 0x2ec, "Offset mismatch for UDelMarPlayerIndicatorWidget::BehindAvatarSizeBoxWidth");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, AheadAvatarSizeBoxWidth) == 0x2f0, "Offset mismatch for UDelMarPlayerIndicatorWidget::AheadAvatarSizeBoxWidth");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, bBehindAvatarImageIsExpanded) == 0x2f4, "Offset mismatch for UDelMarPlayerIndicatorWidget::bBehindAvatarImageIsExpanded");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, bAheadAvatarImageIsExpanded) == 0x2f5, "Offset mismatch for UDelMarPlayerIndicatorWidget::bAheadAvatarImageIsExpanded");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, BehindPlayerNameSizeBoxMaxWidth) == 0x2f8, "Offset mismatch for UDelMarPlayerIndicatorWidget::BehindPlayerNameSizeBoxMaxWidth");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, AheadPlayerNameSizeBoxMaxWidth) == 0x2fc, "Offset mismatch for UDelMarPlayerIndicatorWidget::AheadPlayerNameSizeBoxMaxWidth");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, BehindBackgroundOverlaySlotPadding) == 0x300, "Offset mismatch for UDelMarPlayerIndicatorWidget::BehindBackgroundOverlaySlotPadding");
static_assert(offsetof(UDelMarPlayerIndicatorWidget, AheadBackgroundOverlaySlotPadding) == 0x304, "Offset mismatch for UDelMarPlayerIndicatorWidget::AheadBackgroundOverlaySlotPadding");

// Size: 0x428 (Inherited: 0xe88, Single: 0xfffff5a0)
class UDelMarPositionalTrackerWidget : public UDelMarExpandableHudWidget
{
public:
    int32_t MinPlayersToStart; // 0x408 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_40c[0x4]; // 0x40c (Size: 0x4, Type: PaddingProperty)
    TArray<UDelMarPlayerViewModel*> DisplayedPlayers; // 0x410 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_420[0x8]; // 0x420 (Size: 0x8, Type: PaddingProperty)

protected:
    virtual void OnInputMethodChanged(ECommonInputType& InputMethod); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    void UpdatePlayerPositions(TArray<UDelMarPlayerViewModel*>& InPlayers); // 0x11d419b0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarPositionalTrackerWidget) == 0x428, "Size mismatch for UDelMarPositionalTrackerWidget");
static_assert(offsetof(UDelMarPositionalTrackerWidget, MinPlayersToStart) == 0x408, "Offset mismatch for UDelMarPositionalTrackerWidget::MinPlayersToStart");
static_assert(offsetof(UDelMarPositionalTrackerWidget, DisplayedPlayers) == 0x410, "Offset mismatch for UDelMarPositionalTrackerWidget::DisplayedPlayers");

// Size: 0x408 (Inherited: 0xa80, Single: 0xfffff988)
class UDelMarExpandableHudWidget : public UDelMarUserWidget
{
public:
    UImage* NavigateEntriesBindingImage; // 0x350 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_358[0x18]; // 0x358 (Size: 0x18, Type: PaddingProperty)
    UClass* ExpandableHudWidgetEntryClass; // 0x370 (Size: 0x8, Type: ClassProperty)
    int32_t NumDesignerPreviewEntries; // 0x378 (Size: 0x4, Type: IntProperty)
    float EntrySpacing; // 0x37c (Size: 0x4, Type: FloatProperty)
    bool bExpanded; // 0x380 (Size: 0x1, Type: BoolProperty)
    bool bNavigationEnabled; // 0x381 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_382[0x6]; // 0x382 (Size: 0x6, Type: PaddingProperty)
    UTexture2D* NavigateEntriesGamepadTexture; // 0x388 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* NavigateEntriesPCTexture; // 0x390 (Size: 0x8, Type: ObjectProperty)
    UDelMarPlayerPreferencesComponent* PlayerPreferences; // 0x398 (Size: 0x8, Type: ObjectProperty)
    UOverlay* EntryOverlay; // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    URetainerBox* EdgeFadeRetainerBox; // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    USizeBox* ContentSizeBox; // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnExpandToggled[0x10]; // 0x3b8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnNavigationEnabledChanged[0x10]; // 0x3c8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnExpandableChanged[0x10]; // 0x3d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<UDelMarUserWidget*> DisplayedHudWidgetEntries; // 0x3e8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_3f8[0x10]; // 0x3f8 (Size: 0x10, Type: PaddingProperty)

protected:
    virtual void BP_HandlePlayerPreferencesAdded(UDelMarPlayerPreferencesComponent*& InPlayerPreferences); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    void HandleToggleAction(); // 0x11dc1fc0 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    void HandleToggleSettingChanged(bool& bUseToggle); // 0x11dc1fd4 (Index: 0x2, Flags: Final|Native|Protected)
    void SetTargetInterpTransformY(float& InTargetInterpTransformY); // 0x11dc3e08 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarExpandableHudWidget) == 0x408, "Size mismatch for UDelMarExpandableHudWidget");
static_assert(offsetof(UDelMarExpandableHudWidget, NavigateEntriesBindingImage) == 0x350, "Offset mismatch for UDelMarExpandableHudWidget::NavigateEntriesBindingImage");
static_assert(offsetof(UDelMarExpandableHudWidget, ExpandableHudWidgetEntryClass) == 0x370, "Offset mismatch for UDelMarExpandableHudWidget::ExpandableHudWidgetEntryClass");
static_assert(offsetof(UDelMarExpandableHudWidget, NumDesignerPreviewEntries) == 0x378, "Offset mismatch for UDelMarExpandableHudWidget::NumDesignerPreviewEntries");
static_assert(offsetof(UDelMarExpandableHudWidget, EntrySpacing) == 0x37c, "Offset mismatch for UDelMarExpandableHudWidget::EntrySpacing");
static_assert(offsetof(UDelMarExpandableHudWidget, bExpanded) == 0x380, "Offset mismatch for UDelMarExpandableHudWidget::bExpanded");
static_assert(offsetof(UDelMarExpandableHudWidget, bNavigationEnabled) == 0x381, "Offset mismatch for UDelMarExpandableHudWidget::bNavigationEnabled");
static_assert(offsetof(UDelMarExpandableHudWidget, NavigateEntriesGamepadTexture) == 0x388, "Offset mismatch for UDelMarExpandableHudWidget::NavigateEntriesGamepadTexture");
static_assert(offsetof(UDelMarExpandableHudWidget, NavigateEntriesPCTexture) == 0x390, "Offset mismatch for UDelMarExpandableHudWidget::NavigateEntriesPCTexture");
static_assert(offsetof(UDelMarExpandableHudWidget, PlayerPreferences) == 0x398, "Offset mismatch for UDelMarExpandableHudWidget::PlayerPreferences");
static_assert(offsetof(UDelMarExpandableHudWidget, EntryOverlay) == 0x3a0, "Offset mismatch for UDelMarExpandableHudWidget::EntryOverlay");
static_assert(offsetof(UDelMarExpandableHudWidget, EdgeFadeRetainerBox) == 0x3a8, "Offset mismatch for UDelMarExpandableHudWidget::EdgeFadeRetainerBox");
static_assert(offsetof(UDelMarExpandableHudWidget, ContentSizeBox) == 0x3b0, "Offset mismatch for UDelMarExpandableHudWidget::ContentSizeBox");
static_assert(offsetof(UDelMarExpandableHudWidget, OnExpandToggled) == 0x3b8, "Offset mismatch for UDelMarExpandableHudWidget::OnExpandToggled");
static_assert(offsetof(UDelMarExpandableHudWidget, OnNavigationEnabledChanged) == 0x3c8, "Offset mismatch for UDelMarExpandableHudWidget::OnNavigationEnabledChanged");
static_assert(offsetof(UDelMarExpandableHudWidget, OnExpandableChanged) == 0x3d8, "Offset mismatch for UDelMarExpandableHudWidget::OnExpandableChanged");
static_assert(offsetof(UDelMarExpandableHudWidget, DisplayedHudWidgetEntries) == 0x3e8, "Offset mismatch for UDelMarExpandableHudWidget::DisplayedHudWidgetEntries");

// Size: 0x4a0 (Inherited: 0xfc0, Single: 0xfffff4e0)
class UDelMarPostRaceLeaderboard : public UDelMarScreenBase
{
public:
    FDataTableRowHandle FilterDataTableRow; // 0x488 (Size: 0x10, Type: StructProperty)
    uint8_t Pad_498[0x8]; // 0x498 (Size: 0x8, Type: PaddingProperty)

protected:
    virtual void BP_UpdateLeaderboardFilter(); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UDelMarPostRaceLeaderboard) == 0x4a0, "Size mismatch for UDelMarPostRaceLeaderboard");
static_assert(offsetof(UDelMarPostRaceLeaderboard, FilterDataTableRow) == 0x488, "Offset mismatch for UDelMarPostRaceLeaderboard::FilterDataTableRow");

// Size: 0x488 (Inherited: 0xb38, Single: 0xfffff950)
class UDelMarScreenBase : public UCommonActivatableWidget
{
public:
    uint8_t Pad_408[0x58]; // 0x408 (Size: 0x58, Type: PaddingProperty)
    uint8_t InitialTransitionStatus; // 0x460 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_461[0x7]; // 0x461 (Size: 0x7, Type: PaddingProperty)
    UWidgetTransitioner* WidgetTransitioner; // 0x468 (Size: 0x8, Type: ObjectProperty)
    bool bActivateOnShow; // 0x470 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_471[0x7]; // 0x471 (Size: 0x7, Type: PaddingProperty)
    UWidgetAnimation* NormalTransitionIn; // 0x478 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* NormalTransitionOut; // 0x480 (Size: 0x8, Type: ObjectProperty)

public:
    void BP_Hide(bool& bSkipAnimation); // 0x11d4c020 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void BP_Show(bool& bSkipAnimation); // 0x11d4ca28 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    UUIStateChartManager* GetUIStateChartManager(); // 0x11d4dfd8 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    UWidgetTransitioner* GetWidgetTransitioner() const; // 0x11d4dffc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

protected:
    void HandleWidgetTransitionerStatusChanged(UWidgetTransitioner*& InTransitioner, EWidgetTransitionerStatus& InStatus); // 0x11d4e014 (Index: 0x4, Flags: Final|Native|Protected)
    bool IsDisplayEnabled() const; // 0xe102760 (Index: 0x5, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void SetDisplayEnabled(bool& bEnabled, bool& bSkipAnimation); // 0x11d4efd0 (Index: 0x6, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarScreenBase) == 0x488, "Size mismatch for UDelMarScreenBase");
static_assert(offsetof(UDelMarScreenBase, InitialTransitionStatus) == 0x460, "Offset mismatch for UDelMarScreenBase::InitialTransitionStatus");
static_assert(offsetof(UDelMarScreenBase, WidgetTransitioner) == 0x468, "Offset mismatch for UDelMarScreenBase::WidgetTransitioner");
static_assert(offsetof(UDelMarScreenBase, bActivateOnShow) == 0x470, "Offset mismatch for UDelMarScreenBase::bActivateOnShow");
static_assert(offsetof(UDelMarScreenBase, NormalTransitionIn) == 0x478, "Offset mismatch for UDelMarScreenBase::NormalTransitionIn");
static_assert(offsetof(UDelMarScreenBase, NormalTransitionOut) == 0x480, "Offset mismatch for UDelMarScreenBase::NormalTransitionOut");

// Size: 0x540 (Inherited: 0xfc0, Single: 0xfffff580)
class UDelMarPostRaceScreen : public UDelMarScreenBase
{
public:
    FDataTableRowHandle TabNavLeftDataTableRow; // 0x488 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle TabNavRightDataTableRow; // 0x498 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ReadyUpDataTableRow; // 0x4a8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle SpectateDataTableRow; // 0x4b8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ResetRunDataTableRow; // 0x4c8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ReturnToLobbyDataTableRow; // 0x4d8 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle OpenQuestBrowserDataTableRow; // 0x4e8 (Size: 0x10, Type: StructProperty)
    UInputAction* ToggleQuestBrowserInputAction; // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    TArray<EDelMarRaceMode> QuestBrowserAllowedRaceModes; // 0x500 (Size: 0x10, Type: ArrayProperty)
    UCommonButtonGroupBase* ButtonGroup_PostMatchNavigation; // 0x510 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> CachedRaceManager; // 0x518 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_520[0x20]; // 0x520 (Size: 0x20, Type: PaddingProperty)

protected:
    virtual void BP_OnReadyUpChanged(bool& bReady); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    void RequestCountdown(); // 0x11d41384 (Index: 0x1, Flags: Final|Native|Protected|BlueprintCallable)
    void ResetRun(); // 0x11d413bc (Index: 0x2, Flags: Final|Native|Protected|BlueprintCallable)
    void UpdateVote(EDelMarPostRaceVote& NewVote); // 0x11d41cf0 (Index: 0x3, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarPostRaceScreen) == 0x540, "Size mismatch for UDelMarPostRaceScreen");
static_assert(offsetof(UDelMarPostRaceScreen, TabNavLeftDataTableRow) == 0x488, "Offset mismatch for UDelMarPostRaceScreen::TabNavLeftDataTableRow");
static_assert(offsetof(UDelMarPostRaceScreen, TabNavRightDataTableRow) == 0x498, "Offset mismatch for UDelMarPostRaceScreen::TabNavRightDataTableRow");
static_assert(offsetof(UDelMarPostRaceScreen, ReadyUpDataTableRow) == 0x4a8, "Offset mismatch for UDelMarPostRaceScreen::ReadyUpDataTableRow");
static_assert(offsetof(UDelMarPostRaceScreen, SpectateDataTableRow) == 0x4b8, "Offset mismatch for UDelMarPostRaceScreen::SpectateDataTableRow");
static_assert(offsetof(UDelMarPostRaceScreen, ResetRunDataTableRow) == 0x4c8, "Offset mismatch for UDelMarPostRaceScreen::ResetRunDataTableRow");
static_assert(offsetof(UDelMarPostRaceScreen, ReturnToLobbyDataTableRow) == 0x4d8, "Offset mismatch for UDelMarPostRaceScreen::ReturnToLobbyDataTableRow");
static_assert(offsetof(UDelMarPostRaceScreen, OpenQuestBrowserDataTableRow) == 0x4e8, "Offset mismatch for UDelMarPostRaceScreen::OpenQuestBrowserDataTableRow");
static_assert(offsetof(UDelMarPostRaceScreen, ToggleQuestBrowserInputAction) == 0x4f8, "Offset mismatch for UDelMarPostRaceScreen::ToggleQuestBrowserInputAction");
static_assert(offsetof(UDelMarPostRaceScreen, QuestBrowserAllowedRaceModes) == 0x500, "Offset mismatch for UDelMarPostRaceScreen::QuestBrowserAllowedRaceModes");
static_assert(offsetof(UDelMarPostRaceScreen, ButtonGroup_PostMatchNavigation) == 0x510, "Offset mismatch for UDelMarPostRaceScreen::ButtonGroup_PostMatchNavigation");
static_assert(offsetof(UDelMarPostRaceScreen, CachedRaceManager) == 0x518, "Offset mismatch for UDelMarPostRaceScreen::CachedRaceManager");

// Size: 0x350 (Inherited: 0xa80, Single: 0xfffff8d0)
class UDelMarPostRaceVoteWidget : public UDelMarUserWidget
{
public:

public:
    virtual void BP_OnPostRaceVoteChanged(EDelMarPostRaceVote& Vote); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    void UpdateVote(EDelMarPostRaceVote& NewVote); // 0x11d41e1c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarPostRaceVoteWidget) == 0x350, "Size mismatch for UDelMarPostRaceVoteWidget");

// Size: 0x420 (Inherited: 0xa80, Single: 0xfffff9a0)
class UDelMarQuestScreenContainer : public UDelMarUserWidget
{
public:
    FGameplayTagContainer AllowedRaceGameplayStates; // 0x350 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AllowedRacerStates; // 0x370 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer AllowedRaceModes; // 0x390 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer PreRaceInputRaceStates; // 0x3b0 (Size: 0x20, Type: StructProperty)
    FGameplayTag RaceGameplayState; // 0x3d0 (Size: 0x4, Type: StructProperty)
    FGameplayTag RaceMode; // 0x3d4 (Size: 0x4, Type: StructProperty)
    FGameplayTag RacerState; // 0x3d8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_3dc[0x4]; // 0x3dc (Size: 0x4, Type: PaddingProperty)
    UAthenaMapScreenContainer* AthenaScreenContainer; // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    uint8_t OnQuestListActivate[0x10]; // 0x3e8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnQuestListDeactivate[0x10]; // 0x3f8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bAthenaScreenContainerVisible; // 0x408 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_409[0x7]; // 0x409 (Size: 0x7, Type: PaddingProperty)
    double LastOnVisibleTimeSeconds; // 0x410 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag LastOnVisibleRaceState; // 0x418 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_41c[0x4]; // 0x41c (Size: 0x4, Type: PaddingProperty)

public:
    bool IsQuestScreenContainerVisible() const; // 0xf1c6ea4 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    void OnQuestListActivateFunc(); // 0x11d40e50 (Index: 0x5, Flags: Final|Native|Private)
    void OnQuestListDeactivateFunc(); // 0x11d40e64 (Index: 0x6, Flags: Final|Native|Private)
    void OnQuestModalDeactivated(bool& const bWantsExit); // 0x11d40e78 (Index: 0x7, Flags: Final|Native|Private)
    void OnTabWidgetAdded(UWidget*& Widget); // 0x11d40fa4 (Index: 0x8, Flags: Final|Native|Private)
    void OnTabWidgetRemoved(UWidget*& Widget); // 0x11d410d4 (Index: 0x9, Flags: Final|Native|Private)

protected:
    bool CanSetQuestScreenVisible() const; // 0x11d406a4 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void HandleAthenaScreenDeactivated(); // 0x11d408f0 (Index: 0x1, Flags: Final|Native|Protected)
    void HandleMapPanelExitButtonPressed(); // 0x11d40a30 (Index: 0x2, Flags: Final|Native|Protected)
    void HandleToggleQuestList(); // 0x11d40b58 (Index: 0x3, Flags: Final|Native|Protected)
    void SetQuestScreenVisible(bool& const bVisible); // 0x11d41858 (Index: 0xa, Flags: Final|Native|Protected|BlueprintCallable)
    static bool ShouldQuestShowRaceStatus(); // 0x11d41984 (Index: 0xb, Flags: Final|Native|Static|Protected|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UDelMarQuestScreenContainer) == 0x420, "Size mismatch for UDelMarQuestScreenContainer");
static_assert(offsetof(UDelMarQuestScreenContainer, AllowedRaceGameplayStates) == 0x350, "Offset mismatch for UDelMarQuestScreenContainer::AllowedRaceGameplayStates");
static_assert(offsetof(UDelMarQuestScreenContainer, AllowedRacerStates) == 0x370, "Offset mismatch for UDelMarQuestScreenContainer::AllowedRacerStates");
static_assert(offsetof(UDelMarQuestScreenContainer, AllowedRaceModes) == 0x390, "Offset mismatch for UDelMarQuestScreenContainer::AllowedRaceModes");
static_assert(offsetof(UDelMarQuestScreenContainer, PreRaceInputRaceStates) == 0x3b0, "Offset mismatch for UDelMarQuestScreenContainer::PreRaceInputRaceStates");
static_assert(offsetof(UDelMarQuestScreenContainer, RaceGameplayState) == 0x3d0, "Offset mismatch for UDelMarQuestScreenContainer::RaceGameplayState");
static_assert(offsetof(UDelMarQuestScreenContainer, RaceMode) == 0x3d4, "Offset mismatch for UDelMarQuestScreenContainer::RaceMode");
static_assert(offsetof(UDelMarQuestScreenContainer, RacerState) == 0x3d8, "Offset mismatch for UDelMarQuestScreenContainer::RacerState");
static_assert(offsetof(UDelMarQuestScreenContainer, AthenaScreenContainer) == 0x3e0, "Offset mismatch for UDelMarQuestScreenContainer::AthenaScreenContainer");
static_assert(offsetof(UDelMarQuestScreenContainer, OnQuestListActivate) == 0x3e8, "Offset mismatch for UDelMarQuestScreenContainer::OnQuestListActivate");
static_assert(offsetof(UDelMarQuestScreenContainer, OnQuestListDeactivate) == 0x3f8, "Offset mismatch for UDelMarQuestScreenContainer::OnQuestListDeactivate");
static_assert(offsetof(UDelMarQuestScreenContainer, bAthenaScreenContainerVisible) == 0x408, "Offset mismatch for UDelMarQuestScreenContainer::bAthenaScreenContainerVisible");
static_assert(offsetof(UDelMarQuestScreenContainer, LastOnVisibleTimeSeconds) == 0x410, "Offset mismatch for UDelMarQuestScreenContainer::LastOnVisibleTimeSeconds");
static_assert(offsetof(UDelMarQuestScreenContainer, LastOnVisibleRaceState) == 0x418, "Offset mismatch for UDelMarQuestScreenContainer::LastOnVisibleRaceState");

// Size: 0x358 (Inherited: 0x458, Single: 0xffffff00)
class UDelMarRichTextInputSwitcher : public UUserWidget
{
public:
    bool bUseFormattedText; // 0x2b0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_2b1[0x7]; // 0x2b1 (Size: 0x7, Type: PaddingProperty)
    FText TextFormat; // 0x2b8 (Size: 0x10, Type: TextProperty)
    TMap<FDelMarKeyPair, FString> Args; // 0x2c8 (Size: 0x50, Type: MapProperty)
    FText TextKBM; // 0x318 (Size: 0x10, Type: TextProperty)
    FText TextGamepad; // 0x328 (Size: 0x10, Type: TextProperty)
    FText TextTouch; // 0x338 (Size: 0x10, Type: TextProperty)
    UCommonRichTextBlock* Widget_RichText; // 0x348 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_350[0x8]; // 0x350 (Size: 0x8, Type: PaddingProperty)

public:
    void SetInputText(FText& InTextKBM, FText& InTextGamepad, FText& InTextTouch); // 0x11d41510 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarRichTextInputSwitcher) == 0x358, "Size mismatch for UDelMarRichTextInputSwitcher");
static_assert(offsetof(UDelMarRichTextInputSwitcher, bUseFormattedText) == 0x2b0, "Offset mismatch for UDelMarRichTextInputSwitcher::bUseFormattedText");
static_assert(offsetof(UDelMarRichTextInputSwitcher, TextFormat) == 0x2b8, "Offset mismatch for UDelMarRichTextInputSwitcher::TextFormat");
static_assert(offsetof(UDelMarRichTextInputSwitcher, Args) == 0x2c8, "Offset mismatch for UDelMarRichTextInputSwitcher::Args");
static_assert(offsetof(UDelMarRichTextInputSwitcher, TextKBM) == 0x318, "Offset mismatch for UDelMarRichTextInputSwitcher::TextKBM");
static_assert(offsetof(UDelMarRichTextInputSwitcher, TextGamepad) == 0x328, "Offset mismatch for UDelMarRichTextInputSwitcher::TextGamepad");
static_assert(offsetof(UDelMarRichTextInputSwitcher, TextTouch) == 0x338, "Offset mismatch for UDelMarRichTextInputSwitcher::TextTouch");
static_assert(offsetof(UDelMarRichTextInputSwitcher, Widget_RichText) == 0x348, "Offset mismatch for UDelMarRichTextInputSwitcher::Widget_RichText");

// Size: 0x98 (Inherited: 0x108, Single: 0xffffff90)
class UDelMarSelectionListViewModel : public UDelMarListViewModel
{
public:
    int32_t SelectedIndex; // 0x78 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_7c[0x1c]; // 0x7c (Size: 0x1c, Type: PaddingProperty)

public:
    void ClearSelection(); // 0x11d4d0d8 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    int32_t GetSelectedIndex() const; // 0x99c4160 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool HasSelection() const; // 0xfd43ee4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UMVVMViewModelBase* SelectedElement() const; // 0x11d4ee70 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SelectNextElement(bool& bAllowWrap); // 0x11d4ebf0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SelectPreviousElement(bool& bAllowWrap); // 0x11d4ed30 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetSelectedElement(UMVVMViewModelBase*& InSelectedElement); // 0x11d5021c (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void SetSelectedIndex(int32_t& InIndex); // 0x11d50378 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarSelectionListViewModel) == 0x98, "Size mismatch for UDelMarSelectionListViewModel");
static_assert(offsetof(UDelMarSelectionListViewModel, SelectedIndex) == 0x78, "Offset mismatch for UDelMarSelectionListViewModel::SelectedIndex");

// Size: 0x3f0 (Inherited: 0xdf8, Single: 0xfffff5f8)
class UDelMarTouchActionButton : public UDelMarTouchWidgetBase
{
public:
    uint8_t State; // 0x378 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_379[0x7]; // 0x379 (Size: 0x7, Type: PaddingProperty)
    TMap<FDelMarTouchActionButtonStateData, EDelMarTouchActionButtonState> ButtonStateData; // 0x380 (Size: 0x50, Type: MapProperty)
    bool bHighlightActive; // 0x3d0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3d1[0x7]; // 0x3d1 (Size: 0x7, Type: PaddingProperty)
    uint8_t OnHighlightChanged[0x10]; // 0x3d8 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    bool bIsUpdatingState; // 0x3e8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3e9[0x7]; // 0x3e9 (Size: 0x7, Type: PaddingProperty)

public:
    EDelMarTouchActionButtonState GetState() const; // 0x11d4de2c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    virtual void SetBackgroundBrush(const FSlateBrush Brush); // 0x288a61c (Index: 0x3, Flags: BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)
    bool SetButtonState(EDelMarTouchActionButtonState& NewState); // 0x11d4ee98 (Index: 0x4, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
    virtual void SetHighlightActive(bool& bValue); // 0x11c283b4 (Index: 0x5, Flags: BlueprintCosmetic|Native|Event|Public|BlueprintCallable|BlueprintEvent)
    virtual void SetIconBrush(const FSlateBrush Brush); // 0x288a61c (Index: 0x6, Flags: BlueprintCosmetic|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent)

protected:
    virtual bool CanSetState(EDelMarTouchActionButtonState& NewState); // 0x11d4cf84 (Index: 0x0, Flags: BlueprintCosmetic|Native|Event|Protected|BlueprintEvent)
    virtual EDelMarTouchActionButtonState GetStateOnStopInputTracking(bool& bInputCancelled) const; // 0x11d4de44 (Index: 0x2, Flags: BlueprintCosmetic|Native|Event|Protected|BlueprintEvent|Const)
};

static_assert(sizeof(UDelMarTouchActionButton) == 0x3f0, "Size mismatch for UDelMarTouchActionButton");
static_assert(offsetof(UDelMarTouchActionButton, State) == 0x378, "Offset mismatch for UDelMarTouchActionButton::State");
static_assert(offsetof(UDelMarTouchActionButton, ButtonStateData) == 0x380, "Offset mismatch for UDelMarTouchActionButton::ButtonStateData");
static_assert(offsetof(UDelMarTouchActionButton, bHighlightActive) == 0x3d0, "Offset mismatch for UDelMarTouchActionButton::bHighlightActive");
static_assert(offsetof(UDelMarTouchActionButton, OnHighlightChanged) == 0x3d8, "Offset mismatch for UDelMarTouchActionButton::OnHighlightChanged");
static_assert(offsetof(UDelMarTouchActionButton, bIsUpdatingState) == 0x3e8, "Offset mismatch for UDelMarTouchActionButton::bIsUpdatingState");

// Size: 0x378 (Inherited: 0xa80, Single: 0xfffff8f8)
class UDelMarTouchWidgetBase : public UDelMarUserWidget
{
public:
    TArray<FDelMarTouchInputDefinition> InputActionsData; // 0x350 (Size: 0x10, Type: ArrayProperty)
    bool bTrackInputPastBounds; // 0x360 (Size: 0x1, Type: BoolProperty)
    bool bTrackInputFromEnter; // 0x361 (Size: 0x1, Type: BoolProperty)
    bool bIsInjectingInput; // 0x362 (Size: 0x1, Type: BoolProperty)
    uint8_t CurrentInputTrackingState; // 0x363 (Size: 0x1, Type: EnumProperty)
    uint8_t RequiredInputMode; // 0x364 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_365[0x13]; // 0x365 (Size: 0x13, Type: PaddingProperty)

public:
    virtual FGeometry GetHitboxGeometry() const; // 0x11d4dd2c (Index: 0x1, Flags: Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const)
    bool IsGestureInsideHitbox(const FPointerEvent InGestureEvent) const; // 0x11d4e21c (Index: 0x5, Flags: Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const)

private:
    static float GetMobileContentScaleFactor(); // 0x11d4ddc8 (Index: 0x2, Flags: Final|Native|Static|Private|BlueprintCallable|BlueprintPure)
    static int32_t GetPixelsPerInch(); // 0x11d4ddf0 (Index: 0x3, Flags: Final|Native|Static|Private|BlueprintCallable|BlueprintPure)
    static float GetTouchJoystickInputValueMultiplier(); // 0x11d4df84 (Index: 0x4, Flags: Final|Native|Static|Private|BlueprintCallable|BlueprintPure)
    void OnActiveInputModeChanged(ECommonInputMode& NewInputMode); // 0x11d4e34c (Index: 0x6, Flags: Final|Native|Private)
    static bool ShouldTouchJoystickIgnoreContentScaleFactor(); // 0x11d504a0 (Index: 0xc, Flags: Final|Native|Static|Private|BlueprintCallable|BlueprintPure)

protected:
    void CancelInputTracking(); // 0x11d4d0c4 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void OnInputInjectionEnded(const FPointerEvent InGestureEvent, EDelMarInputInjectionState& InInjectedState); // 0x11d4e478 (Index: 0x7, Flags: BlueprintCosmetic|Native|Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnInputInjectionStarted(const FPointerEvent InGestureEvent, EDelMarInputInjectionState& InInjectedState); // 0x11d4e5f4 (Index: 0x8, Flags: BlueprintCosmetic|Native|Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnTrackedInputEnded(const FPointerEvent InGestureEvent, bool& bCancelled); // 0x11d4e770 (Index: 0x9, Flags: BlueprintCosmetic|Native|Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnTrackedInputStarted(const FPointerEvent InGestureEvent); // 0x11d4e8ec (Index: 0xa, Flags: BlueprintCosmetic|Native|Event|Protected|HasOutParms|BlueprintEvent)
    virtual void OnTrackedInputUpdated(const FPointerEvent InGestureEvent); // 0x11d4e9d8 (Index: 0xb, Flags: BlueprintCosmetic|Native|Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UDelMarTouchWidgetBase) == 0x378, "Size mismatch for UDelMarTouchWidgetBase");
static_assert(offsetof(UDelMarTouchWidgetBase, InputActionsData) == 0x350, "Offset mismatch for UDelMarTouchWidgetBase::InputActionsData");
static_assert(offsetof(UDelMarTouchWidgetBase, bTrackInputPastBounds) == 0x360, "Offset mismatch for UDelMarTouchWidgetBase::bTrackInputPastBounds");
static_assert(offsetof(UDelMarTouchWidgetBase, bTrackInputFromEnter) == 0x361, "Offset mismatch for UDelMarTouchWidgetBase::bTrackInputFromEnter");
static_assert(offsetof(UDelMarTouchWidgetBase, bIsInjectingInput) == 0x362, "Offset mismatch for UDelMarTouchWidgetBase::bIsInjectingInput");
static_assert(offsetof(UDelMarTouchWidgetBase, CurrentInputTrackingState) == 0x363, "Offset mismatch for UDelMarTouchWidgetBase::CurrentInputTrackingState");
static_assert(offsetof(UDelMarTouchWidgetBase, RequiredInputMode) == 0x364, "Offset mismatch for UDelMarTouchWidgetBase::RequiredInputMode");

// Size: 0x388 (Inherited: 0xdf8, Single: 0xfffff590)
class UDelMarTouchRegion : public UDelMarTouchWidgetBase
{
public:
    TArray<UDelMarTouchActionButton*> TouchActionButtons; // 0x378 (Size: 0x10, Type: ArrayProperty)

protected:
    UDelMarTouchActionButton* FindButtonByInputAction(UInputAction*& InputAction); // 0x11d4db5c (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
    virtual void SetHighlightForInputAction(UInputAction*& InputAction); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintCallable|BlueprintEvent)
};

static_assert(sizeof(UDelMarTouchRegion) == 0x388, "Size mismatch for UDelMarTouchRegion");
static_assert(offsetof(UDelMarTouchRegion, TouchActionButtons) == 0x378, "Offset mismatch for UDelMarTouchRegion::TouchActionButtons");

// Size: 0x80 (Inherited: 0x78, Single: 0x8)
class UDelMarUICheatManager : public UChildCheatManager
{
public:
    UDynamicUIScene* DriverCameraHiddenScene; // 0x28 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* PlayerIndicatorHiddenScene; // 0x30 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* PointsDebugWidgetVisibleScene; // 0x38 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* RubberbandingWidgetVisibleScene; // 0x40 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* StaticVehicleMeterHiddenScene; // 0x48 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* VehicleDebugVisibleScene; // 0x50 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* VehicleHealthDebugVisibleScene; // 0x58 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* CheckpointDebugWidgetScene; // 0x60 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* MapNameDebugWidgetScene; // 0x68 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* GameplayTrackList; // 0x70 (Size: 0x8, Type: ObjectProperty)
    bool bAttachedWidgetEnabled; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)

protected:
    void DelMarAttachedWidgetSetEnabled(bool& bEnabled); // 0x9e6e1b8 (Index: 0x0, Flags: Final|Exec|Native|Protected)
    void DelMarCheckpointDebugWidgetSetVisible(bool& bVisible); // 0x9e6e1b8 (Index: 0x1, Flags: Final|Exec|Native|Protected)
    void DelMarCloseTrackList(); // 0x554e3c4 (Index: 0x2, Flags: Final|Exec|Native|Protected)
    void DelMarDismissDialog(); // 0x11d4d7d8 (Index: 0x3, Flags: Final|Exec|Native|Protected)
    void DelMarDriverCameraSetHidden(bool& bHidden); // 0x9e6e1b8 (Index: 0x4, Flags: Final|Exec|Native|Protected)
    void DelMarDriverCameraSetReactiveType(int32_t& Type); // 0xa5dc3cc (Index: 0x5, Flags: Final|Exec|Native|Protected)
    void DelMarMapNameDebugWidgetSetVisible(bool& bVisible); // 0x9e6e1b8 (Index: 0x6, Flags: Final|Exec|Native|Protected)
    void DelMarOpenTrackList(); // 0x554e3c4 (Index: 0x7, Flags: Final|Exec|Native|Protected)
    void DelMarPlayerIndicatorsVisible(bool& bVisible); // 0x9e6e1b8 (Index: 0x8, Flags: Final|Exec|Native|Protected)
    void DelMarPointsDebugWidgetSetVisible(bool& bVisible); // 0x9e6e1b8 (Index: 0x9, Flags: Final|Exec|Native|Protected)
    void DelMarRequestDialogByTag(FGameplayTag& Tag); // 0x11d4d828 (Index: 0xa, Flags: Final|Exec|Native|Protected)
    void DelMarRubberbandingWidgetSetVisible(bool& bVisible); // 0x9e6e1b8 (Index: 0xb, Flags: Final|Exec|Native|Protected)
    void DelMarSetHint(FText& HintText, float& RemoveAfterDelay); // 0x11d4d8e8 (Index: 0xc, Flags: Final|Exec|Native|Protected)
    void DelMarTouchHUD(FString& TouchHUDType); // 0xa63baa0 (Index: 0xd, Flags: Final|BlueprintCosmetic|Exec|Native|Protected)
    void DelMarUISetVisible(bool& bVisible); // 0x9e6e1b8 (Index: 0xe, Flags: Final|Exec|Native|Protected)
    void DelMarUseToggleForExpandableHudWidget(bool& bUseToggle); // 0x9e6e1b8 (Index: 0xf, Flags: Final|Exec|Native|Protected)
    void DelMarVehicleDebugWidgetSetVisible(bool& bVisible); // 0x9e6e1b8 (Index: 0x10, Flags: Final|Exec|Native|Protected)
    void DelMarVehicleHealthDebugWidgetSetVisible(bool& bVisible); // 0x9e6e1b8 (Index: 0x11, Flags: Final|Exec|Native|Protected)
    void OnAddedToCheatManagerNative(); // 0x554e3c4 (Index: 0x12, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarUICheatManager) == 0x80, "Size mismatch for UDelMarUICheatManager");
static_assert(offsetof(UDelMarUICheatManager, DriverCameraHiddenScene) == 0x28, "Offset mismatch for UDelMarUICheatManager::DriverCameraHiddenScene");
static_assert(offsetof(UDelMarUICheatManager, PlayerIndicatorHiddenScene) == 0x30, "Offset mismatch for UDelMarUICheatManager::PlayerIndicatorHiddenScene");
static_assert(offsetof(UDelMarUICheatManager, PointsDebugWidgetVisibleScene) == 0x38, "Offset mismatch for UDelMarUICheatManager::PointsDebugWidgetVisibleScene");
static_assert(offsetof(UDelMarUICheatManager, RubberbandingWidgetVisibleScene) == 0x40, "Offset mismatch for UDelMarUICheatManager::RubberbandingWidgetVisibleScene");
static_assert(offsetof(UDelMarUICheatManager, StaticVehicleMeterHiddenScene) == 0x48, "Offset mismatch for UDelMarUICheatManager::StaticVehicleMeterHiddenScene");
static_assert(offsetof(UDelMarUICheatManager, VehicleDebugVisibleScene) == 0x50, "Offset mismatch for UDelMarUICheatManager::VehicleDebugVisibleScene");
static_assert(offsetof(UDelMarUICheatManager, VehicleHealthDebugVisibleScene) == 0x58, "Offset mismatch for UDelMarUICheatManager::VehicleHealthDebugVisibleScene");
static_assert(offsetof(UDelMarUICheatManager, CheckpointDebugWidgetScene) == 0x60, "Offset mismatch for UDelMarUICheatManager::CheckpointDebugWidgetScene");
static_assert(offsetof(UDelMarUICheatManager, MapNameDebugWidgetScene) == 0x68, "Offset mismatch for UDelMarUICheatManager::MapNameDebugWidgetScene");
static_assert(offsetof(UDelMarUICheatManager, GameplayTrackList) == 0x70, "Offset mismatch for UDelMarUICheatManager::GameplayTrackList");
static_assert(offsetof(UDelMarUICheatManager, bAttachedWidgetEnabled) == 0x78, "Offset mismatch for UDelMarUICheatManager::bAttachedWidgetEnabled");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UUIAnimationController : public UObject
{
public:

public:
    void FastForward(); // 0xa39cba8 (Index: 0x0, Flags: Native|Public|BlueprintCallable)
    float GetDuration(); // 0xee18750 (Index: 0x1, Flags: Native|Public|BlueprintCallable)
    bool IsPlaying() const; // 0xbea6ef4 (Index: 0x2, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    void JumpToBeginning(); // 0x472ef98 (Index: 0x3, Flags: Native|Public|BlueprintCallable)
    void JumpToEnd(); // 0x3c6d244 (Index: 0x4, Flags: Native|Public|BlueprintCallable)
    void PlayBackward(); // 0xa20b3a8 (Index: 0x5, Flags: Native|Public|BlueprintCallable)
    void PlayForward(); // 0x41f1e2c (Index: 0x6, Flags: Native|Public|BlueprintCallable)
    void Rewind(); // 0x31f3198 (Index: 0x7, Flags: Native|Public|BlueprintCallable)
    void Stop(); // 0x3305bfc (Index: 0x8, Flags: Native|Public|BlueprintCallable)
    void SwitchPlayDirection(); // 0x5ba16d4 (Index: 0x9, Flags: Native|Public|BlueprintCallable)
};

static_assert(sizeof(UUIAnimationController) == 0x38, "Size mismatch for UUIAnimationController");

// Size: 0x58 (Inherited: 0x60, Single: 0xfffffff8)
class UUITimelineAnimationController : public UUIAnimationController
{
public:
    UUserWidget* WidgetTarget; // 0x38 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Animation; // 0x40 (Size: 0x8, Type: ObjectProperty)
    UUMGSequencePlayer* ActivePlayer; // 0x48 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_50[0x8]; // 0x50 (Size: 0x8, Type: PaddingProperty)

public:
    static UUITimelineAnimationController* CreateInstance(UUserWidget*& WidgetTarget, UWidgetAnimation*& Animation); // 0x11d4d0f0 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UUITimelineAnimationController) == 0x58, "Size mismatch for UUITimelineAnimationController");
static_assert(offsetof(UUITimelineAnimationController, WidgetTarget) == 0x38, "Offset mismatch for UUITimelineAnimationController::WidgetTarget");
static_assert(offsetof(UUITimelineAnimationController, Animation) == 0x40, "Offset mismatch for UUITimelineAnimationController::Animation");
static_assert(offsetof(UUITimelineAnimationController, ActivePlayer) == 0x48, "Offset mismatch for UUITimelineAnimationController::ActivePlayer");

// Size: 0x38 (Inherited: 0x28, Single: 0x10)
class UUIAnimationControllerEntry : public UObject
{
public:
    UUIAnimationController* AnimationController; // 0x28 (Size: 0x8, Type: ObjectProperty)
    bool bIsInverted; // 0x30 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_31[0x7]; // 0x31 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UUIAnimationControllerEntry) == 0x38, "Size mismatch for UUIAnimationControllerEntry");
static_assert(offsetof(UUIAnimationControllerEntry, AnimationController) == 0x28, "Offset mismatch for UUIAnimationControllerEntry::AnimationController");
static_assert(offsetof(UUIAnimationControllerEntry, bIsInverted) == 0x30, "Offset mismatch for UUIAnimationControllerEntry::bIsInverted");

// Size: 0x108 (Inherited: 0x28, Single: 0xe0)
class UWidgetTransitioner : public UObject
{
public:
    uint8_t OnTransitionerStatusChanged[0x10]; // 0x28 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UWidget* TargetWidget; // 0x38 (Size: 0x8, Type: ObjectProperty)
    uint8_t HiddenVisibility; // 0x40 (Size: 0x1, Type: EnumProperty)
    uint8_t ShownVisibility; // 0x41 (Size: 0x1, Type: EnumProperty)
    uint8_t TransitionerStatus; // 0x42 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_43[0x5]; // 0x43 (Size: 0x5, Type: PaddingProperty)
    UUIAnimationControllerEntry* NormalTransitionIn; // 0x48 (Size: 0x8, Type: ObjectProperty)
    UUIAnimationControllerEntry* NormalTransitionOut; // 0x50 (Size: 0x8, Type: ObjectProperty)
    TMap<UUIAnimationControllerEntry*, FGameplayTag> HintedTransitionsIn; // 0x58 (Size: 0x50, Type: MapProperty)
    TMap<UUIAnimationControllerEntry*, FGameplayTag> HintedTransitionsOut; // 0xa8 (Size: 0x50, Type: MapProperty)
    UUIAnimationControllerEntry* ActiveEntry; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    bool bAlwaysReverseInterruptedAnimations; // 0x100 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_101[0x7]; // 0x101 (Size: 0x7, Type: PaddingProperty)

public:
    void AddHintedTransitionIn(FGameplayTag& const InAnimationHint, UUIAnimationController*& InAnimationIn, bool& const bInvert); // 0x11d4baf4 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void AddHintedTransitionOut(FGameplayTag& const InAnimationHint, UUIAnimationController*& InAnimationOut, bool& const bInvert); // 0x11d4bca4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void AddHintedTransitionPair(FGameplayTag& const InAnimationHint, UUIAnimationController*& InAnimation, bool& const bIsTransitionIn); // 0x11d4be54 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void BP_Hide(bool& const bSkipAnimation, FGameplayTagContainer& const AnimationHints); // 0x11d4c148 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    UWidgetTransitioner* BP_Initialize(UWidget*& TargetWidget, EWidgetTransitionerInitialStatus& InitialStatus, ESlateVisibility& HiddenVisibility, ESlateVisibility& ShownVisibility, bool& AlwaysReverseInterruptedAnimations); // 0x11d4c56c (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void BP_Show(bool& const bSkipAnimation, FGameplayTagContainer& const AnimationHints); // 0x11d4cb64 (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    static UWidgetTransitioner* CreateInstance(UWidget*& TargetWidget, EWidgetTransitionerInitialStatus& InitialStatus, ESlateVisibility& HiddenVisibility, ESlateVisibility& ShownVisibility, bool& AlwaysReverseInterruptedAnimations); // 0x11d4d308 (Index: 0x6, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
    EWidgetTransitionerStatus GetTransitionerStatus() const; // 0x11d4dfc4 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsHidden() const; // 0x11d4e334 (Index: 0x8, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void SetNormalTransitionIn(UUIAnimationController*& InAnimationIn, bool& const bInvert); // 0x11d4fbf8 (Index: 0x9, Flags: Final|Native|Public|BlueprintCallable)
    void SetNormalTransitionOut(UUIAnimationController*& InAnimationOut, bool& const bInvert); // 0x11d4fe04 (Index: 0xa, Flags: Final|Native|Public|BlueprintCallable)
    void SetNormalTransitionPair(UUIAnimationController*& InAnimation, bool& const bIsTransitionIn); // 0x11d50010 (Index: 0xb, Flags: Final|Native|Public|BlueprintCallable)
    void WidgetTransitionerStatusChange__DelegateSignature(UWidgetTransitioner*& Transitioner, EWidgetTransitionerStatus& Status); // 0x288a61c (Index: 0xc, Flags: MulticastDelegate|Public|Delegate)
};

static_assert(sizeof(UWidgetTransitioner) == 0x108, "Size mismatch for UWidgetTransitioner");
static_assert(offsetof(UWidgetTransitioner, OnTransitionerStatusChanged) == 0x28, "Offset mismatch for UWidgetTransitioner::OnTransitionerStatusChanged");
static_assert(offsetof(UWidgetTransitioner, TargetWidget) == 0x38, "Offset mismatch for UWidgetTransitioner::TargetWidget");
static_assert(offsetof(UWidgetTransitioner, HiddenVisibility) == 0x40, "Offset mismatch for UWidgetTransitioner::HiddenVisibility");
static_assert(offsetof(UWidgetTransitioner, ShownVisibility) == 0x41, "Offset mismatch for UWidgetTransitioner::ShownVisibility");
static_assert(offsetof(UWidgetTransitioner, TransitionerStatus) == 0x42, "Offset mismatch for UWidgetTransitioner::TransitionerStatus");
static_assert(offsetof(UWidgetTransitioner, NormalTransitionIn) == 0x48, "Offset mismatch for UWidgetTransitioner::NormalTransitionIn");
static_assert(offsetof(UWidgetTransitioner, NormalTransitionOut) == 0x50, "Offset mismatch for UWidgetTransitioner::NormalTransitionOut");
static_assert(offsetof(UWidgetTransitioner, HintedTransitionsIn) == 0x58, "Offset mismatch for UWidgetTransitioner::HintedTransitionsIn");
static_assert(offsetof(UWidgetTransitioner, HintedTransitionsOut) == 0xa8, "Offset mismatch for UWidgetTransitioner::HintedTransitionsOut");
static_assert(offsetof(UWidgetTransitioner, ActiveEntry) == 0xf8, "Offset mismatch for UWidgetTransitioner::ActiveEntry");
static_assert(offsetof(UWidgetTransitioner, bAlwaysReverseInterruptedAnimations) == 0x100, "Offset mismatch for UWidgetTransitioner::bAlwaysReverseInterruptedAnimations");

// Size: 0x410 (Inherited: 0x1a8, Single: 0x268)
class UDelMarActionWidget : public UWidget
{
public:
    uint8_t OnInputMethodChanged[0x10]; // 0x158 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t Pad_168[0x8]; // 0x168 (Size: 0x8, Type: PaddingProperty)
    FSlateBrush ProgressMaterialBrush; // 0x170 (Size: 0xb0, Type: StructProperty)
    FName ProgressMaterialParam; // 0x220 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_224[0xc]; // 0x224 (Size: 0xc, Type: PaddingProperty)
    FSlateBrush IconRimBrush; // 0x230 (Size: 0xb0, Type: StructProperty)
    TArray<FDataTableRowHandle> InputActions; // 0x2e0 (Size: 0x10, Type: ArrayProperty)
    UInputAction* EnhancedInputAction; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2f8[0x8]; // 0x2f8 (Size: 0x8, Type: PaddingProperty)
    UMaterialInstanceDynamic* ProgressDynamicMaterial; // 0x300 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_308[0x108]; // 0x308 (Size: 0x108, Type: PaddingProperty)

public:
    FText GetDisplayText() const; // 0x11d4dcf0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    FSlateBrush GetIcon() const; // 0x11d4dd80 (Index: 0x1, Flags: Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool IsHeldAction() const; // 0x11d4e310 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    void OnInputMethodChanged__DelegateSignature(bool& bUsingGamepad); // 0x288a61c (Index: 0x3, Flags: MulticastDelegate|Public|Delegate)
    void SetEnhancedInputAction(UInputAction*& InInputAction); // 0x11d4f1f0 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
    void SetIconRimBrush(FSlateBrush& InIconRimBrush); // 0x11d4f4dc (Index: 0x5, Flags: Final|Native|Public|BlueprintCallable)
    void SetInputAction(FDataTableRowHandle& InputActionRow); // 0x11d4f5d8 (Index: 0x6, Flags: Final|Native|Public|BlueprintCallable)
    void SetInputActions(TArray<FDataTableRowHandle>& NewInputActions); // 0x11d4f860 (Index: 0x7, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void UpdateActionWidget(); // 0x11d504cc (Index: 0x8, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarActionWidget) == 0x410, "Size mismatch for UDelMarActionWidget");
static_assert(offsetof(UDelMarActionWidget, OnInputMethodChanged) == 0x158, "Offset mismatch for UDelMarActionWidget::OnInputMethodChanged");
static_assert(offsetof(UDelMarActionWidget, ProgressMaterialBrush) == 0x170, "Offset mismatch for UDelMarActionWidget::ProgressMaterialBrush");
static_assert(offsetof(UDelMarActionWidget, ProgressMaterialParam) == 0x220, "Offset mismatch for UDelMarActionWidget::ProgressMaterialParam");
static_assert(offsetof(UDelMarActionWidget, IconRimBrush) == 0x230, "Offset mismatch for UDelMarActionWidget::IconRimBrush");
static_assert(offsetof(UDelMarActionWidget, InputActions) == 0x2e0, "Offset mismatch for UDelMarActionWidget::InputActions");
static_assert(offsetof(UDelMarActionWidget, EnhancedInputAction) == 0x2f0, "Offset mismatch for UDelMarActionWidget::EnhancedInputAction");
static_assert(offsetof(UDelMarActionWidget, ProgressDynamicMaterial) == 0x300, "Offset mismatch for UDelMarActionWidget::ProgressDynamicMaterial");

// Size: 0x420 (Inherited: 0xb38, Single: 0xfffff8e8)
class UDelMarDialogBase : public UCommonActivatableWidget
{
public:

public:
    void DismissDialog(); // 0x11d4db28 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarDialogBase) == 0x420, "Size mismatch for UDelMarDialogBase");

// Size: 0x78 (Inherited: 0x28, Single: 0x50)
class UDelMarDialogHelper : public UObject
{
public:
    TMap<TSoftClassPtr, FGameplayTag> DialogMapping; // 0x28 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(UDelMarDialogHelper) == 0x78, "Size mismatch for UDelMarDialogHelper");
static_assert(offsetof(UDelMarDialogHelper, DialogMapping) == 0x28, "Offset mismatch for UDelMarDialogHelper::DialogMapping");

// Size: 0x410 (Inherited: 0xb38, Single: 0xfffff8d8)
class UDelMarInputConfigWidgetBase : public UCommonActivatableWidget
{
public:
    FUIInputConfig DesiredInputConfig; // 0x408 (Size: 0x6, Type: StructProperty)
    bool bFlushPlayerInputWhenActivating; // 0x40e (Size: 0x1, Type: BoolProperty)
    bool bFlushPlayerInputWhenDeactivating; // 0x40f (Size: 0x1, Type: BoolProperty)
};

static_assert(sizeof(UDelMarInputConfigWidgetBase) == 0x410, "Size mismatch for UDelMarInputConfigWidgetBase");
static_assert(offsetof(UDelMarInputConfigWidgetBase, DesiredInputConfig) == 0x408, "Offset mismatch for UDelMarInputConfigWidgetBase::DesiredInputConfig");
static_assert(offsetof(UDelMarInputConfigWidgetBase, bFlushPlayerInputWhenActivating) == 0x40e, "Offset mismatch for UDelMarInputConfigWidgetBase::bFlushPlayerInputWhenActivating");
static_assert(offsetof(UDelMarInputConfigWidgetBase, bFlushPlayerInputWhenDeactivating) == 0x40f, "Offset mismatch for UDelMarInputConfigWidgetBase::bFlushPlayerInputWhenDeactivating");

// Size: 0x128 (Inherited: 0x28, Single: 0x100)
class UDelMarLoadingScreenHelper : public UObject
{
public:
    FVector2D BackgroundDesiredSize; // 0x28 (Size: 0x10, Type: StructProperty)
    TSoftClassPtr CustomLoadingWidget; // 0x38 (Size: 0x20, Type: SoftClassProperty)
    FZoneLoadingScreenConfig ZoneConfig; // 0x58 (Size: 0xd0, Type: StructProperty)

public:
    void PrepareDelMarLoadingScreen(UObject*& WorldContextObject); // 0x11d4eac4 (Index: 0x0, Flags: Final|BlueprintCosmetic|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarLoadingScreenHelper) == 0x128, "Size mismatch for UDelMarLoadingScreenHelper");
static_assert(offsetof(UDelMarLoadingScreenHelper, BackgroundDesiredSize) == 0x28, "Offset mismatch for UDelMarLoadingScreenHelper::BackgroundDesiredSize");
static_assert(offsetof(UDelMarLoadingScreenHelper, CustomLoadingWidget) == 0x38, "Offset mismatch for UDelMarLoadingScreenHelper::CustomLoadingWidget");
static_assert(offsetof(UDelMarLoadingScreenHelper, ZoneConfig) == 0x58, "Offset mismatch for UDelMarLoadingScreenHelper::ZoneConfig");

// Size: 0x2e0 (Inherited: 0x598, Single: 0xfffffd48)
class ADelMarUIDirector : public ADynamicUIDirectorBase
{
public:
    UClass* DialogHelperClass; // 0x2c8 (Size: 0x8, Type: ClassProperty)
    uint8_t Pad_2d0[0x8]; // 0x2d0 (Size: 0x8, Type: PaddingProperty)
    UDelMarDialogHelper* DialogHelper; // 0x2d8 (Size: 0x8, Type: ObjectProperty)

public:
    void SetLoadingScreenVisibiliy(bool& bVisible); // 0x11dc3cbc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(ADelMarUIDirector) == 0x2e0, "Size mismatch for ADelMarUIDirector");
static_assert(offsetof(ADelMarUIDirector, DialogHelperClass) == 0x2c8, "Offset mismatch for ADelMarUIDirector::DialogHelperClass");
static_assert(offsetof(ADelMarUIDirector, DialogHelper) == 0x2d8, "Offset mismatch for ADelMarUIDirector::DialogHelper");

// Size: 0x28 (Inherited: 0x28, Single: 0x0)
class UDelMarUIGlobals : public UObject
{
public:
};

static_assert(sizeof(UDelMarUIGlobals) == 0x28, "Size mismatch for UDelMarUIGlobals");

// Size: 0x300 (Inherited: 0x2d0, Single: 0x30)
class ADelMarAttachedWidgetActor : public AActor
{
public:
    float DriftFollowDampening; // 0x2a8 (Size: 0x4, Type: FloatProperty)
    float WallFollowDampening; // 0x2ac (Size: 0x4, Type: FloatProperty)
    float RotateDampeningRate; // 0x2b0 (Size: 0x4, Type: FloatProperty)
    TWeakObjectPtr<APlayerState*> ViewPlayerState; // 0x2b4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<USceneComponent*> AttachedTarget; // 0x2bc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> AttachedVehicle; // 0x2c4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<APlayerCameraManager*> CameraManager; // 0x2cc (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_2d4[0x4]; // 0x2d4 (Size: 0x4, Type: PaddingProperty)
    USceneComponent* AttachmentBaseComponent; // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UDelMarWidgetComponent* SpeedometerWidget; // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UDelMarWidgetComponent* DriftBoostWidget; // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UDelMarWidgetComponent* UnderthrustWidget; // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_2f8[0x8]; // 0x2f8 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(ADelMarAttachedWidgetActor) == 0x300, "Size mismatch for ADelMarAttachedWidgetActor");
static_assert(offsetof(ADelMarAttachedWidgetActor, DriftFollowDampening) == 0x2a8, "Offset mismatch for ADelMarAttachedWidgetActor::DriftFollowDampening");
static_assert(offsetof(ADelMarAttachedWidgetActor, WallFollowDampening) == 0x2ac, "Offset mismatch for ADelMarAttachedWidgetActor::WallFollowDampening");
static_assert(offsetof(ADelMarAttachedWidgetActor, RotateDampeningRate) == 0x2b0, "Offset mismatch for ADelMarAttachedWidgetActor::RotateDampeningRate");
static_assert(offsetof(ADelMarAttachedWidgetActor, ViewPlayerState) == 0x2b4, "Offset mismatch for ADelMarAttachedWidgetActor::ViewPlayerState");
static_assert(offsetof(ADelMarAttachedWidgetActor, AttachedTarget) == 0x2bc, "Offset mismatch for ADelMarAttachedWidgetActor::AttachedTarget");
static_assert(offsetof(ADelMarAttachedWidgetActor, AttachedVehicle) == 0x2c4, "Offset mismatch for ADelMarAttachedWidgetActor::AttachedVehicle");
static_assert(offsetof(ADelMarAttachedWidgetActor, CameraManager) == 0x2cc, "Offset mismatch for ADelMarAttachedWidgetActor::CameraManager");
static_assert(offsetof(ADelMarAttachedWidgetActor, AttachmentBaseComponent) == 0x2d8, "Offset mismatch for ADelMarAttachedWidgetActor::AttachmentBaseComponent");
static_assert(offsetof(ADelMarAttachedWidgetActor, SpeedometerWidget) == 0x2e0, "Offset mismatch for ADelMarAttachedWidgetActor::SpeedometerWidget");
static_assert(offsetof(ADelMarAttachedWidgetActor, DriftBoostWidget) == 0x2e8, "Offset mismatch for ADelMarAttachedWidgetActor::DriftBoostWidget");
static_assert(offsetof(ADelMarAttachedWidgetActor, UnderthrustWidget) == 0x2f0, "Offset mismatch for ADelMarAttachedWidgetActor::UnderthrustWidget");

// Size: 0xd8 (Inherited: 0x250, Single: 0xfffffe88)
class UDelMarAttachedWidgetComponent : public UControllerComponent
{
public:
    TArray<UClass*> AttachedWidgetActorsClass; // 0xb8 (Size: 0x10, Type: ArrayProperty)
    TArray<ADelMarAttachedWidgetActor*> AttachedWidgetActors; // 0xc8 (Size: 0x10, Type: ArrayProperty)

protected:
    void HandleViewTargetChanged(AFortPlayerController*& InController, AActor*& OldViewTarget, AActor*& NewViewTarget); // 0x11dc270c (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarAttachedWidgetComponent) == 0xd8, "Size mismatch for UDelMarAttachedWidgetComponent");
static_assert(offsetof(UDelMarAttachedWidgetComponent, AttachedWidgetActorsClass) == 0xb8, "Offset mismatch for UDelMarAttachedWidgetComponent::AttachedWidgetActorsClass");
static_assert(offsetof(UDelMarAttachedWidgetComponent, AttachedWidgetActors) == 0xc8, "Offset mismatch for UDelMarAttachedWidgetComponent::AttachedWidgetActors");

// Size: 0x6c0 (Inherited: 0x1440, Single: 0xfffff280)
class UDelMarWidgetComponent : public UWidgetComponent
{
public:
    FVector2D LeftTopPadding; // 0x6a0 (Size: 0x10, Type: StructProperty)
    FVector2D RightBottomPadding; // 0x6b0 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(UDelMarWidgetComponent) == 0x6c0, "Size mismatch for UDelMarWidgetComponent");
static_assert(offsetof(UDelMarWidgetComponent, LeftTopPadding) == 0x6a0, "Offset mismatch for UDelMarWidgetComponent::LeftTopPadding");
static_assert(offsetof(UDelMarWidgetComponent, RightBottomPadding) == 0x6b0, "Offset mismatch for UDelMarWidgetComponent::RightBottomPadding");

// Size: 0x4c8 (Inherited: 0xfc0, Single: 0xfffff508)
class UDelMarDebugCountdown : public UDelMarScreenBase
{
public:
    UCommonRichTextBlock* CountdownText; // 0x488 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_490[0x38]; // 0x490 (Size: 0x38, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarDebugCountdown) == 0x4c8, "Size mismatch for UDelMarDebugCountdown");
static_assert(offsetof(UDelMarDebugCountdown, CountdownText) == 0x488, "Offset mismatch for UDelMarDebugCountdown::CountdownText");

// Size: 0x398 (Inherited: 0xa80, Single: 0xfffff918)
class UDelMarStartlineCountdownWidget : public UDelMarUserWidget
{
public:
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle; // 0x350 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AActor*> CurrentViewTarget; // 0x358 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_360[0x38]; // 0x360 (Size: 0x38, Type: PaddingProperty)

public:
    virtual void BP_OnActiveIntervalsChanged(int32_t& NumActiveIntervals); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnCountdownStarted(int32_t& TotalIntervals); // 0x288a61c (Index: 0x1, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnStartlineBoostActivated(float& PercentageMaxBonusSpeedEarned); // 0x288a61c (Index: 0x2, Flags: Event|Public|BlueprintEvent)
    virtual void BP_OnStartlineBoostFailed(); // 0x288a61c (Index: 0x3, Flags: Event|Public|BlueprintEvent)

protected:
    int32_t GetNumActiveIntervals() const; // 0x11dc06bc (Index: 0x4, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    int32_t GetNumTotalIntervals() const; // 0x11dc06e0 (Index: 0x5, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
    void HandleViewTargetChanged(AFortPlayerController*& PC, AActor*& Old, AActor*& NewViewTarget); // 0x11dc2cd4 (Index: 0x6, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarStartlineCountdownWidget) == 0x398, "Size mismatch for UDelMarStartlineCountdownWidget");
static_assert(offsetof(UDelMarStartlineCountdownWidget, CachedDelMarVehicle) == 0x350, "Offset mismatch for UDelMarStartlineCountdownWidget::CachedDelMarVehicle");
static_assert(offsetof(UDelMarStartlineCountdownWidget, CurrentViewTarget) == 0x358, "Offset mismatch for UDelMarStartlineCountdownWidget::CurrentViewTarget");

// Size: 0x370 (Inherited: 0xa80, Single: 0xfffff8f0)
class UDelMarCheckpointTrackerEntryWidget : public UDelMarUserWidget
{
public:
    UWidgetAnimation* AnimTransitionIn; // 0x350 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_358[0x18]; // 0x358 (Size: 0x18, Type: PaddingProperty)

public:
    virtual void BP_OnDisplayedCheckpointChanged(const FDelMarSectionData InSectionData, bool& const bNewEntry); // 0x288a61c (Index: 0x0, Flags: Event|Public|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UDelMarCheckpointTrackerEntryWidget) == 0x370, "Size mismatch for UDelMarCheckpointTrackerEntryWidget");
static_assert(offsetof(UDelMarCheckpointTrackerEntryWidget, AnimTransitionIn) == 0x350, "Offset mismatch for UDelMarCheckpointTrackerEntryWidget::AnimTransitionIn");

// Size: 0x398 (Inherited: 0xa80, Single: 0xfffff918)
class UDelMarCheckpointTrackerWidget : public UDelMarUserWidget
{
public:
    UClass* CheckpointTrackerEntryClass; // 0x350 (Size: 0x8, Type: ClassProperty)
    int32_t NumDesignerPreviewEntries; // 0x358 (Size: 0x4, Type: IntProperty)
    float EntrySpacing; // 0x35c (Size: 0x4, Type: FloatProperty)
    int32_t MaxEntriesToDisplay; // 0x360 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_364[0x4]; // 0x364 (Size: 0x4, Type: PaddingProperty)
    UOverlay* CheckpointEntryOverlay; // 0x368 (Size: 0x8, Type: ObjectProperty)
    URetainerBox* EdgeFadeRetainerBox; // 0x370 (Size: 0x8, Type: ObjectProperty)
    USizeBox* TrackerSizeBox; // 0x378 (Size: 0x8, Type: ObjectProperty)
    TArray<UDelMarCheckpointTrackerEntryWidget*> DisplayedCheckpointTrackerEntries; // 0x380 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_390[0x8]; // 0x390 (Size: 0x8, Type: PaddingProperty)

protected:
    void UpdateCheckpoints(TArray<FDelMarSectionData>& InCheckpoints); // 0x11dc3f78 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarCheckpointTrackerWidget) == 0x398, "Size mismatch for UDelMarCheckpointTrackerWidget");
static_assert(offsetof(UDelMarCheckpointTrackerWidget, CheckpointTrackerEntryClass) == 0x350, "Offset mismatch for UDelMarCheckpointTrackerWidget::CheckpointTrackerEntryClass");
static_assert(offsetof(UDelMarCheckpointTrackerWidget, NumDesignerPreviewEntries) == 0x358, "Offset mismatch for UDelMarCheckpointTrackerWidget::NumDesignerPreviewEntries");
static_assert(offsetof(UDelMarCheckpointTrackerWidget, EntrySpacing) == 0x35c, "Offset mismatch for UDelMarCheckpointTrackerWidget::EntrySpacing");
static_assert(offsetof(UDelMarCheckpointTrackerWidget, MaxEntriesToDisplay) == 0x360, "Offset mismatch for UDelMarCheckpointTrackerWidget::MaxEntriesToDisplay");
static_assert(offsetof(UDelMarCheckpointTrackerWidget, CheckpointEntryOverlay) == 0x368, "Offset mismatch for UDelMarCheckpointTrackerWidget::CheckpointEntryOverlay");
static_assert(offsetof(UDelMarCheckpointTrackerWidget, EdgeFadeRetainerBox) == 0x370, "Offset mismatch for UDelMarCheckpointTrackerWidget::EdgeFadeRetainerBox");
static_assert(offsetof(UDelMarCheckpointTrackerWidget, TrackerSizeBox) == 0x378, "Offset mismatch for UDelMarCheckpointTrackerWidget::TrackerSizeBox");
static_assert(offsetof(UDelMarCheckpointTrackerWidget, DisplayedCheckpointTrackerEntries) == 0x380, "Offset mismatch for UDelMarCheckpointTrackerWidget::DisplayedCheckpointTrackerEntries");

// Size: 0x498 (Inherited: 0xfc0, Single: 0xfffff4d8)
class UDelMarBladeMenuContainer : public UDelMarScreenBase
{
public:
    UFortDualBladeMenu* DualBladeMenu; // 0x488 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag CloseBladeMenuTriggerTag; // 0x490 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_494[0x4]; // 0x494 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarBladeMenuContainer) == 0x498, "Size mismatch for UDelMarBladeMenuContainer");
static_assert(offsetof(UDelMarBladeMenuContainer, DualBladeMenu) == 0x488, "Offset mismatch for UDelMarBladeMenuContainer::DualBladeMenu");
static_assert(offsetof(UDelMarBladeMenuContainer, CloseBladeMenuTriggerTag) == 0x490, "Offset mismatch for UDelMarBladeMenuContainer::CloseBladeMenuTriggerTag");

// Size: 0x4b8 (Inherited: 0xfc0, Single: 0xfffff4f8)
class UDelMarCheckpointTimer : public UDelMarScreenBase
{
public:
    UCommonTextBlock* Text_LapCount; // 0x488 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_CheckpointIndex; // 0x490 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Timestamp; // 0x498 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_LapTimestamp; // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_4a8[0x10]; // 0x4a8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarCheckpointTimer) == 0x4b8, "Size mismatch for UDelMarCheckpointTimer");
static_assert(offsetof(UDelMarCheckpointTimer, Text_LapCount) == 0x488, "Offset mismatch for UDelMarCheckpointTimer::Text_LapCount");
static_assert(offsetof(UDelMarCheckpointTimer, Text_CheckpointIndex) == 0x490, "Offset mismatch for UDelMarCheckpointTimer::Text_CheckpointIndex");
static_assert(offsetof(UDelMarCheckpointTimer, Text_Timestamp) == 0x498, "Offset mismatch for UDelMarCheckpointTimer::Text_Timestamp");
static_assert(offsetof(UDelMarCheckpointTimer, Text_LapTimestamp) == 0x4a0, "Offset mismatch for UDelMarCheckpointTimer::Text_LapTimestamp");

// Size: 0x3b0 (Inherited: 0xa80, Single: 0xfffff930)
class UDelMarDebugPointWidget : public UDelMarUserWidget
{
public:
    FString PlayerPointsString; // 0x350 (Size: 0x10, Type: StrProperty)
    uint8_t Pad_360[0x50]; // 0x360 (Size: 0x50, Type: PaddingProperty)

public:
    virtual void BP_OnPointsUpdated(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UDelMarDebugPointWidget) == 0x3b0, "Size mismatch for UDelMarDebugPointWidget");
static_assert(offsetof(UDelMarDebugPointWidget, PlayerPointsString) == 0x350, "Offset mismatch for UDelMarDebugPointWidget::PlayerPointsString");

// Size: 0x398 (Inherited: 0xa80, Single: 0xfffff918)
class UDelMarDebugRubberbandingWidget : public UDelMarUserWidget
{
public:
    bool bRubberbandingEnabled; // 0x350 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_351[0x3]; // 0x351 (Size: 0x3, Type: PaddingProperty)
    float PackDistance; // 0x354 (Size: 0x4, Type: FloatProperty)
    float MinPackDistance; // 0x358 (Size: 0x4, Type: FloatProperty)
    float MaxPackDistance; // 0x35c (Size: 0x4, Type: FloatProperty)
    float DistanceToPack; // 0x360 (Size: 0x4, Type: FloatProperty)
    float MinDistanceFromPack; // 0x364 (Size: 0x4, Type: FloatProperty)
    float MaxDistanceFromPack; // 0x368 (Size: 0x4, Type: FloatProperty)
    float MinSpeed; // 0x36c (Size: 0x4, Type: FloatProperty)
    float StableSpeed; // 0x370 (Size: 0x4, Type: FloatProperty)
    float AppliedBonusSpeed; // 0x374 (Size: 0x4, Type: FloatProperty)
    float DistanceToPackRatio; // 0x378 (Size: 0x4, Type: FloatProperty)
    float MaxBonusSpeedAtPosition; // 0x37c (Size: 0x4, Type: FloatProperty)
    float MaxSpeedAtPosition; // 0x380 (Size: 0x4, Type: FloatProperty)
    float MaxAllowedBonusSpeed; // 0x384 (Size: 0x4, Type: FloatProperty)
    float BonusSpeedGainedPerSecond; // 0x388 (Size: 0x4, Type: FloatProperty)
    float BonusSpeedLostPerSecond; // 0x38c (Size: 0x4, Type: FloatProperty)
    int32_t MMRUsed; // 0x390 (Size: 0x4, Type: IntProperty)
    float MaxBonusSpeedScalar; // 0x394 (Size: 0x4, Type: FloatProperty)

public:
    virtual void BP_OnRubberbandingUpdated(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UDelMarDebugRubberbandingWidget) == 0x398, "Size mismatch for UDelMarDebugRubberbandingWidget");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, bRubberbandingEnabled) == 0x350, "Offset mismatch for UDelMarDebugRubberbandingWidget::bRubberbandingEnabled");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, PackDistance) == 0x354, "Offset mismatch for UDelMarDebugRubberbandingWidget::PackDistance");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, MinPackDistance) == 0x358, "Offset mismatch for UDelMarDebugRubberbandingWidget::MinPackDistance");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, MaxPackDistance) == 0x35c, "Offset mismatch for UDelMarDebugRubberbandingWidget::MaxPackDistance");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, DistanceToPack) == 0x360, "Offset mismatch for UDelMarDebugRubberbandingWidget::DistanceToPack");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, MinDistanceFromPack) == 0x364, "Offset mismatch for UDelMarDebugRubberbandingWidget::MinDistanceFromPack");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, MaxDistanceFromPack) == 0x368, "Offset mismatch for UDelMarDebugRubberbandingWidget::MaxDistanceFromPack");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, MinSpeed) == 0x36c, "Offset mismatch for UDelMarDebugRubberbandingWidget::MinSpeed");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, StableSpeed) == 0x370, "Offset mismatch for UDelMarDebugRubberbandingWidget::StableSpeed");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, AppliedBonusSpeed) == 0x374, "Offset mismatch for UDelMarDebugRubberbandingWidget::AppliedBonusSpeed");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, DistanceToPackRatio) == 0x378, "Offset mismatch for UDelMarDebugRubberbandingWidget::DistanceToPackRatio");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, MaxBonusSpeedAtPosition) == 0x37c, "Offset mismatch for UDelMarDebugRubberbandingWidget::MaxBonusSpeedAtPosition");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, MaxSpeedAtPosition) == 0x380, "Offset mismatch for UDelMarDebugRubberbandingWidget::MaxSpeedAtPosition");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, MaxAllowedBonusSpeed) == 0x384, "Offset mismatch for UDelMarDebugRubberbandingWidget::MaxAllowedBonusSpeed");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, BonusSpeedGainedPerSecond) == 0x388, "Offset mismatch for UDelMarDebugRubberbandingWidget::BonusSpeedGainedPerSecond");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, BonusSpeedLostPerSecond) == 0x38c, "Offset mismatch for UDelMarDebugRubberbandingWidget::BonusSpeedLostPerSecond");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, MMRUsed) == 0x390, "Offset mismatch for UDelMarDebugRubberbandingWidget::MMRUsed");
static_assert(offsetof(UDelMarDebugRubberbandingWidget, MaxBonusSpeedScalar) == 0x394, "Offset mismatch for UDelMarDebugRubberbandingWidget::MaxBonusSpeedScalar");

// Size: 0x360 (Inherited: 0xa80, Single: 0xfffff8e0)
class UDelMarDebugVehicleHealthWidget : public UDelMarUserWidget
{
public:
    float CurrentHealth; // 0x350 (Size: 0x4, Type: FloatProperty)
    float MaxHealth; // 0x354 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_358[0x8]; // 0x358 (Size: 0x8, Type: PaddingProperty)

public:
    virtual void BP_OnHealthUpdated(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)

protected:
    void HandleVehicleHealthChanged(); // 0x11dc26e4 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarDebugVehicleHealthWidget) == 0x360, "Size mismatch for UDelMarDebugVehicleHealthWidget");
static_assert(offsetof(UDelMarDebugVehicleHealthWidget, CurrentHealth) == 0x350, "Offset mismatch for UDelMarDebugVehicleHealthWidget::CurrentHealth");
static_assert(offsetof(UDelMarDebugVehicleHealthWidget, MaxHealth) == 0x354, "Offset mismatch for UDelMarDebugVehicleHealthWidget::MaxHealth");

// Size: 0x418 (Inherited: 0xa80, Single: 0xfffff998)
class UDelMarDebugVehicleWidget : public UDelMarUserWidget
{
public:
    float BaseTargetSpeed; // 0x350 (Size: 0x4, Type: FloatProperty)
    float FinalTargetSpeed; // 0x354 (Size: 0x4, Type: FloatProperty)
    float OversteerPercentage; // 0x358 (Size: 0x4, Type: FloatProperty)
    bool bHasValidDraftingTarget; // 0x35c (Size: 0x1, Type: BoolProperty)
    uint8_t DraftingState; // 0x35d (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_35e[0x2]; // 0x35e (Size: 0x2, Type: PaddingProperty)
    float DraftingBonusSpeed; // 0x360 (Size: 0x4, Type: FloatProperty)
    float DraftingTargetDegrees; // 0x364 (Size: 0x4, Type: FloatProperty)
    float DraftingCurrentBonusSpeedPercentage; // 0x368 (Size: 0x4, Type: FloatProperty)
    float DraftingMaxBonusSpeedPercentage; // 0x36c (Size: 0x4, Type: FloatProperty)
    float SecondsInDrift; // 0x370 (Size: 0x4, Type: FloatProperty)
    float AccumulatedWaitingPeriodSeconds; // 0x374 (Size: 0x4, Type: FloatProperty)
    float DriftBoostBonusSpeed; // 0x378 (Size: 0x4, Type: FloatProperty)
    float DriftBoostDuration; // 0x37c (Size: 0x4, Type: FloatProperty)
    float DriftBoostDurationSecondsLeft; // 0x380 (Size: 0x4, Type: FloatProperty)
    float PotentialDriftBoostBonusSpeed; // 0x384 (Size: 0x4, Type: FloatProperty)
    float PotentialDriftBoostDuration; // 0x388 (Size: 0x4, Type: FloatProperty)
    float QueuedDriftBoostBonusSpeed; // 0x38c (Size: 0x4, Type: FloatProperty)
    float StartlineBonusSpeed; // 0x390 (Size: 0x4, Type: FloatProperty)
    float TurboBonusSpeed; // 0x394 (Size: 0x4, Type: FloatProperty)
    float TurboZoneBonusSpeed; // 0x398 (Size: 0x4, Type: FloatProperty)
    float TurboSecondsRemaining; // 0x39c (Size: 0x4, Type: FloatProperty)
    float TurboCharges; // 0x3a0 (Size: 0x4, Type: FloatProperty)
    float WorldBonusSpeed; // 0x3a4 (Size: 0x4, Type: FloatProperty)
    float TotalBonusSpeed; // 0x3a8 (Size: 0x4, Type: FloatProperty)
    FDelMarTerrainData TerrainData; // 0x3ac (Size: 0x18, Type: StructProperty)
    int32_t NumWheelWorldContacts; // 0x3c4 (Size: 0x4, Type: IntProperty)
    FVector AverageWheelWorldContactNormal; // 0x3c8 (Size: 0x18, Type: StructProperty)
    float MinimumLandingSpeed; // 0x3e0 (Size: 0x4, Type: FloatProperty)
    float BaseForwardSpeed; // 0x3e4 (Size: 0x4, Type: FloatProperty)
    float StableSpeed; // 0x3e8 (Size: 0x4, Type: FloatProperty)
    float UpwardSpeed; // 0x3ec (Size: 0x4, Type: FloatProperty)
    float VehicleSpeed; // 0x3f0 (Size: 0x4, Type: FloatProperty)
    bool bInvertedSteeringActive; // 0x3f4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_3f5[0x3]; // 0x3f5 (Size: 0x3, Type: PaddingProperty)
    float MaxForwardSpeed; // 0x3f8 (Size: 0x4, Type: FloatProperty)
    float SecondsSinceTerrainPenalty; // 0x3fc (Size: 0x4, Type: FloatProperty)
    int32_t KickflipActivationCharges; // 0x400 (Size: 0x4, Type: IntProperty)
    bool bStrafeDisabled; // 0x404 (Size: 0x1, Type: BoolProperty)
    bool bCanActivateStrafe; // 0x405 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_406[0x2]; // 0x406 (Size: 0x2, Type: PaddingProperty)
    float StrafeCooldownSeconds; // 0x408 (Size: 0x4, Type: FloatProperty)
    float StrafeCooldownPercentage; // 0x40c (Size: 0x4, Type: FloatProperty)
    float VehicleMass; // 0x410 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_414[0x4]; // 0x414 (Size: 0x4, Type: PaddingProperty)

public:
    virtual void BP_OnVehicleUpdated(); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)
};

static_assert(sizeof(UDelMarDebugVehicleWidget) == 0x418, "Size mismatch for UDelMarDebugVehicleWidget");
static_assert(offsetof(UDelMarDebugVehicleWidget, BaseTargetSpeed) == 0x350, "Offset mismatch for UDelMarDebugVehicleWidget::BaseTargetSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, FinalTargetSpeed) == 0x354, "Offset mismatch for UDelMarDebugVehicleWidget::FinalTargetSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, OversteerPercentage) == 0x358, "Offset mismatch for UDelMarDebugVehicleWidget::OversteerPercentage");
static_assert(offsetof(UDelMarDebugVehicleWidget, bHasValidDraftingTarget) == 0x35c, "Offset mismatch for UDelMarDebugVehicleWidget::bHasValidDraftingTarget");
static_assert(offsetof(UDelMarDebugVehicleWidget, DraftingState) == 0x35d, "Offset mismatch for UDelMarDebugVehicleWidget::DraftingState");
static_assert(offsetof(UDelMarDebugVehicleWidget, DraftingBonusSpeed) == 0x360, "Offset mismatch for UDelMarDebugVehicleWidget::DraftingBonusSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, DraftingTargetDegrees) == 0x364, "Offset mismatch for UDelMarDebugVehicleWidget::DraftingTargetDegrees");
static_assert(offsetof(UDelMarDebugVehicleWidget, DraftingCurrentBonusSpeedPercentage) == 0x368, "Offset mismatch for UDelMarDebugVehicleWidget::DraftingCurrentBonusSpeedPercentage");
static_assert(offsetof(UDelMarDebugVehicleWidget, DraftingMaxBonusSpeedPercentage) == 0x36c, "Offset mismatch for UDelMarDebugVehicleWidget::DraftingMaxBonusSpeedPercentage");
static_assert(offsetof(UDelMarDebugVehicleWidget, SecondsInDrift) == 0x370, "Offset mismatch for UDelMarDebugVehicleWidget::SecondsInDrift");
static_assert(offsetof(UDelMarDebugVehicleWidget, AccumulatedWaitingPeriodSeconds) == 0x374, "Offset mismatch for UDelMarDebugVehicleWidget::AccumulatedWaitingPeriodSeconds");
static_assert(offsetof(UDelMarDebugVehicleWidget, DriftBoostBonusSpeed) == 0x378, "Offset mismatch for UDelMarDebugVehicleWidget::DriftBoostBonusSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, DriftBoostDuration) == 0x37c, "Offset mismatch for UDelMarDebugVehicleWidget::DriftBoostDuration");
static_assert(offsetof(UDelMarDebugVehicleWidget, DriftBoostDurationSecondsLeft) == 0x380, "Offset mismatch for UDelMarDebugVehicleWidget::DriftBoostDurationSecondsLeft");
static_assert(offsetof(UDelMarDebugVehicleWidget, PotentialDriftBoostBonusSpeed) == 0x384, "Offset mismatch for UDelMarDebugVehicleWidget::PotentialDriftBoostBonusSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, PotentialDriftBoostDuration) == 0x388, "Offset mismatch for UDelMarDebugVehicleWidget::PotentialDriftBoostDuration");
static_assert(offsetof(UDelMarDebugVehicleWidget, QueuedDriftBoostBonusSpeed) == 0x38c, "Offset mismatch for UDelMarDebugVehicleWidget::QueuedDriftBoostBonusSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, StartlineBonusSpeed) == 0x390, "Offset mismatch for UDelMarDebugVehicleWidget::StartlineBonusSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, TurboBonusSpeed) == 0x394, "Offset mismatch for UDelMarDebugVehicleWidget::TurboBonusSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, TurboZoneBonusSpeed) == 0x398, "Offset mismatch for UDelMarDebugVehicleWidget::TurboZoneBonusSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, TurboSecondsRemaining) == 0x39c, "Offset mismatch for UDelMarDebugVehicleWidget::TurboSecondsRemaining");
static_assert(offsetof(UDelMarDebugVehicleWidget, TurboCharges) == 0x3a0, "Offset mismatch for UDelMarDebugVehicleWidget::TurboCharges");
static_assert(offsetof(UDelMarDebugVehicleWidget, WorldBonusSpeed) == 0x3a4, "Offset mismatch for UDelMarDebugVehicleWidget::WorldBonusSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, TotalBonusSpeed) == 0x3a8, "Offset mismatch for UDelMarDebugVehicleWidget::TotalBonusSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, TerrainData) == 0x3ac, "Offset mismatch for UDelMarDebugVehicleWidget::TerrainData");
static_assert(offsetof(UDelMarDebugVehicleWidget, NumWheelWorldContacts) == 0x3c4, "Offset mismatch for UDelMarDebugVehicleWidget::NumWheelWorldContacts");
static_assert(offsetof(UDelMarDebugVehicleWidget, AverageWheelWorldContactNormal) == 0x3c8, "Offset mismatch for UDelMarDebugVehicleWidget::AverageWheelWorldContactNormal");
static_assert(offsetof(UDelMarDebugVehicleWidget, MinimumLandingSpeed) == 0x3e0, "Offset mismatch for UDelMarDebugVehicleWidget::MinimumLandingSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, BaseForwardSpeed) == 0x3e4, "Offset mismatch for UDelMarDebugVehicleWidget::BaseForwardSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, StableSpeed) == 0x3e8, "Offset mismatch for UDelMarDebugVehicleWidget::StableSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, UpwardSpeed) == 0x3ec, "Offset mismatch for UDelMarDebugVehicleWidget::UpwardSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, VehicleSpeed) == 0x3f0, "Offset mismatch for UDelMarDebugVehicleWidget::VehicleSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, bInvertedSteeringActive) == 0x3f4, "Offset mismatch for UDelMarDebugVehicleWidget::bInvertedSteeringActive");
static_assert(offsetof(UDelMarDebugVehicleWidget, MaxForwardSpeed) == 0x3f8, "Offset mismatch for UDelMarDebugVehicleWidget::MaxForwardSpeed");
static_assert(offsetof(UDelMarDebugVehicleWidget, SecondsSinceTerrainPenalty) == 0x3fc, "Offset mismatch for UDelMarDebugVehicleWidget::SecondsSinceTerrainPenalty");
static_assert(offsetof(UDelMarDebugVehicleWidget, KickflipActivationCharges) == 0x400, "Offset mismatch for UDelMarDebugVehicleWidget::KickflipActivationCharges");
static_assert(offsetof(UDelMarDebugVehicleWidget, bStrafeDisabled) == 0x404, "Offset mismatch for UDelMarDebugVehicleWidget::bStrafeDisabled");
static_assert(offsetof(UDelMarDebugVehicleWidget, bCanActivateStrafe) == 0x405, "Offset mismatch for UDelMarDebugVehicleWidget::bCanActivateStrafe");
static_assert(offsetof(UDelMarDebugVehicleWidget, StrafeCooldownSeconds) == 0x408, "Offset mismatch for UDelMarDebugVehicleWidget::StrafeCooldownSeconds");
static_assert(offsetof(UDelMarDebugVehicleWidget, StrafeCooldownPercentage) == 0x40c, "Offset mismatch for UDelMarDebugVehicleWidget::StrafeCooldownPercentage");
static_assert(offsetof(UDelMarDebugVehicleWidget, VehicleMass) == 0x410, "Offset mismatch for UDelMarDebugVehicleWidget::VehicleMass");

// Size: 0x490 (Inherited: 0xfc0, Single: 0xfffff4d0)
class UDelMarEmotePickerContainer : public UDelMarScreenBase
{
public:
    FGameplayTag CloseEmotePickerTriggerTag; // 0x488 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_48c[0x4]; // 0x48c (Size: 0x4, Type: PaddingProperty)

protected:
    void CloseEmotePickerContainer(); // 0x11dc0678 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarEmotePickerContainer) == 0x490, "Size mismatch for UDelMarEmotePickerContainer");
static_assert(offsetof(UDelMarEmotePickerContainer, CloseEmotePickerTriggerTag) == 0x488, "Offset mismatch for UDelMarEmotePickerContainer::CloseEmotePickerTriggerTag");

// Size: 0x2b0 (Inherited: 0x458, Single: 0xfffffe58)
class UDelMarReadyUpWidget : public UUserWidget
{
public:

public:
    void BP_ReadyUp(bool& const bReady); // 0x11dc03f4 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)

protected:
    virtual void BP_OnReadyUpChanged(bool& bReady); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UDelMarReadyUpWidget) == 0x2b0, "Size mismatch for UDelMarReadyUpWidget");

// Size: 0x358 (Inherited: 0xa80, Single: 0xfffff8d8)
class UDelMarTurboBonusZoneWidget : public UDelMarUserWidget
{
public:
    TWeakObjectPtr<ADelMarVehicle*> CachedDelMarVehicle; // 0x350 (Size: 0x8, Type: WeakObjectProperty)

public:
    virtual void BP_OnTurboZoneStateChanged(EDelMarTurboZoneState& NewState); // 0x288a61c (Index: 0x0, Flags: Event|Public|BlueprintEvent)

protected:
    void HandleTurboStateChange(EDelMarTurboZoneState& NewState); // 0x11dc2458 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarTurboBonusZoneWidget) == 0x358, "Size mismatch for UDelMarTurboBonusZoneWidget");
static_assert(offsetof(UDelMarTurboBonusZoneWidget, CachedDelMarVehicle) == 0x350, "Offset mismatch for UDelMarTurboBonusZoneWidget::CachedDelMarVehicle");

// Size: 0x320 (Inherited: 0xa48, Single: 0xfffff8d8)
class UDelMarInteractionIndicatorContainer : public UFortHUDElementWidget
{
public:
    UFortActorCanvas* VehicleIndicators; // 0x318 (Size: 0x8, Type: ObjectProperty)

protected:
    void HandleIndicatorModeChanged(bool& bIndicatorsEnabled); // 0xf1faf6c (Index: 0x0, Flags: Final|Native|Protected)
    void OnTargetChangedNative(bool& bTargeting); // 0x11dc36bc (Index: 0x1, Flags: Final|Native|Protected)
    virtual void OnTargetingChanged(bool& bTargeting); // 0x288a61c (Index: 0x2, Flags: Event|Protected|BlueprintEvent)
};

static_assert(sizeof(UDelMarInteractionIndicatorContainer) == 0x320, "Size mismatch for UDelMarInteractionIndicatorContainer");
static_assert(offsetof(UDelMarInteractionIndicatorContainer, VehicleIndicators) == 0x318, "Offset mismatch for UDelMarInteractionIndicatorContainer::VehicleIndicators");

// Size: 0x380 (Inherited: 0xa80, Single: 0xfffff900)
class UDelMarPositionalTrackerEntryWidget : public UDelMarUserWidget
{
public:
    uint8_t OnDisplayedPlayerSet[0x10]; // 0x350 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnNavigationEnabledChanged[0x10]; // 0x360 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    UWidgetAnimation* AnimIsTargetPlayer; // 0x370 (Size: 0x8, Type: ObjectProperty)
    bool bTargetPlayer; // 0x378 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_379[0x7]; // 0x379 (Size: 0x7, Type: PaddingProperty)

public:
    void RefreshPlayerInfo(bool& IsTargetPlayer); // 0x11dc3818 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetDisplayedPlayer(UDelMarPlayerViewModel*& InPlayerModel); // 0x11dc3b84 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarPositionalTrackerEntryWidget) == 0x380, "Size mismatch for UDelMarPositionalTrackerEntryWidget");
static_assert(offsetof(UDelMarPositionalTrackerEntryWidget, OnDisplayedPlayerSet) == 0x350, "Offset mismatch for UDelMarPositionalTrackerEntryWidget::OnDisplayedPlayerSet");
static_assert(offsetof(UDelMarPositionalTrackerEntryWidget, OnNavigationEnabledChanged) == 0x360, "Offset mismatch for UDelMarPositionalTrackerEntryWidget::OnNavigationEnabledChanged");
static_assert(offsetof(UDelMarPositionalTrackerEntryWidget, AnimIsTargetPlayer) == 0x370, "Offset mismatch for UDelMarPositionalTrackerEntryWidget::AnimIsTargetPlayer");
static_assert(offsetof(UDelMarPositionalTrackerEntryWidget, bTargetPlayer) == 0x378, "Offset mismatch for UDelMarPositionalTrackerEntryWidget::bTargetPlayer");

// Size: 0x2f0 (Inherited: 0x730, Single: 0xfffffbc0)
class UDelMarLoadingScreenWidget : public UCommonUserWidget
{
public:
    uint8_t Pad_2d8[0x8]; // 0x2d8 (Size: 0x8, Type: PaddingProperty)
    TArray<FText> LoadingScreenTips; // 0x2e0 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(UDelMarLoadingScreenWidget) == 0x2f0, "Size mismatch for UDelMarLoadingScreenWidget");
static_assert(offsetof(UDelMarLoadingScreenWidget, LoadingScreenTips) == 0x2e0, "Offset mismatch for UDelMarLoadingScreenWidget::LoadingScreenTips");

// Size: 0x408 (Inherited: 0xb38, Single: 0xfffff8d0)
class UDelMarPostRaceRankedRecap : public UCommonActivatableWidget
{
public:

protected:
    float GetFailsafeDelayDuration() const; // 0x11dc068c (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarPostRaceRankedRecap) == 0x408, "Size mismatch for UDelMarPostRaceRankedRecap");

// Size: 0x2d0 (Inherited: 0x720, Single: 0xfffffbb0)
class UDelMarDebugGameplayTrackEntry : public UDelMarDebugTrackEntry
{
public:
    UDynamicUIScene* GameplayTrackListScene; // 0x2c8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDelMarDebugGameplayTrackEntry) == 0x2d0, "Size mismatch for UDelMarDebugGameplayTrackEntry");
static_assert(offsetof(UDelMarDebugGameplayTrackEntry, GameplayTrackListScene) == 0x2c8, "Offset mismatch for UDelMarDebugGameplayTrackEntry::GameplayTrackListScene");

// Size: 0x2c8 (Inherited: 0x458, Single: 0xfffffe70)
class UDelMarDebugTrackEntry : public UUserWidget
{
public:
    uint8_t Pad_2b0[0x8]; // 0x2b0 (Size: 0x8, Type: PaddingProperty)
    UCommonTextBlock* TrackNameText; // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UDelMarLevelDataAsset* LevelDataAsset; // 0x2c0 (Size: 0x8, Type: ObjectProperty)

protected:
    void BP_OnTrackButtonPressed(); // 0x3f91fd8 (Index: 0x0, Flags: Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarDebugTrackEntry) == 0x2c8, "Size mismatch for UDelMarDebugTrackEntry");
static_assert(offsetof(UDelMarDebugTrackEntry, TrackNameText) == 0x2b8, "Offset mismatch for UDelMarDebugTrackEntry::TrackNameText");
static_assert(offsetof(UDelMarDebugTrackEntry, LevelDataAsset) == 0x2c0, "Offset mismatch for UDelMarDebugTrackEntry::LevelDataAsset");

// Size: 0x498 (Inherited: 0xfc0, Single: 0xfffff4d8)
class UDelMarDebugTrackList : public UDelMarScreenBase
{
public:
    UCommonListView* TrackView; // 0x488 (Size: 0x8, Type: ObjectProperty)
    bool bOnlyReturnAllowedLevels; // 0x490 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_491[0x7]; // 0x491 (Size: 0x7, Type: PaddingProperty)

protected:
    void BP_OnExitButtonPressed(); // 0x11dc03c8 (Index: 0x0, Flags: Final|Native|Protected|BlueprintCallable)
};

static_assert(sizeof(UDelMarDebugTrackList) == 0x498, "Size mismatch for UDelMarDebugTrackList");
static_assert(offsetof(UDelMarDebugTrackList, TrackView) == 0x488, "Offset mismatch for UDelMarDebugTrackList::TrackView");
static_assert(offsetof(UDelMarDebugTrackList, bOnlyReturnAllowedLevels) == 0x490, "Offset mismatch for UDelMarDebugTrackList::bOnlyReturnAllowedLevels");

// Size: 0x260 (Inherited: 0x640, Single: 0xfffffc20)
class UDelMarBoundActionBar : public UCommonBoundActionBar
{
public:
};

static_assert(sizeof(UDelMarBoundActionBar) == 0x260, "Size mismatch for UDelMarBoundActionBar");

// Size: 0x14c0 (Inherited: 0x1bd0, Single: 0xfffff8f0)
class UDelMarBoundActionButton : public UCommonButtonBase
{
public:
    uint8_t Pad_14a0[0x8]; // 0x14a0 (Size: 0x8, Type: PaddingProperty)
    FText Text; // 0x14a8 (Size: 0x10, Type: TextProperty)
    uint8_t Pad_14b8[0x8]; // 0x14b8 (Size: 0x8, Type: PaddingProperty)

protected:
    virtual void BP_OnActionProgress(float& const HoldPercentage); // 0x288a61c (Index: 0x0, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_OnInputActionUpdated(); // 0x288a61c (Index: 0x1, Flags: Event|Protected|BlueprintEvent)
    virtual void BP_SetText(const FText ButtonText); // 0x288a61c (Index: 0x2, Flags: Event|Protected|HasOutParms|BlueprintEvent)
};

static_assert(sizeof(UDelMarBoundActionButton) == 0x14c0, "Size mismatch for UDelMarBoundActionButton");
static_assert(offsetof(UDelMarBoundActionButton, Text) == 0x14a8, "Offset mismatch for UDelMarBoundActionButton::Text");

// Size: 0x58 (Inherited: 0x70, Single: 0xffffffe8)
class UDelMarBladeMenuTriggerUIStateComponent : public UUIStateComponent
{
public:
    UDelMarBladeMenuTriggerUIStateComponentConfiguration* Configuration; // 0x48 (Size: 0x8, Type: ObjectProperty)
    UFortHUDContext* HUDContext; // 0x50 (Size: 0x8, Type: ObjectProperty)

protected:
    void NativeHandleCursorModeChanged(bool& bCursorModeEnabled, FName& ActionName, UUserWidget*& CursorModeContentWidget); // 0x11dc33c8 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarBladeMenuTriggerUIStateComponent) == 0x58, "Size mismatch for UDelMarBladeMenuTriggerUIStateComponent");
static_assert(offsetof(UDelMarBladeMenuTriggerUIStateComponent, Configuration) == 0x48, "Offset mismatch for UDelMarBladeMenuTriggerUIStateComponent::Configuration");
static_assert(offsetof(UDelMarBladeMenuTriggerUIStateComponent, HUDContext) == 0x50, "Offset mismatch for UDelMarBladeMenuTriggerUIStateComponent::HUDContext");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UDelMarBladeMenuTriggerUIStateComponentConfiguration : public UUIStateComponentConfiguration
{
public:
    FGameplayTag BladeMenuTriggerTag; // 0x28 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarBladeMenuTriggerUIStateComponentConfiguration) == 0x30, "Size mismatch for UDelMarBladeMenuTriggerUIStateComponentConfiguration");
static_assert(offsetof(UDelMarBladeMenuTriggerUIStateComponentConfiguration, BladeMenuTriggerTag) == 0x28, "Offset mismatch for UDelMarBladeMenuTriggerUIStateComponentConfiguration::BladeMenuTriggerTag");

// Size: 0x50 (Inherited: 0x70, Single: 0xffffffe0)
class UDelMarEmotePickerTriggerUIStateComponent : public UUIStateComponent
{
public:
    UDelMarEmotePickerTriggerUIStateComponentConfiguration* Configuration; // 0x48 (Size: 0x8, Type: ObjectProperty)

protected:
    void HandlePickerOpenRequest(EFortPickerMode& Mode, int32_t& InitialOption, bool& bIgnoreFirstAccept); // 0x11dc1528 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarEmotePickerTriggerUIStateComponent) == 0x50, "Size mismatch for UDelMarEmotePickerTriggerUIStateComponent");
static_assert(offsetof(UDelMarEmotePickerTriggerUIStateComponent, Configuration) == 0x48, "Offset mismatch for UDelMarEmotePickerTriggerUIStateComponent::Configuration");

// Size: 0x38 (Inherited: 0x50, Single: 0xffffffe8)
class UDelMarEmotePickerTriggerUIStateComponentConfiguration : public UUIStateComponentConfiguration
{
public:
    FGameplayTag EmotePickerOpenTriggerTag; // 0x28 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
    UFortPickerData* PickerData; // 0x30 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(UDelMarEmotePickerTriggerUIStateComponentConfiguration) == 0x38, "Size mismatch for UDelMarEmotePickerTriggerUIStateComponentConfiguration");
static_assert(offsetof(UDelMarEmotePickerTriggerUIStateComponentConfiguration, EmotePickerOpenTriggerTag) == 0x28, "Offset mismatch for UDelMarEmotePickerTriggerUIStateComponentConfiguration::EmotePickerOpenTriggerTag");
static_assert(offsetof(UDelMarEmotePickerTriggerUIStateComponentConfiguration, PickerData) == 0x30, "Offset mismatch for UDelMarEmotePickerTriggerUIStateComponentConfiguration::PickerData");

// Size: 0xe0 (Inherited: 0x70, Single: 0x70)
class UDelMarGameplayContextUpdaterUIStateComponent : public UUIStateComponent
{
public:
    TMap<FString, FGameplayTag> GameStateToUITagMap; // 0x48 (Size: 0x50, Type: MapProperty)
    FGameplayTag CurrentRacerState; // 0x98 (Size: 0x4, Type: StructProperty)
    FGameplayTag CurrentGameState; // 0x9c (Size: 0x4, Type: StructProperty)
    FGameplayTag CurrentRaceMode; // 0xa0 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<AFortPlayerState*> OwnerPlayerState; // 0xa4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> SpectatedPlayerState; // 0xac (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> OwnerPlayerController; // 0xb4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPlayerPreferencesComponent*> CachedPreferences; // 0xbc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarLevelManagerComponent*> LevelManager; // 0xc4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> CachedVehicle; // 0xcc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UFortSocialChatV3Manager*> ChatManager; // 0xd4 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_dc[0x4]; // 0xdc (Size: 0x4, Type: PaddingProperty)

protected:
    void HandleChatOpenChanged(bool& const bOpen); // 0x11dc0998 (Index: 0x0, Flags: Final|Native|Protected)
    void HandleEnterVehicle(); // 0x11dc0d5c (Index: 0x1, Flags: Final|Native|Protected)
    void HandleExitVehicle(); // 0x11dc0d70 (Index: 0x2, Flags: Final|Native|Protected)
    void HandleSpectatorViewTargetChange(AFortPlayerController*& PlayerController, AActor*& OldViewTarget, AActor*& NewViewTarget); // 0x11dc1a58 (Index: 0x3, Flags: Final|Native|Protected)
    void HandleTouchControlsLayoutChanged(FGameplayTag& Layout); // 0x11dc2244 (Index: 0x4, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarGameplayContextUpdaterUIStateComponent) == 0xe0, "Size mismatch for UDelMarGameplayContextUpdaterUIStateComponent");
static_assert(offsetof(UDelMarGameplayContextUpdaterUIStateComponent, GameStateToUITagMap) == 0x48, "Offset mismatch for UDelMarGameplayContextUpdaterUIStateComponent::GameStateToUITagMap");
static_assert(offsetof(UDelMarGameplayContextUpdaterUIStateComponent, CurrentRacerState) == 0x98, "Offset mismatch for UDelMarGameplayContextUpdaterUIStateComponent::CurrentRacerState");
static_assert(offsetof(UDelMarGameplayContextUpdaterUIStateComponent, CurrentGameState) == 0x9c, "Offset mismatch for UDelMarGameplayContextUpdaterUIStateComponent::CurrentGameState");
static_assert(offsetof(UDelMarGameplayContextUpdaterUIStateComponent, CurrentRaceMode) == 0xa0, "Offset mismatch for UDelMarGameplayContextUpdaterUIStateComponent::CurrentRaceMode");
static_assert(offsetof(UDelMarGameplayContextUpdaterUIStateComponent, OwnerPlayerState) == 0xa4, "Offset mismatch for UDelMarGameplayContextUpdaterUIStateComponent::OwnerPlayerState");
static_assert(offsetof(UDelMarGameplayContextUpdaterUIStateComponent, SpectatedPlayerState) == 0xac, "Offset mismatch for UDelMarGameplayContextUpdaterUIStateComponent::SpectatedPlayerState");
static_assert(offsetof(UDelMarGameplayContextUpdaterUIStateComponent, OwnerPlayerController) == 0xb4, "Offset mismatch for UDelMarGameplayContextUpdaterUIStateComponent::OwnerPlayerController");
static_assert(offsetof(UDelMarGameplayContextUpdaterUIStateComponent, CachedPreferences) == 0xbc, "Offset mismatch for UDelMarGameplayContextUpdaterUIStateComponent::CachedPreferences");
static_assert(offsetof(UDelMarGameplayContextUpdaterUIStateComponent, LevelManager) == 0xc4, "Offset mismatch for UDelMarGameplayContextUpdaterUIStateComponent::LevelManager");
static_assert(offsetof(UDelMarGameplayContextUpdaterUIStateComponent, CachedVehicle) == 0xcc, "Offset mismatch for UDelMarGameplayContextUpdaterUIStateComponent::CachedVehicle");
static_assert(offsetof(UDelMarGameplayContextUpdaterUIStateComponent, ChatManager) == 0xd4, "Offset mismatch for UDelMarGameplayContextUpdaterUIStateComponent::ChatManager");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UDelMarGameplayContextUpdaterUIStateComponentConfiguration : public UUIStateComponentConfiguration
{
public:
};

static_assert(sizeof(UDelMarGameplayContextUpdaterUIStateComponentConfiguration) == 0x28, "Size mismatch for UDelMarGameplayContextUpdaterUIStateComponentConfiguration");

// Size: 0x68 (Inherited: 0x70, Single: 0xfffffff8)
class UDelMarIdleMonitorUIStateComponent : public UUIStateComponent
{
public:
    UDelMarIdleMonitorUIStateComponentConfiguration* Configuration; // 0x48 (Size: 0x8, Type: ObjectProperty)
    UDelMarRequestComponent* CachedRequestComponent; // 0x50 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_58[0x10]; // 0x58 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarIdleMonitorUIStateComponent) == 0x68, "Size mismatch for UDelMarIdleMonitorUIStateComponent");
static_assert(offsetof(UDelMarIdleMonitorUIStateComponent, Configuration) == 0x48, "Offset mismatch for UDelMarIdleMonitorUIStateComponent::Configuration");
static_assert(offsetof(UDelMarIdleMonitorUIStateComponent, CachedRequestComponent) == 0x50, "Offset mismatch for UDelMarIdleMonitorUIStateComponent::CachedRequestComponent");

// Size: 0x30 (Inherited: 0x50, Single: 0xffffffe0)
class UDelMarIdleMonitorUIStateComponentConfiguration : public UUIStateComponentConfiguration
{
public:
    float ActivityCheckPeriod; // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_2c[0x4]; // 0x2c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarIdleMonitorUIStateComponentConfiguration) == 0x30, "Size mismatch for UDelMarIdleMonitorUIStateComponentConfiguration");
static_assert(offsetof(UDelMarIdleMonitorUIStateComponentConfiguration, ActivityCheckPeriod) == 0x28, "Offset mismatch for UDelMarIdleMonitorUIStateComponentConfiguration::ActivityCheckPeriod");

// Size: 0xf8 (Inherited: 0x170, Single: 0xffffff88)
class UDelMarGlobalLeaderboardEntryViewModel : public UDelMarViewModelBase
{
public:
    FString PlayerAccountId; // 0x70 (Size: 0x10, Type: StrProperty)
    FString PlayerName; // 0x80 (Size: 0x10, Type: StrProperty)
    double RunDuration; // 0x90 (Size: 0x8, Type: DoubleProperty)
    int64_t Rank; // 0x98 (Size: 0x8, Type: Int64Property)
    bool bIsLocalPlayer; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0x7]; // 0xa1 (Size: 0x7, Type: PaddingProperty)
    FDelMarGlobalLeaderboardEntry GlobalLeaderboardEntry; // 0xa8 (Size: 0x40, Type: StructProperty)
    uint8_t Pad_e8[0x10]; // 0xe8 (Size: 0x10, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarGlobalLeaderboardEntryViewModel) == 0xf8, "Size mismatch for UDelMarGlobalLeaderboardEntryViewModel");
static_assert(offsetof(UDelMarGlobalLeaderboardEntryViewModel, PlayerAccountId) == 0x70, "Offset mismatch for UDelMarGlobalLeaderboardEntryViewModel::PlayerAccountId");
static_assert(offsetof(UDelMarGlobalLeaderboardEntryViewModel, PlayerName) == 0x80, "Offset mismatch for UDelMarGlobalLeaderboardEntryViewModel::PlayerName");
static_assert(offsetof(UDelMarGlobalLeaderboardEntryViewModel, RunDuration) == 0x90, "Offset mismatch for UDelMarGlobalLeaderboardEntryViewModel::RunDuration");
static_assert(offsetof(UDelMarGlobalLeaderboardEntryViewModel, Rank) == 0x98, "Offset mismatch for UDelMarGlobalLeaderboardEntryViewModel::Rank");
static_assert(offsetof(UDelMarGlobalLeaderboardEntryViewModel, bIsLocalPlayer) == 0xa0, "Offset mismatch for UDelMarGlobalLeaderboardEntryViewModel::bIsLocalPlayer");
static_assert(offsetof(UDelMarGlobalLeaderboardEntryViewModel, GlobalLeaderboardEntry) == 0xa8, "Offset mismatch for UDelMarGlobalLeaderboardEntryViewModel::GlobalLeaderboardEntry");

// Size: 0xd0 (Inherited: 0x170, Single: 0xffffff60)
class UDelMarLoadingScreenViewModel : public UDelMarViewModelBase
{
public:
    bool bHasValidTrackData; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
    FText MapName; // 0x78 (Size: 0x10, Type: TextProperty)
    FText MapCreator; // 0x88 (Size: 0x10, Type: TextProperty)
    FText MapDescription; // 0x98 (Size: 0x10, Type: TextProperty)
    FGameplayTag RaceMode; // 0xa8 (Size: 0x4, Type: StructProperty)
    uint8_t Pad_ac[0x4]; // 0xac (Size: 0x4, Type: PaddingProperty)
    TSoftObjectPtr<UTexture2D*> LoadingBackgroundImage; // 0xb0 (Size: 0x20, Type: SoftObjectProperty)
};

static_assert(sizeof(UDelMarLoadingScreenViewModel) == 0xd0, "Size mismatch for UDelMarLoadingScreenViewModel");
static_assert(offsetof(UDelMarLoadingScreenViewModel, bHasValidTrackData) == 0x70, "Offset mismatch for UDelMarLoadingScreenViewModel::bHasValidTrackData");
static_assert(offsetof(UDelMarLoadingScreenViewModel, MapName) == 0x78, "Offset mismatch for UDelMarLoadingScreenViewModel::MapName");
static_assert(offsetof(UDelMarLoadingScreenViewModel, MapCreator) == 0x88, "Offset mismatch for UDelMarLoadingScreenViewModel::MapCreator");
static_assert(offsetof(UDelMarLoadingScreenViewModel, MapDescription) == 0x98, "Offset mismatch for UDelMarLoadingScreenViewModel::MapDescription");
static_assert(offsetof(UDelMarLoadingScreenViewModel, RaceMode) == 0xa8, "Offset mismatch for UDelMarLoadingScreenViewModel::RaceMode");
static_assert(offsetof(UDelMarLoadingScreenViewModel, LoadingBackgroundImage) == 0xb0, "Offset mismatch for UDelMarLoadingScreenViewModel::LoadingBackgroundImage");

// Size: 0x80 (Inherited: 0x170, Single: 0xffffff10)
class UDelMarLocalPlayerSettingsViewModel : public UDelMarViewModelBase
{
public:
    bool bUseIconOnlyPlayerNameplates; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x3]; // 0x71 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<UDelMarPlayerPreferencesComponent*> CachedPreferences; // 0x74 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_7c[0x4]; // 0x7c (Size: 0x4, Type: PaddingProperty)

protected:
    void HandleNameplatesSettingChanged(bool& NewValue); // 0x11dc11d0 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarLocalPlayerSettingsViewModel) == 0x80, "Size mismatch for UDelMarLocalPlayerSettingsViewModel");
static_assert(offsetof(UDelMarLocalPlayerSettingsViewModel, bUseIconOnlyPlayerNameplates) == 0x70, "Offset mismatch for UDelMarLocalPlayerSettingsViewModel::bUseIconOnlyPlayerNameplates");
static_assert(offsetof(UDelMarLocalPlayerSettingsViewModel, CachedPreferences) == 0x74, "Offset mismatch for UDelMarLocalPlayerSettingsViewModel::CachedPreferences");

// Size: 0x110 (Inherited: 0x170, Single: 0xffffffa0)
class UDelMarPlayerRaceStateViewModel : public UDelMarViewModelBase
{
public:
    bool bHasValidData; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x3]; // 0x71 (Size: 0x3, Type: PaddingProperty)
    int32_t CurrentLap; // 0x74 (Size: 0x4, Type: IntProperty)
    bool bHasCompletedRace; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
    FTimespan RaceCompletionTime; // 0x80 (Size: 0x8, Type: StructProperty)
    int32_t SpectatorCount; // 0x88 (Size: 0x4, Type: IntProperty)
    int32_t CurrentPlacement; // 0x8c (Size: 0x4, Type: IntProperty)
    int32_t CurrentPlacementByBestRun; // 0x90 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_94[0x4]; // 0x94 (Size: 0x4, Type: PaddingProperty)
    double CurrentRunStartTimestamp; // 0x98 (Size: 0x8, Type: DoubleProperty)
    int32_t LastCompletedSectionIndex; // 0xa0 (Size: 0x4, Type: IntProperty)
    bool bIsNewBestRun; // 0xa4 (Size: 0x1, Type: BoolProperty)
    bool bRunActive; // 0xa5 (Size: 0x1, Type: BoolProperty)
    bool bIsSubsequentRun; // 0xa6 (Size: 0x1, Type: BoolProperty)
    bool bIsPedestrian; // 0xa7 (Size: 0x1, Type: BoolProperty)
    bool bIsSpectator; // 0xa8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a9[0x7]; // 0xa9 (Size: 0x7, Type: PaddingProperty)
    UDelMarRunRecordViewModel* CurrentRunRecord; // 0xb0 (Size: 0x8, Type: ObjectProperty)
    UDelMarRunRecordViewModel* BestRunRecord; // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UDelMarRunRecordViewModel* PreviousBestRunRecord; // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TArray<UDelMarRunRecordViewModel*> MatchRunRecords; // 0xc8 (Size: 0x10, Type: ArrayProperty)
    UDelMarGlobalLeaderboardEntryViewModel* PersonalBestLeaderboardEntry; // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UDelMarGlobalLeaderboardEntryViewModel* NewPersonalBestLeaderboardEntry; // 0xe0 (Size: 0x8, Type: ObjectProperty)
    UDelMarVehicleViewModel* Vehicle; // 0xe8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag PreviousRacerState; // 0xf0 (Size: 0x4, Type: StructProperty)
    FGameplayTag RacerState; // 0xf4 (Size: 0x4, Type: StructProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager; // 0xf8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PlayerState; // 0x100 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> PositionalTrackerComponent; // 0x108 (Size: 0x8, Type: WeakObjectProperty)

protected:
    void HandleRaceReset(); // 0x11dc1950 (Index: 0x0, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarPlayerRaceStateViewModel) == 0x110, "Size mismatch for UDelMarPlayerRaceStateViewModel");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, bHasValidData) == 0x70, "Offset mismatch for UDelMarPlayerRaceStateViewModel::bHasValidData");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, CurrentLap) == 0x74, "Offset mismatch for UDelMarPlayerRaceStateViewModel::CurrentLap");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, bHasCompletedRace) == 0x78, "Offset mismatch for UDelMarPlayerRaceStateViewModel::bHasCompletedRace");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, RaceCompletionTime) == 0x80, "Offset mismatch for UDelMarPlayerRaceStateViewModel::RaceCompletionTime");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, SpectatorCount) == 0x88, "Offset mismatch for UDelMarPlayerRaceStateViewModel::SpectatorCount");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, CurrentPlacement) == 0x8c, "Offset mismatch for UDelMarPlayerRaceStateViewModel::CurrentPlacement");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, CurrentPlacementByBestRun) == 0x90, "Offset mismatch for UDelMarPlayerRaceStateViewModel::CurrentPlacementByBestRun");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, CurrentRunStartTimestamp) == 0x98, "Offset mismatch for UDelMarPlayerRaceStateViewModel::CurrentRunStartTimestamp");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, LastCompletedSectionIndex) == 0xa0, "Offset mismatch for UDelMarPlayerRaceStateViewModel::LastCompletedSectionIndex");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, bIsNewBestRun) == 0xa4, "Offset mismatch for UDelMarPlayerRaceStateViewModel::bIsNewBestRun");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, bRunActive) == 0xa5, "Offset mismatch for UDelMarPlayerRaceStateViewModel::bRunActive");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, bIsSubsequentRun) == 0xa6, "Offset mismatch for UDelMarPlayerRaceStateViewModel::bIsSubsequentRun");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, bIsPedestrian) == 0xa7, "Offset mismatch for UDelMarPlayerRaceStateViewModel::bIsPedestrian");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, bIsSpectator) == 0xa8, "Offset mismatch for UDelMarPlayerRaceStateViewModel::bIsSpectator");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, CurrentRunRecord) == 0xb0, "Offset mismatch for UDelMarPlayerRaceStateViewModel::CurrentRunRecord");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, BestRunRecord) == 0xb8, "Offset mismatch for UDelMarPlayerRaceStateViewModel::BestRunRecord");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, PreviousBestRunRecord) == 0xc0, "Offset mismatch for UDelMarPlayerRaceStateViewModel::PreviousBestRunRecord");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, MatchRunRecords) == 0xc8, "Offset mismatch for UDelMarPlayerRaceStateViewModel::MatchRunRecords");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, PersonalBestLeaderboardEntry) == 0xd8, "Offset mismatch for UDelMarPlayerRaceStateViewModel::PersonalBestLeaderboardEntry");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, NewPersonalBestLeaderboardEntry) == 0xe0, "Offset mismatch for UDelMarPlayerRaceStateViewModel::NewPersonalBestLeaderboardEntry");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, Vehicle) == 0xe8, "Offset mismatch for UDelMarPlayerRaceStateViewModel::Vehicle");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, PreviousRacerState) == 0xf0, "Offset mismatch for UDelMarPlayerRaceStateViewModel::PreviousRacerState");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, RacerState) == 0xf4, "Offset mismatch for UDelMarPlayerRaceStateViewModel::RacerState");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, RaceManager) == 0xf8, "Offset mismatch for UDelMarPlayerRaceStateViewModel::RaceManager");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, PlayerState) == 0x100, "Offset mismatch for UDelMarPlayerRaceStateViewModel::PlayerState");
static_assert(offsetof(UDelMarPlayerRaceStateViewModel, PositionalTrackerComponent) == 0x108, "Offset mismatch for UDelMarPlayerRaceStateViewModel::PositionalTrackerComponent");

// Size: 0xe8 (Inherited: 0x170, Single: 0xffffff78)
class UDelMarPlayerViewModel : public UDelMarViewModelBase
{
public:
    FText DisplayName; // 0x70 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D*> AvatarLargeImage; // 0x80 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D*> AvatarSmallImage; // 0xa0 (Size: 0x20, Type: SoftObjectProperty)
    FColor AvatarBackgroundColor; // 0xc0 (Size: 0x4, Type: StructProperty)
    FColor AvatarHighlightColor; // 0xc4 (Size: 0x4, Type: StructProperty)
    UTextureRenderTarget2D* DriverCameraRT; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    UDelMarPlayerRaceStateViewModel* PlayerRaceState; // 0xd0 (Size: 0x8, Type: ObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> PlayerState; // 0xd8 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager; // 0xe0 (Size: 0x8, Type: WeakObjectProperty)

public:
    AFortPlayerState* GetPlayerState() const; // 0x11dc0700 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarPlayerViewModel) == 0xe8, "Size mismatch for UDelMarPlayerViewModel");
static_assert(offsetof(UDelMarPlayerViewModel, DisplayName) == 0x70, "Offset mismatch for UDelMarPlayerViewModel::DisplayName");
static_assert(offsetof(UDelMarPlayerViewModel, AvatarLargeImage) == 0x80, "Offset mismatch for UDelMarPlayerViewModel::AvatarLargeImage");
static_assert(offsetof(UDelMarPlayerViewModel, AvatarSmallImage) == 0xa0, "Offset mismatch for UDelMarPlayerViewModel::AvatarSmallImage");
static_assert(offsetof(UDelMarPlayerViewModel, AvatarBackgroundColor) == 0xc0, "Offset mismatch for UDelMarPlayerViewModel::AvatarBackgroundColor");
static_assert(offsetof(UDelMarPlayerViewModel, AvatarHighlightColor) == 0xc4, "Offset mismatch for UDelMarPlayerViewModel::AvatarHighlightColor");
static_assert(offsetof(UDelMarPlayerViewModel, DriverCameraRT) == 0xc8, "Offset mismatch for UDelMarPlayerViewModel::DriverCameraRT");
static_assert(offsetof(UDelMarPlayerViewModel, PlayerRaceState) == 0xd0, "Offset mismatch for UDelMarPlayerViewModel::PlayerRaceState");
static_assert(offsetof(UDelMarPlayerViewModel, PlayerState) == 0xd8, "Offset mismatch for UDelMarPlayerViewModel::PlayerState");
static_assert(offsetof(UDelMarPlayerViewModel, RaceManager) == 0xe0, "Offset mismatch for UDelMarPlayerViewModel::RaceManager");

// Size: 0x228 (Inherited: 0x170, Single: 0xb8)
class UDelMarRaceViewModel : public UDelMarViewModelBase
{
public:
    int32_t TotalLaps; // 0x70 (Size: 0x4, Type: IntProperty)
    int32_t TotalPlayers; // 0x74 (Size: 0x4, Type: IntProperty)
    int32_t TotalReadyPlayers; // 0x78 (Size: 0x4, Type: IntProperty)
    int32_t TotalLoadedPlayers; // 0x7c (Size: 0x4, Type: IntProperty)
    int32_t TotalJoiningPlayers; // 0x80 (Size: 0x4, Type: IntProperty)
    int32_t TotalPlacements; // 0x84 (Size: 0x4, Type: IntProperty)
    FText MapName; // 0x88 (Size: 0x10, Type: TextProperty)
    FText MapCreator; // 0x98 (Size: 0x10, Type: TextProperty)
    FText MapDescription; // 0xa8 (Size: 0x10, Type: TextProperty)
    FGameplayTag RaceMode; // 0xb8 (Size: 0x4, Type: StructProperty)
    FGameplayTag DelMarGameplayState; // 0xbc (Size: 0x4, Type: StructProperty)
    TSoftObjectPtr<UTexture2D*> LoadingBackgroundImage; // 0xc0 (Size: 0x20, Type: SoftObjectProperty)
    double TimeUntilRaceStart; // 0xe0 (Size: 0x8, Type: DoubleProperty)
    double RaceEndTimestamp; // 0xe8 (Size: 0x8, Type: DoubleProperty)
    int32_t MatchTimeLimitSeconds; // 0xf0 (Size: 0x4, Type: IntProperty)
    bool bIsOvertime; // 0xf4 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_f5[0x3]; // 0xf5 (Size: 0x3, Type: PaddingProperty)
    double TimeUntilTrackChange; // 0xf8 (Size: 0x8, Type: DoubleProperty)
    double FirstPlayerFinishedServerTimestamp; // 0x100 (Size: 0x8, Type: DoubleProperty)
    double FirstPlayerFinishedRaceEndServerTimestamp; // 0x108 (Size: 0x8, Type: DoubleProperty)
    char CurrentMatchmakingState; // 0x110 (Size: 0x1, Type: ByteProperty)
    bool bIsRaceFinished; // 0x111 (Size: 0x1, Type: BoolProperty)
    bool bIsRaceStarted; // 0x112 (Size: 0x1, Type: BoolProperty)
    bool bHasPreRaceSocial; // 0x113 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_114[0x4]; // 0x114 (Size: 0x4, Type: PaddingProperty)
    UDelMarMatchEventViewModel* MatchEventViewModel; // 0x118 (Size: 0x8, Type: ObjectProperty)
    UDelMarTrackInfoViewModel* TrackInfoViewModel; // 0x120 (Size: 0x8, Type: ObjectProperty)
    UDelMarPlayerViewModel* LocalPlayer; // 0x128 (Size: 0x8, Type: ObjectProperty)
    UDelMarPlayerViewModel* TargetPlayer; // 0x130 (Size: 0x8, Type: ObjectProperty)
    UDelMarPlayerViewModel* LastTargetPlayer; // 0x138 (Size: 0x8, Type: ObjectProperty)
    TArray<UDelMarPlayerViewModel*> PositionPlayers; // 0x140 (Size: 0x10, Type: ArrayProperty)
    TArray<UDelMarPlayerViewModel*> FinalPlacements; // 0x150 (Size: 0x10, Type: ArrayProperty)
    TMap<UDelMarPlayerViewModel*, int32_t> RacePlayers; // 0x160 (Size: 0x50, Type: MapProperty)
    TArray<UDelMarGlobalLeaderboardEntryViewModel*> TopLeaderboardEntries; // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    TArray<UDelMarGlobalLeaderboardEntryViewModel*> FocusedLeaderboardEntries; // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    TArray<UDelMarGlobalLeaderboardEntryViewModel*> FriendLeaderboardEntries; // 0x1d0 (Size: 0x10, Type: ArrayProperty)
    FString GameSessionId; // 0x1e0 (Size: 0x10, Type: StrProperty)
    FString IslandCode; // 0x1f0 (Size: 0x10, Type: StrProperty)
    TWeakObjectPtr<ADelMarRaceManager*> RaceManager; // 0x200 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerController*> LocalPlayerController; // 0x208 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerState*> ViewTargetPlayerState; // 0x210 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarPositionalTrackerComponent*> PositionalTrackerComponent; // 0x218 (Size: 0x8, Type: WeakObjectProperty)
    UDelMarPlayerViewModel* EmptyPlayerViewModel; // 0x220 (Size: 0x8, Type: ObjectProperty)

protected:
    void HandleFinalRacePositionsChanged(const TArray<FDelMarFinalRacePositionEntry> FinalRacePositions, const FDelMarEvent_RunRecorded RecordedRun); // 0x11dc0d84 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void HandleViewTargetChanged(AFortPlayerController*& PC, AActor*& Old, AActor*& NewViewTarget); // 0x11dc29f0 (Index: 0x1, Flags: Final|Native|Protected)
};

static_assert(sizeof(UDelMarRaceViewModel) == 0x228, "Size mismatch for UDelMarRaceViewModel");
static_assert(offsetof(UDelMarRaceViewModel, TotalLaps) == 0x70, "Offset mismatch for UDelMarRaceViewModel::TotalLaps");
static_assert(offsetof(UDelMarRaceViewModel, TotalPlayers) == 0x74, "Offset mismatch for UDelMarRaceViewModel::TotalPlayers");
static_assert(offsetof(UDelMarRaceViewModel, TotalReadyPlayers) == 0x78, "Offset mismatch for UDelMarRaceViewModel::TotalReadyPlayers");
static_assert(offsetof(UDelMarRaceViewModel, TotalLoadedPlayers) == 0x7c, "Offset mismatch for UDelMarRaceViewModel::TotalLoadedPlayers");
static_assert(offsetof(UDelMarRaceViewModel, TotalJoiningPlayers) == 0x80, "Offset mismatch for UDelMarRaceViewModel::TotalJoiningPlayers");
static_assert(offsetof(UDelMarRaceViewModel, TotalPlacements) == 0x84, "Offset mismatch for UDelMarRaceViewModel::TotalPlacements");
static_assert(offsetof(UDelMarRaceViewModel, MapName) == 0x88, "Offset mismatch for UDelMarRaceViewModel::MapName");
static_assert(offsetof(UDelMarRaceViewModel, MapCreator) == 0x98, "Offset mismatch for UDelMarRaceViewModel::MapCreator");
static_assert(offsetof(UDelMarRaceViewModel, MapDescription) == 0xa8, "Offset mismatch for UDelMarRaceViewModel::MapDescription");
static_assert(offsetof(UDelMarRaceViewModel, RaceMode) == 0xb8, "Offset mismatch for UDelMarRaceViewModel::RaceMode");
static_assert(offsetof(UDelMarRaceViewModel, DelMarGameplayState) == 0xbc, "Offset mismatch for UDelMarRaceViewModel::DelMarGameplayState");
static_assert(offsetof(UDelMarRaceViewModel, LoadingBackgroundImage) == 0xc0, "Offset mismatch for UDelMarRaceViewModel::LoadingBackgroundImage");
static_assert(offsetof(UDelMarRaceViewModel, TimeUntilRaceStart) == 0xe0, "Offset mismatch for UDelMarRaceViewModel::TimeUntilRaceStart");
static_assert(offsetof(UDelMarRaceViewModel, RaceEndTimestamp) == 0xe8, "Offset mismatch for UDelMarRaceViewModel::RaceEndTimestamp");
static_assert(offsetof(UDelMarRaceViewModel, MatchTimeLimitSeconds) == 0xf0, "Offset mismatch for UDelMarRaceViewModel::MatchTimeLimitSeconds");
static_assert(offsetof(UDelMarRaceViewModel, bIsOvertime) == 0xf4, "Offset mismatch for UDelMarRaceViewModel::bIsOvertime");
static_assert(offsetof(UDelMarRaceViewModel, TimeUntilTrackChange) == 0xf8, "Offset mismatch for UDelMarRaceViewModel::TimeUntilTrackChange");
static_assert(offsetof(UDelMarRaceViewModel, FirstPlayerFinishedServerTimestamp) == 0x100, "Offset mismatch for UDelMarRaceViewModel::FirstPlayerFinishedServerTimestamp");
static_assert(offsetof(UDelMarRaceViewModel, FirstPlayerFinishedRaceEndServerTimestamp) == 0x108, "Offset mismatch for UDelMarRaceViewModel::FirstPlayerFinishedRaceEndServerTimestamp");
static_assert(offsetof(UDelMarRaceViewModel, CurrentMatchmakingState) == 0x110, "Offset mismatch for UDelMarRaceViewModel::CurrentMatchmakingState");
static_assert(offsetof(UDelMarRaceViewModel, bIsRaceFinished) == 0x111, "Offset mismatch for UDelMarRaceViewModel::bIsRaceFinished");
static_assert(offsetof(UDelMarRaceViewModel, bIsRaceStarted) == 0x112, "Offset mismatch for UDelMarRaceViewModel::bIsRaceStarted");
static_assert(offsetof(UDelMarRaceViewModel, bHasPreRaceSocial) == 0x113, "Offset mismatch for UDelMarRaceViewModel::bHasPreRaceSocial");
static_assert(offsetof(UDelMarRaceViewModel, MatchEventViewModel) == 0x118, "Offset mismatch for UDelMarRaceViewModel::MatchEventViewModel");
static_assert(offsetof(UDelMarRaceViewModel, TrackInfoViewModel) == 0x120, "Offset mismatch for UDelMarRaceViewModel::TrackInfoViewModel");
static_assert(offsetof(UDelMarRaceViewModel, LocalPlayer) == 0x128, "Offset mismatch for UDelMarRaceViewModel::LocalPlayer");
static_assert(offsetof(UDelMarRaceViewModel, TargetPlayer) == 0x130, "Offset mismatch for UDelMarRaceViewModel::TargetPlayer");
static_assert(offsetof(UDelMarRaceViewModel, LastTargetPlayer) == 0x138, "Offset mismatch for UDelMarRaceViewModel::LastTargetPlayer");
static_assert(offsetof(UDelMarRaceViewModel, PositionPlayers) == 0x140, "Offset mismatch for UDelMarRaceViewModel::PositionPlayers");
static_assert(offsetof(UDelMarRaceViewModel, FinalPlacements) == 0x150, "Offset mismatch for UDelMarRaceViewModel::FinalPlacements");
static_assert(offsetof(UDelMarRaceViewModel, RacePlayers) == 0x160, "Offset mismatch for UDelMarRaceViewModel::RacePlayers");
static_assert(offsetof(UDelMarRaceViewModel, TopLeaderboardEntries) == 0x1b0, "Offset mismatch for UDelMarRaceViewModel::TopLeaderboardEntries");
static_assert(offsetof(UDelMarRaceViewModel, FocusedLeaderboardEntries) == 0x1c0, "Offset mismatch for UDelMarRaceViewModel::FocusedLeaderboardEntries");
static_assert(offsetof(UDelMarRaceViewModel, FriendLeaderboardEntries) == 0x1d0, "Offset mismatch for UDelMarRaceViewModel::FriendLeaderboardEntries");
static_assert(offsetof(UDelMarRaceViewModel, GameSessionId) == 0x1e0, "Offset mismatch for UDelMarRaceViewModel::GameSessionId");
static_assert(offsetof(UDelMarRaceViewModel, IslandCode) == 0x1f0, "Offset mismatch for UDelMarRaceViewModel::IslandCode");
static_assert(offsetof(UDelMarRaceViewModel, RaceManager) == 0x200, "Offset mismatch for UDelMarRaceViewModel::RaceManager");
static_assert(offsetof(UDelMarRaceViewModel, LocalPlayerController) == 0x208, "Offset mismatch for UDelMarRaceViewModel::LocalPlayerController");
static_assert(offsetof(UDelMarRaceViewModel, ViewTargetPlayerState) == 0x210, "Offset mismatch for UDelMarRaceViewModel::ViewTargetPlayerState");
static_assert(offsetof(UDelMarRaceViewModel, PositionalTrackerComponent) == 0x218, "Offset mismatch for UDelMarRaceViewModel::PositionalTrackerComponent");
static_assert(offsetof(UDelMarRaceViewModel, EmptyPlayerViewModel) == 0x220, "Offset mismatch for UDelMarRaceViewModel::EmptyPlayerViewModel");

// Size: 0xa8 (Inherited: 0x170, Single: 0xffffff38)
class UDelMarRunRecordViewModel : public UDelMarViewModelBase
{
public:
    FDelMarRunRecord Record; // 0x70 (Size: 0x20, Type: StructProperty)
    TArray<FDelMarSectionData> RunRecordSectionData; // 0x90 (Size: 0x10, Type: ArrayProperty)
    bool bHasValidData; // 0xa0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_a1[0x7]; // 0xa1 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarRunRecordViewModel) == 0xa8, "Size mismatch for UDelMarRunRecordViewModel");
static_assert(offsetof(UDelMarRunRecordViewModel, Record) == 0x70, "Offset mismatch for UDelMarRunRecordViewModel::Record");
static_assert(offsetof(UDelMarRunRecordViewModel, RunRecordSectionData) == 0x90, "Offset mismatch for UDelMarRunRecordViewModel::RunRecordSectionData");
static_assert(offsetof(UDelMarRunRecordViewModel, bHasValidData) == 0xa0, "Offset mismatch for UDelMarRunRecordViewModel::bHasValidData");

// Size: 0xd0 (Inherited: 0x170, Single: 0xffffff60)
class UDelMarTrackInfoViewModel : public UDelMarViewModelBase
{
public:
    bool bHasValidTrackData; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
    FText TrackName; // 0x78 (Size: 0x10, Type: TextProperty)
    FText TrackDescription; // 0x88 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D*> LoadingBackgroundImage; // 0x98 (Size: 0x20, Type: SoftObjectProperty)
    FText CreatorName; // 0xb8 (Size: 0x10, Type: TextProperty)
    bool bIsEpicCreated; // 0xc8 (Size: 0x1, Type: BoolProperty)
    bool bHasValidCreatorData; // 0xc9 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_ca[0x6]; // 0xca (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(UDelMarTrackInfoViewModel) == 0xd0, "Size mismatch for UDelMarTrackInfoViewModel");
static_assert(offsetof(UDelMarTrackInfoViewModel, bHasValidTrackData) == 0x70, "Offset mismatch for UDelMarTrackInfoViewModel::bHasValidTrackData");
static_assert(offsetof(UDelMarTrackInfoViewModel, TrackName) == 0x78, "Offset mismatch for UDelMarTrackInfoViewModel::TrackName");
static_assert(offsetof(UDelMarTrackInfoViewModel, TrackDescription) == 0x88, "Offset mismatch for UDelMarTrackInfoViewModel::TrackDescription");
static_assert(offsetof(UDelMarTrackInfoViewModel, LoadingBackgroundImage) == 0x98, "Offset mismatch for UDelMarTrackInfoViewModel::LoadingBackgroundImage");
static_assert(offsetof(UDelMarTrackInfoViewModel, CreatorName) == 0xb8, "Offset mismatch for UDelMarTrackInfoViewModel::CreatorName");
static_assert(offsetof(UDelMarTrackInfoViewModel, bIsEpicCreated) == 0xc8, "Offset mismatch for UDelMarTrackInfoViewModel::bIsEpicCreated");
static_assert(offsetof(UDelMarTrackInfoViewModel, bHasValidCreatorData) == 0xc9, "Offset mismatch for UDelMarTrackInfoViewModel::bHasValidCreatorData");

// Size: 0xb0 (Inherited: 0x170, Single: 0xffffff40)
class UDelMarTutorialViewModel : public UDelMarViewModelBase
{
public:
    FText SectionTitle; // 0x70 (Size: 0x10, Type: TextProperty)
    int32_t CurrentSection; // 0x80 (Size: 0x4, Type: IntProperty)
    int32_t TotalSections; // 0x84 (Size: 0x4, Type: IntProperty)
    TArray<UInputAction*> CurrentTutorialAnnouncementInputActions; // 0x88 (Size: 0x10, Type: ArrayProperty)
    TArray<UInputAction*> CurrentTutorialHintInputActions; // 0x98 (Size: 0x10, Type: ArrayProperty)
    FTimespan FinishTargetTime; // 0xa8 (Size: 0x8, Type: StructProperty)
};

static_assert(sizeof(UDelMarTutorialViewModel) == 0xb0, "Size mismatch for UDelMarTutorialViewModel");
static_assert(offsetof(UDelMarTutorialViewModel, SectionTitle) == 0x70, "Offset mismatch for UDelMarTutorialViewModel::SectionTitle");
static_assert(offsetof(UDelMarTutorialViewModel, CurrentSection) == 0x80, "Offset mismatch for UDelMarTutorialViewModel::CurrentSection");
static_assert(offsetof(UDelMarTutorialViewModel, TotalSections) == 0x84, "Offset mismatch for UDelMarTutorialViewModel::TotalSections");
static_assert(offsetof(UDelMarTutorialViewModel, CurrentTutorialAnnouncementInputActions) == 0x88, "Offset mismatch for UDelMarTutorialViewModel::CurrentTutorialAnnouncementInputActions");
static_assert(offsetof(UDelMarTutorialViewModel, CurrentTutorialHintInputActions) == 0x98, "Offset mismatch for UDelMarTutorialViewModel::CurrentTutorialHintInputActions");
static_assert(offsetof(UDelMarTutorialViewModel, FinishTargetTime) == 0xa8, "Offset mismatch for UDelMarTutorialViewModel::FinishTargetTime");

// Size: 0xf0 (Inherited: 0x170, Single: 0xffffff80)
class UDelMarVehicleViewModel : public UDelMarViewModelBase
{
public:
    bool bHasValidData; // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bIsTurboEnabled; // 0x71 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_72[0x2]; // 0x72 (Size: 0x2, Type: PaddingProperty)
    bool bIsDrifting; // 0x74 (Size: 0x1, Type: BoolProperty)
    bool bIsDriftingRight; // 0x75 (Size: 0x1, Type: BoolProperty)
    bool bWheelsOnGround; // 0x76 (Size: 0x1, Type: BoolProperty)
    bool bAnyWheelsOnGround; // 0x77 (Size: 0x1, Type: BoolProperty)
    TArray<double> DriftRanges; // 0x78 (Size: 0x10, Type: ArrayProperty)
    float DriftSlipAngleRatio; // 0x88 (Size: 0x4, Type: FloatProperty)
    uint8_t DriftSteerState; // 0x8c (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_8d[0x3]; // 0x8d (Size: 0x3, Type: PaddingProperty)
    float PotentialDriftBoostPercent; // 0x90 (Size: 0x4, Type: FloatProperty)
    float StartlineBoostBonus; // 0x94 (Size: 0x4, Type: FloatProperty)
    uint8_t SpeedometerState; // 0x98 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_99[0x3]; // 0x99 (Size: 0x3, Type: PaddingProperty)
    float CurrentSpeed; // 0x9c (Size: 0x4, Type: FloatProperty)
    float NumTurboMaxCharges; // 0xa0 (Size: 0x4, Type: FloatProperty)
    float NumTurboCurrentCharges; // 0xa4 (Size: 0x4, Type: FloatProperty)
    uint8_t TurboBonusZoneState; // 0xa8 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a9[0x3]; // 0xa9 (Size: 0x3, Type: PaddingProperty)
    float UnderthrustPercent; // 0xac (Size: 0x4, Type: FloatProperty)
    double MissedCheckpointDemoTimestamp; // 0xb0 (Size: 0x8, Type: DoubleProperty)
    double ReturnToTrackDemoTimestamp; // 0xb8 (Size: 0x8, Type: DoubleProperty)
    bool bIsHeadingWrongWay; // 0xc0 (Size: 0x1, Type: BoolProperty)
    bool bToggleThrottle; // 0xc1 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c2[0x2]; // 0xc2 (Size: 0x2, Type: PaddingProperty)
    float ThrottleInputValue; // 0xc4 (Size: 0x4, Type: FloatProperty)
    bool bDemolished; // 0xc8 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_c9[0x3]; // 0xc9 (Size: 0x3, Type: PaddingProperty)
    float DemolishActionPressedPercent; // 0xcc (Size: 0x4, Type: FloatProperty)
    bool bDemolishActionEnabled; // 0xd0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_d1[0x3]; // 0xd1 (Size: 0x3, Type: PaddingProperty)
    TWeakObjectPtr<AFortPlayerState*> PlayerState; // 0xd4 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<ADelMarVehicle*> CurrentVehicle; // 0xdc (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UDelMarGlobalInputDisabler*> GlobalInputDisabler; // 0xe4 (Size: 0x8, Type: WeakObjectProperty)
    uint8_t Pad_ec[0x4]; // 0xec (Size: 0x4, Type: PaddingProperty)

public:
    void Initialize(AFortPlayerState*& InPlayerState); // 0x11dc329c (Index: 0x15, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void HandleAnyWheelsOnGroundChanged(const TScriptInterface<Class> VehicleRef, bool& bValue); // 0x11dc0848 (Index: 0x0, Flags: Final|Native|Protected|HasOutParms)
    void HandleDemolishPressDurationUpdated(float& PressedDurationPercentage); // 0x11dc0ac4 (Index: 0x1, Flags: Final|Native|Protected)
    void HandleDriftActivated(); // 0x11dc0c08 (Index: 0x2, Flags: Final|Native|Protected)
    void HandleDriftDeactivated(); // 0x11dc0c1c (Index: 0x3, Flags: Final|Native|Protected)
    void HandleDriftSlipAngleRatioChanged(float& InValue); // 0x11dc0c30 (Index: 0x4, Flags: Final|Native|Protected)
    void HandleMissedCheckpointCountdownCancelled(); // 0x11dc10dc (Index: 0x5, Flags: Final|Native|Protected)
    void HandleMissedCheckpointCountdownInitiated(const FDelMarEvent_MissedCheckpointDemoCountdown Event); // 0x11dc10f0 (Index: 0x6, Flags: Final|Native|Protected|HasOutParms)
    void HandleOnThrottleInput(float& Value); // 0x11dc1310 (Index: 0x7, Flags: Final|Native|Protected)
    void HandleOnVehicleDemolished(FGameplayTag& CausedByTag); // 0x11dc1454 (Index: 0x8, Flags: Final|Native|Protected)
    void HandlePotentialDriftBoostChanged(float& InValue); // 0x11dc180c (Index: 0x9, Flags: Final|Native|Protected)
    void HandleReturnToTrackCountdownCancelled(); // 0x11dc1964 (Index: 0xa, Flags: Final|Native|Protected)
    void HandleReturnToTrackCountdownInitiated(const FDelMarEvent_ReturnToTrackDemoCountdown Event); // 0x11dc1978 (Index: 0xb, Flags: Final|Native|Protected|HasOutParms)
    void HandleSpeedometerSpeedChanged(float& InValue); // 0x11dc1d3c (Index: 0xc, Flags: Final|Native|Protected)
    void HandleStartlineBoostActivated(float& InValue); // 0x11dc1e68 (Index: 0xd, Flags: Final|Native|Protected)
    void HandleStartlineBoostFailed(); // 0x11dc1fac (Index: 0xe, Flags: Final|Native|Protected)
    void HandleToggleThrottleSettingChanged(bool& bValue); // 0x11dc2100 (Index: 0xf, Flags: Final|Native|Protected)
    void HandleTurboBonusZoneChanged(EDelMarTurboZoneState& InTurboBonusZoneState); // 0x11dc2304 (Index: 0x10, Flags: Final|Native|Protected)
    void HandleTurboChargesUpdated(); // 0x11dc2444 (Index: 0x11, Flags: Final|Native|Protected)
    void HandleUnderthrustPercentChanged(float& InValue); // 0x11dc25a0 (Index: 0x12, Flags: Final|Native|Protected)
    void HandleVehicleWheelsLeftGround(); // 0x11dc26f8 (Index: 0x13, Flags: Final|Native|Protected)
    void HandleWrongwayIndication(const FDelMarEvent_VehicleWrongwayStatus Event); // 0x11dc31c0 (Index: 0x14, Flags: Final|Native|Protected|HasOutParms)
};

static_assert(sizeof(UDelMarVehicleViewModel) == 0xf0, "Size mismatch for UDelMarVehicleViewModel");
static_assert(offsetof(UDelMarVehicleViewModel, bHasValidData) == 0x70, "Offset mismatch for UDelMarVehicleViewModel::bHasValidData");
static_assert(offsetof(UDelMarVehicleViewModel, bIsTurboEnabled) == 0x71, "Offset mismatch for UDelMarVehicleViewModel::bIsTurboEnabled");
static_assert(offsetof(UDelMarVehicleViewModel, bIsDrifting) == 0x74, "Offset mismatch for UDelMarVehicleViewModel::bIsDrifting");
static_assert(offsetof(UDelMarVehicleViewModel, bIsDriftingRight) == 0x75, "Offset mismatch for UDelMarVehicleViewModel::bIsDriftingRight");
static_assert(offsetof(UDelMarVehicleViewModel, bWheelsOnGround) == 0x76, "Offset mismatch for UDelMarVehicleViewModel::bWheelsOnGround");
static_assert(offsetof(UDelMarVehicleViewModel, bAnyWheelsOnGround) == 0x77, "Offset mismatch for UDelMarVehicleViewModel::bAnyWheelsOnGround");
static_assert(offsetof(UDelMarVehicleViewModel, DriftRanges) == 0x78, "Offset mismatch for UDelMarVehicleViewModel::DriftRanges");
static_assert(offsetof(UDelMarVehicleViewModel, DriftSlipAngleRatio) == 0x88, "Offset mismatch for UDelMarVehicleViewModel::DriftSlipAngleRatio");
static_assert(offsetof(UDelMarVehicleViewModel, DriftSteerState) == 0x8c, "Offset mismatch for UDelMarVehicleViewModel::DriftSteerState");
static_assert(offsetof(UDelMarVehicleViewModel, PotentialDriftBoostPercent) == 0x90, "Offset mismatch for UDelMarVehicleViewModel::PotentialDriftBoostPercent");
static_assert(offsetof(UDelMarVehicleViewModel, StartlineBoostBonus) == 0x94, "Offset mismatch for UDelMarVehicleViewModel::StartlineBoostBonus");
static_assert(offsetof(UDelMarVehicleViewModel, SpeedometerState) == 0x98, "Offset mismatch for UDelMarVehicleViewModel::SpeedometerState");
static_assert(offsetof(UDelMarVehicleViewModel, CurrentSpeed) == 0x9c, "Offset mismatch for UDelMarVehicleViewModel::CurrentSpeed");
static_assert(offsetof(UDelMarVehicleViewModel, NumTurboMaxCharges) == 0xa0, "Offset mismatch for UDelMarVehicleViewModel::NumTurboMaxCharges");
static_assert(offsetof(UDelMarVehicleViewModel, NumTurboCurrentCharges) == 0xa4, "Offset mismatch for UDelMarVehicleViewModel::NumTurboCurrentCharges");
static_assert(offsetof(UDelMarVehicleViewModel, TurboBonusZoneState) == 0xa8, "Offset mismatch for UDelMarVehicleViewModel::TurboBonusZoneState");
static_assert(offsetof(UDelMarVehicleViewModel, UnderthrustPercent) == 0xac, "Offset mismatch for UDelMarVehicleViewModel::UnderthrustPercent");
static_assert(offsetof(UDelMarVehicleViewModel, MissedCheckpointDemoTimestamp) == 0xb0, "Offset mismatch for UDelMarVehicleViewModel::MissedCheckpointDemoTimestamp");
static_assert(offsetof(UDelMarVehicleViewModel, ReturnToTrackDemoTimestamp) == 0xb8, "Offset mismatch for UDelMarVehicleViewModel::ReturnToTrackDemoTimestamp");
static_assert(offsetof(UDelMarVehicleViewModel, bIsHeadingWrongWay) == 0xc0, "Offset mismatch for UDelMarVehicleViewModel::bIsHeadingWrongWay");
static_assert(offsetof(UDelMarVehicleViewModel, bToggleThrottle) == 0xc1, "Offset mismatch for UDelMarVehicleViewModel::bToggleThrottle");
static_assert(offsetof(UDelMarVehicleViewModel, ThrottleInputValue) == 0xc4, "Offset mismatch for UDelMarVehicleViewModel::ThrottleInputValue");
static_assert(offsetof(UDelMarVehicleViewModel, bDemolished) == 0xc8, "Offset mismatch for UDelMarVehicleViewModel::bDemolished");
static_assert(offsetof(UDelMarVehicleViewModel, DemolishActionPressedPercent) == 0xcc, "Offset mismatch for UDelMarVehicleViewModel::DemolishActionPressedPercent");
static_assert(offsetof(UDelMarVehicleViewModel, bDemolishActionEnabled) == 0xd0, "Offset mismatch for UDelMarVehicleViewModel::bDemolishActionEnabled");
static_assert(offsetof(UDelMarVehicleViewModel, PlayerState) == 0xd4, "Offset mismatch for UDelMarVehicleViewModel::PlayerState");
static_assert(offsetof(UDelMarVehicleViewModel, CurrentVehicle) == 0xdc, "Offset mismatch for UDelMarVehicleViewModel::CurrentVehicle");
static_assert(offsetof(UDelMarVehicleViewModel, GlobalInputDisabler) == 0xe4, "Offset mismatch for UDelMarVehicleViewModel::GlobalInputDisabler");

// Size: 0x80 (Inherited: 0x90, Single: 0xfffffff0)
class UDelMarRankedPlacementChangeVM : public UMVVMViewModelBase
{
public:
    UDelMarRankedPlacementVM* InitialPlacement; // 0x68 (Size: 0x8, Type: ObjectProperty)
    UDelMarRankedPlacementVM* CurrentPlacement; // 0x70 (Size: 0x8, Type: ObjectProperty)
    int32_t PositionDelta; // 0x78 (Size: 0x4, Type: IntProperty)
    bool bIsDataValid; // 0x7c (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_7d[0x3]; // 0x7d (Size: 0x3, Type: PaddingProperty)

public:
    UDelMarRankedPlacementVM* GetCurrentPlacement() const; // 0xa1c46cc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    UDelMarRankedPlacementVM* GetInitialPlacement() const; // 0xa1c4770 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsDataValid() const; // 0xf1a99d4 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetPositionDelta() const; // 0x99c4160 (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarRankedPlacementChangeVM) == 0x80, "Size mismatch for UDelMarRankedPlacementChangeVM");
static_assert(offsetof(UDelMarRankedPlacementChangeVM, InitialPlacement) == 0x68, "Offset mismatch for UDelMarRankedPlacementChangeVM::InitialPlacement");
static_assert(offsetof(UDelMarRankedPlacementChangeVM, CurrentPlacement) == 0x70, "Offset mismatch for UDelMarRankedPlacementChangeVM::CurrentPlacement");
static_assert(offsetof(UDelMarRankedPlacementChangeVM, PositionDelta) == 0x78, "Offset mismatch for UDelMarRankedPlacementChangeVM::PositionDelta");
static_assert(offsetof(UDelMarRankedPlacementChangeVM, bIsDataValid) == 0x7c, "Offset mismatch for UDelMarRankedPlacementChangeVM::bIsDataValid");

// Size: 0x1c0 (Inherited: 0x90, Single: 0x130)
class UDelMarRankedPlacementVM : public UMVVMViewModelBase
{
public:
    bool bIsUnranked; // 0x68 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_69[0x3]; // 0x69 (Size: 0x3, Type: PaddingProperty)
    int32_t TierIndex; // 0x6c (Size: 0x4, Type: IntProperty)
    int32_t PlayerPosition; // 0x70 (Size: 0x4, Type: IntProperty)
    float ProgressTowardNextTier; // 0x74 (Size: 0x4, Type: FloatProperty)
    bool bIsDataValid; // 0x78 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_79[0x7]; // 0x79 (Size: 0x7, Type: PaddingProperty)
    TArray<FFortHabaneroTier> TierList; // 0x80 (Size: 0x10, Type: ArrayProperty)
    UFortHabaneroDisplayData* RankedDisplayData; // 0x90 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_98[0x128]; // 0x98 (Size: 0x128, Type: PaddingProperty)

public:
    bool GetIsDataValid() const; // 0xe773758 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    bool GetIsUnranked() const; // 0x11dc06a8 (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetPlayerPosition() const; // 0xc84634c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    float GetProgressTowardNextTier() const; // 0x11dc072c (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)
    int32_t GetTierIndex() const; // 0x11dc0740 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable|BlueprintPure|Const)

private:
    FFortHabaneroTier TierDisplayData() const; // 0x11dc3f34 (Index: 0x5, Flags: Final|Native|Private|BlueprintCallable|BlueprintPure|Const)
};

static_assert(sizeof(UDelMarRankedPlacementVM) == 0x1c0, "Size mismatch for UDelMarRankedPlacementVM");
static_assert(offsetof(UDelMarRankedPlacementVM, bIsUnranked) == 0x68, "Offset mismatch for UDelMarRankedPlacementVM::bIsUnranked");
static_assert(offsetof(UDelMarRankedPlacementVM, TierIndex) == 0x6c, "Offset mismatch for UDelMarRankedPlacementVM::TierIndex");
static_assert(offsetof(UDelMarRankedPlacementVM, PlayerPosition) == 0x70, "Offset mismatch for UDelMarRankedPlacementVM::PlayerPosition");
static_assert(offsetof(UDelMarRankedPlacementVM, ProgressTowardNextTier) == 0x74, "Offset mismatch for UDelMarRankedPlacementVM::ProgressTowardNextTier");
static_assert(offsetof(UDelMarRankedPlacementVM, bIsDataValid) == 0x78, "Offset mismatch for UDelMarRankedPlacementVM::bIsDataValid");
static_assert(offsetof(UDelMarRankedPlacementVM, TierList) == 0x80, "Offset mismatch for UDelMarRankedPlacementVM::TierList");
static_assert(offsetof(UDelMarRankedPlacementVM, RankedDisplayData) == 0x90, "Offset mismatch for UDelMarRankedPlacementVM::RankedDisplayData");

// Size: 0xb8 (Inherited: 0x90, Single: 0x28)
class UDelMarRankedRecapVM : public UMVVMViewModelBase
{
public:
    UDelMarRankedPlacementChangeVM* PlacementChange; // 0x68 (Size: 0x8, Type: ObjectProperty)
    uint8_t ErrorState; // 0x70 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
    FString OptionalErrorText; // 0x78 (Size: 0x10, Type: StrProperty)
    TWeakObjectPtr<ULocalPlayer*> OwningLocalPlayer; // 0x88 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<AFortPlayerControllerAthena*> OwningPlayerController; // 0x90 (Size: 0x8, Type: WeakObjectProperty)
    UFortHabaneroDisplayData* RankedDisplayData; // 0x98 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_a0[0x18]; // 0xa0 (Size: 0x18, Type: PaddingProperty)

public:
    bool GetUnrankedTierData(FFortHabaneroTier& OutUnrankedTierData); // 0x11dc0754 (Index: 0x0, Flags: Final|Native|Public|HasOutParms|BlueprintCallable)

private:
    void QueryProgress(); // 0x11dc3804 (Index: 0x1, Flags: Final|Native|Private)
};

static_assert(sizeof(UDelMarRankedRecapVM) == 0xb8, "Size mismatch for UDelMarRankedRecapVM");
static_assert(offsetof(UDelMarRankedRecapVM, PlacementChange) == 0x68, "Offset mismatch for UDelMarRankedRecapVM::PlacementChange");
static_assert(offsetof(UDelMarRankedRecapVM, ErrorState) == 0x70, "Offset mismatch for UDelMarRankedRecapVM::ErrorState");
static_assert(offsetof(UDelMarRankedRecapVM, OptionalErrorText) == 0x78, "Offset mismatch for UDelMarRankedRecapVM::OptionalErrorText");
static_assert(offsetof(UDelMarRankedRecapVM, OwningLocalPlayer) == 0x88, "Offset mismatch for UDelMarRankedRecapVM::OwningLocalPlayer");
static_assert(offsetof(UDelMarRankedRecapVM, OwningPlayerController) == 0x90, "Offset mismatch for UDelMarRankedRecapVM::OwningPlayerController");
static_assert(offsetof(UDelMarRankedRecapVM, RankedDisplayData) == 0x98, "Offset mismatch for UDelMarRankedRecapVM::RankedDisplayData");

// Size: 0x40 (Inherited: 0x50, Single: 0xfffffff0)
class UDelMarRankedVMContextResolver : public UMVVMViewModelContextResolver
{
public:
    UFortHabaneroDisplayData* RankedDisplayData; // 0x28 (Size: 0x8, Type: ObjectProperty)
    FString DevelopmentRankedKey; // 0x30 (Size: 0x10, Type: StrProperty)
};

static_assert(sizeof(UDelMarRankedVMContextResolver) == 0x40, "Size mismatch for UDelMarRankedVMContextResolver");
static_assert(offsetof(UDelMarRankedVMContextResolver, RankedDisplayData) == 0x28, "Offset mismatch for UDelMarRankedVMContextResolver::RankedDisplayData");
static_assert(offsetof(UDelMarRankedVMContextResolver, DevelopmentRankedKey) == 0x30, "Offset mismatch for UDelMarRankedVMContextResolver::DevelopmentRankedKey");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FDelMarReactiveWidgetAnimation
{
    FName Intro; // 0x0 (Size: 0x4, Type: NameProperty)
    FName Outro; // 0x4 (Size: 0x4, Type: NameProperty)
};

static_assert(sizeof(FDelMarReactiveWidgetAnimation) == 0x8, "Size mismatch for FDelMarReactiveWidgetAnimation");
static_assert(offsetof(FDelMarReactiveWidgetAnimation, Intro) == 0x0, "Offset mismatch for FDelMarReactiveWidgetAnimation::Intro");
static_assert(offsetof(FDelMarReactiveWidgetAnimation, Outro) == 0x4, "Offset mismatch for FDelMarReactiveWidgetAnimation::Outro");

// Size: 0x28 (Inherited: 0x0, Single: 0x28)
struct FDelMarPlayerIndicatorData
{
    TWeakObjectPtr<AFortPlayerState*> PlayerState; // 0x0 (Size: 0x8, Type: WeakObjectProperty)
    float LateralRatio; // 0x8 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_c[0x4]; // 0xc (Size: 0x4, Type: PaddingProperty)
    FVector2D ScreenPosition; // 0x10 (Size: 0x10, Type: StructProperty)
    float SquareDistance; // 0x20 (Size: 0x4, Type: FloatProperty)
    uint8_t VerticalHint; // 0x24 (Size: 0x1, Type: EnumProperty)
    bool bRearIndicator; // 0x25 (Size: 0x1, Type: BoolProperty)
    bool bShow; // 0x26 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_27[0x1]; // 0x27 (Size: 0x1, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarPlayerIndicatorData) == 0x28, "Size mismatch for FDelMarPlayerIndicatorData");
static_assert(offsetof(FDelMarPlayerIndicatorData, PlayerState) == 0x0, "Offset mismatch for FDelMarPlayerIndicatorData::PlayerState");
static_assert(offsetof(FDelMarPlayerIndicatorData, LateralRatio) == 0x8, "Offset mismatch for FDelMarPlayerIndicatorData::LateralRatio");
static_assert(offsetof(FDelMarPlayerIndicatorData, ScreenPosition) == 0x10, "Offset mismatch for FDelMarPlayerIndicatorData::ScreenPosition");
static_assert(offsetof(FDelMarPlayerIndicatorData, SquareDistance) == 0x20, "Offset mismatch for FDelMarPlayerIndicatorData::SquareDistance");
static_assert(offsetof(FDelMarPlayerIndicatorData, VerticalHint) == 0x24, "Offset mismatch for FDelMarPlayerIndicatorData::VerticalHint");
static_assert(offsetof(FDelMarPlayerIndicatorData, bRearIndicator) == 0x25, "Offset mismatch for FDelMarPlayerIndicatorData::bRearIndicator");
static_assert(offsetof(FDelMarPlayerIndicatorData, bShow) == 0x26, "Offset mismatch for FDelMarPlayerIndicatorData::bShow");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarKeyPair
{
    FKey KBMKey; // 0x0 (Size: 0x18, Type: StructProperty)
    FKey GamepadKey; // 0x18 (Size: 0x18, Type: StructProperty)
};

static_assert(sizeof(FDelMarKeyPair) == 0x30, "Size mismatch for FDelMarKeyPair");
static_assert(offsetof(FDelMarKeyPair, KBMKey) == 0x0, "Offset mismatch for FDelMarKeyPair::KBMKey");
static_assert(offsetof(FDelMarKeyPair, GamepadKey) == 0x18, "Offset mismatch for FDelMarKeyPair::GamepadKey");

// Size: 0x170 (Inherited: 0x0, Single: 0x170)
struct FDelMarTouchActionButtonStateData
{
    FSlateBrush IconBrush; // 0x0 (Size: 0xb0, Type: StructProperty)
    FSlateBrush BackgroundBrush; // 0xb0 (Size: 0xb0, Type: StructProperty)
    uint8_t ButtonVisibility; // 0x160 (Size: 0x1, Type: EnumProperty)
    bool bCancelInputOnEnter; // 0x161 (Size: 0x1, Type: BoolProperty)
    bool bCancelInputOnLeave; // 0x162 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_163[0xd]; // 0x163 (Size: 0xd, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarTouchActionButtonStateData) == 0x170, "Size mismatch for FDelMarTouchActionButtonStateData");
static_assert(offsetof(FDelMarTouchActionButtonStateData, IconBrush) == 0x0, "Offset mismatch for FDelMarTouchActionButtonStateData::IconBrush");
static_assert(offsetof(FDelMarTouchActionButtonStateData, BackgroundBrush) == 0xb0, "Offset mismatch for FDelMarTouchActionButtonStateData::BackgroundBrush");
static_assert(offsetof(FDelMarTouchActionButtonStateData, ButtonVisibility) == 0x160, "Offset mismatch for FDelMarTouchActionButtonStateData::ButtonVisibility");
static_assert(offsetof(FDelMarTouchActionButtonStateData, bCancelInputOnEnter) == 0x161, "Offset mismatch for FDelMarTouchActionButtonStateData::bCancelInputOnEnter");
static_assert(offsetof(FDelMarTouchActionButtonStateData, bCancelInputOnLeave) == 0x162, "Offset mismatch for FDelMarTouchActionButtonStateData::bCancelInputOnLeave");

// Size: 0x30 (Inherited: 0x0, Single: 0x30)
struct FDelMarTouchInputDefinition
{
    UInputAction* InputAction; // 0x0 (Size: 0x8, Type: ObjectProperty)
    TArray<UInputModifier*> Modifiers; // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<UInputTrigger*> Triggers; // 0x18 (Size: 0x10, Type: ArrayProperty)
    bool bUseYAxis; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
};

static_assert(sizeof(FDelMarTouchInputDefinition) == 0x30, "Size mismatch for FDelMarTouchInputDefinition");
static_assert(offsetof(FDelMarTouchInputDefinition, InputAction) == 0x0, "Offset mismatch for FDelMarTouchInputDefinition::InputAction");
static_assert(offsetof(FDelMarTouchInputDefinition, Modifiers) == 0x8, "Offset mismatch for FDelMarTouchInputDefinition::Modifiers");
static_assert(offsetof(FDelMarTouchInputDefinition, Triggers) == 0x18, "Offset mismatch for FDelMarTouchInputDefinition::Triggers");
static_assert(offsetof(FDelMarTouchInputDefinition, bUseYAxis) == 0x28, "Offset mismatch for FDelMarTouchInputDefinition::bUseYAxis");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FDelMarSectionData
{
    int32_t SectionIndex; // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Pad_4[0x4]; // 0x4 (Size: 0x4, Type: PaddingProperty)
    double LapDurationAtSection; // 0x8 (Size: 0x8, Type: DoubleProperty)
    double DeltaTime; // 0x10 (Size: 0x8, Type: DoubleProperty)
};

static_assert(sizeof(FDelMarSectionData) == 0x18, "Size mismatch for FDelMarSectionData");
static_assert(offsetof(FDelMarSectionData, SectionIndex) == 0x0, "Offset mismatch for FDelMarSectionData::SectionIndex");
static_assert(offsetof(FDelMarSectionData, LapDurationAtSection) == 0x8, "Offset mismatch for FDelMarSectionData::LapDurationAtSection");
static_assert(offsetof(FDelMarSectionData, DeltaTime) == 0x10, "Offset mismatch for FDelMarSectionData::DeltaTime");

