/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeCommunicationRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "DynamicUI.h"
#include "GameplayAbilities.h"
#include "CoreUObject.h"

// Size: 0x228 (Inherited: 0x330, Single: 0xfffffef8)
class UCreativeGameStateComponent_CommunicationOverride : public UFortGameStateComponent_CommunicationOverride
{
public:
    uint8_t Pad_e0[0x10]; // 0xe0 (Size: 0x10, Type: PaddingProperty)
    AFortMinigame* CachedMinigame; // 0xf0 (Size: 0x8, Type: ObjectProperty)
    UDynamicUIScene* SproutStyleBubbleChatWidgetScene; // 0xf8 (Size: 0x8, Type: ObjectProperty)
    FCreativeBubbleChatSettings CreativeBubbleChatSettings; // 0x100 (Size: 0x38, Type: StructProperty)
    FScalableFloat BubbleChatEnabled; // 0x138 (Size: 0x28, Type: StructProperty)
    FScalableFloat BubbleChatMaximumRange; // 0x160 (Size: 0x28, Type: StructProperty)
    FScalableFloat BubbleChatMinLifeTime; // 0x188 (Size: 0x28, Type: StructProperty)
    FScalableFloat BubbleChatMaxLifeTime; // 0x1b0 (Size: 0x28, Type: StructProperty)
    FScalableFloat BubbleChatOcculdeBubble; // 0x1d8 (Size: 0x28, Type: StructProperty)
    FScalableFloat BubbleChatStyle; // 0x200 (Size: 0x28, Type: StructProperty)

public:
    virtual void ClientSetWidgetScene(); // 0xcc87b74 (Index: 0x0, Flags: RequiredAPI|Net|NetReliableNative|Event|Public|NetClient)
    void OnMinigameEnded(); // 0x113256ac (Index: 0x1, Flags: Final|Native|Public)
    void OnMinigameStarted(); // 0x113256d0 (Index: 0x2, Flags: Final|Native|Public)
    void SetCustomBubbleChatWidgetClass(TSoftClassPtr& CustomWidget); // 0x11325700 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)

protected:
    void OnRep_CreativeBubbleChatSettings(); // 0x113256e4 (Index: 0x3, Flags: Final|Native|Protected)
};

static_assert(sizeof(UCreativeGameStateComponent_CommunicationOverride) == 0x228, "Size mismatch for UCreativeGameStateComponent_CommunicationOverride");
static_assert(offsetof(UCreativeGameStateComponent_CommunicationOverride, CachedMinigame) == 0xf0, "Offset mismatch for UCreativeGameStateComponent_CommunicationOverride::CachedMinigame");
static_assert(offsetof(UCreativeGameStateComponent_CommunicationOverride, SproutStyleBubbleChatWidgetScene) == 0xf8, "Offset mismatch for UCreativeGameStateComponent_CommunicationOverride::SproutStyleBubbleChatWidgetScene");
static_assert(offsetof(UCreativeGameStateComponent_CommunicationOverride, CreativeBubbleChatSettings) == 0x100, "Offset mismatch for UCreativeGameStateComponent_CommunicationOverride::CreativeBubbleChatSettings");
static_assert(offsetof(UCreativeGameStateComponent_CommunicationOverride, BubbleChatEnabled) == 0x138, "Offset mismatch for UCreativeGameStateComponent_CommunicationOverride::BubbleChatEnabled");
static_assert(offsetof(UCreativeGameStateComponent_CommunicationOverride, BubbleChatMaximumRange) == 0x160, "Offset mismatch for UCreativeGameStateComponent_CommunicationOverride::BubbleChatMaximumRange");
static_assert(offsetof(UCreativeGameStateComponent_CommunicationOverride, BubbleChatMinLifeTime) == 0x188, "Offset mismatch for UCreativeGameStateComponent_CommunicationOverride::BubbleChatMinLifeTime");
static_assert(offsetof(UCreativeGameStateComponent_CommunicationOverride, BubbleChatMaxLifeTime) == 0x1b0, "Offset mismatch for UCreativeGameStateComponent_CommunicationOverride::BubbleChatMaxLifeTime");
static_assert(offsetof(UCreativeGameStateComponent_CommunicationOverride, BubbleChatOcculdeBubble) == 0x1d8, "Offset mismatch for UCreativeGameStateComponent_CommunicationOverride::BubbleChatOcculdeBubble");
static_assert(offsetof(UCreativeGameStateComponent_CommunicationOverride, BubbleChatStyle) == 0x200, "Offset mismatch for UCreativeGameStateComponent_CommunicationOverride::BubbleChatStyle");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCreativeCommunicationOverrideBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static UCreativeGameStateComponent_CommunicationOverride* FindCreativeGameStateComponent_CommunicationOverride(UObject*& const WorldContextObject); // 0x11325548 (Index: 0x0, Flags: Final|Native|Static|Public|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UCreativeCommunicationOverrideBlueprintLibrary) == 0x28, "Size mismatch for UCreativeCommunicationOverrideBlueprintLibrary");

// Size: 0x38 (Inherited: 0x0, Single: 0x38)
struct FCreativeBubbleChatSettings
{
    bool bEnabled; // 0x0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_1[0x3]; // 0x1 (Size: 0x3, Type: PaddingProperty)
    float MaximumRange; // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinLifetime; // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxLifetime; // 0xc (Size: 0x4, Type: FloatProperty)
    bool bOcculdeBubble; // 0x10 (Size: 0x1, Type: BoolProperty)
    uint8_t BubbleChatStyle; // 0x11 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_12[0x6]; // 0x12 (Size: 0x6, Type: PaddingProperty)
    TSoftClassPtr CustomBubbleChatWidgetClass; // 0x18 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FCreativeBubbleChatSettings) == 0x38, "Size mismatch for FCreativeBubbleChatSettings");
static_assert(offsetof(FCreativeBubbleChatSettings, bEnabled) == 0x0, "Offset mismatch for FCreativeBubbleChatSettings::bEnabled");
static_assert(offsetof(FCreativeBubbleChatSettings, MaximumRange) == 0x4, "Offset mismatch for FCreativeBubbleChatSettings::MaximumRange");
static_assert(offsetof(FCreativeBubbleChatSettings, MinLifetime) == 0x8, "Offset mismatch for FCreativeBubbleChatSettings::MinLifetime");
static_assert(offsetof(FCreativeBubbleChatSettings, MaxLifetime) == 0xc, "Offset mismatch for FCreativeBubbleChatSettings::MaxLifetime");
static_assert(offsetof(FCreativeBubbleChatSettings, bOcculdeBubble) == 0x10, "Offset mismatch for FCreativeBubbleChatSettings::bOcculdeBubble");
static_assert(offsetof(FCreativeBubbleChatSettings, BubbleChatStyle) == 0x11, "Offset mismatch for FCreativeBubbleChatSettings::BubbleChatStyle");
static_assert(offsetof(FCreativeBubbleChatSettings, CustomBubbleChatWidgetClass) == 0x18, "Offset mismatch for FCreativeBubbleChatSettings::CustomBubbleChatWidgetClass");

