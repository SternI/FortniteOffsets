/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticsFrameworkModifiers
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCosmeticModifierInterface : public UInterface
{
public:
};

static_assert(sizeof(UCosmeticModifierInterface) == 0x28, "Size mismatch for UCosmeticModifierInterface");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCosmeticModifierOwnerInterface : public UInterface
{
public:
};

static_assert(sizeof(UCosmeticModifierOwnerInterface) == 0x28, "Size mismatch for UCosmeticModifierOwnerInterface");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UCosmeticModifierProviderInterface : public UInterface
{
public:
};

static_assert(sizeof(UCosmeticModifierProviderInterface) == 0x28, "Size mismatch for UCosmeticModifierProviderInterface");

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FSoftModifierClassPtr
{
    TSoftClassPtr SoftClass; // 0x0 (Size: 0x20, Type: SoftClassProperty)
};

static_assert(sizeof(FSoftModifierClassPtr) == 0x20, "Size mismatch for FSoftModifierClassPtr");
static_assert(offsetof(FSoftModifierClassPtr, SoftClass) == 0x0, "Offset mismatch for FSoftModifierClassPtr::SoftClass");

