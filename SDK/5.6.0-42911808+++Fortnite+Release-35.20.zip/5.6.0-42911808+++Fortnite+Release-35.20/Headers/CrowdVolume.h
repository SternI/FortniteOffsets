/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CrowdVolume
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "FortniteGame.h"

// Size: 0x280 (Inherited: 0x320, Single: 0xffffff60)
class UCrowdSpawner : public USceneComponent
{
public:
    TArray<UHierarchicalInstancedStaticMeshComponent*> CharacterMeshes; // 0x240 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_250[0x30]; // 0x250 (Size: 0x30, Type: PaddingProperty)

public:
    void RefreshTrackedActors(UPlayspaceComponent_SpatialActorTracker*& InPlaySpaceComponent_SpatialActorTracker); // 0x11324c98 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SpawnCrowd(int32_t& Width, int32_t& Depth, int32_t& Height, int32_t& Precision, int32_t& CharacterScaleRandomness, int32_t& CharacterAngleRandomness, int32_t& Density); // 0x11aa128c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UCrowdSpawner) == 0x280, "Size mismatch for UCrowdSpawner");
static_assert(offsetof(UCrowdSpawner, CharacterMeshes) == 0x240, "Offset mismatch for UCrowdSpawner::CharacterMeshes");

