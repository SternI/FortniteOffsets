/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AmbientAudio
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "AudioGameplay.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "GameplayTags.h"

// Size: 0xf0 (Inherited: 0x1a0, Single: 0xffffff50)
class UAmbientAudioComponent : public UAudioGameplayComponent
{
public:
    uint8_t Pad_c0[0x8]; // 0xc0 (Size: 0x8, Type: PaddingProperty)
    UAmbientAudioDataAsset* AmbientAsset; // 0xc8 (Size: 0x8, Type: ObjectProperty)
    int32_t Priority; // 0xd0 (Size: 0x4, Type: IntProperty)
    float CrossfadeTime; // 0xd4 (Size: 0x4, Type: FloatProperty)
    FGuid AmbientGuid; // 0xd8 (Size: 0x10, Type: StructProperty)
    FName DisplayName; // 0xe8 (Size: 0x4, Type: NameProperty)
    uint8_t Pad_ec[0x4]; // 0xec (Size: 0x4, Type: PaddingProperty)

public:
    void SetAmbientAsset(UAmbientAudioDataAsset*& InAmbientAsset); // 0xc33feb0 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void SetCrossfadeTime(float& InCrossfadeTime); // 0xc33ffdc (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    void SetPriority(int32_t& InPriority); // 0xc340118 (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAmbientAudioComponent) == 0xf0, "Size mismatch for UAmbientAudioComponent");
static_assert(offsetof(UAmbientAudioComponent, AmbientAsset) == 0xc8, "Offset mismatch for UAmbientAudioComponent::AmbientAsset");
static_assert(offsetof(UAmbientAudioComponent, Priority) == 0xd0, "Offset mismatch for UAmbientAudioComponent::Priority");
static_assert(offsetof(UAmbientAudioComponent, CrossfadeTime) == 0xd4, "Offset mismatch for UAmbientAudioComponent::CrossfadeTime");
static_assert(offsetof(UAmbientAudioComponent, AmbientGuid) == 0xd8, "Offset mismatch for UAmbientAudioComponent::AmbientGuid");
static_assert(offsetof(UAmbientAudioComponent, DisplayName) == 0xe8, "Offset mismatch for UAmbientAudioComponent::DisplayName");

// Size: 0x58 (Inherited: 0x58, Single: 0x0)
class UAmbientAudioDataAsset : public UDataAsset
{
public:
    TArray<FAmbientAudioLoop> LoopingSounds; // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FAmbientAudioOneShot> OneShotSounds; // 0x40 (Size: 0x10, Type: ArrayProperty)
    float TagCrossfadeTime; // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t Pad_54[0x4]; // 0x54 (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(UAmbientAudioDataAsset) == 0x58, "Size mismatch for UAmbientAudioDataAsset");
static_assert(offsetof(UAmbientAudioDataAsset, LoopingSounds) == 0x30, "Offset mismatch for UAmbientAudioDataAsset::LoopingSounds");
static_assert(offsetof(UAmbientAudioDataAsset, OneShotSounds) == 0x40, "Offset mismatch for UAmbientAudioDataAsset::OneShotSounds");
static_assert(offsetof(UAmbientAudioDataAsset, TagCrossfadeTime) == 0x50, "Offset mismatch for UAmbientAudioDataAsset::TagCrossfadeTime");

// Size: 0x258 (Inherited: 0x88, Single: 0x1d0)
class UAmbientAudioSubsystem : public UWorldSubsystem
{
public:
    uint8_t Pad_30[0x8]; // 0x30 (Size: 0x8, Type: PaddingProperty)
    uint8_t OnTagChanged[0x10]; // 0x38 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    uint8_t OnEntryChanged[0x10]; // 0x48 (Size: 0x10, Type: MulticastInlineDelegateProperty)
    TArray<UAmbientAudioComponent*> AmbientComponents; // 0x58 (Size: 0x10, Type: ArrayProperty)
    AAmbientAudioParameterActor* ParameterActor; // 0x68 (Size: 0x8, Type: ObjectProperty)
    uint8_t Pad_70[0x1e8]; // 0x70 (Size: 0x1e8, Type: PaddingProperty)

public:
    void AddAmbientEntry(FName& AmbientName, UAmbientAudioDataAsset*& Asset, int32_t& Priority, float& CrossfadeTime); // 0x3711ddc (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
    void AddGameplayTag(FGameplayTag& GameplayTag); // 0x371416c (Index: 0x1, Flags: Final|Native|Public|BlueprintCallable)
    UAudioParameterComponent* GetAudioParameterComponent(); // 0x57ced5c (Index: 0x2, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveAmbientEntry(FName& AmbientName, float& CrossfadeOverride); // 0x5430dcc (Index: 0x3, Flags: Final|Native|Public|BlueprintCallable)
    void RemoveGameplayTag(FGameplayTag& GameplayTag); // 0x3711c90 (Index: 0x4, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UAmbientAudioSubsystem) == 0x258, "Size mismatch for UAmbientAudioSubsystem");
static_assert(offsetof(UAmbientAudioSubsystem, OnTagChanged) == 0x38, "Offset mismatch for UAmbientAudioSubsystem::OnTagChanged");
static_assert(offsetof(UAmbientAudioSubsystem, OnEntryChanged) == 0x48, "Offset mismatch for UAmbientAudioSubsystem::OnEntryChanged");
static_assert(offsetof(UAmbientAudioSubsystem, AmbientComponents) == 0x58, "Offset mismatch for UAmbientAudioSubsystem::AmbientComponents");
static_assert(offsetof(UAmbientAudioSubsystem, ParameterActor) == 0x68, "Offset mismatch for UAmbientAudioSubsystem::ParameterActor");

// Size: 0x2b0 (Inherited: 0x2d0, Single: 0xffffffe0)
class AAmbientAudioParameterActor : public AActor
{
public:
    UAudioParameterComponent* Parameters; // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

static_assert(sizeof(AAmbientAudioParameterActor) == 0x2b0, "Size mismatch for AAmbientAudioParameterActor");
static_assert(offsetof(AAmbientAudioParameterActor, Parameters) == 0x2a8, "Offset mismatch for AAmbientAudioParameterActor::Parameters");

// Size: 0xb8 (Inherited: 0x0, Single: 0xb8)
struct FAmbientAudioBase
{
    TSoftObjectPtr<USoundBase*> Sound; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FGameplayTagQuery Requirements; // 0x20 (Size: 0x48, Type: StructProperty)
    FAudioGameplayRequirements PlaybackRequirements; // 0x68 (Size: 0x50, Type: StructProperty)
};

static_assert(sizeof(FAmbientAudioBase) == 0xb8, "Size mismatch for FAmbientAudioBase");
static_assert(offsetof(FAmbientAudioBase, Sound) == 0x0, "Offset mismatch for FAmbientAudioBase::Sound");
static_assert(offsetof(FAmbientAudioBase, Requirements) == 0x20, "Offset mismatch for FAmbientAudioBase::Requirements");
static_assert(offsetof(FAmbientAudioBase, PlaybackRequirements) == 0x68, "Offset mismatch for FAmbientAudioBase::PlaybackRequirements");

// Size: 0xb8 (Inherited: 0xb8, Single: 0x0)
struct FAmbientAudioLoop : FAmbientAudioBase
{
};

static_assert(sizeof(FAmbientAudioLoop) == 0xb8, "Size mismatch for FAmbientAudioLoop");

// Size: 0xd8 (Inherited: 0xb8, Single: 0x20)
struct FAmbientAudioOneShot : FAmbientAudioBase
{
    FVector2D RetriggerTimeRange; // 0xb8 (Size: 0x10, Type: StructProperty)
    FVector2D TriggerDistanceRange; // 0xc8 (Size: 0x10, Type: StructProperty)
};

static_assert(sizeof(FAmbientAudioOneShot) == 0xd8, "Size mismatch for FAmbientAudioOneShot");
static_assert(offsetof(FAmbientAudioOneShot, RetriggerTimeRange) == 0xb8, "Offset mismatch for FAmbientAudioOneShot::RetriggerTimeRange");
static_assert(offsetof(FAmbientAudioOneShot, TriggerDistanceRange) == 0xc8, "Offset mismatch for FAmbientAudioOneShot::TriggerDistanceRange");

