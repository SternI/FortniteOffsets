/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BattleRoyaleGame
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0xb8 (Inherited: 0x3c0, Single: 0xfffffcf8)
class UFortGameStateComponent_BattleRoyalePlacementInfo : public UFortGameStateComponent_PlacementInfo
{
public:
};

static_assert(sizeof(UFortGameStateComponent_BattleRoyalePlacementInfo) == 0xb8, "Size mismatch for UFortGameStateComponent_BattleRoyalePlacementInfo");

