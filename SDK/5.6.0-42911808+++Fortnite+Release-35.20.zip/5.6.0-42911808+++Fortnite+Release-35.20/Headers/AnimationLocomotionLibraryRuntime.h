/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnimationLocomotionLibraryRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "CoreUObject.h"
#include "AnimGraphRuntime.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAnimCharacterMovementLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FVector PredictGroundMovementPivotLocation(const FVector Acceleration, const FVector Velocity, float& GroundFriction); // 0x101eb4a0 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
    static FVector PredictGroundMovementStopLocation(const FVector Velocity, bool& bUseSeparateBrakingFriction, float& BrakingFriction, float& GroundFriction, float& BrakingFrictionFactor, float& BrakingDecelerationWalking); // 0x101eb6c8 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure)
};

static_assert(sizeof(UAnimCharacterMovementLibrary) == 0x28, "Size mismatch for UAnimCharacterMovementLibrary");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UAnimDistanceMatchingLibrary : public UBlueprintFunctionLibrary
{
public:

public:
    static FSequenceEvaluatorReference AdvanceTimeByDistanceMatching(const FAnimUpdateContext UpdateContext, const FSequenceEvaluatorReference SequenceEvaluator, float& DistanceTraveled, FName& DistanceCurveName, FVector2D& PlayRateClamp); // 0x101eafc4 (Index: 0x0, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
    static FSequenceEvaluatorReference DistanceMatchToTarget(const FSequenceEvaluatorReference SequenceEvaluator, float& DistanceToTarget, FName& DistanceCurveName); // 0x101eb2d8 (Index: 0x1, Flags: Final|Native|Static|Public|HasOutParms|BlueprintCallable)
    static FSequencePlayerReference SetPlayrateToMatchSpeed(const FSequencePlayerReference SequencePlayer, float& SpeedToMatch, FVector2D& PlayRateClamp); // 0x101eba9c (Index: 0x2, Flags: Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable)
};

static_assert(sizeof(UAnimDistanceMatchingLibrary) == 0x28, "Size mismatch for UAnimDistanceMatchingLibrary");

