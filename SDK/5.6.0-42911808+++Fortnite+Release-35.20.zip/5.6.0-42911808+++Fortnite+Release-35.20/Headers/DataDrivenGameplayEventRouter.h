/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataDrivenGameplayEventRouter
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayEventRouter.h"

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameplayEventLegacyBroadcast : public UInterface
{
public:
};

static_assert(sizeof(UGameplayEventLegacyBroadcast) == 0x28, "Size mismatch for UGameplayEventLegacyBroadcast");

// Size: 0x28 (Inherited: 0x50, Single: 0xffffffd8)
class UGameplayEventDescriptorLibrary : public UBlueprintFunctionLibrary
{
public:

private:
    static bool BroadcastEvent(const FGameplayEventDescriptor EventDescriptor, UObject*& EventContext, const int32_t Event, UClass*& EventRouterScope, AActor*& RouterContextActor); // 0x377547c (Index: 0x0, Flags: Final|Native|Static|Private|HasOutParms|BlueprintCallable)
};

static_assert(sizeof(UGameplayEventDescriptorLibrary) == 0x28, "Size mismatch for UGameplayEventDescriptorLibrary");

// Size: 0x10 (Inherited: 0x0, Single: 0x10)
struct FGameplayEventDefinition
{
    UScriptStruct* EventType; // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bIsStateful; // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t NetPolicy; // 0x9 (Size: 0x1, Type: EnumProperty)
    uint8_t Pad_a[0x6]; // 0xa (Size: 0x6, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayEventDefinition) == 0x10, "Size mismatch for FGameplayEventDefinition");
static_assert(offsetof(FGameplayEventDefinition, EventType) == 0x0, "Offset mismatch for FGameplayEventDefinition::EventType");
static_assert(offsetof(FGameplayEventDefinition, bIsStateful) == 0x8, "Offset mismatch for FGameplayEventDefinition::bIsStateful");
static_assert(offsetof(FGameplayEventDefinition, NetPolicy) == 0x9, "Offset mismatch for FGameplayEventDefinition::NetPolicy");

// Size: 0x8 (Inherited: 0x0, Single: 0x8)
struct FGameplayEventDescriptor
{
};

static_assert(sizeof(FGameplayEventDescriptor) == 0x8, "Size mismatch for FGameplayEventDescriptor");

// Size: 0x70 (Inherited: 0x0, Single: 0x70)
struct FGameplayEventSubscription
{
    TSoftObjectPtr<UObject*> Object; // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FMemberReference EventDescriptor; // 0x20 (Size: 0x30, Type: StructProperty)
    FGameplayEventListenerHandle EventHandle; // 0x50 (Size: 0x1c, Type: StructProperty)
    uint8_t Pad_6c[0x4]; // 0x6c (Size: 0x4, Type: PaddingProperty)
};

static_assert(sizeof(FGameplayEventSubscription) == 0x70, "Size mismatch for FGameplayEventSubscription");
static_assert(offsetof(FGameplayEventSubscription, Object) == 0x0, "Offset mismatch for FGameplayEventSubscription::Object");
static_assert(offsetof(FGameplayEventSubscription, EventDescriptor) == 0x20, "Offset mismatch for FGameplayEventSubscription::EventDescriptor");
static_assert(offsetof(FGameplayEventSubscription, EventHandle) == 0x50, "Offset mismatch for FGameplayEventSubscription::EventHandle");

// Size: 0x80 (Inherited: 0x0, Single: 0x80)
struct FGameplayEventHandlerFunction
{
    FMemberReference EventHandlerFunction; // 0x0 (Size: 0x30, Type: StructProperty)
    TMap<FString, FName> EventHandlerFunctionDefaultValues; // 0x30 (Size: 0x50, Type: MapProperty)
};

static_assert(sizeof(FGameplayEventHandlerFunction) == 0x80, "Size mismatch for FGameplayEventHandlerFunction");
static_assert(offsetof(FGameplayEventHandlerFunction, EventHandlerFunction) == 0x0, "Offset mismatch for FGameplayEventHandlerFunction::EventHandlerFunction");
static_assert(offsetof(FGameplayEventHandlerFunction, EventHandlerFunctionDefaultValues) == 0x30, "Offset mismatch for FGameplayEventHandlerFunction::EventHandlerFunctionDefaultValues");

// Size: 0x180 (Inherited: 0x0, Single: 0x180)
struct FGameplayEventHandlerFunctions
{
    FGameplayEventHandlerFunction OnEventReceived; // 0x0 (Size: 0x80, Type: StructProperty)
    FGameplayEventHandlerFunction OnStatefulEventApplied; // 0x80 (Size: 0x80, Type: StructProperty)
    FGameplayEventHandlerFunction OnStatefulEventCleared; // 0x100 (Size: 0x80, Type: StructProperty)
};

static_assert(sizeof(FGameplayEventHandlerFunctions) == 0x180, "Size mismatch for FGameplayEventHandlerFunctions");
static_assert(offsetof(FGameplayEventHandlerFunctions, OnEventReceived) == 0x0, "Offset mismatch for FGameplayEventHandlerFunctions::OnEventReceived");
static_assert(offsetof(FGameplayEventHandlerFunctions, OnStatefulEventApplied) == 0x80, "Offset mismatch for FGameplayEventHandlerFunctions::OnStatefulEventApplied");
static_assert(offsetof(FGameplayEventHandlerFunctions, OnStatefulEventCleared) == 0x100, "Offset mismatch for FGameplayEventHandlerFunctions::OnStatefulEventCleared");

// Size: 0x18 (Inherited: 0x0, Single: 0x18)
struct FGameplayEventFunction
{
    TArray<FGameplayEventSubscription> EventSubscriptions; // 0x8 (Size: 0x10, Type: ArrayProperty)
};

static_assert(sizeof(FGameplayEventFunction) == 0x18, "Size mismatch for FGameplayEventFunction");
static_assert(offsetof(FGameplayEventFunction, EventSubscriptions) == 0x8, "Offset mismatch for FGameplayEventFunction::EventSubscriptions");

