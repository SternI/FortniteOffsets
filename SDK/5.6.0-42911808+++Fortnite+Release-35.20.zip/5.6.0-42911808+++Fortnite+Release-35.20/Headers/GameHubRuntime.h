/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameHubRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteGame.h"
#include "PlayspaceSystem.h"
#include "Engine.h"
#include "GameplayTags.h"

// Size: 0x370 (Inherited: 0xbc0, Single: 0xfffff7b0)
class AGameHubBaseMutator : public AFortAthenaMutator
{
public:
};

static_assert(sizeof(AGameHubBaseMutator) == 0x370, "Size mismatch for AGameHubBaseMutator");

// Size: 0xe8 (Inherited: 0x318, Single: 0xfffffdd0)
class UGameHubPlayerSpawningComponent : public UPlayspaceComponent_PlayerSpawning
{
public:
    FGameplayTagContainer PlayerStartRequirements; // 0xc8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(UGameHubPlayerSpawningComponent) == 0xe8, "Size mismatch for UGameHubPlayerSpawningComponent");
static_assert(offsetof(UGameHubPlayerSpawningComponent, PlayerStartRequirements) == 0xc8, "Offset mismatch for UGameHubPlayerSpawningComponent::PlayerStartRequirements");

// Size: 0x708 (Inherited: 0x1240, Single: 0xfffff4c8)
class AGameHubPlayspace : public AFortPlayspace
{
public:
    bool bSimulatePlayerDamage; // 0x6e0 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_6e1[0x7]; // 0x6e1 (Size: 0x7, Type: PaddingProperty)
    FGameplayTagContainer PlayerStartRequirements; // 0x6e8 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(AGameHubPlayspace) == 0x708, "Size mismatch for AGameHubPlayspace");
static_assert(offsetof(AGameHubPlayspace, bSimulatePlayerDamage) == 0x6e0, "Offset mismatch for AGameHubPlayspace::bSimulatePlayerDamage");
static_assert(offsetof(AGameHubPlayspace, PlayerStartRequirements) == 0x6e8, "Offset mismatch for AGameHubPlayspace::PlayerStartRequirements");

