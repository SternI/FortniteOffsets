/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarTrackSelectorUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "FortniteUI.h"
#include "ModelViewViewModel.h"
#include "CoreUObject.h"
#include "FortniteGame.h"

// Size: 0xe0 (Inherited: 0x50, Single: 0x90)
class UDelMarMatchmakingSettingsUI : public UMatchmakingSettingsUI
{
public:
    FText MatchmakingSettingsButtonPrimaryText; // 0x28 (Size: 0x10, Type: TextProperty)
    FText MatchmakingSettingsButtonInvalidSelectionText; // 0x38 (Size: 0x10, Type: TextProperty)
    FText MatchmakingSettingsButtonRankedText; // 0x48 (Size: 0x10, Type: TextProperty)
    TSoftClassPtr MatchmakingSettingsModificationModal; // 0x58 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr TrackSelectScreen; // 0x78 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr ProductLogoWidget; // 0x98 (Size: 0x20, Type: SoftClassProperty)
    TSoftClassPtr MatchFoundWidget; // 0xb8 (Size: 0x20, Type: SoftClassProperty)
    UClass* ProductModeUserFacingDataClass; // 0xd8 (Size: 0x8, Type: ClassProperty)
};

static_assert(sizeof(UDelMarMatchmakingSettingsUI) == 0xe0, "Size mismatch for UDelMarMatchmakingSettingsUI");
static_assert(offsetof(UDelMarMatchmakingSettingsUI, MatchmakingSettingsButtonPrimaryText) == 0x28, "Offset mismatch for UDelMarMatchmakingSettingsUI::MatchmakingSettingsButtonPrimaryText");
static_assert(offsetof(UDelMarMatchmakingSettingsUI, MatchmakingSettingsButtonInvalidSelectionText) == 0x38, "Offset mismatch for UDelMarMatchmakingSettingsUI::MatchmakingSettingsButtonInvalidSelectionText");
static_assert(offsetof(UDelMarMatchmakingSettingsUI, MatchmakingSettingsButtonRankedText) == 0x48, "Offset mismatch for UDelMarMatchmakingSettingsUI::MatchmakingSettingsButtonRankedText");
static_assert(offsetof(UDelMarMatchmakingSettingsUI, MatchmakingSettingsModificationModal) == 0x58, "Offset mismatch for UDelMarMatchmakingSettingsUI::MatchmakingSettingsModificationModal");
static_assert(offsetof(UDelMarMatchmakingSettingsUI, TrackSelectScreen) == 0x78, "Offset mismatch for UDelMarMatchmakingSettingsUI::TrackSelectScreen");
static_assert(offsetof(UDelMarMatchmakingSettingsUI, ProductLogoWidget) == 0x98, "Offset mismatch for UDelMarMatchmakingSettingsUI::ProductLogoWidget");
static_assert(offsetof(UDelMarMatchmakingSettingsUI, MatchFoundWidget) == 0xb8, "Offset mismatch for UDelMarMatchmakingSettingsUI::MatchFoundWidget");
static_assert(offsetof(UDelMarMatchmakingSettingsUI, ProductModeUserFacingDataClass) == 0xd8, "Offset mismatch for UDelMarMatchmakingSettingsUI::ProductModeUserFacingDataClass");

// Size: 0x98 (Inherited: 0x90, Single: 0x8)
class UDelMarRankedViewModel : public UMVVMViewModelBase
{
public:
    UFortSocialUser* SocialUser; // 0x68 (Size: 0x8, Type: ObjectProperty)
    bool bIsPlayerRanked; // 0x70 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_71[0x7]; // 0x71 (Size: 0x7, Type: PaddingProperty)
    FString RankType; // 0x78 (Size: 0x10, Type: StrProperty)
    int32_t CurrentRank; // 0x88 (Size: 0x4, Type: IntProperty)
    int32_t HighestRank; // 0x8c (Size: 0x4, Type: IntProperty)
    int32_t CurrentPlayerPosition; // 0x90 (Size: 0x4, Type: IntProperty)
    float Progress; // 0x94 (Size: 0x4, Type: FloatProperty)

public:
    void InitializeRankedViewModal(); // 0x1217d128 (Index: 0x0, Flags: Final|Native|Public|BlueprintCallable)
};

static_assert(sizeof(UDelMarRankedViewModel) == 0x98, "Size mismatch for UDelMarRankedViewModel");
static_assert(offsetof(UDelMarRankedViewModel, SocialUser) == 0x68, "Offset mismatch for UDelMarRankedViewModel::SocialUser");
static_assert(offsetof(UDelMarRankedViewModel, bIsPlayerRanked) == 0x70, "Offset mismatch for UDelMarRankedViewModel::bIsPlayerRanked");
static_assert(offsetof(UDelMarRankedViewModel, RankType) == 0x78, "Offset mismatch for UDelMarRankedViewModel::RankType");
static_assert(offsetof(UDelMarRankedViewModel, CurrentRank) == 0x88, "Offset mismatch for UDelMarRankedViewModel::CurrentRank");
static_assert(offsetof(UDelMarRankedViewModel, HighestRank) == 0x8c, "Offset mismatch for UDelMarRankedViewModel::HighestRank");
static_assert(offsetof(UDelMarRankedViewModel, CurrentPlayerPosition) == 0x90, "Offset mismatch for UDelMarRankedViewModel::CurrentPlayerPosition");
static_assert(offsetof(UDelMarRankedViewModel, Progress) == 0x94, "Offset mismatch for UDelMarRankedViewModel::Progress");

