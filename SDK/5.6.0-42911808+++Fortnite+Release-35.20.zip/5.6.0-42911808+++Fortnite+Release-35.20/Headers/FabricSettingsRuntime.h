/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricSettingsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"

// Size: 0x40 (Inherited: 0x68, Single: 0xffffffd8)
class UFabricClientSettingRecordPartition : public UFortClientSettingRecordPartition
{
public:
};

static_assert(sizeof(UFabricClientSettingRecordPartition) == 0x40, "Size mismatch for UFabricClientSettingRecordPartition");

