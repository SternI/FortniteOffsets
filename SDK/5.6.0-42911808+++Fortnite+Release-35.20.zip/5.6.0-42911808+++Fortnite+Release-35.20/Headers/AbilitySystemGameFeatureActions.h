/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AbilitySystemGameFeatureActions
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameFeatures.h"
#include "CoreUObject.h"

// Size: 0x48 (Inherited: 0x50, Single: 0xfffffff8)
class UGameFeatureAction_AddAttributeDefaults : public UGameFeatureAction
{
public:
    bool bApplyOnRegister; // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Pad_29[0x7]; // 0x29 (Size: 0x7, Type: PaddingProperty)
    TArray<FSoftObjectPath> AttribDefaultTableNames; // 0x30 (Size: 0x10, Type: ArrayProperty)
    uint8_t Pad_40[0x8]; // 0x40 (Size: 0x8, Type: PaddingProperty)
};

static_assert(sizeof(UGameFeatureAction_AddAttributeDefaults) == 0x48, "Size mismatch for UGameFeatureAction_AddAttributeDefaults");
static_assert(offsetof(UGameFeatureAction_AddAttributeDefaults, bApplyOnRegister) == 0x28, "Offset mismatch for UGameFeatureAction_AddAttributeDefaults::bApplyOnRegister");
static_assert(offsetof(UGameFeatureAction_AddAttributeDefaults, AttribDefaultTableNames) == 0x30, "Offset mismatch for UGameFeatureAction_AddAttributeDefaults::AttribDefaultTableNames");

