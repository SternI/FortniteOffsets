/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicGamesTemporary
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x20 (Inherited: 0x0, Single: 0x20)
struct FVerseRotation_Deprecated
{
    FQuat Quaternion; // 0x0 (Size: 0x20, Type: StructProperty)
};

static_assert(sizeof(FVerseRotation_Deprecated) == 0x20, "Size mismatch for FVerseRotation_Deprecated");
static_assert(offsetof(FVerseRotation_Deprecated, Quaternion) == 0x0, "Offset mismatch for FVerseRotation_Deprecated::Quaternion");

