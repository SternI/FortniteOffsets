/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AnalyticsBlueprintLibrary
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x28
class UAnalyticsBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x20
struct FAnalyticsEventAttr
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

