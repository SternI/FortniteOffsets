/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BP_FortSettingVolumeMarkup_SparksMusic
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0xa0
class UBP_FortSettingVolumeMarkup_SparksMusic_C : public UFortSettingVolumeMarkup
{
public:
};

