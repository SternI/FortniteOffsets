/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DelMarSettings
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0x40
class UDelMarClientSettingRecordPartition : public UFortClientSettingRecordPartition
{
public:
};

// Size: 0x80
class UDelMarInputContextRedirectMap : public UDataAsset
{
public:
    TMap<UFortInputMappingContext*, UFortInputMappingContext*> RedirectMap() const { return Read<TMap<UFortInputMappingContext*, UFortInputMappingContext*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_RedirectMap(const TMap<UFortInputMappingContext*, UFortInputMappingContext*>& Value) { Write<TMap<UFortInputMappingContext*, UFortInputMappingContext*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

// Size: 0x28
class UDelMarInputModifierPitchInversion : public UInputModifier
{
public:
};

// Size: 0x28
class UDelMarInputModifierZeroOut : public UInputModifier
{
public:
};

// Size: 0x28
class UDelMarInputModifierAlwaysOne : public UInputModifier
{
public:
};

// Size: 0x58
class UDelMarInputModifierScalarBySign : public UInputModifier
{
public:
    FVector PositiveScalar() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FVector NegativeScalar() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_PositiveScalar(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_NegativeScalar(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x58
class UDelMarInputModifierClamp : public UInputModifier
{
public:
    FVector Minimum() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FVector Maximum() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_Minimum(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_Maximum(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
class UDelMarSettingsGlobals : public UObject
{
public:
    FGameplayTag DefaultTouchControlsLayout() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)

    void SET_DefaultTouchControlsLayout(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
};

// Size: 0x110
class UGameFeatureAction_AddInputContextMappingPlatformOverrides : public UGameFeatureAction_AddInputContextMapping
{
public:
    TSoftObjectPtr<UDelMarInputContextRedirectMap> DigitalRedirectMap() const { return Read<TSoftObjectPtr<UDelMarInputContextRedirectMap>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x20, Type: SoftObjectProperty)

    void SET_DigitalRedirectMap(const TSoftObjectPtr<UDelMarInputContextRedirectMap>& Value) { Write<TSoftObjectPtr<UDelMarInputContextRedirectMap>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x20, Type: SoftObjectProperty)
};

