/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AtomRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "ISMPool.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x28
class UAtomActorConnectivityResolver : public UObject
{
public:
};

// Size: 0x40
class UAtomActorConnectivityResolverRegistry : public UDeveloperSettings
{
public:
    TArray<UClass*> Resolvers() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Resolvers(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UAtomTextureImportData : public UAssetImportData
{
public:
};

// Size: 0x58
class UAtomColorThemeTextureUserData : public UAssetUserData
{
public:
    TArray<FName> ThemeNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UAtomColorThemeLibrary> SourceColorThemeLibrary() const { return Read<TSoftObjectPtr<UAtomColorThemeLibrary>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x20, Type: SoftObjectProperty)

    void SET_ThemeNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_SourceColorThemeLibrary(const TSoftObjectPtr<UAtomColorThemeLibrary>& Value) { Write<TSoftObjectPtr<UAtomColorThemeLibrary>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x520
class UAtomCollisionComponent : public UPrimitiveComponent
{
public:
    UBodySetup* BodySetup() const { return Read<UBodySetup*>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: ObjectProperty)

    void SET_BodySetup(const UBodySetup*& Value) { Write<UBodySetup*>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x48
class UAtomColorLUTAtlas : public UObject
{
public:
    UTexture2D* AtlasTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    TArray<UTexture2D*> Textures() const { return Read<TArray<UTexture2D*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_AtlasTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_Textures(const TArray<UTexture2D*>& Value) { Write<TArray<UTexture2D*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xe8
class UAtomColorThemeComponent : public UActorComponent
{
public:
    UAtomColorLUTAtlas* ColorLUTAtlas() const { return Read<UAtomColorLUTAtlas*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* ColorLUTTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    bool bIsThemeCustomTexture() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    FName ColorThemeLibrary() const { return Read<FName>(uintptr_t(this) + 0xcc); } // 0xcc (Size: 0x4, Type: NameProperty)
    FName ColorTheme() const { return Read<FName>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: NameProperty)
    UTexture2D* SelectedGeneratedLibraryTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    UAtomColorThemeLibrary* SelectedColorThemeLibrary() const { return Read<UAtomColorThemeLibrary*>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: ObjectProperty)

    void SET_ColorLUTAtlas(const UAtomColorLUTAtlas*& Value) { Write<UAtomColorLUTAtlas*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_ColorLUTTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsThemeCustomTexture(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
    void SET_ColorThemeLibrary(const FName& Value) { Write<FName>(uintptr_t(this) + 0xcc, Value); } // 0xcc (Size: 0x4, Type: NameProperty)
    void SET_ColorTheme(const FName& Value) { Write<FName>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: NameProperty)
    void SET_SelectedGeneratedLibraryTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectedColorThemeLibrary(const UAtomColorThemeLibrary*& Value) { Write<UAtomColorThemeLibrary*>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
class UAtomDatabaseSubsystemBase : public UEngineSubsystem
{
public:
};

// Size: 0x98
class UAtomLUCTAtlas : public UObject
{
public:
    TMap<FAtomLUCTRemappedColorTable, FName> Themes() const { return Read<TMap<FAtomLUCTRemappedColorTable, FName>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)
    TSoftObjectPtr<UTexture2D> GeneratedAtlasTexture() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x20, Type: SoftObjectProperty)

    void SET_Themes(const TMap<FAtomLUCTRemappedColorTable, FName>& Value) { Write<TMap<FAtomLUCTRemappedColorTable, FName>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
    void SET_GeneratedAtlasTexture(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x2c0
class AAtomModelActor : public AActor
{
public:
    UAtomModel* AtomModel() const { return Read<UAtomModel*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    FString PrimitiveStyleName() const { return Read<FString>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x10, Type: StrProperty)

    void SET_AtomModel(const UAtomModel*& Value) { Write<UAtomModel*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_PrimitiveStyleName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x28
class UAtomModelActorConnectivityResolver : public UAtomActorConnectivityResolver
{
public:
};

// Size: 0x28
class UAtomPartsCollectionBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UAtomPlacementResultHelperLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UAtomPrimitiveBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x2e8
class UAtomPrimitiveGeometry : public UObject
{
public:
};

// Size: 0x140
class UAtomPrimitiveGeometryContainer : public UObject
{
public:
    TSoftObjectPtr<UStaticMesh> SourceMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    FName ExportStyleName() const { return Read<FName>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: NameProperty)
    int32_t LOD() const { return Read<int32_t>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: IntProperty)
    TMap<int32_t, FString> GeometryCount() const { return Read<TMap<int32_t, FString>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x50, Type: MapProperty)
    TMap<FAtomPrimitiveGeometrySectionTextureInfos, FString> SectionTextureInfos() const { return Read<TMap<FAtomPrimitiveGeometrySectionTextureInfos, FString>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x50, Type: MapProperty)

    void SET_SourceMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ExportStyleName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: NameProperty)
    void SET_LOD(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: IntProperty)
    void SET_GeometryCount(const TMap<int32_t, FString>& Value) { Write<TMap<int32_t, FString>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x50, Type: MapProperty)
    void SET_SectionTextureInfos(const TMap<FAtomPrimitiveGeometrySectionTextureInfos, FString>& Value) { Write<TMap<FAtomPrimitiveGeometrySectionTextureInfos, FString>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x610
class UAtomPrimitiveStaticMeshComponent : public UStaticMeshComponent
{
public:
};

// Size: 0x28
class UAtomRejectionReason : public UInterface
{
public:
};

// Size: 0x30
class UAtomConnectivityRejection : public UObject
{
public:
};

// Size: 0x50
class UAtomCollisionRejection : public UObject
{
public:
};

// Size: 0x28
class UAtomRuntimeBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x60
class UAtomRuntimeSettings : public UDeveloperSettings
{
public:
    float PrimitiveGlobalScale() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    TSoftObjectPtr<UDataTable> ColorDataTableOverride() const { return Read<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    bool bEnableWorldConnectivity() const { return Read<bool>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: BoolProperty)
    bool bCookContent() const { return Read<bool>(uintptr_t(this) + 0x59); } // 0x59 (Size: 0x1, Type: BoolProperty)

    void SET_PrimitiveGlobalScale(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_ColorDataTableOverride(const TSoftObjectPtr<UDataTable>& Value) { Write<TSoftObjectPtr<UDataTable>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bEnableWorldConnectivity(const bool& Value) { Write<bool>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: BoolProperty)
    void SET_bCookContent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x59, Value); } // 0x59 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UConnectivityBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x178
class UConnectivityRegistration : public UObject
{
public:
};

// Size: 0x610
class UDirectSnapPlacementTool : public UProximitySnapPlacementTool
{
public:
};

// Size: 0x5f0
class UProximitySnapPlacementTool : public UAtomPlacementToolBase
{
public:
};

// Size: 0x5f0
class UAtomPlacementToolBase : public UObject
{
public:
    TWeakObjectPtr<UConnectivityRegistration*> ConnectivityRegistrationWeakPtr() const { return Read<TWeakObjectPtr<UConnectivityRegistration*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)

    void SET_ConnectivityRegistrationWeakPtr(const TWeakObjectPtr<UConnectivityRegistration*>& Value) { Write<TWeakObjectPtr<UConnectivityRegistration*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x660
class UDragSnapPlacementTool : public UAtomPlacementToolBase
{
public:
};

// Size: 0x70
class UPlacementSettings : public UObject
{
public:
    uint8_t SnapToolMode() const { return Read<uint8_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: EnumProperty)
    bool bIgnoreRejectedEdgeSnappingPlacement() const { return Read<bool>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: BoolProperty)
    uint8_t DragSnapMode() const { return Read<uint8_t>(uintptr_t(this) + 0x4a); } // 0x4a (Size: 0x1, Type: EnumProperty)
    bool bEnableEdgeSnapping() const { return Read<bool>(uintptr_t(this) + 0x4b); } // 0x4b (Size: 0x1, Type: BoolProperty)
    uint32_t MaxSnappingDistanceInStudCount() const { return Read<uint32_t>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: UInt32Property)
    bool bSingleFieldPlacement() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    bool bEnableCollisionDetection() const { return Read<bool>(uintptr_t(this) + 0x51); } // 0x51 (Size: 0x1, Type: BoolProperty)
    double LineTraceLength() const { return Read<double>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    FCollisionProfileName ConnectivityTraceProfileName() const { return Read<FCollisionProfileName>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: StructProperty)
    FCollisionProfileName RegistrationOverlapProfileName() const { return Read<FCollisionProfileName>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: StructProperty)
    bool bDebugVisualization() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)
    int32_t DebugDrawFlags() const { return Read<int32_t>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: IntProperty)

    void SET_SnapToolMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: EnumProperty)
    void SET_bIgnoreRejectedEdgeSnappingPlacement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: BoolProperty)
    void SET_DragSnapMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4a, Value); } // 0x4a (Size: 0x1, Type: EnumProperty)
    void SET_bEnableEdgeSnapping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4b, Value); } // 0x4b (Size: 0x1, Type: BoolProperty)
    void SET_MaxSnappingDistanceInStudCount(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: UInt32Property)
    void SET_bSingleFieldPlacement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableCollisionDetection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x51, Value); } // 0x51 (Size: 0x1, Type: BoolProperty)
    void SET_LineTraceLength(const double& Value) { Write<double>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    void SET_ConnectivityTraceProfileName(const FCollisionProfileName& Value) { Write<FCollisionProfileName>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: StructProperty)
    void SET_RegistrationOverlapProfileName(const FCollisionProfileName& Value) { Write<FCollisionProfileName>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: StructProperty)
    void SET_bDebugVisualization(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
    void SET_DebugDrawFlags(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
class UAtomPlacementTool : public UInterface
{
public:
};

// Size: 0x28
class UDragPlacement : public UInterface
{
public:
};

// Size: 0x28
class UDirectPlacement : public UInterface
{
public:
};

// Size: 0x38
class UWorldConnectivitySubsystem : public UWorldSubsystem
{
public:
    UConnectivityRegistration* ConnectivityRegistration() const { return Read<UConnectivityRegistration*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)

    void SET_ConnectivityRegistration(const UConnectivityRegistration*& Value) { Write<UConnectivityRegistration*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UWorldConnectivityBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xc8
class UAtomColorComponent : public UActorComponent
{
public:
    UAtomColorLUTAtlas* ColorLUTAtlas() const { return Read<UAtomColorLUTAtlas*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* ColorLUTTexture() const { return Read<UTexture2D*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)

    void SET_ColorLUTAtlas(const UAtomColorLUTAtlas*& Value) { Write<UAtomColorLUTAtlas*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_ColorLUTTexture(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x88
class UAtomColorThemeLibrary : public UObject
{
public:
    FString Description() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    char MinimumReservedSlotsForTextureBasedThemes() const { return Read<char>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: ByteProperty)
    TArray<FAtomColorTheme> ColorThemes() const { return Read<TArray<FAtomColorTheme>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UTexture2D> GeneratedTexture() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x20, Type: SoftObjectProperty)
    TArray<UTexture2D*> LUTTextures() const { return Read<TArray<UTexture2D*>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)

    void SET_Description(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_MinimumReservedSlotsForTextureBasedThemes(const char& Value) { Write<char>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: ByteProperty)
    void SET_ColorThemes(const TArray<FAtomColorTheme>& Value) { Write<TArray<FAtomColorTheme>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_GeneratedTexture(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x20, Type: SoftObjectProperty)
    void SET_LUTTextures(const TArray<UTexture2D*>& Value) { Write<TArray<UTexture2D*>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2e8
class UAtomCommonPartStaticMeshAssetUserData : public UAssetUserData
{
public:
};

// Size: 0x100
class UAtomISMPoolRenderer : public UObject
{
public:
    UISMPoolComponent* CachedISMPoolComponent() const { return Read<UISMPoolComponent*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    UISMPoolComponent* LocalISMPoolComponent() const { return Read<UISMPoolComponent*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)

    void SET_CachedISMPoolComponent(const UISMPoolComponent*& Value) { Write<UISMPoolComponent*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalISMPoolComponent(const UISMPoolComponent*& Value) { Write<UISMPoolComponent*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x298
class UAtomModel : public UObject
{
public:
    FAtomModelAssetSettings Settings() const { return Read<FAtomModelAssetSettings>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)
    TArray<FAtomModelPrimitive> Primitives() const { return Read<TArray<FAtomModelPrimitive>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomHingedElement> Elements() const { return Read<TArray<FAtomHingedElement>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomModelSelectionSet> SelectionSets() const { return Read<TArray<FAtomModelSelectionSet>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomModelConfigurationGroup> Groups() const { return Read<TArray<FAtomModelConfigurationGroup>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    FSerializedConnectivityObjects SerializedConnectivityObjects() const { return Read<FSerializedConnectivityObjects>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x40, Type: StructProperty)
    TMap<TSoftObjectPtr<UTexture*>, FString> TextureNameToAsset() const { return Read<TMap<TSoftObjectPtr<UTexture*>, FString>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x50, Type: MapProperty)
    TMap<FString, FName> Attributes() const { return Read<TMap<FString, FName>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x50, Type: MapProperty)
    TSet<FName> Tags() const { return Read<TSet<FName>>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x50, Type: SetProperty)
    FAtomSourceModel SourceModel() const { return Read<FAtomSourceModel>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x88, Type: StructProperty)

    void SET_Settings(const FAtomModelAssetSettings& Value) { Write<FAtomModelAssetSettings>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
    void SET_Primitives(const TArray<FAtomModelPrimitive>& Value) { Write<TArray<FAtomModelPrimitive>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_Elements(const TArray<FAtomHingedElement>& Value) { Write<TArray<FAtomHingedElement>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_SelectionSets(const TArray<FAtomModelSelectionSet>& Value) { Write<TArray<FAtomModelSelectionSet>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_Groups(const TArray<FAtomModelConfigurationGroup>& Value) { Write<TArray<FAtomModelConfigurationGroup>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_SerializedConnectivityObjects(const FSerializedConnectivityObjects& Value) { Write<FSerializedConnectivityObjects>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x40, Type: StructProperty)
    void SET_TextureNameToAsset(const TMap<TSoftObjectPtr<UTexture*>, FString>& Value) { Write<TMap<TSoftObjectPtr<UTexture*>, FString>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x50, Type: MapProperty)
    void SET_Attributes(const TMap<FString, FName>& Value) { Write<TMap<FString, FName>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x50, Type: MapProperty)
    void SET_Tags(const TSet<FName>& Value) { Write<TSet<FName>>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x50, Type: SetProperty)
    void SET_SourceModel(const FAtomSourceModel& Value) { Write<FAtomSourceModel>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x88, Type: StructProperty)
};

// Size: 0x48
class UAtomPrimitiveCollisionGeometryWrapper : public UObject
{
public:
    TArray<FAtomPrimitiveCollisionGeometryBox> BoxElems() const { return Read<TArray<FAtomPrimitiveCollisionGeometryBox>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveCollisionGeometryConvex> ConvexElems() const { return Read<TArray<FAtomPrimitiveCollisionGeometryConvex>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_BoxElems(const TArray<FAtomPrimitiveCollisionGeometryBox>& Value) { Write<TArray<FAtomPrimitiveCollisionGeometryBox>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_ConvexElems(const TArray<FAtomPrimitiveCollisionGeometryConvex>& Value) { Write<TArray<FAtomPrimitiveCollisionGeometryConvex>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x78
class UAtomConnectivityAssetUserData : public UAssetUserData
{
public:
    FSerializedConnectivityObjects AtomModelConnections() const { return Read<FSerializedConnectivityObjects>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x40, Type: StructProperty)
    TArray<FName> Tags() const { return Read<TArray<FName>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)

    void SET_AtomModelConnections(const FSerializedConnectivityObjects& Value) { Write<FSerializedConnectivityObjects>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x40, Type: StructProperty)
    void SET_Tags(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x78
class UAtomModelAssetUserData : public UAtomConnectivityAssetUserData
{
public:
};

// Size: 0x28
class UAtomEditorModePrimitiveUserData : public UAssetUserData
{
public:
};

// Size: 0x78
class UAtomPrimitiveAssetUserData : public UAtomConnectivityAssetUserData
{
public:
};

// Size: 0x38
class UAtomCommonPartModelAssetUserData : public UAssetUserData
{
public:
    FAtomCommonPartAssetDescription AssetDescription() const { return Read<FAtomCommonPartAssetDescription>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0xc, Type: StructProperty)

    void SET_AssetDescription(const FAtomCommonPartAssetDescription& Value) { Write<FAtomCommonPartAssetDescription>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0xc, Type: StructProperty)
};

// Size: 0x28
class UAtomAssetUserDataActorConnectivityResolver : public UAtomActorConnectivityResolver
{
public:
};

// Size: 0x2c0
class UAtomModelComponent : public USceneComponent
{
public:
    UAtomModel* AtomModel() const { return Read<UAtomModel*>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x8, Type: ObjectProperty)
    uint8_t InstanceType() const { return Read<uint8_t>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x1, Type: EnumProperty)
    bool bUseCombinedMeshes() const { return Read<bool>(uintptr_t(this) + 0x249); } // 0x249 (Size: 0x1, Type: BoolProperty)
    uint8_t MaterialColorSource() const { return Read<uint8_t>(uintptr_t(this) + 0x24a); } // 0x24a (Size: 0x1, Type: EnumProperty)
    bool bCreateRigidElements() const { return Read<bool>(uintptr_t(this) + 0x24b); } // 0x24b (Size: 0x1, Type: BoolProperty)
    bool bEnableConnectivity() const { return Read<bool>(uintptr_t(this) + 0x24c); } // 0x24c (Size: 0x1, Type: BoolProperty)
    FName SelectionSetFilter() const { return Read<FName>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x4, Type: NameProperty)
    char CommonPartOptimization() const { return Read<char>(uintptr_t(this) + 0x254); } // 0x254 (Size: 0x1, Type: ByteProperty)
    TArray<USceneComponent*> RigidElementComponents() const { return Read<TArray<USceneComponent*>>(uintptr_t(this) + 0x258); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    TMap<FModelPrimitiveEntry, FName> ComponentToPrimitive() const { return Read<TMap<FModelPrimitiveEntry, FName>>(uintptr_t(this) + 0x268); } // 0x268 (Size: 0x50, Type: MapProperty)
    uint8_t PrimitiveGeometryComplexity() const { return Read<uint8_t>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x1, Type: EnumProperty)
    char PrimitiveGeometrySections() const { return Read<char>(uintptr_t(this) + 0x2b9); } // 0x2b9 (Size: 0x1, Type: ByteProperty)
    bool bShowCommonParts() const { return Read<bool>(uintptr_t(this) + 0x2ba); } // 0x2ba (Size: 0x1, Type: BoolProperty)

    void SET_AtomModel(const UAtomModel*& Value) { Write<UAtomModel*>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x8, Type: ObjectProperty)
    void SET_InstanceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x1, Type: EnumProperty)
    void SET_bUseCombinedMeshes(const bool& Value) { Write<bool>(uintptr_t(this) + 0x249, Value); } // 0x249 (Size: 0x1, Type: BoolProperty)
    void SET_MaterialColorSource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x24a, Value); } // 0x24a (Size: 0x1, Type: EnumProperty)
    void SET_bCreateRigidElements(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24b, Value); } // 0x24b (Size: 0x1, Type: BoolProperty)
    void SET_bEnableConnectivity(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24c, Value); } // 0x24c (Size: 0x1, Type: BoolProperty)
    void SET_SelectionSetFilter(const FName& Value) { Write<FName>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x4, Type: NameProperty)
    void SET_CommonPartOptimization(const char& Value) { Write<char>(uintptr_t(this) + 0x254, Value); } // 0x254 (Size: 0x1, Type: ByteProperty)
    void SET_RigidElementComponents(const TArray<USceneComponent*>& Value) { Write<TArray<USceneComponent*>>(uintptr_t(this) + 0x258, Value); } // 0x258 (Size: 0x10, Type: ArrayProperty)
    void SET_ComponentToPrimitive(const TMap<FModelPrimitiveEntry, FName>& Value) { Write<TMap<FModelPrimitiveEntry, FName>>(uintptr_t(this) + 0x268, Value); } // 0x268 (Size: 0x50, Type: MapProperty)
    void SET_PrimitiveGeometryComplexity(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x1, Type: EnumProperty)
    void SET_PrimitiveGeometrySections(const char& Value) { Write<char>(uintptr_t(this) + 0x2b9, Value); } // 0x2b9 (Size: 0x1, Type: ByteProperty)
    void SET_bShowCommonParts(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2ba, Value); } // 0x2ba (Size: 0x1, Type: BoolProperty)
};

// Size: 0x640
class UAtomPrimitiveComponent : public UStaticMeshComponent
{
public:
    UAtomPrimitive* AtomPrimitive() const { return Read<UAtomPrimitive*>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x8, Type: ObjectProperty)
    FString RenderStyle() const { return Read<FString>(uintptr_t(this) + 0x610); } // 0x610 (Size: 0x10, Type: StrProperty)
    FString FallbackRenderStyle() const { return Read<FString>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x10, Type: StrProperty)
    bool bUseCombinedMeshes() const { return Read<bool>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x1, Type: BoolProperty)
    bool bUseRenderStyle() const { return Read<bool>(uintptr_t(this) + 0x631); } // 0x631 (Size: 0x1, Type: BoolProperty)
    bool bUseFallbackRenderStyle() const { return Read<bool>(uintptr_t(this) + 0x632); } // 0x632 (Size: 0x1, Type: BoolProperty)

    void SET_AtomPrimitive(const UAtomPrimitive*& Value) { Write<UAtomPrimitive*>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x8, Type: ObjectProperty)
    void SET_RenderStyle(const FString& Value) { Write<FString>(uintptr_t(this) + 0x610, Value); } // 0x610 (Size: 0x10, Type: StrProperty)
    void SET_FallbackRenderStyle(const FString& Value) { Write<FString>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x10, Type: StrProperty)
    void SET_bUseCombinedMeshes(const bool& Value) { Write<bool>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x1, Type: BoolProperty)
    void SET_bUseRenderStyle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x631, Value); } // 0x631 (Size: 0x1, Type: BoolProperty)
    void SET_bUseFallbackRenderStyle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x632, Value); } // 0x632 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc0
class UAtomModelPartsCollectionConnectivity : public UObject
{
public:
    FAtomModelPartsCollection PartsCollection() const { return Read<FAtomModelPartsCollection>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x80, Type: StructProperty)

    void SET_PartsCollection(const FAtomModelPartsCollection& Value) { Write<FAtomModelPartsCollection>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x80, Type: StructProperty)
};

// Size: 0x58
class UAtomModelProcessor : public UObject
{
public:
    bool bEnableRebuildProgress() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    float DialogDelay() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    int32_t NumProgressSteps() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    FString ProgressMessage() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)

    void SET_bEnableRebuildProgress(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_DialogDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_NumProgressSteps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_ProgressMessage(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
};

// Size: 0x28
class UAtomProcessorBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x270
class UAtomPrimitive : public UObject
{
public:
    int32_t PartId() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    FString PartRevision() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    FName DesignName() const { return Read<FName>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: NameProperty)
    bool bIsFlex() const { return Read<bool>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x1, Type: BoolProperty)
    bool bIsVariant() const { return Read<bool>(uintptr_t(this) + 0x45); } // 0x45 (Size: 0x1, Type: BoolProperty)
    TArray<FString> DecorationSurfaceNames() const { return Read<TArray<FString>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    int32_t NumberOfColorSurfaces() const { return Read<int32_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: IntProperty)
    uint8_t AtomPlatform() const { return Read<uint8_t>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x1, Type: EnumProperty)
    int32_t AtomMainGroupId() const { return Read<int32_t>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: IntProperty)
    int32_t AtomSubMainGroupId() const { return Read<int32_t>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: IntProperty)
    TMap<FAtomPrimitiveCommonPart, EAtomCommonPartType> PrimitiveCommonParts() const { return Read<TMap<FAtomPrimitiveCommonPart, EAtomCommonPartType>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x50, Type: MapProperty)
    bool bOverrideConnectionFields() const { return Read<bool>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    FBoxSphereBounds UnscaledBounds() const { return Read<FBoxSphereBounds>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x38, Type: StructProperty)
    FAtomPrimitivePhysicsAttributes PhysicsAttributes() const { return Read<FAtomPrimitivePhysicsAttributes>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0xa0, Type: StructProperty)
    TArray<UAtomPrimitiveGeometryContainer*> GeometryContainers() const { return Read<TArray<UAtomPrimitiveGeometryContainer*>>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveDetailTextureData> DetailTextures() const { return Read<TArray<FAtomPrimitiveDetailTextureData>>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    FConnectionFieldContainer ConnectionFields() const { return Read<FConnectionFieldContainer>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x30, Type: StructProperty)
    FConnectionFieldContainer ConnectionFieldsOverride() const { return Read<FConnectionFieldContainer>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x30, Type: StructProperty)
    TMap<FTypedConnectivityFieldReference, FAtomPrimitiveTechnicCapReference> TechnicCapConnectivityRefs() const { return Read<TMap<FTypedConnectivityFieldReference, FAtomPrimitiveTechnicCapReference>>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x50, Type: MapProperty)

    void SET_PartId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_PartRevision(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_DesignName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: NameProperty)
    void SET_bIsFlex(const bool& Value) { Write<bool>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x1, Type: BoolProperty)
    void SET_bIsVariant(const bool& Value) { Write<bool>(uintptr_t(this) + 0x45, Value); } // 0x45 (Size: 0x1, Type: BoolProperty)
    void SET_DecorationSurfaceNames(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_NumberOfColorSurfaces(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: IntProperty)
    void SET_AtomPlatform(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x1, Type: EnumProperty)
    void SET_AtomMainGroupId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: IntProperty)
    void SET_AtomSubMainGroupId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: IntProperty)
    void SET_PrimitiveCommonParts(const TMap<FAtomPrimitiveCommonPart, EAtomCommonPartType>& Value) { Write<TMap<FAtomPrimitiveCommonPart, EAtomCommonPartType>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x50, Type: MapProperty)
    void SET_bOverrideConnectionFields(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: BoolProperty)
    void SET_UnscaledBounds(const FBoxSphereBounds& Value) { Write<FBoxSphereBounds>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x38, Type: StructProperty)
    void SET_PhysicsAttributes(const FAtomPrimitivePhysicsAttributes& Value) { Write<FAtomPrimitivePhysicsAttributes>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0xa0, Type: StructProperty)
    void SET_GeometryContainers(const TArray<UAtomPrimitiveGeometryContainer*>& Value) { Write<TArray<UAtomPrimitiveGeometryContainer*>>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x10, Type: ArrayProperty)
    void SET_DetailTextures(const TArray<FAtomPrimitiveDetailTextureData>& Value) { Write<TArray<FAtomPrimitiveDetailTextureData>>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: ArrayProperty)
    void SET_ConnectionFields(const FConnectionFieldContainer& Value) { Write<FConnectionFieldContainer>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x30, Type: StructProperty)
    void SET_ConnectionFieldsOverride(const FConnectionFieldContainer& Value) { Write<FConnectionFieldContainer>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x30, Type: StructProperty)
    void SET_TechnicCapConnectivityRefs(const TMap<FTypedConnectivityFieldReference, FAtomPrimitiveTechnicCapReference>& Value) { Write<TMap<FTypedConnectivityFieldReference, FAtomPrimitiveTechnicCapReference>>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x50, Type: MapProperty)
};

// Size: 0x28
struct FAtomConnectionPointLocation
{
public:
    UConnectivityRegistration* ConnectivityRegistration() const { return Read<UConnectivityRegistration*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_ConnectivityRegistration(const UConnectivityRegistration*& Value) { Write<UConnectivityRegistration*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb0
struct FAtomClosestConnectionPointQuery
{
public:
    UConnectivityRegistration* ConnectivityRegistration() const { return Read<UConnectivityRegistration*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_ConnectivityRegistration(const UConnectivityRegistration*& Value) { Write<UConnectivityRegistration*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FAtomColorInfo : public FTableRowBase
{
public:
    FColor Color() const { return Read<FColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    uint8_t MaterialType() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    bool bIsActive() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_Color(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_MaterialType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_bIsActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x4
struct FAtomColorProperty
{
public:
    int32_t AtomColorValue() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_AtomColorValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x390
struct FAtomConnectionProxy
{
public:
    TArray<TScriptInterface<Class>> RejectionReasons() const { return Read<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x10, Type: ArrayProperty)

    void SET_RejectionReasons(const TArray<TScriptInterface<Class>>& Value) { Write<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FAtomLUCTRemappedColorEntry
{
public:
    FAtomColorProperty SourceColor() const { return Read<FAtomColorProperty>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FAtomColorProperty RemappedColor() const { return Read<FAtomColorProperty>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_SourceColor(const FAtomColorProperty& Value) { Write<FAtomColorProperty>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_RemappedColor(const FAtomColorProperty& Value) { Write<FAtomColorProperty>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x10
struct FAtomLUCTRemappedColorTable
{
public:
    TArray<FAtomLUCTRemappedColorEntry> Entries() const { return Read<TArray<FAtomLUCTRemappedColorEntry>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Entries(const TArray<FAtomLUCTRemappedColorEntry>& Value) { Write<TArray<FAtomLUCTRemappedColorEntry>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FAtomMaterialOverride
{
public:
    UMaterialInterface* Material() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    bool bManualColorSource() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_Material(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_bManualColorSource(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb0
struct FAtomMaterialFeatures
{
public:
    uint8_t MaterialType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    TMap<UTexture*, int32_t> UDIMDecorationMap() const { return Read<TMap<UTexture*, int32_t>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x50, Type: MapProperty)
    UTexture* NormalMap() const { return Read<UTexture*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    UTexture* AlphaMask() const { return Read<UTexture*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    UTexture* TechnicNormalMap() const { return Read<UTexture*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    UTexture* TechnicMasks() const { return Read<UTexture*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    UTexture* LookUpTableAtlasTexture() const { return Read<UTexture*>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    uint8_t ColorSource() const { return Read<uint8_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: EnumProperty)
    int32_t ColorId() const { return Read<int32_t>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: IntProperty)
    uint8_t UVFeature() const { return Read<uint8_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: EnumProperty)
    uint8_t TranslucencyType() const { return Read<uint8_t>(uintptr_t(this) + 0x89); } // 0x89 (Size: 0x1, Type: EnumProperty)
    FAtomMaterialOverride MaterialOverride() const { return Read<FAtomMaterialOverride>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: StructProperty)
    TArray<FInstancedStruct> AdditionalFeatures() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)

    void SET_MaterialType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_UDIMDecorationMap(const TMap<UTexture*, int32_t>& Value) { Write<TMap<UTexture*, int32_t>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x50, Type: MapProperty)
    void SET_NormalMap(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    void SET_AlphaMask(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_TechnicNormalMap(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
    void SET_TechnicMasks(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ObjectProperty)
    void SET_LookUpTableAtlasTexture(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: ObjectProperty)
    void SET_ColorSource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: EnumProperty)
    void SET_ColorId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: IntProperty)
    void SET_UVFeature(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: EnumProperty)
    void SET_TranslucencyType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x89, Value); } // 0x89 (Size: 0x1, Type: EnumProperty)
    void SET_MaterialOverride(const FAtomMaterialOverride& Value) { Write<FAtomMaterialOverride>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: StructProperty)
    void SET_AdditionalFeatures(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FAtomMergedMeshLODDistanceSettings
{
public:
    bool bOverrideLODScreenSizes() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float BaseLODScreenSize() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float BaseLODScreenSizeScaling() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    TArray<float> LODDistances() const { return Read<TArray<float>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_bOverrideLODScreenSizes(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_BaseLODScreenSize(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_BaseLODScreenSizeScaling(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_LODDistances(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FAtomCommonPartOcclusionInfo
{
public:
    TArray<bool> InstancesOccluded() const { return Read<TArray<bool>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_InstancesOccluded(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x58
struct FAtomModelPrimitiveOcclusionInfo
{
public:
    bool bShellOccluded() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    TMap<FAtomCommonPartOcclusionInfo, EAtomCommonPartType> CommonPartsOccluded() const { return Read<TMap<FAtomCommonPartOcclusionInfo, EAtomCommonPartType>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x50, Type: MapProperty)

    void SET_bShellOccluded(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_CommonPartsOccluded(const TMap<FAtomCommonPartOcclusionInfo, EAtomCommonPartType>& Value) { Write<TMap<FAtomCommonPartOcclusionInfo, EAtomCommonPartType>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x50
struct FAtomModelOcclusionCache
{
public:
    TMap<FAtomModelPrimitiveOcclusionInfo, FAtomModelPartGuid> PartsOcclusion() const { return Read<TMap<FAtomModelPrimitiveOcclusionInfo, FAtomModelPartGuid>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_PartsOcclusion(const TMap<FAtomModelPrimitiveOcclusionInfo, FAtomModelPartGuid>& Value) { Write<TMap<FAtomModelPrimitiveOcclusionInfo, FAtomModelPartGuid>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x14
struct FAtomModelPartGuid
{
public:
    FGuid Guid() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    int32_t PartIndex() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_Guid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_PartIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x400
struct FAtomPlacementResult
{
public:
    FTransform TransformDelta() const { return Read<FTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x60, Type: StructProperty)
    FAtomConnectionProxy ConnectionProxy() const { return Read<FAtomConnectionProxy>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x390, Type: StructProperty)
    uint8_t PlacementType() const { return Read<uint8_t>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x1, Type: EnumProperty)

    void SET_TransformDelta(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x60, Type: StructProperty)
    void SET_ConnectionProxy(const FAtomConnectionProxy& Value) { Write<FAtomConnectionProxy>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x390, Type: StructProperty)
    void SET_PlacementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x20
struct FAtomPrimitiveCollisionVolumeBase
{
public:
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    uint16_t BoneIndex() const { return Read<uint16_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x2, Type: UInt16Property)

    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_BoneIndex(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x2, Type: UInt16Property)
};

// Size: 0x50
struct FAtomPrimitiveCollisionVolumeBox : public FAtomPrimitiveCollisionVolumeBase
{
public:
    FRotator Rotation() const { return Read<FRotator>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector HalfExtent() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_HalfExtent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FAtomPrimitiveCollisionVolumeCapsule : public FAtomPrimitiveCollisionVolumeBase
{
public:
    FRotator Rotation() const { return Read<FRotator>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float HalfLength() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)

    void SET_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_HalfLength(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x40
struct FAtomPrimitiveCollisionVolumeCylinder : public FAtomPrimitiveCollisionVolumeBase
{
public:
    FRotator Rotation() const { return Read<FRotator>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float HalfLength() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)

    void SET_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_HalfLength(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x48
struct FAtomPrimitiveCollisionVolumeTube : public FAtomPrimitiveCollisionVolumeBase
{
public:
    FRotator Rotation() const { return Read<FRotator>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float InnerRadius() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float OuterRadius() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float HalfLength() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)

    void SET_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_InnerRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_OuterRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_HalfLength(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FAtomPrimitiveCollisionVolumeSphere : public FAtomPrimitiveCollisionVolumeBase
{
public:
    float Radius() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x50
struct FAtomPrimitiveCollisionVolumeContainer
{
public:
    TArray<FAtomPrimitiveCollisionVolumeBox> Boxes() const { return Read<TArray<FAtomPrimitiveCollisionVolumeBox>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveCollisionVolumeSphere> Spheres() const { return Read<TArray<FAtomPrimitiveCollisionVolumeSphere>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveCollisionVolumeCapsule> Capsules() const { return Read<TArray<FAtomPrimitiveCollisionVolumeCapsule>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveCollisionVolumeCylinder> Cylinders() const { return Read<TArray<FAtomPrimitiveCollisionVolumeCylinder>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveCollisionVolumeTube> Tubes() const { return Read<TArray<FAtomPrimitiveCollisionVolumeTube>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_Boxes(const TArray<FAtomPrimitiveCollisionVolumeBox>& Value) { Write<TArray<FAtomPrimitiveCollisionVolumeBox>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Spheres(const TArray<FAtomPrimitiveCollisionVolumeSphere>& Value) { Write<TArray<FAtomPrimitiveCollisionVolumeSphere>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Capsules(const TArray<FAtomPrimitiveCollisionVolumeCapsule>& Value) { Write<TArray<FAtomPrimitiveCollisionVolumeCapsule>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Cylinders(const TArray<FAtomPrimitiveCollisionVolumeCylinder>& Value) { Write<TArray<FAtomPrimitiveCollisionVolumeCylinder>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_Tubes(const TArray<FAtomPrimitiveCollisionVolumeTube>& Value) { Write<TArray<FAtomPrimitiveCollisionVolumeTube>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa0
struct FAtomPrimitiveCollisionGeometry
{
public:
    FKAggregateGeom AggGeom() const { return Read<FKAggregateGeom>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xa0, Type: StructProperty)

    void SET_AggGeom(const FKAggregateGeom& Value) { Write<FKAggregateGeom>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xa0, Type: StructProperty)
};

// Size: 0x20
struct FAtomPrimitiveGeometryMaterialAssignments
{
public:
    TArray<FString> MaterialSlotName() const { return Read<TArray<FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomMaterialFeatures> MaterialFeatures() const { return Read<TArray<FAtomMaterialFeatures>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_MaterialSlotName(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_MaterialFeatures(const TArray<FAtomMaterialFeatures>& Value) { Write<TArray<FAtomMaterialFeatures>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x188
struct FAtomPrimitiveGeometryLODs
{
public:
    TArray<UAtomPrimitiveGeometry*> GeometryLODs() const { return Read<TArray<UAtomPrimitiveGeometry*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomPrimitiveGeometryMaterialAssignments> GeometryLODsMaterials() const { return Read<TArray<FAtomPrimitiveGeometryMaterialAssignments>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    UAtomPrimitiveGeometry* HiResNaniteGeomery() const { return Read<UAtomPrimitiveGeometry*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    FAtomPrimitiveGeometryMaterialAssignments HiResNaniteGeomeryMaterials() const { return Read<FAtomPrimitiveGeometryMaterialAssignments>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)
    FAtomPrimitiveCollisionGeometry Collision() const { return Read<FAtomPrimitiveCollisionGeometry>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0xa0, Type: StructProperty)
    FAtomPrimitiveCollisionGeometry DetailedCollision() const { return Read<FAtomPrimitiveCollisionGeometry>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0xa0, Type: StructProperty)

    void SET_GeometryLODs(const TArray<UAtomPrimitiveGeometry*>& Value) { Write<TArray<UAtomPrimitiveGeometry*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_GeometryLODsMaterials(const TArray<FAtomPrimitiveGeometryMaterialAssignments>& Value) { Write<TArray<FAtomPrimitiveGeometryMaterialAssignments>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_HiResNaniteGeomery(const UAtomPrimitiveGeometry*& Value) { Write<UAtomPrimitiveGeometry*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    void SET_HiResNaniteGeomeryMaterials(const FAtomPrimitiveGeometryMaterialAssignments& Value) { Write<FAtomPrimitiveGeometryMaterialAssignments>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
    void SET_Collision(const FAtomPrimitiveCollisionGeometry& Value) { Write<FAtomPrimitiveCollisionGeometry>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0xa0, Type: StructProperty)
    void SET_DetailedCollision(const FAtomPrimitiveCollisionGeometry& Value) { Write<FAtomPrimitiveCollisionGeometry>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0xa0, Type: StructProperty)
};

// Size: 0x40
struct FAtomPrimitiveGeometryAndTransform
{
public:
    UAtomPrimitiveGeometry* AtomPrimitiveGeometry() const { return Read<UAtomPrimitiveGeometry*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FTransform3f Transform() const { return Read<FTransform3f>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x30, Type: StructProperty)

    void SET_AtomPrimitiveGeometry(const UAtomPrimitiveGeometry*& Value) { Write<UAtomPrimitiveGeometry*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Transform(const FTransform3f& Value) { Write<FTransform3f>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x30, Type: StructProperty)
};

// Size: 0x50
struct FAtomPrimitiveGeometrySectionTextureInfos
{
public:
    TMap<FString, EAtomPrimitiveDetailTextureType> TextureInfos() const { return Read<TMap<FString, EAtomPrimitiveDetailTextureType>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_TextureInfos(const TMap<FString, EAtomPrimitiveDetailTextureType>& Value) { Write<TMap<FString, EAtomPrimitiveDetailTextureType>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x40
struct FAtomPrimitiveGeometrySectionFilterParams
{
public:
    TArray<FString> UncommonPartsIncludeList() const { return Read<TArray<FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> UncommonPartsExcludeList() const { return Read<TArray<FString>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> OtherPartsIncludeList() const { return Read<TArray<FString>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> OtherPartsExcludeList() const { return Read<TArray<FString>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_UncommonPartsIncludeList(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_UncommonPartsExcludeList(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_OtherPartsIncludeList(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_OtherPartsExcludeList(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FConnectionField
{
public:
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    uint32_t Subtype() const { return Read<uint32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: UInt32Property)
    uint16_t BoneIndex() const { return Read<uint16_t>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x2, Type: UInt16Property)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x3e); } // 0x3e (Size: 0x1, Type: EnumProperty)

    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Subtype(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: UInt32Property)
    void SET_BoneIndex(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x2, Type: UInt16Property)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3e, Value); } // 0x3e (Size: 0x1, Type: EnumProperty)
};

// Size: 0x50
struct FConnectionFieldLine : public FConnectionField
{
public:
    double Length() const { return Read<double>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    bool StartCapped() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    bool EndCapped() const { return Read<bool>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: BoolProperty)

    void SET_Length(const double& Value) { Write<double>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: DoubleProperty)
    void SET_StartCapped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_EndCapped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x60
struct FConnectionFieldAxle : public FConnectionFieldLine
{
public:
    bool Grabbing() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    bool RequireGrabbing() const { return Read<bool>(uintptr_t(this) + 0x51); } // 0x51 (Size: 0x1, Type: BoolProperty)
    float DiscreteSnapInterval() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)

    void SET_Grabbing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_RequireGrabbing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x51, Value); } // 0x51 (Size: 0x1, Type: BoolProperty)
    void SET_DiscreteSnapInterval(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x40
struct FConnectionFieldPoint : public FConnectionField
{
public:
};

// Size: 0x40
struct FConnectionFieldBall : public FConnectionFieldPoint
{
public:
};

// Size: 0x30
struct FConnectionFieldContainer
{
public:
    TArray<FConnectionFieldPlanar> PlanarFields() const { return Read<TArray<FConnectionFieldPlanar>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> LineFields() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FInstancedStruct> PointFields() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_PlanarFields(const TArray<FConnectionFieldPlanar>& Value) { Write<TArray<FConnectionFieldPlanar>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_LineFields(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_PointFields(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x60
struct FConnectionFieldPlanar : public FConnectionField
{
public:
    char Width() const { return Read<char>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: ByteProperty)
    char Height() const { return Read<char>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: ByteProperty)
    TArray<FConnectionPoint> Points() const { return Read<TArray<FConnectionPoint>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)

    void SET_Width(const char& Value) { Write<char>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: ByteProperty)
    void SET_Height(const char& Value) { Write<char>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: ByteProperty)
    void SET_Points(const TArray<FConnectionPoint>& Value) { Write<TArray<FConnectionPoint>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FConnectionPoint
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    char Size() const { return Read<char>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: ByteProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_Size(const char& Value) { Write<char>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x50
struct FConnectionFieldFixed : public FConnectionFieldPoint
{
public:
    uint32_t Axes() const { return Read<uint32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: UInt32Property)

    void SET_Axes(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x60
struct FConnectionFieldGear : public FConnectionFieldLine
{
public:
    double Radius() const { return Read<double>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    uint32_t ToothCount() const { return Read<uint32_t>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: UInt32Property)

    void SET_Radius(const double& Value) { Write<double>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    void SET_ToothCount(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: UInt32Property)
};

// Size: 0x70
struct FConnectionFieldHinge : public FConnectionFieldPoint
{
public:
    bool Oriented() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    bool Flip() const { return Read<bool>(uintptr_t(this) + 0x41); } // 0x41 (Size: 0x1, Type: BoolProperty)
    bool HasLimits() const { return Read<bool>(uintptr_t(this) + 0x42); } // 0x42 (Size: 0x1, Type: BoolProperty)
    bool RequireGrabbing() const { return Read<bool>(uintptr_t(this) + 0x43); } // 0x43 (Size: 0x1, Type: BoolProperty)
    double OrientedMin() const { return Read<double>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    double OrientedMax() const { return Read<double>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    double FlippedMin() const { return Read<double>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    double FlippedMax() const { return Read<double>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: DoubleProperty)

    void SET_Oriented(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_Flip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x41, Value); } // 0x41 (Size: 0x1, Type: BoolProperty)
    void SET_HasLimits(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42, Value); } // 0x42 (Size: 0x1, Type: BoolProperty)
    void SET_RequireGrabbing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x43, Value); } // 0x43 (Size: 0x1, Type: BoolProperty)
    void SET_OrientedMin(const double& Value) { Write<double>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: DoubleProperty)
    void SET_OrientedMax(const double& Value) { Write<double>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: DoubleProperty)
    void SET_FlippedMin(const double& Value) { Write<double>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    void SET_FlippedMax(const double& Value) { Write<double>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x70
struct FConnectionFieldSlider : public FConnectionFieldLine
{
public:
    bool Cylindrical() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    bool HasSpring() const { return Read<bool>(uintptr_t(this) + 0x51); } // 0x51 (Size: 0x1, Type: BoolProperty)
    double SpringRest() const { return Read<double>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    double SpringStrength() const { return Read<double>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    double SpringDamping() const { return Read<double>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: DoubleProperty)

    void SET_Cylindrical(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_HasSpring(const bool& Value) { Write<bool>(uintptr_t(this) + 0x51, Value); } // 0x51 (Size: 0x1, Type: BoolProperty)
    void SET_SpringRest(const double& Value) { Write<double>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: DoubleProperty)
    void SET_SpringStrength(const double& Value) { Write<double>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: DoubleProperty)
    void SET_SpringDamping(const double& Value) { Write<double>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x90
struct FPlacementContextData
{
public:
    FTransform PlacementTransform() const { return Read<FTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x60, Type: StructProperty)
    FRay CastRay() const { return Read<FRay>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x30, Type: StructProperty)

    void SET_PlacementTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x60, Type: StructProperty)
    void SET_CastRay(const FRay& Value) { Write<FRay>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x30, Type: StructProperty)
};

// Size: 0x590
struct FPlacementToolContext
{
public:
    TArray<AActor*> ActorsToMove() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_ActorsToMove(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FSerializedPlanarConnection
{
public:
    FPlanarFieldConnectionInfo Connection() const { return Read<FPlanarFieldConnectionInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FConnectivityFieldReference FieldA() const { return Read<FConnectivityFieldReference>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: StructProperty)
    FConnectivityFieldReference FieldB() const { return Read<FConnectivityFieldReference>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: StructProperty)

    void SET_Connection(const FPlanarFieldConnectionInfo& Value) { Write<FPlanarFieldConnectionInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_FieldA(const FConnectivityFieldReference& Value) { Write<FConnectivityFieldReference>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: StructProperty)
    void SET_FieldB(const FConnectivityFieldReference& Value) { Write<FConnectivityFieldReference>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: StructProperty)
};

// Size: 0x8
struct FConnectivityFieldReference
{
public:
    int32_t ObjectId() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    uint16_t FieldIndex() const { return Read<uint16_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x2, Type: UInt16Property)

    void SET_ObjectId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_FieldIndex(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x2, Type: UInt16Property)
};

// Size: 0x1
struct FFieldConnectionInfo
{
public:
    uint8_t ConnectResult() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)

    void SET_ConnectResult(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x20
struct FPlanarFieldConnectionInfo : public FFieldConnectionInfo
{
public:
    TArray<FPlanarFieldPointConnectionInfo> PointConnections() const { return Read<TArray<FPlanarFieldPointConnectionInfo>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint32_t OverlapA() const { return Read<uint32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: UInt32Property)
    uint32_t OverlapB() const { return Read<uint32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: UInt32Property)

    void SET_PointConnections(const TArray<FPlanarFieldPointConnectionInfo>& Value) { Write<TArray<FPlanarFieldPointConnectionInfo>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_OverlapA(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: UInt32Property)
    void SET_OverlapB(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: UInt32Property)
};

// Size: 0x4
struct FPlanarFieldPointConnectionInfo
{
public:
    uint16_t IndexA() const { return Read<uint16_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: UInt16Property)
    uint16_t IndexB() const { return Read<uint16_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: UInt16Property)

    void SET_IndexA(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: UInt16Property)
    void SET_IndexB(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: UInt16Property)
};

// Size: 0x18
struct FSerializedLineConnection
{
public:
    FLineFieldConnectionInfo Connection() const { return Read<FLineFieldConnectionInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FConnectivityFieldReference FieldA() const { return Read<FConnectivityFieldReference>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FConnectivityFieldReference FieldB() const { return Read<FConnectivityFieldReference>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)

    void SET_Connection(const FLineFieldConnectionInfo& Value) { Write<FLineFieldConnectionInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_FieldA(const FConnectivityFieldReference& Value) { Write<FConnectivityFieldReference>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_FieldB(const FConnectivityFieldReference& Value) { Write<FConnectivityFieldReference>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
};

// Size: 0x8
struct FLineFieldConnectionInfo : public FFieldConnectionInfo
{
public:
    bool Flip() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)

    void SET_Flip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FSerializedPointConnection
{
public:
    FPointFieldConnectionInfo Connection() const { return Read<FPointFieldConnectionInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FConnectivityFieldReference FieldA() const { return Read<FConnectivityFieldReference>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FConnectivityFieldReference FieldB() const { return Read<FConnectivityFieldReference>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)

    void SET_Connection(const FPointFieldConnectionInfo& Value) { Write<FPointFieldConnectionInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_FieldA(const FConnectivityFieldReference& Value) { Write<FConnectivityFieldReference>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_FieldB(const FConnectivityFieldReference& Value) { Write<FConnectivityFieldReference>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
};

// Size: 0x10
struct FPointFieldConnectionInfo : public FFieldConnectionInfo
{
public:
    double OneAxisRotation() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)

    void SET_OneAxisRotation(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x40
struct FSerializedConnectivityObjects
{
public:
    TArray<FConnectionFieldContainer> Fields() const { return Read<TArray<FConnectionFieldContainer>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FSerializedPlanarConnection> PlanarConnections() const { return Read<TArray<FSerializedPlanarConnection>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FSerializedLineConnection> LineConnections() const { return Read<TArray<FSerializedLineConnection>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FSerializedPointConnection> PointConnections() const { return Read<TArray<FSerializedPointConnection>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Fields(const TArray<FConnectionFieldContainer>& Value) { Write<TArray<FConnectionFieldContainer>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_PlanarConnections(const TArray<FSerializedPlanarConnection>& Value) { Write<TArray<FSerializedPlanarConnection>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_LineConnections(const TArray<FSerializedLineConnection>& Value) { Write<TArray<FSerializedLineConnection>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_PointConnections(const TArray<FSerializedPointConnection>& Value) { Write<TArray<FSerializedPointConnection>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FPlanarFieldPointInfo
{
public:
    FVector PointLocation() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t PointType() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    bool IsAvailable() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)

    void SET_PointLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_PointType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_IsAvailable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
struct FPlanarFieldInfo
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x60, Type: StructProperty)
    FVector2D Size() const { return Read<FVector2D>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: StructProperty)
    uint8_t PlanarFieldType() const { return Read<uint8_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: EnumProperty)
    TArray<FPlanarFieldPointInfo> PointInfo() const { return Read<TArray<FPlanarFieldPointInfo>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x60, Type: StructProperty)
    void SET_Size(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: StructProperty)
    void SET_PlanarFieldType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: EnumProperty)
    void SET_PointInfo(const TArray<FPlanarFieldPointInfo>& Value) { Write<TArray<FPlanarFieldPointInfo>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x4
struct FWorldConnectivityHandle
{
public:
    int32_t ObjectId() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_ObjectId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0xc0
struct FConnectivityQueryResult
{
public:
    bool bHasValidConnection() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FTransform TargetTransformToConnect() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FVector HitLocation() const { return Read<FVector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FVector OffsetToBestFit() const { return Read<FVector>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)
    int32_t SourceFieldIndex() const { return Read<int32_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: IntProperty)
    int32_t SourceFieldObjectId() const { return Read<int32_t>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: IntProperty)
    int32_t SourceFieldConnectionPointIndex() const { return Read<int32_t>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: IntProperty)
    int32_t TargetFieldIndex() const { return Read<int32_t>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: IntProperty)
    int32_t TargetFieldObjectId() const { return Read<int32_t>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: IntProperty)
    int32_t TargetFieldConnectionPointIndex() const { return Read<int32_t>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: IntProperty)
    FName ErrorMessage() const { return Read<FName>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: NameProperty)

    void SET_bHasValidConnection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_TargetTransformToConnect(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_HitLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_OffsetToBestFit(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
    void SET_SourceFieldIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: IntProperty)
    void SET_SourceFieldObjectId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: IntProperty)
    void SET_SourceFieldConnectionPointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: IntProperty)
    void SET_TargetFieldIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: IntProperty)
    void SET_TargetFieldObjectId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: IntProperty)
    void SET_TargetFieldConnectionPointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: IntProperty)
    void SET_ErrorMessage(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x8
struct FAtomThemeColorEntry
{
public:
    FAtomColorProperty OriginalColor() const { return Read<FAtomColorProperty>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    FAtomColorProperty ReplacementColor() const { return Read<FAtomColorProperty>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: StructProperty)

    void SET_OriginalColor(const FAtomColorProperty& Value) { Write<FAtomColorProperty>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_ReplacementColor(const FAtomColorProperty& Value) { Write<FAtomColorProperty>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: StructProperty)
};

// Size: 0x18
struct FAtomColorTheme
{
public:
    FName ThemeName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<FAtomThemeColorEntry> Entries() const { return Read<TArray<FAtomThemeColorEntry>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_ThemeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Entries(const TArray<FAtomThemeColorEntry>& Value) { Write<TArray<FAtomThemeColorEntry>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FAtomCommonPartDescription
{
public:
    float Radius() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Height() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float InnerRadius() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    char PlaneQuadrant() const { return Read<char>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: ByteProperty)
    bool bShowLogo() const { return Read<bool>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: BoolProperty)

    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Height(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_InnerRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_PlaneQuadrant(const char& Value) { Write<char>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: ByteProperty)
    void SET_bShowLogo(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FAtomModelProcessedResults
{
public:
    TArray<TSoftObjectPtr<UObject*>> ProcessedResults() const { return Read<TArray<TSoftObjectPtr<UObject*>>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_ProcessedResults(const TArray<TSoftObjectPtr<UObject*>>& Value) { Write<TArray<TSoftObjectPtr<UObject*>>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x68
struct FAtomModelMapping : public FTableRowBase
{
public:
    FString ModelName() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    TMap<FAtomModelProcessedResults, FString> ProcessedResultsMap() const { return Read<TMap<FAtomModelProcessedResults, FString>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x50, Type: MapProperty)

    void SET_ModelName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_ProcessedResultsMap(const TMap<FAtomModelProcessedResults, FString>& Value) { Write<TMap<FAtomModelProcessedResults, FString>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x50, Type: MapProperty)
};

// Size: 0x18
struct FAtomColor
{
public:
    int32_t ID() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    uint8_t Effects() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_ID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_Effects(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x8
struct FAtomColorSurface
{
public:
    int32_t ColorId() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)

    void SET_ColorId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
struct FAtomDecorationAssignment
{
public:
    FString SurfaceName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString TextureName() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FString Version() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)

    void SET_SurfaceName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_TextureName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_Version(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
};

// Size: 0x90
struct FAtomModelPrimitiveInstance
{
public:
    UAtomPrimitive* Primitive() const { return Read<UAtomPrimitive*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FTransform PrimitiveTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FVector PivotOrigin() const { return Read<FVector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_Primitive(const UAtomPrimitive*& Value) { Write<UAtomPrimitive*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_PrimitiveTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_PivotOrigin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0x70
struct FAtomModelPart
{
public:
    TSoftObjectPtr<UAtomPrimitive> AtomPrimitive() const { return Read<TSoftObjectPtr<UAtomPrimitive>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    uint32_t PartId() const { return Read<uint32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: UInt32Property)
    FString PartRevision() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    TArray<FAtomColorSurface> ColorSurfaces() const { return Read<TArray<FAtomColorSurface>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomDecorationAssignment> Decorations() const { return Read<TArray<FAtomDecorationAssignment>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    bool bIgnoreCommonPartCulling() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)

    void SET_AtomPrimitive(const TSoftObjectPtr<UAtomPrimitive>& Value) { Write<TSoftObjectPtr<UAtomPrimitive>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_PartId(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: UInt32Property)
    void SET_PartRevision(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_ColorSurfaces(const TArray<FAtomColorSurface>& Value) { Write<TArray<FAtomColorSurface>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_Decorations(const TArray<FAtomDecorationAssignment>& Value) { Write<TArray<FAtomDecorationAssignment>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_bIgnoreCommonPartCulling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
struct FAtomModelSocket
{
public:
    FGuid ID() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)

    void SET_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
};

// Size: 0x28
struct FAtomModelPrimitive
{
public:
    TArray<FAtomModelPart> Parts() const { return Read<TArray<FAtomModelPart>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t DesignId() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    FGuid UUID() const { return Read<FGuid>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)
    FName DesignName() const { return Read<FName>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: NameProperty)

    void SET_Parts(const TArray<FAtomModelPart>& Value) { Write<TArray<FAtomModelPart>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_DesignId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_UUID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
    void SET_DesignName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: NameProperty)
};

// Size: 0xc
struct FAtomBoneReference
{
public:
    int32_t PrimitiveIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t PartIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t BoneIndex() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_PrimitiveIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_PartIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_BoneIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x18
struct FAtomPrimitiveConnection
{
public:
    FAtomBoneReference From() const { return Read<FAtomBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FAtomBoneReference To() const { return Read<FAtomBoneReference>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)

    void SET_From(const FAtomBoneReference& Value) { Write<FAtomBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_To(const FAtomBoneReference& Value) { Write<FAtomBoneReference>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
};

// Size: 0x80
struct FAtomRigidElementConnection
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x60, Type: StructProperty)
    int32_t OtherElementIndex() const { return Read<int32_t>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: IntProperty)
    int32_t ConnectionUniqueId() const { return Read<int32_t>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: IntProperty)
    TArray<FAtomPrimitiveConnection> PrimitiveConnections() const { return Read<TArray<FAtomPrimitiveConnection>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x60, Type: StructProperty)
    void SET_OtherElementIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: IntProperty)
    void SET_ConnectionUniqueId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: IntProperty)
    void SET_PrimitiveConnections(const TArray<FAtomPrimitiveConnection>& Value) { Write<TArray<FAtomPrimitiveConnection>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FAtomRigidElement
{
public:
    TArray<FAtomBoneReference> BoneReferences() const { return Read<TArray<FAtomBoneReference>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomRigidElementConnection> Connections() const { return Read<TArray<FAtomRigidElementConnection>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    int32_t IndexOfMetaBone() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)

    void SET_BoneReferences(const TArray<FAtomBoneReference>& Value) { Write<TArray<FAtomBoneReference>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Connections(const TArray<FAtomRigidElementConnection>& Value) { Write<TArray<FAtomRigidElementConnection>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_IndexOfMetaBone(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
};

// Size: 0x18
struct FAtomHingedElement
{
public:
    TArray<FAtomRigidElement> RigidElements() const { return Read<TArray<FAtomRigidElement>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t HierarchyRootIndex() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_RigidElements(const TArray<FAtomRigidElement>& Value) { Write<TArray<FAtomRigidElement>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_HierarchyRootIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x14
struct FAtomModelPartReference
{
public:
    FGuid PrimitiveUUID() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    int32_t PartIndex() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)

    void SET_PrimitiveUUID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_PartIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
};

// Size: 0x50
struct FAtomGlueSet
{
public:
    TSet<FAtomModelPartReference> Entries() const { return Read<TSet<FAtomModelPartReference>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: SetProperty)

    void SET_Entries(const TSet<FAtomModelPartReference>& Value) { Write<TSet<FAtomModelPartReference>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: SetProperty)
};

// Size: 0x18
struct FAtomPrimitiveGroup
{
public:
    FVector PivotOrigin() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)

    void SET_PivotOrigin(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x18
struct FAtomModelGeometryOptimizationSettings
{
public:
    bool bEnforceLODBudgets() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bUseTagBudget() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    int32_t TriangleBudget() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    double SimplifyBaseTolerance() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    double OptimizeBaseTriCost() const { return Read<double>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: DoubleProperty)

    void SET_bEnforceLODBudgets(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseTagBudget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_TriangleBudget(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_SimplifyBaseTolerance(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_OptimizeBaseTriCost(const double& Value) { Write<double>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x20
struct FAtomSelectionSetPrimitiveGroup : public FAtomPrimitiveGroup
{
public:
    FName SelectionSetName() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)

    void SET_SelectionSetName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
};

// Size: 0x18
struct FAtomModelPrimitiveGroup : public FAtomPrimitiveGroup
{
public:
};

// Size: 0xc
struct FAtomRigidElementIndices
{
public:
    int32_t HingedElementIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t RigidElementIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t BoneIndex() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_HingedElementIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_RigidElementIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_BoneIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x18
struct FAtomResolvedModelPartReference
{
public:
    FAtomBoneReference Indices() const { return Read<FAtomBoneReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xc, Type: StructProperty)
    FAtomRigidElementIndices ElementIndices() const { return Read<FAtomRigidElementIndices>(uintptr_t(this) + 0xc); } // 0xc (Size: 0xc, Type: StructProperty)

    void SET_Indices(const FAtomBoneReference& Value) { Write<FAtomBoneReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xc, Type: StructProperty)
    void SET_ElementIndices(const FAtomRigidElementIndices& Value) { Write<FAtomRigidElementIndices>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0xc, Type: StructProperty)
};

// Size: 0x1c
struct FAtomRigidElementSettings
{
public:
    FAtomModelPartReference ElementIdentifyingPart() const { return Read<FAtomModelPartReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)
    FName RigidElementName() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    bool MergeWithParentElement() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    bool ShouldBeRootElement() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)

    void SET_ElementIdentifyingPart(const FAtomModelPartReference& Value) { Write<FAtomModelPartReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
    void SET_RigidElementName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_MergeWithParentElement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_ShouldBeRootElement(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FAtomModelTags
{
public:
    TArray<FName> Tags() const { return Read<TArray<FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Tags(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FAtomModelAssetSettings
{
public:
    float Scale() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    bool CreateRigidElementComponents() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    FAtomModelGeometryOptimizationSettings OptimizationSettings() const { return Read<FAtomModelGeometryOptimizationSettings>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    bool bEnableConnectivity() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_CreateRigidElementComponents(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_OptimizationSettings(const FAtomModelGeometryOptimizationSettings& Value) { Write<FAtomModelGeometryOptimizationSettings>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_bEnableConnectivity(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x68
struct FAtomModelSelectionSet
{
public:
    TSet<FGuid> PrimitiveIds() const { return Read<TSet<FGuid>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: SetProperty)
    FName SelectionSetName() const { return Read<FName>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: NameProperty)
    FName ImportedName() const { return Read<FName>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: NameProperty)
    FGuid ID() const { return Read<FGuid>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)

    void SET_PrimitiveIds(const TSet<FGuid>& Value) { Write<TSet<FGuid>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: SetProperty)
    void SET_SelectionSetName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: NameProperty)
    void SET_ImportedName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: NameProperty)
    void SET_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
};

// Size: 0x190
struct FAtomModelConfigurationGroup
{
public:
    FGuid ID() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FGuid ParentGroupId() const { return Read<FGuid>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)
    TSet<FGuid> PrimitiveIds() const { return Read<TSet<FGuid>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: SetProperty)
    TArray<FAtomModelSocket> Sockets() const { return Read<TArray<FAtomModelSocket>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    FTransform GroupPivot() const { return Read<FTransform>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x60, Type: StructProperty)
    TMap<FString, FName> Attributes() const { return Read<TMap<FString, FName>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x50, Type: MapProperty)
    TSet<FName> Tags() const { return Read<TSet<FName>>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x50, Type: SetProperty)

    void SET_ID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_ParentGroupId(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
    void SET_PrimitiveIds(const TSet<FGuid>& Value) { Write<TSet<FGuid>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: SetProperty)
    void SET_Sockets(const TArray<FAtomModelSocket>& Value) { Write<TArray<FAtomModelSocket>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_GroupPivot(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x60, Type: StructProperty)
    void SET_Attributes(const TMap<FString, FName>& Value) { Write<TMap<FString, FName>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x50, Type: MapProperty)
    void SET_Tags(const TSet<FName>& Value) { Write<TSet<FName>>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x50, Type: SetProperty)
};

// Size: 0x90
struct FAtomModelHierarchicalSceneNode
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FTransform WorldTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    int32_t ParentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: IntProperty)
    TArray<FString> ItemNames() const { return Read<TArray<FString>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_WorldTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_ParentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: IntProperty)
    void SET_ItemNames(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FAtomModelHierarchicalScene
{
public:
    TArray<FAtomModelHierarchicalSceneNode> SceneNodes() const { return Read<TArray<FAtomModelHierarchicalSceneNode>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_SceneNodes(const TArray<FAtomModelHierarchicalSceneNode>& Value) { Write<TArray<FAtomModelHierarchicalSceneNode>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x88
struct FAtomSourceModel
{
public:
    TArray<FAtomModelPrimitive> Primitives() const { return Read<TArray<FAtomModelPrimitive>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomHingedElement> Elements() const { return Read<TArray<FAtomHingedElement>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomModelSelectionSet> SelectionSets() const { return Read<TArray<FAtomModelSelectionSet>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomGlueSet> GlueSets() const { return Read<TArray<FAtomGlueSet>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomModelConfigurationGroup> Groups() const { return Read<TArray<FAtomModelConfigurationGroup>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    FBox Bounds() const { return Read<FBox>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x38, Type: StructProperty)

    void SET_Primitives(const TArray<FAtomModelPrimitive>& Value) { Write<TArray<FAtomModelPrimitive>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Elements(const TArray<FAtomHingedElement>& Value) { Write<TArray<FAtomHingedElement>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_SelectionSets(const TArray<FAtomModelSelectionSet>& Value) { Write<TArray<FAtomModelSelectionSet>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_GlueSets(const TArray<FAtomGlueSet>& Value) { Write<TArray<FAtomGlueSet>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_Groups(const TArray<FAtomModelConfigurationGroup>& Value) { Write<TArray<FAtomModelConfigurationGroup>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_Bounds(const FBox& Value) { Write<FBox>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x38, Type: StructProperty)
};

// Size: 0x18
struct FAtomModelIssue
{
public:
    int32_t ID() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    FString StringData() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_ID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_StringData(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x8
struct FCommonPartInstanceDescription
{
public:
    int16_t MeshIdx() const { return Read<int16_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: Int16Property)
    int16_t MaterialIdx() const { return Read<int16_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: Int16Property)
    int16_t UUIDIdx() const { return Read<int16_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x2, Type: Int16Property)
    uint16_t ColorId() const { return Read<uint16_t>(uintptr_t(this) + 0x6); } // 0x6 (Size: 0x2, Type: UInt16Property)

    void SET_MeshIdx(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: Int16Property)
    void SET_MaterialIdx(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: Int16Property)
    void SET_UUIDIdx(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x2, Type: Int16Property)
    void SET_ColorId(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x6, Value); } // 0x6 (Size: 0x2, Type: UInt16Property)
};

// Size: 0x50
struct FAtomCommonPartInstancesCache
{
public:
    TArray<UStaticMesh*> Meshes() const { return Read<TArray<UStaticMesh*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInterface*> Materials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FGuid> UUIDs() const { return Read<TArray<FGuid>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FCommonPartInstanceDescription> Instances() const { return Read<TArray<FCommonPartInstanceDescription>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform3f> InstanceTransforms() const { return Read<TArray<FTransform3f>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_Meshes(const TArray<UStaticMesh*>& Value) { Write<TArray<UStaticMesh*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Materials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_UUIDs(const TArray<FGuid>& Value) { Write<TArray<FGuid>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Instances(const TArray<FCommonPartInstanceDescription>& Value) { Write<TArray<FCommonPartInstanceDescription>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_InstanceTransforms(const TArray<FTransform3f>& Value) { Write<TArray<FTransform3f>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FAtomPrimitiveMaterialAssignment
{
public:
    FName SlotName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TSoftObjectPtr<UMaterialInterface> Material() const { return Read<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    bool bIsCustomMaterialOverride() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bHasManualColorSource() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)

    void SET_SlotName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Material(const TSoftObjectPtr<UMaterialInterface>& Value) { Write<TSoftObjectPtr<UMaterialInterface>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bIsCustomMaterialOverride(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_bHasManualColorSource(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FAtomPrimitiveInstanceData
{
public:
    TArray<FAtomPrimitiveMaterialAssignment> MaterialAssignments() const { return Read<TArray<FAtomPrimitiveMaterialAssignment>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TSoftObjectPtr<UStaticMesh> MeshOverride() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: SoftObjectProperty)

    void SET_MaterialAssignments(const TArray<FAtomPrimitiveMaterialAssignment>& Value) { Write<TArray<FAtomPrimitiveMaterialAssignment>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_MeshOverride(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x40
struct FAtomPrimitiveCollisionGeometryBox
{
public:
    FVector Center() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FRotator Rotation() const { return Read<FRotator>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    float X() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float Y() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float Z() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_Center(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_X(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_Y(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_Z(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc0
struct FAtomPrimitiveCollisionGeometryConvex
{
public:
    TArray<FVector> VertexData() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> IndexData() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FBox ElemBox() const { return Read<FBox>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x38, Type: StructProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x60, Type: StructProperty)

    void SET_VertexData(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_IndexData(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_ElemBox(const FBox& Value) { Write<FBox>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x38, Type: StructProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x60, Type: StructProperty)
};

// Size: 0xc
struct FAtomCommonPartAssetDescription
{
public:
    uint8_t CommonPartType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FName CommonPartStyle() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_CommonPartType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_CommonPartStyle(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FModelPrimitiveEntry
{
public:
    TSoftObjectPtr<UPrimitiveComponent> Component() const { return Read<TSoftObjectPtr<UPrimitiveComponent>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FAtomModelPartReference PartReference() const { return Read<FAtomModelPartReference>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x14, Type: StructProperty)

    void SET_Component(const TSoftObjectPtr<UPrimitiveComponent>& Value) { Write<TSoftObjectPtr<UPrimitiveComponent>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_PartReference(const FAtomModelPartReference& Value) { Write<FAtomModelPartReference>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x14, Type: StructProperty)
};

// Size: 0xc
struct FAtomModelPartColorInfo
{
public:
    FColor Color() const { return Read<FColor>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: StructProperty)
    int32_t ColorId() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    uint8_t MaterialType() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)

    void SET_Color(const FColor& Value) { Write<FColor>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: StructProperty)
    void SET_ColorId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_MaterialType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x28
struct FAtomModelPartDecorationInfo
{
public:
    UMaterialInterface* Material() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UTexture* Texture() const { return Read<UTexture*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FString PrimitiveSurfaceName() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t PrimitiveSurfaceIndex() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)

    void SET_Material(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Texture(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_PrimitiveSurfaceName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_PrimitiveSurfaceIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
};

// Size: 0x80
struct FAtomCommonPartAndTransform
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    TArray<FName> GeometryStyles() const { return Read<TArray<FName>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_GeometryStyles(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb0
struct FAtomModelPartInstanceInfo
{
public:
    FAtomModelPartGuid PartGuid() const { return Read<FAtomModelPartGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)
    int32_t PartId() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    UAtomPrimitive* Primitive() const { return Read<UAtomPrimitive*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomModelPartDecorationInfo> Decorations() const { return Read<TArray<FAtomModelPartDecorationInfo>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FAtomModelPartColorInfo> Colors() const { return Read<TArray<FAtomModelPartColorInfo>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> SelectionSets() const { return Read<TArray<FString>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    FString Group() const { return Read<FString>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StrProperty)
    FString ParentGroup() const { return Read<FString>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StrProperty)
    TArray<FAtomCommonPartAndTransform> CommonParts() const { return Read<TArray<FAtomCommonPartAndTransform>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    bool bIsUndersideVisible() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)

    void SET_PartGuid(const FAtomModelPartGuid& Value) { Write<FAtomModelPartGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
    void SET_PartId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_Primitive(const UAtomPrimitive*& Value) { Write<UAtomPrimitive*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Decorations(const TArray<FAtomModelPartDecorationInfo>& Value) { Write<TArray<FAtomModelPartDecorationInfo>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_Colors(const TArray<FAtomModelPartColorInfo>& Value) { Write<TArray<FAtomModelPartColorInfo>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_SelectionSets(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_Group(const FString& Value) { Write<FString>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StrProperty)
    void SET_ParentGroup(const FString& Value) { Write<FString>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StrProperty)
    void SET_CommonParts(const TArray<FAtomCommonPartAndTransform>& Value) { Write<TArray<FAtomCommonPartAndTransform>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsUndersideVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
struct FAtomModelPartsCollection
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FTransform Pivot() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    TArray<FAtomModelPartInstanceInfo> Parts() const { return Read<TArray<FAtomModelPartInstanceInfo>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Pivot(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Parts(const TArray<FAtomModelPartInstanceInfo>& Value) { Write<TArray<FAtomModelPartInstanceInfo>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc0
struct FAtomPartConnectivityFieldReference
{
public:
    FAtomModelPartInstanceInfo PartInfo() const { return Read<FAtomModelPartInstanceInfo>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0xb0, Type: StructProperty)
    FTypedConnectivityFieldReference ConnectivityField() const { return Read<FTypedConnectivityFieldReference>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0xc, Type: StructProperty)

    void SET_PartInfo(const FAtomModelPartInstanceInfo& Value) { Write<FAtomModelPartInstanceInfo>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0xb0, Type: StructProperty)
    void SET_ConnectivityField(const FTypedConnectivityFieldReference& Value) { Write<FTypedConnectivityFieldReference>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0xc, Type: StructProperty)
};

// Size: 0xc
struct FTypedConnectivityFieldReference : public FConnectivityFieldReference
{
public:
    uint8_t FieldType() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)

    void SET_FieldType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x28
struct FAtomProcessorResult
{
public:
    bool bSuccess() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    TArray<UObject*> ProcessedObjects() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<UObject*> SharedAssets() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_bSuccess(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_ProcessedObjects(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_SharedAssets(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FAtomOnProcessPrimitiveSettings
{
public:
    FString CustomLocation() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    bool bSupportDecorations() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_CustomLocation(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_bSupportDecorations(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FAtomModelProcessorInstance
{
public:
    bool bUseCustomSettings() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    UAtomModelProcessor* Processor() const { return Read<UAtomModelProcessor*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    UAtomModelProcessor* InternalTransientPropStorage() const { return Read<UAtomModelProcessor*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    TArray<TSoftObjectPtr<UObject*>> ProcessedObjects() const { return Read<TArray<TSoftObjectPtr<UObject*>>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_bUseCustomSettings(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Processor(const UAtomModelProcessor*& Value) { Write<UAtomModelProcessor*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_InternalTransientPropStorage(const UAtomModelProcessor*& Value) { Write<UAtomModelProcessor*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_ProcessedObjects(const TArray<TSoftObjectPtr<UObject*>>& Value) { Write<TArray<TSoftObjectPtr<UObject*>>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x130
struct FAtomPrimitiveMapping : public FTableRowBase
{
public:
    int32_t PartId() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    FString Revision() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FName DesignName() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    TSoftObjectPtr<UStaticMesh> StaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    TSet<int32_t> AllowedColorSet() const { return Read<TSet<int32_t>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x50, Type: SetProperty)
    TSet<FString> SearchTerms() const { return Read<TSet<FString>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x50, Type: SetProperty)
    TSoftObjectPtr<UTexture2D> Thumbnail() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x20, Type: SoftObjectProperty)
    FName SanitizedName() const { return Read<FName>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x4, Type: NameProperty)
    TSoftObjectPtr<UAtomPrimitive> AtomPrimitiveOverride() const { return Read<TSoftObjectPtr<UAtomPrimitive>>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x20, Type: SoftObjectProperty)

    void SET_PartId(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_Revision(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_DesignName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_StaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: SoftObjectProperty)
    void SET_AllowedColorSet(const TSet<int32_t>& Value) { Write<TSet<int32_t>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x50, Type: SetProperty)
    void SET_SearchTerms(const TSet<FString>& Value) { Write<TSet<FString>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x50, Type: SetProperty)
    void SET_Thumbnail(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_SanitizedName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x4, Type: NameProperty)
    void SET_AtomPrimitiveOverride(const TSoftObjectPtr<UAtomPrimitive>& Value) { Write<TSoftObjectPtr<UAtomPrimitive>>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x4
struct FAtomPrimitiveConnectionPointReference
{
public:
    int16_t PlanarFieldIndex() const { return Read<int16_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: Int16Property)
    int16_t ConnectionPointIndex() const { return Read<int16_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: Int16Property)

    void SET_PlanarFieldIndex(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: Int16Property)
    void SET_ConnectionPointIndex(const int16_t& Value) { Write<int16_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: Int16Property)
};

// Size: 0xc
struct FAtomPrimitiveTechnicCapReference
{
public:
    FName StyleName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t LOD() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t CapIndex() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)

    void SET_StyleName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_LOD(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_CapIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x50
struct FAtomCommonPartInstance
{
public:
    FTransform3f Transform() const { return Read<FTransform3f>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x30, Type: StructProperty)
    FAtomPrimitiveConnectionPointReference ConnectionPointReference() const { return Read<FAtomPrimitiveConnectionPointReference>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)
    TArray<FName> GeometryStyles() const { return Read<TArray<FName>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_Transform(const FTransform3f& Value) { Write<FTransform3f>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x30, Type: StructProperty)
    void SET_ConnectionPointReference(const FAtomPrimitiveConnectionPointReference& Value) { Write<FAtomPrimitiveConnectionPointReference>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
    void SET_GeometryStyles(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FAtomPrimitiveCommonPart
{
public:
    TArray<FAtomCommonPartInstance> UnscaledInstances() const { return Read<TArray<FAtomCommonPartInstance>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_UnscaledInstances(const TArray<FAtomCommonPartInstance>& Value) { Write<TArray<FAtomCommonPartInstance>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa0
struct FAtomPrimitivePhysicsAttributes
{
public:
    FMatrix InertiaTensor() const { return Read<FMatrix>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x80, Type: StructProperty)
    FVector CenterOfMass() const { return Read<FVector>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    float Mass() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)

    void SET_InertiaTensor(const FMatrix& Value) { Write<FMatrix>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x80, Type: StructProperty)
    void SET_CenterOfMass(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_Mass(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FAtomPrimitiveUserNote
{
public:
    FString Text() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString PartRevision() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_Text(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_PartRevision(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x30
struct FAtomPrimitiveOptimizationSettings
{
public:
    uint8_t OptimizationType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t ApproximationShapeType() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    bool bUseOptimizationAxisOverride() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FVector ApproximationAxisOverride() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_OptimizationType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ApproximationShapeType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_bUseOptimizationAxisOverride(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_ApproximationAxisOverride(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FAtomPrimitiveStyleImportData
{
public:
    FString Revision() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    uint8_t DatabaseSourceType() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    FString SourceDatabase() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)
    int32_t ImportWarnings() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)

    void SET_Revision(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_DatabaseSourceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_SourceDatabase(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
    void SET_ImportWarnings(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
};

// Size: 0x40
struct FAtomPrimitiveDetailTextureData
{
public:
    TSoftObjectPtr<UTexture> Texture() const { return Read<TSoftObjectPtr<UTexture>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FName Style() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    TArray<int32_t> Lods() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t GeometrySection() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    uint8_t TextureType() const { return Read<uint8_t>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: EnumProperty)

    void SET_Texture(const TSoftObjectPtr<UTexture>& Value) { Write<TSoftObjectPtr<UTexture>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Style(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_Lods(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_GeometrySection(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_TextureType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1
struct FAtomPrimitiveBevelOptions
{
public:
};

// Size: 0x1
struct FAtomPrimitiveBuildOptions
{
public:
};

// Size: 0x1
struct FAtomPrimitiveBuildSettings
{
public:
};

// Size: 0xc
struct FConnectivityFieldConnection
{
public:
    FConnectivityFieldReference Reference() const { return Read<FConnectivityFieldReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    uint8_t ConnectResult() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)

    void SET_Reference(const FConnectivityFieldReference& Value) { Write<FConnectivityFieldReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_ConnectResult(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x18
struct FHingeFieldConnectionInfo : public FPointFieldConnectionInfo
{
public:
    bool Flip() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_Flip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

