/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortnitePlaytimeRewardsTypes
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "GameplayTags.h"
#include "FortniteDynamicXpTypes.h"

// Size: 0x8
struct FPlaytimeXpProfileStat
{
public:
    int32_t CurrentWeekXp() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t CurrentWeek() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_CurrentWeekXp(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_CurrentWeek(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
struct FPlaytimeRewardsTableRow : public FTableRowBase
{
public:
    FGameplayTag ProductTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: StructProperty)
    int32_t XpPayout() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    FRestedXpUsage RestedXpUsage() const { return Read<FRestedXpUsage>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    float CompletionTimeMinutes() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float DisplayTimeIntervalMinutes() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    bool bDisableIfDynamicDistributorsAreActive() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bUseDynamicXpCircuitBreaker() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    int32_t WeeklyXpThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)
    int32_t DiminishedXpPayout() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)

    void SET_ProductTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: StructProperty)
    void SET_XpPayout(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_RestedXpUsage(const FRestedXpUsage& Value) { Write<FRestedXpUsage>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_CompletionTimeMinutes(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_DisplayTimeIntervalMinutes(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_bDisableIfDynamicDistributorsAreActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_bUseDynamicXpCircuitBreaker(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_WeeklyXpThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
    void SET_DiminishedXpPayout(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
};

