/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreatorRefreshMyIslandUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"
#include "SlateCore.h"

// Size: 0x4a0
class UFortCreativeMyIslandSideNavWidget : public UCommonActivatableWidget
{
public:
    FDataTableRowHandle SearchInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle ClearSearchInputActionRow() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x10, Type: StructProperty)

    void SET_SearchInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x10, Type: StructProperty)
    void SET_ClearSearchInputActionRow(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x10, Type: StructProperty)
};

