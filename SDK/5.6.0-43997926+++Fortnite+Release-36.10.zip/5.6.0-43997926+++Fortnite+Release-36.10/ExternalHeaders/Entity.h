/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Entity
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Execution.h"

// Size: 0x48
class UBaseEntity : public UObject
{
public:
    TArray<UObject*> Components() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<UObject*> OwnedEntities() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_Components(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_OwnedEntities(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa8
class UEntityPrefab : public UBlueprint
{
public:
};

// Size: 0x28
class UEntityReplicationSupport : public UInterface
{
public:
};

// Size: 0x468
class AEntityReplicator : public AActor
{
public:
    bool bIsNetInitialized() const { return Read<bool>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UObject> EntityPtr() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UObject> EntityOwnerPtr() const { return Read<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x20, Type: SoftObjectProperty)
    FSoftObjectPath EntityServerPath() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath EntityOwnerServerPath() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x18, Type: StructProperty)
    FFastEntityComponentArray NonDynamicEntityComponents() const { return Read<FFastEntityComponentArray>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x118, Type: StructProperty)
    UObject* EntityPendingInitialization() const { return Read<UObject*>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x8, Type: ObjectProperty)
    TArray<UObject*> EntityComponentsPendingInitialization() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x10, Type: ArrayProperty)

    void SET_bIsNetInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x1, Type: BoolProperty)
    void SET_EntityPtr(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_EntityOwnerPtr(const TSoftObjectPtr<UObject>& Value) { Write<TSoftObjectPtr<UObject>>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_EntityServerPath(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x18, Type: StructProperty)
    void SET_EntityOwnerServerPath(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x18, Type: StructProperty)
    void SET_NonDynamicEntityComponents(const FFastEntityComponentArray& Value) { Write<FFastEntityComponentArray>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x118, Type: StructProperty)
    void SET_EntityPendingInitialization(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x8, Type: ObjectProperty)
    void SET_EntityComponentsPendingInitialization(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x468
class AEntityReplicator_AlwaysRelevant : public AEntityReplicator
{
public:
};

// Size: 0x250
class UWorldExecutionSubsystem : public UWorldSubsystem
{
public:
    UExecutionSubsystem* ExecutionSystem() const { return Read<UExecutionSubsystem*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_ExecutionSystem(const UExecutionSubsystem*& Value) { Write<UExecutionSubsystem*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x48
class UNetEntityFactory : public UNetObjectFactory
{
public:
};

// Size: 0x2e8
class ASimulationEntity : public AActor
{
public:
    UObject* SimulationEntity() const { return Read<UObject*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UClass* SavedEntityClass() const { return Read<UClass*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ClassProperty)
    UClass* SavedEntityComponentClass() const { return Read<UClass*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ClassProperty)
    TArray<FString> DefaultComponentClassNames() const { return Read<TArray<FString>>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> DefaultComponentClasses() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x10, Type: ArrayProperty)

    void SET_SimulationEntity(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_SavedEntityClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ClassProperty)
    void SET_SavedEntityComponentClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ClassProperty)
    void SET_DefaultComponentClassNames(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultComponentClasses(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb8
class USimulationLifetimeComponent : public UActorComponent
{
public:
};

// Size: 0x30
class UEntityPlayspaceRegistryBase : public UWorldSubsystem
{
public:
};

// Size: 0x30
class UEntityRegistryBase : public UWorldSubsystem
{
public:
};

// Size: 0x38
class UEntityVerseEngineSubsystem : public UEngineSubsystem
{
public:
};

// Size: 0x10
struct FFastEntityComponentArrayItem : public FFastArraySerializerItem
{
public:
    FName ComponentName() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)

    void SET_ComponentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
};

// Size: 0x118
struct FFastEntityComponentArray : public FFastArraySerializer
{
public:
    TArray<FFastEntityComponentArrayItem> Components() const { return Read<TArray<FFastEntityComponentArrayItem>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)

    void SET_Components(const TArray<FFastEntityComponentArrayItem>& Value) { Write<TArray<FFastEntityComponentArrayItem>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x58
struct FWorldExecutionPhase : public FTickFunction
{
public:
};

// Size: 0x18
struct FReplicatedDataEntry
{
public:
    UObject* ReplicatedData() const { return Read<UObject*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_ReplicatedData(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FReplicatedDataRegistry
{
public:
    TArray<FReplicatedDataEntry> Registry() const { return Read<TArray<FReplicatedDataEntry>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Registry(const TArray<FReplicatedDataEntry>& Value) { Write<TArray<FReplicatedDataEntry>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

