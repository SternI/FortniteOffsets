/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortniteMusic
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "GameplayTags.h"
#include "Engine.h"
#include "MetasoundEngine.h"

// Size: 0x28
class UFortMusicItemInterface : public UInterface
{
public:
};

// Size: 0x28
class UFortMusicPlayerInterface : public UInterface
{
public:
};

// Size: 0x170
class UFortMusicPlayerRegistry : public UGameInstanceSubsystem
{
public:
    TScriptInterface<Class> CurrentItem() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: InterfaceProperty)
    FFortMusicPlayerParams CurrentItemPlayParams() const { return Read<FFortMusicPlayerParams>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x48, Type: StructProperty)
    TScriptInterface<Class> CurrentPlaylist() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: InterfaceProperty)
    FFortMusicPlayerParams PlaylistParams() const { return Read<FFortMusicPlayerParams>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x48, Type: StructProperty)

    void SET_CurrentItem(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: InterfaceProperty)
    void SET_CurrentItemPlayParams(const FFortMusicPlayerParams& Value) { Write<FFortMusicPlayerParams>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x48, Type: StructProperty)
    void SET_CurrentPlaylist(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: InterfaceProperty)
    void SET_PlaylistParams(const FFortMusicPlayerParams& Value) { Write<FFortMusicPlayerParams>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x48, Type: StructProperty)
};

// Size: 0x28
class UFortMusicPlaylist : public UInterface
{
public:
};

// Size: 0x40
class UFortSimpleMusicPlaylist : public UObject
{
public:
    TArray<TScriptInterface<Class>> Items() const { return Read<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const TArray<TScriptInterface<Class>>& Value) { Write<TArray<TScriptInterface<Class>>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x88
struct FFortMusicPlaybackState
{
public:
    TScriptInterface<Class> CurrentItem() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: InterfaceProperty)
    TScriptInterface<Class> CurrentPlaylist() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: InterfaceProperty)
    FFortMusicPlayerParams PlayParams() const { return Read<FFortMusicPlayerParams>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x48, Type: StructProperty)

    void SET_CurrentItem(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: InterfaceProperty)
    void SET_CurrentPlaylist(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: InterfaceProperty)
    void SET_PlayParams(const FFortMusicPlayerParams& Value) { Write<FFortMusicPlayerParams>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x48, Type: StructProperty)
};

// Size: 0x48
struct FFortMusicPlayerParams
{
public:
    uint8_t PlaybackType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    float StartTimeOffset() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    bool bSkipCountIn() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bLooping() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)
    bool bAutoPlay() const { return Read<bool>(uintptr_t(this) + 0xa); } // 0xa (Size: 0x1, Type: BoolProperty)
    UAudioComponent* AudioComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    UMetaSoundSource* MetaSoundSource() const { return Read<UMetaSoundSource*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag MusicEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)
    FName MusicEventGroup() const { return Read<FName>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: NameProperty)
    FGameplayTagContainer MusicEventBehaviorTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x20, Type: StructProperty)

    void SET_PlaybackType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_StartTimeOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_bSkipCountIn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_bLooping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
    void SET_bAutoPlay(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa, Value); } // 0xa (Size: 0x1, Type: BoolProperty)
    void SET_AudioComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_MetaSoundSource(const UMetaSoundSource*& Value) { Write<UMetaSoundSource*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_MusicEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
    void SET_MusicEventGroup(const FName& Value) { Write<FName>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: NameProperty)
    void SET_MusicEventBehaviorTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x20, Type: StructProperty)
};

