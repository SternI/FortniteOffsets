/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ControlRig
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "AnimationCore.h"
#include "CoreUObject.h"
#include "Constraints.h"
#include "Engine.h"
#include "RigVM.h"
#include "MovieSceneTracks.h"
#include "MovieScene.h"

// Size: 0x138
class UControlRigShapeLibraryLink : public UNameSpacedUserData
{
public:
    TSoftObjectPtr<UControlRigShapeLibrary> ShapeLibrary() const { return Read<TSoftObjectPtr<UControlRigShapeLibrary>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FName> ShapeNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    UControlRigShapeLibrary* ShapeLibraryCached() const { return Read<UControlRigShapeLibrary*>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x8, Type: ObjectProperty)

    void SET_ShapeLibrary(const TSoftObjectPtr<UControlRigShapeLibrary>& Value) { Write<TSoftObjectPtr<UControlRigShapeLibrary>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ShapeNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x10, Type: ArrayProperty)
    void SET_ShapeLibraryCached(const UControlRigShapeLibrary*& Value) { Write<UControlRigShapeLibrary*>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd08
class UModularRig : public UControlRig
{
public:
    TArray<FRigModuleInstance> Modules() const { return Read<TArray<FRigModuleInstance>>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x10, Type: ArrayProperty)
    FModularRigSettings ModularRigSettings() const { return Read<FModularRigSettings>(uintptr_t(this) + 0xb98); } // 0xb98 (Size: 0x1, Type: StructProperty)
    FModularRigModel ModularRigModel() const { return Read<FModularRigModel>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x100, Type: StructProperty)
    TArray<FRigModuleExecutionElement> ExecutionQueue() const { return Read<TArray<FRigModuleExecutionElement>>(uintptr_t(this) + 0xca0); } // 0xca0 (Size: 0x10, Type: ArrayProperty)

    void SET_Modules(const TArray<FRigModuleInstance>& Value) { Write<TArray<FRigModuleInstance>>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x10, Type: ArrayProperty)
    void SET_ModularRigSettings(const FModularRigSettings& Value) { Write<FModularRigSettings>(uintptr_t(this) + 0xb98, Value); } // 0xb98 (Size: 0x1, Type: StructProperty)
    void SET_ModularRigModel(const FModularRigModel& Value) { Write<FModularRigModel>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x100, Type: StructProperty)
    void SET_ExecutionQueue(const TArray<FRigModuleExecutionElement>& Value) { Write<TArray<FRigModuleExecutionElement>>(uintptr_t(this) + 0xca0, Value); } // 0xca0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb68
class UControlRig : public URigVMHost
{
public:
    TArray<UControlRigOverrideAsset*> OverrideAssets() const { return Read<TArray<UControlRigOverrideAsset*>>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    uint8_t ExecutionType() const { return Read<uint8_t>(uintptr_t(this) + 0x2b9); } // 0x2b9 (Size: 0x1, Type: EnumProperty)
    FRigHierarchySettings HierarchySettings() const { return Read<FRigHierarchySettings>(uintptr_t(this) + 0x2bc); } // 0x2bc (Size: 0x8, Type: StructProperty)
    TMap<FRigControlElementCustomization, FRigElementKey> ControlCustomizations() const { return Read<TMap<FRigControlElementCustomization, FRigElementKey>>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x50, Type: MapProperty)
    URigHierarchy* DynamicHierarchy() const { return Read<URigHierarchy*>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: ObjectProperty)
    TArray<TSoftObjectPtr<UControlRigShapeLibrary*>> ShapeLibraries() const { return Read<TArray<TSoftObjectPtr<UControlRigShapeLibrary*>>>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x10, Type: ArrayProperty)
    TMap<FString, FString> ShapeLibraryNameMap() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x50, Type: MapProperty)
    FRigVMExtendedExecuteContext RigVMExtendedExecuteContext() const { return Read<FRigVMExtendedExecuteContext>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x240, Type: StructProperty)
    UAnimationDataSourceRegistry* DataSourceRegistry() const { return Read<UAnimationDataSourceRegistry*>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    FRigInfluenceMapPerEvent Influences() const { return Read<FRigInfluenceMapPerEvent>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x60, Type: StructProperty)
    TMap<UDataAssetLink*, FName> ExternalVariableDataAssetLinks() const { return Read<TMap<UDataAssetLink*, FName>>(uintptr_t(this) + 0x7a0); } // 0x7a0 (Size: 0x50, Type: MapProperty)
    uint8_t OnControlSelected_BP() const { return Read<uint8_t>(uintptr_t(this) + 0x8c0); } // 0x8c0 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    bool bIsAdditive() const { return Read<bool>(uintptr_t(this) + 0x8f0); } // 0x8f0 (Size: 0x1, Type: BoolProperty)
    FRigModuleSettings RigModuleSettings() const { return Read<FRigModuleSettings>(uintptr_t(this) + 0xad0); } // 0xad0 (Size: 0x78, Type: StructProperty)
    FString RigModulePrefix() const { return Read<FString>(uintptr_t(this) + 0xb48); } // 0xb48 (Size: 0x10, Type: StrProperty)

    void SET_OverrideAssets(const TArray<UControlRigOverrideAsset*>& Value) { Write<TArray<UControlRigOverrideAsset*>>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x10, Type: ArrayProperty)
    void SET_ExecutionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2b9, Value); } // 0x2b9 (Size: 0x1, Type: EnumProperty)
    void SET_HierarchySettings(const FRigHierarchySettings& Value) { Write<FRigHierarchySettings>(uintptr_t(this) + 0x2bc, Value); } // 0x2bc (Size: 0x8, Type: StructProperty)
    void SET_ControlCustomizations(const TMap<FRigControlElementCustomization, FRigElementKey>& Value) { Write<TMap<FRigControlElementCustomization, FRigElementKey>>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x50, Type: MapProperty)
    void SET_DynamicHierarchy(const URigHierarchy*& Value) { Write<URigHierarchy*>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: ObjectProperty)
    void SET_ShapeLibraries(const TArray<TSoftObjectPtr<UControlRigShapeLibrary*>>& Value) { Write<TArray<TSoftObjectPtr<UControlRigShapeLibrary*>>>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x10, Type: ArrayProperty)
    void SET_ShapeLibraryNameMap(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x50, Type: MapProperty)
    void SET_RigVMExtendedExecuteContext(const FRigVMExtendedExecuteContext& Value) { Write<FRigVMExtendedExecuteContext>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x240, Type: StructProperty)
    void SET_DataSourceRegistry(const UAnimationDataSourceRegistry*& Value) { Write<UAnimationDataSourceRegistry*>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Influences(const FRigInfluenceMapPerEvent& Value) { Write<FRigInfluenceMapPerEvent>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x60, Type: StructProperty)
    void SET_ExternalVariableDataAssetLinks(const TMap<UDataAssetLink*, FName>& Value) { Write<TMap<UDataAssetLink*, FName>>(uintptr_t(this) + 0x7a0, Value); } // 0x7a0 (Size: 0x50, Type: MapProperty)
    void SET_OnControlSelected_BP(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8c0, Value); } // 0x8c0 (Size: 0x1, Type: MulticastSparseDelegateProperty)
    void SET_bIsAdditive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8f0, Value); } // 0x8f0 (Size: 0x1, Type: BoolProperty)
    void SET_RigModuleSettings(const FRigModuleSettings& Value) { Write<FRigModuleSettings>(uintptr_t(this) + 0xad0, Value); } // 0xad0 (Size: 0x78, Type: StructProperty)
    void SET_RigModulePrefix(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb48, Value); } // 0xb48 (Size: 0x10, Type: StrProperty)
};

// Size: 0x5d0
class URigHierarchy : public UObject
{
public:
    uint32_t TopologyVersion() const { return Read<uint32_t>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: UInt32Property)
    uint32_t MetadataVersion() const { return Read<uint32_t>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: UInt32Property)
    uint16_t MetadataTagVersion() const { return Read<uint16_t>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x2, Type: UInt16Property)
    bool bEnableDirtyPropagation() const { return Read<bool>(uintptr_t(this) + 0xb2); } // 0xb2 (Size: 0x1, Type: BoolProperty)
    int32_t TransformStackIndex() const { return Read<int32_t>(uintptr_t(this) + 0x29c); } // 0x29c (Size: 0x4, Type: IntProperty)
    URigHierarchyController* HierarchyController() const { return Read<URigHierarchyController*>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    UModularRigRuleManager* RuleManager() const { return Read<UModularRigRuleManager*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    URigHierarchy* HierarchyForCacheValidation() const { return Read<URigHierarchy*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)

    void SET_TopologyVersion(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: UInt32Property)
    void SET_MetadataVersion(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: UInt32Property)
    void SET_MetadataTagVersion(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x2, Type: UInt16Property)
    void SET_bEnableDirtyPropagation(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb2, Value); } // 0xb2 (Size: 0x1, Type: BoolProperty)
    void SET_TransformStackIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x29c, Value); } // 0x29c (Size: 0x4, Type: IntProperty)
    void SET_HierarchyController(const URigHierarchyController*& Value) { Write<URigHierarchyController*>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    void SET_RuleManager(const UModularRigRuleManager*& Value) { Write<UModularRigRuleManager*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    void SET_HierarchyForCacheValidation(const URigHierarchy*& Value) { Write<URigHierarchy*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class URigHierarchyProvider : public UInterface
{
public:
};

// Size: 0x28
class UAnimNodeControlRigLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x140
class UTransformableControlHandle : public UTransformableHandle
{
public:
    TSoftObjectPtr<UControlRig> ControlRig() const { return Read<TSoftObjectPtr<UControlRig>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x20, Type: SoftObjectProperty)
    FName ControlName() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)

    void SET_ControlRig(const TSoftObjectPtr<UControlRig>& Value) { Write<TSoftObjectPtr<UControlRig>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ControlName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
};

// Size: 0x3e0
class UControlRigAnimInstance : public UAnimInstance
{
public:
};

// Size: 0x390
class UControlRigBlueprintGeneratedClass : public URigVMBlueprintGeneratedClass
{
public:
};

// Size: 0x6c0
class UControlRigComponent : public UPrimitiveComponent
{
public:
    UClass* ControlRigClass() const { return Read<UClass*>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: ClassProperty)
    TArray<FControlRigComponentMappedElement> UserDefinedElements() const { return Read<TArray<FControlRigComponentMappedElement>>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x10, Type: ArrayProperty)
    TArray<FControlRigComponentMappedElement> MappedElements() const { return Read<TArray<FControlRigComponentMappedElement>>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x10, Type: ArrayProperty)
    bool bEnableLazyEvaluation() const { return Read<bool>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x1, Type: BoolProperty)
    float LazyEvaluationPositionThreshold() const { return Read<float>(uintptr_t(this) + 0x5a4); } // 0x5a4 (Size: 0x4, Type: FloatProperty)
    float LazyEvaluationRotationThreshold() const { return Read<float>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x4, Type: FloatProperty)
    float LazyEvaluationScaleThreshold() const { return Read<float>(uintptr_t(this) + 0x5ac); } // 0x5ac (Size: 0x4, Type: FloatProperty)
    bool bResetTransformBeforeTick() const { return Read<bool>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x1, Type: BoolProperty)
    bool bResetInitialsBeforeConstruction() const { return Read<bool>(uintptr_t(this) + 0x5b1); } // 0x5b1 (Size: 0x1, Type: BoolProperty)
    bool bUpdateRigOnTick() const { return Read<bool>(uintptr_t(this) + 0x5b2); } // 0x5b2 (Size: 0x1, Type: BoolProperty)
    bool bUpdateInEditor() const { return Read<bool>(uintptr_t(this) + 0x5b3); } // 0x5b3 (Size: 0x1, Type: BoolProperty)
    bool bDrawBones() const { return Read<bool>(uintptr_t(this) + 0x5b4); } // 0x5b4 (Size: 0x1, Type: BoolProperty)
    bool bShowDebugDrawing() const { return Read<bool>(uintptr_t(this) + 0x5b5); } // 0x5b5 (Size: 0x1, Type: BoolProperty)
    UControlRig* ControlRig() const { return Read<UControlRig*>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)

    void SET_ControlRigClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: ClassProperty)
    void SET_UserDefinedElements(const TArray<FControlRigComponentMappedElement>& Value) { Write<TArray<FControlRigComponentMappedElement>>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x10, Type: ArrayProperty)
    void SET_MappedElements(const TArray<FControlRigComponentMappedElement>& Value) { Write<TArray<FControlRigComponentMappedElement>>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x10, Type: ArrayProperty)
    void SET_bEnableLazyEvaluation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x1, Type: BoolProperty)
    void SET_LazyEvaluationPositionThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x5a4, Value); } // 0x5a4 (Size: 0x4, Type: FloatProperty)
    void SET_LazyEvaluationRotationThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x4, Type: FloatProperty)
    void SET_LazyEvaluationScaleThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x5ac, Value); } // 0x5ac (Size: 0x4, Type: FloatProperty)
    void SET_bResetTransformBeforeTick(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x1, Type: BoolProperty)
    void SET_bResetInitialsBeforeConstruction(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5b1, Value); } // 0x5b1 (Size: 0x1, Type: BoolProperty)
    void SET_bUpdateRigOnTick(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5b2, Value); } // 0x5b2 (Size: 0x1, Type: BoolProperty)
    void SET_bUpdateInEditor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5b3, Value); } // 0x5b3 (Size: 0x1, Type: BoolProperty)
    void SET_bDrawBones(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5b4, Value); } // 0x5b4 (Size: 0x1, Type: BoolProperty)
    void SET_bShowDebugDrawing(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5b5, Value); } // 0x5b5 (Size: 0x1, Type: BoolProperty)
    void SET_ControlRig(const UControlRig*& Value) { Write<UControlRig*>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x350
class AControlRigControlActor : public AActor
{
public:
    AActor* ActorToTrack() const { return Read<AActor*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    UClass* ControlRigClass() const { return Read<UClass*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ClassProperty)
    bool bRefreshOnTick() const { return Read<bool>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x1, Type: BoolProperty)
    bool bIsSelectable() const { return Read<bool>(uintptr_t(this) + 0x2b9); } // 0x2b9 (Size: 0x1, Type: BoolProperty)
    UMaterialInterface* MaterialOverride() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    FString ColorParameter() const { return Read<FString>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x10, Type: StrProperty)
    bool bCastShadows() const { return Read<bool>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x1, Type: BoolProperty)
    USceneComponent* ActorRootComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UControlRig> ControlRig() const { return Read<TSoftObjectPtr<UControlRig>>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x20, Type: SoftObjectProperty)
    TArray<FName> ControlNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> ShapeTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x10, Type: ArrayProperty)
    TArray<UStaticMeshComponent*> Components() const { return Read<TArray<UStaticMeshComponent*>>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> Materials() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x10, Type: ArrayProperty)
    FName ColorParameterName() const { return Read<FName>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x4, Type: NameProperty)

    void SET_ActorToTrack(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_ControlRigClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ClassProperty)
    void SET_bRefreshOnTick(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x1, Type: BoolProperty)
    void SET_bIsSelectable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b9, Value); } // 0x2b9 (Size: 0x1, Type: BoolProperty)
    void SET_MaterialOverride(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_ColorParameter(const FString& Value) { Write<FString>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x10, Type: StrProperty)
    void SET_bCastShadows(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x1, Type: BoolProperty)
    void SET_ActorRootComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_ControlRig(const TSoftObjectPtr<UControlRig>& Value) { Write<TSoftObjectPtr<UControlRig>>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_ControlNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x10, Type: ArrayProperty)
    void SET_ShapeTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x10, Type: ArrayProperty)
    void SET_Components(const TArray<UStaticMeshComponent*>& Value) { Write<TArray<UStaticMeshComponent*>>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x10, Type: ArrayProperty)
    void SET_Materials(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x10, Type: ArrayProperty)
    void SET_ColorParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x4, Type: NameProperty)
};

// Size: 0x380
class AControlRigShapeActor : public AActor
{
public:
    USceneComponent* ActorRootComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMeshComponent() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    uint32_t ControlRigIndex() const { return Read<uint32_t>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x4, Type: UInt32Property)
    TWeakObjectPtr<UControlRig*> ControlRig() const { return Read<TWeakObjectPtr<UControlRig*>>(uintptr_t(this) + 0x2c4); } // 0x2c4 (Size: 0x8, Type: WeakObjectProperty)
    FName ControlName() const { return Read<FName>(uintptr_t(this) + 0x2cc); } // 0x2cc (Size: 0x4, Type: NameProperty)
    FName ShapeName() const { return Read<FName>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x4, Type: NameProperty)
    FName ColorParameterName() const { return Read<FName>(uintptr_t(this) + 0x2d4); } // 0x2d4 (Size: 0x4, Type: NameProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x18, Type: StructProperty)
    bool bSelected() const { return (Read<uint8_t>(uintptr_t(this) + 0x368) >> 0x0) & 1; } // 0x368:0 (Size: 0x1, Type: BoolProperty)
    bool bHovered() const { return (Read<uint8_t>(uintptr_t(this) + 0x368) >> 0x1) & 1; } // 0x368:1 (Size: 0x1, Type: BoolProperty)

    void SET_ActorRootComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMeshComponent(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_ControlRigIndex(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x4, Type: UInt32Property)
    void SET_ControlRig(const TWeakObjectPtr<UControlRig*>& Value) { Write<TWeakObjectPtr<UControlRig*>>(uintptr_t(this) + 0x2c4, Value); } // 0x2c4 (Size: 0x8, Type: WeakObjectProperty)
    void SET_ControlName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2cc, Value); } // 0x2cc (Size: 0x4, Type: NameProperty)
    void SET_ShapeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x4, Type: NameProperty)
    void SET_ColorParameterName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2d4, Value); } // 0x2d4 (Size: 0x4, Type: NameProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x18, Type: StructProperty)
    void SET_bSelected(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x368); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x368, B); } // 0x368:0 (Size: 0x1, Type: BoolProperty)
    void SET_bHovered(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x368); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x368, B); } // 0x368:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x140
class UControlRigShapeLibrary : public UObject
{
public:
    FControlRigShapeDefinition DefaultShape() const { return Read<FControlRigShapeDefinition>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xa0, Type: StructProperty)
    TSoftObjectPtr<UMaterial> DefaultMaterial() const { return Read<TSoftObjectPtr<UMaterial>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UMaterial> XRayMaterial() const { return Read<TSoftObjectPtr<UMaterial>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x20, Type: SoftObjectProperty)
    FName MaterialColorParameter() const { return Read<FName>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: NameProperty)
    TArray<FControlRigShapeDefinition> Shapes() const { return Read<TArray<FControlRigShapeDefinition>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: ArrayProperty)

    void SET_DefaultShape(const FControlRigShapeDefinition& Value) { Write<FControlRigShapeDefinition>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xa0, Type: StructProperty)
    void SET_DefaultMaterial(const TSoftObjectPtr<UMaterial>& Value) { Write<TSoftObjectPtr<UMaterial>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_XRayMaterial(const TSoftObjectPtr<UMaterial>& Value) { Write<TSoftObjectPtr<UMaterial>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MaterialColorParameter(const FName& Value) { Write<FName>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: NameProperty)
    void SET_Shapes(const TArray<FControlRigShapeDefinition>& Value) { Write<TArray<FControlRigShapeDefinition>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x198
class UControlRigOverrideAsset : public UObject
{
public:
    FControlRigOverrideContainer Overrides() const { return Read<FControlRigOverrideContainer>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x158, Type: StructProperty)

    void SET_Overrides(const FControlRigOverrideContainer& Value) { Write<FControlRigOverrideContainer>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x158, Type: StructProperty)
};

// Size: 0x3d8
class UControlRigReplay : public UObject
{
public:
    FText Description() const { return Read<FText>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: TextProperty)
    FSoftObjectPath ControlRigObjectPath() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FSoftObjectPath PreviewSkeletalMeshObjectPath() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    FControlRigReplayTracks InputTracks() const { return Read<FControlRigReplayTracks>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x178, Type: StructProperty)
    FControlRigReplayTracks OutputTracks() const { return Read<FControlRigReplayTracks>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x178, Type: StructProperty)
    double Tolerance() const { return Read<double>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: DoubleProperty)
    bool bValidateHierarchyTopology() const { return Read<bool>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x1, Type: BoolProperty)
    bool bValidatePose() const { return Read<bool>(uintptr_t(this) + 0x361); } // 0x361 (Size: 0x1, Type: BoolProperty)
    bool bValidateMetadata() const { return Read<bool>(uintptr_t(this) + 0x362); } // 0x362 (Size: 0x1, Type: BoolProperty)
    bool bValidateVariables() const { return Read<bool>(uintptr_t(this) + 0x363); } // 0x363 (Size: 0x1, Type: BoolProperty)
    TArray<int32_t> FramesToSkip() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x10, Type: ArrayProperty)
    bool EnableTest() const { return Read<bool>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x1, Type: BoolProperty)

    void SET_Description(const FText& Value) { Write<FText>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: TextProperty)
    void SET_ControlRigObjectPath(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_PreviewSkeletalMeshObjectPath(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_InputTracks(const FControlRigReplayTracks& Value) { Write<FControlRigReplayTracks>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x178, Type: StructProperty)
    void SET_OutputTracks(const FControlRigReplayTracks& Value) { Write<FControlRigReplayTracks>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x178, Type: StructProperty)
    void SET_Tolerance(const double& Value) { Write<double>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: DoubleProperty)
    void SET_bValidateHierarchyTopology(const bool& Value) { Write<bool>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x1, Type: BoolProperty)
    void SET_bValidatePose(const bool& Value) { Write<bool>(uintptr_t(this) + 0x361, Value); } // 0x361 (Size: 0x1, Type: BoolProperty)
    void SET_bValidateMetadata(const bool& Value) { Write<bool>(uintptr_t(this) + 0x362, Value); } // 0x362 (Size: 0x1, Type: BoolProperty)
    void SET_bValidateVariables(const bool& Value) { Write<bool>(uintptr_t(this) + 0x363, Value); } // 0x363 (Size: 0x1, Type: BoolProperty)
    void SET_FramesToSkip(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x10, Type: ArrayProperty)
    void SET_EnableTest(const bool& Value) { Write<bool>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x518
class UControlRigTestData : public UControlRigReplay
{
public:
    FControlRigTestDataFrame Initial() const { return Read<FControlRigTestDataFrame>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x108, Type: StructProperty)
    TArray<FControlRigTestDataFrame> InputFrames() const { return Read<TArray<FControlRigTestDataFrame>>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x10, Type: ArrayProperty)
    TArray<FControlRigTestDataFrame> OutputFrames() const { return Read<TArray<FControlRigTestDataFrame>>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> EventQueue() const { return Read<TArray<FName>>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x10, Type: ArrayProperty)

    void SET_Initial(const FControlRigTestDataFrame& Value) { Write<FControlRigTestDataFrame>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x108, Type: StructProperty)
    void SET_InputFrames(const TArray<FControlRigTestDataFrame>& Value) { Write<TArray<FControlRigTestDataFrame>>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x10, Type: ArrayProperty)
    void SET_OutputFrames(const TArray<FControlRigTestDataFrame>& Value) { Write<TArray<FControlRigTestDataFrame>>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x10, Type: ArrayProperty)
    void SET_EventQueue(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x68
class UControlRigValidator : public UObject
{
public:
    TArray<UControlRigValidationPass*> Passes() const { return Read<TArray<UControlRigValidationPass*>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Passes(const TArray<UControlRigValidationPass*>& Value) { Write<TArray<UControlRigValidationPass*>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
class UControlRigValidationPass : public UObject
{
public:
};

// Size: 0x50
class UModularRigController : public UObject
{
public:
};

// Size: 0x30
class UModularRigRuleManager : public UObject
{
public:
};

// Size: 0xb78
class UAdditiveControlRig : public UControlRig
{
public:
};

// Size: 0xba8
class UFKControlRig : public UControlRig
{
public:
    TArray<bool> IsControlActive() const { return Read<TArray<bool>>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x10, Type: ArrayProperty)
    uint8_t ApplyMode() const { return Read<uint8_t>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x1, Type: EnumProperty)

    void SET_IsControlActive(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x10, Type: ArrayProperty)
    void SET_ApplyMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x80
class URigHierarchyController : public UObject
{
public:
    bool bReportWarningsAndErrors() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_bReportWarningsAndErrors(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x3e0
class UControlRigLayerInstance : public UAnimInstance
{
public:
};

// Size: 0x440
class UMovieSceneControlRigParameterSection : public UMovieSceneParameterSection
{
public:
    UControlRig* ControlRig() const { return Read<UControlRig*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    UClass* ControlRigClass() const { return Read<UClass*>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x8, Type: ClassProperty)
    TArray<bool> ControlsMask() const { return Read<TArray<bool>>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    TSet<FName> ControlNameMask() const { return Read<TSet<FName>>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x50, Type: SetProperty)
    FMovieSceneTransformMask TransformMask() const { return Read<FMovieSceneTransformMask>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x4, Type: StructProperty)
    FMovieSceneFloatChannel Weight() const { return Read<FMovieSceneFloatChannel>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x110, Type: StructProperty)
    TMap<FChannelMapInfo, FName> ControlChannelMap() const { return Read<TMap<FChannelMapInfo, FName>>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x50, Type: MapProperty)
    TArray<FEnumParameterNameAndCurve> EnumParameterNamesAndCurves() const { return Read<TArray<FEnumParameterNameAndCurve>>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x10, Type: ArrayProperty)
    TArray<FIntegerParameterNameAndCurve> IntegerParameterNamesAndCurves() const { return Read<TArray<FIntegerParameterNameAndCurve>>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: ArrayProperty)
    TArray<FSpaceControlNameAndChannel> SpaceChannels() const { return Read<TArray<FSpaceControlNameAndChannel>>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x10, Type: ArrayProperty)
    TArray<FConstraintAndActiveChannel> ConstraintsChannels() const { return Read<TArray<FConstraintAndActiveChannel>>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)

    void SET_ControlRig(const UControlRig*& Value) { Write<UControlRig*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    void SET_ControlRigClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x8, Type: ClassProperty)
    void SET_ControlsMask(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x10, Type: ArrayProperty)
    void SET_ControlNameMask(const TSet<FName>& Value) { Write<TSet<FName>>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x50, Type: SetProperty)
    void SET_TransformMask(const FMovieSceneTransformMask& Value) { Write<FMovieSceneTransformMask>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x4, Type: StructProperty)
    void SET_Weight(const FMovieSceneFloatChannel& Value) { Write<FMovieSceneFloatChannel>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x110, Type: StructProperty)
    void SET_ControlChannelMap(const TMap<FChannelMapInfo, FName>& Value) { Write<TMap<FChannelMapInfo, FName>>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x50, Type: MapProperty)
    void SET_EnumParameterNamesAndCurves(const TArray<FEnumParameterNameAndCurve>& Value) { Write<TArray<FEnumParameterNameAndCurve>>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x10, Type: ArrayProperty)
    void SET_IntegerParameterNamesAndCurves(const TArray<FIntegerParameterNameAndCurve>& Value) { Write<TArray<FIntegerParameterNameAndCurve>>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: ArrayProperty)
    void SET_SpaceChannels(const TArray<FSpaceControlNameAndChannel>& Value) { Write<TArray<FSpaceControlNameAndChannel>>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x10, Type: ArrayProperty)
    void SET_ConstraintsChannels(const TArray<FConstraintAndActiveChannel>& Value) { Write<TArray<FConstraintAndActiveChannel>>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x290
class UMovieSceneControlRigParameterTrack : public UMovieSceneNameableTrack
{
public:
    TMap<TWeakObjectPtr<UMovieSceneSection*>, FName> SectionToKeyPerControl() const { return Read<TMap<TWeakObjectPtr<UMovieSceneSection*>, FName>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x50, Type: MapProperty)
    UControlRig* ControlRig() const { return Read<UControlRig*>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    UMovieSceneSection* SectionToKey() const { return Read<UMovieSceneSection*>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    TArray<UMovieSceneSection*> Sections() const { return Read<TArray<UMovieSceneSection*>>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    FName TrackName() const { return Read<FName>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x4, Type: NameProperty)
    TMap<FControlRotationOrder, FName> ControlsRotationOrder() const { return Read<TMap<FControlRotationOrder, FName>>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x50, Type: MapProperty)
    int32_t PriorityOrder() const { return Read<int32_t>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x4, Type: IntProperty)
    FInstancedPropertyBag ControlRigSettingsOverrides() const { return Read<FInstancedPropertyBag>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x10, Type: StructProperty)
    TMap<UControlRig*, TWeakObjectPtr<UWorld*>> GameWorldControlRigs() const { return Read<TMap<UControlRig*, TWeakObjectPtr<UWorld*>>>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x50, Type: MapProperty)

    void SET_SectionToKeyPerControl(const TMap<TWeakObjectPtr<UMovieSceneSection*>, FName>& Value) { Write<TMap<TWeakObjectPtr<UMovieSceneSection*>, FName>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x50, Type: MapProperty)
    void SET_ControlRig(const UControlRig*& Value) { Write<UControlRig*>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x8, Type: ObjectProperty)
    void SET_SectionToKey(const UMovieSceneSection*& Value) { Write<UMovieSceneSection*>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Sections(const TArray<UMovieSceneSection*>& Value) { Write<TArray<UMovieSceneSection*>>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: ArrayProperty)
    void SET_TrackName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x4, Type: NameProperty)
    void SET_ControlsRotationOrder(const TMap<FControlRotationOrder, FName>& Value) { Write<TMap<FControlRotationOrder, FName>>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x50, Type: MapProperty)
    void SET_PriorityOrder(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x4, Type: IntProperty)
    void SET_ControlRigSettingsOverrides(const FInstancedPropertyBag& Value) { Write<FInstancedPropertyBag>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x10, Type: StructProperty)
    void SET_GameWorldControlRigs(const TMap<UControlRig*, TWeakObjectPtr<UWorld*>>& Value) { Write<TMap<UControlRig*, TWeakObjectPtr<UWorld*>>>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x50, Type: MapProperty)
};

// Size: 0x248
class UMovieSceneControlRigParameterEvaluatorSystem : public UMovieSceneEntitySystem
{
public:
    UMovieScenePiecewiseDoubleBlenderSystem* DoubleBlenderSystem() const { return Read<UMovieScenePiecewiseDoubleBlenderSystem*>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x8, Type: ObjectProperty)

    void SET_DoubleBlenderSystem(const UMovieScenePiecewiseDoubleBlenderSystem*& Value) { Write<UMovieScenePiecewiseDoubleBlenderSystem*>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x30
class UControlRigSettings : public UDeveloperSettings
{
public:
};

// Size: 0x30
class UControlRigEditorSettings : public URigVMEditorSettings
{
public:
};

// Size: 0x88
class UControlRigPoseAsset : public UObject
{
public:
    FControlRigControlPose Pose() const { return Read<FControlRigControlPose>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x60, Type: StructProperty)

    void SET_Pose(const FControlRigControlPose& Value) { Write<FControlRigControlPose>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x60, Type: StructProperty)
};

// Size: 0x50
class UControlRigPoseMirrorSettings : public UObject
{
public:
    FString RightSide() const { return Read<FString>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StrProperty)
    FString LeftSide() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    TEnumAsByte<EAxis> MirrorAxis() const { return Read<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EAxis> AxisToFlip() const { return Read<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: ByteProperty)

    void SET_RightSide(const FString& Value) { Write<FString>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StrProperty)
    void SET_LeftSide(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_MirrorAxis(const TEnumAsByte<EAxis>& Value) { Write<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: ByteProperty)
    void SET_AxisToFlip(const TEnumAsByte<EAxis>& Value) { Write<TEnumAsByte<EAxis>>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x38
class UControlRigPoseProjectSettings : public UObject
{
public:
    TArray<FDirectoryPath> RootSaveDirs() const { return Read<TArray<FDirectoryPath>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_RootSaveDirs(const TArray<FDirectoryPath>& Value) { Write<TArray<FDirectoryPath>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb0
class UControlRigWorkflowOptions : public URigVMUserWorkflowOptions
{
public:
    URigHierarchy* Hierarchy() const { return Read<URigHierarchy*>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    TArray<FRigElementKey> Selection() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)

    void SET_Hierarchy(const URigHierarchy*& Value) { Write<URigHierarchy*>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: ObjectProperty)
    void SET_Selection(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb8
class UControlRigTransformWorkflowOptions : public UControlRigWorkflowOptions
{
public:
    TEnumAsByte<ERigTransformType> TransformType() const { return Read<TEnumAsByte<ERigTransformType>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x1, Type: ByteProperty)

    void SET_TransformType(const TEnumAsByte<ERigTransformType>& Value) { Write<TEnumAsByte<ERigTransformType>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xb8
class UControlRigNumericalValidationPass : public UControlRigValidationPass
{
public:
    bool bCheckControls() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool bCheckBones() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)
    bool bCheckCurves() const { return Read<bool>(uintptr_t(this) + 0x2a); } // 0x2a (Size: 0x1, Type: BoolProperty)
    float TranslationPrecision() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float RotationPrecision() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float ScalePrecision() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float CurvePrecision() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    FName EventNameA() const { return Read<FName>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: NameProperty)
    FName EventNameB() const { return Read<FName>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: NameProperty)
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x70, Type: StructProperty)

    void SET_bCheckControls(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_bCheckBones(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
    void SET_bCheckCurves(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a, Value); } // 0x2a (Size: 0x1, Type: BoolProperty)
    void SET_TranslationPrecision(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_RotationPrecision(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_ScalePrecision(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_CurvePrecision(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_EventNameA(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: NameProperty)
    void SET_EventNameB(const FName& Value) { Write<FName>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: NameProperty)
    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x70, Type: StructProperty)
};

// Size: 0x8
struct FRigElementKey
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x58
struct FRigBaseElement
{
public:
    FRigElementKey Key() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    int32_t Index() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t SubIndex() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    int32_t CreatedAtInstructionIndex() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    bool bSelected() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)

    void SET_Key(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_SubIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_CreatedAtInstructionIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_bSelected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x118
struct FRigTransformElement : public FRigBaseElement
{
public:
};

// Size: 0x230
struct FRigMultiParentElement : public FRigTransformElement
{
public:
};

// Size: 0x580
struct FRigControlElement : public FRigMultiParentElement
{
public:
    FRigControlSettings Settings() const { return Read<FRigControlSettings>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x210, Type: StructProperty)
    FRigPreferredEulerAngles PreferredEulerAngles() const { return Read<FRigPreferredEulerAngles>(uintptr_t(this) + 0x440); } // 0x440 (Size: 0x38, Type: StructProperty)

    void SET_Settings(const FRigControlSettings& Value) { Write<FRigControlSettings>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x210, Type: StructProperty)
    void SET_PreferredEulerAngles(const FRigPreferredEulerAngles& Value) { Write<FRigPreferredEulerAngles>(uintptr_t(this) + 0x440, Value); } // 0x440 (Size: 0x38, Type: StructProperty)
};

// Size: 0x38
struct FRigPreferredEulerAngles
{
public:
    uint8_t RotationOrder() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FVector Current() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Initial() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_RotationOrder(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Current(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Initial(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x210
struct FRigControlSettings
{
public:
    uint8_t AnimationType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t ControlType() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    FName DisplayName() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    uint8_t PrimaryAxis() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    bool bIsCurve() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)
    TArray<FRigControlLimitEnabled> LimitEnabled() const { return Read<TArray<FRigControlLimitEnabled>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bDrawLimits() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    FRigControlValue MinimumValue() const { return Read<FRigControlValue>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x84, Type: StructProperty)
    FRigControlValue MaximumValue() const { return Read<FRigControlValue>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x84, Type: StructProperty)
    bool bShapeVisible() const { return Read<bool>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x1, Type: BoolProperty)
    uint8_t ShapeVisibility() const { return Read<uint8_t>(uintptr_t(this) + 0x12d); } // 0x12d (Size: 0x1, Type: EnumProperty)
    FName ShapeName() const { return Read<FName>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x4, Type: NameProperty)
    FLinearColor ShapeColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x10, Type: StructProperty)
    bool bIsTransientControl() const { return Read<bool>(uintptr_t(this) + 0x144); } // 0x144 (Size: 0x1, Type: BoolProperty)
    UEnum* ControlEnum() const { return Read<UEnum*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ObjectProperty)
    FRigControlElementCustomization Customization() const { return Read<FRigControlElementCustomization>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x20, Type: StructProperty)
    TArray<FRigElementKey> DrivenControls() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x10, Type: ArrayProperty)
    bool bGroupWithParentControl() const { return Read<bool>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x1, Type: BoolProperty)
    bool bRestrictSpaceSwitching() const { return Read<bool>(uintptr_t(this) + 0x191); } // 0x191 (Size: 0x1, Type: BoolProperty)
    TArray<ERigControlTransformChannel> FilteredChannels() const { return Read<TArray<ERigControlTransformChannel>>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x10, Type: ArrayProperty)
    uint8_t PreferredRotationOrder() const { return Read<uint8_t>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x1, Type: EnumProperty)
    bool bUsePreferredRotationOrder() const { return Read<bool>(uintptr_t(this) + 0x1a9); } // 0x1a9 (Size: 0x1, Type: BoolProperty)
    FTransform ShapeTransform() const { return Read<FTransform>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x60, Type: StructProperty)

    void SET_AnimationType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ControlType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_DisplayName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_PrimaryAxis(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_bIsCurve(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
    void SET_LimitEnabled(const TArray<FRigControlLimitEnabled>& Value) { Write<TArray<FRigControlLimitEnabled>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_bDrawLimits(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_MinimumValue(const FRigControlValue& Value) { Write<FRigControlValue>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x84, Type: StructProperty)
    void SET_MaximumValue(const FRigControlValue& Value) { Write<FRigControlValue>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x84, Type: StructProperty)
    void SET_bShapeVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x1, Type: BoolProperty)
    void SET_ShapeVisibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x12d, Value); } // 0x12d (Size: 0x1, Type: EnumProperty)
    void SET_ShapeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x4, Type: NameProperty)
    void SET_ShapeColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x10, Type: StructProperty)
    void SET_bIsTransientControl(const bool& Value) { Write<bool>(uintptr_t(this) + 0x144, Value); } // 0x144 (Size: 0x1, Type: BoolProperty)
    void SET_ControlEnum(const UEnum*& Value) { Write<UEnum*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ObjectProperty)
    void SET_Customization(const FRigControlElementCustomization& Value) { Write<FRigControlElementCustomization>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x20, Type: StructProperty)
    void SET_DrivenControls(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x10, Type: ArrayProperty)
    void SET_bGroupWithParentControl(const bool& Value) { Write<bool>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x1, Type: BoolProperty)
    void SET_bRestrictSpaceSwitching(const bool& Value) { Write<bool>(uintptr_t(this) + 0x191, Value); } // 0x191 (Size: 0x1, Type: BoolProperty)
    void SET_FilteredChannels(const TArray<ERigControlTransformChannel>& Value) { Write<TArray<ERigControlTransformChannel>>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x10, Type: ArrayProperty)
    void SET_PreferredRotationOrder(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x1, Type: EnumProperty)
    void SET_bUsePreferredRotationOrder(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a9, Value); } // 0x1a9 (Size: 0x1, Type: BoolProperty)
    void SET_ShapeTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x60, Type: StructProperty)
};

// Size: 0x20
struct FRigControlElementCustomization
{
public:
    TArray<FRigElementKeyWithLabel> AvailableSpaces() const { return Read<TArray<FRigElementKeyWithLabel>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigElementKey> RemovedSpaces() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_AvailableSpaces(const TArray<FRigElementKeyWithLabel>& Value) { Write<TArray<FRigElementKeyWithLabel>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_RemovedSpaces(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc
struct FRigElementKeyWithLabel
{
public:
    FRigElementKey Key() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FName Label() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_Key(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Label(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x84
struct FRigControlValue
{
public:
    FRigControlValueStorage FloatStorage() const { return Read<FRigControlValueStorage>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x84, Type: StructProperty)

    void SET_FloatStorage(const FRigControlValueStorage& Value) { Write<FRigControlValueStorage>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x84, Type: StructProperty)
};

// Size: 0x84
struct FRigControlValueStorage
{
public:
    float Float00() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Float01() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Float02() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Float03() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float Float10() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float Float11() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float Float12() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float Float13() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float Float20() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float Float21() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float Float22() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float Float23() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float Float30() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float Float31() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float Float32() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float Float33() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float Float00_2() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float Float01_2() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    float Float02_2() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float Float03_2() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float Float10_2() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float Float11_2() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float Float12_2() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float Float13_2() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    float Float20_2() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    float Float21_2() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    float Float22_2() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    float Float23_2() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    float Float30_2() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    float Float31_2() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    float Float32_2() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    float Float33_2() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    bool bValid() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)

    void SET_Float00(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Float01(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Float02(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Float03(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Float10(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Float11(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Float12(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_Float13(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_Float20(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_Float21(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_Float22(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_Float23(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_Float30(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_Float31(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_Float32(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_Float33(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_Float00_2(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_Float01_2(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_Float02_2(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_Float03_2(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_Float10_2(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_Float11_2(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_Float12_2(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_Float13_2(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_Float20_2(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_Float21_2(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_Float22_2(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_Float23_2(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_Float30_2(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_Float31_2(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_Float32_2(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_Float33_2(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET_bValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x2
struct FRigControlLimitEnabled
{
public:
    bool bMinimum() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bMaximum() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)

    void SET_bMinimum(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bMaximum(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x78
struct FRigModuleSettings
{
public:
    FRigModuleIdentifier Identifier() const { return Read<FRigModuleIdentifier>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FSoftObjectPath Icon() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FString Category() const { return Read<FString>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StrProperty)
    FString Keywords() const { return Read<FString>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StrProperty)
    FString Description() const { return Read<FString>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StrProperty)
    TArray<FRigModuleConnector> ExposedConnectors() const { return Read<TArray<FRigModuleConnector>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)

    void SET_Identifier(const FRigModuleIdentifier& Value) { Write<FRigModuleIdentifier>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_Icon(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Category(const FString& Value) { Write<FString>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StrProperty)
    void SET_Keywords(const FString& Value) { Write<FString>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StrProperty)
    void SET_Description(const FString& Value) { Write<FString>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StrProperty)
    void SET_ExposedConnectors(const TArray<FRigModuleConnector>& Value) { Write<TArray<FRigModuleConnector>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FRigModuleConnector
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FRigConnectorSettings Settings() const { return Read<FRigConnectorSettings>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x28, Type: StructProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Settings(const FRigConnectorSettings& Value) { Write<FRigConnectorSettings>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x28, Type: StructProperty)
};

// Size: 0x28
struct FRigConnectorSettings
{
public:
    FString Description() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bOptional() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bIsArray() const { return Read<bool>(uintptr_t(this) + 0x12); } // 0x12 (Size: 0x1, Type: BoolProperty)
    TArray<FRigConnectionRuleStash> Rules() const { return Read<TArray<FRigConnectionRuleStash>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Description(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_bOptional(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_bIsArray(const bool& Value) { Write<bool>(uintptr_t(this) + 0x12, Value); } // 0x12 (Size: 0x1, Type: BoolProperty)
    void SET_Rules(const TArray<FRigConnectionRuleStash>& Value) { Write<TArray<FRigConnectionRuleStash>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FRigConnectionRuleStash
{
public:
    FString ScriptStructPath() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString ExportedText() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_ScriptStructPath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_ExportedText(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x20
struct FRigModuleIdentifier
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString Type() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_Type(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
};

// Size: 0x60
struct FRigInfluenceMapPerEvent
{
public:
    TArray<FRigInfluenceMap> Maps() const { return Read<TArray<FRigInfluenceMap>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TMap<int32_t, FName> EventToIndex() const { return Read<TMap<int32_t, FName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x50, Type: MapProperty)

    void SET_Maps(const TArray<FRigInfluenceMap>& Value) { Write<TArray<FRigInfluenceMap>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_EventToIndex(const TMap<int32_t, FName>& Value) { Write<TMap<int32_t, FName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x50, Type: MapProperty)
};

// Size: 0x68
struct FRigInfluenceMap
{
public:
    FName EventName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TArray<FRigInfluenceEntry> Entries() const { return Read<TArray<FRigInfluenceEntry>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TMap<int32_t, FRigElementKey> KeyToIndex() const { return Read<TMap<int32_t, FRigElementKey>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x50, Type: MapProperty)

    void SET_EventName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Entries(const TArray<FRigInfluenceEntry>& Value) { Write<TArray<FRigInfluenceEntry>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_KeyToIndex(const TMap<int32_t, FRigElementKey>& Value) { Write<TMap<int32_t, FRigElementKey>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x50, Type: MapProperty)
};

// Size: 0x18
struct FRigInfluenceEntry
{
public:
    FRigElementKey Source() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementKey> AffectedList() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Source(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_AffectedList(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FRigHierarchySettings
{
public:
    uint8_t ElementNameDisplayMode() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    int32_t ProceduralElementLimit() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_ElementNameDisplayMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ProceduralElementLimit(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x2
struct FControlRigIOSettings
{
public:
    bool bUpdatePose() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bUpdateCurves() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)

    void SET_bUpdatePose(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bUpdateCurves(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa8
struct FRigModuleInstance
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    UControlRig* RigPtr() const { return Read<UControlRig*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FString ParentPath() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FName ParentModuleName() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    TMap<FRigVMExternalVariable, FName> VariableBindings() const { return Read<TMap<FRigVMExternalVariable, FName>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x50, Type: MapProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_RigPtr(const UControlRig*& Value) { Write<UControlRig*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_ParentPath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_ParentModuleName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_VariableBindings(const TMap<FRigVMExternalVariable, FName>& Value) { Write<TMap<FRigVMExternalVariable, FName>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x50, Type: MapProperty)
};

// Size: 0x18
struct FRigModuleExecutionElement
{
public:
    FName ModuleName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName EventName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    bool bExecuted() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)

    void SET_ModuleName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_EventName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_bExecuted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x148
struct FMovieSceneControlRigInstanceData : public FMovieSceneSequenceInstanceData
{
public:
    bool bAdditive() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bApplyBoneFilter() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)
    FInputBlendPose BoneFilter() const { return Read<FInputBlendPose>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FMovieSceneFloatChannel Weight() const { return Read<FMovieSceneFloatChannel>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x110, Type: StructProperty)
    FMovieSceneEvaluationOperand Operand() const { return Read<FMovieSceneEvaluationOperand>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x14, Type: StructProperty)

    void SET_bAdditive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_bApplyBoneFilter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
    void SET_BoneFilter(const FInputBlendPose& Value) { Write<FInputBlendPose>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Weight(const FMovieSceneFloatChannel& Value) { Write<FMovieSceneFloatChannel>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x110, Type: StructProperty)
    void SET_Operand(const FMovieSceneEvaluationOperand& Value) { Write<FMovieSceneEvaluationOperand>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x14, Type: StructProperty)
};

// Size: 0x8
struct FRigUnit : public FRigVMStruct
{
public:
};

// Size: 0x10
struct FRigUnit_DebugBase : public FRigUnit
{
public:
    FRigVMDebugDrawSettings DebugDrawSettings() const { return Read<FRigVMDebugDrawSettings>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_DebugDrawSettings(const FRigVMDebugDrawSettings& Value) { Write<FRigVMDebugDrawSettings>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x10
struct FRigUnitMutable : public FRigUnit
{
public:
    FRigVMExecutePin ExecutePin() const { return Read<FRigVMExecutePin>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_ExecutePin(const FRigVMExecutePin& Value) { Write<FRigVMExecutePin>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x18
struct FRigUnit_DebugBaseMutable : public FRigUnitMutable
{
public:
    FRigVMDebugDrawSettings DebugDrawSettings() const { return Read<FRigVMDebugDrawSettings>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)

    void SET_DebugDrawSettings(const FRigVMDebugDrawSettings& Value) { Write<FRigVMDebugDrawSettings>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
};

// Size: 0x8
struct FRigUnit_HighlevelBase : public FRigUnit
{
public:
};

// Size: 0x10
struct FRigUnit_HighlevelBaseMutable : public FRigUnitMutable
{
public:
};

// Size: 0x8
struct FStructReference
{
public:
};

// Size: 0xf0
struct FRigTransformStackEntry
{
public:
    FRigElementKey Key() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    TEnumAsByte<ERigTransformStackEntryType> EntryType() const { return Read<TEnumAsByte<ERigTransformStackEntryType>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<ERigTransformType> TransformType() const { return Read<TEnumAsByte<ERigTransformType>>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: ByteProperty)
    FTransform OldTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform NewTransform() const { return Read<FTransform>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x60, Type: StructProperty)
    bool bAffectChildren() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    TArray<FString> Callstack() const { return Read<TArray<FString>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)

    void SET_Key(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_EntryType(const TEnumAsByte<ERigTransformStackEntryType>& Value) { Write<TEnumAsByte<ERigTransformStackEntryType>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: ByteProperty)
    void SET_TransformType(const TEnumAsByte<ERigTransformType>& Value) { Write<TEnumAsByte<ERigTransformType>>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: ByteProperty)
    void SET_OldTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_NewTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x60, Type: StructProperty)
    void SET_bAffectChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_Callstack(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x228
struct FAnimNode_ControlRigBase : public FAnimNode_CustomProperty
{
public:
    FPoseLink Source() const { return Read<FPoseLink>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    bool bResetInputPoseToInitial() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)
    bool bTransferInputPose() const { return Read<bool>(uintptr_t(this) + 0x69); } // 0x69 (Size: 0x1, Type: BoolProperty)
    bool bTransferInputCurves() const { return Read<bool>(uintptr_t(this) + 0x6a); } // 0x6a (Size: 0x1, Type: BoolProperty)
    bool bTransferPoseInGlobalSpace() const { return Read<bool>(uintptr_t(this) + 0x6b); } // 0x6b (Size: 0x1, Type: BoolProperty)
    TArray<FBoneReference> InputBonesToTransfer() const { return Read<TArray<FBoneReference>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    TArray<FBoneReference> OutputBonesToTransfer() const { return Read<TArray<FBoneReference>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<UAssetUserData*> AssetUserData() const { return Read<TArray<UAssetUserData*>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    TWeakObjectPtr<UNodeMappingContainer*> NodeMappingContainer() const { return Read<TWeakObjectPtr<UNodeMappingContainer*>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x8, Type: WeakObjectProperty)
    FControlRigIOSettings InputSettings() const { return Read<FControlRigIOSettings>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x2, Type: StructProperty)
    FControlRigIOSettings OutputSettings() const { return Read<FControlRigIOSettings>(uintptr_t(this) + 0xaa); } // 0xaa (Size: 0x2, Type: StructProperty)
    bool bExecute() const { return Read<bool>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x1, Type: BoolProperty)
    TArray<FControlRigAnimNodeEventName> EventQueue() const { return Read<TArray<FControlRigAnimNodeEventName>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: ArrayProperty)

    void SET_Source(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_bResetInputPoseToInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
    void SET_bTransferInputPose(const bool& Value) { Write<bool>(uintptr_t(this) + 0x69, Value); } // 0x69 (Size: 0x1, Type: BoolProperty)
    void SET_bTransferInputCurves(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6a, Value); } // 0x6a (Size: 0x1, Type: BoolProperty)
    void SET_bTransferPoseInGlobalSpace(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b, Value); } // 0x6b (Size: 0x1, Type: BoolProperty)
    void SET_InputBonesToTransfer(const TArray<FBoneReference>& Value) { Write<TArray<FBoneReference>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_OutputBonesToTransfer(const TArray<FBoneReference>& Value) { Write<TArray<FBoneReference>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_AssetUserData(const TArray<UAssetUserData*>& Value) { Write<TArray<UAssetUserData*>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_NodeMappingContainer(const TWeakObjectPtr<UNodeMappingContainer*>& Value) { Write<TWeakObjectPtr<UNodeMappingContainer*>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x8, Type: WeakObjectProperty)
    void SET_InputSettings(const FControlRigIOSettings& Value) { Write<FControlRigIOSettings>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x2, Type: StructProperty)
    void SET_OutputSettings(const FControlRigIOSettings& Value) { Write<FControlRigIOSettings>(uintptr_t(this) + 0xaa, Value); } // 0xaa (Size: 0x2, Type: StructProperty)
    void SET_bExecute(const bool& Value) { Write<bool>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x1, Type: BoolProperty)
    void SET_EventQueue(const TArray<FControlRigAnimNodeEventName>& Value) { Write<TArray<FControlRigAnimNodeEventName>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x4
struct FControlRigAnimNodeEventName
{
public:
    FName EventName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)

    void SET_EventName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x4b8
struct FAnimNode_ControlRig : public FAnimNode_ControlRigBase
{
public:
    UClass* ControlRigClass() const { return Read<UClass*>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x8, Type: ClassProperty)
    UClass* DefaultControlRigClass() const { return Read<UClass*>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x8, Type: ClassProperty)
    UControlRig* ControlRig() const { return Read<UControlRig*>(uintptr_t(this) + 0x238); } // 0x238 (Size: 0x8, Type: ObjectProperty)
    TMap<UControlRig*, UClass*> ControlRigPerClass() const { return Read<TMap<UControlRig*, UClass*>>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x50, Type: MapProperty)
    float Alpha() const { return Read<float>(uintptr_t(this) + 0x290); } // 0x290 (Size: 0x4, Type: FloatProperty)
    uint8_t AlphaInputType() const { return Read<uint8_t>(uintptr_t(this) + 0x294); } // 0x294 (Size: 0x1, Type: EnumProperty)
    bool bAlphaBoolEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x295) >> 0x0) & 1; } // 0x295:0 (Size: 0x1, Type: BoolProperty)
    bool bSetRefPoseFromSkeleton() const { return (Read<uint8_t>(uintptr_t(this) + 0x295) >> 0x1) & 1; } // 0x295:1 (Size: 0x1, Type: BoolProperty)
    FInputScaleBias AlphaScaleBias() const { return Read<FInputScaleBias>(uintptr_t(this) + 0x298); } // 0x298 (Size: 0x8, Type: StructProperty)
    FInputAlphaBoolBlend AlphaBoolBlend() const { return Read<FInputAlphaBoolBlend>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x48, Type: StructProperty)
    FName AlphaCurveName() const { return Read<FName>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x4, Type: NameProperty)
    FInputScaleBiasClamp AlphaScaleBiasClamp() const { return Read<FInputScaleBiasClamp>(uintptr_t(this) + 0x2ec); } // 0x2ec (Size: 0x30, Type: StructProperty)
    TMap<FName, FName> InputMapping() const { return Read<TMap<FName, FName>>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x50, Type: MapProperty)
    TMap<FName, FName> OutputMapping() const { return Read<TMap<FName, FName>>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x50, Type: MapProperty)
    int32_t LODThreshold() const { return Read<int32_t>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x4, Type: IntProperty)

    void SET_ControlRigClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x8, Type: ClassProperty)
    void SET_DefaultControlRigClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x8, Type: ClassProperty)
    void SET_ControlRig(const UControlRig*& Value) { Write<UControlRig*>(uintptr_t(this) + 0x238, Value); } // 0x238 (Size: 0x8, Type: ObjectProperty)
    void SET_ControlRigPerClass(const TMap<UControlRig*, UClass*>& Value) { Write<TMap<UControlRig*, UClass*>>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x50, Type: MapProperty)
    void SET_Alpha(const float& Value) { Write<float>(uintptr_t(this) + 0x290, Value); } // 0x290 (Size: 0x4, Type: FloatProperty)
    void SET_AlphaInputType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x294, Value); } // 0x294 (Size: 0x1, Type: EnumProperty)
    void SET_bAlphaBoolEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x295); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x295, B); } // 0x295:0 (Size: 0x1, Type: BoolProperty)
    void SET_bSetRefPoseFromSkeleton(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x295); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x295, B); } // 0x295:1 (Size: 0x1, Type: BoolProperty)
    void SET_AlphaScaleBias(const FInputScaleBias& Value) { Write<FInputScaleBias>(uintptr_t(this) + 0x298, Value); } // 0x298 (Size: 0x8, Type: StructProperty)
    void SET_AlphaBoolBlend(const FInputAlphaBoolBlend& Value) { Write<FInputAlphaBoolBlend>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x48, Type: StructProperty)
    void SET_AlphaCurveName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x4, Type: NameProperty)
    void SET_AlphaScaleBiasClamp(const FInputScaleBiasClamp& Value) { Write<FInputScaleBiasClamp>(uintptr_t(this) + 0x2ec, Value); } // 0x2ec (Size: 0x30, Type: StructProperty)
    void SET_InputMapping(const TMap<FName, FName>& Value) { Write<TMap<FName, FName>>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x50, Type: MapProperty)
    void SET_OutputMapping(const TMap<FName, FName>& Value) { Write<TMap<FName, FName>>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x50, Type: MapProperty)
    void SET_LODThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x230
struct FAnimNode_ControlRig_ExternalSource : public FAnimNode_ControlRigBase
{
public:
    TWeakObjectPtr<UControlRig*> ControlRig() const { return Read<TWeakObjectPtr<UControlRig*>>(uintptr_t(this) + 0x228); } // 0x228 (Size: 0x8, Type: WeakObjectProperty)

    void SET_ControlRig(const TWeakObjectPtr<UControlRig*>& Value) { Write<TWeakObjectPtr<UControlRig*>>(uintptr_t(this) + 0x228, Value); } // 0x228 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x10
struct FControlRigReference : public FAnimNodeReference
{
public:
};

// Size: 0x880
struct FControlRigAnimInstanceProxy : public FAnimInstanceProxy
{
public:
};

// Size: 0xe0
struct FControlRigComponentMappedElement
{
public:
    FSoftComponentReference ComponentReference() const { return Read<FSoftComponentReference>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x40, Type: StructProperty)
    int32_t TransformIndex() const { return Read<int32_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: IntProperty)
    FName TransformName() const { return Read<FName>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: NameProperty)
    uint8_t ElementType() const { return Read<uint8_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: EnumProperty)
    FName ElementName() const { return Read<FName>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: NameProperty)
    uint8_t Direction() const { return Read<uint8_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: EnumProperty)
    FTransform Offset() const { return Read<FTransform>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x60, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x1, Type: EnumProperty)
    USceneComponent* SceneComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    int32_t ElementIndex() const { return Read<int32_t>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: IntProperty)
    int32_t SubIndex() const { return Read<int32_t>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: IntProperty)

    void SET_ComponentReference(const FSoftComponentReference& Value) { Write<FSoftComponentReference>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x40, Type: StructProperty)
    void SET_TransformIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: IntProperty)
    void SET_TransformName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: NameProperty)
    void SET_ElementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: EnumProperty)
    void SET_ElementName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: NameProperty)
    void SET_Direction(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: EnumProperty)
    void SET_Offset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x60, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x1, Type: EnumProperty)
    void SET_SceneComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_ElementIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: IntProperty)
    void SET_SubIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x10
struct FControlRigComponentMappedComponent
{
public:
    USceneComponent* Component() const { return Read<USceneComponent*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FName ElementName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t ElementType() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Direction() const { return Read<uint8_t>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: EnumProperty)

    void SET_Component(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ElementName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_ElementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Direction(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: EnumProperty)
};

// Size: 0x8
struct FControlRigComponentMappedBone
{
public:
    FName Source() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName Target() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_Source(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Target(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x8
struct FControlRigComponentMappedCurve
{
public:
    FName Source() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName Target() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)

    void SET_Source(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Target(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x1a0
struct FControlShapeActorCreationParam
{
public:
};

// Size: 0xa0
struct FControlRigShapeDefinition
{
public:
    FName ShapeName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    TSoftObjectPtr<UStaticMesh> StaticMesh() const { return Read<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)

    void SET_ShapeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_StaticMesh(const TSoftObjectPtr<UStaticMesh>& Value) { Write<TSoftObjectPtr<UStaticMesh>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
};

// Size: 0x48
struct FControlRigOverrideValue
{
public:
};

// Size: 0x158
struct FControlRigOverrideContainer
{
public:
};

// Size: 0x18
struct FControlRigReplayVariable
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FName CPPType() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FString Value() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_CPPType(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_Value(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x10
struct FSampleTrackHost
{
public:
};

// Size: 0x178
struct FControlRigReplayTracks : public FSampleTrackHost
{
public:
};

// Size: 0x108
struct FControlRigTestDataFrame
{
public:
    double AbsoluteTime() const { return Read<double>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    double DeltaTime() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    TArray<FControlRigReplayVariable> Variables() const { return Read<TArray<FControlRigReplayVariable>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x70, Type: StructProperty)
    TArray<char> MetaData() const { return Read<TArray<char>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)

    void SET_AbsoluteTime(const double& Value) { Write<double>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: DoubleProperty)
    void SET_DeltaTime(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
    void SET_Variables(const TArray<FControlRigReplayVariable>& Value) { Write<TArray<FControlRigReplayVariable>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x70, Type: StructProperty)
    void SET_MetaData(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x70
struct FRigPose
{
public:
    TArray<FRigPoseElement> Elements() const { return Read<TArray<FRigPoseElement>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    int32_t HierarchyTopologyVersion() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t PoseHash() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)

    void SET_Elements(const TArray<FRigPoseElement>& Value) { Write<TArray<FRigPoseElement>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_HierarchyTopologyVersion(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_PoseHash(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
};

// Size: 0x110
struct FRigPoseElement
{
public:
    FCachedRigElement Index() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FTransform GlobalTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform LocalTransform() const { return Read<FTransform>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x60, Type: StructProperty)
    FVector PreferredEulerAngle() const { return Read<FVector>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x18, Type: StructProperty)
    FRigElementKey ActiveParent() const { return Read<FRigElementKey>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: StructProperty)
    float CurveValue() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)

    void SET_Index(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_GlobalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_LocalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x60, Type: StructProperty)
    void SET_PreferredEulerAngle(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x18, Type: StructProperty)
    void SET_ActiveParent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: StructProperty)
    void SET_CurveValue(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FCachedRigElement
{
public:
    FRigElementKey Key() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    uint16_t Index() const { return Read<uint16_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x2, Type: UInt16Property)
    int32_t ContainerVersion() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_Key(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Index(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x2, Type: UInt16Property)
    void SET_ContainerVersion(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FControlRigValidationContext
{
public:
};

// Size: 0x18
struct FCRSimContainer
{
public:
    float TimeStep() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float AccumulatedTime() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float TimeLeftForStep() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_TimeStep(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_AccumulatedTime(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_TimeLeftForStep(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FCRSimLinearSpring
{
public:
    int32_t SubjectA() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t SubjectB() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    float Coefficient() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Equilibrium() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_SubjectA(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_SubjectB(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_Coefficient(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Equilibrium(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x40
struct FCRSimPointConstraint
{
public:
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    int32_t SubjectA() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t SubjectB() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    FVector DataA() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector DataB() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_SubjectA(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_SubjectB(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_DataA(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_DataB(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x78
struct FCRSimPointContainer : public FCRSimContainer
{
public:
    TArray<FRigVMSimPoint> Points() const { return Read<TArray<FRigVMSimPoint>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimLinearSpring> Springs() const { return Read<TArray<FCRSimLinearSpring>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimPointForce> Forces() const { return Read<TArray<FCRSimPointForce>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimSoftCollision> CollisionVolumes() const { return Read<TArray<FCRSimSoftCollision>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimPointConstraint> Constraints() const { return Read<TArray<FCRSimPointConstraint>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigVMSimPoint> PreviousStep() const { return Read<TArray<FRigVMSimPoint>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)

    void SET_Points(const TArray<FRigVMSimPoint>& Value) { Write<TArray<FRigVMSimPoint>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Springs(const TArray<FCRSimLinearSpring>& Value) { Write<TArray<FCRSimLinearSpring>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Forces(const TArray<FCRSimPointForce>& Value) { Write<TArray<FCRSimPointForce>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_CollisionVolumes(const TArray<FCRSimSoftCollision>& Value) { Write<TArray<FCRSimSoftCollision>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_Constraints(const TArray<FCRSimPointConstraint>& Value) { Write<TArray<FCRSimPointConstraint>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_PreviousStep(const TArray<FRigVMSimPoint>& Value) { Write<TArray<FRigVMSimPoint>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x80
struct FCRSimSoftCollision
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x60, Type: StructProperty)
    uint8_t ShapeType() const { return Read<uint8_t>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x1, Type: EnumProperty)
    float MinimumDistance() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    float MaximumDistance() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    uint8_t FalloffType() const { return Read<uint8_t>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x1, Type: EnumProperty)
    float Coefficient() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    bool bInverted() const { return Read<bool>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x1, Type: BoolProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x60, Type: StructProperty)
    void SET_ShapeType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x1, Type: EnumProperty)
    void SET_MinimumDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_MaximumDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_FalloffType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x1, Type: EnumProperty)
    void SET_Coefficient(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_bInverted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FCRSimPointForce
{
public:
    uint8_t ForceType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FVector Vector() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    float Coefficient() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bNormalize() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)

    void SET_ForceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Vector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Coefficient(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_bNormalize(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x2c0
struct FRigModuleReference
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FString ShortName() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    bool bShortNameBasedOnPath() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FString ParentPath() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    FName ParentModuleName() const { return Read<FName>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: NameProperty)
    TMap<FRigElementKey, FRigElementKey> Connections() const { return Read<TMap<FRigElementKey, FRigElementKey>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x50, Type: MapProperty)
    TMap<FString, FName> ConfigValues() const { return Read<TMap<FString, FName>>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x50, Type: MapProperty)
    FControlRigOverrideContainer ConfigOverrides() const { return Read<FControlRigOverrideContainer>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x158, Type: StructProperty)
    TMap<FString, FName> Bindings() const { return Read<TMap<FString, FName>>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x50, Type: MapProperty)
    FName PreviousName() const { return Read<FName>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x4, Type: NameProperty)
    FName PreviousParentName() const { return Read<FName>(uintptr_t(this) + 0x2a4); } // 0x2a4 (Size: 0x4, Type: NameProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ShortName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_bShortNameBasedOnPath(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_ParentPath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_ParentModuleName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: NameProperty)
    void SET_Connections(const TMap<FRigElementKey, FRigElementKey>& Value) { Write<TMap<FRigElementKey, FRigElementKey>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x50, Type: MapProperty)
    void SET_ConfigValues(const TMap<FString, FName>& Value) { Write<TMap<FString, FName>>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x50, Type: MapProperty)
    void SET_ConfigOverrides(const FControlRigOverrideContainer& Value) { Write<FControlRigOverrideContainer>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x158, Type: StructProperty)
    void SET_Bindings(const TMap<FString, FName>& Value) { Write<TMap<FString, FName>>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x50, Type: MapProperty)
    void SET_PreviousName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x4, Type: NameProperty)
    void SET_PreviousParentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2a4, Value); } // 0x2a4 (Size: 0x4, Type: NameProperty)
};

// Size: 0x20
struct FModularRigSingleConnection
{
public:
    FRigElementKey Connector() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FRigElementKey Target() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementKey> Targets() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Connector(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Target(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Targets(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x60
struct FModularRigConnections
{
public:
    TArray<FModularRigSingleConnection> ConnectionList() const { return Read<TArray<FModularRigSingleConnection>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_ConnectionList(const TArray<FModularRigSingleConnection>& Value) { Write<TArray<FModularRigSingleConnection>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x100
struct FModularRigModel
{
public:
    TArray<FRigModuleReference> Modules() const { return Read<TArray<FRigModuleReference>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FModularRigConnections Connections() const { return Read<FModularRigConnections>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    UObject* Controller() const { return Read<UObject*>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    TMap<FName, FRigHierarchyModulePath> PreviousModulePaths() const { return Read<TMap<FName, FRigHierarchyModulePath>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x50, Type: MapProperty)

    void SET_Modules(const TArray<FRigModuleReference>& Value) { Write<TArray<FRigModuleReference>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Connections(const FModularRigConnections& Value) { Write<FModularRigConnections>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_Controller(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x8, Type: ObjectProperty)
    void SET_PreviousModulePaths(const TMap<FName, FRigHierarchyModulePath>& Value) { Write<TMap<FName, FRigHierarchyModulePath>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x50, Type: MapProperty)
};

// Size: 0x38
struct FRigHierarchyModulePath
{
public:
    FString ModulePath() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)

    void SET_ModulePath(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
};

// Size: 0x108
struct FModularRigModuleSettingsForClipboard
{
public:
    FSoftObjectPath ModuleClass() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    TMap<FString, FString> Defaults() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x50, Type: MapProperty)
    TMap<FString, FString> Overrides() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x50, Type: MapProperty)
    TMap<FString, FName> Bindings() const { return Read<TMap<FString, FName>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x50, Type: MapProperty)

    void SET_ModuleClass(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Defaults(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x50, Type: MapProperty)
    void SET_Overrides(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x50, Type: MapProperty)
    void SET_Bindings(const TMap<FString, FName>& Value) { Write<TMap<FString, FName>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x50
struct FModularRigModuleSettingsSetForClipboard
{
public:
    TMap<FModularRigModuleSettingsForClipboard, FName> Settings() const { return Read<TMap<FModularRigModuleSettingsForClipboard, FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_Settings(const TMap<FModularRigModuleSettingsForClipboard, FName>& Value) { Write<TMap<FModularRigModuleSettingsForClipboard, FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x140
struct FConstraintNodeData
{
public:
    FTransform RelativeParent() const { return Read<FTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x60, Type: StructProperty)
    FConstraintOffset ConstraintOffset() const { return Read<FConstraintOffset>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0xc0, Type: StructProperty)
    FName LinkedNode() const { return Read<FName>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: NameProperty)
    TArray<FTransformConstraint> Constraints() const { return Read<TArray<FTransformConstraint>>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x10, Type: ArrayProperty)

    void SET_RelativeParent(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x60, Type: StructProperty)
    void SET_ConstraintOffset(const FConstraintOffset& Value) { Write<FConstraintOffset>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0xc0, Type: StructProperty)
    void SET_LinkedNode(const FName& Value) { Write<FName>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: NameProperty)
    void SET_Constraints(const TArray<FTransformConstraint>& Value) { Write<TArray<FTransformConstraint>>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x88
struct FAnimationHierarchy : public FNodeHierarchyWithUserData
{
public:
    TArray<FConstraintNodeData> UserData() const { return Read<TArray<FConstraintNodeData>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_UserData(const TArray<FConstraintNodeData>& Value) { Write<TArray<FConstraintNodeData>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FRigElement
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    int32_t Index() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x160
struct FRigBone : public FRigElement
{
public:
    FName ParentName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    int32_t ParentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    FTransform InitialTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform GlobalTransform() const { return Read<FTransform>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x60, Type: StructProperty)
    FTransform LocalTransform() const { return Read<FTransform>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x60, Type: StructProperty)
    TArray<int32_t> Dependents() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x1, Type: EnumProperty)

    void SET_ParentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_ParentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_InitialTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_GlobalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x60, Type: StructProperty)
    void SET_LocalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x60, Type: StructProperty)
    void SET_Dependents(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x10, Type: ArrayProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x10
struct FRigBoneHierarchy
{
public:
    TArray<FRigBone> Bones() const { return Read<TArray<FRigBone>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Bones(const TArray<FRigBone>& Value) { Write<TArray<FRigBone>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FRigConnectionRule
{
public:
};

// Size: 0x18
struct FRigAndConnectionRule : public FRigConnectionRule
{
public:
    TArray<FRigConnectionRuleStash> ChildRules() const { return Read<TArray<FRigConnectionRuleStash>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_ChildRules(const TArray<FRigConnectionRuleStash>& Value) { Write<TArray<FRigConnectionRuleStash>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FRigOrConnectionRule : public FRigConnectionRule
{
public:
    TArray<FRigConnectionRuleStash> ChildRules() const { return Read<TArray<FRigConnectionRuleStash>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_ChildRules(const TArray<FRigConnectionRuleStash>& Value) { Write<TArray<FRigConnectionRuleStash>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FRigTypeConnectionRule : public FRigConnectionRule
{
public:
    uint8_t ElementType() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)

    void SET_ElementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x10
struct FRigTagConnectionRule : public FRigConnectionRule
{
public:
    FName Tag() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_Tag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x8
struct FRigChildOfPrimaryConnectionRule : public FRigConnectionRule
{
public:
};

// Size: 0x340
struct FRigControl : public FRigElement
{
public:
    uint8_t ControlType() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    FName DisplayName() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    FName ParentName() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    int32_t ParentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    FName SpaceName() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)
    int32_t SpaceIndex() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)
    FTransform OffsetTransform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    FRigControlValue InitialValue() const { return Read<FRigControlValue>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x84, Type: StructProperty)
    FRigControlValue Value() const { return Read<FRigControlValue>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x84, Type: StructProperty)
    uint8_t PrimaryAxis() const { return Read<uint8_t>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x1, Type: EnumProperty)
    bool bIsCurve() const { return Read<bool>(uintptr_t(this) + 0x199); } // 0x199 (Size: 0x1, Type: BoolProperty)
    bool bAnimatable() const { return Read<bool>(uintptr_t(this) + 0x19a); } // 0x19a (Size: 0x1, Type: BoolProperty)
    bool bLimitTranslation() const { return Read<bool>(uintptr_t(this) + 0x19b); } // 0x19b (Size: 0x1, Type: BoolProperty)
    bool bLimitRotation() const { return Read<bool>(uintptr_t(this) + 0x19c); } // 0x19c (Size: 0x1, Type: BoolProperty)
    bool bLimitScale() const { return Read<bool>(uintptr_t(this) + 0x19d); } // 0x19d (Size: 0x1, Type: BoolProperty)
    bool bDrawLimits() const { return Read<bool>(uintptr_t(this) + 0x19e); } // 0x19e (Size: 0x1, Type: BoolProperty)
    FRigControlValue MinimumValue() const { return Read<FRigControlValue>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x84, Type: StructProperty)
    FRigControlValue MaximumValue() const { return Read<FRigControlValue>(uintptr_t(this) + 0x224); } // 0x224 (Size: 0x84, Type: StructProperty)
    bool bGizmoEnabled() const { return Read<bool>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    bool bGizmoVisible() const { return Read<bool>(uintptr_t(this) + 0x2a9); } // 0x2a9 (Size: 0x1, Type: BoolProperty)
    FName GizmoName() const { return Read<FName>(uintptr_t(this) + 0x2ac); } // 0x2ac (Size: 0x4, Type: NameProperty)
    FTransform GizmoTransform() const { return Read<FTransform>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x60, Type: StructProperty)
    FLinearColor GizmoColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x10, Type: StructProperty)
    TArray<int32_t> Dependents() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x10, Type: ArrayProperty)
    bool bIsTransientControl() const { return Read<bool>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x1, Type: BoolProperty)
    UEnum* ControlEnum() const { return Read<UEnum*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)

    void SET_ControlType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_DisplayName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_ParentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_ParentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_SpaceName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
    void SET_SpaceIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
    void SET_OffsetTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_InitialValue(const FRigControlValue& Value) { Write<FRigControlValue>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x84, Type: StructProperty)
    void SET_Value(const FRigControlValue& Value) { Write<FRigControlValue>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x84, Type: StructProperty)
    void SET_PrimaryAxis(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x1, Type: EnumProperty)
    void SET_bIsCurve(const bool& Value) { Write<bool>(uintptr_t(this) + 0x199, Value); } // 0x199 (Size: 0x1, Type: BoolProperty)
    void SET_bAnimatable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19a, Value); } // 0x19a (Size: 0x1, Type: BoolProperty)
    void SET_bLimitTranslation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19b, Value); } // 0x19b (Size: 0x1, Type: BoolProperty)
    void SET_bLimitRotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19c, Value); } // 0x19c (Size: 0x1, Type: BoolProperty)
    void SET_bLimitScale(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19d, Value); } // 0x19d (Size: 0x1, Type: BoolProperty)
    void SET_bDrawLimits(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19e, Value); } // 0x19e (Size: 0x1, Type: BoolProperty)
    void SET_MinimumValue(const FRigControlValue& Value) { Write<FRigControlValue>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x84, Type: StructProperty)
    void SET_MaximumValue(const FRigControlValue& Value) { Write<FRigControlValue>(uintptr_t(this) + 0x224, Value); } // 0x224 (Size: 0x84, Type: StructProperty)
    void SET_bGizmoEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x1, Type: BoolProperty)
    void SET_bGizmoVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a9, Value); } // 0x2a9 (Size: 0x1, Type: BoolProperty)
    void SET_GizmoName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2ac, Value); } // 0x2ac (Size: 0x4, Type: NameProperty)
    void SET_GizmoTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x60, Type: StructProperty)
    void SET_GizmoColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x10, Type: StructProperty)
    void SET_Dependents(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsTransientControl(const bool& Value) { Write<bool>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x1, Type: BoolProperty)
    void SET_ControlEnum(const UEnum*& Value) { Write<UEnum*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x10
struct FRigControlHierarchy
{
public:
    TArray<FRigControl> Controls() const { return Read<TArray<FRigControl>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Controls(const TArray<FRigControl>& Value) { Write<TArray<FRigControl>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FRigCurve : public FRigElement
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FRigCurveContainer
{
public:
    TArray<FRigCurve> Curves() const { return Read<TArray<FRigCurve>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Curves(const TArray<FRigCurve>& Value) { Write<TArray<FRigCurve>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FCachedRigComponent
{
public:
    FCachedRigElement CachedElement() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    uint16_t Index() const { return Read<uint16_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x2, Type: UInt16Property)

    void SET_CachedElement(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_Index(const uint16_t& Value) { Write<uint16_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x2, Type: UInt16Property)
};

// Size: 0x40
struct FRigBaseComponent
{
public:
};

// Size: 0x40
struct FRigHierarchyContainer
{
public:
    FRigBoneHierarchy BoneHierarchy() const { return Read<FRigBoneHierarchy>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FRigSpaceHierarchy SpaceHierarchy() const { return Read<FRigSpaceHierarchy>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FRigControlHierarchy ControlHierarchy() const { return Read<FRigControlHierarchy>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    FRigCurveContainer CurveContainer() const { return Read<FRigCurveContainer>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)

    void SET_BoneHierarchy(const FRigBoneHierarchy& Value) { Write<FRigBoneHierarchy>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_SpaceHierarchy(const FRigSpaceHierarchy& Value) { Write<FRigSpaceHierarchy>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_ControlHierarchy(const FRigControlHierarchy& Value) { Write<FRigControlHierarchy>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_CurveContainer(const FRigCurveContainer& Value) { Write<FRigCurveContainer>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FRigSpaceHierarchy
{
public:
    TArray<FRigSpace> Spaces() const { return Read<TArray<FRigSpace>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Spaces(const TArray<FRigSpace>& Value) { Write<TArray<FRigSpace>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xe0
struct FRigSpace : public FRigElement
{
public:
    uint8_t SpaceType() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    FName ParentName() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    int32_t ParentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    FTransform InitialTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform LocalTransform() const { return Read<FTransform>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x60, Type: StructProperty)

    void SET_SpaceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_ParentName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_ParentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_InitialTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_LocalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x60, Type: StructProperty)
};

// Size: 0x1
struct FRigHierarchyRef
{
public:
};

// Size: 0x14
struct FRigControlModifiedContext
{
public:
};

// Size: 0xc
struct FRigComponentKey
{
public:
    FRigElementKey ElementKey() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_ElementKey(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x1c
struct FRigHierarchyKey
{
public:
};

// Size: 0x10
struct FRigElementKeyCollection
{
public:
    TArray<FRigElementKey> Keys() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Keys(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FRigEventContext
{
public:
};

// Size: 0x20
struct FRigElementResolveResult
{
public:
    FRigElementKey Key() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    uint8_t State() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    FText Message() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)

    void SET_Key(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_State(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_Message(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
};

// Size: 0x40
struct FModularRigResolveResult
{
public:
    FRigElementKey Connector() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementResolveResult> Matches() const { return Read<TArray<FRigElementResolveResult>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigElementResolveResult> Excluded() const { return Read<TArray<FRigElementResolveResult>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t State() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    FText Message() const { return Read<FText>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: TextProperty)

    void SET_Connector(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Matches(const TArray<FRigElementResolveResult>& Value) { Write<TArray<FRigElementResolveResult>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Excluded(const TArray<FRigElementResolveResult>& Value) { Write<TArray<FRigElementResolveResult>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_State(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_Message(const FText& Value) { Write<FText>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: TextProperty)
};

// Size: 0x10
struct FRigTransformDirtyState
{
public:
};

// Size: 0x20
struct FRigLocalAndGlobalDirtyState
{
public:
    FRigTransformDirtyState Global() const { return Read<FRigTransformDirtyState>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FRigTransformDirtyState Local() const { return Read<FRigTransformDirtyState>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_Global(const FRigTransformDirtyState& Value) { Write<FRigTransformDirtyState>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Local(const FRigTransformDirtyState& Value) { Write<FRigTransformDirtyState>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x40
struct FRigCurrentAndInitialDirtyState
{
public:
    FRigLocalAndGlobalDirtyState Current() const { return Read<FRigLocalAndGlobalDirtyState>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FRigLocalAndGlobalDirtyState Initial() const { return Read<FRigLocalAndGlobalDirtyState>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)

    void SET_Current(const FRigLocalAndGlobalDirtyState& Value) { Write<FRigLocalAndGlobalDirtyState>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_Initial(const FRigLocalAndGlobalDirtyState& Value) { Write<FRigLocalAndGlobalDirtyState>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
};

// Size: 0x10
struct FRigComputedTransform
{
public:
};

// Size: 0x20
struct FRigLocalAndGlobalTransform
{
public:
    FRigComputedTransform Local() const { return Read<FRigComputedTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FRigComputedTransform Global() const { return Read<FRigComputedTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_Local(const FRigComputedTransform& Value) { Write<FRigComputedTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Global(const FRigComputedTransform& Value) { Write<FRigComputedTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x40
struct FRigCurrentAndInitialTransform
{
public:
    FRigLocalAndGlobalTransform Current() const { return Read<FRigLocalAndGlobalTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    FRigLocalAndGlobalTransform Initial() const { return Read<FRigLocalAndGlobalTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)

    void SET_Current(const FRigLocalAndGlobalTransform& Value) { Write<FRigLocalAndGlobalTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_Initial(const FRigLocalAndGlobalTransform& Value) { Write<FRigLocalAndGlobalTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
};

// Size: 0x120
struct FRigSingleParentElement : public FRigTransformElement
{
public:
};

// Size: 0xc
struct FRigElementWeight
{
public:
    float Location() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Rotation() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_Location(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Rotation(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xa0
struct FRigElementParentConstraint
{
public:
};

// Size: 0x128
struct FRigBoneElement : public FRigSingleParentElement
{
public:
    uint8_t BoneType() const { return Read<uint8_t>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x1, Type: EnumProperty)

    void SET_BoneType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x230
struct FRigNullElement : public FRigMultiParentElement
{
public:
};

// Size: 0x68
struct FRigCurveElement : public FRigBaseElement
{
public:
};

// Size: 0x130
struct FRigReferenceElement : public FRigSingleParentElement
{
public:
};

// Size: 0x38
struct FRigConnectorState
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FRigElementKey ResolvedTarget() const { return Read<FRigElementKey>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x8, Type: StructProperty)
    FRigConnectorSettings Settings() const { return Read<FRigConnectorSettings>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x28, Type: StructProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ResolvedTarget(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x8, Type: StructProperty)
    void SET_Settings(const FRigConnectorSettings& Value) { Write<FRigConnectorSettings>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x28, Type: StructProperty)
};

// Size: 0x80
struct FRigConnectorElement : public FRigBaseElement
{
public:
    FRigConnectorSettings Settings() const { return Read<FRigConnectorSettings>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x28, Type: StructProperty)

    void SET_Settings(const FRigConnectorSettings& Value) { Write<FRigConnectorSettings>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x28, Type: StructProperty)
};

// Size: 0x90
struct FRigSocketState
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x8, Type: StructProperty)
    FTransform InitialLocalTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: StructProperty)
    FString Description() const { return Read<FString>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StrProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x8, Type: StructProperty)
    void SET_InitialLocalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: StructProperty)
    void SET_Description(const FString& Value) { Write<FString>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StrProperty)
};

// Size: 0x120
struct FRigSocketElement : public FRigSingleParentElement
{
public:
};

// Size: 0x58
struct FRigHierarchyCopyPasteContentPerElement
{
public:
    FRigElementKey Key() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FString Content() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)
    TArray<FRigElementKeyWithLabel> Parents() const { return Read<TArray<FRigElementKeyWithLabel>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigElementWeight> ParentWeights() const { return Read<TArray<FRigElementWeight>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> Poses() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<bool> DirtyStates() const { return Read<TArray<bool>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)

    void SET_Key(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Content(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
    void SET_Parents(const TArray<FRigElementKeyWithLabel>& Value) { Write<TArray<FRigElementKeyWithLabel>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_ParentWeights(const TArray<FRigElementWeight>& Value) { Write<TArray<FRigElementWeight>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Poses(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_DirtyStates(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FRigHierarchyCopyPasteContent
{
public:
    TArray<FRigHierarchyCopyPasteContentPerElement> Elements() const { return Read<TArray<FRigHierarchyCopyPasteContentPerElement>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<ERigElementType> Types() const { return Read<TArray<ERigElementType>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> Contents() const { return Read<TArray<FString>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> LocalTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> GlobalTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_Elements(const TArray<FRigHierarchyCopyPasteContentPerElement>& Value) { Write<TArray<FRigHierarchyCopyPasteContentPerElement>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Types(const TArray<ERigElementType>& Value) { Write<TArray<ERigElementType>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Contents(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_LocalTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_GlobalTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FRigBaseMetadata
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
};

// Size: 0x20
struct FRigBoolMetadata : public FRigBaseMetadata
{
public:
    bool Value() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)

    void SET_Value(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FRigBoolArrayMetadata : public FRigBaseMetadata
{
public:
    TArray<bool> Value() const { return Read<TArray<bool>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FRigFloatMetadata : public FRigBaseMetadata
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FRigFloatArrayMetadata : public FRigBaseMetadata
{
public:
    TArray<float> Value() const { return Read<TArray<float>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FRigInt32Metadata : public FRigBaseMetadata
{
public:
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)

    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FRigInt32ArrayMetadata : public FRigBaseMetadata
{
public:
    TArray<int32_t> Value() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FRigNameMetadata : public FRigBaseMetadata
{
public:
    FName Value() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)

    void SET_Value(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
};

// Size: 0x28
struct FRigNameArrayMetadata : public FRigBaseMetadata
{
public:
    TArray<FName> Value() const { return Read<TArray<FName>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FRigVectorMetadata : public FRigBaseMetadata
{
public:
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x28
struct FRigVectorArrayMetadata : public FRigBaseMetadata
{
public:
    TArray<FVector> Value() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FRigRotatorMetadata : public FRigBaseMetadata
{
public:
    FRotator Value() const { return Read<FRotator>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x28
struct FRigRotatorArrayMetadata : public FRigBaseMetadata
{
public:
    TArray<FRotator> Value() const { return Read<TArray<FRotator>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<FRotator>& Value) { Write<TArray<FRotator>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FRigQuatMetadata : public FRigBaseMetadata
{
public:
    FQuat Value() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)

    void SET_Value(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
struct FRigQuatArrayMetadata : public FRigBaseMetadata
{
public:
    TArray<FQuat> Value() const { return Read<TArray<FQuat>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<FQuat>& Value) { Write<TArray<FQuat>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x80
struct FRigTransformMetadata : public FRigBaseMetadata
{
public:
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)

    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
};

// Size: 0x28
struct FRigTransformArrayMetadata : public FRigBaseMetadata
{
public:
    TArray<FTransform> Value() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FRigLinearColorMetadata : public FRigBaseMetadata
{
public:
    FLinearColor Value() const { return Read<FLinearColor>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)

    void SET_Value(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
struct FRigLinearColorArrayMetadata : public FRigBaseMetadata
{
public:
    TArray<FLinearColor> Value() const { return Read<TArray<FLinearColor>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<FLinearColor>& Value) { Write<TArray<FLinearColor>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FRigElementKeyMetadata : public FRigBaseMetadata
{
public:
    FRigElementKey Value() const { return Read<FRigElementKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)

    void SET_Value(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
};

// Size: 0x28
struct FRigElementKeyArrayMetadata : public FRigBaseMetadata
{
public:
    TArray<FRigElementKey> Value() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Value(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FRigInfluenceEntryModifier
{
public:
    TArray<FRigElementKey> AffectedList() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_AffectedList(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1
struct FModularRigSettings
{
public:
    bool bAutoResolve() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)

    void SET_bAutoResolve(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
struct FRigModuleDescription
{
public:
    FSoftObjectPath Path() const { return Read<FSoftObjectPath>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FRigModuleSettings Settings() const { return Read<FRigModuleSettings>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x78, Type: StructProperty)

    void SET_Path(const FSoftObjectPath& Value) { Write<FSoftObjectPath>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Settings(const FRigModuleSettings& Value) { Write<FRigModuleSettings>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x78, Type: StructProperty)
};

// Size: 0x20
struct FRigPhysicsSimulationBase
{
public:
};

// Size: 0x10
struct FRigPhysicsSolverID
{
public:
    FGuid Guid() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)

    void SET_Guid(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x14
struct FRigPhysicsSolverDescription
{
public:
    FRigPhysicsSolverID ID() const { return Read<FRigPhysicsSolverID>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)

    void SET_ID(const FRigPhysicsSolverID& Value) { Write<FRigPhysicsSolverID>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
};

// Size: 0x30
struct FAnimNode_ControlRigInputPose : public FAnimNode_Base
{
public:
    FPoseLink InputPose() const { return Read<FPoseLink>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_InputPose(const FPoseLink& Value) { Write<FPoseLink>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x840
struct FControlRigLayerInstanceProxy : public FAnimInstanceProxy
{
public:
};

// Size: 0x8
struct FControlRigSequenceObjectReference
{
public:
    UClass* ControlRigClass() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)

    void SET_ControlRigClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x10
struct FControlRigSequenceObjectReferences
{
public:
    TArray<FControlRigSequenceObjectReference> Array() const { return Read<TArray<FControlRigSequenceObjectReference>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Array(const TArray<FControlRigSequenceObjectReference>& Value) { Write<TArray<FControlRigSequenceObjectReference>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FControlRigSequenceObjectReferenceMap
{
public:
    TArray<FGuid> BindingIds() const { return Read<TArray<FGuid>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FControlRigSequenceObjectReferences> References() const { return Read<TArray<FControlRigSequenceObjectReferences>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_BindingIds(const TArray<FGuid>& Value) { Write<TArray<FGuid>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_References(const TArray<FControlRigSequenceObjectReferences>& Value) { Write<TArray<FControlRigSequenceObjectReferences>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x118
struct FEnumParameterNameAndCurve : public FBaseParameterNameAndValue
{
public:
    FMovieSceneByteChannel ParameterCurve() const { return Read<FMovieSceneByteChannel>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x110, Type: StructProperty)

    void SET_ParameterCurve(const FMovieSceneByteChannel& Value) { Write<FMovieSceneByteChannel>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x110, Type: StructProperty)
};

// Size: 0x110
struct FIntegerParameterNameAndCurve : public FBaseParameterNameAndValue
{
public:
    FMovieSceneIntegerChannel ParameterCurve() const { return Read<FMovieSceneIntegerChannel>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x108, Type: StructProperty)

    void SET_ParameterCurve(const FMovieSceneIntegerChannel& Value) { Write<FMovieSceneIntegerChannel>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x108, Type: StructProperty)
};

// Size: 0x118
struct FSpaceControlNameAndChannel
{
public:
    FName ControlName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FMovieSceneControlRigSpaceChannel SpaceCurve() const { return Read<FMovieSceneControlRigSpaceChannel>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x110, Type: StructProperty)

    void SET_ControlName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_SpaceCurve(const FMovieSceneControlRigSpaceChannel& Value) { Write<FMovieSceneControlRigSpaceChannel>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x110, Type: StructProperty)
};

// Size: 0x110
struct FMovieSceneControlRigSpaceChannel : public FMovieSceneChannel
{
public:
    TArray<FFrameNumber> KeyTimes() const { return Read<TArray<FFrameNumber>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    TArray<FMovieSceneControlRigSpaceBaseKey> KeyValues() const { return Read<TArray<FMovieSceneControlRigSpaceBaseKey>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    FMovieSceneKeyHandleMap KeyHandles() const { return Read<FMovieSceneKeyHandleMap>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x88, Type: StructProperty)

    void SET_KeyTimes(const TArray<FFrameNumber>& Value) { Write<TArray<FFrameNumber>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
    void SET_KeyValues(const TArray<FMovieSceneControlRigSpaceBaseKey>& Value) { Write<TArray<FMovieSceneControlRigSpaceBaseKey>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_KeyHandles(const FMovieSceneKeyHandleMap& Value) { Write<FMovieSceneKeyHandleMap>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x88, Type: StructProperty)
};

// Size: 0xc
struct FMovieSceneControlRigSpaceBaseKey
{
public:
    uint8_t SpaceType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FRigElementKey ControlRigElement() const { return Read<FRigElementKey>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x8, Type: StructProperty)

    void SET_SpaceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ControlRigElement(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x8, Type: StructProperty)
};

// Size: 0x38
struct FChannelMapInfo
{
public:
    int32_t ControlIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    int32_t TotalChannelIndex() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t ChannelIndex() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t ParentControlIndex() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    FName ChannelTypeName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    bool bDoesHaveSpace() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    int32_t SpaceChannelIndex() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    int32_t MaskIndex() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)
    int32_t CategoryIndex() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    TArray<uint32_t> ConstraintsIndex() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_ControlIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_TotalChannelIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_ChannelIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_ParentControlIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_ChannelTypeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_bDoesHaveSpace(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_SpaceChannelIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_MaskIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
    void SET_CategoryIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_ConstraintsIndex(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xc0
struct FMovieSceneControlRigParameterTemplate : public FMovieSceneParameterSectionTemplate
{
public:
    TArray<FEnumParameterNameAndCurve> Enums() const { return Read<TArray<FEnumParameterNameAndCurve>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FIntegerParameterNameAndCurve> Integers() const { return Read<TArray<FIntegerParameterNameAndCurve>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    TArray<FSpaceControlNameAndChannel> Spaces() const { return Read<TArray<FSpaceControlNameAndChannel>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FConstraintAndActiveChannel> Constraints() const { return Read<TArray<FConstraintAndActiveChannel>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)

    void SET_Enums(const TArray<FEnumParameterNameAndCurve>& Value) { Write<TArray<FEnumParameterNameAndCurve>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_Integers(const TArray<FIntegerParameterNameAndCurve>& Value) { Write<TArray<FIntegerParameterNameAndCurve>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_Spaces(const TArray<FSpaceControlNameAndChannel>& Value) { Write<TArray<FSpaceControlNameAndChannel>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    void SET_Constraints(const TArray<FConstraintAndActiveChannel>& Value) { Write<TArray<FConstraintAndActiveChannel>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2
struct FControlRotationOrder
{
public:
    uint8_t RotationOrder() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    bool bOverrideSetting() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)

    void SET_RotationOrder(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_bOverrideSetting(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x50
struct FControlRigSettingsPerPinBool
{
public:
    TMap<bool, FString> Values() const { return Read<TMap<bool, FString>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x50, Type: MapProperty)

    void SET_Values(const TMap<bool, FString>& Value) { Write<TMap<bool, FString>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x50, Type: MapProperty)
};

// Size: 0x220
struct FRigControlCopy
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t ControlType() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    FRigElementKey ParentKey() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FRigControlValue Value() const { return Read<FRigControlValue>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x84, Type: StructProperty)
    FTransform OffsetTransform() const { return Read<FTransform>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x60, Type: StructProperty)
    FTransform ParentTransform() const { return Read<FTransform>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x60, Type: StructProperty)
    FTransform LocalTransform() const { return Read<FTransform>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x60, Type: StructProperty)
    FTransform GlobalTransform() const { return Read<FTransform>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x60, Type: StructProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_ControlType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_ParentKey(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Value(const FRigControlValue& Value) { Write<FRigControlValue>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x84, Type: StructProperty)
    void SET_OffsetTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x60, Type: StructProperty)
    void SET_ParentTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x60, Type: StructProperty)
    void SET_LocalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x60, Type: StructProperty)
    void SET_GlobalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x60, Type: StructProperty)
};

// Size: 0x60
struct FControlRigControlPose
{
public:
    TArray<FRigControlCopy> CopyOfControls() const { return Read<TArray<FRigControlCopy>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_CopyOfControls(const TArray<FRigControlCopy>& Value) { Write<TArray<FRigControlCopy>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FSampleTrackMemoryData
{
public:
    TArray<char> Buffer() const { return Read<TArray<char>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> Names() const { return Read<TArray<FName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FString> ObjectPaths() const { return Read<TArray<FString>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_Buffer(const TArray<char>& Value) { Write<TArray<char>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Names(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_ObjectPaths(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x70
struct FRigDispatchFactory : public FRigVMDispatchFactory
{
public:
};

// Size: 0xa0
struct FRigDispatch_AnimAttributeBase : public FRigDispatchFactory
{
public:
};

// Size: 0xa0
struct FRigDispatch_GetAnimAttribute : public FRigDispatch_AnimAttributeBase
{
public:
};

// Size: 0xa0
struct FRigDispatch_SetAnimAttribute : public FRigDispatch_AnimAttributeBase
{
public:
};

// Size: 0x38
struct FRigUnit_SphereTrace_WorkData
{
public:
    uint32_t Hash() const { return Read<uint32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: UInt32Property)
    bool bHit() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    FVector HitLocation() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector HitNormal() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Hash(const uint32_t& Value) { Write<uint32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: UInt32Property)
    void SET_bHit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET_HitLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_HitNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0xb0
struct FRigUnit_SphereTraceWorld : public FRigUnit
{
public:
    FVector Start() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector End() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ECollisionChannel> Channel() const { return Read<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: ByteProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    bool bHit() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    FVector HitLocation() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FVector HitNormal() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)
    FRigUnit_SphereTrace_WorkData WorkData() const { return Read<FRigUnit_SphereTrace_WorkData>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x38, Type: StructProperty)

    void SET_Start(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_End(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Channel(const TEnumAsByte<ECollisionChannel>& Value) { Write<TEnumAsByte<ECollisionChannel>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: ByteProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_bHit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_HitLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_HitNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
    void SET_WorkData(const FRigUnit_SphereTrace_WorkData& Value) { Write<FRigUnit_SphereTrace_WorkData>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x38, Type: StructProperty)
};

// Size: 0xb0
struct FRigUnit_SphereTraceByTraceChannel : public FRigUnit
{
public:
    FVector Start() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector End() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ETraceTypeQuery> TraceChannel() const { return Read<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: ByteProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    bool bHit() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    FVector HitLocation() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FVector HitNormal() const { return Read<FVector>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)
    FRigUnit_SphereTrace_WorkData WorkData() const { return Read<FRigUnit_SphereTrace_WorkData>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x38, Type: StructProperty)

    void SET_Start(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_End(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_TraceChannel(const TEnumAsByte<ETraceTypeQuery>& Value) { Write<TEnumAsByte<ETraceTypeQuery>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: ByteProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_bHit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_HitLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_HitNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
    void SET_WorkData(const FRigUnit_SphereTrace_WorkData& Value) { Write<FRigUnit_SphereTrace_WorkData>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x38, Type: StructProperty)
};

// Size: 0xb8
struct FRigUnit_SphereTraceByObjectTypes : public FRigUnit
{
public:
    FVector Start() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector End() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes() const { return Read<TArray<TEnumAsByte<EObjectTypeQuery>>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    bool bHit() const { return Read<bool>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x1, Type: BoolProperty)
    FVector HitLocation() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    FVector HitNormal() const { return Read<FVector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    FRigUnit_SphereTrace_WorkData WorkData() const { return Read<FRigUnit_SphereTrace_WorkData>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x38, Type: StructProperty)

    void SET_Start(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_End(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_ObjectTypes(const TArray<TEnumAsByte<EObjectTypeQuery>>& Value) { Write<TArray<TEnumAsByte<EObjectTypeQuery>>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_bHit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x1, Type: BoolProperty)
    void SET_HitLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_HitNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_WorkData(const FRigUnit_SphereTrace_WorkData& Value) { Write<FRigUnit_SphereTrace_WorkData>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x38, Type: StructProperty)
};

// Size: 0x180
struct FRigUnit_Control : public FRigUnit
{
public:
    FEulerTransform Transform() const { return Read<FEulerTransform>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x48, Type: StructProperty)
    FTransform base() const { return Read<FTransform>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x60, Type: StructProperty)
    FTransform InitTransform() const { return Read<FTransform>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x60, Type: StructProperty)
    FTransform Result() const { return Read<FTransform>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x60, Type: StructProperty)
    FTransformFilter Filter() const { return Read<FTransformFilter>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x9, Type: StructProperty)
    bool bIsInitialized() const { return Read<bool>(uintptr_t(this) + 0x179); } // 0x179 (Size: 0x1, Type: BoolProperty)

    void SET_Transform(const FEulerTransform& Value) { Write<FEulerTransform>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x48, Type: StructProperty)
    void SET_base(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x60, Type: StructProperty)
    void SET_InitTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x60, Type: StructProperty)
    void SET_Result(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x60, Type: StructProperty)
    void SET_Filter(const FTransformFilter& Value) { Write<FTransformFilter>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x9, Type: StructProperty)
    void SET_bIsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x179, Value); } // 0x179 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1e0
struct FRigUnit_Control_StaticMesh : public FRigUnit_Control
{
public:
    FTransform MeshTransform() const { return Read<FTransform>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x60, Type: StructProperty)

    void SET_MeshTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x60, Type: StructProperty)
};

// Size: 0x70
struct FRigDispatch_GetUserData : public FRigDispatchFactory
{
public:
};

// Size: 0x48
struct FRigUnit_SetupShapeLibraryFromUserData : public FRigUnitMutable
{
public:
    FString Namespace() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    FString Path() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    FString LibraryName() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    bool LogShapeLibraries() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)

    void SET_Namespace(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_Path(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_LibraryName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_LogShapeLibraries(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FRigUnit_ShapeExists : public FRigUnit
{
public:
    FName ShapeName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    bool Result() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)

    void SET_ShapeName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Result(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
};

// Size: 0x110
struct FRigUnit_DebugBezier : public FRigVMFunction_DebugBaseMutable
{
public:
    FRigVMFourPointBezier Bezier() const { return Read<FRigVMFourPointBezier>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x60, Type: StructProperty)
    float MinimumU() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    float MaximumU() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    int32_t Detail() const { return Read<int32_t>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: IntProperty)
    FName Space() const { return Read<FName>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: NameProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)

    void SET_Bezier(const FRigVMFourPointBezier& Value) { Write<FRigVMFourPointBezier>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x60, Type: StructProperty)
    void SET_MinimumU(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_MaximumU(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_Detail(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: IntProperty)
    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: NameProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x110
struct FRigUnit_DebugBezierItemSpace : public FRigVMFunction_DebugBaseMutable
{
public:
    FRigVMFourPointBezier Bezier() const { return Read<FRigVMFourPointBezier>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x60, Type: StructProperty)
    float MinimumU() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    float MaximumU() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    int32_t Detail() const { return Read<int32_t>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: IntProperty)
    FRigElementKey Space() const { return Read<FRigElementKey>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: StructProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)

    void SET_Bezier(const FRigVMFourPointBezier& Value) { Write<FRigVMFourPointBezier>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x60, Type: StructProperty)
    void SET_MinimumU(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_MaximumU(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_Detail(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: IntProperty)
    void SET_Space(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: StructProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb0
struct FRigUnit_DebugHierarchy : public FRigVMFunction_DebugBase
{
public:
    FRigVMExecutePin ExecutePin() const { return Read<FRigVMExecutePin>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)

    void SET_ExecutePin(const FRigVMExecutePin& Value) { Write<FRigVMExecutePin>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x120
struct FRigUnit_DebugPose : public FRigVMFunction_DebugBase
{
public:
    FRigVMExecutePin ExecutePin() const { return Read<FRigVMExecutePin>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x70, Type: StructProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: FloatProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: BoolProperty)

    void SET_ExecutePin(const FRigVMExecutePin& Value) { Write<FRigVMExecutePin>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x70, Type: StructProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: FloatProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd0
struct FRigUnit_DebugLine : public FRigUnit_DebugBaseMutable
{
public:
    FVector A() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector B() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    FName Space() const { return Read<FName>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: NameProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)

    void SET_A(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_B(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: NameProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xe0
struct FRigUnit_DebugLineItemSpace : public FRigUnit_DebugBaseMutable
{
public:
    FVector A() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector B() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space() const { return Read<FRigElementKey>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x8, Type: StructProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)

    void SET_A(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_B(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x8, Type: StructProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb0
struct FRigUnit_DebugLineStrip : public FRigUnit_DebugBaseMutable
{
public:
    TArray<FVector> Points() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    FName Space() const { return Read<FName>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: NameProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)

    void SET_Points(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: NameProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc0
struct FRigUnit_DebugLineStripItemSpace : public FRigUnit_DebugBaseMutable
{
public:
    TArray<FVector> Points() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space() const { return Read<FRigElementKey>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x8, Type: StructProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x1, Type: BoolProperty)

    void SET_Points(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x8, Type: StructProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x110
struct FRigUnit_DebugRectangle : public FRigUnit_DebugBaseMutable
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    FName Space() const { return Read<FName>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: NameProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: NameProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x110
struct FRigUnit_DebugRectangleItemSpace : public FRigUnit_DebugBaseMutable
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space() const { return Read<FRigElementKey>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x8, Type: StructProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x8, Type: StructProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x120
struct FRigUnit_DebugArc : public FRigUnit_DebugBaseMutable
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float MinimumDegrees() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    float MaximumDegrees() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    int32_t Detail() const { return Read<int32_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: IntProperty)
    FName Space() const { return Read<FName>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: NameProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: BoolProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_MinimumDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_MaximumDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_Detail(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: IntProperty)
    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: NameProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x120
struct FRigUnit_DebugArcItemSpace : public FRigUnit_DebugBaseMutable
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float MinimumDegrees() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    float MaximumDegrees() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    int32_t Detail() const { return Read<int32_t>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: IntProperty)
    FRigElementKey Space() const { return Read<FRigElementKey>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x8, Type: StructProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: BoolProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_MinimumDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_MaximumDegrees(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_Detail(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: IntProperty)
    void SET_Space(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x8, Type: StructProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x100
struct FRigUnit_DebugTransform : public FRigUnit_DebugBase
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: EnumProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    FName Space() const { return Read<FName>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: NameProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: EnumProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: NameProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x110
struct FRigUnit_DebugTransformMutable : public FRigUnit_DebugBaseMutable
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: EnumProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    FName Space() const { return Read<FName>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: NameProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: EnumProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: NameProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x120
struct FRigUnit_DebugTransformMutableItemSpace : public FRigUnit_DebugBaseMutable
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: EnumProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space() const { return Read<FRigElementKey>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x8, Type: StructProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: BoolProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: EnumProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x8, Type: StructProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FRigUnit_DebugTransformArrayMutable_WorkData
{
public:
    TArray<FTransform> DrawTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_DrawTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xd0
struct FRigUnit_DebugTransformArrayMutable : public FRigUnit_DebugBaseMutable
{
public:
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    FName Space() const { return Read<FName>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: NameProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x1, Type: BoolProperty)
    FRigUnit_DebugTransformArrayMutable_WorkData WorkData() const { return Read<FRigUnit_DebugTransformArrayMutable_WorkData>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StructProperty)

    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: NameProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_DebugTransformArrayMutable_WorkData& Value) { Write<FRigUnit_DebugTransformArrayMutable_WorkData>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StructProperty)
};

// Size: 0xd0
struct FRigUnit_DebugTransformArrayMutableItemSpace : public FRigUnit_DebugBaseMutable
{
public:
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ParentIndices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space() const { return Read<FRigElementKey>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x8, Type: StructProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)

    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_ParentIndices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x8, Type: StructProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FRigUnit_StartProfilingTimer : public FRigVMFunction_DebugBaseMutable
{
public:
};

// Size: 0x40
struct FRigUnit_EndProfilingTimer : public FRigVMFunction_DebugBaseMutable
{
public:
    int32_t NumberOfMeasurements() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    FString Prefix() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    float AccumulatedTime() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    int32_t MeasurementsLeft() const { return Read<int32_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: IntProperty)
    bool bIsInitialized() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)

    void SET_NumberOfMeasurements(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_Prefix(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_AccumulatedTime(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_MeasurementsLeft(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: IntProperty)
    void SET_bIsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x48
struct FRigUnit_VisualDebugVector : public FRigUnit_DebugBase
{
public:
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: EnumProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    FName BoneSpace() const { return Read<FName>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: NameProperty)

    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: EnumProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_BoneSpace(const FName& Value) { Write<FName>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: NameProperty)
};

// Size: 0x50
struct FRigUnit_VisualDebugVectorItemSpace : public FRigUnit_DebugBase
{
public:
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: EnumProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x10, Type: StructProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space() const { return Read<FRigElementKey>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x8, Type: StructProperty)

    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: EnumProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x10, Type: StructProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x8, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_VisualDebugQuat : public FRigUnit_DebugBase
{
public:
    FQuat Value() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    FName BoneSpace() const { return Read<FName>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: NameProperty)

    void SET_Value(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_BoneSpace(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: NameProperty)
};

// Size: 0x50
struct FRigUnit_VisualDebugQuatItemSpace : public FRigUnit_DebugBase
{
public:
    FQuat Value() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space() const { return Read<FRigElementKey>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x8, Type: StructProperty)

    void SET_Value(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x8, Type: StructProperty)
};

// Size: 0x80
struct FRigUnit_VisualDebugTransform : public FRigUnit_DebugBase
{
public:
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    FName BoneSpace() const { return Read<FName>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: NameProperty)

    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_BoneSpace(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: NameProperty)
};

// Size: 0x90
struct FRigUnit_VisualDebugTransformItemSpace : public FRigUnit_DebugBase
{
public:
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: FloatProperty)
    FRigElementKey Space() const { return Read<FRigElementKey>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x8, Type: StructProperty)

    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: FloatProperty)
    void SET_Space(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x8, Type: StructProperty)
};

// Size: 0xc0
struct FRigUnit_ConvertTransform : public FRigUnit
{
public:
    FTransform Input() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FEulerTransform Result() const { return Read<FEulerTransform>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x48, Type: StructProperty)

    void SET_Input(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Result(const FEulerTransform& Value) { Write<FEulerTransform>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x48, Type: StructProperty)
};

// Size: 0xb0
struct FRigUnit_ConvertEulerTransform : public FRigUnit
{
public:
    FEulerTransform Input() const { return Read<FEulerTransform>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x48, Type: StructProperty)
    FTransform Result() const { return Read<FTransform>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x60, Type: StructProperty)

    void SET_Input(const FEulerTransform& Value) { Write<FEulerTransform>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x48, Type: StructProperty)
    void SET_Result(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x60, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_ConvertRotation : public FRigUnit
{
public:
    FRotator Input() const { return Read<FRotator>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FQuat Result() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)

    void SET_Input(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Result(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_ConvertVectorRotation : public FRigUnit_ConvertRotation
{
public:
};

// Size: 0x50
struct FRigUnit_ConvertQuaternion : public FRigUnit
{
public:
    FQuat Input() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    FRotator Result() const { return Read<FRotator>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)

    void SET_Input(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_Result(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_ConvertVectorToRotation : public FRigUnit
{
public:
    FVector Input() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FRotator Result() const { return Read<FRotator>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Input(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Result(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_ConvertVectorToQuaternion : public FRigUnit
{
public:
    FVector Input() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FQuat Result() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)

    void SET_Input(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Result(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_ConvertRotationToVector : public FRigUnit
{
public:
    FRotator Input() const { return Read<FRotator>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Result() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Input(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Result(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_ConvertQuaternionToVector : public FRigUnit
{
public:
    FQuat Input() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    FVector Result() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)

    void SET_Input(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_Result(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_ToSwingAndTwist : public FRigUnit
{
public:
    FQuat Input() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    FVector TwistAxis() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FQuat Swing() const { return Read<FQuat>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x20, Type: StructProperty)
    FQuat Twist() const { return Read<FQuat>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x20, Type: StructProperty)

    void SET_Input(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_TwistAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_Swing(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x20, Type: StructProperty)
    void SET_Twist(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x20, Type: StructProperty)
};

// Size: 0x18
struct FRigUnit_BinaryFloatOp : public FRigUnit
{
public:
    float Argument0() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Argument1() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float Result() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_Argument0(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Argument1(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Result(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FRigUnit_Multiply_FloatFloat : public FRigUnit_BinaryFloatOp
{
public:
};

// Size: 0x18
struct FRigUnit_Add_FloatFloat : public FRigUnit_BinaryFloatOp
{
public:
};

// Size: 0x18
struct FRigUnit_Subtract_FloatFloat : public FRigUnit_BinaryFloatOp
{
public:
};

// Size: 0x18
struct FRigUnit_Divide_FloatFloat : public FRigUnit_BinaryFloatOp
{
public:
};

// Size: 0x18
struct FRigUnit_Clamp_Float : public FRigUnit
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Min() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float Max() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float Result() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Min(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Max(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Result(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FRigUnit_MapRange_Float : public FRigUnit
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinIn() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float MaxIn() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float MinOut() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float MaxOut() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float Result() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MinIn(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_MaxIn(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_MinOut(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_MaxOut(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_Result(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x70
struct FRigUnit_BinaryQuaternionOp : public FRigUnit
{
public:
    FQuat Argument0() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    FQuat Argument1() const { return Read<FQuat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)
    FQuat Result() const { return Read<FQuat>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x20, Type: StructProperty)

    void SET_Argument0(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_Argument1(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
    void SET_Result(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x20, Type: StructProperty)
};

// Size: 0x70
struct FRigUnit_MultiplyQuaternion : public FRigUnit_BinaryQuaternionOp
{
public:
};

// Size: 0x50
struct FRigUnit_UnaryQuaternionOp : public FRigUnit
{
public:
    FQuat Argument() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    FQuat Result() const { return Read<FQuat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)

    void SET_Argument(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_Result(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_InverseQuaterion : public FRigUnit_UnaryQuaternionOp
{
public:
};

// Size: 0x50
struct FRigUnit_QuaternionToAxisAndAngle : public FRigUnit
{
public:
    FQuat Argument() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    FVector Axis() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    float Angle() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)

    void SET_Argument(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_Axis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_Angle(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x50
struct FRigUnit_QuaternionFromAxisAndAngle : public FRigUnit
{
public:
    FVector Axis() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    float Angle() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    FQuat Result() const { return Read<FQuat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)

    void SET_Axis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Angle(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_Result(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_QuaternionToAngle : public FRigUnit
{
public:
    FVector Axis() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FQuat Argument() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    float Angle() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)

    void SET_Axis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Argument(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_Angle(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x130
struct FRigUnit_BinaryTransformOp : public FRigUnit
{
public:
    FTransform Argument0() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform Argument1() const { return Read<FTransform>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x60, Type: StructProperty)
    FTransform Result() const { return Read<FTransform>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x60, Type: StructProperty)

    void SET_Argument0(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Argument1(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x60, Type: StructProperty)
    void SET_Result(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x60, Type: StructProperty)
};

// Size: 0x130
struct FRigUnit_MultiplyTransform : public FRigUnit_BinaryTransformOp
{
public:
};

// Size: 0x130
struct FRigUnit_GetRelativeTransform : public FRigUnit_BinaryTransformOp
{
public:
};

// Size: 0x50
struct FRigUnit_BinaryVectorOp : public FRigUnit
{
public:
    FVector Argument0() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Argument1() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector Result() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_Argument0(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Argument1(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Result(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_Multiply_VectorVector : public FRigUnit_BinaryVectorOp
{
public:
};

// Size: 0x50
struct FRigUnit_Add_VectorVector : public FRigUnit_BinaryVectorOp
{
public:
};

// Size: 0x50
struct FRigUnit_Subtract_VectorVector : public FRigUnit_BinaryVectorOp
{
public:
};

// Size: 0x50
struct FRigUnit_Divide_VectorVector : public FRigUnit_BinaryVectorOp
{
public:
};

// Size: 0x40
struct FRigUnit_Distance_VectorVector : public FRigUnit
{
public:
    FVector Argument0() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Argument1() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float Result() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)

    void SET_Argument0(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Argument1(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Result(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x90
struct FAimTarget
{
public:
    float Weight() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FVector AlignVector() const { return Read<FVector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_AlignVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_AimConstraint_WorkData
{
public:
    TArray<FConstraintData> ConstraintData() const { return Read<TArray<FConstraintData>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_ConstraintData(const TArray<FConstraintData>& Value) { Write<TArray<FConstraintData>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x78
struct FRigUnit_AimConstraint : public FRigUnitMutable
{
public:
    FName Joint() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t AimMode() const { return Read<uint8_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t UpMode() const { return Read<uint8_t>(uintptr_t(this) + 0x15); } // 0x15 (Size: 0x1, Type: EnumProperty)
    FVector AimVector() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector UpVector() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    TArray<FAimTarget> AimTargets() const { return Read<TArray<FAimTarget>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FAimTarget> UpTargets() const { return Read<TArray<FAimTarget>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    FRigUnit_AimConstraint_WorkData WorkData() const { return Read<FRigUnit_AimConstraint_WorkData>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)

    void SET_Joint(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_AimMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: EnumProperty)
    void SET_UpMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x15, Value); } // 0x15 (Size: 0x1, Type: EnumProperty)
    void SET_AimVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_UpVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_AimTargets(const TArray<FAimTarget>& Value) { Write<TArray<FAimTarget>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_UpTargets(const TArray<FAimTarget>& Value) { Write<TArray<FAimTarget>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_WorkData(const FRigUnit_AimConstraint_WorkData& Value) { Write<FRigUnit_AimConstraint_WorkData>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
};

// Size: 0x100
struct FRigUnit_ApplyFK : public FRigUnitMutable
{
public:
    FName Joint() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FTransformFilter Filter() const { return Read<FTransformFilter>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x9, Type: StructProperty)
    uint8_t ApplyTransformMode() const { return Read<uint8_t>(uintptr_t(this) + 0x89); } // 0x89 (Size: 0x1, Type: EnumProperty)
    uint8_t ApplyTransformSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x8a); } // 0x8a (Size: 0x1, Type: EnumProperty)
    FTransform BaseTransform() const { return Read<FTransform>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x60, Type: StructProperty)
    FName BaseJoint() const { return Read<FName>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: NameProperty)

    void SET_Joint(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Filter(const FTransformFilter& Value) { Write<FTransformFilter>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x9, Type: StructProperty)
    void SET_ApplyTransformMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x89, Value); } // 0x89 (Size: 0x1, Type: EnumProperty)
    void SET_ApplyTransformSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8a, Value); } // 0x8a (Size: 0x1, Type: EnumProperty)
    void SET_BaseTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x60, Type: StructProperty)
    void SET_BaseJoint(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: NameProperty)
};

// Size: 0x70
struct FBlendTarget
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x60, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x60, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xe0
struct FRigUnit_BlendTransform : public FRigUnit
{
public:
    FTransform Source() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    TArray<FBlendTarget> Targets() const { return Read<TArray<FBlendTarget>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    FTransform Result() const { return Read<FTransform>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x60, Type: StructProperty)

    void SET_Source(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Targets(const TArray<FBlendTarget>& Value) { Write<TArray<FBlendTarget>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_Result(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x60, Type: StructProperty)
};

// Size: 0xf0
struct FRigUnit_GetJointTransform : public FRigUnitMutable
{
public:
    FName Joint() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t TransformSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x15); } // 0x15 (Size: 0x1, Type: EnumProperty)
    FTransform BaseTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FName BaseJoint() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    FTransform Output() const { return Read<FTransform>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x60, Type: StructProperty)

    void SET_Joint(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: EnumProperty)
    void SET_TransformSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x15, Value); } // 0x15 (Size: 0x1, Type: EnumProperty)
    void SET_BaseTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_BaseJoint(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_Output(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x60, Type: StructProperty)
};

// Size: 0x320
struct FRigUnit_TwoBoneIKFK : public FRigUnitMutable
{
public:
    FName StartJoint() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName EndJoint() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    FVector PoleTarget() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    float Spin() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    FTransform EndEffector() const { return Read<FTransform>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x60, Type: StructProperty)
    float IKBlend() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    FTransform StartJointFKTransform() const { return Read<FTransform>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x60, Type: StructProperty)
    FTransform MidJointFKTransform() const { return Read<FTransform>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x60, Type: StructProperty)
    FTransform EndJointFKTransform() const { return Read<FTransform>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x60, Type: StructProperty)
    float PreviousFKIKBlend() const { return Read<float>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x4, Type: FloatProperty)
    FTransform StartJointIKTransform() const { return Read<FTransform>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x60, Type: StructProperty)
    FTransform MidJointIKTransform() const { return Read<FTransform>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x60, Type: StructProperty)
    FTransform EndJointIKTransform() const { return Read<FTransform>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x60, Type: StructProperty)
    int32_t StartJointIndex() const { return Read<int32_t>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x4, Type: IntProperty)
    int32_t MidJointIndex() const { return Read<int32_t>(uintptr_t(this) + 0x304); } // 0x304 (Size: 0x4, Type: IntProperty)
    int32_t EndJointIndex() const { return Read<int32_t>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x4, Type: IntProperty)
    float UpperLimbLength() const { return Read<float>(uintptr_t(this) + 0x30c); } // 0x30c (Size: 0x4, Type: FloatProperty)
    float LowerLimbLength() const { return Read<float>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x4, Type: FloatProperty)
    bool bIsInitialized() const { return Read<bool>(uintptr_t(this) + 0x314); } // 0x314 (Size: 0x1, Type: BoolProperty)

    void SET_StartJoint(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_EndJoint(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_PoleTarget(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Spin(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_EndEffector(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x60, Type: StructProperty)
    void SET_IKBlend(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_StartJointFKTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x60, Type: StructProperty)
    void SET_MidJointFKTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x60, Type: StructProperty)
    void SET_EndJointFKTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x60, Type: StructProperty)
    void SET_PreviousFKIKBlend(const float& Value) { Write<float>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x4, Type: FloatProperty)
    void SET_StartJointIKTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x60, Type: StructProperty)
    void SET_MidJointIKTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x60, Type: StructProperty)
    void SET_EndJointIKTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x60, Type: StructProperty)
    void SET_StartJointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x4, Type: IntProperty)
    void SET_MidJointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x304, Value); } // 0x304 (Size: 0x4, Type: IntProperty)
    void SET_EndJointIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x4, Type: IntProperty)
    void SET_UpperLimbLength(const float& Value) { Write<float>(uintptr_t(this) + 0x30c, Value); } // 0x30c (Size: 0x4, Type: FloatProperty)
    void SET_LowerLimbLength(const float& Value) { Write<float>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x4, Type: FloatProperty)
    void SET_bIsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x314, Value); } // 0x314 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
struct FRigUnit_DrawContainerGetInstruction : public FRigUnit
{
public:
    FName InstructionName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x10, Type: StructProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)

    void SET_InstructionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x10, Type: StructProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_DrawContainerSetColor : public FRigUnitMutable
{
public:
    FName InstructionName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)

    void SET_InstructionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
};

// Size: 0x18
struct FRigUnit_DrawContainerSetThickness : public FRigUnitMutable
{
public:
    FName InstructionName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    float Thickness() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)

    void SET_InstructionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Thickness(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x80
struct FRigUnit_DrawContainerSetTransform : public FRigUnitMutable
{
public:
    FName InstructionName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)

    void SET_InstructionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_BeginExecution : public FRigUnit
{
public:
    FRigVMExecutePin ExecutePin() const { return Read<FRigVMExecutePin>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_ExecutePin(const FRigVMExecutePin& Value) { Write<FRigVMExecutePin>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_PreBeginExecution : public FRigUnit
{
public:
    FRigVMExecutePin ExecutePin() const { return Read<FRigVMExecutePin>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_ExecutePin(const FRigVMExecutePin& Value) { Write<FRigVMExecutePin>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_PostBeginExecution : public FRigUnit
{
public:
    FRigVMExecutePin ExecutePin() const { return Read<FRigVMExecutePin>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_ExecutePin(const FRigVMExecutePin& Value) { Write<FRigVMExecutePin>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x8
struct FRigUnit_CollectionBase : public FRigUnit
{
public:
};

// Size: 0x10
struct FRigUnit_CollectionBaseMutable : public FRigUnitMutable
{
public:
};

// Size: 0x30
struct FRigUnit_CollectionChain : public FRigUnit_CollectionBase
{
public:
    FRigElementKey FirstItem() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey LastItem() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool Reverse() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)

    void SET_FirstItem(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_LastItem(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Reverse(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_CollectionChainArray : public FRigUnit_CollectionBase
{
public:
    FRigElementKey FirstItem() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey LastItem() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool Reverse() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_FirstItem(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_LastItem(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Reverse(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FRigUnit_CollectionNameSearch : public FRigUnit_CollectionBase
{
public:
    FName PartialName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t TypeToSearch() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)

    void SET_PartialName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_TypeToSearch(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
};

// Size: 0x20
struct FRigUnit_CollectionNameSearchArray : public FRigUnit_CollectionBase
{
public:
    FName PartialName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t TypeToSearch() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_PartialName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_TypeToSearch(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FRigUnit_CollectionChildren : public FRigUnit_CollectionBase
{
public:
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeParent() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bRecursive() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t TypeToSearch() const { return Read<uint8_t>(uintptr_t(this) + 0x12); } // 0x12 (Size: 0x1, Type: EnumProperty)
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)

    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bIncludeParent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bRecursive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_TypeToSearch(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x12, Value); } // 0x12 (Size: 0x1, Type: EnumProperty)
    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_CollectionChildrenArray : public FRigUnit_CollectionBase
{
public:
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeParent() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bRecursive() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bDefaultChildren() const { return Read<bool>(uintptr_t(this) + 0x12); } // 0x12 (Size: 0x1, Type: BoolProperty)
    uint8_t TypeToSearch() const { return Read<uint8_t>(uintptr_t(this) + 0x13); } // 0x13 (Size: 0x1, Type: EnumProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bIncludeParent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bRecursive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_bDefaultChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x12, Value); } // 0x12 (Size: 0x1, Type: BoolProperty)
    void SET_TypeToSearch(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x13, Value); } // 0x13 (Size: 0x1, Type: EnumProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FRigUnit_CollectionGetAll : public FRigUnit_CollectionBase
{
public:
    uint8_t TypeToSearch() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_TypeToSearch(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FRigUnit_CollectionReplaceItems : public FRigUnit_CollectionBase
{
public:
    FRigElementKeyCollection Items() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FName Old() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    FName New() const { return Read<FName>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: NameProperty)
    bool RemoveInvalidItems() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bAllowDuplicates() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)

    void SET_Items(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_Old(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_New(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: NameProperty)
    void SET_RemoveInvalidItems(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowDuplicates(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_CollectionReplaceItemsArray : public FRigUnit_CollectionBase
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    FName Old() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    FName New() const { return Read<FName>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: NameProperty)
    bool RemoveInvalidItems() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bAllowDuplicates() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    TArray<FRigElementKey> Result() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Old(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_New(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: NameProperty)
    void SET_RemoveInvalidItems(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowDuplicates(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_Result(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FRigUnit_CollectionItems : public FRigUnit_CollectionBase
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    bool bAllowDuplicates() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_bAllowDuplicates(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_CollectionGetItems : public FRigUnit_CollectionBase
{
public:
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FRigUnit_CollectionGetParentIndices : public FRigUnit_CollectionBase
{
public:
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    TArray<int32_t> ParentIndices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_ParentIndices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FRigUnit_CollectionGetParentIndicesItemArray : public FRigUnit_CollectionBase
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ParentIndices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_ParentIndices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FRigUnit_CollectionUnion : public FRigUnit_CollectionBase
{
public:
    FRigElementKeyCollection A() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FRigElementKeyCollection B() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    bool bAllowDuplicates() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)

    void SET_A(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_B(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_bAllowDuplicates(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_CollectionIntersection : public FRigUnit_CollectionBase
{
public:
    FRigElementKeyCollection A() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FRigElementKeyCollection B() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)

    void SET_A(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_B(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_CollectionDifference : public FRigUnit_CollectionBase
{
public:
    FRigElementKeyCollection A() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FRigElementKeyCollection B() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)

    void SET_A(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_B(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_CollectionReverse : public FRigUnit_CollectionBase
{
public:
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FRigElementKeyCollection Reversed() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)

    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_Reversed(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
};

// Size: 0x20
struct FRigUnit_CollectionCount : public FRigUnit_CollectionBase
{
public:
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    int32_t Count() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)

    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_Count(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FRigUnit_CollectionItemAtIndex : public FRigUnit_CollectionBase
{
public:
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    int32_t Index() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x8, Type: StructProperty)

    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x8, Type: StructProperty)
};

// Size: 0x230
struct FRigUnit_CollectionLoop : public FRigUnit_CollectionBaseMutable
{
public:
    FName BlockToRun() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: StructProperty)
    int32_t Index() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    int32_t Count() const { return Read<int32_t>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: IntProperty)
    float Ratio() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    FControlRigExecuteContext Completed() const { return Read<FControlRigExecuteContext>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1f0, Type: StructProperty)

    void SET_BlockToRun(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: StructProperty)
    void SET_Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_Count(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: IntProperty)
    void SET_Ratio(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_Completed(const FControlRigExecuteContext& Value) { Write<FControlRigExecuteContext>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1f0, Type: StructProperty)
};

// Size: 0x1f0
struct FControlRigExecuteContext : public FRigVMExecuteContext
{
public:
};

// Size: 0x30
struct FRigUnit_CollectionAddItem : public FRigUnit_CollectionBase
{
public:
    FRigElementKeyCollection Collection() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)
    FRigElementKeyCollection Result() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)

    void SET_Collection(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
    void SET_Result(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
};

// Size: 0x8
struct FRigUnit_DynamicHierarchyBase : public FRigUnit
{
public:
};

// Size: 0x10
struct FRigUnit_DynamicHierarchyBaseMutable : public FRigUnitMutable
{
public:
};

// Size: 0x28
struct FRigUnit_AddParent : public FRigUnit_DynamicHierarchyBaseMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)
    FName DisplayLabel() const { return Read<FName>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: NameProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
    void SET_DisplayLabel(const FName& Value) { Write<FName>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: NameProperty)
};

// Size: 0x20
struct FRigUnit_SetDefaultParent : public FRigUnit_DynamicHierarchyBaseMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_AddAvailableSpaces : public FRigUnit_DynamicHierarchyBaseMutable
{
public:
    FRigElementKey Control() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementKeyWithLabel> Spaces() const { return Read<TArray<FRigElementKeyWithLabel>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Control(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Spaces(const TArray<FRigElementKeyWithLabel>& Value) { Write<TArray<FRigElementKeyWithLabel>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FRigUnit_SetChannelHosts : public FRigUnit_DynamicHierarchyBaseMutable
{
public:
    FRigElementKey Channel() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementKey> Hosts() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Channel(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Hosts(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FRigUnit_SwitchParent : public FRigUnit_DynamicHierarchyBaseMutable
{
public:
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x8, Type: StructProperty)
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x8, Type: StructProperty)
    bool bMaintainGlobal() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)

    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x8, Type: StructProperty)
    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x8, Type: StructProperty)
    void SET_bMaintainGlobal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FRigUnit_HierarchyGetParentWeights : public FRigUnit_DynamicHierarchyBase
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementWeight> Weights() const { return Read<TArray<FRigElementWeight>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FRigElementKeyCollection Parents() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Weights(const TArray<FRigElementWeight>& Value) { Write<TArray<FRigElementWeight>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Parents(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_HierarchyGetParentWeightsArray : public FRigUnit_DynamicHierarchyBase
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementWeight> Weights() const { return Read<TArray<FRigElementWeight>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigElementKey> Parents() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Weights(const TArray<FRigElementWeight>& Value) { Write<TArray<FRigElementWeight>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Parents(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FRigUnit_HierarchySetParentWeights : public FRigUnit_DynamicHierarchyBaseMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementWeight> Weights() const { return Read<TArray<FRigElementWeight>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Weights(const TArray<FRigElementWeight>& Value) { Write<TArray<FRigElementWeight>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FRigUnit_HierarchyReset : public FRigUnit_DynamicHierarchyBaseMutable
{
public:
};

// Size: 0x28
struct FRigUnit_HierarchyImportFromSkeleton : public FRigUnit_DynamicHierarchyBaseMutable
{
public:
    FName Namespace() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    bool bIncludeCurves() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    bool bIncludeMeshSockets() const { return Read<bool>(uintptr_t(this) + 0x15); } // 0x15 (Size: 0x1, Type: BoolProperty)
    bool bIncludeVirtualBones() const { return Read<bool>(uintptr_t(this) + 0x16); } // 0x16 (Size: 0x1, Type: BoolProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)

    void SET_Namespace(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_bIncludeCurves(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_bIncludeMeshSockets(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15, Value); } // 0x15 (Size: 0x1, Type: BoolProperty)
    void SET_bIncludeVirtualBones(const bool& Value) { Write<bool>(uintptr_t(this) + 0x16, Value); } // 0x16 (Size: 0x1, Type: BoolProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x20
struct FRigUnit_HierarchyRemoveElement : public FRigUnit_DynamicHierarchyBaseMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool bSuccess() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_bSuccess(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FRigUnit_HierarchyAddElement : public FRigUnit_DynamicHierarchyBaseMutable
{
public:
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x8, Type: StructProperty)

    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x8, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_HierarchyAddBone : public FRigUnit_HierarchyAddElement
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: EnumProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xa0
struct FRigUnit_HierarchyAddNull : public FRigUnit_HierarchyAddElement
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: EnumProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x10
struct FRigUnit_HierarchyAddControl_Settings
{
public:
    FName DisplayName() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_DisplayName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x80
struct FRigUnit_HierarchyAddControl_ShapeSettings
{
public:
    bool bVisible() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)

    void SET_bVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
};

// Size: 0x20
struct FRigUnit_HierarchyAddControl_ProxySettings
{
public:
    bool bIsProxy() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    TArray<FRigElementKey> DrivenControls() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t ShapeVisibility() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)

    void SET_bIsProxy(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_DrivenControls(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_ShapeVisibility(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x10
struct FRigUnit_HierarchyAddControlFloat_LimitSettings
{
public:
    FRigControlLimitEnabled Limit() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: StructProperty)
    float MinValue() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MaxValue() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bDrawLimits() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)

    void SET_Limit(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: StructProperty)
    void SET_MinValue(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MaxValue(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_bDrawLimits(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd0
struct FRigUnit_HierarchyAddControlFloat_Settings : public FRigUnit_HierarchyAddControl_Settings
{
public:
    uint8_t PrimaryAxis() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bIsScale() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    FRigUnit_HierarchyAddControlFloat_LimitSettings Limits() const { return Read<FRigUnit_HierarchyAddControlFloat_LimitSettings>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Shape() const { return Read<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x80, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ProxySettings Proxy() const { return Read<FRigUnit_HierarchyAddControl_ProxySettings>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x20, Type: StructProperty)

    void SET_PrimaryAxis(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_bIsScale(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_Limits(const FRigUnit_HierarchyAddControlFloat_LimitSettings& Value) { Write<FRigUnit_HierarchyAddControlFloat_LimitSettings>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
    void SET_Shape(const FRigUnit_HierarchyAddControl_ShapeSettings& Value) { Write<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x80, Type: StructProperty)
    void SET_Proxy(const FRigUnit_HierarchyAddControl_ProxySettings& Value) { Write<FRigUnit_HierarchyAddControl_ProxySettings>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x20, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_HierarchyAddControlElement : public FRigUnit_HierarchyAddElement
{
public:
    FTransform OffsetTransform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    uint8_t OffsetSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: EnumProperty)

    void SET_OffsetTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_OffsetSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x170
struct FRigUnit_HierarchyAddControlFloat : public FRigUnit_HierarchyAddControlElement
{
public:
    float InitialValue() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    FRigUnit_HierarchyAddControlFloat_Settings Settings() const { return Read<FRigUnit_HierarchyAddControlFloat_Settings>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0xd0, Type: StructProperty)

    void SET_InitialValue(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_Settings(const FRigUnit_HierarchyAddControlFloat_Settings& Value) { Write<FRigUnit_HierarchyAddControlFloat_Settings>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0xd0, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_HierarchyAddControlInteger_LimitSettings
{
public:
    FRigControlLimitEnabled Limit() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: StructProperty)
    int32_t MinValue() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t MaxValue() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    bool bDrawLimits() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)

    void SET_Limit(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: StructProperty)
    void SET_MinValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_MaxValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_bDrawLimits(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd0
struct FRigUnit_HierarchyAddControlInteger_Settings : public FRigUnit_HierarchyAddControl_Settings
{
public:
    uint8_t PrimaryAxis() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    UEnum* ControlEnum() const { return Read<UEnum*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    FRigUnit_HierarchyAddControlInteger_LimitSettings Limits() const { return Read<FRigUnit_HierarchyAddControlInteger_LimitSettings>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Shape() const { return Read<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x80, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ProxySettings Proxy() const { return Read<FRigUnit_HierarchyAddControl_ProxySettings>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x20, Type: StructProperty)

    void SET_PrimaryAxis(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_ControlEnum(const UEnum*& Value) { Write<UEnum*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET_Limits(const FRigUnit_HierarchyAddControlInteger_LimitSettings& Value) { Write<FRigUnit_HierarchyAddControlInteger_LimitSettings>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_Shape(const FRigUnit_HierarchyAddControl_ShapeSettings& Value) { Write<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x80, Type: StructProperty)
    void SET_Proxy(const FRigUnit_HierarchyAddControl_ProxySettings& Value) { Write<FRigUnit_HierarchyAddControl_ProxySettings>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x170
struct FRigUnit_HierarchyAddControlInteger : public FRigUnit_HierarchyAddControlElement
{
public:
    int32_t InitialValue() const { return Read<int32_t>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: IntProperty)
    FRigUnit_HierarchyAddControlInteger_Settings Settings() const { return Read<FRigUnit_HierarchyAddControlInteger_Settings>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0xd0, Type: StructProperty)

    void SET_InitialValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: IntProperty)
    void SET_Settings(const FRigUnit_HierarchyAddControlInteger_Settings& Value) { Write<FRigUnit_HierarchyAddControlInteger_Settings>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0xd0, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_HierarchyAddControlVector2D_LimitSettings
{
public:
    FRigControlLimitEnabled LimitX() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitY() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: StructProperty)
    FVector2D MinValue() const { return Read<FVector2D>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FVector2D MaxValue() const { return Read<FVector2D>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    bool bDrawLimits() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_LimitX(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: StructProperty)
    void SET_LimitY(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: StructProperty)
    void SET_MinValue(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_MaxValue(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_bDrawLimits(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x100
struct FRigUnit_HierarchyAddControlVector2D_Settings : public FRigUnit_HierarchyAddControl_Settings
{
public:
    uint8_t PrimaryAxis() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    FRigUnit_HierarchyAddControlVector2D_LimitSettings Limits() const { return Read<FRigUnit_HierarchyAddControlVector2D_LimitSettings>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x30, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Shape() const { return Read<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x80, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ProxySettings Proxy() const { return Read<FRigUnit_HierarchyAddControl_ProxySettings>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: StructProperty)
    TArray<ERigControlTransformChannel> FilteredChannels() const { return Read<TArray<ERigControlTransformChannel>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)

    void SET_PrimaryAxis(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_Limits(const FRigUnit_HierarchyAddControlVector2D_LimitSettings& Value) { Write<FRigUnit_HierarchyAddControlVector2D_LimitSettings>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x30, Type: StructProperty)
    void SET_Shape(const FRigUnit_HierarchyAddControl_ShapeSettings& Value) { Write<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x80, Type: StructProperty)
    void SET_Proxy(const FRigUnit_HierarchyAddControl_ProxySettings& Value) { Write<FRigUnit_HierarchyAddControl_ProxySettings>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: StructProperty)
    void SET_FilteredChannels(const TArray<ERigControlTransformChannel>& Value) { Write<TArray<ERigControlTransformChannel>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1b0
struct FRigUnit_HierarchyAddControlVector2D : public FRigUnit_HierarchyAddControlElement
{
public:
    FVector2D InitialValue() const { return Read<FVector2D>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StructProperty)
    FRigUnit_HierarchyAddControlVector2D_Settings Settings() const { return Read<FRigUnit_HierarchyAddControlVector2D_Settings>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x100, Type: StructProperty)

    void SET_InitialValue(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StructProperty)
    void SET_Settings(const FRigUnit_HierarchyAddControlVector2D_Settings& Value) { Write<FRigUnit_HierarchyAddControlVector2D_Settings>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x100, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_HierarchyAddControlVector_LimitSettings
{
public:
    FRigControlLimitEnabled LimitX() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitY() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitZ() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x2, Type: StructProperty)
    FVector MinValue() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector MaxValue() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    bool bDrawLimits() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)

    void SET_LimitX(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: StructProperty)
    void SET_LimitY(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: StructProperty)
    void SET_LimitZ(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x2, Type: StructProperty)
    void SET_MinValue(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_MaxValue(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_bDrawLimits(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x110
struct FRigUnit_HierarchyAddControlVector_Settings : public FRigUnit_HierarchyAddControl_Settings
{
public:
    uint8_t InitialSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bIsPosition() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    FRigUnit_HierarchyAddControlVector_LimitSettings Limits() const { return Read<FRigUnit_HierarchyAddControlVector_LimitSettings>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x40, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Shape() const { return Read<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x80, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ProxySettings Proxy() const { return Read<FRigUnit_HierarchyAddControl_ProxySettings>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x20, Type: StructProperty)
    TArray<ERigControlTransformChannel> FilteredChannels() const { return Read<TArray<ERigControlTransformChannel>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)

    void SET_InitialSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_bIsPosition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_Limits(const FRigUnit_HierarchyAddControlVector_LimitSettings& Value) { Write<FRigUnit_HierarchyAddControlVector_LimitSettings>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x40, Type: StructProperty)
    void SET_Shape(const FRigUnit_HierarchyAddControl_ShapeSettings& Value) { Write<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x80, Type: StructProperty)
    void SET_Proxy(const FRigUnit_HierarchyAddControl_ProxySettings& Value) { Write<FRigUnit_HierarchyAddControl_ProxySettings>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x20, Type: StructProperty)
    void SET_FilteredChannels(const TArray<ERigControlTransformChannel>& Value) { Write<TArray<ERigControlTransformChannel>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1c0
struct FRigUnit_HierarchyAddControlVector : public FRigUnit_HierarchyAddControlElement
{
public:
    FVector InitialValue() const { return Read<FVector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x18, Type: StructProperty)
    FRigUnit_HierarchyAddControlVector_Settings Settings() const { return Read<FRigUnit_HierarchyAddControlVector_Settings>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x110, Type: StructProperty)

    void SET_InitialValue(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x18, Type: StructProperty)
    void SET_Settings(const FRigUnit_HierarchyAddControlVector_Settings& Value) { Write<FRigUnit_HierarchyAddControlVector_Settings>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x110, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_HierarchyAddControlRotator_LimitSettings
{
public:
    FRigControlLimitEnabled LimitPitch() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitYaw() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitRoll() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x2, Type: StructProperty)
    FRotator MinValue() const { return Read<FRotator>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FRotator MaxValue() const { return Read<FRotator>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    bool bDrawLimits() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)

    void SET_LimitPitch(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: StructProperty)
    void SET_LimitYaw(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: StructProperty)
    void SET_LimitRoll(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x2, Type: StructProperty)
    void SET_MinValue(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_MaxValue(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_bDrawLimits(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x120
struct FRigUnit_HierarchyAddControlRotator_Settings : public FRigUnit_HierarchyAddControl_Settings
{
public:
    uint8_t InitialSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    FRigUnit_HierarchyAddControlRotator_LimitSettings Limits() const { return Read<FRigUnit_HierarchyAddControlRotator_LimitSettings>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x40, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Shape() const { return Read<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x80, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ProxySettings Proxy() const { return Read<FRigUnit_HierarchyAddControl_ProxySettings>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x20, Type: StructProperty)
    TArray<ERigControlTransformChannel> FilteredChannels() const { return Read<TArray<ERigControlTransformChannel>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    bool bUsePreferredRotationOrder() const { return Read<bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: BoolProperty)
    uint8_t PreferredRotationOrder() const { return Read<uint8_t>(uintptr_t(this) + 0x111); } // 0x111 (Size: 0x1, Type: EnumProperty)

    void SET_InitialSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_Limits(const FRigUnit_HierarchyAddControlRotator_LimitSettings& Value) { Write<FRigUnit_HierarchyAddControlRotator_LimitSettings>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x40, Type: StructProperty)
    void SET_Shape(const FRigUnit_HierarchyAddControl_ShapeSettings& Value) { Write<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x80, Type: StructProperty)
    void SET_Proxy(const FRigUnit_HierarchyAddControl_ProxySettings& Value) { Write<FRigUnit_HierarchyAddControl_ProxySettings>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x20, Type: StructProperty)
    void SET_FilteredChannels(const TArray<ERigControlTransformChannel>& Value) { Write<TArray<ERigControlTransformChannel>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: ArrayProperty)
    void SET_bUsePreferredRotationOrder(const bool& Value) { Write<bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: BoolProperty)
    void SET_PreferredRotationOrder(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x111, Value); } // 0x111 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x1d0
struct FRigUnit_HierarchyAddControlRotator : public FRigUnit_HierarchyAddControlElement
{
public:
    FRotator InitialValue() const { return Read<FRotator>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x18, Type: StructProperty)
    FRigUnit_HierarchyAddControlRotator_Settings Settings() const { return Read<FRigUnit_HierarchyAddControlRotator_Settings>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x120, Type: StructProperty)

    void SET_InitialValue(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x18, Type: StructProperty)
    void SET_Settings(const FRigUnit_HierarchyAddControlRotator_Settings& Value) { Write<FRigUnit_HierarchyAddControlRotator_Settings>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x120, Type: StructProperty)
};

// Size: 0xb0
struct FRigUnit_HierarchyAddControlTransform_LimitSettings
{
public:
    FRigControlLimitEnabled LimitTranslationX() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitTranslationY() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitTranslationZ() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitPitch() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x6); } // 0x6 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitYaw() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitRoll() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0xa); } // 0xa (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitScaleX() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitScaleY() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0xe); } // 0xe (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled LimitScaleZ() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x2, Type: StructProperty)
    FEulerTransform MinValue() const { return Read<FEulerTransform>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x48, Type: StructProperty)
    FEulerTransform MaxValue() const { return Read<FEulerTransform>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x48, Type: StructProperty)
    bool bDrawLimits() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)

    void SET_LimitTranslationX(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: StructProperty)
    void SET_LimitTranslationY(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: StructProperty)
    void SET_LimitTranslationZ(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x2, Type: StructProperty)
    void SET_LimitPitch(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x6, Value); } // 0x6 (Size: 0x2, Type: StructProperty)
    void SET_LimitYaw(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x2, Type: StructProperty)
    void SET_LimitRoll(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0xa, Value); } // 0xa (Size: 0x2, Type: StructProperty)
    void SET_LimitScaleX(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x2, Type: StructProperty)
    void SET_LimitScaleY(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0xe, Value); } // 0xe (Size: 0x2, Type: StructProperty)
    void SET_LimitScaleZ(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x2, Type: StructProperty)
    void SET_MinValue(const FEulerTransform& Value) { Write<FEulerTransform>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x48, Type: StructProperty)
    void SET_MaxValue(const FEulerTransform& Value) { Write<FEulerTransform>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x48, Type: StructProperty)
    void SET_bDrawLimits(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x180
struct FRigUnit_HierarchyAddControlTransform_Settings : public FRigUnit_HierarchyAddControl_Settings
{
public:
    uint8_t InitialSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bUsePreferredRotationOrder() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    uint8_t PreferredRotationOrder() const { return Read<uint8_t>(uintptr_t(this) + 0x12); } // 0x12 (Size: 0x1, Type: EnumProperty)
    FRigUnit_HierarchyAddControlTransform_LimitSettings Limits() const { return Read<FRigUnit_HierarchyAddControlTransform_LimitSettings>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0xb0, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Shape() const { return Read<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x80, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ProxySettings Proxy() const { return Read<FRigUnit_HierarchyAddControl_ProxySettings>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x20, Type: StructProperty)
    TArray<ERigControlTransformChannel> FilteredChannels() const { return Read<TArray<ERigControlTransformChannel>>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x10, Type: ArrayProperty)

    void SET_InitialSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_bUsePreferredRotationOrder(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_PreferredRotationOrder(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x12, Value); } // 0x12 (Size: 0x1, Type: EnumProperty)
    void SET_Limits(const FRigUnit_HierarchyAddControlTransform_LimitSettings& Value) { Write<FRigUnit_HierarchyAddControlTransform_LimitSettings>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0xb0, Type: StructProperty)
    void SET_Shape(const FRigUnit_HierarchyAddControl_ShapeSettings& Value) { Write<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x80, Type: StructProperty)
    void SET_Proxy(const FRigUnit_HierarchyAddControl_ProxySettings& Value) { Write<FRigUnit_HierarchyAddControl_ProxySettings>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x20, Type: StructProperty)
    void SET_FilteredChannels(const TArray<ERigControlTransformChannel>& Value) { Write<TArray<ERigControlTransformChannel>>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x280
struct FRigUnit_HierarchyAddControlTransform : public FRigUnit_HierarchyAddControlElement
{
public:
    FTransform InitialValue() const { return Read<FTransform>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x60, Type: StructProperty)
    FRigUnit_HierarchyAddControlTransform_Settings Settings() const { return Read<FRigUnit_HierarchyAddControlTransform_Settings>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x180, Type: StructProperty)

    void SET_InitialValue(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x60, Type: StructProperty)
    void SET_Settings(const FRigUnit_HierarchyAddControlTransform_Settings& Value) { Write<FRigUnit_HierarchyAddControlTransform_Settings>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x180, Type: StructProperty)
};

// Size: 0x1
struct FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings
{
public:
};

// Size: 0x30
struct FRigUnit_HierarchyAddAnimationChannelBool : public FRigUnit_HierarchyAddElement
{
public:
    bool InitialValue() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    bool MinimumValue() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)
    bool MaximumValue() const { return Read<bool>(uintptr_t(this) + 0x2a); } // 0x2a (Size: 0x1, Type: BoolProperty)
    FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings LimitsEnabled() const { return Read<FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings>(uintptr_t(this) + 0x2b); } // 0x2b (Size: 0x1, Type: StructProperty)

    void SET_InitialValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_MinimumValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
    void SET_MaximumValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2a, Value); } // 0x2a (Size: 0x1, Type: BoolProperty)
    void SET_LimitsEnabled(const FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings& Value) { Write<FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings>(uintptr_t(this) + 0x2b, Value); } // 0x2b (Size: 0x1, Type: StructProperty)
};

// Size: 0x2
struct FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings : public FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings
{
public:
    FRigControlLimitEnabled Enabled() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: StructProperty)

    void SET_Enabled(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_HierarchyAddAnimationChannelFloat : public FRigUnit_HierarchyAddElement
{
public:
    float InitialValue() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float MinimumValue() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float MaximumValue() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings LimitsEnabled() const { return Read<FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x2, Type: StructProperty)

    void SET_InitialValue(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_MinimumValue(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_MaximumValue(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_LimitsEnabled(const FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings& Value) { Write<FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x2, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_HierarchyAddAnimationChannelScaleFloat : public FRigUnit_HierarchyAddElement
{
public:
    float InitialValue() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float MinimumValue() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float MaximumValue() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings LimitsEnabled() const { return Read<FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x2, Type: StructProperty)

    void SET_InitialValue(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_MinimumValue(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_MaximumValue(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_LimitsEnabled(const FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings& Value) { Write<FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x2, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_HierarchyAddAnimationChannelInteger : public FRigUnit_HierarchyAddElement
{
public:
    int32_t InitialValue() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)
    int32_t MinimumValue() const { return Read<int32_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: IntProperty)
    int32_t MaximumValue() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings LimitsEnabled() const { return Read<FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x2, Type: StructProperty)
    UEnum* ControlEnum() const { return Read<UEnum*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_InitialValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
    void SET_MinimumValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: IntProperty)
    void SET_MaximumValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_LimitsEnabled(const FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings& Value) { Write<FRigUnit_HierarchyAddAnimationChannelSingleLimitSettings>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x2, Type: StructProperty)
    void SET_ControlEnum(const UEnum*& Value) { Write<UEnum*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4
struct FRigUnit_HierarchyAddAnimationChannel2DLimitSettings : public FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings
{
public:
    FRigControlLimitEnabled X() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled Y() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: StructProperty)

    void SET_X(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: StructProperty)
    void SET_Y(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: StructProperty)
};

// Size: 0x60
struct FRigUnit_HierarchyAddAnimationChannelVector2D : public FRigUnit_HierarchyAddElement
{
public:
    FVector2D InitialValue() const { return Read<FVector2D>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FVector2D MinimumValue() const { return Read<FVector2D>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FVector2D MaximumValue() const { return Read<FVector2D>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FRigUnit_HierarchyAddAnimationChannel2DLimitSettings LimitsEnabled() const { return Read<FRigUnit_HierarchyAddAnimationChannel2DLimitSettings>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: StructProperty)

    void SET_InitialValue(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_MinimumValue(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_MaximumValue(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_LimitsEnabled(const FRigUnit_HierarchyAddAnimationChannel2DLimitSettings& Value) { Write<FRigUnit_HierarchyAddAnimationChannel2DLimitSettings>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: StructProperty)
};

// Size: 0x6
struct FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings : public FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings
{
public:
    FRigControlLimitEnabled X() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled Y() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled Z() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x2, Type: StructProperty)

    void SET_X(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: StructProperty)
    void SET_Y(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: StructProperty)
    void SET_Z(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x2, Type: StructProperty)
};

// Size: 0x78
struct FRigUnit_HierarchyAddAnimationChannelVector : public FRigUnit_HierarchyAddElement
{
public:
    FVector InitialValue() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FVector MinimumValue() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FVector MaximumValue() const { return Read<FVector>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings LimitsEnabled() const { return Read<FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x6, Type: StructProperty)

    void SET_InitialValue(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_MinimumValue(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_MaximumValue(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_LimitsEnabled(const FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings& Value) { Write<FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x6, Type: StructProperty)
};

// Size: 0x78
struct FRigUnit_HierarchyAddAnimationChannelScaleVector : public FRigUnit_HierarchyAddElement
{
public:
    FVector InitialValue() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FVector MinimumValue() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FVector MaximumValue() const { return Read<FVector>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings LimitsEnabled() const { return Read<FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x6, Type: StructProperty)

    void SET_InitialValue(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_MinimumValue(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_MaximumValue(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_LimitsEnabled(const FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings& Value) { Write<FRigUnit_HierarchyAddAnimationChannelVectorLimitSettings>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x6, Type: StructProperty)
};

// Size: 0x6
struct FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings : public FRigUnit_HierarchyAddAnimationChannelEmptyLimitSettings
{
public:
    FRigControlLimitEnabled pitch() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled Yaw() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x2, Type: StructProperty)
    FRigControlLimitEnabled Roll() const { return Read<FRigControlLimitEnabled>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x2, Type: StructProperty)

    void SET_pitch(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x2, Type: StructProperty)
    void SET_Yaw(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x2, Type: StructProperty)
    void SET_Roll(const FRigControlLimitEnabled& Value) { Write<FRigControlLimitEnabled>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x2, Type: StructProperty)
};

// Size: 0x78
struct FRigUnit_HierarchyAddAnimationChannelRotator : public FRigUnit_HierarchyAddElement
{
public:
    FRotator InitialValue() const { return Read<FRotator>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FRotator MinimumValue() const { return Read<FRotator>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FRotator MaximumValue() const { return Read<FRotator>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings LimitsEnabled() const { return Read<FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x6, Type: StructProperty)

    void SET_InitialValue(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_MinimumValue(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_MaximumValue(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_LimitsEnabled(const FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings& Value) { Write<FRigUnit_HierarchyAddAnimationChannelRotatorLimitSettings>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x6, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_HierarchyGetShapeSettings : public FRigUnit_DynamicHierarchyBase
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Settings() const { return Read<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x80, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Settings(const FRigUnit_HierarchyAddControl_ShapeSettings& Value) { Write<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x80, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_HierarchySetShapeSettings : public FRigUnit_DynamicHierarchyBaseMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigUnit_HierarchyAddControl_ShapeSettings Settings() const { return Read<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x80, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Settings(const FRigUnit_HierarchyAddControl_ShapeSettings& Value) { Write<FRigUnit_HierarchyAddControl_ShapeSettings>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x80, Type: StructProperty)
};

// Size: 0xc0
struct FRigUnit_HierarchyAddSocket : public FRigUnit_HierarchyAddElement
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: EnumProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x10, Type: StructProperty)
    FString Description() const { return Read<FString>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: StrProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: EnumProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x10, Type: StructProperty)
    void SET_Description(const FString& Value) { Write<FString>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x8
struct FRigUnit_HierarchyBase : public FRigUnit
{
public:
};

// Size: 0x10
struct FRigUnit_HierarchyBaseMutable : public FRigUnitMutable
{
public:
};

// Size: 0x50
struct FRigUnit_HierarchyGetParent : public FRigUnit_HierarchyBase
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bDefaultParent() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x8, Type: StructProperty)
    FCachedRigElement CachedChild() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bDefaultParent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x8, Type: StructProperty)
    void SET_CachedChild(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_CachedParent(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_HierarchyGetParents : public FRigUnit_HierarchyBase
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeChild() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bReverse() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    FRigElementKeyCollection Parents() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FCachedRigElement CachedChild() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FRigElementKeyCollection CachedParents() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bIncludeChild(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bReverse(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_Parents(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_CachedChild(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_CachedParents(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_HierarchyGetParentsItemArray : public FRigUnit_HierarchyBase
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeChild() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bReverse() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    bool bDefaultParent() const { return Read<bool>(uintptr_t(this) + 0x12); } // 0x12 (Size: 0x1, Type: BoolProperty)
    TArray<FRigElementKey> Parents() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedChild() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FRigElementKeyCollection CachedParents() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bIncludeChild(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bReverse(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_bDefaultParent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x12, Value); } // 0x12 (Size: 0x1, Type: BoolProperty)
    void SET_Parents(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedChild(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_CachedParents(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_HierarchyGetChildren : public FRigUnit_HierarchyBase
{
public:
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeParent() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bRecursive() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    FRigElementKeyCollection Children() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FCachedRigElement CachedParent() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FRigElementKeyCollection CachedChildren() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)

    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bIncludeParent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bRecursive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_Children(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_CachedParent(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_CachedChildren(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_HierarchyGetSiblings : public FRigUnit_HierarchyBase
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeItem() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FRigElementKeyCollection Siblings() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FCachedRigElement CachedItem() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FRigElementKeyCollection CachedSiblings() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bIncludeItem(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_Siblings(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_CachedItem(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_CachedSiblings(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_HierarchyGetSiblingsItemArray : public FRigUnit_HierarchyBase
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bIncludeItem() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bDefaultSiblings() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    TArray<FRigElementKey> Siblings() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedItem() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FRigElementKeyCollection CachedSiblings() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bIncludeItem(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bDefaultSiblings(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_Siblings(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedItem(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_CachedSiblings(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: StructProperty)
};

// Size: 0x70
struct FRigUnit_HierarchyGetChainItemArray : public FRigUnit_HierarchyBase
{
public:
    FRigElementKey Start() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey End() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool bIncludeStart() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bIncludeEnd() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    bool bReverse() const { return Read<bool>(uintptr_t(this) + 0x1a); } // 0x1a (Size: 0x1, Type: BoolProperty)
    TArray<FRigElementKey> Chain() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedStart() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedEnd() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FRigElementKeyCollection CachedChain() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: StructProperty)

    void SET_Start(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_End(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_bIncludeStart(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_bIncludeEnd(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_bReverse(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a, Value); } // 0x1a (Size: 0x1, Type: BoolProperty)
    void SET_Chain(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedStart(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_CachedEnd(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_CachedChain(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_HierarchyGetPose : public FRigUnit_HierarchyBase
{
public:
    bool Initial() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t ElementType() const { return Read<uint8_t>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: EnumProperty)
    FRigElementKeyCollection ItemsToGet() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x70, Type: StructProperty)

    void SET_Initial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_ElementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: EnumProperty)
    void SET_ItemsToGet(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x70, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_HierarchyGetPoseItemArray : public FRigUnit_HierarchyBase
{
public:
    bool Initial() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    uint8_t ElementType() const { return Read<uint8_t>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: EnumProperty)
    TArray<FRigElementKey> ItemsToGet() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x70, Type: StructProperty)

    void SET_Initial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_ElementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: EnumProperty)
    void SET_ItemsToGet(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x70, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_HierarchySetPose : public FRigUnit_HierarchyBaseMutable
{
public:
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x70, Type: StructProperty)
    uint8_t ElementType() const { return Read<uint8_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x81); } // 0x81 (Size: 0x1, Type: EnumProperty)
    FRigElementKeyCollection ItemsToSet() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)

    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x70, Type: StructProperty)
    void SET_ElementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: EnumProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x81, Value); } // 0x81 (Size: 0x1, Type: EnumProperty)
    void SET_ItemsToSet(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xa0
struct FRigUnit_HierarchySetPoseItemArray : public FRigUnit_HierarchyBaseMutable
{
public:
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x70, Type: StructProperty)
    uint8_t ElementType() const { return Read<uint8_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: EnumProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x81); } // 0x81 (Size: 0x1, Type: EnumProperty)
    TArray<FRigElementKey> ItemsToSet() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)

    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x70, Type: StructProperty)
    void SET_ElementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: EnumProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x81, Value); } // 0x81 (Size: 0x1, Type: EnumProperty)
    void SET_ItemsToSet(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x80
struct FRigUnit_PoseIsEmpty : public FRigUnit_HierarchyBase
{
public:
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x70, Type: StructProperty)
    bool IsEmpty() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)

    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x70, Type: StructProperty)
    void SET_IsEmpty(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
struct FRigUnit_PoseGetItems : public FRigUnit_HierarchyBase
{
public:
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x70, Type: StructProperty)
    uint8_t ElementType() const { return Read<uint8_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: EnumProperty)
    FRigElementKeyCollection Items() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: StructProperty)

    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x70, Type: StructProperty)
    void SET_ElementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: EnumProperty)
    void SET_Items(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_PoseGetItemsItemArray : public FRigUnit_HierarchyBase
{
public:
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x70, Type: StructProperty)
    uint8_t ElementType() const { return Read<uint8_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: EnumProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)

    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x70, Type: StructProperty)
    void SET_ElementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: EnumProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x128
struct FRigUnit_PoseGetDelta : public FRigUnit_HierarchyBase
{
public:
    FRigPose PoseA() const { return Read<FRigPose>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x70, Type: StructProperty)
    FRigPose PoseB() const { return Read<FRigPose>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x70, Type: StructProperty)
    float PositionThreshold() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    float RotationThreshold() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    float ScaleThreshold() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    float CurveThreshold() const { return Read<float>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    uint8_t ElementType() const { return Read<uint8_t>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x1, Type: EnumProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0xf9); } // 0xf9 (Size: 0x1, Type: EnumProperty)
    FRigElementKeyCollection ItemsToCompare() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: StructProperty)
    bool PosesAreEqual() const { return Read<bool>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x1, Type: BoolProperty)
    FRigElementKeyCollection ItemsWithDelta() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: StructProperty)

    void SET_PoseA(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x70, Type: StructProperty)
    void SET_PoseB(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x70, Type: StructProperty)
    void SET_PositionThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_RotationThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_ScaleThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_CurveThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    void SET_ElementType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x1, Type: EnumProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xf9, Value); } // 0xf9 (Size: 0x1, Type: EnumProperty)
    void SET_ItemsToCompare(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: StructProperty)
    void SET_PosesAreEqual(const bool& Value) { Write<bool>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x1, Type: BoolProperty)
    void SET_ItemsWithDelta(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: StructProperty)
};

// Size: 0x100
struct FRigUnit_PoseGetTransform : public FRigUnit_HierarchyBase
{
public:
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x70, Type: StructProperty)
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x8, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: EnumProperty)
    bool Valid() const { return Read<bool>(uintptr_t(this) + 0x81); } // 0x81 (Size: 0x1, Type: BoolProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x60, Type: StructProperty)
    float CurveValue() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    int32_t CachedPoseElementIndex() const { return Read<int32_t>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: IntProperty)
    int32_t CachedPoseHash() const { return Read<int32_t>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: IntProperty)

    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x70, Type: StructProperty)
    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x8, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: EnumProperty)
    void SET_Valid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x81, Value); } // 0x81 (Size: 0x1, Type: BoolProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x60, Type: StructProperty)
    void SET_CurveValue(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_CachedPoseElementIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: IntProperty)
    void SET_CachedPoseHash(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x90
struct FRigUnit_PoseGetTransformArray : public FRigUnit_HierarchyBase
{
public:
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x70, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: EnumProperty)
    bool Valid() const { return Read<bool>(uintptr_t(this) + 0x79); } // 0x79 (Size: 0x1, Type: BoolProperty)
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)

    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x70, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: EnumProperty)
    void SET_Valid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x79, Value); } // 0x79 (Size: 0x1, Type: BoolProperty)
    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x90
struct FRigUnit_PoseGetCurve : public FRigUnit_HierarchyBase
{
public:
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x70, Type: StructProperty)
    FName Curve() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    bool Valid() const { return Read<bool>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x1, Type: BoolProperty)
    float CurveValue() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    int32_t CachedPoseElementIndex() const { return Read<int32_t>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: IntProperty)
    int32_t CachedPoseHash() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)

    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x70, Type: StructProperty)
    void SET_Curve(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET_Valid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x1, Type: BoolProperty)
    void SET_CurveValue(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_CachedPoseElementIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: IntProperty)
    void SET_CachedPoseHash(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
};

// Size: 0x350
struct FRigUnit_PoseLoop : public FRigUnit_HierarchyBaseMutable
{
public:
    FName BlockToRun() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x70, Type: StructProperty)
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x8, Type: StructProperty)
    FTransform GlobalTransform() const { return Read<FTransform>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x60, Type: StructProperty)
    FTransform LocalTransform() const { return Read<FTransform>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x60, Type: StructProperty)
    float CurveValue() const { return Read<float>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: FloatProperty)
    int32_t Index() const { return Read<int32_t>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x4, Type: IntProperty)
    int32_t Count() const { return Read<int32_t>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: IntProperty)
    float Ratio() const { return Read<float>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x4, Type: FloatProperty)
    FControlRigExecuteContext Completed() const { return Read<FControlRigExecuteContext>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x1f0, Type: StructProperty)

    void SET_BlockToRun(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x70, Type: StructProperty)
    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x8, Type: StructProperty)
    void SET_GlobalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x60, Type: StructProperty)
    void SET_LocalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x60, Type: StructProperty)
    void SET_CurveValue(const float& Value) { Write<float>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: FloatProperty)
    void SET_Index(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x4, Type: IntProperty)
    void SET_Count(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: IntProperty)
    void SET_Ratio(const float& Value) { Write<float>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x4, Type: FloatProperty)
    void SET_Completed(const FControlRigExecuteContext& Value) { Write<FControlRigExecuteContext>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x1f0, Type: StructProperty)
};

// Size: 0x100
struct FRigUnit_HierarchyCreatePoseItemArray_Entry
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FTransform LocalTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform GlobalTransform() const { return Read<FTransform>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x60, Type: StructProperty)
    bool UseEulerAngles() const { return Read<bool>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    FVector EulerAngles() const { return Read<FVector>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)
    float CurveValue() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_LocalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_GlobalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x60, Type: StructProperty)
    void SET_UseEulerAngles(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: BoolProperty)
    void SET_EulerAngles(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
    void SET_CurveValue(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x88
struct FRigUnit_HierarchyCreatePoseItemArray : public FRigUnit_HierarchyBase
{
public:
    TArray<FRigUnit_HierarchyCreatePoseItemArray_Entry> Entries() const { return Read<TArray<FRigUnit_HierarchyCreatePoseItemArray_Entry>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    FRigPose Pose() const { return Read<FRigPose>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x70, Type: StructProperty)

    void SET_Entries(const TArray<FRigUnit_HierarchyCreatePoseItemArray_Entry>& Value) { Write<TArray<FRigUnit_HierarchyCreatePoseItemArray_Entry>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Pose(const FRigPose& Value) { Write<FRigPose>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x70, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_InteractionExecution : public FRigUnit
{
public:
    FRigVMExecutePin ExecutePin() const { return Read<FRigVMExecutePin>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_ExecutePin(const FRigVMExecutePin& Value) { Write<FRigVMExecutePin>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_InverseExecution : public FRigUnit
{
public:
    FRigVMExecutePin ExecutePin() const { return Read<FRigVMExecutePin>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_ExecutePin(const FRigVMExecutePin& Value) { Write<FRigVMExecutePin>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x20
struct FRigUnit_IsInteracting : public FRigUnit
{
public:
    bool bIsInteracting() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)
    bool bIsTranslating() const { return Read<bool>(uintptr_t(this) + 0x9); } // 0x9 (Size: 0x1, Type: BoolProperty)
    bool bIsRotating() const { return Read<bool>(uintptr_t(this) + 0xa); } // 0xa (Size: 0x1, Type: BoolProperty)
    bool bIsScaling() const { return Read<bool>(uintptr_t(this) + 0xb); } // 0xb (Size: 0x1, Type: BoolProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_bIsInteracting(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
    void SET_bIsTranslating(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9, Value); } // 0x9 (Size: 0x1, Type: BoolProperty)
    void SET_bIsRotating(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa, Value); } // 0xa (Size: 0x1, Type: BoolProperty)
    void SET_bIsScaling(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb, Value); } // 0xb (Size: 0x1, Type: BoolProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x8
struct FRigUnit_ItemBase : public FRigUnit
{
public:
};

// Size: 0x10
struct FRigUnit_ItemBaseMutable : public FRigUnitMutable
{
public:
};

// Size: 0x30
struct FRigUnit_ItemExists : public FRigUnit_ItemBase
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool Exists() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Exists(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x20
struct FRigUnit_ItemReplace : public FRigUnit_ItemBase
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FName Old() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName New() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    FRigElementKey Result() const { return Read<FRigElementKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Old(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_New(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_Result(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
};

// Size: 0x20
struct FRigUnit_ItemEquals : public FRigUnit_ItemBase
{
public:
    FRigElementKey A() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey B() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool Result() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)

    void SET_A(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_B(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Result(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FRigUnit_ItemNotEquals : public FRigUnit_ItemBase
{
public:
    FRigElementKey A() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey B() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool Result() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)

    void SET_A(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_B(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Result(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FRigUnit_ItemTypeEquals : public FRigUnit_ItemBase
{
public:
    FRigElementKey A() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey B() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool Result() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)

    void SET_A(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_B(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Result(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FRigUnit_ItemTypeNotEquals : public FRigUnit_ItemBase
{
public:
    FRigElementKey A() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FRigElementKey B() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool Result() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)

    void SET_A(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_B(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Result(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FRigUnit_ItemToName : public FRigUnit_ItemBase
{
public:
    FRigElementKey Value() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FName Result() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)

    void SET_Value(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Result(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
};

// Size: 0x28
struct FRigUnit_HierarchyAddPhysicsSolver : public FRigUnit_DynamicHierarchyBaseMutable
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FRigPhysicsSolverID Solver() const { return Read<FRigPhysicsSolverID>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Solver(const FRigPhysicsSolverID& Value) { Write<FRigPhysicsSolverID>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_HierarchyAddPhysicsJoint : public FRigUnit_HierarchyAddElement
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    FRigPhysicsSolverID Solver() const { return Read<FRigPhysicsSolverID>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: StructProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_Solver(const FRigPhysicsSolverID& Value) { Write<FRigPhysicsSolverID>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_PrepareForExecution : public FRigUnit
{
public:
    FRigVMExecutePin ExecutePin() const { return Read<FRigVMExecutePin>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_ExecutePin(const FRigVMExecutePin& Value) { Write<FRigVMExecutePin>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_PostPrepareForExecution : public FRigUnit
{
public:
    FRigVMExecutePin ExecutePin() const { return Read<FRigVMExecutePin>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_ExecutePin(const FRigVMExecutePin& Value) { Write<FRigVMExecutePin>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x8
struct FRigUnit_RigModulesBase : public FRigUnit
{
public:
};

// Size: 0x10
struct FRigUnit_RigModulesBaseMutable : public FRigUnitMutable
{
public:
};

// Size: 0x20
struct FRigUnit_ResolveConnector : public FRigUnit_RigModulesBase
{
public:
    FRigElementKey Connector() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool SkipSocket() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FRigElementKey Result() const { return Read<FRigElementKey>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x8, Type: StructProperty)
    bool bIsConnected() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)

    void SET_Connector(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_SkipSocket(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_Result(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x8, Type: StructProperty)
    void SET_bIsConnected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FRigUnit_ResolveArrayConnector : public FRigUnit_RigModulesBase
{
public:
    FRigElementKey Connector() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool SkipSocket() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    TArray<FRigElementKey> Result() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    bool bIsConnected() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_Connector(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_SkipSocket(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_Result(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsConnected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FRigUnit_GetCurrentNameSpace : public FRigUnit_RigModulesBase
{
public:
    FString Namespace() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_Namespace(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x18
struct FRigUnit_GetItemShortName : public FRigUnit_RigModulesBase
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FName ShortName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_ShortName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
};

// Size: 0x28
struct FRigUnit_GetItemNameSpace : public FRigUnit_RigModulesBase
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool HasNameSpace() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FString Namespace() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_HasNameSpace(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_Namespace(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
};

// Size: 0x18
struct FRigUnit_IsItemInCurrentNameSpace : public FRigUnit_RigModulesBase
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool Result() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Result(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FRigUnit_GetItemsInNameSpace : public FRigUnit_RigModulesBase
{
public:
    uint8_t TypeToSearch() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_TypeToSearch(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x18
struct FRigUnit_GetModuleName : public FRigUnit_RigModulesBase
{
public:
    FString Module() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_Module(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x28
struct FRigUnit_GetItemModuleName : public FRigUnit_RigModulesBase
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool IsPartOfModule() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FString Module() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_IsPartOfModule(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_Module(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
};

// Size: 0x18
struct FRigUnit_IsItemInCurrentModule : public FRigUnit_RigModulesBase
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool Result() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Result(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FRigUnit_GetItemsInModule : public FRigUnit_RigModulesBase
{
public:
    uint8_t TypeToSearch() const { return Read<uint8_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: EnumProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_TypeToSearch(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: EnumProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x9c0
struct FRigUnit_SequenceExecution : public FRigUnit
{
public:
    FControlRigExecuteContext ExecuteContext() const { return Read<FControlRigExecuteContext>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1f0, Type: StructProperty)
    FControlRigExecuteContext A() const { return Read<FControlRigExecuteContext>(uintptr_t(this) + 0x200); } // 0x200 (Size: 0x1f0, Type: StructProperty)
    FControlRigExecuteContext B() const { return Read<FControlRigExecuteContext>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x1f0, Type: StructProperty)
    FControlRigExecuteContext C() const { return Read<FControlRigExecuteContext>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x1f0, Type: StructProperty)
    FControlRigExecuteContext D() const { return Read<FControlRigExecuteContext>(uintptr_t(this) + 0x7d0); } // 0x7d0 (Size: 0x1f0, Type: StructProperty)

    void SET_ExecuteContext(const FControlRigExecuteContext& Value) { Write<FControlRigExecuteContext>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1f0, Type: StructProperty)
    void SET_A(const FControlRigExecuteContext& Value) { Write<FControlRigExecuteContext>(uintptr_t(this) + 0x200, Value); } // 0x200 (Size: 0x1f0, Type: StructProperty)
    void SET_B(const FControlRigExecuteContext& Value) { Write<FControlRigExecuteContext>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x1f0, Type: StructProperty)
    void SET_C(const FControlRigExecuteContext& Value) { Write<FControlRigExecuteContext>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x1f0, Type: StructProperty)
    void SET_D(const FControlRigExecuteContext& Value) { Write<FControlRigExecuteContext>(uintptr_t(this) + 0x7d0, Value); } // 0x7d0 (Size: 0x1f0, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_AddBoneTransform : public FRigUnitMutable
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    bool bPostMultiply() const { return Read<bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: BoolProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x85); } // 0x85 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedBone() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_bPostMultiply(const bool& Value) { Write<bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: BoolProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x85, Value); } // 0x85 (Size: 0x1, Type: BoolProperty)
    void SET_CachedBone(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_Item : public FRigUnit
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x18
struct FRigUnit_ItemArray : public FRigUnit
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FRigUnit_BoneName : public FRigUnit
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x10
struct FRigUnit_SpaceName : public FRigUnit
{
public:
    FName Space() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

// Size: 0x10
struct FRigUnit_ControlName : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
};

// Size: 0xa8
struct FRigDispatch_ComponentBase : public FRigDispatchFactory
{
public:
};

// Size: 0xa8
struct FRigDispatch_SpawnComponent : public FRigDispatch_ComponentBase
{
public:
};

// Size: 0xa8
struct FRigDispatch_GetComponentContent : public FRigDispatch_ComponentBase
{
public:
};

// Size: 0xa8
struct FRigDispatch_SetComponentContent : public FRigDispatch_ComponentBase
{
public:
};

// Size: 0x20
struct FRigUnit_GetAnimationChannelBase : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FName Channel() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    bool bInitial() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FRigElementKey CachedChannelKey() const { return Read<FRigElementKey>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x8, Type: StructProperty)
    int32_t CachedChannelHash() const { return Read<int32_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: IntProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Channel(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_bInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_CachedChannelKey(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x8, Type: StructProperty)
    void SET_CachedChannelHash(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FRigUnit_GetBoolAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
public:
    bool Value() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_Value(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FRigUnit_GetFloatAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FRigUnit_GetIntAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
public:
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)

    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
struct FRigUnit_GetVector2DAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
public:
    FVector2D Value() const { return Read<FVector2D>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)

    void SET_Value(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_GetVectorAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
public:
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_GetRotatorAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
public:
    FRotator Value() const { return Read<FRotator>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x80
struct FRigUnit_GetTransformAnimationChannel : public FRigUnit_GetAnimationChannelBase
{
public:
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)

    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_SetAnimationChannelBase : public FRigUnit_GetAnimationChannelBase
{
public:
    FRigVMExecutePin ExecutePin() const { return Read<FRigVMExecutePin>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: StructProperty)

    void SET_ExecutePin(const FRigVMExecutePin& Value) { Write<FRigVMExecutePin>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_SetBoolAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
public:
    bool Value() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)

    void SET_Value(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FRigUnit_SetFloatAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x30
struct FRigUnit_SetIntAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
public:
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: IntProperty)

    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: IntProperty)
};

// Size: 0x38
struct FRigUnit_SetVector2DAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
public:
    FVector2D Value() const { return Read<FVector2D>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)

    void SET_Value(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_SetVectorAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
public:
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_SetRotatorAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
public:
    FRotator Value() const { return Read<FRotator>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_SetTransformAnimationChannel : public FRigUnit_SetAnimationChannelBase
{
public:
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)

    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
};

// Size: 0x18
struct FRigUnit_GetAnimationChannelFromItemBase : public FRigUnit
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bInitial() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FRigUnit_GetBoolAnimationChannelFromItem : public FRigUnit_GetAnimationChannelFromItemBase
{
public:
    bool Value() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)

    void SET_Value(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FRigUnit_GetFloatAnimationChannelFromItem : public FRigUnit_GetAnimationChannelFromItemBase
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x20
struct FRigUnit_GetIntAnimationChannelFromItem : public FRigUnit_GetAnimationChannelFromItemBase
{
public:
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)

    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
};

// Size: 0x28
struct FRigUnit_GetVector2DAnimationChannelFromItem : public FRigUnit_GetAnimationChannelFromItemBase
{
public:
    FVector2D Value() const { return Read<FVector2D>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)

    void SET_Value(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_GetVectorAnimationChannelFromItem : public FRigUnit_GetAnimationChannelFromItemBase
{
public:
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_GetRotatorAnimationChannelFromItem : public FRigUnit_GetAnimationChannelFromItemBase
{
public:
    FRotator Value() const { return Read<FRotator>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x80
struct FRigUnit_GetTransformAnimationChannelFromItem : public FRigUnit_GetAnimationChannelFromItemBase
{
public:
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)

    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
};

// Size: 0x20
struct FRigUnit_SetAnimationChannelBaseFromItem : public FRigUnit_GetAnimationChannelFromItemBase
{
public:
    FRigVMExecutePin ExecutePin() const { return Read<FRigVMExecutePin>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)

    void SET_ExecutePin(const FRigVMExecutePin& Value) { Write<FRigVMExecutePin>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_SetBoolAnimationChannelFromItem : public FRigUnit_SetAnimationChannelBaseFromItem
{
public:
    bool Value() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_Value(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FRigUnit_SetFloatAnimationChannelFromItem : public FRigUnit_SetAnimationChannelBaseFromItem
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FRigUnit_SetIntAnimationChannelFromItem : public FRigUnit_SetAnimationChannelBaseFromItem
{
public:
    int32_t Value() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)

    void SET_Value(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
};

// Size: 0x30
struct FRigUnit_SetVector2DAnimationChannelFromItem : public FRigUnit_SetAnimationChannelBaseFromItem
{
public:
    FVector2D Value() const { return Read<FVector2D>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)

    void SET_Value(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_SetVectorAnimationChannelFromItem : public FRigUnit_SetAnimationChannelBaseFromItem
{
public:
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_SetRotatorAnimationChannelFromItem : public FRigUnit_SetAnimationChannelBaseFromItem
{
public:
    FRotator Value() const { return Read<FRotator>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x80
struct FRigUnit_SetTransformAnimationChannelFromItem : public FRigUnit_SetAnimationChannelBaseFromItem
{
public:
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)

    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_CurveExists : public FRigUnit
{
public:
    FName Curve() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    bool Exists() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedCurveIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)

    void SET_Curve(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Exists(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_CachedCurveIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_FindClosestItem : public FRigUnitMutable
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FVector Point() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: StructProperty)
    TArray<FCachedRigElement> CachedItems() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Point(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: StructProperty)
    void SET_CachedItems(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x90
struct FRigUnit_GetBoneTransform : public FRigUnit
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedBone() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    bool bFirstUpdate() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_CachedBone(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_bFirstUpdate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
struct FRigUnit_GetControlInitialTransform : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_GetControlOffset : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    FTransform OffsetTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_OffsetTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_GetControlBool : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    bool BoolValue() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_BoolValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_GetControlFloat : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    float FloatValue() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float Minimum() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float Maximum() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_FloatValue(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Minimum(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Maximum(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_GetControlInteger : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    int32_t IntegerValue() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)
    int32_t Minimum() const { return Read<int32_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: IntProperty)
    int32_t Maximum() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_IntegerValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
    void SET_Minimum(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: IntProperty)
    void SET_Maximum(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x58
struct FRigUnit_GetControlVector2D : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FVector2D Vector() const { return Read<FVector2D>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FVector2D Minimum() const { return Read<FVector2D>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    FVector2D Maximum() const { return Read<FVector2D>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Vector(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Minimum(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_Maximum(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x70
struct FRigUnit_GetControlVector : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    FVector Vector() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector Minimum() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FVector Maximum() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Vector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_Minimum(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_Maximum(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
};

// Size: 0x70
struct FRigUnit_GetControlRotator : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    FRotator Rotator() const { return Read<FRotator>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FRotator Minimum() const { return Read<FRotator>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FRotator Maximum() const { return Read<FRotator>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Rotator(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_Minimum(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_Maximum(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
};

// Size: 0x150
struct FRigUnit_GetControlTransform : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform Minimum() const { return Read<FTransform>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x60, Type: StructProperty)
    FTransform Maximum() const { return Read<FTransform>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Minimum(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x60, Type: StructProperty)
    void SET_Maximum(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x60, Type: StructProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_GetCurveValue : public FRigUnit
{
public:
    FName Curve() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    bool Valid() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    float Value() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement CachedCurveIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Curve(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Valid(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_CachedCurveIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_GetInitialBoneTransform : public FRigUnit
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedBone() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_CachedBone(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_GetRelativeBoneTransform : public FRigUnit
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FName Space() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedBone() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedSpace() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_CachedBone(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_CachedSpace(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
};

// Size: 0xb0
struct FRigUnit_GetRelativeTransformForItem : public FRigUnit
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bChildInitial() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x8, Type: StructProperty)
    bool bParentInitial() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)
    FTransform RelativeTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedChild() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x18, Type: StructProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bChildInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x8, Type: StructProperty)
    void SET_bParentInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
    void SET_RelativeTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_CachedChild(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_CachedParent(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x18, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_GetSpaceTransform : public FRigUnit
{
public:
    FName Space() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t SpaceType() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedSpaceIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_SpaceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_CachedSpaceIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_GetTransform : public FRigUnit
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    bool bInitial() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_bInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_GetTransformArray : public FRigUnit
{
public:
    FRigElementKeyCollection Items() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bInitial() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedIndex() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_bInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedIndex(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FRigUnit_GetTransformItemArray : public FRigUnit
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bInitial() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedIndex() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_bInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedIndex(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa0
struct FRigDispatch_MetadataBase : public FRigDispatchFactory
{
public:
};

// Size: 0xa0
struct FRigDispatch_GetMetadata : public FRigDispatch_MetadataBase
{
public:
};

// Size: 0xa0
struct FRigDispatch_SetMetadata : public FRigDispatch_MetadataBase
{
public:
};

// Size: 0x38
struct FRigUnit_RemoveMetadata : public FRigUnitMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Namespace() const { return Read<uint8_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: EnumProperty)
    bool Removed() const { return Read<bool>(uintptr_t(this) + 0x1d); } // 0x1d (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_Namespace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: EnumProperty)
    void SET_Removed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d, Value); } // 0x1d (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_RemoveAllMetadata : public FRigUnitMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Namespace() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    bool Removed() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Namespace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_Removed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_HasMetadata : public FRigUnit
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: EnumProperty)
    uint8_t Namespace() const { return Read<uint8_t>(uintptr_t(this) + 0x15); } // 0x15 (Size: 0x1, Type: EnumProperty)
    bool Found() const { return Read<bool>(uintptr_t(this) + 0x16); } // 0x16 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: EnumProperty)
    void SET_Namespace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x15, Value); } // 0x15 (Size: 0x1, Type: EnumProperty)
    void SET_Found(const bool& Value) { Write<bool>(uintptr_t(this) + 0x16, Value); } // 0x16 (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x20
struct FRigUnit_FindItemsWithMetadata : public FRigUnit
{
public:
    FName Name() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Type() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    uint8_t Namespace() const { return Read<uint8_t>(uintptr_t(this) + 0xd); } // 0xd (Size: 0x1, Type: EnumProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Type(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Namespace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd, Value); } // 0xd (Size: 0x1, Type: EnumProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FRigUnit_GetMetadataTags : public FRigUnit
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FName> Tags() const { return Read<TArray<FName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Tags(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_SetMetadataTag : public FRigUnitMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FName Tag() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Namespace() const { return Read<uint8_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: EnumProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Tag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_Namespace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: EnumProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x48
struct FRigUnit_SetMetadataTagArray : public FRigUnitMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    TArray<FName> Tags() const { return Read<TArray<FName>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t Namespace() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Tags(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Namespace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_RemoveMetadataTag : public FRigUnitMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FName Tag() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    uint8_t Namespace() const { return Read<uint8_t>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: EnumProperty)
    bool Removed() const { return Read<bool>(uintptr_t(this) + 0x1d); } // 0x1d (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Tag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_Namespace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: EnumProperty)
    void SET_Removed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d, Value); } // 0x1d (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_HasMetadataTag : public FRigUnit
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    FName Tag() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t Namespace() const { return Read<uint8_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: EnumProperty)
    bool Found() const { return Read<bool>(uintptr_t(this) + 0x15); } // 0x15 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Tag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Namespace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: EnumProperty)
    void SET_Found(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15, Value); } // 0x15 (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_HasMetadataTagArray : public FRigUnit
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FName> Tags() const { return Read<TArray<FName>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    uint8_t Namespace() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    bool Found() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Tags(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Namespace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_Found(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x20
struct FRigUnit_FindItemsWithMetadataTag : public FRigUnit
{
public:
    FName Tag() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t Namespace() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Tag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Namespace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FRigUnit_FindItemsWithMetadataTagArray : public FRigUnit
{
public:
    TArray<FName> Tags() const { return Read<TArray<FName>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    uint8_t Namespace() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_Tags(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Namespace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FRigUnit_FilterItemsByMetadataTags : public FRigUnit
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> Tags() const { return Read<TArray<FName>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t Namespace() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    bool Inclusive() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)
    TArray<FRigElementKey> Result() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedIndices() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Tags(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Namespace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_Inclusive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
    void SET_Result(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedIndices(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa0
struct FRigDispatch_GetModuleMetadata : public FRigDispatch_GetMetadata
{
public:
};

// Size: 0xa0
struct FRigDispatch_SetModuleMetadata : public FRigDispatch_SetMetadata
{
public:
};

// Size: 0xa0
struct FRigUnit_OffsetTransformForItem : public FRigUnitMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FTransform OffsetTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_OffsetTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
};

// Size: 0x1a0
struct FRigUnit_ParentSwitchConstraint : public FRigUnitMutable
{
public:
    FRigElementKey Subject() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    int32_t ParentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    FRigElementKeyCollection Parents() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    FTransform InitialGlobalTransform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x60, Type: StructProperty)
    bool Switched() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedSubject() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x18, Type: StructProperty)
    FTransform RelativeOffset() const { return Read<FTransform>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x60, Type: StructProperty)

    void SET_Subject(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_ParentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_Parents(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_InitialGlobalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x60, Type: StructProperty)
    void SET_Switched(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
    void SET_CachedSubject(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x18, Type: StructProperty)
    void SET_CachedParent(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x18, Type: StructProperty)
    void SET_RelativeOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x60, Type: StructProperty)
};

// Size: 0x1a0
struct FRigUnit_ParentSwitchConstraintArray : public FRigUnitMutable
{
public:
    FRigElementKey Subject() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    int32_t ParentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    TArray<FRigElementKey> Parents() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    FTransform InitialGlobalTransform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x60, Type: StructProperty)
    bool Switched() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedSubject() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x18, Type: StructProperty)
    FTransform RelativeOffset() const { return Read<FTransform>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x60, Type: StructProperty)

    void SET_Subject(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_ParentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_Parents(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_InitialGlobalTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x60, Type: StructProperty)
    void SET_Switched(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
    void SET_CachedSubject(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x18, Type: StructProperty)
    void SET_CachedParent(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x18, Type: StructProperty)
    void SET_RelativeOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x60, Type: StructProperty)
};

// Size: 0xe0
struct FRigUnit_ProjectTransformToNewParent : public FRigUnit
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bChildInitial() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FRigElementKey OldParent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x8, Type: StructProperty)
    bool bOldParentInitial() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)
    FRigElementKey NewParent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: StructProperty)
    bool bNewParentInitial() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedChild() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedOldParent() const { return Read<FCachedRigElement>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedNewParent() const { return Read<FCachedRigElement>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bChildInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_OldParent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x8, Type: StructProperty)
    void SET_bOldParentInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
    void SET_NewParent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: StructProperty)
    void SET_bNewParentInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_CachedChild(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_CachedOldParent(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x18, Type: StructProperty)
    void SET_CachedNewParent(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_PropagateTransform : public FRigUnitMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool bRecomputeGlobal() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    bool bApplyToChildren() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    bool bRecursive() const { return Read<bool>(uintptr_t(this) + 0x1a); } // 0x1a (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_bRecomputeGlobal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_bApplyToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_bRecursive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a, Value); } // 0x1a (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_SendEvent : public FRigUnitMutable
{
public:
    uint8_t Event() const { return Read<uint8_t>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: EnumProperty)
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x8, Type: StructProperty)
    float OffsetInSeconds() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    bool bEnable() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    bool bOnlyDuringInteraction() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)

    void SET_Event(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: EnumProperty)
    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x8, Type: StructProperty)
    void SET_OffsetInSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_bEnable(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_bOnlyDuringInteraction(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x100
struct FRigUnit_SetBoneInitialTransform : public FRigUnitMutable
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform Result() const { return Read<FTransform>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x60, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: EnumProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0xe1); } // 0xe1 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedBone() const { return Read<FCachedRigElement>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x18, Type: StructProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Result(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x60, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: EnumProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe1, Value); } // 0xe1 (Size: 0x1, Type: BoolProperty)
    void SET_CachedBone(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x70
struct FRigUnit_SetBoneRotation : public FRigUnitMutable
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedBone() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_CachedBone(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
};

// Size: 0x110
struct FRigUnit_SetBoneTransform : public FRigUnitMutable
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform Result() const { return Read<FTransform>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x60, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedBone() const { return Read<FCachedRigElement>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Result(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x60, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    void SET_CachedBone(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x58
struct FRigUnit_SetBoneTranslation : public FRigUnitMutable
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FVector Translation() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedBone() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Translation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_CachedBone(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_GetControlColor : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x10, Type: StructProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x10, Type: StructProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_SetControlColor : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_GetControlDrivenList : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    TArray<FRigElementKey> Driven() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Driven(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_SetControlDrivenList : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    TArray<FRigElementKey> Driven() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Driven(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_SetControlOffset : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FTransform Offset() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: EnumProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Offset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: EnumProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_SetControlTranslationOffset : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FVector Offset() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Offset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x60
struct FRigUnit_SetControlRotationOffset : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FQuat Offset() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: EnumProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Offset(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: EnumProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_SetControlScaleOffset : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FVector Scale() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Scale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_GetShapeTransform : public FRigUnit
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_SetShapeTransform : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_SetControlBool : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    bool BoolValue() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_BoolValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x8
struct FRigUnit_SetMultiControlBool_Entry
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    bool BoolValue() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_BoolValue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FRigUnit_SetMultiControlBool : public FRigUnitMutable
{
public:
    TArray<FRigUnit_SetMultiControlBool_Entry> Entries() const { return Read<TArray<FRigUnit_SetMultiControlBool_Entry>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedControlIndices() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_Entries(const TArray<FRigUnit_SetMultiControlBool_Entry>& Value) { Write<TArray<FRigUnit_SetMultiControlBool_Entry>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedControlIndices(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FRigUnit_SetControlFloat : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float FloatValue() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_FloatValue(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x8
struct FRigUnit_SetMultiControlFloat_Entry
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    float FloatValue() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_FloatValue(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x38
struct FRigUnit_SetMultiControlFloat : public FRigUnitMutable
{
public:
    TArray<FRigUnit_SetMultiControlFloat_Entry> Entries() const { return Read<TArray<FRigUnit_SetMultiControlFloat_Entry>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    TArray<FCachedRigElement> CachedControlIndices() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Entries(const TArray<FRigUnit_SetMultiControlFloat_Entry>& Value) { Write<TArray<FRigUnit_SetMultiControlFloat_Entry>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_CachedControlIndices(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FRigUnit_SetControlInteger : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    int32_t Weight() const { return Read<int32_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: IntProperty)
    int32_t IntegerValue() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Weight(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: IntProperty)
    void SET_IntegerValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x8
struct FRigUnit_SetMultiControlInteger_Entry
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t IntegerValue() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_IntegerValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x38
struct FRigUnit_SetMultiControlInteger : public FRigUnitMutable
{
public:
    TArray<FRigUnit_SetMultiControlInteger_Entry> Entries() const { return Read<TArray<FRigUnit_SetMultiControlInteger_Entry>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    TArray<FCachedRigElement> CachedControlIndices() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Entries(const TArray<FRigUnit_SetMultiControlInteger_Entry>& Value) { Write<TArray<FRigUnit_SetMultiControlInteger_Entry>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_CachedControlIndices(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FRigUnit_SetControlVector2D : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FVector2D Vector() const { return Read<FVector2D>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Vector(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
};

// Size: 0x18
struct FRigUnit_SetMultiControlVector2D_Entry
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FVector2D Vector() const { return Read<FVector2D>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Vector(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_SetMultiControlVector2D : public FRigUnitMutable
{
public:
    TArray<FRigUnit_SetMultiControlVector2D_Entry> Entries() const { return Read<TArray<FRigUnit_SetMultiControlVector2D_Entry>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    TArray<FCachedRigElement> CachedControlIndices() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Entries(const TArray<FRigUnit_SetMultiControlVector2D_Entry>& Value) { Write<TArray<FRigUnit_SetMultiControlVector2D_Entry>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_CachedControlIndices(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FRigUnit_SetControlVector : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FVector Vector() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Vector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_SetControlRotator : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FRotator Rotator() const { return Read<FRotator>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Rotator(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0x28
struct FRigUnit_SetMultiControlRotator_Entry
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FRotator Rotator() const { return Read<FRotator>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Rotator(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x38
struct FRigUnit_SetMultiControlRotator : public FRigUnitMutable
{
public:
    TArray<FRigUnit_SetMultiControlRotator_Entry> Entries() const { return Read<TArray<FRigUnit_SetMultiControlRotator_Entry>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    TArray<FCachedRigElement> CachedControlIndices() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_Entries(const TArray<FRigUnit_SetMultiControlRotator_Entry>& Value) { Write<TArray<FRigUnit_SetMultiControlRotator_Entry>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_CachedControlIndices(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa0
struct FRigUnit_SetControlTransform : public FRigUnitMutable
{
public:
    FName Control() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: EnumProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)

    void SET_Control(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: EnumProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_GetControlVisibility : public FRigUnit
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    bool bVisible() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedControlIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_bVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_CachedControlIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_SetControlVisibility : public FRigUnitMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FString Pattern() const { return Read<FString>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StrProperty)
    bool bVisible() const { return Read<bool>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: BoolProperty)
    TArray<FCachedRigElement> CachedControlIndices() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Pattern(const FString& Value) { Write<FString>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StrProperty)
    void SET_bVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: BoolProperty)
    void SET_CachedControlIndices(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FRigUnit_SetCurveValue : public FRigUnitMutable
{
public:
    FName Curve() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    float Value() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement CachedCurveIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Curve(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_CachedCurveIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0xc0
struct FRigUnit_SetRelativeBoneTransform : public FRigUnitMutable
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName Space() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedBone() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedSpaceIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x18, Type: StructProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: BoolProperty)
    void SET_CachedBone(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
    void SET_CachedSpaceIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x18, Type: StructProperty)
};

// Size: 0xd0
struct FRigUnit_SetRelativeTransformForItem : public FRigUnitMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)
    bool bParentInitial() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedChild() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent() const { return Read<FCachedRigElement>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x18, Type: StructProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
    void SET_bParentInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x1, Type: BoolProperty)
    void SET_CachedChild(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x18, Type: StructProperty)
    void SET_CachedParent(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x78
struct FRigUnit_SetRelativeTranslationForItem : public FRigUnitMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)
    bool bParentInitial() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedChild() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x18, Type: StructProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
    void SET_bParentInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x1, Type: BoolProperty)
    void SET_CachedChild(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_CachedParent(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x18, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_SetRelativeRotationForItem : public FRigUnitMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey Parent() const { return Read<FRigElementKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)
    bool bParentInitial() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    FQuat Value() const { return Read<FQuat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedChild() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedParent() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Parent(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
    void SET_bParentInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET_Value(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x1, Type: BoolProperty)
    void SET_CachedChild(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_CachedParent(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
};

// Size: 0x100
struct FRigUnit_SetSpaceInitialTransform : public FRigUnitMutable
{
public:
    FName SpaceName() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FTransform Result() const { return Read<FTransform>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x60, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: EnumProperty)
    FCachedRigElement CachedSpaceIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x18, Type: StructProperty)

    void SET_SpaceName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Result(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x60, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: EnumProperty)
    void SET_CachedSpaceIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_SetSpaceTransform : public FRigUnitMutable
{
public:
    FName Space() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t SpaceType() const { return Read<uint8_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: EnumProperty)
    FCachedRigElement CachedSpaceIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)

    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_SpaceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: EnumProperty)
    void SET_CachedSpaceIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa0
struct FRigUnit_SetTransform : public FRigUnitMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bInitial() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_bInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
};

// Size: 0x58
struct FRigUnit_SetTranslation : public FRigUnitMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bInitial() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_bInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x60
struct FRigUnit_SetRotation : public FRigUnitMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bInitial() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    FQuat Value() const { return Read<FQuat>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_bInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_Value(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
};

// Size: 0x58
struct FRigUnit_SetScale : public FRigUnitMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    bool bInitial() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    FVector Scale() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: BoolProperty)
    FCachedRigElement CachedIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_bInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET_Scale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_SetTransformArray : public FRigUnitMutable
{
public:
    FRigElementKeyCollection Items() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bInitial() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: BoolProperty)
    TArray<FCachedRigElement> CachedIndex() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_bInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x50
struct FRigUnit_SetTransformItemArray : public FRigUnitMutable
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    uint8_t Space() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bInitial() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: BoolProperty)
    TArray<FCachedRigElement> CachedIndex() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Space(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_bInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: BoolProperty)
    void SET_CachedIndex(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FRigUnit_UnsetCurveValue : public FRigUnitMutable
{
public:
    FName Curve() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FCachedRigElement CachedCurveIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)

    void SET_Curve(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_CachedCurveIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
};

// Size: 0xd0
struct FRigUnit_ToWorldSpace_Transform : public FRigUnit
{
public:
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform World() const { return Read<FTransform>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x60, Type: StructProperty)

    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_World(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x60, Type: StructProperty)
};

// Size: 0xd0
struct FRigUnit_ToRigSpace_Transform : public FRigUnit
{
public:
    FTransform Value() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FTransform Global() const { return Read<FTransform>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x60, Type: StructProperty)

    void SET_Value(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Global(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x60, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_ToWorldSpace_Location : public FRigUnit
{
public:
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector World() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_World(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_ToRigSpace_Location : public FRigUnit
{
public:
    FVector Value() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Global() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Value(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Global(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_ToWorldSpace_Rotation : public FRigUnit
{
public:
    FQuat Value() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    FQuat World() const { return Read<FQuat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)

    void SET_Value(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_World(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_ToRigSpace_Rotation : public FRigUnit
{
public:
    FQuat Value() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    FQuat Global() const { return Read<FQuat>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: StructProperty)

    void SET_Value(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_Global(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: StructProperty)
};

// Size: 0x8
struct FRigUnit_BoneHarmonics_BoneTarget
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    float Ratio() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Ratio(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FRigUnit_Harmonics_TargetItem
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    float Ratio() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Ratio(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FRigUnit_BoneHarmonics_WorkData
{
public:
    TArray<FCachedRigElement> CachedItems() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FVector WaveTime() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)

    void SET_CachedItems(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_WaveTime(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
};

// Size: 0xd0
struct FRigUnit_BoneHarmonics : public FRigUnit_HighlevelBaseMutable
{
public:
    TArray<FRigUnit_BoneHarmonics_BoneTarget> Bones() const { return Read<TArray<FRigUnit_BoneHarmonics_BoneTarget>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FVector WaveSpeed() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector WaveFrequency() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FVector WaveAmplitude() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    FVector WaveOffset() const { return Read<FVector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    FVector WaveNoise() const { return Read<FVector>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    uint8_t WaveEase() const { return Read<uint8_t>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: EnumProperty)
    float WaveMinimum() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    float WaveMaximum() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    uint8_t RotationOrder() const { return Read<uint8_t>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x1, Type: EnumProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0xa5); } // 0xa5 (Size: 0x1, Type: BoolProperty)
    FRigUnit_BoneHarmonics_WorkData WorkData() const { return Read<FRigUnit_BoneHarmonics_WorkData>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x28, Type: StructProperty)

    void SET_Bones(const TArray<FRigUnit_BoneHarmonics_BoneTarget>& Value) { Write<TArray<FRigUnit_BoneHarmonics_BoneTarget>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_WaveSpeed(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_WaveFrequency(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_WaveAmplitude(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_WaveOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_WaveNoise(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_WaveEase(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: EnumProperty)
    void SET_WaveMinimum(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_WaveMaximum(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_RotationOrder(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x1, Type: EnumProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa5, Value); } // 0xa5 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_BoneHarmonics_WorkData& Value) { Write<FRigUnit_BoneHarmonics_WorkData>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x28, Type: StructProperty)
};

// Size: 0xd0
struct FRigUnit_ItemHarmonics : public FRigUnit_HighlevelBaseMutable
{
public:
    TArray<FRigUnit_Harmonics_TargetItem> Targets() const { return Read<TArray<FRigUnit_Harmonics_TargetItem>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FVector WaveSpeed() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector WaveFrequency() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FVector WaveAmplitude() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    FVector WaveOffset() const { return Read<FVector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    FVector WaveNoise() const { return Read<FVector>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    uint8_t WaveEase() const { return Read<uint8_t>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: EnumProperty)
    float WaveMinimum() const { return Read<float>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: FloatProperty)
    float WaveMaximum() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    uint8_t RotationOrder() const { return Read<uint8_t>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x1, Type: EnumProperty)
    FRigUnit_BoneHarmonics_WorkData WorkData() const { return Read<FRigUnit_BoneHarmonics_WorkData>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x28, Type: StructProperty)

    void SET_Targets(const TArray<FRigUnit_Harmonics_TargetItem>& Value) { Write<TArray<FRigUnit_Harmonics_TargetItem>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_WaveSpeed(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_WaveFrequency(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_WaveAmplitude(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_WaveOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_WaveNoise(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_WaveEase(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: EnumProperty)
    void SET_WaveMinimum(const float& Value) { Write<float>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: FloatProperty)
    void SET_WaveMaximum(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET_RotationOrder(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x1, Type: EnumProperty)
    void SET_WorkData(const FRigUnit_BoneHarmonics_WorkData& Value) { Write<FRigUnit_BoneHarmonics_WorkData>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x48
struct FRigUnit_ChainHarmonics_Reach
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FVector ReachTarget() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector ReachAxis() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float ReachMinimum() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float ReachMaximum() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    uint8_t ReachEase() const { return Read<uint8_t>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: EnumProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_ReachTarget(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_ReachAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_ReachMinimum(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_ReachMaximum(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_ReachEase(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x78
struct FRigUnit_ChainHarmonics_Wave
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    FVector WaveFrequency() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector WaveAmplitude() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector WaveOffset() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FVector WaveNoise() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    float WaveMinimum() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    float WaveMaximum() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    uint8_t WaveEase() const { return Read<uint8_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: EnumProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_WaveFrequency(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_WaveAmplitude(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_WaveOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_WaveNoise(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_WaveMinimum(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_WaveMaximum(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_WaveEase(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x58
struct FRigUnit_ChainHarmonics_Pendulum
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float PendulumStiffness() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FVector PendulumGravity() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    float PendulumBlend() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float PendulumDrag() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float PendulumMinimum() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float PendulumMaximum() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    uint8_t PendulumEase() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    FVector UnwindAxis() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    float UnwindMinimum() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    float UnwindMaximum() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_PendulumStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_PendulumGravity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_PendulumBlend(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_PendulumDrag(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_PendulumMinimum(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_PendulumMaximum(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_PendulumEase(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_UnwindAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_UnwindMinimum(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_UnwindMaximum(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x98
struct FRigUnit_ChainHarmonics_WorkData
{
public:
    FVector time() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    TArray<FCachedRigElement> Items() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<float> Ratio() const { return Read<TArray<float>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> LocalTip() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> PendulumTip() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> PendulumPosition() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> PendulumVelocity() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> HierarchyLine() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> VelocityLines() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)

    void SET_time(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Items(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Ratio(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_LocalTip(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_PendulumTip(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_PendulumPosition(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_PendulumVelocity(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_HierarchyLine(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_VelocityLines(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2e0
struct FRigUnit_ChainHarmonics : public FRigUnit_HighlevelBaseMutable
{
public:
    FName ChainRoot() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FVector Speed() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FRigUnit_ChainHarmonics_Reach Reach() const { return Read<FRigUnit_ChainHarmonics_Reach>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x48, Type: StructProperty)
    FRigUnit_ChainHarmonics_Wave Wave() const { return Read<FRigUnit_ChainHarmonics_Wave>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x78, Type: StructProperty)
    FRuntimeFloatCurve WaveCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x88, Type: StructProperty)
    FRigUnit_ChainHarmonics_Pendulum Pendulum() const { return Read<FRigUnit_ChainHarmonics_Pendulum>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x58, Type: StructProperty)
    bool bDrawDebug() const { return Read<bool>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x1, Type: BoolProperty)
    FTransform DrawWorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x60, Type: StructProperty)
    FRigUnit_ChainHarmonics_WorkData WorkData() const { return Read<FRigUnit_ChainHarmonics_WorkData>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x98, Type: StructProperty)

    void SET_ChainRoot(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Speed(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Reach(const FRigUnit_ChainHarmonics_Reach& Value) { Write<FRigUnit_ChainHarmonics_Reach>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x48, Type: StructProperty)
    void SET_Wave(const FRigUnit_ChainHarmonics_Wave& Value) { Write<FRigUnit_ChainHarmonics_Wave>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x78, Type: StructProperty)
    void SET_WaveCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x88, Type: StructProperty)
    void SET_Pendulum(const FRigUnit_ChainHarmonics_Pendulum& Value) { Write<FRigUnit_ChainHarmonics_Pendulum>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x58, Type: StructProperty)
    void SET_bDrawDebug(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x1, Type: BoolProperty)
    void SET_DrawWorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x60, Type: StructProperty)
    void SET_WorkData(const FRigUnit_ChainHarmonics_WorkData& Value) { Write<FRigUnit_ChainHarmonics_WorkData>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x98, Type: StructProperty)
};

// Size: 0x2e0
struct FRigUnit_ChainHarmonicsPerItem : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey ChainRoot() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FVector Speed() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FRigUnit_ChainHarmonics_Reach Reach() const { return Read<FRigUnit_ChainHarmonics_Reach>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x48, Type: StructProperty)
    FRigUnit_ChainHarmonics_Wave Wave() const { return Read<FRigUnit_ChainHarmonics_Wave>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x78, Type: StructProperty)
    FRuntimeFloatCurve WaveCurve() const { return Read<FRuntimeFloatCurve>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x88, Type: StructProperty)
    FRigUnit_ChainHarmonics_Pendulum Pendulum() const { return Read<FRigUnit_ChainHarmonics_Pendulum>(uintptr_t(this) + 0x178); } // 0x178 (Size: 0x58, Type: StructProperty)
    bool bDrawDebug() const { return Read<bool>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x1, Type: BoolProperty)
    FTransform DrawWorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x60, Type: StructProperty)
    FRigUnit_ChainHarmonics_WorkData WorkData() const { return Read<FRigUnit_ChainHarmonics_WorkData>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x98, Type: StructProperty)

    void SET_ChainRoot(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Speed(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_Reach(const FRigUnit_ChainHarmonics_Reach& Value) { Write<FRigUnit_ChainHarmonics_Reach>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x48, Type: StructProperty)
    void SET_Wave(const FRigUnit_ChainHarmonics_Wave& Value) { Write<FRigUnit_ChainHarmonics_Wave>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x78, Type: StructProperty)
    void SET_WaveCurve(const FRuntimeFloatCurve& Value) { Write<FRuntimeFloatCurve>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x88, Type: StructProperty)
    void SET_Pendulum(const FRigUnit_ChainHarmonics_Pendulum& Value) { Write<FRigUnit_ChainHarmonics_Pendulum>(uintptr_t(this) + 0x178, Value); } // 0x178 (Size: 0x58, Type: StructProperty)
    void SET_bDrawDebug(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x1, Type: BoolProperty)
    void SET_DrawWorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x60, Type: StructProperty)
    void SET_WorkData(const FRigUnit_ChainHarmonics_WorkData& Value) { Write<FRigUnit_ChainHarmonics_WorkData>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x98, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_AimBone_Target
{
public:
    float Weight() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FVector Axis() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Target() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t Kind() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    FName Space() const { return Read<FName>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: NameProperty)

    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Axis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Target(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Kind(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_Space(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: NameProperty)
};

// Size: 0x48
struct FRigUnit_AimItem_Target
{
public:
    float Weight() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    FVector Axis() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Target() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    uint8_t Kind() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    FRigElementKey Space() const { return Read<FRigElementKey>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x8, Type: StructProperty)

    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Axis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Target(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Kind(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_Space(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x8, Type: StructProperty)
};

// Size: 0x70
struct FRigUnit_AimBone_DebugSettings
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
};

// Size: 0x220
struct FRigUnit_AimBoneMath : public FRigUnit_HighlevelBase
{
public:
    FTransform InputTransform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FRigUnit_AimItem_Target Primary() const { return Read<FRigUnit_AimItem_Target>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x48, Type: StructProperty)
    FRigUnit_AimItem_Target Secondary() const { return Read<FRigUnit_AimItem_Target>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x48, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)
    FTransform Result() const { return Read<FTransform>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x60, Type: StructProperty)
    FRigUnit_AimBone_DebugSettings DebugSettings() const { return Read<FRigUnit_AimBone_DebugSettings>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x70, Type: StructProperty)
    FCachedRigElement PrimaryCachedSpace() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x18, Type: StructProperty)
    FCachedRigElement SecondaryCachedSpace() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x18, Type: StructProperty)
    bool bIsInitialized() const { return Read<bool>(uintptr_t(this) + 0x210); } // 0x210 (Size: 0x1, Type: BoolProperty)

    void SET_InputTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Primary(const FRigUnit_AimItem_Target& Value) { Write<FRigUnit_AimItem_Target>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x48, Type: StructProperty)
    void SET_Secondary(const FRigUnit_AimItem_Target& Value) { Write<FRigUnit_AimItem_Target>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x48, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
    void SET_Result(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x60, Type: StructProperty)
    void SET_DebugSettings(const FRigUnit_AimBone_DebugSettings& Value) { Write<FRigUnit_AimBone_DebugSettings>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x70, Type: StructProperty)
    void SET_PrimaryCachedSpace(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryCachedSpace(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x18, Type: StructProperty)
    void SET_bIsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x210, Value); } // 0x210 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x160
struct FRigUnit_AimBone : public FRigUnit_HighlevelBaseMutable
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FRigUnit_AimBone_Target Primary() const { return Read<FRigUnit_AimBone_Target>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x40, Type: StructProperty)
    FRigUnit_AimBone_Target Secondary() const { return Read<FRigUnit_AimBone_Target>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x40, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x1, Type: BoolProperty)
    FRigUnit_AimBone_DebugSettings DebugSettings() const { return Read<FRigUnit_AimBone_DebugSettings>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x70, Type: StructProperty)
    FCachedRigElement CachedBoneIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x18, Type: StructProperty)
    FCachedRigElement PrimaryCachedSpace() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x18, Type: StructProperty)
    FCachedRigElement SecondaryCachedSpace() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x18, Type: StructProperty)
    bool bIsInitialized() const { return Read<bool>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x1, Type: BoolProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Primary(const FRigUnit_AimBone_Target& Value) { Write<FRigUnit_AimBone_Target>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x40, Type: StructProperty)
    void SET_Secondary(const FRigUnit_AimBone_Target& Value) { Write<FRigUnit_AimBone_Target>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x40, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x1, Type: BoolProperty)
    void SET_DebugSettings(const FRigUnit_AimBone_DebugSettings& Value) { Write<FRigUnit_AimBone_DebugSettings>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x70, Type: StructProperty)
    void SET_CachedBoneIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x18, Type: StructProperty)
    void SET_PrimaryCachedSpace(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryCachedSpace(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x18, Type: StructProperty)
    void SET_bIsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x170
struct FRigUnit_AimItem : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigUnit_AimItem_Target Primary() const { return Read<FRigUnit_AimItem_Target>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x48, Type: StructProperty)
    FRigUnit_AimItem_Target Secondary() const { return Read<FRigUnit_AimItem_Target>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x48, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    FRigUnit_AimBone_DebugSettings DebugSettings() const { return Read<FRigUnit_AimBone_DebugSettings>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x70, Type: StructProperty)
    FCachedRigElement CachedItem() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x18, Type: StructProperty)
    FCachedRigElement PrimaryCachedSpace() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x138); } // 0x138 (Size: 0x18, Type: StructProperty)
    FCachedRigElement SecondaryCachedSpace() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x18, Type: StructProperty)
    bool bIsInitialized() const { return Read<bool>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x1, Type: BoolProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_Primary(const FRigUnit_AimItem_Target& Value) { Write<FRigUnit_AimItem_Target>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x48, Type: StructProperty)
    void SET_Secondary(const FRigUnit_AimItem_Target& Value) { Write<FRigUnit_AimItem_Target>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x48, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: FloatProperty)
    void SET_DebugSettings(const FRigUnit_AimBone_DebugSettings& Value) { Write<FRigUnit_AimBone_DebugSettings>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x70, Type: StructProperty)
    void SET_CachedItem(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x18, Type: StructProperty)
    void SET_PrimaryCachedSpace(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x138, Value); } // 0x138 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryCachedSpace(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x18, Type: StructProperty)
    void SET_bIsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FRigUnit_AimConstraint_WorldUp
{
public:
    FVector Target() const { return Read<FVector>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    uint8_t Kind() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    FRigElementKey Space() const { return Read<FRigElementKey>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x8, Type: StructProperty)

    void SET_Target(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_Kind(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_Space(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x8, Type: StructProperty)
};

// Size: 0x80
struct FRigUnit_AimConstraint_AdvancedSettings
{
public:
    FRigUnit_AimBone_DebugSettings DebugSettings() const { return Read<FRigUnit_AimBone_DebugSettings>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x70, Type: StructProperty)
    uint8_t RotationOrderForFilter() const { return Read<uint8_t>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: EnumProperty)

    void SET_DebugSettings(const FRigUnit_AimBone_DebugSettings& Value) { Write<FRigUnit_AimBone_DebugSettings>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x70, Type: StructProperty)
    void SET_RotationOrderForFilter(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x160
struct FRigUnit_AimConstraintLocalSpaceOffset : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x3, Type: StructProperty)
    FVector AimAxis() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector UpAxis() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FRigUnit_AimConstraint_WorldUp WorldUp() const { return Read<FRigUnit_AimConstraint_WorldUp>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x28, Type: StructProperty)
    TArray<FConstraintParent> Parents() const { return Read<TArray<FConstraintParent>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    FRigUnit_AimConstraint_AdvancedSettings AdvancedSettings() const { return Read<FRigUnit_AimConstraint_AdvancedSettings>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x80, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement WorldUpSpaceCache() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x18, Type: StructProperty)
    FCachedRigElement ChildCache() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x18, Type: StructProperty)
    TArray<FCachedRigElement> ParentCaches() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x10, Type: ArrayProperty)
    bool bIsInitialized() const { return Read<bool>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x1, Type: BoolProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_bMaintainOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_Filter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x3, Type: StructProperty)
    void SET_AimAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_UpAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_WorldUp(const FRigUnit_AimConstraint_WorldUp& Value) { Write<FRigUnit_AimConstraint_WorldUp>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x28, Type: StructProperty)
    void SET_Parents(const TArray<FConstraintParent>& Value) { Write<TArray<FConstraintParent>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_AdvancedSettings(const FRigUnit_AimConstraint_AdvancedSettings& Value) { Write<FRigUnit_AimConstraint_AdvancedSettings>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x80, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: FloatProperty)
    void SET_WorldUpSpaceCache(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x18, Type: StructProperty)
    void SET_ChildCache(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x18, Type: StructProperty)
    void SET_ParentCaches(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc
struct FConstraintParent
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x8
struct FRigUnit_CCDIK_RotationLimit
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    float Limit() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Limit(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xc
struct FRigUnit_CCDIK_RotationLimitPerItem
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    float Limit() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Limit(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x58
struct FRigUnit_CCDIK_WorkData
{
public:
    TArray<FCCDIKChainLink> Chain() const { return Read<TArray<FCCDIKChainLink>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedItems() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> RotationLimitIndex() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<float> RotationLimitsPerItem() const { return Read<TArray<float>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedEffector() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)

    void SET_Chain(const TArray<FCCDIKChainLink>& Value) { Write<TArray<FCCDIKChainLink>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedItems(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_RotationLimitIndex(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_RotationLimitsPerItem(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedEffector(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
};

// Size: 0x110
struct FRigUnit_CCDIK : public FRigUnit_HighlevelBaseMutable
{
public:
    FName StartBone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName EffectorBone() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    FTransform EffectorTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    float Precision() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)
    bool bStartFromTail() const { return Read<bool>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x1, Type: BoolProperty)
    float BaseRotationLimit() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    TArray<FRigUnit_CCDIK_RotationLimit> RotationLimits() const { return Read<TArray<FRigUnit_CCDIK_RotationLimit>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    FRigUnit_CCDIK_WorkData WorkData() const { return Read<FRigUnit_CCDIK_WorkData>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x58, Type: StructProperty)

    void SET_StartBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_EffectorBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_EffectorTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Precision(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_MaxIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
    void SET_bStartFromTail(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x1, Type: BoolProperty)
    void SET_BaseRotationLimit(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_RotationLimits(const TArray<FRigUnit_CCDIK_RotationLimit>& Value) { Write<TArray<FRigUnit_CCDIK_RotationLimit>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_CCDIK_WorkData& Value) { Write<FRigUnit_CCDIK_WorkData>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x58, Type: StructProperty)
};

// Size: 0x110
struct FRigUnit_CCDIKPerItem : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKeyCollection Items() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FTransform EffectorTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    float Precision() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)
    bool bStartFromTail() const { return Read<bool>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x1, Type: BoolProperty)
    float BaseRotationLimit() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    TArray<FRigUnit_CCDIK_RotationLimitPerItem> RotationLimits() const { return Read<TArray<FRigUnit_CCDIK_RotationLimitPerItem>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    FRigUnit_CCDIK_WorkData WorkData() const { return Read<FRigUnit_CCDIK_WorkData>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x58, Type: StructProperty)

    void SET_Items(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_EffectorTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Precision(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_MaxIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
    void SET_bStartFromTail(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x1, Type: BoolProperty)
    void SET_BaseRotationLimit(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_RotationLimits(const TArray<FRigUnit_CCDIK_RotationLimitPerItem>& Value) { Write<TArray<FRigUnit_CCDIK_RotationLimitPerItem>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_CCDIK_WorkData& Value) { Write<FRigUnit_CCDIK_WorkData>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x58, Type: StructProperty)
};

// Size: 0x110
struct FRigUnit_CCDIKItemArray : public FRigUnit_HighlevelBaseMutable
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FTransform EffectorTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    float Precision() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    int32_t MaxIterations() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)
    bool bStartFromTail() const { return Read<bool>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x1, Type: BoolProperty)
    float BaseRotationLimit() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    TArray<FRigUnit_CCDIK_RotationLimitPerItem> RotationLimits() const { return Read<TArray<FRigUnit_CCDIK_RotationLimitPerItem>>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    FRigUnit_CCDIK_WorkData WorkData() const { return Read<FRigUnit_CCDIK_WorkData>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x58, Type: StructProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_EffectorTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Precision(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_MaxIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
    void SET_bStartFromTail(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x1, Type: BoolProperty)
    void SET_BaseRotationLimit(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_RotationLimits(const TArray<FRigUnit_CCDIK_RotationLimitPerItem>& Value) { Write<TArray<FRigUnit_CCDIK_RotationLimitPerItem>>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: ArrayProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_CCDIK_WorkData& Value) { Write<FRigUnit_CCDIK_WorkData>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x58, Type: StructProperty)
};

// Size: 0x50
struct FRigUnit_ChainInfo_Segment
{
public:
    FCachedRigElement StartItem() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    int32_t StartItemIndex() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    FCachedRigElement EndItem() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    int32_t EndItemIndex() const { return Read<int32_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: IntProperty)
    float InitialLength() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float InitialCumLength() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float Length() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    float CumLength() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)

    void SET_StartItem(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_StartItemIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_EndItem(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_EndItemIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: IntProperty)
    void SET_InitialLength(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_InitialCumLength(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_Length(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_CumLength(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x2c
struct FRigUnit_ChainInfo_SegmentInfo
{
public:
    int32_t SegmentIndex() const { return Read<int32_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: IntProperty)
    float SegmentLength() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float SegmentParam() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float SegmentParamLength() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    FRigElementKey SegmentStartItem() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    int32_t SegmentStartItemIndex() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    FRigElementKey SegmentEndItem() const { return Read<FRigElementKey>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x8, Type: StructProperty)
    int32_t SegmentEndItemIndex() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)
    float SegmentStretchFactor() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)

    void SET_SegmentIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: IntProperty)
    void SET_SegmentLength(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_SegmentParam(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_SegmentParamLength(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_SegmentStartItem(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_SegmentStartItemIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_SegmentEndItem(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x8, Type: StructProperty)
    void SET_SegmentEndItemIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
    void SET_SegmentStretchFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xe0
struct FRigUnit_ChainInfo : public FRigUnit_HighlevelBase
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    float Param() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bCalculateStretch() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)
    bool bInitial() const { return Read<bool>(uintptr_t(this) + 0x1d); } // 0x1d (Size: 0x1, Type: BoolProperty)
    bool bDebug() const { return Read<bool>(uintptr_t(this) + 0x1e); } // 0x1e (Size: 0x1, Type: BoolProperty)
    float DebugScale() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    FTransform InterpolatedTransform() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    float ChainLength() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float ParamLength() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)
    float ChainStretchFactor() const { return Read<float>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: FloatProperty)
    FRigUnit_ChainInfo_SegmentInfo SegmentInfo() const { return Read<FRigUnit_ChainInfo_SegmentInfo>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x2c, Type: StructProperty)
    TArray<FCachedRigElement> CachedElements() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_Param(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_bCalculateStretch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
    void SET_bInitial(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d, Value); } // 0x1d (Size: 0x1, Type: BoolProperty)
    void SET_bDebug(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e, Value); } // 0x1e (Size: 0x1, Type: BoolProperty)
    void SET_DebugScale(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_InterpolatedTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_ChainLength(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_ParamLength(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
    void SET_ChainStretchFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: FloatProperty)
    void SET_SegmentInfo(const FRigUnit_ChainInfo_SegmentInfo& Value) { Write<FRigUnit_ChainInfo_SegmentInfo>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x2c, Type: StructProperty)
    void SET_CachedElements(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FRigUnit_DistributeRotation_Rotation
{
public:
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    float Ratio() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_Ratio(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x50
struct FRigUnit_DistributeRotation_WorkData
{
public:
    TArray<FCachedRigElement> CachedItems() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ItemRotationA() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ItemRotationB() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<float> ItemRotationT() const { return Read<TArray<float>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> ItemLocalTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)

    void SET_CachedItems(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemRotationA(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemRotationB(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemRotationT(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemLocalTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x88
struct FRigUnit_DistributeRotation : public FRigUnit_HighlevelBaseMutable
{
public:
    FName StartBone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName EndBone() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    TArray<FRigUnit_DistributeRotation_Rotation> Rotations() const { return Read<TArray<FRigUnit_DistributeRotation_Rotation>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: BoolProperty)
    FRigUnit_DistributeRotation_WorkData WorkData() const { return Read<FRigUnit_DistributeRotation_WorkData>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x50, Type: StructProperty)

    void SET_StartBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_EndBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_Rotations(const TArray<FRigUnit_DistributeRotation_Rotation>& Value) { Write<TArray<FRigUnit_DistributeRotation_Rotation>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_RotationEaseType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_DistributeRotation_WorkData& Value) { Write<FRigUnit_DistributeRotation_WorkData>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x50, Type: StructProperty)
};

// Size: 0x88
struct FRigUnit_DistributeRotationForCollection : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKeyCollection Items() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    TArray<FRigUnit_DistributeRotation_Rotation> Rotations() const { return Read<TArray<FRigUnit_DistributeRotation_Rotation>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    FRigUnit_DistributeRotation_WorkData WorkData() const { return Read<FRigUnit_DistributeRotation_WorkData>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x50, Type: StructProperty)

    void SET_Items(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Rotations(const TArray<FRigUnit_DistributeRotation_Rotation>& Value) { Write<TArray<FRigUnit_DistributeRotation_Rotation>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_RotationEaseType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_WorkData(const FRigUnit_DistributeRotation_WorkData& Value) { Write<FRigUnit_DistributeRotation_WorkData>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x50, Type: StructProperty)
};

// Size: 0x88
struct FRigUnit_DistributeRotationForItemArray : public FRigUnit_HighlevelBaseMutable
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FRigUnit_DistributeRotation_Rotation> Rotations() const { return Read<TArray<FRigUnit_DistributeRotation_Rotation>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    FRigUnit_DistributeRotation_WorkData WorkData() const { return Read<FRigUnit_DistributeRotation_WorkData>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x50, Type: StructProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Rotations(const TArray<FRigUnit_DistributeRotation_Rotation>& Value) { Write<TArray<FRigUnit_DistributeRotation_Rotation>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_RotationEaseType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_WorkData(const FRigUnit_DistributeRotation_WorkData& Value) { Write<FRigUnit_DistributeRotation_WorkData>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x50, Type: StructProperty)
};

// Size: 0x38
struct FRigUnit_FABRIK_WorkData
{
public:
    TArray<FFABRIKChainLink> Chain() const { return Read<TArray<FFABRIKChainLink>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedItems() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedEffector() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)

    void SET_Chain(const TArray<FFABRIKChainLink>& Value) { Write<TArray<FFABRIKChainLink>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedItems(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedEffector(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
};

// Size: 0xd0
struct FRigUnit_FABRIK : public FRigUnit_HighlevelBaseMutable
{
public:
    FName StartBone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName EffectorBone() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    FTransform EffectorTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    float Precision() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)
    int32_t MaxIterations() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)
    FRigUnit_FABRIK_WorkData WorkData() const { return Read<FRigUnit_FABRIK_WorkData>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    bool bSetEffectorTransform() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)

    void SET_StartBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_EffectorBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_EffectorTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Precision(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
    void SET_MaxIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
    void SET_WorkData(const FRigUnit_FABRIK_WorkData& Value) { Write<FRigUnit_FABRIK_WorkData>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_bSetEffectorTransform(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd0
struct FRigUnit_FABRIKPerItem : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKeyCollection Items() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FTransform EffectorTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    float Precision() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)
    int32_t MaxIterations() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)
    FRigUnit_FABRIK_WorkData WorkData() const { return Read<FRigUnit_FABRIK_WorkData>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    bool bSetEffectorTransform() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)

    void SET_Items(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_EffectorTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Precision(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
    void SET_MaxIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
    void SET_WorkData(const FRigUnit_FABRIK_WorkData& Value) { Write<FRigUnit_FABRIK_WorkData>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_bSetEffectorTransform(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xd0
struct FRigUnit_FABRIKItemArray : public FRigUnit_HighlevelBaseMutable
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FTransform EffectorTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    float Precision() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)
    int32_t MaxIterations() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)
    FRigUnit_FABRIK_WorkData WorkData() const { return Read<FRigUnit_FABRIK_WorkData>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x38, Type: StructProperty)
    bool bSetEffectorTransform() const { return Read<bool>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: BoolProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_EffectorTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Precision(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
    void SET_MaxIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
    void SET_WorkData(const FRigUnit_FABRIK_WorkData& Value) { Write<FRigUnit_FABRIK_WorkData>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x38, Type: StructProperty)
    void SET_bSetEffectorTransform(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FRigUnit_FitChainToCurve_Rotation
{
public:
    FQuat Rotation() const { return Read<FQuat>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: StructProperty)
    float Ratio() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_Rotation(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: StructProperty)
    void SET_Ratio(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x90
struct FRigUnit_FitChainToCurve_DebugSettings
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FLinearColor CurveColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FLinearColor SegmentsColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_CurveColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_SegmentsColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
};

// Size: 0x98
struct FRigUnit_FitChainToCurve_WorkData
{
public:
    float ChainLength() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    TArray<FVector> ItemPositions() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<float> ItemSegments() const { return Read<TArray<float>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector> CurvePositions() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<float> CurveSegments() const { return Read<TArray<float>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedItems() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ItemRotationA() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> ItemRotationB() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    TArray<float> ItemRotationT() const { return Read<TArray<float>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> ItemLocalTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)

    void SET_ChainLength(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ItemPositions(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemSegments(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_CurvePositions(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_CurveSegments(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedItems(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemRotationA(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemRotationB(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemRotationT(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemLocalTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x220
struct FRigUnit_FitChainToCurve : public FRigUnit_HighlevelBaseMutable
{
public:
    FName StartBone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName EndBone() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    FRigVMFourPointBezier Bezier() const { return Read<FRigVMFourPointBezier>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x60, Type: StructProperty)
    uint8_t Alignment() const { return Read<uint8_t>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: EnumProperty)
    float Minimum() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    float Maximum() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    int32_t SamplingPrecision() const { return Read<int32_t>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: IntProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x18, Type: StructProperty)
    FVector PoleVectorPosition() const { return Read<FVector>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x18, Type: StructProperty)
    TArray<FRigUnit_FitChainToCurve_Rotation> Rotations() const { return Read<TArray<FRigUnit_FitChainToCurve_Rotation>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType() const { return Read<uint8_t>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    FRigUnit_FitChainToCurve_DebugSettings DebugSettings() const { return Read<FRigUnit_FitChainToCurve_DebugSettings>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x90, Type: StructProperty)
    FRigUnit_FitChainToCurve_WorkData WorkData() const { return Read<FRigUnit_FitChainToCurve_WorkData>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x98, Type: StructProperty)

    void SET_StartBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_EndBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_Bezier(const FRigVMFourPointBezier& Value) { Write<FRigVMFourPointBezier>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x60, Type: StructProperty)
    void SET_Alignment(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: EnumProperty)
    void SET_Minimum(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET_Maximum(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_SamplingPrecision(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: IntProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x18, Type: StructProperty)
    void SET_PoleVectorPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x18, Type: StructProperty)
    void SET_Rotations(const TArray<FRigUnit_FitChainToCurve_Rotation>& Value) { Write<TArray<FRigUnit_FitChainToCurve_Rotation>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: ArrayProperty)
    void SET_RotationEaseType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: BoolProperty)
    void SET_DebugSettings(const FRigUnit_FitChainToCurve_DebugSettings& Value) { Write<FRigUnit_FitChainToCurve_DebugSettings>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x90, Type: StructProperty)
    void SET_WorkData(const FRigUnit_FitChainToCurve_WorkData& Value) { Write<FRigUnit_FitChainToCurve_WorkData>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x98, Type: StructProperty)
};

// Size: 0x230
struct FRigUnit_FitChainToCurvePerItem : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKeyCollection Items() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FRigVMFourPointBezier Bezier() const { return Read<FRigVMFourPointBezier>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t Alignment() const { return Read<uint8_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: EnumProperty)
    float Minimum() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float Maximum() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    int32_t SamplingPrecision() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x18, Type: StructProperty)
    FVector PoleVectorPosition() const { return Read<FVector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)
    TArray<FRigUnit_FitChainToCurve_Rotation> Rotations() const { return Read<TArray<FRigUnit_FitChainToCurve_Rotation>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType() const { return Read<uint8_t>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    FRigUnit_FitChainToCurve_DebugSettings DebugSettings() const { return Read<FRigUnit_FitChainToCurve_DebugSettings>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x90, Type: StructProperty)
    FRigUnit_FitChainToCurve_WorkData WorkData() const { return Read<FRigUnit_FitChainToCurve_WorkData>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x98, Type: StructProperty)

    void SET_Items(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_Bezier(const FRigVMFourPointBezier& Value) { Write<FRigVMFourPointBezier>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Alignment(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: EnumProperty)
    void SET_Minimum(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_Maximum(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_SamplingPrecision(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x18, Type: StructProperty)
    void SET_PoleVectorPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
    void SET_Rotations(const TArray<FRigUnit_FitChainToCurve_Rotation>& Value) { Write<TArray<FRigUnit_FitChainToCurve_Rotation>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    void SET_RotationEaseType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    void SET_DebugSettings(const FRigUnit_FitChainToCurve_DebugSettings& Value) { Write<FRigUnit_FitChainToCurve_DebugSettings>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x90, Type: StructProperty)
    void SET_WorkData(const FRigUnit_FitChainToCurve_WorkData& Value) { Write<FRigUnit_FitChainToCurve_WorkData>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x98, Type: StructProperty)
};

// Size: 0x230
struct FRigUnit_FitChainToCurveItemArray : public FRigUnit_HighlevelBaseMutable
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FRigVMFourPointBezier Bezier() const { return Read<FRigVMFourPointBezier>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    uint8_t Alignment() const { return Read<uint8_t>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: EnumProperty)
    float Minimum() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    float Maximum() const { return Read<float>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: FloatProperty)
    int32_t SamplingPrecision() const { return Read<int32_t>(uintptr_t(this) + 0x8c); } // 0x8c (Size: 0x4, Type: IntProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x18, Type: StructProperty)
    FVector PoleVectorPosition() const { return Read<FVector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)
    TArray<FRigUnit_FitChainToCurve_Rotation> Rotations() const { return Read<TArray<FRigUnit_FitChainToCurve_Rotation>>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    uint8_t RotationEaseType() const { return Read<uint8_t>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    FRigUnit_FitChainToCurve_DebugSettings DebugSettings() const { return Read<FRigUnit_FitChainToCurve_DebugSettings>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x90, Type: StructProperty)
    FRigUnit_FitChainToCurve_WorkData WorkData() const { return Read<FRigUnit_FitChainToCurve_WorkData>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x98, Type: StructProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Bezier(const FRigVMFourPointBezier& Value) { Write<FRigVMFourPointBezier>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_Alignment(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: EnumProperty)
    void SET_Minimum(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_Maximum(const float& Value) { Write<float>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: FloatProperty)
    void SET_SamplingPrecision(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8c, Value); } // 0x8c (Size: 0x4, Type: IntProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x18, Type: StructProperty)
    void SET_PoleVectorPosition(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
    void SET_Rotations(const TArray<FRigUnit_FitChainToCurve_Rotation>& Value) { Write<TArray<FRigUnit_FitChainToCurve_Rotation>>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x10, Type: ArrayProperty)
    void SET_RotationEaseType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    void SET_DebugSettings(const FRigUnit_FitChainToCurve_DebugSettings& Value) { Write<FRigUnit_FitChainToCurve_DebugSettings>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x90, Type: StructProperty)
    void SET_WorkData(const FRigUnit_FitChainToCurve_WorkData& Value) { Write<FRigUnit_FitChainToCurve_WorkData>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x98, Type: StructProperty)
};

// Size: 0x70
struct FRigUnit_ModifyBoneTransforms_PerBone
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_ModifyTransforms_WorkData
{
public:
    TArray<FCachedRigElement> CachedItems() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_CachedItems(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FRigUnit_ModifyBoneTransforms_WorkData : public FRigUnit_ModifyTransforms_WorkData
{
public:
};

// Size: 0x40
struct FRigUnit_ModifyBoneTransforms : public FRigUnit_HighlevelBaseMutable
{
public:
    TArray<FRigUnit_ModifyBoneTransforms_PerBone> BoneToModify() const { return Read<TArray<FRigUnit_ModifyBoneTransforms_PerBone>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float WeightMinimum() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float WeightMaximum() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: EnumProperty)
    FRigUnit_ModifyBoneTransforms_WorkData WorkData() const { return Read<FRigUnit_ModifyBoneTransforms_WorkData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)

    void SET_BoneToModify(const TArray<FRigUnit_ModifyBoneTransforms_PerBone>& Value) { Write<TArray<FRigUnit_ModifyBoneTransforms_PerBone>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_WeightMinimum(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_WeightMaximum(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: EnumProperty)
    void SET_WorkData(const FRigUnit_ModifyBoneTransforms_WorkData& Value) { Write<FRigUnit_ModifyBoneTransforms_WorkData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
};

// Size: 0x70
struct FRigUnit_ModifyTransforms_PerItem
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: StructProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: StructProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_ModifyTransforms : public FRigUnit_HighlevelBaseMutable
{
public:
    TArray<FRigUnit_ModifyTransforms_PerItem> ItemToModify() const { return Read<TArray<FRigUnit_ModifyTransforms_PerItem>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float WeightMinimum() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float WeightMaximum() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    uint8_t Mode() const { return Read<uint8_t>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: EnumProperty)
    FRigUnit_ModifyTransforms_WorkData WorkData() const { return Read<FRigUnit_ModifyTransforms_WorkData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)

    void SET_ItemToModify(const TArray<FRigUnit_ModifyTransforms_PerItem>& Value) { Write<TArray<FRigUnit_ModifyTransforms_PerItem>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_WeightMinimum(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_WeightMaximum(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_Mode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: EnumProperty)
    void SET_WorkData(const FRigUnit_ModifyTransforms_WorkData& Value) { Write<FRigUnit_ModifyTransforms_WorkData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
};

// Size: 0x68
struct FRigUnit_MultiFABRIK_WorkData
{
public:
};

// Size: 0x20
struct FRigUnit_MultiFABRIK_EndEffector
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
};

// Size: 0xa8
struct FRigUnit_MultiFABRIK : public FRigUnit_HighlevelBaseMutable
{
public:
    FName RootBone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    TArray<FRigUnit_MultiFABRIK_EndEffector> Effectors() const { return Read<TArray<FRigUnit_MultiFABRIK_EndEffector>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    float Precision() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x1, Type: BoolProperty)
    int32_t MaxIterations() const { return Read<int32_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: IntProperty)
    FRigUnit_MultiFABRIK_WorkData WorkData() const { return Read<FRigUnit_MultiFABRIK_WorkData>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x68, Type: StructProperty)
    bool bIsInitialized() const { return Read<bool>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x1, Type: BoolProperty)

    void SET_RootBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_Effectors(const TArray<FRigUnit_MultiFABRIK_EndEffector>& Value) { Write<TArray<FRigUnit_MultiFABRIK_EndEffector>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Precision(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x1, Type: BoolProperty)
    void SET_MaxIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: IntProperty)
    void SET_WorkData(const FRigUnit_MultiFABRIK_WorkData& Value) { Write<FRigUnit_MultiFABRIK_WorkData>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x68, Type: StructProperty)
    void SET_bIsInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x48
struct FRigUnit_SlideChain_WorkData
{
public:
    float ChainLength() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    TArray<float> ItemSegments() const { return Read<TArray<float>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    TArray<FCachedRigElement> CachedItems() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> BlendedTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_ChainLength(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_ItemSegments(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedItems(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: ArrayProperty)
    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_BlendedTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x68
struct FRigUnit_SlideChain : public FRigUnit_HighlevelBaseMutable
{
public:
    FName StartBone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName EndBone() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    float SlideAmount() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)
    FRigUnit_SlideChain_WorkData WorkData() const { return Read<FRigUnit_SlideChain_WorkData>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x48, Type: StructProperty)

    void SET_StartBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_EndBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_SlideAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_SlideChain_WorkData& Value) { Write<FRigUnit_SlideChain_WorkData>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x48, Type: StructProperty)
};

// Size: 0x70
struct FRigUnit_SlideChainPerItem : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKeyCollection Items() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    float SlideAmount() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)
    FRigUnit_SlideChain_WorkData WorkData() const { return Read<FRigUnit_SlideChain_WorkData>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x48, Type: StructProperty)

    void SET_Items(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_SlideAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_SlideChain_WorkData& Value) { Write<FRigUnit_SlideChain_WorkData>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x48, Type: StructProperty)
};

// Size: 0x70
struct FRigUnit_SlideChainItemArray : public FRigUnit_HighlevelBaseMutable
{
public:
    TArray<FRigElementKey> Items() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    float SlideAmount() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)
    FRigUnit_SlideChain_WorkData WorkData() const { return Read<FRigUnit_SlideChain_WorkData>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x48, Type: StructProperty)

    void SET_Items(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_SlideAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_SlideChain_WorkData& Value) { Write<FRigUnit_SlideChain_WorkData>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x48, Type: StructProperty)
};

// Size: 0x10
struct FRegionScaleFactors
{
public:
    float PositiveWidth() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float NegativeWidth() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float PositiveHeight() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float NegativeHeight() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_PositiveWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_NegativeWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_PositiveHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_NegativeHeight(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x14
struct FSphericalRegion
{
public:
};

// Size: 0x10
struct FSphericalPoseReaderDebugSettings
{
public:
    bool bDrawDebug() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bDraw2D() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bDrawLocalAxes() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)
    float DebugScale() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    int32_t DebugSegments() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    float DebugThickness() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_bDrawDebug(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bDraw2D(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bDrawLocalAxes(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
    void SET_DebugScale(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_DebugSegments(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_DebugThickness(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1a0
struct FRigUnit_SphericalPoseReader : public FRigUnit_HighlevelBaseMutable
{
public:
    float OutputParam() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    FRigElementKey DriverItem() const { return Read<FRigElementKey>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x8, Type: StructProperty)
    FVector DriverAxis() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector RotationOffset() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    float ActiveRegionSize() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    FRegionScaleFactors ActiveRegionScaleFactors() const { return Read<FRegionScaleFactors>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x10, Type: StructProperty)
    float FalloffSize() const { return Read<float>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: FloatProperty)
    FRegionScaleFactors FalloffRegionScaleFactors() const { return Read<FRegionScaleFactors>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)
    bool FlipWidthScaling() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)
    bool FlipHeightScaling() const { return Read<bool>(uintptr_t(this) + 0x79); } // 0x79 (Size: 0x1, Type: BoolProperty)
    FRigElementKey OptionalParentItem() const { return Read<FRigElementKey>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x8, Type: StructProperty)
    FSphericalPoseReaderDebugSettings Debug() const { return Read<FSphericalPoseReaderDebugSettings>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x10, Type: StructProperty)
    FSphericalRegion InnerRegion() const { return Read<FSphericalRegion>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x14, Type: StructProperty)
    FSphericalRegion OuterRegion() const { return Read<FSphericalRegion>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x14, Type: StructProperty)
    FVector DriverNormal() const { return Read<FVector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)
    FVector Driver2D() const { return Read<FVector>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)
    FCachedRigElement DriverCache() const { return Read<FCachedRigElement>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)
    FCachedRigElement OptionalParentCache() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x18, Type: StructProperty)
    FTransform LocalDriverTransformInit() const { return Read<FTransform>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x60, Type: StructProperty)
    FVector CachedRotationOffset() const { return Read<FVector>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x18, Type: StructProperty)
    bool bCachedInitTransforms() const { return Read<bool>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x1, Type: BoolProperty)

    void SET_OutputParam(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_DriverItem(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x8, Type: StructProperty)
    void SET_DriverAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_RotationOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_ActiveRegionSize(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_ActiveRegionScaleFactors(const FRegionScaleFactors& Value) { Write<FRegionScaleFactors>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x10, Type: StructProperty)
    void SET_FalloffSize(const float& Value) { Write<float>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: FloatProperty)
    void SET_FalloffRegionScaleFactors(const FRegionScaleFactors& Value) { Write<FRegionScaleFactors>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
    void SET_FlipWidthScaling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
    void SET_FlipHeightScaling(const bool& Value) { Write<bool>(uintptr_t(this) + 0x79, Value); } // 0x79 (Size: 0x1, Type: BoolProperty)
    void SET_OptionalParentItem(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x8, Type: StructProperty)
    void SET_Debug(const FSphericalPoseReaderDebugSettings& Value) { Write<FSphericalPoseReaderDebugSettings>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x10, Type: StructProperty)
    void SET_InnerRegion(const FSphericalRegion& Value) { Write<FSphericalRegion>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x14, Type: StructProperty)
    void SET_OuterRegion(const FSphericalRegion& Value) { Write<FSphericalRegion>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x14, Type: StructProperty)
    void SET_DriverNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
    void SET_Driver2D(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
    void SET_DriverCache(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
    void SET_OptionalParentCache(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x18, Type: StructProperty)
    void SET_LocalDriverTransformInit(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x60, Type: StructProperty)
    void SET_CachedRotationOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x18, Type: StructProperty)
    void SET_bCachedInitTransforms(const bool& Value) { Write<bool>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
struct FRigUnit_SpringIK_DebugSettings
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
};

// Size: 0xb0
struct FRigUnit_SpringIK_WorkData
{
public:
    TArray<FCachedRigElement> CachedBones() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    FCachedRigElement CachedPoleVector() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    TArray<FTransform> Transforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    FCRSimPointContainer Simulation() const { return Read<FCRSimPointContainer>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x78, Type: StructProperty)

    void SET_CachedBones(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_CachedPoleVector(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_Transforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_Simulation(const FCRSimPointContainer& Value) { Write<FCRSimPointContainer>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x78, Type: StructProperty)
};

// Size: 0x1c0
struct FRigUnit_SpringIK : public FRigUnit_HighlevelBaseMutable
{
public:
    FName StartBone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName EndBone() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    float HierarchyStrength() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float EffectorStrength() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float EffectorRatio() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float RootStrength() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float RootRatio() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float Damping() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    FVector PoleVector() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    bool bFlipPolePlane() const { return Read<bool>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: BoolProperty)
    uint8_t PoleVectorKind() const { return Read<uint8_t>(uintptr_t(this) + 0x49); } // 0x49 (Size: 0x1, Type: EnumProperty)
    FName PoleVectorSpace() const { return Read<FName>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: NameProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    bool bLiveSimulation() const { return Read<bool>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: BoolProperty)
    int32_t Iterations() const { return Read<int32_t>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: IntProperty)
    bool bLimitLocalPosition() const { return Read<bool>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x1, Type: BoolProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x89); } // 0x89 (Size: 0x1, Type: BoolProperty)
    FRigUnit_SpringIK_DebugSettings DebugSettings() const { return Read<FRigUnit_SpringIK_DebugSettings>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x80, Type: StructProperty)
    FRigUnit_SpringIK_WorkData WorkData() const { return Read<FRigUnit_SpringIK_WorkData>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0xb0, Type: StructProperty)

    void SET_StartBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_EndBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_HierarchyStrength(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_EffectorStrength(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_EffectorRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_RootStrength(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_RootRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_Damping(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_PoleVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_bFlipPolePlane(const bool& Value) { Write<bool>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: BoolProperty)
    void SET_PoleVectorKind(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x49, Value); } // 0x49 (Size: 0x1, Type: EnumProperty)
    void SET_PoleVectorSpace(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: NameProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_bLiveSimulation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: BoolProperty)
    void SET_Iterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: IntProperty)
    void SET_bLimitLocalPosition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x1, Type: BoolProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x89, Value); } // 0x89 (Size: 0x1, Type: BoolProperty)
    void SET_DebugSettings(const FRigUnit_SpringIK_DebugSettings& Value) { Write<FRigUnit_SpringIK_DebugSettings>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x80, Type: StructProperty)
    void SET_WorkData(const FRigUnit_SpringIK_WorkData& Value) { Write<FRigUnit_SpringIK_WorkData>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0xb0, Type: StructProperty)
};

// Size: 0x70
struct FConstraintTarget
{
public:
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x60, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    bool bMaintainOffset() const { return Read<bool>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x1, Type: BoolProperty)
    FTransformFilter Filter() const { return Read<FTransformFilter>(uintptr_t(this) + 0x65); } // 0x65 (Size: 0x9, Type: StructProperty)

    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x60, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_bMaintainOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x1, Type: BoolProperty)
    void SET_Filter(const FTransformFilter& Value) { Write<FTransformFilter>(uintptr_t(this) + 0x65, Value); } // 0x65 (Size: 0x9, Type: StructProperty)
};

// Size: 0x60
struct FRigUnit_TransformConstraint_WorkData
{
public:
    TArray<FConstraintData> ConstraintData() const { return Read<TArray<FConstraintData>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TMap<int32_t, int32_t> ConstraintDataToTargets() const { return Read<TMap<int32_t, int32_t>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x50, Type: MapProperty)

    void SET_ConstraintData(const TArray<FConstraintData>& Value) { Write<TArray<FConstraintData>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ConstraintDataToTargets(const TMap<int32_t, int32_t>& Value) { Write<TMap<int32_t, int32_t>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x50, Type: MapProperty)
};

// Size: 0x100
struct FRigUnit_TransformConstraint : public FRigUnit_HighlevelBaseMutable
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    uint8_t BaseTransformSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: EnumProperty)
    FTransform BaseTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FName BaseBone() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    TArray<FConstraintTarget> Targets() const { return Read<TArray<FConstraintTarget>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    bool bUseInitialTransforms() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)
    FRigUnit_TransformConstraint_WorkData WorkData() const { return Read<FRigUnit_TransformConstraint_WorkData>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x60, Type: StructProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_BaseTransformSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: EnumProperty)
    void SET_BaseTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_BaseBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET_Targets(const TArray<FConstraintTarget>& Value) { Write<TArray<FConstraintTarget>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_bUseInitialTransforms(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_TransformConstraint_WorkData& Value) { Write<FRigUnit_TransformConstraint_WorkData>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x60, Type: StructProperty)
};

// Size: 0x100
struct FRigUnit_TransformConstraintPerItem : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Item() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    uint8_t BaseTransformSpace() const { return Read<uint8_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: EnumProperty)
    FTransform BaseTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FRigElementKey BaseItem() const { return Read<FRigElementKey>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: StructProperty)
    TArray<FConstraintTarget> Targets() const { return Read<TArray<FConstraintTarget>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    bool bUseInitialTransforms() const { return Read<bool>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x1, Type: BoolProperty)
    FRigUnit_TransformConstraint_WorkData WorkData() const { return Read<FRigUnit_TransformConstraint_WorkData>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x60, Type: StructProperty)

    void SET_Item(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_BaseTransformSpace(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: EnumProperty)
    void SET_BaseTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_BaseItem(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: StructProperty)
    void SET_Targets(const TArray<FConstraintTarget>& Value) { Write<TArray<FConstraintTarget>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET_bUseInitialTransforms(const bool& Value) { Write<bool>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_TransformConstraint_WorkData& Value) { Write<FRigUnit_TransformConstraint_WorkData>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x60, Type: StructProperty)
};

// Size: 0x2
struct FRigUnit_ParentConstraint_AdvancedSettings
{
public:
    uint8_t InterpolationType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t RotationOrderForFilter() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)

    void SET_InterpolationType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_RotationOrderForFilter(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x68
struct FRigUnit_ParentConstraint : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FTransformFilter Filter() const { return Read<FTransformFilter>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x9, Type: StructProperty)
    TArray<FConstraintParent> Parents() const { return Read<TArray<FConstraintParent>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    FRigUnit_ParentConstraint_AdvancedSettings AdvancedSettings() const { return Read<FRigUnit_ParentConstraint_AdvancedSettings>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x2, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    FCachedRigElement ChildCache() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    TArray<FCachedRigElement> ParentCaches() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: ArrayProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_bMaintainOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_Filter(const FTransformFilter& Value) { Write<FTransformFilter>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x9, Type: StructProperty)
    void SET_Parents(const TArray<FConstraintParent>& Value) { Write<TArray<FConstraintParent>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET_AdvancedSettings(const FRigUnit_ParentConstraint_AdvancedSettings& Value) { Write<FRigUnit_ParentConstraint_AdvancedSettings>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x2, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_ChildCache(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_ParentCaches(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1
struct FRigUnit_ParentConstraintMath_AdvancedSettings
{
public:
    uint8_t InterpolationType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)

    void SET_InterpolationType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x100
struct FRigUnit_ParentConstraintMath : public FRigUnit_HighlevelBase
{
public:
    FTransform Input() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    TArray<FConstraintParent> Parents() const { return Read<TArray<FConstraintParent>>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    FRigUnit_ParentConstraintMath_AdvancedSettings AdvancedSettings() const { return Read<FRigUnit_ParentConstraintMath_AdvancedSettings>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x1, Type: StructProperty)
    FTransform Output() const { return Read<FTransform>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x60, Type: StructProperty)
    TArray<FCachedRigElement> ParentCaches() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: ArrayProperty)

    void SET_Input(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_Parents(const TArray<FConstraintParent>& Value) { Write<TArray<FConstraintParent>>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x10, Type: ArrayProperty)
    void SET_AdvancedSettings(const FRigUnit_ParentConstraintMath_AdvancedSettings& Value) { Write<FRigUnit_ParentConstraintMath_AdvancedSettings>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x1, Type: StructProperty)
    void SET_Output(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x60, Type: StructProperty)
    void SET_ParentCaches(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FRigUnit_PositionConstraint : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x3, Type: StructProperty)
    TArray<FConstraintParent> Parents() const { return Read<TArray<FConstraintParent>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_bMaintainOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_Filter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x3, Type: StructProperty)
    void SET_Parents(const TArray<FConstraintParent>& Value) { Write<TArray<FConstraintParent>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x60
struct FRigUnit_PositionConstraintLocalSpaceOffset : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x3, Type: StructProperty)
    TArray<FConstraintParent> Parents() const { return Read<TArray<FConstraintParent>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement ChildCache() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    TArray<FCachedRigElement> ParentCaches() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_bMaintainOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_Filter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x3, Type: StructProperty)
    void SET_Parents(const TArray<FConstraintParent>& Value) { Write<TArray<FConstraintParent>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_ChildCache(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_ParentCaches(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2
struct FRigUnit_RotationConstraint_AdvancedSettings
{
public:
    uint8_t InterpolationType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t RotationOrderForFilter() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)

    void SET_InterpolationType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_RotationOrderForFilter(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x38
struct FRigUnit_RotationConstraint : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x3, Type: StructProperty)
    TArray<FConstraintParent> Parents() const { return Read<TArray<FConstraintParent>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    FRigUnit_RotationConstraint_AdvancedSettings AdvancedSettings() const { return Read<FRigUnit_RotationConstraint_AdvancedSettings>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x2, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_bMaintainOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_Filter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x3, Type: StructProperty)
    void SET_Parents(const TArray<FConstraintParent>& Value) { Write<TArray<FConstraintParent>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_AdvancedSettings(const FRigUnit_RotationConstraint_AdvancedSettings& Value) { Write<FRigUnit_RotationConstraint_AdvancedSettings>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x2, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x60
struct FRigUnit_RotationConstraintLocalSpaceOffset : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x3, Type: StructProperty)
    TArray<FConstraintParent> Parents() const { return Read<TArray<FConstraintParent>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    FRigUnit_RotationConstraint_AdvancedSettings AdvancedSettings() const { return Read<FRigUnit_RotationConstraint_AdvancedSettings>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x2, Type: StructProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement ChildCache() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    TArray<FCachedRigElement> ParentCaches() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_bMaintainOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_Filter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x3, Type: StructProperty)
    void SET_Parents(const TArray<FConstraintParent>& Value) { Write<TArray<FConstraintParent>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_AdvancedSettings(const FRigUnit_RotationConstraint_AdvancedSettings& Value) { Write<FRigUnit_RotationConstraint_AdvancedSettings>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x2, Type: StructProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_ChildCache(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_ParentCaches(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x38
struct FRigUnit_ScaleConstraint : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x3, Type: StructProperty)
    TArray<FConstraintParent> Parents() const { return Read<TArray<FConstraintParent>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_bMaintainOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_Filter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x3, Type: StructProperty)
    void SET_Parents(const TArray<FConstraintParent>& Value) { Write<TArray<FConstraintParent>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x60
struct FRigUnit_ScaleConstraintLocalSpaceOffset : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey Child() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    bool bMaintainOffset() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    FFilterOptionPerAxis Filter() const { return Read<FFilterOptionPerAxis>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x3, Type: StructProperty)
    TArray<FConstraintParent> Parents() const { return Read<TArray<FConstraintParent>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    FCachedRigElement ChildCache() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    TArray<FCachedRigElement> ParentCaches() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x10, Type: ArrayProperty)

    void SET_Child(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_bMaintainOffset(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_Filter(const FFilterOptionPerAxis& Value) { Write<FFilterOptionPerAxis>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x3, Type: StructProperty)
    void SET_Parents(const TArray<FConstraintParent>& Value) { Write<TArray<FConstraintParent>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_ChildCache(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_ParentCaches(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FRigUnit_TwistBones_WorkData
{
public:
    TArray<FCachedRigElement> CachedItems() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<float> ItemRatios() const { return Read<TArray<float>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FTransform> ItemTransforms() const { return Read<TArray<FTransform>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_CachedItems(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemRatios(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_ItemTransforms(const TArray<FTransform>& Value) { Write<TArray<FTransform>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x88
struct FRigUnit_TwistBones : public FRigUnit_HighlevelBaseMutable
{
public:
    FName StartBone() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName EndBone() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    FVector TwistAxis() const { return Read<FVector>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x18, Type: StructProperty)
    FVector PoleAxis() const { return Read<FVector>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x18, Type: StructProperty)
    uint8_t TwistEaseType() const { return Read<uint8_t>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    FRigUnit_TwistBones_WorkData WorkData() const { return Read<FRigUnit_TwistBones_WorkData>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x30, Type: StructProperty)

    void SET_StartBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_EndBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_TwistAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x18, Type: StructProperty)
    void SET_PoleAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x18, Type: StructProperty)
    void SET_TwistEaseType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_TwistBones_WorkData& Value) { Write<FRigUnit_TwistBones_WorkData>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x30, Type: StructProperty)
};

// Size: 0x90
struct FRigUnit_TwistBonesPerItem : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKeyCollection Items() const { return Read<FRigElementKeyCollection>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FVector TwistAxis() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector PoleAxis() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    uint8_t TwistEaseType() const { return Read<uint8_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: EnumProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x1, Type: BoolProperty)
    FRigUnit_TwistBones_WorkData WorkData() const { return Read<FRigUnit_TwistBones_WorkData>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x30, Type: StructProperty)

    void SET_Items(const FRigElementKeyCollection& Value) { Write<FRigElementKeyCollection>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_TwistAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_PoleAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_TwistEaseType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: EnumProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x1, Type: BoolProperty)
    void SET_WorkData(const FRigUnit_TwistBones_WorkData& Value) { Write<FRigUnit_TwistBones_WorkData>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x30, Type: StructProperty)
};

// Size: 0x70
struct FRigUnit_TwoBoneIKSimple_DebugSettings
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
};

// Size: 0x1d0
struct FRigUnit_TwoBoneIKSimple : public FRigUnit_HighlevelBaseMutable
{
public:
    FName BoneA() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName BoneB() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    FName EffectorBone() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    FTransform Effector() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x18, Type: StructProperty)
    float SecondaryAxisWeight() const { return Read<float>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    FVector PoleVector() const { return Read<FVector>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x18, Type: StructProperty)
    uint8_t PoleVectorKind() const { return Read<uint8_t>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: EnumProperty)
    FName PoleVectorSpace() const { return Read<FName>(uintptr_t(this) + 0xd4); } // 0xd4 (Size: 0x4, Type: NameProperty)
    bool bEnableStretch() const { return Read<bool>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: BoolProperty)
    float StretchStartRatio() const { return Read<float>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: FloatProperty)
    float StretchMaximumRatio() const { return Read<float>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    float BoneALength() const { return Read<float>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    float BoneBLength() const { return Read<float>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    FRigUnit_TwoBoneIKSimple_DebugSettings DebugSettings() const { return Read<FRigUnit_TwoBoneIKSimple_DebugSettings>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x70, Type: StructProperty)
    FCachedRigElement CachedBoneAIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedBoneBIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedEffectorBoneIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedPoleVectorSpaceIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x18, Type: StructProperty)

    void SET_BoneA(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET_BoneB(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET_EffectorBone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET_Effector(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxisWeight(const float& Value) { Write<float>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: FloatProperty)
    void SET_PoleVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x18, Type: StructProperty)
    void SET_PoleVectorKind(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: EnumProperty)
    void SET_PoleVectorSpace(const FName& Value) { Write<FName>(uintptr_t(this) + 0xd4, Value); } // 0xd4 (Size: 0x4, Type: NameProperty)
    void SET_bEnableStretch(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: BoolProperty)
    void SET_StretchStartRatio(const float& Value) { Write<float>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: FloatProperty)
    void SET_StretchMaximumRatio(const float& Value) { Write<float>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: FloatProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: FloatProperty)
    void SET_BoneALength(const float& Value) { Write<float>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: FloatProperty)
    void SET_BoneBLength(const float& Value) { Write<float>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    void SET_DebugSettings(const FRigUnit_TwoBoneIKSimple_DebugSettings& Value) { Write<FRigUnit_TwoBoneIKSimple_DebugSettings>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x70, Type: StructProperty)
    void SET_CachedBoneAIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x18, Type: StructProperty)
    void SET_CachedBoneBIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x18, Type: StructProperty)
    void SET_CachedEffectorBoneIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x18, Type: StructProperty)
    void SET_CachedPoleVectorSpaceIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x1e0
struct FRigUnit_TwoBoneIKSimplePerItem : public FRigUnit_HighlevelBaseMutable
{
public:
    FRigElementKey ItemA() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)
    FRigElementKey ItemB() const { return Read<FRigElementKey>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: StructProperty)
    FRigElementKey EffectorItem() const { return Read<FRigElementKey>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: StructProperty)
    FTransform Effector() const { return Read<FTransform>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x60, Type: StructProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x18, Type: StructProperty)
    float SecondaryAxisWeight() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    FVector PoleVector() const { return Read<FVector>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x18, Type: StructProperty)
    uint8_t PoleVectorKind() const { return Read<uint8_t>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: EnumProperty)
    FRigElementKey PoleVectorSpace() const { return Read<FRigElementKey>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x8, Type: StructProperty)
    bool bEnableStretch() const { return Read<bool>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x1, Type: BoolProperty)
    float StretchStartRatio() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    float StretchMaximumRatio() const { return Read<float>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    float Weight() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    float ItemALength() const { return Read<float>(uintptr_t(this) + 0xfc); } // 0xfc (Size: 0x4, Type: FloatProperty)
    float ItemBLength() const { return Read<float>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x4, Type: FloatProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x1, Type: BoolProperty)
    FRigUnit_TwoBoneIKSimple_DebugSettings DebugSettings() const { return Read<FRigUnit_TwoBoneIKSimple_DebugSettings>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x70, Type: StructProperty)
    FCachedRigElement CachedItemAIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedItemBIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedEffectorItemIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x18, Type: StructProperty)
    FCachedRigElement CachedPoleVectorSpaceIndex() const { return Read<FCachedRigElement>(uintptr_t(this) + 0x1c8); } // 0x1c8 (Size: 0x18, Type: StructProperty)

    void SET_ItemA(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
    void SET_ItemB(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: StructProperty)
    void SET_EffectorItem(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: StructProperty)
    void SET_Effector(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x60, Type: StructProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxisWeight(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_PoleVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x18, Type: StructProperty)
    void SET_PoleVectorKind(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: EnumProperty)
    void SET_PoleVectorSpace(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x8, Type: StructProperty)
    void SET_bEnableStretch(const bool& Value) { Write<bool>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x1, Type: BoolProperty)
    void SET_StretchStartRatio(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_StretchMaximumRatio(const float& Value) { Write<float>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    void SET_Weight(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    void SET_ItemALength(const float& Value) { Write<float>(uintptr_t(this) + 0xfc, Value); } // 0xfc (Size: 0x4, Type: FloatProperty)
    void SET_ItemBLength(const float& Value) { Write<float>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x4, Type: FloatProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x1, Type: BoolProperty)
    void SET_DebugSettings(const FRigUnit_TwoBoneIKSimple_DebugSettings& Value) { Write<FRigUnit_TwoBoneIKSimple_DebugSettings>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x70, Type: StructProperty)
    void SET_CachedItemAIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x18, Type: StructProperty)
    void SET_CachedItemBIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x18, Type: StructProperty)
    void SET_CachedEffectorItemIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x18, Type: StructProperty)
    void SET_CachedPoleVectorSpaceIndex(const FCachedRigElement& Value) { Write<FCachedRigElement>(uintptr_t(this) + 0x1c8, Value); } // 0x1c8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x80
struct FRigUnit_TwoBoneIKSimpleVectors : public FRigUnit_HighlevelBase
{
public:
    FVector Root() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector PoleVector() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    FVector Effector() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    bool bEnableStretch() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    float StretchStartRatio() const { return Read<float>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: FloatProperty)
    float StretchMaximumRatio() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    float BoneALength() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    float BoneBLength() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    FVector Elbow() const { return Read<FVector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)

    void SET_Root(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_PoleVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Effector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_bEnableStretch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_StretchStartRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: FloatProperty)
    void SET_StretchMaximumRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_BoneALength(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_BoneBLength(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_Elbow(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
};

// Size: 0x1a0
struct FRigUnit_TwoBoneIKSimpleTransforms : public FRigUnit_HighlevelBase
{
public:
    FTransform Root() const { return Read<FTransform>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x60, Type: StructProperty)
    FVector PoleVector() const { return Read<FVector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FTransform Effector() const { return Read<FTransform>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x60, Type: StructProperty)
    FVector PrimaryAxis() const { return Read<FVector>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAxis() const { return Read<FVector>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x18, Type: StructProperty)
    float SecondaryAxisWeight() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)
    bool bEnableStretch() const { return Read<bool>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x1, Type: BoolProperty)
    float StretchStartRatio() const { return Read<float>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x4, Type: FloatProperty)
    float StretchMaximumRatio() const { return Read<float>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: FloatProperty)
    float BoneALength() const { return Read<float>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x4, Type: FloatProperty)
    float BoneBLength() const { return Read<float>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x4, Type: FloatProperty)
    FTransform Elbow() const { return Read<FTransform>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x60, Type: StructProperty)

    void SET_Root(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x60, Type: StructProperty)
    void SET_PoleVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_Effector(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x60, Type: StructProperty)
    void SET_PrimaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAxisWeight(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
    void SET_bEnableStretch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x1, Type: BoolProperty)
    void SET_StretchStartRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x4, Type: FloatProperty)
    void SET_StretchMaximumRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: FloatProperty)
    void SET_BoneALength(const float& Value) { Write<float>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x4, Type: FloatProperty)
    void SET_BoneBLength(const float& Value) { Write<float>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x4, Type: FloatProperty)
    void SET_Elbow(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x60, Type: StructProperty)
};

// Size: 0x20
struct FRigUnit_GetCandidates : public FRigUnit
{
public:
    FRigElementKey Connector() const { return Read<FRigElementKey>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: StructProperty)
    TArray<FRigElementKey> Candidates() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)

    void SET_Connector(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: StructProperty)
    void SET_Candidates(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x30
struct FRigUnit_DiscardMatches : public FRigUnitMutable
{
public:
    TArray<FRigElementKey> Excluded() const { return Read<TArray<FRigElementKey>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    FString Message() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)

    void SET_Excluded(const TArray<FRigElementKey>& Value) { Write<TArray<FRigElementKey>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Message(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
};

// Size: 0x18
struct FRigUnit_SetDefaultMatch : public FRigUnitMutable
{
public:
    FRigElementKey Default() const { return Read<FRigElementKey>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)

    void SET_Default(const FRigElementKey& Value) { Write<FRigElementKey>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
};

// Size: 0x200
struct FRigUnit_ConnectorExecution : public FRigUnit
{
public:
    FControlRigExecuteContext ExecuteContext() const { return Read<FControlRigExecuteContext>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1f0, Type: StructProperty)

    void SET_ExecuteContext(const FControlRigExecuteContext& Value) { Write<FControlRigExecuteContext>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1f0, Type: StructProperty)
};

// Size: 0x80
struct FRigUnit_PointSimulation_DebugSettings
{
public:
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float CollisionScale() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bDrawPointsAsSpheres() const { return Read<bool>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: BoolProperty)
    FLinearColor Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FTransform WorldOffset() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)

    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_CollisionScale(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_bDrawPointsAsSpheres(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: BoolProperty)
    void SET_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_WorldOffset(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
};

// Size: 0x10
struct FRigUnit_PointSimulation_BoneTarget
{
public:
    FName bone() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    int32_t TranslationPoint() const { return Read<int32_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: IntProperty)
    int32_t PrimaryAimPoint() const { return Read<int32_t>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: IntProperty)
    int32_t SecondaryAimPoint() const { return Read<int32_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: IntProperty)

    void SET_bone(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_TranslationPoint(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: IntProperty)
    void SET_PrimaryAimPoint(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: IntProperty)
    void SET_SecondaryAimPoint(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: IntProperty)
};

// Size: 0x88
struct FRigUnit_PointSimulation_WorkData
{
public:
    FCRSimPointContainer Simulation() const { return Read<FCRSimPointContainer>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x78, Type: StructProperty)
    TArray<FCachedRigElement> BoneIndices() const { return Read<TArray<FCachedRigElement>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_Simulation(const FCRSimPointContainer& Value) { Write<FCRSimPointContainer>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x78, Type: StructProperty)
    void SET_BoneIndices(const TArray<FCachedRigElement>& Value) { Write<TArray<FCachedRigElement>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x220
struct FRigUnit_PointSimulation : public FRigVMFunction_SimBaseMutable
{
public:
    TArray<FRigVMSimPoint> Points() const { return Read<TArray<FRigVMSimPoint>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimLinearSpring> Links() const { return Read<TArray<FCRSimLinearSpring>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimPointForce> Forces() const { return Read<TArray<FCRSimPointForce>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    TArray<FCRSimSoftCollision> CollisionVolumes() const { return Read<TArray<FCRSimSoftCollision>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    float SimulatedStepsPerSecond() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)
    uint8_t IntegratorType() const { return Read<uint8_t>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x1, Type: EnumProperty)
    float VerletBlend() const { return Read<float>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: FloatProperty)
    TArray<FRigUnit_PointSimulation_BoneTarget> BoneTargets() const { return Read<TArray<FRigUnit_PointSimulation_BoneTarget>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    bool bLimitLocalPosition() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)
    bool bPropagateToChildren() const { return Read<bool>(uintptr_t(this) + 0x71); } // 0x71 (Size: 0x1, Type: BoolProperty)
    FVector PrimaryAimAxis() const { return Read<FVector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)
    FVector SecondaryAimAxis() const { return Read<FVector>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    FRigUnit_PointSimulation_DebugSettings DebugSettings() const { return Read<FRigUnit_PointSimulation_DebugSettings>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x80, Type: StructProperty)
    FRigVMFourPointBezier Bezier() const { return Read<FRigVMFourPointBezier>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x60, Type: StructProperty)
    FRigUnit_PointSimulation_WorkData WorkData() const { return Read<FRigUnit_PointSimulation_WorkData>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x88, Type: StructProperty)

    void SET_Points(const TArray<FRigVMSimPoint>& Value) { Write<TArray<FRigVMSimPoint>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Links(const TArray<FCRSimLinearSpring>& Value) { Write<TArray<FCRSimLinearSpring>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_Forces(const TArray<FCRSimPointForce>& Value) { Write<TArray<FCRSimPointForce>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_CollisionVolumes(const TArray<FCRSimSoftCollision>& Value) { Write<TArray<FCRSimSoftCollision>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x10, Type: ArrayProperty)
    void SET_SimulatedStepsPerSecond(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
    void SET_IntegratorType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x1, Type: EnumProperty)
    void SET_VerletBlend(const float& Value) { Write<float>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: FloatProperty)
    void SET_BoneTargets(const TArray<FRigUnit_PointSimulation_BoneTarget>& Value) { Write<TArray<FRigUnit_PointSimulation_BoneTarget>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET_bLimitLocalPosition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
    void SET_bPropagateToChildren(const bool& Value) { Write<bool>(uintptr_t(this) + 0x71, Value); } // 0x71 (Size: 0x1, Type: BoolProperty)
    void SET_PrimaryAimAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
    void SET_SecondaryAimAxis(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_DebugSettings(const FRigUnit_PointSimulation_DebugSettings& Value) { Write<FRigUnit_PointSimulation_DebugSettings>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x80, Type: StructProperty)
    void SET_Bezier(const FRigVMFourPointBezier& Value) { Write<FRigVMFourPointBezier>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x60, Type: StructProperty)
    void SET_WorkData(const FRigUnit_PointSimulation_WorkData& Value) { Write<FRigUnit_PointSimulation_WorkData>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x88, Type: StructProperty)
};

// Size: 0x30
struct FRigUnit_SpringInterp : public FRigVMFunction_SimBase
{
public:
    float Current() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Target() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float Stiffness() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float CriticalDamping() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float Mass() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float Result() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    FFloatSpringState SpringState() const { return Read<FFloatSpringState>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0xc, Type: StructProperty)

    void SET_Current(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Target(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Stiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_CriticalDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_Mass(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_Result(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_SpringState(const FFloatSpringState& Value) { Write<FFloatSpringState>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0xc, Type: StructProperty)
};

// Size: 0x98
struct FRigUnit_SpringInterpVector : public FRigVMFunction_SimBase
{
public:
    FVector Current() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    FVector Target() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    float Stiffness() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    float CriticalDamping() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float Mass() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    FVector Result() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    FVectorSpringState SpringState() const { return Read<FVectorSpringState>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x38, Type: StructProperty)

    void SET_Current(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Target(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_Stiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_CriticalDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_Mass(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_Result(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_SpringState(const FVectorSpringState& Value) { Write<FVectorSpringState>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x38, Type: StructProperty)
};

// Size: 0x40
struct FRigUnit_SpringInterpV2 : public FRigVMFunction_SimBase
{
public:
    float Target() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Strength() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float CriticalDamping() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float Force() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    bool bUseCurrentInput() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    float Current() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float TargetVelocityAmount() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    bool bInitializeFromTarget() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)
    float Result() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float Velocity() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float SimulatedResult() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    FFloatSpringState SpringState() const { return Read<FFloatSpringState>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0xc, Type: StructProperty)

    void SET_Target(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Strength(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_CriticalDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_Force(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_bUseCurrentInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET_Current(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_TargetVelocityAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_bInitializeFromTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
    void SET_Result(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_Velocity(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_SimulatedResult(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_SpringState(const FFloatSpringState& Value) { Write<FFloatSpringState>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0xc, Type: StructProperty)
};

// Size: 0xe8
struct FRigUnit_SpringInterpVectorV2 : public FRigVMFunction_SimBase
{
public:
    FVector Target() const { return Read<FVector>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x18, Type: StructProperty)
    float Strength() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float CriticalDamping() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    FVector Force() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    bool bUseCurrentInput() const { return Read<bool>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x1, Type: BoolProperty)
    FVector Current() const { return Read<FVector>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x18, Type: StructProperty)
    float TargetVelocityAmount() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    bool bInitializeFromTarget() const { return Read<bool>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x1, Type: BoolProperty)
    FVector Result() const { return Read<FVector>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x18, Type: StructProperty)
    FVector Velocity() const { return Read<FVector>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x18, Type: StructProperty)
    FVector SimulatedResult() const { return Read<FVector>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x18, Type: StructProperty)
    FVectorSpringState SpringState() const { return Read<FVectorSpringState>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x38, Type: StructProperty)

    void SET_Target(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x18, Type: StructProperty)
    void SET_Strength(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_CriticalDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_Force(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_bUseCurrentInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x1, Type: BoolProperty)
    void SET_Current(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x18, Type: StructProperty)
    void SET_TargetVelocityAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_bInitializeFromTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x1, Type: BoolProperty)
    void SET_Result(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x18, Type: StructProperty)
    void SET_Velocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x18, Type: StructProperty)
    void SET_SimulatedResult(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x18, Type: StructProperty)
    void SET_SpringState(const FVectorSpringState& Value) { Write<FVectorSpringState>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x38, Type: StructProperty)
};

// Size: 0x130
struct FRigUnit_SpringInterpQuaternionV2 : public FRigVMFunction_SimBase
{
public:
    FQuat Target() const { return Read<FQuat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x20, Type: StructProperty)
    float Strength() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float CriticalDamping() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    FVector Torque() const { return Read<FVector>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    bool bUseCurrentInput() const { return Read<bool>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: BoolProperty)
    FQuat Current() const { return Read<FQuat>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x20, Type: StructProperty)
    float TargetVelocityAmount() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    bool bInitializeFromTarget() const { return Read<bool>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x1, Type: BoolProperty)
    FQuat Result() const { return Read<FQuat>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x20, Type: StructProperty)
    FVector AngularVelocity() const { return Read<FVector>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x18, Type: StructProperty)
    FQuat SimulatedResult() const { return Read<FQuat>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x20, Type: StructProperty)
    FQuaternionSpringState SpringState() const { return Read<FQuaternionSpringState>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x40, Type: StructProperty)

    void SET_Target(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x20, Type: StructProperty)
    void SET_Strength(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_CriticalDamping(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_Torque(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_bUseCurrentInput(const bool& Value) { Write<bool>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: BoolProperty)
    void SET_Current(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x20, Type: StructProperty)
    void SET_TargetVelocityAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_bInitializeFromTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x1, Type: BoolProperty)
    void SET_Result(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x20, Type: StructProperty)
    void SET_AngularVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x18, Type: StructProperty)
    void SET_SimulatedResult(const FQuat& Value) { Write<FQuat>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x20, Type: StructProperty)
    void SET_SpringState(const FQuaternionSpringState& Value) { Write<FQuaternionSpringState>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x40, Type: StructProperty)
};

