/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CollectionMapShared
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"
#include "FortniteUI.h"
#include "CoreUObject.h"

// Size: 0x748
class UAthenaCollectionScreenMapBase : public UAthenaCollectionScreenBase
{
public:
    UAthenaFullScreenMapBase* MapWidget() const { return Read<UAthenaFullScreenMapBase*>(uintptr_t(this) + 0x6c0); } // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    UClass* CollectionIconType() const { return Read<UClass*>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x8, Type: ClassProperty)
    TMap<UAthenaMapCollectionIcon*, FGameplayTag> MapCollectionIcons() const { return Read<TMap<UAthenaMapCollectionIcon*, FGameplayTag>>(uintptr_t(this) + 0x6d8); } // 0x6d8 (Size: 0x50, Type: MapProperty)

    void SET_MapWidget(const UAthenaFullScreenMapBase*& Value) { Write<UAthenaFullScreenMapBase*>(uintptr_t(this) + 0x6c0, Value); } // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    void SET_CollectionIconType(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x8, Type: ClassProperty)
    void SET_MapCollectionIcons(const TMap<UAthenaMapCollectionIcon*, FGameplayTag>& Value) { Write<TMap<UAthenaMapCollectionIcon*, FGameplayTag>>(uintptr_t(this) + 0x6d8, Value); } // 0x6d8 (Size: 0x50, Type: MapProperty)
};

// Size: 0x3e8
class UAthenaMapCollectionIcon : public UAthenaMapNavigableIconCustom
{
public:
};

