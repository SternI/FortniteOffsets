/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FNRedwoodUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x15b0
class UFNRedwoodFeedbackInjector : public USocialListEntryBase
{
public:
    FName ReportId() const { return Read<FName>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x4, Type: NameProperty)
    FName ReportInjectCategoryName() const { return Read<FName>(uintptr_t(this) + 0x157c); } // 0x157c (Size: 0x4, Type: NameProperty)
    FText ReportOption() const { return Read<FText>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x10, Type: TextProperty)
    FText ReportOptionSummary() const { return Read<FText>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x10, Type: TextProperty)
    FText ReportOptionDescription() const { return Read<FText>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x10, Type: TextProperty)

    void SET_ReportId(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x4, Type: NameProperty)
    void SET_ReportInjectCategoryName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x157c, Value); } // 0x157c (Size: 0x4, Type: NameProperty)
    void SET_ReportOption(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x10, Type: TextProperty)
    void SET_ReportOptionSummary(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x10, Type: TextProperty)
    void SET_ReportOptionDescription(const FText& Value) { Write<FText>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x10, Type: TextProperty)
};

