/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ChaosSolverEngine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "ChaosVDRuntime.h"
#include "Engine.h"
#include "Chaos.h"
#include "CoreUObject.h"
#include "DataflowSimulation.h"

// Size: 0x30
class UChaosDebugDrawSubsystem : public UWorldSubsystem
{
public:
};

// Size: 0xc0
class UChaosDebugDrawComponent : public UActorComponent
{
public:
};

// Size: 0xc0
class UChaosEventListenerComponent : public UActorComponent
{
public:
};

// Size: 0x2d0
class UChaosGameplayEventDispatcher : public UChaosEventListenerComponent
{
public:
    TMap<FChaosHandlerSet, UPrimitiveComponent*> CollisionEventRegistrations() const { return Read<TMap<FChaosHandlerSet, UPrimitiveComponent*>>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x50, Type: MapProperty)
    TMap<FBreakEventCallbackWrapper, UPrimitiveComponent*> BreakEventRegistrations() const { return Read<TMap<FBreakEventCallbackWrapper, UPrimitiveComponent*>>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x50, Type: MapProperty)
    TMap<FRemovalEventCallbackWrapper, UPrimitiveComponent*> RemovalEventRegistrations() const { return Read<TMap<FRemovalEventCallbackWrapper, UPrimitiveComponent*>>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x50, Type: MapProperty)
    TMap<FCrumblingEventCallbackWrapper, UPrimitiveComponent*> CrumblingEventRegistrations() const { return Read<TMap<FCrumblingEventCallbackWrapper, UPrimitiveComponent*>>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x50, Type: MapProperty)

    void SET_CollisionEventRegistrations(const TMap<FChaosHandlerSet, UPrimitiveComponent*>& Value) { Write<TMap<FChaosHandlerSet, UPrimitiveComponent*>>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x50, Type: MapProperty)
    void SET_BreakEventRegistrations(const TMap<FBreakEventCallbackWrapper, UPrimitiveComponent*>& Value) { Write<TMap<FBreakEventCallbackWrapper, UPrimitiveComponent*>>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x50, Type: MapProperty)
    void SET_RemovalEventRegistrations(const TMap<FRemovalEventCallbackWrapper, UPrimitiveComponent*>& Value) { Write<TMap<FRemovalEventCallbackWrapper, UPrimitiveComponent*>>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x50, Type: MapProperty)
    void SET_CrumblingEventRegistrations(const TMap<FCrumblingEventCallbackWrapper, UPrimitiveComponent*>& Value) { Write<TMap<FCrumblingEventCallbackWrapper, UPrimitiveComponent*>>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x50, Type: MapProperty)
};

// Size: 0x28
class UChaosNotifyHandlerInterface : public UInterface
{
public:
};

// Size: 0x28
class UChaosSolverEngineBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x28
class UChaosSolver : public UObject
{
public:
};

// Size: 0x4a8
class AChaosSolverActor : public AActor
{
public:
    FChaosSolverConfiguration Properties() const { return Read<FChaosSolverConfiguration>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x84, Type: StructProperty)
    float TimeStepMultiplier() const { return Read<float>(uintptr_t(this) + 0x334); } // 0x334 (Size: 0x4, Type: FloatProperty)
    int32_t CollisionIterations() const { return Read<int32_t>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x4, Type: IntProperty)
    int32_t PushOutIterations() const { return Read<int32_t>(uintptr_t(this) + 0x33c); } // 0x33c (Size: 0x4, Type: IntProperty)
    int32_t PushOutPairIterations() const { return Read<int32_t>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x4, Type: IntProperty)
    float ClusterConnectionFactor() const { return Read<float>(uintptr_t(this) + 0x344); } // 0x344 (Size: 0x4, Type: FloatProperty)
    uint8_t ClusterUnionConnectionType() const { return Read<uint8_t>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x1, Type: EnumProperty)
    bool DoGenerateCollisionData() const { return Read<bool>(uintptr_t(this) + 0x349); } // 0x349 (Size: 0x1, Type: BoolProperty)
    FSolverCollisionFilterSettings CollisionFilterSettings() const { return Read<FSolverCollisionFilterSettings>(uintptr_t(this) + 0x34c); } // 0x34c (Size: 0x10, Type: StructProperty)
    bool DoGenerateBreakingData() const { return Read<bool>(uintptr_t(this) + 0x35c); } // 0x35c (Size: 0x1, Type: BoolProperty)
    FSolverBreakingFilterSettings BreakingFilterSettings() const { return Read<FSolverBreakingFilterSettings>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x10, Type: StructProperty)
    bool DoGenerateTrailingData() const { return Read<bool>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x1, Type: BoolProperty)
    FSolverTrailingFilterSettings TrailingFilterSettings() const { return Read<FSolverTrailingFilterSettings>(uintptr_t(this) + 0x374); } // 0x374 (Size: 0x10, Type: StructProperty)
    float MassScale() const { return Read<float>(uintptr_t(this) + 0x384); } // 0x384 (Size: 0x4, Type: FloatProperty)
    bool bHasFloor() const { return Read<bool>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x1, Type: BoolProperty)
    float FloorHeight() const { return Read<float>(uintptr_t(this) + 0x38c); } // 0x38c (Size: 0x4, Type: FloatProperty)
    FChaosDebugSubstepControl ChaosDebugSubstepControl() const { return Read<FChaosDebugSubstepControl>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x3, Type: StructProperty)
    UBillboardComponent* SpriteComponent() const { return Read<UBillboardComponent*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    FDataflowSimulationAsset SimulationAsset() const { return Read<FDataflowSimulationAsset>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x58, Type: StructProperty)
    UChaosGameplayEventDispatcher* GameplayEventDispatcherComponent() const { return Read<UChaosGameplayEventDispatcher*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)

    void SET_Properties(const FChaosSolverConfiguration& Value) { Write<FChaosSolverConfiguration>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x84, Type: StructProperty)
    void SET_TimeStepMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x334, Value); } // 0x334 (Size: 0x4, Type: FloatProperty)
    void SET_CollisionIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x4, Type: IntProperty)
    void SET_PushOutIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x33c, Value); } // 0x33c (Size: 0x4, Type: IntProperty)
    void SET_PushOutPairIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x4, Type: IntProperty)
    void SET_ClusterConnectionFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x344, Value); } // 0x344 (Size: 0x4, Type: FloatProperty)
    void SET_ClusterUnionConnectionType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x1, Type: EnumProperty)
    void SET_DoGenerateCollisionData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x349, Value); } // 0x349 (Size: 0x1, Type: BoolProperty)
    void SET_CollisionFilterSettings(const FSolverCollisionFilterSettings& Value) { Write<FSolverCollisionFilterSettings>(uintptr_t(this) + 0x34c, Value); } // 0x34c (Size: 0x10, Type: StructProperty)
    void SET_DoGenerateBreakingData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x35c, Value); } // 0x35c (Size: 0x1, Type: BoolProperty)
    void SET_BreakingFilterSettings(const FSolverBreakingFilterSettings& Value) { Write<FSolverBreakingFilterSettings>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x10, Type: StructProperty)
    void SET_DoGenerateTrailingData(const bool& Value) { Write<bool>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x1, Type: BoolProperty)
    void SET_TrailingFilterSettings(const FSolverTrailingFilterSettings& Value) { Write<FSolverTrailingFilterSettings>(uintptr_t(this) + 0x374, Value); } // 0x374 (Size: 0x10, Type: StructProperty)
    void SET_MassScale(const float& Value) { Write<float>(uintptr_t(this) + 0x384, Value); } // 0x384 (Size: 0x4, Type: FloatProperty)
    void SET_bHasFloor(const bool& Value) { Write<bool>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x1, Type: BoolProperty)
    void SET_FloorHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x38c, Value); } // 0x38c (Size: 0x4, Type: FloatProperty)
    void SET_ChaosDebugSubstepControl(const FChaosDebugSubstepControl& Value) { Write<FChaosDebugSubstepControl>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x3, Type: StructProperty)
    void SET_SpriteComponent(const UBillboardComponent*& Value) { Write<UBillboardComponent*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_SimulationAsset(const FDataflowSimulationAsset& Value) { Write<FDataflowSimulationAsset>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x58, Type: StructProperty)
    void SET_GameplayEventDispatcherComponent(const UChaosGameplayEventDispatcher*& Value) { Write<UChaosGameplayEventDispatcher*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x50
class UChaosSolverSettings : public UDeveloperSettings
{
public:
    FSoftClassPath DefaultChaosSolverActorClass() const { return Read<FSoftClassPath>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)

    void SET_DefaultChaosSolverActorClass(const FSoftClassPath& Value) { Write<FSoftClassPath>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
};

// Size: 0xc0
struct FChaosPhysicsCollisionInfo
{
public:
    UPrimitiveComponent* Component() const { return Read<UPrimitiveComponent*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* OtherComponent() const { return Read<UPrimitiveComponent*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector Location() const { return Read<FVector>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)
    FVector Normal() const { return Read<FVector>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x18, Type: StructProperty)
    FVector AccumulatedImpulse() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    FVector Velocity() const { return Read<FVector>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x18, Type: StructProperty)
    FVector OtherVelocity() const { return Read<FVector>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x18, Type: StructProperty)
    FVector AngularVelocity() const { return Read<FVector>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x18, Type: StructProperty)
    FVector OtherAngularVelocity() const { return Read<FVector>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x18, Type: StructProperty)
    float Mass() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float OtherMass() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)

    void SET_Component(const UPrimitiveComponent*& Value) { Write<UPrimitiveComponent*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_OtherComponent(const UPrimitiveComponent*& Value) { Write<UPrimitiveComponent*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
    void SET_Normal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x18, Type: StructProperty)
    void SET_AccumulatedImpulse(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_Velocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x18, Type: StructProperty)
    void SET_OtherVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x18, Type: StructProperty)
    void SET_AngularVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x18, Type: StructProperty)
    void SET_OtherAngularVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x18, Type: StructProperty)
    void SET_Mass(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_OtherMass(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FChaosVDSessionPing
{
public:
    FGuid ControllerInstanceId() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)

    void SET_ControllerInstanceId(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x38
struct FChaosVDSessionPong
{
public:
    FGuid InstanceID() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FGuid SessionId() const { return Read<FGuid>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StructProperty)
    FString SessionName() const { return Read<FString>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StrProperty)
    char BuildTargetType() const { return Read<char>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: ByteProperty)

    void SET_InstanceID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_SessionId(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StructProperty)
    void SET_SessionName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StrProperty)
    void SET_BuildTargetType(const char& Value) { Write<char>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x18
struct FChaosVDStartRecordingCommandMessage
{
public:
    uint8_t RecordingMode() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FString Target() const { return Read<FString>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StrProperty)

    void SET_RecordingMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_Target(const FString& Value) { Write<FString>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StrProperty)
};

// Size: 0x1
struct FChaosVDStopRecordingCommandMessage
{
public:
};

// Size: 0x50
struct FChaosVDRecordingStatusMessage
{
public:
    FGuid InstanceID() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    bool bIsRecording() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float ElapsedTime() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    FChaosVDTraceDetails TraceDetails() const { return Read<FChaosVDTraceDetails>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x38, Type: StructProperty)

    void SET_InstanceID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_bIsRecording(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_ElapsedTime(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_TraceDetails(const FChaosVDTraceDetails& Value) { Write<FChaosVDTraceDetails>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x38, Type: StructProperty)
};

// Size: 0x18
struct FChaosVDDataChannelState
{
public:
    FString ChannelName() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    bool bIsEnabled() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    bool bCanChangeChannelState() const { return Read<bool>(uintptr_t(this) + 0x11); } // 0x11 (Size: 0x1, Type: BoolProperty)

    void SET_ChannelName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_bIsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_bCanChangeChannelState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11, Value); } // 0x11 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FChaosVDChannelStateChangeCommandMessage
{
public:
    FChaosVDDataChannelState NewState() const { return Read<FChaosVDDataChannelState>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)

    void SET_NewState(const FChaosVDDataChannelState& Value) { Write<FChaosVDDataChannelState>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
};

// Size: 0x28
struct FChaosVDChannelStateChangeResponseMessage
{
public:
    FGuid InstanceID() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FChaosVDDataChannelState NewState() const { return Read<FChaosVDDataChannelState>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x18, Type: StructProperty)

    void SET_InstanceID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_NewState(const FChaosVDDataChannelState& Value) { Write<FChaosVDDataChannelState>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x18, Type: StructProperty)
};

// Size: 0x1
struct FChaosVDFullSessionInfoRequestMessage
{
public:
};

// Size: 0x28
struct FChaosVDFullSessionInfoResponseMessage
{
public:
    FGuid InstanceID() const { return Read<FGuid>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    TArray<FChaosVDDataChannelState> DataChannelsStates() const { return Read<TArray<FChaosVDDataChannelState>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bIsRecording() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_InstanceID(const FGuid& Value) { Write<FGuid>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_DataChannelsStates(const TArray<FChaosVDDataChannelState>& Value) { Write<TArray<FChaosVDDataChannelState>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsRecording(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FBreakEventCallbackWrapper
{
public:
};

// Size: 0x30
struct FRemovalEventCallbackWrapper
{
public:
};

// Size: 0x30
struct FCrumblingEventCallbackWrapper
{
public:
};

// Size: 0x58
struct FChaosHandlerSet
{
public:
    TSet<UObject*> ChaosHandlers() const { return Read<TSet<UObject*>>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x50, Type: SetProperty)

    void SET_ChaosHandlers(const TSet<UObject*>& Value) { Write<TSet<UObject*>>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x50, Type: SetProperty)
};

// Size: 0x3
struct FChaosDebugSubstepControl
{
public:
    bool bPause() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    bool bSubstep() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    bool bStep() const { return Read<bool>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: BoolProperty)

    void SET_bPause(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_bSubstep(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET_bStep(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x90
struct FDataflowRigidSolverProxy : public FDataflowPhysicsSolverProxy
{
public:
};

