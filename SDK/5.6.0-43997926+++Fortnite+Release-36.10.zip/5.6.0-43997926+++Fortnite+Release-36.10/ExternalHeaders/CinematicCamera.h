/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CinematicCamera
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x2d8
class ACameraRig_Crane : public AActor
{
public:
    float CranePitch() const { return Read<float>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x4, Type: FloatProperty)
    float CraneYaw() const { return Read<float>(uintptr_t(this) + 0x2ac); } // 0x2ac (Size: 0x4, Type: FloatProperty)
    float CraneArmLength() const { return Read<float>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x4, Type: FloatProperty)
    bool bLockMountPitch() const { return Read<bool>(uintptr_t(this) + 0x2b4); } // 0x2b4 (Size: 0x1, Type: BoolProperty)
    bool bLockMountYaw() const { return Read<bool>(uintptr_t(this) + 0x2b5); } // 0x2b5 (Size: 0x1, Type: BoolProperty)
    USceneComponent* TransformComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* CraneYawControl() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* CranePitchControl() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* CraneCameraMount() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)

    void SET_CranePitch(const float& Value) { Write<float>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x4, Type: FloatProperty)
    void SET_CraneYaw(const float& Value) { Write<float>(uintptr_t(this) + 0x2ac, Value); } // 0x2ac (Size: 0x4, Type: FloatProperty)
    void SET_CraneArmLength(const float& Value) { Write<float>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x4, Type: FloatProperty)
    void SET_bLockMountPitch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b4, Value); } // 0x2b4 (Size: 0x1, Type: BoolProperty)
    void SET_bLockMountYaw(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b5, Value); } // 0x2b5 (Size: 0x1, Type: BoolProperty)
    void SET_TransformComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_CraneYawControl(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_CranePitchControl(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_CraneCameraMount(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2c8
class ACameraRig_Rail : public AActor
{
public:
    float CurrentPositionOnRail() const { return Read<float>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x4, Type: FloatProperty)
    bool bLockOrientationToRail() const { return Read<bool>(uintptr_t(this) + 0x2ac); } // 0x2ac (Size: 0x1, Type: BoolProperty)
    USceneComponent* TransformComponent() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    USplineComponent* RailSplineComponent() const { return Read<USplineComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* RailCameraMount() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)

    void SET_CurrentPositionOnRail(const float& Value) { Write<float>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x4, Type: FloatProperty)
    void SET_bLockOrientationToRail(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2ac, Value); } // 0x2ac (Size: 0x1, Type: BoolProperty)
    void SET_TransformComponent(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_RailSplineComponent(const USplineComponent*& Value) { Write<USplineComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_RailCameraMount(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xaa0
class ACineCameraActor : public ACameraActor
{
public:
    FCameraLookatTrackingSettings LookatTrackingSettings() const { return Read<FCameraLookatTrackingSettings>(uintptr_t(this) + 0xa30); } // 0xa30 (Size: 0x60, Type: StructProperty)

    void SET_LookatTrackingSettings(const FCameraLookatTrackingSettings& Value) { Write<FCameraLookatTrackingSettings>(uintptr_t(this) + 0xa30, Value); } // 0xa30 (Size: 0x60, Type: StructProperty)
};

// Size: 0xba0
class UCineCameraComponent : public UCameraComponent
{
public:
    FCameraFilmbackSettings FilmbackSettings() const { return Read<FCameraFilmbackSettings>(uintptr_t(this) + 0xa80); } // 0xa80 (Size: 0x14, Type: StructProperty)
    FCameraFilmbackSettings Filmback() const { return Read<FCameraFilmbackSettings>(uintptr_t(this) + 0xa94); } // 0xa94 (Size: 0x14, Type: StructProperty)
    FCameraLensSettings LensSettings() const { return Read<FCameraLensSettings>(uintptr_t(this) + 0xaa8); } // 0xaa8 (Size: 0x1c, Type: StructProperty)
    FCameraFocusSettings FocusSettings() const { return Read<FCameraFocusSettings>(uintptr_t(this) + 0xac8); } // 0xac8 (Size: 0x58, Type: StructProperty)
    FPlateCropSettings CropSettings() const { return Read<FPlateCropSettings>(uintptr_t(this) + 0xb20); } // 0xb20 (Size: 0x4, Type: StructProperty)
    float CurrentFocalLength() const { return Read<float>(uintptr_t(this) + 0xb24); } // 0xb24 (Size: 0x4, Type: FloatProperty)
    float CurrentAperture() const { return Read<float>(uintptr_t(this) + 0xb28); } // 0xb28 (Size: 0x4, Type: FloatProperty)
    float CurrentFocusDistance() const { return Read<float>(uintptr_t(this) + 0xb2c); } // 0xb2c (Size: 0x4, Type: FloatProperty)
    bool bOverride_CustomNearClippingPlane() const { return (Read<uint8_t>(uintptr_t(this) + 0xb30) >> 0x0) & 1; } // 0xb30:0 (Size: 0x1, Type: BoolProperty)
    float CustomNearClippingPlane() const { return Read<float>(uintptr_t(this) + 0xb34); } // 0xb34 (Size: 0x4, Type: FloatProperty)
    TArray<FNamedFilmbackPreset> FilmbackPresets() const { return Read<TArray<FNamedFilmbackPreset>>(uintptr_t(this) + 0xb40); } // 0xb40 (Size: 0x10, Type: ArrayProperty)
    TArray<FNamedLensPreset> LensPresets() const { return Read<TArray<FNamedLensPreset>>(uintptr_t(this) + 0xb50); } // 0xb50 (Size: 0x10, Type: ArrayProperty)
    FString DefaultFilmbackPresetName() const { return Read<FString>(uintptr_t(this) + 0xb60); } // 0xb60 (Size: 0x10, Type: StrProperty)
    FString DefaultFilmbackPreset() const { return Read<FString>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x10, Type: StrProperty)
    FString DefaultLensPresetName() const { return Read<FString>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x10, Type: StrProperty)
    float DefaultLensFocalLength() const { return Read<float>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x4, Type: FloatProperty)
    float DefaultLensFStop() const { return Read<float>(uintptr_t(this) + 0xb94); } // 0xb94 (Size: 0x4, Type: FloatProperty)

    void SET_FilmbackSettings(const FCameraFilmbackSettings& Value) { Write<FCameraFilmbackSettings>(uintptr_t(this) + 0xa80, Value); } // 0xa80 (Size: 0x14, Type: StructProperty)
    void SET_Filmback(const FCameraFilmbackSettings& Value) { Write<FCameraFilmbackSettings>(uintptr_t(this) + 0xa94, Value); } // 0xa94 (Size: 0x14, Type: StructProperty)
    void SET_LensSettings(const FCameraLensSettings& Value) { Write<FCameraLensSettings>(uintptr_t(this) + 0xaa8, Value); } // 0xaa8 (Size: 0x1c, Type: StructProperty)
    void SET_FocusSettings(const FCameraFocusSettings& Value) { Write<FCameraFocusSettings>(uintptr_t(this) + 0xac8, Value); } // 0xac8 (Size: 0x58, Type: StructProperty)
    void SET_CropSettings(const FPlateCropSettings& Value) { Write<FPlateCropSettings>(uintptr_t(this) + 0xb20, Value); } // 0xb20 (Size: 0x4, Type: StructProperty)
    void SET_CurrentFocalLength(const float& Value) { Write<float>(uintptr_t(this) + 0xb24, Value); } // 0xb24 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentAperture(const float& Value) { Write<float>(uintptr_t(this) + 0xb28, Value); } // 0xb28 (Size: 0x4, Type: FloatProperty)
    void SET_CurrentFocusDistance(const float& Value) { Write<float>(uintptr_t(this) + 0xb2c, Value); } // 0xb2c (Size: 0x4, Type: FloatProperty)
    void SET_bOverride_CustomNearClippingPlane(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xb30); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xb30, B); } // 0xb30:0 (Size: 0x1, Type: BoolProperty)
    void SET_CustomNearClippingPlane(const float& Value) { Write<float>(uintptr_t(this) + 0xb34, Value); } // 0xb34 (Size: 0x4, Type: FloatProperty)
    void SET_FilmbackPresets(const TArray<FNamedFilmbackPreset>& Value) { Write<TArray<FNamedFilmbackPreset>>(uintptr_t(this) + 0xb40, Value); } // 0xb40 (Size: 0x10, Type: ArrayProperty)
    void SET_LensPresets(const TArray<FNamedLensPreset>& Value) { Write<TArray<FNamedLensPreset>>(uintptr_t(this) + 0xb50, Value); } // 0xb50 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultFilmbackPresetName(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb60, Value); } // 0xb60 (Size: 0x10, Type: StrProperty)
    void SET_DefaultFilmbackPreset(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x10, Type: StrProperty)
    void SET_DefaultLensPresetName(const FString& Value) { Write<FString>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x10, Type: StrProperty)
    void SET_DefaultLensFocalLength(const float& Value) { Write<float>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x4, Type: FloatProperty)
    void SET_DefaultLensFStop(const float& Value) { Write<float>(uintptr_t(this) + 0xb94, Value); } // 0xb94 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xa8
class UCineCameraSettings : public UDeveloperSettings
{
public:
    FString DefaultLensPresetName() const { return Read<FString>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StrProperty)
    float DefaultLensFocalLength() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    float DefaultLensFStop() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    TArray<FNamedLensPreset> LensPresets() const { return Read<TArray<FNamedLensPreset>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    FString DefaultFilmbackPreset() const { return Read<FString>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StrProperty)
    TArray<FNamedFilmbackPreset> FilmbackPresets() const { return Read<TArray<FNamedFilmbackPreset>>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    FString DefaultCropPresetName() const { return Read<FString>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StrProperty)
    TArray<FNamedPlateCropPreset> CropPresets() const { return Read<TArray<FNamedPlateCropPreset>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)

    void SET_DefaultLensPresetName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StrProperty)
    void SET_DefaultLensFocalLength(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_DefaultLensFStop(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_LensPresets(const TArray<FNamedLensPreset>& Value) { Write<TArray<FNamedLensPreset>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultFilmbackPreset(const FString& Value) { Write<FString>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StrProperty)
    void SET_FilmbackPresets(const TArray<FNamedFilmbackPreset>& Value) { Write<TArray<FNamedFilmbackPreset>>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: ArrayProperty)
    void SET_DefaultCropPresetName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StrProperty)
    void SET_CropPresets(const TArray<FNamedPlateCropPreset>& Value) { Write<TArray<FNamedPlateCropPreset>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x58
struct FCameraFocusSettings
{
public:
    uint8_t FocusMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    float ManualFocusDistance() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    FCameraTrackingFocusSettings TrackingFocusSettings() const { return Read<FCameraTrackingFocusSettings>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x40, Type: StructProperty)
    bool bSmoothFocusChanges() const { return (Read<uint8_t>(uintptr_t(this) + 0x48) >> 0x0) & 1; } // 0x48:0 (Size: 0x1, Type: BoolProperty)
    float FocusSmoothingInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    float FocusOffset() const { return Read<float>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x4, Type: FloatProperty)

    void SET_FocusMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_ManualFocusDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_TrackingFocusSettings(const FCameraTrackingFocusSettings& Value) { Write<FCameraTrackingFocusSettings>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x40, Type: StructProperty)
    void SET_bSmoothFocusChanges(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x48); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x48, B); } // 0x48:0 (Size: 0x1, Type: BoolProperty)
    void SET_FocusSmoothingInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_FocusOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x40
struct FCameraTrackingFocusSettings
{
public:
    TSoftObjectPtr<AActor> ActorToTrack() const { return Read<TSoftObjectPtr<AActor>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    FVector RelativeOffset() const { return Read<FVector>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x18, Type: StructProperty)
    bool bDrawDebugTrackingFocusPoint() const { return (Read<uint8_t>(uintptr_t(this) + 0x38) >> 0x0) & 1; } // 0x38:0 (Size: 0x1, Type: BoolProperty)

    void SET_ActorToTrack(const TSoftObjectPtr<AActor>& Value) { Write<TSoftObjectPtr<AActor>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_RelativeOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x18, Type: StructProperty)
    void SET_bDrawDebugTrackingFocusPoint(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x38); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x38, B); } // 0x38:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1c
struct FCameraLensSettings
{
public:
    float MinFocalLength() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float MaxFocalLength() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float MinFStop() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MaxFStop() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float MinimumFocusDistance() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float SqueezeFactor() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    int32_t DiaphragmBladeCount() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)

    void SET_MinFocalLength(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_MaxFocalLength(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_MinFStop(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxFStop(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_MinimumFocusDistance(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_SqueezeFactor(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_DiaphragmBladeCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
};

// Size: 0x14
struct FCameraFilmbackSettings
{
public:
    float SensorWidth() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float SensorHeight() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float SensorHorizontalOffset() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float SensorVerticalOffset() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float SensorAspectRatio() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)

    void SET_SensorWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_SensorHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_SensorHorizontalOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_SensorVerticalOffset(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_SensorAspectRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x60
struct FCameraLookatTrackingSettings
{
public:
    bool bEnableLookAtTracking() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x0) & 1; } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    bool bDrawDebugLookAtTrackingPosition() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x1) & 1; } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    float LookAtTrackingInterpSpeed() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    TSoftObjectPtr<AActor> ActorToTrack() const { return Read<TSoftObjectPtr<AActor>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    FVector RelativeOffset() const { return Read<FVector>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x18, Type: StructProperty)
    bool bAllowRoll() const { return (Read<uint8_t>(uintptr_t(this) + 0x58) >> 0x0) & 1; } // 0x58:0 (Size: 0x1, Type: BoolProperty)

    void SET_bEnableLookAtTracking(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    void SET_bDrawDebugLookAtTrackingPosition(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:1 (Size: 0x1, Type: BoolProperty)
    void SET_LookAtTrackingInterpSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ActorToTrack(const TSoftObjectPtr<AActor>& Value) { Write<TSoftObjectPtr<AActor>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x20, Type: SoftObjectProperty)
    void SET_RelativeOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x18, Type: StructProperty)
    void SET_bAllowRoll(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x58); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x58, B); } // 0x58:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x38
struct FNamedFilmbackPreset
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FText DisplayName() const { return Read<FText>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: TextProperty)
    FCameraFilmbackSettings FilmbackSettings() const { return Read<FCameraFilmbackSettings>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x14, Type: StructProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_DisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: TextProperty)
    void SET_FilmbackSettings(const FCameraFilmbackSettings& Value) { Write<FCameraFilmbackSettings>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x14, Type: StructProperty)
};

// Size: 0x30
struct FNamedLensPreset
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FCameraLensSettings LensSettings() const { return Read<FCameraLensSettings>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1c, Type: StructProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_LensSettings(const FCameraLensSettings& Value) { Write<FCameraLensSettings>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1c, Type: StructProperty)
};

// Size: 0x4
struct FPlateCropSettings
{
public:
    float AspectRatio() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)

    void SET_AspectRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FNamedPlateCropPreset
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FPlateCropSettings CropSettings() const { return Read<FPlateCropSettings>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_CropSettings(const FPlateCropSettings& Value) { Write<FPlateCropSettings>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
};

