/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CrowdVolume
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "FortniteGame.h"
#include "Engine.h"

// Size: 0x280
class UCrowdSpawner : public USceneComponent
{
public:
    TArray<UHierarchicalInstancedStaticMeshComponent*> CharacterMeshes() const { return Read<TArray<UHierarchicalInstancedStaticMeshComponent*>>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x10, Type: ArrayProperty)

    void SET_CharacterMeshes(const TArray<UHierarchicalInstancedStaticMeshComponent*>& Value) { Write<TArray<UHierarchicalInstancedStaticMeshComponent*>>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x10, Type: ArrayProperty)
};

