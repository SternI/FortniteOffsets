/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DataAssets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "Engine.h"

// Size: 0x80
class UPDA_RankConfig_C : public UPrimaryDataAsset
{
public:
    TMap<TSoftObjectPtr<UTexture2D*>, int32_t> RankIcons() const { return Read<TMap<TSoftObjectPtr<UTexture2D*>, int32_t>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)

    void SET_RankIcons(const TMap<TSoftObjectPtr<UTexture2D*>, int32_t>& Value) { Write<TMap<TSoftObjectPtr<UTexture2D*>, int32_t>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
};

