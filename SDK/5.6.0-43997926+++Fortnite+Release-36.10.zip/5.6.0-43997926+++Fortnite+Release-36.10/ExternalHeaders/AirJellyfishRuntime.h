/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AirJellyfishRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x5f0
class UFortAirJellyfishAnimInstance : public UFortAnimInstance
{
public:
    float RotatorLerpRate() const { return Read<float>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x4, Type: FloatProperty)
    float VelocityDirectionScalar() const { return Read<float>(uintptr_t(this) + 0x5cc); } // 0x5cc (Size: 0x4, Type: FloatProperty)
    FRotator RootRotation() const { return Read<FRotator>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x18, Type: StructProperty)

    void SET_RotatorLerpRate(const float& Value) { Write<float>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x4, Type: FloatProperty)
    void SET_VelocityDirectionScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x5cc, Value); } // 0x5cc (Size: 0x4, Type: FloatProperty)
    void SET_RootRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x18, Type: StructProperty)
};

