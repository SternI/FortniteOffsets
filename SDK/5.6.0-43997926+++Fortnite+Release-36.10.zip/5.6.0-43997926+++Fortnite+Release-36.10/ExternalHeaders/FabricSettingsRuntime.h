/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FabricSettingsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x40
class UFabricClientSettingRecordPartition : public UFortClientSettingRecordPartition
{
public:
};

