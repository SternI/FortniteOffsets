/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CRD_ClassSelectorUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "FortniteUI.h"
#include "CommonUI.h"
#include "CoreUObject.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "SlateCore.h"

// Size: 0x390
class UClassSelectorLoadoutContainer : public UCommonUserWidget
{
public:
    UWrapBox* WrapBox() const { return Read<UWrapBox*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    UClass* EntryWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ClassProperty)
    TArray<UAthenaItemElementWidgetBase*> EntryWidgets() const { return Read<TArray<UAthenaItemElementWidgetBase*>>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x10, Type: ArrayProperty)
    UFortItemDefinition* PreviewItemDef() const { return Read<UFortItemDefinition*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    int32_t NumPreviewEntries() const { return Read<int32_t>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x4, Type: IntProperty)

    void SET_WrapBox(const UWrapBox*& Value) { Write<UWrapBox*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_EntryWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ClassProperty)
    void SET_EntryWidgets(const TArray<UAthenaItemElementWidgetBase*>& Value) { Write<TArray<UAthenaItemElementWidgetBase*>>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x10, Type: ArrayProperty)
    void SET_PreviewItemDef(const UFortItemDefinition*& Value) { Write<UFortItemDefinition*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_NumPreviewEntries(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x4, Type: IntProperty)
};

// Size: 0x400
class UClassSelectorTabButtons : public UCommonUserWidget
{
public:
    UCommonActionWidget* LeftActionWidget() const { return Read<UCommonActionWidget*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    UCommonActionWidget* RightActionWidget() const { return Read<UCommonActionWidget*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UScrollBox* TabButtonsScrollBox() const { return Read<UScrollBox*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* LeftButton() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* RightButton() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle LeftInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x10, Type: StructProperty)
    FDataTableRowHandle RightInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x10, Type: StructProperty)
    TArray<UClassSelectorTeamTile*> TabButtons() const { return Read<TArray<UClassSelectorTeamTile*>>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: ArrayProperty)
    UClass* TabButtonClass() const { return Read<UClass*>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x8, Type: ClassProperty)
    FMargin TabButtonPadding() const { return Read<FMargin>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x10, Type: StructProperty)
    TArray<FText> DesignerPreviewTabNames() const { return Read<TArray<FText>>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x10, Type: ArrayProperty)
    float ButtonScrollAmount() const { return Read<float>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x4, Type: FloatProperty)

    void SET_LeftActionWidget(const UCommonActionWidget*& Value) { Write<UCommonActionWidget*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_RightActionWidget(const UCommonActionWidget*& Value) { Write<UCommonActionWidget*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_TabButtonsScrollBox(const UScrollBox*& Value) { Write<UScrollBox*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_LeftButton(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_RightButton(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_LeftInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x10, Type: StructProperty)
    void SET_RightInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x10, Type: StructProperty)
    void SET_TabButtons(const TArray<UClassSelectorTeamTile*>& Value) { Write<TArray<UClassSelectorTeamTile*>>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: ArrayProperty)
    void SET_TabButtonClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x8, Type: ClassProperty)
    void SET_TabButtonPadding(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x10, Type: StructProperty)
    void SET_DesignerPreviewTabNames(const TArray<FText>& Value) { Write<TArray<FText>>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x10, Type: ArrayProperty)
    void SET_ButtonScrollAmount(const float& Value) { Write<float>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x338
class UClassSelectorTeamInfoWidget : public UUserWidget
{
public:
    UCommonTextBlock* TeamName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* TeamCountText() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* TeamDescription() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)

    void SET_TeamName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    void SET_TeamCountText(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_TeamDescription(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x15e0
class UClassSelectorTeamTile : public UCreativeClassSelectorButton
{
public:
    UTextBlock* PlayerCount() const { return Read<UTextBlock*>(uintptr_t(this) + 0x15c8); } // 0x15c8 (Size: 0x8, Type: ObjectProperty)
    UCommonLazyImage* TeamIconImage() const { return Read<UCommonLazyImage*>(uintptr_t(this) + 0x15d0); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)

    void SET_PlayerCount(const UTextBlock*& Value) { Write<UTextBlock*>(uintptr_t(this) + 0x15c8, Value); } // 0x15c8 (Size: 0x8, Type: ObjectProperty)
    void SET_TeamIconImage(const UCommonLazyImage*& Value) { Write<UCommonLazyImage*>(uintptr_t(this) + 0x15d0, Value); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1550
class UCreativeClassSelectorButton : public UCommonButtonBase
{
public:
    UCommonTextBlock* ButtonTextBlock() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1510); } // 0x1510 (Size: 0x8, Type: ObjectProperty)
    UCommonActionWidget* ActionWidget() const { return Read<UCommonActionWidget*>(uintptr_t(this) + 0x1518); } // 0x1518 (Size: 0x8, Type: ObjectProperty)
    FText ButtonText() const { return Read<FText>(uintptr_t(this) + 0x1520); } // 0x1520 (Size: 0x10, Type: TextProperty)
    FDataTableRowHandle buttonInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x1530); } // 0x1530 (Size: 0x10, Type: StructProperty)
    bool bAutoCapitalize() const { return Read<bool>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x1, Type: BoolProperty)

    void SET_ButtonTextBlock(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1510, Value); } // 0x1510 (Size: 0x8, Type: ObjectProperty)
    void SET_ActionWidget(const UCommonActionWidget*& Value) { Write<UCommonActionWidget*>(uintptr_t(this) + 0x1518, Value); } // 0x1518 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1520, Value); } // 0x1520 (Size: 0x10, Type: TextProperty)
    void SET_buttonInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x1530, Value); } // 0x1530 (Size: 0x10, Type: StructProperty)
    void SET_bAutoCapitalize(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x390
class UClassSelectorTeamTiles : public UCommonUserWidget
{
public:
    TArray<UClassSelectorTeamTile*> TeamTiles() const { return Read<TArray<UClassSelectorTeamTile*>>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: ArrayProperty)
    UUniformGridPanel* RootPanel() const { return Read<UUniformGridPanel*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UClass* EntryClass() const { return Read<UClass*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ClassProperty)
    int32_t DesignerPreviewEntries() const { return Read<int32_t>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x4, Type: IntProperty)

    void SET_TeamTiles(const TArray<UClassSelectorTeamTile*>& Value) { Write<TArray<UClassSelectorTeamTile*>>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: ArrayProperty)
    void SET_RootPanel(const UUniformGridPanel*& Value) { Write<UUniformGridPanel*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_EntryClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ClassProperty)
    void SET_DesignerPreviewEntries(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x4, Type: IntProperty)
};

// Size: 0x70
class UCreativeClassItemInfo : public UObject
{
public:
    FMinigameClassSlot ClassSlot() const { return Read<FMinigameClassSlot>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x40, Type: StructProperty)

    void SET_ClassSlot(const FMinigameClassSlot& Value) { Write<FMinigameClassSlot>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x40, Type: StructProperty)
};

// Size: 0x1560
class UCreativeClassEntry : public UCreativeClassSelectorButton
{
public:
    UCreativeClassItemInfo* ItemInfo() const { return Read<UCreativeClassItemInfo*>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x8, Type: ObjectProperty)

    void SET_ItemInfo(const UCreativeClassItemInfo*& Value) { Write<UCreativeClassItemInfo*>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x5b0
class UCreativeClassSelector : public UCommonActivatableWidget
{
public:
    UClassSelectorTabButtons* TabButtons_TeamSelection() const { return Read<UClassSelectorTabButtons*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UCommonListView* ListView_Classes() const { return Read<UCommonListView*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    TArray<UCreativeClassItemInfo*> ClassItemInfos() const { return Read<TArray<UCreativeClassItemInfo*>>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x10, Type: ArrayProperty)
    UScrollBox* LoadoutScrollBox() const { return Read<UScrollBox*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UClassSelectorLoadoutContainer* LoadoutContainer_Inventory() const { return Read<UClassSelectorLoadoutContainer*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UClassSelectorLoadoutContainer* LoadoutContainer_Resources() const { return Read<UClassSelectorLoadoutContainer*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_SelectLoadout() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UCommonButtonBase* Button_RandomClass() const { return Read<UCommonButtonBase*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UWidgetSwitcher* Switcher_Descriptions() const { return Read<UWidgetSwitcher*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* ClassAndTeamDescriptionContainer() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* ItemDescriptionContainer() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* InventoryPanel() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* ResourcesPanel() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* ItemRarity() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* ItemName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* ItemDescription() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* TeamDescriptionContainer() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    UClassSelectorTeamInfoWidget* TeamInfoWidget_FullView() const { return Read<UClassSelectorTeamInfoWidget*>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: ObjectProperty)
    UClassSelectorTeamInfoWidget* TeamInfoWidget_TeamsOnly() const { return Read<UClassSelectorTeamInfoWidget*>(uintptr_t(this) + 0x520); } // 0x520 (Size: 0x8, Type: ObjectProperty)
    UWidgetSwitcher* DisplaySwitcher() const { return Read<UWidgetSwitcher*>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* ClassAndTeamSelectionContainer() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* OnlyTeamSelectionContainer() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x8, Type: ObjectProperty)
    UPanelWidget* InvalidDataContainer() const { return Read<UPanelWidget*>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x8, Type: ObjectProperty)
    UClassSelectorTeamTiles* TeamTiles() const { return Read<UClassSelectorTeamTiles*>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x8, Type: ObjectProperty)
    UClass* TeamSelectionTabClass() const { return Read<UClass*>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x8, Type: ClassProperty)
    bool bIsModalVersion() const { return Read<bool>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x1, Type: BoolProperty)
    bool bEnableModalTimeLimit() const { return Read<bool>(uintptr_t(this) + 0x559); } // 0x559 (Size: 0x1, Type: BoolProperty)
    int32_t ModalTimeLimitInSeconds() const { return Read<int32_t>(uintptr_t(this) + 0x55c); } // 0x55c (Size: 0x4, Type: IntProperty)
    uint8_t DisplayMode() const { return Read<uint8_t>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x1, Type: EnumProperty)
    bool bDeferRespawn() const { return Read<bool>(uintptr_t(this) + 0x571); } // 0x571 (Size: 0x1, Type: BoolProperty)
    FDataTableRowHandle ReturnToClassSelectionInputAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x10, Type: StructProperty)
    float LoadoutScrollPadding() const { return Read<float>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x4, Type: FloatProperty)
    UCreativeClassItemInfo* SelectedClassItemInfo() const { return Read<UCreativeClassItemInfo*>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)

    void SET_TabButtons_TeamSelection(const UClassSelectorTabButtons*& Value) { Write<UClassSelectorTabButtons*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_ListView_Classes(const UCommonListView*& Value) { Write<UCommonListView*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_ClassItemInfos(const TArray<UCreativeClassItemInfo*>& Value) { Write<TArray<UCreativeClassItemInfo*>>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x10, Type: ArrayProperty)
    void SET_LoadoutScrollBox(const UScrollBox*& Value) { Write<UScrollBox*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_LoadoutContainer_Inventory(const UClassSelectorLoadoutContainer*& Value) { Write<UClassSelectorLoadoutContainer*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_LoadoutContainer_Resources(const UClassSelectorLoadoutContainer*& Value) { Write<UClassSelectorLoadoutContainer*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_SelectLoadout(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_RandomClass(const UCommonButtonBase*& Value) { Write<UCommonButtonBase*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_Descriptions(const UWidgetSwitcher*& Value) { Write<UWidgetSwitcher*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    void SET_ClassAndTeamDescriptionContainer(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemDescriptionContainer(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    void SET_InventoryPanel(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    void SET_ResourcesPanel(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemRarity(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemDescription(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    void SET_TeamDescriptionContainer(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    void SET_TeamInfoWidget_FullView(const UClassSelectorTeamInfoWidget*& Value) { Write<UClassSelectorTeamInfoWidget*>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: ObjectProperty)
    void SET_TeamInfoWidget_TeamsOnly(const UClassSelectorTeamInfoWidget*& Value) { Write<UClassSelectorTeamInfoWidget*>(uintptr_t(this) + 0x520, Value); } // 0x520 (Size: 0x8, Type: ObjectProperty)
    void SET_DisplaySwitcher(const UWidgetSwitcher*& Value) { Write<UWidgetSwitcher*>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x8, Type: ObjectProperty)
    void SET_ClassAndTeamSelectionContainer(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    void SET_OnlyTeamSelectionContainer(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x8, Type: ObjectProperty)
    void SET_InvalidDataContainer(const UPanelWidget*& Value) { Write<UPanelWidget*>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x8, Type: ObjectProperty)
    void SET_TeamTiles(const UClassSelectorTeamTiles*& Value) { Write<UClassSelectorTeamTiles*>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x8, Type: ObjectProperty)
    void SET_TeamSelectionTabClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x8, Type: ClassProperty)
    void SET_bIsModalVersion(const bool& Value) { Write<bool>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableModalTimeLimit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x559, Value); } // 0x559 (Size: 0x1, Type: BoolProperty)
    void SET_ModalTimeLimitInSeconds(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x55c, Value); } // 0x55c (Size: 0x4, Type: IntProperty)
    void SET_DisplayMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x1, Type: EnumProperty)
    void SET_bDeferRespawn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x571, Value); } // 0x571 (Size: 0x1, Type: BoolProperty)
    void SET_ReturnToClassSelectionInputAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x10, Type: StructProperty)
    void SET_LoadoutScrollPadding(const float& Value) { Write<float>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x4, Type: FloatProperty)
    void SET_SelectedClassItemInfo(const UCreativeClassItemInfo*& Value) { Write<UCreativeClassItemInfo*>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4e8
class UCreativeClassSelectorMapTab : public UCommonActivatableWidget
{
public:
    FAthenaMapScreenContainerTabInfo MapTabInfo() const { return Read<FAthenaMapScreenContainerTabInfo>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x40, Type: StructProperty)
    UCreativeClassSelector* CreativeClassSelector() const { return Read<UCreativeClassSelector*>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)

    void SET_MapTabInfo(const FAthenaMapScreenContainerTabInfo& Value) { Write<FAthenaMapScreenContainerTabInfo>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x40, Type: StructProperty)
    void SET_CreativeClassSelector(const UCreativeClassSelector*& Value) { Write<UCreativeClassSelector*>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x360
class AMutator_ClassSelectorUI : public AFortAthenaMutator
{
public:
};

