/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DianaCore
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteGame.h"

// Size: 0xad0
class ADianaRootPlayspaceBase : public AJunoSurvivalRootPlayspace
{
public:
};

// Size: 0x90
class UDianaState_Setup : public UJunoState_SetupBase
{
public:
};

// Size: 0x358
class UDianaControllerComponent_SessionAnalytics : public UJunoPlayerControllerComponent_JunoSessionAnalytics
{
public:
};

// Size: 0x360
class ADianaCoreMutators : public AFortAthenaMutator
{
public:
};

// Size: 0x28
class UDianaGameplayCheatManager : public UChildCheatManager
{
public:
};

// Size: 0xf8
class UDianaGameStateComponent : public UGameStateComponent
{
public:
    int32_t MatchEndingThreshold() const { return Read<int32_t>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: IntProperty)

    void SET_MatchEndingThreshold(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: IntProperty)
};

// Size: 0x168
class UDianaPlayerSpawningComponent : public UJunoPlayerSpawningComponent
{
public:
    FGameplayTagContainer UsedSpawnPointGroups() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x20, Type: StructProperty)

    void SET_UsedSpawnPointGroups(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x20, Type: StructProperty)
};

