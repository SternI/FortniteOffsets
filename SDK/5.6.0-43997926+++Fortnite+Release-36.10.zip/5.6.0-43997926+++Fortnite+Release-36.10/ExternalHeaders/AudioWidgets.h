/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioWidgets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "SlateCore.h"

// Size: 0x208
class UAudioMaterialButton : public UWidget
{
public:
    FAudioMaterialButtonStyle WidgetStyle() const { return Read<FAudioMaterialButtonStyle>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x88, Type: StructProperty)
    bool bIsPressed() const { return Read<bool>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x1, Type: BoolProperty)

    void SET_WidgetStyle(const FAudioMaterialButtonStyle& Value) { Write<FAudioMaterialButtonStyle>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x88, Type: StructProperty)
    void SET_bIsPressed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1d8
class UAudioMaterialEnvelope : public UWidget
{
public:
    FAudioMaterialEnvelopeStyle WidgetStyle() const { return Read<FAudioMaterialEnvelopeStyle>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x48, Type: StructProperty)
    FAudioMaterialEnvelopeSettings EnvelopeSettings() const { return Read<FAudioMaterialEnvelopeSettings>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x24, Type: StructProperty)

    void SET_WidgetStyle(const FAudioMaterialEnvelopeStyle& Value) { Write<FAudioMaterialEnvelopeStyle>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x48, Type: StructProperty)
    void SET_EnvelopeSettings(const FAudioMaterialEnvelopeSettings& Value) { Write<FAudioMaterialEnvelopeSettings>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x24, Type: StructProperty)
};

// Size: 0x360
class UAudioMaterialKnob : public UWidget
{
public:
    FAudioMaterialKnobStyle WidgetStyle() const { return Read<FAudioMaterialKnobStyle>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x1c0, Type: StructProperty)
    float Value() const { return Read<float>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x4, Type: FloatProperty)
    float TuneSpeed() const { return Read<float>(uintptr_t(this) + 0x334); } // 0x334 (Size: 0x4, Type: FloatProperty)
    float FineTuneSpeed() const { return Read<float>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x4, Type: FloatProperty)
    bool bLocked() const { return Read<bool>(uintptr_t(this) + 0x33c); } // 0x33c (Size: 0x1, Type: BoolProperty)
    bool bMouseUsesStep() const { return Read<bool>(uintptr_t(this) + 0x33d); } // 0x33d (Size: 0x1, Type: BoolProperty)
    float StepSize() const { return Read<float>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x4, Type: FloatProperty)

    void SET_WidgetStyle(const FAudioMaterialKnobStyle& Value) { Write<FAudioMaterialKnobStyle>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x1c0, Type: StructProperty)
    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x4, Type: FloatProperty)
    void SET_TuneSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x334, Value); } // 0x334 (Size: 0x4, Type: FloatProperty)
    void SET_FineTuneSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x4, Type: FloatProperty)
    void SET_bLocked(const bool& Value) { Write<bool>(uintptr_t(this) + 0x33c, Value); } // 0x33c (Size: 0x1, Type: BoolProperty)
    void SET_bMouseUsesStep(const bool& Value) { Write<bool>(uintptr_t(this) + 0x33d, Value); } // 0x33d (Size: 0x1, Type: BoolProperty)
    void SET_StepSize(const float& Value) { Write<float>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x270
class UAudioMaterialMeter : public UWidget
{
public:
    FAudioMaterialMeterStyle WidgetStyle() const { return Read<FAudioMaterialMeterStyle>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0xe8, Type: StructProperty)
    TEnumAsByte<EOrientation> orientation() const { return Read<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x1, Type: ByteProperty)
    TArray<FMeterChannelInfo> MeterChannelInfo() const { return Read<TArray<FMeterChannelInfo>>(uintptr_t(this) + 0x260); } // 0x260 (Size: 0x10, Type: ArrayProperty)

    void SET_WidgetStyle(const FAudioMaterialMeterStyle& Value) { Write<FAudioMaterialMeterStyle>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0xe8, Type: StructProperty)
    void SET_orientation(const TEnumAsByte<EOrientation>& Value) { Write<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x1, Type: ByteProperty)
    void SET_MeterChannelInfo(const TArray<FMeterChannelInfo>& Value) { Write<TArray<FMeterChannelInfo>>(uintptr_t(this) + 0x260, Value); } // 0x260 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x2f0
class UAudioMaterialSlider : public UWidget
{
public:
    FAudioMaterialSliderStyle WidgetStyle() const { return Read<FAudioMaterialSliderStyle>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x150, Type: StructProperty)
    float Value() const { return Read<float>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EOrientation> orientation() const { return Read<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x2c4); } // 0x2c4 (Size: 0x1, Type: ByteProperty)
    float TuneSpeed() const { return Read<float>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x4, Type: FloatProperty)
    float FineTuneSpeed() const { return Read<float>(uintptr_t(this) + 0x2cc); } // 0x2cc (Size: 0x4, Type: FloatProperty)
    bool bLocked() const { return Read<bool>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x1, Type: BoolProperty)
    bool bMouseUsesStep() const { return Read<bool>(uintptr_t(this) + 0x2d1); } // 0x2d1 (Size: 0x1, Type: BoolProperty)
    float StepSize() const { return Read<float>(uintptr_t(this) + 0x2d4); } // 0x2d4 (Size: 0x4, Type: FloatProperty)

    void SET_WidgetStyle(const FAudioMaterialSliderStyle& Value) { Write<FAudioMaterialSliderStyle>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x150, Type: StructProperty)
    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x4, Type: FloatProperty)
    void SET_orientation(const TEnumAsByte<EOrientation>& Value) { Write<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x2c4, Value); } // 0x2c4 (Size: 0x1, Type: ByteProperty)
    void SET_TuneSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x4, Type: FloatProperty)
    void SET_FineTuneSpeed(const float& Value) { Write<float>(uintptr_t(this) + 0x2cc, Value); } // 0x2cc (Size: 0x4, Type: FloatProperty)
    void SET_bLocked(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x1, Type: BoolProperty)
    void SET_bMouseUsesStep(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2d1, Value); } // 0x2d1 (Size: 0x1, Type: BoolProperty)
    void SET_StepSize(const float& Value) { Write<float>(uintptr_t(this) + 0x2d4, Value); } // 0x2d4 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x1f0
class UAudioMaterialKnobWidgetStyle : public USlateWidgetStyleContainerBase
{
public:
    FAudioMaterialKnobStyle KnobStyle() const { return Read<FAudioMaterialKnobStyle>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1c0, Type: StructProperty)

    void SET_KnobStyle(const FAudioMaterialKnobStyle& Value) { Write<FAudioMaterialKnobStyle>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1c0, Type: StructProperty)
};

// Size: 0x118
class UAudioMaterialMeterWidgetStyle : public USlateWidgetStyleContainerBase
{
public:
    FAudioMaterialMeterStyle MeterStyle() const { return Read<FAudioMaterialMeterStyle>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0xe8, Type: StructProperty)

    void SET_MeterStyle(const FAudioMaterialMeterStyle& Value) { Write<FAudioMaterialMeterStyle>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0xe8, Type: StructProperty)
};

// Size: 0xb8
class UAudioMaterialButtonWidgetStyle : public USlateWidgetStyleContainerBase
{
public:
    FAudioMaterialButtonStyle ButtonStyle() const { return Read<FAudioMaterialButtonStyle>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x88, Type: StructProperty)

    void SET_ButtonStyle(const FAudioMaterialButtonStyle& Value) { Write<FAudioMaterialButtonStyle>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x88, Type: StructProperty)
};

// Size: 0x180
class UAudioMaterialSliderWidgetStyle : public USlateWidgetStyleContainerBase
{
public:
    FAudioMaterialSliderStyle SliderStyle() const { return Read<FAudioMaterialSliderStyle>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x150, Type: StructProperty)

    void SET_SliderStyle(const FAudioMaterialSliderStyle& Value) { Write<FAudioMaterialSliderStyle>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x150, Type: StructProperty)
};

// Size: 0x640
class UAudioMeter : public UWidget
{
public:
    TArray<FMeterChannelInfo> MeterChannelInfo() const { return Read<TArray<FMeterChannelInfo>>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x10, Type: ArrayProperty)
    FAudioMeterStyle WidgetStyle() const { return Read<FAudioMeterStyle>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x430, Type: StructProperty)
    TEnumAsByte<EOrientation> orientation() const { return Read<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x1, Type: ByteProperty)
    FLinearColor BackgroundColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x5b4); } // 0x5b4 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterBackgroundColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x5c4); } // 0x5c4 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterValueColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x5d4); } // 0x5d4 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterPeakColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x5e4); } // 0x5e4 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterClippingColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x5f4); } // 0x5f4 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterScaleColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x604); } // 0x604 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterScaleLabelColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x614); } // 0x614 (Size: 0x10, Type: StructProperty)

    void SET_MeterChannelInfo(const TArray<FMeterChannelInfo>& Value) { Write<TArray<FMeterChannelInfo>>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x10, Type: ArrayProperty)
    void SET_WidgetStyle(const FAudioMeterStyle& Value) { Write<FAudioMeterStyle>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x430, Type: StructProperty)
    void SET_orientation(const TEnumAsByte<EOrientation>& Value) { Write<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x1, Type: ByteProperty)
    void SET_BackgroundColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x5b4, Value); } // 0x5b4 (Size: 0x10, Type: StructProperty)
    void SET_MeterBackgroundColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x5c4, Value); } // 0x5c4 (Size: 0x10, Type: StructProperty)
    void SET_MeterValueColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x5d4, Value); } // 0x5d4 (Size: 0x10, Type: StructProperty)
    void SET_MeterPeakColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x5e4, Value); } // 0x5e4 (Size: 0x10, Type: StructProperty)
    void SET_MeterClippingColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x5f4, Value); } // 0x5f4 (Size: 0x10, Type: StructProperty)
    void SET_MeterScaleColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x604, Value); } // 0x604 (Size: 0x10, Type: StructProperty)
    void SET_MeterScaleLabelColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x614, Value); } // 0x614 (Size: 0x10, Type: StructProperty)
};

// Size: 0x620
class UAudioOscilloscope : public UWidget
{
public:
    FAudioOscilloscopePanelStyle OscilloscopeStyle() const { return Read<FAudioOscilloscopePanelStyle>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x440, Type: StructProperty)
    UAudioBus* AudioBus() const { return Read<UAudioBus*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    float MaxTimeWindowMs() const { return Read<float>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x4, Type: FloatProperty)
    float TimeWindowMs() const { return Read<float>(uintptr_t(this) + 0x5ac); } // 0x5ac (Size: 0x4, Type: FloatProperty)
    float AnalysisPeriodMs() const { return Read<float>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x4, Type: FloatProperty)
    bool bShowTimeGrid() const { return Read<bool>(uintptr_t(this) + 0x5b4); } // 0x5b4 (Size: 0x1, Type: BoolProperty)
    uint8_t TimeGridLabelsUnit() const { return Read<uint8_t>(uintptr_t(this) + 0x5b5); } // 0x5b5 (Size: 0x1, Type: EnumProperty)
    bool bShowAmplitudeGrid() const { return Read<bool>(uintptr_t(this) + 0x5b6); } // 0x5b6 (Size: 0x1, Type: BoolProperty)
    bool bShowAmplitudeLabels() const { return Read<bool>(uintptr_t(this) + 0x5b7); } // 0x5b7 (Size: 0x1, Type: BoolProperty)
    uint8_t AmplitudeGridLabelsUnit() const { return Read<uint8_t>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x1, Type: EnumProperty)
    uint8_t TriggerMode() const { return Read<uint8_t>(uintptr_t(this) + 0x5b9); } // 0x5b9 (Size: 0x1, Type: EnumProperty)
    float TriggerThreshold() const { return Read<float>(uintptr_t(this) + 0x5bc); } // 0x5bc (Size: 0x4, Type: FloatProperty)
    uint8_t PanelLayoutType() const { return Read<uint8_t>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x1, Type: EnumProperty)
    int32_t ChannelToAnalyze() const { return Read<int32_t>(uintptr_t(this) + 0x5c4); } // 0x5c4 (Size: 0x4, Type: IntProperty)

    void SET_OscilloscopeStyle(const FAudioOscilloscopePanelStyle& Value) { Write<FAudioOscilloscopePanelStyle>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x440, Type: StructProperty)
    void SET_AudioBus(const UAudioBus*& Value) { Write<UAudioBus*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    void SET_MaxTimeWindowMs(const float& Value) { Write<float>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x4, Type: FloatProperty)
    void SET_TimeWindowMs(const float& Value) { Write<float>(uintptr_t(this) + 0x5ac, Value); } // 0x5ac (Size: 0x4, Type: FloatProperty)
    void SET_AnalysisPeriodMs(const float& Value) { Write<float>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x4, Type: FloatProperty)
    void SET_bShowTimeGrid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5b4, Value); } // 0x5b4 (Size: 0x1, Type: BoolProperty)
    void SET_TimeGridLabelsUnit(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5b5, Value); } // 0x5b5 (Size: 0x1, Type: EnumProperty)
    void SET_bShowAmplitudeGrid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5b6, Value); } // 0x5b6 (Size: 0x1, Type: BoolProperty)
    void SET_bShowAmplitudeLabels(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5b7, Value); } // 0x5b7 (Size: 0x1, Type: BoolProperty)
    void SET_AmplitudeGridLabelsUnit(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x1, Type: EnumProperty)
    void SET_TriggerMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5b9, Value); } // 0x5b9 (Size: 0x1, Type: EnumProperty)
    void SET_TriggerThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x5bc, Value); } // 0x5bc (Size: 0x4, Type: FloatProperty)
    void SET_PanelLayoutType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x1, Type: EnumProperty)
    void SET_ChannelToAnalyze(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5c4, Value); } // 0x5c4 (Size: 0x4, Type: IntProperty)
};

// Size: 0x350
class UAudioRadialSlider : public UWidget
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EAudioRadialSliderLayout> WidgetLayout() const { return Read<TEnumAsByte<EAudioRadialSliderLayout>>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x1, Type: ByteProperty)
    FLinearColor CenterBackgroundColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x16c); } // 0x16c (Size: 0x10, Type: StructProperty)
    FLinearColor SliderProgressColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x17c); } // 0x17c (Size: 0x10, Type: StructProperty)
    FLinearColor SliderBarColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x18c); } // 0x18c (Size: 0x10, Type: StructProperty)
    FVector2D HandStartEndRatio() const { return Read<FVector2D>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x10, Type: StructProperty)
    FText UnitsText() const { return Read<FText>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x10, Type: TextProperty)
    FLinearColor TextLabelBackgroundColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x10, Type: StructProperty)
    bool ShowLabelOnlyOnHover() const { return Read<bool>(uintptr_t(this) + 0x1d0); } // 0x1d0 (Size: 0x1, Type: BoolProperty)
    bool ShowUnitsText() const { return Read<bool>(uintptr_t(this) + 0x1d1); } // 0x1d1 (Size: 0x1, Type: BoolProperty)
    bool IsUnitsTextReadOnly() const { return Read<bool>(uintptr_t(this) + 0x1d2); } // 0x1d2 (Size: 0x1, Type: BoolProperty)
    bool IsValueTextReadOnly() const { return Read<bool>(uintptr_t(this) + 0x1d3); } // 0x1d3 (Size: 0x1, Type: BoolProperty)
    float SliderThickness() const { return Read<float>(uintptr_t(this) + 0x1d4); } // 0x1d4 (Size: 0x4, Type: FloatProperty)
    FVector2D OutputRange() const { return Read<FVector2D>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x10, Type: StructProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: FloatProperty)
    void SET_WidgetLayout(const TEnumAsByte<EAudioRadialSliderLayout>& Value) { Write<TEnumAsByte<EAudioRadialSliderLayout>>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x1, Type: ByteProperty)
    void SET_CenterBackgroundColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x16c, Value); } // 0x16c (Size: 0x10, Type: StructProperty)
    void SET_SliderProgressColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x17c, Value); } // 0x17c (Size: 0x10, Type: StructProperty)
    void SET_SliderBarColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x18c, Value); } // 0x18c (Size: 0x10, Type: StructProperty)
    void SET_HandStartEndRatio(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x10, Type: StructProperty)
    void SET_UnitsText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x10, Type: TextProperty)
    void SET_TextLabelBackgroundColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x10, Type: StructProperty)
    void SET_ShowLabelOnlyOnHover(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d0, Value); } // 0x1d0 (Size: 0x1, Type: BoolProperty)
    void SET_ShowUnitsText(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d1, Value); } // 0x1d1 (Size: 0x1, Type: BoolProperty)
    void SET_IsUnitsTextReadOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d2, Value); } // 0x1d2 (Size: 0x1, Type: BoolProperty)
    void SET_IsValueTextReadOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d3, Value); } // 0x1d3 (Size: 0x1, Type: BoolProperty)
    void SET_SliderThickness(const float& Value) { Write<float>(uintptr_t(this) + 0x1d4, Value); } // 0x1d4 (Size: 0x4, Type: FloatProperty)
    void SET_OutputRange(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x350
class UAudioVolumeRadialSlider : public UAudioRadialSlider
{
public:
};

// Size: 0x350
class UAudioFrequencyRadialSlider : public UAudioRadialSlider
{
public:
};

// Size: 0x880
class UAudioSliderBase : public UWidget
{
public:
    float Value() const { return Read<float>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: FloatProperty)
    FText UnitsText() const { return Read<FText>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x10, Type: TextProperty)
    FLinearColor TextLabelBackgroundColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x10, Type: StructProperty)
    bool ShowLabelOnlyOnHover() const { return Read<bool>(uintptr_t(this) + 0x18c); } // 0x18c (Size: 0x1, Type: BoolProperty)
    bool ShowUnitsText() const { return Read<bool>(uintptr_t(this) + 0x18d); } // 0x18d (Size: 0x1, Type: BoolProperty)
    bool IsUnitsTextReadOnly() const { return Read<bool>(uintptr_t(this) + 0x18e); } // 0x18e (Size: 0x1, Type: BoolProperty)
    bool IsValueTextReadOnly() const { return Read<bool>(uintptr_t(this) + 0x18f); } // 0x18f (Size: 0x1, Type: BoolProperty)
    FLinearColor SliderBackgroundColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x19c); } // 0x19c (Size: 0x10, Type: StructProperty)
    FLinearColor SliderBarColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderThumbColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x1d4); } // 0x1d4 (Size: 0x10, Type: StructProperty)
    FLinearColor WidgetBackgroundColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x10, Type: StructProperty)
    TEnumAsByte<EOrientation> orientation() const { return Read<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x20c); } // 0x20c (Size: 0x1, Type: ByteProperty)

    void SET_Value(const float& Value) { Write<float>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: FloatProperty)
    void SET_UnitsText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x10, Type: TextProperty)
    void SET_TextLabelBackgroundColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x10, Type: StructProperty)
    void SET_ShowLabelOnlyOnHover(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18c, Value); } // 0x18c (Size: 0x1, Type: BoolProperty)
    void SET_ShowUnitsText(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18d, Value); } // 0x18d (Size: 0x1, Type: BoolProperty)
    void SET_IsUnitsTextReadOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18e, Value); } // 0x18e (Size: 0x1, Type: BoolProperty)
    void SET_IsValueTextReadOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18f, Value); } // 0x18f (Size: 0x1, Type: BoolProperty)
    void SET_SliderBackgroundColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x19c, Value); } // 0x19c (Size: 0x10, Type: StructProperty)
    void SET_SliderBarColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x10, Type: StructProperty)
    void SET_SliderThumbColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x1d4, Value); } // 0x1d4 (Size: 0x10, Type: StructProperty)
    void SET_WidgetBackgroundColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x10, Type: StructProperty)
    void SET_orientation(const TEnumAsByte<EOrientation>& Value) { Write<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x20c, Value); } // 0x20c (Size: 0x1, Type: ByteProperty)
};

// Size: 0x890
class UAudioSlider : public UAudioSliderBase
{
public:
    TWeakObjectPtr<UCurveFloat*> LinToOutputCurve() const { return Read<TWeakObjectPtr<UCurveFloat*>>(uintptr_t(this) + 0x880); } // 0x880 (Size: 0x8, Type: WeakObjectProperty)
    TWeakObjectPtr<UCurveFloat*> OutputToLinCurve() const { return Read<TWeakObjectPtr<UCurveFloat*>>(uintptr_t(this) + 0x888); } // 0x888 (Size: 0x8, Type: WeakObjectProperty)

    void SET_LinToOutputCurve(const TWeakObjectPtr<UCurveFloat*>& Value) { Write<TWeakObjectPtr<UCurveFloat*>>(uintptr_t(this) + 0x880, Value); } // 0x880 (Size: 0x8, Type: WeakObjectProperty)
    void SET_OutputToLinCurve(const TWeakObjectPtr<UCurveFloat*>& Value) { Write<TWeakObjectPtr<UCurveFloat*>>(uintptr_t(this) + 0x888, Value); } // 0x888 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x890
class UAudioVolumeSlider : public UAudioSlider
{
public:
};

// Size: 0x890
class UAudioFrequencySlider : public UAudioSliderBase
{
public:
    FVector2D OutputRange() const { return Read<FVector2D>(uintptr_t(this) + 0x880); } // 0x880 (Size: 0x10, Type: StructProperty)

    void SET_OutputRange(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x880, Value); } // 0x880 (Size: 0x10, Type: StructProperty)
};

// Size: 0x360
class UAudioVectorscope : public UWidget
{
public:
    FAudioVectorscopePanelStyle VectorscopeStyle() const { return Read<FAudioVectorscopePanelStyle>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x190, Type: StructProperty)
    UAudioBus* AudioBus() const { return Read<UAudioBus*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    bool bShowGrid() const { return Read<bool>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x1, Type: BoolProperty)
    int32_t GridDivisions() const { return Read<int32_t>(uintptr_t(this) + 0x2fc); } // 0x2fc (Size: 0x4, Type: IntProperty)
    float MaxDisplayPersistenceMs() const { return Read<float>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x4, Type: FloatProperty)
    float DisplayPersistenceMs() const { return Read<float>(uintptr_t(this) + 0x304); } // 0x304 (Size: 0x4, Type: FloatProperty)
    float Scale() const { return Read<float>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x4, Type: FloatProperty)
    uint8_t PanelLayoutType() const { return Read<uint8_t>(uintptr_t(this) + 0x30c); } // 0x30c (Size: 0x1, Type: EnumProperty)

    void SET_VectorscopeStyle(const FAudioVectorscopePanelStyle& Value) { Write<FAudioVectorscopePanelStyle>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x190, Type: StructProperty)
    void SET_AudioBus(const UAudioBus*& Value) { Write<UAudioBus*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    void SET_bShowGrid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x1, Type: BoolProperty)
    void SET_GridDivisions(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2fc, Value); } // 0x2fc (Size: 0x4, Type: IntProperty)
    void SET_MaxDisplayPersistenceMs(const float& Value) { Write<float>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x4, Type: FloatProperty)
    void SET_DisplayPersistenceMs(const float& Value) { Write<float>(uintptr_t(this) + 0x304, Value); } // 0x304 (Size: 0x4, Type: FloatProperty)
    void SET_Scale(const float& Value) { Write<float>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x4, Type: FloatProperty)
    void SET_PanelLayoutType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30c, Value); } // 0x30c (Size: 0x1, Type: EnumProperty)
};

// Size: 0xc
struct FMeterChannelInfo
{
public:
    float MeterValue() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float PeakValue() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float ClippingValue() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_MeterValue(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_PeakValue(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ClippingValue(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x18
struct FAudioMaterialWidgetStyle : public FSlateWidgetStyle
{
public:
    UMaterialInterface* Material() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FVector2f DesiredSize() const { return Read<FVector2f>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: StructProperty)

    void SET_Material(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_DesiredSize(const FVector2f& Value) { Write<FVector2f>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: StructProperty)
};

// Size: 0xe8
struct FAudioMaterialMeterStyle : public FAudioMaterialWidgetStyle
{
public:
    FLinearColor MeterFillMinColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterFillMidColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterFillMaxColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterFillBackgroundColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FVector2D MeterPadding() const { return Read<FVector2D>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FVector2D ValueRangeDb() const { return Read<FVector2D>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)
    bool bShowScale() const { return Read<bool>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x1, Type: BoolProperty)
    bool bScaleSide() const { return Read<bool>(uintptr_t(this) + 0x79); } // 0x79 (Size: 0x1, Type: BoolProperty)
    float ScaleHashOffset() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    float ScaleHashWidth() const { return Read<float>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: FloatProperty)
    float ScaleHashHeight() const { return Read<float>(uintptr_t(this) + 0x84); } // 0x84 (Size: 0x4, Type: FloatProperty)
    int32_t DecibelsPerHash() const { return Read<int32_t>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x4, Type: IntProperty)
    FSlateFontInfo Font() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x58, Type: StructProperty)

    void SET_MeterFillMinColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_MeterFillMidColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_MeterFillMaxColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_MeterFillBackgroundColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_MeterPadding(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_ValueRangeDb(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
    void SET_bShowScale(const bool& Value) { Write<bool>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x1, Type: BoolProperty)
    void SET_bScaleSide(const bool& Value) { Write<bool>(uintptr_t(this) + 0x79, Value); } // 0x79 (Size: 0x1, Type: BoolProperty)
    void SET_ScaleHashOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET_ScaleHashWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: FloatProperty)
    void SET_ScaleHashHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x84, Value); } // 0x84 (Size: 0x4, Type: FloatProperty)
    void SET_DecibelsPerHash(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x4, Type: IntProperty)
    void SET_Font(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x58, Type: StructProperty)
};

// Size: 0x430
struct FAudioMeterStyle : public FSlateWidgetStyle
{
public:
    FSlateBrush MeterValueImage() const { return Read<FSlateBrush>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xb0, Type: StructProperty)
    FSlateBrush BackgroundImage() const { return Read<FSlateBrush>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0xb0, Type: StructProperty)
    FSlateBrush MeterBackgroundImage() const { return Read<FSlateBrush>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0xb0, Type: StructProperty)
    FSlateBrush MeterValueBackgroundImage() const { return Read<FSlateBrush>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0xb0, Type: StructProperty)
    FSlateBrush MeterPeakImage() const { return Read<FSlateBrush>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0xb0, Type: StructProperty)
    FVector2D MeterSize() const { return Read<FVector2D>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x10, Type: StructProperty)
    FVector2D MeterPadding() const { return Read<FVector2D>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x10, Type: StructProperty)
    float MeterValuePadding() const { return Read<float>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x4, Type: FloatProperty)
    float PeakValueWidth() const { return Read<float>(uintptr_t(this) + 0x3a4); } // 0x3a4 (Size: 0x4, Type: FloatProperty)
    FVector2D ValueRangeDb() const { return Read<FVector2D>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x10, Type: StructProperty)
    bool bShowScale() const { return Read<bool>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x1, Type: BoolProperty)
    bool bScaleSide() const { return Read<bool>(uintptr_t(this) + 0x3b9); } // 0x3b9 (Size: 0x1, Type: BoolProperty)
    float ScaleHashOffset() const { return Read<float>(uintptr_t(this) + 0x3bc); } // 0x3bc (Size: 0x4, Type: FloatProperty)
    float ScaleHashWidth() const { return Read<float>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x4, Type: FloatProperty)
    float ScaleHashHeight() const { return Read<float>(uintptr_t(this) + 0x3c4); } // 0x3c4 (Size: 0x4, Type: FloatProperty)
    int32_t DecibelsPerHash() const { return Read<int32_t>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x4, Type: IntProperty)
    FSlateFontInfo Font() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x58, Type: StructProperty)

    void SET_MeterValueImage(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xb0, Type: StructProperty)
    void SET_BackgroundImage(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0xb0, Type: StructProperty)
    void SET_MeterBackgroundImage(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0xb0, Type: StructProperty)
    void SET_MeterValueBackgroundImage(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0xb0, Type: StructProperty)
    void SET_MeterPeakImage(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0xb0, Type: StructProperty)
    void SET_MeterSize(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x10, Type: StructProperty)
    void SET_MeterPadding(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x10, Type: StructProperty)
    void SET_MeterValuePadding(const float& Value) { Write<float>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x4, Type: FloatProperty)
    void SET_PeakValueWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x3a4, Value); } // 0x3a4 (Size: 0x4, Type: FloatProperty)
    void SET_ValueRangeDb(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x10, Type: StructProperty)
    void SET_bShowScale(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x1, Type: BoolProperty)
    void SET_bScaleSide(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b9, Value); } // 0x3b9 (Size: 0x1, Type: BoolProperty)
    void SET_ScaleHashOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x3bc, Value); } // 0x3bc (Size: 0x4, Type: FloatProperty)
    void SET_ScaleHashWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x4, Type: FloatProperty)
    void SET_ScaleHashHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x3c4, Value); } // 0x3c4 (Size: 0x4, Type: FloatProperty)
    void SET_DecibelsPerHash(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x4, Type: IntProperty)
    void SET_Font(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x58, Type: StructProperty)
};

// Size: 0x440
struct FAudioOscilloscopePanelStyle : public FSlateWidgetStyle
{
public:
    FFixedSampleSequenceRulerStyle TimeRulerStyle() const { return Read<FFixedSampleSequenceRulerStyle>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x230, Type: StructProperty)
    FSampledSequenceValueGridOverlayStyle ValueGridStyle() const { return Read<FSampledSequenceValueGridOverlayStyle>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x98, Type: StructProperty)
    FSampledSequenceViewerStyle WaveViewerStyle() const { return Read<FSampledSequenceViewerStyle>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x140, Type: StructProperty)
    FTriggerThresholdLineStyle TriggerThresholdLineStyle() const { return Read<FTriggerThresholdLineStyle>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x18, Type: StructProperty)

    void SET_TimeRulerStyle(const FFixedSampleSequenceRulerStyle& Value) { Write<FFixedSampleSequenceRulerStyle>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x230, Type: StructProperty)
    void SET_ValueGridStyle(const FSampledSequenceValueGridOverlayStyle& Value) { Write<FSampledSequenceValueGridOverlayStyle>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x98, Type: StructProperty)
    void SET_WaveViewerStyle(const FSampledSequenceViewerStyle& Value) { Write<FSampledSequenceViewerStyle>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x140, Type: StructProperty)
    void SET_TriggerThresholdLineStyle(const FTriggerThresholdLineStyle& Value) { Write<FTriggerThresholdLineStyle>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x18, Type: StructProperty)
};

// Size: 0x18
struct FTriggerThresholdLineStyle : public FSlateWidgetStyle
{
public:
    FLinearColor LineColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)

    void SET_LineColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x140
struct FSampledSequenceViewerStyle : public FSlateWidgetStyle
{
public:
    FSlateColor SequenceColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x14, Type: StructProperty)
    float SequenceLineThickness() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    FSlateColor MajorGridLineColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x14, Type: StructProperty)
    FSlateColor MinorGridLineColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x14, Type: StructProperty)
    FSlateColor ZeroCrossingLineColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x14, Type: StructProperty)
    float ZeroCrossingLineThickness() const { return Read<float>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: FloatProperty)
    float SampleMarkersSize() const { return Read<float>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: FloatProperty)
    FSlateColor SequenceBackgroundColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x14, Type: StructProperty)
    FSlateBrush BackgroundBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0xb0, Type: StructProperty)
    float DesiredWidth() const { return Read<float>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x4, Type: FloatProperty)
    float DesiredHeight() const { return Read<float>(uintptr_t(this) + 0x134); } // 0x134 (Size: 0x4, Type: FloatProperty)

    void SET_SequenceColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x14, Type: StructProperty)
    void SET_SequenceLineThickness(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_MajorGridLineColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x14, Type: StructProperty)
    void SET_MinorGridLineColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x14, Type: StructProperty)
    void SET_ZeroCrossingLineColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x14, Type: StructProperty)
    void SET_ZeroCrossingLineThickness(const float& Value) { Write<float>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: FloatProperty)
    void SET_SampleMarkersSize(const float& Value) { Write<float>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: FloatProperty)
    void SET_SequenceBackgroundColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x14, Type: StructProperty)
    void SET_BackgroundBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0xb0, Type: StructProperty)
    void SET_DesiredWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x4, Type: FloatProperty)
    void SET_DesiredHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x134, Value); } // 0x134 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x98
struct FSampledSequenceValueGridOverlayStyle : public FSlateWidgetStyle
{
public:
    FSlateColor GridColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x14, Type: StructProperty)
    float GridThickness() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    FSlateColor LabelTextColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x14, Type: StructProperty)
    FSlateFontInfo LabelTextFont() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x58, Type: StructProperty)
    float DesiredWidth() const { return Read<float>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x4, Type: FloatProperty)
    float DesiredHeight() const { return Read<float>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: FloatProperty)

    void SET_GridColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x14, Type: StructProperty)
    void SET_GridThickness(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_LabelTextColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x14, Type: StructProperty)
    void SET_LabelTextFont(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x58, Type: StructProperty)
    void SET_DesiredWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x4, Type: FloatProperty)
    void SET_DesiredHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x230
struct FFixedSampleSequenceRulerStyle : public FSlateWidgetStyle
{
public:
    float HandleWidth() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    FSlateColor HandleColor() const { return Read<FSlateColor>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x14, Type: StructProperty)
    FSlateBrush HandleBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0xb0, Type: StructProperty)
    FSlateColor TicksColor() const { return Read<FSlateColor>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x14, Type: StructProperty)
    FSlateColor TicksTextColor() const { return Read<FSlateColor>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x14, Type: StructProperty)
    FSlateFontInfo TicksTextFont() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x58, Type: StructProperty)
    float TicksTextOffset() const { return Read<float>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x4, Type: FloatProperty)
    FSlateColor BackgroundColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x154); } // 0x154 (Size: 0x14, Type: StructProperty)
    FSlateBrush BackgroundBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0xb0, Type: StructProperty)
    float DesiredWidth() const { return Read<float>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x4, Type: FloatProperty)
    float DesiredHeight() const { return Read<float>(uintptr_t(this) + 0x224); } // 0x224 (Size: 0x4, Type: FloatProperty)

    void SET_HandleWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_HandleColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x14, Type: StructProperty)
    void SET_HandleBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0xb0, Type: StructProperty)
    void SET_TicksColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x14, Type: StructProperty)
    void SET_TicksTextColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x14, Type: StructProperty)
    void SET_TicksTextFont(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x58, Type: StructProperty)
    void SET_TicksTextOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x4, Type: FloatProperty)
    void SET_BackgroundColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x154, Value); } // 0x154 (Size: 0x14, Type: StructProperty)
    void SET_BackgroundBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0xb0, Type: StructProperty)
    void SET_DesiredWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x4, Type: FloatProperty)
    void SET_DesiredHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x224, Value); } // 0x224 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x190
struct FAudioVectorscopePanelStyle : public FSlateWidgetStyle
{
public:
    FSampledSequenceValueGridOverlayStyle ValueGridStyle() const { return Read<FSampledSequenceValueGridOverlayStyle>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x98, Type: StructProperty)
    FSampledSequenceVectorViewerStyle VectorViewerStyle() const { return Read<FSampledSequenceVectorViewerStyle>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0xf0, Type: StructProperty)

    void SET_ValueGridStyle(const FSampledSequenceValueGridOverlayStyle& Value) { Write<FSampledSequenceValueGridOverlayStyle>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x98, Type: StructProperty)
    void SET_VectorViewerStyle(const FSampledSequenceVectorViewerStyle& Value) { Write<FSampledSequenceVectorViewerStyle>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0xf0, Type: StructProperty)
};

// Size: 0xf0
struct FSampledSequenceVectorViewerStyle : public FSlateWidgetStyle
{
public:
    FSlateColor BackgroundColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x14, Type: StructProperty)
    FSlateBrush BackgroundBrush() const { return Read<FSlateBrush>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0xb0, Type: StructProperty)
    FLinearColor LineColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x10, Type: StructProperty)
    float LineThickness() const { return Read<float>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: FloatProperty)

    void SET_BackgroundColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x14, Type: StructProperty)
    void SET_BackgroundBrush(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0xb0, Type: StructProperty)
    void SET_LineColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x10, Type: StructProperty)
    void SET_LineThickness(const float& Value) { Write<float>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x24
struct FAudioMaterialEnvelopeSettings
{
public:
    uint8_t EnvelopeType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    float AttackCurve() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float AttackValue() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float AttackTime() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float DecayCurve() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float DecayTime() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float SustainValue() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float ReleaseCurve() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float ReleaseTime() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)

    void SET_EnvelopeType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_AttackCurve(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_AttackValue(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_AttackTime(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_DecayCurve(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_DecayTime(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_SustainValue(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_ReleaseCurve(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_ReleaseTime(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x88
struct FAudioMaterialButtonStyle : public FAudioMaterialWidgetStyle
{
public:
    FLinearColor ButtonMainColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor ButtonMainColorTint_1() const { return Read<FLinearColor>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor ButtonMainColorTint_2() const { return Read<FLinearColor>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FLinearColor ButtonAccentColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FLinearColor ButtonShadowColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FLinearColor ButtonUnpressedOutlineColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)
    FLinearColor ButtonPressedOutlineColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StructProperty)

    void SET_ButtonMainColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_ButtonMainColorTint_1(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_ButtonMainColorTint_2(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_ButtonAccentColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_ButtonShadowColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_ButtonUnpressedOutlineColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
    void SET_ButtonPressedOutlineColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StructProperty)
};

// Size: 0x150
struct FAudioMaterialSliderStyle : public FAudioMaterialWidgetStyle
{
public:
    FLinearColor SliderBackgroundColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderBackgroundAccentColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderValueMainColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderHandleMainColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FLinearColor SliderHandleOutlineColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FAudioTextBoxStyle TextBoxStyle() const { return Read<FAudioTextBoxStyle>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0xe0, Type: StructProperty)

    void SET_SliderBackgroundColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_SliderBackgroundAccentColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_SliderValueMainColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_SliderHandleMainColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_SliderHandleOutlineColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_TextBoxStyle(const FAudioTextBoxStyle& Value) { Write<FAudioTextBoxStyle>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0xe0, Type: StructProperty)
};

// Size: 0xe0
struct FAudioTextBoxStyle : public FSlateWidgetStyle
{
public:
    FSlateBrush BackgroundImage() const { return Read<FSlateBrush>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xb0, Type: StructProperty)
    FSlateColor BackgroundColor() const { return Read<FSlateColor>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x14, Type: StructProperty)

    void SET_BackgroundImage(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xb0, Type: StructProperty)
    void SET_BackgroundColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x14, Type: StructProperty)
};

// Size: 0x1c0
struct FAudioMaterialKnobStyle : public FAudioMaterialWidgetStyle
{
public:
    FLinearColor KnobMainColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobAccentColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobShadowColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobSmoothBevelColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobIndicatorDotColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobEdgeFillColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobBarColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobBarShadowColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobBarFillMinColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobBarFillMidColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobBarFillMaxColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x10, Type: StructProperty)
    FLinearColor KnobBarFillTintColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: StructProperty)
    FAudioTextBoxStyle TextBoxStyle() const { return Read<FAudioTextBoxStyle>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0xe0, Type: StructProperty)

    void SET_KnobMainColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_KnobAccentColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_KnobShadowColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_KnobSmoothBevelColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_KnobIndicatorDotColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
    void SET_KnobEdgeFillColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StructProperty)
    void SET_KnobBarColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: StructProperty)
    void SET_KnobBarShadowColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: StructProperty)
    void SET_KnobBarFillMinColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StructProperty)
    void SET_KnobBarFillMidColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x10, Type: StructProperty)
    void SET_KnobBarFillMaxColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x10, Type: StructProperty)
    void SET_KnobBarFillTintColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: StructProperty)
    void SET_TextBoxStyle(const FAudioTextBoxStyle& Value) { Write<FAudioTextBoxStyle>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0xe0, Type: StructProperty)
};

// Size: 0x48
struct FAudioMaterialEnvelopeStyle : public FAudioMaterialWidgetStyle
{
public:
    FLinearColor CurveColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor BackgroundColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor OutlineColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)

    void SET_CurveColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_BackgroundColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_OutlineColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
};

// Size: 0x7
struct FSpectrogramRackUnitSettings
{
public:
    uint8_t AnalyzerType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t FFTAnalyzerFFTSize() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t CQTAnalyzerFFTSize() const { return Read<uint8_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t PixelPlotMode() const { return Read<uint8_t>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: EnumProperty)
    uint8_t FrequencyScale() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t ColorMap() const { return Read<uint8_t>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EOrientation> orientation() const { return Read<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x6); } // 0x6 (Size: 0x1, Type: ByteProperty)

    void SET_AnalyzerType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_FFTAnalyzerFFTSize(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_CQTAnalyzerFFTSize(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: EnumProperty)
    void SET_PixelPlotMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: EnumProperty)
    void SET_FrequencyScale(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_ColorMap(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: EnumProperty)
    void SET_orientation(const TEnumAsByte<EOrientation>& Value) { Write<TEnumAsByte<EOrientation>>(uintptr_t(this) + 0x6, Value); } // 0x6 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x9
struct FSpectrumAnalyzerRackUnitSettings
{
public:
    uint8_t Ballistics() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t AnalyzerType() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t FFTAnalyzerFFTSize() const { return Read<uint8_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: EnumProperty)
    uint8_t CQTAnalyzerFFTSize() const { return Read<uint8_t>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: EnumProperty)
    uint8_t TiltSpectrum() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    uint8_t PixelPlotMode() const { return Read<uint8_t>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: EnumProperty)
    uint8_t FrequencyScale() const { return Read<uint8_t>(uintptr_t(this) + 0x6); } // 0x6 (Size: 0x1, Type: EnumProperty)
    bool bDisplayFrequencyAxisLabels() const { return Read<bool>(uintptr_t(this) + 0x7); } // 0x7 (Size: 0x1, Type: BoolProperty)
    bool bDisplaySoundLevelAxisLabels() const { return Read<bool>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x1, Type: BoolProperty)

    void SET_Ballistics(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_AnalyzerType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_FFTAnalyzerFFTSize(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: EnumProperty)
    void SET_CQTAnalyzerFFTSize(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: EnumProperty)
    void SET_TiltSpectrum(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_PixelPlotMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: EnumProperty)
    void SET_FrequencyScale(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6, Value); } // 0x6 (Size: 0x1, Type: EnumProperty)
    void SET_bDisplayFrequencyAxisLabels(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7, Value); } // 0x7 (Size: 0x1, Type: BoolProperty)
    void SET_bDisplaySoundLevelAxisLabels(const bool& Value) { Write<bool>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x68
struct FAudioMeterDefaultColorStyle : public FSlateWidgetStyle
{
public:
    FLinearColor MeterBackgroundColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterValueColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterPeakColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterClippingColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterScaleColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    FLinearColor MeterScaleLabelColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x10, Type: StructProperty)

    void SET_MeterBackgroundColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x10, Type: StructProperty)
    void SET_MeterValueColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x10, Type: StructProperty)
    void SET_MeterPeakColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_MeterClippingColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: StructProperty)
    void SET_MeterScaleColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_MeterScaleLabelColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x10, Type: StructProperty)
};

// Size: 0x120
struct FAudioSpectrumPlotStyle : public FSlateWidgetStyle
{
public:
    FSlateColor BackgroundColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x14, Type: StructProperty)
    FSlateColor GridColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x14, Type: StructProperty)
    FSlateColor AxisLabelColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x14, Type: StructProperty)
    FSlateFontInfo AxisLabelFont() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x58, Type: StructProperty)
    FSlateColor SpectrumColor() const { return Read<FSlateColor>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x14, Type: StructProperty)
    FSlateColor CrosshairColor() const { return Read<FSlateColor>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x14, Type: StructProperty)
    FSlateFontInfo CrosshairLabelFont() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x58, Type: StructProperty)

    void SET_BackgroundColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x14, Type: StructProperty)
    void SET_GridColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x14, Type: StructProperty)
    void SET_AxisLabelColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x14, Type: StructProperty)
    void SET_AxisLabelFont(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x58, Type: StructProperty)
    void SET_SpectrumColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x14, Type: StructProperty)
    void SET_CrosshairColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x14, Type: StructProperty)
    void SET_CrosshairLabelFont(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x58, Type: StructProperty)
};

// Size: 0x650
struct FAudioSliderStyle : public FSlateWidgetStyle
{
public:
    FSliderStyle SliderStyle() const { return Read<FSliderStyle>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x440, Type: StructProperty)
    FAudioTextBoxStyle TextBoxStyle() const { return Read<FAudioTextBoxStyle>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0xe0, Type: StructProperty)
    FSlateBrush WidgetBackgroundImage() const { return Read<FSlateBrush>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0xb0, Type: StructProperty)
    FSlateColor SliderBackgroundColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x14, Type: StructProperty)
    FVector2D SliderBackgroundSize() const { return Read<FVector2D>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x10, Type: StructProperty)
    float LabelPadding() const { return Read<float>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x4, Type: FloatProperty)
    FSlateColor SliderBarColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x60c); } // 0x60c (Size: 0x14, Type: StructProperty)
    FSlateColor SliderThumbColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x14, Type: StructProperty)
    FSlateColor WidgetBackgroundColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x634); } // 0x634 (Size: 0x14, Type: StructProperty)

    void SET_SliderStyle(const FSliderStyle& Value) { Write<FSliderStyle>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x440, Type: StructProperty)
    void SET_TextBoxStyle(const FAudioTextBoxStyle& Value) { Write<FAudioTextBoxStyle>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0xe0, Type: StructProperty)
    void SET_WidgetBackgroundImage(const FSlateBrush& Value) { Write<FSlateBrush>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0xb0, Type: StructProperty)
    void SET_SliderBackgroundColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x14, Type: StructProperty)
    void SET_SliderBackgroundSize(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x10, Type: StructProperty)
    void SET_LabelPadding(const float& Value) { Write<float>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x4, Type: FloatProperty)
    void SET_SliderBarColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x60c, Value); } // 0x60c (Size: 0x14, Type: StructProperty)
    void SET_SliderThumbColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x14, Type: StructProperty)
    void SET_WidgetBackgroundColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x634, Value); } // 0x634 (Size: 0x14, Type: StructProperty)
};

// Size: 0x140
struct FAudioRadialSliderStyle : public FSlateWidgetStyle
{
public:
    FAudioTextBoxStyle TextBoxStyle() const { return Read<FAudioTextBoxStyle>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0xe0, Type: StructProperty)
    FSlateColor CenterBackgroundColor() const { return Read<FSlateColor>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x14, Type: StructProperty)
    FSlateColor SliderBarColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x104); } // 0x104 (Size: 0x14, Type: StructProperty)
    FSlateColor SliderProgressColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x14, Type: StructProperty)
    float LabelPadding() const { return Read<float>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: FloatProperty)
    float DefaultSliderRadius() const { return Read<float>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x4, Type: FloatProperty)

    void SET_TextBoxStyle(const FAudioTextBoxStyle& Value) { Write<FAudioTextBoxStyle>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0xe0, Type: StructProperty)
    void SET_CenterBackgroundColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x14, Type: StructProperty)
    void SET_SliderBarColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x104, Value); } // 0x104 (Size: 0x14, Type: StructProperty)
    void SET_SliderProgressColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x14, Type: StructProperty)
    void SET_LabelPadding(const float& Value) { Write<float>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: FloatProperty)
    void SET_DefaultSliderRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FPlayheadOverlayStyle : public FSlateWidgetStyle
{
public:
    FSlateColor PlayheadColor() const { return Read<FSlateColor>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x14, Type: StructProperty)
    float PlayheadWidth() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float DesiredWidth() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float DesiredHeight() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)

    void SET_PlayheadColor(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x14, Type: StructProperty)
    void SET_PlayheadWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_DesiredWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_DesiredHeight(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
};

