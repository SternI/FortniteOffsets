/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: ClothingSystemRuntimeCommon
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "Engine.h"
#include "ClothingSystemRuntimeInterface.h"
#include "CoreUObject.h"

// Size: 0x28
class UClothConfigCommon : public UClothConfigBase
{
public:
};

// Size: 0x28
class UClothSharedConfigCommon : public UClothConfigCommon
{
public:
};

// Size: 0x28
class UClothingAssetCustomData : public UObject
{
public:
};

// Size: 0xd8
class UClothingAssetCommon : public UClothingAssetBase
{
public:
    UPhysicsAsset* PhysicsAsset() const { return Read<UPhysicsAsset*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    TMap<UClothConfigBase*, FName> ClothConfigs() const { return Read<TMap<UClothConfigBase*, FName>>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x50, Type: MapProperty)
    TArray<FClothLODDataCommon> LODData() const { return Read<TArray<FClothLODDataCommon>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> LodMap() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    TArray<FName> UsedBoneNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> UsedBoneIndices() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    int32_t ReferenceBoneIndex() const { return Read<int32_t>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x4, Type: IntProperty)

    void SET_PhysicsAsset(const UPhysicsAsset*& Value) { Write<UPhysicsAsset*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET_ClothConfigs(const TMap<UClothConfigBase*, FName>& Value) { Write<TMap<UClothConfigBase*, FName>>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x50, Type: MapProperty)
    void SET_LODData(const TArray<FClothLODDataCommon>& Value) { Write<TArray<FClothLODDataCommon>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_LodMap(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: ArrayProperty)
    void SET_UsedBoneNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x10, Type: ArrayProperty)
    void SET_UsedBoneIndices(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x10, Type: ArrayProperty)
    void SET_ReferenceBoneIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x4, Type: IntProperty)
};

// Size: 0x1b8
class UClothLODDataCommon_Legacy : public UObject
{
public:
    UClothPhysicalMeshDataBase_Legacy* PhysicalMeshData() const { return Read<UClothPhysicalMeshDataBase_Legacy*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    FClothPhysicalMeshData ClothPhysicalMeshData() const { return Read<FClothPhysicalMeshData>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x128, Type: StructProperty)
    FClothCollisionData CollisionData() const { return Read<FClothCollisionData>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x40, Type: StructProperty)

    void SET_PhysicalMeshData(const UClothPhysicalMeshDataBase_Legacy*& Value) { Write<UClothPhysicalMeshDataBase_Legacy*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_ClothPhysicalMeshData(const FClothPhysicalMeshData& Value) { Write<FClothPhysicalMeshData>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x128, Type: StructProperty)
    void SET_CollisionData(const FClothCollisionData& Value) { Write<FClothCollisionData>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x40, Type: StructProperty)
};

// Size: 0x10
struct FClothConstraintSetup_Legacy
{
public:
    float Stiffness() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float StiffnessMultiplier() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float StretchLimit() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float CompressionLimit() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_Stiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_StiffnessMultiplier(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_StretchLimit(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_CompressionLimit(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x130
struct FClothConfig_Legacy
{
public:
    uint8_t WindMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    FClothConstraintSetup_Legacy VerticalConstraintConfig() const { return Read<FClothConstraintSetup_Legacy>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x10, Type: StructProperty)
    FClothConstraintSetup_Legacy HorizontalConstraintConfig() const { return Read<FClothConstraintSetup_Legacy>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x10, Type: StructProperty)
    FClothConstraintSetup_Legacy BendConstraintConfig() const { return Read<FClothConstraintSetup_Legacy>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x10, Type: StructProperty)
    FClothConstraintSetup_Legacy ShearConstraintConfig() const { return Read<FClothConstraintSetup_Legacy>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x10, Type: StructProperty)
    float SelfCollisionRadius() const { return Read<float>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionStiffness() const { return Read<float>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: FloatProperty)
    float SelfCollisionCullScale() const { return Read<float>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: FloatProperty)
    FVector Damping() const { return Read<FVector>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x18, Type: StructProperty)
    float Friction() const { return Read<float>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: FloatProperty)
    float WindDragCoefficient() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    float WindLiftCoefficient() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    FVector LinearDrag() const { return Read<FVector>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x18, Type: StructProperty)
    FVector AngularDrag() const { return Read<FVector>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x18, Type: StructProperty)
    FVector LinearInertiaScale() const { return Read<FVector>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x18, Type: StructProperty)
    FVector AngularInertiaScale() const { return Read<FVector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)
    FVector CentrifugalInertiaScale() const { return Read<FVector>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x18, Type: StructProperty)
    float SolverFrequency() const { return Read<float>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    float StiffnessFrequency() const { return Read<float>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    float GravityScale() const { return Read<float>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    FVector GravityOverride() const { return Read<FVector>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x18, Type: StructProperty)
    bool bUseGravityOverride() const { return Read<bool>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x1, Type: BoolProperty)
    float TetherStiffness() const { return Read<float>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x4, Type: FloatProperty)
    float TetherLimit() const { return Read<float>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: FloatProperty)
    float CollisionThickness() const { return Read<float>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x4, Type: FloatProperty)
    float AnimDriveSpringStiffness() const { return Read<float>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x4, Type: FloatProperty)
    float AnimDriveDamperStiffness() const { return Read<float>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: FloatProperty)

    void SET_WindMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_VerticalConstraintConfig(const FClothConstraintSetup_Legacy& Value) { Write<FClothConstraintSetup_Legacy>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x10, Type: StructProperty)
    void SET_HorizontalConstraintConfig(const FClothConstraintSetup_Legacy& Value) { Write<FClothConstraintSetup_Legacy>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x10, Type: StructProperty)
    void SET_BendConstraintConfig(const FClothConstraintSetup_Legacy& Value) { Write<FClothConstraintSetup_Legacy>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x10, Type: StructProperty)
    void SET_ShearConstraintConfig(const FClothConstraintSetup_Legacy& Value) { Write<FClothConstraintSetup_Legacy>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x10, Type: StructProperty)
    void SET_SelfCollisionRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: FloatProperty)
    void SET_SelfCollisionStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: FloatProperty)
    void SET_SelfCollisionCullScale(const float& Value) { Write<float>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: FloatProperty)
    void SET_Damping(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x18, Type: StructProperty)
    void SET_Friction(const float& Value) { Write<float>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: FloatProperty)
    void SET_WindDragCoefficient(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_WindLiftCoefficient(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_LinearDrag(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x18, Type: StructProperty)
    void SET_AngularDrag(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x18, Type: StructProperty)
    void SET_LinearInertiaScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x18, Type: StructProperty)
    void SET_AngularInertiaScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
    void SET_CentrifugalInertiaScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x18, Type: StructProperty)
    void SET_SolverFrequency(const float& Value) { Write<float>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: FloatProperty)
    void SET_StiffnessFrequency(const float& Value) { Write<float>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: FloatProperty)
    void SET_GravityScale(const float& Value) { Write<float>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x4, Type: FloatProperty)
    void SET_GravityOverride(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x18, Type: StructProperty)
    void SET_bUseGravityOverride(const bool& Value) { Write<bool>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x1, Type: BoolProperty)
    void SET_TetherStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x4, Type: FloatProperty)
    void SET_TetherLimit(const float& Value) { Write<float>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: FloatProperty)
    void SET_CollisionThickness(const float& Value) { Write<float>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x4, Type: FloatProperty)
    void SET_AnimDriveSpringStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x4, Type: FloatProperty)
    void SET_AnimDriveDamperStiffness(const float& Value) { Write<float>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: FloatProperty)
};

// Size: 0x10
struct FPointWeightMap
{
public:
    TArray<float> Values() const { return Read<TArray<float>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_Values(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x158
struct FClothLODDataCommon
{
public:
    FClothPhysicalMeshData PhysicalMeshData() const { return Read<FClothPhysicalMeshData>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x128, Type: StructProperty)
    bool bUseMultipleInfluences() const { return Read<bool>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x1, Type: BoolProperty)
    float SkinningKernelRadius() const { return Read<float>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x4, Type: FloatProperty)
    bool bSmoothTransition() const { return Read<bool>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x1, Type: BoolProperty)

    void SET_PhysicalMeshData(const FClothPhysicalMeshData& Value) { Write<FClothPhysicalMeshData>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x128, Type: StructProperty)
    void SET_bUseMultipleInfluences(const bool& Value) { Write<bool>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x1, Type: BoolProperty)
    void SET_SkinningKernelRadius(const float& Value) { Write<float>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x4, Type: FloatProperty)
    void SET_bSmoothTransition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x128
struct FClothPhysicalMeshData
{
public:
    TArray<FVector3f> Vertices() const { return Read<TArray<FVector3f>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<FVector3f> Normals() const { return Read<TArray<FVector3f>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<uint32_t> Indices() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    TMap<FPointWeightMap, uint32_t> WeightMaps() const { return Read<TMap<FPointWeightMap, uint32_t>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x50, Type: MapProperty)
    TArray<float> InverseMasses() const { return Read<TArray<float>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    TArray<FClothVertBoneData> BoneData() const { return Read<TArray<FClothVertBoneData>>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    TSet<int32_t> SelfCollisionVertexSet() const { return Read<TSet<int32_t>>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x50, Type: SetProperty)
    FClothTetherData EuclideanTethers() const { return Read<FClothTetherData>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x10, Type: StructProperty)
    FClothTetherData GeodesicTethers() const { return Read<FClothTetherData>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x10, Type: StructProperty)
    int32_t MaxBoneWeights() const { return Read<int32_t>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x4, Type: IntProperty)
    int32_t NumFixedVerts() const { return Read<int32_t>(uintptr_t(this) + 0x114); } // 0x114 (Size: 0x4, Type: IntProperty)
    TArray<uint32_t> SelfCollisionIndices() const { return Read<TArray<uint32_t>>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x10, Type: ArrayProperty)

    void SET_Vertices(const TArray<FVector3f>& Value) { Write<TArray<FVector3f>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_Normals(const TArray<FVector3f>& Value) { Write<TArray<FVector3f>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_Indices(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET_WeightMaps(const TMap<FPointWeightMap, uint32_t>& Value) { Write<TMap<FPointWeightMap, uint32_t>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x50, Type: MapProperty)
    void SET_InverseMasses(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_BoneData(const TArray<FClothVertBoneData>& Value) { Write<TArray<FClothVertBoneData>>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x10, Type: ArrayProperty)
    void SET_SelfCollisionVertexSet(const TSet<int32_t>& Value) { Write<TSet<int32_t>>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x50, Type: SetProperty)
    void SET_EuclideanTethers(const FClothTetherData& Value) { Write<FClothTetherData>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x10, Type: StructProperty)
    void SET_GeodesicTethers(const FClothTetherData& Value) { Write<FClothTetherData>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x10, Type: StructProperty)
    void SET_MaxBoneWeights(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x4, Type: IntProperty)
    void SET_NumFixedVerts(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x114, Value); } // 0x114 (Size: 0x4, Type: IntProperty)
    void SET_SelfCollisionIndices(const TArray<uint32_t>& Value) { Write<TArray<uint32_t>>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FClothTetherData
{
public:
};

// Size: 0x28
struct FClothParameterMask_Legacy
{
public:
    FName MaskName() const { return Read<FName>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: NameProperty)
    uint8_t CurrentTarget() const { return Read<uint8_t>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: EnumProperty)
    float MaxValue() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float MinValue() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    TArray<float> Values() const { return Read<TArray<float>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    bool bEnabled() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_MaskName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: NameProperty)
    void SET_CurrentTarget(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: EnumProperty)
    void SET_MaxValue(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_MinValue(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_Values(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_bEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

