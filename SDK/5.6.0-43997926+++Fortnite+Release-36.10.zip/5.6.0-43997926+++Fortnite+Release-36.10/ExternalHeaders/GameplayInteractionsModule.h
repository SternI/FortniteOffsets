/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: GameplayInteractionsModule
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "StateTreeModule.h"
#include "Engine.h"
#include "AIModule.h"
#include "SmartObjectsModule.h"
#include "ContextualAnimation.h"
#include "GameplayTags.h"

// Size: 0x50
class UGameplayInteractionSmartObjectBehaviorDefinition : public USmartObjectBehaviorDefinition
{
public:
    FStateTreeReference StateTreeReference() const { return Read<FStateTreeReference>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x28, Type: StructProperty)

    void SET_StateTreeReference(const FStateTreeReference& Value) { Write<FStateTreeReference>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x28, Type: StructProperty)
};

// Size: 0x158
class UAITask_UseGameplayInteraction : public UAITask
{
public:
    FGameplayInteractionContext GameplayInteractionContext() const { return Read<FGameplayInteractionContext>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x78, Type: StructProperty)
    UAITask_MoveTo* MoveToTask() const { return Read<UAITask_MoveTo*>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    FSmartObjectClaimHandle ClaimedHandle() const { return Read<FSmartObjectClaimHandle>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x28, Type: StructProperty)
    FGameplayInteractionAbortContext AbortContext() const { return Read<FGameplayInteractionAbortContext>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x1, Type: StructProperty)

    void SET_GameplayInteractionContext(const FGameplayInteractionContext& Value) { Write<FGameplayInteractionContext>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x78, Type: StructProperty)
    void SET_MoveToTask(const UAITask_MoveTo*& Value) { Write<UAITask_MoveTo*>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x8, Type: ObjectProperty)
    void SET_ClaimedHandle(const FSmartObjectClaimHandle& Value) { Write<FSmartObjectClaimHandle>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x28, Type: StructProperty)
    void SET_AbortContext(const FGameplayInteractionAbortContext& Value) { Write<FGameplayInteractionAbortContext>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x1, Type: StructProperty)
};

// Size: 0x48
class UGameplayInteractionStateTreeSchema : public UStateTreeSchema
{
public:
    UClass* ContextActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ClassProperty)
    UClass* SmartObjectActorClass() const { return Read<UClass*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ClassProperty)
    TArray<FStateTreeExternalDataDesc> ContextDataDescs() const { return Read<TArray<FStateTreeExternalDataDesc>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_ContextActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ClassProperty)
    void SET_SmartObjectActorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ClassProperty)
    void SET_ContextDataDescs(const TArray<FStateTreeExternalDataDesc>& Value) { Write<TArray<FStateTreeExternalDataDesc>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa0
class UStateTreeTask_PlayContextualAnim_InstanceData : public UObject
{
public:
    AActor* PrimaryActor() const { return Read<AActor*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    AActor* SecondaryActor() const { return Read<AActor*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    FName SecondaryRole() const { return Read<FName>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: NameProperty)
    AActor* TertiaryActor() const { return Read<AActor*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    FName TertiaryRole() const { return Read<FName>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: NameProperty)
    UContextualAnimSceneAsset* SceneAsset() const { return Read<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    FName SectionName() const { return Read<FName>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: NameProperty)
    uint8_t ExecutionMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x1, Type: EnumProperty)
    bool bWaitForNotifyEventToEnd() const { return Read<bool>(uintptr_t(this) + 0x5d); } // 0x5d (Size: 0x1, Type: BoolProperty)
    FName NotifyEventNameToEnd() const { return Read<FName>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: NameProperty)
    int32_t LoopsToRun() const { return Read<int32_t>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: IntProperty)
    bool bLoopForever() const { return Read<bool>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x1, Type: BoolProperty)
    float DelayBetweenLoops() const { return Read<float>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x4, Type: FloatProperty)
    float RandomDeviationBetweenLoops() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    TArray<FContextualAnimWarpTarget> WarpTargets() const { return Read<TArray<FContextualAnimWarpTarget>>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: ArrayProperty)

    void SET_PrimaryActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_SecondaryActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_SecondaryRole(const FName& Value) { Write<FName>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: NameProperty)
    void SET_TertiaryActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_TertiaryRole(const FName& Value) { Write<FName>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: NameProperty)
    void SET_SceneAsset(const UContextualAnimSceneAsset*& Value) { Write<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_SectionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: NameProperty)
    void SET_ExecutionMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x1, Type: EnumProperty)
    void SET_bWaitForNotifyEventToEnd(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5d, Value); } // 0x5d (Size: 0x1, Type: BoolProperty)
    void SET_NotifyEventNameToEnd(const FName& Value) { Write<FName>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: NameProperty)
    void SET_LoopsToRun(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: IntProperty)
    void SET_bLoopForever(const bool& Value) { Write<bool>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x1, Type: BoolProperty)
    void SET_DelayBetweenLoops(const float& Value) { Write<float>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x4, Type: FloatProperty)
    void SET_RandomDeviationBetweenLoops(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET_WarpTargets(const TArray<FContextualAnimWarpTarget>& Value) { Write<TArray<FContextualAnimWarpTarget>>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x78
struct FGameplayInteractionContext
{
public:
    FStateTreeInstanceData StateTreeInstanceData() const { return Read<FStateTreeInstanceData>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StructProperty)
    FSmartObjectClaimHandle ClaimedHandle() const { return Read<FSmartObjectClaimHandle>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x28, Type: StructProperty)
    FSmartObjectSlotEntranceHandle SlotEntranceHandle() const { return Read<FSmartObjectSlotEntranceHandle>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x18, Type: StructProperty)
    FGameplayInteractionAbortContext AbortContext() const { return Read<FGameplayInteractionAbortContext>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: StructProperty)
    AActor* ContextActor() const { return Read<AActor*>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    AActor* SmartObjectActor() const { return Read<AActor*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    UGameplayInteractionSmartObjectBehaviorDefinition* Definition() const { return Read<UGameplayInteractionSmartObjectBehaviorDefinition*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ObjectProperty)

    void SET_StateTreeInstanceData(const FStateTreeInstanceData& Value) { Write<FStateTreeInstanceData>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StructProperty)
    void SET_ClaimedHandle(const FSmartObjectClaimHandle& Value) { Write<FSmartObjectClaimHandle>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x28, Type: StructProperty)
    void SET_SlotEntranceHandle(const FSmartObjectSlotEntranceHandle& Value) { Write<FSmartObjectSlotEntranceHandle>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x18, Type: StructProperty)
    void SET_AbortContext(const FGameplayInteractionAbortContext& Value) { Write<FGameplayInteractionAbortContext>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: StructProperty)
    void SET_ContextActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x8, Type: ObjectProperty)
    void SET_SmartObjectActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ObjectProperty)
    void SET_Definition(const UGameplayInteractionSmartObjectBehaviorDefinition*& Value) { Write<UGameplayInteractionSmartObjectBehaviorDefinition*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1
struct FGameplayInteractionAbortContext
{
public:
    uint8_t Reason() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)

    void SET_Reason(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
};

// Size: 0x8
struct FGameplayInteractionSlotUserData : public FSmartObjectSlotStateData
{
public:
};

// Size: 0x20
struct FGameplayInteractionStateTreeTask : public FStateTreeTaskBase
{
public:
};

// Size: 0x20
struct FGameplayInteractionStateTreeCondition : public FStateTreeConditionBase
{
public:
};

// Size: 0x38
struct FGameplayInteractionMatchSlotTagsConditionInstanceData
{
public:
    FSmartObjectSlotHandle Slot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)
    FGameplayTagContainer TagsToMatch() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x20, Type: StructProperty)

    void SET_Slot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
    void SET_TagsToMatch(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x20, Type: StructProperty)
};

// Size: 0x30
struct FGameplayInteractionSlotTagsMatchCondition : public FGameplayInteractionStateTreeCondition
{
public:
    uint8_t Source() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t MatchType() const { return Read<uint8_t>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: EnumProperty)
    bool bExactMatch() const { return Read<bool>(uintptr_t(this) + 0x22); } // 0x22 (Size: 0x1, Type: BoolProperty)
    bool bInvert() const { return Read<bool>(uintptr_t(this) + 0x23); } // 0x23 (Size: 0x1, Type: BoolProperty)

    void SET_Source(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_MatchType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: EnumProperty)
    void SET_bExactMatch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x22, Value); } // 0x22 (Size: 0x1, Type: BoolProperty)
    void SET_bInvert(const bool& Value) { Write<bool>(uintptr_t(this) + 0x23, Value); } // 0x23 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x14
struct FGameplayInteractionQuerySlotTagsConditionInstanceData
{
public:
    FSmartObjectSlotHandle Slot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)

    void SET_Slot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
};

// Size: 0x78
struct FGameplayInteractionQuerySlotTagCondition : public FGameplayInteractionStateTreeCondition
{
public:
    uint8_t Source() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    FGameplayTagQuery TagQuery() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x48, Type: StructProperty)
    bool bInvert() const { return Read<bool>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x1, Type: BoolProperty)

    void SET_Source(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_TagQuery(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x48, Type: StructProperty)
    void SET_bInvert(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x14
struct FGameplayInteractionIsSlotHandleValidConditionInstanceData
{
public:
    FSmartObjectSlotHandle Slot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)

    void SET_Slot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
};

// Size: 0x28
struct FGameplayInteractionIsSlotHandleValidCondition : public FGameplayInteractionStateTreeCondition
{
public:
    bool bInvert() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_bInvert(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FGameplayInteractionFindSlotTaskInstanceData
{
public:
    FSmartObjectSlotHandle ReferenceSlot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)
    FSmartObjectSlotHandle ResultSlot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x14, Type: StructProperty)

    void SET_ReferenceSlot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
    void SET_ResultSlot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x14, Type: StructProperty)
};

// Size: 0x30
struct FGameplayInteractionFindSlotTask : public FGameplayInteractionStateTreeTask
{
public:
    uint8_t ReferenceType() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    FGameplayTag FindByTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: StructProperty)

    void SET_ReferenceType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_FindByTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: StructProperty)
};

// Size: 0x20
struct FGameplayInteractionGetSlotActorTaskInstanceData
{
public:
    FSmartObjectSlotHandle TargetSlot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)
    AActor* ResultActor() const { return Read<AActor*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)

    void SET_TargetSlot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
    void SET_ResultActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
struct FGameplayInteractionGetSlotActorTask : public FGameplayInteractionStateTreeTask
{
public:
    bool bFailIfNotFound() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)

    void SET_bFailIfNotFound(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x20
struct FGameplayInteractionListenSlotEventsTaskInstanceData
{
public:
    FSmartObjectSlotHandle TargetSlot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)

    void SET_TargetSlot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
};

// Size: 0x28
struct FGameplayInteractionListenSlotEventsTask : public FGameplayInteractionStateTreeTask
{
public:
};

// Size: 0x18
struct FGameplayInteractionModifySlotTagTaskInstanceData
{
public:
    FSmartObjectSlotHandle TargetSlot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)
    bool bTagRemoved() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)

    void SET_TargetSlot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
    void SET_bTagRemoved(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FGameplayInteractionModifySlotTagTask : public FGameplayInteractionStateTreeTask
{
public:
    uint8_t Modify() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bHandleExternalStopAsFailure() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    uint8_t Operation() const { return Read<uint8_t>(uintptr_t(this) + 0x22); } // 0x22 (Size: 0x1, Type: EnumProperty)
    FGameplayTag Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: StructProperty)

    void SET_Modify(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_bHandleExternalStopAsFailure(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_Operation(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x22, Value); } // 0x22 (Size: 0x1, Type: EnumProperty)
    void SET_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: StructProperty)
};

// Size: 0x14
struct FGameplayInteractionSendSlotEventTaskInstanceData
{
public:
    FSmartObjectSlotHandle TargetSlot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)

    void SET_TargetSlot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
};

// Size: 0x48
struct FGameplayInteractionSendSlotEventTask : public FGameplayInteractionStateTreeTask
{
public:
    FGameplayTag EventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)
    FInstancedStruct Payload() const { return Read<FInstancedStruct>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: StructProperty)
    uint8_t Trigger() const { return Read<uint8_t>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: EnumProperty)
    bool bHandleExternalStopAsFailure() const { return Read<bool>(uintptr_t(this) + 0x39); } // 0x39 (Size: 0x1, Type: BoolProperty)
    bool bShouldTriggerOnReselect() const { return Read<bool>(uintptr_t(this) + 0x3a); } // 0x3a (Size: 0x1, Type: BoolProperty)

    void SET_EventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
    void SET_Payload(const FInstancedStruct& Value) { Write<FInstancedStruct>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: StructProperty)
    void SET_Trigger(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: EnumProperty)
    void SET_bHandleExternalStopAsFailure(const bool& Value) { Write<bool>(uintptr_t(this) + 0x39, Value); } // 0x39 (Size: 0x1, Type: BoolProperty)
    void SET_bShouldTriggerOnReselect(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3a, Value); } // 0x3a (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FGameplayInteractionSetSlotEnabledInstanceData
{
public:
    FSmartObjectSlotHandle TargetSlot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)
    bool bInitialState() const { return Read<bool>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x1, Type: BoolProperty)

    void SET_TargetSlot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
    void SET_bInitialState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
struct FGameplayInteractionSetSlotEnabledTask : public FGameplayInteractionStateTreeTask
{
public:
    uint8_t Modify() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bHandleExternalStopAsFailure() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    bool bEnableSlot() const { return Read<bool>(uintptr_t(this) + 0x22); } // 0x22 (Size: 0x1, Type: BoolProperty)

    void SET_Modify(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_bHandleExternalStopAsFailure(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableSlot(const bool& Value) { Write<bool>(uintptr_t(this) + 0x22, Value); } // 0x22 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FGameplayInteractionSyncSlotTagStateInstanceData
{
public:
    FSmartObjectSlotHandle TargetSlot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)

    void SET_TargetSlot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
};

// Size: 0x30
struct FGameplayInteractionSyncSlotTagStateTask : public FGameplayInteractionStateTreeTask
{
public:
    FGameplayTag TagToMonitor() const { return Read<FGameplayTag>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)
    FGameplayTag BreakEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: StructProperty)

    void SET_TagToMonitor(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
    void SET_BreakEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: StructProperty)
};

// Size: 0x28
struct FGameplayInteractionSyncSlotTagTransitionInstanceData
{
public:
    FSmartObjectSlotHandle TargetSlot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x14, Type: StructProperty)

    void SET_TargetSlot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x14, Type: StructProperty)
};

// Size: 0x38
struct FGameplayInteractionSyncSlotTagTransitionTask : public FGameplayInteractionStateTreeTask
{
public:
    FGameplayTag TransitionFromTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: StructProperty)
    FGameplayTag TransitionToTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: StructProperty)
    FGameplayTag TransitionEventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)

    void SET_TransitionFromTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: StructProperty)
    void SET_TransitionToTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: StructProperty)
    void SET_TransitionEventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
};

// Size: 0x10
struct FPlayMontageStateTreeTaskInstanceData
{
public:
    AActor* Actor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    float ComputedDuration() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float time() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)

    void SET_Actor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ComputedDuration(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_time(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
struct FPlayMontageStateTreeTask : public FGameplayInteractionStateTreeTask
{
public:
    UAnimMontage* Montage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x8, Type: ObjectProperty)

    void SET_Montage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa0
struct FStateTreeTask_FindSlotEntranceLocation_InstanceData
{
public:
    AActor* UserActor() const { return Read<AActor*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    FSmartObjectSlotHandle ReferenceSlot() const { return Read<FSmartObjectSlotHandle>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x14, Type: StructProperty)
    FTransform EntryTransform() const { return Read<FTransform>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x60, Type: StructProperty)
    FGameplayTagContainer EntranceTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x20, Type: StructProperty)

    void SET_UserActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_ReferenceSlot(const FSmartObjectSlotHandle& Value) { Write<FSmartObjectSlotHandle>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x14, Type: StructProperty)
    void SET_EntryTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x60, Type: StructProperty)
    void SET_EntranceTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x20, Type: StructProperty)
};

// Size: 0x40
struct FStateTreeTask_FindSlotEntranceLocation : public FGameplayInteractionStateTreeTask
{
public:
    uint8_t SelectMethod() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    bool bProjectNavigationLocation() const { return Read<bool>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: BoolProperty)
    bool bTraceGroundLocation() const { return Read<bool>(uintptr_t(this) + 0x22); } // 0x22 (Size: 0x1, Type: BoolProperty)
    bool bCheckTransitionTrajectory() const { return Read<bool>(uintptr_t(this) + 0x23); } // 0x23 (Size: 0x1, Type: BoolProperty)
    bool bCheckEntranceLocationOverlap() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)
    bool bCheckSlotLocationOverlap() const { return Read<bool>(uintptr_t(this) + 0x25); } // 0x25 (Size: 0x1, Type: BoolProperty)
    bool bUseUpAxisLockedRotation() const { return Read<bool>(uintptr_t(this) + 0x26); } // 0x26 (Size: 0x1, Type: BoolProperty)
    bool bUseSlotLocationAsFallbackCandidate() const { return Read<bool>(uintptr_t(this) + 0x27); } // 0x27 (Size: 0x1, Type: BoolProperty)
    uint8_t LocationType() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    UClass* ValidationFilter() const { return Read<UClass*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ClassProperty)

    void SET_SelectMethod(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_bProjectNavigationLocation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: BoolProperty)
    void SET_bTraceGroundLocation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x22, Value); } // 0x22 (Size: 0x1, Type: BoolProperty)
    void SET_bCheckTransitionTrajectory(const bool& Value) { Write<bool>(uintptr_t(this) + 0x23, Value); } // 0x23 (Size: 0x1, Type: BoolProperty)
    void SET_bCheckEntranceLocationOverlap(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
    void SET_bCheckSlotLocationOverlap(const bool& Value) { Write<bool>(uintptr_t(this) + 0x25, Value); } // 0x25 (Size: 0x1, Type: BoolProperty)
    void SET_bUseUpAxisLockedRotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x26, Value); } // 0x26 (Size: 0x1, Type: BoolProperty)
    void SET_bUseSlotLocationAsFallbackCandidate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x27, Value); } // 0x27 (Size: 0x1, Type: BoolProperty)
    void SET_LocationType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_ValidationFilter(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x38
struct FStateTreeTask_GetSlotEntranceTags_InstanceData
{
public:
    FSmartObjectSlotEntranceHandle SlotEntranceHandle() const { return Read<FSmartObjectSlotEntranceHandle>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x18, Type: StructProperty)
    FGameplayTagContainer EntranceTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x20, Type: StructProperty)

    void SET_SlotEntranceHandle(const FSmartObjectSlotEntranceHandle& Value) { Write<FSmartObjectSlotEntranceHandle>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x18, Type: StructProperty)
    void SET_EntranceTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
struct FStateTreeTask_GetSlotEntranceTags : public FGameplayInteractionStateTreeTask
{
public:
};

// Size: 0x20
struct FStateTreeTask_PlayContextualAnim : public FStateTreeTaskCommonBase
{
public:
};

