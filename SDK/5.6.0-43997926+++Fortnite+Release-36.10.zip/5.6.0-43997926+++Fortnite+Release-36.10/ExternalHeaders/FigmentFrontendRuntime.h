/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FigmentFrontendRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"

// Size: 0x110
class UFigmentFrontendExperienceFlow : public UObject
{
public:
    TArray<FString> FlowStepArray() const { return Read<TArray<FString>>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    bool bEnableTrailer() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    FString CinematicTrailerVUID() const { return Read<FString>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x10, Type: StrProperty)
    FName CinematicTrailerString() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    TMap<FString, FString> CinematicTrailerRating() const { return Read<TMap<FString, FString>>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x50, Type: MapProperty)
    UClass* SimpleBuildAndEditModalHelper() const { return Read<UClass*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ClassProperty)

    void SET_FlowStepArray(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x10, Type: ArrayProperty)
    void SET_bEnableTrailer(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_CinematicTrailerVUID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x10, Type: StrProperty)
    void SET_CinematicTrailerString(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET_CinematicTrailerRating(const TMap<FString, FString>& Value) { Write<TMap<FString, FString>>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x50, Type: MapProperty)
    void SET_SimpleBuildAndEditModalHelper(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ClassProperty)
};

