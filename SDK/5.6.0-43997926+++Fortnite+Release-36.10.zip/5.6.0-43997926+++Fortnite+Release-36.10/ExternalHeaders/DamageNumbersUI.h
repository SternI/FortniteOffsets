/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DamageNumbersUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "FortniteGame.h"
#include "UMG.h"
#include "GameplayTags.h"
#include "CommonUI.h"
#include "CoreUObject.h"

// Size: 0x500
class UCommonUserWidget_DamageNumbers : public UCommonUserWidget
{
public:
    FVector WorldSpacePos() const { return Read<FVector>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x18, Type: StructProperty)
    FGameplayTag CheckAnimalTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x4, Type: StructProperty)
    float Damage() const { return Read<float>(uintptr_t(this) + 0x374); } // 0x374 (Size: 0x4, Type: FloatProperty)
    float AdditionalVerticalScreenOffset() const { return Read<float>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x4, Type: FloatProperty)
    double SpawnTime() const { return Read<double>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: DoubleProperty)
    FVector2D DamageNumberScaleVector() const { return Read<FVector2D>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x10, Type: StructProperty)
    FVector2D ScreenSpaceOffsetFromHitActor() const { return Read<FVector2D>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x10, Type: StructProperty)
    FVector2D InverseHUDScaleVector() const { return Read<FVector2D>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x10, Type: StructProperty)
    AActor* HitActor() const { return Read<AActor*>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    bool bHitAnimal() const { return Read<bool>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x1, Type: BoolProperty)
    bool bHitVehicle() const { return Read<bool>(uintptr_t(this) + 0x3c1); } // 0x3c1 (Size: 0x1, Type: BoolProperty)
    bool bIsPlayingCritAnimation() const { return Read<bool>(uintptr_t(this) + 0x3c2); } // 0x3c2 (Size: 0x1, Type: BoolProperty)
    bool bUpdateZeroDamagePosition() const { return Read<bool>(uintptr_t(this) + 0x3c3); } // 0x3c3 (Size: 0x1, Type: BoolProperty)
    FLinearColor HitColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x10, Type: StructProperty)
    FLinearColor VehicleColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x10, Type: StructProperty)
    FLinearColor CritColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x10, Type: StructProperty)
    FLinearColor HealthColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x10, Type: StructProperty)
    FLinearColor ShieldColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x10, Type: StructProperty)
    FLinearColor CritColor_Text() const { return Read<FLinearColor>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x10, Type: StructProperty)
    FLinearColor ShieldColor_Text() const { return Read<FLinearColor>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0x10, Type: StructProperty)
    FLinearColor HealthColor_InnerStroke() const { return Read<FLinearColor>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x10, Type: StructProperty)
    FLinearColor ShieldColor_InnerStroke() const { return Read<FLinearColor>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x10, Type: StructProperty)
    FLinearColor CritColor_InnerStroke() const { return Read<FLinearColor>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x10, Type: StructProperty)
    FLinearColor DamageIconVehicleColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x10, Type: StructProperty)
    FLinearColor DamageIconShieldColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x10, Type: StructProperty)
    FLinearColor DamageIconShieldOutline1Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x10, Type: StructProperty)
    FLinearColor DamageIconShieldOutline2Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x10, Type: StructProperty)
    FLinearColor DamageIconVehicleOutline1Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x10, Type: StructProperty)
    FLinearColor DamageIconVehicleOutline2Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x10, Type: StructProperty)
    UWidgetAnimation* OnDamage() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnDamage_Crit() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Number() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Number_Stroke() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    UImage* DamageTypeCrit() const { return Read<UImage*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    UImage* DamageTypeIcon() const { return Read<UImage*>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    UImage* DamageTypeIcon_EMP() const { return Read<UImage*>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)

    void SET_WorldSpacePos(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x18, Type: StructProperty)
    void SET_CheckAnimalTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x4, Type: StructProperty)
    void SET_Damage(const float& Value) { Write<float>(uintptr_t(this) + 0x374, Value); } // 0x374 (Size: 0x4, Type: FloatProperty)
    void SET_AdditionalVerticalScreenOffset(const float& Value) { Write<float>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x4, Type: FloatProperty)
    void SET_SpawnTime(const double& Value) { Write<double>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: DoubleProperty)
    void SET_DamageNumberScaleVector(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x10, Type: StructProperty)
    void SET_ScreenSpaceOffsetFromHitActor(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x10, Type: StructProperty)
    void SET_InverseHUDScaleVector(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x10, Type: StructProperty)
    void SET_HitActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    void SET_bHitAnimal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x1, Type: BoolProperty)
    void SET_bHitVehicle(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c1, Value); } // 0x3c1 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPlayingCritAnimation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c2, Value); } // 0x3c2 (Size: 0x1, Type: BoolProperty)
    void SET_bUpdateZeroDamagePosition(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c3, Value); } // 0x3c3 (Size: 0x1, Type: BoolProperty)
    void SET_HitColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x10, Type: StructProperty)
    void SET_VehicleColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x10, Type: StructProperty)
    void SET_CritColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x10, Type: StructProperty)
    void SET_HealthColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x10, Type: StructProperty)
    void SET_ShieldColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x10, Type: StructProperty)
    void SET_CritColor_Text(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x10, Type: StructProperty)
    void SET_ShieldColor_Text(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0x10, Type: StructProperty)
    void SET_HealthColor_InnerStroke(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x10, Type: StructProperty)
    void SET_ShieldColor_InnerStroke(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x10, Type: StructProperty)
    void SET_CritColor_InnerStroke(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x10, Type: StructProperty)
    void SET_DamageIconVehicleColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x10, Type: StructProperty)
    void SET_DamageIconShieldColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x10, Type: StructProperty)
    void SET_DamageIconShieldOutline1Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x10, Type: StructProperty)
    void SET_DamageIconShieldOutline2Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x10, Type: StructProperty)
    void SET_DamageIconVehicleOutline1Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x10, Type: StructProperty)
    void SET_DamageIconVehicleOutline2Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x10, Type: StructProperty)
    void SET_OnDamage(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    void SET_OnDamage_Crit(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Number(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Number_Stroke(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: ObjectProperty)
    void SET_DamageTypeCrit(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    void SET_DamageTypeIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    void SET_DamageTypeIcon_EMP(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xe0
class UCustomDamageNumbersDataComponent : public UActorComponent
{
public:
    int32_t Priority() const { return Read<int32_t>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: IntProperty)
    UClass* DamageNumbersClass() const { return Read<UClass*>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    bool bSpecifiedAsInstigator() const { return Read<bool>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x1, Type: BoolProperty)

    void SET_Priority(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: IntProperty)
    void SET_DamageNumbersClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x8, Type: ClassProperty)
    void SET_bSpecifiedAsInstigator(const bool& Value) { Write<bool>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x410
class UFortUserWidget_DamageNumbers : public UFortUserWidget
{
public:
    UClass* DefaultDamageNumberClass() const { return Read<UClass*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ClassProperty)
    double VerticalShiftForNewDamage() const { return Read<double>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: DoubleProperty)
    double AccumulationTime() const { return Read<double>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: DoubleProperty)
    int32_t MaxNumberCount() const { return Read<int32_t>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x4, Type: IntProperty)
    FVector OffsetFromPawnLocationDBNO() const { return Read<FVector>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x18, Type: StructProperty)
    FVector OffsetFromPawnLocation() const { return Read<FVector>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x18, Type: StructProperty)
    AFortPlayerPawn* BoundPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag HideDamageNumbersTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x4, Type: StructProperty)
    FGameplayTag DamageAtLocTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x38c); } // 0x38c (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer TagsToNotDisplayDmgNumbersOnSpecificActors() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x20, Type: StructProperty)
    UDynamicEntryBox* DynamicEntryBox_Numbers() const { return Read<UDynamicEntryBox*>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    TMap<int32_t, UClass*> PoolByClassController() const { return Read<TMap<int32_t, UClass*>>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x50, Type: MapProperty)
    FGameplayTag DamageCueEMPTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x4, Type: StructProperty)
    bool bPrecreateDamageNumberEntries() const { return Read<bool>(uintptr_t(this) + 0x40c); } // 0x40c (Size: 0x1, Type: BoolProperty)

    void SET_DefaultDamageNumberClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ClassProperty)
    void SET_VerticalShiftForNewDamage(const double& Value) { Write<double>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: DoubleProperty)
    void SET_AccumulationTime(const double& Value) { Write<double>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxNumberCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x4, Type: IntProperty)
    void SET_OffsetFromPawnLocationDBNO(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x18, Type: StructProperty)
    void SET_OffsetFromPawnLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x18, Type: StructProperty)
    void SET_BoundPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_HideDamageNumbersTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x4, Type: StructProperty)
    void SET_DamageAtLocTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x38c, Value); } // 0x38c (Size: 0x4, Type: StructProperty)
    void SET_TagsToNotDisplayDmgNumbersOnSpecificActors(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x20, Type: StructProperty)
    void SET_DynamicEntryBox_Numbers(const UDynamicEntryBox*& Value) { Write<UDynamicEntryBox*>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    void SET_PoolByClassController(const TMap<int32_t, UClass*>& Value) { Write<TMap<int32_t, UClass*>>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x50, Type: MapProperty)
    void SET_DamageCueEMPTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x4, Type: StructProperty)
    void SET_bPrecreateDamageNumberEntries(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40c, Value); } // 0x40c (Size: 0x1, Type: BoolProperty)
};

// Size: 0x30
class UFortGameSettingRegistryExtension_DamageNumbers : public UFortGameSettingRegistryExtension
{
public:
};

