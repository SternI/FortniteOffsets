/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FortMetasound
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "MetasoundEngine.h"

// Size: 0x40
class UFortMetaSoundCacheDefinition : public UDataAsset
{
public:
    FFortMetaSoundCache Cache() const { return Read<FFortMetaSoundCache>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)

    void SET_Cache(const FFortMetaSoundCache& Value) { Write<FFortMetaSoundCache>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
};

// Size: 0xa8
class UFortGameFeatureAction_PrecacheMetaSounds : public UGameFeatureAction_AudioActionBase
{
public:
    bool bDefineCacheInline() const { return Read<bool>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x1, Type: BoolProperty)
    UFortMetaSoundCacheDefinition* CacheDefinition() const { return Read<UFortMetaSoundCacheDefinition*>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    FFortMetaSoundCache InlineCacheDefinition() const { return Read<FFortMetaSoundCache>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: StructProperty)
    TMap<FCachedMetaSoundContainer, uint32_t> CachedMetaSoundsForDevice() const { return Read<TMap<FCachedMetaSoundContainer, uint32_t>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x50, Type: MapProperty)

    void SET_bDefineCacheInline(const bool& Value) { Write<bool>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x1, Type: BoolProperty)
    void SET_CacheDefinition(const UFortMetaSoundCacheDefinition*& Value) { Write<UFortMetaSoundCacheDefinition*>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x8, Type: ObjectProperty)
    void SET_InlineCacheDefinition(const FFortMetaSoundCache& Value) { Write<FFortMetaSoundCache>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: StructProperty)
    void SET_CachedMetaSoundsForDevice(const TMap<FCachedMetaSoundContainer, uint32_t>& Value) { Write<TMap<FCachedMetaSoundContainer, uint32_t>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x50, Type: MapProperty)
};

// Size: 0x230
class UFortMetaSoundInterfaceSubsystem : public UAudioEngineSubsystem
{
public:
};

// Size: 0x48
class UGameFeatureAction_AddParameterInterfaceDefinitions : public UGameFeatureAction_AudioActionBase
{
public:
    TArray<FInstancedStruct> Definitions() const { return Read<TArray<FInstancedStruct>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)

    void SET_Definitions(const TArray<FInstancedStruct>& Value) { Write<TArray<FInstancedStruct>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x28
struct FFortMetaSoundCacheEntry
{
public:
    TSoftObjectPtr<UMetaSoundSource> MetaSound() const { return Read<TSoftObjectPtr<UMetaSoundSource>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    int32_t MaxInstancesToCache() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    bool bUseSharedCache() const { return Read<bool>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x1, Type: BoolProperty)

    void SET_MetaSound(const TSoftObjectPtr<UMetaSoundSource>& Value) { Write<TSoftObjectPtr<UMetaSoundSource>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_MaxInstancesToCache(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_bUseSharedCache(const bool& Value) { Write<bool>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FFortMetaSoundCache
{
public:
    TArray<FFortMetaSoundCacheEntry> CacheEntries() const { return Read<TArray<FFortMetaSoundCacheEntry>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_CacheEntries(const TArray<FFortMetaSoundCacheEntry>& Value) { Write<TArray<FFortMetaSoundCacheEntry>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FCachedMetaSoundContainer
{
public:
    TArray<UMetaSoundSource*> CachedMetaSounds() const { return Read<TArray<UMetaSoundSource*>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_CachedMetaSounds(const TArray<UMetaSoundSource*>& Value) { Write<TArray<UMetaSoundSource*>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x10
struct FRecentPlayTimes
{
public:
    TArray<float> RecentPlayTimes() const { return Read<TArray<float>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_RecentPlayTimes(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1
struct FParameterInterfaceContext
{
public:
};

// Size: 0x8
struct FParameterInterfaceContext_ActiveSound : public FParameterInterfaceContext
{
public:
};

// Size: 0x8
struct FParameterInterfaceDefinition
{
public:
};

// Size: 0x8
struct FParameterInterfaceDefinition_ActiveSound : public FParameterInterfaceDefinition
{
public:
};

// Size: 0x8
struct FParameterInterfaceDefinition_ActiveSound_Movement : public FParameterInterfaceDefinition
{
public:
};

// Size: 0x10
struct FParameterInterfaceContext_ActiveSound_RecentCollection : public FParameterInterfaceContext_ActiveSound
{
public:
};

// Size: 0x8
struct FParameterInterfaceDefinition_ActiveSound_RecentCollection : public FParameterInterfaceDefinition
{
public:
};

// Size: 0x10
struct FParameterInterfaceContext_ActiveSound_Time : public FParameterInterfaceContext_ActiveSound
{
public:
};

// Size: 0x8
struct FParameterInterfaceDefinition_ActiveSound_Time : public FParameterInterfaceDefinition
{
public:
};

