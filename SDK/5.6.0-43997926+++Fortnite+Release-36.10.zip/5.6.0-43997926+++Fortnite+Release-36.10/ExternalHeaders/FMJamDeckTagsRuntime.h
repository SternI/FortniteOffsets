/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FMJamDeckTagsRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "GameplayTags.h"

// Size: 0x38
class UJamDeckTagsAsset : public UObject
{
public:
    FGameplayTag PermitJamDeckTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: StructProperty)
    FGameplayTag RestrictJamDeckTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: StructProperty)
    FGameplayTag AlwaysSpawnDecksTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: StructProperty)

    void SET_PermitJamDeckTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: StructProperty)
    void SET_RestrictJamDeckTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: StructProperty)
    void SET_AlwaysSpawnDecksTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: StructProperty)
};

