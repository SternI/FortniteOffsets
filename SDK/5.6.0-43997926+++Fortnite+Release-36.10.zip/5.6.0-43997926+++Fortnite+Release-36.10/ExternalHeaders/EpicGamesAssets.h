/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicGamesAssets
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "VerseAssets.h"
#include "Niagara.h"

// Size: 0x2e8
class APlayedSoundReplication : public AActor
{
public:
    double StartTime() const { return Read<double>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: DoubleProperty)
    bool bPlaySound2D() const { return Read<bool>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x1, Type: BoolProperty)
    UVerseAssetPtr* SoundAsset() const { return Read<UVerseAssetPtr*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* AudioComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    USoundAttenuation* SoundAttenuation() const { return Read<USoundAttenuation*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)

    void SET_StartTime(const double& Value) { Write<double>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: DoubleProperty)
    void SET_bPlaySound2D(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x1, Type: BoolProperty)
    void SET_SoundAsset(const UVerseAssetPtr*& Value) { Write<UVerseAssetPtr*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundAttenuation(const USoundAttenuation*& Value) { Write<USoundAttenuation*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2e0
class ASpawnedParticleSystemReplication : public AActor
{
public:
    double StartTime() const { return Read<double>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: DoubleProperty)
    UVerseAssetPtr* VFXAsset() const { return Read<UVerseAssetPtr*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* VFXComponent() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)

    void SET_StartTime(const double& Value) { Write<double>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: DoubleProperty)
    void SET_VFXAsset(const UVerseAssetPtr*& Value) { Write<UVerseAssetPtr*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_VFXComponent(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
};

