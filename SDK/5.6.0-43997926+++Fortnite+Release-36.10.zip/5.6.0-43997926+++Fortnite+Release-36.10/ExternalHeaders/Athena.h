/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Athena
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "UI.h"
#include "Engine.h"
#include "CoreUObject.h"
#include "CommonUI.h"
#include "EngineCameras.h"
#include "UIKit.h"
#include "Systems.h"
#include "GameplayAbilities.h"
#include "CommonUILegacy.h"
#include "UMG.h"
#include "FortniteAI.h"
#include "FortniteGame.h"
#include "Water.h"
#include "GameplayTags.h"
#include "AmbientAudio.h"
#include "AudioModulation.h"
#include "AnimGraphRuntime.h"
#include "Creative.h"
#include "Sounds.h"
#include "Effects.h"
#include "AudioExtensions.h"
#include "Niagara.h"
#include "SoundLibrary.h"
#include "AnimBP.h"
#include "GameplayEventRouter.h"
#include "ItemizationCoreRuntime.h"
#include "Environments.h"
#include "AIModule.h"
#include "FortniteUI.h"
#include "SlateCore.h"
#include "MotionWarping.h"
#include "ContextualAnimation.h"
#include "Gadgets.h"
#include "BP_ProjectileTrajectory.h"
#include "Building.h"
#include "FluidSimulation.h"

// Size: 0xa68
class UGE_NPC_Parent_DirectDamage_C : public UGET_DirectCreatureDamage_C
{
public:
};

// Size: 0xa68
class UGE_NPC_Parent_DestroyBuilding_C : public UGE_NPC_Parent_DirectDamage_C
{
public:
};

// Size: 0x180
class UMinigameStat_Score_C : public UFortMinigameStatFilter
{
public:
};

// Size: 0x90
class UStormCameraModifier_C : public UStormCameraModifier
{
public:
    FVector4 Saturation() const { return Read<FVector4>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x20, Type: StructProperty)
    FVector4 Contrast() const { return Read<FVector4>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x20, Type: StructProperty)

    void SET_Saturation(const FVector4& Value) { Write<FVector4>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x20, Type: StructProperty)
    void SET_Contrast(const FVector4& Value) { Write<FVector4>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x20, Type: StructProperty)
};

// Size: 0x350
class USquadMarkerConfirmationWidget_C : public UAthenaMarkerConfirmationWidget
{
public:
};

// Size: 0x3f8
class UWBP_PlayerVisited_Context_C : public UAthenaCommonPrioritizedWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_POIState() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_LandmarkState() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    UCommonWidgetSwitcherLegacy* Switcher_landmarkerPOI() const { return Read<UCommonWidgetSwitcherLegacy*>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* MainLocationText() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x8, Type: StructProperty)
    void SET_Text_POIState(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_LandmarkState(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_landmarkerPOI(const UCommonWidgetSwitcherLegacy*& Value) { Write<UCommonWidgetSwitcherLegacy*>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    void SET_MainLocationText(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x488
class UW_MobileDefaultSettingsChangeModal_C : public UMobileDefaultSettingsChangeModal
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_Dialog_Internal_C* Dialog_Internal() const { return Read<UWBP_UIKit_Dialog_Internal_C*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: StructProperty)
    void SET_Dialog_Internal(const UWBP_UIKit_Dialog_Internal_C*& Value) { Write<UWBP_UIKit_Dialog_Internal_C*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3a0
class UMatchmakingInputIndicator_C : public UMatchmakingInputIndicatorBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: StructProperty)
    UImage* InputIcon() const { return Read<UImage*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: StructProperty)
    void SET_InputIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UStormDaySequenceInterface_C : public UInterface
{
public:
};

// Size: 0xa68
class UGE_Athena_TillLandFallDamageImmunity_Grant_Parent_C : public UGameplayEffect
{
public:
};

// Size: 0x780
class UMissionGen_NoBuildBR_Solo_C : public UFortMissionGenerator
{
public:
};

// Size: 0x780
class UMissionGen_Gold_C : public UFortMissionGenerator
{
public:
};

// Size: 0x780
class UMissionGen_Toss_C : public UFortMissionGenerator
{
public:
};

// Size: 0x780
class UMissionGen_Trios_C : public UFortMissionGenerator
{
public:
};

// Size: 0x780
class UMissionGen_Respawn_C : public UFortMissionGenerator
{
public:
};

// Size: 0x780
class UMissionGen_NoBuildBR_Squad_C : public UFortMissionGenerator
{
public:
};

// Size: 0x780
class UMissionGen_NoBuildBR_Duo_C : public UFortMissionGenerator
{
public:
};

// Size: 0x780
class UMissionGen_NoBuildBR_Trio_C : public UFortMissionGenerator
{
public:
};

// Size: 0x780
class UMissionGen_BigBattle_C : public UFortMissionGenerator
{
public:
};

// Size: 0x780
class UMissionGen_Mash_C : public UFortMissionGenerator
{
public:
};

// Size: 0xa00
class AGCN_Loop_Snow_Whiteout_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    UPostProcessComponent* PostProcess() const { return Read<UPostProcessComponent*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    float FadeinOut_Post_BDCA5FC943E3CD00D42B59A9A0D1C530() const { return Read<float>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x4, Type: FloatProperty)
    float FadeinOut_Fade_BDCA5FC943E3CD00D42B59A9A0D1C530() const { return Read<float>(uintptr_t(this) + 0x9dc); } // 0x9dc (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> FadeinOut__Direction_BDCA5FC943E3CD00D42B59A9A0D1C530() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* FadeInOut() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SoundOnFadeIn() const { return Read<USoundBase*>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SoundOnFadeOut() const { return Read<USoundBase*>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_PostProcess(const UPostProcessComponent*& Value) { Write<UPostProcessComponent*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_FadeinOut_Post_BDCA5FC943E3CD00D42B59A9A0D1C530(const float& Value) { Write<float>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x4, Type: FloatProperty)
    void SET_FadeinOut_Fade_BDCA5FC943E3CD00D42B59A9A0D1C530(const float& Value) { Write<float>(uintptr_t(this) + 0x9dc, Value); } // 0x9dc (Size: 0x4, Type: FloatProperty)
    void SET_FadeinOut__Direction_BDCA5FC943E3CD00D42B59A9A0D1C530(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x1, Type: ByteProperty)
    void SET_FadeInOut(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundOnFadeIn(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundOnFadeOut(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x2b8
class APapayaBoundarySpline_C : public AActor
{
public:
    USplineComponent* Spline2() const { return Read<USplineComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_Spline2(const USplineComponent*& Value) { Write<USplineComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x780
class UMissionGen_Papaya_C : public UFortMissionGenerator
{
public:
};

// Size: 0x40
struct FSTRUCT_WarningData
{
public:
    FText WarningText_2_8C8B54C740E74BC85C1346BD21F3BDF5() const { return Read<FText>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: TextProperty)
    UMaterialInstance* Image_5_4F84EB8C4E689D497CBDF7A68AFEB2D9() const { return Read<UMaterialInstance*>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    int32_t Priority_8_8C9CED6445FCED6BA9A5E08BF207F6A3() const { return Read<int32_t>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: IntProperty)
    bool ShowBolt_11_8617663F4B68570A07EC6C94883ACC0A() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)
    FLinearColor TextShadowColor_15_3EBAAB0244AAD10D6A220FBDD9D8499B() const { return Read<FLinearColor>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: StructProperty)
    FLinearColor TextOutlineColor_18_439E79DA4234BD56DD175DB209F6325D() const { return Read<FLinearColor>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: StructProperty)

    void SET_WarningText_2_8C8B54C740E74BC85C1346BD21F3BDF5(const FText& Value) { Write<FText>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: TextProperty)
    void SET_Image_5_4F84EB8C4E689D497CBDF7A68AFEB2D9(const UMaterialInstance*& Value) { Write<UMaterialInstance*>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x8, Type: ObjectProperty)
    void SET_Priority_8_8C9CED6445FCED6BA9A5E08BF207F6A3(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: IntProperty)
    void SET_ShowBolt_11_8617663F4B68570A07EC6C94883ACC0A(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
    void SET_TextShadowColor_15_3EBAAB0244AAD10D6A220FBDD9D8499B(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: StructProperty)
    void SET_TextOutlineColor_18_439E79DA4234BD56DD175DB209F6325D(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: StructProperty)
};

// Size: 0x30
class UVictoryImageStyles_C : public URichTextBlockImageDecorator
{
public:
};

// Size: 0xcaa
class ABP_SprayDecal_C : public AFortSprayDecalInstance
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xbf8); } // 0xbf8 (Size: 0x8, Type: StructProperty)
    double DecalFadeoutTime() const { return Read<double>(uintptr_t(this) + 0xc00); } // 0xc00 (Size: 0x8, Type: DoubleProperty)
    UDecalComponent* EmissiveDecal() const { return Read<UDecalComponent*>(uintptr_t(this) + 0xc08); } // 0xc08 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* EmissiveDecalMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x8, Type: ObjectProperty)
    double DecalSize() const { return Read<double>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x8, Type: DoubleProperty)
    UMaterialInterface* EmissiveMatSource() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0xc20); } // 0xc20 (Size: 0x8, Type: ObjectProperty)
    double DecalDepth() const { return Read<double>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x8, Type: DoubleProperty)
    UAthenaSprayItemDefinition* SprayAsset() const { return Read<UAthenaSprayItemDefinition*>(uintptr_t(this) + 0xc30); } // 0xc30 (Size: 0x8, Type: ObjectProperty)
    int32_t LoadsOutstanding() const { return Read<int32_t>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x4, Type: IntProperty)
    TSoftObjectPtr<UTexture2D> DecalTextureOverrideSoft() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0xc40); } // 0xc40 (Size: 0x20, Type: SoftObjectProperty)
    UTexture2D* DecalTextureOverride() const { return Read<UTexture2D*>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x8, Type: ObjectProperty)
    FLinearColor BannerPrimaryColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xc68); } // 0xc68 (Size: 0x10, Type: StructProperty)
    FLinearColor BannerSecondaryColor() const { return Read<FLinearColor>(uintptr_t(this) + 0xc78); } // 0xc78 (Size: 0x10, Type: StructProperty)
    AFortPlayerController* SpawningPlayerController() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x8, Type: ObjectProperty)
    TArray<AActor*> NearbyBuildingActors() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0xc90); } // 0xc90 (Size: 0x10, Type: ArrayProperty)
    double SpawnStartTimeDelay() const { return Read<double>(uintptr_t(this) + 0xca0); } // 0xca0 (Size: 0x8, Type: DoubleProperty)
    bool bIsFrontEndPreview() const { return Read<bool>(uintptr_t(this) + 0xca8); } // 0xca8 (Size: 0x1, Type: BoolProperty)
    bool bDestroyOnTrapPlaced() const { return Read<bool>(uintptr_t(this) + 0xca9); } // 0xca9 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xbf8, Value); } // 0xbf8 (Size: 0x8, Type: StructProperty)
    void SET_DecalFadeoutTime(const double& Value) { Write<double>(uintptr_t(this) + 0xc00, Value); } // 0xc00 (Size: 0x8, Type: DoubleProperty)
    void SET_EmissiveDecal(const UDecalComponent*& Value) { Write<UDecalComponent*>(uintptr_t(this) + 0xc08, Value); } // 0xc08 (Size: 0x8, Type: ObjectProperty)
    void SET_EmissiveDecalMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x8, Type: ObjectProperty)
    void SET_DecalSize(const double& Value) { Write<double>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x8, Type: DoubleProperty)
    void SET_EmissiveMatSource(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0xc20, Value); } // 0xc20 (Size: 0x8, Type: ObjectProperty)
    void SET_DecalDepth(const double& Value) { Write<double>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x8, Type: DoubleProperty)
    void SET_SprayAsset(const UAthenaSprayItemDefinition*& Value) { Write<UAthenaSprayItemDefinition*>(uintptr_t(this) + 0xc30, Value); } // 0xc30 (Size: 0x8, Type: ObjectProperty)
    void SET_LoadsOutstanding(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x4, Type: IntProperty)
    void SET_DecalTextureOverrideSoft(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0xc40, Value); } // 0xc40 (Size: 0x20, Type: SoftObjectProperty)
    void SET_DecalTextureOverride(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x8, Type: ObjectProperty)
    void SET_BannerPrimaryColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xc68, Value); } // 0xc68 (Size: 0x10, Type: StructProperty)
    void SET_BannerSecondaryColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xc78, Value); } // 0xc78 (Size: 0x10, Type: StructProperty)
    void SET_SpawningPlayerController(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x8, Type: ObjectProperty)
    void SET_NearbyBuildingActors(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0xc90, Value); } // 0xc90 (Size: 0x10, Type: ArrayProperty)
    void SET_SpawnStartTimeDelay(const double& Value) { Write<double>(uintptr_t(this) + 0xca0, Value); } // 0xca0 (Size: 0x8, Type: DoubleProperty)
    void SET_bIsFrontEndPreview(const bool& Value) { Write<bool>(uintptr_t(this) + 0xca8, Value); } // 0xca8 (Size: 0x1, Type: BoolProperty)
    void SET_bDestroyOnTrapPlaced(const bool& Value) { Write<bool>(uintptr_t(this) + 0xca9, Value); } // 0xca9 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
class UCampfire_Interface_C : public UInterface
{
public:
};

// Size: 0x28
class USafeZoneIndicatorMaterial_Interface_C : public UInterface
{
public:
};

// Size: 0xa68
class UGE_Athena_EnhancedResurrection_PostReboot_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_OutsideSafeZoneDamageCN_C : public UGET_PeriodicEnergyDamage_C
{
public:
};

// Size: 0x1a9
class UBP_AmbientAudioController_C : public UFortAmbientAudioController
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x8, Type: StructProperty)
    double CheckFrequency() const { return Read<double>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x8, Type: DoubleProperty)
    bool bInSnowCurrent() const { return Read<bool>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    UAmbientAudioDataAsset* WinterAudioBank() const { return Read<UAmbientAudioDataAsset*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    bool bSnowEnabled() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)
    UAmbientAudioDataAsset* CurieAudioBank() const { return Read<UAmbientAudioDataAsset*>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    FVector SnowOriginWorldLoc() const { return Read<FVector>(uintptr_t(this) + 0x110); } // 0x110 (Size: 0x18, Type: StructProperty)
    double SnowRadius() const { return Read<double>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x8, Type: DoubleProperty)
    TArray<FGameplayTag> SnowTagsToApply() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x10, Type: ArrayProperty)
    FName SnowEntryName() const { return Read<FName>(uintptr_t(this) + 0x140); } // 0x140 (Size: 0x4, Type: NameProperty)
    AActor* CurrViewTarget() const { return Read<AActor*>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x8, Type: ObjectProperty)
    TArray<FGameplayTag> GenericTagsToApply() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0x150); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    bool bTagApplicationEnabled() const { return Read<bool>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x1, Type: BoolProperty)
    UFortGameStateComponent_SurfaceOverride* SnowCoverageComponent() const { return Read<UFortGameStateComponent_SurfaceOverride*>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x8, Type: ObjectProperty)
    TArray<FString> SupportedTagLevels() const { return Read<TArray<FString>>(uintptr_t(this) + 0x170); } // 0x170 (Size: 0x10, Type: ArrayProperty)
    double SpecialSurfacePadding() const { return Read<double>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: DoubleProperty)
    USoundMix* IsSnowingSoundMix() const { return Read<USoundMix*>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* ControlBus_UpEnclosure() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x8, Type: ObjectProperty)
    USoundControlBus* ControlBus_Enclosure() const { return Read<USoundControlBus*>(uintptr_t(this) + 0x198); } // 0x198 (Size: 0x8, Type: ObjectProperty)
    double EnclosureThresholdForIndoors() const { return Read<double>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x8, Type: DoubleProperty)
    bool bIsIndoors() const { return Read<bool>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x8, Type: StructProperty)
    void SET_CheckFrequency(const double& Value) { Write<double>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x8, Type: DoubleProperty)
    void SET_bInSnowCurrent(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x1, Type: BoolProperty)
    void SET_WinterAudioBank(const UAmbientAudioDataAsset*& Value) { Write<UAmbientAudioDataAsset*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_bSnowEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
    void SET_CurieAudioBank(const UAmbientAudioDataAsset*& Value) { Write<UAmbientAudioDataAsset*>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x8, Type: ObjectProperty)
    void SET_SnowOriginWorldLoc(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x110, Value); } // 0x110 (Size: 0x18, Type: StructProperty)
    void SET_SnowRadius(const double& Value) { Write<double>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x8, Type: DoubleProperty)
    void SET_SnowTagsToApply(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x10, Type: ArrayProperty)
    void SET_SnowEntryName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x140, Value); } // 0x140 (Size: 0x4, Type: NameProperty)
    void SET_CurrViewTarget(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x8, Type: ObjectProperty)
    void SET_GenericTagsToApply(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0x150, Value); } // 0x150 (Size: 0x10, Type: ArrayProperty)
    void SET_bTagApplicationEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x1, Type: BoolProperty)
    void SET_SnowCoverageComponent(const UFortGameStateComponent_SurfaceOverride*& Value) { Write<UFortGameStateComponent_SurfaceOverride*>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x8, Type: ObjectProperty)
    void SET_SupportedTagLevels(const TArray<FString>& Value) { Write<TArray<FString>>(uintptr_t(this) + 0x170, Value); } // 0x170 (Size: 0x10, Type: ArrayProperty)
    void SET_SpecialSurfacePadding(const double& Value) { Write<double>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: DoubleProperty)
    void SET_IsSnowingSoundMix(const USoundMix*& Value) { Write<USoundMix*>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x8, Type: ObjectProperty)
    void SET_ControlBus_UpEnclosure(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x8, Type: ObjectProperty)
    void SET_ControlBus_Enclosure(const USoundControlBus*& Value) { Write<USoundControlBus*>(uintptr_t(this) + 0x198, Value); } // 0x198 (Size: 0x8, Type: ObjectProperty)
    void SET_EnclosureThresholdForIndoors(const double& Value) { Write<double>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x8, Type: DoubleProperty)
    void SET_bIsIndoors(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x80
class UQuickHealItemPickerBP_C : public UQuickHealItemPicker
{
public:
};

// Size: 0x1f0
class USkydiveCamShake_C : public ULegacyCameraShake
{
public:
};

// Size: 0x168
class UBP_MovementInterruptable_C : public UFortControllerComponent_MovementCancellableAction
{
public:
};

// Size: 0x2e8
class AMegaStormManagerAthena_C : public AMegaStormManager
{
public:
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)

    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa68
class UGE_Athena_PostReboot_ApplyTag_C : public UGameplayEffect
{
public:
};

// Size: 0x1f8
class UCreative_PhotoMode_ControllerComponent_C : public UFortControllerComponent_PhotoMode
{
public:
};

// Size: 0x2b8
class AAthena_FlyingVehicleBoundarySpline_Child_C : public AFlyingVehicleBoundarySpline_C
{
public:
};

// Size: 0x2b8
class AFlyingVehicleBoundarySpline_C : public AActor
{
public:
    USplineComponent* Spline() const { return Read<USplineComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)

    void SET_Spline(const USplineComponent*& Value) { Write<USplineComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x380
class ULetoHudOverlay_C : public ULetoHudOverlay
{
public:
};

// Size: 0xce0
class UGA_Athena_HidingProp_Hide_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    AB_HidingProp_C* HidingProp() const { return Read<AB_HidingProp_C*>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* Enter_Anim_Montage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GC_Wobble() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x4, Type: StructProperty)
    FScalableFloat ExitBlockShootDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x28, Type: StructProperty)
    FGameplayTagContainer TC_Quest() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TC_PlayerOwned() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xbd8); } // 0xbd8 (Size: 0x20, Type: StructProperty)
    FScalableFloat RustleMinDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbf8); } // 0xbf8 (Size: 0x28, Type: StructProperty)
    FScalableFloat RustleMaxDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc20); } // 0xc20 (Size: 0x28, Type: StructProperty)
    AFortPlayerController* PlayerController() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0xc48); } // 0xc48 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer HidingInPropTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc50); } // 0xc50 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer GettingInPropTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc70); } // 0xc70 (Size: 0x20, Type: StructProperty)
    FGameplayTag CurieBurningTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc90); } // 0xc90 (Size: 0x4, Type: StructProperty)
    bool AllowCosmetics() const { return Read<bool>(uintptr_t(this) + 0xc94); } // 0xc94 (Size: 0x1, Type: BoolProperty)
    FGameplayTag DisallowCosmeticsTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc98); } // 0xc98 (Size: 0x4, Type: StructProperty)
    bool LandedOnProp() const { return Read<bool>(uintptr_t(this) + 0xc9c); } // 0xc9c (Size: 0x1, Type: BoolProperty)
    FTimerHandle LockOnTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0xca0); } // 0xca0 (Size: 0x8, Type: StructProperty)
    FVector HideLocationForwardVectorWorldPos() const { return Read<FVector>(uintptr_t(this) + 0xca8); } // 0xca8 (Size: 0x18, Type: StructProperty)
    FRotator HideLocationForwardVectorWorldRot() const { return Read<FRotator>(uintptr_t(this) + 0xcc0); } // 0xcc0 (Size: 0x18, Type: StructProperty)
    AB_HidingProp_C* PrevInputEnabledHidingProp() const { return Read<AB_HidingProp_C*>(uintptr_t(this) + 0xcd8); } // 0xcd8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_HidingProp(const AB_HidingProp_C*& Value) { Write<AB_HidingProp_C*>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    void SET_Enter_Anim_Montage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    void SET_GC_Wobble(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x4, Type: StructProperty)
    void SET_ExitBlockShootDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x28, Type: StructProperty)
    void SET_TC_Quest(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x20, Type: StructProperty)
    void SET_TC_PlayerOwned(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xbd8, Value); } // 0xbd8 (Size: 0x20, Type: StructProperty)
    void SET_RustleMinDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbf8, Value); } // 0xbf8 (Size: 0x28, Type: StructProperty)
    void SET_RustleMaxDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc20, Value); } // 0xc20 (Size: 0x28, Type: StructProperty)
    void SET_PlayerController(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0xc48, Value); } // 0xc48 (Size: 0x8, Type: ObjectProperty)
    void SET_HidingInPropTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc50, Value); } // 0xc50 (Size: 0x20, Type: StructProperty)
    void SET_GettingInPropTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc70, Value); } // 0xc70 (Size: 0x20, Type: StructProperty)
    void SET_CurieBurningTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc90, Value); } // 0xc90 (Size: 0x4, Type: StructProperty)
    void SET_AllowCosmetics(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc94, Value); } // 0xc94 (Size: 0x1, Type: BoolProperty)
    void SET_DisallowCosmeticsTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc98, Value); } // 0xc98 (Size: 0x4, Type: StructProperty)
    void SET_LandedOnProp(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc9c, Value); } // 0xc9c (Size: 0x1, Type: BoolProperty)
    void SET_LockOnTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xca0, Value); } // 0xca0 (Size: 0x8, Type: StructProperty)
    void SET_HideLocationForwardVectorWorldPos(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xca8, Value); } // 0xca8 (Size: 0x18, Type: StructProperty)
    void SET_HideLocationForwardVectorWorldRot(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0xcc0, Value); } // 0xcc0 (Size: 0x18, Type: StructProperty)
    void SET_PrevInputEnabledHidingProp(const AB_HidingProp_C*& Value) { Write<AB_HidingProp_C*>(uintptr_t(this) + 0xcd8, Value); } // 0xcd8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x6de0
class APlayerPawn_Athena_C : public APlayerPawn_Athena_Generic_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x6428); } // 0x6428 (Size: 0x8, Type: StructProperty)
    UFortContrailsComponent* FortContrails() const { return Read<UFortContrailsComponent*>(uintptr_t(this) + 0x6430); } // 0x6430 (Size: 0x8, Type: ObjectProperty)
    UFortUnderwaterDamageComponent* FortUnderwaterDamage() const { return Read<UFortUnderwaterDamageComponent*>(uintptr_t(this) + 0x6438); } // 0x6438 (Size: 0x8, Type: ObjectProperty)
    float Timeline_0_BlendWeight_A4943458400C3662DB243099F9EAC7E8() const { return Read<float>(uintptr_t(this) + 0x6440); } // 0x6440 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_A4943458400C3662DB243099F9EAC7E8() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x6444); } // 0x6444 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_0() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x6448); } // 0x6448 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* TargetHead() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x6450); } // 0x6450 (Size: 0x8, Type: ObjectProperty)
    USkeletalMeshComponent* TargetBody() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x6458); } // 0x6458 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInterface*> PawnHeadMaterials_0() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x6460); } // 0x6460 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInterface*> PawnBodyMaterials_0() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x6470); } // 0x6470 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer TC_FlakVest() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x6480); } // 0x6480 (Size: 0x20, Type: StructProperty)
    FGameplayEventData Event_Data() const { return Read<FGameplayEventData>(uintptr_t(this) + 0x64a0); } // 0x64a0 (Size: 0xb0, Type: StructProperty)
    FGameplayTag EventSpawnEffect() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6550); } // 0x6550 (Size: 0x4, Type: StructProperty)
    bool IsMale() const { return Read<bool>(uintptr_t(this) + 0x6554); } // 0x6554 (Size: 0x1, Type: BoolProperty)
    AFortWeapon* MenuGoingCommandowWeapon() const { return Read<AFortWeapon*>(uintptr_t(this) + 0x6558); } // 0x6558 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SafeZonePassThroughSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x6560); } // 0x6560 (Size: 0x8, Type: ObjectProperty)
    bool bHasBeenOutsideSafeZone() const { return Read<bool>(uintptr_t(this) + 0x6568); } // 0x6568 (Size: 0x1, Type: BoolProperty)
    FLinearColor ThreatColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x656c); } // 0x656c (Size: 0x10, Type: StructProperty)
    USoundBase* PlayerKilledSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x6580); } // 0x6580 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* WindDebrisParticles() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x6588); } // 0x6588 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* FallingRainParticles() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x6590); } // 0x6590 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* StormAuraParticles() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x6598); } // 0x6598 (Size: 0x8, Type: ObjectProperty)
    FVector LightningSpawnLocation() const { return Read<FVector>(uintptr_t(this) + 0x65a0); } // 0x65a0 (Size: 0x18, Type: StructProperty)
    double LightningIntensityMin() const { return Read<double>(uintptr_t(this) + 0x65b8); } // 0x65b8 (Size: 0x8, Type: DoubleProperty)
    double LightningIntensityMax() const { return Read<double>(uintptr_t(this) + 0x65c0); } // 0x65c0 (Size: 0x8, Type: DoubleProperty)
    AActor* SafeZoneActor() const { return Read<AActor*>(uintptr_t(this) + 0x65c8); } // 0x65c8 (Size: 0x8, Type: ObjectProperty)
    double LightningIntensity() const { return Read<double>(uintptr_t(this) + 0x65d0); } // 0x65d0 (Size: 0x8, Type: DoubleProperty)
    UPointLightComponent* RandomLightningLight() const { return Read<UPointLightComponent*>(uintptr_t(this) + 0x65d8); } // 0x65d8 (Size: 0x8, Type: ObjectProperty)
    double LightningTimelinePlaySpeedMin() const { return Read<double>(uintptr_t(this) + 0x65e0); } // 0x65e0 (Size: 0x8, Type: DoubleProperty)
    double LightningTimelinePlaySpeedMax() const { return Read<double>(uintptr_t(this) + 0x65e8); } // 0x65e8 (Size: 0x8, Type: DoubleProperty)
    double LightningFlashDiameter() const { return Read<double>(uintptr_t(this) + 0x65f0); } // 0x65f0 (Size: 0x8, Type: DoubleProperty)
    double LightningFlashHeight() const { return Read<double>(uintptr_t(this) + 0x65f8); } // 0x65f8 (Size: 0x8, Type: DoubleProperty)
    double LightningFlashRepeatDelayMin() const { return Read<double>(uintptr_t(this) + 0x6600); } // 0x6600 (Size: 0x8, Type: DoubleProperty)
    double LightningFlashRepeatDelayMax() const { return Read<double>(uintptr_t(this) + 0x6608); } // 0x6608 (Size: 0x8, Type: DoubleProperty)
    AEmitterCameraLensEffectBase* RainCameraLensParticles() const { return Read<AEmitterCameraLensEffectBase*>(uintptr_t(this) + 0x6610); } // 0x6610 (Size: 0x8, Type: ObjectProperty)
    double _ChanceOfLightningMesh() const { return Read<double>(uintptr_t(this) + 0x6618); } // 0x6618 (Size: 0x8, Type: DoubleProperty)
    bool ShowInvulnerableVisuals() const { return Read<bool>(uintptr_t(this) + 0x6620); } // 0x6620 (Size: 0x1, Type: BoolProperty)
    UAudioComponent* StormAudioLoop_Inst() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x6628); } // 0x6628 (Size: 0x8, Type: ObjectProperty)
    double StormAudioVolume() const { return Read<double>(uintptr_t(this) + 0x6630); } // 0x6630 (Size: 0x8, Type: DoubleProperty)
    UAudioComponent* FallingAudioLoop_Inst() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x6638); } // 0x6638 (Size: 0x8, Type: ObjectProperty)
    bool bIsPlayingFallingSound() const { return Read<bool>(uintptr_t(this) + 0x6640); } // 0x6640 (Size: 0x1, Type: BoolProperty)
    double PlayerAttributes_Speed_Walk() const { return Read<double>(uintptr_t(this) + 0x6648); } // 0x6648 (Size: 0x8, Type: DoubleProperty)
    double PlayerAttributes_Speed_Run() const { return Read<double>(uintptr_t(this) + 0x6650); } // 0x6650 (Size: 0x8, Type: DoubleProperty)
    double PlayerAttributes_Speed_Sprint() const { return Read<double>(uintptr_t(this) + 0x6658); } // 0x6658 (Size: 0x8, Type: DoubleProperty)
    int32_t MaxTrailsLOD() const { return Read<int32_t>(uintptr_t(this) + 0x6660); } // 0x6660 (Size: 0x4, Type: IntProperty)
    UPostProcessComponent* MobilePostProcess() const { return Read<UPostProcessComponent*>(uintptr_t(this) + 0x6668); } // 0x6668 (Size: 0x8, Type: ObjectProperty)
    bool bIsOutsideSafeZoneCached() const { return Read<bool>(uintptr_t(this) + 0x6670); } // 0x6670 (Size: 0x1, Type: BoolProperty)
    TArray<UMaterialInstanceDynamic*> ResOutMaterials() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x6678); } // 0x6678 (Size: 0x10, Type: ArrayProperty)
    ADuplicateResOutMesh_C* RezInFXActor() const { return Read<ADuplicateResOutMesh_C*>(uintptr_t(this) + 0x6688); } // 0x6688 (Size: 0x8, Type: ObjectProperty)
    bool bQueueRezIn() const { return Read<bool>(uintptr_t(this) + 0x6690); } // 0x6690 (Size: 0x1, Type: BoolProperty)
    ADuplicateResOutMesh_C* RezOutFXActor() const { return Read<ADuplicateResOutMesh_C*>(uintptr_t(this) + 0x6698); } // 0x6698 (Size: 0x8, Type: ObjectProperty)
    bool bQueueRezOut() const { return Read<bool>(uintptr_t(this) + 0x66a0); } // 0x66a0 (Size: 0x1, Type: BoolProperty)
    bool bWasEverInWarmUp() const { return Read<bool>(uintptr_t(this) + 0x66a1); } // 0x66a1 (Size: 0x1, Type: BoolProperty)
    bool bStormAudioCleanedUp() const { return Read<bool>(uintptr_t(this) + 0x66a2); } // 0x66a2 (Size: 0x1, Type: BoolProperty)
    FGameplayTag OutsideSafeZoneGameplayCueTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x66a4); } // 0x66a4 (Size: 0x4, Type: StructProperty)
    int32_t SafeZonePhase() const { return Read<int32_t>(uintptr_t(this) + 0x66a8); } // 0x66a8 (Size: 0x4, Type: IntProperty)
    int32_t WhichSafeZoneTag() const { return Read<int32_t>(uintptr_t(this) + 0x66ac); } // 0x66ac (Size: 0x4, Type: IntProperty)
    bool bOutsideSafeZoneGameplayCueActive() const { return Read<bool>(uintptr_t(this) + 0x66b0); } // 0x66b0 (Size: 0x1, Type: BoolProperty)
    FScalableFloat SafeZoneDamageScalableFloat() const { return Read<FScalableFloat>(uintptr_t(this) + 0x66b8); } // 0x66b8 (Size: 0x28, Type: StructProperty)
    bool bFrontendPartyInProgress() const { return Read<bool>(uintptr_t(this) + 0x66e0); } // 0x66e0 (Size: 0x1, Type: BoolProperty)
    bool bLockOnInteractionComplete() const { return Read<bool>(uintptr_t(this) + 0x66e1); } // 0x66e1 (Size: 0x1, Type: BoolProperty)
    USoundBase* DBNOEnterSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x6728); } // 0x6728 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag PhoneGhostCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6760); } // 0x6760 (Size: 0x4, Type: StructProperty)
    FGameplayTag WhiteoutCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6764); } // 0x6764 (Size: 0x4, Type: StructProperty)
    FGameplayTag OutsideSafeZoneCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6768); } // 0x6768 (Size: 0x4, Type: StructProperty)
    FGameplayTag OutsideSafeZone2Cue() const { return Read<FGameplayTag>(uintptr_t(this) + 0x676c); } // 0x676c (Size: 0x4, Type: StructProperty)
    FGameplayTag OutsideSafeZone3Cue() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6770); } // 0x6770 (Size: 0x4, Type: StructProperty)
    bool PlayRespawnFXOnSpawn() const { return Read<bool>(uintptr_t(this) + 0x6774); } // 0x6774 (Size: 0x1, Type: BoolProperty)
    AFortPlayerPawnAthena* PlayerPawnAthena() const { return Read<AFortPlayerPawnAthena*>(uintptr_t(this) + 0x6778); } // 0x6778 (Size: 0x8, Type: ObjectProperty)
    bool TestProceduralWaterInIsolation() const { return Read<bool>(uintptr_t(this) + 0x67a0); } // 0x67a0 (Size: 0x1, Type: BoolProperty)
    bool Is_First_Water_Body() const { return Read<bool>(uintptr_t(this) + 0x67a1); } // 0x67a1 (Size: 0x1, Type: BoolProperty)
    bool Is_Last_Water_Body() const { return Read<bool>(uintptr_t(this) + 0x67a2); } // 0x67a2 (Size: 0x1, Type: BoolProperty)
    double AccumulatedNormalizedDiveSpeed() const { return Read<double>(uintptr_t(this) + 0x67a8); } // 0x67a8 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag WaterSprintBoostTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x67b0); } // 0x67b0 (Size: 0x4, Type: StructProperty)
    TMap<FPawnHighlight, UObject*> PawnHighlights() const { return Read<TMap<FPawnHighlight, UObject*>>(uintptr_t(this) + 0x67c8); } // 0x67c8 (Size: 0x50, Type: MapProperty)
    FPawnHighlight Current_Highlight() const { return Read<FPawnHighlight>(uintptr_t(this) + 0x6818); } // 0x6818 (Size: 0x30, Type: StructProperty)
    UObject* Current_Highlight_Source() const { return Read<UObject*>(uintptr_t(this) + 0x6848); } // 0x6848 (Size: 0x8, Type: ObjectProperty)
    FPawnHighlight Invulnerable_Highlight() const { return Read<FPawnHighlight>(uintptr_t(this) + 0x6850); } // 0x6850 (Size: 0x30, Type: StructProperty)
    bool IsGalileo() const { return Read<bool>(uintptr_t(this) + 0x6880); } // 0x6880 (Size: 0x1, Type: BoolProperty)
    FScalableFloat HotFixSnow() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6888); } // 0x6888 (Size: 0x28, Type: StructProperty)
    TSet<FName> NoSnowPlaylists() const { return Read<TSet<FName>>(uintptr_t(this) + 0x68b0); } // 0x68b0 (Size: 0x50, Type: SetProperty)
    FGameplayTag GalileoPlaylistTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6900); } // 0x6900 (Size: 0x4, Type: StructProperty)
    TArray<UMaterialInstanceDynamic*> WeaponMIDs() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x6908); } // 0x6908 (Size: 0x10, Type: ArrayProperty)
    int32_t AmountOfTimesToAttemptRestoreMats() const { return Read<int32_t>(uintptr_t(this) + 0x6918); } // 0x6918 (Size: 0x4, Type: IntProperty)
    FGameplayTag TC_PawnAthenaNPC() const { return Read<FGameplayTag>(uintptr_t(this) + 0x691c); } // 0x691c (Size: 0x4, Type: StructProperty)
    double HitGlowBrightnessScalar() const { return Read<double>(uintptr_t(this) + 0x6920); } // 0x6920 (Size: 0x8, Type: DoubleProperty)
    TArray<UMaterialInterface*> CurrentWeaponMaterials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x6928); } // 0x6928 (Size: 0x10, Type: ArrayProperty)
    TArray<USkeletalMeshComponent*> CurrentWeaponMeshes() const { return Read<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x6938); } // 0x6938 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> WeaponDissolveMIDs() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x6948); } // 0x6948 (Size: 0x10, Type: ArrayProperty)
    double HitGlowBrightnessScalar_Mobile() const { return Read<double>(uintptr_t(this) + 0x6958); } // 0x6958 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag TC_PawnAthenaDecoy() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6960); } // 0x6960 (Size: 0x4, Type: StructProperty)
    double ScaleRate() const { return Read<double>(uintptr_t(this) + 0x6968); } // 0x6968 (Size: 0x8, Type: DoubleProperty)
    FGameplayTagContainer TetherQuestTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x6970); } // 0x6970 (Size: 0x20, Type: StructProperty)
    FName FirefliesTag() const { return Read<FName>(uintptr_t(this) + 0x6990); } // 0x6990 (Size: 0x4, Type: NameProperty)
    FTransform RightSideRim_Transform() const { return Read<FTransform>(uintptr_t(this) + 0x69a0); } // 0x69a0 (Size: 0x60, Type: StructProperty)
    USpotLightComponent* Right_Side_Rim_Light() const { return Read<USpotLightComponent*>(uintptr_t(this) + 0x6a00); } // 0x6a00 (Size: 0x8, Type: ObjectProperty)
    double Rim_light_Shadow_Bias() const { return Read<double>(uintptr_t(this) + 0x6a08); } // 0x6a08 (Size: 0x8, Type: DoubleProperty)
    double Rim_Light_Intensity() const { return Read<double>(uintptr_t(this) + 0x6a10); } // 0x6a10 (Size: 0x8, Type: DoubleProperty)
    FRotator PlayerAimRotation() const { return Read<FRotator>(uintptr_t(this) + 0x6a18); } // 0x6a18 (Size: 0x18, Type: StructProperty)
    FScalableFloat ControlRotationReplicationTickRate() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6a30); } // 0x6a30 (Size: 0x28, Type: StructProperty)
    FGameplayTag Elimination_Rez_Sequence_GC() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6a58); } // 0x6a58 (Size: 0x4, Type: StructProperty)
    FGameplayTag Creative_Respawn_Teleportation_GC() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6a5c); } // 0x6a5c (Size: 0x4, Type: StructProperty)
    FGameplayTag Teleport_In_GC() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6a60); } // 0x6a60 (Size: 0x4, Type: StructProperty)
    double RimLightDistanceFromCamera() const { return Read<double>(uintptr_t(this) + 0x6a68); } // 0x6a68 (Size: 0x8, Type: DoubleProperty)
    FLinearColor Rim_Light_Color___Night() const { return Read<FLinearColor>(uintptr_t(this) + 0x6a70); } // 0x6a70 (Size: 0x10, Type: StructProperty)
    FLinearColor Rim_Light_Color___Day() const { return Read<FLinearColor>(uintptr_t(this) + 0x6a80); } // 0x6a80 (Size: 0x10, Type: StructProperty)
    FGameplayTag PhoneModeratorModeGameplayCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6a90); } // 0x6a90 (Size: 0x4, Type: StructProperty)
    FGameplayTag PhoneInvulnerableGameplayCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6a94); } // 0x6a94 (Size: 0x4, Type: StructProperty)
    bool Swinging_HandsUp() const { return Read<bool>(uintptr_t(this) + 0x6a98); } // 0x6a98 (Size: 0x1, Type: BoolProperty)
    bool Swinging_LockedToHip() const { return Read<bool>(uintptr_t(this) + 0x6a99); } // 0x6a99 (Size: 0x1, Type: BoolProperty)
    double InputDragCoefficient() const { return Read<double>(uintptr_t(this) + 0x6aa0); } // 0x6aa0 (Size: 0x8, Type: DoubleProperty)
    bool ToggleSwingNativized() const { return Read<bool>(uintptr_t(this) + 0x6aa8); } // 0x6aa8 (Size: 0x1, Type: BoolProperty)
    UAudioComponent* SwingingSound() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x6ab0); } // 0x6ab0 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* Swinging_ReelingInCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x6ab8); } // 0x6ab8 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* Swinging_NotReelingInCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x6ac0); } // 0x6ac0 (Size: 0x8, Type: ObjectProperty)
    FVector Swinging_OriginalVecToTarget() const { return Read<FVector>(uintptr_t(this) + 0x6ac8); } // 0x6ac8 (Size: 0x18, Type: StructProperty)
    bool Swinging_ReelingIn() const { return Read<bool>(uintptr_t(this) + 0x6ae0); } // 0x6ae0 (Size: 0x1, Type: BoolProperty)
    double Swinging_Goal_Length() const { return Read<double>(uintptr_t(this) + 0x6ae8); } // 0x6ae8 (Size: 0x8, Type: DoubleProperty)
    UCurveFloat* Swinging_ReelingTimeCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x6af0); } // 0x6af0 (Size: 0x8, Type: ObjectProperty)
    bool Swinging_ColliderBigger() const { return Read<bool>(uintptr_t(this) + 0x6af8); } // 0x6af8 (Size: 0x1, Type: BoolProperty)
    TArray<FAudioParameter> SoundParams() const { return Read<TArray<FAudioParameter>>(uintptr_t(this) + 0x6b00); } // 0x6b00 (Size: 0x10, Type: ArrayProperty)
    bool Swinging_UseNewRotationAlgorithm() const { return Read<bool>(uintptr_t(this) + 0x6b10); } // 0x6b10 (Size: 0x1, Type: BoolProperty)
    FVector AttachedWallInverseNormal() const { return Read<FVector>(uintptr_t(this) + 0x6b18); } // 0x6b18 (Size: 0x18, Type: StructProperty)
    FVector VelocityOnSlideStart() const { return Read<FVector>(uintptr_t(this) + 0x6b30); } // 0x6b30 (Size: 0x18, Type: StructProperty)
    double SlideStartTime() const { return Read<double>(uintptr_t(this) + 0x6b48); } // 0x6b48 (Size: 0x8, Type: DoubleProperty)
    double MaxSlideTime() const { return Read<double>(uintptr_t(this) + 0x6b50); } // 0x6b50 (Size: 0x8, Type: DoubleProperty)
    UCurveVector* WallSlidingVelocityMultiplierCurve() const { return Read<UCurveVector*>(uintptr_t(this) + 0x6b58); } // 0x6b58 (Size: 0x8, Type: ObjectProperty)
    UCurveFloat* WallSlidingAddedDownwardVelocityMultiplierCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x6b60); } // 0x6b60 (Size: 0x8, Type: ObjectProperty)
    double WallSlidingAddedDownwardVelocityMax() const { return Read<double>(uintptr_t(this) + 0x6b68); } // 0x6b68 (Size: 0x8, Type: DoubleProperty)
    FVector AttachedWallNormal() const { return Read<FVector>(uintptr_t(this) + 0x6b70); } // 0x6b70 (Size: 0x18, Type: StructProperty)
    FVector WallSlidingVelocity() const { return Read<FVector>(uintptr_t(this) + 0x6b88); } // 0x6b88 (Size: 0x18, Type: StructProperty)
    double DesiredDistanceToAttachedWall() const { return Read<double>(uintptr_t(this) + 0x6ba0); } // 0x6ba0 (Size: 0x8, Type: DoubleProperty)
    double MinGroundSlopeToLeaveAttachedWall() const { return Read<double>(uintptr_t(this) + 0x6ba8); } // 0x6ba8 (Size: 0x8, Type: DoubleProperty)
    FFortGameplayAbilityMontageInfo OverrideSearchMontageInfo() const { return Read<FFortGameplayAbilityMontageInfo>(uintptr_t(this) + 0x6bb0); } // 0x6bb0 (Size: 0x58, Type: StructProperty)
    bool Is_Hidding_CharacterParrts() const { return Read<bool>(uintptr_t(this) + 0x6c08); } // 0x6c08 (Size: 0x1, Type: BoolProperty)
    double RimlightCVARBoost() const { return Read<double>(uintptr_t(this) + 0x6c10); } // 0x6c10 (Size: 0x8, Type: DoubleProperty)
    bool Rimlight_Enabled() const { return Read<bool>(uintptr_t(this) + 0x6c18); } // 0x6c18 (Size: 0x1, Type: BoolProperty)
    FString LCVar_Name() const { return Read<FString>(uintptr_t(this) + 0x6c20); } // 0x6c20 (Size: 0x10, Type: StrProperty)
    FScalableFloat UGC_RimLightIntensity() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6c30); } // 0x6c30 (Size: 0x28, Type: StructProperty)
    USoundBase* SFX_WaterExit_3P() const { return Read<USoundBase*>(uintptr_t(this) + 0x6c58); } // 0x6c58 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SFX_WaterExit_1P() const { return Read<USoundBase*>(uintptr_t(this) + 0x6c60); } // 0x6c60 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SFX_WaterEntry_3P() const { return Read<USoundBase*>(uintptr_t(this) + 0x6c68); } // 0x6c68 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SFX_WaterEntry_1P() const { return Read<USoundBase*>(uintptr_t(this) + 0x6c70); } // 0x6c70 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat EnableDecayRow() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6c78); } // 0x6c78 (Size: 0x28, Type: StructProperty)
    double CeilingHeight() const { return Read<double>(uintptr_t(this) + 0x6ca0); } // 0x6ca0 (Size: 0x8, Type: DoubleProperty)
    FVector BAProtoVelocity() const { return Read<FVector>(uintptr_t(this) + 0x6ca8); } // 0x6ca8 (Size: 0x18, Type: StructProperty)
    FScalableFloat HF_TetherMultiplierHorz() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6cc0); } // 0x6cc0 (Size: 0x28, Type: StructProperty)
    FScalableFloat HF_TetherMultiplierVert() const { return Read<FScalableFloat>(uintptr_t(this) + 0x6ce8); } // 0x6ce8 (Size: 0x28, Type: StructProperty)
    FGameplayTag Teleport_In_GC_Frontend() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6d10); } // 0x6d10 (Size: 0x4, Type: StructProperty)
    FTimerHandle Re_apply_Highlight_Timer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x6d18); } // 0x6d18 (Size: 0x8, Type: StructProperty)
    FGameplayTag Style_Transfer_GC_Frontend() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6d20); } // 0x6d20 (Size: 0x4, Type: StructProperty)
    FGameplayTag RemovePawnHighlightGC() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6d24); } // 0x6d24 (Size: 0x4, Type: StructProperty)
    TMap<FGameplayTag, FGameplayTag> Elimination_Rez_Sequence_TagMap() const { return Read<TMap<FGameplayTag, FGameplayTag>>(uintptr_t(this) + 0x6d28); } // 0x6d28 (Size: 0x50, Type: MapProperty)
    FGameplayTag Tactical_Elimination_Rez_Sequence_GC() const { return Read<FGameplayTag>(uintptr_t(this) + 0x6d78); } // 0x6d78 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer On_Death_Damage_Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x6d80); } // 0x6d80 (Size: 0x20, Type: StructProperty)
    FVector On_Death_Momentum() const { return Read<FVector>(uintptr_t(this) + 0x6da0); } // 0x6da0 (Size: 0x18, Type: StructProperty)
    FGameplayEffectContextHandle On_Death_Effect_Context() const { return Read<FGameplayEffectContextHandle>(uintptr_t(this) + 0x6db8); } // 0x6db8 (Size: 0x18, Type: StructProperty)
    FTimerHandle WaitingForMaterialsTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x6dd0); } // 0x6dd0 (Size: 0x8, Type: StructProperty)
    AController* On_Death_Controller() const { return Read<AController*>(uintptr_t(this) + 0x6dd8); } // 0x6dd8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x6428, Value); } // 0x6428 (Size: 0x8, Type: StructProperty)
    void SET_FortContrails(const UFortContrailsComponent*& Value) { Write<UFortContrailsComponent*>(uintptr_t(this) + 0x6430, Value); } // 0x6430 (Size: 0x8, Type: ObjectProperty)
    void SET_FortUnderwaterDamage(const UFortUnderwaterDamageComponent*& Value) { Write<UFortUnderwaterDamageComponent*>(uintptr_t(this) + 0x6438, Value); } // 0x6438 (Size: 0x8, Type: ObjectProperty)
    void SET_Timeline_0_BlendWeight_A4943458400C3662DB243099F9EAC7E8(const float& Value) { Write<float>(uintptr_t(this) + 0x6440, Value); } // 0x6440 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_0__Direction_A4943458400C3662DB243099F9EAC7E8(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x6444, Value); } // 0x6444 (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_0(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x6448, Value); } // 0x6448 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetHead(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x6450, Value); } // 0x6450 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetBody(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x6458, Value); } // 0x6458 (Size: 0x8, Type: ObjectProperty)
    void SET_PawnHeadMaterials_0(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x6460, Value); } // 0x6460 (Size: 0x10, Type: ArrayProperty)
    void SET_PawnBodyMaterials_0(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x6470, Value); } // 0x6470 (Size: 0x10, Type: ArrayProperty)
    void SET_TC_FlakVest(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x6480, Value); } // 0x6480 (Size: 0x20, Type: StructProperty)
    void SET_Event_Data(const FGameplayEventData& Value) { Write<FGameplayEventData>(uintptr_t(this) + 0x64a0, Value); } // 0x64a0 (Size: 0xb0, Type: StructProperty)
    void SET_EventSpawnEffect(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6550, Value); } // 0x6550 (Size: 0x4, Type: StructProperty)
    void SET_IsMale(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6554, Value); } // 0x6554 (Size: 0x1, Type: BoolProperty)
    void SET_MenuGoingCommandowWeapon(const AFortWeapon*& Value) { Write<AFortWeapon*>(uintptr_t(this) + 0x6558, Value); } // 0x6558 (Size: 0x8, Type: ObjectProperty)
    void SET_SafeZonePassThroughSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x6560, Value); } // 0x6560 (Size: 0x8, Type: ObjectProperty)
    void SET_bHasBeenOutsideSafeZone(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6568, Value); } // 0x6568 (Size: 0x1, Type: BoolProperty)
    void SET_ThreatColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x656c, Value); } // 0x656c (Size: 0x10, Type: StructProperty)
    void SET_PlayerKilledSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x6580, Value); } // 0x6580 (Size: 0x8, Type: ObjectProperty)
    void SET_WindDebrisParticles(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x6588, Value); } // 0x6588 (Size: 0x8, Type: ObjectProperty)
    void SET_FallingRainParticles(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x6590, Value); } // 0x6590 (Size: 0x8, Type: ObjectProperty)
    void SET_StormAuraParticles(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x6598, Value); } // 0x6598 (Size: 0x8, Type: ObjectProperty)
    void SET_LightningSpawnLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x65a0, Value); } // 0x65a0 (Size: 0x18, Type: StructProperty)
    void SET_LightningIntensityMin(const double& Value) { Write<double>(uintptr_t(this) + 0x65b8, Value); } // 0x65b8 (Size: 0x8, Type: DoubleProperty)
    void SET_LightningIntensityMax(const double& Value) { Write<double>(uintptr_t(this) + 0x65c0, Value); } // 0x65c0 (Size: 0x8, Type: DoubleProperty)
    void SET_SafeZoneActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x65c8, Value); } // 0x65c8 (Size: 0x8, Type: ObjectProperty)
    void SET_LightningIntensity(const double& Value) { Write<double>(uintptr_t(this) + 0x65d0, Value); } // 0x65d0 (Size: 0x8, Type: DoubleProperty)
    void SET_RandomLightningLight(const UPointLightComponent*& Value) { Write<UPointLightComponent*>(uintptr_t(this) + 0x65d8, Value); } // 0x65d8 (Size: 0x8, Type: ObjectProperty)
    void SET_LightningTimelinePlaySpeedMin(const double& Value) { Write<double>(uintptr_t(this) + 0x65e0, Value); } // 0x65e0 (Size: 0x8, Type: DoubleProperty)
    void SET_LightningTimelinePlaySpeedMax(const double& Value) { Write<double>(uintptr_t(this) + 0x65e8, Value); } // 0x65e8 (Size: 0x8, Type: DoubleProperty)
    void SET_LightningFlashDiameter(const double& Value) { Write<double>(uintptr_t(this) + 0x65f0, Value); } // 0x65f0 (Size: 0x8, Type: DoubleProperty)
    void SET_LightningFlashHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x65f8, Value); } // 0x65f8 (Size: 0x8, Type: DoubleProperty)
    void SET_LightningFlashRepeatDelayMin(const double& Value) { Write<double>(uintptr_t(this) + 0x6600, Value); } // 0x6600 (Size: 0x8, Type: DoubleProperty)
    void SET_LightningFlashRepeatDelayMax(const double& Value) { Write<double>(uintptr_t(this) + 0x6608, Value); } // 0x6608 (Size: 0x8, Type: DoubleProperty)
    void SET_RainCameraLensParticles(const AEmitterCameraLensEffectBase*& Value) { Write<AEmitterCameraLensEffectBase*>(uintptr_t(this) + 0x6610, Value); } // 0x6610 (Size: 0x8, Type: ObjectProperty)
    void SET__ChanceOfLightningMesh(const double& Value) { Write<double>(uintptr_t(this) + 0x6618, Value); } // 0x6618 (Size: 0x8, Type: DoubleProperty)
    void SET_ShowInvulnerableVisuals(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6620, Value); } // 0x6620 (Size: 0x1, Type: BoolProperty)
    void SET_StormAudioLoop_Inst(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x6628, Value); } // 0x6628 (Size: 0x8, Type: ObjectProperty)
    void SET_StormAudioVolume(const double& Value) { Write<double>(uintptr_t(this) + 0x6630, Value); } // 0x6630 (Size: 0x8, Type: DoubleProperty)
    void SET_FallingAudioLoop_Inst(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x6638, Value); } // 0x6638 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsPlayingFallingSound(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6640, Value); } // 0x6640 (Size: 0x1, Type: BoolProperty)
    void SET_PlayerAttributes_Speed_Walk(const double& Value) { Write<double>(uintptr_t(this) + 0x6648, Value); } // 0x6648 (Size: 0x8, Type: DoubleProperty)
    void SET_PlayerAttributes_Speed_Run(const double& Value) { Write<double>(uintptr_t(this) + 0x6650, Value); } // 0x6650 (Size: 0x8, Type: DoubleProperty)
    void SET_PlayerAttributes_Speed_Sprint(const double& Value) { Write<double>(uintptr_t(this) + 0x6658, Value); } // 0x6658 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxTrailsLOD(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6660, Value); } // 0x6660 (Size: 0x4, Type: IntProperty)
    void SET_MobilePostProcess(const UPostProcessComponent*& Value) { Write<UPostProcessComponent*>(uintptr_t(this) + 0x6668, Value); } // 0x6668 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsOutsideSafeZoneCached(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6670, Value); } // 0x6670 (Size: 0x1, Type: BoolProperty)
    void SET_ResOutMaterials(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x6678, Value); } // 0x6678 (Size: 0x10, Type: ArrayProperty)
    void SET_RezInFXActor(const ADuplicateResOutMesh_C*& Value) { Write<ADuplicateResOutMesh_C*>(uintptr_t(this) + 0x6688, Value); } // 0x6688 (Size: 0x8, Type: ObjectProperty)
    void SET_bQueueRezIn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6690, Value); } // 0x6690 (Size: 0x1, Type: BoolProperty)
    void SET_RezOutFXActor(const ADuplicateResOutMesh_C*& Value) { Write<ADuplicateResOutMesh_C*>(uintptr_t(this) + 0x6698, Value); } // 0x6698 (Size: 0x8, Type: ObjectProperty)
    void SET_bQueueRezOut(const bool& Value) { Write<bool>(uintptr_t(this) + 0x66a0, Value); } // 0x66a0 (Size: 0x1, Type: BoolProperty)
    void SET_bWasEverInWarmUp(const bool& Value) { Write<bool>(uintptr_t(this) + 0x66a1, Value); } // 0x66a1 (Size: 0x1, Type: BoolProperty)
    void SET_bStormAudioCleanedUp(const bool& Value) { Write<bool>(uintptr_t(this) + 0x66a2, Value); } // 0x66a2 (Size: 0x1, Type: BoolProperty)
    void SET_OutsideSafeZoneGameplayCueTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x66a4, Value); } // 0x66a4 (Size: 0x4, Type: StructProperty)
    void SET_SafeZonePhase(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x66a8, Value); } // 0x66a8 (Size: 0x4, Type: IntProperty)
    void SET_WhichSafeZoneTag(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x66ac, Value); } // 0x66ac (Size: 0x4, Type: IntProperty)
    void SET_bOutsideSafeZoneGameplayCueActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x66b0, Value); } // 0x66b0 (Size: 0x1, Type: BoolProperty)
    void SET_SafeZoneDamageScalableFloat(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x66b8, Value); } // 0x66b8 (Size: 0x28, Type: StructProperty)
    void SET_bFrontendPartyInProgress(const bool& Value) { Write<bool>(uintptr_t(this) + 0x66e0, Value); } // 0x66e0 (Size: 0x1, Type: BoolProperty)
    void SET_bLockOnInteractionComplete(const bool& Value) { Write<bool>(uintptr_t(this) + 0x66e1, Value); } // 0x66e1 (Size: 0x1, Type: BoolProperty)
    void SET_DBNOEnterSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x6728, Value); } // 0x6728 (Size: 0x8, Type: ObjectProperty)
    void SET_PhoneGhostCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6760, Value); } // 0x6760 (Size: 0x4, Type: StructProperty)
    void SET_WhiteoutCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6764, Value); } // 0x6764 (Size: 0x4, Type: StructProperty)
    void SET_OutsideSafeZoneCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6768, Value); } // 0x6768 (Size: 0x4, Type: StructProperty)
    void SET_OutsideSafeZone2Cue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x676c, Value); } // 0x676c (Size: 0x4, Type: StructProperty)
    void SET_OutsideSafeZone3Cue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6770, Value); } // 0x6770 (Size: 0x4, Type: StructProperty)
    void SET_PlayRespawnFXOnSpawn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6774, Value); } // 0x6774 (Size: 0x1, Type: BoolProperty)
    void SET_PlayerPawnAthena(const AFortPlayerPawnAthena*& Value) { Write<AFortPlayerPawnAthena*>(uintptr_t(this) + 0x6778, Value); } // 0x6778 (Size: 0x8, Type: ObjectProperty)
    void SET_TestProceduralWaterInIsolation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x67a0, Value); } // 0x67a0 (Size: 0x1, Type: BoolProperty)
    void SET_Is_First_Water_Body(const bool& Value) { Write<bool>(uintptr_t(this) + 0x67a1, Value); } // 0x67a1 (Size: 0x1, Type: BoolProperty)
    void SET_Is_Last_Water_Body(const bool& Value) { Write<bool>(uintptr_t(this) + 0x67a2, Value); } // 0x67a2 (Size: 0x1, Type: BoolProperty)
    void SET_AccumulatedNormalizedDiveSpeed(const double& Value) { Write<double>(uintptr_t(this) + 0x67a8, Value); } // 0x67a8 (Size: 0x8, Type: DoubleProperty)
    void SET_WaterSprintBoostTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x67b0, Value); } // 0x67b0 (Size: 0x4, Type: StructProperty)
    void SET_PawnHighlights(const TMap<FPawnHighlight, UObject*>& Value) { Write<TMap<FPawnHighlight, UObject*>>(uintptr_t(this) + 0x67c8, Value); } // 0x67c8 (Size: 0x50, Type: MapProperty)
    void SET_Current_Highlight(const FPawnHighlight& Value) { Write<FPawnHighlight>(uintptr_t(this) + 0x6818, Value); } // 0x6818 (Size: 0x30, Type: StructProperty)
    void SET_Current_Highlight_Source(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x6848, Value); } // 0x6848 (Size: 0x8, Type: ObjectProperty)
    void SET_Invulnerable_Highlight(const FPawnHighlight& Value) { Write<FPawnHighlight>(uintptr_t(this) + 0x6850, Value); } // 0x6850 (Size: 0x30, Type: StructProperty)
    void SET_IsGalileo(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6880, Value); } // 0x6880 (Size: 0x1, Type: BoolProperty)
    void SET_HotFixSnow(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6888, Value); } // 0x6888 (Size: 0x28, Type: StructProperty)
    void SET_NoSnowPlaylists(const TSet<FName>& Value) { Write<TSet<FName>>(uintptr_t(this) + 0x68b0, Value); } // 0x68b0 (Size: 0x50, Type: SetProperty)
    void SET_GalileoPlaylistTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6900, Value); } // 0x6900 (Size: 0x4, Type: StructProperty)
    void SET_WeaponMIDs(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x6908, Value); } // 0x6908 (Size: 0x10, Type: ArrayProperty)
    void SET_AmountOfTimesToAttemptRestoreMats(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6918, Value); } // 0x6918 (Size: 0x4, Type: IntProperty)
    void SET_TC_PawnAthenaNPC(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x691c, Value); } // 0x691c (Size: 0x4, Type: StructProperty)
    void SET_HitGlowBrightnessScalar(const double& Value) { Write<double>(uintptr_t(this) + 0x6920, Value); } // 0x6920 (Size: 0x8, Type: DoubleProperty)
    void SET_CurrentWeaponMaterials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x6928, Value); } // 0x6928 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentWeaponMeshes(const TArray<USkeletalMeshComponent*>& Value) { Write<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x6938, Value); } // 0x6938 (Size: 0x10, Type: ArrayProperty)
    void SET_WeaponDissolveMIDs(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x6948, Value); } // 0x6948 (Size: 0x10, Type: ArrayProperty)
    void SET_HitGlowBrightnessScalar_Mobile(const double& Value) { Write<double>(uintptr_t(this) + 0x6958, Value); } // 0x6958 (Size: 0x8, Type: DoubleProperty)
    void SET_TC_PawnAthenaDecoy(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6960, Value); } // 0x6960 (Size: 0x4, Type: StructProperty)
    void SET_ScaleRate(const double& Value) { Write<double>(uintptr_t(this) + 0x6968, Value); } // 0x6968 (Size: 0x8, Type: DoubleProperty)
    void SET_TetherQuestTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x6970, Value); } // 0x6970 (Size: 0x20, Type: StructProperty)
    void SET_FirefliesTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x6990, Value); } // 0x6990 (Size: 0x4, Type: NameProperty)
    void SET_RightSideRim_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x69a0, Value); } // 0x69a0 (Size: 0x60, Type: StructProperty)
    void SET_Right_Side_Rim_Light(const USpotLightComponent*& Value) { Write<USpotLightComponent*>(uintptr_t(this) + 0x6a00, Value); } // 0x6a00 (Size: 0x8, Type: ObjectProperty)
    void SET_Rim_light_Shadow_Bias(const double& Value) { Write<double>(uintptr_t(this) + 0x6a08, Value); } // 0x6a08 (Size: 0x8, Type: DoubleProperty)
    void SET_Rim_Light_Intensity(const double& Value) { Write<double>(uintptr_t(this) + 0x6a10, Value); } // 0x6a10 (Size: 0x8, Type: DoubleProperty)
    void SET_PlayerAimRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x6a18, Value); } // 0x6a18 (Size: 0x18, Type: StructProperty)
    void SET_ControlRotationReplicationTickRate(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6a30, Value); } // 0x6a30 (Size: 0x28, Type: StructProperty)
    void SET_Elimination_Rez_Sequence_GC(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6a58, Value); } // 0x6a58 (Size: 0x4, Type: StructProperty)
    void SET_Creative_Respawn_Teleportation_GC(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6a5c, Value); } // 0x6a5c (Size: 0x4, Type: StructProperty)
    void SET_Teleport_In_GC(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6a60, Value); } // 0x6a60 (Size: 0x4, Type: StructProperty)
    void SET_RimLightDistanceFromCamera(const double& Value) { Write<double>(uintptr_t(this) + 0x6a68, Value); } // 0x6a68 (Size: 0x8, Type: DoubleProperty)
    void SET_Rim_Light_Color___Night(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x6a70, Value); } // 0x6a70 (Size: 0x10, Type: StructProperty)
    void SET_Rim_Light_Color___Day(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x6a80, Value); } // 0x6a80 (Size: 0x10, Type: StructProperty)
    void SET_PhoneModeratorModeGameplayCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6a90, Value); } // 0x6a90 (Size: 0x4, Type: StructProperty)
    void SET_PhoneInvulnerableGameplayCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6a94, Value); } // 0x6a94 (Size: 0x4, Type: StructProperty)
    void SET_Swinging_HandsUp(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6a98, Value); } // 0x6a98 (Size: 0x1, Type: BoolProperty)
    void SET_Swinging_LockedToHip(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6a99, Value); } // 0x6a99 (Size: 0x1, Type: BoolProperty)
    void SET_InputDragCoefficient(const double& Value) { Write<double>(uintptr_t(this) + 0x6aa0, Value); } // 0x6aa0 (Size: 0x8, Type: DoubleProperty)
    void SET_ToggleSwingNativized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6aa8, Value); } // 0x6aa8 (Size: 0x1, Type: BoolProperty)
    void SET_SwingingSound(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x6ab0, Value); } // 0x6ab0 (Size: 0x8, Type: ObjectProperty)
    void SET_Swinging_ReelingInCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x6ab8, Value); } // 0x6ab8 (Size: 0x8, Type: ObjectProperty)
    void SET_Swinging_NotReelingInCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x6ac0, Value); } // 0x6ac0 (Size: 0x8, Type: ObjectProperty)
    void SET_Swinging_OriginalVecToTarget(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x6ac8, Value); } // 0x6ac8 (Size: 0x18, Type: StructProperty)
    void SET_Swinging_ReelingIn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6ae0, Value); } // 0x6ae0 (Size: 0x1, Type: BoolProperty)
    void SET_Swinging_Goal_Length(const double& Value) { Write<double>(uintptr_t(this) + 0x6ae8, Value); } // 0x6ae8 (Size: 0x8, Type: DoubleProperty)
    void SET_Swinging_ReelingTimeCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x6af0, Value); } // 0x6af0 (Size: 0x8, Type: ObjectProperty)
    void SET_Swinging_ColliderBigger(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6af8, Value); } // 0x6af8 (Size: 0x1, Type: BoolProperty)
    void SET_SoundParams(const TArray<FAudioParameter>& Value) { Write<TArray<FAudioParameter>>(uintptr_t(this) + 0x6b00, Value); } // 0x6b00 (Size: 0x10, Type: ArrayProperty)
    void SET_Swinging_UseNewRotationAlgorithm(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6b10, Value); } // 0x6b10 (Size: 0x1, Type: BoolProperty)
    void SET_AttachedWallInverseNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x6b18, Value); } // 0x6b18 (Size: 0x18, Type: StructProperty)
    void SET_VelocityOnSlideStart(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x6b30, Value); } // 0x6b30 (Size: 0x18, Type: StructProperty)
    void SET_SlideStartTime(const double& Value) { Write<double>(uintptr_t(this) + 0x6b48, Value); } // 0x6b48 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxSlideTime(const double& Value) { Write<double>(uintptr_t(this) + 0x6b50, Value); } // 0x6b50 (Size: 0x8, Type: DoubleProperty)
    void SET_WallSlidingVelocityMultiplierCurve(const UCurveVector*& Value) { Write<UCurveVector*>(uintptr_t(this) + 0x6b58, Value); } // 0x6b58 (Size: 0x8, Type: ObjectProperty)
    void SET_WallSlidingAddedDownwardVelocityMultiplierCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x6b60, Value); } // 0x6b60 (Size: 0x8, Type: ObjectProperty)
    void SET_WallSlidingAddedDownwardVelocityMax(const double& Value) { Write<double>(uintptr_t(this) + 0x6b68, Value); } // 0x6b68 (Size: 0x8, Type: DoubleProperty)
    void SET_AttachedWallNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x6b70, Value); } // 0x6b70 (Size: 0x18, Type: StructProperty)
    void SET_WallSlidingVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x6b88, Value); } // 0x6b88 (Size: 0x18, Type: StructProperty)
    void SET_DesiredDistanceToAttachedWall(const double& Value) { Write<double>(uintptr_t(this) + 0x6ba0, Value); } // 0x6ba0 (Size: 0x8, Type: DoubleProperty)
    void SET_MinGroundSlopeToLeaveAttachedWall(const double& Value) { Write<double>(uintptr_t(this) + 0x6ba8, Value); } // 0x6ba8 (Size: 0x8, Type: DoubleProperty)
    void SET_OverrideSearchMontageInfo(const FFortGameplayAbilityMontageInfo& Value) { Write<FFortGameplayAbilityMontageInfo>(uintptr_t(this) + 0x6bb0, Value); } // 0x6bb0 (Size: 0x58, Type: StructProperty)
    void SET_Is_Hidding_CharacterParrts(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6c08, Value); } // 0x6c08 (Size: 0x1, Type: BoolProperty)
    void SET_RimlightCVARBoost(const double& Value) { Write<double>(uintptr_t(this) + 0x6c10, Value); } // 0x6c10 (Size: 0x8, Type: DoubleProperty)
    void SET_Rimlight_Enabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6c18, Value); } // 0x6c18 (Size: 0x1, Type: BoolProperty)
    void SET_LCVar_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x6c20, Value); } // 0x6c20 (Size: 0x10, Type: StrProperty)
    void SET_UGC_RimLightIntensity(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6c30, Value); } // 0x6c30 (Size: 0x28, Type: StructProperty)
    void SET_SFX_WaterExit_3P(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x6c58, Value); } // 0x6c58 (Size: 0x8, Type: ObjectProperty)
    void SET_SFX_WaterExit_1P(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x6c60, Value); } // 0x6c60 (Size: 0x8, Type: ObjectProperty)
    void SET_SFX_WaterEntry_3P(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x6c68, Value); } // 0x6c68 (Size: 0x8, Type: ObjectProperty)
    void SET_SFX_WaterEntry_1P(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x6c70, Value); } // 0x6c70 (Size: 0x8, Type: ObjectProperty)
    void SET_EnableDecayRow(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6c78, Value); } // 0x6c78 (Size: 0x28, Type: StructProperty)
    void SET_CeilingHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x6ca0, Value); } // 0x6ca0 (Size: 0x8, Type: DoubleProperty)
    void SET_BAProtoVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x6ca8, Value); } // 0x6ca8 (Size: 0x18, Type: StructProperty)
    void SET_HF_TetherMultiplierHorz(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6cc0, Value); } // 0x6cc0 (Size: 0x28, Type: StructProperty)
    void SET_HF_TetherMultiplierVert(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x6ce8, Value); } // 0x6ce8 (Size: 0x28, Type: StructProperty)
    void SET_Teleport_In_GC_Frontend(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6d10, Value); } // 0x6d10 (Size: 0x4, Type: StructProperty)
    void SET_Re_apply_Highlight_Timer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x6d18, Value); } // 0x6d18 (Size: 0x8, Type: StructProperty)
    void SET_Style_Transfer_GC_Frontend(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6d20, Value); } // 0x6d20 (Size: 0x4, Type: StructProperty)
    void SET_RemovePawnHighlightGC(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6d24, Value); } // 0x6d24 (Size: 0x4, Type: StructProperty)
    void SET_Elimination_Rez_Sequence_TagMap(const TMap<FGameplayTag, FGameplayTag>& Value) { Write<TMap<FGameplayTag, FGameplayTag>>(uintptr_t(this) + 0x6d28, Value); } // 0x6d28 (Size: 0x50, Type: MapProperty)
    void SET_Tactical_Elimination_Rez_Sequence_GC(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x6d78, Value); } // 0x6d78 (Size: 0x4, Type: StructProperty)
    void SET_On_Death_Damage_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x6d80, Value); } // 0x6d80 (Size: 0x20, Type: StructProperty)
    void SET_On_Death_Momentum(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x6da0, Value); } // 0x6da0 (Size: 0x18, Type: StructProperty)
    void SET_On_Death_Effect_Context(const FGameplayEffectContextHandle& Value) { Write<FGameplayEffectContextHandle>(uintptr_t(this) + 0x6db8, Value); } // 0x6db8 (Size: 0x18, Type: StructProperty)
    void SET_WaitingForMaterialsTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x6dd0, Value); } // 0x6dd0 (Size: 0x8, Type: StructProperty)
    void SET_On_Death_Controller(const AController*& Value) { Write<AController*>(uintptr_t(this) + 0x6dd8, Value); } // 0x6dd8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x6421
class APlayerPawn_Athena_Generic_C : public APlayerPawn_Athena_Generic_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x6160); } // 0x6160 (Size: 0x8, Type: StructProperty)
    UParticleSystemComponent* Effect_WaterInteraction_FX() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x6168); } // 0x6168 (Size: 0x8, Type: ObjectProperty)
    bool IsInWater() const { return Read<bool>(uintptr_t(this) + 0x6170); } // 0x6170 (Size: 0x1, Type: BoolProperty)
    FRotator RunWalkParticleRotation() const { return Read<FRotator>(uintptr_t(this) + 0x6178); } // 0x6178 (Size: 0x18, Type: StructProperty)
    int32_t WaterCounter() const { return Read<int32_t>(uintptr_t(this) + 0x6190); } // 0x6190 (Size: 0x4, Type: IntProperty)
    double Tick_Delta_Seconds() const { return Read<double>(uintptr_t(this) + 0x6198); } // 0x6198 (Size: 0x8, Type: DoubleProperty)
    USoundBase* Sound_Shield_Impact() const { return Read<USoundBase*>(uintptr_t(this) + 0x61a0); } // 0x61a0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Sound_Shield_Destroyed() const { return Read<USoundBase*>(uintptr_t(this) + 0x61a8); } // 0x61a8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Sound_Shield_Destroyed_1P() const { return Read<USoundBase*>(uintptr_t(this) + 0x61b0); } // 0x61b0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Sound_Shield_FullyCharged() const { return Read<USoundBase*>(uintptr_t(this) + 0x61b8); } // 0x61b8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Sound_Shield_StartRecharge() const { return Read<USoundBase*>(uintptr_t(this) + 0x61c0); } // 0x61c0 (Size: 0x8, Type: ObjectProperty)
    bool BodyValid() const { return Read<bool>(uintptr_t(this) + 0x61c8); } // 0x61c8 (Size: 0x1, Type: BoolProperty)
    bool BackpackValid() const { return Read<bool>(uintptr_t(this) + 0x61c9); } // 0x61c9 (Size: 0x1, Type: BoolProperty)
    bool HatValid() const { return Read<bool>(uintptr_t(this) + 0x61ca); } // 0x61ca (Size: 0x1, Type: BoolProperty)
    bool FaceValid() const { return Read<bool>(uintptr_t(this) + 0x61cb); } // 0x61cb (Size: 0x1, Type: BoolProperty)
    bool CharmValid() const { return Read<bool>(uintptr_t(this) + 0x61cc); } // 0x61cc (Size: 0x1, Type: BoolProperty)
    bool HeadValid() const { return Read<bool>(uintptr_t(this) + 0x61cd); } // 0x61cd (Size: 0x1, Type: BoolProperty)
    TArray<UMaterialInstanceDynamic*> TempArray() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x61d0); } // 0x61d0 (Size: 0x10, Type: ArrayProperty)
    USceneComponent* Sound_Player_Hit() const { return Read<USceneComponent*>(uintptr_t(this) + 0x61e0); } // 0x61e0 (Size: 0x8, Type: ObjectProperty)
    UClass* SpeechBubbleWidgetClass() const { return Read<UClass*>(uintptr_t(this) + 0x61e8); } // 0x61e8 (Size: 0x8, Type: ClassProperty)
    FText LastSpeechText() const { return Read<FText>(uintptr_t(this) + 0x61f0); } // 0x61f0 (Size: 0x10, Type: TextProperty)
    double Time_when_you_ll_be_able_to_splash_again() const { return Read<double>(uintptr_t(this) + 0x6200); } // 0x6200 (Size: 0x8, Type: DoubleProperty)
    AActor* CurrentWaterMeshActor() const { return Read<AActor*>(uintptr_t(this) + 0x6208); } // 0x6208 (Size: 0x8, Type: ObjectProperty)
    FHitResult WaterTraceHitLocation() const { return Read<FHitResult>(uintptr_t(this) + 0x6210); } // 0x6210 (Size: 0xf8, Type: StructProperty)
    FVector StableVelocityVector() const { return Read<FVector>(uintptr_t(this) + 0x6308); } // 0x6308 (Size: 0x18, Type: StructProperty)
    UParticleSystem* PlayerRunTemplate_Ground() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x6320); } // 0x6320 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* PlayerWalkTemplate_Ground() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x6328); } // 0x6328 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* PlayerRunTemplate_Water() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x6330); } // 0x6330 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* PlayerWalkTemplate_Water() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x6338); } // 0x6338 (Size: 0x8, Type: ObjectProperty)
    USkeletalMesh* Pawn_Charm_Skeletal_Mesh() const { return Read<USkeletalMesh*>(uintptr_t(this) + 0x6340); } // 0x6340 (Size: 0x8, Type: ObjectProperty)
    UMaterialInterface* WeaponMaterialOverride() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x6348); } // 0x6348 (Size: 0x8, Type: ObjectProperty)
    bool TickWaterLevel() const { return Read<bool>(uintptr_t(this) + 0x6350); } // 0x6350 (Size: 0x1, Type: BoolProperty)
    UTextureRenderTarget2D* WetnessDepthTexture() const { return Read<UTextureRenderTarget2D*>(uintptr_t(this) + 0x6358); } // 0x6358 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* WaterLevelMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x6360); } // 0x6360 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* WaterDecayMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x6368); } // 0x6368 (Size: 0x8, Type: ObjectProperty)
    bool Was_RTT_Enabled_Var_Set() const { return Read<bool>(uintptr_t(this) + 0x6370); } // 0x6370 (Size: 0x1, Type: BoolProperty)
    bool Is_RTT_Enabled() const { return Read<bool>(uintptr_t(this) + 0x6371); } // 0x6371 (Size: 0x1, Type: BoolProperty)
    double StartingMinCapsuleShadowVis() const { return Read<double>(uintptr_t(this) + 0x6378); } // 0x6378 (Size: 0x8, Type: DoubleProperty)
    double InstigatorCheckDistanceSqrd() const { return Read<double>(uintptr_t(this) + 0x6380); } // 0x6380 (Size: 0x8, Type: DoubleProperty)
    double SlideDustActivateSpeed() const { return Read<double>(uintptr_t(this) + 0x6388); } // 0x6388 (Size: 0x8, Type: DoubleProperty)
    bool CanSpawnSlideKickupFX_() const { return Read<bool>(uintptr_t(this) + 0x6390); } // 0x6390 (Size: 0x1, Type: BoolProperty)
    UParticleSystem* Effect_Player_ShieldActivate() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x6398); } // 0x6398 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* Effect_PLayer_ShieldBreak() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x63a0); } // 0x63a0 (Size: 0x8, Type: ObjectProperty)
    bool GhostMode() const { return Read<bool>(uintptr_t(this) + 0x63a8); } // 0x63a8 (Size: 0x1, Type: BoolProperty)
    USoundBase* Sound_Shield_Destroyed_2D() const { return Read<USoundBase*>(uintptr_t(this) + 0x63d0); } // 0x63d0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Sound_Shield_Destroyed_Crit_2D() const { return Read<USoundBase*>(uintptr_t(this) + 0x63d8); } // 0x63d8 (Size: 0x8, Type: ObjectProperty)
    double ReppedCapsuleExtraHalfHeight() const { return Read<double>(uintptr_t(this) + 0x63f0); } // 0x63f0 (Size: 0x8, Type: DoubleProperty)
    double CachedCapsuleHalfHeight() const { return Read<double>(uintptr_t(this) + 0x63f8); } // 0x63f8 (Size: 0x8, Type: DoubleProperty)
    USkeletalMeshComponent* NullPart_Mesh() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0x6410); } // 0x6410 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* Effect_PLayer_ShieldBreak_LW() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0x6418); } // 0x6418 (Size: 0x8, Type: ObjectProperty)
    bool ShieldFPCheck() const { return Read<bool>(uintptr_t(this) + 0x6420); } // 0x6420 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x6160, Value); } // 0x6160 (Size: 0x8, Type: StructProperty)
    void SET_Effect_WaterInteraction_FX(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x6168, Value); } // 0x6168 (Size: 0x8, Type: ObjectProperty)
    void SET_IsInWater(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6170, Value); } // 0x6170 (Size: 0x1, Type: BoolProperty)
    void SET_RunWalkParticleRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x6178, Value); } // 0x6178 (Size: 0x18, Type: StructProperty)
    void SET_WaterCounter(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6190, Value); } // 0x6190 (Size: 0x4, Type: IntProperty)
    void SET_Tick_Delta_Seconds(const double& Value) { Write<double>(uintptr_t(this) + 0x6198, Value); } // 0x6198 (Size: 0x8, Type: DoubleProperty)
    void SET_Sound_Shield_Impact(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x61a0, Value); } // 0x61a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Sound_Shield_Destroyed(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x61a8, Value); } // 0x61a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Sound_Shield_Destroyed_1P(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x61b0, Value); } // 0x61b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Sound_Shield_FullyCharged(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x61b8, Value); } // 0x61b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Sound_Shield_StartRecharge(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x61c0, Value); } // 0x61c0 (Size: 0x8, Type: ObjectProperty)
    void SET_BodyValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x61c8, Value); } // 0x61c8 (Size: 0x1, Type: BoolProperty)
    void SET_BackpackValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x61c9, Value); } // 0x61c9 (Size: 0x1, Type: BoolProperty)
    void SET_HatValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x61ca, Value); } // 0x61ca (Size: 0x1, Type: BoolProperty)
    void SET_FaceValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x61cb, Value); } // 0x61cb (Size: 0x1, Type: BoolProperty)
    void SET_CharmValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x61cc, Value); } // 0x61cc (Size: 0x1, Type: BoolProperty)
    void SET_HeadValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x61cd, Value); } // 0x61cd (Size: 0x1, Type: BoolProperty)
    void SET_TempArray(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x61d0, Value); } // 0x61d0 (Size: 0x10, Type: ArrayProperty)
    void SET_Sound_Player_Hit(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x61e0, Value); } // 0x61e0 (Size: 0x8, Type: ObjectProperty)
    void SET_SpeechBubbleWidgetClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x61e8, Value); } // 0x61e8 (Size: 0x8, Type: ClassProperty)
    void SET_LastSpeechText(const FText& Value) { Write<FText>(uintptr_t(this) + 0x61f0, Value); } // 0x61f0 (Size: 0x10, Type: TextProperty)
    void SET_Time_when_you_ll_be_able_to_splash_again(const double& Value) { Write<double>(uintptr_t(this) + 0x6200, Value); } // 0x6200 (Size: 0x8, Type: DoubleProperty)
    void SET_CurrentWaterMeshActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x6208, Value); } // 0x6208 (Size: 0x8, Type: ObjectProperty)
    void SET_WaterTraceHitLocation(const FHitResult& Value) { Write<FHitResult>(uintptr_t(this) + 0x6210, Value); } // 0x6210 (Size: 0xf8, Type: StructProperty)
    void SET_StableVelocityVector(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x6308, Value); } // 0x6308 (Size: 0x18, Type: StructProperty)
    void SET_PlayerRunTemplate_Ground(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x6320, Value); } // 0x6320 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerWalkTemplate_Ground(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x6328, Value); } // 0x6328 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerRunTemplate_Water(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x6330, Value); } // 0x6330 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerWalkTemplate_Water(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x6338, Value); } // 0x6338 (Size: 0x8, Type: ObjectProperty)
    void SET_Pawn_Charm_Skeletal_Mesh(const USkeletalMesh*& Value) { Write<USkeletalMesh*>(uintptr_t(this) + 0x6340, Value); } // 0x6340 (Size: 0x8, Type: ObjectProperty)
    void SET_WeaponMaterialOverride(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x6348, Value); } // 0x6348 (Size: 0x8, Type: ObjectProperty)
    void SET_TickWaterLevel(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6350, Value); } // 0x6350 (Size: 0x1, Type: BoolProperty)
    void SET_WetnessDepthTexture(const UTextureRenderTarget2D*& Value) { Write<UTextureRenderTarget2D*>(uintptr_t(this) + 0x6358, Value); } // 0x6358 (Size: 0x8, Type: ObjectProperty)
    void SET_WaterLevelMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x6360, Value); } // 0x6360 (Size: 0x8, Type: ObjectProperty)
    void SET_WaterDecayMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x6368, Value); } // 0x6368 (Size: 0x8, Type: ObjectProperty)
    void SET_Was_RTT_Enabled_Var_Set(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6370, Value); } // 0x6370 (Size: 0x1, Type: BoolProperty)
    void SET_Is_RTT_Enabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6371, Value); } // 0x6371 (Size: 0x1, Type: BoolProperty)
    void SET_StartingMinCapsuleShadowVis(const double& Value) { Write<double>(uintptr_t(this) + 0x6378, Value); } // 0x6378 (Size: 0x8, Type: DoubleProperty)
    void SET_InstigatorCheckDistanceSqrd(const double& Value) { Write<double>(uintptr_t(this) + 0x6380, Value); } // 0x6380 (Size: 0x8, Type: DoubleProperty)
    void SET_SlideDustActivateSpeed(const double& Value) { Write<double>(uintptr_t(this) + 0x6388, Value); } // 0x6388 (Size: 0x8, Type: DoubleProperty)
    void SET_CanSpawnSlideKickupFX_(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6390, Value); } // 0x6390 (Size: 0x1, Type: BoolProperty)
    void SET_Effect_Player_ShieldActivate(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x6398, Value); } // 0x6398 (Size: 0x8, Type: ObjectProperty)
    void SET_Effect_PLayer_ShieldBreak(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x63a0, Value); } // 0x63a0 (Size: 0x8, Type: ObjectProperty)
    void SET_GhostMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x63a8, Value); } // 0x63a8 (Size: 0x1, Type: BoolProperty)
    void SET_Sound_Shield_Destroyed_2D(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x63d0, Value); } // 0x63d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Sound_Shield_Destroyed_Crit_2D(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x63d8, Value); } // 0x63d8 (Size: 0x8, Type: ObjectProperty)
    void SET_ReppedCapsuleExtraHalfHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x63f0, Value); } // 0x63f0 (Size: 0x8, Type: DoubleProperty)
    void SET_CachedCapsuleHalfHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x63f8, Value); } // 0x63f8 (Size: 0x8, Type: DoubleProperty)
    void SET_NullPart_Mesh(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0x6410, Value); } // 0x6410 (Size: 0x8, Type: ObjectProperty)
    void SET_Effect_PLayer_ShieldBreak_LW(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0x6418, Value); } // 0x6418 (Size: 0x8, Type: ObjectProperty)
    void SET_ShieldFPCheck(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6420, Value); } // 0x6420 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa68
class UGE_SurfaceChange_Ice_Suppress_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Athena_HidingProp_GettingInProp_C : public UGameplayEffect
{
public:
};

// Size: 0xb70
class UGA_Athena_HidingProp_BlockMovement_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
};

// Size: 0x218
class UGCN_Athena_PlayerLevelUp_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0xac8
class AGCNL_AthenaAI_NonParticipant_AlertState_C : public AFortGameplayCueNotifyAthena_AIAlertState
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa70); } // 0xa70 (Size: 0x8, Type: StructProperty)
    FLinearColor IconColorAlert() const { return Read<FLinearColor>(uintptr_t(this) + 0xa78); } // 0xa78 (Size: 0x10, Type: StructProperty)
    FLinearColor IconColorThreatend() const { return Read<FLinearColor>(uintptr_t(this) + 0xa88); } // 0xa88 (Size: 0x10, Type: StructProperty)
    double AnimationLength() const { return Read<double>(uintptr_t(this) + 0xa98); } // 0xa98 (Size: 0x8, Type: DoubleProperty)
    FLinearColor IconColorAlertInner() const { return Read<FLinearColor>(uintptr_t(this) + 0xaa0); } // 0xaa0 (Size: 0x10, Type: StructProperty)
    USoundBase* Hostile_Combat_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0xab0); } // 0xab0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SearchingSound() const { return Read<USoundBase*>(uintptr_t(this) + 0xab8); } // 0xab8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Non_hostile_Combat_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0xac0); } // 0xac0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa70, Value); } // 0xa70 (Size: 0x8, Type: StructProperty)
    void SET_IconColorAlert(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xa78, Value); } // 0xa78 (Size: 0x10, Type: StructProperty)
    void SET_IconColorThreatend(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xa88, Value); } // 0xa88 (Size: 0x10, Type: StructProperty)
    void SET_AnimationLength(const double& Value) { Write<double>(uintptr_t(this) + 0xa98, Value); } // 0xa98 (Size: 0x8, Type: DoubleProperty)
    void SET_IconColorAlertInner(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0xaa0, Value); } // 0xaa0 (Size: 0x10, Type: StructProperty)
    void SET_Hostile_Combat_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xab0, Value); } // 0xab0 (Size: 0x8, Type: ObjectProperty)
    void SET_SearchingSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xab8, Value); } // 0xab8 (Size: 0x8, Type: ObjectProperty)
    void SET_Non_hostile_Combat_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xac0, Value); } // 0xac0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x7338
class ABP_PlayerPawn_NonParticipant_C : public ABP_PlayerPawn_Athena_Phoebe_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x7088); } // 0x7088 (Size: 0x8, Type: StructProperty)
    UFortPawnComponent_AIPatrol* FortPawnComponent_AIPatrol() const { return Read<UFortPawnComponent_AIPatrol*>(uintptr_t(this) + 0x7090); } // 0x7090 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAlertStateComponent* FortAthenaAlertState() const { return Read<UFortAthenaAlertStateComponent*>(uintptr_t(this) + 0x7098); } // 0x7098 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* VOAudioComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x70a0); } // 0x70a0 (Size: 0x8, Type: ObjectProperty)
    bool UseAlertness() const { return Read<bool>(uintptr_t(this) + 0x70a8); } // 0x70a8 (Size: 0x1, Type: BoolProperty)
    bool UseVO() const { return Read<bool>(uintptr_t(this) + 0x70a9); } // 0x70a9 (Size: 0x1, Type: BoolProperty)
    bool UseIdleVO() const { return Read<bool>(uintptr_t(this) + 0x70aa); } // 0x70aa (Size: 0x1, Type: BoolProperty)
    bool UseDropExtraLootOnDeath() const { return Read<bool>(uintptr_t(this) + 0x70ab); } // 0x70ab (Size: 0x1, Type: BoolProperty)
    bool UseFullBodyHitReact() const { return Read<bool>(uintptr_t(this) + 0x70ac); } // 0x70ac (Size: 0x1, Type: BoolProperty)
    bool UseChangedTargetReplication() const { return Read<bool>(uintptr_t(this) + 0x70ad); } // 0x70ad (Size: 0x1, Type: BoolProperty)
    bool UseAlertSound() const { return Read<bool>(uintptr_t(this) + 0x70ae); } // 0x70ae (Size: 0x1, Type: BoolProperty)
    bool CalculateTargetYawDegrees() const { return Read<bool>(uintptr_t(this) + 0x70af); } // 0x70af (Size: 0x1, Type: BoolProperty)
    uint8_t AlertLevel() const { return Read<uint8_t>(uintptr_t(this) + 0x70b0); } // 0x70b0 (Size: 0x1, Type: EnumProperty)
    uint8_t OldAlertLevel() const { return Read<uint8_t>(uintptr_t(this) + 0x70b1); } // 0x70b1 (Size: 0x1, Type: EnumProperty)
    FGameplayTag GameplayCueAlertState() const { return Read<FGameplayTag>(uintptr_t(this) + 0x70b4); } // 0x70b4 (Size: 0x4, Type: StructProperty)
    UClass* GE_NPC_Status_Stressed_Infinite() const { return Read<UClass*>(uintptr_t(this) + 0x70b8); } // 0x70b8 (Size: 0x8, Type: ClassProperty)
    UClass* GE_NPC_Status_Stressed_Cooldown() const { return Read<UClass*>(uintptr_t(this) + 0x70c0); } // 0x70c0 (Size: 0x8, Type: ClassProperty)
    double MinDistanceToTargetToPlayCombatAlertAnimation() const { return Read<double>(uintptr_t(this) + 0x70c8); } // 0x70c8 (Size: 0x8, Type: DoubleProperty)
    FScalableFloat MinIdleVODelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x70d0); } // 0x70d0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxIdleVODelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x70f8); } // 0x70f8 (Size: 0x28, Type: StructProperty)
    FName LootTierNameToSpawnWhenDead() const { return Read<FName>(uintptr_t(this) + 0x7120); } // 0x7120 (Size: 0x4, Type: NameProperty)
    FName LootTier_Medium() const { return Read<FName>(uintptr_t(this) + 0x7124); } // 0x7124 (Size: 0x4, Type: NameProperty)
    FName LootTier_Shell() const { return Read<FName>(uintptr_t(this) + 0x7128); } // 0x7128 (Size: 0x4, Type: NameProperty)
    FName LootTier_Heavy() const { return Read<FName>(uintptr_t(this) + 0x712c); } // 0x712c (Size: 0x4, Type: NameProperty)
    FName LootTier_Light() const { return Read<FName>(uintptr_t(this) + 0x7130); } // 0x7130 (Size: 0x4, Type: NameProperty)
    FName LootTier_Rockets() const { return Read<FName>(uintptr_t(this) + 0x7134); } // 0x7134 (Size: 0x4, Type: NameProperty)
    UFortGameplayDataTrackerComponentManager* DataTrackerComponentManager() const { return Read<UFortGameplayDataTrackerComponentManager*>(uintptr_t(this) + 0x7138); } // 0x7138 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag AlertLevelUnawareTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x7140); } // 0x7140 (Size: 0x4, Type: StructProperty)
    FGameplayTag AlertLevelAlertedTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x7144); } // 0x7144 (Size: 0x4, Type: StructProperty)
    FGameplayTag AlertLevelAggressiveTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x7148); } // 0x7148 (Size: 0x4, Type: StructProperty)
    FGameplayTag TC_DisguiseTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x714c); } // 0x714c (Size: 0x4, Type: StructProperty)
    UClass* GE_RemoveDisguise() const { return Read<UClass*>(uintptr_t(this) + 0x7150); } // 0x7150 (Size: 0x8, Type: ClassProperty)
    UFortAbilitySet* HitReactAbilitySet() const { return Read<UFortAbilitySet*>(uintptr_t(this) + 0x7158); } // 0x7158 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* DefaultFullbodyHitReactionMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x7160); } // 0x7160 (Size: 0x8, Type: ObjectProperty)
    UFortPatrolAnimAsset* CurrentPatrolAnimAsset() const { return Read<UFortPatrolAnimAsset*>(uintptr_t(this) + 0x7168); } // 0x7168 (Size: 0x8, Type: ObjectProperty)
    UClass* PatrolLayerAnimBP() const { return Read<UClass*>(uintptr_t(this) + 0x7170); } // 0x7170 (Size: 0x8, Type: ClassProperty)
    TArray<FFortPatrolAnimSetWeaponPair> PatrolAnimSetPairs() const { return Read<TArray<FFortPatrolAnimSetWeaponPair>>(uintptr_t(this) + 0x7178); } // 0x7178 (Size: 0x10, Type: ArrayProperty)
    bool bShouldDoFullAnimationUpdate() const { return Read<bool>(uintptr_t(this) + 0x7188); } // 0x7188 (Size: 0x1, Type: BoolProperty)
    FActiveGameplayEffectHandle GEDuelHandle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x718c); } // 0x718c (Size: 0x8, Type: StructProperty)
    UClass* GE_DuelTag() const { return Read<UClass*>(uintptr_t(this) + 0x7198); } // 0x7198 (Size: 0x8, Type: ClassProperty)
    AFortPlayerPawn* Challenger() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x71a0); } // 0x71a0 (Size: 0x8, Type: ObjectProperty)
    UClass* OverrideLayerAnimBP() const { return Read<UClass*>(uintptr_t(this) + 0x71a8); } // 0x71a8 (Size: 0x8, Type: ClassProperty)
    UFortPatrolAnimAsset* FallbackPatrolAnimAsset() const { return Read<UFortPatrolAnimAsset*>(uintptr_t(this) + 0x71b0); } // 0x71b0 (Size: 0x8, Type: ObjectProperty)
    bool bIsInVehicleThatSupportsNoAlertState() const { return Read<bool>(uintptr_t(this) + 0x71b8); } // 0x71b8 (Size: 0x1, Type: BoolProperty)
    FActiveGameplayEffectHandle GE_Quest_Converted_Handle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x71bc); } // 0x71bc (Size: 0x8, Type: StructProperty)
    UClass* GE_Quest_Converted_HireNPC() const { return Read<UClass*>(uintptr_t(this) + 0x71c8); } // 0x71c8 (Size: 0x8, Type: ClassProperty)
    USoundBase* DeathFX_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x71d0); } // 0x71d0 (Size: 0x8, Type: ObjectProperty)
    AFortPawn* PawnConverter() const { return Read<AFortPawn*>(uintptr_t(this) + 0x71d8); } // 0x71d8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer TagsToApplyOnConvertedPawn() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x71e0); } // 0x71e0 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TagsToApplyOnConvertingPawn() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x7200); } // 0x7200 (Size: 0x20, Type: StructProperty)
    USoundLibrary* PawnSoundLibrary() const { return Read<USoundLibrary*>(uintptr_t(this) + 0x7220); } // 0x7220 (Size: 0x8, Type: ObjectProperty)
    bool RemoveTagsOnUnconverted() const { return Read<bool>(uintptr_t(this) + 0x7228); } // 0x7228 (Size: 0x1, Type: BoolProperty)
    UFortAbilitySet* GASToApplyOnConvertedPawn() const { return Read<UFortAbilitySet*>(uintptr_t(this) + 0x7230); } // 0x7230 (Size: 0x8, Type: ObjectProperty)
    bool RemoveGASOnUnconverted() const { return Read<bool>(uintptr_t(this) + 0x7238); } // 0x7238 (Size: 0x1, Type: BoolProperty)
    FFortAbilitySetHandle HNDL_EquippedAbilitySet() const { return Read<FFortAbilitySetHandle>(uintptr_t(this) + 0x7240); } // 0x7240 (Size: 0x38, Type: StructProperty)
    AActor* NewTargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x7278); } // 0x7278 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle IdleVOTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x72b0); } // 0x72b0 (Size: 0x8, Type: StructProperty)
    FScalableFloat UseMotionMatchingForPatrols() const { return Read<FScalableFloat>(uintptr_t(this) + 0x72b8); } // 0x72b8 (Size: 0x28, Type: StructProperty)
    FGameplayTag TagEventVOTrigger() const { return Read<FGameplayTag>(uintptr_t(this) + 0x72e0); } // 0x72e0 (Size: 0x4, Type: StructProperty)
    FGameplayTag VOSoundBankTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x72e4); } // 0x72e4 (Size: 0x4, Type: StructProperty)
    bool bAllowStingers() const { return Read<bool>(uintptr_t(this) + 0x72e8); } // 0x72e8 (Size: 0x1, Type: BoolProperty)
    FGameplayTag Tag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x72ec); } // 0x72ec (Size: 0x4, Type: StructProperty)
    FFortAthenaTeamHUDInfo Fort_Athena_Team_HUDInfo() const { return Read<FFortAthenaTeamHUDInfo>(uintptr_t(this) + 0x72f0); } // 0x72f0 (Size: 0x20, Type: StructProperty)
    AFortPawn* Instigator_Pawn() const { return Read<AFortPawn*>(uintptr_t(this) + 0x7310); } // 0x7310 (Size: 0x8, Type: ObjectProperty)
    FSoundLibraryTag SlStingerTag() const { return Read<FSoundLibraryTag>(uintptr_t(this) + 0x7318); } // 0x7318 (Size: 0x4, Type: StructProperty)
    USoundLibraryContext* Context() const { return Read<USoundLibraryContext*>(uintptr_t(this) + 0x7320); } // 0x7320 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle HNDL_CalculateYawTargetDegreeTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x7328); } // 0x7328 (Size: 0x8, Type: StructProperty)
    double TargetYawDegrees() const { return Read<double>(uintptr_t(this) + 0x7330); } // 0x7330 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x7088, Value); } // 0x7088 (Size: 0x8, Type: StructProperty)
    void SET_FortPawnComponent_AIPatrol(const UFortPawnComponent_AIPatrol*& Value) { Write<UFortPawnComponent_AIPatrol*>(uintptr_t(this) + 0x7090, Value); } // 0x7090 (Size: 0x8, Type: ObjectProperty)
    void SET_FortAthenaAlertState(const UFortAthenaAlertStateComponent*& Value) { Write<UFortAthenaAlertStateComponent*>(uintptr_t(this) + 0x7098, Value); } // 0x7098 (Size: 0x8, Type: ObjectProperty)
    void SET_VOAudioComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x70a0, Value); } // 0x70a0 (Size: 0x8, Type: ObjectProperty)
    void SET_UseAlertness(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70a8, Value); } // 0x70a8 (Size: 0x1, Type: BoolProperty)
    void SET_UseVO(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70a9, Value); } // 0x70a9 (Size: 0x1, Type: BoolProperty)
    void SET_UseIdleVO(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70aa, Value); } // 0x70aa (Size: 0x1, Type: BoolProperty)
    void SET_UseDropExtraLootOnDeath(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70ab, Value); } // 0x70ab (Size: 0x1, Type: BoolProperty)
    void SET_UseFullBodyHitReact(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70ac, Value); } // 0x70ac (Size: 0x1, Type: BoolProperty)
    void SET_UseChangedTargetReplication(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70ad, Value); } // 0x70ad (Size: 0x1, Type: BoolProperty)
    void SET_UseAlertSound(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70ae, Value); } // 0x70ae (Size: 0x1, Type: BoolProperty)
    void SET_CalculateTargetYawDegrees(const bool& Value) { Write<bool>(uintptr_t(this) + 0x70af, Value); } // 0x70af (Size: 0x1, Type: BoolProperty)
    void SET_AlertLevel(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70b0, Value); } // 0x70b0 (Size: 0x1, Type: EnumProperty)
    void SET_OldAlertLevel(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x70b1, Value); } // 0x70b1 (Size: 0x1, Type: EnumProperty)
    void SET_GameplayCueAlertState(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x70b4, Value); } // 0x70b4 (Size: 0x4, Type: StructProperty)
    void SET_GE_NPC_Status_Stressed_Infinite(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x70b8, Value); } // 0x70b8 (Size: 0x8, Type: ClassProperty)
    void SET_GE_NPC_Status_Stressed_Cooldown(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x70c0, Value); } // 0x70c0 (Size: 0x8, Type: ClassProperty)
    void SET_MinDistanceToTargetToPlayCombatAlertAnimation(const double& Value) { Write<double>(uintptr_t(this) + 0x70c8, Value); } // 0x70c8 (Size: 0x8, Type: DoubleProperty)
    void SET_MinIdleVODelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x70d0, Value); } // 0x70d0 (Size: 0x28, Type: StructProperty)
    void SET_MaxIdleVODelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x70f8, Value); } // 0x70f8 (Size: 0x28, Type: StructProperty)
    void SET_LootTierNameToSpawnWhenDead(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7120, Value); } // 0x7120 (Size: 0x4, Type: NameProperty)
    void SET_LootTier_Medium(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7124, Value); } // 0x7124 (Size: 0x4, Type: NameProperty)
    void SET_LootTier_Shell(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7128, Value); } // 0x7128 (Size: 0x4, Type: NameProperty)
    void SET_LootTier_Heavy(const FName& Value) { Write<FName>(uintptr_t(this) + 0x712c, Value); } // 0x712c (Size: 0x4, Type: NameProperty)
    void SET_LootTier_Light(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7130, Value); } // 0x7130 (Size: 0x4, Type: NameProperty)
    void SET_LootTier_Rockets(const FName& Value) { Write<FName>(uintptr_t(this) + 0x7134, Value); } // 0x7134 (Size: 0x4, Type: NameProperty)
    void SET_DataTrackerComponentManager(const UFortGameplayDataTrackerComponentManager*& Value) { Write<UFortGameplayDataTrackerComponentManager*>(uintptr_t(this) + 0x7138, Value); } // 0x7138 (Size: 0x8, Type: ObjectProperty)
    void SET_AlertLevelUnawareTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x7140, Value); } // 0x7140 (Size: 0x4, Type: StructProperty)
    void SET_AlertLevelAlertedTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x7144, Value); } // 0x7144 (Size: 0x4, Type: StructProperty)
    void SET_AlertLevelAggressiveTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x7148, Value); } // 0x7148 (Size: 0x4, Type: StructProperty)
    void SET_TC_DisguiseTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x714c, Value); } // 0x714c (Size: 0x4, Type: StructProperty)
    void SET_GE_RemoveDisguise(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x7150, Value); } // 0x7150 (Size: 0x8, Type: ClassProperty)
    void SET_HitReactAbilitySet(const UFortAbilitySet*& Value) { Write<UFortAbilitySet*>(uintptr_t(this) + 0x7158, Value); } // 0x7158 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultFullbodyHitReactionMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x7160, Value); } // 0x7160 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentPatrolAnimAsset(const UFortPatrolAnimAsset*& Value) { Write<UFortPatrolAnimAsset*>(uintptr_t(this) + 0x7168, Value); } // 0x7168 (Size: 0x8, Type: ObjectProperty)
    void SET_PatrolLayerAnimBP(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x7170, Value); } // 0x7170 (Size: 0x8, Type: ClassProperty)
    void SET_PatrolAnimSetPairs(const TArray<FFortPatrolAnimSetWeaponPair>& Value) { Write<TArray<FFortPatrolAnimSetWeaponPair>>(uintptr_t(this) + 0x7178, Value); } // 0x7178 (Size: 0x10, Type: ArrayProperty)
    void SET_bShouldDoFullAnimationUpdate(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7188, Value); } // 0x7188 (Size: 0x1, Type: BoolProperty)
    void SET_GEDuelHandle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x718c, Value); } // 0x718c (Size: 0x8, Type: StructProperty)
    void SET_GE_DuelTag(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x7198, Value); } // 0x7198 (Size: 0x8, Type: ClassProperty)
    void SET_Challenger(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x71a0, Value); } // 0x71a0 (Size: 0x8, Type: ObjectProperty)
    void SET_OverrideLayerAnimBP(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x71a8, Value); } // 0x71a8 (Size: 0x8, Type: ClassProperty)
    void SET_FallbackPatrolAnimAsset(const UFortPatrolAnimAsset*& Value) { Write<UFortPatrolAnimAsset*>(uintptr_t(this) + 0x71b0, Value); } // 0x71b0 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsInVehicleThatSupportsNoAlertState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x71b8, Value); } // 0x71b8 (Size: 0x1, Type: BoolProperty)
    void SET_GE_Quest_Converted_Handle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x71bc, Value); } // 0x71bc (Size: 0x8, Type: StructProperty)
    void SET_GE_Quest_Converted_HireNPC(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x71c8, Value); } // 0x71c8 (Size: 0x8, Type: ClassProperty)
    void SET_DeathFX_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x71d0, Value); } // 0x71d0 (Size: 0x8, Type: ObjectProperty)
    void SET_PawnConverter(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x71d8, Value); } // 0x71d8 (Size: 0x8, Type: ObjectProperty)
    void SET_TagsToApplyOnConvertedPawn(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x71e0, Value); } // 0x71e0 (Size: 0x20, Type: StructProperty)
    void SET_TagsToApplyOnConvertingPawn(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x7200, Value); } // 0x7200 (Size: 0x20, Type: StructProperty)
    void SET_PawnSoundLibrary(const USoundLibrary*& Value) { Write<USoundLibrary*>(uintptr_t(this) + 0x7220, Value); } // 0x7220 (Size: 0x8, Type: ObjectProperty)
    void SET_RemoveTagsOnUnconverted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7228, Value); } // 0x7228 (Size: 0x1, Type: BoolProperty)
    void SET_GASToApplyOnConvertedPawn(const UFortAbilitySet*& Value) { Write<UFortAbilitySet*>(uintptr_t(this) + 0x7230, Value); } // 0x7230 (Size: 0x8, Type: ObjectProperty)
    void SET_RemoveGASOnUnconverted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7238, Value); } // 0x7238 (Size: 0x1, Type: BoolProperty)
    void SET_HNDL_EquippedAbilitySet(const FFortAbilitySetHandle& Value) { Write<FFortAbilitySetHandle>(uintptr_t(this) + 0x7240, Value); } // 0x7240 (Size: 0x38, Type: StructProperty)
    void SET_NewTargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x7278, Value); } // 0x7278 (Size: 0x8, Type: ObjectProperty)
    void SET_IdleVOTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x72b0, Value); } // 0x72b0 (Size: 0x8, Type: StructProperty)
    void SET_UseMotionMatchingForPatrols(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x72b8, Value); } // 0x72b8 (Size: 0x28, Type: StructProperty)
    void SET_TagEventVOTrigger(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x72e0, Value); } // 0x72e0 (Size: 0x4, Type: StructProperty)
    void SET_VOSoundBankTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x72e4, Value); } // 0x72e4 (Size: 0x4, Type: StructProperty)
    void SET_bAllowStingers(const bool& Value) { Write<bool>(uintptr_t(this) + 0x72e8, Value); } // 0x72e8 (Size: 0x1, Type: BoolProperty)
    void SET_Tag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x72ec, Value); } // 0x72ec (Size: 0x4, Type: StructProperty)
    void SET_Fort_Athena_Team_HUDInfo(const FFortAthenaTeamHUDInfo& Value) { Write<FFortAthenaTeamHUDInfo>(uintptr_t(this) + 0x72f0, Value); } // 0x72f0 (Size: 0x20, Type: StructProperty)
    void SET_Instigator_Pawn(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x7310, Value); } // 0x7310 (Size: 0x8, Type: ObjectProperty)
    void SET_SlStingerTag(const FSoundLibraryTag& Value) { Write<FSoundLibraryTag>(uintptr_t(this) + 0x7318, Value); } // 0x7318 (Size: 0x4, Type: StructProperty)
    void SET_Context(const USoundLibraryContext*& Value) { Write<USoundLibraryContext*>(uintptr_t(this) + 0x7320, Value); } // 0x7320 (Size: 0x8, Type: ObjectProperty)
    void SET_HNDL_CalculateYawTargetDegreeTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x7328, Value); } // 0x7328 (Size: 0x8, Type: StructProperty)
    void SET_TargetYawDegrees(const double& Value) { Write<double>(uintptr_t(this) + 0x7330, Value); } // 0x7330 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xbd9
class UGAB_ApplyFullBodyHit_NonParticipant_C : public UGAB_GenericApplyFullBodyHit_C
{
public:
};

// Size: 0x7088
class ABP_PlayerPawn_Athena_Phoebe_C : public APlayerPawn_Athena_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x6de0); } // 0x6de0 (Size: 0x8, Type: StructProperty)
    FName AIEvaluator_CharacterLaunchedKeyName() const { return Read<FName>(uintptr_t(this) + 0x6de8); } // 0x6de8 (Size: 0x4, Type: NameProperty)
    bool bUseCosmeticVariants() const { return Read<bool>(uintptr_t(this) + 0x6dec); } // 0x6dec (Size: 0x1, Type: BoolProperty)
    int32_t CosmeticVariantID() const { return Read<int32_t>(uintptr_t(this) + 0x6df0); } // 0x6df0 (Size: 0x4, Type: IntProperty)
    FFortAnimInput_AdjustedAim AdjustedAimOverride() const { return Read<FFortAnimInput_AdjustedAim>(uintptr_t(this) + 0x6df4); } // 0x6df4 (Size: 0x26c, Type: StructProperty)
    FScalableFloat UseAdjustedAimOverride() const { return Read<FScalableFloat>(uintptr_t(this) + 0x7060); } // 0x7060 (Size: 0x28, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x6de0, Value); } // 0x6de0 (Size: 0x8, Type: StructProperty)
    void SET_AIEvaluator_CharacterLaunchedKeyName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x6de8, Value); } // 0x6de8 (Size: 0x4, Type: NameProperty)
    void SET_bUseCosmeticVariants(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6dec, Value); } // 0x6dec (Size: 0x1, Type: BoolProperty)
    void SET_CosmeticVariantID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x6df0, Value); } // 0x6df0 (Size: 0x4, Type: IntProperty)
    void SET_AdjustedAimOverride(const FFortAnimInput_AdjustedAim& Value) { Write<FFortAnimInput_AdjustedAim>(uintptr_t(this) + 0x6df4, Value); } // 0x6df4 (Size: 0x26c, Type: StructProperty)
    void SET_UseAdjustedAimOverride(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x7060, Value); } // 0x7060 (Size: 0x28, Type: StructProperty)
};

// Size: 0xa68
class UGE_DefaultTurboBuildSettings_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Athena_HidingProp_ExitingProp_NoJump_C : public UGameplayEffect
{
public:
};

// Size: 0x28
class UInterface_StickyProjectiles_C : public UInterface
{
public:
};

// Size: 0xa68
class UGE_DudeBro_Vent_C : public UGameplayEffect
{
public:
};

// Size: 0xbac
class UGA_DudeBro_Vent_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    USkeletalMeshComponent* VehicleSkelMesh() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    double GravFloorAltitude() const { return Read<double>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: DoubleProperty)
    double UpwardLaunchVelocity() const { return Read<double>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x8, Type: DoubleProperty)
    TArray<AActor*> VentsHitBeforeLanding() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x10, Type: ArrayProperty)
    int32_t NumVentsToHitForQuest() const { return Read<int32_t>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x4, Type: IntProperty)
    FGameplayTag Tag_to_Check() const { return Read<FGameplayTag>(uintptr_t(this) + 0xba4); } // 0xba4 (Size: 0x4, Type: StructProperty)
    FGameplayTag VentBlocked() const { return Read<FGameplayTag>(uintptr_t(this) + 0xba8); } // 0xba8 (Size: 0x4, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_VehicleSkelMesh(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    void SET_GravFloorAltitude(const double& Value) { Write<double>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: DoubleProperty)
    void SET_UpwardLaunchVelocity(const double& Value) { Write<double>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x8, Type: DoubleProperty)
    void SET_VentsHitBeforeLanding(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x10, Type: ArrayProperty)
    void SET_NumVentsToHitForQuest(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x4, Type: IntProperty)
    void SET_Tag_to_Check(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xba4, Value); } // 0xba4 (Size: 0x4, Type: StructProperty)
    void SET_VentBlocked(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xba8, Value); } // 0xba8 (Size: 0x4, Type: StructProperty)
};

// Size: 0xa68
class UGE_WilliePete_PlayerLaunch_ApplyGC_C : public UGameplayEffect
{
public:
};

// Size: 0x1c
struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
public:
    bool __BoolProperty() const { return Read<bool>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: BoolProperty)
    float __FloatProperty_0() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_1() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_2() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_3() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_4() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_5() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)

    void SET___BoolProperty(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: BoolProperty)
    void SET___FloatProperty_0(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET___FloatProperty_1(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET___FloatProperty_2(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET___FloatProperty_3(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET___FloatProperty_4(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET___FloatProperty_5(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x850
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
public:
    FName __NameProperty_172() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_173() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_174() const { return Read<FName>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: NameProperty)
    FName __NameProperty_175() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    UCurveFloat* __CurveFloat_176() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    uint8_t __EnumProperty_177() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    uint8_t __EnumProperty_178() const { return Read<uint8_t>(uintptr_t(this) + 0x21); } // 0x21 (Size: 0x1, Type: EnumProperty)
    uint8_t __EnumProperty_179() const { return Read<uint8_t>(uintptr_t(this) + 0x22); } // 0x22 (Size: 0x1, Type: EnumProperty)
    TArray<float> __ArrayProperty_180() const { return Read<TArray<float>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    UBlendProfile* __BlendProfile_181() const { return Read<UBlendProfile*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    FName __NameProperty_182() const { return Read<FName>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: NameProperty)
    int32_t __IntProperty_183() const { return Read<int32_t>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0x4, Type: IntProperty)
    FName __NameProperty_184() const { return Read<FName>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x4, Type: NameProperty)
    int32_t __IntProperty_185() const { return Read<int32_t>(uintptr_t(this) + 0x4c); } // 0x4c (Size: 0x4, Type: IntProperty)
    uint8_t __EnumProperty_186() const { return Read<uint8_t>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x1, Type: EnumProperty)
    FName __NameProperty_187() const { return Read<FName>(uintptr_t(this) + 0x54); } // 0x54 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_188() const { return Read<FName>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: NameProperty)
    int32_t __IntProperty_189() const { return Read<int32_t>(uintptr_t(this) + 0x5c); } // 0x5c (Size: 0x4, Type: IntProperty)
    FName __NameProperty_190() const { return Read<FName>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_191() const { return Read<FName>(uintptr_t(this) + 0x64); } // 0x64 (Size: 0x4, Type: NameProperty)
    int32_t __IntProperty_192() const { return Read<int32_t>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x4, Type: IntProperty)
    bool __BoolProperty_193() const { return Read<bool>(uintptr_t(this) + 0x6c); } // 0x6c (Size: 0x1, Type: BoolProperty)
    float __FloatProperty_194() const { return Read<float>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: FloatProperty)
    FInputScaleBiasClampConstants __StructProperty_195() const { return Read<FInputScaleBiasClampConstants>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x2c, Type: StructProperty)
    float __FloatProperty_196() const { return Read<float>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    uint8_t __EnumProperty_197() const { return Read<uint8_t>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x1, Type: EnumProperty)
    bool __BoolProperty_198() const { return Read<bool>(uintptr_t(this) + 0xa5); } // 0xa5 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EAnimGroupRole> __ByteProperty_199() const { return Read<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0xa6); } // 0xa6 (Size: 0x1, Type: ByteProperty)
    FAnimNodeFunctionRef __StructProperty_200() const { return Read<FAnimNodeFunctionRef>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x18, Type: StructProperty)
    FName __NameProperty_201() const { return Read<FName>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_202() const { return Read<FName>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: NameProperty)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess() const { return Read<FAnimSubsystem_PropertyAccess>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x80, Type: StructProperty)
    FAnimSubsystem_Base AnimBlueprintExtension_Base() const { return Read<FAnimSubsystem_Base>(uintptr_t(this) + 0x148); } // 0x148 (Size: 0x40, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler AnimGraphNode_LinkedInputPose_2() const { return Read<FAnimNodeExposedValueHandler>(uintptr_t(this) + 0x1b8); } // 0x1b8 (Size: 0x8, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1c0); } // 0x1c0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedInputPose_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LinkedInputPose() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x280); } // 0x280 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_7() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_6() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_5() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_4() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LayeredBoneBlend_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_4() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x520); } // 0x520 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_LayeredBoneBlend() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x610); } // 0x610 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x700); } // 0x700 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x730); } // 0x730 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x760); } // 0x760 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x790); } // 0x790 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x7c0); } // 0x7c0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x7f0); } // 0x7f0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x820); } // 0x820 (Size: 0x30, Type: StructProperty)

    void SET___NameProperty_172(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_173(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_174(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_175(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET___CurveFloat_176(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x8, Type: ObjectProperty)
    void SET___EnumProperty_177(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET___EnumProperty_178(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x21, Value); } // 0x21 (Size: 0x1, Type: EnumProperty)
    void SET___EnumProperty_179(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x22, Value); } // 0x22 (Size: 0x1, Type: EnumProperty)
    void SET___ArrayProperty_180(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
    void SET___BlendProfile_181(const UBlendProfile*& Value) { Write<UBlendProfile*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
    void SET___NameProperty_182(const FName& Value) { Write<FName>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: NameProperty)
    void SET___IntProperty_183(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0x4, Type: IntProperty)
    void SET___NameProperty_184(const FName& Value) { Write<FName>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x4, Type: NameProperty)
    void SET___IntProperty_185(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4c, Value); } // 0x4c (Size: 0x4, Type: IntProperty)
    void SET___EnumProperty_186(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x1, Type: EnumProperty)
    void SET___NameProperty_187(const FName& Value) { Write<FName>(uintptr_t(this) + 0x54, Value); } // 0x54 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_188(const FName& Value) { Write<FName>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: NameProperty)
    void SET___IntProperty_189(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5c, Value); } // 0x5c (Size: 0x4, Type: IntProperty)
    void SET___NameProperty_190(const FName& Value) { Write<FName>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_191(const FName& Value) { Write<FName>(uintptr_t(this) + 0x64, Value); } // 0x64 (Size: 0x4, Type: NameProperty)
    void SET___IntProperty_192(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x4, Type: IntProperty)
    void SET___BoolProperty_193(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6c, Value); } // 0x6c (Size: 0x1, Type: BoolProperty)
    void SET___FloatProperty_194(const float& Value) { Write<float>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: FloatProperty)
    void SET___StructProperty_195(const FInputScaleBiasClampConstants& Value) { Write<FInputScaleBiasClampConstants>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x2c, Type: StructProperty)
    void SET___FloatProperty_196(const float& Value) { Write<float>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: FloatProperty)
    void SET___EnumProperty_197(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x1, Type: EnumProperty)
    void SET___BoolProperty_198(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa5, Value); } // 0xa5 (Size: 0x1, Type: BoolProperty)
    void SET___ByteProperty_199(const TEnumAsByte<EAnimGroupRole>& Value) { Write<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0xa6, Value); } // 0xa6 (Size: 0x1, Type: ByteProperty)
    void SET___StructProperty_200(const FAnimNodeFunctionRef& Value) { Write<FAnimNodeFunctionRef>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x18, Type: StructProperty)
    void SET___NameProperty_201(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_202(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: NameProperty)
    void SET_AnimBlueprintExtension_PropertyAccess(const FAnimSubsystem_PropertyAccess& Value) { Write<FAnimSubsystem_PropertyAccess>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x80, Type: StructProperty)
    void SET_AnimBlueprintExtension_Base(const FAnimSubsystem_Base& Value) { Write<FAnimSubsystem_Base>(uintptr_t(this) + 0x148, Value); } // 0x148 (Size: 0x40, Type: StructProperty)
    void SET_AnimGraphNode_Root_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_LinkedInputPose_2(const FAnimNodeExposedValueHandler& Value) { Write<FAnimNodeExposedValueHandler>(uintptr_t(this) + 0x1b8, Value); } // 0x1b8 (Size: 0x8, Type: StructProperty)
    void SET_AnimGraphNode_Root_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1c0, Value); } // 0x1c0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_LinkedInputPose_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_Root_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_LinkedInputPose(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x280, Value); } // 0x280 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_7(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_6(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_5(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_4(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_LayeredBoneBlend_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_4(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x520, Value); } // 0x520 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_LayeredBoneBlend(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x610, Value); } // 0x610 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x700, Value); } // 0x700 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x730, Value); } // 0x730 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SaveCachedPose_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x760, Value); } // 0x760 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x790, Value); } // 0x790 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x7c0, Value); } // 0x7c0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SaveCachedPose(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x7f0, Value); } // 0x7f0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_Root(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x820, Value); } // 0x820 (Size: 0x30, Type: StructProperty)
};

// Size: 0xa08
class AGCNL_EnvCampFire_Doused_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    float Fade_Doused_Smoke_Fade_50A77D974140FDA04967E2BABB987458() const { return Read<float>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Fade_Doused_Smoke__Direction_50A77D974140FDA04967E2BABB987458() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Fade_Doused_Smoke() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat Row_Duration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x28, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_Fade_Doused_Smoke_Fade_50A77D974140FDA04967E2BABB987458(const float& Value) { Write<float>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    void SET_Fade_Doused_Smoke__Direction_50A77D974140FDA04967E2BABB987458(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4, Value); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    void SET_Fade_Doused_Smoke(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Row_Duration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x28, Type: StructProperty)
};

// Size: 0xa20
class AGCNL_EnvCampFire_Stoke_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    FScalableFloat Row_TickInterval() const { return Read<FScalableFloat>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x28, Type: StructProperty)
    FScalableFloat Row_MaxHeals() const { return Read<FScalableFloat>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x28, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_Row_TickInterval(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x28, Type: StructProperty)
    void SET_Row_MaxHeals(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x28, Type: StructProperty)
};

// Size: 0x9d9
class AGCNL_Athena_SCMachine_Redux_Active_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    UFXSystemComponent* SpawnWarmupFXSystemComponent() const { return Read<UFXSystemComponent*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    bool Enhanced_Resurrection() const { return Read<bool>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_SpawnWarmupFXSystemComponent(const UFXSystemComponent*& Value) { Write<UFXSystemComponent*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Enhanced_Resurrection(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x710
class UAthenaMinimapTeamIndicators_C : public UFortMiniMapTeamIndicators
{
public:
};

// Size: 0x330
class UMinimapChallengeIndicators_C : public UFortMiniMapChallengeIndicators
{
public:
};

// Size: 0x9c8
class AGCN_Loop_SnowFlakes_CameraAttached_C : public AFortGameplayCueNotify_Loop
{
public:
};

// Size: 0x610
class AB_AthenaPlayerMarker_WithCustomization_C : public AB_AthenaMapMarkerBase_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x8, Type: StructProperty)
    UObject* TopperInstance() const { return Read<UObject*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    FTransform TopperTransform() const { return Read<FTransform>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x60, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x8, Type: StructProperty)
    void SET_TopperInstance(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    void SET_TopperTransform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x60, Type: StructProperty)
};

// Size: 0x598
class AB_AthenaMapMarkerBase_C : public AFortPlayerMarkerBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* PingMarkerProto() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_Target() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    float OnProtoMarkerPlaced_RampPow_83EEC58A4783B077FB03728C433B4B7E() const { return Read<float>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x4, Type: FloatProperty)
    float OnProtoMarkerPlaced_Pinch_83EEC58A4783B077FB03728C433B4B7E() const { return Read<float>(uintptr_t(this) + 0x494); } // 0x494 (Size: 0x4, Type: FloatProperty)
    float OnProtoMarkerPlaced_Glow_83EEC58A4783B077FB03728C433B4B7E() const { return Read<float>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> OnProtoMarkerPlaced__Direction_83EEC58A4783B077FB03728C433B4B7E() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x49c); } // 0x49c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* OnProtoMarkerPlaced() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    bool bUseProtoMarker() const { return Read<bool>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x1, Type: BoolProperty)
    UMaterialInstanceDynamic* MIDProtoMarker() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    FFortWorldMarkerData MarkerData() const { return Read<FFortWorldMarkerData>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0xe0, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: StructProperty)
    void SET_PingMarkerProto(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_SM_Target(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_OnProtoMarkerPlaced_RampPow_83EEC58A4783B077FB03728C433B4B7E(const float& Value) { Write<float>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x4, Type: FloatProperty)
    void SET_OnProtoMarkerPlaced_Pinch_83EEC58A4783B077FB03728C433B4B7E(const float& Value) { Write<float>(uintptr_t(this) + 0x494, Value); } // 0x494 (Size: 0x4, Type: FloatProperty)
    void SET_OnProtoMarkerPlaced_Glow_83EEC58A4783B077FB03728C433B4B7E(const float& Value) { Write<float>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x4, Type: FloatProperty)
    void SET_OnProtoMarkerPlaced__Direction_83EEC58A4783B077FB03728C433B4B7E(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x49c, Value); } // 0x49c (Size: 0x1, Type: ByteProperty)
    void SET_OnProtoMarkerPlaced(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_bUseProtoMarker(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x1, Type: BoolProperty)
    void SET_MIDProtoMarker(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_MarkerData(const FFortWorldMarkerData& Value) { Write<FFortWorldMarkerData>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0xe0, Type: StructProperty)
};

// Size: 0x15c8
class AAthena_GameMode_C : public AFortGameModeBR
{
public:
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x15c0); } // 0x15c0 (Size: 0x8, Type: ObjectProperty)

    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x15c0, Value); } // 0x15c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x440
class ABP_SafeZoneStorm_C : public AFortSafeZoneStorm
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* SM_CloudBottomBlend() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_CloudRing_Mobile() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_CloudRingTopBlend() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_Storm_ScreenEffect() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    UPostProcessComponent* PostProcess() const { return Read<UPostProcessComponent*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    UBoxComponent* Box() const { return Read<UBoxComponent*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* CloudsOuterRing() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh10() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh9() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh8() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh7() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh6() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh5() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh4() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh3() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh2() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh1() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain16() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain15() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain1() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain13() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain12() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain11() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain10() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain9() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain8() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain7() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain6() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain5() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain4() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain3() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain2() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain14() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormRings() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StormQuadMain() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    bool MobileMode() const { return Read<bool>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x1, Type: BoolProperty)
    bool ShowStorm() const { return Read<bool>(uintptr_t(this) + 0x401); } // 0x401 (Size: 0x1, Type: BoolProperty)
    double StormSize() const { return Read<double>(uintptr_t(this) + 0x408); } // 0x408 (Size: 0x8, Type: DoubleProperty)
    double StormBias() const { return Read<double>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x8, Type: DoubleProperty)
    FVector StormCenter() const { return Read<FVector>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x18, Type: StructProperty)
    bool UseNewStorm() const { return Read<bool>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x1, Type: BoolProperty)
    bool UseSeason11Storm() const { return Read<bool>(uintptr_t(this) + 0x431); } // 0x431 (Size: 0x1, Type: BoolProperty)
    bool UseVolumetricStorm() const { return Read<bool>(uintptr_t(this) + 0x432); } // 0x432 (Size: 0x1, Type: BoolProperty)
    UAsyncAction_StartListeningToStatefulEvent* GamePhaseUpdatedAsyncTask() const { return Read<UAsyncAction_StartListeningToStatefulEvent*>(uintptr_t(this) + 0x438); } // 0x438 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: StructProperty)
    void SET_SM_CloudBottomBlend(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_SM_CloudRing_Mobile(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_SM_CloudRingTopBlend(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    void SET_SM_Storm_ScreenEffect(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    void SET_PostProcess(const UPostProcessComponent*& Value) { Write<UPostProcessComponent*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Box(const UBoxComponent*& Value) { Write<UBoxComponent*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_CloudsOuterRing(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMesh10(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMesh9(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMesh8(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMesh7(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMesh6(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMesh5(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMesh4(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMesh3(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMesh2(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMesh1(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain16(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain15(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain1(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain13(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain12(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain11(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain10(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain9(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain8(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain7(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain6(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain5(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain4(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain3(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain2(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain14(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_StormRings(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    void SET_StormQuadMain(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x8, Type: ObjectProperty)
    void SET_MobileMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x1, Type: BoolProperty)
    void SET_ShowStorm(const bool& Value) { Write<bool>(uintptr_t(this) + 0x401, Value); } // 0x401 (Size: 0x1, Type: BoolProperty)
    void SET_StormSize(const double& Value) { Write<double>(uintptr_t(this) + 0x408, Value); } // 0x408 (Size: 0x8, Type: DoubleProperty)
    void SET_StormBias(const double& Value) { Write<double>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x8, Type: DoubleProperty)
    void SET_StormCenter(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x18, Type: StructProperty)
    void SET_UseNewStorm(const bool& Value) { Write<bool>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x1, Type: BoolProperty)
    void SET_UseSeason11Storm(const bool& Value) { Write<bool>(uintptr_t(this) + 0x431, Value); } // 0x431 (Size: 0x1, Type: BoolProperty)
    void SET_UseVolumetricStorm(const bool& Value) { Write<bool>(uintptr_t(this) + 0x432, Value); } // 0x432 (Size: 0x1, Type: BoolProperty)
    void SET_GamePhaseUpdatedAsyncTask(const UAsyncAction_StartListeningToStatefulEvent*& Value) { Write<UAsyncAction_StartListeningToStatefulEvent*>(uintptr_t(this) + 0x438, Value); } // 0x438 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x640
class UW_PinnedQuestMarkerIndicator_C : public UAthenaMarkedActorIndicator
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x8, Type: StructProperty)
    UImage* Pin() const { return Read<UImage*>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ShowHide() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x8, Type: StructProperty)
    void SET_Pin(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x8, Type: ObjectProperty)
    void SET_ShowHide(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x870
class USquadMarker_C : public UAthenaSquadIndicator
{
public:
    UFortHUDElementWrapper_C* FortHUDElementWrapper() const { return Read<UFortHUDElementWrapper_C*>(uintptr_t(this) + 0x868); } // 0x868 (Size: 0x8, Type: ObjectProperty)

    void SET_FortHUDElementWrapper(const UFortHUDElementWrapper_C*& Value) { Write<UFortHUDElementWrapper_C*>(uintptr_t(this) + 0x868, Value); } // 0x868 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb8
class UEmptyBehavior_C : public UHUDWidgetBehavior
{
public:
};

// Size: 0xa68
class UGE_ColdBreath_V2_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Athena_Lockout_C : public UGameplayEffect
{
public:
};

// Size: 0xb80
class UGA_Athena_Lockout_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    FTimerHandle Timer_LockoutFailsafe() const { return Read<FTimerHandle>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: StructProperty)
    double LockoutFailsafeTime() const { return Read<double>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_Timer_LockoutFailsafe(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: StructProperty)
    void SET_LockoutFailsafeTime(const double& Value) { Write<double>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x348
class AB_FP_ShieldBreak_C : public ANiagaraLensEffectBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: StructProperty)
};

// Size: 0xa68
class UGE_Patrolling_C : public UGameplayEffect
{
public:
};

// Size: 0x48
class UNavFilter_Phoebe_C : public UFortNavigationFilter
{
public:
};

// Size: 0xb70
class UGA_Athena_HidingProp_GettingInProp_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
};

// Size: 0x28
class UBPI_NonParticipant_C : public UInterface
{
public:
};

// Size: 0xa68
class UGE_NPC_Status_Stressed_Cooldown_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_Challenged_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_Status_Stressed_Infinite_C : public UGameplayEffect
{
public:
};

// Size: 0x48
class UNavFilter_NPC_Base_C : public UFortNavigationFilter
{
public:
};

// Size: 0xa68
class UGE_Quest_Converted_HireNPC_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Athena_Disguise_Remove_C : public UGameplayEffect
{
public:
};

// Size: 0xbe9
class AAthenaCreativeSpawnDrop_C : public AFortAthenaCreativeSupplyDrop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb58); } // 0xb58 (Size: 0x8, Type: StructProperty)
    UAudioComponent* treasure_pinata_loop_Cue() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xb60); } // 0xb60 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* LlamaStaticMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: ObjectProperty)
    UBoxComponent* BoxCollision() const { return Read<UBoxComponent*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    UProjectileMovementComponent* ProjectileMovement() const { return Read<UProjectileMovementComponent*>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    FName LootTableName() const { return Read<FName>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x4, Type: NameProperty)
    FVector LootSpawnOffset() const { return Read<FVector>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x18, Type: StructProperty)
    UParticleSystem* LlamaLootFX() const { return Read<UParticleSystem*>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x8, Type: ObjectProperty)
    FName FXSocketName() const { return Read<FName>(uintptr_t(this) + 0xba8); } // 0xba8 (Size: 0x4, Type: NameProperty)
    USoundBase* Sound_Looted() const { return Read<USoundBase*>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Sound_Destroyed() const { return Read<USoundBase*>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Sound_Ambient() const { return Read<USoundBase*>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x8, Type: ObjectProperty)
    bool Looted() const { return Read<bool>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x1, Type: BoolProperty)
    AFortPlayerController* ControllerWhoOpenedLlama() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0xbd0); } // 0xbd0 (Size: 0x8, Type: ObjectProperty)
    FName ObjBackendName() const { return Read<FName>(uintptr_t(this) + 0xbd8); } // 0xbd8 (Size: 0x4, Type: NameProperty)
    UFortQuestItemDefinition* QuestItem() const { return Read<UFortQuestItemDefinition*>(uintptr_t(this) + 0xbe0); } // 0xbe0 (Size: 0x8, Type: ObjectProperty)
    bool CreativeMode() const { return Read<bool>(uintptr_t(this) + 0xbe8); } // 0xbe8 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb58, Value); } // 0xb58 (Size: 0x8, Type: StructProperty)
    void SET_treasure_pinata_loop_Cue(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xb60, Value); } // 0xb60 (Size: 0x8, Type: ObjectProperty)
    void SET_LlamaStaticMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: ObjectProperty)
    void SET_BoxCollision(const UBoxComponent*& Value) { Write<UBoxComponent*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_ProjectileMovement(const UProjectileMovementComponent*& Value) { Write<UProjectileMovementComponent*>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    void SET_LootTableName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x4, Type: NameProperty)
    void SET_LootSpawnOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x18, Type: StructProperty)
    void SET_LlamaLootFX(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x8, Type: ObjectProperty)
    void SET_FXSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xba8, Value); } // 0xba8 (Size: 0x4, Type: NameProperty)
    void SET_Sound_Looted(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x8, Type: ObjectProperty)
    void SET_Sound_Destroyed(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x8, Type: ObjectProperty)
    void SET_Sound_Ambient(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x8, Type: ObjectProperty)
    void SET_Looted(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x1, Type: BoolProperty)
    void SET_ControllerWhoOpenedLlama(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0xbd0, Value); } // 0xbd0 (Size: 0x8, Type: ObjectProperty)
    void SET_ObjBackendName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xbd8, Value); } // 0xbd8 (Size: 0x4, Type: NameProperty)
    void SET_QuestItem(const UFortQuestItemDefinition*& Value) { Write<UFortQuestItemDefinition*>(uintptr_t(this) + 0xbe0, Value); } // 0xbe0 (Size: 0x8, Type: ObjectProperty)
    void SET_CreativeMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbe8, Value); } // 0xbe8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x98
class UAthenaInventoryDragDrop_C : public UDragDropOperation
{
public:
    bool SplitTheStack() const { return Read<bool>(uintptr_t(this) + 0x90); } // 0x90 (Size: 0x1, Type: BoolProperty)
    bool bIsFromCreativeInventory() const { return Read<bool>(uintptr_t(this) + 0x91); } // 0x91 (Size: 0x1, Type: BoolProperty)
    int32_t InstigatorSlotIndex() const { return Read<int32_t>(uintptr_t(this) + 0x94); } // 0x94 (Size: 0x4, Type: IntProperty)

    void SET_SplitTheStack(const bool& Value) { Write<bool>(uintptr_t(this) + 0x90, Value); } // 0x90 (Size: 0x1, Type: BoolProperty)
    void SET_bIsFromCreativeInventory(const bool& Value) { Write<bool>(uintptr_t(this) + 0x91, Value); } // 0x91 (Size: 0x1, Type: BoolProperty)
    void SET_InstigatorSlotIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x94, Value); } // 0x94 (Size: 0x4, Type: IntProperty)
};

// Size: 0xa68
class UGE_Athena_EnhancedResurrection_Shield_C : public UGameplayEffect
{
public:
};

// Size: 0x610
class AFortVolumeManager_BP_C : public AFortVolumeManager
{
public:
};

// Size: 0x378
class UItemInfoWidget_C : public UFortItemInfoWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: StructProperty)
    UImage* RarityGlow() const { return Read<UImage*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: StructProperty)
    void SET_RarityGlow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xef8
class UGA_NPC_Parent_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    AFortAIPawn* NPC_ActivatingFortAIPawn() const { return Read<AFortAIPawn*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EFortMovementUrgency> NPC_InitialMovementUrgency() const { return Read<TEnumAsByte<EFortMovementUrgency>>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x1, Type: ByteProperty)
    bool NPC_DebugAbility() const { return Read<bool>(uintptr_t(this) + 0xb79); } // 0xb79 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer NPC_IgnoreDamageAndOnlyDoKnockbackIfTheseAbilitiesAreActive() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x20, Type: StructProperty)
    bool NPC_DebugFreezeFrameEnabled() const { return Read<bool>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x1, Type: BoolProperty)
    bool NPC_DebugFreezeFrameOnlyWhenAbilityTargetHit() const { return Read<bool>(uintptr_t(this) + 0xba1); } // 0xba1 (Size: 0x1, Type: BoolProperty)
    bool NPC_DebugFreezeFrameOnlyWhenWeHaveSomeTarget() const { return Read<bool>(uintptr_t(this) + 0xba2); } // 0xba2 (Size: 0x1, Type: BoolProperty)
    bool NPC_DamageHitAbilityTargetDuringThisAbilityActivation() const { return Read<bool>(uintptr_t(this) + 0xba3); } // 0xba3 (Size: 0x1, Type: BoolProperty)
    bool NPC_DebugFreezeFrameShouldDrawCapsules() const { return Read<bool>(uintptr_t(this) + 0xba4); } // 0xba4 (Size: 0x1, Type: BoolProperty)
    TArray<AActor*> NPC_DamageActorsWeHaveHitDuringThisAbilityActivation() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0xba8); } // 0xba8 (Size: 0x10, Type: ArrayProperty)
    bool NPC_CanActivateAbility_AbilityTargetTeamAffiliationCanBeNeutral() const { return Read<bool>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x1, Type: BoolProperty)
    bool NPC_CanActivateAbility_AbilityTargetTeamAffiliationCanBeFriendly() const { return Read<bool>(uintptr_t(this) + 0xbb9); } // 0xbb9 (Size: 0x1, Type: BoolProperty)
    bool NPC_CanActivateAbility_AbilityTargetTeamAffiliationCanBeHostile() const { return Read<bool>(uintptr_t(this) + 0xbba); } // 0xbba (Size: 0x1, Type: BoolProperty)
    double NPC_CanActivateAbility_MaxTargetZDistanceBelow() const { return Read<double>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x8, Type: DoubleProperty)
    double NPC_CanActivateAbility_MaxTargetZDistanceAbove() const { return Read<double>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x8, Type: DoubleProperty)
    double NPC_CanActivateAbility_MaxTargetZDistanceAbove_ForIntentionalFailedAttack() const { return Read<double>(uintptr_t(this) + 0xbd0); } // 0xbd0 (Size: 0x8, Type: DoubleProperty)
    TArray<AActor*> BuildingTargetingHitActors() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0xbd8); } // 0xbd8 (Size: 0x10, Type: ArrayProperty)
    FScalableFloat NPC_CanBuildMovementFrustrationAtAllHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbe8); } // 0xbe8 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_CanBuildGoalFrustrationAtAllHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x28, Type: StructProperty)
    FGameplayTagContainer TC_NPC_FrustrationTagsToClearForGoals() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x20, Type: StructProperty)
    TEnumAsByte<Enum_NPC_AlertLevel> NPC_AlertLevelGoalIsFortPawn() const { return Read<TEnumAsByte<Enum_NPC_AlertLevel>>(uintptr_t(this) + 0xc58); } // 0xc58 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<Enum_NPC_AlertLevel> NPC_AlertLevelGoalIsOther() const { return Read<TEnumAsByte<Enum_NPC_AlertLevel>>(uintptr_t(this) + 0xc59); } // 0xc59 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<Enum_NPC_AlertLevel> NPC_AlertLevelGoalIsNotValid() const { return Read<TEnumAsByte<Enum_NPC_AlertLevel>>(uintptr_t(this) + 0xc5a); } // 0xc5a (Size: 0x1, Type: ByteProperty)
    FScalableFloat NPC_DamageKnockbackVelocityHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_DamageKnockbackVerticalAngleHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_DamageKnockbackMinimumYawValueHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xcb0); } // 0xcb0 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_DamageCanAttackDBNOPlayersHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xcd8); } // 0xcd8 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_DamageKnockbackVelocityVehicleHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd00); } // 0xd00 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_DamageKnockbackVerticalAngleVehicleHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd28); } // 0xd28 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_DamageKnockbackMinimumYawValueVehicleHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd50); } // 0xd50 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_DamageChanceToEjectFromVehicleHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd78); } // 0xd78 (Size: 0x28, Type: StructProperty)
    FGameplayTag DestroyBuildingGC() const { return Read<FGameplayTag>(uintptr_t(this) + 0xda0); } // 0xda0 (Size: 0x4, Type: StructProperty)
    UClass* DestroyBuildingGE() const { return Read<UClass*>(uintptr_t(this) + 0xda8); } // 0xda8 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer TC_NPC_FrustrationTagsToClearForMovement() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xdb0); } // 0xdb0 (Size: 0x20, Type: StructProperty)
    FGameplayTag TC_NPC_FrustrationBuildDueToGoal() const { return Read<FGameplayTag>(uintptr_t(this) + 0xdd0); } // 0xdd0 (Size: 0x4, Type: StructProperty)
    FGameplayTag TC_NPC_FrustrationBuildDueToMovement() const { return Read<FGameplayTag>(uintptr_t(this) + 0xdd4); } // 0xdd4 (Size: 0x4, Type: StructProperty)
    FGameplayTagQuery TQ_NPC_RequirementsToBuildFrustrationDueToGoal() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xdd8); } // 0xdd8 (Size: 0x48, Type: StructProperty)
    FGameplayTagQuery TQ_NPC_RequirementsToBuildFrustrationDueToMovement() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0xe20); } // 0xe20 (Size: 0x48, Type: StructProperty)
    FScalableFloat NPC_BodyBumpBuildingsWhenBuildingMovementFrustrationHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe68); } // 0xe68 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_FrustrationBodyBumpOnlyDestroyPlayerBuildingsHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe90); } // 0xe90 (Size: 0x28, Type: StructProperty)
    FGameplayTag TC_NPC_EffectContainer_BodyBumpBuildingsWhenBuildingMovementFrustration() const { return Read<FGameplayTag>(uintptr_t(this) + 0xeb8); } // 0xeb8 (Size: 0x4, Type: StructProperty)
    FGameplayAbilityTargetDataHandle BuildingTargetingTargetData() const { return Read<FGameplayAbilityTargetDataHandle>(uintptr_t(this) + 0xec0); } // 0xec0 (Size: 0x28, Type: StructProperty)
    FGameplayTag BuildingTargetingApplicationTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xee8); } // 0xee8 (Size: 0x4, Type: StructProperty)
    FGameplayTag TC_BuildingTypePlayer() const { return Read<FGameplayTag>(uintptr_t(this) + 0xeec); } // 0xeec (Size: 0x4, Type: StructProperty)
    UClass* GE_NPC_MMR_Scaling_AbilityCooldown() const { return Read<UClass*>(uintptr_t(this) + 0xef0); } // 0xef0 (Size: 0x8, Type: ClassProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_NPC_ActivatingFortAIPawn(const AFortAIPawn*& Value) { Write<AFortAIPawn*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_NPC_InitialMovementUrgency(const TEnumAsByte<EFortMovementUrgency>& Value) { Write<TEnumAsByte<EFortMovementUrgency>>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x1, Type: ByteProperty)
    void SET_NPC_DebugAbility(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb79, Value); } // 0xb79 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_IgnoreDamageAndOnlyDoKnockbackIfTheseAbilitiesAreActive(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x20, Type: StructProperty)
    void SET_NPC_DebugFreezeFrameEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_DebugFreezeFrameOnlyWhenAbilityTargetHit(const bool& Value) { Write<bool>(uintptr_t(this) + 0xba1, Value); } // 0xba1 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_DebugFreezeFrameOnlyWhenWeHaveSomeTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0xba2, Value); } // 0xba2 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_DamageHitAbilityTargetDuringThisAbilityActivation(const bool& Value) { Write<bool>(uintptr_t(this) + 0xba3, Value); } // 0xba3 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_DebugFreezeFrameShouldDrawCapsules(const bool& Value) { Write<bool>(uintptr_t(this) + 0xba4, Value); } // 0xba4 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_DamageActorsWeHaveHitDuringThisAbilityActivation(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0xba8, Value); } // 0xba8 (Size: 0x10, Type: ArrayProperty)
    void SET_NPC_CanActivateAbility_AbilityTargetTeamAffiliationCanBeNeutral(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_CanActivateAbility_AbilityTargetTeamAffiliationCanBeFriendly(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbb9, Value); } // 0xbb9 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_CanActivateAbility_AbilityTargetTeamAffiliationCanBeHostile(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbba, Value); } // 0xbba (Size: 0x1, Type: BoolProperty)
    void SET_NPC_CanActivateAbility_MaxTargetZDistanceBelow(const double& Value) { Write<double>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x8, Type: DoubleProperty)
    void SET_NPC_CanActivateAbility_MaxTargetZDistanceAbove(const double& Value) { Write<double>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x8, Type: DoubleProperty)
    void SET_NPC_CanActivateAbility_MaxTargetZDistanceAbove_ForIntentionalFailedAttack(const double& Value) { Write<double>(uintptr_t(this) + 0xbd0, Value); } // 0xbd0 (Size: 0x8, Type: DoubleProperty)
    void SET_BuildingTargetingHitActors(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0xbd8, Value); } // 0xbd8 (Size: 0x10, Type: ArrayProperty)
    void SET_NPC_CanBuildMovementFrustrationAtAllHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbe8, Value); } // 0xbe8 (Size: 0x28, Type: StructProperty)
    void SET_NPC_CanBuildGoalFrustrationAtAllHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x28, Type: StructProperty)
    void SET_TC_NPC_FrustrationTagsToClearForGoals(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x20, Type: StructProperty)
    void SET_NPC_AlertLevelGoalIsFortPawn(const TEnumAsByte<Enum_NPC_AlertLevel>& Value) { Write<TEnumAsByte<Enum_NPC_AlertLevel>>(uintptr_t(this) + 0xc58, Value); } // 0xc58 (Size: 0x1, Type: ByteProperty)
    void SET_NPC_AlertLevelGoalIsOther(const TEnumAsByte<Enum_NPC_AlertLevel>& Value) { Write<TEnumAsByte<Enum_NPC_AlertLevel>>(uintptr_t(this) + 0xc59, Value); } // 0xc59 (Size: 0x1, Type: ByteProperty)
    void SET_NPC_AlertLevelGoalIsNotValid(const TEnumAsByte<Enum_NPC_AlertLevel>& Value) { Write<TEnumAsByte<Enum_NPC_AlertLevel>>(uintptr_t(this) + 0xc5a, Value); } // 0xc5a (Size: 0x1, Type: ByteProperty)
    void SET_NPC_DamageKnockbackVelocityHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x28, Type: StructProperty)
    void SET_NPC_DamageKnockbackVerticalAngleHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x28, Type: StructProperty)
    void SET_NPC_DamageKnockbackMinimumYawValueHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xcb0, Value); } // 0xcb0 (Size: 0x28, Type: StructProperty)
    void SET_NPC_DamageCanAttackDBNOPlayersHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xcd8, Value); } // 0xcd8 (Size: 0x28, Type: StructProperty)
    void SET_NPC_DamageKnockbackVelocityVehicleHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd00, Value); } // 0xd00 (Size: 0x28, Type: StructProperty)
    void SET_NPC_DamageKnockbackVerticalAngleVehicleHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd28, Value); } // 0xd28 (Size: 0x28, Type: StructProperty)
    void SET_NPC_DamageKnockbackMinimumYawValueVehicleHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd50, Value); } // 0xd50 (Size: 0x28, Type: StructProperty)
    void SET_NPC_DamageChanceToEjectFromVehicleHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd78, Value); } // 0xd78 (Size: 0x28, Type: StructProperty)
    void SET_DestroyBuildingGC(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xda0, Value); } // 0xda0 (Size: 0x4, Type: StructProperty)
    void SET_DestroyBuildingGE(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xda8, Value); } // 0xda8 (Size: 0x8, Type: ClassProperty)
    void SET_TC_NPC_FrustrationTagsToClearForMovement(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xdb0, Value); } // 0xdb0 (Size: 0x20, Type: StructProperty)
    void SET_TC_NPC_FrustrationBuildDueToGoal(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xdd0, Value); } // 0xdd0 (Size: 0x4, Type: StructProperty)
    void SET_TC_NPC_FrustrationBuildDueToMovement(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xdd4, Value); } // 0xdd4 (Size: 0x4, Type: StructProperty)
    void SET_TQ_NPC_RequirementsToBuildFrustrationDueToGoal(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xdd8, Value); } // 0xdd8 (Size: 0x48, Type: StructProperty)
    void SET_TQ_NPC_RequirementsToBuildFrustrationDueToMovement(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0xe20, Value); } // 0xe20 (Size: 0x48, Type: StructProperty)
    void SET_NPC_BodyBumpBuildingsWhenBuildingMovementFrustrationHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe68, Value); } // 0xe68 (Size: 0x28, Type: StructProperty)
    void SET_NPC_FrustrationBodyBumpOnlyDestroyPlayerBuildingsHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe90, Value); } // 0xe90 (Size: 0x28, Type: StructProperty)
    void SET_TC_NPC_EffectContainer_BodyBumpBuildingsWhenBuildingMovementFrustration(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xeb8, Value); } // 0xeb8 (Size: 0x4, Type: StructProperty)
    void SET_BuildingTargetingTargetData(const FGameplayAbilityTargetDataHandle& Value) { Write<FGameplayAbilityTargetDataHandle>(uintptr_t(this) + 0xec0, Value); } // 0xec0 (Size: 0x28, Type: StructProperty)
    void SET_BuildingTargetingApplicationTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xee8, Value); } // 0xee8 (Size: 0x4, Type: StructProperty)
    void SET_TC_BuildingTypePlayer(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xeec, Value); } // 0xeec (Size: 0x4, Type: StructProperty)
    void SET_GE_NPC_MMR_Scaling_AbilityCooldown(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xef0, Value); } // 0xef0 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x3f8
class UWBP_VehicleSpeedoMeter_Wrapper_C : public UFortMobileHUDElement
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: StructProperty)
    UWBP_VehicleSpeedoMeter_C* WBP_VehicleSpeedoMeter() const { return Read<UWBP_VehicleSpeedoMeter_C*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    AFortAthenaVehicle* CachedVehicle() const { return Read<AFortAthenaVehicle*>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerController* ChachedPlayerController() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: StructProperty)
    void SET_WBP_VehicleSpeedoMeter(const UWBP_VehicleSpeedoMeter_C*& Value) { Write<UWBP_VehicleSpeedoMeter_C*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedVehicle(const AFortAthenaVehicle*& Value) { Write<AFortAthenaVehicle*>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    void SET_ChachedPlayerController(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x4d8
class UWBP_VehicleSpeedoMeter_Proxy_C : public UFortMobileHUDElementProxy
{
public:
    UCommonTextBlock* Text_Warning_1() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_ItemName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x458); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_FuelMin() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x460); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_FuelMax() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x468); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_FuelInfinite() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x470); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    UOverlay* OverlayBoostMeter() const { return Read<UOverlay*>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Speedometer() const { return Read<UOverlay*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Action() const { return Read<UOverlay*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UCommonNumericTextBlock* NumericText_Speed() const { return Read<UCommonNumericTextBlock*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_WarningIcon_1() const { return Read<UImage*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_WarningIcon() const { return Read<UImage*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Speedometer() const { return Read<UImage*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_RoundCard_Bolt_1() const { return Read<UImage*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_MeterIconGlow() const { return Read<UImage*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_MeterIcon() const { return Read<UImage*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Meter() const { return Read<UImage*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_BoostMeter() const { return Read<UImage*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)

    void SET_Text_Warning_1(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_ItemName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x458, Value); } // 0x458 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_FuelMin(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x460, Value); } // 0x460 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_FuelMax(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x468, Value); } // 0x468 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_FuelInfinite(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x470, Value); } // 0x470 (Size: 0x8, Type: ObjectProperty)
    void SET_OverlayBoostMeter(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Speedometer(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Action(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_NumericText_Speed(const UCommonNumericTextBlock*& Value) { Write<UCommonNumericTextBlock*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_WarningIcon_1(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_WarningIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Speedometer(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_RoundCard_Bolt_1(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_MeterIconGlow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_MeterIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Meter(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_BoostMeter(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x588
class UWBP_Vehicle_FuelGauge_C : public UFortVehicleFuelGauge
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_FuelMin() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x520); } // 0x520 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_FuelMax() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_FuelInfinite() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    UImage* RefuellingShine() const { return Read<UImage*>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x8, Type: ObjectProperty)
    UImage* RefuellingCircle() const { return Read<UImage*>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x8, Type: ObjectProperty)
    UImage* RefuellingBacking() const { return Read<UImage*>(uintptr_t(this) + 0x548); } // 0x548 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_ExtensionSlot() const { return Read<UOverlay*>(uintptr_t(this) + 0x550); } // 0x550 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_MeterIcon() const { return Read<UImage*>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Meter() const { return Read<UImage*>(uintptr_t(this) + 0x560); } // 0x560 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_BatteryIcon() const { return Read<UImage*>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_ReFuelling() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_RefuellingScaleLoop() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_ReFuelling_Reset() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: StructProperty)
    void SET_Text_FuelMin(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x520, Value); } // 0x520 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_FuelMax(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_FuelInfinite(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    void SET_RefuellingShine(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x8, Type: ObjectProperty)
    void SET_RefuellingCircle(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x8, Type: ObjectProperty)
    void SET_RefuellingBacking(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x548, Value); } // 0x548 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_ExtensionSlot(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x550, Value); } // 0x550 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_MeterIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Meter(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x560, Value); } // 0x560 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_BatteryIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_ReFuelling(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_RefuellingScaleLoop(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_ReFuelling_Reset(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x681
class UWBP_VehicleSpeedoMeter_C : public UWBP_VehicleGaugeBase_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x8, Type: StructProperty)
    UWBP_Vehicle_Warning_C* Widget_LowFuelWarning() const { return Read<UWBP_Vehicle_Warning_C*>(uintptr_t(this) + 0x610); } // 0x610 (Size: 0x8, Type: ObjectProperty)
    USpacer* Spacer_Boost() const { return Read<USpacer*>(uintptr_t(this) + 0x618); } // 0x618 (Size: 0x8, Type: ObjectProperty)
    UOverlay* OverlayBoostMeter() const { return Read<UOverlay*>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Speedometer() const { return Read<UOverlay*>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Action() const { return Read<UOverlay*>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Sparks_1() const { return Read<UImage*>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Sparks() const { return Read<UImage*>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Pulse() const { return Read<UImage*>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_LargeCone() const { return Read<UImage*>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Glow() const { return Read<UImage*>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* NameIntro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* NameOutro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* BoostEngage() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* BoostFull() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x8, Type: ObjectProperty)
    bool BoostEffectsVisible_0() const { return Read<bool>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x8, Type: StructProperty)
    void SET_Widget_LowFuelWarning(const UWBP_Vehicle_Warning_C*& Value) { Write<UWBP_Vehicle_Warning_C*>(uintptr_t(this) + 0x610, Value); } // 0x610 (Size: 0x8, Type: ObjectProperty)
    void SET_Spacer_Boost(const USpacer*& Value) { Write<USpacer*>(uintptr_t(this) + 0x618, Value); } // 0x618 (Size: 0x8, Type: ObjectProperty)
    void SET_OverlayBoostMeter(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Speedometer(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Action(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Sparks_1(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Sparks(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Pulse(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_LargeCone(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Glow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x8, Type: ObjectProperty)
    void SET_NameIntro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x8, Type: ObjectProperty)
    void SET_NameOutro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    void SET_BoostEngage(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    void SET_BoostFull(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x8, Type: ObjectProperty)
    void SET_BoostEffectsVisible_0(const bool& Value) { Write<bool>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x9c0
class AFuelIndicator_C : public ABuildingGameplayActor
{
public:
    UAthenaSpecialActorComponent* AthenaSpecialActor() const { return Read<UAthenaSpecialActorComponent*>(uintptr_t(this) + 0x9b0); } // 0x9b0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x9b8); } // 0x9b8 (Size: 0x8, Type: ObjectProperty)

    void SET_AthenaSpecialActor(const UAthenaSpecialActorComponent*& Value) { Write<UAthenaSpecialActorComponent*>(uintptr_t(this) + 0x9b0, Value); } // 0x9b0 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x9b8, Value); } // 0x9b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x9e8
class AGCNL_Valet_Boost_RadialBlur_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    UPostProcessComponent* PostProcess() const { return Read<UPostProcessComponent*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    float BlendTimeline_BlendWeight_4BA13AB34E6EEF57F3BD4A9FB71B4A52() const { return Read<float>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> BlendTimeline__Direction_4BA13AB34E6EEF57F3BD4A9FB71B4A52() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9dc); } // 0x9dc (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* BlendTimeline() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_PostProcess(const UPostProcessComponent*& Value) { Write<UPostProcessComponent*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_BlendTimeline_BlendWeight_4BA13AB34E6EEF57F3BD4A9FB71B4A52(const float& Value) { Write<float>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x4, Type: FloatProperty)
    void SET_BlendTimeline__Direction_4BA13AB34E6EEF57F3BD4A9FB71B4A52(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9dc, Value); } // 0x9dc (Size: 0x1, Type: ByteProperty)
    void SET_BlendTimeline(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x370
class UGCN_CollisionEffects_PropaneTank_C : public UGCN_CollisionEffects_Parent_C
{
public:
};

// Size: 0xb70
class AGCNL_RollingEffects_Stone_C : public AGCNL_RollingEffects_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
};

// Size: 0xb68
class AGCNL_RollingEffects_Metal_C : public AGCNL_RollingEffects_Parent_C
{
public:
};

// Size: 0x1f0
class UCamShake_Shadow_Bomb_C : public ULegacyCameraShake
{
public:
};

// Size: 0x9da
class AGCNL_Athena_Surface_Parent_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* TargetPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    bool Debug() const { return Read<bool>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x1, Type: BoolProperty)
    bool Is_in_Water() const { return Read<bool>(uintptr_t(this) + 0x9d9); } // 0x9d9 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_TargetPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Debug(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x1, Type: BoolProperty)
    void SET_Is_in_Water(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9d9, Value); } // 0x9d9 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1f0
class UB_DudeBro_VortexActivate_Shake_C : public ULegacyCameraShake
{
public:
};

// Size: 0x9f0
class AGCNL_Athena_UnderwaterDamage_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    double Intensity() const { return Read<double>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: DoubleProperty)
    USoundBase* DamageTickSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    USoundMix* DrownSoundMix() const { return Read<USoundMix*>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    AActor* LocalTargetPawn() const { return Read<AActor*>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_Intensity(const double& Value) { Write<double>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: DoubleProperty)
    void SET_DamageTickSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    void SET_DrownSoundMix(const USoundMix*& Value) { Write<USoundMix*>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalTargetPawn(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb68
class AGCNL_RollingEffects_Propane_C : public AGCNL_RollingEffects_Parent_C
{
public:
};

// Size: 0x370
class UGCN_CollisionEffects_Parent_C : public UGameplayCueBurst_CollisionEffect_Parent
{
public:
};

// Size: 0x1f0
class UCameraShake_ZipLine_DownhillSpeed_C : public ULegacyCameraShake
{
public:
};

// Size: 0x218
class UGCN_Athena_HidingProp_WilliePete_Rustle_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x218
class UGCN_Athena_HidingProp_WilliePete_WhileEntering_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x218
class UGCN_Athena_HidingProp_WilliePete_Enter_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x218
class UGCN_Athena_HidingProp_WilliePete_LandedOn_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x218
class UGCN_Athena_HidingProp_Teleporter_Enter_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x9d0
class AGCNL_Athena_HidingProp_PropTeleporting_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x9d0
class AGCNL_Athena_HidingProp_Collision_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x1f0
class UCameraShake_ZipLineAttach_C : public ULegacyCameraShake
{
public:
};

// Size: 0x218
class UGCN_Athena_HidingProp_Wobble_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0xfe4
class ABGA_Athena_SCMachine_C : public ABuildingGameplayActorSpawnMachine
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc08); } // 0xc08 (Size: 0x8, Type: StructProperty)
    UNiagaraComponent* NS_SCMachine_HoloLogo_LW() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* NS_SCMachine_PedestalGlow_LW() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x8, Type: ObjectProperty)
    UMultiInteractActorComponent_C* MultiInteractActorComponent() const { return Read<UMultiInteractActorComponent_C*>(uintptr_t(this) + 0xc20); } // 0xc20 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* ActivateEndSound() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x8, Type: ObjectProperty)
    UFortSoundIndicatorComponent* FortSoundIndicatorComponent() const { return Read<UFortSoundIndicatorComponent*>(uintptr_t(this) + 0xc30); } // 0xc30 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* BlockingSkirt() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x8, Type: ObjectProperty)
    UChildActorComponent* EdgeNavLinks2() const { return Read<UChildActorComponent*>(uintptr_t(this) + 0xc40); } // 0xc40 (Size: 0x8, Type: ObjectProperty)
    UChildActorComponent* EdgeNavLinks() const { return Read<UChildActorComponent*>(uintptr_t(this) + 0xc48); } // 0xc48 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* SC_Machine_Cooldown_Cue_End() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xc50); } // 0xc50 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* SC_Machine_Cooldown_Cue() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xc58); } // 0xc58 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* P_SCMachine_HoloLogo() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* HeadlightR() const { return Read<USpotLightComponent*>(uintptr_t(this) + 0xc68); } // 0xc68 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* HeadlightL() const { return Read<USpotLightComponent*>(uintptr_t(this) + 0xc70); } // 0xc70 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* P_SCMachine_PedestalGlow() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0xc78); } // 0xc78 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* ActivateSound() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xc80); } // 0xc80 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* AmbientSound() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x8, Type: ObjectProperty)
    UCapsuleComponent* BlockingVolume() const { return Read<UCapsuleComponent*>(uintptr_t(this) + 0xc90); } // 0xc90 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* PadCollision() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xc98); } // 0xc98 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Van() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xca0); } // 0xca0 (Size: 0x8, Type: ObjectProperty)
    UBoxComponent* InteractionBox() const { return Read<UBoxComponent*>(uintptr_t(this) + 0xca8); } // 0xca8 (Size: 0x8, Type: ObjectProperty)
    float LightFlash_LightBrightness_9296C3734D2838F5D5DD42912D8F0CBB() const { return Read<float>(uintptr_t(this) + 0xcb0); } // 0xcb0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> LightFlash__Direction_9296C3734D2838F5D5DD42912D8F0CBB() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xcb4); } // 0xcb4 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* LightFlash() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0xcb8); } // 0xcb8 (Size: 0x8, Type: ObjectProperty)
    FVector WarpVan_Scale_947A8C9647767577A408EC87E76820CB() const { return Read<FVector>(uintptr_t(this) + 0xcc0); } // 0xcc0 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<ETimelineDirection> WarpVan__Direction_947A8C9647767577A408EC87E76820CB() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xcd8); } // 0xcd8 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* WarpVan() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0xce0); } // 0xce0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* SpawnInParticle() const { return Read<UParticleSystem*>(uintptr_t(this) + 0xce8); } // 0xce8 (Size: 0x8, Type: ObjectProperty)
    FVector SpawnInParticleOffset() const { return Read<FVector>(uintptr_t(this) + 0xcf0); } // 0xcf0 (Size: 0x18, Type: StructProperty)
    FVector MannequinTransitionOffset() const { return Read<FVector>(uintptr_t(this) + 0xd08); } // 0xd08 (Size: 0x18, Type: StructProperty)
    double FXDoneDelay() const { return Read<double>(uintptr_t(this) + 0xd20); } // 0xd20 (Size: 0x8, Type: DoubleProperty)
    TArray<AActor*> PawnsBehindVan() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0xd28); } // 0xd28 (Size: 0x10, Type: ArrayProperty)
    FTimerHandle Timer_Cooldown() const { return Read<FTimerHandle>(uintptr_t(this) + 0xd38); } // 0xd38 (Size: 0x8, Type: StructProperty)
    double FXDelayThenBotSpawn() const { return Read<double>(uintptr_t(this) + 0xd40); } // 0xd40 (Size: 0x8, Type: DoubleProperty)
    int32_t VanState() const { return Read<int32_t>(uintptr_t(this) + 0xd48); } // 0xd48 (Size: 0x4, Type: IntProperty)
    UMaterialInstanceDynamic* ScreensMaterial() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xd50); } // 0xd50 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat Row_DestroyIfOff() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd58); } // 0xd58 (Size: 0x28, Type: StructProperty)
    double PlayRate() const { return Read<double>(uintptr_t(this) + 0xd80); } // 0xd80 (Size: 0x8, Type: DoubleProperty)
    double XYKnockAmountPlayer() const { return Read<double>(uintptr_t(this) + 0xd88); } // 0xd88 (Size: 0x8, Type: DoubleProperty)
    double ZKnockAmountPlayer() const { return Read<double>(uintptr_t(this) + 0xd90); } // 0xd90 (Size: 0x8, Type: DoubleProperty)
    USoundBase* DefaultAmbientAudio() const { return Read<USoundBase*>(uintptr_t(this) + 0xd98); } // 0xd98 (Size: 0x8, Type: ObjectProperty)
    USoundBase* CooldownAmbientAudio() const { return Read<USoundBase*>(uintptr_t(this) + 0xda0); } // 0xda0 (Size: 0x8, Type: ObjectProperty)
    double DelayBeforeCooldown() const { return Read<double>(uintptr_t(this) + 0xda8); } // 0xda8 (Size: 0x8, Type: DoubleProperty)
    FScalableFloat Row_RespawnTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0xdb0); } // 0xdb0 (Size: 0x28, Type: StructProperty)
    FScalableFloat Row_InteractTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0xdd8); } // 0xdd8 (Size: 0x28, Type: StructProperty)
    bool RepServerInteract() const { return Read<bool>(uintptr_t(this) + 0xe00); } // 0xe00 (Size: 0x1, Type: BoolProperty)
    UFortWorldItemDefinition* WeaponToGive() const { return Read<UFortWorldItemDefinition*>(uintptr_t(this) + 0xe08); } // 0xe08 (Size: 0x8, Type: ObjectProperty)
    UFortWorldItemDefinition* MatsToGive() const { return Read<UFortWorldItemDefinition*>(uintptr_t(this) + 0xe10); } // 0xe10 (Size: 0x8, Type: ObjectProperty)
    int32_t MatNumberToGive() const { return Read<int32_t>(uintptr_t(this) + 0xe18); } // 0xe18 (Size: 0x4, Type: IntProperty)
    int32_t AmmoNumberToGive() const { return Read<int32_t>(uintptr_t(this) + 0xe1c); } // 0xe1c (Size: 0x4, Type: IntProperty)
    FText FailedTextNoCard() const { return Read<FText>(uintptr_t(this) + 0xe20); } // 0xe20 (Size: 0x10, Type: TextProperty)
    UFortWorldItemDefinition* AmmoToGive() const { return Read<UFortWorldItemDefinition*>(uintptr_t(this) + 0xe30); } // 0xe30 (Size: 0x8, Type: ObjectProperty)
    FText FailedTextRecharging() const { return Read<FText>(uintptr_t(this) + 0xe38); } // 0xe38 (Size: 0x10, Type: TextProperty)
    FText FailedTextRebooting() const { return Read<FText>(uintptr_t(this) + 0xe48); } // 0xe48 (Size: 0x10, Type: TextProperty)
    FText PassedText() const { return Read<FText>(uintptr_t(this) + 0xe58); } // 0xe58 (Size: 0x10, Type: TextProperty)
    UMaterialInstanceDynamic* VanBodyMaterial() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xe68); } // 0xe68 (Size: 0x8, Type: ObjectProperty)
    double HeadlightIntensity() const { return Read<double>(uintptr_t(this) + 0xe70); } // 0xe70 (Size: 0x8, Type: DoubleProperty)
    bool Did_Horn_Play_() const { return Read<bool>(uintptr_t(this) + 0xe78); } // 0xe78 (Size: 0x1, Type: BoolProperty)
    TArray<AFortPlayerControllerAthena*> PlayersInteracting() const { return Read<TArray<AFortPlayerControllerAthena*>>(uintptr_t(this) + 0xe80); } // 0xe80 (Size: 0x10, Type: ArrayProperty)
    FName GrantedItemsLootTier() const { return Read<FName>(uintptr_t(this) + 0xe90); } // 0xe90 (Size: 0x4, Type: NameProperty)
    double HeightCheckForSkydive() const { return Read<double>(uintptr_t(this) + 0xe98); } // 0xe98 (Size: 0x8, Type: DoubleProperty)
    double ZKnockAmountVehicle() const { return Read<double>(uintptr_t(this) + 0xea0); } // 0xea0 (Size: 0x8, Type: DoubleProperty)
    double XYKnockAmountVehicle() const { return Read<double>(uintptr_t(this) + 0xea8); } // 0xea8 (Size: 0x8, Type: DoubleProperty)
    double InvincibleVisualsDuration() const { return Read<double>(uintptr_t(this) + 0xeb0); } // 0xeb0 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag ActiveCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xeb8); } // 0xeb8 (Size: 0x4, Type: StructProperty)
    FGameplayTag EndCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xebc); } // 0xebc (Size: 0x4, Type: StructProperty)
    FGameplayTag TransitionCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xec0); } // 0xec0 (Size: 0x4, Type: StructProperty)
    FGameplayTag ActivateCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xec4); } // 0xec4 (Size: 0x4, Type: StructProperty)
    double DelayBeforeSkydiveCheck() const { return Read<double>(uintptr_t(this) + 0xec8); } // 0xec8 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag SCMachine_Respawn_Cue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xed0); } // 0xed0 (Size: 0x4, Type: StructProperty)
    bool RepDisabledState() const { return Read<bool>(uintptr_t(this) + 0xed4); } // 0xed4 (Size: 0x1, Type: BoolProperty)
    FScalableFloat Row_EnabledInWorld() const { return Read<FScalableFloat>(uintptr_t(this) + 0xed8); } // 0xed8 (Size: 0x28, Type: StructProperty)
    UMaterialInterface* StaticScreen_Material() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0xf00); } // 0xf00 (Size: 0x8, Type: ObjectProperty)
    int32_t ScreenMaterialIndex() const { return Read<int32_t>(uintptr_t(this) + 0xf08); } // 0xf08 (Size: 0x4, Type: IntProperty)
    FName Van_Emissive_Parameter() const { return Read<FName>(uintptr_t(this) + 0xf0c); } // 0xf0c (Size: 0x4, Type: NameProperty)
    bool UseRiftSpawn() const { return Read<bool>(uintptr_t(this) + 0xf10); } // 0xf10 (Size: 0x1, Type: BoolProperty)
    USoundBase* HornAlertAudio() const { return Read<USoundBase*>(uintptr_t(this) + 0xf18); } // 0xf18 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* RebootedPlayer() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xf20); } // 0xf20 (Size: 0x8, Type: ObjectProperty)
    FVector OriginalVanMaterialEmissive() const { return Read<FVector>(uintptr_t(this) + 0xf28); } // 0xf28 (Size: 0x18, Type: StructProperty)
    UGameplayEventRouterComponent* EventRouterRef() const { return Read<UGameplayEventRouterComponent*>(uintptr_t(this) + 0xf40); } // 0xf40 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat EnableDecayRow() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf48); } // 0xf48 (Size: 0x28, Type: StructProperty)
    FGameplayTag SoloSquadTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xf70); } // 0xf70 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer SoloSquadTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xf78); } // 0xf78 (Size: 0x20, Type: StructProperty)
    TArray<AFortPlayerPawn*> EnhancedResurrectionRebootingPlayerPawns() const { return Read<TArray<AFortPlayerPawn*>>(uintptr_t(this) + 0xf98); } // 0xf98 (Size: 0x10, Type: ArrayProperty)
    FName EnhancedGrantedItemsLootTier() const { return Read<FName>(uintptr_t(this) + 0xfa8); } // 0xfa8 (Size: 0x4, Type: NameProperty)
    TArray<UClass*> EnhancedResurrectionGameplayEffects() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0xfb0); } // 0xfb0 (Size: 0x10, Type: ArrayProperty)
    USoundBase* BuyRebootCardInteractSound() const { return Read<USoundBase*>(uintptr_t(this) + 0xfc0); } // 0xfc0 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle RemoveActiveGameplayCueTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xfd8); } // 0xfd8 (Size: 0x8, Type: StructProperty)
    float RemoveActiveGameplayCueDelay() const { return Read<float>(uintptr_t(this) + 0xfe0); } // 0xfe0 (Size: 0x4, Type: FloatProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc08, Value); } // 0xc08 (Size: 0x8, Type: StructProperty)
    void SET_NS_SCMachine_HoloLogo_LW(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x8, Type: ObjectProperty)
    void SET_NS_SCMachine_PedestalGlow_LW(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x8, Type: ObjectProperty)
    void SET_MultiInteractActorComponent(const UMultiInteractActorComponent_C*& Value) { Write<UMultiInteractActorComponent_C*>(uintptr_t(this) + 0xc20, Value); } // 0xc20 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivateEndSound(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x8, Type: ObjectProperty)
    void SET_FortSoundIndicatorComponent(const UFortSoundIndicatorComponent*& Value) { Write<UFortSoundIndicatorComponent*>(uintptr_t(this) + 0xc30, Value); } // 0xc30 (Size: 0x8, Type: ObjectProperty)
    void SET_BlockingSkirt(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x8, Type: ObjectProperty)
    void SET_EdgeNavLinks2(const UChildActorComponent*& Value) { Write<UChildActorComponent*>(uintptr_t(this) + 0xc40, Value); } // 0xc40 (Size: 0x8, Type: ObjectProperty)
    void SET_EdgeNavLinks(const UChildActorComponent*& Value) { Write<UChildActorComponent*>(uintptr_t(this) + 0xc48, Value); } // 0xc48 (Size: 0x8, Type: ObjectProperty)
    void SET_SC_Machine_Cooldown_Cue_End(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xc50, Value); } // 0xc50 (Size: 0x8, Type: ObjectProperty)
    void SET_SC_Machine_Cooldown_Cue(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xc58, Value); } // 0xc58 (Size: 0x8, Type: ObjectProperty)
    void SET_P_SCMachine_HoloLogo(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x8, Type: ObjectProperty)
    void SET_HeadlightR(const USpotLightComponent*& Value) { Write<USpotLightComponent*>(uintptr_t(this) + 0xc68, Value); } // 0xc68 (Size: 0x8, Type: ObjectProperty)
    void SET_HeadlightL(const USpotLightComponent*& Value) { Write<USpotLightComponent*>(uintptr_t(this) + 0xc70, Value); } // 0xc70 (Size: 0x8, Type: ObjectProperty)
    void SET_P_SCMachine_PedestalGlow(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0xc78, Value); } // 0xc78 (Size: 0x8, Type: ObjectProperty)
    void SET_ActivateSound(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xc80, Value); } // 0xc80 (Size: 0x8, Type: ObjectProperty)
    void SET_AmbientSound(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x8, Type: ObjectProperty)
    void SET_BlockingVolume(const UCapsuleComponent*& Value) { Write<UCapsuleComponent*>(uintptr_t(this) + 0xc90, Value); } // 0xc90 (Size: 0x8, Type: ObjectProperty)
    void SET_PadCollision(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xc98, Value); } // 0xc98 (Size: 0x8, Type: ObjectProperty)
    void SET_Van(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xca0, Value); } // 0xca0 (Size: 0x8, Type: ObjectProperty)
    void SET_InteractionBox(const UBoxComponent*& Value) { Write<UBoxComponent*>(uintptr_t(this) + 0xca8, Value); } // 0xca8 (Size: 0x8, Type: ObjectProperty)
    void SET_LightFlash_LightBrightness_9296C3734D2838F5D5DD42912D8F0CBB(const float& Value) { Write<float>(uintptr_t(this) + 0xcb0, Value); } // 0xcb0 (Size: 0x4, Type: FloatProperty)
    void SET_LightFlash__Direction_9296C3734D2838F5D5DD42912D8F0CBB(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xcb4, Value); } // 0xcb4 (Size: 0x1, Type: ByteProperty)
    void SET_LightFlash(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0xcb8, Value); } // 0xcb8 (Size: 0x8, Type: ObjectProperty)
    void SET_WarpVan_Scale_947A8C9647767577A408EC87E76820CB(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xcc0, Value); } // 0xcc0 (Size: 0x18, Type: StructProperty)
    void SET_WarpVan__Direction_947A8C9647767577A408EC87E76820CB(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xcd8, Value); } // 0xcd8 (Size: 0x1, Type: ByteProperty)
    void SET_WarpVan(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0xce0, Value); } // 0xce0 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawnInParticle(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0xce8, Value); } // 0xce8 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawnInParticleOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xcf0, Value); } // 0xcf0 (Size: 0x18, Type: StructProperty)
    void SET_MannequinTransitionOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd08, Value); } // 0xd08 (Size: 0x18, Type: StructProperty)
    void SET_FXDoneDelay(const double& Value) { Write<double>(uintptr_t(this) + 0xd20, Value); } // 0xd20 (Size: 0x8, Type: DoubleProperty)
    void SET_PawnsBehindVan(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0xd28, Value); } // 0xd28 (Size: 0x10, Type: ArrayProperty)
    void SET_Timer_Cooldown(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xd38, Value); } // 0xd38 (Size: 0x8, Type: StructProperty)
    void SET_FXDelayThenBotSpawn(const double& Value) { Write<double>(uintptr_t(this) + 0xd40, Value); } // 0xd40 (Size: 0x8, Type: DoubleProperty)
    void SET_VanState(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd48, Value); } // 0xd48 (Size: 0x4, Type: IntProperty)
    void SET_ScreensMaterial(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xd50, Value); } // 0xd50 (Size: 0x8, Type: ObjectProperty)
    void SET_Row_DestroyIfOff(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd58, Value); } // 0xd58 (Size: 0x28, Type: StructProperty)
    void SET_PlayRate(const double& Value) { Write<double>(uintptr_t(this) + 0xd80, Value); } // 0xd80 (Size: 0x8, Type: DoubleProperty)
    void SET_XYKnockAmountPlayer(const double& Value) { Write<double>(uintptr_t(this) + 0xd88, Value); } // 0xd88 (Size: 0x8, Type: DoubleProperty)
    void SET_ZKnockAmountPlayer(const double& Value) { Write<double>(uintptr_t(this) + 0xd90, Value); } // 0xd90 (Size: 0x8, Type: DoubleProperty)
    void SET_DefaultAmbientAudio(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xd98, Value); } // 0xd98 (Size: 0x8, Type: ObjectProperty)
    void SET_CooldownAmbientAudio(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xda0, Value); } // 0xda0 (Size: 0x8, Type: ObjectProperty)
    void SET_DelayBeforeCooldown(const double& Value) { Write<double>(uintptr_t(this) + 0xda8, Value); } // 0xda8 (Size: 0x8, Type: DoubleProperty)
    void SET_Row_RespawnTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xdb0, Value); } // 0xdb0 (Size: 0x28, Type: StructProperty)
    void SET_Row_InteractTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xdd8, Value); } // 0xdd8 (Size: 0x28, Type: StructProperty)
    void SET_RepServerInteract(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe00, Value); } // 0xe00 (Size: 0x1, Type: BoolProperty)
    void SET_WeaponToGive(const UFortWorldItemDefinition*& Value) { Write<UFortWorldItemDefinition*>(uintptr_t(this) + 0xe08, Value); } // 0xe08 (Size: 0x8, Type: ObjectProperty)
    void SET_MatsToGive(const UFortWorldItemDefinition*& Value) { Write<UFortWorldItemDefinition*>(uintptr_t(this) + 0xe10, Value); } // 0xe10 (Size: 0x8, Type: ObjectProperty)
    void SET_MatNumberToGive(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe18, Value); } // 0xe18 (Size: 0x4, Type: IntProperty)
    void SET_AmmoNumberToGive(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe1c, Value); } // 0xe1c (Size: 0x4, Type: IntProperty)
    void SET_FailedTextNoCard(const FText& Value) { Write<FText>(uintptr_t(this) + 0xe20, Value); } // 0xe20 (Size: 0x10, Type: TextProperty)
    void SET_AmmoToGive(const UFortWorldItemDefinition*& Value) { Write<UFortWorldItemDefinition*>(uintptr_t(this) + 0xe30, Value); } // 0xe30 (Size: 0x8, Type: ObjectProperty)
    void SET_FailedTextRecharging(const FText& Value) { Write<FText>(uintptr_t(this) + 0xe38, Value); } // 0xe38 (Size: 0x10, Type: TextProperty)
    void SET_FailedTextRebooting(const FText& Value) { Write<FText>(uintptr_t(this) + 0xe48, Value); } // 0xe48 (Size: 0x10, Type: TextProperty)
    void SET_PassedText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xe58, Value); } // 0xe58 (Size: 0x10, Type: TextProperty)
    void SET_VanBodyMaterial(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xe68, Value); } // 0xe68 (Size: 0x8, Type: ObjectProperty)
    void SET_HeadlightIntensity(const double& Value) { Write<double>(uintptr_t(this) + 0xe70, Value); } // 0xe70 (Size: 0x8, Type: DoubleProperty)
    void SET_Did_Horn_Play_(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe78, Value); } // 0xe78 (Size: 0x1, Type: BoolProperty)
    void SET_PlayersInteracting(const TArray<AFortPlayerControllerAthena*>& Value) { Write<TArray<AFortPlayerControllerAthena*>>(uintptr_t(this) + 0xe80, Value); } // 0xe80 (Size: 0x10, Type: ArrayProperty)
    void SET_GrantedItemsLootTier(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe90, Value); } // 0xe90 (Size: 0x4, Type: NameProperty)
    void SET_HeightCheckForSkydive(const double& Value) { Write<double>(uintptr_t(this) + 0xe98, Value); } // 0xe98 (Size: 0x8, Type: DoubleProperty)
    void SET_ZKnockAmountVehicle(const double& Value) { Write<double>(uintptr_t(this) + 0xea0, Value); } // 0xea0 (Size: 0x8, Type: DoubleProperty)
    void SET_XYKnockAmountVehicle(const double& Value) { Write<double>(uintptr_t(this) + 0xea8, Value); } // 0xea8 (Size: 0x8, Type: DoubleProperty)
    void SET_InvincibleVisualsDuration(const double& Value) { Write<double>(uintptr_t(this) + 0xeb0, Value); } // 0xeb0 (Size: 0x8, Type: DoubleProperty)
    void SET_ActiveCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xeb8, Value); } // 0xeb8 (Size: 0x4, Type: StructProperty)
    void SET_EndCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xebc, Value); } // 0xebc (Size: 0x4, Type: StructProperty)
    void SET_TransitionCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xec0, Value); } // 0xec0 (Size: 0x4, Type: StructProperty)
    void SET_ActivateCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xec4, Value); } // 0xec4 (Size: 0x4, Type: StructProperty)
    void SET_DelayBeforeSkydiveCheck(const double& Value) { Write<double>(uintptr_t(this) + 0xec8, Value); } // 0xec8 (Size: 0x8, Type: DoubleProperty)
    void SET_SCMachine_Respawn_Cue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xed0, Value); } // 0xed0 (Size: 0x4, Type: StructProperty)
    void SET_RepDisabledState(const bool& Value) { Write<bool>(uintptr_t(this) + 0xed4, Value); } // 0xed4 (Size: 0x1, Type: BoolProperty)
    void SET_Row_EnabledInWorld(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xed8, Value); } // 0xed8 (Size: 0x28, Type: StructProperty)
    void SET_StaticScreen_Material(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0xf00, Value); } // 0xf00 (Size: 0x8, Type: ObjectProperty)
    void SET_ScreenMaterialIndex(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xf08, Value); } // 0xf08 (Size: 0x4, Type: IntProperty)
    void SET_Van_Emissive_Parameter(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf0c, Value); } // 0xf0c (Size: 0x4, Type: NameProperty)
    void SET_UseRiftSpawn(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf10, Value); } // 0xf10 (Size: 0x1, Type: BoolProperty)
    void SET_HornAlertAudio(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xf18, Value); } // 0xf18 (Size: 0x8, Type: ObjectProperty)
    void SET_RebootedPlayer(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xf20, Value); } // 0xf20 (Size: 0x8, Type: ObjectProperty)
    void SET_OriginalVanMaterialEmissive(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf28, Value); } // 0xf28 (Size: 0x18, Type: StructProperty)
    void SET_EventRouterRef(const UGameplayEventRouterComponent*& Value) { Write<UGameplayEventRouterComponent*>(uintptr_t(this) + 0xf40, Value); } // 0xf40 (Size: 0x8, Type: ObjectProperty)
    void SET_EnableDecayRow(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf48, Value); } // 0xf48 (Size: 0x28, Type: StructProperty)
    void SET_SoloSquadTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xf70, Value); } // 0xf70 (Size: 0x4, Type: StructProperty)
    void SET_SoloSquadTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xf78, Value); } // 0xf78 (Size: 0x20, Type: StructProperty)
    void SET_EnhancedResurrectionRebootingPlayerPawns(const TArray<AFortPlayerPawn*>& Value) { Write<TArray<AFortPlayerPawn*>>(uintptr_t(this) + 0xf98, Value); } // 0xf98 (Size: 0x10, Type: ArrayProperty)
    void SET_EnhancedGrantedItemsLootTier(const FName& Value) { Write<FName>(uintptr_t(this) + 0xfa8, Value); } // 0xfa8 (Size: 0x4, Type: NameProperty)
    void SET_EnhancedResurrectionGameplayEffects(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0xfb0, Value); } // 0xfb0 (Size: 0x10, Type: ArrayProperty)
    void SET_BuyRebootCardInteractSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xfc0, Value); } // 0xfc0 (Size: 0x8, Type: ObjectProperty)
    void SET_RemoveActiveGameplayCueTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xfd8, Value); } // 0xfd8 (Size: 0x8, Type: StructProperty)
    void SET_RemoveActiveGameplayCueDelay(const float& Value) { Write<float>(uintptr_t(this) + 0xfe0, Value); } // 0xfe0 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x4a1
class UWBP_CosmeticGate_PurchaseInfo_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_SubHeader() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_PurchaseConfirmation() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Header() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_Body() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    UWBP_CosmeticGate_IslandPreview_C* IslandPreview_T() const { return Read<UWBP_CosmeticGate_IslandPreview_C*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    UWBP_CosmeticGate_IslandPreview_C* IslandPreview_E10() const { return Read<UWBP_CosmeticGate_IslandPreview_C*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UWBP_CosmeticGate_IslandPreview_C* IslandPreview_E() const { return Read<UWBP_CosmeticGate_IslandPreview_C*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UImage* Icon_Warning() const { return Read<UImage*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UImage* Icon_Header() const { return Read<UImage*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HBox_IslandPreviews() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HBox_Header() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    UFortItemShopOfferVM* FortItemShopOfferVM() const { return Read<UFortItemShopOfferVM*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    bool Show_Header() const { return Read<bool>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x1, Type: BoolProperty)
    bool Show_Header_Icon() const { return Read<bool>(uintptr_t(this) + 0x389); } // 0x389 (Size: 0x1, Type: BoolProperty)
    FSlateFontInfo Header_Font() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x58, Type: StructProperty)
    bool Show_Sub_Header_Icon() const { return Read<bool>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x1, Type: BoolProperty)
    FSlateFontInfo Sub_Header_Font() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x58, Type: StructProperty)
    FSlateFontInfo Body_Text_Font() const { return Read<FSlateFontInfo>(uintptr_t(this) + 0x448); } // 0x448 (Size: 0x58, Type: StructProperty)
    TEnumAsByte<EHorizontalAlignment> Usability_Matrix_Alignment() const { return Read<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x1, Type: ByteProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_Text_SubHeader(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_PurchaseConfirmation(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Header(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_Body(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_IslandPreview_T(const UWBP_CosmeticGate_IslandPreview_C*& Value) { Write<UWBP_CosmeticGate_IslandPreview_C*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_IslandPreview_E10(const UWBP_CosmeticGate_IslandPreview_C*& Value) { Write<UWBP_CosmeticGate_IslandPreview_C*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_IslandPreview_E(const UWBP_CosmeticGate_IslandPreview_C*& Value) { Write<UWBP_CosmeticGate_IslandPreview_C*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_Icon_Warning(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_Icon_Header(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_HBox_IslandPreviews(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_HBox_Header(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_FortItemShopOfferVM(const UFortItemShopOfferVM*& Value) { Write<UFortItemShopOfferVM*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_Show_Header(const bool& Value) { Write<bool>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x1, Type: BoolProperty)
    void SET_Show_Header_Icon(const bool& Value) { Write<bool>(uintptr_t(this) + 0x389, Value); } // 0x389 (Size: 0x1, Type: BoolProperty)
    void SET_Header_Font(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x58, Type: StructProperty)
    void SET_Show_Sub_Header_Icon(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x1, Type: BoolProperty)
    void SET_Sub_Header_Font(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x58, Type: StructProperty)
    void SET_Body_Text_Font(const FSlateFontInfo& Value) { Write<FSlateFontInfo>(uintptr_t(this) + 0x448, Value); } // 0x448 (Size: 0x58, Type: StructProperty)
    void SET_Usability_Matrix_Alignment(const TEnumAsByte<EHorizontalAlignment>& Value) { Write<TEnumAsByte<EHorizontalAlignment>>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x380
class UWBP_CosmeticGate_IslandPreview_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_StatusIndicator_C* WBP_UIKit_StatusIndicator() const { return Read<UWBP_UIKit_StatusIndicator_C*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_RatingName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Thumbnail() const { return Read<UImage*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_RatingIcon() const { return Read<UImage*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    bool IsApproved() const { return Read<bool>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x1, Type: BoolProperty)
    FVector2D MobileScaleFactor() const { return Read<FVector2D>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: StructProperty)
    TSoftObjectPtr<UTexture2D> SoftThumbnailImage() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x20, Type: SoftObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_StatusIndicator(const UWBP_UIKit_StatusIndicator_C*& Value) { Write<UWBP_UIKit_StatusIndicator_C*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_RatingName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Thumbnail(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_RatingIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_IsApproved(const bool& Value) { Write<bool>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x1, Type: BoolProperty)
    void SET_MobileScaleFactor(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: StructProperty)
    void SET_SoftThumbnailImage(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x418
class USimpleMaterialProgressBar_C : public UFortSimpleMaterialProgressBar
{
public:
};

// Size: 0x610
class UWBP_PlayerVisited_C : public UAthenaVisitedAreaDisplay
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: StructProperty)
    UWBP_PlayerVisited_Context_C* WBP_PlayerVisited_Context() const { return Read<UWBP_PlayerVisited_Context_C*>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    UFortPrioritizedWidgetSwitcher* Switcher_Underlay() const { return Read<UFortPrioritizedWidgetSwitcher*>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    UFortPrioritizedWidgetSwitcher* Switcher_Layout() const { return Read<UFortPrioritizedWidgetSwitcher*>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    USpacer* Spacer_Mobile() const { return Read<USpacer*>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Alignment() const { return Read<UOverlay*>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* BriefShow() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle BriefShowFallbackTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: StructProperty)
    FText LastLocationVisited() const { return Read<FText>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x10, Type: TextProperty)
    double TimeLastLocationVisited() const { return Read<double>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: DoubleProperty)
    double LocationVisitedCooldown() const { return Read<double>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x8, Type: DoubleProperty)
    TSoftObjectPtr<USoundCue> Discovered_Sound_Cue() const { return Read<TSoftObjectPtr<USoundCue>>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x20, Type: SoftObjectProperty)
    bool Is_Discovered() const { return Read<bool>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x1, Type: BoolProperty)
    USoundBase* POI_Discover_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Landmark_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    bool IsNamedLocation() const { return Read<bool>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x1, Type: BoolProperty)
    UAudioComponent* DiscoveryMusic() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: StructProperty)
    void SET_WBP_PlayerVisited_Context(const UWBP_PlayerVisited_Context_C*& Value) { Write<UWBP_PlayerVisited_Context_C*>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_Underlay(const UFortPrioritizedWidgetSwitcher*& Value) { Write<UFortPrioritizedWidgetSwitcher*>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    void SET_Switcher_Layout(const UFortPrioritizedWidgetSwitcher*& Value) { Write<UFortPrioritizedWidgetSwitcher*>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    void SET_Spacer_Mobile(const USpacer*& Value) { Write<USpacer*>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Alignment(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    void SET_BriefShow(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    void SET_BriefShowFallbackTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: StructProperty)
    void SET_LastLocationVisited(const FText& Value) { Write<FText>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x10, Type: TextProperty)
    void SET_TimeLastLocationVisited(const double& Value) { Write<double>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: DoubleProperty)
    void SET_LocationVisitedCooldown(const double& Value) { Write<double>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x8, Type: DoubleProperty)
    void SET_Discovered_Sound_Cue(const TSoftObjectPtr<USoundCue>& Value) { Write<TSoftObjectPtr<USoundCue>>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Is_Discovered(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x1, Type: BoolProperty)
    void SET_POI_Discover_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x8, Type: ObjectProperty)
    void SET_Landmark_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x8, Type: ObjectProperty)
    void SET_IsNamedLocation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x1, Type: BoolProperty)
    void SET_DiscoveryMusic(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x5f8
class UPlayerDiscovered_C : public UAthenaDiscoveredAreaOverlay
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x558); } // 0x558 (Size: 0x8, Type: StructProperty)
    UWidgetSwitcher* WidgetSwitcher_LandmarkOrPOI() const { return Read<UWidgetSwitcher*>(uintptr_t(this) + 0x560); } // 0x560 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Underlay() const { return Read<UOverlay*>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Container() const { return Read<UOverlay*>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* MainLocationText_1() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* MainLocationText() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* MainBox_Landmark() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x8, Type: ObjectProperty)
    UVerticalBox* MainBox() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_BulletRight() const { return Read<UImage*>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_BulletLeft() const { return Read<UImage*>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* CommonTextBlock_LandmarkName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* BriefShow() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer RelevantPlaylistTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x20, Type: StructProperty)
    TSoftObjectPtr<USoundCue> SoundCue() const { return Read<TSoftObjectPtr<USoundCue>>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x20, Type: SoftObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x558, Value); } // 0x558 (Size: 0x8, Type: StructProperty)
    void SET_WidgetSwitcher_LandmarkOrPOI(const UWidgetSwitcher*& Value) { Write<UWidgetSwitcher*>(uintptr_t(this) + 0x560, Value); } // 0x560 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Underlay(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Container(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    void SET_MainLocationText_1(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x8, Type: ObjectProperty)
    void SET_MainLocationText(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: ObjectProperty)
    void SET_MainBox_Landmark(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x8, Type: ObjectProperty)
    void SET_MainBox(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_BulletRight(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_BulletLeft(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x8, Type: ObjectProperty)
    void SET_CommonTextBlock_LandmarkName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    void SET_BriefShow(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x8, Type: ObjectProperty)
    void SET_RelevantPlaylistTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x20, Type: StructProperty)
    void SET_SoundCue(const TSoftObjectPtr<USoundCue>& Value) { Write<TSoftObjectPtr<USoundCue>>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x340
class UWBP_CosmeticGating_WarningIcon_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    UImage* Icon() const { return Read<UImage*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    FVector2D IconSize() const { return Read<FVector2D>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x10, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_Icon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_IconSize(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x10, Type: StructProperty)
};

// Size: 0x10
struct FSafeZone_Event_Hide
{
public:
    bool bSafeZoneHidden_11_D95F757D4D3C77140E36D781AFD39654() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    double TransitionTime_15_386FCD724C4F878643BFB6A8D2AA4043() const { return Read<double>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: DoubleProperty)

    void SET_bSafeZoneHidden_11_D95F757D4D3C77140E36D781AFD39654(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_TransitionTime_15_386FCD724C4F878643BFB6A8D2AA4043(const double& Value) { Write<double>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x8d8
class ASafeZoneIndicator_C : public AFortSafeZoneIndicator
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x8, Type: StructProperty)
    UChildActorComponent* BP_StormMeshRotator() const { return Read<UChildActorComponent*>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    UChildActorComponent* AGV_Storm() const { return Read<UChildActorComponent*>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    float Timeline___Scale_to_Hide_Alpha_95606EC24230B83DF0ABB9824143F208() const { return Read<float>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline___Scale_to_Hide__Direction_95606EC24230B83DF0ABB9824143F208() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x64c); } // 0x64c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline___Scale_to_Hide() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    float TimelineInitialStorm_PhaseLerp_CAFF73A340D12D2CE325CF87E417163D() const { return Read<float>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> TimelineInitialStorm__Direction_CAFF73A340D12D2CE325CF87E417163D() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x65c); } // 0x65c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* TimelineInitialStorm() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x8, Type: ObjectProperty)
    float VolCloudsPhaseBlend_PhaseLerp_0AFD23C94964FFB76386A4B5AE3A4C77() const { return Read<float>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> VolCloudsPhaseBlend__Direction_0AFD23C94964FFB76386A4B5AE3A4C77() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x66c); } // 0x66c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* VolCloudsPhaseBlend() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    float VolumetricStormFadeTimeline_StormFadeIn_5D8CED344AED096A33ABDAA94E2E18CD() const { return Read<float>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> VolumetricStormFadeTimeline__Direction_5D8CED344AED096A33ABDAA94E2E18CD() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x67c); } // 0x67c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* VolumetricStormFadeTimeline() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    float StormFadeTimeline_StormFadeIn_6FB75EFB416FB419D85F8797DEDD058C() const { return Read<float>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> StormFadeTimeline__Direction_6FB75EFB416FB419D85F8797DEDD058C() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x68c); } // 0x68c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* StormFadeTimeline() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x8, Type: ObjectProperty)
    float Pre_Damage_Audio_Ramp_Intensity_05A077AD4FED08F2426E5CA16BD41D7C() const { return Read<float>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Pre_Damage_Audio_Ramp__Direction_05A077AD4FED08F2426E5CA16BD41D7C() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x69c); } // 0x69c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Pre_Damage_Audio_Ramp() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* ShieldBoundaryLoopSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* HoldingLoopSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x8, Type: ObjectProperty)
    double HoldingStartTime_0() const { return Read<double>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x8, Type: DoubleProperty)
    USoundBase* HoldingLoopTickSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x6c0); } // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* SafeZoneMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x6c8); } // 0x6c8 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle MegaStormDamageTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x8, Type: StructProperty)
    double MegastormAudioDuration() const { return Read<double>(uintptr_t(this) + 0x6d8); } // 0x6d8 (Size: 0x8, Type: DoubleProperty)
    uint8_t SafeZoneState() const { return Read<uint8_t>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x1, Type: EnumProperty)
    TMap<FVector2D, EFortSafeZoneState> SafeZoneStateThunderFreqs() const { return Read<TMap<FVector2D, EFortSafeZoneState>>(uintptr_t(this) + 0x6f8); } // 0x6f8 (Size: 0x50, Type: MapProperty)
    TMap<double, EFortSafeZoneState> SafeZoneStateThunderDuration() const { return Read<TMap<double, EFortSafeZoneState>>(uintptr_t(this) + 0x748); } // 0x748 (Size: 0x50, Type: MapProperty)
    bool OceanEnabled() const { return Read<bool>(uintptr_t(this) + 0x798); } // 0x798 (Size: 0x1, Type: BoolProperty)
    int32_t NumberofImpactEffects() const { return Read<int32_t>(uintptr_t(this) + 0x79c); } // 0x79c (Size: 0x4, Type: IntProperty)
    double ImapctFX_MaxHeight() const { return Read<double>(uintptr_t(this) + 0x7a0); } // 0x7a0 (Size: 0x8, Type: DoubleProperty)
    double ImapctFX_MinHeight() const { return Read<double>(uintptr_t(this) + 0x7a8); } // 0x7a8 (Size: 0x8, Type: DoubleProperty)
    int32_t Phase() const { return Read<int32_t>(uintptr_t(this) + 0x7b0); } // 0x7b0 (Size: 0x4, Type: IntProperty)
    bool ShowStorm() const { return Read<bool>(uintptr_t(this) + 0x7b4); } // 0x7b4 (Size: 0x1, Type: BoolProperty)
    double StormRadiusKm() const { return Read<double>(uintptr_t(this) + 0x7b8); } // 0x7b8 (Size: 0x8, Type: DoubleProperty)
    double StormHeightNormalized() const { return Read<double>(uintptr_t(this) + 0x7c0); } // 0x7c0 (Size: 0x8, Type: DoubleProperty)
    double StormThicknessKm() const { return Read<double>(uintptr_t(this) + 0x7c8); } // 0x7c8 (Size: 0x8, Type: DoubleProperty)
    double StormAltitudeNormalized() const { return Read<double>(uintptr_t(this) + 0x7d0); } // 0x7d0 (Size: 0x8, Type: DoubleProperty)
    double StormRadiusKm_End() const { return Read<double>(uintptr_t(this) + 0x7d8); } // 0x7d8 (Size: 0x8, Type: DoubleProperty)
    double StormHeightNormalized_End() const { return Read<double>(uintptr_t(this) + 0x7e0); } // 0x7e0 (Size: 0x8, Type: DoubleProperty)
    double StormThicknessKm_End() const { return Read<double>(uintptr_t(this) + 0x7e8); } // 0x7e8 (Size: 0x8, Type: DoubleProperty)
    double StormAltitudeNormalized_End() const { return Read<double>(uintptr_t(this) + 0x7f0); } // 0x7f0 (Size: 0x8, Type: DoubleProperty)
    double StormProgression() const { return Read<double>(uintptr_t(this) + 0x7f8); } // 0x7f8 (Size: 0x8, Type: DoubleProperty)
    bool TestStormProgression() const { return Read<bool>(uintptr_t(this) + 0x800); } // 0x800 (Size: 0x1, Type: BoolProperty)
    double CloudMaskScale_Km() const { return Read<double>(uintptr_t(this) + 0x808); } // 0x808 (Size: 0x8, Type: DoubleProperty)
    double TopCloudsLayerAltitudeNormalized() const { return Read<double>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x8, Type: DoubleProperty)
    double TopCloudsLayerThicknessNormalized() const { return Read<double>(uintptr_t(this) + 0x818); } // 0x818 (Size: 0x8, Type: DoubleProperty)
    double LowerCloudsLayerAltitudeNormalized() const { return Read<double>(uintptr_t(this) + 0x820); } // 0x820 (Size: 0x8, Type: DoubleProperty)
    double LowerCloudsLayerThicknessNormalized() const { return Read<double>(uintptr_t(this) + 0x828); } // 0x828 (Size: 0x8, Type: DoubleProperty)
    double TopCloudsLayerSpeed() const { return Read<double>(uintptr_t(this) + 0x830); } // 0x830 (Size: 0x8, Type: DoubleProperty)
    double TopCloudMips() const { return Read<double>(uintptr_t(this) + 0x838); } // 0x838 (Size: 0x8, Type: DoubleProperty)
    double CurrentRadiusScale() const { return Read<double>(uintptr_t(this) + 0x840); } // 0x840 (Size: 0x8, Type: DoubleProperty)
    double NextRadiusScale() const { return Read<double>(uintptr_t(this) + 0x848); } // 0x848 (Size: 0x8, Type: DoubleProperty)
    double BiasPowerCurve() const { return Read<double>(uintptr_t(this) + 0x850); } // 0x850 (Size: 0x8, Type: DoubleProperty)
    TArray<double> PhaseInfoArray() const { return Read<TArray<double>>(uintptr_t(this) + 0x858); } // 0x858 (Size: 0x10, Type: ArrayProperty)
    bool initializedPhaseInfo() const { return Read<bool>(uintptr_t(this) + 0x868); } // 0x868 (Size: 0x1, Type: BoolProperty)
    double CloudStartBiasHeadStart() const { return Read<double>(uintptr_t(this) + 0x870); } // 0x870 (Size: 0x8, Type: DoubleProperty)
    bool bWarmUpFinished() const { return Read<bool>(uintptr_t(this) + 0x878); } // 0x878 (Size: 0x1, Type: BoolProperty)
    TArray<double> RadiusInfoArray() const { return Read<TArray<double>>(uintptr_t(this) + 0x880); } // 0x880 (Size: 0x10, Type: ArrayProperty)
    bool bLatchWarmUp() const { return Read<bool>(uintptr_t(this) + 0x890); } // 0x890 (Size: 0x1, Type: BoolProperty)
    ABP_StormMeshRotator_C* StormRotatorActor() const { return Read<ABP_StormMeshRotator_C*>(uintptr_t(this) + 0x898); } // 0x898 (Size: 0x8, Type: ObjectProperty)
    AFortPawn* PawnRef() const { return Read<AFortPawn*>(uintptr_t(this) + 0x8a0); } // 0x8a0 (Size: 0x8, Type: ObjectProperty)
    double Saved_Radius_for_Hiding() const { return Read<double>(uintptr_t(this) + 0x8a8); } // 0x8a8 (Size: 0x8, Type: DoubleProperty)
    double Saved_Shrink_for_Hiding() const { return Read<double>(uintptr_t(this) + 0x8b0); } // 0x8b0 (Size: 0x8, Type: DoubleProperty)
    double Saved_Bias_for_Hiding() const { return Read<double>(uintptr_t(this) + 0x8b8); } // 0x8b8 (Size: 0x8, Type: DoubleProperty)
    double Saved_MID_Opacity_for_Hiding() const { return Read<double>(uintptr_t(this) + 0x8c0); } // 0x8c0 (Size: 0x8, Type: DoubleProperty)
    double Saved_MPC_Opacity_for_Hiding() const { return Read<double>(uintptr_t(this) + 0x8c8); } // 0x8c8 (Size: 0x8, Type: DoubleProperty)
    double Transition_Time() const { return Read<double>(uintptr_t(this) + 0x8d0); } // 0x8d0 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x8, Type: StructProperty)
    void SET_BP_StormMeshRotator(const UChildActorComponent*& Value) { Write<UChildActorComponent*>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    void SET_AGV_Storm(const UChildActorComponent*& Value) { Write<UChildActorComponent*>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    void SET_Timeline___Scale_to_Hide_Alpha_95606EC24230B83DF0ABB9824143F208(const float& Value) { Write<float>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline___Scale_to_Hide__Direction_95606EC24230B83DF0ABB9824143F208(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x64c, Value); } // 0x64c (Size: 0x1, Type: ByteProperty)
    void SET_Timeline___Scale_to_Hide(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    void SET_TimelineInitialStorm_PhaseLerp_CAFF73A340D12D2CE325CF87E417163D(const float& Value) { Write<float>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x4, Type: FloatProperty)
    void SET_TimelineInitialStorm__Direction_CAFF73A340D12D2CE325CF87E417163D(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x65c, Value); } // 0x65c (Size: 0x1, Type: ByteProperty)
    void SET_TimelineInitialStorm(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x8, Type: ObjectProperty)
    void SET_VolCloudsPhaseBlend_PhaseLerp_0AFD23C94964FFB76386A4B5AE3A4C77(const float& Value) { Write<float>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x4, Type: FloatProperty)
    void SET_VolCloudsPhaseBlend__Direction_0AFD23C94964FFB76386A4B5AE3A4C77(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x66c, Value); } // 0x66c (Size: 0x1, Type: ByteProperty)
    void SET_VolCloudsPhaseBlend(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    void SET_VolumetricStormFadeTimeline_StormFadeIn_5D8CED344AED096A33ABDAA94E2E18CD(const float& Value) { Write<float>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x4, Type: FloatProperty)
    void SET_VolumetricStormFadeTimeline__Direction_5D8CED344AED096A33ABDAA94E2E18CD(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x67c, Value); } // 0x67c (Size: 0x1, Type: ByteProperty)
    void SET_VolumetricStormFadeTimeline(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    void SET_StormFadeTimeline_StormFadeIn_6FB75EFB416FB419D85F8797DEDD058C(const float& Value) { Write<float>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x4, Type: FloatProperty)
    void SET_StormFadeTimeline__Direction_6FB75EFB416FB419D85F8797DEDD058C(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x68c, Value); } // 0x68c (Size: 0x1, Type: ByteProperty)
    void SET_StormFadeTimeline(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x8, Type: ObjectProperty)
    void SET_Pre_Damage_Audio_Ramp_Intensity_05A077AD4FED08F2426E5CA16BD41D7C(const float& Value) { Write<float>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x4, Type: FloatProperty)
    void SET_Pre_Damage_Audio_Ramp__Direction_05A077AD4FED08F2426E5CA16BD41D7C(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x69c, Value); } // 0x69c (Size: 0x1, Type: ByteProperty)
    void SET_Pre_Damage_Audio_Ramp(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    void SET_ShieldBoundaryLoopSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    void SET_HoldingLoopSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x8, Type: ObjectProperty)
    void SET_HoldingStartTime_0(const double& Value) { Write<double>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x8, Type: DoubleProperty)
    void SET_HoldingLoopTickSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x6c0, Value); } // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    void SET_SafeZoneMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x6c8, Value); } // 0x6c8 (Size: 0x8, Type: ObjectProperty)
    void SET_MegaStormDamageTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x8, Type: StructProperty)
    void SET_MegastormAudioDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x6d8, Value); } // 0x6d8 (Size: 0x8, Type: DoubleProperty)
    void SET_SafeZoneState(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x1, Type: EnumProperty)
    void SET_SafeZoneStateThunderFreqs(const TMap<FVector2D, EFortSafeZoneState>& Value) { Write<TMap<FVector2D, EFortSafeZoneState>>(uintptr_t(this) + 0x6f8, Value); } // 0x6f8 (Size: 0x50, Type: MapProperty)
    void SET_SafeZoneStateThunderDuration(const TMap<double, EFortSafeZoneState>& Value) { Write<TMap<double, EFortSafeZoneState>>(uintptr_t(this) + 0x748, Value); } // 0x748 (Size: 0x50, Type: MapProperty)
    void SET_OceanEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x798, Value); } // 0x798 (Size: 0x1, Type: BoolProperty)
    void SET_NumberofImpactEffects(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x79c, Value); } // 0x79c (Size: 0x4, Type: IntProperty)
    void SET_ImapctFX_MaxHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x7a0, Value); } // 0x7a0 (Size: 0x8, Type: DoubleProperty)
    void SET_ImapctFX_MinHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x7a8, Value); } // 0x7a8 (Size: 0x8, Type: DoubleProperty)
    void SET_Phase(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x7b0, Value); } // 0x7b0 (Size: 0x4, Type: IntProperty)
    void SET_ShowStorm(const bool& Value) { Write<bool>(uintptr_t(this) + 0x7b4, Value); } // 0x7b4 (Size: 0x1, Type: BoolProperty)
    void SET_StormRadiusKm(const double& Value) { Write<double>(uintptr_t(this) + 0x7b8, Value); } // 0x7b8 (Size: 0x8, Type: DoubleProperty)
    void SET_StormHeightNormalized(const double& Value) { Write<double>(uintptr_t(this) + 0x7c0, Value); } // 0x7c0 (Size: 0x8, Type: DoubleProperty)
    void SET_StormThicknessKm(const double& Value) { Write<double>(uintptr_t(this) + 0x7c8, Value); } // 0x7c8 (Size: 0x8, Type: DoubleProperty)
    void SET_StormAltitudeNormalized(const double& Value) { Write<double>(uintptr_t(this) + 0x7d0, Value); } // 0x7d0 (Size: 0x8, Type: DoubleProperty)
    void SET_StormRadiusKm_End(const double& Value) { Write<double>(uintptr_t(this) + 0x7d8, Value); } // 0x7d8 (Size: 0x8, Type: DoubleProperty)
    void SET_StormHeightNormalized_End(const double& Value) { Write<double>(uintptr_t(this) + 0x7e0, Value); } // 0x7e0 (Size: 0x8, Type: DoubleProperty)
    void SET_StormThicknessKm_End(const double& Value) { Write<double>(uintptr_t(this) + 0x7e8, Value); } // 0x7e8 (Size: 0x8, Type: DoubleProperty)
    void SET_StormAltitudeNormalized_End(const double& Value) { Write<double>(uintptr_t(this) + 0x7f0, Value); } // 0x7f0 (Size: 0x8, Type: DoubleProperty)
    void SET_StormProgression(const double& Value) { Write<double>(uintptr_t(this) + 0x7f8, Value); } // 0x7f8 (Size: 0x8, Type: DoubleProperty)
    void SET_TestStormProgression(const bool& Value) { Write<bool>(uintptr_t(this) + 0x800, Value); } // 0x800 (Size: 0x1, Type: BoolProperty)
    void SET_CloudMaskScale_Km(const double& Value) { Write<double>(uintptr_t(this) + 0x808, Value); } // 0x808 (Size: 0x8, Type: DoubleProperty)
    void SET_TopCloudsLayerAltitudeNormalized(const double& Value) { Write<double>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x8, Type: DoubleProperty)
    void SET_TopCloudsLayerThicknessNormalized(const double& Value) { Write<double>(uintptr_t(this) + 0x818, Value); } // 0x818 (Size: 0x8, Type: DoubleProperty)
    void SET_LowerCloudsLayerAltitudeNormalized(const double& Value) { Write<double>(uintptr_t(this) + 0x820, Value); } // 0x820 (Size: 0x8, Type: DoubleProperty)
    void SET_LowerCloudsLayerThicknessNormalized(const double& Value) { Write<double>(uintptr_t(this) + 0x828, Value); } // 0x828 (Size: 0x8, Type: DoubleProperty)
    void SET_TopCloudsLayerSpeed(const double& Value) { Write<double>(uintptr_t(this) + 0x830, Value); } // 0x830 (Size: 0x8, Type: DoubleProperty)
    void SET_TopCloudMips(const double& Value) { Write<double>(uintptr_t(this) + 0x838, Value); } // 0x838 (Size: 0x8, Type: DoubleProperty)
    void SET_CurrentRadiusScale(const double& Value) { Write<double>(uintptr_t(this) + 0x840, Value); } // 0x840 (Size: 0x8, Type: DoubleProperty)
    void SET_NextRadiusScale(const double& Value) { Write<double>(uintptr_t(this) + 0x848, Value); } // 0x848 (Size: 0x8, Type: DoubleProperty)
    void SET_BiasPowerCurve(const double& Value) { Write<double>(uintptr_t(this) + 0x850, Value); } // 0x850 (Size: 0x8, Type: DoubleProperty)
    void SET_PhaseInfoArray(const TArray<double>& Value) { Write<TArray<double>>(uintptr_t(this) + 0x858, Value); } // 0x858 (Size: 0x10, Type: ArrayProperty)
    void SET_initializedPhaseInfo(const bool& Value) { Write<bool>(uintptr_t(this) + 0x868, Value); } // 0x868 (Size: 0x1, Type: BoolProperty)
    void SET_CloudStartBiasHeadStart(const double& Value) { Write<double>(uintptr_t(this) + 0x870, Value); } // 0x870 (Size: 0x8, Type: DoubleProperty)
    void SET_bWarmUpFinished(const bool& Value) { Write<bool>(uintptr_t(this) + 0x878, Value); } // 0x878 (Size: 0x1, Type: BoolProperty)
    void SET_RadiusInfoArray(const TArray<double>& Value) { Write<TArray<double>>(uintptr_t(this) + 0x880, Value); } // 0x880 (Size: 0x10, Type: ArrayProperty)
    void SET_bLatchWarmUp(const bool& Value) { Write<bool>(uintptr_t(this) + 0x890, Value); } // 0x890 (Size: 0x1, Type: BoolProperty)
    void SET_StormRotatorActor(const ABP_StormMeshRotator_C*& Value) { Write<ABP_StormMeshRotator_C*>(uintptr_t(this) + 0x898, Value); } // 0x898 (Size: 0x8, Type: ObjectProperty)
    void SET_PawnRef(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x8a0, Value); } // 0x8a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Saved_Radius_for_Hiding(const double& Value) { Write<double>(uintptr_t(this) + 0x8a8, Value); } // 0x8a8 (Size: 0x8, Type: DoubleProperty)
    void SET_Saved_Shrink_for_Hiding(const double& Value) { Write<double>(uintptr_t(this) + 0x8b0, Value); } // 0x8b0 (Size: 0x8, Type: DoubleProperty)
    void SET_Saved_Bias_for_Hiding(const double& Value) { Write<double>(uintptr_t(this) + 0x8b8, Value); } // 0x8b8 (Size: 0x8, Type: DoubleProperty)
    void SET_Saved_MID_Opacity_for_Hiding(const double& Value) { Write<double>(uintptr_t(this) + 0x8c0, Value); } // 0x8c0 (Size: 0x8, Type: DoubleProperty)
    void SET_Saved_MPC_Opacity_for_Hiding(const double& Value) { Write<double>(uintptr_t(this) + 0x8c8, Value); } // 0x8c8 (Size: 0x8, Type: DoubleProperty)
    void SET_Transition_Time(const double& Value) { Write<double>(uintptr_t(this) + 0x8d0, Value); } // 0x8d0 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x690
class UAthena_GamePhaseLogic_C : public UFortGameStateComponent_BattleRoyaleGamePhaseLogic
{
public:
};

// Size: 0x3a28
class AAthena_GameState_C : public AFortGameStateBR
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3a10); } // 0x3a10 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x3a18); } // 0x3a18 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Victory_Royale_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x3a20); } // 0x3a20 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3a10, Value); } // 0x3a10 (Size: 0x8, Type: StructProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x3a18, Value); } // 0x3a18 (Size: 0x8, Type: ObjectProperty)
    void SET_Victory_Royale_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x3a20, Value); } // 0x3a20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3b8
class ABP_StormMeshRotator_C : public AFortStormRotator
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* Sphere() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* stormCircleLowerSheet() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_stormCircleTopRim() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    URotatingMovementComponent* RotatingMovement() const { return Read<URotatingMovementComponent*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_stormCircleNew() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    double RotationSpeed() const { return Read<double>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: DoubleProperty)
    double BoundsScale() const { return Read<double>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: DoubleProperty)
    double StormProgression() const { return Read<double>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: DoubleProperty)
    bool TestStorm() const { return Read<bool>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x1, Type: BoolProperty)
    bool isMobileStormEnabled() const { return Read<bool>(uintptr_t(this) + 0x2f9); } // 0x2f9 (Size: 0x1, Type: BoolProperty)
    bool areStormEffectsEnabled() const { return Read<bool>(uintptr_t(this) + 0x2fa); } // 0x2fa (Size: 0x1, Type: BoolProperty)
    bool bOverrideMaterialParams() const { return Read<bool>(uintptr_t(this) + 0x2fb); } // 0x2fb (Size: 0x1, Type: BoolProperty)
    UMaterialInstanceDynamic* MIDStormMain() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* MIDStormLower() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x308); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstanceDynamic* MIDStormTop() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    FLinearColor CloudColorDark() const { return Read<FLinearColor>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x10, Type: StructProperty)
    FLinearColor CloudColorLight() const { return Read<FLinearColor>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x10, Type: StructProperty)
    FLinearColor BackScatteringColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x10, Type: StructProperty)
    FLinearColor FresnelColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x10, Type: StructProperty)
    FLinearColor SunScatteringDay() const { return Read<FLinearColor>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x10, Type: StructProperty)
    FLinearColor SunScatteringEvening() const { return Read<FLinearColor>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x10, Type: StructProperty)
    FLinearColor SunScatteringMorning() const { return Read<FLinearColor>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x10, Type: StructProperty)
    FLinearColor SunScatteringNight() const { return Read<FLinearColor>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x10, Type: StructProperty)
    FLinearColor LightningColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x10, Type: StructProperty)
    FLinearColor SecondaryClouds() const { return Read<FLinearColor>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x10, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    void SET_Sphere(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_stormCircleLowerSheet(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_SM_stormCircleTopRim(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_RotatingMovement(const URotatingMovementComponent*& Value) { Write<URotatingMovementComponent*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_SM_stormCircleNew(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_RotationSpeed(const double& Value) { Write<double>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: DoubleProperty)
    void SET_BoundsScale(const double& Value) { Write<double>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: DoubleProperty)
    void SET_StormProgression(const double& Value) { Write<double>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: DoubleProperty)
    void SET_TestStorm(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x1, Type: BoolProperty)
    void SET_isMobileStormEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2f9, Value); } // 0x2f9 (Size: 0x1, Type: BoolProperty)
    void SET_areStormEffectsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2fa, Value); } // 0x2fa (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideMaterialParams(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2fb, Value); } // 0x2fb (Size: 0x1, Type: BoolProperty)
    void SET_MIDStormMain(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x8, Type: ObjectProperty)
    void SET_MIDStormLower(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x308, Value); } // 0x308 (Size: 0x8, Type: ObjectProperty)
    void SET_MIDStormTop(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x8, Type: ObjectProperty)
    void SET_CloudColorDark(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x10, Type: StructProperty)
    void SET_CloudColorLight(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x10, Type: StructProperty)
    void SET_BackScatteringColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x10, Type: StructProperty)
    void SET_FresnelColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x10, Type: StructProperty)
    void SET_SunScatteringDay(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x10, Type: StructProperty)
    void SET_SunScatteringEvening(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x10, Type: StructProperty)
    void SET_SunScatteringMorning(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x10, Type: StructProperty)
    void SET_SunScatteringNight(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x10, Type: StructProperty)
    void SET_LightningColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x10, Type: StructProperty)
    void SET_SecondaryClouds(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x10, Type: StructProperty)
};

// Size: 0x5998
class AAthena_PlayerController_C : public AFortPlayerControllerAthena
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x5850); } // 0x5850 (Size: 0x8, Type: StructProperty)
    UUnderwaterAudioComponent_C* UnderwaterAudioComponent() const { return Read<UUnderwaterAudioComponent_C*>(uintptr_t(this) + 0x5858); } // 0x5858 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* ListenerOverride() const { return Read<USceneComponent*>(uintptr_t(this) + 0x5860); } // 0x5860 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* VictoryRoyaleAudio() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x5868); } // 0x5868 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* VictoryRoyaleMusic1() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x5870); } // 0x5870 (Size: 0x8, Type: ObjectProperty)
    USoundBase* CurrentMusic() const { return Read<USoundBase*>(uintptr_t(this) + 0x5878); } // 0x5878 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer BladeWielderTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x5880); } // 0x5880 (Size: 0x20, Type: StructProperty)
    uint8_t InteractingItemType() const { return Read<uint8_t>(uintptr_t(this) + 0x58a0); } // 0x58a0 (Size: 0x1, Type: EnumProperty)
    FGameplayTagContainer InteractionTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x58a8); } // 0x58a8 (Size: 0x20, Type: StructProperty)
    FTimerHandle PermissionsRecheckTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x58d8); } // 0x58d8 (Size: 0x8, Type: StructProperty)
    USoundMix* CamUnderwaterSoundMix() const { return Read<USoundMix*>(uintptr_t(this) + 0x58e0); } // 0x58e0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* CamUnderwaterLoopSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x58e8); } // 0x58e8 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* CamUnderwaterAudio() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x58f0); } // 0x58f0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* CamUnderwaterStartSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x58f8); } // 0x58f8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* CamUnderwaterStopSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x5900); } // 0x5900 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* VictoryRoyaleMusic2() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x5908); } // 0x5908 (Size: 0x8, Type: ObjectProperty)
    double LobbyMusicOnVictoryDelayTime_Default() const { return Read<double>(uintptr_t(this) + 0x5910); } // 0x5910 (Size: 0x8, Type: DoubleProperty)
    FFortCreativeOptionBundleTableRow CreativeOptionBundleTableRow() const { return Read<FFortCreativeOptionBundleTableRow>(uintptr_t(this) + 0x5918); } // 0x5918 (Size: 0x28, Type: StructProperty)
    FScalableFloat PlayVictoryLobbyMusic_() const { return Read<FScalableFloat>(uintptr_t(this) + 0x5960); } // 0x5960 (Size: 0x28, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x5850, Value); } // 0x5850 (Size: 0x8, Type: StructProperty)
    void SET_UnderwaterAudioComponent(const UUnderwaterAudioComponent_C*& Value) { Write<UUnderwaterAudioComponent_C*>(uintptr_t(this) + 0x5858, Value); } // 0x5858 (Size: 0x8, Type: ObjectProperty)
    void SET_ListenerOverride(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x5860, Value); } // 0x5860 (Size: 0x8, Type: ObjectProperty)
    void SET_VictoryRoyaleAudio(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x5868, Value); } // 0x5868 (Size: 0x8, Type: ObjectProperty)
    void SET_VictoryRoyaleMusic1(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x5870, Value); } // 0x5870 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentMusic(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x5878, Value); } // 0x5878 (Size: 0x8, Type: ObjectProperty)
    void SET_BladeWielderTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x5880, Value); } // 0x5880 (Size: 0x20, Type: StructProperty)
    void SET_InteractingItemType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x58a0, Value); } // 0x58a0 (Size: 0x1, Type: EnumProperty)
    void SET_InteractionTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x58a8, Value); } // 0x58a8 (Size: 0x20, Type: StructProperty)
    void SET_PermissionsRecheckTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x58d8, Value); } // 0x58d8 (Size: 0x8, Type: StructProperty)
    void SET_CamUnderwaterSoundMix(const USoundMix*& Value) { Write<USoundMix*>(uintptr_t(this) + 0x58e0, Value); } // 0x58e0 (Size: 0x8, Type: ObjectProperty)
    void SET_CamUnderwaterLoopSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x58e8, Value); } // 0x58e8 (Size: 0x8, Type: ObjectProperty)
    void SET_CamUnderwaterAudio(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x58f0, Value); } // 0x58f0 (Size: 0x8, Type: ObjectProperty)
    void SET_CamUnderwaterStartSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x58f8, Value); } // 0x58f8 (Size: 0x8, Type: ObjectProperty)
    void SET_CamUnderwaterStopSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x5900, Value); } // 0x5900 (Size: 0x8, Type: ObjectProperty)
    void SET_VictoryRoyaleMusic2(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x5908, Value); } // 0x5908 (Size: 0x8, Type: ObjectProperty)
    void SET_LobbyMusicOnVictoryDelayTime_Default(const double& Value) { Write<double>(uintptr_t(this) + 0x5910, Value); } // 0x5910 (Size: 0x8, Type: DoubleProperty)
    void SET_CreativeOptionBundleTableRow(const FFortCreativeOptionBundleTableRow& Value) { Write<FFortCreativeOptionBundleTableRow>(uintptr_t(this) + 0x5918, Value); } // 0x5918 (Size: 0x28, Type: StructProperty)
    void SET_PlayVictoryLobbyMusic_(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x5960, Value); } // 0x5960 (Size: 0x28, Type: StructProperty)
};

// Size: 0x9f8
class AGCN_Loop_PlayerWorldPFX_Persistent_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    UNiagaraComponent* NS_Loop_WorldFX_Persistent_Motes01() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* NS_Loop_WorldFX_Persistent() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    AActor* My_Target() const { return Read<AActor*>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle Timer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: StructProperty)
    double LoopingCheckTime() const { return Read<double>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_NS_Loop_WorldFX_Persistent_Motes01(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_NS_Loop_WorldFX_Persistent(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    void SET_My_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Timer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: StructProperty)
    void SET_LoopingCheckTime(const double& Value) { Write<double>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x1f0
class UCamShake_Spooky_Dive_C : public ULegacyCameraShake
{
public:
};

// Size: 0xa20
class AGCNL_Athena_FallDamageImmunity_C : public AFortGameplayCueNotifyAthena_FallDamageImmunity
{
public:
    UAudioComponent* InUseLoopAudio() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xa10); } // 0xa10 (Size: 0x8, Type: ObjectProperty)
    AActor* Target() const { return Read<AActor*>(uintptr_t(this) + 0xa18); } // 0xa18 (Size: 0x8, Type: ObjectProperty)

    void SET_InUseLoopAudio(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xa10, Value); } // 0xa10 (Size: 0x8, Type: ObjectProperty)
    void SET_Target(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xa18, Value); } // 0xa18 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x780
class UMissionGen_CreativeMMS_C : public UFortMissionGenerator
{
public:
};

// Size: 0x40
class UTextScrollStyle_Base_Ticker_C : public UCommonTextScrollStyle
{
public:
};

// Size: 0xb98
class AGCN_Loop_Shadow_Bomb_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    float Timeline_0_Visbility_E1DFEC9547FE3FAED2AFF3B0D8598182() const { return Read<float>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_E1DFEC9547FE3FAED2AFF3B0D8598182() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_0() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* TargetPlayer() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    double ExpirationSoundPeriod() const { return Read<double>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: DoubleProperty)
    double VelocityInterp() const { return Read<double>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x8, Type: DoubleProperty)
    TArray<UParticleSystemComponent*> AttachedFX() const { return Read<TArray<UParticleSystemComponent*>>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x10, Type: ArrayProperty)
    TArray<USkeletalMeshComponent*> PlayerSkeletalMeshes() const { return Read<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0xa08); } // 0xa08 (Size: 0x10, Type: ArrayProperty)
    bool FriendlyPlayer() const { return Read<bool>(uintptr_t(this) + 0xa18); } // 0xa18 (Size: 0x1, Type: BoolProperty)
    FTimerHandle ExpireTellDelayTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0xa20); } // 0xa20 (Size: 0x8, Type: StructProperty)
    FTimerHandle ExpirationSoundTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0xa28); } // 0xa28 (Size: 0x8, Type: StructProperty)
    double VisbilityLevel() const { return Read<double>(uintptr_t(this) + 0xa30); } // 0xa30 (Size: 0x8, Type: DoubleProperty)
    double WalkVisMultiplier() const { return Read<double>(uintptr_t(this) + 0xa38); } // 0xa38 (Size: 0x8, Type: DoubleProperty)
    double SprintVisMultiplier() const { return Read<double>(uintptr_t(this) + 0xa40); } // 0xa40 (Size: 0x8, Type: DoubleProperty)
    double MinFriendlyOpacity() const { return Read<double>(uintptr_t(this) + 0xa48); } // 0xa48 (Size: 0x8, Type: DoubleProperty)
    double InteractVisibility() const { return Read<double>(uintptr_t(this) + 0xa50); } // 0xa50 (Size: 0x8, Type: DoubleProperty)
    FScalableFloat DataDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa58); } // 0xa58 (Size: 0x28, Type: StructProperty)
    FScalableFloat DataTellDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0xa80); } // 0xa80 (Size: 0x28, Type: StructProperty)
    FScalableFloat DataWalkVisMult() const { return Read<FScalableFloat>(uintptr_t(this) + 0xaa8); } // 0xaa8 (Size: 0x28, Type: StructProperty)
    FScalableFloat DataSprintVisMult() const { return Read<FScalableFloat>(uintptr_t(this) + 0xad0); } // 0xad0 (Size: 0x28, Type: StructProperty)
    FScalableFloat DataFriendlyVisMult() const { return Read<FScalableFloat>(uintptr_t(this) + 0xaf8); } // 0xaf8 (Size: 0x28, Type: StructProperty)
    FScalableFloat DataShadowPlaneOpacity() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb20); } // 0xb20 (Size: 0x28, Type: StructProperty)
    UTimelineComponent* FadeInOut() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0xb48); } // 0xb48 (Size: 0x8, Type: ObjectProperty)
    bool TickENabled() const { return Read<bool>(uintptr_t(this) + 0xb50); } // 0xb50 (Size: 0x1, Type: BoolProperty)
    FScalableFloat SmokeBombDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb58); } // 0xb58 (Size: 0x28, Type: StructProperty)
    double TellDuration() const { return Read<double>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: DoubleProperty)
    double ExpireTellOpacity() const { return Read<double>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x8, Type: DoubleProperty)
    double SmokeBombDurationUserSpecified() const { return Read<double>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_Timeline_0_Visbility_E1DFEC9547FE3FAED2AFF3B0D8598182(const float& Value) { Write<float>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_0__Direction_E1DFEC9547FE3FAED2AFF3B0D8598182(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4, Value); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_0(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetPlayer(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    void SET_ExpirationSoundPeriod(const double& Value) { Write<double>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: DoubleProperty)
    void SET_VelocityInterp(const double& Value) { Write<double>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x8, Type: DoubleProperty)
    void SET_AttachedFX(const TArray<UParticleSystemComponent*>& Value) { Write<TArray<UParticleSystemComponent*>>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x10, Type: ArrayProperty)
    void SET_PlayerSkeletalMeshes(const TArray<USkeletalMeshComponent*>& Value) { Write<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0xa08, Value); } // 0xa08 (Size: 0x10, Type: ArrayProperty)
    void SET_FriendlyPlayer(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa18, Value); } // 0xa18 (Size: 0x1, Type: BoolProperty)
    void SET_ExpireTellDelayTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xa20, Value); } // 0xa20 (Size: 0x8, Type: StructProperty)
    void SET_ExpirationSoundTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xa28, Value); } // 0xa28 (Size: 0x8, Type: StructProperty)
    void SET_VisbilityLevel(const double& Value) { Write<double>(uintptr_t(this) + 0xa30, Value); } // 0xa30 (Size: 0x8, Type: DoubleProperty)
    void SET_WalkVisMultiplier(const double& Value) { Write<double>(uintptr_t(this) + 0xa38, Value); } // 0xa38 (Size: 0x8, Type: DoubleProperty)
    void SET_SprintVisMultiplier(const double& Value) { Write<double>(uintptr_t(this) + 0xa40, Value); } // 0xa40 (Size: 0x8, Type: DoubleProperty)
    void SET_MinFriendlyOpacity(const double& Value) { Write<double>(uintptr_t(this) + 0xa48, Value); } // 0xa48 (Size: 0x8, Type: DoubleProperty)
    void SET_InteractVisibility(const double& Value) { Write<double>(uintptr_t(this) + 0xa50, Value); } // 0xa50 (Size: 0x8, Type: DoubleProperty)
    void SET_DataDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa58, Value); } // 0xa58 (Size: 0x28, Type: StructProperty)
    void SET_DataTellDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xa80, Value); } // 0xa80 (Size: 0x28, Type: StructProperty)
    void SET_DataWalkVisMult(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xaa8, Value); } // 0xaa8 (Size: 0x28, Type: StructProperty)
    void SET_DataSprintVisMult(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xad0, Value); } // 0xad0 (Size: 0x28, Type: StructProperty)
    void SET_DataFriendlyVisMult(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xaf8, Value); } // 0xaf8 (Size: 0x28, Type: StructProperty)
    void SET_DataShadowPlaneOpacity(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb20, Value); } // 0xb20 (Size: 0x28, Type: StructProperty)
    void SET_FadeInOut(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0xb48, Value); } // 0xb48 (Size: 0x8, Type: ObjectProperty)
    void SET_TickENabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb50, Value); } // 0xb50 (Size: 0x1, Type: BoolProperty)
    void SET_SmokeBombDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb58, Value); } // 0xb58 (Size: 0x28, Type: StructProperty)
    void SET_TellDuration(const double& Value) { Write<double>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: DoubleProperty)
    void SET_ExpireTellOpacity(const double& Value) { Write<double>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x8, Type: DoubleProperty)
    void SET_SmokeBombDurationUserSpecified(const double& Value) { Write<double>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xa88
class AGC_Athena_OutsideSafeZone_Stage03_C : public AGC_Athena_OutsideSafeZone_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa80); } // 0xa80 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xa80, Value); } // 0xa80 (Size: 0x8, Type: StructProperty)
};

// Size: 0xa79
class AGC_Athena_OutsideSafeZone_Stage02_C : public AGC_Athena_OutsideSafeZone_C
{
public:
};

// Size: 0xf0
class UFortTimeDilationComponent_C : public UFortGameStateComponent_TimeDilation
{
public:
};

// Size: 0x218
class UGCN_Tether_Smash_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0xb88
class AGCN_Loop_SpookyMist_C : public AFortGameplayCueNotifyLoop_SpookyMist
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    UPostProcessComponent* PostProcess() const { return Read<UPostProcessComponent*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    float Timeline_Interaction_Fade_In_Out_Visbility_5529D6B24898E091AFB4668B43CFAB50() const { return Read<float>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_Interaction_Fade_In_Out__Direction_5529D6B24898E091AFB4668B43CFAB50() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xb7c); } // 0xb7c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_Interaction_Fade_In_Out() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_PostProcess(const UPostProcessComponent*& Value) { Write<UPostProcessComponent*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_Timeline_Interaction_Fade_In_Out_Visbility_5529D6B24898E091AFB4668B43CFAB50(const float& Value) { Write<float>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_Interaction_Fade_In_Out__Direction_5529D6B24898E091AFB4668B43CFAB50(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xb7c, Value); } // 0xb7c (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_Interaction_Fade_In_Out(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb68
class AGCNL_MovementEffects_BeachBall_C : public AGCNL_RollingEffects_Parent_C
{
public:
};

// Size: 0xb70
class AGCNL_RollingEffects_PhysicsTree_C : public AGCNL_RollingEffects_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
};

// Size: 0xb68
class AGCNL_RollingEffects_Wood_C : public AGCNL_RollingEffects_Parent_C
{
public:
};

// Size: 0xb68
class AGCNL_RollingEffects_Generic_C : public AGCNL_RollingEffects_Parent_C
{
public:
};

// Size: 0x370
class UGCN_CollisionEffects_GiantBeachBall_C : public UGCN_CollisionEffects_Parent_C
{
public:
};

// Size: 0x228
class UGCN_MultiInteractionAdd_C : public UFortGameplayCueNotify_Burst
{
public:
    USoundBase* DBNO_Player_Joined_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Default_Player_Joined_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x8, Type: ObjectProperty)

    void SET_DBNO_Player_Joined_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x8, Type: ObjectProperty)
    void SET_Default_Player_Joined_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x9f0
class AGCNL_Athena_ChromeSurface_C : public AGCNL_Athena_Surface_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* LocalTarget() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: StructProperty)
    void SET_LocalTarget(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x228
class UGCN_MultiInteractionRemove_C : public UFortGameplayCueNotify_Burst
{
public:
    USoundBase* DBNO_Player_Removed_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Default_Player_Removed_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x220); } // 0x220 (Size: 0x8, Type: ObjectProperty)

    void SET_DBNO_Player_Removed_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x8, Type: ObjectProperty)
    void SET_Default_Player_Removed_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x220, Value); } // 0x220 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x218
class UGCN_Athena_HidingProp_WilliePete_ExitPlayer_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x218
class UGCN_Athena_HidingProp_WilliePete_LoopingTeleporting_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x9c8
class AGCNL_Athena_Consumable_Throw_Cook_Generic_C : public AFortGameplayCueNotify_Loop
{
public:
};

// Size: 0x218
class UGCN_Athena_Consumable_Throw_Generic_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x218
class UGCN_Zipline_ApplyBrakes_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x1f0
class UCameraShake_ZipLine_ReversedMomentum_C : public ULegacyCameraShake
{
public:
};

// Size: 0xac8
class AGCNL_Zipline_Travel_C : public AFortGameplayCueNotifyLoop_ZiplineTravel
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xaa8); } // 0xaa8 (Size: 0x8, Type: StructProperty)
    UAudioComponent* AttachSoundAudioComp() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xab0); } // 0xab0 (Size: 0x8, Type: ObjectProperty)
    TArray<bool> NewVar_0() const { return Read<TArray<bool>>(uintptr_t(this) + 0xab8); } // 0xab8 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xaa8, Value); } // 0xaa8 (Size: 0x8, Type: StructProperty)
    void SET_AttachSoundAudioComp(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xab0, Value); } // 0xab0 (Size: 0x8, Type: ObjectProperty)
    void SET_NewVar_0(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0xab8, Value); } // 0xab8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x218
class UGCN_Athena_SCMachine_CDEnd_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0xb20
class UVehicleConfigsJackal_BR_C : public UFortAthenaJackalVehicleConfigs
{
public:
};

// Size: 0x218
class UGCN_Athena_SCMachine_HoloTransition_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x9d0
class AGCNL_Athena_SCMachine_Active_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
};

// Size: 0xa08
class AGCNL_MegaStorm_DamageRing_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    float Timeline_1_StormDamage_20EF97A841793BC1BC17A38E68D1694B() const { return Read<float>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_1__Direction_20EF97A841793BC1BC17A38E68D1694B() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_1() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    float Timeline_0_StormDamage_217AB728482679C9E1B9D281A03AF2D6() const { return Read<float>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_217AB728482679C9E1B9D281A03AF2D6() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9e4); } // 0x9e4 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_0() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* StormDamageFX() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x8, Type: ObjectProperty)
    double RawMagnitude() const { return Read<double>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x8, Type: DoubleProperty)
    USoundBase* OnDamageSound() const { return Read<USoundBase*>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_Timeline_1_StormDamage_20EF97A841793BC1BC17A38E68D1694B(const float& Value) { Write<float>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_1__Direction_20EF97A841793BC1BC17A38E68D1694B(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4, Value); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_1(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Timeline_0_StormDamage_217AB728482679C9E1B9D281A03AF2D6(const float& Value) { Write<float>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_0__Direction_217AB728482679C9E1B9D281A03AF2D6(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9e4, Value); } // 0x9e4 (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_0(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    void SET_StormDamageFX(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x8, Type: ObjectProperty)
    void SET_RawMagnitude(const double& Value) { Write<double>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x8, Type: DoubleProperty)
    void SET_OnDamageSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x218
class UGCN_Athena_SCMachine_Activate_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x218
class UGCN_Athena_SwimSprintBoost_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x1f0
class UB_Ground_CameraShake_Heavy_C : public ULegacyCameraShake
{
public:
};

// Size: 0x388
class UGCN_CollisionEffects_Water_GiantBeachBall_C : public UGCN_CollisionEffects_Parent_C
{
public:
    int32_t FXSize() const { return Read<int32_t>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x4, Type: IntProperty)
    TArray<UNiagaraSystem*> WaterSplash() const { return Read<TArray<UNiagaraSystem*>>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x10, Type: ArrayProperty)

    void SET_FXSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x4, Type: IntProperty)
    void SET_WaterSplash(const TArray<UNiagaraSystem*>& Value) { Write<TArray<UNiagaraSystem*>>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x388
class UGCN_CollisionEffects_Water_C : public UGCN_CollisionEffects_Parent_C
{
public:
    int32_t FXSize() const { return Read<int32_t>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x4, Type: IntProperty)
    TArray<UNiagaraSystem*> WaterSplash() const { return Read<TArray<UNiagaraSystem*>>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x10, Type: ArrayProperty)

    void SET_FXSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x4, Type: IntProperty)
    void SET_WaterSplash(const TArray<UNiagaraSystem*>& Value) { Write<TArray<UNiagaraSystem*>>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x370
class UGCN_CollisionEffects_Metal_C : public UGCN_CollisionEffects_Parent_C
{
public:
};

// Size: 0x370
class UGCN_CollisionEffects_Stone_C : public UGCN_CollisionEffects_Parent_C
{
public:
};

// Size: 0x370
class UGCN_CollisionEffects_Generic_C : public UGCN_CollisionEffects_Parent_C
{
public:
};

// Size: 0x370
class UGCN_CollisionEffects_PhysicsTree_C : public UGCN_CollisionEffects_Parent_C
{
public:
};

// Size: 0x370
class UGCN_CollisionEffects_Wood_C : public UGCN_CollisionEffects_Parent_C
{
public:
};

// Size: 0x218
class UGCN_Burst_Hot_Feet_Environmental_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x218
class UGCN_Athena_HidingProp_WilliePete_Exit_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x9c8
class AGCN_Loop_ColdBreath_V2_C : public AFortGameplayCueNotify_Loop
{
public:
};

// Size: 0x330
class AB_EmotePreviewDisplay_C : public AFortEmotePreviewActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: StructProperty)
    USceneComponent* Scene() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    UAthenaEmojiItemDefinition* EmojiItemDefinition() const { return Read<UAthenaEmojiItemDefinition*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UAnimMontage> Animation() const { return Read<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x20, Type: SoftObjectProperty)
    UFortMontageItemDefinitionBase* DanceOrEmojiItemDefinition() const { return Read<UFortMontageItemDefinitionBase*>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    FName StartSectionName() const { return Read<FName>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x4, Type: NameProperty)
    UAthenaShoutItemDefinition* ShoutItemDefinition() const { return Read<UAthenaShoutItemDefinition*>(uintptr_t(this) + 0x318); } // 0x318 (Size: 0x8, Type: ObjectProperty)
    TArray<UAudioComponent*> DynamicallySpawnedSounds() const { return Read<TArray<UAudioComponent*>>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: StructProperty)
    void SET_Scene(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_EmojiItemDefinition(const UAthenaEmojiItemDefinition*& Value) { Write<UAthenaEmojiItemDefinition*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Animation(const TSoftObjectPtr<UAnimMontage>& Value) { Write<TSoftObjectPtr<UAnimMontage>>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_DanceOrEmojiItemDefinition(const UFortMontageItemDefinitionBase*& Value) { Write<UFortMontageItemDefinitionBase*>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: ObjectProperty)
    void SET_StartSectionName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x4, Type: NameProperty)
    void SET_ShoutItemDefinition(const UAthenaShoutItemDefinition*& Value) { Write<UAthenaShoutItemDefinition*>(uintptr_t(this) + 0x318, Value); } // 0x318 (Size: 0x8, Type: ObjectProperty)
    void SET_DynamicallySpawnedSounds(const TArray<UAudioComponent*>& Value) { Write<TArray<UAudioComponent*>>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x3c8
class ABP_Frontend_ShopBG_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* StandardBackgroundPlane1() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StandardBackgroundPlane() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Cone() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Plane() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* Scene() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* BackgroundTexturePlane() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* VeryLargeBackgroundPlane() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* Scene_Signal() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    FRotator Rot_Intro() const { return Read<FRotator>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x18, Type: StructProperty)
    FRotator NextRot() const { return Read<FRotator>(uintptr_t(this) + 0x310); } // 0x310 (Size: 0x18, Type: StructProperty)
    FRotator Rot_0() const { return Read<FRotator>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x18, Type: StructProperty)
    FRotator Rot_2() const { return Read<FRotator>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x18, Type: StructProperty)
    double PlayRate() const { return Read<double>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: DoubleProperty)
    FRotator Rot_IntroStart() const { return Read<FRotator>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x18, Type: StructProperty)
    bool bHasEvent() const { return Read<bool>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x1, Type: BoolProperty)
    double YInitial() const { return Read<double>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: DoubleProperty)
    double YEnd() const { return Read<double>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: DoubleProperty)
    UMaterialInstanceDynamic* Mid() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    ACMSLobbyDirector_C* CMSDirector() const { return Read<ACMSLobbyDirector_C*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    FString BPEnvName() const { return Read<FString>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: StrProperty)
    bool ShopEntered() const { return Read<bool>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x1, Type: BoolProperty)
    FTimerHandle DonutSeqTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: StructProperty)
    AActor* DomeObstruction() const { return Read<AActor*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    void SET_StandardBackgroundPlane1(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_StandardBackgroundPlane(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Cone(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Plane(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x8, Type: ObjectProperty)
    void SET_Scene(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x8, Type: ObjectProperty)
    void SET_BackgroundTexturePlane(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: ObjectProperty)
    void SET_VeryLargeBackgroundPlane(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Scene_Signal(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: ObjectProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: ObjectProperty)
    void SET_Rot_Intro(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x18, Type: StructProperty)
    void SET_NextRot(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x310, Value); } // 0x310 (Size: 0x18, Type: StructProperty)
    void SET_Rot_0(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x18, Type: StructProperty)
    void SET_Rot_2(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x18, Type: StructProperty)
    void SET_PlayRate(const double& Value) { Write<double>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: DoubleProperty)
    void SET_Rot_IntroStart(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x18, Type: StructProperty)
    void SET_bHasEvent(const bool& Value) { Write<bool>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x1, Type: BoolProperty)
    void SET_YInitial(const double& Value) { Write<double>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: DoubleProperty)
    void SET_YEnd(const double& Value) { Write<double>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: DoubleProperty)
    void SET_Mid(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    void SET_CMSDirector(const ACMSLobbyDirector_C*& Value) { Write<ACMSLobbyDirector_C*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_BPEnvName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: StrProperty)
    void SET_ShopEntered(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x1, Type: BoolProperty)
    void SET_DonutSeqTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: StructProperty)
    void SET_DomeObstruction(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UPawnHighlight_Interface_C : public UInterface
{
public:
};

// Size: 0xa68
class UGE_SnowFlakes_PlayerEffect_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_VehicleDamage_PhysicsObject_Global_C : public UGet_DirectDamageParent_C
{
public:
};

// Size: 0xca8
class AProp_PhysicsBoulder_Granite_C : public AProp_PhysicsBoulder_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc80); } // 0xc80 (Size: 0x8, Type: StructProperty)
    UNiagaraSystem* NS_RollingEffects() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x8, Type: ObjectProperty)
    FName RollingEffectsVector3VarName() const { return Read<FName>(uintptr_t(this) + 0xc90); } // 0xc90 (Size: 0x4, Type: NameProperty)
    UNiagaraSystem* OnSpawnFX_One() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0xc98); } // 0xc98 (Size: 0x8, Type: ObjectProperty)
    UNiagaraSystem* OnSpawnFX_Two() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0xca0); } // 0xca0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc80, Value); } // 0xc80 (Size: 0x8, Type: StructProperty)
    void SET_NS_RollingEffects(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x8, Type: ObjectProperty)
    void SET_RollingEffectsVector3VarName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc90, Value); } // 0xc90 (Size: 0x4, Type: NameProperty)
    void SET_OnSpawnFX_One(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0xc98, Value); } // 0xc98 (Size: 0x8, Type: ObjectProperty)
    void SET_OnSpawnFX_Two(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0xca0, Value); } // 0xca0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x398
class AGCL_Rift_Teleport_C : public AFortGameplayCueNotify_Looping
{
public:
};

// Size: 0x398
class ABP_CameraLens_CrackExit_C : public AEmitterCameraLensEffectBase
{
public:
    UParticleSystemComponent* Portal() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)

    void SET_Portal(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x370
class UGCN_CollisionEffects_PhysicsBoulder_C : public UGCN_CollisionEffects_Parent_C
{
public:
};

// Size: 0xc88
class AProp_PhysicsBoulder_Desert_01_C : public AProp_PhysicsBoulder_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc80); } // 0xc80 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc80, Value); } // 0xc80 (Size: 0x8, Type: StructProperty)
};

// Size: 0xbbc
class UGA_Athena_HidingProp_HidingInProp_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer ChangeEquipmentTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x20, Type: StructProperty)
    FScalableFloat Row_bDisablePlayerCollision() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x28, Type: StructProperty)
    float WaitForRequiredTagTime() const { return Read<float>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x4, Type: FloatProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_ChangeEquipmentTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x20, Type: StructProperty)
    void SET_Row_bDisablePlayerCollision(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x28, Type: StructProperty)
    void SET_WaitForRequiredTagTime(const float& Value) { Write<float>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x28
class UAthenaQuestFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xa68
class UGE_Athena_Tethered_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Athena_Revive_C : public UGameplayEffect
{
public:
};

// Size: 0x330
class UFortFuelGaugeIndicator_C : public UFortFuelGaugeIndicator
{
public:
};

// Size: 0x370
class UAthenaGadgetFuelGauge_C : public UAthenaGadgetFuelWidget
{
public:
};

// Size: 0x1560
class USimpleCommonButton_C : public UCommonButtonLegacy
{
public:
};

// Size: 0x4f0
class UWBP_Sidebar_ExpressYourSupport_CoachMark_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    UWBP_UIKit_CoachMark_C* WBP_UIKit_CoachMark() const { return Read<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    void SET_WBP_UIKit_CoachMark(const UWBP_UIKit_CoachMark_C*& Value) { Write<UWBP_UIKit_CoachMark_C*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1560
class USimpleCommonButtonWithInput_C : public UCommonButtonLegacy
{
public:
};

// Size: 0x1f0
class UCameraShake_HitImpact_Vehicle_C : public ULegacyCameraShake
{
public:
};

// Size: 0xa08
class AGCNL_Zipline_Downhill_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    ULegacyCameraShake* matineeCamShake() const { return Read<ULegacyCameraShake*>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    double MinCamShakeAmp() const { return Read<double>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: DoubleProperty)
    double MaxCamShakeAmp() const { return Read<double>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: DoubleProperty)
    double MinCamShakeFreq() const { return Read<double>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x8, Type: DoubleProperty)
    double MaxCamShakeFreq() const { return Read<double>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle CameraShakeTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_matineeCamShake(const ULegacyCameraShake*& Value) { Write<ULegacyCameraShake*>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    void SET_MinCamShakeAmp(const double& Value) { Write<double>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxCamShakeAmp(const double& Value) { Write<double>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: DoubleProperty)
    void SET_MinCamShakeFreq(const double& Value) { Write<double>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxCamShakeFreq(const double& Value) { Write<double>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x8, Type: DoubleProperty)
    void SET_CameraShakeTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0x8, Type: StructProperty)
};

// Size: 0x1f0
class USpeed_CameraShakePerlin_C : public ULegacyCameraShake
{
public:
};

// Size: 0x218
class UGCN_Zipline_Smash_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0xa79
class AGC_Athena_OutsideSafeZone_C : public AFortGameplayCueNotifyLoop_OutsideSafeZone
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    UPointLightComponent* Random_Lighting_Light() const { return Read<UPointLightComponent*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    float LightningFlashTL_LERP_3FDEC95248645BE865DCD0840F99915A() const { return Read<float>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> LightningFlashTL__Direction_3FDEC95248645BE865DCD0840F99915A() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9dc); } // 0x9dc (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* LightningFlashTL() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Storm_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    double LightningFlashDiameter() const { return Read<double>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x8, Type: DoubleProperty)
    double LightningFlashHeight() const { return Read<double>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x8, Type: DoubleProperty)
    FVector Lightning_Spawn_Location() const { return Read<FVector>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0x18, Type: StructProperty)
    double _ChanceOfLightningMesh() const { return Read<double>(uintptr_t(this) + 0xa18); } // 0xa18 (Size: 0x8, Type: DoubleProperty)
    double Lightning_Intensity() const { return Read<double>(uintptr_t(this) + 0xa20); } // 0xa20 (Size: 0x8, Type: DoubleProperty)
    double LightningIntensityMin() const { return Read<double>(uintptr_t(this) + 0xa28); } // 0xa28 (Size: 0x8, Type: DoubleProperty)
    double LightningIntensityMax() const { return Read<double>(uintptr_t(this) + 0xa30); } // 0xa30 (Size: 0x8, Type: DoubleProperty)
    double LightningTimelinePlaySpeedMin() const { return Read<double>(uintptr_t(this) + 0xa38); } // 0xa38 (Size: 0x8, Type: DoubleProperty)
    double LightningTimelinePlaySpeedMax() const { return Read<double>(uintptr_t(this) + 0xa40); } // 0xa40 (Size: 0x8, Type: DoubleProperty)
    APlayerPawn_Athena_Generic_C* Player_Pawn() const { return Read<APlayerPawn_Athena_Generic_C*>(uintptr_t(this) + 0xa48); } // 0xa48 (Size: 0x8, Type: ObjectProperty)
    double LightningFlashRepeatDelayMin() const { return Read<double>(uintptr_t(this) + 0xa50); } // 0xa50 (Size: 0x8, Type: DoubleProperty)
    double LightningFlashRepeatDelayMax() const { return Read<double>(uintptr_t(this) + 0xa58); } // 0xa58 (Size: 0x8, Type: DoubleProperty)
    int32_t Storm_Stage() const { return Read<int32_t>(uintptr_t(this) + 0xa60); } // 0xa60 (Size: 0x4, Type: IntProperty)
    FGameplayTag StormAudioTag_Low() const { return Read<FGameplayTag>(uintptr_t(this) + 0xa64); } // 0xa64 (Size: 0x4, Type: StructProperty)
    FGameplayTag StormAudioTag_Medium() const { return Read<FGameplayTag>(uintptr_t(this) + 0xa68); } // 0xa68 (Size: 0x4, Type: StructProperty)
    FGameplayTag StormAudioTag_High() const { return Read<FGameplayTag>(uintptr_t(this) + 0xa6c); } // 0xa6c (Size: 0x4, Type: StructProperty)
    UAmbientAudioDataAsset* StormAudioBank() const { return Read<UAmbientAudioDataAsset*>(uintptr_t(this) + 0xa70); } // 0xa70 (Size: 0x8, Type: ObjectProperty)
    bool StormEffectsEnabled() const { return Read<bool>(uintptr_t(this) + 0xa78); } // 0xa78 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_Random_Lighting_Light(const UPointLightComponent*& Value) { Write<UPointLightComponent*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_LightningFlashTL_LERP_3FDEC95248645BE865DCD0840F99915A(const float& Value) { Write<float>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x4, Type: FloatProperty)
    void SET_LightningFlashTL__Direction_3FDEC95248645BE865DCD0840F99915A(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9dc, Value); } // 0x9dc (Size: 0x1, Type: ByteProperty)
    void SET_LightningFlashTL(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Storm_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    void SET_LightningFlashDiameter(const double& Value) { Write<double>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x8, Type: DoubleProperty)
    void SET_LightningFlashHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x8, Type: DoubleProperty)
    void SET_Lightning_Spawn_Location(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0x18, Type: StructProperty)
    void SET__ChanceOfLightningMesh(const double& Value) { Write<double>(uintptr_t(this) + 0xa18, Value); } // 0xa18 (Size: 0x8, Type: DoubleProperty)
    void SET_Lightning_Intensity(const double& Value) { Write<double>(uintptr_t(this) + 0xa20, Value); } // 0xa20 (Size: 0x8, Type: DoubleProperty)
    void SET_LightningIntensityMin(const double& Value) { Write<double>(uintptr_t(this) + 0xa28, Value); } // 0xa28 (Size: 0x8, Type: DoubleProperty)
    void SET_LightningIntensityMax(const double& Value) { Write<double>(uintptr_t(this) + 0xa30, Value); } // 0xa30 (Size: 0x8, Type: DoubleProperty)
    void SET_LightningTimelinePlaySpeedMin(const double& Value) { Write<double>(uintptr_t(this) + 0xa38, Value); } // 0xa38 (Size: 0x8, Type: DoubleProperty)
    void SET_LightningTimelinePlaySpeedMax(const double& Value) { Write<double>(uintptr_t(this) + 0xa40, Value); } // 0xa40 (Size: 0x8, Type: DoubleProperty)
    void SET_Player_Pawn(const APlayerPawn_Athena_Generic_C*& Value) { Write<APlayerPawn_Athena_Generic_C*>(uintptr_t(this) + 0xa48, Value); } // 0xa48 (Size: 0x8, Type: ObjectProperty)
    void SET_LightningFlashRepeatDelayMin(const double& Value) { Write<double>(uintptr_t(this) + 0xa50, Value); } // 0xa50 (Size: 0x8, Type: DoubleProperty)
    void SET_LightningFlashRepeatDelayMax(const double& Value) { Write<double>(uintptr_t(this) + 0xa58, Value); } // 0xa58 (Size: 0x8, Type: DoubleProperty)
    void SET_Storm_Stage(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xa60, Value); } // 0xa60 (Size: 0x4, Type: IntProperty)
    void SET_StormAudioTag_Low(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xa64, Value); } // 0xa64 (Size: 0x4, Type: StructProperty)
    void SET_StormAudioTag_Medium(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xa68, Value); } // 0xa68 (Size: 0x4, Type: StructProperty)
    void SET_StormAudioTag_High(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xa6c, Value); } // 0xa6c (Size: 0x4, Type: StructProperty)
    void SET_StormAudioBank(const UAmbientAudioDataAsset*& Value) { Write<UAmbientAudioDataAsset*>(uintptr_t(this) + 0xa70, Value); } // 0xa70 (Size: 0x8, Type: ObjectProperty)
    void SET_StormEffectsEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa78, Value); } // 0xa78 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1f0
class UB_DudeBro_VortexLoop_Shake_C : public ULegacyCameraShake
{
public:
};

// Size: 0x218
class UGCN_Athena_HidingProp_HayStack_WhileEntering_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0xad0
class AGCNL_Athena_SnowSurface_C : public AGCNL_Athena_Surface_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: StructProperty)
    UNiagaraComponent* FootStepFX() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    bool bNotValid() const { return Read<bool>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x1, Type: BoolProperty)
    bool bReplayMode() const { return Read<bool>(uintptr_t(this) + 0x9f1); } // 0x9f1 (Size: 0x1, Type: BoolProperty)
    AFortReplaySpectatorAthena* ReplayController() const { return Read<AFortReplaySpectatorAthena*>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)
    FGameplayCueParameters GCParameters() const { return Read<FGameplayCueParameters>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0xd0, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: StructProperty)
    void SET_FootStepFX(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    void SET_bNotValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x1, Type: BoolProperty)
    void SET_bReplayMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9f1, Value); } // 0x9f1 (Size: 0x1, Type: BoolProperty)
    void SET_ReplayController(const AFortReplaySpectatorAthena*& Value) { Write<AFortReplaySpectatorAthena*>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)
    void SET_GCParameters(const FGameplayCueParameters& Value) { Write<FGameplayCueParameters>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0xd0, Type: StructProperty)
};

// Size: 0x1f0
class UCameraShake_BigHit_C : public ULegacyCameraShake
{
public:
};

// Size: 0xa68
class UGE_VehicleDamage_PhysicsOnCollision_C : public UGet_DirectDamageParent_C
{
public:
};

// Size: 0x148
class UTT_Athena_FragGrenade_C : public UFortGameplayAbilityTooltip
{
public:
};

// Size: 0xa68
class UGE_ThrownConsumable_InWindup_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_SurfaceChange_Sand_Surface_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Athena_DBNO_HealthBonus_C : public UGameplayEffect
{
public:
};

// Size: 0xb7c
class UGA_Athena_Tethered_PassiveTriggered_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    FGameplayTag GCN_BoostTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x4, Type: StructProperty)
    FGameplayTag GCN_JumpTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb74); } // 0xb74 (Size: 0x4, Type: StructProperty)
    FGameplayTag ZiplineExit() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x4, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_GCN_BoostTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x4, Type: StructProperty)
    void SET_GCN_JumpTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb74, Value); } // 0xb74 (Size: 0x4, Type: StructProperty)
    void SET_ZiplineExit(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x4, Type: StructProperty)
};

// Size: 0xa68
class UGE_Athena_HidingProp_ExitingProp_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_AthenaInVehicle_C : public UGameplayEffect
{
public:
};

// Size: 0xb78
class UGA_Athena_RemoveIceFeetOnWater_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* Fort_Player_Pawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_Fort_Player_Pawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb98
class UGA_Vehicle_ExitHoldEvent_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    FGameplayTag EquippingCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x4, Type: StructProperty)
    AFortPlayerController* PlayerController() const { return Read<AFortPlayerController*>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    UAbilityTask_WaitGameplayEvent* OnHoldExitStartedAsyncTask() const { return Read<UAbilityTask_WaitGameplayEvent*>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    UAbilityTask_WaitGameplayEvent* OnHoldExitStoppedAsyncTask() const { return Read<UAbilityTask_WaitGameplayEvent*>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x8, Type: ObjectProperty)
    FActiveGameplayEffectHandle GameplayEffectHandle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_EquippingCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x4, Type: StructProperty)
    void SET_PlayerController(const AFortPlayerController*& Value) { Write<AFortPlayerController*>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    void SET_OnHoldExitStartedAsyncTask(const UAbilityTask_WaitGameplayEvent*& Value) { Write<UAbilityTask_WaitGameplayEvent*>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    void SET_OnHoldExitStoppedAsyncTask(const UAbilityTask_WaitGameplayEvent*& Value) { Write<UAbilityTask_WaitGameplayEvent*>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x8, Type: ObjectProperty)
    void SET_GameplayEffectHandle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x8, Type: StructProperty)
};

// Size: 0xb88
class UGA_SurfaceChange_Ice_IceCheckOnTimer_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* FortPlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle TraceTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: StructProperty)
    FTimerHandle OffIceTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_FortPlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_TraceTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: StructProperty)
    void SET_OffIceTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: StructProperty)
};

// Size: 0xa68
class UGE_Athena_DBNO_Start_C : public UGE_Map_Fortitude_To_Health_C
{
public:
};

// Size: 0x420
class AB_WilliePete_WaterBodyChild_C : public AFortWaterBodyActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x8, Type: StructProperty)
    UArrowComponent* Debug() const { return Read<UArrowComponent*>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x8, Type: StructProperty)
    void SET_Debug(const UArrowComponent*& Value) { Write<UArrowComponent*>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa68
class UGE_Blade_LeapSlam_BuildingDestroy_C : public UGET_DirectPhysicalDamage_C
{
public:
};

// Size: 0xa68
class UGE_HidingProp_DestroyStructure_C : public UGameplayEffect
{
public:
};

// Size: 0xbc0
class UGA_AthenaExitVehicle_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    FGameplayTag Keep_DBNO_players_in_Vehicles() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer Event_Damage_Died_Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x20, Type: StructProperty)
    FVehicleExitData VehicleExitData() const { return Read<FVehicleExitData>(uintptr_t(this) + 0xb98); } // 0xb98 (Size: 0x28, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_Keep_DBNO_players_in_Vehicles(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x4, Type: StructProperty)
    void SET_Event_Damage_Died_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x20, Type: StructProperty)
    void SET_VehicleExitData(const FVehicleExitData& Value) { Write<FVehicleExitData>(uintptr_t(this) + 0xb98, Value); } // 0xb98 (Size: 0x28, Type: StructProperty)
};

// Size: 0xb70
class UGA_AthenaEnterVehicle_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
};

// Size: 0xa68
class UGE_Athena_DBNO_DamageImmune_C : public UGE_Map_Fortitude_To_Health_C
{
public:
};

// Size: 0xb80
class UGA_DuelObserver_C : public UFortGameplayAbility_ObserveDuels
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: StructProperty)
};

// Size: 0xa68
class UGE_Athena_HidingProp_HidingInProp_C : public UGameplayEffect
{
public:
};

// Size: 0xc60
class UGA_Athena_ZipLine_ReachedEnd_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat MaxLateralSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x28, Type: StructProperty)
    FVector ImpulseVec() const { return Read<FVector>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x18, Type: StructProperty)
    FScalableFloat JumpVertStrength() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x28, Type: StructProperty)
    FScalableFloat LateralDamping() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbe0); } // 0xbe0 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxZiplineVel() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc08); } // 0xc08 (Size: 0x28, Type: StructProperty)
    bool Debug() const { return Read<bool>(uintptr_t(this) + 0xc30); } // 0xc30 (Size: 0x1, Type: BoolProperty)
    FScalableFloat MinJumpVertStrength() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x28, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_MaxLateralSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x28, Type: StructProperty)
    void SET_ImpulseVec(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x18, Type: StructProperty)
    void SET_JumpVertStrength(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x28, Type: StructProperty)
    void SET_LateralDamping(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbe0, Value); } // 0xbe0 (Size: 0x28, Type: StructProperty)
    void SET_MaxZiplineVel(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc08, Value); } // 0xc08 (Size: 0x28, Type: StructProperty)
    void SET_Debug(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc30, Value); } // 0xc30 (Size: 0x1, Type: BoolProperty)
    void SET_MinJumpVertStrength(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x28, Type: StructProperty)
};

// Size: 0xa68
class UGE_SD_SiphonEffect_HoT_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_SD_SiphonEffect_SoT_C : public UGameplayEffect
{
public:
};

// Size: 0xe58
class UGAB_SurfaceChange_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    bool Debug() const { return Read<bool>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x1, Type: BoolProperty)
    FScalableFloat RemovalDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x28, Type: StructProperty)
    FScalableFloat IcySurfacesEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x28, Type: StructProperty)
    FGameplayTagContainer HasIce() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x20, Type: StructProperty)
    UClass* GE_SurfaceChange_Ice() const { return Read<UClass*>(uintptr_t(this) + 0xbe8); } // 0xbe8 (Size: 0x8, Type: ClassProperty)
    UClass* GE_SurfaceChange_Snow() const { return Read<UClass*>(uintptr_t(this) + 0xbf0); } // 0xbf0 (Size: 0x8, Type: ClassProperty)
    UClass* GE_SurfaceChange_Lava() const { return Read<UClass*>(uintptr_t(this) + 0xbf8); } // 0xbf8 (Size: 0x8, Type: ClassProperty)
    AFortPawn* AvatarPawn() const { return Read<AFortPawn*>(uintptr_t(this) + 0xc00); } // 0xc00 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer IceTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc08); } // 0xc08 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer LavaTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer SnowTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc48); } // 0xc48 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer SandTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc68); } // 0xc68 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer ChromeTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x20, Type: StructProperty)
    double LavaBounceMultiplier() const { return Read<double>(uintptr_t(this) + 0xca8); } // 0xca8 (Size: 0x8, Type: DoubleProperty)
    double RandomAngleOffset() const { return Read<double>(uintptr_t(this) + 0xcb0); } // 0xcb0 (Size: 0x8, Type: DoubleProperty)
    FScalableFloat RandomConeAngle() const { return Read<FScalableFloat>(uintptr_t(this) + 0xcb8); } // 0xcb8 (Size: 0x28, Type: StructProperty)
    FScalableFloat FacingAngleVelocityComponent() const { return Read<FScalableFloat>(uintptr_t(this) + 0xce0); } // 0xce0 (Size: 0x28, Type: StructProperty)
    FScalableFloat BaseVerticalBounceVelocity() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd08); } // 0xd08 (Size: 0x28, Type: StructProperty)
    FScalableFloat BaseLateralBounceVelocity() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd30); } // 0xd30 (Size: 0x28, Type: StructProperty)
    FScalableFloat MaxBounceMultiplier() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd58); } // 0xd58 (Size: 0x28, Type: StructProperty)
    FScalableFloat BounceMultiplierStepAmount() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd80); } // 0xd80 (Size: 0x28, Type: StructProperty)
    FRandomStream RandomAngleStream() const { return Read<FRandomStream>(uintptr_t(this) + 0xda8); } // 0xda8 (Size: 0x8, Type: StructProperty)
    FGameplayTag LavaBounceCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xdb0); } // 0xdb0 (Size: 0x4, Type: StructProperty)
    FGameplayTag EventTag_SandUnburrow() const { return Read<FGameplayTag>(uintptr_t(this) + 0xdb4); } // 0xdb4 (Size: 0x4, Type: StructProperty)
    FScalableFloat IceLingerDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0xdb8); } // 0xdb8 (Size: 0x28, Type: StructProperty)
    FGameplayTagContainer PreviousSurfaceTagContainer() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xde0); } // 0xde0 (Size: 0x20, Type: StructProperty)
    UAsyncAction_StartListeningToStatefulEvent* GamePhaseUpdatedAsyncTask() const { return Read<UAsyncAction_StartListeningToStatefulEvent*>(uintptr_t(this) + 0xe00); } // 0xe00 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer LavaPeriodicDamageTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xe08); } // 0xe08 (Size: 0x20, Type: StructProperty)
    FScalableFloat LavaPeriodicDamageEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xe28); } // 0xe28 (Size: 0x28, Type: StructProperty)
    UAbilityTask_WaitGameplayEvent* Async_Task() const { return Read<UAbilityTask_WaitGameplayEvent*>(uintptr_t(this) + 0xe50); } // 0xe50 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_Debug(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x1, Type: BoolProperty)
    void SET_RemovalDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x28, Type: StructProperty)
    void SET_IcySurfacesEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x28, Type: StructProperty)
    void SET_HasIce(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x20, Type: StructProperty)
    void SET_GE_SurfaceChange_Ice(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xbe8, Value); } // 0xbe8 (Size: 0x8, Type: ClassProperty)
    void SET_GE_SurfaceChange_Snow(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xbf0, Value); } // 0xbf0 (Size: 0x8, Type: ClassProperty)
    void SET_GE_SurfaceChange_Lava(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xbf8, Value); } // 0xbf8 (Size: 0x8, Type: ClassProperty)
    void SET_AvatarPawn(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0xc00, Value); } // 0xc00 (Size: 0x8, Type: ObjectProperty)
    void SET_IceTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc08, Value); } // 0xc08 (Size: 0x20, Type: StructProperty)
    void SET_LavaTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x20, Type: StructProperty)
    void SET_SnowTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc48, Value); } // 0xc48 (Size: 0x20, Type: StructProperty)
    void SET_SandTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc68, Value); } // 0xc68 (Size: 0x20, Type: StructProperty)
    void SET_ChromeTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x20, Type: StructProperty)
    void SET_LavaBounceMultiplier(const double& Value) { Write<double>(uintptr_t(this) + 0xca8, Value); } // 0xca8 (Size: 0x8, Type: DoubleProperty)
    void SET_RandomAngleOffset(const double& Value) { Write<double>(uintptr_t(this) + 0xcb0, Value); } // 0xcb0 (Size: 0x8, Type: DoubleProperty)
    void SET_RandomConeAngle(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xcb8, Value); } // 0xcb8 (Size: 0x28, Type: StructProperty)
    void SET_FacingAngleVelocityComponent(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xce0, Value); } // 0xce0 (Size: 0x28, Type: StructProperty)
    void SET_BaseVerticalBounceVelocity(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd08, Value); } // 0xd08 (Size: 0x28, Type: StructProperty)
    void SET_BaseLateralBounceVelocity(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd30, Value); } // 0xd30 (Size: 0x28, Type: StructProperty)
    void SET_MaxBounceMultiplier(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd58, Value); } // 0xd58 (Size: 0x28, Type: StructProperty)
    void SET_BounceMultiplierStepAmount(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd80, Value); } // 0xd80 (Size: 0x28, Type: StructProperty)
    void SET_RandomAngleStream(const FRandomStream& Value) { Write<FRandomStream>(uintptr_t(this) + 0xda8, Value); } // 0xda8 (Size: 0x8, Type: StructProperty)
    void SET_LavaBounceCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xdb0, Value); } // 0xdb0 (Size: 0x4, Type: StructProperty)
    void SET_EventTag_SandUnburrow(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xdb4, Value); } // 0xdb4 (Size: 0x4, Type: StructProperty)
    void SET_IceLingerDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xdb8, Value); } // 0xdb8 (Size: 0x28, Type: StructProperty)
    void SET_PreviousSurfaceTagContainer(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xde0, Value); } // 0xde0 (Size: 0x20, Type: StructProperty)
    void SET_GamePhaseUpdatedAsyncTask(const UAsyncAction_StartListeningToStatefulEvent*& Value) { Write<UAsyncAction_StartListeningToStatefulEvent*>(uintptr_t(this) + 0xe00, Value); } // 0xe00 (Size: 0x8, Type: ObjectProperty)
    void SET_LavaPeriodicDamageTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xe08, Value); } // 0xe08 (Size: 0x20, Type: StructProperty)
    void SET_LavaPeriodicDamageEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xe28, Value); } // 0xe28 (Size: 0x28, Type: StructProperty)
    void SET_Async_Task(const UAbilityTask_WaitGameplayEvent*& Value) { Write<UAbilityTask_WaitGameplayEvent*>(uintptr_t(this) + 0xe50, Value); } // 0xe50 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa68
class UGE_SurfaceChange_Ice_Linger_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_SurfaceChange_Snow_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_SurfaceChange_Ice_C : public UGameplayEffect
{
public:
};

// Size: 0xbc0
class UGA_Athena_HidingProp_LandedOn_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    FScalableFloat HidingEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x28, Type: StructProperty)
    FScalableFloat Hiding_Enable_From_Landing() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb98); } // 0xb98 (Size: 0x28, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_HidingEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x28, Type: StructProperty)
    void SET_Hiding_Enable_From_Landing(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb98, Value); } // 0xb98 (Size: 0x28, Type: StructProperty)
};

// Size: 0xa68
class UGE_ZipLine_Damage_Structure_C : public UGET_DirectPhysicalDamage_C
{
public:
};

// Size: 0xa68
class UGE_DefaultResourceCap_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Rift_Athena_Teleport_C : public UGameplayEffect
{
public:
};

// Size: 0xc91
class UGA_NPC_Wildlife_Knockback_Player_C : public UGAB_GenericApplyKnockback_C
{
public:
};

// Size: 0xb90
class UGA_AthenaInVehicle_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer ExitTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x20, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_ExitTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x20, Type: StructProperty)
};

// Size: 0xa68
class UGE_Athena_PurpleStuff_Health_C : public UGameplayEffect
{
public:
};

// Size: 0xd5c
class UGA_SD_Siphon_Update_C : public UGAT_TriggeredAbility_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    UClass* HealthGE() const { return Read<UClass*>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x8, Type: ClassProperty)
    UClass* ShieldGE() const { return Read<UClass*>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x8, Type: ClassProperty)
    FScalableFloat SF_SiphonAmount() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb98); } // 0xb98 (Size: 0x28, Type: StructProperty)
    FGameplayTag ShieldHealGC() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x4, Type: StructProperty)
    FScalableFloat SF_SiphonHPFactor() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x28, Type: StructProperty)
    FScalableFloat SF_SiphonShieldFactor() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbf0); } // 0xbf0 (Size: 0x28, Type: StructProperty)
    FScalableFloat HealoverTimeEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x28, Type: StructProperty)
    FScalableFloat InstantHealthEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc40); } // 0xc40 (Size: 0x28, Type: StructProperty)
    double HoTAmount_Pool() const { return Read<double>(uintptr_t(this) + 0xc68); } // 0xc68 (Size: 0x8, Type: DoubleProperty)
    FScalableFloat SF_HoTSiphonAmount() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc70); } // 0xc70 (Size: 0x28, Type: StructProperty)
    double H_Sheild_Hot_Amount() const { return Read<double>(uintptr_t(this) + 0xc98); } // 0xc98 (Size: 0x8, Type: DoubleProperty)
    UClass* HoT_GE() const { return Read<UClass*>(uintptr_t(this) + 0xca0); } // 0xca0 (Size: 0x8, Type: ClassProperty)
    UClass* SoT_GE() const { return Read<UClass*>(uintptr_t(this) + 0xca8); } // 0xca8 (Size: 0x8, Type: ClassProperty)
    double Ho_THeal_Amount() const { return Read<double>(uintptr_t(this) + 0xcb0); } // 0xcb0 (Size: 0x8, Type: DoubleProperty)
    FScalableFloat HoTOnFactor() const { return Read<FScalableFloat>(uintptr_t(this) + 0xcb8); } // 0xcb8 (Size: 0x28, Type: StructProperty)
    FScalableFloat SoTOnFactor() const { return Read<FScalableFloat>(uintptr_t(this) + 0xce0); } // 0xce0 (Size: 0x28, Type: StructProperty)
    FScalableFloat SimShield() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd08); } // 0xd08 (Size: 0x28, Type: StructProperty)
    FScalableFloat BothTypesEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd30); } // 0xd30 (Size: 0x28, Type: StructProperty)
    FGameplayTag SiphonHealingGCTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd58); } // 0xd58 (Size: 0x4, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: StructProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    void SET_HealthGE(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x8, Type: ClassProperty)
    void SET_ShieldGE(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x8, Type: ClassProperty)
    void SET_SF_SiphonAmount(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb98, Value); } // 0xb98 (Size: 0x28, Type: StructProperty)
    void SET_ShieldHealGC(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x4, Type: StructProperty)
    void SET_SF_SiphonHPFactor(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x28, Type: StructProperty)
    void SET_SF_SiphonShieldFactor(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbf0, Value); } // 0xbf0 (Size: 0x28, Type: StructProperty)
    void SET_HealoverTimeEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x28, Type: StructProperty)
    void SET_InstantHealthEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc40, Value); } // 0xc40 (Size: 0x28, Type: StructProperty)
    void SET_HoTAmount_Pool(const double& Value) { Write<double>(uintptr_t(this) + 0xc68, Value); } // 0xc68 (Size: 0x8, Type: DoubleProperty)
    void SET_SF_HoTSiphonAmount(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc70, Value); } // 0xc70 (Size: 0x28, Type: StructProperty)
    void SET_H_Sheild_Hot_Amount(const double& Value) { Write<double>(uintptr_t(this) + 0xc98, Value); } // 0xc98 (Size: 0x8, Type: DoubleProperty)
    void SET_HoT_GE(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xca0, Value); } // 0xca0 (Size: 0x8, Type: ClassProperty)
    void SET_SoT_GE(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xca8, Value); } // 0xca8 (Size: 0x8, Type: ClassProperty)
    void SET_Ho_THeal_Amount(const double& Value) { Write<double>(uintptr_t(this) + 0xcb0, Value); } // 0xcb0 (Size: 0x8, Type: DoubleProperty)
    void SET_HoTOnFactor(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xcb8, Value); } // 0xcb8 (Size: 0x28, Type: StructProperty)
    void SET_SoTOnFactor(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xce0, Value); } // 0xce0 (Size: 0x28, Type: StructProperty)
    void SET_SimShield(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd08, Value); } // 0xd08 (Size: 0x28, Type: StructProperty)
    void SET_BothTypesEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd30, Value); } // 0xd30 (Size: 0x28, Type: StructProperty)
    void SET_SiphonHealingGCTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd58, Value); } // 0xd58 (Size: 0x4, Type: StructProperty)
};

// Size: 0xa68
class UGE_Athena_HidingProp_Teleporting_C : public UGameplayEffect
{
public:
};

// Size: 0x50
class UHidingProp_CameraModifier_C : public UCameraModifier
{
public:
    AFortPlayerPawn* Pawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x8, Type: ObjectProperty)

    void SET_Pawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa68
class UGE_Athena_PurpleStuff_Shields_C : public UGameplayEffect
{
public:
};

// Size: 0xb88
class UGAT_Athena_PurpleStuff_C : public UGAT_TriggeredAbility_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: StructProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3133
class UJackalVehicle_Hoverboard_Base_AnimBP_C : public UFortVehicleAnimInstance_Jackal
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x8, Type: StructProperty)
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables() const { return Read<FAnimBlueprintGeneratedMutableData>(uintptr_t(this) + 0x6e8); } // 0x6e8 (Size: 0x2c, Type: StructProperty)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess() const { return Read<FAnimSubsystemInstance>(uintptr_t(this) + 0x718); } // 0x718 (Size: 0x8, Type: StructProperty)
    FAnimSubsystemInstance AnimBlueprintExtension_Base() const { return Read<FAnimSubsystemInstance>(uintptr_t(this) + 0x720); } // 0x720 (Size: 0x8, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root() const { return Read<FAnimNode_Root>(uintptr_t(this) + 0x728); } // 0x728 (Size: 0x20, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_38() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x748); } // 0x748 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_37() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x770); } // 0x770 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_36() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x798); } // 0x798 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_35() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x7c0); } // 0x7c0 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_34() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x7e8); } // 0x7e8 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_33() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_32() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x838); } // 0x838 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_31() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x860); } // 0x860 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_30() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x888); } // 0x888 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_29() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x8b0); } // 0x8b0 (Size: 0x28, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_41() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x8d8); } // 0x8d8 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_40() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x920); } // 0x920 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_3() const { return Read<FAnimNode_BlendListByEnum>(uintptr_t(this) + 0x968); } // 0x968 (Size: 0x50, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_26() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x9b8); } // 0x9b8 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_39() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_25() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0xa20); } // 0xa20 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_38() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xa40); } // 0xa40 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_2() const { return Read<FAnimNode_BlendListByEnum>(uintptr_t(this) + 0xa88); } // 0xa88 (Size: 0x50, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_37() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xad8); } // 0xad8 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_24() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0xb20); } // 0xb20 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_36() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xb40); } // 0xb40 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_35() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_34() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xbd0); } // 0xbd0 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_33() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_32() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_14() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0xca8); } // 0xca8 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_13() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0xcf8); } // 0xcf8 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_12() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0xd48); } // 0xd48 (Size: 0x50, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_11() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0xd98); } // 0xd98 (Size: 0x50, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_31() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xde8); } // 0xde8 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_30() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xe30); } // 0xe30 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_29() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xe78); } // 0xe78 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum_1() const { return Read<FAnimNode_BlendListByEnum>(uintptr_t(this) + 0xec0); } // 0xec0 (Size: 0x50, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_23() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0xf10); } // 0xf10 (Size: 0x20, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_3() const { return Read<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0xf30); } // 0xf30 (Size: 0x70, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_28() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xfa0); } // 0xfa0 (Size: 0x48, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_4() const { return Read<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0xfe8); } // 0xfe8 (Size: 0xc8, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_22() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x10b0); } // 0x10b0 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_6() const { return Read<FAnimNode_StateMachine>(uintptr_t(this) + 0x10d0); } // 0x10d0 (Size: 0xc8, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_3() const { return Read<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0x1198); } // 0x1198 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2() const { return Read<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0x1260); } // 0x1260 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_10() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x12d0); } // 0x12d0 (Size: 0x50, Type: StructProperty)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3() const { return Read<FAnimNode_SaveCachedPose>(uintptr_t(this) + 0x1320); } // 0x1320 (Size: 0x78, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_2() const { return Read<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0x1398); } // 0x1398 (Size: 0xc8, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5() const { return Read<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x1460); } // 0x1460 (Size: 0x28, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4() const { return Read<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x1488); } // 0x1488 (Size: 0x28, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_1() const { return Read<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0x14b0); } // 0x14b0 (Size: 0xc8, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_27() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_1() const { return Read<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0x15c0); } // 0x15c0 (Size: 0x70, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_9() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1630); } // 0x1630 (Size: 0x50, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_26() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1680); } // 0x1680 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_8() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x16c8); } // 0x16c8 (Size: 0x50, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_25() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1718); } // 0x1718 (Size: 0x48, Type: StructProperty)
    FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend() const { return Read<FAnimNode_TwoWayBlend>(uintptr_t(this) + 0x1760); } // 0x1760 (Size: 0xc0, Type: StructProperty)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2() const { return Read<FAnimNode_SaveCachedPose>(uintptr_t(this) + 0x1820); } // 0x1820 (Size: 0x78, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_28() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1898); } // 0x1898 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_27() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x18c0); } // 0x18c0 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_26() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x18e8); } // 0x18e8 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_25() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1910); } // 0x1910 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_24() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1938); } // 0x1938 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_23() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1960); } // 0x1960 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_22() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1988); } // 0x1988 (Size: 0x28, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_24() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x19b0); } // 0x19b0 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_21() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x19f8); } // 0x19f8 (Size: 0x20, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_21() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1a18); } // 0x1a18 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_20() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1a40); } // 0x1a40 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_19() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1a68); } // 0x1a68 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_18() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1a90); } // 0x1a90 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_17() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1ab8); } // 0x1ab8 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_16() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1ae0); } // 0x1ae0 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_15() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1b08); } // 0x1b08 (Size: 0x28, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3() const { return Read<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x1b30); } // 0x1b30 (Size: 0x28, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_20() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x1b58); } // 0x1b58 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_23() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1b78); } // 0x1b78 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_7() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1bc0); } // 0x1bc0 (Size: 0x50, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_22() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1c10); } // 0x1c10 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_6() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1c58); } // 0x1c58 (Size: 0x50, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_21() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1ca8); } // 0x1ca8 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_19() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x1cf0); } // 0x1cf0 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_20() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1d10); } // 0x1d10 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_18() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x1d58); } // 0x1d58 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_19() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1d78); } // 0x1d78 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_5() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1dc0); } // 0x1dc0 (Size: 0x50, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_18() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1e10); } // 0x1e10 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_17() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1e58); } // 0x1e58 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_4() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1ea0); } // 0x1ea0 (Size: 0x50, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_17() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x1ef0); } // 0x1ef0 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_16() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1f10); } // 0x1f10 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1f58); } // 0x1f58 (Size: 0x50, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_15() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1fa8); } // 0x1fa8 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1ff0); } // 0x1ff0 (Size: 0x50, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_14() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2040); } // 0x2040 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_16() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x2088); } // 0x2088 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_5() const { return Read<FAnimNode_StateMachine>(uintptr_t(this) + 0x20a8); } // 0x20a8 (Size: 0xc8, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_15() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x2170); } // 0x2170 (Size: 0x20, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2() const { return Read<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x2190); } // 0x2190 (Size: 0x28, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_14() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x21b8); } // 0x21b8 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_4() const { return Read<FAnimNode_StateMachine>(uintptr_t(this) + 0x21d8); } // 0x21d8 (Size: 0xc8, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_13() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x22a0); } // 0x22a0 (Size: 0x20, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x22c0); } // 0x22c0 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x22e8); } // 0x22e8 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2310); } // 0x2310 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2338); } // 0x2338 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2360); } // 0x2360 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2388); } // 0x2388 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x23b0); } // 0x23b0 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x23d8); } // 0x23d8 (Size: 0x28, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_13() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2400); } // 0x2400 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_12() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x2448); } // 0x2448 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_12() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2468); } // 0x2468 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_11() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x24b0); } // 0x24b0 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_11() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x24d0); } // 0x24d0 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_10() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x2518); } // 0x2518 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_10() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2538); } // 0x2538 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_9() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x2580); } // 0x2580 (Size: 0x20, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_1() const { return Read<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x25a0); } // 0x25a0 (Size: 0x28, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_8() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x25c8); } // 0x25c8 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_3() const { return Read<FAnimNode_StateMachine>(uintptr_t(this) + 0x25e8); } // 0x25e8 (Size: 0xc8, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_7() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x26b0); } // 0x26b0 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_2() const { return Read<FAnimNode_StateMachine>(uintptr_t(this) + 0x26d0); } // 0x26d0 (Size: 0xc8, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2798); } // 0x2798 (Size: 0x48, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive() const { return Read<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0x27e0); } // 0x27e0 (Size: 0xc8, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_1() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x28a8); } // 0x28a8 (Size: 0x50, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x28f8); } // 0x28f8 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer() const { return Read<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0x2940); } // 0x2940 (Size: 0x70, Type: StructProperty)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_1() const { return Read<FAnimNode_SaveCachedPose>(uintptr_t(this) + 0x29b0); } // 0x29b0 (Size: 0x78, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2a28); } // 0x2a28 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2a50); } // 0x2a50 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2a78); } // 0x2a78 (Size: 0x28, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2aa0); } // 0x2aa0 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_6() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x2ae8); } // 0x2ae8 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2b08); } // 0x2b08 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_5() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x2b50); } // 0x2b50 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2b70); } // 0x2b70 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_4() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x2bb8); } // 0x2bb8 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine_1() const { return Read<FAnimNode_StateMachine>(uintptr_t(this) + 0x2bd8); } // 0x2bd8 (Size: 0xc8, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2ca0); } // 0x2ca0 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2cc8); } // 0x2cc8 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2cf0); } // 0x2cf0 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2d18); } // 0x2d18 (Size: 0x28, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose() const { return Read<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x2d40); } // 0x2d40 (Size: 0x28, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_3() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x2d68); } // 0x2d68 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2d88); } // 0x2d88 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_2() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x2dd0); } // 0x2dd0 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2df0); } // 0x2df0 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_1() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x2e38); } // 0x2e38 (Size: 0x20, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2e58); } // 0x2e58 (Size: 0x48, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2ea0); } // 0x2ea0 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum() const { return Read<FAnimNode_BlendListByEnum>(uintptr_t(this) + 0x2ee8); } // 0x2ee8 (Size: 0x50, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0x2f38); } // 0x2f38 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine() const { return Read<FAnimNode_StateMachine>(uintptr_t(this) + 0x2f58); } // 0x2f58 (Size: 0xc8, Type: StructProperty)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose() const { return Read<FAnimNode_SaveCachedPose>(uintptr_t(this) + 0x3020); } // 0x3020 (Size: 0x78, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x3098); } // 0x3098 (Size: 0x48, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x30e0); } // 0x30e0 (Size: 0x50, Type: StructProperty)
    uint8_t PrePivot() const { return Read<uint8_t>(uintptr_t(this) + 0x3130); } // 0x3130 (Size: 0x1, Type: EnumProperty)
    bool ShouldTrigerGrappleMontage() const { return Read<bool>(uintptr_t(this) + 0x3131); } // 0x3131 (Size: 0x1, Type: BoolProperty)
    bool AreFeetAttachedToBoard() const { return Read<bool>(uintptr_t(this) + 0x3132); } // 0x3132 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x8, Type: StructProperty)
    void SET___AnimBlueprintMutables(const FAnimBlueprintGeneratedMutableData& Value) { Write<FAnimBlueprintGeneratedMutableData>(uintptr_t(this) + 0x6e8, Value); } // 0x6e8 (Size: 0x2c, Type: StructProperty)
    void SET_AnimBlueprintExtension_PropertyAccess(const FAnimSubsystemInstance& Value) { Write<FAnimSubsystemInstance>(uintptr_t(this) + 0x718, Value); } // 0x718 (Size: 0x8, Type: StructProperty)
    void SET_AnimBlueprintExtension_Base(const FAnimSubsystemInstance& Value) { Write<FAnimSubsystemInstance>(uintptr_t(this) + 0x720, Value); } // 0x720 (Size: 0x8, Type: StructProperty)
    void SET_AnimGraphNode_Root(const FAnimNode_Root& Value) { Write<FAnimNode_Root>(uintptr_t(this) + 0x728, Value); } // 0x728 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_38(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x748, Value); } // 0x748 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_37(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x770, Value); } // 0x770 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_36(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x798, Value); } // 0x798 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_35(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x7c0, Value); } // 0x7c0 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_34(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x7e8, Value); } // 0x7e8 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_33(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_32(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x838, Value); } // 0x838 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_31(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x860, Value); } // 0x860 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_30(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x888, Value); } // 0x888 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_29(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x8b0, Value); } // 0x8b0 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_41(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x8d8, Value); } // 0x8d8 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_40(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x920, Value); } // 0x920 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByEnum_3(const FAnimNode_BlendListByEnum& Value) { Write<FAnimNode_BlendListByEnum>(uintptr_t(this) + 0x968, Value); } // 0x968 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_26(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x9b8, Value); } // 0x9b8 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_39(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_25(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0xa20, Value); } // 0xa20 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_38(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xa40, Value); } // 0xa40 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByEnum_2(const FAnimNode_BlendListByEnum& Value) { Write<FAnimNode_BlendListByEnum>(uintptr_t(this) + 0xa88, Value); } // 0xa88 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_37(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xad8, Value); } // 0xad8 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_24(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0xb20, Value); } // 0xb20 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_36(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xb40, Value); } // 0xb40 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_35(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_34(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xbd0, Value); } // 0xbd0 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_33(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_32(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_14(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0xca8, Value); } // 0xca8 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_13(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0xcf8, Value); } // 0xcf8 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_12(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0xd48, Value); } // 0xd48 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_11(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0xd98, Value); } // 0xd98 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_31(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xde8, Value); } // 0xde8 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_30(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xe30, Value); } // 0xe30 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_29(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xe78, Value); } // 0xe78 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByEnum_1(const FAnimNode_BlendListByEnum& Value) { Write<FAnimNode_BlendListByEnum>(uintptr_t(this) + 0xec0, Value); } // 0xec0 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_23(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0xf10, Value); } // 0xf10 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer_3(const FAnimNode_BlendSpacePlayer& Value) { Write<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0xf30, Value); } // 0xf30 (Size: 0x70, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_28(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xfa0, Value); } // 0xfa0 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive_4(const FAnimNode_ApplyAdditive& Value) { Write<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0xfe8, Value); } // 0xfe8 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_22(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x10b0, Value); } // 0x10b0 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine_6(const FAnimNode_StateMachine& Value) { Write<FAnimNode_StateMachine>(uintptr_t(this) + 0x10d0, Value); } // 0x10d0 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive_3(const FAnimNode_ApplyAdditive& Value) { Write<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0x1198, Value); } // 0x1198 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer_2(const FAnimNode_BlendSpacePlayer& Value) { Write<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0x1260, Value); } // 0x1260 (Size: 0x70, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_10(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x12d0, Value); } // 0x12d0 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_SaveCachedPose_3(const FAnimNode_SaveCachedPose& Value) { Write<FAnimNode_SaveCachedPose>(uintptr_t(this) + 0x1320, Value); } // 0x1320 (Size: 0x78, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive_2(const FAnimNode_ApplyAdditive& Value) { Write<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0x1398, Value); } // 0x1398 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_5(const FAnimNode_UseCachedPose& Value) { Write<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x1460, Value); } // 0x1460 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_4(const FAnimNode_UseCachedPose& Value) { Write<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x1488, Value); } // 0x1488 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive_1(const FAnimNode_ApplyAdditive& Value) { Write<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0x14b0, Value); } // 0x14b0 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_27(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer_1(const FAnimNode_BlendSpacePlayer& Value) { Write<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0x15c0, Value); } // 0x15c0 (Size: 0x70, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_9(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1630, Value); } // 0x1630 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_26(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1680, Value); } // 0x1680 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_8(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x16c8, Value); } // 0x16c8 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_25(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1718, Value); } // 0x1718 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_TwoWayBlend(const FAnimNode_TwoWayBlend& Value) { Write<FAnimNode_TwoWayBlend>(uintptr_t(this) + 0x1760, Value); } // 0x1760 (Size: 0xc0, Type: StructProperty)
    void SET_AnimGraphNode_SaveCachedPose_2(const FAnimNode_SaveCachedPose& Value) { Write<FAnimNode_SaveCachedPose>(uintptr_t(this) + 0x1820, Value); } // 0x1820 (Size: 0x78, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_28(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1898, Value); } // 0x1898 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_27(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x18c0, Value); } // 0x18c0 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_26(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x18e8, Value); } // 0x18e8 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_25(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1910, Value); } // 0x1910 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_24(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1938, Value); } // 0x1938 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_23(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1960, Value); } // 0x1960 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_22(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1988, Value); } // 0x1988 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_24(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x19b0, Value); } // 0x19b0 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_21(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x19f8, Value); } // 0x19f8 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_21(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1a18, Value); } // 0x1a18 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_20(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1a40, Value); } // 0x1a40 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_19(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1a68, Value); } // 0x1a68 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_18(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1a90, Value); } // 0x1a90 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_17(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1ab8, Value); } // 0x1ab8 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_16(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1ae0, Value); } // 0x1ae0 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_15(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x1b08, Value); } // 0x1b08 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_3(const FAnimNode_UseCachedPose& Value) { Write<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x1b30, Value); } // 0x1b30 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_20(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x1b58, Value); } // 0x1b58 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_23(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1b78, Value); } // 0x1b78 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_7(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1bc0, Value); } // 0x1bc0 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_22(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1c10, Value); } // 0x1c10 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_6(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1c58, Value); } // 0x1c58 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_21(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1ca8, Value); } // 0x1ca8 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_19(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x1cf0, Value); } // 0x1cf0 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_20(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1d10, Value); } // 0x1d10 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_18(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x1d58, Value); } // 0x1d58 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_19(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1d78, Value); } // 0x1d78 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_5(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1dc0, Value); } // 0x1dc0 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_18(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1e10, Value); } // 0x1e10 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_17(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1e58, Value); } // 0x1e58 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_4(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1ea0, Value); } // 0x1ea0 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_17(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x1ef0, Value); } // 0x1ef0 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_16(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1f10, Value); } // 0x1f10 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_3(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1f58, Value); } // 0x1f58 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_15(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1fa8, Value); } // 0x1fa8 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_2(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x1ff0, Value); } // 0x1ff0 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_14(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2040, Value); } // 0x2040 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_16(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x2088, Value); } // 0x2088 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine_5(const FAnimNode_StateMachine& Value) { Write<FAnimNode_StateMachine>(uintptr_t(this) + 0x20a8, Value); } // 0x20a8 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_15(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x2170, Value); } // 0x2170 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_2(const FAnimNode_UseCachedPose& Value) { Write<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x2190, Value); } // 0x2190 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_14(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x21b8, Value); } // 0x21b8 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine_4(const FAnimNode_StateMachine& Value) { Write<FAnimNode_StateMachine>(uintptr_t(this) + 0x21d8, Value); } // 0x21d8 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_13(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x22a0, Value); } // 0x22a0 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_14(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x22c0, Value); } // 0x22c0 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_13(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x22e8, Value); } // 0x22e8 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_12(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2310, Value); } // 0x2310 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_11(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2338, Value); } // 0x2338 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_10(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2360, Value); } // 0x2360 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_9(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2388, Value); } // 0x2388 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_8(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x23b0, Value); } // 0x23b0 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_7(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x23d8, Value); } // 0x23d8 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_13(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2400, Value); } // 0x2400 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_12(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x2448, Value); } // 0x2448 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_12(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2468, Value); } // 0x2468 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_11(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x24b0, Value); } // 0x24b0 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_11(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x24d0, Value); } // 0x24d0 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_10(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x2518, Value); } // 0x2518 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_10(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2538, Value); } // 0x2538 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_9(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x2580, Value); } // 0x2580 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_1(const FAnimNode_UseCachedPose& Value) { Write<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x25a0, Value); } // 0x25a0 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_8(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x25c8, Value); } // 0x25c8 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine_3(const FAnimNode_StateMachine& Value) { Write<FAnimNode_StateMachine>(uintptr_t(this) + 0x25e8, Value); } // 0x25e8 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_7(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x26b0, Value); } // 0x26b0 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine_2(const FAnimNode_StateMachine& Value) { Write<FAnimNode_StateMachine>(uintptr_t(this) + 0x26d0, Value); } // 0x26d0 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_9(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2798, Value); } // 0x2798 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive(const FAnimNode_ApplyAdditive& Value) { Write<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0x27e0, Value); } // 0x27e0 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_1(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x28a8, Value); } // 0x28a8 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_8(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x28f8, Value); } // 0x28f8 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer(const FAnimNode_BlendSpacePlayer& Value) { Write<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0x2940, Value); } // 0x2940 (Size: 0x70, Type: StructProperty)
    void SET_AnimGraphNode_SaveCachedPose_1(const FAnimNode_SaveCachedPose& Value) { Write<FAnimNode_SaveCachedPose>(uintptr_t(this) + 0x29b0, Value); } // 0x29b0 (Size: 0x78, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_6(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2a28, Value); } // 0x2a28 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_5(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2a50, Value); } // 0x2a50 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_4(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2a78, Value); } // 0x2a78 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_7(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2aa0, Value); } // 0x2aa0 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_6(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x2ae8, Value); } // 0x2ae8 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_6(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2b08, Value); } // 0x2b08 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_5(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x2b50, Value); } // 0x2b50 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_5(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2b70, Value); } // 0x2b70 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_4(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x2bb8, Value); } // 0x2bb8 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine_1(const FAnimNode_StateMachine& Value) { Write<FAnimNode_StateMachine>(uintptr_t(this) + 0x2bd8, Value); } // 0x2bd8 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_3(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2ca0, Value); } // 0x2ca0 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_2(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2cc8, Value); } // 0x2cc8 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_1(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2cf0, Value); } // 0x2cf0 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x2d18, Value); } // 0x2d18 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose(const FAnimNode_UseCachedPose& Value) { Write<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x2d40, Value); } // 0x2d40 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_3(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x2d68, Value); } // 0x2d68 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_4(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2d88, Value); } // 0x2d88 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_2(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x2dd0, Value); } // 0x2dd0 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_3(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2df0, Value); } // 0x2df0 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_1(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x2e38, Value); } // 0x2e38 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_2(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2e58, Value); } // 0x2e58 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_1(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x2ea0, Value); } // 0x2ea0 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByEnum(const FAnimNode_BlendListByEnum& Value) { Write<FAnimNode_BlendListByEnum>(uintptr_t(this) + 0x2ee8, Value); } // 0x2ee8 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_StateResult(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0x2f38, Value); } // 0x2f38 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine(const FAnimNode_StateMachine& Value) { Write<FAnimNode_StateMachine>(uintptr_t(this) + 0x2f58, Value); } // 0x2f58 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_SaveCachedPose(const FAnimNode_SaveCachedPose& Value) { Write<FAnimNode_SaveCachedPose>(uintptr_t(this) + 0x3020, Value); } // 0x3020 (Size: 0x78, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x3098, Value); } // 0x3098 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x30e0, Value); } // 0x30e0 (Size: 0x50, Type: StructProperty)
    void SET_PrePivot(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3130, Value); } // 0x3130 (Size: 0x1, Type: EnumProperty)
    void SET_ShouldTrigerGrappleMontage(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3131, Value); } // 0x3131 (Size: 0x1, Type: BoolProperty)
    void SET_AreFeetAttachedToBoard(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3132, Value); } // 0x3132 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa50
class AGCNL_Athena_MultiInteract_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    UAudioComponent* Audio() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    double CurrentPitch() const { return Read<double>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x8, Type: DoubleProperty)
    double TargetPitch() const { return Read<double>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: DoubleProperty)
    TMap<double, int32_t> Player_Pitch_Map() const { return Read<TMap<double, int32_t>>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x50, Type: MapProperty)
    double PreviousPitch() const { return Read<double>(uintptr_t(this) + 0xa38); } // 0xa38 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle TargetProgressHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xa40); } // 0xa40 (Size: 0x8, Type: StructProperty)
    APlayerPawn_Athena_C* Effect_Causer_Pawn() const { return Read<APlayerPawn_Athena_C*>(uintptr_t(this) + 0xa48); } // 0xa48 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_Audio(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_CurrentPitch(const double& Value) { Write<double>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x8, Type: DoubleProperty)
    void SET_TargetPitch(const double& Value) { Write<double>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: DoubleProperty)
    void SET_Player_Pitch_Map(const TMap<double, int32_t>& Value) { Write<TMap<double, int32_t>>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x50, Type: MapProperty)
    void SET_PreviousPitch(const double& Value) { Write<double>(uintptr_t(this) + 0xa38, Value); } // 0xa38 (Size: 0x8, Type: DoubleProperty)
    void SET_TargetProgressHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xa40, Value); } // 0xa40 (Size: 0x8, Type: StructProperty)
    void SET_Effect_Causer_Pawn(const APlayerPawn_Athena_C*& Value) { Write<APlayerPawn_Athena_C*>(uintptr_t(this) + 0xa48, Value); } // 0xa48 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x9dc
class AGCN_Loop_SnowFlakes_CameraAttached_Niagara_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    UNiagaraComponent* ReturnValue() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    int32_t NewVar() const { return Read<int32_t>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x4, Type: IntProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_ReturnValue(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_NewVar(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x4, Type: IntProperty)
};

// Size: 0xa00
class AGCNL_Athena_SandSurface_C : public AGCNL_Athena_Surface_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: StructProperty)
    UNiagaraComponent* FootStepFX() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    bool bNotValid() const { return Read<bool>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x1, Type: BoolProperty)
    bool bReplayMode() const { return Read<bool>(uintptr_t(this) + 0x9f1); } // 0x9f1 (Size: 0x1, Type: BoolProperty)
    AFortReplaySpectatorAthena* ReplayController() const { return Read<AFortReplaySpectatorAthena*>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: StructProperty)
    void SET_FootStepFX(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    void SET_bNotValid(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x1, Type: BoolProperty)
    void SET_bReplayMode(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9f1, Value); } // 0x9f1 (Size: 0x1, Type: BoolProperty)
    void SET_ReplayController(const AFortReplaySpectatorAthena*& Value) { Write<AFortReplaySpectatorAthena*>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x24c
class UGCN_Athena_SiphonUpdate_Heal_C : public UFortGameplayCueNotify_Burst
{
public:
    FScalableFloat HF_EffectDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x218); } // 0x218 (Size: 0x28, Type: StructProperty)
    double ConvertSecondsToScalar() const { return Read<double>(uintptr_t(this) + 0x240); } // 0x240 (Size: 0x8, Type: DoubleProperty)
    float RankedIntensityScalar() const { return Read<float>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x4, Type: FloatProperty)

    void SET_HF_EffectDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x218, Value); } // 0x218 (Size: 0x28, Type: StructProperty)
    void SET_ConvertSecondsToScalar(const double& Value) { Write<double>(uintptr_t(this) + 0x240, Value); } // 0x240 (Size: 0x8, Type: DoubleProperty)
    void SET_RankedIntensityScalar(const float& Value) { Write<float>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x78
struct FStruct_NPC_TargetSlots
{
public:
    TEnumAsByte<Enum_NPC_TargetSlots> TargetSlotType_6_B268C50140F4F849CE916EA5DB4A30E7() const { return Read<TEnumAsByte<Enum_NPC_TargetSlots>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: ByteProperty)
    UClass* TargetSlotCountingGE_7_F6007B01441781AB71302C91A1C4CFD2() const { return Read<UClass*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ClassProperty)
    FScalableFloat AITargetSlotSizeHF_8_E81162534B067D58D70AE9AC8B4B1F98() const { return Read<FScalableFloat>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x28, Type: StructProperty)
    FScalableFloat AITargetSlotDurationHF_14_A9B6ED4D4072D7BB507AA5A14118FA5B() const { return Read<FScalableFloat>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x28, Type: StructProperty)
    UClass* TargetSlotOverrideGE_11_6C40525043B50B2B696580B362A65DB3() const { return Read<UClass*>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x8, Type: ClassProperty)
    UClass* TargetSlotOwnerGE_17_19F50D8848750D3BC118D9BBD861CAA1() const { return Read<UClass*>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x8, Type: ClassProperty)
    UClass* TargetSlotCountingMaxedGE_19_BF1E1EF24CCA642F87D4379BB916F271() const { return Read<UClass*>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x8, Type: ClassProperty)

    void SET_TargetSlotType_6_B268C50140F4F849CE916EA5DB4A30E7(const TEnumAsByte<Enum_NPC_TargetSlots>& Value) { Write<TEnumAsByte<Enum_NPC_TargetSlots>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: ByteProperty)
    void SET_TargetSlotCountingGE_7_F6007B01441781AB71302C91A1C4CFD2(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ClassProperty)
    void SET_AITargetSlotSizeHF_8_E81162534B067D58D70AE9AC8B4B1F98(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x28, Type: StructProperty)
    void SET_AITargetSlotDurationHF_14_A9B6ED4D4072D7BB507AA5A14118FA5B(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x28, Type: StructProperty)
    void SET_TargetSlotOverrideGE_11_6C40525043B50B2B696580B362A65DB3(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x8, Type: ClassProperty)
    void SET_TargetSlotOwnerGE_17_19F50D8848750D3BC118D9BBD861CAA1(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x8, Type: ClassProperty)
    void SET_TargetSlotCountingMaxedGE_19_BF1E1EF24CCA642F87D4379BB916F271(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x780
class UMissionGen_Playground_C : public UFortMissionGenerator
{
public:
};

// Size: 0xa68
class UGE_NPC_Behavior_TargetSlots_Ranged_SlotOwner_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_Behavior_TargetSlots_Ranged_AbandonSlot_C : public UGameplayEffect
{
public:
};

// Size: 0x15e1
class UWBP_PartySuggestionButton_C : public UFortPartySuggestionButton
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x8, Type: StructProperty)
    UImage* SparklyTraingles() const { return Read<UImage*>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_PartySize() const { return Read<UImage*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HB_ActionPrompt() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x15a8); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    UBorder* BorderOfDarkenedText() const { return Read<UBorder*>(uintptr_t(this) + 0x15b0); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Block_Outline_C* Block_Outline() const { return Read<UWBP_UIKit_Block_Outline_C*>(uintptr_t(this) + 0x15b8); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Intro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15c0); } // 0x15c0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_Outro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15c8); } // 0x15c8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* MouseHovered() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15d0); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Anim_RequestAccepted() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15d8); } // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    bool bIsInvited() const { return Read<bool>(uintptr_t(this) + 0x15e0); } // 0x15e0 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x8, Type: StructProperty)
    void SET_SparklyTraingles(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_PartySize(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    void SET_HB_ActionPrompt(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x15a8, Value); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    void SET_BorderOfDarkenedText(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x15b0, Value); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Block_Outline(const UWBP_UIKit_Block_Outline_C*& Value) { Write<UWBP_UIKit_Block_Outline_C*>(uintptr_t(this) + 0x15b8, Value); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_Intro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15c0, Value); } // 0x15c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_Outro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15c8, Value); } // 0x15c8 (Size: 0x8, Type: ObjectProperty)
    void SET_MouseHovered(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15d0, Value); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Anim_RequestAccepted(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15d8, Value); } // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsInvited(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15e0, Value); } // 0x15e0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xe0
class UMobileDefaultSettingsChangeModalVM_C : public UUIKitDialogViewModel
{
public:
};

// Size: 0x440
class UConvertedMarkerInfo_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: StructProperty)
    UImage* SquadMarker() const { return Read<UImage*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UCommonVisibilitySwitcher* ImageSwitcher() const { return Read<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Command() const { return Read<UImage*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Avatar() const { return Read<UImage*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle DBNOPulseTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer RelevantPlaylistTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x20, Type: StructProperty)
    bool bIsTalking() const { return Read<bool>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x1, Type: BoolProperty)
    bool bShowBackgroundOverridden() const { return Read<bool>(uintptr_t(this) + 0x399); } // 0x399 (Size: 0x1, Type: BoolProperty)
    bool bEnemyVersion() const { return Read<bool>(uintptr_t(this) + 0x39a); } // 0x39a (Size: 0x1, Type: BoolProperty)
    TSoftObjectPtr<UTexture2D> Icon_Move() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D> Icon_Hold() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D> Icon_BackToMe() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D> Icon_Revive() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UTexture2D> Icon_Attack() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x20, Type: SoftObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: StructProperty)
    void SET_SquadMarker(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_ImageSwitcher(const UCommonVisibilitySwitcher*& Value) { Write<UCommonVisibilitySwitcher*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Command(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Avatar(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_DBNOPulseTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: StructProperty)
    void SET_RelevantPlaylistTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x20, Type: StructProperty)
    void SET_bIsTalking(const bool& Value) { Write<bool>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x1, Type: BoolProperty)
    void SET_bShowBackgroundOverridden(const bool& Value) { Write<bool>(uintptr_t(this) + 0x399, Value); } // 0x399 (Size: 0x1, Type: BoolProperty)
    void SET_bEnemyVersion(const bool& Value) { Write<bool>(uintptr_t(this) + 0x39a, Value); } // 0x39a (Size: 0x1, Type: BoolProperty)
    void SET_Icon_Move(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Icon_Hold(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Icon_BackToMe(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Icon_Revive(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Icon_Attack(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x20, Type: SoftObjectProperty)
};

// Size: 0x390
class UFortHUDElementWrapper_C : public UFortHUDElementWidget
{
public:
    UNamedSlot* Content() const { return Read<UNamedSlot*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)

    void SET_Content(const UNamedSlot*& Value) { Write<UNamedSlot*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x218
class UGCN_Athena_HidingProp_HayStack_Exit_Player_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x218
class UGCN_Athena_HidingProp_HayStack_LandedOn_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x218
class UGCN_Athena_HidingProp_HayStack_Enter_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x218
class UGCN_Athena_HidingProp_HayStack_Rustle_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x9d8
class AGCNL_Status_DanceStunned_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    UParticleSystemComponent* Active_Confetti() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_Active_Confetti(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa28
class AGCN_Loop_Hot_Feet_Environmental_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* TargetPlayer() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    TArray<UParticleSystemComponent*> SpawnedEmitters() const { return Read<TArray<UParticleSystemComponent*>>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x10, Type: ArrayProperty)
    USoundBase* SC_Footstep_Local() const { return Read<USoundBase*>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SC_Footstep_Remote() const { return Read<USoundBase*>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SC_Collision() const { return Read<USoundBase*>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)
    UFortCollisionAudioComponent* CollisionAudioComp() const { return Read<UFortCollisionAudioComponent*>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0x8, Type: ObjectProperty)
    TArray<UAudioComponent*> SpawnedAudioComps() const { return Read<TArray<UAudioComponent*>>(uintptr_t(this) + 0xa08); } // 0xa08 (Size: 0x10, Type: ArrayProperty)
    USoundBase* SC_OnJumpOrBeginFalling() const { return Read<USoundBase*>(uintptr_t(this) + 0xa18); } // 0xa18 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SC_OnLand() const { return Read<USoundBase*>(uintptr_t(this) + 0xa20); } // 0xa20 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_TargetPlayer(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawnedEmitters(const TArray<UParticleSystemComponent*>& Value) { Write<TArray<UParticleSystemComponent*>>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x10, Type: ArrayProperty)
    void SET_SC_Footstep_Local(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    void SET_SC_Footstep_Remote(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x8, Type: ObjectProperty)
    void SET_SC_Collision(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)
    void SET_CollisionAudioComp(const UFortCollisionAudioComponent*& Value) { Write<UFortCollisionAudioComponent*>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawnedAudioComps(const TArray<UAudioComponent*>& Value) { Write<TArray<UAudioComponent*>>(uintptr_t(this) + 0xa08, Value); } // 0xa08 (Size: 0x10, Type: ArrayProperty)
    void SET_SC_OnJumpOrBeginFalling(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xa18, Value); } // 0xa18 (Size: 0x8, Type: ObjectProperty)
    void SET_SC_OnLand(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xa20, Value); } // 0xa20 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x218
class UGCN_Athena_HidingProp_HayStack_Exit_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x1670
class ABP_PhoebeController_NonParticipant_C : public ABP_PhoebePlayerController_C
{
public:
};

// Size: 0x1670
class ABP_PhoebePlayerController_C : public AFortAthenaAIBotController
{
public:
    UFortControllerComponent_RechargeWeapons* RechargingWeaponsComponent() const { return Read<UFortControllerComponent_RechargeWeapons*>(uintptr_t(this) + 0x1650); } // 0x1650 (Size: 0x8, Type: ObjectProperty)
    UFortBlackboardComponent* Blackboard1() const { return Read<UFortBlackboardComponent*>(uintptr_t(this) + 0x1658); } // 0x1658 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaAIBotBuildingComponent* FortAthenaAIBotBuilding() const { return Read<UFortAthenaAIBotBuildingComponent*>(uintptr_t(this) + 0x1660); } // 0x1660 (Size: 0x8, Type: ObjectProperty)
    UAIPerceptionComponent* AIPerception() const { return Read<UAIPerceptionComponent*>(uintptr_t(this) + 0x1668); } // 0x1668 (Size: 0x8, Type: ObjectProperty)

    void SET_RechargingWeaponsComponent(const UFortControllerComponent_RechargeWeapons*& Value) { Write<UFortControllerComponent_RechargeWeapons*>(uintptr_t(this) + 0x1650, Value); } // 0x1650 (Size: 0x8, Type: ObjectProperty)
    void SET_Blackboard1(const UFortBlackboardComponent*& Value) { Write<UFortBlackboardComponent*>(uintptr_t(this) + 0x1658, Value); } // 0x1658 (Size: 0x8, Type: ObjectProperty)
    void SET_FortAthenaAIBotBuilding(const UFortAthenaAIBotBuildingComponent*& Value) { Write<UFortAthenaAIBotBuildingComponent*>(uintptr_t(this) + 0x1660, Value); } // 0x1660 (Size: 0x8, Type: ObjectProperty)
    void SET_AIPerception(const UAIPerceptionComponent*& Value) { Write<UAIPerceptionComponent*>(uintptr_t(this) + 0x1668, Value); } // 0x1668 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x6160
class APlayerPawn_Athena_Generic_Parent_C : public AFortPlayerPawnAthena
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x6070); } // 0x6070 (Size: 0x8, Type: StructProperty)
    UMotionWarpingComponent* MotionWarping() const { return Read<UMotionWarpingComponent*>(uintptr_t(this) + 0x6078); } // 0x6078 (Size: 0x8, Type: ObjectProperty)
    UMultiInteractActorComponent_C* MultiInteractActorComponent() const { return Read<UMultiInteractActorComponent_C*>(uintptr_t(this) + 0x6080); } // 0x6080 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInterface*> Default_Weapon_Materials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x6088); } // 0x6088 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnBackpackMaterials() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x6098); } // 0x6098 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnHatMaterials() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x60a8); } // 0x60a8 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnHeadMaterials() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x60b8); } // 0x60b8 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnBodyMaterials() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x60c8); } // 0x60c8 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnCharmMaterials() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x60d8); } // 0x60d8 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnFaceMaterials() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x60e8); } // 0x60e8 (Size: 0x10, Type: ArrayProperty)
    UPostProcessComponent* PlayerPostProcessFX() const { return Read<UPostProcessComponent*>(uintptr_t(this) + 0x60f8); } // 0x60f8 (Size: 0x8, Type: ObjectProperty)
    TArray<USkeletalMeshComponent*> SkeletalMeshes() const { return Read<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x6100); } // 0x6100 (Size: 0x10, Type: ArrayProperty)
    TArray<UMaterialInstanceDynamic*> PawnMaterials_ALL() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x6110); } // 0x6110 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x6070, Value); } // 0x6070 (Size: 0x8, Type: StructProperty)
    void SET_MotionWarping(const UMotionWarpingComponent*& Value) { Write<UMotionWarpingComponent*>(uintptr_t(this) + 0x6078, Value); } // 0x6078 (Size: 0x8, Type: ObjectProperty)
    void SET_MultiInteractActorComponent(const UMultiInteractActorComponent_C*& Value) { Write<UMultiInteractActorComponent_C*>(uintptr_t(this) + 0x6080, Value); } // 0x6080 (Size: 0x8, Type: ObjectProperty)
    void SET_Default_Weapon_Materials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x6088, Value); } // 0x6088 (Size: 0x10, Type: ArrayProperty)
    void SET_PawnBackpackMaterials(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x6098, Value); } // 0x6098 (Size: 0x10, Type: ArrayProperty)
    void SET_PawnHatMaterials(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x60a8, Value); } // 0x60a8 (Size: 0x10, Type: ArrayProperty)
    void SET_PawnHeadMaterials(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x60b8, Value); } // 0x60b8 (Size: 0x10, Type: ArrayProperty)
    void SET_PawnBodyMaterials(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x60c8, Value); } // 0x60c8 (Size: 0x10, Type: ArrayProperty)
    void SET_PawnCharmMaterials(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x60d8, Value); } // 0x60d8 (Size: 0x10, Type: ArrayProperty)
    void SET_PawnFaceMaterials(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x60e8, Value); } // 0x60e8 (Size: 0x10, Type: ArrayProperty)
    void SET_PlayerPostProcessFX(const UPostProcessComponent*& Value) { Write<UPostProcessComponent*>(uintptr_t(this) + 0x60f8, Value); } // 0x60f8 (Size: 0x8, Type: ObjectProperty)
    void SET_SkeletalMeshes(const TArray<USkeletalMeshComponent*>& Value) { Write<TArray<USkeletalMeshComponent*>>(uintptr_t(this) + 0x6100, Value); } // 0x6100 (Size: 0x10, Type: ArrayProperty)
    void SET_PawnMaterials_ALL(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0x6110, Value); } // 0x6110 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x16c0
class ABP_BotController_NPC_Base_C : public ABP_PhoebeController_NonParticipant_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1670); } // 0x1670 (Size: 0x8, Type: StructProperty)
    UFortAthenaNpcPatrollingComponent* FortAthenaNpcPatrolling() const { return Read<UFortAthenaNpcPatrollingComponent*>(uintptr_t(this) + 0x1678); } // 0x1678 (Size: 0x8, Type: ObjectProperty)
    UClass* GE_Patrolling() const { return Read<UClass*>(uintptr_t(this) + 0x1680); } // 0x1680 (Size: 0x8, Type: ClassProperty)
    FActiveGameplayEffectHandle GE_PatrollingSpeedHandle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x1688); } // 0x1688 (Size: 0x8, Type: StructProperty)
    FRotator SavedRotationRate() const { return Read<FRotator>(uintptr_t(this) + 0x1690); } // 0x1690 (Size: 0x18, Type: StructProperty)
    FRotator PatrollingRotationRate() const { return Read<FRotator>(uintptr_t(this) + 0x16a8); } // 0x16a8 (Size: 0x18, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1670, Value); } // 0x1670 (Size: 0x8, Type: StructProperty)
    void SET_FortAthenaNpcPatrolling(const UFortAthenaNpcPatrollingComponent*& Value) { Write<UFortAthenaNpcPatrollingComponent*>(uintptr_t(this) + 0x1678, Value); } // 0x1678 (Size: 0x8, Type: ObjectProperty)
    void SET_GE_Patrolling(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1680, Value); } // 0x1680 (Size: 0x8, Type: ClassProperty)
    void SET_GE_PatrollingSpeedHandle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x1688, Value); } // 0x1688 (Size: 0x8, Type: StructProperty)
    void SET_SavedRotationRate(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x1690, Value); } // 0x1690 (Size: 0x18, Type: StructProperty)
    void SET_PatrollingRotationRate(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x16a8, Value); } // 0x16a8 (Size: 0x18, Type: StructProperty)
};

// Size: 0x9d0
class AGCL_Cornfield_Movement_C : public AFortGameplayCueNotify_Loop
{
public:
    AFortPlayerPawn* TargetPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: ObjectProperty)

    void SET_TargetPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xb68
class AGCNL_RollingEffects_Parent_C : public AFortGameplayCueNotifyLoop_PhysicsObjectRolling
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb40); } // 0xb40 (Size: 0x8, Type: StructProperty)
    USoundBase* SoundAssetDefault() const { return Read<USoundBase*>(uintptr_t(this) + 0xb48); } // 0xb48 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SoundAssetSmall() const { return Read<USoundBase*>(uintptr_t(this) + 0xb50); } // 0xb50 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SoundAssetMedium() const { return Read<USoundBase*>(uintptr_t(this) + 0xb58); } // 0xb58 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SoundAssetLarge() const { return Read<USoundBase*>(uintptr_t(this) + 0xb60); } // 0xb60 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb40, Value); } // 0xb40 (Size: 0x8, Type: StructProperty)
    void SET_SoundAssetDefault(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xb48, Value); } // 0xb48 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundAssetSmall(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xb50, Value); } // 0xb50 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundAssetMedium(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xb58, Value); } // 0xb58 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundAssetLarge(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xb60, Value); } // 0xb60 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x780
class UMissionGen_CreativeTestIsland_C : public UFortMissionGenerator
{
public:
};

// Size: 0x218
class UGCN_Athena_OutsideSafeZoneDamage_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x370
class UAthenaFPSTicker_C : public UAthenaFPSBase
{
public:
};

// Size: 0x650
class UNPCConvertedIndicatorMarker_C : public UAthenaMarkedActorIndicator
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x8, Type: StructProperty)
    UConvertedMarkerInfo_C* RidingMarkerInfo() const { return Read<UConvertedMarkerInfo_C*>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x8, Type: ObjectProperty)
    UImage* IrwinIndicator() const { return Read<UImage*>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    FLinearColor CachedColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x10, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x8, Type: StructProperty)
    void SET_RidingMarkerInfo(const UConvertedMarkerInfo_C*& Value) { Write<UConvertedMarkerInfo_C*>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x8, Type: ObjectProperty)
    void SET_IrwinIndicator(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    void SET_CachedColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x10, Type: StructProperty)
};

// Size: 0x500
class UNPCStatusWidget_C : public UNPCStatusWidgetBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: StructProperty)
    UVerticalBox* VerticalBox_BarExtensions() const { return Read<UVerticalBox*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_BarsPrefix() const { return Read<UOverlay*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UNPCStatusWidgetBar_C* Bar_Shield() const { return Read<UNPCStatusWidgetBar_C*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UNPCStatusWidgetBar_C* Bar_Health() const { return Read<UNPCStatusWidgetBar_C*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle VisibiltyTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: StructProperty)
    double StatusWidgetVisibleDuration() const { return Read<double>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x8, Type: DoubleProperty)
    double CurrentHealthPercent() const { return Read<double>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: DoubleProperty)
    double CurrentShieldPercent() const { return Read<double>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: DoubleProperty)
    bool KeepVisibilityOn() const { return Read<bool>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x1, Type: BoolProperty)
    AFortPawn* FortPawn() const { return Read<AFortPawn*>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: StructProperty)
    void SET_VerticalBox_BarExtensions(const UVerticalBox*& Value) { Write<UVerticalBox*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_BarsPrefix(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Bar_Shield(const UNPCStatusWidgetBar_C*& Value) { Write<UNPCStatusWidgetBar_C*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Bar_Health(const UNPCStatusWidgetBar_C*& Value) { Write<UNPCStatusWidgetBar_C*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    void SET_VisibiltyTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: StructProperty)
    void SET_StatusWidgetVisibleDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x8, Type: DoubleProperty)
    void SET_CurrentHealthPercent(const double& Value) { Write<double>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: DoubleProperty)
    void SET_CurrentShieldPercent(const double& Value) { Write<double>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: DoubleProperty)
    void SET_KeepVisibilityOn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x1, Type: BoolProperty)
    void SET_FortPawn(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x411
class UNPCStatusWidgetBar_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    USimpleMaterialProgressBar_C* ProgressBarFill() const { return Read<USimpleMaterialProgressBar_C*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    USimpleMaterialProgressBar_C* ProgressBarDelta() const { return Read<USimpleMaterialProgressBar_C*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_CastShadow() const { return Read<UImage*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_BarBG() const { return Read<UImage*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    USizeBox* BarSizeBox() const { return Read<USizeBox*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    FLinearColor FillColor1() const { return Read<FLinearColor>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: StructProperty)
    FLinearColor FillColor2() const { return Read<FLinearColor>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x10, Type: StructProperty)
    FLinearColor Delta1() const { return Read<FLinearColor>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x10, Type: StructProperty)
    FLinearColor Delta2() const { return Read<FLinearColor>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x10, Type: StructProperty)
    FLinearColor FillColor1_75Percent() const { return Read<FLinearColor>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x10, Type: StructProperty)
    FLinearColor FillColor2_75Percent() const { return Read<FLinearColor>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x10, Type: StructProperty)
    FLinearColor FillColor1_50Percent() const { return Read<FLinearColor>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x10, Type: StructProperty)
    FLinearColor FillColor2_50Percent() const { return Read<FLinearColor>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x10, Type: StructProperty)
    FLinearColor FillColor1_25Percent() const { return Read<FLinearColor>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x10, Type: StructProperty)
    FLinearColor FillColor2_25Percent() const { return Read<FLinearColor>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x10, Type: StructProperty)
    FLinearColor FillColor1_100Percent() const { return Read<FLinearColor>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x10, Type: StructProperty)
    FLinearColor FillColor2_100Percent() const { return Read<FLinearColor>(uintptr_t(this) + 0x400); } // 0x400 (Size: 0x10, Type: StructProperty)
    bool DifferentProgressColors() const { return Read<bool>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_ProgressBarFill(const USimpleMaterialProgressBar_C*& Value) { Write<USimpleMaterialProgressBar_C*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_ProgressBarDelta(const USimpleMaterialProgressBar_C*& Value) { Write<USimpleMaterialProgressBar_C*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_CastShadow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_BarBG(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_BarSizeBox(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_FillColor1(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: StructProperty)
    void SET_FillColor2(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x10, Type: StructProperty)
    void SET_Delta1(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x10, Type: StructProperty)
    void SET_Delta2(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x10, Type: StructProperty)
    void SET_FillColor1_75Percent(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x10, Type: StructProperty)
    void SET_FillColor2_75Percent(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x10, Type: StructProperty)
    void SET_FillColor1_50Percent(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x10, Type: StructProperty)
    void SET_FillColor2_50Percent(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x10, Type: StructProperty)
    void SET_FillColor1_25Percent(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x10, Type: StructProperty)
    void SET_FillColor2_25Percent(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x10, Type: StructProperty)
    void SET_FillColor1_100Percent(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x10, Type: StructProperty)
    void SET_FillColor2_100Percent(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x400, Value); } // 0x400 (Size: 0x10, Type: StructProperty)
    void SET_DifferentProgressColors(const bool& Value) { Write<bool>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x9f9
class AGCNL_Vent_Enter_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    UPostProcessComponent* PostProcess() const { return Read<UPostProcessComponent*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    float FadePPVol_LERP_6D28D8B64202D10F474B48B80194DA6D() const { return Read<float>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> FadePPVol__Direction_6D28D8B64202D10F474B48B80194DA6D() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9dc); } // 0x9dc (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* FadePPVol() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    UClass* CameraShakeClass() const { return Read<UClass*>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: ClassProperty)
    ULegacyCameraShake* CameraShake() const { return Read<ULegacyCameraShake*>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x8, Type: ObjectProperty)
    bool UsePP() const { return Read<bool>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_PostProcess(const UPostProcessComponent*& Value) { Write<UPostProcessComponent*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_FadePPVol_LERP_6D28D8B64202D10F474B48B80194DA6D(const float& Value) { Write<float>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x4, Type: FloatProperty)
    void SET_FadePPVol__Direction_6D28D8B64202D10F474B48B80194DA6D(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9dc, Value); } // 0x9dc (Size: 0x1, Type: ByteProperty)
    void SET_FadePPVol(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    void SET_CameraShakeClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: ClassProperty)
    void SET_CameraShake(const ULegacyCameraShake*& Value) { Write<ULegacyCameraShake*>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x8, Type: ObjectProperty)
    void SET_UsePP(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa38
class AGCN_Loop_GhostMode_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    float FadeMaterialsTL_Lerp_D7B0BAAD47F48403BE23B98F38D8CA3E() const { return Read<float>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> FadeMaterialsTL__Direction_D7B0BAAD47F48403BE23B98F38D8CA3E() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* FadeMaterialsTL() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    FLinearColor HitGlowColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x10, Type: StructProperty)
    FLinearColor HotGlowOuterColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x10, Type: StructProperty)
    double HitGlowFresnelBrightness() const { return Read<double>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0x8, Type: DoubleProperty)
    double HitGlowFresnelExponent() const { return Read<double>(uintptr_t(this) + 0xa08); } // 0xa08 (Size: 0x8, Type: DoubleProperty)
    double Glow_Priority() const { return Read<double>(uintptr_t(this) + 0xa10); } // 0xa10 (Size: 0x8, Type: DoubleProperty)
    USoundBase* StopSoundCue() const { return Read<USoundBase*>(uintptr_t(this) + 0xa18); } // 0xa18 (Size: 0x8, Type: ObjectProperty)
    USoundBase* StartSoundCue() const { return Read<USoundBase*>(uintptr_t(this) + 0xa20); } // 0xa20 (Size: 0x8, Type: ObjectProperty)
    TScriptInterface<Class> TargetPawn() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0xa28); } // 0xa28 (Size: 0x10, Type: InterfaceProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_FadeMaterialsTL_Lerp_D7B0BAAD47F48403BE23B98F38D8CA3E(const float& Value) { Write<float>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    void SET_FadeMaterialsTL__Direction_D7B0BAAD47F48403BE23B98F38D8CA3E(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4, Value); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    void SET_FadeMaterialsTL(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    void SET_HitGlowColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x10, Type: StructProperty)
    void SET_HotGlowOuterColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x10, Type: StructProperty)
    void SET_HitGlowFresnelBrightness(const double& Value) { Write<double>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0x8, Type: DoubleProperty)
    void SET_HitGlowFresnelExponent(const double& Value) { Write<double>(uintptr_t(this) + 0xa08, Value); } // 0xa08 (Size: 0x8, Type: DoubleProperty)
    void SET_Glow_Priority(const double& Value) { Write<double>(uintptr_t(this) + 0xa10, Value); } // 0xa10 (Size: 0x8, Type: DoubleProperty)
    void SET_StopSoundCue(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xa18, Value); } // 0xa18 (Size: 0x8, Type: ObjectProperty)
    void SET_StartSoundCue(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xa20, Value); } // 0xa20 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetPawn(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0xa28, Value); } // 0xa28 (Size: 0x10, Type: InterfaceProperty)
};

// Size: 0x5e8
class AGCN_Athena_Interrogation_Reveal_Stencil_Latent_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: StructProperty)
    UPostProcessComponent* PostProcess() const { return Read<UPostProcessComponent*>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    double SweepDuration() const { return Read<double>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle SweepDelayHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: StructProperty)
    double SweepRadius() const { return Read<double>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x8, Type: DoubleProperty)
    FVector LocalPlayerLocation() const { return Read<FVector>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x18, Type: StructProperty)
    APlayerPawn_Athena_C* PlayerPawnAthena() const { return Read<APlayerPawn_Athena_C*>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    double DelayBeforeSweep() const { return Read<double>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle DelayBeforeSweepHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: StructProperty)
    FScalableFloat StencilDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x28, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: StructProperty)
    void SET_PostProcess(const UPostProcessComponent*& Value) { Write<UPostProcessComponent*>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    void SET_SweepDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x8, Type: DoubleProperty)
    void SET_SweepDelayHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: StructProperty)
    void SET_SweepRadius(const double& Value) { Write<double>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x8, Type: DoubleProperty)
    void SET_LocalPlayerLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x18, Type: StructProperty)
    void SET_PlayerPawnAthena(const APlayerPawn_Athena_C*& Value) { Write<APlayerPawn_Athena_C*>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    void SET_DelayBeforeSweep(const double& Value) { Write<double>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    void SET_DelayBeforeSweepHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: StructProperty)
    void SET_StencilDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x28, Type: StructProperty)
};

// Size: 0xa68
class UGE_NPC_BehaviorPhaseIntroBehaviorCooldown_60s_C : public UGameplayEffect
{
public:
};

// Size: 0x48
class UNavFilter_NPC_AnyTraversable_C : public UNavigationQueryFilter
{
public:
};

// Size: 0x48
class UNavFilter_NPC_AvoidAllWater_C : public URecastFilter_UseDefaultArea
{
public:
};

// Size: 0xa68
class UGE_InSafeZone_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_Parent_Alert_Cooldown_C : public UGameplayEffect
{
public:
};

// Size: 0x218
class UGCN_Athena_Tether_FallLanding_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x609
class AGCN_Athena_Interrogation_Reveal_Latent_C : public AFortGameplayCueNotify_BurstLatent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x8, Type: StructProperty)
    UPostProcessComponent* PostProcess() const { return Read<UPostProcessComponent*>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    double SweepDuration() const { return Read<double>(uintptr_t(this) + 0x578); } // 0x578 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle SweepDelayHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: StructProperty)
    double SweepRadius() const { return Read<double>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x8, Type: DoubleProperty)
    FVector SourceObjectLocation() const { return Read<FVector>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x18, Type: StructProperty)
    APlayerPawn_Athena_C* PlayerPawnAthena() const { return Read<APlayerPawn_Athena_C*>(uintptr_t(this) + 0x5a8); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    double DelayBeforeSweep() const { return Read<double>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle DelayBeforeSweepHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x8, Type: StructProperty)
    FVector ParticleRelativeLocation() const { return Read<FVector>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x18, Type: StructProperty)
    USoundMix* RevealSoundMix() const { return Read<USoundMix*>(uintptr_t(this) + 0x5d8); } // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat StencilDuration() const { return Read<FScalableFloat>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x28, Type: StructProperty)
    bool bShouldPlayParticleEffectOnHand() const { return Read<bool>(uintptr_t(this) + 0x608); } // 0x608 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x8, Type: StructProperty)
    void SET_PostProcess(const UPostProcessComponent*& Value) { Write<UPostProcessComponent*>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x8, Type: ObjectProperty)
    void SET_SweepDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x578, Value); } // 0x578 (Size: 0x8, Type: DoubleProperty)
    void SET_SweepDelayHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: StructProperty)
    void SET_SweepRadius(const double& Value) { Write<double>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x8, Type: DoubleProperty)
    void SET_SourceObjectLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x18, Type: StructProperty)
    void SET_PlayerPawnAthena(const APlayerPawn_Athena_C*& Value) { Write<APlayerPawn_Athena_C*>(uintptr_t(this) + 0x5a8, Value); } // 0x5a8 (Size: 0x8, Type: ObjectProperty)
    void SET_DelayBeforeSweep(const double& Value) { Write<double>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x8, Type: DoubleProperty)
    void SET_DelayBeforeSweepHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x8, Type: StructProperty)
    void SET_ParticleRelativeLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x18, Type: StructProperty)
    void SET_RevealSoundMix(const USoundMix*& Value) { Write<USoundMix*>(uintptr_t(this) + 0x5d8, Value); } // 0x5d8 (Size: 0x8, Type: ObjectProperty)
    void SET_StencilDuration(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x28, Type: StructProperty)
    void SET_bShouldPlayParticleEffectOnHand(const bool& Value) { Write<bool>(uintptr_t(this) + 0x608, Value); } // 0x608 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa00
class AGCN_Loop_Ice_Feet_Environmental_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    AActor* TargetActor() const { return Read<AActor*>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    TArray<UFXSystemComponent*> SpawnedEmitters() const { return Read<TArray<UFXSystemComponent*>>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x10, Type: ArrayProperty)
    UFortCollisionAudioComponent* CollisionAudioComp() const { return Read<UFortCollisionAudioComponent*>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    TArray<UAudioComponent*> SpawnedAudioComps() const { return Read<TArray<UAudioComponent*>>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_TargetActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawnedEmitters(const TArray<UFXSystemComponent*>& Value) { Write<TArray<UFXSystemComponent*>>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x10, Type: ArrayProperty)
    void SET_CollisionAudioComp(const UFortCollisionAudioComponent*& Value) { Write<UFortCollisionAudioComponent*>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawnedAudioComps(const TArray<UAudioComponent*>& Value) { Write<TArray<UAudioComponent*>>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x218
class UGC_Athena_Feedback_ExplosionSmall_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x658
class ANPC_Wildlife_Controller_Parent_C : public AAthenaAIController
{
public:
    UAthenaMarkerComponent* AthenaMarker() const { return Read<UAthenaMarkerComponent*>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    UFortAthenaNpcPatrollingComponent* FortAthenaNpcPatrolling() const { return Read<UFortAthenaNpcPatrollingComponent*>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x8, Type: ObjectProperty)

    void SET_AthenaMarker(const UAthenaMarkerComponent*& Value) { Write<UAthenaMarkerComponent*>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    void SET_FortAthenaNpcPatrolling(const UFortAthenaNpcPatrollingComponent*& Value) { Write<UFortAthenaNpcPatrollingComponent*>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa68
class UGE_NPC_Parent_Convert_Damage_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_GoalSelection_Tamed_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_Behavior_TargetSlots_Ranged_SlotInUse_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_Behavior_TargetSlots_Melee_Max_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_Behavior_TargetSlots_Ranged_OverrideSlot_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_Gameplay_Status_RecentlyDamaged_10sec_C : public UGameplayEffect
{
public:
};

// Size: 0xa10
class AGCNL_Athena_HidingProp_Teleporting_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    float Timeline_0_LerpWhiteWash_3C12694840EC8C9B33E562A2C6B279BA() const { return Read<float>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_3C12694840EC8C9B33E562A2C6B279BA() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_0() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* 1PTravelAudio() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    TScriptInterface<Class> LensEffectInterface() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x10, Type: InterfaceProperty)
    AActor* LensEffectActor() const { return Read<AActor*>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)
    USoundMix* 1pMixMod() const { return Read<USoundMix*>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* OwningActor() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xa08); } // 0xa08 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_Timeline_0_LerpWhiteWash_3C12694840EC8C9B33E562A2C6B279BA(const float& Value) { Write<float>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_0__Direction_3C12694840EC8C9B33E562A2C6B279BA(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4, Value); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_0(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    void SET_1PTravelAudio(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    void SET_LensEffectInterface(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x10, Type: InterfaceProperty)
    void SET_LensEffectActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)
    void SET_1pMixMod(const USoundMix*& Value) { Write<USoundMix*>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0x8, Type: ObjectProperty)
    void SET_OwningActor(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xa08, Value); } // 0xa08 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x218
class UGCN_Zipline_SpeedLines_C : public UFortGameplayCueNotify_Burst
{
public:
};

// Size: 0x390
class ABP_ZipLine_Camera_LensEffect_C : public AEmitterCameraLensEffectBase
{
public:
};

// Size: 0xa68
class UGE_OutsideSafeZoneDamage_C : public UGET_PeriodicEnergyDamage_C
{
public:
};

// Size: 0xa68
class UGE_NPC_Behavior_TargetSlots_Melee_OverrideSlot_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_Behavior_TargetSlots_Melee_SlotOwner_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_Behavior_TargetSlots_Melee_AbandonSlot_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_Behavior_TargetSlots_Ranged_Max_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_NPC_Behavior_TargetSlots_Melee_SlotInUse_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Quest_Converted_Irwin_C : public UGameplayEffect
{
public:
};

// Size: 0x4498
class ANPC_Pawn_Wildlife_Parent_C : public ANPC_Pawn_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x42f0); } // 0x42f0 (Size: 0x8, Type: StructProperty)
    UFortCharacterPartsComponent* FortCharacterParts() const { return Read<UFortCharacterPartsComponent*>(uintptr_t(this) + 0x42f8); } // 0x42f8 (Size: 0x8, Type: ObjectProperty)
    UNiagaraComponent* Wildlife_FootDust() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0x4300); } // 0x4300 (Size: 0x8, Type: ObjectProperty)
    UFortPawnComponent_Convert* ConvertComponent() const { return Read<UFortPawnComponent_Convert*>(uintptr_t(this) + 0x4308); } // 0x4308 (Size: 0x8, Type: ObjectProperty)
    char LeaderTeam() const { return Read<char>(uintptr_t(this) + 0x4370); } // 0x4370 (Size: 0x1, Type: ByteProperty)
    USoundEffectSourcePresetChain* VocalSourceEffectChainOverride() const { return Read<USoundEffectSourcePresetChain*>(uintptr_t(this) + 0x4378); } // 0x4378 (Size: 0x8, Type: ObjectProperty)
    bool bTamingEnabled() const { return Read<bool>(uintptr_t(this) + 0x4380); } // 0x4380 (Size: 0x1, Type: BoolProperty)
    bool bCanBeInteractedWithWhileTamed() const { return Read<bool>(uintptr_t(this) + 0x4398); } // 0x4398 (Size: 0x1, Type: BoolProperty)
    FActiveGameplayEffectHandle GE_Quest_Converted_Handle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x439c); } // 0x439c (Size: 0x8, Type: StructProperty)
    UClass* GE_Quest_Converted_Irwin() const { return Read<UClass*>(uintptr_t(this) + 0x43a8); } // 0x43a8 (Size: 0x8, Type: ClassProperty)
    bool bIsBeingRidden() const { return Read<bool>(uintptr_t(this) + 0x43c0); } // 0x43c0 (Size: 0x1, Type: BoolProperty)
    bool NPCStatusWidgetShouldDisplayDamage() const { return Read<bool>(uintptr_t(this) + 0x43c1); } // 0x43c1 (Size: 0x1, Type: BoolProperty)
    UClass* GE_GoalSelectionWhileTamed() const { return Read<UClass*>(uintptr_t(this) + 0x43c8); } // 0x43c8 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer T_GoalSelectionWhileTamed() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x43d0); } // 0x43d0 (Size: 0x20, Type: StructProperty)
    double CurrentEnergy() const { return Read<double>(uintptr_t(this) + 0x43f0); } // 0x43f0 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag IrwinSlidingGC() const { return Read<FGameplayTag>(uintptr_t(this) + 0x43f8); } // 0x43f8 (Size: 0x4, Type: StructProperty)
    bool bLeaderSetSuccess() const { return Read<bool>(uintptr_t(this) + 0x43fc); } // 0x43fc (Size: 0x1, Type: BoolProperty)
    FGameplayTag JumpLandSoundLibTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4400); } // 0x4400 (Size: 0x4, Type: StructProperty)
    FGameplayTag TameSoundLibTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4404); } // 0x4404 (Size: 0x4, Type: StructProperty)
    USoundBase* SoundIndicatorSound_Unridden() const { return Read<USoundBase*>(uintptr_t(this) + 0x4408); } // 0x4408 (Size: 0x8, Type: ObjectProperty)
    USoundBase* SoundIndicatorSound_Ridden() const { return Read<USoundBase*>(uintptr_t(this) + 0x4410); } // 0x4410 (Size: 0x8, Type: ObjectProperty)
    bool OverrideIncomingDmg() const { return Read<bool>(uintptr_t(this) + 0x4418); } // 0x4418 (Size: 0x1, Type: BoolProperty)
    double OverridenIncomingDmgAmount() const { return Read<double>(uintptr_t(this) + 0x4420); } // 0x4420 (Size: 0x8, Type: DoubleProperty)
    double ColorVariation() const { return Read<double>(uintptr_t(this) + 0x4438); } // 0x4438 (Size: 0x8, Type: DoubleProperty)
    char Default_Unconvert_Reason() const { return Read<char>(uintptr_t(this) + 0x4440); } // 0x4440 (Size: 0x1, Type: ByteProperty)
    FScalableFloat StuckBouncing_UnstuckEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0x4448); } // 0x4448 (Size: 0x28, Type: StructProperty)
    int32_t StuckBouncing_LaunchCount() const { return Read<int32_t>(uintptr_t(this) + 0x4470); } // 0x4470 (Size: 0x4, Type: IntProperty)
    int32_t StuckBouncing_MinLaunchCount() const { return Read<int32_t>(uintptr_t(this) + 0x4474); } // 0x4474 (Size: 0x4, Type: IntProperty)
    FActiveGameplayEffectHandle StuckBouncing_GeHandle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x4478); } // 0x4478 (Size: 0x8, Type: StructProperty)
    UClass* StuckBouncing_GE() const { return Read<UClass*>(uintptr_t(this) + 0x4480); } // 0x4480 (Size: 0x8, Type: ClassProperty)
    double StuckBouncing_UnstuckVelocityMaxZRotationAngle() const { return Read<double>(uintptr_t(this) + 0x4488); } // 0x4488 (Size: 0x8, Type: DoubleProperty)
    double StuckBouncing_UnstuckVelocity() const { return Read<double>(uintptr_t(this) + 0x4490); } // 0x4490 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x42f0, Value); } // 0x42f0 (Size: 0x8, Type: StructProperty)
    void SET_FortCharacterParts(const UFortCharacterPartsComponent*& Value) { Write<UFortCharacterPartsComponent*>(uintptr_t(this) + 0x42f8, Value); } // 0x42f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Wildlife_FootDust(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0x4300, Value); } // 0x4300 (Size: 0x8, Type: ObjectProperty)
    void SET_ConvertComponent(const UFortPawnComponent_Convert*& Value) { Write<UFortPawnComponent_Convert*>(uintptr_t(this) + 0x4308, Value); } // 0x4308 (Size: 0x8, Type: ObjectProperty)
    void SET_LeaderTeam(const char& Value) { Write<char>(uintptr_t(this) + 0x4370, Value); } // 0x4370 (Size: 0x1, Type: ByteProperty)
    void SET_VocalSourceEffectChainOverride(const USoundEffectSourcePresetChain*& Value) { Write<USoundEffectSourcePresetChain*>(uintptr_t(this) + 0x4378, Value); } // 0x4378 (Size: 0x8, Type: ObjectProperty)
    void SET_bTamingEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4380, Value); } // 0x4380 (Size: 0x1, Type: BoolProperty)
    void SET_bCanBeInteractedWithWhileTamed(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4398, Value); } // 0x4398 (Size: 0x1, Type: BoolProperty)
    void SET_GE_Quest_Converted_Handle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x439c, Value); } // 0x439c (Size: 0x8, Type: StructProperty)
    void SET_GE_Quest_Converted_Irwin(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x43a8, Value); } // 0x43a8 (Size: 0x8, Type: ClassProperty)
    void SET_bIsBeingRidden(const bool& Value) { Write<bool>(uintptr_t(this) + 0x43c0, Value); } // 0x43c0 (Size: 0x1, Type: BoolProperty)
    void SET_NPCStatusWidgetShouldDisplayDamage(const bool& Value) { Write<bool>(uintptr_t(this) + 0x43c1, Value); } // 0x43c1 (Size: 0x1, Type: BoolProperty)
    void SET_GE_GoalSelectionWhileTamed(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x43c8, Value); } // 0x43c8 (Size: 0x8, Type: ClassProperty)
    void SET_T_GoalSelectionWhileTamed(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x43d0, Value); } // 0x43d0 (Size: 0x20, Type: StructProperty)
    void SET_CurrentEnergy(const double& Value) { Write<double>(uintptr_t(this) + 0x43f0, Value); } // 0x43f0 (Size: 0x8, Type: DoubleProperty)
    void SET_IrwinSlidingGC(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x43f8, Value); } // 0x43f8 (Size: 0x4, Type: StructProperty)
    void SET_bLeaderSetSuccess(const bool& Value) { Write<bool>(uintptr_t(this) + 0x43fc, Value); } // 0x43fc (Size: 0x1, Type: BoolProperty)
    void SET_JumpLandSoundLibTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4400, Value); } // 0x4400 (Size: 0x4, Type: StructProperty)
    void SET_TameSoundLibTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4404, Value); } // 0x4404 (Size: 0x4, Type: StructProperty)
    void SET_SoundIndicatorSound_Unridden(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x4408, Value); } // 0x4408 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundIndicatorSound_Ridden(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x4410, Value); } // 0x4410 (Size: 0x8, Type: ObjectProperty)
    void SET_OverrideIncomingDmg(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4418, Value); } // 0x4418 (Size: 0x1, Type: BoolProperty)
    void SET_OverridenIncomingDmgAmount(const double& Value) { Write<double>(uintptr_t(this) + 0x4420, Value); } // 0x4420 (Size: 0x8, Type: DoubleProperty)
    void SET_ColorVariation(const double& Value) { Write<double>(uintptr_t(this) + 0x4438, Value); } // 0x4438 (Size: 0x8, Type: DoubleProperty)
    void SET_Default_Unconvert_Reason(const char& Value) { Write<char>(uintptr_t(this) + 0x4440, Value); } // 0x4440 (Size: 0x1, Type: ByteProperty)
    void SET_StuckBouncing_UnstuckEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x4448, Value); } // 0x4448 (Size: 0x28, Type: StructProperty)
    void SET_StuckBouncing_LaunchCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4470, Value); } // 0x4470 (Size: 0x4, Type: IntProperty)
    void SET_StuckBouncing_MinLaunchCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x4474, Value); } // 0x4474 (Size: 0x4, Type: IntProperty)
    void SET_StuckBouncing_GeHandle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x4478, Value); } // 0x4478 (Size: 0x8, Type: StructProperty)
    void SET_StuckBouncing_GE(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x4480, Value); } // 0x4480 (Size: 0x8, Type: ClassProperty)
    void SET_StuckBouncing_UnstuckVelocityMaxZRotationAngle(const double& Value) { Write<double>(uintptr_t(this) + 0x4488, Value); } // 0x4488 (Size: 0x8, Type: DoubleProperty)
    void SET_StuckBouncing_UnstuckVelocity(const double& Value) { Write<double>(uintptr_t(this) + 0x4490, Value); } // 0x4490 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x42ec
class ANPC_Pawn_Parent_C : public AFortAIPawn
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3a00); } // 0x3a00 (Size: 0x8, Type: StructProperty)
    USoundLibraryComponent* SoundLibrary() const { return Read<USoundLibraryComponent*>(uintptr_t(this) + 0x3a08); } // 0x3a08 (Size: 0x8, Type: ObjectProperty)
    UFortPawnComponent_CustomDepth* FortPawnComponent_CustomDepth() const { return Read<UFortPawnComponent_CustomDepth*>(uintptr_t(this) + 0x3a10); } // 0x3a10 (Size: 0x8, Type: ObjectProperty)
    UCapsuleComponent* WeaponCapsuleCollision() const { return Read<UCapsuleComponent*>(uintptr_t(this) + 0x3a18); } // 0x3a18 (Size: 0x8, Type: ObjectProperty)
    UFortTaggedNavFiltersComponent* FortTaggedNavFilters() const { return Read<UFortTaggedNavFiltersComponent*>(uintptr_t(this) + 0x3a20); } // 0x3a20 (Size: 0x8, Type: ObjectProperty)
    UFortActorComponent_Affiliation* FortActorComponent_Affiliation() const { return Read<UFortActorComponent_Affiliation*>(uintptr_t(this) + 0x3a28); } // 0x3a28 (Size: 0x8, Type: ObjectProperty)
    USoundLibraryComponent* SoundLibrary_Component() const { return Read<USoundLibraryComponent*>(uintptr_t(this) + 0x3a30); } // 0x3a30 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* MovementAudioComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x3a38); } // 0x3a38 (Size: 0x8, Type: ObjectProperty)
    UNPC_VoiceComponent_C* NPC_VoiceComponent() const { return Read<UNPC_VoiceComponent_C*>(uintptr_t(this) + 0x3a40); } // 0x3a40 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* VOAudioComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x3a48); } // 0x3a48 (Size: 0x8, Type: ObjectProperty)
    UFortWidgetComponent* NPCStatusWidget() const { return Read<UFortWidgetComponent*>(uintptr_t(this) + 0x3a50); } // 0x3a50 (Size: 0x8, Type: ObjectProperty)
    float Timeline_ScaleMeshInOrOut_MeshScaleAlpha_9DAAC0B243D26E4160CEC3A458AE0E86() const { return Read<float>(uintptr_t(this) + 0x3a58); } // 0x3a58 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_ScaleMeshInOrOut__Direction_9DAAC0B243D26E4160CEC3A458AE0E86() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x3a5c); } // 0x3a5c (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_ScaleMeshInOrOut() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x3a60); } // 0x3a60 (Size: 0x8, Type: ObjectProperty)
    UClass* GE_NPC_RecentlyDamaged() const { return Read<UClass*>(uintptr_t(this) + 0x3a68); } // 0x3a68 (Size: 0x8, Type: ClassProperty)
    TEnumAsByte<Enum_NPC_AlertLevel> NPC_AlertLevel() const { return Read<TEnumAsByte<Enum_NPC_AlertLevel>>(uintptr_t(this) + 0x3a70); } // 0x3a70 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<Enum_NPC_AlertLevel> NPC_AlertLevelPrevious() const { return Read<TEnumAsByte<Enum_NPC_AlertLevel>>(uintptr_t(this) + 0x3a71); } // 0x3a71 (Size: 0x1, Type: ByteProperty)
    TMap<FGameplayTag, TEnumAsByte<Enum_NPC_AlertLevel>> NPC_AlertLevelToTagMap() const { return Read<TMap<FGameplayTag, TEnumAsByte<Enum_NPC_AlertLevel>>>(uintptr_t(this) + 0x3a78); } // 0x3a78 (Size: 0x50, Type: MapProperty)
    bool NPC_StatusWidgetHealthBarDisabled() const { return Read<bool>(uintptr_t(this) + 0x3ac8); } // 0x3ac8 (Size: 0x1, Type: BoolProperty)
    FGameplayTag GameplayCue_PickupGrabbed() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3acc); } // 0x3acc (Size: 0x4, Type: StructProperty)
    uint8_t NPC_BestLootRarityInInventory() const { return Read<uint8_t>(uintptr_t(this) + 0x3ad0); } // 0x3ad0 (Size: 0x1, Type: EnumProperty)
    bool NPC_DebugPawn() const { return Read<bool>(uintptr_t(this) + 0x3ad1); } // 0x3ad1 (Size: 0x1, Type: BoolProperty)
    bool NPC_ShowInventoryRarityVisuals() const { return Read<bool>(uintptr_t(this) + 0x3ad2); } // 0x3ad2 (Size: 0x1, Type: BoolProperty)
    double InventoryGlowDelay() const { return Read<double>(uintptr_t(this) + 0x3ad8); } // 0x3ad8 (Size: 0x8, Type: DoubleProperty)
    FScalableFloat NPC_NumberOfInventoryItemsToDeliverHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3ae0); } // 0x3ae0 (Size: 0x28, Type: StructProperty)
    bool NPC_SpawnInvisible() const { return Read<bool>(uintptr_t(this) + 0x3b08); } // 0x3b08 (Size: 0x1, Type: BoolProperty)
    bool NPC_ScaleMeshInOnSpawn() const { return Read<bool>(uintptr_t(this) + 0x3b09); } // 0x3b09 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer TC_NPC_SpawnAbilityTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x3b10); } // 0x3b10 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer TC_NPC_AlternateSpawnAbilityTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x3b30); } // 0x3b30 (Size: 0x20, Type: StructProperty)
    bool NPC_IsSpawning() const { return Read<bool>(uintptr_t(this) + 0x3b50); } // 0x3b50 (Size: 0x1, Type: BoolProperty)
    double NPC_OriginalGravityScale() const { return Read<double>(uintptr_t(this) + 0x3b58); } // 0x3b58 (Size: 0x8, Type: DoubleProperty)
    FRotator NPC_OriginalRotationRate() const { return Read<FRotator>(uintptr_t(this) + 0x3b60); } // 0x3b60 (Size: 0x18, Type: StructProperty)
    bool NPC_HasPawnGoal() const { return Read<bool>(uintptr_t(this) + 0x3b78); } // 0x3b78 (Size: 0x1, Type: BoolProperty)
    AActor* NPC_PawnGoalActor() const { return Read<AActor*>(uintptr_t(this) + 0x3b80); } // 0x3b80 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat NPC_NumberOfInventoryItemsToConsumeBeforeFullHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3b88); } // 0x3b88 (Size: 0x28, Type: StructProperty)
    bool NPC_PawnIsDestroyingBuildingForNavigation() const { return Read<bool>(uintptr_t(this) + 0x3bb0); } // 0x3bb0 (Size: 0x1, Type: BoolProperty)
    FScalableFloat MaxIdleVODelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3bb8); } // 0x3bb8 (Size: 0x28, Type: StructProperty)
    FScalableFloat MinIdleVODelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3be0); } // 0x3be0 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_DeathDropLootDelay() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3c08); } // 0x3c08 (Size: 0x28, Type: StructProperty)
    FName NPC_DeathDropLootTierGroupName() const { return Read<FName>(uintptr_t(this) + 0x3c30); } // 0x3c30 (Size: 0x4, Type: NameProperty)
    FGameplayTagContainer NPC_DeathDropLootRequiredDamageTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x3c38); } // 0x3c38 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer NPC_DeathDropLootForbiddenDamageTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x3c58); } // 0x3c58 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer GrantStartingItemsAbilityTC() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x3c78); } // 0x3c78 (Size: 0x20, Type: StructProperty)
    bool NPC_HasItemInInventory() const { return Read<bool>(uintptr_t(this) + 0x3c98); } // 0x3c98 (Size: 0x1, Type: BoolProperty)
    FGameplayTag VoiceTag_FullAlertIdle() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3c9c); } // 0x3c9c (Size: 0x4, Type: StructProperty)
    FGameplayTag VoiceTag_Idle() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3ca0); } // 0x3ca0 (Size: 0x4, Type: StructProperty)
    FGameplayTag VoiceTag_ReturnToIdle() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3ca4); } // 0x3ca4 (Size: 0x4, Type: StructProperty)
    FGameplayTag VoiceTag_LostTarget() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3ca8); } // 0x3ca8 (Size: 0x4, Type: StructProperty)
    FGameplayTag VoiceTag_Suspicious() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3cac); } // 0x3cac (Size: 0x4, Type: StructProperty)
    FGameplayTag VoiceTag_FullAlert() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3cb0); } // 0x3cb0 (Size: 0x4, Type: StructProperty)
    TArray<FStruct_NPC_TargetSlots> NPC_TargetSlotsHF() const { return Read<TArray<FStruct_NPC_TargetSlots>>(uintptr_t(this) + 0x3cb8); } // 0x3cb8 (Size: 0x10, Type: ArrayProperty)
    bool NPC_DamageCanCancelIntroPhase() const { return Read<bool>(uintptr_t(this) + 0x3cc8); } // 0x3cc8 (Size: 0x1, Type: BoolProperty)
    FGameplayTagQuery TQ_NPC_DamageTagsThatCanCancelIntroPhase() const { return Read<FGameplayTagQuery>(uintptr_t(this) + 0x3cd0); } // 0x3cd0 (Size: 0x48, Type: StructProperty)
    UClass* GE_NPC_IntroPhaseBehaviorCooldown() const { return Read<UClass*>(uintptr_t(this) + 0x3d18); } // 0x3d18 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer TC_IntroBehaviorActive() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x3d20); } // 0x3d20 (Size: 0x20, Type: StructProperty)
    bool Debug_NPC_AlertLevelForced() const { return Read<bool>(uintptr_t(this) + 0x3d40); } // 0x3d40 (Size: 0x1, Type: BoolProperty)
    bool NPC_PawnCanInteractInternal() const { return Read<bool>(uintptr_t(this) + 0x3d41); } // 0x3d41 (Size: 0x1, Type: BoolProperty)
    FScalableFloat NPC_PrimtiveDataFloatSetRandomlyInRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3d48); } // 0x3d48 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_PrimtiveDataFloatIndexHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3d70); } // 0x3d70 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_PrimtiveDataFloatMinRangeHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3d98); } // 0x3d98 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_PrimtiveDataFloatMaxRangeHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3dc0); } // 0x3dc0 (Size: 0x28, Type: StructProperty)
    AActor* NPC_Leader() const { return Read<AActor*>(uintptr_t(this) + 0x3de8); } // 0x3de8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag GameplayCue_LeaderSet() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3df0); } // 0x3df0 (Size: 0x4, Type: StructProperty)
    double NPC_Skeletal_Mesh_Index() const { return Read<double>(uintptr_t(this) + 0x3df8); } // 0x3df8 (Size: 0x8, Type: DoubleProperty)
    USoundBase* TamedSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x3e00); } // 0x3e00 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* StateChangeSound() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x3e08); } // 0x3e08 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat NPC_ShouldDespawnFromStormHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3e10); } // 0x3e10 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_DespawnTimerHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3e38); } // 0x3e38 (Size: 0x28, Type: StructProperty)
    FGameplayTag NPC_DespawnGameplayTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3e60); } // 0x3e60 (Size: 0x4, Type: StructProperty)
    FTimerHandle NPC_TestIsInSafeZoneTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x3e68); } // 0x3e68 (Size: 0x8, Type: StructProperty)
    FTimerHandle NPC_DespawnFromStormTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x3e70); } // 0x3e70 (Size: 0x8, Type: StructProperty)
    bool NPC_isTryingToDespawn() const { return Read<bool>(uintptr_t(this) + 0x3e78); } // 0x3e78 (Size: 0x1, Type: BoolProperty)
    FGameplayTag NPC_ResetIntroGameplayTags() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3e7c); } // 0x3e7c (Size: 0x4, Type: StructProperty)
    double SelectedPrimitiveDataFloat() const { return Read<double>(uintptr_t(this) + 0x3e80); } // 0x3e80 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag GameplayCue_Death() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3e88); } // 0x3e88 (Size: 0x4, Type: StructProperty)
    TArray<UMaterialInterface*> OG_Materials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x3e90); } // 0x3e90 (Size: 0x10, Type: ArrayProperty)
    bool NPC_Apply_GE_for_Swimming() const { return Read<bool>(uintptr_t(this) + 0x3ea0); } // 0x3ea0 (Size: 0x1, Type: BoolProperty)
    UClass* NPC_GE_ClassToApplyForSwimming() const { return Read<UClass*>(uintptr_t(this) + 0x3ea8); } // 0x3ea8 (Size: 0x8, Type: ClassProperty)
    bool NPC_Apply_Water_Enter_Exit_Burst_GC() const { return Read<bool>(uintptr_t(this) + 0x3eb0); } // 0x3eb0 (Size: 0x1, Type: BoolProperty)
    FActiveGameplayEffectHandle NPC_GE_AppliedForSwimming() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x3eb4); } // 0x3eb4 (Size: 0x8, Type: StructProperty)
    FName GoalActorBBKey() const { return Read<FName>(uintptr_t(this) + 0x3ebc); } // 0x3ebc (Size: 0x4, Type: NameProperty)
    FGameplayTag GameplayCueLureInterest() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3ec0); } // 0x3ec0 (Size: 0x4, Type: StructProperty)
    UObject* NPC_PreviousLureGoal() const { return Read<UObject*>(uintptr_t(this) + 0x3ec8); } // 0x3ec8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag Enter_Water() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3ed0); } // 0x3ed0 (Size: 0x4, Type: StructProperty)
    FGameplayTag Exit_Water() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3ed4); } // 0x3ed4 (Size: 0x4, Type: StructProperty)
    FScalableFloat NPC_MaxDistanceFromDamagedNPCToDrawHeallthBarHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3ed8); } // 0x3ed8 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_HealthBarHideTimeAfterDeathHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3f00); } // 0x3f00 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_PlayEffectWhenLuredHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3f28); } // 0x3f28 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_PawnCanInteractHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3f50); } // 0x3f50 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_AllowInteractOnlyWhenUnawareHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3f78); } // 0x3f78 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_AllowInteractWhenHasLeaderHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3fa0); } // 0x3fa0 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_AllowDrownInShallowWaterHF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x3fc8); } // 0x3fc8 (Size: 0x28, Type: StructProperty)
    bool NPC_IsInventoryInitialized() const { return Read<bool>(uintptr_t(this) + 0x3ff0); } // 0x3ff0 (Size: 0x1, Type: BoolProperty)
    float LeaderClearedCueDelay() const { return Read<float>(uintptr_t(this) + 0x3ff4); } // 0x3ff4 (Size: 0x4, Type: FloatProperty)
    FGameplayTag GameplayCue_LeaderCleared() const { return Read<FGameplayTag>(uintptr_t(this) + 0x3ff8); } // 0x3ff8 (Size: 0x4, Type: StructProperty)
    bool isGCForLeaderSetLooping() const { return Read<bool>(uintptr_t(this) + 0x3ffc); } // 0x3ffc (Size: 0x1, Type: BoolProperty)
    FGameplayTag NPC_DeathByStormTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4000); } // 0x4000 (Size: 0x4, Type: StructProperty)
    bool NPC_TryDespawnAbility() const { return Read<bool>(uintptr_t(this) + 0x4004); } // 0x4004 (Size: 0x1, Type: BoolProperty)
    FActiveGameplayEffectHandle GeOutsideSafeZoneDamageHandle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x4008); } // 0x4008 (Size: 0x8, Type: StructProperty)
    bool IsGEStormDamageInit() const { return Read<bool>(uintptr_t(this) + 0x4010); } // 0x4010 (Size: 0x1, Type: BoolProperty)
    bool NPC_MeshScalingInProgress() const { return Read<bool>(uintptr_t(this) + 0x4011); } // 0x4011 (Size: 0x1, Type: BoolProperty)
    bool NPC_DisableCapsuleOverlapsWhenScalingOut() const { return Read<bool>(uintptr_t(this) + 0x4012); } // 0x4012 (Size: 0x1, Type: BoolProperty)
    FVector NPC_OriginalMeshScale() const { return Read<FVector>(uintptr_t(this) + 0x4018); } // 0x4018 (Size: 0x18, Type: StructProperty)
    bool NPC_CanDropLoot() const { return Read<bool>(uintptr_t(this) + 0x4050); } // 0x4050 (Size: 0x1, Type: BoolProperty)
    FScalableFloat NPC_StaleDespawnTestDistance_HF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x4058); } // 0x4058 (Size: 0x28, Type: StructProperty)
    FScalableFloat NPC_StaleDespawnTimeThreshold_HF() const { return Read<FScalableFloat>(uintptr_t(this) + 0x4080); } // 0x4080 (Size: 0x28, Type: StructProperty)
    double NPC_LastNonStaleCheckTime() const { return Read<double>(uintptr_t(this) + 0x40a8); } // 0x40a8 (Size: 0x8, Type: DoubleProperty)
    bool bCanBeDamagedByNullInstigator() const { return Read<bool>(uintptr_t(this) + 0x40b0); } // 0x40b0 (Size: 0x1, Type: BoolProperty)
    bool IsEnteringWater() const { return Read<bool>(uintptr_t(this) + 0x40b1); } // 0x40b1 (Size: 0x1, Type: BoolProperty)
    bool NPCDynamicBlockConversionOnInteract() const { return Read<bool>(uintptr_t(this) + 0x40c8); } // 0x40c8 (Size: 0x1, Type: BoolProperty)
    bool NPC_TempInteractOverride() const { return Read<bool>(uintptr_t(this) + 0x40c9); } // 0x40c9 (Size: 0x1, Type: BoolProperty)
    USoundBase* HeadShot_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x40d0); } // 0x40d0 (Size: 0x8, Type: ObjectProperty)
    FName Headshot_FX_Socket() const { return Read<FName>(uintptr_t(this) + 0x40d8); } // 0x40d8 (Size: 0x4, Type: NameProperty)
    bool UseHeadShotFX() const { return Read<bool>(uintptr_t(this) + 0x40dc); } // 0x40dc (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer TC_WeaponTypesAllowedForHeadshotFX() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x40e0); } // 0x40e0 (Size: 0x20, Type: StructProperty)
    bool AllowHeadshot() const { return Read<bool>(uintptr_t(this) + 0x4100); } // 0x4100 (Size: 0x1, Type: BoolProperty)
    double AdditiveHitReactRetriggerDelay() const { return Read<double>(uintptr_t(this) + 0x4108); } // 0x4108 (Size: 0x8, Type: DoubleProperty)
    UAnimMontage* Additive_Hit_React_Montage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0x4110); } // 0x4110 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Death_Normal_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x4118); } // 0x4118 (Size: 0x8, Type: ObjectProperty)
    UParticleSystem* HeadshotFXEmitterTemplate() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x4120); } // 0x4120 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer Sound_Library_Collection_Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x4128); } // 0x4128 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer Sound_Library_Default_Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x4148); } // 0x4148 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer Sound_Library_Alert_Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x4168); } // 0x4168 (Size: 0x20, Type: StructProperty)
    FGameplayTagContainer Sound_Library_Aggressive_Tags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x4188); } // 0x4188 (Size: 0x20, Type: StructProperty)
    TArray<USoundLibrary*> SoundLibs_Default() const { return Read<TArray<USoundLibrary*>>(uintptr_t(this) + 0x41a8); } // 0x41a8 (Size: 0x10, Type: ArrayProperty)
    TArray<USoundLibrary*> SoundLibs_Alert() const { return Read<TArray<USoundLibrary*>>(uintptr_t(this) + 0x41b8); } // 0x41b8 (Size: 0x10, Type: ArrayProperty)
    USoundLibrary* CurrentSoundLib() const { return Read<USoundLibrary*>(uintptr_t(this) + 0x41c8); } // 0x41c8 (Size: 0x8, Type: ObjectProperty)
    TArray<USoundLibrary*> SoundLibs_Aggressive() const { return Read<TArray<USoundLibrary*>>(uintptr_t(this) + 0x41d0); } // 0x41d0 (Size: 0x10, Type: ArrayProperty)
    TArray<USoundLibrary*> SoundLibs_Foley() const { return Read<TArray<USoundLibrary*>>(uintptr_t(this) + 0x41e0); } // 0x41e0 (Size: 0x10, Type: ArrayProperty)
    TArray<USoundLibrary*> SoundLibs_Foley_Water() const { return Read<TArray<USoundLibrary*>>(uintptr_t(this) + 0x41f0); } // 0x41f0 (Size: 0x10, Type: ArrayProperty)
    USoundLibrary* CurrentFoleyLib() const { return Read<USoundLibrary*>(uintptr_t(this) + 0x4200); } // 0x4200 (Size: 0x8, Type: ObjectProperty)
    double Custom_Depth_Update_Rate() const { return Read<double>(uintptr_t(this) + 0x4208); } // 0x4208 (Size: 0x8, Type: DoubleProperty)
    UClass* Class() const { return Read<UClass*>(uintptr_t(this) + 0x4210); } // 0x4210 (Size: 0x8, Type: ClassProperty)
    UClass* GE_Converted() const { return Read<UClass*>(uintptr_t(this) + 0x4218); } // 0x4218 (Size: 0x8, Type: ClassProperty)
    FActiveGameplayEffectHandle GE_Converted_Handle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x4220); } // 0x4220 (Size: 0x8, Type: StructProperty)
    double NPC_Death_Time() const { return Read<double>(uintptr_t(this) + 0x4228); } // 0x4228 (Size: 0x8, Type: DoubleProperty)
    float ScaleMeshInOrOutPlayRate() const { return Read<float>(uintptr_t(this) + 0x4230); } // 0x4230 (Size: 0x4, Type: FloatProperty)
    bool AllowSkipScaleOutIfNotRecentlyRendered() const { return Read<bool>(uintptr_t(this) + 0x4234); } // 0x4234 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer GameplayTagsToBlockHitReact() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x4248); } // 0x4248 (Size: 0x20, Type: StructProperty)
    FGameplayTag GCInstantDeathTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x4268); } // 0x4268 (Size: 0x4, Type: StructProperty)
    UContextualAnimSceneAsset* CAS_Interaction_Petting() const { return Read<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x4280); } // 0x4280 (Size: 0x8, Type: ObjectProperty)
    UContextualAnimSceneAsset* CAS_Interaction_Feeding() const { return Read<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x4288); } // 0x4288 (Size: 0x8, Type: ObjectProperty)
    UContextualAnimSceneAsset* CAS_Interaction_Taming() const { return Read<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x4290); } // 0x4290 (Size: 0x8, Type: ObjectProperty)
    bool NPC_Apply_Deep_Water_Enter_Exit_Burst_GC() const { return Read<bool>(uintptr_t(this) + 0x42c8); } // 0x42c8 (Size: 0x1, Type: BoolProperty)
    FGameplayTag Enter_Deep_Water() const { return Read<FGameplayTag>(uintptr_t(this) + 0x42cc); } // 0x42cc (Size: 0x4, Type: StructProperty)
    FGameplayTag Exit_Deep_Water() const { return Read<FGameplayTag>(uintptr_t(this) + 0x42d0); } // 0x42d0 (Size: 0x4, Type: StructProperty)
    bool NPC_Client_Apply_Water_Enter_Exit_Burst_GC() const { return Read<bool>(uintptr_t(this) + 0x42d4); } // 0x42d4 (Size: 0x1, Type: BoolProperty)
    FGameplayTag GameplayCue_SystemInstantDeath() const { return Read<FGameplayTag>(uintptr_t(this) + 0x42d8); } // 0x42d8 (Size: 0x4, Type: StructProperty)
    bool RunningInstantDeathCue() const { return Read<bool>(uintptr_t(this) + 0x42dc); } // 0x42dc (Size: 0x1, Type: BoolProperty)
    FGameplayTag GCInstantDeathTagTwo() const { return Read<FGameplayTag>(uintptr_t(this) + 0x42e0); } // 0x42e0 (Size: 0x4, Type: StructProperty)
    bool NPCInteractEnabled() const { return Read<bool>(uintptr_t(this) + 0x42e4); } // 0x42e4 (Size: 0x1, Type: BoolProperty)
    FGameplayTag GameplayCueDespawnOnInstantDeath() const { return Read<FGameplayTag>(uintptr_t(this) + 0x42e8); } // 0x42e8 (Size: 0x4, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3a00, Value); } // 0x3a00 (Size: 0x8, Type: StructProperty)
    void SET_SoundLibrary(const USoundLibraryComponent*& Value) { Write<USoundLibraryComponent*>(uintptr_t(this) + 0x3a08, Value); } // 0x3a08 (Size: 0x8, Type: ObjectProperty)
    void SET_FortPawnComponent_CustomDepth(const UFortPawnComponent_CustomDepth*& Value) { Write<UFortPawnComponent_CustomDepth*>(uintptr_t(this) + 0x3a10, Value); } // 0x3a10 (Size: 0x8, Type: ObjectProperty)
    void SET_WeaponCapsuleCollision(const UCapsuleComponent*& Value) { Write<UCapsuleComponent*>(uintptr_t(this) + 0x3a18, Value); } // 0x3a18 (Size: 0x8, Type: ObjectProperty)
    void SET_FortTaggedNavFilters(const UFortTaggedNavFiltersComponent*& Value) { Write<UFortTaggedNavFiltersComponent*>(uintptr_t(this) + 0x3a20, Value); } // 0x3a20 (Size: 0x8, Type: ObjectProperty)
    void SET_FortActorComponent_Affiliation(const UFortActorComponent_Affiliation*& Value) { Write<UFortActorComponent_Affiliation*>(uintptr_t(this) + 0x3a28, Value); } // 0x3a28 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundLibrary_Component(const USoundLibraryComponent*& Value) { Write<USoundLibraryComponent*>(uintptr_t(this) + 0x3a30, Value); } // 0x3a30 (Size: 0x8, Type: ObjectProperty)
    void SET_MovementAudioComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x3a38, Value); } // 0x3a38 (Size: 0x8, Type: ObjectProperty)
    void SET_NPC_VoiceComponent(const UNPC_VoiceComponent_C*& Value) { Write<UNPC_VoiceComponent_C*>(uintptr_t(this) + 0x3a40, Value); } // 0x3a40 (Size: 0x8, Type: ObjectProperty)
    void SET_VOAudioComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x3a48, Value); } // 0x3a48 (Size: 0x8, Type: ObjectProperty)
    void SET_NPCStatusWidget(const UFortWidgetComponent*& Value) { Write<UFortWidgetComponent*>(uintptr_t(this) + 0x3a50, Value); } // 0x3a50 (Size: 0x8, Type: ObjectProperty)
    void SET_Timeline_ScaleMeshInOrOut_MeshScaleAlpha_9DAAC0B243D26E4160CEC3A458AE0E86(const float& Value) { Write<float>(uintptr_t(this) + 0x3a58, Value); } // 0x3a58 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_ScaleMeshInOrOut__Direction_9DAAC0B243D26E4160CEC3A458AE0E86(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x3a5c, Value); } // 0x3a5c (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_ScaleMeshInOrOut(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x3a60, Value); } // 0x3a60 (Size: 0x8, Type: ObjectProperty)
    void SET_GE_NPC_RecentlyDamaged(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3a68, Value); } // 0x3a68 (Size: 0x8, Type: ClassProperty)
    void SET_NPC_AlertLevel(const TEnumAsByte<Enum_NPC_AlertLevel>& Value) { Write<TEnumAsByte<Enum_NPC_AlertLevel>>(uintptr_t(this) + 0x3a70, Value); } // 0x3a70 (Size: 0x1, Type: ByteProperty)
    void SET_NPC_AlertLevelPrevious(const TEnumAsByte<Enum_NPC_AlertLevel>& Value) { Write<TEnumAsByte<Enum_NPC_AlertLevel>>(uintptr_t(this) + 0x3a71, Value); } // 0x3a71 (Size: 0x1, Type: ByteProperty)
    void SET_NPC_AlertLevelToTagMap(const TMap<FGameplayTag, TEnumAsByte<Enum_NPC_AlertLevel>>& Value) { Write<TMap<FGameplayTag, TEnumAsByte<Enum_NPC_AlertLevel>>>(uintptr_t(this) + 0x3a78, Value); } // 0x3a78 (Size: 0x50, Type: MapProperty)
    void SET_NPC_StatusWidgetHealthBarDisabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3ac8, Value); } // 0x3ac8 (Size: 0x1, Type: BoolProperty)
    void SET_GameplayCue_PickupGrabbed(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3acc, Value); } // 0x3acc (Size: 0x4, Type: StructProperty)
    void SET_NPC_BestLootRarityInInventory(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x3ad0, Value); } // 0x3ad0 (Size: 0x1, Type: EnumProperty)
    void SET_NPC_DebugPawn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3ad1, Value); } // 0x3ad1 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_ShowInventoryRarityVisuals(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3ad2, Value); } // 0x3ad2 (Size: 0x1, Type: BoolProperty)
    void SET_InventoryGlowDelay(const double& Value) { Write<double>(uintptr_t(this) + 0x3ad8, Value); } // 0x3ad8 (Size: 0x8, Type: DoubleProperty)
    void SET_NPC_NumberOfInventoryItemsToDeliverHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3ae0, Value); } // 0x3ae0 (Size: 0x28, Type: StructProperty)
    void SET_NPC_SpawnInvisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b08, Value); } // 0x3b08 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_ScaleMeshInOnSpawn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b09, Value); } // 0x3b09 (Size: 0x1, Type: BoolProperty)
    void SET_TC_NPC_SpawnAbilityTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x3b10, Value); } // 0x3b10 (Size: 0x20, Type: StructProperty)
    void SET_TC_NPC_AlternateSpawnAbilityTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x3b30, Value); } // 0x3b30 (Size: 0x20, Type: StructProperty)
    void SET_NPC_IsSpawning(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b50, Value); } // 0x3b50 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_OriginalGravityScale(const double& Value) { Write<double>(uintptr_t(this) + 0x3b58, Value); } // 0x3b58 (Size: 0x8, Type: DoubleProperty)
    void SET_NPC_OriginalRotationRate(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x3b60, Value); } // 0x3b60 (Size: 0x18, Type: StructProperty)
    void SET_NPC_HasPawnGoal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3b78, Value); } // 0x3b78 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_PawnGoalActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x3b80, Value); } // 0x3b80 (Size: 0x8, Type: ObjectProperty)
    void SET_NPC_NumberOfInventoryItemsToConsumeBeforeFullHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3b88, Value); } // 0x3b88 (Size: 0x28, Type: StructProperty)
    void SET_NPC_PawnIsDestroyingBuildingForNavigation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3bb0, Value); } // 0x3bb0 (Size: 0x1, Type: BoolProperty)
    void SET_MaxIdleVODelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3bb8, Value); } // 0x3bb8 (Size: 0x28, Type: StructProperty)
    void SET_MinIdleVODelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3be0, Value); } // 0x3be0 (Size: 0x28, Type: StructProperty)
    void SET_NPC_DeathDropLootDelay(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3c08, Value); } // 0x3c08 (Size: 0x28, Type: StructProperty)
    void SET_NPC_DeathDropLootTierGroupName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3c30, Value); } // 0x3c30 (Size: 0x4, Type: NameProperty)
    void SET_NPC_DeathDropLootRequiredDamageTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x3c38, Value); } // 0x3c38 (Size: 0x20, Type: StructProperty)
    void SET_NPC_DeathDropLootForbiddenDamageTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x3c58, Value); } // 0x3c58 (Size: 0x20, Type: StructProperty)
    void SET_GrantStartingItemsAbilityTC(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x3c78, Value); } // 0x3c78 (Size: 0x20, Type: StructProperty)
    void SET_NPC_HasItemInInventory(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c98, Value); } // 0x3c98 (Size: 0x1, Type: BoolProperty)
    void SET_VoiceTag_FullAlertIdle(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3c9c, Value); } // 0x3c9c (Size: 0x4, Type: StructProperty)
    void SET_VoiceTag_Idle(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3ca0, Value); } // 0x3ca0 (Size: 0x4, Type: StructProperty)
    void SET_VoiceTag_ReturnToIdle(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3ca4, Value); } // 0x3ca4 (Size: 0x4, Type: StructProperty)
    void SET_VoiceTag_LostTarget(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3ca8, Value); } // 0x3ca8 (Size: 0x4, Type: StructProperty)
    void SET_VoiceTag_Suspicious(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3cac, Value); } // 0x3cac (Size: 0x4, Type: StructProperty)
    void SET_VoiceTag_FullAlert(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3cb0, Value); } // 0x3cb0 (Size: 0x4, Type: StructProperty)
    void SET_NPC_TargetSlotsHF(const TArray<FStruct_NPC_TargetSlots>& Value) { Write<TArray<FStruct_NPC_TargetSlots>>(uintptr_t(this) + 0x3cb8, Value); } // 0x3cb8 (Size: 0x10, Type: ArrayProperty)
    void SET_NPC_DamageCanCancelIntroPhase(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3cc8, Value); } // 0x3cc8 (Size: 0x1, Type: BoolProperty)
    void SET_TQ_NPC_DamageTagsThatCanCancelIntroPhase(const FGameplayTagQuery& Value) { Write<FGameplayTagQuery>(uintptr_t(this) + 0x3cd0, Value); } // 0x3cd0 (Size: 0x48, Type: StructProperty)
    void SET_GE_NPC_IntroPhaseBehaviorCooldown(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3d18, Value); } // 0x3d18 (Size: 0x8, Type: ClassProperty)
    void SET_TC_IntroBehaviorActive(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x3d20, Value); } // 0x3d20 (Size: 0x20, Type: StructProperty)
    void SET_Debug_NPC_AlertLevelForced(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d40, Value); } // 0x3d40 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_PawnCanInteractInternal(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3d41, Value); } // 0x3d41 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_PrimtiveDataFloatSetRandomlyInRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3d48, Value); } // 0x3d48 (Size: 0x28, Type: StructProperty)
    void SET_NPC_PrimtiveDataFloatIndexHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3d70, Value); } // 0x3d70 (Size: 0x28, Type: StructProperty)
    void SET_NPC_PrimtiveDataFloatMinRangeHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3d98, Value); } // 0x3d98 (Size: 0x28, Type: StructProperty)
    void SET_NPC_PrimtiveDataFloatMaxRangeHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3dc0, Value); } // 0x3dc0 (Size: 0x28, Type: StructProperty)
    void SET_NPC_Leader(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x3de8, Value); } // 0x3de8 (Size: 0x8, Type: ObjectProperty)
    void SET_GameplayCue_LeaderSet(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3df0, Value); } // 0x3df0 (Size: 0x4, Type: StructProperty)
    void SET_NPC_Skeletal_Mesh_Index(const double& Value) { Write<double>(uintptr_t(this) + 0x3df8, Value); } // 0x3df8 (Size: 0x8, Type: DoubleProperty)
    void SET_TamedSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x3e00, Value); } // 0x3e00 (Size: 0x8, Type: ObjectProperty)
    void SET_StateChangeSound(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x3e08, Value); } // 0x3e08 (Size: 0x8, Type: ObjectProperty)
    void SET_NPC_ShouldDespawnFromStormHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3e10, Value); } // 0x3e10 (Size: 0x28, Type: StructProperty)
    void SET_NPC_DespawnTimerHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3e38, Value); } // 0x3e38 (Size: 0x28, Type: StructProperty)
    void SET_NPC_DespawnGameplayTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3e60, Value); } // 0x3e60 (Size: 0x4, Type: StructProperty)
    void SET_NPC_TestIsInSafeZoneTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x3e68, Value); } // 0x3e68 (Size: 0x8, Type: StructProperty)
    void SET_NPC_DespawnFromStormTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x3e70, Value); } // 0x3e70 (Size: 0x8, Type: StructProperty)
    void SET_NPC_isTryingToDespawn(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3e78, Value); } // 0x3e78 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_ResetIntroGameplayTags(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3e7c, Value); } // 0x3e7c (Size: 0x4, Type: StructProperty)
    void SET_SelectedPrimitiveDataFloat(const double& Value) { Write<double>(uintptr_t(this) + 0x3e80, Value); } // 0x3e80 (Size: 0x8, Type: DoubleProperty)
    void SET_GameplayCue_Death(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3e88, Value); } // 0x3e88 (Size: 0x4, Type: StructProperty)
    void SET_OG_Materials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0x3e90, Value); } // 0x3e90 (Size: 0x10, Type: ArrayProperty)
    void SET_NPC_Apply_GE_for_Swimming(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3ea0, Value); } // 0x3ea0 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_GE_ClassToApplyForSwimming(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x3ea8, Value); } // 0x3ea8 (Size: 0x8, Type: ClassProperty)
    void SET_NPC_Apply_Water_Enter_Exit_Burst_GC(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3eb0, Value); } // 0x3eb0 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_GE_AppliedForSwimming(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x3eb4, Value); } // 0x3eb4 (Size: 0x8, Type: StructProperty)
    void SET_GoalActorBBKey(const FName& Value) { Write<FName>(uintptr_t(this) + 0x3ebc, Value); } // 0x3ebc (Size: 0x4, Type: NameProperty)
    void SET_GameplayCueLureInterest(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3ec0, Value); } // 0x3ec0 (Size: 0x4, Type: StructProperty)
    void SET_NPC_PreviousLureGoal(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0x3ec8, Value); } // 0x3ec8 (Size: 0x8, Type: ObjectProperty)
    void SET_Enter_Water(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3ed0, Value); } // 0x3ed0 (Size: 0x4, Type: StructProperty)
    void SET_Exit_Water(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3ed4, Value); } // 0x3ed4 (Size: 0x4, Type: StructProperty)
    void SET_NPC_MaxDistanceFromDamagedNPCToDrawHeallthBarHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3ed8, Value); } // 0x3ed8 (Size: 0x28, Type: StructProperty)
    void SET_NPC_HealthBarHideTimeAfterDeathHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3f00, Value); } // 0x3f00 (Size: 0x28, Type: StructProperty)
    void SET_NPC_PlayEffectWhenLuredHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3f28, Value); } // 0x3f28 (Size: 0x28, Type: StructProperty)
    void SET_NPC_PawnCanInteractHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3f50, Value); } // 0x3f50 (Size: 0x28, Type: StructProperty)
    void SET_NPC_AllowInteractOnlyWhenUnawareHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3f78, Value); } // 0x3f78 (Size: 0x28, Type: StructProperty)
    void SET_NPC_AllowInteractWhenHasLeaderHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3fa0, Value); } // 0x3fa0 (Size: 0x28, Type: StructProperty)
    void SET_NPC_AllowDrownInShallowWaterHF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x3fc8, Value); } // 0x3fc8 (Size: 0x28, Type: StructProperty)
    void SET_NPC_IsInventoryInitialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3ff0, Value); } // 0x3ff0 (Size: 0x1, Type: BoolProperty)
    void SET_LeaderClearedCueDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x3ff4, Value); } // 0x3ff4 (Size: 0x4, Type: FloatProperty)
    void SET_GameplayCue_LeaderCleared(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x3ff8, Value); } // 0x3ff8 (Size: 0x4, Type: StructProperty)
    void SET_isGCForLeaderSetLooping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3ffc, Value); } // 0x3ffc (Size: 0x1, Type: BoolProperty)
    void SET_NPC_DeathByStormTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4000, Value); } // 0x4000 (Size: 0x4, Type: StructProperty)
    void SET_NPC_TryDespawnAbility(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4004, Value); } // 0x4004 (Size: 0x1, Type: BoolProperty)
    void SET_GeOutsideSafeZoneDamageHandle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x4008, Value); } // 0x4008 (Size: 0x8, Type: StructProperty)
    void SET_IsGEStormDamageInit(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4010, Value); } // 0x4010 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_MeshScalingInProgress(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4011, Value); } // 0x4011 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_DisableCapsuleOverlapsWhenScalingOut(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4012, Value); } // 0x4012 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_OriginalMeshScale(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x4018, Value); } // 0x4018 (Size: 0x18, Type: StructProperty)
    void SET_NPC_CanDropLoot(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4050, Value); } // 0x4050 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_StaleDespawnTestDistance_HF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x4058, Value); } // 0x4058 (Size: 0x28, Type: StructProperty)
    void SET_NPC_StaleDespawnTimeThreshold_HF(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x4080, Value); } // 0x4080 (Size: 0x28, Type: StructProperty)
    void SET_NPC_LastNonStaleCheckTime(const double& Value) { Write<double>(uintptr_t(this) + 0x40a8, Value); } // 0x40a8 (Size: 0x8, Type: DoubleProperty)
    void SET_bCanBeDamagedByNullInstigator(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40b0, Value); } // 0x40b0 (Size: 0x1, Type: BoolProperty)
    void SET_IsEnteringWater(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40b1, Value); } // 0x40b1 (Size: 0x1, Type: BoolProperty)
    void SET_NPCDynamicBlockConversionOnInteract(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40c8, Value); } // 0x40c8 (Size: 0x1, Type: BoolProperty)
    void SET_NPC_TempInteractOverride(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40c9, Value); } // 0x40c9 (Size: 0x1, Type: BoolProperty)
    void SET_HeadShot_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x40d0, Value); } // 0x40d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Headshot_FX_Socket(const FName& Value) { Write<FName>(uintptr_t(this) + 0x40d8, Value); } // 0x40d8 (Size: 0x4, Type: NameProperty)
    void SET_UseHeadShotFX(const bool& Value) { Write<bool>(uintptr_t(this) + 0x40dc, Value); } // 0x40dc (Size: 0x1, Type: BoolProperty)
    void SET_TC_WeaponTypesAllowedForHeadshotFX(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x40e0, Value); } // 0x40e0 (Size: 0x20, Type: StructProperty)
    void SET_AllowHeadshot(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4100, Value); } // 0x4100 (Size: 0x1, Type: BoolProperty)
    void SET_AdditiveHitReactRetriggerDelay(const double& Value) { Write<double>(uintptr_t(this) + 0x4108, Value); } // 0x4108 (Size: 0x8, Type: DoubleProperty)
    void SET_Additive_Hit_React_Montage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0x4110, Value); } // 0x4110 (Size: 0x8, Type: ObjectProperty)
    void SET_Death_Normal_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x4118, Value); } // 0x4118 (Size: 0x8, Type: ObjectProperty)
    void SET_HeadshotFXEmitterTemplate(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x4120, Value); } // 0x4120 (Size: 0x8, Type: ObjectProperty)
    void SET_Sound_Library_Collection_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x4128, Value); } // 0x4128 (Size: 0x20, Type: StructProperty)
    void SET_Sound_Library_Default_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x4148, Value); } // 0x4148 (Size: 0x20, Type: StructProperty)
    void SET_Sound_Library_Alert_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x4168, Value); } // 0x4168 (Size: 0x20, Type: StructProperty)
    void SET_Sound_Library_Aggressive_Tags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x4188, Value); } // 0x4188 (Size: 0x20, Type: StructProperty)
    void SET_SoundLibs_Default(const TArray<USoundLibrary*>& Value) { Write<TArray<USoundLibrary*>>(uintptr_t(this) + 0x41a8, Value); } // 0x41a8 (Size: 0x10, Type: ArrayProperty)
    void SET_SoundLibs_Alert(const TArray<USoundLibrary*>& Value) { Write<TArray<USoundLibrary*>>(uintptr_t(this) + 0x41b8, Value); } // 0x41b8 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentSoundLib(const USoundLibrary*& Value) { Write<USoundLibrary*>(uintptr_t(this) + 0x41c8, Value); } // 0x41c8 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundLibs_Aggressive(const TArray<USoundLibrary*>& Value) { Write<TArray<USoundLibrary*>>(uintptr_t(this) + 0x41d0, Value); } // 0x41d0 (Size: 0x10, Type: ArrayProperty)
    void SET_SoundLibs_Foley(const TArray<USoundLibrary*>& Value) { Write<TArray<USoundLibrary*>>(uintptr_t(this) + 0x41e0, Value); } // 0x41e0 (Size: 0x10, Type: ArrayProperty)
    void SET_SoundLibs_Foley_Water(const TArray<USoundLibrary*>& Value) { Write<TArray<USoundLibrary*>>(uintptr_t(this) + 0x41f0, Value); } // 0x41f0 (Size: 0x10, Type: ArrayProperty)
    void SET_CurrentFoleyLib(const USoundLibrary*& Value) { Write<USoundLibrary*>(uintptr_t(this) + 0x4200, Value); } // 0x4200 (Size: 0x8, Type: ObjectProperty)
    void SET_Custom_Depth_Update_Rate(const double& Value) { Write<double>(uintptr_t(this) + 0x4208, Value); } // 0x4208 (Size: 0x8, Type: DoubleProperty)
    void SET_Class(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x4210, Value); } // 0x4210 (Size: 0x8, Type: ClassProperty)
    void SET_GE_Converted(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x4218, Value); } // 0x4218 (Size: 0x8, Type: ClassProperty)
    void SET_GE_Converted_Handle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x4220, Value); } // 0x4220 (Size: 0x8, Type: StructProperty)
    void SET_NPC_Death_Time(const double& Value) { Write<double>(uintptr_t(this) + 0x4228, Value); } // 0x4228 (Size: 0x8, Type: DoubleProperty)
    void SET_ScaleMeshInOrOutPlayRate(const float& Value) { Write<float>(uintptr_t(this) + 0x4230, Value); } // 0x4230 (Size: 0x4, Type: FloatProperty)
    void SET_AllowSkipScaleOutIfNotRecentlyRendered(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4234, Value); } // 0x4234 (Size: 0x1, Type: BoolProperty)
    void SET_GameplayTagsToBlockHitReact(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x4248, Value); } // 0x4248 (Size: 0x20, Type: StructProperty)
    void SET_GCInstantDeathTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x4268, Value); } // 0x4268 (Size: 0x4, Type: StructProperty)
    void SET_CAS_Interaction_Petting(const UContextualAnimSceneAsset*& Value) { Write<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x4280, Value); } // 0x4280 (Size: 0x8, Type: ObjectProperty)
    void SET_CAS_Interaction_Feeding(const UContextualAnimSceneAsset*& Value) { Write<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x4288, Value); } // 0x4288 (Size: 0x8, Type: ObjectProperty)
    void SET_CAS_Interaction_Taming(const UContextualAnimSceneAsset*& Value) { Write<UContextualAnimSceneAsset*>(uintptr_t(this) + 0x4290, Value); } // 0x4290 (Size: 0x8, Type: ObjectProperty)
    void SET_NPC_Apply_Deep_Water_Enter_Exit_Burst_GC(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42c8, Value); } // 0x42c8 (Size: 0x1, Type: BoolProperty)
    void SET_Enter_Deep_Water(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x42cc, Value); } // 0x42cc (Size: 0x4, Type: StructProperty)
    void SET_Exit_Deep_Water(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x42d0, Value); } // 0x42d0 (Size: 0x4, Type: StructProperty)
    void SET_NPC_Client_Apply_Water_Enter_Exit_Burst_GC(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42d4, Value); } // 0x42d4 (Size: 0x1, Type: BoolProperty)
    void SET_GameplayCue_SystemInstantDeath(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x42d8, Value); } // 0x42d8 (Size: 0x4, Type: StructProperty)
    void SET_RunningInstantDeathCue(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42dc, Value); } // 0x42dc (Size: 0x1, Type: BoolProperty)
    void SET_GCInstantDeathTagTwo(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x42e0, Value); } // 0x42e0 (Size: 0x4, Type: StructProperty)
    void SET_NPCInteractEnabled(const bool& Value) { Write<bool>(uintptr_t(this) + 0x42e4, Value); } // 0x42e4 (Size: 0x1, Type: BoolProperty)
    void SET_GameplayCueDespawnOnInstantDeath(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x42e8, Value); } // 0x42e8 (Size: 0x4, Type: StructProperty)
};

// Size: 0xa10
class AGCNL_Athena_HidingProp_Teleporting_WilliePete_C : public AFortGameplayCueNotify_Loop
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    float Timeline_0_LerpWhiteWash_7F6EEB5A42EA09E354D8B4A32C35C459() const { return Read<float>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Timeline_0__Direction_7F6EEB5A42EA09E354D8B4A32C35C459() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Timeline_0() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* 1PTravelAudio() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x9e0); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    TScriptInterface<Class> LensEffectInterface() const { return Read<TScriptInterface<Class>>(uintptr_t(this) + 0x9e8); } // 0x9e8 (Size: 0x10, Type: InterfaceProperty)
    AActor* LensEffectActor() const { return Read<AActor*>(uintptr_t(this) + 0x9f8); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)
    USoundMix* 1pMixMod() const { return Read<USoundMix*>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* OwningActor() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xa08); } // 0xa08 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: StructProperty)
    void SET_Timeline_0_LerpWhiteWash_7F6EEB5A42EA09E354D8B4A32C35C459(const float& Value) { Write<float>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x4, Type: FloatProperty)
    void SET_Timeline_0__Direction_7F6EEB5A42EA09E354D8B4A32C35C459(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0x9d4, Value); } // 0x9d4 (Size: 0x1, Type: ByteProperty)
    void SET_Timeline_0(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0x8, Type: ObjectProperty)
    void SET_1PTravelAudio(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x9e0, Value); } // 0x9e0 (Size: 0x8, Type: ObjectProperty)
    void SET_LensEffectInterface(const TScriptInterface<Class>& Value) { Write<TScriptInterface<Class>>(uintptr_t(this) + 0x9e8, Value); } // 0x9e8 (Size: 0x10, Type: InterfaceProperty)
    void SET_LensEffectActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x9f8, Value); } // 0x9f8 (Size: 0x8, Type: ObjectProperty)
    void SET_1pMixMod(const USoundMix*& Value) { Write<USoundMix*>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0x8, Type: ObjectProperty)
    void SET_OwningActor(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xa08, Value); } // 0xa08 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x710
class UChallengeTile_EmptyButton_C : public UCommonButtonStyle
{
public:
};

// Size: 0xe0
class UBorder_Matchmaking_Rectangle_C : public UCommonBorderStyle
{
public:
};

// Size: 0x1f0
class UCameraShake_Pedal_C : public ULegacyCameraShake
{
public:
};

// Size: 0x1f0
class USpeed_CameraShake_C : public ULegacyCameraShake
{
public:
};

// Size: 0x1f0
class UCameraShake_HitImpact_ShoppingCart_C : public UCameraShake_HitImpact_Vehicle_C
{
public:
};

// Size: 0xa68
class UGE_Athena_Vehicle_Boost_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_VehicleDamage150_C : public UGet_DirectDamageParent_C
{
public:
};

// Size: 0xb20
class UVehicleConfigsJackal_C : public UFortAthenaJackalVehicleConfigs
{
public:
};

// Size: 0x2030
class UJackal_CameraMode_Boost_C : public UFortCameraMode_AthenaVehicle
{
public:
};

// Size: 0x2030
class UJackal_CameraMode_Sprint_C : public UFortCameraMode_AthenaVehicle
{
public:
};

// Size: 0x30
class URichTextDecorator_CosmeticGate_C : public URichTextBlockImageDecorator
{
public:
};

// Size: 0x300
class ABP_Generic_TimerManager_Lobby_C : public AActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    double TotalSecondsAtEvent() const { return Read<double>(uintptr_t(this) + 0x2b8); } // 0x2b8 (Size: 0x8, Type: DoubleProperty)
    FTimespan TimeUntilCountdownEnd() const { return Read<FTimespan>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x8, Type: StructProperty)
    FString CalendarEventName() const { return Read<FString>(uintptr_t(this) + 0x2c8); } // 0x2c8 (Size: 0x10, Type: StrProperty)
    FTimerHandle CountdownTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0x2d8); } // 0x2d8 (Size: 0x8, Type: StructProperty)
    double Phase3VisualDuration() const { return Read<double>(uintptr_t(this) + 0x2e0); } // 0x2e0 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle AccuracyTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x2e8); } // 0x2e8 (Size: 0x8, Type: StructProperty)
    FTimespan TimeSinceCountdownBegin() const { return Read<FTimespan>(uintptr_t(this) + 0x2f0); } // 0x2f0 (Size: 0x8, Type: StructProperty)
    double TimespanRatio() const { return Read<double>(uintptr_t(this) + 0x2f8); } // 0x2f8 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: StructProperty)
    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x8, Type: ObjectProperty)
    void SET_TotalSecondsAtEvent(const double& Value) { Write<double>(uintptr_t(this) + 0x2b8, Value); } // 0x2b8 (Size: 0x8, Type: DoubleProperty)
    void SET_TimeUntilCountdownEnd(const FTimespan& Value) { Write<FTimespan>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x8, Type: StructProperty)
    void SET_CalendarEventName(const FString& Value) { Write<FString>(uintptr_t(this) + 0x2c8, Value); } // 0x2c8 (Size: 0x10, Type: StrProperty)
    void SET_CountdownTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x2d8, Value); } // 0x2d8 (Size: 0x8, Type: StructProperty)
    void SET_Phase3VisualDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x2e0, Value); } // 0x2e0 (Size: 0x8, Type: DoubleProperty)
    void SET_AccuracyTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x2e8, Value); } // 0x2e8 (Size: 0x8, Type: StructProperty)
    void SET_TimeSinceCountdownBegin(const FTimespan& Value) { Write<FTimespan>(uintptr_t(this) + 0x2f0, Value); } // 0x2f0 (Size: 0x8, Type: StructProperty)
    void SET_TimespanRatio(const double& Value) { Write<double>(uintptr_t(this) + 0x2f8, Value); } // 0x2f8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xb84
class UGA_Athena_Vehicle_Boost_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    double TriggerDuration() const { return Read<double>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag BoostCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x4, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_TriggerDuration(const double& Value) { Write<double>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: DoubleProperty)
    void SET_BoostCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x4, Type: StructProperty)
};

// Size: 0xc80
class UGA_Athena_ZipLine_Smash_C : public UGA_Athena_ZipLine_SmashParent_C
{
public:
};

// Size: 0xc80
class UGA_Athena_ZipLine_SmashParent_C : public UFortGameplayAbility_ZiplineSmashBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xba8); } // 0xba8 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x8, Type: ObjectProperty)
    double UpdateIntervalForSmashVolume() const { return Read<double>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x8, Type: DoubleProperty)
    UClass* StructureDamageGE() const { return Read<UClass*>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x8, Type: ClassProperty)
    ABP_ZipLine_Athena_Harness_C* ZiplineHarness() const { return Read<ABP_ZipLine_Athena_Harness_C*>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x8, Type: ObjectProperty)
    AFortAthenaZipline* Zipline() const { return Read<AFortAthenaZipline*>(uintptr_t(this) + 0xbd0); } // 0xbd0 (Size: 0x8, Type: ObjectProperty)
    UPrimitiveComponent* ZiplineInteractComponent() const { return Read<UPrimitiveComponent*>(uintptr_t(this) + 0xbd8); } // 0xbd8 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EFortCustomMovement> DrivingCustomMovementMode() const { return Read<TEnumAsByte<EFortCustomMovement>>(uintptr_t(this) + 0xbe0); } // 0xbe0 (Size: 0x1, Type: ByteProperty)
    FActiveGameplayEffectHandle FallImmunityGEFX() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xbe4); } // 0xbe4 (Size: 0x8, Type: StructProperty)
    FGameplayTag AttachVFXCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbec); } // 0xbec (Size: 0x4, Type: StructProperty)
    FGameplayTag SmashCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbf0); } // 0xbf0 (Size: 0x4, Type: StructProperty)
    FGameplayTag T_Swimming() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbf4); } // 0xbf4 (Size: 0x4, Type: StructProperty)
    FGameplayTag T_Falling() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbf8); } // 0xbf8 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer TagsThatBlockFallImmunityRemoval() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc00); } // 0xc00 (Size: 0x20, Type: StructProperty)
    FTimerHandle TH_DelayFallDamageRemoval() const { return Read<FTimerHandle>(uintptr_t(this) + 0xc20); } // 0xc20 (Size: 0x8, Type: StructProperty)
    FTimerHandle SurroundingsCheckTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x8, Type: StructProperty)
    FGameplayTag ZiplineExitTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xc30); } // 0xc30 (Size: 0x4, Type: StructProperty)
    FVector Smash_Box_Extent() const { return Read<FVector>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x18, Type: StructProperty)
    double SmashBoxPosAdditionalZ() const { return Read<double>(uintptr_t(this) + 0xc50); } // 0xc50 (Size: 0x8, Type: DoubleProperty)
    UClass* GE_Ziplining_Passive() const { return Read<UClass*>(uintptr_t(this) + 0xc58); } // 0xc58 (Size: 0x8, Type: ClassProperty)
    FGameplayTagContainer ZiplineEnterBlockedTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x20, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xba8, Value); } // 0xba8 (Size: 0x8, Type: StructProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x8, Type: ObjectProperty)
    void SET_UpdateIntervalForSmashVolume(const double& Value) { Write<double>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x8, Type: DoubleProperty)
    void SET_StructureDamageGE(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x8, Type: ClassProperty)
    void SET_ZiplineHarness(const ABP_ZipLine_Athena_Harness_C*& Value) { Write<ABP_ZipLine_Athena_Harness_C*>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x8, Type: ObjectProperty)
    void SET_Zipline(const AFortAthenaZipline*& Value) { Write<AFortAthenaZipline*>(uintptr_t(this) + 0xbd0, Value); } // 0xbd0 (Size: 0x8, Type: ObjectProperty)
    void SET_ZiplineInteractComponent(const UPrimitiveComponent*& Value) { Write<UPrimitiveComponent*>(uintptr_t(this) + 0xbd8, Value); } // 0xbd8 (Size: 0x8, Type: ObjectProperty)
    void SET_DrivingCustomMovementMode(const TEnumAsByte<EFortCustomMovement>& Value) { Write<TEnumAsByte<EFortCustomMovement>>(uintptr_t(this) + 0xbe0, Value); } // 0xbe0 (Size: 0x1, Type: ByteProperty)
    void SET_FallImmunityGEFX(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xbe4, Value); } // 0xbe4 (Size: 0x8, Type: StructProperty)
    void SET_AttachVFXCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbec, Value); } // 0xbec (Size: 0x4, Type: StructProperty)
    void SET_SmashCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbf0, Value); } // 0xbf0 (Size: 0x4, Type: StructProperty)
    void SET_T_Swimming(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbf4, Value); } // 0xbf4 (Size: 0x4, Type: StructProperty)
    void SET_T_Falling(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbf8, Value); } // 0xbf8 (Size: 0x4, Type: StructProperty)
    void SET_TagsThatBlockFallImmunityRemoval(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc00, Value); } // 0xc00 (Size: 0x20, Type: StructProperty)
    void SET_TH_DelayFallDamageRemoval(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xc20, Value); } // 0xc20 (Size: 0x8, Type: StructProperty)
    void SET_SurroundingsCheckTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x8, Type: StructProperty)
    void SET_ZiplineExitTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xc30, Value); } // 0xc30 (Size: 0x4, Type: StructProperty)
    void SET_Smash_Box_Extent(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x18, Type: StructProperty)
    void SET_SmashBoxPosAdditionalZ(const double& Value) { Write<double>(uintptr_t(this) + 0xc50, Value); } // 0xc50 (Size: 0x8, Type: DoubleProperty)
    void SET_GE_Ziplining_Passive(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc58, Value); } // 0xc58 (Size: 0x8, Type: ClassProperty)
    void SET_ZiplineEnterBlockedTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x20, Type: StructProperty)
};

// Size: 0x110
class UBulletWhipTrackerComponent_Default_C : public UBulletWhipTrackerComponentBase
{
public:
};

// Size: 0x102c
class UGA_Athena_Consumable_Throw_Parent_C : public UFortGameplayAbility_ConsumableThrowParent
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xea0); } // 0xea0 (Size: 0x8, Type: StructProperty)
    bool AbilityKeyPressed() const { return Read<bool>(uintptr_t(this) + 0xea8); } // 0xea8 (Size: 0x1, Type: BoolProperty)
    bool InThrowWindup() const { return Read<bool>(uintptr_t(this) + 0xea9); } // 0xea9 (Size: 0x1, Type: BoolProperty)
    FScalableFloat bIsEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xeb0); } // 0xeb0 (Size: 0x28, Type: StructProperty)
    FGameplayTagContainer Tag_BlockAbilityActivation() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xed8); } // 0xed8 (Size: 0x20, Type: StructProperty)
    bool bIsSecondaryFire() const { return Read<bool>(uintptr_t(this) + 0xef8); } // 0xef8 (Size: 0x1, Type: BoolProperty)
    bool bThrowInstantly() const { return Read<bool>(uintptr_t(this) + 0xef9); } // 0xef9 (Size: 0x1, Type: BoolProperty)
    FScalableFloat ProjectileGravityScale() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf00); } // 0xf00 (Size: 0x28, Type: StructProperty)
    FScalableFloat ProjectileSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xf28); } // 0xf28 (Size: 0x28, Type: StructProperty)
    ABP_ProjectileTrajectory_C* TrajectoryIndicator() const { return Read<ABP_ProjectileTrajectory_C*>(uintptr_t(this) + 0xf50); } // 0xf50 (Size: 0x8, Type: ObjectProperty)
    UClass* TrajectoryIndicatorClass() const { return Read<UClass*>(uintptr_t(this) + 0xf58); } // 0xf58 (Size: 0x8, Type: ClassProperty)
    double TrajectoryUpdateInterval() const { return Read<double>(uintptr_t(this) + 0xf60); } // 0xf60 (Size: 0x8, Type: DoubleProperty)
    UAnimMontage* CookMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xf68); } // 0xf68 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* CookMontage1P() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xf70); } // 0xf70 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* ThrowMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xf78); } // 0xf78 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* ThrowMontage1P() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xf80); } // 0xf80 (Size: 0x8, Type: ObjectProperty)
    double TrajectoryTimeStep() const { return Read<double>(uintptr_t(this) + 0xf88); } // 0xf88 (Size: 0x8, Type: DoubleProperty)
    int32_t TrajectoryMaxSteps() const { return Read<int32_t>(uintptr_t(this) + 0xf90); } // 0xf90 (Size: 0x4, Type: IntProperty)
    FName TrajectoryCollisionProfileName() const { return Read<FName>(uintptr_t(this) + 0xf94); } // 0xf94 (Size: 0x4, Type: NameProperty)
    UClass* GE_InWindup() const { return Read<UClass*>(uintptr_t(this) + 0xf98); } // 0xf98 (Size: 0x8, Type: ClassProperty)
    UClass* CameraMode() const { return Read<UClass*>(uintptr_t(this) + 0xfa0); } // 0xfa0 (Size: 0x8, Type: ClassProperty)
    bool ReturnPhysicalMaterial() const { return Read<bool>(uintptr_t(this) + 0xfa8); } // 0xfa8 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer Tags_UseNullFailedActivateReason() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xfb0); } // 0xfb0 (Size: 0x20, Type: StructProperty)
    bool bIsThrowing() const { return Read<bool>(uintptr_t(this) + 0xfd0); } // 0xfd0 (Size: 0x1, Type: BoolProperty)
    bool SpawnedOnEquip() const { return Read<bool>(uintptr_t(this) + 0xfd1); } // 0xfd1 (Size: 0x1, Type: BoolProperty)
    FActiveGameplayEffectHandle Handle_GE_InWindup() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xfd4); } // 0xfd4 (Size: 0x8, Type: StructProperty)
    bool bPreventDeploymentInBlockAreas() const { return Read<bool>(uintptr_t(this) + 0xfdc); } // 0xfdc (Size: 0x1, Type: BoolProperty)
    float DeployableBlockingAreaCheckRadius() const { return Read<float>(uintptr_t(this) + 0xfe0); } // 0xfe0 (Size: 0x4, Type: FloatProperty)
    FVector DeployableBlockingAreaCheckOffset() const { return Read<FVector>(uintptr_t(this) + 0xfe8); } // 0xfe8 (Size: 0x18, Type: StructProperty)
    float Trajectory_Max_Distance_Between_Spline_Points() const { return Read<float>(uintptr_t(this) + 0x1000); } // 0x1000 (Size: 0x4, Type: FloatProperty)
    int32_t Trajectory_Max_Bounces() const { return Read<int32_t>(uintptr_t(this) + 0x1004); } // 0x1004 (Size: 0x4, Type: IntProperty)
    float Trajectory_Initial_Distance() const { return Read<float>(uintptr_t(this) + 0x1008); } // 0x1008 (Size: 0x4, Type: FloatProperty)
    bool Projectile_Trajectory_Data_Initialized() const { return Read<bool>(uintptr_t(this) + 0x100c); } // 0x100c (Size: 0x1, Type: BoolProperty)
    UFortAbilityTask_PlayMontageWaitTarget* ThrowMontageAsyncTask() const { return Read<UFortAbilityTask_PlayMontageWaitTarget*>(uintptr_t(this) + 0x1010); } // 0x1010 (Size: 0x8, Type: ObjectProperty)
    TArray<AActor*> TrajectoryIgnoredWorldActors() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0x1018); } // 0x1018 (Size: 0x10, Type: ArrayProperty)
    FName UniqueBlockDeploymentTag() const { return Read<FName>(uintptr_t(this) + 0x1028); } // 0x1028 (Size: 0x4, Type: NameProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xea0, Value); } // 0xea0 (Size: 0x8, Type: StructProperty)
    void SET_AbilityKeyPressed(const bool& Value) { Write<bool>(uintptr_t(this) + 0xea8, Value); } // 0xea8 (Size: 0x1, Type: BoolProperty)
    void SET_InThrowWindup(const bool& Value) { Write<bool>(uintptr_t(this) + 0xea9, Value); } // 0xea9 (Size: 0x1, Type: BoolProperty)
    void SET_bIsEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xeb0, Value); } // 0xeb0 (Size: 0x28, Type: StructProperty)
    void SET_Tag_BlockAbilityActivation(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xed8, Value); } // 0xed8 (Size: 0x20, Type: StructProperty)
    void SET_bIsSecondaryFire(const bool& Value) { Write<bool>(uintptr_t(this) + 0xef8, Value); } // 0xef8 (Size: 0x1, Type: BoolProperty)
    void SET_bThrowInstantly(const bool& Value) { Write<bool>(uintptr_t(this) + 0xef9, Value); } // 0xef9 (Size: 0x1, Type: BoolProperty)
    void SET_ProjectileGravityScale(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf00, Value); } // 0xf00 (Size: 0x28, Type: StructProperty)
    void SET_ProjectileSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xf28, Value); } // 0xf28 (Size: 0x28, Type: StructProperty)
    void SET_TrajectoryIndicator(const ABP_ProjectileTrajectory_C*& Value) { Write<ABP_ProjectileTrajectory_C*>(uintptr_t(this) + 0xf50, Value); } // 0xf50 (Size: 0x8, Type: ObjectProperty)
    void SET_TrajectoryIndicatorClass(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xf58, Value); } // 0xf58 (Size: 0x8, Type: ClassProperty)
    void SET_TrajectoryUpdateInterval(const double& Value) { Write<double>(uintptr_t(this) + 0xf60, Value); } // 0xf60 (Size: 0x8, Type: DoubleProperty)
    void SET_CookMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xf68, Value); } // 0xf68 (Size: 0x8, Type: ObjectProperty)
    void SET_CookMontage1P(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xf70, Value); } // 0xf70 (Size: 0x8, Type: ObjectProperty)
    void SET_ThrowMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xf78, Value); } // 0xf78 (Size: 0x8, Type: ObjectProperty)
    void SET_ThrowMontage1P(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xf80, Value); } // 0xf80 (Size: 0x8, Type: ObjectProperty)
    void SET_TrajectoryTimeStep(const double& Value) { Write<double>(uintptr_t(this) + 0xf88, Value); } // 0xf88 (Size: 0x8, Type: DoubleProperty)
    void SET_TrajectoryMaxSteps(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xf90, Value); } // 0xf90 (Size: 0x4, Type: IntProperty)
    void SET_TrajectoryCollisionProfileName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf94, Value); } // 0xf94 (Size: 0x4, Type: NameProperty)
    void SET_GE_InWindup(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xf98, Value); } // 0xf98 (Size: 0x8, Type: ClassProperty)
    void SET_CameraMode(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xfa0, Value); } // 0xfa0 (Size: 0x8, Type: ClassProperty)
    void SET_ReturnPhysicalMaterial(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfa8, Value); } // 0xfa8 (Size: 0x1, Type: BoolProperty)
    void SET_Tags_UseNullFailedActivateReason(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xfb0, Value); } // 0xfb0 (Size: 0x20, Type: StructProperty)
    void SET_bIsThrowing(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfd0, Value); } // 0xfd0 (Size: 0x1, Type: BoolProperty)
    void SET_SpawnedOnEquip(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfd1, Value); } // 0xfd1 (Size: 0x1, Type: BoolProperty)
    void SET_Handle_GE_InWindup(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xfd4, Value); } // 0xfd4 (Size: 0x8, Type: StructProperty)
    void SET_bPreventDeploymentInBlockAreas(const bool& Value) { Write<bool>(uintptr_t(this) + 0xfdc, Value); } // 0xfdc (Size: 0x1, Type: BoolProperty)
    void SET_DeployableBlockingAreaCheckRadius(const float& Value) { Write<float>(uintptr_t(this) + 0xfe0, Value); } // 0xfe0 (Size: 0x4, Type: FloatProperty)
    void SET_DeployableBlockingAreaCheckOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xfe8, Value); } // 0xfe8 (Size: 0x18, Type: StructProperty)
    void SET_Trajectory_Max_Distance_Between_Spline_Points(const float& Value) { Write<float>(uintptr_t(this) + 0x1000, Value); } // 0x1000 (Size: 0x4, Type: FloatProperty)
    void SET_Trajectory_Max_Bounces(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x1004, Value); } // 0x1004 (Size: 0x4, Type: IntProperty)
    void SET_Trajectory_Initial_Distance(const float& Value) { Write<float>(uintptr_t(this) + 0x1008, Value); } // 0x1008 (Size: 0x4, Type: FloatProperty)
    void SET_Projectile_Trajectory_Data_Initialized(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100c, Value); } // 0x100c (Size: 0x1, Type: BoolProperty)
    void SET_ThrowMontageAsyncTask(const UFortAbilityTask_PlayMontageWaitTarget*& Value) { Write<UFortAbilityTask_PlayMontageWaitTarget*>(uintptr_t(this) + 0x1010, Value); } // 0x1010 (Size: 0x8, Type: ObjectProperty)
    void SET_TrajectoryIgnoredWorldActors(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0x1018, Value); } // 0x1018 (Size: 0x10, Type: ArrayProperty)
    void SET_UniqueBlockDeploymentTag(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1028, Value); } // 0x1028 (Size: 0x4, Type: NameProperty)
};

// Size: 0x28
class UAthenaConsumablesSharedFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xc9c
class ABGA_Athena_WithGravity_Parent_C : public ABuildingGameplayActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9b0); } // 0x9b0 (Size: 0x8, Type: StructProperty)
    UFortWaterInteractionComponent* FortWaterInteraction() const { return Read<UFortWaterInteractionComponent*>(uintptr_t(this) + 0x9b8); } // 0x9b8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* StaticMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x9c0); } // 0x9c0 (Size: 0x8, Type: ObjectProperty)
    UProjectileMovementComponent* ProjectileMovement() const { return Read<UProjectileMovementComponent*>(uintptr_t(this) + 0x9c8); } // 0x9c8 (Size: 0x8, Type: ObjectProperty)
    bool ResumeGravSimOnBegin() const { return Read<bool>(uintptr_t(this) + 0x9d0); } // 0x9d0 (Size: 0x1, Type: BoolProperty)
    bool bResumeSimulation() const { return Read<bool>(uintptr_t(this) + 0x9d1); } // 0x9d1 (Size: 0x1, Type: BoolProperty)
    FHitResult NullHit() const { return Read<FHitResult>(uintptr_t(this) + 0x9d8); } // 0x9d8 (Size: 0xf8, Type: StructProperty)
    FVector GravImpact_Loc() const { return Read<FVector>(uintptr_t(this) + 0xad0); } // 0xad0 (Size: 0x18, Type: StructProperty)
    FVector GravHitNormal() const { return Read<FVector>(uintptr_t(this) + 0xae8); } // 0xae8 (Size: 0x18, Type: StructProperty)
    double GravMaxSlope() const { return Read<double>(uintptr_t(this) + 0xb00); } // 0xb00 (Size: 0x8, Type: DoubleProperty)
    bool CheckForBounce() const { return Read<bool>(uintptr_t(this) + 0xb08); } // 0xb08 (Size: 0x1, Type: BoolProperty)
    double ForcedBounceExtraZ() const { return Read<double>(uintptr_t(this) + 0xb10); } // 0xb10 (Size: 0x8, Type: DoubleProperty)
    int32_t ForcedBounceCurrentCount() const { return Read<int32_t>(uintptr_t(this) + 0xb18); } // 0xb18 (Size: 0x4, Type: IntProperty)
    double ForcedBounceMult() const { return Read<double>(uintptr_t(this) + 0xb20); } // 0xb20 (Size: 0x8, Type: DoubleProperty)
    TArray<AActor*> GravFoundBuildingOnDied() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0xb28); } // 0xb28 (Size: 0x10, Type: ArrayProperty)
    bool RepCollision() const { return Read<bool>(uintptr_t(this) + 0xb38); } // 0xb38 (Size: 0x1, Type: BoolProperty)
    UObject* AdditionalBounceObject() const { return Read<UObject*>(uintptr_t(this) + 0xb40); } // 0xb40 (Size: 0x8, Type: ObjectProperty)
    int32_t ForcedBounceMaxCount() const { return Read<int32_t>(uintptr_t(this) + 0xb48); } // 0xb48 (Size: 0x4, Type: IntProperty)
    bool ForceBounce() const { return Read<bool>(uintptr_t(this) + 0xb4c); } // 0xb4c (Size: 0x1, Type: BoolProperty)
    bool CountNonForceBounces() const { return Read<bool>(uintptr_t(this) + 0xb4d); } // 0xb4d (Size: 0x1, Type: BoolProperty)
    double BounceExtraZ() const { return Read<double>(uintptr_t(this) + 0xb50); } // 0xb50 (Size: 0x8, Type: DoubleProperty)
    double BounceMult() const { return Read<double>(uintptr_t(this) + 0xb58); } // 0xb58 (Size: 0x8, Type: DoubleProperty)
    bool ShouldAttach() const { return Read<bool>(uintptr_t(this) + 0xb60); } // 0xb60 (Size: 0x1, Type: BoolProperty)
    TArray<AActor*> ActorsToNotAttachTo() const { return Read<TArray<AActor*>>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x10, Type: ArrayProperty)
    bool DontAttachToOthersOfThisClass() const { return Read<bool>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x1, Type: BoolProperty)
    bool DebugText() const { return Read<bool>(uintptr_t(this) + 0xb79); } // 0xb79 (Size: 0x1, Type: BoolProperty)
    bool ShouldNotReattach() const { return Read<bool>(uintptr_t(this) + 0xb7a); } // 0xb7a (Size: 0x1, Type: BoolProperty)
    bool BlockStoppingSim() const { return Read<bool>(uintptr_t(this) + 0xb7b); } // 0xb7b (Size: 0x1, Type: BoolProperty)
    bool DeactivatePawnAndVehicleCollisionOnStop() const { return Read<bool>(uintptr_t(this) + 0xb7c); } // 0xb7c (Size: 0x1, Type: BoolProperty)
    bool AllowReattachmentToActors() const { return Read<bool>(uintptr_t(this) + 0xb7d); } // 0xb7d (Size: 0x1, Type: BoolProperty)
    FHitResult StopSimHitResult() const { return Read<FHitResult>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0xf8, Type: StructProperty)
    FVector StopSimServerLocation() const { return Read<FVector>(uintptr_t(this) + 0xc78); } // 0xc78 (Size: 0x18, Type: StructProperty)
    double BounceAwayFromLocation_MinSpeed() const { return Read<double>(uintptr_t(this) + 0xc90); } // 0xc90 (Size: 0x8, Type: DoubleProperty)
    bool BounceOffTires() const { return Read<bool>(uintptr_t(this) + 0xc98); } // 0xc98 (Size: 0x1, Type: BoolProperty)
    bool bBounceOnHitNormal() const { return Read<bool>(uintptr_t(this) + 0xc99); } // 0xc99 (Size: 0x1, Type: BoolProperty)
    bool bCalledStopSim() const { return Read<bool>(uintptr_t(this) + 0xc9a); } // 0xc9a (Size: 0x1, Type: BoolProperty)
    bool bBounceOffVehicles() const { return Read<bool>(uintptr_t(this) + 0xc9b); } // 0xc9b (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x9b0, Value); } // 0x9b0 (Size: 0x8, Type: StructProperty)
    void SET_FortWaterInteraction(const UFortWaterInteractionComponent*& Value) { Write<UFortWaterInteractionComponent*>(uintptr_t(this) + 0x9b8, Value); } // 0x9b8 (Size: 0x8, Type: ObjectProperty)
    void SET_StaticMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x9c0, Value); } // 0x9c0 (Size: 0x8, Type: ObjectProperty)
    void SET_ProjectileMovement(const UProjectileMovementComponent*& Value) { Write<UProjectileMovementComponent*>(uintptr_t(this) + 0x9c8, Value); } // 0x9c8 (Size: 0x8, Type: ObjectProperty)
    void SET_ResumeGravSimOnBegin(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9d0, Value); } // 0x9d0 (Size: 0x1, Type: BoolProperty)
    void SET_bResumeSimulation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x9d1, Value); } // 0x9d1 (Size: 0x1, Type: BoolProperty)
    void SET_NullHit(const FHitResult& Value) { Write<FHitResult>(uintptr_t(this) + 0x9d8, Value); } // 0x9d8 (Size: 0xf8, Type: StructProperty)
    void SET_GravImpact_Loc(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xad0, Value); } // 0xad0 (Size: 0x18, Type: StructProperty)
    void SET_GravHitNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xae8, Value); } // 0xae8 (Size: 0x18, Type: StructProperty)
    void SET_GravMaxSlope(const double& Value) { Write<double>(uintptr_t(this) + 0xb00, Value); } // 0xb00 (Size: 0x8, Type: DoubleProperty)
    void SET_CheckForBounce(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb08, Value); } // 0xb08 (Size: 0x1, Type: BoolProperty)
    void SET_ForcedBounceExtraZ(const double& Value) { Write<double>(uintptr_t(this) + 0xb10, Value); } // 0xb10 (Size: 0x8, Type: DoubleProperty)
    void SET_ForcedBounceCurrentCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb18, Value); } // 0xb18 (Size: 0x4, Type: IntProperty)
    void SET_ForcedBounceMult(const double& Value) { Write<double>(uintptr_t(this) + 0xb20, Value); } // 0xb20 (Size: 0x8, Type: DoubleProperty)
    void SET_GravFoundBuildingOnDied(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0xb28, Value); } // 0xb28 (Size: 0x10, Type: ArrayProperty)
    void SET_RepCollision(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb38, Value); } // 0xb38 (Size: 0x1, Type: BoolProperty)
    void SET_AdditionalBounceObject(const UObject*& Value) { Write<UObject*>(uintptr_t(this) + 0xb40, Value); } // 0xb40 (Size: 0x8, Type: ObjectProperty)
    void SET_ForcedBounceMaxCount(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb48, Value); } // 0xb48 (Size: 0x4, Type: IntProperty)
    void SET_ForceBounce(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb4c, Value); } // 0xb4c (Size: 0x1, Type: BoolProperty)
    void SET_CountNonForceBounces(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb4d, Value); } // 0xb4d (Size: 0x1, Type: BoolProperty)
    void SET_BounceExtraZ(const double& Value) { Write<double>(uintptr_t(this) + 0xb50, Value); } // 0xb50 (Size: 0x8, Type: DoubleProperty)
    void SET_BounceMult(const double& Value) { Write<double>(uintptr_t(this) + 0xb58, Value); } // 0xb58 (Size: 0x8, Type: DoubleProperty)
    void SET_ShouldAttach(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb60, Value); } // 0xb60 (Size: 0x1, Type: BoolProperty)
    void SET_ActorsToNotAttachTo(const TArray<AActor*>& Value) { Write<TArray<AActor*>>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x10, Type: ArrayProperty)
    void SET_DontAttachToOthersOfThisClass(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x1, Type: BoolProperty)
    void SET_DebugText(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb79, Value); } // 0xb79 (Size: 0x1, Type: BoolProperty)
    void SET_ShouldNotReattach(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb7a, Value); } // 0xb7a (Size: 0x1, Type: BoolProperty)
    void SET_BlockStoppingSim(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb7b, Value); } // 0xb7b (Size: 0x1, Type: BoolProperty)
    void SET_DeactivatePawnAndVehicleCollisionOnStop(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb7c, Value); } // 0xb7c (Size: 0x1, Type: BoolProperty)
    void SET_AllowReattachmentToActors(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb7d, Value); } // 0xb7d (Size: 0x1, Type: BoolProperty)
    void SET_StopSimHitResult(const FHitResult& Value) { Write<FHitResult>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0xf8, Type: StructProperty)
    void SET_StopSimServerLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc78, Value); } // 0xc78 (Size: 0x18, Type: StructProperty)
    void SET_BounceAwayFromLocation_MinSpeed(const double& Value) { Write<double>(uintptr_t(this) + 0xc90, Value); } // 0xc90 (Size: 0x8, Type: DoubleProperty)
    void SET_BounceOffTires(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc98, Value); } // 0xc98 (Size: 0x1, Type: BoolProperty)
    void SET_bBounceOnHitNormal(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc99, Value); } // 0xc99 (Size: 0x1, Type: BoolProperty)
    void SET_bCalledStopSim(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc9a, Value); } // 0xc9a (Size: 0x1, Type: BoolProperty)
    void SET_bBounceOffVehicles(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc9b, Value); } // 0xc9b (Size: 0x1, Type: BoolProperty)
};

// Size: 0x11f0
class UMANG_PatrolLayerAnimBP_C : public UFortPatrolAnimLayer
{
public:
    FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables() const { return Read<FAnimBlueprintGeneratedMutableData>(uintptr_t(this) + 0x560); } // 0x560 (Size: 0x1c, Type: StructProperty)
    FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess() const { return Read<FAnimSubsystemInstance>(uintptr_t(this) + 0x580); } // 0x580 (Size: 0x8, Type: StructProperty)
    FAnimSubsystemInstance AnimBlueprintExtension_Base() const { return Read<FAnimSubsystemInstance>(uintptr_t(this) + 0x588); } // 0x588 (Size: 0x8, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_3() const { return Read<FAnimNode_Root>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_2() const { return Read<FAnimNode_LinkedInputPose>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_2() const { return Read<FAnimNode_Root>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_1() const { return Read<FAnimNode_LinkedInputPose>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0xb0, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root_1() const { return Read<FAnimNode_Root>(uintptr_t(this) + 0x730); } // 0x730 (Size: 0x20, Type: StructProperty)
    FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose() const { return Read<FAnimNode_LinkedInputPose>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0xb0, Type: StructProperty)
    FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool() const { return Read<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x800); } // 0x800 (Size: 0x50, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x850); } // 0x850 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x878); } // 0x878 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x8a0); } // 0x8a0 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x8c8); } // 0x8c8 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x8f0); } // 0x8f0 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x918); } // 0x918 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult_1() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x940); } // 0x940 (Size: 0x28, Type: StructProperty)
    FAnimNode_TransitionResult AnimGraphNode_TransitionResult() const { return Read<FAnimNode_TransitionResult>(uintptr_t(this) + 0x968); } // 0x968 (Size: 0x28, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2() const { return Read<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0x990); } // 0x990 (Size: 0x70, Type: StructProperty)
    FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_1() const { return Read<FAnimNode_LayeredBoneBlend>(uintptr_t(this) + 0xa00); } // 0xa00 (Size: 0xe8, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4() const { return Read<FAnimNode_UseCachedPose>(uintptr_t(this) + 0xae8); } // 0xae8 (Size: 0x28, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_3() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0xb10); } // 0xb10 (Size: 0x20, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3() const { return Read<FAnimNode_UseCachedPose>(uintptr_t(this) + 0xb30); } // 0xb30 (Size: 0x28, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_2() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0xb58); } // 0xb58 (Size: 0x20, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_1() const { return Read<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x70, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive_1() const { return Read<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0xbe8); } // 0xbe8 (Size: 0xc8, Type: StructProperty)
    FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend() const { return Read<FAnimNode_LayeredBoneBlend>(uintptr_t(this) + 0xcb0); } // 0xcb0 (Size: 0xe8, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2() const { return Read<FAnimNode_UseCachedPose>(uintptr_t(this) + 0xd98); } // 0xd98 (Size: 0x28, Type: StructProperty)
    FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer() const { return Read<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0xdc0); } // 0xdc0 (Size: 0x70, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult_1() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0xe30); } // 0xe30 (Size: 0x20, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_1() const { return Read<FAnimNode_UseCachedPose>(uintptr_t(this) + 0xe50); } // 0xe50 (Size: 0x28, Type: StructProperty)
    FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive() const { return Read<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0xe78); } // 0xe78 (Size: 0xc8, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_1() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xf40); } // 0xf40 (Size: 0x48, Type: StructProperty)
    FAnimNode_StateResult AnimGraphNode_StateResult() const { return Read<FAnimNode_StateResult>(uintptr_t(this) + 0xf88); } // 0xf88 (Size: 0x20, Type: StructProperty)
    FAnimNode_StateMachine AnimGraphNode_StateMachine() const { return Read<FAnimNode_StateMachine>(uintptr_t(this) + 0xfa8); } // 0xfa8 (Size: 0xc8, Type: StructProperty)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_1() const { return Read<FAnimNode_SaveCachedPose>(uintptr_t(this) + 0x1070); } // 0x1070 (Size: 0x78, Type: StructProperty)
    FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose() const { return Read<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x10e8); } // 0x10e8 (Size: 0x28, Type: StructProperty)
    FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer() const { return Read<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1110); } // 0x1110 (Size: 0x48, Type: StructProperty)
    FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose() const { return Read<FAnimNode_SaveCachedPose>(uintptr_t(this) + 0x1158); } // 0x1158 (Size: 0x78, Type: StructProperty)
    FAnimNode_Root AnimGraphNode_Root() const { return Read<FAnimNode_Root>(uintptr_t(this) + 0x11d0); } // 0x11d0 (Size: 0x20, Type: StructProperty)

    void SET___AnimBlueprintMutables(const FAnimBlueprintGeneratedMutableData& Value) { Write<FAnimBlueprintGeneratedMutableData>(uintptr_t(this) + 0x560, Value); } // 0x560 (Size: 0x1c, Type: StructProperty)
    void SET_AnimBlueprintExtension_PropertyAccess(const FAnimSubsystemInstance& Value) { Write<FAnimSubsystemInstance>(uintptr_t(this) + 0x580, Value); } // 0x580 (Size: 0x8, Type: StructProperty)
    void SET_AnimBlueprintExtension_Base(const FAnimSubsystemInstance& Value) { Write<FAnimSubsystemInstance>(uintptr_t(this) + 0x588, Value); } // 0x588 (Size: 0x8, Type: StructProperty)
    void SET_AnimGraphNode_Root_3(const FAnimNode_Root& Value) { Write<FAnimNode_Root>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_LinkedInputPose_2(const FAnimNode_LinkedInputPose& Value) { Write<FAnimNode_LinkedInputPose>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0xb0, Type: StructProperty)
    void SET_AnimGraphNode_Root_2(const FAnimNode_Root& Value) { Write<FAnimNode_Root>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_LinkedInputPose_1(const FAnimNode_LinkedInputPose& Value) { Write<FAnimNode_LinkedInputPose>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0xb0, Type: StructProperty)
    void SET_AnimGraphNode_Root_1(const FAnimNode_Root& Value) { Write<FAnimNode_Root>(uintptr_t(this) + 0x730, Value); } // 0x730 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_LinkedInputPose(const FAnimNode_LinkedInputPose& Value) { Write<FAnimNode_LinkedInputPose>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0xb0, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool(const FAnimNode_BlendListByBool& Value) { Write<FAnimNode_BlendListByBool>(uintptr_t(this) + 0x800, Value); } // 0x800 (Size: 0x50, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_7(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x850, Value); } // 0x850 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_6(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x878, Value); } // 0x878 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_5(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x8a0, Value); } // 0x8a0 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_4(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x8c8, Value); } // 0x8c8 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_3(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x8f0, Value); } // 0x8f0 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_2(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x918, Value); } // 0x918 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_1(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x940, Value); } // 0x940 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult(const FAnimNode_TransitionResult& Value) { Write<FAnimNode_TransitionResult>(uintptr_t(this) + 0x968, Value); } // 0x968 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer_2(const FAnimNode_BlendSpacePlayer& Value) { Write<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0x990, Value); } // 0x990 (Size: 0x70, Type: StructProperty)
    void SET_AnimGraphNode_LayeredBoneBlend_1(const FAnimNode_LayeredBoneBlend& Value) { Write<FAnimNode_LayeredBoneBlend>(uintptr_t(this) + 0xa00, Value); } // 0xa00 (Size: 0xe8, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_4(const FAnimNode_UseCachedPose& Value) { Write<FAnimNode_UseCachedPose>(uintptr_t(this) + 0xae8, Value); } // 0xae8 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_3(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0xb10, Value); } // 0xb10 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_3(const FAnimNode_UseCachedPose& Value) { Write<FAnimNode_UseCachedPose>(uintptr_t(this) + 0xb30, Value); } // 0xb30 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_2(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0xb58, Value); } // 0xb58 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer_1(const FAnimNode_BlendSpacePlayer& Value) { Write<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x70, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive_1(const FAnimNode_ApplyAdditive& Value) { Write<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0xbe8, Value); } // 0xbe8 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_LayeredBoneBlend(const FAnimNode_LayeredBoneBlend& Value) { Write<FAnimNode_LayeredBoneBlend>(uintptr_t(this) + 0xcb0, Value); } // 0xcb0 (Size: 0xe8, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_2(const FAnimNode_UseCachedPose& Value) { Write<FAnimNode_UseCachedPose>(uintptr_t(this) + 0xd98, Value); } // 0xd98 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer(const FAnimNode_BlendSpacePlayer& Value) { Write<FAnimNode_BlendSpacePlayer>(uintptr_t(this) + 0xdc0, Value); } // 0xdc0 (Size: 0x70, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_1(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0xe30, Value); } // 0xe30 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_1(const FAnimNode_UseCachedPose& Value) { Write<FAnimNode_UseCachedPose>(uintptr_t(this) + 0xe50, Value); } // 0xe50 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive(const FAnimNode_ApplyAdditive& Value) { Write<FAnimNode_ApplyAdditive>(uintptr_t(this) + 0xe78, Value); } // 0xe78 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_1(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0xf40, Value); } // 0xf40 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_StateResult(const FAnimNode_StateResult& Value) { Write<FAnimNode_StateResult>(uintptr_t(this) + 0xf88, Value); } // 0xf88 (Size: 0x20, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine(const FAnimNode_StateMachine& Value) { Write<FAnimNode_StateMachine>(uintptr_t(this) + 0xfa8, Value); } // 0xfa8 (Size: 0xc8, Type: StructProperty)
    void SET_AnimGraphNode_SaveCachedPose_1(const FAnimNode_SaveCachedPose& Value) { Write<FAnimNode_SaveCachedPose>(uintptr_t(this) + 0x1070, Value); } // 0x1070 (Size: 0x78, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose(const FAnimNode_UseCachedPose& Value) { Write<FAnimNode_UseCachedPose>(uintptr_t(this) + 0x10e8, Value); } // 0x10e8 (Size: 0x28, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer(const FAnimNode_SequencePlayer& Value) { Write<FAnimNode_SequencePlayer>(uintptr_t(this) + 0x1110, Value); } // 0x1110 (Size: 0x48, Type: StructProperty)
    void SET_AnimGraphNode_SaveCachedPose(const FAnimNode_SaveCachedPose& Value) { Write<FAnimNode_SaveCachedPose>(uintptr_t(this) + 0x1158, Value); } // 0x1158 (Size: 0x78, Type: StructProperty)
    void SET_AnimGraphNode_Root(const FAnimNode_Root& Value) { Write<FAnimNode_Root>(uintptr_t(this) + 0x11d0, Value); } // 0x11d0 (Size: 0x20, Type: StructProperty)
};

// Size: 0x28
class UNPCFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x398
class UAthenaItemTierWidget_C : public UAthenaItemTierWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: StructProperty)
    UBorder* StarsRarityTint() const { return Read<UBorder*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    USizeBox* RootSizeBox() const { return Read<USizeBox*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UImage* Backing() const { return Read<UImage*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Selected() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    bool ShowBacking() const { return Read<bool>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x1, Type: BoolProperty)
    float BackingHeightOverride() const { return Read<float>(uintptr_t(this) + 0x384); } // 0x384 (Size: 0x4, Type: FloatProperty)
    FMargin BackingStarsPadding() const { return Read<FMargin>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x10, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: StructProperty)
    void SET_StarsRarityTint(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_RootSizeBox(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_Backing(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_Selected(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_ShowBacking(const bool& Value) { Write<bool>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x1, Type: BoolProperty)
    void SET_BackingHeightOverride(const float& Value) { Write<float>(uintptr_t(this) + 0x384, Value); } // 0x384 (Size: 0x4, Type: FloatProperty)
    void SET_BackingStarsPadding(const FMargin& Value) { Write<FMargin>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x10, Type: StructProperty)
};

// Size: 0x3fe
class UAthenaItemIconLoadout_C : public UAthenaItemIcon
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3b8); } // 0x3b8 (Size: 0x8, Type: StructProperty)
    UImage* Shadow() const { return Read<UImage*>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    UImage* SelectionOutline() const { return Read<UImage*>(uintptr_t(this) + 0x3c8); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    UImage* InfoPanel_Backing() const { return Read<UImage*>(uintptr_t(this) + 0x3d0); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* InfoPanel() const { return Read<UOverlay*>(uintptr_t(this) + 0x3d8); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Hover() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Selected_NoOutline() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3e8); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* RecipeHover() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    bool bShowAmmoIcon() const { return Read<bool>(uintptr_t(this) + 0x3f8); } // 0x3f8 (Size: 0x1, Type: BoolProperty)
    bool bShowStackCountText() const { return Read<bool>(uintptr_t(this) + 0x3f9); } // 0x3f9 (Size: 0x1, Type: BoolProperty)
    bool bShowItemTier() const { return Read<bool>(uintptr_t(this) + 0x3fa); } // 0x3fa (Size: 0x1, Type: BoolProperty)
    bool IsHoveredAnimActive() const { return Read<bool>(uintptr_t(this) + 0x3fb); } // 0x3fb (Size: 0x1, Type: BoolProperty)
    bool IsSelectedAnimActive() const { return Read<bool>(uintptr_t(this) + 0x3fc); } // 0x3fc (Size: 0x1, Type: BoolProperty)
    bool IsRecipeHoveredAnimActive() const { return Read<bool>(uintptr_t(this) + 0x3fd); } // 0x3fd (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x3b8, Value); } // 0x3b8 (Size: 0x8, Type: StructProperty)
    void SET_Shadow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectionOutline(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x3c8, Value); } // 0x3c8 (Size: 0x8, Type: ObjectProperty)
    void SET_InfoPanel_Backing(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x3d0, Value); } // 0x3d0 (Size: 0x8, Type: ObjectProperty)
    void SET_InfoPanel(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x3d8, Value); } // 0x3d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Hover(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x8, Type: ObjectProperty)
    void SET_Selected_NoOutline(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3e8, Value); } // 0x3e8 (Size: 0x8, Type: ObjectProperty)
    void SET_RecipeHover(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x8, Type: ObjectProperty)
    void SET_bShowAmmoIcon(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3f8, Value); } // 0x3f8 (Size: 0x1, Type: BoolProperty)
    void SET_bShowStackCountText(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3f9, Value); } // 0x3f9 (Size: 0x1, Type: BoolProperty)
    void SET_bShowItemTier(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3fa, Value); } // 0x3fa (Size: 0x1, Type: BoolProperty)
    void SET_IsHoveredAnimActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3fb, Value); } // 0x3fb (Size: 0x1, Type: BoolProperty)
    void SET_IsSelectedAnimActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3fc, Value); } // 0x3fc (Size: 0x1, Type: BoolProperty)
    void SET_IsRecipeHoveredAnimActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3fd, Value); } // 0x3fd (Size: 0x1, Type: BoolProperty)
};

// Size: 0x350
class UAthenaItemTierPip_C : public UAthenaItemTierPipWidget
{
public:
    UImage* Star() const { return Read<UImage*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)

    void SET_Star(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1730
class UAthenaInventoryEquipSlot_C : public UAthenaInventoryQuickBarSlotButton
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x16a0); } // 0x16a0 (Size: 0x8, Type: StructProperty)
    UOverlay* SwapTargetIndicator() const { return Read<UOverlay*>(uintptr_t(this) + 0x16a8); } // 0x16a8 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SlotSizeBox() const { return Read<USizeBox*>(uintptr_t(this) + 0x16b0); } // 0x16b0 (Size: 0x8, Type: ObjectProperty)
    UScaleBox* ScaleBox_InputAction() const { return Read<UScaleBox*>(uintptr_t(this) + 0x16b8); } // 0x16b8 (Size: 0x8, Type: ObjectProperty)
    UQuickbarSlotDurability_C* QuickbarSlotDurability() const { return Read<UQuickbarSlotDurability_C*>(uintptr_t(this) + 0x16c0); } // 0x16c0 (Size: 0x8, Type: ObjectProperty)
    UOverlay* OverlayExtensionWidgets() const { return Read<UOverlay*>(uintptr_t(this) + 0x16c8); } // 0x16c8 (Size: 0x8, Type: ObjectProperty)
    UAthenaGadgetFuelGauge_C* JetpackFuelGauge() const { return Read<UAthenaGadgetFuelGauge_C*>(uintptr_t(this) + 0x16d0); } // 0x16d0 (Size: 0x8, Type: ObjectProperty)
    UImage* EmptyImage() const { return Read<UImage*>(uintptr_t(this) + 0x16d8); } // 0x16d8 (Size: 0x8, Type: ObjectProperty)
    UBorder* Border_153() const { return Read<UBorder*>(uintptr_t(this) + 0x16e0); } // 0x16e0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* EmptySlotHover() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x16e8); } // 0x16e8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Scale() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x16f0); } // 0x16f0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* UnderlineSelect() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x16f8); } // 0x16f8 (Size: 0x8, Type: ObjectProperty)
    bool bIsSwapOrigin() const { return Read<bool>(uintptr_t(this) + 0x1700); } // 0x1700 (Size: 0x1, Type: BoolProperty)
    bool bHasValidItem() const { return Read<bool>(uintptr_t(this) + 0x1701); } // 0x1701 (Size: 0x1, Type: BoolProperty)
    bool bIsSwapTarget() const { return Read<bool>(uintptr_t(this) + 0x1702); } // 0x1702 (Size: 0x1, Type: BoolProperty)
    bool bIsSelected() const { return Read<bool>(uintptr_t(this) + 0x1703); } // 0x1703 (Size: 0x1, Type: BoolProperty)
    double SingleSlotSize() const { return Read<double>(uintptr_t(this) + 0x1708); } // 0x1708 (Size: 0x8, Type: DoubleProperty)
    bool IsUnderlineSelectStateActive() const { return Read<bool>(uintptr_t(this) + 0x1710); } // 0x1710 (Size: 0x1, Type: BoolProperty)
    bool IsScaleStateActive() const { return Read<bool>(uintptr_t(this) + 0x1711); } // 0x1711 (Size: 0x1, Type: BoolProperty)
    bool IsEmptySlotHoverStateActive() const { return Read<bool>(uintptr_t(this) + 0x1712); } // 0x1712 (Size: 0x1, Type: BoolProperty)
    UAthenaItemIconLoadout_C* AthenaItemIconLoadout() const { return Read<UAthenaItemIconLoadout_C*>(uintptr_t(this) + 0x1718); } // 0x1718 (Size: 0x8, Type: ObjectProperty)
    bool bAddToQuickbarOnDrop() const { return Read<bool>(uintptr_t(this) + 0x1720); } // 0x1720 (Size: 0x1, Type: BoolProperty)
    bool bCanShowSelectedState() const { return Read<bool>(uintptr_t(this) + 0x1721); } // 0x1721 (Size: 0x1, Type: BoolProperty)
    USoundBase* ClickSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x1728); } // 0x1728 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x16a0, Value); } // 0x16a0 (Size: 0x8, Type: StructProperty)
    void SET_SwapTargetIndicator(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x16a8, Value); } // 0x16a8 (Size: 0x8, Type: ObjectProperty)
    void SET_SlotSizeBox(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x16b0, Value); } // 0x16b0 (Size: 0x8, Type: ObjectProperty)
    void SET_ScaleBox_InputAction(const UScaleBox*& Value) { Write<UScaleBox*>(uintptr_t(this) + 0x16b8, Value); } // 0x16b8 (Size: 0x8, Type: ObjectProperty)
    void SET_QuickbarSlotDurability(const UQuickbarSlotDurability_C*& Value) { Write<UQuickbarSlotDurability_C*>(uintptr_t(this) + 0x16c0, Value); } // 0x16c0 (Size: 0x8, Type: ObjectProperty)
    void SET_OverlayExtensionWidgets(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x16c8, Value); } // 0x16c8 (Size: 0x8, Type: ObjectProperty)
    void SET_JetpackFuelGauge(const UAthenaGadgetFuelGauge_C*& Value) { Write<UAthenaGadgetFuelGauge_C*>(uintptr_t(this) + 0x16d0, Value); } // 0x16d0 (Size: 0x8, Type: ObjectProperty)
    void SET_EmptyImage(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x16d8, Value); } // 0x16d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Border_153(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x16e0, Value); } // 0x16e0 (Size: 0x8, Type: ObjectProperty)
    void SET_EmptySlotHover(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x16e8, Value); } // 0x16e8 (Size: 0x8, Type: ObjectProperty)
    void SET_Scale(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x16f0, Value); } // 0x16f0 (Size: 0x8, Type: ObjectProperty)
    void SET_UnderlineSelect(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x16f8, Value); } // 0x16f8 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsSwapOrigin(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1700, Value); } // 0x1700 (Size: 0x1, Type: BoolProperty)
    void SET_bHasValidItem(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1701, Value); } // 0x1701 (Size: 0x1, Type: BoolProperty)
    void SET_bIsSwapTarget(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1702, Value); } // 0x1702 (Size: 0x1, Type: BoolProperty)
    void SET_bIsSelected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1703, Value); } // 0x1703 (Size: 0x1, Type: BoolProperty)
    void SET_SingleSlotSize(const double& Value) { Write<double>(uintptr_t(this) + 0x1708, Value); } // 0x1708 (Size: 0x8, Type: DoubleProperty)
    void SET_IsUnderlineSelectStateActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1710, Value); } // 0x1710 (Size: 0x1, Type: BoolProperty)
    void SET_IsScaleStateActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1711, Value); } // 0x1711 (Size: 0x1, Type: BoolProperty)
    void SET_IsEmptySlotHoverStateActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1712, Value); } // 0x1712 (Size: 0x1, Type: BoolProperty)
    void SET_AthenaItemIconLoadout(const UAthenaItemIconLoadout_C*& Value) { Write<UAthenaItemIconLoadout_C*>(uintptr_t(this) + 0x1718, Value); } // 0x1718 (Size: 0x8, Type: ObjectProperty)
    void SET_bAddToQuickbarOnDrop(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1720, Value); } // 0x1720 (Size: 0x1, Type: BoolProperty)
    void SET_bCanShowSelectedState(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1721, Value); } // 0x1721 (Size: 0x1, Type: BoolProperty)
    void SET_ClickSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x1728, Value); } // 0x1728 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x360
class UAthenaInventoryDragVisual_C : public UFortUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: StructProperty)
    UImage* Shadow() const { return Read<UImage*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    UAthenaItemIconLoadout_C* ItemIcon() const { return Read<UAthenaItemIconLoadout_C*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    UBorder* DropImageContainer() const { return Read<UBorder*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    UImage* DropImage() const { return Read<UImage*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UFortItem* Item() const { return Read<UFortItem*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: StructProperty)
    void SET_Shadow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemIcon(const UAthenaItemIconLoadout_C*& Value) { Write<UAthenaItemIconLoadout_C*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_DropImageContainer(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_DropImage(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_Item(const UFortItem*& Value) { Write<UFortItem*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3b1
class UWBP_Vehicle_Warning_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_Warning() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_WarningPulse() const { return Read<UImage*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_WarningIcon() const { return Read<UImage*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_RoundCard_Bolt() const { return Read<UImage*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Intro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    TArray<TEnumAsByte<ENUM_WarningType>> ActiveWarningTypes() const { return Read<TArray<TEnumAsByte<ENUM_WarningType>>>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x10, Type: ArrayProperty)
    TMap<FSTRUCT_WarningData, TEnumAsByte<ENUM_WarningType>> WarningData() const { return Read<TMap<FSTRUCT_WarningData, TEnumAsByte<ENUM_WarningType>>>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x50, Type: MapProperty)
    TEnumAsByte<ENUM_WarningType> CurrentDisplayedType() const { return Read<TEnumAsByte<ENUM_WarningType>>(uintptr_t(this) + 0x3b0); } // 0x3b0 (Size: 0x1, Type: ByteProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_Text_Warning(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_WarningPulse(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_WarningIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_RoundCard_Bolt(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_Intro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_ActiveWarningTypes(const TArray<TEnumAsByte<ENUM_WarningType>>& Value) { Write<TArray<TEnumAsByte<ENUM_WarningType>>>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x10, Type: ArrayProperty)
    void SET_WarningData(const TMap<FSTRUCT_WarningData, TEnumAsByte<ENUM_WarningType>>& Value) { Write<TMap<FSTRUCT_WarningData, TEnumAsByte<ENUM_WarningType>>>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x50, Type: MapProperty)
    void SET_CurrentDisplayedType(const TEnumAsByte<ENUM_WarningType>& Value) { Write<TEnumAsByte<ENUM_WarningType>>(uintptr_t(this) + 0x3b0, Value); } // 0x3b0 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x1f9
class UMultiInteractActorComponent_C : public UFortActorComponent_MultiInteract
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1d8); } // 0x1d8 (Size: 0x8, Type: StructProperty)
    FGameplayTag RemoveInteractPlayerTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1e0); } // 0x1e0 (Size: 0x4, Type: StructProperty)
    FGameplayTag AddInteractPlayerTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1e4); } // 0x1e4 (Size: 0x4, Type: StructProperty)
    FGameplayTag LoopingMultiInteractTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1e8); } // 0x1e8 (Size: 0x4, Type: StructProperty)
    double RequiredDuration() const { return Read<double>(uintptr_t(this) + 0x1f0); } // 0x1f0 (Size: 0x8, Type: DoubleProperty)
    bool GCNLApplied() const { return Read<bool>(uintptr_t(this) + 0x1f8); } // 0x1f8 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1d8, Value); } // 0x1d8 (Size: 0x8, Type: StructProperty)
    void SET_RemoveInteractPlayerTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1e0, Value); } // 0x1e0 (Size: 0x4, Type: StructProperty)
    void SET_AddInteractPlayerTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1e4, Value); } // 0x1e4 (Size: 0x4, Type: StructProperty)
    void SET_LoopingMultiInteractTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1e8, Value); } // 0x1e8 (Size: 0x4, Type: StructProperty)
    void SET_RequiredDuration(const double& Value) { Write<double>(uintptr_t(this) + 0x1f0, Value); } // 0x1f0 (Size: 0x8, Type: DoubleProperty)
    void SET_GCNLApplied(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f8, Value); } // 0x1f8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa68
class UGE_Athena_Revive_Self_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Lowgrav_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_AntiGrav_C : public UGameplayEffect
{
public:
};

// Size: 0x779
class UContextTutorialIndicator_C : public UAthenaContextTutorialIndicator
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x8, Type: StructProperty)
    UImage* White_Box_Solo() const { return Read<UImage*>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    UImage* White_Box_Child() const { return Read<UImage*>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x8, Type: ObjectProperty)
    UImage* Sign_1() const { return Read<UImage*>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    UImage* Sign() const { return Read<UImage*>(uintptr_t(this) + 0x688); } // 0x688 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_SmallIndicator_Child() const { return Read<UImage*>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_SmallIndicator() const { return Read<UImage*>(uintptr_t(this) + 0x698); } // 0x698 (Size: 0x8, Type: ObjectProperty)
    UImage* Icon_1() const { return Read<UImage*>(uintptr_t(this) + 0x6a0); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    UImage* Icon() const { return Read<UImage*>(uintptr_t(this) + 0x6a8); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    UEditableTextBox* DescriptionOLD() const { return Read<UEditableTextBox*>(uintptr_t(this) + 0x6b0); } // 0x6b0 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Description() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x6b8); } // 0x6b8 (Size: 0x8, Type: ObjectProperty)
    UImage* Circle_1() const { return Read<UImage*>(uintptr_t(this) + 0x6c0); } // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    UImage* Circle() const { return Read<UImage*>(uintptr_t(this) + 0x6c8); } // 0x6c8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_in() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_border() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x6d8); } // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_in_Diamond_Spin() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x6e0); } // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Marker_Idle() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x6e8); } // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_in_DiamondBox_Spin() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Marker_MoveReaction() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x6f8); } // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Diamond_Disappear() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x700); } // 0x700 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_DiamondBox_Fade() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x708); } // 0x708 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_in_Spin_Arrow_Marker() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x710); } // 0x710 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Arrow_Fade() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x718); } // 0x718 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Marker_FadeIN() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x720); } // 0x720 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Out_Arrow_Marker() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x728); } // 0x728 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Arrow_Transition() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x730); } // 0x730 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Arrow_Bounce() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x738); } // 0x738 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Arrow_Disappear() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x740); } // 0x740 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Text_in() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x748); } // 0x748 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Text_Out() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Marker_Out01() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x758); } // 0x758 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Marker_Out02() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x760); } // 0x760 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_Text_Out_Fast() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x768); } // 0x768 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ST_in_bounce() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x770); } // 0x770 (Size: 0x8, Type: ObjectProperty)
    bool bIntroAnimationDone() const { return Read<bool>(uintptr_t(this) + 0x778); } // 0x778 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x8, Type: StructProperty)
    void SET_White_Box_Solo(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    void SET_White_Box_Child(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x8, Type: ObjectProperty)
    void SET_Sign_1(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x8, Type: ObjectProperty)
    void SET_Sign(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x688, Value); } // 0x688 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_SmallIndicator_Child(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_SmallIndicator(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x698, Value); } // 0x698 (Size: 0x8, Type: ObjectProperty)
    void SET_Icon_1(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x6a0, Value); } // 0x6a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Icon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x6a8, Value); } // 0x6a8 (Size: 0x8, Type: ObjectProperty)
    void SET_DescriptionOLD(const UEditableTextBox*& Value) { Write<UEditableTextBox*>(uintptr_t(this) + 0x6b0, Value); } // 0x6b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Description(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x6b8, Value); } // 0x6b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Circle_1(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x6c0, Value); } // 0x6c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Circle(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x6c8, Value); } // 0x6c8 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_in(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_border(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x6d8, Value); } // 0x6d8 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_in_Diamond_Spin(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x6e0, Value); } // 0x6e0 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Marker_Idle(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x6e8, Value); } // 0x6e8 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_in_DiamondBox_Spin(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Marker_MoveReaction(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x6f8, Value); } // 0x6f8 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Diamond_Disappear(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x700, Value); } // 0x700 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_DiamondBox_Fade(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x708, Value); } // 0x708 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_in_Spin_Arrow_Marker(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x710, Value); } // 0x710 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Arrow_Fade(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x718, Value); } // 0x718 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Marker_FadeIN(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x720, Value); } // 0x720 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Out_Arrow_Marker(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x728, Value); } // 0x728 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Arrow_Transition(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x730, Value); } // 0x730 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Arrow_Bounce(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x738, Value); } // 0x738 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Arrow_Disappear(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x740, Value); } // 0x740 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Text_in(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x748, Value); } // 0x748 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Text_Out(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Marker_Out01(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x758, Value); } // 0x758 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Marker_Out02(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x760, Value); } // 0x760 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_Text_Out_Fast(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x768, Value); } // 0x768 (Size: 0x8, Type: ObjectProperty)
    void SET_ST_in_bounce(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x770, Value); } // 0x770 (Size: 0x8, Type: ObjectProperty)
    void SET_bIntroAnimationDone(const bool& Value) { Write<bool>(uintptr_t(this) + 0x778, Value); } // 0x778 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x688
class URebootCardIndicator_C : public UAthenaRebootCardIndicator
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x8, Type: StructProperty)
    UHorizontalBox* RebootCountdownContainer() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x8, Type: ObjectProperty)
    USpacer* IndicatorSpacer() const { return Read<USpacer*>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_RebootIcon() const { return Read<UImage*>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    UImage* burst() const { return Read<UImage*>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x8, Type: ObjectProperty)
    UBorder* Border_Nameplate() const { return Read<UBorder*>(uintptr_t(this) + 0x680); } // 0x680 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x8, Type: StructProperty)
    void SET_RebootCountdownContainer(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x8, Type: ObjectProperty)
    void SET_IndicatorSpacer(const USpacer*& Value) { Write<USpacer*>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_RebootIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x8, Type: ObjectProperty)
    void SET_burst(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x8, Type: ObjectProperty)
    void SET_Border_Nameplate(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x680, Value); } // 0x680 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x678
class URebootVanIndicator_C : public UAthenaRebootVanIndicator
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x8, Type: StructProperty)
    USpacer* IndicatorSpacer() const { return Read<USpacer*>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Van() const { return Read<UImage*>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_SmallIndicator() const { return Read<UImage*>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_RebootIcon() const { return Read<UImage*>(uintptr_t(this) + 0x658); } // 0x658 (Size: 0x8, Type: ObjectProperty)
    UImage* Icon() const { return Read<UImage*>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x8, Type: ObjectProperty)
    UBorder* Border_Nameplate() const { return Read<UBorder*>(uintptr_t(this) + 0x668); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Intro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x670); } // 0x670 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x8, Type: StructProperty)
    void SET_IndicatorSpacer(const USpacer*& Value) { Write<USpacer*>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Van(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_SmallIndicator(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_RebootIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x658, Value); } // 0x658 (Size: 0x8, Type: ObjectProperty)
    void SET_Icon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x8, Type: ObjectProperty)
    void SET_Border_Nameplate(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x668, Value); } // 0x668 (Size: 0x8, Type: ObjectProperty)
    void SET_Intro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x670, Value); } // 0x670 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x658
class UAthenaEliminationIndicator_C : public UAthenaEliminationIndicator
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x8, Type: StructProperty)
    UImage* Image_Diamondpulse() const { return Read<UImage*>(uintptr_t(this) + 0x638); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    UImage* Arrow() const { return Read<UImage*>(uintptr_t(this) + 0x640); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Intro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x648); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Outro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x650); } // 0x650 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x8, Type: StructProperty)
    void SET_Image_Diamondpulse(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x638, Value); } // 0x638 (Size: 0x8, Type: ObjectProperty)
    void SET_Arrow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x640, Value); } // 0x640 (Size: 0x8, Type: ObjectProperty)
    void SET_Intro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x648, Value); } // 0x648 (Size: 0x8, Type: ObjectProperty)
    void SET_Outro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x650, Value); } // 0x650 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa68
class UGE_UnderwaterDamage_C : public UGET_PeriodicEnergyDamage_C
{
public:
};

// Size: 0xdf0
class ABP_Athena_Environmental_ZipLine_Spline_C : public AFortAthenaSplineZipline
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xcc8); } // 0xcc8 (Size: 0x8, Type: StructProperty)
    USphereComponent* EndPointInteractSphere() const { return Read<USphereComponent*>(uintptr_t(this) + 0xcd0); } // 0xcd0 (Size: 0x8, Type: ObjectProperty)
    USphereComponent* StartPointInteractSphere() const { return Read<USphereComponent*>(uintptr_t(this) + 0xcd8); } // 0xcd8 (Size: 0x8, Type: ObjectProperty)
    UStaticMesh* SplineStaticMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0xce0); } // 0xce0 (Size: 0x8, Type: ObjectProperty)
    double TangentSmoothStrength() const { return Read<double>(uintptr_t(this) + 0xce8); } // 0xce8 (Size: 0x8, Type: DoubleProperty)
    bool AutoSmoothTangents() const { return Read<bool>(uintptr_t(this) + 0xcf0); } // 0xcf0 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ESplineMeshAxis> ForwardMeshAxis() const { return Read<TEnumAsByte<ESplineMeshAxis>>(uintptr_t(this) + 0xcf1); } // 0xcf1 (Size: 0x1, Type: ByteProperty)
    FVector MotorOffset() const { return Read<FVector>(uintptr_t(this) + 0xcf8); } // 0xcf8 (Size: 0x18, Type: StructProperty)
    ABuildingActor* PoleA() const { return Read<ABuildingActor*>(uintptr_t(this) + 0xd10); } // 0xd10 (Size: 0x8, Type: ObjectProperty)
    ABuildingActor* PoleB() const { return Read<ABuildingActor*>(uintptr_t(this) + 0xd18); } // 0xd18 (Size: 0x8, Type: ObjectProperty)
    FVector PoleASocketLocation() const { return Read<FVector>(uintptr_t(this) + 0xd20); } // 0xd20 (Size: 0x18, Type: StructProperty)
    FVector PoleBSocketLocation() const { return Read<FVector>(uintptr_t(this) + 0xd38); } // 0xd38 (Size: 0x18, Type: StructProperty)
    int32_t LowerPointID() const { return Read<int32_t>(uintptr_t(this) + 0xd50); } // 0xd50 (Size: 0x4, Type: IntProperty)
    int32_t HigherPointID() const { return Read<int32_t>(uintptr_t(this) + 0xd54); } // 0xd54 (Size: 0x4, Type: IntProperty)
    FVector HigherEndLocation() const { return Read<FVector>(uintptr_t(this) + 0xd58); } // 0xd58 (Size: 0x18, Type: StructProperty)
    FVector LowerEndLocation() const { return Read<FVector>(uintptr_t(this) + 0xd70); } // 0xd70 (Size: 0x18, Type: StructProperty)
    double AutoLinearFactorLow() const { return Read<double>(uintptr_t(this) + 0xd88); } // 0xd88 (Size: 0x8, Type: DoubleProperty)
    double AutoLinearFactorHigh() const { return Read<double>(uintptr_t(this) + 0xd90); } // 0xd90 (Size: 0x8, Type: DoubleProperty)
    double AutoSplineTangentLengthCoef() const { return Read<double>(uintptr_t(this) + 0xd98); } // 0xd98 (Size: 0x8, Type: DoubleProperty)
    double AutoSplineTangentHorizCoef() const { return Read<double>(uintptr_t(this) + 0xda0); } // 0xda0 (Size: 0x8, Type: DoubleProperty)
    double AutoSplineTangentVertCoef() const { return Read<double>(uintptr_t(this) + 0xda8); } // 0xda8 (Size: 0x8, Type: DoubleProperty)
    bool Auto_Set_Spline_Ends() const { return Read<bool>(uintptr_t(this) + 0xdb0); } // 0xdb0 (Size: 0x1, Type: BoolProperty)
    bool Auto_Set_Spline_Mids() const { return Read<bool>(uintptr_t(this) + 0xdb1); } // 0xdb1 (Size: 0x1, Type: BoolProperty)
    TArray<UMaterialInstanceDynamic*> SplineMaterials() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0xdb8); } // 0xdb8 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer BlockInteractTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xdc8); } // 0xdc8 (Size: 0x20, Type: StructProperty)
    double TilingDivisor() const { return Read<double>(uintptr_t(this) + 0xde8); } // 0xde8 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xcc8, Value); } // 0xcc8 (Size: 0x8, Type: StructProperty)
    void SET_EndPointInteractSphere(const USphereComponent*& Value) { Write<USphereComponent*>(uintptr_t(this) + 0xcd0, Value); } // 0xcd0 (Size: 0x8, Type: ObjectProperty)
    void SET_StartPointInteractSphere(const USphereComponent*& Value) { Write<USphereComponent*>(uintptr_t(this) + 0xcd8, Value); } // 0xcd8 (Size: 0x8, Type: ObjectProperty)
    void SET_SplineStaticMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0xce0, Value); } // 0xce0 (Size: 0x8, Type: ObjectProperty)
    void SET_TangentSmoothStrength(const double& Value) { Write<double>(uintptr_t(this) + 0xce8, Value); } // 0xce8 (Size: 0x8, Type: DoubleProperty)
    void SET_AutoSmoothTangents(const bool& Value) { Write<bool>(uintptr_t(this) + 0xcf0, Value); } // 0xcf0 (Size: 0x1, Type: BoolProperty)
    void SET_ForwardMeshAxis(const TEnumAsByte<ESplineMeshAxis>& Value) { Write<TEnumAsByte<ESplineMeshAxis>>(uintptr_t(this) + 0xcf1, Value); } // 0xcf1 (Size: 0x1, Type: ByteProperty)
    void SET_MotorOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xcf8, Value); } // 0xcf8 (Size: 0x18, Type: StructProperty)
    void SET_PoleA(const ABuildingActor*& Value) { Write<ABuildingActor*>(uintptr_t(this) + 0xd10, Value); } // 0xd10 (Size: 0x8, Type: ObjectProperty)
    void SET_PoleB(const ABuildingActor*& Value) { Write<ABuildingActor*>(uintptr_t(this) + 0xd18, Value); } // 0xd18 (Size: 0x8, Type: ObjectProperty)
    void SET_PoleASocketLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd20, Value); } // 0xd20 (Size: 0x18, Type: StructProperty)
    void SET_PoleBSocketLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd38, Value); } // 0xd38 (Size: 0x18, Type: StructProperty)
    void SET_LowerPointID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd50, Value); } // 0xd50 (Size: 0x4, Type: IntProperty)
    void SET_HigherPointID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd54, Value); } // 0xd54 (Size: 0x4, Type: IntProperty)
    void SET_HigherEndLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd58, Value); } // 0xd58 (Size: 0x18, Type: StructProperty)
    void SET_LowerEndLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd70, Value); } // 0xd70 (Size: 0x18, Type: StructProperty)
    void SET_AutoLinearFactorLow(const double& Value) { Write<double>(uintptr_t(this) + 0xd88, Value); } // 0xd88 (Size: 0x8, Type: DoubleProperty)
    void SET_AutoLinearFactorHigh(const double& Value) { Write<double>(uintptr_t(this) + 0xd90, Value); } // 0xd90 (Size: 0x8, Type: DoubleProperty)
    void SET_AutoSplineTangentLengthCoef(const double& Value) { Write<double>(uintptr_t(this) + 0xd98, Value); } // 0xd98 (Size: 0x8, Type: DoubleProperty)
    void SET_AutoSplineTangentHorizCoef(const double& Value) { Write<double>(uintptr_t(this) + 0xda0, Value); } // 0xda0 (Size: 0x8, Type: DoubleProperty)
    void SET_AutoSplineTangentVertCoef(const double& Value) { Write<double>(uintptr_t(this) + 0xda8, Value); } // 0xda8 (Size: 0x8, Type: DoubleProperty)
    void SET_Auto_Set_Spline_Ends(const bool& Value) { Write<bool>(uintptr_t(this) + 0xdb0, Value); } // 0xdb0 (Size: 0x1, Type: BoolProperty)
    void SET_Auto_Set_Spline_Mids(const bool& Value) { Write<bool>(uintptr_t(this) + 0xdb1, Value); } // 0xdb1 (Size: 0x1, Type: BoolProperty)
    void SET_SplineMaterials(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0xdb8, Value); } // 0xdb8 (Size: 0x10, Type: ArrayProperty)
    void SET_BlockInteractTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xdc8, Value); } // 0xdc8 (Size: 0x20, Type: StructProperty)
    void SET_TilingDivisor(const double& Value) { Write<double>(uintptr_t(this) + 0xde8, Value); } // 0xde8 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x2d0
class AB_AthenaAlwaysLoadedContentHack_C : public AActor
{
public:
    USceneComponent* DefaultSceneRoot() const { return Read<USceneComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    TArray<UObject*> HardObjectList() const { return Read<TArray<UObject*>>(uintptr_t(this) + 0x2b0); } // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    TArray<UClass*> HardClassList() const { return Read<TArray<UClass*>>(uintptr_t(this) + 0x2c0); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)

    void SET_DefaultSceneRoot(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
    void SET_HardObjectList(const TArray<UObject*>& Value) { Write<TArray<UObject*>>(uintptr_t(this) + 0x2b0, Value); } // 0x2b0 (Size: 0x10, Type: ArrayProperty)
    void SET_HardClassList(const TArray<UClass*>& Value) { Write<TArray<UClass*>>(uintptr_t(this) + 0x2c0, Value); } // 0x2c0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x1058
class UGA_Athena_Grenade_Rethrow_C : public UGA_Athena_Consumable_Throw_Parent_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1030); } // 0x1030 (Size: 0x8, Type: StructProperty)
    AFortProjectileBase* Projectile() const { return Read<AFortProjectileBase*>(uintptr_t(this) + 0x1038); } // 0x1038 (Size: 0x8, Type: ObjectProperty)
    double TossDelay() const { return Read<double>(uintptr_t(this) + 0x1040); } // 0x1040 (Size: 0x8, Type: DoubleProperty)
    FName HolsterId() const { return Read<FName>(uintptr_t(this) + 0x1048); } // 0x1048 (Size: 0x4, Type: NameProperty)
    double PostThrowEndDelay() const { return Read<double>(uintptr_t(this) + 0x1050); } // 0x1050 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1030, Value); } // 0x1030 (Size: 0x8, Type: StructProperty)
    void SET_Projectile(const AFortProjectileBase*& Value) { Write<AFortProjectileBase*>(uintptr_t(this) + 0x1038, Value); } // 0x1038 (Size: 0x8, Type: ObjectProperty)
    void SET_TossDelay(const double& Value) { Write<double>(uintptr_t(this) + 0x1040, Value); } // 0x1040 (Size: 0x8, Type: DoubleProperty)
    void SET_HolsterId(const FName& Value) { Write<FName>(uintptr_t(this) + 0x1048, Value); } // 0x1048 (Size: 0x4, Type: NameProperty)
    void SET_PostThrowEndDelay(const double& Value) { Write<double>(uintptr_t(this) + 0x1050, Value); } // 0x1050 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xd34
class AB_Prj_Athena_FragGrenade_C : public AB_Prj_Athena_Grenade_Base_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xce0); } // 0xce0 (Size: 0x8, Type: StructProperty)
    UNiagaraComponent* NS_Object_FloatingInWater() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0xce8); } // 0xce8 (Size: 0x8, Type: ObjectProperty)
    UBP_SurfaceTypeSoundComponent_C* BP_SurfaceTypeSoundComponent() const { return Read<UBP_SurfaceTypeSoundComponent_C*>(uintptr_t(this) + 0xcf0); } // 0xcf0 (Size: 0x8, Type: ObjectProperty)
    float PreExploWarning_PreExplo_E5859FFE443F57359EC2C0AB73DFA4CD() const { return Read<float>(uintptr_t(this) + 0xcf8); } // 0xcf8 (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> PreExploWarning__Direction_E5859FFE443F57359EC2C0AB73DFA4CD() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xcfc); } // 0xcfc (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* PreExploWarning() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0xd00); } // 0xd00 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag FeedbackCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd08); } // 0xd08 (Size: 0x4, Type: StructProperty)
    UNiagaraSystem* Niagara_Bounse() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0xd10); } // 0xd10 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<PreExplodeRampType> PreExplodeOptimization() const { return Read<TEnumAsByte<PreExplodeRampType>>(uintptr_t(this) + 0xd18); } // 0xd18 (Size: 0x1, Type: ByteProperty)
    double PreExplodeRampTime() const { return Read<double>(uintptr_t(this) + 0xd20); } // 0xd20 (Size: 0x8, Type: DoubleProperty)
    FName GrenadeFuseParamName() const { return Read<FName>(uintptr_t(this) + 0xd28); } // 0xd28 (Size: 0x4, Type: NameProperty)
    float PreExplodeTimerRampFrequency() const { return Read<float>(uintptr_t(this) + 0xd2c); } // 0xd2c (Size: 0x4, Type: FloatProperty)
    float PreExplodeTimerAccumulatedRampTime() const { return Read<float>(uintptr_t(this) + 0xd30); } // 0xd30 (Size: 0x4, Type: FloatProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xce0, Value); } // 0xce0 (Size: 0x8, Type: StructProperty)
    void SET_NS_Object_FloatingInWater(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0xce8, Value); } // 0xce8 (Size: 0x8, Type: ObjectProperty)
    void SET_BP_SurfaceTypeSoundComponent(const UBP_SurfaceTypeSoundComponent_C*& Value) { Write<UBP_SurfaceTypeSoundComponent_C*>(uintptr_t(this) + 0xcf0, Value); } // 0xcf0 (Size: 0x8, Type: ObjectProperty)
    void SET_PreExploWarning_PreExplo_E5859FFE443F57359EC2C0AB73DFA4CD(const float& Value) { Write<float>(uintptr_t(this) + 0xcf8, Value); } // 0xcf8 (Size: 0x4, Type: FloatProperty)
    void SET_PreExploWarning__Direction_E5859FFE443F57359EC2C0AB73DFA4CD(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xcfc, Value); } // 0xcfc (Size: 0x1, Type: ByteProperty)
    void SET_PreExploWarning(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0xd00, Value); } // 0xd00 (Size: 0x8, Type: ObjectProperty)
    void SET_FeedbackCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd08, Value); } // 0xd08 (Size: 0x4, Type: StructProperty)
    void SET_Niagara_Bounse(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0xd10, Value); } // 0xd10 (Size: 0x8, Type: ObjectProperty)
    void SET_PreExplodeOptimization(const TEnumAsByte<PreExplodeRampType>& Value) { Write<TEnumAsByte<PreExplodeRampType>>(uintptr_t(this) + 0xd18, Value); } // 0xd18 (Size: 0x1, Type: ByteProperty)
    void SET_PreExplodeRampTime(const double& Value) { Write<double>(uintptr_t(this) + 0xd20, Value); } // 0xd20 (Size: 0x8, Type: DoubleProperty)
    void SET_GrenadeFuseParamName(const FName& Value) { Write<FName>(uintptr_t(this) + 0xd28, Value); } // 0xd28 (Size: 0x4, Type: NameProperty)
    void SET_PreExplodeTimerRampFrequency(const float& Value) { Write<float>(uintptr_t(this) + 0xd2c, Value); } // 0xd2c (Size: 0x4, Type: FloatProperty)
    void SET_PreExplodeTimerAccumulatedRampTime(const float& Value) { Write<float>(uintptr_t(this) + 0xd30, Value); } // 0xd30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xcde
class AB_Prj_Athena_Grenade_Base_C : public AFortProjectileBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb58); } // 0xb58 (Size: 0x8, Type: StructProperty)
    UNiagaraComponent* NS_Fuse_Particle() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0xb60); } // 0xb60 (Size: 0x8, Type: ObjectProperty)
    UFortCollisionAudioComponent* FortCollisionAudio() const { return Read<UFortCollisionAudioComponent*>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: ObjectProperty)
    URotatingMovementComponent* RotatingMovement() const { return Read<URotatingMovementComponent*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Mesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* GrenadeFuse_AudioComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* Effect_Distance() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UParticleSystem> P_Explosion() const { return Read<TSoftObjectPtr<UParticleSystem>>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x20, Type: SoftObjectProperty)
    USoundBase* Cue_ExplosionSound() const { return Read<USoundBase*>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x8, Type: ObjectProperty)
    TSoftObjectPtr<UParticleSystem> P_Explosion_Water() const { return Read<TSoftObjectPtr<UParticleSystem>>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x20, Type: SoftObjectProperty)
    int32_t NumberOfBouncesTillExplode() const { return Read<int32_t>(uintptr_t(this) + 0xbd8); } // 0xbd8 (Size: 0x4, Type: IntProperty)
    int32_t CurrentNumberOfBounces() const { return Read<int32_t>(uintptr_t(this) + 0xbdc); } // 0xbdc (Size: 0x4, Type: IntProperty)
    USoundBase* Cue_GrenadeFuseSound() const { return Read<USoundBase*>(uintptr_t(this) + 0xbe0); } // 0xbe0 (Size: 0x8, Type: ObjectProperty)
    double BouncePawnAgainstPawnGravityScale() const { return Read<double>(uintptr_t(this) + 0xbe8); } // 0xbe8 (Size: 0x8, Type: DoubleProperty)
    UForceFeedbackEffect* ExplosionForceFeedbackNear() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0xbf0); } // 0xbf0 (Size: 0x8, Type: ObjectProperty)
    UForceFeedbackEffect* ExplosionForceFeedbackFar() const { return Read<UForceFeedbackEffect*>(uintptr_t(this) + 0xbf8); } // 0xbf8 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Cue_Bounce() const { return Read<USoundBase*>(uintptr_t(this) + 0xc00); } // 0xc00 (Size: 0x8, Type: ObjectProperty)
    UClass* ExplosionCameraShake() const { return Read<UClass*>(uintptr_t(this) + 0xc08); } // 0xc08 (Size: 0x8, Type: ClassProperty)
    double FuseTime() const { return Read<double>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x8, Type: DoubleProperty)
    double ExplosionRadius() const { return Read<double>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x8, Type: DoubleProperty)
    FRotator Explosion_Rotation() const { return Read<FRotator>(uintptr_t(this) + 0xc20); } // 0xc20 (Size: 0x18, Type: StructProperty)
    UAudioComponent* WaterFuseAudioComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Water_Debris_Explosion() const { return Read<USoundBase*>(uintptr_t(this) + 0xc40); } // 0xc40 (Size: 0x8, Type: ObjectProperty)
    USoundBase* Splash_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0xc48); } // 0xc48 (Size: 0x8, Type: ObjectProperty)
    UTexture* SoundIndicatorIcon() const { return Read<UTexture*>(uintptr_t(this) + 0xc50); } // 0xc50 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle FuseIndicatorTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0xc58); } // 0xc58 (Size: 0x8, Type: StructProperty)
    TSoftObjectPtr<UNiagaraSystem> NS_Explosion() const { return Read<TSoftObjectPtr<UNiagaraSystem>>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x20, Type: SoftObjectProperty)
    TSoftObjectPtr<UNiagaraSystem> NS_Explosion_Water() const { return Read<TSoftObjectPtr<UNiagaraSystem>>(uintptr_t(this) + 0xc80); } // 0xc80 (Size: 0x20, Type: SoftObjectProperty)
    uint8_t FXType() const { return Read<uint8_t>(uintptr_t(this) + 0xca0); } // 0xca0 (Size: 0x1, Type: EnumProperty)
    UFXSystemAsset* VFX_Explosion() const { return Read<UFXSystemAsset*>(uintptr_t(this) + 0xca8); } // 0xca8 (Size: 0x8, Type: ObjectProperty)
    UFXSystemAsset* VFX_Explosion_Water() const { return Read<UFXSystemAsset*>(uintptr_t(this) + 0xcb0); } // 0xcb0 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle FuseTimer_() const { return Read<FTimerHandle>(uintptr_t(this) + 0xcb8); } // 0xcb8 (Size: 0x8, Type: StructProperty)
    UNiagaraSystem* NS_HitWater() const { return Read<UNiagaraSystem*>(uintptr_t(this) + 0xcc0); } // 0xcc0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* WaterFuseSound() const { return Read<USoundBase*>(uintptr_t(this) + 0xcc8); } // 0xcc8 (Size: 0x8, Type: ObjectProperty)
    UFXSystemAsset* FX_Physical_Surface() const { return Read<UFXSystemAsset*>(uintptr_t(this) + 0xcd0); } // 0xcd0 (Size: 0x8, Type: ObjectProperty)
    int32_t PhysicalSurfaceID() const { return Read<int32_t>(uintptr_t(this) + 0xcd8); } // 0xcd8 (Size: 0x4, Type: IntProperty)
    bool bShowFuseSoundIndicator() const { return Read<bool>(uintptr_t(this) + 0xcdc); } // 0xcdc (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<EPhysicalSurface> E_Surface_Type() const { return Read<TEnumAsByte<EPhysicalSurface>>(uintptr_t(this) + 0xcdd); } // 0xcdd (Size: 0x1, Type: ByteProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb58, Value); } // 0xb58 (Size: 0x8, Type: StructProperty)
    void SET_NS_Fuse_Particle(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0xb60, Value); } // 0xb60 (Size: 0x8, Type: ObjectProperty)
    void SET_FortCollisionAudio(const UFortCollisionAudioComponent*& Value) { Write<UFortCollisionAudioComponent*>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: ObjectProperty)
    void SET_RotatingMovement(const URotatingMovementComponent*& Value) { Write<URotatingMovementComponent*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_Mesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    void SET_GrenadeFuse_AudioComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    void SET_Effect_Distance(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x8, Type: ObjectProperty)
    void SET_P_Explosion(const TSoftObjectPtr<UParticleSystem>& Value) { Write<TSoftObjectPtr<UParticleSystem>>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x20, Type: SoftObjectProperty)
    void SET_Cue_ExplosionSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x8, Type: ObjectProperty)
    void SET_P_Explosion_Water(const TSoftObjectPtr<UParticleSystem>& Value) { Write<TSoftObjectPtr<UParticleSystem>>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x20, Type: SoftObjectProperty)
    void SET_NumberOfBouncesTillExplode(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xbd8, Value); } // 0xbd8 (Size: 0x4, Type: IntProperty)
    void SET_CurrentNumberOfBounces(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xbdc, Value); } // 0xbdc (Size: 0x4, Type: IntProperty)
    void SET_Cue_GrenadeFuseSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xbe0, Value); } // 0xbe0 (Size: 0x8, Type: ObjectProperty)
    void SET_BouncePawnAgainstPawnGravityScale(const double& Value) { Write<double>(uintptr_t(this) + 0xbe8, Value); } // 0xbe8 (Size: 0x8, Type: DoubleProperty)
    void SET_ExplosionForceFeedbackNear(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0xbf0, Value); } // 0xbf0 (Size: 0x8, Type: ObjectProperty)
    void SET_ExplosionForceFeedbackFar(const UForceFeedbackEffect*& Value) { Write<UForceFeedbackEffect*>(uintptr_t(this) + 0xbf8, Value); } // 0xbf8 (Size: 0x8, Type: ObjectProperty)
    void SET_Cue_Bounce(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xc00, Value); } // 0xc00 (Size: 0x8, Type: ObjectProperty)
    void SET_ExplosionCameraShake(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc08, Value); } // 0xc08 (Size: 0x8, Type: ClassProperty)
    void SET_FuseTime(const double& Value) { Write<double>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x8, Type: DoubleProperty)
    void SET_ExplosionRadius(const double& Value) { Write<double>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x8, Type: DoubleProperty)
    void SET_Explosion_Rotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0xc20, Value); } // 0xc20 (Size: 0x18, Type: StructProperty)
    void SET_WaterFuseAudioComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x8, Type: ObjectProperty)
    void SET_Water_Debris_Explosion(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xc40, Value); } // 0xc40 (Size: 0x8, Type: ObjectProperty)
    void SET_Splash_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xc48, Value); } // 0xc48 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundIndicatorIcon(const UTexture*& Value) { Write<UTexture*>(uintptr_t(this) + 0xc50, Value); } // 0xc50 (Size: 0x8, Type: ObjectProperty)
    void SET_FuseIndicatorTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xc58, Value); } // 0xc58 (Size: 0x8, Type: StructProperty)
    void SET_NS_Explosion(const TSoftObjectPtr<UNiagaraSystem>& Value) { Write<TSoftObjectPtr<UNiagaraSystem>>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x20, Type: SoftObjectProperty)
    void SET_NS_Explosion_Water(const TSoftObjectPtr<UNiagaraSystem>& Value) { Write<TSoftObjectPtr<UNiagaraSystem>>(uintptr_t(this) + 0xc80, Value); } // 0xc80 (Size: 0x20, Type: SoftObjectProperty)
    void SET_FXType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xca0, Value); } // 0xca0 (Size: 0x1, Type: EnumProperty)
    void SET_VFX_Explosion(const UFXSystemAsset*& Value) { Write<UFXSystemAsset*>(uintptr_t(this) + 0xca8, Value); } // 0xca8 (Size: 0x8, Type: ObjectProperty)
    void SET_VFX_Explosion_Water(const UFXSystemAsset*& Value) { Write<UFXSystemAsset*>(uintptr_t(this) + 0xcb0, Value); } // 0xcb0 (Size: 0x8, Type: ObjectProperty)
    void SET_FuseTimer_(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xcb8, Value); } // 0xcb8 (Size: 0x8, Type: StructProperty)
    void SET_NS_HitWater(const UNiagaraSystem*& Value) { Write<UNiagaraSystem*>(uintptr_t(this) + 0xcc0, Value); } // 0xcc0 (Size: 0x8, Type: ObjectProperty)
    void SET_WaterFuseSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xcc8, Value); } // 0xcc8 (Size: 0x8, Type: ObjectProperty)
    void SET_FX_Physical_Surface(const UFXSystemAsset*& Value) { Write<UFXSystemAsset*>(uintptr_t(this) + 0xcd0, Value); } // 0xcd0 (Size: 0x8, Type: ObjectProperty)
    void SET_PhysicalSurfaceID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xcd8, Value); } // 0xcd8 (Size: 0x4, Type: IntProperty)
    void SET_bShowFuseSoundIndicator(const bool& Value) { Write<bool>(uintptr_t(this) + 0xcdc, Value); } // 0xcdc (Size: 0x1, Type: BoolProperty)
    void SET_E_Surface_Type(const TEnumAsByte<EPhysicalSurface>& Value) { Write<TEnumAsByte<EPhysicalSurface>>(uintptr_t(this) + 0xcdd, Value); } // 0xcdd (Size: 0x1, Type: ByteProperty)
};

// Size: 0xa68
class UGE_Athena_FallDmgImmune_FX_C : public UGameplayEffect
{
public:
};

// Size: 0x28
class UAthenaFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0xd10
class AAthena_Prop_ParentBuildingContainerBlueprint_C : public ABuildingProp
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc00); } // 0xc00 (Size: 0x8, Type: StructProperty)
    bool DebugWind() const { return Read<bool>(uintptr_t(this) + 0xc08); } // 0xc08 (Size: 0x1, Type: BoolProperty)
    TArray<UMaterialInterface*> IntenseWindMaterialsForPreview() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x10, Type: ArrayProperty)
    UStaticMeshComponent* Wind_Intensity_Debug_Mesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xc20); } // 0xc20 (Size: 0x8, Type: ObjectProperty)
    TArray<UMaterialInterface*> OriginalMaterials() const { return Read<TArray<UMaterialInterface*>>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x10, Type: ArrayProperty)
    UMaterialInstanceDynamic* Debug_TempMaterial() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xc38); } // 0xc38 (Size: 0x8, Type: ObjectProperty)
    double DebugWindYaw() const { return Read<double>(uintptr_t(this) + 0xc40); } // 0xc40 (Size: 0x8, Type: DoubleProperty)
    double Debug_Wind_Intensity() const { return Read<double>(uintptr_t(this) + 0xc48); } // 0xc48 (Size: 0x8, Type: DoubleProperty)
    bool Set_Max_Actor_Scale() const { return Read<bool>(uintptr_t(this) + 0xc50); } // 0xc50 (Size: 0x1, Type: BoolProperty)
    double Max_Scale() const { return Read<double>(uintptr_t(this) + 0xc58); } // 0xc58 (Size: 0x8, Type: DoubleProperty)
    bool Disable_TOD_Lights_and_Material_Emissive_Values() const { return Read<bool>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x1, Type: BoolProperty)
    bool Disable_Static_Mesh_Shadow_Casting_When_Lights_Are_Active() const { return Read<bool>(uintptr_t(this) + 0xc61); } // 0xc61 (Size: 0x1, Type: BoolProperty)
    bool Use_An_Alternate_Shadow_Mesh_When_The_Light_is_On_() const { return Read<bool>(uintptr_t(this) + 0xc62); } // 0xc62 (Size: 0x1, Type: BoolProperty)
    UStaticMesh* AlternateShadowStaticMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0xc68); } // 0xc68 (Size: 0x8, Type: ObjectProperty)
    bool Animate_Emissive_and_Lights_Over_Time() const { return Read<bool>(uintptr_t(this) + 0xc70); } // 0xc70 (Size: 0x1, Type: BoolProperty)
    TArray<FLinearColor> CodeControlled_EmissiveColor() const { return Read<TArray<FLinearColor>>(uintptr_t(this) + 0xc78); } // 0xc78 (Size: 0x10, Type: ArrayProperty)
    TArray<double> CodeControlled_LightConeOpacity() const { return Read<TArray<double>>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x10, Type: ArrayProperty)
    FDayPhaseFloats Light_Intensity_Over_Time_of_Day_() const { return Read<FDayPhaseFloats>(uintptr_t(this) + 0xc98); } // 0xc98 (Size: 0x10, Type: StructProperty)
    double Day_Phase_Transition_Length() const { return Read<double>(uintptr_t(this) + 0xca8); } // 0xca8 (Size: 0x8, Type: DoubleProperty)
    FDayPhaseFloats Emissive_Intensity_Over_Time_of_Day() const { return Read<FDayPhaseFloats>(uintptr_t(this) + 0xcb0); } // 0xcb0 (Size: 0x10, Type: StructProperty)
    double Volumetric_Light_Scattering_Intensity() const { return Read<double>(uintptr_t(this) + 0xcc0); } // 0xcc0 (Size: 0x8, Type: DoubleProperty)
    bool Cast_Volumetric_Shadows() const { return Read<bool>(uintptr_t(this) + 0xcc8); } // 0xcc8 (Size: 0x1, Type: BoolProperty)
    bool Animate_Lights_With_A_Curve___Disables_time_of_day_light_controls() const { return Read<bool>(uintptr_t(this) + 0xcc9); } // 0xcc9 (Size: 0x1, Type: BoolProperty)
    bool Animate_Mesh_MID_Emissive_Value_with_a_Curve___Disables_time_of_day_light_controls() const { return Read<bool>(uintptr_t(this) + 0xcca); } // 0xcca (Size: 0x1, Type: BoolProperty)
    UCurveFloat* LightAnimationCurve() const { return Read<UCurveFloat*>(uintptr_t(this) + 0xcd0); } // 0xcd0 (Size: 0x8, Type: ObjectProperty)
    double CodeControlled_Animation_Curve_Animation_Length() const { return Read<double>(uintptr_t(this) + 0xcd8); } // 0xcd8 (Size: 0x8, Type: DoubleProperty)
    int32_t CodeControlled_NumberOfMaterials() const { return Read<int32_t>(uintptr_t(this) + 0xce0); } // 0xce0 (Size: 0x4, Type: IntProperty)
    TArray<double> NewVar_0() const { return Read<TArray<double>>(uintptr_t(this) + 0xce8); } // 0xce8 (Size: 0x10, Type: ArrayProperty)
    double Random_Time_Scale_Percent() const { return Read<double>(uintptr_t(this) + 0xcf8); } // 0xcf8 (Size: 0x8, Type: DoubleProperty)
    double CodeControlled_CurrentPlayLength() const { return Read<double>(uintptr_t(this) + 0xd00); } // 0xd00 (Size: 0x8, Type: DoubleProperty)
    double Snow_Coverage_Amount() const { return Read<double>(uintptr_t(this) + 0xd08); } // 0xd08 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc00, Value); } // 0xc00 (Size: 0x8, Type: StructProperty)
    void SET_DebugWind(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc08, Value); } // 0xc08 (Size: 0x1, Type: BoolProperty)
    void SET_IntenseWindMaterialsForPreview(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x10, Type: ArrayProperty)
    void SET_Wind_Intensity_Debug_Mesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xc20, Value); } // 0xc20 (Size: 0x8, Type: ObjectProperty)
    void SET_OriginalMaterials(const TArray<UMaterialInterface*>& Value) { Write<TArray<UMaterialInterface*>>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x10, Type: ArrayProperty)
    void SET_Debug_TempMaterial(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xc38, Value); } // 0xc38 (Size: 0x8, Type: ObjectProperty)
    void SET_DebugWindYaw(const double& Value) { Write<double>(uintptr_t(this) + 0xc40, Value); } // 0xc40 (Size: 0x8, Type: DoubleProperty)
    void SET_Debug_Wind_Intensity(const double& Value) { Write<double>(uintptr_t(this) + 0xc48, Value); } // 0xc48 (Size: 0x8, Type: DoubleProperty)
    void SET_Set_Max_Actor_Scale(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc50, Value); } // 0xc50 (Size: 0x1, Type: BoolProperty)
    void SET_Max_Scale(const double& Value) { Write<double>(uintptr_t(this) + 0xc58, Value); } // 0xc58 (Size: 0x8, Type: DoubleProperty)
    void SET_Disable_TOD_Lights_and_Material_Emissive_Values(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x1, Type: BoolProperty)
    void SET_Disable_Static_Mesh_Shadow_Casting_When_Lights_Are_Active(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc61, Value); } // 0xc61 (Size: 0x1, Type: BoolProperty)
    void SET_Use_An_Alternate_Shadow_Mesh_When_The_Light_is_On_(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc62, Value); } // 0xc62 (Size: 0x1, Type: BoolProperty)
    void SET_AlternateShadowStaticMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0xc68, Value); } // 0xc68 (Size: 0x8, Type: ObjectProperty)
    void SET_Animate_Emissive_and_Lights_Over_Time(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc70, Value); } // 0xc70 (Size: 0x1, Type: BoolProperty)
    void SET_CodeControlled_EmissiveColor(const TArray<FLinearColor>& Value) { Write<TArray<FLinearColor>>(uintptr_t(this) + 0xc78, Value); } // 0xc78 (Size: 0x10, Type: ArrayProperty)
    void SET_CodeControlled_LightConeOpacity(const TArray<double>& Value) { Write<TArray<double>>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x10, Type: ArrayProperty)
    void SET_Light_Intensity_Over_Time_of_Day_(const FDayPhaseFloats& Value) { Write<FDayPhaseFloats>(uintptr_t(this) + 0xc98, Value); } // 0xc98 (Size: 0x10, Type: StructProperty)
    void SET_Day_Phase_Transition_Length(const double& Value) { Write<double>(uintptr_t(this) + 0xca8, Value); } // 0xca8 (Size: 0x8, Type: DoubleProperty)
    void SET_Emissive_Intensity_Over_Time_of_Day(const FDayPhaseFloats& Value) { Write<FDayPhaseFloats>(uintptr_t(this) + 0xcb0, Value); } // 0xcb0 (Size: 0x10, Type: StructProperty)
    void SET_Volumetric_Light_Scattering_Intensity(const double& Value) { Write<double>(uintptr_t(this) + 0xcc0, Value); } // 0xcc0 (Size: 0x8, Type: DoubleProperty)
    void SET_Cast_Volumetric_Shadows(const bool& Value) { Write<bool>(uintptr_t(this) + 0xcc8, Value); } // 0xcc8 (Size: 0x1, Type: BoolProperty)
    void SET_Animate_Lights_With_A_Curve___Disables_time_of_day_light_controls(const bool& Value) { Write<bool>(uintptr_t(this) + 0xcc9, Value); } // 0xcc9 (Size: 0x1, Type: BoolProperty)
    void SET_Animate_Mesh_MID_Emissive_Value_with_a_Curve___Disables_time_of_day_light_controls(const bool& Value) { Write<bool>(uintptr_t(this) + 0xcca, Value); } // 0xcca (Size: 0x1, Type: BoolProperty)
    void SET_LightAnimationCurve(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0xcd0, Value); } // 0xcd0 (Size: 0x8, Type: ObjectProperty)
    void SET_CodeControlled_Animation_Curve_Animation_Length(const double& Value) { Write<double>(uintptr_t(this) + 0xcd8, Value); } // 0xcd8 (Size: 0x8, Type: DoubleProperty)
    void SET_CodeControlled_NumberOfMaterials(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xce0, Value); } // 0xce0 (Size: 0x4, Type: IntProperty)
    void SET_NewVar_0(const TArray<double>& Value) { Write<TArray<double>>(uintptr_t(this) + 0xce8, Value); } // 0xce8 (Size: 0x10, Type: ArrayProperty)
    void SET_Random_Time_Scale_Percent(const double& Value) { Write<double>(uintptr_t(this) + 0xcf8, Value); } // 0xcf8 (Size: 0x8, Type: DoubleProperty)
    void SET_CodeControlled_CurrentPlayLength(const double& Value) { Write<double>(uintptr_t(this) + 0xd00, Value); } // 0xd00 (Size: 0x8, Type: DoubleProperty)
    void SET_Snow_Coverage_Amount(const double& Value) { Write<double>(uintptr_t(this) + 0xd08, Value); } // 0xd08 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0xbe0
class UGA_WilliePete_PlayerLaunch_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawnAthena* OwningPawn() const { return Read<AFortPlayerPawnAthena*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* ExitMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat LaunchHeightValue() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x28, Type: StructProperty)
    AB_HidingProp_WilliePete_C* WilliePeteLauncher() const { return Read<AB_HidingProp_WilliePete_C*>(uintptr_t(this) + 0xba8); } // 0xba8 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer PlayerLaunchTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x20, Type: StructProperty)
    UClass* GE_WilliePete_PlayerLaunch_ApplyGC() const { return Read<UClass*>(uintptr_t(this) + 0xbd0); } // 0xbd0 (Size: 0x8, Type: ClassProperty)
    AFortPlayerPawnAthena* TeleportExitPlayer() const { return Read<AFortPlayerPawnAthena*>(uintptr_t(this) + 0xbd8); } // 0xbd8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_OwningPawn(const AFortPlayerPawnAthena*& Value) { Write<AFortPlayerPawnAthena*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_ExitMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    void SET_LaunchHeightValue(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x28, Type: StructProperty)
    void SET_WilliePeteLauncher(const AB_HidingProp_WilliePete_C*& Value) { Write<AB_HidingProp_WilliePete_C*>(uintptr_t(this) + 0xba8, Value); } // 0xba8 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayerLaunchTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x20, Type: StructProperty)
    void SET_GE_WilliePete_PlayerLaunch_ApplyGC(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xbd0, Value); } // 0xbd0 (Size: 0x8, Type: ClassProperty)
    void SET_TeleportExitPlayer(const AFortPlayerPawnAthena*& Value) { Write<AFortPlayerPawnAthena*>(uintptr_t(this) + 0xbd8, Value); } // 0xbd8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x14aa
class AB_HidingProp_WilliePete_C : public AB_HidingProp_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1260); } // 0x1260 (Size: 0x8, Type: StructProperty)
    UStaticMeshComponent* overlapCylinder() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x1268); } // 0x1268 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* WilliePete_Ambient_Loop() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x1270); } // 0x1270 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Geyser() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x1278); } // 0x1278 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* S_Whirlpool_01() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x1280); } // 0x1280 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* P_WilliePete_SurfaceVerticalSplash() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x1288); } // 0x1288 (Size: 0x8, Type: ObjectProperty)
    UFortProjectileMovementComponent* OverlappedFortProjectileMovementComponent() const { return Read<UFortProjectileMovementComponent*>(uintptr_t(this) + 0x1290); } // 0x1290 (Size: 0x8, Type: ObjectProperty)
    UProjectileMovementComponent* OverlappedStandardProjectileMovementComponent() const { return Read<UProjectileMovementComponent*>(uintptr_t(this) + 0x1298); } // 0x1298 (Size: 0x8, Type: ObjectProperty)
    AActor* TeleportingNonPawn() const { return Read<AActor*>(uintptr_t(this) + 0x12a0); } // 0x12a0 (Size: 0x8, Type: ObjectProperty)
    FHitResult SphereOverlapResult() const { return Read<FHitResult>(uintptr_t(this) + 0x12a8); } // 0x12a8 (Size: 0xf8, Type: StructProperty)
    double ProjectileSpeedCeiling() const { return Read<double>(uintptr_t(this) + 0x13a0); } // 0x13a0 (Size: 0x8, Type: DoubleProperty)
    FRotator ProjectileExitFVectorRotation() const { return Read<FRotator>(uintptr_t(this) + 0x13a8); } // 0x13a8 (Size: 0x18, Type: StructProperty)
    int32_t WaterLevel() const { return Read<int32_t>(uintptr_t(this) + 0x13c0); } // 0x13c0 (Size: 0x4, Type: IntProperty)
    FGameplayTag GC_Exit() const { return Read<FGameplayTag>(uintptr_t(this) + 0x13c4); } // 0x13c4 (Size: 0x4, Type: StructProperty)
    FGameplayTag GC_Enter() const { return Read<FGameplayTag>(uintptr_t(this) + 0x13c8); } // 0x13c8 (Size: 0x4, Type: StructProperty)
    FScalableFloat EnabledValue() const { return Read<FScalableFloat>(uintptr_t(this) + 0x13d0); } // 0x13d0 (Size: 0x28, Type: StructProperty)
    FScalableFloat LaunchHeightValue() const { return Read<FScalableFloat>(uintptr_t(this) + 0x13f8); } // 0x13f8 (Size: 0x28, Type: StructProperty)
    AFortPlayerPawnAthena* LaunchPawn() const { return Read<AFortPlayerPawnAthena*>(uintptr_t(this) + 0x1420); } // 0x1420 (Size: 0x8, Type: ObjectProperty)
    FActiveGameplayEffectHandle LaunchGrantedEffectHandle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x1428); } // 0x1428 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer T_Quest() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x1430); } // 0x1430 (Size: 0x20, Type: StructProperty)
    UClass* SpawnedWaterBody() const { return Read<UClass*>(uintptr_t(this) + 0x1450); } // 0x1450 (Size: 0x8, Type: ClassProperty)
    FGameplayTag GC_ScreenFX() const { return Read<FGameplayTag>(uintptr_t(this) + 0x1458); } // 0x1458 (Size: 0x4, Type: StructProperty)
    bool isOnTestMap() const { return Read<bool>(uintptr_t(this) + 0x145c); } // 0x145c (Size: 0x1, Type: BoolProperty)
    USoundBase* Launch_Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x1460); } // 0x1460 (Size: 0x8, Type: ObjectProperty)
    FVector AdjustedLocation() const { return Read<FVector>(uintptr_t(this) + 0x1468); } // 0x1468 (Size: 0x18, Type: StructProperty)
    bool skipAnimForLaunch() const { return Read<bool>(uintptr_t(this) + 0x1480); } // 0x1480 (Size: 0x1, Type: BoolProperty)
    AFortPlayerPawnAthena* ExitingPawn() const { return Read<AFortPlayerPawnAthena*>(uintptr_t(this) + 0x1488); } // 0x1488 (Size: 0x8, Type: ObjectProperty)
    UMovementComponent* OverlappedMovementComponent() const { return Read<UMovementComponent*>(uintptr_t(this) + 0x1490); } // 0x1490 (Size: 0x8, Type: ObjectProperty)
    double ProjectileSpeedMult() const { return Read<double>(uintptr_t(this) + 0x1498); } // 0x1498 (Size: 0x8, Type: DoubleProperty)
    double PickupSpeedMult() const { return Read<double>(uintptr_t(this) + 0x14a0); } // 0x14a0 (Size: 0x8, Type: DoubleProperty)
    bool bSetSilentDie() const { return Read<bool>(uintptr_t(this) + 0x14a8); } // 0x14a8 (Size: 0x1, Type: BoolProperty)
    bool bSetSpawnedWaterBody() const { return Read<bool>(uintptr_t(this) + 0x14a9); } // 0x14a9 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1260, Value); } // 0x1260 (Size: 0x8, Type: StructProperty)
    void SET_overlapCylinder(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x1268, Value); } // 0x1268 (Size: 0x8, Type: ObjectProperty)
    void SET_WilliePete_Ambient_Loop(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x1270, Value); } // 0x1270 (Size: 0x8, Type: ObjectProperty)
    void SET_Geyser(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x1278, Value); } // 0x1278 (Size: 0x8, Type: ObjectProperty)
    void SET_S_Whirlpool_01(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x1280, Value); } // 0x1280 (Size: 0x8, Type: ObjectProperty)
    void SET_P_WilliePete_SurfaceVerticalSplash(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x1288, Value); } // 0x1288 (Size: 0x8, Type: ObjectProperty)
    void SET_OverlappedFortProjectileMovementComponent(const UFortProjectileMovementComponent*& Value) { Write<UFortProjectileMovementComponent*>(uintptr_t(this) + 0x1290, Value); } // 0x1290 (Size: 0x8, Type: ObjectProperty)
    void SET_OverlappedStandardProjectileMovementComponent(const UProjectileMovementComponent*& Value) { Write<UProjectileMovementComponent*>(uintptr_t(this) + 0x1298, Value); } // 0x1298 (Size: 0x8, Type: ObjectProperty)
    void SET_TeleportingNonPawn(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x12a0, Value); } // 0x12a0 (Size: 0x8, Type: ObjectProperty)
    void SET_SphereOverlapResult(const FHitResult& Value) { Write<FHitResult>(uintptr_t(this) + 0x12a8, Value); } // 0x12a8 (Size: 0xf8, Type: StructProperty)
    void SET_ProjectileSpeedCeiling(const double& Value) { Write<double>(uintptr_t(this) + 0x13a0, Value); } // 0x13a0 (Size: 0x8, Type: DoubleProperty)
    void SET_ProjectileExitFVectorRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x13a8, Value); } // 0x13a8 (Size: 0x18, Type: StructProperty)
    void SET_WaterLevel(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x13c0, Value); } // 0x13c0 (Size: 0x4, Type: IntProperty)
    void SET_GC_Exit(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x13c4, Value); } // 0x13c4 (Size: 0x4, Type: StructProperty)
    void SET_GC_Enter(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x13c8, Value); } // 0x13c8 (Size: 0x4, Type: StructProperty)
    void SET_EnabledValue(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x13d0, Value); } // 0x13d0 (Size: 0x28, Type: StructProperty)
    void SET_LaunchHeightValue(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x13f8, Value); } // 0x13f8 (Size: 0x28, Type: StructProperty)
    void SET_LaunchPawn(const AFortPlayerPawnAthena*& Value) { Write<AFortPlayerPawnAthena*>(uintptr_t(this) + 0x1420, Value); } // 0x1420 (Size: 0x8, Type: ObjectProperty)
    void SET_LaunchGrantedEffectHandle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x1428, Value); } // 0x1428 (Size: 0x8, Type: StructProperty)
    void SET_T_Quest(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x1430, Value); } // 0x1430 (Size: 0x20, Type: StructProperty)
    void SET_SpawnedWaterBody(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1450, Value); } // 0x1450 (Size: 0x8, Type: ClassProperty)
    void SET_GC_ScreenFX(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x1458, Value); } // 0x1458 (Size: 0x4, Type: StructProperty)
    void SET_isOnTestMap(const bool& Value) { Write<bool>(uintptr_t(this) + 0x145c, Value); } // 0x145c (Size: 0x1, Type: BoolProperty)
    void SET_Launch_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x1460, Value); } // 0x1460 (Size: 0x8, Type: ObjectProperty)
    void SET_AdjustedLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1468, Value); } // 0x1468 (Size: 0x18, Type: StructProperty)
    void SET_skipAnimForLaunch(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1480, Value); } // 0x1480 (Size: 0x1, Type: BoolProperty)
    void SET_ExitingPawn(const AFortPlayerPawnAthena*& Value) { Write<AFortPlayerPawnAthena*>(uintptr_t(this) + 0x1488, Value); } // 0x1488 (Size: 0x8, Type: ObjectProperty)
    void SET_OverlappedMovementComponent(const UMovementComponent*& Value) { Write<UMovementComponent*>(uintptr_t(this) + 0x1490, Value); } // 0x1490 (Size: 0x8, Type: ObjectProperty)
    void SET_ProjectileSpeedMult(const double& Value) { Write<double>(uintptr_t(this) + 0x1498, Value); } // 0x1498 (Size: 0x8, Type: DoubleProperty)
    void SET_PickupSpeedMult(const double& Value) { Write<double>(uintptr_t(this) + 0x14a0, Value); } // 0x14a0 (Size: 0x8, Type: DoubleProperty)
    void SET_bSetSilentDie(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14a8, Value); } // 0x14a8 (Size: 0x1, Type: BoolProperty)
    void SET_bSetSpawnedWaterBody(const bool& Value) { Write<bool>(uintptr_t(this) + 0x14a9, Value); } // 0x14a9 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xb90
class UGA_Athena_HidingProp_JumpOut_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    FGameplayTagContainer GameplayCueAthenaHidingProp() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x20, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_GameplayCueAthenaHidingProp(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x20, Type: StructProperty)
};

// Size: 0xbb4
class ABGA_Athena_SCMachine_Pickup_C : public ABuildingGameplayActorSpawnChip
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xac0); } // 0xac0 (Size: 0x8, Type: StructProperty)
    UNiagaraComponent* NS_SCCard_ResIn() const { return Read<UNiagaraComponent*>(uintptr_t(this) + 0xac8); } // 0xac8 (Size: 0x8, Type: ObjectProperty)
    UCapsuleComponent* OverlapCollision() const { return Read<UCapsuleComponent*>(uintptr_t(this) + 0xad0); } // 0xad0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* ParentMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xad8); } // 0xad8 (Size: 0x8, Type: ObjectProperty)
    UFortLinkToActorComponent* FortLinkToActor() const { return Read<UFortLinkToActorComponent*>(uintptr_t(this) + 0xae0); } // 0xae0 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* SC_Machine_Memory_Card_Loop_Cue() const { return Read<UAudioComponent*>(uintptr_t(this) + 0xae8); } // 0xae8 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* SpawninEffect() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0xaf0); } // 0xaf0 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* BackgroundGlow() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xaf8); } // 0xaf8 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* Card() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xb00); } // 0xb00 (Size: 0x8, Type: ObjectProperty)
    int32_t UnHide() const { return Read<int32_t>(uintptr_t(this) + 0xb08); } // 0xb08 (Size: 0x4, Type: IntProperty)
    double DelayBeforeUnhide() const { return Read<double>(uintptr_t(this) + 0xb10); } // 0xb10 (Size: 0x8, Type: DoubleProperty)
    char OwnerTeam() const { return Read<char>(uintptr_t(this) + 0xb18); } // 0xb18 (Size: 0x1, Type: ByteProperty)
    FTimerHandle Timer_DestroyPickup() const { return Read<FTimerHandle>(uintptr_t(this) + 0xb20); } // 0xb20 (Size: 0x8, Type: StructProperty)
    FScalableFloat Row_PickupLife() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb28); } // 0xb28 (Size: 0x28, Type: StructProperty)
    FText InteractText() const { return Read<FText>(uintptr_t(this) + 0xb50); } // 0xb50 (Size: 0x10, Type: TextProperty)
    UParticleSystem* SpawnOutParticle() const { return Read<UParticleSystem*>(uintptr_t(this) + 0xb60); } // 0xb60 (Size: 0x8, Type: ObjectProperty)
    USoundBase* PickupSound() const { return Read<USoundBase*>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: ObjectProperty)
    bool SpawnSoundPlayed() const { return Read<bool>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x1, Type: BoolProperty)
    USoundBase* SpawnInSound() const { return Read<USoundBase*>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    bool IsPendingKill() const { return Read<bool>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x1, Type: BoolProperty)
    bool HideAndKill() const { return Read<bool>(uintptr_t(this) + 0xb81); } // 0xb81 (Size: 0x1, Type: BoolProperty)
    FScalableFloat Row_PickUpInteractTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x28, Type: StructProperty)
    bool IsDelayingDeath() const { return Read<bool>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x1, Type: BoolProperty)
    bool OwnerDiedInVortex() const { return Read<bool>(uintptr_t(this) + 0xbb1); } // 0xbb1 (Size: 0x1, Type: BoolProperty)
    bool CollectedPickup() const { return Read<bool>(uintptr_t(this) + 0xbb2); } // 0xbb2 (Size: 0x1, Type: BoolProperty)
    bool Was_Card_Purchased() const { return Read<bool>(uintptr_t(this) + 0xbb3); } // 0xbb3 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xac0, Value); } // 0xac0 (Size: 0x8, Type: StructProperty)
    void SET_NS_SCCard_ResIn(const UNiagaraComponent*& Value) { Write<UNiagaraComponent*>(uintptr_t(this) + 0xac8, Value); } // 0xac8 (Size: 0x8, Type: ObjectProperty)
    void SET_OverlapCollision(const UCapsuleComponent*& Value) { Write<UCapsuleComponent*>(uintptr_t(this) + 0xad0, Value); } // 0xad0 (Size: 0x8, Type: ObjectProperty)
    void SET_ParentMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xad8, Value); } // 0xad8 (Size: 0x8, Type: ObjectProperty)
    void SET_FortLinkToActor(const UFortLinkToActorComponent*& Value) { Write<UFortLinkToActorComponent*>(uintptr_t(this) + 0xae0, Value); } // 0xae0 (Size: 0x8, Type: ObjectProperty)
    void SET_SC_Machine_Memory_Card_Loop_Cue(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0xae8, Value); } // 0xae8 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawninEffect(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0xaf0, Value); } // 0xaf0 (Size: 0x8, Type: ObjectProperty)
    void SET_BackgroundGlow(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xaf8, Value); } // 0xaf8 (Size: 0x8, Type: ObjectProperty)
    void SET_Card(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xb00, Value); } // 0xb00 (Size: 0x8, Type: ObjectProperty)
    void SET_UnHide(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb08, Value); } // 0xb08 (Size: 0x4, Type: IntProperty)
    void SET_DelayBeforeUnhide(const double& Value) { Write<double>(uintptr_t(this) + 0xb10, Value); } // 0xb10 (Size: 0x8, Type: DoubleProperty)
    void SET_OwnerTeam(const char& Value) { Write<char>(uintptr_t(this) + 0xb18, Value); } // 0xb18 (Size: 0x1, Type: ByteProperty)
    void SET_Timer_DestroyPickup(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xb20, Value); } // 0xb20 (Size: 0x8, Type: StructProperty)
    void SET_Row_PickupLife(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb28, Value); } // 0xb28 (Size: 0x28, Type: StructProperty)
    void SET_InteractText(const FText& Value) { Write<FText>(uintptr_t(this) + 0xb50, Value); } // 0xb50 (Size: 0x10, Type: TextProperty)
    void SET_SpawnOutParticle(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0xb60, Value); } // 0xb60 (Size: 0x8, Type: ObjectProperty)
    void SET_PickupSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawnSoundPlayed(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x1, Type: BoolProperty)
    void SET_SpawnInSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    void SET_IsPendingKill(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x1, Type: BoolProperty)
    void SET_HideAndKill(const bool& Value) { Write<bool>(uintptr_t(this) + 0xb81, Value); } // 0xb81 (Size: 0x1, Type: BoolProperty)
    void SET_Row_PickUpInteractTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x28, Type: StructProperty)
    void SET_IsDelayingDeath(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x1, Type: BoolProperty)
    void SET_OwnerDiedInVortex(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbb1, Value); } // 0xbb1 (Size: 0x1, Type: BoolProperty)
    void SET_CollectedPickup(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbb2, Value); } // 0xbb2 (Size: 0x1, Type: BoolProperty)
    void SET_Was_Card_Purchased(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbb3, Value); } // 0xbb3 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc11
class UGA_Athena_SCMachine_Passive_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawnAthena* PlayerPawn() const { return Read<AFortPlayerPawnAthena*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    FVector SpawnZOffset() const { return Read<FVector>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x18, Type: StructProperty)
    FGameplayTag BlockChipSpawnTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x4, Type: StructProperty)
    FScalableFloat DropRebootCards() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb98); } // 0xb98 (Size: 0x28, Type: StructProperty)
    FScalableFloat ShouldAutoCollectCards_OceanKill() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x28, Type: StructProperty)
    FScalableFloat ShouldAutoCollectCards_Override() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbe8); } // 0xbe8 (Size: 0x28, Type: StructProperty)
    bool AutoCollectCardsOverride() const { return Read<bool>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_PlayerPawn(const AFortPlayerPawnAthena*& Value) { Write<AFortPlayerPawnAthena*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_SpawnZOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x18, Type: StructProperty)
    void SET_BlockChipSpawnTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x4, Type: StructProperty)
    void SET_DropRebootCards(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb98, Value); } // 0xb98 (Size: 0x28, Type: StructProperty)
    void SET_ShouldAutoCollectCards_OceanKill(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x28, Type: StructProperty)
    void SET_ShouldAutoCollectCards_Override(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbe8, Value); } // 0xbe8 (Size: 0x28, Type: StructProperty)
    void SET_AutoCollectCardsOverride(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xc68
class UGA_Rift_Athena_Skydive_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    UAnimMontage* FallingAnimation() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    double Hangtimee() const { return Read<double>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: DoubleProperty)
    USkeletalMeshComponent* VehicleSkelMesh() const { return Read<USkeletalMeshComponent*>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat HangTime() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x28, Type: StructProperty)
    FGameplayTag EventTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x4, Type: StructProperty)
    FScalableFloat KickFromVehicle_() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x28, Type: StructProperty)
    USoundBase* LocalPlayerSound() const { return Read<USoundBase*>(uintptr_t(this) + 0xbe0); } // 0xbe0 (Size: 0x8, Type: ObjectProperty)
    UClass* GameplayCueGE() const { return Read<UClass*>(uintptr_t(this) + 0xbe8); } // 0xbe8 (Size: 0x8, Type: ClassProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xbf0); } // 0xbf0 (Size: 0x8, Type: ObjectProperty)
    bool bHolstered() const { return Read<bool>(uintptr_t(this) + 0xbf8); } // 0xbf8 (Size: 0x1, Type: BoolProperty)
    FName RiftSkydiveHolster() const { return Read<FName>(uintptr_t(this) + 0xbfc); } // 0xbfc (Size: 0x4, Type: NameProperty)
    FVector ImpulseStrength() const { return Read<FVector>(uintptr_t(this) + 0xc00); } // 0xc00 (Size: 0x18, Type: StructProperty)
    bool bNeedsInputEnable() const { return Read<bool>(uintptr_t(this) + 0xc18); } // 0xc18 (Size: 0x1, Type: BoolProperty)
    FTimerHandle SafetyTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0xc20); } // 0xc20 (Size: 0x8, Type: StructProperty)
    FVector NewVar_0() const { return Read<FVector>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x18, Type: StructProperty)
    FGameplayTagContainer UnblockTagsIfPassenger() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xc40); } // 0xc40 (Size: 0x20, Type: StructProperty)
    UClass* GameplayCueGE_Override() const { return Read<UClass*>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x8, Type: ClassProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_FallingAnimation(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_Hangtimee(const double& Value) { Write<double>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: DoubleProperty)
    void SET_VehicleSkelMesh(const USkeletalMeshComponent*& Value) { Write<USkeletalMeshComponent*>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    void SET_HangTime(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x28, Type: StructProperty)
    void SET_EventTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x4, Type: StructProperty)
    void SET_KickFromVehicle_(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x28, Type: StructProperty)
    void SET_LocalPlayerSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0xbe0, Value); } // 0xbe0 (Size: 0x8, Type: ObjectProperty)
    void SET_GameplayCueGE(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xbe8, Value); } // 0xbe8 (Size: 0x8, Type: ClassProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xbf0, Value); } // 0xbf0 (Size: 0x8, Type: ObjectProperty)
    void SET_bHolstered(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbf8, Value); } // 0xbf8 (Size: 0x1, Type: BoolProperty)
    void SET_RiftSkydiveHolster(const FName& Value) { Write<FName>(uintptr_t(this) + 0xbfc, Value); } // 0xbfc (Size: 0x4, Type: NameProperty)
    void SET_ImpulseStrength(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc00, Value); } // 0xc00 (Size: 0x18, Type: StructProperty)
    void SET_bNeedsInputEnable(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc18, Value); } // 0xc18 (Size: 0x1, Type: BoolProperty)
    void SET_SafetyTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xc20, Value); } // 0xc20 (Size: 0x8, Type: StructProperty)
    void SET_NewVar_0(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x18, Type: StructProperty)
    void SET_UnblockTagsIfPassenger(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xc40, Value); } // 0xc40 (Size: 0x20, Type: StructProperty)
    void SET_GameplayCueGE_Override(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x8, Type: ClassProperty)
};

// Size: 0x430
class AAsteria_Waterbody_Ocean_Parent_C : public AFortWaterBodyBP_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x8, Type: StructProperty)
    UFortSplineWaterAudioComponent* FortSplineWaterAudio() const { return Read<UFortSplineWaterAudioComponent*>(uintptr_t(this) + 0x428); } // 0x428 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x8, Type: StructProperty)
    void SET_FortSplineWaterAudio(const UFortSplineWaterAudioComponent*& Value) { Write<UFortSplineWaterAudioComponent*>(uintptr_t(this) + 0x428, Value); } // 0x428 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc00
class UGA_Athena_HidingProp_Teleport_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    AB_HidingProp_C* HidingProp() const { return Read<AB_HidingProp_C*>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    AB_HidingProp_C* TargetTeleporter() const { return Read<AB_HidingProp_C*>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer T_HudElementToHide() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x20, Type: StructProperty)
    FGameplayTag TargetPropTeleportingCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x4, Type: StructProperty)
    FTimerHandle WobbleHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x8, Type: StructProperty)
    FGameplayTag WobbleCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x4, Type: StructProperty)
    double ServerWorldTime() const { return Read<double>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag EnterCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbd0); } // 0xbd0 (Size: 0x4, Type: StructProperty)
    FGameplayTag HidingInPropTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbd4); } // 0xbd4 (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer ChangeEquipmentTag() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xbd8); } // 0xbd8 (Size: 0x20, Type: StructProperty)
    FActiveGameplayEffectHandle TeleportingGEOnPlayer() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xbf8); } // 0xbf8 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_HidingProp(const AB_HidingProp_C*& Value) { Write<AB_HidingProp_C*>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetTeleporter(const AB_HidingProp_C*& Value) { Write<AB_HidingProp_C*>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x8, Type: ObjectProperty)
    void SET_T_HudElementToHide(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x20, Type: StructProperty)
    void SET_TargetPropTeleportingCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x4, Type: StructProperty)
    void SET_WobbleHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x8, Type: StructProperty)
    void SET_WobbleCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x4, Type: StructProperty)
    void SET_ServerWorldTime(const double& Value) { Write<double>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x8, Type: DoubleProperty)
    void SET_EnterCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbd0, Value); } // 0xbd0 (Size: 0x4, Type: StructProperty)
    void SET_HidingInPropTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbd4, Value); } // 0xbd4 (Size: 0x4, Type: StructProperty)
    void SET_ChangeEquipmentTag(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xbd8, Value); } // 0xbd8 (Size: 0x20, Type: StructProperty)
    void SET_TeleportingGEOnPlayer(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xbf8, Value); } // 0xbf8 (Size: 0x8, Type: StructProperty)
};

// Size: 0x1259
class AB_HidingProp_C : public AFortHidingProp
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc58); } // 0xc58 (Size: 0x8, Type: StructProperty)
    USoundLibraryComponent* SoundLibrary() const { return Read<USoundLibraryComponent*>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* ProjectileLocation_ForwardVector() const { return Read<USceneComponent*>(uintptr_t(this) + 0xc68); } // 0xc68 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* LandedOnCollisionMesh() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0xc70); } // 0xc70 (Size: 0x8, Type: ObjectProperty)
    USphereComponent* Sphere() const { return Read<USphereComponent*>(uintptr_t(this) + 0xc78); } // 0xc78 (Size: 0x8, Type: ObjectProperty)
    USceneComponent* HideLocation_ForwardVector() const { return Read<USceneComponent*>(uintptr_t(this) + 0xc80); } // 0xc80 (Size: 0x8, Type: ObjectProperty)
    float Loot_MovementTimeline_Forward_0FC694AE4A45D691CB6BD5A8CD00E521() const { return Read<float>(uintptr_t(this) + 0xc88); } // 0xc88 (Size: 0x4, Type: FloatProperty)
    float Loot_MovementTimeline_Z_0FC694AE4A45D691CB6BD5A8CD00E521() const { return Read<float>(uintptr_t(this) + 0xc8c); } // 0xc8c (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<ETimelineDirection> Loot_MovementTimeline__Direction_0FC694AE4A45D691CB6BD5A8CD00E521() const { return Read<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xc90); } // 0xc90 (Size: 0x1, Type: ByteProperty)
    UTimelineComponent* Loot_MovementTimeline() const { return Read<UTimelineComponent*>(uintptr_t(this) + 0xc98); } // 0xc98 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat Enabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xca0); } // 0xca0 (Size: 0x28, Type: StructProperty)
    FScalableFloat HidingEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xcc8); } // 0xcc8 (Size: 0x28, Type: StructProperty)
    FScalableFloat PlayerLimit() const { return Read<FScalableFloat>(uintptr_t(this) + 0xcf0); } // 0xcf0 (Size: 0x28, Type: StructProperty)
    FScalableFloat TeleportEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd18); } // 0xd18 (Size: 0x28, Type: StructProperty)
    FScalableFloat CanTeleport() const { return Read<FScalableFloat>(uintptr_t(this) + 0xd40); } // 0xd40 (Size: 0x28, Type: StructProperty)
    TArray<AFortPawn*> HidingPlayers() const { return Read<TArray<AFortPawn*>>(uintptr_t(this) + 0xd68); } // 0xd68 (Size: 0x10, Type: ArrayProperty)
    FGameplayTag EnterGameplayCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd78); } // 0xd78 (Size: 0x4, Type: StructProperty)
    FGameplayTag ExitGameplayCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd7c); } // 0xd7c (Size: 0x4, Type: StructProperty)
    FGameplayTag LandedOnGameplayCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd80); } // 0xd80 (Size: 0x4, Type: StructProperty)
    UMaterialInstanceDynamic* Mid() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xd88); } // 0xd88 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag RustleGameplayCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd90); } // 0xd90 (Size: 0x4, Type: StructProperty)
    FGameplayTag ExitGameplayCue_Player() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd94); } // 0xd94 (Size: 0x4, Type: StructProperty)
    FGameplayTag WhileEnteringGameplayCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xd98); } // 0xd98 (Size: 0x4, Type: StructProperty)
    double ObstructionTraceLength() const { return Read<double>(uintptr_t(this) + 0xda0); } // 0xda0 (Size: 0x8, Type: DoubleProperty)
    TArray<TEnumAsByte<EObjectTypeQuery>> DestroyObjectTypes() const { return Read<TArray<TEnumAsByte<EObjectTypeQuery>>>(uintptr_t(this) + 0xda8); } // 0xda8 (Size: 0x10, Type: ArrayProperty)
    TArray<AFortPawn*> Array() const { return Read<TArray<AFortPawn*>>(uintptr_t(this) + 0xdb8); } // 0xdb8 (Size: 0x10, Type: ArrayProperty)
    int32_t int() const { return Read<int32_t>(uintptr_t(this) + 0xdc8); } // 0xdc8 (Size: 0x4, Type: IntProperty)
    FVector DeimosPropSpawnerOffset() const { return Read<FVector>(uintptr_t(this) + 0xdd0); } // 0xdd0 (Size: 0x18, Type: StructProperty)
    bool FixedEntranceDirection() const { return Read<bool>(uintptr_t(this) + 0xde8); } // 0xde8 (Size: 0x1, Type: BoolProperty)
    double MaxInteractAngle() const { return Read<double>(uintptr_t(this) + 0xdf0); } // 0xdf0 (Size: 0x8, Type: DoubleProperty)
    FVector WobbleLocationOffset() const { return Read<FVector>(uintptr_t(this) + 0xdf8); } // 0xdf8 (Size: 0x18, Type: StructProperty)
    double InteractBelowPropDistance() const { return Read<double>(uintptr_t(this) + 0xe10); } // 0xe10 (Size: 0x8, Type: DoubleProperty)
    TMap<double, AFortPawn*> HiddenPlayersAndEnterTimes() const { return Read<TMap<double, AFortPawn*>>(uintptr_t(this) + 0xe18); } // 0xe18 (Size: 0x50, Type: MapProperty)
    AFortPawn* LastPawnToInteract() const { return Read<AFortPawn*>(uintptr_t(this) + 0xe68); } // 0xe68 (Size: 0x8, Type: ObjectProperty)
    AB_HidingProp_C* TargetTeleporter() const { return Read<AB_HidingProp_C*>(uintptr_t(this) + 0xe70); } // 0xe70 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag TeleporterEnterGameplayCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xe78); } // 0xe78 (Size: 0x4, Type: StructProperty)
    FGameplayTag TeleporterExitGameplayCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xe7c); } // 0xe7c (Size: 0x4, Type: StructProperty)
    FGameplayTag LoopingTeleportingCue() const { return Read<FGameplayTag>(uintptr_t(this) + 0xe80); } // 0xe80 (Size: 0x4, Type: StructProperty)
    FGameplayTag GC_Wobble() const { return Read<FGameplayTag>(uintptr_t(this) + 0xe84); } // 0xe84 (Size: 0x4, Type: StructProperty)
    FTimerHandle WobbleTimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xe88); } // 0xe88 (Size: 0x8, Type: StructProperty)
    TArray<FGameplayTag> BlockEntranceTags() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0xe90); } // 0xe90 (Size: 0x10, Type: ArrayProperty)
    TArray<FGameplayTag> BlockExitTags() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0xea0); } // 0xea0 (Size: 0x10, Type: ArrayProperty)
    UAnimMontage* EnterAnimMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xeb0); } // 0xeb0 (Size: 0x8, Type: ObjectProperty)
    UAnimMontage* ExitAnimMontage() const { return Read<UAnimMontage*>(uintptr_t(this) + 0xeb8); } // 0xeb8 (Size: 0x8, Type: ObjectProperty)
    AFortPawn* LastPawnToHide() const { return Read<AFortPawn*>(uintptr_t(this) + 0xec0); } // 0xec0 (Size: 0x8, Type: ObjectProperty)
    FGameplayTag TeleportingStateGC() const { return Read<FGameplayTag>(uintptr_t(this) + 0xec8); } // 0xec8 (Size: 0x4, Type: StructProperty)
    bool RandomWobbleNormal() const { return Read<bool>(uintptr_t(this) + 0xecc); } // 0xecc (Size: 0x1, Type: BoolProperty)
    bool SingleOccupant() const { return Read<bool>(uintptr_t(this) + 0xecd); } // 0xecd (Size: 0x1, Type: BoolProperty)
    bool Teleporting() const { return Read<bool>(uintptr_t(this) + 0xece); } // 0xece (Size: 0x1, Type: BoolProperty)
    bool JumpOut() const { return Read<bool>(uintptr_t(this) + 0xecf); } // 0xecf (Size: 0x1, Type: BoolProperty)
    UClass* GE_OnExitingPropNoJump_BlockActions() const { return Read<UClass*>(uintptr_t(this) + 0xed0); } // 0xed0 (Size: 0x8, Type: ClassProperty)
    bool DestroyInNonSpyLTM() const { return Read<bool>(uintptr_t(this) + 0xed8); } // 0xed8 (Size: 0x1, Type: BoolProperty)
    bool ActiveInSpyLTM() const { return Read<bool>(uintptr_t(this) + 0xed9); } // 0xed9 (Size: 0x1, Type: BoolProperty)
    TArray<FGameplayTag> ForceAllowInteractTags() const { return Read<TArray<FGameplayTag>>(uintptr_t(this) + 0xee0); } // 0xee0 (Size: 0x10, Type: ArrayProperty)
    FGameplayTag IsTeleporter() const { return Read<FGameplayTag>(uintptr_t(this) + 0xef0); } // 0xef0 (Size: 0x4, Type: StructProperty)
    FGameplayTag ContainsPlayerRepNof() const { return Read<FGameplayTag>(uintptr_t(this) + 0xef4); } // 0xef4 (Size: 0x4, Type: StructProperty)
    FVector ObstructionTraceExtents() const { return Read<FVector>(uintptr_t(this) + 0xef8); } // 0xef8 (Size: 0x18, Type: StructProperty)
    FVector ObstructionTraceStartOffSet() const { return Read<FVector>(uintptr_t(this) + 0xf10); } // 0xf10 (Size: 0x18, Type: StructProperty)
    double ExitLaunchVelocity() const { return Read<double>(uintptr_t(this) + 0xf28); } // 0xf28 (Size: 0x8, Type: DoubleProperty)
    FVector AdditionalLaunchVelocity() const { return Read<FVector>(uintptr_t(this) + 0xf30); } // 0xf30 (Size: 0x18, Type: StructProperty)
    FVector Obstruction_Trace_End() const { return Read<FVector>(uintptr_t(this) + 0xf48); } // 0xf48 (Size: 0x18, Type: StructProperty)
    FVector FixedEntraceObstructionTraceEndOffset() const { return Read<FVector>(uintptr_t(this) + 0xf60); } // 0xf60 (Size: 0x18, Type: StructProperty)
    bool isActiveTeleportExit() const { return Read<bool>(uintptr_t(this) + 0xf78); } // 0xf78 (Size: 0x1, Type: BoolProperty)
    UClass* GE_TeleportAbilityGranted() const { return Read<UClass*>(uintptr_t(this) + 0xf80); } // 0xf80 (Size: 0x8, Type: ClassProperty)
    bool DisableWhenSubmergedInWater() const { return Read<bool>(uintptr_t(this) + 0xf88); } // 0xf88 (Size: 0x1, Type: BoolProperty)
    FGameplayTagContainer DisableWhenSubmergedExceptionTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xf90); } // 0xf90 (Size: 0x20, Type: StructProperty)
    TArray<AFortPawn*> NonCosmeticPawns() const { return Read<TArray<AFortPawn*>>(uintptr_t(this) + 0xfb0); } // 0xfb0 (Size: 0x10, Type: ArrayProperty)
    UClass* CameraModifier() const { return Read<UClass*>(uintptr_t(this) + 0xfc0); } // 0xfc0 (Size: 0x8, Type: ClassProperty)
    FVector NewVar_0() const { return Read<FVector>(uintptr_t(this) + 0xfc8); } // 0xfc8 (Size: 0x18, Type: StructProperty)
    AActor* Pawn() const { return Read<AActor*>(uintptr_t(this) + 0xfe0); } // 0xfe0 (Size: 0x8, Type: ObjectProperty)
    FVector Loot_CachedActorForward() const { return Read<FVector>(uintptr_t(this) + 0xfe8); } // 0xfe8 (Size: 0x18, Type: StructProperty)
    TArray<FVector> Loot_VectorOffsets() const { return Read<TArray<FVector>>(uintptr_t(this) + 0x1000); } // 0x1000 (Size: 0x10, Type: ArrayProperty)
    bool SpawnedLoot() const { return Read<bool>(uintptr_t(this) + 0x1010); } // 0x1010 (Size: 0x1, Type: BoolProperty)
    double Loot_MoveForwardDistance() const { return Read<double>(uintptr_t(this) + 0x1018); } // 0x1018 (Size: 0x8, Type: DoubleProperty)
    double Loot_MoveUpDistance() const { return Read<double>(uintptr_t(this) + 0x1020); } // 0x1020 (Size: 0x8, Type: DoubleProperty)
    double Loot_SpawnRadius() const { return Read<double>(uintptr_t(this) + 0x1028); } // 0x1028 (Size: 0x8, Type: DoubleProperty)
    FVector Loot_SpawnOffset() const { return Read<FVector>(uintptr_t(this) + 0x1030); } // 0x1030 (Size: 0x18, Type: StructProperty)
    bool ShouldSpawnLoot() const { return Read<bool>(uintptr_t(this) + 0x1048); } // 0x1048 (Size: 0x1, Type: BoolProperty)
    FString Loot_Tier_Group() const { return Read<FString>(uintptr_t(this) + 0x1050); } // 0x1050 (Size: 0x10, Type: StrProperty)
    bool SetEntranceRotation() const { return Read<bool>(uintptr_t(this) + 0x1060); } // 0x1060 (Size: 0x1, Type: BoolProperty)
    UClass* PropSpecificEffectToApplyToHiders() const { return Read<UClass*>(uintptr_t(this) + 0x1068); } // 0x1068 (Size: 0x8, Type: ClassProperty)
    FScalableFloat RustlesPerWobble() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1070); } // 0x1070 (Size: 0x28, Type: StructProperty)
    FScalableFloat RustleWobbleRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1098); } // 0x1098 (Size: 0x28, Type: StructProperty)
    FScalableFloat EnterWobbleRadius() const { return Read<FScalableFloat>(uintptr_t(this) + 0x10c0); } // 0x10c0 (Size: 0x28, Type: StructProperty)
    double NonJumpExitDistance() const { return Read<double>(uintptr_t(this) + 0x10e8); } // 0x10e8 (Size: 0x8, Type: DoubleProperty)
    UClass* Camera_Mode() const { return Read<UClass*>(uintptr_t(this) + 0x10f0); } // 0x10f0 (Size: 0x8, Type: ClassProperty)
    bool MoveToActorOnEnter() const { return Read<bool>(uintptr_t(this) + 0x10f8); } // 0x10f8 (Size: 0x1, Type: BoolProperty)
    bool IgnorePhysicsBodyCollisionOnEnter() const { return Read<bool>(uintptr_t(this) + 0x10f9); } // 0x10f9 (Size: 0x1, Type: BoolProperty)
    bool bCanRustleAndWobble() const { return Read<bool>(uintptr_t(this) + 0x10fa); } // 0x10fa (Size: 0x1, Type: BoolProperty)
    bool SkipRestoreCameraViewTargetOnStopHiding() const { return Read<bool>(uintptr_t(this) + 0x10fb); } // 0x10fb (Size: 0x1, Type: BoolProperty)
    bool SkipRootMotionMovementOnStopHiding() const { return Read<bool>(uintptr_t(this) + 0x10fc); } // 0x10fc (Size: 0x1, Type: BoolProperty)
    FRotator AddedSetEntranceRotation() const { return Read<FRotator>(uintptr_t(this) + 0x1100); } // 0x1100 (Size: 0x18, Type: StructProperty)
    double MoveToActorDelayOnEnter() const { return Read<double>(uintptr_t(this) + 0x1118); } // 0x1118 (Size: 0x8, Type: DoubleProperty)
    double MoveToActorDurationOverride() const { return Read<double>(uintptr_t(this) + 0x1120); } // 0x1120 (Size: 0x8, Type: DoubleProperty)
    FMarkedActorDisplayInfo MarkerDisplay() const { return Read<FMarkedActorDisplayInfo>(uintptr_t(this) + 0x1128); } // 0x1128 (Size: 0xb0, Type: StructProperty)
    FVector MarkerPositionOffset() const { return Read<FVector>(uintptr_t(this) + 0x11d8); } // 0x11d8 (Size: 0x18, Type: StructProperty)
    bool ObstructionTraceByObject() const { return Read<bool>(uintptr_t(this) + 0x11f0); } // 0x11f0 (Size: 0x1, Type: BoolProperty)
    FScalableFloat Hiding_Enable_From_Landing() const { return Read<FScalableFloat>(uintptr_t(this) + 0x11f8); } // 0x11f8 (Size: 0x28, Type: StructProperty)
    FScalableFloat HidingEnabled_0() const { return Read<FScalableFloat>(uintptr_t(this) + 0x1220); } // 0x1220 (Size: 0x28, Type: StructProperty)
    TArray<TSoftObjectPtr<AB_HidingProp_C*>> TeleportersTargetingMe() const { return Read<TArray<TSoftObjectPtr<AB_HidingProp_C*>>>(uintptr_t(this) + 0x1248); } // 0x1248 (Size: 0x10, Type: ArrayProperty)
    bool BypassJumpOut() const { return Read<bool>(uintptr_t(this) + 0x1258); } // 0x1258 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc58, Value); } // 0xc58 (Size: 0x8, Type: StructProperty)
    void SET_SoundLibrary(const USoundLibraryComponent*& Value) { Write<USoundLibraryComponent*>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x8, Type: ObjectProperty)
    void SET_ProjectileLocation_ForwardVector(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0xc68, Value); } // 0xc68 (Size: 0x8, Type: ObjectProperty)
    void SET_LandedOnCollisionMesh(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0xc70, Value); } // 0xc70 (Size: 0x8, Type: ObjectProperty)
    void SET_Sphere(const USphereComponent*& Value) { Write<USphereComponent*>(uintptr_t(this) + 0xc78, Value); } // 0xc78 (Size: 0x8, Type: ObjectProperty)
    void SET_HideLocation_ForwardVector(const USceneComponent*& Value) { Write<USceneComponent*>(uintptr_t(this) + 0xc80, Value); } // 0xc80 (Size: 0x8, Type: ObjectProperty)
    void SET_Loot_MovementTimeline_Forward_0FC694AE4A45D691CB6BD5A8CD00E521(const float& Value) { Write<float>(uintptr_t(this) + 0xc88, Value); } // 0xc88 (Size: 0x4, Type: FloatProperty)
    void SET_Loot_MovementTimeline_Z_0FC694AE4A45D691CB6BD5A8CD00E521(const float& Value) { Write<float>(uintptr_t(this) + 0xc8c, Value); } // 0xc8c (Size: 0x4, Type: FloatProperty)
    void SET_Loot_MovementTimeline__Direction_0FC694AE4A45D691CB6BD5A8CD00E521(const TEnumAsByte<ETimelineDirection>& Value) { Write<TEnumAsByte<ETimelineDirection>>(uintptr_t(this) + 0xc90, Value); } // 0xc90 (Size: 0x1, Type: ByteProperty)
    void SET_Loot_MovementTimeline(const UTimelineComponent*& Value) { Write<UTimelineComponent*>(uintptr_t(this) + 0xc98, Value); } // 0xc98 (Size: 0x8, Type: ObjectProperty)
    void SET_Enabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xca0, Value); } // 0xca0 (Size: 0x28, Type: StructProperty)
    void SET_HidingEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xcc8, Value); } // 0xcc8 (Size: 0x28, Type: StructProperty)
    void SET_PlayerLimit(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xcf0, Value); } // 0xcf0 (Size: 0x28, Type: StructProperty)
    void SET_TeleportEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd18, Value); } // 0xd18 (Size: 0x28, Type: StructProperty)
    void SET_CanTeleport(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xd40, Value); } // 0xd40 (Size: 0x28, Type: StructProperty)
    void SET_HidingPlayers(const TArray<AFortPawn*>& Value) { Write<TArray<AFortPawn*>>(uintptr_t(this) + 0xd68, Value); } // 0xd68 (Size: 0x10, Type: ArrayProperty)
    void SET_EnterGameplayCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd78, Value); } // 0xd78 (Size: 0x4, Type: StructProperty)
    void SET_ExitGameplayCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd7c, Value); } // 0xd7c (Size: 0x4, Type: StructProperty)
    void SET_LandedOnGameplayCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd80, Value); } // 0xd80 (Size: 0x4, Type: StructProperty)
    void SET_Mid(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0xd88, Value); } // 0xd88 (Size: 0x8, Type: ObjectProperty)
    void SET_RustleGameplayCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd90, Value); } // 0xd90 (Size: 0x4, Type: StructProperty)
    void SET_ExitGameplayCue_Player(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd94, Value); } // 0xd94 (Size: 0x4, Type: StructProperty)
    void SET_WhileEnteringGameplayCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xd98, Value); } // 0xd98 (Size: 0x4, Type: StructProperty)
    void SET_ObstructionTraceLength(const double& Value) { Write<double>(uintptr_t(this) + 0xda0, Value); } // 0xda0 (Size: 0x8, Type: DoubleProperty)
    void SET_DestroyObjectTypes(const TArray<TEnumAsByte<EObjectTypeQuery>>& Value) { Write<TArray<TEnumAsByte<EObjectTypeQuery>>>(uintptr_t(this) + 0xda8, Value); } // 0xda8 (Size: 0x10, Type: ArrayProperty)
    void SET_Array(const TArray<AFortPawn*>& Value) { Write<TArray<AFortPawn*>>(uintptr_t(this) + 0xdb8, Value); } // 0xdb8 (Size: 0x10, Type: ArrayProperty)
    void SET_int(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xdc8, Value); } // 0xdc8 (Size: 0x4, Type: IntProperty)
    void SET_DeimosPropSpawnerOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xdd0, Value); } // 0xdd0 (Size: 0x18, Type: StructProperty)
    void SET_FixedEntranceDirection(const bool& Value) { Write<bool>(uintptr_t(this) + 0xde8, Value); } // 0xde8 (Size: 0x1, Type: BoolProperty)
    void SET_MaxInteractAngle(const double& Value) { Write<double>(uintptr_t(this) + 0xdf0, Value); } // 0xdf0 (Size: 0x8, Type: DoubleProperty)
    void SET_WobbleLocationOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xdf8, Value); } // 0xdf8 (Size: 0x18, Type: StructProperty)
    void SET_InteractBelowPropDistance(const double& Value) { Write<double>(uintptr_t(this) + 0xe10, Value); } // 0xe10 (Size: 0x8, Type: DoubleProperty)
    void SET_HiddenPlayersAndEnterTimes(const TMap<double, AFortPawn*>& Value) { Write<TMap<double, AFortPawn*>>(uintptr_t(this) + 0xe18, Value); } // 0xe18 (Size: 0x50, Type: MapProperty)
    void SET_LastPawnToInteract(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0xe68, Value); } // 0xe68 (Size: 0x8, Type: ObjectProperty)
    void SET_TargetTeleporter(const AB_HidingProp_C*& Value) { Write<AB_HidingProp_C*>(uintptr_t(this) + 0xe70, Value); } // 0xe70 (Size: 0x8, Type: ObjectProperty)
    void SET_TeleporterEnterGameplayCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xe78, Value); } // 0xe78 (Size: 0x4, Type: StructProperty)
    void SET_TeleporterExitGameplayCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xe7c, Value); } // 0xe7c (Size: 0x4, Type: StructProperty)
    void SET_LoopingTeleportingCue(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xe80, Value); } // 0xe80 (Size: 0x4, Type: StructProperty)
    void SET_GC_Wobble(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xe84, Value); } // 0xe84 (Size: 0x4, Type: StructProperty)
    void SET_WobbleTimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xe88, Value); } // 0xe88 (Size: 0x8, Type: StructProperty)
    void SET_BlockEntranceTags(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0xe90, Value); } // 0xe90 (Size: 0x10, Type: ArrayProperty)
    void SET_BlockExitTags(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0xea0, Value); } // 0xea0 (Size: 0x10, Type: ArrayProperty)
    void SET_EnterAnimMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xeb0, Value); } // 0xeb0 (Size: 0x8, Type: ObjectProperty)
    void SET_ExitAnimMontage(const UAnimMontage*& Value) { Write<UAnimMontage*>(uintptr_t(this) + 0xeb8, Value); } // 0xeb8 (Size: 0x8, Type: ObjectProperty)
    void SET_LastPawnToHide(const AFortPawn*& Value) { Write<AFortPawn*>(uintptr_t(this) + 0xec0, Value); } // 0xec0 (Size: 0x8, Type: ObjectProperty)
    void SET_TeleportingStateGC(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xec8, Value); } // 0xec8 (Size: 0x4, Type: StructProperty)
    void SET_RandomWobbleNormal(const bool& Value) { Write<bool>(uintptr_t(this) + 0xecc, Value); } // 0xecc (Size: 0x1, Type: BoolProperty)
    void SET_SingleOccupant(const bool& Value) { Write<bool>(uintptr_t(this) + 0xecd, Value); } // 0xecd (Size: 0x1, Type: BoolProperty)
    void SET_Teleporting(const bool& Value) { Write<bool>(uintptr_t(this) + 0xece, Value); } // 0xece (Size: 0x1, Type: BoolProperty)
    void SET_JumpOut(const bool& Value) { Write<bool>(uintptr_t(this) + 0xecf, Value); } // 0xecf (Size: 0x1, Type: BoolProperty)
    void SET_GE_OnExitingPropNoJump_BlockActions(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xed0, Value); } // 0xed0 (Size: 0x8, Type: ClassProperty)
    void SET_DestroyInNonSpyLTM(const bool& Value) { Write<bool>(uintptr_t(this) + 0xed8, Value); } // 0xed8 (Size: 0x1, Type: BoolProperty)
    void SET_ActiveInSpyLTM(const bool& Value) { Write<bool>(uintptr_t(this) + 0xed9, Value); } // 0xed9 (Size: 0x1, Type: BoolProperty)
    void SET_ForceAllowInteractTags(const TArray<FGameplayTag>& Value) { Write<TArray<FGameplayTag>>(uintptr_t(this) + 0xee0, Value); } // 0xee0 (Size: 0x10, Type: ArrayProperty)
    void SET_IsTeleporter(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xef0, Value); } // 0xef0 (Size: 0x4, Type: StructProperty)
    void SET_ContainsPlayerRepNof(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xef4, Value); } // 0xef4 (Size: 0x4, Type: StructProperty)
    void SET_ObstructionTraceExtents(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xef8, Value); } // 0xef8 (Size: 0x18, Type: StructProperty)
    void SET_ObstructionTraceStartOffSet(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf10, Value); } // 0xf10 (Size: 0x18, Type: StructProperty)
    void SET_ExitLaunchVelocity(const double& Value) { Write<double>(uintptr_t(this) + 0xf28, Value); } // 0xf28 (Size: 0x8, Type: DoubleProperty)
    void SET_AdditionalLaunchVelocity(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf30, Value); } // 0xf30 (Size: 0x18, Type: StructProperty)
    void SET_Obstruction_Trace_End(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf48, Value); } // 0xf48 (Size: 0x18, Type: StructProperty)
    void SET_FixedEntraceObstructionTraceEndOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xf60, Value); } // 0xf60 (Size: 0x18, Type: StructProperty)
    void SET_isActiveTeleportExit(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf78, Value); } // 0xf78 (Size: 0x1, Type: BoolProperty)
    void SET_GE_TeleportAbilityGranted(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xf80, Value); } // 0xf80 (Size: 0x8, Type: ClassProperty)
    void SET_DisableWhenSubmergedInWater(const bool& Value) { Write<bool>(uintptr_t(this) + 0xf88, Value); } // 0xf88 (Size: 0x1, Type: BoolProperty)
    void SET_DisableWhenSubmergedExceptionTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xf90, Value); } // 0xf90 (Size: 0x20, Type: StructProperty)
    void SET_NonCosmeticPawns(const TArray<AFortPawn*>& Value) { Write<TArray<AFortPawn*>>(uintptr_t(this) + 0xfb0, Value); } // 0xfb0 (Size: 0x10, Type: ArrayProperty)
    void SET_CameraModifier(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xfc0, Value); } // 0xfc0 (Size: 0x8, Type: ClassProperty)
    void SET_NewVar_0(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xfc8, Value); } // 0xfc8 (Size: 0x18, Type: StructProperty)
    void SET_Pawn(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xfe0, Value); } // 0xfe0 (Size: 0x8, Type: ObjectProperty)
    void SET_Loot_CachedActorForward(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xfe8, Value); } // 0xfe8 (Size: 0x18, Type: StructProperty)
    void SET_Loot_VectorOffsets(const TArray<FVector>& Value) { Write<TArray<FVector>>(uintptr_t(this) + 0x1000, Value); } // 0x1000 (Size: 0x10, Type: ArrayProperty)
    void SET_SpawnedLoot(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1010, Value); } // 0x1010 (Size: 0x1, Type: BoolProperty)
    void SET_Loot_MoveForwardDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x1018, Value); } // 0x1018 (Size: 0x8, Type: DoubleProperty)
    void SET_Loot_MoveUpDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x1020, Value); } // 0x1020 (Size: 0x8, Type: DoubleProperty)
    void SET_Loot_SpawnRadius(const double& Value) { Write<double>(uintptr_t(this) + 0x1028, Value); } // 0x1028 (Size: 0x8, Type: DoubleProperty)
    void SET_Loot_SpawnOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x1030, Value); } // 0x1030 (Size: 0x18, Type: StructProperty)
    void SET_ShouldSpawnLoot(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1048, Value); } // 0x1048 (Size: 0x1, Type: BoolProperty)
    void SET_Loot_Tier_Group(const FString& Value) { Write<FString>(uintptr_t(this) + 0x1050, Value); } // 0x1050 (Size: 0x10, Type: StrProperty)
    void SET_SetEntranceRotation(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1060, Value); } // 0x1060 (Size: 0x1, Type: BoolProperty)
    void SET_PropSpecificEffectToApplyToHiders(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x1068, Value); } // 0x1068 (Size: 0x8, Type: ClassProperty)
    void SET_RustlesPerWobble(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1070, Value); } // 0x1070 (Size: 0x28, Type: StructProperty)
    void SET_RustleWobbleRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1098, Value); } // 0x1098 (Size: 0x28, Type: StructProperty)
    void SET_EnterWobbleRadius(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x10c0, Value); } // 0x10c0 (Size: 0x28, Type: StructProperty)
    void SET_NonJumpExitDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x10e8, Value); } // 0x10e8 (Size: 0x8, Type: DoubleProperty)
    void SET_Camera_Mode(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x10f0, Value); } // 0x10f0 (Size: 0x8, Type: ClassProperty)
    void SET_MoveToActorOnEnter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10f8, Value); } // 0x10f8 (Size: 0x1, Type: BoolProperty)
    void SET_IgnorePhysicsBodyCollisionOnEnter(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10f9, Value); } // 0x10f9 (Size: 0x1, Type: BoolProperty)
    void SET_bCanRustleAndWobble(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10fa, Value); } // 0x10fa (Size: 0x1, Type: BoolProperty)
    void SET_SkipRestoreCameraViewTargetOnStopHiding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10fb, Value); } // 0x10fb (Size: 0x1, Type: BoolProperty)
    void SET_SkipRootMotionMovementOnStopHiding(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10fc, Value); } // 0x10fc (Size: 0x1, Type: BoolProperty)
    void SET_AddedSetEntranceRotation(const FRotator& Value) { Write<FRotator>(uintptr_t(this) + 0x1100, Value); } // 0x1100 (Size: 0x18, Type: StructProperty)
    void SET_MoveToActorDelayOnEnter(const double& Value) { Write<double>(uintptr_t(this) + 0x1118, Value); } // 0x1118 (Size: 0x8, Type: DoubleProperty)
    void SET_MoveToActorDurationOverride(const double& Value) { Write<double>(uintptr_t(this) + 0x1120, Value); } // 0x1120 (Size: 0x8, Type: DoubleProperty)
    void SET_MarkerDisplay(const FMarkedActorDisplayInfo& Value) { Write<FMarkedActorDisplayInfo>(uintptr_t(this) + 0x1128, Value); } // 0x1128 (Size: 0xb0, Type: StructProperty)
    void SET_MarkerPositionOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x11d8, Value); } // 0x11d8 (Size: 0x18, Type: StructProperty)
    void SET_ObstructionTraceByObject(const bool& Value) { Write<bool>(uintptr_t(this) + 0x11f0, Value); } // 0x11f0 (Size: 0x1, Type: BoolProperty)
    void SET_Hiding_Enable_From_Landing(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x11f8, Value); } // 0x11f8 (Size: 0x28, Type: StructProperty)
    void SET_HidingEnabled_0(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0x1220, Value); } // 0x1220 (Size: 0x28, Type: StructProperty)
    void SET_TeleportersTargetingMe(const TArray<TSoftObjectPtr<AB_HidingProp_C*>>& Value) { Write<TArray<TSoftObjectPtr<AB_HidingProp_C*>>>(uintptr_t(this) + 0x1248, Value); } // 0x1248 (Size: 0x10, Type: ArrayProperty)
    void SET_BypassJumpOut(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1258, Value); } // 0x1258 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xa68
class UGE_WilliePete_PlayerLaunch_Granted_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Athena_HidingProp_ApplyTeleportGA_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Athena_TillLandFallDamageImmunity_C : public UGameplayEffect
{
public:
};

// Size: 0xbd8
class UGA_Athena_TillLandFallDamageImmunity_Parent_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    UClass* GE_FallDamageImmunity() const { return Read<UClass*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ClassProperty)
    FActiveGameplayEffectHandle GEH_FallDamageImmunity() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: StructProperty)
    double Delay_PostLand() const { return Read<double>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag Tag_SurfaceSwimming() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x4, Type: StructProperty)
    FGameplayTag Tag_Sliding() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb8c); } // 0xb8c (Size: 0x4, Type: StructProperty)
    FGameplayTagContainer TC_IgnoreApplication() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x20, Type: StructProperty)
    FGameplayTag Tag_InVehicle() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbb0); } // 0xbb0 (Size: 0x4, Type: StructProperty)
    double Delay_WaterSwimBind() const { return Read<double>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x8, Type: DoubleProperty)
    bool ApplyInAirOnly() const { return Read<bool>(uintptr_t(this) + 0xbc0); } // 0xbc0 (Size: 0x1, Type: BoolProperty)
    FGameplayTag TagIsRiding() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbc4); } // 0xbc4 (Size: 0x4, Type: StructProperty)
    TArray<UAbilityTask_WaitGameplayTagAdded*> WaitTagAsyncTasks() const { return Read<TArray<UAbilityTask_WaitGameplayTagAdded*>>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_GE_FallDamageImmunity(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ClassProperty)
    void SET_GEH_FallDamageImmunity(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: StructProperty)
    void SET_Delay_PostLand(const double& Value) { Write<double>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: DoubleProperty)
    void SET_Tag_SurfaceSwimming(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x4, Type: StructProperty)
    void SET_Tag_Sliding(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb8c, Value); } // 0xb8c (Size: 0x4, Type: StructProperty)
    void SET_TC_IgnoreApplication(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x20, Type: StructProperty)
    void SET_Tag_InVehicle(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbb0, Value); } // 0xbb0 (Size: 0x4, Type: StructProperty)
    void SET_Delay_WaterSwimBind(const double& Value) { Write<double>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x8, Type: DoubleProperty)
    void SET_ApplyInAirOnly(const bool& Value) { Write<bool>(uintptr_t(this) + 0xbc0, Value); } // 0xbc0 (Size: 0x1, Type: BoolProperty)
    void SET_TagIsRiding(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbc4, Value); } // 0xbc4 (Size: 0x4, Type: StructProperty)
    void SET_WaitTagAsyncTasks(const TArray<UAbilityTask_WaitGameplayTagAdded*>& Value) { Write<TArray<UAbilityTask_WaitGameplayTagAdded*>>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xa68
class UGE_SurfaceChange_Lava_DamageCoolDown_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Athena_HidingProp_TeleportCoolDown_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Athena_DBNO_Bleed_C : public UGET_PeriodicEnergyDamage_C
{
public:
};

// Size: 0xa68
class UGE_Athena_Tether_DamageStructure_C : public UGet_DirectDamageParent_C
{
public:
};

// Size: 0xa68
class UGE_DudebroDamageWallsLOTS_C : public UGet_DirectDamageParent_C
{
public:
};

// Size: 0xa68
class UGE_SD_SiphonEffect_Heal_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_SurfaceChange_Lava_Damage_Periodic_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_SurfaceChange_Lava_Damage_C : public UGameplayEffect
{
public:
};

// Size: 0x420
class AFortWaterBodyBP_C : public AFortWaterBodyActor
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x410); } // 0x410 (Size: 0x8, Type: StructProperty)
    ABP_FluidSim_FN_C* FluidSimBP() const { return Read<ABP_FluidSim_FN_C*>(uintptr_t(this) + 0x418); } // 0x418 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x410, Value); } // 0x410 (Size: 0x8, Type: StructProperty)
    void SET_FluidSimBP(const ABP_FluidSim_FN_C*& Value) { Write<ABP_FluidSim_FN_C*>(uintptr_t(this) + 0x418, Value); } // 0x418 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xa68
class UGE_SiphonEffect_Heal_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_Athena_ZipLine_Passive_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_SiphonEffect_Shield_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_SurfaceChange_Lava_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_SurfaceChange_Chrome_Surface_C : public UGameplayEffect
{
public:
};

// Size: 0xa68
class UGE_SD_SiphonEffect_Shield_C : public UGameplayEffect
{
public:
};

// Size: 0x28
class UHidingPropInterface_C : public UInterface
{
public:
};

// Size: 0xa68
class UGE_Athena_ZipLine_FallDamageImmunityFX_C : public UGameplayEffect
{
public:
};

// Size: 0x350
class ULetoPlayerAvatar_C : public ULetoPlayerAvatar
{
public:
};

// Size: 0xc08
class UGA_Athena_ZipLine_Jump_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    FScalableFloat MaxLateralSpeed() const { return Read<FScalableFloat>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x28, Type: StructProperty)
    FVector ImpulseVec() const { return Read<FVector>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x18, Type: StructProperty)
    FScalableFloat JumpVertStrength() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbb8); } // 0xbb8 (Size: 0x28, Type: StructProperty)
    FScalableFloat JumpLateralDamper() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbe0); } // 0xbe0 (Size: 0x28, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_MaxLateralSpeed(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x28, Type: StructProperty)
    void SET_ImpulseVec(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x18, Type: StructProperty)
    void SET_JumpVertStrength(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbb8, Value); } // 0xbb8 (Size: 0x28, Type: StructProperty)
    void SET_JumpLateralDamper(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbe0, Value); } // 0xbe0 (Size: 0x28, Type: StructProperty)
};

// Size: 0x322
class ABP_ProjectileTrajectory_Athena_C : public ABP_ProjectileTrajectory_C
{
public:
};

// Size: 0xe01
class APROTOTYPE_BP_Athena_Dynamic_ZipLine_Spline_C : public AFortAthenaSplineZipline
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xcc8); } // 0xcc8 (Size: 0x8, Type: StructProperty)
    UStaticMesh* SplineStaticMesh() const { return Read<UStaticMesh*>(uintptr_t(this) + 0xcd0); } // 0xcd0 (Size: 0x8, Type: ObjectProperty)
    double TangentSmoothStrength() const { return Read<double>(uintptr_t(this) + 0xcd8); } // 0xcd8 (Size: 0x8, Type: DoubleProperty)
    bool AutoSmoothTangents() const { return Read<bool>(uintptr_t(this) + 0xce0); } // 0xce0 (Size: 0x1, Type: BoolProperty)
    TEnumAsByte<ESplineMeshAxis> ForwardMeshAxis() const { return Read<TEnumAsByte<ESplineMeshAxis>>(uintptr_t(this) + 0xce1); } // 0xce1 (Size: 0x1, Type: ByteProperty)
    FVector MotorOffset() const { return Read<FVector>(uintptr_t(this) + 0xce8); } // 0xce8 (Size: 0x18, Type: StructProperty)
    AActor* PoleA() const { return Read<AActor*>(uintptr_t(this) + 0xd00); } // 0xd00 (Size: 0x8, Type: ObjectProperty)
    AActor* PoleB() const { return Read<AActor*>(uintptr_t(this) + 0xd08); } // 0xd08 (Size: 0x8, Type: ObjectProperty)
    FVector PoleASocketLocation() const { return Read<FVector>(uintptr_t(this) + 0xd10); } // 0xd10 (Size: 0x18, Type: StructProperty)
    FVector PoleBSocketLocation() const { return Read<FVector>(uintptr_t(this) + 0xd28); } // 0xd28 (Size: 0x18, Type: StructProperty)
    int32_t LowerPointID() const { return Read<int32_t>(uintptr_t(this) + 0xd40); } // 0xd40 (Size: 0x4, Type: IntProperty)
    int32_t HigherPointID() const { return Read<int32_t>(uintptr_t(this) + 0xd44); } // 0xd44 (Size: 0x4, Type: IntProperty)
    FVector HigherEndLocation() const { return Read<FVector>(uintptr_t(this) + 0xd48); } // 0xd48 (Size: 0x18, Type: StructProperty)
    FVector LowerEndLocation() const { return Read<FVector>(uintptr_t(this) + 0xd60); } // 0xd60 (Size: 0x18, Type: StructProperty)
    double AutoLinearFactorLow() const { return Read<double>(uintptr_t(this) + 0xd78); } // 0xd78 (Size: 0x8, Type: DoubleProperty)
    double AutoLinearFactorHigh() const { return Read<double>(uintptr_t(this) + 0xd80); } // 0xd80 (Size: 0x8, Type: DoubleProperty)
    double AutoSplineTangentLengthCoef() const { return Read<double>(uintptr_t(this) + 0xd88); } // 0xd88 (Size: 0x8, Type: DoubleProperty)
    double AutoSplineTangentHorizCoef() const { return Read<double>(uintptr_t(this) + 0xd90); } // 0xd90 (Size: 0x8, Type: DoubleProperty)
    double AutoSplineTangentVertCoef() const { return Read<double>(uintptr_t(this) + 0xd98); } // 0xd98 (Size: 0x8, Type: DoubleProperty)
    bool Auto_Set_Spline_Ends() const { return Read<bool>(uintptr_t(this) + 0xda0); } // 0xda0 (Size: 0x1, Type: BoolProperty)
    bool Auto_Set_Spline_Mids() const { return Read<bool>(uintptr_t(this) + 0xda1); } // 0xda1 (Size: 0x1, Type: BoolProperty)
    TArray<UMaterialInstanceDynamic*> SplineMaterials() const { return Read<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0xda8); } // 0xda8 (Size: 0x10, Type: ArrayProperty)
    FGameplayTagContainer BlockInteractTags() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0xdb8); } // 0xdb8 (Size: 0x20, Type: StructProperty)
    double TilingDivisor() const { return Read<double>(uintptr_t(this) + 0xdd8); } // 0xdd8 (Size: 0x8, Type: DoubleProperty)
    TArray<USplineMeshComponent*> SplineMeshComponents() const { return Read<TArray<USplineMeshComponent*>>(uintptr_t(this) + 0xde0); } // 0xde0 (Size: 0x10, Type: ArrayProperty)
    TArray<AFortPlayerPawn*> PlayerPawnArray() const { return Read<TArray<AFortPlayerPawn*>>(uintptr_t(this) + 0xdf0); } // 0xdf0 (Size: 0x10, Type: ArrayProperty)
    bool Debug() const { return Read<bool>(uintptr_t(this) + 0xe00); } // 0xe00 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xcc8, Value); } // 0xcc8 (Size: 0x8, Type: StructProperty)
    void SET_SplineStaticMesh(const UStaticMesh*& Value) { Write<UStaticMesh*>(uintptr_t(this) + 0xcd0, Value); } // 0xcd0 (Size: 0x8, Type: ObjectProperty)
    void SET_TangentSmoothStrength(const double& Value) { Write<double>(uintptr_t(this) + 0xcd8, Value); } // 0xcd8 (Size: 0x8, Type: DoubleProperty)
    void SET_AutoSmoothTangents(const bool& Value) { Write<bool>(uintptr_t(this) + 0xce0, Value); } // 0xce0 (Size: 0x1, Type: BoolProperty)
    void SET_ForwardMeshAxis(const TEnumAsByte<ESplineMeshAxis>& Value) { Write<TEnumAsByte<ESplineMeshAxis>>(uintptr_t(this) + 0xce1, Value); } // 0xce1 (Size: 0x1, Type: ByteProperty)
    void SET_MotorOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xce8, Value); } // 0xce8 (Size: 0x18, Type: StructProperty)
    void SET_PoleA(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xd00, Value); } // 0xd00 (Size: 0x8, Type: ObjectProperty)
    void SET_PoleB(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0xd08, Value); } // 0xd08 (Size: 0x8, Type: ObjectProperty)
    void SET_PoleASocketLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd10, Value); } // 0xd10 (Size: 0x18, Type: StructProperty)
    void SET_PoleBSocketLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd28, Value); } // 0xd28 (Size: 0x18, Type: StructProperty)
    void SET_LowerPointID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd40, Value); } // 0xd40 (Size: 0x4, Type: IntProperty)
    void SET_HigherPointID(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd44, Value); } // 0xd44 (Size: 0x4, Type: IntProperty)
    void SET_HigherEndLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd48, Value); } // 0xd48 (Size: 0x18, Type: StructProperty)
    void SET_LowerEndLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd60, Value); } // 0xd60 (Size: 0x18, Type: StructProperty)
    void SET_AutoLinearFactorLow(const double& Value) { Write<double>(uintptr_t(this) + 0xd78, Value); } // 0xd78 (Size: 0x8, Type: DoubleProperty)
    void SET_AutoLinearFactorHigh(const double& Value) { Write<double>(uintptr_t(this) + 0xd80, Value); } // 0xd80 (Size: 0x8, Type: DoubleProperty)
    void SET_AutoSplineTangentLengthCoef(const double& Value) { Write<double>(uintptr_t(this) + 0xd88, Value); } // 0xd88 (Size: 0x8, Type: DoubleProperty)
    void SET_AutoSplineTangentHorizCoef(const double& Value) { Write<double>(uintptr_t(this) + 0xd90, Value); } // 0xd90 (Size: 0x8, Type: DoubleProperty)
    void SET_AutoSplineTangentVertCoef(const double& Value) { Write<double>(uintptr_t(this) + 0xd98, Value); } // 0xd98 (Size: 0x8, Type: DoubleProperty)
    void SET_Auto_Set_Spline_Ends(const bool& Value) { Write<bool>(uintptr_t(this) + 0xda0, Value); } // 0xda0 (Size: 0x1, Type: BoolProperty)
    void SET_Auto_Set_Spline_Mids(const bool& Value) { Write<bool>(uintptr_t(this) + 0xda1, Value); } // 0xda1 (Size: 0x1, Type: BoolProperty)
    void SET_SplineMaterials(const TArray<UMaterialInstanceDynamic*>& Value) { Write<TArray<UMaterialInstanceDynamic*>>(uintptr_t(this) + 0xda8, Value); } // 0xda8 (Size: 0x10, Type: ArrayProperty)
    void SET_BlockInteractTags(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0xdb8, Value); } // 0xdb8 (Size: 0x20, Type: StructProperty)
    void SET_TilingDivisor(const double& Value) { Write<double>(uintptr_t(this) + 0xdd8, Value); } // 0xdd8 (Size: 0x8, Type: DoubleProperty)
    void SET_SplineMeshComponents(const TArray<USplineMeshComponent*>& Value) { Write<TArray<USplineMeshComponent*>>(uintptr_t(this) + 0xde0, Value); } // 0xde0 (Size: 0x10, Type: ArrayProperty)
    void SET_PlayerPawnArray(const TArray<AFortPlayerPawn*>& Value) { Write<TArray<AFortPlayerPawn*>>(uintptr_t(this) + 0xdf0, Value); } // 0xdf0 (Size: 0x10, Type: ArrayProperty)
    void SET_Debug(const bool& Value) { Write<bool>(uintptr_t(this) + 0xe00, Value); } // 0xe00 (Size: 0x1, Type: BoolProperty)
};

// Size: 0xbf4
class UGA_Athena_Tethered_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    FActiveGameplayEffectHandle GE_TetheredHandle() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* OwningFortPlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    double maxSpeedToPlayGCN() const { return Read<double>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: DoubleProperty)
    FGameplayTag GCTagPlayerLand() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x4, Type: StructProperty)
    UClass* StructureDamageGE() const { return Read<UClass*>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x8, Type: ClassProperty)
    FGameplayTag SmashGC() const { return Read<FGameplayTag>(uintptr_t(this) + 0xb98); } // 0xb98 (Size: 0x4, Type: StructProperty)
    FScalableFloat BreakStructuresOnTetherEnabled() const { return Read<FScalableFloat>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x28, Type: StructProperty)
    FScalableFloat BreakStructuresOnTetherRange() const { return Read<FScalableFloat>(uintptr_t(this) + 0xbc8); } // 0xbc8 (Size: 0x28, Type: StructProperty)
    FGameplayTag Event_FishingForceEnd() const { return Read<FGameplayTag>(uintptr_t(this) + 0xbf0); } // 0xbf0 (Size: 0x4, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_GE_TetheredHandle(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: StructProperty)
    void SET_OwningFortPlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x8, Type: ObjectProperty)
    void SET_maxSpeedToPlayGCN(const double& Value) { Write<double>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: DoubleProperty)
    void SET_GCTagPlayerLand(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x4, Type: StructProperty)
    void SET_StructureDamageGE(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x8, Type: ClassProperty)
    void SET_SmashGC(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xb98, Value); } // 0xb98 (Size: 0x4, Type: StructProperty)
    void SET_BreakStructuresOnTetherEnabled(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x28, Type: StructProperty)
    void SET_BreakStructuresOnTetherRange(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xbc8, Value); } // 0xbc8 (Size: 0x28, Type: StructProperty)
    void SET_Event_FishingForceEnd(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0xbf0, Value); } // 0xbf0 (Size: 0x4, Type: StructProperty)
};

// Size: 0xc80
class AProp_PhysicsBoulder_Parent_C : public ABuildingProp
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc00); } // 0xc00 (Size: 0x8, Type: StructProperty)
    UFortSoundIndicatorComponent* Sound_Indicator() const { return Read<UFortSoundIndicatorComponent*>(uintptr_t(this) + 0xc08); } // 0xc08 (Size: 0x8, Type: ObjectProperty)
    FVector LastImpactNormal() const { return Read<FVector>(uintptr_t(this) + 0xc10); } // 0xc10 (Size: 0x18, Type: StructProperty)
    FScalableFloat VerticalImpulseRatio() const { return Read<FScalableFloat>(uintptr_t(this) + 0xc28); } // 0xc28 (Size: 0x28, Type: StructProperty)
    double NextPotentialLaunchTime() const { return Read<double>(uintptr_t(this) + 0xc50); } // 0xc50 (Size: 0x8, Type: DoubleProperty)
    double LaunchDelay() const { return Read<double>(uintptr_t(this) + 0xc58); } // 0xc58 (Size: 0x8, Type: DoubleProperty)
    TArray<FScalableFloat> PlayerImpactTiers() const { return Read<TArray<FScalableFloat>>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x10, Type: ArrayProperty)
    TArray<FScalableFloat> PlayerImpulseTiers() const { return Read<TArray<FScalableFloat>>(uintptr_t(this) + 0xc70); } // 0xc70 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xc00, Value); } // 0xc00 (Size: 0x8, Type: StructProperty)
    void SET_Sound_Indicator(const UFortSoundIndicatorComponent*& Value) { Write<UFortSoundIndicatorComponent*>(uintptr_t(this) + 0xc08, Value); } // 0xc08 (Size: 0x8, Type: ObjectProperty)
    void SET_LastImpactNormal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc10, Value); } // 0xc10 (Size: 0x18, Type: StructProperty)
    void SET_VerticalImpulseRatio(const FScalableFloat& Value) { Write<FScalableFloat>(uintptr_t(this) + 0xc28, Value); } // 0xc28 (Size: 0x28, Type: StructProperty)
    void SET_NextPotentialLaunchTime(const double& Value) { Write<double>(uintptr_t(this) + 0xc50, Value); } // 0xc50 (Size: 0x8, Type: DoubleProperty)
    void SET_LaunchDelay(const double& Value) { Write<double>(uintptr_t(this) + 0xc58, Value); } // 0xc58 (Size: 0x8, Type: DoubleProperty)
    void SET_PlayerImpactTiers(const TArray<FScalableFloat>& Value) { Write<TArray<FScalableFloat>>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x10, Type: ArrayProperty)
    void SET_PlayerImpulseTiers(const TArray<FScalableFloat>& Value) { Write<TArray<FScalableFloat>>(uintptr_t(this) + 0xc70, Value); } // 0xc70 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb98
class UGA_Athena_Slurp_OLD_C : public UFortGameplayAbility
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68); } // 0xb68 (Size: 0x8, Type: StructProperty)
    AFortPlayerPawn* PlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    int32_t IncreCheck() const { return Read<int32_t>(uintptr_t(this) + 0xb78); } // 0xb78 (Size: 0x4, Type: IntProperty)
    double MaxTicks() const { return Read<double>(uintptr_t(this) + 0xb80); } // 0xb80 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle TimerHandle() const { return Read<FTimerHandle>(uintptr_t(this) + 0xb88); } // 0xb88 (Size: 0x8, Type: StructProperty)
    double TickRate() const { return Read<double>(uintptr_t(this) + 0xb90); } // 0xb90 (Size: 0x8, Type: DoubleProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0xb68, Value); } // 0xb68 (Size: 0x8, Type: StructProperty)
    void SET_PlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x8, Type: ObjectProperty)
    void SET_IncreCheck(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb78, Value); } // 0xb78 (Size: 0x4, Type: IntProperty)
    void SET_MaxTicks(const double& Value) { Write<double>(uintptr_t(this) + 0xb80, Value); } // 0xb80 (Size: 0x8, Type: DoubleProperty)
    void SET_TimerHandle(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0xb88, Value); } // 0xb88 (Size: 0x8, Type: StructProperty)
    void SET_TickRate(const double& Value) { Write<double>(uintptr_t(this) + 0xb90, Value); } // 0xb90 (Size: 0x8, Type: DoubleProperty)
};

// Size: 0x7a8
class ABP_FluidSim_FN_C : public ABP_FluidSim_01_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x8, Type: StructProperty)
    FFluidForceDynamic BoatForceSettings() const { return Read<FFluidForceDynamic>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x70, Type: StructProperty)
    FFluidForceDynamic PlayerForceSettings() const { return Read<FFluidForceDynamic>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x70, Type: StructProperty)
    FFluidForceDynamic MechForceSettings() const { return Read<FFluidForceDynamic>(uintptr_t(this) + 0x6d0); } // 0x6d0 (Size: 0x70, Type: StructProperty)
    TArray<AFortPawn*> RelevantFortPawns() const { return Read<TArray<AFortPawn*>>(uintptr_t(this) + 0x740); } // 0x740 (Size: 0x10, Type: ArrayProperty)
    bool Use_FN_Pawn_Forces() const { return Read<bool>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0x1, Type: BoolProperty)
    TMap<FFluidForceDynamic, FGameplayTag> VehicleTypeMap() const { return Read<TMap<FFluidForceDynamic, FGameplayTag>>(uintptr_t(this) + 0x758); } // 0x758 (Size: 0x50, Type: MapProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x8, Type: StructProperty)
    void SET_BoatForceSettings(const FFluidForceDynamic& Value) { Write<FFluidForceDynamic>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x70, Type: StructProperty)
    void SET_PlayerForceSettings(const FFluidForceDynamic& Value) { Write<FFluidForceDynamic>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x70, Type: StructProperty)
    void SET_MechForceSettings(const FFluidForceDynamic& Value) { Write<FFluidForceDynamic>(uintptr_t(this) + 0x6d0, Value); } // 0x6d0 (Size: 0x70, Type: StructProperty)
    void SET_RelevantFortPawns(const TArray<AFortPawn*>& Value) { Write<TArray<AFortPawn*>>(uintptr_t(this) + 0x740, Value); } // 0x740 (Size: 0x10, Type: ArrayProperty)
    void SET_Use_FN_Pawn_Forces(const bool& Value) { Write<bool>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0x1, Type: BoolProperty)
    void SET_VehicleTypeMap(const TMap<FFluidForceDynamic, FGameplayTag>& Value) { Write<TMap<FFluidForceDynamic, FGameplayTag>>(uintptr_t(this) + 0x758, Value); } // 0x758 (Size: 0x50, Type: MapProperty)
};

// Size: 0x2530
class AJackalVehicle_Athena_C : public AFortAthenaJackalVehicle
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2330); } // 0x2330 (Size: 0x8, Type: StructProperty)
    UFortVehicleAudioVoice* AudioWind() const { return Read<UFortVehicleAudioVoice*>(uintptr_t(this) + 0x2338); } // 0x2338 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* AudioLand() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x2340); } // 0x2340 (Size: 0x8, Type: ObjectProperty)
    UFortVehicleAudioVoice* AudioBoost() const { return Read<UFortVehicleAudioVoice*>(uintptr_t(this) + 0x2348); } // 0x2348 (Size: 0x8, Type: ObjectProperty)
    UFortVehicleAudioVoice* AudioMovement() const { return Read<UFortVehicleAudioVoice*>(uintptr_t(this) + 0x2350); } // 0x2350 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* AudioJump() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x2358); } // 0x2358 (Size: 0x8, Type: ObjectProperty)
    UStaticMeshComponent* SM_Hoverboard_Lightbeams() const { return Read<UStaticMeshComponent*>(uintptr_t(this) + 0x2360); } // 0x2360 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* LoopingFX() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x2368); } // 0x2368 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* BoostFX() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x2370); } // 0x2370 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* BackLight() const { return Read<USpotLightComponent*>(uintptr_t(this) + 0x2378); } // 0x2378 (Size: 0x8, Type: ObjectProperty)
    USpotLightComponent* FrontLight() const { return Read<USpotLightComponent*>(uintptr_t(this) + 0x2380); } // 0x2380 (Size: 0x8, Type: ObjectProperty)
    UFortCollisionAudioComponent* FortCollisionAudioImpacts() const { return Read<UFortCollisionAudioComponent*>(uintptr_t(this) + 0x2388); } // 0x2388 (Size: 0x8, Type: ObjectProperty)
    UBoxComponent* OverlapVolume() const { return Read<UBoxComponent*>(uintptr_t(this) + 0x2390); } // 0x2390 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* DriverPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x2398); } // 0x2398 (Size: 0x8, Type: ObjectProperty)
    APlayerController* DrivingPlayerController() const { return Read<APlayerController*>(uintptr_t(this) + 0x23a0); } // 0x23a0 (Size: 0x8, Type: ObjectProperty)
    AFortPlayerPawn* LocalPlayerPawn() const { return Read<AFortPlayerPawn*>(uintptr_t(this) + 0x23a8); } // 0x23a8 (Size: 0x8, Type: ObjectProperty)
    double Delta() const { return Read<double>(uintptr_t(this) + 0x23b0); } // 0x23b0 (Size: 0x8, Type: DoubleProperty)
    bool bJumpCharging() const { return Read<bool>(uintptr_t(this) + 0x23b8); } // 0x23b8 (Size: 0x1, Type: BoolProperty)
    USoundBase* MountSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x23c0); } // 0x23c0 (Size: 0x8, Type: ObjectProperty)
    UParticleSystemComponent* InWaterFX() const { return Read<UParticleSystemComponent*>(uintptr_t(this) + 0x23c8); } // 0x23c8 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* InWaterLoop() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x23d0); } // 0x23d0 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle CheckWaterTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x23d8); } // 0x23d8 (Size: 0x8, Type: StructProperty)
    double RumbleIntensity() const { return Read<double>(uintptr_t(this) + 0x23e0); } // 0x23e0 (Size: 0x8, Type: DoubleProperty)
    bool Debug_NoCameraShake() const { return Read<bool>(uintptr_t(this) + 0x23e8); } // 0x23e8 (Size: 0x1, Type: BoolProperty)
    ULegacyCameraShake* DriverCameraShake() const { return Read<ULegacyCameraShake*>(uintptr_t(this) + 0x23f0); } // 0x23f0 (Size: 0x8, Type: ObjectProperty)
    double EngineSoundMaxDistance() const { return Read<double>(uintptr_t(this) + 0x23f8); } // 0x23f8 (Size: 0x8, Type: DoubleProperty)
    bool Jumped() const { return Read<bool>(uintptr_t(this) + 0x2400); } // 0x2400 (Size: 0x1, Type: BoolProperty)
    UMaterialInstanceDynamic* BoostMeterMID() const { return Read<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2408); } // 0x2408 (Size: 0x8, Type: ObjectProperty)
    double BoostTImelineAlpha() const { return Read<double>(uintptr_t(this) + 0x2410); } // 0x2410 (Size: 0x8, Type: DoubleProperty)
    FVector FXBoostEnd_0() const { return Read<FVector>(uintptr_t(this) + 0x2418); } // 0x2418 (Size: 0x18, Type: StructProperty)
    USoundBase* DismountSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x2430); } // 0x2430 (Size: 0x8, Type: ObjectProperty)
    FVector FXFrontSpringOffset() const { return Read<FVector>(uintptr_t(this) + 0x2438); } // 0x2438 (Size: 0x18, Type: StructProperty)
    FVector FXRearSpringOffset() const { return Read<FVector>(uintptr_t(this) + 0x2450); } // 0x2450 (Size: 0x18, Type: StructProperty)
    int32_t FXSurfaceType() const { return Read<int32_t>(uintptr_t(this) + 0x2468); } // 0x2468 (Size: 0x4, Type: IntProperty)
    double SavedDamageValueForMID() const { return Read<double>(uintptr_t(this) + 0x2470); } // 0x2470 (Size: 0x8, Type: DoubleProperty)
    double MaxSpeedToDestroy() const { return Read<double>(uintptr_t(this) + 0x2478); } // 0x2478 (Size: 0x8, Type: DoubleProperty)
    double MaxHealthToDestroy() const { return Read<double>(uintptr_t(this) + 0x2480); } // 0x2480 (Size: 0x8, Type: DoubleProperty)
    double SavedHeadlightValueForMID() const { return Read<double>(uintptr_t(this) + 0x2488); } // 0x2488 (Size: 0x8, Type: DoubleProperty)
    double BoostTimeValueForMID() const { return Read<double>(uintptr_t(this) + 0x2490); } // 0x2490 (Size: 0x8, Type: DoubleProperty)
    AActor* VehicleHitActor() const { return Read<AActor*>(uintptr_t(this) + 0x2498); } // 0x2498 (Size: 0x8, Type: ObjectProperty)
    double DestructionAngle() const { return Read<double>(uintptr_t(this) + 0x24a0); } // 0x24a0 (Size: 0x8, Type: DoubleProperty)
    double LandingFXImpactThreshold() const { return Read<double>(uintptr_t(this) + 0x24a8); } // 0x24a8 (Size: 0x8, Type: DoubleProperty)
    UParticleSystem* LandingFX() const { return Read<UParticleSystem*>(uintptr_t(this) + 0x24b0); } // 0x24b0 (Size: 0x8, Type: ObjectProperty)
    USoundBase* OnDeathSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x24b8); } // 0x24b8 (Size: 0x8, Type: ObjectProperty)
    double BumpForceAngle() const { return Read<double>(uintptr_t(this) + 0x24c0); } // 0x24c0 (Size: 0x8, Type: DoubleProperty)
    UClass* JumpCameraShake() const { return Read<UClass*>(uintptr_t(this) + 0x24c8); } // 0x24c8 (Size: 0x8, Type: ClassProperty)
    double MovementVisualUpdate() const { return Read<double>(uintptr_t(this) + 0x24d0); } // 0x24d0 (Size: 0x8, Type: DoubleProperty)
    FTimerHandle MovementVisualTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x24d8); } // 0x24d8 (Size: 0x8, Type: StructProperty)
    double SlipStreamImpulseForce() const { return Read<double>(uintptr_t(this) + 0x24e0); } // 0x24e0 (Size: 0x8, Type: DoubleProperty)
    UMaterialInterface* WrapBaseMaterial() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x24e8); } // 0x24e8 (Size: 0x8, Type: ObjectProperty)
    FActiveGameplayEffectHandle CooldownCueEvent() const { return Read<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x24f0); } // 0x24f0 (Size: 0x8, Type: StructProperty)
    UClass* GE_Boost() const { return Read<UClass*>(uintptr_t(this) + 0x24f8); } // 0x24f8 (Size: 0x8, Type: ClassProperty)
    FGameplayTag GameplayEvent() const { return Read<FGameplayTag>(uintptr_t(this) + 0x2500); } // 0x2500 (Size: 0x4, Type: StructProperty)
    double WaterFXHeightOffset() const { return Read<double>(uintptr_t(this) + 0x2508); } // 0x2508 (Size: 0x8, Type: DoubleProperty)
    double WaterHeight() const { return Read<double>(uintptr_t(this) + 0x2510); } // 0x2510 (Size: 0x8, Type: DoubleProperty)
    FName Water_Test_Socket_Name() const { return Read<FName>(uintptr_t(this) + 0x2518); } // 0x2518 (Size: 0x4, Type: NameProperty)
    bool bUseAudio() const { return Read<bool>(uintptr_t(this) + 0x251c); } // 0x251c (Size: 0x1, Type: BoolProperty)
    TArray<UAnimMontage*> MontagesToStopOnBoost() const { return Read<TArray<UAnimMontage*>>(uintptr_t(this) + 0x2520); } // 0x2520 (Size: 0x10, Type: ArrayProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x2330, Value); } // 0x2330 (Size: 0x8, Type: StructProperty)
    void SET_AudioWind(const UFortVehicleAudioVoice*& Value) { Write<UFortVehicleAudioVoice*>(uintptr_t(this) + 0x2338, Value); } // 0x2338 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioLand(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x2340, Value); } // 0x2340 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioBoost(const UFortVehicleAudioVoice*& Value) { Write<UFortVehicleAudioVoice*>(uintptr_t(this) + 0x2348, Value); } // 0x2348 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioMovement(const UFortVehicleAudioVoice*& Value) { Write<UFortVehicleAudioVoice*>(uintptr_t(this) + 0x2350, Value); } // 0x2350 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioJump(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x2358, Value); } // 0x2358 (Size: 0x8, Type: ObjectProperty)
    void SET_SM_Hoverboard_Lightbeams(const UStaticMeshComponent*& Value) { Write<UStaticMeshComponent*>(uintptr_t(this) + 0x2360, Value); } // 0x2360 (Size: 0x8, Type: ObjectProperty)
    void SET_LoopingFX(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x2368, Value); } // 0x2368 (Size: 0x8, Type: ObjectProperty)
    void SET_BoostFX(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x2370, Value); } // 0x2370 (Size: 0x8, Type: ObjectProperty)
    void SET_BackLight(const USpotLightComponent*& Value) { Write<USpotLightComponent*>(uintptr_t(this) + 0x2378, Value); } // 0x2378 (Size: 0x8, Type: ObjectProperty)
    void SET_FrontLight(const USpotLightComponent*& Value) { Write<USpotLightComponent*>(uintptr_t(this) + 0x2380, Value); } // 0x2380 (Size: 0x8, Type: ObjectProperty)
    void SET_FortCollisionAudioImpacts(const UFortCollisionAudioComponent*& Value) { Write<UFortCollisionAudioComponent*>(uintptr_t(this) + 0x2388, Value); } // 0x2388 (Size: 0x8, Type: ObjectProperty)
    void SET_OverlapVolume(const UBoxComponent*& Value) { Write<UBoxComponent*>(uintptr_t(this) + 0x2390, Value); } // 0x2390 (Size: 0x8, Type: ObjectProperty)
    void SET_DriverPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x2398, Value); } // 0x2398 (Size: 0x8, Type: ObjectProperty)
    void SET_DrivingPlayerController(const APlayerController*& Value) { Write<APlayerController*>(uintptr_t(this) + 0x23a0, Value); } // 0x23a0 (Size: 0x8, Type: ObjectProperty)
    void SET_LocalPlayerPawn(const AFortPlayerPawn*& Value) { Write<AFortPlayerPawn*>(uintptr_t(this) + 0x23a8, Value); } // 0x23a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Delta(const double& Value) { Write<double>(uintptr_t(this) + 0x23b0, Value); } // 0x23b0 (Size: 0x8, Type: DoubleProperty)
    void SET_bJumpCharging(const bool& Value) { Write<bool>(uintptr_t(this) + 0x23b8, Value); } // 0x23b8 (Size: 0x1, Type: BoolProperty)
    void SET_MountSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x23c0, Value); } // 0x23c0 (Size: 0x8, Type: ObjectProperty)
    void SET_InWaterFX(const UParticleSystemComponent*& Value) { Write<UParticleSystemComponent*>(uintptr_t(this) + 0x23c8, Value); } // 0x23c8 (Size: 0x8, Type: ObjectProperty)
    void SET_InWaterLoop(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x23d0, Value); } // 0x23d0 (Size: 0x8, Type: ObjectProperty)
    void SET_CheckWaterTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x23d8, Value); } // 0x23d8 (Size: 0x8, Type: StructProperty)
    void SET_RumbleIntensity(const double& Value) { Write<double>(uintptr_t(this) + 0x23e0, Value); } // 0x23e0 (Size: 0x8, Type: DoubleProperty)
    void SET_Debug_NoCameraShake(const bool& Value) { Write<bool>(uintptr_t(this) + 0x23e8, Value); } // 0x23e8 (Size: 0x1, Type: BoolProperty)
    void SET_DriverCameraShake(const ULegacyCameraShake*& Value) { Write<ULegacyCameraShake*>(uintptr_t(this) + 0x23f0, Value); } // 0x23f0 (Size: 0x8, Type: ObjectProperty)
    void SET_EngineSoundMaxDistance(const double& Value) { Write<double>(uintptr_t(this) + 0x23f8, Value); } // 0x23f8 (Size: 0x8, Type: DoubleProperty)
    void SET_Jumped(const bool& Value) { Write<bool>(uintptr_t(this) + 0x2400, Value); } // 0x2400 (Size: 0x1, Type: BoolProperty)
    void SET_BoostMeterMID(const UMaterialInstanceDynamic*& Value) { Write<UMaterialInstanceDynamic*>(uintptr_t(this) + 0x2408, Value); } // 0x2408 (Size: 0x8, Type: ObjectProperty)
    void SET_BoostTImelineAlpha(const double& Value) { Write<double>(uintptr_t(this) + 0x2410, Value); } // 0x2410 (Size: 0x8, Type: DoubleProperty)
    void SET_FXBoostEnd_0(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2418, Value); } // 0x2418 (Size: 0x18, Type: StructProperty)
    void SET_DismountSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x2430, Value); } // 0x2430 (Size: 0x8, Type: ObjectProperty)
    void SET_FXFrontSpringOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2438, Value); } // 0x2438 (Size: 0x18, Type: StructProperty)
    void SET_FXRearSpringOffset(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x2450, Value); } // 0x2450 (Size: 0x18, Type: StructProperty)
    void SET_FXSurfaceType(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x2468, Value); } // 0x2468 (Size: 0x4, Type: IntProperty)
    void SET_SavedDamageValueForMID(const double& Value) { Write<double>(uintptr_t(this) + 0x2470, Value); } // 0x2470 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxSpeedToDestroy(const double& Value) { Write<double>(uintptr_t(this) + 0x2478, Value); } // 0x2478 (Size: 0x8, Type: DoubleProperty)
    void SET_MaxHealthToDestroy(const double& Value) { Write<double>(uintptr_t(this) + 0x2480, Value); } // 0x2480 (Size: 0x8, Type: DoubleProperty)
    void SET_SavedHeadlightValueForMID(const double& Value) { Write<double>(uintptr_t(this) + 0x2488, Value); } // 0x2488 (Size: 0x8, Type: DoubleProperty)
    void SET_BoostTimeValueForMID(const double& Value) { Write<double>(uintptr_t(this) + 0x2490, Value); } // 0x2490 (Size: 0x8, Type: DoubleProperty)
    void SET_VehicleHitActor(const AActor*& Value) { Write<AActor*>(uintptr_t(this) + 0x2498, Value); } // 0x2498 (Size: 0x8, Type: ObjectProperty)
    void SET_DestructionAngle(const double& Value) { Write<double>(uintptr_t(this) + 0x24a0, Value); } // 0x24a0 (Size: 0x8, Type: DoubleProperty)
    void SET_LandingFXImpactThreshold(const double& Value) { Write<double>(uintptr_t(this) + 0x24a8, Value); } // 0x24a8 (Size: 0x8, Type: DoubleProperty)
    void SET_LandingFX(const UParticleSystem*& Value) { Write<UParticleSystem*>(uintptr_t(this) + 0x24b0, Value); } // 0x24b0 (Size: 0x8, Type: ObjectProperty)
    void SET_OnDeathSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x24b8, Value); } // 0x24b8 (Size: 0x8, Type: ObjectProperty)
    void SET_BumpForceAngle(const double& Value) { Write<double>(uintptr_t(this) + 0x24c0, Value); } // 0x24c0 (Size: 0x8, Type: DoubleProperty)
    void SET_JumpCameraShake(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x24c8, Value); } // 0x24c8 (Size: 0x8, Type: ClassProperty)
    void SET_MovementVisualUpdate(const double& Value) { Write<double>(uintptr_t(this) + 0x24d0, Value); } // 0x24d0 (Size: 0x8, Type: DoubleProperty)
    void SET_MovementVisualTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x24d8, Value); } // 0x24d8 (Size: 0x8, Type: StructProperty)
    void SET_SlipStreamImpulseForce(const double& Value) { Write<double>(uintptr_t(this) + 0x24e0, Value); } // 0x24e0 (Size: 0x8, Type: DoubleProperty)
    void SET_WrapBaseMaterial(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x24e8, Value); } // 0x24e8 (Size: 0x8, Type: ObjectProperty)
    void SET_CooldownCueEvent(const FActiveGameplayEffectHandle& Value) { Write<FActiveGameplayEffectHandle>(uintptr_t(this) + 0x24f0, Value); } // 0x24f0 (Size: 0x8, Type: StructProperty)
    void SET_GE_Boost(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x24f8, Value); } // 0x24f8 (Size: 0x8, Type: ClassProperty)
    void SET_GameplayEvent(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x2500, Value); } // 0x2500 (Size: 0x4, Type: StructProperty)
    void SET_WaterFXHeightOffset(const double& Value) { Write<double>(uintptr_t(this) + 0x2508, Value); } // 0x2508 (Size: 0x8, Type: DoubleProperty)
    void SET_WaterHeight(const double& Value) { Write<double>(uintptr_t(this) + 0x2510, Value); } // 0x2510 (Size: 0x8, Type: DoubleProperty)
    void SET_Water_Test_Socket_Name(const FName& Value) { Write<FName>(uintptr_t(this) + 0x2518, Value); } // 0x2518 (Size: 0x4, Type: NameProperty)
    void SET_bUseAudio(const bool& Value) { Write<bool>(uintptr_t(this) + 0x251c, Value); } // 0x251c (Size: 0x1, Type: BoolProperty)
    void SET_MontagesToStopOnBoost(const TArray<UAnimMontage*>& Value) { Write<TArray<UAnimMontage*>>(uintptr_t(this) + 0x2520, Value); } // 0x2520 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x3b0
class UWBP_VehicleSpeedoMeter_Preview_C : public UHUDLayoutToolV2_WidgetPreview
{
public:
    UCommonNumericTextBlock* NumericText_Speed() const { return Read<UCommonNumericTextBlock*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Speedometer() const { return Read<UImage*>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_MeterIcon() const { return Read<UImage*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Meter() const { return Read<UImage*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)

    void SET_NumericText_Speed(const UCommonNumericTextBlock*& Value) { Write<UCommonNumericTextBlock*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Speedometer(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_MeterIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Meter(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x608
class UWBP_VehicleGaugeBase_C : public UFortAthenaVehicleDashboardWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x8, Type: StructProperty)
    FGameplayTag DisabledTag() const { return Read<FGameplayTag>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x4, Type: StructProperty)
    bool bIsVehicleElectric() const { return Read<bool>(uintptr_t(this) + 0x604); } // 0x604 (Size: 0x1, Type: BoolProperty)
    bool OutOfFuelWarningActive() const { return Read<bool>(uintptr_t(this) + 0x605); } // 0x605 (Size: 0x1, Type: BoolProperty)
    bool LowFuelWarningActive() const { return Read<bool>(uintptr_t(this) + 0x606); } // 0x606 (Size: 0x1, Type: BoolProperty)
    bool RefuelingWarningActive() const { return Read<bool>(uintptr_t(this) + 0x607); } // 0x607 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x8, Type: StructProperty)
    void SET_DisabledTag(const FGameplayTag& Value) { Write<FGameplayTag>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x4, Type: StructProperty)
    void SET_bIsVehicleElectric(const bool& Value) { Write<bool>(uintptr_t(this) + 0x604, Value); } // 0x604 (Size: 0x1, Type: BoolProperty)
    void SET_OutOfFuelWarningActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x605, Value); } // 0x605 (Size: 0x1, Type: BoolProperty)
    void SET_LowFuelWarningActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x606, Value); } // 0x606 (Size: 0x1, Type: BoolProperty)
    void SET_RefuelingWarningActive(const bool& Value) { Write<bool>(uintptr_t(this) + 0x607, Value); } // 0x607 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x5e8
class UGuidedTutorial_FakeLoadingScreen_C : public UGuidedTutorialLoadingScreen
{
public:
    UImage* BaseColor() const { return Read<UImage*>(uintptr_t(this) + 0x5e0); } // 0x5e0 (Size: 0x8, Type: ObjectProperty)

    void SET_BaseColor(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x5e0, Value); } // 0x5e0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x15e0
class UBP_SkewedTabButton_C : public UAthenaSkewedTabButton
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x8, Type: StructProperty)
    UHorizontalBox* HorizontalBox_0() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    UImage* Background() const { return Read<UImage*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Selected() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15a8); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Hovered() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15b0); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Unhovered() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15b8); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
    FLinearColor RGB1_Text_Color() const { return Read<FLinearColor>(uintptr_t(this) + 0x15c0); } // 0x15c0 (Size: 0x10, Type: StructProperty)
    bool IsSelected() const { return Read<bool>(uintptr_t(this) + 0x15d0); } // 0x15d0 (Size: 0x1, Type: BoolProperty)
    bool bPlaySound() const { return Read<bool>(uintptr_t(this) + 0x15d1); } // 0x15d1 (Size: 0x1, Type: BoolProperty)
    USoundBase* PressedSound() const { return Read<USoundBase*>(uintptr_t(this) + 0x15d8); } // 0x15d8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x8, Type: StructProperty)
    void SET_HorizontalBox_0(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    void SET_Background(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Selected(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15a8, Value); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Hovered(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15b0, Value); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Unhovered(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15b8, Value); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
    void SET_RGB1_Text_Color(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x15c0, Value); } // 0x15c0 (Size: 0x10, Type: StructProperty)
    void SET_IsSelected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15d0, Value); } // 0x15d0 (Size: 0x1, Type: BoolProperty)
    void SET_bPlaySound(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15d1, Value); } // 0x15d1 (Size: 0x1, Type: BoolProperty)
    void SET_PressedSound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x15d8, Value); } // 0x15d8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1520
class UMoreInfo_Ressources_Button_C : public UCommonButtonBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1510); } // 0x1510 (Size: 0x8, Type: StructProperty)
    UWidgetAnimation* Hover() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1518); } // 0x1518 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1510, Value); } // 0x1510 (Size: 0x8, Type: StructProperty)
    void SET_Hover(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1518, Value); } // 0x1518 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x3b0
class UAthenaWatchers_C : public UAthenaWatchers
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x398); } // 0x398 (Size: 0x8, Type: StructProperty)
    UAthenaWatcherEye_C* AthenaWatcherEye() const { return Read<UAthenaWatcherEye_C*>(uintptr_t(this) + 0x3a0); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnValueChanged() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x3a8); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x398, Value); } // 0x398 (Size: 0x8, Type: StructProperty)
    void SET_AthenaWatcherEye(const UAthenaWatcherEye_C*& Value) { Write<UAthenaWatcherEye_C*>(uintptr_t(this) + 0x3a0, Value); } // 0x3a0 (Size: 0x8, Type: ObjectProperty)
    void SET_OnValueChanged(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x3a8, Value); } // 0x3a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x368
class UAthenaWatcherEye_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    UImage* I_Watcher() const { return Read<UImage*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Open() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* LookAround() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Blink() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Surprise() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Blink_New() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Mad() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    FTimerHandle WatcherFinishedTransitionTimer() const { return Read<FTimerHandle>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_I_Watcher(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_Open(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_LookAround(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_Blink(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x8, Type: ObjectProperty)
    void SET_Surprise(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: ObjectProperty)
    void SET_Blink_New(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_Mad(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_WatcherFinishedTransitionTimer(const FTimerHandle& Value) { Write<FTimerHandle>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: StructProperty)
};

// Size: 0x390
class UFortAutoRunNotificationWidget_C : public UFortAutoRunNotificationWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_0() const { return Read<UOverlay*>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Run() const { return Read<UImage*>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    UFortLazyImage* Image_Background() const { return Read<UFortLazyImage*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Intro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Outro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: StructProperty)
    void SET_Text(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_0(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Run(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Background(const UFortLazyImage*& Value) { Write<UFortLazyImage*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_Intro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_Outro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x390
class UAthenaFPS_C : public UFortHUDElementWidget
{
public:
    UAthenaFPSTicker_C* AthenaFPSTicker() const { return Read<UAthenaFPSTicker_C*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)

    void SET_AthenaFPSTicker(const UAthenaFPSTicker_C*& Value) { Write<UAthenaFPSTicker_C*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x15c0
class UAthenaMatchmakingModeButton_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x8, Type: StructProperty)
    UHorizontalBox* SubGameModeNameHB() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x1568); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* SubGameModeName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x8, Type: ObjectProperty)
    UImage* LTMModeSubIcon() const { return Read<UImage*>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* GameModeName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    UImage* GameModeIcon() const { return Read<UImage*>(uintptr_t(this) + 0x1588); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    UImage* ConfirmSelectionShine() const { return Read<UImage*>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    UImage* ConfirmSelectionFlash() const { return Read<UImage*>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* ConfirmSelection() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnHover() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15a8); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    bool FillSquad() const { return Read<bool>(uintptr_t(this) + 0x15b0); } // 0x15b0 (Size: 0x1, Type: BoolProperty)
    UFortPlaylistAthena* PlaylistData() const { return Read<UFortPlaylistAthena*>(uintptr_t(this) + 0x15b8); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x8, Type: StructProperty)
    void SET_SubGameModeNameHB(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x1568, Value); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    void SET_SubGameModeName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x8, Type: ObjectProperty)
    void SET_LTMModeSubIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x8, Type: ObjectProperty)
    void SET_GameModeName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    void SET_GameModeIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1588, Value); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    void SET_ConfirmSelectionShine(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    void SET_ConfirmSelectionFlash(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    void SET_ConfirmSelection(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    void SET_OnHover(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15a8, Value); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    void SET_FillSquad(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15b0, Value); } // 0x15b0 (Size: 0x1, Type: BoolProperty)
    void SET_PlaylistData(const UFortPlaylistAthena*& Value) { Write<UFortPlaylistAthena*>(uintptr_t(this) + 0x15b8, Value); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1f80
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
public:
    FName __NameProperty_1247() const { return Read<FName>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1248() const { return Read<FName>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: NameProperty)
    uint8_t __EnumProperty_1249() const { return Read<uint8_t>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x1, Type: EnumProperty)
    FName __NameProperty_1250() const { return Read<FName>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1251() const { return Read<FName>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1252() const { return Read<FName>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: NameProperty)
    TArray<float> __ArrayProperty_1253() const { return Read<TArray<float>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    uint8_t __EnumProperty_1254() const { return Read<uint8_t>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x1, Type: EnumProperty)
    TArray<float> __ArrayProperty_1255() const { return Read<TArray<float>>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> __ArrayProperty_1256() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x48); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    FName __NameProperty_1257() const { return Read<FName>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x4, Type: NameProperty)
    TArray<float> __ArrayProperty_1258() const { return Read<TArray<float>>(uintptr_t(this) + 0x60); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    FName __NameProperty_1259() const { return Read<FName>(uintptr_t(this) + 0x70); } // 0x70 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1260() const { return Read<FName>(uintptr_t(this) + 0x74); } // 0x74 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1261() const { return Read<FName>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x4, Type: NameProperty)
    float __FloatProperty_1262() const { return Read<float>(uintptr_t(this) + 0x7c); } // 0x7c (Size: 0x4, Type: FloatProperty)
    FName __NameProperty_1263() const { return Read<FName>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x4, Type: NameProperty)
    TArray<float> __ArrayProperty_1264() const { return Read<TArray<float>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    FName __NameProperty_1265() const { return Read<FName>(uintptr_t(this) + 0x98); } // 0x98 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1266() const { return Read<FName>(uintptr_t(this) + 0x9c); } // 0x9c (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1267() const { return Read<FName>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1268() const { return Read<FName>(uintptr_t(this) + 0xa4); } // 0xa4 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1269() const { return Read<FName>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x4, Type: NameProperty)
    int32_t __IntProperty_1270() const { return Read<int32_t>(uintptr_t(this) + 0xac); } // 0xac (Size: 0x4, Type: IntProperty)
    FName __NameProperty_1271() const { return Read<FName>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1272() const { return Read<FName>(uintptr_t(this) + 0xb4); } // 0xb4 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1273() const { return Read<FName>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1274() const { return Read<FName>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1275() const { return Read<FName>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: NameProperty)
    TArray<float> __ArrayProperty_1276() const { return Read<TArray<float>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    FName __NameProperty_1277() const { return Read<FName>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1278() const { return Read<FName>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1279() const { return Read<FName>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x4, Type: NameProperty)
    int32_t __IntProperty_1280() const { return Read<int32_t>(uintptr_t(this) + 0xe4); } // 0xe4 (Size: 0x4, Type: IntProperty)
    FName __NameProperty_1281() const { return Read<FName>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x4, Type: NameProperty)
    int32_t __IntProperty_1282() const { return Read<int32_t>(uintptr_t(this) + 0xec); } // 0xec (Size: 0x4, Type: IntProperty)
    FName __NameProperty_1283() const { return Read<FName>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x4, Type: NameProperty)
    int32_t __IntProperty_1284() const { return Read<int32_t>(uintptr_t(this) + 0xf4); } // 0xf4 (Size: 0x4, Type: IntProperty)
    TArray<float> __ArrayProperty_1285() const { return Read<TArray<float>>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    TArray<int32_t> __ArrayProperty_1286() const { return Read<TArray<int32_t>>(uintptr_t(this) + 0x108); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    FName __NameProperty_1287() const { return Read<FName>(uintptr_t(this) + 0x118); } // 0x118 (Size: 0x4, Type: NameProperty)
    FName __NameProperty_1288() const { return Read<FName>(uintptr_t(this) + 0x11c); } // 0x11c (Size: 0x4, Type: NameProperty)
    int32_t __IntProperty_1289() const { return Read<int32_t>(uintptr_t(this) + 0x120); } // 0x120 (Size: 0x4, Type: IntProperty)
    bool __BoolProperty_1290() const { return Read<bool>(uintptr_t(this) + 0x124); } // 0x124 (Size: 0x1, Type: BoolProperty)
    float __FloatProperty_1291() const { return Read<float>(uintptr_t(this) + 0x128); } // 0x128 (Size: 0x4, Type: FloatProperty)
    FInputScaleBiasClampConstants __StructProperty_1292() const { return Read<FInputScaleBiasClampConstants>(uintptr_t(this) + 0x12c); } // 0x12c (Size: 0x2c, Type: StructProperty)
    float __FloatProperty_1293() const { return Read<float>(uintptr_t(this) + 0x158); } // 0x158 (Size: 0x4, Type: FloatProperty)
    uint8_t __EnumProperty_1294() const { return Read<uint8_t>(uintptr_t(this) + 0x15c); } // 0x15c (Size: 0x1, Type: EnumProperty)
    TEnumAsByte<EAnimGroupRole> __ByteProperty_1295() const { return Read<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0x15d); } // 0x15d (Size: 0x1, Type: ByteProperty)
    FName __NameProperty_1296() const { return Read<FName>(uintptr_t(this) + 0x160); } // 0x160 (Size: 0x4, Type: NameProperty)
    FAnimNodeFunctionRef __StructProperty_1297() const { return Read<FAnimNodeFunctionRef>(uintptr_t(this) + 0x168); } // 0x168 (Size: 0x18, Type: StructProperty)
    UCurveFloat* __CurveFloat_1298() const { return Read<UCurveFloat*>(uintptr_t(this) + 0x180); } // 0x180 (Size: 0x8, Type: ObjectProperty)
    uint8_t __EnumProperty_1299() const { return Read<uint8_t>(uintptr_t(this) + 0x188); } // 0x188 (Size: 0x1, Type: EnumProperty)
    uint8_t __EnumProperty_1300() const { return Read<uint8_t>(uintptr_t(this) + 0x189); } // 0x189 (Size: 0x1, Type: EnumProperty)
    uint8_t __EnumProperty_1301() const { return Read<uint8_t>(uintptr_t(this) + 0x18a); } // 0x18a (Size: 0x1, Type: EnumProperty)
    TArray<float> __ArrayProperty_1302() const { return Read<TArray<float>>(uintptr_t(this) + 0x190); } // 0x190 (Size: 0x10, Type: ArrayProperty)
    bool __BoolProperty_1303() const { return Read<bool>(uintptr_t(this) + 0x1a0); } // 0x1a0 (Size: 0x1, Type: BoolProperty)
    UBlendProfile* __BlendProfile_1304() const { return Read<UBlendProfile*>(uintptr_t(this) + 0x1a8); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess() const { return Read<FAnimSubsystem_PropertyAccess>(uintptr_t(this) + 0x1b0); } // 0x1b0 (Size: 0x80, Type: StructProperty)
    FAnimSubsystem_Base AnimBlueprintExtension_Base() const { return Read<FAnimSubsystem_Base>(uintptr_t(this) + 0x230); } // 0x230 (Size: 0x40, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_Root() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x270); } // 0x270 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_38() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x2a0); } // 0x2a0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_37() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x2d0); } // 0x2d0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_36() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x300); } // 0x300 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_35() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_34() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_33() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_32() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x3c0); } // 0x3c0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_31() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x3f0); } // 0x3f0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_30() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x420); } // 0x420 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_29() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_41() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_40() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_26() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_39() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_25() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x570); } // 0x570 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_38() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x5a0); } // 0x5a0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_37() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_24() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x630); } // 0x630 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_36() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x660); } // 0x660 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_35() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x690); } // 0x690 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_34() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x6c0); } // 0x6c0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_33() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x6f0); } // 0x6f0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_32() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x720); } // 0x720 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_14() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_13() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x780); } // 0x780 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_12() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x7b0); } // 0x7b0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_11() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x7e0); } // 0x7e0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_31() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x810); } // 0x810 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_30() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x840); } // 0x840 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_29() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x870); } // 0x870 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x8a0); } // 0x8a0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_23() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x8d0); } // 0x8d0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x900); } // 0x900 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_28() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x930); } // 0x930 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_4() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x960); } // 0x960 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_22() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x990); } // 0x990 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_6() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x9c0); } // 0x9c0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x9f0); } // 0x9f0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xa20); } // 0xa20 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_10() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xa50); } // 0xa50 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xa80); } // 0xa80 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xab0); } // 0xab0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_5() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xae0); } // 0xae0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_4() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xb10); } // 0xb10 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xb40); } // 0xb40 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_27() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xb70); } // 0xb70 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xba0); } // 0xba0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_9() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xbd0); } // 0xbd0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_26() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xc00); } // 0xc00 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_8() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xc30); } // 0xc30 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_25() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xc60); } // 0xc60 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TwoWayBlend() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xc90); } // 0xc90 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xcc0); } // 0xcc0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_28() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xcf0); } // 0xcf0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_27() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xd20); } // 0xd20 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_26() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xd50); } // 0xd50 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_25() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xd80); } // 0xd80 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_24() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xdb0); } // 0xdb0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_23() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xde0); } // 0xde0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_22() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xe10); } // 0xe10 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_24() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xe40); } // 0xe40 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_21() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xe70); } // 0xe70 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_21() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xea0); } // 0xea0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_20() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xed0); } // 0xed0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_19() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xf00); } // 0xf00 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_18() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xf30); } // 0xf30 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_17() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xf60); } // 0xf60 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_16() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xf90); } // 0xf90 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_15() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xfc0); } // 0xfc0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xff0); } // 0xff0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_20() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1020); } // 0x1020 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_23() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1050); } // 0x1050 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_7() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1080); } // 0x1080 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_22() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x10b0); } // 0x10b0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_6() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x10e0); } // 0x10e0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_21() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1110); } // 0x1110 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_19() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1140); } // 0x1140 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_20() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1170); } // 0x1170 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_18() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x11a0); } // 0x11a0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_19() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x11d0); } // 0x11d0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_5() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1200); } // 0x1200 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_18() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1230); } // 0x1230 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_17() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1260); } // 0x1260 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_4() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1290); } // 0x1290 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_17() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x12c0); } // 0x12c0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_16() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x12f0); } // 0x12f0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1320); } // 0x1320 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_15() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1350); } // 0x1350 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1380); } // 0x1380 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_14() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x13b0); } // 0x13b0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_16() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x13e0); } // 0x13e0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_5() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1410); } // 0x1410 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_15() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1440); } // 0x1440 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1470); } // 0x1470 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_14() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x14a0); } // 0x14a0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_4() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x14d0); } // 0x14d0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_13() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1500); } // 0x1500 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_14() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1530); } // 0x1530 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_13() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_12() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_11() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x15c0); } // 0x15c0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_10() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x15f0); } // 0x15f0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_9() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1620); } // 0x1620 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_8() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1650); } // 0x1650 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_7() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1680); } // 0x1680 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_13() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x16b0); } // 0x16b0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_12() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x16e0); } // 0x16e0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_12() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1710); } // 0x1710 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_11() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1740); } // 0x1740 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_11() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1770); } // 0x1770 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_10() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x17a0); } // 0x17a0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_10() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x17d0); } // 0x17d0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_9() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1800); } // 0x1800 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1830); } // 0x1830 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_8() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1860); } // 0x1860 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1890); } // 0x1890 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_7() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x18c0); } // 0x18c0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x18f0); } // 0x18f0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_9() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1920); } // 0x1920 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_ApplyAdditive() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1950); } // 0x1950 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1980); } // 0x1980 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_8() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x19b0); } // 0x19b0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendSpacePlayer() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x19e0); } // 0x19e0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1a10); } // 0x1a10 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_6() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1a40); } // 0x1a40 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_5() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1a70); } // 0x1a70 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_4() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1aa0); } // 0x1aa0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_7() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1ad0); } // 0x1ad0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_6() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1b00); } // 0x1b00 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_6() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1b30); } // 0x1b30 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_5() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1b60); } // 0x1b60 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_5() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1b90); } // 0x1b90 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_4() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1bc0); } // 0x1bc0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1bf0); } // 0x1bf0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1c20); } // 0x1c20 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1c50); } // 0x1c50 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1c80); } // 0x1c80 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_TransitionResult() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1cb0); } // 0x1cb0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_UseCachedPose() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1ce0); } // 0x1ce0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1d10); } // 0x1d10 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_4() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1d40); } // 0x1d40 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1d70); } // 0x1d70 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_3() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1da0); } // 0x1da0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1dd0); } // 0x1dd0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_2() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1e00); } // 0x1e00 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer_1() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1e30); } // 0x1e30 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByEnum() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1e60); } // 0x1e60 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateResult() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1e90); } // 0x1e90 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_StateMachine() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1ec0); } // 0x1ec0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SaveCachedPose() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1ef0); } // 0x1ef0 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_SequencePlayer() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1f20); } // 0x1f20 (Size: 0x30, Type: StructProperty)
    FAnimNodeExposedValueHandler_PropertyAccess AnimGraphNode_BlendListByBool() const { return Read<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1f50); } // 0x1f50 (Size: 0x30, Type: StructProperty)

    void SET___NameProperty_1247(const FName& Value) { Write<FName>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1248(const FName& Value) { Write<FName>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: NameProperty)
    void SET___EnumProperty_1249(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x1, Type: EnumProperty)
    void SET___NameProperty_1250(const FName& Value) { Write<FName>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1251(const FName& Value) { Write<FName>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1252(const FName& Value) { Write<FName>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: NameProperty)
    void SET___ArrayProperty_1253(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
    void SET___EnumProperty_1254(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x1, Type: EnumProperty)
    void SET___ArrayProperty_1255(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x10, Type: ArrayProperty)
    void SET___ArrayProperty_1256(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x48, Value); } // 0x48 (Size: 0x10, Type: ArrayProperty)
    void SET___NameProperty_1257(const FName& Value) { Write<FName>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x4, Type: NameProperty)
    void SET___ArrayProperty_1258(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x60, Value); } // 0x60 (Size: 0x10, Type: ArrayProperty)
    void SET___NameProperty_1259(const FName& Value) { Write<FName>(uintptr_t(this) + 0x70, Value); } // 0x70 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1260(const FName& Value) { Write<FName>(uintptr_t(this) + 0x74, Value); } // 0x74 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1261(const FName& Value) { Write<FName>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x4, Type: NameProperty)
    void SET___FloatProperty_1262(const float& Value) { Write<float>(uintptr_t(this) + 0x7c, Value); } // 0x7c (Size: 0x4, Type: FloatProperty)
    void SET___NameProperty_1263(const FName& Value) { Write<FName>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x4, Type: NameProperty)
    void SET___ArrayProperty_1264(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x10, Type: ArrayProperty)
    void SET___NameProperty_1265(const FName& Value) { Write<FName>(uintptr_t(this) + 0x98, Value); } // 0x98 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1266(const FName& Value) { Write<FName>(uintptr_t(this) + 0x9c, Value); } // 0x9c (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1267(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1268(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa4, Value); } // 0xa4 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1269(const FName& Value) { Write<FName>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x4, Type: NameProperty)
    void SET___IntProperty_1270(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xac, Value); } // 0xac (Size: 0x4, Type: IntProperty)
    void SET___NameProperty_1271(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1272(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb4, Value); } // 0xb4 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1273(const FName& Value) { Write<FName>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1274(const FName& Value) { Write<FName>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1275(const FName& Value) { Write<FName>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: NameProperty)
    void SET___ArrayProperty_1276(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
    void SET___NameProperty_1277(const FName& Value) { Write<FName>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1278(const FName& Value) { Write<FName>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1279(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x4, Type: NameProperty)
    void SET___IntProperty_1280(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xe4, Value); } // 0xe4 (Size: 0x4, Type: IntProperty)
    void SET___NameProperty_1281(const FName& Value) { Write<FName>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x4, Type: NameProperty)
    void SET___IntProperty_1282(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xec, Value); } // 0xec (Size: 0x4, Type: IntProperty)
    void SET___NameProperty_1283(const FName& Value) { Write<FName>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x4, Type: NameProperty)
    void SET___IntProperty_1284(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xf4, Value); } // 0xf4 (Size: 0x4, Type: IntProperty)
    void SET___ArrayProperty_1285(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x10, Type: ArrayProperty)
    void SET___ArrayProperty_1286(const TArray<int32_t>& Value) { Write<TArray<int32_t>>(uintptr_t(this) + 0x108, Value); } // 0x108 (Size: 0x10, Type: ArrayProperty)
    void SET___NameProperty_1287(const FName& Value) { Write<FName>(uintptr_t(this) + 0x118, Value); } // 0x118 (Size: 0x4, Type: NameProperty)
    void SET___NameProperty_1288(const FName& Value) { Write<FName>(uintptr_t(this) + 0x11c, Value); } // 0x11c (Size: 0x4, Type: NameProperty)
    void SET___IntProperty_1289(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x120, Value); } // 0x120 (Size: 0x4, Type: IntProperty)
    void SET___BoolProperty_1290(const bool& Value) { Write<bool>(uintptr_t(this) + 0x124, Value); } // 0x124 (Size: 0x1, Type: BoolProperty)
    void SET___FloatProperty_1291(const float& Value) { Write<float>(uintptr_t(this) + 0x128, Value); } // 0x128 (Size: 0x4, Type: FloatProperty)
    void SET___StructProperty_1292(const FInputScaleBiasClampConstants& Value) { Write<FInputScaleBiasClampConstants>(uintptr_t(this) + 0x12c, Value); } // 0x12c (Size: 0x2c, Type: StructProperty)
    void SET___FloatProperty_1293(const float& Value) { Write<float>(uintptr_t(this) + 0x158, Value); } // 0x158 (Size: 0x4, Type: FloatProperty)
    void SET___EnumProperty_1294(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x15c, Value); } // 0x15c (Size: 0x1, Type: EnumProperty)
    void SET___ByteProperty_1295(const TEnumAsByte<EAnimGroupRole>& Value) { Write<TEnumAsByte<EAnimGroupRole>>(uintptr_t(this) + 0x15d, Value); } // 0x15d (Size: 0x1, Type: ByteProperty)
    void SET___NameProperty_1296(const FName& Value) { Write<FName>(uintptr_t(this) + 0x160, Value); } // 0x160 (Size: 0x4, Type: NameProperty)
    void SET___StructProperty_1297(const FAnimNodeFunctionRef& Value) { Write<FAnimNodeFunctionRef>(uintptr_t(this) + 0x168, Value); } // 0x168 (Size: 0x18, Type: StructProperty)
    void SET___CurveFloat_1298(const UCurveFloat*& Value) { Write<UCurveFloat*>(uintptr_t(this) + 0x180, Value); } // 0x180 (Size: 0x8, Type: ObjectProperty)
    void SET___EnumProperty_1299(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x188, Value); } // 0x188 (Size: 0x1, Type: EnumProperty)
    void SET___EnumProperty_1300(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x189, Value); } // 0x189 (Size: 0x1, Type: EnumProperty)
    void SET___EnumProperty_1301(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x18a, Value); } // 0x18a (Size: 0x1, Type: EnumProperty)
    void SET___ArrayProperty_1302(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x190, Value); } // 0x190 (Size: 0x10, Type: ArrayProperty)
    void SET___BoolProperty_1303(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a0, Value); } // 0x1a0 (Size: 0x1, Type: BoolProperty)
    void SET___BlendProfile_1304(const UBlendProfile*& Value) { Write<UBlendProfile*>(uintptr_t(this) + 0x1a8, Value); } // 0x1a8 (Size: 0x8, Type: ObjectProperty)
    void SET_AnimBlueprintExtension_PropertyAccess(const FAnimSubsystem_PropertyAccess& Value) { Write<FAnimSubsystem_PropertyAccess>(uintptr_t(this) + 0x1b0, Value); } // 0x1b0 (Size: 0x80, Type: StructProperty)
    void SET_AnimBlueprintExtension_Base(const FAnimSubsystem_Base& Value) { Write<FAnimSubsystem_Base>(uintptr_t(this) + 0x230, Value); } // 0x230 (Size: 0x40, Type: StructProperty)
    void SET_AnimGraphNode_Root(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x270, Value); } // 0x270 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_38(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x2a0, Value); } // 0x2a0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_37(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x2d0, Value); } // 0x2d0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_36(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x300, Value); } // 0x300 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_35(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_34(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_33(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_32(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x3c0, Value); } // 0x3c0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_31(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x3f0, Value); } // 0x3f0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_30(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x420, Value); } // 0x420 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_29(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_41(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_40(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByEnum_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_26(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_39(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_25(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x570, Value); } // 0x570 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_38(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x5a0, Value); } // 0x5a0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByEnum_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_37(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_24(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x630, Value); } // 0x630 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_36(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x660, Value); } // 0x660 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_35(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x690, Value); } // 0x690 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_34(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x6c0, Value); } // 0x6c0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_33(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x6f0, Value); } // 0x6f0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_32(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x720, Value); } // 0x720 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_14(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_13(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x780, Value); } // 0x780 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_12(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x7b0, Value); } // 0x7b0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_11(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x7e0, Value); } // 0x7e0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_31(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x810, Value); } // 0x810 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_30(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x840, Value); } // 0x840 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_29(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x870, Value); } // 0x870 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByEnum_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x8a0, Value); } // 0x8a0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_23(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x8d0, Value); } // 0x8d0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x900, Value); } // 0x900 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_28(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x930, Value); } // 0x930 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive_4(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x960, Value); } // 0x960 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_22(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x990, Value); } // 0x990 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine_6(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x9c0, Value); } // 0x9c0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x9f0, Value); } // 0x9f0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xa20, Value); } // 0xa20 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_10(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xa50, Value); } // 0xa50 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SaveCachedPose_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xa80, Value); } // 0xa80 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xab0, Value); } // 0xab0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_5(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xae0, Value); } // 0xae0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_4(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xb10, Value); } // 0xb10 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xb40, Value); } // 0xb40 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_27(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xb70, Value); } // 0xb70 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xba0, Value); } // 0xba0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_9(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xbd0, Value); } // 0xbd0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_26(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xc00, Value); } // 0xc00 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_8(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xc30, Value); } // 0xc30 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_25(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xc60, Value); } // 0xc60 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TwoWayBlend(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xc90, Value); } // 0xc90 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SaveCachedPose_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xcc0, Value); } // 0xcc0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_28(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xcf0, Value); } // 0xcf0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_27(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xd20, Value); } // 0xd20 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_26(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xd50, Value); } // 0xd50 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_25(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xd80, Value); } // 0xd80 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_24(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xdb0, Value); } // 0xdb0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_23(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xde0, Value); } // 0xde0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_22(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xe10, Value); } // 0xe10 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_24(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xe40, Value); } // 0xe40 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_21(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xe70, Value); } // 0xe70 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_21(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xea0, Value); } // 0xea0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_20(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xed0, Value); } // 0xed0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_19(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xf00, Value); } // 0xf00 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_18(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xf30, Value); } // 0xf30 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_17(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xf60, Value); } // 0xf60 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_16(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xf90, Value); } // 0xf90 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_15(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xfc0, Value); } // 0xfc0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0xff0, Value); } // 0xff0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_20(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1020, Value); } // 0x1020 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_23(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1050, Value); } // 0x1050 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_7(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1080, Value); } // 0x1080 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_22(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x10b0, Value); } // 0x10b0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_6(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x10e0, Value); } // 0x10e0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_21(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1110, Value); } // 0x1110 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_19(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1140, Value); } // 0x1140 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_20(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1170, Value); } // 0x1170 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_18(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x11a0, Value); } // 0x11a0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_19(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x11d0, Value); } // 0x11d0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_5(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1200, Value); } // 0x1200 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_18(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1230, Value); } // 0x1230 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_17(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1260, Value); } // 0x1260 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_4(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1290, Value); } // 0x1290 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_17(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x12c0, Value); } // 0x12c0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_16(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x12f0, Value); } // 0x12f0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1320, Value); } // 0x1320 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_15(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1350, Value); } // 0x1350 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1380, Value); } // 0x1380 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_14(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x13b0, Value); } // 0x13b0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_16(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x13e0, Value); } // 0x13e0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine_5(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1410, Value); } // 0x1410 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_15(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1440, Value); } // 0x1440 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1470, Value); } // 0x1470 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_14(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x14a0, Value); } // 0x14a0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine_4(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x14d0, Value); } // 0x14d0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_13(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1500, Value); } // 0x1500 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_14(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1530, Value); } // 0x1530 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_13(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_12(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_11(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x15c0, Value); } // 0x15c0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_10(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x15f0, Value); } // 0x15f0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_9(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1620, Value); } // 0x1620 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_8(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1650, Value); } // 0x1650 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_7(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1680, Value); } // 0x1680 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_13(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x16b0, Value); } // 0x16b0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_12(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x16e0, Value); } // 0x16e0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_12(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1710, Value); } // 0x1710 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_11(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1740, Value); } // 0x1740 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_11(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1770, Value); } // 0x1770 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_10(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x17a0, Value); } // 0x17a0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_10(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x17d0, Value); } // 0x17d0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_9(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1800, Value); } // 0x1800 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1830, Value); } // 0x1830 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_8(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1860, Value); } // 0x1860 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1890, Value); } // 0x1890 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_7(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x18c0, Value); } // 0x18c0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x18f0, Value); } // 0x18f0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_9(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1920, Value); } // 0x1920 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_ApplyAdditive(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1950, Value); } // 0x1950 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1980, Value); } // 0x1980 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_8(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x19b0, Value); } // 0x19b0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendSpacePlayer(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x19e0, Value); } // 0x19e0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SaveCachedPose_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1a10, Value); } // 0x1a10 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_6(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1a40, Value); } // 0x1a40 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_5(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1a70, Value); } // 0x1a70 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_4(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1aa0, Value); } // 0x1aa0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_7(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1ad0, Value); } // 0x1ad0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_6(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1b00, Value); } // 0x1b00 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_6(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1b30, Value); } // 0x1b30 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_5(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1b60, Value); } // 0x1b60 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_5(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1b90, Value); } // 0x1b90 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_4(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1bc0, Value); } // 0x1bc0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1bf0, Value); } // 0x1bf0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1c20, Value); } // 0x1c20 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1c50, Value); } // 0x1c50 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1c80, Value); } // 0x1c80 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_TransitionResult(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1cb0, Value); } // 0x1cb0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_UseCachedPose(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1ce0, Value); } // 0x1ce0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1d10, Value); } // 0x1d10 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_4(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1d40, Value); } // 0x1d40 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1d70, Value); } // 0x1d70 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_3(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1da0, Value); } // 0x1da0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1dd0, Value); } // 0x1dd0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_2(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1e00, Value); } // 0x1e00 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer_1(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1e30, Value); } // 0x1e30 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByEnum(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1e60, Value); } // 0x1e60 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateResult(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1e90, Value); } // 0x1e90 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_StateMachine(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1ec0, Value); } // 0x1ec0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SaveCachedPose(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1ef0, Value); } // 0x1ef0 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_SequencePlayer(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1f20, Value); } // 0x1f20 (Size: 0x30, Type: StructProperty)
    void SET_AnimGraphNode_BlendListByBool(const FAnimNodeExposedValueHandler_PropertyAccess& Value) { Write<FAnimNodeExposedValueHandler_PropertyAccess>(uintptr_t(this) + 0x1f50, Value); } // 0x1f50 (Size: 0x30, Type: StructProperty)
};

// Size: 0x2a
struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
public:
    char __ByteProperty() const { return Read<char>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: ByteProperty)
    char __ByteProperty_0() const { return Read<char>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: ByteProperty)
    bool __BoolProperty_1() const { return Read<bool>(uintptr_t(this) + 0x3); } // 0x3 (Size: 0x1, Type: BoolProperty)
    bool __BoolProperty_2() const { return Read<bool>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x1, Type: BoolProperty)
    bool __BoolProperty_3() const { return Read<bool>(uintptr_t(this) + 0x5); } // 0x5 (Size: 0x1, Type: BoolProperty)
    bool __BoolProperty_4() const { return Read<bool>(uintptr_t(this) + 0x6); } // 0x6 (Size: 0x1, Type: BoolProperty)
    char __ByteProperty_5() const { return Read<char>(uintptr_t(this) + 0x7); } // 0x7 (Size: 0x1, Type: ByteProperty)
    float __FloatProperty_6() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float __FloatProperty_7() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool __BoolProperty_8() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float __FloatProperty_9() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    bool __BoolProperty_10() const { return Read<bool>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x1, Type: BoolProperty)
    bool __BoolProperty_11() const { return Read<bool>(uintptr_t(this) + 0x19); } // 0x19 (Size: 0x1, Type: BoolProperty)
    bool __BoolProperty_12() const { return Read<bool>(uintptr_t(this) + 0x1a); } // 0x1a (Size: 0x1, Type: BoolProperty)
    bool __BoolProperty_13() const { return Read<bool>(uintptr_t(this) + 0x1b); } // 0x1b (Size: 0x1, Type: BoolProperty)
    bool __BoolProperty_14() const { return Read<bool>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x1, Type: BoolProperty)
    bool __BoolProperty_15() const { return Read<bool>(uintptr_t(this) + 0x1d); } // 0x1d (Size: 0x1, Type: BoolProperty)
    bool __BoolProperty_16() const { return Read<bool>(uintptr_t(this) + 0x1e); } // 0x1e (Size: 0x1, Type: BoolProperty)
    bool __BoolProperty_17() const { return Read<bool>(uintptr_t(this) + 0x1f); } // 0x1f (Size: 0x1, Type: BoolProperty)
    bool __BoolProperty_18() const { return Read<bool>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: BoolProperty)
    float __FloatProperty_19() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    char __ByteProperty_20() const { return Read<char>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: ByteProperty)
    bool __BoolProperty_21() const { return Read<bool>(uintptr_t(this) + 0x29); } // 0x29 (Size: 0x1, Type: BoolProperty)

    void SET___ByteProperty(const char& Value) { Write<char>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: ByteProperty)
    void SET___ByteProperty_0(const char& Value) { Write<char>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: ByteProperty)
    void SET___BoolProperty_1(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3, Value); } // 0x3 (Size: 0x1, Type: BoolProperty)
    void SET___BoolProperty_2(const bool& Value) { Write<bool>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x1, Type: BoolProperty)
    void SET___BoolProperty_3(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5, Value); } // 0x5 (Size: 0x1, Type: BoolProperty)
    void SET___BoolProperty_4(const bool& Value) { Write<bool>(uintptr_t(this) + 0x6, Value); } // 0x6 (Size: 0x1, Type: BoolProperty)
    void SET___ByteProperty_5(const char& Value) { Write<char>(uintptr_t(this) + 0x7, Value); } // 0x7 (Size: 0x1, Type: ByteProperty)
    void SET___FloatProperty_6(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET___FloatProperty_7(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET___BoolProperty_8(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET___FloatProperty_9(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET___BoolProperty_10(const bool& Value) { Write<bool>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x1, Type: BoolProperty)
    void SET___BoolProperty_11(const bool& Value) { Write<bool>(uintptr_t(this) + 0x19, Value); } // 0x19 (Size: 0x1, Type: BoolProperty)
    void SET___BoolProperty_12(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1a, Value); } // 0x1a (Size: 0x1, Type: BoolProperty)
    void SET___BoolProperty_13(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1b, Value); } // 0x1b (Size: 0x1, Type: BoolProperty)
    void SET___BoolProperty_14(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x1, Type: BoolProperty)
    void SET___BoolProperty_15(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1d, Value); } // 0x1d (Size: 0x1, Type: BoolProperty)
    void SET___BoolProperty_16(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1e, Value); } // 0x1e (Size: 0x1, Type: BoolProperty)
    void SET___BoolProperty_17(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1f, Value); } // 0x1f (Size: 0x1, Type: BoolProperty)
    void SET___BoolProperty_18(const bool& Value) { Write<bool>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: BoolProperty)
    void SET___FloatProperty_19(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET___ByteProperty_20(const char& Value) { Write<char>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: ByteProperty)
    void SET___BoolProperty_21(const bool& Value) { Write<bool>(uintptr_t(this) + 0x29, Value); } // 0x29 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x360
class UAthenaTemperature_C : public UAthenaTemperatureBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: StructProperty)
};

// Size: 0x3a0
class UAthenaGenericLobbyViolator_C : public UAthenaMatchmakingViolator
{
public:
};

// Size: 0x528
class UWBP_ExpressYourSupportOnboardingTooltipRight_C : public UFortSidebarOnboardTooltipWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    USizeBox* SizeBox_Mobile() const { return Read<USizeBox*>(uintptr_t(this) + 0x4e8); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    UScaleBox* ScaleBox_Mobile() const { return Read<UScaleBox*>(uintptr_t(this) + 0x4f0); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    UImage* ImageBurst() const { return Read<UImage*>(uintptr_t(this) + 0x4f8); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Arrow() const { return Read<UImage*>(uintptr_t(this) + 0x500); } // 0x500 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* CommonRichTextBlock_140() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x508); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* CommonRichTextBlock_106() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x510); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Pulse() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Outro() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x520); } // 0x520 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x4e0, Value); } // 0x4e0 (Size: 0x8, Type: StructProperty)
    void SET_SizeBox_Mobile(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x4e8, Value); } // 0x4e8 (Size: 0x8, Type: ObjectProperty)
    void SET_ScaleBox_Mobile(const UScaleBox*& Value) { Write<UScaleBox*>(uintptr_t(this) + 0x4f0, Value); } // 0x4f0 (Size: 0x8, Type: ObjectProperty)
    void SET_ImageBurst(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4f8, Value); } // 0x4f8 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Arrow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x500, Value); } // 0x500 (Size: 0x8, Type: ObjectProperty)
    void SET_CommonRichTextBlock_140(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x508, Value); } // 0x508 (Size: 0x8, Type: ObjectProperty)
    void SET_CommonRichTextBlock_106(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x510, Value); } // 0x510 (Size: 0x8, Type: ObjectProperty)
    void SET_Pulse(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: ObjectProperty)
    void SET_Outro(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x520, Value); } // 0x520 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x15c0
class UAthenaMatchmakingPlayButton_C : public UAthenaMatchmakingPlayButtonBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x8, Type: StructProperty)
    UMatchmakingInputIndicator_C* MatchmakingInputIndicator() const { return Read<UMatchmakingInputIndicator_C*>(uintptr_t(this) + 0x1588); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Shadow() const { return Read<UImage*>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_ButtonTop() const { return Read<UImage*>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* CenterButtonTextWidget() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* OnHovered() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15a8); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* PlayShine() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15b0); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Disabled() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15b8); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x8, Type: StructProperty)
    void SET_MatchmakingInputIndicator(const UMatchmakingInputIndicator_C*& Value) { Write<UMatchmakingInputIndicator_C*>(uintptr_t(this) + 0x1588, Value); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Shadow(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_ButtonTop(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    void SET_CenterButtonTextWidget(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    void SET_OnHovered(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15a8, Value); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    void SET_PlayShine(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15b0, Value); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Disabled(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15b8, Value); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x15e9
class UGenericModalButton_C : public UCommonButtonLegacy
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x8, Type: StructProperty)
    USizeBox* SizeBox_Height() const { return Read<USizeBox*>(uintptr_t(this) + 0x1568); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* Rich_Text() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x8, Type: ObjectProperty)
    UOverlay* Overlay_Right_Image() const { return Read<UOverlay*>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_45() const { return Read<UImage*>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    UImage* Image() const { return Read<UImage*>(uintptr_t(this) + 0x1588); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    UBorder* Border_Material() const { return Read<UBorder*>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Hover() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* Hover2() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    FText Button_Text() const { return Read<FText>(uintptr_t(this) + 0x15a8); } // 0x15a8 (Size: 0x10, Type: TextProperty)
    FSlateColor Text_Color() const { return Read<FSlateColor>(uintptr_t(this) + 0x15b8); } // 0x15b8 (Size: 0x14, Type: StructProperty)
    UMaterialInterface* Material_Brush() const { return Read<UMaterialInterface*>(uintptr_t(this) + 0x15d0); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)
    UTexture2D* Right_Image() const { return Read<UTexture2D*>(uintptr_t(this) + 0x15d8); } // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<ETextJustify> Justifiction() const { return Read<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x15e0); } // 0x15e0 (Size: 0x1, Type: ByteProperty)
    bool Auto_wrap_text() const { return Read<bool>(uintptr_t(this) + 0x15e1); } // 0x15e1 (Size: 0x1, Type: BoolProperty)
    bool SimpleHover() const { return Read<bool>(uintptr_t(this) + 0x15e2); } // 0x15e2 (Size: 0x1, Type: BoolProperty)
    bool FontSizeOverride() const { return Read<bool>(uintptr_t(this) + 0x15e3); } // 0x15e3 (Size: 0x1, Type: BoolProperty)
    int32_t FontSize() const { return Read<int32_t>(uintptr_t(this) + 0x15e4); } // 0x15e4 (Size: 0x4, Type: IntProperty)
    bool ShearText() const { return Read<bool>(uintptr_t(this) + 0x15e8); } // 0x15e8 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x8, Type: StructProperty)
    void SET_SizeBox_Height(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x1568, Value); } // 0x1568 (Size: 0x8, Type: ObjectProperty)
    void SET_Rich_Text(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x8, Type: ObjectProperty)
    void SET_Overlay_Right_Image(const UOverlay*& Value) { Write<UOverlay*>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_45(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    void SET_Image(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1588, Value); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    void SET_Border_Material(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    void SET_Hover(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    void SET_Hover2(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Text(const FText& Value) { Write<FText>(uintptr_t(this) + 0x15a8, Value); } // 0x15a8 (Size: 0x10, Type: TextProperty)
    void SET_Text_Color(const FSlateColor& Value) { Write<FSlateColor>(uintptr_t(this) + 0x15b8, Value); } // 0x15b8 (Size: 0x14, Type: StructProperty)
    void SET_Material_Brush(const UMaterialInterface*& Value) { Write<UMaterialInterface*>(uintptr_t(this) + 0x15d0, Value); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)
    void SET_Right_Image(const UTexture2D*& Value) { Write<UTexture2D*>(uintptr_t(this) + 0x15d8, Value); } // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    void SET_Justifiction(const TEnumAsByte<ETextJustify>& Value) { Write<TEnumAsByte<ETextJustify>>(uintptr_t(this) + 0x15e0, Value); } // 0x15e0 (Size: 0x1, Type: ByteProperty)
    void SET_Auto_wrap_text(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15e1, Value); } // 0x15e1 (Size: 0x1, Type: BoolProperty)
    void SET_SimpleHover(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15e2, Value); } // 0x15e2 (Size: 0x1, Type: BoolProperty)
    void SET_FontSizeOverride(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15e3, Value); } // 0x15e3 (Size: 0x1, Type: BoolProperty)
    void SET_FontSize(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x15e4, Value); } // 0x15e4 (Size: 0x4, Type: IntProperty)
    void SET_ShearText(const bool& Value) { Write<bool>(uintptr_t(this) + 0x15e8, Value); } // 0x15e8 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x15f0
class UWBP_ExpressYourSupportThumbsUpButtonRight_C : public UFortExpressYourSupportThumbsUpButton
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x8, Type: StructProperty)
    UWidgetSwitcher* TextSwitcher() const { return Read<UWidgetSwitcher*>(uintptr_t(this) + 0x1588); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    USizeBox* SizeBox_0() const { return Read<USizeBox*>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Pulse() const { return Read<UImage*>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_FavoriteIcon() const { return Read<UImage*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    UBorder* Border_Background() const { return Read<UBorder*>(uintptr_t(this) + 0x15a8); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* HoveredToggleOn() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15b0); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* HoveredToggleOff() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15b8); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* HoverToggledOn() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15c0); } // 0x15c0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* UnhoverToggledOn() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15c8); } // 0x15c8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* HoverToggledOff() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15d0); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* UnhoverToggledOff() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15d8); } // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* UnhoveredToggleOn() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15e0); } // 0x15e0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* UnhoveredToggleOff() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15e8); } // 0x15e8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x8, Type: StructProperty)
    void SET_TextSwitcher(const UWidgetSwitcher*& Value) { Write<UWidgetSwitcher*>(uintptr_t(this) + 0x1588, Value); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    void SET_SizeBox_0(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Pulse(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_FavoriteIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Border_Background(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x15a8, Value); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    void SET_HoveredToggleOn(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15b0, Value); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    void SET_HoveredToggleOff(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15b8, Value); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
    void SET_HoverToggledOn(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15c0, Value); } // 0x15c0 (Size: 0x8, Type: ObjectProperty)
    void SET_UnhoverToggledOn(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15c8, Value); } // 0x15c8 (Size: 0x8, Type: ObjectProperty)
    void SET_HoverToggledOff(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15d0, Value); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)
    void SET_UnhoverToggledOff(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15d8, Value); } // 0x15d8 (Size: 0x8, Type: ObjectProperty)
    void SET_UnhoveredToggleOn(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15e0, Value); } // 0x15e0 (Size: 0x8, Type: ObjectProperty)
    void SET_UnhoveredToggleOff(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15e8, Value); } // 0x15e8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x398
class UWBP_ExpressYourSupportRow_C : public UFortExpressYourSupportRow
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: StructProperty)
    UWBP_Sidebar_ExpressYourSupport_CoachMark_C* WBP_Sidebar_ExpressYourSupport_CoachMark() const { return Read<UWBP_Sidebar_ExpressYourSupport_CoachMark_C*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    UWBP_ExpressYourSupportButton_C* Button_Recommend() const { return Read<UWBP_ExpressYourSupportButton_C*>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    UWBP_ExpressYourSupportButton_C* Button_NotInterested() const { return Read<UWBP_ExpressYourSupportButton_C*>(uintptr_t(this) + 0x388); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    UWBP_ExpressYourSupportButton_C* Button_Favorite() const { return Read<UWBP_ExpressYourSupportButton_C*>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: StructProperty)
    void SET_WBP_Sidebar_ExpressYourSupport_CoachMark(const UWBP_Sidebar_ExpressYourSupport_CoachMark_C*& Value) { Write<UWBP_Sidebar_ExpressYourSupport_CoachMark_C*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Recommend(const UWBP_ExpressYourSupportButton_C*& Value) { Write<UWBP_ExpressYourSupportButton_C*>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_NotInterested(const UWBP_ExpressYourSupportButton_C*& Value) { Write<UWBP_ExpressYourSupportButton_C*>(uintptr_t(this) + 0x388, Value); } // 0x388 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Favorite(const UWBP_ExpressYourSupportButton_C*& Value) { Write<UWBP_ExpressYourSupportButton_C*>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x1592
class UWBP_ExpressYourSupportButton_C : public UCommonButtonBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1510); } // 0x1510 (Size: 0x8, Type: StructProperty)
    UImage* Image_Pulse() const { return Read<UImage*>(uintptr_t(this) + 0x1518); } // 0x1518 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Icon() const { return Read<UImage*>(uintptr_t(this) + 0x1520); } // 0x1520 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* ButtonText() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x1528); } // 0x1528 (Size: 0x8, Type: ObjectProperty)
    UImage* Background() const { return Read<UImage*>(uintptr_t(this) + 0x1530); } // 0x1530 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* HoveringSelected() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1538); } // 0x1538 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* HoveringDeselected() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1540); } // 0x1540 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* HoveredSelecting() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1548); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* SelectedPulse() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1550); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* DeselectedPulse() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1558); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    FText Text() const { return Read<FText>(uintptr_t(this) + 0x1560); } // 0x1560 (Size: 0x10, Type: TextProperty)
    FVector2D Icon_Size() const { return Read<FVector2D>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x10, Type: StructProperty)
    UMaterialInstance* Icon() const { return Read<UMaterialInstance*>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    UMaterialInstance* PulseIcon() const { return Read<UMaterialInstance*>(uintptr_t(this) + 0x1588); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    bool IsIconsInverted() const { return Read<bool>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x1, Type: BoolProperty)
    bool IsInitiallySelected() const { return Read<bool>(uintptr_t(this) + 0x1591); } // 0x1591 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1510, Value); } // 0x1510 (Size: 0x8, Type: StructProperty)
    void SET_Image_Pulse(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1518, Value); } // 0x1518 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Icon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1520, Value); } // 0x1520 (Size: 0x8, Type: ObjectProperty)
    void SET_ButtonText(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x1528, Value); } // 0x1528 (Size: 0x8, Type: ObjectProperty)
    void SET_Background(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1530, Value); } // 0x1530 (Size: 0x8, Type: ObjectProperty)
    void SET_HoveringSelected(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1538, Value); } // 0x1538 (Size: 0x8, Type: ObjectProperty)
    void SET_HoveringDeselected(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1540, Value); } // 0x1540 (Size: 0x8, Type: ObjectProperty)
    void SET_HoveredSelecting(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1548, Value); } // 0x1548 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectedPulse(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1550, Value); } // 0x1550 (Size: 0x8, Type: ObjectProperty)
    void SET_DeselectedPulse(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1558, Value); } // 0x1558 (Size: 0x8, Type: ObjectProperty)
    void SET_Text(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1560, Value); } // 0x1560 (Size: 0x10, Type: TextProperty)
    void SET_Icon_Size(const FVector2D& Value) { Write<FVector2D>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x10, Type: StructProperty)
    void SET_Icon(const UMaterialInstance*& Value) { Write<UMaterialInstance*>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    void SET_PulseIcon(const UMaterialInstance*& Value) { Write<UMaterialInstance*>(uintptr_t(this) + 0x1588, Value); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    void SET_IsIconsInverted(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x1, Type: BoolProperty)
    void SET_IsInitiallySelected(const bool& Value) { Write<bool>(uintptr_t(this) + 0x1591, Value); } // 0x1591 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x15d8
class UWBP_ExpressYourSupportFavoriteButton_C : public UFortExpressYourSupportFavoriteButton
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1570); } // 0x1570 (Size: 0x8, Type: StructProperty)
    USizeBox* SizeBox_0() const { return Read<USizeBox*>(uintptr_t(this) + 0x1578); } // 0x1578 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_Pulse() const { return Read<UImage*>(uintptr_t(this) + 0x1580); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_FavoriteIcon() const { return Read<UImage*>(uintptr_t(this) + 0x1588); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    UBorder* Border_Background() const { return Read<UBorder*>(uintptr_t(this) + 0x1590); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* HoveredToggleOn() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x1598); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* HoveredToggleOff() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15a0); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* HoverToggledOn() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15a8); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* UnhoverToggledOn() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15b0); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* HoverToggledOff() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15b8); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* UnhoverToggledOff() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15c0); } // 0x15c0 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* UnhoveredToggleOn() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15c8); } // 0x15c8 (Size: 0x8, Type: ObjectProperty)
    UWidgetAnimation* UnhoveredToggleOff() const { return Read<UWidgetAnimation*>(uintptr_t(this) + 0x15d0); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1570, Value); } // 0x1570 (Size: 0x8, Type: StructProperty)
    void SET_SizeBox_0(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x1578, Value); } // 0x1578 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_Pulse(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1580, Value); } // 0x1580 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_FavoriteIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x1588, Value); } // 0x1588 (Size: 0x8, Type: ObjectProperty)
    void SET_Border_Background(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x1590, Value); } // 0x1590 (Size: 0x8, Type: ObjectProperty)
    void SET_HoveredToggleOn(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x1598, Value); } // 0x1598 (Size: 0x8, Type: ObjectProperty)
    void SET_HoveredToggleOff(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15a0, Value); } // 0x15a0 (Size: 0x8, Type: ObjectProperty)
    void SET_HoverToggledOn(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15a8, Value); } // 0x15a8 (Size: 0x8, Type: ObjectProperty)
    void SET_UnhoverToggledOn(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15b0, Value); } // 0x15b0 (Size: 0x8, Type: ObjectProperty)
    void SET_HoverToggledOff(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15b8, Value); } // 0x15b8 (Size: 0x8, Type: ObjectProperty)
    void SET_UnhoverToggledOff(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15c0, Value); } // 0x15c0 (Size: 0x8, Type: ObjectProperty)
    void SET_UnhoveredToggleOn(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15c8, Value); } // 0x15c8 (Size: 0x8, Type: ObjectProperty)
    void SET_UnhoveredToggleOff(const UWidgetAnimation*& Value) { Write<UWidgetAnimation*>(uintptr_t(this) + 0x15d0, Value); } // 0x15d0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x338
class UMatchmakingRegionAndPool_C : public UMatchmakingRegionAndPoolBase
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    USizeBox* SizeBox_Mobile() const { return Read<USizeBox*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* RegionText() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_SizeBox_Mobile(const USizeBox*& Value) { Write<USizeBox*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_RegionText(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x350
class UGenericModalEntry_C : public UUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320); } // 0x320 (Size: 0x8, Type: StructProperty)
    UImage* PIP() const { return Read<UImage*>(uintptr_t(this) + 0x328); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    UHorizontalBox* HorizontalBox_14() const { return Read<UHorizontalBox*>(uintptr_t(this) + 0x330); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    UCommonRichTextBlock* Description() const { return Read<UCommonRichTextBlock*>(uintptr_t(this) + 0x338); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    FText Text() const { return Read<FText>(uintptr_t(this) + 0x340); } // 0x340 (Size: 0x10, Type: TextProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x320, Value); } // 0x320 (Size: 0x8, Type: StructProperty)
    void SET_PIP(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x328, Value); } // 0x328 (Size: 0x8, Type: ObjectProperty)
    void SET_HorizontalBox_14(const UHorizontalBox*& Value) { Write<UHorizontalBox*>(uintptr_t(this) + 0x330, Value); } // 0x330 (Size: 0x8, Type: ObjectProperty)
    void SET_Description(const UCommonRichTextBlock*& Value) { Write<UCommonRichTextBlock*>(uintptr_t(this) + 0x338, Value); } // 0x338 (Size: 0x8, Type: ObjectProperty)
    void SET_Text(const FText& Value) { Write<FText>(uintptr_t(this) + 0x340, Value); } // 0x340 (Size: 0x10, Type: TextProperty)
};

// Size: 0x390
class UAthenaRewardItemTypeRarityTag_C : public UAthenaRewardItemTypeRarityTag
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x370); } // 0x370 (Size: 0x8, Type: StructProperty)
    UBorder* Border_ItemType() const { return Read<UBorder*>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    FLinearColor ItemTypeTextColor() const { return Read<FLinearColor>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x10, Type: StructProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x370, Value); } // 0x370 (Size: 0x8, Type: StructProperty)
    void SET_Border_ItemType(const UBorder*& Value) { Write<UBorder*>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x8, Type: ObjectProperty)
    void SET_ItemTypeTextColor(const FLinearColor& Value) { Write<FLinearColor>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x10, Type: StructProperty)
};

// Size: 0x320
class ULocalizedCountdownDisplay_C : public UUserWidget
{
public:
};

// Size: 0x40
class UMobileHUDPresets_C : public UFortMobileHUDPresetContainer
{
public:
};

// Size: 0x40
class UMobileHUDPresetsInDevelopment_C : public UFortMobileHUDPresetContainer
{
public:
};

