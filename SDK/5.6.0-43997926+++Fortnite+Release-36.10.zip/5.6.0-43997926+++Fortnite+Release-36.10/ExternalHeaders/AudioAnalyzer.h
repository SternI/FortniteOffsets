/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioAnalyzer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x28
class UAudioAnalyzerAssetBase : public UObject
{
public:
};

// Size: 0x28
class UAudioAnalyzerSettings : public UAudioAnalyzerAssetBase
{
public:
};

// Size: 0xa0
class UAudioAnalyzer : public UObject
{
public:
    UAudioBus* AudioBus() const { return Read<UAudioBus*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    UAudioAnalyzerSubsystem* AudioAnalyzerSubsystem() const { return Read<UAudioAnalyzerSubsystem*>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x8, Type: ObjectProperty)

    void SET_AudioBus(const UAudioBus*& Value) { Write<UAudioBus*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioAnalyzerSubsystem(const UAudioAnalyzerSubsystem*& Value) { Write<UAudioAnalyzerSubsystem*>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x28
class UAudioAnalyzerNRTSettings : public UAudioAnalyzerAssetBase
{
public:
};

// Size: 0x78
class UAudioAnalyzerNRT : public UAudioAnalyzerAssetBase
{
public:
    USoundWave* Sound() const { return Read<USoundWave*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    float DurationInSeconds() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)

    void SET_Sound(const USoundWave*& Value) { Write<USoundWave*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_DurationInSeconds(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x50
class UAudioAnalyzerSubsystem : public UEngineSubsystem
{
public:
    TArray<UAudioAnalyzer*> AudioAnalyzers() const { return Read<TArray<UAudioAnalyzer*>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)

    void SET_AudioAnalyzers(const TArray<UAudioAnalyzer*>& Value) { Write<TArray<UAudioAnalyzer*>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
};

