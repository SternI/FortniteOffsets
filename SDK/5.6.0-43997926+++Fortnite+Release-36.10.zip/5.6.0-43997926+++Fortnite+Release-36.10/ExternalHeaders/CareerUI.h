/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CareerUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "GameplayTags.h"
#include "FortniteGame.h"
#include "CoreUObject.h"

// Size: 0xb8
class UFortCareerChangeFlagModalItemVM : public UMVVMViewModelBase
{
public:
    FString RegionId() const { return Read<FString>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StrProperty)
    FText RegionDisplayName() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D> RegionFlagAsset() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x20, Type: SoftObjectProperty)
    bool bIsCurrent() const { return Read<bool>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    UFortCareerUIManager* CareerUIManager() const { return Read<UFortCareerUIManager*>(uintptr_t(this) + 0xb0); } // 0xb0 (Size: 0x8, Type: ObjectProperty)

    void SET_RegionId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StrProperty)
    void SET_RegionDisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
    void SET_RegionFlagAsset(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x20, Type: SoftObjectProperty)
    void SET_bIsCurrent(const bool& Value) { Write<bool>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x1, Type: BoolProperty)
    void SET_CareerUIManager(const UFortCareerUIManager*& Value) { Write<UFortCareerUIManager*>(uintptr_t(this) + 0xb0, Value); } // 0xb0 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd8
class UFortCareerChangeFlagModalVM : public UFortCareerStatsScreenVM
{
public:
    int32_t RegionLockDaysRemaining() const { return Read<int32_t>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: IntProperty)
    bool bAllowedToChangeFlag() const { return Read<bool>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x1, Type: BoolProperty)
    TArray<UFortCareerChangeFlagModalItemVM*> AvailableRegions() const { return Read<TArray<UFortCareerChangeFlagModalItemVM*>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x10, Type: ArrayProperty)

    void SET_RegionLockDaysRemaining(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: IntProperty)
    void SET_bAllowedToChangeFlag(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x1, Type: BoolProperty)
    void SET_AvailableRegions(const TArray<UFortCareerChangeFlagModalItemVM*>& Value) { Write<TArray<UFortCareerChangeFlagModalItemVM*>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0xb0
class UFortCareerStatsScreenVM : public UMVVMViewModelBase
{
public:
    FString RegionId() const { return Read<FString>(uintptr_t(this) + 0x68); } // 0x68 (Size: 0x10, Type: StrProperty)
    FText RegionDisplayName() const { return Read<FText>(uintptr_t(this) + 0x78); } // 0x78 (Size: 0x10, Type: TextProperty)
    TSoftObjectPtr<UTexture2D> RegionFlagAsset() const { return Read<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x88); } // 0x88 (Size: 0x20, Type: SoftObjectProperty)
    UFortCareerUIManager* CareerUIManager() const { return Read<UFortCareerUIManager*>(uintptr_t(this) + 0xa8); } // 0xa8 (Size: 0x8, Type: ObjectProperty)

    void SET_RegionId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x68, Value); } // 0x68 (Size: 0x10, Type: StrProperty)
    void SET_RegionDisplayName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x78, Value); } // 0x78 (Size: 0x10, Type: TextProperty)
    void SET_RegionFlagAsset(const TSoftObjectPtr<UTexture2D>& Value) { Write<TSoftObjectPtr<UTexture2D>>(uintptr_t(this) + 0x88, Value); } // 0x88 (Size: 0x20, Type: SoftObjectProperty)
    void SET_CareerUIManager(const UFortCareerUIManager*& Value) { Write<UFortCareerUIManager*>(uintptr_t(this) + 0xa8, Value); } // 0xa8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x88
class UFortCareerUIManager : public UEngineSubsystem
{
public:
    UFortCareerChangeFlagModalVM* ChangeFlagModalVM() const { return Read<UFortCareerChangeFlagModalVM*>(uintptr_t(this) + 0x80); } // 0x80 (Size: 0x8, Type: ObjectProperty)

    void SET_ChangeFlagModalVM(const UFortCareerChangeFlagModalVM*& Value) { Write<UFortCareerChangeFlagModalVM*>(uintptr_t(this) + 0x80, Value); } // 0x80 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x48
class UFortUIGameFeatureAction_CompeteTab : public UFortUIGameFeatureAction
{
public:
};

