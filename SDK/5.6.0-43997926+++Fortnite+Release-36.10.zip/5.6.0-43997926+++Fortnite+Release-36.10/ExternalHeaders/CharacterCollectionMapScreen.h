/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CharacterCollectionMapScreen
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "UMG.h"
#include "GameplayTags.h"
#include "FortniteUI.h"

// Size: 0x770
class UAthenaCollectionScreenMapCharacter : public UAthenaCollectionScreenMapBase
{
public:
    UCollectionScreenServiceVisualData* SharedServiceVisualData() const { return Read<UCollectionScreenServiceVisualData*>(uintptr_t(this) + 0x748); } // 0x748 (Size: 0x8, Type: ObjectProperty)
    FGameplayTagContainer ExcludedProducts() const { return Read<FGameplayTagContainer>(uintptr_t(this) + 0x750); } // 0x750 (Size: 0x20, Type: StructProperty)

    void SET_SharedServiceVisualData(const UCollectionScreenServiceVisualData*& Value) { Write<UCollectionScreenServiceVisualData*>(uintptr_t(this) + 0x748, Value); } // 0x748 (Size: 0x8, Type: ObjectProperty)
    void SET_ExcludedProducts(const FGameplayTagContainer& Value) { Write<FGameplayTagContainer>(uintptr_t(this) + 0x750, Value); } // 0x750 (Size: 0x20, Type: StructProperty)
};

// Size: 0x548
class UCollectionNPCServiceInfoOverlay : public UAthenaCollectionScreenInfoOverlay
{
public:
    UCollectionNPCServiceContainer* Services() const { return Read<UCollectionNPCServiceContainer*>(uintptr_t(this) + 0x530); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_ServiceIcon() const { return Read<UImage*>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x8, Type: ObjectProperty)
    UCollectionScreenServiceVisualData* SharedServiceVisualData() const { return Read<UCollectionScreenServiceVisualData*>(uintptr_t(this) + 0x540); } // 0x540 (Size: 0x8, Type: ObjectProperty)

    void SET_Services(const UCollectionNPCServiceContainer*& Value) { Write<UCollectionNPCServiceContainer*>(uintptr_t(this) + 0x530, Value); } // 0x530 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_ServiceIcon(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x8, Type: ObjectProperty)
    void SET_SharedServiceVisualData(const UCollectionScreenServiceVisualData*& Value) { Write<UCollectionScreenServiceVisualData*>(uintptr_t(this) + 0x540, Value); } // 0x540 (Size: 0x8, Type: ObjectProperty)
};

