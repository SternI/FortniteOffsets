/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: Filter
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "CommonUI.h"
#include "CompeteUI.h"
#include "UMG.h"
#include "FortniteGame.h"
#include "Engine.h"
#include "Systems.h"
#include "UIKit.h"

// Size: 0x4e0
class UWBP_TournamentsFilter_C : public UCommonActivatableWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x478); } // 0x478 (Size: 0x8, Type: StructProperty)
    UCommonTextBlock* Text_TournamentFilter() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x480); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_TournamentType() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x488); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_TournamentStatus() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_TeamSize() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_Region() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_Experience() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_Eligibility() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UWBP_TournamentsFilter_Section_C* Section_Bookmarks() const { return Read<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Dialog_Internal_C* Dialog_Internal() const { return Read<UWBP_UIKit_Dialog_Internal_C*>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* Button_Cancel() const { return Read<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x4c8); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_Button_Regular_C* Button_ApplyFilters() const { return Read<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x4d0); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    UFortPoblanoTournamentsCalendarFilterVM* FortPoblanoTournamentsCalendarFilterVM() const { return Read<UFortPoblanoTournamentsCalendarFilterVM*>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x478, Value); } // 0x478 (Size: 0x8, Type: StructProperty)
    void SET_Text_TournamentFilter(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x480, Value); } // 0x480 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_TournamentType(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x488, Value); } // 0x488 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_TournamentStatus(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_TeamSize(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_Region(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_Experience(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_Eligibility(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Section_Bookmarks(const UWBP_TournamentsFilter_Section_C*& Value) { Write<UWBP_TournamentsFilter_Section_C*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    void SET_Dialog_Internal(const UWBP_UIKit_Dialog_Internal_C*& Value) { Write<UWBP_UIKit_Dialog_Internal_C*>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_Cancel(const UWBP_UIKit_Button_Regular_C*& Value) { Write<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x4c8, Value); } // 0x4c8 (Size: 0x8, Type: ObjectProperty)
    void SET_Button_ApplyFilters(const UWBP_UIKit_Button_Regular_C*& Value) { Write<UWBP_UIKit_Button_Regular_C*>(uintptr_t(this) + 0x4d0, Value); } // 0x4d0 (Size: 0x8, Type: ObjectProperty)
    void SET_FortPoblanoTournamentsCalendarFilterVM(const UFortPoblanoTournamentsCalendarFilterVM*& Value) { Write<UFortPoblanoTournamentsCalendarFilterVM*>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x431
class UWBP_TournamentsFilter_Section_C : public UCommonUserWidget
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348); } // 0x348 (Size: 0x8, Type: StructProperty)
    UUniformGridPanel* UniformGridPanel_Filters() const { return Read<UUniformGridPanel*>(uintptr_t(this) + 0x350); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    UCommonTextBlock* Text_SectionName() const { return Read<UCommonTextBlock*>(uintptr_t(this) + 0x358); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    UWBP_UIKit_ButtonWithToggle_C* SelectedRadioToggle() const { return Read<UWBP_UIKit_ButtonWithToggle_C*>(uintptr_t(this) + 0x360); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    TArray<UWBP_TournamentFilter_SortToggleButton_C*> FilterSectionEntries() const { return Read<TArray<UWBP_TournamentFilter_SortToggleButton_C*>>(uintptr_t(this) + 0x368); } // 0x368 (Size: 0x10, Type: ArrayProperty)
    bool bRadioType() const { return Read<bool>(uintptr_t(this) + 0x378); } // 0x378 (Size: 0x1, Type: BoolProperty)
    int32_t MaxElementsPerRow() const { return Read<int32_t>(uintptr_t(this) + 0x37c); } // 0x37c (Size: 0x4, Type: IntProperty)
    TArray<bool> ToggleValues() const { return Read<TArray<bool>>(uintptr_t(this) + 0x380); } // 0x380 (Size: 0x10, Type: ArrayProperty)
    TMap<TSoftObjectPtr<UTexture*>, ETournamentType> TournamentTypesIcons() const { return Read<TMap<TSoftObjectPtr<UTexture*>, ETournamentType>>(uintptr_t(this) + 0x390); } // 0x390 (Size: 0x50, Type: MapProperty)
    TMap<TSoftObjectPtr<UTexture*>, ETournamentTypeFilter> TournamentTypesFilterIcons() const { return Read<TMap<TSoftObjectPtr<UTexture*>, ETournamentTypeFilter>>(uintptr_t(this) + 0x3e0); } // 0x3e0 (Size: 0x50, Type: MapProperty)
    bool IsShowIcons() const { return Read<bool>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x1, Type: BoolProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x348, Value); } // 0x348 (Size: 0x8, Type: StructProperty)
    void SET_UniformGridPanel_Filters(const UUniformGridPanel*& Value) { Write<UUniformGridPanel*>(uintptr_t(this) + 0x350, Value); } // 0x350 (Size: 0x8, Type: ObjectProperty)
    void SET_Text_SectionName(const UCommonTextBlock*& Value) { Write<UCommonTextBlock*>(uintptr_t(this) + 0x358, Value); } // 0x358 (Size: 0x8, Type: ObjectProperty)
    void SET_SelectedRadioToggle(const UWBP_UIKit_ButtonWithToggle_C*& Value) { Write<UWBP_UIKit_ButtonWithToggle_C*>(uintptr_t(this) + 0x360, Value); } // 0x360 (Size: 0x8, Type: ObjectProperty)
    void SET_FilterSectionEntries(const TArray<UWBP_TournamentFilter_SortToggleButton_C*>& Value) { Write<TArray<UWBP_TournamentFilter_SortToggleButton_C*>>(uintptr_t(this) + 0x368, Value); } // 0x368 (Size: 0x10, Type: ArrayProperty)
    void SET_bRadioType(const bool& Value) { Write<bool>(uintptr_t(this) + 0x378, Value); } // 0x378 (Size: 0x1, Type: BoolProperty)
    void SET_MaxElementsPerRow(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x37c, Value); } // 0x37c (Size: 0x4, Type: IntProperty)
    void SET_ToggleValues(const TArray<bool>& Value) { Write<TArray<bool>>(uintptr_t(this) + 0x380, Value); } // 0x380 (Size: 0x10, Type: ArrayProperty)
    void SET_TournamentTypesIcons(const TMap<TSoftObjectPtr<UTexture*>, ETournamentType>& Value) { Write<TMap<TSoftObjectPtr<UTexture*>, ETournamentType>>(uintptr_t(this) + 0x390, Value); } // 0x390 (Size: 0x50, Type: MapProperty)
    void SET_TournamentTypesFilterIcons(const TMap<TSoftObjectPtr<UTexture*>, ETournamentTypeFilter>& Value) { Write<TMap<TSoftObjectPtr<UTexture*>, ETournamentTypeFilter>>(uintptr_t(this) + 0x3e0, Value); } // 0x3e0 (Size: 0x50, Type: MapProperty)
    void SET_IsShowIcons(const bool& Value) { Write<bool>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x1958
class UWBP_TournamentFilter_SortToggleButton_C : public UWBP_UIKit_ButtonWithToggle_C
{
public:
    FPointerToUberGraphFrame UberGraphFrame() const { return Read<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1900); } // 0x1900 (Size: 0x8, Type: StructProperty)
    float MainPaddingLeft() const { return Read<float>(uintptr_t(this) + 0x1918); } // 0x1918 (Size: 0x4, Type: FloatProperty)
    UMaterialInstance* ToggleIconMaterial() const { return Read<UMaterialInstance*>(uintptr_t(this) + 0x1940); } // 0x1940 (Size: 0x8, Type: ObjectProperty)
    FText FilterName() const { return Read<FText>(uintptr_t(this) + 0x1948); } // 0x1948 (Size: 0x10, Type: TextProperty)

    void SET_UberGraphFrame(const FPointerToUberGraphFrame& Value) { Write<FPointerToUberGraphFrame>(uintptr_t(this) + 0x1900, Value); } // 0x1900 (Size: 0x8, Type: StructProperty)
    void SET_MainPaddingLeft(const float& Value) { Write<float>(uintptr_t(this) + 0x1918, Value); } // 0x1918 (Size: 0x4, Type: FloatProperty)
    void SET_ToggleIconMaterial(const UMaterialInstance*& Value) { Write<UMaterialInstance*>(uintptr_t(this) + 0x1940, Value); } // 0x1940 (Size: 0x8, Type: ObjectProperty)
    void SET_FilterName(const FText& Value) { Write<FText>(uintptr_t(this) + 0x1948, Value); } // 0x1948 (Size: 0x10, Type: TextProperty)
};

