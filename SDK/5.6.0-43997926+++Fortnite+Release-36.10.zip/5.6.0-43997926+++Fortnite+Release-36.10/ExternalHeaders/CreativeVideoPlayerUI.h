/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CreativeVideoPlayerUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "MediaAssets.h"
#include "Engine.h"
#include "CommonUILegacy.h"
#include "UMG.h"

// Size: 0x4f0
class UCreativeVideoPlayerFullScreenWidget : public UCommonActivatableWidget
{
public:
    USoundSourceBus* SourceBus() const { return Read<USoundSourceBus*>(uintptr_t(this) + 0x490); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    USoundClass* SoundClass() const { return Read<USoundClass*>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    FDataTableRowHandle HoldToSkipAction() const { return Read<FDataTableRowHandle>(uintptr_t(this) + 0x4a0); } // 0x4a0 (Size: 0x10, Type: StructProperty)
    UCommonButtonLegacy* Button_Skip() const { return Read<UCommonButtonLegacy*>(uintptr_t(this) + 0x4b0); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    UImage* Image_VideoTexture() const { return Read<UImage*>(uintptr_t(this) + 0x4b8); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    float SkipButtonTimeout() const { return Read<float>(uintptr_t(this) + 0x4c0); } // 0x4c0 (Size: 0x4, Type: FloatProperty)
    UAudioComponent* SoundComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x4d8); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)

    void SET_SourceBus(const USoundSourceBus*& Value) { Write<USoundSourceBus*>(uintptr_t(this) + 0x490, Value); } // 0x490 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundClass(const USoundClass*& Value) { Write<USoundClass*>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x8, Type: ObjectProperty)
    void SET_HoldToSkipAction(const FDataTableRowHandle& Value) { Write<FDataTableRowHandle>(uintptr_t(this) + 0x4a0, Value); } // 0x4a0 (Size: 0x10, Type: StructProperty)
    void SET_Button_Skip(const UCommonButtonLegacy*& Value) { Write<UCommonButtonLegacy*>(uintptr_t(this) + 0x4b0, Value); } // 0x4b0 (Size: 0x8, Type: ObjectProperty)
    void SET_Image_VideoTexture(const UImage*& Value) { Write<UImage*>(uintptr_t(this) + 0x4b8, Value); } // 0x4b8 (Size: 0x8, Type: ObjectProperty)
    void SET_SkipButtonTimeout(const float& Value) { Write<float>(uintptr_t(this) + 0x4c0, Value); } // 0x4c0 (Size: 0x4, Type: FloatProperty)
    void SET_SoundComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x4d8, Value); } // 0x4d8 (Size: 0x8, Type: ObjectProperty)
};

