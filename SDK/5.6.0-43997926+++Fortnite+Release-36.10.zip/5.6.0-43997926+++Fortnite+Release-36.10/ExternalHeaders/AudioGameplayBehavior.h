/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioGameplayBehavior
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "AudioGameplay.h"
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x110
class UAudioGameplayBehavior : public UActorComponent
{
public:
    bool bKillOnSoundsFinished() const { return Read<bool>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    bool bTickWhileStopped() const { return Read<bool>(uintptr_t(this) + 0xc1); } // 0xc1 (Size: 0x1, Type: BoolProperty)
    TArray<FActiveVoice> PlayingSounds() const { return Read<TArray<FActiveVoice>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    UAudioComponentGroup* ComponentGroupOwner() const { return Read<UAudioComponentGroup*>(uintptr_t(this) + 0xf8); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    bool bReleaseActiveVoicesOnFadeOut() const { return Read<bool>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: BoolProperty)

    void SET_bKillOnSoundsFinished(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x1, Type: BoolProperty)
    void SET_bTickWhileStopped(const bool& Value) { Write<bool>(uintptr_t(this) + 0xc1, Value); } // 0xc1 (Size: 0x1, Type: BoolProperty)
    void SET_PlayingSounds(const TArray<FActiveVoice>& Value) { Write<TArray<FActiveVoice>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x10, Type: ArrayProperty)
    void SET_ComponentGroupOwner(const UAudioComponentGroup*& Value) { Write<UAudioComponentGroup*>(uintptr_t(this) + 0xf8, Value); } // 0xf8 (Size: 0x8, Type: ObjectProperty)
    void SET_bReleaseActiveVoicesOnFadeOut(const bool& Value) { Write<bool>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x18
struct FActiveVoice
{
public:
    USoundBase* Sound() const { return Read<USoundBase*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* Component() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    FPlayingId ID() const { return Read<FPlayingId>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: StructProperty)

    void SET_Sound(const USoundBase*& Value) { Write<USoundBase*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
    void SET_Component(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
    void SET_ID(const FPlayingId& Value) { Write<FPlayingId>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: StructProperty)
};

// Size: 0x4
struct FPlayingId
{
public:
};

// Size: 0x10
struct FAudioGameplayBehaviorInstance
{
public:
    UClass* Sound() const { return Read<UClass*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ClassProperty)
    UAudioGameplayBehavior* Instance() const { return Read<UAudioGameplayBehavior*>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x8, Type: ObjectProperty)

    void SET_Sound(const UClass*& Value) { Write<UClass*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ClassProperty)
    void SET_Instance(const UAudioGameplayBehavior*& Value) { Write<UAudioGameplayBehavior*>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x8, Type: ObjectProperty)
};

