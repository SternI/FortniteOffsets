/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BeanstalkManagersRuntime
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "BeanstalkCosmeticsRuntime.h"
#include "CoreUObject.h"
#include "FortniteGame.h"

// Size: 0xa8
class UBeanstalkAccountItemDefinitionOverrideManager : public UObject
{
public:
    TSoftObjectPtr<UBeanCosmeticsData> BeanCosmetics() const { return Read<TSoftObjectPtr<UBeanCosmeticsData>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    UBeanCosmeticsData* BeanCosmeticsDataCache() const { return Read<UBeanCosmeticsData*>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    TMap<FBeanstalkAccountItemDefinitionOverride, FPrimaryAssetId> OverrideCache() const { return Read<TMap<FBeanstalkAccountItemDefinitionOverride, FPrimaryAssetId>>(uintptr_t(this) + 0x58); } // 0x58 (Size: 0x50, Type: MapProperty)

    void SET_BeanCosmetics(const TSoftObjectPtr<UBeanCosmeticsData>& Value) { Write<TSoftObjectPtr<UBeanCosmeticsData>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x20, Type: SoftObjectProperty)
    void SET_BeanCosmeticsDataCache(const UBeanCosmeticsData*& Value) { Write<UBeanCosmeticsData*>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0x8, Type: ObjectProperty)
    void SET_OverrideCache(const TMap<FBeanstalkAccountItemDefinitionOverride, FPrimaryAssetId>& Value) { Write<TMap<FBeanstalkAccountItemDefinitionOverride, FPrimaryAssetId>>(uintptr_t(this) + 0x58, Value); } // 0x58 (Size: 0x50, Type: MapProperty)
};

// Size: 0x10
struct FBeanstalkAccountItemDefinitionOverride
{
public:
    UFortAccountItemDefinition* AccountItemDefinition() const { return Read<UFortAccountItemDefinition*>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x8, Type: ObjectProperty)

    void SET_AccountItemDefinition(const UFortAccountItemDefinition*& Value) { Write<UFortAccountItemDefinition*>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x8, Type: ObjectProperty)
};

