/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CosmeticsFrameworkModifiers
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x28
class UCosmeticModifierInterface : public UInterface
{
public:
};

// Size: 0x28
class UCosmeticModifierOwnerInterface : public UInterface
{
public:
};

// Size: 0x28
class UCosmeticModifierProviderInterface : public UInterface
{
public:
};

// Size: 0x20
struct FSoftModifierClassPtr
{
public:
};

