/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: EpicMediaCDNHostnames
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
// Size: 0x178
class UEpicMediaCDNHostnames : public UObject
{
public:
    TArray<float> CDNDistribution() const { return Read<TArray<float>>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x10, Type: ArrayProperty)

    void SET_CDNDistribution(const TArray<float>& Value) { Write<TArray<float>>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x10, Type: ArrayProperty)
};

