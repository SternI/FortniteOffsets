/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: CableComponent
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "Engine.h"
#include "CoreUObject.h"

// Size: 0x2b0
class ACableActor : public AActor
{
public:
    UCableComponent* CableComponent() const { return Read<UCableComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_CableComponent(const UCableComponent*& Value) { Write<UCableComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x730
class UCableComponent : public UMeshComponent
{
public:
    bool bAttachStart() const { return Read<bool>(uintptr_t(this) + 0x560); } // 0x560 (Size: 0x1, Type: BoolProperty)
    bool bAttachEnd() const { return Read<bool>(uintptr_t(this) + 0x561); } // 0x561 (Size: 0x1, Type: BoolProperty)
    FComponentReference AttachEndTo() const { return Read<FComponentReference>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x28, Type: StructProperty)
    FName AttachEndToSocketName() const { return Read<FName>(uintptr_t(this) + 0x590); } // 0x590 (Size: 0x4, Type: NameProperty)
    FVector EndLocation() const { return Read<FVector>(uintptr_t(this) + 0x598); } // 0x598 (Size: 0x18, Type: StructProperty)
    float CableLength() const { return Read<float>(uintptr_t(this) + 0x5b0); } // 0x5b0 (Size: 0x4, Type: FloatProperty)
    int32_t NumSegments() const { return Read<int32_t>(uintptr_t(this) + 0x5b4); } // 0x5b4 (Size: 0x4, Type: IntProperty)
    float SubstepTime() const { return Read<float>(uintptr_t(this) + 0x5b8); } // 0x5b8 (Size: 0x4, Type: FloatProperty)
    int32_t SolverIterations() const { return Read<int32_t>(uintptr_t(this) + 0x5bc); } // 0x5bc (Size: 0x4, Type: IntProperty)
    bool bEnableStiffness() const { return Read<bool>(uintptr_t(this) + 0x5c0); } // 0x5c0 (Size: 0x1, Type: BoolProperty)
    bool bUseSubstepping() const { return Read<bool>(uintptr_t(this) + 0x5c1); } // 0x5c1 (Size: 0x1, Type: BoolProperty)
    bool bSkipCableUpdateWhenNotVisible() const { return Read<bool>(uintptr_t(this) + 0x5c2); } // 0x5c2 (Size: 0x1, Type: BoolProperty)
    bool bSkipCableUpdateWhenNotOwnerRecentlyRendered() const { return Read<bool>(uintptr_t(this) + 0x5c3); } // 0x5c3 (Size: 0x1, Type: BoolProperty)
    bool bEnableCollision() const { return Read<bool>(uintptr_t(this) + 0x5c4); } // 0x5c4 (Size: 0x1, Type: BoolProperty)
    float CollisionFriction() const { return Read<float>(uintptr_t(this) + 0x5c8); } // 0x5c8 (Size: 0x4, Type: FloatProperty)
    FVector CableForce() const { return Read<FVector>(uintptr_t(this) + 0x5d0); } // 0x5d0 (Size: 0x18, Type: StructProperty)
    float CableGravityScale() const { return Read<float>(uintptr_t(this) + 0x5e8); } // 0x5e8 (Size: 0x4, Type: FloatProperty)
    float CableWidth() const { return Read<float>(uintptr_t(this) + 0x5ec); } // 0x5ec (Size: 0x4, Type: FloatProperty)
    int32_t NumSides() const { return Read<int32_t>(uintptr_t(this) + 0x5f0); } // 0x5f0 (Size: 0x4, Type: IntProperty)
    float TileMaterial() const { return Read<float>(uintptr_t(this) + 0x5f4); } // 0x5f4 (Size: 0x4, Type: FloatProperty)
    bool bResetAfterTeleport() const { return Read<bool>(uintptr_t(this) + 0x5f8); } // 0x5f8 (Size: 0x1, Type: BoolProperty)
    float TeleportDistanceThreshold() const { return Read<float>(uintptr_t(this) + 0x5fc); } // 0x5fc (Size: 0x4, Type: FloatProperty)
    float TeleportRotationThreshold() const { return Read<float>(uintptr_t(this) + 0x600); } // 0x600 (Size: 0x4, Type: FloatProperty)
    bool bTeleportAfterReattach() const { return Read<bool>(uintptr_t(this) + 0x604); } // 0x604 (Size: 0x1, Type: BoolProperty)

    void SET_bAttachStart(const bool& Value) { Write<bool>(uintptr_t(this) + 0x560, Value); } // 0x560 (Size: 0x1, Type: BoolProperty)
    void SET_bAttachEnd(const bool& Value) { Write<bool>(uintptr_t(this) + 0x561, Value); } // 0x561 (Size: 0x1, Type: BoolProperty)
    void SET_AttachEndTo(const FComponentReference& Value) { Write<FComponentReference>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x28, Type: StructProperty)
    void SET_AttachEndToSocketName(const FName& Value) { Write<FName>(uintptr_t(this) + 0x590, Value); } // 0x590 (Size: 0x4, Type: NameProperty)
    void SET_EndLocation(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x598, Value); } // 0x598 (Size: 0x18, Type: StructProperty)
    void SET_CableLength(const float& Value) { Write<float>(uintptr_t(this) + 0x5b0, Value); } // 0x5b0 (Size: 0x4, Type: FloatProperty)
    void SET_NumSegments(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5b4, Value); } // 0x5b4 (Size: 0x4, Type: IntProperty)
    void SET_SubstepTime(const float& Value) { Write<float>(uintptr_t(this) + 0x5b8, Value); } // 0x5b8 (Size: 0x4, Type: FloatProperty)
    void SET_SolverIterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5bc, Value); } // 0x5bc (Size: 0x4, Type: IntProperty)
    void SET_bEnableStiffness(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c0, Value); } // 0x5c0 (Size: 0x1, Type: BoolProperty)
    void SET_bUseSubstepping(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c1, Value); } // 0x5c1 (Size: 0x1, Type: BoolProperty)
    void SET_bSkipCableUpdateWhenNotVisible(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c2, Value); } // 0x5c2 (Size: 0x1, Type: BoolProperty)
    void SET_bSkipCableUpdateWhenNotOwnerRecentlyRendered(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c3, Value); } // 0x5c3 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableCollision(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5c4, Value); } // 0x5c4 (Size: 0x1, Type: BoolProperty)
    void SET_CollisionFriction(const float& Value) { Write<float>(uintptr_t(this) + 0x5c8, Value); } // 0x5c8 (Size: 0x4, Type: FloatProperty)
    void SET_CableForce(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0x5d0, Value); } // 0x5d0 (Size: 0x18, Type: StructProperty)
    void SET_CableGravityScale(const float& Value) { Write<float>(uintptr_t(this) + 0x5e8, Value); } // 0x5e8 (Size: 0x4, Type: FloatProperty)
    void SET_CableWidth(const float& Value) { Write<float>(uintptr_t(this) + 0x5ec, Value); } // 0x5ec (Size: 0x4, Type: FloatProperty)
    void SET_NumSides(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x5f0, Value); } // 0x5f0 (Size: 0x4, Type: IntProperty)
    void SET_TileMaterial(const float& Value) { Write<float>(uintptr_t(this) + 0x5f4, Value); } // 0x5f4 (Size: 0x4, Type: FloatProperty)
    void SET_bResetAfterTeleport(const bool& Value) { Write<bool>(uintptr_t(this) + 0x5f8, Value); } // 0x5f8 (Size: 0x1, Type: BoolProperty)
    void SET_TeleportDistanceThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x5fc, Value); } // 0x5fc (Size: 0x4, Type: FloatProperty)
    void SET_TeleportRotationThreshold(const float& Value) { Write<float>(uintptr_t(this) + 0x600, Value); } // 0x600 (Size: 0x4, Type: FloatProperty)
    void SET_bTeleportAfterReattach(const bool& Value) { Write<bool>(uintptr_t(this) + 0x604, Value); } // 0x604 (Size: 0x1, Type: BoolProperty)
};

