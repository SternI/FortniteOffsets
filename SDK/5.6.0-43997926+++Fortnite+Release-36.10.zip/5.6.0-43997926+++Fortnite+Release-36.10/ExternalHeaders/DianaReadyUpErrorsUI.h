/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: DianaReadyUpErrorsUI
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"

// Size: 0x130
class UDianaGeneralWarningUI : public UReadyUpErrorUI
{
public:
};

// Size: 0x4b8
class UDiana_ModeWarningPopupScreen : public UCommonActivatableWidget
{
public:
    FString StartDate() const { return Read<FString>(uintptr_t(this) + 0x498); } // 0x498 (Size: 0x10, Type: StrProperty)
    FString EndDate() const { return Read<FString>(uintptr_t(this) + 0x4a8); } // 0x4a8 (Size: 0x10, Type: StrProperty)

    void SET_StartDate(const FString& Value) { Write<FString>(uintptr_t(this) + 0x498, Value); } // 0x498 (Size: 0x10, Type: StrProperty)
    void SET_EndDate(const FString& Value) { Write<FString>(uintptr_t(this) + 0x4a8, Value); } // 0x4a8 (Size: 0x10, Type: StrProperty)
};

