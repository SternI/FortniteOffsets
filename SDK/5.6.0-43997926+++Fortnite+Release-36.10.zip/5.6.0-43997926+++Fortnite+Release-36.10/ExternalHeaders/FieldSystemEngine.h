/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: FieldSystemEngine
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "CoreUObject.h"
#include "ChaosSolverEngine.h"

// Size: 0x2b0
class AFieldSystemActor : public AActor
{
public:
    UFieldSystemComponent* FieldSystemComponent() const { return Read<UFieldSystemComponent*>(uintptr_t(this) + 0x2a8); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)

    void SET_FieldSystemComponent(const UFieldSystemComponent*& Value) { Write<UFieldSystemComponent*>(uintptr_t(this) + 0x2a8, Value); } // 0x2a8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x38
class UFieldSystem : public UObject
{
public:
};

// Size: 0x5f0
class UFieldSystemComponent : public UPrimitiveComponent
{
public:
    UFieldSystem* FieldSystem() const { return Read<UFieldSystem*>(uintptr_t(this) + 0x518); } // 0x518 (Size: 0x8, Type: ObjectProperty)
    bool bIsWorldField() const { return Read<bool>(uintptr_t(this) + 0x520); } // 0x520 (Size: 0x1, Type: BoolProperty)
    bool bIsChaosField() const { return Read<bool>(uintptr_t(this) + 0x521); } // 0x521 (Size: 0x1, Type: BoolProperty)
    TArray<TSoftObjectPtr<AChaosSolverActor*>> SupportedSolvers() const { return Read<TArray<TSoftObjectPtr<AChaosSolverActor*>>>(uintptr_t(this) + 0x528); } // 0x528 (Size: 0x10, Type: ArrayProperty)
    FFieldObjectCommands ConstructionCommands() const { return Read<FFieldObjectCommands>(uintptr_t(this) + 0x538); } // 0x538 (Size: 0x30, Type: StructProperty)
    FFieldObjectCommands BufferCommands() const { return Read<FFieldObjectCommands>(uintptr_t(this) + 0x568); } // 0x568 (Size: 0x30, Type: StructProperty)

    void SET_FieldSystem(const UFieldSystem*& Value) { Write<UFieldSystem*>(uintptr_t(this) + 0x518, Value); } // 0x518 (Size: 0x8, Type: ObjectProperty)
    void SET_bIsWorldField(const bool& Value) { Write<bool>(uintptr_t(this) + 0x520, Value); } // 0x520 (Size: 0x1, Type: BoolProperty)
    void SET_bIsChaosField(const bool& Value) { Write<bool>(uintptr_t(this) + 0x521, Value); } // 0x521 (Size: 0x1, Type: BoolProperty)
    void SET_SupportedSolvers(const TArray<TSoftObjectPtr<AChaosSolverActor*>>& Value) { Write<TArray<TSoftObjectPtr<AChaosSolverActor*>>>(uintptr_t(this) + 0x528, Value); } // 0x528 (Size: 0x10, Type: ArrayProperty)
    void SET_ConstructionCommands(const FFieldObjectCommands& Value) { Write<FFieldObjectCommands>(uintptr_t(this) + 0x538, Value); } // 0x538 (Size: 0x30, Type: StructProperty)
    void SET_BufferCommands(const FFieldObjectCommands& Value) { Write<FFieldObjectCommands>(uintptr_t(this) + 0x568, Value); } // 0x568 (Size: 0x30, Type: StructProperty)
};

// Size: 0xb8
class UFieldSystemMetaData : public UActorComponent
{
public:
};

// Size: 0xc0
class UFieldSystemMetaDataIteration : public UFieldSystemMetaData
{
public:
    int32_t Iterations() const { return Read<int32_t>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: IntProperty)

    void SET_Iterations(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: IntProperty)
};

// Size: 0xc0
class UFieldSystemMetaDataProcessingResolution : public UFieldSystemMetaData
{
public:
    TEnumAsByte<EFieldResolutionType> ResolutionType() const { return Read<TEnumAsByte<EFieldResolutionType>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: ByteProperty)

    void SET_ResolutionType(const TEnumAsByte<EFieldResolutionType>& Value) { Write<TEnumAsByte<EFieldResolutionType>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xc0
class UFieldSystemMetaDataFilter : public UFieldSystemMetaData
{
public:
    TEnumAsByte<EFieldFilterType> FilterType() const { return Read<TEnumAsByte<EFieldFilterType>>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EFieldObjectType> ObjectType() const { return Read<TEnumAsByte<EFieldObjectType>>(uintptr_t(this) + 0xb9); } // 0xb9 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EFieldPositionType> PositionType() const { return Read<TEnumAsByte<EFieldPositionType>>(uintptr_t(this) + 0xba); } // 0xba (Size: 0x1, Type: ByteProperty)

    void SET_FilterType(const TEnumAsByte<EFieldFilterType>& Value) { Write<TEnumAsByte<EFieldFilterType>>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x1, Type: ByteProperty)
    void SET_ObjectType(const TEnumAsByte<EFieldObjectType>& Value) { Write<TEnumAsByte<EFieldObjectType>>(uintptr_t(this) + 0xb9, Value); } // 0xb9 (Size: 0x1, Type: ByteProperty)
    void SET_PositionType(const TEnumAsByte<EFieldPositionType>& Value) { Write<TEnumAsByte<EFieldPositionType>>(uintptr_t(this) + 0xba, Value); } // 0xba (Size: 0x1, Type: ByteProperty)
};

// Size: 0xb8
class UFieldNodeBase : public UActorComponent
{
public:
};

// Size: 0xb8
class UFieldNodeInt : public UFieldNodeBase
{
public:
};

// Size: 0xb8
class UFieldNodeFloat : public UFieldNodeBase
{
public:
};

// Size: 0xb8
class UFieldNodeVector : public UFieldNodeBase
{
public:
};

// Size: 0xc0
class UUniformInteger : public UFieldNodeInt
{
public:
    int32_t Magnitude() const { return Read<int32_t>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: IntProperty)

    void SET_Magnitude(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: IntProperty)
};

// Size: 0xe8
class URadialIntMask : public UFieldNodeInt
{
public:
    float Radius() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    FVector Position() const { return Read<FVector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)
    int32_t InteriorValue() const { return Read<int32_t>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: IntProperty)
    int32_t ExteriorValue() const { return Read<int32_t>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: IntProperty)
    TEnumAsByte<ESetMaskConditionType> SetMaskCondition() const { return Read<TEnumAsByte<ESetMaskConditionType>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: ByteProperty)

    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_Position(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
    void SET_InteriorValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: IntProperty)
    void SET_ExteriorValue(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: IntProperty)
    void SET_SetMaskCondition(const TEnumAsByte<ESetMaskConditionType>& Value) { Write<TEnumAsByte<ESetMaskConditionType>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xc0
class UUniformScalar : public UFieldNodeFloat
{
public:
    float Magnitude() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)

    void SET_Magnitude(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xe8
class UWaveScalar : public UFieldNodeFloat
{
public:
    float Magnitude() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    FVector Position() const { return Read<FVector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)
    float WaveLength() const { return Read<float>(uintptr_t(this) + 0xd8); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    float Period() const { return Read<float>(uintptr_t(this) + 0xdc); } // 0xdc (Size: 0x4, Type: FloatProperty)
    TEnumAsByte<EWaveFunctionType> Function() const { return Read<TEnumAsByte<EWaveFunctionType>>(uintptr_t(this) + 0xe0); } // 0xe0 (Size: 0x1, Type: ByteProperty)
    TEnumAsByte<EFieldFalloffType> Falloff() const { return Read<TEnumAsByte<EFieldFalloffType>>(uintptr_t(this) + 0xe1); } // 0xe1 (Size: 0x1, Type: ByteProperty)

    void SET_Magnitude(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_Position(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
    void SET_WaveLength(const float& Value) { Write<float>(uintptr_t(this) + 0xd8, Value); } // 0xd8 (Size: 0x4, Type: FloatProperty)
    void SET_Period(const float& Value) { Write<float>(uintptr_t(this) + 0xdc, Value); } // 0xdc (Size: 0x4, Type: FloatProperty)
    void SET_Function(const TEnumAsByte<EWaveFunctionType>& Value) { Write<TEnumAsByte<EWaveFunctionType>>(uintptr_t(this) + 0xe0, Value); } // 0xe0 (Size: 0x1, Type: ByteProperty)
    void SET_Falloff(const TEnumAsByte<EFieldFalloffType>& Value) { Write<TEnumAsByte<EFieldFalloffType>>(uintptr_t(this) + 0xe1, Value); } // 0xe1 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xf0
class URadialFalloff : public UFieldNodeFloat
{
public:
    float Magnitude() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float MinRange() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float MaxRange() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float Default() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    float Radius() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    FVector Position() const { return Read<FVector>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<EFieldFalloffType> Falloff() const { return Read<TEnumAsByte<EFieldFalloffType>>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x1, Type: ByteProperty)

    void SET_Magnitude(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_MinRange(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_MaxRange(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_Default(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_Radius(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_Position(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x18, Type: StructProperty)
    void SET_Falloff(const TEnumAsByte<EFieldFalloffType>& Value) { Write<TEnumAsByte<EFieldFalloffType>>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x108
class UPlaneFalloff : public UFieldNodeFloat
{
public:
    float Magnitude() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float MinRange() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float MaxRange() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float Default() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    float Distance() const { return Read<float>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    FVector Position() const { return Read<FVector>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x18, Type: StructProperty)
    FVector Normal() const { return Read<FVector>(uintptr_t(this) + 0xe8); } // 0xe8 (Size: 0x18, Type: StructProperty)
    TEnumAsByte<EFieldFalloffType> Falloff() const { return Read<TEnumAsByte<EFieldFalloffType>>(uintptr_t(this) + 0x100); } // 0x100 (Size: 0x1, Type: ByteProperty)

    void SET_Magnitude(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_MinRange(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_MaxRange(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_Default(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_Distance(const float& Value) { Write<float>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x4, Type: FloatProperty)
    void SET_Position(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x18, Type: StructProperty)
    void SET_Normal(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xe8, Value); } // 0xe8 (Size: 0x18, Type: StructProperty)
    void SET_Falloff(const TEnumAsByte<EFieldFalloffType>& Value) { Write<TEnumAsByte<EFieldFalloffType>>(uintptr_t(this) + 0x100, Value); } // 0x100 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x140
class UBoxFalloff : public UFieldNodeFloat
{
public:
    float Magnitude() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float MinRange() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    float MaxRange() const { return Read<float>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    float Default() const { return Read<float>(uintptr_t(this) + 0xc4); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x60, Type: StructProperty)
    TEnumAsByte<EFieldFalloffType> Falloff() const { return Read<TEnumAsByte<EFieldFalloffType>>(uintptr_t(this) + 0x130); } // 0x130 (Size: 0x1, Type: ByteProperty)

    void SET_Magnitude(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_MinRange(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_MaxRange(const float& Value) { Write<float>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x4, Type: FloatProperty)
    void SET_Default(const float& Value) { Write<float>(uintptr_t(this) + 0xc4, Value); } // 0xc4 (Size: 0x4, Type: FloatProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x60, Type: StructProperty)
    void SET_Falloff(const TEnumAsByte<EFieldFalloffType>& Value) { Write<TEnumAsByte<EFieldFalloffType>>(uintptr_t(this) + 0x130, Value); } // 0x130 (Size: 0x1, Type: ByteProperty)
};

// Size: 0x120
class UNoiseField : public UFieldNodeFloat
{
public:
    float MinRange() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    float MaxRange() const { return Read<float>(uintptr_t(this) + 0xbc); } // 0xbc (Size: 0x4, Type: FloatProperty)
    FTransform Transform() const { return Read<FTransform>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x60, Type: StructProperty)

    void SET_MinRange(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_MaxRange(const float& Value) { Write<float>(uintptr_t(this) + 0xbc, Value); } // 0xbc (Size: 0x4, Type: FloatProperty)
    void SET_Transform(const FTransform& Value) { Write<FTransform>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x60, Type: StructProperty)
};

// Size: 0xd8
class UUniformVector : public UFieldNodeVector
{
public:
    float Magnitude() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    FVector Direction() const { return Read<FVector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)

    void SET_Magnitude(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_Direction(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
};

// Size: 0xd8
class URadialVector : public UFieldNodeVector
{
public:
    float Magnitude() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    FVector Position() const { return Read<FVector>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x18, Type: StructProperty)

    void SET_Magnitude(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_Position(const FVector& Value) { Write<FVector>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x18, Type: StructProperty)
};

// Size: 0xc0
class URandomVector : public UFieldNodeVector
{
public:
    float Magnitude() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)

    void SET_Magnitude(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0xd8
class UOperatorField : public UFieldNodeBase
{
public:
    float Magnitude() const { return Read<float>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    UFieldNodeBase* RightField() const { return Read<UFieldNodeBase*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    UFieldNodeBase* LeftField() const { return Read<UFieldNodeBase*>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EFieldOperationType> Operation() const { return Read<TEnumAsByte<EFieldOperationType>>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x1, Type: ByteProperty)

    void SET_Magnitude(const float& Value) { Write<float>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x4, Type: FloatProperty)
    void SET_RightField(const UFieldNodeBase*& Value) { Write<UFieldNodeBase*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_LeftField(const UFieldNodeBase*& Value) { Write<UFieldNodeBase*>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x8, Type: ObjectProperty)
    void SET_Operation(const TEnumAsByte<EFieldOperationType>& Value) { Write<TEnumAsByte<EFieldOperationType>>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xc0
class UToIntegerField : public UFieldNodeInt
{
public:
    UFieldNodeFloat* FloatField() const { return Read<UFieldNodeFloat*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)

    void SET_FloatField(const UFieldNodeFloat*& Value) { Write<UFieldNodeFloat*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xc0
class UToFloatField : public UFieldNodeFloat
{
public:
    UFieldNodeInt* IntField() const { return Read<UFieldNodeInt*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)

    void SET_IntField(const UFieldNodeInt*& Value) { Write<UFieldNodeInt*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0xd0
class UCullingField : public UFieldNodeBase
{
public:
    UFieldNodeBase* Culling() const { return Read<UFieldNodeBase*>(uintptr_t(this) + 0xb8); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    UFieldNodeBase* Field() const { return Read<UFieldNodeBase*>(uintptr_t(this) + 0xc0); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    TEnumAsByte<EFieldCullingOperationType> Operation() const { return Read<TEnumAsByte<EFieldCullingOperationType>>(uintptr_t(this) + 0xc8); } // 0xc8 (Size: 0x1, Type: ByteProperty)

    void SET_Culling(const UFieldNodeBase*& Value) { Write<UFieldNodeBase*>(uintptr_t(this) + 0xb8, Value); } // 0xb8 (Size: 0x8, Type: ObjectProperty)
    void SET_Field(const UFieldNodeBase*& Value) { Write<UFieldNodeBase*>(uintptr_t(this) + 0xc0, Value); } // 0xc0 (Size: 0x8, Type: ObjectProperty)
    void SET_Operation(const TEnumAsByte<EFieldCullingOperationType>& Value) { Write<TEnumAsByte<EFieldCullingOperationType>>(uintptr_t(this) + 0xc8, Value); } // 0xc8 (Size: 0x1, Type: ByteProperty)
};

// Size: 0xb8
class UReturnResultsTerminal : public UFieldNodeBase
{
public:
};

// Size: 0x30
struct FFieldObjectCommands
{
public:
    TArray<FName> TargetNames() const { return Read<TArray<FName>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    TArray<UFieldNodeBase*> RootNodes() const { return Read<TArray<UFieldNodeBase*>>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    TArray<UFieldSystemMetaData*> MetaDatas() const { return Read<TArray<UFieldSystemMetaData*>>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x10, Type: ArrayProperty)

    void SET_TargetNames(const TArray<FName>& Value) { Write<TArray<FName>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
    void SET_RootNodes(const TArray<UFieldNodeBase*>& Value) { Write<TArray<UFieldNodeBase*>>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: ArrayProperty)
    void SET_MetaDatas(const TArray<UFieldSystemMetaData*>& Value) { Write<TArray<UFieldSystemMetaData*>>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x10, Type: ArrayProperty)
};

