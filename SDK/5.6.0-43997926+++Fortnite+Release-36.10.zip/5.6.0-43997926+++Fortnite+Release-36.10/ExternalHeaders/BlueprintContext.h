/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: BlueprintContext
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include "CoreUObject.h"
#include "Engine.h"

// Size: 0x30
class UBlueprintContextBase : public USubsystem
{
public:
};

// Size: 0x28
class UBlueprintContextLibrary : public UBlueprintFunctionLibrary
{
public:
};

