/**
 * ==============================
 *  AUEDumper Generated SDK File
 *  Package: AudioMixer
 *  Author : Stern
 * ==============================
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include "../Enums.h"
#include "CoreUObject.h"
#include "Engine.h"
#include "AudioExtensions.h"

// Size: 0x108
class UAudioBusSubsystem : public UAudioEngineSubsystem
{
public:
};

// Size: 0x438
class UScrubbedSound : public USoundWave
{
public:
    USoundWave* SoundWaveToScrub() const { return Read<USoundWave*>(uintptr_t(this) + 0x430); } // 0x430 (Size: 0x8, Type: ObjectProperty)

    void SET_SoundWaveToScrub(const USoundWave*& Value) { Write<USoundWave*>(uintptr_t(this) + 0x430, Value); } // 0x430 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x128
class UAudioDeviceNotificationSubsystem : public UEngineSubsystem
{
public:
};

// Size: 0x28
class UAudioMixerBlueprintLibrary : public UBlueprintFunctionLibrary
{
public:
};

// Size: 0x470
class USynthSound : public USoundWaveProcedural
{
public:
    TWeakObjectPtr<USynthComponent*> OwningSynthComponent() const { return Read<TWeakObjectPtr<USynthComponent*>>(uintptr_t(this) + 0x450); } // 0x450 (Size: 0x8, Type: WeakObjectProperty)

    void SET_OwningSynthComponent(const TWeakObjectPtr<USynthComponent*>& Value) { Write<TWeakObjectPtr<USynthComponent*>>(uintptr_t(this) + 0x450, Value); } // 0x450 (Size: 0x8, Type: WeakObjectProperty)
};

// Size: 0x8a0
class USynthComponent : public USceneComponent
{
public:
    bool bAutoDestroy() const { return (Read<uint8_t>(uintptr_t(this) + 0x240) >> 0x0) & 1; } // 0x240:0 (Size: 0x1, Type: BoolProperty)
    bool bStopWhenOwnerDestroyed() const { return (Read<uint8_t>(uintptr_t(this) + 0x240) >> 0x1) & 1; } // 0x240:1 (Size: 0x1, Type: BoolProperty)
    bool bAllowSpatialization() const { return (Read<uint8_t>(uintptr_t(this) + 0x240) >> 0x2) & 1; } // 0x240:2 (Size: 0x1, Type: BoolProperty)
    bool bOverrideAttenuation() const { return (Read<uint8_t>(uintptr_t(this) + 0x240) >> 0x3) & 1; } // 0x240:3 (Size: 0x1, Type: BoolProperty)
    bool bEnableBusSends() const { return (Read<uint8_t>(uintptr_t(this) + 0x244) >> 0x0) & 1; } // 0x244:0 (Size: 0x1, Type: BoolProperty)
    bool bEnableBaseSubmix() const { return (Read<uint8_t>(uintptr_t(this) + 0x244) >> 0x1) & 1; } // 0x244:1 (Size: 0x1, Type: BoolProperty)
    bool bEnableSubmixSends() const { return (Read<uint8_t>(uintptr_t(this) + 0x244) >> 0x2) & 1; } // 0x244:2 (Size: 0x1, Type: BoolProperty)
    USoundAttenuation* AttenuationSettings() const { return Read<USoundAttenuation*>(uintptr_t(this) + 0x248); } // 0x248 (Size: 0x8, Type: ObjectProperty)
    FSoundAttenuationSettings AttenuationOverrides() const { return Read<FSoundAttenuationSettings>(uintptr_t(this) + 0x250); } // 0x250 (Size: 0x3d0, Type: StructProperty)
    USoundConcurrency* ConcurrencySettings() const { return Read<USoundConcurrency*>(uintptr_t(this) + 0x620); } // 0x620 (Size: 0x8, Type: ObjectProperty)
    TSet<USoundConcurrency*> ConcurrencySet() const { return Read<TSet<USoundConcurrency*>>(uintptr_t(this) + 0x628); } // 0x628 (Size: 0x50, Type: SetProperty)
    FSoundModulationDefaultRoutingSettings ModulationRouting() const { return Read<FSoundModulationDefaultRoutingSettings>(uintptr_t(this) + 0x678); } // 0x678 (Size: 0x168, Type: StructProperty)
    USoundClass* SoundClass() const { return Read<USoundClass*>(uintptr_t(this) + 0x7e0); } // 0x7e0 (Size: 0x8, Type: ObjectProperty)
    USoundEffectSourcePresetChain* SourceEffectChain() const { return Read<USoundEffectSourcePresetChain*>(uintptr_t(this) + 0x7e8); } // 0x7e8 (Size: 0x8, Type: ObjectProperty)
    USoundSubmixBase* SoundSubmix() const { return Read<USoundSubmixBase*>(uintptr_t(this) + 0x7f0); } // 0x7f0 (Size: 0x8, Type: ObjectProperty)
    TArray<FSoundSubmixSendInfo> SoundSubmixSends() const { return Read<TArray<FSoundSubmixSendInfo>>(uintptr_t(this) + 0x7f8); } // 0x7f8 (Size: 0x10, Type: ArrayProperty)
    TArray<FSoundSourceBusSendInfo> BusSends() const { return Read<TArray<FSoundSourceBusSendInfo>>(uintptr_t(this) + 0x808); } // 0x808 (Size: 0x10, Type: ArrayProperty)
    TArray<FSoundSourceBusSendInfo> PreEffectBusSends() const { return Read<TArray<FSoundSourceBusSendInfo>>(uintptr_t(this) + 0x818); } // 0x818 (Size: 0x10, Type: ArrayProperty)
    bool bIsUISound() const { return (Read<uint8_t>(uintptr_t(this) + 0x828) >> 0x0) & 1; } // 0x828:0 (Size: 0x1, Type: BoolProperty)
    bool bIsPreviewSound() const { return (Read<uint8_t>(uintptr_t(this) + 0x828) >> 0x1) & 1; } // 0x828:1 (Size: 0x1, Type: BoolProperty)
    int32_t EnvelopeFollowerAttackTime() const { return Read<int32_t>(uintptr_t(this) + 0x82c); } // 0x82c (Size: 0x4, Type: IntProperty)
    int32_t EnvelopeFollowerReleaseTime() const { return Read<int32_t>(uintptr_t(this) + 0x830); } // 0x830 (Size: 0x4, Type: IntProperty)
    USynthSound* Synth() const { return Read<USynthSound*>(uintptr_t(this) + 0x868); } // 0x868 (Size: 0x8, Type: ObjectProperty)
    UAudioComponent* AudioComponent() const { return Read<UAudioComponent*>(uintptr_t(this) + 0x870); } // 0x870 (Size: 0x8, Type: ObjectProperty)

    void SET_bAutoDestroy(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x240); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x240, B); } // 0x240:0 (Size: 0x1, Type: BoolProperty)
    void SET_bStopWhenOwnerDestroyed(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x240); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x240, B); } // 0x240:1 (Size: 0x1, Type: BoolProperty)
    void SET_bAllowSpatialization(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x240); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x240, B); } // 0x240:2 (Size: 0x1, Type: BoolProperty)
    void SET_bOverrideAttenuation(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x240); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x240, B); } // 0x240:3 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableBusSends(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x244); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x244, B); } // 0x244:0 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableBaseSubmix(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x244); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x244, B); } // 0x244:1 (Size: 0x1, Type: BoolProperty)
    void SET_bEnableSubmixSends(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x244); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x244, B); } // 0x244:2 (Size: 0x1, Type: BoolProperty)
    void SET_AttenuationSettings(const USoundAttenuation*& Value) { Write<USoundAttenuation*>(uintptr_t(this) + 0x248, Value); } // 0x248 (Size: 0x8, Type: ObjectProperty)
    void SET_AttenuationOverrides(const FSoundAttenuationSettings& Value) { Write<FSoundAttenuationSettings>(uintptr_t(this) + 0x250, Value); } // 0x250 (Size: 0x3d0, Type: StructProperty)
    void SET_ConcurrencySettings(const USoundConcurrency*& Value) { Write<USoundConcurrency*>(uintptr_t(this) + 0x620, Value); } // 0x620 (Size: 0x8, Type: ObjectProperty)
    void SET_ConcurrencySet(const TSet<USoundConcurrency*>& Value) { Write<TSet<USoundConcurrency*>>(uintptr_t(this) + 0x628, Value); } // 0x628 (Size: 0x50, Type: SetProperty)
    void SET_ModulationRouting(const FSoundModulationDefaultRoutingSettings& Value) { Write<FSoundModulationDefaultRoutingSettings>(uintptr_t(this) + 0x678, Value); } // 0x678 (Size: 0x168, Type: StructProperty)
    void SET_SoundClass(const USoundClass*& Value) { Write<USoundClass*>(uintptr_t(this) + 0x7e0, Value); } // 0x7e0 (Size: 0x8, Type: ObjectProperty)
    void SET_SourceEffectChain(const USoundEffectSourcePresetChain*& Value) { Write<USoundEffectSourcePresetChain*>(uintptr_t(this) + 0x7e8, Value); } // 0x7e8 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundSubmix(const USoundSubmixBase*& Value) { Write<USoundSubmixBase*>(uintptr_t(this) + 0x7f0, Value); } // 0x7f0 (Size: 0x8, Type: ObjectProperty)
    void SET_SoundSubmixSends(const TArray<FSoundSubmixSendInfo>& Value) { Write<TArray<FSoundSubmixSendInfo>>(uintptr_t(this) + 0x7f8, Value); } // 0x7f8 (Size: 0x10, Type: ArrayProperty)
    void SET_BusSends(const TArray<FSoundSourceBusSendInfo>& Value) { Write<TArray<FSoundSourceBusSendInfo>>(uintptr_t(this) + 0x808, Value); } // 0x808 (Size: 0x10, Type: ArrayProperty)
    void SET_PreEffectBusSends(const TArray<FSoundSourceBusSendInfo>& Value) { Write<TArray<FSoundSourceBusSendInfo>>(uintptr_t(this) + 0x818, Value); } // 0x818 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsUISound(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x828); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x828, B); } // 0x828:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsPreviewSound(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x828); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x828, B); } // 0x828:1 (Size: 0x1, Type: BoolProperty)
    void SET_EnvelopeFollowerAttackTime(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x82c, Value); } // 0x82c (Size: 0x4, Type: IntProperty)
    void SET_EnvelopeFollowerReleaseTime(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x830, Value); } // 0x830 (Size: 0x4, Type: IntProperty)
    void SET_Synth(const USynthSound*& Value) { Write<USynthSound*>(uintptr_t(this) + 0x868, Value); } // 0x868 (Size: 0x8, Type: ObjectProperty)
    void SET_AudioComponent(const UAudioComponent*& Value) { Write<UAudioComponent*>(uintptr_t(this) + 0x870, Value); } // 0x870 (Size: 0x8, Type: ObjectProperty)
};

// Size: 0x150
class USubmixEffectDynamicsProcessorPreset : public USoundEffectSubmixPreset
{
public:
    FSubmixEffectDynamicsProcessorSettings Settings() const { return Read<FSubmixEffectDynamicsProcessorSettings>(uintptr_t(this) + 0xf0); } // 0xf0 (Size: 0x60, Type: StructProperty)

    void SET_Settings(const FSubmixEffectDynamicsProcessorSettings& Value) { Write<FSubmixEffectDynamicsProcessorSettings>(uintptr_t(this) + 0xf0, Value); } // 0xf0 (Size: 0x60, Type: StructProperty)
};

// Size: 0xb0
class USubmixEffectSubmixEQPreset : public USoundEffectSubmixPreset
{
public:
    FSubmixEffectSubmixEQSettings Settings() const { return Read<FSubmixEffectSubmixEQSettings>(uintptr_t(this) + 0xa0); } // 0xa0 (Size: 0x10, Type: StructProperty)

    void SET_Settings(const FSubmixEffectSubmixEQSettings& Value) { Write<FSubmixEffectSubmixEQSettings>(uintptr_t(this) + 0xa0, Value); } // 0xa0 (Size: 0x10, Type: StructProperty)
};

// Size: 0x110
class USubmixEffectReverbPreset : public USoundEffectSubmixPreset
{
public:
    FSubmixEffectReverbSettings Settings() const { return Read<FSubmixEffectReverbSettings>(uintptr_t(this) + 0xd0); } // 0xd0 (Size: 0x40, Type: StructProperty)

    void SET_Settings(const FSubmixEffectReverbSettings& Value) { Write<FSubmixEffectReverbSettings>(uintptr_t(this) + 0xd0, Value); } // 0xd0 (Size: 0x40, Type: StructProperty)
};

// Size: 0xa8
class UAudioGenerator : public UObject
{
public:
};

// Size: 0x208
class UQuartzClockHandle : public UObject
{
public:
};

// Size: 0x68
class UQuartzSubsystem : public UTickableWorldSubsystem
{
public:
};

// Size: 0x48
struct FAudioOutputDeviceInfo
{
public:
    FString Name() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString DeviceID() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    int32_t NumChannels() const { return Read<int32_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: IntProperty)
    int32_t SampleRate() const { return Read<int32_t>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: IntProperty)
    uint8_t Format() const { return Read<uint8_t>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x1, Type: EnumProperty)
    TArray<EAudioMixerChannelType> OutputChannelArray() const { return Read<TArray<EAudioMixerChannelType>>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    bool bIsSystemDefault() const { return (Read<uint8_t>(uintptr_t(this) + 0x40) >> 0x0) & 1; } // 0x40:0 (Size: 0x1, Type: BoolProperty)
    bool bIsCurrentDevice() const { return (Read<uint8_t>(uintptr_t(this) + 0x40) >> 0x1) & 1; } // 0x40:1 (Size: 0x1, Type: BoolProperty)

    void SET_Name(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_DeviceID(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_NumChannels(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: IntProperty)
    void SET_SampleRate(const int32_t& Value) { Write<int32_t>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: IntProperty)
    void SET_Format(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x1, Type: EnumProperty)
    void SET_OutputChannelArray(const TArray<EAudioMixerChannelType>& Value) { Write<TArray<EAudioMixerChannelType>>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x10, Type: ArrayProperty)
    void SET_bIsSystemDefault(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x40); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x40, B); } // 0x40:0 (Size: 0x1, Type: BoolProperty)
    void SET_bIsCurrentDevice(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x40); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x40, B); } // 0x40:1 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x28
struct FSwapAudioOutputResult
{
public:
    FString CurrentDeviceId() const { return Read<FString>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: StrProperty)
    FString RequestedDeviceId() const { return Read<FString>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x10, Type: StrProperty)
    uint8_t Result() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)

    void SET_CurrentDeviceId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: StrProperty)
    void SET_RequestedDeviceId(const FString& Value) { Write<FString>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x10, Type: StrProperty)
    void SET_Result(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
};

// Size: 0xc
struct FSubmixEffectDynamicProcessorFilterSettings
{
public:
    bool bEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0x0) >> 0x0) & 1; } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    float Cutoff() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float GainDb() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)

    void SET_bEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x0); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x0, B); } // 0x0:0 (Size: 0x1, Type: BoolProperty)
    void SET_Cutoff(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_GainDb(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
};

// Size: 0x60
struct FSubmixEffectDynamicsProcessorSettings
{
public:
    uint8_t DynamicsProcessorType() const { return Read<uint8_t>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: EnumProperty)
    uint8_t PeakMode() const { return Read<uint8_t>(uintptr_t(this) + 0x1); } // 0x1 (Size: 0x1, Type: EnumProperty)
    uint8_t LinkMode() const { return Read<uint8_t>(uintptr_t(this) + 0x2); } // 0x2 (Size: 0x1, Type: EnumProperty)
    float InputGainDb() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float ThresholdDb() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float Ratio() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    float KneeBandwidthDb() const { return Read<float>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x4, Type: FloatProperty)
    float LookAheadMsec() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float AttackTimeMsec() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float ReleaseTimeMsec() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    uint8_t KeySource() const { return Read<uint8_t>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x1, Type: EnumProperty)
    UAudioBus* ExternalAudioBus() const { return Read<UAudioBus*>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    USoundSubmix* ExternalSubmix() const { return Read<USoundSubmix*>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    bool bChannelLinked() const { return (Read<uint8_t>(uintptr_t(this) + 0x38) >> 0x0) & 1; } // 0x38:0 (Size: 0x1, Type: BoolProperty)
    bool bAnalogMode() const { return (Read<uint8_t>(uintptr_t(this) + 0x38) >> 0x1) & 1; } // 0x38:1 (Size: 0x1, Type: BoolProperty)
    bool bBypass() const { return (Read<uint8_t>(uintptr_t(this) + 0x38) >> 0x2) & 1; } // 0x38:2 (Size: 0x1, Type: BoolProperty)
    bool bKeyAudition() const { return (Read<uint8_t>(uintptr_t(this) + 0x38) >> 0x3) & 1; } // 0x38:3 (Size: 0x1, Type: BoolProperty)
    float KeyGainDb() const { return Read<float>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x4, Type: FloatProperty)
    float OutputGainDb() const { return Read<float>(uintptr_t(this) + 0x40); } // 0x40 (Size: 0x4, Type: FloatProperty)
    FSubmixEffectDynamicProcessorFilterSettings KeyHighshelf() const { return Read<FSubmixEffectDynamicProcessorFilterSettings>(uintptr_t(this) + 0x44); } // 0x44 (Size: 0xc, Type: StructProperty)
    FSubmixEffectDynamicProcessorFilterSettings KeyLowshelf() const { return Read<FSubmixEffectDynamicProcessorFilterSettings>(uintptr_t(this) + 0x50); } // 0x50 (Size: 0xc, Type: StructProperty)

    void SET_DynamicsProcessorType(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: EnumProperty)
    void SET_PeakMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x1, Value); } // 0x1 (Size: 0x1, Type: EnumProperty)
    void SET_LinkMode(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x2, Value); } // 0x2 (Size: 0x1, Type: EnumProperty)
    void SET_InputGainDb(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_ThresholdDb(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_Ratio(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_KneeBandwidthDb(const float& Value) { Write<float>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x4, Type: FloatProperty)
    void SET_LookAheadMsec(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_AttackTimeMsec(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_ReleaseTimeMsec(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_KeySource(const uint8_t& Value) { Write<uint8_t>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x1, Type: EnumProperty)
    void SET_ExternalAudioBus(const UAudioBus*& Value) { Write<UAudioBus*>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x8, Type: ObjectProperty)
    void SET_ExternalSubmix(const USoundSubmix*& Value) { Write<USoundSubmix*>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x8, Type: ObjectProperty)
    void SET_bChannelLinked(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x38); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0x38, B); } // 0x38:0 (Size: 0x1, Type: BoolProperty)
    void SET_bAnalogMode(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x38); B = (B & ~(1 << 0x1)) | (Value << 0x1); Write<uint8_t>(uintptr_t(this) + 0x38, B); } // 0x38:1 (Size: 0x1, Type: BoolProperty)
    void SET_bBypass(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x38); B = (B & ~(1 << 0x2)) | (Value << 0x2); Write<uint8_t>(uintptr_t(this) + 0x38, B); } // 0x38:2 (Size: 0x1, Type: BoolProperty)
    void SET_bKeyAudition(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0x38); B = (B & ~(1 << 0x3)) | (Value << 0x3); Write<uint8_t>(uintptr_t(this) + 0x38, B); } // 0x38:3 (Size: 0x1, Type: BoolProperty)
    void SET_KeyGainDb(const float& Value) { Write<float>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x4, Type: FloatProperty)
    void SET_OutputGainDb(const float& Value) { Write<float>(uintptr_t(this) + 0x40, Value); } // 0x40 (Size: 0x4, Type: FloatProperty)
    void SET_KeyHighshelf(const FSubmixEffectDynamicProcessorFilterSettings& Value) { Write<FSubmixEffectDynamicProcessorFilterSettings>(uintptr_t(this) + 0x44, Value); } // 0x44 (Size: 0xc, Type: StructProperty)
    void SET_KeyLowshelf(const FSubmixEffectDynamicProcessorFilterSettings& Value) { Write<FSubmixEffectDynamicProcessorFilterSettings>(uintptr_t(this) + 0x50, Value); } // 0x50 (Size: 0xc, Type: StructProperty)
};

// Size: 0x10
struct FSubmixEffectEQBand
{
public:
    float Frequency() const { return Read<float>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x4, Type: FloatProperty)
    float Bandwidth() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float GainDb() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    bool bEnabled() const { return (Read<uint8_t>(uintptr_t(this) + 0xc) >> 0x0) & 1; } // 0xc:0 (Size: 0x1, Type: BoolProperty)

    void SET_Frequency(const float& Value) { Write<float>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x4, Type: FloatProperty)
    void SET_Bandwidth(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_GainDb(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_bEnabled(bool Value) { auto B = Read<uint8_t>(uintptr_t(this) + 0xc); B = (B & ~(1 << 0x0)) | (Value << 0x0); Write<uint8_t>(uintptr_t(this) + 0xc, B); } // 0xc:0 (Size: 0x1, Type: BoolProperty)
};

// Size: 0x10
struct FSubmixEffectSubmixEQSettings
{
public:
    TArray<FSubmixEffectEQBand> EqBands() const { return Read<TArray<FSubmixEffectEQBand>>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x10, Type: ArrayProperty)

    void SET_EqBands(const TArray<FSubmixEffectEQBand>& Value) { Write<TArray<FSubmixEffectEQBand>>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x10, Type: ArrayProperty)
};

// Size: 0x40
struct FSubmixEffectReverbSettings
{
public:
    bool bBypassEarlyReflections() const { return Read<bool>(uintptr_t(this) + 0x0); } // 0x0 (Size: 0x1, Type: BoolProperty)
    float ReflectionsDelay() const { return Read<float>(uintptr_t(this) + 0x4); } // 0x4 (Size: 0x4, Type: FloatProperty)
    float GainHF() const { return Read<float>(uintptr_t(this) + 0x8); } // 0x8 (Size: 0x4, Type: FloatProperty)
    float ReflectionsGain() const { return Read<float>(uintptr_t(this) + 0xc); } // 0xc (Size: 0x4, Type: FloatProperty)
    bool bBypassLateReflections() const { return Read<bool>(uintptr_t(this) + 0x10); } // 0x10 (Size: 0x1, Type: BoolProperty)
    float LateDelay() const { return Read<float>(uintptr_t(this) + 0x14); } // 0x14 (Size: 0x4, Type: FloatProperty)
    float DecayTime() const { return Read<float>(uintptr_t(this) + 0x18); } // 0x18 (Size: 0x4, Type: FloatProperty)
    float Density() const { return Read<float>(uintptr_t(this) + 0x1c); } // 0x1c (Size: 0x4, Type: FloatProperty)
    float Diffusion() const { return Read<float>(uintptr_t(this) + 0x20); } // 0x20 (Size: 0x4, Type: FloatProperty)
    float AirAbsorptionGainHF() const { return Read<float>(uintptr_t(this) + 0x24); } // 0x24 (Size: 0x4, Type: FloatProperty)
    float DecayHFRatio() const { return Read<float>(uintptr_t(this) + 0x28); } // 0x28 (Size: 0x4, Type: FloatProperty)
    float LateGain() const { return Read<float>(uintptr_t(this) + 0x2c); } // 0x2c (Size: 0x4, Type: FloatProperty)
    float Gain() const { return Read<float>(uintptr_t(this) + 0x30); } // 0x30 (Size: 0x4, Type: FloatProperty)
    float WetLevel() const { return Read<float>(uintptr_t(this) + 0x34); } // 0x34 (Size: 0x4, Type: FloatProperty)
    float DryLevel() const { return Read<float>(uintptr_t(this) + 0x38); } // 0x38 (Size: 0x4, Type: FloatProperty)
    bool bBypass() const { return Read<bool>(uintptr_t(this) + 0x3c); } // 0x3c (Size: 0x1, Type: BoolProperty)

    void SET_bBypassEarlyReflections(const bool& Value) { Write<bool>(uintptr_t(this) + 0x0, Value); } // 0x0 (Size: 0x1, Type: BoolProperty)
    void SET_ReflectionsDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x4, Value); } // 0x4 (Size: 0x4, Type: FloatProperty)
    void SET_GainHF(const float& Value) { Write<float>(uintptr_t(this) + 0x8, Value); } // 0x8 (Size: 0x4, Type: FloatProperty)
    void SET_ReflectionsGain(const float& Value) { Write<float>(uintptr_t(this) + 0xc, Value); } // 0xc (Size: 0x4, Type: FloatProperty)
    void SET_bBypassLateReflections(const bool& Value) { Write<bool>(uintptr_t(this) + 0x10, Value); } // 0x10 (Size: 0x1, Type: BoolProperty)
    void SET_LateDelay(const float& Value) { Write<float>(uintptr_t(this) + 0x14, Value); } // 0x14 (Size: 0x4, Type: FloatProperty)
    void SET_DecayTime(const float& Value) { Write<float>(uintptr_t(this) + 0x18, Value); } // 0x18 (Size: 0x4, Type: FloatProperty)
    void SET_Density(const float& Value) { Write<float>(uintptr_t(this) + 0x1c, Value); } // 0x1c (Size: 0x4, Type: FloatProperty)
    void SET_Diffusion(const float& Value) { Write<float>(uintptr_t(this) + 0x20, Value); } // 0x20 (Size: 0x4, Type: FloatProperty)
    void SET_AirAbsorptionGainHF(const float& Value) { Write<float>(uintptr_t(this) + 0x24, Value); } // 0x24 (Size: 0x4, Type: FloatProperty)
    void SET_DecayHFRatio(const float& Value) { Write<float>(uintptr_t(this) + 0x28, Value); } // 0x28 (Size: 0x4, Type: FloatProperty)
    void SET_LateGain(const float& Value) { Write<float>(uintptr_t(this) + 0x2c, Value); } // 0x2c (Size: 0x4, Type: FloatProperty)
    void SET_Gain(const float& Value) { Write<float>(uintptr_t(this) + 0x30, Value); } // 0x30 (Size: 0x4, Type: FloatProperty)
    void SET_WetLevel(const float& Value) { Write<float>(uintptr_t(this) + 0x34, Value); } // 0x34 (Size: 0x4, Type: FloatProperty)
    void SET_DryLevel(const float& Value) { Write<float>(uintptr_t(this) + 0x38, Value); } // 0x38 (Size: 0x4, Type: FloatProperty)
    void SET_bBypass(const bool& Value) { Write<bool>(uintptr_t(this) + 0x3c, Value); } // 0x3c (Size: 0x1, Type: BoolProperty)
};

